from abc import ABC,abstractmethod
import logging
from blues_lib.types import CleanOpts

class BaseCleaner(ABC):

  def __init__(self,options:CleanOpts):
    '''
    The abstract class of handlers 
    '''
    self._options = options
    self._logger = logging.getLogger('airflow.task')

  @abstractmethod
  def clean(self):
    pass