from blues_lib.services.cleaner.BaseCleaner import BaseCleaner
from blues_lib.utils.MatFiler import MatFiler
from blues_lib.utils.BluesFiler import BluesFiler
from blues_lib.types import CleanOpts

class DirCleaner(BaseCleaner):
  _DEFAULT_DIRS:list[str] = [MatFiler.get_log_root()]

  def __init__(self,options:CleanOpts):
    super().__init__(options)
    
  def clean(self)->int:
    validity_days:int = int(self._options.get('validity_days',30))
    dirs:list[str] = self._options.get('dirs') or self._DEFAULT_DIRS
    total_count:int = 0
    for dir in dirs:
      count = BluesFiler.removedirs(dir,validity_days) or 0
      self._logger.info(f'{self.__class__.__name__} Deleted {count} files from {dir}')
      total_count += count
    return total_count
