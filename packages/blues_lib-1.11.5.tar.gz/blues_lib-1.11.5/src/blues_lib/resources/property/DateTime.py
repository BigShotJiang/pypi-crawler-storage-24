from typing import Any
from blues_lib.utils.BluesDateTime import BluesDateTime

class DateTime():

  PROPERTIES = {
    "timestamp": lambda: BluesDateTime.get_timestamp(),
    "now": lambda: BluesDateTime.get_now(),
  }

  @classmethod
  def get(cls, name:str)->Any:
    if name not in cls.PROPERTIES:
      raise ValueError(f"property {name} not found")
    return cls.PROPERTIES[name]()
