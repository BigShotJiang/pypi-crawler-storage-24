import re
from typing import Any
from blues_lib.utils.ResourceReader import ResourceReader
from blues_lib.utils.MCPUri import MCPUri
from blues_lib.utils.DotFileReader import DotFileReader
from blues_lib.utils.FileReader import FileReader
from blues_lib.resources.property.PropertyReader import PropertyReader

class ResourceManager:
  
  SCHEME_NAMESPACES = {
    'definition': 'blues_lib.resources.definition',
    'template': 'blues_lib.resources.template',
    'bizdata': 'blues_lib.resources.bizdata',
    'schema': 'blues_lib.resources.schema',
  }
  TEMP_RESOURCES = {}

  @classmethod
  def read(cls, uri:str) -> Any:
    '''
    Read resource from URI
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
    Returns:
      Any: Resource content
    '''
    if uri in cls.TEMP_RESOURCES:
      return cls.TEMP_RESOURCES[uri]
    
    segments:dict[str,str] = MCPUri.parse(uri)
    scheme:str = segments.get('scheme')
    netloc:str = segments.get('netloc','')
    path:str = segments.get('path','')

    if scheme == 'property':
      return cls.read_property(netloc+path)

    package:str = cls.SCHEME_NAMESPACES.get(scheme,'')
    if not package:
      raise ValueError(f'{uri} is a unknow resource')

    return ResourceReader.read_hocon(package, netloc+path+'.conf')

  @classmethod
  def read_temp(cls, uri:str) -> Any|None:
    '''
    Read temporary resource from URI
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
    Returns:
      Any: Resource content
    '''
    return cls.TEMP_RESOURCES.get(uri)

  @classmethod
  def read_property(cls, property_path:str) -> Any|None:
    '''
    Read property resource from URI
    Args:
      property_path {str} : Property path, such as 'datetime/now'
    Returns:
      Any: Property content
    '''
    return PropertyReader.get(property_path)

  @classmethod
  def register(cls, uri:str, resource_or_path:Any) -> str:
    '''
    Register temporary resource to URI
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
      resource {Any} : Resource content
    Returns:
      Any: Resource content
    '''
    if cls.is_dot_path(resource_or_path):
      return cls.register_by_dot_path(uri, resource_or_path)

    if cls.is_file_path(resource_or_path):
      return cls.register_by_file_path(uri, resource_or_path)

    cls.TEMP_RESOURCES[uri] = resource_or_path
    return uri

  @classmethod
  def is_dot_path(cls, dot_path:str) -> bool:
    '''
    Check if dot path is valid
    Args:
      dot_path {str} : Dot path, such as 'tests.task.browser.login.def'
    Returns:
      bool: True if dot path is valid
    '''
    if not dot_path or not isinstance(dot_path, str):
      return False
    pattern = r'^[^/\\.]+(?:\.[^/\\.]+)+$'
    return bool(re.match(pattern, dot_path))

  @classmethod
  def is_file_path(cls, file_path:str) -> bool:
    '''
    Check if file path is valid, support Win and Linux and Mac
    Args:
      file_path {str} : absolute file path, such as '/Users/bluesliu/Documents/Projects/python/blues-lib-py/tests/task/browser/login.def'
    Returns:
      bool: True if file path is valid
    '''
    if not file_path or not isinstance(file_path, str):
      return False
    pattern = r'^(?:[a-zA-Z]:[/\\]|/|\\{2}|//).+'
    return bool(re.match(pattern, file_path))

  @classmethod
  def register_by_dot_path(cls, uri:str, dot_path:str) -> str:
    '''
    Register temporary resource to URI by file path
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
      dot_path {str} : Dot path, such as 'tests.task.browser.login.def'
    Returns:
      Any: Resource content
    '''
    resource:Any = DotFileReader.read_hocon('blues-lib-py',dot_path)
    cls.TEMP_RESOURCES[uri] = resource
    return uri
  
  @classmethod
  def register_by_file_path(cls, uri:str, file_path:str) -> str:
    '''
    Register temporary resource to URI by file path
    Args:
      uri {str} : URI, such as 'definition://ability/login/account'
      file_path {str} : absolute file path, such as '/Users/bluesliu/Documents/Projects/python/blues-lib-py/tests/task/browser/login.def'
    Returns:
      Any: Resource content
    '''
    resource:Any = FileReader.read_hocon(file_path)
    cls.TEMP_RESOURCES[uri] = resource
    return uri
