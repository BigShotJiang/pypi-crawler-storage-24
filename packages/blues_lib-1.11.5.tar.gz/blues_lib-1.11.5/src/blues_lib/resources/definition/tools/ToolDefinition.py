from blues_lib.resources.ResourceManager import ResourceManager

class ToolDefinition:
  
  _URI_DICT = {
    # atom ability
    'click':'definition://tools/ability/atom/click',
    'dbclick':'definition://tools/ability/atom/dbclick',
    'get_text':'definition://tools/ability/atom/get_text',
    
    # seq ability
    'cast':'definition://tools/ability/seq/cast',
    'cast_loop':'definition://tools/ability/seq/cast_loop',
    'cast_page':'definition://tools/ability/seq/cast_page',
    'cast_combo':'definition://tools/ability/seq/cast_combo',
    
    # common 
    'ability_collection':'definition://tools/ability/ability_collection',
  }
  
  @classmethod 
  def get_uris(cls)->dict[str,str]:
    return cls._URI_DICT
  
  @classmethod 
  def get_uri(cls,tool_name:str)->str:
    return cls._URI_DICT[tool_name] if cls.exists(tool_name) else ''
  
  @classmethod 
  def exists(cls,tool_name:str)->bool:
    return tool_name in cls._URI_DICT

  @classmethod 
  def get(cls,tool_name:str)->dict|None:
    uri = cls.get_uri(tool_name)
    return ResourceManager.read(uri) if uri else None
  
  @classmethod 
  def get_input_schema(cls,tool_name:str)->dict|None:
    definition = cls.get(tool_name)
    return definition.get('input_schema') if definition else None
  
  @classmethod 
  def list(cls)->list[dict]:
    defs:list[dict] = []
    for tool_name in cls._URI_DICT:
      definition:dict|None = cls.get(tool_name)
      if definition:
        defs.append(definition)
    return defs