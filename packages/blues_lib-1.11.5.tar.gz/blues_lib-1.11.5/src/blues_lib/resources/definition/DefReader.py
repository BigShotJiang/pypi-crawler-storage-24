from blues_lib.utils.ResourceReader import ResourceReader
from blues_lib.utils.DotFileReader import DotFileReader

class DefReader:
  
  PACKAGE = 'blues_lib.resources.definition'

  @classmethod
  def read(cls, dot_path:str) -> dict:
    extension:str = 'conf'
    slash_path:str = DotFileReader.get_slash_path(dot_path,extension)
    return ResourceReader.read_hocon(cls.PACKAGE, slash_path)
