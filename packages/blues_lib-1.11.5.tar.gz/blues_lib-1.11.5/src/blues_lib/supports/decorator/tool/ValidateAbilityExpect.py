from typing import Any
from functools import wraps
import logging
from blues_lib.types import AbilityExpect
from blues_lib.supports.dp.exception.BlockException import BlockException
from blues_lib.supports.dp.exception.SkipAbilityException import SkipAbilityException
from blues_lib.supports.dp.exception.SkipFlowException import SkipFlowException
from blues_lib.supports.dp.exception.SkipSeqException import SkipSeqException
from blues_lib.supports.dp.exception.SkipTaskException import SkipTaskException
from blues_lib.supports.dp.exception.RetryException import RetryException
from blues_lib.supports.dp.exception.FailTaskException import FailTaskException
from blues_lib.utils.Expecter import Expecter

class ValidateAbilityExpect():
  EXCEPTIONS = {
    BlockException.__name__:BlockException,
    SkipAbilityException.__name__:SkipAbilityException,
    SkipSeqException.__name__:SkipSeqException,
    SkipFlowException.__name__:SkipFlowException,
    SkipTaskException.__name__:SkipTaskException,
    RetryException.__name__:RetryException,
    FailTaskException.__name__:FailTaskException,
  }

  def __init__(self):
    self._logger = logging.getLogger('airflow.task')

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,*args,**kwargs):
      result:Any = func(instance,*args,**kwargs)
      if args:
        options:dict = args[0]
        caller:str = instance.__class__.__name__
        self._match(caller,options,result)
      return result
    return wrapper
  
  def _match(self,caller:str,options:dict,result:Any)->None:
    expect_opts:AbilityExpect = options.get('expect',{})
    if not expect_opts:
      return 

    method = expect_opts.get('method', 'to_be')
    expect_opts['result'] = result
    matcher = getattr(Expecter, method, None)
    if not matcher:
      raise ValueError(f"Invalid expect method: {method}")

    if not matcher(expect_opts):
      expect_exception:str = expect_opts.get('exception')
      exception_class = self.EXCEPTIONS.get(expect_exception,BlockException)
      message = f"{caller} : expect {method} {expect_opts.get('value')}, but got {result}"
      raise exception_class(result, message)
    
    
