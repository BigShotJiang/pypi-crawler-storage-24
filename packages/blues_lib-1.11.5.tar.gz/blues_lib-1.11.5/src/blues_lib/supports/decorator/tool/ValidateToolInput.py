from functools import wraps
from blues_lib.resources.definition.tools.ToolDefinition import ToolDefinition
from blues_lib.tools.meta.validate.SchemaValidator import SchemaValidator

import logging

class ValidateToolInput():
  def __init__(self,uri_name:str=''):
    self._logger = logging.getLogger('airflow.task')
    self._uri_name = uri_name

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,*args,**kwargs):
      func_name:str = self._uri_name or func.__name__
      is_opts_empty:bool = len(args)==0 or not args[0]

      # Seq ability: options is required
      from blues_lib.tools.ability.sequence.BaseSeqAbility import BaseSeqAbility
      is_seq_ability:bool = isinstance(instance,BaseSeqAbility)
      if is_seq_ability and is_opts_empty:
        raise ValueError('Seq ability options is required')

      # Atom ability: options is optional
      if not is_opts_empty:
        options:dict = args[0]
        input_schema:dict = ToolDefinition.get_input_schema(func_name) 
        if not input_schema:
          self._logger.info(f'No input schema found for tool {func_name}, skip validation')
        else:
          stat,message = SchemaValidator.validate(options,input_schema)
          if not stat:
            raise ValueError(message)

      return func(instance,*args,**kwargs)
    return wrapper