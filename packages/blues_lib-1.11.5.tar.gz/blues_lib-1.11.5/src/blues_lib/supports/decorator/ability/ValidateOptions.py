from functools import wraps
from blues_lib.tools.meta.validate.SchemaValidator import SchemaValidator

import logging

class ValidateOptions():
  def __init__(self,tpl_path:str):
    self._logger = logging.getLogger('airflow.task')
    self._tpl_path = tpl_path

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,*args,**kwargs):

      # options is optional
      if len(args)>0 and args[0]:
        options:dict = args[0]
        stat,message = SchemaValidator.validate_with_template(options,self._tpl_path)
        if not stat:
          raise ValueError(message)

      return func(instance,*args,**kwargs)
    return wrapper