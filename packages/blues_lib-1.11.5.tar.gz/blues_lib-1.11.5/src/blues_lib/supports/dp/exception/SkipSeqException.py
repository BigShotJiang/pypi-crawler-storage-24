from typing import Any

class SkipSeqException(Exception):
  def __init__(self, result:Any,message="seq skip exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)