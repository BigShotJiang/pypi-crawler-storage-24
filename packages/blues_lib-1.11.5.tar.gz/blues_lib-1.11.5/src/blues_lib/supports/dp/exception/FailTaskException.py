from typing import Any

class FailTaskException(Exception):
  def __init__(self, result:Any,message="task fail exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)