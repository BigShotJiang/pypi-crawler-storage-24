from typing import Any
class BlockException(Exception):
  def __init__(self,result:Any, message="ability block exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)