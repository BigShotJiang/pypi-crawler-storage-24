import re
from blues_lib.utils.hocon.HoconRenderer import HoconRenderer 
from blues_lib.tools.meta.validate.SchemaValidator import SchemaValidator

class MetaRenderer():

  @classmethod
  def render(cls,definition:dict,bizdata:dict|None = None)->dict:
    '''
    Base on a definition, render it with the bizdata
      - replace the environment variables ${var}
      - include the file  %{include a.b.c}
      - calcualte the function %{function fn_name}
      - replace the bizdata variables {{var}}
    Args:
      definition: The base data
      bizdata: The business data
    Returns:
      The deep cloned rendered definition
    '''
    if not definition:
      return {}
    return HoconRenderer(definition,bizdata).render()

  @classmethod
  def render_and_validate(cls,validate_tpl:str,definition:dict,bizdata:dict|None = None)->dict:
    meta:dict = cls.render(definition,bizdata)
    stat,message = SchemaValidator.validate_with_template(meta,validate_tpl)
    if not stat:
      raise ValueError(message)
    return meta

  @classmethod
  def render_by_self(cls,template:dict)->dict:
    if not template:
      return {}
    return HoconRenderer(template).render_by_self()

  @classmethod
  def render_node(cls,key:str,definition:dict,bizdata:dict|None = None)->dict:
    '''
    render the definition node with the bizdata
    Args:
      key: The key of the definition node to render
      definition: the base data
      bizdata: The business data
    Returns:
      The deep cloned rendered definition node
    '''
    if not definition:
      return {}
    # support replace the whole node,like {"tools":"{{form_tools}}"}
    node_def:dict|str = definition.get(key,{})
    if isinstance(node_def,str):
      name:str = cls._get_var_name(node_def)
      if not name:
        raise ValueError(f'Invalid tools replace: {node_def}')
      return bizdata.get(name,{})
    return MetaRenderer.render(node_def,bizdata) if node_def else {}
  
  @classmethod
  def _get_var_name(cls,placeholder:str)->str:
    pattern = r"^\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}$"
    # 使用 re.findall 提取所有匹配的分组
    match = re.match(pattern, placeholder)
    return match.group(1) if match else ''

  @classmethod
  def render_and_validate_node(cls,validate_tpl:str,key:str,definition:dict,bizdata:dict|None = None)->dict:
    '''
    render the definition node with the bizdata, and validate it with the schema
    Args:
      validate_tpl: The schema template path to validate the rendered node
      key: The key of the definition node to render
      definition: the base data
      bizdata: The business data
    Returns:
      The deep cloned rendered definition node
    '''
    node_meta:dict = cls.render_node(key,definition,bizdata)
    stat,message = SchemaValidator.validate_with_template(node_meta,validate_tpl)
    if not stat:
      raise ValueError(message)
    return node_meta