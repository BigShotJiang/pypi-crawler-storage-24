from typing import Any
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.tools.meta.bizdata.BizManager import BizManager
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,ToolDef,SeqCastOpts
from blues_lib.supports.dp.exception.SkipSeqException import SkipSeqException
from blues_lib.tools.ability.sequence.BaseSeq import BaseSeq

class BaseSeqLoop(BaseSeq):

  def _cast_items(self,items:list[dict[str,Any]],options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    results:list[list|dict] = []
    attempts:int = int(cast_opts.get('attempts') or -1)

    for idx,item in enumerate(items):
      if attempts>0 and idx>=attempts:
        break

      try:
        result:list[Any]|dict[str,Any] = self._cast_single(options,item,idx,bizdata)
      except SkipSeqException as e:
        self._logger.info(f'seq skip error: {e}')
        continue

      results.append(result)
      IterationHelper.delay(cast_opts)

    self._logger.info(f'cast loop by {len(items)} items (attempts={attempts}) and  get {len(results)} results')
    return results

  def _cast_single(self,options:SeqOpts,item:dict[str,Any],idx:int,bizdata:dict[str,Any])->list[Any]|dict[str,Any]:
    iter_bizdata:dict[str,Any] = BizManager.add_item(bizdata,item,idx)
    atoms:list[ToolDef]|dict[str,ToolDef] = MetaRenderer.render_node('tools',options,iter_bizdata)
    if not atoms:
      self._logger.warning('seq ability has no tools')
      return {}

    tool_defs:list[ToolDef]|dict[str,ToolDef] = self._get_std_tool_defs(atoms)
    self._update_atoms(tool_defs,item) 
    return self._seq_executor.execute(tool_defs)

  def _update_atoms(self,atoms:list[ToolDef]|dict[str,Any],item:dict[str,Any])->None:
    pass
