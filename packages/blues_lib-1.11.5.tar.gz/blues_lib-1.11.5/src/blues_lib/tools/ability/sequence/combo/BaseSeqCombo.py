from typing import Any
from blues_lib.tools.ability.sequence.flat.FlatSeqAbility import FlatSeqAbility
from blues_lib.tools.ability.sequence.loop.LoopSeqAbility import LoopSeqAbility

from blues_lib.types import SeqOpts,ToolDef
from blues_lib.tools.ability.sequence.BaseSeq import BaseSeq

class BaseSeqCombo(BaseSeq):
  
  def _cast_by_ability_name(self,atoms:list[ToolDef],bizdata:dict[str,Any])->list[Any]:
    results:list[Any] = []
    for atom in atoms:
      result = None
      name:str = atom.get('name')
      options:SeqOpts = atom.get('options')
      if name=='cast_loop':
        result = LoopSeqAbility(self._driver).cast_loop(options,bizdata)
      elif name=='cast':
        result = FlatSeqAbility(self._driver).cast(options,bizdata)
      else:
        raise ValueError(f'{self.__class__.__name__} Only support cast_loop and cast, but got {name}')
      results.append(result)
    return results
     
