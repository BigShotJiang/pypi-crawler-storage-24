from typing import Any
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.types import SeqOpts,ToolDef,SeqCastOpts
from blues_lib.tools.ability.sequence.loop.BaseSeqLoop import BaseSeqLoop

class EachLoop(BaseSeqLoop):
  
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    items:list[dict[str,Any]] = IterationHelper.get_items_by_element(self._facade,cast_opts)
    return self._cast_items(items,options,bizdata,cast_opts)
  
  def _update_atoms(self,atoms:list[ToolDef]|dict[str,Any],item:dict[str,Any])->None:
    """
    Replace the root element by the loop element for the abilities
    Args:
      options (dict): the ability options
      elem (WebElement): the element
    """
    elem:WebElement = item.get('element')
    def add_elem_to_atom(atom:ToolDef,elem:WebElement):
      atom_opts:dict = atom.get('options',{})
      if not atom_opts:
        return

      target:str = atom_opts.get('target')
      if target:
        atom_opts['root'] = elem
      else:
        atom_opts['target'] = elem

    if isinstance(atoms,list):
      for atom in atoms:
        add_elem_to_atom(atom,elem)
    elif isinstance(atoms,dict):
      for atom in atoms.values():
        add_elem_to_atom(atom,elem)
