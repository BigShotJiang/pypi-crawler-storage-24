from typing import Any
import logging
from selenium.webdriver.chrome.webdriver import WebDriver 
from blues_lib.types import ToolDef
from blues_lib.supports.dp.exception.SkipAbilityException import SkipAbilityException

class SeqExecutor():
  # execute a atom ability list or dict
  
  def __init__(self,driver:WebDriver):
    self._facade = None
    self._driver = driver
    self._logger = logging.getLogger('airflow.task')

  def execute(self,atoms:list[ToolDef]|dict[str,ToolDef])->list[Any]|dict[str,Any]|None:
    '''
    Use abilities of a series of elements in order
    Args:
      atoms (list[ToolDef]|dict[str,ToolDef]): the atom ability list or dict
    Returns:
      list[Any]|dict[str,Any]|None
    '''
    
    if not atoms:
      return None

    from blues_lib.tools.ability.AbilityFacade import AbilityFacade
    self._facade = AbilityFacade(self._driver)
    
    # calculate results
    results:list[Any]|dict[str,Any]|None = None
    if isinstance(atoms,list):
      results = self._exec_by_list(atoms)
    elif isinstance(atoms,dict):
      results = self._exec_by_dict(atoms)
    return results
  
  def _exec_by_dict(self,atoms:dict[str,ToolDef])->dict[str,Any]:
    results:dict[str,Any] = {}
    for key,atom in atoms.items():
      try:
        result = self._exec_ability(atom)
        results[key] = result
      except SkipAbilityException as e:
        self._logger.info(e.message)
        results[key] = e.result
        break
    return results

  def _exec_by_list(self,atoms:list[ToolDef])->list[Any]:
    results:list[Any] = []
    for atom in atoms:
      try:
        result = self._exec_ability(atom)
        results.append(result)
      except SkipAbilityException as e:
        self._logger.info(e.message)
        results.append(e.result)
        break
    return results

  def _exec_ability(self,atom:ToolDef)->Any:
    # support seq nest
    name:str = atom.get('name')
    opts:dict = atom.get('options')
    args:list[Any] = [name,opts] if opts else [name]
    return self._facade.execute(*args)
