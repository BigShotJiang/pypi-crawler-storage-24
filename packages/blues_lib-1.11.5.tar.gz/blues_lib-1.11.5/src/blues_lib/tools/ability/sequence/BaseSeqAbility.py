import logging
from abc import ABC
from typing import Any
from selenium.webdriver.chrome.webdriver import WebDriver 
from blues_lib.tools.ability.atom.AtomFacade import AtomFacade
from blues_lib.supports.dp.exception import SkipSeqException
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.tools.hook.SeqHook import SeqHook
from blues_lib.types import SeqOpts,SeqCastOpts,ToolDef
from blues_lib.supports.dp.exception.SkipSeqException import SkipSeqException

class BaseSeqAbility(ABC):
  
  _CAST_CLASSES = {}
  _DEFAULT_BY_TYPE = ''

  def __init__(self,driver:WebDriver):
    self._driver = driver
    self._facade = AtomFacade(driver)
    self._logger = logging.getLogger('airflow.task')

  def _cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[Any]|dict[str,Any]|None:
    bizdata = MetaRenderer.render_by_self(bizdata)
    
    hooks:dict[str,list[ToolDef]] = {
      'input':cast_opts.get('prev_tools',[]),
      'output':cast_opts.get('post_tools',[]),
    }
    
    extra = {
      'driver':self._driver,
      'definition':options,
      'bizdata':bizdata,
      'result':None,
    }
    seq_hook:SeqHook = SeqHook(hooks,extra) 
    try:
      seq_hook.input() 
    except SkipSeqException as e:
      self._logger.error(f'seq hook input error: {e}')
      return None

    result:list[Any]|dict[str,Any]|None = self._cast_by_type(options,bizdata,cast_opts)
    extra['result'] = result

    try:
      seq_hook.output()
    except SkipSeqException as e:
      self._logger.error(f'seq hook output error: {e}')
      return None

    return extra['result']

  def _cast_by_type(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    """
    loop by each elements and execute the ability sequence
    Args:
      options (SeqOpts): the sequence options
    Returns:
      list[list|dict]: the results of the abilities
    """
    # render and validate
    by_type:str = cast_opts.get('by_type',self._DEFAULT_BY_TYPE)
    
    cast_class = self._CAST_CLASSES.get(by_type)
    if not cast_class:
      raise ValueError(f'Unknown cast type: {by_type}')
    cast_instance = cast_class(self._driver,self._facade,self._logger)
    return cast_instance.cast(options,bizdata,cast_opts)