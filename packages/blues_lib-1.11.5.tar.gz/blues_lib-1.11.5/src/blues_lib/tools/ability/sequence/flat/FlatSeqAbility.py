from typing import Any
from blues_lib.tools.ability.sequence.BaseSeqAbility import BaseSeqAbility
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.flat.StandardFlat import StandardFlat
from blues_lib.tools.ability.sequence.flat.OrderFlat import OrderFlatSeqAbility
from blues_lib.supports.decorator.tool import ValidateToolInput

class FlatSeqAbility(BaseSeqAbility):
  
  _CAST_CLASSES = {
    'standard':StandardFlat,
    'order':OrderFlatSeqAbility,
  }
  _DEFAULT_BY_TYPE = 'standard'
  
  @ValidateToolInput()
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None=None)->list[Any]|dict[str,Any]|None:
    cast_opts:SeqCastOpts = MetaRenderer.render_node('flat',options,bizdata)
    return self._cast(options,bizdata,cast_opts)
