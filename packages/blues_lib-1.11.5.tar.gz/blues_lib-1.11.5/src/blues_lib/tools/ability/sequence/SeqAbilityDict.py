from selenium.webdriver.remote.webdriver import WebDriver

from blues_lib.tools.ability.sequence.flat.FlatSeqAbility import FlatSeqAbility
from blues_lib.tools.ability.sequence.loop.LoopSeqAbility import LoopSeqAbility
from blues_lib.tools.ability.sequence.page.PageSeqAbility import PageSeqAbility
from blues_lib.tools.ability.sequence.combo.ComboSeqAbility import ComboSeqAbility

class SeqAbilityDict():

  @classmethod
  def get(cls,driver:WebDriver)->dict:
    return {
      # flat seq
      FlatSeqAbility.__name__:FlatSeqAbility(driver),
      # loop seq
      LoopSeqAbility.__name__:LoopSeqAbility(driver),
      # page seq
      PageSeqAbility.__name__:PageSeqAbility(driver),
      # combo seq
      ComboSeqAbility.__name__:ComboSeqAbility(driver),
    }