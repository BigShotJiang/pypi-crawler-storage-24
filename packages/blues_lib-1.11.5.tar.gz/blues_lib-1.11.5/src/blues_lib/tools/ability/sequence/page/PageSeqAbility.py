from typing import Any
from blues_lib.tools.ability.sequence.BaseSeqAbility import BaseSeqAbility
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,SeqCastOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.page.NumberPage import NumberPage
from blues_lib.tools.ability.sequence.page.NextPage import NextPage
from blues_lib.supports.decorator.tool import ValidateToolInput

class PageSeqAbility(BaseSeqAbility):

  _CAST_CLASSES = {
    'number':NumberPage,
    'next':NextPage,
  }

  @ValidateToolInput()
  def cast_page(self,options:SeqOpts,bizdata:dict[str,Any]|None=None)->list[Any]|dict[str,Any]|None:
    cast_opts:SeqCastOpts = MetaRenderer.render_node('page',options,bizdata)
    return self._cast(options,bizdata,cast_opts)
