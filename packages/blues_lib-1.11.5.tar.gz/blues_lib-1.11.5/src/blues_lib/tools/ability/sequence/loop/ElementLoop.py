from typing import Any
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.types import SeqOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.loop.BaseSeqLoop import BaseSeqLoop

class ElementLoop(BaseSeqLoop):
  
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    items:list[dict[str,Any]] = IterationHelper.get_items_by_element(self._facade,cast_opts)
    return self._cast_items(items,options,bizdata,cast_opts)
