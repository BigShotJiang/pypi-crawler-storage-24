from abc import ABC,abstractmethod
from typing import Any
from logging import Logger
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.ability.atom import AtomFacade
from blues_lib.types import SeqOpts,SeqCastOpts,ToolDef
from blues_lib.tools.ability.sequence.SeqExecutor import SeqExecutor

class BaseSeq(ABC):
  
  def __init__(self,driver:WebDriver,facade:AtomFacade,logger:Logger):
    self._driver = driver
    self._facade = facade
    self._seq_executor = SeqExecutor(driver)
    self._logger = logger

  @abstractmethod
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    pass

  def _get_std_tool_defs(self,atoms:list[ToolDef|list]|dict[str,ToolDef|list])->list[ToolDef]|dict[str,ToolDef]:
    if isinstance(atoms,list):
      return self._get_std_list_tool_defs(atoms)
    if isinstance(atoms,dict):
      return self._get_std_dict_tool_defs(atoms)
  
  def _get_std_dict_tool_defs(self,atoms:dict[str,ToolDef|list])->dict[str,ToolDef]:
    tool_defs:dict[str,ToolDef] = {}
    for key,atom in atoms.items():
      if not atom:
        continue

      if isinstance(atom,list):
        order_defs:list[ToolDef] = self._get_tool_def(atom)
        for idx,tool_def in enumerate(order_defs):
          tool_defs[f'{key}_{idx}'] = tool_def
      else:
        tool_defs[key] = atom
    return tool_defs

  def _get_std_list_tool_defs(self,atoms:list[ToolDef|list])->list[ToolDef]:
    tool_defs:list[ToolDef] = []
    for atom in atoms:
      if not atom:
        continue

      if isinstance(atom,list):
        tool_defs.extend(self._get_tool_def(atom))
      else:
        tool_defs.append(atom)
    return tool_defs
  
  def _get_list_value(self,value:Any)->list[Any]:
    if value is None:
      return []
    if not isinstance(value,list):
      return [value]
    return value

  def _get_tool_def(self,attrs:list[Any])->list[ToolDef]|None:
    attrs = (attrs + [None] * 3)[:4]
    name:str = attrs[0]
    targets:list[str] = self._get_list_value(attrs[1])
    values:list[Any] = self._get_list_value(attrs[2])
    extra:dict = attrs[3] or {}
    
    if not name:
      return None

    if not targets and not values:
      return {
        "name":name,
        "options":{
          **extra,
        },
      }

    target_len:int = len(targets)
    value_len:int = len(values)
    tool_len:int = target_len or value_len
    tool_defs:list[ToolDef] = []

    for idx in range(0,tool_len):
      tool_def:ToolDef = {
        'name':name,
        'options':{
          **extra,
        },
      }
      if idx<target_len:
        tool_def['options']['target'] = targets[idx]
      if idx<value_len:
        tool_def['options']['value'] = values[idx]
      tool_defs.append(tool_def)
    return tool_defs
