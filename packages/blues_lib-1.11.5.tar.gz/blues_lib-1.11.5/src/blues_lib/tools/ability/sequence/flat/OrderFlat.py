from typing import Any
from blues_lib.tools.ability.sequence.flat.BaseSeqFlat import BaseSeqFlat
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,ToolDef,SeqCastOpts

class OrderFlatSeqAbility(BaseSeqFlat):

  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    return self._cast_by_order(options,bizdata,cast_opts)
    
  def _cast_by_order(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[Any]|dict[str,Any]|None:
    method:str = cast_opts.get('by_value')
    children:list[dict]|dict[str,dict] = MetaRenderer.render_node('tools',options,bizdata)
    atoms:list[ToolDef]|dict[str,ToolDef] = []
    if self._is_simple_opts(children):
      atoms = self._get_atoms_by_simple_opts(method,children)
    else:
      atoms = self._get_atoms_by_std_opts(method,children)
    return self._seq_executor.execute(atoms)
  
  def _is_simple_opts(self,children:list[dict]|dict[str,dict])->bool:
    if not isinstance(children,list):
      return False
    if len(children)!=1:
      return False

    first_child:dict = children[0]
    return 'targets' in first_child or 'values' in first_child

  def _get_atoms_by_simple_opts(self,method:str,children:list[dict])->list[ToolDef]:
    '''
    Get standard tool definitions by simple options
    Args:
      method (str) : the tool name
      children (list[dict]) : the simple options (only has one item), such as
       [{'targets':['#name','#age'],'values':['liu','20'],'extra':{}}]
    '''
    targets:list[str] = children[0].get('targets') or []
    values:list[Any] = children[0].get('values') or []
    
    if not targets and not values:
      return []
    
    target_len:int = len(targets)
    value_len:int = len(values)
    max_len:int = max(target_len,value_len)

    extra:dict = children[0].get('extra') or {}
    atoms:list[ToolDef] = []

    for idx in range(0,max_len):
      atom:ToolDef = {
        'name':method,
        'options':{
          **extra,
        },
      }
      if idx<target_len:
        atom['options']['target'] = targets[idx]
      if idx<len(values):
        atom['options']['value'] = values[idx]
      atoms.append(atom)
    return atoms
  
  def _get_atoms_by_std_opts(self,method:str,children:list[dict]|dict[str,dict])->list[ToolDef]|dict[str,ToolDef]:
    '''
    Get standard tool definitions by standard options
    Args:
      method (str) : the tool name
      children (list[dict]|dict[str,dict]) : the standard options, such as
       [{'target':'#name','value':'liu'}]
    '''
    atoms:list[ToolDef]|dict[str,ToolDef] = []
    if isinstance(children,list):
      atoms:list[ToolDef] = self._get_atoms_by_list(method,children)
    elif isinstance(children,dict):
      atoms:dict[str,ToolDef] = self._get_atoms_by_dict(method,children)
    return atoms

  def _get_atoms_by_dict(self,method:str,children:dict[str,dict])->dict[str,ToolDef]:
    atoms:dict[str,ToolDef] = {}
    for k,v in children.items():
      atom:ToolDef = {
        'name':method,
        'options':v,
      }
      atoms[k] = atom
    return atoms
  
  def _get_atoms_by_list(self,method:str,optset:list[dict])->list[ToolDef]:
    atoms:list[ToolDef] = []
    for opts in optset:
      atom:ToolDef = {
        'name':method,
        'options':opts,
      }
      atoms.append(atom)
    return atoms
