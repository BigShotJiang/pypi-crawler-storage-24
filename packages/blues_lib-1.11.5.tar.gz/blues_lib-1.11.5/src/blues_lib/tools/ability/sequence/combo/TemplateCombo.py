from typing import Any
from blues_lib.tools.ability.sequence.combo.BaseSeqCombo import BaseSeqCombo
from blues_lib.types import Para,ParaType,ToolDef,SeqOpts,SeqCastOpts
from blues_lib.tools.meta.validate.MetaValidator import MetaValidator
from blues_lib.resources.definition.DefReader import DefReader

class TemplateCombo(BaseSeqCombo):

  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    paras:list[Para] = cast_opts.get('by_value')
    validate_tpl = 'ability.seq_paras'
    MetaValidator.validate_with_template(paras,validate_tpl)
    return self._cast_by_para(paras,bizdata)

  def _cast_by_para(self,paras:list[Para],bizdata:dict[str,Any]|None)->list[Any]:
    results:list[Any] = []
    for para in paras:
      result:list[Any] = self._cast_single(para,bizdata)
      results.extend(result)
    return results
  
  def _cast_single(self,para:Para,bizdata:dict[str,Any]|None)->list[Any]:
    tpl_path:str = 'ability.write.para'
    tpl_def:dict = DefReader.read(tpl_path) 
    
    para_type:ParaType = para.get('type')
    atoms:list[ToolDef] = []
    if para_type == 'image':
      atoms = tpl_def.get('image')
    else:
      atoms = tpl_def.get('text')
    para_biz = {**bizdata,**para} if bizdata else para
    return self._cast_by_ability_name(atoms,para_biz)
  