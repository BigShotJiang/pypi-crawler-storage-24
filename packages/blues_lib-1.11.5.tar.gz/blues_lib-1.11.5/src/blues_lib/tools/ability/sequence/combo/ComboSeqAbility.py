from typing import Any
from blues_lib.tools.ability.sequence.BaseSeqAbility import BaseSeqAbility
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.combo.TemplateCombo import TemplateCombo
from blues_lib.supports.decorator.tool import ValidateToolInput

class ComboSeqAbility(BaseSeqAbility):

  _CAST_CLASSES = {
    'template':TemplateCombo,
  }

  @ValidateToolInput()
  def cast_combo(self,options:SeqOpts,bizdata:dict[str,Any]|None=None)->list[Any]|dict[str,Any]|None:
    cast_opts:SeqCastOpts = MetaRenderer.render_node('combo',options,bizdata)
    return self._cast(options,bizdata,cast_opts)
