import logging
from abc import abstractmethod
from typing import Any,Callable
from selenium.webdriver.chrome.webdriver import WebDriver 
from blues_lib.tools.ability.atom.AtomFacade import AtomFacade
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.types import SeqOpts,SeqCastOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.tools.ability.sequence.loop.LoopSeqAbility import LoopSeqAbility
from blues_lib.tools.ability.sequence.flat.FlatSeqAbility import FlatSeqAbility
from blues_lib.supports.dp.exception.SkipSeqException import SkipSeqException
from blues_lib.tools.ability.sequence.BaseSeq import BaseSeq

class BasePageLoop(BaseSeq):

  def __init__(self,driver:WebDriver,facade:AtomFacade,logger:logging.Logger):
    super().__init__(driver,facade,logger)
    
    self._loop_ability = LoopSeqAbility(driver)
    self._flat_ability = FlatSeqAbility(driver)

  @abstractmethod
  def _get_next_elem(self,cast_opts:SeqCastOpts,idx:int)->WebElement|None:
    pass

  def _cast_by_page(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    
    attempts:int = int(cast_opts.get('attempts') or -1)
    totals:list[list|dict] = self._cast_single(options,bizdata)
    idx:int = 1

    while True:

      IterationHelper.delay(cast_opts)

      if attempts>0 and idx>=attempts:
        break

      elem:WebElement|None = self._get_next_elem(cast_opts,idx)
      if not elem:
        break

      self._next_page(elem)
      idx+=1

      try:
        result = self._cast_single(options,bizdata)
      except SkipSeqException as e:
        self._logger.error(f'cast single error: {e}')
        continue

      totals+= result
    
    return totals

  def _next_page(self,elem:WebElement):
    self._facade.execute('click',{'target':elem})

  def _cast_single(self,options:SeqOpts,bizdata:dict[str,Any]|None)->list[list|dict]:
    opts_copy = options.copy()
    # loop seq can't have page
    del opts_copy['page']
    loop_opts:SeqCastOpts|None = opts_copy.get('loop')
    if loop_opts:
      return self._loop_ability.cast_loop(opts_copy,bizdata)
    else:
      return [self._flat_ability.cast(opts_copy,bizdata)]
