from typing import Any
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.types import SeqOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.page.BasePageLoop import BasePageLoop

class NumberPage(BasePageLoop):
  
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    self._page_elems:list[WebElement] = IterationHelper._query_elems(self._facade,cast_opts)
    return self._cast_by_page(options,bizdata,cast_opts)

  def _get_next_elem(self,cast_opts:SeqCastOpts,idx:int)->WebElement|None:
    return self._page_elems[idx] if idx<len(self._page_elems) else None
