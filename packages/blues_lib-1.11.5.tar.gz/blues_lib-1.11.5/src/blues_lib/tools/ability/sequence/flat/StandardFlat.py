from typing import Any
from blues_lib.tools.ability.sequence.flat.BaseSeqFlat import BaseSeqFlat
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,ToolDef,SeqCastOpts

class StandardFlat(BaseSeqFlat):

  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    return self._cast_by_standard(options,bizdata)
    
  def _cast_by_standard(self,options:SeqOpts,bizdata:dict[str,Any]|None)->list[Any]|dict[str,Any]|None:
    atoms:list[ToolDef|list]|dict[str,ToolDef|list] = MetaRenderer.render_node('tools',options,bizdata)
    if not atoms:
      self._logger.warning('seq ability has no tools')
      return None

    tool_defs:list[ToolDef]|dict[str,ToolDef] = self._get_std_tool_defs(atoms)
    return self._seq_executor.execute(tool_defs)
  