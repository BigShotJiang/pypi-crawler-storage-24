import random
from typing import Any
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.utils.BluesDateTime import BluesDateTime
from blues_lib.tools.ability.atom.AtomFacade import AtomFacade
from blues_lib.types import SeqCastOpts,AttemptDelay

class IterationHelper():

  @classmethod
  def get_items_by_element(cls,facade:AtomFacade,cast_opts:SeqCastOpts)->list[dict[str,Any]]:
    elems:list[WebElement] = cls._query_elems(facade,cast_opts)
    return [{'element':elem} for elem in elems]

  @classmethod
  def get_items_by_count(cls,cast_opts:SeqCastOpts)->list[dict[str,Any]]:
    count:int = int(cast_opts.get('by_value',0))
    if count<=0:
      raise ValueError('for loop by count must be a positive number')
    return [{'count':i} for i in range(count)]

  @classmethod
  def get_items(cls,cast_opts:SeqCastOpts)->list[dict[str,Any]]:
    items:list[dict[str,Any]]|None = cast_opts.get('by_value')
    if not items:
      raise ValueError('for loop by items must be a non-empty list')
    return items

  @classmethod
  def _query_elems(cls,facade:AtomFacade,cast_opts:SeqCastOpts) -> list[WebElement]:
    elem_opts:dict|str = cast_opts.get('by_value')
    # support simple locator string
    if isinstance(elem_opts,str):
      elem_opts = {'target':elem_opts}

    elems:list[WebElement]|None = facade.execute('query_elements',elem_opts)
    if not elems:
      raise ValueError(f'loop options {elem_opts} query no elements')
    return elems

  @classmethod
  def query_elem(cls,facade:AtomFacade,cast_opts:SeqCastOpts) -> WebElement|None:
    elem_opts:dict|str = cast_opts.get('by_value')
    # support simple locator string
    if isinstance(elem_opts,str):
      elem_opts = {'target':elem_opts}
    return facade.execute('query_element',elem_opts)

  @classmethod
  def delay(cls,cast_opts:SeqCastOpts):
    interval:int|float = cls._get_loop_interval(cast_opts)
    if interval>0:
      BluesDateTime.count_down({
        'duration':interval,
        'title':f'Wait {interval}s in seq loop '
      })

  @classmethod
  def _get_loop_interval(cls,cast_opts:SeqCastOpts)->int|float:
    interval:AttemptDelay = cast_opts.get('attempt_delay')
    if not interval:
      return 0

    value:float = 0
    try: 
      if isinstance(interval,list):
        value= round(random.uniform(*interval), 1)
      else:
        value= float(interval)
    except ValueError:
      value= 0
    return value
