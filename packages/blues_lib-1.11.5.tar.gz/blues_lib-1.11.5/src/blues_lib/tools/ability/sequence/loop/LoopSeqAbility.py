from typing import Any
from blues_lib.tools.ability.sequence.BaseSeqAbility import BaseSeqAbility
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.types import SeqOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.loop.EachLoop import EachLoop
from blues_lib.tools.ability.sequence.loop.CountLoop import CountLoop
from blues_lib.tools.ability.sequence.loop.ItemLoop import ItemLoop
from blues_lib.tools.ability.sequence.loop.ElementLoop import ElementLoop
from blues_lib.supports.decorator.tool import ValidateToolInput

class LoopSeqAbility(BaseSeqAbility):
  
  _CAST_CLASSES = {
    'each':EachLoop,
    'count':CountLoop,
    'item':ItemLoop,
    'element':ElementLoop,
  }
  
  @ValidateToolInput()
  def cast_loop(self,options:SeqOpts,bizdata:dict[str,Any]|None=None)->list[Any]|dict[str,Any]|None:
    cast_opts:SeqCastOpts = MetaRenderer.render_node('loop',options,bizdata)
    return self._cast(options,bizdata,cast_opts)
