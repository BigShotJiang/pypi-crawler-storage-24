from typing import Any
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.sequence.page.BasePageLoop import BasePageLoop
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.types import SeqOpts,SeqCastOpts
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper

class NextPage(BasePageLoop):
  
  def cast(self,options:SeqOpts,bizdata:dict[str,Any]|None,cast_opts:SeqCastOpts)->list[list|dict]:
    return self._cast_by_page(options,bizdata,cast_opts)
  
  def _get_next_elem(self,cast_opts:SeqCastOpts,idx:int)->WebElement|None:
    return IterationHelper.query_elem(self._facade,cast_opts)
