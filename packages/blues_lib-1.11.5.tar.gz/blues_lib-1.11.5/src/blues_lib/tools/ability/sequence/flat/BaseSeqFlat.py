from blues_lib.tools.ability.sequence.BaseSeq import BaseSeq

class BaseSeqFlat(BaseSeq):
  pass