from blues_lib.tools.ability.atom.hook.Material import Material
from blues_lib.tools.ability.atom.hook.Sharing import Sharing
from blues_lib.tools.ability.atom.hook.Mapping import Mapping

class HookAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Material.__name__:Material(),
      Sharing.__name__:Sharing(),
      Mapping.__name__:Mapping(),
    }