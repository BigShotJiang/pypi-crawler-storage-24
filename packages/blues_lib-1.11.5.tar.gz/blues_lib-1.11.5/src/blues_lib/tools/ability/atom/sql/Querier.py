from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts,SQLCondition,SQLPagination
from blues_lib.services.dao.sql.TableQuerier import TableQuerier
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Querier(BaseAbility):
  
  _DEFAULT_PAGINATION:SQLPagination = {
    'no':1,
    'size':1
  }

  @ValidateAbilityExpect()
  def sql_query(self,options:dict)->STDOut:
    sql_opts:SQLOpts = options.get('value',{}) 
    table:str = sql_opts.get('table')
    conditions:list[SQLCondition] = SQLHelper.get_conditions(sql_opts)
    fields:list[str] = sql_opts.get('fields',[])
    pagination:SQLPagination = sql_opts.get('page') or self._DEFAULT_PAGINATION
    orders:list[SQLOrder] = sql_opts.get('orders') or []
    querier = TableQuerier(table)
    return querier.get(fields,conditions,orders,pagination)



     