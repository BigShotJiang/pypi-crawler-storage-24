from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Dummy(BaseAbility):
  
  @ValidateAbilityExpect()
  def dummy_info(self,options:dict)->bool:
    self._logger.info(f'{self.__class__.__name__}: {options.get("value")}')
    return True

  @ValidateAbilityExpect()
  def dummy_value(self,options:dict)->Any:
    return options.get('value')
