from selenium.webdriver.common.keys import Keys
from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardBase import KeyboardBase

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class KeyboardArrow(KeyboardBase):

  @ValidateAbilityExpect()
  def arrow_up(self,options:dict|None=None)->bool:
    '''
    Press arrow up key
    Args:
      options (dict): The element query options
    '''
    options = options or {}
    options['value'] = Keys.ARROW_UP
    return self.press(options)

  @ValidateAbilityExpect()
  def arrow_down(self,options:dict|None=None)->bool:
    '''
    Press arrow down key
    Args:
      options (dict): The element query options
    '''
    options = options or {}
    options['value'] = Keys.ARROW_DOWN
    return self.press(options)
  
  @ValidateAbilityExpect()
  def arrow_left(self,options:dict|None=None)->bool:
    '''
    Press arrow left key
    Args:
      options (dict): The element query options
    '''
    options = options or {}
    options['value'] = Keys.ARROW_LEFT
    return self.press(options)

  @ValidateAbilityExpect()
  def arrow_right(self,options:dict|None=None)->bool:
    '''
    Press arrow right key
    Args:
      options (dict): The element query options
    '''
    options = options or {}
    options['value'] = Keys.ARROW_RIGHT
    return self.press(options)

  @ValidateAbilityExpect()
  def page_up(self,options:dict|None=None)->bool:
    '''
    Press page up key
    Args:
      options (dict): The element query options
    '''
    options = options or {}
    options['value'] = Keys.PAGE_UP
    return self.press(options)

  @ValidateAbilityExpect()
  def page_down(self,options:dict|None=None)->bool:
    '''
    Press page down key
    Args:
      options (dict): The element query options
    '''
    options = options or {}
    options['value'] = Keys.PAGE_DOWN
    return self.press(options)
