from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.action.mouse.MouseBase import MouseBase

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class MouseDrag(MouseBase):
  '''
  These methods first move mouse to designated origin and then by number of pixels in provided offset. Note that position of mouse must be in viewport or else command will error.
  Reference: https://www.selenium.dev/documentation/webdriver/actions_api/mouse/#move-by-offset
  '''
  
  @ValidateAbilityExpect()
  def drag_and_drop(self,options:dict)->bool:
    '''
    Darg draggable into droppable
    The centers of two elements will coincide
    Args:
      options (dict) : The element query options
    Returns:
      bool : True if element is found and moved, False otherwise
    '''
    draggable,droppable = self._get_draggable_and_droppable(options)
    if not droppable or not draggable:
      return False
    self._chains.drag_and_drop(draggable,droppable).perform()
    return True

  @ValidateAbilityExpect()
  def drag_and_drop_by_offset(self,options:dict)->bool:
    '''
    Move relative to current position
    Args:
      options (dict) : The element query options
    Returns:
      bool : True if element is found and moved, False otherwise
    '''
    elem:WebElement|None = self._querier.query_element(options)
    value:list[int] = options.get('value')
    if not elem or not value:
      return False
    self._chains.drag_and_drop_by_offset(elem,*value).perform()
    return True

  @ValidateAbilityExpect()
  def drag_to_element_with_offset(self,options:dict)->bool:
    '''
    The distance between two elements's centers
    Args:
      options (dict) : The element query options
    Returns:
      bool : True if element is found and moved, False otherwise
    '''
    draggable,droppable = self._get_draggable_and_droppable(options)
    value:list[int] = options.get('value')
    if not droppable or not draggable or not value:
      return False
    self._chains.click_and_hold(draggable).move_to_element_with_offset(droppable,*value).release(draggable).perform()
    return True

  @ValidateAbilityExpect()
  def drag_to_location(self,options:dict)->bool:
    '''
    Move to a point relative to viewport's top left point
    Use new feature -- ActionBuilder
    Args:
      options (dict) : The element query options
    Returns:
      bool : True if element is found and moved, False otherwise
    '''
    elem:WebElement|None = self._querier.query_element(options)
    value:list[int] = options.get('value')
    if not elem or not value:
      return False
    self._chains.click_and_hold(elem).perform()
    self._builder.pointer_action.move_to_location(*value)
    self._builder.perform()
    self._chains.release(elem).perform()        
    return True

  @ValidateAbilityExpect()
  def drag_to_border(self,options:dict)->bool:
    '''
    Darg a element to a target container's border
    经测试不准确，需进一步优化
    Args:
      options (dict) : The element query options
    Returns:
      bool : True if element is found and moved, False otherwise
    '''
    drag_opts:dict = {**options,'target':options.get('draggable')}
    drop_opts:dict = {**options,'target':options.get('droppable')}

    # 获取容器右侧坐标
    drag_coord = self.get_coord(drag_opts)
    drop_coord = self.get_coord(drop_opts)
    if not drag_coord or not drop_coord:
      return False
    
    loc:tuple[int,int] = self._get_border_position(drag_coord,drop_coord,options.get('direction'))
    self.drag_to_location({**drag_opts,'value':loc})
    return True

  def drag_to_right(self,options:dict)->bool:
    return self.drag_to_border({'direction':'right',**options})

  def drag_to_left(self,options:dict)->bool:
    return self.drag_to_border({'direction':'left',**options})

  def drag_to_top(self,options:dict)->bool:  
    return self.drag_to_border({'direction':'top',**options})  

  def drag_to_bottom(self,options:dict)->bool:
    return self.drag_to_border({'direction':'bottom',**options})

  def _get_border_position(self,drag_coord:dict[str,int],drop_coord:dict[str,int],direction:str)->tuple[int,int]:
    '''
    move_to calculate postion to element's center point, not its top left border
    '''
    x = drag_coord['left'] # init x-axis position
    y = drag_coord['top'] # init y-axis position
    half_width = round(drag_coord['width']/2)
    half_height = round(drag_coord['height']/2)

    if direction == 'left':
      x = drop_coord[direction]+half_width
    elif direction == 'right':
      x = drop_coord[direction]-half_width
    elif direction == 'top':
      y = drop_coord[direction]+half_height
    elif direction == 'bottom':
      y = drop_coord[direction]-half_height

    return (x,y)

  @ValidateAbilityExpect()
  def get_coord(self,options:dict)->dict[str,int]|None:
    '''
    Get element's size and position
    Args:
      options (dict): The element query options
    Returns:
      dict[str,int]|None: The element's size and position, or None if element is not found
    '''
    coordinate = {}
    elem:WebElement|None = self._querier.query_element(options)
    if not elem:
      return None

    coordinate['left'] = round(elem.location.get('x'))
    coordinate['top'] = round(elem.location.get('y'))
    coordinate['width'] = round(elem.size.get('width'))
    coordinate['height'] = round(elem.size.get('height'))
    coordinate['right'] = coordinate['left']+coordinate['width']
    coordinate['bottom'] = coordinate['top']+coordinate['height']
    return coordinate

  def _get_draggable_and_droppable(self,options:dict)->tuple[WebElement|None,WebElement|None]:
    darg_opts:dict = {**options,'target':options.get('draggable')}
    drop_opts:dict = {**options,'target':options.get('droppable')}
    draggable = self._querier.query_element(darg_opts)
    droppable = self._querier.query_element(drop_opts)
    if not droppable or not draggable:
      return None,None
    return draggable,droppable


