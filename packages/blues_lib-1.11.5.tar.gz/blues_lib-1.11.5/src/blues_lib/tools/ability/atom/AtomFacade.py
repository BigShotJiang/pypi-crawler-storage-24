from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.supports.dp.facade.DynamicFacade import DynamicFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.tools.ability.atom.webdriver.DriverAbilityDict import DriverAbilityDict
from blues_lib.tools.ability.atom.matcher.MatcherAbilityDict import MatcherAbilityDict
from blues_lib.tools.ability.atom.tool.ToolAbilityDict import ToolAbilityDict
from blues_lib.tools.ability.atom.llm.LLMAbilityDict import LLMAbilityDict
from blues_lib.tools.ability.atom.sql.SQLAbilityDict import SQLAbilityDict
from blues_lib.tools.ability.atom.cleanup.CleanupAbilityDict import CleanupAbilityDict
from blues_lib.tools.ability.atom.message.MessageAbilityDict import MessageAbilityDict
from blues_lib.tools.ability.atom.hook.HookAbilityDict import HookAbilityDict
from blues_lib.tools.ability.atom.script.ScriptAbilityDict import ScriptAbilityDict

class AtomFacade(DynamicFacade):
  
  def __init__(self,driver:WebDriver|None = None) -> None:
    self._driver = driver
    super().__init__()
    
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    generic_insts = {
      **ToolAbilityDict.get(),
      **LLMAbilityDict.get(),
      **SQLAbilityDict.get(),
      **CleanupAbilityDict.get(),
      **MessageAbilityDict.get(),
      **HookAbilityDict.get(),
      **ScriptAbilityDict.get(),
    }
    driver_insts = {
      **DriverAbilityDict.get(self._driver),
      **MatcherAbilityDict.get(self._driver),
    } if self._driver else {}
    return {**generic_insts,**driver_insts}
