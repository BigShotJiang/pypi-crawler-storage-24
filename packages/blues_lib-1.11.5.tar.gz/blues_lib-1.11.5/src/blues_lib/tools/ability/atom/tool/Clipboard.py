import pyperclip
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Clipboard(BaseAbility):
  
  def read_clipboard(self)->str:
    return pyperclip.paste()

  @ValidateAbilityExpect()
  def write_clipboard(self,options:dict)->bool:
    value:str = options.get('value','') 
    if value:
      pyperclip.copy(value)
    return True

  def clear_clipboard(self)->bool:
    pyperclip.copy('')
    return True