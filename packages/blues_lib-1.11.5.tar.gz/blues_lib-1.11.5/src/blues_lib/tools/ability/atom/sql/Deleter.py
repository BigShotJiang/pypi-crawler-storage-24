from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts,SQLCondition
from blues_lib.services.dao.sql.TableMutator import TableMutator
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Deleter(BaseAbility):

  @ValidateAbilityExpect()
  def sql_delete(self,options:dict)->STDOut:
    sql_opts:SQLOpts = options.get('value',{}) 
    table:str = sql_opts.get('table')
    conditions:list[SQLCondition] = SQLHelper.get_conditions(sql_opts)
    mutator = TableMutator(table)
    return mutator.delete(conditions)

