from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.task.xcom.XComMapper import XComMapper

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Mapping(BaseAbility): 

  @ValidateToolInput()
  @ValidateAbilityExpect()
  def xcom_map(self,opts:dict)->bool: 
    mappings:list[list[str]] = opts.get('value') or []
    extra:dict = opts.get('extra',{})
    bizdata:dict|None = extra.get('bizdata')
    ti:Any = extra.get('ti')
    if not mappings or not ti:
      self._logger.warning(f'{self.__class__.__name__} :  mappings or ti is None')
      return False
    if bizdata is None:
      self._logger.warning(f'{self.__class__.__name__} :  bizdata is None')
      return False

    map_count:int = 0    
    for mapping_item in mappings:
      if len(mapping_item)<2:
        continue
      
      callback:str = mapping_item[2] if len(mapping_item)>2 else ''
      mapping:dict = {
        'source':mapping_item[0],
        'target':mapping_item[1],
      }
      if callback:
        mapping['callback'] = callback

      is_success:bool = XComMapper(mapping,bizdata,ti).handle()
      if is_success:
        map_count += 1

    return True if map_count>0 else False
