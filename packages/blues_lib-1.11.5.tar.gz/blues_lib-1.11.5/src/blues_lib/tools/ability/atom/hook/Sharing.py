from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.supports.dp.output.STDOut import STDOut

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Sharing(BaseAbility): 

  @ValidateAbilityExpect()
  def share_to_file(self,opts:dict)->STDOut: 
    pass

  @ValidateAbilityExpect()
  def share_to_xcom(self,opts:dict)->STDOut: 
    result:Any|None = opts.get('value')
    ti = opts.get('extra',{}).get('ti')

    if not ti:
      self._logger.warning(f'{self.__class__.__name__} : share_to_xcom error, ti is None')
      return STDOut(500,'error',result)

    stdout:STDOut = self._get_dict_stdout(result) if isinstance(result,dict) else STDOut(200,'ok',result)
    result = stdout.to_dict()
    for key,value in result.items(): 
      ti.xcom_push(key,value)
      
    return stdout
     
  def _get_dict_stdout(self,result:dict[str,Any])->STDOut:
      code:int = 200 if ('status' not in result or result.get('status')=='success') else 500
      data:list[Any]|dict[str,Any] = result if 'data' not in result else result.get('data')
      message:str = 'ok' if code==200 else 'error'
      return STDOut(code,message,data)
 