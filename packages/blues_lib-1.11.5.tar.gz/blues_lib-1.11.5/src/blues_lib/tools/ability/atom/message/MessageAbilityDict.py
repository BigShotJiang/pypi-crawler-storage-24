from blues_lib.tools.ability.atom.message.Email import Email

class MessageAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Email.__name__:Email(),
    }