import time
from blues_lib.tools.ability.atom.webdriver.DriverAbility import DriverAbility
from blues_lib.types import AbilityStep
from blues_lib.tools.ability.atom.webdriver.action.Wheel import Wheel
from blues_lib.tools.ability.atom.webdriver.interaction.JavaScript import JavaScript
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Browser(DriverAbility):
  """
  Working with browser
  Reference : https://www.selenium.dev/documentation/webdriver/interactions/browser/
  """

  def get_title(self)->str:
    '''
    Get the browser document's title
    Returns:
      str
    '''
    return self._driver.title

  def get_current_url(self)->str:
    '''
    Get the current page url
    Returns:
      str
    '''
    return self._driver.current_url

  @ValidateAbilityExpect()
  def get_page_source(self,options:dict|None=None)->str:
    '''
    Get the current page source
    Returns:
      str
    '''
    options = options or {}
    step:AbilityStep|None = options.get('step',None)
    if step:
      java = JavaScript(self._driver)
      java.lazy_scroll_to_bottom(options)

    return self._driver.page_source
