from abc import ABC
import logging
from blues_lib.tools.ability.atom.webdriver.DriverAbilityFacade import DriverAbilityFacade

class MatcherAbility(ABC):

  def __init__(self,driver):
    self._driver = driver
    self._facade = DriverAbilityFacade(driver)
    self._logger = logging.getLogger('airflow.task')
