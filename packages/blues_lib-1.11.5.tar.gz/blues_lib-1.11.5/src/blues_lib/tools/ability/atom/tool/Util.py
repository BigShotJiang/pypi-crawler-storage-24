from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.utils.BluesDateTime import BluesDateTime
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Util(BaseAbility):
  
  @ValidateAbilityExpect()
  def sleep(self,options:dict)->bool:
    duration:float|int = float(options.get('duration') or 0)
    if duration>0:
      value:str = options.get('value') or f'Sleep {duration} seconds'
      BluesDateTime.count_down({
        "duration":duration,
        "title":value,
      })
    return True