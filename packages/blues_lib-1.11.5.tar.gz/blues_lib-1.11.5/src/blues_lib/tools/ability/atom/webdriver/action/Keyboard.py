from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardArrow import KeyboardArrow
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput
from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardSingle import KeyboardSingle
from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardHotkey import KeyboardHotkey


class Keyboard(KeyboardArrow,KeyboardSingle,KeyboardHotkey):
  """
  A representation of any key input device for interacting with a web page.
  Reference : https://www.selenium.dev/documentation/webdriver/actions_api/keyboard/
  """
  
  @ValidateAbilityExpect()
  def paste_and_enter(self,options:dict)->bool:
    self.paste(options)
    return self.enter(options)

  @ValidateAbilityExpect()
  def clear_paste_and_enter(self,options:dict)->bool:
    self.clear_and_paste(options)
    return self.enter(options)

  
