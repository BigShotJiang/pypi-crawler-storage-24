from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class UrlMatcher(MatcherAbility):

  @ValidateAbilityExpect()
  def url_to_match(self,options:dict)->bool:
    return self._facade.execute('url_matches',options)
