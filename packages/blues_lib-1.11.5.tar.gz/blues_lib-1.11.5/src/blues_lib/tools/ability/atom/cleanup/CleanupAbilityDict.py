from blues_lib.tools.ability.atom.cleanup.Cleaner import Cleaner

class CleanupAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Cleaner.__name__:Cleaner(),
    }