from selenium.webdriver.common.keys import Keys
from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardBase import KeyboardBase

from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class KeyboardSingle(KeyboardBase):

  @ValidateAbilityExpect()
  def enter(self,options:dict)->bool:
    """
    Press enter key
    Args:
      options (dict): The element query options
    """
    key_options = {'value':Keys.ENTER}
    options = {**options,**key_options} if options else key_options
    return self.press(options)  
  @ValidateAbilityExpect()
  def newline(self,options:dict)->bool:
    """
    Press newline key
    Args:
      options (dict): The element query options
    """
    key_options = {'value':'\n'}
    options = {**options,**key_options} if options else key_options
    return self.press(options)  
  @ValidateAbilityExpect()
  def esc(self,options:dict|None=None)->bool:
    """
    Press escape key
    Args:
      options (dict): The element query options
    """
    key_options = {'value':Keys.ESCAPE}
    options = {**options,**key_options} if options else key_options
    return self.press(options)

  @ValidateAbilityExpect()
  def f12(self,options:dict|None=None)->bool:
    """
    Press f12 key
    """
    key_options = {'value':Keys.F12}
    options = {**options,**key_options} if options else key_options
    return self.press(options)
  