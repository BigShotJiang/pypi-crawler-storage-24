from blues_lib.tools.ability.atom.tool.Dummy import Dummy
from blues_lib.tools.ability.atom.tool.Util import Util
from blues_lib.tools.ability.atom.tool.Clipboard import Clipboard
from blues_lib.tools.ability.atom.tool.Calculator import Calculator

class ToolAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Dummy.__name__:Dummy(),
      Util.__name__:Util(),
      Clipboard.__name__:Clipboard(),
      Calculator.__name__:Calculator(),
    }