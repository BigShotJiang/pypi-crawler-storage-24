from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.BluesMailer import BluesMailer  
from blues_lib.tools.ability.atom.message.PublishHelper import PublishHelper
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.types import EmailOpts
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Email(BaseAbility):

  @ValidateAbilityExpect()
  def send_email(self,options:dict)->STDOut:
    mailer = BluesMailer.get_instance()
    value:EmailOpts = options.get('value',{})
    return mailer.send(value)

  @ValidateAbilityExpect()
  def send_publish_email(self,options:dict)->STDOut:
    mailer = BluesMailer.get_instance()
    value:EmailOpts = PublishHelper.get_opts(options)
    return mailer.send(value)

