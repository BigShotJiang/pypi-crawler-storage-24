from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts
from blues_lib.services.dao.sql.TableMutator import TableMutator
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class Inserter(BaseAbility):

  @ValidateAbilityExpect()
  def sql_insert(self,options:dict)->STDOut:
    sql_opts:SQLOpts = options.get('value',{}) 
    table:str = sql_opts.get('table')
    entities = SQLHelper.get_entities(sql_opts)
    mutator = TableMutator(table)
    return mutator.insert(entities)

