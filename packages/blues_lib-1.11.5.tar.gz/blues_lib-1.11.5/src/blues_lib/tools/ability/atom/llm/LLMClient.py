from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.services.llm.BaseLLMClient import BaseLLMClient
from blues_lib.services.llm.StandardLLMClient import StandardLLMClient
from blues_lib.services.llm.JSONLLMClient import JSONLLMClient
from blues_lib.types import LLMBaseReqOpts,LLMSTDReqOpts
from blues_lib.supports.decorator.tool import ValidateAbilityExpect,ValidateToolInput

class LLMClient(BaseAbility):

  @ValidateToolInput()
  @ValidateAbilityExpect()
  def base_llm_request(self,options:dict)->dict:
    requet_opts:LLMBaseReqOpts = options.get('value')
    client = BaseLLMClient(requet_opts)
    return client.request()

  @ValidateToolInput()
  @ValidateAbilityExpect()
  def standard_llm_request(self,options:dict)->str:
    requet_opts:LLMSTDReqOpts = options.get('value')
    client = StandardLLMClient(requet_opts)
    return client.request()
  
  @ValidateToolInput()
  @ValidateAbilityExpect()
  def json_llm_request(self,options:dict)->list|dict:
    requet_opts:LLMSTDReqOpts = options.get('value')
    client = JSONLLMClient(requet_opts)
    return client.request()