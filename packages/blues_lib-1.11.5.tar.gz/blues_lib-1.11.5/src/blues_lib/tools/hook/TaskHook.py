from blues_lib.types import ToolDef
from blues_lib.tools.hook.BaseHook import BaseHook
from blues_lib.tools.hook.handler.ShareHandler import ShareHandler

class TaskHook(BaseHook):

  def _prepare_for_output(self)->None:
    ShareHandler(self._hooks,self._extra).handle()
    
  def _get_builtin_prev_tools(self)->list[ToolDef]:
    xcom_map_def:ToolDef|None = self._get_task_xcom_map_def()
    return [xcom_map_def] if xcom_map_def else []
    
  def _get_prev_task_id(self)->str:
    task_def:ToolDef = self._extra.get('definition',{})
    return task_def.get('options',{}).get('prev_task_id','')
  
  def _get_task_xcom_map_def(self)->ToolDef|None:
    prev_task_id = self._get_prev_task_id()
    if not prev_task_id:
      return None
    
    mappings:list[list[str]] = [
      [f'{prev_task_id}/code','bizdata/prev_task_code'],
      [f'{prev_task_id}/data','bizdata/prev_task_data'],
      [f'{prev_task_id}/message','bizdata/prev_task_message'],
    ]
    ability_def:ToolDef = {
      'name':'xcom_map',
      'description':'map xcom from prev task to bizdata',
      'options':{
        'value':mappings,
      }
    }
    return ability_def
