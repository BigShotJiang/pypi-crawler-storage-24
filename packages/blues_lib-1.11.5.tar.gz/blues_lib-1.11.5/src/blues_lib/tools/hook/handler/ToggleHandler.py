from blues_lib.tools.hook.handler.HookHandler import HookHandler

class ToggleHandler(HookHandler):

  ABILITY_NAME_HASH = {
    'switch_to_frame':'switch_to_default_content',
    'switch_to_new_tab':'switch_to_first_content',
    'switch_to_new_window':'switch_to_first_content',
  }

  def handle(self)->None:
    name:str = self._get_reset_name()
    if name:
      self._output_atoms.append({
        'name':name,
      })
    
  def _get_reset_name(self)->str:
    for name in self._input_ability_names:
      hash_name:str = self.ABILITY_NAME_HASH.get(name,'')
      if hash_name and hash_name not in self._output_ability_names:
        return hash_name
    return ''
