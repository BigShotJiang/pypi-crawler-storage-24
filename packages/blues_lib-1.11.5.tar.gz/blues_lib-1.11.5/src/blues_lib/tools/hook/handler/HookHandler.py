from abc import ABC,abstractmethod
from typing import Any
from blues_lib.types import ToolDef

class HookHandler(ABC):
  def __init__(self,hooks:dict[str,list[ToolDef]],extra:dict[str,Any]) -> None:
    self._hooks = hooks
    self._extra = extra
    
    self._input_atoms:list[ToolDef] = self._hooks.get('input')
    self._output_atoms:list[ToolDef] = self._hooks.get('output')
    
    self._input_ability_names:list[str] = [atom.get('name') for atom in self._input_atoms]
    self._output_ability_names:list[str] = [atom.get('name') for atom in self._output_atoms]

  @abstractmethod
  def handle(self)->None:
    pass

  def _update_hooks(self)->None:
    for atoms in self._hooks.values():
      for atom in atoms:
        name:str = atom.get('name','')
        options:dict[str,Any] = atom.get('options',{})
        self._update_ability(name,options)

  def _update_ability(self,name:str,options:dict[str,Any])->None:
    pass