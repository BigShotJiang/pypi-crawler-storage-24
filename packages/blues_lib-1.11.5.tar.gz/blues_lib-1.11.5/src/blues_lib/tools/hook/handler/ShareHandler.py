from typing import Any
from blues_lib.tools.hook.handler.HookHandler import HookHandler
from blues_lib.types import ToolDef

class ShareHandler(HookHandler):
  ABILITY_NAME:str = 'share_to_xcom'
  
  def handle(self)->None:
    if self.ABILITY_NAME not in self._output_ability_names:
      xcom_def:ToolDef = self._get_ability()
      self._output_atoms.append(xcom_def)
    
  def _get_ability(self)->ToolDef:
    value:Any = self._extra.get('result')
    ti:Any = self._extra.get('ti')
    return {
      'name':self.ABILITY_NAME, 
      'options':{
        'value':value,
        'extra':{
          'ti':ti,
        },
      },
    }
