from typing import Any
from blues_lib.tools.hook.handler.HookHandler import HookHandler

class ExtraHandler(HookHandler):
  
  def handle(self)->None:
    self._update_hooks()
    
  def _update_ability(self,name:str,options:dict[str,Any])->None:
    extra:dict[str,Any] = options.get('extra',{})
    # must keep the ref to the self._extra dict
    options['extra'] = self._extra
    self._extra.update(extra)
