import logging
from typing import Any
from abc import ABC
from blues_lib.tools.meta.validate.MetaValidator import MetaValidator
from blues_lib.types import ToolDef
from blues_lib.tools.ability.sequence.SeqExecutor import SeqExecutor
from blues_lib.tools.hook.handler.ToggleHandler import ToggleHandler
from blues_lib.tools.hook.handler.ExtraHandler import ExtraHandler
from blues_lib.tools.hook.handler.PreprocessHandler import PreprocessHandler

class BaseHook(ABC):

  HOOK_SCHEMA_TPL = 'common/hook.conf'

  def __init__(self,hooks:dict[str,list[ToolDef]]|None,extra:dict[str,Any]):
    self._extra = extra
    self._hooks = self._init_hooks(hooks or {})

    self._seq_executor = SeqExecutor(extra['driver'])
    self._logger = logging.getLogger('airflow.task')
    self._prepare()
    self._validate()
    
  def _init_hooks(self,hooks:dict[str,list[ToolDef]])->dict[str,list[ToolDef]]:
    prev_tools:list[ToolDef] = hooks.setdefault('input',[])
    prev_builtin_tools:list[ToolDef] = self._get_builtin_prev_tools()
    hooks['input'] = prev_builtin_tools + prev_tools
    
    hooks.setdefault('output',[])
    return hooks

  def _get_builtin_prev_tools(self)->list[ToolDef]:
    return []
    
  def _validate(self):
    for hook_name in self._hooks:
      hook_defs:list[ToolDef] = self._hooks[hook_name]
      MetaValidator.validate_with_template(hook_defs,self.HOOK_SCHEMA_TPL)
      
  def _prepare(self)->None:
    ToggleHandler(self._hooks,self._extra).handle()
    # add extra to tool definition's options
    ExtraHandler(self._hooks,self._extra).handle()
    
  def update(self,hook_name:str,atoms:list[ToolDef])->None:
    self._hooks.setdefault(hook_name,[]).extend(atoms)
    self._validate()

  def call(self,hook_name:str)->list[Any]|None:
    hook_defs:list[ToolDef] = self._hooks.get(hook_name,[])
    if hook_defs:
      return self._seq_executor.execute(hook_defs)
    
  def input(self)->None:
    self.call('input')

  def output(self)->None:
    # this handler relay the result
    PreprocessHandler(self._hooks,self._extra).handle()
    
    self._prepare_for_output()
    self.call('output')
    
  def _prepare_for_output(self)->None:
    pass
