from typing import Any
from blues_lib.types import ToolDef,TaskName
from blues_lib.supports.dp.factory.Factory import Factory
from blues_lib.resources.ResourceManager import ResourceManager

from blues_lib.tools.task.BaseTask import BaseTask
from blues_lib.tools.task.AtomTask import AtomTask
from blues_lib.tools.task.flow.FlowTask import FlowTask
from blues_lib.tools.task.TaskContext import TaskContext


class TaskFactory(Factory):
  
  _TASKS:dict[str,type[BaseTask]] = {
    AtomTask.__name__:AtomTask,
    FlowTask.__name__:FlowTask,
  }
  
  @classmethod
  def create(cls,definition:ToolDef|str,bizdata:dict|str|None,ti:Any,context:TaskContext)->BaseTask:

    if isinstance(definition,str):
      definition:ToolDef|None = ResourceManager.read(definition)
    if isinstance(bizdata,str):
      bizdata:dict = ResourceManager.read(bizdata) or {}
      
    if not definition:
      error = f"Failed to read definition from {definition}"
      raise ValueError(f"Failed to create task - {error}")
    
    task_name:TaskName = definition.get('name')
    task_class:type[BaseTask]|None = cls._TASKS.get(task_name)
    if not task_class:
      error = f"The task '{task_name}' is not supported."
      raise ValueError(f"Failed to create task - {error}")

    return task_class(definition,bizdata,ti,context)
  