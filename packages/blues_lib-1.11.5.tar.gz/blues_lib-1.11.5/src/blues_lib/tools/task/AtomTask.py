from typing import Any
from blues_lib.types import ToolDef
from blues_lib.tools.ability.AbilityExecutor import AbilityExecutor
from blues_lib.tools.task.BaseTask import BaseTask

class AtomTask(BaseTask):

  def _process(self)->list[Any]|dict[str,Any]:
    tools:list[ToolDef]|dict[str,ToolDef] = self._task_opts.get('tools')
    executor = AbilityExecutor(self._context.driver)
    return executor.execute(tools,self._task_biz)
