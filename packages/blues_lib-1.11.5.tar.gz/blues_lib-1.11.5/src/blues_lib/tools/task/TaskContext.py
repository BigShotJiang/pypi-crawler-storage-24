from typing import Callable
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.types import DriverMode,DriverStartupOpts,DriverLocOpts,DriverDef
from blues_lib.tools.ability.atom.webdriver.driver.DriverFactory import DriverFactory   

class TaskContext:
  _driver:WebDriver|None
  _instance = None
  _default_driver = {
    "mode":"cft",
    "startup":{
      "features" : ["imageless"],
    },
  }

  def __new__(cls,config:dict|None = None)->'TaskContext':
    if cls._instance is None:
      cls._instance = super().__new__(cls)
    return cls._instance

  def __init__(self,config:dict|None = None):
    if not hasattr(self,'_config'):
      self._config = config or {}
      self._driver = None
      self._setup()

  @property
  def driver(self)->WebDriver|None:
    return self._driver

  @classmethod
  def get_instance(cls,config:dict|None = None)->'TaskContext':
    return cls(config)
      
  def _setup(self)->None:
    driver_def:dict|False = self._config.get('driver')
    # if set as False, then not create driver
    if driver_def is False:
      return 

    driver_def = driver_def or self._default_driver
    self.add_driver(driver_def)
    
  def add_driver(self,driver_def:DriverDef)->None:
    self.clear_driver()

    mode:DriverMode = driver_def.get('mode') or 'cft'
    startup_opts:DriverStartupOpts = driver_def.get('startup') or {}
    location_opts:DriverLocOpts = driver_def.get('location') or {}

    factory =  DriverFactory(**startup_opts)
    method:Callable = getattr(factory,mode)
    self._driver = method(**location_opts)
    
  def has_driver(self)->bool:
    return self._driver is not None
  
  def clear_driver(self)->None:
    if self.has_driver():
      self._driver.quit()
      self._driver = None
      
  def clear(self)->None:
    self.clear_driver()
