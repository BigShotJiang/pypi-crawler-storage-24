import logging
from abc import ABC,abstractmethod
from typing import Any
from blues_lib.types import ToolDef
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.tools.hook.TaskHook import TaskHook
from blues_lib.supports.dp.exception import SkipTaskException,FailTaskException,BlockException
from blues_lib.tools.task.TaskContext import TaskContext

class BaseTask(ABC):

  def __init__(self,task_def:ToolDef,task_biz:dict|None,ti:Any,context:TaskContext)->None:
    self._task_def = MetaRenderer.render(task_def)
    self._task_opts = self._task_def.get('options')
    self._task_biz = MetaRenderer.render_by_self(task_biz) or {}
    self._ti = ti
    self._context = context
    self._logger = logging.getLogger('airflow.task')
  
  def get_task_id(self)->str:
    return self._task_opts.get('task_id')

  def get_prev_task_id(self)->str:
    return self._task_opts.get('prev_task_id')

  def get_next_task_id(self)->str:
    return self._task_opts.get('next_task_id')

  def execute(self)->list[Any]|dict[str,Any]|None:

    hooks:dict[str,list[ToolDef]] = {
      'input':MetaRenderer.render_node('prev_tools',self._task_opts,self._task_biz) or [],
      'output':MetaRenderer.render_node('post_tools',self._task_opts,self._task_biz) or [],
    }
    extra = {
      'driver':self._context.driver,
      'definition':self._task_def,
      'bizdata':self._task_biz,
      'result':None,
      'ti':self._ti,
    } 

    task_hook:TaskHook = TaskHook(hooks,extra) 
    try:
      task_hook.input()
      result:list[Any]|dict[str,Any] = self._process()
    except SkipTaskException as e:
      self._logger.info(f'Task {self.get_task_id()} skipped with result {e.result}')
      result:None = None
    except FailTaskException as e:
      self._logger.error(f'Task {self.get_task_id()} failed with exception {e}')
      result:dict = {'code':500,'message':str(e),'data':None}
    except BlockException as e:
      self._context.clear()
      raise e
    except Exception as e:
      self._context.clear()
      raise e

    extra['result'] = result
    task_hook.output()
    return result

  @abstractmethod   
  def _process(self)->list[Any]|dict[str,Any]:
    pass