import logging
from typing import Callable
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.meta.validate.MetaValidator import MetaValidator
from blues_lib.types import DriverDef,DriverMode,DriverStartupOpts,DriverLocOpts,ToolDef,ToolDef
from blues_lib.tools.ability.atom.webdriver.driver.DriverFactory import DriverFactory   
from blues_lib.resources.ResourceManager import ResourceManager

class DriverInitializer:
  def __init__(self,driver_def:DriverDef,definition:dict,bizdata:dict|None=None) -> None:
    self._driver_def = driver_def
    self._definition = definition
    self._bizdata = bizdata
    self._logger = logging.getLogger('airflow.task')

  def init(self)->WebDriver:
    validate_tpl = 'ability.driver_def'
    MetaValidator.validate_with_template(self._driver_def,validate_tpl)

    mode:DriverMode = self._driver_def.get('mode') or 'cft'
    startup_opts:DriverStartupOpts = self._driver_def.get('startup') or {}
    location_opts:DriverLocOpts = self._driver_def.get('location') or {}

    factory =  DriverFactory(**startup_opts)
    method:Callable = getattr(factory,mode)
    self._logger.info(f"{self.__class__.__name__} driver mode ⌜{mode}⌟ {location_opts}")
    driver:WebDriver = method(**location_opts)
    self._add_login_abilities()
    return driver
  
  def _add_login_abilities(self)->None:
    login_abilities:dict[str,ToolDef] = self._driver_def.get('login') or {}
    if not login_abilities:
      raise ValueError(f"login abilities of driver def not found")
    
    abilities:dict[str,ToolDef] = self._definition.get('abilities',{})
    self._definition['abilities'] = {**login_abilities,**abilities}

