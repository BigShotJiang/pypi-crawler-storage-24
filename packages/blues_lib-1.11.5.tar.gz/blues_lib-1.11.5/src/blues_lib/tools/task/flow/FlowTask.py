from typing import Any
from blues_lib.tools.task import TaskContext
from blues_lib.types import ToolDef
from blues_lib.tools.task.BaseTask import BaseTask
from blues_lib.tools.task.MockTI import MockTI
from blues_lib.supports.dp.exception import SkipFlowException
from blues_lib.tools.task.TaskContext import TaskContext

class FlowTask(BaseTask):
  def __init__(self,task_def:ToolDef,task_biz:dict|None,ti:Any,context:TaskContext)->None:
    super().__init__(task_def,task_biz,ti,context)
    self._task_ids:list[str] = []

  def _process(self)->list[Any]|dict[str,Any]:
    
    executors:list[BaseTask] = self._get_executors()
    for executor in executors:
      self._logger.info(f'FlowTask {executor.get_task_id()} started')
      try:
        executor.execute()
      except SkipFlowException as e:
        self._logger.error(f'flow {executor.get_task_id()} skip: {e.message}')
        break
    
    self._context.clear()
    return self.get_last_task_output()
  
  def get_task_output(self,task_id:str)->dict:
    return MockTI.store.get(task_id) or {}

  def get_last_task_output(self)->dict:
    return self.get_task_output(self._task_ids[-1])
  
  def get_task_ids(self)->list[str]:
    return self._task_ids

  def _get_executors(self)->list[BaseTask]:
    task_defs:list[ToolDef] = self._task_opts.get('tools',[])
    task_bizs:list[dict] = self._get_tool_bizs(task_defs)

    executors:list[BaseTask] = []

    prev_task_id:str = ''
    next_task_id:str = ''
    for idx,task_def in enumerate(task_defs):

      self._update_task_id(task_def,idx)
      task_id:str = self._get_task_id(task_def)
      
      # check task_id
      if not task_id:
        raise ValueError(f"task_id is not defined in task_def {task_def}")

      # add unique task_id
      self._task_ids.append(task_id)
      
      # add prev_task_id
      self._set_task_opts(task_def,'prev_task_id',prev_task_id)
      prev_task_id = task_id

      # add next_task_id
      next_task_def:ToolDef|None = self._get_next_task_def(task_defs,idx)
      next_task_id:str = self._get_task_id(next_task_def)
      self._set_task_opts(task_def,'next_task_id',next_task_id)

      task_biz:dict = task_bizs[idx] if idx < len(task_bizs) else {}
      self._append_executor(executors,task_def,task_biz)

    return executors
  
  def _get_next_task_def(self,task_defs:list[ToolDef],curr_idx:int)->ToolDef|None:
    next_idx:int = curr_idx+1
    if next_idx >= len(task_defs):
      return None
    return task_defs[next_idx]
  
  def _set_task_opts(self,task_def:ToolDef,key:str,value:Any):
    opts:dict = task_def.setdefault('options',{})
    opts[key] = value
  
  def _get_task_id(self,task_def:ToolDef|None)->str:
    if not task_def:
      return ''
    return task_def.get('options',{}).get('task_id','')
  
  def _update_task_id(self,task_def:ToolDef,idx:int)->None:
    # make sure task_id is unique in the flow
    task_id:str = self._get_task_id(task_def)
    if task_id in self._task_ids:
      new_task_id:str = f'{task_id}-{idx}'
      task_def['options']['task_id'] = new_task_id
  
  def _get_tool_bizs(self,task_defs:list[ToolDef])->list[dict]:
    if not self._task_biz:
      return []
    tools_biz:list|dict|None = self._task_biz.get('tools')
    if not tools_biz:
      return []

    # all tools use the same biz config
    if isinstance(tools_biz,dict):
      tools_len = len(task_defs)
      tools_biz = [tools_biz] * tools_len

    return tools_biz
  
  def _append_executor(self,executors:list[BaseTask],task_def:ToolDef,task_biz:dict)->None:
    task_id:str = self._get_task_id(task_def)
    ti = MockTI(task_id)
    from blues_lib.tools.task.TaskFactory import TaskFactory
    executor:BaseTask = TaskFactory.create(task_def,task_biz,ti,self._context)
    executors.append(executor)
    
