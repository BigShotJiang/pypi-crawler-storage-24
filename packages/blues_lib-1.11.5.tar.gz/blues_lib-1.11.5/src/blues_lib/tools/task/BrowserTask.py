from typing import Any
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.types import ToolDef,DriverDef,DriverMode
from blues_lib.tools.meta.render.MetaRenderer import MetaRenderer
from blues_lib.tools.ability.AbilityExecutor import AbilityExecutor
from blues_lib.tools.task.BaseTask import BaseTask
from blues_lib.tools.task.driver.DriverInitializer import DriverInitializer

class BrowserTask(BaseTask):

  def _prepare(self,definition:ToolDef,bizdata:dict|None=None)->None:
    validate_tpl = 'ability.driver_def'
    self._driver_def:DriverDef = MetaRenderer.render_and_validate_node(validate_tpl,'driver',definition,bizdata)
    mode:DriverMode = self._driver_def.get('mode')
    if mode == 'context':
      if self._context is None:
        raise ValueError(f"{self.__class__.__name__} context is required for BrowserTask with mode {mode}")
      self._driver = self._context.get('driver')
    else:
      self._driver = DriverInitializer(self._driver_def,definition,bizdata).init()

    if not self._driver or not isinstance(self._driver,WebDriver):
      raise ValueError(f"{self.__class__.__name__} failed to create the [{mode}] driver")

  def _process(self,definition:ToolDef,bizdata:dict|None=None)->list[Any]|dict[str,Any]|None:

    abilities:list[ToolDef]|dict[str,ToolDef] = definition.get('abilities')
    try:
      results:list[Any]|dict[str,Any] = AbilityExecutor(self._driver).execute(abilities,bizdata)
      self._cleanup()
      return results
    except Exception as e:
      self._cleanup()
      raise
    
  def _cleanup(self):
    # task don't deal the context's driver
    mode:DriverMode = self._driver_def.get('mode')
    # by default, task close it own driver
    ephemeral:bool = self._driver_def.get('ephemeral',True)
    if mode != 'context' and ephemeral:
      self._quit_driver()

      