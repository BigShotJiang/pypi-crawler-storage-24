from typing import TypeAlias,TypedDict,Literal,Any
from blues_lib.types.ability import Para,AttemptDelay,ToolDef

SeqCastOpts: TypeAlias = TypedDict("SeqCastOpts", {
  "by_type":Literal[
    "standard","order", # flat
    "each","elements","items","count", # loop
    "number","next", # pagination
    "template" # combo
  ],
  "by_value": dict[str,Any] | list[dict[str,Any]] | int | str | list[Para], 

  "attempts": int, # for loop and pagination
  "attempt_delay": AttemptDelay,
  
  "prev_tools": list[ToolDef],
  "post_tools": list[ToolDef],
})

SeqMethodName: TypeAlias =  Literal["cast", "cast_loop","cast_page","cast_combo"]

SeqOpts: TypeAlias = TypedDict("SeqOpts", {

  "flat": SeqCastOpts, # for standard and order
  "loop": SeqCastOpts, # for each, element, item, count
  "page": SeqCastOpts, # for number and next
  "combo": SeqCastOpts, # for para
  
  "tools": list[ToolDef]|dict[str,ToolDef], 

})
