from typing import TypeAlias,TypedDict,Any,Literal,NotRequired
from blues_lib.types.webdriver import ElementTarget,ElementRoot

AttemptDelay: TypeAlias = int|float|list[int|float]

AbilityStep: TypeAlias = TypedDict("AbilityStep", {
  "value":float|int,
  "max_attempts":int,
  "interval":float|int,
})

AbilityExpect: TypeAlias = TypedDict("AbilityExpect", {
  "method": Literal[
    "to_be", # use == to compare the string/number/boolean value
    "to_equal", # compare the array/object value
    "to_be_null", # check the value is None
    "to_be_truthy","to_be_falsy", # check the value is truthy or falsy
    "to_be_greater_than","to_be_less_than","to_be_greater_than_or_equal","to_be_less_than_or_equal", # compare the number value
    "to_contain", # string or array contain the substring or element
    "to_match", # string match the regex pattern
    "to_have_length", # array have the length
    "to_have_property", # object has the property
    "not_to_be", # use != to compare the string/number/boolean value
    "not_to_equal", # compare the array/object value not equal
    "not_to_be_null", # check the value is not None
    "not_to_be_truthy","not_to_be_falsy", # check the value is not truthy or not falsy
    "not_to_be_greater_than","not_to_be_less_than","not_to_be_greater_than_or_equal","not_to_be_less_than_or_equal", # compare the number value
    "not_to_contain", # string or array not contain the substring or element
    "not_to_match", # string not match the regex pattern
    "not_to_have_length", # array not have the length
    "not_to_have_property", # object not have the property
  ],
  "value": Any, # the value to compare
  "result": Any, # the result of the ability
  "exception": Literal["skip","block"],
})

class ToolDef(TypedDict):
  name: str
  description: NotRequired[str]
  options: dict

# --- seq level ---
# standard is the default type, and don't need by_value
ParaType: TypeAlias = Literal["text","image"]
Para: TypeAlias = TypedDict("Para", {
  "type":ParaType,
  "value":str,
})

# --- plan level ---
DriverStartupOpts: TypeAlias = TypedDict("DriverStartupOpts", {
  "features": list[str],
  "caps": dict[str,Any],
  "arguments": list[str],
  "exp_options": dict[str,Any],
  "extensions": list[str],
  "cdp_cmds": dict[str,Any],
})

# cft: chrome for testing; udc: undetected chrome; udcft: undetected chrome for testing
DriverMode: TypeAlias =  Literal["remote" , "chrome" , "cft" , "udc" , "udcft","context"]

DriverLocOpts: TypeAlias = TypedDict("DriverLocOpts", {
  # for remote
  "command_executor": str,
  # for chrome and udc
  "executable_path": str,
  "binary_location": str,
  # for context
  "path": str,
})

LoginMode: TypeAlias =  Literal["account","sms","qrcode"]
 
DriverDef: TypeAlias = TypedDict("DriverDef", {
  "mode": DriverMode,
  "ephemeral": bool, # whether quit the driver after task finished
  "startup": DriverStartupOpts,
  "location": DriverLocOpts,
  "login": str, # login definition uri
})
