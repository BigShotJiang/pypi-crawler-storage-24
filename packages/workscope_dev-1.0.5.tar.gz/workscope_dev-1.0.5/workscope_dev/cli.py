"""Smart dispatcher module for global wsd command.

This module serves as the entry point for the globally-installed wsd command
(via pipx). It implements intelligent routing logic that distinguishes between:

1. Global commands (install/update/uninstall) - Always use bundled wsd.py
2. Project commands - Delegate to local wsd.py if present
3. Help/version - Delegate to local if present, bundled otherwise

The dispatcher ensures a unified user experience where a single `wsd` command
handles both package-level operations and project-level operations.

Usage:
    wsd install <path>    Install WSD to target directory
    wsd update <path>     Update existing WSD installation
    wsd uninstall <path>  Remove WSD from target directory
    wsd <command>         Run command from local wsd.py (if present)

When run from a WSD-enabled project directory, project-specific commands
like `wsd test`, `wsd health`, etc. are delegated to the local wsd.py.
"""

import subprocess
import sys
from pathlib import Path


# Commands that always use the bundled wsd.py regardless of local presence
GLOBAL_COMMANDS = {"install", "update", "uninstall"}

# Flags that delegate to local when present, use bundled when absent
HELP_VERSION_FLAGS = {"--help", "-h", "--version", "-v"}


def local_wsd_exists() -> bool:
    """Check if local project has wsd.py installed.

    Returns:
        True if wsd.py exists in current working directory, False otherwise
    """
    return (Path.cwd() / "wsd.py").exists()


def run_bundled_wsd(args: list[str]) -> None:
    """Execute the package's bundled wsd.py with provided arguments.

    Finds the bundled wsd.py relative to this module's location and executes
    it with the given arguments. Exit code is propagated to the caller.

    Args:
        args: Command-line arguments to pass to bundled wsd.py
    """
    bundled_wsd = Path(__file__).parent / "wsd.py"
    result = subprocess.run(
        [sys.executable, str(bundled_wsd), *args],
        cwd=Path.cwd(),
        check=False,
    )
    sys.exit(result.returncode)


def delegate_to_local_wsd(args: list[str]) -> None:
    """Execute the local project's wsd.py with provided arguments.

    Finds the local wsd.py in the current working directory and executes
    it with the given arguments. Exit code is propagated to the caller.

    Args:
        args: Command-line arguments to pass to local wsd.py
    """
    local_wsd = Path.cwd() / "wsd.py"
    result = subprocess.run(
        [sys.executable, str(local_wsd), *args],
        cwd=Path.cwd(),
        check=False,
    )
    sys.exit(result.returncode)


def show_package_help() -> None:
    """Display usage information for the global wsd command.

    Shows available package-level commands (install, update, uninstall) and
    guidance for project-specific commands.
    """
    print("WSD (Workscope Development) - Template management for AI-assisted development")
    print()
    print("Usage:")
    print("  wsd install <path>    Install WSD to target directory")
    print("  wsd update <path>     Update existing WSD installation")
    print("  wsd uninstall <path>  Remove WSD from target directory")
    print("  wsd <command>         Run command from local wsd.py")
    print()
    print("For project-specific commands, run from a WSD-enabled project directory.")


def print_no_local_wsd_error() -> None:
    """Display error when local wsd.py required but not found.

    Provides guidance on how to install WSD to the current directory.
    """
    print("Error: No wsd.py found in current directory.", file=sys.stderr)
    print(file=sys.stderr)
    print("This command requires a local WSD installation. To set up WSD:", file=sys.stderr)
    print("  wsd install .", file=sys.stderr)
    print(file=sys.stderr)
    print("Or navigate to a project with WSD already installed.", file=sys.stderr)


def main() -> None:
    """Entry point for the wsd CLI command.

    Implements smart dispatch logic based on the command and context:

    - Global commands (install/update/uninstall): Always use bundled wsd.py
    - Help/version flags: Delegate to local if present, bundled otherwise
    - No arguments: Delegate to local if present, show package help otherwise
    - Other commands: Delegate to local if present, error otherwise
    """
    args = sys.argv[1:]

    # No arguments: delegate to local or show package help
    if not args:
        if local_wsd_exists():
            delegate_to_local_wsd([])
        else:
            show_package_help()
        return

    # Get the first argument to determine routing
    first_arg = args[0]

    # Global commands always use bundled wsd.py
    if first_arg in GLOBAL_COMMANDS:
        run_bundled_wsd(args)
        return

    # Help/version flags: delegate to local if present, bundled otherwise
    if first_arg in HELP_VERSION_FLAGS:
        if local_wsd_exists():
            delegate_to_local_wsd(args)
        else:
            run_bundled_wsd(args)
        return

    # All other commands require local wsd.py
    if local_wsd_exists():
        delegate_to_local_wsd(args)
    else:
        print_no_local_wsd_error()
        sys.exit(1)


if __name__ == "__main__":
    main()
