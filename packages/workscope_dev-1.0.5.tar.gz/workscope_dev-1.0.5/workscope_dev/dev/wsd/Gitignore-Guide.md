# Gitignore Guide

**Version:** 1.0.0
**Audience:** Developers using WSD in version-controlled projects

## Introduction

WSD installs several files and directories that should be excluded from version control. These are symlinks or generated outputs that change frequently and provide no value when tracked by git. The actual content they point to (archived prompts, archived journals) is tracked normally through its permanent locations.

This guide documents which entries to add to your project's `.gitignore` and explains the rationale for each.

## Recommended Entries

The following entries should be added to your project's `.gitignore`:

```
# Workscope-Dev Coordination Files
dev/reports/
dev/journal/Current-Journal.md
dev/prompts/Current-Prompts.md
dev/prompts/Previous-Prompts.md
```

### Entry Rationale

**`dev/prompts/Current-Prompts.md`** is a symlink to the active prompt workspace archive file in `dev/prompts/archive/`. The archive file itself is tracked normally; the symlink simply provides a stable path to whichever archive is currently active. Tracking the symlink would create noisy diffs every time a new prompt workspace is started, since the symlink target changes each time.

**`dev/prompts/Previous-Prompts.md`** is a symlink to the previous prompt workspace archive file. Like `Current-Prompts.md`, it provides a convenience pointer that changes frequently. The underlying archive files in `dev/prompts/archive/` are tracked as usual.

**`dev/journal/Current-Journal.md`** is a symlink to the active Work Journal in `dev/journal/archive/`. Each workscope session creates a new journal file in the archive, and this symlink points to whichever journal is currently in use. The archived journals are tracked; the rotating symlink is not.

**`dev/reports/`** contains tool-generated output such as API documentation produced by pdoc, TypeDoc, JSDoc, and other documentation generators. These reports are regenerated on demand and should not be committed. The directory can be recreated at any time by running the appropriate documentation generation commands.

## Adding Entries to Your Project

### New Projects

When setting up a new project with WSD, the installation includes a `.gitignore` file that already contains these entries alongside standard patterns for Python, TypeScript/JavaScript, and general development artifacts. No additional action is needed for new projects that use the provided `.gitignore` as their starting point.

### Existing Projects

When adding WSD to a project that already has a `.gitignore`, append the recommended entries to your existing file. A dedicated section keeps the entries organized and easy to identify:

```
# Workscope-Dev Coordination Files
dev/reports/
dev/journal/Current-Journal.md
dev/prompts/Current-Prompts.md
dev/prompts/Previous-Prompts.md
```

Before adding entries, check whether your existing `.gitignore` already covers them through broader patterns. For example, if your `.gitignore` already contains `dev/` or `dev/reports/`, additional entries for files within those directories are unnecessary.

## Additional Context

The entries documented here represent the minimum set identified through practitioner experience with WSD. As WSD evolves and new coordination files are introduced, this guide will be updated to reflect additional recommendations.

The WSD installation's `.gitignore` also includes entries for `dev/template/`, `.workscope-id`, and `.workscope-parent-branch`. These are included in the installed `.gitignore` and do not require manual addition, but they serve a similar purpose of excluding transient coordination files from version control.

---

*For installation instructions, see `Integration-Guide.md`. For daily usage, see `User-Guide.md`.*
