## Models:
## `opus` : claude-opus-4-6
## `opus[1m]`: claude-opus-4-6[1m]
## `sonnet` : claude-sonnet-4-6
## `sonnet[1m]` : claude-sonnet-4-6[1m]
## `haiku` : claude-haiku-4-5-20251001
##   - These models also have a "strength" component, e.g., `opus|med` or `opus|high`

## Modes:
## `design` means the session opened with `/wsd:init --custom` for collaboration
## `compile` means the session opened with `/wsd:init` and ran a workscope cycle
##   - In the case of `compile`, add the WPD file and the phases addressed

---

## New Session: Claude Code v2.1.71: `opus|high`
## Mode: ``
## WPD: ``
## Phases: all

