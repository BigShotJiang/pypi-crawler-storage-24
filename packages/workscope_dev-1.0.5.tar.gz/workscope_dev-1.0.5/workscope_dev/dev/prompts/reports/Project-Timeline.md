---
title: "Project Timeline"
description: "Extract dated entries for: milestones reached, features completed, experiments run, key decisions made, methodology changes. This report is invaluable for establishing a chronology for the project and hunting down issues or answering questions that depend on what was done when."
integration: "Append new entries in chronological order using date headers (## YYYY-MM-DD) with concise bullet points underneath. If an entry already exists for a given date, add new bullets to the existing date section rather than creating a duplicate."
stage: distributed
distribute_by: "month - entries grouped by calendar month"
---

# Project Timeline
