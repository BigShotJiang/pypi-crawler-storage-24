#!/usr/bin/env python
"""Decomposition script for the Decompose Report Skill.

Transforms monolithic report files in dev/prompts/reports/ into distributed
report directories with section files. Supports two modes: inventory (emit
a raw section inventory as JSON to stdout) and execute (perform the
decomposition using an agent-provided execution plan read from stdin).

The script handles structural parsing and plan-driven file I/O. All
semantic reasoning (grouping strategy interpretation, section organization,
filename generation for groups) belongs to the orchestrating agent.

Key Components:
    parse_args              - CLI argument parsing for mode and filename
    validate_report         - Report existence, frontmatter, and stage checks
    parse_yaml_frontmatter  - YAML frontmatter extraction from markdown files
    parse_headings          - Heading and section boundary identification
    to_kebab_case           - Heading text to kebab-case filename conversion
    run_inventory_mode      - Inventory workflow: validate, parse, emit JSON
    run_execute_mode        - Execute workflow: read plan from stdin, extract
                              sections, transform meta file with error recovery
"""

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any, TypedDict


# Paths relative to project root (working directory at invocation time)
REPORTS_DIR = Path("dev/prompts/reports")

# Pattern for any ## heading
H2_HEADING_PATTERN = re.compile(r"^##\s+(.+)$")


class SectionInfo(TypedDict):
    """A single section identified during heading parsing.

    Attributes:
        heading: The full heading line including the ## prefix.
        heading_text: The heading text without the ## prefix.
        content: The complete section content including the heading line
            and all body text until the next ## heading.
        child_headings: List of child heading lines (### and deeper)
            found within this section, including the heading prefix.
        size_bytes: Size of the section content in bytes.
    """

    heading: str
    heading_text: str
    content: str
    child_headings: list[str]
    size_bytes: int


class InventorySection(TypedDict):
    """A section entry in the inventory output.

    Attributes:
        index: Zero-based sequential index of this section in document order.
        heading: The full heading line including the ## prefix.
        heading_text: The heading text without the ## prefix.
        default_filename: Kebab-case filename suggestion with .md extension,
            derived from the heading text.
        size_kb: Size of the section content in kilobytes (rounded).
        child_headings: List of child heading lines (### and deeper)
            found within this section, including the heading prefix.
    """

    index: int
    heading: str
    heading_text: str
    default_filename: str
    size_kb: int
    child_headings: list[str]


class InventorySummary(TypedDict):
    """Summary statistics for the section inventory.

    Attributes:
        total_sections: Number of sections found in the report.
        total_size_kb: Total size of all section content in kilobytes.
        average_section_kb: Average section size in kilobytes (rounded).
    """

    total_sections: int
    total_size_kb: int
    average_section_kb: int


class InventoryOutput(TypedDict):
    """Complete inventory output emitted by inventory mode.

    Attributes:
        report_file: Relative path to the report file from project root.
        report_title: Title extracted from report YAML frontmatter.
        current_size_kb: Current report file size in kilobytes.
        has_preamble: Whether content exists between the title heading
            and the first ## heading.
        section_directory: Relative path to the section directory that
            would be created during execution.
        sections: List of section entries with structural data only.
        summary: Aggregate statistics about the sections.
    """

    report_file: str
    report_title: str
    current_size_kb: int
    has_preamble: bool
    section_directory: str
    sections: list[InventorySection]
    summary: InventorySummary


class PlanOutputFile(TypedDict):
    """A single output file entry in the execution plan.

    Attributes:
        filename: Target filename within the section directory.
        display_name: Human-readable name used as the link text in the
            meta file table of contents.
        section_indices: List of zero-based section indices whose content
            is concatenated in index order into this output file.
    """

    filename: str
    display_name: str
    section_indices: list[int]


class ExecutionPlan(TypedDict):
    """Execution plan provided by the orchestrating agent via stdin.

    Attributes:
        distribute_by: Natural language description of the distribution
            strategy, written to the meta file frontmatter.
        output_files: List of output file specifications mapping
            section indices to target filenames.
    """

    distribute_by: str
    output_files: list[PlanOutputFile]


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments for decomposition modes.

    Args:
        argv: Argument list to parse. If None, uses sys.argv[1:].

    Returns:
        Parsed namespace with mode and report_filename.
    """
    parser = argparse.ArgumentParser(
        description="Decomposition script for the Decompose Report Skill.",
    )
    parser.add_argument(
        "mode",
        choices=["inventory", "execute"],
        help="Operating mode: 'inventory' to emit a raw section inventory, "
        "'execute' to perform decomposition using a plan from stdin.",
    )
    parser.add_argument(
        "report_filename",
        type=str,
        help="Filename of the report in dev/prompts/reports/ to decompose.",
    )
    return parser.parse_args(argv)


def parse_yaml_frontmatter(file_path: Path) -> dict[str, str] | None:
    """Parse YAML frontmatter from a markdown file.

    Extracts key-value pairs from the YAML block delimited by '---' markers
    at the beginning of the file. Supports multi-line values using YAML
    folded (>) and literal (|) scalar indicators, as well as quoted strings.

    Args:
        file_path: Path to the markdown file with YAML frontmatter.

    Returns:
        Dictionary of frontmatter fields, or None if no valid frontmatter
        block is found.
    """
    with file_path.open(encoding="utf-8") as f:
        content = f.read()

    lines = content.split("\n")

    if not lines or lines[0].strip() != "---":
        return None

    end_index = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end_index = i
            break

    if end_index is None:
        return None

    frontmatter: dict[str, str] = {}
    current_key: str | None = None
    current_value_lines: list[str] = []
    is_multiline = False

    for line in lines[1:end_index]:
        if not line.startswith(" ") and not line.startswith("\t") and ":" in line:
            if current_key is not None:
                frontmatter[current_key] = _join_multiline_value(current_value_lines)

            colon_pos = line.index(":")
            current_key = line[:colon_pos].strip()
            raw_value = line[colon_pos + 1 :].strip()

            if raw_value in (">", "|"):
                is_multiline = True
                current_value_lines = []
            else:
                is_multiline = False
                # Strip surrounding quotes from inline values
                if (
                    len(raw_value) >= 2
                    and raw_value[0] == raw_value[-1]
                    and raw_value[0] in ('"', "'")
                ):
                    raw_value = raw_value[1:-1]
                current_value_lines = [raw_value]
        elif is_multiline and current_key is not None:
            current_value_lines.append(line.strip())

    if current_key is not None:
        frontmatter[current_key] = _join_multiline_value(current_value_lines)

    return frontmatter


def _join_multiline_value(lines: list[str]) -> str:
    """Join multiline YAML value lines into a single string.

    Filters out empty lines and joins with spaces (folded scalar behavior).

    Args:
        lines: List of stripped value lines.

    Returns:
        Joined string value.
    """
    return " ".join(line for line in lines if line)


def validate_report(report_path: Path) -> dict[str, str]:
    """Validate a report file for decomposition eligibility.

    Checks that the report file exists, has valid YAML frontmatter, and is
    in the flat stage (no stage field or stage: flat). Reports already in
    the distributed stage are rejected.

    Args:
        report_path: Path to the report file to validate.

    Returns:
        Parsed YAML frontmatter dictionary for the report.

    Raises:
        SystemExit: If validation fails for any reason.
    """
    if not report_path.exists():
        print(
            f"Error: Report file '{report_path}' not found.\n"
            f"Verify the filename and ensure it exists in {REPORTS_DIR}/.",
            file=sys.stderr,
        )
        sys.exit(1)

    frontmatter = parse_yaml_frontmatter(report_path)

    if frontmatter is None:
        print(
            f"Error: Report file '{report_path.name}' has no valid YAML frontmatter.\n"
            f"Reports must have YAML frontmatter with at least a 'title' field.",
            file=sys.stderr,
        )
        sys.exit(1)

    if "title" not in frontmatter:
        print(
            f"Error: Report file '{report_path.name}' is missing required "
            f"frontmatter field 'title'.",
            file=sys.stderr,
        )
        sys.exit(1)

    stage = frontmatter.get("stage", "")
    if stage == "distributed":
        section_dir = REPORTS_DIR / report_path.stem
        print(
            f"Error: Report '{report_path.name}' is already in the distributed stage.\n"
            f"Re-decomposition is not supported. The report's section files are at:\n"
            f"  {section_dir}/",
            file=sys.stderr,
        )
        sys.exit(1)

    return frontmatter


def parse_headings(file_path: Path) -> tuple[str, list[SectionInfo]]:
    """Parse a report file into preamble and sections.

    Scans the report body for ## headings. Each ## heading and all content
    until the next ## heading (including ### and deeper children) constitutes
    one section. Content between the # Title heading and the first ## heading
    is returned as preamble.

    Args:
        file_path: Path to the report file to parse.

    Returns:
        Tuple of (preamble, sections) where preamble is content before the
        first ## heading (after frontmatter) and sections is a list of
        SectionInfo dicts.

    Raises:
        SystemExit: If no ## headings are found in the report.
    """
    with file_path.open(encoding="utf-8") as f:
        content = f.read()

    # Strip frontmatter
    body = _strip_frontmatter(content)

    # Split body into lines for heading detection
    lines = body.split("\n")

    # Find all ## heading positions
    h2_positions: list[int] = []
    for i, line in enumerate(lines):
        if H2_HEADING_PATTERN.match(line):
            h2_positions.append(i)

    if not h2_positions:
        print(
            f"Error: Report '{file_path.name}' has no ## headings.\n"
            f"Decomposition requires at least one ## heading to define section boundaries.\n"
            f"Add heading structure to the report before decomposing.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Compute character offsets for each line to enable lossless body slicing.
    # Each offset marks the start of a line in the body string. The final
    # entry (len(lines)) points past the last line, clamped to len(body).
    char_offsets: list[int] = [0]
    for line in lines:
        char_offsets.append(char_offsets[-1] + len(line) + 1)

    # Extract preamble (content before first ## heading)
    preamble = body[: char_offsets[h2_positions[0]]]

    # Extract sections using body slicing for lossless content preservation
    sections: list[SectionInfo] = []
    for idx, start_pos in enumerate(h2_positions):
        end_pos = h2_positions[idx + 1] if idx + 1 < len(h2_positions) else len(lines)
        section_content = body[char_offsets[start_pos] : char_offsets[end_pos]]

        # Use lines for heading and child heading extraction
        heading_line = lines[start_pos]
        heading_match = H2_HEADING_PATTERN.match(heading_line)
        heading_text = heading_match.group(1).strip() if heading_match else heading_line[3:].strip()

        # Find child headings (### and deeper), preserving full heading line
        section_lines = lines[start_pos:end_pos]
        child_headings: list[str] = []
        for section_line in section_lines[1:]:
            if re.match(r"^#{3,}\s+.+$", section_line):
                child_headings.append(section_line)

        sections.append(
            SectionInfo(
                heading=heading_line,
                heading_text=heading_text,
                content=section_content,
                child_headings=child_headings,
                size_bytes=len(section_content.encode("utf-8")),
            )
        )

    return preamble, sections


def _strip_frontmatter(content: str) -> str:
    """Remove YAML frontmatter from markdown content.

    Args:
        content: Full markdown file content.

    Returns:
        Content with frontmatter block removed. If no frontmatter is
        present, returns the original content unchanged.
    """
    lines = content.split("\n")

    if not lines or lines[0].strip() != "---":
        return content

    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            # Return everything after the closing ---
            remaining = "\n".join(lines[i + 1 :])
            # Strip leading blank lines but preserve the rest
            return remaining.lstrip("\n")

    return content


def to_kebab_case(text: str) -> str:
    """Convert heading text to a kebab-case filename stem.

    Lowercases the text, replaces spaces with hyphens, and removes
    non-alphanumeric characters except hyphens. Collapses consecutive
    hyphens into a single hyphen and strips leading/trailing hyphens.

    Args:
        text: Heading text to convert.

    Returns:
        Kebab-case string suitable for use as a filename stem.
    """
    result = text.lower()
    result = result.replace(" ", "-")
    result = re.sub(r"[^a-z0-9-]", "", result)
    result = re.sub(r"-+", "-", result)
    return result.strip("-")


def run_inventory_mode(report_filename: str) -> None:
    """Execute the inventory mode workflow.

    Validates the report, parses its heading structure, and prints a raw
    section inventory as JSON to stdout. The inventory contains structural
    data only; no grouping decisions or strategy inference.

    Args:
        report_filename: Filename of the report in dev/prompts/reports/.
    """
    report_path = REPORTS_DIR / report_filename
    frontmatter = validate_report(report_path)
    preamble, sections = parse_headings(report_path)

    file_size_kb = round(report_path.stat().st_size / 1024)
    total_size_bytes = sum(s["size_bytes"] for s in sections)
    total_size_kb = round(total_size_bytes / 1024)

    inventory_sections: list[InventorySection] = []
    for idx, section in enumerate(sections):
        inventory_sections.append(
            InventorySection(
                index=idx,
                heading=section["heading"],
                heading_text=section["heading_text"],
                default_filename=f"{to_kebab_case(section['heading_text'])}.md",
                size_kb=round(section["size_bytes"] / 1024),
                child_headings=section["child_headings"],
            )
        )

    output = InventoryOutput(
        report_file=str(report_path),
        report_title=frontmatter["title"],
        current_size_kb=file_size_kb,
        has_preamble=bool(preamble.strip()),
        section_directory=f"{report_path.parent / report_path.stem}/",
        sections=inventory_sections,
        summary=InventorySummary(
            total_sections=len(inventory_sections),
            total_size_kb=total_size_kb,
            average_section_kb=(
                round(total_size_kb / len(inventory_sections)) if inventory_sections else 0
            ),
        ),
    )

    print(json.dumps(output, indent=2))


def _validate_plan(plan_data: dict[str, Any], section_count: int) -> ExecutionPlan:
    """Validate an execution plan from the orchestrating agent.

    Checks that the plan has the required fields, all filenames are unique,
    all section indices are within range, and distribute_by is present.

    Args:
        plan_data: Parsed JSON data from stdin.
        section_count: Number of sections in the report, for index validation.

    Returns:
        Validated execution plan.

    Raises:
        SystemExit: If the plan fails validation.
    """
    if "distribute_by" not in plan_data or not plan_data["distribute_by"]:
        print(
            "Error: Execution plan is missing required 'distribute_by' field.",
            file=sys.stderr,
        )
        sys.exit(1)

    if "output_files" not in plan_data or not plan_data["output_files"]:
        print(
            "Error: Execution plan is missing required 'output_files' field.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Validate unique filenames and required fields per output file
    filenames: list[str] = []
    for entry in plan_data["output_files"]:
        filename = entry.get("filename", "")
        if not filename:
            print(
                "Error: An output_files entry is missing the 'filename' field.",
                file=sys.stderr,
            )
            sys.exit(1)
        if "display_name" not in entry or not entry["display_name"]:
            print(
                f"Error: Output file '{filename}' is missing required 'display_name' field.",
                file=sys.stderr,
            )
            sys.exit(1)
        if filename in filenames:
            print(
                f"Error: Duplicate filename '{filename}' found in execution plan.\n"
                f"Each output file must have a unique filename.",
                file=sys.stderr,
            )
            sys.exit(1)
        filenames.append(filename)

    # Validate section indices
    for entry in plan_data["output_files"]:
        indices = entry.get("section_indices", [])
        if not indices:
            print(
                f"Error: Output file '{entry.get('filename', '?')}' has no section_indices.",
                file=sys.stderr,
            )
            sys.exit(1)
        for index in indices:
            if not isinstance(index, int) or index < 0 or index >= section_count:
                print(
                    f"Error: Invalid section index {index} in output file "
                    f"'{entry.get('filename', '?')}'. "
                    f"Valid range is 0 to {section_count - 1}.",
                    file=sys.stderr,
                )
                sys.exit(1)

    return ExecutionPlan(
        distribute_by=plan_data["distribute_by"],
        output_files=[
            PlanOutputFile(
                filename=entry["filename"],
                display_name=entry["display_name"],
                section_indices=entry["section_indices"],
            )
            for entry in plan_data["output_files"]
        ],
    )


def run_execute_mode(report_filename: str) -> None:
    """Execute the decomposition workflow using a plan from stdin.

    Reads an execution plan as JSON from stdin, re-validates the report,
    creates the section directory, extracts sections to files according
    to the plan, and transforms the original report into a meta file.
    If any error occurs during section extraction, cleans up the partial
    section directory and leaves the original report unchanged.

    Args:
        report_filename: Filename of the report in dev/prompts/reports/.
    """
    report_path = REPORTS_DIR / report_filename
    frontmatter = validate_report(report_path)
    preamble, sections = parse_headings(report_path)

    # Read execution plan from stdin
    try:
        plan_data = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        print(
            f"Error: Failed to parse execution plan from stdin.\nDetails: {e}",
            file=sys.stderr,
        )
        sys.exit(1)

    plan = _validate_plan(plan_data, len(sections))
    section_dir = report_path.parent / report_path.stem

    # Check for existing section directory
    if section_dir.exists():
        print(
            f"Error: Section directory '{section_dir}/' already exists.\n"
            f"Investigate the existing directory and remove or rename it before retrying.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Create section directory and extract sections
    try:
        section_dir.mkdir(parents=True)
        _extract_sections(plan, sections, section_dir)
    except Exception as e:
        # Error recovery: clean up partial section directory
        if section_dir.exists():
            shutil.rmtree(str(section_dir))
        print(
            f"Error: Decomposition failed during section extraction.\n"
            f"Details: {e}\n"
            f"The section directory has been cleaned up and the original report is unchanged.",
            file=sys.stderr,
        )
        sys.exit(1)

    # All sections written successfully; now transform the meta file
    _write_meta_file(report_path, frontmatter, preamble, plan)

    # Emit completion summary
    print(
        f"Decomposition complete.\n"
        f"  Sections created: {len(plan['output_files'])}\n"
        f"  Section directory: {section_dir}/\n"
        f"  Meta file: {report_path}"
    )


def _extract_sections(
    plan: ExecutionPlan,
    sections: list[SectionInfo],
    section_dir: Path,
) -> None:
    """Extract section content to files according to the execution plan.

    For each output file in the plan, concatenates the content of the
    specified sections (by index, in index order) and writes to the
    target filename within the section directory.

    Args:
        plan: The validated execution plan with output file specifications.
        sections: The parsed sections from the original report.
        section_dir: Path to the section directory.

    Raises:
        OSError: If a section file cannot be written.
    """
    for output_file in plan["output_files"]:
        file_path = section_dir / output_file["filename"]
        combined_content = "".join(
            sections[idx]["content"] for idx in output_file["section_indices"]
        )
        with file_path.open("w", encoding="utf-8") as f:
            f.write(combined_content)
            if not combined_content.endswith("\n"):
                f.write("\n")


def _write_meta_file(
    report_path: Path,
    frontmatter: dict[str, str],
    preamble: str,
    plan: ExecutionPlan,
) -> None:
    """Transform the original report file into a meta file.

    Preserves the original title, description, and integration frontmatter
    fields. Adds stage: distributed and distribute_by fields from the plan.
    Replaces the body with a table of contents linking to section files,
    using display names and filenames from the plan's output_files.

    Args:
        report_path: Path to the report file to transform.
        frontmatter: Original parsed YAML frontmatter.
        preamble: Content between the title heading and the first ##
            heading, preserved in the meta file body above the TOC.
        plan: The execution plan with distribute_by and output file specs.
    """
    # Build frontmatter block
    fm_lines = ["---"]
    for key in ("title", "description", "integration"):
        value = frontmatter.get(key, "")
        if value:
            fm_lines.append(f'{key}: "{value}"')
    fm_lines.append("stage: distributed")
    fm_lines.append(f'distribute_by: "{plan["distribute_by"]}"')
    fm_lines.append("---")

    # Build TOC from plan output files
    report_stem = report_path.stem
    toc_lines: list[str] = []
    for output_file in plan["output_files"]:
        display_name = output_file["display_name"]
        filename = output_file["filename"]
        toc_lines.append(f"- [{display_name}]({report_stem}/{filename})")

    # Assemble meta file content
    parts = ["\n".join(fm_lines), ""]

    # Include preamble if present (content between # Title and first ##)
    preamble_stripped = preamble.strip()
    if preamble_stripped:
        parts.append(preamble_stripped)
        parts.append("")

    parts.append("\n".join(toc_lines))
    parts.append("")

    with report_path.open("w", encoding="utf-8") as f:
        f.write("\n".join(parts))


def main() -> None:
    """Entry point for the decomposition script."""
    args = parse_args()

    if args.mode == "inventory":
        run_inventory_mode(args.report_filename)
    elif args.mode == "execute":
        run_execute_mode(args.report_filename)


if __name__ == "__main__":
    main()
