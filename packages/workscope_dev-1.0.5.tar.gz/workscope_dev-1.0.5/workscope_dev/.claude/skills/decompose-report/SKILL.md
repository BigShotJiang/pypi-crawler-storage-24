---
name: decompose-report
description: Decomposes a monolithic report file in dev/prompts/reports/ into a distributed report directory with section files. Use when a report has grown too large for the prompt-analyzer's context window.
argument-hint: <report-filename> [--distribute-by "<strategy>"]
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Bash, Glob
---

# Decompose Report

Transform a monolithic report file in `dev/prompts/reports/` into a distributed report directory with section files. The decomposition script handles structural parsing and plan-driven file I/O; the orchestrating agent handles grouping decisions, plan construction, and User interaction.

## Invocation

```
/decompose-report <report-filename> [--distribute-by "<strategy>"]
```

The report filename argument is required. It is the filename (not full path) of the report in `dev/prompts/reports/`. The optional `--distribute-by` flag provides a natural language description of how sections should be organized into output files. If omitted, the agent infers a strategy from the heading patterns.

Examples:
```
/decompose-report Design-Evolution.md
/decompose-report Project-Timeline.md --distribute-by "month - entries grouped by calendar month"
```

## Workflow

Execute the following 6 steps. Do not skip steps or reorder them. All steps are sequential.

### Step 1: Argument Parsing

Parse the arguments provided with `/decompose-report`:

- **Report filename**: The first argument is the report filename (required). This is the filename only, not the full path.
- **`--distribute-by` flag**: If `--distribute-by` appears in the arguments, capture the quoted string that follows it as the distribution strategy. This strategy guides how sections are grouped into output files during Step 3.

**Error handling:** If no report filename is provided, report:
```
Error: No report filename provided.
Usage: /decompose-report <report-filename> [--distribute-by "<strategy>"]
```
Halt. Do not proceed.

### Step 2: Inventory

Run the decomposition script in `inventory` mode via Bash:

```bash
python .claude/skills/decompose-report/scripts/decompose.py inventory <report-filename>
```

The script validates the report file, parses its heading structure, and outputs a raw section inventory as JSON to stdout. Capture and parse this JSON output. The inventory contains structural data only — no grouping decisions.

The inventory JSON contains:
- `report_file`: Path to the report
- `report_title`: Title from frontmatter
- `current_size_kb`: Report file size
- `has_preamble`: Whether content exists before the first `##` heading
- `section_directory`: Path where section files will be created
- `sections`: Array of section objects, each with:
  - `index`: Zero-based sequential index
  - `heading`: Full heading line including `##` prefix
  - `heading_text`: Heading text without the `##` prefix
  - `default_filename`: Kebab-case filename suggestion
  - `size_kb`: Section content size in kilobytes
  - `child_headings`: List of child heading lines (`###` and deeper)
- `summary`: Aggregate statistics (`total_sections`, `total_size_kb`, `average_section_kb`)

**Error handling:** If the script exits with a non-zero status, report the script's stderr output to the User and halt. Do not proceed. Common errors include:
- Report file not found
- Report has no valid YAML frontmatter
- Report is already in the distributed stage
- Report has no `##` headings for section boundaries

### Step 3: Grouping

Examine the raw section inventory from Step 2 and determine how sections should be organized into output files.

**If `--distribute-by` was provided:** Interpret the natural language strategy and apply it to the section inventory. For example, `"month - entries grouped by calendar month"` on a report with date-formatted headings (`## 2025-11-03`, `## 2025-11-05`) would group sections by their month prefix into output files like `2025-11.md`.

**If `--distribute-by` was not provided:** Infer an appropriate strategy from the heading patterns. Common strategies include:
- **Thematic (1:1 mapping)**: One output file per section, using each section's `default_filename` and `heading_text`. Appropriate when headings represent distinct topics.
- **Chronological (many:1 mapping)**: Multiple date-entry sections grouped by time period (e.g., by month). Appropriate when headings follow date patterns like `## YYYY-MM-DD`.
- Any other reasonable organization that matches the heading structure.

Construct an execution plan JSON with the following structure:

```json
{
  "distribute_by": "<strategy description>",
  "output_files": [
    {
      "filename": "<target-filename.md>",
      "display_name": "<human-readable name for TOC>",
      "section_indices": [0, 1, 2]
    }
  ]
}
```

**Plan construction guidance:**

- **`distribute_by`**: A natural language string describing the distribution strategy (e.g., `"thematic area - each major design thread is its own section file"` or `"month - entries grouped by calendar month"`). If the User provided `--distribute-by`, use that value. Otherwise, compose a descriptive string for the inferred strategy.

- **For 1:1 mapping** (one output file per raw section): Use the section's `default_filename` as `filename` and `heading_text` as `display_name`. Each entry's `section_indices` array contains a single index.

- **For many:1 mapping** (multiple raw sections grouped into one output file): Generate an appropriate `filename` for the group (e.g., `2025-11.md` for a month-based grouping) and a descriptive `display_name` (e.g., `November 2025`). The `section_indices` array contains all indices for sections in that group, in ascending order.

- **Filename collision detection**: After constructing all output file entries, check for duplicate filenames. If collisions exist, resolve by appending a numeric suffix to duplicates (e.g., `api-design.md`, `api-design-2.md`, `api-design-3.md`). The first occurrence keeps the original name.

### Step 4: Plan Presentation and Approval

Present the decomposition plan to the User, including:
- The report file and its current size (`current_size_kb` from the inventory)
- The proposed distribution strategy (`distribute_by` from the plan)
- The section directory path (`section_directory` from the inventory)
- A list of output files that will be created, showing each file's name, display name, assigned sections (with headings and sizes), and total size
- Summary statistics: total output file count, total section count, and size distribution

**HALT.** Wait for explicit User approval before proceeding. The User may:
- **Approve**: Proceed to Step 5
- **Reject**: Abort the decomposition entirely. Report that the decomposition was cancelled and stop.
- **Modify**: Request a different grouping strategy. Return to Step 3 with the new strategy and re-construct the plan from the same inventory (no need to re-run the script). Re-present the updated plan.

**Error handling:** If the User rejects the plan, halt. Do not proceed. Report:
```
Decomposition cancelled by User.
```

### Step 5: Execution

Upon User approval, pipe the execution plan JSON to the decomposition script in `execute` mode via Bash:

```bash
echo '<plan-json>' | python .claude/skills/decompose-report/scripts/decompose.py execute <report-filename>
```

Replace `<plan-json>` with the complete JSON plan constructed in Step 3. Ensure the JSON is valid and properly escaped for the shell.

The script reads the plan from stdin, validates it (unique filenames, valid section indices, `distribute_by` present), creates the section directory, extracts sections to files with lossless content preservation, and transforms the original report into a meta file with updated frontmatter and a table of contents.

**Error handling:** If the script exits with a non-zero status, report the script's stderr output to the User and halt. The script handles its own error recovery: if section extraction fails, the section directory is cleaned up and the original report file remains unchanged. Report:
```
Error: Decomposition failed during execution.
[Include the script's stderr output]
The original report file is unchanged.
```

### Step 6: Completion

Report a summary to the User:
- How many section files were created
- The section directory path
- A reminder that `/process-prompts` will now operate on the distributed format for this report
