#!/usr/bin/env python
"""Preprocessing script for the Process Prompts Skill.

Bridges the protected dev/prompts/archive/ directory and the agent system by
scanning prompt archives, discovering report definitions, managing the
processing manifest, staging unprocessed files, and generating JSON
processing plans. Runs via Bash to bypass hook-based read protection.

Two modes of operation:
    plan        - Scan archive, compute diff against manifest, stage files,
                  and emit a JSON processing plan to stdout.
    post-process - Update the manifest with processed file-report pairs
                   and clean up the staging directory.

Key Components:
    parse_args            - CLI argument parsing for mode, staging dir, and filters
    scan_archive          - Discover .txt files in dev/prompts/archive/
    discover_reports      - Find and validate report files with YAML frontmatter,
                            read lifecycle stage, compute section directory paths
    load_manifest         - Read the processing manifest (.process-manifest.json)
    compute_diff          - Determine unprocessed files per report
    truncate_work_items   - Limit work items to first N using file-primary ordering
    stage_files           - Copy unprocessed files to staging directory
    build_plan            - Construct the JSON processing plan
    _emit_size_warnings   - Warn about oversized flat reports during plan mode
    run_plan_mode         - Orchestrate the plan workflow
    run_post_process      - Update manifest and clean staging directory
"""

import argparse
import json
import shutil
import sys
from pathlib import Path
from typing import TypedDict


# Paths relative to project root (working directory at invocation time)
ARCHIVE_DIR = Path("dev/prompts/archive")
REPORTS_DIR = Path("dev/prompts/reports")
MANIFEST_FILE = REPORTS_DIR / ".process-manifest.json"

# Required YAML frontmatter fields for valid report files
REQUIRED_FRONTMATTER_FIELDS = {"title", "description", "integration"}

# Flat reports exceeding this size trigger an advisory decomposition warning
SIZE_WARNING_THRESHOLD_BYTES = 110 * 1024  # 110KB

# Approximate bytes per token for estimating token counts in warnings
BYTES_PER_TOKEN = 4700


class FileEntry(TypedDict):
    """A single file processing entry in the processing plan.

    Attributes:
        staged_path: Absolute path to the staged copy of the prompt file.
            Empty string before staging occurs.
        original_name: Original filename of the prompt file in the archive.
        target_reports: List of report file paths this prompt file should
            be processed against.
    """

    staged_path: str
    original_name: str
    target_reports: list[str]


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments for preprocessing modes.

    Args:
        argv: Argument list to parse. If None, uses sys.argv[1:].

    Returns:
        Parsed namespace with mode, staging_dir, optional report filter,
        and optional limit.
    """
    parser = argparse.ArgumentParser(
        description="Preprocessing script for the Process Prompts Skill.",
    )
    parser.add_argument(
        "mode",
        choices=["plan", "post-process"],
        help="Operating mode: 'plan' to generate processing plan, "
        "'post-process' to update manifest and clean staging.",
    )
    parser.add_argument(
        "staging_dir",
        type=Path,
        help="Path to the staging directory for prompt files.",
    )
    parser.add_argument(
        "--report",
        type=str,
        default=None,
        help="Restrict processing to a single named report file.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Truncate the processing queue to the first N work items.",
    )
    return parser.parse_args(argv)


def parse_yaml_frontmatter(file_path: Path) -> dict[str, str] | None:
    """Parse YAML frontmatter from a markdown file.

    Extracts key-value pairs from the YAML block delimited by '---' markers
    at the beginning of the file. Supports multi-line values using YAML
    folded (>) and literal (|) scalar indicators.

    Args:
        file_path: Path to the markdown file with YAML frontmatter.

    Returns:
        Dictionary of frontmatter fields, or None if no valid frontmatter
        block is found.
    """
    with file_path.open(encoding="utf-8") as f:
        content = f.read()

    lines = content.split("\n")

    # Must start with '---'
    if not lines or lines[0].strip() != "---":
        return None

    # Find the closing '---'
    end_index = None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end_index = i
            break

    if end_index is None:
        return None

    frontmatter: dict[str, str] = {}
    current_key: str | None = None
    current_value_lines: list[str] = []
    is_multiline = False

    for line in lines[1:end_index]:
        # Check for a new key-value pair (non-indented line with colon)
        if not line.startswith(" ") and not line.startswith("\t") and ":" in line:
            # Save the previous key if any
            if current_key is not None:
                frontmatter[current_key] = _join_multiline_value(current_value_lines)

            colon_pos = line.index(":")
            current_key = line[:colon_pos].strip()
            raw_value = line[colon_pos + 1 :].strip()

            # Check for multiline indicators
            if raw_value in (">", "|"):
                is_multiline = True
                current_value_lines = []
            else:
                is_multiline = False
                current_value_lines = [raw_value]
        elif is_multiline and current_key is not None:
            # Continuation of a multiline value
            current_value_lines.append(line.strip())

    # Save the last key
    if current_key is not None:
        frontmatter[current_key] = _join_multiline_value(current_value_lines)

    return frontmatter


def _join_multiline_value(lines: list[str]) -> str:
    """Join multiline YAML value lines into a single string.

    Filters out empty lines and joins with spaces (folded scalar behavior).

    Args:
        lines: List of stripped value lines.

    Returns:
        Joined string value.
    """
    return " ".join(line for line in lines if line)


def scan_archive() -> list[str]:
    """Scan the prompt archive directory for .txt files.

    Returns:
        Sorted list of .txt filenames found in dev/prompts/archive/.
        Returns empty list if the archive directory does not exist.
    """
    if not ARCHIVE_DIR.exists():
        return []

    return sorted(f.name for f in ARCHIVE_DIR.iterdir() if f.is_file() and f.suffix == ".txt")


def discover_reports(report_filter: str | None = None) -> tuple[list[dict[str, str]], list[str]]:
    """Discover and validate report files in the reports directory.

    Scans dev/prompts/reports/ for .md files, parses their YAML frontmatter,
    and validates that required fields (title, description, integration) are
    present. Reads the ``stage`` field to identify distributed reports and
    computes the section directory path for them.

    Args:
        report_filter: If provided, restrict discovery to this single report
            filename. Other reports are excluded from results.

    Returns:
        Tuple of (valid_reports, warnings) where:
            valid_reports: List of dicts with 'file' (relative path),
                'title', and 'stage' keys for reports with valid frontmatter.
                Distributed reports also include a 'section_directory' key
                containing the relative path to the section files directory.
            warnings: List of warning messages for invalid report files.
    """
    valid_reports: list[dict[str, str]] = []
    warnings: list[str] = []

    if not REPORTS_DIR.exists():
        return valid_reports, warnings

    report_files = sorted(f for f in REPORTS_DIR.iterdir() if f.is_file() and f.suffix == ".md")

    for report_path in report_files:
        filename = report_path.name

        # Apply report filter if specified
        if report_filter is not None and filename != report_filter:
            continue

        frontmatter = parse_yaml_frontmatter(report_path)

        if frontmatter is None:
            warnings.append(
                f"Warning: Report file '{REPORTS_DIR / filename}' has no YAML frontmatter. "
                f"Skipping this report."
            )
            continue

        # Check for required fields
        missing_fields = REQUIRED_FRONTMATTER_FIELDS - set(frontmatter.keys())
        if missing_fields:
            for field in sorted(missing_fields):
                warnings.append(
                    f"Warning: Report file '{REPORTS_DIR / filename}' is missing required "
                    f"frontmatter field '{field}'. Skipping this report."
                )
            continue

        stage = frontmatter.get("stage", "")

        report_entry: dict[str, str] = {
            "file": str(REPORTS_DIR / filename),
            "title": frontmatter["title"],
            "stage": stage,
        }

        if stage == "distributed":
            report_entry["section_directory"] = str(REPORTS_DIR / report_path.stem) + "/"

        valid_reports.append(report_entry)

    return valid_reports, warnings


def load_manifest() -> dict[str, list[str]]:
    """Load the processing manifest from disk.

    Reads .process-manifest.json from the reports directory. If the file
    does not exist, returns an empty dict (fresh start). If the file
    contains invalid JSON, halts with an error.

    Returns:
        Dictionary mapping report filenames to lists of processed prompt
        filenames.

    Raises:
        SystemExit: If the manifest file exists but contains invalid JSON.
    """
    if not MANIFEST_FILE.exists():
        return {}

    try:
        with MANIFEST_FILE.open(encoding="utf-8") as f:
            manifest = json.load(f)
    except json.JSONDecodeError as e:
        print(
            f"Error: Cannot read manifest file '{MANIFEST_FILE}': invalid JSON\n"
            f"Details: {e}\n"
            f"Please verify the manifest file is valid JSON or delete it to start fresh.",
            file=sys.stderr,
        )
        sys.exit(1)

    if not isinstance(manifest, dict):
        print(
            f"Error: Manifest file '{MANIFEST_FILE}' has unexpected format. "
            f"Expected a JSON object.\n"
            f"Please verify the manifest file or delete it to start fresh.",
            file=sys.stderr,
        )
        sys.exit(1)

    return manifest


def compute_diff(
    archive_files: list[str],
    valid_reports: list[dict[str, str]],
    manifest: dict[str, list[str]],
) -> list[FileEntry]:
    """Compute which prompt files need processing for which reports.

    For each report, determines which archive files have not yet been
    processed by comparing the archive file list against manifest entries.

    Args:
        archive_files: List of all .txt filenames in the archive.
        valid_reports: List of valid report dicts with 'file' and 'title'.
        manifest: Current processing manifest mapping report filenames
            to lists of already-processed prompt filenames.

    Returns:
        List of file processing entries, each with 'staged_path' (to be
        filled during staging), 'original_name', and 'target_reports'.
    """
    # Build a map of which files need processing for which reports
    file_to_reports: dict[str, list[str]] = {}

    for report in valid_reports:
        report_filename = Path(report["file"]).name
        processed_for_report = set(manifest.get(report_filename, []))

        for archive_file in archive_files:
            if archive_file not in processed_for_report:
                if archive_file not in file_to_reports:
                    file_to_reports[archive_file] = []
                file_to_reports[archive_file].append(report["file"])

    # Convert to list sorted by filename
    files_to_process: list[FileEntry] = []
    for filename in sorted(file_to_reports.keys()):
        files_to_process.append(
            FileEntry(
                staged_path="",
                original_name=filename,
                target_reports=file_to_reports[filename],
            )
        )

    return files_to_process


def truncate_work_items(
    file_entries: list[FileEntry],
    limit: int | None,
) -> tuple[list[FileEntry], int]:
    """Truncate work items to the specified limit using file-primary ordering.

    Flattens file entries to individual (prompt-file, report) pairings ordered
    chronologically by prompt filename (all reports for a given file before
    moving to the next file), takes the first N entries, and re-groups into
    FileEntry objects with potentially reduced target_reports per entry.

    Args:
        file_entries: List of FileEntry objects from compute_diff().
        limit: Maximum number of work items to retain. None means no limit.

    Returns:
        Tuple of (truncated_entries, total_work_items) where:
            truncated_entries: List of FileEntry objects containing at most
                ``limit`` work items.
            total_work_items: Total count of work items before truncation.
    """
    # Count total work items (each file-report pairing is one work item)
    total_work_items = sum(len(entry["target_reports"]) for entry in file_entries)

    if limit is None or limit >= total_work_items:
        return file_entries, total_work_items

    # Flatten to individual (file, report) pairings in file-primary order
    pairings: list[tuple[str, str]] = []
    for entry in file_entries:
        for report_path in entry["target_reports"]:
            pairings.append((entry["original_name"], report_path))

    # Take the first N pairings
    truncated_pairings = pairings[:limit]

    # Re-group into FileEntry objects preserving chronological file order
    grouped: dict[str, list[str]] = {}
    insertion_order: list[str] = []
    for filename, report_path in truncated_pairings:
        if filename not in grouped:
            grouped[filename] = []
            insertion_order.append(filename)
        grouped[filename].append(report_path)

    truncated_entries: list[FileEntry] = []
    for filename in insertion_order:
        truncated_entries.append(
            FileEntry(
                staged_path="",
                original_name=filename,
                target_reports=grouped[filename],
            )
        )

    return truncated_entries, total_work_items


def stage_files(
    files_to_process: list[FileEntry],
    staging_dir: Path,
) -> list[FileEntry]:
    """Copy unprocessed prompt files to the staging directory.

    Creates the staging directory if it does not exist, then copies each
    file from the archive to the staging directory. Updates the staged_path
    field in each entry.

    Args:
        files_to_process: List of file entries to stage. Each entry is
            modified in-place with the staged_path field set.
        staging_dir: Path to the staging directory.

    Returns:
        The updated files_to_process list with staged_path fields populated.

    Raises:
        SystemExit: If a source file cannot be found or copied.
    """
    staging_dir.mkdir(parents=True, exist_ok=True)

    for entry in files_to_process:
        original_name = str(entry["original_name"])
        source_path = ARCHIVE_DIR / original_name
        dest_path = staging_dir / original_name

        if not source_path.exists():
            print(
                f"Error: Archive file '{source_path}' not found during staging.",
                file=sys.stderr,
            )
            sys.exit(1)

        shutil.copy2(str(source_path), str(dest_path))
        entry["staged_path"] = str(dest_path)

    return files_to_process


def build_plan(
    staging_dir: Path,
    valid_reports: list[dict[str, str]],
    files_to_process: list[FileEntry],
    total_prompt_files: int,
    total_work_items: int,
    work_items_limited: bool,
    limit_applied: int | None,
) -> dict[str, object]:
    """Construct the JSON processing plan.

    Args:
        staging_dir: Path to the staging directory.
        valid_reports: List of valid report dicts with 'file' and 'title'.
        files_to_process: List of file entries with staging info.
        total_prompt_files: Total number of .txt files in the archive.
        total_work_items: Count of work items before any truncation.
        work_items_limited: Whether truncation was applied to the work items.
        limit_applied: The limit value that caused truncation, or None when
            no limit was specified or the limit did not cause truncation.

    Returns:
        Complete processing plan dictionary ready for JSON serialization.
    """
    # Determine unique target reports
    targeted_reports: set[str] = set()
    for entry in files_to_process:
        for report_path in entry["target_reports"]:
            targeted_reports.add(str(report_path))

    nothing_to_do = len(files_to_process) == 0

    return {
        "staging_dir": str(staging_dir),
        "reports": valid_reports,
        "files_to_process": files_to_process,
        "summary": {
            "total_prompt_files": total_prompt_files,
            "files_to_process": len(files_to_process),
            "total_work_items": total_work_items,
            "work_items_limited": work_items_limited,
            "limit_applied": limit_applied,
            "reports_targeted": len(targeted_reports),
            "nothing_to_do": nothing_to_do,
        },
    }


def _emit_size_warnings(valid_reports: list[dict[str, str]]) -> None:
    """Emit advisory warnings for flat reports exceeding the size threshold.

    Checks each flat report's file size and prints a warning to stderr if it
    exceeds SIZE_WARNING_THRESHOLD_BYTES (110KB), suggesting decomposition
    with ``/decompose-report``.

    Args:
        valid_reports: List of valid report dicts from discover_reports().
    """
    for report in valid_reports:
        if report.get("stage", "") == "distributed":
            continue

        report_path = Path(report["file"])
        if not report_path.exists():
            continue

        file_size = report_path.stat().st_size
        if file_size > SIZE_WARNING_THRESHOLD_BYTES:
            size_kb = round(file_size / 1024)
            est_tokens_k = round(file_size / BYTES_PER_TOKEN)
            print(
                f"Warning: Report '{report_path.name}' is {size_kb}KB "
                f"(estimated ~{est_tokens_k}k tokens).\n"
                f"Consider decomposing this report with /decompose-report.",
                file=sys.stderr,
            )


def run_plan_mode(
    staging_dir: Path,
    report_filter: str | None = None,
    limit: int | None = None,
) -> None:
    """Execute the plan mode workflow.

    Scans the archive, discovers reports, loads the manifest, computes the
    diff, applies work item truncation if limited, stages unprocessed files,
    and prints the JSON processing plan to stdout. Warnings about invalid
    reports and oversized flat reports are printed to stderr.

    Args:
        staging_dir: Path to the staging directory for file copies.
        report_filter: If provided, restrict processing to this report.
        limit: If provided, truncate the processing queue to the first N
            work items. None means no limit.
    """
    archive_files = scan_archive()
    valid_reports, warnings = discover_reports(report_filter)
    manifest = load_manifest()
    files_to_process = compute_diff(archive_files, valid_reports, manifest)

    # Apply work item truncation
    files_to_process, total_work_items = truncate_work_items(files_to_process, limit)
    work_items_limited = limit is not None and limit < total_work_items
    limit_applied = limit if work_items_limited else None

    # Only stage files if there are files to process
    if files_to_process:
        stage_files(files_to_process, staging_dir)

    plan = build_plan(
        staging_dir,
        valid_reports,
        files_to_process,
        len(archive_files),
        total_work_items,
        work_items_limited,
        limit_applied,
    )

    # Print warnings to stderr
    for warning in warnings:
        print(warning, file=sys.stderr)

    # Emit size warnings for oversized flat reports
    _emit_size_warnings(valid_reports)

    # Print plan to stdout as JSON
    print(json.dumps(plan, indent=2))


def run_post_process(
    staging_dir: Path,
    report_filter: str | None = None,
    limit: int | None = None,
) -> None:
    """Execute the post-process mode workflow.

    Recomputes the processing plan (with the same truncation if limited) to
    determine which file-report pairs were processed, updates the manifest
    accordingly, and cleans up the staging directory.

    Args:
        staging_dir: Path to the staging directory to clean up.
        report_filter: If provided, restrict manifest updates to this report.
        limit: If provided, apply the same truncation as plan mode so only
            the truncated subset of pairings is recorded. None means no limit.
    """
    archive_files = scan_archive()
    valid_reports, _ = discover_reports(report_filter)
    manifest = load_manifest()
    files_to_process = compute_diff(archive_files, valid_reports, manifest)

    # Apply the same truncation as plan mode
    files_to_process, _ = truncate_work_items(files_to_process, limit)

    # Update manifest with processed file-report pairs
    for entry in files_to_process:
        original_name = str(entry["original_name"])
        for report_path in entry["target_reports"]:
            report_filename = Path(str(report_path)).name
            if report_filename not in manifest:
                manifest[report_filename] = []
            if original_name not in manifest[report_filename]:
                manifest[report_filename].append(original_name)

    # Write updated manifest
    with MANIFEST_FILE.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")

    # Clean up staging directory
    if staging_dir.exists():
        shutil.rmtree(str(staging_dir))


def main() -> None:
    """Entry point for the preprocessing script."""
    args = parse_args()

    if args.mode == "plan":
        run_plan_mode(args.staging_dir, args.report, args.limit)
    elif args.mode == "post-process":
        run_post_process(args.staging_dir, args.report, args.limit)


if __name__ == "__main__":
    main()
