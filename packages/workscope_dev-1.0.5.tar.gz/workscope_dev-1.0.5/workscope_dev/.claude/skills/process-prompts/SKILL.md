---
name: process-prompts
description: Incrementally analyzes prompt archives against user-defined report templates, extracting domain-specific insights and integrating them into persistent report files. Use when processing prompt logs for project intelligence extraction.
argument-hint: [optional-report-name] [--limit N] [--dry-run]
disable-model-invocation: true
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, Task
---

# Process Prompts

Incrementally analyze prompt archives against user-defined report templates, extracting domain-specific insights and integrating them directly into persistent report files. The preprocessing script handles all deterministic work (archive scanning, manifest management, file staging); the prompt-analyzer agent handles all semantic work (extraction, cross-referencing, integration).

## Invocation

```
/process-prompts [optional-report-name] [--limit N] [--dry-run]
```

The optional report name argument restricts processing to a single report file. The `--limit N` flag truncates the processing queue to the first N work items (prompt-report pairings), enabling controlled batch processing. The `--dry-run` flag displays the processing plan without executing it. All arguments are optional and can be combined.

Examples:
```
/process-prompts
/process-prompts Project-Timeline.md
/process-prompts --limit 10
/process-prompts --dry-run
/process-prompts Project-Timeline.md --limit 5
/process-prompts Project-Timeline.md --dry-run
```

## Workflow

Execute the following 7 steps. Do not skip steps or reorder them. All steps are sequential.

### Step 1: Invocation

Parse the arguments provided with `/process-prompts`:

- **Report name filter**: If a `.md` filename is provided, use it as the `--report` filter for the preprocessing script. This restricts processing to only the named report.
- **`--limit N` flag**: If `--limit` appears in the arguments followed by a positive integer N, truncate the processing queue to the first N work items. A "work item" is a single (prompt-file, report) pairing. Pass this value to the preprocessing script in Steps 3 and 6.

**CRITICAL — `--limit` is a script parameter, not orchestration logic.** The `--limit` flag is handled entirely by the preprocessing script. You MUST pass it as a CLI argument to the script in Steps 3 and 6. Do NOT implement limit logic yourself (e.g., by processing fewer files in Step 5 than the plan contains). The script truncates the work queue during planning (Step 3) and records only the truncated subset during post-processing (Step 6). The plan returned by the script already reflects the limit — process everything in it.

- **`--dry-run` flag**: If `--dry-run` appears anywhere in the arguments, show the processing plan without executing analyzer invocations or post-processing.

All arguments are optional and can be combined.

### Step 2: Staging Directory Setup

Generate a timestamp in `YYYYMMDD-HHMMSS` format using the system `date` command. Create a staging directory at:

```
/tmp/process-prompts-[YYYYMMDD-HHMMSS]/
```

This directory bridges the protected archive and the agent system. The preprocessing script copies prompt files here; the prompt-analyzer reads from here.

**Error handling:** If the directory cannot be created, report:
```
Error: Cannot create staging directory '/tmp/process-prompts-[timestamp]/'.
Check directory permissions and available disk space.
```
Halt. Do not proceed.

### Step 3: Preprocessing (Plan Generation)

Run the preprocessing script in `plan` mode via Bash:

```bash
python .claude/skills/process-prompts/scripts/preprocess.py plan <staging-dir> [--report <report-name>] [--limit <N>]
```

Include the `--report` flag only if the User provided a report name argument. Include the `--limit` flag only if the User provided a limit argument.

The script scans the archive, discovers reports, loads the manifest, computes which files need processing, stages unprocessed files into the staging directory, and outputs a JSON processing plan to stdout. Capture and parse this JSON output.

**Error handling:** If the preprocessing script exits with a non-zero status or produces invalid JSON, report:
```
Error: Preprocessing script failed during plan generation.
[Include the script's stderr output if available]
Staging directory preserved at: [staging-dir]
```
Halt. Do not proceed.

If the script outputs warnings to stderr (e.g., about report files with invalid frontmatter), include these warnings in your report to the User.

### Step 4: Plan Evaluation

Evaluate the processing plan returned by the preprocessing script:

**Limit validation** (perform first if `--limit N` was specified): If `summary.total_work_items` exceeds N but `summary.work_items_limited` is `false`, the `--limit` flag was not passed to the script in Step 3. Report:
```
Error: Plan does not reflect --limit N. The preprocessing script returned
[summary.total_work_items] work items without truncation, indicating --limit
was not included in the Step 3 command. Re-run from Step 3 with --limit in
the command arguments.
```
Clean up the staging directory and halt. Do not proceed.

1. **Nothing to do**: If `summary.nothing_to_do` is `true`, report to the User:
   ```
   All prompt files have already been processed for all targeted reports. Nothing to do.
   ```
   Clean up the staging directory and stop. Do not proceed to further steps.

2. **Dry run**: If the User specified `--dry-run`, present the plan summary to the User:
   - Total prompt files in archive: `summary.total_prompt_files`
   - Files to process: `summary.files_to_process`
   - Reports targeted: `summary.reports_targeted`
   - List each file and its target reports
   - If `summary.work_items_limited` is `true`: how many total work items remain (`summary.total_work_items`) and that processing is limited to `summary.limit_applied` work items

   Clean up the staging directory and stop. Do not proceed to further steps.

3. **Normal execution**: Present a brief summary to the User showing how many files will be processed for how many reports. When `summary.work_items_limited` is `true`, include in the summary that processing is limited to the first `summary.limit_applied` work items out of `summary.total_work_items` total available. Then proceed to Step 5.

### Step 5: Sequential Analyzer Invocation

Build a section directory map from the plan's `reports` array: for each report entry that has `stage` equal to `"distributed"`, record its `file` path and `section_directory` path. This map is used below when providing context to the prompt-analyzer.

For each file in the `files_to_process` array from the processing plan, invoke the prompt-analyzer agent via the Task tool:

- **Agent**: `prompt-analyzer` (use `subagent_type` or reference `.claude/agents/prompt-analyzer.md`)
- **Provide**: The staged prompt file path (`staged_path`) and the list of target report file paths (`target_reports`) for this file. For any target report that appears in the section directory map (i.e., it is a distributed report), also provide its section directory path so the prompt-analyzer knows to read section files rather than the meta file body.

**CRITICAL — Sequential execution required.** Invoke one prompt-analyzer at a time. Wait for each invocation to complete before starting the next. Multiple analyzers writing to the same report files concurrently would create conflicts.

Report progress to the User after each file is processed:
```
Processed file [N] of [total]: [filename]
```

**CRITICAL — Information Barrier.** The prompt-analyzer writes findings directly to report files on disk. Its Task tool response contains ONLY a brief completion confirmation (e.g., "Processing of [filename] complete. Updated [N] reports."). There is no findings content to read or process in the Task results.

**Error handling:** If any prompt-analyzer invocation fails, halt immediately. Do NOT proceed to post-processing. Report:
```
Error: Prompt-analyzer failed processing '[filename]'.
Processed [N] of [total] files before failure.
Post-processing will NOT run. Staging directory preserved at: [staging-dir]
```
Halt. Do not proceed. The staging directory is preserved so the User can investigate. Since post-processing does not run, the manifest is not updated and no files are marked as processed. The User can re-invoke `/process-prompts` after resolving the issue — previously failed files will be included in the next plan.

### Step 6: Post-Processing

After all analyzer invocations complete successfully, run the preprocessing script in `post-process` mode via Bash:

```bash
python .claude/skills/process-prompts/scripts/preprocess.py post-process <staging-dir> [--report <report-name>] [--limit <N>]
```

Include the `--report` and `--limit` flags only if the User provided the corresponding arguments. These must match exactly what was passed in Step 3.

The script updates the manifest with the newly processed file-report pairs and cleans up the staging directory.

**Error handling:** If the post-processing script fails, report:
```
Error: Post-processing failed.
[Include the script's stderr output if available]
Report files have been updated but the manifest was not saved.
Re-running /process-prompts will re-process the same files.
```
Halt. Do not proceed. The User resolves the issue and re-invokes the skill.

### Step 7: Completion

Report a summary to the User:

- How many prompt files were processed
- Which reports were updated
- Any warnings from the preprocessing script (e.g., report files skipped due to invalid frontmatter)
- When `--limit` was applied: how many work items were processed out of the total available, and how many remain for future invocations

If no files were processed (nothing-to-do path in Step 4), confirm that all prompt files have been processed for all targeted reports.
