from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List


def aggregate(results: List[Dict[str, float]]) -> Dict[str, float]:
    if not results:
        return {}
    keys = [
        key
        for key, value in results[0].items()
        if key not in ("id", "tier", "status") and isinstance(value, (int, float))
    ]
    return {
        key: float(sum(float(row.get(key, 0.0)) for row in results) / len(results))
        for key in keys
    }


def aggregate_by_tier(results: List[Dict[str, float]]) -> Dict[str, Dict[str, float]]:
    by: Dict[str, List[Dict[str, float]]] = {}
    for row in results:
        tier = str(row.get("tier", "unknown"))
        by.setdefault(tier, []).append(row)
    return {tier: aggregate(rows) for tier, rows in by.items()}


def write_scorecard(
    path_json: Path,
    path_csv: Path,
    rows: List[Dict[str, float]],
    summary: Dict[str, Any],
    metadata: Dict[str, Any] | None = None,
) -> None:
    sorted_rows = sorted(rows, key=lambda row: (str(row.get("tier", "")), str(row.get("id", ""))))
    payload = {
        "results": sorted_rows,
        "summary": summary,
        "by_tier": aggregate_by_tier(sorted_rows),
        "metadata": metadata or {},
    }
    path_json.parent.mkdir(parents=True, exist_ok=True)
    path_json.write_text(json.dumps(payload, indent=2, sort_keys=True))

    fieldnames = list(sorted_rows[0].keys()) if sorted_rows else []
    path_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(path_csv, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if fieldnames:
            writer.writeheader()
            writer.writerows(sorted_rows)


def read_scorecard(path_json: Path) -> Dict[str, Any]:
    return json.loads(path_json.read_text())


def write_scorecard_to_dir(rows: List[Dict[str, float]], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary = aggregate(rows)
    write_scorecard(out_dir / "scorecard.json", out_dir / "scorecard.csv", rows, summary)
