"""Decoding modules for DYANA."""
