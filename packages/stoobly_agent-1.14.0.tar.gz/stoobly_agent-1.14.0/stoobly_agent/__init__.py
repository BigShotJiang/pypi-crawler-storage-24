COMMAND = 'stoobly-agent'
VERSION = '1.14.0'
