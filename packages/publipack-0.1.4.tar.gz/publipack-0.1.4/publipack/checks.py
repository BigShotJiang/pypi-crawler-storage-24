import subprocess


def run_secret_scan():

    try:
        subprocess.run(["gitleaks", "detect", "--no-git"], check=True)
    except FileNotFoundError:
        print("gitleaks not installed — skipping secret scan")


import subprocess


def run_secret_scan():

    try:
        subprocess.run(["gitleaks", "detect", "--no-git"], check=True)
    except FileNotFoundError:
        print("gitleaks not installed — skipping secret scan")


def run_tests():
    """Run pytest if available. Skip if no tests are found."""
    try:
        result = subprocess.run(["pytest"], capture_output=True, text=True)
        if result.returncode == 5:
            print("No tests found — skipping test step.")
        elif result.returncode != 0:
            raise RuntimeError(f"Tests failed with exit code {result.returncode}")
        else:
            print("Tests passed successfully.")
    except FileNotFoundError:
        print("pytest not installed — skipping tests.")
