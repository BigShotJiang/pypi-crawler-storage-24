from setuptools import setup
setup(name='privaton-beacon-img-66bafbfd9399d52a-png', version='774.489.244', py_modules=['data'])
