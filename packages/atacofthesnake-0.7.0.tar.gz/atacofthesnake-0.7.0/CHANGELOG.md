# Changelog

## [0.7.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.6.0...v0.7.0) (2026-03-26)


### Features

* axline in MAplot ([#58](https://github.com/maxplanck-ie/ATACofthesnake/issues/58)) ([8cb8f4d](https://github.com/maxplanck-ie/ATACofthesnake/commit/8cb8f4d161986c85745dd68ded487cfc9929ecd0))
* downstream motif analysis ([#62](https://github.com/maxplanck-ie/ATACofthesnake/issues/62)) ([98865a4](https://github.com/maxplanck-ie/ATACofthesnake/commit/98865a42a80976dccfcef32676d6efe481568fca))
* enrichment plots per surviving (sigpeaks / FDR) comparison ([98865a4](https://github.com/maxplanck-ie/ATACofthesnake/commit/98865a42a80976dccfcef32676d6efe481568fca))
* GP postprocessing for both plain and int test mode ([85a5a58](https://github.com/maxplanck-ie/ATACofthesnake/commit/85a5a58bd39e3238ff2924b3161338c850e1187f))
* gp time * covar interaction testing ([85a5a58](https://github.com/maxplanck-ie/ATACofthesnake/commit/85a5a58bd39e3238ff2924b3161338c850e1187f))
* label simplification on heatmap ([8cb8f4d](https://github.com/maxplanck-ie/ATACofthesnake/commit/8cb8f4d161986c85745dd68ded487cfc9929ecd0))
* no dashes allowed in filenames ([#56](https://github.com/maxplanck-ie/ATACofthesnake/issues/56)) ([d400253](https://github.com/maxplanck-ie/ATACofthesnake/commit/d400253c52f2ba4c259676991172ddb6f41a1611))
* peak-K connections for LRT and GP when relevant ([85a5a58](https://github.com/maxplanck-ie/ATACofthesnake/commit/85a5a58bd39e3238ff2924b3161338c850e1187f))
* sigres file aggregation through checkpoint ([98865a4](https://github.com/maxplanck-ie/ATACofthesnake/commit/98865a42a80976dccfcef32676d6efe481568fca))
* validate design ([#59](https://github.com/maxplanck-ie/ATACofthesnake/issues/59)) ([68481a1](https://github.com/maxplanck-ie/ATACofthesnake/commit/68481a1d548339b91ea1578560cf022f4440554b))


### Bug Fixes

* cutoff in twogroup properly set ([98865a4](https://github.com/maxplanck-ie/ATACofthesnake/commit/98865a42a80976dccfcef32676d6efe481568fca))
* tiny runtime bugfix in sigres collation ([98865a4](https://github.com/maxplanck-ie/ATACofthesnake/commit/98865a42a80976dccfcef32676d6efe481568fca))


### Documentation

* part on ame in usage ([98865a4](https://github.com/maxplanck-ie/ATACofthesnake/commit/98865a42a80976dccfcef32676d6efe481568fca))
* usage for interaction gp explained ([85a5a58](https://github.com/maxplanck-ie/ATACofthesnake/commit/85a5a58bd39e3238ff2924b3161338c850e1187f))

## [0.6.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.5.0...v0.6.0) (2026-02-26)


### Features

* parametrize cutoffs, lfs, FDR, permutation FDR and number of permutations ([a09be5a](https://github.com/maxplanck-ie/ATACofthesnake/commit/a09be5ab2324c89e5699e509c38b8db324e5271e))
* properly deal with no survivors in gp mode ([a09be5a](https://github.com/maxplanck-ie/ATACofthesnake/commit/a09be5ab2324c89e5699e509c38b8db324e5271e))
* type check on numeric arguments ([a09be5a](https://github.com/maxplanck-ie/ATACofthesnake/commit/a09be5ab2324c89e5699e509c38b8db324e5271e))


### Documentation

* example illustration ([#53](https://github.com/maxplanck-ie/ATACofthesnake/issues/53)) ([a09be5a](https://github.com/maxplanck-ie/ATACofthesnake/commit/a09be5ab2324c89e5699e509c38b8db324e5271e))

## [0.5.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.4.0...v0.5.0) (2026-02-21)


### Features

* comparison validation over three subtypes ([46ed43c](https://github.com/maxplanck-ie/ATACofthesnake/commit/46ed43ca4e66ad271bac299ed45e0468e9959fa9))
* gaussian process for timecourse data ([c405bc3](https://github.com/maxplanck-ie/ATACofthesnake/commit/c405bc35976695d371494d0515cb7208c9f33c8d))
* Kmeans under twogroup and LRT are shifted to python ([c405bc3](https://github.com/maxplanck-ie/ATACofthesnake/commit/c405bc35976695d371494d0515cb7208c9f33c8d))
* LRT mode ([#48](https://github.com/maxplanck-ie/ATACofthesnake/issues/48)) ([c405bc3](https://github.com/maxplanck-ie/ATACofthesnake/commit/c405bc35976695d371494d0515cb7208c9f33c8d))
* ordinal GP ([#49](https://github.com/maxplanck-ie/ATACofthesnake/issues/49)) ([46ed43c](https://github.com/maxplanck-ie/ATACofthesnake/commit/46ed43ca4e66ad271bac299ed45e0468e9959fa9))
* twogroup contrasts inferred over balanced dummy samplesheet ([390c69c](https://github.com/maxplanck-ie/ATACofthesnake/commit/390c69c9e80b8d41a395ded951f5504ffd4e097a))
* twogroup, LRT, timecourse ([#44](https://github.com/maxplanck-ie/ATACofthesnake/issues/44)) ([390c69c](https://github.com/maxplanck-ie/ATACofthesnake/commit/390c69c9e80b8d41a395ded951f5504ffd4e097a))


### Documentation

* rtd initiated ([390c69c](https://github.com/maxplanck-ie/ATACofthesnake/commit/390c69c9e80b8d41a395ded951f5504ffd4e097a))
* usage on three comparison types ([46ed43c](https://github.com/maxplanck-ie/ATACofthesnake/commit/46ed43ca4e66ad271bac299ed45e0468e9959fa9))

## [0.4.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.3.0...v0.4.0) (2026-02-11)


### Features

* functionality to download example data ([#42](https://github.com/maxplanck-ie/ATACofthesnake/issues/42)) ([1be0228](https://github.com/maxplanck-ie/ATACofthesnake/commit/1be0228eca56e23a8045750c0f82bb825cea3a5a))
* handle both cram and bam files ([1be0228](https://github.com/maxplanck-ie/ATACofthesnake/commit/1be0228eca56e23a8045750c0f82bb825cea3a5a))

## [0.3.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.2.0...v0.3.0) (2026-02-09)


### Features

* validate sample presence in samplesheet ([#40](https://github.com/maxplanck-ie/ATACofthesnake/issues/40)) ([f68dd85](https://github.com/maxplanck-ie/ATACofthesnake/commit/f68dd859564af5ad157466a71b50472799b5f170))

## [0.2.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.1.0...v0.2.0) (2026-02-08)


### Features

* scm for versioning ([a5f5575](https://github.com/maxplanck-ie/ATACofthesnake/commit/a5f5575741713571c033b6555d37afa9ce645e82))

## [0.1.0](https://github.com/maxplanck-ie/ATACofthesnake/compare/v0.0.1...v0.1.0) (2026-02-08)


### Features

* drop conda ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
* logger ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
* release rework ([#34](https://github.com/maxplanck-ie/ATACofthesnake/issues/34)) ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
* smk_profile optional ([4de9382](https://github.com/maxplanck-ie/ATACofthesnake/commit/4de9382221b06cd959c68b68c7d318e7f65a31d3))
