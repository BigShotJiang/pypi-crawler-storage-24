# MyPlot

A uniform plotting module for matplotlib with automatic font detection and cross-platform support.

## Features

- **Uniform Formatting**: Consistent plot styling across all your projects
- **Automatic Font Detection**: Finds and configures Source Han Serif font for Chinese characters
- **Cross-Platform Support**: Works on Windows, macOS, and Linux
- **Easy to Use**: Simple decorator interface for creating publication-quality plots
- **Built-in Utilities**: Radian/degree formatters and other plotting utilities

## Installation

```bash
pip install -e .
# Using uv
uv add myplot
```

## Quick Start

```python
import myplot
import numpy as np

@myplot.myplot(figsize=(8, 6))
def simple_plot():
    x = np.linspace(0, 10, 100)
    plt.plot(x, np.sin(x), label='正弦波')
    plt.xlabel('x (弧度)')
    plt.ylabel('sin(x)')
    plt.title('正弦函数图')
    plt.legend()

simple_plot()
```

## Font Detection Logic

MyPlot automatically searches for Source Han Serif fonts using an optimized strategy:

1. **Registry Check**: First checks matplotlib's font registry (fastest)
2. **System Search**: Searches system fonts by checking properties
3. **Project Search**: Falls back to project directories if needed

This optimized approach significantly speeds up initialization while maintaining compatibility.

**Search Paths**:
- Windows: `C:/Windows/Fonts`, `%LOCALAPPDATA%/Microsoft/Windows/Fonts`
- macOS: `/System/Library/Fonts`, `/Library/Fonts`, `~/Library/Fonts`
- Linux: `/usr/share/fonts/*`, `~/.local/share/fonts`
- Project: `./fonts/`, `./resources/fonts/`, `./src/fonts/`

If no font is found, it falls back to matplotlib's default settings.

## API

### myplot Decorator

```python
@myplot.myplot(
    figsize=(4.8, 3.6),  # Figure size
    save=True,           # Save automatically
    log=True,            # Log creation
    savename='plot',     # Custom filename
    config_dir='./config'  # Custom config dir
)
def plot():
    plt.plot(x, y)
```

### myUtilities

```python
# Radian formatter (e.g., 0.5π)
formatter = myplot.myUtilities.radFormatter()

# Degree formatter (e.g., 90°)
formatter = myplot.myUtilities.degFormatter()
```

### myparams

```python
params = myplot.myparams()
params.put('width', 800)
params['theme'] = 'dark'
```

## Requirements

- Python 3.8+
- matplotlib >= 3.5.0
- numpy >= 1.20.0

## License

MIT License