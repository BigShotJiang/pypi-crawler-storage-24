"""
MyPlot - A uniform plotting module for matplotlib with proper font handling.

This module provides decorators and utilities for creating publication-quality plots
with consistent formatting and automatic font detection.

Features:
- @myplot decorator for consistent plot styling
- Automatic Source Han Serif font detection for Chinese characters
- Cross-platform support (Windows, macOS, Linux)
- Built-in utilities for radian/degree formatters
- Automatic plot saving capabilities
- Parameter management system with JSON storage

Font Detection Logic:
The module automatically searches for Source Han Serif fonts using an optimized strategy:
1. Checks matplotlib's font registry (fastest)
2. Searches system fonts by loading and checking properties
3. Falls back to direct file search in project directories (slowest)
4. Uses default matplotlib settings if no font is found

Supported Platforms:
- Windows: C:/Windows/Fonts, %LOCALAPPDATA%/Microsoft/Windows/Fonts
- macOS: /System/Library/Fonts, /Library/Fonts, ~/Library/Fonts
- Linux: /usr/sharefonts/*, ~/.local/share/fonts
"""

import platform
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import matplotlib.ticker as ticker
import numpy as np
import functools
import sys
import builtins
from pathlib import Path
import json
import os

__version__ = "0.1.1"

__all__ = ['myplot', 'plt', 'np', 'myparams', 'myUtilities']


class myparams:
    """
    Configuration parameter manager with JSON storage.

    A class for managing configuration parameters that persist between sessions.
    Parameters are stored in a JSON file with platform-specific directory support.

    The configuration directory is determined by the platform:
    - Windows: %LOCALAPP%/Local/myplot/
    - macOS: ~/Library/Application Support/myplot/
    - Linux: ~/.config/myplot/

    Usage:
        >>> params = myparams()
        >>> params.put('theme', 'dark')
        >>> value = params.get('theme')
        >>> params['width'] = 800
        >>> del params['temp_setting']
    """

    def __init__(self, file="myplot_params.json", config_dir=None):
        if config_dir:
            config_path = Path(config_dir)
        else:
            # Use platform-specific configuration directories
            if platform.system() == 'Windows':
                config_path = Path.home() / 'AppData' / 'Local' / 'myplot'
            elif platform.system() == 'Darwin':  # macOS
                config_path = Path.home() / 'Library' / 'Application Support' / 'myplot'
            else:  # Linux and other Unix-like systems
                config_path = Path.home() / '.config' / 'myplot'

        self.f = config_path / file
        self.f.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(self.f, 'r') as ff:
                self.p = json.load(ff)
        except (FileNotFoundError, json.JSONDecodeError):
            self.p = {}

    def get(self, key):
        return self.p.get(key)

    def put(self, arg: dict = None, **kwargs):
        d = (arg or {}) | (kwargs or {})
        for k in d:
            self.p[k] = d[k]
        self.update()

    def update(self):
        with open(self.f, 'w') as ff:
            json.dump(self.p, ff, indent=4)

    def __getitem__(self, key):
        return self.get(key)

    def __setitem__(self, key, value):
        self.put({key: value})

    def __delitem__(self, key):
        if key in self.p:
            del self.p[key]
            self.update()

    def __contains__(self, key):
        return key in self.p


def get_font_search_paths():
    """
    Get platform-specific font search paths.

    Returns a list of directories to search for fonts, including:
    - System font directories (platform-specific)
    - User font directories
    - Project-local font directories

    Returns:
        list[Path]: List of font search paths
    """
    system = platform.system()
    paths = []

    # Add system font paths
    if system == 'Windows':
        system_font_dirs = [
            Path('C:/Windows/Fonts'),
            Path('C:/Windows/Fonts/simhei'),  # Chinese fonts
        ]
        if 'LOCALAPPDATA' in os.environ:
            user_font_dir = Path(os.environ['LOCALAPPDATA']) / 'Microsoft' / 'Windows' / 'Fonts'
            if user_font_dir.exists():
                paths.append(user_font_dir)

    elif system == 'Darwin':  # macOS
        system_font_dirs = [
            Path('/System/Library/Fonts'),
            Path('/System/Library/Fonts/ChineseSimplified'),
            Path('/Library/Fonts'),
            Path('/Library/Fonts/ChineseSimplified'),
        ]
        user_font_dir = Path.home() / 'Library' / 'Fonts'
        if user_font_dir.exists():
            paths.append(user_font_dir)
    else:  # Linux
        system_font_dirs = [
            Path('/usr/share/fonts'),
            Path('/usr/share/fonts/truetype'),
            Path('/usr/share/fonts/opentype'),
            Path('/usr/share/fonts/truetype/freefont'),
            Path('/usr/share/fonts/opentype/noto'),
        ]
        user_font_dir = Path.home() / '.local' / 'share' / 'fonts'
        if user_font_dir.exists():
            paths.append(user_font_dir)

    # Add existing system font directories
    for font_dir in system_font_dirs:
        if font_dir.exists():
            paths.append(font_dir)

    # Add current directory and relative paths (for local font files)
    current_dir = Path.cwd()
    paths.extend([
        current_dir,
        current_dir / 'fonts',
        current_dir / 'resources' / 'fonts',
        current_dir / 'src' / 'fonts',
    ])

    return paths


def find_source_han_serif_font():
    """
    Find Source Han Serif font with optimized search strategy.

    This function implements a fast, optimized font search strategy:
    1. Check matplotlib's cached font registry (fastest)
    2. Search system fonts using font properties
    3. Fall back to direct file search only if needed

    Font variants searched include:
    - SourceHanSerifSC-Medium.otf
    - SourceHanSerif-Medium.otf
    - SourceHanSerifSC-Regular.otf
    - SourceHanSerif-Regular.otf
    - SourceHanSerif-Heavy.otf
    - NotoSerifCJK variants (as alternatives)

    Returns:
        Path or None: Path to the font file if found, None otherwise
    """
    font_names_variants = [
        'SourceHanSerifSC-Medium.otf',
        'SourceHanSerif-Medium.otf',
        'SourceHanSerifSC-Regular.otf',
        'SourceHanSerif-Regular.otf',
        'SourceHanSerif-Heavy.otf',
        'NotoSerifCJK-Regular.otf',  # Alternative
        'NotoSerifCJK-Medium.otf',   # Alternative
        'NotoSerifCJK-SC-Regular.otf',
        'NotoSerifCJK-TC-Regular.otf'
    ]

    # Fast path: Check matplotlib's font registry first
    print("Checking matplotlib's font registry...")
    try:
        # Get all registered font names
        font_manager = fm.fontManager
        registered_fonts = font_manager.get_font_names()

        # Look for matching font families
        for family in registered_fonts:
            family_lower = family.lower()
            if ('source' in family_lower and 'serif' in family_lower):
                print(f"Found registered font family: {family}")

                # Use matplotlib's findfont (without size parameter)
                font_files = font_manager.findfont(family)
                if font_files and os.path.exists(font_files):
                    font_path = Path(font_files).resolve()
                    print(f"Using font file: {font_path}")
                    return font_path
    except Exception as e:
        print(f"Registry check failed: {e}")

    # Medium path: Search system fonts by loading properties
    print("\nSearching system fonts by properties...")
    try:
        # Get all system fonts
        font_list = fm.findSystemFonts()

        # Check each font for properties
        for font_file in font_list:
            try:
                # Try to load font properties
                font_obj = fm.FontProperties(fname=font_file)
                font_name = font_obj.get_name()

                # Check if it matches our criteria
                font_name_lower = font_name.lower()
                font_file_name = Path(font_file).name.lower()

                if (('source' in font_name_lower and 'serif' in font_name_lower) or
                    any(variant.lower() in font_file_name for variant in font_names_variants)):
                    font_path = Path(font_file).resolve()
                    print(f"Found matching font: {font_path}")
                    print(f"  Font name: {font_name}")
                    return font_path
            except Exception:
                # Skip fonts that can't be loaded
                continue
    except Exception as e:
        print(f"System font search failed: {e}")

    # Slow path: Direct file search (only if other methods fail)
    print("\nPerforming direct file search...")
    search_paths = get_font_search_paths()
    print(f"Searching in {len(search_paths)} paths:")

    for font_variant in font_names_variants:
        for search_path in search_paths:
            font_path = search_path / font_variant
            if font_path.exists():
                print(f"Found font file: {font_path}")
                return font_path.resolve()

    print('⚠ Cannot find Source Han Serif font, using default settings')
    return None


def setup_font_properties():
    """
    Setup matplotlib font properties if Source Han Serif is found.

    This function:
    1. Registers the font with matplotlib's font manager
    2. Sets up matplotlib rcParams for proper rendering
    3. Configures math font and minus sign handling
    4. Sets appropriate fallback font families

    The font family is determined by trying multiple possible names:
    - 'Source Han Serif'
    - 'Source Han Serif SC' (Simplified Chinese)
    - 'Source Han Serif TC' (Traditional Chinese)
    - 'Noto Serif CJK SC'
    - 'Noto Serif CJK'

    Returns:
        bool: True if font was successfully setup, False otherwise
    """
    font_path = find_source_han_serif_font()

    if font_path:
        try:
            # Force register the font
            fontManager = fm.fontManager
            fontManager.addfont(str(font_path))

            # Create font properties
            font_prop = fm.FontProperties(fname=str(font_path))
            font_name = font_prop.get_name()
            print(f"Font file found: {font_path}")
            print(f"Font name detected: {font_name}")

            # Try multiple possible family names
            possible_families = [
                'Source Han Serif',
                'Source Han Serif SC',
                'Source Han Serif TC',
                'Noto Serif CJK SC',
                'Noto Serif CJK'
            ]

            # Set matplotlib font configuration
            plt.rcParams['mathtext.fontset'] = 'stix'
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.family'] = 'sans-serif'  # fallback
            plt.rcParams['font.sans-serif'] = ['Source Han Serif'] + plt.rcParams['font.sans-serif']

            # Manually set the font for the current session
            try:
                # Try to find the correct family name from the registered font
                for family in possible_families:
                    if family in fontManager.get_font_names():
                        plt.rcParams['font.family'] = family
                        plt.rcParams['font.sans-serif'] = [family] + plt.rcParams['font.sans-serif']
                        print(f"Set font family to: {family}")
                        break
            except Exception as e:
                print(f"Note: Could not set font family explicitly: {e}")

            return True
        except Exception as e:
            print(f"Error setting up font: {e}")
            return False
    return False


# Initialize font setup
setup_successful = setup_font_properties()
myparams.font = None

# Load the font into myparams if setup was successful
if setup_successful:
    font_path = find_source_han_serif_font()
    if font_path:
        try:
            myparams.font = fm.FontProperties(fname=str(font_path))
            print("Font loaded into myparams")
        except Exception as e:
            print(f"Could not load font into myparams: {e}")

# Character size settings
plt.rcParams['font.size'] = 9
plt.rcParams['axes.titlesize'] = 11
plt.rcParams['axes.labelsize'] = 10
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['lines.linewidth'] = 1.2
plt.rcParams['lines.markersize'] = 4
plt.rcParams['errorbar.capsize'] = 3
elinewidth = 0.8


def myplot(figsize=(4.8, 3.6), save=True, log=True, savename='', config_dir=None):
    """
    Decorator for creating uniformly formatted matplotlib plots.

    Args:
        figsize: Figure size in inches (width, height)
        save: Whether to save the figure
        log: Whether to log plot creation
        savename: Filename for saved figure (defaults to function name)
        config_dir: Directory for configuration files (optional)

    Returns:
        Decorator function
    """
    def decorator(func):
        @functools.wraps(func)
        def wrap(*args, **kwargs):
            # Process keyword arguments
            recfg_list = ['figsize', 'save', 'log', 'savename', 'config_dir']
            p = {}
            for rec in recfg_list:
                if rec in kwargs:
                    p[rec] = kwargs[rec]
                    del kwargs[rec]
                else:
                    p[rec] = {
                        'figsize': figsize,
                        'save': save,
                        'log': log,
                        'savename': savename or func.__name__,
                        'config_dir': config_dir
                    }.get(rec)

            # Setup plot environment
            plt.figure(figsize=p['figsize'])
            biprint = builtins.print

            # Setup logging and save paths
            if p['log'] or p['save']:
                # Determine save directories
                if p['config_dir']:
                    base_path = Path(p['config_dir'])
                else:
                    # Use platform-specific directories
                    if platform.system() == 'Windows':
                        base_path = Path.home() / 'Documents' / 'MyPlots'
                    elif platform.system() == 'Darwin':  # macOS
                        base_path = Path.home() / 'Documents' / 'MyPlots'
                    else:  # Linux
                        base_path = Path.home() / 'Documents' / 'MyPlots'

                stats_dir = base_path / 'stats'
                imags_dir = base_path / 'images'

                stats_dir.mkdir(parents=True, exist_ok=True)
                imags_dir.mkdir(parents=True, exist_ok=True)

                if p['log'] and p['save']:
                    logpath = stats_dir / f"{p['savename']}.txt"
                    with open(logpath, 'w') as f:
                        pass
                    biprint(f"{p['savename']} created stats into path:\n{logpath.absolute()}")
                    builtins.print = myprint(logpath)(biprint)

            # Call parent function
            result = func(*args, **kwargs)

            # Cleanup
            plt.tight_layout()
            builtins.print = biprint
            if p['save']:
                pltpath = imags_dir / f"{p['savename']}.png"
                pltpath.parent.mkdir(parents=True, exist_ok=True)
                plt.savefig(pltpath, dpi=400, bbox_inches='tight')
                print(f"{p['savename']} saved figure into path:\n{pltpath.absolute()}")
            plt.show()
            return result

        return wrap
    return decorator


def myprint(target):
    """Decorator for redirecting print output to a file."""
    def decorator(func):
        def wrap(*args, **kwargs):
            temp = sys.stdout
            try:
                with open(target, 'a') as f:
                    sys.stdout = f
                    func(*args, **kwargs)
            finally:
                sys.stdout = temp
        return wrap
    return decorator


# Override errorbar with custom line width
def _myerrorbar(errorbar):
    def wrap(*args, **kwargs):
        if 'elinewidth' not in kwargs:
            kwargs['elinewidth'] = elinewidth
        return errorbar(*args, **kwargs)
    return wrap


plt.errorbar = _myerrorbar(plt.errorbar)
plt.Axes.errorbar = _myerrorbar(plt.Axes.errorbar)


class myUtilities:
    """
    Utility functions for plot formatting.

    A collection of static methods for common plot formatting tasks,
    including tick formatting and font utilities.

    Examples:
        >>> # Create a radian formatter
        >>> formatter = myUtilities.radFormatter('.1f')
        >>> ax.xaxis.set_major_formatter(formatter)

        >>> # Create a degree formatter
        >>> formatter = myUtilities.degFormatter('0f')
        >>> ax.yaxis.set_major_formatter(formatter)

        >>> # Create a dB formatter
        >>> formatter = myUtilities.dBFormatter('.1f')
        >>> ax.xaxis.set_major_formatter(formatter)
    """

    @staticmethod
    def radFormatter(dig='.2f'):
        """Create radian tick formatter (e.g., 0.5π)."""
        return ticker.FuncFormatter(lambda x, pos: f"{x / np.pi:{dig}}π")

    @staticmethod
    def degFormatter(dig='1.0f'):
        """Create degree tick formatter (e.g., 90°)."""
        return ticker.FuncFormatter(lambda x, pos: f"{x:{dig}}°")

    @staticmethod
    def dBFormatter(dig='1.2f'):
        """Create dB tick formatter."""
        return ticker.FuncFormatter(lambda x, pos: f"{x:{dig}} dB")

    @staticmethod
    def radLocator(base=np.pi / 4):
        """Create radian tick locator."""
        return ticker.MultipleLocator(base=base)

    @staticmethod
    def get_available_fonts():
        """Get list of available fonts."""
        return fm.findSystemFonts()

    @staticmethod
    def get_font_properties(font_path):
        """Get font properties from font file."""
        return fm.FontProperties(fname=str(font_path))


# Examples for documentation
if __name__ == "__main__":
    # Test the module
    print(f"Platform: {platform.system()}")
    print(f"Font setup successful: {setup_successful}")

    # List some available fonts
    available_fonts = myUtilities.get_available_fonts()
    print(f"Found {len(available_fonts)} fonts")

    # Test font finding
    source_han_font = find_source_han_serif_font()
    if source_han_font:
        print(f"Source Han Serif found at: {source_han_font}")