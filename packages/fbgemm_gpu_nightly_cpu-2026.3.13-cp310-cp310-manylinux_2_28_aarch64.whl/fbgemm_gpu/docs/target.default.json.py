
{
    "version": "2026.3.13",
    "target": "default",
    "variant": "cpu"
}
