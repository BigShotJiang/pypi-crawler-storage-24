# TEMPORAL.md — Migration Guide: llmkt Graph → Temporal Knowledge Substrate

You have two MCP servers connected:

1. **`old-`** (namespaced) — `mcp-neo4j-cypher` pointing at the old llmkt graph. You have `old-read_neo4j_cypher` and `old-write_neo4j_cypher`. **Only use the read tool.** Do not write to the old graph.
2. **`new-`** (namespaced) — `mcp-temporal-knowledge` pointing at an empty Neo4j database. This is the destination. Use only the bounded mutation tools — never `read_cypher` for writes.

Your job is to read everything worth keeping from the old graph and write it into the new graph using the proper tools. The old graph is structurally corrupted. You are not preserving its structure — you are extracting its *knowledge* and giving it a sound skeleton.

---

## What's Wrong With the Old Graph

The old graph was built by an LLM with raw Cypher access. The CLAUDE.md told it what to do; it did something else. Known damage:

- **NEXT_RUN edges point backwards.** The instructions said "link to previous" and the LLM created `(current)-[:NEXT_RUN]->(prev)` instead of `(prev)-[:NEXT_RUN]->(current)`. Some point forward, some backward. You cannot trust the chain direction.
- **Orphaned RunContexts.** 11 of 19 RunContexts are disconnected from their NEXT_ENCOUNTER chains. The LLM simply didn't create the linking edges on some runs.
- **Duplicate entities.** The reconciliation phase was a cognitive task in the CLAUDE.md. The LLM couldn't do it reliably. Run 3 created 14 new M365 entities when Run 1 had already found 7 of them. Same real-world thing, different nodes.
- **Duplicate Change nodes.** Identical IDs, created across different runs because the LLM couldn't remember what it had already written.

**Do not try to fix the old graph.** Extract what's valuable, discard the structural noise.

---

## Step 1 — Discover What's in the Old Graph

Start by understanding what you're working with. Run these read queries against the old graph:

### Find all node labels
```
CALL db.labels() YIELD label RETURN label ORDER BY label
```

### Find all relationship types
```
CALL db.relationshipTypes() YIELD relationshipType RETURN relationshipType ORDER BY relationshipType
```

### Find what looks like domains or top-level groupings
```
MATCH (n) WHERE n.domain IS NOT NULL
RETURN DISTINCT n.domain AS domain, labels(n) AS labels, count(*) AS count
ORDER BY domain
```

### Find RunContext/Run-like nodes (the session backbone)
```
MATCH (r) WHERE r:RunContext OR r:Run OR r:Session
RETURN labels(r) AS labels, r.domain AS domain, r.timestamp AS timestamp,
       r.purpose AS purpose, r.summary AS summary, r.status AS status
ORDER BY r.timestamp
```

### Get a count of everything
```
MATCH (n) RETURN labels(n) AS labels, count(*) AS count ORDER BY count DESC
```

### Sample entities with their properties
```
MATCH (n) WHERE NOT n:RunContext AND NOT n:Run AND NOT n:Domain
RETURN labels(n) AS labels, n.name AS name, n.domain AS domain,
       n.description AS description, keys(n) AS properties
LIMIT 50
```

Read through the results. Identify:
- What domains exist (even if implicit — entities grouped by a domain property or by naming convention)
- What knowledge entities are worth preserving (vs. duplicates or noise)
- What the RunContexts look like and whether any carry useful purpose/summary text

---

## Step 2 — Plan the Domain Structure

Before writing anything, decide on domains. The old graph may have domain names like `"m365"`, `"adobe"`, `"five9"`, etc. — or the entities may not have domain properties at all and you'll need to infer groupings.

List the domains you intend to create. Each should have a clear description of what the knowledge area covers.

---

## Step 3 — Create Domains

For each domain:
```
create_domain(name="m365", description="Microsoft 365 platform — Exchange Online, Teams, SharePoint, licensing, and migration tracking")
```

Do all domains first before any sessions.

---

## Step 4 — Migrate Knowledge, One Domain at a Time

For each domain, run one migration session:

### 4a. Begin a migration session
```
begin_session(domain="m365", purpose="Migration from legacy llmkt graph — extracting valid knowledge entities and connections", user="migration")
```

Save the `run_id` — you need it for every subsequent call.

### 4b. Read entities from the old graph for this domain
```
MATCH (n) WHERE n.domain = "m365" AND NOT n:RunContext AND NOT n:Run AND NOT n:Domain
RETURN labels(n) AS labels, n.name AS name, n.description AS description,
       n.id AS id, keys(n) AS all_properties
ORDER BY n.name
```

### 4c. Deduplicate

This is the step the LLM couldn't do with raw Cypher. You need to do it now.

Look at the results. You will likely see:
- Multiple nodes with the same or very similar names (e.g., "Exchange Online" and "Exchange Online Migration" and "EXO")
- Nodes with the same `id` property but different descriptions
- Nodes that represent the same real-world thing from different runs

**Keep the most descriptive version.** If two nodes have the same name, merge their descriptions. If they conflict, use the one from the later run (higher timestamp).

### 4d. Map old labels to knowledge types

The old graph may use labels that don't match the 10 knowledge types. Map them:

| Old Label (likely) | New Type | Notes |
|---|---|---|
| `Change` | `Change` | Direct match — tracked changes, deprecations, rollouts |
| `System`, `Platform`, `Tool` | `System` | Software systems, platforms, tools |
| `Process`, `Workflow` | `Process` | How something works |
| `Configuration`, `Setting`, `Config` | `Configuration` | Specific settings or parameters |
| `Person`, `Contact`, `Role` | `Person` | Roles, contacts, responsible parties |
| `Integration`, `API` | `Dependency` | External requirements or integration points |
| `Document`, `File`, `Reference` | `Artifact` | Documents, screenshots, reference material |
| Anything unlabeled or generic | Decide per entity | Read the description — use `Insight` for discovered truths, `Gotcha` for pitfalls, `Rationale` for decision reasoning |

If you encounter labels not in this table, read the entity's description and pick the most appropriate knowledge type. When in doubt, `Insight` is a reasonable default for "a thing we learned."

### 4e. Create knowledge entities

Batch them into `create_knowledge` calls. Each entity needs `name`, `type`, and `description`. The `domain` will default to the Run's domain.

```
create_knowledge(run_id="<run_id>", entities=[
    {"name": "Exchange Online", "type": "System", "description": "Microsoft's cloud email platform. Part of M365 suite. Successor to on-premises Exchange Server."},
    {"name": "EWS Retirement", "type": "Change", "description": "Exchange Web Services deprecated by Microsoft. Timeline: ..."},
    {"name": "Teams Connectors EOL", "type": "Change", "description": "Office 365 Connectors for Teams being retired. Webhook-based integrations must migrate to Power Automate Workflows."},
    ...
])
```

**Do not set `confidence` or `sources`.** These are human-supplied fields. You're an LLM migrating data.

### 4f. Read relationships from the old graph
```
MATCH (a)-[r]->(b)
WHERE a.domain = "m365" AND b.domain = "m365"
  AND NOT type(r) IN ["NEXT_RUN", "NEXT_ENCOUNTER", "HAS_RUN", "DISCOVERED", "CONFIRMED", "NEXT_GENESIS", "SEQUENCE", "OPENING"]
RETURN a.name AS source, b.name AS target, type(r) AS rel_type
```

### 4g. Map old relationship types and create connections

Map old relationship types to the 7 allowed knowledge edge types:

| Old Relationship (likely) | New Type | Notes |
|---|---|---|
| `DEPENDS_ON`, `REQUIRES` | `REQUIRING` | Source depends on target |
| `ENABLES`, `SUPPORTS` | `ENABLING` | Source makes target possible |
| `CAUSED_BY`, `TRIGGERED` | `CAUSING` | Source directly produced target |
| `INFORMED_BY`, `REFERENCES` | `INFORMING` | Source shaped target |
| `PART_OF`, `CONTAINS` | `COMPOSING` | Source is a building block of target |
| `RELATED_TO`, anything else | `RELATES_TO` | Catch-all for loose coupling |

```
create_connections(connections=[
    {"source": "Campaign Routing", "target": "Skill Mapping", "type": "REQUIRING"},
    ...
])
```

Cross-domain connections are allowed. If an M365 entity relates to a Five9 entity, create the connection — that's expected.

### 4h. End the migration session
```
end_session(run_id="<run_id>", summary="Migrated N entities and M connections from legacy llmkt graph. Deduplicated X redundant nodes. Mapped labels to knowledge types.")
```

The response will include `entities_discovered` and `entities_confirmed` counts.

---

## Step 5 — Migrate Old Run History (Optional)

If the old RunContexts carry useful `purpose` and `summary` text, you may want to preserve that narrative. But **do not try to reconstruct the old run chain**. It's broken.

Instead, for each domain, read the old RunContexts:

```
MATCH (r:RunContext) WHERE r.domain = "m365"
RETURN r.timestamp AS timestamp, r.purpose AS purpose, r.summary AS summary
ORDER BY r.timestamp
```

If any have substantive purpose/summary text, create an `Insight` entity capturing the historical session narrative:

```
create_knowledge(run_id="<current_run_id>", entities=[
    {"name": "Legacy Run History — m365", "type": "Artifact", "description": "Session log from legacy graph migration:\n\nRun 1 (2026-01-15): Purpose: Initial M365 discovery. Summary: Found 7 systems...\nRun 2 (2026-01-22): Purpose: Change tracking. Summary: Documented EWS retirement..."}
])
```

This preserves the narrative without recreating the broken temporal chain.

---

## Step 6 — Post-Migration: How Subsequent Sessions Work

Migration is Run 1. Runs 2, 3, 4... are where the substrate earns its keep. Here's how a normal session differs from migration:

### The three operations on knowledge

Each session, when you revisit entities, you have three choices:

1. **Confirm** — "I looked at this and it hasn't changed." Use `confirm_knowledge(run_id, names)`. Creates a `CONFIRMED` edge from the Run to the entity. No new nodes, no mutations. The provenance trail records that someone reviewed this and found it current.

2. **Evolve** — "This has changed." Use `evolve_knowledge(run_id, name, description)`. Creates a new version linked via EVOLVED_FROM. The old version is preserved. The evolution chain *is* the state machine — each version's description captures reality at that moment.

3. **Discover** — "This is new." Use `create_knowledge(run_id, entities)`. Creates new entities with DISCOVERED edges from the Run.

### t_valid — when knowledge has a shelf life

If an entity has an expiration date in the real world (a deprecation deadline, a contract end date, a temporary configuration), set `t_valid` when creating or evolving it. This means "externally valid until this date." When `t_valid` passes, the entity isn't deleted — it's a signal that the next session should evolve or re-confirm it.

### Domain-specific vocabulary lives in descriptions, not schema

The substrate is domain-agnostic. If TIP needs `State: IN_PROGRESS` or `Risk: HIGH`, put that in the entity description — not as a schema property. The evolution chain captures state transitions naturally: when you evolve an entity with a new description, the old description (with its old state) is preserved in the chain. Consumer-side code (CLAUDE.md rendering logic, pipeline parsers) can regex structured fields out of descriptions.

---

## Step 7 — Verify

After migrating all domains (and before starting normal sessions), verify the new graph:

```
list_domains()
```

For each domain:
```
get_domain_state(domain="m365")
get_run_history(domain="m365")
```

Check that:
- All domains appear with correct descriptions
- Entity counts are reasonable (less than the old graph — you deduplicated)
- Connections exist between entities that should be connected
- No orphaned entities (everything should have been DISCOVERED by a migration Run)

---

## Rules

1. **Read-only on the old graph.** Never write to it.
2. **One migration session per domain.** Don't create multiple runs per domain during migration.
3. **Deduplicate aggressively.** The whole point of this migration is to go from noise to signal. If two entities describe the same thing, keep one with a merged description.
4. **Don't invent knowledge.** If an entity in the old graph has an empty or placeholder description, either write a description based strictly on what other nodes and relationships tell you about it, or skip it.
5. **Don't set `confidence` or `sources`.** You're an LLM. These fields are for humans.
6. **Use `Gotcha` generously.** If the old graph has anything that looks like a pitfall, trap, or "thing that breaks in production" — that's a Gotcha. This is the most valuable knowledge type for operators. Don't lose these by mapping them to generic `Insight`.
7. **Preserve `Change` nodes carefully.** Changes with timelines (deprecations, rollouts, EOL dates) are high-value. Make sure their descriptions include the timeline.
