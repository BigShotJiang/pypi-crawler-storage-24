# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

An MCP server for domain-scoped knowledge accumulation backed by Neo4j. Two-layer architecture:
- **Process layer** (immutable): Domain → Run chain with tool-enforced temporal integrity (NEXT_RUN always points forward in time)
- **Knowledge layer** (append-only, evolving): 11 entity types + 7 relationship types. Identity entities are updated in place; event entities create new versions linked via EVOLVED_FROM

The core design principle: every invariant lives in tools, not in instructions. No raw Cypher writes are exposed.

## Commands

```bash
# Install dependencies
uv sync --dev

# Run the server
mcp-temporal-knowledge --db-url bolt://localhost:7687

# Run all tests
uv run pytest

# Run a single test
uv run pytest tests/unit/test_server.py::TestKnowledgeTypeValidation::test_valid_knowledge_type_accepted

# Type checking
uv run pyright
```

## Architecture

### Entry flow
`__init__.py` (CLI argparse + `process_config`) → `server.main()` (Neo4j driver setup, fulltext index creation) → `create_mcp_server()` (FastMCP tool registration)

### Key modules
- **`server.py`** — FastMCP server factory with 23 tools (4 process, 7 knowledge, 4 query, 2 taxonomy, 6 GDS analytics). Includes a monkey patch for FastMCP 2.13.0.2 HTTP method bug.
- **`substrate.py`** — Core logic class `TemporalKnowledgeSubstrate` wrapping the Neo4j async driver. Contains enums (`KnowledgeType`, `ConnectionType`), Pydantic models (`KnowledgeEntity`, `Connection`, `DomainKnowledge`), and guard constants (`PROCESS_TYPES`, `PROCESS_EDGES`).
- **`utils.py`** — `load_cypher()` template loader, `process_config()` for CLI/env var resolution, `_is_write_query()` guard, `_value_sanitize()` for stripping embeddings from results.
- **`_cypher/`** — Cypher query templates using `__placeholder__` convention (e.g., `__label__`, `__rel_type__`). Loaded and cached by `load_cypher()`.

### Cypher template system
Templates in `_cypher/*.cypher` use `__key__` placeholders (not `$param`). `load_cypher("knowledge_create", label="System")` replaces `__label__` with `System`. Neo4j parameters use `$param` syntax. This separation exists because Neo4j doesn't support parameterized labels/relationship types.

### Session model
Stateless — no server-side session state. `begin_session()` returns a `run_id` that the client passes to all subsequent knowledge tools. Incomplete sessions (no `end_session` call) remain with `status: 'active'` — this is by design, not a bug.

### Tool guard invariants
- `create_knowledge` hard-rejects process types (Domain, Run)
- `update_knowledge` updates an existing entity's description in place — no new node, no EVOLVED_FROM. Hard-rejects process types. Creates DISCOVERED edge from Run.
- `retype_knowledge` changes an entity's Neo4j label (e.g., Person → Organization). Keeps all properties and edges. Hard-rejects process types.
- `merge_knowledge` collapses an entity's EVOLVED_FROM chain into a single canonical node. Redirects all edges from duplicates to the canonical, deletes duplicates. Returns absorbed descriptions so temporal observations can be relocated. Hard-rejects process types. **Destructive** — cannot be undone.
- `confirm_knowledge` creates CONFIRMED edges from Run to head-of-chain entities — "I looked at this and it hasn't changed"
- `create_connections` hard-rejects process edge types (HAS_RUN, NEXT_RUN, DISCOVERED, CONFIRMED) and knowledge edges between two process nodes. Domain-scoped matching via `source_domain`/`target_domain` fields — errors on ambiguity instead of creating cross-product edges. Only matches head-of-chain entities.
- `read_cypher` rejects write queries via regex check
- `evolve_knowledge` only operates on head-of-chain entities (`WHERE NOT (e)<-[:EVOLVED_FROM]-()`)

### Identity vs Event entity types

**Identity entities** persist through time. New information enriches the same node via `update_knowledge`.
- Person, Organization, System, Process, Configuration, Dependency, Insight, Gotcha, Rationale

**Event entities** are discrete temporal occurrences. Each is a genuinely new thing. `EVOLVED_FROM` chains via `evolve_knowledge` are correct.
- Change, Artifact

**The test**: "If I encounter this entity in a future filing, would I say 'that's the same thing' or 'that's a new instance'?" Same thing → `update_knowledge`. New instance → `evolve_knowledge`.

### Person vs Organization

- **Person** — an individual. A localized conscious entity. Calvin McDonald, Meghan Frank, Dennis J. Wilson.
- **Organization** — a collective entity. An institution, fund, corporation, or group operating as a unified body. FMR LLC (Fidelity), The Vanguard Group, Susquehanna Group (SIG).

The distinction is ontological, not administrative. A person is a consciousness. An organization is a collective of consciousnesses operating through shared structure. Both are identity entities — they persist through time — but they are fundamentally different kinds of things.

### What descriptions describe

An entity's description describes **what the entity IS**, not what happened to it or around it. Temporal observations belong on event nodes (Change, Artifact) connected via edges.

- **Correct Person description**: "Founder of lululemon. Largest individual shareholder (8.4%). Filed under Schedule 13D — not passive."
- **Wrong Person description**: "SCHEDULE 13D/A Amendment No. 10 filed Oct 8, 2025. WILSON GOES PUBLIC. Published letter in WSJ..."

The filing IS a Change. Wilson IS the founder. The filing reveals information about Wilson — that's an INFORMING edge from the Change to the Person. The description of Wilson should survive unchanged across any number of future filings about him (unless his identity itself changes — resignation, death, role change).

### Config resolution
CLI args → environment variables → defaults. Key env vars: `NEO4J_URI`/`NEO4J_URL`, `NEO4J_USERNAME`, `NEO4J_PASSWORD`, `NEO4J_DATABASE`. Transport modes: stdio (default), sse, streamable-http.

## Testing

Tests use `pytest-asyncio` and mock the `TemporalKnowledgeSubstrate`. Integration tests require a Neo4j instance (testcontainers dependency is available but no integration tests exist yet).
