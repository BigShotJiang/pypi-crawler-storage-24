"""Базовая схема сообщений app-event: тело сообщения — весь JSON (без обёртки data)."""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, ConfigDict, Field


class BaseAppEventMessage(BaseModel):
    """
    Базовое сообщение: тело Kafka-сообщения — весь JSON (поля модели напрямую).
    Используется для отправки/чтения результатов обработки (не CRUD before/after).
    """

    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))

    model_config = ConfigDict(extra="allow", populate_by_name=True)
