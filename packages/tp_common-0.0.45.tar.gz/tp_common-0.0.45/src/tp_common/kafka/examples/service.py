"""Тестовый сервис результатов для примера."""

from datetime import datetime

from tp_common.kafka.app_event import BaseAppEventMessage
from tp_common.kafka.app_event.app_event import AppEventServiceAsync


class ExampleResultMessage(BaseAppEventMessage):
    """Сообщение примера: id, name, created_at + timestamp из базы."""

    id: int
    name: str
    created_at: datetime | None = None


class ExampleEventService(AppEventServiceAsync[ExampleResultMessage]):
    TOPIC_PREFIX = "example.events"
    MESSAGE_CLASS = ExampleResultMessage
