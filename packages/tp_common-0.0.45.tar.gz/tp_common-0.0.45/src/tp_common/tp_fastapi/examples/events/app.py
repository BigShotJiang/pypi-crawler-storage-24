"""
Пример: использование events (Kafka) в FastAPI.

Эндпоинт GET /events возвращает список сообщений с указанной даты (timestamp в мс).
  - 200: список сообщений (каждое с полем timestamp из схемы), может быть пустым.
  - 500: ошибка (Kafka/таймаут); в логе trace_id.

Запуск (Kafka должен быть доступен):
  uvicorn tp_common.tp_fastapi.examples.events.app:app --reload --port 8000

Пример запроса:
  curl "http://127.0.0.1:8000/events?timestamp=1710000000000&source_system=my_client&limit=100"
"""

import logging
import os
import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import Depends, FastAPI, Query
from fastapi.responses import JSONResponse, Response

from tp_common.exceptions import ApiException
from tp_common.kafka.connector import KafkaConnector
from tp_common.kafka.examples.service import ExampleEventService
from tp_common.tp_logger.fastapi_integration import (
    TpMiddleware,
    get_request_logger,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory

logging.basicConfig(level=logging.INFO)
logger_factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
logger = logger_factory.get_logger("example_api")


class EventReadException(ApiException):
    """Ошибка чтения событий из Kafka (таймаут, сбой и т.д.)."""

    def __init__(
        self,
        *,
        trace_id: str | int | uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message="Internal Server Error",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            trace_id=trace_id,
        )


def get_kafka_connector() -> KafkaConnector:
    url = os.environ.get("KAFKA_URL", "plaintext://localhost:9092")
    return KafkaConnector(url, logger=logger)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    app.state.log_factory = logger_factory
    TpLoggerFactory.setup_standard_loggers(EnvironmentType.LOCAL)
    yield


app = FastAPI(
    title="Example Events API (Kafka)",
    description="Эндпоинт /events — список сообщений с указанной даты (timestamp).",
    lifespan=lifespan,
)
app.add_middleware(TpMiddleware)


@app.get(
    "/events",
    summary="Список сообщений с даты (timestamp)",
    description="Возвращает список сообщений с timestamp >= timestamp. "
    "200 — массив сообщений (у каждого есть timestamp), может быть пустым; "
    "для пагинации используй timestamp последнего сообщения. "
    "500 — ошибка после повторов (Kafka/таймаут и т.д.), в логе trace_id. "
    "timeout — максимум секунд ожидания чтения (по умолчанию 25).",
)
async def events_list(
    logger: TpLogger = Depends(get_request_logger),
    timestamp: int = Query(
        ...,
        description="Начальная дата: timestamp в миллисекундах (UTC).",
    ),
    source_system: str = Query(
        ...,
        description="Система-источник: топик example.events.<source_system>.",
    ),
    limit: int | None = Query(
        default=None,
        ge=1,
        le=10_000,
        description="Максимум сообщений в ответе (без ограничения, если не задан).",
    ),
    timeout: float = Query(
        default=25.0,
        ge=1.0,
        le=120.0,
        description="Максимум секунд ожидания чтения из Kafka (таймаут запроса).",
    ),
) -> Response:
    connector = get_kafka_connector()
    async with ExampleEventService(
        connector=connector,
        logger=logger,
        consumer_group="example_events_list_api",
        source_system=source_system,
    ) as service:
        try:
            async with service.subscription():
                messages = await service.read_from_timestamp_ready(
                    timestamp,
                    limit=limit,
                    read_timeout_sec=timeout,
                    assignment_timeout_sec=15.0,
                )
            return JSONResponse(content=[m.model_dump(mode="json") for m in messages])
        except Exception as e:
            logger.exception(
                "Чтение событий не удалось (исчерпаны повторы или ошибка): %s", e
            )
            raise EventReadException(trace_id=logger.trace_id) from e


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}
