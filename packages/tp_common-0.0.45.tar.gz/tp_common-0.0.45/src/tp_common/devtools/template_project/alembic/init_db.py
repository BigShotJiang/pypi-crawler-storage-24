#!/usr/bin/env python3
"""
Скрипт для управления базой данных.
Динамически импортирует все модели и создает/удаляет таблицы.

Использование:
    python init_db.py                 # Только создание таблиц
    python init_db.py --drop          # Удалить и создать таблицы заново
"""

import argparse
import asyncio
import importlib
import pkgutil
import sys
import time
from pathlib import Path

# Добавляем путь к проекту
sys.path.append(str(Path(__file__).resolve().parent / "src"))

import src.models
from sqlalchemy.ext.asyncio import create_async_engine
from src.config import config


def import_all_models():
    """Динамический импорт всех моделей"""
    print("Импортируем модели...")
    imported_count = 0

    for _, module_name, _ in pkgutil.iter_modules(src.models.__path__):
        if not module_name.startswith("__"):  # Пропускаем __init__ и __pycache__
            try:
                importlib.import_module(f"src.models.{module_name}")
                print(f"  ✓ {module_name}")
                imported_count += 1
            except ImportError as e:
                print(f"  ✗ {module_name}: {e}")

    print(f"Импортировано {imported_count} моделей")


async def drop_all_tables():
    """Удаление всех таблиц"""
    print("Удаляем все таблицы...")

    # Динамически импортируем все модели
    import_all_models()

    # Импортируем BaseModel после импорта всех моделей
    from src.domain.shared.models.base_model import BaseModel

    # Создаем движок
    engine_url = config.get_async_postgres_url_connection()
    print(f"Подключение к базе: {engine_url.split('@')[1]}")  # Скрываем пароль

    engine = create_async_engine(engine_url, echo=True)

    try:
        # Удаляем все таблицы
        async with engine.begin() as conn:
            await conn.run_sync(BaseModel.metadata.drop_all)

        print("Все таблицы удалены!")

    except Exception as e:
        print(f"Ошибка при удалении таблиц: {e}")
        raise
    finally:
        await engine.dispose()


async def create_tables():
    """Создание всех таблиц"""
    print("Создаем таблицы...")

    # Динамически импортируем все модели
    import_all_models()

    # Импортируем BaseModel после импорта всех моделей
    from src.domain.shared.models.base_model import BaseModel

    # Создаем движок
    engine_url = config.get_async_postgres_url_connection()
    print(f"Подключение к базе: {engine_url.split('@')[1]}")  # Скрываем пароль

    engine = create_async_engine(engine_url, echo=True)

    try:
        # Создаем все таблицы
        async with engine.begin() as conn:
            await conn.run_sync(BaseModel.metadata.create_all)

        print("Таблицы созданы успешно!")

    except Exception as e:
        print(f"Ошибка при создании таблиц: {e}")
        raise
    finally:
        await engine.dispose()


async def recreate_database(drop_first=False):
    """Пересоздание базы данных"""
    if drop_first:
        await drop_all_tables()
        print()  # Пустая строка для разделения

    await create_tables()


async def main():
    """Основная функция"""
    parser = argparse.ArgumentParser(description="Управление базой данных")
    parser.add_argument(
        "--drop", action="store_true", help="Удалить все таблицы перед созданием новых"
    )

    args = parser.parse_args()

    print("=" * 50)
    if args.drop:
        print("ПЕРЕСОЗДАНИЕ БАЗЫ ДАННЫХ")
    else:
        print("СОЗДАНИЕ ТАБЛИЦ")
    print("=" * 50)

    start_time = time.time()

    try:
        if args.drop:
            print("ВНИМАНИЕ: Все данные будут удалены!")
            confirm = input("Продолжить? (yes/no): ").lower().strip()
            if confirm not in ["yes", "y", "да", "д"]:
                print("Операция отменена.")
                return

        await recreate_database(drop_first=args.drop)

        elapsed_time = time.time() - start_time
        print(f"\nГотово! Время выполнения: {elapsed_time:.2f} секунд")

    except Exception as e:
        print(f"\nОшибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
