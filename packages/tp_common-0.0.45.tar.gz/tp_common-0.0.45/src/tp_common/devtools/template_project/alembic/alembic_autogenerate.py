"""
Генерация миграции Alembic с автогенерацией.

Принимает только описание — автоматически использует --autogenerate.

Usage:
    poetry run python alembic/alembic_autogenerate.py "описание"
    poetry run python alembic/alembic_autogenerate.py init
"""

import os
import sys
from datetime import datetime
from pathlib import Path

# Корень проекта (родитель папки alembic/)
project_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root))
os.chdir(project_root)

from alembic.config import Config

from alembic import command


def main() -> None:
    msg = sys.argv[1] if len(sys.argv) > 1 else ""

    config = Config(str(project_root / "alembic.ini"))

    script_location = config.get_main_option("script_location", "alembic")
    versions_dir = project_root / script_location.replace("/", os.sep) / "versions"
    now = datetime.now()
    year_month_dir = versions_dir / str(now.year) / f"{now.month:02d}"
    year_month_dir.mkdir(parents=True, exist_ok=True)

    ym_path = str(year_month_dir)

    # Собираем все существующие год/месяц директории + текущую.
    # recursive_version_locations = true в alembic.ini не используем для корня,
    # чтобы избежать дублей — явно перечисляем все leaf-директории с файлами.
    existing_dirs = sorted({str(p.parent) for p in versions_dir.rglob("*.py")})
    if ym_path not in existing_dirs:
        existing_dirs.append(ym_path)
    config.set_main_option("version_locations", os.pathsep.join(existing_dirs))

    command.revision(
        config,
        message=msg,
        autogenerate=True,
        version_path=ym_path,
    )


if __name__ == "__main__":
    main()
