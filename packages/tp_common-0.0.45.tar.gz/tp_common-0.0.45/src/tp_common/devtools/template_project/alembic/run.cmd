poetry run python alembic/alembic_revision.py --autogenerate -m ""
poetry run python alembic/alembic_apply.py

poetry run python alembic/alembic_apply.py downgrade -1

