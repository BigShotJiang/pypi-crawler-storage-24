import asyncio
import importlib
import sys
from logging.config import fileConfig
from pathlib import Path
from typing import Literal

import alembic_postgresql_enum  # noqa: F401 - autogenerate: создание/изменение/удаление enum, create_type=False в колонках
from alembic.autogenerate.api import AutogenContext
from sqlalchemy import engine_from_config, pool, text
from sqlalchemy.dialects import postgresql
from sqlalchemy.ext.asyncio import AsyncEngine
from src.config import config as project_config
from src.domain.shared.models.base_model import BaseModel

from alembic import context

sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
target_metadata = BaseModel.metadata  # Использование Base.metadata


# УЛУЧШЕННЫЙ ИМПОРТ МОДЕЛЕЙ
def import_all_models():
    """Импортирует все модели из src/domain (включая вложенные папки)."""
    project_root = Path(__file__).resolve().parents[1]
    domain_path = project_root / "src" / "domain"

    print(f"Importing models from: {domain_path}")

    for model_file in sorted(domain_path.rglob("model.py")):
        rel = model_file.relative_to(project_root)
        parts = rel.with_suffix("").parts
        module_name = ".".join(parts)
        if any(p.startswith("_") for p in parts):
            continue
        try:
            importlib.import_module(module_name)
        except Exception as e:
            print(f"  [-] Failed to import {module_name}: {e}")


# Импортируем все модели
import_all_models()

# Выводим информацию о найденных таблицах
# print(f"\nTables found in metadata: {list(target_metadata.tables.keys())}")

# Трекаем enum-типы при autogenerate
_seen_enum_names: set[str] = set()
_existing_enum_names: set[str] | None = None  # None = ещё не загружали из БД


def _get_connection_for_enum_check(autogen_context: object):
    """Получает connection для проверки enum в БД (autogenerate/revision)."""
    conn = getattr(autogen_context, "connection", None)
    if conn is not None:
        return conn
    migration_ctx = getattr(autogen_context, "migration_context", None)
    if migration_ctx is not None:
        conn = getattr(migration_ctx, "connection", None)
        if conn is not None:
            return conn
    try:
        ctx = context.get_context()
        return getattr(ctx, "connection", None)
    except Exception:
        return None


def _get_existing_enum_names(autogen_context: object) -> set[str]:
    """Загружает из БД имена enum-типов (кеш)."""
    global _existing_enum_names
    if _existing_enum_names is not None:
        return _existing_enum_names
    conn = _get_connection_for_enum_check(autogen_context)
    if conn is None:
        _existing_enum_names = set()
        return _existing_enum_names
    try:
        result = conn.execute(
            text(
                "SELECT t.typname FROM pg_type t "
                "JOIN pg_namespace n ON t.typnamespace = n.oid "
                "WHERE t.typtype = 'e' AND n.nspname = 'public'"
            )
        )
        _existing_enum_names = {row[0] for row in result}
    except Exception:
        _existing_enum_names = set()
    return _existing_enum_names


def _render_enum_item(
    type_: str, obj: object, autogen_context: AutogenContext
) -> str | Literal[False]:
    """
    Для enum: используем create_type=False, если тип уже есть в БД или уже встречался в этой миграции.
    Предотвращает DuplicateObjectError.
    """
    if type_ != "type":
        return False

    enum_type = obj
    if not hasattr(enum_type, "enums") or not hasattr(enum_type, "name"):
        return False

    db_name = getattr(enum_type, "name", None)
    if not db_name:
        return False

    # PostgreSQL ENUM или sa.Enum
    is_pg_enum = isinstance(enum_type, postgresql.ENUM)
    is_sa_enum = type(enum_type).__name__ == "Enum" and type(
        enum_type
    ).__module__.startswith("sqlalchemy")
    if not (is_pg_enum or is_sa_enum):
        return False

    values = []
    for e in getattr(enum_type, "enums", ()):
        if hasattr(e, "name") and isinstance(getattr(e, "name", None), str):
            values.append(repr(e.name))
        else:
            values.append(repr(str(e)))

    existing = _get_existing_enum_names(autogen_context)
    use_create_type_false = db_name in existing or db_name in _seen_enum_names
    _seen_enum_names.add(db_name)

    if use_create_type_false:
        autogen_context.imports.add("from sqlalchemy.dialects import postgresql")
        return (
            f"postgresql.ENUM({', '.join(values)}, name={db_name!r}, create_type=False)"
        )
    return False


# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def get_url():
    """URL для миграций. Если передан sqlalchemy.url в конфиге (например, из интеграционных тестов) — используем его."""
    return (
        context.config.get_main_option("sqlalchemy.url")
        or project_config.get_async_postgres_url_connection()
    )


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.
    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well. By skipping the Engine creation
    we don't even need a DBAPI to be available.
    Calls to context.execute() here emit the given string to the
    script output.
    """
    url = get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        render_item=_render_enum_item,
    )

    with context.begin_transaction():
        context.run_migrations()


# ...existing code...


def do_run_migrations(connection):
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        render_item=_render_enum_item,
    )

    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    """Run migrations in 'online' mode.
    In this scenario we need to create an Engine
    and associate a connection with the context.
    """
    configuration = config.get_section(config.config_ini_section) or {}
    configuration["sqlalchemy.url"] = (
        context.config.get_main_option("sqlalchemy.url") or get_url()
    )
    connectable = AsyncEngine(
        engine_from_config(
            configuration,
            prefix="sqlalchemy.",
            poolclass=pool.NullPool,
            future=True,
        )
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
