"""
Генерация миграций Alembic с папочной структурой год/месяц.

Создаёт миграции в alembic/versions/YYYY/MM/ вместо корня versions.

Usage:
    poetry run python alembic/alembic_revision.py --autogenerate -m "описание"
    poetry run python alembic/alembic_revision.py -m "описание"
"""

import os
import sys
from datetime import datetime
from pathlib import Path

# Корень проекта (родитель папки alembic/)
project_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root))
os.chdir(project_root)

from alembic.config import Config

from alembic import command


def main() -> None:
    config = Config(str(project_root / "alembic.ini"))

    script_location = config.get_main_option("script_location", "alembic")
    versions_dir = project_root / script_location.replace("/", os.sep) / "versions"
    now = datetime.now()
    year_month_dir = versions_dir / str(now.year) / f"{now.month:02d}"
    year_month_dir.mkdir(parents=True, exist_ok=True)

    # version_locations: год/месяц + база (для поиска существующих миграций)
    ym_path = str(year_month_dir)
    base = str(versions_dir)
    config.set_main_option("version_locations", f"{ym_path}{os.pathsep}{base}")

    argv = sys.argv[1:]
    msg = None
    if "-m" in argv:
        idx = argv.index("-m")
        msg = argv[idx + 1] if idx + 1 < len(argv) else ""
    autogenerate = "--autogenerate" in argv or "-x" in argv

    # version_path — явно задаём, куда писать (иначе Alembic использует родителя head)
    command.revision(
        config,
        message=msg,
        autogenerate=autogenerate,
        version_path=ym_path,
    )


if __name__ == "__main__":
    main()
