"""
Применение миграций Alembic.

Выполняет `alembic upgrade head`.

Usage:
    poetry run python alembic/alembic_apply.py
    poetry run python alembic/alembic_apply.py downgrade -1
"""

import os
import sys
from pathlib import Path

project_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root))
os.chdir(project_root)

from alembic.config import Config

from alembic import command


def main() -> None:
    config = Config(str(project_root / "alembic.ini"))

    argv = sys.argv[1:]
    if argv and argv[0] == "downgrade":
        steps = argv[1] if len(argv) > 1 else "-1"
        command.downgrade(config, steps)
    else:
        command.upgrade(config, "head")


if __name__ == "__main__":
    main()
