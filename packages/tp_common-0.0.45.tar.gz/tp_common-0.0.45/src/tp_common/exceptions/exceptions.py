import re
import uuid
from http import HTTPStatus

from fastapi import HTTPException


class ApiException(HTTPException):
    """
    Базовое API-исключение: message, status_code, trace_id.
    Наследуй для каждой конкретной ошибки и задавай статус/сообщение, прокидывай trace_id.
    Как наследник HTTPException обрабатывается FastAPI и отдаёт JSON в ответ.
    """

    def __init__(
        self,
        message: str,
        status_code: HTTPStatus = HTTPStatus.INTERNAL_SERVER_ERROR,
        trace_id: str | int | uuid.UUID | None = None,
    ) -> None:
        self.trace_id = trace_id
        super().__init__(status_code=status_code, detail=message)

    @property
    def error(self) -> str:
        """Идентификатор ошибки из имени класса в snake_case: UserScopeCompanyAccessDenied → user_scope_company_access_denied."""
        return re.sub(r"(?<!^)(?=[A-Z])", "_", self.__class__.__name__).lower()
