# API Exceptions

Исключения API-слоя наследуются от `ApiException` (из `tp_common.exceptions.business_exception`).

Исключения, специфичные для сущности, создавать в модуле этой сущности — `exceptions.py` рядом с route/service (например `cp_vehicles/vehicle_types/exceptions.py`). В общий `src/apis/exceptions/` выносить только общие ошибки.

## 1 класс — 1 ошибка

Каждое исключение — отдельный класс. Один класс описывает одну конкретную ошибку.

**Использовать** отдельный класс на каждую ошибку:

```python
# ✅ GOOD
from http import HTTPStatus

from tp_common.exceptions.business_exception import ApiException


class VehicleTypeNotFound(ApiBusinessException):
    def __init__(self, type_id: uuid.UUID) -> None:
        super().__init__(
            message=f"Тип транспортного средства не найден: {type_id}",
            status_code=HTTPStatus.NOT_FOUND,
        )
