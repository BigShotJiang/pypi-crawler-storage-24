"""
Пример: работа с cookies — единая точка входа bytes.

Запуск (из корня проекта):
    python -m tp_common.base_client.example.example_cookies

Показано: cookies_to_bytes / load_cookies, save_cookies_to_string,
cookies_string_to_bytes, load_cookies_from_string.
Сайт: https://t.mos.ru/gruzoviki/reestr
"""

from __future__ import annotations

import asyncio
import pickle

from tp_common.base_client.client import BaseClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory

LOG_FACTORY = TpLoggerFactory(EnvironmentType.DEV)
logger = LOG_FACTORY.get_logger("base_client_example_cookies")


def parse_cookies_from_bytes(data: bytes) -> list[tuple[str, str]]:
    """
    Парсит bytes от cookies_to_bytes() в список пар (name, value).
    """
    raw = pickle.loads(data)
    result: list[tuple[str, str]] = []
    for simple_cookie in raw.values():
        for name in simple_cookie:
            result.append((name, simple_cookie[name].value))
    return result


async def main() -> None:
    base_url = "https://mail.yandex.ru"
    client = BaseClient(
        base_url=base_url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ),
        },
        logger=logger.logger,
    )

    cookies_str = ""
    async with client:
        await client.get_response("")

        # Единая точка входа — bytes
        cookies_bytes = client.cookies_to_bytes()
        logger.info("cookies_to_bytes(): %s байт", len(cookies_bytes))

        pairs = parse_cookies_from_bytes(cookies_bytes)
        for name, value in pairs:
            logger.info("  %s=%s", name, value)
        if not pairs:
            logger.info("  (пусто)")

        # Строка Set-Cookie (читаемый формат)
        cookies_str = client.save_cookies_to_string()
        logger.info("save_cookies_to_string(): %s символов", len(cookies_str))
        if cookies_str:
            logger.info(
                "  первая строка: %s...",
                cookies_str.split("\n")[0][:80],
            )

    # Строка → bytes и загрузка в другой клиент (или тот же)
    if cookies_str:
        bytes_from_string = BaseClient.cookies_string_to_bytes(cookies_str)
        client2 = BaseClient(base_url=base_url, logger=logger.logger)
        client2.load_cookies(bytes_from_string)
        # либо: client2.load_cookies_from_string(cookies_str)
        logger.info(
            "load_cookies(BaseClient.cookies_string_to_bytes(s)) — готово к запросам с cookies"
        )


if __name__ == "__main__":
    asyncio.run(main())
