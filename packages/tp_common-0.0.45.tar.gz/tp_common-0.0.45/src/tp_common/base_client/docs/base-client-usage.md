# BaseClient: краткое использование

## Правило компании

**В запросах и ответах всегда использовать Pydantic-схемы:**

- **Запрос (тело):** передавать модель через параметр `body=...` (например `body=LoginRequest(...)`).
- **Ответ:** методы `get`, `post`, `put`, `patch`, `delete` принимают вторым аргументом схему ответа и возвращают уже типизированную модель (без ручного `model_validate`).
- **Сырой ответ** (когда нужны заголовки, статус, `.text()` / `.bytes()`): использовать `get_response`, `post_response`, `put_response`, `patch_response`, `delete_response` — они возвращают `ClientResponse`.

## Обязательный вариант: использование через `async with`

```python
from pydantic import BaseModel

from tp_common.base_client.client import BaseClient


class User(BaseModel):
    id: int
    name: str


# Ответ API вида {"items": [...], "total": 100} — отдельная схема
class UsersListResponse(BaseModel):
    items: list[User]
    total: int


# Query-параметры — только схема (params принимает только BodySchema)
class UsersParams(BaseModel):
    limit: int = 10


client = BaseClient(base_url="https://api.example.com")

async with client:
    user = await client.get("/users/1", User)

    users_response = await client.get(
        "/users", UsersListResponse, params=UsersParams(limit=10)
    )
    # users_response.items — list[User], users_response.total — int
```

Клиент **обязательно** использовать в контексте `async with`: сессия открывается при входе и закрывается при выходе.

## Запросы с авторизацией

**Что предпочесть:** если API отдаёт токен в ответе на логин — лучше **Bearer** (`set_bearer_token`): одна строка, удобно хранить и передавать. **Cookies** — когда API авторизует только через сессию (Set-Cookie), без токена в теле ответа.

**Bearer (JWT, OAuth)** — задать токен для всех запросов через `set_bearer_token`:

```python
from pydantic import BaseModel

from tp_common.base_client.client import BaseClient


class MeResponse(BaseModel):
    id: int
    login: str


client = BaseClient(base_url="https://api.example.com")
client.set_bearer_token(token)
async with client:
    me = await client.get("/me", MeResponse)
```

**API-ключ в заголовке** — аналогично:

```python
client = BaseClient(
    base_url="https://api.example.com",
    headers={"X-API-Key": api_key},
)
```

**Логин → токен в заголовки** — получаем токен из ответа логина, подставляем в заголовки; дальше все запросы в этом же блоке (и в следующих `async with`) идут с `Authorization`:

```python
from pydantic import BaseModel

from tp_common.base_client.client import BaseClient


class LoginRequest(BaseModel):
    login: str
    password: str


class LoginResponse(BaseModel):
    token: str  # или access_token — как возвращает API


class ProtectedResponse(BaseModel):
    # поля ответа /protected под ваш API
    pass


client = BaseClient(base_url="https://api.example.com")
async with client:
    auth = await client.post("/login", LoginResponse, body=LoginRequest(login="user", password="pass"))
    client.set_bearer_token(auth.token)
    protected = await client.get("/protected", ProtectedResponse)
```

**Логин → cookies** — после логина сериализуем cookies в bytes через `cookies_to_bytes()`, восстанавливаем через `load_cookies(bytes)`. Можно оставить в переменной (следующие `async with` с тем же клиентом) или сохранить в БД и подставить в другом процессе:

```python
from pydantic import BaseModel

from tp_common.base_client.client import BaseClient


class LoginRequest(BaseModel):
    login: str
    password: str


class ProtectedResponse(BaseModel):
    pass  # поля под ваш API


client = BaseClient(base_url="https://api.example.com")
async with client:
    await client.post_response("/login", body=LoginRequest(login="user", password="pass"))
    cookies_bytes = client.cookies_to_bytes()
    # вариант: сохранить в БД — db.save("cookies", cookies_bytes)
client.load_cookies(cookies_bytes)
# вариант после перезапуска: cookies_bytes = db.get("cookies"); client.load_cookies(cookies_bytes)
async with client:
    protected = await client.get("/protected", ProtectedResponse)
```

Устаревший способ (строка, теряются domain/path/expires): `extract_cookies_from_session()` и `cookies=...` при создании клиента.

**Полное сохранение cookies (domain, path, expires)** — в объект (bytes) или в файл:

```python
from pydantic import BaseModel

from tp_common.base_client.client import BaseClient


class LoginRequest(BaseModel):
    login: str
    password: str


class ProtectedResponse(BaseModel):
    pass  # поля под ваш API


# после логина — сохранить в объект (БД, кэш, передать в другой процесс)
async with client:
    await client.post_response("/login", body=LoginRequest(login="user", password="pass"))
    cookies_bytes = client.cookies_to_bytes()

# позже — загрузить из объекта
client = BaseClient(base_url="https://api.example.com")
client.load_cookies(cookies_bytes)
async with client:
    protected = await client.get("/protected", ProtectedResponse)
```

Тот же формат можно писать в файл: `save_cookies_to_file(path)`, `load_cookies_from_file(path)`.

**Строка Set-Cookie и конвертация в bytes** — единая точка входа для хранения: bytes. Если есть строка (например из `save_cookies_to_string()` или из заголовков ответа), перевести в bytes и загрузить:

```python
# сессия → строка (читаемый формат)
cookies_str = client.save_cookies_to_string()

# строка → bytes (для БД или другого клиента)
cookies_bytes = BaseClient.cookies_string_to_bytes(cookies_str)
client2.load_cookies(cookies_bytes)

# либо сразу: client2.load_cookies_from_string(cookies_str)
```

**Один запрос с другим токеном** — подставить токен через метод, затем запрос:

```python
from pydantic import BaseModel

class AdminResponse(BaseModel):
    pass  # поля под ваш API

client.set_bearer_token(admin_token)
async with client:
    admin_data = await client.get("/admin", AdminResponse)
```

## Варианты использования

1. **get, post, put, patch, delete** — второй аргумент обязателен: схема ответа (Pydantic BaseModel). Возвращают типизированную модель.  
   **get_response, post_response, put_response, patch_response, delete_response** — возвращают сырой `ClientResponse` (когда нужны заголовки, статус, `.text()` / `.bytes()` или ручной разбор).

2. Чтение ответа  
   - Обычный сценарий: `user = await client.get("/users/1", User)` — сразу модель.  
   - Сырой ответ: `resp = await client.get_response("/some"); data = resp.json()` или `resp.text()` / `resp.bytes()`.

3. Передача данных  
   - `params` — query-параметры **только как схема** с model_dump() (Pydantic BaseModel), например `params=UsersParams(limit=10)`.  
   - `body` — тело запроса как Pydantic-модель (для post/put/patch/delete).  
   - `json` — dict/list (только в методах `*_response`, если не используется body).  
   - `data` — сырое тело (bytes/str/FormData).  
   - `headers` — заголовки запроса.

4. Глобальные настройки клиента  
   - `headers` — применяются ко всем запросам  
   - `add_headers(dict)` — добавить/обновить заголовки (не затирая существующие)  
   - `set_bearer_token(token)` — задать `Authorization: Bearer <token>`  
   - **cookies** — свойство, строка формата `"a=1; b=2"` (get/set).  
   - **Единая точка входа — bytes:** `cookies_to_bytes()` (сессия → bytes), `load_cookies(data: bytes)` (bytes → клиент). Хранение в БД — только bytes.  
   - **Строка Set-Cookie:** `save_cookies_to_string()` (сессия → строка), `BaseClient.cookies_string_to_bytes(s)` (строка → bytes), `load_cookies_from_string(s)` (строка → клиент).  
   - **Файл:** `save_cookies_to_file(path)`, `load_cookies_from_file(path)`.  
   - `proxy` - прокси URL  
   - `retry_on_proxy_error`, `max_retries` - повторы при ошибках прокси

5. Повторное использование  
   Один экземпляр клиента можно использовать во многих запросах и в нескольких `async with` блоках.

## Другие варианты

- **Ручное управление сессией** — без `async with`: после запросов обязательно вызвать `await client.close()`. Не рекомендуется: легко забыть закрыть сессию.
- **Наследование** — свой класс-клиент с методами API (например `get_user(id)`), внутри вызывающими `self.get(...)` / `self.post(...)`; доступен `self.logger`.
- **Свой логгер** — в конструкторе передать `logger=logging.getLogger("my.app.client")`.
- **Cookies после логина** — для БД/кэша: единая точка входа bytes — `cookies_to_bytes()` и `load_cookies(bytes)`. Строку Set-Cookie конвертировать в bytes через `BaseClient.cookies_string_to_bytes(s)` или загрузить через `load_cookies_from_string(s)`. Устаревший вариант: `extract_cookies_from_session()` (только в памяти, теряются domain/path/expires).
- **Смена настроек в процессе** — можно менять `client.headers`, `client.proxy`, `client.retry_on_proxy_error`, `client.max_retries`; при смене `client.cookies` сессия пересоздаётся при следующем запросе.
- **params с датой** — в `params` можно передавать `datetime`; будет подставлен ISO-формат с `Z`.

## Обработка ошибок (минимум)

```python
from pydantic import BaseModel

from tp_common.base_client.client import BaseClient
from tp_common.base_client.exceptions import (
    ClientException,
    ClientNetworkErrorException,
    ClientResponseErrorException,
)

class User(BaseModel):
    id: int
    name: str


try:
    async with client:
        user = await client.get("/users/1", User)
except ClientResponseErrorException:
    # HTTP 4xx/5xx
    ...
except ClientNetworkErrorException:
    # сеть/таймаут/прокси/DNS
    ...
except ClientException:
    # любая ошибка клиента
    ...
```

## Что не использовать в новом коде

- `request_text(...)`, `request_json(...)` — устарели; используйте типизированные get/post или get_response/post_response.
- **Сохранение cookies в БД через** `extract_cookies_from_session()` — устарел; сохраняйте **bytes** в БД: `client.cookies_to_bytes()` → сохранить в БД → позже `client.load_cookies(bytes)`.
