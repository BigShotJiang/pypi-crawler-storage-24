# Исключения базового HTTP-клиента

## Иерархия

```
ClientException
├── ClientResponseErrorException          # ответ с кодом >= 400
│   ├── ClientRequestErrorException       # 4xx (кроме 429)
│   │   ├── ClientAuthorizationException  # 401, 403
│   │   ├── ClientValidationException     # 400, 422
│   │   └── ClientResourceNotFoundException  # 404
│   ├── ClientTooManyRequestsException   # 429
│   └── ClientServerErrorException       # 5xx
│       ├── ClientInternalServerException # 500
│       └── ClientServiceUnavailableException  # 502, 503, 504
└── ClientNetworkErrorException          # нет ответа (сеть/соединение)
    ├── ClientConnectionException        # ошибка соединения
    ├── ClientTimeoutException           # таймаут
    ├── ClientProxyException             # ошибка прокси
    └── ClientDNSException               # ошибка DNS
```

## Атрибуты исключений

Во всех исключениях клиента (через базовый `ClientException`) доступны по необходимости:

- **message** — текст ошибки
- **url** — URL запроса
- **status_code** — HTTP-код ответа (для ошибок ответа; для сетевых ошибок — `None`)
- **response_body** — тело ответа (для ошибок ответа; для сетевых — `None`)
- **method** — HTTP-метод (GET, POST, …)
- **duration_ms** — время до ошибки или до ответа, мс
- **response_headers** — заголовки ответа как `dict[str, str]` (только для ошибок с ответом)

У **ClientProxyException** дополнительно: **proxy** — URL прокси.

## Описание классов

- **ClientException** (база: `Exception`) — базовое исключение клиента. Поля: `message`, `url`, `status_code`, `response_body`, `method`, `duration_ms`, `response_headers`.

- **ClientResponseErrorException** (база: `ClientException`) — получен HTTP-ответ с кодом >= 400. Всегда есть `status_code` и при необходимости `response_body`.

- **ClientRequestErrorException** (база: `ClientResponseErrorException`) — ошибка клиентского запроса: 400, 401, 403, 404, 422 (4xx, кроме 429).

- **ClientAuthorizationException** (база: `ClientRequestErrorException`) — 401 Unauthorized, 403 Forbidden.

- **ClientValidationException** (база: `ClientRequestErrorException`) — 400 Bad Request, 422 Unprocessable Entity.

- **ClientResourceNotFoundException** (база: `ClientRequestErrorException`) — 404 Not Found.

- **ClientTooManyRequestsException** (база: `ClientResponseErrorException`) — 429 Too Many Requests (rate limit).

- **ClientServerErrorException** (база: `ClientResponseErrorException`) — ответ сервера 5xx.

- **ClientInternalServerException** (база: `ClientServerErrorException`) — 500 Internal Server Error.

- **ClientServiceUnavailableException** (база: `ClientServerErrorException`) — 502, 503, 504.

- **ClientNetworkErrorException** (база: `ClientException`) — ответ не получен: сетевая ошибка, таймаут, прокси, DNS. Нет `status_code`.

- **ClientConnectionException** (база: `ClientNetworkErrorException`) — ошибка установки соединения (не таймаут, не DNS, не прокси).

- **ClientTimeoutException** (база: `ClientNetworkErrorException`) — таймаут запроса.

- **ClientProxyException** (база: `ClientNetworkErrorException`) — ошибка прокси. Доп. поле: `proxy`.

- **ClientDNSException** (база: `ClientNetworkErrorException`) — ошибка разрешения имени (DNS).

## Маппинг HTTP-кодов на исключения

- 400 → `ClientValidationException`
- 401, 403 → `ClientAuthorizationException`
- 404 → `ClientResourceNotFoundException`
- 422 → `ClientValidationException`
- 429 → `ClientTooManyRequestsException`
- 500 → `ClientInternalServerException`
- 502, 503, 504 → `ClientServiceUnavailableException`
- остальные 4xx → `ClientRequestErrorException`
- остальные 5xx → `ClientServerErrorException`

## Использование в коде

- Обработка по категории: `except ClientRequestErrorException`, `except ClientServerErrorException`, `except ClientNetworkErrorException`.
- Обработка по конкретному типу: `except ClientResourceNotFoundException`, `except ClientTimeoutException`.
- Общая обработка клиента: `except ClientException`.
- `ClientResponseErrorException` — любой неуспешный ответ; `ClientNetworkErrorException` — ответ не получен (сеть/таймаут/прокси/DNS).
