"""Исключения для базового HTTP клиента.

Иерархия исключений:

    ClientException
    ├── ClientResponseErrorException          # ответ с кодом >= 400
    │   ├── ClientRequestErrorException       # 4xx (кроме 429)
    │   │   ├── ClientAuthorizationException  # 401, 403
    │   │   ├── ClientValidationException     # 400, 422
    │   │   └── ClientResourceNotFoundException  # 404
    │   ├── ClientTooManyRequestsException   # 429
    │   └── ClientServerErrorException       # 5xx
    │       ├── ClientInternalServerException # 500
    │       └── ClientServiceUnavailableException  # 502, 503, 504
    └── ClientNetworkErrorException          # нет ответа (сеть/соединение)
        ├── ClientConnectionException        # ошибка соединения
        ├── ClientTimeoutException           # таймаут
        ├── ClientProxyException             # ошибка прокси
        └── ClientDNSException               # ошибка DNS

Отдельно (не в иерархии ClientException):
    ClientSessionNotOpenException(RuntimeError)   # сессия не открыта (cookies_to_bytes и т.д.)
    ClientCookieJarNotSaveableException(RuntimeError)  # cookie jar не поддерживает сохранение
"""


class ClientException(Exception):
    """Базовое исключение для всех ошибок клиента."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
        response_headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.url = url
        self.status_code = status_code
        self.response_body = response_body
        self.method = method
        self.duration_ms = duration_ms
        self.response_headers = response_headers


class ClientSessionNotOpenException(RuntimeError):
    """Сессия не открыта: операция требует активной сессии (например cookies_to_bytes)."""

    def __init__(
        self,
        message: str = "Сессия не открыта: сначала выполните запрос внутри async with",
    ) -> None:
        super().__init__(message)


class ClientCookieJarNotSaveableException(RuntimeError):
    """Текущая cookie jar не поддерживает сохранение (например DummyCookieJar)."""

    def __init__(
        self,
        message: str = "Текущая cookie jar не поддерживает сохранение (например DummyCookieJar)",
    ) -> None:
        super().__init__(message)


class ClientResponseErrorException(ClientException):
    """Исключение при неуспешном HTTP статусе (>=400)."""


class ClientRequestErrorException(ClientResponseErrorException):
    """Базовое исключение для ошибок клиентского запроса (4xx, кроме 429)."""


class ClientAuthorizationException(ClientRequestErrorException):
    """Исключение при ошибке авторизации (401, 403)."""


class ClientValidationException(ClientRequestErrorException):
    """Исключение при ошибке валидации данных (400, 422)."""


class ClientResourceNotFoundException(ClientRequestErrorException):
    """Исключение при отсутствии ресурса (404)."""


class ClientTooManyRequestsException(ClientResponseErrorException):
    """Исключение при превышении лимита запросов (429)."""


class ClientServerErrorException(ClientResponseErrorException):
    """Базовое исключение для ошибок сервера (500, 502, 503, 504)."""


class ClientInternalServerException(ClientServerErrorException):
    """Исключение при ошибке сервера (500)."""


class ClientServiceUnavailableException(ClientServerErrorException):
    """Исключение при недоступности сервиса (502, 503, 504)."""


class ClientNetworkErrorException(ClientException):
    """Базовое исключение для сетевых ошибок (ответ не получен: соединение, таймаут, прокси, DNS)."""


class ClientConnectionException(ClientNetworkErrorException):
    """Исключение при ошибке соединения (не удалось установить соединение)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)


class ClientTimeoutException(ClientNetworkErrorException):
    """Исключение при таймауте соединения."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)


class ClientProxyException(ClientNetworkErrorException):
    """Исключение при ошибке прокси."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        proxy: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)
        self.proxy = proxy


class ClientDNSException(ClientNetworkErrorException):
    """Исключение при ошибке DNS (не удалось разрешить доменное имя)."""

    def __init__(
        self,
        message: str,
        url: str | None = None,
        method: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(message, url, method=method, duration_ms=duration_ms)


def get_response_exception_class(
    status_code: int,
) -> type[ClientResponseErrorException]:
    """Возвращает класс исключения для HTTP статус-кода (>=400)."""
    if status_code in (401, 403):
        return ClientAuthorizationException
    if status_code == 404:
        return ClientResourceNotFoundException
    if status_code in (400, 422):
        return ClientValidationException
    if status_code == 429:
        return ClientTooManyRequestsException
    if status_code == 500:
        return ClientInternalServerException
    if status_code in (502, 503, 504):
        return ClientServiceUnavailableException
    if 400 <= status_code < 500:
        return ClientRequestErrorException
    if status_code >= 500:
        return ClientServerErrorException
    return ClientResponseErrorException
