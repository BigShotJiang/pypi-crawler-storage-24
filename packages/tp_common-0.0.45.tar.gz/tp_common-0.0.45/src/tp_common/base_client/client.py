import asyncio
import json as json_lib
import logging
import pickle
import re
import time
import warnings
from collections import defaultdict
from datetime import UTC, datetime
from http.cookies import Morsel, SimpleCookie
from pathlib import Path
from typing import Any, Literal, Protocol, TypeVar
from urllib.parse import urlencode

import aiohttp
from aiohttp import (
    ClientConnectionError,
    ClientConnectorDNSError,
    ClientHttpProxyError,
    ClientProxyConnectionError,
    ServerTimeoutError,
)

from tp_common.base_client.exceptions import (
    ClientConnectionException,
    ClientCookieJarNotSaveableException,
    ClientDNSException,
    ClientException,
    ClientProxyException,
    ClientResponseErrorException,
    ClientSessionNotOpenException,
    ClientTimeoutException,
    get_response_exception_class,
)

T = TypeVar("T", bound="BaseClient")

MAX_LOG_FIELD_LENGTH = 1000


def _truncate_for_log(value: Any) -> Any:
    """Обрезает строку до MAX_LOG_FIELD_LENGTH символов для лога."""
    if isinstance(value, str) and len(value) > MAX_LOG_FIELD_LENGTH:
        return value[:MAX_LOG_FIELD_LENGTH] + "… (обрезано)"
    return value


class ResponseSchema(Protocol):
    """Протокол для схемы ответа: класс с model_validate() (например Pydantic BaseModel)."""

    @classmethod
    def model_validate(cls, obj: Any) -> Any: ...


R = TypeVar("R", bound=ResponseSchema)


class BodySchema(Protocol):
    """Протокол для тела запроса: объект с model_dump() (например Pydantic BaseModel)."""

    def model_dump(self) -> dict[str, Any]: ...


def _charset_from_headers(headers: dict[str, str]) -> str | None:
    """Извлекает charset из заголовка Content-Type."""
    for key, value in headers.items():
        if key.lower() == "content-type" and value:
            match = re.search(r"charset=([^;\s]+)", value, re.IGNORECASE)
            if match:
                return match.group(1).strip("'\"").lower()
    return None


class ClientResponse:
    """
    Обёртка ответа HTTP. Позволяет получить тело как bytes, текст или JSON.

    Пример:
        resp = await client.get_response("/items")  # или post_response, put_response и т.д.
        data = resp.json()
        raw = resp.bytes()
        txt = resp.text()
    """

    __slots__ = ("_body", "_headers", "_url", "_status_code")

    def __init__(
        self,
        body: bytes,
        headers: dict[str, str] | None = None,
        url: str | None = None,
        status_code: int | None = None,
    ) -> None:
        self._body = body
        self._headers = dict(headers or {})
        self._url = url
        self._status_code = status_code

    def bytes(self) -> bytes:
        """Возвращает тело ответа как байты."""
        return self._body

    def text(self, encoding: str | None = None) -> str:
        """
        Возвращает тело ответа как строку.
        Если encoding не указан, используется charset из Content-Type или utf-8.
        """
        enc = encoding or _charset_from_headers(self._headers) or "utf-8"
        encodings_to_try: list[str | tuple[str, str]] = [
            enc,
            "utf-8",
            "cp1251",
            ("iso-8859-1", "replace"),
        ]
        for entry in encodings_to_try:
            if isinstance(entry, tuple):
                enc_name, errors = entry
            else:
                enc_name, errors = entry, "strict"
            try:
                return self._body.decode(enc_name, errors=errors)
            except (UnicodeDecodeError, LookupError):
                continue
        return self._body.decode("iso-8859-1", errors="replace")

    def json(self) -> dict[str, Any] | list[Any]:
        """Парсит тело ответа как JSON и возвращает dict или list."""
        return json_lib.loads(self._body.decode("utf-8", errors="replace"))

    @property
    def url(self) -> str | None:
        """URL запроса."""
        return self._url

    @property
    def status_code(self) -> int | None:
        """HTTP статус-код ответа."""
        return self._status_code

    @property
    def headers(self) -> dict[str, str]:
        """Заголовки ответа."""
        return self._headers.copy()


class BaseClient:
    """
    Базовый HTTP клиент для работы с внешними API.

    Поддерживает:
    - Переиспользование сессии
    - Прокси
    - Cookies
    - Заголовки (задаются один раз, применяются к каждому запросу; есть встроенные значения по умолчанию)
    - Имитацию браузера
    - Логирование (с автоматическим созданием логгера при необходимости)
    - Переопределение базового URL для тестирования

    Args:
        base_url: Базовый URL для запросов (обязательный параметр)
        cookies: Строка с cookies в формате "name=value; name2=value2"
        proxy: URL прокси-сервера
        logger: Внешний логгер (если не передан, создается автоматически)
        headers: Заголовки клиента: задаются один раз и применяются к каждому запросу (дополняют встроенные;
            можно переопределить позже через свойство headers)
        retry_on_proxy_error: Повторять ли запрос при ошибках прокси (можно переопределить через свойство)
        max_retries: Максимум попыток при retry_on_proxy_error (можно переопределить через свойство)
    """

    DEFAULT_TIMEOUT = 30.0  # секунды

    def __init__(
        self,
        base_url: str,
        cookies: str | None = None,
        proxy: str | None = None,
        logger: logging.Logger | None = None,
        headers: dict[str, Any] | None = None,
        retry_on_proxy_error: bool = False,
        max_retries: int = 5,
    ):
        self._raw_cookies = cookies
        self._proxy: str | None = proxy
        self._session: aiohttp.ClientSession | None = None
        self._cookies_file: str | Path | None = None
        self._cookies_data: bytes | None = None
        self._logger = logger or self._create_logger()
        # Нормализуем один раз, чтобы при склейке с URI не появлялся двойной слеш.
        self._base_url = base_url.rstrip("/")
        self.headers = headers
        self._retry_on_proxy_error = retry_on_proxy_error
        self._max_retries = max_retries

    def _create_logger(self) -> logging.Logger:
        """Создает логгер на основе имени класса, если не передан внешний."""
        class_name = self.__class__.__name__
        module_name = self.__class__.__module__
        logger_name = f"{module_name}.{class_name}"
        return logging.getLogger(logger_name)

    @property
    def logger(self) -> logging.Logger:
        """Возвращает логгер для использования в наследниках."""
        return self._logger

    @logger.setter
    def logger(self, logger: logging.Logger) -> None:
        self._logger = logger

    async def __aenter__(self: T) -> T:
        """Инициализация сессии при входе в контекстный менеджер"""
        _ = await self._get_session()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Закрытие сессии при выходе из контекстного менеджера"""
        await self.close()

    async def _get_session(self) -> aiohttp.ClientSession:
        """Получает или создает переиспользуемую сессию"""
        if self._session is None or self._session.closed:
            self._logger.debug(
                "Создание HTTP сессии (timeout=%.1fs)",
                self.DEFAULT_TIMEOUT,
            )
            timeout = aiohttp.ClientTimeout(total=self.DEFAULT_TIMEOUT)
            connector = aiohttp.TCPConnector(limit=100, limit_per_host=30)

            if self._cookies_data is not None:
                jar = aiohttp.CookieJar()
                jar._cookies = pickle.loads(self._cookies_data)
                self._session = aiohttp.ClientSession(
                    timeout=timeout,
                    connector=connector,
                    cookie_jar=jar,
                )
            elif self._cookies_file is not None:
                jar = aiohttp.CookieJar()
                jar.load(self._cookies_file)
                self._session = aiohttp.ClientSession(
                    timeout=timeout,
                    connector=connector,
                    cookie_jar=jar,
                )
            else:
                self._session = aiohttp.ClientSession(
                    timeout=timeout,
                    connector=connector,
                    cookies=self._prepare_cookies_dict(),
                )
        return self._session

    async def close(self) -> None:
        """Закрывает HTTP сессию"""
        if self._session and not self._session.closed:
            self._logger.debug("Закрытие HTTP сессии")
            await self._session.close()
            self._session = None

    def _get_builtin_default_headers(self) -> dict[str, str]:
        """Встроенные заголовки по умолчанию (имитация браузера). Всегда применяются."""
        return {
            "accept": "*/*",
            "accept-language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": '"Chromium";v="122"',
            "sec-ch-ua-mobile": "?0",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "referer": f"{self._base_url}/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        }

    def _get_default_headers(self) -> dict[str, str]:
        """Возвращает базовые заголовки для запроса: встроенные + заголовки клиента (headers)."""
        out = self._get_builtin_default_headers()
        if self._headers:
            out.update(self._headers)
        return out

    @property
    def headers(self) -> dict[str, str]:
        """Заголовки клиента: задаются один раз и применяются к каждому запросу."""
        return self._headers.copy()

    @headers.setter
    def headers(self, value: dict[str, Any] | None) -> None:
        """Задать заголовки клиента — они будут использоваться во всех запросах."""
        self._headers = {k: str(v) for k, v in (value or {}).items()}

    def add_headers(self, headers: dict[str, Any]) -> None:
        """Добавляет или обновляет заголовки клиента (объединяет с существующими)."""
        if headers:
            self._headers.update({k: str(v) for k, v in headers.items()})

    def set_bearer_token(self, token: str) -> None:
        """Задаёт заголовок Authorization: Bearer <token> для всех последующих запросов."""
        self.add_headers({"Authorization": f"Bearer {token}"})

    @property
    def retry_on_proxy_error(self) -> bool:
        """Повторять ли запрос при ошибках прокси."""
        return self._retry_on_proxy_error

    @retry_on_proxy_error.setter
    def retry_on_proxy_error(self, value: bool) -> None:
        self._retry_on_proxy_error = value

    @property
    def max_retries(self) -> int:
        """Максимум попыток при retry_on_proxy_error."""
        return self._max_retries

    @max_retries.setter
    def max_retries(self, value: int) -> None:
        self._max_retries = value

    @property
    def cookies(self) -> str | None:
        """Возвращает текущие cookies"""
        return self._raw_cookies

    @cookies.setter
    def cookies(self, cookies: str) -> None:
        """Устанавливает новые cookies (требует пересоздания сессии)"""
        self._raw_cookies = cookies
        self._cookies_file = None
        self._cookies_data = None
        # Сразу обнуляем _session, чтобы следующий _get_session() создал новую сессию
        # с новыми cookies; старую сессию закрываем в фоне (иначе гонка: запрос
        # может получить уже закрываемую сессию → "Connector is closed")
        old_session = self._session
        self._session = None
        if old_session and not old_session.closed:

            async def _close_old() -> None:
                await old_session.close()

            asyncio.create_task(_close_old())

    @property
    def proxy(self) -> str | None:
        """Возвращает текущий прокси"""
        return self._proxy

    @proxy.setter
    def proxy(self, proxy: str) -> None:
        """Устанавливает новый прокси"""
        self._proxy = proxy

    def _prepare_cookies_dict(self) -> dict[str, str] | None:
        """Подготавливает словарь cookies из строки для aiohttp"""
        if not self._raw_cookies:
            return None

        cookies_dict: dict[str, str] = {}

        # Парсим строку cookies в формате "name=value; name2=value2"
        for cookie_str in self._raw_cookies.split(";"):
            cookie_str = cookie_str.strip()
            if not cookie_str:
                continue
            if "=" in cookie_str:
                name, value = cookie_str.split("=", 1)
                cookies_dict[name.strip()] = value.strip()

        return cookies_dict if cookies_dict else None

    def extract_cookies_from_session(self) -> str | None:
        """
        Извлекает cookies из текущей сессии в строку формата 'name=value; name2=value2'.

        .. deprecated::
            Устарел. Для сохранения в БД/кэш используйте :meth:`cookies_to_bytes` — возвращает
            bytes (полная сериализация: domain, path, expires); сохраняйте эти байты в БД
            и восстанавливайте через :meth:`load_cookies`.

        Returns:
            Строка с кукисами в формате 'name=value; name2=value2' или None
        """
        warnings.warn(
            "extract_cookies_from_session устарел: используйте cookies_to_bytes() и сохраняйте bytes в БД, восстанавливайте через load_cookies().",
            DeprecationWarning,
            stacklevel=2,
        )
        if not self._session or self._session.closed:
            return self._raw_cookies

        cookies_list: list[str] = []
        for cookie in self._session.cookie_jar:
            cookies_list.append(f"{cookie.key}={cookie.value}")

        if not cookies_list:
            return self._raw_cookies

        return "; ".join(cookies_list)

    def cookies_to_bytes(self) -> bytes:
        """
        Сериализует все cookies текущей сессии в bytes (pickle).

        Сохраняются domain, path, expires и т.д. Вызывать при открытой сессии.
        Результат можно передать в load_cookies() или сохранить (БД, кэш).
        """
        if self._session is None or self._session.closed:
            raise ClientSessionNotOpenException()

        jar = self._session.cookie_jar
        if not isinstance(jar, aiohttp.CookieJar):
            raise ClientCookieJarNotSaveableException()

        return pickle.dumps(jar._cookies, pickle.HIGHEST_PROTOCOL)

    def load_cookies(self, data: bytes) -> None:
        """
        Загружает cookies из объекта (bytes от cookies_to_bytes) при следующем создании сессии.

        Полное восстановление (domain, path, expires, secure и т.д.). Текущая сессия
        будет закрыта; при следующем запросе создастся новая с этими cookies.
        """
        self._cookies_data = data
        self._cookies_file = None
        old_session = self._session
        self._session = None
        if old_session and not old_session.closed:

            async def _close_old() -> None:
                await old_session.close()

            asyncio.create_task(_close_old())

    def save_cookies_to_file(self, file_path: str | Path) -> None:
        """
        Сохраняет все cookies текущей сессии в файл (domain, path, expires и т.д.).

        Использует aiohttp.CookieJar.save. Вызывать при открытой сессии
        (внутри async with или после хотя бы одного запроса).
        """
        if self._session is None or self._session.closed:
            raise ClientSessionNotOpenException()
        jar = self._session.cookie_jar
        if not isinstance(jar, aiohttp.CookieJar):
            raise ClientCookieJarNotSaveableException()
        jar.save(file_path)

    def save_cookies_to_string(self) -> str:
        """
        Возвращает cookies текущей сессии в формате заголовка Set-Cookie.

        Строка вида «Set-Cookie: name=value; Domain=...; Path=...; Expires=...;
        HttpOnly; Secure; SameSite=...». Несколько cookie разделяются переводом строки.
        Вызывать при открытой сессии. Единая точка входа для хранения — bytes: чтобы
        снова получить bytes из этой строки, вызовите :meth:`cookies_string_to_bytes`
        и затем :meth:`load_cookies`.
        """
        if self._session is None or self._session.closed:
            raise ClientSessionNotOpenException()
        jar = self._session.cookie_jar
        if not isinstance(jar, aiohttp.CookieJar):
            raise ClientCookieJarNotSaveableException()
        lines: list[str] = []
        for simple_cookie in jar._cookies.values():
            out = simple_cookie.output(header="Set-Cookie: ", sep="\r\n")
            for line in out.split("\r\n"):
                line = line.strip()
                if line:
                    lines.append(line)
        return "\n".join(lines)

    @staticmethod
    def cookies_string_to_bytes(data: str) -> bytes:
        """
        Конвертирует строку в формате Set-Cookie в bytes (тот же формат, что у cookies_to_bytes()).

        Единая точка входа для cookies — bytes. Строка из :meth:`save_cookies_to_string`
        или из заголовков ответа парсится в структуру jar и сериализуется в bytes;
        результат можно передать в :meth:`load_cookies` или сохранить в БД.
        """
        cookies_dict: defaultdict[tuple[str, str], SimpleCookie] = defaultdict(
            SimpleCookie
        )
        for line in data.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            if line.lower().startswith("set-cookie:"):
                line = line[len("set-cookie:") :].strip()
            parts = [p.strip() for p in line.split(";")]
            if not parts or "=" not in parts[0]:
                continue
            name, value = parts[0].split("=", 1)
            name, value = name.strip(), value.strip()
            morsel: Morsel[str] = Morsel()
            morsel.set(name, value, value)
            for part in parts[1:]:
                if "=" in part:
                    attr, attr_val = part.split("=", 1)
                    attr = attr.strip().lower()
                    attr_val = attr_val.strip()
                    if attr in ("domain", "path", "expires", "max-age", "samesite"):
                        morsel[attr] = attr_val
                else:
                    flag = part.lower()
                    if flag == "secure":
                        morsel["secure"] = True
                    elif flag == "httponly":
                        morsel["httponly"] = True
            domain = morsel.get("domain", "")
            path = (morsel.get("path", "") or "/").rstrip("/") or "/"
            if domain and domain.startswith("."):
                domain = domain[1:]
            key = (domain, path)
            cookies_dict[key][name] = morsel
        return pickle.dumps(dict(cookies_dict), pickle.HIGHEST_PROTOCOL)

    def load_cookies_from_string(self, data: str) -> None:
        """
        Загружает cookies из строки в формате Set-Cookie при следующем создании сессии.

        Ожидается строка вида «Set-Cookie: name=value; Domain=...; Path=...; ...»
        (одна или несколько строк через перевод строки). Внутри конвертирует в bytes
        через :meth:`cookies_string_to_bytes` и вызывает :meth:`load_cookies`.
        """
        self.load_cookies(BaseClient.cookies_string_to_bytes(data))

    def load_cookies_from_file(self, file_path: str | Path) -> None:
        """
        Загружает cookies из файла при следующем создании сессии.

        Полное восстановление (domain, path, expires, secure и т.д.). Текущая сессия
        будет закрыта; при следующем запросе создастся новая с cookies из файла.
        """
        self._cookies_file = (
            Path(file_path) if isinstance(file_path, str) else file_path
        )
        self._cookies_data = None
        old_session = self._session
        self._session = None
        if old_session and not old_session.closed:

            async def _close_old() -> None:
                await old_session.close()

            asyncio.create_task(_close_old())

    def _build_url(self, uri: str, params: dict[str, Any] | None = None) -> str:
        """Строит полный URL из базового адреса, URI и параметров (params — dict из схемы model_dump())."""
        url = f"{self._base_url}/{uri.lstrip('/')}"

        if params:
            # Фильтруем None значения и конвертируем все значения в строки для urlencode
            filtered_params: dict[str, str] = {}
            for key, val in params.items():
                if val is not None:
                    # Для datetime объектов используем ISO формат с Z и миллисекундами
                    if isinstance(val, datetime):
                        # Формат: 2026-01-20T00:00:00.000Z
                        if val.tzinfo is not None:
                            val_utc = val.astimezone(UTC)
                            filtered_params[key] = (
                                val_utc.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                            )
                        else:
                            filtered_params[key] = (
                                val.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                            )
                    else:
                        filtered_params[key] = str(val)
            if filtered_params:
                query_string = urlencode(filtered_params, doseq=False)
                url += "?" + query_string

        return url

    def _merge_headers(self, custom_headers: dict[str, Any] | None) -> dict[str, str]:
        """Объединяет заголовки: встроенные → headers клиента → заголовки запроса."""
        headers = self._get_default_headers()
        if custom_headers:
            headers.update({k: str(v) for k, v in custom_headers.items()})
        return headers

    def _prepare_payload(
        self, json: Any, data: Any | None
    ) -> dict[str, Any] | list[Any] | str | None:
        """Подготавливает payload для логирования"""
        if json is not None:
            return json
        if data is not None:
            if isinstance(data, str):
                try:
                    return json_lib.loads(data)
                except (json_lib.JSONDecodeError, TypeError):
                    return None
            elif isinstance(data, (dict, list)):
                return data
            return None
        return None

    def _prepare_response(self, response_text: str) -> dict[str, Any] | list[Any] | str:
        """Подготавливает response для логирования: пытается распарсить JSON, иначе возвращает текст"""
        if not response_text:
            return response_text
        try:
            return json_lib.loads(response_text)
        except (json_lib.JSONDecodeError, TypeError):
            return response_text

    def _decode_response_body(
        self, body_bytes: bytes, response: aiohttp.ClientResponse
    ) -> str:
        """
        Декодирует тело ответа в строку с учётом кодировки из заголовков
        и резервных кодировок при ошибке UTF-8 (например, cp1251 для российских API).
        """
        encodings_to_try: list[str | tuple[str, str]] = []
        if response.charset:
            encodings_to_try.append(response.charset)
        encodings_to_try.append("utf-8")
        encodings_to_try.append("cp1251")  # Windows-1251, типично для российских API
        encodings_to_try.append(("iso-8859-1", "replace"))
        for entry in encodings_to_try:
            if isinstance(entry, tuple):
                encoding, errors = entry
            else:
                encoding, errors = entry, "strict"
            try:
                return body_bytes.decode(encoding, errors=errors)
            except (UnicodeDecodeError, LookupError):
                continue
        return body_bytes.decode("iso-8859-1", errors="replace")

    def _body_to_dict(self, body: BodySchema) -> dict[str, Any]:
        """Преобразует схему тела (Pydantic BaseModel и т.п.) в dict через model_dump()."""
        return body.model_dump()

    def _params_to_dict(self, params: BodySchema | None) -> dict[str, Any] | None:
        """Преобразует params-схему в dict для query-строки (model_dump())."""
        if params is None:
            return None
        return params.model_dump()

    async def _make_request_response(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> ClientResponse:
        """
        Выполняет HTTP запрос и возвращает обёртку ClientResponse (body bytes + заголовки).

        params — query-параметры только как схема с model_dump() (Pydantic BaseModel).
        json — тело запроса как dict или list. body — схема с model_dump(); при указании имеет приоритет над json.
        data — сырое тело запроса (bytes, str, FormData и т.п.), если не используется json/body.
        """
        url = self._build_url(uri, self._params_to_dict(params))
        merged_headers = self._merge_headers(headers)
        session = await self._get_session()

        if body is not None:
            json_payload: dict[str, Any] | list[Any] | None = self._body_to_dict(body)
        else:
            json_payload = json

        request_kwargs: dict[str, Any] = {
            "url": url,
            "headers": merged_headers,
            "proxy": self._proxy,
        }

        if json_payload is not None:
            request_kwargs["json"] = json_payload
        elif data is not None:
            request_kwargs["data"] = data

        payload = self._prepare_payload(json_payload, data)
        amount_failed = 0

        while True:
            response_body_text = ""
            start_time = time.perf_counter()
            self._logger.info(
                "Запрос: %s %s", method, url, extra={"method": method, "url": url}
            )
            try:
                async with session.request(method, **request_kwargs) as response:
                    body_bytes = await response.read()
                    response_body_text = self._decode_response_body(
                        body_bytes, response
                    )
                    end_time = time.perf_counter()
                    duration_ms = int((end_time - start_time) * 1000)

                    response_data = self._prepare_response(response_body_text)

                    self._logger.info(
                        "HTTP запрос выполнен: %s %s — %s, %d ms",
                        method,
                        url,
                        response.status,
                        duration_ms,
                        extra={
                            "url": url,
                            "method": method,
                            "status_code": response.status,
                            "payload": _truncate_for_log(payload),
                            "response": _truncate_for_log(response_data),
                            "duration": duration_ms,
                        },
                    )

                    if response.status >= 400:
                        exc_cls = get_response_exception_class(response.status)
                        raise exc_cls(
                            f"HTTP {response.status} error: {response.reason}",
                            url=url,
                            status_code=response.status,
                            response_body=response_body_text,
                            method=method,
                            duration_ms=duration_ms,
                            response_headers=dict(response.headers),
                        )

                    return ClientResponse(
                        body=body_bytes,
                        headers=dict(response.headers),
                        url=url,
                        status_code=response.status,
                    )

            except (ClientHttpProxyError, ClientProxyConnectionError) as e:
                if not self._retry_on_proxy_error:
                    self._logger.error(
                        "Ошибка прокси при HTTP запросе",
                        extra={
                            "method": method,
                            "url": url,
                            "proxy": self._proxy,
                            "error": str(e),
                        },
                    )
                    duration_ms = int((time.perf_counter() - start_time) * 1000)
                    raise ClientProxyException(
                        f"Proxy error: {str(e)}",
                        url=url,
                        proxy=self._proxy,
                        method=method,
                        duration_ms=duration_ms,
                    ) from e

                amount_failed += 1
                if amount_failed >= self._max_retries:
                    self._logger.error(
                        "Ошибка прокси после исчерпания попыток",
                        extra={
                            "method": method,
                            "url": url,
                            "proxy": self._proxy,
                            "retries": amount_failed,
                            "error": str(e),
                        },
                    )
                    duration_ms = int((time.perf_counter() - start_time) * 1000)
                    raise ClientProxyException(
                        f"Proxy error after {self._max_retries} retries: {str(e)}",
                        url=url,
                        proxy=self._proxy,
                        method=method,
                        duration_ms=duration_ms,
                    ) from e

                self._logger.warning(
                    "Повтор запроса после ошибки прокси",
                    extra={
                        "method": method,
                        "url": url,
                        "proxy": self._proxy,
                        "retry": amount_failed,
                        "max_retries": self._max_retries,
                    },
                )
                continue

            except (TimeoutError, ServerTimeoutError) as e:
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                self._logger.warning(
                    "Таймаут HTTP запроса: %s %s (%.1fs)",
                    method,
                    url,
                    self.DEFAULT_TIMEOUT,
                    extra={
                        "method": method,
                        "url": url,
                        "timeout": self.DEFAULT_TIMEOUT,
                        "duration_ms": duration_ms,
                        "error": str(e),
                    },
                )
                raise ClientTimeoutException(
                    f"Request timeout after {self.DEFAULT_TIMEOUT}s: {str(e)}",
                    url=url,
                    method=method,
                    duration_ms=duration_ms,
                ) from e

            except ClientConnectorDNSError as e:
                self._logger.error(
                    "Ошибка DNS при HTTP запросе",
                    extra={
                        "method": method,
                        "url": url,
                        "error": str(e),
                    },
                )
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                raise ClientDNSException(
                    f"DNS resolution failed: {str(e)}",
                    url=url,
                    method=method,
                    duration_ms=duration_ms,
                ) from e

            except ClientConnectionError as e:
                self._logger.error(
                    "Ошибка соединения при HTTP запросе",
                    extra={
                        "method": method,
                        "url": url,
                        "error": str(e),
                    },
                )
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                raise ClientConnectionException(
                    f"Connection error: {str(e)}",
                    url=url,
                    method=method,
                    duration_ms=duration_ms,
                ) from e
            except ClientResponseErrorException as e:
                raise e
            except Exception as e:
                # Неожиданные ошибки
                self._logger.error(
                    "Неожиданная ошибка HTTP запроса",
                    extra={
                        "method": method,
                        "url": url,
                        "error_type": type(e).__name__,
                        "error": str(e),
                        "response": response_body_text or "",
                    },
                )
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                raise ClientException(
                    f"Неожиданная HTTP-ошибка: {str(e)}",
                    url=url,
                    method=method,
                    duration_ms=duration_ms,
                    response_body=response_body_text or None,
                ) from e

    async def _make_request(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> str:
        """Выполняет запрос и возвращает тело ответа как строку. Используется request_text/request_json (deprecated)."""
        resp = await self._make_request_response(
            method=method,
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )
        return resp.text()

    async def get_response(
        self,
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
    ) -> ClientResponse:
        """GET запрос. Возвращает ClientResponse (сырой ответ: .json(), .text(), .bytes(), .status_code, .headers)."""
        return await self._make_request_response(
            method="GET",
            uri=uri,
            headers=headers,
            params=params,
        )

    async def get(
        self,
        uri: str,
        response_schema: type[R],
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
    ) -> R:
        """GET запрос. Возвращает типизированную модель (response_schema.model_validate от JSON-ответа)."""
        resp = await self.get_response(uri, headers=headers, params=params)
        return response_schema.model_validate(resp.json())

    async def post_response(
        self,
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> ClientResponse:
        """POST запрос. Возвращает ClientResponse (сырой ответ)."""
        return await self._make_request_response(
            method="POST",
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )

    async def post(
        self,
        uri: str,
        response_schema: type[R],
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> R:
        """POST запрос. Возвращает типизированную модель (response_schema.model_validate от JSON-ответа)."""
        resp = await self.post_response(
            uri, headers=headers, params=params, json=json, body=body, data=data
        )
        return response_schema.model_validate(resp.json())

    async def put_response(
        self,
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> ClientResponse:
        """PUT запрос. Возвращает ClientResponse (сырой ответ)."""
        return await self._make_request_response(
            method="PUT",
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )

    async def put(
        self,
        uri: str,
        response_schema: type[R],
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> R:
        """PUT запрос. Возвращает типизированную модель."""
        resp = await self.put_response(
            uri, headers=headers, params=params, json=json, body=body, data=data
        )
        return response_schema.model_validate(resp.json())

    async def patch_response(
        self,
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> ClientResponse:
        """PATCH запрос. Возвращает ClientResponse (сырой ответ)."""
        return await self._make_request_response(
            method="PATCH",
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )

    async def patch(
        self,
        uri: str,
        response_schema: type[R],
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> R:
        """PATCH запрос. Возвращает типизированную модель."""
        resp = await self.patch_response(
            uri, headers=headers, params=params, json=json, body=body, data=data
        )
        return response_schema.model_validate(resp.json())

    async def delete_response(
        self,
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> ClientResponse:
        """DELETE запрос. Возвращает ClientResponse (сырой ответ)."""
        return await self._make_request_response(
            method="DELETE",
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )

    async def delete(
        self,
        uri: str,
        response_schema: type[R],
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> R:
        """DELETE запрос. Возвращает типизированную модель."""
        resp = await self.delete_response(
            uri, headers=headers, params=params, json=json, body=body, data=data
        )
        return response_schema.model_validate(resp.json())

    async def request_text(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> str:
        """
        Выполняет HTTP запрос и возвращает ответ как строку.

        .. deprecated::
            Используйте методы по методу запроса и :meth:`ClientResponse.text()`:
            ``(await client.get_response(uri)).text()``, ``(await client.post_response(uri, body=...)).text()`` и т.д.
        """
        warnings.warn(
            "request_text устарел: используйте client.get_response(uri).text() или client.post_response(uri, body=...).text() и т.д.",
            DeprecationWarning,
            stacklevel=2,
        )
        return await self._make_request(
            method=method,
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )

    async def request_json(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
    ) -> dict[str, Any] | list[Any]:
        """
        Выполняет HTTP запрос и возвращает ответ как распарсенный JSON.

        .. deprecated::
            Используйте методы по методу запроса и :meth:`ClientResponse.json()`:
            ``(await client.get(uri, SomeSchema))`` для типизированного ответа или ``(await client.get_response(uri)).json()``.
        """
        warnings.warn(
            "request_json устарел: используйте client.get(uri, SomeSchema) или client.get_response(uri).json() и т.д.",
            DeprecationWarning,
            stacklevel=2,
        )
        resp = await self._make_request_response(
            method=method,
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            body=body,
            data=data,
        )
        try:
            return resp.json()
        except json_lib.JSONDecodeError as e:
            url = self._build_url(uri, self._params_to_dict(params))
            self._logger.error(
                "Не удалось распарсить ответ как JSON",
                extra={
                    "method": method,
                    "url": url,
                    "response": resp.text(),
                    "error": str(e),
                },
            )
            raise
