# Асинхронный Event Service (BaseEventAsync)

## Описание

`BaseEventAsync` — асинхронная версия `BaseEvent` для работы с событиями Kafka через библиотеку `aiokafka`. Полностью совместима с синхронной версией по структуре классов и API, но использует `async/await`.

## Когда использовать

- **Асинхронные приложения**: FastAPI, aiohttp, asyncio-based сервисы
- **Высокая нагрузка**: когда нужно обрабатывать много конкурентных соединений
- **Non-blocking операции**: когда важно не блокировать event loop

## Отличия от синхронной версии

| Аспект | BaseEvent (sync) | BaseEventAsync (async) |
|--------|------------------|------------------------|
| Библиотека | confluent-kafka | aiokafka |
| Контекстный менеджер | `with` | `async with` |
| Методы | обычные | `async def` с `await` |
| Consumer/Producer | Consumer, Producer | AIOKafkaConsumer, AIOKafkaProducer |
| Retry декоратор | `@retry_sync` | `@retry_async` |

## Использование

### 1. Определение сервиса событий

Структура класса **точно такая же**, как в синхронной версии:

```python
from enum import Enum
from pydantic import BaseModel
from tp_common.event_service.schemas import BaseEventMessage
from tp_common.event_service.service_async import BaseEventAsync
from tp_common.kafka.connector import KafkaConnector

class EventGroup(str, Enum):
    USERS = "users"

class UserEvent(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    CHANGE_NAME = "change_name"

class User(BaseModel):
    id: int
    name: str
    is_active: bool

class UserEventMessage(BaseEventMessage[User, UserEvent]):
    """Сообщение события пользователя."""

class UserEventService(BaseEventAsync[UserEventMessage, UserEvent]):
    """Асинхронный дескриптор события пользователей."""
    
    SERVICE_NAME = "postgres"
    EVENT_GROUP = EventGroup.USERS
    MESSAGE_CLASS = UserEventMessage
    EVENT_TYPE_CLASS = UserEvent
```

### 2. Создание экземпляра

```python
connector = KafkaConnector("sasl_plaintext://user:pass@host:9094")
logger = logging.getLogger(__name__)

event_service = UserEventService(
    connector=connector,
    consumer_group="my_consumer_group",
    log=logger,
    subscribe_to=[UserEvent.CREATE, UserEvent.UPDATE],  # опционально
    retry_enabled=True,  # по умолчанию
)
```

### 3. Чтение событий

**Важно**: используйте `async with` вместо `with`!

```python
async def consume_events():
    """Обработка событий из Kafka."""
    
    async with event_service.subscription():
        while True:
            async with event_service.pop(timeout=60) as message:
                if message is None:
                    continue
                
                print(f"Event: {message.event}")
                print(f"Before: {message.before}")
                print(f"After: {message.after}")
                
                # Ваша бизнес-логика здесь
                await process_user_event(message)
```

### 4. Публикация событий

```python
async def publish_event():
    """Отправка события в Kafka."""
    
    message = UserEventMessage(
        event=UserEvent.CREATE,
        after=User(id=1, name="John", is_active=True),
    )
    
    # send_and_wait делает flush автоматически
    await event_service.publish(message)
```

### 5. Полный пример

```python
import asyncio

async def main():
    """Основной цикл обработки событий."""
    
    while True:
        try:
            async with event_service.subscription():
                while True:
                    async with event_service.pop() as message:
                        
                        # Обработка события
                        print(f"Received: {message.event}")
                        
                        # Публикация нового события
                        if message.event == UserEvent.CREATE:
                            new_message = UserEventMessage(
                                event=UserEvent.CHANGE_NAME,
                                after=message.after,
                            )
                            await event_service.publish(new_message)
        
        except Exception as e:
            logger.exception("Ошибка в цикле: %s", e)
            await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(main())
```

## Обработка ошибок

### Автоматический retry

Декоратор `@retry_async` автоматически повторяет операции при ошибках:
- Подписка на топик
- Чтение сообщений
- Commit
- Публикация

```python
# Отключить retry (например, для тестов)
event_service = UserEventService(
    connector=connector,
    consumer_group="test_group",
    log=logger,
    retry_enabled=False,  # отключить автоповторы
)
```

### Несовпадение схем

При ошибке парсинга (несовпадение схемы) сервис автоматически:
1. Логирует Critical
2. Останавливает обработку (unsub + close)
3. Входит в бесконечный цикл алертов (каждые 10 минут)

```python
async def schema_alert(msg: str):
    """Custom alert handler."""
    await send_to_telegram(msg)
    # или await send_to_sentry(msg)

event_service = UserEventService(
    connector=connector,
    consumer_group="my_group",
    log=logger,
    schema_alert_interval_seconds=300,  # 5 минут
    schema_alert_callback=schema_alert,  # async или sync
)
```

## Фильтрация событий

### По типу события

```python
# Обрабатывать только CREATE и UPDATE
event_service = UserEventService(
    connector=connector,
    consumer_group="my_group",
    log=logger,
    subscribe_to=[UserEvent.CREATE, UserEvent.UPDATE],
)

# Все остальные события будут автоматически закоммичены и пропущены
```

### Auto-commit

```python
# Включить автоматический commit после чтения
event_service.enable_auto_commit()

async with event_service.subscription():
    while True:
        async with event_service.pop() as message:
            # commit происходит автоматически перед обработкой
            process(message)
```

## Интеграция с FastAPI

```python
from fastapi import FastAPI
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle для FastAPI."""
    
    # Startup: запуск consumer в фоне
    task = asyncio.create_task(consume_events())
    
    yield
    
    # Shutdown: остановка consumer
    task.cancel()
    await event_service.close()

app = FastAPI(lifespan=lifespan)

@app.post("/users")
async def create_user(user: User):
    """API endpoint с публикацией события."""
    
    # Сохранение в БД
    await save_user(user)
    
    # Публикация события
    message = UserEventMessage(
        event=UserEvent.CREATE,
        after=user,
    )
    await event_service.publish(message)
    
    return {"status": "ok"}
```

## Миграция с синхронной версии

### Что нужно изменить

1. **Импорт**:
   ```python
   # Было
   from tp_common.event_service.service import BaseEvent
   
   # Стало
   from tp_common.event_service.service_async import BaseEventAsync
   ```

2. **Наследование**:
   ```python
   # Было
   class UserEventService(BaseEvent[UserEventMessage, UserEvent]):
   
   # Стало
   class UserEventService(BaseEventAsync[UserEventMessage, UserEvent]):
   ```

3. **Использование**:
   ```python
   # Было
   with event.subscription():
       while True:
           with event.pop() as message:
               event.publish(message)
   
   # Стало
   async with event.subscription():
       while True:
           async with event.pop() as message:
               await event.publish(message)
   ```

### Что НЕ нужно менять

- ✅ ClassVar атрибуты (SERVICE_NAME, EVENT_GROUP, etc.)
- ✅ Структура MESSAGE_CLASS и EVENT_TYPE_CLASS
- ✅ Логика парсинга и валидации
- ✅ Фильтрация событий
- ✅ Обработка ошибок схемы

## Производительность

### Преимущества async версии

- **Меньше потоков**: один event loop вместо множества потоков
- **Меньше памяти**: нет overhead на потоки
- **Больше конкурентных операций**: можно обрабатывать тысячи подключений

### Когда остаться на sync версии

- Простые скрипты без асинхронности
- Legacy код на синхронных библиотеках
- Когда нет требований к высокой нагрузке

## Тестирование

```python
import pytest

@pytest.mark.asyncio
async def test_publish_and_consume():
    """Тест публикации и чтения."""
    
    # Publish
    message = UserEventMessage(
        event=UserEvent.CREATE,
        after=User(id=1, name="Test", is_active=True),
    )
    await event_service.publish(message)
    
    # Consume
    async with event_service.subscription():
        async with event_service.pop(timeout=10) as received:
            assert received.event == UserEvent.CREATE
            assert received.after.name == "Test"
```