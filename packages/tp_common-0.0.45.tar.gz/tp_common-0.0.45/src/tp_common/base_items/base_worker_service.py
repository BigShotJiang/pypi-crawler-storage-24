from logging import Logger

from redis.asyncio import Redis

from tp_common.base_items.base_logging_service import BaseLoggingService
from tp_common.tp_logger.tp_logging import TpLogger


class BaseWorkerService(BaseLoggingService):
    def __init__(
        self,
        logger: Logger | TpLogger,
        redis_client: Redis | None = None,
    ) -> None:
        super().__init__(logger)
        self.redis_client = redis_client
