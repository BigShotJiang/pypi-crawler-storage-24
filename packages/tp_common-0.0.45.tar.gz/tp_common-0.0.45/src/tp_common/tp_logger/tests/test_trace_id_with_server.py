"""
Проверка, что при запросах к FastAPI-серверу с TpLogger во всех логах присутствует trace_id.

Поднимается веб-сервер (tp_fastapi.examples.logger), выполняются запросы (успех, ошибка,
запрос с X-Trace-ID), собирается stdout сервера; проверяется, что каждая
строка лога в формате JSON содержит поле trace_id.

Запуск из корня репозитория:
  pytest tp_common/tp_logger/tests/test_trace_id_with_server.py -v
"""

import contextlib
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

import pytest

PORT = 18766
BASE = f"http://127.0.0.1:{PORT}"
TIMEOUT = 15
WAIT_ATTEMPTS = 30
WAIT_INTERVAL = 0.2


def _wait_ready() -> bool:
    for _ in range(WAIT_ATTEMPTS):
        try:
            req = urllib.request.Request(f"{BASE}/", method="GET")
            with urllib.request.urlopen(req, timeout=2) as r:
                if r.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(WAIT_INTERVAL)
    return False


def _request(path: str, headers: dict | None = None) -> tuple[int, str]:
    url = BASE + path
    req = urllib.request.Request(url, method="GET", headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return r.status, r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return e.code, (e.read().decode("utf-8", errors="replace") if e.fp else "")


# Сообщения uvicorn/lifespan (без request context → без trace_id); не требуем для них trace_id.
_UVICORN_MSG_SUBSTRINGS = (
    "Application startup complete",
    "Uvicorn running on",
    "Shutting down",
    "Waiting for application shutdown",
    "Application shutdown complete",
    "Finished server process",
)


def _is_app_log_line(line: str) -> bool:
    """Строка — наш JSON-лог (level, msg) и не системное сообщение uvicorn/lifespan."""
    line = line.strip()
    if not line or not line.startswith("{"):
        return False
    try:
        data = json.loads(line)
        if not (isinstance(data, dict) and "level" in data and "msg" in data):
            return False
        msg = data.get("msg", "")
        return not any(s in msg for s in _UVICORN_MSG_SUBSTRINGS)
    except json.JSONDecodeError:
        return False


@pytest.fixture(scope="module")
def server_log_lines() -> list[str]:
    """
    Поднимает сервер, выполняет запросы, останавливает сервер, возвращает строки лога приложения.
    """
    with tempfile.NamedTemporaryFile(mode="w+t", suffix=".log", delete=False) as f:
        log_path = f.name

    try:
        with open(log_path, "w") as out_f:
            proc = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "tp_common.tp_fastapi.examples.logger.app:app",
                    "--port",
                    str(PORT),
                    "--host",
                    "127.0.0.1",
                ],
                stdout=out_f,
                stderr=subprocess.STDOUT,
                env=os.environ,
            )
            try:
                if not _wait_ready():
                    pytest.fail("Сервер не поднялся за отведённое время")

                _request("/")
                _request("/items/1")
                _request("/", headers={"X-Trace-ID": "custom-trace-123"})
                _request("/error")

                time.sleep(0.5)
            finally:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2)
                out_f.close()

        with open(log_path) as f:
            lines = f.read().splitlines()
    finally:
        with contextlib.suppress(OSError):
            os.unlink(log_path)

    return [ln for ln in lines if _is_app_log_line(ln)]


def test_server_produces_app_logs(server_log_lines: list[str]) -> None:
    """Сервер пишет хотя бы одну строку лога в формате приложения (level + msg)."""
    assert (
        len(server_log_lines) > 0
    ), "Не найдено ни одной строки лога приложения (level + msg)"


def test_every_app_log_line_has_trace_id(server_log_lines: list[str]) -> None:
    """В каждой строке лога приложения присутствует trace_id (успех, ошибка, свой X-Trace-ID)."""
    missing: list[str] = []
    for raw in server_log_lines:
        try:
            data = json.loads(raw)
            if "trace_id" not in data:
                missing.append(raw[:200])
        except json.JSONDecodeError:
            missing.append(raw[:200])

    assert not missing, f"Строки лога без trace_id ({len(missing)}): " + "; ".join(
        missing[:3]
    )
