#!/usr/bin/env python3
"""
Скрипт (не pytest): поднимает API, делает запросы, в stdout видны логи с trace_id.

Имя с check_ — не собирается pytest. Запуск сервера без перехвата stdout,
чтобы JSON-логи шли в терминал и было видно trace_id в каждой записи по запросу.

Запуск из корня репозитория:
  python -m tp_common.tp_logger.tests.check_trace_id_in_logs
"""

import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

PORT = 18767
BASE = f"http://127.0.0.1:{PORT}"
TIMEOUT = 10
WAIT_ATTEMPTS = 40
WAIT_INTERVAL = 0.25


def wait_ready() -> bool:
    for _ in range(WAIT_ATTEMPTS):
        try:
            req = urllib.request.Request(f"{BASE}/", method="GET")
            with urllib.request.urlopen(req, timeout=2) as r:
                if r.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(WAIT_INTERVAL)
    return False


def request(path: str, headers: dict | None = None) -> tuple[int, dict, str]:
    url = BASE + path
    req = urllib.request.Request(url, method="GET", headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            out_headers = {k.lower(): v for k, v in r.headers.items()}
            return r.status, out_headers, r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        out_headers = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
        body = e.read().decode("utf-8", errors="replace") if e.fp else ""
        return e.code, out_headers, body


def main() -> int:
    print("Запуск API на порту", PORT, "...")
    print("Логи сервера (JSON с trace_id) идут ниже.\n")

    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "tp_common.tp_fastapi.examples.logger.app:app",
            "--port",
            str(PORT),
            "--host",
            "127.0.0.1",
        ],
        stdout=None,
        stderr=subprocess.STDOUT,
        env=os.environ,
    )

    try:
        if not wait_ready():
            print("Сервер не поднялся.", file=sys.stderr)
            return 1

        requests_spec = [
            ("/", "GET /", None),
            ("/items/42", "GET /items/42", None),
            (
                "/",
                "GET / с X-Trace-ID: my-trace-abc",
                {"X-Trace-ID": "my-trace-abc"},
            ),
            ("/error", "GET /error (ожидаем 500)", None),
        ]

        for path, desc, headers in requests_spec:
            print("=" * 60)
            print("Запрос:", desc)
            status, resp_headers, body = request(path, headers)
            x_id = resp_headers.get("x-trace-id", "")
            print(f"Ответ: HTTP {status}" + (f", X-Trace-ID: {x_id}" if x_id else ""))
            if body and len(body) < 300:
                print("Тело:", body)
            print()

        print("=" * 60)
        print("Готово. В логах выше в каждой строке по запросу должен быть trace_id.")
        return 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        print("Сервер остановлен.")


if __name__ == "__main__":
    sys.exit(main())
