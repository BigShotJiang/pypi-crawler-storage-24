import requests

def usings(ip, post, data):
    session = requests.Session()
    urls = f"{ip}:{post}"
    resp = session.post(urls, data=data)
    return resp
