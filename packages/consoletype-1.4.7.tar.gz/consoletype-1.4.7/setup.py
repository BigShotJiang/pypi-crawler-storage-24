from setuptools import setup, find_packages

setup(
    name="ConsoleType",
    version="1.4.7",
    author="Vadim | Mur Studio",
    author_email="somerare23@gmail.com",
    description="A update",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
