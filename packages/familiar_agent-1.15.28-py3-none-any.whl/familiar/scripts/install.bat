@echo off
REM Familiar Installation Script for Windows
REM
REM Usage:
REM   install.bat              Standard install
REM   install.bat --full       Include all optional dependencies
REM

echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║                                                           ║
echo ║   🦔 FAMILIAR INSTALLER                                    ║
echo ║   Your Private AI Assistant                               ║
echo ║                                                           ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

REM Check for Python
echo 1. Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo    ❌ Python not found. Please install Python 3.10+
    echo    Download from: https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PY_VERSION=%%i
echo    Found: Python %PY_VERSION%

REM Create virtual environment
echo.
echo 2. Creating virtual environment...
if not exist "venv" (
    python -m venv venv
    echo    Created: venv\
) else (
    echo    Exists: venv\
)

REM Activate venv
call venv\Scripts\activate.bat

REM Upgrade pip
echo.
echo 3. Upgrading pip...
python -m pip install --upgrade pip -q

REM Install base requirements
echo.
echo 4. Installing base dependencies...
pip install -q -r requirements.txt

REM Install llama-cpp-python
echo.
echo 5. Installing local LLM support...
pip install llama-cpp-python -q

REM Install optional dependencies
if "%1"=="--full" (
    echo.
    echo 6. Installing full dependencies...
    pip install -q -r requirements-full.txt
)

REM Create data directories
echo.
echo 7. Creating directories...
if not exist "%USERPROFILE%\.familiar" mkdir "%USERPROFILE%\.familiar"
if not exist "%USERPROFILE%\.familiar\models" mkdir "%USERPROFILE%\.familiar\models"
if not exist "%USERPROFILE%\.familiar\data" mkdir "%USERPROFILE%\.familiar\data"
if not exist "%USERPROFILE%\.familiar\logs" mkdir "%USERPROFILE%\.familiar\logs"
echo    Created: %USERPROFILE%\.familiar\

REM Summary
echo.
echo ╔═══════════════════════════════════════════════════════════╗
echo ║                                                           ║
echo ║   ✅ INSTALLATION COMPLETE                                ║
echo ║                                                           ║
echo ║   Next steps:                                             ║
echo ║                                                           ║
echo ║   1. Run Familiar:                                         ║
echo ║      python -m familiar                                    ║
echo ║                                                           ║
echo ║   2. Click 'Quick Setup' to download a model              ║
echo ║                                                           ║
echo ╚═══════════════════════════════════════════════════════════╝
echo.

pause
