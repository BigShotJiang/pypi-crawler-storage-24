"""Unit tests for the SemASE ontology using rdflib in-memory graphs."""

from rdflib import OWL, RDF, RDFS, Namespace

SEMASE = Namespace("https://semase.org/ontology#")


def test_ontology_loads(memory_graph):
    """The ontology file parses without errors and contains triples."""
    assert len(memory_graph) > 0


def test_classes_defined(memory_graph):
    """All expected OWL classes are declared."""
    expected = [
        SEMASE.AtomicSystem,
        SEMASE.Atom,
        SEMASE.Cell,
        SEMASE.Calculator,
        SEMASE.Vector3D,
    ]
    for cls in expected:
        assert (cls, RDF.type, OWL.Class) in memory_graph, (
            f"{cls} not declared as owl:Class"
        )


def test_object_properties_defined(memory_graph):
    """Key object properties exist."""
    expected = [
        SEMASE.hasAtom,
        SEMASE.hasCell,
        SEMASE.hasCalculator,
        SEMASE.hasPosition,
        SEMASE.hasForce,
        SEMASE.hasCellVectorA,
        SEMASE.hasCellVectorB,
        SEMASE.hasCellVectorC,
    ]
    for prop in expected:
        assert (prop, RDF.type, OWL.ObjectProperty) in memory_graph, (
            f"{prop} not declared as owl:ObjectProperty"
        )


def test_datatype_properties_defined(memory_graph):
    """Key datatype properties exist."""
    expected = [
        SEMASE.chemicalFormula,
        SEMASE.element,
        SEMASE.atomicNumber,
        SEMASE.mass,
        SEMASE.x,
        SEMASE.y,
        SEMASE.z,
    ]
    for prop in expected:
        assert (prop, RDF.type, OWL.DatatypeProperty) in memory_graph, (
            f"{prop} not declared as owl:DatatypeProperty"
        )


def test_has_atom_domain_range(memory_graph):
    """hasAtom links AtomicSystem to Atom."""
    assert (SEMASE.hasAtom, RDFS.domain, SEMASE.AtomicSystem) in memory_graph
    assert (SEMASE.hasAtom, RDFS.range, SEMASE.Atom) in memory_graph


def test_has_cell_domain_range(memory_graph):
    """hasCell links AtomicSystem to Cell."""
    assert (SEMASE.hasCell, RDFS.domain, SEMASE.AtomicSystem) in memory_graph
    assert (SEMASE.hasCell, RDFS.range, SEMASE.Cell) in memory_graph
