"""Integration tests using Oxigraph as an in-memory SPARQL store."""

import pytest

pyoxigraph = pytest.importorskip("pyoxigraph")


PREFIXES = """
PREFIX semase: <https://semase.org/ontology#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
"""


def _val(term):
    """Extract the plain value from a pyoxigraph term."""
    if hasattr(term, "value"):
        return term.value
    return str(term)


def test_insert_and_query_atomic_system(oxigraph_store):
    """Insert an AtomicSystem and retrieve it via SPARQL."""
    oxigraph_store.update(
        PREFIXES
        + """
        INSERT DATA {
            <ase:water-001> a semase:AtomicSystem ;
                semase:chemicalFormula "H2O" ;
                semase:atomCount 3 .
        }
        """
    )

    results = list(
        oxigraph_store.query(
            PREFIXES
            + """
            SELECT ?formula ?count WHERE {
                <ase:water-001> semase:chemicalFormula ?formula ;
                                semase:atomCount ?count .
            }
            """
        )
    )

    assert len(results) == 1
    assert _val(results[0][0]) == "H2O"
    assert int(_val(results[0][1])) == 3


def test_insert_atoms_with_positions(oxigraph_store):
    """Insert atoms with 3D positions and query them back."""
    oxigraph_store.update(
        PREFIXES
        + """
        INSERT DATA {
            <ase:water-001> a semase:AtomicSystem ;
                semase:hasAtom <ase:water-001/atom/0> ,
                               <ase:water-001/atom/1> ,
                               <ase:water-001/atom/2> .

            <ase:water-001/atom/0> a semase:Atom ;
                semase:element "O" ;
                semase:atomIndex 0 ;
                semase:hasPosition <ase:water-001/atom/0/pos> .

            <ase:water-001/atom/0/pos> a semase:Vector3D ;
                semase:x "0.0"^^xsd:double ;
                semase:y "0.0"^^xsd:double ;
                semase:z "0.0"^^xsd:double .

            <ase:water-001/atom/1> a semase:Atom ;
                semase:element "H" ;
                semase:atomIndex 1 .

            <ase:water-001/atom/2> a semase:Atom ;
                semase:element "H" ;
                semase:atomIndex 2 .
        }
        """
    )

    results = list(
        oxigraph_store.query(
            PREFIXES
            + """
            SELECT ?element ?idx WHERE {
                <ase:water-001> semase:hasAtom ?atom .
                ?atom semase:element ?element ;
                      semase:atomIndex ?idx .
            }
            ORDER BY ?idx
            """
        )
    )

    assert len(results) == 3
    elements = [_val(r[0]) for r in results]
    assert elements == ["O", "H", "H"]


def test_insert_cell(oxigraph_store):
    """Insert a Cell with lattice vectors and periodic boundary conditions."""
    oxigraph_store.update(
        PREFIXES
        + """
        INSERT DATA {
            <ase:si-diamond/cell> a semase:Cell ;
                semase:periodicX true ;
                semase:periodicY true ;
                semase:periodicZ true ;
                semase:volume "40.03"^^xsd:double ;
                semase:hasCellVectorA <ase:si-diamond/cell/a> .

            <ase:si-diamond/cell/a> a semase:Vector3D ;
                semase:x "5.43"^^xsd:double ;
                semase:y "0.0"^^xsd:double ;
                semase:z "0.0"^^xsd:double .
        }
        """
    )

    results = list(
        oxigraph_store.query(
            PREFIXES
            + """
            SELECT ?vol ?px WHERE {
                <ase:si-diamond/cell> semase:volume ?vol ;
                                      semase:periodicX ?px .
            }
            """
        )
    )

    assert len(results) == 1
    assert float(_val(results[0][0])) == pytest.approx(40.03)
    assert _val(results[0][1]) == "true"


def test_delete_and_reinsert(oxigraph_store):
    """Simulate an update by deleting and reinserting triples."""
    oxigraph_store.update(
        PREFIXES
        + """
        INSERT DATA {
            <ase:mol-001> a semase:AtomicSystem ;
                semase:chemicalFormula "CH4" .
        }
        """
    )

    # Delete old data
    oxigraph_store.update(
        PREFIXES
        + """
        DELETE WHERE {
            <ase:mol-001> ?p ?o .
        }
        """
    )

    # Reinsert with updated formula
    oxigraph_store.update(
        PREFIXES
        + """
        INSERT DATA {
            <ase:mol-001> a semase:AtomicSystem ;
                semase:chemicalFormula "C2H6" .
        }
        """
    )

    results = list(
        oxigraph_store.query(
            PREFIXES
            + """
            SELECT ?formula WHERE {
                <ase:mol-001> semase:chemicalFormula ?formula .
            }
            """
        )
    )

    assert len(results) == 1
    assert _val(results[0][0]) == "C2H6"
