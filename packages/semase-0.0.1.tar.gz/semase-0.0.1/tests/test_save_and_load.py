"""Tests for save_to_kg() and update_from_kg() using Oxigraph."""

import numpy as np
import pytest

pyoxigraph = pytest.importorskip("pyoxigraph")


def test_atoms_round_trip(activated_semase, oxigraph_store):
    """Save an Atoms object and load it back."""
    from ase import Atoms

    water = Atoms(
        "H2O",
        positions=[(0.0, 0.0, 0.0), (0.0, 0.76, 0.59), (0.0, -0.76, 0.59)],
    )

    water.save_to_kg(uri="ase:water-001", store=oxigraph_store)

    loaded = Atoms()
    loaded.update_from_kg(uri="ase:water-001", store=oxigraph_store)

    assert loaded.get_chemical_formula() == "H2O"
    assert len(loaded) == 3
    np.testing.assert_allclose(loaded.positions, water.positions, atol=1e-10)


def test_atoms_with_cell_round_trip(activated_semase, oxigraph_store):
    """Save an Atoms object with a unit cell and load it back."""
    from ase import Atoms

    si = Atoms(
        "Si2",
        positions=[(0.0, 0.0, 0.0), (1.36, 1.36, 1.36)],
        cell=[5.43, 5.43, 5.43],
        pbc=True,
    )

    si.save_to_kg(uri="ase:si-001", store=oxigraph_store)

    loaded = Atoms()
    loaded.update_from_kg(uri="ase:si-001", store=oxigraph_store)

    assert loaded.get_chemical_formula() == "Si2"
    np.testing.assert_allclose(loaded.positions, si.positions, atol=1e-10)
    np.testing.assert_allclose(loaded.cell.array, si.cell.array, atol=1e-10)
    assert all(loaded.pbc)


def test_cell_round_trip(activated_semase, oxigraph_store):
    """Save a Cell independently and load it back."""
    from ase.cell import Cell

    cell = Cell([[5.43, 0, 0], [0, 5.43, 0], [0, 0, 5.43]])
    pbc = [True, True, False]

    cell.save_to_kg(uri="ase:cell-001", pbc=pbc, store=oxigraph_store)

    loaded = Cell([[0, 0, 0], [0, 0, 0], [0, 0, 0]])
    loaded.update_from_kg(uri="ase:cell-001", store=oxigraph_store)

    np.testing.assert_allclose(loaded.array, cell.array, atol=1e-10)


def test_overwrite_existing(activated_semase, oxigraph_store):
    """Saving to the same URI replaces the previous data."""
    from ase import Atoms

    ch4 = Atoms(
        "CH4",
        positions=[
            (0, 0, 0),
            (0.63, 0.63, 0.63),
            (-0.63, -0.63, 0.63),
            (-0.63, 0.63, -0.63),
            (0.63, -0.63, -0.63),
        ],
    )
    ch4.save_to_kg(uri="ase:mol-001", store=oxigraph_store)

    c2h6 = Atoms(
        "C2H6",
        positions=[
            (0, 0, 0),
            (1.54, 0, 0),
            (-0.4, 0.9, 0),
            (-0.4, -0.9, 0),
            (-0.4, 0, 0.9),
            (1.94, 0.9, 0),
            (1.94, -0.9, 0),
            (1.94, 0, 0.9),
        ],
    )
    c2h6.save_to_kg(uri="ase:mol-001", store=oxigraph_store)

    loaded = Atoms()
    loaded.update_from_kg(uri="ase:mol-001", store=oxigraph_store)

    assert loaded.get_chemical_formula() == "C2H6"
    assert len(loaded) == 8


def test_load_nonexistent_raises(activated_semase, oxigraph_store):
    """Loading a URI that doesn't exist raises ValueError."""
    from ase import Atoms

    atoms = Atoms()
    with pytest.raises(ValueError, match="No AtomicSystem found"):
        atoms.update_from_kg(uri="ase:nonexistent", store=oxigraph_store)
