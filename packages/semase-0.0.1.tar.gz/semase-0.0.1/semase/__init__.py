"""SemASE: Semantic integration of ASE with SPARQL knowledge graphs."""

from semase.config import configure
from semase.sparql.client import SparqlClient as SparqlClient

__version__ = "0.0.1"

_activated = False


def activate(endpoint=None, graph=None):
    """Patch ASE classes with knowledge graph methods.

    After calling this, ASE classes like Atoms and Cell gain
    save_to_kg() and update_from_kg() methods.

    Args:
        endpoint: Default SPARQL endpoint URL.
        graph: Optional default named graph URI.
    """
    global _activated

    if endpoint or graph:
        configure(endpoint=endpoint, graph=graph)

    if _activated:
        return

    from ase import Atoms
    from ase.cell import Cell

    from semase.mixins.atoms import _atoms_save_to_kg, _atoms_update_from_kg
    from semase.mixins.cell import _cell_save_to_kg, _cell_update_from_kg

    Atoms.save_to_kg = _atoms_save_to_kg
    Atoms.update_from_kg = _atoms_update_from_kg
    Cell.save_to_kg = _cell_save_to_kg
    Cell.update_from_kg = _cell_update_from_kg

    _activated = True
