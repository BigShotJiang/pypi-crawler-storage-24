"""Serialize ASE objects to SPARQL INSERT statements and deserialize query
results back into ASE objects."""

from rdflib import XSD, URIRef

from semase.ontology.namespaces import ASE

PREFIXES = """\
PREFIX semase: <https://semase.org/ontology#>
PREFIX ase: <https://semase.org/ase#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
"""


def make_uri(uri):
    """Convert a string URI to a full URI, expanding the ase: prefix."""
    if isinstance(uri, URIRef):
        return uri
    if uri.startswith("ase:"):
        return URIRef(str(ASE) + uri[4:])
    return URIRef(uri)


def _literal(value, datatype):
    """Format a value as a SPARQL literal string."""
    if datatype == XSD.boolean:
        return "true" if value else "false"
    if datatype == XSD.double:
        return f'"{value}"^^xsd:double'
    if datatype == XSD.integer:
        return str(int(value))
    return f'"{value}"'


def _uri_str(uri):
    """Format a URIRef as a SPARQL-safe <uri> string."""
    return f"<{uri}>"


def serialize_atoms(atoms, uri):
    """Serialize an ASE Atoms object to a SPARQL INSERT DATA statement."""
    uri = make_uri(uri)
    lines = []
    lines.append(f"{_uri_str(uri)} a semase:AtomicSystem ;")
    lines.append(f'    semase:chemicalFormula "{atoms.get_chemical_formula()}" ;')
    lines.append(f"    semase:atomCount {len(atoms)} ;")

    # Cell
    cell_uri = URIRef(str(uri) + "/cell")
    lines.append(f"    semase:hasCell {_uri_str(cell_uri)} ;")

    # Atom references
    for i in range(len(atoms)):
        atom_uri = URIRef(str(uri) + f"/atom/{i}")
        sep = ";" if i < len(atoms) - 1 else "."
        lines.append(f"    semase:hasAtom {_uri_str(atom_uri)} {sep}")

    # Cell triples
    lines.append("")
    lines.extend(_serialize_cell(atoms.cell, cell_uri, pbc=atoms.pbc))

    # Atom triples
    for i, atom in enumerate(atoms):
        lines.append("")
        lines.extend(_serialize_atom(atom, i, uri))

    body = "\n    ".join(lines)
    return f"{PREFIXES}\nINSERT DATA {{\n    {body}\n}}"


def _serialize_cell(cell, cell_uri, pbc=None):
    """Serialize an ASE Cell to triples."""
    if pbc is None:
        pbc = [False, False, False]
    lines = []
    lines.append(f"{_uri_str(cell_uri)} a semase:Cell ;")
    lines.append(f"    semase:periodicX {_literal(bool(pbc[0]), XSD.boolean)} ;")
    lines.append(f"    semase:periodicY {_literal(bool(pbc[1]), XSD.boolean)} ;")
    lines.append(f"    semase:periodicZ {_literal(bool(pbc[2]), XSD.boolean)} ;")
    lines.append(f"    semase:volume {_literal(float(cell.volume), XSD.double)} ;")

    vectors = cell.array
    for idx, label in enumerate(["A", "B", "C"]):
        vec_uri = URIRef(str(cell_uri) + f"/{label.lower()}")
        sep = ";" if idx < 2 else "."
        lines.append(f"    semase:hasCellVector{label} {_uri_str(vec_uri)} {sep}")

    for idx, label in enumerate(["A", "B", "C"]):
        vec_uri = URIRef(str(cell_uri) + f"/{label.lower()}")
        v = vectors[idx]
        lines.append("")
        lines.append(f"{_uri_str(vec_uri)} a semase:Vector3D ;")
        lines.append(f"    semase:x {_literal(float(v[0]), XSD.double)} ;")
        lines.append(f"    semase:y {_literal(float(v[1]), XSD.double)} ;")
        lines.append(f"    semase:z {_literal(float(v[2]), XSD.double)} .")

    return lines


def _serialize_atom(atom, index, system_uri):
    """Serialize a single atom to triples."""
    atom_uri = URIRef(str(system_uri) + f"/atom/{index}")
    pos_uri = URIRef(str(atom_uri) + "/pos")

    lines = []
    lines.append(f"{_uri_str(atom_uri)} a semase:Atom ;")
    lines.append(f'    semase:element "{atom.symbol}" ;')
    lines.append(f"    semase:atomicNumber {atom.number} ;")
    lines.append(f"    semase:mass {_literal(float(atom.mass), XSD.double)} ;")
    lines.append(f"    semase:atomIndex {index} ;")
    lines.append(f"    semase:hasPosition {_uri_str(pos_uri)} .")

    pos = atom.position
    lines.append("")
    lines.append(f"{_uri_str(pos_uri)} a semase:Vector3D ;")
    lines.append(f"    semase:x {_literal(float(pos[0]), XSD.double)} ;")
    lines.append(f"    semase:y {_literal(float(pos[1]), XSD.double)} ;")
    lines.append(f"    semase:z {_literal(float(pos[2]), XSD.double)} .")

    return lines


def serialize_cell(cell, uri, pbc=None):
    """Serialize a standalone ASE Cell to a SPARQL INSERT DATA statement."""
    uri = make_uri(uri)
    lines = _serialize_cell(cell, uri, pbc=pbc)
    body = "\n    ".join(lines)
    return f"{PREFIXES}\nINSERT DATA {{\n    {body}\n}}"


def delete_uri(uri):
    """Return a list of SPARQL UPDATE statements that delete all triples for a
    URI and its sub-resources (atoms, cell, positions, vectors)."""
    uri = make_uri(uri)
    child_delete = (
        f"{PREFIXES}\n"
        f"DELETE {{ ?child ?p2 ?o2 }} WHERE {{"
        f" ?child ?p2 ?o2 .\n"
        f'    FILTER(STRSTARTS(STR(?child), "{uri}/"))\n'
        f"}}"
    )
    return [
        f"{PREFIXES}\nDELETE WHERE {{ {_uri_str(uri)} ?p ?o }}",
        child_delete,
    ]
