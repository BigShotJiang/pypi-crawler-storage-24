"""SPARQL client abstraction supporting HTTP endpoints and in-memory stores."""

from SPARQLWrapper import JSON, SPARQLWrapper


class SparqlClient:
    """Client for executing SPARQL queries and updates.

    Supports two backends:
    - HTTP endpoint via SPARQLWrapper (for production use)
    - pyoxigraph.Store (for testing without a server)
    """

    def __init__(self, endpoint=None, store=None):
        """Create a client backed by either an HTTP endpoint or a local store.

        Args:
            endpoint: URL of a SPARQL endpoint.
            store: A pyoxigraph.Store instance for in-memory operation.
        """
        if store is not None:
            self._backend = "oxigraph"
            self._store = store
        elif endpoint is not None:
            self._backend = "http"
            self._endpoint = endpoint
        else:
            raise ValueError("Provide either 'endpoint' or 'store'")

    def update(self, sparql_update):
        """Execute a SPARQL UPDATE operation."""
        if self._backend == "oxigraph":
            self._store.update(sparql_update)
        else:
            wrapper = SPARQLWrapper(self._endpoint)
            wrapper.setMethod("POST")
            wrapper.setQuery(sparql_update)
            wrapper.query()

    def query(self, sparql_query):
        """Execute a SPARQL SELECT query and return a list of result rows.

        Each row is a dict mapping variable names to values.
        """
        if self._backend == "oxigraph":
            return self._query_oxigraph(sparql_query)
        else:
            return self._query_http(sparql_query)

    def _query_oxigraph(self, sparql_query):
        raw = self._store.query(sparql_query)
        rows = []
        for solution in raw:
            row = {}
            for var in raw.variables:
                name = str(var)[1:]  # strip leading '?'
                val = solution[var]
                if hasattr(val, "value"):
                    row[name] = val.value
                else:
                    row[name] = str(val)
            rows.append(row)
        return rows

    def _query_http(self, sparql_query):
        wrapper = SPARQLWrapper(self._endpoint)
        wrapper.setQuery(sparql_query)
        wrapper.setReturnFormat(JSON)
        response = wrapper.query().convert()
        rows = []
        for binding in response["results"]["bindings"]:
            row = {}
            for var, val in binding.items():
                row[var] = val["value"]
            rows.append(row)
        return rows
