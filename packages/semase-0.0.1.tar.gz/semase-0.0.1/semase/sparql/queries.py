"""SPARQL query templates for reading ASE objects from the knowledge graph."""

from semase.sparql.serializer import PREFIXES, _uri_str, make_uri


def query_atomic_system(uri):
    """Return a SPARQL SELECT for the top-level AtomicSystem properties."""
    uri = make_uri(uri)
    return f"""{PREFIXES}
SELECT ?formula ?count ?cellUri WHERE {{
    {_uri_str(uri)} a semase:AtomicSystem ;
        semase:chemicalFormula ?formula ;
        semase:atomCount ?count ;
        semase:hasCell ?cellUri .
}}"""


def query_atoms(uri):
    """Return a SPARQL SELECT for all atoms in an AtomicSystem."""
    uri = make_uri(uri)
    return f"""{PREFIXES}
SELECT ?element ?number ?mass ?idx ?x ?y ?z WHERE {{
    {_uri_str(uri)} semase:hasAtom ?atom .
    ?atom a semase:Atom ;
        semase:element ?element ;
        semase:atomicNumber ?number ;
        semase:mass ?mass ;
        semase:atomIndex ?idx ;
        semase:hasPosition ?pos .
    ?pos semase:x ?x ;
         semase:y ?y ;
         semase:z ?z .
}}
ORDER BY ?idx"""


def query_cell(cell_uri):
    """Return a SPARQL SELECT for a Cell and its vectors."""
    cell_uri = make_uri(cell_uri)
    return f"""{PREFIXES}
SELECT ?vol ?px ?py ?pz
       ?ax ?ay ?az ?bx ?by ?bz ?cx ?cy ?cz WHERE {{
    {_uri_str(cell_uri)} a semase:Cell ;
        semase:volume ?vol ;
        semase:periodicX ?px ;
        semase:periodicY ?py ;
        semase:periodicZ ?pz ;
        semase:hasCellVectorA ?va ;
        semase:hasCellVectorB ?vb ;
        semase:hasCellVectorC ?vc .
    ?va semase:x ?ax ; semase:y ?ay ; semase:z ?az .
    ?vb semase:x ?bx ; semase:y ?by ; semase:z ?bz .
    ?vc semase:x ?cx ; semase:y ?cy ; semase:z ?cz .
}}"""
