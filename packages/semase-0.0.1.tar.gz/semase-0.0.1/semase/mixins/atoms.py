"""Mixin that adds save_to_kg() and update_from_kg() to ase.Atoms."""

import numpy as np

from semase.mixins.base import _get_client
from semase.sparql.queries import query_atomic_system, query_atoms, query_cell
from semase.sparql.serializer import delete_uri, serialize_atoms


def _atoms_save_to_kg(self, uri, endpoint=None, store=None):
    """Save this Atoms object (including Cell and all atoms) to the knowledge graph.

    Args:
        uri: URI identifying this atomic system (e.g. "ase:water-001").
        endpoint: Optional SPARQL endpoint URL (overrides global config).
        store: Optional pyoxigraph.Store for in-memory operation.
    """
    client = _get_client(endpoint=endpoint, store=store)
    for stmt in delete_uri(uri):
        client.update(stmt)
    client.update(serialize_atoms(self, uri))


def _atoms_update_from_kg(self, uri, endpoint=None, store=None):
    """Load this Atoms object's state from the knowledge graph.

    Populates symbols, positions, cell, and periodic boundary conditions.

    Args:
        uri: URI identifying the atomic system to load.
        endpoint: Optional SPARQL endpoint URL (overrides global config).
        store: Optional pyoxigraph.Store for in-memory operation.
    """
    from ase import Atoms

    client = _get_client(endpoint=endpoint, store=store)

    # Query top-level system
    sys_rows = client.query(query_atomic_system(uri))
    if not sys_rows:
        raise ValueError(f"No AtomicSystem found at URI: {uri}")

    sys_row = sys_rows[0]
    cell_uri = str(sys_row["cellUri"])

    # Query atoms
    atom_rows = client.query(query_atoms(uri))

    # Query cell
    cell_rows = client.query(query_cell(cell_uri))

    def f(val):
        return float(str(val))

    def b(val):
        v = str(val)
        return v.lower() in ("true", "1")

    # Build atoms data
    symbols = [str(r["element"]) for r in atom_rows]
    positions = np.array([[f(r["x"]), f(r["y"]), f(r["z"])] for r in atom_rows])

    # Build cell data
    if cell_rows:
        cr = cell_rows[0]
        cell_array = np.array(
            [
                [f(cr["ax"]), f(cr["ay"]), f(cr["az"])],
                [f(cr["bx"]), f(cr["by"]), f(cr["bz"])],
                [f(cr["cx"]), f(cr["cy"]), f(cr["cz"])],
            ]
        )
        pbc = [b(cr["px"]), b(cr["py"]), b(cr["pz"])]
    else:
        cell_array = np.zeros((3, 3))
        pbc = [False, False, False]

    # Update self in place
    temp = Atoms(symbols=symbols, positions=positions, cell=cell_array, pbc=pbc)
    self.__init__(
        symbols=temp.get_chemical_symbols(),
        positions=temp.get_positions(),
        cell=temp.cell,
        pbc=temp.pbc,
    )
