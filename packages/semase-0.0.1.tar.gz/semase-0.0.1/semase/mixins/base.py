"""Base mixin providing save_to_kg() and update_from_kg() to ASE classes."""

from semase import config
from semase.sparql.client import SparqlClient


def _get_client(endpoint=None, store=None):
    """Resolve a SparqlClient from explicit args or global config."""
    if store is not None:
        return SparqlClient(store=store)
    endpoint = endpoint or config.get_endpoint()
    if endpoint is None:
        raise ValueError(
            "No SPARQL endpoint configured. "
            "Call semase.activate(endpoint=...) or pass endpoint= explicitly."
        )
    return SparqlClient(endpoint=endpoint)
