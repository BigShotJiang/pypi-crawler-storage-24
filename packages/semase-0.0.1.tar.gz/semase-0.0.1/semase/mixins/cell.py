"""Mixin that adds save_to_kg() and update_from_kg() to ase.cell.Cell."""

import numpy as np

from semase.mixins.base import _get_client
from semase.sparql.queries import query_cell
from semase.sparql.serializer import delete_uri, serialize_cell


def _cell_save_to_kg(self, uri, pbc=None, endpoint=None, store=None):
    """Save this Cell to the knowledge graph.

    Args:
        uri: URI identifying this cell (e.g. "ase:my-system/cell").
        pbc: Periodic boundary conditions [bool, bool, bool].
        endpoint: Optional SPARQL endpoint URL (overrides global config).
        store: Optional pyoxigraph.Store for in-memory operation.
    """
    client = _get_client(endpoint=endpoint, store=store)
    for stmt in delete_uri(uri):
        client.update(stmt)
    client.update(serialize_cell(self, uri, pbc=pbc))


def _cell_update_from_kg(self, uri, endpoint=None, store=None):
    """Load this Cell's state from the knowledge graph.

    Args:
        uri: URI identifying the cell to load.
        endpoint: Optional SPARQL endpoint URL (overrides global config).
        store: Optional pyoxigraph.Store for in-memory operation.
    """
    client = _get_client(endpoint=endpoint, store=store)
    rows = client.query(query_cell(uri))
    if not rows:
        raise ValueError(f"No Cell found at URI: {uri}")

    row = rows[0]

    def f(val):
        return float(str(val))

    def b(val):
        v = str(val)
        return v.lower() in ("true", "1")

    cell_array = np.array(
        [
            [f(row["ax"]), f(row["ay"]), f(row["az"])],
            [f(row["bx"]), f(row["by"]), f(row["bz"])],
            [f(row["cx"]), f(row["cy"]), f(row["cz"])],
        ]
    )

    pbc = [b(row["px"]), b(row["py"]), b(row["pz"])]

    # Update the Cell in place
    self[:] = cell_array
    self.pbc = pbc
