_config = {
    "endpoint": None,
    "graph": None,
}


def configure(endpoint=None, graph=None):
    """Set the default SPARQL endpoint URL and optional named graph.

    Args:
        endpoint: SPARQL endpoint URL (e.g. "http://localhost:3030/ase/sparql").
        graph: Optional named graph URI for all operations.
    """
    if endpoint is not None:
        _config["endpoint"] = endpoint
    if graph is not None:
        _config["graph"] = graph


def get_endpoint():
    return _config["endpoint"]


def get_graph():
    return _config["graph"]
