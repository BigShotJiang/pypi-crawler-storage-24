from rdflib import Namespace

SEMASE = Namespace("https://semase.org/ontology#")
ASE = Namespace("https://semase.org/ase#")
