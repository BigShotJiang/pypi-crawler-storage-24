"""Declarative mapping from ASE class attributes to RDF properties.

Each entry maps a fully-qualified ASE class name to:
- rdf_class: the OWL class URI
- properties: a dict of ASE attribute name -> RDF property URI
- nested: attributes that reference other mapped objects (committed recursively)
- collection: attributes that are lists of mapped objects
"""

from rdflib import XSD

from semase.ontology.namespaces import SEMASE

MAPPING = {
    "ase.cell.Cell": {
        "rdf_class": SEMASE.Cell,
        "properties": {
            "volume": (SEMASE.volume, XSD.double),
        },
        "pbc_properties": {
            0: SEMASE.periodicX,
            1: SEMASE.periodicY,
            2: SEMASE.periodicZ,
        },
        "vector_properties": {
            0: SEMASE.hasCellVectorA,
            1: SEMASE.hasCellVectorB,
            2: SEMASE.hasCellVectorC,
        },
    },
    "ase.Atoms": {
        "rdf_class": SEMASE.AtomicSystem,
        "properties": {
            "chemicalFormula": (SEMASE.chemicalFormula, XSD.string),
            "atomCount": (SEMASE.atomCount, XSD.integer),
        },
        "nested": {
            "cell": "ase.cell.Cell",
        },
        "collection": {
            "atoms": "atom",
        },
    },
    "atom": {
        "rdf_class": SEMASE.Atom,
        "properties": {
            "element": (SEMASE.element, XSD.string),
            "atomicNumber": (SEMASE.atomicNumber, XSD.integer),
            "mass": (SEMASE.mass, XSD.double),
            "atomIndex": (SEMASE.atomIndex, XSD.integer),
        },
    },
}


def get_mapping(key):
    """Return the mapping dict for a given key."""
    if key not in MAPPING:
        raise ValueError(f"No mapping defined for '{key}'")
    return MAPPING[key]
