"""
Submit insurance-optimise pytest suite to Databricks serverless compute.

Uses the REST API directly — no cluster spec required.
"""

import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid

# ---------------------------------------------------------------------------
# Load credentials
# ---------------------------------------------------------------------------
env_path = os.path.expanduser("~/.config/burning-cost/databricks.env")
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ[k.strip()] = v.strip()

api_base = os.environ["DATABRICKS_HOST"].rstrip("/")
token = os.environ["DATABRICKS_TOKEN"]
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json",
}

RUN_ID = uuid.uuid4().hex[:8]
WORKSPACE_FOLDER = "/Workspace/insurance-optimise"
NOTEBOOK_PATH = f"{WORKSPACE_FOLDER}/run_pytest"

# ---------------------------------------------------------------------------
# Read source files
# ---------------------------------------------------------------------------
BASE = "/home/ralph/repos/insurance-optimise"


def read_file(path: str) -> str:
    with open(path, "r") as f:
        return f.read()


src_files = {
    "__init__.py":     read_file(f"{BASE}/src/insurance_optimise/__init__.py"),
    "result.py":       read_file(f"{BASE}/src/insurance_optimise/result.py"),
    "demand.py":       read_file(f"{BASE}/src/insurance_optimise/demand.py"),
    "constraints.py":  read_file(f"{BASE}/src/insurance_optimise/constraints.py"),
    "audit.py":        read_file(f"{BASE}/src/insurance_optimise/audit.py"),
    "optimiser.py":    read_file(f"{BASE}/src/insurance_optimise/optimiser.py"),
    "frontier.py":     read_file(f"{BASE}/src/insurance_optimise/frontier.py"),
    "scenarios.py":    read_file(f"{BASE}/src/insurance_optimise/scenarios.py"),
}

test_files = {
    "conftest.py":          read_file(f"{BASE}/tests/conftest.py"),
    "test_demand.py":       read_file(f"{BASE}/tests/test_demand.py"),
    "test_constraints.py":  read_file(f"{BASE}/tests/test_constraints.py"),
    "test_optimiser.py":    read_file(f"{BASE}/tests/test_optimiser.py"),
    "test_result.py":       read_file(f"{BASE}/tests/test_result.py"),
    "test_scenarios.py":    read_file(f"{BASE}/tests/test_scenarios.py"),
    "test_frontier.py":     read_file(f"{BASE}/tests/test_frontier.py"),
    "test_integration.py":  read_file(f"{BASE}/tests/test_integration.py"),
}

all_files = {**src_files, **test_files}
src_file_names = set(src_files.keys())
files_json = json.dumps(all_files)

pyproject_content = """[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "insurance-optimise"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "numpy>=1.24",
    "polars>=0.20",
    "scipy>=1.10",
]

[tool.hatch.build.targets.wheel]
packages = ["src/insurance_optimise"]
"""
pyproject_json = json.dumps(pyproject_content)

# ---------------------------------------------------------------------------
# Build notebook source
# ---------------------------------------------------------------------------
NOTEBOOK_SOURCE = f"""# Databricks notebook source
# MAGIC %pip install polars>=0.20 numpy>=1.24 scipy>=1.10 pytest>=7.0 hatchling --quiet

# COMMAND ----------

import json, os, sys, uuid, subprocess

pkg_id = uuid.uuid4().hex[:8]
pkg_dir = f"/tmp/insurance_optimise_{{pkg_id}}"
src_dir = f"{{pkg_dir}}/src/insurance_optimise"
tests_dir = f"{{pkg_dir}}/tests"
os.makedirs(src_dir, exist_ok=True)
os.makedirs(tests_dir, exist_ok=True)

FILES_JSON = {files_json!r}
PYPROJECT_JSON = {pyproject_json!r}
SRC_FILE_NAMES = {json.dumps(list(src_file_names))!r}

files_map = json.loads(FILES_JSON)
pyproject_src = json.loads(PYPROJECT_JSON)
src_names = set(json.loads(SRC_FILE_NAMES))

for name, content in files_map.items():
    if name in src_names:
        path = f"{{src_dir}}/{{name}}"
    else:
        path = f"{{tests_dir}}/{{name}}"
    with open(path, "w") as f:
        f.write(content)

with open(f"{{pkg_dir}}/pyproject.toml", "w") as f:
    f.write(pyproject_src)

print(f"Written {{len(files_map) + 1}} files to {{pkg_dir}}")

# COMMAND ----------

r = subprocess.run(
    [sys.executable, "-m", "pip", "install", "-e", pkg_dir, "--quiet"],
    capture_output=True, text=True
)
if r.returncode != 0:
    print("Install error:", r.stderr[:1000])
else:
    print("insurance-optimise installed from", pkg_dir)

# COMMAND ----------

r = subprocess.run(
    [sys.executable, "-m", "pytest", tests_dir, "-v", "--tb=short",
     "--no-header", "-p", "no:cacheprovider"],
    capture_output=True, text=True, cwd=pkg_dir
)

print(r.stdout[-8000:])
if r.stderr:
    print("STDERR:", r.stderr[-1000:])

if r.returncode == 0:
    print("\\n=== ALL TESTS PASSED ===")
    try:
        dbutils.notebook.exit("ALL TESTS PASSED")
    except NameError:
        pass
else:
    msg = f"TESTS FAILED (exit {{r.returncode}})"
    print(f"\\n=== {{msg}} ===")
    try:
        dbutils.notebook.exit(msg)
    except NameError:
        pass
"""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def api_call(method: str, endpoint: str, body: dict | None = None):
    data = json.dumps(body).encode("utf-8") if body else None
    req = urllib.request.Request(
        f"{api_base}/{endpoint}",
        data=data,
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        err_body = e.read().decode()
        raise RuntimeError(f"API {method} {endpoint} failed {e.code}: {err_body}")


# ---------------------------------------------------------------------------
# Ensure workspace folder exists
# ---------------------------------------------------------------------------
print(f"Creating workspace folder {WORKSPACE_FOLDER} ...")
try:
    api_call("POST", "api/2.0/workspace/mkdirs", {"path": WORKSPACE_FOLDER})
    print("Folder ready.")
except RuntimeError as exc:
    print(f"mkdirs note: {exc}")

# ---------------------------------------------------------------------------
# Upload notebook
# ---------------------------------------------------------------------------
print(f"Uploading notebook to {NOTEBOOK_PATH} ...")
notebook_b64 = base64.b64encode(NOTEBOOK_SOURCE.encode("utf-8")).decode("ascii")

api_call("POST", "api/2.0/workspace/import", {
    "path": NOTEBOOK_PATH,
    "format": "SOURCE",
    "language": "PYTHON",
    "content": notebook_b64,
    "overwrite": True,
})
print("Upload OK")

# ---------------------------------------------------------------------------
# Submit serverless run
# ---------------------------------------------------------------------------
print(f"Submitting serverless run {RUN_ID} ...")
submit_body = {
    "run_name": f"insurance-optimise-pytest-{RUN_ID}",
    "tasks": [
        {
            "task_key": "pytest",
            "notebook_task": {
                "notebook_path": NOTEBOOK_PATH,
                "source": "WORKSPACE",
            },
        }
    ],
}
result = api_call("POST", "api/2.1/jobs/runs/submit", submit_body)
run_id = result["run_id"]
print(f"Run submitted: run_id={run_id}")

# ---------------------------------------------------------------------------
# Poll
# ---------------------------------------------------------------------------
print("Polling ...")
lc, rs = "PENDING", "-"
for i in range(120):
    time.sleep(15)
    run_state = api_call("GET", f"api/2.1/jobs/runs/get?run_id={run_id}")
    lc = run_state.get("state", {}).get("life_cycle_state", "UNKNOWN")
    rs = run_state.get("state", {}).get("result_state", "-")
    print(f"  [{i * 15}s] {lc} / {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break

print(f"\nFinal state: {lc} / {rs}")

# ---------------------------------------------------------------------------
# Fetch output
# ---------------------------------------------------------------------------
try:
    output = api_call("GET", f"api/2.1/jobs/runs/get-output?run_id={run_id}")
    notebook_result = output.get("notebook_output", {}).get("result", "")
    error = output.get("error", "")
    error_trace = output.get("error_trace", "")
    logs = output.get("logs", "")

    if notebook_result:
        print(f"\nExit value: {notebook_result}")
    if error:
        print(f"Error: {error}")
    if error_trace:
        print(f"Trace:\n{error_trace[:3000]}")
    if logs:
        print(f"\nLogs:\n{logs[-8000:]}")
except Exception as e:
    print(f"Could not fetch output: {e}")

if rs == "SUCCESS":
    print("\n=== PASS: All tests completed on Databricks. ===")
    sys.exit(0)
else:
    print(f"\n=== FAIL: Run ended with state {rs}. ===")
    sys.exit(1)
