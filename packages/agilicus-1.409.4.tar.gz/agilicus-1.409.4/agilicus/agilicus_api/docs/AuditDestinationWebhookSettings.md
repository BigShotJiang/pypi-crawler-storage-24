# AuditDestinationWebhookSettings

Configuration for webhook destintions 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**format** | **str** | The format of the webhook message. This controls how the data is presented to the webhook server. The possible values are:  - agilicus: The agilicus builtin webhook format. See AuditWebhookBulkEvent - unified: A common event format for all record types, sent as a json array.  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


