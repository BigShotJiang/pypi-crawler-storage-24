import pytest

from matterlab_hotplates import IKAHBHotbath


@pytest.mark.real
def test_ika_hotbath_real_read(hardware_com_port):
    hotbath = IKAHBHotbath(com_port=hardware_com_port)

    assert isinstance(hotbath.temp, int)
    assert hotbath.rpm == 0
    assert hotbath.max_temp == 80


@pytest.mark.real
def test_ika_hotbath_real_set_and_standby(hardware_com_port):
    hotbath = IKAHBHotbath(com_port=hardware_com_port)

    hotbath.temp = 40
    assert hotbath.target_temp == 40

    hotbath.stand_by()
    assert hotbath.target_temp == 0
