import pytest

from matterlab_hotplates import IKAHotplate


@pytest.mark.real
def test_ika_real_read(hardware_com_port):
    hotplate = IKAHotplate(com_port=hardware_com_port)

    assert isinstance(hotplate.temp, float)
    assert isinstance(hotplate.rpm, int)
    assert hotplate.max_temp == 200
    assert hotplate.max_rpm == 1700


@pytest.mark.real
def test_ika_real_set_and_standby(hardware_com_port):
    hotplate = IKAHotplate(com_port=hardware_com_port)

    hotplate.rpm = 200
    assert hotplate.target_rpm == 200

    hotplate.stand_by()
    assert hotplate.target_rpm == 0
