import pytest
from matterlab_hotplates.base_hotplate import HeatStirPlate


class MockHotplate(HeatStirPlate):
    def __init__(self, max_temp: float, max_rpm: float):
        super().__init__(max_temp=max_temp, max_rpm=max_rpm)
        self.commands = []
        self._temp = 20.0
        self._rpm = 0
        self._target_temp = 42.0
        self._target_rpm = 1000
        self._heat_switch_status = False
        self._stir_switch_status = False

    def _write_hotplate(self, command: str) -> None:
        self.commands.append(command)

    def _query_hotplate(self, command: str) -> str:
        return ""

    @property
    def temp(self) -> float:
        return self._temp

    @temp.setter
    def temp(self, temp: float) -> None:
        self._target_temp = temp
        self._temp = temp

    @property
    def target_temp(self) -> float:
        return self._target_temp

    @property
    def _heat_switch(self) -> bool:
        return self._heat_switch_status

    @_heat_switch.setter
    def _heat_switch(self, heat_switch_status: bool) -> None:
        self._heat_switch_status = heat_switch_status

    @property
    def rpm(self) -> int:
        return self._rpm

    @rpm.setter
    def rpm(self, rpm: int) -> None:
        self._target_rpm = rpm
        self._rpm = rpm

    @property
    def target_rpm(self) -> int:
        return self._target_rpm

    @property
    def _stir_switch(self) -> bool:
        return self._stir_switch_status

    @_stir_switch.setter
    def _stir_switch(self, stir_switch_status: bool):
        self._stir_switch_status = stir_switch_status


def test_heat_stir_plate_abstract_methods():
    with pytest.raises(TypeError):
        HeatStirPlate(max_temp=100, max_rpm=1000)


def test_heat_stir_plate_instantiation():
    hotplate = MockHotplate(max_temp=100, max_rpm=1000)
    assert isinstance(hotplate, HeatStirPlate)
    assert hotplate.max_temp == 100
    assert hotplate.max_rpm == 1000
    assert hotplate._switch_temp == 0
    assert hotplate._switch_rpm == 0


def test_heat_stir_plate_read():
    hotplate = MockHotplate(max_temp=100, max_rpm=1000)
    assert hotplate.temp == 20.0
    assert hotplate.rpm == 0


def test_heat_stir_plate_targets():
    hotplate = MockHotplate(max_temp=100, max_rpm=1000)
    assert hotplate.target_temp == 42.0
    assert hotplate.target_rpm == 1000


def test_stand_by_sets_switch_values():
    hotplate = MockHotplate(max_temp=100, max_rpm=1000)
    hotplate._switch_temp = 25
    hotplate._switch_rpm = 150
    hotplate.temp = 90
    hotplate.rpm = 500

    hotplate.stand_by()

    assert hotplate.temp == 25
    assert hotplate.rpm == 150
