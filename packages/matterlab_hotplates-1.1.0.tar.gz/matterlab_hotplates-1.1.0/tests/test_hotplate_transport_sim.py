from matterlab_hotplates import (
    HeidolphHotplate,
    IKAHBHotbath,
    IKAHotplate,
    create_heidolph_sim_transport_factory,
    create_ika_hotbath_sim_transport_factory,
    create_ika_hotplate_sim_transport_factory,
)


def test_heidolph_transport_sim_uses_public_api():
    transport_factory = create_heidolph_sim_transport_factory(current_temp=27.8, current_rpm=0)
    hotplate = HeidolphHotplate(com_port="SIM::heidolph", transport_factory=transport_factory)

    assert hotplate.temp == 27.8
    hotplate.rpm = 100
    assert hotplate.target_rpm == 100
    assert hotplate.rpm > 0
    hotplate.stand_by()
    assert hotplate.target_rpm == 0


def test_ika_hotplate_transport_sim_uses_public_api():
    transport_factory = create_ika_hotplate_sim_transport_factory(current_temp=24.5, current_rpm=0, weight=8.2)
    hotplate = IKAHotplate(com_port="SIM::ika", transport_factory=transport_factory)

    assert hotplate.temp == 25.0
    hotplate.temp = 60
    hotplate.rpm = 400
    assert hotplate.target_temp == 60
    assert hotplate.target_rpm == 400
    hotplate.tare()
    assert hotplate.weight == 8.2


def test_ika_hotbath_transport_sim_uses_public_api():
    transport_factory = create_ika_hotbath_sim_transport_factory(current_temp=35, max_temp=80, name="HB10")
    hotbath = IKAHBHotbath(com_port="SIM::hotbath", transport_factory=transport_factory)

    assert hotbath.name == "HB10"
    assert hotbath.temp == 35
    hotbath.temp = 40
    assert hotbath.target_temp == 40
    hotbath.stand_by()
    assert hotbath.target_temp == 0
