from logging import Logger
from typing import Optional, Union

from matterlab_serial_device import SerialDevice, open_close

from matterlab_hotplates.base_hotplate import HeatStirPlate


class IKAHBHotbath(HeatStirPlate, SerialDevice):
    category = "Hotplate"
    ui_fields = ("com_port",)

    _name: str = "IN_NAME"
    _temp_query: str = "IN_PV_2"
    _temp_set: str = "OUT_SP_2"
    _max_temp_query: str = "IN_SP_3"
    _max_temp_set: str = "OUT_SP_3"
    _heat_start: str = "START_1"
    _heat_stop: str = "STOP_1"

    def __init__(
        self,
        com_port: str,
        max_temp: int = 80,
        connect_hardware: bool = True,
        encoding: str = "utf-8",
        baudrate: int = 9600,
        timeout: float = 1.0,
        parity: str = "even",
        bytesize: int = 7,
        stopbits: int = 1,
        query_delay: float = 0.5,
        logger: Optional[Logger] = None,
        **kwargs,
    ) -> None:
        SerialDevice.__init__(
            self,
            com_port=com_port,
            encoding=encoding,
            baudrate=baudrate,
            timeout=timeout,
            parity=parity,
            bytesize=bytesize,
            stopbits=stopbits,
            **kwargs,
        )
        HeatStirPlate.__init__(self, max_temp=max_temp, max_rpm=9999, logger=logger)
        self._query_delay = query_delay
        self._target_temp = 20
        self._target_rpm = 0
        self._heat_switch_status = False
        self._stir_switch_status = False

        if connect_hardware:
            self.logger.info("Initializing IKA hotbath on %s", self.com_port)
            self.stand_by()

    @open_close
    def _write_hotplate(self, command: str) -> None:
        self.query(write_command=f"{command}\r\n", read_delay=self._query_delay)
        self.logger.debug("Write to IKA hotbath on %s: %s", self.com_port, command)

    @open_close
    def _query_hotplate(self, command: str) -> str:
        response = self.query(write_command=f"{command}\r\n", read_delay=self._query_delay).split()[0]
        self.logger.debug("Query to IKA hotbath on %s: %s -> %s", self.com_port, command, response)
        return response

    def _query_hotbath(self, command: str) -> str:
        return self._query_hotplate(command)

    @property
    def name(self) -> str:
        name = self._query_hotplate(self._name)
        self.logger.info("IKA hotbath on %s reports name %s", self.com_port, name)
        return name

    @property
    def temp(self) -> int:
        temp_read = int(self._query_hotplate(self._temp_query))
        self.logger.info("Temperature reading on hotbath %s is %s", self.com_port, temp_read)
        return temp_read

    @temp.setter
    def temp(self, temp: Union[int, float]) -> None:
        if not isinstance(temp, (float, int)):
            raise TypeError("Temperature must be float or int!")

        if not self._switch_temp <= temp <= self.max_temp:
            raise ValueError(f"Temperature out of range: min {self._switch_temp}, max {self.max_temp}!")

        self._target_temp = int(temp)
        self._query_hotplate(f"{self._temp_set} {self._target_temp}")
        self.logger.info("Target hotbath temperature on %s set to %s", self.com_port, self._target_temp)

        if temp == self._switch_temp:
            self._heat_switch = False
        else:
            self._heat_switch = True

    @property
    def target_temp(self) -> int:
        return self._target_temp

    @property
    def _heat_switch(self) -> bool:
        self.logger.info("Hotbath heat switch on %s is %s", self.com_port, self._heat_switch_status)
        return self._heat_switch_status

    @_heat_switch.setter
    def _heat_switch(self, heat_switch_status: bool) -> None:
        self._heat_switch_status = heat_switch_status
        if self._heat_switch_status:
            self._query_hotplate(self._heat_start)
            self.logger.info("Start heating hotbath on %s", self.com_port)
        else:
            self._query_hotplate(self._heat_stop)
            self.logger.info("Stop heating hotbath on %s", self.com_port)

    @property
    def maxtemp(self) -> int:
        max_temp = int(self._query_hotplate(self._max_temp_query))
        self.logger.info("Hotbath %s max temperature limit is %s", self.com_port, max_temp)
        return max_temp

    @maxtemp.setter
    def maxtemp(self, maxtemp: int) -> None:
        self._query_hotplate(f"{self._max_temp_set} {int(maxtemp)}")
        self.logger.info("Set hotbath %s max temperature limit to %s", self.com_port, int(maxtemp))

    @property
    def rpm(self) -> int:
        self.logger.info("IKA hotbath on %s does not support stirring; rpm is 0", self.com_port)
        return 0

    @rpm.setter
    def rpm(self, rpm: int) -> None:
        if rpm != self._switch_rpm:
            raise ValueError("IKA hotbath does not support stirring; rpm must remain 0.")
        self._target_rpm = 0
        self._stir_switch = False

    @property
    def target_rpm(self) -> int:
        return self._target_rpm

    @property
    def _stir_switch(self) -> bool:
        return False

    @_stir_switch.setter
    def _stir_switch(self, stir_switch_status: bool) -> None:
        if stir_switch_status:
            raise ValueError("IKA hotbath does not support stirring.")
        self._stir_switch_status = False
