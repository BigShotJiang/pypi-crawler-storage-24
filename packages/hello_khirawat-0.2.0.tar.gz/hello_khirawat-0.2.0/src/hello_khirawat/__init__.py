"""A simple sample package to test PyPI publishing."""

__version__ = "0.2.0"


def greet(name: str = "World") -> str:
    """Return a friendly greeting."""
    return f"Hello, {name}! Welcome from hello-khirawat package."
