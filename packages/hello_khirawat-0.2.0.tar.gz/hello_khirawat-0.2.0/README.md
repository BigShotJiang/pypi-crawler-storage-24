# hello-khirawat

A simple sample Python package to test PyPI publishing.

## Installation

```bash
pip install hello-khirawat
```

## Usage

### As a library

```python
from hello_khirawat import greet

print(greet("PyPI"))
```

### As a CLI tool

```bash
hello-khirawat Alice
```
