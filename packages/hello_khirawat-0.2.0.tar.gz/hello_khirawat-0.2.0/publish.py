"""Publish package to PyPI by hitting the upload API directly."""

import configparser
import email.parser
import hashlib
import os
import sys
import tarfile
import zipfile
from pathlib import Path

import requests


def read_token(config_path=".pypirc", repository="pypi"):
    config = configparser.ConfigParser()
    config.read(config_path)
    if repository not in config:
        sys.exit(f"Section [{repository}] not found in {config_path}")
    return config[repository]["password"]


def extract_metadata(filepath):
    """Extract metadata from the METADATA/PKG-INFO inside the dist file."""
    filename = os.path.basename(filepath)
    raw = None

    if filename.endswith(".whl"):
        with zipfile.ZipFile(filepath) as zf:
            for name in zf.namelist():
                if name.endswith(".dist-info/METADATA"):
                    raw = zf.read(name).decode("utf-8")
                    break
    elif filename.endswith(".tar.gz"):
        with tarfile.open(filepath, "r:gz") as tf:
            for member in tf.getmembers():
                if member.name.endswith("/PKG-INFO"):
                    raw = tf.extractfile(member).read().decode("utf-8")
                    break

    if not raw:
        sys.exit(f"Could not find metadata in {filename}")

    parser = email.parser.Parser()
    meta = parser.parsestr(raw)
    return meta


def file_hashes(filepath):
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            md5.update(chunk)
            sha256.update(chunk)
    return md5.hexdigest(), sha256.hexdigest()


def upload(filepath, token, repository_url="https://upload.pypi.org/legacy/"):
    filename = os.path.basename(filepath)
    meta = extract_metadata(filepath)
    md5_digest, sha256_digest = file_hashes(filepath)

    filetype = "sdist" if filename.endswith(".tar.gz") else "bdist_wheel"

    data = {
        ":action": "file_upload",
        "protocol_version": "1",
        "metadata_version": meta.get("Metadata-Version", "2.1"),
        "name": meta.get("Name"),
        "version": meta.get("Version"),
        "summary": meta.get("Summary", ""),
        "author": meta.get("Author", ""),
        "author_email": meta.get("Author-email", ""),
        "license": meta.get("License", ""),
        "requires_python": meta.get("Requires-Python", ""),
        "description_content_type": meta.get("Description-Content-Type", ""),
        "description": meta.get_payload() or "",
        "filetype": filetype,
        "md5_digest": md5_digest,
        "sha256_digest": sha256_digest,
    }

    classifiers = meta.get_all("Classifier")
    if classifiers:
        data["classifiers"] = classifiers

    if filetype == "bdist_wheel":
        parts = filename[: -len(".whl")].split("-")
        data["pyversion"] = parts[2]
    else:
        data["pyversion"] = ""

    with open(filepath, "rb") as f:
        files = {"content": (filename, f, "application/octet-stream")}
        resp = requests.post(
            repository_url,
            data=data,
            files=files,
            auth=("__token__", token),
        )

    return resp


def main():
    repo = sys.argv[1] if len(sys.argv) > 1 else "pypi"

    repo_urls = {
        "pypi": "https://upload.pypi.org/legacy/",
        "testpypi": "https://test.pypi.org/legacy/",
    }
    url = repo_urls.get(repo, repo)

    token = read_token(repository=repo)
    dist_dir = Path("dist")

    if not dist_dir.exists() or not list(dist_dir.iterdir()):
        sys.exit("No files found in dist/. Run 'python -m build' first.")

    for filepath in sorted(dist_dir.iterdir()):
        if filepath.suffix not in (".gz", ".whl"):
            continue
        print(f"Uploading {filepath.name} to {url} ...")
        resp = upload(str(filepath), token, url)
        if resp.status_code == 200:
            print(f"  Success! {resp.status_code}")
        else:
            print(f"  Failed: {resp.status_code} — {resp.text}")

    print("\nDone.")


if __name__ == "__main__":
    main()
