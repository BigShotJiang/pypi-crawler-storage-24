"""Typer CLI for Cobo Agent Wallet SDK."""

from __future__ import annotations

import asyncio
from contextlib import suppress
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_FLOOR
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable, NoReturn

import typer

from cobo_agent_wallet.cli.config import (
    load_config,
    resolve_config_path,
    save_config,
)
from cobo_agent_wallet.cli.tss import (
    DEFAULT_TSS_NODE_FILENAME,
    TSS_NODE_ENV_ENV,
    create_mpc_wallet,
    download_tss_node,
    init_tss_node,
    poll_wallet_status,
    start_tss_node,
)
from cobo_agent_wallet.errors import APIError, AuthenticationError, PolicyDeniedError
from cobo_agent_wallet_api.models.delegation_permission import DelegationPermission
from cobo_agent_wallet_api.models.freeze_scope import FreezeScope as SDKFreezeScope
from cobo_agent_wallet_api.models.inline_policy_create import InlinePolicyCreate
from cobo_agent_wallet_api.models.policy_type import PolicyType
from cobo_agent_wallet.client import WalletAPIClient
from cobo_agent_wallet_api.exceptions import ApiException
from cobo_agent_wallet.toolkit import AgentWalletToolkit

AGENT_WALLET_API_KEY = "AGENT_WALLET_API_KEY"
AGENT_WALLET_API_URL = "AGENT_WALLET_API_URL"
AGENT_WALLET_TIMEOUT = "AGENT_WALLET_TIMEOUT"
CAW_CONFIG_PATH = "CAW_CONFIG_PATH"

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Cobo Agent Wallet CLI",
)


class OutputFormat(str, Enum):
    JSON = "json"
    TABLE = "table"


class FreezeScope(str, Enum):
    OWNER = "owner"
    WALLET = "wallet"
    DELEGATION = "delegation"


@dataclass(frozen=True)
class CLIContext:
    api_key: str
    api_url: str
    timeout: float
    output_format: OutputFormat


ClientOperation = Callable[[WalletAPIClient], Awaitable[Any]]


@app.callback()
def main(
    ctx: typer.Context,
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        envvar=AGENT_WALLET_API_KEY,
        help="AgentWallet API key. Falls back to AGENT_WALLET_API_KEY.",
    ),
    api_url: str = typer.Option(
        "http://localhost:8000",
        "--api-url",
        envvar=AGENT_WALLET_API_URL,
        help="AgentWallet API URL. Falls back to AGENT_WALLET_API_URL.",
    ),
    timeout: float = typer.Option(
        30.0,
        "--timeout",
        envvar=AGENT_WALLET_TIMEOUT,
        help="Request timeout in seconds. Falls back to AGENT_WALLET_TIMEOUT.",
    ),
    output_format: OutputFormat = typer.Option(
        OutputFormat.JSON,
        "--format",
        case_sensitive=False,
        help="Output format: json or table.",
    ),
) -> None:
    """Configure global CLI options."""

    if ctx.resilient_parsing:
        return

    ctx.obj = CLIContext(
        api_key=api_key or "",
        api_url=api_url,
        timeout=timeout,
        output_format=output_format,
    )


def _get_context(ctx: typer.Context) -> CLIContext:
    context = ctx.obj
    if isinstance(context, CLIContext):
        return context
    raise RuntimeError("CLI context not initialized.")


def _to_cell(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True, ensure_ascii=True)
    return str(value)


def _render_table(headers: list[str], rows: list[list[str]]) -> str:
    widths = [len(header) for header in headers]
    for row in rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], len(cell))

    def _line(cells: list[str]) -> str:
        return " | ".join(cell.ljust(widths[idx]) for idx, cell in enumerate(cells))

    separator = "-+-".join("-" * width for width in widths)
    lines = [_line(headers), separator]
    lines.extend(_line(row) for row in rows)
    return "\n".join(lines)


def _table_from_list(items: list[Any]) -> str:
    if not items:
        return "(empty)"

    if not all(isinstance(item, dict) for item in items):
        rows = [[str(idx), _to_cell(item)] for idx, item in enumerate(items)]
        return _render_table(["index", "value"], rows)

    headers: list[str] = []
    for item in items:
        for key in item.keys():
            if key not in headers:
                headers.append(str(key))

    rows = [[_to_cell(item.get(key, "")) for key in headers] for item in items]
    return _render_table(headers, rows)


def _table_from_dict(payload: dict[str, Any]) -> str:
    items = payload.get("items")
    if isinstance(items, list):
        table = _table_from_list(items)
        extra_lines = [f"{k}: {_to_cell(v)}" for k, v in payload.items() if k != "items"]
        if extra_lines:
            return f"{table}\n\n" + "\n".join(extra_lines)
        return table

    rows = [[str(key), _to_cell(value)] for key, value in payload.items()]
    if not rows:
        return "(empty)"
    return _render_table(["field", "value"], rows)


def _emit(payload: Any, output_format: OutputFormat) -> None:
    if output_format == OutputFormat.JSON:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True, default=str, ensure_ascii=True))
        return

    if isinstance(payload, list):
        typer.echo(_table_from_list(payload))
        return
    if isinstance(payload, dict):
        typer.echo(_table_from_dict(payload))
        return

    typer.echo(str(payload))


def _handle_api_error(exc: APIError, output_format: OutputFormat) -> NoReturn:
    if isinstance(exc, PolicyDeniedError):
        denial_payload = {
            "error": "POLICY_DENIED",
            "code": exc.denial.code,
            "reason": exc.denial.reason,
            "details": exc.denial.details,
            "suggestion": exc.denial.suggestion,
        }
        if output_format == OutputFormat.JSON:
            typer.echo(
                json.dumps(denial_payload, indent=2, sort_keys=True, ensure_ascii=True), err=True
            )
        else:
            typer.echo(AgentWalletToolkit._format_denial(exc.denial), err=True)
        raise typer.Exit(code=1)

    if isinstance(exc, AuthenticationError):
        typer.echo(f"Authentication failed: {exc}", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"API error ({exc.status_code}): {exc}", err=True)
    raise typer.Exit(code=1)


def _run_async_operation(context: CLIContext, operation: Callable[[], Awaitable[Any]]) -> Any:
    try:
        return asyncio.run(operation())
    except ApiException as exc:
        # Convert generated SDK exception to our APIError or PolicyDeniedError
        body = None
        if exc.body:
            try:
                body = json.loads(exc.body) if isinstance(exc.body, str) else exc.body
            except (json.JSONDecodeError, TypeError):
                pass

        # Check if this is a policy denial (403 with denial structure)
        if exc.status == 403 and body:
            from cobo_agent_wallet.errors import PolicyDenial

            denial = PolicyDenial.try_from_response(body)
            if denial:
                policy_error = PolicyDeniedError(
                    denial.reason,
                    status_code=403,
                    response_body=body,
                    denial=denial,
                )
                _handle_api_error(policy_error, context.output_format)
                return None

        api_error = APIError(
            str(exc.reason or exc), status_code=exc.status or 500, response_body=body
        )
        _handle_api_error(api_error, context.output_format)
    except APIError as exc:
        _handle_api_error(exc, context.output_format)
    except (RuntimeError, TimeoutError, FileNotFoundError, ValueError) as exc:
        typer.echo(f"Runtime error: {exc}", err=True)
        raise typer.Exit(code=1) from exc


def _make_client(
    context: CLIContext,
    *,
    api_key: str | None = None,
    allow_unauthenticated: bool = False,
) -> WalletAPIClient:
    kwargs: dict[str, Any] = {
        "base_url": context.api_url,
        "timeout": context.timeout,
    }
    if api_key:
        kwargs["api_key"] = api_key
    elif allow_unauthenticated:
        kwargs["allow_unauthenticated"] = True
    return WalletAPIClient(**kwargs)


def _run_with_client(context: CLIContext, operation: ClientOperation) -> Any:
    if not context.api_key:
        typer.echo(
            f"API key is required. Set --api-key or {AGENT_WALLET_API_KEY}.",
            err=True,
        )
        raise typer.Exit(code=1)

    async def _runner() -> Any:
        client = _make_client(context, api_key=context.api_key)
        try:
            return await operation(client)
        finally:
            await client.close()

    return _run_async_operation(context, _runner)


def _progress(message: str, *, enabled: bool) -> None:
    if enabled:
        typer.echo(message, err=True)


def _extract_text(payload: dict[str, Any], *keys: str) -> str | None:
    for key in keys:
        raw = payload.get(key)
        if raw is None:
            continue
        text = str(raw).strip()
        if text:
            return text
    return None


def _require_text(payload: dict[str, Any], *keys: str) -> str:
    value = _extract_text(payload, *keys)
    if value is None:
        joined = ", ".join(keys)
        raise RuntimeError(f"Missing required response field: {joined}")
    return value


def _parse_decimal(raw: Any) -> Decimal | None:
    if raw is None:
        return None
    try:
        return Decimal(str(raw))
    except (InvalidOperation, ValueError):
        return None


def _usage_cell(spent: Any, limit: Any) -> str:
    spent_dec = _parse_decimal(spent)
    limit_dec = _parse_decimal(limit)
    if spent_dec is None:
        return "n/a"
    if limit_dec is None or limit_dec <= 0:
        return f"{spent_dec} / -"
    return f"{spent_dec} / {limit_dec} ({_progress_bar(spent_dec, limit_dec)})"


def _progress_bar(spent: Decimal, limit: Decimal, width: int = 12) -> str:
    ratio = max(Decimal("0"), min(Decimal("1"), spent / limit))
    filled = int((ratio * Decimal(width)).to_integral_value(rounding=ROUND_FLOOR))
    return "[" + ("#" * filled).ljust(width, ".") + "]"


def _render_wallet_status_table(payload: dict[str, Any]) -> str:
    wallet = payload.get("wallet")
    if not isinstance(wallet, dict):
        return _table_from_dict(payload)

    lines = [
        f"wallet_uuid: {_to_cell(wallet.get('uuid', ''))}",
        f"name: {_to_cell(wallet.get('name', ''))}",
        f"owner_id: {_to_cell(wallet.get('owner_id', ''))}",
        f"wallet_status: {_to_cell(wallet.get('status', ''))}",
    ]

    summary = payload.get("spend_summary")
    if not isinstance(summary, list) or not summary:
        lines.append("spend_summary: (empty)")
        return "\n".join(lines)

    rows: list[list[str]] = []
    frozen_count = 0
    for item in summary:
        if not isinstance(item, dict):
            continue
        is_frozen = bool(item.get("frozen"))
        if is_frozen:
            frozen_count += 1
        rows.append(
            [
                _to_cell(item.get("delegation_id", "")),
                _to_cell(item.get("operator_id", "")),
                "yes" if is_frozen else "no",
                _usage_cell(item.get("daily_spent"), item.get("daily_limit")),
                _usage_cell(item.get("monthly_spent"), item.get("monthly_limit")),
            ],
        )
    lines.append(
        f"delegations: {len(rows)} total, {frozen_count} frozen",
    )
    lines.append("")
    lines.append(
        _render_table(
            ["delegation_id", "operator_id", "frozen", "daily_usage", "monthly_usage"],
            rows,
        ),
    )
    return "\n".join(lines)


async def _list_all_owner_delegations(
    client: WalletAPIClient,
    *,
    wallet_id: str | None = None,
) -> list[dict[str, Any]]:
    offset = 0
    limit = 200
    all_items: list[dict[str, Any]] = []
    while True:
        page = await client.list_delegations(
            wallet_id=wallet_id,
            offset=offset,
            limit=limit,
        )
        if not isinstance(page, list) or not page:
            break
        all_items.extend(item for item in page if isinstance(item, dict))
        if len(page) < limit:
            break
        offset += limit
    return all_items


async def _infer_owner_id(client: WalletAPIClient) -> str | None:
    items = await _list_all_owner_delegations(client, wallet_id=None)
    if not items:
        return None
    owner_id = items[0].get("owner_id")
    return str(owner_id) if owner_id is not None else None


async def _estimate_affected_count(
    client: WalletAPIClient,
    *,
    scope: FreezeScope,
    delegation_id: str | None,
    wallet_id: str | None,
    frozen_state: bool,
) -> int:
    items = await _list_all_owner_delegations(
        client, wallet_id=wallet_id if scope == FreezeScope.WALLET else None
    )
    if scope == FreezeScope.DELEGATION:
        items = [item for item in items if str(item.get("id", "")) == str(delegation_id)]

    count = 0
    for item in items:
        status_value = str(item.get("status", "")).lower()
        if status_value != "active":
            continue
        if bool(item.get("frozen")) == frozen_state:
            continue
        count += 1
    return count


def _validate_scope_params(
    *,
    scope: FreezeScope,
    owner_id: str | None,
    wallet_id: str | None,
    delegation_id: str | None,
) -> None:
    if scope == FreezeScope.OWNER:
        if wallet_id is not None:
            raise typer.BadParameter("--wallet-id is only valid when --scope wallet.")
        if delegation_id is not None:
            raise typer.BadParameter("--delegation-id is only valid when --scope delegation.")
        return

    if scope == FreezeScope.WALLET:
        if wallet_id is None:
            raise typer.BadParameter("--wallet-id is required when --scope wallet.")
        if owner_id is not None:
            raise typer.BadParameter("--owner-id is only valid when --scope owner.")
        if delegation_id is not None:
            raise typer.BadParameter("--delegation-id is only valid when --scope delegation.")
        return

    if delegation_id is None:
        raise typer.BadParameter("--delegation-id is required when --scope delegation.")
    if owner_id is not None:
        raise typer.BadParameter("--owner-id is only valid when --scope owner.")
    if wallet_id is not None:
        raise typer.BadParameter("--wallet-id is only valid when --scope wallet.")


@app.command("list-wallets")
def list_wallets(
    ctx: typer.Context,
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
    include_archived: bool = typer.Option(False),
) -> None:
    """List wallets accessible to the caller."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_wallets(
            limit=limit, offset=offset, include_archived=include_archived
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("balance")
def balance(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
) -> None:
    """Show wallet balance by wallet UUID."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_wallet(wallet_uuid, include_spend_summary=True)

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("transfer")
def transfer(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    to: str = typer.Option(..., "--to", help="Destination address."),
    token: str = typer.Option(..., "--token", help="Token ID."),
    amount: str = typer.Option(..., "--amount", help="Transfer amount."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
    request_id: str | None = typer.Option(None, "--request-id", help="Optional idempotency key."),
) -> None:
    """Transfer tokens with policy enforcement."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.transfer_tokens(
            wallet_uuid,
            chain_id=chain,
            dst_addr=to,
            token_id=token,
            amount=amount,
            src_addr=src_addr,
            request_id=request_id,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("list-transactions")
def list_transactions(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
    status: str | None = typer.Option(None, "--status", help="Optional status filter."),
) -> None:
    """List wallet transactions with optional status filter."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_transactions(
            wallet_uuid,
            limit=limit,
            offset=offset,
            status=status,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("delegate")
def delegate(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    to: str = typer.Option(..., "--to", help="Operator principal UUID."),
    max_tx: str = typer.Option(..., "--max-tx", help="Maximum amount per transaction."),
    permission: list[str] | None = typer.Option(
        None,
        "--permission",
        help="Permission to grant. Can be repeated.",
    ),
) -> None:
    """Create a delegation with an operator role and max-per-tx constraint."""

    context = _get_context(ctx)
    permission_list = permission or ["operator"]
    # Convert string permissions to DelegationPermission enums
    permissions_enum = [DelegationPermission(p) for p in permission_list]
    # Create inline policy for max_per_tx constraint
    policies = [
        InlinePolicyCreate(
            name="max_per_tx",
            type=PolicyType.TRANSFER,
            rules={"max_per_tx": max_tx},
        )
    ]

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_delegation(
            operator_id=to,
            wallet_id=wallet_uuid,
            permissions=permissions_enum,
            policies=policies,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("received-delegations")
def received_delegations(
    ctx: typer.Context,
    owner_id: str | None = typer.Option(None, "--owner-id", help="Filter by owner principal UUID."),
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    status: str | None = typer.Option(None, "--status", help="Filter by delegation status."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List delegations received by the current principal (as operator)."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_received_delegations(
            owner_id=owner_id,
            wallet_id=wallet_id,
            status=status,
            limit=limit,
            offset=offset,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("estimate-transfer-fee")
def estimate_transfer_fee(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    to: str = typer.Option(..., "--to", help="Destination address."),
    token: str = typer.Option(..., "--token", help="Token ID."),
    amount: str = typer.Option(..., "--amount", help="Transfer amount."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
) -> None:
    """Estimate transfer fee for a transaction."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.estimate_transfer_fee(
            wallet_uuid,
            chain_id=chain,
            dst_addr=to,
            token_id=token,
            amount=amount,
            src_addr=src_addr,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("contract-call")
def contract_call(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    contract: str = typer.Option(..., "--contract", help="Contract address."),
    calldata: str = typer.Option(..., "--calldata", help="Hex-encoded calldata."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    value: str | None = typer.Option(None, "--value", help="Native token value to send."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
    function_id: str | None = typer.Option(None, "--function-id", help="Function identifier."),
    request_id: str | None = typer.Option(None, "--request-id", help="Optional idempotency key."),
) -> None:
    """Execute a contract call with policy enforcement."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        # Note: function_id is accepted by CLI but not used by current SDK
        _ = function_id  # Reserved for future use
        return await client.contract_call(
            wallet_uuid,
            chain_id=chain,
            contract_addr=contract,
            calldata=calldata,
            value=value,
            src_addr=src_addr,
            request_id=request_id,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("estimate-contract-call-fee")
def estimate_contract_call_fee(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    contract: str = typer.Option(..., "--contract", help="Contract address."),
    calldata: str = typer.Option(..., "--calldata", help="Hex-encoded calldata."),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID."),
    value: str | None = typer.Option(None, "--value", help="Native token value to send."),
    src_addr: str | None = typer.Option(None, "--src-addr", help="Source address."),
    function_id: str | None = typer.Option(None, "--function-id", help="Function identifier."),
) -> None:
    """Estimate contract call fee."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        # Note: function_id is accepted by CLI but not used by current SDK
        _ = function_id  # Reserved for future use
        return await client.estimate_contract_call_fee(
            wallet_uuid,
            chain_id=chain,
            contract_addr=contract,
            calldata=calldata,
            value=value,
            src_addr=src_addr,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("audit-logs")
def audit_logs(
    ctx: typer.Context,
    wallet: str | None = typer.Option(None, "--wallet", help="Wallet UUID filter."),
    result: str | None = typer.Option(
        None, "--result", help="Result filter: allowed/denied/error."
    ),
    action: str | None = typer.Option(None, "--action", help="Action filter."),
    cursor: str | None = typer.Option(None, "--cursor", help="Cursor token."),
    limit: int = typer.Option(50, min=1, max=200),
) -> None:
    """Query audit logs with optional filters."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_audit_logs(
            wallet_id=wallet,
            result=result,
            action=action,
            cursor=cursor,
            limit=limit,
        )

    logs = _run_with_client(context, _operation)
    _emit(logs, context.output_format)


@app.command("freeze")
def freeze(
    ctx: typer.Context,
    scope: FreezeScope = typer.Option(..., "--scope", case_sensitive=False),
    owner_id: str | None = typer.Option(
        None,
        "--owner-id",
        help="Owner principal UUID. Optional for --scope owner if inferable.",
    ),
    wallet_id: str | None = typer.Option(
        None, "--wallet-id", help="Wallet UUID for --scope wallet."
    ),
    delegation_id: str | None = typer.Option(
        None,
        "--delegation-id",
        help="Delegation UUID for --scope delegation.",
    ),
    reason: str | None = typer.Option(None, "--reason", help="Optional freeze reason."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview affected delegation count without applying changes.",
    ),
) -> None:
    """Freeze delegations by owner, wallet, or delegation scope."""

    context = _get_context(ctx)
    _validate_scope_params(
        scope=scope,
        owner_id=owner_id,
        wallet_id=wallet_id,
        delegation_id=delegation_id,
    )

    async def _operation(client: WalletAPIClient) -> Any:
        resolved_owner_id = owner_id
        if scope == FreezeScope.OWNER and resolved_owner_id is None:
            resolved_owner_id = await _infer_owner_id(client)
            if resolved_owner_id is None:
                raise RuntimeError(
                    "Unable to infer owner_id automatically. Pass --owner-id for --scope owner."
                )

        estimated: int | None = None
        if dry_run or not yes:
            estimated = await _estimate_affected_count(
                client,
                scope=scope,
                delegation_id=delegation_id,
                wallet_id=wallet_id,
                frozen_state=True,
            )
        if dry_run:
            assert estimated is not None
            return {
                "dry_run": True,
                "scope": scope.value,
                "estimated_count": estimated,
            }
        if not yes:
            confirmed = typer.confirm(
                f"Freeze {estimated} delegation(s)?",
                default=False,
            )
            if not confirmed:
                return {"cancelled": True, "scope": scope.value, "estimated_count": estimated}

        return await client.freeze_delegations(
            scope=SDKFreezeScope(scope.value),
            owner_id=resolved_owner_id,
            wallet_id=wallet_id,
            delegation_id=delegation_id,
            reason=reason,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("unfreeze")
def unfreeze(
    ctx: typer.Context,
    scope: FreezeScope = typer.Option(..., "--scope", case_sensitive=False),
    owner_id: str | None = typer.Option(
        None,
        "--owner-id",
        help="Owner principal UUID. Optional for --scope owner if inferable.",
    ),
    wallet_id: str | None = typer.Option(
        None, "--wallet-id", help="Wallet UUID for --scope wallet."
    ),
    delegation_id: str | None = typer.Option(
        None,
        "--delegation-id",
        help="Delegation UUID for --scope delegation.",
    ),
    reason: str | None = typer.Option(None, "--reason", help="Optional unfreeze reason."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview affected delegation count without applying changes.",
    ),
) -> None:
    """Unfreeze delegations by owner, wallet, or delegation scope."""

    context = _get_context(ctx)
    _validate_scope_params(
        scope=scope,
        owner_id=owner_id,
        wallet_id=wallet_id,
        delegation_id=delegation_id,
    )

    async def _operation(client: WalletAPIClient) -> Any:
        resolved_owner_id = owner_id
        if scope == FreezeScope.OWNER and resolved_owner_id is None:
            resolved_owner_id = await _infer_owner_id(client)
            if resolved_owner_id is None:
                raise RuntimeError(
                    "Unable to infer owner_id automatically. Pass --owner-id for --scope owner."
                )

        estimated: int | None = None
        if dry_run or not yes:
            estimated = await _estimate_affected_count(
                client,
                scope=scope,
                delegation_id=delegation_id,
                wallet_id=wallet_id,
                frozen_state=False,
            )
        if dry_run:
            assert estimated is not None
            return {
                "dry_run": True,
                "scope": scope.value,
                "estimated_count": estimated,
            }
        if not yes:
            confirmed = typer.confirm(
                f"Unfreeze {estimated} delegation(s)?",
                default=False,
            )
            if not confirmed:
                return {"cancelled": True, "scope": scope.value, "estimated_count": estimated}

        return await client.unfreeze_delegations(
            scope=SDKFreezeScope(scope.value),
            owner_id=resolved_owner_id,
            wallet_id=wallet_id,
            delegation_id=delegation_id,
            reason=reason,
        )

    result = _run_with_client(context, _operation)
    _emit(result, context.output_format)


@app.command("status")
def status(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
) -> None:
    """Show wallet status with spend summary and frozen delegation state."""

    context = _get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        wallet = await client.get_wallet(wallet_uuid, include_spend_summary=True)
        # Format as status response
        if isinstance(wallet, dict):
            return {
                "wallet": wallet,
                "spend_summary": wallet.get("spend_summary", []),
            }
        return wallet

    result = _run_with_client(context, _operation)
    if context.output_format == OutputFormat.TABLE and isinstance(result, dict):
        typer.echo(_render_wallet_status_table(result))
        return
    _emit(result, context.output_format)


@app.command("provision")
def provision(
    ctx: typer.Context,
    token: str = typer.Option(..., "--token", help="Setup token from owner Telegram flow."),
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Config path. Falls back to CAW_CONFIG_PATH or ~/.cobo-agent-wallet/config.",
    ),
    tss_node_path: str | None = typer.Option(
        None,
        "--tss-node-path",
        help="Path to store TSS-Node binary. Defaults to ~/.cobo-agent-wallet/tss-node.",
    ),
    tss_env: str | None = typer.Option(
        None,
        "--tss-env",
        envvar=TSS_NODE_ENV_ENV,
        help="TSS node env: dev (--dev), prod (--prod), sandbox (--sandbox). Default: dev.",
    ),
    vault_poll_interval: float = typer.Option(2.0, "--vault-poll-interval", min=0.0),
    vault_timeout: float = typer.Option(300.0, "--vault-timeout", min=1.0),
) -> None:
    """Path A provisioning: token bootstrap + vault keygen orchestration."""

    context = _get_context(ctx)
    show_progress = context.output_format != OutputFormat.JSON
    resolved_config_path = resolve_config_path(config_path)
    resolved_tss_path = (
        Path(tss_node_path).expanduser()
        if tss_node_path
        else resolved_config_path.parent / DEFAULT_TSS_NODE_FILENAME
    )

    async def _operation() -> Any:
        _progress("[1/4] Registering with Cobo backend...", enabled=show_progress)
        bootstrap_client = _make_client(context, allow_unauthenticated=True)
        try:
            provision_result = await bootstrap_client.provision_agent(token=token)
        finally:
            await bootstrap_client.close()
        if not isinstance(provision_result, dict):
            raise RuntimeError("Invalid provisioning response")

        agent_id = _require_text(provision_result, "agent_id")
        api_key = _require_text(provision_result, "api_key")
        onboarding_session_id = _require_text(provision_result, "onboarding_session_id")
        status_value = _extract_text(provision_result, "status") or ""
        if status_value.lower() != "active":
            raise RuntimeError(f"Unexpected provisioning status: {status_value}")
        _progress("[1/4] Registering with Cobo backend... done", enabled=show_progress)

        config_payload: dict[str, Any] = {
            "agent_id": agent_id,
            "api_key": api_key,
            "api_url": context.api_url,
            "status": status_value,
            "onboarding_session_id": onboarding_session_id,
            "activation_secret": None,
            "deep_link": None,
        }
        save_config(config_payload, resolved_config_path)

        _progress("[2/4] Downloading TSS-Node...", enabled=show_progress)
        await asyncio.to_thread(
            download_tss_node,
            destination=resolved_tss_path,
            tss_env=tss_env,
            reporter=lambda message: _progress(f"[TSS] {message}", enabled=show_progress),
        )
        _progress("[2/4] Downloading TSS-Node... done", enabled=show_progress)

        _progress("[3/4] Initializing TSS-Node...", enabled=show_progress)
        init_result = await asyncio.to_thread(
            init_tss_node,
            tss_binary_path=resolved_tss_path,
            config_path=resolved_config_path,
        )
        _progress("[3/4] Initializing TSS-Node... done", enabled=show_progress)
        main_node_id = _require_text(init_result, "tss_node_id")

        _progress("[4/4] Starting TSS-Node and creating MPC wallet...", enabled=show_progress)
        await asyncio.to_thread(
            start_tss_node,
            tss_binary_path=resolved_tss_path,
            tss_env=tss_env,
            reporter=lambda message: _progress(f"[TSS] {message}", enabled=show_progress),
        )
        client = _make_client(context, api_key=api_key)
        try:
            wallet_payload = await create_mpc_wallet(
                client=client,
                main_node_id=main_node_id,
            )
            wallet_uuid = _require_text(wallet_payload, "wallet_uuid", "uuid", "id")
            wallet_status_payload = await poll_wallet_status(
                client=client,
                wallet_uuid=wallet_uuid,
                poll_interval_seconds=vault_poll_interval,
                timeout_seconds=vault_timeout,
            )
        finally:
            await client.close()
        _progress("[4/4] Starting TSS-Node and creating MPC wallet... done", enabled=show_progress)

        config_payload.update(
            {
                "wallet_uuid": wallet_uuid,
                "status": _extract_text(wallet_status_payload, "status") or "active",
                "activation_secret": None,
            }
        )
        save_config(config_payload, resolved_config_path)
        return {
            "agent_id": agent_id,
            "status": config_payload["status"],
            "wallet_uuid": wallet_uuid,
            "onboarding_session_id": onboarding_session_id,
            "config_path": str(resolved_config_path),
            "tss_node_path": str(resolved_tss_path),
        }

    result = _run_async_operation(context, _operation)
    _emit(result, context.output_format)


@app.command("init")
def init(
    ctx: typer.Context,
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Config path. Falls back to CAW_CONFIG_PATH or ~/.cobo-agent-wallet/config.",
    ),
    tss_node_path: str | None = typer.Option(
        None,
        "--tss-node-path",
        help="Path to store TSS-Node binary. Defaults to ~/.cobo-agent-wallet/tss-node.",
    ),
    tss_env: str | None = typer.Option(
        None,
        "--tss-env",
        envvar=TSS_NODE_ENV_ENV,
        help="TSS node env: dev (--dev), prod (--prod), sandbox (--sandbox). Default: dev.",
    ),
    status_poll_interval: float = typer.Option(2.0, "--status-poll-interval", min=0.0),
    status_timeout: float = typer.Option(600.0, "--status-timeout", min=1.0),
    vault_poll_interval: float = typer.Option(2.0, "--vault-poll-interval", min=0.0),
    vault_timeout: float = typer.Option(300.0, "--vault-timeout", min=1.0),
) -> None:
    """Path B provisioning: temporary principal, deep link, then upgrade + vault."""

    context = _get_context(ctx)
    show_progress = context.output_format != OutputFormat.JSON
    resolved_config_path = resolve_config_path(config_path)
    resolved_tss_path = (
        Path(tss_node_path).expanduser()
        if tss_node_path
        else resolved_config_path.parent / DEFAULT_TSS_NODE_FILENAME
    )

    async def _operation() -> Any:
        _progress("[1/5] Registering with Cobo backend...", enabled=show_progress)
        bootstrap_client = _make_client(context, allow_unauthenticated=True)
        try:
            provision_result = await bootstrap_client.provision_agent()
        finally:
            await bootstrap_client.close()
        if not isinstance(provision_result, dict):
            raise RuntimeError("Invalid provisioning response")

        agent_id = _require_text(provision_result, "agent_id")
        api_key = _require_text(provision_result, "api_key")
        activation_secret = _require_text(provision_result, "activation_secret")
        deep_link = _require_text(provision_result, "deep_link")
        status_value = (_extract_text(provision_result, "status") or "").lower()
        if status_value != "temporary":
            raise RuntimeError(f"Unexpected init status: {status_value}")
        _progress("[1/5] Registering with Cobo backend... done", enabled=show_progress)

        config_payload: dict[str, Any] = {
            "agent_id": agent_id,
            "api_key": api_key,
            "api_url": context.api_url,
            "status": status_value,
            "activation_secret": activation_secret,
            "deep_link": deep_link,
            "onboarding_session_id": None,
        }
        save_config(config_payload, resolved_config_path)

        _progress("[2/5] Downloading TSS-Node in background...", enabled=show_progress)
        download_task = asyncio.create_task(
            asyncio.to_thread(
                download_tss_node,
                destination=resolved_tss_path,
                tss_env=tss_env,
                reporter=lambda message: _progress(f"[TSS] {message}", enabled=show_progress),
            )
        )
        try:
            _progress("Share this link with your wallet owner:", enabled=show_progress)
            _progress(f"  {deep_link}", enabled=show_progress)

            _progress("[3/5] Waiting for owner to connect...", enabled=show_progress)
            status_client = _make_client(context, api_key=api_key)
            try:
                started_at = asyncio.get_running_loop().time()
                onboarding_session_id = ""
                while True:
                    status_payload = await status_client.get_agent_status(agent_id=agent_id)
                    if not isinstance(status_payload, dict):
                        raise RuntimeError("Invalid agent status response")
                    current_status = (_extract_text(status_payload, "status") or "").lower()
                    if current_status == "active":
                        onboarding_session_id = _require_text(
                            status_payload,
                            "onboarding_session_id",
                        )
                        break
                    if asyncio.get_running_loop().time() - started_at > status_timeout:
                        raise TimeoutError("Timed out waiting for owner activation")
                    await asyncio.sleep(max(0.0, status_poll_interval))
            finally:
                await status_client.close()
            _progress("[3/5] Waiting for owner to connect... done", enabled=show_progress)

            await download_task
            _progress("[TSS] Downloading TSS-Node in background... done", enabled=show_progress)

            _progress("[4/5] Initializing TSS-Node...", enabled=show_progress)
            init_result = await asyncio.to_thread(
                init_tss_node,
                tss_binary_path=resolved_tss_path,
                config_path=resolved_config_path,
            )
            _progress("[4/5] Initializing TSS-Node... done", enabled=show_progress)
            main_node_id = _require_text(init_result, "tss_node_id")

            _progress("[5/5] Starting TSS-Node and creating MPC wallet...", enabled=show_progress)
            await asyncio.to_thread(
                start_tss_node,
                tss_binary_path=resolved_tss_path,
                tss_env=tss_env,
                reporter=lambda message: _progress(f"[TSS] {message}", enabled=show_progress),
            )
            active_client = _make_client(context, api_key=api_key)
            try:
                wallet_payload = await create_mpc_wallet(
                    client=active_client,
                    main_node_id=main_node_id,
                    for_owner=True,
                )
                wallet_uuid = _require_text(wallet_payload, "wallet_uuid", "uuid", "id")
                wallet_status_payload = await poll_wallet_status(
                    client=active_client,
                    wallet_uuid=wallet_uuid,
                    poll_interval_seconds=vault_poll_interval,
                    timeout_seconds=vault_timeout,
                )
            finally:
                await active_client.close()
            _progress(
                "[5/5] Starting TSS-Node and creating MPC wallet... done", enabled=show_progress
            )
        finally:
            if not download_task.done():
                download_task.cancel()
                with suppress(asyncio.CancelledError):
                    await download_task

        config_payload.update(
            {
                "status": _extract_text(wallet_status_payload, "status") or "active",
                "activation_secret": None,
                "onboarding_session_id": onboarding_session_id,
                "wallet_uuid": wallet_uuid,
            }
        )
        save_config(config_payload, resolved_config_path)
        return {
            "agent_id": agent_id,
            "status": config_payload["status"],
            "deep_link": deep_link,
            "wallet_uuid": wallet_uuid,
            "onboarding_session_id": onboarding_session_id,
            "config_path": str(resolved_config_path),
            "tss_node_path": str(resolved_tss_path),
        }

    try:
        result = _run_async_operation(context, _operation)
    except KeyboardInterrupt as exc:
        typer.echo(
            "\nInterrupted. Run 'caw init' again to restart onboarding setup.",
            err=True,
        )
        raise typer.Exit(code=130) from exc
    _emit(result, context.output_format)


@app.command("self-test")
def self_test(
    ctx: typer.Context,
    wallet_uuid: str = typer.Option(..., "--wallet", help="Wallet UUID to test."),
    token: str = typer.Option("USDC", "--token", help="Token ID for transfer tests."),
    chain: str = typer.Option("BASE", "--chain", help="Chain ID for transfer tests."),
    blocked_amount: str = typer.Option("500", "--blocked-amount", help="Expected denied amount."),
    allowed_amount: str = typer.Option("2", "--allowed-amount", help="Expected allowed amount."),
    to: str = typer.Option(
        "0x1111111111111111111111111111111111111111",
        "--to",
        help="Destination address for transfer tests.",
    ),
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Config path used for API key fallback when --api-key is not provided.",
    ),
) -> None:
    """Run blocked+allowed transfer checks for onboarding validation."""

    context = _get_context(ctx)
    resolved_api_key = context.api_key
    if not resolved_api_key:
        try:
            config_payload = load_config(config_path)
        except FileNotFoundError:
            config_payload = {}
        except ValueError as exc:
            typer.echo(f"Invalid CLI config: {exc}", err=True)
            raise typer.Exit(code=1) from exc
        resolved_api_key = str(config_payload.get("api_key", "")).strip()
    if not resolved_api_key:
        typer.echo(
            f"API key is required. Set --api-key, {AGENT_WALLET_API_KEY}, or run 'caw provision'/'caw init' first.",
            err=True,
        )
        raise typer.Exit(code=1)

    async def _operation(client: WalletAPIClient) -> Any:
        blocked: dict[str, Any]
        try:
            response = await client.transfer_tokens(
                wallet_uuid,
                chain_id=chain,
                dst_addr=to,
                token_id=token,
                amount=blocked_amount,
            )
            blocked = {
                "passed": False,
                "reason": "blocked transfer unexpectedly succeeded",
                "response": response,
            }
        except PolicyDeniedError as exc:
            blocked = {
                "passed": True,
                "code": exc.denial.code,
                "reason": exc.denial.reason,
                "details": exc.denial.details,
            }
        except APIError as exc:
            blocked = {
                "passed": False,
                "reason": f"blocked transfer failed with non-policy error ({exc.status_code})",
                "error": str(exc),
            }

        allowed: dict[str, Any]
        try:
            response = await client.transfer_tokens(
                wallet_uuid,
                chain_id=chain,
                dst_addr=to,
                token_id=token,
                amount=allowed_amount,
            )
            allowed_status = ""
            if isinstance(response, dict):
                allowed_status = (_extract_text(response, "status") or "").lower()
            if allowed_status in {"denied", "failed", "rejected"}:
                allowed = {
                    "passed": False,
                    "reason": f"allowed transfer returned status={allowed_status}",
                    "response": response,
                }
            else:
                tx_identifier = ""
                if isinstance(response, dict):
                    tx_identifier = (
                        _extract_text(response, "tx_id", "id", "request_id", "tx_hash") or ""
                    )
                allowed = {
                    "passed": True,
                    "status": allowed_status or "submitted",
                    "tx_id": tx_identifier or None,
                    "response": response,
                }
        except PolicyDeniedError as exc:
            allowed = {
                "passed": False,
                "reason": "allowed transfer was denied",
                "code": exc.denial.code,
                "details": exc.denial.details,
            }
        except APIError as exc:
            allowed = {
                "passed": False,
                "reason": f"allowed transfer failed ({exc.status_code})",
                "error": str(exc),
            }

        return {
            "wallet_uuid": wallet_uuid,
            "chain_id": chain,
            "token_id": token,
            "blocked_test": blocked,
            "allowed_test": allowed,
            "passed": bool(blocked.get("passed")) and bool(allowed.get("passed")),
        }

    async def _runner() -> Any:
        client = _make_client(context, api_key=resolved_api_key)
        try:
            return await _operation(client)
        finally:
            await client.close()

    result = _run_async_operation(context, _runner)
    _emit(result, context.output_format)
    if isinstance(result, dict) and not result.get("passed", False):
        raise typer.Exit(code=1)


@app.command("demo")
def demo(ctx: typer.Context) -> None:
    """Run the P11 quickstart demo workflow."""

    context = _get_context(ctx)
    from cobo_agent_wallet.demo import (
        DemoBackendUnavailableError,
        DemoExecutionError,
        format_demo_output,
        run_quickstart_demo,
    )

    try:
        result = asyncio.run(
            run_quickstart_demo(
                api_url=context.api_url,
                timeout=context.timeout,
            )
        )
    except DemoBackendUnavailableError as exc:
        payload = {
            "error": "BACKEND_UNAVAILABLE",
            "message": str(exc),
            "suggestion": exc.suggestion,
        }
        if context.output_format == OutputFormat.JSON:
            typer.echo(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True), err=True)
        else:
            typer.echo(f"{payload['message']}\nSuggestion: {payload['suggestion']}", err=True)
        raise typer.Exit(code=1) from exc
    except DemoExecutionError as exc:
        payload = {"error": "DEMO_FAILED", "message": str(exc)}
        if context.output_format == OutputFormat.JSON:
            typer.echo(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True), err=True)
        else:
            typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    if context.output_format == OutputFormat.TABLE:
        typer.echo(format_demo_output(result))
    else:
        _emit(result, context.output_format)


if __name__ == "__main__":
    app()
