"""Mixin classes for WalletAPIClient (auto-generated)."""

from cobo_agent_wallet._mixins.base import BaseClient
from cobo_agent_wallet._mixins.audit import AuditMixin
from cobo_agent_wallet._mixins.delegation import DelegationMixin
from cobo_agent_wallet._mixins.identity import IdentityMixin
from cobo_agent_wallet._mixins.policy import PolicyMixin
from cobo_agent_wallet._mixins.transaction import TransactionMixin
from cobo_agent_wallet._mixins.wallet import WalletMixin

# Composite mixin that includes all functionality
AllMixins = (
    AuditMixin,
    DelegationMixin,
    IdentityMixin,
    PolicyMixin,
    TransactionMixin,
    WalletMixin,
)

__all__ = [
    "BaseClient",
    "AuditMixin",
    "DelegationMixin",
    "IdentityMixin",
    "PolicyMixin",
    "TransactionMixin",
    "WalletMixin",
    "AllMixins",
]
