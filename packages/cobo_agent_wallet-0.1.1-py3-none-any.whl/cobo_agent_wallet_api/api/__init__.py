# flake8: noqa

# TYPE_CHECKING imports for IDE support while maintaining lazy loading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    # Import all API classes for IDE type checking and autocompletion
    from .audit_api import AuditApi
    from .coin_price_api import CoinPriceApi
    from .delegations_api import DelegationsApi
    from .health_api import HealthApi
    from .identity_api import IdentityApi
    from .meta_api import MetaApi
    from .metadata_api import MetadataApi
    from .policies_api import PoliciesApi
    from .transactions_api import TransactionsApi
    from .wallets_api import WalletsApi
    from .webhooks_api import WebhooksApi

    # Import all Async API classes for IDE type checking and autocompletion
    from .audit_api_async import AsyncAuditApi
    from .coin_price_api_async import AsyncCoinPriceApi
    from .delegations_api_async import AsyncDelegationsApi
    from .health_api_async import AsyncHealthApi
    from .identity_api_async import AsyncIdentityApi
    from .meta_api_async import AsyncMetaApi
    from .metadata_api_async import AsyncMetadataApi
    from .policies_api_async import AsyncPoliciesApi
    from .transactions_api_async import AsyncTransactionsApi
    from .wallets_api_async import AsyncWalletsApi
    from .webhooks_api_async import AsyncWebhooksApi


# API classes mapping for lazy import
_API_CLASSES = {
    'AuditApi': 'audit_api',
    'CoinPriceApi': 'coin_price_api',
    'DelegationsApi': 'delegations_api',
    'HealthApi': 'health_api',
    'IdentityApi': 'identity_api',
    'MetaApi': 'meta_api',
    'MetadataApi': 'metadata_api',
    'PoliciesApi': 'policies_api',
    'TransactionsApi': 'transactions_api',
    'WalletsApi': 'wallets_api',
    'WebhooksApi': 'webhooks_api',
}

# Async API classes mapping for lazy import
_ASYNC_API_CLASSES = {
    'AsyncAuditApi': 'audit_api_async',
    'AsyncCoinPriceApi': 'coin_price_api_async',
    'AsyncDelegationsApi': 'delegations_api_async',
    'AsyncHealthApi': 'health_api_async',
    'AsyncIdentityApi': 'identity_api_async',
    'AsyncMetaApi': 'meta_api_async',
    'AsyncMetadataApi': 'metadata_api_async',
    'AsyncPoliciesApi': 'policies_api_async',
    'AsyncTransactionsApi': 'transactions_api_async',
    'AsyncWalletsApi': 'wallets_api_async',
    'AsyncWebhooksApi': 'webhooks_api_async',
}

def __getattr__(name):
    """Lazy import for API classes and Async API classes."""
    if name in _API_CLASSES:
        module_name = f'cobo_agent_wallet_api.api.{_API_CLASSES[name]}'
        module = __import__(module_name, fromlist=[name])
        attr = getattr(module, name)
        globals()[name] = attr
        return attr
    elif name in _ASYNC_API_CLASSES:
        module_name = f'cobo_agent_wallet_api.api.{_ASYNC_API_CLASSES[name]}'
        module = __import__(module_name, fromlist=[name])
        attr = getattr(module, name)
        globals()[name] = attr
        return attr
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

def __dir__():
    """Support for autocompletion."""
    return list(globals().keys()) + list(_API_CLASSES.keys()) + list(_ASYNC_API_CLASSES.keys())
