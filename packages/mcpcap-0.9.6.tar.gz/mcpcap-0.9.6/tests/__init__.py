"""Tests for mcpcap."""
