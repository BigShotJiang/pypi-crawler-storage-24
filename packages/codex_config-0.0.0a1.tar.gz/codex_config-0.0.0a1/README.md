# codex-config

Tool for statically configuring Codex CLI
