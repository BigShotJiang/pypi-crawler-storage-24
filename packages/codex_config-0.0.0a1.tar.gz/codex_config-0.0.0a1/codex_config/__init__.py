"""Tool for statically configuring Codex CLI"""

__version__ = "0.0.0a1"
