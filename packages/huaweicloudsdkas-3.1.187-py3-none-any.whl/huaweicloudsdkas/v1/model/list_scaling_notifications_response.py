# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListScalingNotificationsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'topics': 'list[Topics]'
    }

    attribute_map = {
        'topics': 'topics'
    }

    def __init__(self, topics=None):
        r"""ListScalingNotificationsResponse

        The model defined in huaweicloud sdk

        :param topics: 伸缩组通知列表。
        :type topics: list[:class:`huaweicloudsdkas.v1.Topics`]
        """
        
        super().__init__()

        self._topics = None
        self.discriminator = None

        if topics is not None:
            self.topics = topics

    @property
    def topics(self):
        r"""Gets the topics of this ListScalingNotificationsResponse.

        伸缩组通知列表。

        :return: The topics of this ListScalingNotificationsResponse.
        :rtype: list[:class:`huaweicloudsdkas.v1.Topics`]
        """
        return self._topics

    @topics.setter
    def topics(self, topics):
        r"""Sets the topics of this ListScalingNotificationsResponse.

        伸缩组通知列表。

        :param topics: The topics of this ListScalingNotificationsResponse.
        :type topics: list[:class:`huaweicloudsdkas.v1.Topics`]
        """
        self._topics = topics

    def to_dict(self):
        import warnings
        warnings.warn("ListScalingNotificationsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListScalingNotificationsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
