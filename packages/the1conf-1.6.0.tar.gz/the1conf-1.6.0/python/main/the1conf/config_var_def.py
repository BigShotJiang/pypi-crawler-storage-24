from __future__ import annotations

from collections.abc import Callable, Sequence
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Optional,
    TypeVar,
    Union,
    cast,
    dataclass_transform,
    get_args,
    get_origin,
    get_type_hints,
)
import inspect
from .utils import Undefined, _undef, PathType, is_sequence
from .flags import Flags
import json

if TYPE_CHECKING:
    from .app_config import AppConfig

_T = TypeVar("_T")


@dataclass_transform()
class ConfigVarDef(Generic[_T]):
    """
    Definition of an application configuration variable.

    Attribute of this class are called configuration directives that are used to specify the configuration of the application with the AppConfig class.

    Configuration are used indirectly by defining attributes of an AppConfig subclass with the configvar() function that creates ConfigVarDef objects:
        class MyAppConfig(AppConfig):
            my_var: int = configvar(default=1)

    The method resolve_vars() of the AppConfig class uses these configuration variable definitions to look for the values of the variables as explained in its documentation.
    Each configuration variable definition contains several directives to define how to look for the values of the variables in a dictionnarary that can be the CLI parameters,
    or a configuration file, or an environment variables or a computation defined by a python Callable.

    Two directive are not specified in the constructor of ConfigVarDef because they are inferred from the attribute name and type hint:
        - name : the name of the variable, inferred from the attribute name.
        - type_info : the type to which to cast the variable value, inferred from the attribute type hint. Must be a python builtin type or a class or a list of
            builtin types.
            Here how to get the list of python builtin types:
                print([t.__name__ for t in __builtins__.__dict__.values() if isinstance(t, type)])
            Lists are handle with a specific processing detail below in the paragraph 'Lists'.
            Complex casting can be handle with a transfom Eval Form or with a class that implements the complex type.
            Optional value are supported like Optional[int] or Union[str, None] to indicate that the variable can be None.
            When the type hint is missing the variable is considered to be of type str.

    The directives that can be specified in configvar() are:

    - help [optional]: a help string that describes the variable.
    - default [optional]: the default value, can be a value or an Eval Form (see below explanation on Eval forms) whose
        returned value will be the value of the variable if no other value has been found.
        See paragraph about None below for more information.
    - env_name [optional ]: the name of the environment variable that can contain the value. By default search for name
    - file_key [optional ]: the key to look for in the configuration file, key can be in the form a1.a2.a3 (attributes separated by dots) to indicate
        nested namespaces (see AppConfig documentation). By default search for name.
    - value_key [optional ]: the option names that can be used by click_options.
    - transform : an Eval Form (see below explanation on Eval forms) that transform the value found for the variable and produce another value that will be the value
        of the variable before possible casting (like explain in type_info).
    - scopes [optional]: a list of names indicating in which scope the variable is valid. If one of the scope names passed at variable resolution to
        AppConfig.resolve_vars() matches one of the scope names of the variable or if the variable has no scope directive then the variable is
        considered for resolution.
    - split_to_list [optional ]: Indicates that the value found must be split in order to produce a list of string. The value

        of the directive is the list separator or True if the separator is a comma. Value in the string list will be casted to the type specified in type_info.
        See the paragraph below about Lists that explain how list handled.
    - can_be_relative_to [optional]: a directory path or the name of another key that resolves in a directory path.
        If type_info is a Path and the retrieved value is not an empty string nor None nor an absolute path then
        transform the value to an absolute path with the given directory as parent directory.
        See details below on how Path are processed.
    - make_dirs [optional ]: a PathType that indicates the type of Path for which directories are to be created if they do not exist yet.
            if PathType is:
                - Dir : create the hierarchy of directory necessary to contains this directory as well as the directory itself
                - File: create the parent hierarchy of directory necessary to contains this file
        See details below on how Path are processed.
    - auto_prolog [optional]: mark the variable for automatic prolog processing - which means that the variable will be resolved at an early stage, before the configuration file
        is resolved and before all other variables. If it has also the allow_override flag True then it can be processed again with all other variables in the regular resolution.


    - Flag directives:
        These directives can also be defined globally in the AppConfig object or when calling resolve_vars().Flags defined in a ConfigVarDef override
        the other values if they are defined.
        - no_dir_processing [optional ]: don't run specific Path processing for this variable.
        - no_env_search [optional ]: boolean, False by default. If true the value of the variable is not searched in the Environment.
        - no_value_search[optional ]: boolean, False by default. If true the value of the variable is not searched in the values dict.
        - no_conffile_search [optional ]: boolean, False by default. If true the value of the variable is not searched in the configuration file.
        - allow_override [optional ]: boolean, False by default. If true the variable value can be overridden by another context.
        - mandatory [optional ]: boolean, True by default. If true an exception is thrown if the variable value is not found. Otherwise the variable is not set which means that accessing it
          would raise an Exception.
        - no_search [optional] : boolean, False by default. It true the value of the variable is not searched in the Environment, the values or the configuration
            file. It's equivaleut to set the directives no_env_search, no_value_search, no_conffile_search to True. In this case the value of the variable should be defined by
            the default directive.

    For backward compatibilty the special value __NO_SEARCH__ for env_name, config_key, file_key and value_key are still supported but it's recommended to use
    the no_env_search, no_value_search, no_conffile_search or no_search directives instead.

    By default throw an exception if no value are found except if mandatory is False

    Eval Forms:
    -----------

        an eval form is a callable that is evaluated to compute a value for a variable. Eval forms can be used in the default directive or the
        transform directive.

        The callable receives three parameters: the variable name, this configuration object and the current value found for the variable if one has been found
        in the case of a transform directive.

        The expression can use value already defined in tf dehis application configuration object by using the first parameter of the callable which is the AppConfig object itself,
        knowing that variables are evaluated in the order they are defined.

        In the case of a default directive the third parameter of the callable will be None.
        In the case of a transform directive the third parameter of the callable may be None if no value have been found and
        the 'mandatory' global flag is set to False, otherwise it will be the value found for the variable before transformation.

        The returned value from the evaluation of the callable will be used to set the variable value before casting to type_info.
        Note that the eventual type casting will be done after the Eval call.
        It's up to the caller to deal with the returned value.

        Note that the libraries used in Eval Forms must be imported in the module that defines the form.

        !!Warning!!: default and transform directives should be set or return a value that must be 'castable' to the type defined by type_info.
        For example if a variable is declared as a class that accept a string in its constructor then the default directive should be a string or an Eval
        Form that returns a string not the class instance.

    Path and Path list type_info variables:
    --------------------------------------

        If a variable has a type_info that is a Path or a list of Path there a dedicated processing that applies on the
        value found for them.
        This processing takes place at the end of the processing of normal variable and occurs when:
            - the type_info is a Path or a list of Path
            - a value for the variable was found
            - the directive no_dir_processing is False

        The specific processing is the following on the Path or on each of the Path in the list of Path:
            - can_be_relative_to: if this directive has a value that can be a path-like directory or the name of another key already defined
            that resolves in a path-like directory and the value found is not an absolute Path:
                - then make a Path with the can_be_relative_to directory as parent and the value found as its child.
            - make_dirs: if this directive is True , then create the necessary directories of the path if they don't exist yet.
            - Call the 'expanduser()' and 'resolve()' method on the resulting Path.

    List:
    -----

        All values found are strings that should be casted to the type specified in type_info inferred from the type hint of the variable.
        Only list of single type are supported like list[int], list[str], list[MyClass], etc.
        The value is considered as a list when split_to_list is not False and a value was found for the variable.
        In this case the temporaray string value found for the variable is split with the string 'split()' method to generate
        a list of string.
        Then all items of the list of strings are casted to the specified type_info.

    scopes:
    --------
        Every configuration variable can specify a list of scope(s) in which it is valid.
        When resolving variables it is also possible to specify for which scope(s) the resolution must be done.

        When one or several scopes are specify for the resolution then only the variable valid for these scopes will be considered for resolution
        as well as the VarDef without Scope directive. Variable defined without Scope directive are common to all scope, the one with a Scope directive
        are specific to their scopes.

        This allows to define variables that are specific to some scope and to resolve only these variables when needed.
        When the flage allow_override is False and several resolutions are done, then variables are evaluated only once even if they are valid in several
        of the requested scope(s), only the first valid scope is used.

    None value:
    ----------
        All the VarDef valid for the involved scopes will be resolved and the one for which no value have been found will be set to None if the
        flag 'mandatory' is False.

        If the flag 'mandatory' is true and one varDef for the scope has no value then an exception is raised.

        Whatever is the value of the flag 'mandatory' it is possible to set a value to None either with the 'default' directive or with
        an Eval Form or a None value in one of the search location.

    AutoProlog variables:
    --------------------
        Variables defined with the auto_prolog directive set to True are considered as AutoProlog variables. These variables are resolved at an early stage
        before all other variables and before the configuration file is processed.
        This allows to define variables that are necessary to locate the configuration file when its path depends on other variables. In this case these variables
        must be defined as AutoProlog variables.
        The default variables defined in the AutoProlog class are all AutoProlog variables and therefore are made available to be used in variable substitution for all other
        variables and for locating the configuration file.

    Note on implementation:
    -----------------------
        ConfigVarDef is a descriptor class that defines the __get__ and __set__ methods.
        This allows to define configuration variables as class attributes on AppConfig subclasses.
        The __set_name__ method is used to set the name and type_info directives based on the attribute name and type hint.
    """

    _env_keys: Optional[Sequence[str]] = None
    _file_keys: Optional[Sequence[str]] = None
    _mandatory: Optional[bool] = True
    _no_dir_processing: Optional[bool] = None
    _split_to_list: Optional[bool | str] = None
    _cli_keys: Optional[Sequence[str]] = None
    auto_prolog: Optional[bool] = None
    can_be_relative_to: Optional[Path | str] = None
    default: Any | Callable[[str, Any, Any], Any] | Undefined = _undef
    flags: Flags
    fq_name: Optional[str] = None
    help: str = ""
    make_dirs: Optional[PathType] = None
    name_space: Optional[tuple[str, ...]] = None
    name: Optional[str] = None
    scopes: Optional[Sequence[str]] = None
    transform: Optional[Union[Callable[[str, Any, Any], Any], str]] = None
    type_info: Any = _undef

    def __init__(
        self,
        *,
        allow_override: Optional[bool] = None,
        auto_prolog: Optional[bool] = None,
        can_be_relative_to: Optional[Path | str] = None,
        default: Any | Callable[[str, Any, Any], Any] | Undefined = _undef,
        env_keys: Optional[str | Sequence[str]] = None,
        file_keys: Optional[str | Sequence[str]] = None,
        help: str = "",
        make_dirs: Optional[PathType] = None,
        mandatory: Optional[bool] = None,
        no_conffile_search: Optional[bool] = None,
        no_dir_processing: Optional[bool] = None,
        no_env_search: Optional[bool] = None,
        no_search: Optional[bool] = None,
        no_value_search: Optional[bool] = None,
        scopes: Optional[Sequence[str]] = None,
        split_to_list: Optional[bool | str] = None,
        transform: Optional[Union[Callable[[str, Any, Any], Any], str]] = None,
        type_info: Any = _undef,
        cli_keys: Optional[str | Sequence[str]] = None,
    ) -> None:
        """Initialize the configuration variable definition.
        Should not be used directly but be used through the function configvar() to define a configuration variable as a class attribute
        on an AppConfig subclass like this:
            class MyCfg(AppConfig):
                my_var: int = configvar(default=1)

        """
        self.__doc__ = help
        self.auto_prolog = auto_prolog
        self.can_be_relative_to = can_be_relative_to
        self.scopes = scopes
        self.default = default
        self._env_keys = (
            None
            if env_keys is None
            else (
                env_keys
                if is_sequence(env_keys)
                else [env_keys] if isinstance(env_keys, str) else None
            )
        )
        self._file_keys = (
            None
            if file_keys is None
            else (
                file_keys
                if is_sequence(file_keys)
                else [file_keys] if isinstance(file_keys, str) else None
            )
        )
        self.help = help
        self.make_dirs = make_dirs
        self._mandatory = mandatory
        self._no_dir_processing = no_dir_processing
        self._no_search = no_search
        self._split_to_list = split_to_list
        self.transform = transform
        self.type_info = type_info
        self._cli_keys = (
            None
            if cli_keys is None
            else (
                cli_keys
                if is_sequence(cli_keys)
                else [cli_keys] if isinstance(cli_keys, str) else None
            )
        )
        self.flags = Flags(
            no_env_search=no_env_search,
            no_value_search=no_value_search,
            no_conffile_search=no_conffile_search,
            allow_override=allow_override,
            no_search=no_search,
        )

    def __set_name__(self, owner: type, name: str) -> None:
        """This method is a special python method called when a descriptor is assigned to a class attribute.
        ConfigVarDef is a descriptor class because it defines the __get__ and __set__ methods.

        The goal of this method is to:
            - set the name directive of this ConfigVarDef based on the attribute _name.
            - infer the type of the attribute and set the type_info directive with it.

        At this stage we can't access the namespace of the variable because we just have the name of the attribute
        and its owning class that can be a NameSpace or an AppConfig subclass but nothing more.

        Args:
            owner (type): the owning class of the attribute that is being assigned the descriptor
            name (str): the attribute name
        """

        # set the name of the attribute
        self.name = name

        # try to find a type:
        #     if we have a type hints and a type_info directive we take the type_info.
        #     This allow to define a type for the type checker that allow override with another type if the user wants to.
        #     (it is usefull for exec_stage)
        #     but still have a correct run time type , this is correct as long as the user use duck typing types
        #     that are compatible.
        try:
            hints = get_type_hints(owner, include_extras=True)
        except Exception:
            hints = getattr(owner, "__annotations__", {})

        # test if there is a type hint for this attribute
        annotated_type: dict[str, Any] | Any | dict[Any, Any] = None
        if name in hints:
            annotated_type = hints[name]
            if isinstance(annotated_type, str):
                # Why can it be a string? In Python, type hints are strings if:
                #   from __future__ import annotations is used (postponed evaluation of annotations).
                #   The user explicitly used quotes for a forward reference (e.g., var: "MyClass" where MyClass is defined later).
                for frame_info in inspect.stack():
                    # try to resolve the type with an eval to which we provide the globals and locals for its resolution.
                    # But it can happen that the type is defined in a local scope, so we need to go through all frames
                    # using the stack.
                    try:
                        resolved_type = eval(
                            annotated_type,
                            frame_info.frame.f_globals,
                            frame_info.frame.f_locals,
                        )
                        if resolved_type is not None:
                            annotated_type = resolved_type
                            break
                    except Exception:
                        continue
                else:
                    raise TypeError(
                        f"Could not resolve type hint '{annotated_type}' for configuration variable '{name}'. "
                        "Please check that the type is imported and available."
                    )

        type_info_directive = self.type_info

        if annotated_type is not None and type_info_directive != _undef:
            # both type hint and type_info directive are defined, use type_info directive
            self.type_info = type_info_directive
        elif annotated_type is not None:
            # only type hint is defined, use it
            self.type_info = annotated_type
        elif type_info_directive != _undef:
            # only type_info directive is defined, use it
            self.type_info = type_info_directive
        else:
            # no type hint nor type_info directive, default to str
            self.type_info = str

        # We still need to handle split_to_list if not set and the type selected is a list
        if self._split_to_list is None:
            try:
                origin = get_origin(self.type_info)
                args = get_args(self.type_info)

                # Check for basic list
                if origin is list or self.type_info is list:
                    self._split_to_list = True
                # Check for Optional[list] / Union[list, ...]
                elif origin is Union:
                    for arg in args:
                        arg_origin = get_origin(arg)
                        if arg_origin is list or arg is list:
                            self._split_to_list = True
                            break
            except Exception:
                pass

    def __get__(
        self, instance: Optional[AppConfig], owner: Optional[type] = None
    ) -> ConfigVarDef[_T] | _T | None:
        """
        Descriptor method that gets the value of the configuration variable from the AppConfig instance.

        The value is retrieved from the instance's __dict__ using the variable's fq_name because we want to
        handle the case where we have dotted names for nested attributes.

        If no value is found in the instance's __dict__ for this variable name then raise AttributeError because
        it means that the variable was not resolved and should not be accessed.
        """
        if instance is None:
            return self
        fq_name = self.fq_name
        if fq_name is None:
            raise AttributeError(
                "Configuration variable's fq_name is not set. Make sure to call resolve_vars() before accessing it."
            )
        if instance.has_value(fq_name):
            return instance[fq_name]
        else:
            raise AttributeError(
                f"Configuration variable '{fq_name}' is not set. Make sure to call resolve_vars() before accessing it."
            )

    def __set__(self, instance: AppConfig, value: Any) -> None:
        """
        Descriptor method that sets the value of the configuration variable in the AppConfig instance.
        The value is set in the instance's __dict__ using the variable's fqn_name because we want to
        handle the case where we have dotted names for nested attributes.
        """
        instance[self.fq_name] = value

    @property
    def env_keys(self) -> Optional[Sequence[str]]:
        if self.flags.no_search or self.flags.no_env_search:
            return None
        elif self._env_keys:
            return self._env_keys
        else:
            if self.fq_name is None:
                raise ValueError("Internal error fq_name is not set.")
            return [self.fq_name]

    @property
    def file_keys(self) -> Optional[Sequence[str]]:
        if self.flags.no_search or self.flags.no_conffile_search:
            return None
        elif self._file_keys:
            if self.name_space:
                # if the variable is in a namespace then we need to add the namespace to the file_keys for it to be found in the configuration file.
                return [
                    f"{'.'.join(self.name_space)}.{file_key}"
                    for file_key in self._file_keys
                ]
            return self._file_keys
        else:
            if self.fq_name is None:
                raise ValueError("Internal error fq_name is not set.")
            return [self.fq_name]

    @property
    def mandatory(self) -> bool:
        return True if self._mandatory is None else self._mandatory

    @property
    def no_dir_processing(self) -> bool:
        return False if self._no_dir_processing is None else self._no_dir_processing

    @property
    def split_to_list(self) -> bool | str:
        return False if self._split_to_list is None else self._split_to_list

    @property
    def cli_keys(self) -> Optional[Sequence[str]]:
        if self.flags.no_search or self.flags.no_value_search:
            return None
        elif self._cli_keys:
            if self.name_space:
                # if the variable is in a namespace then we need to add the namespace to the cli_keys for it to be found in the values dict.
                return [
                    f"{'.'.join(self.name_space)}.{cli_key}" for cli_key in self._cli_keys
                ]
            return self._cli_keys
        else:
            if self.fq_name is None:
                raise ValueError("Internal error fq_name is not set.")
            return [self.fq_name]

    def __json__(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "fq_name": self.fq_name,
            "env_keys": self.env_keys,
            "file_keys": self.file_keys,
            "mandatory": self.mandatory,
            "no_dir_processing": self.no_dir_processing,
            "split_to_list": self.split_to_list,
            "cli_keys": self.cli_keys,
            "auto_prolog": self.auto_prolog,
            "can_be_relative_to": (
                str(self.can_be_relative_to) if self.can_be_relative_to else ""
            ),
            "default": str(self.default) if self.default != _undef else "",
            "flags": self.flags.__json__(),
            "help": self.help,
            "make_dirs": str(self.make_dirs),
            "scopes": self.scopes,
            "type_info": str(self.type_info),
        }

    def __repr__(self) -> str:
        return json.dumps(self.__json__(), indent=2)

    def __str__(self) -> str:
        return (
            self.fq_name if self.fq_name else self.name if self.name else self.__repr__()
        )
