from __future__ import annotations

import copy

import json
import logging
import os

from collections import OrderedDict
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any, Callable, Optional, Union, cast

from .auto_prolog import AutoProlog
import toml
import yaml

from .attr_dict import AttrDict
from .utils import is_sequence, Undefined
from .config_var import ConfigVar
from .config_var_def import Flags
from .solver import Solver
from .configvar_expression import PathOperand
from .utils import _undef
from .app_config_meta import AppConfigMeta
from itertools import chain


class AppConfig(AttrDict, AutoProlog, metaclass=AppConfigMeta):
    """ "
    A class to manage application configuration. It can be passed from callable to callable.
    It can search for variable values in command line arguments, environment variables, a yaml or json configuration file
    or a default value or a computed value.

    Configuration variable are defined with a list of ConfigVar object which defines how to look for the variable values and/or compute them.

    The variable values are searched in these locations in the following order:
    - a dict of values usually passed from the command line arguments
    - environment variables
    - a configuration file in yaml or json format
    - a default value or a computed value
    The first match found is used as the value for the variable.

    When found the variable can be casted to a specific type and/or transformed with a callable.

    The default value can also be computed with a callable that can use already defined variables in this AppConfig object.
    One can combine a default value and a transformation callable to compute complex default values that can combine several already defined variables,
    knowing that variables are resolved in the order they are declared in the AppConfig subclass.

    See method 'resolve_vars()' and class 'ConfigVar' for more information.

    Variable can also be set directly like in an object attribute or in a Dict key:

    ctx = AppConfig()
    ctx["var"] = 2
    print(ct.var) # print 2

    Accessing the variables can also be done like an object attribute or a Dict key:
    ctx = AppConfig()
    ctx.var = 2
    print(ctx["var"]) # print 2

    This can be useful to mix known variable name and variable dynamically defined in a file or passed from the command line.
    def foo(ctx: AppConfig,attname:Any) -> Any:
        return ctx[attname]

    Variable can contain variable recursively, in this case they can be access with a dotted notation or with a dict like way:
    ctx = AppConfig()
    ctx["var1.var2"] = 2
    ctx["var1.var3"] = 3
    print(f"var1 = {ctx.var1}") # print a dict {"var2":2,"var3":3}

    print(ctx.var1.var2) # print 2

    Declarative Configuration:
    --------------------------
    Configuration is best defined declaratively by subclassing AppConfig:

        class MyConfig(AppConfig):
            host: str = configvar(default="localhost")
            port: int = configvar(default=8080)

    Nested Namespaces:
    ------------------
    Variables can be grouped into namespaces using nested classes inheriting from NameSpace.
    This creates a structured configuration:

        class MyConfig(AppConfig):
            # Root level variable
            debug: bool = configvar(default=False)

            # Nested namespace 'db'
            class db(NameSpace):
                host: str = configvar(default="db.local")
                port: int = configvar(default=5432)

            # Nested namespace 'api'
            class api(NameSpace):
                key: str = configvar(env_name="API_KEY")

    inst = MyConfig()
    inst.resolve_vars()
    print(inst.db.host)  # Access nested variables

    Decentralized Configuration (Mixins):
    -------------------------------------
    Configuration can be split across multiple classes (Mixins) and combined using inheritance.
    This allows different modules to define their own configuration requirements.

        class DatabaseConfig(AppConfig):
            class db(NameSpace):
                host: str = configvar(default="localhost")

        class ApiConfig(AppConfig):
            class api(NameSpace):
                timeout: int = configvar(default=30)

        # Combine into the final application config
        class App(DatabaseConfig, ApiConfig):
            pass

    If multiple mixins define the same namespace (e.g. `class db(NameSpace)`), their variables are merged.
    """

    _logger = logging.getLogger(__name__)
    _global_flags: Flags
    _config_var_defs: OrderedDict[str, ConfigVar]
    """ The list of ConfigVar defined in this AppConfig class and its parent classes as an ordered dictionary. 
        This attribute is created at class creation time by the meta class.
    """
    _autoprolog_var_names: list[str]
    """ The list of the names of ConfigVar defined in AutoProlog.
        This attribute is created at class creation time by the meta class.
    """

    def __init__(
        self,
        *,
        no_env_search: Optional[bool] = None,
        no_key_search: Optional[bool] = None,
        no_conffile_search: Optional[bool] = None,
        no_search: Optional[bool] = None,
        allow_override: Optional[bool] = None,
    ):
        """Init the config.

        Arguments are called 'global flags', they specify the behavior of the variable resolution globaly. They can be overiden
        when the resolve method is call. (this method can be call several time and thus on each call some flags can be changed) or
        per variable when defining the ConfigVar object.

        Global Flags:
            no_env_search (bool, optional): don't search values in the environment. Defaults to False.
            no_key_search (bool, optional): don't search values in the value dictionary. Defaults to False.
            no_conffile_search (bool, optional): don't search values in the configuration file. Defaults to False.
            no_search (bool, optional): don't search values in any location. Defaults to False.
            allow_override (bool, optional): allow overriding variable in the configuration when calling resolve_vars.
                it happens either when resolve_vars() is call several times or the variable was set before its call.
        """
        self._global_flags = Flags(
            no_env_search=no_env_search,
            no_value_search=no_key_search,
            no_conffile_search=no_conffile_search,
            no_search=no_search,
            allow_override=allow_override,
        )

        self._logger.debug("init AppConfig")

    def clone(self) -> AppConfig:
        """cloning the AppConfig object"""
        clone = AppConfig()
        clone.update(self.to_dict(), override=True)
        return clone

    def _set_value(self, name: str, value: Any) -> None:
        """Set a value.

        Use an AttrDict implementation to handle dotted keys and not trigger recursion loops
        if called from a descriptor.
        """
        self[name] = value

    def _get_eval_runner(
        self,
    ) -> Callable[[Callable[[str, Any, Any], Any], str, Any], Any]:
        """
        Call a Callable found in a Eval Form.
        """
        this = self

        def runner(
            callable: Callable[[str, Any, Any], Any], var_name: str, var_val: Any
        ) -> Any:
            return callable(var_name, this, var_val)

        return runner

    def resolve_vars(
        self,
        *,
        scopes: Optional[str | Iterable[str]] = None,
        values: Mapping[str, Any] = {},
        no_env_search: Optional[bool] = None,
        no_value_search: Optional[bool] = None,
        no_conffile_search: Optional[bool] = None,
        no_search: Optional[bool] = None,
        conffile_path: Optional[PathOperand | Iterable[PathOperand]] = None,
        allow_override: Optional[bool] = None,
    ) -> None:
        """
        Resolve the configuration variables defined in this AppConfig object.
        The variable values are searched in these locations in the following order:
        - a dict of values usually passed from the command line arguments
        - environment variables
        - a configuration file in yaml or json format
        - a default value or a computed value
        The first match found is used as the value for the variable.
        When found the variable can be casted to a specific type and/or transformed with a callable.
        The default value can also be computed with a callable that can use already defined variables in this AppConfig object.
        One can combine a default value and a transformation callable to compute complex default values that can combine several already defined variables,
        knowing that variables are resolved in the order they are declared in the AppConfig subclass.
        """

        self._logger.info("Starting variable resolution ...  ")

        # Compute flags that can be override locally.
        resolve_flags = Flags(
            no_env_search=no_env_search,
            no_value_search=no_value_search,
            no_conffile_search=no_conffile_search,
            no_search=no_search,
            allow_override=allow_override,
        )
        local_flags = self._global_flags.merge(inplace=False, other=resolve_flags)
        assert local_flags is not None

        # building the Solver who is in charge of resolving configuration variables
        solver = Solver(
            eval_runner=self._get_eval_runner(),
            flags=local_flags,
            values_map=values,
            var_solved=self,
        )

        # Special case for auto_prolog variable: we need to try to solve them
        # before any other variable and before resolving the configuration file path because
        # it can depends on one of them, the one that can be ovveriden are resolved at each run
        remaining_auto_prolog_vars: list[str] = []
        for var_fq_name in self._autoprolog_var_names:

            vardef = self._config_var_defs.get(var_fq_name)
            assert (
                vardef is not None
            ), f"AutoProlog variable '{var_fq_name}' must have a ConfigVar definition."
            allow_override = (
                local_flags.allow_override
                if vardef.flags.allow_override is None
                else vardef.flags.allow_override
            )
            if vardef is None:
                continue
            if self.has_value(var_fq_name) and not allow_override:
                continue
            # call solver to try to find a value for the configuration variable
            value_found = solver.resolve_confvar(var_to_solve=vardef, scopes=scopes)
            if value_found != _undef:
                self._set_value(var_fq_name, value_found)
            if allow_override or value_found == _undef:
                # we will try to resolve this variable again later with the new value of other variables that can be used in its resolution.
                remaining_auto_prolog_vars.append(var_fq_name)

        # Read configuration file if requiered
        conf_file_vars = None
        if not local_flags.no_conffile_search and conffile_path is not None:
            # Resolve conffile_path if it's dynamic
            cur_conffile_path: Path | Undefined = solver.resolve_conffile_path(
                conffile_path
            )
            if cur_conffile_path == _undef or cur_conffile_path is None:
                self._logger.warning(
                    f"Configuration file not found in any of these locations: {conffile_path}"
                )

            if (
                cur_conffile_path is not None
                and cur_conffile_path != _undef
                and cur_conffile_path.is_file()
            ):
                with cur_conffile_path.open("r") as f:
                    if cur_conffile_path.suffix.lower() == ".json":
                        self._logger.debug(f"Parsing json file {cur_conffile_path}")
                        conf_file_vars = json.load(f)
                    elif cur_conffile_path.suffix.lower() == ".toml":
                        self._logger.debug(f"Parsing toml file {cur_conffile_path}")
                        conf_file_vars = toml.load(f)
                    else:
                        self._logger.debug(
                            f"Parsing file {cur_conffile_path} with suffix {cur_conffile_path.suffix.lower()}"
                        )
                        conf_file_vars = yaml.safe_load(f)
                    # updating the solver with the values found in the configuration file
                    solver.set_conffile_values_map(conf_file_vars)
            else:
                self._logger.info(f"configuration file {cur_conffile_path} not found.")

        # Read the var definitions one by one in their definition order -
        # We start by the auto_prolog variables that can be overriden in order to garantee that they can be used by other vars.
        # Then we will loop over the other variables in the order they have been defined.
        for var_fq_name in chain(
            remaining_auto_prolog_vars,
            [
                vfqn
                for vfqn in self._config_var_defs.keys()
                if vfqn not in self._autoprolog_var_names
            ],
        ):

            var_def = self._config_var_defs[var_fq_name]

            # Check if variable is manually set on the instance or resolved in a previous pass
            has_value = self.has_value(var_fq_name)

            # compute the current flags for this variable by merging local flags with variable flags
            cur_flags = local_flags.merge(inplace=False, other=var_def.flags)
            assert cur_flags is not None

            # if the variable is already defined and override is not allowed then
            # we skip it (First valid scope wins).
            if not cur_flags.allow_override and has_value:
                continue

            # call solver to try to find a value for the configuration variable
            value_found = solver.resolve_confvar(var_to_solve=var_def, scopes=scopes)
            if value_found != _undef:
                self._logger.info(
                    f"Variable '{var_fq_name}' resolved to: {str(value_found)}"
                )
                # add the found value to the AppConfig object through the AttrDict implementation.
                self._set_value(var_fq_name, value_found)
            else:
                self._logger.debug(f"Variable '{var_fq_name}' could not be resolved.")

    def _serialize_var_defs(
        self, vardef_to_serialize: Iterable[ConfigVar], for_file: bool = False
    ) -> dict[str, Any]:
        """
        Serialize the given variable definitions to a dictionary for variables that has been resolved.

        for_file is used to specify if we serialize for storing in a file or for display

        if 'for_file' is True  we serialize only variables that have no_conffile_search set to False and used
        the first key in file_key as the key in the dict. In this case we don't serialize variables whose
        type_info is None and their real type is not 'str' because we would not be able to read them back
        from the file and get the same value.

        if for_file is False the key is the variable name.

        We use str() to serialize configuration variables .
        To detect list we need to look at the split_to_list attribute of the ConfigVar and call str() on
        each element of the list, then join them with the separator used to create the list.
        """
        # we are going to take advantage of the AttrDict to accept dotted keys in order to create nested dicts.
        dumper = AttrDict()
        for var in vardef_to_serialize:
            if not self.has_value(var.fq_name):
                # we skip variables that don't have a value, surely their scope hasn't been resolved yet.
                continue
            stringifiable = True
            if var.type_info is None and not isinstance(self[var.fq_name], str):
                # type_info None means Any, we don't know how to put this variable in a file so that we can read it afterward and get back the same value.
                stringifiable = False
            if for_file and stringifiable and var.file_keys is not None:
                # ConfigVar class guarantee that file_key is a list of str with at least one element if it's not None, so we can
                # safely take the first element here, also file_key is not None only if the variable is searchable in file.
                key = var.file_keys[0]
            elif not for_file:
                key = var.fq_name
            else:
                continue

            sep = (
                var.split_to_list
                if isinstance(var.split_to_list, str)
                else (
                    ","
                    if isinstance(var.split_to_list, bool) and var.split_to_list
                    else None
                )
            )
            if sep is not None and is_sequence(self[var.fq_name]):
                val_list = [str(v) for v in self[var.fq_name]]
                val = sep.join(val_list)
            else:
                val = str(self[var.fq_name])

            dumper[key] = val

        return cast(dict[str, Any], dumper.to_dict())

    def store_conf_infile(
        self,
        file: Union[Path, str],
        *,
        namespaces: Sequence[str] = [],
        scopes: Sequence[str] = [],
        type: str = "yaml",
    ) -> None:
        """
        Store the current configuration in a file by merging the variables in the file with the one in this Appconfig object.
        The method writes the variables in a file.
        The variables to write must be in one of the specified namespaces and have one of the specified scopes.

        Args:
            file (Path | str ): The path to the file where to write the configuration.
            namespaces (Sequence[str], optional): A list of namespaces dotted names to filter the variables to write. Defaults to [].
            scopes (Sequence[str], optional): A list of scopes to filter the variables to write. Defaults to [].
            type (str, optional): The type of the file to write. Can be "yaml", "json" or "toml". Defaults to "yaml".
        """

        def get_vars_to_dump() -> Iterable[ConfigVar]:
            """
            loop over variable definitions to select the variables to dump. we use a separate function
            in ordre to return a generator to avoid double list traversal
            """
            for var in self._config_var_defs.values():
                var_fq_name = var.fq_name
                if var_fq_name is None:
                    continue
                # check namespaces filter if any
                if namespaces:
                    # if the variable is not in one of the requested namespaces skip it
                    if not any(var_fq_name.startswith(prefix) for prefix in namespaces):
                        continue

                # check scope filter if any
                if scopes:
                    # if the variable is specific to some scopes check if one of them is in the requested scopes
                    if var.scopes is not None:
                        if not any(ctx in var.scopes for ctx in scopes):
                            continue

                # check if the variable should be in the file
                # redondant because file_key is None only if no_conffile_search is True, but useful for type checker that knwos that file_key is not None.
                if var.flags.no_conffile_search or var.file_keys is None:
                    continue

                yield var

        if type not in ["json", "yaml", "toml"]:
            raise ValueError(
                f"Unknown type {type}. Supported types are 'json', 'toml' and 'yaml'."
            )
        data: dict[str, Any] = {}

        data = self._serialize_var_defs(get_vars_to_dump())
        if isinstance(file, str):
            file = Path(file)

        # if possible we need to read the file in order to inject our data into it and
        # not remove data in the file that we don't have in configuration.
        if file.exists() and os.access(file, os.R_OK):
            # file exists and is readable, we open it in read mode to load existing data
            with file.open("r", encoding="utf-8") as f:
                if type == "json":
                    existing_data = json.load(f)
                elif type == "yaml":
                    existing_data = yaml.safe_load(f)
                else:
                    existing_data = toml.load(f)
            # merge existing data with new data
            existing_data.update(data)
            data = existing_data
        if not file.parent.exists():
            file.parent.mkdir(parents=True, exist_ok=True)

        with file.open("w", encoding="utf-8") as f:
            if type == "json":
                json.dump(data, f, indent=4)
            elif type == "yaml":
                yaml.safe_dump(data, f)
            else:
                toml.dump(data, f)

    def serialize(self) -> dict[str, Any]:
        """Serialize the AppConfig to a dictionary."""
        return self._serialize_var_defs(self._config_var_defs.values())

    def __repr__(self) -> str:
        return str(self.to_dict())

    def __str__(self) -> str:
        return json.dumps(self.serialize(), indent=2, sort_keys=True, default=str)
