from __future__ import annotations

import sys
from pathlib import Path
from typing import Literal, Optional, Any

from .config_var import configvar
from .utils import PathType, _undef


def _get_os_type() -> str:
    if sys.platform.startswith("win"):
        return "windows"
    elif sys.platform.startswith("linux"):
        return "linux"
    elif sys.platform.startswith("darwin"):
        return "macos"
    return "unknown"


class AutoProlog:
    """
    Automatic configuration for standard paths and environment variables.
    This class defines configuration variables that will be accessible in any
    subclass of AppConfig, providing sensible defaults based directories, Os type
    and execution stage.

    Variables defined:
    - os_type: The operating system type (windows, linux, macos)
    - user_home: The user's home directory, as returned by Path.home()
      Must be used instead of '~' to ensure cross platform compatibility.
    - xdg_data_home: Base directory for user specific data files (XDG standard)
    - xdg_config_home: Base directory for user specific configuration files (XDG standard)
    - xdg_cache_home: Base directory for user specific non-essential data files (XDG standard)
    - xdg_state_home: Base directory for user specific state files (XDG standard)
    - app_data: Application Data directory on Windows
    - app_config: Application Config directory on Windows
    - app_cache: Application Cache directory on Windows
    - data_home: OS independent application data directory
    - config_home: OS independent application configuration directory
    - cache_home: OS independent application cache directory
    - exec_stage: The execution stage, default to the string "dev", no restriction on its value
        to let the user define its own stages.

    Any of this variable can be overridden by a redefinition on a subclasse of AppConfig.
    """

    os_type: Literal["windows", "linux", "macos", "unknown"] = configvar(
        default=lambda _, __, ___: _get_os_type(),
        no_search=True,
        auto_prolog=True,
    )
    """The operating system type (windows, linux, macos)"""

    exec_stage: Any = configvar(
        default=None,
        type_info=str,
        env_keys=["EXEC_STAGE", "STAGE", "ENV"],
        cli_keys=["exec_stage", "stage", "env"],
        allow_override=True,
        auto_prolog=True,
    )
    """The execution stage (dev, prod, test)"""
    user_home: Path = configvar(
        default=lambda _, __, ___: Path.home(),
        no_search=True,
        auto_prolog=True,
    )
    """The user's home directory"""
    # XDG Standards
    xdg_data_home: Optional[Path] = configvar(
        default=lambda _, c, __: (
            c.user_home / ".local" / "share" if c.os_type != "windows" else _undef
        ),
        mandatory=False,
        env_keys="XDG_DATA_HOME",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """XDG Base directory for user specific data files"""
    xdg_config_home: Optional[Path] = configvar(
        default=lambda _, c, __: (
            c.user_home / ".config" if c.os_type != "windows" else _undef
        ),
        mandatory=False,
        env_keys="XDG_CONFIG_HOME",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """XDG Base directory for user specific configuration files"""
    xdg_cache_home: Optional[Path] = configvar(
        default=lambda _, c, __: (
            c.user_home / ".cache" if c.os_type != "windows" else _undef
        ),
        mandatory=False,
        env_keys="XDG_CACHE_HOME",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """XDG Base directory for user specific non-essential data files"""
    xdg_state_home: Optional[Path] = configvar(
        default=lambda _, c, __: (
            c.user_home / ".local" / "state" if c.os_type != "windows" else _undef
        ),
        mandatory=False,
        env_keys="XDG_STATE_HOME",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """XDG Base directory for user specific state files"""
    # Windows specific variables
    app_data: Optional[Path] = configvar(
        default=lambda _, c, __: (
            c.user_home / "AppData" if c.os_type == "windows" else _undef
        ),
        mandatory=False,
        env_keys="APP_DATA",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """Windows Application Data directory"""

    app_config: Optional[Path] = configvar(
        default=lambda _, c, __: (
            _undef if not c.has_value("app_data") else c.app_data / "Config"
        ),
        mandatory=False,
        env_keys="APP_CONFIG",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """Windows Application Config directory"""

    app_cache: Optional[Path] = configvar(
        default=lambda _, c, __: (
            _undef if not c.has_value("app_data") else c.app_data / "Cache"
        ),
        mandatory=False,
        env_keys="APP_CACHE",
        no_value_search=True,
        no_conffile_search=True,
        auto_prolog=True,
    )
    """Windows Application Cache directory"""
    # Unified variables
    data_home: Path = configvar(
        default=lambda _, c, __: (
            c.app_data if c.os_type == "windows" else c.xdg_data_home
        ),
        auto_prolog=True,
        allow_override=True,
    )
    """OS specific application data directory"""

    config_home: Path = configvar(
        default=lambda _, c, __: (
            c.app_config if c.os_type == "windows" else c.xdg_config_home
        ),
        auto_prolog=True,
        allow_override=True,
    )
    """OS specific application configuration directory"""
    cache_home: Path = configvar(
        default=lambda _, c, __: (
            c.app_cache if c.os_type == "windows" else c.xdg_cache_home
        ),
        auto_prolog=True,
        allow_override=True,
    )
    """OS specific application cache directory"""
