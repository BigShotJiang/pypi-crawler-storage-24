# tibet-snap — Cryptographic State Snapshots & Rollback

After a breach (Odido leak, Politie cookies hack, ransomware), the first question is:
**what changed, and how do we get back to a trustworthy state?**

tibet-snap creates cryptographically sealed snapshots of system state using TIBET
provenance tokens. Each snapshot captures file paths, SHA-256 hashes, timestamps,
sizes and permissions — forming an immutable chain of system states.

## What it does

1. **Snapshot** — Capture the current state of files and directories as a TIBET-sealed record
2. **Compare** — Diff two snapshots to see exactly what was added, removed, or modified
3. **Verify** — Re-hash every file and confirm the snapshot is still intact
4. **Rollback plan** — Auto-generate a rollback plan with restore/remove/revert actions
5. **Provenance** — Every operation (create, verify, compare, rollback) is a linked TIBET token

## Install

```bash
pip install tibet-snap
```

## Usage

```python
from tibet_snap import SnapEngine, Snapshot, SnapshotDiff

engine = SnapEngine(store_dir=".tibet-snap")

# Create a snapshot of /etc/nginx
snap = engine.create_snapshot("pre-deploy", paths=["/etc/nginx"])

# Later: create another snapshot
snap2 = engine.create_snapshot("post-deploy", paths=["/etc/nginx"])

# Compare
diff = engine.compare(snap.id, snap2.id)
print(f"Modified: {len(diff.modified)}, Added: {len(diff.added)}, Removed: {len(diff.removed)}")
print(f"Drift score: {diff.drift_score}")

# Verify integrity
ok = engine.verify(snap.id)

# Generate rollback plan
plan = engine.rollback_plan(snap.id)
for action in plan:
    print(f"  {action['action']}: {action['path']}")
```

## CLI

```bash
# Concept overview
tibet-snap info

# Create a snapshot
tibet-snap create pre-deploy /etc/nginx /etc/ssl

# List all snapshots
tibet-snap list

# Compare two snapshots
tibet-snap compare <id_a> <id_b>

# Verify snapshot integrity
tibet-snap verify <id>

# Interactive demo: create → hack → compare → rollback
tibet-snap demo
```

## TIBET Provenance

Every operation creates a linked `SnapToken`:

| Layer     | Content                              |
|-----------|--------------------------------------|
| ERIN      | Snapshot content (paths, hashes)     |
| ERAAN     | Parent snapshot, dependencies        |
| EROMHEEN  | Hostname, timestamp, actor           |
| ERACHTER  | Intent (create/verify/compare/rollback) |

Tokens are chained: each new token references its parent, forming a
tamper-evident audit trail of all snapshot operations.

## License

MIT — Humotica / J. van de Meent
