"""Allow running tibet-snap as ``python -m tibet_snap``."""

from .cli import main

main()
