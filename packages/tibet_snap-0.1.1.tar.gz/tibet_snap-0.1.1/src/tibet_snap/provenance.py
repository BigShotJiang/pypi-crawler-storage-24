"""
TIBET provenance for snapshot operations.

Every create, verify, compare and rollback is recorded
as a SnapToken. The chain is the forensic audit trail.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class SnapToken:
    """
    A single TIBET provenance token for a snapshot operation.

    Layers:
        erin:      snapshot content (paths, hashes)
        eraan:     parent snapshot, dependencies
        eromheen:  hostname, timestamp, actor
        erachter:  intent (create / verify / compare / rollback)
    """
    token_id: str
    timestamp: str
    action: str
    snapshot_id: str
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "snap_provenance",
            "action": self.action,
            "snapshot_id": self.snapshot_id,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class SnapProvenance:
    """
    Provenance tracker for tibet-snap operations.

    Each operation (create, verify, compare, rollback) creates a
    linked SnapToken. Tokens form a chain via parent_id references.
    """

    def __init__(self, actor: str = "tibet-snap"):
        self.actor = actor
        self.tokens: list[SnapToken] = []
        self._last_id: str | None = None

    def create_token(
        self,
        action: str,
        snapshot_id: str,
        paths: list[str] | None = None,
        file_hashes: dict[str, str] | None = None,
        parent_snapshot: str | None = None,
        dependencies: list[str] | None = None,
        intent: str = "",
        details: dict | None = None,
    ) -> SnapToken:
        """
        Create a new provenance token for a snapshot operation.

        Args:
            action: Operation type (create, verify, compare, rollback)
            snapshot_id: The snapshot this token relates to
            paths: File paths captured in the snapshot
            file_hashes: Dict of path -> SHA-256 hash
            parent_snapshot: ID of the parent snapshot (if any)
            dependencies: Other snapshot IDs this depends on
            intent: Human-readable intent description
            details: Extra details for the token
        """
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "paths": paths or [],
            "file_count": len(file_hashes) if file_hashes else 0,
            "hashes_sample": dict(list((file_hashes or {}).items())[:5]),
            "details": details or {},
        }
        eraan = {
            "parent_snapshot": parent_snapshot,
            "parent_token": self._last_id,
            "dependencies": dependencies or [],
            "snapshot_jis": f"jis:{snapshot_id}",
        }
        eromheen = {
            "hostname": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }
        erachter = {
            "intent": intent or f"Snapshot operation: {action}",
            "action": action,
            "snapshot_id": snapshot_id,
        }

        content = json.dumps({"erin": erin}, sort_keys=True)
        token_id = hashlib.sha256(
            f"{snapshot_id}:{action}:{now}".encode()
        ).hexdigest()[:16]
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = SnapToken(
            token_id=token_id,
            timestamp=now,
            action=action,
            snapshot_id=snapshot_id,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        """Return the full token chain as a list of dicts."""
        return [t.to_dict() for t in self.tokens]
