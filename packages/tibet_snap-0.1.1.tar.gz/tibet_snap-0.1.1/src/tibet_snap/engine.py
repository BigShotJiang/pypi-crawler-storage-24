"""
Snap Engine — the core snapshot and rollback engine.

Creates cryptographically sealed snapshots of system state,
compares them, verifies integrity, and generates rollback plans.
"""

import hashlib
import json
import os
import stat
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .provenance import SnapProvenance


@dataclass
class FileRecord:
    """A single file's state at snapshot time."""
    path: str
    sha256: str
    size: int
    mtime: float
    permissions: str

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "size": self.size,
            "mtime": self.mtime,
            "permissions": self.permissions,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "FileRecord":
        return cls(
            path=d["path"],
            sha256=d["sha256"],
            size=d["size"],
            mtime=d["mtime"],
            permissions=d["permissions"],
        )


@dataclass
class Snapshot:
    """
    A cryptographically sealed snapshot of system state.

    Each snapshot records every file's path, SHA-256 hash, size,
    modification time, and permissions. The snapshot itself is
    identified by a hash of all file hashes combined.
    """
    id: str
    name: str
    timestamp: str
    files: dict[str, FileRecord] = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    tibet_token_id: Optional[str] = None

    @property
    def file_count(self) -> int:
        return len(self.files)

    @property
    def total_size(self) -> int:
        return sum(f.size for f in self.files.values())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "timestamp": self.timestamp,
            "file_count": self.file_count,
            "total_size": self.total_size,
            "files": {p: f.to_dict() for p, f in self.files.items()},
            "metadata": self.metadata,
            "tibet_token_id": self.tibet_token_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Snapshot":
        files = {
            p: FileRecord.from_dict(f) for p, f in d.get("files", {}).items()
        }
        return cls(
            id=d["id"],
            name=d["name"],
            timestamp=d["timestamp"],
            files=files,
            metadata=d.get("metadata", {}),
            tibet_token_id=d.get("tibet_token_id"),
        )


@dataclass
class SnapshotDiff:
    """
    The difference between two snapshots.

    Lists every file that was added, removed, or modified.
    drift_score is a 0.0-1.0 measure of how different the states are.
    """
    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    modified: list[str] = field(default_factory=list)
    snapshot_a: str = ""
    snapshot_b: str = ""
    drift_score: float = 0.0

    def to_dict(self) -> dict:
        return {
            "snapshot_a": self.snapshot_a,
            "snapshot_b": self.snapshot_b,
            "added": self.added,
            "removed": self.removed,
            "modified": self.modified,
            "drift_score": self.drift_score,
            "total_changes": len(self.added) + len(self.removed) + len(self.modified),
        }


def _hash_file(path: str) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                h.update(chunk)
    except (OSError, PermissionError):
        return "ERROR_UNREADABLE"
    return h.hexdigest()


def _scan_path(path: str) -> list[str]:
    """Recursively collect all file paths under a directory or single file."""
    p = Path(path)
    if p.is_file():
        return [str(p.resolve())]
    if p.is_dir():
        result = []
        for root, _dirs, filenames in os.walk(p):
            for fn in sorted(filenames):
                result.append(str(Path(root, fn).resolve()))
        return result
    return []


def _file_permissions(path: str) -> str:
    """Return octal permission string for a file."""
    try:
        return oct(os.stat(path).st_mode & 0o7777)
    except OSError:
        return "0o0000"


def _compute_snapshot_id(files: dict[str, FileRecord], name: str, ts: str) -> str:
    """Derive a snapshot ID from the combined file hashes."""
    content = json.dumps(
        {
            "name": name,
            "timestamp": ts,
            "hashes": {p: f.sha256 for p, f in sorted(files.items())},
        },
        sort_keys=True,
    )
    return hashlib.sha256(content.encode()).hexdigest()[:16]


class SnapEngine:
    """
    Cryptographic State Snapshot Engine.

    Creates sealed snapshots of files and directories, compares them,
    verifies integrity, and generates rollback plans.

    Usage::

        engine = SnapEngine(store_dir=".tibet-snap")
        snap = engine.create_snapshot("baseline", paths=["/etc/nginx"])
        ok = engine.verify(snap.id)

    Args:
        store_dir: Directory where snapshots are stored as JSON files.
                   Defaults to ".tibet-snap" in the current working directory.
        actor: Actor name for provenance tokens.
    """

    def __init__(
        self,
        store_dir: str = ".tibet-snap",
        actor: str = "tibet-snap",
    ):
        self.store_dir = Path(store_dir)
        self.provenance = SnapProvenance(actor=actor)
        self._snapshots: dict[str, Snapshot] = {}

        # Load existing snapshots from disk
        if self.store_dir.exists():
            self._load_snapshots()

    def _load_snapshots(self) -> None:
        """Load all snapshot JSON files from the store directory."""
        for fp in sorted(self.store_dir.glob("snap_*.json")):
            try:
                with open(fp) as f:
                    data = json.load(f)
                snap = Snapshot.from_dict(data)
                self._snapshots[snap.id] = snap
            except (json.JSONDecodeError, KeyError, OSError):
                continue

    def _save_snapshot(self, snap: Snapshot) -> None:
        """Persist a snapshot to disk as JSON."""
        self.store_dir.mkdir(parents=True, exist_ok=True)
        fp = self.store_dir / f"snap_{snap.id}.json"
        with open(fp, "w") as f:
            json.dump(snap.to_dict(), f, indent=2)

    def create_snapshot(
        self,
        name: str,
        paths: list[str] | None = None,
        metadata: dict | None = None,
    ) -> Snapshot:
        """
        Create a new snapshot of the specified files and directories.

        If no paths are given, creates an empty snapshot (useful for demos).

        Args:
            name: Human-readable snapshot name (e.g. "pre-deploy")
            paths: List of file/directory paths to snapshot
            metadata: Optional metadata dict to store with the snapshot

        Returns:
            The created Snapshot object
        """
        now = datetime.now(timezone.utc).isoformat()
        files: dict[str, FileRecord] = {}

        for path in (paths or []):
            for file_path in _scan_path(path):
                st = os.stat(file_path)
                record = FileRecord(
                    path=file_path,
                    sha256=_hash_file(file_path),
                    size=st.st_size,
                    mtime=st.st_mtime,
                    permissions=_file_permissions(file_path),
                )
                files[file_path] = record

        snap_id = _compute_snapshot_id(files, name, now)

        # Find parent: the most recent existing snapshot
        parent_id: str | None = None
        if self._snapshots:
            latest = max(self._snapshots.values(), key=lambda s: s.timestamp)
            parent_id = latest.id

        snap = Snapshot(
            id=snap_id,
            name=name,
            timestamp=now,
            files=files,
            metadata=metadata or {},
        )

        # Create provenance token
        file_hashes = {p: r.sha256 for p, r in files.items()}
        token = self.provenance.create_token(
            action="create",
            snapshot_id=snap_id,
            paths=paths or [],
            file_hashes=file_hashes,
            parent_snapshot=parent_id,
            intent=f"Create snapshot '{name}' with {len(files)} files",
        )
        snap.tibet_token_id = token.token_id

        self._snapshots[snap_id] = snap
        self._save_snapshot(snap)
        return snap

    def compare(self, snapshot_id_a: str, snapshot_id_b: str) -> SnapshotDiff:
        """
        Compare two snapshots and return the differences.

        Args:
            snapshot_id_a: ID of the first (older) snapshot
            snapshot_id_b: ID of the second (newer) snapshot

        Returns:
            SnapshotDiff with added, removed, and modified file lists

        Raises:
            KeyError: If either snapshot ID is not found
        """
        snap_a = self._get_snapshot(snapshot_id_a)
        snap_b = self._get_snapshot(snapshot_id_b)

        paths_a = set(snap_a.files.keys())
        paths_b = set(snap_b.files.keys())

        added = sorted(paths_b - paths_a)
        removed = sorted(paths_a - paths_b)
        modified = sorted(
            p for p in (paths_a & paths_b)
            if snap_a.files[p].sha256 != snap_b.files[p].sha256
        )

        # Drift score: proportion of files that changed
        total = len(paths_a | paths_b)
        changes = len(added) + len(removed) + len(modified)
        drift_score = round(changes / total, 4) if total > 0 else 0.0

        diff = SnapshotDiff(
            added=added,
            removed=removed,
            modified=modified,
            snapshot_a=snapshot_id_a,
            snapshot_b=snapshot_id_b,
            drift_score=drift_score,
        )

        # Provenance token for the comparison
        self.provenance.create_token(
            action="compare",
            snapshot_id=snapshot_id_a,
            dependencies=[snapshot_id_b],
            intent=f"Compare '{snap_a.name}' vs '{snap_b.name}': "
                   f"{changes} changes, drift={drift_score}",
            details=diff.to_dict(),
        )

        return diff

    def verify(self, snapshot_id: str) -> bool:
        """
        Verify the integrity of a snapshot by re-hashing all files.

        Returns True if every file still matches its recorded hash.
        Returns False if any file has changed, is missing, or is unreadable.

        Args:
            snapshot_id: ID of the snapshot to verify

        Returns:
            True if all hashes match, False otherwise
        """
        snap = self._get_snapshot(snapshot_id)

        mismatches: list[str] = []
        missing: list[str] = []
        verified = 0

        for path, record in snap.files.items():
            if not Path(path).exists():
                missing.append(path)
                continue
            current_hash = _hash_file(path)
            if current_hash != record.sha256:
                mismatches.append(path)
            else:
                verified += 1

        intact = len(mismatches) == 0 and len(missing) == 0

        self.provenance.create_token(
            action="verify",
            snapshot_id=snapshot_id,
            file_hashes={p: r.sha256 for p, r in snap.files.items()},
            intent=f"Verify snapshot '{snap.name}': "
                   f"{'INTACT' if intact else 'COMPROMISED'}",
            details={
                "intact": intact,
                "verified": verified,
                "mismatches": mismatches,
                "missing": missing,
                "total_files": len(snap.files),
            },
        )

        return intact

    def rollback_plan(self, snapshot_id: str) -> list[dict]:
        """
        Generate a rollback plan to restore the system to a snapshot state.

        Compares the current filesystem against the snapshot and produces
        a list of actions (restore, remove, revert) needed to get back
        to the snapshot state.

        Args:
            snapshot_id: ID of the target snapshot to roll back to

        Returns:
            List of action dicts with keys: action, path, reason, details
        """
        snap = self._get_snapshot(snapshot_id)
        actions: list[dict] = []

        for path, record in snap.files.items():
            p = Path(path)

            if not p.exists():
                actions.append({
                    "action": "restore",
                    "path": path,
                    "reason": "File missing — must be restored from backup",
                    "details": {
                        "expected_sha256": record.sha256,
                        "expected_size": record.size,
                        "expected_permissions": record.permissions,
                    },
                })
                continue

            current_hash = _hash_file(path)
            if current_hash != record.sha256:
                actions.append({
                    "action": "revert",
                    "path": path,
                    "reason": "File modified — hash mismatch, revert to snapshot version",
                    "details": {
                        "expected_sha256": record.sha256,
                        "current_sha256": current_hash,
                        "expected_size": record.size,
                        "expected_permissions": record.permissions,
                    },
                })
                continue

            # Check permissions change
            current_perms = _file_permissions(path)
            if current_perms != record.permissions:
                actions.append({
                    "action": "fix_permissions",
                    "path": path,
                    "reason": "Permissions changed — restore original permissions",
                    "details": {
                        "expected_permissions": record.permissions,
                        "current_permissions": current_perms,
                    },
                })

        # Check for files that exist in the snapshot's directories but
        # are NOT in the snapshot (potentially injected after snapshot)
        snapshot_dirs = set()
        for path in snap.files:
            snapshot_dirs.add(str(Path(path).parent))

        for d in snapshot_dirs:
            if not Path(d).exists():
                continue
            for file_path in _scan_path(d):
                if file_path not in snap.files:
                    actions.append({
                        "action": "remove",
                        "path": file_path,
                        "reason": "File not in snapshot — potentially injected, remove",
                        "details": {
                            "current_sha256": _hash_file(file_path),
                        },
                    })

        self.provenance.create_token(
            action="rollback",
            snapshot_id=snapshot_id,
            intent=f"Rollback plan for '{snap.name}': {len(actions)} actions",
            details={
                "action_count": len(actions),
                "actions_summary": {
                    a: len([x for x in actions if x["action"] == a])
                    for a in {"restore", "revert", "remove", "fix_permissions"}
                },
            },
        )

        return actions

    def list_snapshots(self) -> list[Snapshot]:
        """
        List all known snapshots, ordered by timestamp.

        Returns:
            List of Snapshot objects sorted oldest-first
        """
        return sorted(self._snapshots.values(), key=lambda s: s.timestamp)

    def get_snapshot(self, snapshot_id: str) -> Snapshot:
        """
        Get a snapshot by ID.

        Args:
            snapshot_id: The snapshot ID

        Returns:
            The Snapshot object

        Raises:
            KeyError: If snapshot not found
        """
        return self._get_snapshot(snapshot_id)

    def _get_snapshot(self, snapshot_id: str) -> Snapshot:
        """Internal: get snapshot or raise KeyError."""
        if snapshot_id not in self._snapshots:
            raise KeyError(f"Snapshot not found: {snapshot_id}")
        return self._snapshots[snapshot_id]
