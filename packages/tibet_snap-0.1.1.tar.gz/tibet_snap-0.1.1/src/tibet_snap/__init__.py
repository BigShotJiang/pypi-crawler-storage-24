"""
tibet-snap — Cryptographic State Snapshots & Rollback
=====================================================

After a breach you need to roll back to a trustworthy state.
tibet-snap creates TIBET-sealed snapshots of system state,
compares them, and generates verifiable rollback plans.

Every snapshot is a TIBET token chain of all file hashes at
that moment. Every comparison and rollback is provenance-tracked.

Usage::

    from tibet_snap import SnapEngine, Snapshot, SnapshotDiff

    engine = SnapEngine()
    snap = engine.create_snapshot("pre-deploy", paths=["/etc/nginx"])
    ok = engine.verify(snap.id)

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica 2025
"""

from .engine import SnapEngine, Snapshot, SnapshotDiff
from .provenance import SnapProvenance

__version__ = "0.1.1"

__all__ = [
    "SnapEngine",
    "Snapshot",
    "SnapshotDiff",
    "SnapProvenance",
]
