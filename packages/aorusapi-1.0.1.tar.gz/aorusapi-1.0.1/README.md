# AorusAPI SDK

SDK para la API de voz de AorusAPI. Compatible con el SDK oficial de SignalWire — solo cambia el import.

## Instalación

```bash
pip install aorusapi
```

## Configuración

Las credenciales se obtienen desde el dashboard: **https://app.aorusapi.com**

Ejemplo de `settings.json`:

```json
{
  "signalwire": {
    "project_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
    "api_token": "PTxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "space_url": "app.aorusapi.com"
  }
}
```

## Uso

```python
import json
from aorusapi.rest import Client as SignalWireClient

# Cargar settings
with open("settings.json", "r") as f:
    jsonsettings = json.load(f)

sw = jsonsettings["signalwire"]

# Inicializar cliente
signalwire_client = SignalWireClient(
    sw["project_id"],
    sw["api_token"],
    signalwire_space_url=sw["space_url"]
)

# Crear llamada
call = signalwire_client.calls.create(
    to="+1234567890",
    from_="+0987654321",
    url="https://mi-backend.com/voice",
    method="POST",
    timeout=28,
    record=True,
    status_callback="https://mi-backend.com/status_callback",
    status_callback_event=["initiated", "ringing", "completed"],
    recording_status_callback="https://mi-backend.com/notify_end",
    machine_detection="Enable",
)

print(call.sid)     # CAxxxxxxxxxxxxx
print(call.status)  # queued
```

## Parámetros de `calls.create()`

| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `to` | str | Número destino en formato E.164 (`+1234567890`) |
| `from_` | str | Número origen en formato E.164 |
| `url` | str | URL que devuelve el XML con las instrucciones de la llamada |
| `method` | str | Método HTTP para `url` (`GET` / `POST`) |
| `timeout` | int | Segundos antes de considerar la llamada sin respuesta |
| `record` | bool | Grabar la llamada |
| `status_callback` | str | URL que recibe los eventos de estado de la llamada |
| `status_callback_event` | list | Eventos a notificar: `initiated`, `ringing`, `answered`, `completed` |
| `recording_status_callback` | str | URL que recibe la notificación cuando la grabación está lista |
| `machine_detection` | str | `Enable` para activar detección de contestador automático |
| `machine_detection_timeout` | int | Segundos máximos para la detección AMD |
| `async_amd` | bool | Detección AMD asíncrona (no bloquea la llamada) |
| `async_amd_status_callback` | str | URL que recibe el resultado AMD cuando `async_amd=True` |

## Consultar y modificar una llamada

```python
# Obtener estado
call = signalwire_client.calls("CAxxxxxxxxxxxxx").fetch()
print(call.status)

# Colgar una llamada activa
signalwire_client.calls("CAxxxxxxxxxxxxx").update(status="completed")

# Redirigir a nuevo XML
signalwire_client.calls("CAxxxxxxxxxxxxx").update(url="https://mi-backend.com/nuevo-xml")
```

## Migrar desde SignalWire

```python
# Antes
from signalwire.rest import Client as SignalWireClient

# Después — el resto del código no cambia
from aorusapi.rest import Client as SignalWireClient
```

## Migrar desde el archivo `signalwire_replacement.py`

```python
# Antes
from signalwire_replacement import Client as SignalWireClient

# Después — el resto del código no cambia
from aorusapi.rest import Client as SignalWireClient
```
