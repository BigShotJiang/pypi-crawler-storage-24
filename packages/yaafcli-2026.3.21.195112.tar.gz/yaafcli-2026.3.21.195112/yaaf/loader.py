"""Filesystem route discovery and module loading."""

from __future__ import annotations

import importlib.util
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any

from .di import DependencyResolver, ServiceRegistry, _get_service_metadata
from .types import Handler


@dataclass
class RouteTarget:
    """A discovered filesystem route and its handlers/services."""

    pattern: re.Pattern[str]
    route_parts: list[str]
    param_names: list[str]
    handlers: dict[str, Handler]
    services: ServiceRegistry
    service: Any | None
    static_count: int
    segment_count: int


def _load_module(path: Path, name_prefix: str, root_dir: str) -> ModuleType:
    """Load a Python module from an explicit file path."""
    parts = path.parts
    root_parts = Path(root_dir).parts
    if len(root_parts) == 1:
        root_name = root_parts[0]
        if root_name in parts:
            root_index = parts.index(root_name)
            module_parts = parts[root_index:]
            module_name = ".".join(module_parts[:-1] + (path.stem,))
        else:
            module_name = f"yaaf_{name_prefix}_{abs(hash(path))}"
    else:
        try:
            root_index = parts.index(root_parts[-1])
            path_to_root = Path(*parts[: root_index + 1])
            if path_to_root.samefile(Path(root_dir)):
                module_parts = parts[root_index:]
                module_name = ".".join(module_parts[:-1] + (path.stem,))
            else:
                module_name = f"yaaf_{name_prefix}_{abs(hash(path))}"
        except (ValueError, OSError):
            module_name = f"yaaf_{name_prefix}_{abs(hash(path))}"

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _collect_services(
    module: ModuleType, resolver: DependencyResolver
) -> tuple[Any | None, list[str]]:
    """Create a service from a module, if it exposes one.

    Returns:
        Tuple of (instance, aliases) where aliases come from @service decorator metadata.
    """
    instance = None
    service_cls = None

    if hasattr(module, "service"):
        inst = getattr(module, "service")
        if inst is not None:
            if callable(inst):
                instance = resolver.call(inst, {})
            else:
                instance = inst
            if hasattr(module, "Service"):
                service_cls = module.Service
    elif hasattr(module, "get_service") and callable(module.get_service):
        instance = resolver.call(module.get_service, {})
    elif hasattr(module, "Service"):
        service_cls = module.Service
        if callable(service_cls):
            instance = resolver.call(service_cls, {})

    if instance is not None:
        inst_type = type(instance)
        name, aliases = _get_service_metadata(inst_type)
        return instance, aliases or []

    return None, []


def discover_routes(root_dir: str) -> tuple[list[RouteTarget], ServiceRegistry]:
    """Discover route handlers and services rooted under a directory."""
    base = Path(root_dir)
    if not base.exists():
        return [], ServiceRegistry(by_type={}, by_alias={})

    base_parent = str(base.parent)
    if base_parent not in sys.path:
        sys.path.insert(0, base_parent)

    targets: list[tuple[Path, list[str], list[str], str, int, int]] = []
    service_modules: dict[Path, ModuleType] = {}
    server_modules: dict[Path, ModuleType] = {}
    service_aliases: dict[Path, list[str]] = {}

    for root, _dirs, files in os.walk(base):
        if "_server.py" not in files:
            continue

        root_path = Path(root)
        parts = root_path.parts
        base_parts = base.parts
        route_parts = list(parts[len(base_parts) :])
        pattern, param_names, static_count, segment_count = build_pattern(
            route_parts, prefix=""
        )
        targets.append(
            (root_path, route_parts, param_names, pattern, static_count, segment_count)
        )

        route_key = "_".join(route_parts)
        aliases = [route_key, _service_alias(route_parts)]
        if route_parts:
            aliases.append(route_parts[-1])
        service_aliases[root_path] = [alias for alias in aliases if alias]

        if "_service.py" in files:
            service_modules[root_path] = _load_module(
                root_path / "_service.py", "service", root_dir
            )
        server_modules[root_path] = _load_module(
            root_path / "_server.py", "server", root_dir
        )

    registry = ServiceRegistry(by_type={}, by_alias={})
    resolver = DependencyResolver(registry)

    service_instances: dict[Path, Any] = {}
    unresolved = list(service_modules.items())
    while unresolved:
        progress = False
        remaining: list[tuple[Path, ModuleType]] = []
        for path, module in unresolved:
            try:
                instance, decorator_aliases = _collect_services(module, resolver)
            except TypeError:
                instance = None
                decorator_aliases = []
            if instance is None:
                remaining.append((path, module))
                continue
            service_instances[path] = instance

            for alias in service_aliases.get(path, []):
                registry.by_alias[alias] = instance

            for alias in decorator_aliases:
                registry.by_alias[alias] = instance

            progress = True
        if not progress:
            missing = [str(path) for path, _ in remaining]
            raise RuntimeError(
                f"Unresolved service dependencies in: {', '.join(missing)}"
            )
        unresolved = remaining

    routes: list[RouteTarget] = []
    for (
        root_path,
        route_parts,
        param_names,
        pattern,
        static_count,
        segment_count,
    ) in targets:
        server_module = server_modules[root_path]
        handlers: dict[str, Handler] = {}
        for method in ("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"):
            func = getattr(server_module, method.lower(), None)
            if callable(func):
                handlers[method] = func  # type: ignore[assignment]
        compiled = re.compile(pattern)
        service_instance = service_instances.get(root_path)
        routes.append(
            RouteTarget(
                pattern=compiled,
                route_parts=route_parts,
                param_names=param_names,
                handlers=handlers,
                services=registry,
                service=service_instance,
                static_count=static_count,
                segment_count=segment_count,
            )
        )

    routes.sort(
        key=lambda route: (route.static_count, route.segment_count), reverse=True
    )

    static_routes = [route for route in routes if not route.param_names]
    dynamic_routes = [route for route in routes if route.param_names]
    for dyn in dynamic_routes:
        for stat in static_routes:
            if dyn.segment_count != stat.segment_count:
                continue
            candidate = "/" + "/".join(stat.route_parts)
            if dyn.pattern.match(candidate):
                print(
                    f"Warning: dynamic route /{'/'.join(dyn.route_parts)} matches "
                    f"static route /{'/'.join(stat.route_parts)}"
                )
                break
    return routes, registry


def build_pattern(
    route_parts: list[str], prefix: str
) -> tuple[str, list[str], int, int]:
    """Build a regex pattern and metadata for a route path.

    Supports:
        [name]     - Single segment dynamic (matches "value")
        [...name]  - Catch-all dynamic (matches "path/to/file.txt")
    """
    if not route_parts:
        if prefix:
            return rf"^/{re.escape(prefix)}$", [], 0, 0
        return "^/$", [], 0, 0

    param_names: list[str] = []
    pattern_parts: list[str] = []
    static_count = 0
    for part in route_parts:
        if part.startswith("[...") and part.endswith("]"):
            name = part[4:-1]
            if not name:
                raise ValueError("Empty catch-all route segment")
            param_names.append(name)
            pattern_parts.append(f"(?P<{name}>.*)")
        elif part.startswith("[") and part.endswith("]"):
            name = part[1:-1]
            if not name:
                raise ValueError("Empty dynamic route segment")
            param_names.append(name)
            pattern_parts.append(f"(?P<{name}>[^/]+)")
        else:
            pattern_parts.append(re.escape(part))
            static_count += 1

    if prefix:
        pattern = "^/" + re.escape(prefix) + "/" + "/".join(pattern_parts) + "$"
    else:
        pattern = "^/" + "/".join(pattern_parts) + "$"
    return pattern, param_names, static_count, len(route_parts)


def _service_alias(route_parts: list[str]) -> str:
    def strip_dynamic(segment: str) -> str:
        if segment.startswith("[...") and segment.endswith("]"):
            return segment[4:-1]
        if segment.startswith("[") and segment.endswith("]"):
            return segment[1:-1]
        return segment

    def camel_case(parts: list[str]) -> str:
        return "".join(
            sub[:1].upper() + sub[1:]
            for part in parts
            if part
            for sub in part.split("_")
            if sub
        )

    parts = [strip_dynamic(part) for part in route_parts]
    safe = [part for part in parts if part.isidentifier()]
    base = camel_case(safe) or "Route"
    return f"{base}Service"
