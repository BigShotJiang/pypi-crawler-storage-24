"""Tests for the diff module."""

from __future__ import annotations

from pathlib import Path

import pytest

from py_import_cleaner.analyzer import analyze_file, analyze_source
from py_import_cleaner.diff import generate_diff, generate_diff_from_source


class TestGenerateDiff:
    """Test diff generation."""

    def test_diff_shows_removed_import(self) -> None:
        source = "import os\nimport sys\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        diff = generate_diff_from_source(source, result)
        assert "-import sys" in diff
        assert "+import os" not in diff or "import os" in diff

    def test_no_unused_no_diff(self) -> None:
        source = "import os\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        diff = generate_diff_from_source(source, result)
        assert diff == ""

    def test_diff_shows_filename(self) -> None:
        source = "import os\nimport sys\n\nprint(os.getcwd())\n"
        result = analyze_source(source, filename="test.py")
        diff = generate_diff_from_source(source, result, filename="test.py")
        assert "test.py" in diff

    def test_diff_partial_from_import(self) -> None:
        source = "from os.path import join, exists\n\nprint(join('a', 'b'))\n"
        result = analyze_source(source)
        diff = generate_diff_from_source(source, result)
        assert "-from os.path import join, exists" in diff
        assert "+from os.path import join" in diff


class TestGenerateDiffFromFile:
    """Test file-based diff generation."""

    def test_generate_diff_from_file(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("import os\nimport sys\n\nprint(os.getcwd())\n")
        result = analyze_file(filepath)
        diff = generate_diff(filepath, result)
        assert "-import sys" in diff

    def test_generate_diff_no_unused(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("import os\n\nprint(os.getcwd())\n")
        result = analyze_file(filepath)
        diff = generate_diff(filepath, result)
        assert diff == ""
