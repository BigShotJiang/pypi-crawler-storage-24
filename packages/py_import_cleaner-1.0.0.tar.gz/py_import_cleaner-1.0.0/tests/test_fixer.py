"""Tests for the fixer module."""

from __future__ import annotations

import pytest

from py_import_cleaner.analyzer import analyze_source
from py_import_cleaner.fixer import fix_source


class TestFixSimpleImports:
    """Test fixing simple unused imports."""

    def test_remove_single_unused(self) -> None:
        source = "import os\nimport sys\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "import sys" not in fixed
        assert "import os" in fixed
        assert "print(os.getcwd())" in fixed

    def test_remove_all_unused(self) -> None:
        source = "import os\nimport sys\n\nprint('hello')\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "import os" not in fixed
        assert "import sys" not in fixed
        assert "print('hello')" in fixed

    def test_no_unused_no_change(self) -> None:
        source = "import os\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert fixed == source


class TestFixAliasImports:
    """Test fixing alias imports."""

    def test_remove_unused_alias(self) -> None:
        source = "import numpy as np\nimport os\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "import numpy" not in fixed
        assert "import os" in fixed

    def test_keep_used_alias(self) -> None:
        source = "import numpy as np\nimport os\n\nnp.array([1])\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert fixed == source


class TestFixFromImports:
    """Test fixing from...import statements."""

    def test_remove_single_name_from_import(self) -> None:
        source = "from datetime import datetime\n\nprint('hello')\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "from datetime" not in fixed

    def test_partial_from_import(self) -> None:
        source = "from os.path import join, exists\n\nprint(join('a', 'b'))\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "exists" not in fixed
        assert "from os.path import join" in fixed

    def test_remove_all_names_from_import(self) -> None:
        source = "from os.path import join, exists\n\nprint('hello')\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "from os.path" not in fixed

    def test_partial_three_names(self) -> None:
        source = "from collections import OrderedDict, defaultdict, Counter\n\nd = defaultdict(list)\nc = Counter()\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "OrderedDict" not in fixed
        assert "defaultdict" in fixed
        assert "Counter" in fixed


class TestFixFormatting:
    """Test that fixing preserves formatting."""

    def test_preserves_surrounding_code(self) -> None:
        source = (
            "# Header comment\n\n"
            "import os\n"
            "import sys\n\n"
            "def main():\n"
            "    print(os.getcwd())\n"
        )
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "# Header comment" in fixed
        assert "def main():" in fixed
        assert "import sys" not in fixed

    def test_no_excessive_blank_lines(self) -> None:
        source = "import os\nimport sys\nimport json\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        # Should not have more than 2 consecutive newlines
        assert "\n\n\n" not in fixed

    def test_preserves_indented_imports(self) -> None:
        source = (
            "def foo():\n"
            "    import os\n"
            "    import sys\n"
            "    return os.getcwd()\n"
        )
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "import sys" not in fixed
        assert "    import os" in fixed


class TestFixFromImportWithAlias:
    """Test fixing from imports that have aliases."""

    def test_partial_from_import_with_alias_kept(self) -> None:
        source = "from os.path import join as j, exists\n\nprint(j('a', 'b'))\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "exists" not in fixed
        assert "join as j" in fixed

    def test_partial_from_import_with_alias_removed(self) -> None:
        source = "from os.path import join, exists as ex\n\nprint(ex('a'))\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "join" not in fixed
        assert "exists as ex" in fixed


class TestFixMultipleFiles:
    """Test fixing with multiple unused imports spread across lines."""

    def test_remove_multiple_scattered_unused(self) -> None:
        source = (
            "import os\n"
            "import sys\n"
            "import json\n"
            "import csv\n\n"
            "print(os.getcwd())\n"
            "print(json.dumps({}))\n"
        )
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "import sys" not in fixed
        assert "import csv" not in fixed
        assert "import os" in fixed
        assert "import json" in fixed


class TestFixCommaImport:
    """Test fixing 'import a, b' style imports (rare but valid Python)."""

    def test_comma_import_partial_unused(self) -> None:
        """Test 'import os, sys' where sys is unused — keeps only os."""
        source = "import os, sys\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "sys" not in fixed
        assert "import os" in fixed

    def test_comma_import_all_unused(self) -> None:
        """Test 'import os, sys' where both are unused."""
        source = "import os, sys\n\nprint('hello')\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "import" not in fixed
        assert "print('hello')" in fixed

    def test_comma_import_with_alias_partial(self) -> None:
        """Test 'import os, sys as s' where os is unused."""
        source = "import os, sys as s\n\nprint(s.argv)\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "os" not in fixed
        assert "sys as s" in fixed


class TestFixMultiLineFromImport:
    """Test fixing multi-line from imports with parentheses."""

    def test_multi_line_from_import_partial(self) -> None:
        source = (
            "from os.path import (\n"
            "    join,\n"
            "    exists,\n"
            ")\n\n"
            "print(join('a', 'b'))\n"
        )
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "exists" not in fixed
        assert "join" in fixed

    def test_multi_line_from_import_all_unused(self) -> None:
        source = (
            "from os.path import (\n"
            "    join,\n"
            "    exists,\n"
            ")\n\n"
            "print('hello')\n"
        )
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert "from os.path" not in fixed


class TestFixInPlace:
    """Test fix_file_in_place."""

    def test_fix_file_in_place_modifies(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("import os\nimport sys\n\nprint(os.getcwd())\n")

        from py_import_cleaner.analyzer import analyze_file
        from py_import_cleaner.fixer import fix_file_in_place

        result = analyze_file(filepath)
        modified = fix_file_in_place(filepath, result)
        assert modified is True

        content = filepath.read_text()
        assert "import sys" not in content
        assert "import os" in content

    def test_fix_file_in_place_no_change(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("import os\n\nprint(os.getcwd())\n")

        from py_import_cleaner.analyzer import analyze_file
        from py_import_cleaner.fixer import fix_file_in_place

        result = analyze_file(filepath)
        modified = fix_file_in_place(filepath, result)
        assert modified is False


class TestFixFile:
    """Test fix_file function."""

    def test_fix_file_returns_fixed_source(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("import os\nimport sys\n\nprint(os.getcwd())\n")

        from py_import_cleaner.analyzer import analyze_file
        from py_import_cleaner.fixer import fix_file

        result = analyze_file(filepath)
        fixed = fix_file(filepath, result)
        assert "import sys" not in fixed
        assert "import os" in fixed

    def test_fix_file_no_unused(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        source = "import os\n\nprint(os.getcwd())\n"
        filepath.write_text(source)

        from py_import_cleaner.analyzer import analyze_file
        from py_import_cleaner.fixer import fix_file

        result = analyze_file(filepath)
        fixed = fix_file(filepath, result)
        assert fixed == source


class TestFixEdgeCases:
    """Test edge cases in fixing."""

    def test_empty_result_returns_source(self) -> None:
        source = "import os\n\nprint(os.getcwd())\n"
        result = analyze_source(source)
        fixed = fix_source(source, result)
        assert fixed == source

    def test_syntax_error_source(self) -> None:
        source = "import os\n\ndef foo(:\n    pass\n"
        result = analyze_source(source)
        assert result.error is not None
        # Trying to fix a file with syntax error should return original
        fixed = fix_source(source, result)
        assert fixed == source
