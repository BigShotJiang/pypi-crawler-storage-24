"""Tests for the utils module."""

from __future__ import annotations

from pathlib import Path

import pytest

from py_import_cleaner.utils import is_python_file, read_file_content, setup_logging, write_file_content


class TestIsPythonFile:
    """Test is_python_file."""

    def test_python_file(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("print('hello')")
        assert is_python_file(filepath) is True

    def test_non_python_file(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.txt"
        filepath.write_text("hello")
        assert is_python_file(filepath) is False

    def test_directory(self, tmp_path: Path) -> None:
        assert is_python_file(tmp_path) is False

    def test_nonexistent(self, tmp_path: Path) -> None:
        assert is_python_file(tmp_path / "nonexistent.py") is False


class TestReadWriteFileContent:
    """Test file read/write functions."""

    def test_read_file(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        filepath.write_text("import os\n", encoding="utf-8")
        content = read_file_content(filepath)
        assert content == "import os\n"

    def test_write_file(self, tmp_path: Path) -> None:
        filepath = tmp_path / "test.py"
        write_file_content(filepath, "import sys\n")
        assert filepath.read_text(encoding="utf-8") == "import sys\n"


class TestSetupLogging:
    """Test logging setup."""

    def test_setup_logging_default(self) -> None:
        setup_logging()  # Should not raise

    def test_setup_logging_verbose(self) -> None:
        setup_logging(verbose=True)  # Should not raise
