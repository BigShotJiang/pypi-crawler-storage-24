"""Tests for the CLI module."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from click.testing import CliRunner

from py_import_cleaner.cli import main


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def sample_project(tmp_path: Path) -> Path:
    """Create a sample project with unused imports."""
    (tmp_path / "clean.py").write_text("import os\n\nprint(os.getcwd())\n")
    (tmp_path / "dirty.py").write_text("import os\nimport sys\n\nprint(os.getcwd())\n")
    (tmp_path / "all_dirty.py").write_text("import json\nimport csv\n\nprint('hello')\n")
    return tmp_path


class TestCLIBasicScan:
    """Test basic scanning via CLI."""

    def test_scan_finds_unused(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(main, [str(sample_project)])
        assert result.exit_code == 1  # non-zero because unused found
        assert "unused" in result.output.lower() or "sys" in result.output

    def test_scan_clean_project(self, runner: CliRunner, tmp_path: Path) -> None:
        (tmp_path / "clean.py").write_text("import os\n\nprint(os.getcwd())\n")
        result = runner.invoke(main, [str(tmp_path)])
        assert result.exit_code == 0
        assert "no unused" in result.output.lower()

    def test_scan_no_python_files(self, runner: CliRunner, tmp_path: Path) -> None:
        (tmp_path / "readme.md").write_text("# Hello\n")
        result = runner.invoke(main, [str(tmp_path)])
        assert result.exit_code == 0


class TestCLIFix:
    """Test --fix mode."""

    def test_fix_removes_unused(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(main, [str(sample_project), "--fix"])
        assert result.exit_code == 0
        # Verify the file was fixed
        content = (sample_project / "dirty.py").read_text()
        assert "import sys" not in content
        assert "import os" in content

    def test_fix_preserves_clean_files(self, runner: CliRunner, sample_project: Path) -> None:
        original = (sample_project / "clean.py").read_text()
        runner.invoke(main, [str(sample_project), "--fix"])
        assert (sample_project / "clean.py").read_text() == original


class TestCLIDryRun:
    """Test --dry-run mode."""

    def test_dry_run_no_changes(self, runner: CliRunner, sample_project: Path) -> None:
        original_dirty = (sample_project / "dirty.py").read_text()
        result = runner.invoke(main, [str(sample_project), "--dry-run"])
        # File should not be modified
        assert (sample_project / "dirty.py").read_text() == original_dirty


class TestCLIDiff:
    """Test --diff mode."""

    def test_diff_shows_changes(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(main, [str(sample_project), "--diff"])
        assert result.exit_code == 1
        # Should show diff-like output
        assert "-import sys" in result.output or "sys" in result.output


class TestCLIVerbose:
    """Test --verbose mode."""

    def test_verbose_shows_scanning_info(self, runner: CliRunner, sample_project: Path) -> None:
        result = runner.invoke(main, [str(sample_project), "--verbose"])
        assert "scanning" in result.output.lower() or "file" in result.output.lower()


class TestCLIExclude:
    """Test --exclude option."""

    def test_exclude_directory(self, runner: CliRunner, tmp_path: Path) -> None:
        sub = tmp_path / "excluded"
        sub.mkdir()
        (sub / "module.py").write_text("import os\n\nprint('hello')\n")
        (tmp_path / "main.py").write_text("import os\n\nprint(os.getcwd())\n")

        result = runner.invoke(main, [str(tmp_path), "--exclude", "excluded"])
        assert result.exit_code == 0  # Only clean file left


class TestCLIConfigFile:
    """Test --config option."""

    def test_custom_config(self, runner: CliRunner, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text("import typing\n\nprint('hello')\n")
        config = tmp_path / "custom.toml"
        config.write_text('[tool.importcleaner]\nignore_modules = ["typing"]\n')

        result = runner.invoke(main, [str(tmp_path), "--config", str(config)])
        assert result.exit_code == 0
