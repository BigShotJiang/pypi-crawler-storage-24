"""Tests for the scanner module."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from py_import_cleaner.config import Config
from py_import_cleaner.scanner import scan_path, scan_paths


@pytest.fixture
def tmp_project(tmp_path: Path) -> Path:
    """Create a temporary project structure."""
    # Create Python files
    (tmp_path / "main.py").write_text("import os\n")
    (tmp_path / "utils.py").write_text("import sys\n")

    # Create subdirectory with Python files
    sub = tmp_path / "subpkg"
    sub.mkdir()
    (sub / "__init__.py").write_text("")
    (sub / "module.py").write_text("import json\n")

    # Create excluded directories
    venv = tmp_path / ".venv"
    venv.mkdir()
    (venv / "activate.py").write_text("import venv\n")

    pycache = tmp_path / "__pycache__"
    pycache.mkdir()
    (pycache / "main.cpython-311.pyc").write_text("")

    git = tmp_path / ".git"
    git.mkdir()
    (git / "config.py").write_text("")

    # Non-python file
    (tmp_path / "README.md").write_text("# Project\n")

    return tmp_path


class TestScanPath:
    """Test scanning a single path."""

    def test_scan_directory(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_path(tmp_project, config)
        filenames = {f.name for f in files}
        assert "main.py" in filenames
        assert "utils.py" in filenames
        assert "__init__.py" in filenames
        assert "module.py" in filenames

    def test_excludes_venv(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_path(tmp_project, config)
        filenames = {f.name for f in files}
        assert "activate.py" not in filenames

    def test_excludes_pycache(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_path(tmp_project, config)
        for f in files:
            assert "__pycache__" not in f.parts

    def test_excludes_git(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_path(tmp_project, config)
        for f in files:
            assert ".git" not in f.parts

    def test_excludes_custom_dir(self, tmp_project: Path) -> None:
        config = Config(exclude=["subpkg"])
        files = scan_path(tmp_project, config)
        filenames = {f.name for f in files}
        assert "module.py" not in filenames
        assert "__init__.py" not in filenames

    def test_scan_single_file(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_path(tmp_project / "main.py", config)
        assert len(files) == 1
        assert files[0].name == "main.py"

    def test_scan_non_python_file(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_path(tmp_project / "README.md", config)
        assert len(files) == 0

    def test_scan_nonexistent_path(self, tmp_path: Path) -> None:
        config = Config()
        files = scan_path(tmp_path / "nonexistent", config)
        assert len(files) == 0

    def test_include_pattern(self, tmp_project: Path) -> None:
        config = Config(include=["subpkg/**"])
        files = scan_path(tmp_project, config)
        for f in files:
            assert "subpkg" in str(f.relative_to(tmp_project))


class TestScanPaths:
    """Test scanning multiple paths."""

    def test_deduplicate(self, tmp_project: Path) -> None:
        config = Config()
        # Scan same path twice
        files = scan_paths([tmp_project, tmp_project], config)
        # Should be deduplicated
        resolved_files = [f.resolve() for f in files]
        assert len(resolved_files) == len(set(resolved_files))

    def test_multiple_paths(self, tmp_project: Path) -> None:
        config = Config()
        files = scan_paths(
            [tmp_project / "main.py", tmp_project / "utils.py"],
            config,
        )
        assert len(files) == 2
