"""Tests for the config module."""

from __future__ import annotations

from pathlib import Path

import pytest

from py_import_cleaner.config import Config, load_config


@pytest.fixture
def config_dir(tmp_path: Path) -> Path:
    """Create a temporary directory with config files."""
    return tmp_path


class TestConfig:
    """Test Config dataclass."""

    def test_default_config(self) -> None:
        config = Config()
        assert config.exclude == []
        assert config.include == []
        assert config.ignore_modules == []
        assert config.fix is False
        assert config.dry_run is False
        assert config.diff is False
        assert config.verbose is False

    def test_excluded_dirs_includes_defaults(self) -> None:
        config = Config()
        excluded = config.excluded_dirs
        assert ".git" in excluded
        assert ".venv" in excluded
        assert "venv" in excluded
        assert "__pycache__" in excluded
        assert "node_modules" in excluded

    def test_excluded_dirs_includes_custom(self) -> None:
        config = Config(exclude=["my_dir"])
        excluded = config.excluded_dirs
        assert "my_dir" in excluded
        assert ".git" in excluded  # defaults preserved


class TestLoadConfig:
    """Test configuration loading."""

    def test_load_importcleaner_toml(self, config_dir: Path) -> None:
        toml_content = (
            '[tool.importcleaner]\n'
            'exclude = ["tests", "migrations"]\n'
            'ignore_modules = ["typing"]\n'
        )
        (config_dir / ".importcleaner.toml").write_text(toml_content)

        config = load_config(base_dir=config_dir)
        assert "tests" in config.exclude
        assert "migrations" in config.exclude
        assert "typing" in config.ignore_modules

    def test_load_pyproject_toml(self, config_dir: Path) -> None:
        toml_content = (
            '[tool.importcleaner]\n'
            'exclude = ["docs"]\n'
            'ignore_modules = ["typing", "typing_extensions"]\n'
        )
        (config_dir / "pyproject.toml").write_text(toml_content)

        config = load_config(base_dir=config_dir)
        assert "docs" in config.exclude
        assert "typing" in config.ignore_modules
        assert "typing_extensions" in config.ignore_modules

    def test_importcleaner_toml_priority(self, config_dir: Path) -> None:
        """`.importcleaner.toml` should take priority over `pyproject.toml`."""
        (config_dir / ".importcleaner.toml").write_text(
            '[tool.importcleaner]\nexclude = ["from_importcleaner"]\n'
        )
        (config_dir / "pyproject.toml").write_text(
            '[tool.importcleaner]\nexclude = ["from_pyproject"]\n'
        )

        config = load_config(base_dir=config_dir)
        assert "from_importcleaner" in config.exclude
        assert "from_pyproject" not in config.exclude

    def test_load_explicit_config_path(self, config_dir: Path) -> None:
        custom = config_dir / "custom.toml"
        custom.write_text(
            '[tool.importcleaner]\nexclude = ["custom_dir"]\n'
        )

        config = load_config(config_path=str(custom))
        assert "custom_dir" in config.exclude

    def test_missing_config_path(self, config_dir: Path) -> None:
        config = load_config(config_path=str(config_dir / "nonexistent.toml"))
        # Should return default config without error
        assert config.exclude == []

    def test_no_config_files(self, config_dir: Path) -> None:
        config = load_config(base_dir=config_dir)
        assert config.exclude == []
        assert config.ignore_modules == []

    def test_empty_importcleaner_section(self, config_dir: Path) -> None:
        (config_dir / "pyproject.toml").write_text("[tool.other]\nfoo = 'bar'\n")
        config = load_config(base_dir=config_dir)
        # No importcleaner section, should return defaults
        assert config.exclude == []
