"""py-import-cleaner: Detect and remove unused Python imports."""

from __future__ import annotations

__version__ = "1.0.0"

from py_import_cleaner.analyzer import AnalysisResult, ImportInfo, UnusedImport, analyze_file, analyze_source
from py_import_cleaner.config import Config, load_config
from py_import_cleaner.diff import generate_diff, generate_diff_from_source
from py_import_cleaner.fixer import fix_file, fix_file_in_place, fix_source
from py_import_cleaner.scanner import scan_path, scan_paths

__all__ = [
    "AnalysisResult",
    "Config",
    "ImportInfo",
    "UnusedImport",
    "__version__",
    "analyze_file",
    "analyze_source",
    "fix_file",
    "fix_file_in_place",
    "fix_source",
    "generate_diff",
    "generate_diff_from_source",
    "load_config",
    "scan_path",
    "scan_paths",
]
