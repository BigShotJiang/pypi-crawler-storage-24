"""Utility functions for py-import-cleaner."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

logger = logging.getLogger("py_import_cleaner")


def setup_logging(verbose: bool = False) -> None:
    """Configure structured logging for the application."""
    level = logging.DEBUG if verbose else logging.INFO
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(level)
    formatter = logging.Formatter("%(levelname)s: %(message)s")
    handler.setFormatter(formatter)

    root_logger = logging.getLogger("py_import_cleaner")
    root_logger.setLevel(level)
    root_logger.handlers.clear()
    root_logger.addHandler(handler)


def is_python_file(path: Path) -> bool:
    """Check if a path is a Python file."""
    return path.is_file() and path.suffix == ".py"


def read_file_content(path: Path) -> str:
    """Read and return file contents as a string."""
    return path.read_text(encoding="utf-8")


def write_file_content(path: Path, content: str) -> None:
    """Write content to a file."""
    path.write_text(content, encoding="utf-8")
