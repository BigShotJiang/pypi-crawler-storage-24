"""Configuration loading for py-import-cleaner."""

from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib  # type: ignore[import-not-found]
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]

logger = logging.getLogger("py_import_cleaner")

CONFIG_FILENAMES = [".importcleaner.toml", "pyproject.toml"]

DEFAULT_EXCLUDE_DIRS = frozenset({
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    "dist",
    "build",
    "*.egg-info",
})


@dataclass
class Config:
    """Configuration for the import cleaner."""

    exclude: list[str] = field(default_factory=list)
    include: list[str] = field(default_factory=list)
    ignore_modules: list[str] = field(default_factory=list)
    fix: bool = False
    dry_run: bool = False
    diff: bool = False
    verbose: bool = False

    @property
    def excluded_dirs(self) -> frozenset[str]:
        """Return all directories to exclude (defaults + user-defined)."""
        return DEFAULT_EXCLUDE_DIRS | frozenset(self.exclude)


def _load_toml(path: Path) -> dict[str, Any]:
    """Load a TOML file and return its contents."""
    with open(path, "rb") as f:
        return tomllib.load(f)


def _extract_config_section(data: dict[str, Any], filepath: Path) -> dict[str, Any]:
    """Extract the importcleaner config section from parsed TOML data."""
    if filepath.name == "pyproject.toml":
        tool = data.get("tool", {})
        return tool.get("importcleaner", {})
    return data.get("tool", {}).get("importcleaner", data)


def load_config(config_path: str | None = None, base_dir: Path | None = None) -> Config:
    """Load configuration from a file.

    Searches for config in the following order:
    1. Explicit config_path if provided
    2. .importcleaner.toml in base_dir
    3. pyproject.toml in base_dir
    """
    if base_dir is None:
        base_dir = Path.cwd()

    config = Config()

    if config_path:
        path = Path(config_path)
        if path.exists():
            try:
                data = _load_toml(path)
                section = _extract_config_section(data, path)
                config = _apply_config_section(config, section)
                logger.debug("Loaded config from %s", path)
            except Exception as e:
                logger.error("Failed to load config from %s: %s", path, e)
        else:
            logger.error("Config file not found: %s", path)
        return config

    for filename in CONFIG_FILENAMES:
        path = base_dir / filename
        if path.exists():
            try:
                data = _load_toml(path)
                section = _extract_config_section(data, path)
                if section:
                    config = _apply_config_section(config, section)
                    logger.debug("Loaded config from %s", path)
                    break
            except Exception as e:
                logger.debug("Failed to load %s: %s", path, e)

    return config


def _apply_config_section(config: Config, section: dict[str, Any]) -> Config:
    """Apply a config section dictionary onto a Config object."""
    if "exclude" in section:
        config.exclude = list(section["exclude"])
    if "include" in section:
        config.include = list(section["include"])
    if "ignore_modules" in section:
        config.ignore_modules = list(section["ignore_modules"])
    return config
