"""AST-based unused import detection for py-import-cleaner."""

from __future__ import annotations

import ast
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Union

from py_import_cleaner.utils import read_file_content

logger = logging.getLogger("py_import_cleaner")


@dataclass
class ImportInfo:
    """Represents a single imported name."""

    module: str
    name: str  # The imported name or module name
    alias: str | None  # The alias if 'as' was used
    lineno: int
    col_offset: int
    end_lineno: int | None
    is_from_import: bool  # True for 'from X import Y'
    node: ast.Import | ast.ImportFrom  # Reference to the AST node
    is_star: bool = False  # True for 'from X import *'

    @property
    def local_name(self) -> str:
        """The name as it appears in local scope."""
        if self.alias:
            return self.alias
        if self.is_from_import:
            return self.name
        # For 'import a.b.c', only 'a' is bound in local scope
        return self.name.split(".")[0]


@dataclass
class UnusedImport:
    """Represents an unused import finding."""

    filepath: Path
    module: str
    name: str
    alias: str | None
    lineno: int
    is_from_import: bool
    import_info: ImportInfo

    def __str__(self) -> str:
        if self.is_from_import:
            imported = f"{self.name}" if not self.alias else f"{self.name} as {self.alias}"
            return f"from {self.module} import {imported}"
        if self.alias:
            return f"import {self.name} as {self.alias}"
        return f"import {self.name}"


@dataclass
class AnalysisResult:
    """Result of analyzing a single file."""

    filepath: Path
    unused_imports: list[UnusedImport] = field(default_factory=list)
    all_imports: list[ImportInfo] = field(default_factory=list)
    error: str | None = None

    @property
    def has_unused(self) -> bool:
        return len(self.unused_imports) > 0


class _NameCollector(ast.NodeVisitor):
    """Collects all name references in a module, excluding import statements."""

    def __init__(self) -> None:
        self.used_names: set[str] = set()
        self.dunder_all: list[str] | None = None
        self._import_nodes: set[int] = set()

    def visit_Name(self, node: ast.Name) -> None:
        # Only track names that aren't part of import statements
        if id(node) not in self._import_nodes:
            self.used_names.add(node.id)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        # For attribute access like os.path, we need to track 'os'
        root = _get_attribute_root(node)
        if root:
            self.used_names.add(root)
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        # Check for __all__ assignment
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == "__all__":
                self.dunder_all = _extract_all_names(node.value)
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        # Handle __all__ += [...]
        if isinstance(node.target, ast.Name) and node.target.id == "__all__":
            extra = _extract_all_names(node.value)
            if extra is not None:
                if self.dunder_all is None:
                    self.dunder_all = extra
                else:
                    self.dunder_all.extend(extra)
        self.generic_visit(node)


def _get_attribute_root(node: ast.Attribute) -> str | None:
    """Get the root name of an attribute chain (e.g., 'os' from 'os.path.join')."""
    current: ast.expr = node
    while isinstance(current, ast.Attribute):
        current = current.value
    if isinstance(current, ast.Name):
        return current.id
    return None


def _extract_all_names(node: ast.expr) -> list[str] | None:
    """Extract string values from a list/tuple literal used in __all__."""
    if isinstance(node, (ast.List, ast.Tuple)):
        names: list[str] = []
        for elt in node.elts:
            if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                names.append(elt.value)
        return names
    return None


def _is_in_try_except_import_error(node: ast.AST, tree: ast.Module) -> bool:
    """Check if an import node is inside a try/except ImportError block."""
    for top_node in ast.walk(tree):
        if isinstance(top_node, ast.Try):
            # Check if any handler catches ImportError or ModuleNotFoundError
            has_import_error_handler = False
            for handler in top_node.handlers:
                if handler.type is None:
                    # Bare except catches everything
                    has_import_error_handler = True
                    break
                handler_names = _get_exception_names(handler.type)
                if handler_names & {"ImportError", "ModuleNotFoundError"}:
                    has_import_error_handler = True
                    break

            if has_import_error_handler:
                # Check if the import node is in the try body
                for child in ast.walk(top_node):
                    if child is node:
                        return True
    return False


def _get_exception_names(node: ast.expr) -> set[str]:
    """Extract exception class names from an except handler type."""
    names: set[str] = set()
    if isinstance(node, ast.Name):
        names.add(node.id)
    elif isinstance(node, ast.Tuple):
        for elt in node.elts:
            if isinstance(elt, ast.Name):
                names.add(elt.id)
    return names


def _extract_imports(tree: ast.Module) -> list[ImportInfo]:
    """Extract all import information from an AST tree."""
    imports: list[ImportInfo] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(
                    ImportInfo(
                        module=alias.name,
                        name=alias.name,
                        alias=alias.asname,
                        lineno=node.lineno,
                        col_offset=node.col_offset,
                        end_lineno=node.end_lineno,
                        is_from_import=False,
                        node=node,
                    )
                )
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            for alias in node.names:
                is_star = alias.name == "*"
                imports.append(
                    ImportInfo(
                        module=module,
                        name=alias.name,
                        alias=alias.asname,
                        lineno=node.lineno,
                        col_offset=node.col_offset,
                        end_lineno=node.end_lineno,
                        is_from_import=True,
                        node=node,
                        is_star=is_star,
                    )
                )

    return imports


def analyze_file(
    filepath: Path,
    ignore_modules: list[str] | None = None,
) -> AnalysisResult:
    """Analyze a Python file for unused imports.

    Args:
        filepath: Path to the Python file to analyze.
        ignore_modules: List of module names to ignore (never report as unused).

    Returns:
        An AnalysisResult containing any unused imports found.
    """
    ignore_modules = ignore_modules or []
    result = AnalysisResult(filepath=filepath)

    try:
        source = read_file_content(filepath)
    except Exception as e:
        result.error = f"Failed to read file: {e}"
        logger.error("Failed to read %s: %s", filepath, e)
        return result

    try:
        tree = ast.parse(source, filename=str(filepath))
    except SyntaxError as e:
        result.error = f"Syntax error: {e}"
        logger.error("Syntax error in %s: %s", filepath, e)
        return result

    # Extract all imports
    all_imports = _extract_imports(tree)
    result.all_imports = all_imports

    # Collect all used names
    collector = _NameCollector()
    collector.visit(tree)
    used_names = collector.used_names
    dunder_all = collector.dunder_all

    # Determine unused imports
    for imp in all_imports:
        # Skip star imports — can't reliably determine if used
        if imp.is_star:
            continue

        # Skip ignored modules
        if imp.module in ignore_modules or imp.name in ignore_modules:
            continue

        # Skip imports inside try/except ImportError
        if _is_in_try_except_import_error(imp.node, tree):
            continue

        # Check if the import's local name is used
        local_name = imp.local_name
        is_used = local_name in used_names

        # Check if it's in __all__
        if dunder_all is not None:
            if imp.name in dunder_all or (imp.alias and imp.alias in dunder_all):
                is_used = True

        if not is_used:
            result.unused_imports.append(
                UnusedImport(
                    filepath=filepath,
                    module=imp.module,
                    name=imp.name,
                    alias=imp.alias,
                    lineno=imp.lineno,
                    is_from_import=imp.is_from_import,
                    import_info=imp,
                )
            )

    return result


def analyze_source(
    source: str,
    filename: str = "<string>",
    ignore_modules: list[str] | None = None,
) -> AnalysisResult:
    """Analyze Python source code string for unused imports.

    This is useful for testing and library usage without file I/O.
    """
    ignore_modules = ignore_modules or []
    filepath = Path(filename)
    result = AnalysisResult(filepath=filepath)

    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError as e:
        result.error = f"Syntax error: {e}"
        return result

    all_imports = _extract_imports(tree)
    result.all_imports = all_imports

    collector = _NameCollector()
    collector.visit(tree)
    used_names = collector.used_names
    dunder_all = collector.dunder_all

    for imp in all_imports:
        if imp.is_star:
            continue
        if imp.module in ignore_modules or imp.name in ignore_modules:
            continue
        if _is_in_try_except_import_error(imp.node, tree):
            continue

        local_name = imp.local_name
        is_used = local_name in used_names

        if dunder_all is not None:
            if imp.name in dunder_all or (imp.alias and imp.alias in dunder_all):
                is_used = True

        if not is_used:
            result.unused_imports.append(
                UnusedImport(
                    filepath=filepath,
                    module=imp.module,
                    name=imp.name,
                    alias=imp.alias,
                    lineno=imp.lineno,
                    is_from_import=imp.is_from_import,
                    import_info=imp,
                )
            )

    return result
