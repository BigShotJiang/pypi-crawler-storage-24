"""Safe removal of unused imports for py-import-cleaner."""

from __future__ import annotations

import ast
import logging
import re
from pathlib import Path

from py_import_cleaner.analyzer import AnalysisResult, ImportInfo, UnusedImport
from py_import_cleaner.utils import read_file_content, write_file_content

logger = logging.getLogger("py_import_cleaner")


def fix_file(filepath: Path, result: AnalysisResult) -> str:
    """Remove unused imports from a file and return the fixed source.

    Args:
        filepath: Path to the Python file.
        result: Analysis result containing unused imports.

    Returns:
        The fixed source code as a string.
    """
    if not result.has_unused:
        return read_file_content(filepath)

    source = read_file_content(filepath)
    return fix_source(source, result)


def fix_source(source: str, result: AnalysisResult) -> str:
    """Remove unused imports from source code.

    Args:
        source: The original source code.
        result: Analysis result containing unused imports.

    Returns:
        The fixed source code.
    """
    if not result.has_unused:
        return source

    lines = source.splitlines(keepends=True)

    # Group unused imports by their AST node (line number + type)
    # Multiple names can be imported on one line: from X import a, b, c
    unused_by_line: dict[int, list[UnusedImport]] = {}
    for unused in result.unused_imports:
        lineno = unused.lineno
        if lineno not in unused_by_line:
            unused_by_line[lineno] = []
        unused_by_line[lineno].append(unused)

    # Also build a lookup of all imports by line for multi-name handling
    all_imports_by_line: dict[int, list[ImportInfo]] = {}
    for imp in result.all_imports:
        if imp.lineno not in all_imports_by_line:
            all_imports_by_line[imp.lineno] = []
        all_imports_by_line[imp.lineno].append(imp)

    lines_to_remove: set[int] = set()
    line_replacements: dict[int, str] = {}

    for lineno, unused_list in unused_by_line.items():
        all_imports_on_line = all_imports_by_line.get(lineno, [])
        unused_names = {u.import_info.name for u in unused_list}

        if not all_imports_on_line:
            continue

        first_import = all_imports_on_line[0]

        # Check if ALL imports on this line/statement are unused
        all_unused = all(imp.name in unused_names or imp.is_star for imp in all_imports_on_line)

        if all_unused:
            # Remove the entire line(s)
            start_line = lineno
            end_line = first_import.end_lineno or lineno
            for ln in range(start_line, end_line + 1):
                lines_to_remove.add(ln)
        elif first_import.is_from_import:
            # Partial removal: only some names from 'from X import a, b, c'
            _handle_partial_from_import(
                lines, lineno, first_import, unused_names, line_replacements, lines_to_remove
            )
        else:
            # For 'import a, b, c' (rare but valid)
            _handle_partial_import(
                lines, lineno, first_import, unused_names, line_replacements, lines_to_remove
            )

    # Apply changes
    new_lines: list[str] = []
    for i, line in enumerate(lines):
        lineno = i + 1  # 1-based
        if lineno in lines_to_remove:
            continue
        if lineno in line_replacements:
            replacement = line_replacements[lineno]
            if replacement:
                new_lines.append(replacement)
        else:
            new_lines.append(line)

    result_source = "".join(new_lines)

    # Clean up excessive blank lines (more than 2 consecutive)
    result_source = re.sub(r"\n{3,}", "\n\n", result_source)

    return result_source


def fix_file_in_place(filepath: Path, result: AnalysisResult) -> bool:
    """Fix a file in place by removing unused imports.

    Args:
        filepath: Path to the Python file.
        result: Analysis result containing unused imports.

    Returns:
        True if the file was modified, False otherwise.
    """
    if not result.has_unused:
        return False

    fixed_source = fix_file(filepath, result)
    original_source = read_file_content(filepath)

    if fixed_source != original_source:
        write_file_content(filepath, fixed_source)
        logger.info("Fixed %s: removed %d unused import(s)", filepath, len(result.unused_imports))
        return True

    return False


def _handle_partial_from_import(
    lines: list[str],
    lineno: int,
    first_import: ImportInfo,
    unused_names: set[str],
    line_replacements: dict[int, str],
    lines_to_remove: set[int],
) -> None:
    """Handle partial removal of names from a 'from X import a, b, c' statement."""
    # Reconstruct the full import statement text from potentially multi-line source
    end_lineno = first_import.end_lineno or lineno
    stmt_lines = lines[lineno - 1 : end_lineno]
    full_stmt = "".join(stmt_lines)

    # Parse to get all imported names on this statement
    try:
        mini_tree = ast.parse(full_stmt.strip())
    except SyntaxError:
        logger.debug("Cannot parse import statement at line %d, skipping partial fix", lineno)
        return

    if not mini_tree.body or not isinstance(mini_tree.body[0], ast.ImportFrom):
        return

    import_node = mini_tree.body[0]
    kept_aliases: list[ast.alias] = []
    for alias in import_node.names:
        if alias.name not in unused_names:
            kept_aliases.append(alias)

    if not kept_aliases:
        # All removed — remove the whole statement
        for ln in range(lineno, end_lineno + 1):
            lines_to_remove.add(ln)
        return

    # Rebuild the import line
    module = import_node.module or ""
    imports_str = ", ".join(
        f"{a.name} as {a.asname}" if a.asname else a.name for a in kept_aliases
    )

    # Detect indentation from original line
    original_line = lines[lineno - 1]
    indent = original_line[: len(original_line) - len(original_line.lstrip())]

    new_line = f"{indent}from {module} import {imports_str}\n"

    # Mark all original lines for this statement
    line_replacements[lineno] = new_line
    for ln in range(lineno + 1, end_lineno + 1):
        lines_to_remove.add(ln)


def _handle_partial_import(
    lines: list[str],
    lineno: int,
    first_import: ImportInfo,
    unused_names: set[str],
    line_replacements: dict[int, str],
    lines_to_remove: set[int],
) -> None:
    """Handle partial removal of names from 'import a, b, c' statement."""
    end_lineno = first_import.end_lineno or lineno
    stmt_lines = lines[lineno - 1 : end_lineno]
    full_stmt = "".join(stmt_lines)

    try:
        mini_tree = ast.parse(full_stmt.strip())
    except SyntaxError:
        return

    if not mini_tree.body or not isinstance(mini_tree.body[0], ast.Import):
        return

    import_node = mini_tree.body[0]
    kept_aliases: list[ast.alias] = []
    for alias in import_node.names:
        if alias.name not in unused_names:
            kept_aliases.append(alias)

    if not kept_aliases:
        for ln in range(lineno, end_lineno + 1):
            lines_to_remove.add(ln)
        return

    imports_str = ", ".join(
        f"{a.name} as {a.asname}" if a.asname else a.name for a in kept_aliases
    )

    original_line = lines[lineno - 1]
    indent = original_line[: len(original_line) - len(original_line.lstrip())]

    new_line = f"{indent}import {imports_str}\n"

    line_replacements[lineno] = new_line
    for ln in range(lineno + 1, end_lineno + 1):
        lines_to_remove.add(ln)
