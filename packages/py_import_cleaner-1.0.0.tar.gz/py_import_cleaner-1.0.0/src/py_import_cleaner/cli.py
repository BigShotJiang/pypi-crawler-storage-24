"""CLI interface for py-import-cleaner."""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from py_import_cleaner.analyzer import AnalysisResult, analyze_file
from py_import_cleaner.config import Config, load_config
from py_import_cleaner.diff import generate_diff
from py_import_cleaner.fixer import fix_file_in_place
from py_import_cleaner.scanner import scan_paths
from py_import_cleaner.utils import setup_logging

console = Console()
error_console = Console(stderr=True)


@click.command(
    name="py-import-cleaner",
    help="Detect and remove unused Python imports.",
)
@click.argument("paths", nargs=-1, type=click.Path(exists=True))
@click.option("--fix", is_flag=True, default=False, help="Remove unused imports.")
@click.option("--dry-run", is_flag=True, default=False, help="Show results without changes.")
@click.option("--diff", is_flag=True, default=False, help="Show file diff of proposed changes.")
@click.option("--verbose", is_flag=True, default=False, help="Detailed logging.")
@click.option("--exclude", multiple=True, help="Exclude directories or patterns.")
@click.option("--include", multiple=True, help="Only scan selected paths or patterns.")
@click.option("--config", "config_path", default=None, help="Path to config file.")
def main(
    paths: tuple[str, ...],
    fix: bool,
    dry_run: bool,
    diff: bool,
    verbose: bool,
    exclude: tuple[str, ...],
    include: tuple[str, ...],
    config_path: str | None,
) -> None:
    """Detect and remove unused Python imports."""
    setup_logging(verbose=verbose)

    # Default to current directory if no paths specified
    if not paths:
        paths = (".",)

    # Load configuration
    base_dir = Path(paths[0]).resolve() if paths else Path.cwd()
    if base_dir.is_file():
        base_dir = base_dir.parent
    cfg = load_config(config_path=config_path, base_dir=base_dir)

    # Merge CLI options into config
    cfg.fix = fix
    cfg.dry_run = dry_run
    cfg.diff = diff
    cfg.verbose = verbose
    if exclude:
        cfg.exclude.extend(exclude)
    if include:
        cfg.include.extend(include)

    # Scan for Python files
    path_objects = [Path(p) for p in paths]
    files = scan_paths(path_objects, cfg)

    if not files:
        console.print("[yellow]No Python files found.[/yellow]")
        sys.exit(0)

    if verbose:
        console.print(f"[dim]Scanning {len(files)} file(s)...[/dim]")

    # Analyze each file
    results: list[AnalysisResult] = []
    for filepath in files:
        result = analyze_file(filepath, ignore_modules=cfg.ignore_modules)
        if result.has_unused:
            results.append(result)

    total_unused = sum(len(r.unused_imports) for r in results)

    if total_unused == 0:
        console.print("[green]No unused imports found.[/green]")
        sys.exit(0)

    # Display results
    console.print(f"\n[bold]{total_unused} unused import(s) found[/bold]\n")

    for result in results:
        _display_result(result, cfg)

    # Apply fixes if requested
    if fix and not dry_run:
        fixed_count = 0
        for result in results:
            if fix_file_in_place(result.filepath, result):
                fixed_count += 1
        console.print(f"\n[green]Fixed {fixed_count} file(s).[/green]")
    elif not fix and not diff:
        console.print("\n[dim]Run with --fix to remove them[/dim]")

    # Exit with non-zero code if unused imports found (useful for CI)
    if not fix:
        sys.exit(1)


def _display_result(result: AnalysisResult, cfg: Config) -> None:
    """Display analysis result for a single file."""
    rel_path = _get_relative_path(result.filepath)
    console.print(f"[bold cyan]{rel_path}[/bold cyan]")

    for unused in result.unused_imports:
        console.print(f"  [yellow]line {unused.lineno}[/yellow]: {unused}")

    if cfg.diff:
        diff_text = generate_diff(result.filepath, result)
        if diff_text:
            console.print()
            for line in diff_text.splitlines():
                if line.startswith("+") and not line.startswith("+++"):
                    console.print(f"  [green]{line}[/green]")
                elif line.startswith("-") and not line.startswith("---"):
                    console.print(f"  [red]{line}[/red]")
                elif line.startswith("@@"):
                    console.print(f"  [cyan]{line}[/cyan]")
                else:
                    console.print(f"  {line}")

    console.print()


def _get_relative_path(filepath: Path) -> str:
    """Get a relative path from CWD for display purposes."""
    try:
        return str(filepath.relative_to(Path.cwd()))
    except ValueError:
        return str(filepath)


if __name__ == "__main__":
    main()
