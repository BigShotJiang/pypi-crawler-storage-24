"""Directory traversal and file discovery for py-import-cleaner."""

from __future__ import annotations

import fnmatch
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Callable

from py_import_cleaner.config import Config

logger = logging.getLogger("py_import_cleaner")


def _should_skip_dir(dirname: str, excluded_dirs: frozenset[str]) -> bool:
    """Check if a directory should be skipped based on exclusion rules."""
    for pattern in excluded_dirs:
        if fnmatch.fnmatch(dirname, pattern):
            return True
    return dirname.startswith(".")


def scan_path(path: Path, config: Config) -> list[Path]:
    """Scan a path for Python files, respecting exclusion rules.

    Args:
        path: The root path to scan (file or directory).
        config: Configuration with exclusion/inclusion rules.

    Returns:
        A list of Path objects pointing to Python files.
    """
    excluded_dirs = config.excluded_dirs

    if path.is_file():
        if path.suffix == ".py":
            return [path]
        return []

    if not path.is_dir():
        logger.error("Path does not exist: %s", path)
        return []

    python_files: list[Path] = []

    for item in sorted(path.rglob("*.py")):
        # Check if any parent directory should be excluded
        relative = item.relative_to(path)
        skip = False
        for part in relative.parts[:-1]:  # Exclude the filename itself
            if _should_skip_dir(part, excluded_dirs):
                skip = True
                break
        if skip:
            continue

        # If include patterns are specified, check them
        if config.include:
            matched = False
            for inc_pattern in config.include:
                if fnmatch.fnmatch(str(relative), inc_pattern) or fnmatch.fnmatch(
                    str(item), inc_pattern
                ):
                    matched = True
                    break
            if not matched:
                continue

        python_files.append(item)

    logger.debug("Found %d Python files in %s", len(python_files), path)
    return python_files


def scan_paths(paths: list[Path], config: Config) -> list[Path]:
    """Scan multiple paths for Python files.

    Args:
        paths: List of root paths to scan.
        config: Configuration with exclusion/inclusion rules.

    Returns:
        A deduplicated list of Path objects pointing to Python files.
    """
    seen: set[Path] = set()
    result: list[Path] = []
    for p in paths:
        for f in scan_path(p, config):
            resolved = f.resolve()
            if resolved not in seen:
                seen.add(resolved)
                result.append(f)
    return result


def process_files_parallel(
    files: list[Path],
    processor: Callable[[Path], object],
    max_workers: int | None = None,
) -> list[object]:
    """Process files in parallel using ProcessPoolExecutor.

    Args:
        files: List of file paths to process.
        processor: A callable that processes a single file.
        max_workers: Maximum number of worker processes.

    Returns:
        List of results from processing each file.
    """
    if len(files) <= 1:
        return [processor(f) for f in files]

    results: list[object] = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        future_to_file = {executor.submit(processor, f): f for f in files}
        for future in as_completed(future_to_file):
            filepath = future_to_file[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                logger.error("Error processing %s: %s", filepath, e)
    return results
