"""Diff preview generation for py-import-cleaner."""

from __future__ import annotations

import difflib
from pathlib import Path

from py_import_cleaner.analyzer import AnalysisResult
from py_import_cleaner.fixer import fix_source
from py_import_cleaner.utils import read_file_content


def generate_diff(filepath: Path, result: AnalysisResult) -> str:
    """Generate a unified diff showing proposed import removals.

    Args:
        filepath: Path to the Python file.
        result: Analysis result containing unused imports.

    Returns:
        A string containing the unified diff, or empty string if no changes.
    """
    if not result.has_unused:
        return ""

    original = read_file_content(filepath)
    fixed = fix_source(original, result)

    if original == fixed:
        return ""

    original_lines = original.splitlines(keepends=True)
    fixed_lines = fixed.splitlines(keepends=True)

    diff = difflib.unified_diff(
        original_lines,
        fixed_lines,
        fromfile=str(filepath),
        tofile=str(filepath),
    )

    return "".join(diff)


def generate_diff_from_source(
    source: str,
    result: AnalysisResult,
    filename: str = "<string>",
) -> str:
    """Generate a unified diff from source code string.

    Args:
        source: The original source code.
        result: Analysis result containing unused imports.
        filename: Display name for the diff header.

    Returns:
        A string containing the unified diff.
    """
    if not result.has_unused:
        return ""

    fixed = fix_source(source, result)

    if source == fixed:
        return ""

    original_lines = source.splitlines(keepends=True)
    fixed_lines = fixed.splitlines(keepends=True)

    diff = difflib.unified_diff(
        original_lines,
        fixed_lines,
        fromfile=filename,
        tofile=filename,
    )

    return "".join(diff)
