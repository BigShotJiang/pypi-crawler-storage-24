# tasks/scheduler.py

import json
import logging
import time
import datetime
import threading
from datetime import timezone
from typing import Optional

from sqlalchemy import select
from fastpluggy.core.database import session_scope
from loguru import logger

from .. import TaskWorker
from ..persistence.models.scheduled import ScheduledTaskDB


def schedule_loop(shutdown_event: Optional[threading.Event] = None, **_kwargs):
    """
    Main scheduling loop.  On each tick, it:
      1. Loads all enabled ScheduledTaskDB records.
      2. For each task, computes expected_next_run (based on last_attempt).
      3. If expected_next_run is not None AND now >= expected_next_run, dispatch the task:
         a. Update last_attempt = now.
         b. Submit the task to the worker.
         c. Record last_task_id.
      4. Sleep for scheduler_frequency seconds and repeat.

    Args:
        shutdown_event: Optional threading.Event to signal graceful shutdown.
                        When set, the loop exits after the current tick.
    """
    from ..config import TasksRunnerSettings

    settings = TasksRunnerSettings()
    logging.info("[SCHEDULER] Starting schedule loop")

    def _should_stop() -> bool:
        return shutdown_event is not None and shutdown_event.is_set()

    while not _should_stop():
        logging.debug("[SCHEDULER] Schedule loop running")

        now_utc = datetime.datetime.now(timezone.utc)
        try:
            with session_scope() as db:
                # 1) Fetch all enabled tasks from the database
                stmt = select(ScheduledTaskDB).where(ScheduledTaskDB.enabled == True)
                all_tasks = db.execute(stmt).scalars().all()

                if not all_tasks:
                    logger.debug("[SCHEDULER] No enabled tasks in DB.")
                else:
                    # 2) Iterate over each scheduled task
                    for sched in all_tasks:
                        try:
                            should_run = sched.is_late
                            logging.debug(f"[SCHEDULER] {sched.name}: is_late={should_run} last_attempt={sched.last_attempt} next={sched.expected_next_run}")

                            # 3) If now >= expected_next_run, we should fire this task
                            if should_run:
                                # a) Mark last_attempt = now_utc and persist
                                sched.last_attempt = now_utc
                                db.add(sched)
                                db.commit()

                                # b) Lookup the function by name
                                from ..registry.registry import task_registry
                                func = task_registry.get(sched.function)
                                if not func:
                                    logger.warning(
                                        f"[SCHEDULER] Function not found: {sched.function}"
                                    )
                                    continue

                                logger.info(f"[SCHEDULER] Triggering task: {sched.name}")

                                # c) Parse kwargs JSON
                                try:
                                    kw = json.loads(sched.kwargs or "{}")
                                except Exception as parse_err:
                                    logger.exception(
                                        f"[SCHEDULER] Invalid kwargs for {sched.name}: {parse_err}"
                                    )
                                    continue

                                # d) Submit the task to the worker
                                task_id = TaskWorker.submit(
                                    func,
                                    task_name=sched.name,
                                    task_origin="scheduler",
                                    kwargs=kw,
                                    topic=sched.topic,
                                    extra_context={"schedule_id": sched.id}
                                )

                                # e) Record last_task_id and commit
                                sched.last_task_id = task_id
                                db.add(sched)
                                db.commit()

                        except Exception as task_error:
                            logger.exception(
                                f"[SCHEDULER] Error scheduling task '{sched.name}': {task_error}"
                            )
                            db.rollback()

        except Exception as e:
            logger.exception(f"[SCHEDULER] Error in main scheduling loop: {e}")

        # 4) Sleep until next tick (interruptible via shutdown_event)
        if shutdown_event is not None:
            shutdown_event.wait(settings.scheduler_frequency)
        else:
            time.sleep(settings.scheduler_frequency)
