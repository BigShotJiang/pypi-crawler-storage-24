import logging
import threading
from collections import deque
from typing import Optional

log = logging.getLogger("ExecutorManager")


class ExecutorManager:
    """
    Minimal control-plane:
      - If topics contains '*' or is empty, enable wildcard mode
      - Periodically polls broker.get_topics() and auto-adds new topics (wildcard only)
      - Always syncs broker TopicConfig.concurrency_limit into executor semaphores (C2)
      - Optional autoscaling: adjusts executor pool capacity based on utilisation ratio
    """

    def __init__(self, *, broker, executor, topics, interval: float = 3.0,
                 autoscale_cfg=None, capacity_setter=None):
        self.broker = broker
        self.executor = executor
        self.interval = float(interval)

        # Detect wildcard behavior internally
        try:
            raw_topics = list(topics) if topics else []
            self.wildcard_enabled = (not raw_topics) or ("*" in raw_topics)
        except Exception:
            self.wildcard_enabled = True

        self._stop = threading.Event()
        self._thr: Optional[threading.Thread] = None

        # Autoscaling
        self._autoscale_cfg = autoscale_cfg
        self._capacity_setter = capacity_setter  # callback(new_capacity) -> None
        self._utilisation_history: deque = deque(maxlen=autoscale_cfg.autoscale_window if autoscale_cfg else 5)

    def start(self) -> None:
        # Always sync limits once at startup so broker-configured limits take effect immediately
        self._sync_topic_limits()

        if not self.wildcard_enabled and not self._autoscale_enabled:
            log.info("[TaskManager] wildcard not enabled; watcher not started (limits synced)")
            return
        if self._thr and self._thr.is_alive():
            return
        self._stop.clear()
        self._thr = threading.Thread(target=self._loop, name="manager:topic-watcher", daemon=True)
        self._thr.start()
        log.info("[TaskManager] topic watcher started (autoscale=%s)", self._autoscale_enabled)

    def stop(self) -> None:
        self._stop.set()
        if self._thr and self._thr.is_alive():
            self._thr.join(timeout=2.0)
        self._thr = None
        log.info("[TaskManager] stopped")

    @property
    def _autoscale_enabled(self) -> bool:
        return bool(self._autoscale_cfg and self._autoscale_cfg.autoscale_enabled)

    # --- internals ---
    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                if self.wildcard_enabled:
                    topics = self._safe_get_topics()
                    for t in topics:
                        self.executor.add_topic(t)
                self._sync_topic_limits()
                if self._autoscale_enabled:
                    self._autoscale_tick()
            except Exception as e:
                log.debug("[TaskManager] loop error: %s", e, exc_info=False)
            self._stop.wait(self.interval)

    def _autoscale_tick(self) -> None:
        """Evaluate utilisation and scale capacity if trend is sustained."""
        cfg = self._autoscale_cfg
        stats = self.executor.get_pool_stats()
        capacity = stats.get("max_workers", 1)
        running = stats.get("running_tasks", 0)

        if capacity <= 0:
            return

        ratio = running / capacity
        self._utilisation_history.append(ratio)

        window = cfg.autoscale_window
        if len(self._utilisation_history) < window:
            return  # not enough data yet

        recent = list(self._utilisation_history)[-window:]

        # Scale up: all recent ticks above threshold
        if all(r >= cfg.autoscale_scale_up_threshold for r in recent):
            new_cap = min(capacity + cfg.autoscale_scale_step, cfg.autoscale_max_capacity)
            if new_cap > capacity:
                log.info("[Autoscale] scaling UP: %d -> %d (ratio=%.2f)", capacity, new_cap, ratio)
                self._apply_capacity(new_cap)
                self._utilisation_history.clear()
            return

        # Scale down: all recent ticks below threshold
        if all(r <= cfg.autoscale_scale_down_threshold for r in recent):
            new_cap = max(capacity - cfg.autoscale_scale_step, cfg.autoscale_min_capacity)
            if new_cap < capacity:
                log.info("[Autoscale] scaling DOWN: %d -> %d (ratio=%.2f)", capacity, new_cap, ratio)
                self._apply_capacity(new_cap)
                self._utilisation_history.clear()

    def _apply_capacity(self, new_capacity: int) -> None:
        """Update executor max_workers and notify the runner (for heartbeat)."""
        self.executor.max_workers = new_capacity
        if self._capacity_setter:
            try:
                self._capacity_setter(new_capacity)
            except Exception as e:
                log.debug("[Autoscale] capacity_setter error: %s", e, exc_info=False)

    def _sync_topic_limits(self) -> None:
        """Push broker TopicConfig.concurrency_limit into the executor's semaphores.

        Called at startup and on every loop iteration so that admin changes
        to per-topic limits take effect without restarting the worker.
        """
        try:
            configs = self.broker.get_all_topic_configs()
        except Exception:
            return
        for topic, cfg in configs.items():
            try:
                self.executor.set_topic_limit(topic, cfg.concurrency_limit)
            except Exception as e:
                log.debug(
                    "[TaskManager] limit sync error for %r: %s", topic, e, exc_info=False
                )

    def _safe_get_topics(self) -> list[str]:
        try:
            infos = self.broker.get_topics() or []
            return [
                str(getattr(item, "topic", None) or (item.get("topic") if isinstance(item, dict) else ""))
                for item in infos
                if (getattr(item, "topic", None) or (isinstance(item, dict) and item.get("topic")))
            ]
        except Exception:
            return []
