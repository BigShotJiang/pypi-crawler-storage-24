# broker/rabbitmq.py
"""
RabbitMQ broker backend.
- Uses RabbitMQ as the message queue backend
- Supports distributed worker scenarios across multiple processes/hosts
- Provides persistence and reliability through RabbitMQ
- Compatible with the Broker contracts used by TaskRunner

Intended use:
    BROKER_TYPE=rabbitmq
    BROKER_DSN=amqp://guest:guest@localhost:5672/

Features:
- Message persistence via RabbitMQ queues
- Worker registration and heartbeat tracking in separate exchange
- Topic configuration and concurrency limits
- Dead-letter queue support
- Distributed locking via RabbitMQ
"""
import json
import logging
import queue as stdlib_queue
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Callable, TypeVar

T = TypeVar("T")

try:
    import pika
    from pika.exceptions import AMQPError, AMQPConnectionError
except ImportError:
    pika = None
    AMQPError = Exception
    AMQPConnectionError = Exception

def retry_on_connection_error(func: Callable[..., T]) -> Callable[..., T]:
    """Decorator to retry broker operations on connection or channel errors."""
    import functools
    @functools.wraps(func)
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except (AMQPError) as e:
            log.warning(f"RabbitMQ error in {func.__name__}: {e}. Retrying after reconnection...")
            # We must be careful not to hold the lock if we call _ensure_channel
            # But the decorator is used on methods that typically acquire the lock themselves.
            # So if we are here, we might already have the lock if the decorated method uses 'with self._lock'.
            # Fortunately, RLock is reentrant.
            self._ensure_channel()
            return func(self, *args, **kwargs)
    return wrapper

from fastpluggy.core.tools.serialize_tools import serialize_value

from .contracts import (
    Broker,
    BrokerMessage,
    TopicInfo,
    TopicConfig,
    WorkerInfo,
    ClusterStats,
    ActiveTaskInfo,
    LockInfo,
    BrokerUtils,
)

log = logging.getLogger("RabbitMQBroker")
# Reduce pika logging noise
logging.getLogger("pika").setLevel(logging.WARNING)


class RabbitMQBroker(Broker):
    """A distributed broker implementation using RabbitMQ."""

    def __init__(self, rabbitmq_url: str) -> None:
        if pika is None:
            raise ImportError(
                "pika library is required for RabbitMQ broker. "
                "Install it with: pip install pika"
            )

        # Connection parameters
        self.rabbitmq_url = rabbitmq_url
        self._connection = None
        self._channel = None
        self._lock = threading.RLock()

        # Message id generator (local counter, prefixed with instance id)
        import uuid
        self._instance_id = str(uuid.uuid4())[:8]
        self._next_id = 1

        # In-memory tracking for workers, running messages, and locks
        # (These could be moved to Redis/DB for true multi-instance support)
        self._workers: Dict[str, WorkerInfo] = {}
        self._worker_tasks: Dict[str, set[str]] = {}
        self._running: Dict[str, BrokerMessage] = {}
        self._delivery_info: Dict[str, tuple] = {}  # msg_id -> (channel, delivery_tag) — ack/nack must use the same channel that received the message (delivery_tag is channel-scoped in RabbitMQ)
        self._known_topics: set = set()  # topics already declared in RabbitMQ
        self._locks: Dict[str, Dict[str, Any]] = {}
        self._locks_by_name: Dict[str, str] = {}
        self._initialized_lock_queues: set = set()  # lock queues we've checked/seeded
        self._remote_locks: Dict[str, Dict[str, Any]] = {}  # task_name -> lock info from remote nodes
        self._lock_ttl = 300.0  # seconds before a held lock is considered expired

        # Remote counter deltas keyed by (instance_id, topic, counter_name)
        self._remote_counter_deltas: Dict[tuple, int] = {}

        # Listener mode — True until register_worker() is called.
        # In listener mode, the broker connects to the fanout exchange to
        # receive heartbeats/registrations but does not claim tasks.
        self._listener_mode = True

        # Worker control
        self._draining = False  # True when drain command received
        # Cluster-wide running tasks view (from task_started/task_completed broadcasts)
        self._cluster_running_tasks: Dict[str, Dict[str, Any]] = {}  # task_id -> info
        
        # Topic configs stored in memory (could be persisted to RabbitMQ metadata or external store)
        self._topic_configs: Dict[str, TopicConfig] = {}

        # Counters per topic (in-memory for now, could be moved to Redis)
        self._running_per_topic: Dict[str, int] = {}
        self._completed_counts: Dict[str, int] = {}
        self._error_counts: Dict[str, int] = {}
        self._skipped_counts: Dict[str, int] = {}
        self._total_counts: Dict[str, int] = {}

        # Heartbeat staleness threshold (seconds) — workers not seen for this
        # duration are marked stale in get_workers().
        self._hb_ttl = 10.0
        # Reap interval: how often _reap_stale_workers runs (seconds).
        # Workers not seen for 3 × heartbeat_interval are removed entirely.
        self._reap_interval = 10.0
        self._last_reap_time = 0.0

        # Exchange and queue naming conventions
        self._task_exchange = "fp.tasks"
        self._worker_exchange = "fp.workers"
        self._dlx_exchange = "fp.dlx"
        self._worker_update_queue = None
        
        # Background thread for consuming worker updates
        self._consumer_thread = None
        self._stop_event = threading.Event()

        # Per-topic push consumers (Phase 1)
        self._topic_consumers: Dict[str, threading.Thread] = {}  # topic -> consumer thread
        self._topic_queues: Dict[str, stdlib_queue.Queue] = {}  # topic -> thread-safe Queue
        self._consumer_ready: Dict[str, threading.Event] = {}  # topic -> ready event
        self._topic_stop_events: Dict[str, threading.Event] = {}  # per-topic stop signals
        # Per-topic ack/nack queues — worker threads push requests here,
        # the consumer thread drains them inside process_data_events to avoid
        # cross-thread pika channel access.
        self._ack_queues: Dict[str, stdlib_queue.Queue] = {}  # topic -> Queue of (delivery_tag, "ack"|"nack", requeue)
        

    # ------------- Connection Management -------------
    def _connect(self) -> None:
        """Establish connection to RabbitMQ."""
        if self._connection and not self._connection.is_closed:
            return

        try:
            params = pika.URLParameters(self.rabbitmq_url)
            # Add client properties for AMQP 1.0 identification
            params.client_properties = {
                'connection_name': f'fastpluggy-{"listener" if self._listener_mode else "worker"}',
                'container-id': self._instance_id
            }
            # Prevent indefinite blocking when broker is unreachable
            params.socket_timeout = 10
            params.connection_attempts = 2
            params.retry_delay = 2
            self._connection = pika.BlockingConnection(params)
            self._channel = self._connection.channel()
            
            # Declare main task exchange (topic exchange for routing by queue name)
            self._channel.exchange_declare(
                exchange=self._task_exchange,
                exchange_type='topic',
                durable=True
            )
            
            # Declare dead-letter exchange
            self._channel.exchange_declare(
                exchange=self._dlx_exchange,
                exchange_type='topic',
                durable=True
            )

            # Declare worker exchange (fanout so all instances receive heartbeats)
            self._channel.exchange_declare(
                exchange=self._worker_exchange,
                exchange_type='fanout',
                durable=False,
                auto_delete=True
            )
            
            # Create a private temporary queue for this instance to receive worker updates
            # Use a named queue based on instance_id to avoid creating multiple anonymous queues on reconnection
            prefix = "listener" if self._listener_mode else "worker"
            queue_name = f"{prefix}.{self._instance_id}"
            self._channel.queue_declare(queue=queue_name, exclusive=False, auto_delete=True)
            self._worker_update_queue = queue_name
            self._channel.queue_bind(exchange=self._worker_exchange, queue=self._worker_update_queue)
            
            log.info(f"Connected to RabbitMQ: {self.rabbitmq_url}")
        except Exception as e:
            log.error(f"Failed to connect to RabbitMQ: {e}")
            raise

    def _ensure_channel(self) -> None:
        """Ensure we have a valid channel, reconnecting if necessary."""
        try:
            if self._connection and self._connection.is_open and self._channel and self._channel.is_open:
                return
        except Exception:
            pass
        
        # Reset local connection/channel to ensure fresh connect
        if self._channel:
            try:
                self._channel.close()
            except Exception:
                pass
            self._channel = None

        if self._connection:
            try:
                self._connection.close()
            except Exception:
                pass
            self._connection = None

        log.info("RabbitMQ connection or channel closed, reconnecting...")
        self._known_topics.clear()  # new channel needs fresh declarations
        self._connect()
        # Restart consumer thread after reconnection
        self._start_consumer_thread()

    def _start_consumer_thread(self) -> None:
        """Start background thread to consume worker updates."""
        with self._lock:
            if self._consumer_thread and self._consumer_thread.is_alive():
                return
            
            self._stop_event.clear()
            self._consumer_thread = threading.Thread(
                target=self._worker_update_consumer,
                name=f"rmq-worker-consumer-{self._instance_id}",
                daemon=True
            )
            self._consumer_thread.start()

    def _worker_update_consumer(self) -> None:
        """Background loop to consume worker registration/heartbeat messages."""
        while not self._stop_event.is_set():
            try:
                # We need a separate connection for the background consumer
                # because BlockingConnection is not thread-safe for simultaneous operations.
                params = pika.URLParameters(self.rabbitmq_url)
                conn = pika.BlockingConnection(params)
                channel = conn.channel()

                # Re-declare exchange and queue on this connection so they are
                # recreated if RabbitMQ was restarted (auto_delete queues vanish).
                channel.exchange_declare(
                    exchange=self._worker_exchange,
                    exchange_type='fanout',
                    durable=False,
                    auto_delete=True,
                )
                channel.queue_declare(
                    queue=self._worker_update_queue,
                    exclusive=False,
                    auto_delete=True,
                )
                channel.queue_bind(
                    exchange=self._worker_exchange,
                    queue=self._worker_update_queue,
                )
                
                def callback(ch, method, properties, body):
                    try:
                        data = json.loads(body.decode('utf-8'))
                        event_type = data.get('event')
                        sender_id = data.get('sender_id')

                        # Ignore messages from ourselves for coordination events
                        # (worker_command and task lifecycle events are NOT filtered
                        # because a node may send commands to its own workers)
                        self_message = (sender_id == self._instance_id)
                        if self_message and event_type not in (
                            'worker_command', 'task_started', 'task_completed', 'task_failed',
                        ):
                            return

                        if event_type == 'who_is_alive':
                            # Another node is asking who's alive — reply with our local workers
                            # Use the consumer's channel (ch) to avoid thread-safety issues
                            # with the main connection's channel
                            self._reply_worker_list(ch)
                            return

                        if event_type == 'worker_list':
                            # Another node sent its worker list — merge into ours
                            workers = data.get('workers', [])
                            self._merge_remote_workers(workers)
                            return

                        if event_type == 'lock_acquired':
                            lock_data = data.get('lock', {})
                            tname = lock_data.get('task_name')
                            if tname:
                                with self._lock:
                                    self._remote_locks[tname] = lock_data
                            return

                        if event_type == 'lock_released':
                            lock_data = data.get('lock', {})
                            tname = lock_data.get('task_name')
                            if tname:
                                with self._lock:
                                    self._remote_locks.pop(tname, None)
                            return

                        if event_type == 'config_update':
                            topic = data.get('topic')
                            cfg = data.get('config', {})
                            if topic:
                                with self._lock:
                                    self._topic_configs[topic] = TopicConfig(
                                        concurrency_limit=cfg.get('concurrency_limit'),
                                        max_retries=cfg.get('max_retries'),
                                        dead_letter_enabled=cfg.get('dead_letter_enabled', True),
                                        retention_seconds=cfg.get('retention_seconds'),
                                    )
                                log.debug(f"Applied remote config_update for topic '{topic}'")
                            return

                        if event_type == 'config_request':
                            self._reply_config_list(ch)
                            return

                        if event_type == 'config_reply':
                            configs = data.get('configs', {})
                            with self._lock:
                                for topic, cfg in configs.items():
                                    if topic not in self._topic_configs:
                                        self._topic_configs[topic] = TopicConfig(
                                            concurrency_limit=cfg.get('concurrency_limit'),
                                            max_retries=cfg.get('max_retries'),
                                            dead_letter_enabled=cfg.get('dead_letter_enabled', True),
                                            retention_seconds=cfg.get('retention_seconds'),
                                        )
                            return

                        if event_type == 'counter_delta':
                            topic = data.get('topic')
                            counter = data.get('counter')
                            delta = data.get('delta', 1)
                            instance = data.get('sender_id')
                            if topic and counter and instance:
                                with self._lock:
                                    key = (instance, topic, counter)
                                    self._remote_counter_deltas[key] = \
                                        self._remote_counter_deltas.get(key, 0) + delta
                            return

                        if event_type == 'worker_command':
                            target = data.get('target_worker_id')
                            action = data.get('action')
                            params = data.get('params', {})
                            # Only act if this command targets one of our local workers
                            with self._lock:
                                is_target = target in self._workers
                            if is_target:
                                self._handle_worker_command(action, target, params)
                            return

                        if event_type == 'task_started':
                            info = data.get('task_info', {})
                            tid = info.get('task_id')
                            if tid:
                                with self._lock:
                                    self._cluster_running_tasks[tid] = info
                            return

                        if event_type in ('task_completed', 'task_failed'):
                            info = data.get('task_info', {})
                            tid = info.get('task_id')
                            if tid:
                                with self._lock:
                                    self._cluster_running_tasks.pop(tid, None)
                            return

                        worker_data = data.get('worker')
                        if not worker_data:
                            return

                        wid = worker_data.get('worker_id')
                        with self._lock:
                            if event_type == 'register' or event_type == 'heartbeat':
                                # Reconstruct WorkerInfo
                                w = WorkerInfo(
                                    worker_id=wid,
                                    host=worker_data.get('host'),
                                    pid=worker_data.get('pid'),
                                    capacity=worker_data.get('capacity'),
                                    running=worker_data.get('running', 0),
                                    running_hint=worker_data.get('running_hint'),
                                    stale=False,
                                    topics=worker_data.get('topics', []),
                                    started_at=worker_data.get('started_at'),
                                    last_heartbeat=worker_data.get('last_heartbeat'),
                                    meta=worker_data.get('meta', {}),
                                )
                                self._workers[wid] = w
                                # Update topics we know about
                                for t in w.topics:
                                    if t != "*" and t not in self._topic_configs:
                                        self._topic_configs[t] = TopicConfig()
                            elif event_type == 'unregister':
                                self._workers.pop(wid, None)
                    except Exception as e:
                        log.error(f"Error processing worker update: {e}")

                channel.basic_consume(queue=self._worker_update_queue, on_message_callback=callback, auto_ack=True)
                log.info(f"Started worker update consumer on queue {self._worker_update_queue}")
                
                while not self._stop_event.is_set() and conn.is_open:
                    conn.process_data_events(time_limit=1)
                    self._reap_stale_workers()

                try:
                    conn.close()
                except Exception:
                    pass
            except Exception as e:
                if not self._stop_event.is_set():
                    log.warning(f"Worker update consumer error: {e}. Retrying in 5s...")
                    time.sleep(5)

    # ------------- Per-topic consumers -------------
    def _start_topic_consumer(self, topic: str) -> None:
        """Start a push-based consumer thread for a topic (if not already running)."""
        with self._lock:
            existing = self._topic_consumers.get(topic)
            if existing and existing.is_alive():
                return

            if topic not in self._topic_queues:
                self._topic_queues[topic] = stdlib_queue.Queue()
            if topic not in self._ack_queues:
                self._ack_queues[topic] = stdlib_queue.Queue()
            if topic not in self._consumer_ready:
                self._consumer_ready[topic] = threading.Event()
            else:
                self._consumer_ready[topic].clear()

            topic_stop = threading.Event()
            self._topic_stop_events[topic] = topic_stop

            t = threading.Thread(
                target=self._topic_consumer_loop,
                args=(topic, topic_stop),
                name=f"rmq-consumer-{topic}-{self._instance_id}",
                daemon=True,
            )
            self._topic_consumers[topic] = t
            t.start()

    def _topic_consumer_loop(self, topic: str, topic_stop: threading.Event = None) -> None:
        """Consumer loop for a single topic — runs in its own thread with its own connection."""
        def _should_stop():
            return self._stop_event.is_set() or (topic_stop and topic_stop.is_set())

        backoff = 1
        while not _should_stop():
            conn = None
            try:
                params = pika.URLParameters(self.rabbitmq_url)
                conn = pika.BlockingConnection(params)
                channel = conn.channel()

                # Ensure the queue exists on this connection
                config = self._topic_configs.get(topic, TopicConfig())
                # Prefetch must stay small relative to worker capacity —
                # RabbitMQ's consumer_timeout (default 30 min) kills the
                # channel if any delivered message sits unacked too long.
                prefetch = config.concurrency_limit or 32
                channel.basic_qos(prefetch_count=prefetch)

                # Declare queue (idempotent)
                args = {
                    'x-dead-letter-exchange': self._dlx_exchange,
                    'x-dead-letter-routing-key': f"dlx.{topic}",
                }
                channel.queue_declare(queue=topic, durable=True, arguments=args)

                q = self._topic_queues[topic]

                def on_message(ch, method, properties, body, _topic=topic, _q=q):
                    """Push received message into the thread-safe queue."""
                    try:
                        msg = self._deserialize_message(body)
                        # Store delivery info keyed by msg_id
                        _q.put((msg, ch, method.delivery_tag))
                    except Exception as e:
                        log.error(f"Failed to deserialize message on {_topic}: {e}")
                        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

                channel.basic_consume(queue=topic, on_message_callback=on_message, auto_ack=False)
                log.info(f"Started push consumer for topic '{topic}' (prefetch={prefetch})")
                backoff = 1  # reset on successful connect
                self._consumer_ready[topic].set()

                ack_q = self._ack_queues.get(topic)
                while not _should_stop() and conn.is_open:
                    # Drain pending ack/nack requests on the consumer's own
                    # thread so we never touch the channel from a worker thread.
                    if ack_q:
                        while True:
                            try:
                                delivery_tag, action, requeue = ack_q.get_nowait()
                            except stdlib_queue.Empty:
                                break
                            try:
                                if action == "ack":
                                    channel.basic_ack(delivery_tag=delivery_tag)
                                else:
                                    channel.basic_nack(delivery_tag=delivery_tag, requeue=requeue)
                            except Exception as e:
                                log.error(f"Failed to {action} delivery_tag={delivery_tag}: {e}")
                    conn.process_data_events(time_limit=0.1)

                try:
                    conn.close()
                except Exception:
                    pass
            except Exception as e:
                if not _should_stop():
                    log.warning(f"Topic consumer '{topic}' error: {e}. Retrying in {backoff}s...")
                    time.sleep(backoff)
                    backoff = min(backoff * 2, 30)
                if conn:
                    try:
                        conn.close()
                    except Exception:
                        pass

    def _stop_topic_consumer(self, topic: str) -> None:
        """Stop a per-topic consumer thread via its dedicated stop event."""
        stop_ev = self._topic_stop_events.pop(topic, None)
        if stop_ev:
            stop_ev.set()
        t = self._topic_consumers.pop(topic, None)
        if t:
            t.join(timeout=3)

    def _close(self) -> None:
        """Gracefully shut down all consumers and connections.

        1. Signal all threads to stop (via _stop_event)
        2. Wait for consumer threads to exit (they'll finish current process_data_events)
        3. Drain any unprocessed messages from topic queues back via nack
        4. Wait for in-flight tasks (already claimed but not yet ack/nacked) — caller's responsibility
        5. Close the main connection
        """
        # Release all locally-held locks (re-publish tokens) before stopping
        for task_id in list(self._locks.keys()):
            self._release_lock_no_owner_check(task_id)

        self._stop_event.set()

        # Wait for worker-update consumer
        if self._consumer_thread:
            self._consumer_thread.join(timeout=5)

        # Wait for all topic consumer threads
        for topic, t in list(self._topic_consumers.items()):
            t.join(timeout=5)
        self._topic_consumers.clear()

        # Drain topic queues — nack any messages that were delivered but not claimed
        for topic, q in self._topic_queues.items():
            while not q.empty():
                try:
                    msg, ch, delivery_tag = q.get_nowait()
                    try:
                        ch.basic_nack(delivery_tag=delivery_tag, requeue=True)
                    except Exception:
                        pass  # channel may already be closed
                except stdlib_queue.Empty:
                    break
        self._topic_queues.clear()
        self._consumer_ready.clear()

    # ------------- Lifecycle -------------
    def setup(self) -> None:
        """Initialize RabbitMQ connection and exchanges."""
        with self._lock:
            self._connect()
            self._start_consumer_thread()
            self._publish_who_is_alive()
            self._publish_config_request()

    def wait_ready(self) -> None:
        """Wait for broker to be ready."""
        self._ensure_channel()
        # consumer thread is started by _ensure_channel if not already running

    # ------------- Topic Helpers -------------
    @retry_on_connection_error
    def ensure_topic(self, topic: str) -> None:
        """Ensure a topic/queue exists in RabbitMQ."""
        with self._lock:
            if topic in self._known_topics:
                return

            self._ensure_channel()

            # Get or create topic config
            if topic not in self._topic_configs:
                self._topic_configs[topic] = TopicConfig()

            # Declare queue with dead-letter exchange support
            args = {
                'x-dead-letter-exchange': self._dlx_exchange,
                'x-dead-letter-routing-key': f"dlx.{topic}"
            }

            self._channel.queue_declare(
                queue=topic,
                durable=True,
                arguments=args
            )

            # Bind queue to task exchange with its name as routing key
            self._channel.queue_bind(
                exchange=self._task_exchange,
                queue=topic,
                routing_key=topic
            )

            # Declare corresponding dead-letter queue
            dlq_name = f"{topic}.dead"
            self._channel.queue_declare(queue=dlq_name, durable=True)
            self._channel.queue_bind(
                exchange=self._dlx_exchange,
                queue=dlq_name,
                routing_key=f"dlx.{topic}"
            )

            self._known_topics.add(topic)

    # ------------- Deserialization -------------
    def _deserialize_message(self, body: bytes) -> BrokerMessage:
        """Deserialize a raw message body into a BrokerMessage.

        Raises on malformed JSON or missing required fields — the caller
        is responsible for handling the exception.
        """
        data = json.loads(body.decode('utf-8'))
        return BrokerMessage(
            id=data['id'],
            topic=data['topic'],
            payload=data['payload'],
            headers=data.get('headers', {}),
            attempts=data.get('attempts', 0),
            created_at=datetime.fromisoformat(data['created_at']),
        )

    # ------------- Core Operations -------------
    @retry_on_connection_error
    def publish(self, topic: str, payload: Dict[str, Any], headers: Optional[Dict[str, Any]] = None, attempts: int = 0) -> str:
        """Publish a new message to the given topic."""
        with self._lock:
            self._ensure_channel()
            self.ensure_topic(topic)
            
            msg_id = f"rmq:{self._instance_id}:{self._next_id}"
            self._next_id += 1
            
            msg = BrokerMessage(
                id=msg_id,
                topic=topic,
                payload=dict(payload or {}),
                headers=dict(headers or {}),
                attempts=attempts,
                created_at=datetime.now(timezone.utc),
            )
            
            # Serialize message to JSON (ensure we pass a string to .encode)
            body = json.dumps(serialize_value({
                'id': msg.id,
                'topic': msg.topic,
                'payload': msg.payload,
                'headers': msg.headers,
                'attempts': msg.attempts,
                'created_at': msg.created_at.isoformat(),
            }), ensure_ascii=False)
            
            # Publish to exchange with routing key = topic name
            self._channel.basic_publish(
                exchange=self._task_exchange,
                routing_key=topic,
                body=body.encode('utf-8'),
                properties=pika.BasicProperties(
                    delivery_mode=2,  # persistent
                    message_id=msg_id,
                    timestamp=int(time.time()),
                )
            )

            # Increment total counter
            self._total_counts[topic] = self._total_counts.get(topic, 0) + 1
            
            log.debug(f"Published message {msg_id} to topic {topic}")
            return msg_id

    def _has_global_permit(self, topic: str) -> bool:
        """Check if topic has capacity for another running message."""
        config = self._topic_configs.get(topic, TopicConfig())
        if config.concurrency_limit is None:
            return True

        running_count = self._running_per_topic.get(topic, 0)
        return running_count < config.concurrency_limit

    def claim(self, topic: str, worker_id: str) -> Optional[BrokerMessage]:
        """Claim one message from the given topic for a specific worker.

        Messages are delivered by the per-topic push consumer thread into a
        thread-safe queue.Queue.  claim() does a non-blocking get from that
        queue, preserving the existing TaskExecutor polling interface.
        """
        # Handle wildcard topic - not implemented in this version
        if topic == "*":
            log.warning("Wildcard topic claiming not yet implemented for RabbitMQ broker")
            return None

        # Ensure topic consumer is running (creates queue + starts thread)
        self.ensure_topic(topic)
        self._start_topic_consumer(topic)

        q = self._topic_queues.get(topic)
        if q is None:
            return None

        try:
            msg, ch, delivery_tag = q.get_nowait()
        except stdlib_queue.Empty:
            return None

        # Increment attempts
        msg.attempts += 1

        # Update headers
        msg.headers['worker_id'] = worker_id
        msg.headers['claimed_at'] = datetime.now(timezone.utc).isoformat()

        # Store delivery info (channel is the consumer's channel, not self._channel)
        self._delivery_info[msg.id] = (ch, delivery_tag)

        with self._lock:
            # Track as running
            self._running[msg.id] = msg
            self._running_per_topic[topic] = self._running_per_topic.get(topic, 0) + 1
            self._worker_tasks.setdefault(worker_id, set()).add(msg.id)

        log.debug(f"Claimed message {msg.id} from topic {topic} for worker {worker_id}")
        return msg

    @retry_on_connection_error
    def ack(self, msg_id: str) -> None:
        """Acknowledge successful processing of a message."""
        with self._lock:
            msg = self._running.pop(msg_id, None)
            if not msg:
                log.warning(f"Attempted to ack unknown message: {msg_id}")
                return

            # Decrement running counter
            topic = msg.topic
            self._running_per_topic[topic] = max(0, self._running_per_topic.get(topic, 1) - 1)

            # Remove from worker task tracking
            wid = msg.headers.get('worker_id')
            if wid:
                self._worker_tasks.get(wid, set()).discard(msg_id)

            # Enqueue ack for the consumer thread (avoids cross-thread pika access)
            info = self._delivery_info.pop(msg_id, None)
            if info is not None:
                _ch, delivery_tag = info
                ack_q = self._ack_queues.get(topic)
                if ack_q is not None:
                    ack_q.put((delivery_tag, "ack", False))
                    self._completed_counts[topic] = self._completed_counts.get(topic, 0) + 1
                    self._broadcast_counter_delta(topic, 'completed')
                else:
                    # Fallback: no ack queue (shouldn't happen)
                    try:
                        _ch.basic_ack(delivery_tag=delivery_tag)
                        self._completed_counts[topic] = self._completed_counts.get(topic, 0) + 1
                        self._broadcast_counter_delta(topic, 'completed')
                    except Exception as e:
                        log.error(f"Failed to ack message {msg_id}: {e}")
            
            # Auto-release any lock associated with this task
            try:
                task_id = msg.payload.get("task_id") or msg_id
                if task_id in self._locks:
                    self._release_lock_no_owner_check(task_id)
            except Exception:
                pass
            
            log.debug(f"Acknowledged message {msg_id}")

    @retry_on_connection_error
    def nack(self, msg_id: str, requeue: bool = True) -> None:
        """Negative acknowledgement: mark a message as failed."""
        with self._lock:
            msg = self._running.pop(msg_id, None)
            if not msg:
                log.warning(f"Attempted to nack unknown message: {msg_id}")
                return

            # Decrement running counter
            topic = msg.topic
            self._running_per_topic[topic] = max(0, self._running_per_topic.get(topic, 1) - 1)

            # Remove from worker task tracking
            wid = msg.headers.get('worker_id')
            if wid:
                self._worker_tasks.get(wid, set()).discard(msg_id)
            
            # Release any locks
            try:
                task_id = msg.payload.get("task_id") or msg_id
                if task_id in self._locks:
                    self._release_lock_no_owner_check(task_id)
            except Exception:
                pass
            
            # Enqueue nack for the consumer thread (avoids cross-thread pika access)
            info = self._delivery_info.pop(msg_id, None)
            if info is not None:
                _ch, delivery_tag = info
                ack_q = self._ack_queues.get(topic)
                if requeue:
                    # Re-publish with incremented attempts because RabbitMQ basic_nack(requeue=True)
                    # returns the ORIGINAL message to the queue, losing our local 'attempts' increment.
                    self.publish(msg.topic, msg.payload, msg.headers, attempts=msg.attempts)
                    # Ack the original (consumer thread will execute it)
                    if ack_q is not None:
                        ack_q.put((delivery_tag, "ack", False))
                    else:
                        try:
                            _ch.basic_ack(delivery_tag=delivery_tag)
                        except Exception as e:
                            log.error(f"Failed to ack (nack-requeue) message {msg_id}: {e}")
                    self._error_counts[topic] = self._error_counts.get(topic, 0) + 1
                    self._broadcast_counter_delta(topic, 'error')
                else:
                    if ack_q is not None:
                        ack_q.put((delivery_tag, "nack", False))
                    else:
                        try:
                            _ch.basic_nack(delivery_tag=delivery_tag, requeue=False)
                        except Exception as e:
                            log.error(f"Failed to nack message {msg_id}: {e}")
                    self._skipped_counts[topic] = self._skipped_counts.get(topic, 0) + 1
                    self._broadcast_counter_delta(topic, 'skipped')
            
            log.debug(f"Nacked message {msg_id} (requeue={requeue})")

    # ------------- Workers / Heartbeat -------------
    def register_worker(
        self,
        worker_id: str,
        *,
        pid: int,
        host: str,
        topics: List[str],
        capacity: int,
        meta: Optional[Dict[str, Any]] = None,
        role: Optional[str] = None,
    ) -> None:
        """Register a worker presence with the broker."""
        self._listener_mode = False
        with self._lock:
            w = self._build_worker_info(
                worker_id=worker_id, pid=pid, host=host,
                topics=topics, capacity=capacity, role=role or "", meta=meta or {},
            )
            self._workers[worker_id] = w
            self._worker_tasks.setdefault(worker_id, set())
            log.info(f"Registered worker {worker_id} on {host} (capacity={capacity})")

            # Start push consumers for each topic this worker handles
            for t in w.topics:
                if t != "*":
                    self.ensure_topic(t)
                    self._start_topic_consumer(t)

            # Broadcast registration to other broker instances
            self._broadcast_worker_event('register', w)

    def heartbeat(
        self,
        worker_id: str,
        running: Optional[int] = None,
        capacity: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
        role: Optional[str] = None,
    ) -> None:
        """Update worker heartbeat."""
        with self._lock:
            w = self._workers.get(worker_id)
            if not w:
                log.warning(f"Heartbeat for unknown worker: {worker_id}")
                return

            self._apply_heartbeat(w, running=running, capacity=capacity, meta=meta, role=role)

            # Broadcast heartbeat to other broker instances
            self._broadcast_worker_event('heartbeat', w)

    def unregister_worker(self, worker_id: str) -> None:
        """Unregister a worker."""
        with self._lock:
            w = self._workers.pop(worker_id, None)
            self._worker_tasks.pop(worker_id, None)
            log.info(f"Unregistered worker {worker_id}")
            
            if w:
                # Broadcast unregistration to other broker instances
                self._broadcast_worker_event('unregister', w)

    def _broadcast_worker_event(self, event: str, worker: WorkerInfo) -> None:
        """Broadcast a worker event to all broker instances via RabbitMQ."""
        try:
            self._ensure_channel()
            # Convert WorkerInfo to dict for serialization
            worker_dict = {
                'worker_id': worker.worker_id,
                'host': worker.host,
                'pid': worker.pid,
                'capacity': worker.capacity,
                'running': worker.running,
                'running_hint': worker.running_hint,
                'topics': worker.topics,
                'started_at': worker.started_at,
                'last_heartbeat': worker.last_heartbeat,
                'meta': worker.meta,
            }
            body = json.dumps({'event': event, 'sender_id': self._instance_id, 'worker': worker_dict})
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8')
            )
        except Exception as e:
            log.error(f"Failed to broadcast worker event {event}: {e}")

    def _publish_who_is_alive(self) -> None:
        """Publish a who_is_alive request to discover existing workers on other nodes."""
        try:
            self._ensure_channel()
            body = json.dumps({'event': 'who_is_alive', 'sender_id': self._instance_id})
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'),
            )
            log.info("Published who_is_alive request to discover existing workers")
        except Exception as e:
            log.error(f"Failed to publish who_is_alive: {e}")

    def _publish_config_request(self) -> None:
        """Publish a config_request to discover existing topic configs on other nodes."""
        try:
            self._ensure_channel()
            body = json.dumps({'event': 'config_request', 'sender_id': self._instance_id})
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'),
            )
            log.info("Published config_request to discover existing topic configs")
        except Exception as e:
            log.error(f"Failed to publish config_request: {e}")

    def _reply_worker_list(self, channel) -> None:
        """Reply to a who_is_alive request with our local workers.

        Uses the provided *channel* (from the consumer callback) to avoid
        thread-safety issues with the main connection.
        """
        with self._lock:
            local_workers = []
            for w in self._workers.values():
                local_workers.append({
                    'worker_id': w.worker_id,
                    'host': w.host,
                    'pid': w.pid,
                    'capacity': w.capacity,
                    'running': w.running,
                    'running_hint': w.running_hint,
                    'topics': w.topics,
                    'started_at': w.started_at,
                    'last_heartbeat': w.last_heartbeat,
                    'meta': w.meta,
                })
        if not local_workers:
            return  # nothing to reply with
        try:
            body = json.dumps({
                'event': 'worker_list',
                'sender_id': self._instance_id,
                'workers': local_workers,
            })
            channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'),
            )
            log.debug(f"Replied with {len(local_workers)} worker(s) to who_is_alive")
        except Exception as e:
            log.error(f"Failed to reply with worker_list: {e}")

    def _reap_stale_workers(self) -> None:
        """Remove workers whose last_heartbeat exceeds 3 × hb_ttl."""
        now = time.monotonic()
        if now - self._last_reap_time < self._reap_interval:
            return
        self._last_reap_time = now

        threshold = self._hb_ttl * 3  # 3 × heartbeat_interval
        utcnow = datetime.now(timezone.utc)
        with self._lock:
            stale_ids = []
            for wid, w in self._workers.items():
                hb = w.last_heartbeat
                if not hb:
                    continue
                if isinstance(hb, str):
                    try:
                        hb_dt = datetime.fromisoformat(hb)
                    except ValueError:
                        continue
                else:
                    hb_dt = hb
                # Make timezone-aware if naive
                if hb_dt.tzinfo is None:
                    hb_dt = hb_dt.replace(tzinfo=timezone.utc)
                elapsed = (utcnow - hb_dt).total_seconds()
                if elapsed > threshold:
                    stale_ids.append(wid)

            for wid in stale_ids:
                self._workers.pop(wid, None)
                self._worker_tasks.pop(wid, None)
                log.info(f"Reaped stale worker {wid} (no heartbeat for >{threshold:.0f}s)")

    def _merge_remote_workers(self, workers: List[Dict[str, Any]]) -> None:
        """Merge a list of remote worker dicts into the local registry (dedup by worker_id)."""
        with self._lock:
            for wd in workers:
                wid = wd.get('worker_id')
                if not wid:
                    continue
                # Don't overwrite local workers — they have authoritative state
                if wid in self._workers:
                    continue
                w = WorkerInfo(
                    worker_id=wid,
                    host=wd.get('host'),
                    pid=wd.get('pid'),
                    capacity=wd.get('capacity'),
                    running=wd.get('running', 0),
                    running_hint=wd.get('running_hint'),
                    stale=False,
                    topics=wd.get('topics', []),
                    started_at=wd.get('started_at'),
                    last_heartbeat=wd.get('last_heartbeat'),
                    meta=wd.get('meta', {}),
                )
                self._workers[wid] = w
                for t in w.topics:
                    if t != "*" and t not in self._topic_configs:
                        self._topic_configs[t] = TopicConfig()
                log.info(f"Discovered remote worker {wid} on {w.host}")

    # ------------- Worker commands (Phase 5) -------------

    def send_worker_command(self, target_worker_id: str, action: str, params: Optional[Dict[str, Any]] = None) -> None:
        """Publish a command targeting a specific worker via the coordination exchange.

        Actions: ``drain``, ``join_topic``, ``leave_topic``, ``update_prefetch``.
        """
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': 'worker_command',
                'sender_id': self._instance_id,
                'target_worker_id': target_worker_id,
                'action': action,
                'params': params or {},
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
            log.info(f"Sent worker_command '{action}' to {target_worker_id}")
        except Exception as e:
            log.error(f"Failed to send worker_command: {e}")

    def _handle_worker_command(self, action: str, worker_id: str, params: Dict[str, Any]) -> None:
        """Handle an incoming worker command for one of our local workers."""
        log.info(f"Handling worker_command '{action}' for {worker_id}: {params}")
        if action == 'drain':
            self._draining = True
            # Stop all topic consumers; in-flight tasks finish naturally
            for topic in list(self._topic_consumers.keys()):
                self._stop_topic_consumer(topic)
            log.info(f"Worker {worker_id} entering drain mode — consumers stopped")

        elif action == 'join_topic':
            topic = params.get('topic')
            if topic:
                self.ensure_topic(topic)
                self._start_topic_consumer(topic)
                # Update worker's topic list
                with self._lock:
                    w = self._workers.get(worker_id)
                    if w and topic not in w.topics:
                        w.topics.append(topic)
                log.info(f"Worker {worker_id} joined topic '{topic}'")

        elif action == 'leave_topic':
            topic = params.get('topic')
            if topic:
                self._stop_topic_consumer(topic)
                with self._lock:
                    w = self._workers.get(worker_id)
                    if w and topic in w.topics:
                        w.topics.remove(topic)
                log.info(f"Worker {worker_id} left topic '{topic}'")

        elif action == 'update_prefetch':
            topic = params.get('topic')
            prefetch = params.get('prefetch')
            if topic and prefetch is not None:
                # Update config, then restart consumer to apply new prefetch
                with self._lock:
                    cfg = self._topic_configs.get(topic, TopicConfig())
                    self._topic_configs[topic] = TopicConfig(
                        concurrency_limit=int(prefetch),
                        max_retries=cfg.max_retries,
                        dead_letter_enabled=cfg.dead_letter_enabled,
                        retention_seconds=cfg.retention_seconds,
                    )
                self._stop_topic_consumer(topic)
                self._start_topic_consumer(topic)
                log.info(f"Worker {worker_id} updated prefetch for '{topic}' to {prefetch}")

        else:
            log.warning(f"Unknown worker command: {action}")

    # ------------- Task lifecycle broadcasting (Phase 5) -------------

    def broadcast_task_started(self, worker_id: str, task_id: str, topic: str) -> None:
        """Broadcast that a task has started (for cluster-wide visibility)."""
        info = {
            'task_id': task_id,
            'worker_id': worker_id,
            'topic': topic,
            'started_at': datetime.now(timezone.utc).isoformat(),
        }
        with self._lock:
            self._cluster_running_tasks[task_id] = info
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': 'task_started',
                'sender_id': self._instance_id,
                'task_info': info,
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
        except Exception as e:
            log.error(f"Failed to broadcast task_started: {e}")

    def broadcast_task_completed(self, worker_id: str, task_id: str, topic: str, duration: Optional[float] = None) -> None:
        """Broadcast that a task has completed."""
        with self._lock:
            self._cluster_running_tasks.pop(task_id, None)
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': 'task_completed',
                'sender_id': self._instance_id,
                'task_info': {
                    'task_id': task_id,
                    'worker_id': worker_id,
                    'topic': topic,
                    'duration': duration,
                },
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
        except Exception as e:
            log.error(f"Failed to broadcast task_completed: {e}")

    def broadcast_task_failed(self, worker_id: str, task_id: str, topic: str, error: str = '') -> None:
        """Broadcast that a task has failed."""
        with self._lock:
            self._cluster_running_tasks.pop(task_id, None)
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': 'task_failed',
                'sender_id': self._instance_id,
                'task_info': {
                    'task_id': task_id,
                    'worker_id': worker_id,
                    'topic': topic,
                    'error': error,
                },
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
        except Exception as e:
            log.error(f"Failed to broadcast task_failed: {e}")

    def get_cluster_running_tasks(self) -> List[Dict[str, Any]]:
        """Return cluster-wide running tasks aggregated from task lifecycle broadcasts."""
        with self._lock:
            return list(self._cluster_running_tasks.values())

    def get_workers(self, include_tasks: bool = False, stale_after: Optional[float] = None) -> List[WorkerInfo]:
        """List workers known to the broker."""
        with self._lock:
            now = datetime.now(timezone.utc)
            ttl = stale_after if stale_after is not None else self._hb_ttl
            out: List[WorkerInfo] = []
            
            for w in self._workers.values():
                running = len(self._worker_tasks.get(w.worker_id, ()))
                hb = getattr(w, 'last_heartbeat', None)
                stale = BrokerUtils.compute_stale(hb, now=now, ttl=ttl)
                tasks_list = None
                if include_tasks:
                    tasks_list = sorted(list(self._worker_tasks.get(w.worker_id, ())))
                
                out.append(WorkerInfo(
                    worker_id=w.worker_id,
                    host=w.host,
                    pid=int(w.pid),
                    capacity=int(w.capacity),
                    running=running,
                    running_hint=w.running_hint,
                    stale=stale,
                    topics=sorted(list(w.topics)),
                    started_at=w.started_at,
                    last_heartbeat=hb or w.started_at,
                    meta=w.meta,
                    role=w.role,
                    tasks=tasks_list,
                ))
            
            return out

    # ------------- Listings / Stats -------------
    @retry_on_connection_error
    def get_topics(self) -> List[TopicInfo]:
        """List topics with queue metrics."""
        with self._lock:
            self._ensure_channel()
            out: List[TopicInfo] = []
            
            # Start with topics we have configs or counters for
            all_topics = set(self._topic_configs.keys())
            all_topics.update(self._completed_counts.keys())
            all_topics.update(self._error_counts.keys())
            all_topics.update(self._skipped_counts.keys())
            all_topics.update(self._total_counts.keys())
            
            # Also add topics from registered workers
            for w in self._workers.values():
                for t in w.topics:
                    if t != "*":
                        all_topics.add(t)

            for topic_name in all_topics:
                # Count subscribers (workers listening to this topic)
                subscribers = sum(
                    1 for w in self._workers.values()
                    if (topic_name in w.topics) or ("*" in w.topics)
                )
                
                # Count running for this topic
                running_count = self._running_per_topic.get(topic_name, 0)
                
                try:
                    # Get queue statistics from RabbitMQ
                    result = self._channel.queue_declare(queue=topic_name, passive=True, durable=True)
                    queued = result.method.message_count
                    
                    # Count dead-letter messages
                    dlq_name = f"{topic_name}.dead"
                    try:
                        dlq_result = self._channel.queue_declare(queue=dlq_name, passive=True, durable=True)
                        dead_letter = dlq_result.method.message_count
                    except Exception:
                        dead_letter = 0
                    
                    config = self._topic_configs.get(topic_name, TopicConfig())
                    
                    # If queue declare fails with 404, we'll catch it below
                    out.append(TopicInfo(
                        topic=topic_name,
                        queued=queued,
                        running=running_count,
                        dead_letter=dead_letter,
                        subscribers=subscribers,
                        configuration=config,
                        completed_count=self._completed_counts.get(topic_name, 0) + self._remote_counter(topic_name, 'completed'),
                        error_count=self._error_counts.get(topic_name, 0) + self._remote_counter(topic_name, 'error'),
                        skipped_count=self._skipped_counts.get(topic_name, 0) + self._remote_counter(topic_name, 'skipped'),
                        total_count=self._total_counts.get(topic_name, 0),
                    ))
                except (pika.exceptions.ChannelClosedByBroker, pika.exceptions.AMQPChannelError) as e:
                    # Topic might exist in worker metadata but not yet in RabbitMQ
                    if hasattr(e, 'reply_code') and e.reply_code == 404:
                        # Re-open channel if it was closed by the 404
                        self._ensure_channel()
                        
                        # Add topic with 0 metrics if it's known to workers
                        out.append(TopicInfo(
                            topic=topic_name,
                            queued=0,
                            running=running_count,
                            dead_letter=0,
                            subscribers=subscribers,
                            configuration=self._topic_configs.get(topic_name, TopicConfig()),
                        ))
                    else:
                        log.warning(f"Failed to get stats for topic {topic_name}: {e}")
                except Exception as e:
                    log.warning(f"Failed to get stats for topic {topic_name}: {e}")
            
            return sorted(out, key=lambda x: x.topic)

    def get_cluster_stats(self) -> ClusterStats:
        """Aggregate cluster-level stats."""
        with self._lock:
            total_capacity = sum(w.capacity for w in self._workers.values())
            total_running = sum(len(s) for s in self._worker_tasks.values())
            
            return ClusterStats(
                workers=len(self._workers),
                total_capacity=total_capacity,
                total_running=total_running,
                topics=self.get_topics(),
                broker_type="rabbitmq",
            )

    def stats(self) -> Dict[str, Any]:
        """Return a summary of broker status."""
        cs = self.get_cluster_stats()
        return {
            "workers": cs.workers,
            "total_capacity": cs.total_capacity,
            "total_running": cs.total_running,
            "topics": [t.topic for t in cs.topics],
            "broker_type": cs.broker_type,
        }

    def get_all_active_tasks(self, topic: Optional[str]) -> List[ActiveTaskInfo]:
        """Return a list of active tasks known by the broker."""
        with self._lock:
            items: List[ActiveTaskInfo] = []
            
            # For now, only return running tasks (queued tasks would require consuming from RabbitMQ)
            for m in self._running.values():
                if topic is not None and m.topic != topic:
                    continue
                items.append(ActiveTaskInfo(
                    id=m.id,
                    topic=m.topic,
                    payload=m.payload,
                    headers=dict(m.headers or {}),
                    attempts=m.attempts,
                    created_at=m.created_at.isoformat(),
                    state="running",
                    claimed_by=(m.headers or {}).get('worker_id')
                ))
            
            return items

    # ------------- Locks (distributed via RabbitMQ queues) -------------
    #
    # Each lock name gets a durable queue ``tw.lock.<task_name>`` with
    # ``x-max-length=1``.  The queue holds a single "token" message.
    # To acquire: ``basic_get`` the token (atomic — only one consumer gets it).
    # To release: re-publish the token.
    # Crash recovery: if a holder crashes, the token is lost.  Stale lock
    # detection uses broadcast events + TTL to re-seed the queue.

    def _ensure_lock_queue(self, task_name: str) -> str:
        """Ensure the lock queue exists in RabbitMQ, seeding a token if newly created."""
        lock_queue = f"tw.lock.{task_name}"
        if lock_queue in self._initialized_lock_queues:
            return lock_queue

        self._ensure_channel()

        # Check if queue already exists using a temporary channel so that a
        # 404 error doesn't close self._channel.
        queue_is_new = False
        try:
            temp_ch = self._connection.channel()
            temp_ch.queue_declare(queue=lock_queue, passive=True)
            temp_ch.close()
        except pika.exceptions.ChannelClosedByBroker as e:
            if e.reply_code == 404:
                queue_is_new = True
            else:
                raise

        # Declare the actual queue (idempotent)
        self._channel.queue_declare(
            queue=lock_queue, durable=True,
            arguments={'x-max-length': 1})

        if queue_is_new:
            # Seed exactly one token.  x-max-length=1 ensures that even if
            # two nodes race to seed simultaneously, only one token survives.
            self._channel.basic_publish(
                exchange='', routing_key=lock_queue,
                body=json.dumps({'lock': task_name}).encode(),
                properties=pika.BasicProperties(delivery_mode=2))
            log.info(f"Created and seeded lock queue {lock_queue}")

        self._initialized_lock_queues.add(lock_queue)
        return lock_queue

    def _release_lock_token(self, task_name: str) -> None:
        """Re-publish the lock token so the next acquirer can get it."""
        lock_queue = f"tw.lock.{task_name}"
        try:
            self._ensure_channel()
            self._channel.basic_publish(
                exchange='', routing_key=lock_queue,
                body=json.dumps({'lock': task_name}).encode(),
                properties=pika.BasicProperties(delivery_mode=2))
        except Exception as e:
            log.error(f"Failed to release lock token for {task_name}: {e}")

    def _broadcast_lock_event(self, event: str, task_name: str, task_id: str, locked_by: str) -> None:
        """Broadcast a lock event to all nodes via the coordination exchange."""
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': event,
                'sender_id': self._instance_id,
                'lock': {
                    'task_name': task_name,
                    'task_id': task_id,
                    'locked_by': locked_by,
                    'acquired_at': datetime.now(timezone.utc).isoformat(),
                    'instance_id': self._instance_id,
                },
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
        except Exception as e:
            log.error(f"Failed to broadcast lock event {event}: {e}")

    def _release_lock_no_owner_check(self, task_id: str) -> bool:
        """Release a lock without checking ownership."""
        info = self._locks.pop(task_id, None)
        if not info:
            return False
        tname = info.get("task_name")
        if tname:
            if self._locks_by_name.get(tname) == task_id:
                self._locks_by_name.pop(tname, None)
            self._release_lock_token(tname)
            self._broadcast_lock_event('lock_released', tname, task_id, info.get('locked_by', ''))
        return True

    @retry_on_connection_error
    def acquire_lock(self, task_name: str, task_id: str, locked_by: str) -> bool:
        """Acquire an exclusive distributed lock for a task.

        Uses a RabbitMQ queue with a single token message.  ``basic_get`` is
        atomic — only one node can retrieve the token at a time.
        """
        if not task_id:
            return False
        if not task_name:
            task_name = task_id

        with self._lock:
            # Fast-path: idempotent re-acquire
            xid = self._locks_by_name.get(task_name)
            if xid == task_id:
                return True
            if xid and xid != task_id:
                return False

            # Check remote lock cache (from broadcast events)
            remote = self._remote_locks.get(task_name)
            if remote:
                try:
                    acq_dt = datetime.fromisoformat(remote.get('acquired_at', ''))
                    if acq_dt.tzinfo is None:
                        acq_dt = acq_dt.replace(tzinfo=timezone.utc)
                    elapsed = (datetime.now(timezone.utc) - acq_dt).total_seconds()
                    if elapsed < self._lock_ttl:
                        return False  # held by a live remote node
                except (ValueError, TypeError):
                    pass
                # Remote lock is expired — clear it and try to acquire
                self._remote_locks.pop(task_name, None)

            lock_queue = self._ensure_lock_queue(task_name)

            # Try to get the token (atomic dequeue)
            method, props, body = self._channel.basic_get(
                queue=lock_queue, auto_ack=True)

            if not method:
                # Token not available.  If there's an expired remote lock,
                # the holder likely crashed — re-seed and retry once.
                if remote:
                    log.info(f"Re-seeding lock {task_name}: previous holder timed out")
                    self._channel.basic_publish(
                        exchange='', routing_key=lock_queue,
                        body=json.dumps({'lock': task_name}).encode(),
                        properties=pika.BasicProperties(delivery_mode=2))
                    method, props, body = self._channel.basic_get(
                        queue=lock_queue, auto_ack=True)

            if method:
                self._locks[task_id] = {
                    "task_id": task_id,
                    "task_name": task_name,
                    "locked_by": locked_by,
                    "acquired_at": datetime.now(timezone.utc).isoformat(),
                }
                self._locks_by_name[task_name] = task_id
                self._broadcast_lock_event('lock_acquired', task_name, task_id, locked_by)
                return True

            return False

    def release_lock(self, task_id: str, locked_by: Optional[str] = None) -> bool:
        """Release a distributed lock, putting the token back in the queue."""
        if not task_id:
            return False

        with self._lock:
            info = self._locks.get(task_id)
            if not info:
                return False
            if locked_by is not None and info.get("locked_by") != locked_by:
                return False
            return self._release_lock_no_owner_check(task_id)

    def get_locks(self) -> List[LockInfo]:
        """List current task locks (local + remote)."""
        with self._lock:
            out = []
            # Local locks
            for tid, info in self._locks.items():
                out.append(LockInfo(
                    task_id=tid,
                    task_name=info.get("task_name"),
                    locked_by=info.get("locked_by"),
                    acquired_at=info.get("acquired_at"),
                ))
            # Remote locks (from broadcast cache)
            local_names = set(self._locks_by_name.keys())
            for tname, rinfo in self._remote_locks.items():
                if tname not in local_names:
                    out.append(LockInfo(
                        task_id=rinfo.get("task_id"),
                        task_name=tname,
                        locked_by=rinfo.get("locked_by"),
                        acquired_at=rinfo.get("acquired_at"),
                    ))
            return out

    def force_release_lock(self, task_id: str) -> bool:
        """Force release a task lock."""
        with self._lock:
            return self._release_lock_no_owner_check(task_id)

    # ------------- Topic Configuration -------------
    def set_topic_config(self, topic: str, config: TopicConfig) -> None:
        """Set full topic configuration atomically and broadcast to other nodes."""
        with self._lock:
            self.ensure_topic(topic)

            lim = None if config.concurrency_limit is None else int(config.concurrency_limit)
            if lim is not None and lim < 0:
                raise ValueError("concurrency_limit must be >= 0 or None")

            self._topic_configs[topic] = TopicConfig(
                concurrency_limit=lim,
                max_retries=config.max_retries,
                dead_letter_enabled=bool(config.dead_letter_enabled),
                retention_seconds=config.retention_seconds,
            )

            # Broadcast config change to other nodes
            self._broadcast_config_update(topic, self._topic_configs[topic])

    def _broadcast_config_update(self, topic: str, config: TopicConfig) -> None:
        """Broadcast a topic config change to all nodes."""
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': 'config_update',
                'sender_id': self._instance_id,
                'topic': topic,
                'config': {
                    'concurrency_limit': config.concurrency_limit,
                    'max_retries': config.max_retries,
                    'dead_letter_enabled': config.dead_letter_enabled,
                    'retention_seconds': config.retention_seconds,
                },
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
        except Exception as e:
            log.error(f"Failed to broadcast config_update for {topic}: {e}")

    def _reply_config_list(self, channel) -> None:
        """Reply to a config_request with all local topic configs.

        Uses the provided *channel* (from the consumer callback) to avoid
        thread-safety issues with the main connection.
        """
        with self._lock:
            configs = {}
            for topic, cfg in self._topic_configs.items():
                configs[topic] = {
                    'concurrency_limit': cfg.concurrency_limit,
                    'max_retries': cfg.max_retries,
                    'dead_letter_enabled': cfg.dead_letter_enabled,
                    'retention_seconds': cfg.retention_seconds,
                }
        if not configs:
            return
        try:
            body = json.dumps({
                'event': 'config_reply',
                'sender_id': self._instance_id,
                'configs': configs,
            })
            channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
            log.debug(f"Replied with {len(configs)} topic config(s)")
        except Exception as e:
            log.error(f"Failed to reply with config_reply: {e}")

    def _remote_counter(self, topic: str, counter: str) -> int:
        """Sum counter deltas received from all remote nodes for a topic."""
        total = 0
        for (inst, t, c), delta in self._remote_counter_deltas.items():
            if t == topic and c == counter:
                total += delta
        return total

    def _broadcast_counter_delta(self, topic: str, counter: str, delta: int = 1) -> None:
        """Broadcast a counter increment to all nodes."""
        try:
            self._ensure_channel()
            body = json.dumps({
                'event': 'counter_delta',
                'sender_id': self._instance_id,
                'topic': topic,
                'counter': counter,  # 'completed', 'error', 'skipped'
                'delta': delta,
            })
            self._channel.basic_publish(
                exchange=self._worker_exchange,
                routing_key='',
                body=body.encode('utf-8'))
        except Exception as e:
            log.error(f"Failed to broadcast counter_delta: {e}")

    def get_topic_config(self, topic: str) -> TopicConfig:
        """Return the current TopicConfig for a topic."""
        with self._lock:
            self.ensure_topic(topic)
            return self._topic_configs.get(topic, TopicConfig())

    def get_all_topic_configs(self) -> Dict[str, TopicConfig]:
        """Return a snapshot of all topic configs by topic name."""
        with self._lock:
            return {name: cfg for name, cfg in self._topic_configs.items()}

    def get_topic_running(self) -> Dict[str, int]:
        """Return current running counts per topic."""
        with self._lock:
            result = {}
            # Initialize with known topics
            all_topics = set(self._topic_configs.keys())
            for w in self._workers.values():
                for t in w.topics:
                    if t != "*":
                        all_topics.add(t)

            for topic_name in all_topics:
                result[topic_name] = self._running_per_topic.get(topic_name, 0)

            return result

    @retry_on_connection_error
    def purge_topic(self, topic: str, include_dead_letter: bool = False) -> Dict[str, Any]:
        """
        Purge queued messages for a topic. Optionally clear its dead-letter queue.
        Returns counts comparable to other backends. Best-effort: if queues do not exist,
        returns zeros instead of raising.
        """
        with self._lock:
            if not topic:
                return {"topic": topic, "purged_queued": 0, "purged_dead_letter": 0, "running": 0, "queued": 0, "dead_letter": 0}

            self._ensure_channel()
            # Ensure we know about the topic (creates queues if they don't exist)
            try:
                self.ensure_topic(topic)
            except Exception:
                # Even if ensure fails, try passive declare for counts
                pass

            purged_q = 0
            purged_dead = 0
            remaining_q = 0
            remaining_dead = 0

            # Main queue
            try:
                # Get current count via passive declare
                res = self._channel.queue_declare(queue=topic, passive=True, durable=True)
                qcnt = getattr(res.method, 'message_count', 0) or 0
                purged_q = int(qcnt)
                # Purge all
                self._channel.queue_purge(queue=topic)
                # after purge, remaining queued should be 0
                remaining_q = 0
                
                # Reset local counters for this topic
                self._completed_counts[topic] = 0
                self._error_counts[topic] = 0
                self._skipped_counts[topic] = 0
                self._total_counts[topic] = 0
            except Exception:
                # Queue might not exist yet
                purged_q = 0
                remaining_q = 0

            # Dead-letter queue
            if include_dead_letter:
                dlq_name = f"{topic}.dead"
                try:
                    resd = self._channel.queue_declare(queue=dlq_name, passive=True, durable=True)
                    dcnt = getattr(resd.method, 'message_count', 0) or 0
                    purged_dead = int(dcnt)
                    self._channel.queue_purge(queue=dlq_name)
                    remaining_dead = 0
                except Exception:
                    purged_dead = 0
                    remaining_dead = 0
            else:
                # report current dead-letter count without purging
                try:
                    resd = self._channel.queue_declare(queue=f"{topic}.dead", passive=True, durable=True)
                    remaining_dead = int(getattr(resd.method, 'message_count', 0) or 0)
                except Exception:
                    remaining_dead = 0

            running_cnt = self._running_per_topic.get(topic, 0)

            return {
                "topic": topic,
                "purged_queued": purged_q,
                "purged_dead_letter": purged_dead,
                "running": int(running_cnt),
                "queued": int(remaining_q),
                "dead_letter": int(remaining_dead),
            }

    def __del__(self):
        """Cleanup on destruction."""
        if not getattr(self, "_stop_event", None):
            return
        self._close()
