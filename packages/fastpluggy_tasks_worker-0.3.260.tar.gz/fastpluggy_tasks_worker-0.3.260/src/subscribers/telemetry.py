# telemetry.py
from dataclasses import dataclass, field
from collections import defaultdict
from typing import Dict, Any

from ..core.events import TaskLifecycleEvent
from ..core.status import TaskStatus


@dataclass
class TaskTelemetry:
    # totals
    submitted_total: int = 0
    completed_total: int = 0
    failed_total: int = 0
    running_total: int = 0

    # per-topic breakdown
    running_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    submitted_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    completed_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    failed_per_topic: Dict[str, int] = field(default_factory=lambda: defaultdict(int))

    running_tasks: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # ---- handlers: names must match "on_<TaskStatus.name.lower()>" ----

    def on_created(self, e: TaskLifecycleEvent) -> None:
        # purely informational; often emitted before enqueue
        pass

    def on_queued(self, e: TaskLifecycleEvent) -> None:
        topic = getattr(e.context, "topic", "unknown")
        self.submitted_total += 1
        self.submitted_per_topic[topic] += 1

    def on_running(self, e: TaskLifecycleEvent) -> None:
        topic = getattr(e.context, "topic", "unknown")
        self.running_total += 1
        self.running_per_topic[topic] += 1
        self.running_tasks[e.task_id] = {
            "task_id": e.task_id,
            "task_name": getattr(e.context, "task_name", "unknown"),
            "topic": topic,
            "broker_msg_id": e.broker_msg_id,
        }

    # Final states — SUCCESS, FAILED, CANCELLED, MANUAL_CANCELLED, ERROR, TIMEOUT, DEAD, SKIPPED
    def on_final(self, e: TaskLifecycleEvent) -> None:
        topic = getattr(e.context, "topic", "unknown")
        # Only decrement running counters if this task was actually observed as running.
        # Tasks that fail before emitting RUNNING (e.g. bad payload) must not touch
        # the running counters — doing so would corrupt counts for legitimately running tasks.
        was_running = e.task_id in self.running_tasks
        self.running_tasks.pop(e.task_id, None)

        if was_running:
            if self.running_total > 0:
                self.running_total -= 1
            if self.running_per_topic.get(topic, 0) > 0:
                self.running_per_topic[topic] -= 1
                if self.running_per_topic[topic] == 0:
                    self.running_per_topic.pop(topic, None)

        # completion counters (only if it's a real terminal outcome)
        if e.status in {
            TaskStatus.SUCCESS, TaskStatus.FAILED, TaskStatus.CANCELLED,
            TaskStatus.MANUAL_CANCELLED, TaskStatus.ERROR, TaskStatus.TIMEOUT,
            TaskStatus.DEAD, TaskStatus.SKIPPED
        }:
            self.completed_total += 1
            self.completed_per_topic[topic] += 1

            # Track failures separately
            if e.status in {
                TaskStatus.FAILED, TaskStatus.ERROR, TaskStatus.TIMEOUT, TaskStatus.DEAD
            }:
                self.failed_total += 1
                self.failed_per_topic[topic] += 1

    # Optional: logs/progress events (no counters, but you can mine metadata)
    def on_logs(self, e: TaskLifecycleEvent) -> None:
        pass

    def on_progress(self, e: TaskLifecycleEvent) -> None:
        pass

    # Public snapshot for heartbeat/manager/etc.
    def snapshot(self) -> dict:
        return {
            "running": self.running_total,
            "running_per_topic": dict(self.running_per_topic),
            "running_tasks": list(self.running_tasks.values()),
            "submitted_total": self.submitted_total,
            "submitted_per_topic": dict(self.submitted_per_topic),
            "completed_total": self.completed_total,
            "completed_per_topic": dict(self.completed_per_topic),
            "failed_total": self.failed_total,
            "failed_per_topic": dict(self.failed_per_topic),
        }
