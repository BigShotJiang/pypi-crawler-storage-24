"""Tests for BrokerUtils helpers and Broker base class methods."""
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock

import pytest

from src.broker.contracts import Broker, BrokerUtils, WorkerInfo


class TestBuildWorkerInfo:
    def test_basic_construction(self):
        w = Broker._build_worker_info(worker_id="w1", pid=123, host="host1")
        assert w.worker_id == "w1"
        assert w.pid == 123
        assert w.host == "host1"
        assert w.running == 0
        assert w.stale is False
        assert w.tasks is None

    def test_defaults(self):
        w = Broker._build_worker_info(worker_id="w1")
        assert w.pid == 0
        assert w.host == ""
        assert w.topics == []
        assert w.capacity == 1
        assert w.role == ""
        assert w.meta == {}

    def test_topics_and_capacity(self):
        w = Broker._build_worker_info(worker_id="w1", topics=["a", "b"], capacity=4)
        assert w.topics == ["a", "b"]
        assert w.capacity == 4

    def test_role_set(self):
        w = Broker._build_worker_info(worker_id="w1", role="beat")
        assert w.role == "beat"

    def test_role_empty(self):
        w = Broker._build_worker_info(worker_id="w1", role="")
        assert w.role == ""

    def test_meta_passed_through(self):
        w = Broker._build_worker_info(worker_id="w1", meta={"custom": "value"})
        assert w.meta["custom"] == "value"

    def test_timestamps_set(self):
        w = Broker._build_worker_info(worker_id="w1")
        assert w.started_at is not None
        assert w.last_heartbeat is not None
        # Should be valid ISO format
        datetime.fromisoformat(w.started_at)
        datetime.fromisoformat(w.last_heartbeat)


class TestApplyHeartbeat:
    def _make_worker(self, **kwargs):
        defaults = dict(
            worker_id="w1", host="h", pid=1, capacity=2, running=0,
            running_hint=None, stale=False, topics=[], started_at="2024-01-01T00:00:00+00:00",
            last_heartbeat="2024-01-01T00:00:00+00:00", meta={}, role="worker", tasks=None,
        )
        defaults.update(kwargs)
        return WorkerInfo(**defaults)

    def test_updates_last_heartbeat(self):
        w = self._make_worker()
        old_hb = w.last_heartbeat
        Broker._apply_heartbeat(w)
        assert w.last_heartbeat != old_hb

    def test_updates_capacity(self):
        w = self._make_worker(capacity=2)
        Broker._apply_heartbeat(w, capacity=8)
        assert w.capacity == 8

    def test_updates_running_hint(self):
        w = self._make_worker()
        Broker._apply_heartbeat(w, running=5)
        assert w.running_hint == 5

    def test_updates_role(self):
        w = self._make_worker(role="worker")
        Broker._apply_heartbeat(w, role="worker+beat")
        assert w.role == "worker+beat"
        assert w.meta["role"] == "worker+beat"

    def test_none_values_not_applied(self):
        w = self._make_worker(capacity=4, role="worker")
        Broker._apply_heartbeat(w, capacity=None, running=None, role=None)
        assert w.capacity == 4
        assert w.role == "worker"


class TestGetWorkerRole:
    def test_from_worker_info_role_field(self):
        w = WorkerInfo(
            worker_id="w1", host="h", pid=1, capacity=1, running=0,
            running_hint=None, stale=False, topics=[], started_at="", last_heartbeat="",
            meta={}, role="beat", tasks=None,
        )
        assert BrokerUtils.get_worker_role(w) == "beat"

    def test_from_worker_info_meta_fallback(self):
        w = WorkerInfo(
            worker_id="w1", host="h", pid=1, capacity=1, running=0,
            running_hint=None, stale=False, topics=[], started_at="", last_heartbeat="",
            meta={"role": "worker+beat"}, role="", tasks=None,
        )
        assert BrokerUtils.get_worker_role(w) == "worker+beat"

    def test_from_dict_role_field(self):
        assert BrokerUtils.get_worker_role({"role": "beat"}) == "beat"

    def test_from_dict_meta_fallback(self):
        assert BrokerUtils.get_worker_role({"role": "", "meta": {"role": "worker"}}) == "worker"

    def test_from_dict_empty(self):
        assert BrokerUtils.get_worker_role({}) == ""

    def test_unknown_type(self):
        assert BrokerUtils.get_worker_role(42) == ""


class TestCheckExistingBeat:
    def _make_mock_broker(self, workers):
        broker = MagicMock()
        broker.get_workers.return_value = workers
        broker.unregister_worker = MagicMock()
        return broker

    def _make_worker_info(self, worker_id, role, hb_age_seconds=0):
        now = datetime.now(timezone.utc)
        hb = (now - timedelta(seconds=hb_age_seconds)).isoformat()
        return WorkerInfo(
            worker_id=worker_id, host="h", pid=1, capacity=1, running=0,
            running_hint=None, stale=False, topics=[], started_at=hb,
            last_heartbeat=hb, meta={}, role=role, tasks=None,
        )

    def test_no_workers(self):
        broker = self._make_mock_broker([])
        assert BrokerUtils.check_existing_beat(broker) is False

    def test_no_beat_workers(self):
        broker = self._make_mock_broker([
            self._make_worker_info("w1", "worker"),
        ])
        assert BrokerUtils.check_existing_beat(broker) is False

    def test_live_beat_returns_true(self):
        broker = self._make_mock_broker([
            self._make_worker_info("beat-1", "beat", hb_age_seconds=2),
        ])
        assert BrokerUtils.check_existing_beat(broker) is True

    def test_stale_beat_cleaned_up(self):
        broker = self._make_mock_broker([
            self._make_worker_info("beat-1", "beat", hb_age_seconds=60),
        ])
        assert BrokerUtils.check_existing_beat(broker) is False
        broker.unregister_worker.assert_called_once_with("beat-1")

    def test_worker_plus_beat_detected(self):
        broker = self._make_mock_broker([
            self._make_worker_info("w1", "worker+beat", hb_age_seconds=1),
        ])
        assert BrokerUtils.check_existing_beat(broker) is True

    def test_mixed_stale_and_live(self):
        broker = self._make_mock_broker([
            self._make_worker_info("beat-old", "beat", hb_age_seconds=60),
            self._make_worker_info("beat-new", "beat", hb_age_seconds=1),
        ])
        assert BrokerUtils.check_existing_beat(broker) is True
        broker.unregister_worker.assert_called_once_with("beat-old")


class TestCountLiveBeats:
    def _make_mock_broker(self, workers):
        broker = MagicMock()
        broker.get_workers.return_value = workers
        return broker

    def _make_worker_info(self, worker_id, role, hb_age_seconds=0):
        now = datetime.now(timezone.utc)
        hb = (now - timedelta(seconds=hb_age_seconds)).isoformat()
        return WorkerInfo(
            worker_id=worker_id, host="h", pid=1, capacity=1, running=0,
            running_hint=None, stale=False, topics=[], started_at=hb,
            last_heartbeat=hb, meta={}, role=role, tasks=None,
        )

    def test_zero_beats(self):
        broker = self._make_mock_broker([self._make_worker_info("w1", "worker")])
        assert BrokerUtils.count_live_beats(broker) == 0

    def test_one_beat(self):
        broker = self._make_mock_broker([self._make_worker_info("b1", "beat", 1)])
        assert BrokerUtils.count_live_beats(broker) == 1

    def test_duplicate_beats(self):
        broker = self._make_mock_broker([
            self._make_worker_info("b1", "beat", 1),
            self._make_worker_info("b2", "beat", 2),
        ])
        assert BrokerUtils.count_live_beats(broker) == 2

    def test_stale_beats_excluded(self):
        broker = self._make_mock_broker([
            self._make_worker_info("b1", "beat", 60),
        ])
        assert BrokerUtils.count_live_beats(broker) == 0

    def test_broker_error_returns_zero(self):
        broker = MagicMock()
        broker.get_workers.side_effect = RuntimeError("connection lost")
        assert BrokerUtils.count_live_beats(broker) == 0
