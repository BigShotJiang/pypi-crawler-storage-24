import threading
import time
from unittest.mock import MagicMock

import pytest

from fastpluggy_plugin.tasks_worker.broker.contracts import BrokerMessage
from fastpluggy_plugin.tasks_worker.core.executor import TaskExecutor


def _make_msg(topic: str, task_id: str) -> BrokerMessage:
    return BrokerMessage(id=f"msg-{task_id}", topic=topic, payload={"task_id": task_id})


@pytest.fixture
def mock_broker():
    broker = MagicMock()
    broker.claim.return_value = None
    broker.ack.return_value = None
    broker.nack.return_value = None
    return broker


class TestDrainIdleTopic:
    """Draining a topic with no in-flight tasks returns immediately."""

    def test_drain_idle(self, mock_broker):
        executor = TaskExecutor(mock_broker, ["work"], handler=lambda m: True, worker_id="w1")
        executor.start_executor()
        try:
            result = executor.drain_topic("work", timeout=2.0)
            assert result == {"drained": True, "remaining": 0}
        finally:
            executor.stop()

    def test_is_draining_false_by_default(self, mock_broker):
        executor = TaskExecutor(mock_broker, ["work"], handler=lambda m: True, worker_id="w1")
        assert executor.is_draining("work") is False


class TestDrainWithInflight:
    """Draining waits for in-flight tasks to finish."""

    def test_drain_waits_for_inflight(self, mock_broker):
        gate = threading.Event()

        def slow_handler(msg):
            gate.wait(timeout=5)
            return True

        # Broker returns one message then None
        msg = _make_msg("work", "t1")
        mock_broker.claim.side_effect = [msg] + [None] * 200

        executor = TaskExecutor(mock_broker, ["work"], handler=slow_handler, worker_id="w1")
        executor.start_executor()
        try:
            # Wait for the task to be claimed
            for _ in range(40):
                with executor._running_tasks_lock:
                    if executor._running_tasks:
                        break
                time.sleep(0.05)

            # Start drain in a background thread
            drain_result = {}

            def do_drain():
                drain_result.update(executor.drain_topic("work", timeout=5.0))

            t = threading.Thread(target=do_drain)
            t.start()

            # Verify draining is active
            time.sleep(0.1)
            assert executor.is_draining("work") is True

            # Release the task
            gate.set()
            t.join(timeout=5)

            assert drain_result == {"drained": True, "remaining": 0}
            # Draining flag cleared after completion
            assert executor.is_draining("work") is False
        finally:
            gate.set()
            executor.stop()


class TestDrainTimeout:
    """Drain returns drained=False when timeout expires with tasks still running."""

    def test_drain_timeout(self, mock_broker):
        gate = threading.Event()

        def blocking_handler(msg):
            gate.wait(timeout=10)
            return True

        msg = _make_msg("work", "t1")
        mock_broker.claim.side_effect = [msg] + [None] * 200

        executor = TaskExecutor(mock_broker, ["work"], handler=blocking_handler, worker_id="w1")
        executor.start_executor()
        try:
            # Wait for task to be in-flight
            for _ in range(40):
                with executor._running_tasks_lock:
                    if executor._running_tasks:
                        break
                time.sleep(0.05)

            result = executor.drain_topic("work", timeout=1.0)
            assert result["drained"] is False
            assert result["remaining"] >= 1
        finally:
            gate.set()
            executor.stop()


class TestDrainSkipsClaiming:
    """While draining, the dispatch loop must not claim new messages."""

    def test_no_claims_while_draining(self, mock_broker):
        executor = TaskExecutor(mock_broker, ["work"], handler=lambda m: True, worker_id="w1")
        executor.start_executor()
        try:
            # Reset call count after startup claims
            time.sleep(0.2)
            mock_broker.claim.reset_mock()

            # Start draining (idle, so returns immediately, but we want to hold it)
            executor._draining.add("work")
            time.sleep(0.5)

            # No claims should have been made while draining
            assert mock_broker.claim.call_count == 0
        finally:
            executor._draining.discard("work")
            executor.stop()
