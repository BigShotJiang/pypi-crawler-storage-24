"""Tests for the tasks-worker start CLI command (Phase 1).

Verifies that the start command:
- blocks the main thread until a signal is received
- performs graceful shutdown on SIGINT/SIGTERM
- accepts --log-level option
- prints a startup banner
- returns runners from start_workers_if_available
"""

import os
import signal
import threading
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from fastpluggy_plugin.tasks_worker.cli import tasks_worker_group


@pytest.fixture
def cli_runner():
    return CliRunner()


@pytest.fixture
def mock_runner():
    runner = MagicMock()
    runner.stop = MagicMock()
    return runner


def _send_signal_after(delay: float, sig: int = signal.SIGINT):
    """Send a signal to the current process after a short delay."""
    pid = os.getpid()

    def _send():
        os.kill(pid, sig)

    t = threading.Timer(delay, _send)
    t.daemon = True
    t.start()
    return t


class TestStartCommand:
    """Tests for the `tasks-worker start` CLI command."""

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_blocks_and_responds_to_sigint(self, mock_start, mock_runner, cli_runner):
        """The start command blocks and shuts down on SIGINT."""
        mock_start.return_value = [mock_runner]

        _send_signal_after(0.1, signal.SIGINT)

        result = cli_runner.invoke(tasks_worker_group, ["start"])

        assert result.exit_code == 0
        assert "Workers: 1" in result.output
        assert "All workers stopped" in result.output
        mock_runner.stop.assert_called_once()

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_blocks_and_responds_to_sigterm(self, mock_start, mock_runner, cli_runner):
        """The start command shuts down on SIGTERM."""
        mock_start.return_value = [mock_runner]

        _send_signal_after(0.1, signal.SIGTERM)

        result = cli_runner.invoke(tasks_worker_group, ["start"])

        assert result.exit_code == 0
        assert "All workers stopped" in result.output
        mock_runner.stop.assert_called_once()

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_stops_multiple_runners(self, mock_start, cli_runner):
        """All runners are stopped on shutdown."""
        runners = [MagicMock(), MagicMock(), MagicMock()]
        mock_start.return_value = runners

        _send_signal_after(0.1, signal.SIGINT)

        result = cli_runner.invoke(tasks_worker_group, ["start"])

        assert result.exit_code == 0
        assert "Workers: 3" in result.output
        for r in runners:
            r.stop.assert_called_once()

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_no_workers_exits_with_error(self, mock_start, cli_runner):
        """Exit code 1 when no workers can be started."""
        mock_start.return_value = []

        result = cli_runner.invoke(tasks_worker_group, ["start"])

        assert result.exit_code == 1
        assert "no workers started" in result.output

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_prints_banner(self, mock_start, mock_runner, cli_runner):
        """The startup banner includes PID, broker type, and worker count."""
        mock_start.return_value = [mock_runner]

        _send_signal_after(0.1, signal.SIGINT)

        result = cli_runner.invoke(tasks_worker_group, ["start"])

        assert "PID:" in result.output
        assert "Broker:" in result.output
        assert "Workers: 1" in result.output
        assert "Press Ctrl+C to stop" in result.output

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_log_level_option(self, mock_start, mock_runner, cli_runner):
        """The --log-level option is accepted."""
        mock_start.return_value = [mock_runner]

        _send_signal_after(0.1, signal.SIGINT)

        result = cli_runner.invoke(tasks_worker_group, ["start", "--log-level", "DEBUG"])

        assert result.exit_code == 0
        assert "Log:     DEBUG" in result.output

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_log_level_case_insensitive(self, mock_start, mock_runner, cli_runner):
        """--log-level accepts lowercase values."""
        mock_start.return_value = [mock_runner]

        _send_signal_after(0.1, signal.SIGINT)

        result = cli_runner.invoke(tasks_worker_group, ["start", "--log-level", "warning"])

        assert result.exit_code == 0
        assert "Log:     WARNING" in result.output

    @patch("fastpluggy_plugin.tasks_worker.start_workers_if_available")
    def test_start_runner_stop_exception_handled(self, mock_start, cli_runner):
        """Runner.stop() exceptions are caught gracefully."""
        import logging

        runner = MagicMock()
        runner.stop.side_effect = RuntimeError("broker gone")
        mock_start.return_value = [runner]

        _send_signal_after(0.1, signal.SIGINT)

        # Suppress the warning log to avoid I/O conflict with Click's test runner
        logging.getLogger("tasks_worker.cli").setLevel(logging.CRITICAL)
        try:
            result = cli_runner.invoke(tasks_worker_group, ["start"])
        finally:
            logging.getLogger("tasks_worker.cli").setLevel(logging.NOTSET)

        # Should still exit cleanly
        assert result.exit_code == 0
        assert "All workers stopped" in result.output


class TestStartWorkersIfAvailable:
    """Tests for the refactored start_workers_if_available function."""

    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.init_worker")
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.setup_broker")
    @patch("fastpluggy_plugin.tasks_worker.is_installed", return_value=True)
    def test_returns_list_of_runners(self, mock_installed, mock_setup, mock_init):
        from fastpluggy_plugin.tasks_worker import start_workers_if_available

        mock_runner = MagicMock()
        mock_init.return_value = mock_runner
        os.environ["WORKER_NUMBER"] = "2"

        try:
            result = start_workers_if_available()
            assert isinstance(result, list)
            assert len(result) == 2
            assert all(r is mock_runner for r in result)
        finally:
            os.environ.pop("WORKER_NUMBER", None)

    @patch("fastpluggy_plugin.tasks_worker.is_installed", return_value=False)
    def test_returns_empty_list_when_not_installed(self, mock_installed):
        from fastpluggy_plugin.tasks_worker import start_workers_if_available

        result = start_workers_if_available()
        assert result == []

    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.init_worker")
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.setup_broker")
    @patch("fastpluggy_plugin.tasks_worker.is_installed", return_value=True)
    def test_skips_none_runners(self, mock_installed, mock_setup, mock_init):
        """If init_worker returns None (error), it's excluded from the list."""
        from fastpluggy_plugin.tasks_worker import start_workers_if_available

        mock_init.return_value = None
        os.environ["WORKER_NUMBER"] = "1"

        try:
            result = start_workers_if_available()
            assert result == []
        finally:
            os.environ.pop("WORKER_NUMBER", None)
