import pytest
import uuid
from datetime import datetime, timedelta, timezone

from fastpluggy_plugin.tasks_worker.core.context import TaskContext
from fastpluggy_plugin.tasks_worker.core.events import TaskLifecycleEvent
from fastpluggy_plugin.tasks_worker.core.status import TaskStatus
from fastpluggy_plugin.tasks_worker.subscribers.db_adapter import DBPersistence
from fastpluggy_plugin.tasks_worker.persistence.models.report import TaskReportDB
from fastpluggy_plugin.tasks_worker.persistence.models.context import TaskContextDB
from fastpluggy_plugin.tasks_worker.persistence.repository.tasks import get_task_context_reports_and_format
from fastpluggy.core.database import session_scope


@pytest.fixture
def db_persistence():
    return DBPersistence()


def test_on_skipped_creates_report_if_missing(fast_pluggy, db_persistence):
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_task_skipped",
        func_name="test_func_skipped",
    )

    event = TaskLifecycleEvent(
        status=TaskStatus.SKIPPED,
        task_id=task_id,
        context=ctx,
        meta={"worker_id": "test_worker"}
    )

    with session_scope() as db:
        db.query(TaskReportDB).filter_by(task_id=task_id).delete()
        db.query(TaskContextDB).filter_by(task_id=task_id).delete()
        db.commit()

    db_persistence.on_skipped(event)

    with session_scope() as db:
        report = db.query(TaskReportDB).filter_by(task_id=task_id).first()
        assert report is not None, "Report should be created even if on_created was not called"
        assert report.status == TaskStatus.SKIPPED.value
        assert "concurrency lock" in report.logs


def test_on_created_creates_report(fast_pluggy, db_persistence):
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_task_created",
        func_name="test_func_created",
    )

    event = TaskLifecycleEvent(
        status=TaskStatus.CREATED,
        task_id=task_id,
        context=ctx,
        meta={"worker_id": "test_worker"}
    )

    with session_scope() as db:
        db.query(TaskReportDB).filter_by(task_id=task_id).delete()
        db.commit()

    db_persistence.on_created(event)

    with session_scope() as db:
        report = db.query(TaskReportDB).filter_by(task_id=task_id).first()
        assert report is not None
        assert report.status == TaskStatus.CREATED.value


def test_on_queued_updates_report(fast_pluggy, db_persistence):
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_task_queued",
        func_name="test_func_queued",
    )

    event = TaskLifecycleEvent(
        status=TaskStatus.QUEUED,
        task_id=task_id,
        context=ctx,
        meta={"worker_id": "test_worker"}
    )

    with session_scope() as db:
        db.query(TaskReportDB).filter_by(task_id=task_id).delete()
        db.commit()

    db_persistence.on_queued(event)

    with session_scope() as db:
        report = db.query(TaskReportDB).filter_by(task_id=task_id).first()
        assert report is not None
        assert report.status == TaskStatus.QUEUED.value


def test_wait_duration_calculation(fast_pluggy, db_persistence):
    """wait_duration = execution_start - enqueued_at in formatted output."""
    task_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    enqueued = now - timedelta(seconds=30)
    exec_start = now - timedelta(seconds=5)

    with session_scope() as db:
        db.add(TaskContextDB(
            task_id=task_id, task_name="test_wait", func_name="test_func_wait",
        ))
        db.add(TaskReportDB(
            task_id=task_id, function="test_func_wait", status="success",
            enqueued_at=enqueued, execution_start=exec_start,
            end_time=now, duration=5.0,
        ))
        db.commit()

    with session_scope() as db:
        results = get_task_context_reports_and_format(db, task_id=task_id)
        assert len(results) == 1
        assert results[0]["enqueued_at"] is not None
        assert results[0]["wait_duration"] == pytest.approx(25.0, abs=0.1)
        assert results[0]["execution_start"] is not None


def test_wait_duration_null_enqueued(fast_pluggy, db_persistence):
    """Pre-migration tasks with null enqueued_at => wait_duration is None."""
    task_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).replace(tzinfo=None)

    with session_scope() as db:
        db.add(TaskContextDB(
            task_id=task_id, task_name="test_null_wait", func_name="test_func_null",
        ))
        db.add(TaskReportDB(
            task_id=task_id, function="test_func_null", status="success",
            execution_start=now, end_time=now, duration=1.0,
        ))
        db.commit()

    with session_scope() as db:
        results = get_task_context_reports_and_format(db, task_id=task_id)
        assert len(results) == 1
        assert results[0]["enqueued_at"] is None
        assert results[0]["wait_duration"] is None


def test_wait_duration_via_events(fast_pluggy, db_persistence):
    """CREATED->QUEUED->RUNNING events produce a valid wait_duration."""
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_wait_events",
        func_name="test_func_wait_events",
    )

    db_persistence.on_created(TaskLifecycleEvent(
        status=TaskStatus.CREATED, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))
    db_persistence.on_queued(TaskLifecycleEvent(
        status=TaskStatus.QUEUED, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))
    db_persistence.on_running(TaskLifecycleEvent(
        status=TaskStatus.RUNNING, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))

    with session_scope() as db:
        results = get_task_context_reports_and_format(db, task_id=task_id)
        assert len(results) == 1
        assert results[0]["enqueued_at"] is not None
        assert results[0]["execution_start"] is not None
        assert results[0]["wait_duration"] is not None
        assert results[0]["wait_duration"] >= 0.0


def test_wait_duration_null_no_queued(fast_pluggy, db_persistence):
    """Skip QUEUED, go straight to RUNNING => enqueued_at and wait_duration are None."""
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_no_queued",
        func_name="test_func_no_queued",
    )

    db_persistence.on_running(TaskLifecycleEvent(
        status=TaskStatus.RUNNING, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))

    with session_scope() as db:
        results = get_task_context_reports_and_format(db, task_id=task_id)
        assert len(results) == 1
        assert results[0]["enqueued_at"] is None
        assert results[0]["wait_duration"] is None


def test_heartbeat_includes_system_metrics(fast_pluggy):
    """TaskRunner.send_heartbeat() includes cpu_pct and mem_pct in meta.system."""
    from unittest.mock import MagicMock, patch

    from fastpluggy_plugin.tasks_worker.core.runner import TaskRunner
    from fastpluggy.fastpluggy import FastPluggy

    fp = FastPluggy(app=None)
    bus = MagicMock()
    bus.get_instance = MagicMock(return_value=None)
    runner = TaskRunner(fp=fp, bus=bus)

    mock_broker = MagicMock()
    runner._broker = mock_broker

    with patch("psutil.cpu_percent", return_value=42.0), \
         patch("psutil.virtual_memory") as mock_vmem:
        mock_vmem.return_value.percent = 65.3
        runner.send_heartbeat(running=0, capacity=8)

    mock_broker.heartbeat.assert_called_once()
    call_kwargs = mock_broker.heartbeat.call_args
    meta = call_kwargs.kwargs.get("meta") or call_kwargs[1].get("meta", {})
    assert "system" in meta
    assert meta["system"]["cpu_pct"] == 42.0
    assert meta["system"]["mem_pct"] == 65.3


def test_on_progress_updates_report(fast_pluggy, db_persistence):
    """PROGRESS event persists pct and message to the report row."""
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_task_progress",
        func_name="test_func_progress",
    )

    # Create the report first
    db_persistence.on_created(TaskLifecycleEvent(
        status=TaskStatus.CREATED, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))
    db_persistence.on_running(TaskLifecycleEvent(
        status=TaskStatus.RUNNING, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))

    # Emit progress
    db_persistence.on_progress(TaskLifecycleEvent(
        status=TaskStatus.PROGRESS, task_id=task_id,
        context=ctx, meta={"pct": 42.5, "message": "Processing batch 3/7"},
    ))

    with session_scope() as db:
        report = db.query(TaskReportDB).filter_by(task_id=task_id).first()
        assert report is not None
        assert report.progress_pct == pytest.approx(42.5)
        assert report.progress_message == "Processing batch 3/7"
        assert report.progress_updated_at is not None


def test_progress_in_api_response(fast_pluggy, db_persistence):
    """progress_pct and progress_message appear in formatted API output."""
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_progress_api",
        func_name="test_func_progress_api",
    )

    db_persistence.on_created(TaskLifecycleEvent(
        status=TaskStatus.CREATED, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))
    db_persistence.on_running(TaskLifecycleEvent(
        status=TaskStatus.RUNNING, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))
    db_persistence.on_progress(TaskLifecycleEvent(
        status=TaskStatus.PROGRESS, task_id=task_id,
        context=ctx, meta={"pct": 75.0, "message": "Almost done"},
    ))

    with session_scope() as db:
        results = get_task_context_reports_and_format(db, task_id=task_id)
        assert len(results) == 1
        assert results[0]["progress_pct"] == pytest.approx(75.0)
        assert results[0]["progress_message"] == "Almost done"


def test_wait_duration_null_no_running(fast_pluggy, db_persistence):
    """QUEUED but not yet RUNNING => execution_start and wait_duration are None."""
    task_id = str(uuid.uuid4())
    ctx = TaskContext(
        task_id=task_id,
        task_name="test_no_running",
        func_name="test_func_no_running",
    )

    db_persistence.on_created(TaskLifecycleEvent(
        status=TaskStatus.CREATED, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))
    db_persistence.on_queued(TaskLifecycleEvent(
        status=TaskStatus.QUEUED, task_id=task_id,
        context=ctx, meta={"worker_id": "w1"},
    ))

    with session_scope() as db:
        results = get_task_context_reports_and_format(db, task_id=task_id)
        assert len(results) == 1
        assert results[0]["execution_start"] is None
        assert results[0]["wait_duration"] is None
