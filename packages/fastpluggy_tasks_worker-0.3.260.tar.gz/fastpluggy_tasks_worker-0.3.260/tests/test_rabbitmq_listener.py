"""Tests for RabbitMQ broker listener mode."""
import threading
from unittest.mock import MagicMock, patch

import pytest

from fastpluggy_plugin.tasks_worker.broker.rabbitmq import RabbitMQBroker


class TestListenerModeInit:
    """__init__ sets _listener_mode = True by default."""

    def test_listener_mode_default_true(self):
        broker = RabbitMQBroker("amqp://guest:guest@localhost:5672/")
        assert broker._listener_mode is True

    def test_instance_id_set(self):
        broker = RabbitMQBroker("amqp://guest:guest@localhost:5672/")
        assert isinstance(broker._instance_id, str)
        assert len(broker._instance_id) == 8


class TestRegisterWorkerClearsListenerMode:
    """register_worker() switches _listener_mode to False."""

    def test_register_worker_sets_false(self):
        broker = RabbitMQBroker("amqp://guest:guest@localhost:5672/")
        assert broker._listener_mode is True

        # Stub out the parts that need a real connection
        broker._broadcast_worker_event = MagicMock()
        broker.ensure_topic = MagicMock()
        broker._start_topic_consumer = MagicMock()

        broker.register_worker(
            "w-1",
            pid=1234,
            host="localhost",
            topics=["test"],
            capacity=1,
        )

        assert broker._listener_mode is False


class TestConnectQueueNaming:
    """_connect() uses mode-aware queue and connection names."""

    def _make_broker_and_connect(self, *, listener_mode: bool):
        """Create a broker and call _connect() with pika mocked."""
        broker = RabbitMQBroker("amqp://guest:guest@localhost:5672/")
        broker._listener_mode = listener_mode
        broker._connection = None  # force fresh connection

        mock_channel = MagicMock()
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel

        mock_params = MagicMock()

        with patch("fastpluggy_plugin.tasks_worker.broker.rabbitmq.pika") as mock_pika:
            mock_pika.URLParameters.return_value = mock_params
            mock_pika.BlockingConnection.return_value = mock_conn
            broker._connect()

        return broker, mock_channel, mock_params

    def test_listener_queue_prefix(self):
        """In listener mode, queue name starts with 'listener.'."""
        broker, mock_channel, _ = self._make_broker_and_connect(listener_mode=True)

        queue_declare_calls = mock_channel.queue_declare.call_args_list
        assert len(queue_declare_calls) >= 1
        queue_name = queue_declare_calls[-1].kwargs.get("queue")
        assert queue_name.startswith("listener."), f"Expected listener prefix, got: {queue_name}"
        assert broker._instance_id in queue_name

    def test_worker_queue_prefix(self):
        """After register_worker(), queue name starts with 'worker.'."""
        broker, mock_channel, _ = self._make_broker_and_connect(listener_mode=False)

        queue_declare_calls = mock_channel.queue_declare.call_args_list
        assert len(queue_declare_calls) >= 1
        queue_name = queue_declare_calls[-1].kwargs.get("queue")
        assert queue_name.startswith("worker."), f"Expected worker prefix, got: {queue_name}"
        assert broker._instance_id in queue_name

    def test_connection_name_listener(self):
        """Connection name reflects listener mode."""
        _, _, mock_params = self._make_broker_and_connect(listener_mode=True)
        assert mock_params.client_properties["connection_name"] == "fastpluggy-listener"

    def test_connection_name_worker(self):
        """Connection name reflects worker mode."""
        _, _, mock_params = self._make_broker_and_connect(listener_mode=False)
        assert mock_params.client_properties["connection_name"] == "fastpluggy-worker"
