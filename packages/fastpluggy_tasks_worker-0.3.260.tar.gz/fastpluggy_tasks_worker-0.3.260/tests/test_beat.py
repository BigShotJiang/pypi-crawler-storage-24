"""Tests for the --beat flag, scheduler refactor, and role column."""

import os
import threading
import unittest
from unittest.mock import MagicMock, call, patch


class TestInitWorkerBeat(unittest.TestCase):
    """init_worker() beat parameter controls scheduler submission."""

    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.get_broker")
    @patch("fastpluggy.fastpluggy.FastPluggy")
    @patch("fastpluggy_plugin.tasks_worker.core.runner.TaskRunner")
    @patch("fastpluggy_plugin.tasks_worker.core.events.TaskEventBus")
    @patch("fastpluggy_plugin.tasks_worker.subscribers.setup_persistence")
    @patch("fastpluggy_plugin.tasks_worker.config.TasksRunnerSettings")
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.submit")
    def test_beat_false_does_not_submit_scheduler(
        self, mock_submit, mock_settings_cls, mock_setup,
        mock_bus_cls, mock_runner_cls, mock_fp_cls, mock_get_broker,
    ):
        from fastpluggy_plugin.tasks_worker import TaskWorker

        mock_settings = MagicMock()
        mock_settings.enable_auto_task_discovery = False
        mock_settings.discover_celery_tasks = False
        mock_settings_cls.return_value = mock_settings

        mock_runner = MagicMock()
        mock_runner_cls.return_value = mock_runner
        mock_get_broker.return_value = MagicMock()

        TaskWorker.init_worker(beat=False)

        # schedule_loop should NOT be submitted
        for c in mock_submit.call_args_list:
            func = c[0][0] if c[0] else c[1].get("func")
            func_name = getattr(func, "__name__", str(func))
            assert func_name != "schedule_loop", "schedule_loop should not be submitted when beat=False"

    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.get_broker")
    @patch("fastpluggy.fastpluggy.FastPluggy")
    @patch("fastpluggy_plugin.tasks_worker.core.runner.TaskRunner")
    @patch("fastpluggy_plugin.tasks_worker.core.events.TaskEventBus")
    @patch("fastpluggy_plugin.tasks_worker.subscribers.setup_persistence")
    @patch("fastpluggy_plugin.tasks_worker.config.TasksRunnerSettings")
    @patch("fastpluggy_plugin.tasks_worker.TaskWorker.submit")
    def test_beat_true_submits_scheduler(
        self, mock_submit, mock_settings_cls, mock_setup,
        mock_bus_cls, mock_runner_cls, mock_fp_cls, mock_get_broker,
    ):
        from fastpluggy_plugin.tasks_worker import TaskWorker

        mock_settings = MagicMock()
        mock_settings.enable_auto_task_discovery = False
        mock_settings.discover_celery_tasks = False
        mock_settings_cls.return_value = mock_settings

        mock_runner = MagicMock()
        mock_runner_cls.return_value = mock_runner
        mock_get_broker.return_value = MagicMock()

        TaskWorker.init_worker(beat=True)

        # schedule_loop should be submitted
        submitted_names = [
            getattr(c[0][0], "__name__", str(c[0][0]))
            for c in mock_submit.call_args_list if c[0]
        ]
        assert "schedule_loop" in submitted_names, f"schedule_loop not found in submitted tasks: {submitted_names}"


class TestScheduleLoopSync(unittest.TestCase):
    """schedule_loop is now a sync function that respects shutdown_event."""

    def test_schedule_loop_is_sync(self):
        import asyncio
        from fastpluggy_plugin.tasks_worker.tasks.scheduler import schedule_loop
        assert not asyncio.iscoroutinefunction(schedule_loop), "schedule_loop should be a sync function"

    @patch("fastpluggy_plugin.tasks_worker.tasks.scheduler.session_scope")
    @patch("fastpluggy_plugin.tasks_worker.config.TasksRunnerSettings")
    def test_schedule_loop_stops_on_shutdown_event(self, mock_settings_cls, mock_session):
        from fastpluggy_plugin.tasks_worker.tasks.scheduler import schedule_loop

        mock_settings = MagicMock()
        mock_settings.scheduler_frequency = 0.01
        mock_settings_cls.return_value = mock_settings

        # Mock session to return no tasks
        mock_db = MagicMock()
        mock_db.execute.return_value.scalars.return_value.all.return_value = []
        mock_session.return_value.__enter__ = MagicMock(return_value=mock_db)
        mock_session.return_value.__exit__ = MagicMock(return_value=False)

        shutdown = threading.Event()

        # Run schedule_loop in a thread, signal shutdown after a brief delay
        def _run():
            schedule_loop(shutdown_event=shutdown)

        t = threading.Thread(target=_run)
        t.start()
        shutdown.set()
        t.join(timeout=5)
        assert not t.is_alive(), "schedule_loop did not stop after shutdown_event was set"


class TestAutoRestartWrapper(unittest.TestCase):
    """The beat subcommand wraps schedule_loop with auto-restart on crash."""

    def test_crash_and_restart(self):
        """Simulate schedule_loop crashing — verify it's called again."""
        call_count = 0

        def fake_schedule_loop(shutdown_event=None, **_kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("simulated crash")
            # Second call: stop
            if shutdown_event:
                shutdown_event.set()

        shutdown = threading.Event()

        # Reproduce the beat subcommand's auto-restart loop
        while not shutdown.is_set():
            try:
                fake_schedule_loop(shutdown_event=shutdown)
            except Exception:
                shutdown.wait(0.01)  # shortened for test

        assert call_count == 2, f"Expected 2 calls (crash + restart), got {call_count}"


class TestWorkerRoleInBroker(unittest.TestCase):
    """Broker register_worker and heartbeat accept role parameter."""

    def test_memory_broker_stores_role(self):
        from fastpluggy_plugin.tasks_worker.broker.memory import InMemoryBroker

        broker = InMemoryBroker()
        broker.register_worker(
            worker_id="test-beat",
            pid=123,
            host="localhost",
            topics=[],
            capacity=0,
            role="beat",
        )

        workers = broker.get_workers()
        assert len(workers) >= 1
        beat_worker = next(
            (w for w in workers
             if (w.get("worker_id") if isinstance(w, dict) else getattr(w, "worker_id", None)) == "test-beat"),
            None,
        )
        assert beat_worker is not None
        meta = beat_worker.get("meta") if isinstance(beat_worker, dict) else getattr(beat_worker, "meta", {})
        assert meta.get("role") == "beat"

    def test_memory_broker_heartbeat_updates_role(self):
        from fastpluggy_plugin.tasks_worker.broker.memory import InMemoryBroker

        broker = InMemoryBroker()
        broker.register_worker(
            worker_id="test-worker",
            pid=456,
            host="localhost",
            topics=["default"],
            capacity=4,
            role="worker",
        )
        broker.heartbeat("test-worker", running=2, capacity=4, role="worker")

        workers = broker.get_workers()
        worker = next(
            (w for w in workers
             if (w.get("worker_id") if isinstance(w, dict) else getattr(w, "worker_id", None)) == "test-worker"),
            None,
        )
        assert worker is not None


class TestBeatWarningLogic(unittest.TestCase):
    """Stale beat warning triggers when enabled tasks exist but no beat worker."""

    def test_no_beat_worker_with_enabled_tasks(self):
        """When enabled tasks exist but no beat worker, warning should show."""
        # Simulate the monitoring route logic
        workers = [
            {"worker_id": "worker-1", "role": "worker", "meta": {"role": "worker"}},
        ]
        has_enabled_tasks = True

        beat_alive = False
        for w in workers:
            meta = w.get("meta", {}) or {}
            role = meta.get("role", "") or w.get("role", "")
            if role == "beat":
                beat_alive = True
                break

        assert has_enabled_tasks and not beat_alive

    def test_beat_worker_registered(self):
        """When beat worker is registered, no warning."""
        workers = [
            {"worker_id": "worker-1", "role": "worker", "meta": {"role": "worker"}},
            {"worker_id": "beat-host-123", "role": "beat", "meta": {"role": "beat"}},
        ]

        beat_alive = False
        for w in workers:
            meta = w.get("meta", {}) or {}
            role = meta.get("role", "") or w.get("role", "")
            if role == "beat":
                beat_alive = True
                break

        assert beat_alive


if __name__ == "__main__":
    unittest.main()
