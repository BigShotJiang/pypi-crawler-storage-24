import warnings

import pytest
import torch

from typing import Optional

from srforge.data import Entry
from srforge.models import Model, SequentialModel
from srforge.transform import EntryTransform, DataTransform
from srforge.transform.data import Multiply
from srforge.transform.entry import RemoveFields, SetAttribute
from srforge.utils import IOSpec


class _AddOne(Model):
    def __init__(self):
        super().__init__()

    def _forward(self, x):
        return x + 1


class _TwoOut(Model):
    io_spec = IOSpec(required_inputs=("x", "g"), required_outputs=("sr", "aux"))

    def __init__(self):
        super().__init__()

    def _forward(self, x, g):
        return x + 1, g + 2


class _AddOneEntry(EntryTransform):

    def __init__(self, *, x_key: str = "x", y_key: str = "y"):
        self.x_key = x_key
        self.y_key = y_key
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        entry[self.y_key] = entry[self.x_key] + 1
        return entry


class _MaskOptional(EntryTransform):

    def __init__(
        self,
        *,
        x_key: str = "x",
        y_key: str = "y",
        mask_key: Optional[str] = None,
    ):
        self.x_key = x_key
        self.y_key = y_key
        self.mask_key = mask_key
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        value = entry[self.x_key]
        mask = entry[self.mask_key] if self.mask_key and self.mask_key in entry else None
        entry[self.y_key] = value if mask is None else value * mask
        return entry


class _OptionalOutput(EntryTransform):

    def __init__(
        self,
        *,
        x_key: str = "x",
        y_key: str = "y",
        mask_key: Optional[str] = None,
    ):
        self.x_key = x_key
        self.y_key = y_key
        self.mask_key = mask_key
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        entry[self.y_key] = entry[self.x_key] + 1
        if self.mask_key is not None:
            entry[self.mask_key] = entry[self.x_key] * 0
        return entry


class _NoWriteOutput(EntryTransform):

    def __init__(self, *, x_key: str = "x", y_key: str = "y"):
        self.x_key = x_key
        self.y_key = y_key
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        return entry


class TestSequentialModelModelSteps:
    def test_model_step_positional_mapping(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> y"])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.x, torch.tensor(1.0))

    def test_model_step_named_mapping_on_lhs(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["(x=x) -> m1 -> y"])
        entry = Entry(x=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(4.0))

    def test_model_step_positional_multi_output(self):
        seq = SequentialModel(modules={"m2": _TwoOut()}, flow=["(x, g) -> m2 -> (out, z)"])
        entry = Entry(x=torch.tensor(1.0), g=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.out, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(4.0))

    def test_model_step_unknown_input_key_raises(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"m1": _AddOne()}, flow=["(z=x) -> m1 -> y"])

    def test_model_step_named_output_raises(self):
        with pytest.raises(ValueError, match="Named output mapping.*not supported"):
            SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> (q=y)"])

    def test_model_step_mixed_positional_and_named_raises(self):
        with pytest.raises(ValueError, match="Cannot mix positional and named"):
            SequentialModel(modules={"m1": _AddOne()}, flow=["(x, x=z) -> m1 -> y"])

    def test_module_segment_parentheses_raises_migration(self):
        with pytest.raises(ValueError, match="Named input mapping goes on the LHS"):
            SequentialModel(modules={"m1": _AddOne()}, flow=[" -> m1(x=x) -> y"])

    def test_model_reuse_same_instance(self):
        model = _AddOne()
        seq = SequentialModel(modules={"m1": model}, flow=["x -> m1 -> y", "y -> m1 -> z"])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.x, torch.tensor(1.0))
        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(3.0))
        assert len(seq.models) == 1


class TestSequentialModelEntryTransforms:
    """EntryTransform steps are opaque — field keys set via constructor."""

    def test_entry_transform_basic(self):
        seq = SequentialModel(modules={"t1": _AddOneEntry(x_key="x", y_key="y")}, flow=[" -> t1 -> "])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_entry_transform_with_mask(self):
        seq = SequentialModel(
            modules={"t1": _MaskOptional(x_key="x", y_key="y", mask_key="mask")},
            flow=[" -> t1 -> "],
        )
        entry = Entry(x=torch.tensor(2.0), mask=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(1.0))

    def test_entry_transform_without_optional_mask(self):
        seq = SequentialModel(
            modules={"t1": _MaskOptional(x_key="x", y_key="y")},
            flow=[" -> t1 -> "],
        )
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_entry_transform_optional_output(self):
        seq = SequentialModel(
            modules={"t1": _OptionalOutput(x_key="x", y_key="y", mask_key="mask")},
            flow=[" -> t1 -> "],
        )
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(3.0))
        assert torch.allclose(out.mask, torch.tensor(0.0))

    def test_entry_transform_no_optional_output(self):
        seq = SequentialModel(
            modules={"t1": _OptionalOutput(x_key="x", y_key="y")},
            flow=[" -> t1 -> "],
        )
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(3.0))
        assert "mask" not in out

    def test_entry_transform_no_output(self):
        seq = SequentialModel(modules={"rm": RemoveFields(field_key="x")}, flow=[" -> rm -> "])
        entry = Entry(x=torch.tensor(1.0), y=torch.tensor(2.0))

        out = seq(entry)

        assert "x" not in out
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_entry_transform_output_only(self):
        seq = SequentialModel(modules={"set": SetAttribute(5, attr_key="y")}, flow=[" -> set -> "])
        entry = Entry()

        out = seq(entry)

        assert out.y == 5

    def test_entry_transform_remapped_keys(self):
        seq = SequentialModel(
            modules={"t1": _MaskOptional(x_key="a", y_key="result", mask_key="b")},
            flow=[" -> t1 -> "],
        )
        entry = Entry(a=torch.tensor(4.0), b=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.result, torch.tensor(2.0))


class TestSequentialModelDataTransforms:
    def test_data_transform_basic(self):
        seq = SequentialModel(modules={"mul": Multiply(3.0)}, flow=["x -> mul -> y"])
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(6.0))
        assert torch.allclose(out.x, torch.tensor(2.0))

    def test_data_transform_default_output(self):
        seq = SequentialModel(modules={"mul": Multiply(3.0)}, flow=["x -> mul -> "])
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.x, torch.tensor(6.0))

    def test_data_transform_multiple_fields_via_separate_lines(self):
        mul = Multiply(2.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["x -> mul -> x2", "y -> mul -> y2"],
        )
        entry = Entry(x=torch.tensor(2.0), y=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.x2, torch.tensor(4.0))
        assert torch.allclose(out.y2, torch.tensor(6.0))

    def test_data_transform_recursive(self):
        seq = SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x -> mul -> y"])
        entry = Entry(x={"a": torch.tensor(1.0), "b": torch.tensor(2.0)})

        out = seq(entry)

        assert torch.allclose(out.y["a"], torch.tensor(2.0))
        assert torch.allclose(out.y["b"], torch.tensor(4.0))

    def test_data_transform_named_mapping(self):
        seq = SequentialModel(modules={"mul": Multiply(2.0)}, flow=["(image=a) -> mul -> y"])
        entry = Entry(a=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(6.0))

    def test_data_transform_named_output_raises(self):
        with pytest.raises(ValueError, match="Named output mapping.*not supported"):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x -> mul -> (y=z)"])

    def test_data_transform_mixed_positional_and_named_raises(self):
        with pytest.raises(ValueError, match="Cannot mix positional and named"):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=["(a, data=b) -> mul -> y"])

    def test_data_transform_positional_input_count_mismatch_raises(self):
        with pytest.raises(ValueError, match="expects 1..1 inputs.*got 2"):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x, y -> mul -> z"])

    def test_data_transform_return_count_mismatch_raises(self):
        class _ReturnOne(DataTransform):
            def transform(self, data: torch.Tensor):
                return data + 1

        seq = SequentialModel(
            modules={"t": _ReturnOne()},
            flow=["(data=x) -> t -> (y, z)"],
        )
        entry = Entry(x=torch.tensor(1.0))

        with pytest.raises(ValueError, match="returned 1 value.*expects 2"):
            seq(entry)

    def test_data_transform_no_inputs_raises(self):
        with pytest.raises(ValueError, match="requires inputs in flow line"):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=[" -> mul -> y"])

    def test_data_transform_multi_param_positional(self):
        from srforge.transform.data import MatchReference
        seq = SequentialModel(
            modules={"m": MatchReference()},
            flow=["x, ref -> m -> matched"],
        )
        img = torch.randn(1, 3, 8, 8)
        ref = torch.randn(1, 3, 8, 8)
        entry = Entry(x=img, ref=ref)
        out = seq(entry)
        assert out.matched.shape == img.shape

    def test_data_transform_multi_param_positional_too_few_raises(self):
        from srforge.transform.data import MatchReference
        with pytest.raises(ValueError, match="expects 2..2 inputs.*got 1"):
            SequentialModel(modules={"m": MatchReference()}, flow=["x -> m -> y"])

    def test_data_transform_positional_multi_output(self):
        class _SplitTwo(DataTransform):
            def transform(self, image: torch.Tensor):
                return image[:, :1], image[:, 1:]

        seq = SequentialModel(
            modules={"s": _SplitTwo()},
            flow=["x -> s -> (a, b)"],
        )
        entry = Entry(x=torch.randn(1, 3, 4, 4))
        out = seq(entry)
        assert out.a.shape == (1, 1, 4, 4)
        assert out.b.shape == (1, 2, 4, 4)


class TestSequentialModelErrors:
    def test_unknown_module_raises(self):
        with pytest.raises(KeyError):
            SequentialModel(modules={"t1": _AddOneEntry(x_key="x", y_key="y")}, flow=["x -> missing -> y"])

    def test_duplicate_outputs_raise(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"m2": _TwoOut()}, flow=["x -> m2 -> (sr=out, aux=out)"])

    def test_missing_input_runtime_raises(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> y"])
        entry = Entry()

        with pytest.raises(KeyError):
            seq(entry)

    def test_output_collision_runtime_raises(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> y"])
        entry = Entry(x=torch.tensor(1.0), y=torch.tensor(0.0))

        with pytest.raises(KeyError):
            seq(entry)



class TestSequentialModelModuleReuse:
    """All module types can be reused with different mappings in the same flow."""

    def test_entry_transform_separate_instances(self):
        t1 = _AddOneEntry(x_key="a", y_key="b")
        t2 = _AddOneEntry(x_key="b", y_key="c")
        seq = SequentialModel(
            modules={"t1": t1, "t2": t2},
            flow=[" -> t1 -> ", " -> t2 -> "],
        )
        entry = Entry(a=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))
        assert torch.allclose(out.c, torch.tensor(3.0))

    def test_entry_transform_separate_instances_with_optional(self):
        t1 = _MaskOptional(x_key="a", y_key="b", mask_key="m")
        t2 = _MaskOptional(x_key="b", y_key="c")
        seq = SequentialModel(
            modules={"t1": t1, "t2": t2},
            flow=[" -> t1 -> ", " -> t2 -> "],
        )
        entry = Entry(a=torch.tensor(4.0), m=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))   # 4.0 * 0.5
        assert torch.allclose(out.c, torch.tensor(2.0))   # no mask, pass through

    def test_data_transform_reuse_different_fields(self):
        mul = Multiply(2.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["x -> mul -> x2", "y -> mul -> y2"],
        )
        entry = Entry(x=torch.tensor(3.0), y=torch.tensor(5.0))

        out = seq(entry)

        assert torch.allclose(out.x2, torch.tensor(6.0))
        assert torch.allclose(out.y2, torch.tensor(10.0))

    def test_data_transform_reuse_chained(self):
        mul = Multiply(2.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["x -> mul -> y", "y -> mul -> z"],
        )
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(4.0))

    def test_data_transform_reuse_multi_field(self):
        mul = Multiply(3.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["a -> mul -> a2", "b -> mul -> b2", "c -> mul -> c2"],
        )
        entry = Entry(a=torch.tensor(1.0), b=torch.tensor(2.0), c=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.a2, torch.tensor(3.0))
        assert torch.allclose(out.b2, torch.tensor(6.0))
        assert torch.allclose(out.c2, torch.tensor(9.0))

    def test_model_reuse_different_mappings(self):
        m = _AddOne()
        seq = SequentialModel(
            modules={"m1": m},
            flow=["a -> m1 -> b", "b -> m1 -> c"],
        )
        entry = Entry(a=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))
        assert torch.allclose(out.c, torch.tensor(3.0))


class TestSequentialModelFlowSpecVariants:
    def test_flow_spec_list_of_dicts(self):
        seq = SequentialModel(
            modules={"m1": _AddOne(), "t1": _AddOneEntry(x_key="y", y_key="z")},
            flow=[{"flow": "x -> m1 -> y"}, {"flow": " -> t1 -> "}],
        )
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(3.0))

    def test_flow_comments_and_whitespace(self):
        seq = SequentialModel(
            modules={"m1": _AddOne(), "t1": _AddOneEntry(x_key="y", y_key="z")},
            flow="""
                # comment
                x -> m1 -> y

                 -> t1 ->
            """,
        )
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.z, torch.tensor(3.0))

    def test_flow_as_single_string(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow="x -> m1 -> y")
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))


class TestSequentialModelBackwardCompat:
    """Old API (models= and flow-as-dict) still works with deprecation warnings."""

    def test_models_kwarg_deprecated(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            seq = SequentialModel(models={"m1": _AddOne()}, flow=["x -> m1 -> y"])
            deprecations = [x for x in w if issubclass(x.category, DeprecationWarning)]
            assert any("models" in str(d.message) for d in deprecations)

        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_flow_as_dict_deprecated(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            seq = SequentialModel(modules={"m1": _AddOne()}, flow={"flow": ["x -> m1 -> y"]})
            deprecations = [x for x in w if issubclass(x.category, DeprecationWarning)]
            assert any("dict" in str(d.message).lower() for d in deprecations)

        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_old_api_models_and_nested_flow(self):
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            seq = SequentialModel(
                models={"m1": _AddOne(), "t1": _AddOneEntry(x_key="y", y_key="z")},
                flow={"flow": ["x -> m1 -> y", " -> t1 -> "]},
            )

        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(3.0))

    def test_both_modules_and_models_raises(self):
        with pytest.raises(ValueError, match="Cannot specify both"):
            SequentialModel(
                modules={"m1": _AddOne()},
                models={"m1": _AddOne()},
                flow=["x -> m1 -> y"],
            )
