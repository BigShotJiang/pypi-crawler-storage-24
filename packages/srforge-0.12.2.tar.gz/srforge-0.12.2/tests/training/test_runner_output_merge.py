import pytest
import torch

from torch.utils.data import DataLoader, Dataset

from srforge.data import Entry
from srforge.loss import Loss
from srforge.training.runners import (
    EpochRunner, TrainingEpochRunner, ValidationEpochRunner, BenchmarkRunner,
)


class _DummyDataset(Dataset):
    def __len__(self):
        return 1

    def __getitem__(self, idx):
        return Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))


class _DictModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(1, 1, bias=False)
        torch.nn.init.constant_(self.linear.weight, 1.0)

    def forward(self, entry: Entry):
        x = entry["x"].view(-1, 1)
        y = self.linear(x).view(-1)
        return {"y": y}


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


def _make_loader():
    return DataLoader(_DummyDataset(), batch_size=1, shuffle=False, collate_fn=lambda batch: batch[0])


def test_training_runner_merges_dict_output_before_postprocessor():
    model = _DictModel()
    loss = _AbsDiff()
    seen = {}

    def postproc(entry: Entry):
        assert "y" in entry
        seen["y"] = entry["y"].detach().clone()
        return entry

    runner = TrainingEpochRunner(
        optimizer=torch.optim.SGD(model.parameters(), lr=0.1),
        device="cpu",
        postprocessor=[postproc],
    )

    scores = runner.run_epoch(model, _make_loader(), epoch=0, criterion=loss)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))
    assert "y" in seen
    assert torch.allclose(seen["y"], torch.tensor([1.0]))


def test_validation_runner_merges_dict_output():
    model = _DictModel()
    loss = _AbsDiff()

    runner = ValidationEpochRunner(device="cpu", postprocessor=[])

    scores = runner.run_epoch(model, _make_loader(), epoch=0, criterion=loss)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))


def test_benchmark_runner_merges_dict_output():
    model = _DictModel()
    loss = _AbsDiff()

    runner = BenchmarkRunner(device="cpu", postprocessor=[])

    scores = runner.run_epoch(model, _make_loader(), epoch=0, criterion=loss)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))


def test_benchmark_runner_no_criterion():
    """BenchmarkRunner with no criterion still runs without error."""
    model = _DictModel()

    runner = BenchmarkRunner(device="cpu", postprocessor=[])

    scores = runner.run_epoch(model, _make_loader(), epoch=0)
    assert scores.as_raw_dict() == {}


def test_validation_runner_requires_criterion():
    """ValidationEpochRunner raises ValueError when criterion is not passed."""
    model = _DictModel()
    runner = ValidationEpochRunner(device="cpu", postprocessor=[])
    with pytest.raises(ValueError, match="requires a criterion"):
        runner.run_epoch(model, _make_loader(), epoch=0)


# --- _forward_and_merge unit tests ---


class _EntryModel(torch.nn.Module):
    """Model that returns a full Entry (single-GPU path)."""
    def forward(self, entry):
        return Entry(x=entry["x"], t=entry["t"], y=entry["x"] * 2)


class _BadModel(torch.nn.Module):
    """Model that returns an unsupported type."""
    def forward(self, entry):
        return "not_a_valid_output"


class _ConcreteRunner(EpochRunner):
    """Minimal concrete runner to test _forward_and_merge directly."""
    def run_epoch(self, model, data_loader, epoch):
        raise NotImplementedError


def test_forward_and_merge_entry_output():
    """Model returning an Entry passes through directly."""
    runner = _ConcreteRunner()
    entry = Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))
    result = runner._forward_and_merge(_EntryModel(), entry, "cpu")
    assert isinstance(result, Entry)
    assert "y" in result
    assert torch.allclose(result["y"], torch.tensor([2.0]))


def test_forward_and_merge_dict_output():
    """Model returning a dict triggers merge_fields."""
    runner = _ConcreteRunner()
    entry = Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))
    result = runner._forward_and_merge(_DictModel(), entry, "cpu")
    assert isinstance(result, Entry)
    assert "y" in result


def test_forward_and_merge_unsupported_type_raises():
    """Model returning an unsupported type raises TypeError."""
    runner = _ConcreteRunner()
    entry = Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))
    with pytest.raises(TypeError, match="Unsupported model output type"):
        runner._forward_and_merge(_BadModel(), entry, "cpu")
