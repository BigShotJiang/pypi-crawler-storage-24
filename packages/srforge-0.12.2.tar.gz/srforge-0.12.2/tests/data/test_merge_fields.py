import pytest
import torch

from srforge.data.entry import Entry, GraphEntry
from srforge.data import _HAS_PYG

needs_pyg = pytest.mark.skipif(not _HAS_PYG, reason="torch-geometric not installed")


def test_merge_fields_entry_adds_fields_and_returns_same():
    entry = Entry(name="scene", x=torch.tensor([1.0]))
    out = entry.merge_fields({"y": torch.tensor([2.0])})

    assert out is entry
    assert "y" in entry
    assert "x" in entry
    assert torch.allclose(entry.x, torch.tensor([1.0]))
    assert torch.allclose(entry.y, torch.tensor([2.0]))
    assert set(entry.keys()) == {"name", "x", "y"}


def test_merge_fields_entry_rejects_overlap_with_source_and_name():
    entry = Entry(name="scene", x=torch.tensor([1.0]))

    with pytest.raises(KeyError) as exc:
        entry.merge_fields({"x": torch.tensor([2.0])}, source="model")

    msg = str(exc.value)
    assert "model" in msg
    assert "scene" in msg
    assert "x" in msg
    assert torch.allclose(entry.x, torch.tensor([1.0]))


def test_merge_fields_entry_allow_overwrite():
    entry = Entry(x=torch.tensor([1.0]))
    entry.merge_fields({"x": torch.tensor([3.0])}, allow_overwrite=True)

    assert torch.allclose(entry.x, torch.tensor([3.0]))
    assert set(entry.keys()) == {"name", "x"}


def test_merge_fields_none_returns_entry():
    entry = Entry(x=torch.tensor([1.0]))
    out = entry.merge_fields(None)

    assert out is entry
    assert set(entry.keys()) == {"name", "x"}


def test_merge_fields_non_mapping_raises_type_error():
    entry = Entry(x=torch.tensor([1.0]))

    with pytest.raises(TypeError, match="mapping"):
        entry.merge_fields([("y", torch.tensor([2.0]))])


@needs_pyg
def test_merge_fields_graph_entry():
    entry = GraphEntry(name="graph", x=torch.tensor([1.0]))
    out = entry.merge_fields({"y": torch.tensor([2.0])})

    assert out is entry
    assert "x" in entry and "y" in entry
    assert torch.allclose(entry.x, torch.tensor([1.0]))
    assert torch.allclose(entry.y, torch.tensor([2.0]))


@needs_pyg
def test_merge_fields_graph_entry_rejects_overlap():
    entry = GraphEntry(name="graph", x=torch.tensor([1.0]))

    with pytest.raises(KeyError, match="overwrite"):
        entry.merge_fields({"x": torch.tensor([2.0])}, source="model")


@needs_pyg
def test_merge_fields_graph_entry_none_is_noop():
    entry = GraphEntry(x=torch.tensor([1.0]))
    out = entry.merge_fields(None)
    assert out is entry
