import math
from pathlib import Path
from typing import Optional, Union, List, Literal

import cv2
import numpy as np
import torch
from imageio import v3 as iio

from srforge.registry import register_class
from srforge.observers.base import Observer
from srforge.events import runner as runner_events


def _to_hwc_numpy(tensor: torch.Tensor) -> np.ndarray:
    """Convert a BCHW tensor to a single HWC numpy array (first batch element)."""
    img = tensor[0].detach().cpu().numpy()  # C×H×W
    return np.transpose(img, (1, 2, 0))     # H×W×C


def _apply_transforms(tensor: torch.Tensor, transforms: list) -> torch.Tensor:
    """Apply a list of DataTransform instances to a tensor."""
    for t in transforms:
        tensor = t.transform(tensor)
    return tensor


@register_class
class BatchImageSaver(Observer):
    """Save processed images to disk, automatically scaling float to uint
    if you request an integer dtype.

    Args:
        batch_id: Which batches to save (int, list, or range).
        transforms: List of DataTransform instances applied to each image
            tensor before saving (e.g., CropBorder, CLAHE, Normalize).
        output_path: Directory for saved images.
        img_key: Entry field to save.
        ref_key: Optional reference field (unused after ImageProcessor removal).
        fmt: Image format.
        dtype: Output dtype.
    """
    EVENTS = [runner_events.RunnerBatchFinished, runner_events.RunnerEpochFinished]
    def __init__(
        self,
        batch_id: int | List[int] | range = None,
        transforms: list = None,
        output_path: Union[str, Path] = "./logs",
        img_key: str = "sr",
        fmt: str = "png",
        dtype: Union[str, np.dtype] = "uint8",
        **kwargs,
    ):
        super().__init__(**kwargs)
        if isinstance(batch_id, int):
            batch_id = [batch_id]
        if isinstance(batch_id, range):
            batch_id = list(batch_id)

        self.batch_id = batch_id
        self._transforms = transforms or []
        self.output_path = Path(output_path)
        self.img_key = img_key
        self.fmt = fmt.lstrip(".")
        self.dtype = np.dtype(dtype)
        self.step = -1

    def on_batch_finished(self, event: runner_events.RunnerBatchFinished):
        image_batch = event.entry[self.img_key]
        batch_size = image_batch.shape[0] if isinstance(image_batch, torch.Tensor) else list(image_batch.values())[0].shape[0]
        for i in range(batch_size):
            self.step += 1
            if self.batch_id is not None and self.step not in self.batch_id:
                continue

            if isinstance(image_batch, dict):
                for band, tensor in image_batch.items():
                    tensor = tensor[i:i+1]  # keep batch dim
                    self._save(tensor, event.entry.name[i], suffix=band)
            else:
                img_to_save = image_batch[i:i+1]  # keep batch dim
                self._save(img_to_save, event.entry.name[i], suffix=None)

    def on_runner_epoch_finished(self, event: runner_events.RunnerEpochFinished):
        self.step = -1

    def _save(
        self,
        img: torch.Tensor,
        name: str,
        suffix: Optional[str] = None,
    ):
        # 1) apply transforms
        img = _apply_transforms(img, self._transforms)

        # 2) BCHW → HWC numpy
        arr = _to_hwc_numpy(img)
        # 3) RGB → BGR for OpenCV
        if arr.ndim == 3 and arr.shape[2] == 3:
            arr = arr[..., ::-1]

        # 4) FLOAT→UINT scaling if needed
        if np.issubdtype(arr.dtype, np.floating) and np.issubdtype(self.dtype, np.integer):
            info = np.iinfo(self.dtype)
            arr = np.clip(arr, 0.0, 1.0)
            arr = (arr * info.max).round().astype(self.dtype)
        else:
            arr = arr.astype(self.dtype, copy=False)
        # 5) mkdir & filename
        if suffix:
            folder = self.output_path / name
            filename = f'{suffix}.{self.fmt}'
        else:
            folder = self.output_path
            filename = f'{name}.{self.fmt}'
        folder.mkdir(parents=True, exist_ok=True)

        path = folder / filename

        # 6) write out
        if np.issubdtype(self.dtype, np.integer) and self.dtype in (np.uint8, np.uint16):
            if not cv2.imwrite(str(path), arr):
                raise IOError(f"cv2 failed to write image to {path}")
        else:
            iio.imwrite(str(path), arr, extension=f'.{self.fmt}')


@register_class
class BatchImageLogger(Observer):
    """Log processed images to Weights & Biases.

    Args:
        batch_id: Which batches to log (int, list, or range).
        transforms: List of DataTransform instances applied to each image
            tensor before logging (e.g., CropBorder, CLAHE, Normalize).
        log_dir: W&B log directory name.
        img_key: Entry field to log.
        max_channels: Limit channel grid visualization.
        step_mode: 'epoch' or 'batch' for W&B logging step.
    """
    EVENTS = [runner_events.RunnerBatchFinished, runner_events.RunnerEpochFinished]
    def __init__(
        self,
        batch_id: int | List[int] | range = None,
        transforms: list = None,
        log_dir: str = 'val_pred',
        img_key: str = 'sr',
        max_channels: int = 16,
        step_mode: Literal['epoch', 'batch'] = 'epoch',
        tracker=None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if isinstance(batch_id, int):
            batch_id = [batch_id]
        if isinstance(batch_id, range):
            batch_id = list(batch_id)

        self.batch_id = batch_id
        self._transforms = transforms or []
        self.log_dir = log_dir
        self.img_key = img_key
        self.max_channels = max_channels
        self.step_mode = step_mode
        self.step = -1
        if tracker is None:
            from srforge.tracking import NullTracker
            tracker = NullTracker()
        self.tracker = tracker

    def _log_image(self, name: str, img: np.ndarray, step: int, caption: str = None):
        self.tracker.log_image(name, img, step=step, caption=caption)

    def _make_channel_grid(self, img: np.ndarray) -> np.ndarray:
        """Turn an (H, W, C) array into a grid of C single-channel images."""
        H, W, C = img.shape
        if C > self.max_channels:
            img = img[..., :self.max_channels]
            C = self.max_channels
        cols = math.ceil(math.sqrt(C))
        rows = math.ceil(C / cols)
        sep = max(1, int(min(H, W) * 0.05))
        grid_h = rows * H + (rows - 1) * sep
        grid_w = cols * W + (cols - 1) * sep
        grid = np.zeros((grid_h, grid_w), dtype=img.dtype)
        k = 0
        for r in range(rows):
            for c in range(cols):
                if k >= C:
                    break
                y0 = r * (H + sep)
                x0 = c * (W + sep)
                grid[y0:y0 + H, x0:x0 + W] = img[..., k]
                k += 1
        return grid

    def on_batch_finished(self, event: runner_events.RunnerBatchFinished):
        image_batch = event.entry[self.img_key]
        batch_size = image_batch.shape[0] if isinstance(image_batch, torch.Tensor) else list(image_batch.values())[0].shape[0]
        for i in range(batch_size):
            self.step += 1
            if self.batch_id is not None and self.step not in self.batch_id:
                continue
            names = event.entry.name
            caption = names[i] if isinstance(names, (list, tuple)) else names

            if isinstance(image_batch, dict):
                for band, tensor in image_batch.items():
                    tensor = tensor[i:i+1]  # keep batch dim
                    processed = _apply_transforms(tensor, self._transforms)
                    processed = self._make_channel_grid(_to_hwc_numpy(processed))
                    self._log_image(f"{self.log_dir}/{band}", processed, event.epoch if self.step_mode == 'epoch' else self.step, caption=caption)
            else:
                img_to_save = image_batch[i:i+1]  # keep batch dim
                processed = _apply_transforms(img_to_save, self._transforms)
                processed = self._make_channel_grid(_to_hwc_numpy(processed))
                self._log_image(f"{self.log_dir}", processed, event.epoch if self.step_mode == 'epoch' else self.step, caption=caption)

    def on_runner_epoch_finished(self, event: runner_events.RunnerEpochFinished):
        self.step = -1

