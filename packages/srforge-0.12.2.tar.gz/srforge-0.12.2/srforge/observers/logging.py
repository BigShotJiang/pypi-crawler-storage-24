import time
from typing import Any

import torch

import srforge.events.trainer
from srforge.loss import MetricScores
from srforge.registry import register_class
from .base import Observer
from srforge.events import runner as runner_events


@register_class
class LossLogger(Observer):
    """Observer that logs training and validation losses after each epoch.

    Args:
        tracker: Experiment tracker for logging metrics.
            Defaults to :class:`~srforge.tracking.NullTracker` if not provided.
    """

    EVENTS = [srforge.events.trainer.TrainerEpochFinished]

    def __init__(self, tracker: "ExperimentTracker | None" = None, **kwargs):
        super().__init__(**kwargs)
        if tracker is None:
            from srforge.tracking import NullTracker
            tracker = NullTracker()
        self.tracker = tracker

    def on_epoch_finished(self, event: srforge.events.trainer.TrainerEpochFinished) -> None:
        val_loss = event.val_loss.as_summary_dict()
        train_loss = event.train_loss.as_summary_dict()
        lr = {i: pg["lr"] for i, pg in enumerate(event.optimizer.param_groups)}
        self.tracker.log_metrics(
            {
                "validation_loss": val_loss,
                "training_loss": train_loss,
                "epoch": event.epoch,
                "learning_rate": lr,
            },
            step=event.epoch,
        )
        self.tracker.commit(step=event.epoch)


@register_class
class ProgressBar(Observer):
    """Observer that renders a text-based progress bar to stdout during training."""

    @staticmethod
    def _format_duration(seconds: float) -> str:
        """Format a duration in seconds as ``H:MM:SS`` (supports >24 h)."""
        total = int(round(seconds))
        h, remainder = divmod(total, 3600)
        m, s = divmod(remainder, 60)
        return f"{h}:{m:02d}:{s:02d}"

    class _BarState:
        """Internal mutable state for a single epoch's progress bar."""

        def __init__(self, total: int, prefix: str):
            self._total = total
            self._iter = 0
            self._prefix = prefix
            self._started = time.time()
            if total != 0:
                self.tick()

        def tick(self, loss: Any = None):
            length = 100
            decimals = 1
            current = min(100.0, 100.0 * self._iter / float(self._total))
            percent = ("{0:." + str(decimals) + "f}").format(current)
            filledLength = int(current)
            bar = 'X' * filledLength + '_' * (length - filledLength)
            elapsed_time = time.time() - self._started
            elapsed_str = ProgressBar._format_duration(elapsed_time)
            if self._iter != 0:
                seconds_per_iteration = round(elapsed_time / self._iter, 2)
                time_left = seconds_per_iteration * (self._total - self._iter)
                time_left = ProgressBar._format_duration(time_left)
            else:
                seconds_per_iteration = '-'
                time_left = '-'

            print(f'\r{self._prefix} ({self._iter}\\{self._total}) |{bar}| {percent}% '
                  f'[{elapsed_str}<{time_left}, {seconds_per_iteration}s/it] ' +
                  f'Loss - {loss}',
                  end='', flush=True)
            self._iter = self._iter + 1

        def finish(self):
            print()

    EVENTS = [runner_events.RunnerEpochStarted, runner_events.RunnerBatchFinished, runner_events.RunnerEpochFinished]

    def __init__(self, name: str, **kwargs):
        super().__init__(**kwargs)
        self._name = name
        self._sig_digits = 5
        self._pb = None

        self._sum: dict[str, torch.Tensor] = {}
        self._count: int = 0

    def on_epoch_started(self, event: runner_events.RunnerEpochStarted):
        self._pb = ProgressBar._BarState(total=event.num_batches,
                                         prefix= f"{self._name}({str(event.epoch).zfill(4)}):")
        self._sum = {}
        self._count = 0

    def on_batch_finished(self, event: runner_events.RunnerBatchFinished):
        if self._pb is None:
            return
        batch_scores: MetricScores = event.batch_scores
        batch_means = batch_scores.mean_weighted()        # dict[name -> scalar tensor]
        batch_total = batch_scores.total_weighted()  # scalar tensor

        batch_size = int(batch_total.shape[0]) if batch_total.ndim > 0 else 1
        batch_total = batch_total.mean()

        # update running sums
        for name, val in batch_means.items():
            if name not in self._sum:
                self._sum[name] = val.detach() * batch_size
            else:
                self._sum[name] += val.detach() * batch_size

        if "Total" not in self._sum:
            self._sum["Total"] = batch_total.detach() * batch_size
        else:
            self._sum["Total"] += batch_total.detach() * batch_size

        self._count += batch_size

        # epoch-so-far means
        epoch_means = {name: self._sum[name] / self._count for name in self._sum}
        tops = {k: v for k, v in epoch_means.items() if "." not in k}

        order = ["Total"] + sorted(k for k in tops if k != "Total")
        parts = [
            f"{name}: {format(tops[name].item(), f'.{self._sig_digits}g')}"
            for name in order
        ]
        loss_string = ", ".join(parts)
        self._pb.tick(loss_string)

    def on_epoch_finished(self, event: runner_events.RunnerEpochFinished) -> None:
        if self._pb is not None:
            self._pb.finish()
            self._pb = None
            self._sum = {}
            self._count = 0



