import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import hydra
import omegaconf

from srforge import GlobalSettings, init
from srforge.data.loader import DataLoaderFactory
from srforge.training.runners import BenchmarkRunner
from srforge.utils.checkpoint import load_model_weights, load_weights_from_tracker
from srforge.utils.multigpu import setup_device


@hydra.main(config_path="configs", config_name="benchmark-cfg", version_base=None)
def main(cfg) -> None:
    resolve = init(cfg, log_level=cfg.system.debug_level)
    settings = GlobalSettings()

    # -- Tracking ---------------------------------------------------------
    tracker = resolve(cfg.tracker)
    tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))

    print('Configuring benchmark...')
    print(f'Run ID: {tracker.run_id}')
    print(f'Run Name: {tracker.run_name}')
    print(f'Run path: {tracker.run_path}')

    # -- Model & metrics --------------------------------------------------
    model         = resolve(cfg.model)
    metrics       = resolve(cfg.test_metrics)
    postprocessor = resolve(cfg.postprocessing)
    test_dataset  = resolve(cfg.dataset)

    # -- Load trained weights ---------------------------------------------
    if cfg.weights.run_id is not None:
        load_weights_from_tracker(
            model, tracker, cfg.weights.run_id, best=cfg.weights.best,
        )
    elif cfg.weights.path is not None:
        load_model_weights(
            model,
            load_fn=lambda f: os.path.join(cfg.weights.path, f),
            suffix="_best" if cfg.weights.best else "_last",
        )

    model, device = setup_device(model, cfg.system.device)

    # -- Data loader ------------------------------------------------------
    test_loader = DataLoaderFactory(
        test_dataset, batch_size=1, shuffle=False,
        num_workers=0, device=cfg.system.device,
    ).get_loader()

    # -- Observers --------------------------------------------------------
    observers = resolve(cfg.observers)
    settings.event_bus.subscribe(observers)

    # -- Benchmark --------------------------------------------------------
    runner = BenchmarkRunner(device=device, postprocessor=postprocessor)
    runner.run_epoch(model=model, data_loader=test_loader, epoch=0, criterion=metrics)

    tracker.finish(0)


if __name__ == "__main__":
    main()
