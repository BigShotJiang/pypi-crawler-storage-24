import math
from typing import Dict

import torch
import torch_geometric as tg

from srforge.registry import register_class
from srforge.data import Entry, GraphEntry
from srforge.transform import EntryTransform, DataTransform
from srforge.utils.experimental import experimental


@register_class
@experimental
class MultibandToGraphEntry(EntryTransform):
    """Convert a multiband Entry (dict of per-band tensors) into a GraphEntry.

    Each band's pixels become graph nodes positioned in metric space using
    the band's ground sampling distance (GSD).  Bands with different spatial
    resolutions naturally produce nodes at different densities.

    The Entry field identified by *nodes_key* must be a
    ``dict[str, Tensor]`` mapping band names to ``(B, C, H, W)`` tensors
    (or ``(C, H, W)`` — a leading batch dim is added automatically).

    Produced GraphEntry attributes:

    * ``{nodes_key}`` — flattened node features ``(N_total, C)``
    * ``pos`` — ``(N_total, 2)`` positions in metres ``(y, x)``
    * ``band`` — ``(N_total, 1)`` integer band index per node
    * ``all_bands`` — list of band name strings
    * ``{nodes_key}_org`` — original dict (when ``nodes_key != "nodes"``)
    * all other Entry fields are carried over unchanged
    """

    def __init__(self, *, nodes_key: str = "nodes",
                 gsd_mapping: Dict[str, float] = None):
        super().__init__()
        self.nodes_key = nodes_key
        self.gsd_mapping = gsd_mapping or {}

    def transform(self, entry: Entry) -> GraphEntry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> GraphEntry:
        nodes_key = self.nodes_key
        nodes_value = entry[nodes_key]

        if not isinstance(nodes_value, dict):
            raise TypeError(
                f"MultibandToGraphEntry expects a dict for '{nodes_key}', "
                f"got {type(nodes_value).__name__}. "
                "Use MultiImageToGraphEntry for list/tensor inputs."
            )

        if not all(band in self.gsd_mapping for band in nodes_value):
            raise ValueError(
                "Not all bands in the entry have GSDs defined in gsd_mapping."
            )

        all_feats = []
        all_pos = []
        band_ids = []
        bands = []

        for b_idx, (band, gsd) in enumerate(self.gsd_mapping.items()):
            if band not in nodes_value:
                continue
            feats = nodes_value[band]
            if feats.dim() == 3:
                feats = feats.unsqueeze(0)
            if feats.dim() != 4:
                raise ValueError(
                    f"Invalid spatial dimensions for band {band}: "
                    f"{tuple(feats.shape)}"
                )
            B, C, H, W = feats.shape
            feats = feats.flatten(2).transpose(1, 2).reshape(-1, C)
            all_feats.append(feats)

            ys = (torch.arange(H, dtype=torch.float32) + 0.5) * gsd
            xs = (torch.arange(W, dtype=torch.float32) + 0.5) * gsd
            grid_y, grid_x = torch.meshgrid(ys, xs, indexing='ij')
            coords = torch.stack([grid_y.flatten(), grid_x.flatten()], dim=1)
            coords = coords.repeat(B, 1)
            all_pos.append(coords)

            band_ids.append(torch.full((B * H * W, 1), b_idx, dtype=torch.int))
            bands.append(band)

        node_feat = torch.cat(all_feats, dim=0)
        pos = torch.cat(all_pos, dim=0)
        band_id = torch.cat(band_ids, dim=0)

        data_kwargs = {
            nodes_key: node_feat,
            "pos": pos,
            "band": band_id,
            "name": entry.name,
            "all_bands": bands,
        }
        if nodes_key != "nodes":
            data_kwargs[f"{nodes_key}_org"] = nodes_value
        for key in entry.keys():
            if key in ("name", nodes_key):
                continue
            obj = entry[key]
            if key in data_kwargs:
                key = f"{key}_org"
            data_kwargs[key] = obj
        return GraphEntry(**data_kwargs)


@register_class
class MultiImageToGraphEntry(EntryTransform):
    """Convert a multi-image Entry (list/tensor of LR frames) into a GraphEntry.

    Used for multi-image super-resolution (MISR) where multiple shifted
    low-resolution observations of the same scene are fused via a graph
    neural network.

    Operates on a **single, unbatched** Entry (no batch dimension).
    PyG handles batching via ``Batch.from_data_list()`` at the DataLoader
    level.

    The Entry field identified by *nodes_key* can be:

    * ``list[Tensor]`` / ``tuple[Tensor]`` of K tensors each ``(C, H, W)``
    * ``Tensor`` of shape ``(C, H, W)`` (single image) or
      ``(C, K, H, W)`` (pre-stacked multi-image)

    When *translations_key* is set and the Entry contains per-image
    sub-pixel translations ``(K, 2)`` in ``(y, x)`` order, positions are
    adjusted so that nodes from different frames are offset according to
    their registration shifts (RadiusBuilder pattern).

    Produced GraphEntry attributes:

    * ``{nodes_key}`` — flattened node features ``(K*H*W, C)``
    * ``{nodes_key}_org`` — original tensor before flattening
    * ``{nodes_key}_org_shape`` — ``(1, ndim)`` shape metadata for
      reconstruction (leading dim for PyG batching)
    * ``pos`` — ``(K*H*W, 2)`` node coordinates (optionally adjusted)
    * ``cluster`` — ``(K*H*W,)`` maps each node to its pixel index
      in the H×W grid
    * all other Entry fields are carried over (spatial tensors get a
      leading dim for PyG batching)
    """

    def __init__(self, *, nodes_key: str = "lrs",
                 translations_key: str = None,
                 add_pos: bool = True,
                 adjust_pos: bool = True):
        super().__init__()
        self.nodes_key = nodes_key
        self.translations_key = translations_key
        self.add_pos = add_pos
        self.adjust_pos = adjust_pos

    def transform(self, entry: Entry) -> GraphEntry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> GraphEntry:
        nodes_key = self.nodes_key
        nodes_value = entry[nodes_key]

        if isinstance(nodes_value, dict):
            raise TypeError(
                f"MultiImageToGraphEntry expects a list or tensor for "
                f"'{nodes_key}', got dict. "
                "Use MultibandToGraphEntry for dict inputs."
            )

        # List/tuple of K tensors (C, H, W) → stack to (C, K, H, W)
        if isinstance(nodes_value, (list, tuple)):
            nodes_value = torch.stack(nodes_value, dim=1)  # (C, K, H, W)

        nodes_org = nodes_value

        if nodes_org.dim() == 3:
            # Single image (C, H, W) → K=1
            C, H, W = nodes_org.shape
            K = 1
        elif nodes_org.dim() == 4:
            # Multi-image (C, K, H, W)
            C, K, H, W = nodes_org.shape
        else:
            raise ValueError(
                f"Expected 3D (C, H, W) or 4D (C, K, H, W) tensor for "
                f"'{nodes_key}', got {nodes_org.dim()}D."
            )

        nodes = _flatten_to_nodes(nodes_org)  # (K*H*W, C) or (H*W, C)

        result_kwargs = {}
        for key in entry.keys():
            if key == nodes_key:
                continue
            val = entry[key]
            if isinstance(val, torch.Tensor) and val.shape == nodes_org.shape:
                # Co-flatten tensors with same shape (e.g. masks)
                val = _flatten_to_nodes(val)
            elif isinstance(val, torch.Tensor) and val.dim() >= 3:
                # Add leading dim for graph-level spatial tensors (e.g. hr)
                # so PyG batching concatenates along dim 0
                val = val.unsqueeze(0)
            result_kwargs[key] = val

        result_kwargs[nodes_key] = nodes
        result_kwargs[f"{nodes_key}_org"] = nodes_org
        result_kwargs[f"{nodes_key}_org_shape"] = (
            torch.tensor(nodes_org.shape).unsqueeze(0)
        )

        # Cluster: maps each node to its pixel index in the H×W grid
        cluster = torch.arange(H * W).repeat(K)
        result_kwargs["cluster"] = cluster

        if self.add_pos:
            pos = _pos_grid(K, H, W)

            # Apply per-image translation offsets (RadiusBuilder pattern)
            if (self.adjust_pos
                    and self.translations_key is not None
                    and self.translations_key in entry):
                translations = entry[self.translations_key]
                if not isinstance(translations, torch.Tensor):
                    translations = torch.tensor(translations,
                                                dtype=torch.float32)
                # Convention: swap (y, x) → (x, y) and negate y for image
                # coordinates where y=0 is top
                translations = translations[:, [1, 0]]
                translations[:, 1] = -translations[:, 1]
                pos = pos + torch.repeat_interleave(
                    translations, H * W, dim=0
                )

            result_kwargs["pos"] = pos

        return GraphEntry(**result_kwargs)


@register_class
class UnflattenNodes(DataTransform):
    """Reshape flat graph nodes back to channels-first spatial form.

    Takes a ``(K*H*W, F)`` node tensor and reshapes it to ``(F, K, H, W)``
    (or ``(F, H, W)`` for single-image graphs).  The feature dimension ``F``
    is read from the tensor itself, so the same ``shape`` reference can be
    reused for tensors with different feature counts (e.g. ``lrs`` with
    ``F=C`` and ``pos`` with ``F=2``).

    Reads the spatial dimensions from the ``shape`` input (the
    ``{nodes_key}_org_shape`` field stored by MultiImageToGraphEntry).

    Example YAML config::

        - _target: srforge.transform.graph.UnflattenNodes
          io:
            inputs:
              - {nodes: lrs, shape: lrs_org_shape}
              - {nodes: pos, shape: lrs_org_shape}
            outputs: [lrs_unflat, pos_unflat]
    """

    def transform_unbatched(self, nodes: torch.Tensor,
                            shape: torch.Tensor) -> torch.Tensor:
        spatial = shape.squeeze(0).tolist()[1:]  # [K, H, W] or [H, W]
        F = nodes.shape[-1]                      # actual feature dim

        # (K*H*W, F) → (*spatial, F) → (F, *spatial)
        return nodes.reshape(*spatial, F).movedim(-1, 0)


def _pos_grid(K, H, W):
    """Create a ``(K*H*W, 2)`` pixel-coordinate grid for K images of size H×W.

    Positions use image coordinates where ``(0, 0)`` is top-left.
    The H×W grid is repeated K times (once per image).
    """
    _, pos = tg.utils.grid(H, W, dtype=torch.float32)
    pos[:, [0, 1]] = pos[:, [1, 0]]
    pos[:, 0] = H - pos[:, 0] - 1.0
    pos = pos.repeat(K, 1)
    return pos


def _flatten_to_nodes(tensor):
    """Flatten channels-first spatial tensor to ``(N, C)`` node features.

    * ``(C, H, W)`` → ``(H*W, C)``
    * ``(C, K, H, W)`` → ``(K*H*W, C)``
    """
    C = tensor.shape[0]
    if tensor.dim() == 3:
        # (C, H, W) → (H, W, C) → (H*W, C)
        return tensor.permute(1, 2, 0).reshape(-1, C)
    if tensor.dim() == 4:
        # (C, K, H, W) → (K, H, W, C) → (K*H*W, C)
        return tensor.permute(1, 2, 3, 0).reshape(-1, C)
    raise ValueError(f"Expected 3D or 4D tensor, got {tensor.dim()}D")
