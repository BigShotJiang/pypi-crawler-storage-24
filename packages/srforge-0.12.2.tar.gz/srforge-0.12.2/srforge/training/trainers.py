"""Trainers — orchestrate the epoch loop over training and validation runners."""
import abc
from typing import Union
import logging

import torch.optim.lr_scheduler
from torch.utils import data
from torch import optim

import srforge.events.trainer
from srforge.training import stop, schedule
from srforge.training import runners
from srforge.events import trainer as trainer_events
from srforge import observers
from srforge.observers.bus import EventBus
from srforge.models import Model
from srforge.loss.schedule import LossScheduler, Loss
from srforge.registry import register_class


logger = logging.getLogger(__name__)

class Trainer(abc.ABC, observers.Observable):
    @abc.abstractmethod
    def train(self, epochs: int, training_loader, validation_loader):
        """
        Performs training of a model.
        """


@register_class
class PyTorchTrainer(Trainer):
    """Orchestrates the training loop over training and validation runners.

    The trainer owns the loss criteria and passes them to the runners at
    call time via ``runner.run_epoch(criterion=...)``.  It also manages
    the LR scheduler, early stopping, and checkpoint restoration.

    Args:
        model: The model to train.  Any ``torch.nn.Module`` works;
            :class:`~srforge.models.Model` provides additional
            Entry-based routing.
        training_epoch_runner: Runner that executes one training epoch
            (typically :class:`~srforge.training.runners.TrainingEpochRunner`).
        validation_epoch_runner: Runner that executes one validation
            epoch (typically
            :class:`~srforge.training.runners.ValidationEpochRunner`).
        training_criterion: Loss or :class:`LossScheduler` used during
            the training phase.  Passed to the training runner each epoch.
        validation_criterion: Loss or :class:`LossScheduler` used
            during the validation phase.  Passed to the validation
            runner each epoch.
        lr_scheduler: Any ``torch.optim.lr_scheduler.LRScheduler``.
            Stepped once per epoch after both runners finish.  ``None``
            means constant learning rate.
        stop_condition: A :class:`~srforge.training.stop.StopCondition`
            checked after each epoch.  Defaults to
            :class:`~srforge.training.stop.NoCondition` (train for all
            epochs).
    """

    def __init__(self, model: Union[Model, torch.nn.Module],
                 training_epoch_runner: runners.EpochRunner,
                 validation_epoch_runner: runners.EpochRunner,
                 training_criterion: Union[Loss, LossScheduler],
                 validation_criterion: Union[Loss, LossScheduler],
                 lr_scheduler: torch.optim.lr_scheduler.LRScheduler = None,
                 stop_condition: stop.StopCondition = stop.NoCondition()):
        super().__init__()
        self.model = model
        self.training_runner = training_epoch_runner
        self.validation_runner = validation_epoch_runner
        self.training_criterion = training_criterion
        self.validation_criterion = validation_criterion
        self.stop_condition = stop_condition
        self.initial_epoch = 0
        self.best_losses = None
        self.lr_scheduler = lr_scheduler or schedule.BlankLRScheduler()
    @property
    def event_bus(self) -> EventBus:
        """The shared event bus for this training session."""
        return self._event_bus

    def restore(self, checkpoint: "CheckpointState | None") -> None:
        """Apply a checkpoint to this trainer.

        Sets ``initial_epoch``, ``best_losses``, and restores the GradScaler
        state if present.  Accepts ``None`` (no-op for fresh runs).

        Args:
            checkpoint: A :class:`~srforge.utils.checkpoint.CheckpointState`
                returned by :func:`~srforge.utils.checkpoint.resume_from_checkpoint`,
                or ``None``.
        """
        if checkpoint is None:
            return
        self.initial_epoch = checkpoint.epoch + 1
        self.best_losses = checkpoint.best_losses
        if checkpoint.scaler_state is not None:
            self.training_runner.scaler.load_state_dict(checkpoint.scaler_state)

    def train(self, epochs: int,
              training_loader: data.DataLoader,
              validation_loader: data.DataLoader):
        self.notify(trainer_events.TrainingBegan(
            total_epochs=epochs,
            initial_epoch=self.initial_epoch,
            train_batches_per_epoch=len(training_loader),
            val_batches_per_epoch=len(validation_loader),
            best_losses=self.best_losses,
        ))
        for epoch in range(self.initial_epoch, epochs):
            if isinstance(self.training_criterion, LossScheduler):
                self.training_criterion.update(epoch)
            if isinstance(self.validation_criterion, LossScheduler):
                self.validation_criterion.update(epoch)

            loss = self.training_runner.run_epoch(
                self.model, training_loader, epoch, criterion=self.training_criterion,
            )
            val_loss = self.validation_runner.run_epoch(
                self.model, validation_loader, epoch, criterion=self.validation_criterion,
            )

            self.notify(trainer_events.TrainerEpochFinished(
                optimizer=self.training_runner.optimizer,
                lr_scheduler=self.lr_scheduler,
                model=self.model,
                train_loss=loss,
                val_loss=val_loss,
                epoch=epoch,
                scaler=self.training_runner.scaler
            ))

            val_loss_total_mean = val_loss.total_weighted().mean()
            if isinstance(self.lr_scheduler, optim.lr_scheduler.ReduceLROnPlateau):
                self.lr_scheduler.step(val_loss_total_mean)
            else:
                self.lr_scheduler.step()
            if self.stop_condition.is_condition_satisfied(epoch, loss.total_weighted().mean().item(), val_loss_total_mean.item()):
                break