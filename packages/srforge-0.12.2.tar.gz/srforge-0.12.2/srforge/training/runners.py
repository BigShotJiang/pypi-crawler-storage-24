"""
Individual runners i.e. classes that execute epochs in a training process.

"""
import os
from typing import Union, Optional

from typing import List

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import abc
import logging

import torch
from torch.utils import data
from torch import optim
from torch import nn
try:
    from torch_geometric.data import Batch
except ImportError:
    Batch = None
from torch.amp import GradScaler
from torch.amp import autocast

from srforge.events import runner as runner_events
from srforge import observers
from srforge.loss import Loss
from srforge.loss.schedule import LossScheduler
from srforge.loss.storage import MetricScores

#: Type alias for anything callable as a loss criterion.
Criterion = Union[Loss, LossScheduler]
from srforge.models import Model
from srforge.data.entry import Entry, GraphEntry
from srforge.registry import register_class

logger = logging.getLogger(__name__)

class EpochRunner(abc.ABC, observers.Observable):
    """
    Base class defining an interface for running a single pass through the whole input dataset
    """
    _scope: str = ""

    @property
    def scope(self) -> str:
        """Scope tag used by :class:`EventBus` for filtering."""
        return self._scope

    def __init__(self, scope: str = None):
        if scope is not None:
            self._scope = scope
        observers.Observable.__init__(self)

    def _forward_and_merge(self, model, entry, device):
        """Run model forward pass and merge output into the entry.

        Handles two execution paths:

        * **Single GPU** — ``Model.forward`` receives an Entry/GraphEntry,
          merges internally, and returns the updated Entry.
        * **Multi-GPU** (``DataParallel`` + ``DataListLoader``) — model
          receives a list, ``DataParallel`` splits across GPUs.  The
          gathered output is a raw dict of tensors.  The runner batches
          the original list post-forward and merges manually.
        """
        if not isinstance(entry, list):
            entry = entry.to(device)
        output = model(entry)
        if isinstance(entry, list):
            entry = Batch.from_data_list(entry).to(device)
        if isinstance(output, (Entry, GraphEntry)):
            return output
        if isinstance(output, dict):
            return entry.merge_fields(output, source="model")
        raise TypeError(f"Unsupported model output type: {type(output)}")

    @abc.abstractmethod
    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int) -> MetricScores:
        """
        :param model: Model to run epoch on.
        :param data_loader: Loader return batches of tuples (input, label)
        :param epoch: Current epoch index.
        :return: Epoch loss
        """


@register_class
class TrainingEpochRunner(EpochRunner):
    """Runner that executes one training epoch with backward pass and optimizer steps.

    The criterion is **not** stored on the runner — it is passed to
    :meth:`run_epoch` at call time by the :class:`PyTorchTrainer`.

    Args:
        optimizer: Optimizer instance (e.g. ``torch.optim.AdamW``).
        device: Device to move entries to before the forward pass
            (e.g. ``"cpu"``, ``"cuda:0"``, or a ``torch.device``).
        postprocessor: List of callables applied to the entry after the
            forward pass and before loss computation (e.g. clamping,
            denormalization).  ``None`` means no postprocessing.
        mixed_precision: Enable automatic mixed precision (AMP).  When
            ``True``, the forward pass runs inside ``torch.autocast``
            and a ``GradScaler`` handles loss scaling for the backward pass.
        gradient_accumulation_steps: Number of batches over which to
            accumulate gradients before an optimizer step.  The loss is
            divided by this value before ``.backward()``.  Effective
            batch size = ``batch_size * gradient_accumulation_steps``.
        scope: Event scope tag (default ``"train"``).  Observers
            subscribed with a matching scope receive this runner's events.
    """
    _scope = "train"

    def __init__(self,
                 optimizer: optim.Optimizer,
                 device: Union[torch.device, str] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 gradient_accumulation_steps: int = 1,
                 scope: str = None,
                 **kwargs):
        super().__init__(scope=scope)
        self.optimizer = optimizer
        self._device = device
        self.postprocessor = postprocessor or []

        self.mixed_precision = mixed_precision
        self.scaler = GradScaler(self._device, enabled=mixed_precision)
        self.gradient_accumulation_steps = max(1, gradient_accumulation_steps)
        self._kwargs = kwargs

    def run_epoch(self, model: Model, data_loader: data.DataLoader, epoch: int,
                  criterion: Criterion = None) -> MetricScores:
        model.train(True)
        score_accumulator = MetricScores.empty()

        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))

        # initialize grads to zero *once*
        self.optimizer.zero_grad(set_to_none=True)
        with torch.autograd.set_detect_anomaly(True):
            for batch_idx, entry in enumerate(data_loader):
                torch.cuda.memory.empty_cache()

                with autocast('cuda', enabled=self.mixed_precision):
                    entry = self._forward_and_merge(model, entry, self._device)
                    for t in self.postprocessor:
                        entry = t(entry)

                    # compute losses
                    batch_scores = criterion(entry)
                    total_loss = batch_scores.total_weighted()

                # ---- GRADIENT ACCUMULATION LOGIC ----
                # scale down the loss so that over N steps it's equivalent to one big batch
                accum_loss = total_loss / self.gradient_accumulation_steps
                self.scaler.scale(accum_loss.mean()).backward()

                # only step & zero every N batches (or on last batch)
                is_last_batch = (batch_idx == len(data_loader) - 1)
                if ((batch_idx + 1) % self.gradient_accumulation_steps == 0) or is_last_batch:
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    logger.debug(f"Optimizer step at batch {batch_idx}.")

                # log & accumulate
                score_accumulator.add_scores(batch_scores.detached())

                self.notify(runner_events.RunnerBatchFinished(
                    epoch=epoch,
                    batch=batch_idx,
                    entry=entry,
                    batch_scores=batch_scores,
                    criterion=criterion,
                    epoch_scores=score_accumulator
                ))

                # free memory
                del entry, batch_scores, total_loss, accum_loss

        # finalize: epoch-level means
        self.notify(runner_events.RunnerEpochFinished(
            epoch=epoch,
            epoch_scores=score_accumulator
        ))

        return score_accumulator

class InferenceRunner(EpochRunner):
    """Base for non-training runners (no backward pass).

    Runs the model under ``torch.no_grad()`` and optionally scores each
    batch with a criterion.  The criterion is passed to :meth:`run_epoch`
    at call time, not stored on the runner.

    Args:
        device: Device to move entries to before the forward pass
            (e.g. ``"cpu"``, ``"cuda:0"``, or a ``torch.device``).
        postprocessor: List of callables applied to the entry after the
            forward pass (e.g. clamping, denormalization).  ``None``
            means no postprocessing.
        mixed_precision: Enable automatic mixed precision (AMP).
        scope: Event scope tag.  Observers subscribed with a matching
            scope receive this runner's events.
    """

    def __init__(self, *,
                 device: Union[str, torch.device] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 scope: str = None):
        super().__init__(scope=scope)
        self._device = device
        self.postprocessor = postprocessor or []
        self.mixed_precision = mixed_precision

    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int,
                  criterion: Optional[Criterion] = None) -> MetricScores:
        model.train(False)
        score_accumulator = MetricScores.empty()
        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))
        with torch.no_grad():
            with autocast('cuda', enabled=self.mixed_precision):
                for batch_idx, entry in enumerate(data_loader):
                    torch.cuda.memory.empty_cache()
                    entry = self._forward_and_merge(model, entry, self._device)
                    for t in self.postprocessor:
                        entry = t(entry)
                    if criterion is not None:
                        batch_scores = criterion(entry)
                        score_accumulator.add_scores(batch_scores.detached())
                    else:
                        batch_scores = MetricScores.empty()

                    self.notify(runner_events.RunnerBatchFinished(
                        epoch=epoch,
                        batch=batch_idx,
                        entry=entry,
                        batch_scores=batch_scores,
                        criterion=criterion,
                        epoch_scores=score_accumulator
                    ))

                    del entry, batch_scores
                self.notify(runner_events.RunnerEpochFinished(
                    epoch=epoch,
                    epoch_scores=score_accumulator
                ))
        return score_accumulator


@register_class
class ValidationEpochRunner(InferenceRunner):
    """Inference runner for validation.

    Identical to :class:`InferenceRunner` but enforces that a criterion
    is passed to :meth:`run_epoch` (raises ``ValueError`` otherwise).

    Constructor accepts the same parameters as :class:`InferenceRunner`.
    Default scope is ``"val"``.
    """
    _scope = "val"

    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int,
                  criterion: Criterion = None) -> MetricScores:
        if criterion is None:
            raise ValueError("ValidationEpochRunner requires a criterion.")
        return super().run_epoch(model, data_loader, epoch, criterion=criterion)


@register_class
class BenchmarkRunner(InferenceRunner):
    """Inference runner for benchmarking.

    Criterion is optional — omit it for inference-only runs where only
    model outputs are needed (e.g. saving images).

    Constructor accepts the same parameters as :class:`InferenceRunner`.
    Default scope is ``"benchmark"``.
    """
    _scope = "benchmark"
