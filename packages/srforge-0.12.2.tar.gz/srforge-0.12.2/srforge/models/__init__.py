import abc
import logging
import inspect
import warnings
from typing import Tuple, Union, List, Dict, Any, overload

import torch

from srforge.data import Entry, GraphEntry
from srforge.transform import EntryTransform, DataTransform
from srforge.utils import obj_to_str, IOSpec, IOModule
from srforge.registry import register_class
from srforge.utils.io_parsing import parse_io_config, build_applications

try:
    import graphviz
except ImportError:
    graphviz = None

logger = logging.getLogger(__name__)

class Model(IOModule, torch.nn.Module, abc.ABC):
    _install_io_ports = False

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        has_forward = 'forward' in cls.__dict__
        has_private = '_forward' in cls.__dict__
        if has_forward and has_private:
            raise TypeError(
                f"Class {cls.__name__} defines both 'forward' and '_forward'. "
                f"Define only one — 'forward' is recommended."
            )
        if has_forward:
            # Transparently move the user's forward() to _forward() so that
            # Model.forward (the IO routing layer) is inherited unchanged.
            cls._forward = cls.__dict__['forward']
            delattr(cls, 'forward')

    def __init__(
        self,
        name: str = None,
        io_spec: IOSpec | None = None,
    ):
        """Initialize the model and optionally attach its IO contract."""
        super().__init__()
        self._name = name
        # Resolve the IO spec from an explicit instance or a class-level declaration.
        if io_spec is not None:
            if not isinstance(io_spec, IOSpec):
                raise TypeError(f"io_spec must be an IOSpec, got {type(io_spec)}.")
            self.io_spec = io_spec
        elif isinstance(getattr(self.__class__, "io_spec", None), IOSpec):
            self.io_spec = self.__class__.io_spec
        # Safety check: forward() should always resolve to Model.forward (the routing layer).
        # __init_subclass__ handles the rename, so this only triggers on manual monkey-patching.
        if self.__class__.forward is not Model.forward:
            raise RuntimeError(
                f"Class {self.__class__.__name__}: 'forward' was not processed correctly. "
                f"Define forward() in the class body (not assigned after class creation)."
            )
        # Cache the _forward signature for IO binding/inference.
        self._signature = inspect.signature(self._forward)

        # Ensure io_spec is never None — auto-create from signature if needed.
        spec = self.io_spec
        if spec is None:
            _, required, optional = self._infer_input_names()
            spec = IOSpec(required_inputs=tuple(required), optional_inputs=tuple(optional))
        elif isinstance(spec, IOSpec) and not spec.all_inputs:
            _, required, optional = self._infer_input_names()
            spec = spec.replace(required_inputs=tuple(required), optional_inputs=tuple(optional))
        self.io_spec = spec

        self._applications = []

    @property
    def name(self):
        """Human-readable name used in output merges and error messages."""
        if self._name:
            return self._name
        return self.__class__.__name__

    @name.setter
    def name(self, value):
        """Override the display name for this model instance."""
        self._name = value

    def set_io(self, io_cfg, *, strict: bool = True, require_all: bool = True):
        """Bind IO mapping using the unified config format.

        Accepts: ``{"inputs": {param: field}, "outputs": <string|list|dict>}``
        """
        inputs_raw, outputs_raw = parse_io_config(io_cfg)
        self._applications = build_applications(inputs_raw, outputs_raw)
        self._io_bound = True
        return self

    @overload
    def forward(self, data: Entry) -> Entry: ...
    @overload
    def forward(self, data: GraphEntry) -> GraphEntry: ...
    @overload
    def forward(self, *args, **kwargs) -> Any: ...

    def forward(self, *args, **kwargs) -> Any:
        """Route Entry/GraphEntry calls through IO binding; otherwise call _forward directly."""
        all_args = args + tuple(kwargs.values())
        if any(isinstance(arg, (Entry, GraphEntry)) for arg in all_args):
            if len(all_args) != 1:
                raise TypeError("Cannot mix Entry and non-Entry arguments in the forward method.")
            arg = all_args[0]
            if isinstance(arg, Entry):
                return self._forward_entry(arg)
            if isinstance(arg, GraphEntry):
                return self._forward_graph_entry(arg)
        return self._forward(*args, **kwargs)

    def _forward_entry(self, data: Entry) -> Entry:
        """Execute model using applications to map Entry fields to _forward parameters."""
        if not self._applications:
            raise ValueError(
                f"{self.__class__.__name__} has no IO binding. "
                f"Call set_io() before passing an Entry."
            )
        for input_map, output_fields in self._applications:
            kwargs = {}
            for param, field in input_map.items():
                if field not in data:
                    raise KeyError(
                        f"Field '{field}' (mapped to parameter '{param}') "
                        f"not found in Entry for {self.name}."
                    )
                kwargs[param] = data[field]
            result = self._forward(**kwargs)
            if not isinstance(result, (tuple, list)):
                result = (result,)
            if len(result) != len(output_fields):
                raise ValueError(
                    f"{self.name} returned {len(result)} values but expects {len(output_fields)} outputs."
                )
            data = data.merge_fields(dict(zip(output_fields, result)), source=self.name)
        return data

    def _forward_graph_entry(self, data: GraphEntry) -> GraphEntry:
        """Execute model on a GraphEntry."""
        if not self._applications:
            raise ValueError(
                f"{self.__class__.__name__} has no IO binding. "
                f"Call set_io() before passing a GraphEntry."
            )
        result = self._forward(data)
        if not isinstance(result, (tuple, list)):
            result = (result,)
        _, output_fields = self._applications[0]
        if len(result) != len(output_fields):
            raise ValueError(
                f"Expected {len(output_fields)} outputs, got {len(result)} from {self.__class__.__name__}."
            )
        return data.merge_fields(dict(zip(output_fields, result)), source=self.name)

    @abc.abstractmethod
    def _forward(self, *args, **kwargs) -> Any:
        """Implement the model's computation; do not override forward()."""
        raise NotImplementedError(f"Method '_forward' not implemented for {self.__class__.__name__}.")

    def __repr__(self):
        """Pretty-print instance with init parameters."""
        return obj_to_str(self)

    def _infer_input_names(self) -> Tuple[Tuple[str, ...], Tuple[str, ...], Tuple[str, ...]]:
        """Infer input names from the _forward method signature."""
        required: List[str] = []
        optional: List[str] = []
        for name, param in self._signature.parameters.items():
            # Skip variadic args/kwargs; they don't map to named Entry fields.
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            if param.default is inspect.Parameter.empty:
                required.append(name)
            else:
                optional.append(name)
        inferred = tuple(required + optional)
        return inferred, tuple(required), tuple(optional)

    def trainable_params(self) -> List[torch.nn.Parameter]:
        """Return parameters that require gradients.

        Returns:
            List[torch.nn.Parameter]: Trainable parameters.
        """
        return [p for p in self.parameters() if p.requires_grad]

@register_class
class SequentialModel(Model):
    """Defines a flow of Models and transforms that operate on an Entry.

    All module types (Model, EntryTransform, DataTransform) are configured
    uniformly — the flow DSL is the single source of truth for IO binding.

    Args:
        modules: Dict mapping names to module instances (Model, EntryTransform,
            or DataTransform).
        flow: The flow specification as a multiline string, list of strings,
            or list of ``{"flow": "..."}`` dicts.

    Flow DSL::

        <inputs> -> <module> -> <outputs>

    Module types:
      - **Model**: Named mapping in the module segment or positional on LHS/RHS.
      - **EntryTransform**: Opaque — field keys set via constructor ``_key`` params.
        Flow DSL fields are for dependency tracking only.
      - **DataTransform**: Positional IO from LHS/RHS.

    Examples::

        x -> m1 -> y
        (x=x, guide=g) -> m1 -> (out, meta)
         -> crop ->
        x -> mul -> y
    """

    class Step:
        def __init__(
            self,
            *,
            name: str,
            module: Any,
            kind: str,
            entry_inputs: List[str],
            entry_outputs: List[str],
            input_map: Dict[str, str] | None = None,
            applications: List[Tuple[Dict[str, str], List[str]]] | None = None,
            recurse_params: set | None = None,
        ):
            self.name = name
            self.module = module
            self.kind = kind
            self.entry_inputs = entry_inputs
            self.entry_outputs = entry_outputs
            self.input_map = input_map or {}
            self.applications = applications
            self.recurse_params = recurse_params

    def __init__(
        self,
        modules: dict[str, Any] | None = None,
        flow: str | list | dict[str, Any] | None = None,
        *,
        name: str = None,
        models: dict[str, Any] | None = None,
    ):
        super().__init__(name=name, io_spec=IOSpec())

        # --- backward-compat: accept 'models' kwarg -------------------------
        if models is not None and modules is not None:
            raise ValueError("Cannot specify both 'modules' and 'models'. Use 'modules'.")
        if models is not None:
            warnings.warn(
                "The 'models' parameter is deprecated. Use 'modules' instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            modules = models
        modules = modules or {}

        # --- backward-compat: accept flow as nested dict ---------------------
        if isinstance(flow, dict):
            if "flow" not in flow:
                raise ValueError("SequentialModel flow dict must contain a 'flow' key.")
            warnings.warn(
                "Passing flow as a dict is deprecated. Pass the flow string or list directly.",
                DeprecationWarning,
                stacklevel=2,
            )
            modules = flow.get("blocks", modules) or modules
            flow_spec = flow["flow"]
        elif isinstance(flow, (str, list, tuple)):
            flow_spec = flow
        elif flow is None:
            raise ValueError("SequentialModel requires a flow specification.")
        else:
            raise TypeError(f"Invalid flow type: {type(flow)}. Expected str, list, or dict.")

        if not isinstance(modules, dict) or len(modules) == 0:
            raise ValueError("SequentialModel requires a non-empty modules dict.")

        self.steps, required_inputs = self._build_steps_from_flow(flow_spec, modules)
        self.io_spec = self.io_spec.replace(
            required_inputs=tuple(required_inputs),
            optional_inputs=tuple(),
            required_outputs=tuple(),
            optional_outputs=tuple(),
        )
        self.models = self._register_modules(modules)

    # ------------------------------------------------------------------
    # Parsing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _strip_segment(segment: str) -> str:
        seg = segment.strip()
        if seg == "()":
            return ""
        if seg.startswith("(") and seg.endswith(")"):
            seg = seg[1:-1].strip()
        return seg

    @staticmethod
    def _parse_segment(segment: str) -> Tuple[List[str], Dict[str, str]]:
        seg = SequentialModel._strip_segment(segment)
        if not seg:
            return [], {}
        parts = [p.strip() for p in seg.split(",") if p.strip()]
        positional: List[str] = []
        mapping: Dict[str, str] = {}
        for item in parts:
            if "=" in item:
                key, val = item.split("=", 1)
                key = key.strip()
                val = val.strip()
                if not key or not val:
                    raise ValueError(f"Invalid mapping '{item}' in segment '{segment}'.")
                if key in mapping:
                    raise ValueError(f"Duplicate mapping key '{key}' in segment '{segment}'.")
                mapping[key] = val
            else:
                positional.append(item)
        if len(positional) != len(set(positional)):
            raise ValueError(f"Duplicate names in segment '{segment}'.")
        return positional, mapping

    @staticmethod
    def _parse_module_segment(segment: str) -> str:
        seg = segment.strip()
        if "(" in seg:
            raise ValueError(
                f"Named input mapping goes on the LHS: "
                f"'(image=x) -> module -> y', not 'module(image=x)'. "
                f"Got: '{segment.strip()}'."
            )
        if not seg:
            raise ValueError(f"Invalid module segment: '{segment}'.")
        return seg

    @staticmethod
    def _is_entry_transform(module: Any) -> bool:
        return isinstance(module, EntryTransform)

    @staticmethod
    def _is_data_transform(module: Any) -> bool:
        return isinstance(module, DataTransform)


    # ------------------------------------------------------------------
    # Flow building
    # ------------------------------------------------------------------

    def _build_steps_from_flow(
        self,
        flow_spec: Union[str, List[Any]],
        modules: Dict[str, Any],
    ) -> Tuple[List["SequentialModel.Step"], List[str]]:
        raw_lines: List[str] = []
        if isinstance(flow_spec, str):
            raw_lines = [l.strip() for l in flow_spec.splitlines()]
        elif isinstance(flow_spec, (list, tuple)):
            for item in flow_spec:
                if isinstance(item, str):
                    raw_lines.append(item.strip())
                elif isinstance(item, dict) and "flow" in item:
                    raw_lines.append(str(item["flow"]).strip())
                else:
                    raise TypeError(f"Flow line must be a string, got {type(item)}.")
        else:
            raise TypeError(f"Invalid flow specification type: {type(flow_spec)}.")

        lines = [l for l in raw_lines if l and not l.lstrip().startswith("#")]
        steps: List[SequentialModel.Step] = []
        produced: set[str] = set()
        required_inputs: set[str] = set()

        for line in lines:
            parts = [p.strip() for p in line.split("->")]
            if len(parts) != 3:
                raise ValueError(f"Invalid flow line: '{line}'. Expected '<inputs> -> <module> -> <outputs>'.")
            lhs, mid, rhs = parts
            pos_inputs, map_inputs = self._parse_segment(lhs)
            pos_outputs, map_outputs = self._parse_segment(rhs)
            module_name = self._parse_module_segment(mid)

            if module_name not in modules:
                raise KeyError(f"Module '{module_name}' not found in modules.")
            module = modules[module_name]

            if isinstance(module, Model):
                step = self._build_model_step(
                    line, module_name, module,
                    pos_inputs, map_inputs, pos_outputs, map_outputs,
                )
            elif self._is_entry_transform(module):
                step = self._build_entry_transform_step(
                    line, module_name, module,
                    pos_inputs, map_inputs, pos_outputs, map_outputs,
                )
            elif self._is_data_transform(module):
                step = self._build_data_transform_step(
                    line, module_name, module,
                    pos_inputs, map_inputs, pos_outputs, map_outputs,
                )
            else:
                raise TypeError(f"Unsupported module type for '{module_name}': {type(module)}.")

            for name in step.entry_inputs:
                if name not in produced:
                    required_inputs.add(name)
            produced.update(step.entry_outputs)
            steps.append(step)

        return steps, sorted(required_inputs)

    # ------------------------------------------------------------------
    # Step builders
    # ------------------------------------------------------------------

    def _build_model_step(
        self,
        line: str,
        module_name: str,
        module: Model,
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> "SequentialModel.Step":
        if pos_inputs and map_inputs:
            raise ValueError(
                f"Cannot mix positional and named inputs on the LHS: '{line}'. "
                f"Use all positional ('x, y -> m -> z') or all named ('(image=x, guide=y) -> m -> z')."
            )
        if map_outputs:
            raise ValueError(
                f"Named output mapping (port=field) is not supported. "
                f"Use positional outputs instead: '{line}'."
            )
        if not pos_outputs:
            raise ValueError(
                f"Model '{module_name}' has no outputs in flow line '{line}'."
            )

        spec = module.io_spec
        all_inputs = list(spec.all_inputs)
        required_in = list(spec.required_inputs)
        optional_in = list(spec.optional_inputs)

        # --- Input mapping ---------------------------------------------------
        input_map: Dict[str, str] = {}
        if map_inputs:
            # Named mapping on LHS: (image=x, guide=g) -> m1 -> y
            unknown = set(map_inputs.keys()) - set(all_inputs)
            if unknown:
                raise ValueError(
                    f"Module '{module_name}' input mapping has unknown keys: {sorted(unknown)}."
                )
            missing_required = set(required_in) - set(map_inputs.keys())
            if missing_required:
                raise ValueError(
                    f"Module '{module_name}' is missing required inputs: {sorted(missing_required)}."
                )
            input_map = dict(map_inputs)
        else:
            # Pure positional: x, y -> m1
            if len(pos_inputs) < len(required_in) or len(pos_inputs) > len(all_inputs):
                raise ValueError(
                    f"Module '{module_name}' expects {len(required_in)}..{len(all_inputs)} inputs "
                    f"({all_inputs}), got {len(pos_inputs)}."
                )
            input_map = {name: val for name, val in zip(required_in, pos_inputs[:len(required_in)])}
            if len(pos_inputs) > len(required_in):
                extra = pos_inputs[len(required_in):]
                if len(extra) > len(optional_in):
                    raise ValueError(
                        f"Module '{module_name}' has too many inputs; optional inputs are {optional_in}."
                    )
                input_map.update({name: val for name, val in zip(optional_in, extra)})

        # --- Output mapping (positional only) --------------------------------
        entry_inputs = list(input_map.values())
        entry_outputs = list(pos_outputs)
        if len(entry_outputs) != len(set(entry_outputs)):
            raise ValueError(f"Duplicate outputs in flow line '{line}'.")

        return SequentialModel.Step(
            name=module_name,
            module=module,
            kind="model",
            entry_inputs=entry_inputs,
            entry_outputs=entry_outputs,
            input_map=input_map,
        )

    def _build_entry_transform_step(
        self,
        line: str,
        module_name: str,
        module: Any,
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> "SequentialModel.Step":
        # EntryTransform is opaque — field keys are set via its constructor.
        # Flow DSL fields are used for dependency tracking only (no IO binding).
        entry_inputs = list(dict.fromkeys(
            pos_inputs + list(map_inputs.values())
        ))
        entry_outputs = list(dict.fromkeys(
            pos_outputs + list(map_outputs.values())
        ))
        return SequentialModel.Step(
            name=module_name,
            module=module,
            kind="entry_transform",
            entry_inputs=entry_inputs,
            entry_outputs=entry_outputs,
        )

    def _build_data_transform_step(
        self,
        line: str,
        module_name: str,
        module: Any,
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> "SequentialModel.Step":
        if pos_inputs and map_inputs:
            raise ValueError(
                f"Cannot mix positional and named inputs on the LHS: '{line}'. "
                f"Use all positional ('x, y -> t -> z') or all named ('(image=x, ref=y) -> t -> z')."
            )
        if map_outputs:
            raise ValueError(
                f"Named output mapping (port=field) is not supported. "
                f"Use positional outputs instead: '{line}'."
            )

        recurse_params = module._build_recurse_set()

        if map_inputs:
            # Named mapping on LHS: (image=x, reference=ref) -> t -> out
            sig = inspect.signature(module._transform_method)
            all_params = [
                name for name, p in sig.parameters.items()
                if name != "self" and p.kind not in (
                    inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD
                )
            ]
            required_params = [
                name for name, p in sig.parameters.items()
                if name != "self"
                and p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
                and p.default is inspect.Parameter.empty
            ]
            unknown = set(map_inputs.keys()) - set(all_params)
            if unknown:
                raise ValueError(
                    f"DataTransform '{module_name}' has unknown parameter keys: {sorted(unknown)}."
                )
            missing = set(required_params) - set(map_inputs.keys())
            if missing:
                raise ValueError(
                    f"DataTransform '{module_name}' is missing required inputs: {sorted(missing)}."
                )
            if not pos_outputs:
                raise ValueError(
                    f"DataTransform '{module_name}' requires outputs when using named inputs: '{line}'."
                )
            if len(pos_outputs) != len(set(pos_outputs)):
                raise ValueError(f"Duplicate outputs in flow line '{line}'.")
            input_map = dict(map_inputs)
            applications = [(input_map, list(pos_outputs))]
            entry_inputs = list(map_inputs.values())
            entry_outputs = list(pos_outputs)
        else:
            # Positional mode: fields map to transform params by signature order
            if not pos_inputs:
                raise ValueError(
                    f"DataTransform '{module_name}' requires inputs in flow line '{line}'."
                )

            sig = inspect.signature(module._transform_method)
            all_params = [
                name for name, p in sig.parameters.items()
                if name != "self" and p.kind not in (
                    inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD
                )
            ]
            required_params = [
                name for name, p in sig.parameters.items()
                if name != "self"
                and p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
                and p.default is inspect.Parameter.empty
            ]
            if len(pos_inputs) < len(required_params) or len(pos_inputs) > len(all_params):
                raise ValueError(
                    f"DataTransform '{module_name}' expects "
                    f"{len(required_params)}..{len(all_params)} inputs "
                    f"({all_params}), got {len(pos_inputs)}."
                )
            input_map = {name: val for name, val in zip(all_params, pos_inputs)}

            if not pos_outputs:
                pos_outputs = list(pos_inputs) if len(pos_inputs) == 1 else []
            if not pos_outputs:
                raise ValueError(
                    f"DataTransform '{module_name}' requires outputs in '{line}'."
                )
            if len(pos_outputs) != len(set(pos_outputs)):
                raise ValueError(f"Duplicate outputs in flow line '{line}'.")

            applications = [(input_map, list(pos_outputs))]
            entry_inputs = list(pos_inputs)
            entry_outputs = list(pos_outputs)

        return SequentialModel.Step(
            name=module_name,
            module=module,
            kind="data_transform",
            entry_inputs=entry_inputs,
            entry_outputs=entry_outputs,
            applications=applications,
            recurse_params=recurse_params,
        )

    # ------------------------------------------------------------------
    # Module registration
    # ------------------------------------------------------------------

    def _register_modules(self, modules: dict[str, Any]) -> torch.nn.ModuleDict:
        modules_dict = torch.nn.ModuleDict()
        seen: Dict[int, str] = {}
        self._model_refs: Dict[str, Model] = {}

        for step in self.steps:
            if step.kind != "model":
                continue
            if not isinstance(step.module, Model):
                raise TypeError(f"Module '{step.name}' must be a Model, got {type(step.module)}.")
            self._model_refs[step.name] = step.module
            module_id = id(step.module)
            if module_id not in seen:
                modules_dict[step.name] = step.module
                seen[module_id] = step.name

        for name, mod in modules.items():
            if name not in self._model_refs and isinstance(mod, Model):
                logger.warning(f"Module '{name}' not used in the Sequential flow. Consider removing it.")

        return modules_dict

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def _forward_entry(self, data: Entry) -> Entry:
        for step in self.steps:
            if step.kind == "entry_transform":
                # Opaque — transform knows its own field keys from constructor.
                data = step.module(data)
                continue

            if step.kind == "data_transform":
                for name in step.entry_inputs:
                    if name not in data:
                        raise KeyError(f"Transform step '{step.name}' missing input '{name}'.")
                # Drive DataTransform externally using per-step applications.
                for input_map, output_fields in step.applications:
                    kwargs = {}
                    for param, field in input_map.items():
                        if field not in data:
                            raise KeyError(f"Target '{field}' not found in entry for transformation {step.name}.")
                        kwargs[param] = data[field]
                    result = step.module._apply_recursive(kwargs, step.recurse_params)
                    if len(output_fields) == 1:
                        data[output_fields[0]] = result
                    else:
                        if not isinstance(result, (tuple, list)):
                            raise ValueError(
                                f"DataTransform '{step.name}' returned 1 value "
                                f"but expects {len(output_fields)} outputs."
                            )
                        if len(result) != len(output_fields):
                            raise ValueError(
                                f"DataTransform '{step.name}' returned {len(result)} values "
                                f"but expects {len(output_fields)} outputs."
                            )
                        for field, val in zip(output_fields, result):
                            data[field] = val
                for out_name in step.entry_outputs:
                    if out_name not in data:
                        raise KeyError(f"Transform step '{step.name}' did not produce '{out_name}'.")
                continue

            if step.kind == "model":
                inputs: Dict[str, Any] = {}
                for model_inp, entry_name in step.input_map.items():
                    if entry_name not in data:
                        raise KeyError(
                            f"Field '{entry_name}' (mapped to parameter '{model_inp}') "
                            f"not found in Entry for SequentialModel step '{step.name}'."
                        )
                    inputs[model_inp] = data[entry_name]
                result = step.module._forward(**inputs)

                # Positional output — zip return values with entry fields.
                entry_outputs = step.entry_outputs
                if not isinstance(result, (tuple, list)):
                    result = (result,)
                if len(result) != len(entry_outputs):
                    raise ValueError(
                        f"Module '{step.name}' returned {len(result)} values "
                        f"but flow expects {len(entry_outputs)} outputs: {entry_outputs}."
                    )
                outputs_dict = dict(zip(entry_outputs, result))

                data = data.merge_fields(outputs_dict, source=step.name)
                continue

            raise TypeError(f"Unknown step kind '{step.kind}' for '{step.name}'.")

        return data

    def _forward(self, *args, **kwargs) -> Any:
        raise NotImplementedError("SequentialModel expects an Entry input.")
