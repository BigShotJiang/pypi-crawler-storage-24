# TODO

Code quality issues identified during review. Check off when resolved.

## High Priority

- [x] **Merge ValidationEpochRunner / BenchmarkRunner** — 96% identical code.
  Extract shared inference loop into `InferenceRunner` base class.
  `srforge/training/runners.py`

- [x] **Remove `_merge_fields` duplication** — exists as both a module-level
  function and an instance method on Entry, plus a copy on GraphEntry. Pick one.
  `srforge/data/entry.py`

- [x] **Deduplicate `_index_value` / `_unbatch_value`** — identical logic in
  `entry.py` and `transform/__init__.py`. Import from entry.py.
  `srforge/data/entry.py`, `srforge/transform/__init__.py`

- [x] **Fix LogitsLogger batch indexing bug** — removed the class entirely
  (buggy, unused).
  `srforge/observers/image.py`

- [x] **Fix ProgressBar batch_size fallback** — was using `event.batch` (batch
  index, not size) when inferring batch size. Fixed to use `1` for scalar losses.
  `srforge/observers/logging.py`

## Medium Priority — Usability / "Magic"

- [ ] **Document `${ref:}` vs `${}` distinction** — add a prominent warning
  in `docs/src/configuration.md` and scaffold config comments. New users will
  confuse the two.

- [ ] **Make annotation-driven recursion explicit** — DataTransform recurses
  into dicts/lists based on type annotations, defaulting to recurse if
  unannotated. Consider a class attribute or decorator to make this visible.
  `srforge/transform/__init__.py`

- [ ] **Remove or gate IOPort descriptor system** — `_IOPort` and
  `_install_io_ports` are fully implemented but every main class opts out.
  Either remove the dead code or document when it's useful.
  `srforge/utils/iomodule.py`

- [ ] **Warn on ClassRegistry short-name collisions** — second class with the
  same short name is silently ignored. Add a warning.
  `srforge/registry.py`

- [ ] **Log warning on Observable auto-attachment failure** — currently
  swallows all exceptions when `GlobalSettings().event_bus` is unavailable.
  `srforge/observers/base.py`

## Low Priority — Cleanup

- [ ] **Remove redundant transform/transform_unbatched pairs** — ~30% of
  DataTransforms and most EntryTransforms manually delegate one to the other.
  The base class should handle dispatch.
  `srforge/transform/data.py`, `srforge/transform/entry.py`

- [ ] **Simplify `_Args`/`_Kwargs` in ConfigResolver** — internal wrapper
  classes add complexity; replace with a simpler pattern.
  `srforge/config/resolver.py`

- [ ] **Stop using private OmegaConf APIs** — `_key()` and `_get_parent()`
  may break in future versions.
  `srforge/config/resolver.py`

- [ ] **Replace `array.array('d')` with plain list** in stop condition.
  `srforge/training/stop.py`
