# Core Concepts

This page defines every key term in SR-Forge. Read it once before diving into the guide — it will make everything else click faster. Come back anytime you need a refresher.

---

## Entry

A specialized dictionary that carries all data for a single sample through the pipeline. It can hold tensors, nested structures, metadata — anything your experiment needs. Every component in SR-Forge reads from and writes to Entry.

*Detailed guide: [Entry](entry.md)*

## Dataset

The starting point of every pipeline. A Dataset loads raw data (images, time series, point clouds, etc.) and wraps each sample in an Entry. It extends PyTorch's `Dataset` class, so it works directly with PyTorch's `DataLoader` for batching and shuffling. Datasets can also apply transforms at load time and **cache** the preprocessed results so subsequent epochs skip recomputation.

## Fields

Named slots inside an Entry. Think of them as columns in a spreadsheet — each field has a name (like `"image"`, `"target"`, `"mask"`) and holds one piece of data. Components read from specific fields and write results to other fields.

## Transform

A reusable processing step that modifies data. SR-Forge has two kinds:

- **DataTransform** — processes the **values** inside Entry fields. You write a function that takes values in (tensors, strings, dicts, etc.) and returns values out — the framework extracts them from the Entry and stores results back. The Entry structure stays the same; only field content changes. Example: normalizing pixel values, resizing an image, converting types.
- **EntryTransform** — operates on the **Entry itself**. Has full access to add, remove, rename, or inspect fields, and can even change the Entry type. Example: splitting a multispectral image into separate band fields, removing temporary metadata, renaming fields.

*Detailed guide: [Transforms](transforms/index.md)*

## IO Binding

The process of connecting method parameter names to Entry fields. A model with `forward(self, image)` might be bound so that `image` reads from `entry["input_rgb"]` — same model, different data. This separation lets you write a component once and reuse it with different field names in different contexts. There are three ways to bind: in Python code, in YAML configuration, or automatically through the flow DSL.

*Detailed guide: [IO Binding](io-binding.md)*

## Model

A neural network component that participates in SR-Forge's pipeline. It extends PyTorch's `nn.Module` with IO binding, so it can read inputs from Entry fields and write outputs back. You implement `forward()` with your computation logic — the framework handles data routing.

*Detailed guide: [Model](models/model.md)*

## SequentialModel

A way to chain multiple models and transforms into a multi-stage pipeline. Instead of writing glue code to pass data between components, you describe the flow declaratively: "take this field, pass it through this module, store the result there." SequentialModel handles all the wiring.

*Detailed guide: [SequentialModel](models/sequential-model.md)*

## Flow DSL

A small arrow-based syntax for defining pipelines inside SequentialModel. DSL stands for Domain-Specific Language. Every line follows the same pattern — three parts separated by `->`:

```
<input fields> -> <module name> -> <output fields>
```

For example: `image -> encoder -> features` means "read the `image` field, pass it through the module named `encoder`, store the result as `features`." Multiple fields are separated by commas: `(image, mask) -> model -> (output, confidence)`.

## Configuration

YAML files that define your entire experiment — model architecture, optimizer, loss function, data pipeline, everything. SR-Forge reads the YAML and automatically builds all the Python objects it describes. This means you can change your experiment without touching code.

*Detailed guide: [Configuration](configuration.md)*

---

**Next:** [Entry](entry.md) — The foundation everything builds on
