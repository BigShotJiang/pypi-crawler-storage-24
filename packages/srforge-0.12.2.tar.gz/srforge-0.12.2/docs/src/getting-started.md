# Getting Started

## Installation

### Prerequisites

Install PyTorch **before** installing SR-Forge. Follow the official instructions at [pytorch.org](https://pytorch.org/get-started/locally/) to pick the right build for your OS, package manager, and GPU.

```bash
# Example: CUDA 12.8
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128

# Example: CPU only
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

### Install SR-Forge

```bash
pip install srforge
```

This installs the core framework with everything you need for tensor-based super-resolution: models, transforms, datasets, losses, training loops, and configuration.

### Graph neural network support

If you work with graph-based models (e.g., MagNAt), you need PyTorch Geometric and its compiled extensions. Just like PyTorch itself, these must be installed with the correct CUDA version **before** installing SR-Forge's graph extra.

Follow the [PyG installation guide](https://pytorch-geometric.readthedocs.io/en/latest/install/installation.html) to pick the right wheels for your PyTorch version, then install the graph extra:

```bash
# Example: PyG packages for PyTorch 2.7 + CUDA 12.8
pip install torch-geometric
pip install pyg-lib torch-scatter torch-sparse torch-cluster torch-spline-conv \
    -f https://data.pyg.org/whl/torch-2.7.0+cu128.html

# Then install the graph extra
pip install srforge[graph]
```

## Scaffold a new project

After installing SR-Forge, create a ready-to-run training project:

```bash
mkdir my-experiment && cd my-experiment
srforge init
```

This generates:

```
my-experiment/
├── train.py              # Training script
├── benchmark.py          # Benchmark/inference script
└── configs/
    ├── train-cfg.yaml    # Training config
    └── benchmark-cfg.yaml # Benchmark config
```

Edit `configs/train-cfg.yaml` to point at your data and adjust training settings, then run:

```bash
python train.py
```

### What the scaffold contains

The generated `benchmark.py` follows the same structure as `train.py` but runs inference on a test dataset using the `BenchmarkRunner`.

The generated `train.py` follows a 7-step pattern:

1. **`init(cfg)`** — framework setup, returns a config resolver
2. **Tracker** — experiment logging (W&B or null)
3. **Resolve training objects** — model, loss, optimizer, scheduler from YAML
4. **Resume from checkpoint** — one call that restores everything if resuming
5. **Datasets & device** — load data, set up GPU/multi-GPU
6. **Observers** — subscribe progress bars, loggers, checkpointers to the event bus
7. **Train** — create trainer, restore checkpoint state, run the epoch loop

The generated `train-cfg.yaml` has sections for: `system` (device, caching), `tracker`, `training` (epochs, batch size), `model`, `optimizer`, `lr_scheduler`, `loss`, `dataset`, `preprocessing`/`postprocessing`, `training_runner`/`validation_runner`, `trainer`, and `observers`. The `benchmark-cfg.yaml` mirrors the training config but without training-specific sections (optimizer, scheduler, trainer).

The rest of the guide explains each piece in detail.

The generated files are a **starting point**, not a rigid template. They include common features out of the box (multi-GPU, mixed precision, dataset caching, W&B tracking, loss scheduling, checkpointing), but you're expected to modify both files to fit your workflow.

The config file is especially flexible — add any fields you need. The YAML config is a plain Hydra/OmegaConf file, so you can add custom sections for your own training script logic, experiment metadata, or grouping in W&B, MLflow, or any other tracking tool. For example:

```yaml
# Custom fields — use them however you like in train.py
experiment:
  description: "Ablation study on loss weights"
  tags: [ablation, l1-ssim]

my_custom_setting: 42
```

See the [Configuration](configuration.md) guide for details on built-in settings.

## IDE support

<div class="sf-ide-section" markdown>

**SR-Forge Assistant** is a plugin for PyCharm and other JetBrains IDEs that adds first-class support for SR-Forge projects.

<div class="sf-ide-features" markdown>

- **Target intelligence** — resolve `_target_` references, navigate to class definitions
- **Config interpolation** — live preview of `${ref:...}` and OmegaConf expressions
- **Pipeline probe** — visualize SequentialModel flow as a graph
- **Tensor shape inspector** — inspect tensor dimensions at breakpoints
- **Debugger integration** — Entry and tensor visualizations in the debug panel

</div>

<div class="sf-ide-links">
  <a href="https://github.com/ttarasiewicz/SR-Forge-Assistant" class="sf-ide-link" target="_blank">
    <span class="sf-ide-link-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" width="28" height="28" fill="currentColor"><path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8z"/></svg></span>
    <span class="sf-ide-link-text">
      <strong>Source & Documentation</strong>
      <small>github.com/ttarasiewicz/SR-Forge-Assistant</small>
    </span>
  </a>
</div>

<div class="sf-ide-widget">
  <div id="sr-forge-assistant-widget"></div>
</div>

</div>

<script src="https://plugins.jetbrains.com/assets/scripts/mp-widget.js"></script>
<script>
  MarketplaceWidget.setupMarketplaceWidget('card', 30334, "#sr-forge-assistant-widget");
</script>

## What's next

Read the guide in order — each page builds on the previous one:

1. **[Core Concepts](concepts.md)** — Quick glossary of every SR-Forge term
2. **[Entry](entry.md)** — The data container that flows through the pipeline
3. **[Collation](collation.md)** — How single entries become batches
4. **[Datasets](datasets.md)** — Loading data and caching
5. **[Transforms](transforms/index.md)** — Preprocessing and augmentation
6. **[IO Binding](io-binding.md)** — How components connect to Entry fields
7. **[Models](models/index.md)** — Neural networks and pipeline composition
8. **[Losses](losses.md)** — Evaluation metrics and loss functions
9. **[Writing Scripts](scripts.md)** — Training and test scripts
10. **[Trainers & Runners](trainers-and-runners.md)** — Inside the training loop
11. **[Configuration](configuration.md)** — Wire everything together in YAML
12. **[Experiment Tracking](tracking.md)** — Logging, checkpointing, and resume
13. **[Observers & Events](observers.md)** — Pluggable monitoring
14. **[Extending SR-Forge](extending.md)** — Custom components

## For developers

Install PyTorch and PyG with CUDA wheels first (see [Prerequisites](#prerequisites) and [Graph support](#graph-neural-network-support) above), then clone and install in editable mode:

```bash
git clone https://gitlab.com/tarasiewicztomasz/sr-forge.git
cd sr-forge
pip install -e ".[dev,graph]"
```

This gives you:

- **Editable install** — code changes take effect immediately, no reinstall needed
- **Dev tools** — pytest, mkdocs, mkdocstrings
- **Graph support** — full access to all components including graph models

Run the test suite:

```bash
pytest tests/ -v
```

Build and serve the docs locally:

```bash
mkdocs serve
```

Then open the local URL shown in the terminal.
