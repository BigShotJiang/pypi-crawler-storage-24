# Extending SR-Forge

Every component in SR-Forge follows the same pattern: **subclass, implement method(s), use from Python or YAML**. This page shows how to create custom components — models, transforms, losses, datasets, and observers — that integrate seamlessly with the framework. Your custom classes work exactly like built-in ones: they can be wired in YAML, composed in SequentialModel, and used in any pipeline.

---

## Model

Subclass `Model`, implement `forward()`. Parameter names are used for IO binding automatically.

```python
from srforge.models import Model
import torch

class MyUpscaler(Model):
    def __init__(self, scale: int = 2):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Conv2d(3, 64, 3, padding=1),
            torch.nn.ReLU(),
            torch.nn.Conv2d(64, 3 * scale ** 2, 3, padding=1),
            torch.nn.PixelShuffle(scale),
        )

    def forward(self, image):
        return self.net(image)
```

Use in YAML:

```yaml
model:
  _target: my_project.models.MyUpscaler
  params:
    scale: 4
  io:
    inputs:
      image: lr
    outputs: sr
```

See [Model](models/model.md) for details on multiple outputs and standalone use.

---

## DataTransform

Subclass `DataTransform`, implement `transform()` (batched) or `transform_unbatched()` (per-sample). Parameter names and type annotations define the interface.

```python
from srforge.transform import DataTransform
import torch

class GammaCorrection(DataTransform):
    def __init__(self, gamma: float = 2.2):
        super().__init__()
        self.gamma = gamma

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image.clamp(min=0).pow(1.0 / self.gamma)
```

Use in YAML:

```yaml
preprocessing:
  training:
    - _target: my_project.transforms.GammaCorrection
      params:
        gamma: 2.2
      io:
        inputs:
          image: lr
```

Or in a SequentialModel flow:

```yaml
modules:
  gamma:
    _target: my_project.transforms.GammaCorrection
    params:
      gamma: 2.2
flow:
  - "lr -> gamma -> lr"
```

See [DataTransform](transforms/data-transform.md) for annotation-driven recursion, multi-input transforms, and per-sample processing.

---

## EntryTransform

Subclass `EntryTransform`, implement `transform_unbatched()` (or `transform()` for batched). Use `_key` suffix parameters for field names.

```python
from srforge.transform import EntryTransform

class DropSmallFields(EntryTransform):
    def __init__(self, *, min_size: int, field_key: str, output_key: str = None):
        self.min_size = min_size
        self.field_key = field_key
        self.output_key = output_key or field_key
        super().__init__()

    def transform_unbatched(self, entry):
        tensor = entry[self.field_key]
        if tensor.shape[-1] >= self.min_size and tensor.shape[-2] >= self.min_size:
            entry[self.output_key] = tensor
        return entry
```

Use in YAML — field keys go in `params:`, **not** `io:`:

```yaml
- _target: my_project.transforms.DropSmallFields
  params:
    min_size: 32
    field_key: image
```

See [EntryTransform](transforms/entry-transform.md) for the `_key` convention, optional keys, and SequentialModel integration.

---

## Loss

Subclass `Loss`, implement `calculate_score()` and the `best_min` property. Parameter names are used for IO binding.

```python
from srforge.loss import Loss
import torch

class HuberLoss(Loss):
    def __init__(self, delta: float = 1.0, **kwargs):
        super().__init__(**kwargs)
        self.delta = delta

    @property
    def best_min(self) -> bool:
        return True  # lower is better

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        diff = (x - y).abs()
        quadratic = torch.clamp(diff, max=self.delta)
        linear = diff - quadratic
        loss = 0.5 * quadratic ** 2 + self.delta * linear
        return loss.mean(dim=(-3, -2, -1))  # per-sample scalar [B]
```

Use in YAML:

```yaml
loss:
  _target: srforge.loss.combiner.LossCombiner
  params:
    losses:
      - _target: my_project.losses.HuberLoss
        params:
          delta: 0.5
          weight: 1.0
        io:
          inputs: {x: sr, y: hr}
```

See [Losses](losses.md) for masking, multi-band inputs, `MetricScores`, and `LossCombiner`.

---

## Dataset

Subclass `BaseDataset`, implement `_load_entry()`. Each call returns one Entry.

```python
from srforge.dataset import BaseDataset
from srforge.data import Entry
from pathlib import Path
import torch

class TiffDataset(BaseDataset):
    def __init__(self, root: str, **kwargs):
        paths = sorted(Path(root).glob("*.tif"))
        super().__init__(paths, **kwargs)

    def _load_entry(self, path) -> Entry:
        # Load your data however you need
        image = load_tiff(path)  # your loading function
        return Entry(image=torch.from_numpy(image).float())
```

Use in YAML:

```yaml
dataset:
  training:
    _target: my_project.datasets.TiffDataset
    params:
      root: /data/train
```

Datasets support transforms at load time and caching — see [Datasets](datasets.md).

---

## Observer

Subclass `Observer`, set `EVENTS`, implement `on_<event_name>()` handlers.

```python
from srforge.observers.base import Observer
from srforge.events.runner import RunnerEpochFinished

class EpochTimer(Observer):
    EVENTS = [RunnerEpochFinished]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._start = None

    def on_runner_epoch_finished(self, event: RunnerEpochFinished):
        import time
        print(f"Epoch {event.epoch} finished at {time.strftime('%H:%M:%S')}")
```

Use in YAML:

```yaml
observers:
  - _target: my_project.observers.EpochTimer
    params:
      scope: train
```

See [Observers & Events](observers.md) for scoping, the EventBus, and custom events.

---

## Making Classes Available in YAML

All custom classes are used in YAML via their **full module path**:

```yaml
_target: my_project.models.MyUpscaler
```

The `ConfigResolver` imports the module and instantiates the class automatically — no registration step needed. As long as the module is importable (i.e., on `sys.path` or installed as a package), it works.

For a typical project layout:

```
my-experiment/
├── train.py
├── configs/
│   └── train-cfg.yaml
└── my_project/
    ├── __init__.py
    ├── models.py          # _target: my_project.models.MyUpscaler
    ├── transforms.py      # _target: my_project.transforms.GammaCorrection
    ├── losses.py           # _target: my_project.losses.HuberLoss
    ├── datasets.py         # _target: my_project.datasets.TiffDataset
    └── observers.py        # _target: my_project.observers.EpochTimer
```

SR-Forge built-in classes use the `srforge.*` prefix:

```yaml
_target: srforge.loss.metrics.L1
_target: srforge.transform.data.Multiply
_target: srforge.training.trainers.PyTorchTrainer
```

---

**Next:** Return to [Getting Started](getting-started.md) to scaffold a project, or browse the [API Reference](api/config.md) for detailed class documentation.
