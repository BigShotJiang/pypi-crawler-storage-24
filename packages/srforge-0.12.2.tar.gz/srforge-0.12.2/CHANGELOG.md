# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.12.1] - 2026-03-05

### Added
- `InferenceRunner` base class for non-training runners, eliminating code duplication between `ValidationEpochRunner` and `BenchmarkRunner`.
- `GaussianBlur` data transform.
- `MultibandToGraphEntry` and `MultiImageToGraphEntry` replace `EntryToGraphEntry`.

### Fixed
- ProgressBar batch_size fallback used batch index instead of actual size, producing wrong running averages.
- ProgressBar timer overflow — durations over 24 hours no longer wrap to `0:00:00`.
- Scaffold configs use fully qualified `_target` names.

### Changed
- Criterion ownership moved from runners to `PyTorchTrainer`; runners receive criterion via `run_epoch(criterion=...)`.
- `_merge_fields` inlined into `Entry.merge_fields()` and `GraphEntry.merge_fields()`; module-level function removed.
- `_unbatch_value` deduplicated; `transform/__init__.py` imports `_index_value` from `entry.py`.
- Scaffold test script renamed to benchmark.
- Shared output-handling logic extracted into `EpochRunner` base class.

### Removed
- `LogitsLogger` observer (buggy batch indexing, unused).
- `EntryToGraphEntry` (replaced by `MultibandToGraphEntry` / `MultiImageToGraphEntry`).

## [0.12.0] - 2026-02-25

### Added
- `srforge.init()` now accepts `log_level` parameter for logger configuration.
- `srforge init` CLI scaffolds `test.py` and `test-cfg.yaml` alongside training files.
- DataTransform supports positional multi-input/output in flow DSL, matching Model syntax.
- DataTransform supports named input mapping on LHS in flow DSL (`(image=x) -> t -> y`).
- Return count validation for DataTransform (mismatch between outputs and return values raises `ValueError`).
- TRMISR per-component learning rate groups (`lr_coder`, `lr_transformer`).
- Image caption support in `ExperimentTracker.log_image()` and `BatchImageLogger`.
- Trainers & Runners documentation page with mermaid flow diagrams.
- IDE support section in Getting Started with JetBrains Marketplace widget for SR-Forge Assistant.
- ConfigResolver caching edge-case warnings in Configuration documentation.
- Model vs DataTransform comparison section in IO Binding documentation.

### Fixed
- `Entry.to()` and `Entry.numpy()` now preserve batch metadata (`_is_batched`, `_batch_size`).
- `RegisterEntry` skips zero-translation shifts and uses configurable interpolation order.

### Changed
- Named input mapping moved from module segment to LHS: `(image=x) -> m -> y` instead of `-> m(image=x) -> y`.
- `scripts/` directory removed; scaffold is the single source of truth for project templates.
- `train` and `test` console script entry points removed from `pyproject.toml`.
- Scaffold package renamed from `srforge.scaffold` to `srforge._scaffold` (internal).

### Removed
- Dict output format in `set_io()` (`outputs: {port: field}`) — use string or list instead.
- Named output mapping in flow DSL (`-> m -> (port=field)`) — use positional outputs.
- IOSpec/port terminology from public API and documentation.
- Pre-binding fallback for DataTransform in SequentialModel (flow DSL is the single source of truth).
- `flat_to_applications()` utility from `io_parsing.py`.

## [0.11.0] - 2026-02-23

### Changed
- `ResizeFieldsToReference` rewritten as tensor-only DataTransform; manual container recursion removed.
- `ChooseImages` rewritten as tensor-only DataTransform with configurable dim.
- `ResizeFieldsToReference`, `ChooseImages` converted from EntryTransform to DataTransform; `CenterOffset` removed.
- IOSpec removed from EntryTransform; field binding uses constructor `_key` params instead.

## [0.10.0] - 2026-02-23

### Added
- `srforge.init()` one-call framework setup for Hydra scripts.
- `resume_from_checkpoint()` utility with standardized checkpoint structure.
- `${ref:path}` syntax for unquoted object references in YAML config.
- `ConfigResolver` for generic config resolution (deprecates `ConfigParser`).
- `ExperimentTracker` abstraction and multi-GPU utility (`setup_device()`).
- Observer subscription is explicit via `event_bus.subscribe()`.

### Changed
- Tracker removed from `GlobalSettings`; passed explicitly to observers.
- `ResumeState` dropped; `trainer.restore(ckpt)` facade added.
- `templates.py` replaced with real scaffold files for `srforge init`.
- Scripts rewritten to use `ConfigResolver` + tracker.

## [0.9.0] - 2026-02-17

### Changed
- README rewritten to match documentation; index code example fixed.

## [0.8.0] - 2026-02-17

### Added
- Automatic versioning via setuptools-scm.
- PyPI publishing CI pipeline.

## [0.7.0] - 2026-02-16

### Added
- `srforge init` CLI for project scaffolding.
- Unified `set_io()` structured format across Model, DataTransform, and Loss.
- Loss inherits `IOModule` with `set_io()` binding.
- Annotation-driven container recursion for DataTransform.
- Dual-path transforms (`transform()` / `transform_unbatched()`).
- Batch indexing, per-sample transforms, and `Entry.__len__`.
- `StackSequence`, `StackTensors`, `FlattenDict` transforms.
- Comprehensive MkDocs documentation site.
- Reusable modules in SequentialModel with `forward()` rename support.
- `LossScheduler` for epoch-aware criterion switching.
- Typed events and auto-wired observer system.

### Changed
- `torch-geometric` made an optional dependency (`srforge[graph]`).
- Dataset caching rewritten with built-in implementation (replaces `torchdatasets`).
- Transform method names unified to `transform()` / `transform_unbatched()`.
- `Preprocessor` and `TransformationSpec` removed; `EntryTransform` is standalone.
- Codebase cleanup: `assert` replaced with proper exceptions, `super()` modernized.

[Unreleased]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.12.1...HEAD
[0.12.1]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.12.0...v0.12.1
[0.12.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.11.0...v0.12.0
[0.11.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.10.0...v0.11.0
[0.10.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.9.0...v0.10.0
[0.9.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.8.0...v0.9.0
[0.8.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.7.0...v0.8.0
[0.7.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/releases/v0.7.0
