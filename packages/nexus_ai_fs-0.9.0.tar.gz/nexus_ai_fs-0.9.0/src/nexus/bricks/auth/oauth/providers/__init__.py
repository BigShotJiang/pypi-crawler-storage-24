"""OAuth provider implementations."""
