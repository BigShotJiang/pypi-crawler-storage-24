"""Message envelope model for filesystem-as-IPC.

The envelope wraps every message written to an agent's inbox.
Designed per KERNEL-ARCHITECTURE.md.

Wire format uses ``"from"`` and ``"to"`` field names (matching the design
doc), while Python code uses ``sender`` and ``recipient`` to avoid
clashing with the ``from`` keyword.
"""

import json
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator

from nexus.bricks.ipc.conventions import validate_agent_id


class MessageType(StrEnum):
    """Types of inter-agent messages."""

    TASK = "task"
    RESPONSE = "response"
    EVENT = "event"
    CANCEL = "cancel"


class MessageEnvelope(BaseModel):
    """Immutable message envelope for agent-to-agent communication.

    Fields ``sender`` and ``recipient`` serialize to/from the JSON keys
    ``"from"`` and ``"to"`` respectively, via Pydantic aliases.

    Example JSON on disk::

        {
            "nexus_message": "1.0",
            "id": "msg_7f3a9b2c",
            "from": "agent:analyst",
            "to": "agent:reviewer",
            "type": "task",
            "correlation_id": "task_42",
            "timestamp": "2026-02-12T10:00:00Z",
            "ttl_seconds": 3600,
            "payload": {"action": "review_document"}
        }
    """

    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        ser_json_timedelta="float",
    )

    nexus_message: str = "1.0"
    id: str = Field(default_factory=lambda: f"msg_{uuid4().hex[:8]}")
    sender: str = Field(alias="from")
    recipient: str = Field(alias="to")
    type: MessageType
    correlation_id: str | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    ttl_seconds: int | None = None
    payload: dict[str, Any] = Field(default_factory=dict)

    # Cryptographic signature fields (populated by MessageSigner)
    signature: str | None = None
    signer_did: str | None = None
    signer_key_id: str | None = None

    @field_validator("sender", "recipient")
    @classmethod
    def _validate_agent_ref(cls, v: str) -> str:
        return validate_agent_id(v)

    @field_validator("ttl_seconds")
    @classmethod
    def _validate_ttl(cls, v: int | None) -> int | None:
        if v is not None and v <= 0:
            raise ValueError("ttl_seconds must be positive")
        return v

    def signing_bytes(self) -> bytes:
        """Canonical JSON for signing (excludes cryptographic signature fields).

        Returns deterministic bytes suitable for Ed25519 signing:
        - Sorted keys for determinism
        - Compact separators (no whitespace)
        - Excludes signature, signer_did, signer_key_id
        """
        data = self.model_dump(
            by_alias=True,
            exclude={"signature", "signer_did", "signer_key_id"},
        )
        return json.dumps(data, sort_keys=True, separators=(",", ":"), default=str).encode()

    def is_expired(self, now: datetime | None = None) -> bool:
        """Check if the message has exceeded its TTL.

        Args:
            now: Current time for testing. Defaults to UTC now.

        Returns:
            True if the message has a TTL and it has expired.
        """
        if self.ttl_seconds is None:
            return False
        now = now or datetime.now(UTC)
        elapsed = (now - self.timestamp).total_seconds()
        return elapsed > self.ttl_seconds

    def create_reply(
        self,
        payload: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
    ) -> "MessageEnvelope":
        """Create a reply envelope for this message.

        Swaps sender/recipient, sets type=RESPONSE, and links via correlation_id.

        Args:
            payload: Reply payload.
            ttl_seconds: Optional TTL override. If not provided, uses the original TTL.

        Returns:
            New MessageEnvelope configured as a reply.

        Example:
            request = MessageEnvelope.model_validate({
                "from": "agent_a",
                "to": "agent_b",
                "type": "task",
                "payload": {"action": "process"},
            })

            reply = request.create_reply(payload={"status": "done", "result": 42})
            # reply.sender == "agent_b"
            # reply.recipient == "agent_a"
            # reply.type == MessageType.RESPONSE
            # reply.correlation_id == request.id
        """
        return MessageEnvelope.model_validate(
            {
                "from": self.recipient,
                "to": self.sender,
                "type": MessageType.RESPONSE,
                "payload": payload,
                "correlation_id": self.id,
                "ttl_seconds": ttl_seconds if ttl_seconds is not None else self.ttl_seconds,
            }
        )

    def to_bytes(self) -> bytes:
        """Serialize to JSON bytes for VFS write."""
        return self.model_dump_json(by_alias=True, indent=2).encode("utf-8")

    def to_hot_bytes(self) -> bytes:
        """Compact JSON (no indentation) for hot-path delivery."""
        return self.model_dump_json(by_alias=True).encode("utf-8")

    @classmethod
    def from_bytes(cls, data: bytes) -> "MessageEnvelope":
        """Deserialize from JSON bytes read from VFS.

        Raises:
            EnvelopeValidationError: If the data is not valid JSON or
                fails envelope validation.
        """
        from nexus.bricks.ipc.exceptions import EnvelopeValidationError

        try:
            parsed = json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise EnvelopeValidationError(f"Invalid JSON: {exc}") from exc

        try:
            return cls.model_validate(parsed)
        except Exception as exc:
            raise EnvelopeValidationError(str(exc)) from exc
