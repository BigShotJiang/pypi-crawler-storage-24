from setuptools import setup,find_packages

setup(
    name="krishi",
    version="1.0",
    packages=  find_packages(),
    install_requires=[
        "pyttsx3",
        "customtkinter",
        "ollama",

    ], 
    author= "henry",
    description= " ntggggg",
)