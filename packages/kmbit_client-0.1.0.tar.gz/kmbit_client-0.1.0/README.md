# kmbit-client

Spatial Awareness Client for AI Agents.

> Track where AI agents are working in the codebase, detect collisions, and coordinate multi-agent workflows.

## Install

```bash
pip install kmbit-client
```

## Usage

```python
from kmbit_client import KmBiT

kmbit = KmBiT(agent="my-agent")
kmbit.here("/path/to/file.py", "implementing feature X")

# Context manager
with kmbit.at("/path/to/file.py", "reviewing code"):
    pass

# Query
kmbit.where_am_i()
kmbit.who_is_here()
kmbit.hot_zones()
```

## Part of HumoticaOS

```
kmbit-kernel    Route queries to agents (AI Filesystem)
kmbit-client    Track agent locations (Spatial Awareness)  <- you are here
```

## License

MIT — [Humotica](https://humotica.com)
