"""
kmbit-client: Spatial Awareness Client for AI Agents.

Track where AI agents are working in the codebase,
detect collisions, and coordinate multi-agent workflows.

Usage:
    from kmbit_client import KmBiT

    kmbit = KmBiT(agent="my-agent")
    kmbit.here("/path/to/file.py", "implementing feature X")

    # Context manager
    with kmbit.at("/path/to/file.py", "reviewing code"):
        pass

    # Convenience API
    from kmbit_client import init, here, where, who
    init("my-agent")
    here("/path/to/file.py", "working on it")
"""

from .client import KmBiT, init, here, where, who

__version__ = "0.1.0"
__all__ = ["KmBiT", "init", "here", "where", "who"]
