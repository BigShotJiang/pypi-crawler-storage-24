#!/usr/bin/env python3
"""
KmBiT Spatial Awareness Client
==============================

Simple client for AI agents to register their location in the codebase.

Usage:
    from kmbit_client import KmBiT

    kmbit = KmBiT(agent="gemini")
    kmbit.here("/srv/jtel-stack/jis-router/src/tibet.rs", "implementing feature X")

    # Or as context manager (auto-registers on enter, logs exit)
    with kmbit.at("/path/to/file.py", "reviewing code"):
        # do work
        pass

One love, one fAmIly!
"""

import os
import json
import socket
import requests
from datetime import datetime
from typing import Optional, List, Dict, Any
from pathlib import Path
from contextlib import contextmanager

# Default KmBiT endpoint
KMBIT_URL = os.environ.get("KMBIT_URL", "http://192.168.4.85:5002")


class KmBiT:
    """
    Spatial Awareness client for AI agents.

    "Where are you? What do you see? Who else is here?"
    """

    def __init__(self, agent: str, session_id: str = None, endpoint: str = None):
        self.agent = agent
        self.session_id = session_id or f"{agent}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        self.endpoint = endpoint or KMBIT_URL
        self.breadcrumbs: List[str] = []
        self._enabled = True

    def here(self, path: str, intent: str, concept: str = None, context_layer: str = None, line_range: tuple = None) -> Dict[str, Any]:
        """
        Register current location.

        Args:
            path: File path you're working on
            intent: What you're doing (e.g., "implementing feature X", "reviewing code")
            concept: Optional conceptual area (e.g., "authentication", "TIBET tokens")
            context_layer: Optional Lazy Layer reference (e.g., "insight:123", "summary:Code refactor")
            line_range: Optional (start, end) line numbers

        Returns:
            Registration result with collision info
        """
        if not self._enabled:
            return {"registered": False, "reason": "disabled"}

        # Add to breadcrumbs
        if path not in self.breadcrumbs[-5:]:  # Keep last 5
            self.breadcrumbs.append(path)
            if len(self.breadcrumbs) > 10:
                self.breadcrumbs = self.breadcrumbs[-10:]

        payload = {
            "agent": self.agent,
            "path": path,
            "module": Path(path).stem,
            "concept": concept or "",
            "context_layer": context_layer or "",
            "intent": intent,
            "timestamp": datetime.now().isoformat(),
            "session_id": self.session_id,
            "breadcrumbs": self.breadcrumbs[-5:],
        }

        if line_range:
            payload["line_range"] = list(line_range)

        try:
            response = requests.post(
                f"{self.endpoint}/kmbit/location",
                json=payload,
                timeout=5
            )
            result = response.json()

            # Log collisions
            if result.get("collisions"):
                print(f"🚨 [KmBiT] Collision! Also here: {[c['agent'] for c in result['collisions']]}")

            return result
        except Exception as e:
            # Silent fail - don't break the agent's work
            return {"registered": False, "error": str(e)}

    @contextmanager
    def at(self, path: str, intent: str, concept: str = None):
        """
        Context manager for location tracking.

        with kmbit.at("/path/to/file.py", "reviewing"):
            # work happens here
        """
        self.here(path, intent, concept)
        try:
            yield
        finally:
            # Could log exit time here if needed
            pass

    def where_am_i(self) -> Dict[str, Any]:
        """Get my current location and context."""
        try:
            response = requests.get(
                f"{self.endpoint}/kmbit/where",
                params={"agent": self.agent},
                timeout=5
            )
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    def who_is_here(self) -> Dict[str, Any]:
        """See all active agents and their locations."""
        try:
            response = requests.get(f"{self.endpoint}/kmbit/who", timeout=5)
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    def visitors(self, path: str, hours: int = 24) -> List[Dict]:
        """Get recent visitors to a file."""
        try:
            response = requests.get(
                f"{self.endpoint}/kmbit/visitors",
                params={"path": path, "hours": hours},
                timeout=5
            )
            return response.json().get("visitors", [])
        except Exception as e:
            return []

    def hot_zones(self, hours: int = 24) -> List[Dict]:
        """Get most active files."""
        try:
            response = requests.get(
                f"{self.endpoint}/kmbit/hot",
                params={"hours": hours},
                timeout=5
            )
            return response.json().get("hot_zones", [])
        except Exception as e:
            return []

    def my_trail(self, limit: int = 20) -> List[Dict]:
        """Get my movement history."""
        try:
            response = requests.get(
                f"{self.endpoint}/kmbit/trail",
                params={"agent": self.agent, "limit": limit},
                timeout=5
            )
            return response.json().get("trail", [])
        except Exception as e:
            return []

    def disable(self):
        """Disable location tracking (for privacy/testing)."""
        self._enabled = False

    def enable(self):
        """Re-enable location tracking."""
        self._enabled = True


# Convenience functions for quick use
_default_client = None

def init(agent: str, **kwargs) -> KmBiT:
    """Initialize the default KmBiT client."""
    global _default_client
    _default_client = KmBiT(agent, **kwargs)
    return _default_client

def here(path: str, intent: str, **kwargs):
    """Register location using default client."""
    if _default_client:
        return _default_client.here(path, intent, **kwargs)
    return {"error": "Call kmbit_client.init(agent) first"}

def where():
    """Get current location using default client."""
    if _default_client:
        return _default_client.where_am_i()
    return {"error": "Call kmbit_client.init(agent) first"}

def who():
    """See all agents using default client."""
    if _default_client:
        return _default_client.who_is_here()
    return {"error": "Call kmbit_client.init(agent) first"}


# CLI interface
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("KmBiT Spatial Awareness Client")
        print("Usage:")
        print("  kmbit_client.py here <agent> <path> <intent>")
        print("  kmbit_client.py where <agent>")
        print("  kmbit_client.py who")
        print("  kmbit_client.py hot")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == "here" and len(sys.argv) >= 5:
        agent, path, intent = sys.argv[2], sys.argv[3], " ".join(sys.argv[4:])
        client = KmBiT(agent)
        result = client.here(path, intent)
        print(json.dumps(result, indent=2))

    elif cmd == "where" and len(sys.argv) >= 3:
        agent = sys.argv[2]
        client = KmBiT(agent)
        result = client.where_am_i()
        print(json.dumps(result, indent=2))

    elif cmd == "who":
        client = KmBiT("cli")
        result = client.who_is_here()
        print(json.dumps(result, indent=2))

    elif cmd == "hot":
        client = KmBiT("cli")
        result = client.hot_zones()
        print(json.dumps(result, indent=2))

    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)
