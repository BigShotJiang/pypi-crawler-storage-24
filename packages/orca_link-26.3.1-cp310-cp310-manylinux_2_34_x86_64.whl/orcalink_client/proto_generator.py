"""
Protobuf 文件自动生成器

每次导入时自动生成 protobuf Python 文件（*_pb2.py），确保使用当前环境的 grpcio-tools 版本。
这样可以避免因切换 conda 环境导致的版本不匹配问题。
"""
import os
import sys
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


def ensure_pb2_files_exist():
    """
    确保 protobuf 生成文件存在，每次启动时都重新生成以匹配当前环境的 grpcio-tools 版本
    
    这样可以避免因切换 conda 环境导致的版本不匹配问题。
    
    Returns:
        bool: 成功返回 True，失败抛出异常
    """
    # 获取当前文件所在目录
    proto_dir = Path(__file__).parent / "proto"
    proto_file = proto_dir / "orcalink.proto"
    pb2_file = proto_dir / "orcalink_pb2.py"
    pb2_grpc_file = proto_dir / "orcalink_pb2_grpc.py"
    
    # 每次启动都重新生成，确保使用当前环境的 grpcio-tools 版本
    logger.info("正在生成 Protobuf Python 文件（使用当前环境的 grpcio-tools）...")
    
    # 检查 grpcio-tools 是否安装
    try:
        import grpc_tools.protoc
        import grpc_tools
    except ImportError:
        error_msg = (
            "缺少 grpcio-tools，无法生成 protobuf Python 文件。\n"
            "请安装: pip install grpcio-tools"
        )
        logger.error(error_msg)
        raise ImportError(error_msg)
    
    # 使用 grpc_tools.protoc 生成
    try:
        proto_include = Path(grpc_tools.__file__).parent / "_proto"
        
        result = grpc_tools.protoc.main([
            'grpc_tools.protoc',
            f'--proto_path={proto_dir}',
            f'--proto_path={proto_include}',
            f'--python_out={proto_dir}',
            f'--grpc_python_out={proto_dir}',
            str(proto_file)
        ])
        
        if result != 0:
            raise RuntimeError(f"protoc 返回错误代码: {result}")
        
        # 修复生成的文件中的导入语句（绝对导入 -> 相对导入）
        _fix_grpc_imports(pb2_grpc_file)
        
        logger.info(f"✅ 成功生成: {pb2_file.name}, {pb2_grpc_file.name}")
        return True
        
    except Exception as e:
        logger.error(f"❌ 生成 protobuf 文件失败: {e}")
        raise


def _fix_grpc_imports(grpc_file: Path):
    """
    修复 gRPC 生成文件中的导入语句，将绝对导入改为相对导入
    
    Args:
        grpc_file: *_pb2_grpc.py 文件路径
    """
    try:
        content = grpc_file.read_text(encoding='utf-8')
        
        # 将 "import orcalink_pb2 as orcalink__pb2" 改为 "from . import orcalink_pb2 as orcalink__pb2"
        content = content.replace(
            'import orcalink_pb2 as orcalink__pb2',
            'from . import orcalink_pb2 as orcalink__pb2'
        )
        
        grpc_file.write_text(content, encoding='utf-8')
        logger.debug(f"已修复 {grpc_file.name} 的导入语句")
        
    except Exception as e:
        logger.warning(f"修复导入语句失败: {e}")
        # 不抛出异常，因为这不是致命错误

