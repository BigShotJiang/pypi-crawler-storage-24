"""
OrcaLink Protocol Buffers

.proto 文件及生成的 Python 文件
"""

# 自动生成 pb2 文件（如果不存在或过期）
from orcalink_client.proto_generator import ensure_pb2_files_exist
ensure_pb2_files_exist()
