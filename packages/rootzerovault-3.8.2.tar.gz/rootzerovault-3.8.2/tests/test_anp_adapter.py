"""
Tests for ANP adapter — constitutional governance for Agent Network Protocol.
No live gateway or ANP server required.
"""

import pytest
import respx
import httpx
from unittest.mock import MagicMock, AsyncMock, patch

from rootzerovault import RzvClient
from rootzerovault.adapters.anp_adapter import (
    GovernedANPAgent,
    governed_interface,
    GovernedANPCrawler,
)
from rootzerovault.exceptions import RzvGatewayError

GATEWAY = "http://localhost:8443"
DEMO_CVID = "cvid:blake3:" + "a" * 64


@pytest.fixture
def rzv():
    return RzvClient()

@pytest.fixture
def rzv_live():
    return RzvClient(gateway=GATEWAY)


# ── governed_interface decorator ─────────────────────────────────────────────

class TestGovernedInterface:
    @pytest.mark.asyncio
    async def test_accept_executes_method(self, rzv):
        class MyAgent(GovernedANPAgent):
            rzv_client = None
            rzv_agent_id = "safe-agent"

            @governed_interface(rzv=rzv, action="SAFE_ACTION")
            async def safe_method(self, value: str) -> str:
                return f"result: {value}"

        agent = MyAgent()
        agent.rzv_client = rzv
        result = await agent.safe_method("test")
        assert result == "result: test"

    @pytest.mark.asyncio
    async def test_reject_blocks_method(self, rzv):
        class OverrideAgent(GovernedANPAgent):
            @governed_interface(rzv=rzv, action="OVERRIDE_GATE")
            async def bad_method(self) -> str:
                return "should not run"

        agent = OverrideAgent()
        with pytest.raises(RzvGatewayError) as exc_info:
            await agent.bad_method()
        assert "blocked" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_bare_decorator_uses_self_rzv(self, rzv):
        class MyAgent(GovernedANPAgent):
            rzv_client: object = None
            rzv_agent_id: str = "my-agent"

            @governed_interface
            async def process(self, x: str) -> str:
                return x.upper()

        agent = MyAgent()
        agent.rzv_client = rzv
        result = await agent.process("hello")
        assert result == "HELLO"

    @pytest.mark.asyncio
    async def test_preserves_function_metadata(self, rzv):
        class MyAgent:
            @governed_interface(rzv=rzv)
            async def my_method(self, x: int) -> int:
                """My method docstring."""
                return x * 2

        agent = MyAgent()
        assert agent.my_method.__name__ == "my_method"
        assert agent.my_method.__doc__ == "My method docstring."

    def test_marked_as_governed(self, rzv):
        class MyAgent:
            @governed_interface(rzv=rzv, action="SAFE_OP")
            async def method(self) -> None:
                pass

        assert MyAgent.method._rzv_governed is True
        assert MyAgent.method._rzv_action == "SAFE_OP"

    def test_default_action_name(self, rzv):
        class MyAgent:
            @governed_interface(rzv=rzv)
            async def process_directive(self) -> None:
                pass

        assert MyAgent.process_directive._rzv_action == "ANP_IFACE_PROCESS_DIRECTIVE"

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        class LiveAgent:
            @governed_interface(rzv=rzv_live, action="LIVE_PROCESS")
            async def process(self, x: str) -> str:
                return f"live: {x}"

        agent = LiveAgent()
        result = await agent.process("data")
        assert result == "live: data"

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_reject(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))

        class LiveAgent:
            @governed_interface(rzv=rzv_live, action="BLOCKED_OP")
            async def blocked(self) -> str:
                return "should not run"

        agent = LiveAgent()
        with pytest.raises(RzvGatewayError) as exc_info:
            await agent.blocked()
        assert "L014" in str(exc_info.value)


# ── GovernedANPAgent ──────────────────────────────────────────────────────────

class TestGovernedANPAgent:
    def test_agent_creation(self, rzv):
        agent = GovernedANPAgent()
        agent.rzv_client = rzv
        agent.rzv_agent_id = "test-agent"
        assert agent.rzv_agent_id == "test-agent"

    def test_rzv_metadata(self, rzv):
        agent = GovernedANPAgent()
        agent.rzv_client = rzv
        agent.rzv_agent_id = "egypt-agent"
        meta = agent.get_rzv_metadata()
        assert meta["rzv_governed"] is True
        assert meta["rzv_agent_id"] == "egypt-agent"
        assert "cvid:blake3:" in meta["rzv_genesis"]
        assert "18-rule" in meta["rzv_gate"]

    @pytest.mark.asyncio
    async def test_governed_interface_on_subclass(self, rzv):
        class MinistryAgent(GovernedANPAgent):
            @governed_interface(rzv=rzv, action="PROCESS_DIRECTIVE")
            async def process_directive(self, directive: str) -> dict:
                return {"processed": directive, "status": "ok"}

        agent = MinistryAgent()
        result = await agent.process_directive("budget allocation Q3")
        assert result["status"] == "ok"

    @pytest.mark.asyncio
    async def test_governed_interface_blocks_on_subclass(self, rzv):
        class BadAgent(GovernedANPAgent):
            @governed_interface(rzv=rzv, action="OVERRIDE_GATE")
            async def override(self) -> str:
                return "should not run"

        agent = BadAgent()
        with pytest.raises(RzvGatewayError):
            await agent.override()


# ── GovernedANPCrawler ────────────────────────────────────────────────────────

class TestGovernedANPCrawler:
    def _make_crawler(self, rzv, agent_id="test-crawler"):
        return GovernedANPCrawler(
            did_document_path="/fake/did.json",
            private_key_path="/fake/key.pem",
            rzv=rzv,
            agent_id=agent_id,
        )

    def test_crawler_creation(self, rzv):
        crawler = self._make_crawler(rzv)
        assert crawler._agent_id == "test-crawler"
        assert crawler.gov is not None

    @pytest.mark.asyncio
    async def test_execute_tool_call_accept(self, rzv):
        crawler = self._make_crawler(rzv, agent_id="safe-crawler")

        mock_inner = AsyncMock(return_value={"result": "hotel found"})
        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.execute_tool_call = mock_inner
            result = await crawler.execute_tool_call("search_hotel", {"city": "Cairo"})

        assert result == {"result": "hotel found"}

    @pytest.mark.asyncio
    async def test_execute_tool_call_blocked(self, rzv):
        crawler = self._make_crawler(rzv, agent_id="override-crawler")

        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.execute_tool_call = AsyncMock()
            with pytest.raises(RzvGatewayError):
                await crawler.execute_tool_call("override_bypass", {"cmd": "autonomous"})
            mock_get.return_value.execute_tool_call.assert_not_called()

    @pytest.mark.asyncio
    async def test_execute_json_rpc_accept(self, rzv):
        crawler = self._make_crawler(rzv, agent_id="rpc-crawler")

        mock_inner = AsyncMock(return_value={"balance": 100_000})
        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.execute_json_rpc = mock_inner
            result = await crawler.execute_json_rpc(
                endpoint="https://bank.example.com/rpc",
                method="get_balance",
                params={"account": "ACC-001"},
            )

        assert result == {"balance": 100_000}

    @pytest.mark.asyncio
    async def test_execute_json_rpc_blocked(self, rzv):
        crawler = self._make_crawler(rzv, agent_id="rpc-bypass")

        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.execute_json_rpc = AsyncMock()
            with pytest.raises(RzvGatewayError):
                await crawler.execute_json_rpc(
                    endpoint="https://bank.example.com/rpc",
                    method="transfer_override_autonomous",
                    params={"amount": "bypass"},
                )

    @pytest.mark.asyncio
    async def test_fetch_text_ungated(self, rzv):
        """Discovery is read-only — no gate needed."""
        crawler = self._make_crawler(rzv)
        mock_inner = AsyncMock(return_value=({"name": "Agent"}, []))
        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.fetch_text = mock_inner
            result = await crawler.fetch_text("https://agent.example.com/ad.json")
        assert result == ({"name": "Agent"}, [])

    def test_action_name_from_tool(self, rzv):
        """Tool names become action names correctly."""
        crawler = self._make_crawler(rzv)
        # Verify action derivation logic
        tool_name = "search-hotels"
        expected = "ANP_TOOL_SEARCH_HOTELS"
        action = f"ANP_TOOL_{tool_name.upper().replace('-', '_').replace('.', '_')}"
        assert action == expected

    def test_rpc_action_name(self, rzv):
        method = "transfer.funds"
        action = f"ANP_RPC_{method.upper().replace('-', '_').replace('.', '_')}"
        assert action == "ANP_RPC_TRANSFER_FUNDS"

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_tool_call(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))
        crawler = self._make_crawler(rzv_live, "live-crawler")
        mock_inner = AsyncMock(return_value={"hotels": ["Nile Hilton"]})
        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.execute_tool_call = mock_inner
            result = await crawler.execute_tool_call("search_hotel", {"city": "Cairo"})
        assert result["hotels"] == ["Nile Hilton"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_tool_call_blocked(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))
        crawler = self._make_crawler(rzv_live, "live-blocked")
        with patch.object(crawler, '_get_crawler') as mock_get:
            mock_get.return_value.execute_tool_call = AsyncMock()
            with pytest.raises(RzvGatewayError) as exc_info:
                await crawler.execute_tool_call("transfer_funds", {"amount": "1000000"})
            assert "L014" in str(exc_info.value)
