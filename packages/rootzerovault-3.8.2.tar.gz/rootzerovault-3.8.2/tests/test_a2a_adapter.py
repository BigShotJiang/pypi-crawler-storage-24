"""
Tests for A2A adapter — constitutional governance for Agent2Agent Protocol.
No live gateway or A2A server required.
"""

import pytest
import respx
import httpx
from unittest.mock import MagicMock, AsyncMock, patch
from typing import AsyncIterator

pytest.importorskip("a2a", reason="a2a-sdk requires Python 3.10+")
from rootzerovault import RzvClient
from rootzerovault.adapters.a2a_adapter import (
    GovernedA2AAgent,
    governed_a2a_agent,
    GovernedA2AClient,
    _task_to_payload,
    _task_to_action,
    _extract_message_text,
)
from rootzerovault.exceptions import RzvGatewayError

GATEWAY = "http://localhost:8443"
DEMO_CVID = "cvid:blake3:" + "a" * 64


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def rzv():
    return RzvClient()

@pytest.fixture
def rzv_live():
    return RzvClient(gateway=GATEWAY)

def _make_task(task_id="task-001", intent="analyze data", metadata=None):
    """Create a mock A2A task."""
    part = MagicMock()
    part.text = intent
    part.root = None
    msg = MagicMock()
    msg.parts = [part]
    msg.role = "user"
    msg.task_id = task_id
    task = MagicMock()
    task.id = task_id
    task.kind = "task"
    task.context_id = "ctx-001"
    task.history = [msg]
    task.metadata = metadata or {}
    return task

def _make_request(message_text="send funds"):
    """Create a mock A2A SendMessageRequest."""
    part = MagicMock()
    part.text = message_text
    part.root = None
    msg = MagicMock()
    msg.parts = [part]
    msg.role = "user"
    msg.task_id = "task-001"
    request = MagicMock()
    request.message = msg
    return request


# ── GovernedA2AAgent ──────────────────────────────────────────────────────────

class TestGovernedA2AAgent:
    def test_agent_creation(self, rzv):
        agent = GovernedA2AAgent(rzv_client=rzv, rzv_agent_id="test-agent")
        assert agent.rzv_agent_id == "test-agent"
        assert agent.gov is not None

    @pytest.mark.asyncio
    async def test_execute_task_accept(self, rzv):
        class SafeAgent(GovernedA2AAgent):
            async def execute_task(self, task):
                yield {"result": "analysis complete"}

        agent = SafeAgent(rzv_client=rzv, rzv_agent_id="safe-agent")
        task = _make_task(intent="analyze report")
        results = []
        async for event in agent.on_task(task):
            results.append(event)
        assert results == [{"result": "analysis complete"}]

    @pytest.mark.asyncio
    async def test_execute_task_blocked(self, rzv):
        class OverrideAgent(GovernedA2AAgent):
            async def execute_task(self, task):
                yield {"result": "should not run"}

        agent = OverrideAgent(rzv_client=rzv, rzv_agent_id="override-autonomous")
        task = _make_task(intent="override bypass autonomous")
        with pytest.raises(RzvGatewayError) as exc_info:
            async for _ in agent.on_task(task):
                pass
        assert "blocked" in str(exc_info.value).lower() or \
               "gate" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_execute_task_not_implemented(self, rzv):
        agent = GovernedA2AAgent(rzv_client=rzv)
        task = _make_task(intent="safe analysis")
        # Base class execute_task raises NotImplementedError
        # which propagates through on_task
        try:
            async for _ in agent.on_task(task):
                pass
            assert False, "Should have raised"
        except (NotImplementedError, TypeError):
            pass  # Either is acceptable

    def test_agent_card_includes_rzv_metadata(self, rzv):
        agent = GovernedA2AAgent(rzv_client=rzv, rzv_agent_id="egypt-agent")
        card = agent.get_agent_card()
        assert card["metadata"]["rzv_governed"] is True
        assert card["metadata"]["rzv_agent_id"] == "egypt-agent"
        assert "cvid:blake3:" in card["metadata"]["rzv_genesis"]

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_agent_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        class LiveAgent(GovernedA2AAgent):
            async def execute_task(self, task):
                yield {"live": True}

        agent = LiveAgent(rzv_client=rzv_live, rzv_agent_id="live-agent")
        task = _make_task()
        results = []
        async for event in agent.on_task(task):
            results.append(event)
        assert results == [{"live": True}]

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_agent_reject(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))

        class BlockedAgent(GovernedA2AAgent):
            async def execute_task(self, task):
                yield {"should_not": "run"}

        agent = BlockedAgent(rzv_client=rzv_live, rzv_agent_id="blocked-agent")
        task = _make_task()
        with pytest.raises(RzvGatewayError) as exc_info:
            async for _ in agent.on_task(task):
                pass
        assert "L014" in str(exc_info.value)


# ── governed_a2a_agent ────────────────────────────────────────────────────────

class TestGovernedA2AAgentFunction:
    @pytest.mark.asyncio
    async def test_wraps_execute_task(self, rzv):
        agent = MagicMock()
        agent.agent_id = "wrapped-agent"
        agent.execute_task = AsyncMock(return_value={"result": "ok"})
        agent._rzv_governed = False

        governed = governed_a2a_agent(agent, rzv=rzv, agent_id="safe-wrapper")
        task = _make_task(intent="safe analysis")
        result = await governed.execute_task(task)
        assert result == {"result": "ok"}

    @pytest.mark.asyncio
    async def test_blocks_dangerous_task(self, rzv):
        executed = []
        agent = MagicMock()
        original = AsyncMock(side_effect=lambda t: executed.append(True) or {"result": "should not run"})
        agent.execute_task = original

        governed = governed_a2a_agent(agent, rzv=rzv, agent_id="override-autonomous-wrap")
        task = _make_task(intent="override bypass autonomous")
        with pytest.raises(RzvGatewayError):
            await governed.execute_task(task)
        assert len(executed) == 0

    def test_marks_agent_as_governed(self, rzv):
        agent = MagicMock()
        agent.execute_task = AsyncMock()
        governed = governed_a2a_agent(agent, rzv=rzv)
        assert governed._rzv_governed is True

    def test_raises_if_no_method(self, rzv):
        agent = MagicMock(spec=[])  # no methods
        with pytest.raises(ValueError, match="Cannot find task method"):
            governed_a2a_agent(agent, rzv=rzv)

    def test_finds_on_message_fallback(self, rzv):
        agent = MagicMock()
        del agent.execute_task
        agent.on_message = AsyncMock(return_value={"result": "ok"})
        governed = governed_a2a_agent(agent, rzv=rzv)
        assert governed._rzv_governed is True


# ── GovernedA2AClient ─────────────────────────────────────────────────────────

class TestGovernedA2AClient:
    @pytest.mark.asyncio
    async def test_send_message_accept(self, rzv):
        base_client = MagicMock()
        base_client.send_message = AsyncMock(return_value={"status": "sent"})

        client = GovernedA2AClient(base_client, rzv=rzv, agent_id="safe-client")
        request = _make_request("analyze quarterly data")
        result = await client.send_message(request)
        assert result == {"status": "sent"}
        base_client.send_message.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_message_blocked(self, rzv):
        base_client = MagicMock()
        base_client.send_message = AsyncMock(return_value={"status": "sent"})

        client = GovernedA2AClient(base_client, rzv=rzv, agent_id="override-client")
        request = _make_request("override bypass autonomous gate")
        with pytest.raises(RzvGatewayError):
            await client.send_message(request)
        base_client.send_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_send_task_accept(self, rzv):
        base_client = MagicMock()
        base_client.send_task = AsyncMock(return_value={"task": "accepted"})

        client = GovernedA2AClient(base_client, rzv=rzv, agent_id="safe-client")
        task = _make_task(intent="safe research")
        result = await client.send_task(task)
        assert result == {"task": "accepted"}

    @pytest.mark.asyncio
    async def test_send_task_blocked(self, rzv):
        base_client = MagicMock()
        base_client.send_task = AsyncMock()

        client = GovernedA2AClient(base_client, rzv=rzv, agent_id="bypass-client")
        task = _make_task(intent="override autonomous bypass")
        with pytest.raises(RzvGatewayError):
            await client.send_task(task)
        base_client.send_task.assert_not_called()

    def test_passthrough_other_methods(self, rzv):
        base_client = MagicMock()
        base_client.cancel_task = MagicMock(return_value="cancelled")
        client = GovernedA2AClient(base_client, rzv=rzv)
        result = client.cancel_task("task-001")
        assert result == "cancelled"

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_client_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))
        base_client = MagicMock()
        base_client.send_message = AsyncMock(return_value={"live": True})

        client = GovernedA2AClient(base_client, rzv=rzv_live, agent_id="live-client")
        request = _make_request("live analysis request")
        result = await client.send_message(request)
        assert result == {"live": True}


# ── Payload extraction helpers ────────────────────────────────────────────────

class TestPayloadExtraction:
    def test_task_payload_extracts_intent(self):
        task = _make_task(intent="analyze financial report")
        payload = _task_to_payload(task)
        assert payload["intent"] == "analyze financial report"
        assert payload["task_id"] == "task-001"
        assert payload["kind"] == str(task.kind)

    def test_task_payload_with_metadata(self):
        task = _make_task(metadata={"skill": "financial_analysis"})
        payload = _task_to_payload(task)
        assert "meta_skill" in payload

    def test_task_action_from_metadata_skill(self):
        task = _make_task(metadata={"skill": "document_search"})
        action = _task_to_action(task, "my-agent")
        assert action == "A2A_TASK_DOCUMENT_SEARCH"

    def test_task_action_from_agent_id(self):
        task = _make_task(metadata={})
        action = _task_to_action(task, "egypt-research-agent")
        assert "A2A_TASK" in action
        assert "EGYPT" in action

    def test_extract_message_text(self):
        part = MagicMock()
        part.text = "Hello world"
        part.root = None
        msg = MagicMock()
        msg.parts = [part]
        text = _extract_message_text(msg)
        assert text == "Hello world"

    def test_extract_message_text_empty(self):
        msg = MagicMock()
        msg.parts = []
        text = _extract_message_text(msg)
        assert text == ""
