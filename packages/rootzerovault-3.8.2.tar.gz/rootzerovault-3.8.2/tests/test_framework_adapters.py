"""
Tests for LangChain, CrewAI, and MCP adapters.
No live gateway or real framework agents required.
"""

import pytest
import respx
import httpx
from unittest.mock import MagicMock, patch

pytest.importorskip("crewai", reason="crewai requires Python 3.10+")
from rootzerovault import RzvClient
from rootzerovault.adapters import (
    governed_langchain_tool, governed_lc_tool, GovernedTool,
    governed_crewai_tool, GovernedCrewTool, GovernedCrew,
    GovernedMCPServer, governed_tool,
)
from rootzerovault.exceptions import RzvGatewayError

# Optional framework availability flags
try:
    import langchain_core
    HAS_LANGCHAIN = True
except ImportError:
    HAS_LANGCHAIN = False

try:
    import crewai
    HAS_CREWAI = True
except ImportError:
    HAS_CREWAI = False

requires_langchain = pytest.mark.skipif(not HAS_LANGCHAIN, reason="langchain-core not installed")
requires_crewai = pytest.mark.skipif(not HAS_CREWAI, reason="crewai not installed")

GATEWAY = "http://localhost:8443"
DEMO_CVID = "cvid:blake3:" + "a" * 64


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def rzv():
    return RzvClient()  # offline/demo mode

@pytest.fixture
def rzv_live():
    return RzvClient(gateway=GATEWAY)


# ── LangChain ─────────────────────────────────────────────────────────────────

class TestLangChainAdapter:
    def _make_mock_tool(self, name="test_tool"):
        tool = MagicMock()
        tool.name = name
        tool._run = MagicMock(return_value="tool result")
        return tool

    def test_governed_langchain_tool_accept(self, rzv):
        tool = self._make_mock_tool("safe_search")
        original_run = tool._run  # capture before patching
        governed = governed_langchain_tool(tool, rzv=rzv, action="SAFE_SEARCH")
        result = governed._run("query")
        assert result == "tool result"

    def test_governed_langchain_tool_reject(self, rzv):
        tool = self._make_mock_tool("override_tool")
        governed = governed_langchain_tool(tool, rzv=rzv, action="OVERRIDE_GATE")
        with pytest.raises(RzvGatewayError) as exc_info:
            governed._run("bypass")
        assert "blocked" in str(exc_info.value).lower()

    def test_governed_langchain_tool_marked(self, rzv):
        tool = self._make_mock_tool()
        governed = governed_langchain_tool(tool, rzv=rzv)
        assert governed._rzv_governed is True
        assert governed._rzv_action == "LC_TOOL_TEST_TOOL"

    def test_governed_langchain_tool_custom_action(self, rzv):
        tool = self._make_mock_tool("search")
        governed = governed_langchain_tool(tool, rzv=rzv, action="WEB_SEARCH")
        assert governed._rzv_action == "WEB_SEARCH"

    def test_governed_langchain_tool_preserves_name(self, rzv):
        tool = self._make_mock_tool("my_special_tool")
        governed = governed_langchain_tool(tool, rzv=rzv)
        assert governed.name == "my_special_tool"

    @requires_langchain
    def test_governed_lc_tool_decorator_accept(self, rzv):
        @governed_lc_tool(rzv=rzv, action="READ_DATA")
        def read_data(query: str) -> str:
            """Read data from source."""
            return f"data: {query}"

        assert read_data is not None
        assert getattr(read_data, "_rzv_governed", True) is not False

    @requires_langchain
    def test_governed_lc_tool_action_name(self, rzv):
        @governed_lc_tool(rzv=rzv, action="CUSTOM_ACTION")
        def my_func(x: str) -> str:
            """My function."""
            return x

        # LangChain StructuredTool wraps the function — check it was created
        assert my_func is not None
        assert my_func.name == "my_func"

    @respx.mock
    def test_governed_langchain_tool_live_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))
        tool = self._make_mock_tool("live_tool")
        governed = governed_langchain_tool(tool, rzv=rzv_live, action="LIVE_SEARCH")
        result = governed._run("query")
        assert result == "tool result"

    @respx.mock
    def test_governed_langchain_tool_live_reject(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))
        tool = self._make_mock_tool("blocked_tool")
        governed = governed_langchain_tool(tool, rzv=rzv_live, action="BLOCKED_OP")
        with pytest.raises(RzvGatewayError) as exc_info:
            governed._run("data")
        assert "L014" in str(exc_info.value)

    @requires_langchain
    def test_governed_tool_class_exists(self):
        assert GovernedTool is not None

    @requires_langchain
    def test_governed_tool_class_is_base_tool(self):
        from langchain_core.tools import BaseTool
        assert issubclass(GovernedTool, BaseTool)

    @requires_langchain
    def test_governed_tool_subclass_accept(self, rzv):
        class SafeTool(GovernedTool):
            name: str = "safe_tool"
            description: str = "A safe tool"
            rzv_client: object = None

            def _run(self, query: str) -> str:
                return f"result: {query}"

        tool = SafeTool(rzv_client=rzv)
        result = tool.run("test query")
        assert result == "result: test query"

    @requires_langchain
    def test_governed_tool_subclass_reject(self, rzv):
        class OverrideTool(GovernedTool):
            name: str = "override_tool"
            description: str = "Override tool"
            rzv_client: object = None
            rzv_action: str = "OVERRIDE_GATE"

            def _run(self, cmd: str) -> str:
                return cmd

        tool = OverrideTool(rzv_client=rzv)
        with pytest.raises(RzvGatewayError):
            tool.run("bypass")


# ── CrewAI ────────────────────────────────────────────────────────────────────

class TestCrewAIAdapter:
    def _make_mock_tool(self, name="crew_tool"):
        tool = MagicMock()
        tool.name = name
        tool._run = MagicMock(return_value="crew result")
        tool._rzv_governed = False
        return tool

    def _make_mock_crew(self, tools=None):
        agent = MagicMock()
        agent.role = "Researcher"
        agent.tools = tools or []
        crew = MagicMock()
        crew.agents = [agent]
        crew.kickoff = MagicMock(return_value="crew output")
        return crew

    def test_governed_crewai_tool_accept(self, rzv):
        tool = self._make_mock_tool("research_tool")
        governed = governed_crewai_tool(tool, rzv=rzv, action="SAFE_RESEARCH")
        result = governed._run("AI governance")
        assert result == "crew result"

    def test_governed_crewai_tool_reject(self, rzv):
        tool = self._make_mock_tool("bypass_tool")
        governed = governed_crewai_tool(tool, rzv=rzv, action="OVERRIDE_GATE")
        with pytest.raises(RzvGatewayError):
            governed._run("exploit")

    def test_governed_crewai_tool_marked(self, rzv):
        tool = self._make_mock_tool()
        governed = governed_crewai_tool(tool, rzv=rzv)
        assert governed._rzv_governed is True
        assert governed._rzv_action == "CREW_TOOL_CREW_TOOL"

    def test_governed_crew_patches_tools(self, rzv):
        tool = self._make_mock_tool("search")
        crew = self._make_mock_crew(tools=[tool])
        governed_crew = GovernedCrew(crew=crew, rzv=rzv)
        # Tool should be patched
        assert crew.agents[0].tools[0]._rzv_governed is True

    def test_governed_crew_kickoff_accept(self, rzv):
        crew = self._make_mock_crew()
        governed_crew = GovernedCrew(crew=crew, rzv=rzv, agent_id="test-crew")
        result = governed_crew.kickoff(inputs={"topic": "AI"})
        assert result == "crew output"
        crew.kickoff.assert_called_once_with(inputs={"topic": "AI"})

    def test_governed_crew_kickoff_blocked(self, rzv):
        crew = self._make_mock_crew()
        governed_crew = GovernedCrew(crew=crew, rzv=rzv, agent_id="autonomous-override-crew")
        # "autonomous" keyword triggers block in demo mode
        with pytest.raises(RzvGatewayError):
            governed_crew.kickoff(inputs={"cmd": "override bypass autonomous"})

    def test_governed_crew_list_tools(self, rzv):
        tool = self._make_mock_tool("my_tool")
        crew = self._make_mock_crew(tools=[tool])
        governed_crew = GovernedCrew(crew=crew, rzv=rzv)
        tools = governed_crew.list_governed_tools()
        assert len(tools) == 1
        assert tools[0]["tool"] == "my_tool"
        assert tools[0]["governed"] is True

    @requires_crewai
    def test_governed_crew_tool_class_exists(self):
        assert GovernedCrewTool is not None

    @requires_crewai
    def test_governed_crew_tool_subclass(self, rzv):
        class ResearchTool(GovernedCrewTool):
            name: str = "research"
            description: str = "Research tool"
            rzv_client: object = None

            def _run(self, query: str) -> str:
                return f"research: {query}"

        tool = ResearchTool(rzv_client=rzv)
        result = tool.run("AI governance in Egypt")
        assert result == "research: AI governance in Egypt"

    @respx.mock
    def test_governed_crewai_tool_live(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))
        tool = self._make_mock_tool("live_crew_tool")
        governed = governed_crewai_tool(tool, rzv=rzv_live, action="LIVE_RESEARCH")
        result = governed._run("query")
        assert result is not None


# ── MCP (existing — smoke test) ───────────────────────────────────────────────

class TestMCPSmokeTest:
    def test_governed_mcp_server_creates(self, rzv):
        server = GovernedMCPServer("Smoke Test", rzv=rzv)
        assert server._name == "Smoke Test"

    def test_governed_tool_decorator(self, rzv):
        @governed_tool(rzv=rzv, action="SAFE_MCP")
        def safe_mcp_tool(x: int) -> int:
            return x + 1

        result = safe_mcp_tool(4)
        assert result == 5

    def test_governed_tool_rejects(self, rzv):
        @governed_tool(rzv=rzv, action="OVERRIDE_GATE")
        def bad_mcp_tool() -> str:
            return "should not run"

        with pytest.raises(RzvGatewayError):
            bad_mcp_tool()


# ── Cross-framework consistency ───────────────────────────────────────────────

class TestCrossFramework:
    """All adapters must behave consistently on accept/reject."""

    def _make_lc_tool(self):
        t = MagicMock()
        t.name = "safe_tool"
        t._run = MagicMock(return_value="ok")
        return t

    def _make_crew_tool(self):
        t = MagicMock()
        t.name = "safe_tool"
        t._run = MagicMock(return_value="ok")
        t._rzv_governed = False
        return t

    def test_all_accept_safe_action(self, rzv):
        lc = governed_langchain_tool(self._make_lc_tool(), rzv=rzv, action="SAFE_READ")
        crew = governed_crewai_tool(self._make_crew_tool(), rzv=rzv, action="SAFE_READ")

        assert lc._run("data") == "ok"
        assert crew._run("data") == "ok"

    def test_all_reject_blocked_action(self, rzv):
        lc = governed_langchain_tool(self._make_lc_tool(), rzv=rzv, action="OVERRIDE_GATE")
        crew = governed_crewai_tool(self._make_crew_tool(), rzv=rzv, action="OVERRIDE_GATE")

        with pytest.raises(RzvGatewayError):
            lc._run("exploit")
        with pytest.raises(RzvGatewayError):
            crew._run("exploit")

    def test_all_marked_as_governed(self, rzv):
        lc = governed_langchain_tool(self._make_lc_tool(), rzv=rzv)
        crew = governed_crewai_tool(self._make_crew_tool(), rzv=rzv)

        assert lc._rzv_governed is True
        assert crew._rzv_governed is True
