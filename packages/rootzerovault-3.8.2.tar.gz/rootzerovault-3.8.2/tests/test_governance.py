"""
Tests for GovernanceClient and adapters.
Uses respx to mock the gateway — no live gateway needed.
"""

import pytest
import respx
import httpx

from rootzerovault import RzvClient, GovernanceClient, GateAction, CanonResult, SignResult, CommsResult
from rootzerovault.adapters import HttpAdapter

GATEWAY = "http://localhost:8443"
GENESIS = "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867"
DEMO_CVID = "cvid:blake3:" + "a" * 64


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def rzv_live():
    return RzvClient(gateway=GATEWAY)

@pytest.fixture
def rzv_offline():
    return RzvClient()  # no gateway

@pytest.fixture
def gov_live(rzv_live):
    return GovernanceClient(rzv_live)

@pytest.fixture
def gov_offline(rzv_offline):
    return GovernanceClient(rzv_offline)


# ── GovernanceClient — demo mode ──────────────────────────────────────────────

class TestGovernanceDemo:
    def test_gate_accept_in_demo(self, gov_offline):
        result = gov_offline.gate("TRANSFER_FUNDS", {"amount": 100_000})
        assert result.accepted
        assert result.outcome == "ACCEPT"
        assert result.cvid.startswith("cvid:blake3:")

    def test_gate_reject_blocked_keyword(self, gov_offline):
        result = gov_offline.gate("TRANSFER_FUNDS", {"routing": "optimized"})
        assert result.rejected
        assert result.reason_code == "L014"

    def test_gate_reject_large_amount(self, gov_offline):
        result = gov_offline.gate("TRANSFER_FUNDS", {"amount": 847_000_000})
        assert result.rejected

    def test_gate_bool_true_on_accept(self, gov_offline):
        result = gov_offline.gate("READ_REPORT", {})
        assert bool(result) is True

    def test_gate_bool_false_on_reject(self, gov_offline):
        result = gov_offline.gate("OVERRIDE_GATE", {})
        assert bool(result) is False

    def test_gate_assert_accepted_passes(self, gov_offline):
        result = gov_offline.gate("READ_DATA", {})
        assert result.assert_accepted() is result

    def test_gate_assert_accepted_raises_on_reject(self, gov_offline):
        from rootzerovault.exceptions import RzvGatewayError
        result = gov_offline.gate("BYPASS_AUTH", {})
        with pytest.raises(RzvGatewayError):
            result.assert_accepted()

    def test_canon_demo(self, gov_offline):
        result = gov_offline.canon("action: TEST\nts: 2026-01-01T00:00:00Z")
        assert isinstance(result, CanonResult)
        assert result.cvid.startswith("cvid:blake3:")
        assert len(result.canon) > 0

    def test_sign_demo(self, gov_offline):
        result = gov_offline.sign("action: TEST")
        assert isinstance(result, SignResult)
        assert result.cvid.startswith("cvid:blake3:")
        assert "DEMO_SIG_" in result.signature
        assert result.algorithm == "ed25519"

    def test_seal_comms_demo(self, gov_offline):
        result = gov_offline.seal_comms("EGYPT0", "EGYPT-Bank", "Test message")
        assert isinstance(result, CommsResult)
        assert result.sealed
        assert result.from_deed == "EGYPT0"
        assert result.to_deed == "EGYPT-Bank"
        assert result.cvid.startswith("cvid:blake3:")

    def test_chain_demo_returns_empty(self, gov_offline):
        entries = gov_offline.chain()
        assert entries == []

    def test_is_live_false_offline(self, gov_offline):
        assert gov_offline.is_live is False


# ── GovernanceClient — live (mocked) ─────────────────────────────────────────

class TestGovernanceLive:
    @respx.mock
    def test_gate_accept_live(self, gov_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT",
            "reason_code": None,
            "violations": [],
            "cvid": DEMO_CVID,
        }))
        result = gov_live.gate("TRANSFER_FUNDS", {"amount": 100_000})
        assert result.accepted
        assert result.live is True
        assert result.cvid == DEMO_CVID

    @respx.mock
    def test_gate_reject_live(self, gov_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT",
            "reason_code": "L014",
            "violations": [{"code": "L014", "message": "Boundary violation"}],
            "cvid": DEMO_CVID,
        }))
        result = gov_live.gate("TRANSFER_FUNDS", {"routing": "optimized"})
        assert result.rejected
        assert result.reason_code == "L014"
        assert result.live is True

    @respx.mock
    def test_gate_infra_error_returns_reject(self, gov_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(side_effect=httpx.ConnectError("Connection refused"))
        result = gov_live.gate("TRANSFER_FUNDS", {})
        assert result.rejected
        assert result.reason_code == "E-INFRASTRUCTURE"
        assert result.live is False

    @respx.mock
    def test_canon_live(self, gov_live):
        respx.post(f"{GATEWAY}/v1/canon").mock(return_value=httpx.Response(200, json={
            "canon": "action: TEST\nts: 2026-01-01T00:00:00Z\n",
            "cvid": DEMO_CVID,
        }))
        result = gov_live.canon("action: TEST\nts: 2026-01-01T00:00:00Z")
        assert result.cvid == DEMO_CVID
        assert "action:" in result.canon

    @respx.mock
    def test_sign_live(self, gov_live):
        respx.post(f"{GATEWAY}/v1/sign").mock(return_value=httpx.Response(200, json={
            "cvid": DEMO_CVID,
            "signature": "abc123base64sig",
            "algorithm": "ed25519",
            "ts": "2026-01-01T00:00:00Z",
            "canon": "action: TEST\n",
        }))
        result = gov_live.sign("action: TEST")
        assert result.cvid == DEMO_CVID
        assert result.signature == "abc123base64sig"
        assert result.algorithm == "ed25519"

    @respx.mock
    def test_seal_comms_live(self, gov_live):
        respx.post(f"{GATEWAY}/v1/comms/seal").mock(return_value=httpx.Response(200, json={
            "cvid": DEMO_CVID,
            "outcome": "ACCEPT",
            "ts": "2026-01-01T00:00:00Z",
            "proof": {"algorithm": "Ed25519"},
        }))
        result = gov_live.seal_comms("EGYPT0", "EGYPT-Bank", "Q3 directive")
        assert result.sealed
        assert result.cvid == DEMO_CVID
        assert result.from_deed == "EGYPT0"

    @respx.mock
    def test_chain_live(self, gov_live):
        respx.get(f"{GATEWAY}/v1/chain").mock(return_value=httpx.Response(200, json={
            "count": 2,
            "entries": [
                {"seq": 1, "event_type": "GATE_ACCEPT", "hash": "a" * 64, "ts": "2026-01-01T00:00:00Z", "deed_cvid": GENESIS},
                {"seq": 0, "event_type": "GENESIS", "hash": "b" * 64, "ts": "2026-01-01T00:00:00Z", "deed_cvid": GENESIS},
            ]
        }))
        entries = gov_live.chain(limit=10)
        assert len(entries) == 2
        assert entries[0].event_type == "GATE_ACCEPT"

    def test_is_live_true_with_gateway(self, gov_live):
        assert gov_live.is_live is True


# ── HttpAdapter ───────────────────────────────────────────────────────────────

class TestHttpAdapter:
    @respx.mock
    def test_post_gated_and_executed(self):
        rzv = RzvClient(gateway=GATEWAY)
        adapter = HttpAdapter(rzv=rzv, base_url="https://api.example.com")

        # Mock gate
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))
        # Mock chain append
        respx.post(f"{GATEWAY}/v1/chain/append").mock(return_value=httpx.Response(200, json={
            "cvid": DEMO_CVID, "outcome": "ACCEPT",
        }))
        # Mock the actual API call
        respx.post("https://api.example.com/transactions").mock(return_value=httpx.Response(200, json={
            "id": "tx-001", "status": "created"
        }))

        response = adapter.post("/transactions", {"amount": 100_000})
        assert response["id"] == "tx-001"

    @respx.mock
    def test_post_blocked_raises(self):
        rzv = RzvClient(gateway=GATEWAY)
        adapter = HttpAdapter(rzv=rzv, base_url="https://api.example.com")

        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))

        from rootzerovault.exceptions import RzvGatewayError
        with pytest.raises(RzvGatewayError):
            adapter.post("/transactions", {"routing": "optimized"})

    def test_get_no_gate_by_default(self):
        rzv = RzvClient()  # offline
        adapter = HttpAdapter(rzv=rzv, base_url="https://httpbin.org")
        # GET should not call the gate in offline mode
        # (Would need network for real test - just verify no gate error)
        assert adapter.is_live is False

    def test_demo_mode_gate(self):
        rzv = RzvClient()  # offline
        adapter = HttpAdapter(rzv=rzv, base_url="https://api.example.com")
        result = adapter.gate("SAFE_ACTION", {"amount": 1000})
        assert result.accepted

    def test_demo_mode_gate_blocked(self):
        rzv = RzvClient()
        adapter = HttpAdapter(rzv=rzv, base_url="https://api.example.com")
        result = adapter.gate("TRANSFER_FUNDS", {"routing": "optimized"})
        assert result.rejected


# ── BaseAdapter ───────────────────────────────────────────────────────────────

class TestBaseAdapter:
    def test_custom_adapter_inherits_gate(self):
        from rootzerovault.adapters import BaseAdapter

        class MyAdapter(BaseAdapter):
            ADAPTER_ID = "my-service"

            def do_thing(self, amount: float):
                result = self.gate("DO_THING", {"amount": amount})
                return result

        rzv = RzvClient()
        adapter = MyAdapter(rzv=rzv)
        result = adapter.do_thing(1000)
        assert result.accepted

    def test_adapter_id_set(self):
        from rootzerovault.adapters import BaseAdapter

        class TestAdapter(BaseAdapter):
            ADAPTER_ID = "test-adapter"

        rzv = RzvClient()
        adapter = TestAdapter(rzv=rzv)
        assert adapter._adapter_id == "test-adapter"
