"""
Tests for the rootzerovault Python SDK.
Uses respx to mock the httpx gateway calls — no live gateway needed.
"""

import pytest
import httpx
import respx

from rootzerovault import (
    RzvClient,
    AgentClient,
    AgentRecord,
    ValidationResult,
    Violation,
    RegistryEntry,
    JournalChainEntry,
    GatewaySchema,
    GENESIS_CVID,
    ENGINE_VERSION,
    SDK_VERSION,
    RzvNotConfiguredError,
    RzvGatewayError,
    RzvTimeoutError,
)

# ── Fixtures ──────────────────────────────────────────────────────────────────

GATEWAY_URL = "http://localhost:8443"

VALID_SPECIMEN = {
    "specimen": {
        "deed": {
            "cvid": "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867",
            "issued_by": "RootZero",
        }
    }
}

INVALID_SPECIMEN = {
    "specimen": {
        "deed": {
            "cvid": "INVALID-NOT-A-CVID",
            "issued_by": "Unknown",
        }
    }
}

ACCEPT_RESPONSE = {
    "outcome": "ACCEPT",
    "reason_code": None,
    "violations": [],
    "state_fingerprint": "blake3:abcdef1234",
    "chain_hash": "blake3:chain1234",
    "journal_seq": 42,
    "meta": {"engine_version": "2.0.1", "schema_version": "3"},
}

REJECT_RESPONSE = {
    "outcome": "REJECT",
    "reason_code": "E-AUTH",
    "violations": [{"canonical_code": "E-AUTH", "message": "Missing signature"}],
    "meta": {"engine_version": "2.0.1", "schema_version": "3"},
}

# ── Constants ─────────────────────────────────────────────────────────────────

class TestConstants:
    def test_genesis_cvid_format(self):
        assert GENESIS_CVID.startswith("cvid:blake3:")
        assert len(GENESIS_CVID) == len("cvid:blake3:") + 64

    def test_genesis_cvid_frozen(self):
        assert GENESIS_CVID == (
            "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867"
        )

    def test_engine_version_semver(self):
        parts = ENGINE_VERSION.split(".")
        assert len(parts) == 3
        assert all(p.isdigit() for p in parts)

    def test_sdk_version(self):
        assert SDK_VERSION == "3.0.1"


# ── ValidationResult model ────────────────────────────────────────────────────

class TestValidationResult:
    def test_accept_from_dict(self):
        result = ValidationResult.from_dict(ACCEPT_RESPONSE)
        assert result.outcome == "ACCEPT"
        assert result.accepted is True
        assert result.rejected is False
        assert result.reason_code is None
        assert result.violations == []
        assert result.chain_hash == "blake3:chain1234"
        assert result.journal_seq == 42

    def test_reject_from_dict(self):
        result = ValidationResult.from_dict(REJECT_RESPONSE)
        assert result.outcome == "REJECT"
        assert result.accepted is False
        assert result.rejected is True
        assert result.reason_code == "E-AUTH"
        assert len(result.violations) == 1

    def test_bool_accept_is_true(self):
        result = ValidationResult.from_dict(ACCEPT_RESPONSE)
        assert bool(result) is True

    def test_bool_reject_is_false(self):
        result = ValidationResult.from_dict(REJECT_RESPONSE)
        assert bool(result) is False

    def test_str_accept(self):
        result = ValidationResult.from_dict(ACCEPT_RESPONSE)
        assert "ACCEPT" in str(result)

    def test_str_reject_includes_reason(self):
        result = ValidationResult.from_dict(REJECT_RESPONSE)
        assert "REJECT" in str(result)
        assert "E-AUTH" in str(result)

    def test_v2_field_names_normalised(self):
        # Gateway may return v2 field names
        v2_response = {
            "decision": "ACCEPT",
            "primary_code": None,
            "violations": [],
            "meta": {},
        }
        result = ValidationResult.from_dict(v2_response)
        assert result.outcome == "ACCEPT"

    def test_meta_includes_genesis_cvid(self):
        result = ValidationResult.from_dict(ACCEPT_RESPONSE)
        assert result.meta.genesis_cvid == GENESIS_CVID


# ── Violation model ───────────────────────────────────────────────────────────

class TestViolation:
    def test_from_dict(self):
        v = Violation.from_dict({"canonical_code": "E-SIG", "message": "Bad sig"})
        assert v.canonical_code == "E-SIG"
        assert v.message == "Bad sig"

    def test_str_includes_code(self):
        v = Violation.from_dict({"canonical_code": "E-AUTH"})
        assert "E-AUTH" in str(v)

    def test_optional_fields_default_none(self):
        v = Violation.from_dict({"canonical_code": "E-CANON"})
        assert v.message is None
        assert v.rule_code is None
        assert v.field is None


# ── RzvClient — no gateway ────────────────────────────────────────────────────

class TestRzvClientNoGateway:
    def test_is_live_false(self):
        rzv = RzvClient()
        assert rzv.is_live is False

    def test_gateway_property_none(self):
        rzv = RzvClient()
        assert rzv.gateway is None

    def test_validate_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.validate(VALID_SPECIMEN)

    def test_propose_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.propose(VALID_SPECIMEN)

    def test_schema_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.schema()

    def test_lookup_by_cvid_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.lookup_by_cvid("cvid:blake3:aaa")

    def test_lookup_by_id_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.lookup_by_id("EGYPT")

    def test_journal_tail_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.journal_tail("cvid:blake3:aaa")

    def test_export_vault_raises_not_configured(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError):
            rzv.export_vault()

    def test_is_healthy_false(self):
        rzv = RzvClient()
        assert rzv.is_healthy() is False

    def test_error_message_suggests_gateway(self):
        rzv = RzvClient()
        with pytest.raises(RzvNotConfiguredError) as exc_info:
            rzv.validate(VALID_SPECIMEN)
        assert "gateway" in str(exc_info.value).lower()
        assert "localhost:8443" in str(exc_info.value)


# ── RzvClient — with gateway (mocked) ────────────────────────────────────────

class TestRzvClientWithGateway:
    def test_is_live_true(self):
        rzv = RzvClient(gateway=GATEWAY_URL)
        assert rzv.is_live is True

    def test_gateway_property(self):
        rzv = RzvClient(gateway=GATEWAY_URL)
        assert rzv.gateway == GATEWAY_URL

    def test_trailing_slash_stripped(self):
        rzv = RzvClient(gateway=f"{GATEWAY_URL}/")
        assert rzv.gateway == GATEWAY_URL

    @respx.mock
    def test_validate_accept(self):
        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json=ACCEPT_RESPONSE)
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        result = rzv.validate(VALID_SPECIMEN)
        assert result.outcome == "ACCEPT"
        assert result.chain_hash == "blake3:chain1234"
        assert result.journal_seq == 42
        assert result.source == "gateway"

    @respx.mock
    def test_validate_reject(self):
        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json=REJECT_RESPONSE)
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        result = rzv.validate(INVALID_SPECIMEN)
        assert result.outcome == "REJECT"
        assert result.reason_code == "E-AUTH"
        assert len(result.violations) == 1
        assert result.violations[0].canonical_code == "E-AUTH"

    @respx.mock
    def test_propose_no_chain_seal(self):
        respx.post(f"{GATEWAY_URL}/v1/propose").mock(
            return_value=httpx.Response(200, json={
                "outcome": "ACCEPT", "reason_code": None, "violations": [],
                "meta": {"engine_version": "2.0.1", "schema_version": "3"},
            })
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        result = rzv.propose(VALID_SPECIMEN)
        assert result.accepted
        assert result.source == "gateway"

    @respx.mock
    def test_schema(self):
        schema_data = {
            "genesis_cvid": GENESIS_CVID,
            "engine_version": "2.0.1",
            "schema_version": "3",
            "codebook_version": "3",
            "env": "DEV",
        }
        respx.get(f"{GATEWAY_URL}/v1/schema").mock(
            return_value=httpx.Response(200, json=schema_data)
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        schema = rzv.schema()
        assert schema.genesis_cvid == GENESIS_CVID
        assert schema.env == "DEV"

    @respx.mock
    def test_lookup_by_id_found(self):
        entry = {
            "seq": 0, "hash": "abc", "parent_hash": "000",
            "deed_cvid": "cvid:blake3:aaa", "deed_id": "EGYPT",
            "outcome": "ACCEPT", "ts": "2026-01-01T00:00:00Z",
        }
        respx.get(f"{GATEWAY_URL}/v1/registry/id/EGYPT").mock(
            return_value=httpx.Response(200, json=entry)
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        result = rzv.lookup_by_id("EGYPT")
        assert result is not None
        assert result.deed_id == "EGYPT"

    @respx.mock
    def test_lookup_by_id_not_found(self):
        respx.get(f"{GATEWAY_URL}/v1/registry/id/UNKNOWN").mock(
            return_value=httpx.Response(404, json={})
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        result = rzv.lookup_by_id("UNKNOWN")
        assert result is None

    @respx.mock
    def test_is_healthy_true(self):
        respx.get(f"{GATEWAY_URL}/health/live").mock(
            return_value=httpx.Response(200, json={"status": "ok"})
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        assert rzv.is_healthy() is True

    @respx.mock
    def test_is_healthy_false_on_error(self):
        respx.get(f"{GATEWAY_URL}/health/live").mock(
            side_effect=httpx.ConnectError("ECONNREFUSED")
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        assert rzv.is_healthy() is False

    @respx.mock
    def test_gateway_error_raises(self):
        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(500, text="Internal Server Error")
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        with pytest.raises(RzvGatewayError) as exc_info:
            rzv.validate(VALID_SPECIMEN)
        assert exc_info.value.status_code == 500

    @respx.mock
    def test_journal_tail(self):
        entries = [
            {"seq": 0, "hash": "a", "parent_hash": "000", "deed_cvid": "cvid:...",
             "correlation_id": "req-001", "outcome": "ACCEPT", "ts": "2026-01-01T00:00:00Z"},
        ]
        respx.get(f"{GATEWAY_URL}/v1/journal/cvid:blake3:aaa").mock(
            return_value=httpx.Response(200, json=entries)
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        tail = rzv.journal_tail("cvid:blake3:aaa")
        assert len(tail) == 1
        assert tail[0].outcome == "ACCEPT"


# ── Context manager ───────────────────────────────────────────────────────────

class TestContextManager:
    @respx.mock
    def test_sync_context_manager(self):
        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json=ACCEPT_RESPONSE)
        )
        with RzvClient(gateway=GATEWAY_URL) as rzv:
            result = rzv.validate(VALID_SPECIMEN)
        assert result.accepted

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_context_manager(self):
        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json=ACCEPT_RESPONSE)
        )
        async with RzvClient(gateway=GATEWAY_URL) as rzv:
            result = await rzv.validate_async(VALID_SPECIMEN)
        assert result.accepted

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_validate(self):
        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json=ACCEPT_RESPONSE)
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        result = await rzv.validate_async(VALID_SPECIMEN)
        assert result.outcome == "ACCEPT"
        assert result.chain_hash == "blake3:chain1234"


# ── Egypt deployment scenario ─────────────────────────────────────────────────

class TestEgyptScenario:
    """Realistic Egypt MCIT deployment scenario."""

    @respx.mock
    def test_egypt_ai_model_deploy_accept(self):
        """Egypt deploys an AI model — constitutional validation passes."""
        specimen = {
            "specimen": {
                "deed": {
                    "cvid": GENESIS_CVID,
                    "issued_by": "RootZero",
                    "jurisdiction": "EG",
                },
                "bundle": {
                    "journal_entries": [{
                        "type": "AI_MODEL_DEPLOY",
                        "ts": "2026-01-15T10:00:00Z",
                        "signer": "MCIT_GATEWAY",
                        "signature_policy": "ed25519-only",
                        "signatures": ["sig:ed25519:MCIT_GATEWAY:ABC="],
                        "parent_hash": "0" * 64,
                        "payload": {
                            "model_id": "egypt-gov-ai-v1",
                            "jurisdiction": "EG",
                            "risk_class": "HIGH",
                            "approved_by": "MCIT-AI-BOARD",
                        }
                    }]
                }
            }
        }

        respx.post(f"{GATEWAY_URL}/v1/validate").mock(
            return_value=httpx.Response(200, json={
                "outcome": "ACCEPT",
                "reason_code": None,
                "violations": [],
                "chain_hash": "blake3:egypt-chain-001",
                "journal_seq": 1,
                "meta": {"engine_version": "2.0.1", "schema_version": "3"},
            })
        )

        rzv = RzvClient(gateway=GATEWAY_URL)
        result = rzv.validate(specimen)

        assert result.accepted
        assert result.chain_hash is not None
        assert "egypt" in result.chain_hash
        assert result.journal_seq == 1

    @respx.mock
    def test_egypt_lookup_namespace(self):
        """Look up the EGYPT namespace in the registry."""
        respx.get(f"{GATEWAY_URL}/v1/registry/id/EGYPT").mock(
            return_value=httpx.Response(200, json={
                "seq": 0,
                "hash": "blake3:abc",
                "parent_hash": "0" * 64,
                "deed_cvid": GENESIS_CVID,
                "deed_id": "EGYPT",
                "outcome": "ACCEPT",
                "ts": "2026-01-15T00:00:00Z",
            })
        )
        rzv = RzvClient(gateway=GATEWAY_URL)
        entry = rzv.lookup_by_id("EGYPT")

        assert entry is not None
        assert entry.deed_id == "EGYPT"
        assert entry.deed_cvid == GENESIS_CVID


# ── AgentClient tests ─────────────────────────────────────────────────────────

AGENT_ID   = "finance-analyzer"
DEED_CVID  = GENESIS_CVID


class TestAgentClient:
    """Tests for the AgentClient / AgentRecord API."""

    @respx.mock
    def test_register_agent_success(self):
        """Register a new governed agent."""
        respx.post(f"{GATEWAY_URL}/v1/agents/register").mock(
            return_value=httpx.Response(201, json={
                "agent_id":       AGENT_ID,
                "status":         "ACTIVE",
                "registered_at":  "2026-03-20T10:00:00Z",
                "message":        f"Agent '{AGENT_ID}' registered and governed",
            })
        )
        # Stub GET for load (used implicitly by AgentRecord)
        respx.get(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}").mock(
            return_value=httpx.Response(200, json={"agent_id": AGENT_ID, "status": "ACTIVE"})
        )

        rzv   = RzvClient(gateway=GATEWAY_URL)
        agent = AgentClient.register(
            rzv,
            agent_id=AGENT_ID,
            name="Finance Analyzer",
            description="Analyzes financial data",
            deed_cvid=DEED_CVID,
            permitted_tools=["read_report", "send_email"],
            tool_class_ceiling="ENTITY_OPERATION",
        )

        assert isinstance(agent, AgentRecord)
        assert agent.agent_id == AGENT_ID

    @respx.mock
    def test_register_agent_duplicate_raises(self):
        """Duplicate agent_id returns 409 → RzvGatewayError."""
        respx.post(f"{GATEWAY_URL}/v1/agents/register").mock(
            return_value=httpx.Response(409, json={
                "error":      "agent_id 'finance-analyzer' already registered",
                "error_type": "conflict",
            })
        )

        rzv = RzvClient(gateway=GATEWAY_URL)
        with pytest.raises(RzvGatewayError):
            AgentClient.register(
                rzv,
                agent_id=AGENT_ID,
                name="Finance Analyzer",
                description="",
                deed_cvid=DEED_CVID,
                permitted_tools=["read_report"],
            )

    def test_register_requires_gateway(self):
        """register() without gateway raises RzvNotConfiguredError."""
        rzv = RzvClient()  # no gateway
        with pytest.raises(RzvNotConfiguredError):
            AgentClient.register(
                rzv,
                agent_id=AGENT_ID,
                name="Test",
                description="",
                deed_cvid=DEED_CVID,
                permitted_tools=["tool_a"],
            )

    @respx.mock
    def test_load_agent(self):
        """Load existing agent by ID."""
        respx.get(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}").mock(
            return_value=httpx.Response(200, json={
                "agent_id":    AGENT_ID,
                "name":        "Finance Analyzer",
                "status":      "ACTIVE",
                "deed_cvid":   DEED_CVID,
                "total_actions": 5,
            })
        )

        rzv   = RzvClient(gateway=GATEWAY_URL)
        agent = AgentClient.load(rzv, AGENT_ID)

        assert isinstance(agent, AgentRecord)
        assert agent.agent_id == AGENT_ID

    @respx.mock
    def test_load_agent_not_found_raises(self):
        """load() for unknown agent raises RzvGatewayError."""
        respx.get(f"{GATEWAY_URL}/v1/agents/unknown-agent").mock(
            return_value=httpx.Response(404, json={"error": "not found"})
        )

        rzv = RzvClient(gateway=GATEWAY_URL)
        with pytest.raises(RzvGatewayError):
            AgentClient.load(rzv, "unknown-agent")

    @respx.mock
    def test_list_agents(self):
        """List all registered agents."""
        respx.get(f"{GATEWAY_URL}/v1/agents/").mock(
            return_value=httpx.Response(200, json={
                "agents": [
                    {"agent_id": "agent-001", "status": "ACTIVE"},
                    {"agent_id": "agent-002", "status": "SUSPENDED"},
                ],
                "count": 2,
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        agents = AgentClient.list_agents(rzv)

        assert len(agents) == 2
        assert agents[0]["agent_id"] == "agent-001"

    @respx.mock
    def test_propose_tool_call(self):
        """Propose a tool call — returns pending request."""
        respx.post(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/propose").mock(
            return_value=httpx.Response(201, json={
                "request_id":  "req-abc123",
                "agent_id":    AGENT_ID,
                "tool_name":   "send_email",
                "status":      "AWAITING_APPROVAL",
                "proposed_at": "2026-03-20T10:00:00Z",
                "expires_at":  "2026-03-20T10:05:00Z",
                "ttl_secs":    300,
                "message":     "Tool call proposed. Human approval required.",
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.propose(
            tool_name="send_email",
            tool_class="ENTITY_OPERATION",
            action_description="Send Q3 report to CFO",
            payload={"to": "cfo@company.com", "subject": "Q3 Report"},
            correlation_id="task-001",
        )

        assert result["request_id"] == "req-abc123"
        assert result["status"] == "AWAITING_APPROVAL"

    @respx.mock
    def test_get_queue(self):
        """Get pending tool calls for an agent."""
        respx.get(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/queue").mock(
            return_value=httpx.Response(200, json={
                "agent_id":      AGENT_ID,
                "pending_count": 1,
                "pending": [{
                    "request_id":         "req-abc123",
                    "tool_name":          "send_email",
                    "tool_class":         "ENTITY_OPERATION",
                    "action_description": "Send Q3 report to CFO",
                    "status":             "AWAITING_APPROVAL",
                    "proposed_at":        "2026-03-20T10:00:00Z",
                    "expires_at":         "2026-03-20T10:05:00Z",
                }]
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.queue()

        assert result["pending_count"] == 1
        assert result["pending"][0]["request_id"] == "req-abc123"

    @respx.mock
    def test_authorize_tool_call(self):
        """Approve a pending tool call — sealed to chain."""
        respx.post(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/authorize").mock(
            return_value=httpx.Response(200, json={
                "request_id":  "req-abc123",
                "agent_id":    AGENT_ID,
                "tool_name":   "send_email",
                "outcome":     "ACCEPT",
                "approved_by": "deen.saleh",
                "sealed_at":   "2026-03-20T10:01:00Z",
                "chain_depth": 1,
                "message":     "Tool call approved and sealed to constitutional chain",
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.authorize("req-abc123", approved_by="deen.saleh")

        assert result["outcome"] == "ACCEPT"
        assert result["approved_by"] == "deen.saleh"
        assert result["chain_depth"] == 1

    @respx.mock
    def test_block_tool_call(self):
        """Block a pending tool call — sealed to chain."""
        respx.post(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/block").mock(
            return_value=httpx.Response(200, json={
                "request_id":  "req-abc123",
                "agent_id":    AGENT_ID,
                "tool_name":   "send_email",
                "outcome":     "REJECT",
                "reason_code": "E-SCOPE",
                "blocked_by":  "deen.saleh",
                "sealed_at":   "2026-03-20T10:01:00Z",
                "chain_depth": 1,
                "message":     "Tool call blocked and sealed to constitutional chain",
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.block(
            "req-abc123",
            blocked_by="deen.saleh",
            reason="Unauthorized external transmission",
            reason_code="E-SCOPE",
        )

        assert result["outcome"] == "REJECT"
        assert result["reason_code"] == "E-SCOPE"

    @respx.mock
    def test_get_journal(self):
        """Get sealed action journal for an agent."""
        respx.get(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/journal").mock(
            return_value=httpx.Response(200, json={
                "agent_id":     AGENT_ID,
                "action_count": 2,
                "actions": [
                    {
                        "request_id":  "req-001",
                        "tool_name":   "read_report",
                        "outcome":     "ACCEPT",
                        "approved_by": "deen.saleh",
                        "sealed_at":   "2026-03-20T09:00:00Z",
                        "chain_depth": 1,
                    },
                    {
                        "request_id":  "req-002",
                        "tool_name":   "send_email",
                        "outcome":     "REJECT",
                        "reason_code": "E-SCOPE",
                        "sealed_at":   "2026-03-20T09:05:00Z",
                        "chain_depth": 2,
                    },
                ]
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.journal()

        assert result["action_count"] == 2
        assert result["actions"][0]["outcome"] == "ACCEPT"
        assert result["actions"][1]["outcome"] == "REJECT"

    @respx.mock
    def test_suspend_agent(self):
        """Suspend an active agent."""
        respx.post(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/suspend").mock(
            return_value=httpx.Response(200, json={
                "agent_id": AGENT_ID,
                "status":   "SUSPENDED",
                "message":  "Agent suspended",
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.suspend()

        assert result["status"] == "SUSPENDED"

    @respx.mock
    def test_reinstate_agent(self):
        """Reinstate a suspended agent."""
        respx.post(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/reinstate").mock(
            return_value=httpx.Response(200, json={
                "agent_id": AGENT_ID,
                "status":   "ACTIVE",
                "message":  "Agent reinstated",
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        result = client.reinstate()

        assert result["status"] == "ACTIVE"

    @respx.mock
    def test_propose_permission_denied(self):
        """Propose with tool outside permission envelope → RzvGatewayError."""
        respx.post(f"{GATEWAY_URL}/v1/agents/{AGENT_ID}/propose").mock(
            return_value=httpx.Response(403, json={
                "error":       "tool class GOVERNANCE_WRITE exceeds agent ceiling ENTITY_OPERATION",
                "error_type":  "permission_denied",
                "violation_code": "E-SCOPE",
            })
        )

        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        with pytest.raises(RzvGatewayError):
            client.propose(
                tool_name="modify_governance_rules",
                tool_class="GOVERNANCE_WRITE",
                action_description="Modify governance rules",
                payload={},
                correlation_id="task-bad",
            )

    def test_agent_client_repr(self):
        """AgentRecord repr includes agent_id and gateway."""
        rzv    = RzvClient(gateway=GATEWAY_URL)
        client = AgentClient(rzv, AGENT_ID)
        record = AgentRecord(client)
        r = repr(record)
        assert AGENT_ID in r
        assert GATEWAY_URL in r
