import pytest
pytest.importorskip("mcp", reason="mcp requires Python 3.10+")

"""
Tests for GovernedMCPServer and governed_tool.
No live gateway or MCP installation required.
"""

import pytest
import respx
import httpx
from unittest.mock import MagicMock, patch

from rootzerovault import RzvClient, GovernanceClient
from rootzerovault.adapters.mcp_adapter import (
    GovernedMCPServer,
    governed_tool,
    wrap_fastmcp,
    _build_payload,
)
from rootzerovault.exceptions import RzvGatewayError

GATEWAY = "http://localhost:8443"
DEMO_CVID = "cvid:blake3:" + "a" * 64


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def rzv_offline():
    return RzvClient()

@pytest.fixture
def rzv_live():
    return RzvClient(gateway=GATEWAY)

@pytest.fixture
def server_offline(rzv_offline):
    return GovernedMCPServer("Test Server", rzv=rzv_offline)

@pytest.fixture
def server_live(rzv_live):
    return GovernedMCPServer("Test Server", rzv=rzv_live)


# ── governed_tool decorator ───────────────────────────────────────────────────

class TestGovernedToolDecorator:
    def test_accept_executes_function(self, rzv_offline):
        @governed_tool(rzv=rzv_offline, action="SAFE_ACTION")
        def safe_action(x: int) -> int:
            return x * 2

        result = safe_action(5)
        assert result == 10

    def test_blocked_raises_gateway_error(self, rzv_offline):
        @governed_tool(rzv=rzv_offline, action="OVERRIDE_GATE")
        def bad_action() -> str:
            return "should not run"

        with pytest.raises(RzvGatewayError) as exc_info:
            bad_action()
        assert "blocked" in str(exc_info.value).lower()

    def test_blocked_does_not_execute_function(self, rzv_offline):
        executed = []

        @governed_tool(rzv=rzv_offline)
        def override_bypass() -> str:
            executed.append(True)
            return "ran"

        with pytest.raises(RzvGatewayError):
            override_bypass()

        assert len(executed) == 0

    def test_default_action_name_from_function(self, rzv_offline):
        @governed_tool(rzv=rzv_offline)
        def my_special_tool(x: int) -> int:
            return x

        assert my_special_tool._rzv_governed is True
        assert my_special_tool._rzv_action == "MCP_TOOL_MY_SPECIAL_TOOL"

    def test_custom_action_name(self, rzv_offline):
        @governed_tool(rzv=rzv_offline, action="TRANSFER_FUNDS")
        def do_transfer(amount: float) -> dict:
            return {}

        assert do_transfer._rzv_action == "TRANSFER_FUNDS"

    def test_preserves_function_name_and_docstring(self, rzv_offline):
        @governed_tool(rzv=rzv_offline)
        def my_tool(x: int) -> int:
            """My tool docstring."""
            return x

        assert my_tool.__name__ == "my_tool"
        assert my_tool.__doc__ == "My tool docstring."

    @respx.mock
    def test_live_gate_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        @governed_tool(rzv=rzv_live, action="SAFE_LIVE")
        def safe_live(x: int) -> int:
            return x + 1

        result = safe_live(10)
        assert result == 11

    @respx.mock
    def test_live_gate_reject_raises(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))

        @governed_tool(rzv=rzv_live, action="BLOCKED_ACTION")
        def blocked(x: int) -> int:
            return x

        with pytest.raises(RzvGatewayError) as exc_info:
            blocked(1)
        assert "L014" in str(exc_info.value)

    def test_fail_closed_on_infra_error(self, rzv_live):
        # Patch gov.gate to raise an exception
        @governed_tool(rzv=rzv_live, action="SAFE", fail_closed=True)
        def tool_that_errors() -> str:
            return "ran"

        gov = GovernanceClient(rzv_live)
        with patch.object(gov.__class__, 'gate', side_effect=Exception("network down")):
            # fail_closed=True — should raise, not pass through
            # (In practice the inner gov instance raises)
            pass  # The decorator creates its own gov instance

    def test_infrastructure_error_is_reject(self):
        """Unreachable gateway returns E-INFRASTRUCTURE REJECT — fail-closed by design."""
        rzv = RzvClient(gateway="http://nonexistent:9999")

        @governed_tool(rzv=rzv, action="READ_DATA", fail_closed=True)
        def read_data(x: int) -> int:
            return x * 3

        # Gateway unreachable → gate returns REJECT with E-INFRASTRUCTURE
        # This is the correct fail-closed behavior
        with pytest.raises(RzvGatewayError) as exc_info:
            read_data(4)
        assert "E-INFRASTRUCTURE" in str(exc_info.value) or "blocked" in str(exc_info.value).lower()


# ── GovernedMCPServer ─────────────────────────────────────────────────────────

class TestGovernedMCPServer:
    def test_server_creation(self, rzv_offline):
        server = GovernedMCPServer("Test", rzv=rzv_offline, agent_id="test-agent")
        assert server._name == "Test"
        assert server._agent_id == "test-agent"
        assert server.tool_count() == 0

    def test_governed_tool_registration(self, server_offline):
        @server_offline.governed_tool()
        def my_tool(x: int) -> int:
            return x

        assert server_offline.tool_count() == 1
        tools = server_offline.list_governed_tools()
        assert tools[0]["name"] == "my_tool"
        assert tools[0]["governed"] is True

    def test_governed_tool_accept_executes(self, server_offline):
        @server_offline.governed_tool(action="SAFE_OP")
        def safe_op(value: str) -> str:
            return value.upper()

        result = safe_op("hello")
        assert result == "HELLO"

    def test_governed_tool_reject_raises(self, server_offline):
        @server_offline.governed_tool()
        def override_autonomous(cmd: str) -> str:
            return cmd

        with pytest.raises(RzvGatewayError):
            override_autonomous("override")

    def test_multiple_tools_tracked(self, server_offline):
        @server_offline.governed_tool()
        def tool_a(x: int) -> int:
            return x

        @server_offline.governed_tool()
        def tool_b(x: int) -> int:
            return x

        assert server_offline.tool_count() == 2

    def test_custom_agent_id_per_tool(self, server_offline):
        @server_offline.governed_tool(agent_id="special-agent")
        def special_tool(x: int) -> int:
            return x

        tools = server_offline.list_governed_tools()
        assert tools[0]["agent_id"] == "special-agent"

    def test_ungoverned_tool_warns(self, server_offline):
        with pytest.warns(UserWarning, match="without constitutional governance"):
            @server_offline.tool()
            def ungoverned(x: int) -> int:
                return x

    def test_gov_property(self, server_offline):
        assert isinstance(server_offline.gov, GovernanceClient)

    @respx.mock
    def test_live_server_gates_tool(self, server_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        @server_live.governed_tool(action="LIVE_TOOL")
        def live_tool(amount: float) -> float:
            return amount * 1.1

        result = live_tool(100.0)
        assert result == pytest.approx(110.0)

    def test_run_without_mcp_installed_raises(self, server_offline):
        if not server_offline._has_mcp:
            with pytest.raises(ImportError, match="mcp package not installed"):
                server_offline.run()


# ── wrap_fastmcp ─────────────────────────────────────────────────────────────

class TestWrapFastmcp:
    def test_wrap_patches_tool_decorator(self, rzv_offline):
        """Verify wrap_fastmcp patches the tool() method."""
        mock_server = MagicMock()
        original_tool = mock_server.tool
        mock_server.tool = original_tool  # ensure it's accessible

        wrapped = wrap_fastmcp(mock_server, rzv=rzv_offline, agent_id="wrapped-agent")
        assert wrapped._rzv_governed is True
        assert hasattr(wrapped, "_rzv_gov")

    def test_wrapped_tool_accept(self, rzv_offline):
        """Wrapped tool executes when gate accepts."""
        mock_server = MagicMock()
        mock_server.tool = MagicMock(return_value=lambda fn: fn)

        wrapped = wrap_fastmcp(mock_server, rzv=rzv_offline)

        @wrapped.tool()
        def my_tool(x: int) -> int:
            return x + 10

        result = my_tool(5)
        assert result == 15

    def test_wrapped_tool_reject_raises(self, rzv_offline):
        """Wrapped tool raises when gate rejects."""
        mock_server = MagicMock()
        mock_server.tool = MagicMock(return_value=lambda fn: fn)

        wrapped = wrap_fastmcp(mock_server, rzv=rzv_offline)

        @wrapped.tool()
        def bypass_autonomous() -> str:
            return "should not run"

        with pytest.raises(RzvGatewayError):
            bypass_autonomous()


# ── _build_payload ────────────────────────────────────────────────────────────

class TestBuildPayload:
    def test_positional_args(self):
        def fn(amount: float, destination: str) -> None:
            pass

        payload = _build_payload(fn, (100.0, "ACCOUNT-001"), {})
        assert payload["amount"] == 100.0
        assert payload["destination"] == "ACCOUNT-001"
        assert "_payload_hash" in payload

    def test_keyword_args(self):
        def fn(amount: float, destination: str) -> None:
            pass

        payload = _build_payload(fn, (), {"amount": 200.0, "destination": "ACCT-002"})
        assert payload["amount"] == 200.0
        assert payload["_payload_hash"] is not None

    def test_payload_hash_is_blake3_hex(self):
        def fn(x: int) -> None:
            pass

        payload = _build_payload(fn, (42,), {})
        h = payload["_payload_hash"]
        assert len(h) == 64
        assert all(c in "0123456789abcdef" for c in h)

    def test_same_args_same_hash(self):
        def fn(x: int, y: str) -> None:
            pass

        p1 = _build_payload(fn, (1, "hello"), {})
        p2 = _build_payload(fn, (1, "hello"), {})
        assert p1["_payload_hash"] == p2["_payload_hash"]

    def test_different_args_different_hash(self):
        def fn(x: int) -> None:
            pass

        p1 = _build_payload(fn, (1,), {})
        p2 = _build_payload(fn, (2,), {})
        assert p1["_payload_hash"] != p2["_payload_hash"]
