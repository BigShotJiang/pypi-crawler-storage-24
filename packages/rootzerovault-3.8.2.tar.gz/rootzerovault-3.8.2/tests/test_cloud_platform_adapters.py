"""
Tests for cloud platform adapters — Bedrock, Vertex, Azure OpenAI, Anthropic, Cohere.

All tests run without live cloud credentials — adapters are tested
in offline/demo mode using the RzvClient mock pattern.
"""

import pytest
from unittest.mock import MagicMock, patch, AsyncMock

from rootzerovault import RzvClient
from rootzerovault.adapters.bedrock_adapter import (
    GovernedBedrockClient, governed_bedrock_tool, _bedrock_action,
)
from rootzerovault.adapters.vertex_adapter import (
    GovernedVertexModel, governed_vertex_tool,
)
from rootzerovault.adapters.azure_openai_adapter import (
    GovernedAzureOpenAI, governed_azure_tool,
)
from rootzerovault.adapters.anthropic_adapter import (
    GovernedAnthropic, GovernedAsyncAnthropic, governed_claude_tool,
)
from rootzerovault.adapters.cohere_adapter import (
    GovernedCohereClient, GovernedCohereRAG, governed_cohere_tool,
)
from rootzerovault.exceptions import RzvGatewayError

# Cloud platform adapters require Python 3.10+ dependencies.
# On Python 3.9 CI runners these packages are not installed — skip gracefully.
pytest.importorskip("anthropic", reason="anthropic requires Python 3.10+")


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def rzv():
    """Offline RzvClient — no gateway required."""
    return RzvClient()  # offline/demo mode — no gateway required


@pytest.fixture
def mock_gate_accept(rzv):
    """Patch GovernanceClient.gate to always return ACCEPT."""
    mock_result = MagicMock()
    mock_result.accepted = True
    mock_result.rejected = False
    mock_result.reason_code = None
    with patch(
        "rootzerovault.governance.GovernanceClient.gate",
        return_value=mock_result,
    ) as mock:
        yield mock


@pytest.fixture
def mock_gate_block(rzv):
    """Patch GovernanceClient.gate to always return BLOCK."""
    mock_result = MagicMock()
    mock_result.accepted = False
    mock_result.rejected = True
    mock_result.reason_code = "E-PERMISSION-DENIED"
    with patch(
        "rootzerovault.governance.GovernanceClient.gate",
        return_value=mock_result,
    ) as mock:
        yield mock


# ── Bedrock tests ─────────────────────────────────────────────────────────────

class TestBedrockAdapter:

    def test_action_derivation(self):
        assert _bedrock_action("anthropic.claude-3-5-sonnet-20241022-v2:0", None) == \
               "BEDROCK_ANTHROPIC_CLAUDE_INVOKE"
        assert _bedrock_action("amazon.titan-text-v1", None) == \
               "BEDROCK_AMAZON_TITAN_INVOKE"
        assert _bedrock_action("my-model", "CUSTOM_ACTION") == "CUSTOM_ACTION"

    def test_governed_client_init(self, rzv):
        client = GovernedBedrockClient(rzv=rzv, region_name="us-east-1", agent_id="test-agent")
        assert client._region == "us-east-1"
        assert client._agent_id == "test-agent"

    def test_invoke_model_blocked(self, rzv, mock_gate_block):
        client = GovernedBedrockClient(rzv=rzv)
        with pytest.raises(RzvGatewayError, match="Bedrock invoke blocked"):
            client.invoke_model(
                modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
                body='{"messages": [{"role": "user", "content": "test"}], "max_tokens": 100}',
            )
        mock_gate_block.assert_called_once()

    def test_invoke_model_accepted(self, rzv, mock_gate_accept):
        client = GovernedBedrockClient(rzv=rzv)
        mock_boto = MagicMock()
        mock_boto.invoke_model.return_value = {"body": MagicMock()}
        client._GovernedBedrockClient__client = mock_boto
        result = client.invoke_model(
            modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
            body='{"messages": [], "max_tokens": 100}',
        )
        mock_gate_accept.assert_called_once()
        mock_boto.invoke_model.assert_called_once()

    def test_governed_bedrock_tool_decorator(self, rzv, mock_gate_accept):
        @governed_bedrock_tool(rzv=rzv, action="CLINICAL_INFERENCE")
        def run_clinical(patient_ref: str) -> str:
            return f"analysis for {patient_ref}"

        result = run_clinical("CUH-8847")
        assert result == "analysis for CUH-8847"
        mock_gate_accept.assert_called_once()

    def test_governed_bedrock_tool_blocked(self, rzv, mock_gate_block):
        @governed_bedrock_tool(rzv=rzv, action="FINANCIAL_TRANSFER", fail_closed=True)
        def transfer(amount: float) -> str:
            return "transferred"

        with pytest.raises(RzvGatewayError):
            transfer(1_000_000.0)


# ── Vertex AI tests ───────────────────────────────────────────────────────────

class TestVertexAdapter:

    def test_governed_model_init(self, rzv):
        model = GovernedVertexModel(
            model_name="gemini-2.0-flash-001",
            rzv=rzv,
            project="my-project",
            location="us-central1",
        )
        assert model._model_name == "gemini-2.0-flash-001"
        assert model._location == "us-central1"

    def test_generate_content_blocked(self, rzv, mock_gate_block):
        model = GovernedVertexModel(model_name="gemini-2.0-flash-001", rzv=rzv)
        with pytest.raises(RzvGatewayError, match="Vertex AI generate blocked"):
            model.generate_content("Analyze this patient record")
        mock_gate_block.assert_called_once()

    def test_generate_content_accepted(self, rzv, mock_gate_accept):
        model = GovernedVertexModel(model_name="gemini-2.0-flash-001", rzv=rzv)
        mock_vertex_model = MagicMock()
        mock_vertex_model.generate_content.return_value = MagicMock(text="Analysis complete")
        model._GovernedVertexModel__model = mock_vertex_model
        result = model.generate_content("Analyze this patient record")
        mock_gate_accept.assert_called_once()
        mock_vertex_model.generate_content.assert_called_once()

    def test_vertex_tool_decorator(self, rzv, mock_gate_accept):
        @governed_vertex_tool(rzv=rzv, action="REGULATORY_ANALYSIS")
        def analyze(text: str) -> str:
            return f"analyzed: {text}"

        result = analyze("contract text")
        assert "analyzed" in result
        mock_gate_accept.assert_called_once()


# ── Azure OpenAI tests ────────────────────────────────────────────────────────

class TestAzureOpenAIAdapter:

    def test_governed_client_init(self, rzv):
        client = GovernedAzureOpenAI(
            rzv=rzv,
            azure_endpoint="https://my-resource.openai.azure.com",
            api_version="2024-10-21",
            agent_id="azure-test",
        )
        assert client._azure_endpoint == "https://my-resource.openai.azure.com"
        assert client._agent_id == "azure-test"

    def test_chat_completions_blocked(self, rzv, mock_gate_block):
        client = GovernedAzureOpenAI(rzv=rzv)
        # Inject a mock client so no credential check happens before the gate fires
        mock_openai = MagicMock()
        client._GovernedAzureOpenAI__client = mock_openai
        with pytest.raises(RzvGatewayError, match="Azure OpenAI chat blocked"):
            client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Transfer $1M"}],
            )

    def test_chat_completions_accepted(self, rzv, mock_gate_accept):
        client = GovernedAzureOpenAI(rzv=rzv)
        mock_openai = MagicMock()
        mock_openai.chat.completions.create.return_value = MagicMock()
        client._GovernedAzureOpenAI__client = mock_openai
        client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Summarize this contract"}],
        )
        mock_gate_accept.assert_called_once()

    def test_azure_tool_decorator(self, rzv, mock_gate_accept):
        @governed_azure_tool(rzv=rzv, action="FINANCIAL_SUMMARY")
        def summarize(text: str) -> str:
            return f"summary: {text[:50]}"

        result = summarize("annual report text")
        assert "summary" in result
        mock_gate_accept.assert_called_once()


# ── Anthropic direct tests ────────────────────────────────────────────────────

class TestAnthropicAdapter:

    def test_governed_client_init(self, rzv):
        client = GovernedAnthropic(rzv=rzv, agent_id="claude-test")
        assert client._agent_id == "claude-test"

    def test_messages_create_blocked(self, rzv, mock_gate_block):
        client = GovernedAnthropic(rzv=rzv)
        with pytest.raises(RzvGatewayError, match="Anthropic messages.create blocked"):
            client.messages.create(
                model="claude-opus-4-5",
                max_tokens=1024,
                messages=[{"role": "user", "content": "Unauthorized action"}],
            )

    def test_messages_create_accepted(self, rzv, mock_gate_accept):
        client = GovernedAnthropic(rzv=rzv)
        mock_anthropic = MagicMock()
        mock_anthropic.messages.create.return_value = MagicMock(content="response")
        client._GovernedAnthropic__client = mock_anthropic
        client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Analyze contract"}],
        )
        mock_gate_accept.assert_called_once()
        mock_anthropic.messages.create.assert_called_once()

    def test_claude_tool_decorator(self, rzv, mock_gate_accept):
        @governed_claude_tool(rzv=rzv, action="CONTRACT_REVIEW")
        def review(text: str) -> str:
            return f"reviewed: {text}"

        result = review("contract text")
        assert "reviewed" in result
        mock_gate_accept.assert_called_once()

    def test_async_client_init(self, rzv):
        client = GovernedAsyncAnthropic(rzv=rzv, agent_id="async-claude")
        assert client._agent_id == "async-claude"


# ── Cohere tests ──────────────────────────────────────────────────────────────

class TestCohereAdapter:

    def test_governed_client_init(self, rzv):
        co = GovernedCohereClient(rzv=rzv, agent_id="cohere-test")
        assert co._agent_id == "cohere-test"

    def test_chat_blocked(self, rzv, mock_gate_block):
        co = GovernedCohereClient(rzv=rzv)
        with pytest.raises(RzvGatewayError, match="Cohere call blocked"):
            co.chat(
                model="command-r-plus-08-2024",
                messages=[{"role": "user", "content": "Unauthorized query"}],
            )

    def test_chat_accepted(self, rzv, mock_gate_accept):
        co = GovernedCohereClient(rzv=rzv)
        mock_cohere = MagicMock()
        mock_cohere.chat.return_value = MagicMock()
        co._GovernedCohereClient__client = mock_cohere
        co.chat(
            model="command-r-plus-08-2024",
            messages=[{"role": "user", "content": "Summarize this"}],
        )
        mock_gate_accept.assert_called_once()

    def test_embed_accepted(self, rzv, mock_gate_accept):
        co = GovernedCohereClient(rzv=rzv)
        mock_cohere = MagicMock()
        mock_cohere.embed.return_value = MagicMock()
        co._GovernedCohereClient__client = mock_cohere
        co.embed(
            texts=["document 1", "document 2"],
            model="embed-v4.0",
            input_type="search_document",
        )
        mock_gate_accept.assert_called_once()

    def test_rerank_blocked(self, rzv, mock_gate_block):
        co = GovernedCohereClient(rzv=rzv)
        with pytest.raises(RzvGatewayError):
            co.rerank(
                query="force majeure clause",
                documents=["doc1", "doc2"],
                model="rerank-v3.5",
            )

    def test_rag_chat_with_docs_blocked(self, rzv, mock_gate_block):
        co = GovernedCohereClient(rzv=rzv)
        rag = GovernedCohereRAG(rzv=rzv, co=co)
        with pytest.raises(RzvGatewayError, match="Cohere RAG blocked"):
            rag.chat_with_docs(
                query="What are the penalties?",
                documents=[{"text": "Contract clause..."}],
            )

    def test_cohere_tool_decorator(self, rzv, mock_gate_accept):
        @governed_cohere_tool(rzv=rzv, action="DOCUMENT_RERANK")
        def rerank_docs(query: str, docs: list) -> list:
            return docs

        result = rerank_docs("query", ["doc1", "doc2"])
        assert result == ["doc1", "doc2"]
        mock_gate_accept.assert_called_once()
