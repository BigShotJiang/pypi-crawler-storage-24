"""
Tests for ACP, PydanticAI, smolagents, and Semantic Kernel adapters.
"""
import pytest
import respx
import httpx
from unittest.mock import MagicMock, AsyncMock, patch
from typing import AsyncIterator

from rootzerovault import RzvClient
from rootzerovault.adapters.acp_adapter import (
    governed_acp_agent, GovernedACPServer, governed_acp_run,
    _acp_input_to_payload,
)
from rootzerovault.adapters.pydantic_ai_adapter import (
    governed_pydantic_tool, GovernedPydanticAgent,
)
from rootzerovault.adapters.smolagents_adapter import (
    GovernedSmolTool, governed_smol_tool,
)
from rootzerovault.adapters.semantic_kernel_adapter import (
    governed_kernel_function, GovernedKernelPlugin,
)
from rootzerovault.exceptions import RzvGatewayError

GATEWAY = "http://localhost:8443"
DEMO_CVID = "cvid:blake3:" + "a" * 64


@pytest.fixture
def rzv():
    return RzvClient()

@pytest.fixture
def rzv_live():
    return RzvClient(gateway=GATEWAY)


# ══════════════════════════════════════════════════════════════════════════════
# ACP ADAPTER
# ══════════════════════════════════════════════════════════════════════════════

acp_sdk_mod = pytest.importorskip("acp_sdk", reason="acp-sdk requires Python 3.11+")


class TestACPAdapter:
    def _make_acp_input(self, text="analyze data"):
        part = MagicMock()
        part.content = text
        msg = MagicMock()
        msg.parts = [part]
        return [msg]

    @pytest.mark.asyncio
    async def test_governed_acp_agent_accept(self, rzv):
        @governed_acp_agent(rzv=rzv, action="SAFE_PROCESS")
        async def safe_agent(input, context=None):
            yield {"result": "processed"}

        results = []
        async for r in safe_agent(self._make_acp_input("safe data")):
            results.append(r)
        assert results == [{"result": "processed"}]

    @pytest.mark.asyncio
    async def test_governed_acp_agent_reject(self, rzv):
        @governed_acp_agent(rzv=rzv, action="OVERRIDE_GATE")
        async def bad_agent(input, context=None):
            yield {"result": "should not run"}

        with pytest.raises(RzvGatewayError):
            async for _ in bad_agent(self._make_acp_input("bypass")):
                pass

    def test_governed_acp_agent_marked(self, rzv):
        @governed_acp_agent(rzv=rzv, action="SAFE_OP")
        async def my_agent(input, context=None):
            yield {}

        assert my_agent._rzv_governed is True
        assert my_agent._rzv_action == "SAFE_OP"

    def test_default_action_name(self, rzv):
        @governed_acp_agent(rzv=rzv)
        async def process_directive(input, context=None):
            yield {}

        assert process_directive._rzv_action == "ACP_AGENT_PROCESS_DIRECTIVE"

    def test_acp_payload_extraction(self):
        part = MagicMock()
        part.content = "budget analysis Q3"
        msg = MagicMock()
        msg.parts = [part]
        payload = _acp_input_to_payload([msg], "TEST_ACTION")
        assert payload["content"] == "budget analysis Q3"

    def test_acp_payload_empty_input(self):
        payload = _acp_input_to_payload(None, "TEST")
        assert payload["action"] == "TEST"

    def test_governed_acp_server_creation(self, rzv):
        server = GovernedACPServer(rzv=rzv, agent_id="test-server")
        assert server._agent_id == "test-server"
        assert server.gov is not None

    @pytest.mark.asyncio
    async def test_governed_acp_server_agent_accept(self, rzv):
        server = GovernedACPServer(rzv=rzv, agent_id="safe-server")

        async def budget_agent(input, context=None):
            yield {"budget": "approved"}

        with patch.object(server, '_get_server') as mock_srv:
            mock_srv.return_value.agent = lambda f: f
            decorated = server.governed_agent(action="SAFE_BUDGET")(budget_agent)

        results = []
        async for r in decorated(self._make_acp_input("safe budget"), None):
            results.append(r)
        assert results == [{"budget": "approved"}]

    @pytest.mark.asyncio
    async def test_governed_acp_run_accept(self, rzv):
        client = MagicMock()
        client.run_async = AsyncMock(return_value={"status": "done"})
        result = await governed_acp_run(
            client=client,
            agent="safe_agent",
            input=self._make_acp_input("safe"),
            rzv=rzv,
            agent_id="safe-client",
        )
        assert result == {"status": "done"}

    @pytest.mark.asyncio
    async def test_governed_acp_run_blocked(self, rzv):
        client = MagicMock()
        client.run_async = AsyncMock()
        with pytest.raises(RzvGatewayError):
            await governed_acp_run(
                client=client,
                agent="override_bypass_autonomous",
                input=self._make_acp_input("exploit"),
                rzv=rzv,
            )
        client.run_async.assert_not_called()

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_acp_agent_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        @governed_acp_agent(rzv=rzv_live, action="LIVE_PROCESS")
        async def live_agent(input, context=None):
            yield {"live": True}

        results = []
        async for r in live_agent(self._make_acp_input("live data")):
            results.append(r)
        assert results[0]["live"] is True


# ══════════════════════════════════════════════════════════════════════════════
# PYDANTICAI ADAPTER
# ══════════════════════════════════════════════════════════════════════════════

pydantic_ai_mod = pytest.importorskip("pydantic_ai", reason="pydantic-ai requires Python 3.10+")


class TestPydanticAIAdapter:
    @pytest.mark.asyncio
    async def test_governed_tool_accept(self, rzv):
        @governed_pydantic_tool(rzv=rzv, action="SAFE_SEARCH")
        async def search(ctx, query: str) -> str:
            return f"results: {query}"

        ctx = MagicMock()
        result = await search(ctx, "AI governance")
        assert result == "results: AI governance"

    @pytest.mark.asyncio
    async def test_governed_tool_reject(self, rzv):
        @governed_pydantic_tool(rzv=rzv, action="OVERRIDE_GATE")
        async def bad_tool(ctx, cmd: str) -> str:
            return "should not run"

        ctx = MagicMock()
        with pytest.raises(RzvGatewayError):
            await bad_tool(ctx, "bypass")

    def test_governed_tool_marked(self, rzv):
        @governed_pydantic_tool(rzv=rzv, action="MY_ACTION")
        async def my_tool(ctx, x: str) -> str:
            return x

        assert my_tool._rzv_governed is True
        assert my_tool._rzv_action == "MY_ACTION"

    def test_default_action_from_name(self, rzv):
        @governed_pydantic_tool(rzv=rzv)
        async def process_payment(ctx, amount: float) -> str:
            return "ok"

        assert process_payment._rzv_action == "PAI_TOOL_PROCESS_PAYMENT"

    def test_sync_tool_accept(self, rzv):
        @governed_pydantic_tool(rzv=rzv, action="SAFE_SYNC")
        def sync_tool(ctx, x: int) -> int:
            return x * 2

        ctx = MagicMock()
        result = sync_tool(ctx, 5)
        assert result == 10

    def test_sync_tool_reject(self, rzv):
        @governed_pydantic_tool(rzv=rzv, action="OVERRIDE_GATE")
        def bad_sync(ctx) -> str:
            return "no"

        ctx = MagicMock()
        with pytest.raises(RzvGatewayError):
            bad_sync(ctx)

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_tool_accept(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        @governed_pydantic_tool(rzv=rzv_live, action="LIVE_SEARCH")
        async def live_search(ctx, query: str) -> str:
            return f"live: {query}"

        ctx = MagicMock()
        result = await live_search(ctx, "Egypt AI policy")
        assert result == "live: Egypt AI policy"

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_tool_reject(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "REJECT", "reason_code": "L014", "cvid": DEMO_CVID, "violations": [],
        }))

        @governed_pydantic_tool(rzv=rzv_live, action="BLOCKED_OP")
        async def blocked(ctx) -> str:
            return "no"

        ctx = MagicMock()
        with pytest.raises(RzvGatewayError) as exc_info:
            await blocked(ctx)
        assert "L014" in str(exc_info.value)


# ══════════════════════════════════════════════════════════════════════════════
# SMOLAGENTS ADAPTER
# ══════════════════════════════════════════════════════════════════════════════

class TestSmolagentsAdapter:
    @pytest.fixture(autouse=True)
    def require_smolagents(self):
        pytest.importorskip("smolagents", reason="smolagents not installed")

    def test_governed_smol_tool_class_exists(self):
        assert GovernedSmolTool is not None

    def test_governed_smol_tool_subclass_accept(self, rzv):
        class SearchTool(GovernedSmolTool):
            name = "web_search"
            description = "Search the web"
            inputs = {"query": {"type": "string", "description": "query"}}
            output_type = "string"

            def forward(self, query: str) -> str:
                return f"results: {query}"

        tool = SearchTool()
        tool.rzv_client = rzv
        tool.rzv_action = "SAFE_SEARCH"
        result = tool("AI governance in Egypt")
        assert result == "results: AI governance in Egypt"

    def test_governed_smol_tool_subclass_reject(self, rzv):
        class OverrideTool(GovernedSmolTool):
            name = "override_tool"
            description = "Override tool"
            inputs = {}
            output_type = "string"

            def forward(self) -> str:
                return "should not run"

        tool = OverrideTool()
        tool.rzv_client = rzv
        tool.rzv_action = "OVERRIDE_GATE"
        with pytest.raises(RzvGatewayError):
            tool()

    def test_governed_smol_tool_subclass_is_governed(self, rzv):
        class MinimalTool(GovernedSmolTool):
            name = "minimal_tool"
            description = "minimal governed tool"
            inputs = {"x": {"type": "string", "description": "input"}}
            output_type = "string"

            def forward(self, x: str) -> str:
                return x.upper()

        tool = MinimalTool()
        tool.rzv_client = rzv
        tool.rzv_action = "SAFE_MINIMAL"
        result = tool(x="hello")
        assert result == "HELLO"

    def test_governed_smol_tool_wrap_accept(self, rzv):
        mock_tool = MagicMock()
        mock_tool.name = "search"
        mock_tool.__class__.__call__ = MagicMock(return_value="search results")

        governed = governed_smol_tool(mock_tool, rzv=rzv, action="SAFE_SEARCH")
        assert governed._rzv_governed is True
        assert governed._rzv_action == "SAFE_SEARCH"

    def test_governed_smol_tool_wrap_blocked(self, rzv):
        smolagents = pytest.importorskip("smolagents")
        SmolTool = smolagents.Tool

        class ConcreteSmolTool(SmolTool):
            name = "bypass_tool"
            description = "bypass"
            inputs = {}
            output_type = "string"
            def forward(self): return "ran"

        tool = ConcreteSmolTool()
        governed = governed_smol_tool(tool, rzv=rzv, action="OVERRIDE_GATE")
        # forward() is patched — calling it directly raises RzvGatewayError
        with pytest.raises(RzvGatewayError):
            governed.forward()

    def test_action_name_from_tool_name(self, rzv):
        mock_tool = MagicMock()
        mock_tool.name = "web-search-tool"
        governed = governed_smol_tool(mock_tool, rzv=rzv)
        assert governed._rzv_action == "SMOL_TOOL_WEB_SEARCH_TOOL"


# ══════════════════════════════════════════════════════════════════════════════
# SEMANTIC KERNEL ADAPTER
# ══════════════════════════════════════════════════════════════════════════════

class TestSemanticKernelAdapter:
    @pytest.mark.asyncio
    async def test_governed_kernel_function_accept(self, rzv):
        class MyPlugin:
            @governed_kernel_function(rzv=rzv, action="SAFE_SUMMARIZE")
            async def summarize(self, document: str) -> str:
                return f"summary: {document[:50]}"

        plugin = MyPlugin()
        result = await plugin.summarize("This is a long document about AI governance.")
        assert result.startswith("summary:")

    @pytest.mark.asyncio
    async def test_governed_kernel_function_reject(self, rzv):
        class BadPlugin:
            @governed_kernel_function(rzv=rzv, action="OVERRIDE_GATE")
            async def override(self) -> str:
                return "should not run"

        plugin = BadPlugin()
        with pytest.raises(RzvGatewayError):
            await plugin.override()

    def test_governed_kernel_function_marked(self, rzv):
        class MyPlugin:
            @governed_kernel_function(rzv=rzv, action="MY_SK_ACTION")
            async def my_func(self, x: str) -> str:
                return x

        assert MyPlugin.my_func._rzv_governed is True
        assert MyPlugin.my_func._rzv_action == "MY_SK_ACTION"

    def test_default_action_name(self, rzv):
        class MyPlugin:
            @governed_kernel_function(rzv=rzv)
            async def process_directive(self, x: str) -> str:
                return x

        assert MyPlugin.process_directive._rzv_action == "SK_FUNC_PROCESS_DIRECTIVE"

    @pytest.mark.asyncio
    async def test_uses_self_rzv_client(self, rzv):
        class MyPlugin(GovernedKernelPlugin):
            @governed_kernel_function
            async def safe_op(self, x: str) -> str:
                return x.upper()

        plugin = MyPlugin()
        plugin.rzv_client = rzv
        result = await plugin.safe_op("hello")
        assert result == "HELLO"

    @pytest.mark.asyncio
    async def test_self_rzv_blocks(self, rzv):
        class BadPlugin(GovernedKernelPlugin):
            @governed_kernel_function(action="OVERRIDE_GATE")
            async def override(self) -> str:
                return "no"

        plugin = BadPlugin()
        plugin.rzv_client = rzv
        with pytest.raises(RzvGatewayError):
            await plugin.override()

    def test_kernel_plugin_metadata(self, rzv):
        plugin = GovernedKernelPlugin()
        plugin.rzv_client = rzv
        plugin.rzv_agent_id = "azure-agent"
        meta = plugin.get_rzv_metadata()
        assert meta["rzv_governed"] is True
        assert meta["rzv_agent_id"] == "azure-agent"
        assert "cvid:blake3:" in meta["rzv_genesis"]

    def test_sync_kernel_function(self, rzv):
        class MyPlugin:
            @governed_kernel_function(rzv=rzv, action="SAFE_SYNC_SK")
            def sync_func(self, x: int) -> int:
                return x * 3

        plugin = MyPlugin()
        result = plugin.sync_func(7)
        assert result == 21

    @respx.mock
    @pytest.mark.asyncio
    async def test_live_kernel_function(self, rzv_live):
        respx.post(f"{GATEWAY}/v1/validate").mock(return_value=httpx.Response(200, json={
            "outcome": "ACCEPT", "cvid": DEMO_CVID, "violations": [],
        }))

        class LivePlugin:
            @governed_kernel_function(rzv=rzv_live, action="LIVE_SK_OP")
            async def live_func(self, query: str) -> str:
                return f"live: {query}"

        plugin = LivePlugin()
        result = await plugin.live_func("Egypt AI Act compliance")
        assert result == "live: Egypt AI Act compliance"
