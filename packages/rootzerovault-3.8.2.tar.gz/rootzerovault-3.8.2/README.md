# rootzerovault

Constitutional AI Governance SDK for Python.

```python
from rootzerovault import RzvClient
rzv = RzvClient(gateway="http://localhost:8443")
result = rzv.validate(specimen)
print(result.outcome)  # 'ACCEPT' | 'REJECT'
```

Genesis: cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867
