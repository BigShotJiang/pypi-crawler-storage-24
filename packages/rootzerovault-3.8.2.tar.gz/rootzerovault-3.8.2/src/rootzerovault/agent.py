"""
AgentClient — Constitutional AI Agent Deployment for Root Zero Vault

Makes it extremely easy for deed holders to deploy governed AI agents.
Every agent action is validated, sealed to the chain, and independently verifiable.

Quick start:
    from rootzerovault import RzvClient, AgentClient

    rzv = RzvClient(gateway="http://localhost:8443")

    # Register a governed agent
    agent = AgentClient.register(
        rzv,
        agent_id="finance-analyzer",
        name="Finance Analyzer",
        description="Analyzes financial reports and sends summaries",
        deed_cvid="cvid:blake3:1544ff...",
        permitted_tools=["read_report", "query_database", "send_email"],
        tool_class_ceiling="ENTITY_OPERATION",
    )

    # Agent proposes a tool call — returns pending request
    request = agent.propose(
        tool_name="send_email",
        tool_class="ENTITY_OPERATION",
        action_description="Send Q3 report to CFO",
        payload={"to": "cfo@company.com", "subject": "Q3 Report"},
        correlation_id="task-001",
    )

    # Check what is pending approval
    queue = agent.queue()

    # Human approves
    result = agent.authorize(request["request_id"], approved_by="deen.saleh")

    # Or human blocks
    result = agent.block(request["request_id"], blocked_by="deen.saleh", reason="Not authorized")

    # View sealed journal
    journal = agent.journal()

Constitutional guarantees:
    - No AI agent may self-authorize (Article IX)
    - Every action is sealed to the BLAKE3 chain (Article X)
    - Human co-signature is cryptographically bound to the exact tool call
    - An agent cannot act outside its declared permission envelope
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .exceptions import RzvGatewayError, RzvNotConfiguredError


class AgentRecord:
    """
    A registered, governed AI agent.

    Returned by AgentClient.register() and AgentClient.load().
    Use this object to propose tool calls, manage the approval queue,
    and inspect the sealed action journal.
    """

    def __init__(self, client: "AgentClient") -> None:
        self._client = client

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def agent_id(self) -> str:
        return self._client.agent_id

    @property
    def gateway(self) -> str:
        return self._client._rzv._gateway or ""

    # ── Tool call lifecycle ───────────────────────────────────────────────────

    def propose(
        self,
        tool_name: str,
        tool_class: str,
        action_description: str,
        payload: Dict[str, Any],
        correlation_id: str,
    ) -> Dict[str, Any]:
        """
        Propose a tool call. Returns the pending request awaiting human approval.

        Parameters
        ----------
        tool_name : str
            The tool being called (must be in permitted_tools).
        tool_class : str
            Risk class: READ_ONLY | STATE_QUERY | GOVERNANCE_READ |
                        ENTITY_OPERATION | CUSTODY_OPERATION | GOVERNANCE_WRITE
        action_description : str
            Plain English description of what this action does.
        payload : dict
            The tool call payload. Sealed into the chain.
        correlation_id : str
            Your tracking ID for this request.

        Returns
        -------
        dict
            Pending tool call with request_id, status, expires_at.
            If human_oversight_required=False, returns immediately with APPROVED.
        """
        return self._client.propose(
            tool_name=tool_name,
            tool_class=tool_class,
            action_description=action_description,
            payload=payload,
            correlation_id=correlation_id,
        )

    def queue(self) -> Dict[str, Any]:
        """
        Get all pending tool calls awaiting human approval.

        Returns
        -------
        dict
            {"agent_id": ..., "pending_count": ..., "pending": [...]}
        """
        return self._client.queue()

    def authorize(self, request_id: str, approved_by: str) -> Dict[str, Any]:
        """
        Approve a pending tool call. Sealed to the constitutional chain.

        Parameters
        ----------
        request_id : str
            The request_id from propose().
        approved_by : str
            Identity of the human approver.

        Returns
        -------
        dict
            {"outcome": "ACCEPT", "sealed_at": ..., "chain_depth": ...}
        """
        return self._client.authorize(request_id=request_id, approved_by=approved_by)

    def block(
        self,
        request_id: str,
        blocked_by: str,
        reason: str,
        reason_code: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Block a pending tool call. Sealed to the constitutional chain.

        Parameters
        ----------
        request_id : str
            The request_id from propose().
        blocked_by : str
            Identity of the human who blocked it.
        reason : str
            Human-readable reason for blocking.
        reason_code : str, optional
            Machine-readable code (default: E-BLOCK).

        Returns
        -------
        dict
            {"outcome": "REJECT", "reason_code": ..., "sealed_at": ...}
        """
        return self._client.block(
            request_id=request_id,
            blocked_by=blocked_by,
            reason=reason,
            reason_code=reason_code,
        )

    def journal(self) -> Dict[str, Any]:
        """
        Get the agent's sealed action history.

        Returns
        -------
        dict
            {"agent_id": ..., "action_count": ..., "actions": [...]}
            Each action includes outcome, approved_by, sealed_at, chain_depth.
        """
        return self._client.journal()

    def details(self) -> Dict[str, Any]:
        """Get full agent details including stats."""
        return self._client.get()

    def suspend(self) -> Dict[str, Any]:
        """Suspend this agent — no new tool calls accepted."""
        return self._client.suspend()

    def reinstate(self) -> Dict[str, Any]:
        """Reinstate a suspended agent."""
        return self._client.reinstate()

    def __repr__(self) -> str:
        return (
            f"AgentRecord(agent_id={self.agent_id!r}, "
            f"gateway={self.gateway!r})"
        )


class AgentClient:
    """
    Low-level agent API client. Use AgentRecord (returned by register/load)
    for the high-level interface.

    Parameters
    ----------
    rzv : RzvClient
        A configured RzvClient with a gateway URL.
    agent_id : str
        The agent's unique identifier.
    """

    def __init__(self, rzv: Any, agent_id: str) -> None:
        self._rzv   = rzv
        self.agent_id = agent_id

    # ── Class methods ─────────────────────────────────────────────────────────

    @classmethod
    def register(
        cls,
        rzv: Any,
        agent_id: str,
        name: str,
        description: str,
        deed_cvid: str,
        permitted_tools: List[str],
        tool_class_ceiling: str = "ENTITY_OPERATION",
        human_oversight_required: bool = True,
        cosign_ttl_secs: int = 300,
    ) -> AgentRecord:
        """
        Register a new governed AI agent with the gateway.

        Parameters
        ----------
        rzv : RzvClient
            A configured RzvClient with gateway URL.
        agent_id : str
            Unique identifier (slug, e.g. "finance-analyzer").
        name : str
            Display name.
        description : str
            What this agent does.
        deed_cvid : str
            The deed CVID this agent operates under.
        permitted_tools : list[str]
            Tools this agent is allowed to invoke.
        tool_class_ceiling : str
            Maximum tool class: READ_ONLY | STATE_QUERY | GOVERNANCE_READ |
                                ENTITY_OPERATION | CUSTODY_OPERATION | GOVERNANCE_WRITE
        human_oversight_required : bool
            If True (default), every tool call requires human co-signature.
        cosign_ttl_secs : int
            How long a pending approval lives before expiring (default: 300s).

        Returns
        -------
        AgentRecord
            A registered agent ready to propose tool calls.

        Raises
        ------
        RzvNotConfiguredError
            If rzv has no gateway configured.
        RzvGatewayError
            If registration fails (e.g. agent_id already taken).
        """
        if not rzv.is_live:
            raise RzvNotConfiguredError(
                "AgentClient.register() requires a gateway. "
                "Pass gateway='http://...' to RzvClient()."
            )

        body = {
            "agent_id":                 agent_id,
            "name":                     name,
            "description":              description,
            "deed_cvid":                deed_cvid,
            "permitted_tools":          permitted_tools,
            "tool_class_ceiling":       tool_class_ceiling,
            "human_oversight_required": human_oversight_required,
            "cosign_ttl_secs":          cosign_ttl_secs,
        }

        resp = rzv._sync_http().post("/v1/agents/register", json=body)
        if resp.status_code not in (200, 201):
            raise RzvGatewayError(
                f"Agent registration failed [{resp.status_code}]: {resp.text}"
            )

        client = cls(rzv=rzv, agent_id=agent_id)
        return AgentRecord(client)

    @classmethod
    def load(cls, rzv: Any, agent_id: str) -> AgentRecord:
        """
        Load an existing registered agent by ID.

        Parameters
        ----------
        rzv : RzvClient
            A configured RzvClient with gateway URL.
        agent_id : str
            The agent's unique identifier.

        Returns
        -------
        AgentRecord

        Raises
        ------
        RzvGatewayError
            If the agent is not found.
        """
        if not rzv.is_live:
            raise RzvNotConfiguredError(
                "AgentClient.load() requires a gateway."
            )

        resp = rzv._sync_http().get(f"/v1/agents/{agent_id}")
        if resp.status_code == 404:
            raise RzvGatewayError(f"Agent '{agent_id}' not found")
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Failed to load agent [{resp.status_code}]: {resp.text}"
            )

        client = cls(rzv=rzv, agent_id=agent_id)
        return AgentRecord(client)

    @classmethod
    def list_agents(cls, rzv: Any) -> List[Dict[str, Any]]:
        """
        List all registered agents.

        Returns
        -------
        list[dict]
            List of agent records with stats.
        """
        if not rzv.is_live:
            raise RzvNotConfiguredError("list_agents() requires a gateway.")

        resp = rzv._sync_http().get("/v1/agents/")
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Failed to list agents [{resp.status_code}]: {resp.text}"
            )
        return resp.json().get("agents", [])

    # ── Instance methods ──────────────────────────────────────────────────────

    def _http(self) -> Any:
        """Get the sync HTTP client."""
        return self._rzv._sync_http()

    def _base(self) -> str:
        return f"/v1/agents/{self.agent_id}"

    def propose(
        self,
        tool_name: str,
        tool_class: str,
        action_description: str,
        payload: Dict[str, Any],
        correlation_id: str,
    ) -> Dict[str, Any]:
        body = {
            "tool_name":          tool_name,
            "tool_class":         tool_class,
            "action_description": action_description,
            "payload":            payload,
            "correlation_id":     correlation_id,
        }
        resp = self._http().post(f"{self._base()}/propose", json=body)
        if resp.status_code not in (200, 201):
            raise RzvGatewayError(
                f"Propose failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def queue(self) -> Dict[str, Any]:
        resp = self._http().get(f"{self._base()}/queue")
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Queue fetch failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def authorize(self, request_id: str, approved_by: str) -> Dict[str, Any]:
        body = {"request_id": request_id, "approved_by": approved_by}
        resp = self._http().post(f"{self._base()}/authorize", json=body)
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Authorize failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def block(
        self,
        request_id: str,
        blocked_by: str,
        reason: str,
        reason_code: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "request_id": request_id,
            "blocked_by": blocked_by,
            "reason":     reason,
        }
        if reason_code:
            body["reason_code"] = reason_code
        resp = self._http().post(f"{self._base()}/block", json=body)
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Block failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def journal(self) -> Dict[str, Any]:
        resp = self._http().get(f"{self._base()}/journal")
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Journal fetch failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def get(self) -> Dict[str, Any]:
        resp = self._http().get(self._base())
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Agent fetch failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def suspend(self) -> Dict[str, Any]:
        resp = self._http().post(f"{self._base()}/suspend", json={})
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Suspend failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()

    def reinstate(self) -> Dict[str, Any]:
        resp = self._http().post(f"{self._base()}/reinstate", json={})
        if resp.status_code != 200:
            raise RzvGatewayError(
                f"Reinstate failed [{resp.status_code}]: {resp.text}"
            )
        return resp.json()
