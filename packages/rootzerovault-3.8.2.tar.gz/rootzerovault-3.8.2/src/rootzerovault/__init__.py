"""
rootzerovault — Constitutional AI Governance SDK for Python

Root Zero Vault validates every AI action against 18 constitutional rules
and seals the outcome to an immutable BLAKE3 hash chain.

Quick start:
    from rootzerovault import RzvClient, GovernanceClient

    # Connect to gateway
    rzv = RzvClient(gateway="http://localhost:8443")
    gov = GovernanceClient(rzv)

    # Gate any action
    result = gov.gate("TRANSFER_FUNDS", {"amount": 100_000})
    if result.accepted:
        execute_transfer()

    # Canonicalize YAML and get CVID
    canon = gov.canon("action: DEED_REGISTRATION\nts: 2026-01-01T00:00:00Z")
    print(canon.cvid)  # cvid:blake3:...

    # Seal governed communication
    msg = gov.seal_comms("EGYPT0", "EGYPT-CentralBank", "Q3 directive")
    print(msg.cvid)    # cvid:blake3:...

    # Use HttpAdapter to wrap any REST API
    from rootzerovault.adapters import HttpAdapter
    adapter = HttpAdapter(rzv=rzv, base_url="https://api.myservice.com")
    adapter.post("/transactions", {"amount": 100_000})  # gated automatically

Genesis CVID (frozen March 14 2026):
    cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867
"""

from .client import RzvClient
from .agent import AgentClient, AgentRecord
from .governance import (
    GovernanceClient,
    GateAction,
    CanonResult,
    SignResult,
    CommsResult,
    ChainEntry,
)
from .models import (
    Specimen,
    ValidationResult,
    Violation,
    RegistryEntry,
    JournalChainEntry,
    GatewaySchema,
)
from .exceptions import (
    RzvError,
    RzvGatewayError,
    RzvValidationError,
    RzvTimeoutError,
    RzvNotConfiguredError,
)
from .constants import GENESIS_CVID, ENGINE_VERSION, SDK_VERSION

__all__ = [
    # Primary clients
    "RzvClient",
    "GovernanceClient",
    # Agent
    "AgentClient",
    "AgentRecord",
    # Governance types
    "GateAction",
    "CanonResult",
    "SignResult",
    "CommsResult",
    "ChainEntry",
    # Models
    "Specimen",
    "ValidationResult",
    "Violation",
    "RegistryEntry",
    "JournalChainEntry",
    "GatewaySchema",
    # Exceptions
    "RzvError",
    "RzvGatewayError",
    "RzvValidationError",
    "RzvTimeoutError",
    "RzvNotConfiguredError",
    # Constants
    "GENESIS_CVID",
    "ENGINE_VERSION",
    "SDK_VERSION",
]

__version__ = SDK_VERSION
