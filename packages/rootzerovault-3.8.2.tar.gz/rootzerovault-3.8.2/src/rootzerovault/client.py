"""
RzvClient — Root Zero Vault gateway client.

Supports both synchronous and async usage via httpx.
"""

from __future__ import annotations

import json
import uuid
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import httpx

from .constants import DEFAULT_TIMEOUT, GENESIS_CVID
from .exceptions import (
    RzvGatewayError,
    RzvNotConfiguredError,
    RzvTimeoutError,
)
from .models import (
    GatewaySchema,
    JournalChainEntry,
    RegistryEntry,
    Specimen,
    ValidationResult,
)

if TYPE_CHECKING:
    pass


class RzvClient:
    """
    Root Zero Vault client.

    If ``gateway`` is provided → live chain-sealed validation via the gateway.
    If not → raises RzvNotConfiguredError for methods that require the gateway.

    Supports both sync and async usage:

    Sync:
        rzv = RzvClient(gateway="http://localhost:8443")
        result = rzv.validate(specimen)

    Async:
        async with RzvClient(gateway="http://localhost:8443") as rzv:
            result = await rzv.validate_async(specimen)

    Context manager (sync):
        with RzvClient(gateway="http://localhost:8443") as rzv:
            result = rzv.validate(specimen)

    Egypt deployment:
        rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
        result = rzv.validate(ai_action_specimen)

    Parameters
    ----------
    gateway : str, optional
        Gateway base URL (e.g. "http://localhost:8443").
        Required for any method that reads from or writes to the chain.
    timeout : float
        Request timeout in seconds (default: 10.0).
    verify_ssl : bool
        Verify SSL certificates (default: True). Set False for self-signed certs.
    """

    def __init__(
        self,
        gateway: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        verify_ssl: bool = True,
    ) -> None:
        self._gateway = gateway.rstrip("/") if gateway else None
        self._timeout = timeout
        self._verify_ssl = verify_ssl
        self._sync_client: Optional[httpx.Client] = None
        self._async_client: Optional[httpx.AsyncClient] = None

    # ── Properties ─────────────────────────────────────────────────────────────

    @property
    def is_live(self) -> bool:
        """True if a gateway is configured."""
        return self._gateway is not None

    @property
    def gateway(self) -> Optional[str]:
        """The configured gateway URL, or None."""
        return self._gateway

    # ── Context managers ───────────────────────────────────────────────────────

    def __enter__(self) -> "RzvClient":
        self._sync_client = httpx.Client(
            base_url=self._gateway or "",
            timeout=self._timeout,
            verify=self._verify_ssl,
        )
        return self

    def __exit__(self, *args: Any) -> None:
        if self._sync_client:
            self._sync_client.close()
            self._sync_client = None

    async def __aenter__(self) -> "RzvClient":
        self._async_client = httpx.AsyncClient(
            base_url=self._gateway or "",
            timeout=self._timeout,
            verify=self._verify_ssl,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    # ── Sync API ───────────────────────────────────────────────────────────────

    def validate(
        self,
        specimen: Specimen,
        correlation_id: Optional[str] = None,
    ) -> ValidationResult:
        """
        Validate a specimen against the 18 constitutional rules.

        Sends to /v1/validate — chain-seals the result to the journal.
        Use propose() for a dry-run with no side effects.

        Parameters
        ----------
        specimen : Specimen
            The specimen dict to validate.
        correlation_id : str, optional
            Correlation ID for the journal entry. Auto-generated if absent.

        Returns
        -------
        ValidationResult
            outcome='ACCEPT' or 'REJECT', violations, chain_hash, etc.

        Raises
        ------
        RzvNotConfiguredError
            If no gateway is configured.
        RzvGatewayError
            If the gateway returns an error response.
        RzvTimeoutError
            If the request times out.
        """
        self._require_gateway("validate()")
        body: Dict[str, Any] = {"specimen": specimen.get("specimen", specimen)}
        if correlation_id:
            body["correlation_id"] = correlation_id
        else:
            body["correlation_id"] = str(uuid.uuid4())

        data = self._post_sync("/v1/validate", body)
        return ValidationResult.from_dict(data, source="gateway")

    def propose(self, specimen: Specimen) -> ValidationResult:
        """
        Dry-run validation — no side effects, no journal entry.
        Equivalent to /v1/propose on the gateway.
        """
        self._require_gateway("propose()")
        body = {"specimen": specimen.get("specimen", specimen)}
        data = self._post_sync("/v1/propose", body)
        return ValidationResult.from_dict(data, source="gateway")

    def schema(self) -> GatewaySchema:
        """Get gateway schema info — engine version, genesis CVID, env."""
        self._require_gateway("schema()")
        data = self._get_sync("/v1/schema")
        return GatewaySchema.from_dict(data)

    def lookup_by_cvid(self, deed_cvid: str) -> Optional[RegistryEntry]:
        """Look up a deed by CVID. Returns None if not registered."""
        self._require_gateway("lookup_by_cvid()")
        try:
            data = self._get_sync(f"/v1/registry/{deed_cvid}")
            return RegistryEntry.from_dict(data)
        except RzvGatewayError as e:
            if e.status_code == 404:
                return None
            raise

    def lookup_by_id(self, deed_id: str) -> Optional[RegistryEntry]:
        """Look up a deed by human-readable ID (e.g. 'EGYPT', 'NYC')."""
        self._require_gateway("lookup_by_id()")
        try:
            data = self._get_sync(f"/v1/registry/id/{deed_id}")
            return RegistryEntry.from_dict(data)
        except RzvGatewayError as e:
            if e.status_code == 404:
                return None
            raise

    def journal_tail(self, deed_cvid: str) -> List[JournalChainEntry]:
        """Get the last 50 journal entries for a deed."""
        self._require_gateway("journal_tail()")
        data = self._get_sync(f"/v1/journal/{deed_cvid}")
        if isinstance(data, list):
            return [JournalChainEntry.from_dict(e) for e in data]
        return []

    def export_vault(self) -> Dict[str, Any]:
        """Export the full vault as a proof bundle (JSON)."""
        self._require_gateway("export_vault()")
        return self._get_sync("/v1/export/vault")

    def export_journal(self) -> List[JournalChainEntry]:
        """Export the full journal — all entries, all deeds."""
        self._require_gateway("export_journal()")
        data = self._get_sync("/v1/export/journal")
        if isinstance(data, list):
            return [JournalChainEntry.from_dict(e) for e in data]
        return []

    def is_healthy(self) -> bool:
        """Return True if the gateway is reachable and healthy."""
        if not self.is_live:
            return False
        try:
            client = self._get_sync_client()
            resp = client.get("/health/live")
            return resp.status_code == 200
        except Exception:
            return False

    # ── Async API ──────────────────────────────────────────────────────────────

    async def validate_async(
        self,
        specimen: Specimen,
        correlation_id: Optional[str] = None,
    ) -> ValidationResult:
        """Async version of validate()."""
        self._require_gateway("validate_async()")
        body: Dict[str, Any] = {"specimen": specimen.get("specimen", specimen)}
        body["correlation_id"] = correlation_id or str(uuid.uuid4())
        data = await self._post_async("/v1/validate", body)
        return ValidationResult.from_dict(data, source="gateway")

    async def propose_async(self, specimen: Specimen) -> ValidationResult:
        """Async version of propose()."""
        self._require_gateway("propose_async()")
        body = {"specimen": specimen.get("specimen", specimen)}
        data = await self._post_async("/v1/propose", body)
        return ValidationResult.from_dict(data, source="gateway")

    async def schema_async(self) -> GatewaySchema:
        """Async version of schema()."""
        self._require_gateway("schema_async()")
        data = await self._get_async("/v1/schema")
        return GatewaySchema.from_dict(data)

    async def lookup_by_id_async(self, deed_id: str) -> Optional[RegistryEntry]:
        """Async version of lookup_by_id()."""
        self._require_gateway("lookup_by_id_async()")
        try:
            data = await self._get_async(f"/v1/registry/id/{deed_id}")
            return RegistryEntry.from_dict(data)
        except RzvGatewayError as e:
            if e.status_code == 404:
                return None
            raise

    async def is_healthy_async(self) -> bool:
        """Async version of is_healthy()."""
        if not self.is_live:
            return False
        try:
            client = self._get_async_client()
            resp = await client.get("/health/live")
            return resp.status_code == 200
        except Exception:
            return False

    # ── Private helpers ────────────────────────────────────────────────────────

    def _require_gateway(self, method: str) -> None:
        if not self.is_live:
            raise RzvNotConfiguredError(method)

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client:
            return self._sync_client
        return httpx.Client(
            base_url=self._gateway or "",
            timeout=self._timeout,
            verify=self._verify_ssl,
        )

    def _sync_http(self) -> httpx.Client:
        """Alias for AgentClient — returns the configured sync HTTP client."""
        return self._get_sync_client()

    def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client:
            return self._async_client
        return httpx.AsyncClient(
            base_url=self._gateway or "",
            timeout=self._timeout,
            verify=self._verify_ssl,
        )

    def _post_sync(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        client = self._get_sync_client()
        try:
            resp = client.post(
                path,
                json=body,
                headers={"Content-Type": "application/json"},
            )
        except httpx.TimeoutException as e:
            raise RzvTimeoutError(f"Request to {path} timed out after {self._timeout}s") from e
        except httpx.RequestError as e:
            raise RzvGatewayError(f"Request to {path} failed: {e}") from e

        if resp.status_code not in (200, 201):
            raise RzvGatewayError(
                f"Gateway returned {resp.status_code} at {path}",
                status_code=resp.status_code,
                body=resp.text[:500],
            )
        return resp.json()

    def _get_sync(self, path: str) -> Any:
        client = self._get_sync_client()
        try:
            resp = client.get(path)
        except httpx.TimeoutException as e:
            raise RzvTimeoutError(f"Request to {path} timed out") from e
        except httpx.RequestError as e:
            raise RzvGatewayError(f"Request to {path} failed: {e}") from e

        if resp.status_code == 404:
            raise RzvGatewayError(f"Not found: {path}", status_code=404)
        if not resp.is_success:
            raise RzvGatewayError(
                f"Gateway returned {resp.status_code} at {path}",
                status_code=resp.status_code,
                body=resp.text[:500],
            )
        return resp.json()

    async def _post_async(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        client = self._get_async_client()
        try:
            resp = await client.post(
                path,
                json=body,
                headers={"Content-Type": "application/json"},
            )
        except httpx.TimeoutException as e:
            raise RzvTimeoutError(f"Request to {path} timed out") from e
        except httpx.RequestError as e:
            raise RzvGatewayError(f"Request to {path} failed: {e}") from e

        if not resp.is_success:
            raise RzvGatewayError(
                f"Gateway returned {resp.status_code} at {path}",
                status_code=resp.status_code,
                body=resp.text[:500],
            )
        return resp.json()

    async def _get_async(self, path: str) -> Any:
        client = self._get_async_client()
        try:
            resp = await client.get(path)
        except httpx.TimeoutException as e:
            raise RzvTimeoutError(f"Request to {path} timed out") from e
        except httpx.RequestError as e:
            raise RzvGatewayError(f"Request to {path} failed: {e}") from e

        if resp.status_code == 404:
            raise RzvGatewayError(f"Not found: {path}", status_code=404)
        if not resp.is_success:
            raise RzvGatewayError(
                f"Gateway returned {resp.status_code} at {path}",
                status_code=resp.status_code,
                body=resp.text[:500],
            )
        return resp.json()
