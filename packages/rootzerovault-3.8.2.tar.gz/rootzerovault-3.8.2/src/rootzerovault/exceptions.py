"""Exceptions for the Root Zero Vault SDK."""


class RzvError(Exception):
    """Base exception for all Root Zero Vault SDK errors."""


class RzvGatewayError(RzvError):
    """Raised when the gateway returns an error response."""

    def __init__(self, message: str, status_code: int = 0, body: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class RzvValidationError(RzvError):
    """Raised when a validation request is malformed (not a REJECT outcome)."""


class RzvTimeoutError(RzvError):
    """Raised when a gateway request times out."""


class RzvNotConfiguredError(RzvError):
    """Raised when a method requires a gateway but none is configured."""

    def __init__(self, method: str):
        super().__init__(
            f"{method} requires a live gateway. "
            f"Initialize with: RzvClient(gateway='http://localhost:8443')"
        )
