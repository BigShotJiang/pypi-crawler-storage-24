"""Data models for the Root Zero Vault SDK."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional
from .constants import GENESIS_CVID, ENGINE_VERSION


# ── Input types ───────────────────────────────────────────────────────────────

Specimen = Dict[str, Any]
"""
A validation specimen — the payload submitted for constitutional review.

Minimal shape:
    {
        "specimen": {
            "deed": {
                "cvid": "cvid:blake3:...",
                "issued_by": "RootZero"
            }
        }
    }

With bundle:
    {
        "specimen": {
            "deed": { "cvid": "cvid:blake3:...", ... },
            "bundle": {
                "journal_entries": [
                    {
                        "type": "AI_MODEL_DEPLOY",
                        "ts": "2026-01-01T00:00:00Z",
                        "signer": "GATEWAY_KEY",
                        "signature_policy": "ed25519-only",
                        "signatures": ["sig:ed25519:..."],
                        "parent_hash": "0000..."
                    }
                ]
            }
        }
    }
"""


# ── Violation ─────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Violation:
    """A constitutional rule violation — one rule failure."""

    #: Canonical deed spec code (e.g. "E-AUTH", "E-CANON", "E-SIG")
    canonical_code: str

    #: Human-readable violation message
    message: Optional[str] = None

    #: Internal rule code
    rule_code: Optional[str] = None

    #: Field path where the violation occurred
    field: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Violation":
        return cls(
            canonical_code=data.get("canonical_code", data.get("code", "E-UNKNOWN")),
            message=data.get("message"),
            rule_code=data.get("rule_code") or data.get("legacy_code"),
            field=data.get("field"),
        )

    def __str__(self) -> str:
        parts = [self.canonical_code]
        if self.message:
            parts.append(self.message)
        return ": ".join(parts)


# ── ValidationResult ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ValidationMeta:
    """Metadata about the validation engine."""
    engine_version: str = ENGINE_VERSION
    schema_version: str = "3"
    genesis_cvid: str = GENESIS_CVID

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ValidationMeta":
        return cls(
            engine_version=data.get("engine_version", ENGINE_VERSION),
            schema_version=data.get("schema_version", "3"),
            genesis_cvid=data.get("genesis_cvid", GENESIS_CVID),
        )


@dataclass(frozen=True)
class ValidationResult:
    """
    The result of a constitutional validation.

    Attributes:
        outcome: 'ACCEPT' or 'REJECT'
        reason_code: Primary violation code on REJECT, None on ACCEPT
        violations: All violations (empty list on ACCEPT)
        state_fingerprint: blake3 fingerprint of vault state after validation
        meta: Engine metadata
        chain_hash: blake3 hash of the sealed journal entry (gateway only)
        journal_seq: Journal entry sequence number (gateway only)
        source: 'gateway' or 'wasm'
        accepted: True if outcome is ACCEPT
        rejected: True if outcome is REJECT
    """

    outcome: Literal["ACCEPT", "REJECT"]
    reason_code: Optional[str]
    violations: List[Violation] = field(default_factory=list)
    state_fingerprint: Optional[str] = None
    meta: ValidationMeta = field(default_factory=ValidationMeta)
    chain_hash: Optional[str] = None
    journal_seq: Optional[int] = None
    source: Literal["gateway", "wasm"] = "wasm"

    @property
    def accepted(self) -> bool:
        """True if the validation passed all constitutional rules."""
        return self.outcome == "ACCEPT"

    @property
    def rejected(self) -> bool:
        """True if any constitutional rule was violated."""
        return self.outcome == "REJECT"

    @classmethod
    def from_dict(cls, data: Dict[str, Any], source: str = "gateway") -> "ValidationResult":
        # Handle both v2 (decision/primary_code) and v3 (outcome/reason_code) field names
        outcome = data.get("outcome") or data.get("decision") or "REJECT"
        reason_code = data.get("reason_code") or data.get("primary_code")
        violations = [
            Violation.from_dict(v) for v in data.get("violations", [])
        ]
        meta_raw = data.get("meta", {})
        meta = ValidationMeta.from_dict(meta_raw) if isinstance(meta_raw, dict) else ValidationMeta()

        return cls(
            outcome=outcome,
            reason_code=reason_code,
            violations=violations,
            state_fingerprint=data.get("state_fingerprint"),
            meta=meta,
            chain_hash=data.get("chain_hash"),
            journal_seq=data.get("journal_seq"),
            source=source,
        )

    def __str__(self) -> str:
        if self.accepted:
            return f"ValidationResult(ACCEPT, chain={self.chain_hash or 'offline'})"
        codes = ", ".join(v.canonical_code for v in self.violations[:3])
        return f"ValidationResult(REJECT, reason={self.reason_code}, violations=[{codes}])"

    def __bool__(self) -> bool:
        """Truth value is True on ACCEPT, False on REJECT."""
        return self.accepted


# ── Registry ──────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RegistryEntry:
    """A registry entry for a registered deed."""
    seq: int
    hash: str
    parent_hash: str
    deed_cvid: str
    outcome: str
    ts: str
    deed_id: Optional[str] = None
    correlation_id: Optional[str] = None
    journal_ref: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RegistryEntry":
        return cls(
            seq=data["seq"],
            hash=data["hash"],
            parent_hash=data["parent_hash"],
            deed_cvid=data["deed_cvid"],
            outcome=data["outcome"],
            ts=data["ts"],
            deed_id=data.get("deed_id"),
            correlation_id=data.get("correlation_id"),
            journal_ref=data.get("journal_ref"),
        )


# ── Journal ───────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class JournalChainEntry:
    """A sealed entry in the constitutional journal chain."""
    seq: int
    hash: str
    parent_hash: str
    deed_cvid: str
    correlation_id: str
    outcome: str
    ts: str
    reason_code: Optional[str] = None
    envelope_json: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JournalChainEntry":
        return cls(
            seq=data["seq"],
            hash=data["hash"],
            parent_hash=data["parent_hash"],
            deed_cvid=data["deed_cvid"],
            correlation_id=data.get("correlation_id", ""),
            outcome=data["outcome"],
            ts=data["ts"],
            reason_code=data.get("reason_code"),
            envelope_json=data.get("envelope_json"),
        )


# ── Gateway schema ────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class GatewaySchema:
    """Schema information from the gateway /v1/schema endpoint."""
    genesis_cvid: str
    engine_version: str
    schema_version: str
    codebook_version: str
    env: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GatewaySchema":
        return cls(
            genesis_cvid=data.get("genesis_cvid", GENESIS_CVID),
            engine_version=data.get("engine_version", ENGINE_VERSION),
            schema_version=data.get("schema_version", "3"),
            codebook_version=data.get("codebook_version", "3"),
            env=data.get("env", "DEV"),
        )
