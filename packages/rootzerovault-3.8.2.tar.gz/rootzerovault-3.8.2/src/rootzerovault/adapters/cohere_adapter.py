"""
Cohere adapter — constitutional governance for Cohere's API.

Cohere is the leading enterprise RAG platform — Command R+, Rerank,
and Embed models used heavily in document intelligence, enterprise
search, and retrieval-augmented generation pipelines. Significant
adoption in legal, financial, and government document processing.

Every chat(), generate(), rerank(), and embed() call is evaluated
by the RSBIS constitutional gate before execution. Fail-closed.

RAG pipelines are particularly important to govern: when an AI agent
retrieves documents to ground a response, RSBIS seals what knowledge
the agent was permitted to access — not just what it did with it.

Three patterns:

1. GovernedCohereClient — drop-in for cohere.ClientV2:

    from rootzerovault.adapters.cohere_adapter import GovernedCohereClient

    rzv = RzvClient(gateway="http://localhost:8443")
    co = GovernedCohereClient(rzv=rzv, api_key="...")

    response = co.chat(
        model="command-r-plus-08-2024",
        messages=[{"role": "user", "content": "Summarize this contract..."}],
    )

2. GovernedCohereRAG — governed RAG pipeline (retrieve + generate):

    from rootzerovault.adapters.cohere_adapter import GovernedCohereRAG

    rag = GovernedCohereRAG(rzv=rzv, co=co)
    response = rag.chat_with_docs(
        query="What are the force majeure clauses?",
        documents=[...],
        action="LEGAL_RAG_QUERY",
    )

3. governed_cohere_tool — decorator for Cohere-backed functions:

    @governed_cohere_tool(rzv=rzv, action="DOCUMENT_RERANK")
    def rerank_documents(query: str, docs: list) -> list:
        return co.rerank(query=query, documents=docs, model="rerank-v3.5")
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError

F = TypeVar("F", bound=Callable[..., Any])


class GovernedCohereClient:
    """
    Drop-in replacement for cohere.ClientV2 (and legacy cohere.Client).

    Wraps chat(), generate(), embed(), and rerank() with constitutional
    governance. Every call is gated and sealed before execution.
    """

    ADAPTER_ID = "cohere-client"

    def __init__(
        self,
        rzv: RzvClient,
        api_key: Optional[str] = None,
        agent_id: str = "cohere-agent",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
        **cohere_kwargs: Any,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._fail_closed = fail_closed
        self._api_key = api_key
        self._cohere_kwargs = cohere_kwargs
        self.__client: Any = None

    @property
    def _client(self) -> Any:
        if self.__client is None:
            try:
                import cohere
                kwargs = {**self._cohere_kwargs}
                if self._api_key:
                    kwargs["api_key"] = self._api_key
                # Try ClientV2 first (newer), fall back to Client
                try:
                    self.__client = cohere.ClientV2(**kwargs)
                except AttributeError:
                    self.__client = cohere.Client(**kwargs)
            except ImportError:
                raise ImportError(
                    "cohere is required for GovernedCohereClient. "
                    "Install with: pip install cohere"
                )
        return self.__client

    def _gate(self, action: str, payload: Dict[str, Any]) -> None:
        result = self._gov.gate(action=action, payload=payload, agent_id=self._agent_id)
        if result.rejected:
            raise RzvGatewayError(
                f"Cohere call blocked by constitutional gate: "
                f"{result.reason_code} — action={action}"
            )

    def chat(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed chat()."""
        last = messages[-1].get("content", "")[:200] if messages else ""
        self._gate(
            action=action or f"COHERE_{model.upper().replace('-','_')}_CHAT",
            payload={"model": model, "message_count": len(messages), "last_preview": last},
        )
        return self._client.chat(model=model, messages=messages, **kwargs)

    def generate(
        self,
        prompt: str,
        *,
        model: str = "command-r-plus-08-2024",
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed generate()."""
        self._gate(
            action=action or "COHERE_GENERATE",
            payload={"model": model, "prompt_preview": prompt[:200]},
        )
        return self._client.generate(prompt=prompt, model=model, **kwargs)

    def embed(
        self,
        texts: List[str],
        *,
        model: str = "embed-v4.0",
        input_type: str = "search_document",
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """
        Constitutionally governed embed().

        RAG governance: seals what documents were embedded and when.
        The knowledge ingestion pipeline is part of the governed record.
        """
        self._gate(
            action=action or "COHERE_EMBED",
            payload={
                "model": model,
                "text_count": len(texts),
                "input_type": input_type,
                "first_text_preview": texts[0][:100] if texts else "",
            },
        )
        return self._client.embed(texts=texts, model=model, input_type=input_type, **kwargs)

    def rerank(
        self,
        *,
        query: str,
        documents: List[Any],
        model: str = "rerank-v3.5",
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """
        Constitutionally governed rerank().

        Seals what documents were considered for a query — the
        knowledge selection decision is part of the governed record.
        """
        self._gate(
            action=action or "COHERE_RERANK",
            payload={
                "model": model,
                "query_preview": query[:200],
                "document_count": len(documents),
            },
        )
        return self._client.rerank(query=query, documents=documents, model=model, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class GovernedCohereRAG:
    """
    Constitutional governance for Cohere RAG pipelines.

    Every retrieval and generation step is sealed — the full
    knowledge access chain is provable and tamper-evident.

    This answers the question regulators will eventually ask:
    "What documents did your AI consider when it made this decision?"
    """

    ADAPTER_ID = "cohere-rag"

    def __init__(
        self,
        rzv: RzvClient,
        co: Optional[GovernedCohereClient] = None,
        agent_id: str = "cohere-rag-agent",
        deed_cvid: Optional[str] = None,
    ) -> None:
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._co = co
        self._agent_id = agent_id

    def chat_with_docs(
        self,
        *,
        query: str,
        documents: List[Any],
        model: str = "command-r-plus-08-2024",
        action: str = "COHERE_RAG_CHAT",
        **kwargs: Any,
    ) -> Any:
        """
        Governed RAG chat with document grounding.

        Seals the retrieval context (what docs the model saw)
        alongside the generation — the full RAG chain is provable.
        """
        result = self._gov.gate(
            action=action,
            payload={
                "model": model,
                "query_preview": query[:200],
                "document_count": len(documents),
                "doc_preview": str(documents[0])[:100] if documents else "",
            },
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(f"Cohere RAG blocked: {result.reason_code}")
        if self._co is None:
            raise RuntimeError("GovernedCohereRAG requires a GovernedCohereClient instance")
        return self._co.chat(
            model=model,
            messages=[{"role": "user", "content": query}],
            documents=documents,
            action=action,
            **kwargs,
        )


def governed_cohere_tool(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "cohere-tool",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """Decorator for any Cohere-backed function."""
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if rzv is None:
                return func(*args, **kwargs)
            gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
            result = gov.gate(
                action=action or f"COHERE_{func.__name__.upper()}",
                payload={"function": func.__name__},
                agent_id=agent_id,
            )
            if result.rejected and fail_closed:
                raise RzvGatewayError(f"Cohere tool blocked: {result.reason_code}")
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]
    if fn is not None:
        return decorator(fn)
    return decorator
