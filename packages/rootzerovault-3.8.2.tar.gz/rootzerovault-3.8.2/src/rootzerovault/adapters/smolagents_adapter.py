"""
smolagents adapter — constitutional governance for Hugging Face smolagents.

smolagents is the Hugging Face minimal framework for code-centric agents —
agents that write and execute Python code to solve problems. This is the
highest-risk agent type: unrestricted code execution.

RSBIS governance is especially critical here. An agent that can write
and run arbitrary Python has no natural permission boundary. The
constitutional gate provides that boundary before any code runs.

Two patterns:

1. GovernedSmolTool — base class for governed smolagents tools:

    from rootzerovault.adapters.smolagents_adapter import GovernedSmolTool

    class SearchTool(GovernedSmolTool):
        name = "web_search"
        description = "Search the web"
        inputs = {"query": {"type": "string", "description": "Search query"}}
        output_type = "string"
        rzv_client = rzv
        rzv_agent_id = "smol-agent"

        def forward(self, query: str) -> str:
            return search(query)

2. governed_smol_tool — wrap any existing smolagents tool:

    from rootzerovault.adapters.smolagents_adapter import governed_smol_tool

    governed = governed_smol_tool(my_tool, rzv=rzv)

Code execution governance:
    Code-writing agents (CodeAgent) are the highest-risk agent type.
    Every tool call made by a CodeAgent is constitutionally gated.
    The agent cannot execute code that calls a blocked tool.
"""

from __future__ import annotations

import functools
from typing import Any, Dict, Optional

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError


# ── GovernedSmolTool — base class ─────────────────────────────────────────────

def _make_governed_smol_tool() -> Any:
    try:
        from smolagents import Tool as SmolTool

        class GovernedSmolTool(SmolTool):
            """
            smolagents Tool subclass with constitutional governance.

            Override forward() to implement tool logic. The gate runs
            automatically before forward() is called via __call__().

            Example
            -------
            class WebSearch(GovernedSmolTool):
                name = "web_search"
                description = "Search the web for information"
                inputs = {"query": {"type": "string", "description": "query"}}
                output_type = "string"
                rzv_client = RzvClient(gateway="http://localhost:8443")
                rzv_agent_id = "search-agent"

                def forward(self, query: str) -> str:
                    return search_engine(query)
            """

            rzv_client: Optional[Any] = None
            rzv_agent_id: str = "smol-agent"
            rzv_deed_cvid: Optional[str] = None
            rzv_action: Optional[str] = None
            rzv_fail_closed: bool = True

            def _get_gov(self) -> GovernanceClient:
                return GovernanceClient(
                    self.rzv_client or RzvClient(),
                    deed_cvid=self.rzv_deed_cvid,
                )

            def __call__(self, *args: Any, **kwargs: Any) -> Any:
                """Gate before executing the tool."""
                gov = self._get_gov()
                tool_name = getattr(self, 'name', type(self).__name__)
                gate_action = self.rzv_action or f"SMOL_TOOL_{tool_name.upper().replace('-', '_')}"

                payload: Dict[str, Any] = {"tool": tool_name}
                if args:
                    payload["args"] = str(args)[:200]
                payload.update({k: str(v)[:100] for k, v in kwargs.items()})

                gate_result = gov.gate(
                    action=gate_action,
                    payload=payload,
                    agent_id=self.rzv_agent_id,
                )
                if gate_result.rejected:
                    raise RzvGatewayError(
                        f"Constitutional gate blocked smolagents tool '{tool_name}': "
                        f"{gate_result.reason_code} (cvid={gate_result.cvid})"
                    )

                return super().__call__(*args, **kwargs)

            def forward(self, *args: Any, **kwargs: Any) -> Any:
                raise NotImplementedError(
                    f"{type(self).__name__} must implement forward()"
                )

        return GovernedSmolTool

    except ImportError:
        return None


GovernedSmolTool = _make_governed_smol_tool()


# ── governed_smol_tool — wrap existing tool ───────────────────────────────────

def governed_smol_tool(
    tool: Any,
    rzv: RzvClient,
    action: Optional[str] = None,
    agent_id: str = "smol-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Wrap any existing smolagents Tool with constitutional governance.

    Patches the tool's __call__ method to evaluate the constitutional
    gate before forward() executes.

    Parameters
    ----------
    tool : Tool
        Any smolagents Tool instance.
    rzv : RzvClient
        Root Zero Vault client.
    action : str, optional
        Gate action. Defaults to "SMOL_TOOL_{TOOL_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = REJECT (default True).

    Returns
    -------
    Tool
        Same tool with __call__ patched for constitutional governance.

    Example
    -------
    from smolagents import DuckDuckGoSearchTool
    governed = governed_smol_tool(DuckDuckGoSearchTool(), rzv=rzv)
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
    tool_name = getattr(tool, 'name', type(tool).__name__)
    gate_action = action or f"SMOL_TOOL_{tool_name.upper().replace('-', '_')}"
    original_call = tool.__class__.__call__

    @functools.wraps(original_call)
    def governed_call(self_tool: Any, *args: Any, **kwargs: Any) -> Any:
        payload: Dict[str, Any] = {"tool": tool_name}
        if args:
            payload["args"] = str(args)[:200]
        payload.update({k: str(v)[:100] for k, v in kwargs.items()})

        gate_result = gov.gate(
            action=gate_action,
            payload=payload,
            agent_id=agent_id,
        )
        if gate_result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked smolagents tool '{tool_name}': "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )
        return original_call(self_tool, *args, **kwargs)

    # Patch forward() — smolagents __call__ delegates to forward()
    # Instance-level __call__ patch doesn't intercept class dispatch
    original_forward = tool.forward

    @functools.wraps(original_forward)
    def governed_forward(*args: Any, **kwargs: Any) -> Any:
        payload: Dict[str, Any] = {"tool": tool_name}
        if args:
            payload["args"] = str(args)[:200]
        payload.update({k: str(v)[:100] for k, v in kwargs.items()})

        gate_result = gov.gate(
            action=gate_action,
            payload=payload,
            agent_id=agent_id,
        )
        if gate_result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked smolagents tool '{tool_name}': "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )
        return original_forward(*args, **kwargs)

    tool.forward = governed_forward
    tool._rzv_governed = True
    tool._rzv_action = gate_action
    return tool
