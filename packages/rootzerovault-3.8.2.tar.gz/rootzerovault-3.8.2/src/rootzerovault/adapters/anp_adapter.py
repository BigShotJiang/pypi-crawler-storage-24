"""
ANP adapter — constitutional governance for Agent Network Protocol.

Every interface call and tool execution through ANP is evaluated by
the RSBIS constitutional gate before execution. Fail-closed.

ANP is positioned as "the HTTP of the agentic web" — DID-based
identity, meta-protocol negotiation, and application-layer capability
discovery. Backed by China Mobile, China Telecom, China Unicom,
Huawei, and now an active IETF Internet-Draft.

Particularly strategic for Egypt — ANP's IETF backing and Chinese
telco support means it will be the standard for MENA/Belt-and-Road
AI infrastructure. An RSBIS ANP adapter positions Root Zero Vault
as the constitutional trust layer for this entire ecosystem.

Three patterns:

1. GovernedANPAgent — server-side governed agent:

    from rootzerovault.adapters.anp_adapter import GovernedANPAgent, governed_interface

    @anp_agent(AgentConfig(name="Ministry Agent", did="did:wba:mcit.gov.eg:ai"))
    class MinistryAgent(GovernedANPAgent):
        rzv_client = rzv
        rzv_agent_id = "EGYPT0-anp-agent"

        @governed_interface
        async def process_directive(self, directive: str) -> dict:
            return await execute_directive(directive)

2. GovernedANPCrawler — client-side governed tool execution:

    from rootzerovault.adapters.anp_adapter import GovernedANPCrawler

    crawler = GovernedANPCrawler(
        did_document_path="did.json",
        private_key_path="key.pem",
        rzv=rzv,
        agent_id="egypt-crawler",
    )
    result = await crawler.execute_tool_call("transfer_funds", {"amount": 100_000})

3. governed_interface — decorator for any ANP interface method:

    from rootzerovault.adapters.anp_adapter import governed_interface

    class MyAgent:
        @governed_interface(rzv=rzv, action="PROCESS_REQUEST")
        async def process(self, request: str) -> str:
            return await handle(request)

Egypt deployment:
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    crawler = GovernedANPCrawler(did_path, key_path, rzv=rzv, agent_id="EGYPT0-anp")
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError
from .mcp_adapter import _build_payload

F = TypeVar("F", bound=Callable[..., Any])


# ── governed_interface — decorator for ANP interface methods ─────────────────

def governed_interface(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "anp-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Decorator that gates any ANP @interface method constitutionally.

    Works both as a bare decorator and with arguments:

    # Bare — picks up rzv from self.rzv_client if available
    @governed_interface
    async def my_method(self, x: str) -> str: ...

    # With args
    @governed_interface(rzv=rzv, action="PROCESS_DIRECTIVE")
    async def process(self, directive: str) -> dict: ...

    Parameters
    ----------
    fn : callable, optional
        The function to decorate (when used as bare decorator).
    rzv : RzvClient, optional
        Root Zero Vault client. If None, uses self.rzv_client.
    action : str, optional
        Gate action type. Defaults to "ANP_IFACE_{METHOD_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = REJECT (default True).
    """
    def decorator(f: F) -> F:
        gate_action = action or f"ANP_IFACE_{f.__name__.upper()}"
        _gov_cache: Dict[int, GovernanceClient] = {}

        @functools.wraps(f)
        async def wrapper(self_or_first: Any, *args: Any, **kwargs: Any) -> Any:
            # Resolve GovernanceClient — from decorator arg or from self
            gov: Optional[GovernanceClient] = None
            if rzv is not None:
                gov_key = id(rzv)
                if gov_key not in _gov_cache:
                    _gov_cache[gov_key] = GovernanceClient(rzv, deed_cvid=deed_cvid)
                gov = _gov_cache[gov_key]
            elif hasattr(self_or_first, 'rzv_client') and self_or_first.rzv_client is not None:
                client = self_or_first.rzv_client
                gov_key = id(client)
                if gov_key not in _gov_cache:
                    _gov_cache[gov_key] = GovernanceClient(
                        client,
                        deed_cvid=getattr(self_or_first, 'rzv_deed_cvid', deed_cvid),
                    )
                gov = _gov_cache[gov_key]
            else:
                gov = GovernanceClient(RzvClient())  # demo mode

            effective_agent_id = (
                agent_id
                if agent_id != "anp-agent"
                else getattr(self_or_first, 'rzv_agent_id', agent_id)
            )

            # Build payload
            payload = _build_payload(f, (self_or_first,) + args, kwargs)
            payload['method'] = f.__name__

            # Gate evaluation
            try:
                gate_result = await gov.gate_async(
                    action=gate_action,
                    payload=payload,
                    agent_id=effective_agent_id,
                )
            except Exception as e:
                if fail_closed:
                    raise RzvGatewayError(
                        f"ANP gate infrastructure error on '{gate_action}': {e}"
                    ) from e
                gate_result = None

            if gate_result is not None and gate_result.rejected:
                raise RzvGatewayError(
                    f"Constitutional gate blocked ANP interface '{f.__name__}': "
                    f"{gate_result.reason_code} (cvid={gate_result.cvid})"
                )

            return await f(self_or_first, *args, **kwargs)

        wrapper._rzv_governed = True  # type: ignore[attr-defined]
        wrapper._rzv_action = gate_action  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    # Support both @governed_interface and @governed_interface(...)
    if fn is not None:
        return decorator(fn)
    return decorator


# ── GovernedANPAgent — server-side base class ─────────────────────────────────

class GovernedANPAgent:
    """
    Base class for ANP agents with constitutional governance.

    Mix this into any ANP agent class to automatically gate all
    @governed_interface methods. Works alongside @anp_agent decorator.

    Example
    -------
    from anp.openanp import anp_agent, interface, AgentConfig
    from rootzerovault.adapters.anp_adapter import GovernedANPAgent, governed_interface

    @anp_agent(AgentConfig(
        name="Ministry Finance Agent",
        did="did:wba:mcit.gov.eg:finance",
        prefix="/finance",
    ))
    class FinanceAgent(GovernedANPAgent):
        rzv_client = RzvClient(gateway="https://vault.mcit.gov.eg")
        rzv_agent_id = "EGYPT0-finance-anp"

        @governed_interface
        @interface
        async def process_payment(self, amount: float, destination: str) -> dict:
            return await execute_payment(amount, destination)

        @governed_interface
        @interface
        async def query_balance(self, account: str) -> dict:
            # Read-only — gate still runs
            return await get_balance(account)

    Agent description includes RSBIS metadata automatically.
    """

    rzv_client: Optional[RzvClient] = None
    rzv_agent_id: str = "anp-agent"
    rzv_deed_cvid: Optional[str] = None

    def get_rzv_metadata(self) -> Dict[str, Any]:
        """Return RSBIS constitutional metadata for the agent description."""
        return {
            "rzv_governed": True,
            "rzv_agent_id": self.rzv_agent_id,
            "rzv_genesis": (
                "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996b"
                "fdefb62aa8a045ccb63158867"
            ),
            "rzv_gate": "18-rule constitutional gate",
            "rzv_chain": "blake3 evidence chain",
        }


# ── GovernedANPCrawler — client-side governed tool execution ─────────────────

class GovernedANPCrawler:
    """
    ANP crawler with constitutional governance on every tool execution.

    Wraps ANPCrawler to gate every execute_tool_call and execute_json_rpc
    before the remote call is made. Constitutional proof travels with
    every outbound request.

    Parameters
    ----------
    did_document_path : str
        Path to DID document JSON file.
    private_key_path : str
        Path to private key PEM file.
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Agent ID for gate journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    cache_enabled : bool
        Enable ANP response caching (default True).

    Example
    -------
    from rootzerovault.adapters.anp_adapter import GovernedANPCrawler

    crawler = GovernedANPCrawler(
        did_document_path="did.json",
        private_key_path="key.pem",
        rzv=RzvClient(gateway="http://localhost:8443"),
        agent_id="egypt-crawler-001",
    )

    # All tool executions are gated before the remote call
    result = await crawler.execute_tool_call("book_hotel", {"city": "Cairo"})
    result = await crawler.execute_json_rpc(
        endpoint="https://bank.example.com/rpc",
        method="transfer",
        params={"amount": 100_000, "to": "ACCOUNT-001"},
    )
    """

    def __init__(
        self,
        did_document_path: str,
        private_key_path: str,
        rzv: RzvClient,
        agent_id: str = "anp-crawler",
        deed_cvid: Optional[str] = None,
        cache_enabled: bool = True,
    ) -> None:
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._did_document_path = did_document_path
        self._private_key_path = private_key_path
        self._cache_enabled = cache_enabled
        self._crawler: Optional[Any] = None

    def _get_crawler(self) -> Any:
        """Lazy-init the underlying ANPCrawler."""
        if self._crawler is None:
            try:
                from anp.anp_crawler import ANPCrawler
                self._crawler = ANPCrawler(
                    did_document_path=self._did_document_path,
                    private_key_path=self._private_key_path,
                    cache_enabled=self._cache_enabled,
                )
            except ImportError:
                raise ImportError("anp package required: pip install rootzerovault[anp]")
        return self._crawler

    async def execute_tool_call(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Gate and execute an ANP tool call.

        The constitutional gate evaluates the tool call before it is
        transmitted to the remote ANP agent.

        Parameters
        ----------
        tool_name : str
            Name of the ANP tool to call.
        arguments : dict
            Tool call arguments.

        Returns
        -------
        dict
            Tool execution result.
        """
        action = f"ANP_TOOL_{tool_name.upper().replace('-', '_').replace('.', '_')}"
        payload = {"tool": tool_name, **{k: str(v)[:100] for k, v in arguments.items()}}

        gate_result = await self._gov.gate_async(
            action=action,
            payload=payload,
            agent_id=self._agent_id,
        )
        if gate_result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked ANP tool '{tool_name}': "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )

        return await self._get_crawler().execute_tool_call(tool_name, arguments)

    async def execute_json_rpc(
        self,
        endpoint: str,
        method: str,
        params: Dict[str, Any],
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Gate and execute an ANP JSON-RPC call.

        Parameters
        ----------
        endpoint : str
            Remote RPC endpoint URL.
        method : str
            RPC method name.
        params : dict
            RPC parameters.
        request_id : str, optional
            Request ID for correlation.
        """
        action = f"ANP_RPC_{method.upper().replace('-', '_').replace('.', '_')}"
        payload = {
            "endpoint": endpoint[:100],
            "method": method,
            **{k: str(v)[:100] for k, v in params.items()},
        }

        gate_result = await self._gov.gate_async(
            action=action,
            payload=payload,
            agent_id=self._agent_id,
        )
        if gate_result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked ANP RPC '{method}': "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )

        return await self._get_crawler().execute_json_rpc(
            endpoint=endpoint,
            method=method,
            params=params,
            request_id=request_id,
        )

    async def fetch_text(self, url: str) -> Any:
        """Fetch an ANP agent description document (ungated — read-only discovery)."""
        return await self._get_crawler().fetch_text(url)

    async def list_available_tools(self) -> Any:
        """List available tools (ungated — read-only discovery)."""
        return self._get_crawler().list_available_tools()

    def __getattr__(self, name: str) -> Any:
        """Pass through to underlying ANPCrawler."""
        return getattr(self._get_crawler(), name)

    @property
    def gov(self) -> GovernanceClient:
        return self._gov
