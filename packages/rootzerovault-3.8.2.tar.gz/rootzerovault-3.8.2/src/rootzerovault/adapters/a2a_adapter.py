"""
A2A adapter — constitutional governance for Agent2Agent Protocol.

Every task submitted to an A2A agent is evaluated by the RSBIS
constitutional gate before execution. The gate runs before any
task is accepted. Fail-closed.

The A2A protocol enables agent-to-agent communication across
enterprise systems (Salesforce, SAP, ServiceNow, Workday, etc.)
backed by 150+ organizations under Linux Foundation governance.

RSBIS wraps A2A at the task level — the natural constitutional
boundary. Every task has a declared intent, a payload, and a
context. All three are canonicalized and evaluated before the
task executes.

Three patterns:

1. GovernedA2AAgent — wrap any A2A agent with constitutional governance:

    from rootzerovault.adapters.a2a_adapter import GovernedA2AAgent

    class MyAgent(GovernedA2AAgent):
        rzv_client = rzv
        rzv_agent_id = "my-a2a-agent"

        async def execute_task(self, task):
            # Gate is called automatically before this runs
            return await do_work(task)

2. governed_a2a_agent — wrap an existing A2A agent instance:

    from rootzerovault.adapters.a2a_adapter import governed_a2a_agent
    governed = governed_a2a_agent(my_agent, rzv=rzv)

3. GovernedA2AClient — gate outbound task submissions:

    from rootzerovault.adapters.a2a_adapter import GovernedA2AClient
    client = GovernedA2AClient(base_client, rzv=rzv)
    response = await client.send_message(request)

AI-to-AI constitutional relay attack protection:
    When Agent A delegates a task to Agent B via A2A, each task
    is independently evaluated by the constitutional gate.
    Agent B cannot accept a task that exceeds its constitutional
    permission envelope — even if Agent A is fully authorized.
    Relay attacks are structurally impossible.

Egypt deployment:
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    agent = GovernedA2AAgent(rzv_client=rzv, rzv_agent_id="EGYPT0-a2a-001")
"""

from __future__ import annotations

import json
import uuid
from typing import Any, AsyncIterator, Dict, List, Optional, Union

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError


# ── GovernedA2AAgent — server-side governance ─────────────────────────────────

class GovernedA2AAgent:
    """
    A2A agent base class with constitutional governance on every task.

    Subclass this instead of implementing A2A server directly.
    Every task submitted to this agent is evaluated by the RSBIS
    constitutional gate before execute_task() is called.

    Parameters
    ----------
    rzv_client : RzvClient
        Root Zero Vault client.
    rzv_agent_id : str
        Agent ID for gate journal entries.
    rzv_deed_cvid : str, optional
        Governing deed CVID.
    rzv_fail_closed : bool
        Infrastructure errors = REJECT (default True).

    Example
    -------
    class ResearchAgent(GovernedA2AAgent):
        rzv_client = RzvClient(gateway="http://localhost:8443")
        rzv_agent_id = "research-agent-001"

        async def execute_task(self, task) -> AsyncIterator:
            # Gate runs automatically before this
            result = await do_research(task)
            yield result
    """

    rzv_client: Optional[RzvClient] = None
    rzv_agent_id: str = "a2a-agent"
    rzv_deed_cvid: Optional[str] = None
    rzv_fail_closed: bool = True

    def __init__(self, **kwargs: Any) -> None:
        for k, v in kwargs.items():
            setattr(self, k, v)
        self._gov = GovernanceClient(
            self.rzv_client or RzvClient(),
            deed_cvid=self.rzv_deed_cvid,
        )

    @property
    def gov(self) -> GovernanceClient:
        return self._gov

    async def on_task(self, task: Any) -> AsyncIterator:
        """
        Called by A2A server for every incoming task.
        Runs the constitutional gate, then delegates to execute_task().
        """
        # Build gate payload from task
        payload = _task_to_payload(task)
        action = _task_to_action(task, self.rzv_agent_id)

        try:
            gate_result = await self._gov.gate_async(
                action=action,
                payload=payload,
                agent_id=self.rzv_agent_id,
            )
        except Exception as e:
            if self.rzv_fail_closed:
                raise RzvGatewayError(
                    f"A2A gate infrastructure error: {e}"
                ) from e
            # fail_open — log and continue
            gate_result = None

        if gate_result is not None and gate_result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked A2A task "
                f"'{getattr(task, 'id', 'unknown')}': "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )

        # Gate accepted — delegate to implementation
        async for event in self.execute_task(task):
            yield event

    async def execute_task(self, task: Any) -> AsyncIterator:
        """
        Override in subclass to implement task logic.
        The gate has already been evaluated before this is called.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement execute_task()"
        )

    def get_agent_card(self) -> Dict[str, Any]:
        """
        Return the A2A AgentCard for this agent.
        Includes RSBIS constitutional governance metadata.
        Override to customize.
        """
        return {
            "name": type(self).__name__,
            "description": f"Constitutionally governed A2A agent (RSBIS)",
            "version": "1.0.0",
            "url": "http://localhost:8000",
            "capabilities": {
                "streaming": True,
                "push_notifications": False,
            },
            "skills": [],
            "metadata": {
                "rzv_governed": True,
                "rzv_agent_id": self.rzv_agent_id,
                "rzv_genesis": (
                    "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996b"
                    "fdefb62aa8a045ccb63158867"
                ),
            },
        }


# ── governed_a2a_agent — wrap existing agent ────────────────────────────────

def governed_a2a_agent(
    agent: Any,
    rzv: RzvClient,
    agent_id: Optional[str] = None,
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Wrap an existing A2A agent with constitutional governance.

    Patches the agent's execute_task / on_message method to run
    the constitutional gate before every task.

    Parameters
    ----------
    agent : A2A agent instance
        Any object with execute_task() or on_message() method.
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str, optional
        Agent ID for gate journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = REJECT (default True).

    Returns
    -------
    agent
        Same agent instance with execute_task patched.

    Example
    -------
    from a2a.server import A2AServer
    governed = governed_a2a_agent(my_server, rzv=rzv)
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
    effective_agent_id = agent_id or getattr(agent, 'agent_id', 'a2a-agent')

    # Find the right method to patch
    method_name = None
    for name in ['execute_task', 'on_message', 'handle_task', 'process_task']:
        if hasattr(agent, name) and callable(getattr(agent, name)):
            method_name = name
            break

    if method_name is None:
        raise ValueError(
            f"Cannot find task method on agent {type(agent).__name__}. "
            f"Expected execute_task, on_message, handle_task, or process_task."
        )

    original_method = getattr(agent, method_name)

    async def governed_method(task: Any, *args: Any, **kwargs: Any) -> Any:
        payload = _task_to_payload(task)
        action = _task_to_action(task, effective_agent_id)

        try:
            gate_result = await gov.gate_async(
                action=action,
                payload=payload,
                agent_id=effective_agent_id,
            )
        except Exception as e:
            if fail_closed:
                raise RzvGatewayError(f"A2A gate error: {e}") from e
            gate_result = None

        if gate_result is not None and gate_result.rejected:
            raise RzvGatewayError(
                f"Gate blocked A2A task: {gate_result.reason_code} "
                f"(cvid={gate_result.cvid})"
            )

        return await original_method(task, *args, **kwargs)

    setattr(agent, method_name, governed_method)
    agent._rzv_governed = True
    agent._rzv_agent_id = effective_agent_id
    return agent


# ── GovernedA2AClient — client-side governance ───────────────────────────────

class GovernedA2AClient:
    """
    A2A client wrapper that gates outbound task submissions.

    Governs tasks before they are sent to remote A2A agents.
    Provides constitutional proof that this client had authority
    to submit each task at the moment it was submitted.

    Parameters
    ----------
    client : A2AClient
        Any A2A client instance (a2a.client.A2AClient or compatible).
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Client agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.

    Example
    -------
    from a2a.client import A2AClient
    from rootzerovault.adapters.a2a_adapter import GovernedA2AClient

    base_client = A2AClient(httpx_client=httpx.AsyncClient(), agent_card=card)
    client = GovernedA2AClient(base_client, rzv=rzv, agent_id="client-001")

    response = await client.send_message(request)
    """

    def __init__(
        self,
        client: Any,
        rzv: RzvClient,
        agent_id: str = "a2a-client",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
    ) -> None:
        self._client = client
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._fail_closed = fail_closed

    async def send_message(self, request: Any, **kwargs: Any) -> Any:
        """
        Gate and send a message to a remote A2A agent.

        The constitutional gate evaluates the outbound message before
        it is transmitted. If rejected, raises RzvGatewayError.
        """
        payload = _request_to_payload(request)
        gate_result = await self._gov.gate_async(
            action="A2A_SEND_MESSAGE",
            payload=payload,
            agent_id=self._agent_id,
        )
        if gate_result.rejected:
            raise RzvGatewayError(
                f"Gate blocked A2A outbound message: "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )
        return await self._client.send_message(request, **kwargs)

    async def send_task(self, task: Any, **kwargs: Any) -> Any:
        """Gate and send a task to a remote A2A agent."""
        payload = _task_to_payload(task)
        action = _task_to_action(task, self._agent_id)
        gate_result = await self._gov.gate_async(
            action=action,
            payload=payload,
            agent_id=self._agent_id,
        )
        if gate_result.rejected:
            raise RzvGatewayError(
                f"Gate blocked A2A task submission: "
                f"{gate_result.reason_code} (cvid={gate_result.cvid})"
            )
        # Delegate to underlying client
        send_fn = getattr(self._client, 'send_task', None) or \
                  getattr(self._client, 'send_message', None)
        if send_fn:
            return await send_fn(task, **kwargs)
        raise AttributeError("A2A client has no send_task or send_message method")

    def __getattr__(self, name: str) -> Any:
        """Pass through any other client methods."""
        return getattr(self._client, name)

    @property
    def gov(self) -> GovernanceClient:
        return self._gov


# ── Helpers ───────────────────────────────────────────────────────────────────

def _task_to_payload(task: Any) -> Dict[str, Any]:
    """Extract gate-evaluable payload from an A2A Task."""
    payload: Dict[str, Any] = {}

    # Task ID
    if hasattr(task, 'id'):
        payload['task_id'] = str(task.id)[:64]

    # Task kind
    if hasattr(task, 'kind'):
        payload['kind'] = str(task.kind)

    # Extract text from message history
    if hasattr(task, 'history') and task.history:
        messages = task.history
        if messages:
            first = messages[0]
            text = _extract_message_text(first)
            if text:
                payload['intent'] = text[:200]

    # Context
    if hasattr(task, 'context_id'):
        payload['context_id'] = str(task.context_id or '')[:64]

    # Metadata
    if hasattr(task, 'metadata') and task.metadata:
        for k, v in (task.metadata or {}).items():
            payload[f'meta_{k}'] = str(v)[:100]

    return payload


def _request_to_payload(request: Any) -> Dict[str, Any]:
    """Extract gate-evaluable payload from an A2A SendMessageRequest."""
    payload: Dict[str, Any] = {}

    msg = getattr(request, 'message', None) or getattr(request, 'params', None)
    if msg is not None:
        # It's a message object
        text = _extract_message_text(msg)
        if text:
            payload['message'] = text[:200]
        role = getattr(msg, 'role', None)
        if role:
            payload['role'] = str(role)
        task_id = getattr(msg, 'task_id', None)
        if task_id:
            payload['task_id'] = str(task_id)[:64]
    else:
        # Fallback — stringify
        payload['request'] = str(request)[:200]

    return payload


def _extract_message_text(message: Any) -> str:
    """Extract text content from an A2A Message."""
    parts = getattr(message, 'parts', []) or []
    texts = []
    for part in parts:
        # TextPart
        text = getattr(part, 'text', None)
        if text:
            texts.append(str(text))
        # Nested root (Part union type)
        root = getattr(part, 'root', None)
        if root:
            text = getattr(root, 'text', None)
            if text:
                texts.append(str(text))
    return " ".join(texts)[:200]


def _task_to_action(task: Any, agent_id: str) -> str:
    """Derive a meaningful gate action name from a task."""
    # Try to get skill from context
    metadata = getattr(task, 'metadata', {}) or {}
    skill = metadata.get('skill') or metadata.get('action')
    if skill:
        return f"A2A_TASK_{str(skill).upper().replace(' ', '_')}"

    # Derive from agent_id
    agent_part = agent_id.upper().replace('-', '_').replace('/', '_')
    return f"A2A_TASK_{agent_part}"
