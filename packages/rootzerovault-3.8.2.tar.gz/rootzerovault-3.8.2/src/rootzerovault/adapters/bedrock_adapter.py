"""
AWS Bedrock adapter — constitutional governance for Amazon Bedrock.

AWS Bedrock is the enterprise production runtime for AI. Claude, Titan,
Llama, Mistral, Cohere — all running inside AWS VPCs, behind IAM, inside
enterprise networks. This is where regulated AI actually runs in production.

Every invoke_model() and invoke_model_with_response_stream() call is
evaluated by the RSBIS constitutional gate before execution. Fail-closed.

Three patterns:

1. GovernedBedrockClient — drop-in replacement for boto3 bedrock-runtime:

    from rootzerovault.adapters.bedrock_adapter import GovernedBedrockClient

    rzv = RzvClient(gateway="http://localhost:8443")
    bedrock = GovernedBedrockClient(rzv=rzv, region_name="us-east-1")

    # Identical API to boto3 — fully governed
    response = bedrock.invoke_model(
        modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
        body=json.dumps({"messages": [...], "max_tokens": 1000}),
    )

2. governed_bedrock_tool — decorator for Bedrock-backed tools:

    from rootzerovault.adapters.bedrock_adapter import governed_bedrock_tool

    @governed_bedrock_tool(rzv=rzv, action="CLINICAL_INFERENCE")
    def run_clinical_model(patient_ref: str, prompt: str) -> dict:
        return bedrock_client.invoke_model(...)

3. GovernedBedrockAgent — Bedrock Agents with constitutional governance:

    from rootzerovault.adapters.bedrock_adapter import GovernedBedrockAgent

    agent = GovernedBedrockAgent(
        rzv=rzv,
        agent_id_bedrock="ABCDEF",
        agent_alias_id="PROD",
        region_name="us-east-1",
    )
    response = agent.invoke(input_text="Summarize patient history for CUH-8847")

Egypt deployment:
    bedrock = GovernedBedrockClient(
        rzv=RzvClient(gateway="https://vault.mcit.gov.eg"),
        region_name="me-south-1",  # Bahrain — closest AWS region to Egypt
        agent_id="EGYPT0-bedrock-001",
    )
"""

from __future__ import annotations

import functools
import json
from typing import Any, Callable, Dict, Iterator, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError

F = TypeVar("F", bound=Callable[..., Any])


def _bedrock_action(model_id: str, action: Optional[str]) -> str:
    """Derive a constitutional action string from a Bedrock model ID."""
    if action:
        return action
    # e.g. anthropic.claude-3-5-sonnet → BEDROCK_ANTHROPIC_CLAUDE
    vendor = model_id.split(".")[0].upper() if "." in model_id else "BEDROCK"
    short = model_id.split(".")[1].split("-")[0].upper() if "." in model_id else model_id.upper()
    return f"BEDROCK_{vendor}_{short}_INVOKE"


# ── GovernedBedrockClient ─────────────────────────────────────────────────────

class GovernedBedrockClient:
    """
    Drop-in replacement for boto3.client("bedrock-runtime").

    Wraps invoke_model() and invoke_model_with_response_stream() with
    constitutional governance. Every model invocation is gated and sealed
    before execution.

    Parameters
    ----------
    rzv : RzvClient
        Configured Root Zero Vault client.
    region_name : str
        AWS region (default: us-east-1).
    agent_id : str
        RSBIS agent identifier for this client.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        If True (default), block on gate errors. Never silently pass.
    boto3_kwargs : dict
        Additional kwargs passed to boto3.client().
    """

    ADAPTER_ID = "bedrock-runtime"

    def __init__(
        self,
        rzv: RzvClient,
        region_name: str = "us-east-1",
        agent_id: str = "bedrock-agent",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
        **boto3_kwargs: Any,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._fail_closed = fail_closed
        self._region = region_name
        self._boto3_kwargs = boto3_kwargs
        self.__client: Any = None

    @property
    def _client(self) -> Any:
        """Lazy boto3 client — only imported if actually used."""
        if self.__client is None:
            try:
                import boto3
                self.__client = boto3.client(
                    "bedrock-runtime",
                    region_name=self._region,
                    **self._boto3_kwargs,
                )
            except ImportError:
                raise ImportError(
                    "boto3 is required for GovernedBedrockClient. "
                    "Install with: pip install boto3"
                )
        return self.__client

    def _gate(self, model_id: str, action: Optional[str], body: Any) -> None:
        """Evaluate through constitutional gate. Raises on BLOCK."""
        action_str = _bedrock_action(model_id, action)
        try:
            body_dict = json.loads(body) if isinstance(body, (str, bytes)) else body
        except Exception:
            body_dict = {"raw": str(body)[:200]}

        result = self._gov.gate(
            action=action_str,
            payload={
                "model_id": model_id,
                "region": self._region,
                "agent_id": self._agent_id,
                "body_preview": {k: v for k, v in body_dict.items()
                                 if k in ("messages", "prompt", "inputText",
                                          "max_tokens", "maxTokens", "temperature")},
            },
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Bedrock invoke blocked by constitutional gate: "
                f"{result.reason_code} — model={model_id}"
            )

    def invoke_model(
        self,
        *,
        modelId: str,
        body: Any,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Constitutionally governed invoke_model().

        Identical signature to boto3 bedrock-runtime.invoke_model().
        Gate evaluates before the AWS API call. Fail-closed.
        """
        self._gate(modelId, action, body)
        return self._client.invoke_model(modelId=modelId, body=body, **kwargs)

    def invoke_model_with_response_stream(
        self,
        *,
        modelId: str,
        body: Any,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """
        Constitutionally governed invoke_model_with_response_stream().

        Gate evaluates before streaming begins. If blocked, raises before
        any tokens are returned.
        """
        self._gate(modelId, action, body)
        return self._client.invoke_model_with_response_stream(
            modelId=modelId, body=body, **kwargs
        )

    def converse(
        self,
        *,
        modelId: str,
        messages: list,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Constitutionally governed Converse API (Bedrock unified chat API).
        """
        self._gate(modelId, action, json.dumps({"messages": messages}))
        return self._client.converse(modelId=modelId, messages=messages, **kwargs)

    def converse_stream(
        self,
        *,
        modelId: str,
        messages: list,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed converse_stream()."""
        self._gate(modelId, action, json.dumps({"messages": messages}))
        return self._client.converse_stream(modelId=modelId, messages=messages, **kwargs)


# ── GovernedBedrockAgent ──────────────────────────────────────────────────────

class GovernedBedrockAgent:
    """
    Constitutional governance for AWS Bedrock Agents.

    Wraps bedrock-agent-runtime invoke_agent() calls.
    Every agent invocation is gated before execution.
    """

    ADAPTER_ID = "bedrock-agent"

    def __init__(
        self,
        rzv: RzvClient,
        agent_id_bedrock: str,
        agent_alias_id: str,
        region_name: str = "us-east-1",
        rzbis_agent_id: str = "bedrock-agent",
        deed_cvid: Optional[str] = None,
        **boto3_kwargs: Any,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._bedrock_agent_id = agent_id_bedrock
        self._alias_id = agent_alias_id
        self._rzbis_agent_id = rzbis_agent_id
        self._region = region_name
        self._boto3_kwargs = boto3_kwargs
        self.__client: Any = None

    @property
    def _client(self) -> Any:
        if self.__client is None:
            try:
                import boto3
                self.__client = boto3.client(
                    "bedrock-agent-runtime",
                    region_name=self._region,
                    **self._boto3_kwargs,
                )
            except ImportError:
                raise ImportError("boto3 is required. Install with: pip install boto3")
        return self.__client

    def invoke(
        self,
        input_text: str,
        session_id: Optional[str] = None,
        action: str = "BEDROCK_AGENT_INVOKE",
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed Bedrock Agent invocation."""
        import uuid
        sid = session_id or str(uuid.uuid4())

        result = self._gov.gate(
            action=action,
            payload={
                "bedrock_agent_id": self._bedrock_agent_id,
                "alias_id": self._alias_id,
                "session_id": sid,
                "input_preview": input_text[:200],
            },
            agent_id=self._rzbis_agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Bedrock Agent invoke blocked: {result.reason_code}"
            )

        return self._client.invoke_agent(
            agentId=self._bedrock_agent_id,
            agentAliasId=self._alias_id,
            sessionId=sid,
            inputText=input_text,
            **kwargs,
        )


# ── governed_bedrock_tool — decorator ────────────────────────────────────────

def governed_bedrock_tool(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "bedrock-tool",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Decorator for any function that calls Bedrock.

    Evaluates the constitutional gate before the function executes.
    Use for Bedrock-backed tools in any framework.

        @governed_bedrock_tool(rzv=rzv, action="CLINICAL_INFERENCE")
        def run_clinical_model(patient_ref: str, prompt: str) -> dict:
            return bedrock_client.invoke_model(...)
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if rzv is None:
                return func(*args, **kwargs)
            gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
            action_str = action or f"BEDROCK_{func.__name__.upper()}"
            result = gov.gate(
                action=action_str,
                payload={"function": func.__name__, "args_count": len(args)},
                agent_id=agent_id,
            )
            if result.rejected:
                if fail_closed:
                    raise RzvGatewayError(
                        f"Bedrock tool blocked: {result.reason_code}"
                    )
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]

    if fn is not None:
        return decorator(fn)
    return decorator
