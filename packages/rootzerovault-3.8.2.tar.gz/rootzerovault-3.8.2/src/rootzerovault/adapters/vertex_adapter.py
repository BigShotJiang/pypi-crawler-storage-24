"""
Google Vertex AI adapter — constitutional governance for Vertex AI.

Vertex AI is Google's enterprise AI platform — Gemini, PaLM, and
third-party models running inside Google Cloud. Enterprise alternative
to Bedrock for organizations standardized on GCP.

Every GenerativeModel.generate_content() and predict() call is
evaluated by the RSBIS constitutional gate before execution. Fail-closed.

Three patterns:

1. GovernedVertexModel — drop-in for vertexai.generative_models.GenerativeModel:

    from rootzerovault.adapters.vertex_adapter import GovernedVertexModel

    rzv = RzvClient(gateway="http://localhost:8443")
    model = GovernedVertexModel(
        model_name="gemini-2.0-flash-001",
        rzv=rzv,
        project="my-gcp-project",
        location="us-central1",
    )
    response = model.generate_content("Summarize patient record CUH-8847")

2. GovernedVertexEndpoint — wrap a deployed Vertex AI endpoint:

    from rootzerovault.adapters.vertex_adapter import GovernedVertexEndpoint

    endpoint = GovernedVertexEndpoint(
        endpoint_name="projects/123/locations/us-central1/endpoints/456",
        rzv=rzv,
    )
    prediction = endpoint.predict(instances=[{"input": "..."}])

3. governed_vertex_tool — decorator for Vertex-backed functions:

    @governed_vertex_tool(rzv=rzv, action="REGULATORY_ANALYSIS")
    def analyze_regulation(text: str) -> dict:
        return model.generate_content(text)
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError

F = TypeVar("F", bound=Callable[..., Any])


class GovernedVertexModel:
    """
    Drop-in replacement for vertexai.generative_models.GenerativeModel.

    Every generate_content() call — sync and async, streaming and non-streaming —
    is evaluated through the constitutional gate before execution.
    """

    ADAPTER_ID = "vertex-generative-model"

    def __init__(
        self,
        model_name: str,
        rzv: RzvClient,
        project: Optional[str] = None,
        location: str = "us-central1",
        agent_id: str = "vertex-agent",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
        **model_kwargs: Any,
    ) -> None:
        self._model_name = model_name
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._project = project
        self._location = location
        self._agent_id = agent_id
        self._fail_closed = fail_closed
        self._model_kwargs = model_kwargs
        self.__model: Any = None

    @property
    def _model(self) -> Any:
        if self.__model is None:
            try:
                import vertexai
                from vertexai.generative_models import GenerativeModel
                if self._project:
                    vertexai.init(project=self._project, location=self._location)
                self.__model = GenerativeModel(self._model_name, **self._model_kwargs)
            except ImportError:
                raise ImportError(
                    "google-cloud-aiplatform is required for GovernedVertexModel. "
                    "Install with: pip install google-cloud-aiplatform"
                )
        return self.__model

    def _gate(self, contents: Any, action: Optional[str] = None) -> None:
        action_str = action or f"VERTEX_{self._model_name.upper().replace('-','_').replace('.','_')}_GENERATE"
        preview = str(contents)[:200] if not isinstance(contents, list) else str(contents[0])[:200]
        result = self._gov.gate(
            action=action_str,
            payload={
                "model_name": self._model_name,
                "location": self._location,
                "project": self._project,
                "content_preview": preview,
            },
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Vertex AI generate blocked by constitutional gate: "
                f"{result.reason_code} — model={self._model_name}"
            )

    def generate_content(
        self,
        contents: Any,
        *,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed generate_content()."""
        self._gate(contents, action)
        return self._model.generate_content(contents, **kwargs)

    async def generate_content_async(
        self,
        contents: Any,
        *,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Async constitutionally governed generate_content()."""
        self._gate(contents, action)
        return await self._model.generate_content_async(contents, **kwargs)

    def start_chat(self, **kwargs: Any) -> "GovernedVertexChat":
        """Return a governed chat session."""
        return GovernedVertexChat(
            model=self,
            chat=self._model.start_chat(**kwargs),
        )


class GovernedVertexChat:
    """Governed Vertex AI chat session — gates every send_message()."""

    def __init__(self, model: GovernedVertexModel, chat: Any) -> None:
        self._model = model
        self._chat = chat

    def send_message(self, content: Any, action: Optional[str] = None, **kwargs: Any) -> Any:
        self._model._gate(content, action or "VERTEX_CHAT_SEND_MESSAGE")
        return self._chat.send_message(content, **kwargs)

    async def send_message_async(self, content: Any, action: Optional[str] = None, **kwargs: Any) -> Any:
        self._model._gate(content, action or "VERTEX_CHAT_SEND_MESSAGE")
        return await self._chat.send_message_async(content, **kwargs)


class GovernedVertexEndpoint:
    """
    Constitutional governance for deployed Vertex AI endpoints.

    Wraps Vertex AI Endpoint.predict() for custom-trained models.
    """

    ADAPTER_ID = "vertex-endpoint"

    def __init__(
        self,
        endpoint_name: str,
        rzv: RzvClient,
        agent_id: str = "vertex-endpoint-agent",
        deed_cvid: Optional[str] = None,
    ) -> None:
        self._endpoint_name = endpoint_name
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self.__endpoint: Any = None

    @property
    def _endpoint(self) -> Any:
        if self.__endpoint is None:
            try:
                from google.cloud import aiplatform
                self.__endpoint = aiplatform.Endpoint(self._endpoint_name)
            except ImportError:
                raise ImportError(
                    "google-cloud-aiplatform is required. "
                    "Install with: pip install google-cloud-aiplatform"
                )
        return self.__endpoint

    def predict(
        self,
        instances: List[Any],
        action: str = "VERTEX_ENDPOINT_PREDICT",
        **kwargs: Any,
    ) -> Any:
        result = self._gov.gate(
            action=action,
            payload={"endpoint": self._endpoint_name, "instance_count": len(instances)},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(f"Vertex endpoint predict blocked: {result.reason_code}")
        return self._endpoint.predict(instances=instances, **kwargs)


def governed_vertex_tool(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "vertex-tool",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """Decorator for any Vertex AI-backed function."""
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if rzv is None:
                return func(*args, **kwargs)
            gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
            result = gov.gate(
                action=action or f"VERTEX_{func.__name__.upper()}",
                payload={"function": func.__name__},
                agent_id=agent_id,
            )
            if result.rejected and fail_closed:
                raise RzvGatewayError(f"Vertex tool blocked: {result.reason_code}")
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]
    if fn is not None:
        return decorator(fn)
    return decorator
