"""
BaseAdapter — Abstract base class for all Faramesh constitutional adapters.

To build a new adapter:

    from rootzerovault.adapters import BaseAdapter
    from rootzerovault.governance import GateAction

    class MySalesforceAdapter(BaseAdapter):
        ADAPTER_ID = "salesforce-v1"

        def create_opportunity(self, name: str, amount: float) -> dict:
            # 1. Gate the action
            result = self.gate(
                action="CRM_CREATE_OPPORTUNITY",
                payload={"name": name, "amount": amount},
            )
            result.assert_accepted()

            # 2. Execute via Salesforce API
            return self._sf_client.create("Opportunity", {
                "Name": name, "Amount": amount
            })
"""

from __future__ import annotations

from abc import ABC
from typing import Any, Dict, Optional

from ..client import RzvClient
from ..governance import GovernanceClient, GateAction


class BaseAdapter(ABC):
    """
    Abstract base class for all Faramesh constitutional adapters.

    Subclass this to wrap any third-party system with constitutional
    governance. Every action goes through the gate before execution.

    Parameters
    ----------
    rzv : RzvClient
        Configured Root Zero Vault client.
    deed_cvid : str, optional
        Governing deed CVID for this adapter instance.
    adapter_id : str, optional
        Override the adapter identifier for chain entries.
    """

    #: Override in subclass — identifies this adapter in chain entries
    ADAPTER_ID: str = "base-adapter"

    def __init__(
        self,
        rzv: RzvClient,
        deed_cvid: Optional[str] = None,
        adapter_id: Optional[str] = None,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._adapter_id = adapter_id or self.ADAPTER_ID

    @property
    def is_live(self) -> bool:
        """True if connected to a real gateway."""
        return self._gov.is_live

    @property
    def gov(self) -> GovernanceClient:
        """Direct access to the GovernanceClient for advanced usage."""
        return self._gov

    def gate(
        self,
        action: str,
        payload: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
    ) -> GateAction:
        """
        Evaluate an action through the constitutional gate.

        Call this before every action your adapter takes. The gate
        is fail-closed — any infrastructure error returns REJECT.

        Parameters
        ----------
        action : str
            Action type. Use SCREAMING_SNAKE_CASE by convention.
            Examples: "CRM_CREATE_LEAD", "EHR_UPDATE_PATIENT", "FIN_TRANSFER"
        payload : dict, optional
            Action payload for constitutional evaluation.
        correlation_id : str, optional
            Correlation ID for the journal entry.

        Returns
        -------
        GateAction
            Call .assert_accepted() to raise on rejection,
            or check .accepted / .rejected manually.
        """
        return self._gov.gate(
            action=action,
            payload=payload,
            agent_id=self._adapter_id,
            correlation_id=correlation_id,
        )

    def seal(
        self,
        event_type: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Seal a custom event to the evidence chain.

        Returns the CVID of the sealed entry.
        """
        entry = self._gov.append_chain(
            event_type=f"{self._adapter_id.upper()}_{event_type}",
            payload=payload,
        )
        return entry.cvid
