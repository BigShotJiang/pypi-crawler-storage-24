"""
ACP adapter — constitutional governance for Agent Communication Protocol.

ACP (IBM/BeeAI, Linux Foundation) is the local-first agent communication
standard — optimized for on-premise clusters, edge devices, and air-gapped
environments. REST-based, no SDK required, works offline.

Every message handled by an ACP agent is evaluated by the RSBIS
constitutional gate before execution. Fail-closed.

Three patterns:

1. governed_acp_agent — decorator for ACP server agents:

    from acp_sdk.server import Server
    from rootzerovault.adapters.acp_adapter import governed_acp_agent

    server = Server()
    rzv = RzvClient(gateway="http://localhost:8443")

    @server.agent
    @governed_acp_agent(rzv=rzv, agent_id="my-acp-agent")
    async def my_agent(input, context):
        yield MessagePart(content="result")

2. GovernedACPServer — server with governance built in:

    from rootzerovault.adapters.acp_adapter import GovernedACPServer

    server = GovernedACPServer(rzv=rzv, agent_id="egypt-acp")

    @server.governed_agent
    async def ministry_agent(input, context):
        yield MessagePart(content=await process(input))

3. governed_acp_run — gate before running an ACP agent run:

    from rootzerovault.adapters.acp_adapter import governed_acp_run

    result = await governed_acp_run(
        client=acp_client,
        agent="ministry_agent",
        input=messages,
        rzv=rzv,
    )

Egypt / Edge deployment:
    # ACP is local-first — perfect for air-gapped government deployments
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    # Or offline mode — no gateway needed
    rzv = RzvClient()  # demo/offline constitutional gate
"""

from __future__ import annotations

import functools
from typing import Any, AsyncIterator, Dict, List, Optional

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError


# ── governed_acp_agent — decorator for ACP agent functions ───────────────────

def governed_acp_agent(
    fn: Optional[Any] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "acp-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Decorator that gates any ACP agent function constitutionally.

    Apply before or after @server.agent. Every message is evaluated
    by the constitutional gate before the generator yields.

    Usage:
        @server.agent
        @governed_acp_agent(rzv=rzv, agent_id="my-agent")
        async def my_agent(input, context):
            yield MessagePart(content="result")

    Parameters
    ----------
    fn : callable, optional
        The agent function (when used as bare decorator).
    rzv : RzvClient, optional
        Root Zero Vault client. Defaults to demo mode.
    action : str, optional
        Gate action. Defaults to "ACP_AGENT_{FUNCTION_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = REJECT (default True).
    """
    def decorator(f: Any) -> Any:
        gate_action = action or f"ACP_AGENT_{f.__name__.upper()}"
        gov = GovernanceClient(rzv or RzvClient(), deed_cvid=deed_cvid)

        @functools.wraps(f)
        async def wrapper(input: Any, context: Any = None, *args: Any, **kwargs: Any) -> AsyncIterator:
            # Extract payload from ACP input (list of Messages)
            payload = _acp_input_to_payload(input, gate_action)

            try:
                gate_result = await gov.gate_async(
                    action=gate_action,
                    payload=payload,
                    agent_id=agent_id,
                )
            except Exception as e:
                if fail_closed:
                    raise RzvGatewayError(
                        f"ACP gate infrastructure error on '{gate_action}': {e}"
                    ) from e
                gate_result = None

            if gate_result is not None and gate_result.rejected:
                raise RzvGatewayError(
                    f"Constitutional gate blocked ACP agent '{f.__name__}': "
                    f"{gate_result.reason_code} (cvid={gate_result.cvid})"
                )

            async for event in f(input, context, *args, **kwargs):
                yield event

        wrapper._rzv_governed = True
        wrapper._rzv_action = gate_action
        return wrapper

    if fn is not None:
        return decorator(fn)
    return decorator


# ── GovernedACPServer — server with governance built in ──────────────────────

class GovernedACPServer:
    """
    ACP Server with constitutional governance on all agent registrations.

    Drop-in replacement pattern for acp_sdk.server.Server.
    Every agent registered with @governed_agent is gated constitutionally.

    Parameters
    ----------
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Default agent ID for all agents on this server.
    deed_cvid : str, optional
        Governing deed CVID.

    Example
    -------
    server = GovernedACPServer(
        rzv=RzvClient(gateway="http://localhost:8443"),
        agent_id="egypt-ministry-acp",
    )

    @server.governed_agent
    async def budget_agent(input, context):
        yield MessagePart(content=await process_budget(input))

    server.run()
    """

    def __init__(
        self,
        rzv: RzvClient,
        agent_id: str = "acp-server",
        deed_cvid: Optional[str] = None,
    ) -> None:
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._agents: List[Dict[str, Any]] = []
        self._server: Optional[Any] = None

    def _get_server(self) -> Any:
        if self._server is None:
            try:
                from acp_sdk.server import Server
                self._server = Server()
            except ImportError:
                raise ImportError("acp-sdk required: pip install rootzerovault[acp]")
        return self._server

    def governed_agent(
        self,
        fn: Optional[Any] = None,
        *,
        action: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Any:
        """Register an agent with constitutional governance."""
        effective_agent_id = agent_id or self._agent_id

        def decorator(f: Any) -> Any:
            gate_action = action or f"ACP_AGENT_{f.__name__.upper()}"

            @functools.wraps(f)
            async def governed(input: Any, context: Any = None) -> AsyncIterator:
                payload = _acp_input_to_payload(input, gate_action)
                gate_result = await self._gov.gate_async(
                    action=gate_action,
                    payload=payload,
                    agent_id=effective_agent_id,
                )
                if gate_result.rejected:
                    raise RzvGatewayError(
                        f"Gate blocked ACP agent '{f.__name__}': "
                        f"{gate_result.reason_code} (cvid={gate_result.cvid})"
                    )
                async for event in f(input, context):
                    yield event

            governed._rzv_governed = True
            governed._rzv_action = gate_action
            self._agents.append({"name": f.__name__, "action": gate_action, "agent_id": effective_agent_id})

            # Register with underlying ACP server
            self._get_server().agent(governed)
            return governed

        if fn is not None:
            return decorator(fn)
        return decorator

    def run(self, **kwargs: Any) -> None:
        """Start the ACP server."""
        self._get_server().run(**kwargs)

    def list_governed_agents(self) -> List[Dict[str, Any]]:
        return list(self._agents)

    @property
    def gov(self) -> GovernanceClient:
        return self._gov


# ── governed_acp_run — gate outbound ACP client calls ────────────────────────

async def governed_acp_run(
    client: Any,
    agent: str,
    input: Any,
    rzv: RzvClient,
    agent_id: str = "acp-client",
    deed_cvid: Optional[str] = None,
) -> Any:
    """
    Gate and run an ACP agent via client.

    Evaluates the constitutional gate before submitting the run
    to the remote ACP agent. Constitutional proof that this client
    had authority to invoke the agent at this moment.

    Parameters
    ----------
    client : ACP client
        Any ACP client with a run() or run_sync() method.
    agent : str
        Agent name to invoke.
    input : list
        ACP input messages.
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Client agent ID for journal entries.
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
    action = f"ACP_RUN_{agent.upper().replace('-', '_')}"
    payload = _acp_input_to_payload(input, action)
    payload["agent"] = agent

    gate_result = await gov.gate_async(
        action=action,
        payload=payload,
        agent_id=agent_id,
    )
    if gate_result.rejected:
        raise RzvGatewayError(
            f"Constitutional gate blocked ACP run '{agent}': "
            f"{gate_result.reason_code} (cvid={gate_result.cvid})"
        )

    run_fn = getattr(client, 'run_async', None) or getattr(client, 'run', None)
    if run_fn is None:
        raise AttributeError("ACP client has no run or run_async method")
    return await run_fn(agent=agent, input=input)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _acp_input_to_payload(input: Any, action: str) -> Dict[str, Any]:
    """Extract gate-evaluable payload from ACP input messages."""
    payload: Dict[str, Any] = {"action": action}

    if input is None:
        return payload

    messages = input if isinstance(input, list) else [input]
    texts = []
    for msg in messages:
        parts = getattr(msg, 'parts', []) or []
        for part in parts:
            content = getattr(part, 'content', None)
            if content:
                if isinstance(content, (str, bytes)):
                    texts.append(str(content)[:100])
                elif hasattr(content, 'decode'):
                    texts.append(content.decode()[:100])

    if texts:
        payload["content"] = " ".join(texts)[:200]

    return payload
