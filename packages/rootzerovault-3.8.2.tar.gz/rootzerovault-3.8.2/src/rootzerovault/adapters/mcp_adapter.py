"""
GovernedMCPServer — Constitutional governance for MCP tool calls.

Every tool call through this server is evaluated by the RSBIS constitutional
gate before execution. The gate uses the full 9-step pipeline from
rsbis-agent-gate:

  MCP tool call
    → [1] Agent identity verified
    → [2] Permission envelope checked
    → [3–5] Co-sign / payload integrity
    → [6] 18-rule constitutional gate (rsbis-validate)
    → [7] Artifact binding check
    → [8] Fail-closed guard — ACCEPT or BLOCK
    → [9] CVID-stamped, sealed to journal
    → Execute (ACCEPT) | Raise (BLOCK)

Usage — governed MCP server:

    from rootzerovault import RzvClient
    from rootzerovault.adapters.mcp_adapter import GovernedMCPServer

    rzv = RzvClient(gateway="http://localhost:8443")
    mcp = GovernedMCPServer("Root Zero Vault", rzv=rzv, agent_id="my-mcp-agent")

    @mcp.governed_tool()
    def transfer_funds(amount: float, destination: str) -> dict:
        \"\"\"Transfer funds — every call is constitutionally gated.\"\"\"
        return execute_transfer(amount, destination)

    mcp.run()

Usage — wrap existing FastMCP server:

    from mcp.server.fastmcp import FastMCP
    from rootzerovault.adapters.mcp_adapter import wrap_fastmcp

    existing_mcp = FastMCP("My Server")
    governed = wrap_fastmcp(existing_mcp, rzv=rzv, agent_id="my-agent")

Usage — single tool decorator:

    from rootzerovault.adapters.mcp_adapter import governed_tool

    @governed_tool(rzv=rzv, action="PROCESS_PAYMENT")
    def process_payment(amount: float) -> dict:
        return ...

Egypt deployment:
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    mcp = GovernedMCPServer("EGYPT-MCP", rzv=rzv, agent_id="EGYPT0-ai-001")
"""

from __future__ import annotations

import functools
import hashlib
try:
    import blake3 as _blake3
    _HAS_BLAKE3 = True
except ImportError:
    _HAS_BLAKE3 = False
import json
import uuid
from typing import Any, Callable, Dict, List, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient, GateAction
from ..exceptions import RzvGatewayError

F = TypeVar("F", bound=Callable[..., Any])


# ── Governed tool decorator ───────────────────────────────────────────────────

def governed_tool(
    rzv: RzvClient,
    action: Optional[str] = None,
    agent_id: str = "mcp-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Callable[[F], F]:
    """
    Decorator that gates any function through the constitutional gate.

    Apply to any MCP tool function. The gate evaluates the call before
    execution. If rejected, raises RzvGatewayError. Never fails silently.

    Parameters
    ----------
    rzv : RzvClient
        Root Zero Vault client.
    action : str, optional
        Gate action type. Defaults to "MCP_TOOL_{FUNCTION_NAME}".
    agent_id : str
        Agent identifier for journal entries.
    deed_cvid : str, optional
        Governing deed CVID. Uses genesis if not provided.
    fail_closed : bool
        If True (default), infrastructure errors = BLOCK.
        If False, infrastructure errors = pass-through (not recommended).

    Example
    -------
    @governed_tool(rzv=rzv, action="TRANSFER_FUNDS")
    def transfer_funds(amount: float, destination: str) -> dict:
        return execute_transfer(amount, destination)
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)

    def decorator(fn: F) -> F:
        gate_action = action or f"MCP_TOOL_{fn.__name__.upper()}"

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Build payload from args + kwargs for gate evaluation
            payload = _build_payload(fn, args, kwargs)

            # Gate evaluation — fail-closed by default
            try:
                result = gov.gate(
                    action=gate_action,
                    payload=payload,
                    agent_id=agent_id,
                )
            except Exception as e:
                if fail_closed:
                    raise RzvGatewayError(
                        f"Constitutional gate infrastructure error on '{gate_action}': {e}"
                    ) from e
                # fail_open — pass through (not recommended for production)
                result = GateAction(
                    outcome="ACCEPT",
                    action=gate_action,
                    agent_id=agent_id,
                    cvid=None,
                    reason_code=None,
                    live=False,
                )

            if result.rejected:
                raise RzvGatewayError(
                    f"Constitutional gate blocked MCP tool '{fn.__name__}': "
                    f"{result.reason_code or 'rule violation'} "
                    f"(cvid={result.cvid})"
                )

            # Gate accepted — execute the tool
            return fn(*args, **kwargs)

        # Mark as governed for introspection
        wrapper._rzv_governed = True  # type: ignore[attr-defined]
        wrapper._rzv_action = gate_action  # type: ignore[attr-defined]
        wrapper._rzv_agent_id = agent_id  # type: ignore[attr-defined]
        return wrapper  # type: ignore[return-value]

    return decorator


# ── GovernedMCPServer ────────────────────────────────────────────────────────

class GovernedMCPServer:
    """
    MCP server with constitutional governance on every tool call.

    Drop-in replacement for FastMCP. Every tool registered with
    @governed_tool() is evaluated by the constitutional gate before
    execution. The gate is wired to the rsbis-agent-gate 9-step pipeline.

    Parameters
    ----------
    name : str
        Server name (passed to FastMCP).
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Agent ID for all tools on this server. Can be overridden per-tool.
    deed_cvid : str, optional
        Governing deed CVID for all tools.
    fail_closed : bool
        Infrastructure errors = BLOCK (default True).
    **kwargs
        Additional arguments passed to FastMCP.

    Example
    -------
    rzv = RzvClient(gateway="http://localhost:8443")
    mcp = GovernedMCPServer("Root Zero Vault", rzv=rzv, agent_id="rzv-agent")

    @mcp.governed_tool()
    def get_balance(account_id: str) -> dict:
        \"\"\"Get account balance — read-only, always gated.\"\"\"
        return bank.get_balance(account_id)

    @mcp.governed_tool(action="TRANSFER_FUNDS")
    def transfer(amount: float, to: str) -> dict:
        \"\"\"Transfer funds — constitutionally governed.\"\"\"
        return bank.transfer(amount, to)

    mcp.run()
    """

    def __init__(
        self,
        name: str,
        rzv: RzvClient,
        agent_id: str = "mcp-agent",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
        **kwargs: Any,
    ) -> None:
        # Import here so mcp is optional dependency
        try:
            from mcp.server.fastmcp import FastMCP
            self._mcp = FastMCP(name, **kwargs)
            self._has_mcp = True
        except ImportError:
            self._mcp = None
            self._has_mcp = False

        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._fail_closed = fail_closed
        self._name = name
        self._tools: List[Dict[str, Any]] = []

    @property
    def gov(self) -> GovernanceClient:
        """Direct access to GovernanceClient."""
        return self._gov

    def governed_tool(
        self,
        action: Optional[str] = None,
        agent_id: Optional[str] = None,
        fail_closed: Optional[bool] = None,
    ) -> Callable[[F], F]:
        """
        Register a function as a constitutionally governed MCP tool.

        Parameters
        ----------
        action : str, optional
            Gate action type. Defaults to "MCP_TOOL_{FUNCTION_NAME}".
        agent_id : str, optional
            Override the server-level agent ID for this tool.
        fail_closed : bool, optional
            Override the server-level fail_closed for this tool.
        """
        effective_agent_id = agent_id or self._agent_id
        effective_fail_closed = fail_closed if fail_closed is not None else self._fail_closed

        def decorator(fn: F) -> F:
            gate_action = action or f"MCP_TOOL_{fn.__name__.upper()}"

            # Gate wrapper
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                return await _run_governed_async(
                    fn, args, kwargs, self._gov, gate_action,
                    effective_agent_id, effective_fail_closed
                )

            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                payload = _build_payload(fn, args, kwargs)
                result = self._gov.gate(
                    action=gate_action,
                    payload=payload,
                    agent_id=effective_agent_id,
                )
                if result.rejected:
                    raise RzvGatewayError(
                        f"Gate blocked '{fn.__name__}': {result.reason_code} "
                        f"(cvid={result.cvid})"
                    )
                return fn(*args, **kwargs)

            import asyncio
            import inspect
            if inspect.iscoroutinefunction(fn):
                governed_fn = async_wrapper
            else:
                governed_fn = sync_wrapper

            # Mark as governed
            governed_fn._rzv_governed = True  # type: ignore[attr-defined]
            governed_fn._rzv_action = gate_action  # type: ignore[attr-defined]

            # Register with FastMCP if available
            if self._has_mcp and self._mcp is not None:
                self._mcp.tool()(governed_fn)

            # Track for introspection
            self._tools.append({
                "name": fn.__name__,
                "action": gate_action,
                "agent_id": effective_agent_id,
                "governed": True,
            })

            return governed_fn  # type: ignore[return-value]

        return decorator

    def tool(self) -> Callable[[F], F]:
        """
        Register an ungoverned tool. Use governed_tool() instead for
        constitutional governance. This passthrough is provided for
        compatibility — it logs a warning.
        """
        import warnings
        warnings.warn(
            f"Tool registered without constitutional governance on server '{self._name}'. "
            "Use @server.governed_tool() to gate this tool.",
            UserWarning,
            stacklevel=2,
        )
        if self._has_mcp and self._mcp is not None:
            return self._mcp.tool()
        return lambda fn: fn

    def run(self, transport: str = "stdio", **kwargs: Any) -> None:
        """Start the MCP server."""
        if not self._has_mcp:
            raise ImportError(
                "mcp package not installed. Run: pip install mcp"
            )
        self._mcp.run(transport=transport, **kwargs)

    def list_governed_tools(self) -> List[Dict[str, Any]]:
        """Return list of all governed tools on this server."""
        return list(self._tools)

    def tool_count(self) -> int:
        return len(self._tools)


# ── wrap_fastmcp ─────────────────────────────────────────────────────────────

def wrap_fastmcp(
    server: Any,
    rzv: RzvClient,
    agent_id: str = "mcp-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Wrap an existing FastMCP server to gate all tool calls constitutionally.

    Patches the server's tool decorator so every subsequent tool registration
    is automatically governed. Tools already registered are NOT retroactively
    governed — register tools after calling wrap_fastmcp().

    Parameters
    ----------
    server : FastMCP
        Existing FastMCP server instance.
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Agent ID for gate journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = BLOCK (default True).

    Returns
    -------
    FastMCP
        The same server instance, with tool() patched.

    Example
    -------
    existing = FastMCP("My Server")
    governed = wrap_fastmcp(existing, rzv=rzv, agent_id="my-agent")

    @governed.tool()   # now constitutionally governed
    def my_tool(x: int) -> int:
        return x * 2
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
    original_tool = server.tool

    def governed_tool_decorator() -> Callable[[F], F]:
        def decorator(fn: F) -> F:
            gate_action = f"MCP_TOOL_{fn.__name__.upper()}"

            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                payload = _build_payload(fn, args, kwargs)
                result = gov.gate(
                    action=gate_action,
                    payload=payload,
                    agent_id=agent_id,
                )
                if result.rejected:
                    raise RzvGatewayError(
                        f"Gate blocked '{fn.__name__}': {result.reason_code}"
                    )
                return fn(*args, **kwargs)

            wrapper._rzv_governed = True  # type: ignore[attr-defined]
            # Register with original FastMCP tool system
            original_tool()(wrapper)
            return wrapper  # type: ignore[return-value]

        return decorator

    server.tool = governed_tool_decorator
    server._rzv_governed = True  # type: ignore[attr-defined]
    server._rzv_gov = gov  # type: ignore[attr-defined]
    return server


# ── Helpers ──────────────────────────────────────────────────────────────────

def _build_payload(fn: Callable, args: tuple, kwargs: dict) -> Dict[str, Any]:
    """Build a gate-evaluable payload from function arguments."""
    import inspect
    sig = inspect.signature(fn)
    params = list(sig.parameters.keys())

    payload: Dict[str, Any] = {}
    for i, arg in enumerate(args):
        if i < len(params):
            payload[params[i]] = _safe_str(arg)

    for k, v in kwargs.items():
        payload[k] = _safe_str(v)

    # Add payload hash for binding (mirrors rsbis-agent-gate step 7)
    payload_bytes = json.dumps(payload, sort_keys=True).encode()
    if _HAS_BLAKE3:
        payload["_payload_hash"] = _blake3.blake3(payload_bytes).hexdigest()
    else:
        import hashlib
        payload["_payload_hash"] = hashlib.sha256(payload_bytes).hexdigest()

    return payload


def _safe_str(v: Any) -> Any:
    """Convert value to gate-safe type."""
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    try:
        return str(v)
    except Exception:
        return "<unpresentable>"


async def _run_governed_async(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    gov: GovernanceClient,
    gate_action: str,
    agent_id: str,
    fail_closed: bool,
) -> Any:
    """Run gate + function for async tools."""
    payload = _build_payload(fn, args, kwargs)

    try:
        result = await gov.gate_async(
            action=gate_action,
            payload=payload,
            agent_id=agent_id,
        )
    except Exception as e:
        if fail_closed:
            raise RzvGatewayError(
                f"Gate infrastructure error on '{gate_action}': {e}"
            ) from e
        result = GateAction(
            outcome="ACCEPT",
            action=gate_action,
            agent_id=agent_id,
            cvid=None,
            reason_code=None,
            live=False,
        )

    if result.rejected:
        raise RzvGatewayError(
            f"Gate blocked '{fn.__name__}': {result.reason_code} (cvid={result.cvid})"
        )

    import inspect
    if inspect.iscoroutinefunction(fn):
        return await fn(*args, **kwargs)
    return fn(*args, **kwargs)
