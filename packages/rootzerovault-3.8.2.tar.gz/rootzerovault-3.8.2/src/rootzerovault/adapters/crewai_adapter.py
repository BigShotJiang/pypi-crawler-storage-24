"""
CrewAI adapter — constitutional governance for CrewAI agents and tools.

Every tool call by every agent in every crew is evaluated by the RSBIS
constitutional gate before execution. Fail-closed.

Three patterns:

1. governed_crewai_tool — wrap any existing CrewAI tool (one line):

    from rootzerovault.adapters.crewai_adapter import governed_crewai_tool

    governed = governed_crewai_tool(my_tool, rzv=rzv)

2. GovernedCrewTool — base class for new governed tools:

    from rootzerovault.adapters.crewai_adapter import GovernedCrewTool

    class ResearchTool(GovernedCrewTool):
        name: str = "research"
        description: str = "Research any topic"
        rzv_client: Any = None

        def _run(self, query: str) -> str:
            return search(query)

3. GovernedCrew — wraps a full Crew, governing all tool calls:

    from rootzerovault.adapters.crewai_adapter import GovernedCrew

    crew = GovernedCrew(crew=my_crew, rzv=rzv, agent_id="crew-001")
    result = crew.kickoff(inputs={"topic": "AI governance"})

AI-to-AI governed communication:
    When CrewAI agents delegate tasks to each other, each delegation
    passes through the constitutional gate. Neither agent can exceed
    its declared permission envelope — relay attacks are blocked
    structurally, not by policy.

Egypt deployment:
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    crew = GovernedCrew(crew=ministry_crew, rzv=rzv, agent_id="EGYPT0-crew")
"""

from __future__ import annotations

import functools
from typing import Any, Dict, List, Optional, Union

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError
from .mcp_adapter import _build_payload


# ── governed_crewai_tool — wrap any existing tool ────────────────────────────

def governed_crewai_tool(
    tool: Any,
    rzv: RzvClient,
    action: Optional[str] = None,
    agent_id: str = "crewai-agent",
    deed_cvid: Optional[str] = None,
) -> Any:
    """
    Wrap any existing CrewAI tool with constitutional governance.

    Parameters
    ----------
    tool : BaseTool
        Any CrewAI tool instance.
    rzv : RzvClient
        Root Zero Vault client.
    action : str, optional
        Gate action type. Defaults to "CREW_TOOL_{TOOL_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.

    Returns
    -------
    BaseTool
        Same tool with _run patched for constitutional governance.

    Example
    -------
    from crewai_tools import SerperDevTool
    governed = governed_crewai_tool(SerperDevTool(), rzv=rzv)
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
    gate_action = action or f"CREW_TOOL_{tool.name.upper().replace(' ', '_')}"

    original_run = tool._run

    @functools.wraps(original_run)
    def governed_run(*args: Any, **kwargs: Any) -> Any:
        payload = {"tool": tool.name, "args": str(args)[:200], "kwargs": str(kwargs)[:200]}
        result = gov.gate(action=gate_action, payload=payload, agent_id=agent_id)
        if result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked CrewAI tool '{tool.name}': "
                f"{result.reason_code} (cvid={result.cvid})"
            )
        return original_run(*args, **kwargs)

    tool._run = governed_run
    tool._rzv_governed = True
    tool._rzv_action = gate_action
    return tool


# ── GovernedCrewTool — base class ─────────────────────────────────────────────

def _make_governed_crew_tool() -> Any:
    """Build GovernedCrewTool only if crewai is available."""
    try:
        from crewai.tools import BaseTool as CrewBaseTool
        from pydantic import Field

        class GovernedCrewTool(CrewBaseTool):
            """
            CrewAI BaseTool subclass with constitutional governance.

            Every call to run() passes through the constitutional gate
            before _run() executes. Subclass this instead of BaseTool.

            Example
            -------
            class AnalysisTools(GovernedCrewTool):
                name: str = "financial_analysis"
                description: str = "Analyze financial data"
                rzv_client: Any = None
                rzv_agent_id: str = "finance-crew"

                def _run(self, data: str) -> str:
                    return analyze(data)
            """

            rzv_client: Optional[Any] = None
            rzv_agent_id: str = "crewai-agent"
            rzv_deed_cvid: Optional[str] = None
            rzv_action: Optional[str] = None

            class Config:
                arbitrary_types_allowed = True

            def _get_gov(self) -> GovernanceClient:
                if self.rzv_client is None:
                    return GovernanceClient(RzvClient())
                return GovernanceClient(self.rzv_client, deed_cvid=self.rzv_deed_cvid)

            def _run(self, *args: Any, **kwargs: Any) -> Any:
                raise NotImplementedError("Subclass must implement _run")

            def run(self, *args: Any, **kwargs: Any) -> Any:
                gov = self._get_gov()
                gate_action = self.rzv_action or f"CREW_TOOL_{self.name.upper().replace(' ', '_')}"
                payload = {"tool": self.name, "args": str(args)[:200]}
                result = gov.gate(
                    action=gate_action,
                    payload=payload,
                    agent_id=self.rzv_agent_id,
                )
                if result.rejected:
                    raise RzvGatewayError(
                        f"Gate blocked CrewAI tool '{self.name}': "
                        f"{result.reason_code} (cvid={result.cvid})"
                    )
                return self._run(*args, **kwargs)

        return GovernedCrewTool

    except ImportError:
        return None


GovernedCrewTool = _make_governed_crew_tool()


# ── GovernedCrew — wrap an entire crew ───────────────────────────────────────

class GovernedCrew:
    """
    Wrap a full CrewAI Crew with constitutional governance.

    Every tool call by every agent in the crew passes through the
    constitutional gate. AI-to-AI delegation is governed — neither
    agent can exceed its constitutional permission envelope.

    This is the Purple Cow moment for multi-agent systems: the crew
    cannot collectively do what no individual agent is permitted to do.
    Relay attacks are structurally impossible.

    Parameters
    ----------
    crew : Crew
        Any CrewAI Crew instance.
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Agent ID prefix for all crew members.
    deed_cvid : str, optional
        Governing deed CVID for the crew.

    Example
    -------
    from crewai import Agent, Task, Crew
    from rootzerovault.adapters.crewai_adapter import GovernedCrew

    researcher = Agent(role="Researcher", tools=[search_tool], ...)
    writer = Agent(role="Writer", tools=[write_tool], ...)
    crew = Crew(agents=[researcher, writer], tasks=[...])

    governed = GovernedCrew(crew=crew, rzv=rzv, agent_id="research-crew")
    result = governed.kickoff(inputs={"topic": "AI governance in Egypt"})
    """

    def __init__(
        self,
        crew: Any,
        rzv: RzvClient,
        agent_id: str = "crewai-crew",
        deed_cvid: Optional[str] = None,
    ) -> None:
        self._crew = crew
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._patch_crew_tools()

    def _patch_crew_tools(self) -> None:
        """Patch all tools on all agents in the crew."""
        agents = getattr(self._crew, 'agents', [])
        for agent in agents:
            tools = getattr(agent, 'tools', [])
            for i, tool in enumerate(tools):
                if not getattr(tool, '_rzv_governed', False):
                    patched = governed_crewai_tool(
                        tool,
                        rzv=self._gov._rzv,
                        agent_id=f"{self._agent_id}/{getattr(agent, 'role', 'agent')}",
                        deed_cvid=self._gov._deed_cvid,
                    )
                    tools[i] = patched

    def kickoff(self, inputs: Optional[Dict[str, Any]] = None) -> Any:
        """
        Run the crew with constitutional governance on all tool calls.

        Every tool call by every agent is gated before execution.
        The crew cannot collectively exceed any agent's permission envelope.
        """
        # Gate the crew kickoff itself
        result = self._gov.gate(
            action="CREW_KICKOFF",
            payload={"crew": str(type(self._crew).__name__), "inputs": str(inputs or {})[:200]},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked crew kickoff: "
                f"{result.reason_code} (cvid={result.cvid})"
            )
        return self._crew.kickoff(inputs=inputs)

    async def kickoff_async(self, inputs: Optional[Dict[str, Any]] = None) -> Any:
        """Async version of kickoff()."""
        result = await self._gov.gate_async(
            action="CREW_KICKOFF",
            payload={"inputs": str(inputs or {})[:200]},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Gate blocked crew kickoff: {result.reason_code}"
            )
        return await self._crew.kickoff_async(inputs=inputs)

    @property
    def gov(self) -> GovernanceClient:
        return self._gov

    def list_governed_tools(self) -> List[Dict[str, Any]]:
        """List all governed tools across all agents."""
        tools = []
        for agent in getattr(self._crew, 'agents', []):
            for tool in getattr(agent, 'tools', []):
                tools.append({
                    "agent": getattr(agent, 'role', 'unknown'),
                    "tool": tool.name,
                    "governed": getattr(tool, '_rzv_governed', False),
                    "action": getattr(tool, '_rzv_action', None),
                })
        return tools
