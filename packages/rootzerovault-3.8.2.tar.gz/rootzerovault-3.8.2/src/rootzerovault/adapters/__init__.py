"""
Constitutional adapters for Root Zero Vault.

Every adapter routes actions through the RSBIS constitutional gate
before execution. Fail-closed by default.

Available:
    BaseAdapter            — abstract base for custom adapters
    HttpAdapter            — generic REST API governance
    GovernedMCPServer      — MCP server with constitutional governance
    governed_tool          — decorator for any MCP tool function
    wrap_fastmcp           — wrap an existing FastMCP server
    governed_langchain_tool — wrap any LangChain tool (one line)
    GovernedTool           — LangChain BaseTool subclass with governance
    governed_lc_tool       — decorator for function-based LangChain tools
    governed_crewai_tool   — wrap any CrewAI tool (one line)
    GovernedCrewTool       — CrewAI BaseTool subclass with governance
    GovernedCrew           — wrap a full Crew, govern all tool calls
    GovernedA2AAgent       — A2A agent base with constitutional governance
    governed_a2a_agent     — wrap any A2A agent instance (one line)
    GovernedA2AClient      — gate outbound A2A task submissions

Protocols covered:
    MCP  (Anthropic)       — tool calls from any LLM
    A2A  (Google/Linux Foundation) — agent-to-agent tasks
    LangChain              — largest agent framework
    CrewAI                 — multi-agent crews
    HTTP                   — any REST API

Every adapter:
    - Evaluates the 18-rule constitutional gate before execution
    - Fail-closed by default (infra errors = REJECT)
    - Works offline in demo mode (simulated CVIDs)
    - Wires to live gateway for real blake3 chain sealing
    - AI-to-AI relay attacks blocked structurally

Quick start:
    from rootzerovault import RzvClient
    from rootzerovault.adapters import (
        GovernedMCPServer, governed_langchain_tool,
        GovernedCrew, GovernedA2AAgent,
    )

    rzv = RzvClient(gateway="http://localhost:8443")

    # MCP
    mcp = GovernedMCPServer("My Server", rzv=rzv)

    # LangChain
    governed = governed_langchain_tool(my_lc_tool, rzv=rzv)

    # CrewAI
    crew = GovernedCrew(crew=my_crew, rzv=rzv)

    # A2A
    class MyAgent(GovernedA2AAgent):
        rzv_client = rzv
        async def execute_task(self, task):
            yield await do_work(task)
"""

from .base import BaseAdapter
from .http_adapter import HttpAdapter
from .mcp_adapter import GovernedMCPServer, governed_tool, wrap_fastmcp
from .langchain_adapter import governed_langchain_tool, governed_lc_tool, GovernedTool
from .crewai_adapter import governed_crewai_tool, GovernedCrewTool, GovernedCrew
from .a2a_adapter import GovernedA2AAgent, governed_a2a_agent, GovernedA2AClient
from .anp_adapter import GovernedANPAgent, governed_interface, GovernedANPCrawler

__all__ = [
    # Base
    "BaseAdapter",
    "HttpAdapter",
    # MCP
    "GovernedMCPServer",
    "governed_tool",
    "wrap_fastmcp",
    # LangChain
    "governed_langchain_tool",
    "governed_lc_tool",
    "GovernedTool",
    # CrewAI
    "governed_crewai_tool",
    "GovernedCrewTool",
    "GovernedCrew",
    # A2A
    "GovernedA2AAgent",
    "governed_a2a_agent",
    "GovernedA2AClient",
    # ANP
    "GovernedANPAgent",
    "governed_interface",
    "GovernedANPCrawler",
    # ACP (IBM/BeeAI)
    "governed_acp_agent",
    "GovernedACPServer",
    "governed_acp_run",
    # PydanticAI
    "governed_pydantic_tool",
    "GovernedPydanticAgent",
    # smolagents (Hugging Face)
    "GovernedSmolTool",
    "governed_smol_tool",
    # Semantic Kernel (Microsoft)
    "governed_kernel_function",
    "GovernedKernelPlugin",
]

# Extended adapters — added in v3.8.0
from .acp_adapter import governed_acp_agent, GovernedACPServer, governed_acp_run
from .pydantic_ai_adapter import governed_pydantic_tool, GovernedPydanticAgent
from .smolagents_adapter import GovernedSmolTool, governed_smol_tool
from .semantic_kernel_adapter import governed_kernel_function, GovernedKernelPlugin
from .bedrock_adapter import (
    GovernedBedrockClient, GovernedBedrockAgent, governed_bedrock_tool,
)
from .vertex_adapter import (
    GovernedVertexModel, GovernedVertexChat, GovernedVertexEndpoint,
    governed_vertex_tool,
)
from .azure_openai_adapter import (
    GovernedAzureOpenAI, GovernedAzureAssistant, governed_azure_tool,
)
from .anthropic_adapter import (
    GovernedAnthropic, GovernedAsyncAnthropic, governed_claude_tool,
)
from .cohere_adapter import (
    GovernedCohereClient, GovernedCohereRAG, governed_cohere_tool,
)
