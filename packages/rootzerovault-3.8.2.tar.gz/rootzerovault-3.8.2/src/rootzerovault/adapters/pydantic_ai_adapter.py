"""
PydanticAI adapter — constitutional governance for PydanticAI tools.

PydanticAI (v1.70+, API-stable) is the type-safe agent framework built
by the Pydantic team. Favorite for enterprise developers who need
validated, structured tool calls.

Every tool registered on a PydanticAI agent is evaluated by the
RSBIS constitutional gate before execution. Fail-closed.

Two patterns:

1. governed_pydantic_tool — decorator for PydanticAI agent tools:

    from pydantic_ai import Agent
    from rootzerovault.adapters.pydantic_ai_adapter import governed_pydantic_tool

    agent = Agent('openai:gpt-4o')
    rzv = RzvClient(gateway="http://localhost:8443")

    @agent.tool
    @governed_pydantic_tool(rzv=rzv, action="SEARCH_DATABASE")
    async def search_database(ctx, query: str) -> str:
        return await db.search(query)

2. GovernedPydanticAgent — agent with governance on all tools:

    from rootzerovault.adapters.pydantic_ai_adapter import GovernedPydanticAgent

    agent = GovernedPydanticAgent(
        model='openai:gpt-4o',
        rzv=rzv,
        agent_id="egypt-ai",
    )

    @agent.governed_tool
    async def process_directive(ctx, directive: str) -> dict:
        return await execute(directive)

    result = await agent.run("Process the budget directive")
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError
from .mcp_adapter import _build_payload

F = TypeVar("F", bound=Callable[..., Any])


# ── governed_pydantic_tool — decorator ───────────────────────────────────────

def governed_pydantic_tool(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "pydantic-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Decorator that gates any PydanticAI tool constitutionally.

    Apply before @agent.tool. The gate runs before every tool execution.

    Usage:
        @agent.tool
        @governed_pydantic_tool(rzv=rzv, action="TRANSFER_FUNDS")
        async def transfer_funds(ctx, amount: float, to: str) -> str:
            return await bank.transfer(amount, to)

    Parameters
    ----------
    fn : callable, optional
        The tool function.
    rzv : RzvClient, optional
        Root Zero Vault client. Defaults to demo mode.
    action : str, optional
        Gate action. Defaults to "PAI_TOOL_{FUNCTION_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = REJECT (default True).
    """
    def decorator(f: F) -> F:
        gate_action = action or f"PAI_TOOL_{f.__name__.upper()}"
        gov = GovernanceClient(rzv or RzvClient(), deed_cvid=deed_cvid)

        @functools.wraps(f)
        async def async_wrapper(ctx: Any, *args: Any, **kwargs: Any) -> Any:
            payload = _build_payload(f, args, kwargs)
            payload['tool'] = f.__name__

            try:
                gate_result = await gov.gate_async(
                    action=gate_action,
                    payload=payload,
                    agent_id=agent_id,
                )
            except Exception as e:
                if fail_closed:
                    raise RzvGatewayError(
                        f"PydanticAI gate error on '{gate_action}': {e}"
                    ) from e
                gate_result = None

            if gate_result is not None and gate_result.rejected:
                raise RzvGatewayError(
                    f"Constitutional gate blocked PydanticAI tool '{f.__name__}': "
                    f"{gate_result.reason_code} (cvid={gate_result.cvid})"
                )

            import inspect
            if inspect.iscoroutinefunction(f):
                return await f(ctx, *args, **kwargs)
            return f(ctx, *args, **kwargs)

        @functools.wraps(f)
        def sync_wrapper(ctx: Any, *args: Any, **kwargs: Any) -> Any:
            import asyncio
            payload = _build_payload(f, args, kwargs)
            result = gov.gate(action=gate_action, payload=payload, agent_id=agent_id)
            if result.rejected:
                raise RzvGatewayError(
                    f"Gate blocked '{f.__name__}': {result.reason_code}"
                )
            return f(ctx, *args, **kwargs)

        import inspect
        wrapper = async_wrapper if inspect.iscoroutinefunction(f) else sync_wrapper
        wrapper._rzv_governed = True
        wrapper._rzv_action = gate_action
        return wrapper  # type: ignore

    if fn is not None:
        return decorator(fn)
    return decorator


# ── GovernedPydanticAgent — agent with governance ────────────────────────────

class GovernedPydanticAgent:
    """
    PydanticAI Agent wrapper with constitutional governance on all tools.

    Parameters
    ----------
    model : str or model instance
        PydanticAI model (e.g. 'openai:gpt-4o', 'anthropic:claude-3-5-sonnet').
    rzv : RzvClient
        Root Zero Vault client.
    agent_id : str
        Agent ID for gate journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    **kwargs
        Additional arguments passed to pydantic_ai.Agent.

    Example
    -------
    agent = GovernedPydanticAgent(
        model='anthropic:claude-sonnet-4-6',
        rzv=RzvClient(gateway="http://localhost:8443"),
        agent_id="egypt-policy-agent",
    )

    @agent.governed_tool
    async def check_policy(ctx, directive: str) -> dict:
        return {"compliant": await policy.check(directive)}

    result = await agent.run("Is this directive compliant?")
    """

    def __init__(
        self,
        model: Any,
        rzv: RzvClient,
        agent_id: str = "pydantic-agent",
        deed_cvid: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        try:
            from pydantic_ai import Agent
            self._agent = Agent(model, **kwargs)
        except ImportError:
            raise ImportError("pydantic-ai required: pip install rootzerovault[pydantic-ai]")

        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._tools: list = []

    def governed_tool(
        self,
        fn: Optional[F] = None,
        *,
        action: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> Any:
        """Register a constitutionally governed tool on this agent."""
        effective_agent_id = agent_id or self._agent_id

        def decorator(f: F) -> F:
            gate_action = action or f"PAI_TOOL_{f.__name__.upper()}"

            @functools.wraps(f)
            async def governed(ctx: Any, *args: Any, **kwargs: Any) -> Any:
                payload = _build_payload(f, args, kwargs)
                gate_result = await self._gov.gate_async(
                    action=gate_action, payload=payload, agent_id=effective_agent_id,
                )
                if gate_result.rejected:
                    raise RzvGatewayError(
                        f"Gate blocked '{f.__name__}': {gate_result.reason_code}"
                    )
                import inspect
                if inspect.iscoroutinefunction(f):
                    return await f(ctx, *args, **kwargs)
                return f(ctx, *args, **kwargs)

            governed._rzv_governed = True
            governed._rzv_action = gate_action
            self._agent.tool(governed)
            self._tools.append({"name": f.__name__, "action": gate_action})
            return governed  # type: ignore

        if fn is not None:
            return decorator(fn)
        return decorator

    async def run(self, prompt: str, **kwargs: Any) -> Any:
        """Run the agent with constitutional governance on all tools."""
        return await self._agent.run(prompt, **kwargs)

    def run_sync(self, prompt: str, **kwargs: Any) -> Any:
        """Synchronous run."""
        return self._agent.run_sync(prompt, **kwargs)

    @property
    def gov(self) -> GovernanceClient:
        return self._gov

    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)
