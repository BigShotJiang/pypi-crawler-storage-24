"""
Anthropic direct API adapter — constitutional governance for Anthropic's API.

Companies calling Claude directly via the Anthropic SDK — without any
agent framework — have no governance layer. This adapter wraps the
Anthropic client so every messages.create() call is constitutionally
governed before execution.

This covers the large class of production deployments that call Claude
directly: customer service bots, document processors, code assistants,
analysis pipelines — none of which use LangChain or CrewAI.

Three patterns:

1. GovernedAnthropic — drop-in for anthropic.Anthropic:

    from rootzerovault.adapters.anthropic_adapter import GovernedAnthropic

    rzv = RzvClient(gateway="http://localhost:8443")
    client = GovernedAnthropic(rzv=rzv, api_key="sk-ant-...")

    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Analyze contract..."}],
    )

2. GovernedAsyncAnthropic — async drop-in for anthropic.AsyncAnthropic:

    from rootzerovault.adapters.anthropic_adapter import GovernedAsyncAnthropic

    client = GovernedAsyncAnthropic(rzv=rzv)
    message = await client.messages.create(model="claude-opus-4-5", ...)

3. governed_claude_tool — decorator for Claude-backed functions:

    @governed_claude_tool(rzv=rzv, action="CONTRACT_REVIEW")
    def review_contract(text: str) -> str:
        return anthropic_client.messages.create(...)

Egypt deployment:
    client = GovernedAnthropic(
        rzv=RzvClient(gateway="https://vault.mcit.gov.eg"),
        agent_id="EGYPT0-claude-001",
    )
    # Every Claude call from Egyptian government systems — constitutionally sealed
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, Iterator, List, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError

F = TypeVar("F", bound=Callable[..., Any])


class _GovernedMessages:
    """Governed messages namespace — sync."""

    def __init__(self, gov: GovernanceClient, messages: Any, agent_id: str) -> None:
        self._gov = gov
        self._messages = messages
        self._agent_id = agent_id

    def _gate(self, model: str, messages: List[Dict], action: Optional[str]) -> None:
        action_str = action or f"ANTHROPIC_{model.upper().replace('-','_').replace('.','_')}_MESSAGE"
        last = messages[-1].get("content", "")[:200] if messages else ""
        result = self._gov.gate(
            action=action_str,
            payload={
                "model": model,
                "message_count": len(messages),
                "last_message_preview": last if isinstance(last, str) else str(last)[:200],
            },
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Anthropic messages.create blocked by constitutional gate: "
                f"{result.reason_code} — model={model}"
            )

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed messages.create()."""
        self._gate(model, messages, action)
        return self._messages.create(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )

    def stream(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Constitutionally governed messages.stream()."""
        self._gate(model, messages, action)
        return self._messages.stream(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )


class _GovernedAsyncMessages:
    """Governed messages namespace — async."""

    def __init__(self, gov: GovernanceClient, messages: Any, agent_id: str) -> None:
        self._gov = gov
        self._messages = messages
        self._agent_id = agent_id

    def _gate(self, model: str, messages: List[Dict], action: Optional[str]) -> None:
        action_str = action or f"ANTHROPIC_{model.upper().replace('-','_').replace('.','_')}_MESSAGE"
        result = self._gov.gate(
            action=action_str,
            payload={"model": model, "message_count": len(messages)},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(f"Anthropic async message blocked: {result.reason_code}")

    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: int,
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        self._gate(model, messages, action)
        return await self._messages.create(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )

    def stream(self, *, model: str, messages: List[Dict], max_tokens: int,
               action: Optional[str] = None, **kwargs: Any) -> Any:
        self._gate(model, messages, action)
        return self._messages.stream(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )


class GovernedAnthropic:
    """
    Drop-in replacement for anthropic.Anthropic.

    Wraps messages.create() and messages.stream() with constitutional
    governance. Identical API to the Anthropic SDK.
    """

    ADAPTER_ID = "anthropic-direct"

    def __init__(
        self,
        rzv: RzvClient,
        api_key: Optional[str] = None,
        agent_id: str = "anthropic-agent",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
        **anthropic_kwargs: Any,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._fail_closed = fail_closed
        self._api_key = api_key
        self._anthropic_kwargs = anthropic_kwargs
        self.__client: Any = None

    @property
    def _client(self) -> Any:
        if self.__client is None:
            try:
                import anthropic
                kwargs = {**self._anthropic_kwargs}
                if self._api_key:
                    kwargs["api_key"] = self._api_key
                self.__client = anthropic.Anthropic(**kwargs)
            except ImportError:
                raise ImportError(
                    "anthropic>=0.40.0 is required for GovernedAnthropic. "
                    "Install with: pip install anthropic"
                )
        return self.__client

    @property
    def messages(self) -> _GovernedMessages:
        return _GovernedMessages(self._gov, self._client.messages, self._agent_id)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class GovernedAsyncAnthropic:
    """Drop-in replacement for anthropic.AsyncAnthropic."""

    ADAPTER_ID = "anthropic-direct-async"

    def __init__(
        self,
        rzv: RzvClient,
        api_key: Optional[str] = None,
        agent_id: str = "anthropic-async-agent",
        deed_cvid: Optional[str] = None,
        **anthropic_kwargs: Any,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._api_key = api_key
        self._anthropic_kwargs = anthropic_kwargs
        self.__client: Any = None

    @property
    def _client(self) -> Any:
        if self.__client is None:
            try:
                import anthropic
                kwargs = {**self._anthropic_kwargs}
                if self._api_key:
                    kwargs["api_key"] = self._api_key
                self.__client = anthropic.AsyncAnthropic(**kwargs)
            except ImportError:
                raise ImportError("anthropic>=0.40.0 is required.")
        return self.__client

    @property
    def messages(self) -> _GovernedAsyncMessages:
        return _GovernedAsyncMessages(self._gov, self._client.messages, self._agent_id)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


def governed_claude_tool(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "claude-tool",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """Decorator for any function that calls Claude directly."""
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if rzv is None:
                return func(*args, **kwargs)
            gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
            result = gov.gate(
                action=action or f"ANTHROPIC_{func.__name__.upper()}",
                payload={"function": func.__name__},
                agent_id=agent_id,
            )
            if result.rejected and fail_closed:
                raise RzvGatewayError(f"Claude tool blocked: {result.reason_code}")
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]
    if fn is not None:
        return decorator(fn)
    return decorator
