"""
Azure OpenAI adapter — constitutional governance for Azure OpenAI Service.

Azure OpenAI is GPT-4, GPT-4o, and o1 running inside Azure tenants —
inside the enterprise network, behind Azure AD, with data residency
guarantees. This is the Microsoft enterprise AI stack.

Every chat.completions.create() and embeddings.create() call is
evaluated by the RSBIS constitutional gate before execution. Fail-closed.

Three patterns:

1. GovernedAzureOpenAI — drop-in for openai.AzureOpenAI:

    from rootzerovault.adapters.azure_openai_adapter import GovernedAzureOpenAI

    rzv = RzvClient(gateway="http://localhost:8443")
    client = GovernedAzureOpenAI(
        rzv=rzv,
        azure_endpoint="https://my-resource.openai.azure.com",
        api_key="...",
        api_version="2024-10-21",
    )

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Analyze this contract..."}],
    )

2. GovernedAzureAssistant — Azure OpenAI Assistants API with governance:

    assistant = GovernedAzureAssistant(rzv=rzv, assistant_id="asst_abc123", client=client)
    run = assistant.create_run(thread_id="thread_xyz", action="LEGAL_ANALYSIS")

3. governed_azure_tool — decorator for Azure-backed functions:

    @governed_azure_tool(rzv=rzv, action="FINANCIAL_SUMMARY")
    def summarize_report(text: str) -> str:
        return azure_client.chat.completions.create(...)

Egypt deployment:
    # Azure has a UAE North region — closest to Egypt
    client = GovernedAzureOpenAI(
        rzv=RzvClient(gateway="https://vault.mcit.gov.eg"),
        azure_endpoint="https://egypt-ai.openai.azure.com",
        api_version="2024-10-21",
        agent_id="EGYPT0-azure-001",
    )
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError

F = TypeVar("F", bound=Callable[..., Any])


class _GovernedCompletions:
    """Governed chat.completions namespace."""

    def __init__(self, gov: GovernanceClient, completions: Any, agent_id: str) -> None:
        self._gov = gov
        self._completions = completions
        self._agent_id = agent_id

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        action_str = action or f"AZURE_OPENAI_{model.upper().replace('-','_')}_CHAT"
        last_msg = messages[-1].get("content", "")[:200] if messages else ""
        result = self._gov.gate(
            action=action_str,
            payload={
                "model": model,
                "message_count": len(messages),
                "last_message_preview": last_msg,
                "stream": kwargs.get("stream", False),
            },
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(
                f"Azure OpenAI chat blocked by constitutional gate: "
                f"{result.reason_code} — model={model}"
            )
        return self._completions.create(model=model, messages=messages, **kwargs)

    async def create_async(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        action: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        action_str = action or f"AZURE_OPENAI_{model.upper().replace('-','_')}_CHAT"
        result = self._gov.gate(
            action=action_str,
            payload={"model": model, "message_count": len(messages)},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(f"Azure OpenAI async chat blocked: {result.reason_code}")
        return await self._completions.create(model=model, messages=messages, **kwargs)


class _GovernedEmbeddings:
    """Governed embeddings namespace."""

    def __init__(self, gov: GovernanceClient, embeddings: Any, agent_id: str) -> None:
        self._gov = gov
        self._embeddings = embeddings
        self._agent_id = agent_id

    def create(self, *, input: Any, model: str, action: Optional[str] = None, **kwargs: Any) -> Any:
        result = self._gov.gate(
            action=action or "AZURE_OPENAI_EMBEDDINGS_CREATE",
            payload={"model": model, "input_count": len(input) if isinstance(input, list) else 1},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(f"Azure OpenAI embeddings blocked: {result.reason_code}")
        return self._embeddings.create(input=input, model=model, **kwargs)


class GovernedAzureOpenAI:
    """
    Drop-in replacement for openai.AzureOpenAI.

    Wraps chat.completions, embeddings, and images with constitutional
    governance. Identical API to the openai SDK.
    """

    ADAPTER_ID = "azure-openai"

    def __init__(
        self,
        rzv: RzvClient,
        azure_endpoint: Optional[str] = None,
        api_key: Optional[str] = None,
        api_version: str = "2024-10-21",
        agent_id: str = "azure-openai-agent",
        deed_cvid: Optional[str] = None,
        fail_closed: bool = True,
        **openai_kwargs: Any,
    ) -> None:
        self._rzv = rzv
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._agent_id = agent_id
        self._fail_closed = fail_closed
        self._azure_endpoint = azure_endpoint
        self._api_key = api_key
        self._api_version = api_version
        self._openai_kwargs = openai_kwargs
        self.__client: Any = None

    @property
    def _client(self) -> Any:
        if self.__client is None:
            try:
                from openai import AzureOpenAI
                kwargs: Dict[str, Any] = {"api_version": self._api_version, **self._openai_kwargs}
                if self._azure_endpoint:
                    kwargs["azure_endpoint"] = self._azure_endpoint
                if self._api_key:
                    kwargs["api_key"] = self._api_key
                self.__client = AzureOpenAI(**kwargs)
            except ImportError:
                raise ImportError(
                    "openai>=1.0.0 is required for GovernedAzureOpenAI. "
                    "Install with: pip install openai"
                )
        return self.__client

    @property
    def chat(self) -> "_GovernedChat":
        return _GovernedChat(self._gov, self._client.chat, self._agent_id)

    @property
    def embeddings(self) -> _GovernedEmbeddings:
        return _GovernedEmbeddings(self._gov, self._client.embeddings, self._agent_id)

    # Pass-through for any other attributes (responses, assistants, etc.)
    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


class _GovernedChat:
    """Governed chat namespace."""
    def __init__(self, gov: GovernanceClient, chat: Any, agent_id: str) -> None:
        self._gov = gov
        self._chat = chat
        self._agent_id = agent_id

    @property
    def completions(self) -> _GovernedCompletions:
        return _GovernedCompletions(self._gov, self._chat.completions, self._agent_id)


class GovernedAzureAssistant:
    """Constitutional governance for Azure OpenAI Assistants API."""

    def __init__(
        self,
        rzv: RzvClient,
        assistant_id: str,
        client: Optional[GovernedAzureOpenAI] = None,
        agent_id: str = "azure-assistant",
        deed_cvid: Optional[str] = None,
    ) -> None:
        self._gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
        self._assistant_id = assistant_id
        self._client = client
        self._agent_id = agent_id

    def create_run(
        self,
        thread_id: str,
        action: str = "AZURE_ASSISTANT_RUN",
        **kwargs: Any,
    ) -> Any:
        result = self._gov.gate(
            action=action,
            payload={"assistant_id": self._assistant_id, "thread_id": thread_id},
            agent_id=self._agent_id,
        )
        if result.rejected:
            raise RzvGatewayError(f"Azure Assistant run blocked: {result.reason_code}")
        if self._client is None:
            raise RuntimeError("GovernedAzureAssistant requires a client instance")
        return self._client._client.beta.threads.runs.create(
            thread_id=thread_id, assistant_id=self._assistant_id, **kwargs
        )


def governed_azure_tool(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "azure-tool",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """Decorator for any Azure OpenAI-backed function."""
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if rzv is None:
                return func(*args, **kwargs)
            gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
            result = gov.gate(
                action=action or f"AZURE_{func.__name__.upper()}",
                payload={"function": func.__name__},
                agent_id=agent_id,
            )
            if result.rejected and fail_closed:
                raise RzvGatewayError(f"Azure tool blocked: {result.reason_code}")
            return func(*args, **kwargs)
        return wrapper  # type: ignore[return-value]
    if fn is not None:
        return decorator(fn)
    return decorator
