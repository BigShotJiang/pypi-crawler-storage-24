"""
LangChain adapter — constitutional governance for LangChain tools.

Every tool call is evaluated by the RSBIS constitutional gate before
execution. Fail-closed by default.

Three ways to govern LangChain tools:

1. governed_langchain_tool — wrap any existing LangChain tool (one line):

    from langchain_community.tools import ShellTool
    from rootzerovault.adapters.langchain_adapter import governed_langchain_tool

    governed = governed_langchain_tool(ShellTool(), rzv=rzv)
    # Use in any LangChain agent — identical interface

2. GovernedTool — create a new governed tool from a function:

    from rootzerovault.adapters.langchain_adapter import GovernedTool

    class TransferFunds(GovernedTool):
        name = "transfer_funds"
        description = "Transfer funds between accounts"
        rzv: Any = None

        def _run(self, amount: float, destination: str) -> str:
            return bank.transfer(amount, destination)

3. @governed_lc_tool — decorator for function-based tools:

    from rootzerovault.adapters.langchain_adapter import governed_lc_tool

    @governed_lc_tool(rzv=rzv, action="PROCESS_PAYMENT")
    def process_payment(amount: float) -> str:
        return execute_payment(amount)

Egypt deployment:
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    governed = governed_langchain_tool(my_tool, rzv=rzv, agent_id="EGYPT0-ai")
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Optional, Type, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError
from .mcp_adapter import _build_payload

F = TypeVar("F", bound=Callable[..., Any])


# ── governed_langchain_tool — wrap any existing tool ─────────────────────────

def governed_langchain_tool(
    tool: Any,
    rzv: RzvClient,
    action: Optional[str] = None,
    agent_id: str = "langchain-agent",
    deed_cvid: Optional[str] = None,
) -> Any:
    """
    Wrap any existing LangChain tool with constitutional governance.

    One line. Identical interface. Every invocation gated.

    Parameters
    ----------
    tool : BaseTool
        Any LangChain tool instance.
    rzv : RzvClient
        Root Zero Vault client.
    action : str, optional
        Gate action type. Defaults to "LC_TOOL_{TOOL_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.

    Returns
    -------
    BaseTool
        Same tool, with _run and invoke patched to gate every call.

    Example
    -------
    from langchain_community.tools import ShellTool
    governed = governed_langchain_tool(ShellTool(), rzv=rzv)
    result = governed.invoke("ls -la")
    """
    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
    gate_action = action or f"LC_TOOL_{tool.name.upper().replace(' ', '_')}"

    original_run = tool._run

    @functools.wraps(original_run)
    def governed_run(*args: Any, **kwargs: Any) -> Any:
        payload = {"tool": tool.name, "args": str(args)[:200], "kwargs": str(kwargs)[:200]}
        result = gov.gate(action=gate_action, payload=payload, agent_id=agent_id)
        if result.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked LangChain tool '{tool.name}': "
                f"{result.reason_code} (cvid={result.cvid})"
            )
        return original_run(*args, **kwargs)

    tool._run = governed_run
    tool._rzv_governed = True
    tool._rzv_action = gate_action
    tool._rzv_agent_id = agent_id
    return tool


# ── GovernedTool — base class for new governed tools ─────────────────────────

def _make_governed_tool_class() -> Any:
    """Build GovernedTool only if langchain_core is available."""
    try:
        from langchain_core.tools import BaseTool

        class GovernedTool(BaseTool):
            """
            LangChain BaseTool subclass with built-in constitutional governance.

            Subclass this instead of BaseTool to get constitutional governance
            on every tool call automatically.

            Example
            -------
            class TransferFunds(GovernedTool):
                name: str = "transfer_funds"
                description: str = "Transfer funds between accounts"
                rzv_client: Any = None
                rzv_agent_id: str = "finance-agent"

                def _run(self, amount: float, destination: str) -> str:
                    # Gate is called automatically before this runs
                    return bank.transfer(amount, destination)
            """

            # Override in subclass
            rzv_client: Optional[Any] = None
            rzv_agent_id: str = "langchain-agent"
            rzv_deed_cvid: Optional[str] = None
            rzv_action: Optional[str] = None

            class Config:
                arbitrary_types_allowed = True

            def _get_gov(self) -> GovernanceClient:
                if self.rzv_client is None:
                    # Demo mode — no gateway
                    return GovernanceClient(RzvClient())
                return GovernanceClient(
                    self.rzv_client,
                    deed_cvid=self.rzv_deed_cvid,
                )

            def _run(self, *args: Any, **kwargs: Any) -> Any:
                raise NotImplementedError("Subclass must implement _run")

            def run(self, tool_input: Any, **kwargs: Any) -> Any:
                gov = self._get_gov()
                gate_action = self.rzv_action or f"LC_TOOL_{self.name.upper().replace(' ', '_')}"
                payload = {"tool": self.name, "input": str(tool_input)[:200]}
                result = gov.gate(
                    action=gate_action,
                    payload=payload,
                    agent_id=self.rzv_agent_id,
                )
                if result.rejected:
                    raise RzvGatewayError(
                        f"Constitutional gate blocked '{self.name}': "
                        f"{result.reason_code} (cvid={result.cvid})"
                    )
                return super().run(tool_input, **kwargs)

        return GovernedTool

    except ImportError:
        return None


GovernedTool = _make_governed_tool_class()


# ── @governed_lc_tool — decorator for function-based tools ───────────────────

def governed_lc_tool(
    rzv: RzvClient,
    action: Optional[str] = None,
    agent_id: str = "langchain-agent",
    deed_cvid: Optional[str] = None,
    description: Optional[str] = None,
) -> Callable[[F], Any]:
    """
    Decorator that creates a constitutionally governed LangChain tool.

    Parameters
    ----------
    rzv : RzvClient
        Root Zero Vault client.
    action : str, optional
        Gate action type. Defaults to "LC_TOOL_{FUNCTION_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    description : str, optional
        Tool description. Defaults to function docstring.

    Example
    -------
    @governed_lc_tool(rzv=rzv, action="SEARCH_DATABASE")
    def search_database(query: str) -> str:
        \"\"\"Search the constitutional database.\"\"\"
        return db.search(query)
    """
    try:
        from langchain_core.tools import tool as lc_tool
    except ImportError:
        raise ImportError("langchain-core required: pip install langchain-core")

    gov = GovernanceClient(rzv, deed_cvid=deed_cvid)

    def decorator(fn: F) -> Any:
        gate_action = action or f"LC_TOOL_{fn.__name__.upper()}"

        @functools.wraps(fn)
        def governed_fn(*args: Any, **kwargs: Any) -> Any:
            payload = _build_payload(fn, args, kwargs)
            result = gov.gate(action=gate_action, payload=payload, agent_id=agent_id)
            if result.rejected:
                raise RzvGatewayError(
                    f"Gate blocked '{fn.__name__}': {result.reason_code} (cvid={result.cvid})"
                )
            return fn(*args, **kwargs)

        governed_fn._rzv_governed = True
        governed_fn._rzv_action = gate_action

        # Wrap as LangChain tool
        tool_desc = description or fn.__doc__ or f"Governed tool: {fn.__name__}"
        governed_fn.__doc__ = tool_desc
        return lc_tool(governed_fn)

    return decorator
