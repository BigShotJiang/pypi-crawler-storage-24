"""
Semantic Kernel adapter — constitutional governance for Microsoft SK.

Semantic Kernel is Microsoft's enterprise agent framework — the gold
standard for Azure/C# shops. Python SDK available since v1.0.

Every kernel function in every SK plugin is evaluated by the RSBIS
constitutional gate before execution. Fail-closed.

Two patterns:

1. governed_kernel_function — decorator for SK kernel functions:

    from semantic_kernel.functions import kernel_function
    from rootzerovault.adapters.semantic_kernel_adapter import governed_kernel_function

    class MyPlugin:
        @kernel_function(name="transfer", description="Transfer funds")
        @governed_kernel_function(rzv=rzv, action="TRANSFER_FUNDS")
        async def transfer(self, amount: float, destination: str) -> str:
            return await bank.transfer(amount, destination)

2. GovernedKernelPlugin — plugin base class with governance:

    from rootzerovault.adapters.semantic_kernel_adapter import GovernedKernelPlugin

    class FinancePlugin(GovernedKernelPlugin):
        rzv_client = rzv
        rzv_agent_id = "azure-finance-agent"

        @governed_kernel_function
        @kernel_function(name="process_payment")
        async def process_payment(self, amount: str) -> str:
            return await process(float(amount))

Egypt / Azure deployment:
    # Azure Government Cloud with RSBIS constitutional layer
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    plugin = FinancePlugin()
    plugin.rzv_client = rzv
"""

from __future__ import annotations

import functools
from typing import Any, Callable, Optional, TypeVar

from ..client import RzvClient
from ..governance import GovernanceClient
from ..exceptions import RzvGatewayError
from .mcp_adapter import _build_payload

F = TypeVar("F", bound=Callable[..., Any])


# ── governed_kernel_function — decorator ──────────────────────────────────────

def governed_kernel_function(
    fn: Optional[F] = None,
    *,
    rzv: Optional[RzvClient] = None,
    action: Optional[str] = None,
    agent_id: str = "sk-agent",
    deed_cvid: Optional[str] = None,
    fail_closed: bool = True,
) -> Any:
    """
    Decorator that gates any Semantic Kernel function constitutionally.

    Apply before or after @kernel_function. The gate runs before
    every kernel function execution.

    Usage:
        class MyPlugin:
            @kernel_function(name="search")
            @governed_kernel_function(rzv=rzv, action="SEARCH_DOCS")
            async def search(self, query: str) -> str:
                return await docs.search(query)

    Or on GovernedKernelPlugin subclasses (uses self.rzv_client):
        class MyPlugin(GovernedKernelPlugin):
            @governed_kernel_function
            @kernel_function(name="search")
            async def search(self, query: str) -> str:
                return await docs.search(query)

    Parameters
    ----------
    fn : callable, optional
        The kernel function.
    rzv : RzvClient, optional
        Root Zero Vault client. If None, uses self.rzv_client.
    action : str, optional
        Gate action. Defaults to "SK_FUNC_{FUNCTION_NAME}".
    agent_id : str
        Agent ID for journal entries.
    deed_cvid : str, optional
        Governing deed CVID.
    fail_closed : bool
        Infrastructure errors = REJECT (default True).
    """
    _gov_cache: dict = {}

    def decorator(f: F) -> F:
        gate_action = action or f"SK_FUNC_{f.__name__.upper()}"

        @functools.wraps(f)
        async def async_wrapper(self_or_first: Any, *args: Any, **kwargs: Any) -> Any:
            # Resolve gov — from decorator arg or self.rzv_client
            if rzv is not None:
                key = id(rzv)
                if key not in _gov_cache:
                    _gov_cache[key] = GovernanceClient(rzv, deed_cvid=deed_cvid)
                gov = _gov_cache[key]
                effective_agent_id = agent_id
            elif hasattr(self_or_first, 'rzv_client') and self_or_first.rzv_client is not None:
                client = self_or_first.rzv_client
                key = id(client)
                if key not in _gov_cache:
                    _gov_cache[key] = GovernanceClient(
                        client,
                        deed_cvid=getattr(self_or_first, 'rzv_deed_cvid', deed_cvid),
                    )
                gov = _gov_cache[key]
                effective_agent_id = getattr(self_or_first, 'rzv_agent_id', agent_id)
            else:
                gov = GovernanceClient(RzvClient())
                effective_agent_id = agent_id

            payload = _build_payload(f, (self_or_first,) + args, kwargs)
            payload['function'] = f.__name__

            try:
                gate_result = await gov.gate_async(
                    action=gate_action,
                    payload=payload,
                    agent_id=effective_agent_id,
                )
            except Exception as e:
                if fail_closed:
                    raise RzvGatewayError(
                        f"SK gate error on '{gate_action}': {e}"
                    ) from e
                gate_result = None

            if gate_result is not None and gate_result.rejected:
                raise RzvGatewayError(
                    f"Constitutional gate blocked SK function '{f.__name__}': "
                    f"{gate_result.reason_code} (cvid={gate_result.cvid})"
                )

            return await f(self_or_first, *args, **kwargs)

        @functools.wraps(f)
        def sync_wrapper(self_or_first: Any, *args: Any, **kwargs: Any) -> Any:
            if rzv is not None:
                gov = GovernanceClient(rzv, deed_cvid=deed_cvid)
                effective_agent_id = agent_id
            elif hasattr(self_or_first, 'rzv_client') and self_or_first.rzv_client is not None:
                gov = GovernanceClient(self_or_first.rzv_client)
                effective_agent_id = getattr(self_or_first, 'rzv_agent_id', agent_id)
            else:
                gov = GovernanceClient(RzvClient())
                effective_agent_id = agent_id

            payload = _build_payload(f, (self_or_first,) + args, kwargs)
            gate_result = gov.gate(action=gate_action, payload=payload, agent_id=effective_agent_id)
            if gate_result.rejected:
                raise RzvGatewayError(
                    f"Gate blocked '{f.__name__}': {gate_result.reason_code}"
                )
            return f(self_or_first, *args, **kwargs)

        import inspect
        wrapper = async_wrapper if inspect.iscoroutinefunction(f) else sync_wrapper
        wrapper._rzv_governed = True  # type: ignore
        wrapper._rzv_action = gate_action  # type: ignore
        return wrapper  # type: ignore

    if fn is not None:
        return decorator(fn)
    return decorator


# ── GovernedKernelPlugin — base class ─────────────────────────────────────────

class GovernedKernelPlugin:
    """
    Semantic Kernel plugin base class with constitutional governance.

    Mix this into any SK plugin to make @governed_kernel_function
    decorators automatically pick up the RzvClient from self.

    Example
    -------
    class DocumentPlugin(GovernedKernelPlugin):
        rzv_client = RzvClient(gateway="http://localhost:8443")
        rzv_agent_id = "azure-doc-agent"

        @governed_kernel_function
        @kernel_function(name="summarize", description="Summarize a document")
        async def summarize(self, document: str) -> str:
            return await llm.summarize(document)

        @governed_kernel_function
        @kernel_function(name="classify", description="Classify document type")
        async def classify(self, document: str) -> str:
            return await classifier.classify(document)

    # Add to kernel
    kernel = Kernel()
    kernel.add_plugin(DocumentPlugin(), plugin_name="docs")
    """

    rzv_client: Optional[Any] = None
    rzv_agent_id: str = "sk-agent"
    rzv_deed_cvid: Optional[str] = None

    def get_rzv_metadata(self) -> dict:
        """Return RSBIS metadata for this plugin."""
        return {
            "rzv_governed": True,
            "rzv_agent_id": self.rzv_agent_id,
            "rzv_genesis": (
                "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996b"
                "fdefb62aa8a045ccb63158867"
            ),
        }
