"""
HttpAdapter — Generic REST API adapter with constitutional governance.

Wraps any REST API and gates every request through the constitutional
gate before execution. Works with any service that has a REST API.

Usage:
    from rootzerovault import RzvClient
    from rootzerovault.adapters import HttpAdapter

    rzv = RzvClient(gateway="http://localhost:8443")

    # Wrap any REST API
    adapter = HttpAdapter(
        rzv=rzv,
        base_url="https://api.mybank.com",
        deed_cvid="cvid:blake3:...",
        headers={"Authorization": "Bearer my-token"},
    )

    # GET — always passes gate (read-only)
    accounts = adapter.get("/accounts")

    # POST — gated before execution
    tx = adapter.post("/transfers", {
        "amount": 50_000,
        "to_account": "ACC-12345",
    })

    # PUT — gated before execution
    adapter.put("/accounts/123", {"status": "active"})

    # DELETE — always gated, requires explicit allow
    adapter.delete("/records/456", action="DELETE_RECORD")
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .base import BaseAdapter
from ..client import RzvClient
from ..governance import GateAction
from ..exceptions import RzvGatewayError


class HttpAdapter(BaseAdapter):
    """
    Generic REST API adapter with constitutional governance.

    Every mutating request (POST, PUT, PATCH, DELETE) is evaluated by
    the constitutional gate before execution. GET requests pass through
    by default (read-only — no chain entry needed).

    Parameters
    ----------
    rzv : RzvClient
        Configured Root Zero Vault client.
    base_url : str
        Base URL of the REST API to wrap.
    deed_cvid : str, optional
        Governing deed CVID.
    headers : dict, optional
        Default headers for all requests (auth tokens, API keys, etc.)
    timeout : float
        Request timeout in seconds (default 10.0).
    gate_reads : bool
        If True, also gate GET requests (default False).
    """

    ADAPTER_ID = "http-adapter"

    def __init__(
        self,
        rzv: RzvClient,
        base_url: str,
        deed_cvid: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 10.0,
        gate_reads: bool = False,
    ) -> None:
        super().__init__(rzv, deed_cvid=deed_cvid)
        self._base_url = base_url.rstrip("/")
        self._headers = headers or {}
        self._timeout = timeout
        self._gate_reads = gate_reads

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """
        GET request. Passes through by default (read-only).
        Set gate_reads=True in constructor to gate reads too.
        """
        if self._gate_reads:
            result = self.gate("HTTP_GET", {"path": path})
            result.assert_accepted()

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(
                self._base_url + path,
                params=params,
                headers=self._headers,
            )
            resp.raise_for_status()
            return resp.json()

    def post(
        self,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        action: Optional[str] = None,
        gate_payload: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        POST request — gated before execution.

        Parameters
        ----------
        path : str
            API path.
        body : dict, optional
            Request body.
        action : str, optional
            Gate action type. Defaults to "HTTP_POST_{PATH}".
        gate_payload : dict, optional
            Custom payload for gate evaluation. Defaults to body.
        """
        gate_action = action or f"HTTP_POST_{path.strip('/').upper().replace('/', '_')}"
        result = self.gate(gate_action, gate_payload or body or {})
        result.assert_accepted()

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                self._base_url + path,
                json=body,
                headers=self._headers,
            )
            resp.raise_for_status()

        self.seal("POST_EXECUTED", {"path": path, "action": gate_action})
        return resp.json()

    def put(
        self,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        action: Optional[str] = None,
    ) -> Any:
        """PUT request — gated before execution."""
        gate_action = action or f"HTTP_PUT_{path.strip('/').upper().replace('/', '_')}"
        result = self.gate(gate_action, body or {})
        result.assert_accepted()

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.put(
                self._base_url + path,
                json=body,
                headers=self._headers,
            )
            resp.raise_for_status()
            return resp.json()

    def patch(
        self,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        action: Optional[str] = None,
    ) -> Any:
        """PATCH request — gated before execution."""
        gate_action = action or f"HTTP_PATCH_{path.strip('/').upper().replace('/', '_')}"
        result = self.gate(gate_action, body or {})
        result.assert_accepted()

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.patch(
                self._base_url + path,
                json=body,
                headers=self._headers,
            )
            resp.raise_for_status()
            return resp.json()

    def delete(
        self,
        path: str,
        action: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """DELETE request — always gated."""
        gate_action = action or f"HTTP_DELETE_{path.strip('/').upper().replace('/', '_')}"
        result = self.gate(gate_action, payload or {"path": path})
        result.assert_accepted()

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.delete(
                self._base_url + path,
                headers=self._headers,
            )
            resp.raise_for_status()
            return resp.json() if resp.content else {}
