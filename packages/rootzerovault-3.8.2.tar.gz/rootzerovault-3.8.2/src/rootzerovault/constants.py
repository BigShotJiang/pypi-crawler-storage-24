"""Constants for the Root Zero Vault SDK."""

#: The genesis CVID — frozen constitutional anchor.
#: This is the blake3 hash of the genesis deed bytes.
#: It is immutable and never changes.
GENESIS_CVID: str = (
    "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867"
)

#: WASM engine version
ENGINE_VERSION: str = "2.0.1"

#: Python SDK version
SDK_VERSION: str = "3.0.1"

#: Default gateway port
DEFAULT_PORT: int = 8443

#: Default request timeout in seconds
DEFAULT_TIMEOUT: float = 10.0

#: Constitutional rule count (frozen at genesis)
RULE_COUNT: int = 18
