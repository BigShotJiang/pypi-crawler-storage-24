"""
Governance API — High-level constitutional governance for Python.

This is the primary API for Option A adapters (Faramesh plugins).
Every adapter wraps a third-party system and calls these methods
to route actions through the constitutional gate.

Quick start:
    from rootzerovault import RzvClient
    from rootzerovault.governance import GovernanceClient

    rzv = RzvClient(gateway="http://localhost:8443")
    gov = GovernanceClient(rzv)

    # Evaluate any action
    result = gov.gate(
        action="TRANSFER_FUNDS",
        payload={"amount": 847_000_000, "destination": "OffshoreVehicle"},
        agent_id="finance-ai-001",
    )
    if not result.accepted:
        raise RuntimeError(f"Blocked: {result.reason_code}")

    # Canonicalize and get CVID for any YAML
    canon = gov.canon("action: TRANSFER_FUNDS\\namount: 100000")
    print(canon.cvid)  # cvid:blake3:...

    # Sign an artifact
    signed = gov.sign("action: DEED_REGISTRATION\\nts: 2026-01-01T00:00:00Z")
    print(signed.signature)  # base64 Ed25519

    # Seal a governed communication
    msg = gov.seal_comms(
        from_deed="EGYPT0",
        to_deed="EGYPT-CentralBank",
        message="Q3 budget directive",
    )
    print(msg.cvid)  # cvid:blake3:...

Egypt deployment:
    rzv = RzvClient(gateway="https://vault.mcit.gov.eg")
    gov = GovernanceClient(rzv)
    result = gov.gate("AI_MODEL_DEPLOY", payload={"model": "llm-v2", "scope": "ministry"})
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional

from .client import RzvClient
from .exceptions import RzvGatewayError, RzvNotConfiguredError
from .models import ValidationResult


# ── Canon result ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class CanonResult:
    """Result of canonicalization — deterministic bytes + CVID."""

    #: The canonical YAML text (sorted keys, deterministic)
    canon: str

    #: CVID — blake3 hash of the canonical bytes
    cvid: str

    @property
    def is_valid_cvid(self) -> bool:
        return self.cvid.startswith("cvid:blake3:") and len(self.cvid) == 76

    def __str__(self) -> str:
        return f"CanonResult(cvid={self.cvid})"


# ── Sign result ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class SignResult:
    """Result of signing an artifact."""

    cvid: str
    signature: str
    algorithm: str
    ts: str
    canon: str

    def __str__(self) -> str:
        return f"SignResult(cvid={self.cvid}, alg={self.algorithm})"


# ── Comms result ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class CommsResult:
    """Result of sealing a governed communication."""

    cvid: str
    outcome: str
    from_deed: str
    to_deed: str
    ts: str
    ttl_seconds: int
    proof: Dict[str, Any] = field(default_factory=dict)

    @property
    def sealed(self) -> bool:
        return self.outcome == "ACCEPT"

    def __str__(self) -> str:
        status = "SEALED" if self.sealed else "BLOCKED"
        return f"CommsResult({status}, cvid={self.cvid})"


# ── Chain entry ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ChainEntry:
    """A single entry in the constitutional evidence chain."""

    seq: int
    event_type: str
    cvid: str
    ts: str
    deed_cvid: Optional[str] = None
    correlation_id: Optional[str] = None
    parent_hash: Optional[str] = None
    hash: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ChainEntry":
        return cls(
            seq=d.get("seq", 0),
            event_type=d.get("event_type", d.get("outcome", "EVENT")),
            cvid=d.get("hash", d.get("cvid", "")),
            ts=d.get("ts", ""),
            deed_cvid=d.get("deed_cvid"),
            correlation_id=d.get("correlation_id"),
            parent_hash=d.get("parent_hash"),
            hash=d.get("hash"),
        )


# ── Gate action ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class GateAction:
    """
    A constitutional gate evaluation result.

    Wraps ValidationResult with higher-level gate semantics.
    """

    outcome: Literal["ACCEPT", "REJECT"]
    action: str
    agent_id: str
    cvid: Optional[str]
    reason_code: Optional[str]
    violations: List[Any] = field(default_factory=list)
    duration_ms: Optional[float] = None
    live: bool = False

    @property
    def accepted(self) -> bool:
        return self.outcome == "ACCEPT"

    @property
    def rejected(self) -> bool:
        return self.outcome == "REJECT"

    def __bool__(self) -> bool:
        return self.accepted

    def assert_accepted(self) -> "GateAction":
        """Raise RzvGatewayError if rejected. Returns self if accepted."""
        if self.rejected:
            raise RzvGatewayError(
                f"Constitutional gate blocked action '{self.action}': "
                f"{self.reason_code or 'unknown rule'}"
            )
        return self

    def __str__(self) -> str:
        if self.accepted:
            return f"GateAction(ACCEPT, action={self.action}, cvid={self.cvid})"
        return (
            f"GateAction(REJECT, action={self.action}, "
            f"reason={self.reason_code}, violations={len(self.violations)})"
        )


# ── GovernanceClient ──────────────────────────────────────────────────────────

class GovernanceClient:
    """
    High-level constitutional governance API.

    This is what Faramesh adapter plugins use. Every method maps to a
    gateway endpoint and returns a typed result.

    All methods work in demo mode (no gateway) with simulated responses
    so adapters can be developed and tested without a running gateway.

    Parameters
    ----------
    rzv : RzvClient
        Configured Root Zero Vault client.
    deed_cvid : str, optional
        The governing deed CVID. Defaults to genesis CVID.
    demo_mode : bool
        Force demo mode even if gateway is configured.
    """

    GENESIS_CVID = (
        "cvid:blake3:1544ff7dd978d911083bd60a7a4e6ba9647996bfdefb62aa8a045ccb63158867"
    )

    def __init__(
        self,
        rzv: RzvClient,
        deed_cvid: Optional[str] = None,
        demo_mode: bool = False,
    ) -> None:
        self._rzv = rzv
        self._deed_cvid = deed_cvid or self.GENESIS_CVID
        self._demo_mode = demo_mode

    @property
    def is_live(self) -> bool:
        """True if connected to a real gateway and not in demo mode."""
        return self._rzv.is_live and not self._demo_mode

    # ── Gate ─────────────────────────────────────────────────────────────────

    def gate(
        self,
        action: str,
        payload: Optional[Dict[str, Any]] = None,
        agent_id: str = "python-sdk",
        correlation_id: Optional[str] = None,
    ) -> GateAction:
        """
        Evaluate an action through the 18-rule constitutional gate.

        This is the core method for all Faramesh adapters. Every action
        your adapter takes should pass through gate() before execution.

        Parameters
        ----------
        action : str
            The action type (e.g. "TRANSFER_FUNDS", "AI_MODEL_DEPLOY").
        payload : dict, optional
            Action-specific payload fields.
        agent_id : str
            ID of the agent proposing the action.
        correlation_id : str, optional
            Correlation ID for the journal entry.

        Returns
        -------
        GateAction
            Use .accepted / .rejected or bool() to check outcome.
            Call .assert_accepted() to raise on rejection.

        Examples
        --------
        # Simple check
        result = gov.gate("TRANSFER_FUNDS", {"amount": 100_000})
        if result.rejected:
            log.warn(f"Blocked: {result.reason_code}")

        # Raise on rejection (fail-closed)
        gov.gate("AI_MODEL_DEPLOY", {"model": "gpt-4"}).assert_accepted()
        """
        import time
        start = time.monotonic()
        cid = correlation_id or str(uuid.uuid4())

        if not self.is_live:
            return self._demo_gate(action, payload or {}, agent_id, cid)

        # Build artifact YAML
        payload_lines = "\n".join(
            f"  {k}: \"{v}\"" for k, v in (payload or {}).items()
        )
        artifact_yaml = (
            f"agent: \"{agent_id}\"\n"
            f"action: \"{action}\"\n"
            f"payload:\n{payload_lines}\n"
        )

        try:
            data = self._rzv._post_sync("/v1/validate", {
                "correlation_id": cid,
                "deed_cvid": self._deed_cvid,
                "request_ts": _now_ts(),
                "artifact_yaml": artifact_yaml,
            })
            outcome = data.get("outcome", "REJECT")
            duration_ms = (time.monotonic() - start) * 1000
            return GateAction(
                outcome=outcome,
                action=action,
                agent_id=agent_id,
                cvid=data.get("cvid"),
                reason_code=data.get("reason_code"),
                violations=data.get("violations", []),
                duration_ms=round(duration_ms, 2),
                live=True,
            )
        except Exception as e:
            # Fail-closed: any infrastructure error = REJECT
            return GateAction(
                outcome="REJECT",
                action=action,
                agent_id=agent_id,
                cvid=None,
                reason_code="E-INFRASTRUCTURE",
                violations=[],
                duration_ms=None,
                live=False,
            )

    async def gate_async(
        self,
        action: str,
        payload: Optional[Dict[str, Any]] = None,
        agent_id: str = "python-sdk",
        correlation_id: Optional[str] = None,
    ) -> GateAction:
        """Async version of gate()."""
        import time
        start = time.monotonic()
        cid = correlation_id or str(uuid.uuid4())

        if not self.is_live:
            return self._demo_gate(action, payload or {}, agent_id, cid)

        payload_lines = "\n".join(
            f"  {k}: \"{v}\"" for k, v in (payload or {}).items()
        )
        artifact_yaml = (
            f"agent: \"{agent_id}\"\n"
            f"action: \"{action}\"\n"
            f"payload:\n{payload_lines}\n"
        )

        try:
            data = await self._rzv._post_async("/v1/validate", {
                "correlation_id": cid,
                "deed_cvid": self._deed_cvid,
                "request_ts": _now_ts(),
                "artifact_yaml": artifact_yaml,
            })
            outcome = data.get("outcome", "REJECT")
            duration_ms = (time.monotonic() - start) * 1000
            return GateAction(
                outcome=outcome,
                action=action,
                agent_id=agent_id,
                cvid=data.get("cvid"),
                reason_code=data.get("reason_code"),
                violations=data.get("violations", []),
                duration_ms=round(duration_ms, 2),
                live=True,
            )
        except Exception:
            return GateAction(
                outcome="REJECT",
                action=action,
                agent_id=agent_id,
                cvid=None,
                reason_code="E-INFRASTRUCTURE",
                violations=[],
                live=False,
            )

    # ── Canon ─────────────────────────────────────────────────────────────────

    def canon(self, yaml_text: str) -> CanonResult:
        """
        Canonicalize YAML and compute its CVID.

        Produces deterministic bytes — same input always produces
        same CVID, regardless of key ordering or whitespace.

        Parameters
        ----------
        yaml_text : str
            Raw YAML to canonicalize.

        Returns
        -------
        CanonResult
            .canon — canonical YAML text
            .cvid  — cvid:blake3:<hex>
        """
        if not self.is_live:
            return self._demo_canon(yaml_text)

        data = self._rzv._post_sync("/v1/canon", {"yaml": yaml_text})
        return CanonResult(
            canon=data.get("canon", yaml_text),
            cvid=data.get("cvid", "cvid:blake3:" + "0" * 64),
        )

    async def canon_async(self, yaml_text: str) -> CanonResult:
        """Async version of canon()."""
        if not self.is_live:
            return self._demo_canon(yaml_text)
        data = await self._rzv._post_async("/v1/canon", {"yaml": yaml_text})
        return CanonResult(
            canon=data.get("canon", yaml_text),
            cvid=data.get("cvid", "cvid:blake3:" + "0" * 64),
        )

    # ── Sign ──────────────────────────────────────────────────────────────────

    def sign(
        self,
        yaml_text: str,
        algorithm: str = "ed25519",
    ) -> SignResult:
        """
        Canonicalize and sign a YAML artifact with the gateway key.

        Parameters
        ----------
        yaml_text : str
            YAML to sign.
        algorithm : str
            Signing algorithm: 'ed25519' or 'dual' (Ed25519 + Dilithium3).

        Returns
        -------
        SignResult
            .cvid      — CVID of the canonical artifact
            .signature — base64-encoded signature
            .algorithm — algorithm used
            .ts        — timestamp of signing
        """
        if not self.is_live:
            return self._demo_sign(yaml_text, algorithm)

        data = self._rzv._post_sync("/v1/sign", {
            "yaml": yaml_text,
            "algorithm": algorithm,
        })
        return SignResult(
            cvid=data.get("cvid", ""),
            signature=data.get("signature", ""),
            algorithm=data.get("algorithm", algorithm),
            ts=data.get("ts", _now_ts()),
            canon=data.get("canon", yaml_text),
        )

    async def sign_async(self, yaml_text: str, algorithm: str = "ed25519") -> SignResult:
        """Async version of sign()."""
        if not self.is_live:
            return self._demo_sign(yaml_text, algorithm)
        data = await self._rzv._post_async("/v1/sign", {
            "yaml": yaml_text, "algorithm": algorithm,
        })
        return SignResult(
            cvid=data.get("cvid", ""),
            signature=data.get("signature", ""),
            algorithm=data.get("algorithm", algorithm),
            ts=data.get("ts", _now_ts()),
            canon=data.get("canon", yaml_text),
        )

    # ── Comms ─────────────────────────────────────────────────────────────────

    def seal_comms(
        self,
        from_deed: str,
        to_deed: str,
        message: str,
        ttl_seconds: int = 300,
    ) -> CommsResult:
        """
        Seal a governed communication between two deed holders.

        Every message is evaluated by the constitutional gate before
        sealing. The proof packet travels with the message.

        Parameters
        ----------
        from_deed : str
            Sender's deed coordinate (e.g. "EGYPT0").
        to_deed : str
            Recipient's deed coordinate (e.g. "EGYPT-CentralBank").
        message : str
            Message content.
        ttl_seconds : int
            Message time-to-live in seconds (default 300).

        Returns
        -------
        CommsResult
            .sealed — True if constitutional gate accepted
            .cvid   — CVID of the sealed communication
            .proof  — Full proof packet
        """
        if not self.is_live:
            return self._demo_comms(from_deed, to_deed, message, ttl_seconds)

        data = self._rzv._post_sync("/v1/comms/seal", {
            "from": from_deed,
            "to": to_deed,
            "message": message,
            "ttl_seconds": ttl_seconds,
        })
        return CommsResult(
            cvid=data.get("cvid", ""),
            outcome=data.get("outcome", "REJECT"),
            from_deed=from_deed,
            to_deed=to_deed,
            ts=data.get("ts", _now_ts()),
            ttl_seconds=ttl_seconds,
            proof=data.get("proof", {}),
        )

    async def seal_comms_async(
        self,
        from_deed: str,
        to_deed: str,
        message: str,
        ttl_seconds: int = 300,
    ) -> CommsResult:
        """Async version of seal_comms()."""
        if not self.is_live:
            return self._demo_comms(from_deed, to_deed, message, ttl_seconds)
        data = await self._rzv._post_async("/v1/comms/seal", {
            "from": from_deed, "to": to_deed,
            "message": message, "ttl_seconds": ttl_seconds,
        })
        return CommsResult(
            cvid=data.get("cvid", ""),
            outcome=data.get("outcome", "REJECT"),
            from_deed=from_deed, to_deed=to_deed,
            ts=data.get("ts", _now_ts()),
            ttl_seconds=ttl_seconds,
            proof=data.get("proof", {}),
        )

    # ── Chain ─────────────────────────────────────────────────────────────────

    def chain(self, limit: int = 20) -> List[ChainEntry]:
        """
        Get the most recent entries from the evidence chain.

        Parameters
        ----------
        limit : int
            Number of entries to return (default 20, max 200).

        Returns
        -------
        List[ChainEntry]
            Most recent entries, newest first.
        """
        if not self.is_live:
            return []

        data = self._rzv._get_sync(f"/v1/chain?limit={min(limit, 200)}")
        entries = data.get("entries", [])
        return [ChainEntry.from_dict(e) for e in entries]

    async def chain_async(self, limit: int = 20) -> List[ChainEntry]:
        """Async version of chain()."""
        if not self.is_live:
            return []
        data = await self._rzv._get_async(f"/v1/chain?limit={min(limit, 200)}")
        return [ChainEntry.from_dict(e) for e in data.get("entries", [])]

    def append_chain(
        self,
        event_type: str,
        payload: Optional[Dict[str, Any]] = None,
        deed_cvid: Optional[str] = None,
    ) -> ChainEntry:
        """
        Seal a custom event to the evidence chain.

        Parameters
        ----------
        event_type : str
            Event type identifier (e.g. "AI_MODEL_DEPLOYED").
        payload : dict, optional
            Event payload.
        deed_cvid : str, optional
            Governing deed CVID. Uses client default if absent.
        """
        if not self.is_live:
            return ChainEntry(
                seq=0, event_type=event_type,
                cvid="cvid:blake3:" + "0" * 64,
                ts=_now_ts(),
            )

        data = self._rzv._post_sync("/v1/chain/append", {
            "event_type": event_type,
            "payload": payload or {},
            "deed_cvid": deed_cvid or self._deed_cvid,
        })
        return ChainEntry(
            seq=0,
            event_type=event_type,
            cvid=data.get("cvid", ""),
            ts=data.get("ts", _now_ts()),
        )

    # ── Demo mode fallbacks ───────────────────────────────────────────────────

    def _demo_gate(
        self,
        action: str,
        payload: Dict[str, Any],
        agent_id: str,
        cid: str,
    ) -> GateAction:
        """Simulate gate evaluation in demo mode."""
        blocked_keywords = {
            "optimized", "override", "bypass", "847000000",
            "tampered", "autonomous", "revoke",
        }
        action_lower = action.lower()
        payload_str = str(payload).lower()
        is_blocked = (
            any(k in action_lower for k in blocked_keywords) or
            any(k in payload_str for k in blocked_keywords)
        )
        return GateAction(
            outcome="REJECT" if is_blocked else "ACCEPT",
            action=action,
            agent_id=agent_id,
            cvid="cvid:blake3:" + _demo_hex(),
            reason_code="L014" if is_blocked else None,
            violations=[],
            duration_ms=0.3,
            live=False,
        )

    def _demo_canon(self, yaml_text: str) -> CanonResult:
        lines = sorted(yaml_text.strip().split("\n"))
        canon = "\n".join(lines) + "\n"
        return CanonResult(
            canon=canon,
            cvid="cvid:blake3:" + _demo_hex(),
        )

    def _demo_sign(self, yaml_text: str, algorithm: str) -> SignResult:
        return SignResult(
            cvid="cvid:blake3:" + _demo_hex(),
            signature="DEMO_SIG_" + _demo_hex(16),
            algorithm=algorithm,
            ts=_now_ts(),
            canon=yaml_text,
        )

    def _demo_comms(
        self,
        from_deed: str,
        to_deed: str,
        message: str,
        ttl_seconds: int,
    ) -> CommsResult:
        return CommsResult(
            cvid="cvid:blake3:" + _demo_hex(),
            outcome="ACCEPT",
            from_deed=from_deed,
            to_deed=to_deed,
            ts=_now_ts(),
            ttl_seconds=ttl_seconds,
            proof={"algorithm": "Ed25519", "demo": True},
        )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _now_ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _demo_hex(n: int = 32) -> str:
    import random
    return "".join(random.choices("0123456789abcdef", k=n * 2))
