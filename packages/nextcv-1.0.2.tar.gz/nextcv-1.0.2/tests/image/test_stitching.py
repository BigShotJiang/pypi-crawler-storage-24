"""Tests for image stitching functionality."""

import numpy as np
import pytest

from nextcv.image.stitching import (
    AdditiveCompensator,
    LeftRightStitcher,
    NoOpCompensator,
)
from nextcv.sensors import PinholeCamera


class TestLeftRightStitcher:
    """Test cases for LRStitcher class."""

    @pytest.fixture
    def stitcher(self):
        """Create a stitcher instance for testing."""
        # Use hardcoded camera values instead of fixture
        t1 = PinholeCamera(
            width=640,
            height=512,
            fx=1487.0897209580626,
            fy=1486.893999534694,
            cx=319.5,
            cy=255.5,
            roll=-0.6953680852913573,
            pitch=0.3175409097871985,
            yaw=10.942382806743069,
        )
        t2 = PinholeCamera(
            width=640,
            height=512,
            fx=1492.120223972608,
            fy=1492.126838008826,
            cx=319.5,
            cy=255.5,
            roll=-0.25389265482939055,
            pitch=0.7082357267631507,
            yaw=-11.468243408503717,
        )
        return LeftRightStitcher(left_camera=t1, right_camera=t2)

    def test_stitcher_initialization(self, stitcher: LeftRightStitcher):
        """Test that stitcher initializes correctly."""
        assert stitcher is not None
        assert stitcher.virtual_camera is not None
        assert stitcher.virtual_camera.width > 0
        assert stitcher.virtual_camera.height > 0

    def test_stitching_no_op_comepnsator(self, stitcher: LeftRightStitcher):
        """Test that stitched values lie between input values (as requested by user)."""
        # Create left image with constant intensity
        left_img = np.full((512, 640), 16000, dtype=np.uint16)
        # Create right image with different constant intensity
        right_img = np.full((512, 640), 24000, dtype=np.uint16)

        # Stitch the images
        stitched = stitcher([left_img, right_img])

        # Verify output properties
        assert stitched.shape[0] == 472  # Height is cropped to overlapping region
        assert stitched.shape[1] > 640  # Width should be larger (stitched)
        assert stitched.dtype == np.uint16
        assert np.sum(stitched == 0) == 0  # No black pixels

        # The key test: stitched values should lie between the input values
        assert stitched.min() >= 16000  # Should not go below left image value
        assert stitched.max() <= 24000  # Should not go above right image value

    def test_stitching_additive_compensator(self, stitcher: LeftRightStitcher):
        """Test that stitched values match the left (ref) image values."""
        # Create left image with constant intensity
        left_img = np.full((512, 640), 16000, dtype=np.uint16)
        # Create right image with different constant intensity
        right_img = np.full((512, 640), 24000, dtype=np.uint16)

        # Stitch the images
        stitcher.compensator = AdditiveCompensator()
        stitched = stitcher([left_img, right_img])
        stitcher.compensator = NoOpCompensator()  # reset

        # Verify output properties
        assert stitched.shape[0] == 472  # Height is cropped to overlapping region
        assert stitched.shape[1] > 640  # Width should be larger (stitched)
        assert stitched.dtype == np.uint16
        assert np.sum(stitched == 0) == 0  # No black pixels

        # The key test: stitched values should match reference within relative tolerance
        assert abs(float(stitched.min()) - 16000) / 16000 <= 1e-3
        assert abs(float(stitched.max()) - 16000) / 16000 <= 1e-3
