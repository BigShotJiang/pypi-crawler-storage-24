from gr_sch_helper.sch import get_config

class MyTypst:
    def __init__(self):
        self.SCH_NAME = get_config("Στοιχεία", "όνομα_σχολείου")
        self.SCH_PHONE = get_config("Στοιχεία", "τηλέφωνο")
        self.SCH_ADDR = get_config("Στοιχεία", "διεύθυνση")
        self.SCH_MAIL = get_config("Στοιχεία", "email")

    def before(self, sch_year, date, title):
            return f'''
            #set document(title: [{title}])
            
            #set page(
            margin: (x: 2cm, y: 1cm),
            header: context [
            #set text(size: 8pt)
            #set align(right)
            #counter(page).display("1/1",both: true)
            ],
            )
            
            #set text(lang: "el")
            
            #align(center)[
            #set par(spacing: 0.6em)
            #text(size: 14pt, weight: "bold")[
            {self.SCH_NAME} \\
            ]
            #set par(leading: 0.5em)
            #text(size: 10pt)[
            {self.SCH_ADDR} \\
            Τηλέφωνο: {self.SCH_PHONE} \\
            Email: {self.SCH_MAIL.split('@')[0]}\\@{self.SCH_MAIL.split('@')[1]}
            ]
        ]

        #align(right)[
            #grid(
            columns: (auto, auto),
            gutter:8pt,
            align(right)[#text(size: 8pt)[
            Σχολικό έτος: \\
            Ημερομηνία:]],
            align(right)[#text(size: 8pt)[
            {sch_year} \\
            {date}]]
            )
        ]
        #let student(body) = {{
            set text(size: 10pt, weight: "bold")
            [#body]
            }}
            
            = {title}
'''
