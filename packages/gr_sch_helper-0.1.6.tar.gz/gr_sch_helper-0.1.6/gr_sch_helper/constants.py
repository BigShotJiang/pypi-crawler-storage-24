import re

APOF_ID = "cbpCriteria_chkIsForAdditionalSpeciality_S_D"
APOF_STATES = {
    "APOF":"dxWeb_edtCheckBoxChecked",
    "NO_APOF":"dxWeb_edtCheckBoxUnChecked",
    "BOTH":"dxWeb_edtCheckBoxGreyed",
    }
GRADES = ['Α','Β','Γ']


class ShortCode:
    report_base = "https://app.myschool.sch.gr/Report.bas.aspx?rpt="
    def __init__(self,url,basename):
        self.url = self.report_base + url
        self.basename = basename

# όνομα αναφοράς - αριθμός url - όνομα αρχείου (χωρίς κατάληξη)
report_shortcodes = {
    "Γενικά στοιχεία εργαζόμενων":ShortCode("25","rptList"),
    "Γενικά στοιχεία μαθητών":ShortCode("64","rptList"),
    "Κατάσταση Παιδαγωγικών μέτρων":ShortCode("8","rptList"),
    "Τμήματα μαθητή":ShortCode("178","rptList"),
    "Δελτίο κίνησης - 1":ShortCode("175","175"),
    "Αναλυτική κατάσταση απουσιών":ShortCode("2","rptList")
}

page_urls = {
    "Κατάλογος μαθητών":"https://app.myschool.sch.gr/Student.list.aspx?action=list&clear=1",
    "Απουσίες μαθητή":"https://app.myschool.sch.gr/Student.edit.leav.aspx",
}

absenceJustificationTypeId = {
    "0":0,            #<empty string> debugger eval code:6:13
    "άρθρο 21":1279,  # Περ. αρθ. 21 της 102791/ΓΔ4 (ΦΕΚ 5130/τ.Β΄/10-09-2024) debugger eval code:6:13
    "άρθρο 23":1328,  # Περ. αρθ. 23 της 102791/ΓΔ4 (ΦΕΚ 5130/τ.Β΄/10-09-2024) debugger eval code:6:13
    "άρθρο 25":1377,  # Περ. αρθ. 25 της 102791/ΓΔ4 (ΦΕΚ 5130/τ.Β΄/10-09-2024) debugger eval code:6:13
    "γιατρός":1426,   # Ιατρική Βεβαίωση {Αρθ. 26 της 102791/ΓΔ4 (ΦΕΚ 5130/τ.Β΄/10-09-2024)} debugger eval code:6:13
    "κηδεμόνας":1475, # Υπεύθυνη Δήλωση Κηδεμόνα {(Αρθ. 26 της 102791/ΓΔ4 (ΦΕΚ 5130/τ.Β΄/10-09-2024} debugger eval code:6:13
    "γρίπη":1531,     # Λόγω εποχικών ιογενών αναπνευστικών λοιμώξεων
}

absenceTypeId = {
    "0":0,         #  <empty string>
    "Ωριαία":630,  # Προφορική παρατήρηση με ωριαία απομάκρυνση
    "1 μέρα":698,  # Αποβολή από τα μαθήματα μιας (01) ημέρας
    "2 μέρες":747, # Αποβολή από τα μαθήματα δυο (02) ημερών
    "3 μέρες":796, # Αποβολή από τα μαθήματα τριών (03) ημερών
    "4 μέρες":845, # Αποβολή από τα μαθήματα τεσσάρων (04) ημερών
    "5 μέρες":894, # Αποβολή από τα μαθήματα πέντε (05) ημερών
}

class js_scripts:
    apousies_prep_script = re.sub(r"\s+"," ","""
    window.FIELDS = {
      DateFrom: "DateFrom",
      Qty: "Qty",
      JustifiedQty: "JustifiedQty",
      StudentAbsenceJustificationTypeId: "StudentAbsenceJustificationTypeId",
      StudentAbsenceTypeId: "StudentAbsenceTypeId",
    };

    window.autoEditQueue = {
      _queue: [],
      _busy: false,

      enqueue(rowIndex, values) {
        return new Promise(resolve => {
            this._queue.push({ rowIndex, values, resolve });
            this._process();
        });
      },

      async _process() {
        if (this._busy || this._queue.length === 0) return;
        this._busy = true;

        const { rowIndex, values, resolve } = this._queue.shift();
        await this._run(rowIndex, values);
        resolve(); 

        this._busy = false;
        this._process();
      },

      _run(rowIndex, values) {
        return new Promise(resolve => {
            function onUpdateFinished(s, e) {
                s.EndCallback.RemoveHandler(onUpdateFinished);
                resolve();
            }

            function onEditFormReady(s, e) {
                s.EndCallback.RemoveHandler(onEditFormReady);

                Object.values(FIELDS).forEach(field => {
                    if (values[field] != null) s.SetEditValue(field, values[field]);
                });

                s.EndCallback.AddHandler(onUpdateFinished);
                s.UpdateEdit();
            }

            gridStudentAbsenceSummary.EndCallback.AddHandler(onEditFormReady);

            if (rowIndex === -1) {
                gridStudentAbsenceSummary.AddNewRow();
            } else {
                gridStudentAbsenceSummary.StartEditRow(rowIndex);
            }
        });
    }
};

window.startAutoEdit = function(rowIndex, values) {
    return autoEditQueue.enqueue(rowIndex, values);
};
""")
    
