# Vermillio Core SDK

Core python components (clients and models) for interacting with Vermillio API's. Other packages are built on top of this.

## Install

```bash
pip install vermillio-sdk[core]
```

## Configuration

The client loads credentials from environment variables by default:
- `VERMILLIO_SDK_CLIENT_ID`
- `VERMILLIO_SDK_CLIENT_SECRET`

For alternative methods, see `vermillio.sdk.core.config`.
