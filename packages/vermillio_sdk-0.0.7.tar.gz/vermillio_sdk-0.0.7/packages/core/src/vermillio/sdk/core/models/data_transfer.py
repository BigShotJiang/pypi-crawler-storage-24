from enum import Enum
from typing import List, Optional, Set
from pydantic import BaseModel, field_serializer
from .assets import AssetMetadata, AssetType, AssetVisibility, AssetProperty


class UploadStatus(str, Enum):
    Pending = "Pending"
    Completed = "Completed"
    Failed = "Failed"


class MediaDto(BaseModel):
    id: Optional[str] = None
    path: str
    filename: Optional[str] = None
    status: Optional[UploadStatus] = UploadStatus.Pending
    upload_id: Optional[str] = None
    asset_id: Optional[str] = None


class VideoCategory(str, Enum):
    Animation = "Animation"
    Gaming = "Gaming"


class VideoMetadata(BaseModel):
    # partner submitted
    category: VideoCategory
    height: int
    width: int
    framerate: str
    content_title: str
    episode_number: Optional[int] = None
    episode_title: Optional[str] = None

    # vermillio generated
    codec: Optional[str] = None
    bitrate: Optional[str] = None
    duration: Optional[str] = None
    size_in_bytes: Optional[int] = None

    audio_codec: Optional[str] = None
    audio_bitrate: Optional[str] = None
    audio_sample_rate: Optional[int] = None

    md5_checksum: Optional[str] = None
    language: Optional[str] = None
    transcript: Optional[str] = None


class UseCase(str, Enum):
    AppDevelopment = "App Development"
    GameDevelopment = "Game Development"
    SyntheticContent = "Synthetic Content"
    Merchandise = "Merchandise"
    AIModels = "AI Models"


class AssetDto(BaseModel):
    id: Optional[str] = None
    parentAssetId: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    type: AssetType
    visibility: Optional[AssetVisibility] = "Private"
    labels: Optional[List[str]] = None
    media: List[MediaDto]
    property: Optional[AssetProperty] = None
    useCases: Optional[List[UseCase]] = [UseCase.AIModels, UseCase.SyntheticContent]
    metadata: Optional[AssetMetadata] = None


class FileUploadMetadata(BaseModel):
    id: Optional[str] = None
    created_at: Optional[float] = None
    updated_at: Optional[float] = None
    owner_id: Optional[str] = None
    asset_metadata: List[AssetDto]
    zipped: Optional[bool] = False
    status: Optional[UploadStatus] = UploadStatus.Pending


class UploadBatch(BaseModel):
    id: str = None
    owner_id: str
    created_at: Optional[float] = None
    media: Optional[List[MediaDto]] = []
    status: UploadStatus = UploadStatus.Pending


class UploadBatchRequest(BaseModel):
    batch_size_per_upload: int
    upload_ids: Optional[List[str]] = None
    first_media_id: Optional[str] = None


class ScanJob(BaseModel):
    id: Optional[str] = None
    upload_id: Optional[str] = None
    owner_id: Optional[str] = None
    root_path: str
    scanned_paths: Set[str] = []
    status: UploadStatus = UploadStatus.Pending

    @field_serializer("scanned_paths")
    def serialize_scanned_paths(self, scanned_paths: Set[str]) -> List[str]:
        return list(scanned_paths)
