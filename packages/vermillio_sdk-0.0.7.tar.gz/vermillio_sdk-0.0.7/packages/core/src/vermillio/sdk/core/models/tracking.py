from enum import Enum
from typing import Dict, List, Optional
from .base import BaseCamelModel
from pydantic_extra_types.currency_code import ISO4217

class AssetAction(str, Enum):
    Publish = "Publish"

class AssetUsageRequest(BaseCamelModel):
    title: str
    parent_asset_ids: List[str]
    count: Optional[int] = None
    data: Optional[Dict] = None

class AssetActionRequest(BaseCamelModel):
    action: AssetAction
    asset_ids: List[str]
    location: Optional[str] = None
    data: Optional[Dict] = None

class AssetRevenueRequest(BaseCamelModel):
    asset_ids: List[str]
    currency: ISO4217
    amount: float
    transaction_id: Optional[str] = None
    data: Optional[Dict] = None