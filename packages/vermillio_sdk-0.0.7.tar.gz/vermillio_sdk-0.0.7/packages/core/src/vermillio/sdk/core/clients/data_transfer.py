import aiofiles
from typing import Dict, List
from pydantic import RootModel
from cloudpathlib import AnyPath

from .base import VermillioBaseClient
from ..models.data_transfer import (
    FileUploadMetadata,
    ScanJob,
    UploadBatch,
    UploadBatchRequest,
)


class VermillioDataTransfer(VermillioBaseClient):
    def get_upload(self, id: str) -> FileUploadMetadata:
        res = self._get(
            f"/data_transfer/get_upload/{id}", RootModel[FileUploadMetadata]
        )
        return res.root if res else None

    def register_upload(self, upload: FileUploadMetadata, scan_id: str = None) -> str:
        print(scan_id)

        return self._post(
            "/data_transfer/register_upload",
            upload,
            str,
            params={"scan_id": scan_id},
        )

    async def file_upload(
        self, id: str, filepath: str, batch_id: str = None
    ) -> Dict[str, str]:
        async with aiofiles.open(AnyPath(filepath), "rb") as file:
            return await self._async_post(
                f"/data_transfer/file_upload/{id}",
                file,
                Dict[str, str],
                params={"filepath": filepath, "batch_id": batch_id},
            )

    def get_batch(self, batch_id: str) -> UploadBatch:
        res = self._get(f"/data_transfer/get_batch/{batch_id}", RootModel[UploadBatch])
        return res.root if res else None

    def start_batch(self, batch_request: UploadBatchRequest) -> UploadBatch:
        return self._post("/data_transfer/start_batch", batch_request, UploadBatch)

    def get_unfinished_batches(self) -> List[UploadBatch]:
        res = self._get(
            "/data_transfer/unfinished_batches", RootModel[List[UploadBatch]]
        )
        return res.root if res else None

    def get_scan(self, scan_id: str) -> ScanJob:
        res = self._get(f"/data_transfer/get_scan/{scan_id}", RootModel[ScanJob])
        return res.root if res else None

    def get_unfinished_scans(self) -> List[ScanJob]:
        res = self._get("/data_transfer/unfinished_scans", RootModel[List[ScanJob]])
        return res.root if res else None

    def register_scan(self, scan: ScanJob) -> ScanJob:
        return self._post("/data_transfer/register_scan", scan, ScanJob)
