from typing import Literal, Optional, Union
from pydantic import BaseModel, Field


class ExternalPipeline(BaseModel):
    id: str = Field(description="Unique id of the pipeline.")
    name: str = Field(description="The friendly name of the pipeline.")
    description: Optional[str] = Field(
        default=None, description="Description of what the purpose of this pipeline is."
    )
    created_at: float = Field(
        description="The epoch time in seconds of when this pipeline was created."
    )
    contexts: list[str] = Field(
        description="The list of contexts available in this pipeline."
    )
    default_context: str = Field(
        description="The default context used if none is provided in endpoints."
    )


class ExternalSource(BaseModel):
    source_id: Optional[str] = Field(
        default=None,
        description="A (optional) unique id for the source that represents this request in your system.",
    )


class PipelineRunRequest(BaseModel):
    context: Optional[str] = Field(
        default=None,
        description="Override the default context, if available, to run the source against.",
    )
    source: Union[ExternalSource, str] = Field(
        description="The source to run, either an external source or a path to a file (if the pipeline supports that).",
    )


class PipelineLoadRequest(BaseModel):
    context: Optional[str] = Field(
        default=None,
        description="Override the default context, if available, to load the sources against.",
    )
    sources: Union[list[ExternalSource], list[str]] = Field(
        description="The sources to load, either an external source or a path to a file (if the pipeline supports that).",
    )


PipelineSourceStatus = Literal[
    "Pending", "Running", "Succeeded", "Errored", "Failed", "Deleted"
]


class PipelineSource(BaseModel):
    id: str = Field(description="Vermillio's unique id for this pipeline source.")
    status: PipelineSourceStatus = Field(
        description="The status of the source, Pending=Awaiting processing. Running=Currently processing. Succeeded=Finished successully. Errored=Unexpected error occurred, will be retried. Failed=Finished unsuccessfully. Deleted=Marked for deletion."
    )
    created_at: float = Field(
        description="The epoch time in seconds of when this source was created."
    )
    updated_at: Optional[float] = Field(
        description="The last epoch time in seconds of when this source was last updated."
    )
    source_id: Optional[str] = Field(
        default=None,
        description="A (optional) unique id for the source that represents this request in your system.",
    )


class PipelineStatus(BaseModel):
    pending_count: int = Field(
        description="The number of sources under this context with status == 'Pending'"
    )
    running_count: int = Field(
        description="The number of sources under this context with status == 'Running'"
    )
    succeeded_count: int = Field(
        description="The number of sources under this context with status == 'Succeeded'"
    )
    errored_count: int = Field(
        description="The number of sources under this context with status == 'Errored'"
    )
    failed_count: int = Field(
        description="The number of sources under this context with status == 'Failed'"
    )


class PipelineResults(BaseModel):
    id: str = Field(description="Vermillio's unique id for this pipeline source.")
    status: PipelineSourceStatus = Field(
        description="The status of the source, Pending=Awaiting processing. Running=Currently processing. Succeeded=Finished successully. Errored=Unexpected error occurred, will be retried. Failed=Finished unsuccessfully. Deleted=Marked for deletion."
    )
    created_at: float = Field(
        description="The epoch time in seconds of when this source was created."
    )
    updated_at: Optional[float] = Field(
        description="The last epoch time in seconds of when this source was last updated."
    )
    source_id: Optional[str] = Field(
        default=None,
        description="A (optional) unique id for the source that represents this request in your system.",
    )
    source_path: Optional[str] = Field(
        default=None,
        description="The (optional) source path that was provided in the external source."
    )
    
    @property
    def is_finished(self) -> bool:
        return self.status in ["Succeeded", "Failed", "Deleted"]
