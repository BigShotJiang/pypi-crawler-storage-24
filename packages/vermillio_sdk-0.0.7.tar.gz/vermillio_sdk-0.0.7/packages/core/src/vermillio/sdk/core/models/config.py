import os
from typing import Optional

from .auth import OAuthCredentials


class VermillioConfig(OAuthCredentials):
    env: str = "prod"

    @classmethod
    def default(cls):
        """
        Gets the default global config.
        If none is set, defaults to `from_env`
        Returns:
            VermillioConfig: The default VermillioConfig object.
        """
        global _default
        if _default is None:
            _default = cls.from_env()
        return _default

    @classmethod
    def set_default(cls, config: "VermillioConfig"):
        """
        Sets the default global config, used when no config is provided to a client.
        """
        cls._default = config

    @classmethod
    def from_env(cls, env_prefix: str = "VERMILLIO_SDK_") -> "VermillioConfig":
        """
        Extracts a VermillioConfig from environment variables with the specified prefix.
        Args:
            env_prefix (str): Prefix used to construct final environment vars:
                              client_id = f"{env_prefix}CLIENT_ID"
                              client_secret = f"{env_prefix}CLIENT_SECRET"
        """
        key = f"{env_prefix}CLIENT_ID"
        client_id = os.environ.get(key)
        assert client_id, f"Missing required env var: {key}"
        key = f"{env_prefix}CLIENT_SECRET"
        client_secret = os.environ.get(key)
        assert client_secret, f"Missing required env var: {key}"
        env = os.environ.get(f"{env_prefix}ENV", "prod")
        return cls(
            env=env,
            client_id=client_id,
            client_secret=client_secret,
        )

    @classmethod
    def credentials(
        cls, client_id: str, client_secret: str, env: str = "prod"
    ) -> "VermillioConfig":
        return VermillioConfig(
            env=env,
            client_id=client_id,
            client_secret=client_secret,
        )

    @property
    def prod(self) -> bool:
        """
        Whether or not this is targeting production environment.
        Returns:
            bool: True if pointed at production, False otherwise.
        """
        return self.env == "prod"

    @property
    def auth_base_url(self) -> str:
        url = (
            "https://auth.cloud.vermill.io"
            if self.prod
            else "https://staging.auth.cloud.vermill.io"
        )
        return os.getenv("VERMILLIO_AUTH_URL", url)

    @property
    def trace_base_url(self) -> str:
        url = (
            "https://application.tce.cloud.vermill.io"
            if self.prod
            else f"https://application.tce.{self.env}.cloud.vermill.io"
        )
        return os.getenv("VERMILLIO_TRACE_BASE_URL", url)

    @property
    def external_pipeline_url(self) -> str:
        url = (
            "https://external-pipeline.tce.cloud.vermill.io"
            if self.prod
            else f"https://external-pipeline.tce.{self.env}.cloud.vermill.io"
        )
        return os.getenv("VERMILLIO_EXTERNAL_PIPELINE_URL", url)


_default: Optional[VermillioConfig] = None
