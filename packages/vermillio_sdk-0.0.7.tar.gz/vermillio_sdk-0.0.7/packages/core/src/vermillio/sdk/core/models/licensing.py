from typing import List, Literal
from .base import BaseCamelModel
from .assets import PartnerAsset

LicenseStatus = Literal["Requested", "Denied", "Ready", "Revised", "Revoked"]


class PartnerLicense(BaseCamelModel):
    id: str
    description: str
    status: LicenseStatus
    assets: List[PartnerAsset]
