from .base import VermillioBaseClient
from ..models.tracking import AssetAction, AssetActionRequest, AssetRevenueRequest, AssetUsageRequest
from pydantic_extra_types.currency_code import ISO4217

class VermillioTracking(VermillioBaseClient):
    def usage(self, title: str, parent_asset_ids: list[str], count: int = None, data: dict = None):
        return self._post(
                "/partner/tracking/usage",
                AssetUsageRequest(title=title, parent_asset_ids=parent_asset_ids, count=count, data=data),
                None,
            )
    
    def action(self, action: AssetAction,asset_ids: list[str], location: str = None, data: dict = None):
        return self._post(
            "/partner/tracking/action",
            AssetActionRequest(action=action, asset_ids=asset_ids, location=location, data=data),
            None,
        )
    
    def revenue(self, asset_ids: list[str], currency: ISO4217, amount: float, transaction_id: str = None, data: dict = None):
        return self._post(
            "/partner/tracking/revenue",
            AssetRevenueRequest(asset_ids=asset_ids, currency=currency, amount=amount, transaction_id=transaction_id, data=data),
            None,
        ) 