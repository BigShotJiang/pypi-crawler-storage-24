from typing import List, Literal, Optional

from .base import BaseCamelModel, AccountKey
from .auth import OAuthCredentialsPreview

ApplicationStatus = Literal["Active", "Deleted"]
ApplicationEnvironment = Literal["Development", "Production"]


class LicenseAssetAccess(BaseCamelModel):
    license_id: str
    asset_id: str
    media_ids: List[str]
    start_date: int
    end_date: int
    environments: List[ApplicationEnvironment]


class Application(BaseCamelModel):
    id: str
    owner: AccountKey
    status: ApplicationStatus
    name: str
    description: Optional[OAuthCredentialsPreview] = None
    environment: ApplicationEnvironment
    project_id: str
    created_by: str
    deleted_by: Optional[str] = None
    deleted_at: Optional[float] = None
    licenses: Optional[List[str]] = None
    assets: Optional[List[LicenseAssetAccess]] = None
