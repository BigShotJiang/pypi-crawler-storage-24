import logging
import requests

from pydantic import BaseModel
from typing import Any, Dict, Literal, Optional, Type, TypeVar, Union, IO

from requests import PreparedRequest, Session
from authlib.integrations.httpx_client import AsyncOAuth2Client
from requests.adapters import HTTPAdapter
from urllib.parse import quote as url_encode
from urllib3.util import Retry
from tqdm.auto import tqdm

from ..models import VermillioConfig, OAuthToken

BaseModelType = TypeVar("BaseModelType", bound=BaseModel)
HttpMethod = Literal["GET", "POST", "PUT", "DELETE"]

_default_retry = Retry(
    total=2,
    backoff_factor=2,
    # backoff_jitter=0.05,
    # backoff_max=30.0,
    status_forcelist=[
        408,
        429,
        500,
        502,
        503,
        504,
    ],
)


def _url(base_url: str, path: str) -> str:
    if base_url[-1] == "/" and path[0] == "/":
        return f"{base_url}{path[1:]}"
    if base_url[-1] == "/" or path[0] == "/":
        return f"{base_url}{path}"
    return f"{base_url}/{path}"


class RetryAdapter(HTTPAdapter):
    def __init__(self, retry_strategy: Retry = _default_retry):
        super().__init__(max_retries=retry_strategy)


class OAuthTokenAdapter(RetryAdapter):
    def __init__(
        self,
        config: VermillioConfig,
        token_tolerance: int = 30,
        retry_strategy: Retry = _default_retry,
    ):
        super().__init__(retry_strategy)
        self._log = logging.getLogger(__name__)
        self._session = Session()
        self._session.mount(config.auth_base_url, RetryAdapter())
        self._config = config
        self._token_tolerance = token_tolerance
        self._token: OAuthToken = None

    def _bearer_token(self):
        if not self._token or self._token.expired(self._token_tolerance):
            self._log.debug("Fetching new OAuth token")
            res = self._session.post(
                _url(self._config.auth_base_url, "/oauth2/token"),
                data={
                    "grant_type": "client_credentials",
                    "audience": self._config.audience,
                    "client_id": self._config.client_id,
                    "client_secret": self._config.client_secret,
                },
            )

            if not res.ok:
                self._log.warning(
                    f"Failed to fetch OAuth token {res.status_code} :: {res.content}"
                )
                res.raise_for_status()

            self._token = OAuthToken.model_validate_json(res.content)

        return f"Bearer {self._token.access_token}"

    def add_headers(self, request: PreparedRequest, **kwargs):
        if "Authorization" not in request.headers:
            request.headers["Authorization"] = self._bearer_token()


class VermillioBaseClient:
    """
    Base Vermillio Client providing authentication mechanism via VermillioConfig
    """

    def __init__(
        self,
        config: Optional[VermillioConfig] = None,
        base_url: Union[str, None] = None,
    ):
        config = config or VermillioConfig.default()
        self._log = logging.getLogger(__name__)
        self._config = config
        self._session = Session()
        self._base_url = base_url or config.trace_base_url
        self._session.mount(self._base_url, OAuthTokenAdapter(config))
        self._async_client = AsyncOAuth2Client(
            config.client_id,
            config.client_secret,
            token_endpoint_auth_method="client_secret_post",
        )

    def _encode(self, value: str) -> str:
        return url_encode(value, safe="/", encoding=None, errors=None)

    def _url(self, path: str):
        return _url(self._base_url, path)

    def _json(self, data: Union[Dict, BaseModel]):
        return data if isinstance(data, Dict) else data.model_dump()

    def _or_error(
        self, result: Optional[BaseModelType], error: Exception
    ) -> BaseModelType:
        if result is None:
            raise error
        return result

    def _get(
        self,
        path: str,
        response_type: Type[BaseModelType],
        params: Optional[Dict] = None,
        timeout: Optional[float] = None,
    ) -> Optional[BaseModelType]:
        return self._request(path, "GET", response_type, timeout, params)

    def _put(
        self,
        path: str,
        data: Union[Dict, BaseModel],
        response_type: Type[BaseModelType],
        params: Optional[Dict] = None,
        files: Optional[Dict[str, IO]] = None,
        timeout: Optional[float] = None,
    ) -> Optional[BaseModelType]:
        return self._request(path, "PUT", response_type, timeout, params, data, files)

    def _post(
        self,
        path: str,
        data: Union[Dict, BaseModel],
        response_type: Type[BaseModelType],
        params: Optional[Dict] = None,
        files: Optional[Dict[str, IO]] = None,
        timeout: Optional[float] = None,
    ) -> Optional[BaseModelType]:
        return self._request(path, "POST", response_type, timeout, params, data, files)

    async def _async_post(
        self,
        path: str,
        data: Any,
        response_type: Type[BaseModelType],
        params: Optional[Dict] = None,
        files: Optional[Dict[str, IO]] = None,
        timeout: Optional[float] = None,
    ) -> Optional[Union[str, Dict, BaseModelType]]:
        return await self._async_request(
            path, "POST", response_type, timeout, params, data, files
        )

    def _delete(
        self,
        path: str,
        response_type: Type[BaseModelType],
        params: Optional[Dict] = None,
        timeout: Optional[float] = None,
    ) -> Optional[BaseModelType]:
        return self._request(path, "DELETE", response_type, timeout, params)

    async def _async_request(
        self,
        path: str,
        method: HttpMethod,
        response_type: Type[BaseModelType],
        timeout: Optional[float] = None,
        params: Optional[Dict] = None,
        body: Optional[Any] = None,
        files: Optional[Dict[str, IO]] = None,
    ) -> Optional[Union[str, Dict, BaseModelType]]:
        url = self._url(path)
        self._log.debug("Sending %s request to url %s", method, url)

        if not self._async_client.token:
            self._async_client.token = await self._async_client.fetch_token(
                _url(self._config.auth_base_url, "/oauth2/token"),
                grant_type="client_credentials",
                audience=self._config.audience,
            )
        res = await self._async_client.request(
            method,
            url,
            timeout=timeout,
            params=params,
            data=body,
            files=files,
        )
        self._log.debug(
            "Received %d for %s to url %s",
            res.status_code,
            res.request.method,
            res.request.url,
        )
        if res.status_code == 404:
            return None
        if not 200 <= res.status_code < 300:
            self._log.debug("Response: %s", res.content)
            res.raise_for_status()
        try:
            return response_type.model_validate_json(res.content)
        except Exception:
            try:
                return res.json()
            except Exception:
                return res.text

    def _request(
        self,
        path: str,
        method: HttpMethod,
        response_type: Type[BaseModelType],
        timeout: Optional[float] = None,
        params: Optional[Dict] = None,
        body: Optional[Union[Dict, BaseModel]] = None,
        files: Optional[Dict[str, IO]] = None,
    ) -> Optional[BaseModelType]:
        url = self._url(path)
        self._log.debug("Sending %s request to url %s", (method, url))
        res = self._session.request(
            method,
            url,
            timeout=timeout,
            params=params,
            json=self._json(body) if body else None,
            files=files,
        )
        self._log.debug(
            "Received %d for %s to url %s",
            (res.status_code, res.request.method, res.request.url),
        )
        if res.status_code == 404:
            return None
        if not res.ok:
            self._log.debug("Response: %s", res.content)
            res.raise_for_status()
        return response_type.model_validate_json(res.content)

    def _download_file(self, url: str, local_filename: str) -> bool:
        """Downloads using requests with a tqdm progress bar."""
        try:
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                total_size_in_bytes = int(r.headers.get("content-length", 0))
                block_size = 1024  # 1 Kibibyte

                with tqdm(
                    total=total_size_in_bytes,
                    unit="iB",
                    unit_scale=True,
                    desc=local_filename,
                ) as progress_bar:
                    with open(local_filename, "wb") as file:
                        for data in r.iter_content(block_size):
                            progress_bar.update(len(data))
                            file.write(data)

            if total_size_in_bytes != 0 and progress_bar.n != total_size_in_bytes:
                return False

            return True

        except Exception:
            return False


# TODO: build out an async client
# class VermillioBaseAsyncClient:
#     def __init__(self, config: VermillioConfig):
#         self._config = config
