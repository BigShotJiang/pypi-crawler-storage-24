from typing import List

from .base import BaseCamelModel
from .base import AccountKey
from .assets import AssetMediaLicense


class MultiFileDownload(BaseCamelModel):
    id: str
    owner: AccountKey
    status: str
    projectId: str
    assetMedia: List[AssetMediaLicense]
    assetIds: List[str]
    mediaIds: List[str]
    createdAt: int
    createdBy: str
    expiresAt: int
