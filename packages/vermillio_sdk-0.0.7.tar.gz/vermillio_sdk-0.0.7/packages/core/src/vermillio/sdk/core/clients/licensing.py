from typing import List, Optional
from pydantic import RootModel

from .base import VermillioBaseClient
from ..models.licensing import PartnerLicense


class VermillioLicensing(VermillioBaseClient):
    def licenses(self) -> List[PartnerLicense]:
        res = self._get("/partner/license/list", RootModel[List[PartnerLicense]])
        return res.root if res else []

    def license(self, id: str) -> Optional[PartnerLicense]:
        return self._get(f"/partner/license/{id}", PartnerLicense)
