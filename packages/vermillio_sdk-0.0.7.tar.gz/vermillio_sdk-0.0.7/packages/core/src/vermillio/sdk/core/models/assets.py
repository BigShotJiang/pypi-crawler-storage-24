from typing import Dict, List, Literal, Optional

from pydantic import Field
from .base import AccountKey, BaseCamelModel

# TODO: blockchain?

AssetType = Literal[
    "Image",
    "Video",
    "Audio",
    "Adr",
    "Character",
    "Item",
    "Model",
    "Dataset",
    "StyleGuide",
]

AssetStatus = Literal[
    "Pending",
    "Atomizing",
    "Published",
    "Deleted",
    "Error",
]

AssetVisibility = Literal["Private", "Limited", "Public"]

MediaType = Literal["Source", "Preview", "Script"]
MediaStatus = Literal["Pending", "Error", "Rejected", "Ready", "Deleted"]


class SignedUrl(BaseCamelModel):
    url: str
    expiresAt: int
    local_path: Optional[str] = None


class AssetTerm(BaseCamelModel):
    name: str
    criteria: Literal["None", "Includes", "Excludes", "All"]
    values: Optional[str] = None


class AssetTerms(BaseCamelModel):
    use_cases: List[str]
    platforms: List[AssetTerm]
    territories: AssetTerm
    exclusivity: Literal["Non-exclusive", "Exclusive"]
    revenue: float
    credit: Optional[str] = None
    tos_id: Optional[str] = None


class AssetProperty(BaseCamelModel):
    id: str
    name: str
    preview_image: Optional[SignedUrl] = None


class AssetMetadata(BaseCamelModel):
    type: str
    data: Dict


class AssetMedia(BaseCamelModel):
    id: str


class AssetMediaLicense(BaseCamelModel):
    licenseId: str
    assetId: str
    mediaIds: List[str]


class AssetOwner(AccountKey):
    display_name: Optional[str] = None
    display_photo_url: Optional[str] = None
    username: Optional[str] = None


class Asset(BaseCamelModel):
    id: str
    version: int
    parent_asset_id: Optional[str] = None
    parent_trace_id: Optional[str] = None
    status: AssetStatus
    type: AssetType
    visibility: AssetVisibility
    title: str
    description: Optional[str] = None
    preview_image_url: Optional[str] = None
    media: List[AssetMedia]
    media_ids: List[str]
    owner: AssetOwner
    created_at: int
    updated_at: Optional[int] = None
    deleted_at: Optional[int] = None
    published_at: Optional[int] = None
    created_by: str
    updated_by: Optional[str] = None
    deleted_by: Optional[str] = None
    labels: List[str]
    property: Optional[AssetProperty] = None


class UploadMedia(BaseCamelModel):
    path: str
    type: MediaType
    filename: Optional[str] = None


class UploadAsset(BaseCamelModel):
    title: str
    type: AssetType
    media: List[UploadMedia]
    description: Optional[str] = None
    parent_asset_id: Optional[str] = None
    parent_trace_id: Optional[str] = None
    labels: Optional[List[str]] = None
    property: Optional[AssetProperty] = None
    metadata: Optional[AssetMetadata] = None
    terms: AssetTerms
    is_async: Optional[bool] = Field(alias="async")


## TODO: Should above be used at all?


class PartnerAssetOwner(BaseCamelModel):
    id: str
    displayName: str


# --8<-- [start:partner_asset]
class PartnerAsset(BaseCamelModel):
    id: str
    type: AssetType
    title: str
    description: Optional[str] = None
    media_ids: List[str]
    owner: PartnerAssetOwner


# --8<-- [end:partner_asset]


class SignedUrls(BaseCamelModel):
    urls: List[SignedUrl]


BulkStatus = Literal["Pending", "Downloaded"]


class BulkRequest(BaseCamelModel):
    id: str


class BulkEntry(BulkRequest):
    status: BulkStatus


class DownloadResult(BaseCamelModel):
    id: str
    created_at: int
    signed_url: SignedUrl
    asset_id: str
    media_id: str
    license_id: Optional[str] = None
    bulk: Optional[BulkEntry] = None


class DownloadResults(BaseCamelModel):
    results: Optional[List[DownloadResult]] = None
