import os

from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse
from pydantic import RootModel

from .base import VermillioBaseClient
from ..models import (
    PartnerAsset,
    AssetType,
    MultiFileDownload,
    SignedUrl,
    SignedUrls,
    BulkRequest,
    DownloadResult,
    DownloadResults,
)


class VermillioAssets(VermillioBaseClient):
    def list(self) -> List[PartnerAsset]:
        res = self._get("/partner/asset/list", RootModel[List[PartnerAsset]])
        return res.root if res else []

    def get(self, id: str) -> Optional[PartnerAsset]:
        return self._get(f"/partner/asset/{id}", PartnerAsset)

    def upload(
        self,
        file_path: str,
        asset_type: AssetType,
        title: str,
        parent_asset_id: Optional[str] = None,
    ) -> PartnerAsset:
        assert os.path.isfile(file_path), f"Failed to find file: '{file_path}'"
        with open(file_path, "rb") as f:
            return self._post(
                "/partner/asset/upload",
                None,
                PartnerAsset,
                {
                    "type": asset_type,
                    "title": title,
                    **({"parentAssetId": parent_asset_id} if parent_asset_id else {}),
                },
                {(os.path.basename(file_path)): f},
            )

    def _get_filename(self, file_name: str):
        parsed_url = urlparse(file_name)

        return Path(parsed_url.path).name

    def _download_url(self, url: str, download_path: str):
        filename = self._get_filename(url)
        path = os.path.join(download_path, filename)

        self._download_file(url, path)

        return path

    def download(self, media_id: str, download_path: str = "") -> str:
        """
        downloads a specific media
        """
        result = self._get(f"/partner/asset/download/media/{media_id}", SignedUrl)
        if result:
            if result.local_path:
                download_path = os.path.join(download_path, result.local_path)
                os.makedirs(download_path, exist_ok=True)
            return self._download_url(result.url, download_path)

        return None

    def download_media_by_license(
        self, license_id: str, asset_id: str = None, download_path: str = ""
    ) -> str:
        """
        downloads all media for a license
        """
        result = self._get(
            f"/partner/asset/download/license/{license_id}/asset/{asset_id}", SignedUrls
        )
        urls = []
        if result:
            for signed_url in result.urls:
                local_path = download_path
                if signed_url.local_path:
                    local_path = os.path.join(local_path, signed_url.local_path)
                    os.makedirs(local_path, exist_ok=True)
                path = self._download_url(signed_url.url, local_path)
                urls.append(path)

        return urls

    def prepare_zip_license(self, license_id: str):
        """
        prepare download zip for for download of licensed data
        """
        return self._get(
            f"/partner/asset/license/{license_id}/prepare/zip", MultiFileDownload
        )

    def status_zip(self, download_id: str):
        """
        get status of download
        """
        return self._get(
            f"/partner/asset/download/status/{download_id}//zip", MultiFileDownload
        )

    def download_zip(self, download_id, download_path: str = ""):
        """
        downloads all the media for a list of assets
        """
        result = self._get(f"/partner/asset/download/bulk/{download_id}/zip", SignedUrl)
        if result:
            return self._download_url(result.url, download_path)

        return None

    def download_license_zip(self, license_id: str, download_path: str = ""):
        """
        downloads all the media for a license
        """
        result = self._get(
            f"/partner/asset/download/bulk/license/{license_id}/zip", SignedUrl
        )
        if result:
            filename = self._get_filename(result.url)
            path = os.path.join(download_path, filename)

            self._download_file(result.url, path)

            return path

        return None

    def bulk_download_license_zip(self, license_id: str, download_path: str = ""):
        """
        downloads all the media for a license
        """
        result = self._get(
            f"/partner/asset/download/bulk/license/{license_id}/zip", SignedUrl
        )
        if result:
            filename = self._get_filename(result.url)
            path = os.path.join(download_path, filename)

            self._download_file(result.url, path)

            return path

        return None

    def prepare_license(self, license_id: str):
        """
        prepare for download of licensed data
        """
        return self._get(f"/partner/asset/license/{license_id}/prepare", BulkRequest)

    def remaining_n_downloads(self, download_id: str, top: int) -> DownloadResults:
        """
        get remaining bulk downloads
        """
        return self._get(
            f"/partner/asset/download/remaining/{download_id}/top/{top}",
            DownloadResults,
        )

    def remaining_downloads(self, download_id: str) -> DownloadResults:
        """
        get remaining bulk downloads
        """
        return self._get(
            f"/partner/asset/download/remaining/{download_id}", DownloadResults
        )

    def media_access(self, media_access_id: str) -> DownloadResult:
        """
        get media access
        """
        return self._get(
            f"/partner/asset/media/access/{media_access_id}", DownloadResult
        )

    def mark_downloaded(self, media_access_id: str) -> DownloadResult:
        """
        mark media_access as downloaded
        """
        return self._put(
            f"/partner/asset/mark/media/access/downloaded/{media_access_id}",
            None,
            DownloadResult,
        )

    def download_status(self, download_id: str):
        """
        prepare download zip for for download of licensed data
        """
        return self._get(
            f"/partner/asset/download/{download_id}/status", MultiFileDownload
        )

    def bulk_download_license(self, license_id: str, download_path: str = ""):
        """
        bulk download license
        """
        request = self.prepare_license(license_id)

        files = self.remaining_downloads(request.id)
        while len(files.results) > 0:
            for file in files.results:
                filename = self._get_filename(file.signed_url.url)
                local_path = download_path
                if file.signed_url.local_path:
                    local_path = os.path.join(local_path, file.signed_url.local_path)
                    os.makedirs(local_path, exist_ok=True)
                path = os.path.join(local_path, filename)

                self._download_file(file.signed_url.url, path)
                print(f"Marking {file.id} as downloaded")
                self.mark_downloaded(file.id)

            files = self.remaining_downloads(request.id)

        return None
