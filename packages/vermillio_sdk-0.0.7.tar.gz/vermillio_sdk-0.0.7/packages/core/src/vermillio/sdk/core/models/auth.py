import time
from pydantic import BaseModel, Field, field_serializer
from .base import BaseCamelModel


class OAuthCredentials(BaseCamelModel):
    client_id: str
    client_secret: str
    audience: str = "https://application.vermill.io"

    @field_serializer("client_secret")
    def serialize_client_secret(self, client_secret: str, _info):
        return client_secret[:6].rjust(len(client_secret), "*")


class OAuthCredentialsPreview(BaseCamelModel):
    client_id: str
    client_secret_preview: str
    audience: str


class OAuthTokenRequest(BaseModel):
    client_id: str
    client_secret: str
    grant_type: str = "client_credentials"
    audience: str


class OAuthToken(BaseModel):
    created_at: float = Field(default_factory=time.time)
    access_token: str
    expires_in: int
    scope: str
    token_type: str

    @property
    def expires_at(self):
        return self.created_at + self.expires_in

    def expired(self, tolerance: float = 0):
        return (time.time() - tolerance) >= self.expires_at
