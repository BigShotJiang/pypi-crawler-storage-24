import time
from typing import Optional, cast
from pydantic import RootModel

from ..models import (
    VermillioConfig,
    PipelineRunRequest,
    PipelineLoadRequest,
    PipelineResults,
)
from .base import VermillioBaseClient, BaseModelType


# TODO: add uploading
class VermillioBasePipelineClient(VermillioBaseClient):
    """
    Base Client for interacting with External Pipeline API.
    """

    def __init__(self, name: str, config: Optional[VermillioConfig] = None):
        config = config or VermillioConfig.default()
        self._name = self._encode(name)
        super().__init__(config, config.external_pipeline_url)

    def _url(self, path: str) -> str:
        return super()._url(f"/external/pipeline/{self._name}{path}")

    def _pipeline(self, pipeline_cls: type[BaseModelType]) -> Optional[BaseModelType]:
        return self._get("", pipeline_cls)

    def _load(
        self, load_request: PipelineLoadRequest, source_cls: type[BaseModelType]
    ) -> Optional[list[BaseModelType]]:
        res = self._post("", load_request, RootModel[list[source_cls]])
        return res.root if res else None

    def _run(
        self,
        run_request: PipelineRunRequest,
        source_cls: type[BaseModelType],
        timeout: float = 60.0,
        poll_rate: float = 1.0,
    ) -> Optional[BaseModelType]:
        # TODO: bounds on params/validate?
        return self._post(
            "/run",
            run_request,
            source_cls,
            {"timeout": timeout, "poll_rate": poll_rate},
        )

    # TODO: run indefinitely local polling?

    def _run_results(
        self,
        run_request: PipelineRunRequest,
        results_cls: type[BaseModelType],
        timeout: float = 60.0,
        poll_rate: float = 1.0,
    ) -> Optional[BaseModelType]:
        # TODO: bounds on params/validate?
        return self._post(
            "/run/results",
            run_request,
            results_cls,
            {"timeout": timeout, "poll_rate": poll_rate},
        )

    def _status(
        self, status_cls: type[BaseModelType], context: Optional[str] = None
    ) -> Optional[BaseModelType]:
        return self._get("/status", status_cls, {"context": context})

    def _sources(
        self,
        source_cls: type[BaseModelType],
        context: Optional[str] = None,
        after_id: Optional[str] = None,
        limit: int = 10,
    ) -> Optional[list[BaseModelType]]:
        # TODO: validate params
        res = self._get(
            "/sources",
            RootModel[list[source_cls]],
            {"context": context, "after_id": after_id, "limit": limit},
        )
        return res.root if res else None

    def _source(
        self,
        id_or_source_id: str,
        source_cls: type[BaseModelType],
        context: Optional[str] = None,
    ) -> Optional[BaseModelType]:
        return self._get(
            f"/source/{self._encode(id_or_source_id)}", source_cls, {"context": context}
        )

    def _results(
        self,
        id_or_source_id: str,
        results_cls: type[BaseModelType],
        context: Optional[str] = None,
        wait: bool = False,
        # TODO: add a timeout? poll rate?
    ) -> Optional[BaseModelType]:
        def __results():
            return self._get(
                f"/source/{self._encode(id_or_source_id)}/results",
                results_cls,
                {"context": context},
            )
        
        result = __results()        
        while wait and result and issubclass(type(result), PipelineResults) and not cast(PipelineResults, result).is_finished:
            time.sleep(1) # TODO: configure
            result = __results()
        return result
        
