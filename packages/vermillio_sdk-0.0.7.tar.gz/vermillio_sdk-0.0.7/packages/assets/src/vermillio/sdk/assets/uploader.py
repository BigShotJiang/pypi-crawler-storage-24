import mimetypes
import traceback
from typing import Dict, List, Tuple, Union

import fire
from tqdm.asyncio import tqdm_asyncio
from cloudpathlib import AnyPath
from vermillio.sdk.core import (
    VermillioDataTransfer,
    VermillioConfig,
    AssetDto,
    FileUploadMetadata,
    MediaDto,
    ScanJob,
    UploadBatchRequest,
    UploadStatus,
)

from logging.config import dictConfig


def _log_config(level="INFO"):
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "fmt": "%(levelprefix)s %(asctime)s [%(name)s] %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
        },
        "handlers": {
            "default": {
                "formatter": "default",
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout",
            },
        },
        "root": {"level": level, "handlers": ["default"], "propagate": False},
    }


def _init_logging(level="INFO"):
    dictConfig(_log_config(level))


class AssetUploader:
    def __init__(self):
        self.data_transfer = VermillioDataTransfer(VermillioConfig.from_env())

    async def _wrap_upload(
        self, upload_id: str, media_path: str, batch_id: str = None
    ) -> Tuple[str, dict[str, str]]:
        try:
            return (
                UploadStatus.Completed,
                await self.data_transfer.file_upload(upload_id, media_path, batch_id),
            )
        except Exception as e:
            return (
                UploadStatus.Failed,
                {media_path: f"{str(e)} - {traceback.format_exc(e)}"},
            )

    def guess_asset_type(self, types: set) -> str:
        if "video" in types:
            return "Video"
        elif "audio" in types:
            return "Audio"
        elif "image" in types:
            return "Image"
        return "Model"

    async def scan_folder(
        self,
        path: str,
        upload_id: str = None,
        scan_id: str = None,
        batch_size: int = 5,
        asset_per_media: bool = False,
    ) -> FileUploadMetadata:
        upload = FileUploadMetadata(asset_metadata=[])
        upload.id = upload_id

        scan = ScanJob(root_path=path)
        if upload_id is not None:
            scan.upload_id = upload_id
        if scan_id is None:
            scan = self.data_transfer.register_scan(scan)
            scan_id = scan.id
        else:
            scan = self.data_transfer.get_scan(scan_id)
            path = scan.root_path
            upload.id = scan.upload_id

        print(f"scan_id: {scan.id}")

        for root, dirs, files in AnyPath(path).walk():
            if root not in scan.scanned_paths:
                parent = str(root.parents[0])
                if parent == path:
                    parent = None

                assets = [
                    AssetDto(
                        parentAssetId=parent,
                        type="Model",
                        media=[],
                        title=root.name,
                    )
                ]

                types = set()
                for file in files:
                    file_path = str(root.joinpath(file))
                    if file_path not in scan.scanned_paths and not file.startswith("."):
                        file_type, encoding = mimetypes.guess_type(file)
                        if file_type:
                            types.add(file_type.split("/")[0])

                        if asset_per_media:
                            assets.append(
                                AssetDto(
                                    parentAssetId=str(root),
                                    type=self.guess_asset_type(types),
                                    media=[],
                                    title=AnyPath(file).stem,
                                )
                            )
                            types = set()

                        assets[-1].media.append(
                            MediaDto(
                                path=file_path,
                                filename=file,
                                upload_id=upload_id,
                            )
                        )
                        if len(assets) >= batch_size:
                            upload.asset_metadata = assets
                            upload.id = self.data_transfer.register_upload(
                                upload, scan_id
                            )
                            scan.upload_id = upload.id
                            upload.asset_metadata = assets = []

                if len(assets) == 1:
                    assets[0].type = self.guess_asset_type(types)

                for asset in assets:
                    if len(asset.media) > 0:
                        upload.asset_metadata.append(asset)

                if len(upload.asset_metadata) >= batch_size:
                    upload.id = self.data_transfer.register_upload(upload, scan_id)
                    scan.upload_id = upload.id
                    upload.asset_metadata = []

                scan.scanned_paths.add(str(root))
                scan = self.data_transfer.register_scan(scan)

        upload.id = self.data_transfer.register_upload(upload, scan_id)
        scan.upload_id = upload.id
        scan.status = UploadStatus.Completed
        self.data_transfer.register_scan(scan)

        return upload

    async def _upload_media(
        self, media_list: List[MediaDto], batch_id: str = None
    ) -> Dict[str, Union[Dict[str, str], str]]:
        uploads = []
        for media in media_list:
            if media.status != UploadStatus.Completed:
                uploads.append(self._wrap_upload(media.upload_id, media.path, batch_id))

        upload_outputs = await tqdm_asyncio.gather(*uploads)
        output = {}
        final_status = UploadStatus.Completed
        for status, upload in upload_outputs:
            if status != UploadStatus.Completed:
                final_status = UploadStatus.Failed
            for local, remote in upload.items():
                output[local] = {
                    "status": status,
                    "remote_path": remote,
                }

        output["status"] = final_status

        return output

    async def upload_batch(
        self, batch_id: str
    ) -> Dict[str, Union[Dict[str, str], str]]:
        batch = self.data_transfer.get_batch(batch_id)

        return await self._upload_media(list(batch.media), batch_id)

    async def run_new_batch(
        self, batch_size: int
    ) -> Dict[str, Union[Dict[str, str], str]]:
        existing_batches = self.data_transfer.get_unfinished_batches()
        batch_request = UploadBatchRequest(batch_size_per_upload=batch_size)
        if len(existing_batches) > 0:
            batch_request.first_media_id = existing_batches[-1].media[-1].id
        batch = self.data_transfer.start_batch(batch_request)

        print(f"batch_id: {batch.id}")

        return await self.upload_batch(batch.id)

    async def upload_folder(
        self, path: str, upload_id: str = None
    ) -> Dict[str, Union[Dict, str]]:
        if upload_id:
            upload = self.data_transfer.get_upload(upload_id)
            # pull relative to path for partial updates in multiple jobs
        else:
            upload = await self.scan_folder(path)

        print(f"upload record: {upload_id}")

        media_list = []
        for asset in upload.asset_metadata:
            media_list.extend(asset.media)

        output = {"id": upload_id}
        output["path_mapping"] = await self._upload_media(media_list)

        return output


if __name__ == "__main__":
    # _init_logging("DEBUG")
    fire.Fire(AssetUploader)
