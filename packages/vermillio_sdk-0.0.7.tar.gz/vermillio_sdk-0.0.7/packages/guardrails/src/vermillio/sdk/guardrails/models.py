from typing import Literal, Optional
from pydantic import BaseModel, Field
from vermillio.sdk.core import (
    ExternalPipeline,
    PipelineLoadRequest,
    PipelineRunRequest,
    ExternalSource,
    PipelineSource,
    PipelineResults,
    PipelineStatus,
)


# TODO: add examples


class GuardrailsPipeline(ExternalPipeline): ...


class GuardrailsExternalSource(ExternalSource):
    prompt: str = Field(description="The prompt to analyze")
    lyrics: Optional[str] = Field(
        default=None, description="Optional lyrics to include as part of the analysis."
    )  # TODO: music gen version is required?


class GuardrailsRunRequest(PipelineRunRequest):
    source: GuardrailsExternalSource = Field(
        description="The source request to analyze and wait for.",
    )


class GuardrailsLoadRequest(PipelineLoadRequest):
    sources: list[GuardrailsExternalSource] = Field(
        description="List of source load to request to analyze.",
    )


class GuardrailsPipelineSource(PipelineSource):
    prompt: str = Field(description="The prompt to analyze")
    lyrics: Optional[str] = Field(
        default=None,
        description="Optional lyrics to include as part of the analysis.",
    )  # TODO: music gen version is required?


class GuardrailsPipelineStatus(PipelineStatus):
    pipeline: GuardrailsPipeline = Field(
        description="The pipeline that this status is for.",
    )


GuardrailsActionType = Literal["allow", "deny", "classify", "revise", "lyric_match"]
GuardrailsMatchType = Literal["matching", "block"]


class GuardrailsMatchReason(BaseModel):
    highlight: Optional[list[str]] = Field(
        None,
        description="Highlights of the parts of the prompt that matched, wrapped in <em>{matching phrase}</em>.",
    )
    score: float = Field(
        description="The score of the match, scoring is dependent on the type of rule that was matched.",
    )


IpProfileCategory = Literal[
    "character",
    "person",
    "music artist",
    "franchise",
    "song/album",
    "book",
    "organization",
    "other",
]


class IpProfile(BaseModel):
    name: str = Field(
        description="The internal name of the IP Profile",
        examples=["superman"],
    )
    display_name: Optional[str] = Field(
        default=None,
        description="The display name of the IP Profile",
        examples=["Superman"],
    )
    aliases: list[str] = Field(
        default=[],
        description="A list of aliases of the IP Profile",
        examples=[["Clark Kent", "Ka-EL"]],
    )
    category: IpProfileCategory = Field(
        default="other",
        description="The category this IP Profile belongs to",
        examples=["character"],
    )
    created_at: float = Field(
        examples=[1758921103.206561],
        description="The epoch time in seconds of when this profile was created.",
    )
    updated_at: Optional[float] = Field(
        default=None,
        examples=[1758921103.2065752],
        description="The last epoch time in seconds of when this profile was last updated.",
    )
    summary: Optional[str] = Field(None, description="A summary of the IP Profile")
    is_global: bool = Field(
        description="Whether or not this profile is a global Vermillio managed profile."
    )


class IpProfileRule(BaseModel):
    name: str = Field(
        description="The name of the IP Profile Rule",
        examples=["superman-match-name"],
    )
    display_name: Optional[str] = Field(
        None,
        description="The display name of the rule",
        examples=["Superman Match Name"],
    )
    match_type: GuardrailsMatchType = Field(
        description="How this rule should be used, for matching/classification or blocking.",
    )
    notes: Optional[str] = Field(
        default=None,
        description="Notes containing details about this rule.",
    )
    created_at: float = Field(
        examples=[1758921103.206561],
        description="The epoch time in seconds of when this rule was created.",
    )
    updated_at: Optional[float] = Field(
        default=None,
        examples=[1758921103.2065752],
        description="The last epoch time in seconds of when this rule was last updated.",
    )
    synced_at: Optional[float] = Field(
        default=None,
        examples=[1758921103.2065752],
        description="The last epoch time in seconds of when this rule was last synced.",
    )


class GuardrailsSummarizeReason(BaseModel):
    reason: str = Field(description="Friendly description of the reason.")
    action: GuardrailsActionType = Field(
        description="The action that this reason tells us about the prompt."
    )
    matching_profile: IpProfile = Field(
        description="The profile that this reason matched."
    )
    matching_rule: IpProfileRule = Field(
        description="The rule that this reason matched."
    )
    match: GuardrailsMatchReason = Field(description="The details for the match.")


class GuardrailsResultsSummary(BaseModel):
    ip_profiles: list[str] = Field(
        description="List of ip profiles that were classified",
        examples=[["profile-1", "profile-2"]],
    )
    action: GuardrailsActionType = Field(
        description="Overall action derived from the reasons."
    )
    reasons: list[GuardrailsSummarizeReason] = Field(
        description="List of reasons that drive the final action.",
    )
    revisions: Optional[list[str]] = Field(
        None, description="List of revised prompts if any revisions were made."
    )


class GuardrailsPipelineResults(PipelineResults):
    prompt: str = Field(description="The prompt to analyze")
    lyrics: Optional[str] = Field(
        default=None, description="Optional lyrics to include as part of the analysis."
    )  # TODO: music gen version is required?
    summary: Optional[GuardrailsResultsSummary] = Field(
        default=None,
        description="The summary of the guardrails results, only present when status is 'Succeeded'",
    )
