from typing import Optional
from vermillio.sdk.core import VermillioBasePipelineClient, VermillioConfig
from .models import (
    GuardrailsPipeline,
    GuardrailsExternalSource,
    GuardrailsLoadRequest,
    GuardrailsPipelineSource,
    GuardrailsPipelineStatus,
    GuardrailsPipelineResults,
    GuardrailsRunRequest,
)


class VermillioGuardrails(VermillioBasePipelineClient):
    def __init__(self, config: Optional[VermillioConfig] = None):
        """
        Initializes the Guardrails Client.

        Args:
            config (Optional[VermillioConfig]): An optional configuration object.
                If None, it attempts to load configuration from environment variables.
        """
        super().__init__("guardrails", config)

    def pipeline(self) -> GuardrailsPipeline:
        """
        Retrieves the configuration or definition of the current guardrails pipeline.

        Returns:
            GuardrailsPipeline: An object containing the pipeline definition.
        """
        return self._pipeline(GuardrailsPipeline)

    def load(
        self, sources: list[GuardrailsExternalSource], context: Optional[str] = None
    ) -> Optional[list[GuardrailsPipelineSource]]:
        """
        Loads a list of sources into the guardrails pipeline.
        Processing occurs asynchronously.

        Args:
            sources (list[GuardrailsExternalSource]): A list of source objects to be loaded.
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.

        Returns:
            Optional[list[GuardrailsPipelineSource]]: A list of loaded source objects if successful.
        """
        return self._load(
            GuardrailsLoadRequest(sources=sources, context=context),
            GuardrailsPipelineSource,
        )

    def run(
        self,
        source: GuardrailsExternalSource,
        context: Optional[str] = None,
        timeout: float = 60,
        poll_rate: float = 1,
    ) -> Optional[GuardrailsPipelineSource]:
        """
        Loads guardrails sources and waits (within a timeout) for the process to complete.

        Args:
            sources (list[GuardrailsExternalSource]): A list of sources to be analyzed.
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.
            timeout (float): Optional maximum time in seconds to wait for the analysis.
            poll_rate (float): Optional frequency in seconds at which to poll for updates.

        Returns:
            Optional[list[GuardrailsPipelineSource]]: The list of processed sources upon completion.
        """
        return self._run(
            GuardrailsRunRequest(source=source, context=context),
            GuardrailsPipelineSource,
            timeout,
            poll_rate,
        )

    def run_results(
        self,
        source: GuardrailsExternalSource,
        context: Optional[str] = None,
        timeout: float = 60,
        poll_rate: float = 1,
    ) -> Optional[GuardrailsPipelineResults]:
        """
        Loads guardrails sources and waits (within a timeout) for completion,
        returning detailed analysis results.

        Args:
            source (GuardrailsExternalSource): The source to be analyzed.
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.
            timeout (float): Maximum time in seconds to wait for results.
            poll_rate (float): Frequency in seconds at which to poll for results.

        Returns:
            Optional[GuardrailsPipelineResults]: The results object containing match details,
                blocked topics, and suggested revisions.
        """
        return self._run_results(
            GuardrailsRunRequest(source=source, context=context),
            GuardrailsPipelineResults,
            timeout,
            poll_rate,
        )

    def status(
        self, context: Optional[str] = None
    ) -> Optional[GuardrailsPipelineStatus]:
        """
        Checks the health or operational status of the Guardrails service.

        Returns:
            GuardrailsPipelineStatus: An object indicating the current state of the pipeline.
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.
        """
        return self._status(GuardrailsPipelineStatus, context)

    def sources(
        self,
        context: Optional[str] = None,
        after_id: Optional[str] = None,
        limit: int = 10,
    ) -> Optional[list[GuardrailsPipelineSource]]:
        """
        Lists previously loaded sources with pagination support.

        Args:
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.
            after_id (Optional[str]): The optional ID to start listing after for pagination.
            limit (int): The maximum number of sources to return.

        Returns:
            Optional[list[GuardrailsPipelineSource]]: A list of source objects if found.
        """
        return self._sources(GuardrailsPipelineSource, context, after_id, limit)

    def source(
        self, id_or_source_id: str, context: Optional[str] = None
    ) -> Optional[GuardrailsPipelineSource]:
        """
        Fetches details for a specific source.

        Args:
            id_or_source_id (str): The unique identifier or source ID to retrieve.
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.

        Returns:
            Optional[GuardrailsPipelineSource]: The source object if found.
        """
        return self._source(id_or_source_id, GuardrailsPipelineSource, context)

    def results(
        self, id_or_source_id: str, context: Optional[str] = None
    ) -> Optional[GuardrailsPipelineResults]:
        """
        Retrieves the analysis results for a specific source.

        Args:
            id_or_source_id (str): The unique identifier of the source to get results for.
            context (Optional[str]): Optional context to use, uses `GuardrailsPipeline.default_context` if missing.

        Returns:
            Optional[GuardrailsPipelineResults]: An object containing IP matches and suggested revisions.
        """
        return self._results(id_or_source_id, GuardrailsPipelineResults, context)
