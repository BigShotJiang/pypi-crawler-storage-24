# Vermillio Guardrails SDK

Python client for the Vermillio Guardrails API. It provides a pipeline client plus typed models for sources, results, and IP profile matches.

## Install

```bash
pip install vermillio-sdk[guardrails]
```

## Configuration

The client loads credentials from environment variables by default:
- `VERMILLIO_SDK_CLIENT_ID`
- `VERMILLIO_SDK_CLIENT_SECRET`

For alternative methods, see `vermillio.sdk.core.config`.

## Quickstart

```python
from vermillio.sdk.guardrails import VermillioGuardrails, GuardrailsExternalSource

client = VermillioGuardrails()

result = client.run_results(GuardrailsExternalSource(
        prompt="Write a song about a flying hero from Krypton.",
    ))
if result:
    if result.status == 'Succeeded':
        print(result.summary)
    else:
        print(result.status)
```

The client reads configuration from `VermillioConfig` if provided, otherwise it falls back to environment-based configuration defined by `vermillio-core-sdk`.
