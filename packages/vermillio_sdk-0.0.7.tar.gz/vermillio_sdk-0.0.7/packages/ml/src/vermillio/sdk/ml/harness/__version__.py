from importlib.metadata import version, PackageNotFoundError

__title__ = "vermillio-ml-sdk"
try:
    __version__ = version(__title__)
except PackageNotFoundError:
    __version__ = "0.0.1"
