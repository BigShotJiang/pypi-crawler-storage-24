# Vermillio ML SDK

A ML harness/framework for integrating Vermillio SDK's into ML training and inference pipelines.