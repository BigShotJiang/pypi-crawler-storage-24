from pydantic import Field
from vermillio.sdk.core import BaseCamelModel


class AudioSegment(BaseCamelModel):
    start: float = Field(
        description="The start time (inclusive) in seconds of the segment."
    )
    end: float = Field(
        description="The end time (inclusive) in seconds of the segment."
    )
