from typing import Optional, Union
from vermillio.sdk.core import VermillioBasePipelineClient, VermillioConfig
from .models import (
    AIDetectPipeline,
    AIDetectExternalSource,
    AIDetectLoadRequest,
    AIDetectPipelineSource,
    AIDetectPipelineStatus,
    AIDetectPipelineResults,
    AIDetectRunRequest,
)


class VermillioMusicAIDetect(VermillioBasePipelineClient):
    def __init__(self, config: Optional[VermillioConfig] = None):
        """
        Initializes the Music AI Detection Client.

        Args:
            config (Optional[VermillioConfig]): An optional configuration object.
                If None, it attempts to load configuration from environment variables.
        """
        super().__init__("ai_detect", config)

    def pipeline(self) -> AIDetectPipeline:
        """
        Retrieves the configuration or definition of the current AI detection pipeline.

        Returns:
            AIDetectPipeline: An object containing the pipeline definition.
        """
        return self._pipeline(AIDetectPipeline)

    def load(
        self,
        sources: Union[list[AIDetectExternalSource], list[str]],
        context: Optional[str] = None,
    ) -> Optional[list[AIDetectPipelineSource]]:
        """
        Loads a list of audio sources into the AI detection pipeline.
        Processing occurs asynchronously.

        Args:
            sources (Union[list[AIDetectExternalSource], list[str]]): The external audio sources, or paths to a file, to analyze.
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.

        Returns:
            Optional[AIDetectPipelineSource]: An AI Detect Pipeline Source entry, if was loaded successfully.
        """
        return self._load(
            AIDetectLoadRequest(sources=sources, context=context),
            AIDetectPipelineSource,
        )

    def run(
        self,
        source: Union[AIDetectExternalSource, str],
        context: Optional[str] = None,
        timeout: float = 60,
        poll_rate: float = 1,
    ) -> Optional[AIDetectPipelineSource]:
        """
        Loads a source and waits (within a timeout) for the AI detection analysis to complete.

        Args:
            source (Union[AIDetectExternalSource, str]): The external audio source, or path to a file, to analyze.
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.
            timeout (float): Optional maximum time in seconds to wait for the analysis.
            poll_rate (float): Optional frequency in seconds at which to poll for updates.

        Returns:
            Optional[list[AIDetectPipelineSource]]: The list of processed sources upon completion.
        """
        return self._run(
            AIDetectRunRequest(source=source, context=context),
            AIDetectPipelineSource,
            timeout,
            poll_rate,
        )

    def run_results(
        self,
        source: Union[AIDetectExternalSource, str],
        context: Optional[str] = None,
        timeout: float = 60,
        poll_rate: float = 1,
    ) -> Optional[AIDetectPipelineResults]:
        """
        Loads a source and waits for completion, returning detailed AI detection analysis results.

        Args:
            source (Union[AIDetectExternalSource, str]): The external audio source, or path to a file, to analyze.
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.
            timeout (float): Maximum time in seconds to wait for results.
            poll_rate (float): Frequency in seconds at which to poll for results.

        Returns:
            Optional[AIDetectPipelineResults]: A list containing detection scores,
                confidence levels, and AI-generated probability markers.
        """
        return self._run_results(
            AIDetectRunRequest(source=source, context=context),
            AIDetectPipelineResults,
            timeout,
            poll_rate,
        )

    def status(self, context: Optional[str] = None) -> AIDetectPipelineStatus:
        """
        Checks the health or operational status of the AI Detection service.

        Args:
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.

        Returns:
            AIDetectPipelineStatus: An object indicating the current state of the pipeline.
        """
        return self._status(AIDetectPipelineStatus, context)

    def sources(
        self,
        context: Optional[str] = None,
        after_id: Optional[str] = None,
        limit: int = 10,
    ) -> Optional[list[AIDetectPipelineSource]]:
        """
        Lists previously loaded audio sources with pagination support.

        Args:
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.
            after_id (Optional[str]): The optional ID to start listing after for pagination.
            limit (int): The maximum number of sources to return.

        Returns:
            Optional[list[AIDetectPipelineSource]]: A list of source objects if found.
        """
        return self._sources(AIDetectPipelineSource, context, after_id, limit)

    def source(
        self, id_or_source_id: str, context: Optional[str] = None
    ) -> Optional[AIDetectPipelineSource]:
        """
        Fetches details for a specific audio source.

        Args:
            id_or_source_id (str): The unique identifier or source ID to retrieve.
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.

        Returns:
            Optional[AIDetectPipelineSource]: The source object if found.
        """
        return self._source(id_or_source_id, AIDetectPipelineSource, context)

    def results(
        self, 
        id_or_source_id: str, 
        context: Optional[str] = None,
        wait: bool = False,
    ) -> Optional[AIDetectPipelineResults]:
        """
        Retrieves the AI detection analysis results for a specific source.

        Args:
            id_or_source_id (str): The unique identifier of the source to get results for.
            context (Optional[str]): An optional context, uses `AIDetectPipeline.default_context` if missing.
            wait (bool): Optionally wait until the source is in a done state by retrying on a response indicating incomplete.
            timeout (int): 

        Returns:
            Optional[AIDetectPipelineResults]: An object containing the AI vs. Real
                probability scores and analysis metadata.
        """
        return self._results(id_or_source_id, AIDetectPipelineResults, context, wait)
