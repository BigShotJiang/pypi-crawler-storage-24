from typing import Literal, Optional, Union
from pydantic import Field
from vermillio.sdk.core import (
    BaseCamelModel,
    ExternalPipeline,
    ExternalSource,
    PipelineSource,
    PipelineStatus,
    PipelineResults,
    PipelineRunRequest,
    PipelineLoadRequest,
)
from ..models import AudioSegment


class AIDetectPipeline(ExternalPipeline): ...


class AIDetectExternalSource(ExternalSource):
    path: str = Field(
        description="An accessible url to download the track from, we support http(s)://, public gs://, public s3://, etc."
    )
    # TODO: we need more comprehensive details about downloading ^^


class AIDetectRunRequest(PipelineRunRequest):
    source: Union[AIDetectExternalSource, str] = Field(
        description="The external source, or path of the fule to run AI Detection on."
    )


class AIDetectLoadRequest(PipelineLoadRequest):
    sources: Union[list[AIDetectExternalSource], list[str]] = Field(
        description="List of external sources (or paths) to run AI Detection on."
    )


class AIDetectPipelineSource(PipelineSource):
    path: str = Field(
        description="An accessible url to download the track from, we support http(s)://, public gs://, public s3://, etc."
    )


class AIDetectPipelineStatus(PipelineStatus):
    pipeline: AIDetectPipeline


class AIDetectSegment(BaseCamelModel):
    query_segment: AudioSegment = Field(
        description="The times in the original source file that this result is associated with."
    )
    label: Literal["real_music", "ai_music"] = Field(
        alias="source_label", description="Whether or not this segment is real or ai."
    )
    confidence: Optional[float] = Field(
        default=None, description="Confidence in the result."
    )
    source_id: str = Field(
        description = "The source (if available) of labelled 'ai_music', if unknown will be 'ai_music'. 'real_music' if labelled as real music.",
        examples = [
            'ace_step', 'heartmula', 'lyria2', 'minimax', 'mureka', 'real_music', 'riffusion_hobby', 'stable_audio_open', 'topmediai', 'yue', 'ai_music'
        ]
    )


class AIDetectResults(BaseCamelModel):
    detections: list[AIDetectSegment] = Field(
        alias="synthetic", default=[], description="List of detection segments"
    )


class AIDetectPipelineResults(PipelineResults):
    results: Optional[AIDetectResults] = Field(
        default=None,
        description="The AI Detection results, if the execution was successful.",
    )
