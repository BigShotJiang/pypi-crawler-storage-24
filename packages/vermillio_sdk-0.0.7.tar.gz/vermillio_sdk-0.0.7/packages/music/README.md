# Vermillio Music SDK

Python SDK for interacting with Vermillio's Music API. This package currently provides the AI Detection pipeline client and models.

## Install

```bash
pip install vermillio-sdk[music]
```

## Configuration

The client loads credentials from environment variables by default:
- `VERMILLIO_SDK_CLIENT_ID`
- `VERMILLIO_SDK_CLIENT_SECRET`

For alternative methods, see `vermillio.sdk.core.config`.

## Quickstart

```python
from vermillio.sdk.music.ai_detect import (
    VermillioMusicAIDetect,
    AIDetectExternalSource,
)

client = VermillioMusicAIDetect()

# Run and wait for results
result = client.run_results(AIDetectExternalSource(path="https://example.com/track.wav"))
if result and result.status == 'Succeeded':
    for segment in result.detections:
        print(segment.start, segment.end, segment.label, segment.confidence)
```