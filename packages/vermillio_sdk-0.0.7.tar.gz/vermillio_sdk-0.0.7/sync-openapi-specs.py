# /// script
# dependencies = [
#   "requests<3",
#   "click",
# ]
# ///

import json
import os
import subprocess
import requests
import click

# Configuration mapping
ENV_CONFIG = {
    "dev": {
        "url": "https://external-pipeline.tce.play.cloud.vermill.io",
    },
    "prod": {
        "url": "https://external-pipeline.tce.cloud.vermill.io",
    },
}

SPECS = [
    {
        "name": "guardrails",
        "dir": "guardrails",
        "path": "/admin/pipeline/guardrails/openapi.json",
    },
    {
        "name": "ai_detect",
        "dir": "music",
        "path": "/admin/pipeline/ai_detect/openapi.json",
    },
]


def get_gcloud_token() -> str:
    """Fetches identity token from gcloud."""
    try:
        result = subprocess.run(
            ["gcloud", "auth", "print-identity-token"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            text=True,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        click.secho(
            "Error: Failed to get gcloud token. Are you logged in?", fg="red", bold=True
        )
        raise click.Abort()


def update_spec(spec_json, base_url):
    """Applies the server and OAuth2 token URL overrides."""
    spec_json["servers"] = [{"url": base_url}]

    components = spec_json.get("components", {})
    security_schemes = components.get("securitySchemes", {})

    for scheme in security_schemes.values():
        if scheme.get("type") == "oauth2":
            flows = scheme.get("flows", {})
            if "clientCredentials" in flows:
                flows["clientCredentials"]["tokenUrl"] = (
                    f"{base_url}/oauth2/application/token"
                )

    return spec_json


@click.command()
@click.option(
    "--env",
    type=click.Choice(["dev", "prod"], case_sensitive=False),
    default="dev",
    show_default=True,
    help="Target environment for the pipeline.",
)
def sync_specs(env):
    """Syncs OpenAPI specs from the External Pipeline to local docs."""
    config = ENV_CONFIG[env]
    base_url = config["url"]

    click.secho(f"\n🚀 Syncing {env.upper()} environment", fg="cyan", bold=True)
    click.echo(f"URL: {base_url}\n")

    auth_token = get_gcloud_token()
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_token}",
    }

    for spec in SPECS:
        full_url = f"{base_url}{spec['path']}"

        try:
            response = requests.get(full_url, headers=headers)
            response.raise_for_status()

            updated_json = update_spec(response.json(), ENV_CONFIG["prod"]["url"])

            # Ensure directory exists
            out_dir = os.path.join("docs", spec["dir"])
            os.makedirs(out_dir, exist_ok=True)

            out_path = os.path.join(out_dir, f"{spec['name']}.json")
            with open(out_path, "w") as f:
                json.dump(updated_json, f, indent=4)

            click.secho("  SUCCESS: ", fg="green", nl=False)
            click.echo(f"Saved {spec['name']} to {out_path}")

        except requests.exceptions.RequestException as e:
            click.secho("  FAILED:  ", fg="red", nl=False)
            click.echo(f"{spec['name']} ({e})")

    click.secho("\n✨ Sync complete!", fg="cyan", bold=True)


if __name__ == "__main__":
    sync_specs()
