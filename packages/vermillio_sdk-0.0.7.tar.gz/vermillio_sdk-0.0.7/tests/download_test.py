import os
import tempfile
from dotenv import load_dotenv
from vermillio.sdk.core import VermillioAssets

load_dotenv()

assets = VermillioAssets()

# verify downloading an individual media file
if "TEST_MEDIA" in os.environ:
    with tempfile.TemporaryDirectory() as dir:
        file = assets.download(os.getenv("TEST_MEDIA"), dir)
        assert os.path.exists(file)

# verify license download
if all(var in os.environ for var in ["TEST_LICENSE", "TEST_ASSET"]):
    with tempfile.TemporaryDirectory() as dir:
        files = assets.download_media_by_license(
            os.getenv("TEST_LICENSE"), os.getenv("TEST_ASSET"), dir
        )
        for file in files:
            assert os.path.exists(file)

# verify bulk (zip) license download
if "TEST_LICENSE" in os.environ:
    with tempfile.TemporaryDirectory() as dir:
        assets.bulk_download_license(os.getenv("TEST_LICENSE"), dir)
        assert len(os.listdir(dir)) > 0
