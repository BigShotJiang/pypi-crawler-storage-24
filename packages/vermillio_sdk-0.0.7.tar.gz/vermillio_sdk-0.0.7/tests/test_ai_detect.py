from dotenv import load_dotenv
from vermillio.sdk.music import VermillioMusicAIDetect, AIDetectExternalSource

load_dotenv()
ai_detect = VermillioMusicAIDetect()


def test_pipeline():
    pipeline = ai_detect.pipeline()
    assert pipeline.name == "ai_detect"
    assert "v1:balanced" in pipeline.contexts
    assert "v1:min" in pipeline.contexts
    assert "v1:max" in pipeline.contexts
    assert "v2" in pipeline.contexts
    assert "v2" == pipeline.default_context


def test_run():
    result = ai_detect.run_results(
        AIDetectExternalSource(path="https://download.samplelib.com/mp3/sample-15s.mp3")
    )
    assert result is not None
    assert result.status == "Succeeded"
    assert result.results is not None
    assert len(result.results.detections) > 0
    assert result.results.detections[0].label == "real_music"
