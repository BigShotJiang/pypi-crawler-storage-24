from dotenv import load_dotenv
from vermillio.sdk.core import VermillioAssets

load_dotenv()
assets = VermillioAssets()
# print(json.dumps(assets.echo(), indent=2))
print(assets.list())
