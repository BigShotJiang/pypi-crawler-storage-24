from dotenv import load_dotenv
from vermillio.sdk.guardrails import VermillioGuardrails, GuardrailsExternalSource

load_dotenv()
guardrails = VermillioGuardrails()


def test_pipeline():
    pipeline = guardrails.pipeline()
    assert pipeline
    assert pipeline.name == "guardrails"
    assert pipeline.contexts == ["test"]
    assert pipeline.default_context == "test"


def test_run():
    result = guardrails.run_results(
        GuardrailsExternalSource(prompt="hello world from vermillio sdk")
    )
    assert result is not None
    assert result.status == "Succeeded"
    assert result.prompt == "hello world from vermillio sdk"
    assert result.summary is not None
    assert result.summary.action == "allow"

    source = guardrails.source(result.id)
    assert source is not None
    assert source.id == result.id
    assert source.status == result.status


def test_recent():
    sources = guardrails.sources()
    assert sources is not None
    assert len(sources) > 0
    for source in sources:
        result = guardrails.results(source.id)
        assert result is not None
        assert result.id == source.id
        assert result.status == source.status


def test_status():
    status = guardrails.status()
    assert status is not None
    assert status.pipeline.name == "guardrails"
    assert status.pipeline.contexts == ["test"]
    assert status.pipeline.default_context == "test"
    assert status.succeeded_count > 0
