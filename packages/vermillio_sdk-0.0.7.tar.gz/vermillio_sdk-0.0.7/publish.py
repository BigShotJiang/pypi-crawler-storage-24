# /// script
# dependencies = [
#   "click>=8.1.7",
#   "tomlkit>=0.12.0",
#   "hatch>=1.12.0",
# ]
# ///
import os
import subprocess
import click
import tomlkit
from pathlib import Path

PACKAGES = [
    "packages/core",
    "packages/music",
    "packages/guardrails",
    "packages/ml",
    ".",  # Root wrapper last
]


def get_current_version():
    tag = os.getenv("CI_COMMIT_TAG")
    if tag and tag.startswith("v"):
        return tag.lstrip("v")
    commit = os.environ.get("CI_COMMIT_SHORT_SHA", "dev")
    """Fetches the most recent tag from the git history."""
    try:
        result = subprocess.run(
            ["git", "describe", "--tags", "--abbrev=0"],
            capture_output=True,
            text=True,
            check=True,
        )
        tag = result.stdout.strip()
        return f"{tag.lstrip('v')}+{commit}"
    except subprocess.CalledProcessError:
        click.secho("❌ No git tags found. Please create a tag first.", fg="red")
        raise click.Abort()


def run(cmd: list[str], cwd: str, dry_run: bool, verbose: bool):
    click.secho(f"▶ Running: {' '.join(cmd)} in {cwd}", fg="cyan")
    if dry_run:
        return
    result = subprocess.run(cmd, cwd=cwd)
    if verbose:
        if result.stdout:
            click.secho(str(result.stdout), fg="green")
        if result.stderr:
            click.secho(str(result.stderr), err=True, fg="red")
    if result.returncode != 0:
        click.secho(f"❌ Command failed in {cwd}", err=True, fg="red", bold=True)
        raise click.Abort()


def sync_versions(version: str, cwd: str, dry_run: bool, verbose: bool):
    """Updates the root pyproject.toml with a specific version for sub-packages."""
    path = Path(cwd) / "pyproject.toml"
    data = tomlkit.parse(path.read_text())

    click.secho(
        f"🔄 Syncing sub-package dependencies to version {version}...", fg="yellow"
    )

    if "project" in data:
        data["project"]["version"] = version
        if dry_run or verbose:
            click.secho(
                f"{cwd}/pyproject.toml: updating version: {version}", fg="magenta"
            )

    # Update main dependencies
    deps = data["project"].get("dependencies", [])
    for i, dep in enumerate(deps):
        if "vermillio-" in dep:
            pkg_name = dep.split(">=")[0].split("==")[0].strip()
            deps[i] = f"{pkg_name}=={version}"
            if dry_run or verbose:
                click.secho(
                    f"{cwd}/pyproject.toml: updating dependency: {dep} -> {deps[i]}",
                    fg="magenta",
                )

    extras = data["project"].get("optional-dependencies", [])
    for group in extras:
        for i, dep in enumerate(extras[group]):
            if "vermillio-" in dep:
                pkg_name = dep.split(">=")[0].split("==")[0].strip()
                extras[group][i] = f"{pkg_name}=={version}"
                if dry_run or verbose:
                    click.secho(
                        f"{cwd}/pyproject.toml: updating extras[{group}]: {dep} -> {extras[group][i]}",
                        fg="magenta",
                    )

    if dry_run:
        click.secho("🧪 pyproject.toml to be updated", fg="magenta")
        if verbose:
            click.secho(tomlkit.dumps(data), fg="magenta")
    else:
        path.write_text(tomlkit.dumps(data))
        click.secho("✅ pyproject.toml updated.", fg="green")


@click.command()
@click.option(
    "--version/--no-version",
    default=True,
    help="Update the version of vermillio sdk dependencies.",
)
@click.option("--build/--no-build", default=True, help="Build the distributions.")
@click.option(
    "--publish/--no-publish", is_flag=True, help="Publish distributions to PyPI."
)
@click.option("--check", is_flag=True, help="Run uv build --check for validation.")
@click.option("--dry-run", is_flag=True, help="Sync version but don't build/publish.")
@click.option("--verbose", is_flag=True, help="Verbose logging.")
def main(
    version: bool, build: bool, publish: bool, check: bool, dry_run: bool, verbose: bool
):
    """Monorepo build & publish manager for Vermillio SDK."""

    if version:
        current_version = get_current_version()
        click.secho(f"🏷️  Detected Version: {current_version}", fg="green", bold=True)

    for pkg in PACKAGES:
        path = Path(pkg) / "pyproject.toml"
        pyproject = tomlkit.parse(path.read_text())
        pkg_name = pyproject.get("project", {}).get(
            "name", Path(pkg).resolve().name if pkg != "." else "vermillio-sdk"
        )
        click.secho(f"\n📦 Processing {pkg_name}...", fg="blue", bold=True)

        if version:
            sync_versions(current_version, pkg, dry_run, verbose)

        if build:
            build_cmd = ["uv", "build", "--no-sources"]
            if check:
                build_cmd.append("--check")
            run(build_cmd, pkg, dry_run, verbose)
    # TODO: upload in order
    if publish:
        run(["uv", "publish"], ".", dry_run, verbose)

    click.secho("\n✨ All tasks completed successfully!", fg="green", bold=True)


if __name__ == "__main__":
    main()
