---
title: Overview
---
# Vermillio SDK

<!-- [![CI](https://gitlab.com/vermillio-public/vermillio-sdk/badges/main/pipeline.svg)](https://gitlab.com/vermillio-public/vermillio-sdk/-/commits/main)
[![pypi](https://img.shields.io/pypi/v/vermillio-sk.svg)](https://pypi.python.org/pypi/vermillio-sdk) -->

The Vermillio SDK is a Python library designed to allow for developers to programmatically interact with the Vermillio platform.

## Installation

Vermillio SDK is published as a Python package and can be installed ideally within a virtual environment. Vermillio SDK requires __Python 3.9+__.

<!-- === "pip"

    ```bash
    pip install vermillio-sdk
    ```

=== "uv"

    ```bash
    uv add vermillio-sdk
    ``` -->


/// tab | pip
```bash
pip install vermillio-sdk
```
///

/// tab | uv
```bash
uv add vermillio-sdk
```
///