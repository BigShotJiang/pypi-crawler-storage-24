---
title: Getting Started
---

# Guardrails SDK
<!-- [![CI](https://gitlab.com/vermillio-public/vermillio-sdk/badges/main/pipeline.svg)](https://gitlab.com/vermillio-public/vermillio-sdk/-/commits/main)
[![pypi](https://img.shields.io/pypi/v/vermillio-sk.svg)](https://pypi.python.org/pypi/vermillio-sdk) -->

## Installation

Vermillio Guardrails SDK is published as a Python package and can be installed ideally within a virtual environment. Vermillio Guardrails SDK requires __Python 3.9+__.

<!-- === "pip"

    ```bash
    pip install vermillio-sdk[guardrails]
    ```

=== "uv"

    ```bash
    uv add vermillio-sdk[guardrails]
    ``` -->


/// tab | pip
```bash
pip install vermillio-sdk[guardrails]
```
///

/// tab | uv
```bash
uv add vermillio-sdk[guardrails]
```
///

## Configuration

The client loads credentials from environment variables by default:

- `VERMILLIO_SDK_CLIENT_ID` : Client id provided by Vermillio
- `VERMILLIO_SDK_CLIENT_SECRET` : Client secret provided by Vermillio

For full documentation, see [Authentication](../sdk/authentication.md#sdk-authentication) for a more detailed description.

## Initialization

All of the classes for Guardrails SDK live under `vermillio.sdk.guardrails`. Here is an example usage:

```python
from vermillio.sdk.guardrails import VermillioGuardrails, GuardrailsExternalSource

guardrails = VermillioGuardrails() # The default behavior is to pull from env
# alternatively a VermillioConfig class can be provided
# guardrails = VermillioGuardrails(VermillioConfig.credentials(client_id, client_secret))

result = next(iter(guardrails.run_results([
    GuardrailsExternalSource(prompt="Write a song about a flying hero from Krypton.", lyrics="Hit me baby one more time.")
] or []), None)

if result and result.status == 'Succeeded':
    print(f"Recommended action: {result.action}")
    print(f"Identified profiles: {result.summary.profiles}")
```
