---
title: SDK Reference
---
# Guardrails SDK Reference

## VermillioGuardrails Client
The `VermillioGuardrails` client is the primary interface for interacting with the Guardrails API.

::: vermillio.sdk.guardrails.VermillioGuardrails
    options:
      show_root_heading: false
      show_source: false

## Guardrails Model Classes
These Pydantic models represent the inputs and outputs of the Guardrails service.

::: vermillio.sdk.guardrails.models
    options:
      show_root_heading: false
      group_by_category: true
      show_source: false