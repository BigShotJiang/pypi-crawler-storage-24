---
hide:
  - toc
title: API Reference
---
# Guardrails API Reference

<!-- <iframe 
    src="../assets/scalar.html" 
    style="width:100%; height:800px; border:none; overflow:hidden;" scrolling="no"
></iframe> -->

<swagger-ui  src="./guardrails.json"/>