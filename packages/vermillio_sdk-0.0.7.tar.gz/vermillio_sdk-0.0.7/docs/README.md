# Docs


Ref: https://vermillio.atlassian.net/wiki/spaces/~486166302/pages/1320353828/Vermillio+SDK+Documentation


https://www.mkdocs.org/getting-started/

uv sync --group docs

uv run mkdocs build
uv run mkdocs serve
mkdocs serve


mkdocs build


## Examples

- Ray: https://docs.ray.io/
- DVC (Data Version Control): https://dvc.org/doc
- Poetry: https://python-poetry.org/docs/
- MkDocs Awesome Pages Plugin: https://lukasgeiter.github.io/mkdocs-awesome-pages-plugin/
- Home Assistant Developer Docs: https://developers.home-assistant.io/
- OpenFaaS: https://docs.openfaas.com/
- FastAPI: https://fastapi.tiangolo.com/
- Pydantic: https://docs.pydantic.dev/
- MKDocs Material: https://squidfunk.github.io/mkdocs-material/


## Investigate

- https://zensical.org/
- OpenAPI spec integration for interactive API
- Docusaurus


## OpenAPI integration

Using Scalar

```bash
npx @redocly/cli@latest join ./docs/openapi_specs/external-api.yaml ./docs/openapi_specs/petstore.yaml -o ./docs/openapi_specs/combined.yaml
```