---
title: Getting Started
description: Getting started with the Vermillio Music SDK.
---
# Music SDK

<!-- [![CI](https://gitlab.com/vermillio-public/vermillio-sdk/badges/main/pipeline.svg)](https://gitlab.com/vermillio-public/vermillio-sdk/-/commits/main)
[![pypi](https://img.shields.io/pypi/v/vermillio-sk.svg)](https://pypi.python.org/pypi/vermillio-sdk) -->

The Vermillio Music SDK is a Python library designed to allow for developers to programmatically interact with the Vermillio platform.

## Installation

Vermillio Music SDK is published as a Python package and can be installed ideally within a virtual environment. Vermillio Music SDK requires __Python 3.9+__.

<!-- === "pip"

    ```bash
    pip install vermillio-sdk[music]
    ```

=== "uv"

    ```bash
    uv add vermillio-sdk[music]
    ``` -->


/// tab | pip
```bash
pip install vermillio-sdk[music]
```
///

/// tab | uv
```bash
uv add vermillio-sdk[music]
```
///

## Configuration

The client loads credentials from environment variables by default:

- `VERMILLIO_SDK_CLIENT_ID` : Client id provided by Vermillio
- `VERMILLIO_SDK_CLIENT_SECRET` : Client secret provided by Vermillio

For full documentation, see [Authentication](../sdk/authentication.md#sdk-authentication) for a more detailed description.

## Initialization

All of the classes for Music SDK live under `vermillio.sdk.music`. Here is an example usage:

```python
from vermillio.sdk.music import VermillioMusicAIDetect, AIDetectExternalSource

ai_detect = VermillioMusicAIDetect() # The default behavior is to pull from env
# alternatively a VermillioConfig class can be provided
# ai_detect = VermillioMusicAIDetect(VermillioConfig.credentials(client_id, client_secret))

result = next(iter(ai_detect.run_results([
    AIDetectExternalSource(path="https://example.com/track.wav"),
] or [])), None)

if result and result.status == 'Succeeded':
    for detection in result.results.detections:
        confidence = f"({detection.confidence:0.2f})" if detection.confidence else "--"
        print(f"[{detection.query_segment.start:0.2f}-{detection.query_segment.end:0.2f}] {segment.label} {confidence}")
```
