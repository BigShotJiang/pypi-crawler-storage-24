---
title: SDK Reference
---
# Vermillio Music SDK Reference

## Vermillio Music AI Detect Client
The `VermillioMusicAIDetect` client is the primary interface for interacting with the Music AI Detect Service.

::: vermillio.sdk.music.ai_detect.VermillioMusicAIDetect
    options:
      show_root_heading: false
      show_source: false

## Music AI Detect Model Classes
These Pydantic models represent the inputs and outputs of the Music AI Detect Service.

::: vermillio.sdk.music.ai_detect.models
    options:
      show_root_heading: false
      group_by_category: true
      show_source: false

::: vermillio.sdk.music.models
    options:
      show_root_heading: false
      group_by_category: true
      show_source: false