---
hide:
  - toc
title: API Reference
---
# Music API Reference

<!-- <iframe 
    src="../assets/scalar.html" 
    style="width:100%; height:800px; border:none; overflow:hidden;" scrolling="no"
></iframe> -->

### AI Detect API Reference
<swagger-ui  src="./ai_detect.json"/>
