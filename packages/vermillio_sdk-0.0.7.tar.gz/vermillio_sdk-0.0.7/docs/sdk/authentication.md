---
title: Authentication
---

## Authentication

When a developer licenses content through the Vermillio Platform, client credentials are provided. Client credentials consist of a client_id and client_secret which are used in an OAuth 2 Authorization Code Flow to acquire an access_token. All requests to Vermillio Endpoints require a valid access_token passed via the Authorization header as a bearer token.

The flow is initiated by calling the following endpoint:

```bash
POST https://auth.cloud.vermill.io/oauth2/token
```

with the following form (not JSON) parameters:
`client_id`: The `client_id` provided by Vermillio associated with your application.  
`client_secret`: The `client_secret` provided by Vermillio associated with your application.  
`grant_type`: Required and always set to `client_credentials`.  
`audience`: Required and always set to `grant_type=https://application.vermill.io`

If the provided credentials are correct, the endpoint will respond with a JSON object with the following fields:
`access_token`: This is the access token that should be used in all subsequent requests to Vermillio Endpoints.
`expires_in`: The number of seconds as an `int` until the `access_token` is expired. Expired tokens will not be accepted by Vermillio Endpoints.
`scope`: The scope of the access token.
`token_type`: The type of token.

On subsequent calls to Vermillio Endpoints the `access_token` should be used in the `Authorization` header as a bearer token, for example:

```
Authorization: Bearer {access_token}
```

## SDK Authentication

All Vermillio SDK's use a `VermillioConfig` object to authenticate requests to the underlying API's. The `VermillioConfig` holds the `client_id`/`client_secret` as well as additional environment information required to interact with Vermillio API's.

There are several methods for authentication in the Vermillio SDK. The default behavior is to pull the client id and client secret from well known environment variables:
- `VERMILLIO_SDK_CLIENT_ID` : The `client_id` mentioned above.
- `VERMILLIO_SDK_CLIENT_SECRET` : The `client_secret` mentioned above.

### Alternative Methods

The default prefix for environment variables (`VERMILLIO_SDK_`) can be customized:
```python
from vermillio.sdk.core import VermillioConfig

# Load MY_PREFIX_CLIENT_ID and MY_PREFIX_CLIENT_SECRET instead
config = VermillioConfig.from_env('MY_PREFIX_')
# use config in SDK constructor...
```

Or you can bring your own values:
```python
from vermillio.sdk.core import VermillioConfig

config = VermillioConfig.credentials(client_id, client_secret)
# use config in SDK constructor...
```

There's also a utility to store the default config when no config is directly provided to a client:
```python
from vermillio.sdk.core import VermillioConfig

VermillioConfig.set_default(VermillioConfig.from_env('MY_PREFIX_'))
```