# Vermillio SDK

Entrypoint for Vermillio's various SDK's for interacting with Vermillio API's.

## Guardrails SDK

### Installing

```bash
pip install vermillio-sdk[guardrails]
uv add vermillio-sdk[guardrails]
```


### Getting Started

```python
from vermillio.sdk.guardrails import VermillioGuardrails, GuardrailsExternalSource

client = VermillioGuardrails()

result = client.run_results(GuardrailsExternalSource(
    prompt="Write a song about a flying hero from Krypton.",
))
if result:
    if result.status == 'Succeeded':
        print(result.summary)
    else:
        print(result.status)
```

## Music SDK

### Installing

```bash
pip install vermillio-sdk[music]
uv add vermillio-sdk[music]
```

### Getting Started

```python
from vermillio.sdk.music import VermillioMusicAIDetect, AIDetectExternalSource

ai_detect = VermillioMusicAIDetect()
result = ai_detect.run_results(
    AIDetectExternalSource(path="https://example.com/track.wav"),
)

if result and result.status == 'Succeeded':
    for detection in result.results.detections:
        confidence = f"({detection.confidence:0.2f})" if detection.confidence else "--"
        print(f"[{detection.query_segment.start:0.2f}-{detection.query_segment.end:0.2f}] {segment.label} {confidence}")
```
