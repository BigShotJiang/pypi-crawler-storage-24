from .client import ZoraAIClient
from .exceptions import APIError, AuthenticationError, RateLimitError, ZoraAIError
from .models import SMSAnalysisResult
from .sms import SMSAnalyzer

# Preferred alias requested by developer ergonomics docs.
SmsAnalyzer = SMSAnalyzer

__all__ = [
    "ZoraAIClient",
    "SMSAnalyzer",
    "SmsAnalyzer",
    "SMSAnalysisResult",
    "ZoraAIError",
    "APIError",
    "AuthenticationError",
    "RateLimitError",
]
