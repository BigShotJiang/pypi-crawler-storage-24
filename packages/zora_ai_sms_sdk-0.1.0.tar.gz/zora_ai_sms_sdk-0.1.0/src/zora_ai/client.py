from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx

from .exceptions import APIError, AuthenticationError, RateLimitError
from .utils import (
    build_auth_header,
    compute_backoff_delay,
    normalize_base_url,
    parse_retry_after,
    sleep_for,
)


class ZoraAIClient:
    """Core API client for Zora AI REST APIs."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "http://localhost:8000",
        timeout: float = 30.0,
        max_retries: int = 3,
        backoff_factor: float = 0.5,
        enable_logging: bool = False,
        logger: logging.Logger | None = None,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError("api_key must be a non-empty string")
        if timeout <= 0:
            raise ValueError("timeout must be greater than 0")
        if max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if backoff_factor < 0:
            raise ValueError("backoff_factor must be >= 0")

        self.base_url = normalize_base_url(base_url)
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            **build_auth_header(api_key.strip()),
        }
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout,
        )

        self.logger = logger or logging.getLogger("zora_ai.client")
        self.enable_logging = enable_logging

    async def __aenter__(self) -> ZoraAIClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self.client.aclose()

    async def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        return await self.request("GET", path, params=params, timeout=timeout)

    async def post(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        return await self.request("POST", path, json=json, timeout=timeout)

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        request_timeout = timeout if timeout is not None else self.timeout

        for attempt in range(self.max_retries + 1):
            try:
                if self.enable_logging:
                    self.logger.debug("Request %s %s attempt=%s", method, path, attempt + 1)

                response = await self.client.request(
                    method=method.upper(),
                    url=path,
                    params=params,
                    json=json,
                    timeout=request_timeout,
                )
            except httpx.RequestError as exc:
                if attempt >= self.max_retries:
                    raise APIError("Network error while calling Zora AI API", details=str(exc)) from exc
                delay = compute_backoff_delay(attempt, self.backoff_factor)
                if self.enable_logging:
                    self.logger.warning("Network error, retrying in %.2fs: %s", delay, exc)
                await asyncio.sleep(delay)
                continue

            if self._is_retryable_status(response.status_code) and attempt < self.max_retries:
                retry_after = parse_retry_after(response.headers.get("Retry-After"))
                delay = retry_after if retry_after is not None else compute_backoff_delay(attempt, self.backoff_factor)
                if self.enable_logging:
                    self.logger.warning(
                        "Retryable response status=%s, retrying in %.2fs",
                        response.status_code,
                        delay,
                    )
                await asyncio.sleep(delay)
                continue

            return self._handle_response(response)

        raise APIError("Unexpected client retry flow failure")

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        request_id = response.headers.get("x-request-id")
        status_code = response.status_code

        payload: dict[str, Any] | None = None
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                payload = parsed
            else:
                payload = {"data": parsed}
        except ValueError:
            payload = None

        if 200 <= status_code < 300:
            if payload is None:
                payload = {}
            if request_id and "request_id" not in payload:
                payload["request_id"] = request_id
            return payload

        message = "Request failed"
        details: Any = None
        if payload is not None:
            details = payload
            if isinstance(payload.get("detail"), str):
                message = payload["detail"]
        else:
            details = response.text
            if response.text:
                message = response.text

        if status_code == 401:
            raise AuthenticationError(
                message,
                status_code=status_code,
                details=details,
                request_id=request_id,
            )

        if status_code == 429:
            raise RateLimitError(
                message,
                retry_after=parse_retry_after(response.headers.get("Retry-After")),
                status_code=status_code,
                details=details,
                request_id=request_id,
            )

        if status_code == 400 or 500 <= status_code <= 599:
            raise APIError(
                message,
                status_code=status_code,
                details=details,
                request_id=request_id,
            )

        raise APIError(
            message,
            status_code=status_code,
            details=details,
            request_id=request_id,
        )

    @staticmethod
    def _is_retryable_status(status_code: int) -> bool:
        return status_code in {429, 500, 502, 503, 504}
