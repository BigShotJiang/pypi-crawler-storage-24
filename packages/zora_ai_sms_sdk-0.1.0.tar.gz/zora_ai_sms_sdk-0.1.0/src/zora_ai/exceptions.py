from __future__ import annotations

from typing import Any


class ZoraAIError(Exception):
    """Base exception for all SDK errors."""


class APIError(ZoraAIError):
    """Generic API error with optional HTTP metadata."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.details = details
        self.request_id = request_id


class AuthenticationError(APIError):
    """Raised when API authentication fails."""


class RateLimitError(APIError):
    """Raised when API rate limit is exceeded."""

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        status_code: int | None = 429,
        details: Any | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            message,
            status_code=status_code,
            details=details,
            request_id=request_id,
        )
        self.retry_after = retry_after
