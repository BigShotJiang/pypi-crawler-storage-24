from __future__ import annotations

from .client import ZoraAIClient
from .models import SMSAnalysisResult


class SMSAnalyzer:
    """SMS analyzer facade for fraud/phishing detection."""

    def __init__(self, client: ZoraAIClient) -> None:
        self._client = client

    async def analyze(self, text: str, with_llm_explanation: bool = False) -> SMSAnalysisResult:
        if not text or not text.strip():
            raise ValueError("text must be a non-empty string")

        payload = {
            "text": text,
            "include_llm_explanation": bool(with_llm_explanation),
        }
        data = await self._client.post("/text/sms/analyze", json=payload)
        return SMSAnalysisResult.from_api_response(data)
