from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(slots=True)
class SMSAnalysisResult:
    request_id: str | None
    risk_score: float
    confidence: float
    fraud_type: str
    explanation: str
    sub_scores: dict[str, float]
    flags: list[str] = field(default_factory=list)
    llm_enhanced: bool = False
    llm_explanation: str | None = None
    raw_response: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_api_response(cls, payload: Mapping[str, Any]) -> "SMSAnalysisResult":
        sub_scores = {
            "nlp_score": float(payload.get("nlp_score", 0.0) or 0.0),
            "similarity_score": float(payload.get("similarity_score", 0.0) or 0.0),
            "stylometry_score": float(payload.get("stylometry_score", 0.0) or 0.0),
        }

        flags_raw = payload.get("flags", [])
        flags = [str(item) for item in flags_raw] if isinstance(flags_raw, list) else []

        return cls(
            request_id=str(payload["request_id"]) if payload.get("request_id") is not None else None,
            risk_score=float(payload.get("risk_score", 0.0) or 0.0),
            confidence=float(payload.get("confidence", 0.0) or 0.0),
            fraud_type=str(payload.get("fraud_type", "unknown")),
            explanation=str(payload.get("explanation", "")),
            sub_scores=sub_scores,
            flags=flags,
            llm_enhanced=bool(payload.get("llm_enhanced", False)),
            llm_explanation=str(payload["llm_explanation"]) if payload.get("llm_explanation") else None,
            raw_response=payload,
        )
