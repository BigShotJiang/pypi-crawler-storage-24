from __future__ import annotations

import time


def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def build_auth_header(api_key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {api_key}"}


def compute_backoff_delay(attempt: int, backoff_factor: float, max_delay: float = 10.0) -> float:
    # attempt=0 -> backoff_factor, attempt=1 -> backoff_factor*2, etc.
    return min(max_delay, backoff_factor * (2 ** attempt))


def sleep_for(seconds: float) -> None:
    if seconds > 0:
        time.sleep(seconds)


def parse_retry_after(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        retry_after = float(value)
    except (TypeError, ValueError):
        return None
    return retry_after if retry_after >= 0 else None
