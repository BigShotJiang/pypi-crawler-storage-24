---
name: "feature-implementation"
description: "Spec-to-code-to-test feature implementation procedure with structured workflow"
short_desc: "Spec-to-code-to-test implementation procedure"
version: "1.0.0"
tags: ["feature", "implementation", "workflow", "tdd"]
---

# Feature Implementation Skill

스펙 분석부터 코드 작성, 테스트, 문서화까지 기능 구현의 전체 워크플로우를 수행합니다.

## Procedure

### Step 1: Spec Analysis
1. 요구사항을 명확히 이해합니다
   - 기능적 요구사항 (무엇을 해야 하는가)
   - 비기능적 요구사항 (성능, 보안, 접근성)
   - 제약 조건 (기술 스택, 호환성)
2. 모호한 점은 질문으로 명확히 합니다
3. 수용 기준(Acceptance Criteria)을 정리합니다

### Step 2: Design
1. 기존 코드베이스 패턴을 파악합니다
2. 변경이 필요한 파일/모듈을 식별합니다
3. 인터페이스/API를 먼저 설계합니다
4. 데이터 흐름을 스케치합니다

### Step 3: Implementation
1. **점진적 구현** — 작은 단위로 나눠서 작성
2. **기존 패턴 준수** — 프로젝트의 코딩 스타일과 일관되게
3. **YAGNI** — 현재 요구사항에 필요한 것만 구현
4. **명확한 네이밍** — 코드가 자체 문서가 되도록
5. 각 단계마다 동작을 확인합니다

### Step 4: Testing
1. **단위 테스트** — 핵심 로직의 정상/비정상 케이스
2. **통합 테스트** — 모듈 간 상호작용
3. **엣지 케이스** — 경계값, null, 빈 값, 대량 데이터
4. 테스트가 실패하면 구현을 수정합니다

### Step 5: Review & Polish
1. 코드를 다시 읽으며 정리합니다
2. 불필요한 코드, TODO, 디버그 코드를 제거합니다
3. 필요한 경우 문서를 업데이트합니다
4. 변경 사항을 요약하여 PR/커밋 메시지를 작성합니다

## Checklist
- [ ] 수용 기준을 모두 충족하는가?
- [ ] 기존 테스트가 깨지지 않는가?
- [ ] 새 기능에 대한 테스트가 있는가?
- [ ] 코딩 스타일이 프로젝트와 일관되는가?
- [ ] 보안 고려사항을 확인했는가?
- [ ] 성능 영향을 확인했는가?
