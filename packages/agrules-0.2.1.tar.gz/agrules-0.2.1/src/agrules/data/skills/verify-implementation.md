---
name: "verify-implementation"
description: "Run all project verify-* skills sequentially and produce a unified verification report"
short_desc: "Unified verification runner for all verify-* skills"
version: "1.0.0"
tags: ["verification", "quality", "testing", "pre-pr"]
---

# Verify Implementation Skill

프로젝트에 등록된 모든 `verify-*` 스킬을 순차 실행하여 통합 검증 보고서를 생성합니다.

## When to Use

- 새로운 기능을 구현한 후
- Pull Request를 생성하기 전
- 코드 리뷰 중
- 코드베이스 규칙 준수 여부를 감사할 때

## How It Works

이 스킬은 `.claude/skills/` 디렉토리에서 `verify-*` 패턴의 스킬을 탐색하고 순차 실행합니다. 각 스킬의 SKILL.md에 정의된 Workflow와 Exceptions를 준수합니다.

## Workflow

### Step 1: 스킬 탐색

`.claude/skills/` 디렉토리에서 `verify-*` 패턴의 스킬을 탐색합니다.

```bash
ls -d .claude/skills/verify-*/ 2>/dev/null
```

**등록된 스킬이 없는 경우:**

프로젝트의 기본 검증을 대신 수행합니다:

| 검사 | 명령어 |
|------|--------|
| Build | 프로젝트 빌드 도구 자동 감지 후 실행 |
| Type check | `tsc --noEmit` / `pyright` / `go vet ./...` |
| Lint | `npm run lint` / `ruff check .` / `golangci-lint run` |
| Test | `npm test` / `pytest` / `go test ./...` |

**등록된 스킬이 있는 경우:**

```
다음 검증 스킬을 순차 실행합니다:

| # | 스킬 | 설명 |
|---|------|------|
| 1 | verify-<name1> | <description1> |
| 2 | verify-<name2> | <description2> |
```

### Step 2: 순차 실행

각 `verify-*` 스킬에 대해:

#### 2a. SKILL.md 읽기

해당 스킬의 `.claude/skills/verify-<name>/SKILL.md`를 읽고 파싱:

- **Workflow** — 실행할 검사 단계와 탐지 명령어
- **Exceptions** — 위반이 아닌 것으로 간주되는 패턴
- **Related Files** — 검사 대상 파일 목록

#### 2b. 검사 실행

1. Workflow에 정의된 각 검사를 순서대로 실행
2. 탐지된 결과를 PASS/FAIL 기준에 대조
3. Exceptions에 해당하는 패턴은 면제 처리
4. FAIL인 경우 이슈 기록:
   - 파일 경로 및 라인 번호
   - 문제 설명
   - 수정 권장 사항 (코드 예시 포함)

#### 2c. 스킬별 결과 표시

```
### verify-<name> 검증 완료

- 검사 항목: N개
- 통과: X개
- 이슈: Y개
- 면제: Z개
```

### Step 3: 통합 보고서

```
## 구현 검증 보고서

### 요약

| 검증 스킬 | 상태 | 이슈 수 |
|-----------|------|---------|
| verify-<name1> | PASS / X개 이슈 | N |
| verify-<name2> | PASS / X개 이슈 | N |

**발견된 총 이슈: X개**
```

**모든 검증 통과 시:**

```
모든 검증을 통과했습니다! 코드 리뷰 준비가 완료되었습니다.
```

**이슈 발견 시:**

```
| # | 스킬 | 파일 | 문제 | 수정 방법 |
|---|------|------|------|-----------|
| 1 | verify-<name> | path/to/file:42 | 문제 설명 | 수정 코드 예시 |
```

### Step 4: 사용자 액션 확인

이슈가 발견된 경우 사용자에게 확인:

```
### 수정 옵션

X개 이슈가 발견되었습니다. 어떻게 진행할까요?

1. **전체 수정** — 모든 권장 수정사항을 자동 적용
2. **개별 수정** — 각 수정사항을 하나씩 검토 후 적용
3. **건너뛰기** — 변경 없이 종료
```

### Step 5: 수정 적용

**전체 수정**: 모든 수정을 순서대로 적용하며 진행 상황 표시

**개별 수정**: 각 이슈마다 수정 내용을 보여주고 승인 여부 확인

### Step 6: 수정 후 재검증

수정이 적용된 경우, 이슈가 있었던 스킬만 다시 실행하여 Before/After 비교:

```
## 수정 후 재검증

| 검증 스킬 | 수정 전 | 수정 후 |
|-----------|---------|---------|
| verify-<name1> | X개 이슈 | PASS |

모든 검증을 통과했습니다!
```

여전히 이슈가 남은 경우 수동 해결 안내를 표시합니다.

## Exceptions

다음은 문제가 아닙니다:

1. **verify-* 스킬이 없는 프로젝트** — 기본 검증(빌드/린트/테스트)을 대신 수행
2. **각 스킬의 자체 예외** — Exceptions 섹션에 정의된 패턴은 이슈로 보고하지 않음
3. **verify-implementation 자체** — 실행 대상에 자기 자신을 포함하지 않음

---

**TIP**: `/ship` 전에 `/verify-implementation`을 실행하여 품질 게이트를 통과하세요.
