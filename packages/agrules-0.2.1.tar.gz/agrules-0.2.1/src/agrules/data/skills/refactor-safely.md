---
name: "refactor-safely"
description: "Safe refactoring patterns with verification steps to prevent regressions"
short_desc: "Safe refactoring patterns with regression prevention"
version: "1.0.0"
tags: ["refactoring", "code-quality", "safety", "patterns"]
---

# Safe Refactoring Skill

기존 동작을 보존하면서 코드 구조를 개선하는 안전한 리팩토링 절차입니다.

## Procedure

### Step 1: Assessment
1. 리팩토링 대상과 목표를 명확히 합니다
   - 무엇을 개선하려는가? (가독성, 성능, 확장성)
   - 변경 범위는 어디까지인가?
2. 기존 테스트 커버리지를 확인합니다
3. 테스트가 부족하면 먼저 보강합니다

### Step 2: Safety Net
1. **테스트가 모두 통과하는 상태에서 시작합니다**
2. 리팩토링 전 상태를 커밋/브랜치로 보존합니다
3. 대상 코드의 현재 동작을 문서화합니다

### Step 3: Incremental Changes
1. **한 번에 하나의 리팩토링만 수행합니다**
   - Extract Method/Function
   - Rename Variable/Function
   - Move to separate module
   - Simplify conditional
   - Remove duplication
2. 각 변경 후 테스트를 실행합니다
3. 테스트 실패 시 즉시 롤백합니다

### Step 4: Common Patterns
| 패턴 | 적용 시점 | 주의사항 |
|------|-----------|----------|
| Extract Function | 함수가 너무 길거나 여러 일을 할 때 | 파라미터 수 주의 |
| Inline | 불필요한 간접 참조 | 호출처가 많으면 주의 |
| Rename | 이름이 의도를 표현하지 못할 때 | IDE 리팩토링 기능 활용 |
| Move | 잘못된 모듈에 위치할 때 | import 경로 변경 확인 |
| Replace Conditional with Polymorphism | 복잡한 switch/if-else | 과도한 추상화 주의 |

### Step 5: Verification
1. 모든 테스트가 통과하는지 확인합니다
2. 리팩토링 전후 동작이 동일한지 확인합니다
3. 성능 회귀가 없는지 확인합니다
4. 변경 사항을 리뷰합니다

## Rules
- 리팩토링과 기능 변경을 동시에 하지 않습니다
- 동작하는 코드를 먼저 만들고, 그 다음 정리합니다
- 테스트 없이 리팩토링하지 않습니다
- 완벽을 추구하지 않습니다 — 점진적으로 개선합니다
