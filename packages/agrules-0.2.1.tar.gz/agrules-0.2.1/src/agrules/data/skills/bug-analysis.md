---
name: "bug-analysis"
description: "Bug analysis and root cause investigation workflow with systematic debugging approach"
short_desc: "Bug analysis and root cause investigation workflow"
version: "1.0.0"
tags: ["debugging", "bug", "root-cause", "analysis"]
---

# Bug Analysis Skill

버그의 근본 원인을 체계적으로 분석하고, 재현 → 원인 파악 → 수정 → 검증의 워크플로우를 수행합니다.

## Procedure

### Step 1: Bug Reproduction
1. 버그 보고서에서 재현 조건을 추출합니다
2. 최소 재현 케이스(Minimal Reproduction)를 만듭니다
3. 재현 가능 여부를 확인합니다
   - 항상 재현? 간헐적? 특정 환경에서만?

### Step 2: Information Gathering
1. **에러 메시지/스택 트레이스** 수집
2. **로그** 확인 (application, system, network)
3. **환경 정보** — OS, 런타임 버전, 의존성 버전
4. **최근 변경사항** — git log/blame으로 관련 커밋 확인
5. **관련 이슈** — 과거 유사 버그 검색

### Step 3: Root Cause Analysis
**5 Whys 기법 적용:**
1. 왜 버그가 발생했는가?
2. 왜 그 조건이 충족되었는가?
3. 왜 그 상태가 가능했는가?
4. 왜 방어 로직이 없었는가?
5. 왜 테스트에서 잡지 못했는가?

**원인 분류:**
- 로직 오류 (조건문, 경계값)
- 상태 관리 오류 (race condition, stale state)
- 데이터 오류 (null, 타입 불일치)
- 의존성 오류 (API 변경, 버전 불일치)
- 환경 오류 (설정, 권한, 리소스)

### Step 4: Fix Implementation
1. 근본 원인을 해결하는 최소 변경을 작성합니다
2. 증상만 가리는 workaround는 피합니다
3. 관련 코드에 방어 로직을 추가합니다

### Step 5: Verification
1. 원래 재현 케이스에서 버그가 해결되었는지 확인합니다
2. 회귀 테스트를 작성합니다
3. 관련 엣지 케이스도 테스트합니다
4. 사이드 이펙트가 없는지 확인합니다

## Output Template
```
## Bug Analysis Report
- **증상**: (사용자가 경험한 현상)
- **재현 조건**: (재현 단계)
- **근본 원인**: (코드 레벨 원인)
- **수정 내용**: (변경 사항 요약)
- **검증**: (테스트 결과)
- **예방**: (재발 방지를 위한 조치)
```
