---
name: "code-review"
description: "Systematic code review procedure with checklists, severity levels, and constructive feedback patterns"
short_desc: "Step-by-step code review procedure"
version: "1.0.0"
tags: ["code-review", "quality", "feedback", "checklist"]
---

# Code Review Skill

체계적인 코드 리뷰를 수행하는 절차입니다. 체크리스트 기반으로 일관된 품질 기준을 적용하고, 건설적인 피드백을 제공합니다.

## Procedure

### Step 1: Context Understanding
1. PR/변경의 목적과 배경을 파악합니다
2. 관련 이슈/티켓을 확인합니다
3. 변경 범위(파일 수, 라인 수)를 파악합니다

### Step 2: High-Level Review
1. **아키텍처 적합성** — 기존 패턴과 일관되는가?
2. **설계 결정** — 더 나은 대안이 있는가?
3. **변경 범위** — 하나의 PR에 하나의 관심사만 다루는가?

### Step 3: Detailed Review Checklist
- [ ] **정확성**: 로직이 올바른가? 엣지 케이스 처리?
- [ ] **보안**: OWASP Top 10 위반? 입력 검증? 인증/인가?
- [ ] **성능**: N+1 쿼리? 불필요한 반복? 메모리 누수?
- [ ] **가독성**: 명확한 이름? 적절한 추상화 수준?
- [ ] **테스트**: 충분한 커버리지? 의미 있는 테스트 케이스?
- [ ] **에러 처리**: 실패 시나리오 대응? 적절한 에러 메시지?

### Step 4: Severity Classification
| 심각도 | 의미 | 예시 |
|--------|------|------|
| 🔴 Critical | 반드시 수정 | 보안 취약점, 데이터 손실 가능성 |
| 🟡 Major | 수정 권장 | 성능 이슈, 설계 문제 |
| 🟢 Minor | 선택적 | 네이밍 개선, 코드 스타일 |
| 💡 Suggestion | 제안 | 대안 접근법, 학습 포인트 |

### Step 5: Feedback Format
```
[심각도] 파일:라인 — 문제 요약

문제: (무엇이 잘못되었는가)
이유: (왜 문제인가)
제안: (어떻게 개선할 수 있는가)
```

## Best Practices
- 코드가 아닌 사람을 비판하지 않습니다
- "왜?"를 먼저 물어봅니다 — 의도를 파악한 후 제안합니다
- 긍정적인 피드백도 포함합니다
- 대안을 제시할 때는 코드 예시를 포함합니다
