---
name: "pr-creation"
description: "Pull request creation best practices with structured title, description, and review guidance"
short_desc: "Pull request creation best practices"
version: "1.0.0"
tags: ["pull-request", "pr", "git", "collaboration"]
---

# PR Creation Skill

효과적인 Pull Request를 작성하는 절차입니다. 명확한 제목, 구조화된 설명, 리뷰어를 위한 가이드를 포함합니다.

## Procedure

### Step 1: Pre-PR Checklist
1. 변경 사항이 하나의 관심사에 집중되어 있는지 확인합니다
2. 모든 테스트가 통과하는지 확인합니다
3. 린터/포매터를 실행합니다
4. 불필요한 파일(디버그 로그, .env 등)이 포함되지 않았는지 확인합니다
5. 커밋 히스토리가 깔끔한지 확인합니다

### Step 2: Title
- Conventional Commits 형식을 따릅니다
- 70자 이내로 작성합니다
- 예시:
  - `feat: add user authentication with JWT`
  - `fix: resolve race condition in order processing`
  - `refactor: extract payment logic into service layer`

### Step 3: Description
```markdown
## Summary
(변경 사항을 1-3 문장으로 요약)

## Changes
- (주요 변경사항을 불릿 포인트로)

## Why
(이 변경이 필요한 이유, 관련 이슈 링크)

## Test Plan
- [ ] (테스트 항목 1)
- [ ] (테스트 항목 2)

## Screenshots (optional)
(UI 변경이 있는 경우)
```

### Step 4: Review Guidance
1. 리뷰어가 집중해야 할 부분을 명시합니다
2. 의도적인 설계 결정이 있으면 설명합니다
3. 논의가 필요한 부분은 코멘트로 표시합니다

### Step 5: Self-Review
1. diff를 직접 읽으며 최종 점검합니다
2. 리뷰어 관점에서 이해하기 어려운 부분이 없는지 확인합니다

## Best Practices
- PR 크기는 400줄 이하를 목표로 합니다
- 큰 기능은 여러 PR로 나눕니다
- Draft PR을 활용하여 조기 피드백을 받습니다
- 리뷰 코멘트에 24시간 이내 응답합니다
