---
description: "Fast-track commit, merge, and delivery — push to main or create PR"
short_desc: "Commit and ship: push to main or create PR in one step"
category: "git"
agent: "build"
---

# Ship Command

Fast-track commit and delivery. Analyzes changes, generates commit message, and ships.

**Usage:**
- `/ship` or `/ship push` — commit + merge to main + push
- `/ship pr` — commit + create PR to main
- `/ship amend` — amend last commit + force push current branch

## Arguments

$ARGUMENTS — optional: `push` (default), `pr`, or `amend`

## Steps

### 1. Pre-flight Checks

```bash
git status
git diff --stat HEAD
git log --oneline -5
```

- If working tree is clean, say "Nothing to ship" and stop
- Detect current branch name

### 2. Build Verification

Run the project's build/test commands. Auto-detect from project files:

| Indicator | Build Command | Test Command |
|-----------|---------------|--------------|
| `package.json` | `npm run build` | `npm test` |
| `pyproject.toml` / `setup.py` | `python -m build` or skip | `pytest` |
| `go.mod` | `go build ./...` | `go test ./...` |
| `Cargo.toml` | `cargo build` | `cargo test` |
| `Makefile` | `make build` or `make` | `make test` |

Only run builds if relevant source files changed. Skip if only docs/config changed.

**If build fails, stop and report errors. Do not commit broken code.**

### 3. Commit

- Analyze all staged + unstaged changes (use `git diff` and `git diff --cached`)
- Auto-generate commit message following conventional commits:
  - `feat(scope):` for new features
  - `fix(scope):` for bug fixes
  - `refactor(scope):` for refactoring
  - `docs(scope):` for documentation
  - `chore(scope):` for maintenance
  - `test(scope):` for test changes
- Stage relevant files explicitly (never `git add -A`)
- Commit with generated message + `Co-Authored-By: Claude <noreply@anthropic.com>`
- Show the commit to the user for confirmation before proceeding

### 4a. Mode: `push` (default)

- If on a feature branch:
  ```bash
  git checkout main && git pull origin main && git merge <branch> && git push origin main
  ```
- If already on main:
  ```bash
  git push origin main
  ```
- Report: commit hash, files changed, push status

### 4b. Mode: `pr`

- If on main, create a new branch: `git checkout -b <auto-name-from-commit>`
- Push branch: `git push -u origin <branch>`
- Create PR:
  ```bash
  gh pr create --title "<from commit message>" --body "$(cat <<'EOF'
  ## Summary
  <bullet points from changes>

  ## Verification
  - [x] Build passed
  - [x] Tests passed

  🤖 Generated with [Claude Code](https://claude.com/claude-code)
  EOF
  )"
  ```
- Report: PR URL

### 4c. Mode: `amend`

- Stage changed files explicitly and amend:
  ```bash
  git add <changed files> && git commit --amend --no-edit
  ```
- If branch has upstream: `git push --force-with-lease`
- Report: amended commit hash

## Safety Rules

- NEVER force push to main
- NEVER commit `.env`, credentials, or secrets
- NEVER skip pre-commit hooks
- NEVER use `git add -A` or `git add .` — always stage files explicitly
- Always show the user what will be committed before committing
- For `amend` mode, warn the user if the commit has already been pushed

---

**TIP**: Use `/ship pr` for team workflows, `/ship push` for solo projects.
