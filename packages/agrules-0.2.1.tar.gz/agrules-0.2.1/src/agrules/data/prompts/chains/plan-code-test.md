---
name: "plan-code-test"
category: "chains"
description: "Plan-Code-Test chain workflow — structured 3-phase development process"
short_desc: "Plan-Code-Test chain workflow"
version: "1.0.0"
tags: ["chain", "workflow", "planning", "implementation", "testing"]
---

# Plan → Code → Test Chain

3단계 체인 워크플로우로 체계적인 개발 프로세스를 수행합니다. 각 단계는 이전 단계의 출력을 입력으로 받습니다.

## Phase 1: Plan

### Input
- 요구사항 또는 태스크 설명

### Process
1. 요구사항을 분석하고 명확하지 않은 점을 질문합니다
2. 변경이 필요한 파일과 모듈을 식별합니다
3. 구현 단계를 순서대로 나열합니다
4. 예상 리스크와 대안을 식별합니다

### Output
```markdown
## Implementation Plan
1. (단계 1: 무엇을 할 것인가)
2. (단계 2: ...)
3. ...

## Files to Change
- `path/to/file.ts` — (변경 내용)

## Risks
- (리스크 1과 대안)
```

---

## Phase 2: Code

### Input
- Phase 1의 Implementation Plan

### Process
1. Plan의 단계를 순서대로 구현합니다
2. 기존 코드 패턴과 스타일을 따릅니다
3. 각 단계 완료 후 동작을 확인합니다
4. 불필요한 변경을 피합니다

### Rules
- 한 번에 하나의 파일만 변경합니다
- 변경 전 파일의 현재 내용을 반드시 확인합니다
- Plan에 없는 변경은 하지 않습니다
- 중간 결과를 사용자에게 보고합니다

### Output
- 구현된 코드 변경사항
- 변경 요약

---

## Phase 3: Test

### Input
- Phase 2의 코드 변경사항

### Process
1. 기존 테스트를 실행하여 회귀가 없는지 확인합니다
2. 새 기능에 대한 테스트를 작성합니다
   - 정상 케이스 (happy path)
   - 비정상 케이스 (error path)
   - 엣지 케이스 (boundary values)
3. 모든 테스트가 통과하는지 확인합니다
4. 테스트 실패 시 Phase 2로 돌아가 수정합니다

### Output
```markdown
## Test Results
- ✅ (통과한 테스트)
- ❌ (실패한 테스트 — 수정 필요)

## Coverage
- (새 코드의 테스트 커버리지)
```

## Chain Completion
모든 Phase가 완료되면 최종 요약을 제공합니다:
- 구현된 기능 설명
- 변경된 파일 목록
- 테스트 결과
- 알려진 제한사항
