---
name: "bug-report-analysis"
category: "templates"
description: "Bug report analysis request template — structured format for investigating reported bugs"
short_desc: "Bug report analysis request template"
version: "1.0.0"
tags: ["template", "bug", "analysis", "debugging"]
---

# Bug Report Analysis Template

다음 버그 보고서를 분석하고 해결책을 제시해주세요.

## Input Format

```
### Bug Report
- **제목**: {{title}}
- **환경**: {{environment}}
- **재현 단계**:
  1. {{step1}}
  2. {{step2}}
  3. {{step3}}
- **예상 동작**: {{expected}}
- **실제 동작**: {{actual}}
- **에러 메시지**: {{error_message}}
- **스크린샷/로그**: {{attachments}}
```

## Analysis Steps

1. **재현 가능성 확인**: 제공된 재현 단계로 버그를 재현할 수 있는지 평가
2. **영향 범위 분석**: 이 버그가 영향을 미치는 기능/사용자 범위
3. **근본 원인 추정**: 코드 레벨에서 가능한 원인 목록
4. **수정 방안 제시**: 우선순위별 해결 방법
5. **예방 조치**: 유사 버그 재발을 막기 위한 조치

## Expected Output

```markdown
## Analysis Result
- **심각도**: Critical / Major / Minor
- **근본 원인**: (추정되는 원인)
- **관련 코드**: (파일:라인)
- **수정 방안**:
  1. (단기 해결책)
  2. (장기 해결책)
- **테스트 추가**: (회귀 테스트 시나리오)
```
