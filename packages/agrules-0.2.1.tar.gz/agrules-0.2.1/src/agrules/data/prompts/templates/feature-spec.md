---
name: "feature-spec"
category: "templates"
description: "Feature specification writing template — structured format for defining new features"
short_desc: "Feature specification writing template"
version: "1.0.0"
tags: ["template", "feature", "specification", "planning"]
---

# Feature Specification Template

새로운 기능의 스펙을 작성해주세요. 아래 구조를 따라 명확하고 구현 가능한 스펙을 만듭니다.

## Spec Structure

```markdown
# Feature: {{feature_name}}

## Overview
(기능의 목적과 가치를 1-2 문장으로 설명)

## User Story
As a {{role}},
I want to {{action}},
so that {{benefit}}.

## Acceptance Criteria
- [ ] Given {{context}}, when {{action}}, then {{result}}
- [ ] Given {{context}}, when {{action}}, then {{result}}

## Technical Design

### Data Model
(필요한 데이터 구조, 스키마 변경)

### API Changes
(새로운/변경되는 API 엔드포인트)

### UI/UX
(화면 흐름, 와이어프레임 설명)

## Edge Cases
1. (고려해야 할 엣지 케이스)

## Non-functional Requirements
- **성능**: (응답 시간, 처리량)
- **보안**: (인증, 권한, 데이터 보호)
- **접근성**: (a11y 요구사항)

## Out of Scope
- (이번 구현에 포함하지 않는 것)

## Dependencies
- (선행 작업, 외부 의존성)
```

## Guidelines
- 모호한 표현을 피합니다 ("빠르게" → "200ms 이내")
- 수용 기준은 검증 가능해야 합니다
- 하나의 스펙은 하나의 기능에 집중합니다
- 기술적 구현보다 사용자 가치를 먼저 설명합니다
