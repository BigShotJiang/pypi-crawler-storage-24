#!/usr/bin/env python3
"""
agrules — 통합 에이전트 규칙 동기화 도구

하나의 소스(agent-rules/)에서 모든 AI 코딩 도구에 맞는 형식을 생성합니다.

지원 도구:
  - Cursor IDE      → .cursor/rules/*.mdc
  - Kiro IDE/CLI    → .kiro/steering/*.md + .kiro/skills/*/SKILL.md
  - Claude Code     → CLAUDE.md + .claude/rules/*.md
  - Google Jules    → AGENTS.md
  - Windsurf        → .windsurfrules
  - Cline/Roo       → .clinerules

사용법:
  agrules <preset> [--tools ...] [--dir 경로] [--global] [--dry-run] [--clean]

예시:
  agrules fullstack                      # 전체 도구에 fullstack 프리셋
  agrules frontend --tools cursor,claude  # Cursor + Claude만
  agrules fullstack --global              # 홈 디렉토리에 글로벌 설치
  agrules fullstack --global --tools cursor # Cursor만 글로벌
  agrules all --tools kiro                # Kiro만 전체 규칙
  agrules list                            # 프리셋 목록
  agrules list-agents                     # 전체 에이전트 목록
  agrules fullstack --dry-run             # 미리보기
  agrules fullstack --clean               # 기존 삭제 후 재생성
  agrules fullstack --always-load          # Claude: 전체 항상 로드
  agrules fullstack --dir /path/to/proj   # 다른 프로젝트에 생성
"""

import os
import sys
import re
import json
import hashlib
from pathlib import Path
from datetime import datetime
from . import __version__

MANIFEST_FILENAME = ".agrules.lock"

# =============================================================================
# 설정
# =============================================================================

# 소스 디렉토리 해석 순서:
#   1. 환경변수 (AGENT_RULES_DIR 등)
#   2. 로컬 디렉토리 (CWD 기준: agent-rules/, skills/ 등)
#   3. 패키지 내부 번들 데이터 (pip install 시)

try:
    from importlib.resources import files
    _package_data = files("agrules") / "data"
except ImportError:
    import pkg_resources
    _package_data = Path(pkg_resources.resource_filename("agrules", "data"))


def _resolve_source(env_key: str, local_name: str, package_subdir: str) -> Path:
    """환경변수 → 로컬 → 패키지 순으로 소스 디렉토리 결정"""
    env_val = os.environ.get(env_key)
    if env_val:
        return Path(env_val)
    local = Path(local_name)
    if local.is_dir():
        return local
    return Path(str(_package_data / package_subdir))


RULES_DIR = _resolve_source("AGENT_RULES_DIR", "content/agent-rules", "agent-rules")
CURSOR_AGENTS_DIR = _resolve_source("CURSOR_AGENTS_DIR", "content/cursor-agents", "cursor-agents")
SKILLS_DIR = _resolve_source("SKILLS_DIR", "content/skills", "skills")
PROMPTS_DIR = _resolve_source("PROMPTS_DIR", "content/prompts", "prompts")
COMMANDS_DIR = _resolve_source("COMMANDS_DIR", "content/commands", "commands")
CODING_RULES_DIR = _resolve_source("CODING_RULES_DIR", "content/coding-rules", "coding-rules")

# =============================================================================
# frontmatter 파싱 및 디렉토리 스캔 (Single Source of Truth)
# =============================================================================

def parse_frontmatter(text):
    """YAML frontmatter → dict (간단한 regex 기반, PyYAML 불필요)"""
    m = re.match(r'^---[ \t]*\n(.*?)\n---[ \t]*\n', text, re.DOTALL)
    if not m:
        return {}
    raw = m.group(1)
    meta = {}
    for line in raw.split('\n'):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        km = re.match(r'^(\w[\w-]*)\s*:\s*(.*)', line)
        if not km:
            continue
        key, val = km.group(1), km.group(2).strip()
        # 인라인 리스트: ["a", "b", ...]
        if val.startswith('[') and val.endswith(']'):
            items = re.findall(r'"([^"]*)"', val)
            if not items:
                items = re.findall(r"'([^']*)'", val)
            meta[key] = items
            continue
        # 따옴표 제거
        if (val.startswith('"') and val.endswith('"')) or \
           (val.startswith("'") and val.endswith("'")):
            val = val[1:-1]
        # boolean
        if isinstance(val, str):
            if val.lower() == 'true':
                val = True
            elif val.lower() == 'false':
                val = False
        meta[key] = val
    return meta


def _scan_agents(rules_dir):
    """agent-rules/ 스캔 → AGENT_META 호환 dict 자동 생성"""
    defaults = {
        "cursor_globs": "", "cursor_always": False, "claude_paths": "",
        "claude_on_demand": False, "kiro_type": "skill",
        "description": "", "short_desc": "",
    }
    result = {}
    for md in sorted(Path(rules_dir).glob("*.md")):
        fm = parse_frontmatter(md.read_text(encoding="utf-8"))
        meta = dict(defaults)
        for k in defaults:
            if k in fm:
                meta[k] = fm[k]
        if not meta["short_desc"]:
            meta["short_desc"] = meta["description"]
        result[md.stem] = meta
    return result


def _scan_skills(skills_dir):
    """skills/ 스캔 → SKILL_META 호환 dict 자동 생성"""
    result = {}
    for md in sorted(Path(skills_dir).glob("*.md")):
        fm = parse_frontmatter(md.read_text(encoding="utf-8"))
        meta = {
            "description": fm.get("description", ""),
            "short_desc": fm.get("short_desc", fm.get("description", "")),
        }
        result[md.stem] = meta
    return result


def _scan_commands(commands_dir):
    """commands/ 스캔 → COMMAND_META 호환 dict 자동 생성"""
    result = {}
    for md in sorted(Path(commands_dir).glob("*.md")):
        fm = parse_frontmatter(md.read_text(encoding="utf-8"))
        meta = {
            "category": fm.get("category", "general"),
            "description": fm.get("description", ""),
            "short_desc": fm.get("short_desc", fm.get("description", "")),
        }
        result[md.stem] = meta
    return result


def _scan_prompts(prompts_dir):
    """prompts/**/ 스캔 → PROMPT_META 호환 dict 자동 생성"""
    result = {}
    for md in sorted(Path(prompts_dir).rglob("*.md")):
        fm = parse_frontmatter(md.read_text(encoding="utf-8"))
        meta = {
            "category": fm.get("category", md.parent.name),
            "description": fm.get("description", ""),
            "short_desc": fm.get("short_desc", fm.get("description", "")),
        }
        result[md.stem] = meta
    return result


# 디렉토리 스캔으로 META 자동 생성 (frontmatter = Single Source of Truth)
AGENT_META = _scan_agents(RULES_DIR)
SKILL_META = _scan_skills(SKILLS_DIR)
COMMAND_META = _scan_commands(COMMANDS_DIR)
PROMPT_META = _scan_prompts(PROMPTS_DIR)

# =============================================================================
# 프리셋
# =============================================================================

PRESETS = {
    "minimal": [
        "ai-coding-dx-agent", "reviewer-agent", "security-agent",
        "qa-agent", "performance-agent",
    ],
    "frontend": [
        "ai-coding-dx-agent", "frontend-agent", "qa-agent", "reviewer-agent",
        "security-agent", "performance-agent", "i18n-agent", "ux-reviewer-agent",
        "data-visualization-agent", "docs-agent", "dependency-manager-agent",
    ],
    "backend": [
        "ai-coding-dx-agent", "database-agent", "api-designer-agent", "qa-agent",
        "reviewer-agent", "security-agent", "performance-agent", "event-driven-agent",
        "devops-agent", "docs-agent", "search-agent", "compliance-agent",
    ],
    "fullstack": [
        "ai-coding-dx-agent", "frontend-agent", "database-agent", "api-designer-agent",
        "qa-agent", "reviewer-agent", "security-agent", "performance-agent",
        "devops-agent", "docs-agent", "event-driven-agent", "dependency-manager-agent", "i18n-agent",
    ],
    "infra": [
        "ai-coding-dx-agent", "kubernetes-agent", "eks-agent", "oke-agent",
        "devops-agent", "serverless-agent", "sre-agent", "finops-agent",
        "security-agent", "docs-agent", "monorepo-agent",
    ],
    "mobile": [
        "ai-coding-dx-agent", "mobile-agent", "qa-agent", "reviewer-agent",
        "security-agent", "performance-agent", "analytics-agent", "i18n-agent",
        "docs-agent", "dependency-manager-agent",
    ],
    "data": [
        "ai-coding-dx-agent", "data-pipeline-agent", "mlops-agent", "database-agent",
        "data-visualization-agent", "performance-agent", "devops-agent", "docs-agent",
        "security-agent", "compliance-agent",
    ],
    "gamedev": [
        "ai-coding-dx-agent", "gamedev-agent", "performance-agent", "reviewer-agent",
        "qa-agent", "docs-agent", "monorepo-agent",
    ],
    "web3": [
        "ai-coding-dx-agent", "blockchain-agent", "security-agent", "qa-agent",
        "reviewer-agent", "performance-agent", "docs-agent", "devops-agent",
    ],
}

PRESET_SKILLS = {
    "minimal": ["code-review", "coding-standards", "security-review"],
    "frontend": ["code-review", "feature-implementation", "pr-creation",
                 "coding-standards", "frontend-patterns", "e2e-testing", "tdd-workflow"],
    "backend": ["code-review", "bug-analysis", "feature-implementation", "pr-creation",
                "coding-standards", "backend-patterns", "api-design", "security-review",
                "postgres-patterns", "tdd-workflow", "database-migrations"],
    "fullstack": ["code-review", "bug-analysis", "feature-implementation", "pr-creation",
                  "refactor-safely", "coding-standards", "frontend-patterns", "backend-patterns",
                  "api-design", "security-review", "tdd-workflow", "e2e-testing",
                  "deployment-patterns", "docker-patterns", "database-migrations"],
    "infra": ["code-review", "pr-creation", "coding-standards", "docker-patterns",
              "deployment-patterns", "security-review"],
    "mobile": ["code-review", "feature-implementation", "pr-creation",
               "coding-standards", "tdd-workflow", "swift-actor-persistence", "swiftui-patterns"],
    "data": ["code-review", "bug-analysis", "pr-creation", "coding-standards",
             "python-patterns", "postgres-patterns", "database-migrations"],
    "gamedev": ["code-review", "feature-implementation", "pr-creation", "coding-standards", "tdd-workflow"],
    "web3": ["code-review", "bug-analysis", "pr-creation", "coding-standards", "security-review"],
}

PRESET_PROMPTS = {
    "minimal": ["strict-coder"],
    "frontend": ["strict-coder", "feature-spec"],
    "backend": ["strict-coder", "bug-report-analysis", "feature-spec"],
    "fullstack": ["strict-coder", "helpful-reviewer", "bug-report-analysis", "feature-spec", "plan-code-test"],
    "infra": ["strict-coder", "bug-report-analysis"],
    "mobile": ["strict-coder", "feature-spec"],
    "data": ["strict-coder", "bug-report-analysis"],
    "gamedev": ["strict-coder", "feature-spec"],
    "web3": ["strict-coder", "bug-report-analysis"],
}

PRESET_COMMANDS = {
    "minimal": ["plan", "code-review", "verify"],
    "frontend": ["plan", "code-review", "verify", "tdd", "e2e", "build-fix"],
    "backend": ["plan", "code-review", "verify", "tdd", "build-fix", "test-coverage", "security"],
    "fullstack": ["plan", "code-review", "verify", "tdd", "e2e", "build-fix",
                  "refactor-clean", "test-coverage", "update-docs", "security"],
    "infra": ["plan", "code-review", "verify", "build-fix", "security",
              "orchestrate"],
    "mobile": ["plan", "code-review", "verify", "tdd", "e2e", "build-fix"],
    "data": ["plan", "code-review", "verify", "tdd", "build-fix", "test-coverage"],
    "gamedev": ["plan", "code-review", "verify", "tdd", "build-fix"],
    "web3": ["plan", "code-review", "verify", "tdd", "build-fix", "security"],
}

# Colors
R = '\033[0;31m'
G = '\033[0;32m'
Y = '\033[1;33m'
B = '\033[0;34m'
C = '\033[0;36m'
M = '\033[0;35m'
NC = '\033[0m'

# =============================================================================
# 소스 파일 읽기
# =============================================================================

def _read_md(path: Path, label: str) -> str:
    """마크다운 파일 읽기 (frontmatter 제거). 없으면 빈 문자열."""
    if not path.exists():
        print(f"  {Y}⚠️  {label} 파일 없음: {path}{NC}", file=sys.stderr)
        return ""
    content = path.read_text(encoding="utf-8")
    match = re.match(r'^---[ \t]*\n.*?\n---[ \t]*\n(.*)', content, re.DOTALL)
    return match.group(1) if match else content


def read_source(agent_name: str) -> str:
    """전역 소스에서 에이전트 내용 읽기 (frontmatter 제거)"""
    return _read_md(RULES_DIR / f"{agent_name}.md", "소스")


def read_skill(skill_name: str) -> str:
    """스킬 소스에서 내용 읽기 (frontmatter 제거)"""
    return _read_md(SKILLS_DIR / f"{skill_name}.md", "스킬")


def read_prompt(prompt_name: str, category: str) -> str:
    """프롬프트 소스에서 내용 읽기 (frontmatter 제거)"""
    return _read_md(PROMPTS_DIR / category / f"{prompt_name}.md", "프롬프트")


def read_command(cmd_name: str) -> str:
    """커맨드 소스에서 내용 읽기 (frontmatter 제거)"""
    return _read_md(COMMANDS_DIR / f"{cmd_name}.md", "커맨드")


# =============================================================================
# 도구별 생성기
# =============================================================================

def gen_cursor(project: Path, agents: list[str], **kwargs):
    """Cursor IDE: .cursor/rules/*.mdc"""
    rules_dir = project / ".cursor" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for name in agents:
        meta = AGENT_META.get(name, {})
        body = read_source(name)
        if not body:
            continue
        mdc = f"""---
description: {meta.get('description', name)}
globs: {meta.get('cursor_globs', '')}
alwaysApply: {str(meta.get('cursor_always', False)).lower()}
---
{body}"""
        (rules_dir / f"{name}.mdc").write_text(mdc, encoding="utf-8")
        count += 1

    # Skills → .cursor/rules/skill-<name>.mdc
    for skill_name in kwargs.get("skills", []):
        meta = SKILL_META.get(skill_name, {})
        body = read_skill(skill_name)
        if not body:
            continue
        mdc = f"""---
description: "[Skill] {meta.get('description', skill_name)}"
globs:
alwaysApply: false
---
{body}"""
        (rules_dir / f"skill-{skill_name}.mdc").write_text(mdc, encoding="utf-8")
        count += 1

    # Prompts → .cursor/rules/prompt-<name>.mdc
    for prompt_name in kwargs.get("prompts", []):
        meta = PROMPT_META.get(prompt_name, {})
        category = meta.get("category", "system")
        body = read_prompt(prompt_name, category)
        if not body:
            continue
        mdc = f"""---
description: "[Prompt] {meta.get('description', prompt_name)}"
globs:
alwaysApply: false
---
{body}"""
        (rules_dir / f"prompt-{prompt_name}.mdc").write_text(mdc, encoding="utf-8")
        count += 1

    # Commands → .cursor/rules/cmd-<name>.mdc
    for cmd_name in kwargs.get("commands", []):
        meta = COMMAND_META.get(cmd_name, {})
        body = read_command(cmd_name)
        if not body:
            continue
        mdc = f"""---
description: "[Command] {meta.get('description', cmd_name)}"
globs:
alwaysApply: false
---
{body}"""
        (rules_dir / f"cmd-{cmd_name}.mdc").write_text(mdc, encoding="utf-8")
        count += 1

    return count


def deploy_cursor_agents(project: Path, agents: list[str], **kwargs):
    """Cursor Subagents: agent-rules/ + cursor-agents/ → .cursor/agents/*.md"""
    agents_dir = project / ".cursor" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    count = 0

    # 1. 에이전트 룰 → 서브에이전트 자동 변환 (프리셋 기반)
    for name in agents:
        meta = AGENT_META.get(name, {})
        body = read_source(name)
        if not body:
            continue
        subagent = f"""---
name: {name}
description: {meta.get('description', name)}
---

{body}"""
        (agents_dir / f"{name}.md").write_text(subagent, encoding="utf-8")
        count += 1

    # 2. 커스텀 서브에이전트 배포 (cursor-agents/ 소스)
    if CURSOR_AGENTS_DIR.exists():
        for src in sorted(CURSOR_AGENTS_DIR.glob("*.md")):
            dst = agents_dir / src.name
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            count += 1

    # 3. Skills → .cursor/agents/skill-<name>.md
    for skill_name in kwargs.get("skills", []):
        meta = SKILL_META.get(skill_name, {})
        body = read_skill(skill_name)
        if not body:
            continue
        subagent = f"""---
name: skill-{skill_name}
description: "[Skill] {meta.get('description', skill_name)}"
---

{body}"""
        (agents_dir / f"skill-{skill_name}.md").write_text(subagent, encoding="utf-8")
        count += 1

    return count


def gen_kiro(project: Path, agents: list[str], **kwargs):
    """Kiro IDE/CLI: .kiro/agents/*.json"""
    count = 0
    agents_dir = project / ".kiro" / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)

    for name in agents:
        meta = AGENT_META.get(name, {})
        body = read_source(name)
        if not body:
            continue

        agent_config = {
            "name": name,
            "description": meta.get("short_desc", name),
            "prompt": body,
            "tools": ["read", "write", "shell", "thinking"],
        }
        (agents_dir / f"{name}.json").write_text(
            json.dumps(agent_config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        count += 1

    # Skills → .kiro/agents/skill-<name>.json
    for skill_name in kwargs.get("skills", []):
        meta = SKILL_META.get(skill_name, {})
        body = read_skill(skill_name)
        if not body:
            continue
        skill_config = {
            "name": f"skill-{skill_name}",
            "description": f"[Skill] {meta.get('short_desc', skill_name)}",
            "prompt": body,
            "tools": ["read", "write", "shell", "thinking"],
        }
        (agents_dir / f"skill-{skill_name}.json").write_text(
            json.dumps(skill_config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        count += 1

    # Prompts → .kiro/agents/prompt-<name>.json
    for prompt_name in kwargs.get("prompts", []):
        meta = PROMPT_META.get(prompt_name, {})
        category = meta.get("category", "system")
        body = read_prompt(prompt_name, category)
        if not body:
            continue
        prompt_config = {
            "name": f"prompt-{prompt_name}",
            "description": f"[Prompt] {meta.get('short_desc', prompt_name)}",
            "prompt": body,
            "tools": ["read", "write", "shell", "thinking"],
        }
        (agents_dir / f"prompt-{prompt_name}.json").write_text(
            json.dumps(prompt_config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        count += 1

    # Commands → .kiro/agents/cmd-<name>.json
    for cmd_name in kwargs.get("commands", []):
        meta = COMMAND_META.get(cmd_name, {})
        body = read_command(cmd_name)
        if not body:
            continue
        cmd_config = {
            "name": f"cmd-{cmd_name}",
            "description": f"[Command] {meta.get('short_desc', cmd_name)}",
            "prompt": body,
            "tools": ["read", "write", "shell", "thinking"],
        }
        (agents_dir / f"cmd-{cmd_name}.json").write_text(
            json.dumps(cmd_config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        count += 1

    return count


def gen_claude(project: Path, agents: list[str], **kwargs):
    """Claude Code: CLAUDE.md + .claude/rules/agents/*.md"""
    is_global = kwargs.get("is_global", False)
    always_load = kwargs.get("always_load", False)
    rules_dir = project / ".claude" / "rules"
    agents_dir = rules_dir / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    count = 0

    # 기존 flat *-agent.md 파일 정리 (마이그레이션)
    for old_file in rules_dir.glob("*-agent.md"):
        if old_file.parent == rules_dir:
            old_file.unlink()

    on_demand_agents = []

    for name in agents:
        meta = AGENT_META.get(name, {})
        body = read_source(name)
        if not body:
            continue

        claude_paths = meta.get("claude_paths", "")
        is_on_demand = meta.get("claude_on_demand", False)

        if always_load:
            rule_content = body
        elif claude_paths:
            rule_content = f"---\npaths: {claude_paths}\n---\n{body}"
        elif is_on_demand:
            rule_content = f"---\npaths: __agent__/{name}\n---\n{body}"
            on_demand_agents.append((name, meta))
        else:
            rule_content = body

        (agents_dir / f"{name}.md").write_text(rule_content, encoding="utf-8")
        count += 1

    # Commands → .claude/commands/<name>.md (슬래시 커맨드, 우선)
    commands_list = kwargs.get("commands", [])
    cmd_names_set = set(commands_list)
    if commands_list:
        commands_dir = project / ".claude" / "commands"
        commands_dir.mkdir(parents=True, exist_ok=True)
        for cmd_name in commands_list:
            body = read_command(cmd_name)
            if not body:
                continue
            (commands_dir / f"{cmd_name}.md").write_text(body, encoding="utf-8")
            count += 1

    # Skills → .claude/commands/<name>.md (커맨드와 이름 충돌 시 skill- 접두사)
    skills_list = kwargs.get("skills", [])
    if skills_list:
        commands_dir = project / ".claude" / "commands"
        commands_dir.mkdir(parents=True, exist_ok=True)
        for skill_name in skills_list:
            body = read_skill(skill_name)
            if not body:
                continue
            fname = f"skill-{skill_name}.md" if skill_name in cmd_names_set else f"{skill_name}.md"
            (commands_dir / fname).write_text(body, encoding="utf-8")
            count += 1

    # Prompts → .claude/commands/prompt-<name>.md
    prompts_list = kwargs.get("prompts", [])
    if prompts_list:
        commands_dir = project / ".claude" / "commands"
        commands_dir.mkdir(parents=True, exist_ok=True)
        for prompt_name in prompts_list:
            meta = PROMPT_META.get(prompt_name, {})
            category = meta.get("category", "system")
            body = read_prompt(prompt_name, category)
            if not body:
                continue
            (commands_dir / f"prompt-{prompt_name}.md").write_text(body, encoding="utf-8")
            count += 1

    # CLAUDE.md: global → ~/.claude/CLAUDE.md, local → <project>/CLAUDE.md
    claude_md = (project / ".claude" / "CLAUDE.md") if is_global else (project / "CLAUDE.md")
    if not claude_md.exists():
        # Active 에이전트 (always + file-pattern)
        active_list = "\n".join(
            f"- **{n}**: {AGENT_META.get(n, {}).get('short_desc', n)}"
            for n in agents
            if not AGENT_META.get(n, {}).get("claude_on_demand", False)
        )

        # On-demand 에이전트 섹션
        on_demand_section = ""
        if on_demand_agents:
            od_list = "\n".join(
                f"- **{n}**: {m.get('short_desc', n)}"
                for n, m in on_demand_agents
            )
            on_demand_section = f"""
## On-Demand Specialist Agents
아래 에이전트는 컨텍스트 절약을 위해 자동 로딩되지 않습니다.
사용자 요청이 해당 전문 분야와 관련될 때, `.claude/rules/agents/<agent-name>.md` 파일을 읽어 지침을 따르세요.

{od_list}
"""

        claude_md_content = f"""# CLAUDE.md

## Project Rules
Detailed rules are in `.claude/rules/` directory (auto-loaded by path matching).

## Available Specialist Rules
{active_list}
{on_demand_section}
## Core Principles
1. **Plan-first** — 비자명한 작업은 계획 먼저
2. **Verify-after** — 완료 전 반드시 검증 (테스트, 빌드, 타입 체크)
3. **Existing patterns** — 기존 코드 패턴/스타일과 일관되게
4. **No magic** — any 타입 금지, 매직 넘버 금지, 명시적 코드 선호

## Commands
- Test: `npm test` / `pytest` / `go test ./...`
- Lint: `npm run lint` / `ruff check .`
- Build: `npm run build` / `go build ./...`
"""
        claude_md.write_text(claude_md_content, encoding="utf-8")

    return count


def gen_jules(project: Path, agents: list[str], **kwargs):
    """Google Jules: AGENTS.md"""
    agents_md = project / "AGENTS.md"

    sections = []
    for name in agents:
        meta = AGENT_META.get(name, {})
        body = read_source(name)
        if not body:
            continue
        sections.append(f"## {name}\n{meta.get('description', '')}\n")

    skill_sections = []
    for skill_name in kwargs.get("skills", []):
        meta = SKILL_META.get(skill_name, {})
        skill_sections.append(f"- **{skill_name}**: {meta.get('short_desc', skill_name)}")

    prompt_sections = []
    for prompt_name in kwargs.get("prompts", []):
        meta = PROMPT_META.get(prompt_name, {})
        prompt_sections.append(f"- **{prompt_name}** ({meta.get('category', '')}): {meta.get('short_desc', prompt_name)}")

    command_sections = []
    for cmd_name in kwargs.get("commands", []):
        meta = COMMAND_META.get(cmd_name, {})
        command_sections.append(f"- **/{cmd_name}** ({meta.get('category', '')}): {meta.get('short_desc', cmd_name)}")

    skills_block = ""
    if skill_sections:
        skills_block = f"""
## Skills
{chr(10).join(skill_sections)}
"""

    prompts_block = ""
    if prompt_sections:
        prompts_block = f"""
## Prompts
{chr(10).join(prompt_sections)}
"""

    commands_block = ""
    if command_sections:
        commands_block = f"""
## Commands
{chr(10).join(command_sections)}
"""

    content = f"""# AGENTS.md
> Auto-generated by agrules — {datetime.now().strftime('%Y-%m-%d')}
> This file provides AI coding agents (Jules, Kiro, etc.) with project context.

## Project Agents

{chr(10).join(sections)}
{skills_block}{prompts_block}{commands_block}
## Coding Standards
- TypeScript strict mode, no `any` types
- Functional/declarative patterns preferred
- Early return pattern
- Conventional Commits (feat:, fix:, refactor:, test:, docs:)
- All public functions require tests
- Files under 200 lines

## Available Detailed Rules
Detailed specialist rules are available in:
- `.cursor/rules/` (Cursor IDE)
- `.kiro/skills/` (Kiro IDE/CLI)
- `.claude/rules/` (Claude Code)
"""
    agents_md.write_text(content, encoding="utf-8")
    count = len(agents) + len(skill_sections) + len(prompt_sections) + len(command_sections)
    return count


def _gen_single_file(project: Path, agents: list[str], filename: str, header: str, **kwargs) -> int:
    """단일 파일에 모든 규칙을 합쳐 생성 (Windsurf, Cline 공통)"""
    parts = []
    count = 0
    for name in agents:
        meta = AGENT_META.get(name, {})
        body = read_source(name)
        if not body:
            continue
        parts.append(f"# [{name}] {meta.get('short_desc', '')}\n\n{body}")
        count += 1

    # Skills → [skill:<name>] 섹션
    for skill_name in kwargs.get("skills", []):
        meta = SKILL_META.get(skill_name, {})
        body = read_skill(skill_name)
        if not body:
            continue
        parts.append(f"# [skill:{skill_name}] {meta.get('short_desc', '')}\n\n{body}")
        count += 1

    # Prompts → [prompt:<name>] 섹션
    for prompt_name in kwargs.get("prompts", []):
        meta = PROMPT_META.get(prompt_name, {})
        category = meta.get("category", "system")
        body = read_prompt(prompt_name, category)
        if not body:
            continue
        parts.append(f"# [prompt:{prompt_name}] {meta.get('short_desc', '')}\n\n{body}")
        count += 1

    # Commands → [cmd:<name>] 섹션
    for cmd_name in kwargs.get("commands", []):
        meta = COMMAND_META.get(cmd_name, {})
        body = read_command(cmd_name)
        if not body:
            continue
        parts.append(f"# [cmd:{cmd_name}] {meta.get('short_desc', '')}\n\n{body}")
        count += 1

    if parts:
        content = f"# {header}\n# Auto-generated by agrules — {datetime.now().strftime('%Y-%m-%d')}\n\n"
        content += "\n\n---\n\n".join(parts)
        (project / filename).write_text(content, encoding="utf-8")
    return count


def gen_windsurf(project: Path, agents: list[str], **kwargs):
    """Windsurf: .windsurfrules"""
    return _gen_single_file(project, agents, ".windsurfrules", "Windsurf Rules", **kwargs)


def gen_cline(project: Path, agents: list[str], **kwargs):
    """Cline / Roo Code: .clinerules"""
    return _gen_single_file(project, agents, ".clinerules", "Cline Rules", **kwargs)


# =============================================================================
# 메인 로직
# =============================================================================

GENERATORS = {
    "cursor": ("Cursor IDE", gen_cursor),
    "kiro": ("Kiro IDE/CLI", gen_kiro),
    "claude": ("Claude Code", gen_claude),
    "jules": ("Google Jules", gen_jules),
    "windsurf": ("Windsurf", gen_windsurf),
    "cline": ("Cline/Roo", gen_cline),
}


GLOBAL_TOOLS = {"cursor", "kiro", "claude"}  # 글로벌 설치 지원 도구

# =============================================================================
# 코딩 규칙 (Coding Rules) — install-rules / list-rules
# =============================================================================

RULES_COMMON_DIR = "common"


def get_available_languages():
    """사용 가능한 언어 목록 반환 (common 제외)"""
    if not CODING_RULES_DIR.exists():
        return []
    return sorted([
        d.name for d in CODING_RULES_DIR.iterdir()
        if d.is_dir() and d.name != RULES_COMMON_DIR
    ])


def install_rules(languages, target_dir=None, dry_run=False, clean=False):
    """코딩 규칙 설치 — common + 요청 언어를 target_dir에 복사

    반환: 설치된 파일 수
    """
    import shutil

    if target_dir is None:
        target_dir = Path.home() / ".claude" / "rules" / "coding-rules"

    if not CODING_RULES_DIR.exists():
        print(f"{R}❌ 코딩 규칙 소스 디렉토리가 없습니다: {CODING_RULES_DIR}{NC}",
              file=sys.stderr)
        return 0

    # 설치 대상 수집: common + 요청 언어
    dirs_to_install = [RULES_COMMON_DIR]
    available = get_available_languages()
    for lang in languages:
        if lang in available:
            dirs_to_install.append(lang)
        else:
            print(f"  {Y}⚠️  알 수 없는 언어: {lang} (건너뜀){NC}", file=sys.stderr)

    # 파일 목록 수집
    files_to_copy = []
    for dirname in dirs_to_install:
        src_dir = CODING_RULES_DIR / dirname
        if not src_dir.exists():
            continue
        for src_file in sorted(src_dir.glob("*.md")):
            dst_file = target_dir / dirname / src_file.name
            files_to_copy.append((src_file, dst_file))

    if dry_run:
        print(f"\n  {Y}[미리보기] 설치될 코딩 규칙:{NC}\n")
        for src, dst in files_to_copy:
            print(f"    📄 {dst.relative_to(target_dir)}")
        print(f"\n  총 {len(files_to_copy)}개 파일")
        print(f"  대상: {target_dir}")
        print(f"\n  {B}실제 설치하려면 --dry-run을 제거하세요{NC}\n")
        return len(files_to_copy)

    # clean 모드: 기존 삭제
    if clean and target_dir.exists():
        for dirname in dirs_to_install:
            existing = target_dir / dirname
            if existing.exists():
                shutil.rmtree(existing)

    # 복사
    copied = 0
    for src, dst in files_to_copy:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied += 1

    return copied


def show_rules():
    """사용 가능한 코딩 규칙 목록 출력"""
    print(f"\n{C}📏 사용 가능한 코딩 규칙:{NC}\n")

    if not CODING_RULES_DIR.exists():
        print(f"  {Y}코딩 규칙 소스가 없습니다{NC}")
        return

    # common
    common_dir = CODING_RULES_DIR / RULES_COMMON_DIR
    if common_dir.exists():
        files = sorted(common_dir.glob("*.md"))
        print(f"  {G}common{NC} ({len(files)}개) — 항상 설치됨")
        for f in files:
            print(f"    • {f.stem}")

    # 언어별
    langs = get_available_languages()
    for lang in langs:
        lang_dir = CODING_RULES_DIR / lang
        files = sorted(lang_dir.glob("*.md"))
        print(f"  {G}{lang}{NC} ({len(files)}개)")
        for f in files:
            print(f"    • {f.stem}")

    print(f"\n  {B}사용법: agrules install-rules <lang...>{NC}")
    print(f"  {B}예시:   agrules install-rules typescript python{NC}\n")


def show_help():
    """사용법 출력"""
    print(f"\n{C}🔄 Agent Rules Sync{NC} {__version__} — 하나의 소스에서 모든 AI 코딩 도구 규칙을 생성\n")
    print(f"  {Y}사용법:{NC}")
    print(f"    agrules <preset> [options]\n")
    print(f"  {Y}옵션:{NC}")
    print(f"    --tools <list>   대상 도구 (쉼표 구분)  [기본: all]")
    print(f"    --dir <path>     출력 프로젝트 경로      [기본: .]")
    print(f"    --global         홈 디렉토리에 글로벌 설치 (~/.cursor, ~/.claude, ~/.kiro)")
    print(f"    --dry-run        실제 파일 생성 없이 미리보기")
    print(f"    --clean          매니페스트 기반으로 관리 파일만 삭제 후 재생성")
    print(f"    --always-load    Claude: paths 제한 없이 전체 에이전트 항상 로드")
    print(f"    --skills         스킬 파일도 함께 생성")
    print(f"    --prompts        프롬프트 파일도 함께 생성")
    print(f"    --commands       커맨드 파일도 함께 생성")
    print(f"    --all-content    에이전트 + 스킬 + 프롬프트 + 커맨드 모두 생성\n")
    print(f"  {Y}명령:{NC}")
    print(f"    list             프리셋 목록")
    print(f"    list-agents      전체 에이전트 목록")
    print(f"    list-skills      전체 스킬 목록")
    print(f"    list-prompts     전체 프롬프트 목록")
    print(f"    list-commands    전체 커맨드 목록")
    print(f"    list-rules       사용 가능한 코딩 규칙 목록")
    print(f"    install-rules    코딩 규칙 설치 (common + 언어별)")
    print(f"    status           배포 상태 확인 (매니페스트 기반)")
    print(f"    uninstall        관리 파일 전체 삭제 + 매니페스트 제거\n")
    print(f"  {Y}예시:{NC}")
    print(f"    agrules fullstack")
    print(f"    agrules fullstack --tools cursor,claude")
    print(f"    agrules fullstack --global")
    print(f"    agrules fullstack --global --tools cursor")
    print(f"    agrules fullstack --dry-run")
    print(f"    agrules fullstack --clean")
    print(f"    agrules fullstack --skills --prompts --commands")
    print(f"    agrules all --all-content")
    print(f"    agrules install-rules typescript python")
    print(f"    agrules install-rules typescript --global\n")
    print(f"  {Y}도구:{NC}  {', '.join(GENERATORS.keys())}")
    print(f"  {Y}글로벌:{NC} {', '.join(sorted(GLOBAL_TOOLS))} (--global 사용 시)")
    print(f"  {Y}소스:{NC}  content/ (agent-rules, skills, prompts, commands, coding-rules, cursor-agents)\n")


def show_presets():
    """프리셋 목록 출력 (포함 에이전트 표시)"""
    print(f"\n{C}📋 사용 가능한 프리셋:{NC}\n")
    for name, agents in PRESETS.items():
        agent_names = ", ".join(a.replace("-agent", "") for a in agents)
        print(f"  {G}{name:<12}{NC} ({len(agents)}개)")
        print(f"             {M}{agent_names}{NC}")
    print(f"\n  {B}all{NC} — 전체 {len(AGENT_META)}개 에이전트\n")


def show_agents():
    """전체 에이전트 목록 출력"""
    print(f"\n{C}📦 전체 에이전트 ({len(AGENT_META)}개):{NC}\n")

    # 카테고리별 그룹핑
    always = []
    file_pattern = []
    on_demand = []
    for name, meta in AGENT_META.items():
        if meta.get("cursor_always"):
            always.append((name, meta))
        elif meta.get("cursor_globs"):
            file_pattern.append((name, meta))
        else:
            on_demand.append((name, meta))

    if always:
        print(f"  {Y}[Always Apply]{NC}")
        for name, meta in always:
            print(f"    {G}{name:<30}{NC} {meta.get('short_desc', '')}")

    if file_pattern:
        print(f"\n  {Y}[File-pattern Based]{NC}")
        for name, meta in file_pattern:
            globs = meta.get('cursor_globs', '')
            print(f"    {G}{name:<30}{NC} {meta.get('short_desc', '')}")
            if globs:
                print(f"    {'':30} {M}→ {globs}{NC}")

    if on_demand:
        print(f"\n  {Y}[Agent Requested]{NC}")
        for name, meta in on_demand:
            print(f"    {G}{name:<30}{NC} {meta.get('short_desc', '')}")

    print()


def show_skills():
    """전체 스킬 목록 출력"""
    print(f"\n{C}🛠️  전체 스킬 ({len(SKILL_META)}개):{NC}\n")
    for name, meta in SKILL_META.items():
        print(f"  {G}{name:<30}{NC} {meta.get('short_desc', '')}")
    print(f"\n  {B}프리셋별 스킬:{NC}")
    for preset_name, skills in PRESET_SKILLS.items():
        skill_names = ", ".join(skills)
        print(f"    {M}{preset_name:<12}{NC} {skill_names}")
    print()


def show_prompts():
    """전체 프롬프트 목록 출력"""
    print(f"\n{C}📝 전체 프롬프트 ({len(PROMPT_META)}개):{NC}\n")
    categories = {}
    for name, meta in PROMPT_META.items():
        cat = meta.get("category", "system")
        categories.setdefault(cat, []).append((name, meta))

    for cat, items in categories.items():
        print(f"  {Y}[{cat}]{NC}")
        for name, meta in items:
            print(f"    {G}{name:<30}{NC} {meta.get('short_desc', '')}")
        print()

    print(f"  {B}프리셋별 프롬프트:{NC}")
    for preset_name, prompts in PRESET_PROMPTS.items():
        prompt_names = ", ".join(prompts)
        print(f"    {M}{preset_name:<12}{NC} {prompt_names}")
    print()


def show_commands():
    """전체 커맨드 목록 출력"""
    print(f"\n{C}⚡ 전체 커맨드 ({len(COMMAND_META)}개):{NC}\n")
    categories = {}
    for name, meta in COMMAND_META.items():
        cat = meta.get("category", "workflow")
        categories.setdefault(cat, []).append((name, meta))

    for cat, items in categories.items():
        print(f"  {Y}[{cat}]{NC}")
        for name, meta in items:
            print(f"    {G}/{name:<28}{NC} {meta.get('short_desc', '')}")
        print()

    print(f"  {B}프리셋별 커맨드:{NC}")
    for preset_name, cmds in PRESET_COMMANDS.items():
        cmd_names = ", ".join(cmds)
        print(f"    {M}{preset_name:<12}{NC} {cmd_names}")
    print()


TOOL_ICONS = {
    "cursor": "🟣", "kiro": "🔵", "claude": "🟠",
    "jules": "🔴", "windsurf": "🟢", "cline": "🟡",
}

TOOL_PATHS = {
    "cursor": ".cursor/rules/*.mdc + .cursor/agents/*.md",
    "kiro": ".kiro/agents/*.json",
    "claude": "CLAUDE.md + .claude/rules/*.md + .claude/commands/*.md (skills+commands+prompts)",
    "jules": "AGENTS.md",
    "windsurf": ".windsurfrules",
    "cline": ".clinerules",
}

GLOBAL_TOOL_PATHS = {
    "cursor": "~/.cursor/rules/*.mdc + ~/.cursor/agents/*.md",
    "kiro": "~/.kiro/agents/*.json",
    "claude": "~/.claude/CLAUDE.md + ~/.claude/rules/*.md",
}


# =============================================================================
# 배포 매니페스트 (Deploy Manifest)
# =============================================================================

def _file_hash(path: Path) -> str:
    """파일 내용의 SHA-256 해시 (앞 16자)"""
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def _remove_empty_parents(project: Path, file_paths: list[Path]):
    """삭제된 파일들의 부모 디렉토리 중 비어 있는 것을 bottom-up으로 정리.
    project 디렉토리 자체는 절대 삭제하지 않음."""
    dirs_to_check = set()
    project_resolved = project.resolve()
    for fp in file_paths:
        parent = fp.parent
        while parent.resolve() != project_resolved and parent != parent.parent:
            dirs_to_check.add(parent)
            parent = parent.parent
    for d in sorted(dirs_to_check, key=lambda p: len(p.parts), reverse=True):
        try:
            if d.is_dir() and not any(d.iterdir()):
                d.rmdir()
        except OSError:
            pass


def _scan_deployed_files(project: Path, tools: list[str], is_global: bool = False) -> dict:
    """배포된 파일을 스캔하여 {relative_path: {hash, tool, type}} 반환"""
    files = {}

    def _add(path: Path, tool: str, file_type: str):
        if path.is_file():
            rel = str(path.relative_to(project))
            files[rel] = {
                "hash": _file_hash(path),
                "tool": tool,
                "type": file_type,
            }

    def _scan_dir(dirpath: Path, tool: str, file_type: str):
        if dirpath.is_dir():
            for f in sorted(dirpath.rglob("*")):
                if f.is_file():
                    _add(f, tool, file_type)

    for tool_key in tools:
        if tool_key == "cursor":
            _scan_dir(project / ".cursor" / "rules", "cursor", "rule")
            _scan_dir(project / ".cursor" / "agents", "cursor", "subagent")
        elif tool_key == "kiro":
            _scan_dir(project / ".kiro" / "agents", "kiro", "agent")
        elif tool_key == "claude":
            _scan_dir(project / ".claude" / "rules" / "agents", "claude", "rule")
            _scan_dir(project / ".claude" / "commands", "claude", "command")
            claude_md = (project / ".claude" / "CLAUDE.md") if is_global else (project / "CLAUDE.md")
            _add(claude_md, "claude", "summary")
        elif tool_key == "jules":
            _add(project / "AGENTS.md", "jules", "summary")
        elif tool_key == "windsurf":
            _add(project / ".windsurfrules", "windsurf", "summary")
        elif tool_key == "cline":
            _add(project / ".clinerules", "cline", "summary")

    return files


def _manifest_path(project: Path) -> Path:
    return project / MANIFEST_FILENAME


def save_manifest(project: Path, preset: str, tools: list[str],
                   agents: list[str], skills: list[str], commands: list[str],
                   prompts: list[str], options: dict, is_global: bool = False):
    """배포 매니페스트를 .agrules.lock에 저장"""
    files = _scan_deployed_files(project, tools, is_global)
    manifest = {
        "schema_version": "1",
        "synced_at": datetime.now().isoformat(timespec="seconds"),
        "package_version": __version__,
        "preset": preset,
        "tools": tools,
        "options": options,
        "agents": sorted(agents),
        "skills": sorted(skills),
        "commands": sorted(commands),
        "prompts": sorted(prompts),
        "files": files,
    }
    path = _manifest_path(project)
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")
    return manifest


def load_manifest(project: Path) -> dict | None:
    """기존 매니페스트 로드. 없으면 None"""
    path = _manifest_path(project)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def diff_manifests(old: dict, new: dict) -> dict:
    """두 매니페스트 비교 → {added, removed, modified, unchanged} 파일 목록"""
    old_files = old.get("files", {})
    new_files = new.get("files", {})
    old_keys = set(old_files.keys())
    new_keys = set(new_files.keys())

    added = sorted(new_keys - old_keys)
    removed = sorted(old_keys - new_keys)
    modified = sorted(
        k for k in old_keys & new_keys
        if old_files[k].get("hash") != new_files[k].get("hash")
    )
    unchanged = sorted(
        k for k in old_keys & new_keys
        if old_files[k].get("hash") == new_files[k].get("hash")
    )

    # 콘텐츠 목록 비교 (agents, skills, commands, prompts)
    content_diff = {}
    for key in ("agents", "skills", "commands", "prompts"):
        old_set = set(old.get(key, []))
        new_set = set(new.get(key, []))
        if old_set != new_set:
            content_diff[key] = {
                "added": sorted(new_set - old_set),
                "removed": sorted(old_set - new_set),
            }

    return {
        "added": added,
        "removed": removed,
        "modified": modified,
        "unchanged": unchanged,
        "content_diff": content_diff,
    }


def show_deploy_status(project: Path, is_global: bool = False):
    """현재 배포 상태 출력 (status 명령)"""
    manifest = load_manifest(project)
    if not manifest:
        print(f"  {Y}⚠️  매니페스트 없음 ({MANIFEST_FILENAME}){NC}")
        print(f"  agrules를 실행하면 자동 생성됩니다.\n")
        return

    print(f"\n{C}📋 배포 상태{NC}")
    print(f"   동기화:  {manifest.get('synced_at', '?')}")
    print(f"   버전:    {manifest.get('package_version', '?')}")
    print(f"   프리셋:  {G}{manifest.get('preset', '?')}{NC}")
    print(f"   도구:    {G}{', '.join(manifest.get('tools', []))}{NC}")

    opts = manifest.get("options", {})
    flags = [k for k, v in opts.items() if v]
    if flags:
        print(f"   옵션:    {', '.join(flags)}")

    print(f"\n   에이전트: {len(manifest.get('agents', []))}개")
    if manifest.get("skills"):
        print(f"   스킬:    {len(manifest['skills'])}개")
    if manifest.get("commands"):
        print(f"   커맨드:  {len(manifest['commands'])}개")
    if manifest.get("prompts"):
        print(f"   프롬프트: {len(manifest['prompts'])}개")

    files = manifest.get("files", {})
    print(f"   파일:    {len(files)}개")

    # 현재 파일 시스템과 비교 (drift 감지)
    tools = manifest.get("tools", [])
    current_files = _scan_deployed_files(project, tools, is_global)
    current_keys = set(current_files.keys())
    manifest_keys = set(files.keys())

    missing = sorted(manifest_keys - current_keys)
    extra = sorted(current_keys - manifest_keys)
    drifted = sorted(
        k for k in manifest_keys & current_keys
        if files[k].get("hash") != current_files[k].get("hash")
    )

    if missing or extra or drifted:
        print(f"\n  {Y}⚠️  파일 시스템 drift 감지:{NC}")
        for f in missing:
            print(f"    {R}삭제됨  {f}{NC}")
        for f in extra:
            print(f"    {G}추가됨  {f}{NC}")
        for f in drifted:
            print(f"    {Y}변경됨  {f}{NC}")
    else:
        print(f"\n  {G}✅ 파일 시스템과 매니페스트 일치{NC}")

    # 패키지 최신 콘텐츠와 설치된 콘텐츠 비교
    _show_content_diff(manifest)

    print()


def _show_content_diff(manifest: dict):
    """매니페스트에 기록된 콘텐츠와 현재 패키지의 PRESET/META를 비교하여 차이 출력"""
    preset = manifest.get("preset", "")
    manifest_ver = manifest.get("package_version", "?")
    has_diff = False

    # 1. 버전 비교
    if manifest_ver != __version__:
        print(f"\n  {C}📦 패키지 업데이트 감지:{NC} {manifest_ver} → {G}{__version__}{NC}")

    # 2. 에이전트 비교
    installed_agents = set(manifest.get("agents", []))
    if preset == "all":
        available_agents = set(AGENT_META.keys())
    else:
        available_agents = set(PRESETS.get(preset, []))
    if available_agents:
        new_agents = sorted(available_agents - installed_agents)
        removed_agents = sorted(installed_agents - available_agents)
        if new_agents or removed_agents:
            has_diff = True
            print(f"\n  {C}🔄 에이전트 변경 ({preset} 프리셋):{NC}")
            for a in new_agents:
                desc = AGENT_META.get(a, {}).get("short_desc", "")
                suffix = f" — {desc}" if desc else ""
                print(f"    {G}+ {a}{suffix}{NC}")
            for a in removed_agents:
                print(f"    {R}- {a}{NC}")

    # 3. 스킬/커맨드/프롬프트 비교
    content_types = [
        ("skills", "스킬", PRESET_SKILLS, SKILL_META),
        ("commands", "커맨드", PRESET_COMMANDS, COMMAND_META),
        ("prompts", "프롬프트", PRESET_PROMPTS, PROMPT_META),
    ]

    for key, label, preset_map, meta in content_types:
        installed = set(manifest.get(key, []))
        if preset == "all":
            available = set(meta.keys())
        else:
            available = set(preset_map.get(preset, []))
        if not installed and not available:
            continue
        new_items = sorted(available - installed)
        removed_items = sorted(installed - available)
        if new_items or removed_items:
            has_diff = True
            print(f"\n  {C}🔄 {label} 변경 ({preset} 프리셋):{NC}")
            for item in new_items:
                desc = meta.get(item, {}).get("short_desc", "")
                suffix = f" — {desc}" if desc else ""
                print(f"    {G}+ {item}{suffix}{NC}")
            for item in removed_items:
                print(f"    {R}- {item}{NC}")

    # 4. 프리셋 외 추가 가능한 콘텐츠 안내 (all이 아닌 경우만)
    if preset != "all":
        all_new = []
        for key, label, preset_map, meta in content_types:
            installed = set(manifest.get(key, []))
            preset_set = set(preset_map.get(preset, []))
            extra_available = sorted(set(meta.keys()) - installed - preset_set)
            if extra_available and installed:
                all_new.append((label, extra_available, meta))

        if all_new:
            has_diff = True
            print(f"\n  {C}💡 추가 가능한 콘텐츠 (all 프리셋 또는 --all-content):{NC}")
            for label, items, meta in all_new:
                shown = items[:5]
                for item in shown:
                    desc = meta.get(item, {}).get("short_desc", "")
                    suffix = f" — {desc}" if desc else ""
                    print(f"    {M}{label}: {item}{suffix}{NC}")
                if len(items) > 5:
                    print(f"    {M}  ... 외 {len(items) - 5}개{NC}")

    if not has_diff and manifest_ver == __version__:
        print(f"\n  {G}✅ 설치된 콘텐츠가 최신 상태{NC}")


def _print_sync_diff(old_manifest: dict | None, new_manifest: dict):
    """sync 후 이전 매니페스트와의 차이 출력"""
    if not old_manifest:
        return

    diff = diff_manifests(old_manifest, new_manifest)

    # 콘텐츠 변경 (agents, skills, commands, prompts)
    for key, changes in diff.get("content_diff", {}).items():
        label = {"agents": "에이전트", "skills": "스킬",
                 "commands": "커맨드", "prompts": "프롬프트"}.get(key, key)
        if changes.get("added"):
            print(f"  {G}+ {label}: {', '.join(changes['added'])}{NC}")
        if changes.get("removed"):
            print(f"  {R}- {label}: {', '.join(changes['removed'])}{NC}")

    # 파일 변경
    if diff["added"]:
        print(f"  {G}+ {len(diff['added'])}개 파일 추가{NC}")
    if diff["removed"]:
        print(f"  {R}- {len(diff['removed'])}개 파일 제거{NC}")
    if diff["modified"]:
        print(f"  {Y}~ {len(diff['modified'])}개 파일 변경{NC}")


# =============================================================================
# 파일 정리 (Clean)
# =============================================================================

def _get_clean_targets(project: Path, tool_key: str, is_global: bool = False) -> list[Path]:
    """도구별 삭제 대상 경로 반환 (매니페스트 없을 때 레거시 폴백용)"""
    targets = {
        "cursor": [project / ".cursor" / "rules", project / ".cursor" / "agents"],
        "kiro": [project / ".kiro" / "agents"],
        "claude": [
            project / ".claude" / "rules" / "agents",
            project / ".claude" / "commands",
            (project / ".claude" / "CLAUDE.md") if is_global else (project / "CLAUDE.md"),
        ],
        "jules": [project / "AGENTS.md"],
        "windsurf": [project / ".windsurfrules"],
        "cline": [project / ".clinerules"],
    }
    return targets.get(tool_key, [])


def clean_generated(project: Path, tools: list[str], is_global: bool = False,
                    dry_run: bool = False) -> dict:
    """매니페스트 기반으로 관리 파일만 삭제. 매니페스트 없으면 레거시 디렉토리 삭제 폴백.

    Returns:
        매니페스트 모드: {"deleted": [...], "drifted": [...], "missing": [...], "fallback": False}
        폴백 모드:      {"deleted_count": int, "fallback": True}
    """
    manifest = load_manifest(project)

    if manifest is None:
        # 폴백: 매니페스트 없음 → 기존 디렉토리 삭제 방식
        import shutil
        print(f"  {Y}⚠️  매니페스트({MANIFEST_FILENAME}) 없음 — 디렉토리 단위 삭제로 폴백{NC}")
        removed = 0
        for tool_key in tools:
            for target in _get_clean_targets(project, tool_key, is_global):
                if dry_run:
                    if target.exists():
                        removed += 1
                elif target.is_dir():
                    shutil.rmtree(target)
                    removed += 1
                elif target.is_file():
                    target.unlink()
                    removed += 1
        return {"deleted_count": removed, "fallback": True}

    # 매니페스트 기반 삭제
    manifest_files = manifest.get("files", {})
    tool_set = set(tools)
    target_files = {
        rel_path: meta for rel_path, meta in manifest_files.items()
        if meta.get("tool") in tool_set
    }

    deleted = []
    drifted = []
    missing = []
    project_resolved = project.resolve()

    for rel_path in sorted(target_files):
        abs_path = (project / rel_path).resolve()
        # path traversal 방지
        if not str(abs_path).startswith(str(project_resolved)):
            continue

        if not abs_path.exists():
            missing.append(rel_path)
            continue

        # drift 감지
        current_hash = _file_hash(abs_path)
        original_hash = target_files[rel_path].get("hash", "")
        if current_hash != original_hash:
            drifted.append(rel_path)

        if not dry_run:
            abs_path.unlink()
        deleted.append(rel_path)

    # 빈 디렉토리 정리
    if not dry_run:
        _remove_empty_parents(project, [project / rp for rp in target_files])

    return {
        "deleted": deleted,
        "drifted": drifted,
        "missing": missing,
        "fallback": False,
    }


def uninstall(project: Path, is_global: bool = False, dry_run: bool = False) -> dict:
    """매니페스트의 모든 파일 + 매니페스트 자체를 삭제 (완전 제거)."""
    manifest = load_manifest(project)

    if manifest is None:
        print(f"  {Y}⚠️  매니페스트({MANIFEST_FILENAME}) 없음 — 삭제할 파일이 없습니다{NC}")
        return {"deleted": [], "missing": [], "drifted": [],
                "fallback": False, "manifest_removed": False}

    all_tools = manifest.get("tools", [])
    result = clean_generated(project, all_tools, is_global=is_global, dry_run=dry_run)

    # 매니페스트 파일 자체도 삭제
    manifest_file = _manifest_path(project)
    if manifest_file.exists() and not dry_run:
        manifest_file.unlink()
    result["manifest_removed"] = manifest_file.exists() if dry_run else True

    return result


def main():
    args = sys.argv[1:]

    # No args → show help
    if not args:
        show_help()
        sys.exit(0)

    tools_arg = "all"
    project_dir = Path(".")
    dry_run = False
    clean = False
    is_global = False
    always_load = False
    dir_specified = False
    include_skills = False
    include_prompts = False
    include_commands = False

    # Parse named flags first
    positional = []
    i = 0
    while i < len(args):
        if args[i] == "--tools" and i + 1 < len(args):
            tools_arg = args[i + 1]
            i += 2
        elif args[i] == "--dir" and i + 1 < len(args):
            project_dir = Path(args[i + 1])
            dir_specified = True
            i += 2
        elif args[i] == "--global":
            is_global = True
            project_dir = Path.home()
            i += 1
        elif args[i] == "--dry-run":
            dry_run = True
            i += 1
        elif args[i] == "--clean":
            clean = True
            i += 1
        elif args[i] == "--always-load":
            always_load = True
            i += 1
        elif args[i] == "--skills":
            include_skills = True
            i += 1
        elif args[i] == "--prompts":
            include_prompts = True
            i += 1
        elif args[i] == "--commands":
            include_commands = True
            i += 1
        elif args[i] == "--all-content":
            include_skills = True
            include_prompts = True
            include_commands = True
            i += 1
        elif args[i] in ("-h", "--help"):
            show_help()
            sys.exit(0)
        else:
            positional.append(args[i])
            i += 1

    if not positional:
        show_help()
        sys.exit(0)

    preset = positional[0]

    if preset == "list":
        show_presets()
        return
    if preset == "list-agents":
        show_agents()
        return
    if preset == "list-skills":
        show_skills()
        return
    if preset == "list-prompts":
        show_prompts()
        return
    if preset == "list-commands":
        show_commands()
        return
    if preset == "list-rules":
        show_rules()
        return
    if preset == "install-rules":
        # positional[1:] = 언어 목록
        rule_languages = positional[1:]
        if not rule_languages:
            print(f"{R}❌ 설치할 언어를 지정하세요{NC}")
            print(f"  사용 가능: {', '.join(get_available_languages())}")
            print(f"  예시: agrules install-rules typescript python")
            sys.exit(1)
        # target_dir 결정
        if is_global:
            rules_target = Path.home() / ".claude" / "rules" / "coding-rules"
        elif dir_specified:
            rules_target = project_dir / ".claude" / "rules" / "coding-rules"
        else:
            rules_target = Path.home() / ".claude" / "rules" / "coding-rules"
        count = install_rules(rule_languages, target_dir=rules_target,
                              dry_run=dry_run, clean=clean)
        if not dry_run:
            print(f"\n{G}✨ 코딩 규칙 {count}개 파일 설치 완료{NC}")
            print(f"  📂 {rules_target}\n")
        return
    if preset in ("help", "-h"):
        show_help()
        return
    if preset == "status":
        show_deploy_status(project_dir, is_global=is_global)
        return
    if preset == "uninstall":
        print(f"\n{C}🗑️  Agent Rules Uninstall{NC}")
        target_label = f"~/ (글로벌)" if is_global else str(project_dir.resolve())
        print(f"   대상: {target_label}\n")
        result = uninstall(project_dir, is_global=is_global, dry_run=dry_run)
        if result.get("fallback"):
            return
        if dry_run:
            if result.get("deleted"):
                print(f"  {Y}[미리보기] 삭제 대상 ({len(result['deleted'])}개 파일):{NC}")
                for f in result["deleted"]:
                    suffix = f" {Y}(변경됨){NC}" if f in result.get("drifted", []) else ""
                    print(f"    🗑️  {f}{suffix}")
                for f in result.get("missing", []):
                    print(f"    ⏭️  {f} (이미 없음)")
                if result.get("manifest_removed"):
                    print(f"    🗑️  {MANIFEST_FILENAME}")
                print(f"\n  {B}실제 삭제하려면 --dry-run을 제거하세요{NC}\n")
            else:
                print(f"  삭제할 파일이 없습니다.\n")
        else:
            count = len(result.get("deleted", []))
            if count:
                print(f"  🗑️  관리 파일 {count}개 삭제")
            if result.get("drifted"):
                print(f"  {Y}⚠️  변경된 파일 {len(result['drifted'])}개 포함{NC}")
            if result.get("missing"):
                print(f"  ℹ️  이미 없는 파일 {len(result['missing'])}개 건너뜀")
            if result.get("manifest_removed"):
                print(f"  🗑️  {MANIFEST_FILENAME} 삭제됨")
            print(f"\n  {G}✨ 언인스톨 완료{NC}\n")
        return

    # Resolve preset
    if preset == "all":
        agents = list(AGENT_META.keys())
    elif preset in PRESETS:
        agents = PRESETS[preset]
    else:
        print(f"{R}❌ 알 수 없는 프리셋: {preset}{NC}")
        show_presets()
        sys.exit(1)

    # Resolve skills
    skills = []
    if include_skills:
        if preset == "all":
            skills = list(SKILL_META.keys())
        else:
            skills = PRESET_SKILLS.get(preset, [])

    # Resolve prompts
    prompts = []
    if include_prompts:
        if preset == "all":
            prompts = list(PROMPT_META.keys())
        else:
            prompts = PRESET_PROMPTS.get(preset, [])

    # Resolve commands
    commands = []
    if include_commands:
        if preset == "all":
            commands = list(COMMAND_META.keys())
        else:
            commands = PRESET_COMMANDS.get(preset, [])

    # Resolve tools
    if tools_arg == "all":
        tools = list(GENERATORS.keys())
    else:
        tools = [t.strip() for t in tools_arg.split(",")]
        invalid = [t for t in tools if t not in GENERATORS]
        if invalid:
            print(f"{R}❌ 알 수 없는 도구: {', '.join(invalid)}{NC}")
            print(f"  사용 가능: {', '.join(GENERATORS.keys())}")
            sys.exit(1)

    # 인자 충돌 검증
    if is_global and dir_specified:
        print(f"{R}❌ --global과 --dir은 함께 사용할 수 없습니다{NC}")
        print(f"  --global: 홈 디렉토리에 설치 (~)")
        print(f"  --dir:    지정된 프로젝트에 설치")
        sys.exit(1)

    if dir_specified and not project_dir.exists():
        print(f"{R}❌ 지정된 디렉토리가 존재하지 않습니다: {project_dir.resolve()}{NC}")
        sys.exit(1)

    # Global mode: 지원 안 되는 도구 필터링
    if is_global:
        skipped = [t for t in tools if t not in GLOBAL_TOOLS]
        tools = [t for t in tools if t in GLOBAL_TOOLS]
        if skipped:
            print(f"  {Y}⚠️  글로벌 미지원 도구 제외: {', '.join(skipped)}{NC}")
            print(f"     (jules, windsurf, cline은 프로젝트 레벨 전용)\n")
        if not tools:
            print(f"{R}❌ 글로벌 설치 가능한 도구가 없습니다{NC}")
            print(f"  글로벌 지원: {', '.join(sorted(GLOBAL_TOOLS))}")
            sys.exit(1)

    # Check source directory
    if not RULES_DIR.exists():
        print(f"{R}❌ 소스 디렉토리가 없습니다: {RULES_DIR.resolve()}{NC}")
        print(f"\n  현재 디렉토리에 agent-rules/ 폴더가 필요합니다:")
        print(f"  mkdir -p {RULES_DIR}")
        print(f"  cp *-agent.md {RULES_DIR}/")
        sys.exit(1)

    # Header
    mode_labels = []
    if dry_run:
        mode_labels.append(f"{Y}dry-run{NC}")
    if is_global:
        mode_labels.append(f"{M}global{NC}")
    mode_str = f" ({', '.join(mode_labels)})" if mode_labels else ""
    print(f"\n{C}🔄 Agent Rules Sync{NC}{mode_str}")
    preset_info = f"{G}{preset}{NC} ({len(agents)}개 에이전트"
    if skills:
        preset_info += f", {len(skills)}개 스킬"
    if prompts:
        preset_info += f", {len(prompts)}개 프롬프트"
    if commands:
        preset_info += f", {len(commands)}개 커맨드"
    preset_info += ")"
    print(f"   프리셋:  {preset_info}")
    print(f"   도구:    {G}{', '.join(tools)}{NC}")
    target_label = f"~/ (글로벌)" if is_global else str(project_dir.resolve())
    print(f"   대상:    {target_label}")
    print(f"   소스:    {RULES_DIR.resolve()}\n")

    # Dry-run mode
    if dry_run:
        print(f"  {Y}[미리보기] 생성될 파일:{NC}\n")
        for tool_key in tools:
            icon = TOOL_ICONS.get(tool_key, "⚪")
            tool_name = GENERATORS[tool_key][0]
            path_display = GLOBAL_TOOL_PATHS.get(tool_key, TOOL_PATHS.get(tool_key, '?')) if is_global else TOOL_PATHS.get(tool_key, '?')
            print(f"  {icon} {tool_name}")
            print(f"     📂 {path_display}")
            available = [n for n in agents if read_source(n)]
            for name in available:
                print(f"        • {name}")
            if tool_key == "cursor":
                print(f"     📂 Cursor Subagents ({len(available)}개 룰 변환):")
                for name in available:
                    print(f"        • {name}")
                if CURSOR_AGENTS_DIR.exists():
                    custom_agents = sorted(CURSOR_AGENTS_DIR.glob("*.md"))
                    for sa in custom_agents:
                        print(f"        • {sa.stem} (커스텀)")
            if skills:
                print(f"     🛠️  스킬:")
                for s in skills:
                    print(f"        • {s}")
            if prompts:
                print(f"     📝 프롬프트:")
                for p in prompts:
                    print(f"        • {p}")
            if commands:
                print(f"     ⚡ 커맨드:")
                for c in commands:
                    print(f"        • /{c}")
            print()
        summary = f"  총 {len(tools)}개 도구 × {len(agents)}개 에이전트"
        if skills:
            summary += f" + {len(skills)}개 스킬"
        if prompts:
            summary += f" + {len(prompts)}개 프롬프트"
        if commands:
            summary += f" + {len(commands)}개 커맨드"
        print(summary)

        if clean:
            manifest = load_manifest(project_dir)
            if manifest:
                manifest_files = manifest.get("files", {})
                tool_set = set(tools)
                target_files = {
                    rp: meta for rp, meta in manifest_files.items()
                    if meta.get("tool") in tool_set
                }
                if target_files:
                    print(f"\n  {Y}[미리보기] --clean 삭제 대상 ({len(target_files)}개 관리 파일):{NC}")
                    for rp in sorted(target_files):
                        abs_path = project_dir / rp
                        if abs_path.exists():
                            current_hash = _file_hash(abs_path)
                            orig_hash = target_files[rp].get("hash", "")
                            drift_mark = f" {Y}(변경됨){NC}" if current_hash != orig_hash else ""
                            print(f"     🗑️  {rp}{drift_mark}")
                        else:
                            print(f"     ⏭️  {rp} (이미 없음)")
            else:
                existing = []
                for tool_key in tools:
                    for t in _get_clean_targets(project_dir, tool_key, is_global):
                        if t.exists():
                            existing.append(str(t))
                if existing:
                    print(f"\n  {Y}[미리보기] --clean 삭제 대상 (매니페스트 없음 — 디렉토리 단위):{NC}")
                    for t in existing:
                        print(f"     🗑️  {t}")

        print(f"\n  {B}실제 생성하려면 --dry-run을 제거하세요{NC}\n")
        return

    # Clean mode
    if clean:
        result = clean_generated(project_dir, tools, is_global=is_global)
        if result.get("fallback"):
            count = result.get("deleted_count", 0)
            if count:
                print(f"  🗑️  기존 파일 {count}개 삭제 (레거시 모드)\n")
        else:
            count = len(result.get("deleted", []))
            if count:
                print(f"  🗑️  관리 파일 {count}개 삭제")
            if result.get("drifted"):
                print(f"  {Y}⚠️  변경된 파일 {len(result['drifted'])}개 포함{NC}")
            if result.get("missing"):
                print(f"  ℹ️  이미 없는 파일 {len(result['missing'])}개 건너뜀")
            if count:
                print()

    # 이전 매니페스트 로드 (diff 비교용)
    old_manifest = load_manifest(project_dir)

    # Generate
    gen_config = {
        "is_global": is_global,
        "always_load": always_load,
        "skills": skills,
        "prompts": prompts,
        "commands": commands,
    }
    total = 0
    for tool_key in tools:
        tool_name, gen_fn = GENERATORS[tool_key]
        count = gen_fn(project_dir, agents, **gen_config)
        icon = TOOL_ICONS.get(tool_key, "⚪")
        print(f"  {icon} {tool_name:<15} → {G}{count}개{NC} 규칙 생성")
        total += count

        if tool_key == "cursor":
            agent_count = deploy_cursor_agents(project_dir, agents, **gen_config)
            if agent_count:
                print(f"  {icon} {'Cursor Agents':<15} → {G}{agent_count}개{NC} 서브에이전트 배포")
                total += agent_count

    # Summary
    print(f"\n{'='*50}")
    summary_msg = f"{G}✨ 동기화 완료!{NC} 총 {total}개 파일 생성"
    extras = []
    if skills:
        extras.append(f"스킬 {len(skills)}개")
    if prompts:
        extras.append(f"프롬프트 {len(prompts)}개")
    if commands:
        extras.append(f"커맨드 {len(commands)}개")
    if extras:
        summary_msg += f" ({', '.join(extras)} 포함)"
    print(f"{summary_msg}\n")

    # Show generated paths
    for t in tools:
        if is_global:
            print(f"  📂 {GLOBAL_TOOL_PATHS.get(t, TOOL_PATHS.get(t, '?'))}")
        else:
            print(f"  📂 {TOOL_PATHS.get(t, '?')}")

    if is_global:
        print(f"\n{B}💡 글로벌 규칙이 모든 프로젝트에 적용됩니다{NC}\n")
    else:
        print(f"\n{B}💡 Git에 커밋하면 팀 전체가 공유됩니다{NC}\n")

    # 매니페스트 저장
    manifest_options = {
        "always_load": always_load,
        "skills": include_skills,
        "prompts": include_prompts,
        "commands": include_commands,
    }
    new_manifest = save_manifest(
        project_dir, preset, tools, agents, skills, commands, prompts,
        manifest_options, is_global=is_global,
    )
    print(f"  📝 {MANIFEST_FILENAME} 저장됨")

    # 이전 매니페스트와 비교
    if old_manifest:
        _print_sync_diff(old_manifest, new_manifest)

    print()


if __name__ == "__main__":
    main()
