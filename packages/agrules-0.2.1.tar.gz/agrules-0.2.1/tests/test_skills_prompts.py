"""
Skills, Prompts & Commands 확장 기능 통합 테스트

격리된 tmp_path 환경에서:
1. 소스 파일 읽기 (read_skill, read_prompt, read_command)
2. 메타데이터 정합성 (SKILL_META, PROMPT_META, COMMAND_META, PRESET 매핑)
3. 도구별 생성기 (Cursor, Kiro, Claude, Jules, Windsurf, Cline)
4. CLI 플래그 (--skills, --prompts, --commands, --all-content)
5. 하위 호환성 (플래그 없으면 스킬/프롬프트/커맨드 미생성)
6. Clean 동작 (.claude/commands 포함)
7. Skill/Command 이름 충돌 처리
"""

import json
import sys
import textwrap
from pathlib import Path

import pytest


# ============================================================================
# 1. 소스 파일 읽기
# ============================================================================

class TestReadSkill:
    def test_reads_body_without_frontmatter(self, isolated_env):
        mod = isolated_env["mod"]
        body = mod.read_skill("code-review")
        assert "# Code Review Skill" in body
        assert "---" not in body  # frontmatter 제거됨
        assert "name: code-review" not in body

    def test_missing_skill_returns_empty(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        body = mod.read_skill("nonexistent-skill")
        assert body == ""
        captured = capsys.readouterr()
        assert "스킬 파일 없음" in captured.err


class TestReadPrompt:
    def test_reads_body_with_category_path(self, isolated_env):
        mod = isolated_env["mod"]
        body = mod.read_prompt("strict-coder", "system")
        assert "Strict Coder System Prompt" in body
        assert "---" not in body

    def test_reads_templates_category(self, isolated_env):
        mod = isolated_env["mod"]
        body = mod.read_prompt("feature-spec", "templates")
        assert "Feature Spec" in body

    def test_missing_prompt_returns_empty(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        body = mod.read_prompt("nope", "system")
        assert body == ""
        captured = capsys.readouterr()
        assert "프롬프트 파일 없음" in captured.err

    def test_wrong_category_returns_empty(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        body = mod.read_prompt("strict-coder", "chains")
        assert body == ""


class TestReadCommand:
    def test_reads_body_without_frontmatter(self, isolated_env):
        mod = isolated_env["mod"]
        body = mod.read_command("plan")
        assert "# Plan Command" in body
        assert "---" not in body
        assert "description:" not in body

    def test_missing_command_returns_empty(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        body = mod.read_command("nonexistent-command")
        assert body == ""
        captured = capsys.readouterr()
        assert "커맨드 파일 없음" in captured.err


# ============================================================================
# 2. 메타데이터 정합성
# ============================================================================

class TestMetaIntegrity:
    """실제(원본) 메타데이터의 필수 필드/프리셋 참조 검증"""

    def test_skill_meta_has_required_fields(self):
        from agrules.__main__ import SKILL_META
        required = {"description", "short_desc"}
        for name, meta in SKILL_META.items():
            missing = required - set(meta.keys())
            assert not missing, f"SKILL_META[{name}] 누락: {missing}"

    def test_prompt_meta_has_required_fields(self):
        from agrules.__main__ import PROMPT_META
        required = {"category", "description", "short_desc"}
        for name, meta in PROMPT_META.items():
            missing = required - set(meta.keys())
            assert not missing, f"PROMPT_META[{name}] 누락: {missing}"

    def test_preset_skills_reference_valid_skills(self):
        from agrules.__main__ import PRESET_SKILLS, SKILL_META
        for preset, skills in PRESET_SKILLS.items():
            for s in skills:
                assert s in SKILL_META, f"PRESET_SKILLS[{preset}] → '{s}' 는 SKILL_META에 없음"

    def test_preset_prompts_reference_valid_prompts(self):
        from agrules.__main__ import PRESET_PROMPTS, PROMPT_META
        for preset, prompts in PRESET_PROMPTS.items():
            for p in prompts:
                assert p in PROMPT_META, f"PRESET_PROMPTS[{preset}] → '{p}' 는 PROMPT_META에 없음"

    def test_preset_skills_keys_match_presets(self):
        from agrules.__main__ import PRESETS, PRESET_SKILLS
        assert set(PRESET_SKILLS.keys()) == set(PRESETS.keys()), \
            "PRESET_SKILLS 키가 PRESETS 키와 일치해야 합니다"

    def test_preset_prompts_keys_match_presets(self):
        from agrules.__main__ import PRESETS, PRESET_PROMPTS
        assert set(PRESET_PROMPTS.keys()) == set(PRESETS.keys()), \
            "PRESET_PROMPTS 키가 PRESETS 키와 일치해야 합니다"

    def test_prompt_categories_are_valid(self):
        from agrules.__main__ import PROMPT_META
        valid_categories = {"system", "templates", "chains"}
        for name, meta in PROMPT_META.items():
            assert meta["category"] in valid_categories, \
                f"PROMPT_META[{name}].category='{meta['category']}' 는 유효하지 않음"

    def test_command_meta_has_required_fields(self):
        from agrules.__main__ import COMMAND_META
        required = {"category", "description", "short_desc"}
        for name, meta in COMMAND_META.items():
            missing = required - set(meta.keys())
            assert not missing, f"COMMAND_META[{name}] 누락: {missing}"

    def test_preset_commands_reference_valid_commands(self):
        from agrules.__main__ import PRESET_COMMANDS, COMMAND_META
        for preset, cmds in PRESET_COMMANDS.items():
            for c in cmds:
                assert c in COMMAND_META, f"PRESET_COMMANDS[{preset}] → '{c}' 는 COMMAND_META에 없음"

    def test_preset_commands_keys_match_presets(self):
        from agrules.__main__ import PRESETS, PRESET_COMMANDS
        assert set(PRESET_COMMANDS.keys()) == set(PRESETS.keys()), \
            "PRESET_COMMANDS 키가 PRESETS 키와 일치해야 합니다"

    def test_command_categories_are_valid(self):
        from agrules.__main__ import COMMAND_META
        valid_categories = {"workflow", "testing", "docs", "multi-service",
                           "language", "session", "learning", "utility", "git"}
        for name, meta in COMMAND_META.items():
            assert meta["category"] in valid_categories, \
                f"COMMAND_META[{name}].category='{meta['category']}' 는 유효하지 않음"

    def test_no_always_loaded_agents_real(self):
        """실제 AGENT_META에서 항상-로딩 에이전트가 0개"""
        from agrules.__main__ import AGENT_META
        for name, meta in AGENT_META.items():
            has_paths = bool(meta.get("claude_paths", ""))
            is_on_demand = meta.get("claude_on_demand", False)
            assert has_paths or is_on_demand, (
                f"AGENT_META[{name}] has neither claude_paths nor claude_on_demand"
            )

    def test_ai_coding_dx_is_on_demand(self):
        """ai-coding-dx-agent에 claude_on_demand: True"""
        from agrules.__main__ import AGENT_META
        meta = AGENT_META["ai-coding-dx-agent"]
        assert meta.get("claude_on_demand") is True


# ============================================================================
# 3. 소스 파일 존재 검증 (실제 skills/, prompts/ 파일)
# ============================================================================

class TestSourceFilesExist:
    """SKILL_META / PROMPT_META 에 정의된 모든 항목의 소스 파일이 존재하는지"""

    def test_all_skill_source_files_exist(self):
        from agrules.__main__ import SKILL_META, SKILLS_DIR
        # 실제 환경에서만 (CI 등에서 SKILLS_DIR이 존재할 때)
        if not SKILLS_DIR.exists():
            pytest.skip("SKILLS_DIR not available (packaged data)")
        for name in SKILL_META:
            path = SKILLS_DIR / f"{name}.md"
            assert path.exists(), f"스킬 소스 파일 없음: {path}"

    def test_all_prompt_source_files_exist(self):
        from agrules.__main__ import PROMPT_META, PROMPTS_DIR
        if not PROMPTS_DIR.exists():
            pytest.skip("PROMPTS_DIR not available (packaged data)")
        for name, meta in PROMPT_META.items():
            path = PROMPTS_DIR / meta["category"] / f"{name}.md"
            assert path.exists(), f"프롬프트 소스 파일 없음: {path}"

    def test_all_command_source_files_exist(self):
        from agrules.__main__ import COMMAND_META, COMMANDS_DIR
        if not COMMANDS_DIR.exists():
            pytest.skip("COMMANDS_DIR not available (packaged data)")
        for name in COMMAND_META:
            path = COMMANDS_DIR / f"{name}.md"
            assert path.exists(), f"커맨드 소스 파일 없음: {path}"


# ============================================================================
# 4. 도구별 생성기 — Skills & Prompts
# ============================================================================

class TestGenCursorSkillsPrompts:
    def test_creates_skill_mdc_files(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cursor(proj, [], skills=["code-review"], prompts=[])
        assert count == 1
        skill_file = proj / ".cursor" / "rules" / "skill-code-review.mdc"
        assert skill_file.exists()
        content = skill_file.read_text()
        assert "[Skill]" in content
        assert "Code Review Skill" in content

    def test_creates_prompt_mdc_files(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cursor(proj, [], skills=[], prompts=["strict-coder"])
        assert count == 1
        prompt_file = proj / ".cursor" / "rules" / "prompt-strict-coder.mdc"
        assert prompt_file.exists()
        content = prompt_file.read_text()
        assert "[Prompt]" in content

    def test_no_skills_prompts_by_default(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cursor(proj, ["test-always-agent"])
        assert count == 1  # 에이전트만
        rules = list((proj / ".cursor" / "rules").glob("skill-*"))
        assert len(rules) == 0
        rules = list((proj / ".cursor" / "rules").glob("prompt-*"))
        assert len(rules) == 0


class TestDeployCursorAgentsSkills:
    def test_deploys_skill_subagents(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.deploy_cursor_agents(proj, [], skills=["code-review", "bug-analysis"])
        assert count >= 2  # custom agent + skills
        skill_file = proj / ".cursor" / "agents" / "skill-code-review.md"
        assert skill_file.exists()
        content = skill_file.read_text()
        assert "name: skill-code-review" in content
        assert "Code Review Skill" in content


class TestGenKiroSkillsPrompts:
    def test_creates_skill_json(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_kiro(proj, [], skills=["code-review"], prompts=[])
        assert count == 1
        skill_file = proj / ".kiro" / "agents" / "skill-code-review.json"
        assert skill_file.exists()
        data = json.loads(skill_file.read_text())
        assert data["name"] == "skill-code-review"
        assert "[Skill]" in data["description"]
        assert "Code Review Skill" in data["prompt"]

    def test_creates_prompt_json(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_kiro(proj, [], skills=[], prompts=["strict-coder"])
        assert count == 1
        prompt_file = proj / ".kiro" / "agents" / "prompt-strict-coder.json"
        assert prompt_file.exists()
        data = json.loads(prompt_file.read_text())
        assert data["name"] == "prompt-strict-coder"
        assert "[Prompt]" in data["description"]

    def test_agent_plus_skills_plus_prompts(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_kiro(
            proj,
            ["test-always-agent"],
            skills=["code-review"],
            prompts=["strict-coder"],
        )
        assert count == 3  # 1 agent + 1 skill + 1 prompt


class TestGenClaudeSkillsPrompts:
    def test_creates_skill_commands(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_claude(proj, [], skills=["code-review", "bug-analysis"], prompts=[])
        assert count == 2
        cmd_dir = proj / ".claude" / "commands"
        assert cmd_dir.exists()
        assert (cmd_dir / "code-review.md").exists()
        assert (cmd_dir / "bug-analysis.md").exists()
        content = (cmd_dir / "code-review.md").read_text()
        assert "Code Review Skill" in content
        assert "---" not in content  # frontmatter 제거됨

    def test_creates_prompt_commands(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_claude(proj, [], skills=[], prompts=["strict-coder"])
        assert count == 1
        cmd_file = proj / ".claude" / "commands" / "prompt-strict-coder.md"
        assert cmd_file.exists()
        content = cmd_file.read_text()
        assert "Strict Coder" in content

    def test_no_commands_dir_without_skills_prompts(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, ["test-always-agent"])
        assert not (proj / ".claude" / "commands").exists()


class TestGenJulesSkillsPrompts:
    def test_agents_md_contains_skills_section(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_jules(
            proj,
            ["test-always-agent"],
            skills=["code-review"],
            prompts=[],
        )
        assert count == 2  # 1 agent + 1 skill
        content = (proj / "AGENTS.md").read_text()
        assert "## Skills" in content
        assert "code-review" in content

    def test_agents_md_contains_prompts_section(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_jules(
            proj,
            ["test-always-agent"],
            skills=[],
            prompts=["strict-coder"],
        )
        assert count == 2  # 1 agent + 1 prompt
        content = (proj / "AGENTS.md").read_text()
        assert "## Prompts" in content
        assert "strict-coder" in content

    def test_no_skills_prompts_section_when_empty(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_jules(proj, ["test-always-agent"])
        content = (proj / "AGENTS.md").read_text()
        assert "## Skills" not in content
        assert "## Prompts" not in content


class TestGenWindsurfSkillsPrompts:
    def test_single_file_contains_skill_sections(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_windsurf(
            proj,
            ["test-always-agent"],
            skills=["code-review"],
            prompts=["strict-coder"],
        )
        assert count == 3
        content = (proj / ".windsurfrules").read_text()
        assert "[skill:code-review]" in content
        assert "[prompt:strict-coder]" in content
        assert "[test-always-agent]" in content


class TestGenClineSkillsPrompts:
    def test_single_file_contains_skill_sections(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cline(
            proj,
            ["test-always-agent"],
            skills=["bug-analysis"],
            prompts=["feature-spec"],
        )
        assert count == 3
        content = (proj / ".clinerules").read_text()
        assert "[skill:bug-analysis]" in content
        assert "[prompt:feature-spec]" in content


# ============================================================================
# 4b. 도구별 생성기 — Commands
# ============================================================================

class TestGenCursorCommands:
    def test_creates_cmd_mdc_files(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cursor(proj, [], commands=["plan"])
        assert count == 1
        cmd_file = proj / ".cursor" / "rules" / "cmd-plan.mdc"
        assert cmd_file.exists()
        content = cmd_file.read_text()
        assert "[Command]" in content
        assert "Plan Command" in content


class TestGenKiroCommands:
    def test_creates_cmd_json(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_kiro(proj, [], commands=["plan"])
        assert count == 1
        cmd_file = proj / ".kiro" / "agents" / "cmd-plan.json"
        assert cmd_file.exists()
        data = json.loads(cmd_file.read_text())
        assert data["name"] == "cmd-plan"
        assert "[Command]" in data["description"]
        assert "Plan Command" in data["prompt"]


class TestGenClaudeCommands:
    def test_creates_command_files(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_claude(proj, [], commands=["plan", "code-review"])
        assert count == 2
        cmd_dir = proj / ".claude" / "commands"
        assert (cmd_dir / "plan.md").exists()
        assert (cmd_dir / "code-review.md").exists()
        content = (cmd_dir / "plan.md").read_text()
        assert "Plan Command" in content
        assert "---" not in content  # frontmatter 제거됨

    def test_skill_command_collision_prefixes_skill(self, isolated_env):
        """code-review가 command와 skill 양쪽에 있을 때, skill에 prefix 추가"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_claude(
            proj, [],
            commands=["code-review"],
            skills=["code-review"],
        )
        assert count == 2
        cmd_dir = proj / ".claude" / "commands"
        # command: code-review.md (우선)
        assert (cmd_dir / "code-review.md").exists()
        cmd_content = (cmd_dir / "code-review.md").read_text()
        assert "Code Review Command" in cmd_content
        # skill: skill-code-review.md (prefix 붙음)
        assert (cmd_dir / "skill-code-review.md").exists()
        skill_content = (cmd_dir / "skill-code-review.md").read_text()
        assert "Code Review Skill" in skill_content

    def test_no_collision_when_no_commands(self, isolated_env):
        """commands가 없으면 skill은 원래 이름 유지"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, [], skills=["code-review"])
        cmd_dir = proj / ".claude" / "commands"
        assert (cmd_dir / "code-review.md").exists()
        assert not (cmd_dir / "skill-code-review.md").exists()


class TestGenJulesCommands:
    def test_agents_md_contains_commands_section(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_jules(
            proj, ["test-always-agent"], commands=["plan"],
        )
        assert count == 2  # 1 agent + 1 command
        content = (proj / "AGENTS.md").read_text()
        assert "## Commands" in content
        assert "/plan" in content


class TestGenWindsurfCommands:
    def test_single_file_contains_cmd_sections(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_windsurf(proj, ["test-always-agent"], commands=["plan"])
        assert count == 2
        content = (proj / ".windsurfrules").read_text()
        assert "[cmd:plan]" in content


class TestGenClineCommands:
    def test_single_file_contains_cmd_sections(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cline(proj, ["test-always-agent"], commands=["plan"])
        assert count == 2
        content = (proj / ".clinerules").read_text()
        assert "[cmd:plan]" in content


# ============================================================================
# 5. 하위 호환성 — 플래그 없으면 스킬/프롬프트 미생성
# ============================================================================

class TestBackwardCompatibility:
    """--skills / --prompts 없이 실행하면 기존과 동일하게 에이전트만 생성"""

    def test_cursor_no_skills_prompts_commands(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_cursor(proj, ["test-always-agent", "test-pattern-agent"])
        rules = list((proj / ".cursor" / "rules").iterdir())
        # 에이전트 .mdc 만 존재
        for f in rules:
            assert not f.name.startswith("skill-")
            assert not f.name.startswith("prompt-")
            assert not f.name.startswith("cmd-")

    def test_kiro_no_skills_prompts_commands(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_kiro(proj, ["test-always-agent"])
        agents = list((proj / ".kiro" / "agents").iterdir())
        for f in agents:
            assert not f.name.startswith("skill-")
            assert not f.name.startswith("prompt-")
            assert not f.name.startswith("cmd-")

    def test_claude_no_commands_dir(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, ["test-always-agent"])
        assert not (proj / ".claude" / "commands").exists()

    def test_jules_no_extra_sections(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_jules(proj, ["test-always-agent"])
        content = (proj / "AGENTS.md").read_text()
        assert "## Skills" not in content
        assert "## Prompts" not in content
        assert "## Commands" not in content

    def test_windsurf_no_skill_prompt_cmd_tags(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_windsurf(proj, ["test-always-agent"])
        content = (proj / ".windsurfrules").read_text()
        assert "[skill:" not in content
        assert "[prompt:" not in content
        assert "[cmd:" not in content


# ============================================================================
# 6. Clean 동작 — .claude/commands 포함
# ============================================================================

class TestCleanTargets:
    def test_claude_clean_includes_commands(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        targets = mod._get_clean_targets(proj, "claude")
        target_strs = [str(t) for t in targets]
        assert any("commands" in s for s in target_strs)

    def test_clean_removes_commands_dir(self, isolated_env):
        """매니페스트 없으면 폴백 모드로 디렉토리 삭제"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        # 먼저 생성
        mod.gen_claude(proj, ["test-always-agent"], skills=["code-review"], prompts=["strict-coder"])
        assert (proj / ".claude" / "commands").exists()
        # clean (매니페스트 없음 → 폴백)
        result = mod.clean_generated(proj, ["claude"])
        assert result["fallback"] is True
        assert result["deleted_count"] >= 1
        assert not (proj / ".claude" / "commands").exists()

    def test_clean_removes_cursor_dirs(self, isolated_env):
        """매니페스트 없으면 폴백 모드로 디렉토리 삭제"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_cursor(proj, ["test-always-agent"], skills=["code-review"])
        mod.deploy_cursor_agents(proj, ["test-always-agent"], skills=["code-review"])
        assert (proj / ".cursor" / "rules").exists()
        assert (proj / ".cursor" / "agents").exists()
        result = mod.clean_generated(proj, ["cursor"])
        assert result["fallback"] is True
        assert result["deleted_count"] >= 2
        assert not (proj / ".cursor" / "rules").exists()
        assert not (proj / ".cursor" / "agents").exists()


class TestManifestBasedClean:
    """매니페스트 기반 clean 동작 검증"""

    def _generate_and_save_manifest(self, mod, proj, agents, tools, **kwargs):
        """생성 + 매니페스트 저장 헬퍼"""
        skills = kwargs.get("skills", [])
        commands = kwargs.get("commands", [])
        prompts = kwargs.get("prompts", [])
        for tool_key in tools:
            if tool_key == "claude":
                mod.gen_claude(proj, agents, skills=skills, commands=commands, prompts=prompts)
            elif tool_key == "cursor":
                mod.gen_cursor(proj, agents, skills=skills)
                mod.deploy_cursor_agents(proj, agents, skills=skills)
        mod.save_manifest(proj, "fullstack", tools, agents, skills, commands, prompts, {})

    def test_clean_only_deletes_manifest_files(self, isolated_env):
        """매니페스트에 없는 사용자 파일은 삭제하지 않음"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
            skills=["code-review"], prompts=["strict-coder"],
        )
        # 사용자 파일 추가
        user_file = proj / ".claude" / "commands" / "my-custom-command.md"
        user_file.write_text("# My custom command")
        user_rule = proj / ".claude" / "rules" / "agents" / "my-custom-rule.md"
        user_rule.write_text("# My custom rule")

        result = mod.clean_generated(proj, ["claude"])
        assert result["fallback"] is False
        assert len(result["deleted"]) >= 1
        # 사용자 파일 보존
        assert user_file.exists()
        assert user_rule.exists()

    def test_clean_detects_drifted_files(self, isolated_env):
        """변경된 파일 감지 후 삭제"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
            skills=["code-review"],
        )
        # 관리 파일 수정 (drift)
        managed_file = proj / ".claude" / "rules" / "agents" / "test-always-agent.md"
        assert managed_file.exists()
        managed_file.write_text("# Modified by user")

        result = mod.clean_generated(proj, ["claude"])
        assert result["fallback"] is False
        assert any("test-always-agent" in f for f in result["drifted"])
        # 변경되었더라도 삭제됨
        assert not managed_file.exists()

    def test_clean_empty_dirs_removed(self, isolated_env):
        """파일 삭제 후 빈 디렉토리 정리"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
        )
        agents_dir = proj / ".claude" / "rules" / "agents"
        assert agents_dir.exists()

        result = mod.clean_generated(proj, ["claude"])
        assert result["fallback"] is False
        # 모든 파일 삭제 후 빈 디렉토리도 정리됨
        assert not agents_dir.exists()

    def test_clean_partial_tools(self, isolated_env):
        """특정 도구만 clean하면 다른 도구 파일 보존"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude", "cursor"],
            skills=["code-review"],
        )
        assert (proj / ".cursor" / "rules").exists()
        assert (proj / ".claude" / "rules" / "agents").exists()

        # claude만 clean
        result = mod.clean_generated(proj, ["claude"])
        assert result["fallback"] is False
        # cursor 파일 보존
        assert (proj / ".cursor" / "rules").exists()

    def test_clean_missing_files_skipped(self, isolated_env):
        """이미 없는 파일은 건너뜀"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
        )
        # 수동으로 파일 삭제
        managed_file = proj / ".claude" / "rules" / "agents" / "test-always-agent.md"
        managed_file.unlink()

        result = mod.clean_generated(proj, ["claude"])
        assert result["fallback"] is False
        assert len(result["missing"]) >= 1

    def test_clean_dry_run(self, isolated_env):
        """dry_run 시 파일 미삭제"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
        )
        managed_file = proj / ".claude" / "rules" / "agents" / "test-always-agent.md"
        assert managed_file.exists()

        result = mod.clean_generated(proj, ["claude"], dry_run=True)
        assert result["fallback"] is False
        assert len(result["deleted"]) >= 1
        # 파일은 여전히 존재
        assert managed_file.exists()


class TestUninstall:
    """uninstall 커맨드 검증"""

    def _generate_and_save_manifest(self, mod, proj, agents, tools, **kwargs):
        skills = kwargs.get("skills", [])
        commands = kwargs.get("commands", [])
        prompts = kwargs.get("prompts", [])
        for tool_key in tools:
            if tool_key == "claude":
                mod.gen_claude(proj, agents, skills=skills, commands=commands, prompts=prompts)
            elif tool_key == "cursor":
                mod.gen_cursor(proj, agents, skills=skills)
                mod.deploy_cursor_agents(proj, agents, skills=skills)
        mod.save_manifest(proj, "fullstack", tools, agents, skills, commands, prompts, {})

    def test_uninstall_removes_all_and_manifest(self, isolated_env):
        """uninstall은 모든 관리 파일 + 매니페스트 삭제"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
            skills=["code-review"],
        )
        lock_file = proj / ".agrules.lock"
        assert lock_file.exists()

        result = mod.uninstall(proj)
        assert result["fallback"] is False
        assert len(result["deleted"]) >= 1
        assert result["manifest_removed"] is True
        assert not lock_file.exists()

    def test_uninstall_dry_run(self, isolated_env):
        """uninstall --dry-run은 파일 미삭제"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._generate_and_save_manifest(
            mod, proj, ["test-always-agent"], ["claude"],
        )
        lock_file = proj / ".agrules.lock"
        managed_file = proj / ".claude" / "rules" / "agents" / "test-always-agent.md"

        result = mod.uninstall(proj, dry_run=True)
        assert len(result["deleted"]) >= 1
        # 파일은 여전히 존재
        assert managed_file.exists()
        assert lock_file.exists()

    def test_uninstall_no_manifest(self, isolated_env):
        """매니페스트 없으면 경고만 출력"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        result = mod.uninstall(proj)
        assert result["deleted"] == []
        assert result["manifest_removed"] is False


# ============================================================================
# 7. CLI 통합 — main() 호출 시 플래그 파싱 및 파일 생성
# ============================================================================

class TestCLIIntegration:
    """sys.argv를 monkeypatch 하여 main() 호출"""

    def _run_main(self, monkeypatch, mod, argv):
        monkeypatch.setattr(sys, "argv", ["agrules"] + argv)
        mod.main()

    def test_skills_flag_generates_skill_files(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "fullstack", "--skills", "--tools", "claude",
            "--dir", str(proj),
        ])
        cmd_dir = proj / ".claude" / "commands"
        assert cmd_dir.exists()
        skill_files = [f for f in cmd_dir.iterdir() if not f.name.startswith("prompt-")]
        assert len(skill_files) == 3  # code-review, bug-analysis, tdd-workflow

    def test_prompts_flag_generates_prompt_files(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "fullstack", "--prompts", "--tools", "kiro",
            "--dir", str(proj),
        ])
        agents_dir = proj / ".kiro" / "agents"
        prompt_files = sorted(agents_dir.glob("prompt-*.json"))
        assert len(prompt_files) == 2  # strict-coder, feature-spec

    def test_all_content_flag(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "fullstack", "--all-content", "--tools", "claude",
            "--dir", str(proj),
        ])
        cmd_dir = proj / ".claude" / "commands"
        all_files = list(cmd_dir.iterdir())
        # commands: plan.md, code-review.md, security.md (3개)
        # skills: skill-code-review.md (충돌→prefix), bug-analysis.md, tdd-workflow.md (3개)
        # prompts: prompt-strict-coder.md, prompt-feature-spec.md (2개)
        cmd_files = [f for f in all_files if not f.name.startswith(("prompt-", "skill-"))]
        skill_files = [f for f in all_files if f.name.startswith("skill-")]
        prompt_files = [f for f in all_files if f.name.startswith("prompt-")]
        non_prefixed_skills = [f for f in all_files
                               if f.name in ("bug-analysis.md", "tdd-workflow.md")]
        assert len(cmd_files) == 3 + len(non_prefixed_skills)  # plan + code-review + security + non-prefixed skills
        assert len(skill_files) == 1  # skill-code-review (충돌 prefix)
        assert len(prompt_files) == 2

    def test_no_flags_no_skills_prompts(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "fullstack", "--tools", "claude",
            "--dir", str(proj),
        ])
        assert not (proj / ".claude" / "commands").exists()

    def test_list_skills_command(self, isolated_env, monkeypatch, capsys):
        mod = isolated_env["mod"]
        self._run_main(monkeypatch, mod, ["list-skills"])
        out = capsys.readouterr().out
        assert "code-review" in out
        assert "bug-analysis" in out

    def test_list_prompts_command(self, isolated_env, monkeypatch, capsys):
        mod = isolated_env["mod"]
        self._run_main(monkeypatch, mod, ["list-prompts"])
        out = capsys.readouterr().out
        assert "strict-coder" in out
        assert "feature-spec" in out

    def test_commands_flag_generates_command_files(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "fullstack", "--commands", "--tools", "claude",
            "--dir", str(proj),
        ])
        cmd_dir = proj / ".claude" / "commands"
        assert cmd_dir.exists()
        assert (cmd_dir / "plan.md").exists()
        assert (cmd_dir / "code-review.md").exists()

    def test_list_commands_command(self, isolated_env, monkeypatch, capsys):
        mod = isolated_env["mod"]
        self._run_main(monkeypatch, mod, ["list-commands"])
        out = capsys.readouterr().out
        assert "/plan" in out
        assert "/code-review" in out

    def test_preset_all_with_skills(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "all", "--skills", "--tools", "kiro",
            "--dir", str(proj),
        ])
        agents_dir = proj / ".kiro" / "agents"
        skill_files = sorted(agents_dir.glob("skill-*.json"))
        # 'all' preset → 모든 SKILL_META 키 (3개)
        assert len(skill_files) == 3

    def test_preset_all_with_prompts(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "all", "--prompts", "--tools", "kiro",
            "--dir", str(proj),
        ])
        agents_dir = proj / ".kiro" / "agents"
        prompt_files = sorted(agents_dir.glob("prompt-*.json"))
        assert len(prompt_files) == 2

    def test_dry_run_shows_skills_prompts(self, isolated_env, monkeypatch, capsys):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        self._run_main(monkeypatch, mod, [
            "fullstack", "--skills", "--prompts",
            "--tools", "cursor", "--dry-run",
            "--dir", str(proj),
        ])
        out = capsys.readouterr().out
        assert "스킬" in out
        assert "프롬프트" in out
        # dry-run 이므로 파일 미생성
        assert not (proj / ".cursor" / "rules").exists()

    def test_clean_then_regenerate(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        # 1차 생성
        self._run_main(monkeypatch, mod, [
            "fullstack", "--skills", "--prompts", "--tools", "claude",
            "--dir", str(proj),
        ])
        assert (proj / ".claude" / "commands").exists()

        # clean + 재생성 (스킬/프롬프트 없이)
        self._run_main(monkeypatch, mod, [
            "fullstack", "--tools", "claude", "--clean",
            "--dir", str(proj),
        ])
        # commands 디렉토리가 clean 에 의해 삭제됨
        assert not (proj / ".claude" / "commands").exists()


# ============================================================================
# 8. 전체 도구 동시 생성 (E2E)
# ============================================================================

class TestEndToEnd:
    def test_all_tools_with_all_content(self, isolated_env, monkeypatch):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        sys_argv = [
            "agrules",
            "fullstack", "--all-content",
            "--dir", str(proj),
        ]
        monkeypatch.setattr(sys, "argv", sys_argv)
        mod.main()

        # Cursor
        assert (proj / ".cursor" / "rules" / "skill-code-review.mdc").exists()
        assert (proj / ".cursor" / "rules" / "prompt-strict-coder.mdc").exists()
        assert (proj / ".cursor" / "rules" / "cmd-plan.mdc").exists()
        assert (proj / ".cursor" / "rules" / "cmd-code-review.mdc").exists()
        assert (proj / ".cursor" / "agents" / "skill-code-review.md").exists()

        # Kiro
        assert (proj / ".kiro" / "agents" / "skill-code-review.json").exists()
        assert (proj / ".kiro" / "agents" / "prompt-strict-coder.json").exists()
        assert (proj / ".kiro" / "agents" / "cmd-plan.json").exists()

        # Claude — code-review.md is command (priority), skill gets prefix
        assert (proj / ".claude" / "commands" / "plan.md").exists()
        assert (proj / ".claude" / "commands" / "code-review.md").exists()
        cmd_content = (proj / ".claude" / "commands" / "code-review.md").read_text()
        assert "Code Review Command" in cmd_content
        assert (proj / ".claude" / "commands" / "skill-code-review.md").exists()
        assert (proj / ".claude" / "commands" / "prompt-strict-coder.md").exists()

        # Jules
        agents_md = (proj / "AGENTS.md").read_text()
        assert "## Skills" in agents_md
        assert "## Prompts" in agents_md
        assert "## Commands" in agents_md
        assert "/plan" in agents_md

        # Windsurf
        ws = (proj / ".windsurfrules").read_text()
        assert "[skill:code-review]" in ws
        assert "[prompt:strict-coder]" in ws
        assert "[cmd:plan]" in ws

        # Cline
        cl = (proj / ".clinerules").read_text()
        assert "[skill:code-review]" in cl
        assert "[prompt:strict-coder]" in cl
        assert "[cmd:plan]" in cl

    def test_all_tools_without_flags_no_skills_prompts(self, isolated_env, monkeypatch):
        """하위 호환 E2E: 플래그 없이 모든 도구 생성"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        monkeypatch.setattr(sys, "argv", [
            "agrules", "fullstack", "--dir", str(proj),
        ])
        mod.main()

        # 에이전트 파일은 존재
        assert (proj / ".cursor" / "rules" / "test-always-agent.mdc").exists()
        assert (proj / ".kiro" / "agents" / "test-always-agent.json").exists()
        assert (proj / ".claude" / "rules" / "agents" / "test-always-agent.md").exists()

        # 스킬/프롬프트 파일은 부재
        assert not (proj / ".claude" / "commands").exists()
        cursor_rules = list((proj / ".cursor" / "rules").iterdir())
        assert all(not f.name.startswith("skill-") for f in cursor_rules)
        assert all(not f.name.startswith("prompt-") for f in cursor_rules)

        ws = (proj / ".windsurfrules").read_text()
        assert "[skill:" not in ws
        assert "[prompt:" not in ws
        assert "[cmd:" not in ws


# ============================================================================
# 9. 생성 파일 내용 상세 검증
# ============================================================================

class TestGeneratedContent:
    """생성된 파일의 내부 구조가 각 도구 형식에 맞는지 검증"""

    def test_cursor_skill_mdc_format(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_cursor(proj, [], skills=["code-review"])
        content = (proj / ".cursor" / "rules" / "skill-code-review.mdc").read_text()
        # MDC frontmatter 구조 검증
        assert content.startswith("---\n")
        assert "description:" in content
        assert "alwaysApply: false" in content

    def test_kiro_skill_json_structure(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_kiro(proj, [], skills=["code-review"])
        data = json.loads(
            (proj / ".kiro" / "agents" / "skill-code-review.json").read_text()
        )
        assert set(data.keys()) == {"name", "description", "prompt", "tools"}
        assert isinstance(data["tools"], list)
        assert "read" in data["tools"]

    def test_kiro_prompt_json_structure(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_kiro(proj, [], prompts=["strict-coder"])
        data = json.loads(
            (proj / ".kiro" / "agents" / "prompt-strict-coder.json").read_text()
        )
        assert data["name"] == "prompt-strict-coder"
        assert "Strict Coder" in data["prompt"]

    def test_claude_skill_no_frontmatter(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, [], skills=["code-review"])
        content = (proj / ".claude" / "commands" / "code-review.md").read_text()
        # 순수 본문만 (frontmatter 없음)
        assert not content.startswith("---")
        assert "Code Review Skill" in content

    def test_windsurf_section_headers(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_windsurf(proj, [], skills=["code-review"], prompts=["strict-coder"])
        content = (proj / ".windsurfrules").read_text()
        # 헤더 라인과 구분선 검증
        assert "# [skill:code-review] Code review procedure" in content
        assert "# [prompt:strict-coder] Strict coding standards" in content
        assert "---" in content  # 섹션 구분선


# ============================================================================
# 10. 엣지 케이스
# ============================================================================

class TestEdgeCases:
    def test_empty_skills_list(self, isolated_env):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cursor(proj, ["test-always-agent"], skills=[], prompts=[])
        assert count == 1  # 에이전트만

    def test_nonexistent_skill_skipped(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_kiro(proj, [], skills=["nonexistent"])
        assert count == 0

    def test_nonexistent_prompt_skipped(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_claude(proj, [], prompts=["nonexistent"])
        assert count == 0  # PROMPT_META에 없어도 에러 아님

    def test_nonexistent_command_skipped(self, isolated_env, capsys):
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        count = mod.gen_cursor(proj, [], commands=["nonexistent"])
        assert count == 0

    def test_multiple_generators_independent(self, isolated_env):
        """각 제너레이터가 서로 간섭하지 않음"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_cursor(proj, ["test-always-agent"], skills=["code-review"])
        mod.gen_claude(proj, ["test-always-agent"], skills=["code-review"])
        # 각각 독립적으로 올바른 경로에 생성
        assert (proj / ".cursor" / "rules" / "skill-code-review.mdc").exists()
        assert (proj / ".claude" / "commands" / "code-review.md").exists()
        # 서로의 디렉토리에 침범하지 않음
        assert not (proj / ".cursor" / "commands").exists()
        assert not (proj / ".claude" / "rules" / "agents" / "skill-code-review.mdc").exists()


# ============================================================================
# 11. Claude On-Demand 에이전트 + agents/ 서브디렉토리
# ============================================================================

class TestClaudeOnDemandAgents:
    """agents/ 서브디렉토리, on-demand sentinel paths, CLAUDE.md 분리 검증"""

    def test_agents_in_subdirectory(self, isolated_env):
        """에이전트가 rules/agents/ 서브디렉토리에 생성됨"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, ["test-always-agent", "test-pattern-agent", "test-on-demand-agent"])
        agents_dir = proj / ".claude" / "rules" / "agents"
        assert agents_dir.exists()
        assert (agents_dir / "test-always-agent.md").exists()
        assert (agents_dir / "test-pattern-agent.md").exists()
        assert (agents_dir / "test-on-demand-agent.md").exists()

    def test_on_demand_gets_sentinel_paths(self, isolated_env):
        """on-demand 에이전트에 sentinel paths frontmatter 부여"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, ["test-on-demand-agent"])
        content = (proj / ".claude" / "rules" / "agents" / "test-on-demand-agent.md").read_text()
        assert content.startswith("---\n")
        assert "paths: __agent__/test-on-demand-agent" in content

    def test_all_agents_get_frontmatter(self, isolated_env):
        """모든 에이전트에 frontmatter 있음 (항상-로딩 에이전트 0개)"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, ["test-always-agent", "test-pattern-agent", "test-on-demand-agent"])
        agents_dir = proj / ".claude" / "rules" / "agents"
        for name in ["test-always-agent", "test-pattern-agent", "test-on-demand-agent"]:
            content = (agents_dir / f"{name}.md").read_text()
            assert content.startswith("---"), f"{name} should have frontmatter"

    def test_no_always_loaded_agents(self, isolated_env):
        """항상-로딩 에이전트가 0개임을 검증"""
        mod = isolated_env["mod"]
        for name, meta in mod.AGENT_META.items():
            has_paths = bool(meta.get("claude_paths", ""))
            is_on_demand = meta.get("claude_on_demand", False)
            assert has_paths or is_on_demand, (
                f"{name} has neither claude_paths nor claude_on_demand — would be always-loaded"
            )

    def test_pattern_agent_has_real_paths(self, isolated_env):
        """pattern 에이전트는 실제 glob paths 유지"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(proj, ["test-pattern-agent"])
        content = (proj / ".claude" / "rules" / "agents" / "test-pattern-agent.md").read_text()
        assert content.startswith("---\n")
        assert "paths: **/*.test.ts" in content
        assert "__agent__" not in content

    def test_always_load_flag_overrides(self, isolated_env):
        """--always-load 시 모든 에이전트에 frontmatter 없음"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(
            proj,
            ["test-always-agent", "test-pattern-agent", "test-on-demand-agent"],
            always_load=True,
        )
        agents_dir = proj / ".claude" / "rules" / "agents"
        for name in ["test-always-agent", "test-pattern-agent", "test-on-demand-agent"]:
            content = (agents_dir / f"{name}.md").read_text()
            assert not content.startswith("---"), f"{name} should have no frontmatter with always_load"

    def test_claude_md_separates_on_demand(self, isolated_env):
        """CLAUDE.md에 on-demand 에이전트 섹션이 분리됨"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        mod.gen_claude(
            proj,
            ["test-always-agent", "test-pattern-agent", "test-on-demand-agent"],
        )
        claude_md = (proj / "CLAUDE.md").read_text()
        # Pattern 에이전트는 Active 목록에 포함
        assert "test-pattern-agent" in claude_md
        # On-demand 섹션 존재 (test-always-agent, test-on-demand-agent 둘 다 on-demand)
        assert "On-Demand Specialist Agents" in claude_md
        assert "test-on-demand-agent" in claude_md
        assert "test-always-agent" in claude_md
        # On-demand 에이전트가 Active 목록에는 없음
        lines = claude_md.split("\n")
        active_section_lines = []
        in_active = False
        for line in lines:
            if "Available Specialist Rules" in line:
                in_active = True
                continue
            if in_active and line.startswith("## "):
                break
            if in_active:
                active_section_lines.append(line)
        active_text = "\n".join(active_section_lines)
        assert "test-on-demand-agent" not in active_text
        assert "test-always-agent" not in active_text

    def test_old_flat_files_migrated(self, isolated_env):
        """기존 flat *-agent.md 파일이 마이그레이션됨 (삭제)"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        rules_dir = proj / ".claude" / "rules"
        rules_dir.mkdir(parents=True, exist_ok=True)
        # 기존 flat 파일 생성
        (rules_dir / "test-always-agent.md").write_text("old content")
        (rules_dir / "test-pattern-agent.md").write_text("old content")
        # gen_claude 실행
        mod.gen_claude(proj, ["test-always-agent", "test-pattern-agent"])
        # flat 파일 삭제됨
        assert not (rules_dir / "test-always-agent.md").exists()
        assert not (rules_dir / "test-pattern-agent.md").exists()
        # agents/ 서브디렉토리에 새로 생성됨
        assert (rules_dir / "agents" / "test-always-agent.md").exists()
        assert (rules_dir / "agents" / "test-pattern-agent.md").exists()

    def test_clean_preserves_coding_rules(self, isolated_env):
        """clean 시 coding-rules 디렉토리 보존"""
        mod = isolated_env["mod"]
        proj = isolated_env["project_dir"]
        # agents 생성
        mod.gen_claude(proj, ["test-always-agent"])
        # coding-rules 수동 생성 (install_rules가 설치하는 위치)
        coding_rules = proj / ".claude" / "rules" / "coding-rules"
        coding_rules.mkdir(parents=True, exist_ok=True)
        (coding_rules / "common" / "style.md").parent.mkdir(parents=True, exist_ok=True)
        (coding_rules / "common" / "style.md").write_text("# Style rules")
        # clean
        mod.clean_generated(proj, ["claude"])
        # agents/ 삭제됨
        assert not (proj / ".claude" / "rules" / "agents").exists()
        # coding-rules/ 보존
        assert (coding_rules / "common" / "style.md").exists()
