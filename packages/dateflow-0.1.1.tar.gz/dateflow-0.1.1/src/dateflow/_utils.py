"""Internal helpers for dateflow."""
