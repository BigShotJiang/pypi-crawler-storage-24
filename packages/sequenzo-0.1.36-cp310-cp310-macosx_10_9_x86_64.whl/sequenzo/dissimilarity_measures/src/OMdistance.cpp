#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <xsimd/xsimd.hpp>
#include <vector>
#include <cmath>
#include <iostream>
#include "utils.h"
#include "dp_utils.h"
#ifdef _OPENMP
    #include <omp.h>
#endif

namespace py = pybind11;

class OMdistance {
public:
    // indellist: optional state-dependent indel costs. If length alphasize: indellist[state] = cost for state (1-based). If length alphasize-1: indellist[state-1] = cost for state (TraMineR convention). Empty = scalar indel.
    OMdistance(py::array_t<int> sequences, py::array_t<double> sm, double indel, int norm, py::array_t<int> seqlength, py::array_t<int> refseqS,
               py::array_t<double> indellist = py::array_t<double>())
            : indel(indel), norm(norm) {

        py::print("[>] Starting Optimal Matching(OM)...");
        std::cout << std::flush;

        try {
            this->sequences = sequences;
            this->sm = sm;
            this->seqlength = seqlength;

            auto seq_shape = sequences.shape();
            nseq = seq_shape[0];
            seqlen = seq_shape[1];
            alphasize = sm.shape()[0];

            use_indellist = (indellist.size() == static_cast<py::ssize_t>(alphasize) || indellist.size() == static_cast<py::ssize_t>(alphasize - 1));
            indellist_0based = (indellist.size() == static_cast<py::ssize_t>(alphasize - 1));
            if (use_indellist)
                this->indellist = indellist;

            dist_matrix = py::array_t<double>({nseq, nseq});
            // When use_indellist we do not skip prefix/suffix, so DP size is (seqlen+1)x(seqlen+1); prev/curr need seqlen+2 elements.
            fmatsize = use_indellist ? (seqlen + 2) : (seqlen + 1);

            if (norm == 4) {
                maxscost = 2 * indel;
            } else {
                auto ptr = sm.mutable_unchecked<2>();
                for (int i = 0; i < alphasize; i++) {
                    for (int j = i + 1; j < alphasize; j++) {
                        if (ptr(i, j) > maxscost) maxscost = ptr(i, j);
                    }
                }
                maxscost = std::min(maxscost, 2 * indel);
            }

            nans = nseq;
            rseq1 = refseqS.at(0);
            rseq2 = refseqS.at(1);
            if (rseq1 < rseq2) {
                nseq = rseq1;
                nans = nseq * (rseq2 - rseq1);
            } else {
                rseq1 = rseq1 - 1;
            }
            refdist_matrix = py::array_t<double>({nseq, (rseq2 - rseq1)});
        } catch (const std::exception& e) {
            py::print("Error in constructor: ", e.what());
            throw;
        }
    }

    inline double get_indel(int state) const {
        if (use_indellist) {
            auto ptr = indellist.unchecked<1>();
            // state from sequence is 1-based (1..nstates). TraMineR passes indels of length nstates and uses indellist[state] with 0-based state in C.
            int idx = indellist_0based ? (state - 1) : state;
            return ptr(idx);
        }
        return indel;
    }

    double compute_distance(int is, int js, double* prev, double* curr) {
        try {
            auto ptr_len = seqlength.unchecked<1>();
            int m_full = ptr_len(is);
            int n_full = ptr_len(js);
            int mSuf = m_full + 1, nSuf = n_full + 1;
            int prefix = 0;

            auto ptr_seq = sequences.unchecked<2>();
            auto ptr_sm = sm.unchecked<2>();

            // Skipping common prefix/suffix: TraMineR OMVIdistance (vector indel) does NOT skip (commented out in their code), so we match that when use_indellist to get identical results.
            if (!use_indellist) {
                int ii = 1, jj = 1;
                while (ii < mSuf && jj < nSuf && ptr_seq(is, ii-1) == ptr_seq(js, jj-1)) {
                    ii++; jj++; prefix++;
                }
                while (mSuf > ii && nSuf > jj && ptr_seq(is, mSuf - 2) == ptr_seq(js, nSuf - 2)) {
                    mSuf--; nSuf--;
                }
            }

            // Segment lengths (TraMineR uses m=slen[is], n=slen[js]; we align segment [prefix..mSuf-2] so length = mSuf - prefix - 1).
            int m = mSuf - prefix - 1;
            int n = nSuf - prefix - 1;

            if (m == 0 && n == 0)
                return normalize_distance(0.0, 0.0, 0.0, 0.0, norm);
            if (m == 0) {
                double cost = 0;
                for (int x = 0; x < n; ++x)
                    cost += get_indel(ptr_seq(js, prefix + x));
                double maxpossiblecost = std::abs(n_full - m_full) * indel + maxscost * std::min(m_full, n_full);
                return normalize_distance(cost, maxpossiblecost, double(m_full) * indel, double(n_full) * indel, norm);
            }
            if (n == 0) {
                double cost = 0;
                for (int x = 0; x < m; ++x)
                    cost += get_indel(ptr_seq(is, prefix + x));
                double maxpossiblecost = std::abs(n_full - m_full) * indel + maxscost * std::min(m_full, n_full);
                return normalize_distance(cost, maxpossiblecost, double(m_full) * indel, double(n_full) * indel, norm);
            }

            // First row: cumulative insertion costs along js segment
            prev[0] = 0;
            for (int x = 1; x <= n; ++x)
                prev[x] = prev[x - 1] + get_indel(ptr_seq(js, prefix + x - 1));

            if (!use_indellist) {
                // Scalar indel: use SIMD (original logic)
                using batch_t = xsimd::batch<double>;
                constexpr std::size_t B = batch_t::size;
                for (int i = 1; i <= m; ++i) {
                    int ai = ptr_seq(is, prefix + i - 1);
                    curr[0] = indel * double(i);

                    int j = 1;
                    for (; j + (int)B <= n; j += (int)B) {
                        const double* prev_ptr = prev + j;
                        const double* prevm1_ptr = prev + (j - 1);
                        batch_t prevj = batch_t::load_unaligned(prev_ptr);
                        batch_t prevjm1 = batch_t::load_unaligned(prevm1_ptr);
                        alignas(64) double subs[B];
                        for (std::size_t b = 0; b < B; ++b) {
                            int bj = ptr_seq(js, prefix + j + (int)b - 1);
                            subs[b] = (ai == bj) ? 0.0 : ptr_sm(ai, bj);
                        }
                        batch_t sub_batch = batch_t::load_unaligned(subs);
                        batch_t cand_del = prevj + batch_t(indel);
                        batch_t cand_sub = prevjm1 + sub_batch;
                        batch_t vert = xsimd::min(cand_del, cand_sub);
                        double running_ins = curr[j - 1] + indel;
                        for (std::size_t b = 0; b < B; ++b) {
                            double v = vert.get(b);
                            double c = std::min(v, running_ins);
                            curr[j + (int)b] = c;
                            running_ins = c + indel;
                        }
                    }
                    for (; j <= n; ++j) {
                        int bj = ptr_seq(js, prefix + j - 1);
                        double subcost = (ai == bj) ? 0.0 : ptr_sm(ai, bj);
                        curr[j] = std::min({ prev[j] + indel, curr[j - 1] + indel, prev[j - 1] + subcost });
                    }
                    std::swap(prev, curr);
                }
            } else {
                // Vector indel: scalar loop (per-state indel)
                for (int i = 1; i <= m; ++i) {
                    int ai = ptr_seq(is, prefix + i - 1);
                    curr[0] = 0;
                    for (int k = 0; k < i; ++k) curr[0] += get_indel(ptr_seq(is, prefix + k));

                    for (int j = 1; j <= n; ++j) {
                        int bj = ptr_seq(js, prefix + j - 1);
                        double delcost = prev[j] + get_indel(ai);
                        double inscost = curr[j - 1] + get_indel(bj);
                        double subcost = (ai == bj) ? 0.0 : ptr_sm(ai, bj);
                        double subval = prev[j - 1] + subcost;
                        curr[j] = std::min({ delcost, inscost, subval });
                    }
                    std::swap(prev, curr);
                }
            }

            double final_cost = prev[n];
            // TraMineR: use full sequence length for normalization and maxpossiblecost (m_full, n_full = slen[is], slen[js])
            double maxpossiblecost = std::abs(n_full - m_full) * indel + maxscost * std::min(m_full, n_full);
            double ml = double(m_full) * indel;
            double nl = double(n_full) * indel;
            return normalize_distance(final_cost, maxpossiblecost, ml, nl, norm);

        } catch (const std::exception& e) {
            py::print("Error in SIMD-batch compute_distance: ", e.what());
            throw;
        }
    }


    py::array_t<double> compute_all_distances() {
        try {
            return dp_utils::compute_all_distances(
                nseq,
                fmatsize,
                dist_matrix,
                [this](int i, int j, double* prev, double* curr) {
                    return this->compute_distance(i, j, prev, curr);
                }
            );
        } catch (const std::exception& e) {
            py::print("Error in compute_all_distances: ", e.what());
            throw;
        }
    }

    py::array_t<double> compute_refseq_distances() {
        try {
            auto buffer = refdist_matrix.mutable_unchecked<2>();

            #pragma omp parallel
            {
                double* prev = dp_utils::aligned_alloc_double(static_cast<size_t>(fmatsize));
                double* curr = dp_utils::aligned_alloc_double(static_cast<size_t>(fmatsize));

                #pragma omp for schedule(static)
                for (int rseq = rseq1; rseq < rseq2; rseq ++) {
                    for (int is = 0; is < nseq; is ++) {
                        double cmpres = 0;
                        if(is != rseq){
                            cmpres = compute_distance(is, rseq, prev, curr);
                        }

                        buffer(is, rseq - rseq1) = cmpres;
                    }
                }
                dp_utils::aligned_free_double(prev);
                dp_utils::aligned_free_double(curr);
            }

            return refdist_matrix;
        } catch (const std::exception& e) {
            py::print("Error in compute_all_distances: ", e.what());
            throw;
        }
    }

private:
    py::array_t<int> sequences;
    py::array_t<double> sm;
    double indel;
    int norm;
    bool use_indellist = false;
    bool indellist_0based = false;  // true: indellist[state-1]; false: indellist[state]
    py::array_t<double> indellist;
    int nseq;
    int seqlen;
    int alphasize;
    int fmatsize;
    py::array_t<int> seqlength;
    py::array_t<double> dist_matrix;
    double maxscost;

    // about reference sequences :
    int nans = -1;
    int rseq1 = -1;
    int rseq2 = -1;
    py::array_t<double> refdist_matrix;
};