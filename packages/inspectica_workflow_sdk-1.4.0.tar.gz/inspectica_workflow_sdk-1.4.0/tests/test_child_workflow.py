"""Comprehensive tests for the child workflow mechanism.

Covers:
1. Child workflow dispatch — sends request via Kafka, checkpoint-exits
2. Child workflow replay — cached result returned on resume
3. Child workflow resume — parent resumes after child completes
4. Child workflow failure — error propagation to parent
5. Child workflow with no worker — raises ValueError
6. Child workflow shutdown gate — WorkerShutdownError before dispatch
7. Mixed workflow — local + child + fan-out in same workflow
8. Server↔SDK message contract — Kafka payload matches server schema
9. Resume handover — different worker picks up resume after child
10. Edge cases — null input/output, multiple children, index ordering
"""

import asyncio
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from workflow_sdk import workflow as wf_module
from workflow_sdk.workflow import (
    WorkerShutdownError,
    WorkflowCheckpointExit,
    WorkflowContext,
    set_context,
)
from workflow_sdk.worker import (
    CompletedActivity,
    Worker,
    WorkflowResultError,
    WorkflowTask,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_workflow_task(**overrides) -> WorkflowTask:
    defaults = {
        "task_id": "task-001",
        "workflow_id": "wf-parent-001",
        "workflow_name": "ParentWorkflow",
        "input": {"request_id": "req-1"},
        "timeout_ms": 300_000,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    defaults.update(overrides)
    return WorkflowTask(**defaults)


def _make_worker(worker_id: str = "worker-A") -> Worker:
    """Create a Worker with minimal mocks so _execute_workflow can run."""
    worker = Worker.__new__(Worker)
    worker.workflows = {}
    worker.activities = {}
    worker.worker_id = worker_id
    worker.instance_id = "inst-001"
    worker.server_url = "http://localhost:8080"
    worker.api_key = "test-key"
    worker._producer = AsyncMock()
    worker._result_topic = "test-results"
    worker._can_continue_processing = None
    worker._shutting_down = False
    worker._workflow_semaphore = None
    worker._main_loop = None
    return worker


# ===========================================================================
# 1. Child workflow dispatch — checkpoint-exit after Kafka send
# ===========================================================================

class TestChildWorkflowDispatch:
    """execute_child_workflow sends a child_workflow_request via Kafka
    and immediately checkpoint-exits."""

    @pytest.mark.asyncio
    async def test_child_workflow_sends_request_and_checkpoint_exits(self):
        @wf_module.defn
        class ParentWithChild:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                await ctx.execute_activity("local_prep", {})
                result = await ctx.execute_child_workflow(
                    "CreateModelFlow",
                    {"localizationReqId": "loc-1"},
                    start_to_close_timeout_ms=86400000,
                )
                return {"child_result": result}

        async def local_prep(input_data):
            return {"prepared": True}

        local_prep.__activity_name__ = "local_prep"

        worker = _make_worker()
        worker.workflows = {"ParentWithChild": ParentWithChild}
        worker.activities = {"local_prep": local_prep}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(workflow_name="ParentWithChild")
        await worker._execute_workflow(task, "test-results")

        # Workflow should checkpoint-exit (no workflow result sent)
        worker._send_workflow_result.assert_not_called()

        # Verify child_workflow_request was sent via Kafka
        worker._producer.send_and_wait.assert_called()
        child_calls = [
            c for c in worker._producer.send_and_wait.call_args_list
            if c.kwargs.get("value", {}).get("request_type") == "child_workflow_request"
        ]
        assert len(child_calls) == 1
        payload = child_calls[0].kwargs["value"]
        assert payload["child_workflow_name"] == "CreateModelFlow"
        assert payload["activity_index"] == 2  # local_prep was index 1
        assert payload["input"] == {"localizationReqId": "loc-1"}
        assert payload["parent_workflow_id"] == "wf-parent-001"
        assert payload["timeout_ms"] == 86400000

    @pytest.mark.asyncio
    async def test_child_workflow_occupies_single_activity_index(self):
        """execute_child_workflow should use exactly one activity index."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = None
        mock_worker.execute_remote_child_workflow = AsyncMock(
            side_effect=WorkflowCheckpointExit("checkpoint")
        )
        mock_worker._report_local_activity_result = AsyncMock()

        ctx = WorkflowContext(
            activities={"local": AsyncMock(return_value={})},
            workflow_id="wf-001",
            worker=mock_worker,
        )

        # activity index 1
        await ctx.execute_activity("local", {})
        assert ctx._current_activity_index == 1

        # child workflow → index 2
        with pytest.raises(WorkflowCheckpointExit):
            await ctx.execute_child_workflow("ChildFlow", {"key": "val"})
        assert ctx._current_activity_index == 2


# ===========================================================================
# 2. Child workflow replay — cached result on resume
# ===========================================================================

class TestChildWorkflowReplay:
    """When a workflow resumes with child workflow output in completed_activities,
    execute_child_workflow returns the cached result without dispatching."""

    @pytest.mark.asyncio
    async def test_replay_returns_cached_child_workflow_result(self):
        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=None,
            completed_activities={
                1: {"model_id": "mdl-001", "status": "completed"},
            },
        )

        result = await ctx.execute_child_workflow("CreateModelFlow", {"key": "val"})
        assert result == {"model_id": "mdl-001", "status": "completed"}

    @pytest.mark.asyncio
    async def test_replay_does_not_call_worker(self):
        """Cached child workflow result should not trigger any remote call."""
        mock_worker = MagicMock()
        mock_worker.execute_remote_child_workflow = AsyncMock()

        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=mock_worker,
            completed_activities={
                1: {"cached": True},
            },
        )

        result = await ctx.execute_child_workflow("ChildFlow", {})
        assert result == {"cached": True}
        mock_worker.execute_remote_child_workflow.assert_not_called()

    @pytest.mark.asyncio
    async def test_replay_with_null_output(self):
        """Child workflow that returned None should replay as None."""
        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=None,
            completed_activities={1: None},
        )

        result = await ctx.execute_child_workflow("ChildFlow", {})
        assert result is None

    @pytest.mark.asyncio
    async def test_replay_appends_to_activity_results(self):
        """Replayed child workflow result should be appended to activity_results."""
        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=None,
            completed_activities={1: {"child": "output"}},
        )

        await ctx.execute_child_workflow("ChildFlow", {})
        assert ctx.activity_results == [{"child": "output"}]


# ===========================================================================
# 3. Child workflow resume — full workflow lifecycle
# ===========================================================================

class TestChildWorkflowResume:
    """Full lifecycle: dispatch child → checkpoint → resume with cached output."""

    @pytest.mark.asyncio
    async def test_resume_replays_child_then_runs_next_activity(self):
        call_log = []

        async def local_prep(input_data):
            call_log.append("prep")
            return {"prepared": True}

        async def local_finalize(input_data):
            call_log.append("finalize")
            return {"finalized": True, "model": input_data.get("child_result")}

        local_prep.__activity_name__ = "local_prep"
        local_finalize.__activity_name__ = "local_finalize"

        @wf_module.defn
        class ChildResumeWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                await ctx.execute_activity(local_prep, {})
                child_result = await ctx.execute_child_workflow(
                    "CreateModelFlow",
                    {"req_id": "loc-1"},
                    start_to_close_timeout_ms=86400000,
                )
                final = await ctx.execute_activity(
                    local_finalize, {"child_result": child_result}
                )
                return final

        worker = _make_worker()
        worker.workflows = {"ChildResumeWorkflow": ChildResumeWorkflow}
        worker.activities = {"local_prep": local_prep, "local_finalize": local_finalize}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        # Resume with prep + child workflow completed
        task = _make_workflow_task(
            workflow_name="ChildResumeWorkflow",
            completed_activities=[
                CompletedActivity(
                    index=1, name="local_prep", output={"prepared": True}
                ),
                CompletedActivity(
                    index=2,
                    name="child_workflow:CreateModelFlow",
                    output={"model_id": "mdl-001"},
                    is_remote=True,
                ),
            ],
        )

        await worker._execute_workflow(task, "test-results")

        # prep was replayed (not re-executed)
        assert "prep" not in call_log
        # finalize was executed with child output
        assert "finalize" in call_log

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["model"] == {"model_id": "mdl-001"}

    @pytest.mark.asyncio
    async def test_full_lifecycle_dispatch_then_resume(self):
        """Run 1: dispatch child (checkpoint-exit). Run 2: resume with cached."""
        execution_count = {"prep": 0, "finalize": 0}

        async def local_prep(input_data):
            execution_count["prep"] += 1
            return {"prepared": True}

        async def local_finalize(input_data):
            execution_count["finalize"] += 1
            return {"done": True}

        local_prep.__activity_name__ = "local_prep"
        local_finalize.__activity_name__ = "local_finalize"

        @wf_module.defn
        class LifecycleWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                await ctx.execute_activity(local_prep, {})
                child_out = await ctx.execute_child_workflow("ChildFlow", {})
                await ctx.execute_activity(local_finalize, {})
                return {"child": child_out}

        worker = _make_worker()
        worker.workflows = {"LifecycleWorkflow": LifecycleWorkflow}
        worker.activities = {"local_prep": local_prep, "local_finalize": local_finalize}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        # --- Run 1: first execution, checkpoint-exits at child workflow ---
        task1 = _make_workflow_task(workflow_name="LifecycleWorkflow")
        await worker._execute_workflow(task1, "test-results")

        assert execution_count["prep"] == 1
        assert execution_count["finalize"] == 0
        worker._send_workflow_result.assert_not_called()

        # --- Run 2: resume after child completed ---
        worker._send_workflow_result.reset_mock()
        execution_count["prep"] = 0

        task2 = _make_workflow_task(
            workflow_name="LifecycleWorkflow",
            completed_activities=[
                CompletedActivity(index=1, name="local_prep", output={"prepared": True}),
                CompletedActivity(
                    index=2, name="child_workflow:ChildFlow",
                    output={"child_done": True}, is_remote=True,
                ),
            ],
        )
        await worker._execute_workflow(task2, "test-results")

        assert execution_count["prep"] == 0  # replayed
        assert execution_count["finalize"] == 1  # fresh

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["child"] == {"child_done": True}


# ===========================================================================
# 4. Child workflow requires worker — ValueError if worker is None
# ===========================================================================

class TestChildWorkflowNoWorker:
    @pytest.mark.asyncio
    async def test_raises_value_error_without_worker(self):
        """execute_child_workflow requires a worker for remote dispatch."""
        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=None,
        )

        with pytest.raises(ValueError, match="requires a worker"):
            await ctx.execute_child_workflow("ChildFlow", {})


# ===========================================================================
# 5. Child workflow shutdown gate — WorkerShutdownError
# ===========================================================================

class TestChildWorkflowShutdownGate:
    @pytest.mark.asyncio
    async def test_shutdown_gate_blocks_child_workflow(self):
        """If can_continue_processing returns False, raise WorkerShutdownError."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = MagicMock(return_value=False)
        mock_worker.execute_remote_child_workflow = AsyncMock()

        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=mock_worker,
        )

        with pytest.raises(WorkerShutdownError, match="can_continue_processing"):
            await ctx.execute_child_workflow("ChildFlow", {}, start_to_close_timeout_ms=60000)

        # Should NOT have tried to dispatch
        mock_worker.execute_remote_child_workflow.assert_not_called()

    @pytest.mark.asyncio
    async def test_shutdown_gate_allows_when_true(self):
        """If can_continue_processing returns True, proceed normally."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = MagicMock(return_value=True)
        mock_worker.execute_remote_child_workflow = AsyncMock(
            side_effect=WorkflowCheckpointExit("dispatched")
        )

        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=mock_worker,
        )

        with pytest.raises(WorkflowCheckpointExit):
            await ctx.execute_child_workflow("ChildFlow", {})

        mock_worker.execute_remote_child_workflow.assert_called_once()


# ===========================================================================
# 6. execute_remote_child_workflow — Kafka payload & checkpoint-exit
# ===========================================================================

class TestExecuteRemoteChildWorkflow:
    @pytest.mark.asyncio
    async def test_sends_request_and_raises_checkpoint_exit(self):
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit) as exc_info:
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-parent-001",
                child_workflow_name="CreateModelFlow",
                activity_index=5,
                input_data={"localizationReqId": "loc-1"},
                timeout_ms=86400000,
            )

        assert "CreateModelFlow" in str(exc_info.value)
        assert "dispatched" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_kafka_payload_matches_server_schema(self):
        """The Kafka payload must match the server's ChildWorkflowRequest schema."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-parent-042",
                child_workflow_name="CreateModelFlow",
                activity_index=3,
                input_data={"key": "val"},
                timeout_ms=120000,
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        # Required fields for server ChildWorkflowRequest
        assert payload["request_type"] == "child_workflow_request"
        assert payload["parent_workflow_id"] == "wf-parent-042"
        assert payload["child_workflow_name"] == "CreateModelFlow"
        assert payload["activity_index"] == 3
        assert payload["input"] == {"key": "val"}
        assert payload["timeout_ms"] == 120000
        assert payload["requester_worker_id"] == "worker-A"
        assert "request_id" in payload
        assert "correlation_id" in payload
        assert "created_at" in payload

    @pytest.mark.asyncio
    async def test_kafka_key_is_parent_workflow_id(self):
        """Child workflow request should be keyed by parent_workflow_id."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-parent-099",
                child_workflow_name="X",
                activity_index=1,
                input_data={},
            )

        key = worker._producer.send_and_wait.call_args.kwargs["key"]
        assert key == b"wf-parent-099"

    @pytest.mark.asyncio
    async def test_null_input_data(self):
        """Child workflow with None input should serialize correctly."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-001",
                child_workflow_name="SimpleChild",
                activity_index=1,
                input_data=None,
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        assert payload["input"] is None

    @pytest.mark.asyncio
    async def test_producer_not_ready_raises_runtime_error(self):
        """If Kafka producer is not available, RuntimeError should propagate."""
        worker = _make_worker()
        worker._producer = None  # Simulate producer not initialized

        with pytest.raises(RuntimeError, match="Kafka producer not initialized"):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-001",
                child_workflow_name="ChildFlow",
                activity_index=1,
                input_data={},
            )


# ===========================================================================
# 7. Mixed workflow — local + child workflow + fan-out
# ===========================================================================

class TestMixedWorkflowWithChild:
    @pytest.mark.asyncio
    async def test_local_then_child_then_fanout_resume(self):
        """Resume a workflow that has local activity, child workflow,
        and fan-out all completed."""
        call_log = []

        async def final_merge(input_data):
            call_log.append("merge")
            return {
                "model": input_data["child_result"],
                "batch_count": len(input_data["fan_results"]),
            }

        final_merge.__activity_name__ = "final_merge"

        @wf_module.defn
        class MixedFlow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                prep = await ctx.execute_activity("local_prep", {})
                child_result = await ctx.execute_child_workflow(
                    "CreateModelFlow", {"req": "loc-1"}
                )
                fan_results = await ctx.execute_fan_out_activity(
                    "batch_process",
                    [{"b": 0}, {"b": 1}],
                )
                merged = await ctx.execute_activity(
                    final_merge,
                    {"child_result": child_result, "fan_results": fan_results},
                )
                return merged

        async def local_prep(input_data):
            return {"ok": True}

        local_prep.__activity_name__ = "local_prep"

        worker = _make_worker()
        worker.workflows = {"MixedFlow": MixedFlow}
        worker.activities = {"local_prep": local_prep, "final_merge": final_merge}
        worker._send_workflow_result = AsyncMock()
        worker._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(
            workflow_name="MixedFlow",
            completed_activities=[
                CompletedActivity(index=1, name="local_prep", output={"ok": True}),
                CompletedActivity(
                    index=2, name="child_workflow:CreateModelFlow",
                    output={"model_id": "mdl-1"}, is_remote=True,
                ),
                CompletedActivity(
                    index=3, name="batch_process",
                    output=[{"r0": "ok"}, {"r1": "ok"}], is_remote=True,
                ),
            ],
        )

        await worker._execute_workflow(task, "test-results")

        assert "merge" in call_log
        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["model"] == {"model_id": "mdl-1"}
        assert kw["output"]["batch_count"] == 2


# ===========================================================================
# 8. Multiple child workflows in same parent
# ===========================================================================

class TestMultipleChildWorkflows:
    @pytest.mark.asyncio
    async def test_two_child_workflows_sequential(self):
        """Parent dispatches two child workflows in sequence.
        First run: checkpoint at first child. Second run: checkpoint at second.
        Third run: both cached, finalize runs."""

        @wf_module.defn
        class TwoChildFlow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                model = await ctx.execute_child_workflow("CreateModelFlow", {"q": "normal"})
                deliver = await ctx.execute_child_workflow("DeliverFlow", {"model": model})
                return {"model": model, "deliver": deliver}

        worker = _make_worker()
        worker.workflows = {"TwoChildFlow": TwoChildFlow}
        worker.activities = {}
        worker._send_workflow_result = AsyncMock()

        # --- Run 1: checkpoint at first child ---
        task1 = _make_workflow_task(workflow_name="TwoChildFlow")
        await worker._execute_workflow(task1, "test-results")
        worker._send_workflow_result.assert_not_called()

        # --- Run 2: first child cached, checkpoint at second ---
        worker._send_workflow_result.reset_mock()
        task2 = _make_workflow_task(
            workflow_name="TwoChildFlow",
            completed_activities=[
                CompletedActivity(
                    index=1, name="child_workflow:CreateModelFlow",
                    output={"model_id": "m1"}, is_remote=True,
                ),
            ],
        )
        await worker._execute_workflow(task2, "test-results")
        worker._send_workflow_result.assert_not_called()

        # --- Run 3: both cached, workflow completes ---
        worker._send_workflow_result.reset_mock()
        task3 = _make_workflow_task(
            workflow_name="TwoChildFlow",
            completed_activities=[
                CompletedActivity(
                    index=1, name="child_workflow:CreateModelFlow",
                    output={"model_id": "m1"}, is_remote=True,
                ),
                CompletedActivity(
                    index=2, name="child_workflow:DeliverFlow",
                    output={"delivered": True}, is_remote=True,
                ),
            ],
        )
        await worker._execute_workflow(task3, "test-results")

        kw = worker._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["model"] == {"model_id": "m1"}
        assert kw["output"]["deliver"] == {"delivered": True}

    @pytest.mark.asyncio
    async def test_child_workflow_indices_are_correct(self):
        """Each child workflow should get its own incrementing index."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = None

        call_indices = []

        async def capture_index(**kwargs):
            call_indices.append(kwargs["activity_index"])
            raise WorkflowCheckpointExit("dispatched")

        mock_worker.execute_remote_child_workflow = AsyncMock(side_effect=capture_index)
        mock_worker._report_local_activity_result = AsyncMock()

        ctx = WorkflowContext(
            activities={"local": AsyncMock(return_value={})},
            workflow_id="wf-001",
            worker=mock_worker,
        )

        await ctx.execute_activity("local", {})  # index 1

        with pytest.raises(WorkflowCheckpointExit):
            await ctx.execute_child_workflow("ChildA", {})  # index 2

        assert call_indices == [2]
        assert ctx._current_activity_index == 2


# ===========================================================================
# 9. Resume handover — different worker picks up child resume
# ===========================================================================

class TestChildWorkflowResumeHandover:
    @pytest.mark.asyncio
    async def test_resume_on_different_worker_after_child(self):
        """Worker-A dispatched child workflow, Worker-B picks up the resume."""
        call_log = []

        async def step_a(input_data):
            call_log.append("step_a")
            return {"a": 1}

        async def step_c(input_data):
            call_log.append("step_c")
            return {"c": input_data.get("child_out")}

        step_a.__activity_name__ = "step_a"
        step_c.__activity_name__ = "step_c"

        @wf_module.defn
        class HandoverChildWorkflow:
            @wf_module.run
            async def run(self, input_data):
                ctx = wf_module.get_current_context()
                r1 = await ctx.execute_activity(step_a, {})
                child_out = await ctx.execute_child_workflow("ChildFlow", {"from": r1})
                r3 = await ctx.execute_activity(step_c, {"child_out": child_out})
                return {"r1": r1, "child": child_out, "r3": r3}

        # Worker-B (different from Worker-A)
        worker_b = _make_worker(worker_id="worker-B")
        worker_b.workflows = {"HandoverChildWorkflow": HandoverChildWorkflow}
        worker_b.activities = {"step_a": step_a, "step_c": step_c}
        worker_b._send_workflow_result = AsyncMock()
        worker_b._report_local_activity_result = AsyncMock()

        task = _make_workflow_task(
            workflow_name="HandoverChildWorkflow",
            completed_activities=[
                CompletedActivity(index=1, name="step_a", output={"a": 1}),
                CompletedActivity(
                    index=2, name="child_workflow:ChildFlow",
                    output={"child_done": True}, is_remote=True,
                ),
            ],
        )

        await worker_b._execute_workflow(task, "test-results")

        assert "step_a" not in call_log  # replayed
        assert "step_c" in call_log  # fresh

        kw = worker_b._send_workflow_result.call_args.kwargs
        assert kw["status"] == "completed"
        assert kw["output"]["r1"] == {"a": 1}
        assert kw["output"]["child"] == {"child_done": True}
        assert kw["output"]["r3"] == {"c": {"child_done": True}}


# ===========================================================================
# 10. Server↔SDK message contract
# ===========================================================================

class TestChildWorkflowContract:
    @pytest.mark.asyncio
    async def test_child_workflow_request_contract(self):
        """child_workflow_request payload matches server ChildWorkflowRequest schema."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-parent-001",
                child_workflow_name="CreateModelFlow",
                activity_index=5,
                input_data={"localizationReqId": "loc-1", "meshQuality": "normal"},
                timeout_ms=86400000,
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        # Must have all required fields for server ChildWorkflowRequest
        required_fields = [
            "request_type", "request_id", "parent_workflow_id",
            "child_workflow_name", "activity_index", "input",
            "timeout_ms", "requester_worker_id", "correlation_id", "created_at",
        ]
        for field in required_fields:
            assert field in payload, f"Missing required field: {field}"

        assert payload["request_type"] == "child_workflow_request"
        assert isinstance(payload["request_id"], str) and len(payload["request_id"]) > 0
        assert isinstance(payload["correlation_id"], str) and len(payload["correlation_id"]) > 0
        assert isinstance(payload["created_at"], str) and "T" in payload["created_at"]

    @pytest.mark.asyncio
    async def test_resume_task_completed_activities_with_child(self):
        """The completed_activities in a resume WorkflowTask with child workflow
        output must be parseable by the SDK's WorkflowTask model."""
        server_payload = {
            "task_id": "task-resume",
            "task_type": "workflow",
            "workflow_id": "wf-parent-001",
            "workflow_name": "ParentWorkflow",
            "input": {"request_id": "req-1"},
            "timeout_ms": 300000,
            "created_at": "2025-01-01T00:00:00Z",
            "completed_activities": [
                {"index": 1, "name": "local_step", "output": {"a": 1}, "is_remote": False},
                {
                    "index": 2,
                    "name": "child_workflow:CreateModelFlow",
                    "output": {"model_id": "mdl-001", "status": "completed"},
                    "is_remote": True,
                },
            ],
        }

        task = WorkflowTask(**server_payload)
        assert len(task.completed_activities) == 2
        assert task.completed_activities[0].index == 1
        assert task.completed_activities[1].index == 2
        assert task.completed_activities[1].name == "child_workflow:CreateModelFlow"
        assert task.completed_activities[1].output == {"model_id": "mdl-001", "status": "completed"}
        assert task.completed_activities[1].is_remote is True


# ===========================================================================
# 11. Edge cases
# ===========================================================================

class TestChildWorkflowEdgeCases:
    @pytest.mark.asyncio
    async def test_child_workflow_with_empty_dict_input(self):
        """Child workflow with empty dict input should work."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-001",
                child_workflow_name="ChildFlow",
                activity_index=1,
                input_data={},
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        assert payload["input"] == {}

    @pytest.mark.asyncio
    async def test_child_workflow_default_timeout(self):
        """Default timeout_ms should be 300000 (5 minutes)."""
        worker = _make_worker()

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-001",
                child_workflow_name="ChildFlow",
                activity_index=1,
                input_data={},
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        assert payload["timeout_ms"] == 300000

    @pytest.mark.asyncio
    async def test_child_workflow_context_default_timeout(self):
        """WorkflowContext.execute_child_workflow default timeout should be 300000."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = None
        mock_worker.execute_remote_child_workflow = AsyncMock(
            side_effect=WorkflowCheckpointExit("dispatched")
        )

        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=mock_worker,
        )

        with pytest.raises(WorkflowCheckpointExit):
            await ctx.execute_child_workflow("ChildFlow", {})

        call_kwargs = mock_worker.execute_remote_child_workflow.call_args.kwargs
        assert call_kwargs["timeout_ms"] == 300000

    @pytest.mark.asyncio
    async def test_module_level_execute_child_workflow(self):
        """The module-level workflow.execute_child_workflow() convenience function."""
        mock_worker = MagicMock()
        mock_worker._can_continue_processing = None
        mock_worker.execute_remote_child_workflow = AsyncMock(
            side_effect=WorkflowCheckpointExit("dispatched")
        )

        ctx = WorkflowContext(
            activities={},
            workflow_id="wf-001",
            worker=mock_worker,
        )
        set_context(ctx)

        with pytest.raises(WorkflowCheckpointExit):
            await wf_module.execute_child_workflow(
                "ChildFlow", {"key": "val"}, start_to_close_timeout_ms=60000
            )

        mock_worker.execute_remote_child_workflow.assert_called_once()
        call_kwargs = mock_worker.execute_remote_child_workflow.call_args.kwargs
        assert call_kwargs["child_workflow_name"] == "ChildFlow"
        assert call_kwargs["input_data"] == {"key": "val"}
        assert call_kwargs["timeout_ms"] == 60000

    @pytest.mark.asyncio
    async def test_child_workflow_error_in_kafka_send_reports_error(self):
        """If Kafka send fails (non-RuntimeError), the error should be reported."""
        worker = _make_worker()
        worker._producer.send_and_wait = AsyncMock(
            side_effect=ConnectionError("broker down")
        )
        worker._report_workflow_error = AsyncMock()

        with pytest.raises(ConnectionError, match="broker down"):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-001",
                child_workflow_name="ChildFlow",
                activity_index=1,
                input_data={},
            )

        worker._report_workflow_error.assert_called_once()
        call_kwargs = worker._report_workflow_error.call_args.kwargs
        assert call_kwargs["workflow_id"] == "wf-001"
        assert call_kwargs["activity_name"] == "child_workflow:ChildFlow"
        assert "broker down" in call_kwargs["error_message"]

    @pytest.mark.asyncio
    async def test_worker_id_in_request_payload(self):
        """requester_worker_id should be the parent worker's ID."""
        worker = _make_worker(worker_id="localization-worker-staging")

        with pytest.raises(WorkflowCheckpointExit):
            await worker.execute_remote_child_workflow(
                parent_workflow_id="wf-001",
                child_workflow_name="ChildFlow",
                activity_index=1,
                input_data={},
            )

        payload = worker._producer.send_and_wait.call_args.kwargs["value"]
        assert payload["requester_worker_id"] == "localization-worker-staging"
