# Workflow decorators and utilities

import asyncio
import contextvars
import inspect
import logging
import time
from typing import TYPE_CHECKING, Any, Callable, TypeVar

if TYPE_CHECKING:
    from workflow_sdk.worker import Worker

logger = logging.getLogger(__name__)


class WorkerShutdownError(Exception):
    """Raised when ``can_continue_processing`` returns False mid-workflow.

    The worker should catch this, send a retry/resume result to the
    workflow engine, and initiate a graceful shutdown.
    """


class WorkflowCheckpointExit(Exception):
    """Raised after a remote activity or child workflow completes to checkpoint the workflow.

    Instead of continuing execution in the current worker, the workflow
    exits cleanly. The server will send a resume WorkflowTask (with all
    completed activities) via Kafka so that *any* worker instance in the
    consumer group can pick it up and replay from the checkpoint.

    This makes remote-activity and child-workflow invocations resilient
    to worker crashes: the Kafka resume message survives even if the
    original worker dies.
    """

F = TypeVar("F", bound=Callable)
T = TypeVar("T", bound=type)

# Context variable to hold the current workflow execution context
_workflow_context: contextvars.ContextVar["WorkflowContext | None"] = contextvars.ContextVar(
    "_workflow_context", default=None
)


class WorkflowContext:
    """Context for workflow execution, holds activities and allows execute_activity calls."""

    def __init__(
        self,
        activities: dict[str, Callable],
        workflow_id: str,
        worker: "Worker | None" = None,
        completed_activities: dict[int, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        self.activities = activities
        self.workflow_id = workflow_id
        self.worker = worker
        self.activity_results: list[Any] = []
        # For replay: map of activity_index -> cached output
        self._completed_activities = completed_activities or {}
        # Current activity index (incremented on each execute_activity call)
        self._current_activity_index = 0
        # Track if we're in replay mode
        self._is_replaying = bool(completed_activities)
        # Metadata from workflow submission (e.g., access_token for authorization)
        self.metadata = metadata or {}

    async def execute_activity(
        self,
        activity: Callable | str,
        input_data: Any = None,
        start_to_close_timeout_ms: int = 60000,
    ) -> Any:
        """Execute an activity and return its result.
        
        Args:
            activity: Either an activity function (decorated with @activity.defn)
                     or a string name of the activity for cross-worker calls.
            input_data: Input to pass to the activity.
            start_to_close_timeout_ms: Timeout for activity execution.

        Raises:
            WorkerShutdownError: If ``can_continue_processing`` returns False.
        """
        # Increment activity index for this call
        self._current_activity_index += 1
        current_index = self._current_activity_index

        # Check if this activity was already completed (replay mode)
        if current_index in self._completed_activities:
            cached_result = self._completed_activities[current_index]
            logger.info(
                f"Replay: Returning cached result for activity index {current_index}"
            )
            self.activity_results.append(cached_result)
            return cached_result

        # Gate check: can this worker continue processing?
        if self.worker is not None and self.worker._can_continue_processing is not None:
            can_proceed = await asyncio.to_thread(
                self.worker._can_continue_processing, start_to_close_timeout_ms,
            )
            if not can_proceed:
                raise WorkerShutdownError(
                    f"can_continue_processing returned False before activity "
                    f"index {current_index} — worker must shut down"
                )

        # Support both function reference and string name
        if isinstance(activity, str):
            activity_name = activity
        else:
            activity_name = getattr(activity, "__activity_name__", activity.__name__)

        # Check if activity is registered locally
        if activity_name in self.activities:
            # Execute locally (in-process)
            activity_fn = self.activities[activity_name]

            start_time = time.time()

            try:
                if inspect.iscoroutinefunction(activity_fn):
                    result = await asyncio.wait_for(
                        activity_fn(input_data),
                        timeout=start_to_close_timeout_ms / 1000,
                    )
                else:
                    # Run sync activity in thread pool to keep the event loop
                    # free for Kafka heartbeats and server heartbeats
                    result = await asyncio.wait_for(
                        asyncio.to_thread(activity_fn, input_data),
                        timeout=start_to_close_timeout_ms / 1000,
                    )

                duration_ms = int((time.time() - start_time) * 1000)

                # Report local activity completion to server for activity history tracking
                # This is needed so resume can replay completed activities
                if self.worker is not None:
                    await self.worker._report_local_activity_result(
                        workflow_id=self.workflow_id,
                        activity_name=activity_name,
                        activity_index=current_index,
                        status="completed",
                        output=result,
                        duration_ms=duration_ms,
                    )

                self.activity_results.append(result)
                return result

            except WorkerShutdownError:
                raise
            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)

                # Report local activity failure to server for activity history tracking
                if self.worker is not None:
                    await self.worker._report_local_activity_result(
                        workflow_id=self.workflow_id,
                        activity_name=activity_name,
                        activity_index=current_index,
                        status="failed",
                        error_message=str(e),
                        error_type=type(e).__name__,
                        duration_ms=duration_ms,
                    )

                raise  # Re-raise the exception

        # Activity not registered locally - route via server
        if self.worker is None:
            raise ValueError(
                f"Activity '{activity_name}' not registered locally and no worker available for remote execution"
            )

        # Execute remotely via server routing
        result = await self.worker.execute_remote_activity(
            workflow_id=self.workflow_id,
            activity_name=activity_name,
            activity_index=current_index,
            input_data=input_data,
            timeout_ms=start_to_close_timeout_ms,
        )

        self.activity_results.append(result)
        return result

    async def execute_child_workflow(
        self,
        workflow_name: str,
        input_data: Any = None,
        start_to_close_timeout_ms: int = 300000,
    ) -> Any:
        """Execute a child workflow and return its result.

        Sends a child workflow request to the server, which creates a new
        workflow execution linked to this parent.  The parent checkpoints
        and resumes when the child completes.

        The child workflow runs on whatever worker has registered it —
        it can be a completely different worker type / codebase.

        Args:
            workflow_name: Name of the child workflow (must be registered
                by some connected worker).
            input_data: Input to pass to the child workflow.
            start_to_close_timeout_ms: Timeout for the entire child
                workflow execution.

        Returns:
            The output of the child workflow.

        Raises:
            WorkerShutdownError: If ``can_continue_processing`` returns False.
        """
        self._current_activity_index += 1
        current_index = self._current_activity_index

        # Replay: return cached result from a previous execution
        if current_index in self._completed_activities:
            cached_result = self._completed_activities[current_index]
            logger.info(
                f"Replay: Returning cached child workflow result for "
                f"activity index {current_index}"
            )
            self.activity_results.append(cached_result)
            return cached_result

        # Gate check
        if self.worker is not None and self.worker._can_continue_processing is not None:
            can_proceed = await asyncio.to_thread(
                self.worker._can_continue_processing, start_to_close_timeout_ms,
            )
            if not can_proceed:
                raise WorkerShutdownError(
                    f"can_continue_processing returned False before child "
                    f"workflow index {current_index} — worker must shut down"
                )

        if self.worker is None:
            raise ValueError(
                f"Child workflow '{workflow_name}' requires a worker for remote execution"
            )

        result = await self.worker.execute_remote_child_workflow(
            parent_workflow_id=self.workflow_id,
            child_workflow_name=workflow_name,
            activity_index=current_index,
            input_data=input_data,
            timeout_ms=start_to_close_timeout_ms,
        )

        self.activity_results.append(result)
        return result

    async def execute_fan_out_activity(
        self,
        activity: Callable | str,
        inputs: list[Any],
        start_to_close_timeout_ms: int = 60000,
    ) -> list[Any]:
        """Execute an activity in parallel (fan-out) across multiple inputs.

        Dispatches N copies of the same activity with different inputs to be
        executed concurrently on remote workers.  The workflow checkpoints
        after sending the fan-out request; the server resumes the workflow
        once all N tasks complete.

        Args:
            activity: Activity function or string name for cross-worker calls.
            inputs: List of input_data, one per parallel invocation.
            start_to_close_timeout_ms: Timeout for each individual activity.

        Returns:
            List of outputs, one per input (order preserved by fan_out_index).

        Raises:
            WorkerShutdownError: If ``can_continue_processing`` returns False.
        """
        # Increment activity index — the entire fan-out occupies one index
        self._current_activity_index += 1
        current_index = self._current_activity_index

        # Replay: return cached aggregated result
        if current_index in self._completed_activities:
            cached_result = self._completed_activities[current_index]
            logger.info(
                f"Replay: Returning cached fan-out result for activity index {current_index}"
            )
            self.activity_results.append(cached_result)
            return cached_result

        # Gate check
        if self.worker is not None and self.worker._can_continue_processing is not None:
            can_proceed = await asyncio.to_thread(
                self.worker._can_continue_processing, start_to_close_timeout_ms,
            )
            if not can_proceed:
                raise WorkerShutdownError(
                    f"can_continue_processing returned False before fan-out "
                    f"activity index {current_index} — worker must shut down"
                )

        if isinstance(activity, str):
            activity_name = activity
        else:
            activity_name = getattr(activity, "__activity_name__", activity.__name__)

        if self.worker is None:
            raise ValueError(
                f"Activity '{activity_name}' fan-out requires a worker for remote execution"
            )

        # Send fan-out request and checkpoint-exit
        result = await self.worker.execute_remote_fan_out_activity(
            workflow_id=self.workflow_id,
            activity_name=activity_name,
            activity_index=current_index,
            inputs=inputs,
            timeout_ms=start_to_close_timeout_ms,
        )

        self.activity_results.append(result)
        return result


def get_current_context() -> WorkflowContext:
    """Get the current workflow context."""
    ctx = _workflow_context.get()
    if ctx is None:
        raise RuntimeError("Not running inside a workflow context")
    return ctx


def set_context(ctx: WorkflowContext | None) -> contextvars.Token:
    """Set the current workflow context."""
    return _workflow_context.set(ctx)


def defn(cls: T) -> T:
    """
    Decorator to mark a class as a workflow definition.

    Usage:
        from workflow_sdk import workflow

        @workflow.defn
        class MyWorkflow:
            @workflow.run
            async def run(self, input_data: dict) -> dict:
                return {"result": "done"}
    """
    cls.__workflow_name__ = cls.__name__
    cls.__is_workflow__ = True
    return cls


def run(fn: F) -> F:
    """
    Decorator to mark a method as the workflow entry point.

    Usage:
        @workflow.defn
        class MyWorkflow:
            @workflow.run
            async def run(self, input_data: dict) -> dict:
                return {"result": "done"}
    """
    fn.__is_workflow_run__ = True
    return fn


async def execute_activity(
    activity: Callable | str,
    input_data: Any = None,
    start_to_close_timeout_ms: int = 60000,
) -> Any:
    """
    Execute an activity within a workflow.

    Args:
        activity: Either an activity function (decorated with @activity.defn)
                 or a string name of the activity for cross-worker calls.
        input_data: Input to pass to the activity.
        start_to_close_timeout_ms: Timeout for activity execution.

    Usage:
        # Option 1: Local activity (function reference)
        result = await workflow.execute_activity(my_activity, {"key": "value"})
        
        # Option 2: Remote activity (string name) - for cross-worker calls
        result = await workflow.execute_activity("say_count", {"message": "hi", "count": 1})
    """
    ctx = get_current_context()
    return await ctx.execute_activity(
        activity,
        input_data,
        start_to_close_timeout_ms,
    )


async def execute_child_workflow(
    workflow_name: str,
    input_data: Any = None,
    start_to_close_timeout_ms: int = 300000,
) -> Any:
    """
    Execute a child workflow from within a parent workflow.

    The child runs as a separate workflow execution on whatever worker
    has registered it.  The parent checkpoints and resumes automatically
    when the child completes.

    Args:
        workflow_name: Name of the child workflow.
        input_data: Input to pass to the child workflow.
        start_to_close_timeout_ms: Timeout for the entire child workflow.

    Returns:
        The output of the child workflow.

    Usage:
        result = await workflow.execute_child_workflow(
            "CreateModelFlow",
            {"localizationReqId": request_id, "meshQuality": "normal"},
            start_to_close_timeout_ms=86400000,  # 24 hours
        )
    """
    ctx = get_current_context()
    return await ctx.execute_child_workflow(
        workflow_name,
        input_data,
        start_to_close_timeout_ms,
    )


async def execute_fan_out_activity(
    activity: Callable | str,
    inputs: list[Any],
    start_to_close_timeout_ms: int = 60000,
) -> list[Any]:
    """
    Execute an activity in parallel (fan-out) across multiple inputs.

    Dispatches N copies of the same activity with different inputs to be
    executed concurrently on remote workers.  The workflow checkpoints
    after sending the fan-out request; the server resumes the workflow
    once all N tasks complete.

    Args:
        activity: Activity function or string name for cross-worker calls.
        inputs: List of input_data, one per parallel invocation.
        start_to_close_timeout_ms: Timeout for each individual activity.

    Returns:
        List of outputs, one per input (order preserved by fan_out_index).

    Usage:
        results = await workflow.execute_fan_out_activity(
            "localization_match_sample",
            [{"batch_index": i} for i in range(num_batches)],
            start_to_close_timeout_ms=3600000,
        )
    """
    ctx = get_current_context()
    return await ctx.execute_fan_out_activity(
        activity,
        inputs,
        start_to_close_timeout_ms,
    )
