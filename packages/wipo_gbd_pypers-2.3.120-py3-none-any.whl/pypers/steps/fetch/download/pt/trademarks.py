import os
import shutil
import datetime
import os
import io
import json
import argparse
import time
import ntpath
import requests
import http.client
from pathlib import Path
import yaml
import uuid
import datetime
from pypers.steps.base.fetch_step_api import FetchStepAPI

import logging
import logging.handlers 

from . import get_auth_token

class Trademarks(FetchStepAPI):
    spec = {
        "version": "2.0",
        "descr": [
            "Fetch updates using REST API"
        ]
    }

    token = None

    def get_connections_info(self):
        return None, None

    def get_intervals(self):
        """ 
        Return the intervals to be downloaded, in our case one interval is one day, so
        we enumerate days from the day of the last update 
        """
        # get the date of the last update
        if not len(self.done_archives):
            # no done archives in dynamodb table gbd_pypers_done_archive 
            #last_update = (datetime.datetime.today() - datetime.timedelta(1))
            last_update = (datetime.datetime.today() - datetime.timedelta(3))
        else:
            # we get the day of the last update from the last "done_archive" file name stored 
            # in dynamodb table gbd_pypers_done_archive 
            # # expecting names like : 2018-01-07.TO.2018-01-08.1.txt
            last_update = sorted(self.done_archives)[-1].split('.')[2]
            if '_' in last_update:
                last_update = last_update.split('_')[0]
            last_update = datetime.datetime.fromisoformat(last_update)

        today = datetime.datetime.today()
        result = []
        result.append( (last_update.strftime("%Y-%m-%d"), today.strftime("%Y-%m-%d")) )
        print(result)
        return result

    def trademark_update(self, start_date, end_date):
        try:
            token = self._lazy_get_auth_token()
        except Exception as e: 
            return { "error": str(e) }

        json_chunks = []
        header = {
            'Authorization': 'Bearer ' + token,
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            "Cache-Control": "no-cache"
        }

        host = "https://"+self.conn_params["base_url_update"]+"/list/updatedTMList"

        print("url:")
        print(host+"?startDate="+start_date+"&endDate="+end_date)
        
        response = requests.get(host+"?startDate="+start_date+"&endDate="+end_date, headers=header)
        chunks = []

        if response.status_code == 200:
            # format is: '[ "PT500000000387491", "PT500000000387579" ]'
            raw_list = response.text
            raw_list = raw_list.replace("[", "")
            raw_list = raw_list.replace("]", "")
            pieces = raw_list.split(",")
            for piece in pieces:
                chunks.append(piece.strip().replace("\"", ""))

        return chunks

    def _lazy_get_auth_token(self, force=False):
        if self.token == None or force:
            self.token, _ = get_auth_token(self.conn_params)
        return self.token

    def _remove_xml_declaration(self, xml_content):
        return xml_content.replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '')

    def trademark_document(self, application_number):
        '''
        Fech a full document based on an application number.
        There is no authentication needed here, access is granted based on IP whitelist.
        '''
        host = "https://"+self.conn_params["base_url_doc"]+"/trademark/data/"+application_number
        response = requests.get(host)
        print("donwloading: " + host)

        if response.status_code == 200:
            # response is in XML, check encoding
            xml_content = response.text
            # response["content"].encode('utf-8') # bytes
            return xml_content
        else:
            return None
            #raise Exception("error: " + str(response.status_code)) 

    def specific_api_process(self, session):
        self.api_url = "https://"+self.conn_params["base_url_update"]+"/list/updatedTMList"

        if self.intervals is None:
            return
        for interval in self.intervals:
            print("download interval:", interval)
            chunks = self.trademark_update(interval[0], interval[1])
            print("total for interval", str(len(chunks)), "json chunks")

            self.logger.info('%s-%s: %d applications found' % (interval[0], interval[1], len(chunks)))

            # write output file with these chunks 
            output_chunk_file =  os.path.join(self.output_dir, 
                '%s.TO.%s_%s.xml' % (interval[0], interval[1], len(chunks)))
            print("output_chunk_file:", output_chunk_file)

            with open(output_chunk_file, 'w') as fh:
                fh.write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
                fh.write("<transactions>\n")
                rank = 0
                for chunk in chunks: 
                    try:
                        #if rank == 20:
                        #    break
                        xml_content = self.trademark_document(chunk)
                        # remove the first line which is the xml declaration
                        fh.write(self._remove_xml_declaration(xml_content))
                        fh.write("\n")
                        rank += 1
                    except:
                        self.logger.error('Could not download application document: ' + chunk)
                fh.write("</transactions>\n")

            self.output_files.append(output_chunk_file)

            print(output_chunk_file, "written")

        #raise Exception("HERE")

