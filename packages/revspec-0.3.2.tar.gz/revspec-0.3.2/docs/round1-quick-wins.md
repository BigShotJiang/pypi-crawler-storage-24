# Round 1: Quick Wins Implementation Spec

4 independent improvements to ship together. All low-risk, high-impact.

---

## 1. Atomic JSONL Writes

**File:** `revspec/protocol.py` — `append_event()`

**Problem:** The current `open("a")` + `f.write()` + `f.flush()` path allows two concurrent writers (TUI + `revspec reply` CLI) to interleave partial JSON lines, producing corrupt JSONL.

**Fix:** Replace buffered Python file I/O with raw `os.open(O_APPEND)` + `os.write()`. POSIX guarantees atomicity for writes under `PIPE_BUF` (4KB on Linux/macOS). Events are <1KB.

**Current code (lines 79-84):**
```python
try:
    with open(jsonl_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(data) + "\n")
        f.flush()
except OSError as exc:
    raise OSError(f"Failed to write event to {jsonl_path}: {exc}") from exc
```

**New code:**
```python
try:
    line = json.dumps(data, ensure_ascii=False).encode("utf-8") + b"\n"
    fd = os.open(jsonl_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    try:
        os.write(fd, line)
    finally:
        os.close(fd)
except OSError as exc:
    raise OSError(f"Failed to write event to {jsonl_path}: {exc}") from exc
```

No new imports needed (`os` already imported).

---

## 2. Thread List Unread + Reply Count

**Files:** `revspec/overlays.py` (ThreadListScreen), `revspec/app.py` (caller)

**Problem:** Thread list shows status icon + line number + first message preview, but no reply count or unread indicator. Users with 10+ threads can't distinguish handled vs. new without opening each one.

**Changes:**

### a) `overlays.py` — Accept `unread_ids` parameter

Add `unread_ids: set[str] | None = None` to `ThreadListScreen.__init__()`, store as `self._unread_ids`.

### b) `overlays.py` — Update `_render_item()`

Use `is_unread = t.id in self._unread_ids` for color. After the line number, append:
- Reply count: `(N)` in dim text when replies > 0
- Unread marker: `*` in bold yellow when unread

```python
replies = len(t.messages) - 1
# after line_str:
if replies > 0:
    text.append(f" ({replies})", Style(color=THEME["text_dim"]))
if is_unread:
    text.append(" *", Style(color=THEME["yellow"], bold=True))
```

### c) `app.py` — Pass unread IDs

At the `ThreadListScreen` constructor call (line 675):
```python
screen = ThreadListScreen(self.state.threads, on_resolve=on_resolve, unread_ids=set(self.state._unread_thread_ids))
```

Pass a copy via `set(...)` to avoid mutation.

---

## 3. Markdown in AI Popup Messages

**File:** `revspec/comment_screen.py` — `_render_message()`

**Problem:** AI replies render as plain text. AI responses often contain `**bold**`, `` `code` ``, links, etc. The `parse_inline_markdown()` function already exists in `markdown.py` and `append_inline_styled()` in `renderer.py`.

**Changes:**

### a) Add import
```python
from .renderer import append_inline_styled
```

### b) Replace line 180
```python
# Current:
text.append(msg.text, Style(color=THEME["text"]))

# New:
append_inline_styled(text, msg.text, Style(color=THEME["text"]))
```

The `_INLINE_MD_RE` regex uses `.+?` which doesn't match newlines, so multi-line messages work correctly — markdown spans within each line are styled, newlines pass through as-is.

---

## 4. Log Malformed JSONL to stderr

**File:** `revspec/protocol.py` — `read_events()`

**Problem:** Corrupt/invalid JSONL lines are silently swallowed (`except: pass`). When a user reports "my comment disappeared," there is zero diagnostic trail.

**Changes:**

### a) Add import
```python
import sys
```

### b) Replace silent exception handling (lines 113-118)

```python
# Current:
try:
    obj = json.loads(line)
    if is_valid_event(obj):
        events.append(parse_event(obj))
except (json.JSONDecodeError, KeyError):
    pass

# New:
try:
    obj = json.loads(line)
    if is_valid_event(obj):
        events.append(parse_event(obj))
    else:
        print(f"revspec: skipping invalid event: {line[:200]}", file=sys.stderr)
except (json.JSONDecodeError, KeyError) as exc:
    print(f"revspec: malformed JSONL line: {line[:200]} ({exc})", file=sys.stderr)
```

Truncates raw line to 200 chars to avoid flooding stderr. Zero behavioral change for happy path.

---

## Summary

| # | Change | File(s) | Risk |
|---|--------|---------|------|
| 1 | Atomic JSONL writes | `protocol.py` | Low — same observable behavior, stronger guarantees |
| 2 | Thread list unread + reply count | `overlays.py`, `app.py` | Low — additive display, no behavior change |
| 3 | Markdown in AI messages | `comment_screen.py` | Low — uses existing `append_inline_styled`, additive |
| 4 | Log malformed JSONL | `protocol.py` | Low — stderr only, no behavior change |

All 4 changes are independent and can be tested/shipped individually.
