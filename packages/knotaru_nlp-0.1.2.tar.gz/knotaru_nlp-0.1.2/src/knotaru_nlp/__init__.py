"""
knotaru-nlp: Modular NLP primitives for Knotaru.

Modules:
  knotaru_nlp.embedding  — text → vector conversion
  knotaru_nlp.indexing   — vector store / ANN search
  knotaru_nlp.chat       — LLM completions
  knotaru_nlp.extractor  — generic single-turn LLM extraction
"""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = "0.1.0"
