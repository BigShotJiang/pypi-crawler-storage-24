"""Sliding-window compressor — truncates older messages without LLM calls."""

from __future__ import annotations

import logging

from ..chat.classes.messaging import History, MessageRoleEnum
from .base import BaseCompressor
from .tokens import count_history_tokens
from .types import BudgetConfig, CompressionResult, CompressionStats, SlidingWindowConfig

logger = logging.getLogger(__name__)


class SlidingWindowCompressor(BaseCompressor):
    """Compresses a history by discarding the oldest non-system messages.

    No LLM call is made.  Older messages are simply dropped once the
    conversation exceeds :attr:`~SlidingWindowConfig.budget.max_messages`.

    When :attr:`~SlidingWindowConfig.preserve_system` is ``True`` (default),
    system-role messages are always retained and do not count against the
    budget window — only the most-recent non-system messages are evaluated.

    Args:
        config: Strategy configuration.

    Example::

        from knotaru_nlp.compression import SlidingWindowCompressor, SlidingWindowConfig, BudgetConfig

        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=10))
        )

        result = await compressor.compress(long_history)
        print(result.stats)  # CompressionStats(original_count=30, compressed_count=10, ...)

        # Check how much budget has been consumed:
        usage = compressor.budget_usage(long_history)
        print(usage.pct_messages_used)  # e.g. 3.0 (300% — well over budget)
    """

    def __init__(self, config: SlidingWindowConfig | None = None) -> None:
        self._config = config or SlidingWindowConfig()

    # ------------------------------------------------------------------ #
    # BaseCompressor implementation                                        #
    # ------------------------------------------------------------------ #

    @property
    def budget(self) -> BudgetConfig:
        return self._config.budget

    async def compress(self, history: History, *, force: bool = False) -> CompressionResult:
        """Truncate *history* to the configured window.

        System messages are extracted and prepended unconditionally when
        :attr:`~SlidingWindowConfig.preserve_system` is ``True``.

        Args:
            history: Conversation to (potentially) truncate.
            force: When ``True``, truncation is applied even if the history is
                within budget.

        Returns:
            A :class:`~knotaru_nlp.compression.CompressionResult` where
            ``history`` contains at most
            ``config.budget.max_messages`` non-system messages (plus all
            system messages when ``preserve_system=True``).
        """
        original_count = len(history)
        budget = self._config.budget

        original_tokens = (
            count_history_tokens(history, budget.model) if budget.max_tokens is not None else None
        )

        if not force and not self.needs_compression(history, budget):
            logger.debug(
                "sliding_window: no compression needed count=%d budget=%d",
                original_count,
                budget.max_messages,
            )
            return CompressionResult(
                history=list(history),
                stats=CompressionStats(
                    original_count=original_count,
                    compressed_count=original_count,
                    messages_dropped=0,
                    was_summarized=False,
                    original_tokens=original_tokens,
                    compressed_tokens=original_tokens,
                ),
            )

        if self._config.preserve_system:
            system_msgs = [m for m in history if m.role == MessageRoleEnum.SYSTEM.value]
            turns = [m for m in history if m.role != MessageRoleEnum.SYSTEM.value]
        else:
            system_msgs = []
            turns = list(history)

        kept_turns = turns[-budget.max_messages :]
        result = system_msgs + kept_turns
        dropped = original_count - len(result)

        compressed_tokens = (
            count_history_tokens(result, budget.model) if budget.max_tokens is not None else None
        )

        logger.debug(
            "sliding_window: compressed count=%d → %d (dropped=%d)",
            original_count,
            len(result),
            dropped,
        )

        return CompressionResult(
            history=result,
            stats=CompressionStats(
                original_count=original_count,
                compressed_count=len(result),
                messages_dropped=dropped,
                was_summarized=False,
                original_tokens=original_tokens,
                compressed_tokens=compressed_tokens,
            ),
        )
