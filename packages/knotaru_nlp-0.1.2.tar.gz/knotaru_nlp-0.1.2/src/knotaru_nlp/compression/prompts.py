"""Prompt templates for the compression module.

Internal — import :data:`DEFAULT_SUMMARY_PROMPT` rather than this module
directly unless you need to customise the template.
"""

from __future__ import annotations

from ..chat.prompt import Prompt, PromptInput


# ---------------------------------------------------------------------------
# Default summary prompt
# ---------------------------------------------------------------------------

DEFAULT_SUMMARY_PROMPT = Prompt(
    """\
        You are a conversation summarizer.

        Produce a concise but complete factual summary of the conversation below.
        Preserve all of the following: decisions made, facts stated by the user,
        user intent, assistant commitments, and any context that would be needed
        to continue the conversation coherently.

        Output plain prose only — no bullet points, no headers, no meta-commentary.
        Write as if briefing a new participant who is about to take over mid-conversation.

        Conversation:
        {conversation}\
    """,
    inputs=[
        PromptInput(
            key="conversation",
            required=True,
            description="The formatted conversation text to summarize.",
        )
    ],
)
