"""Optional tiktoken-backed token counter for budget enforcement."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...chat.utils import extract_text

if TYPE_CHECKING:
    from ...chat.classes.messaging import History

try:
    import tiktoken  # noqa: F401

    _TIKTOKEN_AVAILABLE = True
except ImportError:
    _TIKTOKEN_AVAILABLE = False


def count_tokens(text: str, model: str = "gpt-4o-mini") -> int:
    """Count tokens in *text* for *model*.

    Requires ``tiktoken``; install with::

        pip install knotaru-nlp[compression-tokens]

    Args:
        text: The string to count tokens for.
        model: Model name used to select the correct encoding.  Falls back to
            ``cl100k_base`` when the model is not recognised by tiktoken.

    Raises:
        ImportError: When ``tiktoken`` is not installed.
    """
    if not _TIKTOKEN_AVAILABLE:
        raise ImportError(
            "Token counting requires tiktoken. "
            "Install it with: pip install knotaru-nlp[compression-tokens]"
        )
    import tiktoken

    try:
        enc = tiktoken.encoding_for_model(model)
    except KeyError:
        enc = tiktoken.get_encoding("cl100k_base")
    return len(enc.encode(text))


def count_history_tokens(history: "History", model: str = "gpt-4o-mini") -> int:
    """Sum token counts across all messages in *history*.

    Args:
        history: Conversation to measure.
        model: Model name forwarded to :func:`count_tokens`.

    Raises:
        ImportError: When ``tiktoken`` is not installed.
    """
    return sum(count_tokens(extract_text(m.content), model) for m in history)
