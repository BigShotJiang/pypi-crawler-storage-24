"""Abstract base class for all compression strategies."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..chat.classes.messaging import History
from .tokens import count_history_tokens
from .types import BudgetConfig, BudgetUsage, CompressionResult


class BaseCompressor(ABC):
    """Provider-agnostic interface for chat history compression.

    Concrete implementations reduce a :data:`~knotaru_nlp.chat.History` that
    has grown beyond a :class:`~knotaru_nlp.compression.BudgetConfig` threshold
    into a shorter one that fits within the allowed budget.

    Usage::

        compressor = SlidingWindowCompressor(SlidingWindowConfig(budget=BudgetConfig(max_messages=10)))

        result = await compressor.compress(long_history)
        # result.history has at most 10 non-system messages
        # result.stats describes what was dropped

        # Check usage before sending to the LLM:
        usage = compressor.budget_usage(history)
        # BudgetUsage(used_messages=14, max_messages=10, pct_messages_used=1.4, needs_compression=True)
    """

    # ------------------------------------------------------------------ #
    # Abstract interface                                                   #
    # ------------------------------------------------------------------ #

    @property
    @abstractmethod
    def budget(self) -> BudgetConfig:
        """The active budget configuration for this compressor."""
        ...

    @abstractmethod
    async def compress(self, history: History, *, force: bool = False) -> CompressionResult:
        """Compress *history* and return the result.

        Implementations that do not need to compress (i.e. the history is
        already within budget and ``force`` is ``False``) **must** still return
        a :class:`CompressionResult` with ``stats.messages_dropped == 0`` and
        ``stats.was_summarized == False``.

        Args:
            history: The full conversation to (potentially) compress.
            force: When ``True``, compression is applied unconditionally even
                if the history is within budget.  Useful for proactive context
                reduction before sending to an LLM.

        Returns:
            A :class:`~knotaru_nlp.compression.CompressionResult` containing the
            compressed history and accompanying statistics.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------ #
    # Shared helpers                                                       #
    # ------------------------------------------------------------------ #

    def needs_compression(self, history: History, budget: BudgetConfig) -> bool:
        """Return ``True`` if *history* exceeds any configured budget threshold.

        Checks both the message count and, when :attr:`~BudgetConfig.max_tokens`
        is configured, the total token count via ``tiktoken``.

        Args:
            history: Conversation to evaluate.
            budget: Configured thresholds.

        Returns:
            ``True`` when the history exceeds the message budget *or* the token
            budget (if set).
        """
        if len(history) > budget.max_messages:
            return True
        if budget.max_tokens is not None:
            used = count_history_tokens(history, budget.model)
            if used > budget.max_tokens:
                return True
        return False

    def budget_usage(self, history: History) -> BudgetUsage:
        """Return a snapshot of current budget consumption for *history*.

        Token fields are populated only when
        :attr:`~BudgetConfig.max_tokens` is configured.  Requires ``tiktoken``
        in that case (install with ``[compression-tokens]`` extra).

        Args:
            history: Conversation to measure.

        Returns:
            A :class:`~knotaru_nlp.compression.BudgetUsage` model ready to
            serialise or pass to a rendering layer.
        """
        cfg = self.budget
        used_msgs = len(history)
        pct_msgs = used_msgs / cfg.max_messages if cfg.max_messages > 0 else 0.0

        used_tokens: int | None = None
        pct_tokens: float | None = None
        if cfg.max_tokens is not None:
            used_tokens = count_history_tokens(history, cfg.model)
            pct_tokens = used_tokens / cfg.max_tokens if cfg.max_tokens > 0 else 0.0

        return BudgetUsage(
            used_messages=used_msgs,
            max_messages=cfg.max_messages,
            pct_messages_used=pct_msgs,
            used_tokens=used_tokens,
            max_tokens=cfg.max_tokens,
            pct_tokens_used=pct_tokens,
            needs_compression=self.needs_compression(history, cfg),
        )
