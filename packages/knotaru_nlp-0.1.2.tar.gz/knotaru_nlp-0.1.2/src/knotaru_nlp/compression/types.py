"""Configuration and result types for the compression module."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from ..chat.classes.messaging import History
from ..chat.prompt import Prompt


# ---------------------------------------------------------------------------
# Budget
# ---------------------------------------------------------------------------


class BudgetConfig(BaseModel):
    """Compression trigger configuration.

    Args:
        max_messages: Maximum number of messages allowed in a history before
            compression is applied.
        max_tokens: Maximum total token count before compression is applied.
            ``None`` disables token budgeting.  Requires ``tiktoken`` when set
            (install with ``pip install knotaru-nlp[compression-tokens]``).
        model: Model name passed to ``tiktoken`` for encoding selection.  Only
            relevant when ``max_tokens`` is set.  Falls back to
            ``cl100k_base`` for unknown models.
    """

    max_messages: int = 20
    max_tokens: int | None = None
    model: str = "gpt-4o-mini"


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------


class CompressionStats(BaseModel):
    """Metrics recorded during a single compression pass."""

    original_count: int
    compressed_count: int
    messages_dropped: int
    was_summarized: bool
    original_tokens: int | None = None
    compressed_tokens: int | None = None


class CompressionResult(BaseModel):
    """Output of a single compression pass.

    Args:
        history: The compressed conversation ready to send to an LLM.
        stats: Before/after message counts and processing flags.
        summary: The LLM-generated prose summary, populated only when
            :class:`~knotaru_nlp.compression.SummarizeCompressor` performed
            summarization.  ``None`` otherwise.
    """

    history: History
    stats: CompressionStats
    summary: str | None = None


# ---------------------------------------------------------------------------
# Budget usage snapshot
# ---------------------------------------------------------------------------


class BudgetUsage(BaseModel):
    """Current budget consumption for a conversation history.

    All fields are ready to be serialised and rendered by the caller (web UI,
    notebook, dashboard, etc.).  ``pct_*`` fields may exceed ``1.0`` when the
    history is already over budget.

    Token fields are ``None`` when :attr:`~BudgetConfig.max_tokens` is not
    configured.

    Args:
        used_messages: Number of messages currently in the history.
        max_messages: Configured message budget.
        pct_messages_used: ``used_messages / max_messages`` (0.0 – 1.0+).
        used_tokens: Total token count across all messages, or ``None``.
        max_tokens: Configured token budget, or ``None``.
        pct_tokens_used: ``used_tokens / max_tokens`` (0.0 – 1.0+), or ``None``.
        needs_compression: Whether the history currently exceeds any configured
            budget threshold.
    """

    used_messages: int
    max_messages: int
    pct_messages_used: float
    used_tokens: int | None = None
    max_tokens: int | None = None
    pct_tokens_used: float | None = None
    needs_compression: bool


# ---------------------------------------------------------------------------
# Strategy configs
# ---------------------------------------------------------------------------


class SlidingWindowConfig(BaseModel):
    """Configuration for :class:`~knotaru_nlp.compression.SlidingWindowCompressor`.

    Args:
        budget: Trigger thresholds for compression.
        preserve_system: When ``True`` (default) all system-role messages are
            kept unconditionally; they do not consume slots in the budget window.
    """

    budget: BudgetConfig = Field(default_factory=BudgetConfig)
    preserve_system: bool = Field(default=True)


class SummarizeConfig(BaseModel):
    """Configuration for :class:`~knotaru_nlp.compression.SummarizeCompressor`.

    Args:
        budget: Trigger thresholds for compression.
        recent_window: Number of most-recent non-system messages to retain
            verbatim after the older portion has been summarized into a single
            system message.
        preserve_system: When ``True`` (default) all system-role messages from
            the original history are always kept in the output.
        summary_prompt: Prompt used to generate the conversation summary.
            A :class:`~knotaru_nlp.chat.Prompt` instance is rendered with the
            variable ``{"conversation": <formatted_text>}``.  Defaults to
            :data:`~knotaru_nlp.compression.prompts.DEFAULT_SUMMARY_PROMPT`.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    budget: BudgetConfig = Field(default_factory=BudgetConfig)
    recent_window: int | None = 10
    preserve_system: bool = Field(default=True)
    summary_prompt: str | Prompt | None = Field(
        default=None,
        description="None uses DEFAULT_SUMMARY_PROMPT from the prompts module.",
    )
