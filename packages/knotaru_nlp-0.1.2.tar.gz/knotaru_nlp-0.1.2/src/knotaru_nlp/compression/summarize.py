"""LLM-based summarization compressor."""

from __future__ import annotations

import logging

from ..chat.base import ChatClient
from ..chat.classes.messaging import History, Message, MessageRoleEnum
from ..chat.prompt import Prompt
from ..chat.utils import extract_text
from .tokens import count_history_tokens
from .base import BaseCompressor
from .prompts import DEFAULT_SUMMARY_PROMPT
from .sliding_window import SlidingWindowCompressor, SlidingWindowConfig
from .types import BudgetConfig, CompressionResult, CompressionStats, SummarizeConfig

logger = logging.getLogger(__name__)

# Stable IDs used for internally-generated messages (within valid 3-50 char range).
_SYSTEM_MSG_ID = "__compress_system__"
_SUMMARY_MSG_ID = "__compress_summary__"


class SummarizeCompressor(BaseCompressor):
    """Compresses a history via LLM summarization of older messages.

    When the history exceeds the configured budget, messages are split into
    two windows:

    1. **To summarize** — everything except the *N* most-recent non-system
       messages.  These are formatted and sent to the LLM as a single prompt.
    2. **To keep** — the *N* most-recent non-system messages, retained verbatim.

    The LLM response is injected back as a ``system``-role message prefixed
    with ``"[Conversation Summary]"`` so it is clearly distinguished from
    original system instructions.  When :attr:`~SummarizeConfig.preserve_system`
    is ``True`` (default), the original system messages from the history are
    prepended before the summary.

    If the LLM call fails for any reason the compressor falls back silently to
    sliding-window truncation and logs a warning.

    Args:
        chat: Chat client used to call the LLM.
        config: Strategy configuration.

    Example::

        from knotaru_nlp.compression import SummarizeCompressor, SummarizeConfig, BudgetConfig
        from knotaru_nlp.chat import OpenAIChatClient

        client = OpenAIChatClient(api_key="...", model="gpt-4o-mini")
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=20),
                recent_window=8,
            ),
        )

        result = await compressor.compress(long_history)
        print(result.summary)   # The generated prose summary
        print(result.stats)     # CompressionStats(was_summarized=True, ...)
    """

    def __init__(
        self,
        chat: ChatClient,
        config: SummarizeConfig | None = None,
    ) -> None:
        self._chat = chat
        self._config = config or SummarizeConfig()
        self._prompt: str | Prompt = self._config.summary_prompt or DEFAULT_SUMMARY_PROMPT
        logger.debug(
            "SummarizeCompressor initialised chat=%s budget=%d recent_window=%d",
            type(chat).__name__,
            self._config.budget.max_messages,
            self._config.recent_window,
        )

    # ------------------------------------------------------------------ #
    # BaseCompressor implementation                                        #
    # ------------------------------------------------------------------ #

    @property
    def budget(self) -> BudgetConfig:
        return self._config.budget

    async def compress(self, history: History, *, force: bool = False) -> CompressionResult:
        """Summarize the older portion of *history* and keep recent messages.

        Args:
            history: Conversation to compress.
            force: When ``True``, summarization is attempted even if the history
                is within budget.

        Returns:
            A :class:`~knotaru_nlp.compression.CompressionResult` whose
            ``history`` is composed of: original system messages (if
            ``preserve_system=True``) + one summary system message + the
            ``recent_window`` most-recent non-system messages.

            ``stats.was_summarized`` is ``True`` only when the LLM call
            succeeded; a fallback to sliding-window sets it to ``False``.
        """
        original_count = len(history)
        budget = self._config.budget

        original_tokens = (
            count_history_tokens(history, budget.model) if budget.max_tokens is not None else None
        )

        if not force and not self.needs_compression(history, budget):
            logger.debug(
                "summarize: no compression needed count=%d budget=%d",
                original_count,
                budget.max_messages,
            )
            return CompressionResult(
                history=list(history),
                stats=CompressionStats(
                    original_count=original_count,
                    compressed_count=original_count,
                    messages_dropped=0,
                    was_summarized=False,
                    original_tokens=original_tokens,
                    compressed_tokens=original_tokens,
                ),
            )

        system_msgs: list[Message] = (
            [m for m in history if m.role == MessageRoleEnum.SYSTEM.value]
            if self._config.preserve_system
            else []
        )
        turns = [m for m in history if m.role != MessageRoleEnum.SYSTEM.value]

        recent_window = self._config.recent_window
        if recent_window is None:
            # No verbatim window — summarize all turns.
            to_summarize = turns
            to_keep: list[Message] = []
        elif recent_window >= len(turns):
            # Nothing older than the window to summarize — fall back to sliding window.
            logger.debug(
                "summarize: recent_window=%d >= turns=%d, falling back to sliding window",
                recent_window,
                len(turns),
            )
            return await self._sliding_fallback(history, force=force)
        else:
            to_summarize = turns[:-recent_window]
            to_keep = turns[-recent_window:]

        summary_text = await self._call_llm(to_summarize)
        if summary_text is None:
            # LLM failure — fall back to sliding window, warning already logged.
            logger.debug("summarize: LLM call failed, falling back to sliding window")
            return await self._sliding_fallback(history, force=force)

        summary_msg = Message(
            message_id=_SUMMARY_MSG_ID,
            role=MessageRoleEnum.SYSTEM.value,
            content=f"[Conversation Summary]\n{summary_text}",
        )

        result = system_msgs + [summary_msg] + to_keep
        dropped = original_count - len(result)

        compressed_tokens = (
            count_history_tokens(result, budget.model) if budget.max_tokens is not None else None
        )

        logger.debug(
            "summarize: compressed count=%d → %d (dropped=%d, summarized=True)",
            original_count,
            len(result),
            dropped,
        )

        return CompressionResult(
            history=result,
            stats=CompressionStats(
                original_count=original_count,
                compressed_count=len(result),
                messages_dropped=dropped,
                was_summarized=True,
                original_tokens=original_tokens,
                compressed_tokens=compressed_tokens,
            ),
            summary=summary_text,
        )

    # ------------------------------------------------------------------ #
    # Private helpers                                                      #
    # ------------------------------------------------------------------ #

    async def _call_llm(self, messages: History) -> str | None:
        """Format *messages* and ask the LLM to summarize them.

        Returns the summary string, or ``None`` on any failure.
        """
        formatted = "\n".join(m.format() for m in messages)

        if isinstance(self._prompt, Prompt):
            rendered = self._prompt.format({"conversation": formatted})
        else:
            rendered = self._prompt.format_map({"conversation": formatted})

        try:
            response = await self._chat.chat(
                [
                    Message(
                        message_id=_SYSTEM_MSG_ID,
                        role=MessageRoleEnum.SYSTEM.value,
                        content=rendered,
                    )
                ]
            )
            return extract_text(response)
        except Exception as exc:
            logger.warning(
                "summarize: LLM call failed, falling back to sliding window: %s", exc
            )
            return None

    async def _sliding_fallback(self, history: History, *, force: bool = False) -> CompressionResult:
        """Delegate to SlidingWindowCompressor with the same budget and preserve_system settings."""
        return await SlidingWindowCompressor(
            SlidingWindowConfig(
                budget=self._config.budget,
                preserve_system=self._config.preserve_system,
            )
        ).compress(history, force=force)


