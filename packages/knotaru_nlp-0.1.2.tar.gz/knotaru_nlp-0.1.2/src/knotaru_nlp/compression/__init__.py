"""Chat history compression for knotaru-nlp.

Provides two concrete strategies that both implement
:class:`~knotaru_nlp.compression.BaseCompressor`:

* :class:`SlidingWindowCompressor` — pure algorithmic truncation, no LLM required.
* :class:`SummarizeCompressor` — LLM-based summarization of older messages with
  verbatim retention of the most-recent window; falls back to sliding-window
  truncation if the LLM call fails.

Quick start::

    from knotaru_nlp.compression import (
        SlidingWindowCompressor, SlidingWindowConfig,
        SummarizeCompressor, SummarizeConfig,
        BudgetConfig,
    )

    # No LLM needed:
    sw = SlidingWindowCompressor(SlidingWindowConfig(budget=BudgetConfig(max_messages=10)))
    result = await sw.compress(history)

    # LLM summarization:
    sm = SummarizeCompressor(chat=client, config=SummarizeConfig(recent_window=6))
    result = await sm.compress(history)
    print(result.summary)   # generated prose
    print(result.stats)     # CompressionStats(was_summarized=True, ...)
"""

from __future__ import annotations

from .base import BaseCompressor
from .prompts import DEFAULT_SUMMARY_PROMPT
from .sliding_window import SlidingWindowCompressor
from .summarize import SummarizeCompressor
from .types import (
    BudgetConfig,
    BudgetUsage,
    CompressionResult,
    CompressionStats,
    SlidingWindowConfig,
    SummarizeConfig,
)

__all__ = [
    # Abstract base
    "BaseCompressor",
    # Concrete strategies
    "SlidingWindowCompressor",
    "SummarizeCompressor",
    # Config models
    "BudgetConfig",
    "SlidingWindowConfig",
    "SummarizeConfig",
    # Result models
    "BudgetUsage",
    "CompressionResult",
    "CompressionStats",
    # Prompts
    "DEFAULT_SUMMARY_PROMPT",
]
