"""Milvus vector index implementation."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from ..filters import BaseFilter, FieldFilter, FilterOp, FilterConditionEnum
from .base import BaseIndex, IndexRecord, IndexRecordDB, IndexRecordInfo, SearchResult

logger = logging.getLogger(__name__)


class MilvusIndex(BaseIndex):
    """Vector index backed by Milvus / Zilliz.

    Creates the collection on first use if it doesn't already exist.

    Args:
        dim: Vector dimensionality.
        collection_name: Milvus collection to use.
        uri: Milvus connection URI (e.g. ``"http://localhost:19530"``).
        token: API token for Zilliz Cloud (optional for self-hosted).
        metric_type: Distance metric — ``"COSINE"`` or ``"IP"`` (inner product).
        index_type: ANN index type (``"IVF_FLAT"``, ``"HNSW"``, etc.).

    Example::

        index = MilvusIndex(
            dim=1536,
            collection_name="knotaru_documents",
            uri="http://localhost:19530",
        )
        await index.upsert([IndexRecord(id="1", vector=[...], text="Hello")])
        results = await index.search(query_vec, top_k=5)

    Filtering::

        from knotaru_nlp.filters import BaseFilter, FieldFilter, FilterOp

        results = await index.search(
            query_vec,
            top_k=5,
            filter=BaseFilter(
                metadata=[
                    FieldFilter(field="topic", op=FilterOp.IN, value=["finance"]),
                    FieldFilter(field="importance", op=FilterOp.GTE, value=3),
                ],
                logic=FilterConditionEnum.AND.value,
            ),
        )
    """

    def __init__(
        self,
        dim: int,
        collection_name: str,
        *,
        client: Any | None = None,
        uri: str = "http://localhost:19530",
        token: str | None = None,
        metric_type: str = "COSINE",
        index_type: str = "IVF_FLAT",
    ) -> None:
        self._dim = dim
        self._collection_name = collection_name
        self._metric_type = metric_type
        self._index_type = index_type
        self._initialized = False

        if client is not None:
            try:
                from pymilvus import AsyncMilvusClient
                if not isinstance(client, AsyncMilvusClient):
                    raise TypeError(
                        f"client must be an AsyncMilvusClient, got {type(client).__name__}"
                    )
            except ImportError:
                pass  # pymilvus not installed; trust the caller
            self._client = client
        else:
            try:
                from pymilvus import AsyncMilvusClient
            except ImportError as e:
                raise ImportError(
                    "pymilvus is required for MilvusIndex. "
                    "Install with: pip install 'knotaru-nlp[indexing]'"
                ) from e

            connect_kwargs: dict[str, Any] = {"uri": uri}
            if token:
                connect_kwargs["token"] = token
            self._client = AsyncMilvusClient(**connect_kwargs)
        logger.debug("MilvusIndex initialized collection=%s dim=%d", collection_name, dim)

    # ------------------------------------------------------------------ #
    # BaseIndex interface                                                   #
    # ------------------------------------------------------------------ #

    @property
    def dim(self) -> int:
        return self._dim

    async def upsert(self, records: list[IndexRecord]) -> None:
        logger.debug("upsert records=%d collection=%s", len(records), self._collection_name)
        await self._ensure_collection()
        now = datetime.now(timezone.utc).isoformat()
        data = [
            IndexRecordDB(
                id=r.id,
                vector=r.vector,
                text=r.text,
                properties=r.properties,
                info=IndexRecordInfo(indexed_at=now),
            ).model_dump()
            for r in records
        ]
        await self._client.upsert(collection_name=self._collection_name, data=data)

    async def search(
        self,
        vector: list[float],
        *,
        top_k: int = 10,
        filter: BaseFilter | None = None,
    ) -> list[SearchResult]:
        logger.debug("search top_k=%d filter=%s collection=%s", top_k, bool(filter), self._collection_name)
        await self._ensure_collection()

        filter_expr = self._build_filter_expr(filter) if filter and not filter.is_empty() else ""
        logger.debug("search filter_expr=%s", filter_expr)

        hits = await self._client.search(
            collection_name=self._collection_name,
            data=[vector],
            limit=top_k,
            filter=filter_expr,
            output_fields=["*"],
        )

        results: list[SearchResult] = []
        for hit in hits[0]:
            entity: dict[str, Any] = hit.get("entity", {})
            record = self._parse_get_item(entity)
            results.append(SearchResult(record=record, score=hit["distance"]))
        
        logger.debug("search completed results=%d", len(results))
        return results

    async def delete(self, ids: list[str]) -> None:
        await self._ensure_collection()
        await self._client.delete(collection_name=self._collection_name, ids=ids)

    async def get(self, id: str) -> IndexRecordDB | None:
        results = await self.get_many([id])
        return results[0] if results else None

    async def get_many(self, ids: list[str]) -> list[IndexRecordDB]:
        await self._ensure_collection()
        if not ids:
            return []
        res = await self._client.get(
            collection_name=self._collection_name,
            ids=ids,
            output_fields=["*"],
        )
        return [self._parse_get_item(item) for item in res]

    async def list_ids(self, filter: BaseFilter | None = None) -> list[str]:
        await self._ensure_collection()
        filter_expr = self._build_filter_expr(filter) if filter and not filter.is_empty() else ""
        res = await self._client.query(
            collection_name=self._collection_name,
            filter=filter_expr,
            output_fields=["id"],
            limit=16384,
        )
        return [item["id"] for item in res]

    async def reset(self) -> None:
        await self._ensure_collection()
        await self._client.drop_collection(self._collection_name)
        self._initialized = False

    # ------------------------------------------------------------------ #
    # Collection bootstrap                                                  #
    # ------------------------------------------------------------------ #

    async def _ensure_collection(self) -> None:
        if self._initialized:
            return

        from pymilvus import AsyncMilvusClient, DataType

        has = await self._client.has_collection(self._collection_name)
        if not has:
            logger.info("creating Milvus collection %s dim=%d", self._collection_name, self._dim)
            schema = AsyncMilvusClient.create_schema(auto_id=False, enable_dynamic_field=True)
            schema.add_field("id", DataType.VARCHAR, max_length=256, is_primary=True)
            schema.add_field("vector", DataType.FLOAT_VECTOR, dim=self._dim)
            schema.add_field("text", DataType.VARCHAR, max_length=65535)
            schema.add_field("properties", DataType.JSON)
            schema.add_field("info", DataType.JSON)

            index_params = AsyncMilvusClient.prepare_index_params()
            index_params.add_index(
                field_name="vector",
                index_type=self._index_type,
                metric_type=self._metric_type,
                params={"nlist": 128},
            )

            await self._client.create_collection(
                collection_name=self._collection_name,
                schema=schema,
                index_params=index_params,
            )

        self._initialized = True

    # ------------------------------------------------------------------ #
    # Filter translation                                                    #
    # ------------------------------------------------------------------ #

    def _build_filter_expr(self, filter: BaseFilter) -> str:
        """Translate a :class:`~knotaru_nlp.filters.BaseFilter` (or subclass) to a Milvus boolean expression.
        Handles arbitrarily nested :class:`~knotaru_nlp.filters.BaseFilter` groups
        """
        # Scope fields from MemoryFilter subclass — always ANDed at the top level
        # Each clause is a FieldFilter leaf or a nested BaseFilter group
        meta_parts: list[str] = [
            expr
            for clause in filter.metadata
            if (expr := self._clause_to_expr(clause))
        ]

        all_parts = list()
        if meta_parts:
            joiner = " and " if filter.logic == FilterConditionEnum.AND.value else " or "
            combined = joiner.join(meta_parts)
            all_parts.append(f"({combined})" if len(meta_parts) > 1 else combined)

        return " and ".join(all_parts)

    def _clause_to_expr(self, clause: FieldFilter | BaseFilter) -> str:
        """Dispatch a single clause to its Milvus expression string.

        A nested :class:`~knotaru_nlp.filters.BaseFilter` group is recursively
        expanded and wrapped in parentheses to preserve operator precedence.
        """
        if isinstance(clause, BaseFilter):
            inner = self._build_filter_expr(clause)
            return f"({inner})" if inner else ""
        return self._field_filter_to_expr(clause)

    @staticmethod
    def _field_filter_to_expr(f: FieldFilter) -> str:
        if "." in f.field:
            json_field, sub_key = f.field.split(".", 1)
            key = f'{json_field}["{sub_key}"]'
        else:
            key = f.field
        match f.op:
            case FilterOp.EQ:
                return f"{key} == {MilvusIndex._fmt_val(f.value)}"
            case FilterOp.NEQ:
                return f"{key} != {MilvusIndex._fmt_val(f.value)}"
            case FilterOp.IN:
                return f"{key} in {MilvusIndex._fmt_list(f.value)}"
            case FilterOp.NIN:
                return f"{key} not in {MilvusIndex._fmt_list(f.value)}"
            case FilterOp.CONTAINS_ANY:
                return f"any(x in {key} for x in {MilvusIndex._fmt_list(f.value)})"
            case FilterOp.GT:
                return f"{key} > {MilvusIndex._fmt_val(f.value)}"
            case FilterOp.GTE:
                return f"{key} >= {MilvusIndex._fmt_val(f.value)}"
            case FilterOp.LT:
                return f"{key} < {MilvusIndex._fmt_val(f.value)}"
            case FilterOp.LTE:
                return f"{key} <= {MilvusIndex._fmt_val(f.value)}"
            case _:
                return ""

    @staticmethod
    def _fmt_val(value: Any) -> str:
        if isinstance(value, str):
            escaped = value.replace('"', '\\"')
            return f'"{escaped}"'
        if isinstance(value, bool):
            return "true" if value else "false"
        return str(value)

    @staticmethod
    def _fmt_list(value: Any) -> str:
        items = value if isinstance(value, (list, tuple)) else [value]
        return "[" + ", ".join(MilvusIndex._fmt_val(v) for v in items) + "]"

    # ------------------------------------------------------------------ #
    # Parsing helpers                                                       #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _parse_get_item(item: dict[str, Any]) -> IndexRecordDB:
        """Parse a record returned by client.get() — fields are top-level."""
        return IndexRecordDB(
            id=item["id"],
            vector=item.get("vector", []),
            text=item.get("text", ""),
            properties=item.get("properties", {}),
            info=IndexRecordInfo(
                indexed_at=MilvusIndex._extract_indexed_at(item.get("info"))
            ),
        )

    @staticmethod
    def _extract_indexed_at(info: Any) -> str:
        if isinstance(info, dict):
            return info.get("indexed_at", datetime.now(timezone.utc).isoformat())
        return datetime.now(timezone.utc).isoformat()
