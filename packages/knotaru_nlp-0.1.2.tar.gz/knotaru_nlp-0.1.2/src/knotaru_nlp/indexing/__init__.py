"""Indexing module — vector store and ANN search.

Public API::

    from knotaru_nlp.indexing import BaseIndex, IndexRecord, SearchResult
    from knotaru_nlp.indexing import MilvusIndex    # production
"""

from .base import BaseIndex, IndexRecord, SearchResult
from .milvus import MilvusIndex

__all__ = [
    "BaseIndex",
    "IndexRecord",
    "SearchResult",
    "MilvusIndex",
]
