"""Abstract base class for vector index providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field

from ..filters import BaseFilter


class IndexRecordInfo(BaseModel):
    """Metadata about an indexed document, returned by :meth:`BaseIndex.get`."""

    indexed_at: str


class IndexRecord(BaseModel):
    """A document stored in the index."""

    id: str
    vector: list[float]
    text: str
    properties: dict[str, Any] = Field(default_factory=dict)


class IndexRecordDB(IndexRecord):
    """Internal record format used by the index implementation."""

    info: IndexRecordInfo

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dict for storage in the index."""
        return self.model_dump()


class SearchResult(BaseModel):
    """A single result from a similarity search."""

    record: IndexRecordDB
    score: float  # Higher is more similar (cosine similarity or inner product)


class BaseIndex(ABC):
    """Abstract vector index.

    Implementations wrap vector databases (Milvus, FAISS, pgvector, etc.)
    behind a uniform async interface.

    Usage::

        index = MyIndex(dim=1536, collection="docs")
        await index.upsert([IndexRecord(id="1", vector=[...], text="Hello")])
        results = await index.search(query_vector, top_k=5)

    Filtering::

        from knotaru_nlp.filters import BaseFilter, FieldFilter, FilterOp

        results = await index.search(
            query_vector,
            top_k=5,
            filter=BaseFilter(
                metadata=[FieldFilter(field="topic", op=FilterOp.IN, value=["news"])],
            ),
        )
    """

    @property
    @abstractmethod
    def dim(self) -> int:
        """Vector dimensionality expected by this index."""

    @abstractmethod
    async def upsert(self, records: list[IndexRecord]) -> None:
        """Insert or update records.

        Args:
            records: Records to upsert. Existing IDs are overwritten.
        """

    @abstractmethod
    async def search(
        self,
        vector: list[float],
        *,
        top_k: int = 10,
        filter: BaseFilter | None = None,
    ) -> list[SearchResult]:
        """Nearest-neighbour search.

        Args:
            vector: Query vector (must match :attr:`dim`).
            top_k: Number of results to return.
            filter: Optional :class:`~knotaru_nlp.filters.BaseFilter` (or subclass)
                to restrict results by metadata predicates.

        Returns:
            Up to *top_k* results ordered by descending similarity.
        """

    @abstractmethod
    async def delete(self, ids: list[str]) -> None:
        """Delete records by ID."""

    @abstractmethod
    async def get(self, id: str) -> IndexRecordDB | None:
        """Fetch a single record by ID. Returns ``None`` if not found."""

    @abstractmethod
    async def get_many(self, ids: list[str]) -> list[IndexRecordDB]:
        """Fetch multiple records by ID.

        Missing IDs are silently omitted from the result.

        Args:
            ids: Record IDs to fetch.

        Returns:
            Records found, in unspecified order.
        """

    @abstractmethod
    async def list_ids(self, filter: BaseFilter | None = None) -> list[str]:
        """Return all record IDs matching the given filter.

        Args:
            filter: Optional :class:`~knotaru_nlp.filters.BaseFilter` to restrict
                results by metadata predicates.  Pass ``None`` to list all records.

        Returns:
            List of matching record IDs.
        """

    @abstractmethod
    async def reset(self) -> None:
        """Reset by deleting the collection and recreating it."""
