"""Generic single-turn LLM extraction helper.

Decouples the "call the LLM, parse JSON, validate" pattern from any specific
domain so that it can be reused across modules (memory, graph, custom pipelines).

Public API::

    from knotaru_nlp.extractor import Extractor, ExtractorConfig

    class Names(BaseModel):
        names: list[str]

    config = ExtractorConfig(
        system_prompt='Return JSON {"names": [...]} of all people mentioned.',
        result_model=Names,
    )
    extractor = Extractor(chat=chat_client)
    result: Names | None = await extractor.run("Alice met Bob.", config)
"""

from __future__ import annotations

import logging
from typing import Any, TypeVar

from pydantic import BaseModel

from knotaru_common.json import safe_json_loads
from ..chat.base import ChatClient
from ..chat.classes.messaging import Message, MessageRoleEnum
from ..chat.prompt import Prompt
from ..chat.utils import extract_text
from .types import ExtractorConfig

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

# ---------------------------------------------------------------------------
# Extractor
# ---------------------------------------------------------------------------

class Extractor:
    """Single-turn LLM extraction helper.

    Combines a static system prompt with dynamic content, sends the combined
    message to the chat client, parses the JSON response, and optionally
    validates it against a Pydantic model.

    Args:
        chat: Chat client used to call the LLM.

    Example::

        extractor = Extractor(chat=chat_client)

        # Raw JSON — no validation
        data = await extractor.run(
            "Conversation:\\nuser: I work at Acme.\\n\\nJSON:",
            ExtractorConfig(system_prompt="Extract entities. Return JSON."),
        )

        # With Pydantic validation
        class Result(BaseModel):
            entities: list[str]

        result = await extractor.run(
            "user: I work at Acme.",
            ExtractorConfig(
                system_prompt="List entity names. Return JSON: {entities: [...]}",
                result_model=Result,
            ),
        )
    """

    def __init__(self, chat: ChatClient) -> None:
        self._chat = chat
        logger.debug("Extractor initialised chat=%s", type(chat).__name__)

    async def run(
        self,
        content: str,
        config: ExtractorConfig,
        values: dict[str, str] | None = None,
    ) -> Any:
        """Run a single-turn extraction.

        Builds a system message as ``config.system_prompt + "\\n\\n" + content``,
        calls the chat client, parses the JSON response, and optionally
        validates it against ``config.result_model``.

        Args:
            content: Dynamic content appended after the system prompt (e.g.
                the conversation text, a search query, or a document chunk).
            config: Extraction configuration — prompt and optional model.
            values: Optional variable values forwarded to
                :meth:`~knotaru_nlp.extraction.ExtractorConfig.format` before
                rendering the system prompt.  Use this to fill
                :class:`~knotaru_nlp.chat.Prompt` placeholders (e.g.
                ``{"user_context": "User is 'alice'."}``).  Has no effect when
                ``config.system_prompt`` is a plain string with no placeholders.

        Returns:
            A validated ``config.result_model`` instance when a model is set.
            Otherwise the raw parsed value (``dict`` or ``list``).
            Returns ``None`` on any failure: network error, non-JSON response,
            or Pydantic validation error.
        """
        if isinstance(config.system_prompt, Prompt):
            rendered_prompt = config.system_prompt.format(values)
        else:
            rendered_prompt = config.system_prompt.format_map(values or {}) if values else config.system_prompt
        
        message = Message(
            message_id="__extractor__",
            role=MessageRoleEnum.SYSTEM.value,
            content=f"{rendered_prompt}\n\n{content}",
        )

        call_kwargs: dict[str, Any] = {}
        if config.result_model is not None and config.structured_output:
            schema = config.result_model.model_json_schema()
            call_kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": config.result_model.__name__,
                    "schema": schema,
                },
            }
            logger.debug("extraction using structured output schema=%s", config.result_model.__name__)

        try:
            response = await self._chat.chat([message], **call_kwargs)
            raw = extract_text(response)
            data = safe_json_loads(raw, default=None)
        except Exception as exc:
            logger.warning("extraction call failed: %s", exc)
            return None

        if data is None:
            logger.warning("extraction returned non-JSON response")
            return None

        if config.result_model is not None:
            try:
                return config.result_model.model_validate(data)
            except Exception as exc:
                logger.warning(
                    "extraction result failed validation against %s: %s",
                    config.result_model.__name__,
                    exc,
                )
                return None

        return data



__all__ = ["Extractor", "ExtractorConfig"]
