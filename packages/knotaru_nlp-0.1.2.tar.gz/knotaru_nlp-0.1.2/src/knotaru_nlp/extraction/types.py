from __future__ import annotations

from typing import Union
from pydantic import BaseModel, ConfigDict

from ..chat.prompt import Prompt

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


class ExtractorConfig(BaseModel):
    """Configuration for a single extraction task.

    Args:
        system_prompt: LLM instructions — either a plain string or a
            :class:`~knotaru_nlp.chat.Prompt` template.  The dynamic
            ``content`` argument passed to :meth:`Extractor.run` is appended
            after two newlines, so the combined message is::

                {system_prompt}

                {content}

        result_model: Optional Pydantic model to validate the parsed JSON
            response against.  When provided, :meth:`Extractor.run` returns
            a validated model instance instead of a raw ``dict`` / ``list``.
            Validation errors are caught and logged; ``None`` is returned on
            failure.

    Example::

        from knotaru_nlp.chat import Prompt
        from knotaru_nlp.extraction import Extractor, ExtractorConfig
        from pydantic import BaseModel

        class Tags(BaseModel):
            tags: list[str]

        config = ExtractorConfig(
            system_prompt=Prompt(
                "Extract topic tags. Return JSON: {{\"tags\": [...]}}\\n\\n{user_context}",
                user_context="",
            ),
            result_model=Tags,
        )
        # Render with variables before calling:
        scoped = config.format(user_context="User is 'alice'.")
        result = await extractor.run("The Fed raised interest rates today.", scoped)
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    system_prompt: Union[str, Prompt]
    """LLM instructions — plain string or a :class:`~knotaru_nlp.chat.Prompt` template."""

    result_model: type[BaseModel] | None = None
    """If set, the parsed JSON is validated against this Pydantic model class."""

    structured_output: bool = True
    """When ``True`` (default) and ``result_model`` is set, the model's JSON
    schema is forwarded to the chat client as ``response_format``.  This
    constrains the LLM to emit valid JSON matching the schema before any
    Python-side validation runs.

    Set to ``False`` if your provider does not support ``response_format``
    (e.g. self-hosted models, older API versions).
    """

