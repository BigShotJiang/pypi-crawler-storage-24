"""Vector-index storage, search, and memory-record deduplication for MemoryIndex."""

from __future__ import annotations

import logging
from typing import Any, List

from ..chat.classes.messaging import History
from ..embedding.base import BaseEmbedder, EmbeddingResult
from ..extraction.extractor import Extractor
from .filters import MemoryFilter
from ..indexing.base import BaseIndex, IndexRecord, IndexRecordDB
from .prompts import DEDUP_LLM_CONFIG, DedupeResponse
from .types import (
    MemoryRecord, MemoryVectorSearchResult, MemoryDedupeConfig, MemoryDedupeScopeEnum
)

logger = logging.getLogger(__name__)


class _IndexStoreMixin:
    """Mixin providing vector-index storage, search, and memory-record deduplication.

    Expects the following attributes to be set by the host class (``MemoryIndex``):

    .. code-block:: python

        self._index: BaseIndex
        self._embedder: BaseEmbedder
        self._extractor: Extractor
    """

    # -- Attributes provided by the host class --------------------------------
    _index: BaseIndex
    _embedder: BaseEmbedder
    _extractor: Extractor

    # -- Cross-class stub: implemented by MemoryIndex -------------------------
    async def delete(self, ids: list[str]) -> None: ...  # noqa: D102

    # ------------------------------------------------------------------ #
    # Internal — memory record deduplication                              #
    # ------------------------------------------------------------------ #

    async def _dedup_scope(
        self,
        *,
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
    ) -> None:
        """Delete all existing records that share the same scope.

        Uses the most specific scope available: ``session_id`` is preferred
        over ``agent_id``, which is preferred over ``user_id``.
        """
        filter = MemoryFilter(agent_id=agent_id, session_id=session_id, user_id=user_id)
        if filter.is_empty():
            logger.debug("_dedup_scope skipped — no scope provided")
            return

        ids = await self._index.list_ids(filter.to_base_filter())
        if ids:
            logger.debug("_dedup_scope deleting %d existing records", len(ids))
            await self.delete(ids)

    async def _dedup_semantic(
        self,
        embeddings: List[EmbeddingResult],
        *,
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
        threshold: float,
    ) -> None:
        """Delete existing records that are semantically similar to the new embeddings.

        For each new embedding, searches the scoped index for records with a
        cosine similarity score >= *threshold* and deletes them before the new
        records are inserted.
        """
        scope_filter = MemoryFilter(agent_id=agent_id, session_id=session_id, user_id=user_id)
        if scope_filter.is_empty():
            logger.debug("_dedup_semantic skipped — no scope provided")
            return

        logger.debug("_dedup_semantic checking %d embeddings for near-duplicates", len(embeddings))

        base_filter = scope_filter.to_base_filter()
        ids_to_delete: set[str] = set()
        for emb in embeddings:
            hits = await self._index.search(emb.vector, top_k=50, filter=base_filter)
            logger.debug("_dedup_semantic found %d candidates for deletion with current embedding", len(hits))
            for hit in hits:
                if hit.score >= threshold:
                    ids_to_delete.add(hit.record.id)

        logger.debug("_dedup_semantic found %d near-duplicate records to delete", len(ids_to_delete))
        if ids_to_delete:
            await self.delete(list(ids_to_delete))

    async def _dedup_llm(
        self,
        new_texts: list[str],
        embeddings: List[EmbeddingResult],
        *,
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
        threshold: float,
    ) -> None:
        """Semantic search finds candidates; an LLM re-ranks and decides which to delete.

        For each new embedding the scoped index is searched for records above
        *threshold*.  All unique candidates are then presented to the LLM together
        with the new texts; the LLM returns the IDs it considers redundant or
        superseded and those records are deleted before the new ones are inserted.
        """
        scope_filter = MemoryFilter(agent_id=agent_id, session_id=session_id, user_id=user_id)
        if scope_filter.is_empty():
            logger.debug("_dedup_llm skipped — no scope provided")
            return

        logger.debug("_dedup_llm checking %d embeddings for candidates", len(embeddings))

        base_filter = scope_filter.to_base_filter()
        candidate_map: dict[str, str] = {}  # id -> text
        for emb in embeddings:
            hits = await self._index.search(emb.vector, top_k=50, filter=base_filter)
            for hit in hits:
                if hit.score >= threshold and hit.record.id not in candidate_map:
                    candidate_map[hit.record.id] = hit.record.text

        if not candidate_map:
            logger.debug("_dedup_llm found no candidates above threshold")
            return

        logger.debug("_dedup_llm presenting %d candidates to LLM", len(candidate_map))

        new_section = "\n".join(f"- {t}" for t in new_texts)
        existing_section = "\n".join(
            f"- ID={record_id}: {text}" for record_id, text in candidate_map.items()
        )
        content = (
            f"NEW ENTRIES (about to be stored):\n{new_section}\n\n"
            f"EXISTING ENTRIES (candidates for deletion):\n{existing_section}"
        )

        result = await self._extractor.run(content, DEDUP_LLM_CONFIG)
        if not isinstance(result, DedupeResponse) or not result.ids_to_delete:
            logger.debug("_dedup_llm LLM returned no IDs to delete")
            return

        # Guard against hallucinated IDs outside the candidate set.
        ids_to_delete = [i for i in result.ids_to_delete if i in candidate_map]
        logger.debug("_dedup_llm deleting %d records chosen by LLM", len(ids_to_delete))
        if ids_to_delete:
            await self.delete(ids_to_delete)

    async def _dedupe_memory(
        self,
        texts: list[str],
        embeddings: List[EmbeddingResult],
        *,
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
        memory_dedupe: MemoryDedupeConfig | None,
    ):
        if memory_dedupe is None or memory_dedupe.strategy == MemoryDedupeScopeEnum.NONE.value:
            logger.debug("_dedupe_memory skipped — strategy is 'none' or not provided")
            return
        
        if memory_dedupe and memory_dedupe.strategy == MemoryDedupeScopeEnum.SCOPE.value:
            await self._dedup_scope(
                agent_id=agent_id,
                session_id=None,  # Scope dedup ignores session boundaries.
                user_id=user_id,
            )
        elif memory_dedupe and memory_dedupe.strategy == MemoryDedupeScopeEnum.SEMANTIC.value:
            await self._dedup_semantic(
                embeddings,
                agent_id=agent_id,
                session_id=None,  # Semantic dedup ignores session boundaries.
                user_id=user_id,
                threshold=memory_dedupe.semantic_threshold,
            )
        elif memory_dedupe and memory_dedupe.strategy == MemoryDedupeScopeEnum.LLM.value:
            await self._dedup_llm(
                texts,
                embeddings,
                agent_id=agent_id,
                session_id=None,
                user_id=user_id,
                threshold=memory_dedupe.semantic_threshold,
            )

    # ------------------------------------------------------------------ #
    # Internal — index storage and search                                 #
    # ------------------------------------------------------------------ #

    async def _store_index(
        self,
        texts: list[str],
        messages: History,
        *,
        record_ids: list[str],
        embeddings: list[EmbeddingResult],
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
        extra_meta: dict[str, Any],
        extract_facts: bool,
    ) -> None:
        """Upsert pre-embedded *texts* into the vector index."""
        index_records: list[IndexRecord] = []
        for idx, (record_id, text, emb) in enumerate(zip(record_ids, texts, embeddings)):
            record_properties: dict[str, Any] = {**extra_meta}
            # Attach message-level fields only when storing raw messages (1:1 with messages list)
            if not extract_facts and idx < len(messages):
                record_properties["role"] = messages[idx].role
                record_properties["message_id"] = messages[idx].message_id
            if agent_id is not None:
                record_properties["agent_id"] = agent_id
            if session_id is not None:
                record_properties["session_id"] = session_id
            if user_id is not None:
                record_properties["user_id"] = user_id
            index_records.append(
                IndexRecord(id=record_id, vector=emb.vector, text=text, properties=record_properties)
            )
        await self._index.upsert(index_records)
        logger.debug("_store_index upserted %d records", len(index_records))

    async def _vector_search(
        self, query: str, *, filter: MemoryFilter | None, top_k: int
    ) -> dict[str, MemoryVectorSearchResult]:
        emb = await self._embedder.embed(query)
        hits = await self._index.search(
            emb.vector, top_k=top_k, filter=filter.to_base_filter() if filter else None
        )
        return {
            hit.record.id: MemoryVectorSearchResult(
                record=self._index_record_to_memory(hit.record),
                score=hit.score,
            )
            for hit in hits
        }

    def _index_record_to_memory(self, record: IndexRecordDB) -> MemoryRecord:
        """Convert an ``IndexRecordDB`` to a :class:`~.types.MemoryRecord`.

        Note: ``entities`` and ``relationships`` are always ``None`` here because
        they are stored in the graph, not the vector index.  Only :meth:`store`
        populates those fields on the records it returns.
        """
        properties: dict[str, Any] = record.properties or {}
        return MemoryRecord(
            id=record.id,
            text=record.text,
            agent_id=properties.get("agent_id"),
            session_id=properties.get("session_id"),
            user_id=properties.get("user_id"),
            metadata={k: v for k, v in properties.items() if k not in ("agent_id", "session_id", "user_id")},
            entities=None,
            relationships=None,
        )
