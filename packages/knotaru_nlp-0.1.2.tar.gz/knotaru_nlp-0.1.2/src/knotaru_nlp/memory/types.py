"""Core types for the memory system."""

from __future__ import annotations

from typing import Any, Literal, Optional, TypedDict
from enum import Enum
from pydantic import BaseModel, Field

from ..graph.types import Entity, Relationship, Direction

class MemoryEntityProperties(TypedDict, total=False):
    """Standardised properties baked into every memory-scoped entity.

    These are automatically added to the ``properties`` dict of each
    :class:`MemoryEntity` for easy access in graph backends, and can be used
    as filters in graph queries.
    """

    memory_record_ids: list[str]

class MemoryEntity(Entity):
    """A graph entity scoped to a memory context.

    Extends :class:`~knotaru_nlp.graph.types.Entity` with typed scope fields.
    Scope values are also automatically baked into ``properties`` so they
    travel with the entity through any backend that serialises ``properties``.

    Args:
        agent_id: Agent this entity belongs to.
        session_id: Session this entity was extracted from.
        user_id: User this entity belongs to.
        properties: Any additional scalar attributes.

    Example::

        entity = MemoryEntity(
            id="e1", name="Alice", type="Person",
            agent_id="agent-1", user_id="user-42",
            properties={"role": "engineer"},
        )
        assert entity.agent_id == "agent-1"
        assert entity.properties["agent_id"] == "agent-1"
        assert entity.properties["role"] == "engineer"
    """

    agent_id: str | None = None
    session_id: str | None = None
    user_id: str | None = None

    def to_entity(self) -> Entity:
        """Return a plain :class:`Entity` with scope baked into ``properties``.

        Use this when passing to graph backends that accept ``list[Entity]``
        to avoid list-invariance type errors.
        """
        props = {
            **self.properties,
            **{k: v for k, v in {
                "agent_id": self.agent_id,
                "session_id": self.session_id,
                "user_id": self.user_id,
            }.items() if v is not None},
        }
        return Entity(id=self.id, name=self.name, type=self.type, properties=props)


class MemoryRelationship(Relationship):
    """A graph relationship scoped to a memory context.

    Extends :class:`~knotaru_nlp.graph.types.Relationship` with typed scope
    fields.

    Args:
        agent_id: Agent this relationship belongs to.
        session_id: Session this relationship was extracted from.
        user_id: User this relationship belongs to.
    """

    agent_id: str | None = None
    session_id: str | None = None
    user_id: str | None = None

    def to_relationship(self) -> Relationship:
        """Return a plain :class:`Relationship` with scope baked into ``properties``.

        Use this when passing to graph backends that accept ``list[Relationship]``
        to avoid list-invariance type errors.
        """
        props = {
            **self.properties,
            **{k: v for k, v in {
                "agent_id": self.agent_id,
                "session_id": self.session_id,
                "user_id": self.user_id,
            }.items() if v is not None},
        }
        return Relationship(
            id=self.id,
            source_id=self.source_id,
            target_id=self.target_id,
            relation=self.relation,
            properties=props,
        )


class ExtractionResult(BaseModel):
    """Structured output from the LLM entity-extraction step.

    Args:
        entities: Extracted memory-scoped entity nodes.
        relationships: Extracted memory-scoped directed edges.
    """

    entities: list[MemoryEntity] = Field(default_factory=list)
    relationships: list[MemoryRelationship] = Field(default_factory=list)


class MemoryRecord(BaseModel):
    """A single stored memory unit.

    Each record corresponds to one vectorised text chunk (typically one
    conversation message).  It carries the scoping IDs, arbitrary metadata,
    and the graph elements extracted from it.

    Args:
        id: Unique record ID (matches the ``id`` stored in the vector index).
        text: The original text chunk that was embedded.
        agent_id: Agent this record belongs to.
        session_id: Session this record belongs to.
        user_id: User this record belongs to.
        metadata: Caller-supplied key-value metadata.
        entities: Memory-scoped graph entities extracted from this chunk.
        relationships: Memory-scoped graph relationships extracted from this chunk.
    """

    id: str
    text: str
    agent_id: str | None = None
    session_id: str | None = None
    user_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    entities: list[MemoryEntity] | None = Field(default_factory=list)
    relationships: list[MemoryRelationship] | None = Field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dict for API responses."""
        return self.model_dump()

class MemoryRelatedEntity(BaseModel):
    """A neighboring entity bundled with the relationship that connects it.

    Args:
        entity: The resolved neighboring entity node.
        relation: Semantic label of the connecting relationship (e.g. ``"works_at"``).
        direction: ``"outgoing"`` if the matched entity is the source, ``"incoming"`` if it is the target.
    """

    entity: MemoryEntity
    relation: str
    direction: Direction


class MemoryGraphSearchResult(BaseModel):
    """A single graph search result returned by a memory search operation.

    Args:
        entity: The matched entity node.
        relationships: Raw edges connected to this entity.
        related_entities: Neighboring entities resolved from relationships,
            each carrying the relation label and direction.
    """

    entity: MemoryEntity
    relationships: list[Relationship] = Field(default_factory=list)
    related_entities: list[MemoryRelatedEntity] = Field(default_factory=list)

class MemoryVectorSearchResult(BaseModel):
    """A single vector search result returned by a memory search operation.

    Args:
        record: The matched memory record, with all its metadata and extracted graph elements.
    """

    record: MemoryRecord
    score: float

class MemorySearchResult(BaseModel):
    """Result from a memory search operation.
    """

    graph_result: Optional[list[MemoryGraphSearchResult]] = Field(default_factory=list)
    vector_result: list[MemoryVectorSearchResult] = Field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

SearchMode = Literal["vector", "graph", "hybrid"]
class SearchModeEnum(str, Enum):
    """Which search pathway to use for a memory search operation."""

    VECTOR = "vector"
    GRAPH = "graph"
    HYBRID = "hybrid"


MemoryDedupeScope = Literal["none", "scope", "semantic", "llm"]
class MemoryDedupeScopeEnum(str, Enum):
    """Strategy for deduplicating overlapping results from vector and graph search.

    - ``"none"``: No deduplication — all results are returned as-is.
    - ``"scope"``: Records with matching IDs are considered duplicates and only the highest-scoring one is kept.
    - ``"semantic"``: Records with similar text (e.g. cosine similarity above a threshold) are considered duplicates and only the highest-scoring one is kept.  This is more expensive but can catch near-duplicates with different IDs.
    - ``"llm"``: Semantic search finds candidates; an LLM then re-ranks and decides which existing records to delete.  Most accurate but slowest.
    """

    NONE = "none"
    SCOPE = "scope"
    SEMANTIC = "semantic"
    LLM = "llm"

class MemoryDedupeConfig(BaseModel):
    """Configuration for deduplication of memory records during storage."""

    strategy: MemoryDedupeScope = MemoryDedupeScopeEnum.NONE.value
    semantic_threshold: float = 0.92  # Used only if strategy is "semantic"

class GraphUpdateConfig(BaseModel):
    """Configuration for graph-context-aware entity and relationship refinement.

    When supplied to ``MemoryIndex.store``, after initial extraction the system will:

    1. Search the graph for entities matching the newly extracted ones.
    2. Collect their 1-hop neighborhood (relationships + neighbor entities).
    3. Run a second LLM pass to correct entity names, resolve ambiguous references
       (e.g. ``"the company"`` → ``"Company X"`` via graph traversal), add implied
       relationships, and mark stale ones for deletion.

    Args:
        context_top_k: Maximum number of existing graph entities to surface per
            extracted entity when building the context window.
    """

    context_top_k: int = 5
    with_index_search: bool = True  # Whether to use the vector index for candidate retrieval in the graph update pass