"""Graph storage and search operations for MemoryIndex."""

from __future__ import annotations

import asyncio
import logging
import uuid

from knotaru_nlp.embedding.base import BaseEmbedder
from copy import deepcopy

from ..chat.classes.messaging import Message
from ..extraction.extractor import Extractor
from .filters import MemoryFilter
from ..graph.base import BaseGraph
from ..graph.types import Entity, GraphSearchResult, Relationship, DirectionEnum, Direction
from ..indexing.base import BaseIndex
from .prompts import (
    EXTRACTION_CONFIG, FACTS_EXTRACTION_CONFIG, QUERY_ENTITIES_CONFIG,
    GRAPH_REFINEMENT_CONFIG,
    ExtractionResponse, FactsResponse, QueryEntitiesResponse,
    GraphRefinementResponse,
)
from .types import (
    GraphUpdateConfig,
    ExtractionResult, MemoryEntity, MemoryEntityProperties,
    MemoryGraphSearchResult, MemoryRelatedEntity, MemoryRelationship,
)

logger = logging.getLogger(__name__)


class _GraphStoreMixin:
    """Mixin providing graph storage, search, and LLM entity/relationship extraction.

    Expects the following attributes to be set by the host class (``MemoryIndex``):

    .. code-block:: python

        self._graph_impl: BaseGraph | None
        self._extractor: Extractor
    """

    # -- Attributes provided by the host class --------------------------------
    _graph_impl: BaseGraph | None
    _extractor: Extractor
    _embedder: BaseEmbedder
    _entity_index: BaseIndex | None  # optional; when present, supplements graph name search with vector search

    # -- Graph property -------------------------------------------------------

    @property
    def _graph(self) -> BaseGraph:
        assert self._graph_impl is not None, "Graph backend is not configured (enable_graph=False)"
        return self._graph_impl

    # ------------------------------------------------------------------ #
    # Internal — graph storage                                            #
    # ------------------------------------------------------------------ #

    async def _store_graph(
        self,
        texts: list[str],
        *,
        record_ids: list[str],
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
        graph_update: GraphUpdateConfig | None = None,
    ) -> ExtractionResult:
        """Extract entities/relationships from *texts* and upsert them into the graph.

        When *graph_update* is provided the initial extraction is followed by a
        graph-context-aware LLM refinement pass that:

        - resolves ambiguous entity references via graph neighbourhood traversal
          (e.g. ``"the company"`` → ``"Company X"`` inferred through co-workers),
        - corrects entity names/types to match existing canonical graph entries,
        - maps new entities to existing graph nodes where appropriate,
        - adds implied relationships, and
        - removes stale relationships that are superseded by the new information.
        """
        extraction = await self._extract_graph_details(
            texts,
            record_ids=record_ids,
            agent_id=agent_id,
            session_id=session_id,
            user_id=user_id,
        )

        if graph_update and (extraction.entities or extraction.relationships):
            scope_filter = MemoryFilter(agent_id=agent_id, session_id=None, user_id=user_id)
            base_filter = scope_filter if not scope_filter.is_empty() else None

            context, all_existing_entities, all_existing_rels = await self._build_graph_context(
                extraction.entities,
                filter=base_filter,
                top_k=graph_update.context_top_k,
                with_index_search=graph_update.with_index_search
            )
            extraction = await self._refine_extraction_with_graph(
                extraction, context, all_existing_entities, all_existing_rels,
                record_ids=record_ids,
                agent_id=agent_id,
                session_id=session_id,
                user_id=user_id,
            )

        if extraction.entities:
            await self._graph.upsert_entities([e.to_entity() for e in extraction.entities])
        if extraction.relationships:
            await self._graph.upsert_relationships([r.to_relationship() for r in extraction.relationships])
        logger.debug(
            "_store_graph entities=%d relationships=%d graph_update=%s",
            len(extraction.entities), len(extraction.relationships), graph_update is not None,
        )
        return extraction

    # ------------------------------------------------------------------ #
    # Internal — graph search                                             #
    # ------------------------------------------------------------------ #

    async def _graph_search(
        self, query: str, *, filter: MemoryFilter | None, top_k: int
    ) -> dict[str, MemoryGraphSearchResult]:
        entity_names = await self._extract_query_entities(query)
        if not entity_names:
            return {}

        seen_entity_ids: set[str] = set()
        result_map: dict[str, MemoryGraphSearchResult] = {}

        for name in entity_names:
            graph_results = await self._graph.search_entities(
                entity_name=name,
                top_k=top_k,
                filter=filter.to_base_filter() if filter else None,
            )
            for gr in graph_results:
                if gr.entity.id in seen_entity_ids:
                    continue
                seen_entity_ids.add(gr.entity.id)

                # Build (entity_id, relation, direction) tuples from all relationships.
                related_refs: list[tuple[str, str, Direction]] = []
                for rel in gr.relationships:
                    if rel.source_id == gr.entity.id and rel.target_id != gr.entity.id:
                        related_refs.append((rel.target_id, rel.relation, DirectionEnum.OUTGOING.value))
                    elif rel.target_id == gr.entity.id and rel.source_id != gr.entity.id:
                        related_refs.append((rel.source_id, rel.relation, DirectionEnum.INCOMING.value))

                # Fetch each unique neighboring entity once.
                unique_ids = list({eid for eid, _, _ in related_refs})
                fetched = await asyncio.gather(*[self._graph.get_entity(eid) for eid in unique_ids])
                entity_by_id = {
                    eid: self._graph_entry_to_entity(e)
                    for eid, e in zip(unique_ids, fetched)
                    if e is not None
                }
                related_entities = [
                    MemoryRelatedEntity(entity=entity_by_id[eid], relation=rel, direction=direction)
                    for eid, rel, direction in related_refs
                    if eid in entity_by_id
                ]

                result_map[gr.entity.id] = MemoryGraphSearchResult(
                    entity=self._graph_entry_to_entity(gr.entity),
                    relationships=gr.relationships,
                    related_entities=related_entities,
                )

        return result_map

    # ------------------------------------------------------------------ #
    # Internal — LLM extraction                                           #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _user_context(user_id: str | None) -> str:
        if not user_id:
            return ""
        return (
            f"Context: the user in this conversation is identified as '{user_id}'. "
            "When extracting entities, facts, and relationships, attribute them to "
            "this user where applicable and use this identifier in your notes."
        )

    async def _extract_facts(self, messages: list[Message], *, user_id: str | None = None) -> list[str]:
        """Extract discrete, atomic facts from a conversation via LLM.

        Falls back to raw formatted messages if extraction fails or returns
        an empty list.
        """
        conversation = "\n".join(m.format() for m in messages)
        result = await self._extractor.run(
            f"Conversation:\n{conversation}",
            FACTS_EXTRACTION_CONFIG,
            {"user_context": self._user_context(user_id)},
        )
        if isinstance(result, FactsResponse) and result.facts:
            facts = [f for f in result.facts if f.strip()]
            if facts:
                logger.debug("_extract_facts produced %d facts", len(facts))
                return facts
        logger.warning("fact extraction failed or returned empty — falling back to raw messages")
        return [m.format() for m in messages]

    async def _extract_graph_details(
        self,
        texts: list[str],
        *,
        record_ids: list[str],
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
    ) -> ExtractionResult:
        content = "\n".join(texts)
        result = await self._extractor.run(
            f"Content:\n{content}",
            EXTRACTION_CONFIG,
            {"user_context": self._user_context(user_id)},
        )
        if not isinstance(result, ExtractionResponse):
            return ExtractionResult()

        entity_map: dict[str, str] = {}  # normalized entity name -> generated id
        entities: list[MemoryEntity] = []

        for item in result.entities:
            name = self._normalize_entity_name(item.name)
            if not name:
                continue
            entity_id = str(uuid.uuid4())
            entity_map[name] = entity_id

            properties = MemoryEntityProperties(
                **item.properties,
                memory_record_ids=record_ids,
            )
            entities.append(
                MemoryEntity(
                    id=entity_id,
                    name=name,
                    type=self._normalize_entity_type(item.type),
                    properties=dict(properties),
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                )
            )

        relationships: list[MemoryRelationship] = []
        for item in result.relationships:
            src_id = entity_map.get(self._normalize_entity_name(item.source))
            tgt_id = entity_map.get(self._normalize_entity_name(item.target))
            if not src_id or not tgt_id:
                continue
            relationships.append(
                MemoryRelationship(
                    id=str(uuid.uuid4()),
                    source_id=src_id,
                    target_id=tgt_id,
                    relation=self._normalize_relation_type(item.type),
                    properties=item.properties,
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                )
            )

        return ExtractionResult(entities=entities, relationships=relationships)

    async def _extract_query_entities(self, query: str) -> list[str]:
        """Return a flat list of entity name strings from a search query."""
        result = await self._extractor.run(
            f"Query: {query}",
            QUERY_ENTITIES_CONFIG,
        )
        if isinstance(result, QueryEntitiesResponse):
            return [n for n in result.names if n]
        return []

    # ------------------------------------------------------------------ #
    # Internal — graph-context refinement                                 #
    # ------------------------------------------------------------------ #

    async def _build_graph_context(
        self,
        entities: list[MemoryEntity],
        *,
        filter: MemoryFilter | None,
        top_k: int,
        with_index_search: bool = True,
    ) -> tuple[str, dict[str, Entity], dict[str, Relationship]]:
        """Search the graph for each extracted entity and build a context window.

        For each entity the graph is searched by name.  Matching nodes and their
        1-hop neighbours (with names resolved) are included.  Neighbour entities
        are also fetched so the LLM can reason about 2-hop connections — e.g.
        resolving ``"the company"`` to ``"Company X"`` via co-worker relationships.

        Returns:
            context_str:       Formatted multi-section string for the LLM prompt.
            all_existing_entities: All surfaced entities (ID → Entity), used
                                   for ID reuse and deletion validation in
                                   :meth:`_refine_extraction_with_graph`.
            all_existing_rels: All surfaced relationships (ID → Relationship), used
                               for ID reuse and deletion validation in
                               :meth:`_refine_extraction_with_graph`.
        """
        all_existing_entities: dict[str, Entity] = {}
        all_existing_rels: dict[str, Relationship] = {}
        sections: list[str] = []
        base_filter = filter.to_base_filter() if filter else None

        # Run graph name search for all entities in parallel.
        # If an entity index is available, also run vector search in parallel so
        # semantically similar existing entities (e.g. "Company X" ≈ "the company")
        # are surfaced even when a direct name match would miss them.
        has_index = self._entity_index is not None
        if with_index_search:
            if not has_index:
                logger.warning("with_index_search=True but no entity index configured — proceeding with graph search only")
                raise ValueError("with_index_search=True but no entity index configured")
            
            entity_texts = [f"{e.name} ({e.type})" for e in entities]
            embeddings = await self._embedder.embed_batch(entity_texts)
            graph_searches, index_searches = await asyncio.gather(
                asyncio.gather(*[
                    self._graph.search_entities(entity_name=e.name, top_k=top_k, filter=base_filter)
                    for e in entities
                ]),
                asyncio.gather(*[
                    self._entity_index.search(emb.vector, top_k=top_k, filter=base_filter)  # type: ignore[union-attr]
                    for emb in embeddings
                ]),
            )
        else:
            graph_searches = await asyncio.gather(*[
                self._graph.search_entities(entity_name=e.name, top_k=top_k, filter=base_filter)
                for e in entities
            ])
            index_searches = [[] for _ in entities]

        # Merge: for each extracted entity, combine graph results with any additional
        # entities found by vector search (fetching them from the graph by ID).
        results_per_entity: list[list[GraphSearchResult]] = []
        for graph_results, index_hits in zip(graph_searches, index_searches):
            known_ids = {gr.entity.id for gr in graph_results}
            new_ids = [h.record.id for h in index_hits if h.record.id not in known_ids]
            if new_ids:
                additional = await self._graph.get_entities_with_relationships(new_ids)
                results_per_entity.append(list(graph_results) + additional)
            else:
                results_per_entity.append(list(graph_results))

        # Cache of entity ID → GraphSearchResult for everything already fetched.
        # Used to avoid re-fetching neighbours that were already returned as
        # direct matches for one of the other extracted entities.
        entity_cache: dict[str, GraphSearchResult] = {
            gr.entity.id: gr
            for entity_results in results_per_entity
            for gr in entity_results
        }

        for entity, graph_results in zip(entities, results_per_entity):
            if not graph_results:
                sections.append(f'No existing graph entry found for "{entity.name}".')
                continue

            section: list[str] = [f'Existing graph matches for "{entity.name}":']

            # Collect neighbour IDs referenced by this entity's relationships.
            neighbour_ids: set[str] = set()
            for gr in graph_results:
                all_existing_entities[gr.entity.id] = gr.entity
                for rel in gr.relationships:
                    all_existing_rels[rel.id] = rel
                    other = rel.target_id if rel.source_id == gr.entity.id else rel.source_id
                    if other != gr.entity.id:
                        neighbour_ids.add(other)

            # Resolve neighbours: use cache where possible, fetch the rest.
            cached_neighbours = {nid: entity_cache[nid] for nid in neighbour_ids if nid in entity_cache}
            missing_ids = [nid for nid in neighbour_ids if nid not in entity_cache]
            fetched_neighbours = await self._graph.get_entities_with_relationships(missing_ids)
            entity_cache.update({gr.entity.id: gr for gr in fetched_neighbours})

            neighbour_results = list(cached_neighbours.values()) + fetched_neighbours
            neighbour_map: dict[str, GraphSearchResult] = {gr.entity.id: gr for gr in neighbour_results}
            for gr in neighbour_results:
                all_existing_entities[gr.entity.id] = gr.entity
                for rel in gr.relationships:
                    all_existing_rels[rel.id] = rel

            def _resolve(entity_id: str, anchor: Entity) -> Entity:
                if entity_id == anchor.id:
                    return anchor
                nb = neighbour_map.get(entity_id)
                return nb.entity if nb else Entity(id=entity_id, name=entity_id, type="unknown", properties={})

            # Describe each graph match.
            for gr in graph_results:
                section.append(
                    f"  Entity: {gr.entity.name} ({gr.entity.type}) [ID={gr.entity.id}]"
                )
                if gr.relationships:
                    section.append("    Relationships:")
                    for rel in gr.relationships:
                        src = _resolve(rel.source_id, gr.entity)
                        tgt = _resolve(rel.target_id, gr.entity)
                        section.append(f"      [REL={rel.id}] {src.name} [ID={src.id}] --[{rel.relation}]--> {tgt.name} [ID={tgt.id}]")

            # Describe neighbours and their own relationships (2-hop context).
            if neighbour_map:
                section.append("  Neighbours:")
                for ngr in neighbour_map.values():
                    section.append(f"    Entity: {ngr.entity.name} ({ngr.entity.type}) [ID={ngr.entity.id}]")
                    for rel in ngr.relationships:
                        src = neighbour_map[rel.source_id].entity if rel.source_id in neighbour_map else Entity(id=rel.source_id, name=rel.source_id, type="unknown", properties={})
                        tgt = neighbour_map[rel.target_id].entity if rel.target_id in neighbour_map else Entity(id=rel.target_id, name=rel.target_id, type="unknown", properties={})
                        section.append(f"      [REL={rel.id}] {src.name} [ID={src.id}] --[{rel.relation}]--> {tgt.name} [ID={tgt.id}]")

            sections.append("\n".join(section))

        return "\n\n".join(sections), all_existing_entities, all_existing_rels

    async def _refine_extraction_with_graph(
        self,
        extraction: ExtractionResult,
        graph_context: str,
        all_existing_entities: dict[str, Entity],
        all_existing_rels: dict[str, Relationship],
        *,
        record_ids: list[str],
        agent_id: str | None,
        session_id: str | None,
        user_id: str | None,
    ) -> ExtractionResult:
        """Run the graph-context-aware LLM refinement pass.

        Builds a prompt from the initial extraction and the graph context produced
        by :meth:`_build_graph_context`, then processes the LLM response into a
        final :class:`~.types.ExtractionResult`.

        Entities:
        - LLM may map a newly extracted entity to an existing graph node via ``existing_id``.
        - Matched entities have their name and type updated to the refined values.
        - New entities receive a fresh UUID.

        Relationships:
        - LLM may reference an existing relationship via ``existing_id`` to update its
          type or endpoints; the old version is added to the delete set.
        - Otherwise an existing relationship is reused by ``(source_id, target_id, relation)``
          key match to avoid creating duplicates.
        - LLM-specified deletions (``relationships_to_delete``) are removed from the graph.

        Falls back to the original *extraction* if the LLM call fails.
        """
        id_to_name = {e.id: e.name for e in extraction.entities}
        entity_lines = [f'  - "{e.name}" ({e.type}) [id={e.id}]' for e in extraction.entities]
        rel_lines = [
            f'  - {id_to_name.get(r.source_id, r.source_id)} --[{r.relation}]--> {id_to_name.get(r.target_id, r.target_id)}'
            for r in extraction.relationships
        ]
        content = (
            "NEWLY EXTRACTED ENTITIES:\n" + ("\n".join(entity_lines) or "  (none)") +
            "\n\nNEWLY EXTRACTED RELATIONSHIPS:\n" + ("\n".join(rel_lines) or "  (none)") +
            "\n\nEXISTING GRAPH CONTEXT:\n" + (graph_context or "  (graph is empty)")
        )

        logger.debug("_refine_extraction_with_graph: sending content to LLM:\n%s", content)
        result = await self._extractor.run(content, GRAPH_REFINEMENT_CONFIG, {"user_context": self._user_context(user_id)})
        if not isinstance(result, GraphRefinementResponse):
            logger.warning("_refine_extraction_with_graph: LLM returned unexpected type — using original extraction")
            return extraction

        logger.debug(
            "_refine_extraction_with_graph: LLM produced %d entities, %d relationships, %d deletions",
            len(result.entities), len(result.relationships), len(result.relationships_to_delete),
        )
        logger.debug("GraphRefinementResponse=%s", result)

        # --- Entity resolution ---
        # name_map provides lookup for relationship resolution and includes all graph-context
        # entities so the LLM can reference them by name in relationships without re-listing them.
        existing_by_name: dict[str, Entity] = {e.name: e for e in all_existing_entities.values()}
        entity_name_map: dict[str, MemoryEntity] = {
            e.name: self._graph_entry_to_entity(e) for e in all_existing_entities.values()
        }

        refined_entities: dict[str, MemoryEntity] = {}  # only entities to upsert
        for item in result.entities:
            name = self._normalize_entity_name(item.name)
            if not name:
                continue

            # Resolve: explicit existing_id > name match in graph context > new entity.
            existing: Entity | None = None
            if item.existing_id and item.existing_id in all_existing_entities:
                existing = all_existing_entities[item.existing_id]
            elif name in existing_by_name:
                existing = existing_by_name[name]

            if existing is not None:
                mem_entity = self._graph_entry_to_entity(existing)
                # Merge record IDs without mutating the source properties dict.

                
                properties = deepcopy(mem_entity.properties) or {}
                existing_record_ids = set(properties.pop("memory_record_ids", []))
                existing_record_ids.update(record_ids)

                mem_entity.properties = {**properties, "memory_record_ids": list(existing_record_ids)}
            else:
                mem_entity = MemoryEntity(
                    id=str(uuid.uuid4()),
                    name=name,
                    type=self._normalize_entity_type(item.type),
                    properties=dict(MemoryEntityProperties(memory_record_ids=record_ids)),
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                )

            mem_entity.name = name
            mem_entity.type = self._normalize_entity_type(item.type)
            refined_entities[mem_entity.id] = mem_entity
            entity_name_map[name] = mem_entity  # override so renamed entities resolve correctly

        # --- Relationship resolution ---
        # Index existing rels two ways: by composite key for duplicate detection, by ID for updates.
        existing_rels_by_key: dict[tuple[str, str, str], Relationship] = {
            (rel.source_id, rel.target_id, rel.relation): rel
            for rel in all_existing_rels.values()
        }

        rels_to_delete: set[str] = set(result.relationships_to_delete)
        refined_relationships: dict[str, MemoryRelationship] = {}

        for item in result.relationships:
            src_name = self._normalize_entity_name(item.source)
            tgt_name = self._normalize_entity_name(item.target)
            src_entity = entity_name_map.get(src_name)
            tgt_entity = entity_name_map.get(tgt_name)

            if not src_entity or not tgt_entity:
                logger.debug(
                    "_refine_extraction_with_graph: skipping relationship — unknown entity %r or %r",
                    item.source, item.target,
                )
                continue

            norm_relation = self._normalize_relation_type(item.type)
            key = (src_entity.id, tgt_entity.id, norm_relation)

            if item.existing_id and item.existing_id in all_existing_rels:
                # LLM is updating an existing relationship (possibly renaming/retyping it).
                old_rel = all_existing_rels[item.existing_id]
                old_key = (old_rel.source_id, old_rel.target_id, old_rel.relation)
                if old_key != key:
                    # The relation has changed — delete the stale version.
                    rels_to_delete.add(old_rel.id)
                
                mem_rel = self._graph_rel_to_memory(old_rel)
                mem_rel.source_id = src_entity.id
                mem_rel.target_id = tgt_entity.id
                mem_rel.relation = norm_relation
            elif key in existing_rels_by_key:
                # Reuse the existing relationship's ID to avoid creating a duplicate.
                mem_rel = self._graph_rel_to_memory(existing_rels_by_key[key])
            else:
                mem_rel = MemoryRelationship(
                    id=str(uuid.uuid4()),
                    source_id=src_entity.id,
                    target_id=tgt_entity.id,
                    relation=norm_relation,
                    properties={},
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                )

            refined_relationships[mem_rel.id] = mem_rel

        # Validate deletion IDs against known context (ignore phantom IDs from the LLM).
        valid_del_ids = [rid for rid in rels_to_delete if rid in all_existing_rels]
        # Exclude deleted rels from the upsert set so they are not re-created.
        for rid in valid_del_ids:
            refined_relationships.pop(rid, None)

        if valid_del_ids:
            logger.debug("_refine_extraction_with_graph: deleting %d stale relationships", len(valid_del_ids))
            await self._graph.delete_relationships(valid_del_ids)

        logger.debug(
            "_refine_extraction_with_graph: entities=%d relationships=%d deleted=%d",
            len(refined_entities), len(refined_relationships), len(valid_del_ids),
        )
        return ExtractionResult(entities=list(refined_entities.values()), relationships=list(refined_relationships.values()))

    # ------------------------------------------------------------------ #
    # Internal — helpers                                                   #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _normalize_entity_name(name: str) -> str:
        """Collapse whitespace and title-case an entity name.

        Example: ``"  alice smith "`` → ``"Alice Smith"``
        """
        return " ".join(name.split()).title()

    @staticmethod
    def _normalize_entity_type(entity_type: str) -> str:
        """Title-case an entity type label.

        Example: ``"organization"`` → ``"Organization"``
        """
        return entity_type.strip().title()

    @staticmethod
    def _normalize_relation_type(relation: str) -> str:
        """Normalize a relationship type to lowercase snake_case.

        Example: ``"Works At"`` → ``"works_at"``, ``"KNOWS--"`` → ``"knows"``
        """
        s = relation.strip().lower().replace("-", "_").replace(" ", "_")
        while "__" in s:
            s = s.replace("__", "_")
        return s.strip("_") or "related_to"

    @staticmethod
    def _graph_entry_to_entity(entity: Entity) -> MemoryEntity:
        """Convert a graph :class:`~knotaru_nlp.graph.types.Entity` to a :class:`~.types.MemoryEntity`."""
        props = entity.properties
        return MemoryEntity(
            id=entity.id,
            name=entity.name,
            type=entity.type,
            properties=props,
            agent_id=props.get("agent_id"),
            session_id=props.get("session_id"),
            user_id=props.get("user_id"),
        )

    @staticmethod
    def _graph_rel_to_memory(rel: Relationship) -> MemoryRelationship:
        """Convert a graph :class:`~knotaru_nlp.graph.types.Relationship` to a :class:`~.types.MemoryRelationship`."""
        props = rel.properties
        return MemoryRelationship(
            id=rel.id,
            source_id=rel.source_id,
            target_id=rel.target_id,
            relation=rel.relation,
            properties=props,
            agent_id=props.get("agent_id"),
            session_id=props.get("session_id"),
            user_id=props.get("user_id"),
        )
