"""Memory-specific filter extending the generic BaseFilter with agent/session/user scoping."""

from __future__ import annotations

from ..filters import BaseFilter, FieldFilter, FilterOp


class MemoryFilter(BaseFilter):
    """Structured filter for memory queries.

    Extends :class:`~knotaru_nlp.filters.BaseFilter` with typed scope fields
    for ``agent_id``, ``session_id``, and ``user_id``.  Call
    :meth:`to_base_filter` to obtain a plain :class:`~knotaru_nlp.filters.BaseFilter`
    where scope fields are converted to :class:`~knotaru_nlp.filters.FieldFilter`
    entries — use that when passing the filter to a backend.

    Args:
        agent_id: Restrict results to a specific agent.
        session_id: Restrict results to a specific session.
        user_id: Restrict results to a specific user.
        metadata: Additional field-level predicates on stored metadata.
        logic: How to combine ``metadata`` predicates — ``"and"`` (default) or ``"or"``.

    Example::

        from knotaru_nlp.memory.filters import MemoryFilter
        from knotaru_nlp.filters import FieldFilter, FilterOp

        f = MemoryFilter(
            agent_id="agent-1",
            user_id="user-42",
            metadata=[
                FieldFilter(field="topic", op=FilterOp.IN, value=["finance", "legal"]),
                FieldFilter(field="importance", op=FilterOp.GTE, value=3),
            ],
        )
        base = f.to_base_filter()  # pass this to index.search / graph backends
    """

    agent_id: str | None = None
    session_id: str | None = None
    user_id: str | None = None

    def is_empty(self) -> bool:
        """Return ``True`` if no scope fields and no metadata predicates are set."""
        return (
            self.agent_id is None
            and self.session_id is None
            and self.user_id is None
            and not self.metadata
        )

    def to_base_filter(self) -> BaseFilter:
        """Return a plain :class:`~knotaru_nlp.filters.BaseFilter` with scope
        fields converted to :class:`~knotaru_nlp.filters.FieldFilter` entries.

        Use this when passing to backends (e.g. vector index) that accept
        ``BaseFilter`` and process only the ``metadata`` list.
        """
        scope_filters: list[FieldFilter] = [
            FieldFilter(field=f"properties.{key}", op=FilterOp.EQ, value=val)
            for key, val in {
                "agent_id": self.agent_id,
                "session_id": self.session_id,
                "user_id": self.user_id,
            }.items()
            if val is not None
        ]
        return BaseFilter(
            metadata=[*scope_filters, *self.metadata],
            logic=self.logic,
        )


# Ensure the inherited recursive metadata annotation is resolved for this subclass.
MemoryFilter.model_rebuild()

__all__ = ["MemoryFilter"]
