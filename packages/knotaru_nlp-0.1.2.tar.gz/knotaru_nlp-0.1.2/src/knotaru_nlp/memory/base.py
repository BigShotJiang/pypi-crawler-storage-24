"""Abstract base class for the memory system."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..chat.classes.messaging import Message
from .filters import MemoryFilter
from .types import GraphUpdateConfig, MemoryDedupeConfig, MemoryRecord, MemorySearchResult, SearchMode, SearchModeEnum


class BaseMemory(ABC):
    """Abstract memory system.

    Combines a vector index and a knowledge graph to build a persistent,
    queryable memory layer for AI agents.

    Concrete implementations wire together:
    - A :class:`~knotaru_nlp.indexing.base.BaseIndex` for vector storage.
    - A :class:`~knotaru_nlp.graph.base.BaseGraph` for entity/relationship storage.
    - A :class:`~knotaru_nlp.embedding.base.BaseEmbedder` for text → vector conversion.
    - A :class:`~knotaru_nlp.chat.base.ChatClient` for LLM-based entity extraction.

    Usage::

        memory = MemoryIndex(index=index, graph=graph, embedder=embedder, chat=chat)

        # Store a conversation turn
        records = await memory.store(
            messages,
            agent_id="agent-1",
            session_id="sess-abc",
            user_id="user-42",
        )

        # Query hybrid (vector + graph)
        results = await memory.search(
            "What does Alice do at Acme?",
            filter=MemoryFilter(agent_id="agent-1"),
            top_k=10,
        )

        # Scoped delete
        await memory.delete([r.id for r in records])
    """

    # ------------------------------------------------------------------ #
    # Writes                                                               #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def store(
        self,
        messages: list[Message],
        *,
        agent_id: str | None = None,
        session_id: str | None = None,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        extract_facts: bool = True,
        memory_dedupe: MemoryDedupeConfig | None = None,
        graph_update: GraphUpdateConfig | None = None,
    ) -> list[MemoryRecord]:
        """Vectorise and store messages, optionally running LLM fact extraction first.

        Args:
            messages: Conversation messages to store.
            agent_id: Agent scoping identifier.
            session_id: Session scoping identifier.
            user_id: User scoping identifier.
            metadata: Additional key-value metadata attached to every record.
            extract_facts: If ``True`` (default), an LLM first extracts and
                summarises the key facts from *messages*.  Those facts are then
                embedded and stored in the vector index, and a second LLM pass
                extracts graph entities and relationships from them.  If
                ``False``, messages are formatted and stored directly as raw
                vector memories — no LLM calls are made and no graph data is
                written.
            dedup: Deduplication strategy applied before storing new records:

                - ``"none"`` *(default)* — no deduplication; current behaviour.
                - ``"scope"`` — delete **all** existing records that share the
                  same scope (``session_id`` → ``agent_id`` → ``user_id``,
                  most specific wins) before inserting.  Ideal when the caller
                  always passes the full conversation so new facts supersede old
                  ones (e.g. re-storing after each turn with the full history).
                - ``"semantic"`` — embed the new texts, search the scoped index
                  for records whose cosine similarity exceeds *dedup_threshold*,
                  and delete them before inserting.  Works with incremental
                  additions and handles rephrased-but-equivalent facts.

            dedup_threshold: Cosine-similarity cutoff used by ``"semantic"``
                dedup (default ``0.92``).  Records with a score at or above
                this value are considered duplicates and removed.

        Returns:
            The stored :class:`~knotaru_nlp.memory.types.MemoryRecord` objects.
        """

    # ------------------------------------------------------------------ #
    # Reads                                                                #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def search(
        self,
        query: str,
        *,
        filter: MemoryFilter | None = None,
        top_k: int = 10,
        mode: SearchMode = SearchModeEnum.HYBRID.value,
    ) -> MemorySearchResult:
        """Search memory using vector similarity, graph traversal, or both.

        **Vector mode** embeds the query and performs ANN search against stored
        message vectors.

        **Graph mode** extracts entity names from the query, finds matching
        nodes in the graph, then fetches the memory records associated with
        those nodes.

        **Hybrid mode** (default) runs both searches, deduplicates on record ID,
        and boosts records that appear in both result sets.

        Args:
            query: Natural-language search query.
            filter: Optional :class:`~knotaru_nlp.filters.MemoryFilter` to
                restrict the result scope.
            top_k: Maximum number of results to return.
            mode: Search strategy — ``"vector"``, ``"graph"``, or ``"hybrid"``.

        Returns:
            Results ordered by descending relevance score.
        """

    @abstractmethod
    async def get(self, record_id: str) -> MemoryRecord | None:
        """Fetch a single memory record by ID.  Returns ``None`` if not found."""

    # ------------------------------------------------------------------ #
    # Deletes                                                              #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def delete(self, ids: list[str]) -> None:
        """Delete memory records and their associated graph data by ID.

        Args:
            ids: Record IDs to delete (as returned by :meth:`store`).
        """

    @abstractmethod
    async def reset(self) -> None:
        """Clear all memory — drops the vector index and graph data."""
