"""Extraction prompts and response models for the memory system.

Defines the Pydantic shapes the LLM must return for each extraction task,
paired with the :class:`~knotaru_nlp.extraction.types.ExtractorConfig` that
wires the prompt, response schema, and structured-output flag together.

Internal — import the config constants, not the response models directly.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from ..chat.prompt import Prompt, PromptInput
from ..extraction.types import ExtractorConfig

_USER_CONTEXT_INPUT = PromptInput(
    key="user_context",
    default="",
    description="Optional user identity context injected into extraction prompts.",
)


# ---------------------------------------------------------------------------
# Response models — describe the exact JSON shape the LLM must return.
# These drive both runtime Pydantic validation and (when structured_output is
# enabled) the response_format schema sent to the LLM.
# ---------------------------------------------------------------------------


class _EntityItem(BaseModel):
    """A single entity as returned by the LLM extraction call."""

    name: str
    type: str = "Other"
    properties: dict[str, Any] = Field(default_factory=dict)


class _RelationshipItem(BaseModel):
    """A single relationship as returned by the LLM extraction call."""

    source: str
    target: str
    type: str = "related_to"
    properties: dict[str, Any] = Field(default_factory=dict)


class ExtractionResponse(BaseModel):
    """Top-level extraction response: entities and relationships from a conversation."""

    entities: list[_EntityItem] = Field(default_factory=list)
    relationships: list[_RelationshipItem] = Field(default_factory=list)


class QueryEntitiesResponse(BaseModel):
    """Entity names extracted from a search query."""

    names: list[str] = Field(default_factory=list)


class FactsResponse(BaseModel):
    """Key facts extracted and summarised from a conversation.

    Each item in ``facts`` is a discrete, self-contained statement that can be
    embedded and retrieved independently.
    """

    facts: list[str] = Field(default_factory=list)


class DedupeResponse(BaseModel):
    """IDs of existing memory records the LLM decided should be deleted.

    Each ID in ``ids_to_delete`` corresponds to an existing record that is
    redundant, outdated, or fully superseded by one of the new entries.
    """

    ids_to_delete: list[str] = Field(default_factory=list)


class _RefinedEntityItem(BaseModel):
    """A single entity produced by the graph refinement LLM pass."""

    name: str
    type: str = "Other"
    existing_id: str | None = None


class _RefinedRelationshipItem(BaseModel):
    """A single relationship produced by the graph refinement LLM pass."""

    source: str
    target: str
    type: str = "related_to"
    existing_id: str | None = None


class GraphRefinementResponse(BaseModel):
    """LLM response for the graph-context-aware refinement pass.

    ``entities`` contains corrected/resolved entities (new or updated).
    ``relationships`` contains the final set of relationships to store.
    ``relationships_to_delete`` lists existing relationship IDs (from the
    graph context) that are now stale and should be removed.
    """

    entities: list[_RefinedEntityItem] = Field(default_factory=list)
    relationships: list[_RefinedRelationshipItem] = Field(default_factory=list)
    relationships_to_delete: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Extraction configs — combine the prompt with the response model.
# ---------------------------------------------------------------------------

EXTRACTION_CONFIG = ExtractorConfig(
    system_prompt=Prompt(
        """\
        You are a precise entity and relationship extraction system.
        Given a conversation, extract all notable entities and the relationships between them.

        Return a JSON object with this exact structure:
        {{
            "entities": [
                {{"name": "entity name", "type": "str", "properties": {{}}}}
            ],
            "relationships": [
                {{"source": "entity name", "target": "entity name", "type": "str", "properties": {{}}}}
            ]
        }}

        Rules:
        - Only include entities explicitly mentioned or strongly implied in the conversation.
        - Entity names must be consistent — use the same string every time the same entity appears.
        - Relationship type should be a short snake_case label (e.g. works_at, knows, located_in, part_of).
        - Properties may include any relevant scalar attributes; use {{}} if none.
        {user_context}\
        """,
        inputs=[_USER_CONTEXT_INPUT],
    ),
    result_model=ExtractionResponse,
)

QUERY_ENTITIES_CONFIG = ExtractorConfig(
    system_prompt="""\
        Extract the key entity names from the search query below.
        Return a JSON object with a single field "names" containing a list of entity name strings.
        Example: {"names": ["Alice", "Acme Corp"]}\
    """,
    result_model=QueryEntitiesResponse,
)

FACTS_EXTRACTION_CONFIG = ExtractorConfig(
    system_prompt=Prompt(
        """\
        You are a personal memory extraction system. Your sole purpose is to capture facts about
        the specific user that an LLM would not already know — things that are unique to this
        person and cannot be inferred from general knowledge.

        Given a conversation, extract only facts that are personal and specific to the user:
        their name, role, employer, location, goals, preferences, relationships, ongoing projects,
        decisions they have made, or anything else that distinguishes them individually.

        Do NOT extract:
        - General knowledge, definitions, or widely known information (e.g. "Python is a programming language").
        - Facts about third parties that have no direct bearing on the user.
        - Statements the assistant made as part of an explanation (as opposed to facts the user revealed).

        Each fact must be:
        - Self-contained and fully understandable without surrounding context.
        - Written in third-person where possible (e.g. "The user works at Acme Corp as a senior engineer.").
        - Specific and concrete — avoid vague summaries.

        Return a JSON object: {{"facts": ["fact 1", "fact 2", ...]}}
        If no personal facts are present in the conversation, return {{"facts": []}}
        {user_context}\
        """,
        inputs=[_USER_CONTEXT_INPUT],
    ),
    result_model=FactsResponse,
)

DEDUP_LLM_CONFIG = ExtractorConfig(
    system_prompt="""\
        You are a memory deduplication assistant.
        You will be given a list of NEW memory entries about to be stored, and a list of EXISTING memory entries that are semantically similar.
        Your task is to decide which existing entries should be deleted because they are fully redundant, outdated, or superseded by the new entries.

        Rules:
        - Only delete an existing entry if a new entry clearly covers the same information at equal or greater specificity.
        - If the existing entry contains ANY information not present in the new entries, keep it.
        - Be conservative — prefer keeping entries over deleting them when uncertain.
        - Return ONLY the IDs of existing entries to delete. Do not include IDs from the new entries.

        Return a JSON object: {"ids_to_delete": ["id1", "id2", ...]}\
    """,
    result_model=DedupeResponse,
)

GRAPH_REFINEMENT_CONFIG = ExtractorConfig(
    system_prompt=Prompt(
        """\
        You are a knowledge graph refinement assistant.
        You will be given NEWLY EXTRACTED entities and relationships from a conversation, along with
        EXISTING GRAPH CONTEXT showing what is already stored — including neighbor entities reached
        via graph traversal.

        Your task is to produce a refined, corrected extraction by:
        1. Resolving ambiguous references using graph context (e.g. "the company" → "Company X" if
           context shows that Company X is where related people work).
        2. Correcting entity names and types to match existing canonical names in the graph.
        3. Mapping new entities to existing ones where they clearly refer to the same real-world thing
           (set existing_id to the entity's graph ID shown in the context as [ID=...]).
        4. Adding relationships clearly implied by the new information, even if not explicitly stated.
           For example, if person A works at Company X and person B is said to work with A, infer
           that B also works_at Company X.
        5. Marking existing relationships for deletion (relationships_to_delete) if they are directly
           contradicted or fully superseded by new information.
        6. When updating an existing relationship's type or endpoints, set existing_id to the
           relationship's graph ID shown as [REL=...] in the context, and add its old ID to
           relationships_to_delete so the stale version is removed.
        7. Prefer updating or merging over creating duplicates — if a new relationship is essentially
           the same as an existing one with a slightly different label, unify them under the correct
           relation type and delete the old one.

        Rules:
        - Use entity names EXACTLY as they appear in the graph context when referring to existing entities.
        - Only set existing_id (for entities or relationships) when you are confident they refer to the
          same real-world thing.
        - Only include entities that are new or being updated — do not re-list unchanged existing entities.
        - Relationship source and target must be names from your entities list OR exact names from the
          graph context.
        - Be conservative with deletions — only delete if clearly superseded or contradicted.
        - Do not create a relationship if an equivalent one already exists in the graph context.

        Return a JSON object:
        {{
            "entities": [
                {{"name": "...", "type": "...", "existing_id": "existing-id-or-null"}},
                ...
            ],
            "relationships": [
                {{"source": "entity name", "target": "entity name", "type": "relation_type", "existing_id": "existing-rel-id-or-null"}},
                ...
            ],
            "relationships_to_delete": ["REL-ID-1", ...]
        }}
        {user_context}\
        """,
        inputs=[_USER_CONTEXT_INPUT],
    ),
    result_model=GraphRefinementResponse,
)
