"""Concrete memory implementation wiring vector index + graph + LLM extraction."""

from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Any

from ..chat.base import ChatClient
from ..chat.classes.messaging import History
from ..embedding.base import BaseEmbedder
from ..extraction.extractor import Extractor
from .filters import MemoryFilter
from ..graph.base import BaseGraph
from ..indexing.base import BaseIndex
from .base import BaseMemory
from .filters import BaseFilter, FieldFilter, FilterOp
from .types import (
    GraphUpdateConfig, MemoryDedupeConfig, MemoryDedupeScopeEnum,
    MemoryEntity, MemoryRecord, MemoryRelationship,
    MemorySearchResult, SearchModeEnum, SearchMode,
)
from ._index_mixin import _IndexStoreMixin
from ._graph_mixin import _GraphStoreMixin

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# MemoryIndex
# ---------------------------------------------------------------------------


class MemoryIndex(BaseMemory, _IndexStoreMixin, _GraphStoreMixin):
    """Hybrid memory system backed by a vector index and a knowledge graph.

    On :meth:`store`:
    1. Each message is formatted as ``"<role>: <content>"`` and embedded.
    2. All records are upserted into the vector index with scoping metadata.
    3. The full conversation is sent to the LLM for entity + relationship
       extraction; results are stored in the graph.

    On :meth:`search` (hybrid mode):
    1. Query is embedded; vector index is searched with optional filter.
    2. Entity names are extracted from the query and looked up in the graph.
    3. Graph hits are resolved back to memory records via stored ``record_id``
       properties on entities.
    4. Results from both sources are merged and deduplicated; records found
       by both sources receive a score boost.

    Args:
        index: Vector index backend for memory records.
        embedder: Text embedding provider.
        chat: LLM client used for entity extraction.
        graph: Graph database backend.
        entity_index: Optional vector index for graph entities.  When provided,
            entities extracted during :meth:`store` are embedded and deduplicated
            against this index before being written to the graph.
        extractor: Optional pre-configured :class:`~knotaru_nlp.extractor.Extractor`
            instance.  When omitted one is created automatically from *chat*.
        enable_graph: Set to ``False`` to skip LLM extraction and graph
            storage (vector-only mode).
        graph_score: Fixed relevance score assigned to graph-sourced results
            that are not also returned by the vector search.
        hybrid_boost: Added to the vector score when a record appears in
            both vector and graph results.
    """

    def __init__(
        self,
        index: BaseIndex,
        embedder: BaseEmbedder,
        chat: ChatClient,
        *,
        graph: BaseGraph | None = None,
        entity_index: BaseIndex | None = None,
        extractor: Extractor | None = None,
        enable_graph: bool = True,
        graph_score: float = 0.75,
        hybrid_boost: float = 0.15,
    ) -> None:
        if enable_graph and graph is None:
            raise ValueError("'graph' must be provided when enable_graph=True")
        if entity_index is not None and not enable_graph:
            raise ValueError("'entity_index' requires enable_graph=True")
        self._index = index
        self._graph_impl: BaseGraph | None = graph
        self._entity_index: BaseIndex | None = entity_index
        self._embedder = embedder
        self._chat = chat
        self._extractor = extractor or Extractor(chat)
        self._enable_graph = enable_graph
        self._graph_score = graph_score
        self._hybrid_boost = hybrid_boost

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    async def store(
        self,
        messages: History,
        *,
        agent_id: str | None = None,
        session_id: str | None = None,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        extract_facts: bool = True,
        memory_dedupe: MemoryDedupeConfig | None = None,
        graph_update: GraphUpdateConfig | None = None,
    ) -> list[MemoryRecord]:
        if not messages:
            return []

        logger.debug(
            "store messages=%d agent_id=%r extract_facts=%s memory_dedupe=%s graph_update=%s",
            len(messages), agent_id, extract_facts, memory_dedupe, graph_update is not None,
        )
        extra_meta = metadata or {}

        # 1. Determine what to embed.
        #    extract_facts=True  → LLM extracts discrete facts first; facts are indexed.
        #    extract_facts=False → raw formatted messages are indexed directly.
        if extract_facts:
            facts = await self._extract_facts(messages, user_id=user_id)
            text = "\n".join(facts)
            texts = [text] if text.strip() else []
        else:
            texts = [m.format() for m in messages]

        if not texts:
            return []

        # 2. Embed upfront — embeddings are needed for both storage and semantic dedup.
        embeddings = await self._embedder.embed_batch(texts)

        # 3. Pre-generate record IDs (shared by index and graph tasks).
        record_ids = [str(uuid.uuid4()) for _ in texts]

        # 4. Dedup: remove stale/similar records before inserting new ones.
        await self._dedupe_memory(
            texts=texts,
            embeddings=embeddings,
            agent_id=agent_id,
            session_id=session_id,
            user_id=user_id,
            memory_dedupe=memory_dedupe,
        )

        # 5. Run index and graph storage in parallel when both are enabled.
        entities: list[MemoryEntity] | None = None
        relationships: list[MemoryRelationship] | None = None

        if self._enable_graph:
            _, extraction = await asyncio.gather(
                self._store_index(
                    texts, messages,
                    record_ids=record_ids,
                    embeddings=embeddings,
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                    extra_meta=extra_meta,
                    extract_facts=extract_facts,
                ),
                self._store_graph(
                    texts,
                    record_ids=record_ids,
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                    graph_update=graph_update,
                ),
            )
            entities = extraction.entities or None
            relationships = extraction.relationships or None
        else:
            await self._store_index(
                texts, messages,
                record_ids=record_ids,
                embeddings=embeddings,
                agent_id=agent_id,
                session_id=session_id,
                user_id=user_id,
                extra_meta=extra_meta,
                extract_facts=extract_facts,
            )

        return [
            MemoryRecord(
                id=record_id,
                text=text,
                agent_id=agent_id,
                session_id=session_id,
                user_id=user_id,
                metadata=extra_meta,
                entities=entities,
                relationships=relationships,
            )
            for record_id, text in zip(record_ids, texts)
        ]

    async def search(
        self,
        query: str,
        *,
        filter: MemoryFilter | None = None,
        top_k: int = 10,
        mode: SearchMode = SearchModeEnum.HYBRID.value,
    ) -> MemorySearchResult:
        logger.debug("search query=%r mode=%s top_k=%d", query, mode, top_k)

        if mode == SearchModeEnum.HYBRID.value:
            vector_map, graph_map = await asyncio.gather(
                self._vector_search(query, filter=filter, top_k=top_k),
                self._graph_search(query, filter=filter, top_k=top_k),
            )
        elif mode == SearchModeEnum.VECTOR.value:
            vector_map = await self._vector_search(query, filter=filter, top_k=top_k)
            graph_map = None
        else:
            vector_map = {}
            graph_map = await self._graph_search(query, filter=filter, top_k=top_k)

        return MemorySearchResult(
            vector_result=list(vector_map.values()),
            graph_result=list(graph_map.values()) if graph_map else None,
        )

    async def get(self, record_id: str) -> MemoryRecord | None:
        index_record = await self._index.get(record_id)
        if index_record is None:
            return None

        entities: list[MemoryEntity] | None = None
        relationships: list[MemoryRelationship] | None = None

        if self._enable_graph:
            graph_results = await self._graph.search_entities(
                filter=BaseFilter(metadata=[
                    FieldFilter(field="properties.memory_record_ids", op=FilterOp.CONTAINS_ANY, value=[record_id])
                ])
            )
            entities = [self._graph_entry_to_entity(gr.entity) for gr in graph_results] or None

            seen_rel_ids: set[str] = set()
            rel_list: list[MemoryRelationship] = []
            for gr in graph_results:
                for rel in gr.relationships:
                    if rel.id in seen_rel_ids:
                        continue
                    seen_rel_ids.add(rel.id)
                    rel_list.append(self._graph_rel_to_memory(rel))
            relationships = rel_list or None

        return self._index_record_to_memory(index_record).model_copy(
            update={"entities": entities, "relationships": relationships}
        )

    async def delete(self, ids: list[str]) -> None:
        logger.debug("calling delete with ids=%d", len(ids))
        if self._enable_graph:
            # Run index delete and graph entity lookup in parallel — independent operations.
            graph_filter = BaseFilter(metadata=[
                FieldFilter(field="properties.memory_record_ids", op=FilterOp.CONTAINS_ANY, value=ids)
            ])
            graph_results, _ = await asyncio.gather(
                self._graph.search_entities(filter=graph_filter, top_k=1000),
                self._index.delete(ids),
            )
            # Only delete the entities directly linked to these records.
            # Relationship cleanup is handled by the graph backend's delete_entities.
            logger.debug("delete found %d graph entities to delete", len(graph_results))
            entity_ids = [gr.entity.id for gr in graph_results]
            if entity_ids:
                await self._graph.delete_entities(entity_ids)
                if self._entity_index is not None:
                    await self._entity_index.delete(entity_ids)
        else:
            await self._index.delete(ids)
        logger.debug("delete completed")

    async def reset(self) -> None:
        await self._index.reset()
        if self._enable_graph:
            await self._graph.reset()
            if self._entity_index is not None:
                await self._entity_index.reset()
