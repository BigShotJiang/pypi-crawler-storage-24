"""Memory module — hybrid vector + graph memory for AI agents.

Public API::

    from knotaru_nlp.memory import BaseMemory, MemoryIndex
    from knotaru_nlp.memory import MemoryRecord, MemorySearchResult, ExtractionResult
    from knotaru_nlp.memory import MemoryFilter
    from knotaru_nlp.memory import MemoryEntity, MemoryRelationship
"""

from .base import BaseMemory
from .filters import MemoryFilter
from .index import MemoryIndex
from .types import (
    ExtractionResult, MemoryEntity, MemoryRecord, 
    MemoryRelationship, MemorySearchResult, 
    SearchMode, SearchModeEnum, MemoryDedupeScope, MemoryDedupeScopeEnum, MemoryDedupeConfig,
    GraphUpdateConfig
)

__all__ = [
    "BaseMemory",
    "MemoryIndex",
    "MemoryFilter",
    "MemoryRecord",
    "MemorySearchResult",
    "ExtractionResult",
    "MemoryEntity",
    "MemoryRelationship",
    "SearchMode",
    "SearchModeEnum",
    "MemoryDedupeScope",
    "MemoryDedupeScopeEnum",
    "MemoryDedupeConfig",
    "GraphUpdateConfig"
]
