from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Optional
from .classes.messaging import History

class ChatClient(ABC):
    """
    Provider-agnostic chat client interface.
    """

    @abstractmethod
    async def chat(
        self,
        messages: History,
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ):
        """
        Send a chat request and return a normalized response.
        """
        raise NotImplementedError
    
    @abstractmethod
    async def chat_stream(
        self,
        messages: History,
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> AsyncIterator[Any]:
        """
        Send a chat request and return an async generator of response chunks.

        By default, this method can be used for streaming responses, but individual
        implementations can choose to buffer and return a single response instead.
        """
        raise NotImplementedError
        yield  # makes this an async generator so subclasses can use `yield`