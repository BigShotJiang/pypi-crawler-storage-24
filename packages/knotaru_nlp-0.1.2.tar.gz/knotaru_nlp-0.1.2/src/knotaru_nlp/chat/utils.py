"""Shared utilities for the chat module."""

from __future__ import annotations

from typing import Any


def extract_text(response: Any) -> str:
    """Extract plain text from a ChatClient response or Message content value.

    Handles all common response shapes across providers:

    * OpenAI ``ChatCompletion`` object — reads ``choices[0].message.content``
    * Plain ``str`` — returned as-is (mock clients, simple providers)
    * ``list`` of content blocks — joins all ``{"type": "text", "text": "..."}``
      entries, ignoring image/tool blocks (OpenAI multimodal, ``Message.content``)
    * ``dict`` — reads ``"content"`` or ``"text"`` key (Anthropic-style)
    * Anything else — ``str()`` fallback

    Args:
        response: A ChatClient response value or a ``Message.content`` value.

    Returns:
        Plain text string, never ``None``.
    """
    if hasattr(response, "choices"):
        return response.choices[0].message.content or ""
    if isinstance(response, str):
        return response
    if isinstance(response, list):
        return " ".join(
            block["text"]
            for block in response
            if isinstance(block, dict) and block.get("type") == "text"
        )
    if isinstance(response, dict):
        return response.get("content", "") or response.get("text", "")
    return str(response)
