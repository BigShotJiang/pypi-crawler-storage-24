"""Chat module — LLM completions with streaming support.

Public API::

    from knotaru_nlp.chat import BaseChat, Message, ChatResponse
    from knotaru_nlp.chat import OpenAIChat
    from knotaru_nlp.chat import Prompt
"""

from .base import ChatClient
from .classes.messaging import Message, History, MessageRoleEnum, MessageRole
from .classes.openai import FinishReason, FinishReasonEnum
from .openai import OpenAIChatClient
from .prompt import Prompt, PromptInput
from .utils import extract_text

__all__ = [
    "ChatClient",
    "Message",
    "MessageRole",
    "MessageRoleEnum",
    "History",
    "OpenAIChatClient",
    "FinishReason",
    "FinishReasonEnum",
    "Prompt",
    "PromptInput",
    "extract_text",
]
