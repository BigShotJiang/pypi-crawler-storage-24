"""Prompt — a structured, variable-aware prompt template.

Each variable in the template is declared up-front as a :class:`PromptInput`
describing its key, whether it is required, and what its default value is.
:meth:`Prompt.format` accepts a plain ``dict`` of values and validates them
against the declared inputs before rendering.

Usage::

    from knotaru_nlp.chat import Prompt, PromptInput

    p = Prompt(
        "You are a {role}.\\n\\n{instructions}",
        inputs=[
            PromptInput(key="role", required=True, description="The assistant's role."),
            PromptInput(key="instructions", default="Be concise."),
        ],
    )

    rendered = p.format({"role": "data analyst"})
    # "You are a data analyst.\\n\\nBe concise."

    p.format({})  # raises ValueError — 'role' is required
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# PromptInput
# ---------------------------------------------------------------------------


@dataclass
class PromptInput:
    """Descriptor for a single named variable in a :class:`Prompt` template.

    Args:
        key: The variable name as it appears in the template (e.g. ``"user_context"``).
        required: When ``True`` the variable must be supplied in the ``values``
            dict passed to :meth:`Prompt.format`; omitting it raises a
            :class:`ValueError`.  Defaults to ``False``.
        default: Fallback value used when the variable is not supplied and
            ``required`` is ``False``.  Defaults to an empty string.
        description: Human-readable explanation of what the variable
            represents.  Used for documentation and error messages only.
    """

    key: str
    required: bool = False
    default: str = ""
    description: str = field(default="", compare=False)


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------


class Prompt:
    """A prompt template with declared, validated variable substitution.

    Variables are denoted with ``{variable_name}`` syntax (standard Python
    format strings).  Every variable that appears in *template* should be
    declared in *inputs* so that required/optional semantics and defaults are
    explicit.

    Args:
        template: The prompt text containing ``{variable}`` placeholders.
        inputs: List of :class:`PromptInput` descriptors, each carrying its
            own ``key``.  Variables not listed here are left as-is by
            :meth:`format` (pass-through, no validation).

    Example::

        from knotaru_nlp.chat import Prompt, PromptInput

        p = Prompt(
            "Extract facts.\\n\\n{user_context}",
            inputs=[PromptInput(key="user_context", default="")],
        )

        str(p)                                    # renders with default
        p.format({"user_context": "User: alice"}) # override at call time
    """

    def __init__(
        self,
        template: str,
        inputs: list[PromptInput] | None = None,
    ) -> None:
        self._template = template
        self._inputs: dict[str, PromptInput] = {inp.key: inp for inp in (inputs or [])}

    def format(self, values: dict[str, Any] | None = None) -> str:
        """Render the template after validating and resolving *values*.

        Args:
            values: Variable overrides keyed by input name.  Required inputs
                must appear here.  Optional inputs fall back to their declared
                ``default`` when absent.

        Returns:
            The fully rendered prompt string.

        Raises:
            ValueError: If a required input is missing from *values*.
        """
        values = values or {}
        resolved: dict[str, str] = {}

        for name, inp in self._inputs.items():
            if name in values:
                resolved[name] = values[name]
            elif inp.default:
                resolved[name] = inp.default
            elif inp.required:
                raise ValueError(
                    f"Prompt input '{name}' is required but was not provided."
                    + (f"  ({inp.description})" if inp.description else "")
                )
            else:
                resolved[name] = ""

        return self._template.format_map(resolved)

    def __str__(self) -> str:
        """Render using declared defaults only (no overrides)."""
        return self.format()

    def __repr__(self) -> str:
        preview = self._template[:40].replace("\n", "\\n")
        return f"Prompt({preview!r}{'...' if len(self._template) > 40 else ''})"
