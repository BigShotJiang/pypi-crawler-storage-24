from enum import Enum
from typing import  Literal

FinishReason = Literal["stop", "length", "tool_calls", "content_filter"]
class FinishReasonEnum(str, Enum):
    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    CONTENT_FILTER = "content_filter"