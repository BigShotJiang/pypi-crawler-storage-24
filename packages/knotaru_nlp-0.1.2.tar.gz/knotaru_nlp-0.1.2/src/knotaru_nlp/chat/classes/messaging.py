from enum import Enum
from typing import List, Literal, Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator

MessageRole = Literal["system", "user", "assistant", "tool"]
class MessageRoleEnum(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"

class Message(BaseModel):
    message_id: str = Field(
        ...,
        description="Unique message identifier",
        min_length=3,
        max_length=50
    )
    role: MessageRole
    content: str | list = Field(..., description="Message content")

    tool_call_id: Optional[str] = Field(
        default=None,
        description="If this message was generated as part of a tool call, the ID of that tool call",
    )
    tool_calls: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="List of tool calls made by the assistant in this message (if any)",
    )

    # Validate content is not empty or whitespace
    @field_validator("content")
    def content_must_not_be_empty(cls, v):
        if isinstance(v, str) and not v.strip():
            raise ValueError("Content must not be empty or whitespace")
        if isinstance(v, list) and not any(isinstance(item, str) and item.strip() for item in v):
            raise ValueError("Content list must contain at least one non-empty string")
        return v
    
    def __str__(self) -> str:
        return f"Message(id={self.message_id}, role={self.role}, content={self.content})"
    
    def dict(self, **kwargs):
        data = super().dict(**kwargs)
        data['role'] = self.role
        return data
    
    def format(self) -> str:
        content = self.content if isinstance(self.content, str) else str(self.content)
        return f"{self.role}: {content}"

    def json(self, **kwargs):
        return super().json(**kwargs)

History = List[Message]