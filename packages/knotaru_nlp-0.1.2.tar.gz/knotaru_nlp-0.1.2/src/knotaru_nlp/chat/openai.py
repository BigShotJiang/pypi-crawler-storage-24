from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, AsyncIterator, Optional, cast
from knotaru_common.json import safe_json_dumps

from .base import ChatClient
from .classes.messaging import History, Message

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from openai.types.chat.chat_completion import ChatCompletion
    from openai.types.chat.chat_completion_chunk import ChatCompletionChunk
    from openai.types.chat.chat_completion_message_param import ChatCompletionMessageParam


def message_to_message_param(message: Message | dict[str, Any]) -> "ChatCompletionMessageParam":
    if isinstance(message, dict):
        return cast("ChatCompletionMessageParam", message)

    content = message.content
    if isinstance(content, list):
        content = safe_json_dumps(content, default="")

    param: dict[str, Any] = {
        "role": cast(Any, message.role),
        "content": content,
    }

    if message.tool_call_id is not None:
        param["tool_call_id"] = message.tool_call_id

    if message.tool_calls is not None:
        param["tool_calls"] = [tc for tc in message.tool_calls]

    return cast("ChatCompletionMessageParam", param)


class OpenAIChatClient(ChatClient):
    def __init__(self, api_key: str, model: str = "gpt-4o-mini", base_url: str | None = None):
        try:
            from openai import AsyncOpenAI
        except ImportError as e:
            raise ImportError(
                "openai is required for OpenAIChat. "
                "Install with: pip install 'knotaru-nlp[chat]'"
            ) from e

        self.client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self.model = model
        logger.debug("OpenAIChatClient initialized model=%s", model)

    async def chat(
        self,
        messages: History,
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> "ChatCompletion":
        logger.debug("chat model=%s messages=%d", self.model, len(messages))
        return await self.client.chat.completions.create(
            model=self.model,
            messages=[message_to_message_param(m) for m in messages],
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=kwargs.pop("top_p", None),
            frequency_penalty=kwargs.pop("frequency_penalty", None),
            presence_penalty=kwargs.pop("presence_penalty", None),
            stream=False,
            **kwargs,
        )

    async def chat_stream(
        self,
        messages: History,
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> AsyncIterator["ChatCompletionChunk"]:
        logger.debug("chat_stream model=%s messages=%d", self.model, len(messages))
        stream = await self.client.chat.completions.create(
            model=self.model,
            messages=[message_to_message_param(m) for m in messages],
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=kwargs.pop("top_p", None),
            frequency_penalty=kwargs.pop("frequency_penalty", None),
            presence_penalty=kwargs.pop("presence_penalty", None),
            stream=True,
            **kwargs,
        )
        async for chunk in stream:
            yield chunk
