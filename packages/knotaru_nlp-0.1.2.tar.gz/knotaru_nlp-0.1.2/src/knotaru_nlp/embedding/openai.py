"""OpenAI embedding implementation."""

from __future__ import annotations

import logging

from .base import BaseEmbedder, OpenAIEmbeddingResult

logger = logging.getLogger(__name__)


class OpenAIEmbedder(BaseEmbedder):
    """Embed text using the OpenAI Embeddings API.

    Args:
        api_key: OpenAI API key. Defaults to ``OPENAI_API_KEY`` env var.
        model: Embedding model to use.
        dimensions: Override output dimensions (only supported by v3 models).
        batch_size: Max texts per API call.

    Example::

        embedder = OpenAIEmbedder(model="text-embedding-3-small")
        results = await embedder.embed(["Hello", "World"])
    """

    def __init__(
        self,
        *,
        model: str,
        dimensions: int,
        api_key: str | None = None,
        batch_size: int = 512,
    ) -> None:
        try:
            from openai import AsyncOpenAI
        except ImportError as e:
            raise ImportError(
                "openai is required for OpenAIEmbedder. "
                "Install with: pip install 'knotaru-nlp[embedding]'"
            ) from e

        self._client = AsyncOpenAI(api_key=api_key)
        self._model = model
        self._dimensions = dimensions
        self._batch_size = batch_size
        logger.debug("OpenAIEmbedder initialized model=%s dim=%d batch_size=%d", model, dimensions, batch_size)

    @property
    def model(self) -> str:
        return self._model

    @property
    def dimensions(self) -> int:
        return self._dimensions

    async def embed(self, text: str) -> OpenAIEmbeddingResult:
        return (await self.embed_batch([text]))[0]

    async def embed_batch(self, texts: list[str]) -> list[OpenAIEmbeddingResult]:
        if not texts:
            return []

        logger.debug("embed_batch texts=%d batch_size=%d", len(texts), self._batch_size)
        results: list[OpenAIEmbeddingResult] = []

        # Process in batches
        for i in range(0, len(texts), self._batch_size):
            batch = texts[i : i + self._batch_size]
            response = await self._client.embeddings.create(
                model=self._model,
                input=batch,
                dimensions=self._dimensions
            )

            for j, embedding_data in enumerate(response.data):
                results.append(
                    OpenAIEmbeddingResult(
                        text=batch[j],
                        vector=embedding_data.embedding,
                        model=self._model,
                        token_count=response.usage.total_tokens // len(batch),
                    )
                )

        logger.debug("embed_batch completed total_results=%d", len(results))
        return results
