"""Abstract base class for embedding providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pydantic import BaseModel, Field
from typing import Any


class _EmbeddingResult(BaseModel):
    """Single embedding result."""

    text: str
    vector: list[float]
    model: str
    metadata: dict[str, Any] = Field(default_factory=dict)

class OpenAIEmbeddingResult(_EmbeddingResult):
    """Embedding result from OpenAI API."""
    token_count: int | None = None

EmbeddingResult = OpenAIEmbeddingResult

class BaseEmbedder(ABC):
    """Abstract embedding provider.

    All implementations must be async-native and return normalised float vectors.

    Usage::

        embedder = MyEmbedder(...)
        results = await embedder.embed(["text one", "text two"])
        single  = await embedder.embed_one("text one")
    """

    @property
    @abstractmethod
    def model(self) -> str:
        """Model identifier (e.g. 'text-embedding-3-small')."""

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Output vector dimensionality."""

    @abstractmethod
    async def embed_batch(self, texts: list[str]) -> list[EmbeddingResult]:
        """Embed a batch of texts.

        Args:
            texts: List of input strings. Empty strings are not allowed.

        Returns:
            List of :class:`EmbeddingResult` in the same order as *texts*.
        """

    @abstractmethod
    async def embed(self, text: str) -> EmbeddingResult:
        """Embed a single text.

        Args:
            text: Input string. Empty string is not allowed.

        Returns:
            An :class:`EmbeddingResult` for the input text.
        """
        return (await self.embed_batch([text]))[0]
