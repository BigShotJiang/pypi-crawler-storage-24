"""Embedding module — text → dense vector conversion.

Public API::

    from knotaru_nlp.embedding import BaseEmbedder, EmbeddingResult
    from knotaru_nlp.embedding import OpenAIEmbedder
"""

from .base import BaseEmbedder, EmbeddingResult
from .openai import OpenAIEmbedder

__all__ = [
    "BaseEmbedder",
    "EmbeddingResult",
    "OpenAIEmbedder",
]
