"""Neo4j graph implementation."""

from __future__ import annotations

import logging
import re
from typing import Any, cast
from knotaru_common.json import safe_json_loads, safe_json_dumps

from .base import BaseGraph
from .types import Direction, Entity, GraphSearchResult, Relationship, DirectionEnum
from ..filters import BaseFilter, FieldFilter, FilterConditionEnum, FilterOp

logger = logging.getLogger(__name__)

class Neo4jGraph(BaseGraph):
    """Knowledge graph backed by Neo4j (or any Neo4j-compatible backend).

    Entities are stored as ``:Entity`` nodes.  Relationships are stored as
    dynamically-typed edges where the Neo4j label is derived from the
    ``relation`` field (e.g. ``"works_at"`` → ``:WORKS_AT``), with ``relation``
    also stored as a property for round-trip fidelity.

    Indexes and uniqueness constraints are created automatically on first use.

    Args:
        uri: Bolt or neo4j URI (e.g. ``"bolt://localhost:7687"`` or
             ``"neo4j+s://….databases.neo4j.io"``).
        user: Neo4j username.
        password: Neo4j password.
        database: Target database (default: ``"neo4j"``).

    Example::

        graph = Neo4jGraph(
            uri="bolt://localhost:7687",
            user="neo4j",
            password="secret",
        )
        await graph.upsert_entities([Entity(id="e1", name="Alice", type="Person")])
        results = await graph.search_entities("Alice", agent_id="agent-1")
        await graph.close()
    """

    def __init__(
        self,
        uri: str | None = None,
        user: str | None = None,
        password: str | None = None,
        *,
        driver: Any | None = None,
        database: str = "neo4j",
    ) -> None:
        self._database = database
        self._initialized = False

        if driver is not None:
            try:
                from neo4j import AsyncDriver  # type: ignore[import-untyped]
                if not isinstance(driver, AsyncDriver):
                    raise TypeError(
                        f"driver must be a Neo4j AsyncDriver, got {type(driver).__name__}"
                    )
            except ImportError:
                pass  # neo4j not installed; trust the caller
            self._driver = driver
        else:
            if not all([uri, user, password]):
                raise ValueError(
                    "Neo4jGraph requires either a pre-built 'driver' or all of "
                    "'uri', 'user', and 'password' connection arguments."
                )
            try:
                from neo4j import AsyncGraphDatabase  # type: ignore[import-untyped]
            except ImportError as e:
                raise ImportError(
                    "neo4j is required for Neo4jGraph. "
                    "Install with: pip install 'knotaru-nlp[graph-neo4j]'"
                ) from e
            self._driver = AsyncGraphDatabase.driver(uri or '', auth=(user or '', password or ''))
        logger.debug("Neo4jGraph initialized database=%s", database)

    async def close(self) -> None:
        """Close the driver and release all connections."""
        await self._driver.close()

    # ------------------------------------------------------------------ #
    # BaseGraph interface — writes                                          #
    # ------------------------------------------------------------------ #

    async def upsert_entities(self, entities: list[Entity]) -> None:
        logger.debug("upsert_entities count=%d", len(entities))
        await self._ensure_indexes()
        # Two-step SET: first replace all properties with the base set (which
        # removes any stale prop_* keys from a prior upsert), then merge in
        # the new flat properties for sub-field filtering.
        query = """
            UNWIND $entities AS e
            MERGE (n:Entity {id: e.id})
            SET n = {id: e.id, name: e.name, type: e.type, properties: e.properties}
            SET n += e.flat_props
        """
        data = []
        for entity in entities:
            d = entity.to_dict(stringify_properties=True)
            def _is_scalar_list(v: Any) -> bool:
                return isinstance(v, list) and all(isinstance(x, (str, int, float, bool)) for x in v)
            
            d["flat_props"] = {
                f"prop_{k}": v
                for k, v in entity.properties.items()
                if isinstance(v, (str, int, float, bool)) or _is_scalar_list(v)
            }
            data.append(d)
        async with self._driver.session(database=self._database) as session:
            result = await session.run(query, entities=data)
            await result.consume()

    async def upsert_relationships(self, relationships: list[Relationship]) -> None:
        logger.debug("upsert_relationships count=%d", len(relationships))
        await self._ensure_indexes()
        # Cypher does not support parameterised relationship types, so we
        # sanitise the label and interpolate it directly into the query string.
        async with self._driver.session(database=self._database) as session:
            for r in relationships:
                label = re.sub(r"[^A-Z0-9_]", "_", r.relation.upper())
                props = safe_json_dumps(r.properties, default="{}") if r.properties else "{}"
                query = f"""
                    MATCH (src:Entity {{id: $source_id}})
                    MATCH (tgt:Entity {{id: $target_id}})
                    MERGE (src)-[rel:{label}]->(tgt)
                    ON CREATE SET rel.id = $id
                    SET rel.relation   = $relation,
                        rel.properties = $properties
                """
                result = await session.run(
                    cast(Any, query),
                    source_id=r.source_id,
                    target_id=r.target_id,
                    id=r.id,
                    relation=r.relation,
                    properties=props,
                )
                await result.consume()

    # ------------------------------------------------------------------ #
    # BaseGraph interface — reads                                           #
    # ------------------------------------------------------------------ #

    async def get_entity(self, entity_id: str) -> Entity | None:
        query = "MATCH (e:Entity {id: $id}) RETURN e"
        async with self._driver.session(database=self._database) as session:
            result = await session.run(query, id=entity_id)
            record = await result.single(strict=False)
        if record is None:
            return None
        return self._parse_entity(record["e"])
    
    async def get_relationships(
        self,
        entity_id: str,
        *,
        direction: Direction = DirectionEnum.BOTH.value,
    ) -> list[Relationship]:
        if direction == DirectionEnum.OUTGOING.value:
            pattern = "(e:Entity {id: $id})-[r]->()"
        elif direction == DirectionEnum.INCOMING.value:
            pattern = "(e:Entity {id: $id})<-[r]-()"
        else:
            pattern = "(e:Entity {id: $id})-[r]-()"

        query = f"""
        MATCH {pattern}
        RETURN r.id AS id,
               r.relation AS relation,
               r.properties AS properties,
               startNode(r).id AS source_id,
               endNode(r).id AS target_id
        """
        async with self._driver.session(database=self._database) as session:
            result = await session.run(query, id=entity_id)
            records = await result.data()

        relationships = []
        for rec in records:
            r = {
                "id": rec.get("id"),
                "relation": rec.get("relation"),
                "properties": rec.get("properties"),
            }
            source_id = rec["source_id"]
            target_id = rec["target_id"]
            relationships.append(self._parse_relationship(r, source_id, target_id))
        
        return relationships
            
    async def search_entities(
        self,
        *,
        entity_name: str | None = None,
        entity_type: str | None = None,
        top_k: int = 10,
        filter: BaseFilter | None = None,
    ) -> list[GraphSearchResult]:
        logger.debug("search_entities name=%r type=%r top_k=%d", entity_name, entity_type, top_k)
        params: dict[str, Any] = {
            "entity_name": entity_name,
            "entity_type": entity_type,
            "top_k": top_k,
        }

        extra_clause = ""
        if filter and not filter.is_empty():
            expr, extra_params = self._build_cypher_filter(filter, prefix="f")
            params.update(extra_params)
            if expr:
                extra_clause = f"\n          AND ({expr})"

        cypher = f"""
            MATCH (e:Entity)
            WHERE ($entity_name IS NULL OR toLower(e.name) CONTAINS toLower($entity_name))
            AND ($entity_type IS NULL OR e.type       = $entity_type){extra_clause}
            RETURN e
            LIMIT $top_k
        """

        async with self._driver.session(database=self._database) as session:
            result = await session.run(cast(Any, cypher), **params)
            records = await result.data()

        graph_results: list[GraphSearchResult] = []
        for rec in records:
            entity = self._parse_entity(rec["e"])
            relationships = await self.get_relationships(entity.id)
            graph_results.append(GraphSearchResult(entity=entity, relationships=relationships))

        return graph_results

    # ------------------------------------------------------------------ #
    # BaseGraph interface — deletes                                         #
    # ------------------------------------------------------------------ #

    async def delete_entities(self, ids: list[str]) -> None:
        """Delete entities and all their attached relationships (DETACH DELETE)."""
        query = "MATCH (e:Entity) WHERE e.id IN $ids DETACH DELETE e"
        async with self._driver.session(database=self._database) as session:
            result = await session.run(query, ids=ids)
            await result.consume()

    async def delete_relationships(self, ids: list[str]) -> None:
        query = "MATCH ()-[r]-() WHERE r.id IN $ids DELETE r"
        async with self._driver.session(database=self._database) as session:
            result = await session.run(query, ids=ids)
            await result.consume()

    async def reset(self) -> None:
        """Delete all Entity nodes and RELATES_TO relationships."""
        query = "MATCH (e:Entity) DETACH DELETE e"
        async with self._driver.session(database=self._database) as session:
            result = await session.run(query)
            await result.consume()

    # ------------------------------------------------------------------ #
    # Schema bootstrap                                                      #
    # ------------------------------------------------------------------ #

    async def _ensure_indexes(self) -> None:
        """Create uniqueness constraints and indexes on first use.

        All statements use ``IF NOT EXISTS`` so they are safe to run repeatedly.
        """
        if self._initialized:
            return

        logger.debug("creating Neo4j indexes and constraints")
        statements = [
            # Unique constraint on Entity.id (implicitly creates a B-tree index)
            "CREATE CONSTRAINT entity_id_unique IF NOT EXISTS "
            "FOR (e:Entity) REQUIRE e.id IS UNIQUE",
            # B-tree index for name CONTAINS searches
            "CREATE INDEX entity_name_index IF NOT EXISTS "
            "FOR (e:Entity) ON (e.name)",
        ]

        async with self._driver.session(database=self._database) as session:
            for stmt in statements:
                result = await session.run(cast(Any, stmt))
                await result.consume()

        self._initialized = True

    # ------------------------------------------------------------------ #
    # Serialisation / deserialisation                                       #
    # ------------------------------------------------------------------ #
    
    @staticmethod
    def _parse_entity(node: Any) -> Entity:
        raw = node.get("properties", "{}")
        props: dict[str, Any] = Neo4jGraph._parse_properties(raw)
        return Entity(
            id=node["id"],
            name=node["name"],
            type=node.get("type", "Other"),
            properties=props,
        )

    @staticmethod
    def _parse_relationship(rel: Any, source_id: str, target_id: str) -> Relationship:
        raw = rel.get("properties", "{}")
        props: dict[str, Any] = Neo4jGraph._parse_properties(raw)
        return Relationship(
            id=rel["id"],
            source_id=source_id,
            target_id=target_id,
            relation=rel.get("relation", "related_to"),
            properties=props,
        )

    @staticmethod
    def _parse_properties(raw: Any) -> dict[str, Any]:
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, str):
            parsed = safe_json_loads(raw, default={})
            return parsed if isinstance(parsed, dict) else {}
        
        return {}

    # ------------------------------------------------------------------ #
    # Filter → Cypher translation                                          #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_cypher_filter(
        filter: BaseFilter, *, prefix: str
    ) -> tuple[str, dict[str, Any]]:
        """Recursively translate a :class:`~knotaru_nlp.filters.BaseFilter` to
        a Cypher boolean expression and a matching parameter dict.

        Fields are mapped to top-level node properties (``e.<field>``).
        """
        parts: list[str] = []
        params: dict[str, Any] = {}

        for i, clause in enumerate(filter.metadata):
            clause_prefix = f"{prefix}_{i}"
            if isinstance(clause, FieldFilter):
                param_name = clause_prefix
                field = clause.field
                value = clause.value
                if field.startswith("properties."):
                    subfield = field[len("properties."):]
                    field_ref = f"e.prop_{subfield}"
                else:
                    field_ref = f"e.{field}"
                    if isinstance(value, dict):
                        value = safe_json_dumps(value, sort_keys=True)
                params[param_name] = value
                expr = Neo4jGraph._field_to_cypher_expr(field_ref, clause.op, f"${param_name}")
                if expr:
                    parts.append(expr)
            elif isinstance(clause, BaseFilter):
                inner_expr, inner_params = Neo4jGraph._build_cypher_filter(
                    clause, prefix=clause_prefix
                )
                params.update(inner_params)
                if inner_expr:
                    parts.append(f"({inner_expr})")

        if not parts:
            return "", {}

        joiner = " AND " if filter.logic == FilterConditionEnum.AND.value else " OR "
        return joiner.join(parts), params

    @staticmethod
    def _field_to_cypher_expr(field_ref: str, op: FilterOp, param_ref: str) -> str:
        match op:
            case FilterOp.EQ:
                return f"{field_ref} = {param_ref}"
            case FilterOp.NEQ:
                return f"{field_ref} <> {param_ref}"
            case FilterOp.IN:
                return f"{field_ref} IN {param_ref}"
            case FilterOp.NIN:
                return f"NOT {field_ref} IN {param_ref}"
            case FilterOp.CONTAINS_ANY:
                return f"ANY(x IN {field_ref} WHERE x IN {param_ref})"
            case FilterOp.GT:
                return f"{field_ref} > {param_ref}"
            case FilterOp.GTE:
                return f"{field_ref} >= {param_ref}"
            case FilterOp.LT:
                return f"{field_ref} < {param_ref}"
            case FilterOp.LTE:
                return f"{field_ref} <= {param_ref}"
            case _:
                return ""
