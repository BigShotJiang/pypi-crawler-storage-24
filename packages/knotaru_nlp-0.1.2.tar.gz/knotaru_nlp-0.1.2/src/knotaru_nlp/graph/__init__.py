"""Graph module — knowledge graph storage for entity and relationship memory.

Public API::

    from knotaru_nlp.graph import BaseGraph, Entity, Relationship, GraphSearchResult
    from knotaru_nlp.graph import Neo4jGraph  # requires knotaru-nlp[graph-neo4j]
"""

from .base import BaseGraph
from .neo4j import Neo4jGraph
from .types import Direction, DirectionEnum, Entity, GraphSearchResult, Relationship

__all__ = [
    "BaseGraph",
    "Entity",
    "Relationship",
    "GraphSearchResult",
    "Direction",
    "DirectionEnum",
    "Neo4jGraph",
]
