"""Shared data models for graph storage — nodes, edges, and search results."""

from __future__ import annotations

from typing import Any, Literal, Optional
from enum import Enum
from pydantic import BaseModel, Field
from knotaru_common.json import safe_json_loads, safe_json_dumps

Direction = Literal["outgoing", "incoming", "both"]
class DirectionEnum(str, Enum):
    """Edge direction for graph queries."""

    OUTGOING = "outgoing"
    INCOMING = "incoming"
    BOTH = "both"


class Entity(BaseModel):
    """A generic graph node — carries no domain-specific scoping.

    Args:
        id: Unique identifier (UUID recommended).
        name: Human-readable entity name (e.g. ``"Alice"``).
        type: Semantic category (e.g. ``"Person"``, ``"Organization"``).
        properties: Arbitrary additional attributes.
    """

    id: str
    name: str
    type: str
    properties: dict[str, Any] = Field(default_factory=dict)

    def to_dict(self, stringify_properties: Optional[bool] = False) -> dict[str, Any]:
        """Convert to a plain dict for API responses."""
        if stringify_properties:
            base = self.model_dump()
            base['properties'] = safe_json_dumps(self.properties, default="{}", sort_keys=True) if self.properties else "{}"
            return base
        
        return self.model_dump()


class Relationship(BaseModel):
    """A generic directed graph edge — carries no domain-specific scoping.

    Args:
        id: Unique identifier (UUID recommended).
        source_id: ID of the source :class:`Entity`.
        target_id: ID of the target :class:`Entity`.
        relation: Semantic relationship label (e.g. ``"works_at"``, ``"knows"``).
        properties: Arbitrary additional attributes.
    """

    id: str
    source_id: str
    target_id: str
    relation: str
    properties: dict[str, Any] = Field(default_factory=dict)

    def to_dict(self, stringify_properties: Optional[bool] = False) -> dict[str, Any]:
        """Convert to a plain dict for API responses."""
        if stringify_properties:
            base = self.model_dump()
            base['properties'] = safe_json_dumps(self.properties, default="{}", sort_keys=True) if self.properties else "{}"
            return base
        
        return self.model_dump()

class GraphSearchResult(BaseModel):
    """A single entity returned by a graph search, with its edges.

    Args:
        entity: The matched entity node.
        relationships: Edges connected to this entity (may be filtered by direction).
    """

    entity: Entity
    relationships: list[Relationship] = Field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dict for API responses."""
        return {
            "entity": self.entity.to_dict(),
            "relationships": [rel.to_dict() for rel in self.relationships],
        }
