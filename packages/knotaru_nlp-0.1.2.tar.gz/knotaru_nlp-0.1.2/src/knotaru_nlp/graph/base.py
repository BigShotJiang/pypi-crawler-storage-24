"""Abstract base class for graph database providers.

A graph stores *entities* (nodes) and *relationships* (directed edges)
extracted from conversation history.  Implementations can wrap Neo4j,
Memgraph, NetworkX in-memory graphs, or any other graph backend.

Usage::

    graph = MyGraph(...)
    await graph.upsert_entities([Entity(id="e1", name="Alice", type="Person")])
    await graph.upsert_relationships([
        Relationship(id="r1", source_id="e1", target_id="e2", relation="works_at")
    ])
    results = await graph.search_entities("Alice")
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from ..filters import BaseFilter
from .types import Direction, DirectionEnum, Entity, GraphSearchResult, Relationship


class BaseGraph(ABC):
    """Abstract knowledge graph client.

    All methods are async.  Implementations wrap their backend
    (Neo4j Bolt driver, in-memory dict, etc.) and must be safe to
    call concurrently.

    Usage::

        graph = MyGraph(...)

        # Store extracted knowledge
        await graph.upsert_entities([Entity(id="e1", name="Alice", type="Person")])
        await graph.upsert_relationships([
            Relationship(id="r1", source_id="e1", target_id="e2", relation="knows")
        ])

        # Retrieve context
        results = await graph.search_entities("Alice", agent_id="agent-1")
        for r in results:
            print(r.entity.name, [rel.relation for rel in r.relationships])
    """

    # ------------------------------------------------------------------ #
    # Writes                                                               #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def upsert_entities(self, entities: list[Entity]) -> None:
        """Insert or update entities.  Existing IDs are overwritten.

        Args:
            entities: Nodes to upsert.
        """

    @abstractmethod
    async def upsert_relationships(self, relationships: list[Relationship]) -> None:
        """Insert or update relationships.  Existing IDs are overwritten.

        Args:
            relationships: Edges to upsert.
        """

    # ------------------------------------------------------------------ #
    # Reads                                                                #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def get_entity(self, entity_id: str) -> Entity | None:
        """Fetch a single entity by ID.  Returns ``None`` if not found."""

    async def get_entities_with_relationships(
        self, entity_ids: list[str]
    ) -> list[GraphSearchResult]:
        """Fetch multiple entities with their relationships in one call.

        The default implementation calls :meth:`get_entity` and
        :meth:`get_relationships` concurrently for every ID.  Subclasses may
        override this with a single backend query for better efficiency.
        Entities not found in the graph are omitted from the result.

        Args:
            entity_ids: IDs to fetch.

        Returns:
            One :class:`~.types.GraphSearchResult` per found entity, in the
            same order as *entity_ids* (missing entities excluded).
        """
        if not entity_ids:
            return []
        entities, rels_lists = await asyncio.gather(
            asyncio.gather(*[self.get_entity(eid) for eid in entity_ids]),
            asyncio.gather(*[self.get_relationships(eid) for eid in entity_ids]),
        )
        return [
            GraphSearchResult(entity=entity, relationships=rels)
            for entity, rels in zip(entities, rels_lists)
            if entity is not None
        ]

    @abstractmethod
    async def get_relationships(
        self,
        entity_id: str,
        *,
        direction: Direction = DirectionEnum.BOTH.value,
    ) -> list[Relationship]:
        """Get all relationships connected to an entity.

        Args:
            entity_id: ID of the entity to query.
            direction: Which edges to include — outgoing (entity is source),
                incoming (entity is target), or both.

        Returns:
            List of matching :class:`Relationship` objects.
        """

    @abstractmethod
    async def search_entities(
        self,
        *,
        entity_name: str | None = None,
        entity_type: str | None = None,
        top_k: int = 10,
        filter: BaseFilter | None = None,
    ) -> list[GraphSearchResult]:
        """Search for entities by name or properties.

        Implementations should at minimum do a case-insensitive name match
        and optionally full-text or fuzzy matching on properties.

        Args:
            query: Search term (entity name or keyword).
            entity_type: Restrict to a specific entity type (e.g. ``"Person"``).
            top_k: Maximum number of entities to return.
            filter: Optional :class:`~knotaru_nlp.filters.BaseFilter` to
                restrict the result scope.

        Returns:
            Matched entities, each paired with their connected relationships,
            ordered by relevance descending.
        """

    # ------------------------------------------------------------------ #
    # Deletes                                                              #
    # ------------------------------------------------------------------ #

    @abstractmethod
    async def delete_entities(self, ids: list[str]) -> None:
        """Delete entities by ID.

        Implementations should also delete any relationships whose
        ``source_id`` or ``target_id`` matches a deleted entity.
        """

    @abstractmethod
    async def delete_relationships(self, ids: list[str]) -> None:
        """Delete relationships by ID."""

    @abstractmethod
    async def reset(self) -> None:
        """Delete all entities and relationships in the graph."""
