"""Type-safe filter expressions for index and memory queries.

Filters flow from high-level queries down to backend-specific query languages
(Milvus boolean expressions, Cypher WHERE clauses, etc.).

Example::

    from knotaru_nlp.filters import BaseFilter, FieldFilter, FilterOp

    f = BaseFilter(
        metadata=[
            FieldFilter(field="topic", op=FilterOp.IN, value=["sports", "tech"]),
            FieldFilter(field="confidence", op=FilterOp.GTE, value=0.8),
        ],
    )
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


class FilterOp(str, Enum):
    """Comparison operators for field-level filters."""

    EQ = "eq"                      # ==  exact match
    NEQ = "neq"                    # !=  not equal
    IN = "in"                      # scalar field value is one of a list
    NIN = "nin"                    # scalar field value is NOT one of a list
    CONTAINS_ANY = "contains_any"  # list field contains any element from the provided list
    GT = "gt"                      # >
    GTE = "gte"                    # >=
    LT = "lt"                      # <
    LTE = "lte"                    # <=

FilterCondition = Literal["and", "or"]
class FilterConditionEnum(str, Enum):
    """Logical conditions for combining multiple filters."""

    AND = "and"
    OR = "or"

class FieldFilter(BaseModel):
    """A filter applied to a single field.

    Args:
        field: Field key (e.g. ``"topic"``).
        op: Comparison operator.
        value: Scalar value for EQ/NEQ/GT/GTE/LT/LTE; list for IN/NIN.

    Example::

        FieldFilter(field="role", op=FilterOp.IN, value=["user", "assistant"])
        FieldFilter(field="score", op=FilterOp.GTE, value=0.9)
        FieldFilter(field="agent_id", op=FilterOp.EQ, value="a1")
    """

    field: str
    op: FilterOp
    value: Any  # scalar or list[scalar]


class BaseFilter(BaseModel):
    """Generic, backend-agnostic filter.

    Each item in ``metadata`` is either a :class:`FieldFilter` (a leaf predicate)
    or a nested :class:`BaseFilter` (a group of predicates with its own ``logic``).
    This lets you build arbitrary boolean trees.

    Subclass this to add domain-specific scope fields (see
    :class:`~knotaru_nlp.memory.filters.MemoryFilter`).

    Args:
        metadata: Predicates — mix of :class:`FieldFilter` leaves and nested
            :class:`BaseFilter` groups.
        logic: How to combine the top-level items — ``"and"`` or ``"or"``.

    Example::

        # agent_id = "x"  OR  session_id = "y"  OR  (name = "Alice" AND type = "Person")
        BaseFilter(
            logic="or",
            metadata=[
                FieldFilter(field="agent_id",   op=FilterOp.EQ, value="x"),
                FieldFilter(field="session_id", op=FilterOp.EQ, value="y"),
                BaseFilter(
                    logic="and",
                    metadata=[
                        FieldFilter(field="name", op=FilterOp.EQ, value="Alice"),
                        FieldFilter(field="type", op=FilterOp.EQ, value="Person"),
                    ],
                ),
            ],
        )
    """

    # Recursive: each clause is either a leaf FieldFilter or a nested group.
    # Pydantic resolves the forward reference after model_rebuild() below.
    metadata: list[FieldFilter | BaseFilter] = Field(default_factory=list)
    logic: FilterCondition = FilterConditionEnum.AND.value

    def is_empty(self) -> bool:
        """Return ``True`` if no predicates are set."""
        return not self.metadata


# Required by Pydantic v2 to resolve the self-referential annotation above.
BaseFilter.model_rebuild()
