# knotaru-nlp

Modular NLP primitives for Knotaru. Each module is independently installable and built around abstract base classes so implementations can be swapped without changing application code.

## Modules

| Module      | Purpose                      | Extra         |
| ----------- | ---------------------------- | ------------- |
| `embedding` | Convert text → dense vectors | `[embedding]` |
| `indexing`  | Store and query vectors      | `[indexing]`  |
| `chat`      | LLM completions              | `[chat]`      |

## Installation

```bash
# All modules
pip install "knotaru-nlp[all]"

# Individual modules
pip install "knotaru-nlp[embedding]"
pip install "knotaru-nlp[indexing]"
pip install "knotaru-nlp[chat]"
```

## Quick Start

```python
from knotaru_nlp.embedding import OpenAIEmbedder
from knotaru_nlp.indexing import MilvusIndex
from knotaru_nlp.chat import OpenAIChat

# Embedding
embedder = OpenAIEmbedder(api_key="sk-...")
vectors = await embedder.embed(["Hello world", "Knotaru rocks"])

# Indexing (Milvus test)
index = MilvusIndex(dim=1536)
await index.upsert([{"id": "1", "vector": vectors[0], "text": "Hello world"}])
results = await index.search(vectors[0], top_k=5)

# Chat
chat = OpenAIChat(api_key="sk-...")
response = await chat.complete([{"role": "user", "content": "Hello!"}])
```

## Design Principles

- **Abstract-first**: Every module exports an abstract base class. Swap implementations by changing one line.
- **Async-native**: All I/O methods are `async`.
- **Zero mandatory deps**: Core package installs with no heavy dependencies. Add only what you use via extras.
- **Typed**: Full `mypy --strict` compliance.
