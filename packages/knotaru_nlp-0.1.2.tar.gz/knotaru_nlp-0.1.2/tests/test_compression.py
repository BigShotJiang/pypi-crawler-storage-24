"""Tests for the chat compression module."""

from __future__ import annotations

from typing import Any, AsyncIterator
from unittest.mock import AsyncMock

import pytest

from knotaru_nlp.chat.base import ChatClient
from knotaru_nlp.chat.classes.messaging import History, Message, MessageRole, MessageRoleEnum
from knotaru_nlp.compression import (
    BudgetConfig,
    BudgetUsage,
    CompressionResult,
    SlidingWindowCompressor,
    SlidingWindowConfig,
    SummarizeCompressor,
    SummarizeConfig,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_message(role: MessageRole, content: str, idx: int) -> Message:
    """Build a Message with a valid message_id."""
    return Message(message_id=f"msg{idx:03d}", role=role, content=content)


def make_history(n_user_turns: int, system: bool = True) -> History:
    """Build a history with alternating user/assistant turns and an optional system message."""
    history: History = []
    if system:
        history.append(make_message(MessageRoleEnum.SYSTEM.value, "You are a helpful assistant.", 0))
    for i in range(n_user_turns):
        history.append(make_message("user", f"User message {i}", i * 2 + 1))
        history.append(make_message("assistant", f"Assistant reply {i}", i * 2 + 2))
    return history


class _MockChatClient(ChatClient):
    """Minimal ChatClient that returns a fixed string response."""

    def __init__(self, response: str = "Mock summary of the conversation.") -> None:
        self._response = response

    async def chat(
        self,
        messages: History,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> str:
        return self._response

    async def chat_stream(
        self,
        messages: History,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        yield self._response


class _FailingChatClient(ChatClient):
    """ChatClient that always raises an exception."""

    async def chat(
        self,
        messages: History,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> str:
        raise RuntimeError("LLM unavailable")

    async def chat_stream(
        self,
        messages: History,
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        raise RuntimeError("LLM unavailable")
        yield  # pragma: no cover


# ---------------------------------------------------------------------------
# SlidingWindowCompressor tests
# ---------------------------------------------------------------------------


class TestSlidingWindowCompressor:
    async def test_no_compression_needed(self) -> None:
        """History under budget is returned unchanged."""
        history = make_history(5)  # 11 messages total (1 system + 10 turns)
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=20))
        )
        result = await compressor.compress(history)

        assert isinstance(result, CompressionResult)
        assert result.history == history
        assert result.stats.original_count == len(history)
        assert result.stats.compressed_count == len(history)
        assert result.stats.messages_dropped == 0
        assert result.stats.was_summarized is False
        assert result.summary is None

    async def test_trims_oldest_turns(self) -> None:
        """Oldest non-system messages are dropped to fit the budget."""
        history = make_history(10)  # 21 messages: 1 system + 20 turns
        budget = BudgetConfig(max_messages=6)
        compressor = SlidingWindowCompressor(SlidingWindowConfig(budget=budget))
        result = await compressor.compress(history)

        # System message always preserved, + last 6 turns kept
        assert result.stats.was_summarized is False
        assert result.stats.messages_dropped > 0

        roles = [m.role for m in result.history]
        assert roles[0] == MessageRoleEnum.SYSTEM.value

        # No more than budget.max_messages non-system messages
        non_system = [m for m in result.history if m.role != MessageRoleEnum.SYSTEM.value]
        assert len(non_system) == budget.max_messages

    async def test_preserve_system_true_keeps_system_messages(self) -> None:
        """System messages are retained regardless of window size."""
        history = make_history(10, system=True)
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(
                budget=BudgetConfig(max_messages=4),
                preserve_system=True,
            )
        )
        result = await compressor.compress(history)

        system_count = sum(1 for m in result.history if m.role == MessageRoleEnum.SYSTEM.value)
        assert system_count == 1  # original system message preserved

    async def test_preserve_system_false_drops_system_messages(self) -> None:
        """With preserve_system=False system messages are included in the window budget."""
        history = make_history(5, system=True)
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(
                budget=BudgetConfig(max_messages=4),
                preserve_system=False,
            )
        )
        result = await compressor.compress(history)

        assert len(result.history) == 4
        assert result.stats.messages_dropped == len(history) - 4

    async def test_empty_history(self) -> None:
        """Empty history is returned as-is."""
        compressor = SlidingWindowCompressor()
        result = await compressor.compress([])

        assert result.history == []
        assert result.stats.messages_dropped == 0

    async def test_default_config(self) -> None:
        """Default config (max_messages=20) is used when none is provided."""
        compressor = SlidingWindowCompressor()
        history = make_history(5)
        result = await compressor.compress(history)

        assert result.stats.messages_dropped == 0

    async def test_stats_consistency(self) -> None:
        """compressed_count + messages_dropped == original_count."""
        history = make_history(15)
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=8))
        )
        result = await compressor.compress(history)

        assert result.stats.compressed_count + result.stats.messages_dropped == result.stats.original_count


# ---------------------------------------------------------------------------
# SummarizeCompressor tests
# ---------------------------------------------------------------------------


MOCK_SUMMARY = "The user asked about Python best practices. The assistant explained PEP 8."


class TestSummarizeCompressor:
    async def test_no_compression_needed(self) -> None:
        """History under budget is returned unchanged, no LLM call made."""
        client = AsyncMock(spec=ChatClient)
        history = make_history(3)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(budget=BudgetConfig(max_messages=20)),
        )
        result = await compressor.compress(history)

        assert result.history == history
        assert result.stats.messages_dropped == 0
        assert result.stats.was_summarized is False
        assert result.summary is None
        client.chat.assert_not_called()

    async def test_summary_injected_as_system_message(self) -> None:
        """LLM summary is wrapped in a system message prefixed with [Conversation Summary]."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(10)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=5),
                recent_window=4,
            ),
        )
        result = await compressor.compress(history)

        assert result.stats.was_summarized is True
        assert result.summary == MOCK_SUMMARY

        summary_msgs = [
            m for m in result.history if "[Conversation Summary]" in m.content
        ]
        assert len(summary_msgs) == 1
        assert summary_msgs[0].role == MessageRoleEnum.SYSTEM.value

    async def test_recent_messages_kept_verbatim(self) -> None:
        """The last recent_window non-system messages appear verbatim at the end."""
        client = _MockChatClient(MOCK_SUMMARY)
        recent_window = 4
        history = make_history(10)
        turns = [m for m in history if m.role != MessageRoleEnum.SYSTEM.value]
        expected_kept = turns[-recent_window:]

        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=5),
                recent_window=recent_window,
            ),
        )
        result = await compressor.compress(history)

        result_turns = [m for m in result.history if m.role != MessageRoleEnum.SYSTEM.value and "[Conversation Summary]" not in m.content]
        assert result_turns == expected_kept

    async def test_original_system_messages_preserved(self) -> None:
        """Original system messages from history are kept with preserve_system=True."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(10, system=True)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=5),
                recent_window=3,
                preserve_system=True,
            ),
        )
        result = await compressor.compress(history)

        system_msgs = [m for m in result.history if m.role == MessageRoleEnum.SYSTEM.value]
        # At least two: original system message + summary message
        assert len(system_msgs) >= 2
        original_system = next(m for m in system_msgs if "[Conversation Summary]" not in m.content)
        assert "helpful assistant" in original_system.content

    async def test_system_messages_dropped_when_preserve_false(self) -> None:
        """With preserve_system=False original system messages are not included."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(10, system=True)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=5),
                recent_window=3,
                preserve_system=False,
            ),
        )
        result = await compressor.compress(history)

        original_system_msgs = [
            m for m in result.history
            if m.role == MessageRoleEnum.SYSTEM.value and "[Conversation Summary]" not in m.content
        ]
        assert original_system_msgs == []

    async def test_llm_failure_falls_back_to_sliding_window(self) -> None:
        """If the LLM call raises, the result falls back to sliding-window truncation."""
        client = _FailingChatClient()
        history = make_history(15)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=8),
                recent_window=4,
            ),
        )
        result = await compressor.compress(history)

        assert result.stats.was_summarized is False
        assert result.summary is None
        # Still compressed — sliding window applied
        assert len(result.history) < len(history)

    async def test_recent_window_larger_than_turns_falls_back(self) -> None:
        """When recent_window >= number of turns, nothing to summarize; uses sliding window."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(5)  # 10 non-system turns
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=3),
                recent_window=20,  # larger than number of turns
            ),
        )
        result = await compressor.compress(history)

        assert result.stats.was_summarized is False

    async def test_stats_consistency(self) -> None:
        """compressed_count + messages_dropped == original_count."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(15)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=8),
                recent_window=4,
            ),
        )
        result = await compressor.compress(history)

        assert (
            result.stats.compressed_count + result.stats.messages_dropped
            == result.stats.original_count
        )

    async def test_custom_string_prompt(self) -> None:
        """A plain string summary_prompt with {conversation} is accepted."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(10)
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=5),
                recent_window=3,
                summary_prompt="Summarize this: {conversation}",
            ),
        )
        result = await compressor.compress(history)

        assert result.stats.was_summarized is True


# ---------------------------------------------------------------------------
# force=True tests
# ---------------------------------------------------------------------------


class TestForceCompression:
    async def test_sliding_window_force_compresses_under_budget(self) -> None:
        """force=True triggers truncation even when the history is under budget."""
        history = make_history(3)  # 7 messages, well under default budget of 20
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=20))
        )
        result = await compressor.compress(history, force=True)

        # Compression ran: kept only the last 20 non-system turns (all of them),
        # but the no-compression guard was bypassed.
        assert result.stats.original_count == len(history)
        # With force and preserve_system, we get system_msgs + all turns
        # (max_messages=20 > actual turns so nothing dropped, but force ran)
        assert result.stats.messages_dropped == 0  # under budget so nothing actually dropped

    async def test_sliding_window_force_drops_messages_with_tight_budget(self) -> None:
        """force=True with a tight budget drops messages even when total is under max_messages."""
        history = make_history(4)  # 9 messages
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=4))
        )
        # Without force, 9 > 4 → would compress anyway.
        # Use a budget larger than history to prove force bypasses the guard:
        compressor2 = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=6))
        )
        # history has 8 non-system turns + 1 system = 9 total, budget=6 for turns
        result = await compressor2.compress(history, force=True)

        non_system = [m for m in result.history if m.role != MessageRoleEnum.SYSTEM.value]
        assert len(non_system) == 6

    async def test_summarize_force_compresses_under_budget(self) -> None:
        """force=True on SummarizeCompressor summarizes even when under budget."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(5)  # 11 messages, under default budget of 20
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(
                budget=BudgetConfig(max_messages=20),
                recent_window=4,
            ),
        )
        result = await compressor.compress(history, force=True)

        # 10 turns, recent_window=4 → 6 turns to summarize, 4 to keep
        assert result.stats.was_summarized is True
        assert result.summary == MOCK_SUMMARY


# ---------------------------------------------------------------------------
# BudgetUsage tests
# ---------------------------------------------------------------------------


class TestBudgetUsage:
    def test_under_budget_message_fields(self) -> None:
        """budget_usage returns correct counts when under budget."""
        history = make_history(3)  # 7 messages
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=20))
        )
        usage = compressor.budget_usage(history)

        assert isinstance(usage, BudgetUsage)
        assert usage.used_messages == len(history)
        assert usage.max_messages == 20
        assert usage.pct_messages_used == pytest.approx(len(history) / 20)
        assert usage.needs_compression is False

    def test_over_budget_needs_compression_true(self) -> None:
        """needs_compression is True when history exceeds the message budget."""
        history = make_history(15)  # 31 messages, over budget of 20
        compressor = SlidingWindowCompressor(
            SlidingWindowConfig(budget=BudgetConfig(max_messages=20))
        )
        usage = compressor.budget_usage(history)

        assert usage.needs_compression is True
        assert usage.pct_messages_used > 1.0

    def test_token_fields_none_when_no_token_budget(self) -> None:
        """Token fields are None when max_tokens is not configured."""
        history = make_history(5)
        compressor = SlidingWindowCompressor()
        usage = compressor.budget_usage(history)

        assert usage.used_tokens is None
        assert usage.max_tokens is None
        assert usage.pct_tokens_used is None

    def test_token_stats_none_in_compression_result_when_no_token_budget(self) -> None:
        """CompressionStats token fields are None when max_tokens is not set."""
        history = make_history(3)
        compressor = SlidingWindowCompressor()

        import asyncio

        result = asyncio.get_event_loop().run_until_complete(compressor.compress(history))
        assert result.stats.original_tokens is None
        assert result.stats.compressed_tokens is None

    def test_summarize_compressor_budget_usage(self) -> None:
        """budget_usage works correctly on SummarizeCompressor."""
        client = _MockChatClient(MOCK_SUMMARY)
        history = make_history(8)  # 17 messages
        compressor = SummarizeCompressor(
            chat=client,
            config=SummarizeConfig(budget=BudgetConfig(max_messages=20)),
        )
        usage = compressor.budget_usage(history)

        assert usage.used_messages == len(history)
        assert usage.max_messages == 20
        assert usage.needs_compression is False
