from pydantic import BaseModel, Field


class _Base(BaseModel):
    pass
