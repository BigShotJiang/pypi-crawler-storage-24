from typing import List

from rtd.models._base import _Base, Field
from rtd.models.route_direction_name import RouteDirectionName


class RouteDirection(_Base):
    id: int = Field(alias='directionId')
    name: RouteDirectionName = Field(alias='directionName')
    trip_headsign: List[str] = Field(alias='tripHeadsign')
