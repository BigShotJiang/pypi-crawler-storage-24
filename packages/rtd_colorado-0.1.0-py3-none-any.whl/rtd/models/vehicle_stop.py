from rtd.models._base import _Base, Field


class VehicleStop(_Base):
    id: str = Field(alias='id')
    name: str = Field(alias='name')
