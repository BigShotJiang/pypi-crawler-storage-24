from datetime import datetime
from typing import Optional

from rtd.models._base import _Base, Field
from rtd.models.route_direction_name import RouteDirectionName
from rtd.models.route_id import RouteId
from rtd.models.trip_status import TripStatus
from rtd.models.vehicle_stop import VehicleStop


class Vehicle(_Base):
    id: str = Field(alias='id')
    label: str = Field(alias='label')
    bearing: float = Field(alias='bearing')
    # direction_id: int = Field(alias='directionId')
    direction_name: RouteDirectionName = Field(alias='directionName')
    trip_status: TripStatus = Field(alias='tripStatus')
    latitude: float = Field(alias='lat')
    longitude: float = Field(alias='lng')
    occupancy_status: Optional[int] = Field(alias='occupancyStatus', default=None)
    trip_id: str = Field(alias='tripId')
    shape_id: str = Field(alias='shapeId')
    route_id: RouteId = Field(alias='routeId')
    service_date: datetime = Field(alias='serviceDate')
    headsign: str = Field(alias='headsign')
    timestamp: int = Field(alias='timestamp')
    current_stop: Optional[VehicleStop] = Field(alias='currentStop', default=None)
    prev_stop: Optional[VehicleStop] = Field(alias='prevStop', default=None)
    next_stop: Optional[VehicleStop] = Field(alias='nextStop', default=None)
