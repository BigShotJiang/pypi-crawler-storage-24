import enum


class RouteDirectionName(enum.Enum):
    EASTBOUND = "Eastbound"
    WESTBOUND = "Westbound"
    NORTHBOUND = "Northbound"
    SOUTHBOUND = "Southbound"
