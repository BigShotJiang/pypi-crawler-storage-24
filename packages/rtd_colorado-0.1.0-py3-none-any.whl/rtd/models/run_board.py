from datetime import datetime

from rtd.models._base import _Base, Field


class RunBoard(_Base):
    id: str = Field(alias='id')
    current_id: str = Field(alias='currentId')
    current_name: str = Field(alias='currentName')
    current_effective_date: datetime = Field(alias='currentEffectiveDate')
