import enum


class RouteMode(enum.Enum):
    RAIL = 'RAIL'
    BUS = 'BUS'
