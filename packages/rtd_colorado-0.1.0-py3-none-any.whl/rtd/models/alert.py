from datetime import datetime
from typing import Optional

from rtd.models._base import _Base, Field
from rtd.models.route_id import RouteId


class Alert(_Base):
    route_name: str = Field(alias='routeName')
    latest_alert_expiration: Optional[datetime] = Field(alias='latestAlertExpiration', default=None)
    alert_count: int = Field(alias='alertCount')
    route_id: RouteId = Field(alias='routeId')
    newest_alert_created_at: datetime = Field(alias='newestAlertCreatedAt')
    display_name: str = Field(alias='displayName')
