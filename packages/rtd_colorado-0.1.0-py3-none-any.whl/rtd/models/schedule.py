from rtd.models._base import _Base, Field
from rtd.models.run_board import RunBoard
from rtd.models.schedule_route import ScheduleRoute


class Schedule(_Base):
    id: str = Field(alias='id')
    run_board: RunBoard = Field(alias='runboard')
    routes: list[ScheduleRoute] = Field(alias='routes')
