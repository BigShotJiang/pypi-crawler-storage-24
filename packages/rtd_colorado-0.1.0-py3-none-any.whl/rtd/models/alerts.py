from typing import Any

from rtd.models._base import _Base, Field
from rtd.models.alert import Alert


class Alerts(_Base):
    bus: list[Alert] = Field(alias='bus')
    rail: list[Alert] = Field(alias='rail')
    station: list[Any] = Field(alias='station')  # TODO: What type?
    systemwide_bus: list[Any] = Field(alias='systemwideBus')  # TODO: What type?
    systemwide_rail: list[Any] = Field(alias='systemwideRail')  # TODO: What type?
