from typing import Optional, Any

from rtd.models._base import _Base, Field
from rtd.models.alert_lifecycle import AlertLifecycle
from rtd.models.alert_link import AlertLink
from rtd.models.route_id import RouteId


class RiderAlert(_Base):
    id: int = Field(alias='id')
    category: str = Field(alias='category')
    description: str = Field(alias='description')
    header: str = Field(alias='header')
    cause: Optional[str] = Field(alias='cause', default=None)
    date_created: int = Field(alias='dateCreated')
    date_modified: int = Field(alias='dateModified')
    delay_time: str = Field(alias='delayTime')
    severity: int = Field(alias='severity')
    start_date: int = Field(alias='startDate')
    link: Optional[AlertLink] = Field(alias='link', default=None)
    end_date: Optional[int] = Field(alias='endDate', default=None)
    alert_lifecycle: AlertLifecycle = Field(alias='alertLifecycle')
    relevance: float = Field(alias='relevance')
    affected_stop_ids: list[str] = Field(alias='affectedStopIds')
    affected_route_ids: list[RouteId] = Field(alias='affectedRouteIds')
    affected_elevator_ids: list[Any] = Field(alias='affectedElevatorIds')
    alternate_stop_ids: list[str] = Field(alias='alternateStopIds')
