import enum


class TripStatus(enum.Enum):
    SCHEDULED = 'SCHEDULED'
    # TODO: Other types?
