import enum


class AlertLifecycle(enum.Enum):
    NEW = 'New'
    ONGOING = 'Ongoing'
    UPCOMING = 'Upcoming'
