from rtd.models._base import _Base, Field

class Suggestion(_Base):
    type: str = Field(alias='suggestionType')
    name: str = Field(alias='name')
    label: str = Field(alias='label')
    slug: str = Field(alias='slug')
    latitude: float = Field(alias='lat')
    longitude: float = Field(alias='lng')
    address: str = Field(alias='address')
    city: str = Field(alias='city')
    zip_code: str = Field(alias='zipCode')
    score: float = Field(alias='score')
