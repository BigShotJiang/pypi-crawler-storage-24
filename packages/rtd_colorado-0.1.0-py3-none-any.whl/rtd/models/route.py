from typing import List

from rtd.models._base import _Base, Field
from rtd.models.agency_id import AgencyId
from rtd.models.route_direction import RouteDirection
from rtd.models.route_id import RouteId
from rtd.models.route_mode import RouteMode


class Route(_Base):
    id: RouteId = Field(alias='id')
    agency_id: AgencyId = Field(alias='agencyId')
    long_name: str = Field(alias='routeLongName')
    color: str = Field(alias='routeColor')
    text_color: str = Field(alias='routeTextColor')
    type: int = Field(alias='routeType')
    mode: RouteMode = Field(alias='mode')
    directions: List[RouteDirection] = Field(alias='directions')
