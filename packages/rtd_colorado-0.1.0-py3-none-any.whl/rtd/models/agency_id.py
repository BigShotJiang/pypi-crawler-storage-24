import enum


class AgencyId(enum.Enum):
    RTD = "RTD"
