from rtd.models._base import _Base, Field


class AlertLink(_Base):
    text: str = Field(alias='text')
    to: str = Field(alias='to')
