from typing import Any, Optional

from rtd.models._base import _Base, Field


class Coordinates(_Base):
    latitude: str = Field(alias='lat')
    longitude: str = Field(alias='lng')


class Geometry(_Base):
    coordinates: Coordinates = Field(alias='location')


class Location(_Base):
    address_components: None = Field(alias='addressComponents', default=None)
    formatted_address: str = Field(alias='formattedAddress')
    place_id: None = Field(alias='placeId', default=None)
    geometry: Geometry = Field(alias='geometry')
    id: int = Field(alias='id')
    name: str = Field(alias='name')
    scope: str = Field(alias='scope')
    stop_code: None = Field(alias='stopCode', default=None)
    types: None = Field(alias='types', default=None)


class Point(_Base):
    name: str = Field(alias='name')
    stop_id: Optional[str] = Field(alias='stopId', default=None)
    stop_index: Optional[int] = Field(alias='stopIndex', default=None)
    latitude: float = Field(alias='lat')
    longitude: float = Field(alias='lng')
    arrival: int = Field(alias='arrival')
    departure: Optional[int] = Field(alias='departure', default=None)


class LegGeometry(_Base):
    points: str = Field(alias='points')
    length: int = Field(alias='length')


class Step(_Base):
    distance: float = Field(alias='distance')
    relative_direction: str = Field(alias='relativeDirection')
    street_name: str = Field(alias='streetName')
    absolute_direction: str = Field(alias='absoluteDirection')
    stay_on: bool = Field(alias='stayOn')
    area: bool = Field(alias='area')
    bogus_name: bool = Field(alias='bogusName')
    latitude: float = Field(alias='lat')
    longitude: float = Field(alias='lng')
    elevation: list[Any] = Field(alias='elevation')
    instruction_text: str = Field(alias='instructionText')


class Leg(_Base):
    mode: str = Field(alias='mode')
    route: str = Field(alias='route')
    is_rail: bool = Field(alias='isRail')
    transit_leg: bool = Field(alias='transitLeg')
    from_: Point = Field(alias='from')
    to: Point = Field(alias='to')
    start_time: int = Field(alias='startTime')
    end_time: int = Field(alias='endTime')
    duration: int = Field(alias='duration')
    distance: float = Field(alias='distance')
    leg_geometry: Optional[LegGeometry] = Field(alias='legGeometry', default=None)
    intermediate_stops: list[Point] = Field(alias='intermediateStops')
    steps: list[Step] = Field(alias='steps')
    flex_ride: bool = Field(alias='flexRide')
    real_time: bool = Field(alias='realTime')
    occupancy_status: None = Field(alias='occupancyStatus', default=None)
    interline_with_previous_leg: bool = Field(alias='interlineWithPreviousLeg')
    route_id: Optional[str] = Field(alias='routeId', default=None)
    route_color: Optional[str] = Field(alias='routeColor', default=None)
    route_short_name: Optional[str] = Field(alias='routeShortName', default=None)
    route_long_name: Optional[str] = Field(alias='routeLongName', default=None)
    route_text_color: Optional[str] = Field(alias='routeTextColor', default=None)
    trip_id: Optional[str] = Field(alias='tripId', default=None)
    headsign: Optional[str] = Field(alias='headsign', default=None)


class Itinerary(_Base):
    id: str = Field(alias='id')
    request_id: int = Field(alias='requestId')
    duration: int = Field(alias='duration')
    walk_time: int = Field(alias='walkTime')
    transit_time: int = Field(alias='transitTime')
    wait_time: int = Field(alias='waitTime')
    walk_distance: float = Field(alias='walkDistance')
    transfers: int = Field(alias='transfers')
    created_at: str = Field(alias='createdAt')
    updated_at: str = Field(alias='updatedAt')
    start_time: int = Field(alias='startTime')
    end_time: int = Field(alias='endTime')
    fare: None = Field(alias='fare', default=None)
    start_location: Location = Field(alias='startLocation')
    end_location: Location = Field(alias='endLocation')
    legs: list[Leg] = Field(alias='legs')
    includes_flex: bool = Field(alias='includesFlex')
    requires_reservation: bool = Field(alias='requiresReservation')
    is_later_option: bool = Field(alias='isLaterOption', default=False)
    later_options: list[Itinerary] = Field(alias='laterOptions')
