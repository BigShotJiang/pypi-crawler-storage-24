from typing import Optional

from rtd.models._base import _Base, Field
from rtd.models.route_id import RouteId


class ScheduleRoute(_Base):
    id: str = Field(alias='id')
    route_id: RouteId = Field(alias='routeId')
    type: int = Field(alias='routeType')
    name: str = Field(alias='routeName')
    line_name: str = Field(alias='lineName')
    branch: Optional[str] = Field(alias='branch', default=None)
