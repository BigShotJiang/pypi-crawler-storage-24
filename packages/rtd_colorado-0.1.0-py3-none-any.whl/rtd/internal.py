import enum
from typing import Union


def _potential_enum_to_string(_in: Union[str, enum.Enum]) -> str:
    if isinstance(_in, enum.Enum):
        return str(_in.value)
    return _in
