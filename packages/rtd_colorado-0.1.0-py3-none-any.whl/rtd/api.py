from datetime import datetime
from typing import List, Union, Optional
from urllib.parse import quote

import objectrest

from rtd.internal import _potential_enum_to_string
from rtd.models.alerts import Alerts
from rtd.models.rider_alert import RiderAlert
from rtd.models.route import Route
from rtd.models.route_id import RouteId
from rtd.models.schedule import Schedule
from rtd.models.suggestion import Suggestion
from rtd.models.vehicle import Vehicle


def get_suggestions(query: str) -> List[Suggestion]:
    url = f'https://app.rtd-denver.com/api/suggestions?q={quote(query)}'
    return objectrest.get_object(url=url, model=Suggestion, extract_list=True)  # type: ignore


def get_routes() -> List[Route]:
    url = 'https://nodejs-prod.rtd-denver.com/api/v2/nextride/routes'
    return objectrest.get_object(url=url, model=Route, extract_list=True)  # type: ignore


def get_route(route_id: Union[str, RouteId]) -> Route:
    route_id: str = _potential_enum_to_string(route_id)
    url = f'https://nodejs-prod.rtd-denver.com/api/v2/nextride/routes/{quote(route_id)}'
    return objectrest.get_object(url=url, model=Route)  # type: ignore


def get_route_vehicles(route_id: Union[str, RouteId]) -> List[Vehicle]:
    route_id: str = _potential_enum_to_string(route_id)
    url = f'https://nodejs-prod.rtd-denver.com/api/v2/nextride/routes/{quote(route_id)}/vehicles'
    return objectrest.get_object(url=url, model=Vehicle, extract_list=True)  # type: ignore


def get_vehicle(vehicle_id: str) -> Vehicle:
    url = f'https://nodejs-prod.rtd-denver.com/api/v2/nextride/vehicles/{quote(vehicle_id)}'
    return objectrest.get_object(url=url, model=Vehicle)  # type: ignore


def get_schedule() -> Schedule:
    url = 'https://nodejs-prod.rtd-denver.com/api/v2/schedules'
    return objectrest.get_object(url=url, model=Schedule)  # type: ignore


def get_rider_alerts() -> List[RiderAlert]:
    url = f'https://nodejs-prod.rtd-denver.com/api/v2/rider-alerts'
    return objectrest.get_object(url=url, model=RiderAlert, extract_list=True)  # type: ignore


def get_alerts() -> Alerts:
    url = f'https://nodejs-prod.rtd-denver.com/api/v2/rider-alerts/alerts'
    return objectrest.get_object(url=url, model=Alerts, sub_keys=['data', 'attributes'])  # type: ignore


def get_plan(
        from_latitude: str,
        from_longitude: str,
        to_latitude: str,
        to_longitude: str,
        depart_time: Optional[datetime] = None,
        max_bicycle_miles: Optional[float] = 3,
        max_transfer_time: Optional[int] = 2700,
        max_walk_miles: Optional[float] = 2.5,
        min_transfer_time_hard: Optional[int] = 180,
        number_of_itineraries: Optional[int] = 4,
):
    depart_time = depart_time or datetime.now()

    url = 'https://nodejs-prod.rtd-denver.com/api/v2/otp/itineraries/plan'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:147.0) Gecko/20100101 Firefox/147.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json',
        'Referer': 'https://app.rtd-denver.com/',
        'Origin': 'https://app.rtd-denver.com',
        'DNT': '1',
        'Connection': 'keep-alive',
    }
    data = {
        "optimize": "TIME",
        "modes": [
            "mode_transit"
        ],
        "flex_use_reservation_services": True,
        "flex_use_elegibilty_services": True,
        "max_bicycle_miles": max_bicycle_miles,
        "max_transfer_time": max_transfer_time,
        "max_walk_miles": max_walk_miles,
        "min_transfer_time_hard": min_transfer_time_hard,
        "itinerary_request": [
            {
                "segment_index": 0,
                "start_location": {
                    "formatted_address": "From Location",
                    "geometry": {
                        "location": {
                            "lat": from_latitude,
                            "lng": from_longitude
                        }
                    }
                },
                "end_location": {
                    "formatted_address": "To Location",
                    "geometry": {
                        "location": {
                            "lat": to_latitude,
                            "lng": to_longitude
                        }
                    }
                },
                "departure_type": "depart",
                "trip_time": datetime.strftime(depart_time, '%Y-%m-%dT%H:%M:%S%z'),
            }
        ],
        "source_tag": "external",
        "trip_purpose": "general_purpose",
        "num_itineraries": number_of_itineraries,
    }
    return objectrest.post_json(url=url, headers=headers, data=data)  # type: ignore
