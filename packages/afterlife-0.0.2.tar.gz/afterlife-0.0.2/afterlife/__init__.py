"""
afterlife — Hollywood of Astrology.

Public API::

    from afterlife import Afterlife

    eng   = Afterlife()
    chart = eng.compute_astro_chart(
        date_str="01-01-1990",
        time_str="12:00",
        lat=41.0,
        lon=29.0,
    )
"""
from afterlife._version import __version__
from afterlife.engine import Afterlife

__all__ = ["Afterlife", "__version__"]
