# Afterlife

**Precision astrological chart engine with a terminal CLI.**

Built on [Swiss Ephemeris](https://www.astro.com/swisseph/) and NASA SPICE kernels.
Supports planets, dwarf planets, asteroids, centaurs, fixed stars, exoplanets, interstellar objects, Arabic lots, eclipses — 335+ celestial bodies.

> **Early Development — v0.0.2**
> This is a very early release under active development. APIs and output formats may change between versions.

---

## Install

```bash
pip install afterlife
afterlife download
```

`afterlife download` fetches ephemeris data (~484 MB) from GitHub Releases and caches it in `~/.cache/afterlife/ephe/`. Only required once.

---

## CLI

```bash
# Natal chart
afterlife chart --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0

# Moon phase calendar
afterlife moon 2026-3

# Transit events for a single body
afterlife transit --body Saturn \
    --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0 \
    --from 2026-01-01 --to 2026-12-31

# All planetary transits for a year
afterlife transits --year 2026 \
    --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0

# Quick planet snapshot
afterlife quick today --lat 41.0 --lon 29.0

# List all supported objects
afterlife list

# Search by name
afterlife search chiron

# JSON output
afterlife chart --date 01-01-1990 --time 12:00 --lat 41.0 --lon 29.0 --json
```

### Flags

| Flag | Default | Description |
| ---- | ------- | ----------- |
| `--tz` | `3.0` | UTC offset in hours |
| `--house-system` | `placidus` | House system |
| `--sort-by` | — | Sort bodies: `name` \| `lon` \| `house` \| `sign` |
| `--limit` | `0` | Max bodies per category (0 = unlimited) |
| `--planets-limit` | `0` | Max planets |
| `--moons-limit` | `0` | Max moons |
| `--dwarfs-limit` | `0` | Max dwarf planets |
| `--asteroids-limit` | `0` | Max asteroids |
| `--centaurs-limit` | `0` | Max centaurs |
| `--points-limit` | `0` | Max points |
| `--advanced-points-limit` | `0` | Max advanced points |
| `--lilith-limit` | `0` | Max Lilith variants |
| `--planetary-nodes-limit` | `0` | Max planetary nodes |
| `--exoplanets-limit` | `0` | Max exoplanets |
| `--interstellar-limit` | `0` | Max interstellar objects |
| `--fixed-stars-limit` | `0` | Max fixed stars |
| `--arabic-lots-limit` | `0` | Max Arabic lots |
| `--no-dwarfs` | — | Exclude dwarf planets |
| `--no-asteroids` | — | Exclude asteroids |
| `--no-fixed-stars` | — | Exclude fixed stars |
| `--json` | — | Raw JSON output |
| `--include` | — | Comma-separated bodies to include |
| `--exclude` | — | Comma-separated bodies to exclude |
| `--sign` | — | Filter by zodiac sign |
| `--house` | — | Filter by house number |

---

## Python API

```python
from afterlife import Afterlife

eng = Afterlife()
chart = eng.compute_astro_chart(
    date_str="01-01-1990",
    time_str="12:00",
    lat=41.0,
    lon=29.0,
    house_system="placidus",
    tz_offset=3.0,
)

import json
print(json.loads(chart)["bodies"]["planets"])
```

---

## Ephemeris Data

Not bundled in the PyPI package. Fetch once with:

```bash
afterlife download
```

Files are cached in `~/.cache/afterlife/ephe/`. Custom path:

```bash
afterlife chart ... --ephe-dir /path/to/ephe
```

```python
eng = Afterlife(ephe_dir="/path/to/ephe", spice_dir="/path/to/kernels")
```

---

## License

MIT © 2026 Mustafa Yavuz Ak
