"""
VendorKernel
============
Commands for managing installed vendor modules.

Commands:
    vendor:list              Show all installed axon vendor providers
    vendor:publish <name>    Write a vendor's config stubs to .env.example
                             and providers section to config.yaml
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


def _ok(msg: str)   -> None: print(f"  ✅ {msg}")
def _warn(msg: str) -> None: print(f"  ⚠️  {msg}")
def _err(msg: str)  -> None: print(f"  ❌ {msg}")
def _info(msg: str) -> None: print(f"  ℹ️  {msg}")
def _step(msg: str) -> None: print(f"\n  › {msg}")
def _dim(msg: str)  -> None: print(f"  {msg}")


class VendorKernel:

    # ── vendor:list ───────────────────────────────────────────────────────

    @staticmethod
    def list_vendors() -> None:
        """Show all installed axon vendor providers and their config keys."""
        from axon.core.module.vendor_loader import _discover_installed
        from axon.core.module.vendor_provider import _VendorRef
        from axon.core.module.vendor_loader import _load_providers_file

        installed = _discover_installed()
        active_refs = _load_providers_file()
        active_names = {r.name for r in active_refs}

        print()
        print("  ╔══════════════════════════════════════════════════════╗")
        print("  ║          Installed Axon Vendor Providers             ║")
        print("  ╚══════════════════════════════════════════════════════╝")

        if not installed:
            print()
            _info("No vendor providers installed.")
            _info("Install one with: pip install python-axon-<name>")
            print()
            return

        for name, cls in sorted(installed.items()):
            status = "✅ active" if name in active_names else "⬜ not registered"
            print()
            print(f"  ┌─ {name}  [{status}]")
            print(f"  │  package : {cls.module_package}")

            if cls.config_keys:
                print(f"  │  required config:")
                for key, desc in cls.config_keys.items():
                    print(f"  │    {key}")
                    print(f"  │      → {desc}")

            if cls.optional_keys:
                print(f"  │  optional config:")
                for key, desc in cls.optional_keys.items():
                    print(f"  │    {key}  (optional)")
                    print(f"  │      → {desc}")

            if name not in active_names:
                print(f"  │")
                print(f"  │  To register: add to app/providers/providers.py:")
                print(f"  │    VendorProvider.use(\"{name}\")")
                print(f"  │  Then run:  ./manage vendor:publish {name}")

            print(f"  └──────────────────────────────────────────────────")

        print()

    # ── vendor:publish ────────────────────────────────────────────────────

    @staticmethod
    def publish(name: str) -> None:
        """
        Write a vendor's config stubs into the project.

        - Appends required env vars as uncommented stubs to .env.example
        - Appends optional env vars as commented hints to .env.example
        - Ensures the vendor is listed under providers: in config.yaml
        - Reminds the developer to add VendorProvider.use() to providers.py
        """
        from axon.core.module.vendor_loader import _discover_installed

        installed = _discover_installed()
        provider_cls = installed.get(name)

        if provider_cls is None:
            _err(f"Vendor '{name}' is not installed.")
            _info(f"Install it with: pip install python-axon-{name}")
            sys.exit(1)

        _step(f"Publishing vendor '{name}'…")

        # ── .env.example ──────────────────────────────────────────────
        env_file = _PROJECT_ROOT / ".env.example"
        existing  = env_file.read_text(encoding="utf-8") if env_file.exists() else ""
        additions = []

        header = f"\n# ---- {name} (python-axon-{name}) " + "-" * max(2, 40 - len(name)) + "\n"
        if f"python-axon-{name}" not in existing:
            additions.append(header)

            for key, desc in provider_cls.config_keys.items():
                line = f"{key}=\n"
                comment = f"# {desc}\n"
                if key not in existing:
                    additions.append(comment)
                    additions.append(line)

            for key, desc in provider_cls.optional_keys.items():
                line = f"# {key}=\n"
                comment = f"# {desc}\n"
                if key not in existing:
                    additions.append(comment)
                    additions.append(line)

            if additions:
                with env_file.open("a", encoding="utf-8") as f:
                    f.writelines(additions)
                _ok(f".env.example — added {len(provider_cls.config_keys)} required key(s), "
                    f"{len(provider_cls.optional_keys)} optional key(s)")
            else:
                _info(".env.example — all keys already present")
        else:
            _info(f".env.example — {name} section already exists")

        # ── providers.py — auto-register ──────────────────────────────
        providers_file = _PROJECT_ROOT / "app" / "providers" / "providers.py"
        if providers_file.exists():
            pf_content = providers_file.read_text(encoding="utf-8")

            if f'"{name}"' in pf_content or f"'{name}'" in pf_content:
                _info(f"providers.py — '{name}' already registered")
            else:
                updated = re.sub(
                    r'(\[)(.*?)(\])',
                    lambda m: m.group(1) + m.group(2) + f'    VendorProvider.use("{name}"),\n' + m.group(3),
                    pf_content,
                    count=1,
                    flags=re.DOTALL,
                )
                if updated == pf_content:
                    _warn(f"providers.py — could not find insertion point, please register '{name}' manually")
                else:
                    providers_file.write_text(updated, encoding="utf-8")
                    _ok(f"providers.py — registered '{name}'")
        else:
            providers_file.parent.mkdir(parents=True, exist_ok=True)
            providers_file.write_text(
                f'from axon import VendorProvider\n\nproviders = [\n    VendorProvider.use("{name}"),\n]\n',
                encoding="utf-8",
            )
            _ok(f"providers.py — created and registered '{name}'")

        # ── Summary ───────────────────────────────────────────────────
        print()
        print(f"  ╔══════════════════════════════════════════════════════╗")
        print(f"  ║  vendor:publish '{name}' complete                    ║")
        print(f"  ╠══════════════════════════════════════════════════════╣")
        print(f"  ║  Next steps:                                         ║")
        print(f"  ║  1. Fill in values in .env.example → copy to .env    ║")
        print(f"  ║  2. ./manage runserver                               ║")
        print(f"  ╚══════════════════════════════════════════════════════╝")
        print()