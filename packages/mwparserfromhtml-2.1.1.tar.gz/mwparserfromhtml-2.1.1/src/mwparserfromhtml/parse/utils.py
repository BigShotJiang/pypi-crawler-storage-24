import json
import typing
from dataclasses import dataclass

from bs4 import Tag

from mwparserfromhtml.parse.const import NAMESPACES


@dataclass
class Link:
    title: str
    prefix: str
    namespace: int


def _get_transclusion_id(html_tag: Tag) -> typing.Optional[str]:
    """Check if a specific element is transcluded."""
    if html_tag.has_attr("about") and html_tag["about"].startswith("#mwt"):
        return html_tag["about"]
    return None


# NOTE: typing for `article` creates circular imports :/
def _get_template_name(html_tag: Tag, article) -> typing.Optional[str]:
    """Check if a specific element is transcluded."""
    transclusion_id = _get_transclusion_id(html_tag)
    if transclusion_id:
        templates = build_list_of_template_wikitext(article)
        if transclusion_id in templates:
            return templates[transclusion_id].split("-", maxsplit=1)[0]
    return None


# NOTE: typing for `article` creates circular imports :/
def build_list_of_template_wikitext(article) -> dict[str, str]:
    templates = {}
    for t in article.wikistew.find_all(
        lambda x: x.attrs["about"].startswith("#mwt") and x.has_attr("data-mw")
        if x.has_attr("about")
        else False
    ):
        template_id = t.attrs["about"]
        try:
            data_mw = json.loads(t["data-mw"])
            if "parts" in data_mw:
                main = data_mw.get("parts")[0]["template"]
                template_name = (
                    main["target"]["wt"].strip().lower()
                )  # normalize template name
                template_params = str(
                    sorted(main["params"].items())
                )  # ensure consistent order
            else:
                template_name = (
                    data_mw.get("name").strip().lower()
                )  # normalize template name
                template_params = str(
                    sorted(data_mw.get("attrs").items())
                )  # ensure consistent order
            if template_id not in templates:
                templates[template_id] = f"{template_name}-{template_params}"
        except Exception:
            continue
    return templates


def is_transcluded(html_tag: Tag) -> bool:
    """Check if element or any of its parents are transcluded."""
    if _get_transclusion_id(html_tag):
        return True
    for p in html_tag.parents:
        if _get_transclusion_id(p):
            return True
    return False


def href_to_link_parts(href: str, wiki: str) -> Link:
    """Map href attribute to wikilink components."""
    namespace = 0
    prefix = ""
    title = ""
    if ":" in href:
        prefix = href.split(":", maxsplit=1)[0].strip("./").replace("_", " ")
        # if newer wiki, fall back to English which has all the defaults
        if wiki not in NAMESPACES:
            wiki = "en"
        if prefix in NAMESPACES[wiki]:
            namespace = NAMESPACES[wiki][prefix]
            title = href.split(":", maxsplit=1)[1].replace("_", " ")
        else:
            prefix = ""
    if not namespace:
        title = href.strip("./").replace("_", " ")
    return Link(title, prefix, namespace)
