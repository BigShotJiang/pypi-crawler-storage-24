# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateShipperResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'code': 'int',
        'data': 'int',
        'msg': 'str'
    }

    attribute_map = {
        'code': 'code',
        'data': 'data',
        'msg': 'msg'
    }

    def __init__(self, code=None, data=None, msg=None):
        r"""CreateShipperResponse

        The model defined in huaweicloud sdk

        :param code: 错误码，0表示成功，其他值表示错误
        :type code: int
        :param data: 返回的数据
        :type data: int
        :param msg: 返回的状态信息
        :type msg: str
        """
        
        super().__init__()

        self._code = None
        self._data = None
        self._msg = None
        self.discriminator = None

        if code is not None:
            self.code = code
        if data is not None:
            self.data = data
        if msg is not None:
            self.msg = msg

    @property
    def code(self):
        r"""Gets the code of this CreateShipperResponse.

        错误码，0表示成功，其他值表示错误

        :return: The code of this CreateShipperResponse.
        :rtype: int
        """
        return self._code

    @code.setter
    def code(self, code):
        r"""Sets the code of this CreateShipperResponse.

        错误码，0表示成功，其他值表示错误

        :param code: The code of this CreateShipperResponse.
        :type code: int
        """
        self._code = code

    @property
    def data(self):
        r"""Gets the data of this CreateShipperResponse.

        返回的数据

        :return: The data of this CreateShipperResponse.
        :rtype: int
        """
        return self._data

    @data.setter
    def data(self, data):
        r"""Sets the data of this CreateShipperResponse.

        返回的数据

        :param data: The data of this CreateShipperResponse.
        :type data: int
        """
        self._data = data

    @property
    def msg(self):
        r"""Gets the msg of this CreateShipperResponse.

        返回的状态信息

        :return: The msg of this CreateShipperResponse.
        :rtype: str
        """
        return self._msg

    @msg.setter
    def msg(self, msg):
        r"""Sets the msg of this CreateShipperResponse.

        返回的状态信息

        :param msg: The msg of this CreateShipperResponse.
        :type msg: str
        """
        self._msg = msg

    def to_dict(self):
        import warnings
        warnings.warn("CreateShipperResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateShipperResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
