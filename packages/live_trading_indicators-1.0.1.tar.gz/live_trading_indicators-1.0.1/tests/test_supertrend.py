import pytest
from common_test import *
import live_trading_indicators as lti


@pytest.mark.parametrize('time_begin, time_end, period', [
    ('2022-07-01', '2022-07-10', 2),
    ('2022-07-01', '2022-07-10', 2),
    ('2022-07-01', '2022-07-10', 20),
    ('2022-07-01', '2022-07-10', 20),
    pytest.param((dt.datetime.utcnow() - dt.timedelta(days=2)).date(), None, 20, marks=pytest.mark.live)  # live
])
def test_supertrend(config_default, test_source, test_symbol, time_begin, time_end, period):

    timeframe = '5m'

    indicators = lti.Indicators(test_source, time_begin, time_end)
    ohlcv = indicators.OHLCV(test_symbol, timeframe)
    supertrend = indicators.Supertrend(test_symbol, timeframe, period=period)
    ref_values = get_ref_values('get_super_trend', ohlcv, 'super_trend', period)
    supertrend = supertrend[:len(ohlcv)]

    assert compare_with_nan(supertrend.supertrend[500:], ref_values.super_trend[500:])


