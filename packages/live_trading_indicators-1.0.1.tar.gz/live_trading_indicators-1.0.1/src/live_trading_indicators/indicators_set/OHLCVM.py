"""OHLCVM(timeframe_low='1m', bars_on_bins=6)
Quotes and the price of the maximum volume: open, high, low, close, volume, mv_price.
The price of the maximum volume is determined by the lower timeframe (default 1m)."""
import numpy as np
from ..indicator_data import IndicatorData
from ..timeframe import Timeframe
from ..exceptions import *
from ..constants import VOLUME_TYPE
from ..volume_clusters import volume_hist, calendar_volume_hist


def get_indicator_out(indicators, symbol, timeframe, out_for_grow, timeframe_low='1m', bars_on_bins=5):

    timeframe_low_enum = Timeframe.cast(timeframe_low)

    if timeframe_low_enum.is_calendar:
        raise LTIExceptionBadParameterValue('Calendar timeframe_low is not supported for OHLCVM')

    if timeframe.is_calendar:
        return get_calendar_indicator_out(indicators, symbol, timeframe, timeframe_low, timeframe_low_enum, bars_on_bins)

    if timeframe.value % timeframe_low_enum.value > 0:
        raise LTIExceptionBadParameterValue(f'the lower timeframe is not a multiple of the larger one ({timeframe!s} / {timeframe_low!s})')

    timeframe_multiple = int(timeframe.value // timeframe_low_enum.value)
    n_bins = timeframe.value // timeframe_low_enum.value // bars_on_bins

    if n_bins < 2:
        raise LTIExceptionBadParameterValue(f'timeframe {timeframe_low_enum} is too large for {timeframe!s}.')

    ohlcv = indicators.OHLCV.full_data(symbol, timeframe)
    ohlcv_low = indicators.OHLCV.full_data(symbol, timeframe_low_enum)

    n_bars = len(ohlcv.time)
    n_low_bars_needed = n_bars * timeframe_multiple

    if len(ohlcv_low.time) > n_low_bars_needed:
        ohlcv_low = ohlcv_low[:n_low_bars_needed]
    elif len(ohlcv_low.time) < n_low_bars_needed:
        n_bars = len(ohlcv_low.time) // timeframe_multiple
        if n_bars == 0:
            raise LTIExceptionTooLittleData(f'timeframe {timeframe_low_enum} is too short for {timeframe!s}.')
        ohlcv = ohlcv[:n_bars]
        ohlcv_low = ohlcv_low[:n_bars * timeframe_multiple]

    hist_volumes, hist_prices = volume_hist(ohlcv_low.low, ohlcv_low.high, ohlcv_low.close, ohlcv_low.volume, n_bins, timeframe_multiple)

    ix_max_volumes = hist_volumes.argmax(1)

    ix_max_volumes_wdims = np.expand_dims(ix_max_volumes, axis=1)
    mv_price = (np.take_along_axis(hist_prices, ix_max_volumes_wdims, 1)
                + np.take_along_axis(hist_prices, ix_max_volumes_wdims + 1, 1)) / 2

    return IndicatorData({
        'indicators': indicators,
        'parameters': {'timeframe_low': timeframe_low, 'bars_on_bins': bars_on_bins},
        'name': 'OHLCVM',
        'symbol': symbol,
        'timeframe': timeframe,
        'time': ohlcv.time,
        'open': ohlcv.open,
        'high': ohlcv.high,
        'low': ohlcv.low,
        'close': ohlcv.close,
        'volume': ohlcv.volume,
        'mv_price': mv_price.flatten(),
        'charts': (({'open': 'open', 'high': 'high', 'low': 'low', 'close': 'close', 'volume': 'volume'}, 'mv_price:bar_level'),)
    })


def get_calendar_indicator_out(indicators, symbol, timeframe, timeframe_low, timeframe_low_enum, bars_on_bins):

    ohlcv = indicators.OHLCV.full_data(symbol, timeframe)
    ohlcv_low = indicators.OHLCV.full_data(symbol, timeframe_low_enum)

    ix_ohlcv, hist_volumes, hist_prices = calendar_volume_hist(ohlcv, ohlcv_low, timeframe, timeframe_low_enum, bars_on_bins)

    ix_max_volumes = hist_volumes.argmax(1)
    ix_max_volumes_wdims = np.expand_dims(ix_max_volumes, axis=1)
    mv_price = (np.take_along_axis(hist_prices, ix_max_volumes_wdims, 1)
                + np.take_along_axis(hist_prices, ix_max_volumes_wdims + 1, 1)) / 2

    return IndicatorData({
        'indicators': indicators,
        'parameters': {'timeframe_low': timeframe_low, 'bars_on_bins': bars_on_bins},
        'name': 'OHLCVM',
        'symbol': symbol,
        'timeframe': timeframe,
        'time': ohlcv.time[ix_ohlcv],
        'open': ohlcv.open[ix_ohlcv],
        'high': ohlcv.high[ix_ohlcv],
        'low': ohlcv.low[ix_ohlcv],
        'close': ohlcv.close[ix_ohlcv],
        'volume': ohlcv.volume[ix_ohlcv],
        'mv_price': mv_price.flatten(),
        'charts': (({'open': 'open', 'high': 'high', 'low': 'low', 'close': 'close', 'volume': 'volume'}, 'mv_price:bar_level'),)
    })