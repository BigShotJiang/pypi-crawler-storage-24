import re
from pathlib import Path

class ApiTranslationManager:
    FILE_EXTENSIONS = [".cs"]
    EXCLUDE_DIRS = ["bin", "obj", "Properties", "Migrations"]
    STRING_PATTERN = re.compile(r'(ResponseErrorCode\.\w+,\s*)"([^"]+)"(?!\s*\.(?:Translate|TranslateFmt)\()')
    EXCEPTION_PATTERN = re.compile(r'(throw new \w*Api\w*Exception\()"([^"]+)"(?!\s*\.(?:Translate|TranslateFmt)\()(\))')

    def __init__(self, project_root):
        self.project_root = project_root

    def __should_process_file(self, file_path):
        if not any(file_path.suffix == ext for ext in self.FILE_EXTENSIONS):
            return False
        parts = file_path.parts
        for excluded in self.EXCLUDE_DIRS:
            if excluded in parts:
                return False
        return True

    def __generate_translation_key(self, file_path, text):
        file_name = file_path.stem
        words = re.findall(r'\w+', text)
        if not words:
            return f"{file_name}.Message"
        key_words = words
        key_suffix = ''.join(word.capitalize() for word in key_words)
        return f"{file_name}.{key_suffix}"

    def __add_using_directive(self, content):
        using_directive = "using Sefrone.Localization;"
        if using_directive in content:
            return content, False
        using_pattern = re.compile(r'^using\s+[\w.]+;', re.MULTILINE)
        using_matches = list(using_pattern.finditer(content))
        if using_matches:
            last_using = using_matches[-1]
            insert_pos = last_using.end()
            content = content[:insert_pos] + f'\n{using_directive}' + content[insert_pos:]
            return content, True
        else:
            namespace_pattern = re.compile(r'^namespace\s+', re.MULTILINE)
            namespace_match = namespace_pattern.search(content)
            if namespace_match:
                insert_pos = namespace_match.start()
                content = content[:insert_pos] + f'{using_directive}\n\n' + content[insert_pos:]
                return content, True
            else:
                content = f'{using_directive}\n\n' + content
                return content, True

    def __process_file(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            original_content = content
            replacements = []
            # ResponseErrorCode patterns
            for match in self.STRING_PATTERN.finditer(content):
                full_match = match.group(0)
                response_code = match.group(1)
                string_literal = match.group(2)
                trans_key = self.__generate_translation_key(file_path, string_literal)
                replacement = f'{response_code}"{trans_key}".Translate()'
                content = content.replace(full_match, replacement, 1)
                replacements.append({
                    'original': string_literal,
                    'key': trans_key,
                    'full_original': full_match,
                    'full_replacement': replacement
                })
            # Api exception patterns
            for match in self.EXCEPTION_PATTERN.finditer(original_content):
                full_match = match.group(0)
                exception_prefix = match.group(1)
                string_literal = match.group(2)
                exception_suffix = match.group(3)
                trans_key = self.__generate_translation_key(file_path, string_literal)
                replacement = f'{exception_prefix}"{trans_key}".Translate(){exception_suffix}'
                if full_match in content:
                    content = content.replace(full_match, replacement, 1)
                    replacements.append({
                        'original': string_literal,
                        'key': trans_key,
                        'full_original': full_match,
                        'full_replacement': replacement
                    })
            if replacements:
                content, using_added = self.__add_using_directive(content)
            if content != original_content:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                return replacements
            return []
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            return []

    def __collect_translation_keys(self, replacements_by_file):
        translations = {}
        for file_path, replacements in replacements_by_file.items():
            for replacement in replacements:
                key = replacement['key']
                original = replacement['original']
                translations[key] = original
        return translations

    def __update_translation_files(self, translations):
        import json
        translation_dir = None
        for path in Path(self.project_root).rglob("*Translations"):
            potential_trans_dir = path
            if potential_trans_dir.exists() and potential_trans_dir.is_dir():
                translation_dir = potential_trans_dir
                break
        if translation_dir is None:
            print("Error: Could not find *Common/Translations folder")
            return
        print(f"Found translation directory: {translation_dir}")
        translation_files = {}
        lang_pattern = re.compile(r'^[a-z]{2}\.json$', re.IGNORECASE)
        for file_path in translation_dir.glob("*.json"):
            if lang_pattern.match(file_path.name):
                lang_code = file_path.stem
                translation_files[lang_code] = file_path
        if not translation_files:
            print("Error: No translation files found matching pattern [xx].json")
            return
        print(f"Found translation files: {', '.join(translation_files.keys())}")
        if 'en' not in translation_files:
            print("Error: en.json is required but not found!")
            return
        all_translations = {}
        for lang_code, file_path in translation_files.items():
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    all_translations[lang_code] = json.load(f)
            except Exception as e:
                print(f"Error loading {file_path}: {e}")
                return
        en_translations = all_translations['en']
        for key, value in translations.items():
            if key not in en_translations:
                en_translations[key] = value
        all_keys = set(en_translations.keys())
        for lang_translations in all_translations.values():
            all_keys.update(lang_translations.keys())
        for lang_code, lang_translations in all_translations.items():
            missing_keys = all_keys - lang_translations.keys()
            if missing_keys:
                print(f"\n{lang_code}.json is missing {len(missing_keys)} keys, adding with English defaults:")
                for key in sorted(missing_keys):
                    lang_translations[key] = en_translations.get(key, "MISSING TRANSLATION")
                    print(f"  + {key}")
        for lang_code, file_path in translation_files.items():
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    sorted_translations = dict(sorted(all_translations[lang_code].items()))
                    json.dump(sorted_translations, f, indent=2, ensure_ascii=False)
                print(f"\n✓ Updated {lang_code}.json (total keys: {len(all_translations[lang_code])})")
            except Exception as e:
                print(f"Error updating {file_path}: {e}")

    def process_project(self):
        print(f"Scanning project at: {self.project_root}")
        print(f"Looking for {self.FILE_EXTENSIONS} files...")
        print(f"Excluding directories: {self.EXCLUDE_DIRS}")
        print("-" * 60)
        project_path = Path(self.project_root)
        replacements_by_file = {}
        total_replacements = 0
        for file_path in project_path.rglob("*"):
            if file_path.is_file() and self.__should_process_file(file_path):
                replacements = self.__process_file(file_path)
                if replacements:
                    relative_path = file_path.relative_to(project_path)
                    replacements_by_file[relative_path] = replacements
                    total_replacements += len(replacements)
                    print(f"\n{relative_path}:")
                    for rep in replacements:
                        print(f"  '{rep['original']}'")
                        print(f"  -> '{rep['key']}'.Translate()")
        print("\n" + "=" * 60)
        print(f"Total files modified: {len(replacements_by_file)}")
        print(f"Total replacements: {total_replacements}")
        if replacements_by_file:
            translations = self.__collect_translation_keys(replacements_by_file)
            print("\n" + "=" * 60)
            print("Updating translation files...")
            self.__update_translation_files(translations)
            print("\n" + "=" * 60)
            print("Done! Please review the changes and update translations for ar.json and fr.json")
        else:
            print("\nNo string literals found to replace.")