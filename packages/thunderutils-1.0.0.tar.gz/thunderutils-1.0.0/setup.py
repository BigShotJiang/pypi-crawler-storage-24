from setuptools import setup, find_packages

setup(
    name="thunderutils",
    version="1.0.0",
    author="ThunderSan85846",
    description="Utility toolkit for Python developers",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
)