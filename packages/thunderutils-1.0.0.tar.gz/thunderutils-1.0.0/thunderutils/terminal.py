# Cores para terminal

class Color:
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    RESET = "\033[0m"


def print_color(text, color):
    # imprime texto colorido
    print(color + text + Color.RESET)


def green(text):
    print_color(text, Color.GREEN)


def red(text):
    print_color(text, Color.RED)


def yellow(text):
    print_color(text, Color.YELLOW)

def blue(text):
    print_color(text, Color.BLUE)