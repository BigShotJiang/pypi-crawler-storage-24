def menu(title, options):
    print("\n" + title)
    print("-" * len(title))

    for i, option in enumerate(options, 1):
        print(f"{i}. {option}")

    while True:
        try:
            choice = int(input("Choose option: "))
            if 1 <= choice <= len(options):
                return choice
        except:
            pass

        print("Invalid option.")