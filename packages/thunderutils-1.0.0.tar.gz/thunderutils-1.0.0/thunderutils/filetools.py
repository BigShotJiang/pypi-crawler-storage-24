import os

def create_file(name, content=""):
    with open(name, "w", encoding="utf-8") as f:
        f.write(content)


def read_file(name):
    with open(name, "r", encoding="utf-8") as f:
        return f.read()


def delete_file(name):
    os.remove(name)