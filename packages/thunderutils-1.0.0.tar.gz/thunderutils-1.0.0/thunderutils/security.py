import random
import string

def generate_password(length=12):
    # gera senha segura
    chars = string.ascii_letters + string.digits + "!@#$%&*"
    return "".join(random.choice(chars) for _ in range(length))