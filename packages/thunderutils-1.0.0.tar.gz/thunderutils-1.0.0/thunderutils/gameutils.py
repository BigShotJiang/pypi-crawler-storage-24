import random

def roll_dice(sides=6):
    return random.randint(1, sides)


def random_choice(items):
    return random.choice(items)


def random_number(min_val, max_val):
    return random.randint(min_val, max_val)