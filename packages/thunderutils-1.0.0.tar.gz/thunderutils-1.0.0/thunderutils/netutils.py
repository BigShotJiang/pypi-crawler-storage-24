import urllib.request
import json

def get(url):
    # faz request GET simples
    with urllib.request.urlopen(url) as response:
        return response.read().decode()


def get_json(url):
    # retorna JSON da API
    data = get(url)
    return json.loads(data)