import os
import platform

def get_os():
    return platform.system()

def get_cwd():
    return os.getcwd()

def list_files(path="."):
    return os.listdir(path)