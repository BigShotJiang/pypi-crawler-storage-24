import time

def measure_time(func):
    start = time.perf_counter()
    func()
    end = time.perf_counter()

    print(f"Execution time: {end - start:.6f}s")


def sleep(seconds):
    time.sleep(seconds)