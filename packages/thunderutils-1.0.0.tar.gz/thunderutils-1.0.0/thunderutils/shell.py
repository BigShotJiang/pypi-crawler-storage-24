from .security import generate_password
from .hashutils import sha256
from .sysutils import get_os
from .cmdutils import run


def shell():

    print("ThunderShell v1.0")
    print("Type 'help' for commands\n")

    while True:

        cmd = input("thunder> ").strip()

        if cmd == "exit":
            break

        elif cmd == "help":
            print("""
Commands:
password [length]
hash [text]
os
run [system command]
exit
""")

        elif cmd.startswith("password"):
            parts = cmd.split()
            length = int(parts[1]) if len(parts) > 1 else 12
            print(generate_password(length))

        elif cmd.startswith("hash"):
            parts = cmd.split()
            if len(parts) > 1:
                print(sha256(parts[1]))

        elif cmd == "os":
            print(get_os())

        elif cmd.startswith("run"):
            command = cmd[4:]
            print(run(command))

        else:
            print("Unknown command")