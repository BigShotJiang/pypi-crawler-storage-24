import subprocess

def run(command):
    # executa comando do sistema
    result = subprocess.run(command, shell=True, capture_output=True, text=True)

    return result.stdout