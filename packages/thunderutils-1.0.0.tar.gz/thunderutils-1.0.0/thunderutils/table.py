def print_table(data):
    # imprime tabela simples
    keys = data[0].keys()

    header = " | ".join(keys)
    print(header)
    print("-" * len(header))

    for row in data:
        line = " | ".join(str(row[k]) for k in keys)
        print(line)