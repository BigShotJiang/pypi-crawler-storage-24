import time
import tracemalloc
import functools

def benchmark(func):
    # mede tempo de execução
    start = time.perf_counter()
    func()
    end = time.perf_counter()
    print(f"Benchmark: {end - start:.6f}s")

def stopwatch():
    input("Press ENTER to start stopwatch")
    start = time.time()
    input("Press ENTER to stop stopwatch")
    end = time.time()
    print(f"Elapsed time: {end - start:.2f}s")

def memory_usage():
    tracemalloc.start()
    current, peak = tracemalloc.get_traced_memory()
    print(f"Current memory: {current / 10**6:.2f}MB")
    print(f"Peak memory: {peak / 10**6:.2f}MB")
    tracemalloc.stop()

def retry(times):
    # decorator para tentar novamente
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for i in range(times):
                try:
                    return func(*args, **kwargs)
                except Exception:
                    if i == times - 1:
                        raise
        return wrapper
    return decorator