import sys
from .security import generate_password
from .hashutils import sha256
from .sysutils import get_os
from .shell import shell

def main():

    args = sys.argv

    if len(args) < 2:
        print("ThunderUtils CLI")
        print("commands: password, hash, os, shell")
        return

    cmd = args[1]

    if cmd == "password":
        length = int(args[2]) if len(args) > 2 else 12
        print(generate_password(length))

    elif cmd == "hash":
        print(sha256(args[2]))

    elif cmd == "os":
        print(get_os())

    elif cmd == "shell":
        shell()

if __name__ == "__main__":
    main()