import sys
import time

def progress_bar(total, delay=0.05):
    for i in range(total + 1):
        percent = int((i / total) * 100)
        bar = "█" * (percent // 2)

        sys.stdout.write(f"\r[{bar:<50}] {percent}%")
        sys.stdout.flush()

        time.sleep(delay)

    print()