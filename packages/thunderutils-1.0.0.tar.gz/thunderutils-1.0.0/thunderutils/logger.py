from .terminal import green, red, yellow, blue

def log_info(msg):
    blue(f"[INFO] {msg}")

def log_success(msg):
    green(f"[SUCCESS] {msg}")

def log_warning(msg):
    yellow(f"[WARNING] {msg}")

def log_error(msg):
    red(f"[ERROR] {msg}")