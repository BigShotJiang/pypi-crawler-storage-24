def bar_chart(data):
    # gráfico de barras simples
    for name, value in data.items():
        bar = "█" * value
        print(f"{name}: {bar} ({value})")