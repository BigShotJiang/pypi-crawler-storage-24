# ThunderUtils

Uma biblioteca Python com utilidades úteis para terminal e scripts.

## Instalação

```bash
pip install thunderutils
```

## Uso em Python

```python
import thunderutils as tu

print(tu.generate_password(16))
print(tu.hash_text("hello"))
```

## CLI

Gerar senha:

```bash
python -m thunderutils password 16
```

Hash de texto:

```bash
python -m thunderutils hash hello
```

Abrir ThunderShell:

```bash
python -m thunderutils shell
```

## Autor

ThunderSan85846