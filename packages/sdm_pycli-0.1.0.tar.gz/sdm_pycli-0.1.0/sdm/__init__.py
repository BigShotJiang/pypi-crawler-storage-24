"""SDM - SDM Downloads Music. A fast CLI tool to download and sync Spotify playlists."""

__version__ = "0.1.0"
