"""openseries package initialization."""

__version__ = "2.1.0"

from .datefixer import (
    date_fix,
    date_offset_foll,
    generate_calendar_date_range,
    get_previous_business_day_before_today,
    holiday_calendar,
    offset_business_days,
)
from .frame import OpenFrame
from .html_utils import export_plotly_figure
from .load_plotly import load_plotly_dict
from .owntypes import ValueType
from .portfoliotools import (
    constrain_optimized_portfolios,
    efficient_frontier,
    prepare_plot_data,
    sharpeplot,
    simulate_portfolios,
)
from .report import report_html
from .series import OpenTimeSeries, timeseries_chain
from .simulation import ReturnSimulation

__all__ = [
    "OpenFrame",
    "OpenTimeSeries",
    "ReturnSimulation",
    "ValueType",
    "constrain_optimized_portfolios",
    "date_fix",
    "date_offset_foll",
    "efficient_frontier",
    "export_plotly_figure",
    "generate_calendar_date_range",
    "get_previous_business_day_before_today",
    "holiday_calendar",
    "load_plotly_dict",
    "offset_business_days",
    "prepare_plot_data",
    "report_html",
    "sharpeplot",
    "simulate_portfolios",
    "timeseries_chain",
]
