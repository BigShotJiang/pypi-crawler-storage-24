# llming-plumber

No-code pipeline automation — visual DAG builder with 112+ blocks

> This is a placeholder release. The full package is coming soon.
