"""No-code pipeline automation — visual DAG builder with 112+ blocks"""

__version__ = "0.0.1"
