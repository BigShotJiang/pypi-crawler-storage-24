import sys
from types import SimpleNamespace

import pytest

from tensorpool import helpers, main


class DummyStdin:
    def __init__(self, is_tty: bool):
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty


def test_job_cancel_rejects_noninteractive_without_no_input(monkeypatch):
    monkeypatch.setattr(helpers.sys, "stdin", DummyStdin(False))

    def unexpected_post(*args, **kwargs):
        raise AssertionError("requests.post should not be called")

    monkeypatch.setattr(helpers.requests, "post", unexpected_post)

    success, message = helpers.job_cancel("j-123")

    assert success is False
    assert message == "Cancel job requires explicit confirmation in non-interactive mode."


def test_job_cancel_honors_no_input_in_noninteractive_mode(monkeypatch):
    monkeypatch.setattr(helpers.sys, "stdin", DummyStdin(False))
    monkeypatch.setenv("TENSORPOOL_KEY", "token")

    calls = []

    class FakeResponse:
        status_code = 202

        def json(self):
            return {"message": "Job j-123 cancellation initiated"}

    def fake_post(url, headers, timeout):
        calls.append(SimpleNamespace(url=url, headers=headers, timeout=timeout))
        return FakeResponse()

    monkeypatch.setattr(helpers.requests, "post", fake_post)

    success, message = helpers.job_cancel("j-123", no_input=True)

    assert success is True
    assert message == "Job j-123 cancellation initiated"
    assert len(calls) == 1
    assert calls[0].url.endswith("/job/cancel/j-123")
    assert calls[0].timeout == 30


@pytest.mark.parametrize(
    ("argv", "expected_job_id"),
    [
        (["tp", "--no-input", "job", "cancel", "j-top"], "j-top"),
        (["tp", "job", "cancel", "j-local", "--no-input"], "j-local"),
    ],
)
def test_main_passes_no_input_to_job_cancel_for_both_flag_positions(
    monkeypatch, argv, expected_job_id
):
    called = {}

    monkeypatch.setattr(main, "get_tensorpool_key", lambda: "token")
    monkeypatch.setattr(main, "health_check", lambda: (True, ""))

    def fake_job_cancel(job_id, no_input=False, wait=False):
        called["job_id"] = job_id
        called["no_input"] = no_input
        called["wait"] = wait
        return True, ""

    monkeypatch.setattr(main, "job_cancel", fake_job_cancel)
    monkeypatch.setattr(sys, "argv", argv)

    main.main()

    assert called == {"job_id": expected_job_id, "no_input": True, "wait": False}
