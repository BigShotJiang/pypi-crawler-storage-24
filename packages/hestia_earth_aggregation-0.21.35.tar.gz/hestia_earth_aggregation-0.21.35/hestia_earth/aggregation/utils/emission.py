from hestia_earth.schema import (
    EmissionMethodTier,
    SchemaType,
    EmissionStatsDefinition,
    TermTermType,
)
from hestia_earth.utils.model import linked_node
from hestia_earth.utils.lookup_utils import is_in_system_boundary
from hestia_earth.utils.tools import flatten, non_empty_list, pick
from hestia_earth.utils.percentiles import percentiles_keys

from hestia_earth.aggregation.recalculate_cycles import should_recalculate
from . import _unique_nodes, _set_dict_single
from .term import METHOD_MODEL

_DEFAULT_TIER = EmissionMethodTier.TIER_1.value


def include_emission(emission: dict, product: dict):
    """
    Keep background emissions that will not be recalculated.
    """
    return any(
        [
            emission.get("methodTier") != EmissionMethodTier.BACKGROUND.value,
            not should_recalculate(product),
            any(
                [
                    input.get("termType") == TermTermType.SEED.value
                    for input in emission.get("inputs", [])
                ]
            ),
        ]
    )


def new_emission(data: dict):
    term = data.get("term", {})
    # only add emissions included in the System Boundary
    if is_in_system_boundary(term.get("@id")):
        node = {"@type": SchemaType.EMISSION.value}
        node["term"] = linked_node(term)

        value = data.get("value")
        if value is not None:
            node["value"] = [value]
            node["statsDefinition"] = EmissionStatsDefinition.CYCLES.value

        node["methodTier"] = data.get("methodTier") or _DEFAULT_TIER
        node["methodModel"] = data.get("methodModel") or METHOD_MODEL

        inputs = data.get("inputs", [])
        # compute list of unique inputs, required for `background` emissions
        if inputs:
            _set_dict_single(
                node,
                "inputs",
                list(map(linked_node, _unique_nodes(inputs))),
                strict=True,
            )

        if node.get("methodTier") != EmissionMethodTier.NOT_RELEVANT.value:
            _set_dict_single(
                node, "distribution", data.get("distribution"), strict=True
            )

        return node | pick(data, percentiles_keys() + ["description", "key"])


def get_method_tier(emissions: list):
    values = non_empty_list(set(flatten([e.get("methodTier", []) for e in emissions])))
    return values[0] if len(values) == 1 else None


def get_method_model(emissions: list):
    values = non_empty_list(flatten([e.get("methodModel", []) for e in emissions]))
    values = list({v["@id"]: v for v in values}.values())
    return values[0] if len(values) == 1 else None


def has_value_without_transformation(blank_node: dict):
    values = blank_node.get("value", [])
    transformations = blank_node.get("transformation", [])
    return (
        not transformations
        or len(transformations) != len(values)
        or any(
            [
                value is not None and transformations[index] is None
                for index, value in enumerate(values)
            ]
        )
    )
