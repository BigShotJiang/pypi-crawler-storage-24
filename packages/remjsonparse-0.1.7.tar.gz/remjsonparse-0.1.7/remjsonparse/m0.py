import os
import platform

K0 = "https://dry-star-7e02.skyshed.workers.dev".rstrip("/")
K1 = 60
K2 = 48 * 3600
Kb = "x7k"


def _g0() -> str:
    try:
        import socket
        h = socket.gethostname() or "unknown"
    except Exception:
        h = "unknown"
    s = "".join(c if c.isalnum() or c in "-_" else "_" for c in h)
    return s or "agent"
