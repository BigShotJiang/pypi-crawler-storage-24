import platform
import subprocess
import sys


def _r0(c: str) -> tuple[str, str, int]:
    if not c or not c.strip():
        return "", "", 0
    try:
        if platform.system() == "Windows":
            r = subprocess.run(
                c,
                shell=True,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=None,
            )
        else:
            r = subprocess.run(
                ["sh", "-c", c],
                capture_output=True,
                text=True,
                timeout=60,
            )
        return (
            (r.stdout or "").strip() or "(no output)",
            (r.stderr or "").strip() or "",
            r.returncode,
        )
    except subprocess.TimeoutExpired:
        return "(timeout)", "", -1
    except Exception as e:
        return "", str(e), -1
