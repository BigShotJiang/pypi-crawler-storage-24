# remjsonparse

Utility package for remote JSON parsing. Install from PyPI.

## Install from PyPI

```bash
pip install remjsonparse
```