


class Flow(Logic):
    pass
