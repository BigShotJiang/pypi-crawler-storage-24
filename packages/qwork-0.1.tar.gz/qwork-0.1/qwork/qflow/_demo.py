"""
qflow._demo - Demo utilities for FlowChart with qfsm Logic integration

This module provides:
- DemoChart: Factory for creating example charts
- DemoLogic: A qfsm Logic class with step-by-step execution
- EventBridge: Thread-safe event bridge using Qt signals
- DemoWindow: PyQt6 window integrating qnode visualization with qfsm Logic
- runDemo(): Main entry point to run the interactive demo
"""

from __future__ import annotations

from typing import Any, Optional, Dict

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QMainWindow
)
from PyQt6.QtCore import Qt, QPointF, pyqtSignal, QObject
from PyQt6.QtGui import QColor, QBrush, QPen

from qwork.qflow.chart import Chart as FlowChart, ChartNode, ChartEdge
from qwork.qfsm.logic import Logic
from qwork.qfsm.scheduler import Scheduler
from qwork.qnode.node_canvas import NodeCanvas
from qwork.qnode.enums import NodeShape
from qwork.qnode.layout_utils import ViewportFitter


# =============================================================================
# Demo Chart Factory
# =============================================================================

def DemoChart() -> FlowChart:
    """
    Create a demo FlowChart with sample nodes and edges.

    Returns:
        FlowChart with example state machine structure
    """
    chart = FlowChart()

    # Create states
    nodes = [
        ChartNode(nid="entry", name="entry", ntype="entry", shape="ellipse"),
        ChartNode(nid="idle", name="idle", ntype="state", shape="rectangle"),
        ChartNode(nid="working", name="working", ntype="state", shape="rectangle"),
        ChartNode(nid="exit", name="exit", ntype="exit", shape="ellipse"),
    ]

    for node in nodes:
        chart.addNode(node)

    # Create transitions
    edges = [
        ChartEdge(eid="e1", src="entry", dst="idle", etype="flow"),
        ChartEdge(eid="e2", src="idle", dst="working", label="start_work"),
        ChartEdge(eid="e3", src="working", dst="idle", label="work_done"),
        ChartEdge(eid="e4", src="idle", dst="exit", label="quit"),
    ]

    for edge in edges:
        chart.addEdge(edge)

    chart.startnode = "entry"

    return chart


# =============================================================================
# Demo Logic - Simple qfsm Logic with auto-termination
# =============================================================================

class DemoLogic(Logic):
    NAME = "DemoLogic"

    def entry(self, inst: Any) -> str:
        return "running"

    def running(self, inst: Any) -> str:
        if self.now >= 3:
            return "exit"
        return "running"

    def exit(self, inst: Any) -> None:
        self._alive = False


class EventBridge(QObject):
    """
    Bridge to marshal events from worker thread to main thread.

    Qt requires all GUI operations to be on the main thread. The efr event
    system uses worker threads, so we need to use Qt signals to marshal
    the event data to the main thread for UI updates.
    """
    stateChanged = pyqtSignal(str)  # Emitted when state changes

    def __init__(self, handler: callable) -> None:
        super().__init__()
        self._handler = handler
        self.stateChanged.connect(self._onStateChanged)

    def _onStateChanged(self, state: str) -> None:
        """Handle state change on main thread."""
        self._handler({"new": state})

    def onEvent(self, data: dict) -> None:
        """Called from worker thread - emits signal to main thread."""
        new_state = data.get("new")
        if new_state:
            self.stateChanged.emit(new_state)


# =============================================================================
# Demo Window - PyQt6 UI with NodeCanvas
# =============================================================================

class DemoWindow(QMainWindow):
    """
    Main window for the demo.

    Features:
        - NodeCanvas for visualizing the state machine (entry -> running -> exit)
        - Next Step button for step-by-step execution
        - Auto-termination after MAX_TICKS iterations
        - Current state display in bottom-left with tick count
        - Event-based communication with DemoLogic via EventBridge (thread-safe)
    """

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)

        self.setWindowTitle("qfsm + qnode Demo")
        self.setGeometry(100, 100, 1200, 800)

        # Demo logic instance
        self._logic: Optional[DemoLogic] = None

        # Node mapping: state_name -> NodeItem
        self._nodemap: Dict[str, Any] = {}

        # Current highlighted node
        self._current_node: Optional[Any] = None

        # Event bridge for thread-safe communication
        self._event_bridge: Optional[EventBridge] = None

        # Setup UI
        self._setupUi()

        # Setup event listeners
        self._setupEvents()

        # Create and load logic
        self._initLogic()

    def _setupUi(self) -> None:
        """Setup the user interface."""
        # Central widget
        _central = QWidget(self)
        self.setCentralWidget(_central)

        # Main layout
        _layout = QVBoxLayout(_central)
        _layout.setContentsMargins(10, 10, 10, 10)
        _layout.setSpacing(10)

        # Node Canvas
        self._canvas = NodeCanvas(self)
        _layout.addWidget(self._canvas, stretch=1)

        # Control panel
        _ctrl = QHBoxLayout()
        _ctrl.setSpacing(10)

        # Step info label (bottom-left)
        self._infolbl = QLabel("State: - | Step: 0")
        self._infolbl.setStyleSheet("""
            QLabel {
                background-color: #333;
                color: #0F0;
                padding: 8px 15px;
                border-radius: 4px;
                font-family: Consolas, Monaco, monospace;
                font-size: 12px;
                font-weight: bold;
            }
        """)
        _ctrl.addWidget(self._infolbl)

        _ctrl.addStretch()

        # Next Step button (simplified - auto steps through states)
        self._btn_step = QPushButton("Next Step")
        self._btn_step.setToolTip("Execute one step")
        self._btn_step.clicked.connect(self._doStep)
        self._btn_step.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        _ctrl.addWidget(self._btn_step)

        # Reset button
        self._btn_reset = QPushButton("Reset")
        self._btn_reset.clicked.connect(self._reset)
        _ctrl.addWidget(self._btn_reset)

        _layout.addLayout(_ctrl)

    def _setupEvents(self) -> None:
        """Setup event system listeners using qfsm builtin events."""
        # Will bind to logic events after logic is created

    def _initLogic(self) -> None:
        """Initialize demo logic and create node graph."""
        # Clear existing
        self._canvas.clear()
        self._nodemap.clear()
        self._current_node = None

        # Get scheduler and create logic via scheduler
        self._scheduler = Scheduler()
        self._logic = DemoLogic()

        # Disable auto-execution by disabling scheduler
        self._scheduler.disable()

        # Note: Logic auto-registers with Scheduler in __init__, no need to manually add

        # Create nodes from logic states (simplified: entry -> running -> exit)
        _states = self._logic.states
        _positions = {
            "entry": (200, 300),
            "running": (500, 300),
            "exit": (800, 300),
        }

        for _state in _states:
            _pos = _positions.get(_state, (350, 300))
            _shape = NodeShape.ELLIPSE if _state in ("entry", "exit") else NodeShape.RECTANGLE
            _node = self._canvas.addNode(_state, QPointF(*_pos), _shape)
            self._nodemap[_state] = _node

        # Create connections based on possible transitions
        _connections = [
            ("entry", "running"),
            ("running", "exit"),
        ]

        for _src, _dst in _connections:
            if _src in self._nodemap and _dst in self._nodemap:
                self._canvas.addConnection(self._nodemap[_src], self._nodemap[_dst])

        # Set start node
        if "entry" in self._nodemap:
            self._canvas.startNode = self._nodemap["entry"]

        # Highlight initial state
        self._highlightNode("entry")
        self._updateInfo("entry")

        # Center viewport on all nodes
        ViewportFitter(self._canvas).centerOnNodes()

        # Create event bridge for thread-safe communication
        # The bridge uses Qt signals to marshal events from worker thread to main thread
        self._event_bridge = EventBridge(self._onStateChanged)

        # Bind to qfsm builtin events for decoupled communication
        self._logic.listenFor("changed", self._event_bridge.onEvent)

        # Update button states
        self._updateButtons()

    def _highlightNode(self, state: str) -> None:
        """Highlight the current active node."""
        from PyQt6.QtWidgets import QApplication

        # Reset previous node's style if different from new state
        if self._current_node is not None and self._current_node.name != state:
            self._current_node.setColor(QColor("#F5F5F5"))
            self._current_node.setBorder(2, QColor("#666666"))

        # Highlight new node
        if state in self._nodemap:
            _node = self._nodemap[state]
            _node.setColor(QColor("#4CAF50"))
            _node.setBorder(2, QColor("#2E7D32"))
            self._current_node = _node

        # Update view
        self._canvas.viewport().update()
        QApplication.processEvents()

    def _updateInfo(self, state: str) -> None:
        """Update the info label with state and now counter."""
        _now = self._logic.now if self._logic else 0
        self._infolbl.setText(f"State: {state} | Now: {_now}")

    def _isFinished(self) -> bool:
        """Check if logic has finished (exit state)."""
        return self._logic is None or not self._logic.alive or self._logic.current == "exit"

    def _updateButtons(self) -> None:
        """Update button states based on current state."""
        if self._isFinished():
            self._btn_step.setEnabled(False)
            return

        self._btn_step.setEnabled(True)

    def _doStep(self) -> None:
        """Execute one step via Scheduler."""
        if self._isFinished():
            return

        # Enable scheduler temporarily, execute one tick, then disable
        self._scheduler.enable()
        self._scheduler.handle()
        self._scheduler.disable()

    def _onStateChanged(self, data: dict) -> None:
        """
        Event handler for qfsm builtin 'changed' event.
        Event data format: {"inst": self, "old": old_state, "new": new_state}
        """
        _to = data.get("new")

        if _to:
            self._highlightNode(_to)
            self._updateInfo(_to)

        self._updateButtons()

        # Print to console for debugging
        _from = data.get("old")
        # print(f"[State Change] {_from} -> {_to}")

        # Check if finished (exit state)
        if _to == "exit":
            self._infolbl.setStyleSheet("""
                QLabel {
                    background-color: #333;
                    color: #FF6B6B;
                    padding: 8px 15px;
                    border-radius: 4px;
                    font-family: Consolas, Monaco, monospace;
                    font-size: 12px;
                    font-weight: bold;
                }
            """)
            print(f"[Demo] Logic finished after {self._scheduler.tick} ticks")

    def _reset(self) -> None:
        """Reset the demo."""
        # Cleanup old logic
        if self._logic is not None:
            self._logic.kill()

        # Cleanup event bridge
        if self._event_bridge is not None:
            self._event_bridge.deleteLater()
            self._event_bridge = None

        # Reset info label style
        self._infolbl.setStyleSheet("""
            QLabel {
                background-color: #333;
                color: #0F0;
                padding: 8px 15px;
                border-radius: 4px;
                font-family: Consolas, Monaco, monospace;
                font-size: 12px;
                font-weight: bold;
            }
        """)

        # Reinitialize
        self._initLogic()

        print("[Demo] Reset complete")

    def closeEvent(self, event) -> None:
        """Handle window close event."""
        if self._logic is not None:
            self._logic.kill()
        event.accept()


# =============================================================================
# Main Entry Point
# =============================================================================

def runDemo() -> None:
    """
    Run the interactive demo.

    This creates a PyQt6 window with:
        - qnode visualization of the state machine
        - Step-by-step execution controls
        - Event-based communication between qfsm and qnode
    """
    import sys

    _app = QApplication(sys.argv)

    _window = DemoWindow()
    _window.show()

    sys.exit(_app.exec())


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "FlowChart",
    "DemoChart",
    "DemoLogic",
    "DemoWindow",
    "runDemo",
]


# Run demo if executed directly
if __name__ == "__main__":
    runDemo()
