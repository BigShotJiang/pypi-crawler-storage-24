#!/usr/bin/env bash
# CertiSigma Census — cron integrity check example
#
# Add to crontab:
#   0 3 * * * /opt/census/cron-check.sh
#
# Or for compare (exfiltration detection):
#   0 4 * * * /opt/census/cron-compare.sh

set -euo pipefail

MANIFEST="/var/lib/census/manifest.db"
LOG="/var/log/census/integrity.jsonl"
ALERT_CMD=""  # e.g. "curl -X POST https://slack.webhook/..."

export CERTISIGMA_API_KEY="${CERTISIGMA_API_KEY:-}"
export NO_COLOR=1

census integrity "$MANIFEST" --strict --format jsonl >> "$LOG" 2>&1
EXIT_CODE=$?

if [ "$EXIT_CODE" -ne 0 ] && [ -n "$ALERT_CMD" ]; then
    tail -1 "$LOG" | $ALERT_CMD
fi

exit "$EXIT_CODE"
