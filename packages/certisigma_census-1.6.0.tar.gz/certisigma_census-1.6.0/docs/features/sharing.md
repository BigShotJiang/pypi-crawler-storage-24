# Forensic Share Tokens

Create time-limited, use-limited share tokens for chain-of-custody evidence sharing.

## Usage

```bash
# Create a share token for specific attestations
census share create <att_id> [<att_id>...] --expires 24h --recipient "Legal Dept" --max-uses 5

# List all share tokens
census share list --json

# Inspect a specific token
census share info <token_id>

# Revoke a token
census share revoke <token_id>
```

## Options

| Option | Description |
|--------|-------------|
| `--expires` | Token lifetime: `30m`, `24h`, `7d` (default: `24h`) |
| `--recipient` | Human-readable recipient label |
| `--max-uses` | Maximum number of times the token can be used |
| `--api-key` | CertiSigma API key (or `CERTISIGMA_API_KEY`) |
| `--json` | Output as JSON |

## How It Works

1. **Owner** creates a share token covering one or more attestation IDs
2. Token includes time limit, optional use limit, and recipient label
3. **Recipient** uses the token to access attestation evidence
4. **Owner** can track all access via `census share info` (use count, active status)
5. Owner can **revoke** the token at any time

## SDK Methods

- `client.create_share_token(attestation_ids, expires_in, recipient_label, max_uses)`
- `client.list_share_tokens()`
- `client.revoke_share_token(token_id)`
- `client.get_share_token_info(token_id)`

Requires API key with `share` scope.

## Audit Trail

All share create/revoke operations are logged to the tamper-evident audit log.
