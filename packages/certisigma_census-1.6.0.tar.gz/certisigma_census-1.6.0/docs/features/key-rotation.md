# Encryption Key Rotation

Rotate the AES-256 encryption key for an attestation's metadata and tags
without exposing plaintext to the server.

## Usage

```bash
census key-rotate <attestation_id> --old-key <hex64> --new-key <hex64>
census key-rotate <attestation_id> --old-key <hex64> --new-key <hex64> --json
```

## How It Works

1. Fetches current encrypted metadata via `get_metadata()`
2. Re-encrypts the envelope using `certisigma.crypto.rotate_key()`
3. Pushes the updated envelope via `update_metadata()`
4. Repeats for any encrypted tags on the same attestation

The server never sees plaintext — only the encrypted envelope is replaced.

## Options

| Option | Description |
|--------|-------------|
| `--old-key` | Current AES-256 key (64 hex characters, required) |
| `--new-key` | New AES-256 key (64 hex characters, required) |
| `--api-key` | CertiSigma API key |
| `--json` | Output as JSON |

## Validation

- Both keys must be exactly 64 valid hex characters
- Old and new keys must be different
- If the attestation has no encrypted data, the command reports "nothing to rotate"

## Compliance

NIST SP 800-57 recommends periodic key rotation for symmetric keys.
This command supports that workflow without requiring re-attestation.

## Audit Trail

Key rotation operations are logged to the tamper-evident audit log
(without logging the actual key values).
