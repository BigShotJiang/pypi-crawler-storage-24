# census doctor — Self-Diagnostic

`census doctor` runs a series of health checks to verify that Census
is properly configured and can communicate with the CertiSigma API.

## Usage

```bash
census doctor
census doctor --manifest inventory.db
census doctor --json
```

## API connectivity

La verifica **API health** usa `CertiSigmaClient` con un timeout HTTP più breve del default di produzione (~8s), così `census doctor` non resta bloccato decine di secondi se l’endpoint è irraggiungibile.

## Checks performed

| Check | What it verifies |
|-------|-----------------|
| **Python version** | Python >= 3.10 |
| **Census version** | Installed package version |
| **SDK version** | CertiSigma SDK installed and version |
| **watchdog** | Optional: watch mode available |
| **fpdf2** | Optional: PDF report generation available |
| **Config (user)** | `~/.config/certisigma-census/config.toml` exists |
| **Config (project)** | `.census.toml` in current directory |
| **API connectivity** | `client.health()` via `/healthz` (no key required) |
| **API key** | Key validity (from env, config, or `--api-key`) |
| **inotify** | Linux only: watch limit >= 524288 |
| **Manifest health** | SQLite integrity check (with `--manifest`) |

## Output

Each check reports one of three statuses:

- **OK** (exit 0) — check passed
- **WARN** — non-critical issue, Census still works
- **FAIL** (exit 1) — critical issue that must be resolved

### Text output (default)

```
  ✓ Python 3.10.12
  ✓ certisigma-census 0.6.x
  ✓ certisigma 1.6.0
  ✓ watchdog 4.0.1 (watch mode available)
  ! fpdf2 not installed (install with: pip install certisigma-census[report])
  ✓ User config: ~/.config/certisigma-census/config.toml
  ! No project config (create with: census config init --project)
  ✓ API reachable (status: ok)
  ✓ API key valid (cs_t...5678)
  ✓ inotify limit: 524,288 (sufficient)

All checks passed.
```

### JSON output (`--json`)

```json
{
  "checks": [
    {"name": "python_version", "status": "ok", "message": "Python 3.10.12", "detail": null},
    {"name": "api_health", "status": "ok", "message": "API reachable (status: ok)", "detail": null}
  ]
}
```

## CI/CD integration

```bash
census doctor --json | jq '.checks[] | select(.status == "fail")'
```

Exit code 1 if any check fails, making it suitable for CI health gates.
