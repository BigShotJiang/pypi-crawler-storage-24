# Manifest Update (AIDE-style)

The `census update` command accepts verified filesystem changes into the manifest
baseline — equivalent to AIDE's `--update` flag. This completes the FIM workflow:
detect → review → accept.

## Usage

```bash
# Interactive confirmation (default)
census update manifest.db

# Non-interactive (cron/CI)
census update manifest.db --yes

# Machine-readable output
census update manifest.db --yes --json

# Silent update
census update manifest.db -y -q
```

## Workflow

```
census scan /data --source baseline-q1          # 1. Create baseline
census integrity manifest.db                     # 2. Detect changes
# [human review: verify changes are legitimate]
census update manifest.db --yes                  # 3. Accept changes
census scan /data --resume --manifest manifest.db # 4. Attest new hashes
```

## What Happens

1. **Integrity check** runs automatically to detect discrepancies
2. **Summary** shows what will change:
   - Missing files → removed from manifest
   - Modified files → re-hashed, entry replaced
   - New files → hashed and added
3. **Confirmation** required (or `--yes` for non-interactive)
4. **Manifest saved** with updated entries

New/modified entries are added with `attested=False`. Run `census scan --resume`
to attest the updated hashes via the CertiSigma API.

## JSON Output

```json
{
  "status": "updated",
  "manifest": "/path/to/manifest.db",
  "removed": 2,
  "updated": 3,
  "added": 5,
  "errors": [],
  "census_version": "1.5.0",
  "elapsed_seconds": 1.23
}
```

When no changes are detected:

```json
{
  "status": "up_to_date",
  "removed": 0,
  "updated": 0,
  "added": 0,
  "census_version": "1.5.0",
  "elapsed_seconds": 0.41
}
```

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Update successful (or no changes needed) |
| 1 | Aborted by user (declined confirmation) |

## Audit Trail

Every update is logged in the audit log:

```
[2026-03-18T10:30:00Z] update       hash: a1b2c3d4... prev: 00000000...
    manifest: /path/to/manifest.db
    removed: 2
    updated: 3
    added: 5
```
