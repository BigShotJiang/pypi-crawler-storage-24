# Evidence Verification

Census verifies hashes against the CertiSigma attestation registry and retrieves the full cryptographic evidence chain (T0/T1/T2). No API key is required — all verification endpoints are public.

## Basic usage

```bash
# Verify a known hash
census verify a1b2c3d4e5f6...

# Hash a file first, then verify
census verify /path/to/document.pdf --file

# Machine-readable output
census verify a1b2c3... --json

# Save OpenTimestamps proof for offline verification
census verify a1b2c3... --save-ots proof.ots
```

## Evidence chain

When a hash is found in the registry, Census displays the full three-layer evidence chain:

```
Hash:        a1b2c3d4e5f67890...
Status:      Attested
Level:       T2 (Bitcoin-anchored)
Registered:  2026-01-15T10:00:00Z
Source:      inventory-hr
ID:          att_12345

Evidence chain:
  T0  ECDSA-P256-SHA256  sig: 304502...
  T1  QuoVadis  2026-01-15T12:00:00Z
  T2  Bitcoin block 876543
      Block:  https://mempool.space/block/0000abc...
      Tx:     https://mempool.space/tx/tx123...
```

### Evidence levels

| Level | Proof type | Latency | Description |
|-------|-----------|---------|-------------|
| T0 | ECDSA-P256-SHA256 | Immediate | CertiSigma server signature at registration time |
| T1 | Qualified TSA (RFC 3161) | Minutes | Timestamped by an accredited TSA (e.g. QuoVadis) |
| T2 | Bitcoin anchor | Hours | Hash anchored in Bitcoin blockchain via OpenTimestamps |

## JSON output

Use `--json` for machine-readable output:

```json
{
  "hash_hex": "a1b2c3...",
  "exists": true,
  "attestation_id": "att_12345",
  "level": "T2",
  "timestamp": "2026-01-15T10:00:00Z",
  "source": "inventory-hr",
  "t0": {"algorithm": "ECDSA-P256-SHA256", "signature": "3045..."},
  "t1": {"tsaProvider": "QuoVadis", "timestamp": "2026-01-15T12:00:00Z"},
  "t2": {"bitcoinBlock": 876543, "bitcoinBlockHash": "0000abc..."},
  "blockchain_url": "https://mempool.space/block/0000abc...",
  "blockchain_tx_url": "https://mempool.space/tx/tx123..."
}
```

## OTS proof export

Save the raw OpenTimestamps `.ots` proof file for independent offline verification:

```bash
census verify a1b2c3... --save-ots document.ots

# Verify independently with the OpenTimestamps tool
ots verify document.ots
```

The `.ots` proof is only available for T2-level attestations (Bitcoin-anchored). For T0/T1-only attestations, the `--save-ots` flag prints a message that the proof is not yet available.

## Full-chain manifest verification

`census verify-manifest` checks that **every** hash in a manifest has a corresponding attestation in the CertiSigma registry:

```bash
# Verify all hashes in a manifest
census verify-manifest inventory.db

# Strict mode: exit code 1 if any hash is unattested
census verify-manifest inventory.db --strict

# Enriched output with source labels and levels
census verify-manifest inventory.db --detailed --json

# Save verification report
census verify-manifest inventory.db -o report.csv
```

This completes the trust chain: **file ↔ manifest ↔ registry**. While `census integrity` checks file→hash consistency (local), `verify-manifest` checks hash→attestation consistency (API).

### Exit codes

| Code | Meaning |
|------|---------|
| `0` | All hashes verified |
| `1` | Discrepancies found (with `--strict`) |

## No API key required

All verification endpoints are public. You do not need a `CERTISIGMA_API_KEY` to use `census verify` or `census verify-manifest`. This enables independent third-party verification of attested hashes.
