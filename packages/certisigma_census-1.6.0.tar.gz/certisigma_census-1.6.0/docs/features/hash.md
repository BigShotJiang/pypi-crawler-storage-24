# Standalone Hashing

Compute SHA-256 hashes without creating manifests or making API calls.

## Usage

```bash
# Single file
census hash document.pdf

# Directory (all visible files)
census hash /path/to/files

# Hash from stdin (for pipes and scripting)
echo "data" | census hash --stdin
cat binary.bin | census hash --stdin --verify a1b2c3...

# Verify a known hash
census hash document.pdf --verify a1b2c3d4e5...

# JSON output
census hash /data --json
```

## How It Works

For files, uses the CertiSigma SDK's `hash_file()` function (streamed, constant memory). For stdin, uses streaming `hashlib.sha256()` in 64KB chunks — no memory overhead regardless of input size. For directories, it walks all visible files (skipping hidden files and directories like `.git`).

## Verification Mode

The `--verify` flag computes the hash and compares it against an expected value:

```bash
census hash document.pdf --verify a1b2c3d4e5f67890...
# Output: Verification: OK (exit 0) or MISMATCH (exit 1)
```

This is useful for integrity checks without a manifest.

## CLI Reference

| Option | Description |
|--------|-------------|
| `--stdin` | Read data from stdin instead of a file |
| `--verify HASH` | Compare computed hash against expected SHA-256 |
| `--json` | Output as JSON array with path, hash, and size |

## Output Format

**Default** (one line per file):
```
a1b2c3d4e5f67890...  /path/to/document.pdf
```

**JSON** (`--json`):
```json
[{"path": "/path/to/document.pdf", "hash": "a1b2...", "size": 5120}]
```
