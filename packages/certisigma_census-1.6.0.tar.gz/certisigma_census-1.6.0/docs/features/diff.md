# Manifest Diffing

Compare two manifest snapshots to identify added, removed, and modified files.

## Usage

```bash
census diff baseline.db current.db
census diff baseline.db current.db --json
census diff baseline.db current.db -o diff.html
census diff baseline.db current.db --summary
census diff baseline.db current.db -o diff.csv
```

## How It Works

Census performs a merge-join on file paths from both manifests:

1. Files in target but not in base are **added**
2. Files in base but not in target are **removed**
3. Files in both with different SHA-256 are **modified**
4. Files in both with identical SHA-256 are **unchanged**

Time complexity: O(n + m) where n and m are manifest sizes.

## Exit Codes

Exit codes follow the AIDE bitmask convention for scripting:

| Code | Meaning |
|------|---------|
| 0 | No changes |
| 1 | Added files detected |
| 2 | Removed files detected |
| 4 | Modified files detected |

Codes are OR'd together: exit code 7 = added + removed + modified.

This enables CI/CD patterns like:

```bash
census diff baseline.db current.db
case $? in
  0) echo "No changes" ;;
  *) echo "Changes detected" ;;
esac
```

## Output Formats

- **Terminal** (default): human-readable summary with optional file details
- **JSON** (`--json`): machine-readable output on stdout
- **HTML** (`-o diff.html`): self-contained report with color-coded tables
- **CSV** (`-o diff.csv`): tabular data for spreadsheet analysis
- **JSON file** (`-o diff.json`): structured data for programmatic use

## CLI Reference

| Option | Description |
|--------|-------------|
| `--json` | Machine-readable JSON output on stdout |
| `-o` / `--output PATH` | Save report (HTML, CSV, or JSON by extension) |
| `--summary` | Show only counts, no individual file details |

## HTML Report

The HTML diff report uses the same styling as other Census reports (CertiSigma branding, responsive layout). Changes are color-coded:

- **Green**: added files
- **Red**: removed files
- **Orange**: modified files

All file paths in the HTML report are HTML-escaped to prevent XSS.
