# Structured Tagging

Classify attestations with key-value tags for enterprise search and compliance.

## Usage

```bash
# Set tags on an attestation
census tag set <att_id> -t department=legal -t case=2026-001

# Set encrypted tags (zero-knowledge)
census tag set <att_id> -t classification=confidential --encrypt

# List tags
census tag get <att_id> --json

# List and decrypt encrypted tags
census tag get <att_id> --decrypt --encryption-key <hex64>

# Delete a tag
census tag delete <att_id> <tag_key>

# Query attestations by tag (AND logic, cursor pagination)
census tag query -f department=legal -f year=2026 --limit 50 --json
```

## Options

| Option | Description |
|--------|-------------|
| `-t`, `--tag` | Tag as `key=value` (repeatable) |
| `-f`, `--filter` | Filter as `key=value` for query (repeatable, AND logic) |
| `--encrypt` | Encrypt tag values client-side (AES-256-GCM) |
| `--decrypt` | Decrypt encrypted tag values on get |
| `--encryption-key` | AES-256 key (64 hex chars) |
| `--limit` | Max results for query (default: 100) |
| `--cursor` | Pagination cursor from previous query |
| `--json` | Output as JSON |

## Encryption

When `--encrypt` is used, tag values are encrypted client-side with AES-256-GCM
before being sent to the server. The server stores only ciphertext and a
`client_encrypted` flag. This enables zero-knowledge classification.

## SDK Methods

- `client.put_tags(attestation_id, tags)` — requires `tags:write` scope
- `client.get_tags(attestation_id)` — requires `tags:read` scope
- `client.delete_tag(attestation_id, tag_key)` — requires `tags:write` scope
- `client.query_tags(filter, limit, cursor)` — requires `tags:read` scope

## Audit Trail

Tag set and delete operations are logged to the tamper-evident audit log.
