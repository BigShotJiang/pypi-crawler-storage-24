# Named Snapshots

Snapshots are timestamped, named copies of a manifest.  They enable
compliance workflows such as "create a Q1 baseline, then compare it
against Q2 to see what changed."

Snapshots leverage the existing `census diff` infrastructure for
comparison.

## Usage

```bash
# Create a snapshot from a manifest
census snapshot create q1-baseline --manifest inventory.db

# List all snapshots
census snapshot list

# Compare two snapshots
census snapshot diff q1-baseline q2-baseline

# Delete a snapshot
census snapshot delete q1-baseline

# JSON output
census snapshot create q1-baseline --manifest inventory.db --json
census snapshot list --json
census snapshot diff q1-baseline q2-baseline --json
```

## Storage

Default directory: `~/.local/share/certisigma-census/snapshots/`

Override via:
- `--snapshot-dir` CLI flag
- `snapshot_dir` in census config

Each snapshot produces two files:
- `<name>.db` -- copy of the SQLite manifest
- `<name>.json` -- metadata (creation time, source manifest path)

## Naming Rules

Snapshot names must:
- Contain only letters, digits, hyphens, and underscores
- Be at most 128 characters
- Be unique within the snapshot directory

## Comparison

`census snapshot diff` uses the same diff engine as `census diff`,
producing AIDE-style bitmask exit codes:
- 0 = no changes
- 1 = files added
- 2 = files removed
- 4 = files modified
- (OR'd together for combinations)

## Use Cases

- **Compliance baselines**: quarterly inventory snapshots for auditors
- **Change tracking**: before/after snapshots around system updates
- **Forensic timeline**: series of snapshots to reconstruct file history
