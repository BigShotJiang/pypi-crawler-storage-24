# Attestation Tracking

Monitor the proof-level progression of attestations from T0 to T2.

## Usage

```bash
# Check current status
census track att_12345

# Wait for Bitcoin anchoring (T2)
census track att_12345 --poll

# JSON output for scripting
census track att_12345 --json

# Custom poll interval and timeout
census track att_12345 --poll --poll-interval 120 --timeout 7200
```

## How It Works

Uses the SDK's `client.status()` method to query the attestation lifecycle:

- **T0**: ECDSA signature (immediate, milliseconds)
- **T1**: Qualified TSA timestamp (seconds to minutes)
- **T2**: Bitcoin blockchain anchor (typically 1-24 hours)

## Poll Mode

With `--poll`, Census periodically checks the attestation status until:

1. T2 level is reached (exit 0)
2. Timeout is exceeded (exit 2)
3. API error occurs (exit 1)

This is useful in CI/CD pipelines that need to wait for full proof completion:

```bash
census scan /data --source "release-v1.0"
# Get attestation ID from manifest, then:
census track att_12345 --poll --timeout 86400
```

## CLI Reference

| Option | Description |
|--------|-------------|
| `--poll` | Continuously check until T2 level reached |
| `--poll-interval SECS` | Seconds between checks (default: 60) |
| `--timeout SECS` | Max time to poll (default: 3600) |
| `--json` | Machine-readable JSON output |
| `--api-key KEY` | API key |
| `--base-url URL` | Override API base URL |

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Status retrieved (or T2 reached in poll mode) |
| 1 | API error |
| 2 | Timeout in poll mode |
