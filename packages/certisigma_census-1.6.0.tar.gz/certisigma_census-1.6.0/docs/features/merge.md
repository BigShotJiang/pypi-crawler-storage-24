# census merge — Manifest Merging

`census merge` combines multiple manifest files into a single unified
manifest.  This enables distributed scanning workflows where different
servers or directories are scanned independently, then results are
merged centrally.

## Usage

```bash
census merge server1.db server2.db -o combined.db
census merge scans/*.db -o full-inventory.db
census merge m1.db m2.db -o merged.db --json
```

## Behavior

- **Unique hashes** are added to the output manifest.
- **Duplicate hashes** (same hash from multiple sources): attestation
  state is preserved — attested entries take precedence over unattested.
- **Path conflicts** (same path, different hash): the entry from the
  later manifest wins (last-write-wins).
- **Attestation state** (attestation IDs, timestamps, levels) is carried
  through to the merged manifest.

## Output

### Text output (default)

```
  + server1.db: 1200 entries (1200 new/updated)
  + server2.db: 800 entries (650 new/updated)

Merged 2 manifests → combined.db (1850 entries)
```

### JSON output (`--json`)

```json
{
  "output": "combined.db",
  "sources": 2,
  "total_entries": 1850,
  "merged_entries": 1850
}
```

## Use cases

### Distributed scanning

Scan different servers independently, then merge for centralized reporting:

```bash
ssh server1 census scan /data --manifest /tmp/s1.db --dry-run
ssh server2 census scan /data --manifest /tmp/s2.db --dry-run
scp server1:/tmp/s1.db server2:/tmp/s2.db ./
census merge s1.db s2.db -o enterprise-inventory.db
```

### Incremental inventory

Merge daily scan results into a cumulative manifest:

```bash
census scan /new-data --manifest today.db
census merge cumulative.db today.db -o cumulative-new.db
mv cumulative-new.db cumulative.db
```
