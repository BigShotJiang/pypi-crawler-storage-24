# JSONL Streaming Output

Census supports JSON Lines (JSONL) output for seamless integration with log aggregators
(ELK, Splunk, Datadog), shell pipelines, and SIEM systems.

## Supported Commands

| Command | `--format jsonl` | What's emitted per line |
|---------|:-:|---|
| `compare` | Yes | One `MatchResult` per match |
| `bulk-scan` | Yes | One match dict per match |
| `integrity` | Yes | One discrepancy per changed/missing/new file |
| `diff` | Yes | One `DiffEntry` per added/removed/modified file |
| `verify-manifest` | Yes | One `ManifestVerifyEntry` per hash |

## Format

Each line is a self-contained JSON object. The final line is always a `_summary` object:

```jsonl
{"hash_hex":"abab...","suspect_path":"leak.txt","attestation_id":"att-1","level":"T0","source":"test","inventory_path":null}
{"_summary":true,"count":1,"census_version":"1.4.0","elapsed_seconds":2.31}
```

## Usage Examples

```bash
# Stream integrity results to a log file
census integrity manifest.db --format jsonl >> /var/log/census/integrity.jsonl

# Pipe to jq for filtering
census compare /suspects --format jsonl | jq 'select(.level=="T2")'

# Count matches without buffering the full report
census compare /data --format jsonl | grep -c '"hash_hex"'

# Append diff results for SIEM ingestion
census diff base.db current.db --format jsonl >> /var/log/census/changes.jsonl
```

## Comparison with `--json`

| Feature | `--json` | `--format jsonl` |
|---------|----------|-------------------|
| Output | Single JSON document | One JSON object per line |
| Buffering | Full result in memory | Flushed per line |
| Machine parsing | `json.loads(output)` | Line-by-line `json.loads` |
| Use case | APIs, file export | Log pipelines, streaming |
| Summary metadata | In root object | In `_summary` trailer line |
