from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import (
    AuthenticatedClient,
    Client,
)
from ...models.api_error import ApiError
from ...models.schedule import Schedule
from ...types import Response


def _get_kwargs(
    account_id: str,
    database_id: str,
    *,
    body: Schedule,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/accounts/{account_id}/databases/{database_id}/schedules".format(
            account_id=quote(str(account_id), safe=""),
            database_id=quote(str(database_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiError | Schedule:
    if response.status_code == 201:
        response_201 = Schedule.from_dict(response.json())

        return response_201

    response_default = ApiError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiError | Schedule]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    account_id: str,
    database_id: str,
    *,
    client: AuthenticatedClient,
    body: Schedule,
) -> Response[ApiError | Schedule]:
    """
    Args:
        account_id (str):
        database_id (str):
        body (Schedule):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | Schedule]
    """

    kwargs = _get_kwargs(
        account_id=account_id,
        database_id=database_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    account_id: str,
    database_id: str,
    *,
    client: AuthenticatedClient,
    body: Schedule,
) -> ApiError | Schedule | None:
    """
    Args:
        account_id (str):
        database_id (str):
        body (Schedule):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | Schedule
    """

    return sync_detailed(
        account_id=account_id,
        database_id=database_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    account_id: str,
    database_id: str,
    *,
    client: AuthenticatedClient,
    body: Schedule,
) -> Response[ApiError | Schedule]:
    """
    Args:
        account_id (str):
        database_id (str):
        body (Schedule):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | Schedule]
    """

    kwargs = _get_kwargs(
        account_id=account_id,
        database_id=database_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    account_id: str,
    database_id: str,
    *,
    client: AuthenticatedClient,
    body: Schedule,
) -> ApiError | Schedule | None:
    """
    Args:
        account_id (str):
        database_id (str):
        body (Schedule):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | Schedule
    """

    return (
        await asyncio_detailed(
            account_id=account_id,
            database_id=database_id,
            client=client,
            body=body,
        )
    ).parsed
