from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import (
    AuthenticatedClient,
    Client,
)
from ...models.api_error import ApiError
from ...models.cluster_connection import ClusterConnection
from ...types import Response


def _get_kwargs(
    account_id: str,
    database_id: str,
    cluster_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/accounts/{account_id}/databases/{database_id}/clusters/{cluster_id}/connect".format(
            account_id=quote(str(account_id), safe=""),
            database_id=quote(str(database_id), safe=""),
            cluster_id=quote(str(cluster_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ApiError | ClusterConnection:
    if response.status_code == 200:
        response_200 = ClusterConnection.from_dict(response.json())

        return response_200

    response_default = ApiError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ApiError | ClusterConnection]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    account_id: str,
    database_id: str,
    cluster_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ApiError | ClusterConnection]:
    """
    Args:
        account_id (str):
        database_id (str):
        cluster_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | ClusterConnection]
    """

    kwargs = _get_kwargs(
        account_id=account_id,
        database_id=database_id,
        cluster_id=cluster_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    account_id: str,
    database_id: str,
    cluster_id: str,
    *,
    client: AuthenticatedClient,
) -> ApiError | ClusterConnection | None:
    """
    Args:
        account_id (str):
        database_id (str):
        cluster_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | ClusterConnection
    """

    return sync_detailed(
        account_id=account_id,
        database_id=database_id,
        cluster_id=cluster_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    account_id: str,
    database_id: str,
    cluster_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ApiError | ClusterConnection]:
    """
    Args:
        account_id (str):
        database_id (str):
        cluster_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | ClusterConnection]
    """

    kwargs = _get_kwargs(
        account_id=account_id,
        database_id=database_id,
        cluster_id=cluster_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    account_id: str,
    database_id: str,
    cluster_id: str,
    *,
    client: AuthenticatedClient,
) -> ApiError | ClusterConnection | None:
    """
    Args:
        account_id (str):
        database_id (str):
        cluster_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | ClusterConnection
    """

    return (
        await asyncio_detailed(
            account_id=account_id,
            database_id=database_id,
            cluster_id=cluster_id,
            client=client,
        )
    ).parsed
