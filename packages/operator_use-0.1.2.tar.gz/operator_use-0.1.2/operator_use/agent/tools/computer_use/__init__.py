﻿"""Computer-use tools from Windows-Use for Windows GUI automation."""

from operator_use.tools import Tool
import sys

COMPUTER_USE_TOOLS: list[Tool] = []

try:
    match sys.platform:
        case "win32":
            from operator_use.agent.tools.computer_use.windows import (
                wait,
                desktop,
                shortcut,
                click,
                type,
                scroll,
                move,
            )
            COMPUTER_USE_TOOLS = [
                wait,
                desktop,
                shortcut,
                click,
                type,
                scroll,
                move,
            ]
        case "darwin":
            from operator_use.agent.tools.computer_use.macos import (
                wait,
                desktop,
                shortcut,
                click,
                type,
                scroll,
                move,
            )
            COMPUTER_USE_TOOLS = [
                wait,
                desktop,
                shortcut,
                click,
                type,
                scroll,
                move,
            ]
        case _:
            pass
except (ImportError, OSError) as e:
    import logging
    logging.getLogger(__name__).warning(f"Computer-use tools unavailable on '{sys.platform}': {e}")

__all__ = ["COMPUTER_USE_TOOLS"]
