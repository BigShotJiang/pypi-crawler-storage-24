﻿import os
import sys
import json
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

# Fix python path for local imports since this could be run nested
sys.path.insert(0, str(Path(__file__).parent.parent))
from operator_use.cli.tui import print_banner, print_start, select, text_input, confirm, print_end

# --- Registry Data ---
# Format: { "Provider Name": [(display_name, model_id), ...] }
# Model IDs sourced from Windows-Use registry (windows_use/cli/registry.py)

LLM_PROVIDERS: dict[str, list[tuple[str, str]]] = {
    "Groq": [
        ("Llama 4 Scout 17B (recommended)", "meta-llama/llama-4-scout-17b-16e-instruct"),
        ("Llama 3.3 70B", "llama-3.3-70b-versatile"),
        ("Llama 3.1 8B", "llama-3.1-8b-instant"),
        ("Qwen3 32B", "qwen/qwen3-32b"),
        ("Compound (agentic)", "groq/compound"),
    ],
    "NVIDIA": [
        ("Qwen 3.5 122B", "qwen/qwen3.5-122b-a10b"),
        ("Llama 3.3 70B", "meta/llama-3.3-70b-instruct"),
        ("Llama 3.1 405B", "meta/llama-3.1-405b-instruct"),
        ("DeepSeek R1", "deepseek-ai/deepseek-r1"),
        ("Mistral Large", "mistralai/mistral-large"),
        ("Nemotron 4 340B", "nvidia/nemotron-4-340b-instruct"),
    ],
    "OpenAI": [
        ("GPT-4.1", "gpt-4.1"),
        ("GPT-4.1 mini", "gpt-4.1-mini"),
        ("GPT-4o", "gpt-4o"),
        ("GPT-4o mini", "gpt-4o-mini"),
        ("o3", "o3"),
        ("o4-mini", "o4-mini"),
        ("o1", "o1"),
    ],
    "Anthropic": [
        ("Claude Sonnet 4.5 (recommended)", "claude-sonnet-4-5"),
        ("Claude Opus 4", "claude-opus-4-20250514"),
        ("Claude 3.5 Sonnet", "claude-3-5-sonnet-latest"),
        ("Claude 3.5 Haiku", "claude-3-5-haiku-latest"),
        ("Claude 3 Haiku", "claude-3-haiku-latest"),
    ],
    "Google": [
        ("Gemini 2.5 Pro", "gemini-2.5-pro"),
        ("Gemini 2.5 Flash", "gemini-2.5-flash"),
        ("Gemini 2.0 Flash", "gemini-2.0-flash"),
        ("Gemini 1.5 Pro", "gemini-1.5-pro"),
    ],
    "Mistral": [
        ("Mistral Large 3", "mistral-large-2512"),
        ("Mistral Medium 3.1", "mistral-medium-2508"),
        ("Mistral Small 3.2", "mistral-small-2506"),
        ("Mistral Large (legacy)", "mistral-large-latest"),
    ],
    "DeepSeek": [
        ("DeepSeek V3 (Chat)", "deepseek-chat"),
        ("DeepSeek R1 (Reasoner)", "deepseek-reasoner"),
    ],
    "Cerebras": [
        ("Llama 3.3 70B", "llama-3.3-70b"),
        ("Llama 3.1 8B", "llama3.1-8b"),
        ("Llama 3.1 70B", "llama-3.1-70b"),
    ],
    "OpenRouter": [
        ("Llama 4 Scout (recommended)", "meta-llama/llama-4-scout-17b-16e-instruct"),
        ("Claude 3.5 Sonnet", "anthropic/claude-3.5-sonnet"),
        ("GPT-4o", "openai/gpt-4o"),
        ("Gemini 2.0 Flash", "google/gemini-2.0-flash"),
        ("Llama 3.3 70B", "meta-llama/llama-3.3-70b-instruct"),
    ],
    "Ollama": [
        ("Llama 3.3 70B", "llama3.3"),
        ("Llama 3.2", "llama3.2"),
        ("DeepSeek R1", "deepseek-r1"),
        ("Qwen 3.5", "qwen3.5"),
        ("Mistral", "mistral"),
        ("Gemma 3", "gemma3"),
    ],
    "Antigravity": [
        ("Gemini 3 Pro (recommended)", "gemini-3-pro"),
        ("Gemini 3 Flash", "gemini-3-flash"),
        ("Gemini 2.5 Pro", "gemini-2.5-pro"),
        ("Gemini 2.5 Flash", "gemini-2.5-flash"),
        ("Claude Opus 4.6", "claude-opus-4-6"),
        ("Claude Sonnet 4.6", "claude-sonnet-4-6"),
    ],
    "Codex": [
        ("GPT-5.4 (recommended)", "gpt-5.4"),
    ],
    "Claude Code": [
        ("Claude Sonnet 4.6 (recommended)", "claude-sonnet-4-6"),
        ("Claude Opus 4.6", "claude-opus-4-6"),
    ],
}

STT_PROVIDERS: dict[str, list[tuple[str, str]]] = {
    "Groq": [
        ("Whisper Large v3 Turbo (recommended)", "whisper-large-v3-turbo"),
        ("Whisper Large v3", "whisper-large-v3"),
    ],
    "OpenAI": [
        ("Whisper 1", "whisper-1"),
    ],
    "Google": [
        ("Gemini 2.0 Flash", "gemini-2.0-flash"),
        ("Gemini 2.5 Flash", "gemini-2.5-flash"),
    ],
    "ElevenLabs": [
        ("Scribe v1", "scribe_v1"),
    ],
    "Deepgram": [
        ("Nova 3 (recommended)", "nova-3"),
        ("Nova 2", "nova-2"),
    ],
    "Sarvam": [
        ("Saaras v3 (recommended)", "saaras:v3"),
    ],
}

TTS_PROVIDERS: dict[str, list[tuple[str, str]]] = {
    "Groq": [
        ("Orpheus v1 English", "canopylabs/orpheus-v1-english"),
    ],
    "OpenAI": [
        ("TTS-1 HD", "tts-1-hd"),
        ("TTS-1", "tts-1"),
    ],
    "Google": [
        ("Gemini 2.0 Flash Preview TTS", "gemini-2.0-flash-preview-tts"),
    ],
    "ElevenLabs": [
        ("Multilingual v2", "eleven_multilingual_v2"),
        ("Flash v2.5", "eleven_flash_v2_5"),
    ],
    "Deepgram": [
        ("Aura 2", "aura-2"),
    ],
    "Sarvam": [
        ("Bulbul v3 (recommended)", "bulbul:v3"),
    ],
}

VOICES: dict[str, list[str]] = {
    "OpenAI": ["alloy", "echo", "fable", "onyx", "nova", "shimmer"],
    "Groq": ["autumn", "diana", "hannah", "austin", "daniel", "troy"],
    "Google": ["Aoede", "Charon", "Fenrir", "Kore", "Puck"],
    "ElevenLabs": ["Rachel", "Drew", "Clyde", "Paul", "Domi"],
    "Deepgram": ["asteria-en", "luna-en", "stella-en", "athena-en", "hera-en"],
    "Sarvam": ["kavya", "rahul", "nitin", "priya", "amrita", "arjun"],
}

from operator_use.config import Config, LLMConfig, STTConfig, TTSConfig, AgentConfig, ProvidersConfig, ProviderConfig, ChannelsConfig, TelegramConfig, DiscordConfig

def _select_model(label: str, options: list[tuple[str, str]]) -> str:
    """Show a selection of (display_name, model_id) options; return the chosen model_id."""
    display_names = [d for d, _ in options]
    chosen_display = select(label, display_names)
    # Map back to model_id
    model_id = next(mid for d, mid in options if d == chosen_display)
    return model_id

OAUTH_PROVIDERS = {"Antigravity", "Codex", "Claude Code"}

OAUTH_NOTES = {
    "Antigravity": "Uses Google Cloud Code Assist OAuth. Run: python -m operator_use.providers.antigravity.auth login",
    "Codex": "Uses ChatGPT subscription OAuth. Run: codex login",
    "Claude Code": "Uses Claude Code CLI OAuth. Token is auto-discovered from ~/.claude/.credentials.json",
}

def get_provider_key(name: str) -> str:
    key_map = {
        "OpenRouter": "open_router",
        "ElevenLabs": "elevenlabs",
        "Deepgram": "deepgram",
        "NVIDIA": "nvidia",
        "DeepSeek": "deepseek",
        "Sarvam": "sarvam",
        "Claude Code": "claude_code",
    }
    return key_map.get(name, name.lower())

def run_initial_setup():
    print_banner()
    print_start()

    # 1. LLM
    llm_provider_name = select("Pick the LLM provider:", list(LLM_PROVIDERS.keys()))
    llm_provider_key = get_provider_key(llm_provider_name)
    llm_model = _select_model("Pick the LLM model:", LLM_PROVIDERS[llm_provider_name])
    if llm_provider_name in OAUTH_PROVIDERS:
        print(f"\n  ℹ  {OAUTH_NOTES[llm_provider_name]}\n")
        llm_api_key = ""
    else:
        llm_api_key = text_input(f"Enter API Key for {llm_provider_name}:", is_password=True)

    llm_conf = LLMConfig(provider=llm_provider_key, model=llm_model)
    api_keys_dict = {}
    if llm_api_key:
        api_keys_dict[llm_provider_key] = llm_api_key

    # 2. STT
    wants_stt = confirm("Do you want to enable Speech-to-Text (STT)?")
    if wants_stt:
        stt_provider_name = select("Pick the STT provider:", list(STT_PROVIDERS.keys()))
        stt_provider_key = get_provider_key(stt_provider_name)
        stt_model = _select_model("Pick the STT model:", STT_PROVIDERS[stt_provider_name])

        if stt_provider_key not in api_keys_dict:
            stt_api_key = text_input(f"Enter API Key for {stt_provider_name}:", is_password=True)
            api_keys_dict[stt_provider_key] = stt_api_key

        stt_conf = STTConfig(enabled=True, provider=stt_provider_key, model=stt_model)
    else:
        stt_conf = STTConfig(enabled=False)

    # 3. TTS
    wants_tts = confirm("Do you want to enable Text-to-Speech (TTS)?")
    if wants_tts:
        tts_provider_name = select("Pick the TTS provider:", list(TTS_PROVIDERS.keys()))
        tts_provider_key = get_provider_key(tts_provider_name)
        tts_model = _select_model("Pick the TTS model:", TTS_PROVIDERS[tts_provider_name])

        tts_voice = None
        if tts_provider_name in VOICES:
            tts_voice = select("Pick a Voice:", VOICES[tts_provider_name])

        if tts_provider_key not in api_keys_dict:
            tts_api_key = text_input(f"Enter API Key for {tts_provider_name}:", is_password=True)
            api_keys_dict[tts_provider_key] = tts_api_key

        tts_conf = TTSConfig(enabled=True, provider=tts_provider_key, model=tts_model, voice=tts_voice)
    else:
        tts_conf = TTSConfig(enabled=False)

    # Create and save config
    providers = ProvidersConfig()
    for prov, key in api_keys_dict.items():
        setattr(providers, prov, ProviderConfig(api_key=key))

    agent_conf = AgentConfig(llm=llm_conf, stt=stt_conf, tts=tts_conf)
    
    # Check for telegram token and enable if present
    tg_token = os.getenv("TELEGRAM_TOKEN", "")
    # Check for discord token and enable if present
    discord_token = os.getenv("DISCORD_TOKEN", "")
    channels = ChannelsConfig(
        telegram=TelegramConfig(enabled=bool(tg_token), token=tg_token),
        discord=DiscordConfig(enabled=bool(discord_token), token=discord_token)
    )

    config_obj = Config(agent=agent_conf, providers=providers, channels=channels)
    config_dict = config_obj.model_dump(by_alias=True, exclude_none=True)

    from operator_use.paths import get_userdata_dir
    operator_use_dir = get_userdata_dir()
    operator_use_dir.mkdir(parents=True, exist_ok=True)
    config_path = operator_use_dir / "config.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config_dict, f, indent=4, ensure_ascii=False)

    # Write to .env
    key_to_env = {
        "groq":        "GROQ_API_KEY",
        "openai":      "OPENAI_API_KEY",
        "anthropic":   "ANTHROPIC_API_KEY",
        "google":      "GEMINI_API_KEY",
        "nvidia":      "NVIDIA_API_KEY",
        "deepseek":    "DEEPSEEK_API_KEY",
        "cerebras":    "CEREBRAS_API_KEY",
        "open_router": "OPENROUTER_API_KEY",
        "elevenlabs":  "ELEVENLABS_API_KEY",
        "deepgram":    "DEEPGRAM_API_KEY",
        "mistral":     "MISTRAL_API_KEY",
        "azure_openai":"AZURE_OPENAI_API_KEY",
        "sarvam":      "SARVAM_API_KEY",
    }
    env_vars = {key_to_env[k]: v for k, v in api_keys_dict.items() if k in key_to_env}
    if env_vars:
        with open(".env", "a") as f:
            f.write("\n")
            for k, v in env_vars.items():
                f.write(f"{k}={v}\n")

    print_end()

if __name__ == "__main__":
    run_initial_setup()
