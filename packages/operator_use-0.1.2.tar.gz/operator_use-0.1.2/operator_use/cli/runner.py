﻿"""Run Operator with Telegram channel and agent."""

import asyncio
import os
import shutil
from pathlib import Path

from dotenv import load_dotenv
import logging
from rich.console import Console

load_dotenv()

logger = logging.getLogger(__name__)

_console = Console()
_P = "#e5c07b"   # primary   – warm gold
_S = "#61afef"   # secondary – blue
_M = "#abb2bf"   # muted     – gray


def _row(label: str, value: str) -> None:
    _console.print(f"│ [{_M}]{label:<10}[/{_M}] [{_S}]{value}[/{_S}]")


def _print_startup(lines: list[tuple[str, str]], title_suffix: str = "") -> None:
    _console.print(f"┌ [bold {_P}]Operator[/bold {_P}][{_M}]{title_suffix}[/{_M}]")
    _console.print("│")
    for label, value in lines:
        _row(label, value)


def setup_logging(userdata_dir: Path) -> None:
    log_file = userdata_dir / "operator.log"
    userdata_dir.mkdir(parents=True, exist_ok=True)

    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    datefmt = "%H:%M:%S"
    handlers = [
        logging.StreamHandler(),
        logging.FileHandler(log_file, encoding="utf-8"),
    ]

    # Root at WARNING — everything inherits this, silencing all INFO noise
    logging.basicConfig(level=logging.WARNING, format=fmt, datefmt=datefmt, handlers=handlers)

import operator_use
from operator_use.agent import Agent
from operator_use.bus import Bus
from operator_use.gateway import Gateway
from operator_use.gateway.channels import TelegramChannel, DiscordChannel, SlackChannel, MQTTChannel
from operator_use.gateway.channels.config import TelegramConfig, MQTTConfig
from operator_use.gateway.channels.discord import DiscordConfig
from operator_use.gateway.channels.slack import SlackConfig
from operator_use.providers.base import BaseChatLLM, BaseSTT, BaseTTS

from operator_use.heartbeat import Heartbeat
from operator_use.crons.views import CronJob
from operator_use.crons import Cron
from operator_use.bus import OutgoingMessage, IncomingMessage, TextPart
from operator_use.config import Config, load_config
from typing import Optional
from pathlib import Path

LLM_CLASS_MAP = {
    "openai": "ChatOpenAI",
    "anthropic": "ChatAnthropic",
    "google": "ChatGoogle",
    "mistral": "ChatMistral",
    "groq": "ChatGroq",
    "nvidia": "ChatNvidia",
    "ollama": "ChatOllama",
    "cerebras": "ChatCerebras",
    "open_router": "ChatOpenRouter",
    "azure_openai": "ChatAzureOpenAI",
    "litellm": "ChatLiteLLM",
    "vllm": "ChatVLLM",
    "deepseek": "ChatDeepSeek",
    "codex": "ChatCodex",
    "claude_code": "ChatClaudeCode",
    "antigravity": "ChatAntigravity",
}

STT_CLASS_MAP = {
    "openai": "STTOpenAI",
    "google": "STTGoogle",
    "groq": "STTGroq",
    "elevenlabs": "STTElevenLabs",
    "deepgram": "STTDeepgram",
    "sarvam": "STTSarvam",
}

TTS_CLASS_MAP = {
    "openai": "TTSOpenAI",
    "google": "TTSGoogle",
    "groq": "TTSGroq",
    "elevenlabs": "TTSElevenLabs",
    "deepgram": "TTSDeepgram",
    "sarvam": "TTSSarvam",
}

def _make_models(config: Config) -> tuple[Optional[BaseChatLLM], Optional[BaseSTT], Optional[BaseTTS]]:
    import operator_use.providers as providers
    llm, stt, tts = None, None, None
    agent_conf = config.agent
    llm_conf = agent_conf.llm
    stt_conf = agent_conf.stt
    tts_conf = agent_conf.tts

    if stt_conf.enabled and stt_conf.provider:
        stt_cls_name = STT_CLASS_MAP.get(stt_conf.provider)
        if stt_cls_name and hasattr(providers, stt_cls_name):
            stt_cls = getattr(providers, stt_cls_name)
            # Find API key in providers
            p_conf = getattr(config.providers, stt_conf.provider, None)
            stt = stt_cls(model=stt_conf.model, api_key=p_conf.api_key if p_conf else None)
            
    if tts_conf.enabled and tts_conf.provider:
        tts_cls_name = TTS_CLASS_MAP.get(tts_conf.provider)
        if tts_cls_name and hasattr(providers, tts_cls_name):
            tts_cls = getattr(providers, tts_cls_name)
            p_conf = getattr(config.providers, tts_conf.provider, None)
            tts_kwargs = {
                "model": tts_conf.model,
                "api_key": p_conf.api_key if p_conf else None
            }
            if tts_conf.voice:
                tts_kwargs["voice"] = tts_conf.voice
            tts = tts_cls(**tts_kwargs)
            
    if llm_conf.provider:
        llm_cls_name = LLM_CLASS_MAP.get(llm_conf.provider)
        if llm_cls_name and hasattr(providers, llm_cls_name):
            llm_cls = getattr(providers, llm_cls_name)
            p_conf = getattr(config.providers, llm_conf.provider, None)
            llm = llm_cls(
                model=llm_conf.model,
                api_key=(p_conf.api_key or None) if p_conf else None,
                base_url=(p_conf.api_base or None) if p_conf else None
            )

    return llm, stt, tts


def copy_templates_to_workspace(user_data_dir: Path) -> None:
    """Copy template files to workspace, skipping files that already exist."""
    template_dir = Path(operator_use.__file__).resolve().parent / "templates"
    workspace = user_data_dir / "workspace"

    if not template_dir.exists():
        return

    (workspace / "skills").mkdir(parents=True, exist_ok=True)

    for src in template_dir.iterdir():
        if src.is_file():
            dest = workspace / src.name
            if dest.exists():
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
        elif src.is_dir():
            dest_dir = workspace / src.name
            dest_dir.mkdir(parents=True, exist_ok=True)
            for f in src.iterdir():
                if f.is_file():
                    dest_file = dest_dir / f.name
                    if not dest_file.exists():
                        shutil.copy2(f, dest_file)

async def main():
    from operator_use.paths import get_userdata_dir
    USERDATA_DIR = get_userdata_dir()
    setup_logging(USERDATA_DIR)
    copy_templates_to_workspace(USERDATA_DIR)

    try:
        config = load_config(USERDATA_DIR)
    except FileNotFoundError:
        print("Error: No config.json found. Please run 'uv run main.py onboard' first.")
        return

    bus = Bus()
    gateway = Gateway(bus=bus)

    # Add Telegram channel if enabled
    telegram_config = config.channels.telegram
    if not telegram_config.token:
        telegram_config.token = os.getenv("TELEGRAM_TOKEN", "")
    if telegram_config.token:
        channel = TelegramChannel(config=telegram_config, bus=bus)
        gateway.add_channel(channel)

    # Add Discord channel if enabled
    discord_config = config.channels.discord
    if not discord_config.token:
        discord_config.token = os.getenv("DISCORD_TOKEN", "")
    if discord_config.token:
        discord_channel = DiscordChannel(config=discord_config, bus=bus)
        gateway.add_channel(discord_channel)

    # Add Slack channel if enabled
    slack_config = config.channels.slack
    if not slack_config.bot_token:
        slack_config.bot_token = os.getenv("SLACK_BOT_TOKEN", "")
    if not slack_config.app_token:
        slack_config.app_token = os.getenv("SLACK_APP_TOKEN", "")
    if slack_config.bot_token and slack_config.app_token:
        slack_channel = SlackChannel(config=slack_config, bus=bus)
        gateway.add_channel(slack_channel)

    # Add MQTT channel if enabled
    mqtt_config = getattr(config.channels, "mqtt", None) or MQTTConfig()
    if mqtt_config.broker_host:
        mqtt_channel = MQTTChannel(config=mqtt_config, bus=bus)
        gateway.add_channel(mqtt_channel)

    if not telegram_config.token and not discord_config.token and not (slack_config.bot_token and slack_config.app_token) and not mqtt_config.broker_host:
        print("Error: No channel tokens configured (Telegram, Discord, Slack, or MQTT).")
        return

    llm, stt, tts = _make_models(config)

    async def on_job(job: CronJob):
        """When a cron job fires:
        - deliver=True: push message directly to the channel (no agent).
        - deliver=False: route message through the agent so it can act on it and respond.
        """
        channel = job.payload.channel
        chat_id = job.payload.chat_id
        message = job.payload.message
        if not message or not channel or not chat_id:
            return

        if job.payload.deliver:
            await bus.publish_outgoing(
                OutgoingMessage(
                    chat_id=chat_id,
                    channel=channel,
                    parts=[TextPart(content=message)],
                    reply=False,
                )
            )
        else:
            await bus.publish_incoming(
                IncomingMessage(
                    channel=channel,
                    chat_id=chat_id,
                    parts=[TextPart(content=message)],
                    user_id="cron",
                    metadata={"_cron_job": True, "job_id": job.id, "job_name": job.name},
                )
            )

    cron_store = USERDATA_DIR / "crons.json"
    cron = Cron(store_path=cron_store, on_job=on_job)
    agent = Agent(
        bus=bus,
        llm=llm,
        stt=stt,
        tts=tts,
        computer_use=config.agent.computer_use,
        streaming=config.agent.streaming,
        cron=cron,
        max_iterations=config.agent.max_tool_iterations,
        gateway=gateway,
    )

    async def on_heartbeat(content: str) -> None:
        return await agent.process_direct(
            content=content,
            channel="cli",
            chat_id="heartbeat",
        )

    # Set up heartbeat for self-improvement tasks
    heartbeat = Heartbeat(on_heartbeat=on_heartbeat)

    channels_active = []
    if telegram_config.token:
        channels_active.append("Telegram")
    if discord_config.token:
        channels_active.append("Discord")
    if mqtt_config.broker_host:
        channels_active.append(f"MQTT({mqtt_config.broker_host})")
    if slack_config.bot_token and slack_config.app_token:
        channels_active.append("Slack")

    llm_conf = config.agent.llm
    stt_conf = config.agent.stt
    tts_conf = config.agent.tts
    startup_rows: list[tuple[str, str]] = []
    if llm_conf.provider:
        startup_rows.append(("LLM", f"{llm_conf.provider} / {llm_conf.model}"))
    if stt_conf.enabled and stt_conf.provider:
        startup_rows.append(("STT", f"{stt_conf.provider} / {stt_conf.model}"))
    if tts_conf.enabled and tts_conf.provider:
        startup_rows.append(("TTS", f"{tts_conf.provider} / {tts_conf.model}"))

    suffix = "  (Ctrl+C to stop)"
    if config.agent.computer_use:
        suffix = " + Computer-Use" + suffix
    _print_startup(startup_rows, suffix)

    restart_file = USERDATA_DIR / "restart.json"

    try:
        heartbeat.start()
        cron.start()

        cron_jobs = cron.list_jobs()
        heartbeat_mins = int(heartbeat.interval // 60)
        _row("Heartbeat", f"every {heartbeat_mins} min")
        _row("Cron", f"{len(cron_jobs)} jobs")

        if restart_file.exists():
            import json as _json
            restart_data = _json.loads(restart_file.read_text(encoding="utf-8"))
            restart_file.unlink()
            task = restart_data.get("task", "")
            resume_channel = restart_data.get("channel")
            resume_chat_id = restart_data.get("chat_id")
            print(f"[restart] Continuation found (channel={resume_channel} chat_id={resume_chat_id}): {task[:80]}", flush=True)
            if task and resume_channel and resume_chat_id:
                async def _dispatch_continuation():
                    # Wait for gateway channels to connect before dispatching
                    await asyncio.sleep(10)
                    print(f"[restart] Dispatching continuation to channel={resume_channel} chat_id={resume_chat_id}", flush=True)
                    await bus.publish_incoming(
                        IncomingMessage(
                            channel=resume_channel,
                            chat_id=resume_chat_id,
                            parts=[TextPart(content=task)],
                            user_id="restart",
                        )
                    )
                asyncio.ensure_future(_dispatch_continuation())

        await asyncio.gather(
            gateway.start(),
            agent.ainvoke(),
        )
    except (asyncio.CancelledError, KeyboardInterrupt):
        pass
    finally:
        heartbeat.stop()
        cron.stop()
        # Shield shutdown from cancellation so it completes before event loop stops
        try:
            await asyncio.shield(gateway.stop())
        except asyncio.CancelledError:
            pass
        pass


if __name__ == "__main__":
    asyncio.run(main())
