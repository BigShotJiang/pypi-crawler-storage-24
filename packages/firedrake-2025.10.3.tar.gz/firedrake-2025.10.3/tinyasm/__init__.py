from ._tinyasm import *
