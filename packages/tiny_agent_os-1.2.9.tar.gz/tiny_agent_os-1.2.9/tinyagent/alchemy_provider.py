"""Compatibility provider for the optional tinyagent-alchemy binding.

This module keeps the Python-side adapter for the external `tinyagent._alchemy`
extension. The binding itself is maintained outside this repo:

    https://github.com/tunahorse/tinyagent-alchemy

Important limitations:
- The binding currently dispatches only `openai-completions` and
  `minimax-completions` APIs.
- Image blocks are not supported yet.
- Python receives events by calling a blocking `next_event()` method in a thread,
  so it is real-time but has more overhead than a native async generator.
"""

from __future__ import annotations

import asyncio
import importlib
import os
from dataclasses import dataclass
from typing import Literal, Protocol, TypeAlias, cast

from .agent_types import (
    AgentTool,
    AssistantMessage,
    AssistantMessageEvent,
    Context,
    JsonObject,
    Model,
    SimpleStreamOptions,
    dump_model_dumpable,
)

ReasoningEffort: TypeAlias = Literal["minimal", "low", "medium", "high", "xhigh"]
ReasoningMode: TypeAlias = bool | ReasoningEffort


class _AlchemyStreamHandle(Protocol):
    def next_event(self) -> object | None: ...

    def result(self) -> object: ...


class _AlchemyModule(Protocol):
    def openai_completions_stream(
        self,
        model: dict[str, object],
        context: dict[str, object],
        options: dict[str, object],
    ) -> _AlchemyStreamHandle: ...


_ALCHEMY_MODULE: _AlchemyModule | None = None

DEFAULT_OPENAI_COMPAT_CHAT_COMPLETIONS_URL = "https://api.openai.com/v1/chat/completions"

_PROVIDER_API_KEY_ENV = {
    "openai": "OPENAI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "minimax": "MINIMAX_API_KEY",
    "minimax-cn": "MINIMAX_CN_API_KEY",
}

_USAGE_KEYS = frozenset({"input", "output", "cache_read", "cache_write", "total_tokens", "cost"})
_COST_KEYS = frozenset({"input", "output", "cache_read", "cache_write", "total"})


def _missing_keys(data: dict[str, object], required: frozenset[str]) -> list[str]:
    return sorted(key for key in required if key not in data)


def _validate_usage_contract(raw_usage: object, *, where: str) -> JsonObject:
    if not isinstance(raw_usage, dict):
        raise RuntimeError(f"{where}: usage must be a dict")

    usage = cast(dict[str, object], raw_usage)
    missing_usage = _missing_keys(usage, _USAGE_KEYS)
    if missing_usage:
        raise RuntimeError(f"{where}: usage missing key(s): {', '.join(missing_usage)}")

    cost_raw = usage.get("cost")
    if not isinstance(cost_raw, dict):
        raise RuntimeError(f"{where}: usage.cost must be a dict")

    cost = cast(dict[str, object], cost_raw)
    missing_cost = _missing_keys(cost, _COST_KEYS)
    if missing_cost:
        raise RuntimeError(f"{where}: usage.cost missing key(s): {', '.join(missing_cost)}")

    return cast(JsonObject, usage)


def _validate_assistant_message_contract(
    raw_message: object,
    *,
    where: str,
    require_usage: bool,
) -> AssistantMessage:
    if isinstance(raw_message, AssistantMessage):
        message = raw_message
    elif isinstance(raw_message, dict):
        message = AssistantMessage.model_validate(raw_message)
    else:
        raise RuntimeError(f"{where}: assistant message must be a dict")

    if require_usage:
        _validate_usage_contract(message.usage, where=where)

    return message


def _get_alchemy_module() -> _AlchemyModule:
    global _ALCHEMY_MODULE
    if _ALCHEMY_MODULE is None:
        package = __package__ or "tinyagent"
        import_errors: list[Exception] = []
        for module_name in (f"{package}._alchemy", "_alchemy"):
            try:
                module = importlib.import_module(module_name)
                _ALCHEMY_MODULE = cast(_AlchemyModule, module)
                break
            except Exception as exc:  # pragma: no cover
                import_errors.append(exc)
        if _ALCHEMY_MODULE is None:
            raise RuntimeError(
                "tinyagent._alchemy is not installed. "
                "Install the optional binding from "
                "https://github.com/tunahorse/tinyagent-alchemy"
            ) from import_errors[-1]
    return _ALCHEMY_MODULE


class OpenAICompatModel(Model):
    """Model config for OpenAI-compatible chat/completions endpoints."""

    provider: str = "openrouter"
    id: str = "moonshotai/kimi-k2.5"
    api: str = "openai-completions"

    base_url: str = DEFAULT_OPENAI_COMPAT_CHAT_COMPLETIONS_URL
    name: str | None = None
    headers: dict[str, str] | None = None

    context_window: int = 128_000
    max_tokens: int = 4096
    reasoning: ReasoningMode = False


@dataclass
class AlchemyStreamResponse:
    """StreamResponse backed by a Rust stream handle."""

    _handle: _AlchemyStreamHandle
    _final_message: AssistantMessage | None = None

    async def result(self) -> AssistantMessage:
        if self._final_message is not None:
            return self._final_message

        msg = await asyncio.to_thread(self._handle.result)
        final_message = _validate_assistant_message_contract(
            msg,
            where="result",
            require_usage=True,
        )
        self._final_message = final_message
        return final_message

    def __aiter__(self) -> AlchemyStreamResponse:
        return self

    async def __anext__(self) -> AssistantMessageEvent:
        ev = await asyncio.to_thread(self._handle.next_event)
        if ev is None:
            raise StopAsyncIteration
        if isinstance(ev, AssistantMessageEvent):
            return ev
        if not isinstance(ev, dict):
            raise RuntimeError("tinyagent._alchemy returned an invalid event")
        return AssistantMessageEvent.model_validate(ev)


def _convert_tools(tools: list[AgentTool] | None) -> list[dict[str, object]] | None:
    if not tools:
        return None
    out: list[dict[str, object]] = []
    for t in tools:
        out.append(
            {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters or {"type": "object", "properties": {}},
            }
        )
    return out


def _resolve_base_url(model: Model) -> str:
    if not isinstance(model, OpenAICompatModel):
        return DEFAULT_OPENAI_COMPAT_CHAT_COMPLETIONS_URL
    base_url = model.base_url.strip()
    if not base_url:
        raise ValueError("Model `base_url` must be a non-empty string")
    return base_url


def _resolve_provider(model: Model) -> str:
    provider = model.provider.strip()
    return provider or "openai"


def _canonicalize_api(raw_api: str) -> str:
    api = raw_api.strip().lower()
    if not api:
        return ""

    # Legacy aliases used in tinyagent Model.api values.
    if api in {"openai", "openai-compatible", "chat-completions"}:
        return "openai-completions"
    if api == "minimax":
        return "minimax-completions"

    return api


def _infer_api_from_provider(provider: str) -> str:
    provider_lc = provider.strip().lower()
    if provider_lc in {"minimax", "minimax-cn"}:
        return "minimax-completions"
    return "openai-completions"


def _resolve_model_api(model: Model, provider: str) -> str:
    """Resolve alchemy API with explicit override and provider fallback.

    Resolution order:
    1) `model.api` when present/non-empty (with legacy alias normalization)
    2) provider-based inference (`minimax|minimax-cn` => minimax-completions,
       else openai-completions)
    """

    explicit = _canonicalize_api(model.api)
    if explicit:
        return explicit

    return _infer_api_from_provider(provider)


def _resolve_api_key(model: Model, options: SimpleStreamOptions) -> str | None:
    explicit = options.api_key
    if explicit:
        return explicit

    provider = _resolve_provider(model).lower()
    env_var = _PROVIDER_API_KEY_ENV.get(provider)
    if not env_var:
        return None

    return os.environ.get(env_var)


async def stream_alchemy_openai_completions(
    model: Model,
    context: Context,
    options: SimpleStreamOptions,
) -> AlchemyStreamResponse:
    """Stream using the Rust alchemy-llm implementation (OpenAI-compatible)."""

    alchemy_llm_py = _get_alchemy_module()

    provider = _resolve_provider(model)
    base_url = _resolve_base_url(model)
    api = _resolve_model_api(model, provider)
    name: str | None = None
    headers: dict[str, str] | None = None
    reasoning: ReasoningMode = False
    context_window: int | None = None
    max_tokens: int | None = None
    if isinstance(model, OpenAICompatModel):
        name = model.name
        headers = model.headers
        reasoning = model.reasoning
        context_window = model.context_window
        max_tokens = model.max_tokens

    model_dict: dict[str, object] = {
        "id": model.id,
        "provider": provider,
        "api": api,
        "base_url": base_url,
        "name": name,
        "headers": headers,
        "reasoning": reasoning,
        "context_window": context_window,
        "max_tokens": max_tokens,
    }

    context_dict: dict[str, object] = {
        "system_prompt": context.system_prompt or "",
        "messages": [
            dump_model_dumpable(message, where="context.messages") for message in context.messages
        ],
        "tools": _convert_tools(context.tools),
    }

    options_dict: dict[str, object] = {
        "api_key": _resolve_api_key(model, options),
        "temperature": options.temperature,
        "max_tokens": options.max_tokens,
    }

    handle = alchemy_llm_py.openai_completions_stream(
        model_dict,
        context_dict,
        options_dict,
    )

    return AlchemyStreamResponse(_handle=handle)
