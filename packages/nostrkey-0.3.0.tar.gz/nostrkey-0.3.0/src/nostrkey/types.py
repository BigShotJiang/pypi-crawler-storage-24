"""Shared types for the NostrKey ecosystem.

SecretStr is the standard way to handle sensitive strings across all
Humanjava OC skills. Import it from nostrkey:

    from nostrkey import SecretStr
"""

from __future__ import annotations


class SecretStr:
    """A string that redacts itself in repr/str to prevent secret leakage.

    Use this for any sensitive value: mnemonics, API keys, passphrases,
    nsec keys, connection strings. The value is only accessible via
    get_secret_value() — an explicit, intentional call.

    Usage:
        secret = SecretStr("my-api-key")
        print(secret)        # "***"
        repr(secret)         # "SecretStr('***')"
        f"key: {secret}"     # "key: ***"
        secret.get_secret_value()  # "my-api-key" (explicit access)

    Immutable — cannot be modified after creation.
    """

    __slots__ = ("_value",)

    def __init__(self, value: str) -> None:
        if not isinstance(value, str):
            raise TypeError(f"SecretStr requires a str, got {type(value).__name__}")
        object.__setattr__(self, "_value", value)

    def get_secret_value(self) -> str:
        """Explicitly retrieve the secret. Use intentionally."""
        return self._value

    def __repr__(self) -> str:
        return "SecretStr('***')"

    def __str__(self) -> str:
        return "***"

    def __bool__(self) -> bool:
        return bool(self._value)

    def __len__(self) -> int:
        return len(self._value)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SecretStr):
            return self._value == other._value
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._value)

    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError("SecretStr is immutable")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("SecretStr is immutable")
