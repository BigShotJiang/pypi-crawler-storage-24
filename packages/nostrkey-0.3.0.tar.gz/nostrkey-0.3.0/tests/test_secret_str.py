"""Tests for SecretStr — the shared secret handling type for the OC platform."""

import pytest

from nostrkey import SecretStr


# ── Redaction ────────────────────────────────────────────────


def test_repr_redacts():
    s = SecretStr("super-secret-mnemonic-phrase")
    assert "super-secret" not in repr(s)
    assert "***" in repr(s)


def test_str_redacts():
    s = SecretStr("super-secret-mnemonic-phrase")
    assert str(s) == "***"


def test_format_redacts():
    s = SecretStr("super-secret-mnemonic-phrase")
    assert "super-secret" not in f"Config: {s}"
    assert "***" in f"Config: {s}"


def test_repr_format_redacts():
    s = SecretStr("super-secret")
    assert "super-secret" not in f"{s!r}"


# ── Access ───────────────────────────────────────────────────


def test_get_secret_value():
    s = SecretStr("my-actual-secret")
    assert s.get_secret_value() == "my-actual-secret"


def test_bool_nonempty():
    assert bool(SecretStr("notempty")) is True


def test_bool_empty():
    assert bool(SecretStr("")) is False


def test_len():
    assert len(SecretStr("hello")) == 5
    assert len(SecretStr("")) == 0


# ── Immutability ─────────────────────────────────────────────


def test_setattr_blocked():
    s = SecretStr("value")
    with pytest.raises(AttributeError, match="immutable"):
        s._value = "changed"


def test_delattr_blocked():
    s = SecretStr("value")
    with pytest.raises(AttributeError, match="immutable"):
        del s._value


def test_new_attr_blocked():
    s = SecretStr("value")
    with pytest.raises(AttributeError, match="immutable"):
        s.other = "nope"


# ── Equality & Hashing ──────────────────────────────────────


def test_equality_same():
    a = SecretStr("same")
    b = SecretStr("same")
    assert a == b


def test_equality_different():
    a = SecretStr("one")
    b = SecretStr("two")
    assert a != b


def test_equality_not_str():
    s = SecretStr("value")
    assert s != "value"  # SecretStr != str


def test_hashable():
    s = SecretStr("key")
    d = {s: "works"}
    assert d[SecretStr("key")] == "works"


# ── Type Safety ──────────────────────────────────────────────


def test_rejects_non_string():
    with pytest.raises(TypeError, match="requires a str"):
        SecretStr(12345)


def test_rejects_none():
    with pytest.raises(TypeError, match="requires a str"):
        SecretStr(None)


def test_rejects_bytes():
    with pytest.raises(TypeError, match="requires a str"):
        SecretStr(b"bytes")


# ── Import Path ──────────────────────────────────────────────


def test_importable_from_nostrkey():
    """Verify SecretStr is importable from the top-level nostrkey package."""
    from nostrkey import SecretStr as S
    assert S is SecretStr


def test_importable_from_types():
    """Verify SecretStr is importable from nostrkey.types."""
    from nostrkey.types import SecretStr as S
    assert S is SecretStr
