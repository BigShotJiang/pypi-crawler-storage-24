"""Runtime configuration from Firestore /config/{agent_name}.

Usage:
    from agent_shared_core.core.config import get_config

    config = get_config("mktg_banner_generator")
    preview_count = config.get("preview_count", 3)
    model_id = config.get("model_id", "imagen-4-fast")
"""

import logging

logger = logging.getLogger(__name__)


def get_config(agent_name: str) -> dict:
    """Read agent configuration from Firestore /config/{agent_name}.

    Returns the document as a dict. Returns empty dict if the document
    does not exist or on Firestore failure. Callers use the
    .get(key, default) pattern to handle missing keys.
    """
    from agent_shared_core.core.firestore import get_client

    try:
        doc = get_client().collection("config").document(agent_name).get()
        if doc.exists:
            return doc.to_dict()
        return {}
    except Exception:
        logger.warning(
            "Failed to read config for %s, returning empty dict",
            agent_name,
            exc_info=True,
        )
        return {}

