"""Workflow checkpoints via ADK session state (no external deps).

Agents use checkpoints to persist intermediate progress within a session.
Data is stored in tool_context.state["checkpoint"] as a flat dict.

Usage:
    from agent_shared_core.core.checkpoints import save_checkpoint, read_checkpoint

    # Save progress after a step completes
    save_checkpoint(tool_context, {"step": "theme_selected", "theme_id": "abc123"})

    # Read current checkpoint (returns None if no checkpoint exists)
    cp = read_checkpoint(tool_context)
    if cp:
        print(cp["step"])  # "theme_selected"

    # Subsequent saves merge into the existing checkpoint
    save_checkpoint(tool_context, {"step": "preview_generated", "image_url": "https://..."})
    # checkpoint now has: step, theme_id, image_url, last_updated
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


def save_checkpoint(tool_context, data: dict) -> None:
    """Merge data into the session checkpoint and set last_updated.

    Reads the existing checkpoint from tool_context.state, merges new
    keys (overwriting on conflict), stamps the current UTC time, and
    writes back.

    Args:
        tool_context: ADK ToolContext with a .state dict.
        data: key-value pairs to merge into the checkpoint.
    """
    checkpoint = tool_context.state.get("checkpoint", {})
    checkpoint.update(data)
    checkpoint["last_updated"] = datetime.now(timezone.utc).isoformat()
    tool_context.state["checkpoint"] = checkpoint

    step = data.get("step", "unknown")
    logger.info("Checkpoint saved: step=%s", step)


def read_checkpoint(tool_context) -> dict | None:
    """Read the current checkpoint from session state.

    Args:
        tool_context: ADK ToolContext with a .state dict.

    Returns:
        The checkpoint dict, or None if no checkpoint exists.
    """
    return tool_context.state.get("checkpoint") or None

