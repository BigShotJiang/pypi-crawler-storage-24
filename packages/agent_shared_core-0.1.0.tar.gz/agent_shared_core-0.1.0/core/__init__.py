# agent_shared_core.core: universal infrastructure (firestore, auth, wallet, config, prompts)

