"""Cost tracking: @wallet_track decorator and log_cost() for /wallet/ collection.

Usage:
    from agent_shared_core.core.wallet import log_cost, wallet_track

    # Direct logging
    log_cost("agent_name", "user@co.com", "model-id", 0.06, "preview")

    # Decorator on cost-incurring tools
    @wallet_track(agent="mktg_banner_generator")
    def generate_preview(user_email, model, phase, ...):
        ...
        return {"cost": 0.06, "images": [...], "phase": "preview"}
"""

import hashlib
import inspect
import logging
from datetime import datetime, timezone
from functools import wraps

logger = logging.getLogger(__name__)


def log_cost(
    agent: str,
    user_email: str,
    model: str,
    cost: float,
    phase: str,
    metadata: dict = None,
) -> None:
    """Write a cost record to the /wallet/ collection.

    The timestamp field is auto-set to current UTC time.
    If metadata is provided, its keys are merged into the record.
    """
    from agent_shared_core.core.firestore import get_client

    record = {
        "agent": agent,
        "user_email": user_email,
        "model": model,
        "cost": cost,
        "phase": phase,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if metadata:
        record.update(metadata)

    try:
        # Deterministic ID: hash of agent + user + phase + minute-level timestamp.
        # Minute-level granularity: one record per invocation per minute,
        # prevents duplicates on immediate retry.
        minute_ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M")
        id_source = f"{agent}:{user_email}:{phase}:{minute_ts}"
        doc_id = hashlib.sha256(id_source.encode()).hexdigest()[:32]
        get_client().collection("wallet").document(doc_id).set(record)
        logger.info("Wallet: logged $%.4f for %s (%s)", cost, agent, phase)
    except Exception:
        logger.error(
            "Wallet: failed to log $%.4f for %s (%s)", cost, agent, phase,
            exc_info=True,
        )


def wallet_track(agent: str):
    """Decorator that auto-logs cost from tool return value.

    Inspects the tool's return dict for a 'cost' key. If present, calls
    log_cost() with agent, user_email, model, cost, and phase extracted
    from the return value or function kwargs.

    On partial failure (tool raises an exception with a .cost attribute),
    the cost is still logged before re-raising.
    """
    def decorator(func):
        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                try:
                    result = await func(*args, **kwargs)
                except Exception as exc:
                    if hasattr(exc, "cost") and exc.cost:
                        _log_from_kwargs(agent, kwargs, exc.cost, kwargs.get("phase", "unknown"))
                    raise

                if isinstance(result, dict) and "cost" in result:
                    cost = result["cost"]
                    phase = result.get("phase", kwargs.get("phase", "unknown"))
                    _log_from_kwargs(agent, kwargs, cost, phase, result=result)

                return result
            return async_wrapper
        else:
            @wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    result = func(*args, **kwargs)
                except Exception as exc:
                    if hasattr(exc, "cost") and exc.cost:
                        _log_from_kwargs(agent, kwargs, exc.cost, kwargs.get("phase", "unknown"))
                    raise

                if isinstance(result, dict) and "cost" in result:
                    cost = result["cost"]
                    phase = result.get("phase", kwargs.get("phase", "unknown"))
                    _log_from_kwargs(agent, kwargs, cost, phase, result=result)

                return result
            return wrapper
    return decorator


def _log_from_kwargs(
    agent: str, kwargs: dict, cost: float, phase: str, result: dict = None
) -> None:
    """Extract user_email and model from result or kwargs and log cost.

    Prefers values from the result dict (set by the tool function after
    resolving session metadata) over raw kwargs (which may have defaults).
    """
    result = result or {}
    user_email = result.get("user_email") or kwargs.get("user_email", "unknown")
    model = result.get("model") or kwargs.get("model", "unknown")
    log_cost(agent, user_email, model, cost, phase)

