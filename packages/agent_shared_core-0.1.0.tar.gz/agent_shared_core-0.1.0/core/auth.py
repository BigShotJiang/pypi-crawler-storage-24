"""Role resolution via Google Directory API with TTL cache.

Usage:
    from agent_shared_core.core.auth import resolve_role
    role = resolve_role("user@company.com", "mktg")  # returns "admin" or "exec"
"""

import logging
import os
import time
from typing import Dict, Tuple

logger = logging.getLogger(__name__)

# Cache: key = (email, dept), value = (role, timestamp)
_role_cache: Dict[Tuple[str, str], Tuple[str, float]] = {}

# Cache TTL in seconds (5 minutes)
_CACHE_TTL = 300

# Read domain from environment. Set per customer deployment.
# Default to company.com for the dev sandbox (concretio-compass-sb).
_GROUP_DOMAIN = os.environ.get("COMPASS_GROUP_DOMAIN", "company.com")


def _check_group_membership(email: str, group_email: str) -> bool:
    """Check if email is a member of the given Google Group.

    Uses the Google Admin SDK Directory API.
    """
    from googleapiclient.discovery import build
    import google.auth

    credentials, _ = google.auth.default(
        scopes=["https://www.googleapis.com/auth/admin.directory.group.member.readonly"]
    )
    service = build("admin", "directory_v1", credentials=credentials)

    try:
        result = service.members().hasMember(
            groupKey=group_email, memberKey=email
        ).execute()
        return result.get("isMember", False)
    except Exception:
        return False


def resolve_role(email: str, dept: str) -> str:
    """Resolve user role based on Google Group membership.

    Returns "admin" if the user is in {dept}-admins@company.com,
    otherwise returns "exec". On API failure, defaults to "exec" (safe default).

    Results are cached for 5 minutes per (email, dept) pair.
    """
    cache_key = (email, dept)

    # Check cache
    if cache_key in _role_cache:
        cached_role, cached_time = _role_cache[cache_key]
        if time.time() - cached_time < _CACHE_TTL:
            return cached_role

    # Query Directory API
    try:
        admin_group = f"{dept}-admins@{_GROUP_DOMAIN}"
        is_admin = _check_group_membership(email, admin_group)
        role = "admin" if is_admin else "exec"
    except Exception:
        logger.warning(
            "Directory API failure for %s in dept %s, defaulting to exec",
            email, dept,
        )
        role = "exec"

    # Cache the result
    _role_cache[cache_key] = (role, time.time())
    return role

