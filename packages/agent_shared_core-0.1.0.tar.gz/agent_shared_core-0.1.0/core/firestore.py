"""Singleton Firestore client for the Compass Agent Framework.

Usage:
    from agent_shared_core.core.firestore import get_client
    db = get_client()
    doc = db.collection("brands").document("abc").get()
"""

import logging
import os

from google.cloud import firestore

logger = logging.getLogger(__name__)

_client = None


def get_client() -> firestore.Client:
    """Return a lazy-initialized singleton Firestore client.

    Uses GOOGLE_CLOUD_PROJECT from the environment, defaulting to
    concretio-compass-sb (the sandbox project).
    """
    global _client
    if _client is None:
        project = os.environ.get("GOOGLE_CLOUD_PROJECT", "concretio-compass-sb")
        _client = firestore.Client(project=project)
        logger.info("Firestore client initialized for project: %s", project)
    return _client

