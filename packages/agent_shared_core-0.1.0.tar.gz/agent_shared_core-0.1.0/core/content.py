"""Content extraction and context analysis for agent workflows.

Usage:
    from agent_shared_core.core.content import fetch_content, extract_content_context

    # Fetch from URL
    result = fetch_content("https://example.com/article")
    # => {"source": "https://...", "content": "...", "content_type": "url", "success": True}

    # Pass raw text
    result = fetch_content("Some plain text content here.")
    # => {"source": "Some plain...", "content": "Some plain...", "content_type": "text", "success": True}

    # Pass markdown
    result = fetch_content("# Heading\n\n**Bold** text with [links](url)")
    # => {"source": "# Heading...", "content": "Heading\nBold text with links", "content_type": "markdown", "success": True}

    # Extract structured context via Gemini Flash
    context = extract_content_context("Article text here...")
    # => {"title": "...", "vertical": "...", "key_themes": [...], ...}
"""

import json
import logging
import os
import re

import trafilatura

logger = logging.getLogger(__name__)

_MAX_CONTENT_LENGTH = 15_000

_EXTRACTION_PROMPT = """Extract structured information from the following content.
Return ONLY valid JSON with these keys:
- title (string): the main title or topic
- vertical (string): the industry or domain vertical
- key_themes (list of strings): 3-5 main themes
- mood (string): overall tone or mood
- visual_cues (list of strings): 2-4 visual elements suggested by the content
- color_hints (list of strings): 2-4 colors associated with the content's mood or vertical
- summary (string): 2-3 sentence summary

Content:
{content}
"""


def fetch_content(source: str) -> dict:
    """Fetch and normalize content from a URL, raw text, or markdown.

    URLs are fetched via trafilatura. Markdown is stripped of formatting.
    All content is truncated to 15,000 chars.

    Args:
        source: a URL (http/https), markdown string, or plain text.

    Returns:
        Dict with keys: source, content, content_type, success, and error (on failure).
    """
    if source.startswith("http://") or source.startswith("https://"):
        return _fetch_url(source)

    if _looks_like_markdown(source):
        text = _strip_markdown(source)[:_MAX_CONTENT_LENGTH]
        return {"source": source, "content": text, "content_type": "markdown", "success": True}

    text = source[:_MAX_CONTENT_LENGTH]
    return {"source": source, "content": text, "content_type": "text", "success": True}


def extract_content_context(text: str) -> dict:
    """Extract structured context from text using Gemini 2.0 Flash.

    Calls the model with a structured extraction prompt and parses the
    JSON response. Logs cost via agent_shared_core.core.wallet.log_cost().

    Args:
        text: the content to analyze.

    Returns:
        Dict with title, vertical, key_themes, mood, visual_cues, color_hints, summary.
        On failure, returns {"error": "..."}.
    """
    from google import genai

    project = os.environ.get("GOOGLE_CLOUD_PROJECT", "concretio-compass-sb")
    location = os.environ.get("GOOGLE_CLOUD_LOCATION", "us-central1")

    try:
        client = genai.Client(
            vertexai=True,
            project=project,
            location=location,
        )

        prompt = _EXTRACTION_PROMPT.format(content=text[:_MAX_CONTENT_LENGTH])
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt,
        )

        raw = response.text.strip()
        # Strip markdown code fences if the model wraps its output
        if raw.startswith("```"):
            raw = re.sub(r"^```(?:json)?\s*", "", raw)
            raw = re.sub(r"\s*```$", "", raw)

        result = json.loads(raw)

        # Log cost estimate
        from agent_shared_core.core.wallet import log_cost
        log_cost(
            agent="content_extraction",
            user_email="system",
            model="gemini-2.0-flash",
            cost=0.001,
            phase="extract_context",
        )

        logger.info("Content context extracted: title=%s", result.get("title", "unknown"))
        return result

    except json.JSONDecodeError as exc:
        logger.error("Failed to parse Gemini response as JSON: %s", exc)
        return {"error": f"JSON parse error: {exc}"}
    except Exception as exc:
        logger.error("Content context extraction failed: %s", exc, exc_info=True)
        return {"error": str(exc)}


# --- Internal helpers ---


def _fetch_url(url: str) -> dict:
    """Download and extract article text from a URL via trafilatura."""
    try:
        downloaded = trafilatura.fetch_url(url)
        if downloaded is None:
            return {
                "source": url,
                "content": "",
                "content_type": "url",
                "success": False,
                "error": f"Could not fetch URL: {url}",
            }

        text = trafilatura.extract(downloaded)
        if text is None:
            return {
                "source": url,
                "content": "",
                "content_type": "url",
                "success": False,
                "error": f"Could not extract content from: {url}",
            }

        truncated = text[:_MAX_CONTENT_LENGTH]
        return {
            "source": url,
            "content": truncated,
            "content_type": "url",
            "success": True,
        }
    except Exception as exc:
        logger.error("URL fetch failed for %s: %s", url, exc)
        return {
            "source": url,
            "content": "",
            "content_type": "url",
            "success": False,
            "error": f"Extraction failed: {exc}",
        }


def _looks_like_markdown(text: str) -> bool:
    """Detect if text contains common markdown patterns."""
    md_patterns = [
        r"^#{1,6}\s",       # headings
        r"\*\*.+\*\*",      # bold
        r"\[.+\]\(.+\)",    # links
        r"^[-*]\s",          # unordered lists
        r"^\d+\.\s",        # ordered lists
        r"^>\s",             # blockquotes
        r"```",              # code blocks
    ]
    for pattern in md_patterns:
        if re.search(pattern, text, re.MULTILINE):
            return True
    return False


def _strip_markdown(text: str) -> str:
    """Remove common markdown formatting, returning plain text."""
    # Remove code blocks
    text = re.sub(r"```[\s\S]*?```", "", text)
    # Remove inline code
    text = re.sub(r"`([^`]+)`", r"\1", text)
    # Remove images
    text = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", text)
    # Remove links, keep text
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    # Remove headings markers
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    # Remove bold/italic markers
    text = re.sub(r"\*{1,3}([^*]+)\*{1,3}", r"\1", text)
    text = re.sub(r"_{1,3}([^_]+)_{1,3}", r"\1", text)
    # Remove blockquote markers
    text = re.sub(r"^>\s?", "", text, flags=re.MULTILINE)
    # Remove horizontal rules
    text = re.sub(r"^[-*_]{3,}\s*$", "", text, flags=re.MULTILINE)
    # Collapse multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

