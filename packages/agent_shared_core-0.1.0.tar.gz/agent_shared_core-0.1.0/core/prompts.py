"""Prompt retrieval with Firestore override and git file fallback.

Usage:
    from agent_shared_core.core.prompts import get_prompt

    system_prompt = get_prompt(
        "mktg_banner_generator",
        "system",
        "mktg_banner_generator/knowledge/system.md",
    )
"""

import logging
import os

logger = logging.getLogger(__name__)


def get_prompt(agent_name: str, prompt_type: str, fallback_path: str) -> str:
    """Retrieve a prompt, checking Firestore first, then falling back to a local file.

    Firestore path: /prompts/{agent_name}/types/{prompt_type}
    Returns the 'content' field if the document exists and has status 'active'.
    Otherwise reads the local file at fallback_path.

    Returns empty string if both sources fail.
    """
    # Try Firestore first
    try:
        from agent_shared_core.core.firestore import get_client

        doc = (
            get_client()
            .collection("prompts")
            .document(agent_name)
            .collection("types")
            .document(prompt_type)
            .get()
        )
        if doc.exists:
            data = doc.to_dict()
            if data.get("status") == "active":
                return data.get("content", "")
    except Exception:
        logger.warning(
            "Firestore lookup failed for prompt %s/%s, falling back to file",
            agent_name,
            prompt_type,
            exc_info=True,
        )

    # Fall back to local file
    return _read_fallback(fallback_path)


def _read_fallback(path: str) -> str:
    """Read prompt content from a local file."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except (FileNotFoundError, OSError):
        logger.warning("Fallback file not found: %s", path)
        return ""

