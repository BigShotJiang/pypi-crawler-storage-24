"""Image generation and upscaling via Vertex AI (Imagen 4 + Gemini 3 Pro).

Usage:
    from agent_shared_core.core.image_gen import generate_images, upscale_image

    # Generate preview images
    results = generate_images("a glass panel banner...", resolution="LinkedIn post", count=3)
    # => [{"image_bytes": b"...", "aspect_ratio": "16:9"}, ...]

    # Upscale from bytes
    upscaled = upscale_image(source_bytes, target_size="2K")
    # => b"..." (upscaled image bytes)

GCS upload is optional and separate. For local dev, tools return base64
and save as ADK artifacts. For production, a Cloud Run wrapper can handle
GCS upload via this same module.
"""

import base64
import logging
import os

from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

# --- Model IDs ---

GENERATE_MODEL_ID = "imagen-4.0-fast-generate-001"
UPSCALE_MODEL_ID = "gemini-3.0-pro-image-generate-001"

# --- Resolution table ---

RESOLUTION_TABLE: dict[str, tuple[int, int]] = {
    "LinkedIn post": (1200, 628),
    "LinkedIn banner": (1584, 396),
    "Twitter/X header": (1500, 500),
    "Twitter/X post": (1200, 675),
    "Facebook cover": (851, 315),
    "Facebook post": (1200, 630),
    "Instagram square": (1080, 1080),
    "Instagram story": (1080, 1920),
    "YouTube thumbnail": (1280, 720),
    "YouTube banner": (2560, 1440),
    "Blog universal": (1200, 628),
    "Blog OG social": (1200, 630),
    "WordPress featured image": (1200, 628),
    "Medium header": (1400, 788),
    "Presentation slide 16:9": (1920, 1080),
    "Presentation slide 4:3": (1440, 1080),
}

DEFAULT_RESOLUTION = (1200, 628)

# --- Aspect ratio mapping for Imagen 4 ---

SUPPORTED_ASPECT_RATIOS = ["1:1", "9:16", "16:9", "3:4", "4:3"]

_ASPECT_RATIO_VALUES = {
    "1:1": 1.0,
    "9:16": 9 / 16,
    "16:9": 16 / 9,
    "3:4": 3 / 4,
    "4:3": 4 / 3,
}

# --- Upscale target dimensions ---

UPSCALE_TARGETS = {
    "2K": (2048, 2048),
    "4K": (4096, 4096),
}


def _get_client() -> genai.Client:
    """Create a google-genai client configured for Vertex AI."""
    project = os.environ.get("GOOGLE_CLOUD_PROJECT", "concretio-compass-sb")
    location = os.environ.get("GOOGLE_CLOUD_LOCATION", "us-central1")
    return genai.Client(vertexai=True, project=project, location=location)


def _closest_aspect_ratio(width: int, height: int) -> str:
    """Map width/height to the nearest supported Imagen 4 aspect ratio."""
    target = width / height
    return min(
        SUPPORTED_ASPECT_RATIOS,
        key=lambda r: abs(_ASPECT_RATIO_VALUES[r] - target),
    )


def generate_images(
    prompt: str,
    resolution: str = "LinkedIn post",
    count: int = 1,
) -> list[dict]:
    """Generate images using Imagen 4 Fast via Vertex AI.

    Args:
        prompt: The image generation prompt.
        resolution: Platform resolution key (e.g. "LinkedIn post").
        count: Number of images to generate (1-4).

    Returns:
        List of dicts, each with "image_bytes" (raw bytes) and "image_b64"
        (base64-encoded string for ADK artifact display).

    Raises:
        Exception on API errors (safety rejection, quota, etc.).
    """
    width, height = RESOLUTION_TABLE.get(resolution, DEFAULT_RESOLUTION)
    aspect_ratio = _closest_aspect_ratio(width, height)

    client = _get_client()
    response = client.models.generate_images(
        model=GENERATE_MODEL_ID,
        prompt=prompt,
        config=types.GenerateImagesConfig(
            number_of_images=count,
            aspect_ratio=aspect_ratio,
            output_mime_type="image/jpeg",
            safety_filter_level="BLOCK_MEDIUM_AND_ABOVE",
            person_generation="ALLOW_ADULT",
        ),
    )

    results = []
    for generated_image in response.generated_images:
        img_bytes = generated_image.image.image_bytes
        results.append({
            "image_bytes": img_bytes,
            "image_b64": base64.b64encode(img_bytes).decode("utf-8"),
        })

    logger.info(
        "Generated %d images with %s, resolution=%s, aspect_ratio=%s",
        len(results), GENERATE_MODEL_ID, resolution, aspect_ratio,
    )
    return results


def upscale_image(
    source_bytes: bytes,
    target_size: str = "2K",
) -> bytes:
    """Upscale an image using Gemini 3 Pro Image via Vertex AI.

    Args:
        source_bytes: Raw bytes of the source image.
        target_size: Target resolution, "2K" or "4K".

    Returns:
        Upscaled image bytes (JPEG).

    Raises:
        ValueError if the response contains no image.
        Exception on API errors.
    """
    target_width, target_height = UPSCALE_TARGETS.get(target_size, UPSCALE_TARGETS["2K"])

    client = _get_client()
    source_image = types.Part.from_bytes(data=source_bytes, mime_type="image/jpeg")

    response = client.models.generate_content(
        model=UPSCALE_MODEL_ID,
        contents=[
            source_image,
            f"Upscale this image to {target_width}x{target_height} resolution. "
            "Preserve all details, colors, and composition exactly. "
            "Enhance clarity and sharpness without altering the content.",
        ],
        config=types.GenerateContentConfig(
            response_modalities=["IMAGE", "TEXT"],
        ),
    )

    for part in response.candidates[0].content.parts:
        if part.inline_data and part.inline_data.mime_type.startswith("image/"):
            logger.info("Upscaled image to %s using %s", target_size, UPSCALE_MODEL_ID)
            return part.inline_data.data

    raise ValueError("Upscale response did not contain an image")

