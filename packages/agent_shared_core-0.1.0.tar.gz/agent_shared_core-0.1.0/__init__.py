# agent_shared_core: shared Python library for the Compass Agent Framework.
# Not an ADK agent (no root_agent). Provides core infra and domain logic.

