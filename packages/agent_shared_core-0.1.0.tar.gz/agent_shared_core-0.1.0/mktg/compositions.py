"""Composition queries for Firestore /themes/{theme_id}/compositions/ subcollection.

Pure domain queries. No role enforcement (that's the agent tool's job).

Usage:
    from agent_shared_core.mktg.compositions import list_compositions, get_composition

    comps = list_compositions("theme_id")
    comp = get_composition("theme_id", "comp_id")
"""

import logging
from typing import List, Optional

logger = logging.getLogger(__name__)

PARENT_COLLECTION = "themes"
SUBCOLLECTION = "compositions"


def list_compositions(theme_id: str) -> List[dict]:
    """List all compositions for a given theme.

    Args:
        theme_id: The parent theme's document ID.

    Returns:
        List of composition dicts, each including an 'id' field.
    """
    from agent_shared_core.core.firestore import get_client

    comps = []
    sub_ref = (
        get_client()
        .collection(PARENT_COLLECTION)
        .document(theme_id)
        .collection(SUBCOLLECTION)
    )
    for doc in sub_ref.stream():
        comp = doc.to_dict()
        comp["id"] = doc.id
        comps.append(comp)
    return comps


def get_composition(theme_id: str, comp_id: str) -> Optional[dict]:
    """Get a single composition by theme ID and composition ID.

    Returns composition dict with 'id' field, or None if not found.
    """
    from agent_shared_core.core.firestore import get_client

    doc = (
        get_client()
        .collection(PARENT_COLLECTION)
        .document(theme_id)
        .collection(SUBCOLLECTION)
        .document(comp_id)
        .get()
    )
    if not doc.exists:
        return None
    comp = doc.to_dict()
    comp["id"] = doc.id
    return comp

