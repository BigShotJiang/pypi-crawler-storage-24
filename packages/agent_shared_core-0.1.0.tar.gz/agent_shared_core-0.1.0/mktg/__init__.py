# agent_shared_core.mktg: marketing domain (brands, themes, compositions, platform_specs)

