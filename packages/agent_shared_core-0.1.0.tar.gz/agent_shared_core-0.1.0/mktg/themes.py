"""Theme CRUD queries for Firestore /themes/ collection.

Pure domain queries. No role enforcement (that's the agent tool's job).
Themes use a three-layer schema: DNA, controls_schema, color_injection.
save_theme auto-increments version and writes to /versions/ subcollection.

Usage:
    from agent_shared_core.mktg.themes import list_themes, get_theme, save_theme, update_theme_status

    themes = list_themes(status="live")
    theme = get_theme("theme_id")
    new_id = save_theme({"name": "Glass Panels", "dna": {...}, ...})
    update_theme_status("theme_id", "retired")
"""

import logging
from datetime import datetime, timezone
from typing import List, Optional

from google.cloud.firestore_v1.base_query import FieldFilter

logger = logging.getLogger(__name__)

COLLECTION = "themes"


def list_themes(status: Optional[str] = None) -> List[dict]:
    """List themes with optional status filter.

    Args:
        status: Filter by theme status (draft, review, live, retired).

    Returns:
        List of theme dicts, each including an 'id' field.
    """
    from agent_shared_core.core.firestore import get_client

    query = get_client().collection(COLLECTION)

    if status:
        query = query.where(filter=FieldFilter("status", "==", status))

    themes = []
    for doc in query.stream():
        theme = doc.to_dict()
        theme["id"] = doc.id
        themes.append(theme)
    return themes


def get_theme(theme_id: str) -> Optional[dict]:
    """Get a single theme by ID.

    Returns theme dict with 'id' field, or None if not found.
    """
    from agent_shared_core.core.firestore import get_client

    doc = get_client().collection(COLLECTION).document(theme_id).get()
    if not doc.exists:
        return None
    theme = doc.to_dict()
    theme["id"] = doc.id
    return theme


def save_theme(data: dict) -> str:
    """Save a new theme to Firestore.

    Validates three-layer schema (dna required), auto-sets version to 1,
    and writes a snapshot to the /versions/ subcollection.

    Args:
        data: Theme data dict with required dna, controls_schema, color_injection.

    Returns:
        The new theme's document ID.

    Raises:
        ValueError: If required dna field is missing.
    """
    from agent_shared_core.core.firestore import get_client

    # Validate three-layer schema
    if "dna" not in data:
        raise ValueError("Theme must include 'dna' (three-layer schema required)")

    now = datetime.now(timezone.utc).isoformat()
    data["created_at"] = data.get("created_at", now)
    data["updated_at"] = now
    data["version"] = 1

    # Default optional fields
    data.setdefault("controls_schema", {})
    data.setdefault("color_injection", {})
    data.setdefault("mood", [])
    data.setdefault("best_for", [])
    data.setdefault("style_era", "")
    data.setdefault("status", "draft")
    data.setdefault("approved_by", None)
    data.setdefault("approved_at", None)
    data.setdefault("updated_by", data.get("created_by", ""))

    db = get_client()
    _, doc_ref = db.collection(COLLECTION).add(data)

    # Write version snapshot to subcollection
    db.collection(COLLECTION).document(doc_ref.id).collection("versions").add({
        **data,
        "version": 1,
    })

    logger.info("Theme created: %s (%s) v1", data.get("name"), doc_ref.id)
    return doc_ref.id


def update_theme_status(
    theme_id: str,
    status: str,
    approved_by: Optional[str] = None,
    updated_by: Optional[str] = None,
) -> None:
    """Update a theme's status.

    Args:
        theme_id: The theme document ID.
        status: New status (draft, review, live, retired).
        approved_by: Email of approver (set when moving to live).
        updated_by: Email of user making the update.

    Raises:
        ValueError: If the theme does not exist.
    """
    from agent_shared_core.core.firestore import get_client

    doc_ref = get_client().collection(COLLECTION).document(theme_id)
    doc = doc_ref.get()
    if not doc.exists:
        raise ValueError(f"Theme '{theme_id}' not found")

    now = datetime.now(timezone.utc).isoformat()
    update_data = {
        "status": status,
        "updated_at": now,
    }

    if updated_by:
        update_data["updated_by"] = updated_by

    if approved_by:
        update_data["approved_by"] = approved_by
        update_data["approved_at"] = now

    doc_ref.update(update_data)
    logger.info("Theme %s status updated to %s", theme_id, status)

