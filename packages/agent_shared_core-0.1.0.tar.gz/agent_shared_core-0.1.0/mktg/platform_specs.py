"""Platform spec lookup with Firestore cache and google-genai search grounding.

Checks Firestore /platform_specs/ first. On cache miss or stale data, uses
google-genai with search grounding to fetch current specs from official sources.
Grounding results are cached in Firestore for future lookups.

Usage:
    from agent_shared_core.mktg.platform_specs import lookup_platform_specs

    spec = lookup_platform_specs("LinkedIn", "post")
    # {"platform": "LinkedIn", "type": "post", "width": 1200, "height": 628, ...}
"""

import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from google.cloud.firestore_v1.base_query import FieldFilter

logger = logging.getLogger(__name__)

COLLECTION = "platform_specs"


def _get_cache_ttl_days() -> int:
    """Read platform cache TTL from agent config, default 90 days."""
    from agent_shared_core.core.config import get_config

    config = get_config("mktg_banner_generator")
    return config.get("platform_cache_ttl_days", 90)


def _is_stale(last_verified: str, ttl_days: int) -> bool:
    """Check if a cached spec is stale based on last_verified and TTL."""
    try:
        verified_dt = datetime.fromisoformat(last_verified)
        if verified_dt.tzinfo is None:
            verified_dt = verified_dt.replace(tzinfo=timezone.utc)
        cutoff = datetime.now(timezone.utc) - timedelta(days=ttl_days)
        return verified_dt < cutoff
    except (ValueError, TypeError):
        return True


def _search_grounding(platform: str, spec_type: str) -> Optional[dict]:
    """Use google-genai with search grounding to look up platform specs.

    Queries for current image dimensions, aspect ratio, and source URL
    for the given platform and content type.
    """
    from google import genai
    from google.genai import types

    client = genai.Client()

    prompt = (
        f"What are the current recommended image dimensions for a {platform} {spec_type}? "
        f"Provide: width (px), height (px), aspect ratio. "
        f"Return ONLY valid JSON with keys: platform, type, width, height, aspect_ratio, source_url. "
        f"No markdown, no explanation."
    )

    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=prompt,
        config=types.GenerateContentConfig(
            tools=[types.Tool(google_search=types.GoogleSearch())],
            temperature=0.1,
        ),
    )

    text = response.text.strip()
    # Strip markdown code fences if present
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(lines[1:-1])

    spec = json.loads(text)
    spec["platform"] = platform
    spec["type"] = spec_type
    return spec


def _cache_spec(spec: dict) -> None:
    """Write a platform spec to Firestore cache."""
    from agent_shared_core.core.firestore import get_client

    now = datetime.now(timezone.utc).isoformat()
    spec["last_verified"] = now
    spec["verified_by"] = "web_search"

    doc_id = f"{spec['platform'].lower()}_{spec['type'].lower()}"
    get_client().collection(COLLECTION).document(doc_id).set(spec, merge=True)
    logger.info("Cached platform spec: %s %s", spec["platform"], spec["type"])


def lookup_platform_specs(platform: str, spec_type: str) -> Optional[dict]:
    """Look up platform specs with Firestore cache and search grounding fallback.

    1. Check Firestore cache for fresh data.
    2. On cache miss or stale data, use search grounding.
    3. On grounding failure with stale cache, return stale data with warning.
    4. On total failure (no cache, no grounding), return None.

    Args:
        platform: Platform name (e.g., "LinkedIn", "Twitter").
        spec_type: Content type (e.g., "post", "banner", "story").

    Returns:
        Platform spec dict or None.
    """
    from agent_shared_core.core.firestore import get_client

    ttl_days = _get_cache_ttl_days()

    # Check Firestore cache
    cached_spec = None
    query = (
        get_client()
        .collection(COLLECTION)
        .where(filter=FieldFilter("platform", "==", platform))
        .where(filter=FieldFilter("type", "==", spec_type))
        .limit(1)
    )

    for doc in query.stream():
        cached_spec = doc.to_dict()
        cached_spec["id"] = doc.id

    # Fresh cache hit
    if cached_spec and not _is_stale(cached_spec.get("last_verified", ""), ttl_days):
        return cached_spec

    # Cache miss or stale: try search grounding
    try:
        grounded_spec = _search_grounding(platform, spec_type)
        if grounded_spec:
            _cache_spec(grounded_spec)
            return grounded_spec
    except Exception:
        logger.warning(
            "Search grounding failed for %s %s", platform, spec_type,
            exc_info=True,
        )

    # Grounding failed but we have stale cache
    if cached_spec:
        cached_spec["_warning"] = (
            f"Stale data (last verified: {cached_spec.get('last_verified', 'unknown')}). "
            "Search grounding failed. Verify dimensions before use."
        )
        return cached_spec

    # Total failure
    logger.error("No platform spec available for %s %s", platform, spec_type)
    return None

