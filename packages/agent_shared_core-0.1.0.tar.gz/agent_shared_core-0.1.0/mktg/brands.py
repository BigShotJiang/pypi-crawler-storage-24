"""Brand CRUD queries for Firestore /brands/ collection.

Pure domain queries. No role enforcement (that's the agent tool's job).

Usage:
    from agent_shared_core.mktg.brands import list_brands, get_brand, save_brand, update_brand_status

    brands = list_brands(type="vertical", status="active")
    brand = get_brand("brand_id")
    new_id = save_brand({"name": "AI", "type": "vertical", ...})
    update_brand_status("brand_id", "archived")
"""

import logging
from datetime import datetime, timezone
from typing import List, Optional

from google.cloud.firestore_v1.base_query import FieldFilter

logger = logging.getLogger(__name__)

COLLECTION = "brands"


def list_brands(
    type: Optional[str] = None,
    status: Optional[str] = None,
) -> List[dict]:
    """List brands with optional filters.

    Args:
        type: Filter by brand type (company, vertical, app).
        status: Filter by status (active, archived).

    Returns:
        List of brand dicts, each including an 'id' field.
    """
    from agent_shared_core.core.firestore import get_client

    query = get_client().collection(COLLECTION)

    if type:
        query = query.where(filter=FieldFilter("type", "==", type))
    if status:
        query = query.where(filter=FieldFilter("status", "==", status))

    brands = []
    for doc in query.stream():
        brand = doc.to_dict()
        brand["id"] = doc.id
        brands.append(brand)
    return brands


def get_brand(brand_id: str) -> Optional[dict]:
    """Get a single brand by ID.

    Returns brand dict with 'id' field, or None if not found.
    """
    from agent_shared_core.core.firestore import get_client

    doc = get_client().collection(COLLECTION).document(brand_id).get()
    if not doc.exists:
        return None
    brand = doc.to_dict()
    brand["id"] = doc.id
    return brand


def save_brand(data: dict) -> str:
    """Save a new brand to Firestore.

    Auto-sets created_at and updated_at timestamps.

    Args:
        data: Brand data dict (name, type, vertical, colors, status, created_by, etc.)

    Returns:
        The new brand's document ID.
    """
    from agent_shared_core.core.firestore import get_client

    now = datetime.now(timezone.utc).isoformat()
    data["created_at"] = data.get("created_at", now)
    data["updated_at"] = now

    # Default optional fields
    data.setdefault("locked_themes", [])
    data.setdefault("app", None)
    data.setdefault("vertical", None)

    _, doc_ref = get_client().collection(COLLECTION).add(data)
    logger.info("Brand created: %s (%s)", data.get("name"), doc_ref.id)
    return doc_ref.id


def update_brand_status(brand_id: str, status: str) -> None:
    """Update a brand's status.

    Args:
        brand_id: The brand document ID.
        status: New status (active, archived).

    Raises:
        ValueError: If the brand does not exist.
    """
    from agent_shared_core.core.firestore import get_client

    doc_ref = get_client().collection(COLLECTION).document(brand_id)
    doc = doc_ref.get()
    if not doc.exists:
        raise ValueError(f"Brand '{brand_id}' not found")

    doc_ref.update({
        "status": status,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    logger.info("Brand %s status updated to %s", brand_id, status)

