"""Exceptions for Flowire SDK.

These exceptions are part of the SDK contract and may be used by both
node packages and the workflow executor.
"""


class FlowFailureError(Exception):
    """Raised by nodes to intentionally fail a workflow execution.

    Unlike regular exceptions (which result in a node-level error with the
    execution still marked as "completed"), this exception signals that the
    entire workflow should be marked as "failed".

    Used by the Throw Error node. The workflow executor catches this and
    sets execution status to "failed" with the provided message.
    """

    pass
