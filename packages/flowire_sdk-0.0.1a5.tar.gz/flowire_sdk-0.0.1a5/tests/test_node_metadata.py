"""Tests for NodeMetadata extensions."""

from flowire_sdk import CodeEditorContract, NodeMetadata


def test_node_metadata_code_editor_contract():
    metadata = NodeMetadata(
        name="Code",
        description="Execute custom code",
        display_component="code",
        code_editor=CodeEditorContract(
            code_field="code",
            language_field="language",
            runtime_field="runtime",
            code_format="code",
            language_defaults={"python": "result = {}"},
            language_options=["python", "javascript"],
            runtime_options={"python": ["latest", "3.13"]},
        ),
    )

    payload = metadata.model_dump()
    contract = payload["code_editor"]

    assert contract["code_field"] == "code"
    assert contract["language_field"] == "language"
    assert contract["runtime_field"] == "runtime"
    assert contract["code_format"] == "code"
    assert contract["language_defaults"]["python"] == "result = {}"
    assert contract["language_options"] == ["python", "javascript"]
    assert contract["runtime_options"]["python"] == ["latest", "3.13"]
