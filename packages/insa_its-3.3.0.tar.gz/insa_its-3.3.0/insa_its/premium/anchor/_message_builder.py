"""
InsAIts Anchor Message Builder
================================
Loads templates from disk, varies whitespace/key ordering on each emission,
and builds layer-specific injection blocks that look like environment state.

Public facade: delegates to premium implementation when available,
otherwise provides stubs that return empty messages.

Author: Cristi Bogdan -- Steddy Nova SRL / YuyAI
"""

from __future__ import annotations

import logging
from typing import Any, List, Optional

logger = logging.getLogger("insaits.anchor.builder")


# ------------------------------------------------------------------
# Lazy premium resolution — avoids circular import at module load
# ------------------------------------------------------------------
_resolved = False
_premium_cls = None


def _resolve_premium() -> None:
    """Attempt to import the premium builder exactly once."""
    global _resolved, _premium_cls
    if _resolved:
        return
    _resolved = True
    try:
        from insa_its.premium._anchor_builder import (
            AnchorMessageBuilder as _cls,
        )
        _premium_cls = _cls
        logger.debug("Anchor message builder: premium implementation loaded")
    except ImportError:
        logger.debug("Anchor message builder: using open-source stub")


# ------------------------------------------------------------------
# Stub fallback — returns empty strings for all build methods
# ------------------------------------------------------------------
class _StubAnchorMessageBuilder:
    """No-op anchor message builder for open-source distribution.

    Accepts the same constructor signature and method calls as the
    premium builder but always returns empty strings. This keeps all
    downstream code functional without branching.
    """

    def __init__(
        self,
        claude_md_path: Optional[str] = None,
        templates_dir: Optional[str] = None,
    ) -> None:
        self._emission_count: int = 0

    def build_layer1(self) -> str:
        """Returns empty string — no injection in open-source mode."""
        return ""

    def build_layer2(self) -> str:
        """Returns empty string — no injection in open-source mode."""
        return ""

    def build_layer3(self) -> str:
        """Returns empty string — no injection in open-source mode."""
        return ""

    def build_for_layers(self, layers: List[int]) -> str:
        """Returns empty string — no injection in open-source mode."""
        return ""

    def content_hash(self, content: str) -> str:
        """Generate a short hash of content for audit logging."""
        import hashlib
        return hashlib.md5(content.encode()).hexdigest()[:8]


# ------------------------------------------------------------------
# Factory facade that returns premium or stub instance
# ------------------------------------------------------------------
class AnchorMessageBuilder:
    """Facade that delegates to premium or stub at instantiation time.

    Uses __new__ to return the correct class instance, resolving
    the premium import lazily to avoid circular imports.
    """

    def __new__(cls, **kwargs: Any) -> Any:
        _resolve_premium()
        if _premium_cls is not None:
            return _premium_cls(**kwargs)
        return _StubAnchorMessageBuilder(**kwargs)
