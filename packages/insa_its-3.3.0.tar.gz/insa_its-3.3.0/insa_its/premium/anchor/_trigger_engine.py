"""
InsAIts Anchor Trigger Engine
==============================
Determines WHEN to inject anchor messages based on session state,
tool call patterns, anomaly thresholds, and randomized cadences.

Three layers:
  Layer 1 (Opus/orchestrator) — periodic + anomaly + session start + critical
  Layer 2 (Agents)            — agent spawn + anomaly threshold
  Layer 3 (Subagents)         — subagent spawn only

Public facade: delegates to premium implementation when available,
otherwise provides no-op stubs that return empty trigger lists.

Author: Cristi Bogdan -- Steddy Nova SRL / YuyAI
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from insa_its.anchor._types import TriggerType  # noqa: F401 — re-exported

logger = logging.getLogger("insaits.anchor.trigger")


# ------------------------------------------------------------------
# Lazy premium resolution — avoids circular import at module load
# ------------------------------------------------------------------
_resolved = False
_premium_cls = None


def _resolve_premium() -> None:
    """Attempt to import the premium engine exactly once."""
    global _resolved, _premium_cls
    if _resolved:
        return
    _resolved = True
    try:
        from insa_its.premium._anchor_trigger import (
            AnchorTriggerEngine as _cls,
        )
        _premium_cls = _cls
        logger.debug("Anchor trigger engine: premium implementation loaded")
    except ImportError:
        logger.debug("Anchor trigger engine: using open-source stub")


# ------------------------------------------------------------------
# Stub fallback — no-op engine that returns empty trigger lists
# ------------------------------------------------------------------
class _StubAnchorTriggerEngine:
    """No-op anchor trigger engine for open-source distribution.

    Accepts the same constructor signature and method calls as the
    premium engine but never produces triggers. This keeps all
    downstream code functional without branching.
    """

    def __init__(self, **kwargs: Any) -> None:
        self._tool_call_count: int = 0
        self._injection_history: List[Dict[str, Any]] = []

    def evaluate(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        anomaly_count: int = 0,
        is_subagent: bool = False,
        agent_id: str = "",
        stealth: bool = False,
        has_critical: bool = False,
    ) -> List[Dict[str, Any]]:
        """Always returns an empty trigger list."""
        self._tool_call_count += 1
        return []

    def schedule_delayed(
        self, layers: List[int], trigger: TriggerType, delay: float
    ) -> None:
        """No-op — nothing to schedule."""
        pass

    @property
    def tool_call_count(self) -> int:
        return self._tool_call_count

    @property
    def next_opus_refresh_at(self) -> int:
        return 0

    @property
    def injection_history(self) -> List[Dict[str, Any]]:
        return list(self._injection_history)

    def get_state(self) -> Dict[str, Any]:
        """Return minimal state dict for dashboard compatibility."""
        return {
            "tool_call_count": self._tool_call_count,
            "subagent_call_count": 0,
            "next_opus_refresh_at": 0,
            "next_subagent_refresh_at": 0,
            "last_anomaly_count": 0,
            "pending_injections": 0,
            "injection_count": 0,
            "seen_agents": 0,
        }


# ------------------------------------------------------------------
# Factory function that returns premium or stub instance
# ------------------------------------------------------------------
class AnchorTriggerEngine:
    """Facade that delegates to premium or stub at instantiation time.

    Uses __new__ to return the correct class instance, resolving
    the premium import lazily to avoid circular imports.
    """

    def __new__(cls, **kwargs: Any) -> Any:
        _resolve_premium()
        if _premium_cls is not None:
            return _premium_cls(**kwargs)
        return _StubAnchorTriggerEngine(**kwargs)
