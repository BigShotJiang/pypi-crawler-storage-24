# Copyright (c) 2024-2026 YuyAI / InsAIts Team. All rights reserved.
# Proprietary and confidential. See LICENSE.premium for terms.
"""
InsAIts SDK - Detector Tuning Configuration (Premium)
======================================================
Proprietary tuning parameters, thresholds, and false-positive
suppression values for all detectors.

This file is included in the paid PyPI package (pip install insa-its)
and excluded from the open-source GitHub repository via .gitignore
on the premium/ directory.

Public detectors import from here via:
    try:
        from insa_its.premium._detector_config import <CONFIG>
    except ImportError:
        <CONFIG> = <CONSERVATIVE_DEFAULT>

Conservative defaults (in public code) are intentionally set to
produce fewer detections (higher thresholds) -- zero false positives
but more false negatives. Premium tuning restores full sensitivity.
"""

# =============================================================================
# Behavioral Fingerprint Detector
# =============================================================================
BEHAVIORAL_FINGERPRINT_CONFIG = {
    # Minimum messages before fingerprint is considered stable
    "warmup_window": 10,
    # Number of recent messages to compare against baseline
    "comparison_window": 5,
    # Z-score thresholds for individual feature checks
    "length_z_threshold": 3.0,
    "formality_z_threshold": 3.0,
    "sentence_length_z_threshold": 3.0,
    # Vocabulary Jaccard similarity below this triggers a flag
    "vocabulary_jaccard_threshold": 0.15,
    # Minimum std floors to prevent over-sensitivity on low-variance baselines
    "length_std_floor": 10.0,
    "formality_std_floor": 0.1,
    "sentence_length_std_floor": 2.0,
    # Confidence calculation: confidence = min(1.0, num_flags * multiplier)
    "confidence_multiplier": 0.3,
    # Severity classification
    "critical_flags": ["new_capability_detected", "snapshot_divergence"],
    "high_flags": ["vocabulary_shift", "formality_shift"],
    # Multi-flag severity threshold: >= this many flags = high severity
    "multi_flag_high_threshold": 2,
}

# =============================================================================
# Credential Pattern Detector
# =============================================================================
CREDENTIAL_PATTERN_CONFIG = {
    # Confidence calculation: confidence = min(1.0, num_findings * multiplier)
    "confidence_multiplier": 0.4,
    # Allowlist patterns -- matched values that look like credentials but are not
    # (documentation examples, placeholders, masked values)
    "allowlist_patterns": [
        r"sk-[a-z]+-example",   # Documentation examples
        r"YOUR_API_KEY",
        r"xxx+",
        r"\.{3,}",              # Placeholder dots
        r"\*{3,}",              # Masked values
        r"<[A-Z_]+>",          # Template placeholders
    ],
}

# =============================================================================
# Hallucination Chain Detector
# =============================================================================
HALLUCINATION_CHAIN_CONFIG = {
    # Default lookback window (prior messages to check for promoted claims)
    "default_lookback": 3,
    # Minimum keyword overlap to consider two claims related
    "min_keyword_overlap": 2,
    # Minimum keyword length to consider significant
    "min_keyword_length": 5,
    # Minimum sentence length to analyze
    "min_sentence_length": 10,
}

# =============================================================================
# Information Flow Tracker
# =============================================================================
INFORMATION_FLOW_CONFIG = {
    # Confidence calculation: confidence = min(1.0, num_violations * multiplier)
    "confidence_multiplier": 0.35,
    # Minimum entity value length to track
    "min_entity_length": 3,
}

# =============================================================================
# Jargon Drift Detector
# =============================================================================
JARGON_DRIFT_CONFIG = {
    # Default OOV threshold fraction (flag if this % of tokens are new)
    "default_oov_threshold": 0.3,
    # Grace period: don't flag acronyms until this many messages
    "grace_period_acronyms": 2,
    # Grace period: don't flag novel terms until this many messages
    "grace_period_novel": 3,
    # Minimum times a novel term must appear in a single message to be flagged
    "min_novel_term_frequency": 2,
    # Maximum novel terms to report (prevents noise)
    "max_novel_terms_reported": 10,
    # Minimum token length to track in vocabulary
    "min_token_length": 4,
}

# =============================================================================
# Query-Intent Divergence Detector
# =============================================================================
QUERY_INTENT_CONFIG = {
    # Default cosine similarity threshold (below triggers a flag)
    "default_similarity_threshold": 0.65,
    # Minimum entity word length
    "min_entity_length": 3,
}

# =============================================================================
# Semantic Drift Detector
# =============================================================================
SEMANTIC_DRIFT_CONFIG = {
    # Default sensitivity (std deviation multiplier for threshold)
    "default_sensitivity": 2.0,
    # Default minimum messages before detection activates
    "default_min_window": 3,
    # EWMA smoothing factor (higher = more weight on recent observations)
    "ewma_alpha": 0.3,
}

# =============================================================================
# Tool Call Frequency Anomaly Detector
# =============================================================================
TOOL_CALL_FREQUENCY_CONFIG = {
    # Minimum calls before baseline is stable
    "warmup_calls": 8,
    # Time window (seconds) for burst detection
    "burst_window_sec": 60,
    # Max calls in burst window before flagging
    "burst_threshold": 10,
    # Tool concentration ratio: if one tool > this fraction of all calls, flag
    "tool_concentration_ratio": 0.8,
    # Minimum total calls before concentration check applies
    "concentration_min_calls_multiplier": 2,
    # Confidence calculation
    "confidence_multiplier": 0.35,
}

# =============================================================================
# Tool Description Divergence Detector
# =============================================================================
TOOL_DESCRIPTION_DIVERGENCE_CONFIG = {
    # Minimum keyword matches to classify output into a category
    "category_min_keyword_matches": 2,
    # Minimum behavior history entries before shift detection
    "behavior_shift_min_history": 4,
    # Semantic divergence threshold (cosine similarity below this = divergent)
    "semantic_divergence_threshold": 0.3,
    # Confidence calculation
    "confidence_multiplier": 0.35,
}

# =============================================================================
# Uncertainty Propagation Detector
# =============================================================================
UNCERTAINTY_PROPAGATION_CONFIG = {
    # Default lookback window (prior messages to check for uncertainty context)
    "default_lookback": 5,
    # Minimum topic keyword overlap to consider messages about the same topic
    "min_topic_overlap": 2,
    # Minimum keyword length for topic matching
    "min_keyword_length": 4,
    # Minimum sentence length for internal contradiction detection
    "min_sentence_length_contradiction": 20,
}
