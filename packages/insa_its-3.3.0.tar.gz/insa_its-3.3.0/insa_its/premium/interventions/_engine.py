"""
InsAIts SDK - Intervention Engine
==================================
Active response system that takes action on detected anomalies
based on severity level and user-configurable callbacks.

This is a facade: full implementation lives in premium/_intervention_engine.py.
Open-source stub returns no interventions (all messages delivered).

Intervention hierarchy (premium):
    CRITICAL -> quarantine + escalate to human (HITL)
    HIGH     -> reroute to backup agent or deliver with warning
    MEDIUM   -> deliver + log warning
    LOW/INFO -> deliver + log
"""

import logging
from typing import Any, Callable, Dict, List, Optional  # noqa: F401

logger = logging.getLogger(__name__)


# Type alias for HITL callback (always available, not premium-gated)
# Signature: callback(message: Dict, result: MonitorResult, context: Dict) -> bool
# Returns True to allow message, False to quarantine
HITLCallback = Callable[[Dict, "MonitorResult", Dict], bool]


try:
    from insa_its.premium._intervention_engine import (  # noqa: F401
        InterventionEngine,
    )
except ImportError:

    class InterventionEngine:  # type: ignore[no-redef]
        """Open-source stub: delivers all messages without intervention.

        Same interface as the premium InterventionEngine but performs
        no quarantine, rerouting, or HITL escalation.
        """

        def __init__(self) -> None:
            self._hitl_callback: Optional[Callable] = None
            self._reroute_map: Dict[str, str] = {}
            self._custom_handlers: Dict[str, Callable] = {}

        def register_hitl_callback(self, callback: Callable) -> None:
            """Stub: stores callback but never invokes it."""
            self._hitl_callback = callback
            logger.info("HITL callback registered (open-source stub)")

        def register_reroute(self, from_agent: str, to_agent: str) -> None:
            """Stub: stores reroute but never applies it."""
            self._reroute_map[from_agent] = to_agent
            logger.info(
                "Reroute registered (open-source stub): %s -> %s",
                from_agent, to_agent,
            )

        def register_handler(
            self, anomaly_type: str, handler: Callable,
        ) -> None:
            """Stub: stores handler but never invokes it."""
            self._custom_handlers[anomaly_type] = handler

        def handle(
            self,
            message: Dict[str, Any],
            result: Any,
            context: Optional[Dict[str, Any]] = None,
        ) -> Dict[str, Any]:
            """Stub: delivers all messages without intervention."""
            return {
                "action": "delivered",
                "modified": False,
                "severity": "info",
                "reason": "No interventions (open-source mode)",
            }


__all__ = [
    "HITLCallback",
    "InterventionEngine",
]
