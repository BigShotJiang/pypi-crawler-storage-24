"""
InsAIts Anchor Message Injection System
=========================================
Three-layer anchor injection targeting Opus (orchestrator),
Agents, and Subagents with randomized cadence and anti-pattern
variation.

Modules:
  trigger_engine  — decides WHEN to inject
  message_builder — decides WHAT to inject
  templates/      — message templates per layer
"""

from insa_its.anchor.trigger_engine import AnchorTriggerEngine, TriggerType
from insa_its.anchor.message_builder import AnchorMessageBuilder

__all__ = [
    "AnchorTriggerEngine",
    "AnchorMessageBuilder",
    "TriggerType",
]
