# InsAIts Learning Engine
# Pattern mining + adaptive thresholds for anomaly detection.
