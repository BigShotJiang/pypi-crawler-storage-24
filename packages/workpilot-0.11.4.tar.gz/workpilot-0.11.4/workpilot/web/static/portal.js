'use strict';
/* WorkPilot Portal Dashboard — extracted from portal.html */

// ── Helpers ───────────────────────────────────────────────────
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const el = (t, a, ...k) => {
  const e = document.createElement(t);
  if (a) for (const [p, v] of Object.entries(a)) {
    if (p === 'html') e.innerHTML = v;
    else if (p === 'text') e.textContent = v;
    else if (p.startsWith('on')) e.addEventListener(p.slice(2), v);
    else if (p === 'class') e.className = v;
    else if (p === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else e.setAttribute(p, v);
  }
  k.flat().forEach(c => { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
  return e;
};
const esc = s => { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; };
const md = s => DOMPurify.sanitize(marked.parse(s || ''));
const fmtK = n => n >= 1e6 ? (n / 1e6).toFixed(n % 1e6 === 0 ? 0 : 1) + 'M' : Math.round(n / 1000) + 'K';
const fmtUp = s => { if (!s && s !== 0) return '--'; const d = ~~(s / 86400), h = ~~(s % 86400 / 3600), m = ~~(s % 3600 / 60); return d > 0 ? d + 'd ' + h + 'h' : h > 0 ? h + 'h ' + m + 'm' : m + 'm ' + (s % 60) + 's'; };

marked.use({ breaks: true, gfm: true, highlight: (code, lang) => {
  if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) return hljs.highlight(code, { language: lang }).value;
  if (typeof hljs !== 'undefined') return hljs.highlightAuto(code).value;
  return code;
}});

// ── User / Theme ─────────────────────────────────────────────
function setUser(name) {
  const display = name || 'Local User';
  $('#unm').textContent = display;
  $('#uav').textContent = display.replace(/@.*/, '').slice(0, 2).toUpperCase();
}
setUser(CFG.upn);

function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  localStorage.setItem('workpilot_theme', t);
  const light = t === 'light';
  $('#ico-sun').style.display = light ? 'none' : 'block';
  $('#ico-moon').style.display = light ? 'block' : 'none';
  $('#theme-lbl').textContent = light ? 'Light' : 'Dark';
}
window.toggleTheme = () => applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
applyTheme(localStorage.getItem('workpilot_theme') || 'dark');
window.toggleSide = () => { $('#side').classList.toggle('open'); $('#ov').classList.toggle('show'); };

// ── Auth ─────────────────────────────────────────────────────
let apiKey = localStorage.getItem('workpilot_api_key') || '';
let entraToken = null, entraAccount = null, entraConfig = null;
let authRequired = false, msalApp = null, dcPoll = null;

const isAuthed = () => !!apiKey || !!entraToken;
const authHeaders = () => {
  const h = {};
  if (apiKey) h['X-API-Key'] = apiKey;
  else if (entraToken) h['Authorization'] = 'Bearer ' + entraToken;
  return h;
};

function updateAuthBtn() {
  $('#auth-role').textContent = isAuthed() ? 'Authenticated' : 'Sign in';
  $('#auth-btn').title = isAuthed() ? 'Click to manage authentication' : 'Click to sign in';
}
updateAuthBtn();

window.openAuth = () => { $('#ak-input').value = apiKey; $('#ak-msg').textContent = ''; $('#ak-msg').className = 'auth-msg'; $('#auth-modal').classList.add('show'); };
window.closeAuth = () => $('#auth-modal').classList.remove('show');

function onLoginSuccess() { updateAuthBtn(); closeAuth(); route(); }

$('#ak-save').addEventListener('click', async () => {
  const key = $('#ak-input').value.trim();
  apiKey = key;
  key ? localStorage.setItem('workpilot_api_key', key) : localStorage.removeItem('workpilot_api_key');
  updateAuthBtn();
  setUser(key ? 'API User' : '');
  const msg = $('#ak-msg');
  msg.textContent = 'Testing...'; msg.className = 'auth-msg';
  try {
    const r = await fetch(CFG.apiBase + '/tools', { headers: authHeaders() });
    if (r.ok) { msg.textContent = 'Authenticated'; msg.className = 'auth-msg ok'; setTimeout(onLoginSuccess, 600); }
    else if (r.status === 401) { msg.textContent = 'Invalid key'; msg.className = 'auth-msg err'; }
    else { msg.textContent = 'Saved'; msg.className = 'auth-msg'; setTimeout(onLoginSuccess, 600); }
  } catch { msg.textContent = 'Saved (offline)'; msg.className = 'auth-msg'; setTimeout(onLoginSuccess, 600); }
});
$('#ak-clear').addEventListener('click', () => { $('#ak-input').value = ''; apiKey = ''; localStorage.removeItem('workpilot_api_key'); updateAuthBtn(); $('#ak-msg').textContent = 'Cleared'; $('#ak-msg').className = 'auth-msg'; });
$('#ak-input').addEventListener('keydown', e => { if (e.key === 'Enter') $('#ak-save').click(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#auth-modal').classList.contains('show')) closeAuth(); });

// ── Entra ID (MSAL.js) ──────────────────────────────────────
async function initMsal(cfg) {
  if (typeof msal === 'undefined') return;
  msalApp = new msal.PublicClientApplication({
    auth: { clientId: cfg.entra_client_id, authority: `https://login.microsoftonline.com/${cfg.entra_tenant_id}`, redirectUri: location.origin + '/auth/spa-callback' },
    cache: { cacheLocation: 'localStorage' },
  });
  await msalApp.initialize();
  $('#msal-login').style.display = 'flex';
  const accounts = msalApp.getAllAccounts();
  if (accounts.length > 0) {
    entraAccount = accounts[0];
    try { onEntraAuth(await msalApp.acquireTokenSilent({ account: entraAccount, scopes: [`${cfg.entra_client_id}/access_as_user`] }), true); } catch {}
  }
}

function onEntraAuth(result, silent) {
  entraToken = result.accessToken;
  entraAccount = result.account;
  const name = result.account?.name || result.account?.username || 'Signed in';
  $('#entra-name').textContent = name;
  $('#entra-out').style.display = 'none';
  $('#entra-in').style.display = '';
  setUser(name);
  updateAuthBtn();
  if (!silent) onLoginSuccess();
}

$('#msal-login').addEventListener('click', async () => {
  if (!msalApp || !entraConfig) return;
  try { onEntraAuth(await msalApp.loginPopup({ scopes: [`${entraConfig.entra_client_id}/access_as_user`] })); }
  catch (err) { const msg = $('#ak-msg'); msg.textContent = err.errorMessage || 'Popup login failed'; msg.className = 'auth-msg err'; }
});

$('#dc-start').addEventListener('click', async function startDeviceCode() {
  const btn = $('#dc-start');
  btn.disabled = true; btn.style.opacity = '.6';
  try {
    const r = await fetch('/api/auth/device-code', { method: 'POST' });
    if (!r.ok) { btn.disabled = false; btn.style.opacity = ''; return; }
    const d = await r.json();
    $('#dc-code').textContent = d.user_code;
    $('#dc-link').href = d.verification_uri;
    $('#dc-status').textContent = 'Waiting for approval...';
    $('#dc-box').style.display = '';
    if (dcPoll) clearInterval(dcPoll);
    dcPoll = setInterval(async () => {
      try {
        const pd = await (await fetch('/api/auth/device-code/poll', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_code: d.user_code }) })).json();
        if (pd.status === 'complete') {
          clearInterval(dcPoll); dcPoll = null;
          entraToken = pd.access_token; entraAccount = pd.account;
          const name = pd.account?.name || pd.account?.username || 'Signed in';
          $('#entra-name').textContent = name; $('#entra-out').style.display = 'none'; $('#entra-in').style.display = '';
          setUser(name); updateAuthBtn();
          $('#ak-msg').textContent = 'Signed in'; $('#ak-msg').className = 'auth-msg ok';
          setTimeout(onLoginSuccess, 600);
        } else if (pd.status === 'error') { clearInterval(dcPoll); dcPoll = null; $('#dc-status').textContent = pd.message || 'Failed'; btn.disabled = false; btn.style.opacity = ''; }
      } catch {}
    }, 3000);
  } catch { btn.disabled = false; btn.style.opacity = ''; }
});

$('#entra-logout')?.addEventListener('click', () => {
  entraToken = null;
  if (dcPoll) { clearInterval(dcPoll); dcPoll = null; }
  $('#dc-box').style.display = 'none'; $('#dc-start').disabled = false; $('#dc-start').style.opacity = '';
  $('#entra-out').style.display = ''; $('#entra-in').style.display = 'none';
  if (msalApp && entraAccount) msalApp.logoutPopup({ account: entraAccount }).catch(() => {});
  entraAccount = null; updateAuthBtn();
});

// ── Data layer ───────────────────────────────────────────────
let isOffline = false, _authExpiring = false;

function onAuthExpired() {
  if (_authExpiring) return;
  _authExpiring = true;
  apiKey = ''; entraToken = null; localStorage.removeItem('workpilot_api_key');
  if (document.hasFocus() && msalApp && entraAccount) {
    msalApp.acquireTokenSilent({ account: entraAccount, scopes: [`${entraConfig.entra_client_id}/access_as_user`] })
      .then(r => { _authExpiring = false; onEntraAuth(r, false); })
      .catch(() => { _authExpiring = false; showAuthExpired(); });
    return;
  }
  _authExpiring = false; showAuthExpired();
}
function showAuthExpired() {
  entraAccount = null; updateAuthBtn(); setUser('');
  if (poll) { clearTimeout(poll); poll = null; }
  render(el('div', { class: 'empty', text: 'Session expired — please sign in again.' }));
  openAuth();
}
function onSessionExpired() { if (poll) { clearTimeout(poll); poll = null; } window.location.reload(); }

async function api(ep) {
  try {
    const r = await fetch(CFG.apiBase + ep, { headers: authHeaders() });
    if (r.status === 503) { setOffline(true); return null; }
    setOffline(false);
    if (r.status === 401) { (CFG.mode === 'cloud' ? onSessionExpired : onAuthExpired)(); return null; }
    return r.ok ? r.json() : null;
  } catch { setOffline(true); return null; }
}
async function apiPost(ep, body) {
  try {
    const r = await fetch(CFG.apiBase + ep, { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify(body || {}) });
    if (r.status === 503) { setOffline(true); return null; }
    setOffline(false);
    if (r.status === 401) { (CFG.mode === 'cloud' ? onSessionExpired : onAuthExpired)(); return null; }
    return r.ok ? r.json() : null;
  } catch { setOffline(true); return null; }
}
function setOffline(v) { isOffline = v; const b = $('#ofl'); if (b) b.classList.toggle('show', v && CFG.mode === 'cloud'); }

// ── Routing ──────────────────────────────────────────────────
let poll = null, routeVer = 0;
const pages = { '': pgDash, sessions: pgSess, tools: pgTools, skills: pgSkills, models: pgModels, cost: pgCost, memory: pgMem, security: pgSec, settings: pgSet };

/** Schedule next poll only if the route hasn't changed since this page started. */
function schedulePoll(fn, ms, ver) { if (ver === routeVer) poll = setTimeout(fn, ms); }

window.go = r => { location.hash = '/' + r; if (innerWidth < 768) { $('#side').classList.remove('open'); $('#ov').classList.remove('show'); } };

function route() {
  if (authRequired && !isAuthed()) { render(el('div', { class: 'empty', text: 'Please sign in to view the dashboard.' })); openAuth(); return; }
  if (poll) { clearTimeout(poll); poll = null; }
  routeVer++;
  const h = location.hash.replace('#/', '').split('/')[0] || '';
  $$('.nav-it').forEach(n => n.classList.toggle('on', (n.dataset.r ?? '') === h));
  (pages[h] || pgDash)();
}
addEventListener('hashchange', route);

function render(c) {
  const m = $('#main'), scrollY = m.scrollTop, frag = document.createDocumentFragment();
  if (CFG.mode === 'cloud') {
    frag.appendChild(el('div', { id: 'ofl', class: 'offline' + (isOffline ? ' show' : '') },
      'WorkPilot client is not connected. Run ', el('code', { text: 'workpilot s' }), ' on your machine (v0.8.0+). ',
      el('a', { href: '/#install', style: 'color:inherit;font-weight:600;text-decoration:underline', text: 'Install WorkPilot \u2192' })));
  }
  frag.appendChild(typeof c === 'string' ? el('div', { html: c }) : c);
  m.replaceChildren(frag);
  m.scrollTop = scrollY;
}

// ── Components ───────────────────────────────────────────────
const C = {
  page: (title, sub, ...extras) => el('div', { class: 'pg-hdr' }, el('div', null, el('div', { class: 'pg-title', text: title }), el('div', { class: 'pg-sub', text: sub })), el('div', { class: 'spacer' }), ...extras),
  card: (lbl, valHtml, det) => { const c = el('div', { class: 'card' }); c.appendChild(el('div', { class: 'card-lbl', text: lbl })); c.appendChild(el('div', { class: 'card-val', html: valHtml })); if (det) c.appendChild(el('div', { class: 'card-det', html: det })); return c; },
  grid: (...k) => el('div', { class: 'cards' }, ...k),
  grid2: (...k) => el('div', { class: 'dash-2col' }, ...k),
  panel: (title, ...k) => { const p = el('div', { class: 'panel' }); p.appendChild(el('div', { class: 'panel-t', text: title })); k.forEach(c => p.appendChild(c)); return p; },
  sec: (title, ...k) => { const s = el('div', { class: 'sec' }); s.appendChild(el('div', { class: 'sec-t', text: title })); k.forEach(c => s.appendChild(c)); return s; },
  table: (hdrs, rows, opts) => { const w = el('div', { class: 'tw' }), t = el('table'), tr = el('tr'); hdrs.forEach(h => tr.appendChild(el('th', { text: h }))); t.appendChild(el('thead', null, tr)); const tb = el('tbody'); rows.forEach(r => { const row = el('tr', opts?.click ? { class: 'clickr', onclick: () => opts.click(r._data) } : null); r.cells.forEach(c => row.appendChild(typeof c === 'string' || typeof c === 'number' ? el('td', { text: String(c) }) : el('td', null, c))); tb.appendChild(row); }); t.appendChild(tb); w.appendChild(t); return w; },
  badge: (text, cls) => el('span', { class: 'b ' + (cls || 'b-muted'), text }),
  mono: t => el('code', { text: t, class: 'mono' }),
  bar: (label, val, max, colorFn) => { const pct = Math.min(val / (max || 100) * 100, 100), color = colorFn ? colorFn(pct) : (pct > 80 ? 'var(--red)' : pct > 50 ? 'var(--amber)' : pct > 0 ? 'var(--blue)' : 'var(--fg2)'); return el('div', { class: 'bus-row' }, el('span', { class: 'bus-lbl', text: label }), el('div', { class: 'bus-track' }, el('div', { class: 'bus-fill', style: { width: Math.max(pct, 2) + '%', background: color } })), el('span', { class: 'bus-val', text: String(val) })); },
  flag: (label, val, warn) => { const r = el('div', { class: 'sec-row' }); r.appendChild(el('span', { class: 'sec-lbl', text: label })); if (typeof val === 'boolean') r.appendChild(el('span', { class: 'sec-val ' + (warn && val ? 'sec-warn' : val ? 'sec-on' : 'sec-off'), text: val ? 'Yes' : 'No' })); else r.appendChild(el('span', { class: 'sec-val', html: `<span class="b b-accent">${esc(String(val))}</span>` })); return r; },
  kv: pairs => { const g = el('div', { class: 'rt-grid' }); pairs.forEach(([k, v, mono]) => { g.appendChild(el('span', { class: 'rt-k', text: k })); g.appendChild(el('span', { class: 'rt-v' + (mono ? ' mono' : ''), text: v || '--' })); }); return g; },
  riskBar: (label, count, total, color) => el('div', { class: 'risk-row' }, el('span', { class: 'risk-lbl', style: { color }, text: label }), el('div', { class: 'risk-track' }, el('div', { class: 'risk-fill', style: { width: (count / (total || 1) * 100) + '%', background: color } })), el('span', { class: 'risk-ct', text: String(count) })),
  empty: msg => el('div', { class: 'empty', text: msg }),
};

// ── Pages ────────────────────────────────────────────────────

// Dashboard
async function pgDash() {
  const v = routeVer;
  const d = await api('/status');
  if (v !== routeVer) return;
  const f = el('div'), extras = [];
  if (d) { if (d.version) extras.push(el('span', { class: 'dash-ver', text: 'v' + d.version })); extras.push(el('span', { class: 'dash-meta', html: `<b>Up</b> ${fmtUp(d.uptime_seconds)}` })); extras.push(el('span', { class: 'dash-meta', text: new Date().toLocaleTimeString() })); }
  f.appendChild(C.page('Dashboard', 'Real-time agent overview', ...extras));
  if (!d) { f.appendChild(C.empty('No data available. Connect your WorkPilot client.')); render(f); schedulePoll(pgDash, CFG.pollFast, v); return; }

  const es = d.estop || {};
  if (es.halted) f.appendChild(el('div', { class: 'estop-bar' }, el('span', { class: 'beacon halt' }), el('b', { text: 'EMERGENCY STOP' }), el('span', { text: ' — ' + (es.reason || 'unknown') }), es.actor ? el('span', { class: 'dash-meta', text: ' by ' + es.actor }) : null, el('div', { class: 'spacer' }), el('button', { class: 'btn btn-ok btn-sm', text: 'Reset', onclick: async () => { await apiPost('/reset', { actor: 'admin' }); pgDash(); } })));

  const ok = d.status === 'ok', sc = d.scheduler || {};
  f.appendChild(C.grid(C.card('Status', `<span class="beacon ${ok ? 'ok' : 'halt'}"></span>${ok ? 'Operational' : 'HALTED'}`), C.card('Sessions', String(d.sessions?.count ?? 0)), C.card('Tools', String(d.tools?.count ?? 0)), C.card('Skills', d.skills ? `${d.skills.active}/${d.skills.count}` : '0'), C.card('Scheduler', sc.enabled ? `${sc.active_jobs}/${sc.job_count} jobs` : 'Disabled')));

  const chKids = (d.channels || []).map(c => el('div', { class: 'ch-row' }, el('span', { class: 'ch-dot ' + (c.connected ? 'on' : 'off') }), el('span', { class: 'ch-name', text: c.name }), c.url && /^https?:|^\//.test(c.url) ? el('a', { class: 'ch-link', href: c.url, target: '_blank', rel: 'noopener', text: 'open' }) : null));
  f.appendChild(C.grid2(C.panel('Channels', ...(chKids.length ? chKids : [el('div', { class: 'dash-meta', text: 'No channels active' })])), C.panel('Message Bus', C.bar('Inbound', d.bus?.inbound_qsize ?? 0, 100), C.bar('Outbound', d.bus?.outbound_qsize ?? 0, 100))));

  const sec = d.security || {}, rt = d.tools?.by_tier || {}, total = (rt.safe || 0) + (rt.moderate || 0) + (rt.elevated || 0) + (rt.high || 0) + (rt.critical || 0) + (rt.dynamic || 0) || 1;
  f.appendChild(C.grid2(C.panel('Security', C.flag('Profile', sec.profile || '--'), C.flag('E-stop', es.halted || false, true), C.flag('Auth Required', sec.require_auth || false), C.flag('Audit Logging', sec.audit_enabled || false), C.flag('Secret Redaction', sec.audit_redact || false), C.flag('E-stop on Leak', sec.estop_on_leak || false)), C.panel('Tools by Risk Tier', C.riskBar('safe (0-2)', rt.safe || 0, total, 'var(--fg2)'), C.riskBar('moderate (3-4)', rt.moderate || 0, total, 'var(--amber)'), C.riskBar('elevated (5-6)', rt.elevated || 0, total, '#f59e0b'), C.riskBar('high (7-8)', rt.high || 0, total, 'var(--red)'), C.riskBar('critical (9-10)', rt.critical || 0, total, '#dc2626'), C.riskBar('dynamic (LLM)', rt.dynamic || 0, total, '#6366f1'))));

  const qaRow = el('div', { class: 'qa-row' }, el('a', { class: 'qa-btn', href: '/chat', target: '_blank', text: 'Open Chat' }), el('a', { class: 'qa-btn', href: '/api/status', target: '_blank', text: 'Raw JSON' }), el('a', { class: 'qa-btn', href: '/api/health', target: '_blank', text: 'Health Check' }), !es.halted ? el('button', { class: 'qa-btn danger', text: 'E-Stop', onclick: async () => { const r = prompt('Reason:'); if (r) { await apiPost('/estop', { reason: r }); pgDash(); } } }) : el('button', { class: 'qa-btn', text: 'Reset E-Stop', onclick: async () => { await apiPost('/reset', { actor: 'admin' }); pgDash(); } }));
  f.appendChild(C.grid2(C.panel('Runtime', C.kv([['Agent', d.agent?.name || 'default'], ['Model', d.provider?.model || '--', 1], ['Max Iter', String(d.agent?.max_iterations ?? '--')], ['Workspace', d.workspace || '--', 1], d.started_at ? ['Started', new Date(d.started_at).toLocaleString()] : null].filter(Boolean))), C.panel('Quick Actions', qaRow)));
  render(f); schedulePoll(pgDash, CFG.pollFast, v);
}

// Sessions
async function pgSess() {
  const v = routeVer;
  const d = await api('/sessions');
  if (v !== routeVer) return;
  const f = el('div');
  f.appendChild(C.page('Sessions', 'Conversation history browser'));
  if (!d?.length) { f.appendChild(C.empty('No sessions found.')); render(f); schedulePoll(pgSess, CFG.pollSlow, v); return; }
  f.appendChild(C.table(['Session ID', 'Messages'], d.map(s => ({ _data: s.session_id, cells: [C.mono(s.session_id), String(s.message_count ?? '--')] })), { click: viewSess }));
  render(f); schedulePoll(pgSess, CFG.pollSlow, v);
}
async function viewSess(id) {
  if (poll) { clearTimeout(poll); poll = null; }
  const d = await api('/sessions/' + encodeURIComponent(id)), f = el('div');
  f.appendChild(el('div', { class: 'back', onclick: () => pgSess(), html: '&larr; Back to sessions' }));
  f.appendChild(C.page(id, ''));
  if (!d?.messages?.length) { f.appendChild(C.empty('No messages.')); render(f); return; }
  const list = el('div', { class: 'msgs' });
  d.messages.forEach(m => { const bub = el('div', { class: 'msg ' + (m.role || 'assistant') }); bub.appendChild(el('div', { class: 'msg-role', text: m.role || 'unknown' })); bub.appendChild(el('div', { html: md(m.content || '') })); list.appendChild(bub); });
  f.appendChild(list); render(f);
}

// Tools
function toolFilter(f, placeholder) {
  const search = el('input', { class: 'tool-search', placeholder, type: 'text' });
  search.addEventListener('input', () => {
    const q = search.value.toLowerCase();
    f.querySelectorAll('.card[data-search]').forEach(c => { c.style.display = c.dataset.search.includes(q) ? '' : 'none'; });
  });
  return search;
}

async function pgTools() {
  const v = routeVer;
  const STATUS_B = { active: 'b-green', inactive: 'b-muted', connected: 'b-green', idle: 'b-muted', connecting: 'b-amber', reconnecting: 'b-amber', failed: 'b-red' };
  const d = await api('/tools');
  if (v !== routeVer) return;
  const f = el('div');
  if (!d?.length) { f.appendChild(C.page('Tools', 'No tools registered')); f.appendChild(C.empty('No tools registered.')); render(f); return; }
  const mcp = d.filter(t => t.type === 'mcp_server').length;
  f.appendChild(C.page('Tools', `${d.length} tools` + (mcp ? ` · ${mcp} MCP servers` : '')));
  f.appendChild(el('div', { class: 'tool-filter' }, toolFilter(f, 'Filter tools...')));

  for (const [type, badge] of [['builtin', 'b-blue'], ['mcp_server', 'b-amber'], ['mcp_tool', 'b-amber']]) {
    const items = d.filter(t => t.type === type);
    if (!items.length) continue;
    const g = el('div', { class: 'tool-grp' });
    g.appendChild(el('div', { class: 'tool-grp-t' }, C.badge(type.replace('_', ' '), badge), ` ${items.length}`));
    const grid = el('div', { class: 'cards-wide' });
    items.forEach(t => {
      const st = t.state || (t.active ? 'active' : 'inactive');
      const border = st === 'active' || st === 'connected' ? 'card-active' : st === 'failed' ? 'card-error' : st === 'connecting' || st === 'reconnecting' ? 'card-warn' : 'card-dim';
      const rr = t.risk_range || [0, 10];
      const lo = Math.max(0, Math.min(10, rr[0] ?? 0));
      const hi = Math.max(lo, Math.min(10, rr[1] ?? 10));
      const riskLabel = lo === hi ? lo + '/10' : lo + '~' + hi;
      // Gradient from lo color to hi color
      const RC = s => s <= 2 ? '#3fb950' : s <= 4 ? '#d29922' : s <= 6 ? '#f59e0b' : s <= 8 ? '#f85149' : '#dc2626';
      const barColor = lo === hi ? RC(lo) : `linear-gradient(to right, ${RC(lo)}, ${RC(hi)})`;
      const barLeft = (lo / 10 * 100) + '%';
      const barWidth = (Math.max(hi - lo, 0.5) / 10 * 100) + '%';
      const card = el('div', { class: 'card ' + border, title: t.name + (t.description ? ' — ' + t.description : ''), 'data-search': (t.name + ' ' + (t.description || '')).toLowerCase() },
        el('div', { class: 'tool-header', style: { display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0 } },
          el('div', { class: 'tool-name', style: { flex: '1', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, title: t.name, text: t.name }),
          C.badge(st, STATUS_B[st] || 'b-muted'),
          t.tier && t.tier !== 'mcp' ? C.badge(t.tier === 'standard' ? 'std' : t.tier, 'b-muted') : null),
        el('div', { class: 'tool-risk', style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '11px', margin: '4px 0 2px' } },
          el('span', { style: { color: 'var(--text-tertiary, var(--fg2))', whiteSpace: 'nowrap', minWidth: '26px' }, text: 'Risk' }),
          el('div', { class: 'risk-bar-track', style: { flex: '1', height: '6px', background: 'var(--bg3)', borderRadius: '3px', position: 'relative', minWidth: '60px' } },
            el('div', { style: { position: 'absolute', left: barLeft, width: barWidth, height: '100%', borderRadius: '3px', background: barColor, transition: 'all 0.2s' } })),
          el('span', { style: { color: 'var(--text-secondary)', whiteSpace: 'nowrap', minWidth: '30px', textAlign: 'right' }, text: riskLabel })),
        el('div', { class: 'tool-desc', style: { overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: '2', WebkitBoxOrient: 'vertical', lineHeight: '1.4' }, title: t.description || '', text: t.description || '' }));
      if (t.type === 'mcp_server' && t.tool_count != null)
        card.appendChild(el('div', { class: 'tool-note', html: '<strong>' + esc(String(t.tool_count)) + '</strong> tools exposed' }));
      grid.appendChild(card);
    });
    g.appendChild(grid); f.appendChild(g);
  }
  render(f); schedulePoll(pgTools, CFG.pollSlow, v);
}

// Skills
async function pgSkills() {
  const v = routeVer;
  const d = await api('/skills');
  if (v !== routeVer) return;
  const f = el('div');
  if (!d?.length) { f.appendChild(C.page('Skills', 'No skills loaded')); f.appendChild(C.empty('No skills loaded.')); render(f); return; }
  const na = d.filter(s => s.status === 'active').length;
  f.appendChild(C.page('Skills', `${na} active / ${d.length} total`));

  const STATUS_B = { active: 'b-green', ineligible: 'b-red', superseded: 'b-muted', 'platform-ineligible': 'b-muted', disabled: 'b-muted' };
  const TIER_B = { bundled: 'b-blue', user: 'b-accent', workspace: 'b-green', custom: 'b-amber' };

  f.appendChild(el('div', { class: 'tool-filter' }, toolFilter(f, 'Filter skills...')));

  for (const tier of ['workspace', 'user', 'bundled', 'custom']) {
    const group = d.filter(s => s.source_tier === tier);
    if (!group.length) continue;
    const g = el('div', { class: 'tool-grp' });
    g.appendChild(el('div', { class: 'tool-grp-t' }, C.badge(tier, TIER_B[tier] || 'b-muted'), ` ${group.length}`));
    const grid = el('div', { class: 'cards-wide' });
    group.forEach(s => {
      const border = s.status === 'active' ? 'card-active' : s.status === 'ineligible' ? 'card-error' : 'card-dim';
      const kids = [
        el('div', { class: 'tool-name', text: s.name }),
        el('div', { class: 'tool-badges' },
          C.badge(s.status, STATUS_B[s.status] || 'b-muted'),
          s.status === 'active' ? C.badge(s.mode, s.mode === 'always' ? 'b-green' : 'b-blue') : null),
        el('div', { class: 'tool-desc', text: s.description || '' })
      ];
      if (s.keywords?.length) kids.push(el('div', { class: 'tool-kw' }, ...s.keywords.slice(0, 8).map(k => C.badge(k, 'b-muted'))));
      if (s.missing_requirements?.length) kids.push(el('div', { class: 'tool-note', html: '<strong>Missing:</strong> ' + esc(s.missing_requirements.join(', ')) }));
      if (s.superseded_by?.length && s.status === 'superseded') kids.push(el('div', { class: 'tool-note', html: '<strong>Superseded by:</strong> ' + esc(s.superseded_by.join(', ')) }));
      if (s.os_filter?.length) kids.push(el('div', { class: 'tool-note', html: '<strong>Platforms:</strong> ' + esc(s.os_filter.join(', ')) }));
      grid.appendChild(el('div', { class: 'card ' + border, 'data-search': (s.name + ' ' + (s.description || '') + ' ' + (s.keywords || []).join(' ')).toLowerCase() }, ...kids));
    });
    g.appendChild(grid); f.appendChild(g);
  }
  render(f); schedulePoll(pgSkills, CFG.pollSlow, v);
}

// Model Routing
function modelChain(chain) {
  const ol = el('ol', { style: 'margin:10px 0 0 0;padding:0 0 0 22px;display:flex;flex-direction:column;gap:8px' });
  const maxCtx = Math.max(...chain.map(m => m.context_window || 0), 1);
  chain.forEach((m, i) => {
    const p = i === 0;
    const li = el('li', { style: `color:${p ? 'var(--accent)' : 'var(--fg2)'}` });
    const row = el('div', { style: `display:flex;align-items:center;gap:10px;padding:6px 10px;border-radius:var(--radius-sm);${p ? 'background:var(--accent-dim);border:1px solid rgba(129,140,248,.15)' : ''}` });
    const pct = Math.max(3, (m.context_window || 0) / maxCtx * 100);
    const bar = el('div', { style: 'flex:1;height:5px;background:var(--bg3);border-radius:3px;min-width:40px;overflow:hidden' });
    bar.appendChild(el('div', { style: `width:${pct}%;height:100%;border-radius:3px;background:${p ? 'var(--accent)' : 'var(--fg2)'};opacity:${p ? '1' : '0.3'}` }));
    row.append(
      el('code', { text: m.model || '--', style: `font-family:var(--mono);font-size:0.92em;color:${p ? 'var(--fg-bright)' : 'var(--fg2)'};font-weight:${p ? '600' : '400'};min-width:180px;white-space:nowrap` }),
      bar,
      el('span', { text: m.context_window ? fmtK(m.context_window) : '--', style: `font-family:var(--mono);font-size:0.85em;color:${p ? 'var(--accent)' : 'var(--fg2)'};font-weight:${p ? '700' : '400'};min-width:48px;text-align:right` }));
    li.appendChild(row); ol.appendChild(li);
  });
  return ol;
}

async function pgModels() {
  const v = routeVer;
  const d = await api('/models');
  if (v !== routeVer) return;
  const f = el('div');
  f.appendChild(C.page('Model Routing', 'Fallback chains and context windows per agent'));
  if (!d) { f.appendChild(C.empty('Model info not available.')); render(f); schedulePoll(pgModels, CFG.pollSlow, v); return; }

  for (const [key, label, badgeCls] of [['agents', 'Agents', 'b-accent'], ['aliases', 'Aliases', 'b-blue']]) {
    const section = d[key];
    if (!section) continue;
    const grid = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(400px,1fr));gap:16px' });
    for (const [name, info] of Object.entries(section)) {
      const chain = info.chain || [], primary = chain[0], card = el('div', { class: 'panel' });
      const hdr = el('div', { style: 'display:flex;align-items:center;gap:10px' });
      if (key === 'agents') {
        hdr.appendChild(el('div', { style: 'font-size:1.05em;font-weight:700;color:var(--fg-bright)', text: name }));
        hdr.appendChild(C.badge(info.alias || '--', badgeCls));
        if (info.internal) hdr.appendChild(C.badge('internal', 'b-muted'));
        if (chain.length > 1) hdr.appendChild(el('span', { text: `${chain.length} models`, style: 'font-size:0.8em;color:var(--fg2)' }));
      } else {
        hdr.appendChild(C.badge(name, badgeCls));
        if (primary) hdr.append(el('code', { text: primary.model, style: 'font-family:var(--mono);font-size:0.9em;color:var(--fg2)' }), el('span', { text: '\u2192', style: 'color:var(--fg2);font-size:0.8em' }), el('span', { text: primary.context_window ? fmtK(primary.context_window) : '', style: 'font-family:var(--mono);font-size:0.85em;color:var(--accent);font-weight:600' }));
      }
      card.appendChild(hdr);
      if (chain.length > 1 || key === 'agents') card.appendChild(modelChain(chain));
      grid.appendChild(card);
    }
    f.appendChild(C.sec(label, grid));
  }
  render(f); schedulePoll(pgModels, CFG.pollSlow, v);
}

// Token Usage
function usageBar(val, max) {
  const w = el('div', { style: 'flex:1;height:4px;background:var(--bg3);border-radius:2px;overflow:hidden;min-width:40px' });
  w.appendChild(el('div', { style: `width:${max > 0 ? Math.max(2, val / max * 100) : 0}%;height:100%;background:var(--accent);border-radius:2px` }));
  return w;
}

async function pgCost() {
  const v = routeVer;
  const d = await api('/cost');
  if (v !== routeVer) return;
  const f = el('div');
  f.appendChild(C.page('Token Usage', 'Cumulative consumption across all LLM calls'));
  if (!d?.total?.calls) { f.appendChild(C.empty('No usage data yet. Start a conversation to see token stats.')); render(f); schedulePoll(pgCost, CFG.pollSlow, v); return; }

  const t = d.total, pctIn = Math.round((t.prompt_tokens || 0) / (t.total_tokens || 1) * 100), pctOut = 100 - pctIn;
  f.appendChild(C.grid(C.card('Total Tokens', fmtK(t.total_tokens || 0), `${(t.total_tokens || 0).toLocaleString()} tokens`), C.card('Prompt (in)', fmtK(t.prompt_tokens || 0), `${pctIn}% of total`), C.card('Completion (out)', fmtK(t.completion_tokens || 0), `${pctOut}% of total`), C.card('LLM Calls', String(t.calls || 0), `avg ${fmtK(Math.round((t.total_tokens || 0) / (t.calls || 1)))} per call`)));

  if (d.by_model && Object.keys(d.by_model).length) {
    const entries = Object.entries(d.by_model).sort((a, b) => (b[1].total_tokens || 0) - (a[1].total_tokens || 0));
    const maxT = Math.max(...entries.map(([, u]) => u.total_tokens || 0), 1);
    const panel = el('div', { class: 'panel' });
    panel.appendChild(el('div', { class: 'panel-t', text: 'Breakdown by Model' }));
    const list = el('div', { style: 'display:flex;flex-direction:column;gap:10px' });
    for (const [m, u] of entries) {
      const row = el('div', { style: 'display:flex;align-items:center;gap:12px' });
      row.append(el('code', { text: m, style: 'font-family:var(--mono);font-size:0.9em;color:var(--fg-bright);min-width:180px;white-space:nowrap' }), usageBar(u.total_tokens || 0, maxT), el('span', { text: fmtK(u.total_tokens || 0), style: 'font-family:var(--mono);font-size:0.85em;color:var(--accent);font-weight:600;min-width:52px;text-align:right' }), el('span', { text: `${u.calls} calls`, style: 'font-size:0.8em;color:var(--fg2);min-width:60px;text-align:right' }));
      list.appendChild(row);
    }
    panel.appendChild(list); f.appendChild(panel);
  }

  if (d.by_day && Object.keys(d.by_day).length) {
    const rows = Object.entries(d.by_day).slice(0, 7).map(([day, models]) => {
      const dayTotal = Object.values(models).reduce((s, u) => s + (u.total_tokens || 0), 0);
      const dayCalls = Object.values(models).reduce((s, u) => s + (u.calls || 0), 0);
      return { cells: [el('b', { text: day }), fmtK(dayTotal), String(dayCalls), el('span', { text: Object.keys(models).join(', '), style: 'font-size:0.85em;color:var(--fg2);font-family:var(--mono)' })] };
    });
    f.appendChild(C.sec('Daily Activity', C.table(['Date', 'Tokens', 'Calls', 'Models'], rows)));
  }
  render(f); schedulePoll(pgCost, CFG.pollSlow, v);
}

// Memory
async function pgMem() {
  const v = routeVer;
  const d = await api('/memory');
  if (v !== routeVer) return;
  const f = el('div');
  f.appendChild(C.page('Memory', 'MEMORY.md + knowledge store'));
  f.appendChild(C.sec('MEMORY.md', d?.memory_md ? el('div', { class: 'md-box', html: md(d.memory_md) }) : C.empty('No MEMORY.md found.')));
  if (d?.knowledge?.length) f.appendChild(C.sec('Knowledge Store', C.table(['Content', 'Category', 'Source'], d.knowledge.map(k => ({ cells: [(k.content || '').slice(0, 120) + ((k.content || '').length > 120 ? '\u2026' : ''), C.badge(k.category || '--', 'b-accent'), k.source || '--'] })))));
  render(f); schedulePoll(pgMem, CFG.pollSlow, v);
}

// Security
let auditFlt = 'all';
async function pgSec() {
  const v = routeVer;
  const [st, au, ap] = await Promise.all([api('/status'), api('/audit'), api('/approvals')]), f = el('div');
  if (v !== routeVer) return;
  f.appendChild(C.page('Security', 'E-stop, audit, approvals'));

  const es = st?.estop || {}, halted = es.halted || false;
  f.appendChild(C.sec('Emergency Stop', el('div', { class: 'estop-pnl' }, el('div', { class: 'estop-st', html: `<span class="beacon ${halted ? 'halt' : 'ok'}"></span>${halted ? 'HALTED' : 'Operational'}` }), halted ? el('div', { class: 'text-sm spacer', text: es.reason || '' }) : el('div', { class: 'spacer' }), halted ? el('button', { class: 'btn btn-ok', text: 'Reset E-stop', onclick: async () => { await apiPost('/reset', { actor: 'admin' }); pgSec(); } }) : el('button', { class: 'btn btn-danger', text: 'Trigger E-stop', onclick: async () => { const r = prompt('Reason:'); if (r) { await apiPost('/estop', { reason: r }); pgSec(); } } }))));

  const pend = ap?.pending || [];
  f.appendChild(C.sec('Pending Approvals', !pend.length ? C.empty('No pending approvals.') : C.table(['Tool', 'Agent', 'Created', 'Actions'], pend.map(a => ({ cells: [C.mono(a.tool_name), a.agent_name || '--', a.created_at ? new Date(a.created_at).toLocaleTimeString() : '--', el('div', null, el('button', { class: 'btn btn-ok btn-sm mr-xs', text: 'Approve', onclick: async () => { await apiPost(`/approvals/${a.id}/resolve`, { approved: true, resolver: 'admin' }); pgSec(); } }), el('button', { class: 'btn btn-danger btn-sm', text: 'Deny', onclick: async () => { await apiPost(`/approvals/${a.id}/resolve`, { approved: false, resolver: 'admin' }); pgSec(); } }))] })))));

  const entries = au?.entries || [], evts = [...new Set(entries.map(e => (e.event || '').split(':')[0]))].filter(Boolean);
  const evtBadge = e => !e ? 'b-muted' : e.startsWith('security') ? 'b-red' : e.startsWith('tool') ? 'b-blue' : e.startsWith('channel') ? 'b-green' : e.startsWith('auth') ? 'b-amber' : 'b-muted';
  const chips = el('div', { class: 'chips' }, el('span', { class: 'chip' + (auditFlt === 'all' ? ' on' : ''), text: 'All', onclick: () => { auditFlt = 'all'; pgSec(); } }), ...evts.map(t => el('span', { class: 'chip' + (auditFlt === t ? ' on' : ''), text: t, onclick: () => { auditFlt = t; pgSec(); } })));
  const filt = auditFlt === 'all' ? entries : entries.filter(e => (e.event || '').startsWith(auditFlt));
  const auditList = el('div', { style: 'display:flex;flex-direction:column;gap:1px' });
  filt.slice(0, 200).forEach(e => {
    const row = el('div', { style: 'display:flex;align-items:center;gap:10px;padding:7px 10px;cursor:pointer;border-radius:var(--radius-sm);transition:background .1s' });
    row.addEventListener('mouseenter', () => row.style.background = 'var(--bg3)');
    row.addEventListener('mouseleave', () => { if (!row.nextElementSibling?.classList?.contains('audit-detail')) row.style.background = ''; });

    row.appendChild(el('div', { style: 'min-width:110px' }, C.badge(e.event || '--', evtBadge(e.event)), e.is_error ? el('span', { text: ' \u2716', style: 'color:var(--red)' }) : null));
    const summary = e.tool || e.channel || '';
    row.appendChild(el('code', { text: summary, style: 'font-family:var(--mono);font-size:0.9em;color:var(--fg-bright);min-width:80px' }));
    row.appendChild(el('div', { class: 'spacer' }));
    const actor = (e.actor || '--').length > 20 ? (e.actor || '--').slice(0, 18) + '\u2026' : (e.actor || '--');
    row.appendChild(el('span', { text: actor, style: 'font-size:0.85em;color:var(--fg2)', title: e.actor || '' }));
    row.appendChild(el('span', { text: e.ts ? new Date(e.ts).toLocaleTimeString() : '--', style: 'font-size:0.8em;color:var(--fg2);min-width:70px;text-align:right' }));
    if (e.duration_ms > 0) row.appendChild(el('span', { text: Math.round(e.duration_ms) + 'ms', style: 'font-size:0.75em;color:var(--fg2);min-width:45px;text-align:right' }));

    row.addEventListener('click', () => {
      const existing = row.nextElementSibling;
      if (existing?.classList?.contains('audit-detail')) { existing.remove(); row.style.background = ''; return; }
      const detail = el('div', { class: 'audit-detail', style: 'padding:8px 10px 12px 130px;font-size:0.85em;color:var(--fg);background:var(--bg3);border-radius:0 0 var(--radius-sm) var(--radius-sm);margin-bottom:4px' });
      const grid = el('div', { style: 'display:grid;grid-template-columns:auto 1fr;gap:4px 12px' });
      const add = (k, v) => { if (v) { grid.appendChild(el('span', { text: k, style: 'color:var(--fg2);font-weight:500' })); grid.appendChild(el('span', { text: String(v), style: 'font-family:var(--mono);word-break:break-all' })); } };
      add('Event', e.event);
      add('Tool', e.tool);
      add('Channel', e.channel);
      add('Actor', e.actor);
      add('Session', e.session_id);
      add('Time', e.ts);
      if (e.duration_ms) add('Duration', Math.round(e.duration_ms) + 'ms');
      if (e.result_preview) add(e.is_error ? 'Error' : 'Result', e.result_preview);
      if (e.args) add('Args', JSON.stringify(e.args, null, 2));
      detail.appendChild(grid);
      row.after(detail);
      row.style.background = 'var(--bg3)';
    });

    auditList.appendChild(row);
  });
  f.appendChild(C.sec(`Audit Log (${filt.length})`, chips, !filt.length ? C.empty('No audit entries.') : auditList));
  render(f); schedulePoll(pgSec, CFG.pollFast, v);
}

// Settings
async function pgSet() {
  const d = await api('/config'), f = el('div');
  f.appendChild(C.page('Settings', 'Read-only configuration'));
  f.appendChild(d ? el('div', { class: 'cfg-block', text: JSON.stringify(d, null, 2) }) : C.empty('Configuration not available.'));
  render(f);
}

// ── Boot ─────────────────────────────────────────────────────
(async function boot() {
  if (CFG.mode !== 'cloud') {
    try {
      const r = await fetch('/api/auth/config');
      if (r.ok) {
        const cfg = await r.json();
        authRequired = cfg.api_key_enabled || cfg.entra_enabled;
        entraConfig = cfg;
        if (cfg.entra_enabled) { $('#entra-sec').style.display = ''; await initMsal(cfg); }
      }
    } catch {}
    if (authRequired && !isAuthed()) { render(el('div', { class: 'empty', text: 'Please sign in to view the dashboard.' })); openAuth(); return; }
  }
  route();
})();
