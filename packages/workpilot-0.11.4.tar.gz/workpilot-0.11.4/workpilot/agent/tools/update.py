"""
UpdateCheckTool — standard-tier tool for checking WorkPilot updates.

Available to the LLM on demand (user can ask about version/upgrade status).
Also called by the heartbeat cron job (HEARTBEAT.md enables it via tools()).
"""

from __future__ import annotations

import asyncio
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.risk import RiskAssessment, RiskScore


class UpdateCheckTool(Tool):
    """Check for WorkPilot updates."""

    risk_range = (0, 0)

    @property
    def name(self) -> str:
        return "check_update"

    @property
    def description(self) -> str:
        return "Check if a newer version of WorkPilot is available."

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Read-only update check")

    async def execute(self, **kwargs: Any) -> str:
        """Check for updates (runs blocking I/O in a thread)."""
        try:
            from workpilot.utils.update import check_update

            status = await asyncio.to_thread(check_update)
            return status.summary
        except Exception as exc:
            logger.debug("Update check failed: {}", exc)
            return f"Update check failed: {exc}"
