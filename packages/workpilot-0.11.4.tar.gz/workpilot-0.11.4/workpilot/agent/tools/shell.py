"""
Shell execution tool — sandboxed command runner with deny-pattern guards,
workspace restriction, output truncation, and timeout enforcement.
"""

from __future__ import annotations

import asyncio
import os
import platform
import re
import shutil
from typing import Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.leak import redact_credentials
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore
from workpilot.security.sandbox import CommandDeniedError, Sandbox

_IS_WINDOWS = platform.system() == "Windows"

# ── Risk assessment patterns ─────────────────────────────────────────────────

# File-reading commands — score based on target file path (reuse filesystem logic).
_SHELL_FILE_READ = re.compile(
    r"^(cat|head|tail|less|more|file|stat|wc)\s+(.+)",
    re.IGNORECASE,
)
# Directory-reading commands — score based on target path.
_SHELL_DIR_READ = re.compile(
    r"^(ls|dir|tree|du|df)\b(?:\s+(.+))?",
    re.IGNORECASE,
)
# Pure info commands — always 0, no file target.
_SHELL_INFO = re.compile(
    r"^(pwd|whoami|hostname|uname|date|id|env|printenv|set|echo|which|where|type)\b",
    re.IGNORECASE,
)
# Search commands — score based on search path.
_SHELL_SEARCH = re.compile(
    r"^(find|grep|rg|ag|awk|sed\s+-n|sort|uniq|cut|tr|diff|md5sum|sha256sum)\b",
    re.IGNORECASE,
)
# Linters (read-only analysis) → 2
_SHELL_LINTER = re.compile(
    r"^(ruff\s+check|mypy|pyright|pylint|flake8|eslint|tsc)\b",
    re.IGNORECASE,
)
# Test runners (may create/modify files) → 3
_SHELL_TEST = re.compile(
    r"^(pytest|python\s+-m\s+pytest|python\s+-m\s+unittest|"
    r"npm\s+test|npx\s+jest|npx\s+vitest|go\s+test|"
    r"cargo\s+test|dotnet\s+test)\b",
    re.IGNORECASE,
)
# Formatters (modify files in place) → 4
_SHELL_FORMATTER = re.compile(
    r"^(ruff\s+format|black|prettier|gofmt|rustfmt|dotnet\s+format)\b",
    re.IGNORECASE,
)
# Info commands for toolchains → 0
_SHELL_TOOLCHAIN_INFO = re.compile(
    r"^(dotnet\s+--info|dotnet\s+--list-sdks|dotnet\s+--list-runtimes|"
    r"dotnet\s+--version|node\s+--version|python\s+--version|"
    r"go\s+version|rustc\s+--version|java\s+--version)\b",
    re.IGNORECASE,
)
# Trivial project setup → 2
_SHELL_PROJECT_INIT = re.compile(
    r"^(dotnet\s+new)\b",
    re.IGNORECASE,
)
# Build / restore (compile, no install to system) → 3
_SHELL_BUILD = re.compile(
    r"^(npm\s+(run\s+)?build|yarn\s+build|cmake|"
    r"cargo\s+build|go\s+build|dotnet\s+build|dotnet\s+publish|dotnet\s+restore|"
    r"pip\s+wheel|python\s+setup\.py|python\s+-m\s+build)\b",
    re.IGNORECASE,
)
# Install commands → LLM (3~7)
_SHELL_INSTALL = re.compile(
    r"^(pip\s+install|python\s+-m\s+pip\s+install|npm\s+install|"
    r"yarn\s+add|dotnet\s+add\s+package|dotnet\s+tool\s+install|make)\b",
    re.IGNORECASE,
)
# npx / dotnet run → LLM (4~8), runs arbitrary code
_SHELL_EXEC_ARBITRARY = re.compile(
    r"^(npx\s|dotnet\s+run)\b",
    re.IGNORECASE,
)
# Publish / DB migration → LLM (5~8), affects external systems
_SHELL_PUBLISH = re.compile(
    r"^(dotnet\s+nuget\s+push|npm\s+publish|dotnet\s+ef\s+database)\b",
    re.IGNORECASE,
)
# curl/wget piped to shell → 9
_SHELL_CURL_PIPE = re.compile(
    r"\b(curl|wget)\b.*\|\s*(ba)?sh\b",
    re.IGNORECASE,
)
# General pipe to interpreter → LLM
_SHELL_PIPE_EXEC = re.compile(
    r"\|\s*(ba)?sh\b|\|\s*python\b|\|\s*node\b|\|\s*eval\b",
    re.IGNORECASE,
)
# Common cleanup targets (gitignored / build artifacts / temp files) → 4
# Well-known build artifacts / cache / temp directories and glob patterns.
# Match: rm [-rf] <known-target> (end of string — no other args).
_CLEANUP_TARGETS = (
    r"__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache|\.tox"
    r"|node_modules|\.next|\.nuxt|\.output"
    r"|bin[\\/]Debug|bin[\\/]Release|obj"
    r"|target[\\/]debug|target[\\/]release"
    r"|\.cache"
    r"|\*\.pyc|\*\.pyo|\*\.tmp|\*\.log|\*\.bak"
)
_SHELL_CLEANUP = re.compile(
    rf"^rm\s+(-r\s+|-rf\s+|-f\s+)?({_CLEANUP_TARGETS})[\\/]?$",
    re.IGNORECASE,
)
# rm -rf (recursive force, not cleanup) → 7
_SHELL_RM_RF = re.compile(r"^rm\s+-rf\s", re.IGNORECASE)
# rm (single file or directory) → 5
_SHELL_RM = re.compile(r"^(rm|rmdir|del|rd|shred|unlink)\b", re.IGNORECASE)
_SHELL_NETWORK = re.compile(
    r"\b(curl|wget|ssh|scp|rsync|nc|ncat|netcat|telnet|ftp)\b",
    re.IGNORECASE,
)
_SHELL_DELETE = re.compile(
    r"\b(rm|rmdir|del|rd|shred|unlink)\b",
    re.IGNORECASE,
)
_SHELL_ELEVATED = re.compile(
    r"\b(sudo|runas|doas|pkexec|su\s)\b",
    re.IGNORECASE,
)
_SHELL_REDIRECT_SYSTEM = re.compile(
    r">\s*/etc/|>\s*/usr/|>\s*C:\\Windows",
    re.IGNORECASE,
)

# Shell executable resolution for each mode
_SHELL_EXECUTABLES: dict[str, list[str]] = {
    "bash": ["bash"],
    "cmd": ["cmd.exe"],
    "powershell": ["pwsh", "powershell"],
}


def _resolve_shell(mode: str) -> tuple[str | None, list[str]]:
    """Resolve shell executable and prefix args.

    Returns (executable, prefix_args). executable=None means use default
    (asyncio.create_subprocess_shell).

    Supports named modes (auto/bash/cmd/powershell) and arbitrary paths.
    """
    if mode == "auto":
        return None, []

    # Named modes
    candidates = _SHELL_EXECUTABLES.get(mode)
    if candidates:
        for candidate in candidates:
            path = shutil.which(candidate)
            if path:
                if mode == "cmd":
                    return path, ["/c"]
                if mode == "powershell":
                    return path, ["-NoProfile", "-Command"]
                return path, ["-c"]
        return None, []  # fallback to default

    # Arbitrary path (e.g. "/usr/bin/zsh", "C:\\cygwin\\bin\\sh.exe")
    resolved = shutil.which(mode)
    if resolved:
        return resolved, ["-c"]

    return None, []  # fallback to default


class ShellTool(Tool):
    """Execute shell commands within the workspace sandbox."""

    risk_range = (0, 10)
    _MAX_BACKGROUND = 3

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox
        self._background: dict[int, asyncio.subprocess.Process] = {}  # pid → proc

    async def kill_all_background(self) -> int:
        """Kill all background processes. Called on E-stop or session end.

        Returns number of processes killed.
        """
        killed = 0
        for _pid, proc in list(self._background.items()):
            if proc.returncode is None:
                try:
                    proc.kill()
                    await asyncio.wait_for(proc.wait(), timeout=3)
                    killed += 1
                except (OSError, TimeoutError):
                    pass
        self._background.clear()
        return killed

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600, streaming=True)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        command = (args.get("command", "") or "").strip()
        if not command:
            return RiskScore(0, reason="Empty command")
        # Redacted command for use in prompt/reason strings (visible in UI/logs/LLM).
        # Original `command` is still used for pattern matching above.
        safe_cmd = redact_credentials(command)

        # ── Deny patterns → 10 (except curl|sh which is handled below) ──
        # curl|sh is caught by _SHELL_CURL_PIPE at score 9 before deny check
        if _SHELL_CURL_PIPE.search(command):
            return RiskScore(9, reason=f"Pipe download to shell: {safe_cmd}")

        matched = self._sandbox.match_deny_pattern(command)
        if matched:
            return RiskScore(10, reason=f"Matches deny pattern: {matched}")

        # ── Pipe to interpreter → LLM ───────────────────────────────────
        if _SHELL_PIPE_EXEC.search(command):
            return RiskPrompt(
                f"Shell command pipes to interpreter: {safe_cmd}. Range: 5~8\n"
                f"Scoring factors:\n"
                f"  5: Pipe of known safe content (e.g. echo literal | python -c)\n"
                f"  6: Pipe from local file to interpreter\n"
                f"  7: Pipe from network source or dynamic content\n"
                f"  8: Pipe with elevated privileges or to system shell"
            )

        # ── File-reading commands → score based on file path ─────────────
        from workpilot.agent.tools.filesystem import path_risk_level

        m = _SHELL_FILE_READ.match(command)
        if m:
            target = m.group(2).split()[0].strip("'\"")  # first argument
            _, read_score, _ = path_risk_level(target)
            return RiskScore(read_score, reason=f"Read file: {target}")

        m = _SHELL_DIR_READ.match(command)
        if m:
            target = (m.group(2) or ".").split()[0].strip("'\"")
            category, _, _ = path_risk_level(target)
            if category == "credential":
                return RiskScore(4, reason=f"List credential dir: {target}")
            if category == "system":
                return RiskScore(3, reason=f"List system dir: {target}")
            if category in ("user_secret", "project_secret"):
                return RiskScore(1, reason=f"List {category} dir: {target}")
            return RiskScore(0, reason=f"Read-only: {safe_cmd}")

        # Pure info commands → 0
        if _SHELL_INFO.match(command):
            return RiskScore(0, reason="Info command")

        # Search commands → 0 (workspace-scoped by sandbox)
        if _SHELL_SEARCH.match(command):
            return RiskScore(0, reason="Search command")

        # ── Dev tools ────────────────────────────────────────────────────
        if _SHELL_TOOLCHAIN_INFO.match(command):
            return RiskScore(0, reason="Toolchain version/info query")

        if _SHELL_LINTER.match(command):
            return RiskScore(2, reason="Linter (read-only analysis)")

        if _SHELL_PROJECT_INIT.match(command):
            return RiskScore(2, reason="Project scaffolding")

        if _SHELL_TEST.match(command):
            return RiskScore(3, reason="Test runner (may modify files)")

        if _SHELL_FORMATTER.match(command):
            return RiskScore(4, reason="Formatter (modifies files in place)")

        if _SHELL_BUILD.match(command):
            return RiskScore(3, reason="Build/compile command")

        # ── Install / package management → LLM (3~7) ────────────────────
        if _SHELL_INSTALL.match(command):
            return RiskPrompt(
                f"Shell command: {safe_cmd}. Detected: install/package manager. Range: 3~7\n"
                f"Scoring factors:\n"
                f"  3: Local editable install (pip install -e .), lock-file restore (npm ci)\n"
                f"  4: Well-known package from official registry\n"
                f"  5: Less common package, or installs from git URL\n"
                f"  6: Untrusted source, --pre/--force flag, or system-wide install (no venv)\n"
                f"  7: Install from arbitrary URL, or package name looks suspicious/typosquatted"
            )

        # Arbitrary code execution → LLM (4~8)
        if _SHELL_EXEC_ARBITRARY.match(command):
            return RiskPrompt(
                f"Shell command: {safe_cmd}. Detected: arbitrary code execution. Range: 4~8\n"
                f"Scoring factors:\n"
                f"  4: Run well-known project entry point (dotnet run, npx tsc)\n"
                f"  5: Run local project script with known purpose\n"
                f"  6: Run third-party package directly (npx unknown-tool)\n"
                f"  7: Run with elevated access or network-facing flags\n"
                f"  8: Run untrusted code, or --dangerously/--no-verify flags"
            )

        # Publish / DB migration → LLM (5~8)
        if _SHELL_PUBLISH.match(command):
            return RiskPrompt(
                f"Shell command: {safe_cmd}. Detected: publish/deploy/migrate. Range: 5~8\n"
                f"Scoring factors:\n"
                f"  5: Publish to private/internal registry or dry-run\n"
                f"  6: Publish to public registry (npm, NuGet) with scope/org\n"
                f"  7: DB migration on dev/staging, or publish without scope\n"
                f"  8: DB migration on production, or publish overwriting existing version"
            )

        # ── Delete commands — classified by target ────────────────────────
        if _SHELL_CLEANUP.match(command):
            return RiskScore(4, reason=f"Cleanup build artifacts / temp files: {safe_cmd}")
        if _SHELL_RM_RF.match(command):
            return RiskScore(7, reason=f"Recursive force delete: {safe_cmd}")
        if _SHELL_RM.match(command):
            return RiskScore(5, reason=f"Delete file/directory: {safe_cmd}")

        # ── Ambiguous — collect hints and scoring factors ─────────────────
        hints: list[str] = []
        factors: list[str] = []
        lo, hi = 3, 6
        if _SHELL_NETWORK.search(command):
            hints.append("network")
            lo, hi = max(lo, 4), max(hi, 7)
            factors.extend(
                [
                    "  Lower: read-only GET/fetch, downloading docs/data",
                    "  Higher: POST/PUT to API, uploading data, connecting to internal services",
                ]
            )
        if _SHELL_DELETE.search(command):
            hints.append("delete")
            lo, hi = max(lo, 4), max(hi, 7)
            factors.extend(
                [
                    "  Lower: delete single temp file, git-restorable workspace file",
                    "  Higher: delete directory tree, non-recoverable files, system paths",
                ]
            )
        if _SHELL_ELEVATED.search(command):
            hints.append("elevated")
            lo, hi = max(lo, 6), max(hi, 9)
            factors.extend(
                [
                    "  Lower: install system package (apt/brew) for dev tooling",
                    "  Higher: modify system config, change permissions, manage services",
                ]
            )
        if _SHELL_REDIRECT_SYSTEM.search(command):
            hints.append("system-redirect")
            lo, hi = max(lo, 7), max(hi, 9)
            factors.extend(
                [
                    "  Lower: append to log file in /var/log",
                    "  Higher: overwrite system config (/etc/hosts, /etc/resolv.conf)",
                ]
            )

        hint_str = f" Detected: {', '.join(hints)}." if hints else ""
        factor_str = "\nScoring factors:\n" + "\n".join(factors) if factors else ""
        return RiskPrompt(f"Shell command: {safe_cmd}.{hint_str} Range: {lo}~{hi}{factor_str}")

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return "Execute a shell command."

    @property
    def parameters(self) -> dict[str, Any]:
        default_shell = "cmd" if _IS_WINDOWS else "bash"
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The command to execute.",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds. 0 = background (return immediately). Default: 600.",
                },
                "directory": {
                    "type": "string",
                    "description": "Working directory (relative to workspace). Default: workspace root.",
                },
                "shell": {
                    "type": "string",
                    "description": f"Shell to use: auto (default, OS default = {default_shell}), bash, cmd, powershell, or a path.",
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> str:
        command: str = kwargs["command"]
        max_timeout = self.metadata.timeout  # 600s from ToolMetadata
        raw_timeout = kwargs.get("timeout")
        background = raw_timeout == 0
        timeout: float | None = (
            None
            if raw_timeout is None
            else (None if background else min(max(int(raw_timeout), 1), max_timeout))
        )
        if timeout is None and not background:
            timeout = max_timeout
        directory: str = kwargs.get("directory", "")
        shell_mode: str = kwargs.get("shell", "auto")

        # Security check
        try:
            self._sandbox.check_command(command)
        except CommandDeniedError as exc:
            return f"BLOCKED: {exc}"

        # Resolve working directory
        if directory:
            cwd = (self._sandbox.workspace / directory).resolve()
            # Ensure it's within workspace
            try:
                cwd.relative_to(self._sandbox.workspace)
            except ValueError:
                return f"BLOCKED: directory '{directory}' is outside workspace"
            if not cwd.is_dir():
                return f"Error: directory '{directory}' does not exist"
        else:
            cwd = self._sandbox.workspace

        # Resolve shell executable
        shell_exe, shell_args = _resolve_shell(shell_mode)

        try:
            if shell_exe:
                proc = await asyncio.create_subprocess_exec(
                    shell_exe,
                    *shell_args,
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                    env={**os.environ},
                )
            else:
                proc = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd),
                    env={**os.environ},
                )

            # Background mode: return immediately with PID
            if background:
                # Clean up finished background processes
                self._background = {
                    pid: p for pid, p in self._background.items() if p.returncode is None
                }
                if len(self._background) >= self._MAX_BACKGROUND:
                    return (
                        f"Error: max {self._MAX_BACKGROUND} background processes. "
                        f"Running: {', '.join(str(p) for p in self._background.keys())}"
                    )
                pid = proc.pid
                self._background[pid] = proc
                stop_cmd = f"taskkill /PID {pid} /F" if _IS_WINDOWS else f"kill {pid}"
                return (
                    f"Background process started: PID {pid}\n"
                    f"Command: {command}\n"
                    f"Use shell(command='{stop_cmd}') to stop."
                )

            # Stream stdout line-by-line when progress callback is available
            if self._progress and proc.stdout:
                stdout_lines: list[str] = []
                try:

                    async def _read_stdout() -> None:
                        assert proc.stdout is not None
                        while True:
                            line = await proc.stdout.readline()
                            if not line:
                                break
                            decoded = line.decode("utf-8", errors="replace")
                            stdout_lines.append(decoded)
                            if self._progress:
                                await self._progress(decoded)

                    async def _read_stderr() -> bytes:
                        assert proc.stderr is not None
                        return await proc.stderr.read()

                    stderr_bytes, _ = await asyncio.wait_for(
                        asyncio.gather(_read_stderr(), _read_stdout()),
                        timeout=timeout,
                    )
                except TimeoutError:
                    proc.kill()
                    await proc.wait()
                    return f"Command timed out after {timeout}s"

                await proc.wait()
                stdout_text = "".join(stdout_lines)
                stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            else:
                # Non-streaming path
                try:
                    stdout_raw, stderr_raw = await asyncio.wait_for(
                        proc.communicate(),
                        timeout=timeout,
                    )
                except TimeoutError:
                    proc.kill()
                    await proc.wait()
                    return f"Command timed out after {timeout}s"
                stdout_text = stdout_raw.decode("utf-8", errors="replace") if stdout_raw else ""
                stderr_text = stderr_raw.decode("utf-8", errors="replace") if stderr_raw else ""

            output_parts: list[str] = []
            if stdout_text:
                output_parts.append(stdout_text)
            if stderr_text:
                output_parts.append(stderr_text)

            output = "\n".join(output_parts).strip() or "(no output)"

            if proc.returncode != 0:
                output = f"Exit code {proc.returncode}\n{output}"

            return output

        except Exception as exc:
            return f"Shell error: {exc}"
