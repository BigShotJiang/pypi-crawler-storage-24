"""
Consolidator — memory consolidation, grouping, and compression logic.

Split from loop.py for modularity. Dependencies are injected explicitly
via constructor — no mixin, no type stubs needed.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.agent.compaction import estimate_tokens
from workpilot.agent.truncation import (
    llm_compress,
    resolve_fast_context_limit,
    smart_truncate,
)

if TYPE_CHECKING:
    from workpilot.agent.memory import AgentMemory
    from workpilot.config.schema import AgentConfig
    from workpilot.providers.base import LLMProvider
    from workpilot.session.manager import SessionManager


class Consolidator:
    """Memory consolidation, grouping, tool-output compression, and re-compression.

    All dependencies are injected via the constructor.

    Parameters
    ----------
    provider:
        LLM provider for consolidation and compression calls.
    memory:
        AgentMemory instance for MEMORY.md and HistoryStore access.
    sessions:
        SessionManager for disk message loading and meta tracking.
    config:
        Agent configuration (memory_window, model, etc.).
    context_limit_fn:
        Callable that returns the effective main model context window.
    """

    _TRUNCATE_THRESHOLD = 2000  # chars — tool outputs longer than this get truncated
    _LLM_COMPRESS_THRESHOLD = 8000  # chars — tool outputs longer than this get LLM-compressed

    def __init__(
        self,
        provider: LLMProvider,
        memory: AgentMemory,
        sessions: SessionManager,
        config: AgentConfig,
        context_limit_fn: Callable[[], int],
    ) -> None:
        self._provider = provider
        self._memory = memory
        self._sessions = sessions
        self._config = config
        self._context_limit_fn = context_limit_fn
        self._pending = False

    # ── Consolidation entry point ─────────────────────────────────────────

    # Cron/scheduler sessions should not pollute MEMORY.md with their
    # doing: tags or Facts. They get HISTORY entries via direct append only.
    _SKIP_CONSOLIDATION_PREFIXES = ("scheduler_",)

    async def maybe_consolidate(self, session_id: str, *, force: bool = False) -> None:
        """Consolidate memory if conversation exceeds window size.

        Reads from disk JSONL (not in-memory messages) for true async execution.
        Uses AgentMemory's per-workspace lock shared across all AgentLoop instances.

        Skips sessions from the scheduler (cron jobs, heartbeat) to prevent
        automated tasks from polluting MEMORY.md with irrelevant facts.
        """
        if any(session_id.startswith(p) for p in self._SKIP_CONSOLIDATION_PREFIXES):
            return
        if self._pending and not force:
            return
        self._pending = True
        try:
            async with self._memory.consolidation_lock:
                await self._do_consolidate(session_id, force=force)
        finally:
            self._pending = False

    async def _do_consolidate(self, session_id: str, *, force: bool = False) -> None:
        """Disk-based consolidation with task grouping (§6 of compaction.md).

        Phase 1: LLM groups messages into distinct tasks (fast model).
        Phase 2: Each completed group (all except last) gets its own
                 consolidation LLM call → MEMORY.md + HISTORY.md.
        Sliding window: last group is NOT written to history. A ``doing:``
                 tag is added to MEMORY.md. ``last_consolidated_at`` is set
                 to the START of the last group so it is re-processed next time.

        When ``force=True`` (e.g. ``/new``), all groups including the last are
        processed — no sliding window.
        """
        meta = self._sessions.read_meta(session_id)
        last_at = meta.get("last_consolidated_at")

        # Read unconsolidated messages from disk
        disk_msgs = self._sessions.load_disk_messages(session_id, after_ts=last_at)

        min_msgs = 10 if force else max(25, self._config.memory_window // 2)
        if len(disk_msgs) < min_msgs:
            return

        # Skip re-grouping if we already grouped up to the latest message
        if not force:
            last_grouped = meta.get("last_grouped_at")
            if last_grouped and disk_msgs:
                latest_ts = disk_msgs[-1].get("_ts", "")
                if last_grouped >= latest_ts:
                    return

        # ── Phase 1: Task grouping (fast model) ──────────────────────────
        groups = await self._group_messages(disk_msgs)
        if not groups:
            groups = [{"topic": "session", "start": 0, "end": len(disk_msgs) - 1}]

        logger.info(f"Consolidation: {len(groups)} task groups identified")

        # Determine which groups to process
        if force:
            completed_groups = groups
            sliding_group = None
        else:
            completed_groups = groups[:-1]
            sliding_group = groups[-1]

        context_limit = self._context_limit_fn()
        reserve = max(6000, context_limit // 4)
        available = max(context_limit - reserve, context_limit // 2)

        # ── Phase 2: Per-group consolidation ─────────────────────────────
        all_groups_ok = True
        for gi, group in enumerate(completed_groups):
            start, end = group["start"], group["end"]
            group_msgs = disk_msgs[start : end + 1]

            group_msgs = await self._compress_to_fit(group_msgs, available)

            task_ctx = (
                f"Processing group {gi + 1} of {len(groups)}: "
                f'"{group["topic"]}" ({len(group_msgs)} messages).'
            )
            logger.info(f"Consolidating: {task_ctx}")
            llm_msgs = self._memory.build_consolidation_messages(group_msgs, task_context=task_ctx)
            try:
                response = await self._provider.complete(
                    model=self._config.model,
                    messages=llm_msgs,
                    temperature=0.1,
                    max_tokens=2048,
                )
                self._memory.apply_consolidation(response.content, group_msgs, session_id)
            except Exception as exc:
                logger.error(f"Consolidation group {gi + 1} failed: {exc}")
                all_groups_ok = False
                break  # Abort remaining groups

            last_ts = disk_msgs[end].get("_ts")
            if last_ts:
                self._sessions.update_meta(session_id, last_consolidated_at=last_ts)

        # ── Sliding window: handle last group ────────────────────────────
        # Only update sliding/grouping progress if all completed groups succeeded.
        # Otherwise, failed groups would be skipped on the next run.
        if sliding_group and all_groups_ok:
            topic = sliding_group.get("topic", "ongoing work")
            self._memory.add_doing_tag(topic)
            slide_start = sliding_group["start"]
            if slide_start > 0:
                prev_ts = disk_msgs[slide_start - 1].get("_ts")
                if prev_ts:
                    self._sessions.update_meta(session_id, last_consolidated_at=prev_ts)
            slide_end = sliding_group.get("end")
            if isinstance(slide_end, int) and 0 <= slide_end < len(disk_msgs):
                end_ts = disk_msgs[slide_end].get("_ts")
                if end_ts:
                    self._sessions.update_meta(session_id, last_grouped_at=end_ts)
            logger.info(f'Sliding window: last group "{topic}" deferred to next consolidation')

        # Re-compress if memory exceeds threshold
        try:
            if self._memory.needs_recompression():
                await self._recompress_memory()
        except Exception as exc:
            logger.error(f"Memory re-compression failed: {exc}")

        self._sessions.trim(session_id, self._config.memory_window)
        self._sessions.maybe_split_session(session_id)
        logger.info("Memory consolidation complete")

    # ── Task grouping ─────────────────────────────────────────────────────

    def _resolve_fast_context_limit(self) -> int:
        """Resolve the context window for the fast model."""
        return resolve_fast_context_limit(self._provider)

    async def _group_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Phase 1: LLM-based task grouping (fast model)."""
        try:
            grouping_msgs = self._memory.build_grouping_messages(messages)

            fast_limit = int(self._resolve_fast_context_limit() * 0.9)
            input_tokens = estimate_tokens(grouping_msgs)
            if input_tokens > fast_limit:
                logger.warning(
                    "Grouping input {}t exceeds fast model limit {}t, falling back",
                    input_tokens,
                    fast_limit,
                )
                return [{"topic": "session", "start": 0, "end": len(messages) - 1}]

            max_output = min(4096, max(1024, len(messages) // 5 * 60))

            response = await self._provider.complete(
                model="fast",
                messages=grouping_msgs,
                temperature=0.0,
                max_tokens=max_output,
            )
            groups = self._parse_grouping_response(response.content, len(messages))
            if groups:
                return groups
        except Exception as exc:
            logger.warning(f"Task grouping failed, using single group: {exc}")

        return [{"topic": "session", "start": 0, "end": len(messages) - 1}]

    @staticmethod
    def _parse_grouping_response(content: str, msg_count: int) -> list[dict[str, Any]] | None:
        """Parse the grouping LLM response into validated groups."""
        json_match = re.search(r"```json\s*\n(.*?)```", content, re.DOTALL)
        raw = json_match.group(1).strip() if json_match else content.strip()

        try:
            groups = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            logger.warning("Grouping response is not valid JSON")
            return None

        if not isinstance(groups, list) or not groups:
            return None

        for g in groups:
            if not isinstance(g, dict):
                return None
            if "start" not in g or "end" not in g or "topic" not in g:
                return None
            if not isinstance(g["start"], int) or not isinstance(g["end"], int):
                return None
            if g["start"] < 0 or g["end"] >= msg_count or g["start"] > g["end"]:
                return None

        groups.sort(key=lambda g: g["start"])
        if groups[0]["start"] != 0:
            logger.warning(
                "Grouping response does not start at message 0 (starts at {})", groups[0]["start"]
            )
            return None
        if groups[-1]["end"] != msg_count - 1:
            logger.warning(
                "Grouping response does not cover last message (ends at {}, expected {})",
                groups[-1]["end"],
                msg_count - 1,
            )
            return None
        for i in range(1, len(groups)):
            if groups[i]["start"] != groups[i - 1]["end"] + 1:
                logger.warning("Grouping response has gaps between groups")
                return None

        return groups

    # ── Tool output compression ───────────────────────────────────────────

    async def _compress_to_fit(
        self, messages: list[dict[str, Any]], max_tokens: int
    ) -> list[dict[str, Any]]:
        """Compress tool outputs until the group fits within max_tokens.

        Three tiers, applied to the 2 longest tool outputs per round:
        1. Smart truncate (>2K chars): keep head + tail, cut middle.
        2. LLM compress (>8K chars): fast model summarizes.
        3. Stop if no more compressible outputs remain (best-effort).
        """
        if estimate_tokens(messages) <= max_tokens:
            return messages

        messages = [dict(m) for m in messages]

        while estimate_tokens(messages) > max_tokens:
            candidates: list[tuple[int, int]] = []
            for i, m in enumerate(messages):
                if (
                    m.get("role") == "tool"
                    and m.get("content", "")
                    and not m.get("_compressed")
                    and len(m["content"]) > self._TRUNCATE_THRESHOLD
                ):
                    candidates.append((i, len(m["content"])))

            if not candidates:
                break

            candidates.sort(key=lambda x: x[1], reverse=True)
            for idx, size in candidates[:2]:
                m = messages[idx]
                content = m["content"]

                if size > self._LLM_COMPRESS_THRESHOLD:
                    compressed = await self._llm_compress_tool_output(content, idx, messages)
                else:
                    compressed = self._smart_truncate(content)

                messages[idx] = {**m, "content": compressed, "_compressed": True}

        return messages

    @staticmethod
    def _smart_truncate(content: str, head_lines: int = 20, tail_lines: int = 10) -> str:
        """Keep first N + last M lines, cut the middle.

        Delegates to :func:`workpilot.agent.truncation.smart_truncate`.
        Uses ``len(content)`` as *max_chars* so only line-level truncation
        applies (no hard character cut — the caller controls token budget).
        """
        return smart_truncate(
            content, max_chars=len(content), head_lines=head_lines, tail_lines=tail_lines
        )

    # Cap consolidation compression output to keep cost bounded.
    _CONSOLIDATION_MAX_CHARS = 8192

    async def _llm_compress_tool_output(
        self, content: str, tool_idx: int, messages: list[dict[str, Any]]
    ) -> str:
        """Use fast model to compress a large tool output, preserving key facts.

        Delegates to :func:`workpilot.agent.truncation.llm_compress`.
        Uses a bounded *max_chars* to keep the compression completion
        within a reasonable token budget.
        """
        tool_name = self._resolve_tool_name_at(tool_idx, messages)
        max_chars = min(len(content), self._CONSOLIDATION_MAX_CHARS)
        return await llm_compress(content, tool_name, self._provider, max_chars=max_chars)

    @staticmethod
    def _resolve_tool_name_at(tool_idx: int, messages: list[dict[str, Any]]) -> str:
        """Resolve tool name from preceding assistant tool_calls."""
        tc_id = messages[tool_idx].get("tool_call_id", "")
        for j in range(tool_idx - 1, -1, -1):
            if messages[j].get("role") == "assistant":
                for tc in messages[j].get("tool_calls", []):
                    if tc.get("id") == tc_id:
                        return str(tc.get("function", {}).get("name", "tool"))
                break
        return "tool"

    # ── Re-compression ────────────────────────────────────────────────────

    @staticmethod
    def _load_recompression_messages(
        *,
        total_chars: int,
        size_summary: str,
        worst: str,
        memory_content: str,
    ) -> list[dict[str, str]]:
        """Load _RECOMPRESSION.md and return [system, user] messages."""
        from workpilot.utils.defaults import load_default

        template = load_default("_RECOMPRESSION.md")

        system_content = template.format(
            total_chars=str(total_chars),
            size_summary=size_summary,
            worst=worst,
        )
        return [
            {"role": "system", "content": system_content},
            {"role": "user", "content": memory_content},
        ]

    async def _recompress_memory(self) -> None:
        """Re-compress MEMORY.md when it exceeds the threshold."""
        diag = self._memory.diagnose_oversize()
        worst = diag["worst"]
        sizes = diag["char_sizes"]
        budgets = diag["budgets"]
        logger.info(
            "MEMORY.md {} chars, {} most over budget ({}/{} chars)",
            diag["total_chars"],
            worst,
            sizes.get(worst, 0),
            budgets.get(worst, 0),
        )
        size_summary = ", ".join(
            f"{n}={sizes.get(n, 0)}/{budgets.get(n, 0)} chars" for n in ("Facts", "Recent Activity")
        )
        recompress_msgs = self._load_recompression_messages(
            total_chars=diag["total_chars"],
            size_summary=size_summary,
            worst=worst,
            memory_content=self._memory.read_memory(),
        )
        recompress_resp = await self._provider.complete(
            model=self._config.model,
            messages=recompress_msgs,
            temperature=0.1,
            max_tokens=2048,
        )
        mem_match = re.search(r"```memory\n(.*?)```", recompress_resp.content, re.DOTALL)
        if mem_match:
            self._memory.write_memory(mem_match.group(1).strip())
            logger.info("Memory re-compression complete")
