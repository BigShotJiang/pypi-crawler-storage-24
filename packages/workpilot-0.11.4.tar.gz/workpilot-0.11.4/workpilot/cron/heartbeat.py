"""Heartbeat — periodic background maintenance task.

Uses a persistent session (single JSONL file on disk for audit) with
in-memory history cleared before each run, so the LLM starts with a
clean context. Cross-run context is managed via a state file with
time-decayed detail:

- **today**: per-run log with timestamps (last 48 entries)
- **recent** (7 days): per-day summaries with notable events
- **older** (8 weeks): weekly run counts only
- **notable**: persistent list of rare events (leaks, updates, skill
  changes) that survive the 7-day window

The state is prepended to the HEARTBEAT.md prompt as a
``## Prior Heartbeat Activity`` section, giving the LLM ~1-2KB of
structured context instead of ~42KB of repeated conversations.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from workpilot.utils.defaults import load_default

# ── Constants ────────────────────────────────────────────────────────────────

JOB_NAME = "__heartbeat__"
STATE_FILENAME = "heartbeat_state.json"

_TODAY_LOG_MAX = 48  # one day at 30-min intervals
_RECENT_DAYS_MAX = 7
_OLDER_WEEKS_MAX = 8
_NOTABLE_MAX = 20
_CONTEXT_TODAY_LOG = 10  # last N log entries shown to LLM
_DAY_EVENTS_MAX = 5
_RECENT_EVENTS_SHOWN = 3


# ── Prompt building ──────────────────────────────────────────────────────────


def load_heartbeat_prompt(state: dict[str, Any]) -> str | None:
    """Load HEARTBEAT.md and prepend prior-activity context.

    Returns None if HEARTBEAT.md is empty (nothing to do).
    """
    # Empty user file = disable heartbeat (return None)
    prompt = load_default("HEARTBEAT.md", allow_empty_override=True)
    if not prompt:
        return None

    context = build_context(state)
    return f"{context}{prompt}" if context else prompt


# ── State I/O ────────────────────────────────────────────────────────────────


def state_file_path() -> Path:
    return Path.home() / ".workpilot" / STATE_FILENAME


def read_state() -> dict[str, Any]:
    """Read heartbeat state file, or return default structure."""
    try:
        path = state_file_path()
        if path.is_file():
            data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
            return data
    except (json.JSONDecodeError, OSError):
        pass
    return {"today": {}, "recent": [], "older": [], "notable": []}


def write_state(state: dict[str, Any]) -> None:
    """Persist heartbeat state to disk."""
    try:
        path = state_file_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        logger.debug("Failed to write heartbeat state: {}", exc)


# ── Context building ─────────────────────────────────────────────────────────


def build_context(state: dict[str, Any]) -> str:
    """Build a ``## Prior Heartbeat Activity`` section from state.

    Example output::

        ## Prior Heartbeat Activity

        ### Today (2026-03-24) — 5 runs, 0 failed
        - 08:00 HEARTBEAT_OK
        - 09:00 update_available: v0.12.0, notified user

        ### Recent Days
        - 2026-03-23: 47 runs, 1 failed | skill_created: git-pr-review

        ### Notable Events
        - 2026-03-23 New version v0.12.0 available, user notified
    """
    sections: list[str] = []

    # Today
    today_data = state.get("today", {})
    if today_data.get("runs"):
        runs = today_data["runs"]
        failed = today_data.get("failed", 0)
        header = f"### Today ({today_data.get('date', '?')}) — {runs} runs, {failed} failed"
        lines = [header]
        for entry in today_data.get("log", [])[-_CONTEXT_TODAY_LOG:]:
            lines.append(f"- {entry}")
        sections.append("\n".join(lines))

    # Recent days
    recent = state.get("recent", [])
    if recent:
        lines = ["### Recent Days"]
        for day in recent[:_RECENT_DAYS_MAX]:
            date = day.get("date", "?")
            r, f = day.get("runs", 0), day.get("failed", 0)
            entry = f"- {date}: {r} runs, {f} failed"
            events = day.get("events", [])
            if events:
                entry += " | " + "; ".join(events[:_RECENT_EVENTS_SHOWN])
            lines.append(entry)
        sections.append("\n".join(lines))

    # Notable events
    notable = state.get("notable", [])
    if notable:
        lines = ["### Notable Events"]
        for event in notable[-_CONTEXT_TODAY_LOG:]:
            lines.append(f"- {event}")
        sections.append("\n".join(lines))

    if not sections:
        return ""
    return "## Prior Heartbeat Activity\n\n" + "\n\n".join(sections) + "\n\n"


# ── State update ─────────────────────────────────────────────────────────────


def update_state(
    state: dict[str, Any],
    result: str | None,
    daily_counts: dict[str, Any] | None = None,
) -> None:
    """Update heartbeat state after a run.

    Handles day rollover (today → recent), week rollover
    (recent → older), and notable event detection.

    Parameters
    ----------
    state:
        Mutable state dict (read via ``read_state()``).
    result:
        LLM result string, or None if the run failed.
    daily_counts:
        Optional daily run counts from SchedulerService._daily_counts
        for error tracking.
    """
    now = datetime.now(UTC)
    today = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")

    today_data = state.setdefault("today", {})
    recent: list[dict[str, Any]] = state.setdefault("recent", [])
    older: list[dict[str, Any]] = state.setdefault("older", [])
    notable: list[str] = state.setdefault("notable", [])

    # ── Day rollover: archive today → recent ─────────────────────────
    if today_data.get("date") and today_data["date"] != today:
        day_summary: dict[str, Any] = {
            "date": today_data["date"],
            "runs": today_data.get("runs", 0),
            "failed": today_data.get("failed", 0),
        }
        # Extract notable events from today's log
        events = [e for e in today_data.get("log", []) if not e.endswith("HEARTBEAT_OK")]
        if events:
            day_summary["events"] = events[:_DAY_EVENTS_MAX]
        recent.insert(0, day_summary)

        # ── Week rollover: recent[7+] → older ────────────────────────
        while len(recent) > _RECENT_DAYS_MAX:
            old_day = recent.pop()
            try:
                from datetime import date as _date

                d = _date.fromisoformat(old_day["date"])
                week_key = f"{d.isocalendar()[0]}-W{d.isocalendar()[1]:02d}"
            except (ValueError, KeyError):
                week_key = "unknown"

            week_bucket = None
            for bucket in older:
                if bucket.get("week") == week_key:
                    week_bucket = bucket
                    break
            if week_bucket is None:
                week_bucket = {"week": week_key, "runs": 0, "failed": 0}
                older.append(week_bucket)

            week_bucket["runs"] += old_day.get("runs", 0)
            week_bucket["failed"] += old_day.get("failed", 0)

        older[:] = older[-_OLDER_WEEKS_MAX:]
        today_data.clear()

    # ── Update today ──────────────────────────────────────────────────
    today_data["date"] = today
    today_data["runs"] = today_data.get("runs", 0) + 1

    is_error = result is None
    is_ok = not is_error and (not result or result.strip() in ("HEARTBEAT_OK", ""))

    if is_error:
        today_data["failed"] = today_data.get("failed", 0) + 1
        error_msg = "unknown"
        if daily_counts and daily_counts.get("last_error"):
            error_msg = daily_counts["last_error"][:100]
        today_data.setdefault("log", []).append(f"{time_str} ERROR: {error_msg}")
    elif is_ok:
        today_data.setdefault("log", []).append(f"{time_str} HEARTBEAT_OK")
    else:
        # Notable: result is not HEARTBEAT_OK — something happened
        preview = (result or "")[:200].replace("\n", " ").strip()
        today_data.setdefault("log", []).append(f"{time_str} {preview}")
        notable.append(f"{today} {preview}")

    # Cap lists
    log = today_data.get("log", [])
    if len(log) > _TODAY_LOG_MAX:
        today_data["log"] = log[-_TODAY_LOG_MAX:]
    if len(notable) > _NOTABLE_MAX:
        notable[:] = notable[-_NOTABLE_MAX:]

    write_state(state)
