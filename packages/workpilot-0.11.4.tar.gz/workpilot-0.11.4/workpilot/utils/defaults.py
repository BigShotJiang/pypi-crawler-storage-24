"""Bundled defaults loader.

Loads packaged default files (identity, config) via importlib.resources.
Works both from source checkouts and pip-installed wheels.

Naming convention:
  - ``_NAME.md`` — bundled only, not user-overridable (format templates, security)
  - ``NAME.md``  — user-overridable via ``~/.workpilot/NAME.md``
"""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path

_DEFAULT_NAMES = {
    "SOUL.md",
    "AGENTS.md",
    "TOOLS.md",
    "HEARTBEAT.md",
    "COMPACTION.md",
    "_CONSOLIDATION.md",  # bundled only — has format placeholders
    "GROUPING.md",
    "MERGE_SUMMARY.md",
    "_RECOMPRESSION.md",  # bundled only — has format placeholders
    "EXPLORER.md",
    "_SECURITY.md",  # bundled only — security scoring criteria
    "USER.md",
    "MEMORY.md",
}

# Templates that go through str.format() at their call sites.
# Each entry maps template name → set of expected placeholder keys.
#
# Rules for these templates:
#   - Placeholders use {key} syntax (Python str.format)
#   - Literal braces in JSON examples MUST be escaped as {{ / }}
#   - Values are inserted verbatim — str.format() does NOT re-scan values
#     for placeholders, so {WorkPilot_Dir} inside a value is safe
#
# Templates NOT in this dict (SOUL.md, HEARTBEAT.md, etc.)
# are loaded as raw text and MUST NOT be passed through str.format()
# — they may contain unescaped { }.
#
# Templates with no placeholders (GROUPING.md, COMPACTION.md, MERGE_SUMMARY.md)
# are pure instructions loaded as-is; data is passed as a separate user message.
FORMAT_TEMPLATES: dict[str, set[str]] = {
    "_CONSOLIDATION.md": {"existing_memory", "notable_calls", "task_context", "usage_signals"},
    "_RECOMPRESSION.md": {"total_chars", "size_summary", "worst"},
}


def load_builtin_default(name: str) -> str:
    """Return bundled default content for a known file name.

    Raises:
        ValueError: if the name is not in the allowlist.
        FileNotFoundError: if packaged data is missing.
    """
    if name not in _DEFAULT_NAMES:
        raise ValueError(f"Unsupported default: {name}")
    resource = files("workpilot.defaults").joinpath(name)
    return resource.read_text(encoding="utf-8").strip()


def load_default(name: str, *, allow_empty_override: bool = False) -> str:
    """Load a default file, preferring user override at ``~/.workpilot/``.

    Files prefixed with ``_`` are bundled-only and never overridden.
    For everything else, checks ``~/.workpilot/{name}`` first and falls
    back to the bundled default.

    Args:
        allow_empty_override: If True, an empty user file returns ``""``
            instead of falling back to the bundled default (useful for
            disabling a section by creating an empty override file).
    """
    if name not in _DEFAULT_NAMES:
        raise ValueError(f"Unsupported default: {name}")
    if not name.startswith("_"):
        user_path = Path.home() / ".workpilot" / name
        if user_path.is_file():
            content = user_path.read_text(encoding="utf-8").strip()
            if content:
                return content
            if allow_empty_override:
                return ""
    return load_builtin_default(name)
