"""Tests for linting rules."""
