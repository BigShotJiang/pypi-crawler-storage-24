class DimensionError(TypeError):
    pass
