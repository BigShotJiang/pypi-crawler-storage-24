"""Tests for DeviceRuntime base types and interface."""

from device_agent.runtime.base import (
    DeviceCapability,
    DeviceInfo,
    DeviceRuntime,
    DeviceType,
)


def test_device_type_values():
    assert DeviceType.ANDROID == "android"
    assert DeviceType.CHROMEOS == "chromeos"
    assert DeviceType.DESKTOP_LINUX == "desktop-linux"
    assert DeviceType.DESKTOP_WINDOWS == "desktop-windows"
    assert DeviceType.DESKTOP_MACOS == "desktop-macos"


def test_device_capability_values():
    assert DeviceCapability.TOUCH == "touch"
    assert DeviceCapability.KEYBOARD == "keyboard"
    assert DeviceCapability.SCREENSHOT == "screenshot"
    assert DeviceCapability.SCREEN_STREAM == "screen-stream"
    assert DeviceCapability.APP_INSTALL == "app-install"


def test_device_info_creation():
    info = DeviceInfo(
        type=DeviceType.ANDROID,
        name="Pixel 6",
        os="Android 14",
        width=1080,
        height=2400,
        capabilities=[DeviceCapability.TOUCH, DeviceCapability.SCREENSHOT],
        metadata={"serial": "ABC123"},
    )
    assert info.type == DeviceType.ANDROID
    assert info.name == "Pixel 6"
    assert info.width == 1080
    assert len(info.capabilities) == 2
    assert info.metadata["serial"] == "ABC123"


def test_device_info_default_metadata():
    info = DeviceInfo(
        type=DeviceType.DESKTOP_MACOS,
        name="MacBook",
        os="macOS 15",
        width=1920,
        height=1080,
        capabilities=[],
    )
    assert info.metadata == {}


def test_device_runtime_is_abstract():
    import pytest
    with pytest.raises(TypeError):
        DeviceRuntime()  # type: ignore[abstract]
