"""Raw PCM → aiortc AudioStreamTrack adapter.

Receives raw PCM audio data (s16le, 48 kHz, stereo) from scrcpy's
audio socket and wraps it as av.AudioFrame objects for WebRTC streaming.
"""

from __future__ import annotations

import asyncio
import fractions
import logging

import av
import numpy as np
from aiortc import MediaStreamTrack

logger = logging.getLogger(__name__)

SAMPLE_RATE = 48_000
CHANNELS = 2
FRAME_DURATION_S = 0.020  # 20 ms — standard OPUS frame
FRAME_SAMPLES = int(SAMPLE_RATE * FRAME_DURATION_S)  # 960
FRAME_BYTES = FRAME_SAMPLES * CHANNELS * 2  # 3840 (s16, stereo)
AUDIO_TIME_BASE = fractions.Fraction(1, SAMPLE_RATE)


class ScrcpyAudioTrack(MediaStreamTrack):
    """aiortc audio track fed by raw PCM from scrcpy."""

    kind = "audio"

    def __init__(self) -> None:
        super().__init__()
        self._queue: asyncio.Queue[np.ndarray] = asyncio.Queue(maxsize=50)
        self._pts = 0
        self._buf = bytearray()

    def push_pcm(self, data: bytes) -> None:
        """Buffer raw PCM and enqueue 960-sample frames."""
        self._buf.extend(data)
        while len(self._buf) >= FRAME_BYTES:
            chunk = bytes(self._buf[:FRAME_BYTES])
            del self._buf[:FRAME_BYTES]
            arr = np.frombuffer(chunk, dtype=np.int16).reshape(1, -1)
            try:
                self._queue.put_nowait(arr)
            except asyncio.QueueFull:
                # Drop oldest to stay close to real-time
                try:
                    self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
                try:
                    self._queue.put_nowait(arr)
                except asyncio.QueueFull:
                    pass

    async def recv(self) -> av.AudioFrame:
        """Called by aiortc — returns the next 20 ms audio frame."""
        try:
            arr = await asyncio.wait_for(self._queue.get(), timeout=0.04)
        except asyncio.TimeoutError:
            # Silence frame to keep the track alive
            arr = np.zeros((1, FRAME_SAMPLES * CHANNELS), dtype=np.int16)

        frame = av.AudioFrame.from_ndarray(arr, format="s16", layout="stereo")
        frame.sample_rate = SAMPLE_RATE
        frame.pts = self._pts
        frame.time_base = AUDIO_TIME_BASE
        self._pts += FRAME_SAMPLES
        return frame

    def stop(self) -> None:
        super().stop()
        self._buf.clear()
