"""Agent Gateway HTTP client with Ed25519 authentication.

Fetches platform configuration (VLM API keys, etc.) from the Agent Gateway
using the same Ed25519 signature scheme as beeos-claw TypeScript agents.

Signing format: "METHOD|PATH|timestamp|nonce"
Headers: X-Agent-Public-Key, X-Agent-Signature, X-Agent-Timestamp, X-Agent-Nonce
"""

from __future__ import annotations

import base64
import logging
import time
import uuid
from typing import Any

import aiohttp
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

logger = logging.getLogger(__name__)


def _sign_http_headers(
    method: str,
    path: str,
    private_key: bytes,
    public_key: bytes,
) -> dict[str, str]:
    """Build Ed25519 auth headers for an Agent Gateway HTTP request."""
    timestamp = str(int(time.time()))
    nonce = str(uuid.uuid4())
    message = f"{method.upper()}|{path}|{timestamp}|{nonce}"

    key = Ed25519PrivateKey.from_private_bytes(private_key)
    signature = key.sign(message.encode())

    return {
        "X-Agent-Public-Key": base64.b64encode(public_key).decode(),
        "X-Agent-Signature": base64.b64encode(signature).decode(),
        "X-Agent-Timestamp": timestamp,
        "X-Agent-Nonce": nonce,
    }


async def fetch_agent_config(
    agent_gateway_url: str,
    private_key: bytes,
    public_key: bytes,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Fetch agent config from Agent Gateway ``GET /api/v1/agent/config``.

    Returns a dict that may contain ``vlm_api_key`` and ``vlm_base_url``.
    Returns an empty dict on any failure (non-fatal).
    """
    path = "/api/v1/agent/config"
    url = agent_gateway_url.rstrip("/") + path
    headers = _sign_http_headers("GET", path, private_key, public_key)

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout)
            ) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    logger.warning(
                        "Agent Gateway config request failed (%d): %s", resp.status, body[:200]
                    )
                    return {}
                data = await resp.json()
                logger.info("Fetched agent config from Agent Gateway: %s", list(data.keys()))
                return data
    except Exception:
        logger.warning("Failed to fetch agent config from Agent Gateway", exc_info=True)
        return {}
