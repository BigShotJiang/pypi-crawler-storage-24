"""ACP session/* method handlers.

Aligned with beeos-claw ACP protocol (camelCase field names).
Session management (new/load/list/rename/delete/clear/cancel/set_mode) maintains
in-memory session state backed by SQLite for persistence across restarts.
session/prompt dispatches to the AI task engine.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from .message_store import MessageStore

logger = logging.getLogger(__name__)

StreamCallback = Callable[[dict[str, Any]], Awaitable[None]]

_MAX_SESSIONS = 50
_SESSION_TTL = 3600.0  # 1 hour


@dataclass
class Session:
    id: str
    title: str = "New chat"
    history: list[dict[str, Any]] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)


class SessionHandler:
    """Handles ACP ``session/*`` JSON-RPC methods.

    Field names use **camelCase** to match the web SDK (``acp-client.ts``).
    Uses MessageStore (SQLite) for persistent chat history.
    """

    def __init__(
        self,
        on_prompt: StreamCallback | None = None,
        max_sessions: int = _MAX_SESSIONS,
        session_ttl: float = _SESSION_TTL,
        message_store: MessageStore | None = None,
    ) -> None:
        self._on_prompt = on_prompt
        self._sessions: dict[str, Session] = {}
        self._active_session_id: str | None = None
        self._max_sessions = max_sessions
        self._session_ttl = session_ttl
        self._store = message_store

    @property
    def active_session(self) -> Session | None:
        if self._active_session_id:
            return self._sessions.get(self._active_session_id)
        return None

    @property
    def message_store(self) -> MessageStore | None:
        return self._store

    # ------------------------------------------------------------------
    # session/new
    # ------------------------------------------------------------------

    async def handle_new(self, msg: dict[str, Any]) -> dict[str, Any]:
        self._evict_expired()
        session_id = str(uuid.uuid4())
        self._sessions[session_id] = Session(id=session_id)
        self._active_session_id = session_id
        if self._store:
            self._store.upsert_session(session_id)
        return {"sessionId": session_id}

    # ------------------------------------------------------------------
    # session/load
    # ------------------------------------------------------------------

    async def handle_load(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        if not session_id:
            session_id = params.get("session_id", "")

        if session_id not in self._sessions:
            self._sessions[session_id] = Session(id=session_id)

        self._sessions[session_id].last_active = time.time()
        self._active_session_id = session_id
        if self._store:
            self._store.upsert_session(session_id)

        history: list[dict[str, Any]] = []
        if self._store:
            history = self._store.get_messages_as_dicts(session_id, limit=50)

        return {"sessionId": session_id, "history": history}

    # ------------------------------------------------------------------
    # session/list
    # ------------------------------------------------------------------

    async def handle_list(self, msg: dict[str, Any]) -> dict[str, Any]:
        self._evict_expired()
        if self._store:
            return {"sessions": self._store.list_sessions(limit=50)}
        return {
            "sessions": [
                {
                    "sessionId": s.id,
                    "title": s.title,
                    "updatedAt": int(s.last_active * 1000),
                }
                for s in self._sessions.values()
            ]
        }

    # ------------------------------------------------------------------
    # session/prompt
    # ------------------------------------------------------------------

    async def handle_prompt(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})

        prompt = params.get("prompt", "")
        if isinstance(prompt, list):
            texts = []
            for block in prompt:
                if isinstance(block, dict) and block.get("type") == "text":
                    texts.append(block.get("text", ""))
            prompt = "\n".join(texts)

        if not prompt:
            raise ValueError("prompt is required")

        session_id = params.get("sessionId", "") or params.get("session_id", "")
        if not session_id or session_id not in self._sessions:
            if not self._active_session_id or self._active_session_id not in self._sessions:
                await self.handle_new({})
            session_id = self._active_session_id

        session = self._sessions.get(session_id or "")
        if session is None:
            await self.handle_new({})
            session = self.active_session
        assert session is not None

        session.last_active = time.time()
        session.history.append({"role": "user", "content": prompt})
        self._active_session_id = session.id

        if self._store:
            self._store.add_message(session.id, "user", prompt, "text")

        if self._on_prompt:
            await self._on_prompt({"prompt": prompt, "session_id": session.id})

        return {
            "stopReason": "end_turn",
        }

    # ------------------------------------------------------------------
    # session/rename
    # ------------------------------------------------------------------

    async def handle_rename(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        title = params.get("title", "")
        session = self._sessions.get(session_id)
        if session:
            session.title = title or session.title
            session.last_active = time.time()
        if self._store and title:
            self._store.rename_session(session_id, title)
        return {"sessionId": session_id, "title": title}

    # ------------------------------------------------------------------
    # session/delete
    # ------------------------------------------------------------------

    async def handle_delete(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        deleted = session_id in self._sessions
        self._sessions.pop(session_id, None)
        if self._active_session_id == session_id:
            self._active_session_id = None
        if self._store:
            self._store.delete_session(session_id)
            deleted = True
        return {"deleted": deleted}

    # ------------------------------------------------------------------
    # session/clear
    # ------------------------------------------------------------------

    async def handle_clear(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        session = self._sessions.get(session_id)
        if session:
            session.history.clear()
            session.last_active = time.time()
        if self._store:
            self._store.clear_session(session_id)
        return {"cleared": session is not None}

    # ------------------------------------------------------------------
    # session/cancel (can be request or notification)
    # ------------------------------------------------------------------

    async def handle_cancel(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        logger.info("Session cancel requested: %s", session_id)
        return {"cancelled": True}

    # ------------------------------------------------------------------
    # session/set_mode
    # ------------------------------------------------------------------

    async def handle_set_mode(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        mode = params.get("mode", "agent")
        logger.info("Session set_mode: %s -> %s", session_id, mode)
        return {"sessionId": session_id, "mode": mode}

    # ------------------------------------------------------------------
    # session/set_model
    # ------------------------------------------------------------------

    async def handle_set_model(self, msg: dict[str, Any]) -> dict[str, Any]:
        params = msg.get("params", {})
        session_id = params.get("sessionId", "")
        model = params.get("model", "")
        logger.info("Session set_model: %s -> %s", session_id, model)
        return {"sessionId": session_id, "model": model}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _evict_expired(self) -> None:
        """Remove sessions older than TTL or exceeding max count."""
        now = time.time()
        expired = [
            sid for sid, s in self._sessions.items()
            if (now - s.last_active) > self._session_ttl
        ]
        for sid in expired:
            del self._sessions[sid]
            if self._active_session_id == sid:
                self._active_session_id = None

        if len(self._sessions) > self._max_sessions:
            by_age = sorted(self._sessions.items(), key=lambda kv: kv[1].last_active)
            for sid, _ in by_age[: len(self._sessions) - self._max_sessions]:
                del self._sessions[sid]
                if self._active_session_id == sid:
                    self._active_session_id = None
