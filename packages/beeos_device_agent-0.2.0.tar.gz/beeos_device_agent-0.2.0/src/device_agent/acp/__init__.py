"""ACP (Agent Communication Protocol) layer — JSON-RPC 2.0 control plane."""

from .router import ACPRouter

__all__ = ["ACPRouter"]
