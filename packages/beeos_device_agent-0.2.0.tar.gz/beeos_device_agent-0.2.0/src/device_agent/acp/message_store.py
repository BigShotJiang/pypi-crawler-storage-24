"""SQLite-backed message store for device-agent chat history.

Persists the last N messages per session so history survives restarts.
Aligned with beeos-claw's chat.history approach but stored locally.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_DB_PATH = Path.home() / ".beeos" / "device-agent" / "messages.db"
_MAX_MESSAGES_PER_SESSION = 500
_SCHEMA_VERSION = 1


@dataclass
class StoredMessage:
    id: int
    session_id: str
    role: str  # "user" | "assistant" | "system" | "tool"
    content: str
    message_type: str  # "text" | "tool_call" | "tool_result" | "status"
    metadata_json: str  # extra fields (tool_call_id, status, etc.)
    created_at: float


class MessageStore:
    """Synchronous SQLite message store (single-writer, safe for asyncio with run_in_executor)."""

    def __init__(
        self,
        db_path: str | Path | None = None,
        max_messages: int = _MAX_MESSAGES_PER_SESSION,
    ) -> None:
        self._db_path = Path(db_path) if db_path else _DEFAULT_DB_PATH
        self._max_messages = max_messages
        self._conn: sqlite3.Connection | None = None

    def open(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._migrate()
        logger.info("MessageStore opened: %s", self._db_path)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def _migrate(self) -> None:
        assert self._conn is not None
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS messages (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id  TEXT    NOT NULL,
                role        TEXT    NOT NULL,
                content     TEXT    NOT NULL DEFAULT '',
                msg_type    TEXT    NOT NULL DEFAULT 'text',
                metadata    TEXT    NOT NULL DEFAULT '{}',
                created_at  REAL    NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_messages_session
                ON messages(session_id, created_at);

            CREATE TABLE IF NOT EXISTS sessions (
                session_id  TEXT PRIMARY KEY,
                title       TEXT NOT NULL DEFAULT 'New chat',
                created_at  REAL NOT NULL,
                updated_at  REAL NOT NULL
            );
        """)
        self._conn.commit()

    # ------------------------------------------------------------------
    # Session CRUD
    # ------------------------------------------------------------------

    def upsert_session(self, session_id: str, title: str = "New chat") -> None:
        assert self._conn is not None
        now = time.time()
        self._conn.execute(
            """INSERT INTO sessions (session_id, title, created_at, updated_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(session_id) DO UPDATE SET updated_at=excluded.updated_at""",
            (session_id, title, now, now),
        )
        self._conn.commit()

    def rename_session(self, session_id: str, title: str) -> None:
        assert self._conn is not None
        self._conn.execute(
            "UPDATE sessions SET title=?, updated_at=? WHERE session_id=?",
            (title, time.time(), session_id),
        )
        self._conn.commit()

    def delete_session(self, session_id: str) -> None:
        assert self._conn is not None
        self._conn.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
        self._conn.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))
        self._conn.commit()

    def list_sessions(self, limit: int = 50) -> list[dict[str, Any]]:
        assert self._conn is not None
        rows = self._conn.execute(
            "SELECT session_id, title, updated_at FROM sessions ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"sessionId": r[0], "title": r[1], "updatedAt": int(r[2] * 1000)}
            for r in rows
        ]

    def clear_session(self, session_id: str) -> None:
        assert self._conn is not None
        self._conn.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
        self._conn.commit()

    # ------------------------------------------------------------------
    # Message CRUD
    # ------------------------------------------------------------------

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        msg_type: str = "text",
        metadata: dict[str, Any] | None = None,
    ) -> int:
        assert self._conn is not None
        now = time.time()
        cur = self._conn.execute(
            """INSERT INTO messages (session_id, role, content, msg_type, metadata, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (session_id, role, content, msg_type, json.dumps(metadata or {}), now),
        )
        self._conn.execute(
            "UPDATE sessions SET updated_at=? WHERE session_id=?",
            (now, session_id),
        )
        self._conn.commit()
        self._trim(session_id)
        return cur.lastrowid or 0

    def get_messages(
        self,
        session_id: str,
        limit: int | None = None,
    ) -> list[StoredMessage]:
        assert self._conn is not None
        n = limit or self._max_messages
        rows = self._conn.execute(
            """SELECT id, session_id, role, content, msg_type, metadata, created_at
               FROM messages
               WHERE session_id=?
               ORDER BY created_at DESC
               LIMIT ?""",
            (session_id, n),
        ).fetchall()
        rows.reverse()
        return [
            StoredMessage(
                id=r[0], session_id=r[1], role=r[2], content=r[3],
                message_type=r[4], metadata_json=r[5], created_at=r[6],
            )
            for r in rows
        ]

    def get_messages_as_dicts(
        self,
        session_id: str,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return messages in ACP-compatible format for session/load replay."""
        msgs = self.get_messages(session_id, limit)
        result: list[dict[str, Any]] = []
        for m in msgs:
            entry: dict[str, Any] = {
                "role": m.role,
                "content": m.content,
                "type": m.message_type,
                "createdAt": int(m.created_at * 1000),
            }
            if m.metadata_json and m.metadata_json != "{}":
                try:
                    entry["metadata"] = json.loads(m.metadata_json)
                except json.JSONDecodeError:
                    pass
            result.append(entry)
        return result

    def _trim(self, session_id: str) -> None:
        """Keep only the most recent max_messages per session."""
        assert self._conn is not None
        count = self._conn.execute(
            "SELECT COUNT(*) FROM messages WHERE session_id=?", (session_id,)
        ).fetchone()[0]
        if count > self._max_messages:
            excess = count - self._max_messages
            self._conn.execute(
                """DELETE FROM messages WHERE id IN (
                       SELECT id FROM messages WHERE session_id=?
                       ORDER BY created_at ASC LIMIT ?
                   )""",
                (session_id, excess),
            )
            self._conn.commit()
