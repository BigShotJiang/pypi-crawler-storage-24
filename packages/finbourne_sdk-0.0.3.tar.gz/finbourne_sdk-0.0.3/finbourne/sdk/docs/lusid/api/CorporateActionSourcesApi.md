# lusid.CorporateActionSourcesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**batch_upsert_corporate_actions**](CorporateActionSourcesApi.md#batch_upsert_corporate_actions) | **POST** /api/api/corporateactionsources/{scope}/{code}/corporateactions | [EARLY ACCESS] BatchUpsertCorporateActions: Batch upsert corporate actions (instrument transition events) to corporate action source.
[**create_corporate_action_source**](CorporateActionSourcesApi.md#create_corporate_action_source) | **POST** /api/api/corporateactionsources | [EARLY ACCESS] CreateCorporateActionSource: Create corporate action source
[**delete_corporate_action_source**](CorporateActionSourcesApi.md#delete_corporate_action_source) | **DELETE** /api/api/corporateactionsources/{scope}/{code} | [EARLY ACCESS] DeleteCorporateActionSource: Delete a corporate action source
[**delete_corporate_actions**](CorporateActionSourcesApi.md#delete_corporate_actions) | **DELETE** /api/api/corporateactionsources/{scope}/{code}/corporateactions | [EARLY ACCESS] DeleteCorporateActions: Delete corporate actions (instrument transition events) from a corporate action source
[**delete_instrument_events**](CorporateActionSourcesApi.md#delete_instrument_events) | **DELETE** /api/api/corporateactionsources/{scope}/{code}/instrumentevents | [EARLY ACCESS] DeleteInstrumentEvents: Delete instrument events from a corporate action source
[**get_corporate_actions**](CorporateActionSourcesApi.md#get_corporate_actions) | **GET** /api/api/corporateactionsources/{scope}/{code}/corporateactions | [EARLY ACCESS] GetCorporateActions: List corporate actions (instrument transition events) from the corporate action source.
[**get_instrument_events**](CorporateActionSourcesApi.md#get_instrument_events) | **GET** /api/api/corporateactionsources/{scope}/{code}/instrumentevents | [EARLY ACCESS] GetInstrumentEvents: Get extrinsic instrument events out of a given corporate actions source.
[**list_corporate_action_sources**](CorporateActionSourcesApi.md#list_corporate_action_sources) | **GET** /api/api/corporateactionsources | [EARLY ACCESS] ListCorporateActionSources: List corporate action sources
[**upsert_instrument_events**](CorporateActionSourcesApi.md#upsert_instrument_events) | **POST** /api/api/corporateactionsources/{scope}/{code}/instrumentevents | [EARLY ACCESS] UpsertInstrumentEvents: Upsert instrument events to the provided corporate actions source.


### Example

```python
from finbourne.sdk.exceptions import ApiException
from finbourne.sdk.extensions.configuration_options import ConfigurationOptions
from finbourne.sdk.services.lusid.models import *

from finbourne.sdk.extensions import (
  SyncApiClientFactory
)

from finbourne.sdk.services.lusid.api.corporate_action_sources_api import CorporateActionSourcesApi

# opts = ConfigurationOptions()
# opts.total_timeout_ms = 30_000

# uncomment the below to use an api client factory with overrides
# api_client_factory = SyncApiClientFactory(opts=opts)

api_client_factory = SyncApiClientFactory()
api_instance = api_client_factory.build(CorporateActionSourcesApi)
```

---

# **batch_upsert_corporate_actions**
> UpsertCorporateActionsResponse batchUpsertCorporateActions = batch_upsert_corporate_actions(scope, code, upsert_corporate_action_request=upsert_corporate_action_request)

[EARLY ACCESS] BatchUpsertCorporateActions: Batch upsert corporate actions (instrument transition events) to corporate action source.

Create or update one or more corporate actions in a particular corporate action source. Failures are identified in the body of the response.                If a corporate action is upserted at exactly the same effective datetime as a transaction for the same instrument, the corporate action takes precedence. Depending on the nature of the corporate action, this may mean it affects the transaction.                The maximum number of corporate actions that this method can upsert per request is 10,000.

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
upsert_corporate_action_request = [{"corporateActionCode":"MyStockSplitId","description":"2-for-1 stock split of instrument BBG001S6PJ31","announcementDate":"2018-03-01T00:00:00.0000000+00:00","exDate":"2018-06-01T00:00:00.0000000+00:00","recordDate":"2018-06-02T00:00:00.0000000+00:00","paymentDate":"2018-08-02T00:00:00.0000000+00:00","transitions":[{"inputTransition":{"instrumentIdentifiers":{"Instrument/default/Figi":"BBG001S6PJ31"},"unitsFactor":1.0,"costFactor":1.0},"outputTransitions":[{"instrumentIdentifiers":{"Instrument/default/Figi":"BBG001S6PJ31"},"unitsFactor":2.0,"costFactor":1.0}]}]}] # List[UpsertCorporateActionRequest] (optional)
api_response = api_instance.batch_upsert_corporate_actions(scope, code, upsert_corporate_action_request=upsert_corporate_action_request)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of corporate action source | [required] 
 **code** | **str**| The code of the corporate action source | [required] 
 **upsert_corporate_action_request** | [**List[UpsertCorporateActionRequest]**](UpsertCorporateActionRequest.md)| The corporate action definitions | [optional] 

### Return type

[**UpsertCorporateActionsResponse**](UpsertCorporateActionsResponse.md)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/*+json
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | The created corporate actions |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **create_corporate_action_source**
> CorporateActionSource createCorporateActionSource = create_corporate_action_source(create_corporate_action_source_request)

[EARLY ACCESS] CreateCorporateActionSource: Create corporate action source

Create a corporate action source.

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
create_corporate_action_source_request = CreateCorporateActionSourceRequest()
api_response = api_instance.create_corporate_action_source(create_corporate_action_source_request)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **create_corporate_action_source_request** | [**CreateCorporateActionSourceRequest**](CreateCorporateActionSourceRequest.md)| The corporate action source definition | [required] 

### Return type

[**CorporateActionSource**](CorporateActionSource.md)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/*+json
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | The created corporate action source |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **delete_corporate_action_source**
> DeletedEntityResponse deleteCorporateActionSource = delete_corporate_action_source(scope, code)

[EARLY ACCESS] DeleteCorporateActionSource: Delete a corporate action source

Deletes a single corporate action source

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
api_response = api_instance.delete_corporate_action_source(scope, code)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of the corporate action source to be deleted | [required] 
 **code** | **str**| The code of the corporate action source to be deleted | [required] 

### Return type

[**DeletedEntityResponse**](DeletedEntityResponse.md)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Corporate Action Source Deleted |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **delete_corporate_actions**
> DeletedEntityResponse deleteCorporateActions = delete_corporate_actions(scope, code, corporate_action_ids)

[EARLY ACCESS] DeleteCorporateActions: Delete corporate actions (instrument transition events) from a corporate action source

Delete one or more corporate actions from a particular corporate action source.                The maximum number of corporate actions that this method can delete per request is 1,000.

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
corporate_action_ids = ['corporate_action_ids_example'] # List[str]
api_response = api_instance.delete_corporate_actions(scope, code, corporate_action_ids)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of the corporate action source | [required] 
 **code** | **str**| The code of the corporate action source | [required] 
 **corporate_action_ids** | [**List[str]**](str.md)| The IDs of the corporate actions to delete | [required] 

### Return type

[**DeletedEntityResponse**](DeletedEntityResponse.md)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Corporate Actions Deleted |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **delete_instrument_events**
> DeletedEntityResponse deleteInstrumentEvents = delete_instrument_events(scope, code, instrument_event_ids)

[EARLY ACCESS] DeleteInstrumentEvents: Delete instrument events from a corporate action source

Delete one or more corporate actions from a particular corporate action source.                The maximum number of instrument events that this method can delete per request is 1,000.

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
instrument_event_ids = ['instrument_event_ids_example'] # List[str]
api_response = api_instance.delete_instrument_events(scope, code, instrument_event_ids)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of the corporate action source | [required] 
 **code** | **str**| The code of the corporate action source | [required] 
 **instrument_event_ids** | [**List[str]**](str.md)| The IDs of the instrument events to delete | [required] 

### Return type

[**DeletedEntityResponse**](DeletedEntityResponse.md)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Instrument Events Deleted |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **get_corporate_actions**
> ResourceListOfCorporateAction getCorporateActions = get_corporate_actions(scope, code, from_effective_at=from_effective_at, to_effective_at=to_effective_at, as_at=as_at, sort_by=sort_by, limit=limit, filter=filter)

[EARLY ACCESS] GetCorporateActions: List corporate actions (instrument transition events) from the corporate action source.

Get corporate actions from a particular corporate action source.

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
from_effective_at = 'from_effective_at_example' # str (optional)
to_effective_at = 'to_effective_at_example' # str (optional)
as_at = '2013-10-20T19:20:30+01:00' # datetime (optional)
sort_by = ['sort_by_example'] # List[str] (optional)
limit = 56 # int (optional)
filter = 'filter_example' # str (optional)
api_response = api_instance.get_corporate_actions(scope, code, from_effective_at=from_effective_at, to_effective_at=to_effective_at, as_at=as_at, sort_by=sort_by, limit=limit, filter=filter)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of the corporate action source. | [required] 
 **code** | **str**| The code of the corporate action source. | [required] 
 **from_effective_at** | **str**| Optional. The start effective date of the data range. | [optional] 
 **to_effective_at** | **str**| Optional. The end effective date of the data range. | [optional] 
 **as_at** | **datetime**| Optional. The AsAt date of the data. | [optional] 
 **sort_by** | [**List[str]**](str.md)| Optional. Order the results by these fields. Use use the &#39;-&#39; sign to denote descending order e.g. -MyFieldName | [optional] 
 **limit** | **int**| Optional. When paginating, limit the results to this number. | [optional] 
 **filter** | **str**| Optional. Expression to filter the result set.              For example, to filter on the Announcement Date, use \&quot;announcementDate eq &#39;2020-03-06&#39;\&quot;              Read more about filtering results from LUSID here https://support.lusid.com/filtering-results-from-lusid. | [optional] 

### Return type

[**ResourceListOfCorporateAction**](ResourceListOfCorporateAction.md)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Corporate Actions |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **get_instrument_events**
> PagedResourceListOfInstrumentEventHolder getInstrumentEvents = get_instrument_events(scope, code, as_at=as_at, limit=limit, page=page, filter=filter, timeline_scope=timeline_scope, timeline_code=timeline_code, closed_period_id=closed_period_id)

[EARLY ACCESS] GetInstrumentEvents: Get extrinsic instrument events out of a given corporate actions source.

Retrieves extrinsic corporate actions out of a corporate actions source

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
as_at = '2013-10-20T19:20:30+01:00' # datetime (optional)
limit = 1000 # int (optional)
page = 'page_example' # str (optional)
filter = 'filter_example' # str (optional)
timeline_scope = 'timeline_scope_example' # str (optional)
timeline_code = 'timeline_code_example' # str (optional)
closed_period_id = 'closed_period_id_example' # str (optional)
api_response = api_instance.get_instrument_events(scope, code, as_at=as_at, limit=limit, page=page, filter=filter, timeline_scope=timeline_scope, timeline_code=timeline_code, closed_period_id=closed_period_id)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of the corporate action source. | [required] 
 **code** | **str**| The code of the corporate action source. | [required] 
 **as_at** | **datetime**| Optional. The AsAt date of the data. | [optional] 
 **limit** | **int**| Optional. When paginating, limit the number of returned results to this many. If not specified, a default  of 1000 is used. | [optional] [default to 1000]
 **page** | **str**| Optional. The pagination token to use to continue listing items from a previous call. Page values are  return from list calls, and must be supplied exactly as returned. Additionally, when specifying this  value, asAt, filter and limit must not  be modified. | [optional] 
 **filter** | **str**| Optional. Expression to filter the result set. | [optional] 
 **timeline_scope** | **str**| The scope of the Timeline, used to override the AsAt, and fetch post close activity data.              If this is provided, timelineCode and closedPeriodId must also be provided. | [optional] 
 **timeline_code** | **str**| The code of the Timeline, used to override the AsAt, and fetch post close activity data.              If this is provided, timelineScope and closedPeriodId must also be provided. | [optional] 
 **closed_period_id** | **str**| The code of the ClosedPeriod attached to the timeline, used to override the AsAt, and fetch post close activity data.              If this is provided, timelineScope and timelineCode must also be provided. | [optional] 

### Return type

[**PagedResourceListOfInstrumentEventHolder**](PagedResourceListOfInstrumentEventHolder.md)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Instrument Events |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **list_corporate_action_sources**
> PagedResourceListOfCorporateActionSource listCorporateActionSources = list_corporate_action_sources(as_at=as_at, sort_by=sort_by, limit=limit, filter=filter, page=page)

[EARLY ACCESS] ListCorporateActionSources: List corporate action sources

Gets a list of all corporate action sources

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
as_at = '2013-10-20T19:20:30+01:00' # datetime (optional)
sort_by = ['sort_by_example'] # List[str] (optional)
limit = 100 # int (optional)
filter = 'filter_example' # str (optional)
page = 'page_example' # str (optional)
api_response = api_instance.list_corporate_action_sources(as_at=as_at, sort_by=sort_by, limit=limit, filter=filter, page=page)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **as_at** | **datetime**| Optional. The AsAt date of the data | [optional] 
 **sort_by** | [**List[str]**](str.md)| Optional. Order the results by these fields. Use use the &#39;-&#39; sign to denote descending order e.g. -MyFieldName | [optional] 
 **limit** | **int**| Optional. When paginating, limit the number of returned results to this many. If not specified, a default  of 100 is used. | [optional] [default to 100]
 **filter** | **str**| Optional. Expression to filter the result set. For example, to  filter on the Display Name, use \&quot;displayName eq &#39;string&#39;\&quot;  Read more about filtering results from LUSID here https://support.lusid.com/filtering-results-from-lusid. | [optional] 
 **page** | **str**| Optional. The pagination token to use to continue listing items from a previous call. Page values are  return from list calls, and must be supplied exactly as returned. Additionally, when specifying this  value, the filter, asAt, and limit must not  be modified. | [optional] 

### Return type

[**PagedResourceListOfCorporateActionSource**](PagedResourceListOfCorporateActionSource.md)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | All Existing Corporate Action Sources |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

---

# **upsert_instrument_events**
> UpsertInstrumentEventsResponse upsertInstrumentEvents = upsert_instrument_events(scope, code, upsert_instrument_event_request=upsert_instrument_event_request)

[EARLY ACCESS] UpsertInstrumentEvents: Upsert instrument events to the provided corporate actions source.

Batch upsert instrument events to corporate action sources.                The maximum number of instrument events that this method can upsert per request is 10,000.

### Example

```python
api_instance = api_client_factory.build(CorporateActionSourcesApi)
scope = 'scope_example' # str
code = 'code_example' # str
upsert_instrument_event_request = [{"instrumentEventId":"MyStockSplitId","instrumentIdentifiers":{"Instrument/default/Figi":"BBG001S6PJ31"},"description":"2-for-1 stock split of instrument BBG001S6PJ31","instrumentEvent":{"announcementDate":"2018-03-01T00:00:00+00:00","exDate":"2018-06-01T00:00:00+00:00","recordDate":"2018-06-02T00:00:00+00:00","paymentDate":"2018-08-02T00:00:00+00:00","inputTransition":{"unitsFactor":1.0,"costFactor":1.0},"outputTransitions":[{"instrumentIdentifiers":{"Instrument/default/Figi":"BBG001S6PJ31"},"unitsFactor":2.0,"costFactor":1.0,"rounding":{"stockUnits":{"roundingType":"NearestRoundHalfAwayFromZero"}}}],"instrumentEventType":"TransitionEvent"},"properties":[],"sequenceNumber":0,"participationType":"thing"}] # List[UpsertInstrumentEventRequest] (optional)
api_response = api_instance.upsert_instrument_events(scope, code, upsert_instrument_event_request=upsert_instrument_event_request)
pprint(api_response)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **str**| The scope of the corporate action source. | [required] 
 **code** | **str**| The code of the corporate action source. | [required] 
 **upsert_instrument_event_request** | [**List[UpsertInstrumentEventRequest]**](UpsertInstrumentEventRequest.md)| The instrument event definitions. | [optional] 

### Return type

[**UpsertInstrumentEventsResponse**](UpsertInstrumentEventsResponse.md)

### HTTP request headers

 - **Content-Type**: application/json-patch+json, application/json, text/json, application/*+json
 - **Accept**: text/plain, application/json, text/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**201** | Instrument Events Upserted |  -  |
**400** | The details of the input related failure |  -  |
**0** | Error response |  -  |

[Back to top](#) · [Back to API list](../../api_endpoints.md) · [Back to Model list](../../models.md) · [Back to README](../../../README.md)

