"""NATS entrypoint package."""
