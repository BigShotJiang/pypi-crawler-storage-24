# agent-cultivation

> Agent Cultivation -- Structured growth and training paths for AI Agents.

Part of the [TianGong](https://github.com/JinNing6/TianGong) ecosystem.

## Status

Planning -- This package is under active development. Stay tuned!

## License

MIT
