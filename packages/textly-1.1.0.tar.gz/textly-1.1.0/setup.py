from setuptools import setup
from io import open

setup(
    name="textly",
    packages=["textly"],
    version="1.1.0",
    description="Text Analytics - Calculate statistical features from text",
    author="Raja CSP Raman",
    author_email="raja.csp@gmail.com",
    url="https://github.com/rajacsp/textly",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    package_data={
        "": [
            "resources/en/easy_words.txt",
            "resources/en/custom_dict.json",
            "resources/en/cmudict.dict",
        ]
    },
    include_package_data=True,
    install_requires=["appdirs"],
    license="MIT",
    python_requires=">=3.10",
    project_urls={
        "Documentation": "https://github.com/rajacsp/textly",
    },
    classifiers=[
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3 :: Only",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "Topic :: Text Processing",
    ],
)
