"""
textly — Text Analytics for Python.

Computes readability scores, grade levels, and text complexity metrics
for English text. Tuned for scientific and technical writing.
"""

import math
import re
import warnings
from collections import Counter
from functools import lru_cache, wraps
from typing import Union, Dict, List, Set, Optional

from importlib.resources import files

from .dictionary_utils import (
    add_term_to_custom_dict,
    add_terms_from_file,
    load_custom_syllable_dict,
    overwrite_custom_dict,
    print_custom_dict,
    revert_custom_dict_to_default,
)

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------
_round_outputs: bool = False
_round_points: Optional[int] = None
_rm_apostrophe: bool = False
_TEXT_ENCODING = "utf-8"

# ---------------------------------------------------------------------------
# Formula coefficients (named constants — no magic numbers)
# ---------------------------------------------------------------------------
# Flesch Reading Ease
_FRE_BASE = 206.835
_FRE_ASL_COEFF = 1.015
_FRE_ASW_COEFF = 84.6

# Flesch-Kincaid Grade
_FK_ASL_COEFF = 0.39
_FK_ASW_COEFF = 11.8
_FK_INTERCEPT = 15.59

# Coleman-Liau
_CL_LETTER_COEFF = 0.0588
_CL_SENTENCE_COEFF = 0.296
_CL_INTERCEPT = 15.8

# Automated Readability Index
_ARI_CHAR_COEFF = 4.71
_ARI_WORD_COEFF = 0.5
_ARI_INTERCEPT = 21.43

# SMOG
_SMOG_COEFF = 1.043
_SMOG_SENTENCE_NORM = 30
_SMOG_INTERCEPT = 3.1291

# Dale-Chall
_DC_PDW_COEFF = 0.1579
_DC_ASL_COEFF = 0.0496
_DC_ADJUSTMENT = 3.6365
_DC_PDW_THRESHOLD = 5

# Gunning Fog
_GF_COEFF = 0.4

# SPACHE
_SPACHE_ASL_COEFF = 0.141
_SPACHE_PDW_COEFF = 0.086
_SPACHE_INTERCEPT = 0.839

# FORCAST
_FORCAST_BASE = 20.0
_FORCAST_DIVISOR = 10.0
_FORCAST_SAMPLE_SIZE = 150

# Linsear Write
_LINSEAR_SAMPLE_SIZE = 100
_LINSEAR_DIFFICULT_WEIGHT = 3
_LINSEAR_THRESHOLD = 20

# LIX / RIX long-word threshold
_LONG_WORD_MIN_LENGTH = 6

# Syllable threshold for polysyllabic words
_POLYSYLLABLE_THRESHOLD = 3

# Flesch Reading Ease → grade mapping
_FRE_GRADE_MAP = [
    (90, 100, [5]),
    (80, 90, [6]),
    (70, 80, [7]),
    (60, 70, [8, 9]),
    (50, 60, [10]),
    (40, 50, [11]),
    (30, 40, [12]),
]
_FRE_DEFAULT_GRADE = 13

# ---------------------------------------------------------------------------
# Regular expressions (compiled once)
# ---------------------------------------------------------------------------
_VOWEL_RUNS = re.compile(r"[aeiouy]+", flags=re.I)
_EXCEPTIONS = re.compile(r"[^aeiou]e[sd]?$|[^e]ely$", flags=re.I)
_ADDITIONAL = re.compile(
    r"[^aeioulr][lr]e[sd]?$|[csgz]es$|[td]ed$|"
    r".y[aeiou]|ia(?!n$)|eo|ism$|[^aeiou]ire$|[^gq]ua|"
    r"[^aeiouy][bcdfgjklmnpqrstvwxyz]le$|"
    r"ian$|^bio",
    flags=re.I,
)
_SENTENCE_SPLIT = re.compile(r"\b[^.!?]+[.!?]*", re.UNICODE)

# Species-name suffix → extra syllable adjustment
_SPECIES_SUFFIX_ADJUSTMENTS = {
    "ii": 1,
    "odes": 1,
    "eae": 1,
    "oides": 1,
    "mallei": 1,
}


# ---------------------------------------------------------------------------
# Internal helpers and decorators
# ---------------------------------------------------------------------------
def _handle_zero_division(func):
    """Decorator: returns 0.0 on ZeroDivisionError."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ZeroDivisionError:
            return 0.0

    return wrapper


def _is_empty(text: str) -> bool:
    """Returns True if text is empty or whitespace-only."""
    return not text or not text.strip()


def _guard_empty_text(default=0.0):
    """Decorator factory: returns *default* when text is empty or has no words.

    Expects the decorated function's first positional arg to be ``text``.
    """

    def decorator(func):
        @wraps(func)
        def wrapper(text, *args, **kwargs):
            if _is_empty(text) or lexicon_count(text) == 0:
                return default
            return func(text, *args, **kwargs)

        return wrapper

    return decorator


def _apply_rounding(
    number: float,
    rounding: Optional[bool] = None,
    points: Optional[int] = None,
    default_points: int = 2,
) -> float:
    """Applies rounding based on per-call or global settings.

    Args:
        number: The raw score to (optionally) round.
        rounding: Per-call override; ``None`` defers to the global setting.
        points: Per-call decimal places; ``None`` defers to the global setting.
        default_points: Fallback decimal places when nothing else is set.

    Returns:
        The score, rounded or not.
    """
    should_round = rounding if rounding is not None else _round_outputs
    decimal_places = points if points is not None else _round_points

    if should_round:
        dp = decimal_places if decimal_places is not None else default_points
        factor = 10 ** dp
        return float(math.floor((number * factor) + math.copysign(0.5, number))) / factor
    return number


def _get_grade_suffix(grade: int) -> str:
    """Returns the ordinal suffix for a grade number (1→'st', 2→'nd', …)."""
    if grade % 100 in (11, 12, 13):
        return "th"
    return {1: "st", 2: "nd", 3: "rd"}.get(grade % 10, "th")


# ---------------------------------------------------------------------------
# Resource loaders
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _load_cmu_dict() -> Dict[str, List[List[str]]]:
    """Loads the CMU Pronouncing Dictionary from package resources.

    Returns:
        Mapping of lowercase word → list of pronunciations (each a list of phones).
    """
    pronouncing_dict: Dict[str, List[List[str]]] = {}
    cmu_text = files("textly").joinpath("resources/en/cmudict.dict").read_text("utf-8")
    for line in cmu_text.splitlines():
        if line.startswith(";;;"):
            continue
        parts = line.split()
        if len(parts) <= 1:
            continue
        word = re.sub(r"\(\d+\)$", "", parts[0]).lower()
        pronouncing_dict.setdefault(word, []).append(parts[1:])
    return pronouncing_dict


@lru_cache(maxsize=1)
def _get_easy_words() -> Set[str]:
    """Loads the Dale–Chall easy-word list from package resources."""
    try:
        raw = files("textly").joinpath("resources/en/easy_words.txt").read_bytes()
        return {ln.decode("utf-8").strip() for ln in raw.splitlines()}
    except FileNotFoundError:
        warnings.warn("Could not find the easy words vocabulary file.", Warning)
        return set()


# ---------------------------------------------------------------------------
# Module initialisation
# ---------------------------------------------------------------------------
custom_dict = load_custom_syllable_dict()
cmu_pronouncing_dict = _load_cmu_dict()


# ---------------------------------------------------------------------------
# Public API — configuration
# ---------------------------------------------------------------------------
def set_rounding(rounding: bool, points: Optional[int] = None) -> None:
    """Sets the global rounding behaviour for all readability scores.

    Args:
        rounding: Enable or disable rounding globally.
        points: Number of decimal places (``None`` lets each formula choose its default).
    """
    global _round_outputs, _round_points
    _round_outputs = rounding
    _round_points = points


def set_rm_apostrophe(rm_apostrophe: bool) -> None:
    """Controls whether apostrophes are stripped during punctuation removal.

    Args:
        rm_apostrophe: ``True`` strips all apostrophes; ``False`` (default)
            preserves contractions like *don't* and *it's*.
    """
    global _rm_apostrophe
    _rm_apostrophe = rm_apostrophe
    _cache_clear()


def _cache_clear() -> None:
    """Clears every LRU cache in this module."""
    _cached_functions = [
        _load_cmu_dict, _get_easy_words,
        char_count, letter_count, lexicon_count, miniword_count,
        syllable_count, sentence_count,
        avg_sentence_length, avg_syllables_per_word,
        avg_character_per_word, avg_letter_per_word,
        avg_sentence_per_word, words_per_sentence,
    ]
    for fn in _cached_functions:
        if hasattr(fn, "cache_clear"):
            fn.cache_clear()


# ---------------------------------------------------------------------------
# Public API — dictionary management
# ---------------------------------------------------------------------------
def add_word_to_dictionary(word: str, syll_count: int) -> None:
    """Adds a single word and its syllable count to the custom dictionary."""
    global custom_dict
    add_term_to_custom_dict(word, syll_count)
    custom_dict = load_custom_syllable_dict()
    _cache_clear()


def add_words_from_file_to_dictionary(file_path: str) -> None:
    """Merges words from a JSON file into the custom dictionary."""
    global custom_dict
    add_terms_from_file(file_path)
    custom_dict = load_custom_syllable_dict()
    _cache_clear()


def overwrite_dictionary(file_path: str) -> None:
    """Replaces the entire custom dictionary with the contents of a JSON file."""
    global custom_dict
    overwrite_custom_dict(file_path)
    custom_dict = load_custom_syllable_dict()
    _cache_clear()


def revert_dictionary_to_default() -> None:
    """Restores the custom dictionary to the package default."""
    global custom_dict
    revert_custom_dict_to_default()
    custom_dict = load_custom_syllable_dict()
    _cache_clear()


def print_dictionary() -> None:
    """Prints the current custom dictionary to stdout."""
    print_custom_dict()


# ---------------------------------------------------------------------------
# Core text statistics
# ---------------------------------------------------------------------------
@lru_cache(maxsize=128)
def char_count(text: str, ignore_spaces: bool = True) -> int:
    """Counts characters in *text* (ignoring whitespace by default)."""
    if ignore_spaces:
        text = re.sub(r"\s", "", text)
    return len(text)


@lru_cache(maxsize=128)
def letter_count(text: str, ignore_spaces: bool = True) -> int:
    """Counts alphabetic characters (A–Z, a–z) in *text*."""
    if ignore_spaces:
        text = re.sub(r"\s", "", text)
    return sum(1 for ch in text if ch.isalpha())


def remove_punctuation(text: str) -> str:
    """Strips punctuation from *text*, respecting the apostrophe setting."""
    if _rm_apostrophe:
        return re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\'(?![tsd]\b|ve\b|ll\b|re\b)", '"', text)
    return re.sub(r"[^\w\s\']", "", text)


@lru_cache(maxsize=128)
def lexicon_count(text: str, removepunct: bool = True) -> int:
    """Counts words (tokens) in *text*."""
    if removepunct:
        text = remove_punctuation(text)
    return len(text.split())


@lru_cache(maxsize=128)
def miniword_count(text: str, max_size: int = 3) -> int:
    """Counts words with *max_size* letters or fewer."""
    return sum(1 for w in remove_punctuation(text).split() if len(w) <= max_size)


@lru_cache(maxsize=128)
def syllable_count(text: str) -> int:
    """Counts total syllables using CMUdict → custom dict → regex fallback.

    Args:
        text: A word, phrase, or full document.

    Returns:
        Total syllable count across all tokens.
    """
    if isinstance(text, bytes):
        text = text.decode(_TEXT_ENCODING)

    text = remove_punctuation(text.lower())
    if not text:
        return 0

    total = 0
    for word in text.split():
        # 1. Custom dictionary (highest priority)
        if word in custom_dict:
            total += custom_dict[word]
            continue

        # 2. CMU Pronouncing Dictionary
        if word in cmu_pronouncing_dict:
            try:
                pronunciations = cmu_pronouncing_dict[word]
                total += min(
                    sum(1 for phone in pron if phone[-1].isdigit())
                    for pron in pronunciations
                )
                continue
            except (TypeError, IndexError, ValueError):
                pass  # fall through to regex

        # 3. Regex fallback with species-name adjustment
        count = _regex_syllable_count(word)
        for suffix, adjustment in _SPECIES_SUFFIX_ADJUSTMENTS.items():
            if word.endswith(suffix):
                count += adjustment
                break
        total += count

    return total


def _regex_syllable_count(word: str) -> int:
    """Heuristic syllable counter based on vowel-run patterns.

    Reference: https://datascience.stackexchange.com/a/89312
    """
    vowel_runs = len(_VOWEL_RUNS.findall(word))
    exceptions = len(_EXCEPTIONS.findall(word))
    additional = len(_ADDITIONAL.findall(word))
    return max(1, vowel_runs - exceptions + additional)


@lru_cache(maxsize=128)
def sentence_count(text: str) -> int:
    """Counts sentences in *text* (ignoring fragments of ≤2 words)."""
    sentences = _SENTENCE_SPLIT.findall(text)
    fragments = sum(1 for s in sentences if lexicon_count(s) <= 2)
    return max(1, len(sentences) - fragments)


# ---------------------------------------------------------------------------
# Averaged text statistics
# ---------------------------------------------------------------------------
@lru_cache(maxsize=128)
@_handle_zero_division
def avg_sentence_length(text: str) -> float:
    """Average number of words per sentence."""
    return float(lexicon_count(text) / sentence_count(text))


@lru_cache(maxsize=128)
@_handle_zero_division
def avg_syllables_per_word(text: str) -> float:
    """Average syllables per word."""
    return float(syllable_count(text)) / float(lexicon_count(text))


@lru_cache(maxsize=128)
@_handle_zero_division
def avg_character_per_word(text: str) -> float:
    """Average characters per word."""
    return float(char_count(text)) / float(lexicon_count(text))


@lru_cache(maxsize=128)
@_handle_zero_division
def avg_letter_per_word(text: str) -> float:
    """Average letters (alphabetic only) per word."""
    return float(letter_count(text)) / float(lexicon_count(text))


@lru_cache(maxsize=128)
@_handle_zero_division
def avg_sentence_per_word(text: str) -> float:
    """Sentences per word (inverse of avg_sentence_length)."""
    return float(sentence_count(text)) / float(lexicon_count(text))


@lru_cache(maxsize=128)
def words_per_sentence(text: str) -> float:
    """Average words per sentence (alias used internally by ARI)."""
    sc = sentence_count(text)
    return float(lexicon_count(text) / sc) if sc >= 1 else float(lexicon_count(text))


# ---------------------------------------------------------------------------
# Readability formulas
# ---------------------------------------------------------------------------
@_guard_empty_text(default=0.0)
def flesch_reading_ease(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Flesch Reading Ease score.

    Higher values indicate easier text (range roughly −∞ to ~121).

    Formula::

        206.835 − 1.015 × ASL − 84.6 × ASW

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        The Flesch Reading Ease score.
    """
    asl = avg_sentence_length(text)
    asw = avg_syllables_per_word(text)
    score = _FRE_BASE - (_FRE_ASL_COEFF * asl) - (_FRE_ASW_COEFF * asw)
    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
def flesch_kincaid_grade(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Flesch–Kincaid Grade Level.

    Estimates the U.S. school grade needed to understand the text.

    Formula::

        0.39 × ASL + 11.8 × ASW − 15.59

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 1 when rounding is on).

    Returns:
        Estimated grade level.
    """
    asl = avg_sentence_length(text)
    asw = avg_syllables_per_word(text)
    score = (_FK_ASL_COEFF * asl) + (_FK_ASW_COEFF * asw) - _FK_INTERCEPT
    return _apply_rounding(score, rounding, points, default_points=1)


@_guard_empty_text(default=0.0)
def smog_index(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """SMOG Index (Simple Measure of Gobbledygook).

    Most reliable with ~30 sentences. Returns 0.0 if fewer than 3 sentences.

    Formula::

        1.043 × √(30 × polysyllables / sentences) + 3.1291

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 1 when rounding is on).

    Returns:
        SMOG grade level, or 0.0 for very short texts.
    """
    sentences = sentence_count(text)
    if sentences < 3:
        return 0.0

    poly = polysyllabcount(text)
    score = (_SMOG_COEFF * math.sqrt(_SMOG_SENTENCE_NORM * poly / sentences)) + _SMOG_INTERCEPT
    return _apply_rounding(score, rounding, points, default_points=1)


@_guard_empty_text(default=0.0)
def coleman_liau_index(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Coleman–Liau Index.

    Uses letters-per-word and sentences-per-word (no syllable counting).

    Formula::

        0.0588 × L − 0.296 × S − 15.8

    where L = avg letters per 100 words, S = avg sentences per 100 words.

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        Estimated grade level.
    """
    letters_per_100 = avg_letter_per_word(text) * 100
    sentences_per_100 = avg_sentence_per_word(text) * 100
    score = (_CL_LETTER_COEFF * letters_per_100) - (_CL_SENTENCE_COEFF * sentences_per_100) - _CL_INTERCEPT
    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def automated_readability_index(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Automated Readability Index (ARI).

    Formula::

        4.71 × (chars/word) + 0.5 × (words/sentence) − 21.43

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 1 when rounding is on).

    Returns:
        Estimated grade level.
    """
    score = (_ARI_CHAR_COEFF * avg_character_per_word(text)) + (_ARI_WORD_COEFF * words_per_sentence(text)) - _ARI_INTERCEPT
    return _apply_rounding(score, rounding, points, default_points=1)


def linsear_write_formula(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Linsear Write Formula.

    Analyses the first 100 words, classifying each as easy (<3 syllables)
    or difficult (≥3 syllables).

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        Grade level estimate, or −1.0 for empty/unparseable text.
    """
    if _is_empty(text):
        return -1.0

    sample_words = text.split()[:_LINSEAR_SAMPLE_SIZE]
    easy = sum(1 for w in sample_words if syllable_count(w) < _POLYSYLLABLE_THRESHOLD)
    difficult = len(sample_words) - easy
    sample_text = " ".join(sample_words)

    try:
        raw = float((easy + difficult * _LINSEAR_DIFFICULT_WEIGHT) / sentence_count(sample_text))
    except ZeroDivisionError:
        return -1.0

    result = raw / 2
    if raw <= _LINSEAR_THRESHOLD:
        result -= 1

    return _apply_rounding(result, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
def forcast(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """FORCAST readability score.

    Designed for 150-word samples; warns if the text is shorter.

    Formula::

        20 − (monosyllable_count / 10)

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 1 when rounding is on).

    Returns:
        Estimated grade level.
    """
    words = remove_punctuation(text).split()
    if len(words) < _FORCAST_SAMPLE_SIZE:
        warnings.warn(
            f"FORCAST is validated on a {_FORCAST_SAMPLE_SIZE}-word sample. "
            f"Text has {len(words)} words — result may be less reliable.",
            stacklevel=2,
        )

    sample = words[:_FORCAST_SAMPLE_SIZE]
    monosyllables = sum(1 for w in sample if syllable_count(w) == 1)
    score = _FORCAST_BASE - (monosyllables / _FORCAST_DIVISOR)
    return _apply_rounding(score, rounding, points, default_points=1)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def dale_chall_readability_score(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Dale–Chall Readability Score.

    Uses token-based difficult-word percentage. Adds an adjustment
    constant when >5 % of words are difficult.

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        Dale–Chall score (maps to grade bands via ``text_standard``).
    """
    word_count = lexicon_count(text)
    pdw = (difficult_words(text, syllable_threshold=0) / word_count) * 100
    asl = avg_sentence_length(text)

    score = (_DC_PDW_COEFF * pdw) + (_DC_ASL_COEFF * asl)
    if pdw > _DC_PDW_THRESHOLD:
        score += _DC_ADJUSTMENT

    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def gunning_fog(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """Gunning Fog Index.

    Formula::

        0.4 × (ASL + % complex words)

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        Estimated grade level.
    """
    asl = avg_sentence_length(text)
    pct_complex = (polysyllabcount(text) / lexicon_count(text)) * 100
    score = _GF_COEFF * (asl + pct_complex)
    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def lix(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """LIX readability score (Swedish formula).

    Formula::

        ASL + (% words > 6 chars)

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        LIX score (not mapped to a specific grade).
    """
    tokens = remove_punctuation(text).split()
    n_words = len(tokens)
    n_long = sum(1 for w in tokens if len(w) > _LONG_WORD_MIN_LENGTH)
    score = (n_words / sentence_count(text)) + (n_long * 100 / n_words)
    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def rix(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """RIX readability score.

    Ratio of long words (>6 chars) to sentences.

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        RIX grade-level estimate.
    """
    tokens = remove_punctuation(text).split()
    n_long = sum(1 for w in tokens if len(w) > _LONG_WORD_MIN_LENGTH)
    score = n_long / sentence_count(text)
    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def spache_readability(
    text: str,
    float_output: bool = True,
    rounding: Optional[bool] = None,
    points: Optional[int] = None,
) -> Union[float, int]:
    """SPACHE readability formula (for young readers).

    Formula::

        0.141 × ASL + 0.086 × (% difficult words) + 0.839

    Args:
        text: The text to analyse.
        float_output: Return float if True, truncated int if False.
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        SPACHE grade level.
    """
    asl = avg_sentence_length(text)
    pdw = (difficult_words(text) / lexicon_count(text)) * 100
    score = (_SPACHE_ASL_COEFF * asl) + (_SPACHE_PDW_COEFF * pdw) + _SPACHE_INTERCEPT

    if not float_output:
        return int(score)
    return _apply_rounding(score, rounding, points, default_points=2)


@_guard_empty_text(default=0.0)
@_handle_zero_division
def mcalpine_eflaw(
    text: str, rounding: Optional[bool] = None, points: Optional[int] = None
) -> float:
    """McAlpine EFLAW score (for English as a Foreign Language materials).

    Formula::

        (word_count + miniword_count) / sentence_count

    Args:
        text: The text to analyse.
        rounding: Per-call rounding override.
        points: Decimal places (default 1 when rounding is on).

    Returns:
        McAlpine EFLAW score.
    """
    score = (lexicon_count(text) + miniword_count(text)) / sentence_count(text)
    return _apply_rounding(score, rounding, points, default_points=1)


# ---------------------------------------------------------------------------
# Consensus grade
# ---------------------------------------------------------------------------
def text_standard(text: str, as_string: bool = True) -> Union[float, str]:
    """Consensus grade level from multiple readability formulas.

    Collects grade estimates from all formulas and returns the most
    frequently occurring grade via majority vote.

    Args:
        text: The text to analyse.
        as_string: Return a human-readable string (e.g. "11th and 12th grade")
            when True, or a float when False.

    Returns:
        Consensus grade as a string or float.
    """
    if _is_empty(text):
        return "0th grade" if as_string else 0.0

    grade_levels: List[int] = []

    # Flesch-Kincaid Grade
    fk = flesch_kincaid_grade(text, rounding=False)
    grade_levels.extend([round(fk), math.ceil(fk)])

    # Flesch Reading Ease → grade mapping
    fre = flesch_reading_ease(text, rounding=False)
    mapped = False
    for low, high, grades in _FRE_GRADE_MAP:
        if low <= fre < high:
            grade_levels.extend(grades)
            mapped = True
            break
    if not mapped:
        grade_levels.append(_FRE_DEFAULT_GRADE)

    # Other formulas
    _grade_formulas = [
        smog_index,
        coleman_liau_index,
        automated_readability_index,
        dale_chall_readability_score,
        linsear_write_formula,
        gunning_fog,
    ]
    for formula in _grade_formulas:
        val = formula(text, rounding=False)
        if not isinstance(val, (int, float)) or val < 0:
            continue
        if formula is dale_chall_readability_score:
            grade_levels.append(_dc_score_to_grade(val))
        else:
            grade_levels.extend([round(val), math.ceil(val)])

    if not grade_levels:
        return "N/A" if as_string else 0.0

    consensus = Counter(int(g) for g in grade_levels).most_common(1)[0][0]

    if not as_string:
        return float(consensus)

    if consensus <= 1:
        return "Kindergarten to 1st grade"

    lower = consensus - 1
    return (
        f"{lower}{_get_grade_suffix(lower)} and "
        f"{consensus}{_get_grade_suffix(consensus)} grade"
    )


# ---------------------------------------------------------------------------
# Word and syllable counts
# ---------------------------------------------------------------------------
def polysyllabcount(text: str) -> int:
    """Counts words with ≥3 syllables."""
    return sum(
        1 for w in remove_punctuation(text).split()
        if syllable_count(w) >= _POLYSYLLABLE_THRESHOLD
    )


def monosyllabcount(text: str) -> int:
    """Counts words with exactly 1 syllable."""
    return sum(1 for w in remove_punctuation(text).split() if syllable_count(w) < 2)


def long_word_count(text: str) -> int:
    """Counts words with more than 6 characters."""
    return sum(
        1 for w in remove_punctuation(text).split()
        if len(w) > _LONG_WORD_MIN_LENGTH
    )


# ---------------------------------------------------------------------------
# Difficult word analysis
# ---------------------------------------------------------------------------
def difficult_words(text: str, syllable_threshold: int = 2) -> int:
    """Counts difficult words (token-based, not unique)."""
    return len(difficult_words_list(text, syllable_threshold))


def difficult_words_list(text: str, syllable_threshold: int = 2) -> List[str]:
    """Returns a list of difficult word tokens in *text*."""
    tokens = remove_punctuation(text).lower().split()
    return [w for w in tokens if is_difficult_word(w, syllable_threshold)]


def is_difficult_word(word: str, syllable_threshold: int = 2) -> bool:
    """Returns True if *word* is not in the easy-word list and meets the syllable threshold."""
    w = word.lower()
    if w in _get_easy_words():
        return False
    if syllable_threshold > 0 and syllable_count(w) < syllable_threshold:
        return False
    return True


def is_easy_word(word: str, syllable_threshold: int = 2) -> bool:
    """Returns True if *word* is considered easy (inverse of ``is_difficult_word``)."""
    return not is_difficult_word(word, syllable_threshold)


# ---------------------------------------------------------------------------
# Other utilities
# ---------------------------------------------------------------------------
def _dc_score_to_grade(score: float) -> int:
    """Maps a Dale–Chall score to an approximate U.S. grade level."""
    thresholds = [
        (4.9, 4),   # 4th grade and below
        (5.9, 6),   # 5th–6th
        (6.9, 8),   # 7th–8th
        (7.9, 10),  # 9th–10th
        (8.9, 12),  # 11th–12th
    ]
    for ceiling, grade in thresholds:
        if score <= ceiling:
            return grade
    return 13  # College


def reading_time(
    text: str,
    wpm: float = 200.0,
    rounding: Optional[bool] = None,
    points: Optional[int] = None,
) -> float:
    """Estimated reading time in seconds.

    Args:
        text: The text to analyse.
        wpm: Reading speed in words per minute (default 200).
        rounding: Per-call rounding override.
        points: Decimal places (default 2 when rounding is on).

    Returns:
        Reading time in seconds.
    """
    words = lexicon_count(text)
    if words == 0:
        return 0.0
    seconds = (words / wpm) * 60.0
    return _apply_rounding(seconds, rounding, points, default_points=2)
