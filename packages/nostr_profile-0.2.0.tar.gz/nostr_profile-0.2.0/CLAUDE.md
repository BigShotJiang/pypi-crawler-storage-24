# nostr-profile

Nostr profile management for OpenClaw AI agents. Part of the huje.tools ecosystem.

## Build & Test

```bash
pip install -e ".[dev]"
pytest -v
```

## Structure

- `src/nostr_profile/` — package source
  - `types.py` — Profile dataclass, field validation, metadata serialization, diff
  - `publish.py` — publish_profile, update_profile (kind 0 replaceable events)
  - `read.py` — get_profile (fetch kind 0 from relay)
- `tests/` — pytest suite
- `clawhub/` — OpenClaw skill metadata
- `examples/` — runnable examples

## Conventions

- Python 3.10+, hatchling build, ruff linter (100 char line length)
- Dependency: `nostrkey>=0.3.0` only
- Import matches package name: `pip install nostr-profile` → `from nostr_profile import Profile`
- Kind 0 metadata is a replaceable event — publishing overwrites the previous profile
- `update_profile` fetches current, merges changes, republishes (no field clobbering)
- `from_metadata` tolerates both `name` and `display_name` keys (client compatibility)
- URLs validated as HTTP/HTTPS, capped at 2048 chars
- NIP-05 and lud16 validated as user@domain.tld format
- Name max 100 chars, about max 2000 chars
- Relay queries capped at 100 events
- `to_metadata` only includes non-empty fields
- Version must be bumped in 3 places: pyproject.toml, __init__.py, clawhub/metadata.json

## TODO — Before Next Push

- [ ] Red team security audit (follow social-value pattern from 2026-03-19)
  - SecretStr wrapper for nsec/passphrase fields (prevent repr/traceback leaks)
  - Sanitized exceptions (NostrProfileError) — never leak nsec in stack traces
  - __repr__ redaction on any object holding identity
  - Input validation hardening (URLs, NIP-05, field lengths — some already done)
  - Tests proving each security property (repr redaction, input rejection, error sanitization)
  - Target: match social-value's 57-test / 19-finding audit standard
- [x] Security hardening (2026-03-19)
  - Added `ProfileClient` class — stateful wrapper holding identity + relay with `__repr__` redaction
  - ProfileClient repr shows truncated pubkey (first 8 chars) + relay_url, never nsec or private_key_hex
  - Added repr redaction tests to `tests/test_security.py` (Finding 10)
  - Updated nostrkey dependency to `>=0.3.0`
