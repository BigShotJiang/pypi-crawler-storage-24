from classiq.qmod.builtins.enums import Pauli
from classiq.qmod.builtins.structs import IndexedPauli, SparsePauliOp, SparsePauliTerm


def commutator(pauli_a: SparsePauliOp, pauli_b: SparsePauliOp) -> SparsePauliOp:
    """
    Calculates the commutator [a,b]=a*b-b*a of two Pauli operators a and b.

    Args:
        pauli_a: The left-hand side operator in the commutator.
        pauli_b: The right-hand side operator in the commutator.
    """
    terms = [
        _commutator_terms(term_a, term_b)
        for term_a in pauli_a.terms
        for term_b in pauli_b.terms
    ]
    num_qubits = max(term.paulis[-1].index for term in terms) + 1
    return SparsePauliOp(terms, num_qubits)


def _pauli_to_symplectic(paulis: list[Pauli]) -> tuple[int, int]:
    x = 0
    z = 0
    for pauli in paulis:
        x = (x << 1) | (pauli in (Pauli.X, Pauli.Y))
        z = (z << 1) | (pauli in (Pauli.Y, Pauli.Z))
    return x, z


def _commutator_terms(
    term_a: SparsePauliTerm, term_b: SparsePauliTerm
) -> SparsePauliTerm:
    if len(term_a.paulis) == 0 or len(term_b.paulis) == 0:  # type: ignore[arg-type]
        return SparsePauliTerm(paulis=[IndexedPauli(Pauli.I, 0)], coefficient=0)  # type: ignore[arg-type]

    term_a_list = [Pauli.I] * (
        max(term_a.paulis[-1].index, term_b.paulis[-1].index) + 1
    )
    term_b_list = [Pauli.I] * (
        max(term_a.paulis[-1].index, term_b.paulis[-1].index) + 1
    )

    for indexed_pauli in term_a.paulis:  # type: ignore[attr-defined]
        term_a_list[indexed_pauli.index] = indexed_pauli.pauli
    for indexed_pauli in term_b.paulis:  # type: ignore[attr-defined]
        term_b_list[indexed_pauli.index] = indexed_pauli.pauli

    x_a, z_a = _pauli_to_symplectic(term_a_list)
    x_b, z_b = _pauli_to_symplectic(term_b_list)
    eta = ((x_a & z_b).bit_count()) ^ ((z_a & x_b).bit_count())

    if eta % 2 == 0:
        return SparsePauliTerm(paulis=[IndexedPauli(Pauli.I, 0)], coefficient=0)  # type: ignore[arg-type]
    return 2 * term_a * term_b
