from collections.abc import Sequence
from dataclasses import dataclass
from itertools import chain
from typing import TYPE_CHECKING

from classiq.interface.exceptions import ClassiqError
from classiq.interface.generator.parameters import ParameterType

from classiq import QuantumProgram
from classiq.cudaq.cudaq_utils import CONVERSION_ERROR_PREFIX, QubitOrQreg

if TYPE_CHECKING:
    import cudaq
    import openqasm3

_ForeachData = dict[str, dict[str, list[float]]]


@dataclass
class _BaseKernelData:
    kernel: "cudaq.PyKernel"
    foreach_parameters: dict[str, dict[str, "cudaq.QuakeValue"]]
    parameters: dict[str, "cudaq.QuakeValue"]
    qubits: dict[str, QubitOrQreg]


@dataclass
class KernelData(_BaseKernelData):
    foreach_values: list[list[float]]
    foreach_lengths: dict[str, int]


def _get_base_kernel(
    qasm_ast: "openqasm3.ast.Program",
    is_main_kernel: bool,
    foreach_data: _ForeachData,
) -> _BaseKernelData:
    import openqasm3

    quantum_var_sizes: dict[str, int] = {}
    classical_inputs: list[str] = []
    for statement in qasm_ast.statements:
        if isinstance(statement, openqasm3.ast.IODeclaration):
            if statement.io_identifier != openqasm3.ast.IOKeyword.input:
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX + "classical outputs are not supported"
                )
            if not isinstance(statement.type, openqasm3.ast.FloatType):
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX
                    + "only float classical inputs are supported"
                )
            classical_inputs.append(statement.identifier.name)
        elif isinstance(statement, openqasm3.ast.QubitDeclaration):
            if statement.size is None:
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX
                    + f"qubit declaration {statement.qubit.name!r} has no size"
                )
            if not isinstance(statement.size, openqasm3.ast.IntegerLiteral):
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX
                    + f"the size of qubit declaration {statement.qubit.name!r} must be an integer literal"
                )
            quantum_var_sizes[statement.qubit.name] = statement.size.value

    if not is_main_kernel:
        return _get_main_base_kernel(classical_inputs, quantum_var_sizes)
    return _get_non_main_base_kernel(classical_inputs, quantum_var_sizes, foreach_data)


def _get_non_main_base_kernel(
    classical_inputs: list[str],
    quantum_var_sizes: dict[str, int],
    foreach_data: _ForeachData,
) -> _BaseKernelData:
    import cudaq

    # Analyze foreach data
    foreach_param_names = {
        param for data in foreach_data.values() for param in data.keys()
    }
    num_foreach_params = sum(len(data) for data in foreach_data.values())
    non_foreach_params = [
        param for param in classical_inputs if param not in foreach_param_names
    ]
    num_params = len(non_foreach_params)

    # Create kernel
    kernel_and_params = cudaq.make_kernel(
        *((list[float],) * num_foreach_params), *((float,) * num_params)
    )
    if not isinstance(kernel_and_params, tuple):
        kernel_and_params = (kernel_and_params,)

    # Get kernel, foreach parameters, and angle parameters
    kernel = kernel_and_params[0]
    foreach_params: dict[str, dict[str, cudaq.QuakeValue]] = {}
    foreach_idx = 0
    for foreach_block_name, data in foreach_data.items():
        foreach_params[foreach_block_name] = {}
        for param in data:
            foreach_params[foreach_block_name][param] = kernel_and_params[
                1 + foreach_idx
            ]
            foreach_idx += 1
    params = {
        classical_input: kernel_and_params[1 + num_foreach_params + idx]
        for idx, classical_input in enumerate(non_foreach_params)
    } | {param: 0.0 for param in foreach_param_names}
    # Add dummy values for foreach params. The actual, symbolic value is assigned
    # when the for loop is created. These dummy values must be passed down to the
    # foreach gate because they appear in the QASM.
    params |= {param: 0.0 for param in foreach_param_names}

    # Allocate qubits
    main_qubits = {
        var_name: kernel.qalloc(var_size)
        for var_name, var_size in quantum_var_sizes.items()
    }

    return _BaseKernelData(
        kernel=kernel,
        foreach_parameters=foreach_params,
        parameters=params,
        qubits=main_qubits,
    )


def _get_main_base_kernel(
    classical_inputs: list[str], quantum_var_sizes: dict[str, int]
) -> _BaseKernelData:
    import cudaq

    # Create kernel
    num_params = len(classical_inputs)
    num_qubits = sum(quantum_var_sizes.values())
    kernel_and_params = cudaq.make_kernel(
        *((float,) * num_params), *((cudaq.qubit,) * num_qubits)
    )
    if not isinstance(kernel_and_params, tuple):
        kernel_and_params = (kernel_and_params,)

    # Get kernel, angle parameters, and qubits
    kernel = kernel_and_params[0]
    qubit_index = 1 + num_params
    params = dict(zip(classical_inputs, kernel_and_params[1:qubit_index], strict=True))
    qubits: dict[str, Sequence["cudaq.QuakeValue"]] = {}
    for var_name, var_size in quantum_var_sizes.items():
        qubits[var_name] = kernel_and_params[qubit_index : qubit_index + var_size]
        qubit_index += var_size

    return _BaseKernelData(
        kernel=kernel, foreach_parameters={}, parameters=params, qubits=qubits
    )


def _get_foreach_data(
    quantum_program: QuantumProgram, is_main_kernel: bool
) -> _ForeachData:
    execution_data = quantum_program.data.execution_data
    if execution_data is None:
        return {}
    if any(
        isinstance(data.power_parameter, ParameterType)
        for data in execution_data.function_execution.values()
    ):
        raise ClassiqError(
            CONVERSION_ERROR_PREFIX + "parametric power is not supported"
        )
    foreach_data = {
        gate_name: values.power_parameter
        for gate_name, values in execution_data.function_execution.items()
        if isinstance(values.power_parameter, dict)
    }
    if len(foreach_data) > 0 and not is_main_kernel:
        raise ClassiqError(
            CONVERSION_ERROR_PREFIX
            + "foreach is not supported for is_main_kernel=False"
        )
    return foreach_data


def construct_kernel(
    quantum_program: QuantumProgram,
    is_main_kernel: bool,
    qasm_ast: "openqasm3.ast.Program",
) -> KernelData:
    foreach_data = _get_foreach_data(quantum_program, is_main_kernel)
    foreach_lengths = {
        block_name: len(next(iter(data.values())))
        for block_name, data in foreach_data.items()
    }
    foreach_values = [
        *chain.from_iterable([data.values() for data in foreach_data.values()])
    ]
    base_kernel_data = _get_base_kernel(qasm_ast, is_main_kernel, foreach_data)
    return KernelData(
        kernel=base_kernel_data.kernel,
        foreach_parameters=base_kernel_data.foreach_parameters,
        parameters=base_kernel_data.parameters,
        qubits=base_kernel_data.qubits,
        foreach_values=foreach_values,
        foreach_lengths=foreach_lengths,
    )
