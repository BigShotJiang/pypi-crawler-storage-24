import ast
import logging
from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, cast

import sympy

from classiq.interface.exceptions import ClassiqInternalExpansionError
from classiq.interface.generator.expressions.proxies.classical.qmod_struct_instance import (
    QmodStructInstance,
)
from classiq.interface.generator.functions.classical_type import Bool
from classiq.interface.model.quantum_type import QuantumBit

from classiq.evaluators.qmod_annotated_expression import (
    QmodAnnotatedExpression,
    QmodExprNodeId,
)
from classiq.evaluators.qmod_expression_visitors.out_of_place_node_transformer import (
    OutOfPlaceNodeTransformer,
)
from classiq.evaluators.qmod_expression_visitors.qmod_expression_bool_normalizer import (
    QmodExpressionBoolNormalizer,
)
from classiq.evaluators.qmod_expression_visitors.sympy_wrappers import (
    BitwiseAnd,
    BitwiseNot,
    BitwiseOr,
    BitwiseXor,
    BoolToInt,
    LShift,
    RShift,
)

_logger = logging.getLogger(__name__)


def _div_wrapper(lhs: Any, rhs: Any) -> Any:
    res = lhs / rhs
    if isinstance(res, sympy.Expr):
        res = res.evalf()
    return res


_SYMPY_WRAPPERS = {
    wrapper.__name__: wrapper
    for wrapper in [
        BitwiseAnd,
        BitwiseNot,
        BitwiseOr,
        BitwiseXor,
        LShift,
        RShift,
        BoolToInt,
    ]
} | {
    _div_wrapper.__name__: _div_wrapper,
}

_PY_NODE = TypeVar("_PY_NODE", bound=ast.AST)


class _VarMaskTransformer(OutOfPlaceNodeTransformer):
    def __init__(self, expr_val: QmodAnnotatedExpression) -> None:
        self._expr_val = expr_val
        self._mask_id = 0
        self.masks: dict[str, QmodExprNodeId] = {}
        self._assigned_masks: dict[Any, str] = {}

    def _create_mask(self) -> str:
        mask = f"x{self._mask_id}"
        self._mask_id += 1
        return mask

    def visit(self, node: ast.AST) -> ast.AST:
        if self._expr_val.has_value(node):
            val = self._expr_val.get_value(node)
            if not isinstance(val, (list, QmodStructInstance)):
                return ast.Constant(value=val)
            mask = self._create_mask()
            self.masks[mask] = id(node)
            return ast.Name(id=mask)
        if self._expr_val.has_var(node):
            var = self._expr_val.get_var(node)
            var_str = str(var.collapse())
            if var_str in self._assigned_masks:
                return ast.Name(id=self._assigned_masks[var_str])
            mask = self._create_mask()
            self._assigned_masks[var_str] = mask
            self.masks[mask] = id(node)
            return ast.Name(id=mask)
        return super().visit(node)

    def _reduce_node(
        self, node: _PY_NODE, inner_node: ast.AST, key: Callable[[_PY_NODE], str]
    ) -> ast.AST:
        new_value = self.visit(inner_node)
        if isinstance(new_value, ast.Name):
            mask_key = (new_value.id, key(node))
            if mask_key in self._assigned_masks:
                return ast.Name(self._assigned_masks[mask_key])
            mask = self._create_mask()
            self._assigned_masks[mask_key] = mask
        else:
            mask = self._create_mask()
        self.masks[mask] = id(node)
        return ast.Name(id=mask)

    def visit_Attribute(self, node: ast.Attribute) -> ast.AST:
        return self._reduce_node(node, node.value, lambda n: n.attr)

    def visit_Subscript(self, node: ast.Subscript) -> ast.AST:
        return self._reduce_node(node, node.value, lambda n: ast.unparse(node.slice))

    def visit_List(self, node: ast.List) -> ast.AST:
        mask = self._create_mask()
        self.masks[mask] = id(node)
        return ast.Name(id=mask)


class _InverseVarMaskTransformer(OutOfPlaceNodeTransformer):
    def __init__(
        self, expr_val: QmodAnnotatedExpression, masks: dict[str, QmodExprNodeId]
    ) -> None:
        self._expr_val = expr_val
        self._masks = masks

    def visit_Name(self, node: ast.Name) -> Any:
        name = node.id
        if name in self._masks:
            mask_id = self._masks[name]
            if not self._expr_val.has_node(mask_id):
                raise ClassiqInternalExpansionError
            return ast.Name(id=ast.unparse(self._expr_val.get_node(mask_id)))
        return node


class _SympyCompatibilityTransformerCommon(OutOfPlaceNodeTransformer):
    def __init__(self, bool_vars: set[str]) -> None:
        self._bool_vars = bool_vars

    def _is_bool(self, node: ast.AST) -> bool:
        if self._is_bool_value(node):
            return True

        if isinstance(node, ast.Name):
            return node.id in self._bool_vars

        if isinstance(node, ast.UnaryOp):
            return isinstance(node.op, ast.Not) or (
                isinstance(node.op, ast.Invert) and self._is_bool(node.operand)
            )

        if isinstance(node, ast.BinOp):
            return (
                isinstance(node.op, (ast.BitOr, ast.BitAnd, ast.BitXor))
                and self._is_bool(node.left)
                and self._is_bool(node.right)
            )

        if isinstance(node, ast.Call) and isinstance(func := node.func, ast.Name):
            return func.id in ("And", "Or", "Not", "Eq", "Ne", "Lt", "Le", "Gt", "Ge")

        return isinstance(node, (ast.Compare, ast.BoolOp))

    def _is_bool_value(self, node: ast.AST) -> TypeGuard[ast.Constant]:
        return isinstance(node, ast.Constant) and node.value in (0, 1, False, True)


class _SympyCompatibilityTransformer(_SympyCompatibilityTransformerCommon):
    def visit_BoolOp(self, node: ast.BoolOp) -> ast.Call:
        if len(node.values) < 2:
            raise ClassiqInternalExpansionError
        node = cast(ast.BoolOp, self.generic_visit(node))
        if isinstance(node.op, ast.Or):
            sympy_func = "Or"
        else:
            sympy_func = "And"
        return ast.Call(func=ast.Name(id=sympy_func), args=node.values, keywords=[])

    def _bool_and_bool_value(
        self, left: ast.expr, right: ast.expr
    ) -> tuple[ast.expr, bool] | None:
        if self._is_bool(left) and self._is_bool_value(right):
            return left, bool(right.value)
        if self._is_bool(right) and self._is_bool_value(left):
            return right, bool(left.value)
        return None

    def _negate_or_nothing(self, node: ast.expr, negate: bool) -> ast.expr:
        if not negate:
            return node
        return ast.Call(func=ast.Name(id="Not"), args=[node], keywords=[])

    def _wrap_in_cast(self, node: ast.expr) -> ast.expr:
        if not self._is_bool(node):
            return node
        if isinstance(node, ast.Constant) and node.value in (0, 1):
            return node
        return ast.Call(func=ast.Name(id=BoolToInt.__name__), args=[node], keywords=[])

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        node = cast(ast.UnaryOp, self.generic_visit(node))
        if isinstance(node.op, ast.Not) or (
            isinstance(node.op, ast.Invert) and self._is_bool(node.operand)
        ):
            sympy_func = "Not"
        elif isinstance(node.op, ast.Invert):
            sympy_func = BitwiseNot.__name__
        else:
            return ast.UnaryOp(
                op=node.op,
                operand=self._wrap_in_cast(node.operand),
            )
        return ast.Call(func=ast.Name(id=sympy_func), args=[node.operand], keywords=[])

    def visit_Compare(self, node: ast.Compare) -> ast.expr:
        if len(node.ops) != 1:
            raise ClassiqInternalExpansionError
        node = cast(ast.Compare, self.generic_visit(node))
        op = node.ops[0]
        left = node.left
        right = node.comparators[0]

        if (
            isinstance(op, (ast.Eq, ast.NotEq))
            and (res := self._bool_and_bool_value(left, right)) is not None
        ):
            child, value = res
            to_negate = isinstance(op, ast.Eq) ^ value
            return self._negate_or_nothing(child, to_negate)

        if not isinstance(op, (ast.Eq, ast.NotEq)):
            left = self._wrap_in_cast(left)
            right = self._wrap_in_cast(right)

        if isinstance(op, ast.Eq):
            sympy_func = "Eq"
        elif isinstance(op, ast.NotEq):
            sympy_func = "Ne"
        elif isinstance(op, ast.Lt):
            sympy_func = "Lt"
        elif isinstance(op, ast.LtE):
            sympy_func = "Le"
        elif isinstance(op, ast.Gt):
            sympy_func = "Gt"
        elif isinstance(op, ast.GtE):
            sympy_func = "Ge"
        else:
            raise ClassiqInternalExpansionError
        return ast.Call(
            func=ast.Name(id=sympy_func),
            args=[left, right],
            keywords=[],
        )

    def visit_BinOp(self, node: ast.BinOp) -> Any:
        node = cast(ast.BinOp, self.generic_visit(node))
        left = node.left
        right = node.right

        if isinstance(node.op, ast.BitXor) and (
            (res := self._bool_and_bool_value(left, right)) is not None
        ):
            child, value = res
            return self._negate_or_nothing(child, value)

        if (
            isinstance(node.op, (ast.BitOr, ast.BitAnd, ast.BitXor))
            and self._is_bool(left)
            and self._is_bool(right)
        ):
            if isinstance(node.op, ast.BitOr):
                sympy_func = "Or"
            elif isinstance(node.op, ast.BitAnd):
                sympy_func = "And"
            else:
                # avoid using sympy's 'Xor' as it leads to unfavourable optimizations
                sympy_func = "Ne"
            return ast.Call(
                func=ast.Name(id=sympy_func), args=[left, right], keywords=[]
            )

        # (1 - b) ===> not b
        if (
            isinstance(node.op, ast.Sub)
            and self._is_bool_value(left)
            and left.value == 1
            and self._is_bool(right)
        ):
            return ast.Call(func=ast.Name(id="Not"), args=[right], keywords=[])

        # b1 * b2 ===> b1 and b2
        if (
            isinstance(node.op, ast.Mult)
            and self._is_bool(left)
            and not self._is_bool_value(left)
            and self._is_bool(right)
            and not self._is_bool_value(right)
        ):
            return ast.Call(func=ast.Name(id="And"), args=[left, right], keywords=[])

        # 1.0 * x ===> x (sympy leaves it as "1.0 * x")
        if isinstance(node.op, ast.Mult) and (
            (isinstance(left, ast.Constant) and left.value == 1)
            or (isinstance(right, ast.Constant) and right.value == 1)
        ):
            return left if isinstance(right, ast.Constant) else right

        left = self._wrap_in_cast(left)
        right = self._wrap_in_cast(right)

        if isinstance(node.op, ast.LShift):
            sympy_func = LShift.__name__
        elif isinstance(node.op, ast.RShift):
            sympy_func = RShift.__name__
        elif isinstance(node.op, ast.BitOr):
            sympy_func = BitwiseOr.__name__
        elif isinstance(node.op, ast.BitXor):
            sympy_func = BitwiseXor.__name__
        elif isinstance(node.op, ast.BitAnd):
            sympy_func = BitwiseAnd.__name__
        elif isinstance(node.op, ast.Div):
            sympy_func = _div_wrapper.__name__
        else:
            return ast.BinOp(
                op=node.op,
                left=left,
                right=right,
            )

        return ast.Call(func=ast.Name(id=sympy_func), args=[left, right], keywords=[])


class _InverseSympyCompatibilityTransformer(_SympyCompatibilityTransformerCommon):
    def visit_Call(self, node: ast.Call) -> Any:
        node = cast(ast.Call, self.generic_visit(node))
        if not isinstance(node.func, ast.Name):
            raise ClassiqInternalExpansionError
        func = node.func.id

        if (
            func
            in {
                "Eq",
                "Ne",
                "Lt",
                "Le",
                "Gt",
                "Ge",
                LShift.__name__,
                RShift.__name__,
                BitwiseOr.__name__,
                BitwiseXor.__name__,
                BitwiseAnd.__name__,
            }
            and (len(node.args) != 2 or len(node.keywords) > 0)
        ) or (
            func in {BitwiseNot.__name__}
            and (len(node.args) != 1 or len(node.keywords) > 0)
        ):
            raise ClassiqInternalExpansionError

        if func == BitwiseNot.__name__:
            return ast.UnaryOp(op=ast.Invert(), operand=node.args[0])

        if func == "Eq":
            if self._is_bool(node.args[0]) and self._is_bool(node.args[1]):
                return ast.UnaryOp(
                    op=ast.Not(),
                    operand=ast.BinOp(
                        op=ast.BitXor(),
                        left=node.args[0],
                        right=node.args[1],
                    ),
                )
            return ast.Compare(
                left=node.args[0], ops=[ast.Eq()], comparators=[node.args[1]]
            )
        if func == "Ne":
            if self._is_bool(node.args[0]) and self._is_bool(node.args[1]):
                return ast.BinOp(
                    op=ast.BitXor(),
                    left=node.args[0],
                    right=node.args[1],
                )
            return ast.Compare(
                left=node.args[0], ops=[ast.NotEq()], comparators=[node.args[1]]
            )
        if func == "Lt":
            return ast.Compare(
                left=node.args[0], ops=[ast.Lt()], comparators=[node.args[1]]
            )
        if func == "Le":
            return ast.Compare(
                left=node.args[0], ops=[ast.LtE()], comparators=[node.args[1]]
            )
        if func == "Gt":
            return ast.Compare(
                left=node.args[0], ops=[ast.Gt()], comparators=[node.args[1]]
            )
        if func == "GtE":
            return ast.Compare(
                left=node.args[0], ops=[ast.GtE()], comparators=[node.args[1]]
            )

        if func == LShift.__name__:
            return ast.BinOp(left=node.args[0], op=ast.LShift(), right=node.args[1])
        if func == RShift.__name__:
            return ast.BinOp(left=node.args[0], op=ast.RShift(), right=node.args[1])
        if func == BitwiseOr.__name__:
            return ast.BinOp(left=node.args[0], op=ast.BitOr(), right=node.args[1])
        if func == BitwiseXor.__name__:
            return ast.BinOp(left=node.args[0], op=ast.BitXor(), right=node.args[1])
        if func == BitwiseAnd.__name__:
            return ast.BinOp(left=node.args[0], op=ast.BitAnd(), right=node.args[1])

        if func == BoolToInt.__name__:
            return node.args[0]

        if func == "Abs":
            node.func.id = "abs"
        if func == "Max":
            node.func.id = "max"
        elif func == "Min":
            node.func.id = "min"
        if func == "Mod":
            return ast.BinOp(left=node.args[0], op=ast.Mod(), right=node.args[1])

        return node

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        node = cast(ast.UnaryOp, self.generic_visit(node))

        if isinstance(node.op, ast.Invert):
            return ast.UnaryOp(op=ast.Not(), operand=node.operand)

        return node

    def visit_BinOp(self, node: ast.BinOp) -> Any:
        node = cast(ast.BinOp, self.generic_visit(node))

        values: list[ast.expr] = []
        if isinstance(node.op, ast.BitOr):
            self._extend_bool_values(values, node.left, ast.Or)
            self._extend_bool_values(values, node.right, ast.Or)
            return ast.BoolOp(op=ast.Or(), values=values)
        if isinstance(node.op, ast.BitAnd):
            self._extend_bool_values(values, node.left, ast.And)
            self._extend_bool_values(values, node.right, ast.And)
            return ast.BoolOp(op=ast.And(), values=values)
        if isinstance(node.op, ast.Sub):
            return self._subtract(node.left, node.right)

        return node

    @staticmethod
    def _extend_bool_values(
        values: list[ast.expr], node: ast.expr, op: type[ast.boolop]
    ) -> None:
        if isinstance(node, ast.BoolOp) and isinstance(node.op, op):
            values.extend(node.values)
        else:
            values.append(node)

    @staticmethod
    def _subtract(left: ast.expr, right: ast.expr) -> ast.expr:
        return ast.BinOp(
            op=ast.Add(),
            left=left,
            right=ast.UnaryOp(
                op=ast.USub(),
                operand=right,
            ),
        )


def _get_bool_vars(
    expr_val: QmodAnnotatedExpression, masks: dict[str, QmodExprNodeId]
) -> set[str]:
    return {
        key
        for key, node in masks.items()
        if isinstance(expr_val.get_type(node), (Bool, QuantumBit))
    }


def simplify_qmod_expression(expr_val: QmodAnnotatedExpression) -> str:
    if expr_val.has_value(expr_val.root):
        raise ClassiqInternalExpansionError(
            "This expression is a constant value. No need for simplification"
        )
    var_mask_transformer = _VarMaskTransformer(expr_val)
    mask_expr = var_mask_transformer.visit(expr_val.root)
    bool_vars = _get_bool_vars(expr_val, var_mask_transformer.masks)
    expr = ast.unparse(_SympyCompatibilityTransformer(bool_vars).visit(mask_expr))
    try:
        expr = str(sympy.simplify(expr))
    except Exception as ex:
        _logger.info("Could not simplify expression %s: %s", expr, ex)
    simplified_expr = str(sympy.sympify(expr, locals=_SYMPY_WRAPPERS))
    restored_expr = _InverseSympyCompatibilityTransformer(bool_vars).visit(
        ast.parse(simplified_expr, mode="eval")
    )
    restored_expr = _InverseVarMaskTransformer(
        expr_val, var_mask_transformer.masks
    ).visit(restored_expr)
    normalized_expr = QmodExpressionBoolNormalizer().visit(restored_expr)
    return ast.unparse(normalized_expr)
