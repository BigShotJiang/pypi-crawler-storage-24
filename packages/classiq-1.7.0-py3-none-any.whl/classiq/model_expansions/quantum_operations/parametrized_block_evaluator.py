from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING

from classiq.interface.generator.expressions.proxies.classical.classical_scalar_proxy import (
    ClassicalScalarProxy,
)
from classiq.interface.generator.functions.concrete_types import ConcreteClassicalType
from classiq.interface.model.handle_binding import HandleBinding
from classiq.interface.model.quantum_function_declaration import PositionalArg
from classiq.interface.model.quantum_statement import QuantumOperation

from classiq import ClassicalParameterDeclaration
from classiq.model_expansions.quantum_operations.block_evaluator import BlockEvaluator
from classiq.model_expansions.scope import Evaluated, Scope

if TYPE_CHECKING:
    from classiq.model_expansions.interpreters.base_interpreter import BaseInterpreter


class ParametrizedBlockEvaluator(BlockEvaluator):
    def __init__(
        self,
        interpreter: "BaseInterpreter",
        operation_name: str,
        iteration_variables: list[str],
        iteration_variables_type: Callable[[], ConcreteClassicalType],
        *block_names: str,
    ) -> None:
        super().__init__(interpreter, operation_name, *block_names)
        self.iteration_variables = iteration_variables
        self.iteration_variables_type = iteration_variables_type

    def get_params(self) -> Sequence[PositionalArg]:
        return [
            ClassicalParameterDeclaration(
                name=iteration_variable, classical_type=self.iteration_variables_type()
            )
            for iteration_variable in self.iteration_variables
        ]

    def get_scope(self, op: QuantumOperation) -> Scope:
        scope = super().get_scope(op)
        for iteration_variable in self.iteration_variables:
            scope[iteration_variable] = Evaluated(
                value=ClassicalScalarProxy(
                    HandleBinding(name=iteration_variable),
                    self.iteration_variables_type(),
                ),
                defining_function=self._builder.current_function,
            )
        return scope
