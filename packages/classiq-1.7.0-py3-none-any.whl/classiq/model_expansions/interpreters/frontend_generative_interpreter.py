import inspect
import os

from pydantic import ValidationError

from classiq.interface.exceptions import ClassiqError
from classiq.interface.model.quantum_function_call import QuantumFunctionCall
from classiq.interface.model.quantum_function_declaration import PositionalArg
from classiq.interface.source_reference import SourceReference

from classiq.model_expansions.closure import FunctionClosure, GenerativeFunctionClosure
from classiq.model_expansions.interpreters.generative_interpreter import (
    GenerativeInterpreter,
)
from classiq.model_expansions.quantum_operations.quantum_function_call import (
    DeclarativeQuantumFunctionCallEmitter,
)
from classiq.model_expansions.scope import Scope
from classiq.qmod.model_state_container import QMODULE

SDK_PATH_PREFIX = "classiq."


class FrontendGenerativeInterpreter(GenerativeInterpreter):
    def emit_quantum_function_call(self, call: QuantumFunctionCall) -> None:
        DeclarativeQuantumFunctionCallEmitter(self).emit(call)

    def _get_main_closure(
        self, main_func: FunctionClosure, params: list[PositionalArg]
    ) -> FunctionClosure:
        if isinstance(main_func, GenerativeFunctionClosure):
            return GenerativeFunctionClosure.create(
                name=main_func.name,
                positional_arg_declarations=params,
                scope=Scope(parent=self._top_level_scope),
                _depth=0,
                generative_blocks={"body": main_func.generative_blocks["body"]},
            )

        return super()._get_main_closure(main_func, params)

    def process_exception(self, e: Exception) -> None:
        if not isinstance(e, (ClassiqError, ValidationError, RecursionError)):
            error_message = str(e)
            trace = inspect.trace()
            frame = trace[-1]
            parent_frame = trace[-2]
            module = inspect.getmodule(frame[0])
            parent_module = inspect.getmodule(parent_frame[0])
            is_error_in_sdk = module is not None and module.__name__.startswith(
                SDK_PATH_PREFIX
            )
            parent_is_error_in_sdk = (
                parent_module is not None
                and parent_module.__name__.startswith(SDK_PATH_PREFIX)
            )
            is_pos_args_error = (
                isinstance(e, TypeError)
                and "required positional argument" in error_message
            )
            if not is_error_in_sdk or (
                not parent_is_error_in_sdk and is_pos_args_error
            ):
                self._register_user_error(e, frame)
                return

        super().process_exception(e)

    def _register_user_error(self, e: Exception, frame: inspect.FrameInfo) -> None:
        file_name = os.path.split(frame.filename)[-1]
        if (
            hasattr(frame, "positions")
            and frame.positions is not None
            and frame.positions.lineno is not None
            and frame.positions.col_offset is not None
            and frame.positions.end_lineno is not None
            and frame.positions.end_col_offset is not None
        ):
            source_ref = SourceReference(
                start_line=frame.positions.lineno - 1,
                start_column=frame.positions.col_offset - 1,
                end_line=frame.positions.end_lineno - 1,
                end_column=frame.positions.end_col_offset - 1,
                file_name=file_name,
            )
        else:
            source_ref = SourceReference(
                start_line=frame.lineno - 1,
                start_column=frame.lineno - 1,
                end_line=-1,
                end_column=-1,
                file_name=file_name,
            )
        error_message = str(e)
        e_str = f": {error_message}" if error_message else ""
        self._error_manager.add_error(
            f"{type(e).__name__}{e_str}",
            source_ref=source_ref,
            function=frame.function,
        )

    def add_purely_declarative_function(self, function: FunctionClosure) -> None:
        functions_to_add = [function.name] + QMODULE.function_dependencies[
            function.name
        ]
        for func in functions_to_add:
            if func not in self._expanded_functions and func in QMODULE.native_defs:
                self._expanded_functions[func] = QMODULE.native_defs[func]
                if func in QMODULE.functions_compilation_metadata:
                    self._expanded_functions_compilation_metadata[func] = (
                        QMODULE.functions_compilation_metadata[func]
                    )
