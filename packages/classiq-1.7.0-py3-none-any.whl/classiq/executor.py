"""Executor module, implementing facilities for executing quantum programs using Classiq platform."""

from typing import TypeAlias, Union

from classiq.interface.backend.backend_preferences import (
    BackendPreferencesTypes,
)
from classiq.interface.executor.cost_estimate import CostEstimateResult
from classiq.interface.executor.estimation import OperatorsEstimation
from classiq.interface.executor.execution_preferences import ExecutionPreferences
from classiq.interface.executor.quantum_code import QuantumCode
from classiq.interface.executor.quantum_instruction_set import QuantumInstructionSet
from classiq.interface.executor.result import ExecutionDetails
from classiq.interface.generator.model.preferences.preferences import (
    TranspilationOption,
)
from classiq.interface.generator.quantum_program import QuantumProgram

from classiq._internals import async_utils
from classiq._internals.api_wrapper import ApiWrapper
from classiq.execution.jobs import ExecutionJob

BatchExecutionResult: TypeAlias = Union[ExecutionDetails, BaseException]
ProgramAndResult: TypeAlias = tuple[QuantumCode, BatchExecutionResult]
BackendPreferencesAndResult: TypeAlias = tuple[
    BackendPreferencesTypes, int, BatchExecutionResult
]


async def _estimate_sample_cost_async(
    quantum_program: QuantumProgram,
    execution_preferences: ExecutionPreferences,
    batch_params: list[dict] | None = None,
) -> CostEstimateResult:
    qprog_with_prefs = quantum_program.model_copy(
        update={
            "model": quantum_program.model.model_copy(
                update={"execution_preferences": execution_preferences}
            )
        }
    )
    execution_input = await ApiWrapper.call_convert_quantum_program(qprog_with_prefs)
    result = await ApiWrapper.call_estimate_sample_cost(
        execution_input=execution_input,
        batch_params=batch_params,
    )
    return CostEstimateResult.model_validate(result)


async def execute_async(quantum_program: QuantumProgram) -> ExecutionJob:
    execution_input = await ApiWrapper.call_convert_quantum_program(quantum_program)
    result = await ApiWrapper.call_execute_execution_input(execution_input)
    return ExecutionJob(details=result)


def execute(quantum_program: QuantumProgram) -> ExecutionJob:
    """
    Execute a quantum program. The preferences for execution are set on the quantum program using the method `set_execution_preferences`.

    Args:
        quantum_program: The quantum program to execute. This is the result of the synthesize method.

    Returns:
        ExecutionJob: The result of the execution.

    For examples please see [Execution Documentation](https://docs.classiq.io/latest/user-guide/execution/)
    """
    return async_utils.run(execute_async(quantum_program))


def set_quantum_program_execution_preferences(
    quantum_program: QuantumProgram,
    preferences: ExecutionPreferences,
) -> QuantumProgram:
    quantum_program.model.execution_preferences = preferences
    return quantum_program


def estimate_sample_cost(
    quantum_program: QuantumProgram,
    execution_options: ExecutionPreferences,
) -> CostEstimateResult:
    """
    Estimate the cost for sampling a quantum program.

    Args:
        quantum_program: The quantum program (output of synthesize).
        execution_options: Execution preferences (backend, shots, transpilation).

    Returns:
        CostEstimateResult with cost and currency.
    """
    return async_utils.run(
        _estimate_sample_cost_async(
            quantum_program, execution_options, batch_params=None
        )
    )


def estimate_sample_batch_cost(
    quantum_program: QuantumProgram,
    execution_backend: BackendPreferencesTypes,
    transpilation_level: TranspilationOption = TranspilationOption.DECOMPOSE,
    shots: int = 1000,
    params: list[dict] | None = None,
) -> CostEstimateResult:
    """
    Estimate the cost for batch sampling a quantum program.

    Args:
        quantum_program: The quantum program (output of synthesize).
        execution_backend: Backend preferences for the target backend.
        transpilation_level: Transpilation option for the circuit.
        shots: Number of shots per sample.
        params: Optional list of parameter sets for batch. If None, single sample.

    Returns:
        CostEstimateResult with cost and currency.
    """
    execution_preferences = ExecutionPreferences(
        backend_preferences=execution_backend,
        transpile_to_hardware=transpilation_level,
        num_shots=shots,
    )
    batch_params = params if params is not None else [{}]
    return async_utils.run(
        _estimate_sample_cost_async(
            quantum_program, execution_preferences, batch_params=batch_params
        )
    )


__all__ = [
    "CostEstimateResult",
    "OperatorsEstimation",
    "QuantumCode",
    "QuantumInstructionSet",
    "estimate_sample_batch_cost",
    "estimate_sample_cost",
    "set_quantum_program_execution_preferences",
]
