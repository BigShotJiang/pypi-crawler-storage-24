import pydantic


class CostEstimateResult(pydantic.BaseModel):
    """Result of sample cost estimation."""

    cost: float = pydantic.Field(description="Estimated cost")
    currency: str = pydantic.Field(default="USD", description="Currency code")
