from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Literal

from classiq.interface.exceptions import ClassiqNotImplementedError
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.model.handle_binding import ConcreteHandleBinding, HandleBinding
from classiq.interface.model.quantum_expressions.quantum_expression import (
    QuantumExpressionOperation,
)

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression


class PhaseOperation(QuantumExpressionOperation):
    if TYPE_CHECKING:
        kind: Literal["PhaseOperation"] = "PhaseOperation"
    else:
        kind: Literal["PhaseOperation"]
    theta: Expression

    @property
    def expressions(self) -> list[Expression]:
        return super().expressions + [self.theta]

    @property
    def inouts(self) -> Sequence[HandleBinding]:
        expr_val = self.expression.value.value
        if not isinstance(expr_val, QmodAnnotatedExpression):
            return []
        return list(dict.fromkeys(expr_val.get_quantum_vars().values()))

    @property
    def wiring_inouts(self) -> Mapping[str, ConcreteHandleBinding]:
        raise ClassiqNotImplementedError("")
