import abc
from collections.abc import Mapping
from typing import cast

import pydantic

from classiq.interface.exceptions import ClassiqInternalExpansionError
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.helpers.pydantic_model_helpers import nameables_to_dict
from classiq.interface.model.handle_binding import (
    ConcreteHandleBinding,
    HandleBinding,
    NestedHandleBinding,
)
from classiq.interface.model.quantum_statement import QuantumOperation
from classiq.interface.model.quantum_type import QuantumType

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression
from classiq.model_expansions.arithmetic import NumericAttributes


class QuantumExpressionOperation(QuantumOperation):
    expression: Expression = pydantic.Field()

    @property
    def expressions(self) -> list[Expression]:
        return [self.expression]


class QuantumAssignmentOperation(QuantumExpressionOperation):
    result_var: ConcreteHandleBinding = pydantic.Field(
        description="The variable storing the expression result"
    )
    _result_type: QuantumType | None = pydantic.PrivateAttr(
        default=None,
    )

    @property
    def result_type(self) -> QuantumType:
        assert self._result_type is not None
        return self._result_type

    def initialize_var_types(self, machine_precision: int) -> None:
        expr_val = self.expression.value.value
        if isinstance(expr_val, QmodAnnotatedExpression):
            self._result_type = expr_val.get_quantum_type(expr_val.root)
            # copy numeric types to preserve bounds
            with expr_val.unlock():
                for node_id in expr_val.get_quantum_vars():
                    expr_val.set_type(
                        node_id, expr_val.get_type(node_id).model_copy(deep=True)
                    )
        else:
            self._result_type = NumericAttributes.from_constant(
                cast(float, expr_val), machine_precision
            ).to_quantum_numeric()

    @property
    def var_handles(self) -> list[HandleBinding]:
        expr_val = self.expression.value.value
        if not isinstance(expr_val, QmodAnnotatedExpression):
            return []
        return list(dict.fromkeys(expr_val.get_quantum_vars().values()))

    @property
    def wiring_inouts(self) -> Mapping[str, ConcreteHandleBinding]:
        return nameables_to_dict(self.var_handles)  # type: ignore[type-var]

    @property
    def var_types(self) -> dict[str, QuantumType]:
        expr_val = self.expression.value.value
        if not isinstance(expr_val, QmodAnnotatedExpression):
            return {}
        quantum_vars = expr_val.get_quantum_vars()
        if any(isinstance(var, NestedHandleBinding) for var in quantum_vars.values()):
            raise ClassiqInternalExpansionError("Unexpected path expression")
        return {
            var.name: expr_val.get_quantum_type(node_id)
            for node_id, var in quantum_vars.items()
        }

    @property
    def wiring_outputs(self) -> Mapping[str, HandleBinding]:
        return {self.result_name(): self.result_var}

    @classmethod
    @abc.abstractmethod
    def result_name(cls) -> str:
        raise NotImplementedError()
