from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal, Optional

from classiq.interface.ast_node import ASTNodeType, reset_lists
from classiq.interface.exceptions import (
    ClassiqInternalError,
    ClassiqInternalExpansionError,
)
from classiq.interface.helpers.pydantic_model_helpers import nameables_to_dict
from classiq.interface.model.handle_binding import (
    ConcreteHandleBinding,
    GeneralHandle,
    HandleBinding,
)
from classiq.interface.model.quantum_expressions.quantum_expression import (
    QuantumExpressionOperation,
)

from classiq.evaluators.qmod_annotated_expression import QmodAnnotatedExpression

if TYPE_CHECKING:
    from classiq.interface.model.statement_block import StatementBlock


class Control(QuantumExpressionOperation):
    if TYPE_CHECKING:
        kind: Literal["Control"] = "Control"
    else:
        kind: Literal["Control"]
    body: "StatementBlock"
    else_block: Optional["StatementBlock"] = None

    @property
    def ctrl_size(self) -> int:
        if not isinstance(self.expression.value.value, QmodAnnotatedExpression):
            raise ClassiqInternalError("Control condition size cannot be determined")
        return self.expression.value.value.get_quantum_type(
            self.expression.value.value.root
        ).size_in_bits

    @property
    def wiring_inouts(self) -> Mapping[str, ConcreteHandleBinding]:
        return nameables_to_dict(self.get_control_vars_list())  # type: ignore[type-var]

    def _as_back_ref(self: ASTNodeType) -> ASTNodeType:
        return reset_lists(self, ["body", "else_block"])

    @property
    def blocks(self) -> dict[str, "StatementBlock"]:
        blocks = {"body": self.body}
        if self.else_block is not None:
            blocks["else_block"] = self.else_block
        return blocks

    def get_control_vars(self) -> GeneralHandle:
        condition = self.expression.value.value
        if not isinstance(condition, QmodAnnotatedExpression):
            raise ClassiqInternalExpansionError(
                "Unexpected non-symbolic control condition"
            )
        if condition.has_var(condition.root):
            return condition.get_var(condition.root)
        if condition.has_concatenation(condition.root):
            return condition.get_concatenation_vars(condition.root)
        raise ClassiqInternalExpansionError(
            f"Unexpected control condition {self.expression.expr!r}"
        )

    def get_control_vars_list(self) -> list[HandleBinding]:
        control_vars = self.get_control_vars()
        if isinstance(control_vars, HandleBinding):
            return [control_vars]
        return control_vars.basic_handles

    def get_control_var_names(self) -> list[str]:
        return list(map(str, self.get_control_vars_list()))
