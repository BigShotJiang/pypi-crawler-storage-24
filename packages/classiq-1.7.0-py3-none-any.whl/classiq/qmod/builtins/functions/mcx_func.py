from classiq.qmod.qfunc import qperm
from classiq.qmod.qmod_variable import Const, QArray, QBit


@qperm(external=True)
def mcx(ctrl: Const[QArray[QBit]], target: QBit) -> None:
    pass


@qperm(external=True)
def mcx_gray_code(ctrl: Const[QArray[QBit]], target: QBit) -> None:
    pass


@qperm(external=True)
def mcx_hybrid_rec(ctrl: Const[QArray[QBit]], target: QBit, aux: QArray[QBit]) -> None:
    pass


@qperm(external=True)
def mcx_hybrid_claudon_etal(
    ctrl: Const[QArray[QBit]], target: QBit, aux: QArray[QBit]
) -> None:
    pass


@qperm(external=True)
def mcx_hybrid_gray(ctrl: Const[QArray[QBit]], target: QBit, aux: QArray[QBit]) -> None:
    pass
