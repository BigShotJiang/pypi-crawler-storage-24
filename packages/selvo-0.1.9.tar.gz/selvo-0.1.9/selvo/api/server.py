"""
selvo REST API server (FastAPI).

Start:
    selvo-api                          # default: localhost:8765
    selvo-api --host 0.0.0.0 --port 8000
    selvo api --port 8000              # via CLI

All routes are under /api/v1/.

Endpoints
─────────
GET  /api/v1/packages            List packages from last snapshot (fast)
GET  /api/v1/packages/{name}     Full detail for one package
GET  /api/v1/cves                CVE listing filtered by CVSS / EPSS thresholds
GET  /api/v1/exploits            Packages with exploit availability data
GET  /api/v1/snapshot            Raw last-snapshot metadata
GET  /api/v1/diff                Diff current snapshot vs previous
POST /api/v1/analyze             Trigger a fresh pipeline run (slow, async)
GET  /api/v1/patch-plan          Ordered patch recommendations
GET  /api/v1/distro-compare      Cross-distro version comparison table
POST /api/v1/fleet/scan          SSH fleet scan

All successful responses are JSON. Long-running endpoints (POST /analyze,
POST /fleet/scan) return a 202 Accepted immediately with a job_id and
stream progress via GET /api/v1/jobs/{job_id}.
"""
from __future__ import annotations

import dataclasses
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Literal, Optional

log = logging.getLogger(__name__)

try:
    from fastapi import FastAPI, HTTPException, Query, BackgroundTasks, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False


# ── Job tracking (simple in-memory for single-process deploy) ─────────────────

_jobs: dict[str, dict[str, Any]] = {}


def _new_job(kind: str, params: dict) -> str:
    jid = str(uuid.uuid4())[:8]
    _jobs[jid] = {
        "id": jid,
        "kind": kind,
        "params": params,
        "status": "queued",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "result": None,
        "error": None,
    }
    return jid


# ── Request models ────────────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    ecosystem: str = Field("all", description="Ecosystem(s) to analyse")
    limit: int = Field(50, ge=1, le=200)
    context_mode: Literal["reference", "local", "auto"] = "reference"


class FleetScanRequest(BaseModel):
    hosts: list[str] = Field(..., description="host[:port] strings")
    username: str = ""
    key_file: Optional[str] = None
    ecosystem: str = "auto"


class ScanRequest(BaseModel):
    sbom: Optional[str] = Field(None, description="Path to CycloneDX/SPDX SBOM JSON")
    grype: Optional[str] = Field(None, description="Path to Grype JSON report")
    trivy: Optional[str] = Field(None, description="Path to Trivy JSON report")
    lockfile: Optional[str] = Field(None, description="Path to lock file (requirements.txt, package-lock.json, etc.)")
    run_cve: bool = Field(True, description="Run CVE + EPSS + CVSS enrichment")


class CheckoutRequest(BaseModel):
    org_id: str
    plan: str = Field("pro", pattern="^(pro|enterprise)$")
    success_url: str
    cancel_url: str


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> "FastAPI":
    if not _FASTAPI_AVAILABLE:
        raise RuntimeError(
            "FastAPI is not installed. Run: pip install 'selvo[api]'"
        )

    try:
        from importlib.metadata import version as _pkg_version
        _selvo_version = _pkg_version("selvo")
    except Exception:
        _selvo_version = "0.0.0+dev"

    app = FastAPI(
        title="selvo API",
        description="Linux dependency risk analysis as a REST service.",
        version=_selvo_version,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Optional API-key authentication middleware ──────────────────────────
    # Activated only when SELVO_API_AUTH=1 is set in the environment so that
    # single-user / local installs continue to work without any key setup.
    #
    # Skip rules (no auth required):
    #   - Exact paths: /docs, /redoc, /openapi.json, /api/v1/status, webhook
    #   - Any path under /dash/ — browser dashboard cannot send X-API-Key
    #
    # Master bypass: if SELVO_API_SECRET is set and the request presents it as
    # X-API-Key, it is granted enterprise access as the "system" org without a
    # DB lookup. Used by the daily analysis cron and admin scripts.

    _AUTH_SKIP_PATHS = frozenset({
        "/docs",
        "/redoc",
        "/openapi.json",
        "/api/v1/status",
        "/api/v1/billing/webhook",
    })

    if os.getenv("SELVO_API_AUTH"):
        from selvo.api.auth import verify_api_key as _verify_key, OrgContext as _OrgCtx

        _MASTER_SECRET = os.getenv("SELVO_API_SECRET", "")

        @app.middleware("http")
        async def _auth_middleware(request: Request, call_next):
            path = request.url.path
            # Dashboard is browser-only — skip API-key check entirely
            if path in _AUTH_SKIP_PATHS or path.startswith("/dash/"):
                return await call_next(request)
            api_key = request.headers.get("X-API-Key", "")
            if not api_key:
                return JSONResponse(
                    {"detail": "Missing X-API-Key header"},
                    status_code=401,
                )
            # Master bypass for internal/cron callers
            if _MASTER_SECRET and api_key == _MASTER_SECRET:
                request.state.org = _OrgCtx(org_id="system", plan="enterprise", key_id=0)
                return await call_next(request)
            ctx = _verify_key(api_key)
            if ctx is None:
                return JSONResponse(
                    {"detail": "Invalid, expired, or rate-limited API key"},
                    status_code=401,
                )
            request.state.org = ctx
            return await call_next(request)

    # ── helpers ───────────────────────────────────────────────────────────────

    def _pkg_to_dict(pkg: Any) -> dict:
        _strip = {"fix_refs", "dependents", "dependencies"}
        d = {k: v for k, v in dataclasses.asdict(pkg).items() if k not in _strip}
        d["is_outdated"] = pkg.is_outdated
        d["cve_count"] = pkg.cve_count
        return d

    def _get_snapshot_packages(ecosystem: str = "all") -> tuple[list[dict], float]:
        from selvo.analysis.cache import load_last_snapshot
        result = load_last_snapshot(ecosystem)
        if result is None:
            return [], 0.0
        pkgs, taken_at = result
        return pkgs, taken_at

    # ── / → dashboard redirect ────────────────────────────────────────────────

    from fastapi.responses import RedirectResponse as _RR

    @app.get("/", include_in_schema=False)
    async def root_redirect():
        return _RR(url="/dash/overview", status_code=302)

    # ── /api/v1/status ────────────────────────────────────────────────────────

    @app.get("/api/v1/status")
    async def status() -> dict:
        """Health check + server info."""
        return {
            "status": "ok",
            "service": "selvo",
            "version": _selvo_version,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }

    # ── /api/v1/snapshot ─────────────────────────────────────────────────────

    @app.get("/api/v1/snapshot")
    async def snapshot(ecosystem: str = Query("all")) -> dict:
        """Return the last cached analysis snapshot metadata."""
        pkgs, taken_at = _get_snapshot_packages(ecosystem)
        if not pkgs:
            raise HTTPException(
                status_code=404,
                detail=f"No snapshot for ecosystem '{ecosystem}'. POST /api/v1/analyze first.",
            )
        return {
            "ecosystem": ecosystem,
            "taken_at": datetime.fromtimestamp(taken_at, tz=timezone.utc).isoformat()
            if taken_at else None,
            "package_count": len(pkgs),
            "packages": pkgs,
        }

    # ── /api/v1/packages ─────────────────────────────────────────────────────

    @app.get("/api/v1/packages")
    async def list_packages(
        ecosystem: str = Query("all"),
        limit: int = Query(50, ge=1, le=500),
        min_score: float = Query(0.0, ge=0.0),
        min_cvss: float = Query(0.0, ge=0.0, le=10.0),
        has_cve: Optional[bool] = Query(None),
        exploit_maturity: Optional[str] = Query(None, description="none|poc|weaponized"),
        in_kev: Optional[bool] = Query(None),
    ) -> dict:
        """List packages from the last snapshot with optional filters."""
        pkgs, taken_at = _get_snapshot_packages(ecosystem)
        if not pkgs:
            raise HTTPException(status_code=404, detail=f"No snapshot for '{ecosystem}'.")

        # Apply filters
        filtered = pkgs
        if min_score > 0.0:
            filtered = [p for p in filtered if p.get("score", 0.0) >= min_score]
        if min_cvss > 0.0:
            filtered = [p for p in filtered if p.get("max_cvss", 0.0) >= min_cvss]
        if has_cve is not None:
            if has_cve:
                filtered = [p for p in filtered if p.get("cve_count", 0) > 0]
            else:
                filtered = [p for p in filtered if p.get("cve_count", 0) == 0]
        if exploit_maturity is not None:
            filtered = [p for p in filtered if p.get("exploit_maturity") == exploit_maturity]
        if in_kev is not None:
            filtered = [p for p in filtered if bool(p.get("in_cisa_kev")) == in_kev]

        return {
            "ecosystem": ecosystem,
            "total_matched": len(filtered),
            "packages": filtered[:limit],
        }

    # ── /api/v1/packages/{name} ───────────────────────────────────────────────

    @app.get("/api/v1/packages/{name}")
    async def get_package(name: str, ecosystem: str = Query("all")) -> dict:
        """Return full detail for one package by name."""
        pkgs, _ = _get_snapshot_packages(ecosystem)
        for p in pkgs:
            if p.get("name", "").lower() == name.lower():
                return p
        raise HTTPException(status_code=404, detail=f"Package '{name}' not found in snapshot.")

    # ── /api/v1/cves ─────────────────────────────────────────────────────────

    @app.get("/api/v1/cves")
    async def list_cves(
        ecosystem: str = Query("all"),
        min_cvss: float = Query(0.0, ge=0.0, le=10.0),
        min_epss: float = Query(0.0, ge=0.0, le=1.0),
        limit: int = Query(100, ge=1, le=1000),
    ) -> dict:
        """List CVE IDs with associated package and severity info."""
        pkgs, _ = _get_snapshot_packages(ecosystem)
        rows: list[dict] = []
        for p in pkgs:
            if not p.get("cve_ids"):
                continue
            if p.get("max_cvss", 0.0) < min_cvss:
                continue
            if p.get("max_epss", 0.0) < min_epss:
                continue
            for cve in p["cve_ids"]:
                rows.append({
                    "cve_id": cve,
                    "package": p["name"],
                    "ecosystem": p.get("ecosystem", ecosystem),
                    "max_cvss": p.get("max_cvss", 0.0),
                    "max_epss": p.get("max_epss", 0.0),
                    "exploit_maturity": p.get("exploit_maturity", "none"),
                    "in_cisa_kev": p.get("in_cisa_kev", False),
                    "package_score": p.get("score", 0.0),
                })
        rows.sort(key=lambda r: (r["max_epss"], r["max_cvss"]), reverse=True)
        return {"total": len(rows), "cves": rows[:limit]}

    # ── /api/v1/exploits ─────────────────────────────────────────────────────

    @app.get("/api/v1/exploits")
    async def list_exploits(
        ecosystem: str = Query("all"),
        maturity: Optional[str] = Query(None, description="poc|weaponized"),
        kev_only: bool = Query(False),
    ) -> dict:
        """Return packages with exploit data."""
        pkgs, _ = _get_snapshot_packages(ecosystem)
        exploitable = [
            p for p in pkgs
            if p.get("has_public_exploit") or p.get("in_cisa_kev")
        ]
        if maturity:
            exploitable = [p for p in exploitable if p.get("exploit_maturity") == maturity]
        if kev_only:
            exploitable = [p for p in exploitable if p.get("in_cisa_kev")]
        return {
            "total": len(exploitable),
            "kev_count": sum(1 for p in exploitable if p.get("in_cisa_kev")),
            "packages": exploitable,
        }

    # ── /api/v1/patch-plan ────────────────────────────────────────────────────

    @app.get("/api/v1/patch-plan")
    async def patch_plan(
        ecosystem: str = Query("all"),
        limit: int = Query(20, ge=1, le=100),
        min_score: float = Query(10.0),
    ) -> dict:
        """Return an ordered patch plan from the last snapshot."""
        pkgs, _ = _get_snapshot_packages(ecosystem)
        actionable = [
            p for p in pkgs
            if p.get("score", 0.0) >= min_score
            and (p.get("cve_count", 0) > 0 or p.get("is_outdated"))
        ]
        actionable.sort(key=lambda p: p.get("score", 0.0), reverse=True)
        plan = []
        for p in actionable[:limit]:
            plan.append({
                "package": p["name"],
                "current_version": p.get("version", "unknown"),
                "upstream_version": p.get("upstream_version"),
                "score": p.get("score", 0.0),
                "cve_count": p.get("cve_count", 0),
                "max_epss": p.get("max_epss", 0.0),
                "exploit_maturity": p.get("exploit_maturity", "none"),
                "in_cisa_kev": p.get("in_cisa_kev", False),
                "patch_safety": p.get("patch_safety_score", 0.0),
                "regression_risk": p.get("patch_regression_risk", ""),
                "distro_patch_dates": p.get("distro_patch_dates", {}),
            })
        return {"total": len(plan), "patch_plan": plan}

    # ── /api/v1/diff ─────────────────────────────────────────────────────────

    @app.get("/api/v1/diff")
    async def get_diff(ecosystem: str = Query("all")) -> dict:
        """Show what changed since the previous snapshot."""
        from selvo.analysis.cache import load_last_snapshot
        # We need to peek at the second-most-recent snapshot — for now return
        # the diff metadata stored in the most recent snapshot (approximate)
        result = load_last_snapshot(ecosystem)
        if result is None:
            raise HTTPException(status_code=404, detail="No snapshot found.")
        pkgs, taken_at = result
        return {
            "ecosystem": ecosystem,
            "note": "POST /api/v1/analyze to refresh and get a live diff",
            "snapshot_taken_at": datetime.fromtimestamp(taken_at, tz=timezone.utc).isoformat()
            if taken_at else None,
            "package_count": len(pkgs),
        }

    # ── POST /api/v1/analyze ─────────────────────────────────────────────────

    @app.post("/api/v1/analyze", status_code=202)
    async def analyze(req: AnalyzeRequest, background_tasks: BackgroundTasks) -> dict:
        """
        Trigger a fresh full pipeline run.

        Returns immediately with a job_id. Poll GET /api/v1/jobs/{job_id}
        for status. This takes 1–3 minutes.
        """
        from selvo.mcp_server import _run_pipeline

        jid = _new_job("analyze", req.model_dump())

        async def _run() -> None:
            _jobs[jid]["status"] = "running"
            try:
                packages = await _run_pipeline(
                    ecosystem=req.ecosystem,
                    limit=req.limit,
                    context_mode=req.context_mode,
                    run_cve=True,
                )
                _jobs[jid]["status"] = "done"
                _jobs[jid]["result"] = {
                    "total_packages": len(packages),
                    "with_cves": sum(1 for p in packages if p.cve_count > 0),
                    "top_5": [
                        {"name": p.name, "score": p.score, "cve_count": p.cve_count}
                        for p in packages[:5]
                    ],
                }
            except Exception as exc:
                _jobs[jid]["status"] = "error"
                _jobs[jid]["error"] = str(exc)

        background_tasks.add_task(_run)

        return {
            "job_id": jid,
            "status": "queued",
            "poll_url": f"/api/v1/jobs/{jid}",
            "note": "Analysis takes 1–3 minutes. Poll poll_url for completion.",
        }

    # ── GET /api/v1/jobs/{job_id} ─────────────────────────────────────────────

    @app.get("/api/v1/jobs/{job_id}")
    async def get_job(job_id: str) -> dict:
        """Poll analyze/fleet-scan job status."""
        if job_id not in _jobs:
            raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
        return _jobs[job_id]

    # ── POST /api/v1/fleet/scan ───────────────────────────────────────────────

    @app.post("/api/v1/fleet/scan", status_code=202)
    async def fleet_scan(req: FleetScanRequest, background_tasks: BackgroundTasks) -> dict:
        """Scan a fleet of SSH hosts for installed packages and CVE exposure."""
        jid = _new_job("fleet_scan", req.model_dump())

        async def _run() -> None:
            _jobs[jid]["status"] = "running"
            try:
                from selvo.analysis.fleet import scan_fleet, MachineSpec

                specs = [
                    MachineSpec(
                        host=h.split(":")[0],
                        port=int(h.split(":")[1]) if ":" in h else 22,
                        username=req.username or None,
                        key_file=req.key_file,
                        ecosystem=req.ecosystem,
                    )
                    for h in req.hosts
                ]
                results = await scan_fleet(specs)
                _jobs[jid]["status"] = "done"
                _jobs[jid]["result"] = [
                    {
                        "host": r.host,
                        "package_count": r.package_count,
                        "cve_count": r.cve_count,
                        "top_risks": r.top_risks,
                        "error": r.error,
                    }
                    for r in results
                ]
            except Exception as exc:
                _jobs[jid]["status"] = "error"
                _jobs[jid]["error"] = str(exc)

        background_tasks.add_task(_run)
        return {"job_id": jid, "status": "queued", "poll_url": f"/api/v1/jobs/{jid}"}

    # ── /api/v1/sla ───────────────────────────────────────────────────────────

    @app.get("/api/v1/sla")
    async def sla_report(
        ecosystem: str = Query("all"),
        critical_days: int = Query(7),
        high_days: int = Query(30),
        medium_days: int = Query(60),
        low_days: int = Query(90),
    ) -> dict:
        """Return an SLA breach report based on CVSS severity and CVE age."""
        from selvo.analysis.sla import SLAPolicy, enrich_sla, sla_report as _sla_report
        from selvo.discovery.base import PackageRecord

        pkgs, taken_at = _get_snapshot_packages(ecosystem)
        if not pkgs:
            raise HTTPException(status_code=404, detail=f"No snapshot for '{ecosystem}'.")

        packages = [
            PackageRecord(
                name=p["name"],
                ecosystem=p.get("ecosystem", ecosystem),
                version=p.get("version", "unknown"),
                max_cvss=p.get("max_cvss", 0.0),
                max_epss=p.get("max_epss", 0.0),
                cve_ids=p.get("cve_ids", []),
                in_cisa_kev=p.get("in_cisa_kev", False),
                exposure_days=p.get("exposure_days", 0),
                cve_disclosed_at=p.get("cve_disclosed_at", ""),
            )
            for p in pkgs
        ]
        policy = SLAPolicy(critical=critical_days, high=high_days, medium=medium_days, low=low_days)
        packages = enrich_sla(packages, policy)
        report = _sla_report(packages)
        report["ecosystem"] = ecosystem
        report["snapshot_taken_at"] = (
            datetime.fromtimestamp(taken_at, tz=timezone.utc).isoformat() if taken_at else None
        )
        return report

    # ── /api/v1/advisories ────────────────────────────────────────────────────

    @app.get("/api/v1/advisories")
    async def list_advisories(
        ecosystem: str = Query("all"),
        limit: int = Query(50, ge=1, le=500),
    ) -> dict:
        """Return packages that have vendor-issued security advisories (USN, Bodhi)."""
        pkgs, taken_at = _get_snapshot_packages(ecosystem)
        if not pkgs:
            raise HTTPException(status_code=404, detail=f"No snapshot for '{ecosystem}'.")

        with_advisories = [
            {
                "package": p["name"],
                "version": p.get("version", "unknown"),
                "advisory_ids": p.get("vendor_advisory_ids", []),
                "cve_ids": p.get("cve_ids", [])[:5],
                "score": p.get("score", 0.0),
            }
            for p in pkgs
            if p.get("vendor_advisory_ids")
        ]
        with_advisories.sort(key=lambda r: len(r["advisory_ids"]), reverse=True)
        return {
            "ecosystem": ecosystem,
            "total": len(with_advisories),
            "packages": with_advisories[:limit],
        }

    # ── GET /api/v1/report.sarif ──────────────────────────────────────────────

    @app.get("/api/v1/report.sarif", response_class=JSONResponse)
    async def report_sarif(ecosystem: str = Query("all")) -> JSONResponse:
        """Export last snapshot as SARIF 2.1.0 for GitHub Code Scanning upload."""
        import json
        from selvo.reporters.sarif import render_sarif
        from selvo.discovery.base import PackageRecord

        pkgs, _ = _get_snapshot_packages(ecosystem)
        if not pkgs:
            raise HTTPException(status_code=404, detail=f"No snapshot for '{ecosystem}'.")

        packages = [PackageRecord(**{k: v for k, v in p.items() if k not in ("is_outdated", "cve_count")}) for p in pkgs]
        sarif_json = render_sarif(packages)
        return JSONResponse(content=json.loads(sarif_json), media_type="application/sarif+json")

    # ── GET /api/v1/report.vex ────────────────────────────────────────────────

    @app.get("/api/v1/report.vex", response_class=JSONResponse)
    async def report_vex(ecosystem: str = Query("all")) -> JSONResponse:
        """Export last snapshot as CycloneDX 1.4 VEX document."""
        import json
        from selvo.reporters.vex import render_vex
        from selvo.discovery.base import PackageRecord

        pkgs, _ = _get_snapshot_packages(ecosystem)
        if not pkgs:
            raise HTTPException(status_code=404, detail=f"No snapshot for '{ecosystem}'.")

        packages = [PackageRecord(**{k: v for k, v in p.items() if k not in ("is_outdated", "cve_count")}) for p in pkgs]
        vex_json = render_vex(packages)
        return JSONResponse(content=json.loads(vex_json), media_type="application/vnd.cyclonedx+json")

    # ── POST /api/v1/scan ─────────────────────────────────────────────────────

    @app.post("/api/v1/scan", status_code=202)
    async def scan(req: ScanRequest, background_tasks: BackgroundTasks) -> dict:
        """
        Scan a SBOM, scanner report, or lock file through the selvo pipeline.

        Accepts a file path on the server filesystem. Returns a job_id to poll.
        """
        jid = _new_job("scan", req.model_dump())

        async def _run() -> None:
            _jobs[jid]["status"] = "running"
            try:
                if req.sbom:
                    from selvo.discovery.sbom_input import load_sbom
                    packages = load_sbom(req.sbom)
                elif req.grype:
                    from selvo.discovery.scanner_import import load_grype
                    packages = load_grype(req.grype)
                elif req.trivy:
                    from selvo.discovery.scanner_import import load_trivy
                    packages = load_trivy(req.trivy)
                elif req.lockfile:
                    from selvo.discovery.lockfile import load_lockfile
                    packages = load_lockfile(req.lockfile)
                else:
                    _jobs[jid]["status"] = "error"
                    _jobs[jid]["error"] = "Provide sbom, grype, trivy, or lockfile."
                    return

                if req.run_cve:
                    from selvo.analysis.cve import enrich_cve
                    from selvo.analysis.epss import enrich_epss
                    from selvo.analysis.cvss import enrich_cvss
                    packages = await enrich_cve(packages)
                    packages = await enrich_epss(packages)
                    packages = await enrich_cvss(packages)

                from selvo.prioritizer.scorer import score_and_rank
                ranked = score_and_rank(packages)

                _jobs[jid]["status"] = "done"
                _jobs[jid]["result"] = {
                    "total_packages": len(ranked),
                    "with_cves": sum(1 for p in ranked if p.cve_count > 0),
                    "kev_count": sum(1 for p in ranked if p.in_cisa_kev),
                    "top_10": [_pkg_to_dict(p) for p in ranked[:10]],
                }
            except Exception as exc:
                _jobs[jid]["status"] = "error"
                _jobs[jid]["error"] = str(exc)

        background_tasks.add_task(_run)
        return {"job_id": jid, "status": "queued", "poll_url": f"/api/v1/jobs/{jid}"}

    # ── Org management (requires SELVO_API_AUTH) ──────────────────────────────

    @app.post("/api/v1/orgs", status_code=201)
    async def create_org(body: dict) -> dict:
        """Register a new organisation and return its first API key.

        Request body: ``{"org_id": "...", "name": "...", "email": "...", "plan": "free"}``

        The API key is returned **once** in plaintext — store it immediately.
        """
        from selvo.api.auth import register_org, generate_api_key

        org_id = (body.get("org_id") or "").strip()
        if not org_id:
            raise HTTPException(status_code=422, detail="org_id is required")
        plan = body.get("plan", "free")
        if plan not in ("free", "pro", "enterprise"):
            raise HTTPException(status_code=422, detail="plan must be free | pro | enterprise")

        register_org(
            org_id,
            name=body.get("name", org_id),
            email=body.get("email", ""),
            plan=plan,
        )
        key = generate_api_key(org_id, plan=plan)
        return {"org_id": org_id, "plan": plan, "api_key": key}

    @app.get("/api/v1/orgs/{org_id}/keys")
    async def list_org_api_keys(org_id: str) -> dict:
        """List metadata for all API keys belonging to *org_id*."""
        from selvo.api.auth import list_org_keys
        return {"org_id": org_id, "keys": list_org_keys(org_id)}

    @app.post("/api/v1/orgs/{org_id}/keys", status_code=201)
    async def create_org_api_key(org_id: str, body: dict) -> dict:
        """Generate an additional API key for an existing org."""
        from selvo.api.auth import generate_api_key, _get_conn, _lock

        with _lock:
            row = _get_conn().execute(
                "SELECT plan FROM orgs WHERE org_id=?", (org_id,)
            ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail=f"Org '{org_id}' not found")

        plan = body.get("plan", row[0])
        key = generate_api_key(org_id, plan=plan)
        return {"org_id": org_id, "plan": plan, "api_key": key}

    @app.delete("/api/v1/orgs/{org_id}/keys/{key_hash}", status_code=204)
    async def revoke_org_api_key(org_id: str, key_hash: str) -> None:
        """Deactivate a specific API key by its SHA-256 hash."""
        from selvo.api.auth import revoke_api_key
        if not revoke_api_key(key_hash):
            raise HTTPException(status_code=404, detail="Key not found or already revoked")

    # ── Stripe billing webhook ────────────────────────────────────────────────

    # ── POST /api/v1/billing/checkout ────────────────────────────────────────

    @app.post("/api/v1/billing/checkout", status_code=200)
    async def create_checkout(req: CheckoutRequest) -> dict:
        """Create a Stripe Checkout session. Returns ``{url, session_id}``.

        Redirect the user to ``url`` to complete payment.
        """
        from selvo.api.billing import create_checkout_session, StripeConfigError
        try:
            session = create_checkout_session(
                org_id=req.org_id,
                plan=req.plan,
                success_url=req.success_url,
                cancel_url=req.cancel_url,
            )
        except StripeConfigError as exc:
            raise HTTPException(status_code=503, detail=str(exc))
        except Exception as exc:
            log.error("Stripe checkout creation failed: %s", exc)
            raise HTTPException(status_code=502, detail=f"Stripe error: {exc}")
        return {"url": session["url"], "session_id": session["id"]}

    @app.post("/api/v1/billing/webhook", status_code=200)
    async def stripe_webhook(
        request: "Request",
        background_tasks: BackgroundTasks,
    ) -> dict:
        """Receive and verify Stripe webhook events (v1 and v2).

        v1 (classic): full event in payload, signed with ``whsec_…``.
        v2 (thin events): thin envelope in payload; full event fetched via API.
        Verifies the ``Stripe-Signature`` header using HMAC-SHA256.
        Processes the event asynchronously so Stripe receives a fast 200.
        """
        from selvo.api.billing import (
            verify_stripe_signature, handle_stripe_event,
            fetch_stripe_event, StripeWebhookError,
        )
        import json as _json

        payload = await request.body()
        sig_header = request.headers.get("Stripe-Signature", "")
        webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET", "")

        try:
            api_version = verify_stripe_signature(payload, sig_header, webhook_secret)
        except StripeWebhookError as exc:
            log.warning("Invalid Stripe webhook: %s", exc)
            raise HTTPException(status_code=400, detail=str(exc))

        try:
            envelope = _json.loads(payload)
        except ValueError:
            raise HTTPException(status_code=400, detail="Webhook payload is not valid JSON")

        # v2 thin events: payload is a thin envelope; fetch full event from API.
        if api_version == "v2":
            event_id = envelope.get("id", "")
            if not event_id:
                raise HTTPException(status_code=400, detail="v2 thin event missing id field")
            try:
                event = fetch_stripe_event(event_id)
            except Exception as exc:
                log.error("Failed to hydrate v2 thin event %s: %s", event_id, exc)
                raise HTTPException(status_code=502, detail="Could not fetch full event from Stripe")
        else:
            event = envelope

        background_tasks.add_task(handle_stripe_event, event)
        return {"received": True, "event_type": event.get("type", "unknown"), "api_version": api_version}

    # ── Dashboard (Jinja2 + htmx) ─────────────────────────────────────────────

    from fastapi.responses import HTMLResponse, RedirectResponse

    try:
        from selvo.api import dashboard as _dash
        _DASH_AVAILABLE = True
    except ImportError:
        _DASH_AVAILABLE = False

    _DASH_ORG = os.getenv("SELVO_DASH_ORG", "default")

    def _dash_packages(request: Request, ecosystem: str) -> tuple[list[dict], float]:
        """Return snapshot packages scoped to the authenticated org when auth is active."""
        org = getattr(request.state, "org", None)
        if org is not None:
            from selvo.api.tenancy import load_org_snapshot
            result = load_org_snapshot(org.org_id, ecosystem)
            return result if result is not None else ([], 0.0)
        return _get_snapshot_packages(ecosystem)

    def _dash_metrics(request: Request, ecosystem: str, days: int = 90) -> list[dict]:
        """Return trend metrics scoped to the authenticated org when auth is active."""
        from selvo.analysis.trend import load_metrics
        org = getattr(request.state, "org", None)
        if org is not None:
            from selvo.api.tenancy import org_ecosystem_key
            return load_metrics(org_ecosystem_key(org.org_id, ecosystem), days=days)
        return load_metrics(ecosystem, days=days)

    def _dash_org_id(request: Request) -> str:
        """Return the org_id for dashboard key management pages."""
        org = getattr(request.state, "org", None)
        return org.org_id if org is not None else _DASH_ORG

    @app.get("/dash", response_class=RedirectResponse, include_in_schema=False)
    async def dash_root():
        return RedirectResponse(url="/dash/overview")

    @app.get("/dash/overview", response_class=HTMLResponse, include_in_schema=False)
    async def dash_overview(request: Request, ecosystem: str = "all"):
        if not _DASH_AVAILABLE:
            return HTMLResponse("<h1>Dashboard unavailable</h1>", status_code=503)
        pkgs, taken_at = _dash_packages(request, ecosystem)
        return HTMLResponse(_dash.render_overview(pkgs, taken_at))

    @app.get("/dash/packages", response_class=HTMLResponse, include_in_schema=False)
    async def dash_packages(request: Request, ecosystem: str = "all", q: str = ""):
        if not _DASH_AVAILABLE:
            return HTMLResponse("<h1>Dashboard unavailable</h1>", status_code=503)
        pkgs, _ = _dash_packages(request, ecosystem)
        # htmx partial swap — return only the table div when hx-request header present
        page = _dash.render_packages(pkgs, query=q)
        return HTMLResponse(page)

    @app.get("/dash/cves", response_class=HTMLResponse, include_in_schema=False)
    async def dash_cves(request: Request, ecosystem: str = "all"):
        if not _DASH_AVAILABLE:
            return HTMLResponse("<h1>Dashboard unavailable</h1>", status_code=503)
        pkgs, _ = _dash_packages(request, ecosystem)
        return HTMLResponse(_dash.render_cves(pkgs))

    @app.get("/dash/trends", response_class=HTMLResponse, include_in_schema=False)
    async def dash_trends(request: Request, ecosystem: str = "all"):
        if not _DASH_AVAILABLE:
            return HTMLResponse("<h1>Dashboard unavailable</h1>", status_code=503)
        try:
            metrics = _dash_metrics(request, ecosystem, days=90)
        except Exception:
            metrics = []
        return HTMLResponse(_dash.render_trends(metrics))

    @app.get("/dash/keys", response_class=HTMLResponse, include_in_schema=False)
    async def dash_keys(request: Request):
        if not _DASH_AVAILABLE:
            return HTMLResponse("<h1>Dashboard unavailable</h1>", status_code=503)
        org_id = _dash_org_id(request)
        try:
            from selvo.api.auth import list_org_keys, register_org
            register_org(org_id, name=org_id, plan="free")
            keys = list_org_keys(org_id)
        except Exception:
            keys = []
        return HTMLResponse(_dash.render_keys(org_id, keys))

    @app.post("/dash/keys", response_class=HTMLResponse, include_in_schema=False)
    async def dash_create_key(request: Request):
        from fastapi.responses import HTMLResponse
        form = await request.form()
        # org_id from the form is advisory only; authenticated org always takes priority
        org_id = _dash_org_id(request) or str(form.get("org_id", _DASH_ORG))
        plan = str(form.get("plan", "pro"))
        try:
            from selvo.api.auth import register_org, generate_api_key, list_org_keys
            register_org(org_id, name=org_id, plan=plan)
            key = generate_api_key(org_id, plan=plan)
            keys = list_org_keys(org_id)
            return HTMLResponse(_dash.render_new_key_result(org_id, key, keys))
        except Exception as exc:
            return HTMLResponse(f'<div class="alert alert-danger">Error: {exc}</div>')

    @app.post("/dash/keys/revoke", response_class=HTMLResponse, include_in_schema=False)
    async def dash_revoke_key(request: Request):
        form = await request.form()
        key_hash = str(form.get("key_hash", ""))
        # Never trust org_id from the form when auth is active — use the session org.
        org_id = _dash_org_id(request) or str(form.get("org_id", _DASH_ORG))
        try:
            from selvo.api.auth import revoke_api_key, list_org_keys
            revoke_api_key(key_hash)
            keys = list_org_keys(org_id)
        except Exception:
            keys = []
        return HTMLResponse(_dash.render_keys(org_id, keys, message="Key revoked."))

    @app.get("/dash/_refresh_badge", response_class=HTMLResponse, include_in_schema=False)
    async def dash_refresh_badge():
        return HTMLResponse(
            f'<span class="text-muted" hx-get="/dash/_refresh_badge" '
            f'hx-trigger="every 60s" hx-swap="outerHTML">'
            f'(refreshed {datetime.now(timezone.utc).strftime("%H:%M")} UTC)</span>'
        )

    @app.get("/dash/billing", response_class=HTMLResponse, include_in_schema=False)
    async def dash_billing(request: Request):
        plan = getattr(getattr(request.state, "org", None), "plan", "free") or "free"
        return HTMLResponse(_dash.render_billing(plan))

    @app.post("/dash/billing/checkout", response_class=HTMLResponse, include_in_schema=False)
    async def dash_billing_checkout(request: Request):
        from selvo.api.billing import create_checkout_session
        form = await request.form()
        plan = str(form.get("plan", "pro"))
        org_id = getattr(getattr(request.state, "org", None), "org_id", "anonymous") or "anonymous"
        try:
            session = create_checkout_session(
                org_id=org_id,
                plan=plan,
                success_url="https://selvo.fly.dev/dash/billing?success=1",
                cancel_url="https://selvo.fly.dev/dash/billing",
            )
            url = session.get("url", "")
            return HTMLResponse(f'<script>window.location="{url}"</script>')
        except Exception as exc:  # noqa: BLE001
            return HTMLResponse(f'<div class="alert alert-danger mt-2">{exc}</div>')

    return app


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    """selvo-api entrypoint."""
    import argparse

    if not _FASTAPI_AVAILABLE:
        print("FastAPI is not installed. Run: pip install 'selvo[api]'")
        raise SystemExit(1)

    parser = argparse.ArgumentParser(prog="selvo-api", description="selvo REST API server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--reload", action="store_true", help="Enable hot-reload (dev only)")
    parser.add_argument("--log-level", default="info")
    args = parser.parse_args()

    app = create_app()
    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=args.log_level,
    )


if __name__ == "__main__":
    main()
