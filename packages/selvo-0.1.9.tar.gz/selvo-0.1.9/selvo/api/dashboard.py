"""Server-side web dashboard for selvo SaaS.

Rendered with Jinja2 + htmx — no client-side build step required.

Routes (all under /dash/):
    GET  /dash/            → redirect to /dash/overview
    GET  /dash/overview    → summary cards + top-10 risk table, HTMX live-reload
    GET  /dash/packages    → filterable package table (htmx-powered search)
    GET  /dash/cves        → CVE listing with EPSS + KEV badges
    GET  /dash/trends      → sparkline time-series chart (SVG inline)
    GET  /dash/keys        → org API key management UI
    POST /dash/keys        → create a new API key
    POST /dash/keys/revoke → deactivate a key

All pages share a minimal Bootstrap 5 + htmx layout injected as a string
constant so the server has zero static-file dependencies.
"""
from __future__ import annotations

import html as _html
import logging
from datetime import datetime, timezone


def _esc(value: object) -> str:
    """HTML-escape a value for safe embedding in templates."""
    return _html.escape(str(value))

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Inline layout template
# If SELVO_OFFLINE_ASSETS=1 (e.g. air-gap / DoD IL4 environments), all
# external CDN links are replaced with a minimal inline CSS fallback so the
# dashboard renders without any outbound network requests.
# ---------------------------------------------------------------------------

_OFFLINE = bool(int(__import__("os").environ.get("SELVO_OFFLINE_ASSETS", "0")))

_CDN_HEAD = """\
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet" crossorigin="anonymous">
  <script src="https://unpkg.com/htmx.org@1.9.12/dist/htmx.min.js"
          crossorigin="anonymous"></script>"""

_OFFLINE_HEAD = """\
  <style>
    /* Minimal offline layout — no Bootstrap, no CDN */
    *{{box-sizing:border-box;margin:0;padding:0}}
    body{{font:14px/1.5 ui-sans-serif,system-ui,sans-serif;padding:1rem 1.5rem}}
    .container-fluid{{max-width:1400px;margin:0 auto}}
    nav{{display:flex;gap:1.5rem;padding:.75rem 0;border-bottom:1px solid #30363d;margin-bottom:1.5rem;flex-wrap:wrap}}
    nav a{{text-decoration:none;color:#58a6ff;font-weight:600}}nav a:hover{{text-decoration:underline}}
    table{{border-collapse:collapse;width:100%}}
    th,td{{border:1px solid #30363d;padding:.4rem .7rem;text-align:left;font-size:.82rem}}
    th{{background:#21262d;font-weight:700}}
    input[type=text]{{padding:.3rem .6rem;border:1px solid #555;border-radius:4px;font:inherit}}
    .badge{{display:inline-block;padding:.1rem .4rem;border-radius:4px;font-size:.72rem;border:1px solid}}
    pre{{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:.75rem;font-size:.8rem;overflow-x:auto}}
  </style>
  <script>
    /* Minimal htmx substitute for offline mode — reloads target via fetch */
    document.addEventListener('DOMContentLoaded',()=>{{
      document.querySelectorAll('[hx-get]').forEach(el=>{{
        el.addEventListener('change',async()=>{{
          const url=el.getAttribute('hx-get');const target=document.querySelector(el.getAttribute('hx-target')||'body');
          if(!url||!target)return;
          const resp=await fetch(url);target.innerHTML=await resp.text();
        }});
      }});
    }});
  </script>"""

_CDN_FOOTER = """\
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>"""

_HEAD = """\
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title} — selvo</title>
{cdn_or_offline}
  <style>
    body {{ background:#0d1117; color:#e6edf3; }}
    .navbar {{ background:#161b22!important; border-bottom:1px solid #30363d; }}
    .card  {{ background:#161b22; border:1px solid #30363d; }}
    .table {{ color:#e6edf3; }}
    .table thead {{ background:#21262d; }}
    .badge-kev  {{ background:#da3633; }}
    .badge-poc  {{ background:#d29922; color:#0d1117; }}
    .badge-wpn  {{ background:#da3633; }}
    .score-bar  {{ height:6px; border-radius:3px; background:#238636; }}
    .epss-high  {{ color:#f85149; font-weight:600; }}
    .epss-med   {{ color:#d29922; }}
    .nav-link {{ color:#8b949e; }}
    .nav-link:hover,.nav-link.active {{ color:#58a6ff; }}
    .stat-card .display-6 {{ font-size:2rem; font-weight:700; }}
    pre {{ background:#161b22; border:1px solid #30363d; border-radius:6px;
           padding:.75rem; color:#8b949e; font-size:.8rem; }}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg mb-4">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold text-info" href="/dash/overview">⚡ selvo</a>
    <div class="navbar-nav ms-3">
      <a class="nav-link" href="/dash/overview">Overview</a>
      <a class="nav-link" href="/dash/packages">Packages</a>
      <a class="nav-link" href="/dash/cves">CVEs</a>
      <a class="nav-link" href="/dash/trends">Trends</a>
      <a class="nav-link" href="/dash/keys">API Keys</a>
      <a class="nav-link" href="/dash/billing">Billing</a>
      <a class="nav-link ms-3" href="/docs">API Docs ↗</a>
    </div>
  </div>
</nav>
<div class="container-fluid px-4">
{body}
</div>
{cdn_footer}
</body>
</html>"""


def _page(title: str, body: str) -> str:
    cdn_or_offline = _OFFLINE_HEAD if _OFFLINE else _CDN_HEAD
    cdn_footer = "" if _OFFLINE else _CDN_FOOTER
    return _HEAD.format(title=title, body=body,
                        cdn_or_offline=cdn_or_offline, cdn_footer=cdn_footer)


def _badge_kev() -> str:
    return '<span class="badge badge-kev">KEV</span>'


def _badge_epss(score: float) -> str:
    pct = f"{score * 100:.1f}%"
    cls = "epss-high" if score >= 0.1 else "epss-med" if score >= 0.01 else "text-muted"
    return f'<span class="{cls}">{pct}</span>'


def _cvss_bar(score: float) -> str:
    color = "#f85149" if score >= 9 else "#d29922" if score >= 7 else "#3fb950"
    pct = int(score / 10 * 100)
    return (
        f'<div title="CVSS {score:.1f}" style="width:{pct}%;height:6px;'
        f'border-radius:3px;background:{color}"></div>'
    )


# ---------------------------------------------------------------------------
# Page renderers
# ---------------------------------------------------------------------------

def render_overview(packages: list[dict], taken_at: float | None) -> str:
    total = len(packages)
    with_cve = sum(1 for p in packages if p.get("cve_count", 0) > 0)
    kev_count = sum(1 for p in packages if p.get("in_cisa_kev"))
    weaponized = sum(1 for p in packages if p.get("exploit_maturity") == "weaponized")
    snap_str = (
        datetime.fromtimestamp(taken_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        if taken_at else "no snapshot yet"
    )

    top10 = sorted(packages, key=lambda p: p.get("score", 0.0), reverse=True)[:10]

    rows = ""
    for i, p in enumerate(top10, 1):
        kev = _badge_kev() if p.get("in_cisa_kev") else ""
        maturity = p.get("exploit_maturity", "none")
        mat_badge = (
            '<span class="badge badge-wpn">Weaponized</span>' if maturity == "weaponized"
            else '<span class="badge badge-poc">PoC</span>' if maturity == "poc"
            else ""
        )
        rows += f"""
        <tr>
          <td class="text-muted">{i}</td>
          <td><a href="/dash/packages?q={_esc(p['name'])}" class="text-info fw-bold">{_esc(p['name'])}</a></td>
          <td><code>{_esc(p.get('version','?'))}</code></td>
          <td>{_cvss_bar(p.get('max_cvss',0))} <small>{p.get('max_cvss',0):.1f}</small></td>
          <td>{_badge_epss(p.get('max_epss',0))}</td>
          <td>{p.get('cve_count',0)}</td>
          <td>{kev} {mat_badge}</td>
          <td>{p.get('score',0):.1f}</td>
        </tr>"""

    body = f"""
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card p-3 stat-card text-center">
      <div class="display-6 text-info">{total}</div>
      <small class="text-muted">Packages tracked</small>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card p-3 stat-card text-center">
      <div class="display-6 text-warning">{with_cve}</div>
      <small class="text-muted">With CVEs</small>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card p-3 stat-card text-center">
      <div class="display-6 text-danger">{kev_count}</div>
      <small class="text-muted">In CISA KEV</small>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card p-3 stat-card text-center">
      <div class="display-6 text-danger">{weaponized}</div>
      <small class="text-muted">Weaponized exploits</small>
    </div>
  </div>
</div>
<div class="d-flex justify-content-between align-items-center mb-2">
  <h5 class="mb-0">Top 10 Highest-Risk Packages</h5>
  <small class="text-muted">Snapshot: {snap_str}
    <span hx-get="/dash/_refresh_badge" hx-trigger="every 60s" hx-swap="outerHTML"></span>
  </small>
</div>
<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>#</th><th>Package</th><th>Version</th>
          <th>CVSS</th><th>EPSS</th><th>CVEs</th><th>Threat</th><th>Score</th>
        </tr>
      </thead>
      <tbody>{rows}</tbody>
    </table>
  </div>
</div>
<div class="mt-3">
  <a href="/dash/packages" class="btn btn-outline-info btn-sm">View all packages →</a>
  <a href="/api/v1/report.sarif" class="btn btn-outline-secondary btn-sm ms-2">Download SARIF</a>
  <a href="/api/v1/report.vex" class="btn btn-outline-secondary btn-sm ms-2">Download VEX</a>
</div>"""

    return _page("Overview", body)


def render_packages(packages: list[dict], query: str = "") -> str:
    if query:
        packages = [p for p in packages if query.lower() in p.get("name", "").lower()]

    rows = ""
    for p in packages:
        kev = _badge_kev() if p.get("in_cisa_kev") else ""
        rows += f"""
        <tr>
          <td><strong>{_esc(p['name'])}</strong></td>
          <td><code>{_esc(p.get('ecosystem','?'))}</code></td>
          <td><code>{_esc(p.get('version','?'))}</code></td>
          <td>{p.get('max_cvss',0):.1f}</td>
          <td>{_badge_epss(p.get('max_epss',0))}</td>
          <td>{p.get('cve_count',0)}</td>
          <td>{p.get('transitive_rdep_count',0):,}</td>
          <td>{kev}</td>
          <td>{p.get('score',0):.1f}</td>
        </tr>"""

    body = f"""
<h5 class="mb-3">Packages</h5>
<div class="card mb-3">
  <div class="card-body pb-0">
    <input class="form-control bg-dark text-light border-secondary"
           placeholder="Filter by name…"
           name="q" value="{_esc(query)}"
           hx-get="/dash/packages"
           hx-trigger="keyup changed delay:300ms"
           hx-target="#pkg-table"
           hx-push-url="true">
  </div>
</div>
<div id="pkg-table">
<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>Package</th><th>Ecosystem</th><th>Version</th>
          <th>CVSS</th><th>EPSS</th><th>CVEs</th><th>rdeps</th><th>KEV</th><th>Score</th>
        </tr>
      </thead>
      <tbody>{rows if rows else '<tr><td colspan="9" class="text-muted text-center py-4">No packages found. Run <code>selvo analyze</code> first.</td></tr>'}</tbody>
    </table>
  </div>
</div>
</div>"""

    return _page("Packages", body)


def render_cves(packages: list[dict]) -> str:
    rows_data: list[dict] = []
    for p in packages:
        for cve in p.get("cve_ids", []):
            rows_data.append({
                "cve": cve,
                "package": p["name"],
                "cvss": p.get("max_cvss", 0.0),
                "epss": p.get("max_epss", 0.0),
                "kev": p.get("in_cisa_kev", False),
                "maturity": p.get("exploit_maturity", "none"),
                "score": p.get("score", 0.0),
            })
    rows_data.sort(key=lambda r: (r["epss"], r["cvss"]), reverse=True)

    rows = ""
    for r in rows_data[:200]:
        kev = _badge_kev() if r["kev"] else ""
        mat = r["maturity"]
        mat_badge = (
            '<span class="badge badge-wpn">Weaponized</span>' if mat == "weaponized"
            else '<span class="badge badge-poc">PoC</span>' if mat == "poc"
            else '<span class="text-muted">—</span>'
        )
        nvd_url = f"https://nvd.nist.gov/vuln/detail/{_esc(r['cve'])}"
        rows += f"""
        <tr>
          <td><a href="{nvd_url}" target="_blank" class="text-info">{_esc(r['cve'])}</a></td>
          <td>{_esc(r['package'])}</td>
          <td>{r['cvss']:.1f}</td>
          <td>{_badge_epss(r['epss'])}</td>
          <td>{kev}</td>
          <td>{mat_badge}</td>
        </tr>"""

    body = f"""
<h5 class="mb-3">CVEs <span class="text-muted fs-6">({len(rows_data)} total)</span></h5>
<div class="card">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>CVE ID</th><th>Package</th><th>CVSS</th><th>EPSS</th><th>KEV</th><th>Exploit</th>
        </tr>
      </thead>
      <tbody>{rows if rows else '<tr><td colspan="6" class="text-muted text-center py-4">No CVEs found in snapshot.</td></tr>'}</tbody>
    </table>
  </div>
</div>
<small class="text-muted mt-2 d-block">Showing top 200 by EPSS. <a href="/api/v1/cves" class="text-info">Full list via API →</a></small>"""

    return _page("CVEs", body)


def render_trends(metrics: list[dict]) -> str:
    """Render a simple inline SVG sparkline for package + CVE counts."""
    if not metrics:
        body = """
<h5 class="mb-3">Trends</h5>
<div class="card p-4 text-center text-muted">
  No trend data yet. Run <code>selvo analyze</code> a few times to build history.
</div>"""
        return _page("Trends", body)

    dates = [m.get("date", "") for m in metrics]
    pkg_counts = [m.get("package_count", 0) for m in metrics]
    cve_counts = [m.get("cve_count", 0) for m in metrics]
    kev_counts = [m.get("kev_count", 0) for m in metrics]

    def _svg_line(values: list[int], color: str, w: int = 800, h: int = 80) -> str:
        if len(values) < 2:
            return ""
        mn, mx = min(values), max(values)
        rng = mx - mn or 1
        xs = [i * w / (len(values) - 1) for i in range(len(values))]
        ys = [h - (v - mn) / rng * (h - 10) - 5 for v in values]
        pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))
        return (
            f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'style="width:100%;height:{h}px">'
            f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2"/>'
            f"</svg>"
        )

    body = f"""
<h5 class="mb-3">Trends</h5>
<div class="row g-3">
  <div class="col-12">
    <div class="card p-3">
      <div class="fw-bold mb-2 text-info">Package count over time</div>
      {_svg_line(pkg_counts, '#58a6ff')}
      <div class="d-flex justify-content-between mt-1">
        <small class="text-muted">{dates[0] if dates else ''}</small>
        <small class="text-muted">{dates[-1] if dates else ''}</small>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6">
    <div class="card p-3">
      <div class="fw-bold mb-2 text-warning">CVEs over time</div>
      {_svg_line(cve_counts, '#d29922')}
    </div>
  </div>
  <div class="col-12 col-md-6">
    <div class="card p-3">
      <div class="fw-bold mb-2 text-danger">KEV listings over time</div>
      {_svg_line(kev_counts, '#f85149')}
    </div>
  </div>
</div>
<small class="text-muted mt-2 d-block">{len(metrics)} snapshots tracked.</small>"""

    return _page("Trends", body)


def render_keys(org_id: str, keys: list[dict], message: str = "") -> str:
    rows = ""
    for k in keys:
        import datetime as _dt
        created = _dt.datetime.fromtimestamp(k["created_at"]).strftime("%Y-%m-%d") if k.get("created_at") else "—"
        last = _dt.datetime.fromtimestamp(k["last_used_at"]).strftime("%Y-%m-%d %H:%M") if k.get("last_used_at") else "—"
        active_badge = '<span class="badge bg-success">Active</span>' if k["active"] else '<span class="badge bg-secondary">Revoked</span>'
        revoke_btn = ""
        if k["active"]:
            revoke_btn = f"""
            <form method="post" action="/dash/keys/revoke" class="d-inline"
                  hx-post="/dash/keys/revoke" hx-target="#keys-section" hx-swap="outerHTML">
              <input type="hidden" name="key_hash" value="{_esc(k['key_hash'])}">
              <input type="hidden" name="org_id" value="{_esc(org_id)}">
              <button type="submit" class="btn btn-outline-danger btn-sm"
                      onclick="return confirm('Revoke this key?')">Revoke</button>
            </form>"""
        rows += f"""
        <tr>
          <td>{k['id']}</td>
          <td><code class="text-muted">{_esc(k['key_hash'][:16])}…</code></td>
          <td>{_esc(k['plan'])}</td>
          <td>{active_badge}</td>
          <td>{created}</td>
          <td>{last}</td>
          <td>{k['requests_today']}</td>
          <td>{revoke_btn}</td>
        </tr>"""

    msg_html = f'<div class="alert alert-info mt-2">{_esc(message)}</div>' if message else ""

    body = f"""
<h5 class="mb-3">API Keys
  <small class="text-muted fs-6">org: <code>{_esc(org_id) or 'not configured'}</code></small>
</h5>
{msg_html}
<div id="keys-section">
<div class="card mb-4">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>ID</th><th>Key (hash prefix)</th><th>Plan</th><th>Status</th>
          <th>Created</th><th>Last used</th><th>Req today</th><th></th>
        </tr>
      </thead>
      <tbody>{rows if rows else '<tr><td colspan="8" class="text-muted text-center py-4">No keys yet.</td></tr>'}</tbody>
    </table>
  </div>
</div>
<div class="card p-3">
  <h6 class="mb-3">Create new key</h6>
  <form method="post" action="/dash/keys"
        hx-post="/dash/keys" hx-target="#keys-section" hx-swap="outerHTML">
    <div class="row g-2">
      <div class="col-auto">
        <input type="hidden" name="org_id" value="{_esc(org_id)}">
        <select name="plan" class="form-select form-select-sm bg-dark text-light border-secondary">
          <option value="free">free</option>
          <option value="pro" selected>pro</option>
          <option value="enterprise">enterprise</option>
        </select>
      </div>
      <div class="col-auto">
        <button type="submit" class="btn btn-outline-info btn-sm">Generate key</button>
      </div>
    </div>
  </form>
</div>
</div>"""

    return _page("API Keys", body)


def render_new_key_result(org_id: str, plaintext_key: str, keys: list[dict]) -> str:
    """Called after key creation — shows the key once then re-renders the table."""
    rows = ""
    for k in keys:
        import datetime as _dt
        created = _dt.datetime.fromtimestamp(k["created_at"]).strftime("%Y-%m-%d") if k.get("created_at") else "—"
        last = _dt.datetime.fromtimestamp(k["last_used_at"]).strftime("%Y-%m-%d %H:%M") if k.get("last_used_at") else "—"
        active_badge = '<span class="badge bg-success">Active</span>' if k["active"] else '<span class="badge bg-secondary">Revoked</span>'
        revoke_btn = ""
        if k["active"]:
            revoke_btn = f"""
            <form method="post" action="/dash/keys/revoke" class="d-inline"
                  hx-post="/dash/keys/revoke" hx-target="#keys-section" hx-swap="outerHTML">
              <input type="hidden" name="key_hash" value="{_esc(k['key_hash'])}">
              <input type="hidden" name="org_id" value="{_esc(org_id)}">
              <button type="submit" class="btn btn-outline-danger btn-sm">Revoke</button>
            </form>"""
        rows += f"""
        <tr>
          <td>{k['id']}</td>
          <td><code class="text-muted">{_esc(k['key_hash'][:16])}…</code></td>
          <td>{_esc(k['plan'])}</td>
          <td>{active_badge}</td>
          <td>{created}</td>
          <td>{last}</td>
          <td>{k['requests_today']}</td>
          <td>{revoke_btn}</td>
        </tr>"""

    return f"""
<div id="keys-section">
<div class="alert alert-success">
  <strong>New API key created.</strong> Copy it now — it will not be shown again.<br>
  <code class="user-select-all fs-6 mt-2 d-block">{_esc(plaintext_key)}</code>
</div>
<div class="card mb-4">
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead>
        <tr>
          <th>ID</th><th>Key (hash prefix)</th><th>Plan</th><th>Status</th>
          <th>Created</th><th>Last used</th><th>Req today</th><th></th>
        </tr>
      </thead>
      <tbody>{rows}</tbody>
    </table>
  </div>
</div>
<div class="card p-3">
  <h6 class="mb-3">Create new key</h6>
  <form method="post" action="/dash/keys"
        hx-post="/dash/keys" hx-target="#keys-section" hx-swap="outerHTML">
    <div class="row g-2">
      <input type="hidden" name="org_id" value="{_esc(org_id)}">
      <div class="col-auto">
        <select name="plan" class="form-select form-select-sm bg-dark text-light border-secondary">
          <option value="free">free</option>
          <option value="pro" selected>pro</option>
          <option value="enterprise">enterprise</option>
        </select>
      </div>
      <div class="col-auto">
        <button type="submit" class="btn btn-outline-info btn-sm">Generate key</button>
      </div>
    </div>
  </form>
</div>
</div>"""


def render_billing(plan: str = "free") -> str:
    """Render the billing / upgrade page with pricing cards."""
    import os as _os
    pro_price_id = _os.environ.get("STRIPE_PRO_MONTHLY_PRICE_ID", "")
    ent_price_id = _os.environ.get("STRIPE_ENT_MONTHLY_PRICE_ID", "")

    plan_color = {"free": "secondary", "pro": "info", "enterprise": "warning"}.get(plan, "secondary")
    plan_label = plan.title()

    def _plan_card(name: str, price: str, price_id: str, features: list, highlight: bool = False) -> str:
        pkey = name.lower()
        active = plan == pkey
        if active:
            btn = '<button class="btn btn-success w-100" disabled>Current plan</button>'
        elif price_id:
            btn = (
                f'<button class="btn btn-{"warning" if pkey == "enterprise" else "info"} w-100" '
                f'hx-post="/dash/billing/checkout" '
                f'hx-vals=\'{{"plan":"{pkey}","price_id":"{price_id}"}}\' '
                f'hx-target="#checkout-result" hx-indicator="#checkout-spinner">'
                f'Upgrade to {name}</button>'
            )
        else:
            btn = '<a href="mailto:sales@sethc5.dev" class="btn btn-outline-warning w-100">Contact Sales</a>'
        border = " border-info" if highlight else ""
        feats = "".join(f"<li class='mb-1'>\u2713 {_esc(f)}</li>" for f in features)
        return f"""
        <div class="col-12 col-md-4">
          <div class="card h-100{border} p-3">
            <h5 class="{'text-info' if highlight else ''}">{name}</h5>
            <div class="display-6 fw-bold mb-1">{price}</div>
            <small class="text-muted mb-3">/month</small>
            <ul class="list-unstyled text-muted small mb-4">{feats}</ul>
            {btn}
          </div>
        </div>"""

    body = f"""
<div class="d-flex align-items-center mb-4 gap-3">
  <h5 class="mb-0">Billing &amp; Plan</h5>
  <span class="badge bg-{plan_color} fs-6">{_esc(plan_label)}</span>
</div>
<div class="row g-3 mb-4">
  {_plan_card("Free", "$0", "", [
      "50 packages / run", "Debian + Fedora ecosystems",
      "CVE + EPSS enrichment", "API access (rate-limited)",
  ])}
  {_plan_card("Pro", "$49", pro_price_id, [
      "500 packages / run", "All ecosystems",
      "SBOM / Grype / Trivy import", "Fleet SSH scanning",
      "Compliance exports (SARIF, VEX)", "Priority support",
  ], highlight=True)}
  {_plan_card("Enterprise", "$299", ent_price_id, [
      "Unlimited packages", "Team seats + SSO",
      "Air-gap / offline mode", "Custom SLA", "Dedicated support",
  ])}
</div>
<div id="checkout-result" class="mt-3"></div>
<div id="checkout-spinner" class="htmx-indicator text-muted small">Redirecting to Stripe\u2026</div>"""

    return _page("Billing", body)
