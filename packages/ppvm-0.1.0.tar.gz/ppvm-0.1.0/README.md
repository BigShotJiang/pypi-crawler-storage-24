﻿# pvm

`pvm` is a Windows-first Python version manager inspired by `nvm`.

Current MVP features:

- `pvm install 3.12.2` downloads the official Windows embeddable package.
- `pvm global 3.12.2` sets the default version.
- `pvm local 3.12.2` writes `.python-version` for a project.
- `pvm current` resolves `local` over `global`.
- `pvm which python` shows the active interpreter.
- `pvm init --shell powershell` prints PATH setup instructions.
- `pvm` writes `python` and `pip` shims into `~/.pvm/shims`.

## Install

```powershell
pip install .
```

Then add the shims directory to your PATH:

```powershell
pvm init --shell powershell
```

## Example

```powershell
pvm install 3.12.2
pvm global 3.12.2
python --version
```

## Notes

- The current installer targets Windows and uses the official embeddable package from `python.org`.
- The embeddable package does not ship with `pip` by default. Use `pvm install 3.12.2 --with-pip` if you want `pip` bootstrapped via `get-pip.py`.
- `pvm` itself should ideally be installed with `pipx` or a bootstrap/system Python, not inside a Python runtime managed by `pvm`.
