﻿from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional


SHIM_NAMES = ("python", "python3", "pip", "pip3")
LOCAL_VERSION_FILE = ".python-version"
GLOBAL_VERSION_FILE = "version"


class PvmError(RuntimeError):
    pass


@dataclass(frozen=True)
class CommandSpec:
    argv: list[str]


@dataclass(frozen=True)
class ResolvedVersion:
    version: str
    source: str
    root: Path

    @property
    def python_path(self) -> Path:
        return self.root / "python.exe"


@dataclass(frozen=True)
class PvmPaths:
    root: Path

    @classmethod
    def discover(cls) -> "PvmPaths":
        raw_root = os.environ.get("PVM_ROOT")
        if raw_root:
            return cls(Path(raw_root).expanduser())
        return cls(Path.home() / ".pvm")

    @property
    def versions_dir(self) -> Path:
        return self.root / "versions"

    @property
    def cache_dir(self) -> Path:
        return self.root / "cache"

    @property
    def shims_dir(self) -> Path:
        return self.root / "shims"

    @property
    def global_version_file(self) -> Path:
        return self.root / GLOBAL_VERSION_FILE

    def version_dir(self, version: str) -> Path:
        return self.versions_dir / normalize_version(version)

    def ensure_layout(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self.versions_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.shims_dir.mkdir(parents=True, exist_ok=True)


def normalize_version(version: str) -> str:
    value = version.strip()
    if value.startswith("v"):
        value = value[1:]
    if not value:
        raise PvmError("version cannot be empty")
    return value


def version_key(version: str) -> tuple[object, ...]:
    parts = re.split(r"[.\-+]", normalize_version(version))
    key = []
    for part in parts:
        if part.isdigit():
            key.append(int(part))
        else:
            key.append(part)
    return tuple(key)


def read_text_file(path: Path) -> Optional[str]:
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8").strip() or None


def write_text_file(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{value.strip()}\n", encoding="utf-8")


def installed_versions(paths: PvmPaths) -> list[str]:
    if not paths.versions_dir.exists():
        return []
    versions = [item.name for item in paths.versions_dir.iterdir() if item.is_dir()]
    return sorted(versions, key=version_key)


def get_global_version(paths: PvmPaths) -> Optional[str]:
    value = read_text_file(paths.global_version_file)
    return normalize_version(value) if value else None


def set_global_version(paths: PvmPaths, version: str) -> None:
    ensure_installed(paths, version)
    write_text_file(paths.global_version_file, normalize_version(version))


def find_local_version(start: Path) -> Optional[tuple[str, Path]]:
    current = start.resolve()
    for base in (current, *current.parents):
        candidate = base / LOCAL_VERSION_FILE
        value = read_text_file(candidate)
        if value:
            return normalize_version(value), candidate
    return None


def set_local_version(directory: Path, version: str, paths: PvmPaths) -> Path:
    ensure_installed(paths, version)
    destination = directory / LOCAL_VERSION_FILE
    write_text_file(destination, normalize_version(version))
    return destination


def ensure_installed(paths: PvmPaths, version: str) -> Path:
    root = paths.version_dir(version)
    python_path = root / "python.exe"
    if not python_path.exists():
        raise PvmError(
            f"Python {normalize_version(version)} is not installed under {root}"
        )
    return root


def resolve_version(
    paths: PvmPaths,
    *,
    explicit_version: Optional[str] = None,
    cwd: Optional[Path] = None,
) -> ResolvedVersion:
    if explicit_version:
        version = normalize_version(explicit_version)
        return ResolvedVersion(
            version=version,
            source="explicit",
            root=ensure_installed(paths, version),
        )

    active_cwd = cwd or Path.cwd()
    local = find_local_version(active_cwd)
    if local:
        version, _ = local
        return ResolvedVersion(
            version=version,
            source="local",
            root=ensure_installed(paths, version),
        )

    global_version = get_global_version(paths)
    if global_version:
        return ResolvedVersion(
            version=global_version,
            source="global",
            root=ensure_installed(paths, global_version),
        )

    raise PvmError(
        "no active Python version configured; use `pvm install` and `pvm global`"
    )


def resolve_tool_command(resolved: ResolvedVersion, tool: str) -> CommandSpec:
    search_entries = [str(resolved.root), str(resolved.root / "Scripts")]
    lookup = shutil.which(tool, path=os.pathsep.join(search_entries))
    if lookup:
        return CommandSpec([lookup])

    if tool in {"pip", "pip3"}:
        return CommandSpec([str(resolved.python_path), "-m", "pip"])

    raise PvmError(
        f"tool `{tool}` was not found in Python {resolved.version}; "
        "for pip, reinstall with `--with-pip` or bootstrap it separately"
    )


def run_tool(
    paths: PvmPaths,
    tool: str,
    tool_args: Iterable[str],
    *,
    explicit_version: Optional[str] = None,
    cwd: Optional[Path] = None,
) -> int:
    resolved = resolve_version(paths, explicit_version=explicit_version, cwd=cwd)
    command = resolve_tool_command(resolved, tool)
    completed = subprocess.run(command.argv + list(tool_args), check=False)
    return int(completed.returncode)


def write_shims(paths: PvmPaths) -> None:
    paths.ensure_layout()
    for name in SHIM_NAMES:
        shim_path = paths.shims_dir / f"{name}.cmd"
        shim_path.write_text(_cmd_shim_template(name), encoding="utf-8")


def _cmd_shim_template(tool: str) -> str:
    return f"@echo off\npvm _run {tool} %*\n"


def print_init(shell: str, paths: PvmPaths) -> str:
    root = str(paths.root)
    shims = str(paths.shims_dir)
    if shell == "powershell":
        return (
            f"$env:PVM_ROOT = '{root}'\n"
            f"$env:Path = '{shims};' + $env:Path\n\n"
            "# Persist for future shells:\n"
            f"[Environment]::SetEnvironmentVariable('PVM_ROOT', '{root}', 'User')\n"
            "$currentUserPath = [Environment]::GetEnvironmentVariable('Path', 'User')\n"
            f"if (($currentUserPath -split ';') -notcontains '{shims}') {{\n"
            f"    [Environment]::SetEnvironmentVariable('Path', '{shims};' + $currentUserPath, 'User')\n"
            "}\n"
        )
    if shell == "cmd":
        return (
            f"set \"PVM_ROOT={root}\"\n"
            f"set \"PATH={shims};%PATH%\"\n\n"
            "REM Persist for future shells:\n"
            f"setx PVM_ROOT \"{root}\"\n"
            f"setx PATH \"{shims};%PATH%\"\n"
        )
    raise PvmError(f"unsupported shell `{shell}`")


def detect_windows_arch() -> str:
    machine = platform.machine().lower()
    if machine in {"amd64", "x86_64"}:
        return "amd64"
    if machine in {"arm64", "aarch64"}:
        return "arm64"
    if machine in {"x86", "i386", "i686"}:
        return "win32"
    raise PvmError(f"unsupported Windows architecture `{platform.machine()}`")


def python_embed_archive_name(version: str, arch: Optional[str] = None) -> str:
    actual_arch = arch or detect_windows_arch()
    return f"python-{normalize_version(version)}-embed-{actual_arch}.zip"


def python_embed_url(version: str, arch: Optional[str] = None) -> str:
    archive_name = python_embed_archive_name(version, arch)
    return f"https://www.python.org/ftp/python/{normalize_version(version)}/{archive_name}"


def download_file(url: str, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"pvm/{sys.version_info.major}.{sys.version_info.minor}"},
    )
    with urllib.request.urlopen(request, timeout=60) as response, destination.open("wb") as handle:
        shutil.copyfileobj(response, handle)
    return destination


def enable_site_imports(version_root: Path) -> None:
    pth_files = list(version_root.glob("python*._pth"))
    if not pth_files:
        return
    pth_path = pth_files[0]
    content = pth_path.read_text(encoding="utf-8")
    if "#import site" in content:
        content = content.replace("#import site", "import site")
        pth_path.write_text(content, encoding="utf-8")


def bootstrap_pip(version_root: Path, cache_dir: Path) -> None:
    python_path = version_root / "python.exe"
    if not python_path.exists():
        raise PvmError(f"python executable not found under {version_root}")

    get_pip = cache_dir / "get-pip.py"
    if not get_pip.exists():
        download_file("https://bootstrap.pypa.io/get-pip.py", get_pip)

    result = subprocess.run([str(python_path), str(get_pip)], check=False)
    if result.returncode != 0:
        raise PvmError("failed to bootstrap pip with get-pip.py")


def install_windows_python(
    paths: PvmPaths,
    version: str,
    *,
    archive: Optional[Path] = None,
    with_pip: bool = False,
    force: bool = False,
) -> Path:
    if platform.system() != "Windows":
        raise PvmError("the current MVP installer only supports Windows")

    normalized = normalize_version(version)
    target = paths.version_dir(normalized)
    if target.exists():
        if not force:
            raise PvmError(f"Python {normalized} is already installed under {target}")
        shutil.rmtree(target)

    target.mkdir(parents=True, exist_ok=True)

    archive_path = archive
    if archive_path is None:
        archive_path = paths.cache_dir / python_embed_archive_name(normalized)
        if not archive_path.exists():
            download_file(python_embed_url(normalized), archive_path)
    else:
        archive_path = archive_path.expanduser().resolve()
        if not archive_path.exists():
            raise PvmError(f"archive does not exist: {archive_path}")

    try:
        with zipfile.ZipFile(archive_path) as package:
            package.extractall(target)
        if not (target / "python.exe").exists():
            raise PvmError(f"archive did not contain python.exe: {archive_path}")
        enable_site_imports(target)
        if with_pip:
            bootstrap_pip(target, paths.cache_dir)
    except Exception:
        shutil.rmtree(target, ignore_errors=True)
        raise

    return target


def uninstall_version(paths: PvmPaths, version: str) -> Path:
    target = paths.version_dir(version)
    if not target.exists():
        raise PvmError(f"Python {normalize_version(version)} is not installed")
    shutil.rmtree(target)
    return target


def format_installed_versions(paths: PvmPaths, cwd: Optional[Path] = None) -> list[str]:
    versions = installed_versions(paths)
    if not versions:
        return []

    current_version = None
    global_version = get_global_version(paths)
    local = find_local_version(cwd or Path.cwd())
    local_version = local[0] if local else None

    try:
        current_version = resolve_version(paths, cwd=cwd).version
    except PvmError:
        current_version = None

    lines = []
    for version in versions:
        markers = []
        if version == current_version:
            markers.append("current")
        if version == global_version:
            markers.append("global")
        if version == local_version:
            markers.append("local")
        suffix = f" [{' '.join(markers)}]" if markers else ""
        lines.append(f"{version}{suffix}")
    return lines

