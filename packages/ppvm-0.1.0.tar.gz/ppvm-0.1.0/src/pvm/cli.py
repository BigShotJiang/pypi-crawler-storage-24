﻿from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Iterable, Optional

from pvm import __version__
from pvm.core import (
    PvmError,
    PvmPaths,
    find_local_version,
    format_installed_versions,
    get_global_version,
    install_windows_python,
    normalize_version,
    print_init,
    resolve_tool_command,
    resolve_version,
    run_tool,
    set_global_version,
    set_local_version,
    uninstall_version,
    write_shims,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pvm",
        description="A Windows-first Python version manager.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command", required=True)

    install_parser = subparsers.add_parser(
        "install",
        help="Download and install a Python version.",
    )
    install_parser.add_argument("version", help="Python version, for example 3.12.2")
    install_parser.add_argument(
        "--archive",
        type=Path,
        help="Install from a local embeddable zip archive instead of downloading.",
    )
    install_parser.add_argument(
        "--with-pip",
        action="store_true",
        help="Bootstrap pip with get-pip.py after extraction.",
    )
    install_parser.add_argument(
        "--force",
        action="store_true",
        help="Replace an existing installation of the same version.",
    )
    install_parser.add_argument(
        "--global",
        dest="set_global",
        action="store_true",
        help="Set the installed version as the global default after install.",
    )

    subparsers.add_parser("list", aliases=["ls"], help="List installed Python versions.")

    use_parser = subparsers.add_parser("use", help="Set the global default version.")
    use_parser.add_argument("version", help="Installed Python version to activate.")

    global_parser = subparsers.add_parser(
        "global",
        help="Get or set the global default version.",
    )
    global_parser.add_argument(
        "version",
        nargs="?",
        help="Installed Python version to activate globally.",
    )

    local_parser = subparsers.add_parser("local", help="Get or set a local project version.")
    local_parser.add_argument(
        "version",
        nargs="?",
        help="Installed Python version to activate locally.",
    )

    subparsers.add_parser("current", help="Show the currently active version.")

    which_parser = subparsers.add_parser("which", help="Show the resolved path for a tool.")
    which_parser.add_argument("tool", nargs="?", default="python", help="Tool name, default: python")

    exec_parser = subparsers.add_parser("exec", help="Execute a tool from the active version.")
    exec_parser.add_argument("tool", help="Tool name, for example python or pip")
    exec_parser.add_argument("args", nargs=argparse.REMAINDER)

    init_parser = subparsers.add_parser("init", help="Print shell initialization instructions.")
    init_parser.add_argument(
        "--shell",
        choices=("powershell", "cmd"),
        default="powershell",
        help="Shell syntax to print.",
    )

    subparsers.add_parser("rehash", help="Rewrite the shim scripts.")

    uninstall_parser = subparsers.add_parser("uninstall", help="Remove an installed Python version.")
    uninstall_parser.add_argument("version", help="Installed Python version to remove.")

    run_parser = subparsers.add_parser("_run", help=argparse.SUPPRESS)
    run_parser.add_argument("tool")
    run_parser.add_argument("args", nargs=argparse.REMAINDER)

    return parser


def main(argv: Optional[Iterable[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    paths = PvmPaths.discover()
    paths.ensure_layout()
    write_shims(paths)

    try:
        if args.command == "install":
            return handle_install(args, paths)
        if args.command in {"list", "ls"}:
            return handle_list(paths)
        if args.command in {"use", "global"}:
            return handle_global(args, paths)
        if args.command == "local":
            return handle_local(args, paths)
        if args.command == "current":
            return handle_current(paths)
        if args.command == "which":
            return handle_which(args.tool, paths)
        if args.command == "exec":
            return run_tool(paths, args.tool, args.args)
        if args.command == "init":
            print(print_init(args.shell, paths), end="")
            return 0
        if args.command == "rehash":
            write_shims(paths)
            print(f"shims written to {paths.shims_dir}")
            return 0
        if args.command == "uninstall":
            removed = uninstall_version(paths, args.version)
            print(f"removed {removed}")
            return 0
        if args.command == "_run":
            return run_tool(paths, args.tool, args.args)
        parser.error(f"unsupported command: {args.command}")
    except PvmError as exc:
        print(f"pvm: error: {exc}", file=sys.stderr)
        return 1
    return 0


def handle_install(args: argparse.Namespace, paths: PvmPaths) -> int:
    installed_root = install_windows_python(
        paths,
        args.version,
        archive=args.archive,
        with_pip=args.with_pip,
        force=args.force,
    )
    print(f"installed Python {normalize_version(args.version)} to {installed_root}")
    if args.set_global:
        set_global_version(paths, args.version)
        print(f"global version set to {normalize_version(args.version)}")
    return 0


def handle_list(paths: PvmPaths) -> int:
    lines = format_installed_versions(paths)
    if not lines:
        print("no Python versions installed")
        return 0
    for line in lines:
        print(line)
    return 0


def handle_global(args: argparse.Namespace, paths: PvmPaths) -> int:
    version = getattr(args, "version", None)
    if not version:
        current = get_global_version(paths)
        if current is None:
            raise PvmError("no global version configured")
        print(current)
        return 0

    set_global_version(paths, version)
    print(f"global version set to {normalize_version(version)}")
    return 0


def handle_local(args: argparse.Namespace, paths: PvmPaths) -> int:
    if not args.version:
        local = find_local_version(Path.cwd())
        if not local:
            raise PvmError("no local version configured in the current directory tree")
        version, source_file = local
        print(f"{version} ({source_file})")
        return 0

    destination = set_local_version(Path.cwd(), args.version, paths)
    print(f"local version set to {normalize_version(args.version)} in {destination}")
    return 0


def handle_current(paths: PvmPaths) -> int:
    resolved = resolve_version(paths)
    print(f"{resolved.version} ({resolved.source})")
    return 0


def handle_which(tool: str, paths: PvmPaths) -> int:
    resolved = resolve_version(paths)
    spec = resolve_tool_command(resolved, tool)
    print(spec.argv[0])
    return 0
