"""
AzerAI Reminder Plugin - Azərbaycan dilində hatırlatma sistemi

Plugin əsaslı, çoxdilli AI asistenti üçün hatırlatma modulu.
"""

__version__ = "1.0.1"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .plugins.reminder.main import (
    create_reminder,
    create_daily_reminder,
    list_reminders,
    delete_reminder,
    pause_reminder,
    resume_reminder,
    reminder_tools
)

__all__ = [
    "create_reminder",
    "create_daily_reminder", 
    "list_reminders",
    "delete_reminder",
    "pause_reminder",
    "resume_reminder",
    "reminder_tools"
]
