"""
Reminder Tools - LiveKit Agent Functions
JSON tabanlı hatırlatma sistem araçları
"""
import json
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path

from livekit.agents import function_tool
from livekit.agents import RunContext
import logging

# APScheduler import
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.date import DateTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    from apscheduler.triggers.cron import CronTrigger
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    print("❌ APScheduler bulunamadı! Hatırlatma sistemi çalışmaz. Lütfen 'pip install apscheduler' komutunu çalıştırın.")

logger = logging.getLogger("reminder-tools")


class ReminderTools:
    def __init__(self):
        self.reminders_file = Path("azerai_reminders.json")
        self.active_reminders: Dict[str, Dict[str, Any]] = {}
        self.session_ref = None
        self.loop_ref = None
        self.running = True
        
        # APScheduler setup
        if APSCHEDULER_AVAILABLE:
            self.scheduler = BackgroundScheduler()
            self.scheduler.start()
            logger.info("APScheduler started")
            print("⚡ APScheduler başlatıldı")
        else:
            self.scheduler = None
            logger.error("APScheduler bulunamadı! Hatırlatma sistemi çalışamaz.")
            print("❌ APScheduler bulunamadı! Lütfen 'pip install apscheduler' komutunu çalıştırın.")
            return
        
        # Dosyayı yükle
        self._load_reminders()
        
        # Mevcut hatırlatmaları schedule et
        self._schedule_existing_reminders()

    def _schedule_existing_reminders(self):
        """Mevcut hatırlatmaları APScheduler ile schedule et"""
        if not self.scheduler:
            return
            
        for reminder_id, reminder in self.active_reminders.items():
            if reminder.get('active', True) and not reminder.get('paused', False):
                self._schedule_reminder(reminder_id, reminder)

    def _schedule_reminder(self, reminder_id: str, reminder: Dict[str, Any]):
        """Tek bir hatırlatmayı schedule et"""
        if not self.scheduler:
            return
            
        try:
            # Eski job varsa kaldır
            job_id = f"reminder_{reminder_id}"
            if self.scheduler.get_job(job_id):
                self.scheduler.remove_job(job_id)
            
            # Günlük hatırlatma
            if reminder.get('daily', False):
                time_parts = reminder['time'].split(':')
                hour, minute = int(time_parts[0]), int(time_parts[1])
                self.scheduler.add_job(
                    func=self._trigger_reminder_job,
                    trigger=CronTrigger(hour=hour, minute=minute),
                    args=[reminder_id, reminder],
                    id=job_id,
                    replace_existing=True
                )
                logger.info(f"Daily reminder scheduled: {reminder_id} at {reminder['time']}")
            
            # Belirli tarih/zaman
            elif 'datetime' in reminder:
                reminder_time = datetime.fromisoformat(reminder['datetime'])
                self.scheduler.add_job(
                    func=self._trigger_reminder_job,
                    trigger=DateTrigger(run_date=reminder_time),
                    args=[reminder_id, reminder],
                    id=job_id,
                    replace_existing=True
                )
                logger.info(f"Datetime reminder scheduled: {reminder_id} at {reminder_time}")
            
            # Göreceli zaman
            elif 'relative_time' in reminder:
                seconds = reminder['relative_time']
                self.scheduler.add_job(
                    func=self._trigger_reminder_job,
                    trigger=IntervalTrigger(seconds=seconds),
                    args=[reminder_id, reminder],
                    id=job_id,
                    replace_existing=True
                )
                logger.info(f"Relative reminder scheduled: {reminder_id} in {seconds}s")
                
        except Exception as e:
            logger.error(f"Error scheduling reminder {reminder_id}: {e}")

    def _trigger_reminder_job(self, reminder_id: str, reminder: Dict[str, Any]):
        """APScheduler job'dan çağrılan hatırlatma fonksiyonu"""
        try:
            self._trigger_reminder(reminder_id, reminder)
            
            # Tek seferlik hatırlatmaları deaktif et (günlükler hariç)
            if not reminder.get('daily', False):
                if reminder_id in self.active_reminders:
                    self.active_reminders[reminder_id]['active'] = False
                    self.active_reminders[reminder_id]['triggered_at'] = datetime.now().isoformat()
                    self._save_reminders()
                    
                    # Job'u kaldır
                    job_id = f"reminder_{reminder_id}"
                    if self.scheduler.get_job(job_id):
                        self.scheduler.remove_job(job_id)
            
            # Günlük hatırlatmalar için son tetiklenme tarihini güncelle
            elif reminder.get('daily', False):
                if reminder_id in self.active_reminders:
                    self.active_reminders[reminder_id]['last_triggered'] = datetime.now().date().isoformat()
                    self._save_reminders()
                    
        except Exception as e:
            logger.error(f"Error in reminder job {reminder_id}: {e}")

    def _load_reminders(self):
        """JSON dosyasından hatırlatmaları yükle"""
        try:
            if self.reminders_file.exists():
                with open(self.reminders_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.active_reminders = data.get('reminders', {})
                    logger.info(f"Loaded {len(self.active_reminders)} reminders from file")
            else:
                # Boş dosya oluştur
                self._save_reminders()
        except Exception as e:
            logger.error(f"Error loading reminders: {e}")
            self.active_reminders = {}

    def _save_reminders(self):
        """Hatırlatmaları JSON dosyasına kaydet"""
        try:
            data = {
                'reminders': self.active_reminders,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.reminders_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            logger.info("Reminders saved to file")
        except Exception as e:
            logger.error(f"Error saving reminders: {e}")

    def _trigger_reminder(self, reminder_id: str, reminder: Dict[str, Any]):
        """Hatırlatmayı tetikle ve bildirim gönder"""
        title = reminder.get('title', 'Hatırlatma')
        message = reminder.get('message', f'⏰ Hatırlatma: {title}')
        
        logger.info(f"=== REMINDER TRIGGERED: {reminder_id} - '{title}' ===")
        print(f"⏰ HATIRLATMA: {title}")
        
        # Session'a bildirim gönder
        if self.session_ref and self.loop_ref:
            try:
                print(f"🔍 DEBUG: Trying to send reminder notification to session...")
                print(f"🔍 DEBUG: Has session: {self.session_ref is not None}")
                print(f"🔍 DEBUG: Has loop: {self.loop_ref is not None}")
                
                # Define inline helper function
                async def send_reminder_notification():
                    try:
                        print(f"📤 SESSION'A GÖNDERİLİYOR: ⏰ Hatırlatma: {title} süresi doldu!")
                        await self.session_ref.generate_reply(
                            instructions=f"assistant | content: sadece şu mesajı ver: {message}. Bu hatırlatma tetiklendi ve artık deaktif."
                        )
                        print(f"✅ SESSION'A BAŞARIYLA GÖNDERİLDİ: {title}")
                    except Exception as e:
                        print(f"❌ SESSION'A GÖNDERİLEMEDİ: {e}")
                
                future = __import__('asyncio').run_coroutine_threadsafe(
                    send_reminder_notification(),
                    self.loop_ref
                )
                print(f"🔍 DEBUG: Reminder future created: {future}")
                logger.info(f"Reminder notification sent: {title}")
            except Exception as e:
                logger.error(f"Failed to send reminder notification: {e}")
                print(f"❌ SESSION'A GÖNDERİLEMEDİ: {e}")
        else:
            print(f"🔍 DEBUG: Cannot send reminder - missing session or loop")
            print(f"🔍 DEBUG: Has session: {self.session_ref is not None}")
            print(f"🔍 DEBUG: Has loop: {self.loop_ref is not None}")
            logger.warning(f"No session reference available for reminder: {title}")

    def update_session_reference(self, ctx: RunContext):
        """Session referansını güncelle"""
        if not self.session_ref:
            self.session_ref = ctx.session
            self.loop_ref = __import__('asyncio').get_running_loop()
            logger.info("Session reference updated for reminders")
            print("🔗 Session referansı hatırlatma sistemi için güncellendi")

    @function_tool()
    async def create_daily_reminder(self, ctx: RunContext, title: str, time_str: str, message: str = ""):
        """Create a daily reminder that repeats every day at specified time."""
        self.update_session_reference(ctx)
        
        reminder_id = f"reminder_{len(self.active_reminders) + 1}"
        
        try:
            datetime.strptime(time_str, "%H:%M")
        except ValueError:
            return "Geçersiz zaman formatı. 'SS:DD' kullanın."
        
        reminder_data = {
            'title': title,
            'message': message or f'📅 Günlük: {title}',
            'created_at': datetime.now().isoformat(),
            'active': True,
            'daily': True,
            'time': time_str
        }
        
        self.active_reminders[reminder_id] = reminder_data
        self._save_reminders()
        
        # APScheduler ile schedule et
        self._schedule_reminder(reminder_id, reminder_data)
        
        print(f"📅 Günlük hatırlatma: '{title}' - {time_str}")
        return f"Günlük hatırlatma '{title}' oluşturuldu: {time_str}"

    @function_tool()
    async def create_reminder(self, ctx: RunContext, title: str, message: str = "", 
                            datetime_str: str = "", hours: int = 0, minutes: int = 0, days: int = 0):
        """Create a new reminder."""
        self.update_session_reference(ctx)
        
        reminder_id = f"reminder_{len(self.active_reminders) + 1}"
        
        reminder_data = {
            'title': title,
            'message': message or f'⏰ Hatırlatma: {title}',
            'created_at': datetime.now().isoformat(),
            'active': True
        }
        
        if datetime_str:
            try:
                reminder_time = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M")
                reminder_data['datetime'] = reminder_time.isoformat()
                time_desc = datetime_str
            except ValueError:
                return "Geçersiz tarih formatı. 'YYYY-MM-DD HH:MM' kullanın."
        else:
            total_seconds = (days * 86400) + (hours * 3600) + (minutes * 60)
            if total_seconds > 0:
                reminder_data['relative_time'] = total_seconds
                time_parts = []
                if days > 0:
                    time_parts.append(f"{days} gün")
                if hours > 0:
                    time_parts.append(f"{hours} saat")
                if minutes > 0:
                    time_parts.append(f"{minutes} dakika")
                time_desc = " ".join(time_parts) + " sonra"
            else:
                return "Geçerli bir zaman belirtin."
        
        self.active_reminders[reminder_id] = reminder_data
        self._save_reminders()
        
        # APScheduler ile schedule et
        self._schedule_reminder(reminder_id, reminder_data)
        
        print(f"📝 Hatırlatma: '{title}' - {time_desc}")
        return f"Hatırlatma '{title}' oluşturuldu: {time_desc}"

    @function_tool()
    async def list_reminders(self, ctx: RunContext):
        """List all reminders with their status."""
        # Session referansını güncelle
        self.update_session_reference(ctx)
        reminders_list = []
        
        for reminder_id, reminder in self.active_reminders.items():
            # Durum belirle
            if reminder.get('paused', False):
                status = "⏸️ Durdurulmuş"
            elif reminder.get('daily', False):
                status = "📅 Günlük"
            elif reminder.get('active', True):
                status = "🟢 Aktif"
            else:
                status = "🔴 Deaktif"
                
            title = reminder.get('title', 'İsimsiz')
            
            # Zaman bilgisini formatla
            if reminder.get('daily', False) and 'time' in reminder:
                time_info = f"Her gün {reminder['time']}"
                if reminder.get('last_triggered'):
                    time_info += f" (Son: {reminder['last_triggered']})"
            elif 'datetime' in reminder:
                time_info = f"Zaman: {reminder['datetime']}"
            elif 'relative_time' in reminder:
                seconds = reminder['relative_time']
                hours = seconds // 3600
                minutes = (seconds % 3600) // 60
                time_info = f"Süre: {hours}sa {minutes}dk"
            else:
                time_info = "Zaman belirtilmemiş"
            
            reminders_list.append(f"{status} - {title} ({time_info})")
        
        if reminders_list:
            result = "\n".join(reminders_list)
            print(f"📋 HATIRLATMALAR:\n{result}")
            return f"Reminders:\n{result}"
        else:
            print("📋 HATIRLATMA YOK")
            return "No reminders found"

    @function_tool()
    async def pause_reminder(self, ctx: RunContext, title: str):
        """Pause an active reminder by title."""
        self.update_session_reference(ctx)
        
        paused_reminders = []
        
        for reminder_id, reminder in self.active_reminders.items():
            if reminder.get('title', '').lower() == title.lower() and reminder.get('active', True):
                reminder['active'] = False
                reminder['paused'] = True
                reminder['paused_at'] = datetime.now().isoformat()
                paused_reminders.append(reminder_id)
                
                # APScheduler job'unu kaldır
                job_id = f"reminder_{reminder_id}"
                if self.scheduler and self.scheduler.get_job(job_id):
                    self.scheduler.remove_job(job_id)
                
                logger.info(f"=== REMINDER PAUSED: {reminder_id} - '{title}' ===")
        
        if paused_reminders:
            self._save_reminders()
            print(f"⏸️ Hatırlatma durduruldu: '{title}'")
            return f"Reminder '{title}' paused successfully"
        else:
            print(f"❌ Aktif hatırlatma bulunamadı: '{title}'")
            return f"No active reminder found with title '{title}'"

    @function_tool()
    async def resume_reminder(self, ctx: RunContext, title: str):
        """Resume a paused reminder by title."""
        self.update_session_reference(ctx)
        
        resumed_reminders = []
        
        for reminder_id, reminder in self.active_reminders.items():
            if reminder.get('title', '').lower() == title.lower() and reminder.get('paused', False):
                # Zamanı hesapla
                if 'paused_at' in reminder and 'relative_time' in reminder:
                    paused_time = datetime.fromisoformat(reminder['paused_at'])
                    created_time = datetime.fromisoformat(reminder['created_at'])
                    elapsed = (paused_time - created_time).total_seconds()
                    remaining = reminder['relative_time'] - elapsed
                    
                    if remaining > 0:
                        reminder['relative_time'] = remaining
                        reminder['created_at'] = datetime.now().isoformat()
                
                reminder['active'] = True
                reminder['paused'] = False
                reminder.pop('paused_at', None)
                resumed_reminders.append(reminder_id)
                
                # APScheduler ile yeniden schedule et
                self._schedule_reminder(reminder_id, reminder)
                
                logger.info(f"=== REMINDER RESUMED: {reminder_id} - '{title}' ===")
        
        if resumed_reminders:
            self._save_reminders()
            print(f"▶️ Hatırlatma devam ettirildi: '{title}'")
            return f"Reminder '{title}' resumed successfully"
        else:
            print(f"❌ Durdurulmuş hatırlatma bulunamadı: '{title}'")
            return f"No paused reminder found with title '{title}'"

    @function_tool()
    async def delete_reminder(self, ctx: RunContext, title: str):
        """Delete a reminder by title."""
        self.update_session_reference(ctx)
        deleted_reminders = []
        
        for reminder_id, reminder in list(self.active_reminders.items()):
            if reminder.get('title', '').lower() == title.lower():
                del self.active_reminders[reminder_id]
                deleted_reminders.append(reminder_id)
                
                # APScheduler job'unu kaldır
                job_id = f"reminder_{reminder_id}"
                if self.scheduler and self.scheduler.get_job(job_id):
                    self.scheduler.remove_job(job_id)
                
                logger.info(f"=== REMINDER DELETED: {reminder_id} - '{title}' ===")
        
        if deleted_reminders:
            self._save_reminders()
            print(f"🗑️ Hatırlatma silindi: '{title}'")
            return f"Reminder '{title}' deleted successfully"
        else:
            print(f"❌ Hatırlatma bulunamadı: '{title}'")
            return f"No reminder found with title '{title}'"

    def __del__(self):
        """Temizlik işlemi"""
        self.running = False
        if self.scheduler:
            try:
                self.scheduler.shutdown()
                logger.info("APScheduler shutdown")
            except:
                pass


# Global instance
reminder_tools = ReminderTools()
create_reminder = reminder_tools.create_reminder
create_daily_reminder = reminder_tools.create_daily_reminder
list_reminders = reminder_tools.list_reminders
delete_reminder = reminder_tools.delete_reminder
pause_reminder = reminder_tools.pause_reminder
resume_reminder = reminder_tools.resume_reminder
