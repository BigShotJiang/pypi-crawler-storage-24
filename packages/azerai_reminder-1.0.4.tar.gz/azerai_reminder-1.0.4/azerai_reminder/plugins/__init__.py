"""
AzerAI Reminder Plugin - Plugin package
"""
