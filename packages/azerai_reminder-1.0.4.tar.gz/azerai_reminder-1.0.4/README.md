# 📅 AzerAI Reminder Plugin

Azərbaycan dilində qabaqcıl səsli AI asistenti üçün hatırlatma plugini.

## Xüsusiyyətlər

- ⏰ **Zamanlı hatırlatmalar** - Specific tarix və saatda
- 📅 **Günlük hatırlatmalar** - Hər gün təkrar olunan
- ⏸️ **Pause/Resume** - Hatırlatmaları idarə et
- 🗑️ **Sil** - Artıq lazım olmayanları sil
- 💾 **JSON saxlama** - Məlumatlar lokal olaraq saxlanılır
- 🔄 **APScheduler** - Güclü zamanlayıcı sistemi

## Quraşdırma

```bash
pip install azerai-reminder
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"5 dəqiqə sonra mənə xatırlat"` - Vaxtlı hatırlatma
- `"Hər gün saat 09:00da mənə xatırlat"` - Günlük hatırlatma
- `"Hatırlatmalarımı göstər"` - Siyahı
- `"X hatırlatmasını dayandır"` - Pause
- `"X hatırlatmasını davam et"` - Resume
- `"X hatırlatmasını sil"` - Sil

## Fayl struktur

```
azerai_reminder/
├── plugins/
│   └── reminder/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Fayllar

- `azerai_reminders.json` - Hatırlatma məlumatları

## Asılılıqlar

- `apscheduler>=3.10.0` - Zamanlayıcı
- `livekit-agents>=1.0.0` - AI agent framework

## Lisenziya

MIT License
