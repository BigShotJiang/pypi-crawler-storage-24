# @Author：青松
import platform
import random

from IPython import display
import numpy as np
import pandas as pd
import torch
import lightning as L
from colorama import Fore, Style
from prettytable import PrettyTable
import matplotlib.pyplot as plt


# @Author：青松
import platform
import random

from IPython import display
import numpy as np
import pandas as pd
import torch
import lightning as L
from colorama import Fore, Style
from prettytable import PrettyTable
import matplotlib.pyplot as plt


def set_seed(seed=1024):
    """设置所有可能的随机种子，确保结果可重复"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    L.seed_everything(seed)
    if torch.backends.mps.is_available():
        torch.mps.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def print_intro():
    """打印项目简介和环境信息"""

    print_table(
        "本书愿景",
        ["Info", "《动手学大语言模型》"],
        [
            ["作者", "吾辈亦有感"],
            ["哔站", "https://space.bilibili.com/3546632320715420"],
            ["定位", "基于'从零构建'的理念，用实战帮助程序员快速入门大模型。"],
            ["愿景", "若让你的AI学习之路走的更容易一点，我将倍感荣幸！祝好😄"],
        ],
    )

    print_table(
        "环境信息",
        ["Python 版本", "PyTorch 版本", "PyTorch Lightning 版本"],
        [[platform.python_version(), torch.__version__, L.__version__]],
    )

    set_seed(1024)


def to_dataframe(data, headers=None):
    """将数据转换为 pandas DataFrame，便于显示"""
    pd.set_option("display.float_format", "{:.4f}".format)
    if headers is not None:
        if isinstance(data, list):
            df = pd.DataFrame(data, columns=headers)
        else:
            df = pd.DataFrame(data, columns=headers)
    else:
        df = pd.DataFrame(data)
    return df


def print_table(table_name, field_names: list, data: list, show_headers=True):
    """内部函数：使用 PrettyTable 打印表格"""
    table = PrettyTable()
    if show_headers:
        table.field_names = field_names
    for data_item in data:
        table.add_row(data_item)
    if table_name:
        print_red(f"{table_name}：")
    print(table)


def print_red(text):
    """以红色打印文本"""
    print(Fore.RED + text + Style.RESET_ALL)


def print_regression_predictions(
    inputs,
    true_values,
    predictions,
    table_name="预测结果",
    field_names=["输入", "真实值", "预测值", "预测偏差", "预测精度"],
):
    """
    打印回归任务的预测结果
    """
    if isinstance(predictions, torch.Tensor):
        predictions = predictions.tolist()

    table_data = []
    for i in range(len(inputs)):
        table_data.append(
            [
                inputs[i],
                round(true_values[i], 4),
                round(predictions[i], 4),
                f"{predictions[i] - true_values[i]:.4f}",
                f"{predictions[i] * 100 / true_values[i]:.2f}%",
            ]
        )
    print_table(table_name, field_names, table_data)


def print_classification_predictions(
    inputs, true_labels, predictions, probabilities, label_map
):
    """
    打印分类任务的预测结果，包含真实标签、预测标签和概率
    """
    if isinstance(predictions, torch.Tensor):
        predictions = predictions.tolist()
    if isinstance(probabilities, torch.Tensor):
        probabilities = probabilities.tolist()

    table_data = []
    correct_count = 0

    for i, text in enumerate(inputs):
        true_label_name = label_map[true_labels[i]]
        pred_label_name = label_map[predictions[i]]

        is_correct = true_labels[i] == predictions[i]
        if is_correct:
            correct_count += 1
            mark = "\033[92m" + "☑" + "\033[0m"
        else:
            mark = "\033[91m" + "☒" + "\033[0m"

        display_text = text[:30] + "..." if len(text) > 30 else text

        if isinstance(probabilities[i], (list, tuple)):
            max_prob = max(probabilities[i])
        else:
            max_prob = probabilities[i].max().item()

        table_data.append(
            [display_text, true_label_name, pred_label_name, f"{max_prob:.4f}", mark]
        )

    accuracy = correct_count / len(inputs) if len(inputs) > 0 else 0
    print_table(
        f"🎯 分类预测结果 (准确率: {correct_count}/{len(inputs)} = {accuracy * 100:.2f}%)",
        ["输入", "真实标签", "预测标签", "最高概率", "标记"],
        table_data,
    )


def print_generation_predictions(questions, real_answers, pred_answers):
    """
    打印生成任务（如AIGC）的预测结果
    """
    table_data = []
    correct_count = 0
    for i in range(len(questions)):
        real_answer_name = real_answers[i]
        pred_answer_name = pred_answers[i]

        if real_answer_name == pred_answer_name:
            correct_count += 1
            mark = "\033[92m" + "☑" + "\033[0m"
        else:
            mark = "\033[91m" + "☒" + "\033[0m"

        table_data.append([questions[i], real_answer_name, pred_answer_name, mark])

    accuracy = correct_count / len(questions) if len(questions) > 0 else 0
    print_table(
        f"🎯 生成结果 (准确率: {correct_count}/{len(questions)} = {accuracy * 100:.2f}%)",
        ["输入", "真实值", "预测值", "标记"],
        table_data,
    )


def plot_training_curves(training_logs):
    """
    绘制训练过程中的损失和参数权重变化曲线
    （注意：当前版本硬编码了特定权重名称，可根据需要泛化）
    """
    epochs = [log["Epoch"] for log in training_logs]
    losses = [log["Loss"] for log in training_logs]
    mint_leaf_weight = [log["薄荷叶权重"] for log in training_logs]
    cucumber_slice_weight = [log["黄瓜片权重"] for log in training_logs]
    rose_salt_weight = [log["玫瑰盐权重"] for log in training_logs]

    plt.rcParams["font.sans-serif"] = ["SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))

    ax1.plot(epochs, losses, color="red")
    ax1.set_title("损失函数变化")
    ax1.set_xlabel("训练轮次")
    ax1.set_ylabel("损失值")
    ax1.grid(True)

    ax2.plot(epochs, mint_leaf_weight, color="blue")
    ax2.set_title("薄荷叶权重变化")
    ax2.set_xlabel("训练轮次")
    ax2.set_ylabel("权重值")
    ax2.grid(True)

    ax3.plot(epochs, cucumber_slice_weight, color="green")
    ax3.set_title("黄瓜片权重变化")
    ax3.set_xlabel("训练轮次")
    ax3.set_ylabel("权重值")
    ax3.grid(True)

    ax4.plot(epochs, rose_salt_weight, color="orange")
    ax4.set_title("玫瑰盐权重变化")
    ax4.set_xlabel("训练轮次")
    ax4.set_ylabel("权重值")
    ax4.grid(True)

    plt.tight_layout()
    plt.show()


def plot_loss_curves(train_losses, val_losses=None):
    """
    绘制训练和验证损失曲线
    """
    epochs = [log["epoch"] for log in train_losses]
    train_loss_vals = [log["loss"] for log in train_losses]

    if val_losses is not None:
        val_loss_vals = [log["loss"] for log in val_losses]

    plt.rcParams["font.sans-serif"] = ["SimHei", "Arial Unicode MS", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False

    plt.figure(figsize=(10, 6))
    plt.plot(epochs, train_loss_vals, color="red", linestyle="-", label="训练损失")
    if val_losses is not None:
        plt.plot(epochs, val_loss_vals, color="blue", linestyle="--", label="验证损失")

    plt.title("损失函数变化")
    plt.xlabel("轮次（Epoch）")
    plt.ylabel("损失（Loss）")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()


def preview_file(file_path, n=5):
    """
    预览文本文件的前 n 行内容
    """
    try:
        data = []
        with open(file_path, "r", encoding="utf-8") as file:
            for i in range(n):
                line = file.readline()
                data.append({"行数": i + 1, "内容": line.strip()})
                if not line:
                    break
        return to_dataframe(data)
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到")
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
