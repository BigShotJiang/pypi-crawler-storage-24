"""Configuration schemas for AgentiCraft packages."""

from __future__ import annotations

from pydantic import BaseModel, Field


class RetryConfig(BaseModel):
    """Configuration for retry behavior."""

    max_retries: int = Field(default=3, ge=0, le=10)
    backoff_factor: float = Field(default=2.0, gt=0)
    max_backoff: float = Field(default=30.0, gt=0)
    jitter: bool = True


class CircuitBreakerConfig(BaseModel):
    """Configuration for circuit breaker behavior."""

    failure_threshold: int = Field(default=5, ge=1)
    recovery_timeout: float = Field(default=60.0, gt=0)
    success_threshold: int = Field(default=2, ge=1)
    monitoring_window: float = Field(default=60.0, gt=0)


class RateLimitConfig(BaseModel):
    """Configuration for rate limiting."""

    max_calls: int = Field(default=100, ge=1)
    time_window: float = Field(default=60.0, gt=0)
    burst_size: int | None = None


__all__ = [
    "RetryConfig",
    "CircuitBreakerConfig",
    "RateLimitConfig",
]
