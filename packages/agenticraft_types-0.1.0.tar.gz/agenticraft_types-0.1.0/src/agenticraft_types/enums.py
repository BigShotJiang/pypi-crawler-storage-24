"""Shared enumerations for AgentiCraft packages."""

from __future__ import annotations

from enum import Enum


class ProviderName(str, Enum):
    """Supported LLM provider identifiers."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    AZURE_OPENAI = "azure_openai"
    BEDROCK = "bedrock"
    FIREWORKS = "fireworks"
    CEREBRAS = "cerebras"
    COHERE = "cohere"
    DEEPSEEK = "deepseek"
    XAI = "xai"
    OLLAMA = "ollama"
    OPENROUTER = "openrouter"
    PERPLEXITY = "perplexity"
    NEBIUS = "nebius"
    GROQ = "groq"
    TOGETHER = "together"
    MISTRAL = "mistral"


class FailureType(str, Enum):
    """Classification of failure types for circuit breakers and error handling."""

    RATE_LIMIT = "rate_limit"
    AUTH = "auth"
    MODEL = "model"
    NETWORK = "network"
    CONTENT = "content"
    TIMEOUT = "timeout"
    SERVICE_ERROR = "service_error"
    CONNECTION_ERROR = "connection_error"
    UNKNOWN = "unknown"


class RoutingStrategy(str, Enum):
    """Provider routing/selection strategies."""

    THOMPSON = "thompson"
    ROUND_ROBIN = "round_robin"
    COST_AWARE = "cost_aware"
    RANDOM = "random"
    LEAST_USED = "least_used"
    LATENCY = "latency"
    QUALITY = "quality"


class MessageRole(str, Enum):
    """Message roles in a conversation."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class CircuitBreakerState(str, Enum):
    """Circuit breaker states."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


__all__ = [
    "ProviderName",
    "FailureType",
    "RoutingStrategy",
    "MessageRole",
    "CircuitBreakerState",
]
