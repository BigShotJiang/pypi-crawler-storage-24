"""Version information for agenticraft-types."""

__version__ = "0.1.0"
