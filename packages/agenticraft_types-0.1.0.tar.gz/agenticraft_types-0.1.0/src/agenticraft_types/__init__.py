"""
agenticraft-types: Shared type definitions for AgentiCraft packages.

Pure data structures, protocols, and error hierarchy.
Zero business logic. Only dependency: pydantic>=2.0.
"""

from __future__ import annotations

from ._version import __version__
from .config import CircuitBreakerConfig, RateLimitConfig, RetryConfig
from .enums import (
    CircuitBreakerState,
    FailureType,
    MessageRole,
    ProviderName,
    RoutingStrategy,
)
from .errors import (
    AgentiCraftError,
    AuthenticationError,
    CircuitOpenError,
    ConfigError,
    ContentFilterError,
    ModelNotFoundError,
    NoProvidersAvailableError,
    OrchestrationError,
    ProviderError,
    QuotaExceededError,
    RateLimitError,
    TimeoutError,
)
from .models import (
    CompletionRequest,
    CompletionResponse,
    Message,
    ProviderConfig,
    StreamChunk,
    Usage,
)
from .protocols import (
    CircuitBreakerLike,
    KeyPoolLike,
    Provider,
    Router,
    StreamingProvider,
)

__all__ = [
    "__version__",
    # Enums
    "ProviderName",
    "FailureType",
    "RoutingStrategy",
    "MessageRole",
    "CircuitBreakerState",
    # Models
    "Message",
    "Usage",
    "CompletionRequest",
    "CompletionResponse",
    "StreamChunk",
    "ProviderConfig",
    # Errors
    "AgentiCraftError",
    "ProviderError",
    "RateLimitError",
    "AuthenticationError",
    "ModelNotFoundError",
    "ContentFilterError",
    "TimeoutError",
    "CircuitOpenError",
    "ConfigError",
    "QuotaExceededError",
    "OrchestrationError",
    "NoProvidersAvailableError",
    # Protocols
    "Provider",
    "StreamingProvider",
    "Router",
    "CircuitBreakerLike",
    "KeyPoolLike",
    # Config
    "RetryConfig",
    "CircuitBreakerConfig",
    "RateLimitConfig",
]
