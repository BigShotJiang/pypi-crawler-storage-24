"""Pydantic v2 request/response models for LLM interactions."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .enums import MessageRole


class Message(BaseModel):
    """A single message in a conversation."""

    role: MessageRole
    content: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    name: str | None = None
    tool_call_id: str | None = None


class Usage(BaseModel):
    """Token usage statistics."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float | None = None


class CompletionRequest(BaseModel):
    """Canonical LLM completion request."""

    messages: list[Message]
    model: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    top_p: float | None = None
    stream: bool = False
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict[str, Any] | None = None
    system_prompt: str | None = None
    stop: list[str] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class CompletionResponse(BaseModel):
    """Canonical LLM completion response."""

    content: str
    usage: Usage | None = None
    provider: str | None = None
    model: str | None = None
    latency_ms: float | None = None
    cost: float | None = None
    finish_reason: str | None = None
    tool_calls: list[dict[str, Any]] | None = None


class StreamChunk(BaseModel):
    """Streaming response chunk."""

    delta: str = ""
    finish_reason: str | None = None
    tool_call_delta: dict[str, Any] | None = None


class ProviderConfig(BaseModel):
    """Configuration for an LLM provider."""

    name: str
    api_key: str | None = None
    base_url: str | None = None
    models: list[str] = Field(default_factory=list)
    timeout: int = 60
    max_retries: int = 3


__all__ = [
    "Message",
    "Usage",
    "CompletionRequest",
    "CompletionResponse",
    "StreamChunk",
    "ProviderConfig",
]
