"""Tests for protocol classes."""

from agenticraft_types.protocols import (
    CircuitBreakerLike,
    KeyPoolLike,
    Provider,
    Router,
    StreamingProvider,
)


class TestProtocolsAreRuntimeCheckable:
    def test_provider_checkable(self):
        assert hasattr(Provider, "__protocol_attrs__") or hasattr(
            Provider, "__abstractmethods__"
        )

    def test_router_checkable(self):
        assert hasattr(Router, "__protocol_attrs__") or hasattr(
            Router, "__abstractmethods__"
        )

    def test_circuit_breaker_checkable(self):
        assert hasattr(CircuitBreakerLike, "__protocol_attrs__") or hasattr(
            CircuitBreakerLike, "__abstractmethods__"
        )

    def test_key_pool_checkable(self):
        assert hasattr(KeyPoolLike, "__protocol_attrs__") or hasattr(
            KeyPoolLike, "__abstractmethods__"
        )

    def test_streaming_provider_checkable(self):
        assert hasattr(StreamingProvider, "__protocol_attrs__") or hasattr(
            StreamingProvider, "__abstractmethods__"
        )


class TestCircuitBreakerLikeConformance:
    def test_conforming_class(self):
        class MyCB:
            @property
            def is_open(self) -> bool:
                return False

            def record_success(self) -> None:
                pass

            def record_failure(self) -> None:
                pass

            def reset(self) -> None:
                pass

        assert isinstance(MyCB(), CircuitBreakerLike)


class TestKeyPoolLikeConformance:
    def test_conforming_class(self):
        class MyPool:
            async def acquire(self) -> str:
                return "key"

            async def record_success(self, key: str, **kwargs) -> None:
                pass

            async def record_error(self, key: str, **kwargs) -> None:
                pass

        assert isinstance(MyPool(), KeyPoolLike)
