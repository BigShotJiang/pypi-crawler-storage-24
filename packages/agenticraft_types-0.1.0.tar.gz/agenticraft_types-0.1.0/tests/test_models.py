"""Tests for Pydantic v2 models."""

from agenticraft_types.enums import MessageRole
from agenticraft_types.models import (
    CompletionRequest,
    CompletionResponse,
    Message,
    ProviderConfig,
    StreamChunk,
    Usage,
)


class TestMessage:
    def test_basic(self):
        msg = Message(role=MessageRole.USER, content="hello")
        assert msg.role == MessageRole.USER
        assert msg.content == "hello"

    def test_tool_message(self):
        msg = Message(role=MessageRole.TOOL, content="result", tool_call_id="tc-1")
        assert msg.tool_call_id == "tc-1"

    def test_serialization(self):
        msg = Message(role=MessageRole.USER, content="hello")
        data = msg.model_dump()
        assert data["role"] == "user"
        assert data["content"] == "hello"


class TestUsage:
    def test_defaults(self):
        usage = Usage()
        assert usage.prompt_tokens == 0
        assert usage.total_tokens == 0
        assert usage.cost_usd is None

    def test_with_values(self):
        usage = Usage(prompt_tokens=100, completion_tokens=50, total_tokens=150, cost_usd=0.01)
        assert usage.total_tokens == 150
        assert usage.cost_usd == 0.01


class TestCompletionRequest:
    def test_minimal(self):
        req = CompletionRequest(messages=[Message(role=MessageRole.USER, content="hi")])
        assert len(req.messages) == 1
        assert req.stream is False

    def test_with_tools(self):
        req = CompletionRequest(
            messages=[Message(role=MessageRole.USER, content="hi")],
            model="gpt-4",
            tools=[{"type": "function", "function": {"name": "test"}}],
        )
        assert req.tools is not None
        assert len(req.tools) == 1


class TestCompletionResponse:
    def test_minimal(self):
        resp = CompletionResponse(content="hello")
        assert resp.content == "hello"
        assert resp.usage is None

    def test_with_usage(self):
        resp = CompletionResponse(
            content="hello",
            usage=Usage(prompt_tokens=10, completion_tokens=5, total_tokens=15),
            provider="openai",
            model="gpt-4",
            finish_reason="stop",
        )
        assert resp.usage.total_tokens == 15
        assert resp.provider == "openai"

    def test_with_tool_calls(self):
        resp = CompletionResponse(
            content="",
            tool_calls=[{"id": "tc-1", "name": "search", "arguments": {}}],
        )
        assert len(resp.tool_calls) == 1


class TestStreamChunk:
    def test_defaults(self):
        chunk = StreamChunk()
        assert chunk.delta == ""
        assert chunk.finish_reason is None

    def test_with_content(self):
        chunk = StreamChunk(delta="hello", finish_reason="stop")
        assert chunk.delta == "hello"
        assert chunk.finish_reason == "stop"

    def test_with_tool_delta(self):
        chunk = StreamChunk(tool_call_delta={"index": 0, "id": "tc-1"})
        assert chunk.tool_call_delta["index"] == 0


class TestProviderConfig:
    def test_defaults(self):
        config = ProviderConfig(name="openai")
        assert config.timeout == 60
        assert config.max_retries == 3
        assert config.models == []

    def test_full(self):
        config = ProviderConfig(
            name="openai",
            api_key="sk-test",
            base_url="https://api.openai.com",
            models=["gpt-4", "gpt-3.5-turbo"],
        )
        assert len(config.models) == 2
