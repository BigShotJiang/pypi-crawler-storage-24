"""Tests for exception hierarchy."""

import pytest

from agenticraft_types.errors import (
    AgentiCraftError,
    AuthenticationError,
    CircuitOpenError,
    ConfigError,
    ContentFilterError,
    ModelNotFoundError,
    NoProvidersAvailableError,
    OrchestrationError,
    ProviderError,
    QuotaExceededError,
    RateLimitError,
    TimeoutError,
)


class TestAgentiCraftError:
    def test_base_error(self):
        err = AgentiCraftError("something failed")
        assert str(err) == "something failed"
        assert err.message == "something failed"
        assert err.details == {}

    def test_with_details(self):
        err = AgentiCraftError("fail", details={"key": "value"})
        assert err.details == {"key": "value"}

    def test_is_exception(self):
        assert issubclass(AgentiCraftError, Exception)


class TestProviderError:
    def test_attributes(self):
        err = ProviderError("bad", provider="openai", model="gpt-4", status_code=500)
        assert err.provider == "openai"
        assert err.model == "gpt-4"
        assert err.status_code == 500

    def test_str_format(self):
        err = ProviderError("error", provider="openai", model="gpt-4")
        assert "openai" in str(err)
        assert "gpt-4" in str(err)

    def test_inherits_base(self):
        assert issubclass(ProviderError, AgentiCraftError)


class TestRateLimitError:
    def test_retry_after(self):
        err = RateLimitError("rate limited", retry_after=30.0)
        assert err.retry_after == 30.0

    def test_inherits_provider_error(self):
        assert issubclass(RateLimitError, ProviderError)


class TestAuthenticationError:
    def test_inherits_provider_error(self):
        assert issubclass(AuthenticationError, ProviderError)


class TestModelNotFoundError:
    def test_available_models(self):
        err = ModelNotFoundError("not found", available_models=["gpt-4", "gpt-3.5"])
        assert err.available_models == ["gpt-4", "gpt-3.5"]

    def test_default_empty_list(self):
        err = ModelNotFoundError("not found")
        assert err.available_models == []


class TestTimeoutError:
    def test_timeout_seconds(self):
        err = TimeoutError("timed out", timeout_seconds=30.0)
        assert err.timeout_seconds == 30.0


class TestCircuitOpenError:
    def test_attributes(self):
        err = CircuitOpenError("circuit open", provider="openai")
        assert err.provider == "openai"

    def test_inherits_base(self):
        assert issubclass(CircuitOpenError, AgentiCraftError)


class TestConfigError:
    def test_attributes(self):
        err = ConfigError("bad config", field="api_key", value=None)
        assert err.field == "api_key"
        assert err.value is None


class TestQuotaExceededError:
    def test_attributes(self):
        err = QuotaExceededError("quota", tenant_id="t1", resource="tokens", limit=1000, current=1001)
        assert err.tenant_id == "t1"
        assert err.limit == 1000


class TestOrchestrationError:
    def test_attributes(self):
        err = OrchestrationError("all failed", strategy="round_robin", providers_tried=["a", "b"])
        assert err.strategy == "round_robin"
        assert err.providers_tried == ["a", "b"]

    def test_no_providers_inherits(self):
        assert issubclass(NoProvidersAvailableError, OrchestrationError)


class TestHierarchy:
    def test_catch_all_with_base(self):
        with pytest.raises(AgentiCraftError):
            raise RateLimitError("rate limited")

    def test_catch_provider_errors(self):
        with pytest.raises(ProviderError):
            raise AuthenticationError("bad key")

    def test_catch_orchestration_errors(self):
        with pytest.raises(OrchestrationError):
            raise NoProvidersAvailableError("none available")
