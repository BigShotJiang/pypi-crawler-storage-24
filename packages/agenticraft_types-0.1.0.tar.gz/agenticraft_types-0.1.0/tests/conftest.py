"""Pytest configuration for agenticraft-types tests."""
