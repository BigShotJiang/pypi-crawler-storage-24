"""Tests for shared enumerations."""

from agenticraft_types.enums import (
    CircuitBreakerState,
    FailureType,
    MessageRole,
    ProviderName,
    RoutingStrategy,
)


class TestProviderName:
    def test_values(self):
        assert ProviderName.OPENAI == "openai"
        assert ProviderName.ANTHROPIC == "anthropic"
        assert ProviderName.GOOGLE == "google"

    def test_all_providers(self):
        assert len(ProviderName) == 17

    def test_string_comparison(self):
        assert ProviderName.OPENAI == "openai"
        assert ProviderName("openai") == ProviderName.OPENAI


class TestFailureType:
    def test_values(self):
        assert FailureType.RATE_LIMIT == "rate_limit"
        assert FailureType.TIMEOUT == "timeout"

    def test_all_types(self):
        assert len(FailureType) == 9


class TestRoutingStrategy:
    def test_values(self):
        assert RoutingStrategy.THOMPSON == "thompson"
        assert RoutingStrategy.ROUND_ROBIN == "round_robin"

    def test_all_strategies(self):
        assert len(RoutingStrategy) == 7


class TestMessageRole:
    def test_values(self):
        assert MessageRole.SYSTEM == "system"
        assert MessageRole.USER == "user"
        assert MessageRole.ASSISTANT == "assistant"
        assert MessageRole.TOOL == "tool"


class TestCircuitBreakerState:
    def test_values(self):
        assert CircuitBreakerState.CLOSED == "closed"
        assert CircuitBreakerState.OPEN == "open"
        assert CircuitBreakerState.HALF_OPEN == "half_open"

    def test_all_states(self):
        assert len(CircuitBreakerState) == 3
