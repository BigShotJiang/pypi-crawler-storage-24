# Changelog

All notable changes to agenticraft-types will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-03-07

Initial release of shared type definitions for AgentiCraft packages.

### Added

- **Enums**: `ProviderName` (17 providers), `FailureType` (9 types), `RoutingStrategy` (7), `MessageRole` (4), `CircuitBreakerState` (3)
- **Models**: Pydantic v2 `CompletionRequest`, `CompletionResponse`, `StreamChunk`, `Usage`, `Message`, `ProviderConfig`
- **Errors**: 12-class exception hierarchy rooted at `AgentiCraftError`
- **Protocols**: `Provider`, `StreamingProvider`, `Router`, `CircuitBreakerLike`, `KeyPoolLike` (all `@runtime_checkable`)
- **Config**: `RetryConfig`, `CircuitBreakerConfig`, `RateLimitConfig`
- Apache 2.0 license, `py.typed`, Python 3.10+

[Unreleased]: https://github.com/agenticraft/agenticraft-types/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/agenticraft/agenticraft-types/releases/tag/v0.1.0
