from __future__ import annotations

from typing import Any

from sapiopycommons.general.aliases import SapioRecord, AliasUtil


class VersionId:
    """
    A versioned identifier consisting of a UUID and a version number.
    Serializes to/from a string in the format "uuid:version" or "uuid:draft".
    """
    uuid: str
    version: int | None

    def __init__(self, uuid: str, version: int | None = None):
        """
        :param uuid: The UUID portion of the identifier.
        :param version: The version number, or None for a draft.
        """
        self.uuid = uuid
        self.version = version

    @staticmethod
    def from_json(value: str) -> VersionId:
        """
        Parse a VersionId from its string representation (format: "uuid:version" or "uuid:draft").

        :param value: The string representation of the VersionId.
        :return: The parsed VersionId.
        """
        parts = value.split(":")
        uuid = parts[0]
        if len(parts) > 1:
            version_str = parts[1]
            if version_str.lower() == "draft":
                version = None
            else:
                version = int(version_str)
                if version <= 0:
                    version = None
        else:
            version = None
        return VersionId(uuid, version)

    def to_json(self) -> str:
        """
        Serialize this VersionId to its string representation.

        :return: A string in the format "uuid:version" or "uuid:draft".
        """
        if self.version is not None and self.version > 0:
            return f"{self.uuid}:{self.version}"
        return f"{self.uuid}:draft"

    def __str__(self) -> str:
        if self.version is not None and self.version > 0:
            return f"{self.uuid} v{self.version}"
        return f"{self.uuid} DRAFT"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, VersionId):
            return NotImplemented
        return self.uuid == other.uuid and self.version == other.version

    def __hash__(self) -> int:
        return hash((self.uuid, self.version))


class ContentType:
    """
    Represents a pipeline content type such as JSON, CSV, or custom user-defined formats.
    """
    name: str
    display_name: str | None
    extensions: list[str]

    def __init__(self, name: str, display_name: str | None = None, extensions: list[str] | None = None):
        """
        :param name: The content type name (e.g. "JSON", "CSV", "BINARY").
        :param display_name: An optional human-readable display name.
        :param extensions: File extensions associated with this content type.
        """
        self.name = name
        self.display_name = display_name
        self.extensions = extensions or []

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> ContentType:
        """
        Deserialize a ContentType from a JSON dictionary.

        :param json_dct: The JSON dictionary.
        :return: The deserialized ContentType.
        """
        return ContentType(
            name=json_dct.get("name", ""),
            display_name=json_dct.get("displayName"),
            extensions=json_dct.get("extensions") or []
        )

    def to_json(self) -> dict[str, Any]:
        """
        Serialize this ContentType to a JSON dictionary.

        :return: A JSON-serializable dictionary.
        """
        result: dict[str, Any] = {"name": self.name}
        if self.display_name is not None:
            result["displayName"] = self.display_name
        if self.extensions:
            result["extensions"] = self.extensions
        return result

    def __str__(self) -> str:
        return self.display_name or self.name

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ContentType):
            return NotImplemented
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


class PipelineTemplateInfo:
    """
    Summary information for a pipeline template without the step definitions.
    """
    id: VersionId
    display_name: str | None
    description: str | None
    category: str | None
    active: bool
    restricted: bool
    pipeline_image: bytes | None
    created_by: str | None
    date_created: int | None
    last_modified_by: str | None
    last_modified_date: int | None
    published_by: str | None
    published_date: int | None

    def __init__(self, version_id: VersionId, display_name: str | None = None):
        """
        :param version_id: The unique versioned identifier for this pipeline template.
        :param display_name: The human-readable display name of the pipeline template.
        """
        self.id = version_id
        self.display_name = display_name
        self.description = None
        self.category = None
        self.active = True
        self.restricted = False
        self.pipeline_image = None
        self.created_by = None
        self.date_created = None
        self.last_modified_by = None
        self.last_modified_date = None
        self.published_by = None
        self.published_date = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> PipelineTemplateInfo:
        """
        Deserialize a PipelineTemplateInfo from a JSON dictionary.

        :param json_dct: The JSON dictionary from the server.
        :return: The deserialized PipelineTemplateInfo.
        """
        id_value = json_dct.get("id")
        version_id = VersionId.from_json(id_value) if isinstance(id_value, str) else VersionId("", None)
        info = PipelineTemplateInfo(version_id, json_dct.get("displayName"))
        info.description = json_dct.get("description")
        info.category = json_dct.get("category")
        info.active = json_dct.get("active", True)
        info.restricted = json_dct.get("restricted", False)
        info.pipeline_image = json_dct.get("pipelineImage")
        info.created_by = json_dct.get("createdBy")
        info.date_created = json_dct.get("dateCreated")
        info.last_modified_by = json_dct.get("lastModifiedBy")
        info.last_modified_date = json_dct.get("lastModifiedDate")
        info.published_by = json_dct.get("publishedBy")
        info.published_date = json_dct.get("publishedDate")
        return info

    def to_json(self) -> dict[str, Any]:
        """
        Serialize this PipelineTemplateInfo to a JSON dictionary.

        :return: A JSON-serializable dictionary.
        """
        result: dict[str, Any] = {
            "id": self.id.to_json(),
            "displayName": self.display_name,
            "description": self.description,
            "category": self.category,
            "active": self.active,
            "restricted": self.restricted,
            "createdBy": self.created_by,
            "dateCreated": self.date_created,
            "lastModifiedBy": self.last_modified_by,
            "lastModifiedDate": self.last_modified_date,
            "publishedBy": self.published_by,
            "publishedDate": self.published_date,
        }
        if self.pipeline_image is not None:
            result["pipelineImage"] = self.pipeline_image
        return result

    def __str__(self) -> str:
        return f"{self.display_name} {self.id}"


class PipelineTemplate(PipelineTemplateInfo):
    """
    A pipeline template is a blueprint for a pipeline that can be used to create a pipeline instance.
    Extends PipelineTemplateInfo with step definitions and execution configuration.
    """
    step_templates: list[dict[str, Any]]
    execute_group_name: str | None

    def __init__(self, info: PipelineTemplateInfo):
        """
        :param info: The base PipelineTemplateInfo to extend.
        """
        super().__init__(info.id, info.display_name)
        self.__dict__ = info.__dict__.copy()
        self.step_templates = []
        self.execute_group_name = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> PipelineTemplate:
        """
        Deserialize a PipelineTemplate from a JSON dictionary.

        :param json_dct: The JSON dictionary from the server.
        :return: The deserialized PipelineTemplate.
        """
        template = PipelineTemplate(PipelineTemplateInfo.from_json(json_dct))
        template.step_templates = json_dct.get("stepTemplates") or []
        template.execute_group_name = json_dct.get("executeGroupName")
        return template

    def to_json(self) -> dict[str, Any]:
        """
        Serialize this PipelineTemplate to a JSON dictionary.

        :return: A JSON-serializable dictionary.
        """
        result = super().to_json()
        result["stepTemplates"] = self.step_templates
        if self.execute_group_name is not None:
            result["executeGroupName"] = self.execute_group_name
        return result


class TriggerPipelineWithRecordsRequest:
    """
    Request body for triggering a pipeline from a template with record inputs.
    """
    pipeline_template: str
    inputs: list[dict[str, Any]]

    def __init__(self, pipeline_template: VersionId | str, inputs: list[dict[str, Any] | SapioRecord]):
        """
        :param pipeline_template: Pipeline template identifier in the format templateId:version (e.g. "uuid:1").
            Drafts must use :draft.
        :param inputs: Array of record payloads. Each item may include record_id to select an existing record;
            omit to create a new record. Fields are applied to the record at creation or update time.
        """
        if isinstance(pipeline_template, VersionId):
            self.pipeline_template = pipeline_template.to_json()
        else:
            self.pipeline_template = pipeline_template
        self.inputs = []
        for record in inputs:
            if isinstance(record, dict):
                self.inputs.append(record)
            else:
                self.inputs.append(AliasUtil.to_field_map(record, True))

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> TriggerPipelineWithRecordsRequest:
        """
        Deserialize a TriggerPipelineWithRecordsRequest from a JSON dictionary.

        :param json_dct: The JSON dictionary.
        :return: The deserialized request.
        """
        return TriggerPipelineWithRecordsRequest(
            pipeline_template=json_dct.get("pipeline_template", ""),
            inputs=json_dct.get("inputs") or []
        )

    def to_json(self) -> dict[str, Any]:
        """
        Serialize this request to a JSON dictionary.

        :return: A JSON-serializable dictionary.
        """
        return {
            "pipeline_template": self.pipeline_template,
            "inputs": self.inputs,
        }


class TriggerPipelineWithRecordsResponse:
    """
    Response for triggering a pipeline from a template with record inputs.
    """
    success: bool
    pipeline_id: int
    pipeline_step_id: int
    input_count: int
    message: str | None
    record_ids: list[int] | None
    trigger_ids: list[int] | None

    def __init__(self):
        self.success = False
        self.pipeline_id = 0
        self.pipeline_step_id = 0
        self.input_count = 0
        self.message = None
        self.record_ids = None
        self.trigger_ids = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> TriggerPipelineWithRecordsResponse:
        """
        Deserialize a TriggerPipelineWithRecordsResponse from a JSON dictionary.

        :param json_dct: The JSON dictionary from the server.
        :return: The deserialized response.
        """
        response = TriggerPipelineWithRecordsResponse()
        response.success = json_dct.get("success", False)
        response.pipeline_id = json_dct.get("pipeline_id", 0)
        response.pipeline_step_id = json_dct.get("pipeline_step_id", 0)
        response.input_count = json_dct.get("input_count", 0)
        response.message = json_dct.get("message")
        response.record_ids = json_dct.get("record_ids")
        response.trigger_ids = json_dct.get("trigger_ids")
        return response

    def to_json(self) -> dict[str, Any]:
        """
        Serialize this response to a JSON dictionary.

        :return: A JSON-serializable dictionary.
        """
        result: dict[str, Any] = {
            "success": self.success,
            "pipeline_id": self.pipeline_id,
            "pipeline_step_id": self.pipeline_step_id,
            "input_count": self.input_count,
        }
        if self.message is not None:
            result["message"] = self.message
        if self.record_ids is not None:
            result["record_ids"] = self.record_ids
        if self.trigger_ids is not None:
            result["trigger_ids"] = self.trigger_ids
        return result
