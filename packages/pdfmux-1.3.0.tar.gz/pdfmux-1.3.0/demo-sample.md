# **Quarterly Report - Q4 2025**

Revenue: $2.4M (+18% YoY)

Active Users: 14,200

Churn Rate: 3.2%


Key Highlights:

# 1. Launched enterprise tier with SSO support

# 2. Reduced P95 latency from 420ms to 180ms

# 3. Expanded to 3 new markets (DACH, Nordics, ANZ)