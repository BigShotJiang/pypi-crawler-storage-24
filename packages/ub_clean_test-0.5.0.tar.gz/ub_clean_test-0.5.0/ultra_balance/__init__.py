__version__ = '0.5.0'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")