"""Image generation service -- orchestrates providers and scratch storage.

The ``ImageService`` is the DI service object injected into MCP tools.
It holds registered providers, dispatches generation requests, manages
an in-memory image registry backed by sidecar JSON files, and saves
generated images to the scratch directory.
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, ClassVar

from PIL import Image as PILImage

from image_generation_mcp.processing import (
    convert_format,
    crop_to_dimensions,
    resize_image,
)
from image_generation_mcp.providers.capabilities import (
    ProviderCapabilities,
    make_degraded,
)
from image_generation_mcp.providers.types import (
    ImageProvider,
    ImageProviderError,
    ImageResult,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ImageRecord:
    """Metadata for a registered image in the scratch directory."""

    id: str
    original_path: Path
    content_type: str
    provider: str
    prompt: str
    negative_prompt: str | None
    aspect_ratio: str
    quality: str
    original_dimensions: tuple[int, int]
    provider_metadata: dict[
        str, Any
    ]  # treat as read-only; frozen prevents reassignment
    created_at: float


class ImageService:
    """Central orchestrator for image generation.

    Args:
        scratch_dir: Directory for saving generated images.
        default_provider: Provider name to use when none specified.
        transform_cache_size: Maximum number of transform results to keep
            in the in-memory LRU cache. Set to 0 to disable caching.
    """

    def __init__(
        self,
        scratch_dir: Path,
        default_provider: str = "auto",
        transform_cache_size: int = 64,
    ) -> None:
        self._providers: dict[str, ImageProvider] = {}
        self._capabilities: dict[str, ProviderCapabilities] = {}
        self._scratch_dir = scratch_dir
        self._default_provider = default_provider
        self._images: dict[str, ImageRecord] = {}
        # NOTE: OrderedDict is not thread-safe. This cache assumes single-threaded
        # access from the asyncio event loop (no to_thread dispatch).
        self._transform_cache: OrderedDict[
            tuple[str, str, int, int, int], tuple[bytes, str]
        ] = OrderedDict()
        self._transform_cache_size = transform_cache_size

        # Rebuild registry from existing sidecar files
        self._load_registry()

    @property
    def scratch_dir(self) -> Path:
        """The scratch directory for saved images."""
        return self._scratch_dir

    @property
    def providers(self) -> dict[str, ImageProvider]:
        """Registered providers (read-only view)."""
        return self._providers

    async def aclose(self) -> None:
        """Close all providers that support async cleanup."""
        for provider in self._providers.values():
            if hasattr(provider, "aclose"):
                await provider.aclose()
        self._transform_cache.clear()

    @property
    def capabilities(self) -> dict[str, ProviderCapabilities]:
        """Discovered provider capabilities."""
        return self._capabilities

    def register_provider(self, name: str, provider: ImageProvider) -> None:
        """Register an image provider.

        Args:
            name: Provider name (e.g., ``"openai"``, ``"placeholder"``).
            provider: Provider instance implementing ``ImageProvider``.
        """
        self._providers[name] = provider
        logger.info("Registered image provider: %s", name)

    async def discover_all_capabilities(self) -> None:
        """Discover capabilities for all registered providers.

        Calls ``discover_capabilities()`` on each provider. If a provider
        raises an exception, it is registered with ``degraded=True`` and
        an empty model list — server startup is not blocked.
        """
        for name, provider in self._providers.items():
            try:
                caps = await provider.discover_capabilities()
                self._capabilities[name] = caps
                model_count = len(caps.models)
                logger.info(
                    "Discovered capabilities for %s: %d model(s)%s",
                    name,
                    model_count,
                    " (degraded)" if caps.degraded else "",
                )
            except Exception:
                logger.warning(
                    "Capability discovery failed for %s — marking degraded",
                    name,
                    exc_info=True,
                )
                self._capabilities[name] = make_degraded(name, time.time())

    _PROVIDER_DESCRIPTIONS: ClassVar[dict[str, str]] = {
        "openai": (
            "OpenAI (gpt-image-1 / dall-e-3) — best for text, logos, "
            "and general-purpose generation"
        ),
        "a1111": (
            "Stable Diffusion via A1111 WebUI — best for photorealism, "
            "portraits, and artistic styles"
        ),
        "placeholder": (
            "Zero-cost solid-color PNG — instant, no API key, for testing and drafts"
        ),
    }

    def list_providers(self) -> dict[str, dict[str, Any]]:
        """List registered providers with availability and capability info.

        Returns:
            Dict of provider name -> ``{available, description, capabilities}``.
            The ``capabilities`` key is present only after discovery has run.
        """
        result: dict[str, dict[str, Any]] = {}
        for name in self._providers:
            entry: dict[str, Any] = {
                "available": True,
                "description": self._PROVIDER_DESCRIPTIONS.get(name, name),
            }
            if name in self._capabilities:
                entry["capabilities"] = self._capabilities[name].to_dict()
            result[name] = entry
        return result

    def _resolve_provider(
        self,
        provider: str,
        prompt: str,
        *,
        background: str = "opaque",
    ) -> tuple[str, ImageProvider]:
        """Resolve a provider name to an instance.

        Args:
            provider: Provider name or ``"auto"``.
            prompt: The generation prompt (used for auto-selection).
            background: Requested background mode (used for capability filtering).

        Returns:
            Tuple of (resolved_name, provider_instance).

        Raises:
            ImageProviderError: If no matching provider is available.
        """
        if not self._providers:
            raise ImageProviderError(
                provider,
                "No providers are registered. Configure at least one: "
                "set IMAGE_GENERATION_MCP_OPENAI_API_KEY for OpenAI, "
                "IMAGE_GENERATION_MCP_A1111_HOST for Stable Diffusion, "
                "or the placeholder provider is always available.",
            )

        if provider == "auto":
            from image_generation_mcp.providers.selector import select_provider

            selected = select_provider(
                prompt,
                set(self._providers),
                capabilities=self._capabilities or None,
                background=background,
            )
            return selected, self._providers[selected]

        if provider not in self._providers:
            available = ", ".join(self._providers)
            raise ImageProviderError(
                provider,
                f"Provider '{provider}' not available. Available: {available}",
            )
        return provider, self._providers[provider]

    async def generate(
        self,
        prompt: str,
        *,
        provider: str | None = None,
        negative_prompt: str | None = None,
        aspect_ratio: str = "1:1",
        quality: str = "standard",
        background: str = "opaque",
        model: str | None = None,
    ) -> tuple[str, ImageResult]:
        """Generate an image using a provider.

        Args:
            prompt: Text prompt for image generation.
            provider: Provider name, or ``None`` to use the configured default.
            negative_prompt: Things to avoid in the image.
            aspect_ratio: Desired aspect ratio.
            quality: Quality level.
            background: Background transparency (``opaque``, ``transparent``).
                Provider support varies.
            model: Specific model to use (e.g., a checkpoint name for A1111,
                or ``"dall-e-3"`` for OpenAI). Passed through to the provider.

        Returns:
            Tuple of (provider_name, ImageResult).

        Raises:
            ImageProviderError: If generation fails.
        """
        resolved_name, resolved_provider = self._resolve_provider(
            provider or self._default_provider,
            prompt,
            background=background,
        )

        # Warn if the resolved provider has degraded capabilities
        caps = self._capabilities.get(resolved_name)
        if caps and caps.degraded:
            logger.warning(
                "Generating with degraded provider %s — capability "
                "discovery failed at startup",
                resolved_name,
            )

        logger.info(
            "Generating image with provider=%s, aspect_ratio=%s",
            resolved_name,
            aspect_ratio,
        )

        result = await resolved_provider.generate(
            prompt,
            negative_prompt=negative_prompt,
            aspect_ratio=aspect_ratio,
            quality=quality,
            background=background,
            model=model,
        )

        return resolved_name, result

    # ------------------------------------------------------------------
    # Image registry
    # ------------------------------------------------------------------

    def register_image(
        self,
        result: ImageResult,
        provider_name: str,
        *,
        prompt: str,
        negative_prompt: str | None = None,
        aspect_ratio: str = "1:1",
        quality: str = "standard",
        background: str = "opaque",
    ) -> ImageRecord:
        """Register a generated image in the scratch directory.

        Saves the original image, writes a sidecar JSON metadata file,
        and stores the record in the in-memory registry.

        Args:
            result: The image result to register.
            provider_name: Name of the provider that generated the image.
            prompt: The generation prompt.
            negative_prompt: Things to avoid (if any).
            aspect_ratio: Requested aspect ratio.
            quality: Requested quality level.
            background: Requested background transparency.

        Returns:
            The created ImageRecord.
        """
        self._scratch_dir.mkdir(parents=True, exist_ok=True)

        # Content-addressed ID
        image_id = hashlib.sha256(result.image_data).hexdigest()[:12]

        # Extract original dimensions via Pillow
        img = PILImage.open(io.BytesIO(result.image_data))
        original_dimensions = img.size  # (width, height)

        # Save original
        ext = _mime_to_ext(result.content_type)
        original_filename = f"{image_id}-original{ext}"
        original_path = self._scratch_dir / original_filename
        original_path.write_bytes(result.image_data)

        # Build record
        record = ImageRecord(
            id=image_id,
            original_path=original_path,
            content_type=result.content_type,
            provider=provider_name,
            prompt=prompt,
            negative_prompt=negative_prompt,
            aspect_ratio=aspect_ratio,
            quality=quality,
            original_dimensions=original_dimensions,
            provider_metadata=result.provider_metadata,
            created_at=time.time(),
        )

        # Write sidecar JSON
        sidecar_path = self._scratch_dir / f"{image_id}.json"
        sidecar_data = {
            "id": record.id,
            "prompt": record.prompt,
            "negative_prompt": record.negative_prompt,
            "provider": record.provider,
            "aspect_ratio": record.aspect_ratio,
            "quality": record.quality,
            "background": background,
            "content_type": record.content_type,
            "original_filename": original_filename,
            "original_size_bytes": result.size_bytes,
            "original_dimensions": list(record.original_dimensions),
            "provider_metadata": record.provider_metadata,
            "created_at": datetime.fromtimestamp(record.created_at, tz=UTC).isoformat(),
        }
        sidecar_path.write_text(json.dumps(sidecar_data, indent=2))

        # Store in registry
        self._images[image_id] = record

        logger.info(
            "Registered image %s from %s (%d bytes)",
            image_id,
            provider_name,
            result.size_bytes,
        )
        return record

    def get_image(self, image_id: str) -> ImageRecord:
        """Look up a registered image by ID.

        Args:
            image_id: The content-addressed image ID.

        Returns:
            The ImageRecord for the image.

        Raises:
            ImageProviderError: If the image ID is not found.
        """
        if image_id not in self._images:
            raise ImageProviderError(
                "server",
                f"Image '{image_id}' not found. "
                "Read image://list to see available IDs.",
            )
        return self._images[image_id]

    def get_transformed_image(
        self,
        image_id: str,
        format: str = "",
        width: int = 0,
        height: int = 0,
        quality: int = 90,
    ) -> tuple[bytes, str]:
        """Return image bytes with optional transforms, using an LRU cache.

        Requests with no transform parameters (``format`` empty and both
        ``width`` and ``height`` zero) bypass the cache entirely and return
        the original file bytes directly.

        Args:
            image_id: Image registry ID.
            format: Target format (``"png"``, ``"webp"``, ``"jpeg"``), or
                empty string to keep the original format.
            width: Target width in pixels, or ``0`` for original.
            height: Target height in pixels, or ``0`` for original.
            quality: Compression quality for lossy formats (1-100).

        Returns:
            Tuple of ``(image_bytes, content_type)``.

        Raises:
            ImageProviderError: If *image_id* is not registered.
        """
        record = self.get_image(image_id)

        # No-transform bypass: skip cache for plain original reads
        if not format and width == 0 and height == 0:
            return record.original_path.read_bytes(), record.content_type

        key = (image_id, format, width, height, quality)

        # Cache hit: move to end (most-recently-used) and return
        if key in self._transform_cache:
            self._transform_cache.move_to_end(key)
            return self._transform_cache[key]

        # Cache miss: compute transform
        data = record.original_path.read_bytes()
        content_type = record.content_type

        # Apply resize/crop first (always from original to prevent quality
        # degradation — see ADR-0006)
        if width > 0 and height > 0:
            data = crop_to_dimensions(data, width, height)
        elif width > 0:
            orig_w, orig_h = record.original_dimensions
            ratio = width / orig_w
            new_height = round(orig_h * ratio)
            data = resize_image(data, width, new_height)
        elif height > 0:
            orig_w, orig_h = record.original_dimensions
            ratio = height / orig_h
            new_width = round(orig_w * ratio)
            data = resize_image(data, new_width, height)

        # Apply format conversion last (one encode from spatial result)
        if format:
            data, content_type = convert_format(data, format, quality=quality)

        # Store in cache, evict oldest if over size limit
        if self._transform_cache_size > 0:
            self._transform_cache[key] = (data, content_type)
            if len(self._transform_cache) > self._transform_cache_size:
                self._transform_cache.popitem(last=False)

        return data, content_type

    def list_images(self) -> list[ImageRecord]:
        """Return all registered images.

        Returns:
            List of ImageRecord instances.
        """
        return list(self._images.values())

    def _load_registry(self) -> None:
        """Rebuild the in-memory registry from sidecar JSON files."""
        if not self._scratch_dir.exists():
            return

        count = 0
        for sidecar_path in sorted(self._scratch_dir.glob("*.json")):
            try:
                data = json.loads(sidecar_path.read_text())
                image_id = data["id"]
                original_path = self._scratch_dir / data["original_filename"]
                if not original_path.exists():
                    logger.warning(
                        "Skipping sidecar %s: original file missing (%s)",
                        sidecar_path,
                        original_path,
                    )
                    continue

                # Parse ISO timestamp back to epoch
                created_at = datetime.fromisoformat(data["created_at"]).timestamp()

                record = ImageRecord(
                    id=image_id,
                    original_path=original_path,
                    content_type=data["content_type"],
                    provider=data["provider"],
                    prompt=data["prompt"],
                    negative_prompt=data.get("negative_prompt"),
                    aspect_ratio=data.get("aspect_ratio", "1:1"),
                    quality=data.get("quality", "standard"),
                    original_dimensions=tuple(data["original_dimensions"]),
                    provider_metadata=data.get("provider_metadata", {}),
                    created_at=created_at,
                )
                self._images[image_id] = record
                count += 1
            except (json.JSONDecodeError, KeyError, TypeError, ValueError):
                logger.warning("Skipping corrupt sidecar file: %s", sidecar_path)

        if count:
            logger.info("Loaded %d images from scratch directory", count)


_MIME_TO_EXT: dict[str, str] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
}


def _mime_to_ext(content_type: str) -> str:
    """Map MIME type to file extension."""
    return _MIME_TO_EXT.get(content_type, ".png")
