from LumAPI import *

fdtd = lumapi.FDTD()










