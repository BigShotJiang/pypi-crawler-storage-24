"""
Data models for SnapGene file format
"""

from .base import SgffModel, SgffListModel
from .sequence import SgffSequence
from .feature import SgffFeature, SgffFeatureList, SgffSegment
from .history import (
    SgffHistory,
    SgffHistoryNode,
    SgffHistoryNodeContent,
    SgffHistoryTree,
    SgffHistoryTreeNode,
    SgffHistoryOligo,
    SgffInputSummary,
    HistoryOperation,
)
from .primer import SgffBindingSite, SgffPrimer, SgffPrimerList
from .notes import SgffNotes
from .properties import SgffProperties
from .alignment import SgffAlignment, SgffAlignmentList
from .trace import SgffTrace, SgffTraceList, SgffTraceClip, SgffTraceSamples
from .ops import SgffOps

__all__ = [
    "SgffModel",
    "SgffListModel",
    "SgffSequence",
    "SgffFeature",
    "SgffFeatureList",
    "SgffSegment",
    "SgffHistory",
    "SgffHistoryNode",
    "SgffHistoryNodeContent",
    "SgffHistoryTree",
    "SgffHistoryTreeNode",
    "SgffHistoryOligo",
    "SgffInputSummary",
    "HistoryOperation",
    "SgffBindingSite",
    "SgffPrimer",
    "SgffPrimerList",
    "SgffNotes",
    "SgffProperties",
    "SgffAlignment",
    "SgffAlignmentList",
    "SgffTrace",
    "SgffTraceList",
    "SgffTraceClip",
    "SgffTraceSamples",
    "SgffOps",
]
