"""
Block type parsers and parsing scheme
"""

import struct
import lzma
import logging
import json
import zlib
from io import BytesIO
from typing import Dict, Tuple, Optional, Callable, Any, List

import xmltodict

logger = logging.getLogger(__name__)


def parse_blocks(stream) -> Dict[int, List[Any]]:
    """Parse TLV blocks from stream."""
    result: Dict[int, List[Any]] = {}

    while True:
        block_type, block_length = read_header(stream)
        if block_type is None:
            break

        data = stream.read(block_length)

        # Skip unknown blocks
        parser = SCHEME.get(block_type)
        if parser is None:
            logger.debug(
                "Skipping unknown block type %d (%d bytes)", block_type, block_length
            )
            continue

        parsed = parser(data)
        if parsed is not None:
            if block_type not in result:
                result[block_type] = []
            result[block_type].append(parsed)

    return result


def read_header(stream) -> Tuple[Optional[int], Optional[int]]:
    """Read TLV block header."""
    type_byte = stream.read(1)
    if not type_byte:
        return None, None
    return type_byte[0], struct.unpack(">I", stream.read(4))[0]


def octet_to_dna(raw_data: bytes, base_count: int) -> bytes:
    """Convert 2-bit encoded DNA to ASCII sequence."""
    bases = b"GATC"
    result = bytearray()
    for byte in raw_data:
        remaining = base_count - len(result)
        if remaining <= 0:
            break
        shifts = [6, 4, 2, 0] if remaining >= 4 else [6, 4, 2, 0][-remaining:]
        for shift in shifts:
            if len(result) < base_count:
                result.append(bases[(byte >> shift) & 3])
    return bytes(result[:base_count])


# =============================================================================
# SEQUENCE PARSERS
# =============================================================================


def parse_sequence(data: bytes) -> Dict[str, Any]:
    """Parse uncompressed sequence block with property flags."""
    props = data[0]
    sequence = data[1:].decode("utf-8", errors="ignore")

    return {
        "sequence": sequence,
        "length": len(sequence),
        "topology": "circular" if props & 0x01 else "linear",
        "strandedness": "double" if props & 0x02 else "single",
        "dam_methylated": bool(props & 0x04),
        "dcm_methylated": bool(props & 0x08),
        "ecoki_methylated": bool(props & 0x10),
    }


def parse_compressed_dna(data: bytes) -> Dict[str, Any]:
    """Parse compressed DNA block with 2-bit GATC encoding and metadata header."""
    offset = 0

    _compressed_length = struct.unpack(">I", data[offset : offset + 4])[0]
    offset += 4

    uncompressed_length = struct.unpack(">I", data[offset : offset + 4])[0]
    offset += 4

    # Decode the 14-byte metadata header
    header = data[offset : offset + 14]
    offset += 14

    format_version = header[0]
    strandedness_flag = header[4]
    property_flags = struct.unpack(">H", header[8:10])[0]
    header_seq_length = struct.unpack(">H", header[12:14])[0]

    total_bytes = (uncompressed_length * 2 + 7) // 8
    seq_data = data[offset : offset + total_bytes]

    return {
        "sequence": octet_to_dna(seq_data, uncompressed_length).decode("ascii"),
        "length": uncompressed_length,
        "format_version": format_version,
        "strandedness_flag": strandedness_flag,
        "property_flags": property_flags,
        "header_seq_length": header_seq_length,
    }


# =============================================================================
# XML PARSERS
# =============================================================================


def _clean_xml_dict(obj: Any) -> Any:
    """Convert xmltodict format to clean JSON keys."""
    if isinstance(obj, dict):
        result = {}
        for key, value in obj.items():
            # Remove @ prefix from attribute keys
            clean_key = key[1:] if key.startswith("@") else key
            # Convert #text to _text
            if clean_key == "#text":
                clean_key = "_text"
            result[clean_key] = _clean_xml_dict(value)
        return result
    elif isinstance(obj, list):
        return [_clean_xml_dict(item) for item in obj]
    else:
        return obj


def parse_xml(data: bytes) -> Optional[Dict]:
    """Parse XML block into dict with clean JSON keys."""
    try:
        xml_str = data.decode("utf-8", errors="ignore")
        parsed = xmltodict.parse(xml_str)
        return _clean_xml_dict(parsed)
    except Exception as e:
        logger.debug("Failed to parse XML: %s", e)
        return None


def parse_lzma_xml(data: bytes) -> Optional[Dict]:
    """Parse LZMA-compressed XML block into dict with clean JSON keys."""
    try:
        decompressed = lzma.decompress(data)
        parsed = xmltodict.parse(decompressed.decode("utf-8", errors="ignore"))
        return _clean_xml_dict(parsed)
    except Exception as e:
        logger.debug("Failed to parse LZMA XML: %s", e)
        return None


def parse_lzma_json(data: bytes) -> Optional[Any]:
    """Parse LZMA-compressed JSON block."""
    try:
        decompressed = lzma.decompress(data)
        return json.loads(decompressed)
    except Exception as e:
        logger.debug("Failed to parse LZMA JSON: %s", e)
        return None


def parse_lzma_nested(data: bytes) -> Optional[Dict[int, List[Any]]]:
    """Parse LZMA-compressed block containing nested TLV blocks."""
    try:
        decompressed = lzma.decompress(data)
        return parse_blocks(BytesIO(decompressed))
    except Exception as e:
        logger.debug("Failed to parse LZMA nested blocks: %s", e)
        return None


# =============================================================================
# FEATURE PARSER
# =============================================================================

STRAND_MAP = {"0": ".", "1": "+", "2": "-", "3": "="}

_FEATURE_KNOWN_KEYS = frozenset({"name", "type", "directionality", "Segment", "Q"})


def parse_features(data: bytes) -> Optional[Dict]:
    """Parse features block with qualifier extraction."""
    raw = parse_xml(data)
    if not raw or "Features" not in raw:
        return raw

    # Handle empty <Features></Features> element (xmltodict returns None)
    if raw["Features"] is None:
        return {"features": [], "wrapper_extras": {}}

    features_wrapper = raw["Features"]

    # Capture wrapper-level extras (nextValidID, recycledIDs)
    wrapper_extras = {
        k: v for k, v in features_wrapper.items() if k != "Feature"
    }

    features_data = features_wrapper.get("Feature", [])
    if not isinstance(features_data, list):
        features_data = [features_data]

    features = []
    for feature in features_data:
        segments = feature.get("Segment", [])
        if not isinstance(segments, list):
            segments = [segments]

        # Parse segment ranges
        ranges = []
        for seg in segments:
            if "range" in seg:
                r = [int(x) for x in seg["range"].split("-")]
                ranges.append(r)

        # Parse qualifiers
        qualifiers = _parse_qualifiers(feature.get("Q", []))

        # Preserve raw qualifier list for lossless roundtrip
        raw_quals = feature.get("Q", [])
        if raw_quals and not isinstance(raw_quals, list):
            raw_quals = [raw_quals]

        color = segments[0].get("color", "") if segments else ""

        # Feature-level extras (unmodeled XML attrs)
        extras = {
            k: v for k, v in feature.items() if k not in _FEATURE_KNOWN_KEYS
        }

        features.append(
            {
                "name": feature.get("name", ""),
                "type": feature.get("type", ""),
                "strand": STRAND_MAP.get(feature.get("directionality", "0"), "."),
                "start": ranges[0][0] - 1 if ranges else 0,
                "end": ranges[-1][1] if ranges else 0,
                "color": color,
                "segments": segments,
                "qualifiers": qualifiers,
                "extras": extras,
                "raw_qualifiers": raw_quals if raw_quals else None,
            }
        )

    return {"features": features, "wrapper_extras": wrapper_extras}


def _parse_qualifiers(quals: Any) -> Dict[str, Any]:
    """Extract qualifiers from feature data."""
    if not quals:
        return {}
    if not isinstance(quals, list):
        quals = [quals]

    result = {}
    for q in quals:
        name = q.get("name", "")
        val = q.get("V")

        if val is None:
            continue
        elif isinstance(val, dict):
            result[name] = _extract_value(val)
        elif isinstance(val, list):
            result[name] = [_extract_value(v) for v in val]
        else:
            result[name] = val

    return result


def _extract_value(v: Dict) -> Any:
    """Extract typed value from qualifier data."""
    if "text" in v:
        return v["text"]
    if "int" in v:
        return int(v["int"])
    # Return first value found
    for key, val in v.items():
        if key != "_text":
            return val
    return v


# =============================================================================
# ZTR PARSER
# =============================================================================

ZTR_MAGIC = b"\xaeZTR\r\n\x1a\n"


def _ztr_decompress(chunk_data: bytes) -> bytes:
    """Decompress ZTR chunk data."""
    if not chunk_data:
        return chunk_data

    format_byte = chunk_data[0]

    # Format 0: raw data
    if format_byte == 0:
        return chunk_data

    # Format 2: zlib compressed
    if format_byte == 2 and len(chunk_data) > 5:
        try:
            return b"\x00" + zlib.decompress(chunk_data[5:])
        except Exception:
            pass

    return chunk_data


def parse_ztr(data: bytes) -> Optional[Dict[str, Any]]:
    """Parse ZTR format sequence trace data."""
    if len(data) < 10 or data[:8] != ZTR_MAGIC:
        return None

    result: Dict[str, Any] = {}
    offset = 10  # Skip magic (8) + version (2)

    while offset + 8 <= len(data):
        # Chunk header: type (4) + metadata_length (4)
        chunk_type = data[offset : offset + 4].decode("ascii", errors="ignore").strip()
        meta_len = struct.unpack(">I", data[offset + 4 : offset + 8])[0]

        # Store metadata if present (e.g., SAMP has 4-byte channel name)
        meta_data = data[offset + 8 : offset + 8 + meta_len] if meta_len > 0 else None
        offset += 8 + meta_len

        if offset + 4 > len(data):
            break

        # Data length
        data_len = struct.unpack(">I", data[offset : offset + 4])[0]
        offset += 4

        if offset + data_len > len(data):
            break

        chunk_data = data[offset : offset + data_len]
        chunk_data = _ztr_decompress(chunk_data)

        # Parse chunk based on type
        if chunk_type == "BASE" and len(chunk_data) > 1:
            # Format byte + padding + ASCII bases
            result["bases"] = chunk_data[2:].decode("ascii", errors="ignore")

        elif chunk_type == "BPOS" and len(chunk_data) > 4:
            # Format byte + 3 padding + 4-byte positions
            positions = []
            for i in range(4, len(chunk_data), 4):
                if i + 4 <= len(chunk_data):
                    pos = struct.unpack(">I", chunk_data[i : i + 4])[0]
                    positions.append(pos)
            result["positions"] = positions

        elif chunk_type == "CNF4" and len(chunk_data) > 1:
            # Format byte + confidence values (1 byte per base)
            # First value is confidence of called base, then A/C/G/T values
            confidence = list(chunk_data[1:])
            result["confidence"] = confidence

        elif chunk_type == "SMP4" and len(chunk_data) > 2:
            # Format byte + padding + interleaved ACGT 16-bit samples
            sample_data = chunk_data[2:]
            trace_len = len(sample_data) // 8  # 4 channels * 2 bytes
            samples: Dict[str, list] = {"A": [], "C": [], "G": [], "T": []}
            for i, base in enumerate(["A", "C", "G", "T"]):
                start = i * trace_len * 2
                for j in range(0, trace_len * 2, 2):
                    if start + j + 2 <= len(sample_data):
                        val = struct.unpack(
                            ">H", sample_data[start + j : start + j + 2]
                        )[0]
                        samples[base].append(val)
            result["samples"] = samples

        elif chunk_type == "SAMP" and meta_data and len(chunk_data) > 2:
            # Metadata: 4-byte channel name (e.g., "A\x00\x00\x00")
            # Data: Format byte + padding + 16-bit samples
            channel = meta_data[0:1].decode("ascii", errors="ignore")
            if channel in "ACGT":
                sample_data = chunk_data[2:]
                trace = []
                for j in range(0, len(sample_data), 2):
                    if j + 2 <= len(sample_data):
                        val = struct.unpack(">H", sample_data[j : j + 2])[0]
                        trace.append(val)
                if "samples" not in result:
                    result["samples"] = {}
                result["samples"][channel] = trace

        elif chunk_type == "TEXT" and len(chunk_data) > 2:
            # Format byte + padding + null-terminated key-value pairs
            items = chunk_data[2:].rstrip(b"\x00").split(b"\x00")
            text = {}
            for i in range(0, len(items) - 1, 2):
                key = items[i].decode("ascii", errors="ignore")
                val = items[i + 1].decode("ascii", errors="ignore")
                if key:
                    text[key] = val
            result["text"] = text

        elif chunk_type == "CLIP" and len(chunk_data) >= 9:
            # Format byte + left (4) + right (4)
            result["clip"] = {
                "left": struct.unpack(">I", chunk_data[1:5])[0],
                "right": struct.unpack(">I", chunk_data[5:9])[0],
            }

        elif chunk_type == "COMM" and len(chunk_data) > 1:
            # Format byte + free text
            comment = chunk_data[1:].decode("ascii", errors="ignore").rstrip("\x00")
            if "comments" not in result:
                result["comments"] = []
            result["comments"].append(comment)

        offset += data_len

    return result if result else None


# =============================================================================
# TRACE CONTAINER PARSER
# =============================================================================


def parse_trace_container(data: bytes) -> Dict[str, Any]:
    """Parse trace container block with flags and nested TLV blocks."""
    result: Dict[str, Any] = {}

    # 4-byte header flags
    flags = struct.unpack(">I", data[:4])[0]
    result["flags"] = flags

    # Parse nested blocks from remaining data
    if len(data) > 4:
        nested = parse_blocks(BytesIO(data[4:]))
        if nested:
            result["blocks"] = nested

    return result


# =============================================================================
# HISTORY NODE PARSER
# =============================================================================


def parse_history_node(data: bytes) -> Dict[str, Any]:
    """Parse history node block containing sequence snapshot and nested blocks."""
    node = {}
    offset = 0

    node["node_index"] = struct.unpack(">I", data[offset : offset + 4])[0]
    offset += 4

    seq_type = data[offset]
    node["sequence_type"] = seq_type
    offset += 1

    # Type 29: modifier only
    if seq_type == 29:
        if offset < len(data):
            nested = parse_blocks(BytesIO(data[offset:]))
            if nested:
                node["node_info"] = nested
        return node

    # Type 1: compressed DNA
    if seq_type == 1:
        compressed_length = struct.unpack(">I", data[offset : offset + 4])[0]
        compressed_start = offset + 4

        block_data = data[offset : compressed_start + compressed_length]
        result = parse_compressed_dna(block_data)
        if result:
            node.update(result)

        offset = compressed_start + compressed_length

    # Types 0, 21, 32: uncompressed
    elif seq_type in [0, 21, 32]:
        seq_length = struct.unpack(">I", data[offset : offset + 4])[0]
        offset += 4
        node["sequence"] = data[offset : offset + seq_length].decode(
            "ascii", errors="ignore"
        )
        node["length"] = seq_length
        offset += seq_length

    # Parse remaining nested blocks
    if offset < len(data):
        nested = parse_blocks(BytesIO(data[offset:]))
        if nested:
            node["node_info"] = nested

    return node


# =============================================================================
# PARSING SCHEME
# =============================================================================

# Format: block_type -> parser_function
# Known blocks are parsed; unknown blocks (2, 3, 13) are skipped
# as SnapGene regenerates them on import.
SCHEME: Dict[int, Callable] = {
    0: parse_sequence,  # DNA
    1: parse_compressed_dna,  # 2bit compressed DNA
    5: parse_xml,  # Primers
    6: parse_xml,  # Notes
    7: parse_lzma_xml,  # History tree
    8: parse_xml,  # Sequence properties
    10: parse_features,  # Features
    11: parse_history_node,  # History node container
    14: parse_xml,  # Custom enzyme sets
    16: parse_trace_container,  # Trace container (nested 18 + 8)
    17: parse_xml,  # Alignable sequences
    18: parse_ztr,  # Sequence trace (inside block 16)
    20: parse_xml,  # Strand colors
    21: parse_sequence,  # Protein
    28: parse_xml,  # Enzyme visibilities
    29: parse_lzma_xml,  # History modifier
    30: parse_lzma_nested,  # History node content
    32: parse_sequence,  # RNA
    34: parse_lzma_json,  # RNA structure predictions (LZMA JSON)
}
