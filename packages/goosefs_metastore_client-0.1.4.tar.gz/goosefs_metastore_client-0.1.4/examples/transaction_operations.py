"""Example: Transaction operations with Lance/GooseFS compatible styles.

This example demonstrates transaction management:
- describe_transaction: Describe a transaction (Lance id / GooseFS transaction_id)
- alter_transaction: Alter transaction state
- batch_commit_tables: Batch commit mixed table operations atomically
"""
from goosefs_metastore_client import GoosefsMetastoreClient
from grpc_files.table_master_pb2 import (
    DescribeTransactionPRequest,
    AlterTransactionPRequest,
    BatchCommitTablesPRequest,
    CommitTableOperation,
    DeclareTablePRequest,
    CreateTableVersionPRequest,
    BatchDeleteTableVersionsPRequest,
    DeregisterTablePRequest,
)

GOOSEFS_HOST = "localhost"
GOOSEFS_PORT = 9220


def example_describe_transaction_lance_style():
    """Describe a transaction using Lance style id field."""
    print("=" * 60)
    print("Example: Describe Transaction - Lance Style")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        request = DescribeTransactionPRequest()
        request.id.extend(["txn_12345"])  # Lance field
        
        print(f"  ID (Lance): {list(request.id)}")
        
        try:
            result = client.describe_transaction(request)
            print(f"  Transaction properties: {result.get('properties', {})}")
            if "status" in result:
                print(f"  Status: {result['status']}")
        except Exception as e:
            print(f"  Failed: {e}")


def example_describe_transaction_goosefs_style():
    """Describe a transaction using GooseFS style transaction_id field."""
    print("=" * 60)
    print("Example: Describe Transaction - GooseFS Style")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        request = DescribeTransactionPRequest()
        request.transaction_id = "txn_12345"  # GooseFS field
        
        print(f"  Transaction ID (GooseFS): {request.transaction_id}")
        
        try:
            result = client.describe_transaction(request)
            print(f"  Transaction properties: {result.get('properties', {})}")
            if "status" in result:
                print(f"  Status: {result['status']}")
        except Exception as e:
            print(f"  Failed: {e}")


def example_alter_transaction():
    """Alter a transaction state."""
    print("=" * 60)
    print("Example: Alter Transaction")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        # Commit a transaction
        commit_request = AlterTransactionPRequest()
        commit_request.transaction_id = "txn_12345"
        commit_request.action = "COMMIT"  # COMMIT, ROLLBACK, ABORT
        
        print(f"  Transaction: {commit_request.transaction_id}")
        print(f"  Action: {commit_request.action}")
        
        try:
            result = client.alter_transaction(commit_request)
            print(f"  Transaction committed successfully!")
            if "status" in result:
                print(f"  Status: {result['status']}")
            print(f"  Properties: {result.get('properties', {})}")
        except Exception as e:
            print(f"  Commit failed: {e}")


def example_batch_commit_tables():
    """Batch commit mixed table operations atomically.
    
    Supports combining DeclareTable, CreateTableVersion,
    DeleteTableVersions, and DeregisterTable operations
    into a single atomic transaction.
    """
    print("=" * 60)
    print("Example: Batch Commit Tables")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        request = BatchCommitTablesPRequest()
        
        # Operation 1: Declare a new table
        op1 = request.operations.add()
        declare_req = DeclareTablePRequest()
        declare_req.id.extend(["my_catalog", "my_database", "new_table"])
        declare_req.location = "s3://my-bucket/tables/new_table"
        declare_req.properties["owner"] = "admin"
        op1.declare_table.CopyFrom(declare_req)
        
        # Operation 2: Create a version for an existing table
        op2 = request.operations.add()
        create_ver_req = CreateTableVersionPRequest()
        create_ver_req.id.extend(["my_catalog", "my_database", "existing_table"])
        create_ver_req.version = 3
        create_ver_req.manifest_path = "s3://my-bucket/tables/existing_table/_versions/3.manifest"
        create_ver_req.manifest_size = 2048
        create_ver_req.metadata["description"] = "Batch commit version"
        op2.create_table_version.CopyFrom(create_ver_req)
        
        # Operation 3: Delete versions from another table
        op3 = request.operations.add()
        delete_ver_req = BatchDeleteTableVersionsPRequest()
        delete_ver_req.id.extend(["my_catalog", "my_database", "old_table"])
        op3.delete_table_versions.CopyFrom(delete_ver_req)
        
        # Operation 4: Deregister a table
        op4 = request.operations.add()
        deregister_req = DeregisterTablePRequest()
        deregister_req.id.extend(["my_catalog", "my_database", "deprecated_table"])
        op4.deregister_table.CopyFrom(deregister_req)
        
        print(f"  Committing {len(request.operations)} operations atomically:")
        print(f"    1. DeclareTable: new_table")
        print(f"    2. CreateTableVersion: existing_table v3")
        print(f"    3. DeleteTableVersions: old_table")
        print(f"    4. DeregisterTable: deprecated_table")
        
        try:
            result = client.batch_commit_tables(request)
            print(f"\n  Batch commit successful!")
            if "transaction_id" in result:
                print(f"  Transaction ID: {result['transaction_id']}")
            results = result.get("results", [])
            print(f"  Got {len(results)} result(s):")
            for i, r in enumerate(results):
                print(f"    Result {i+1}: {r}")
        except Exception as e:
            print(f"  Batch commit failed: {e}")


def main():
    """Run all transaction examples."""
    print()
    print("#" * 60)
    print("# Transaction Operations Examples")
    print("#" * 60)
    print()
    
    example_describe_transaction_lance_style()
    print()
    example_describe_transaction_goosefs_style()
    print()
    example_alter_transaction()
    print()
    example_batch_commit_tables()
    print()


if __name__ == "__main__":
    main()
