"""Complete example showing all gRPC-based operations with the new client interface.

This example demonstrates the complete workflow using the new gRPC PRequest-based API:
1. Namespace operations (create, list, describe, exists, drop)
2. Table operations (create, describe, insert, query, update, delete, drop)
3. Index operations (create, list, describe, drop)
4. Version operations (list, create, describe, batch delete, batch create, restore)
5. Tag operations (create, list, get version, update, delete)
6. Schema operations (update metadata, add/alter/drop columns)
7. Stats and query plan
8. Registration operations (declare, register, deregister)
9. Transaction operations (describe, alter, batch commit)
"""
from goosefs_metastore_client import GoosefsMetastoreClient
from grpc_files.table_master_pb2 import (
    ListNamespacesPRequest,
    CreateNamespacePRequest,
    DescribeNamespacePRequest,
    NamespaceExistsPRequest,
    DropNamespacePRequest,
    CreateTablePRequest,
    DescribeTablePRequest,
    TableExistsPRequest,
    InsertIntoTablePRequest,
    QueryTablePRequest,
    CountTableRowsPRequest,
    UpdateTablePRequest,
    DeleteFromTablePRequest,
    DropTablePRequest,
    ListTablesPRequest,
    ListAllTablesPRequest,
    CreateTableIndexPRequest,
    ListTableIndicesPRequest,
    DescribeTableIndexStatsPRequest,
    DropTableIndexPRequest,
    ListTableVersionsPRequest,
    CreateTableVersionPRequest,
    DescribeTableVersionPRequest,
    BatchDeleteTableVersionsPRequest,
    BatchCreateTableVersionsPRequest,
    CreateTableVersionEntry,
    BatchCommitTablesPRequest,
    CommitTableOperation,
    RestoreTablePRequest,
    CreateTableTagPRequest,
    ListTableTagsPRequest,
    GetTableTagVersionPRequest,
    DeleteTableTagPRequest,
    GetTableStatsPRequest,
    ExplainTableQueryPlanPRequest,
    UpdateTableSchemaMetadataPRequest,
    AlterTableAddColumnsPRequest,
    DeclareTablePRequest,
    RegisterTablePRequest,
    DeregisterTablePRequest,
    DescribeTransactionPRequest,
    AlterTransactionPRequest,
)

GOOSEFS_HOST = "localhost"
GOOSEFS_PORT = 9220


def main():
    print("=" * 70)
    print("GooseFS Metastore Client - Complete Example (gRPC API)")
    print("=" * 70)
    print()

    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:

        # --- 1. Namespace Operations ---
        print("1. Creating a namespace...")
        try:
            req = CreateNamespacePRequest()
            req.id.extend(["my_catalog", "example_ns"])
            req.properties["owner"] = "admin"
            req.mode = "CREATE_IF_NOT_EXISTS"
            result = client.create_namespace(req)
            print(f"   Namespace created. Properties: {result.get('properties', {})}")
        except Exception as e:
            print(f"   Create namespace: {e}")
        print()

        print("2. Listing namespaces...")
        try:
            req = ListNamespacesPRequest()
            req.id.extend(["my_catalog"])
            result = client.list_namespaces(req)
            print(f"   Found {len(result['namespaces'])} namespace(s)")
        except Exception as e:
            print(f"   List namespaces: {e}")
        print()

        print("3. Checking if namespace exists...")
        try:
            req = NamespaceExistsPRequest()
            req.id.extend(["my_catalog", "example_ns"])
            exists = client.namespace_exists(req)
            print(f"   Namespace exists: {exists}")
        except Exception as e:
            print(f"   Namespace exists: {e}")
        print()

        # --- 2. Table Operations ---
        print("4. Creating a table...")
        try:
            req = CreateTablePRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.schema = "id INT, name STRING, age INT"
            req.location = "s3://my-bucket/tables/users"
            req.mode = "CREATE_IF_NOT_EXISTS"
            result = client.create_table(req)
            print(f"   Table created. Location: {result.get('location', 'N/A')}")
        except Exception as e:
            print(f"   Create table: {e}")
        print()

        print("5. Checking if table exists...")
        try:
            req = TableExistsPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            exists = client.table_exists(req)
            print(f"   Table exists: {exists}")
        except Exception as e:
            print(f"   Table exists: {e}")
        print()

        print("6. Describing a table...")
        try:
            req = DescribeTablePRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.load_detailed_metadata = True
            result = client.describe_table(req)
            print(f"   Location: {result.get('location', 'N/A')}")
            print(f"   Metadata: {result.get('metadata', {})}")
        except Exception as e:
            print(f"   Describe table: {e}")
        print()

        print("7. Inserting data...")
        try:
            req = InsertIntoTablePRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.data = "[(1, 'Alice', 25), (2, 'Bob', 30)]"
            req.mode = "APPEND"
            result = client.insert_into_table(req)
            print(f"   Insert result: {result}")
        except Exception as e:
            print(f"   Insert: {e}")
        print()

        print("8. Querying table...")
        try:
            req = QueryTablePRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.query = "SELECT * FROM users WHERE age > 20"
            req.limit = 10
            result = client.query_table(req)
            print(f"   Query result: {result}")
        except Exception as e:
            print(f"   Query: {e}")
        print()

        print("9. Counting rows...")
        try:
            req = CountTableRowsPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            count = client.count_table_rows(req)
            print(f"   Row count: {count}")
        except Exception as e:
            print(f"   Count rows: {e}")
        print()

        print("10. Listing tables in namespace...")
        try:
            req = ListTablesPRequest()
            req.id.extend(["my_catalog", "example_ns"])
            req.limit = 20
            result = client.list_tables(req)
            print(f"   Tables: {result.get('tables', [])}")
        except Exception as e:
            print(f"   List tables: {e}")
        print()

        print("11. Listing all tables...")
        try:
            req = ListAllTablesPRequest()
            req.limit = 50
            result = client.list_all_tables(req)
            print(f"   All tables: {len(result.get('tables', []))} found")
        except Exception as e:
            print(f"   List all tables: {e}")
        print()

        # --- 3. Index Operations ---
        print("12. Creating an index...")
        try:
            req = CreateTableIndexPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.columns.extend(["name"])
            req.index_type = "BTREE"
            req.index_name = "idx_name"
            result = client.create_table_index(req)
            print(f"   Index created: {result}")
        except Exception as e:
            print(f"   Create index: {e}")
        print()

        print("13. Listing indices...")
        try:
            req = ListTableIndicesPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            result = client.list_table_indices(req)
            indices = result.get("indices", [])
            print(f"   Found {len(indices)} index(es)")
        except Exception as e:
            print(f"   List indices: {e}")
        print()

        # --- 4. Version Operations ---
        print("14. Listing table versions...")
        try:
            req = ListTableVersionsPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            result = client.list_table_versions(req)
            versions = result.get("versions", [])
            print(f"   Found {len(versions)} version(s)")
        except Exception as e:
            print(f"   List versions: {e}")
        print()

        print("15. Creating a table version...")
        try:
            req = CreateTableVersionPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.version = 2
            req.manifest_path = "s3://my-bucket/tables/users/_versions/2.manifest"
            req.manifest_size = 2048
            result = client.create_table_version(req)
            print(f"   Version created: {result}")
        except Exception as e:
            print(f"   Create version: {e}")
        print()

        print("16. Describing a table version...")
        try:
            req = DescribeTableVersionPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.version = 1
            result = client.describe_table_version(req)
            print(f"   Version details: {result}")
        except Exception as e:
            print(f"   Describe version: {e}")
        print()

        # --- 5. Tag Operations ---
        print("17. Creating a tag...")
        try:
            req = CreateTableTagPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.tag = "v1.0"
            req.version = 1
            result = client.create_table_tag(req)
            print(f"   Tag created: {result}")
        except Exception as e:
            print(f"   Create tag: {e}")
        print()

        print("18. Listing tags...")
        try:
            req = ListTableTagsPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            result = client.list_table_tags(req)
            tags = result.get("tags", {})
            print(f"   Found {len(tags)} tag(s)")
            for name, contents in tags.items():
                print(f"   - {name}: {contents}")
        except Exception as e:
            print(f"   List tags: {e}")
        print()

        print("19. Getting tag version...")
        try:
            req = GetTableTagVersionPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.tag = "v1.0"
            version = client.get_table_tag_version(req)
            print(f"   Tag 'v1.0' -> version {version}")
        except Exception as e:
            print(f"   Get tag version: {e}")
        print()

        # --- 6. Schema & Stats Operations ---
        print("20. Getting table stats...")
        try:
            req = GetTableStatsPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            result = client.get_table_stats(req)
            print(f"   Stats: {result}")
        except Exception as e:
            print(f"   Get stats: {e}")
        print()

        print("21. Explaining query plan...")
        try:
            req = ExplainTableQueryPlanPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.query = "SELECT * FROM users WHERE age > 25"
            plan = client.explain_table_query_plan(req)
            print(f"   Plan: {plan}")
        except Exception as e:
            print(f"   Explain plan: {e}")
        print()

        print("22. Adding columns...")
        try:
            req = AlterTableAddColumnsPRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.columns.extend(["email STRING", "created_at TIMESTAMP"])
            result = client.alter_table_add_columns(req)
            print(f"   Columns added: {result}")
        except Exception as e:
            print(f"   Add columns: {e}")
        print()

        # --- 7. Registration Operations ---
        print("23. Declaring a table...")
        try:
            req = DeclareTablePRequest()
            req.id.extend(["my_catalog", "example_ns", "declared_table"])
            req.location = "s3://my-bucket/data/declared_table"
            result = client.declare_table(req)
            print(f"   Declared: {result}")
        except Exception as e:
            print(f"   Declare table: {e}")
        print()

        print("24. Registering namespace impl...")
        try:
            client.register_namespace_impl("lance", "com.example.LanceImpl")
            print(f"   Registered!")
        except Exception as e:
            print(f"   Register impl: {e}")
        print()

        print("25. Checking registration...")
        try:
            is_reg = client.is_registered("lance")
            print(f"   lance registered: {is_reg}")
        except Exception as e:
            print(f"   Is registered: {e}")
        print()

        # --- 8. Transaction Operations ---
        print("26. Describing transaction...")
        try:
            req = DescribeTransactionPRequest()
            req.transaction_id = "txn_example"
            result = client.describe_transaction(req)
            print(f"   Transaction: {result}")
        except Exception as e:
            print(f"   Describe transaction: {e}")
        print()

        # --- 9. Batch Operations ---
        print("27. Batch creating table versions...")
        try:
            req = BatchCreateTableVersionsPRequest()
            entry1 = req.entries.add()
            entry1.id.extend(["my_catalog", "example_ns", "users"])
            entry1.version = 10
            entry1.manifest_path = "s3://my-bucket/tables/users/_versions/10.manifest"
            entry1.manifest_size = 4096
            entry1.metadata["author"] = "admin"
            entry2 = req.entries.add()
            entry2.id.extend(["my_catalog", "example_ns", "users"])
            entry2.version = 11
            entry2.manifest_path = "s3://my-bucket/tables/users/_versions/11.manifest"
            entry2.manifest_size = 2048
            result = client.batch_create_table_versions(req)
            print(f"   Batch versions created: {result}")
        except Exception as e:
            print(f"   Batch create versions: {e}")
        print()

        print("28. Batch committing table operations...")
        try:
            req = BatchCommitTablesPRequest()
            # Operation 1: Declare a new table
            op1 = req.operations.add()
            declare_req = DeclareTablePRequest()
            declare_req.id.extend(["my_catalog", "example_ns", "batch_table"])
            declare_req.location = "s3://my-bucket/tables/batch_table"
            op1.declare_table.CopyFrom(declare_req)
            # Operation 2: Create a version for it
            op2 = req.operations.add()
            ver_req = CreateTableVersionPRequest()
            ver_req.id.extend(["my_catalog", "example_ns", "batch_table"])
            ver_req.version = 1
            ver_req.manifest_path = "s3://my-bucket/tables/batch_table/_versions/1.manifest"
            ver_req.manifest_size = 1024
            op2.create_table_version.CopyFrom(ver_req)
            result = client.batch_commit_tables(req)
            print(f"   Batch commit: {result}")
        except Exception as e:
            print(f"   Batch commit: {e}")
        print()

        # --- Cleanup ---
        print("29. Dropping table...")
        try:
            req = DropTablePRequest()
            req.id.extend(["my_catalog", "example_ns", "users"])
            req.mode = "DROP_IF_EXISTS"
            result = client.drop_table(req)
            print(f"   Table dropped: {result}")
        except Exception as e:
            print(f"   Drop table: {e}")
        print()

        print("30. Dropping namespace...")
        try:
            req = DropNamespacePRequest()
            req.id.extend(["my_catalog", "example_ns"])
            req.mode = "DROP_IF_EXISTS"
            req.behavior = "CASCADE"
            result = client.drop_namespace(req)
            print(f"   Namespace dropped: {result}")
        except Exception as e:
            print(f"   Drop namespace: {e}")
        print()

    print("=" * 70)
    print("Complete example finished!")
    print("=" * 70)


if __name__ == "__main__":
    main()
