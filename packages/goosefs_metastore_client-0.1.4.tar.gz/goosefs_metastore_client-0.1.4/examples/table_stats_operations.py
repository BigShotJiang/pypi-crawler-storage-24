"""Example: Table statistics and query plan operations.

This example demonstrates analytics capabilities:
- get_table_stats: Get table statistics (with fragment stats)
- explain_table_query_plan: Explain query plan
- analyze_table_query_plan: Analyze query plan
"""
from goosefs_metastore_client import GoosefsMetastoreClient
from grpc_files.table_master_pb2 import (
    GetTableStatsPRequest,
    ExplainTableQueryPlanPRequest,
    AnalyzeTableQueryPlanPRequest,
)

GOOSEFS_HOST = "localhost"
GOOSEFS_PORT = 9220


def example_get_table_stats():
    """Get statistics for a table."""
    print("=" * 60)
    print("Example: Get Table Stats")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        request = GetTableStatsPRequest()
        request.id.extend(["my_catalog", "my_database", "my_table"])
        
        try:
            result = client.get_table_stats(request)
            if "stats" in result:
                stats = result["stats"]
                print(f"Table statistics:")
                if "total_bytes" in stats:
                    print(f"  Total Bytes: {stats['total_bytes']}")
                if "num_rows" in stats:
                    print(f"  Number of Rows: {stats['num_rows']}")
                if "num_indices" in stats:
                    print(f"  Number of Indices: {stats['num_indices']}")
                if "fragment_stats" in stats:
                    fs = stats["fragment_stats"]
                    print(f"  Fragment Stats:")
                    if "num_fragments" in fs:
                        print(f"    Number of Fragments: {fs['num_fragments']}")
                    if "num_small_fragments" in fs:
                        print(f"    Small Fragments: {fs['num_small_fragments']}")
                    if "lengths" in fs:
                        lengths = fs["lengths"]
                        print(f"    Fragment Lengths:")
                        for metric in ["min", "max", "mean", "p25", "p50", "p75", "p99"]:
                            if metric in lengths:
                                print(f"      {metric}: {lengths[metric]}")
            else:
                print(f"No statistics available")
        except Exception as e:
            print(f"Failed to get stats: {e}")


def example_explain_query_plan():
    """Explain the query execution plan."""
    print("=" * 60)
    print("Example: Explain Table Query Plan")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        request = ExplainTableQueryPlanPRequest()
        request.id.extend(["my_catalog", "my_database", "my_table"])
        request.query = "SELECT * FROM table WHERE age > 20 AND status = 'active'"
        
        print(f"  Query: {request.query}")
        print()
        
        try:
            plan = client.explain_table_query_plan(request)
            print(f"  Execution plan:")
            print(f"  {plan}")
        except Exception as e:
            print(f"  Failed to explain plan: {e}")


def example_analyze_query_plan():
    """Analyze the query execution plan with performance metrics."""
    print("=" * 60)
    print("Example: Analyze Table Query Plan")
    print("=" * 60)
    
    with GoosefsMetastoreClient(GOOSEFS_HOST, GOOSEFS_PORT) as client:
        request = AnalyzeTableQueryPlanPRequest()
        request.id.extend(["my_catalog", "my_database", "my_table"])
        request.query = "SELECT user_id, COUNT(*) FROM table GROUP BY user_id"
        
        print(f"  Query: {request.query}")
        print()
        
        try:
            analysis = client.analyze_table_query_plan(request)
            print(f"  Query analysis:")
            print(f"  {analysis}")
        except Exception as e:
            print(f"  Failed to analyze plan: {e}")


def main():
    """Run all statistics and query plan examples."""
    print()
    print("#" * 60)
    print("# Table Statistics & Query Plan Examples")
    print("#" * 60)
    print()
    
    example_get_table_stats()
    print()
    example_explain_query_plan()
    print()
    example_analyze_query_plan()
    print()


if __name__ == "__main__":
    main()
