"""Examples for GooseFS Metastore Client.

Lance/GooseFS Compatible Operation Examples:
- namespace_operations: Namespace CRUD operations
- table_crud_operations: Table create/read/update/delete (Lance predicate vs GooseFS where_clause)
- table_index_operations: Table index management (with Lance pagination)
- table_schema_operations: Schema updates (Lance metadata vs GooseFS schema)
- table_version_operations: Table versioning, restore, create/describe/batch-delete/batch-create versions
- table_tag_operations: Table tagging
- table_stats_operations: Table statistics and query plan
- table_registration_operations: Table declaration and registration
- transaction_operations: Transaction management (Lance id vs GooseFS transaction_id), batch commit
- complete_example: Comprehensive example with all new gRPC-based operations
"""
