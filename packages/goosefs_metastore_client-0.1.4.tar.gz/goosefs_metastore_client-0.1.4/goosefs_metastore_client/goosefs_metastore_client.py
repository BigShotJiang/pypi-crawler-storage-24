"""GooseFS Metastore Client main class."""
from typing import List, Dict, Optional, Any
import logging
import uuid

import grpc
from grpc_files.table_master_pb2 import (
    ListNamespacesPRequest,
    CreateNamespacePRequest,
    DescribeNamespacePRequest,
    NamespaceExistsPRequest,
    DropNamespacePRequest,
    ListTablesPRequest,
    TableExistsPRequest,
    DescribeTablePRequest,
    DeclareTablePRequest,
    DeregisterTablePRequest,
    RegisterNamespaceImplPRequest,
    UnregisterNamespaceImplPRequest,
    IsRegisteredPRequest,
    RegisterTablePRequest,
    DropTablePRequest,
    CountTableRowsPRequest,
    CreateTablePRequest,
    CreateEmptyTablePRequest,
    InsertIntoTablePRequest,
    MergeInsertIntoTablePRequest,
    UpdateTablePRequest,
    DeleteFromTablePRequest,
    QueryTablePRequest,
    CreateTableIndexPRequest,
    CreateTableScalarIndexPRequest,
    ListTableIndicesPRequest,
    DescribeTableIndexStatsPRequest,
    DropTableIndexPRequest,
    ListAllTablesPRequest,
    RestoreTablePRequest,
    RenameTablePRequest,
    ListTableVersionsPRequest,
    CreateTableVersionPRequest,
    DescribeTableVersionPRequest,
    BatchDeleteTableVersionsPRequest,
    BatchCreateTableVersionsPRequest,
    BatchCommitTablesPRequest,
    CreateTableVersionEntry,
    CommitTableOperation,
    UpdateTableSchemaMetadataPRequest,
    GetTableStatsPRequest,
    ExplainTableQueryPlanPRequest,
    AnalyzeTableQueryPlanPRequest,
    AlterTableAddColumnsPRequest,
    AlterTableAlterColumnsPRequest,
    AlterTableDropColumnsPRequest,
    ListTableTagsPRequest,
    GetTableTagVersionPRequest,
    CreateTableTagPRequest,
    DeleteTableTagPRequest,
    UpdateTableTagPRequest,
    DescribeTransactionPRequest,
    AlterTransactionPRequest,
)
from grpc_files.table_master_pb2_grpc import TableMasterClientServiceStub
from goosefs_metastore_client.authentication import ChannelAuthenticator, ChannelIdInjector


logger = logging.getLogger(__name__)


class GoosefsMetastoreClient:
    """User main interface with the GooseFS Table Master service via gRPC."""

    def __init__(
        self,
        host: str,
        port: int = 9220,
        max_retries: int = 3,
        timeout: int = 30,
        credentials: Optional[grpc.ChannelCredentials] = None,
        authentication_enabled: bool = True,
        username: Optional[str] = None,
        impersonation_user: Optional[str] = None,
    ) -> None:
        """
        Instantiate the client for the given host and port.

        :param host: GooseFS master host
        :param port: GooseFS table master service port (default: 9220)
        :param max_retries: maximum number of retries for failed requests
        :param timeout: timeout in seconds for gRPC calls
        :param credentials: optional gRPC credentials for secure connection
        :param authentication_enabled: whether to enable SASL authentication (default: True)
        :param username: username for authentication (defaults to OS user)
        :param impersonation_user: optional user to impersonate
        """
        self.host = host
        self.port = port
        self.max_retries = max_retries
        self.timeout = timeout
        self.credentials = credentials
        self.authentication_enabled = authentication_enabled
        self.username = username
        self.impersonation_user = impersonation_user
        self.channel: Optional[grpc.Channel] = None
        self.stub: Optional[TableMasterClientServiceStub] = None
        self.channel_id: Optional[uuid.UUID] = None

    def connect(self) -> "GoosefsMetastoreClient":
        """
        Open the gRPC connection to the GooseFS Table Master.

        :return: GoosefsMetastoreClient instance
        """
        address = f"{self.host}:{self.port}"
        
        if self.credentials:
            base_channel = grpc.secure_channel(address, self.credentials)
        else:
            base_channel = grpc.insecure_channel(address)
        
        if self.authentication_enabled:
            self.channel_id = uuid.uuid4()
            logger.info(f"Authenticating with channel ID: {self.channel_id}")
            
            # Authenticate on the base channel (without Channel ID header)
            authenticator = ChannelAuthenticator(
                base_channel,
                self.channel_id,
                username=self.username,
                impersonation_user=self.impersonation_user,
            )
            
            try:
                authenticator.authenticate()
            except Exception as e:
                base_channel.close()
                raise RuntimeError(f"Authentication failed: {e}") from e
            
            # After successful authentication, add Channel ID interceptor
            channel_id_injector = ChannelIdInjector(self.channel_id)
            self.channel = grpc.intercept_channel(base_channel, channel_id_injector)
        else:
            self.channel = base_channel
        
        self.stub = TableMasterClientServiceStub(self.channel)
        logger.info(f"Connected to GooseFS Table Master at {address}")
        
        return self

    def close(self) -> None:
        """Close the gRPC connection."""
        if self.channel:
            self.channel.close()
            logger.info("Closed connection to GooseFS Table Master")

    def __enter__(self) -> "GoosefsMetastoreClient":
        """Handle connection opening when using 'with' block statement."""
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Handle connection closing after the code inside 'with' block ends."""
        self.close()

    def _call_with_retry(self, func, *args, **kwargs):
        """
        Call a gRPC method with retry logic.

        :param func: the gRPC method to call
        :param args: positional arguments for the method
        :param kwargs: keyword arguments for the method
        :return: the result of the gRPC call
        """
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                return func(*args, timeout=self.timeout, **kwargs)
            except grpc.RpcError as e:
                last_exception = e
                logger.warning(
                    f"gRPC call failed (attempt {attempt + 1}/{self.max_retries}): {e}"
                )
                
                if attempt < self.max_retries - 1:
                    if e.code() in (
                        grpc.StatusCode.UNAVAILABLE,
                        grpc.StatusCode.DEADLINE_EXCEEDED,
                    ):
                        continue
                    else:
                        raise
        
        raise last_exception

    # The following method refers to the lance namespace interface.

    def list_namespaces(self, request: ListNamespacesPRequest) -> Dict[str, Any]:
        """
        List namespaces.

        :param request: ListNamespacesPRequest with id, page_token, and limit
        :return: dict with 'namespaces' list and optional 'page_token'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ListNamespaces, request)
        result = {"namespaces": list(response.namespaces)}
        if response.HasField("page_token"):
            result["page_token"] = response.page_token
        return result

    def create_namespace(self, request: CreateNamespacePRequest) -> Dict[str, Any]:
        """
        Create a namespace.

        :param request: CreateNamespacePRequest with id, properties, and mode
        :return: dict with 'properties' and optional 'transaction_id'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateNamespace, request)
        result = {"properties": dict(response.properties)}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def describe_namespace(self, request: DescribeNamespacePRequest) -> Dict[str, str]:
        """
        Describe a namespace.

        :param request: DescribeNamespacePRequest with id
        :return: namespace properties
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DescribeNamespace, request)
        return dict(response.properties)

    def namespace_exists(self, request: NamespaceExistsPRequest) -> bool:
        """
        Check if a namespace exists.

        :param request: NamespaceExistsPRequest with id
        :return: True if namespace exists
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.NamespaceExists, request)
        return response.exists

    def drop_namespace(self, request: DropNamespacePRequest) -> Dict[str, Any]:
        """
        Drop a namespace.

        :param request: DropNamespacePRequest with id, mode, and behavior
        :return: dict with 'properties' and 'transaction_id' list
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DropNamespace, request)
        result = {"properties": dict(response.properties)}
        if response.transaction_id:
            result["transaction_id"] = list(response.transaction_id)
        return result

    def list_tables(self, request: ListTablesPRequest) -> Dict[str, Any]:
        """
        List tables in a namespace.

        :param request: ListTablesPRequest with id, page_token, and limit
        :return: dict with 'tables' list and optional 'page_token'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ListTables, request)
        result = {"tables": list(response.tables)}
        if response.HasField("page_token"):
            result["page_token"] = response.page_token
        return result

    def table_exists(self, request: TableExistsPRequest) -> bool:
        """
        Check if a table exists.

        :param request: TableExistsPRequest with id and optional version
        :return: True if table exists
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.TableExists, request)
        return response.exists

    def describe_table(self, request: DescribeTablePRequest) -> Dict[str, Any]:
        """
        Describe a table.

        :param request: DescribeTablePRequest with id, version, load_detailed_metadata,
                        with_table_uri, and vend_credentials
        :return: table description with location, storage_options, table, namespace,
                 version, table_uri, schema, stats, and metadata
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DescribeTable, request)
        result = {}
        if response.HasField("location"):
            result["location"] = response.location
        result["storage_options"] = dict(response.storage_options)
        if response.HasField("table"):
            result["table"] = response.table
        if response.namespace:
            result["namespace"] = list(response.namespace)
        if response.HasField("version"):
            result["version"] = response.version
        if response.HasField("table_uri"):
            result["table_uri"] = response.table_uri
        if response.HasField("schema"):
            result["schema"] = response.schema
        if response.HasField("stats"):
            result["stats"] = response.stats
        result["metadata"] = dict(response.metadata)
        return result

    def declare_table(self, request: DeclareTablePRequest) -> Dict[str, Any]:
        """
        Declare a table.

        :param request: DeclareTablePRequest with id, location, and properties
        :return: declaration response with location, storage_options, and transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DeclareTable, request)
        result = {}
        if response.HasField("location"):
            result["location"] = response.location
        result["storage_options"] = dict(response.storage_options)
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def deregister_table(self, request: DeregisterTablePRequest) -> Dict[str, Any]:
        """
        Deregister a table.

        :param request: DeregisterTablePRequest with id
        :return: deregistration response with id, location, properties, and transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DeregisterTable, request)
        result = {"id": list(response.id)}
        if response.HasField("location"):
            result["location"] = response.location
        result["properties"] = dict(response.properties)
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def register_namespace_impl(self, name: str, class_name: str) -> None:
        """
        Register a namespace implementation.

        :param name: namespace name
        :param class_name: implementation class name
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        request = RegisterNamespaceImplPRequest()
        request.name = name
        request.class_name = class_name
        
        self._call_with_retry(self.stub.RegisterNamespaceImpl, request)

    def unregister_namespace_impl(self, name: str) -> bool:
        """
        Unregister a namespace implementation.

        :param name: namespace name
        :return: True if successful
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        request = UnregisterNamespaceImplPRequest()
        request.name = name
        
        response = self._call_with_retry(self.stub.UnregisterNamespaceImpl, request)
        return response.success

    def is_registered(self, name: str) -> bool:
        """
        Check if a namespace implementation is registered.

        :param name: namespace name
        :return: True if registered
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        request = IsRegisteredPRequest()
        request.name = name
        
        response = self._call_with_retry(self.stub.IsRegistered, request)
        return response.registered

    def register_table(self, request: RegisterTablePRequest) -> Dict[str, Any]:
        """
        Register a table.

        :param request: RegisterTablePRequest with id, location, properties, and mode
        :return: registration response with location, transaction_id, and properties
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.RegisterTable, request)
        result = {}
        if response.HasField("location"):
            result["location"] = response.location
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        result["properties"] = dict(response.properties)
        return result

    def drop_table(self, request: DropTablePRequest) -> Dict[str, Any]:
        """
        Drop a table.

        :param request: DropTablePRequest with id and mode
        :return: drop response with transaction_id, id, location, and properties
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DropTable, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.id:
            result["id"] = list(response.id)
        if response.HasField("location"):
            result["location"] = response.location
        result["properties"] = dict(response.properties)
        return result

    def count_table_rows(self, request: CountTableRowsPRequest) -> int:
        """
        Count rows in a table.

        :param request: CountTableRowsPRequest with id, predicate, and version
        :return: row count
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CountTableRows, request)
        return response.count

    def create_table(self, request: CreateTablePRequest, request_data: Optional[Any] = None) -> Dict[str, Any]:
        """
        Create a table.

        :param request: CreateTablePRequest with id, schema, location, mode, and properties
        :param request_data: Optional additional data for table creation
        :return: creation response with location, storage_options, transaction_id, and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateTable, request)
        result = {}
        if response.HasField("location"):
            result["location"] = response.location
        result["storage_options"] = dict(response.storage_options)
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def create_empty_table(self, request: CreateEmptyTablePRequest) -> Dict[str, Any]:
        """
        Create an empty table.

        :param request: CreateEmptyTablePRequest with id, schema, location, mode, and properties
        :return: creation response with location, storage_options, and transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateEmptyTable, request)
        result = {}
        if response.HasField("location"):
            result["location"] = response.location
        result["storage_options"] = dict(response.storage_options)
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def insert_into_table(self, request: InsertIntoTablePRequest, request_data: Optional[Any] = None) -> Dict[str, Any]:
        """
        Insert data into a table.

        :param request: InsertIntoTablePRequest with id, data, and mode
        :param request_data: Optional additional data for insertion
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.InsertIntoTable, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def merge_insert_into_table(self, request: MergeInsertIntoTablePRequest, request_data: Optional[Any] = None) -> Dict[str, Any]:
        """
        Merge insert data into a table.

        :param request: MergeInsertIntoTablePRequest with id, data, on_columns,
                        when_matched_update_all, when_not_matched_insert_all,
                        and when_not_matched_by_source_delete
        :param request_data: Optional additional data for merge
        :return: dict with transaction_id, num_inserted_rows, num_updated_rows,
                 num_deleted_rows, and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.MergeInsertIntoTable, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("num_inserted_rows"):
            result["num_inserted_rows"] = response.num_inserted_rows
        if response.HasField("num_updated_rows"):
            result["num_updated_rows"] = response.num_updated_rows
        if response.HasField("num_deleted_rows"):
            result["num_deleted_rows"] = response.num_deleted_rows
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def update_table(self, request: UpdateTablePRequest) -> Dict[str, Any]:
        """
        Update table records.

        :param request: UpdateTablePRequest with id, updates, where_clause, and predicate
        :return: dict with updated_rows, transaction_id, and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.UpdateTable, request)
        result = {}
        if response.HasField("updated_rows"):
            result["updated_rows"] = response.updated_rows
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def delete_from_table(self, request: DeleteFromTablePRequest) -> Dict[str, Any]:
        """
        Delete records from a table.

        :param request: DeleteFromTablePRequest with id, where_clause, and predicate
        :return: dict with transaction_id and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DeleteFromTable, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def query_table(self, request: QueryTablePRequest) -> str:
        """
        Query a table.

        :param request: QueryTablePRequest with id, query, limit, filter, k,
                        query_vector, and columns
        :return: query result (serialized)
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.QueryTable, request)
        return response.result

    def create_table_index(self, request: CreateTableIndexPRequest) -> Dict[str, Any]:
        """
        Create a table index.

        :param request: CreateTableIndexPRequest with id, columns, index_type,
                        index_name, metric_type, num_partitions, num_sub_vectors, and replace
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateTableIndex, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def create_table_scalar_index(self, request: CreateTableScalarIndexPRequest) -> Dict[str, Any]:
        """
        Create a table scalar index.

        :param request: CreateTableScalarIndexPRequest with id, columns, and index_type
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateTableScalarIndex, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def list_table_indices(self, request: ListTableIndicesPRequest) -> Dict[str, Any]:
        """
        List table indices.

        :param request: ListTableIndicesPRequest with id, page_token, limit, and version
        :return: dict with 'indices' list of IndexContent and optional 'page_token'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ListTableIndices, request)
        indices = []
        for idx in response.indexes:
            index_info = {}
            if idx.HasField("index_name"):
                index_info["index_name"] = idx.index_name
            if idx.HasField("index_uuid"):
                index_info["index_uuid"] = idx.index_uuid
            if idx.columns:
                index_info["columns"] = list(idx.columns)
            if idx.HasField("status"):
                index_info["status"] = idx.status
            indices.append(index_info)
        result = {"indices": indices}
        if response.HasField("page_token"):
            result["page_token"] = response.page_token
        return result

    def describe_table_index_stats(self, request: DescribeTableIndexStatsPRequest) -> Dict[str, Any]:
        """
        Describe table index statistics.

        :param request: DescribeTableIndexStatsPRequest with id, index_name, and version
        :return: dict with distance_type, index_type, num_indexed_rows,
                 num_unindexed_rows, and num_indices
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DescribeTableIndexStats, request)
        result = {}
        if response.HasField("distance_type"):
            result["distance_type"] = response.distance_type
        if response.HasField("index_type"):
            result["index_type"] = response.index_type
        if response.HasField("num_indexed_rows"):
            result["num_indexed_rows"] = response.num_indexed_rows
        if response.HasField("num_unindexed_rows"):
            result["num_unindexed_rows"] = response.num_unindexed_rows
        if response.HasField("num_indices"):
            result["num_indices"] = response.num_indices
        return result

    def drop_table_index(self, request: DropTableIndexPRequest) -> Dict[str, Any]:
        """
        Drop a table index.

        :param request: DropTableIndexPRequest with id and index_name
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DropTableIndex, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def list_all_tables(self, request: ListAllTablesPRequest) -> Dict[str, Any]:
        """
        List all tables.

        :param request: ListAllTablesPRequest with page_token and limit
        :return: dict with 'tables' list and optional 'page_token'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ListAllTables, request)
        result = {"tables": list(response.tables)}
        if response.HasField("page_token"):
            result["page_token"] = response.page_token
        return result

    def restore_table(self, request: RestoreTablePRequest) -> Dict[str, Any]:
        """
        Restore a table to a specific version.

        :param request: RestoreTablePRequest with id and version
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.RestoreTable, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def rename_table(self, request: RenameTablePRequest) -> Dict[str, Any]:
        """
        Rename a table.

        :param request: RenameTablePRequest with old_id/new_id (GooseFS style) or
                        id/new_namespace_id/new_table_name (Lance style)
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.RenameTable, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def list_table_versions(self, request: ListTableVersionsPRequest) -> Dict[str, Any]:
        """
        List table versions.

        :param request: ListTableVersionsPRequest with id, page_token, and limit
        :return: dict with 'versions' list of TableVersion details and optional 'page_token'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ListTableVersions, request)
        versions = []
        for v in response.versions:
            version_info = {}
            if v.HasField("version"):
                version_info["version"] = v.version
            if v.HasField("timestamp"):
                version_info["timestamp"] = v.timestamp
            if v.metadata:
                version_info["metadata"] = dict(v.metadata)
            versions.append(version_info)
        result = {"versions": versions}
        if response.HasField("page_token"):
            result["page_token"] = response.page_token
        return result

    def create_table_version(self, request: CreateTableVersionPRequest) -> Dict[str, Any]:
        """
        Create a table version.

        :param request: CreateTableVersionPRequest with id, version, manifest_path,
                        manifest_size, e_tag, metadata, and naming_scheme
        :return: dict with transaction_id and version (TableVersion details)
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateTableVersion, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            version_info = {}
            if response.version.HasField("version"):
                version_info["version"] = response.version.version
            if response.version.HasField("timestamp"):
                version_info["timestamp"] = response.version.timestamp
            if response.version.metadata:
                version_info["metadata"] = dict(response.version.metadata)
            result["version"] = version_info
        return result

    def describe_table_version(self, request: DescribeTableVersionPRequest) -> Dict[str, Any]:
        """
        Describe a table version.

        :param request: DescribeTableVersionPRequest with id and version
        :return: dict with version (TableVersion details)
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DescribeTableVersion, request)
        result = {}
        if response.HasField("version"):
            version_info = {}
            if response.version.HasField("version"):
                version_info["version"] = response.version.version
            if response.version.HasField("timestamp"):
                version_info["timestamp"] = response.version.timestamp
            if response.version.metadata:
                version_info["metadata"] = dict(response.version.metadata)
            result["version"] = version_info
        return result

    def batch_delete_table_versions(self, request: BatchDeleteTableVersionsPRequest) -> Dict[str, Any]:
        """
        Batch delete table versions.

        :param request: BatchDeleteTableVersionsPRequest with id and ranges (VersionRange list)
        :return: dict with deleted_count and transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.BatchDeleteTableVersions, request)
        result = {}
        if response.HasField("deleted_count"):
            result["deleted_count"] = response.deleted_count
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def batch_create_table_versions(self, request: BatchCreateTableVersionsPRequest) -> Dict[str, Any]:
        """
        Batch create table versions atomically.

        :param request: BatchCreateTableVersionsPRequest with entries (CreateTableVersionEntry list)
        :return: dict with transaction_id and versions list
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.BatchCreateTableVersions, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        versions = []
        for v in response.versions:
            version_info = {}
            if v.HasField("version"):
                version_info["version"] = v.version
            if v.HasField("timestamp"):
                version_info["timestamp"] = v.timestamp
            if v.metadata:
                version_info["metadata"] = dict(v.metadata)
            versions.append(version_info)
        result["versions"] = versions
        return result

    def batch_commit_tables(self, request: BatchCommitTablesPRequest) -> Dict[str, Any]:
        """
        Batch commit table operations atomically.

        Supports mixed operations: DeclareTable, CreateTableVersion,
        DeleteTableVersions, DeregisterTable.

        :param request: BatchCommitTablesPRequest with operations (CommitTableOperation list)
        :return: dict with transaction_id and results list
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.BatchCommitTables, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        results = []
        for r in response.results:
            commit_result = {}
            if r.HasField("declare_table"):
                dt = r.declare_table
                dt_info = {}
                if dt.HasField("transaction_id"):
                    dt_info["transaction_id"] = dt.transaction_id
                if dt.HasField("location"):
                    dt_info["location"] = dt.location
                dt_info["storage_options"] = dict(dt.storage_options)
                dt_info["properties"] = dict(dt.properties)
                if dt.HasField("managed_versioning"):
                    dt_info["managed_versioning"] = dt.managed_versioning
                commit_result["declare_table"] = dt_info
            if r.HasField("create_table_version"):
                ctv = r.create_table_version
                ctv_info = {}
                if ctv.HasField("transaction_id"):
                    ctv_info["transaction_id"] = ctv.transaction_id
                if ctv.HasField("version"):
                    version_info = {}
                    if ctv.version.HasField("version"):
                        version_info["version"] = ctv.version.version
                    if ctv.version.HasField("timestamp"):
                        version_info["timestamp"] = ctv.version.timestamp
                    if ctv.version.metadata:
                        version_info["metadata"] = dict(ctv.version.metadata)
                    ctv_info["version"] = version_info
                commit_result["create_table_version"] = ctv_info
            if r.HasField("delete_table_versions"):
                dtv = r.delete_table_versions
                dtv_info = {}
                if dtv.HasField("deleted_count"):
                    dtv_info["deleted_count"] = dtv.deleted_count
                if dtv.HasField("transaction_id"):
                    dtv_info["transaction_id"] = dtv.transaction_id
                commit_result["delete_table_versions"] = dtv_info
            if r.HasField("deregister_table"):
                drt = r.deregister_table
                drt_info = {"id": list(drt.id)}
                if drt.HasField("location"):
                    drt_info["location"] = drt.location
                drt_info["properties"] = dict(drt.properties)
                if drt.HasField("transaction_id"):
                    drt_info["transaction_id"] = drt.transaction_id
                commit_result["deregister_table"] = drt_info
            results.append(commit_result)
        result["results"] = results
        return result

    def update_table_schema_metadata(self, request: UpdateTableSchemaMetadataPRequest) -> Dict[str, Any]:
        """
        Update table schema metadata.

        :param request: UpdateTableSchemaMetadataPRequest with id, schema, and metadata
        :return: dict with metadata and transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.UpdateTableSchemaMetadata, request)
        result = {"metadata": dict(response.metadata)}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def get_table_stats(self, request: GetTableStatsPRequest) -> Dict[str, Any]:
        """
        Get table statistics.

        :param request: GetTableStatsPRequest with id
        :return: dict with stats (TableBasicStats)
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.GetTableStats, request)
        result = {}
        if response.HasField("total_bytes"):
            result["total_bytes"] = response.total_bytes
        if response.HasField("num_rows"):
            result["num_rows"] = response.num_rows
        if response.HasField("num_indices"):
            result["num_indices"] = response.num_indices
        if response.HasField("fragment_stats"):
            fs = response.fragment_stats
            fs_dict = {}
            if fs.HasField("num_fragments"):
                fs_dict["num_fragments"] = fs.num_fragments
            if fs.HasField("num_small_fragments"):
                fs_dict["num_small_fragments"] = fs.num_small_fragments
            if fs.HasField("lengths"):
                lengths = fs.lengths
                lengths_dict = {}
                for field in ["min", "max", "mean", "p25", "p50", "p75", "p99"]:
                    if lengths.HasField(field):
                        lengths_dict[field] = getattr(lengths, field)
                fs_dict["lengths"] = lengths_dict
            result["fragment_stats"] = fs_dict
        return result

    def explain_table_query_plan(self, request: ExplainTableQueryPlanPRequest) -> str:
        """
        Explain table query plan.

        :param request: ExplainTableQueryPlanPRequest with id, query, and verbose
        :return: query plan explanation
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ExplainTableQueryPlan, request)
        return response.plan

    def analyze_table_query_plan(self, request: AnalyzeTableQueryPlanPRequest) -> str:
        """
        Analyze table query plan.

        :param request: AnalyzeTableQueryPlanPRequest with id and query
        :return: query plan analysis
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.AnalyzeTableQueryPlan, request)
        return response.analysis

    def alter_table_add_columns(self, request: AlterTableAddColumnsPRequest) -> Dict[str, Any]:
        """
        Add columns to a table.

        :param request: AlterTableAddColumnsPRequest with id and columns (NewColumnTransform)
        :return: dict with transaction_id and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.AlterTableAddColumns, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def alter_table_alter_columns(self, request: AlterTableAlterColumnsPRequest) -> Dict[str, Any]:
        """
        Alter columns in a table.

        :param request: AlterTableAlterColumnsPRequest with id and columns (AlterColumnsEntry)
        :return: dict with transaction_id and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.AlterTableAlterColumns, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def alter_table_drop_columns(self, request: AlterTableDropColumnsPRequest) -> Dict[str, Any]:
        """
        Drop columns from a table.

        :param request: AlterTableDropColumnsPRequest with id and columns
        :return: dict with transaction_id and version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.AlterTableDropColumns, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        if response.HasField("version"):
            result["version"] = response.version
        return result

    def list_table_tags(self, request: ListTableTagsPRequest) -> Dict[str, Any]:
        """
        List table tags.

        :param request: ListTableTagsPRequest with id, page_token, and limit
        :return: dict with 'tags' (map of tag name to TagContents) and optional 'page_token'
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.ListTableTags, request)
        tags = {}
        for tag_name, tag_contents in response.tags.items():
            tag_info = {}
            if tag_contents.HasField("branch"):
                tag_info["branch"] = tag_contents.branch
            if tag_contents.HasField("version"):
                tag_info["version"] = tag_contents.version
            if tag_contents.HasField("manifest_size"):
                tag_info["manifest_size"] = tag_contents.manifest_size
            tags[tag_name] = tag_info
        result = {"tags": tags}
        if response.HasField("page_token"):
            result["page_token"] = response.page_token
        return result

    def get_table_tag_version(self, request: GetTableTagVersionPRequest) -> int:
        """
        Get table tag version.

        :param request: GetTableTagVersionPRequest with id and tag
        :return: tag version
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.GetTableTagVersion, request)
        return response.version

    def create_table_tag(self, request: CreateTableTagPRequest) -> Dict[str, Any]:
        """
        Create a table tag.

        :param request: CreateTableTagPRequest with id, tag, and version
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.CreateTableTag, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def delete_table_tag(self, request: DeleteTableTagPRequest) -> Dict[str, Any]:
        """
        Delete a table tag.

        :param request: DeleteTableTagPRequest with id and tag
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DeleteTableTag, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def update_table_tag(self, request: UpdateTableTagPRequest) -> Dict[str, Any]:
        """
        Update a table tag.

        :param request: UpdateTableTagPRequest with id, tag, and version
        :return: dict with transaction_id
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.UpdateTableTag, request)
        result = {}
        if response.HasField("transaction_id"):
            result["transaction_id"] = response.transaction_id
        return result

    def describe_transaction(self, request: DescribeTransactionPRequest) -> Dict[str, Any]:
        """
        Describe a transaction.

        :param request: DescribeTransactionPRequest with transaction_id and/or id
        :return: dict with properties and status
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.DescribeTransaction, request)
        result = {"properties": dict(response.properties)}
        if response.HasField("status"):
            result["status"] = response.status
        return result

    def alter_transaction(self, request: AlterTransactionPRequest) -> Dict[str, Any]:
        """
        Alter a transaction.

        :param request: AlterTransactionPRequest with transaction_id, action,
                        id, and actions (AlterTransactionAction list)
        :return: dict with status and properties
        """
        if not self.stub:
            raise RuntimeError("Client not connected. Call connect() first or use context manager.")
        
        response = self._call_with_retry(self.stub.AlterTransaction, request)
        result = {}
        if response.HasField("status"):
            result["status"] = response.status
        result["properties"] = dict(response.properties)
        return result
