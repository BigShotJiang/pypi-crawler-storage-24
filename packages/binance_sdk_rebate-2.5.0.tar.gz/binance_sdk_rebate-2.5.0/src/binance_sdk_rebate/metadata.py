NAME = "binance-sdk-rebate"
