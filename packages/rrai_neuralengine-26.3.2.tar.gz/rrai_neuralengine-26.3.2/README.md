# Rovox Neural Engine

## Installation
1. Method 1: Download source code from this repository, and install in editable mode
    ```
    pip install -e .
    ```

2. Method 2: Build and install wheel
    ```
    # install build tool
    python -m pip install build

    # build wheel in-place
    python -m build --wheel

    # install built wheel generated under folder `dist`
    pip install dist/neuralengine-<version>-py3-none-any.whl
    ```


## Test
1. Test D-FINE-ViT object detection

    Update engine paths in neuralengine/objectdetection/models.jsonl desired to run, then execute following command:
    ```
    python3 test/test_dfine_vit.py
    ```
2. Test Cerberus multi-tasking network

    Update engine paths in neuralengine/multitask/models.jsonl desired to run, then execute following command:
    ```
    python3 test/test_cerberus.py
    ```


## API Usage
Simply import detector API to initiate model instance, currently support `cudart` and `pycuda` backend, or set `auto` to use one of existed library in the system.
1. D-FINE-ViT
    ```
    from neuralengine.objectdetection import DFINEViTDetectorEngine
    trt_engine_path='path/to/your/model.engine'
    model = DFINEViTDetectorEngine(trt_engine_path, verbose=False, backend='cudart')
    ```

2. Cerberus
    ```
    from neuralengine.multitask import CerberusMultitaskEngine
    trt_engine_path='path/to/your/model.engine'
    model = CerberusMultitaskEngine(trt_engine_path, verbose=False, backend='cudart')
    ```



