import os
import sys
import cv2
import json
# import argparse

py_version = sys.version_info
if py_version >= (3, 9):
    import importlib.resources as resources
else:
    import importlib_resources as resources
import tempfile
import shutil

from glob import glob
from time import time
from PIL import Image

import neuralengine as ne
from neuralengine import readModelListJSONL
from neuralengine import multitask # Import the package containing the file
from neuralengine.multitask import Cerberus
from neuralengine.utils import (drawCanvas,
                                drawCanvasCUDART,
                                class_colors,
                                register_draw_canvas,
                                class_name_table_brand_cls2,
                                class_name_table_mscoco_cls80,
                                class_name_table_recycling_cls27,
                                class_name_table_recycling_cls36,
                                )


def test_cerberus(engine, test_image, model_config, output_path, draw_func):
    # Example test function to validate CerberusMultitaskEngine functionality
    print("Running Cerberus Multitask Engine Test...")
    # Here you would add code to load test data, run inference, and validate outputs
    # For demonstration, we will just print a message
    print("Cerberus Multitask Engine Test Completed Successfully.")

    # TODO: inference test code goes here
    print(f'Load image from {test_image}')
    frame = cv2.imread(test_image)
    print('Input frame shape:', frame.shape)

    rgb_img = frame[:, :, ::-1]
    frame_pil = Image.fromarray(rgb_img)

    score_threshold_box1 = 0.9
    score_threshold_box2 = 0.8
    score_threshold_segm = 0.5
    model_heads = model_config.get('outputs', None)
    output_shape = (1280, 720)  # width, height

    t0 = time()
    try:
        print('Running inference...')
        output = engine(frame, format='RGB', output_shape=output_shape, profile_backend=False,
                        main_score_threshold=score_threshold_box1,
                        brand_score_threshold=score_threshold_box2,
                        segm_score_threshold=score_threshold_segm)
        print('Inference completed.')
    except RuntimeError as e:
        print(f"Error during inference: {e}")
        return

    print(f'Inference time: {((time() - t0)*1000):.4f} milliseconds(ms) for inference')

    # pycuda backend
    # result_image = draw_func(frame_pil, output, thrh_0=score_threshold_box1, thrh_1=score_threshold_box2, thrh_segm=score_threshold_segm, model_heads=model_heads)

    # cudart backend
    result_image = draw_func(frame_pil, output, model_heads=model_heads)

    result_image.save(output_path)
    print(f"Saved result image to {output_path}")


if __name__ == "__main__":
    # parser = argparse.ArgumentParser(
    #     description="Test Cerberus Multitask TensorRT Engine"
    # )
    # parser.add_argument(
    #     "--trt_engine_path",
    #     type=str,
    #     required=True,
    #     help="Path to the TensorRT engine file.",
    # )
    # parser.add_argument(
    #     "--verbose",
    #     action="store_true",
    #     help="Enable verbose output during engine operations.",
    # )
    # args = parser.parse_args()

    test_dir = "resources/test_images"
    img_list = glob(f"{test_dir}/*.jpg") + glob(f"{test_dir}/*.png")

    # test_image = 'resources/test_images/20220704_162116_009.jpg'

    output_dir = "outputs"

    if os.path.exists(output_dir) is False:
        os.makedirs(output_dir)

    # Context manager to get the path
    # with importlib.resources.path(multitask, "models.jsonl") as p:
    #     jsonl_path = str(p)

    res = resources.files(multitask).joinpath("models.jsonl")
    with res.open("rb") as src, tempfile.NamedTemporaryFile(delete=False, suffix=".jsonl") as tmp:
        shutil.copyfileobj(src, tmp)
        jsonl_path = tmp.name

    json_list = readModelListJSONL(jsonl_path)

    if json_list:
        for test_i, json_dict in enumerate(json_list):
            trt_engine_path = json_dict['ckpt_path']
            model_name = json_dict['model_name']

            if len(trt_engine_path) > 0:
                print(f"Model: {json_dict['model_name']}, Path: {json_dict['ckpt_path']}")

                # Initialize the Cerberus Multitask Engine
                # engine = CerberusMultitaskEngine(
                #     trt_engine_path=trt_engine_path,
                #     verbose=False
                # )

                engine = Cerberus(model_name).load_model()

                num_classes = json_dict.get('num_classes', None)

                if num_classes is None:
                    print("Number of classes not specified in model config, use COCO 80 classes as default.")
                    num_classes = 80
                else:
                    print(f"Number of classes: {num_classes}")

                print("Cerberus Multitask TensorRT Engine initialized successfully.")

                if num_classes == 27:
                    class_name_table_recycling = class_name_table_recycling_cls27
                    class_color_table_recycling = class_colors(class_name_table_recycling_cls27)
                elif num_classes == 36:
                    class_name_table_recycling = class_name_table_recycling_cls36
                    class_color_table_recycling = class_colors(class_name_table_recycling_cls36)
                else:
                    # raise ValueError(f"Unsupported number of classes: {num_classes}")
                    class_name_table_recycling = class_name_table_mscoco_cls80
                    class_color_table_recycling = class_colors(class_name_table_mscoco_cls80)

                # class_color_table_recycling = class_colors(class_name_table_recycling_cls36)
                class_color_table_brand = dict(Cola=(50, 255, 100), Unknown=(246, 0, 255))

                draw_dunc = register_draw_canvas(
                    class_name_table=class_name_table_recycling,
                    class_color_table=class_color_table_recycling,
                    class_name_table_1=class_name_table_brand_cls2,
                    class_color_table_1=class_color_table_brand,
                    model_heads=10
                # )(drawCanvas)
                )(drawCanvasCUDART)

                for test_image in img_list:
                    image_filename = os.path.basename(test_image)
                    output_path = os.path.join(output_dir, f"test_{test_i}_{model_name}_result_of_{image_filename}.jpg")
                    test_cerberus(engine, test_image, json_dict, output_path, draw_dunc)

                del engine

