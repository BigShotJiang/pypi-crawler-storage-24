import os
import sys
import cv2
import json
# import argparse

py_version = sys.version_info
if py_version >= (3, 9):
    import importlib.resources as resources
else:
    import importlib_resources as resources
import tempfile
import shutil

from glob import glob
from time import time
from PIL import Image

import neuralengine as ne
from neuralengine import readModelListJSONL, objectdetection
from neuralengine.objectdetection import DFINEViT
from neuralengine.utils import (drawCanvas,
                                drawCanvasCUDART,
                                class_colors,
                                register_draw_canvas,
                                class_name_table_mscoco_cls80,
                                class_name_table_recycling_cls27,
                                class_name_table_recycling_cls36,
                                )


def test_dfine_vit(engine, test_image, model_config, output_path, draw_func):
    # Example test function to validate DFINEViTDetectorEngine functionality
    print("Running DFINE-ViT Detector Engine Test...")
    # Here you would add code to load test data, run inference, and validate outputs
    # For demonstration, we will just print a message
    print("DFINE-ViT Detector Engine Test Completed Successfully.")

    # TODO: inference test code goes here
    frame = cv2.imread(test_image)
    print('Input frame shape:', frame.shape)

    rgb_img = frame[:, :, ::-1]
    frame_pil = Image.fromarray(rgb_img)

    score_threshold_box1 = 0.9
    model_heads = model_config.get('outputs', 3)
    output_shape = (1280, 720)  # width, height

    t0 = time()
    try:
        print('Running inference...')
        output = engine(frame, format='RGB', output_shape=output_shape, profile_backend=False)
        print('Inference completed.')
    except RuntimeError as e:
        print(f"Error during inference: {e}")
        return

    print(f'Inference time: {((time() - t0)*1000):.4f} milliseconds(ms) for inference')

    # pycuda backend
    # result_image = draw_func(frame_pil,
    #                          output,
    #                          thrh_0=score_threshold_box1,
    #                          model_heads=model_heads,
    #                          enable_brand_prediction=False,
    #                          enable_contour_segmentation=False,
    #                          )

    # cudart backend
    result_image = draw_func(frame_pil,
                             output,
                             model_heads=model_heads,
                             enable_brand_prediction=False,
                             enable_contour_segmentation=False,
                             )

    result_image.save(output_path)
    print(f"Saved result image to {output_path}")


if __name__ == "__main__":
    # parser = argparse.ArgumentParser(
    #     description="Test Cerberus Multitask TensorRT Engine"
    # )
    # parser.add_argument(
    #     "--trt_engine_path",
    #     type=str,
    #     required=True,
    #     help="Path to the TensorRT engine file.",
    # )
    # parser.add_argument(
    #     "--verbose",
    #     action="store_true",
    #     help="Enable verbose output during engine operations.",
    # )
    # args = parser.parse_args()

    test_dir = "resources/test_images"
    img_list = glob(f"{test_dir}/*.jpg") + glob(f"{test_dir}/*.png")

    # test_image = 'resources/test_images/20220704_162116_009.jpg'

    output_dir = "outputs"

    if os.path.exists(output_dir) is False:
        os.makedirs(output_dir)

    # Context manager to get the path
    # with importlib.resources.path(objectdetection, "models.jsonl") as p:
    #     jsonl_path = str(p)

    res = resources.files(objectdetection).joinpath("models.jsonl")
    with res.open("rb") as src, tempfile.NamedTemporaryFile(delete=False, suffix=".jsonl") as tmp:
        shutil.copyfileobj(src, tmp)
        jsonl_path = tmp.name

    json_list = readModelListJSONL(jsonl_path)

    if json_list:
        for test_i, json_dict in enumerate(json_list):
            trt_engine_path = json_dict['ckpt_path']
            model_name = json_dict['model_name']

            if len(trt_engine_path) > 0:
                print(f"Model: {json_dict['model_name']}, Path: {json_dict['ckpt_path']}")

                # Initialize the Cerberus Multitask Engine
                # engine = DFINEViTDetectorEngine(
                #     trt_engine_path=trt_engine_path,
                #     verbose=False
                # )
                engine = DFINEViT(model_name).load_model()

                num_classes = json_dict.get('num_classes', None)

                if num_classes is None:
                    print("Number of classes not specified in model config, use COCO 80 classes as default.")
                    num_classes = 80
                else:
                    print(f"Number of classes: {num_classes}")

                print("D-FINE-ViT TensorRT Engine initialized successfully.")

                if num_classes == 27:
                    class_name_table_recycling = class_name_table_recycling_cls27
                    class_color_table_recycling = class_colors(class_name_table_recycling_cls27)
                elif num_classes == 36:
                    class_name_table_recycling = class_name_table_recycling_cls36
                    class_color_table_recycling = class_colors(class_name_table_recycling_cls36)
                else:
                    # raise ValueError(f"Unsupported number of classes: {num_classes}")
                    class_name_table_recycling = class_name_table_mscoco_cls80
                    class_color_table_recycling = class_colors(class_name_table_mscoco_cls80)

                draw_dunc = register_draw_canvas(
                    class_name_table=class_name_table_recycling,
                    class_color_table=class_color_table_recycling,
                    class_name_table_1=[],
                    class_color_table_1=dict(),
                    model_heads=3
                # )(drawCanvas)
                )(drawCanvasCUDART)

                for test_image in img_list:
                    image_filename = os.path.basename(test_image)
                    output_path = os.path.join(output_dir, f"test_{test_i}_{model_name}_result_of_{image_filename}.jpg")
                    test_dfine_vit(engine, test_image, json_dict, output_path, draw_dunc)

                del engine

