from .draw import *
from .labels import *

from functools import wraps


def register_draw_canvas(class_name_table, class_color_table,
                        class_name_table_1, class_color_table_1,
                        model_heads):
    """
    Decorator to inject specific model tables into the function's global scope.
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 1. Store the global dict to modify it
            g = func.__globals__

            # 2. Save existing values (if any) to restore later
            saved_values = {}
            vars_to_inject = {
                'class_name_table': class_name_table,
                'class_color_table': class_color_table,
                'class_name_table_1': class_name_table_1,
                'class_color_table_1': class_color_table_1,
                'model_heads': model_heads
            }

            for key, val in vars_to_inject.items():
                if key in g:
                    saved_values[key] = g[key]
                g[key] = val

            # 3. Execute the function with the injected globals
            try:
                result = func(*args, **kwargs)
            finally:
                # 4. Cleanup: Restore original globals to avoid side effects
                for key in vars_to_inject:
                    if key in saved_values:
                        g[key] = saved_values[key]
                    else:
                        del g[key] # Delete if it wasn't there before

            return result
        return wrapper
    return decorator


