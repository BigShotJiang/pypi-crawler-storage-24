import cv2
import numpy as np
import hashlib
from PIL import Image, ImageDraw, ImageFont

class_name_table = []
class_name_table_1 = []
class_color_table = dict()
class_color_table_1 = dict()


def string_to_three_digit_numbers(input_string):
    """
    Convert a text string to a set of three 3-digit numbers.

    Args:
        input_string (str): The text string to encode.

    Returns:
        tuple: Three 3-digit numbers derived from the hash of the input string.
    """
    # Compute the SHA-256 hash of the input string
    hash_object = hashlib.sha256(input_string.encode())
    # Get the hexadecimal digest of the hash
    hex_digest = hash_object.hexdigest()
    # Convert the first 6 characters of the hex digest to an integer
    hash_int = int(hex_digest[:6], 16)
    # Extract three 3-digit numbers
    num1 = (hash_int // 128) % 256
    num2 = (hash_int // 6400) % 256
    num3 = hash_int % 256
    bgr_color = np.uint8([[[num1, num2, num3]]])
    hsv_color = cv2.cvtColor(bgr_color, cv2.COLOR_BGR2HSV)
    hsv_color = np.uint8([[[hsv_color[0][0][0], 255, 255]]])  # Full saturation and value
    bgr_color = cv2.cvtColor(hsv_color, cv2.COLOR_HSV2BGR)[0][0]
    return tuple(bgr_color)


def class_colors(names):
    """
    Generate a list of distinct BGR colors.

    Args:
        n (int): Number of distinct colors to generate.

    Returns:
        list: List of BGR color tuples.
    """
    colors = {}
    step = 1
    n = len(names)*step
    for i, name in enumerate(names):
        colors[name]=string_to_three_digit_numbers(name)
    return colors


def drawCanvas(image, output, thrh_0=0.4, thrh_1=0.4, thrh_segm=0.6, model_heads=9, enable_main_prediction=True, enable_brand_prediction=True, enable_contour_segmentation=True):
    # print(output.keys())

    # print(labels.shape, boxes.shape, scores.shape)
    # head 0
    """
    Draw the detected bounding boxes, labels and scores on the given images.

    Args:
        images (list[PIL.Image]): The input images.
        output (dict): The output from the model, containing the following keys:
            * labels (torch.Tensor): The labels for each detected object.
            * boxes (torch.Tensor): The bounding boxes for each detected object.
            * scores (torch.Tensor): The confidence scores for each detected object.
        thrh_0 (float, optional): The threshold for the first head. Defaults to 0.4.
        thrh_1 (float, optional): The threshold for the second head. Defaults to 0.4.
        thrh_segm (float, optional): The threshold for the contour segmentation head. Defaults to 0.6.

    Returns:
        list[PIL.Image]: The images with the bounding boxes, labels and scores drawn on them.
    """
    # assert len(output) == 9, "length of output should be 9"
    assert len(output) == model_heads, f"length of output should be {model_heads}"

    # assert len(output) == 10, "length of output should be 10"

    # labels, boxes, scores = output['labels'], output['boxes'], output['scores']

    # # head 1
    # if 'labels_1' in output:
    #     labels_1, boxes_1, scores_1 = output['labels_1'], output['boxes_1'], output['scores_1']

    # # contour segmentation
    # if 'labels_segm' in output:
    #     labels_segm, points_segm, scores_segm = output['labels_segm'], output['points_segm'], output['scores_segm']

    # MultitaskV2
    if model_heads == 9:
        labels, boxes, scores, \
            labels_1, boxes_1, scores_1, \
                labels_segm, points_segm, scores_segm = output
    # MultitaskV3
    elif model_heads == 10:
        labels, boxes, scores, \
            labels_1, boxes_1, scores_1, \
                labels_segm, boxes_segm, points_segm, scores_segm = output
    # Single object detection model
    elif model_heads == 3:
        labels, boxes, scores = output
        enable_brand_prediction = False
        enable_contour_segmentation = False


    boxes = boxes.reshape(300, 4)
    if enable_brand_prediction:
        boxes_1 = boxes_1.reshape(300, 4)
    if enable_contour_segmentation:
        points_segm = points_segm.reshape(300, 32, 2)

    if model_heads == 10:
        boxes_segm = boxes_segm.reshape(300, 4)

    # labels = labels.reshape(1, 300)
    # boxes = boxes.reshape(1, 300, 4)
    # scores = scores.reshape(1, 300)

    # labels_1 = labels_1.reshape(1, 300)
    # boxes_1 = boxes_1.reshape(1, 300, 4)
    # scores_1 = scores_1.reshape(1, 300)

    # labels_segm = labels_segm.reshape(1, 300)
    # points_segm = points_segm.reshape(1, 300, 32, 2)
    # scores_segm = scores_segm.reshape(1, 300)


    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12)  # 18 24
    text_offset = (6, 5)

    draw = ImageDraw.Draw(image)

    if enable_main_prediction:
        lab = labels[scores > thrh_0]
        box = boxes[scores > thrh_0]
        scrs = scores[scores > thrh_0]
        # print(f'Number of recycle detected objects: {len(lab)}')

    if enable_brand_prediction:
        lab_1 = labels_1[scores_1 > thrh_1]
        box_1 = boxes_1[scores_1 > thrh_1]
        scrs_1 = scores_1[scores_1 > thrh_1]
        # print(f'Number of brand detected objects: {len(lab_1)}')

    if enable_contour_segmentation:
        mask = scores_segm > thrh_segm
        lab_2 = labels_segm[mask]
        coord = points_segm[mask]
        scrs_2 = scores_segm[mask]
        if model_heads == 10:
            box_2 = boxes_segm[mask]
        # print(f'Number of segmentation detected objects: {len(lab_2)}')

    if enable_main_prediction:
        for j, b in enumerate(box):
            draw.rectangle(list(b), outline=class_color_table[class_name_table[lab[j].item()]], width=7)
            draw.text(
                (b[0]+text_offset[0], b[1]+text_offset[1]),
                # text=f"{lab[j].item()} {round(scrs[j].item(), 2)}",
                text=f"Type: {class_name_table[lab[j].item()]} [{round(scrs[j].item()*100, 2)}]",
                fill=class_color_table[class_name_table[lab[j].item()]],
                font=font,
            )

    if enable_brand_prediction:
        for j, b in enumerate(box_1):
            color = class_color_table_1[class_name_table_1[lab_1[j].item()]]
            draw.rectangle(list(b), outline=color, width=5)
            draw.text(
                (b[0]+text_offset[0], b[1]+text_offset[1]+16),
                text=f"Brand: {class_name_table_1[lab_1[j].item()]} [{round(scrs_1[j].item()*100, 2)}]",
                fill=color,
                font=font,
            )
            # if class_name_table_1[lab_1[j].item()] == 'Cola':
            #     print(class_name_table_1[lab_1[j].item()], round(scrs_1[j].item()*100, 2))

    # head 2 - polygons
    if enable_contour_segmentation:
        for j, (c, l, s) in enumerate(zip(coord, lab_2, scrs_2)):
            # print(f'contour {j}:', s)
            # color = class_color_table_1[class_name_table_1[lab_2[j].item()]]
            color = (50, 150, 255)

            # PIL's polygon function expects a list of (x, y) tuples.
            # Ensure the tensor is on CPU and converted to a list of tuples.
            draw_points = c.tolist()

            # Convert the list of lists to a list of tuples for PIL
            draw_points = [tuple(p) for p in draw_points]

            # Use the PIL ImageDraw.Draw.polygon function to draw a filled polygon
            draw.polygon(draw_points, outline=color, width=3)

            if model_heads == 10:
                draw.rectangle(list(box_2[j]), outline=color, width=3)

    return image


def drawCanvasCUDART(image, output, model_heads=9, enable_main_prediction=True, enable_brand_prediction=True, enable_contour_segmentation=True):
    # print(output.keys())

    # print(labels.shape, boxes.shape, scores.shape)
    # head 0
    """
    Draw the detected bounding boxes, labels and scores on the given images.

    Args:
        images (list[PIL.Image]): The input images.
        output (dict): The output from the model, containing the following keys:
            * labels (torch.Tensor): The labels for each detected object.
            * boxes (torch.Tensor): The bounding boxes for each detected object.
            * scores (torch.Tensor): The confidence scores for each detected object.
        thrh_0 (float, optional): The threshold for the first head. Defaults to 0.4.
        thrh_1 (float, optional): The threshold for the second head. Defaults to 0.4.
        thrh_segm (float, optional): The threshold for the contour segmentation head. Defaults to 0.6.

    Returns:
        list[PIL.Image]: The images with the bounding boxes, labels and scores drawn on them.
    """
    # assert len(output) == 9, "length of output should be 9"
    assert len(output) == model_heads, f"length of output should be {model_heads}"

    # assert len(output) == 10, "length of output should be 10"

    # labels, boxes, scores = output['labels'], output['boxes'], output['scores']

    # # head 1
    # if 'labels_1' in output:
    #     labels_1, boxes_1, scores_1 = output['labels_1'], output['boxes_1'], output['scores_1']

    # # contour segmentation
    # if 'labels_segm' in output:
    #     labels_segm, points_segm, scores_segm = output['labels_segm'], output['points_segm'], output['scores_segm']

    # MultitaskV2
    if model_heads == 9:
        labels, boxes, scores, \
            labels_1, boxes_1, scores_1, \
                labels_segm, points_segm, scores_segm = output
    # MultitaskV3
    elif model_heads == 10:
        labels, boxes, scores, \
            labels_1, boxes_1, scores_1, \
                labels_segm, boxes_segm, points_segm, scores_segm = output
    # Single object detection model
    elif model_heads == 3:
        labels, boxes, scores = output
        enable_brand_prediction = False
        enable_contour_segmentation = False

    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12)  # 18 24
    text_offset = (6, 5)

    draw = ImageDraw.Draw(image)

    if enable_main_prediction:
        for j, b in enumerate(boxes):
            draw.rectangle(list(b), outline=class_color_table[class_name_table[labels[j].item()]], width=7)
            draw.text(
                (b[0]+text_offset[0], b[1]+text_offset[1]),
                # text=f"{lab[j].item()} {round(scrs[j].item(), 2)}",
                text=f"Type: {class_name_table[labels[j].item()]} [{round(scores[j].item()*100, 2)}]",
                fill=class_color_table[class_name_table[labels[j].item()]],
                font=font,
            )

    if enable_brand_prediction:
        for j, b in enumerate(boxes_1):
            color = class_color_table_1[class_name_table_1[labels_1[j].item()]]
            draw.rectangle(list(b), outline=color, width=5)
            draw.text(
                (b[0]+text_offset[0], b[1]+text_offset[1]+16),
                text=f"Brand: {class_name_table_1[labels_1[j].item()]} [{round(scores_1[j].item()*100, 2)}]",
                fill=color,
                font=font,
            )

    # head 2 - polygons
    if enable_contour_segmentation:
        for j, (c, l, s) in enumerate(zip(points_segm, labels_segm, scores_segm)):
            # print(f'contour {j}:', s)
            # color = class_color_table_1[class_name_table_1[lab_2[j].item()]]
            color = (50, 150, 255)

            # PIL's polygon function expects a list of (x, y) tuples.
            # Ensure the tensor is on CPU and converted to a list of tuples.
            draw_points = c.tolist()

            # Convert the list of lists to a list of tuples for PIL
            draw_points = [tuple(p) for p in draw_points]

            # Use the PIL ImageDraw.Draw.polygon function to draw a filled polygon
            draw.polygon(draw_points, outline=color, width=3)

            if model_heads == 10:
                draw.rectangle(list(boxes_segm[j]), outline=color, width=3)

    return image

