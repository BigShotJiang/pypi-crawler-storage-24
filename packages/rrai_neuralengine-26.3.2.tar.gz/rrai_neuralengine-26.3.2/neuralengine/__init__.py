from __future__ import annotations
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from pathlib import Path
import sys

from .core.fileIO import *

# from .core.fileIO import readModelListJSONL
# from .core.trt_engine import TensorRTBaseInferenceEngine

# __all__ = [
#     "readModelListJSONL",
#     "TensorRTBaseInferenceEngine",
# ]

_PACKAGE_NAME = "neuralengine"  # must match [project].name in pyproject.toml

__version__ = "0.0.0"

try:
    # If the package is installed (pip install / pip install -e .)
    __version__ = _pkg_version(_PACKAGE_NAME)
except PackageNotFoundError:
    # Fallback: read from pyproject.toml when running from source
    try:
        if sys.version_info >= (3, 11):
            import tomllib  # stdlib
        else:
            import tomli as tomllib  # pip install tomli for <3.11

        root = Path(__file__).resolve().parent.parent  # adjust if layout differs
        pyproject = root / "pyproject.toml"
        if pyproject.is_file():
            data = tomllib.load(pyproject.open("rb"))
            # For PEP 621 layout:
            __version__ = data["project"]["version"]
            # or for Poetry:
            # __version__ = data["tool"]["poetry"]["version"]
    except Exception:
        # keep default "0.0.0" if anything goes wrong
        pass
