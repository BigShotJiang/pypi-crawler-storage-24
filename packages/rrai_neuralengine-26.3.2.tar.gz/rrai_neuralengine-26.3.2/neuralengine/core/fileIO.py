import json

def readModelListJSONL(file_path):
    with open(file_path, "r") as f:
        lines = f.readlines()

        # remove lines starting with //
        for line in lines:
            if line.strip().startswith("//"):
                lines.remove(line)

        json_list = [json.loads(line) for line in lines]

    return json_list


