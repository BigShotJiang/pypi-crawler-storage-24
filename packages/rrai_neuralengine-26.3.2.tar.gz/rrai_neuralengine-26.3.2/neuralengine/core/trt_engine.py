'''
Docstring for NeuralEngine.neuralengine.core.engine
'''

import numpy as np
import cv2  # Added for video processing
import os
from glob import glob
from time import time
from abc import ABC, abstractmethod

_HAS_PYCUDA = False
_HAS_CUDART = False

try:
    from neuralengine.core.cuda_backends.pycuda_backend import InferenceEnginePyCUDABackend
    _HAS_PYCUDA = True
except ImportError as e:
    print(f"PYCUDA Backend Import Error: {e}")
    InferenceEnginePyCUDABackend = None
    pass

try:
    # import ctypes
    from neuralengine.core.cuda_backends.cudart_backend import InferenceEngineCUDARTBackend
    _HAS_CUDART = True
except ImportError as e:
    print(f"CUDART Backend Import Error: {e}")
    InferenceEngineCUDARTBackend = None
    pass


# TensorRT Inferencer
class TensorRTBaseInferenceEngine(ABC):

    def __init__(self, trt_engine_path, verbose=False, backend='cudart', model_arch='ROVOX-DETR'):
        assert isinstance(backend, str), "Backend must be a string"
        assert model_arch.lower() in ['rovox-detr', 'cerberus'], "model_arch must be one of 'ROVOX-DETR', 'Cerberus'"

        self.trt_engine_path = trt_engine_path
        self.verbose = verbose
        self.model_arch = model_arch

        self.backend_type = backend.lower()
        self.backend = self.select_backend(self.backend_type)

    @abstractmethod
    def preprocess(self, image, input_size, swap=(2, 0, 1), format='RGB'):
        raise NotImplementedError("Please implement preprocess method in subclass")

    @abstractmethod
    def decode_outputs(self, outputs):
        raise NotImplementedError("Please implement decode_outputs method in subclass")

    def select_backend(self, backend: str):
        assert backend in ['auto', 'pycuda', 'cudart'], "Backend must be one of 'auto', 'pycuda', or 'cudart'"
        assert _HAS_PYCUDA or _HAS_CUDART, "No CUDA backend is available. Please install PyCUDA or cuda-python."

        if backend == 'auto':
            backend = 'cudart' if _HAS_CUDART else 'pycuda'

        if backend == 'pycuda':
            if not _HAS_PYCUDA:
                raise ImportError("PyCUDA backend selected, but PyCUDA is not installed.")
            backend_impl = InferenceEnginePyCUDABackend(self.trt_engine_path, self.verbose)
        elif backend == 'cudart':
            if not _HAS_CUDART:
                raise ImportError("CUDART backend selected, but cuda-python is not installed.")
            backend_impl = InferenceEngineCUDARTBackend(self.trt_engine_path, self.verbose, self.model_arch)
        else:
            raise ValueError(f"Unsupported backend: {backend}. Supported backends are 'pycuda' and 'cudart'.")
        return backend_impl

    def __call__(self, image, input_shape=(1024, 576), output_shape=None, format="RGB", profile_backend=False, **kwargs):

        if self.backend_type == 'pycuda':
            # print("Using PyCUDA backend")
            resized_img = self.preprocess(image, input_shape, format=format)

            if output_shape is None:
                h, w, _ = image.shape
                orig_size = np.array([w, h], dtype=np.int32)
            else:
                orig_size = np.array(output_shape, dtype=np.int32)

            raw_out = self.backend.infer(resized_img, orig_size, profile_time=profile_backend, **kwargs)

            return raw_out

        elif self.backend_type == 'cudart':
            # print("Using CUDART backend")
            # required main_score_threshold or
            # main_score_threshold, brand_score_threshold, segm_score_threshold

            if output_shape is None:
                h, w, _ = image.shape
                orig_size = np.array([w, h], dtype=np.int32)
            else:
                orig_size = np.array(output_shape, dtype=np.int32)

            filtered_out = self.backend.infer(image, orig_size, profile_time=profile_backend, **kwargs)

            return filtered_out


