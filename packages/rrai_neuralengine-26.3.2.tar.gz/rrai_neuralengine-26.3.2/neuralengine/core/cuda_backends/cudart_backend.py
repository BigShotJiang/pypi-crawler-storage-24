import tensorrt as trt
import numpy as np
import cv2  # Added for video processing
import os
from glob import glob
from time import time
import ctypes
import sys
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
from cuda import cudart # pip install cuda-python
import cuda_kernels
from cuda_kernels import InferenceEngine, CerberusInferenceEngine

# =============================================================================
# HELPER FUNCTIONS FOR CUDA-PYTHON
# =============================================================================
def check_cuda_err(err):
    """Checks the result of a CUDA API call."""
    if isinstance(err, cudart.cudaError_t):
        if err != cudart.cudaError_t.cudaSuccess:
            raise RuntimeError(f"CUDA Error: {err}")
    # cuda-python often returns a tuple (error_code, value)
    elif isinstance(err, tuple) or isinstance(err, list):
         if err[0] != cudart.cudaError_t.cudaSuccess:
            raise RuntimeError(f"CUDA Error: {err[0]}")


class InferenceEngineCUDARTBackend(object):

    """Manages TensorRT objects for model inference."""
    def __init__(self, trt_engine_path, verbose=False, model_arch='ROVOX-DETR'):
        """Initializes TensorRT objects needed for model inference.

        Args:
            trt_engine_path (str): path where TensorRT engine should be stored
            trt_engine_datatype (trt.DataType):
                requested precision of TensorRT engine used for inference
            batch_size (int): batch size for which engine
                should be optimized for
            conf_thres (float): confidence threshold
        """

        self.verbose = verbose

        self.model_arch = model_arch

        self.trt_engine_path = trt_engine_path

        if self.model_arch.lower() == 'rovox-detr':
            self.inference_engine = InferenceEngine(self.trt_engine_path, self.verbose)
        elif self.model_arch.lower() == 'cerberus':
            self.inference_engine = CerberusInferenceEngine(self.trt_engine_path, self.verbose)
        else:
            raise ValueError(f"Unsupported model architecture: {self.model_arch}. Supported architectures are 'ROVOX-DETR' and 'Cerberus'.")


    # TODO:
    def infer(self, input_image, orig_size, profile_time=False, **kwargs):
        """Infers model on given image.

        Args:
            image (str): image to run object detection model on
        """
        w, h = orig_size

        main_score_threshold = kwargs.pop('main_score_threshold', 0.5)

        brand_score_threshold = kwargs.pop('brand_score_threshold', 0.5)

        segm_score_threshold = kwargs.pop('segm_score_threshold', 0.5)


        if profile_time:
            # When infering on single image, we measure inference
            # time to output it to the user
            inference_start_time = time()

        # Fetch output from the model based on the model architecture
        if self.model_arch.lower() == 'rovox-detr':
            # labels, boxes, scores = detection_out
            detection_out = self.inference_engine.infer(input_image.ctypes.data, h, w, 3, main_score_threshold)
        elif self.model_arch.lower() == 'cerberus':
            # labels, boxes, scores, \
            # brand_labels, brand_boxes, brand_scores, \
            # segm_labels, segm_boxes, segm_points, segm_scores = detection_out
            detection_out = self.inference_engine.infer(input_image.ctypes.data, h, w, 3, main_score_threshold, brand_score_threshold, segm_score_threshold)
        if profile_time:
            exec_time = (time() - inference_start_time) * 1000
            # Output inference time
            print("Inference time of CUDA-Python backend: {} ms".format( float("{:.2f}".format(exec_time)) ))

        return detection_out
