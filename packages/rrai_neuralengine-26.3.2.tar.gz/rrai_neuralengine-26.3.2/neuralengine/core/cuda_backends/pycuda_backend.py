'''
Docstring for NeuralEngine.neuralengine.core.engine
'''

import tensorrt as trt
import numpy as np
import cv2  # Added for video processing
import os
from glob import glob
from time import time

# Simple helper data class that's a little nicer to use than a 2-tuple.
import pycuda.driver as cuda
# import pycuda.autoinit
cuda.init()


# PyCUDA Inferencer
class InferenceEnginePyCUDABackend(object):

    class HostDeviceMem(object):
        """
        A utility class for managing paired host and device memory allocations.

        This class encapsulates memory pointers for both CPU (host) and GPU (device)
        memory, commonly used in CUDA/TensorRT operations for data transfers between
        host and device.

        Attributes:
            host: Host (CPU) memory allocation or pointer.
            device: Device (GPU) memory allocation or pointer.

        Methods:
            __str__: Returns a formatted string representation of both host and device memory.
            __repr__: Returns the same representation as __str__ for debugging purposes.

        Example:
            Typically used to maintain synchronized memory allocations for GPU inference:

            >>> host_mem = np.zeros((1, 3, 224, 224), dtype=np.float32)
            >>> device_mem = cuda.mem_alloc(host_mem.nbytes)
            >>> mem = HostDeviceMem(host_mem, device_mem)
        """
        def __init__(self, host_mem, device_mem):
            self.host = host_mem
            self.device = device_mem

        def __str__(self):
            return "Host:\n" + str(self.host) + "\nDevice:\n" + str(self.device)

        def __repr__(self):
            return self.__str__()

    """Manages TensorRT objects for model inference."""
    def __init__(self, trt_engine_path, verbose=False):
        """Initializes TensorRT objects needed for model inference.

        Args:
            trt_engine_path (str): path where TensorRT engine should be stored
            trt_engine_datatype (trt.DataType):
                requested precision of TensorRT engine used for inference
            conf_thres (float): confidence threshold
        """

        self.verbose = verbose

        # self.thread_local = threading.local()  # For per-thread resources if needed

        self.cuda_context = cuda.Device(0).make_context()

        if verbose:
            print("creating logger,", "use logger level", "VERBOSE" if verbose else "INFO")
        self.logger = trt.Logger(trt.Logger.VERBOSE) if verbose else trt.Logger(trt.Logger.INFO)
        self.trt_engine = self.load_engine(trt_engine_path)

        if self.trt_engine is None:
            raise ValueError("Failed to load TensorRT engine from path: {}".format(trt_engine_path))
        else:
            if verbose:
                print("TensorRT engine loaded successfully!")

        if verbose:
            print("allocating buffers")
        # This allocates memory for network inputs/outputs on both CPU and GPU
        self.inputs, self.outputs, self.bindings, self.stream = self.allocate_buffers()

        if verbose:
            print("creating execution context")
        # Execution context is needed for inference
        self.context = self.trt_engine.create_execution_context()

        if verbose:
            print("TensorRT inference engine is ready!")


    def load_engine(self, path):
        trt.init_libnvinfer_plugins(self.logger, '')
        if self.verbose:
            print("loading engine from file {}".format(path))
        with open(path, 'rb') as f, trt.Runtime(self.logger) as runtime:
            return runtime.deserialize_cuda_engine(f.read())

    # def allocate_buffers(self,):
    #     raise NotImplementedError("Please implement allocate_buffers method in subclass")

    def allocate_buffers(self,):
        """Allocates host and device buffer for TRT engine inference.

        This function is similair to the one in common.py, but
        converts network outputs (which are np.float32) appropriately
        before writing them to Python buffer. This is needed, since
        TensorRT plugins doesn't support output type description, and
        in our particular case, we use NMS plugin as network output.

        Args:
            engine (trt.ICudaEngine): TensorRT engine

        Returns:
            inputs [HostDeviceMem]: engine input memory
            outputs [HostDeviceMem]: engine output memory
            bindings [int]: buffer to device bindings
            stream (cuda.Stream): cuda stream for engine inference synchronization
        """
        inputs = []
        outputs = []
        bindings = []
        stream = cuda.Stream()

        for index, binding in enumerate(self.trt_engine):
            size = trt.volume(self.trt_engine.get_tensor_shape(binding))
            t_type = self.trt_engine.get_tensor_dtype(binding)
            dtype = trt.nptype(self.trt_engine.get_tensor_dtype(binding))
            print(f"index: {index}, binding: {str(binding)}, shape: {self.trt_engine.get_tensor_shape(binding)}, type: {t_type}")
            # Allocate host and device buffers
            host_mem = cuda.pagelocked_empty(size, dtype)
            device_mem = cuda.mem_alloc(host_mem.nbytes)
            # Append the device buffer to device bindings.
            bindings.append(int(device_mem))
            if self.trt_engine.get_tensor_mode(binding) == trt.TensorIOMode.INPUT:
                inputs.append(self.HostDeviceMem(host_mem, device_mem))
            else:
                outputs.append(self.HostDeviceMem(host_mem, device_mem))

        return inputs, outputs, bindings, stream

    # def preprocess(self, image, input_size, swap=(2, 0, 1), format='RGB'):
    #     raise NotImplementedError("Please implement preprocess method in subclass")

    # def decode_outputs(self, outputs):
    #     raise NotImplementedError("Please implement decode_outputs method in subclass")

    def do_inference(self, ):

        # start_time = time() if profile else None

        # Transfer input data to the GPU.
        [cuda.memcpy_htod_async(inp.device, inp.host, self.stream) for inp in self.inputs]

        # ======= TensorRT 10 =======
        # Setup tensor address
        bindings = [int(inp.device) for inp in self.inputs] + [int(outp.device) for outp in self.outputs]

        for i in range(self.trt_engine.num_io_tensors):
            self.context.set_tensor_address(self.trt_engine.get_tensor_name(i), bindings[i])
        # ======= TensorRT 10 =======

        # Run inference.
        self.context.execute_async_v3(stream_handle=self.stream.handle)

        # Transfer predictions back from the GPU.
        [cuda.memcpy_dtoh_async(out.host, out.device, self.stream) for out in self.outputs]

        # Synchronize the stream
        self.stream.synchronize()

        # Return only the host outputs.
        outputs = [out.host for out in self.outputs]

        # if profile:
        #     exec_time_ms = (time() - start_time) * 1000
        #     print(f"TensorRT inference time: {exec_time_ms:.2f} ms")

        return outputs


    # def __call__(self, image, input_shape=(1024, 576), output_shape=None, format='RGB', profile_time=False):
    #     """Infers model on given image.

    #     Args:
    #         image (str): image to run object detection model on
    #     """

    #     # Load image into CPU
    #     resized_img = self.preprocess(image, input_shape, format=format)

    #     # h, w, c = image.shape
    #     # orig_size = np.array([w, h], dtype=np.int32)
    #     if output_shape is None:
    #         h, w, c = image.shape
    #         orig_size = np.array([w, h], dtype=np.int32)
    #     else:
    #         assert len(output_shape) == 2
    #         orig_size = np.array(output_shape, dtype=np.int32)

    #     np.copyto(self.inputs[0].host, resized_img.ravel())
    #     np.copyto(self.inputs[1].host, orig_size.ravel())

    #     if profile_time:
    #         # When infering on single image, we measure inference
    #         # time to output it to the user
    #         inference_start_time = time()

    #     # Fetch output from the model
    #     detection_out = self.do_inference()

    #     if profile_time:
    #         exec_time = (time() - inference_start_time) * 1000
    #         # Output inference time
    #         print("TensorRT inference time: {} ms".format( float("{:.2f}".format(exec_time)) ))

    #     return detection_out


    def infer(self, processed_image, orig_size, profile_time=False, **kwargs):
        """Infers model on given image.

        Args:
            image (str): image to run object detection model on
        """
        np.copyto(self.inputs[0].host, processed_image.ravel())
        np.copyto(self.inputs[1].host, orig_size.ravel())

        if profile_time:
            # When infering on single image, we measure inference
            # time to output it to the user
            inference_start_time = time()

        # Fetch output from the model
        detection_out = self.do_inference()

        if profile_time:
            exec_time = (time() - inference_start_time) * 1000
            # Output inference time
            print("Inference time of PyCUDA backend: {} ms".format( float("{:.2f}".format(exec_time)) ))

        return detection_out


    def __del__(self):
        """Destroys TensorRT objects when the class is deallocated."""

        if self.verbose:
            print("Releasing TensorRT resources...")

        # Release CUDA stream
        if hasattr(self, 'stream'):
            del self.stream

        # Destroy the execution context
        if hasattr(self, 'context'):
            del self.context

        # Destroy the engine
        if hasattr(self, 'trt_engine'):
            del self.trt_engine

        # Free memory allocated for inputs and outputs
        if hasattr(self, 'inputs'):
            for inp in self.inputs:
                inp.device.free()  # Use .free() method on device memory

        if hasattr(self, 'outputs'):
            for out in self.outputs:
                out.device.free()  # Use .free() method on device memory

        if hasattr(self, 'logger'):
            del self.logger # Release the logger to prevent memory leaks

        if hasattr(self, 'cuda_context'):
            self.cuda_context.pop() #Deactivate context
            self.cuda_context.detach() # detach the context

        if self.verbose:
            print("Done!")
