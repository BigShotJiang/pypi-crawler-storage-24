import os
import cv2
import numpy as np
import tensorrt as trt
import pycuda.driver as cuda

from neuralengine import readModelListJSONL
from neuralengine.core import TensorRTBaseInferenceEngine

# import importlib.resources
# from neuralengine import multitask # Import the package containing the file

# # Context manager to get the path
# with importlib.resources.path(multitask, "models.jsonl") as p:
#     jsonl_path = str(p)


# API for multi-task Cerberus Detector
class CerberusMultitaskEngine(TensorRTBaseInferenceEngine):
    """
    CerberusMultitaskEngine

    A TensorRT-based inference engine for multi-task object detection (Cerberus model).

    This class extends TensorRTBaseInferenceEngine to handle inference operations for a model
    that outputs labels, bounding boxes, and confidence scores for detected objects.

    Attributes:
        trt_engine: The TensorRT engine instance loaded from the engine file.
        verbose: Flag to enable debug logging during operations.

    Methods:
        allocate_buffers(): Allocates host and device memory buffers for model inputs and outputs.
            Returns:
                tuple: (inputs, outputs, bindings, stream)
                    - inputs: List of HostDeviceMem objects for input tensors
                    - outputs: List of HostDeviceMem objects for output tensors
                    - bindings: List of device memory addresses for TensorRT binding
                    - stream: CUDA stream for asynchronous operations

        preprocess(image, input_size, swap=(2, 0, 1), format='RGB'): Preprocesses input image
            for model inference.

            Args:
                image: Input image as numpy array
                input_size: Tuple of (width, height) for target resize dimensions
                swap: Tuple specifying axis permutation for channel conversion (default: HWC->CHW)
                format: Color format of input image, either 'BGR' or 'RGB' (default: 'RGB')

            Returns:
                np.ndarray: Preprocessed image as float32 array, normalized to [0, 1] range,
                           with channels in order specified by swap parameter.

            Raises:
                AssertionError: If format is not 'BGR' or 'RGB'
    """
    def __init__(self, trt_engine_path, backend='auto', verbose=False):
        super(CerberusMultitaskEngine, self).__init__(trt_engine_path, verbose=verbose, backend=backend, model_arch='Cerberus')

    # def allocate_buffers(self,):
    #     """
    #     Allocate host and device memory buffers for TensorRT engine inputs and outputs.

    #     This method iterates through all tensors in the TensorRT engine, allocates
    #     corresponding host (CPU) and device (GPU) memory, and organizes them into
    #     input and output lists based on tensor IO mode.

    #     Returns:
    #         tuple: A tuple containing:
    #             - inputs (list): List of HostDeviceMem objects for input tensors
    #             - outputs (list): List of HostDeviceMem objects for output tensors
    #             - bindings (list): List of device memory pointers for all tensors
    #             - stream (cuda.Stream): CUDA stream for asynchronous operations

    #     Notes:
    #         - Allocates page-locked host memory for efficient GPU transfers
    #         - Allocates device memory on the GPU for tensor data
    #         - Determines tensor data type from the TensorRT engine
    #         - Prints allocation details if self.verbose is True
    #     """
    #     inputs = []
    #     outputs = []
    #     bindings = []
    #     stream = cuda.Stream()

    #     # input_names=['images', 'orig_target_sizes']
    #     # output_names=['labels', 'boxes', 'scores']
    #     binding_to_type = {
    #                         "images": np.float32,
    #                         "orig_target_sizes": np.int32,
    #                         "labels": np.int64,
    #                         "boxes": np.float32,
    #                         "scores": np.float32,
    #                        }

    #     # for index in range(len(binding_to_type)):
    #     for index, binding in enumerate(self.trt_engine):
    #         # binding = self.trt_engine.get_tensor_name(index)
    #         size = trt.volume(self.trt_engine.get_tensor_shape(binding))
    #         t_type = self.trt_engine.get_tensor_dtype(binding)
    #         # dtype = binding_to_type[str(binding)]
    #         dtype = trt.nptype(self.trt_engine.get_tensor_dtype(binding))
    #         # Allocate host and device buffers
    #         host_mem = cuda.pagelocked_empty(size, dtype)
    #         device_mem = cuda.mem_alloc(host_mem.nbytes)
    #         # Append the device buffer to device bindings.
    #         bindings.append(int(device_mem))

    #         if self.verbose:
    #             print(f"index: {index}, binding: {str(binding)}, shape: {self.trt_engine.get_tensor_shape(binding)}, type: {t_type}")

    #         # Append to the appropriate list.
    #         if self.trt_engine.get_tensor_mode(binding) == trt.TensorIOMode.INPUT:
    #             inputs.append(self.HostDeviceMem(host_mem, device_mem))
    #         else:
    #             outputs.append(self.HostDeviceMem(host_mem, device_mem))
    #     return inputs, outputs, bindings, stream


    def preprocess(self, image, input_size, swap=(2, 0, 1), format='RGB'):
        """
        Preprocess an image for model inference.

        This method resizes the image, converts its color format if needed,
        normalizes pixel values, and transposes the image from HWC (Height, Width, Channel)
        to CHW (Channel, Height, Width) format.

        Args:
            image (np.ndarray): Input image array.
            input_size (tuple): Target size as (width, height).
            swap (tuple, optional): Axes permutation for transpose operation. Defaults to (2, 0, 1).
            format (str, optional): Target color format, either 'BGR' or 'RGB'. Defaults to 'RGB'.

        Returns:
            np.ndarray: Preprocessed image as a contiguous float32 array in CHW format.

        Raises:
            AssertionError: If format is not 'BGR' or 'RGB'.
        """
        assert format in ['BGR', 'RGB'], "Image format not supported !!! (only support BGR and RGB)"

        w, h = input_size

        # preserve aspect ratio
        resized_img = cv2.resize(
            image,
            (int(w), int(h)),
            interpolation=cv2.INTER_LINEAR,
        ).astype(np.float32)

        # default format of cv image is BGR
        if format == 'RGB':
            # resized_img = resized_img[:, :, ::-1]
            resized_img = cv2.cvtColor(resized_img, cv2.COLOR_BGR2RGB)

        # normalize
        resized_img /= 255.0

        # HWC -> CHW
        resized_img = resized_img.transpose(swap)
        resized_img = np.ascontiguousarray(resized_img, dtype=np.float32)

        return resized_img

    def decode_outputs(self, outputs, **kwargs):
        num_outputs = len(outputs)

        # MultitaskV2
        if num_outputs == 9:
            labels, boxes, scores, \
                labels_1, boxes_1, scores_1, \
                    labels_segm, points_segm, scores_segm = outputs
        # MultitaskV3
        elif num_outputs == 10:
            labels, boxes, scores, \
                labels_1, boxes_1, scores_1, \
                    labels_segm, boxes_segm, points_segm, scores_segm = outputs

        detection_dict = dict()
        # main
        detection_dict.update(labels=labels.reshape(1, 300))
        detection_dict.update(boxes=boxes.reshape(1, 300, 4))
        detection_dict.update(scores=scores.reshape(1, 300))
        # brand
        detection_dict.update(labels_1=labels_1.reshape(1, 300))
        detection_dict.update(boxes_1=boxes_1.reshape(1, 300, 4))
        detection_dict.update(scores_1=scores_1.reshape(1, 300))
        # segm
        detection_dict.update(labels_segm=labels_segm.reshape(1, 300))
        detection_dict.update(boxes_segm=boxes_segm.reshape(1, 300, 4))
        detection_dict.update(scores_segm=scores_segm.reshape(1, 300))
        detection_dict.update(points_segm=points_segm.reshape(1, 300, 32, 2))
        # points_segm = points_segm.reshape(300, 32, 2)

        return detection_dict


# Wrapper class for demo and test package
class Cerberus:
    def __init__(self, model_name, backend='cudart', **kwargs):
        self.model_name = model_name
        self.backend = backend
        current_dir = os.path.dirname(os.path.abspath(__file__))

        # Construct the absolute path to the jsonl file in the same directory
        jsonl_path = os.path.join(current_dir, "models.jsonl")
        self.json_list = readModelListJSONL(jsonl_path)

        self.metadata = kwargs

    def load_model(self, model_path=None):
        if self.model_name in [str(j['model_name']) for j in self.json_list]:
            for json_dict in self.json_list:
                if str(json_dict['model_name']) == self.model_name:
                    if model_path is not None:
                        trt_engine_path = model_path
                    else:
                        trt_engine_path = json_dict['ckpt_path']
                    self.engine = CerberusMultitaskEngine(trt_engine_path, verbose=self.metadata.get('verbose', False), backend=self.backend)
                    if self.engine is not None:
                        print(f"Cerberus model '{self.model_name}' loaded successfully from checkpoint: {trt_engine_path}")
                    else:
                        print(f"Failed to load Cerberus model '{self.model_name}' from checkpoint: {trt_engine_path}")
            return self.engine
        else:
            print(f"Model name '{self.model_name}' not found in models.jsonl")
            return None

