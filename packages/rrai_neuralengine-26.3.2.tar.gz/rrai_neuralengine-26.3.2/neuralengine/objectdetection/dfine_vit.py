import os
import cv2
import numpy as np
import tensorrt as trt
import pycuda.driver as cuda

from neuralengine import readModelListJSONL
from neuralengine.core import TensorRTBaseInferenceEngine


# API for D-FINE-ViT Detector
class DFINEViTDetectorEngine(TensorRTBaseInferenceEngine):
    def __init__(self, trt_engine_path, backend='auto', verbose=False):
        super(DFINEViTDetectorEngine, self).__init__(trt_engine_path, verbose=verbose, backend=backend, model_arch='ROVOX-DETR')

    # def allocate_buffers(self,):
    #     """Allocates host and device buffer for TRT engine inference.

    #     This function is similair to the one in common.py, but
    #     converts network outputs (which are np.float32) appropriately
    #     before writing them to Python buffer. This is needed, since
    #     TensorRT plugins doesn't support output type description, and
    #     in our particular case, we use NMS plugin as network output.

    #     Args:
    #         engine (trt.ICudaEngine): TensorRT engine

    #     Returns:
    #         inputs [HostDeviceMem]: engine input memory
    #         outputs [HostDeviceMem]: engine output memory
    #         bindings [int]: buffer to device bindings
    #         stream (cuda.Stream): cuda stream for engine inference synchronization
    #     """
    #     inputs = []
    #     outputs = []
    #     bindings = []
    #     stream = cuda.Stream()

    #     for index, binding in enumerate(self.trt_engine):
    #         size = trt.volume(self.trt_engine.get_tensor_shape(binding))
    #         t_type = self.trt_engine.get_tensor_dtype(binding)
    #         dtype = trt.nptype(self.trt_engine.get_tensor_dtype(binding))
    #         print(f"index: {index}, binding: {str(binding)}, shape: {self.trt_engine.get_tensor_shape(binding)}, type: {t_type}")
    #         # Allocate host and device buffers
    #         host_mem = cuda.pagelocked_empty(size, dtype)
    #         device_mem = cuda.mem_alloc(host_mem.nbytes)
    #         # Append the device buffer to device bindings.
    #         bindings.append(int(device_mem))
    #         if self.trt_engine.get_tensor_mode(binding) == trt.TensorIOMode.INPUT:
    #             inputs.append(self.HostDeviceMem(host_mem, device_mem))
    #         else:
    #             outputs.append(self.HostDeviceMem(host_mem, device_mem))

    #     return inputs, outputs, bindings, stream


    def preprocess(self, image, input_size, swap=(2, 0, 1), format='RGB'):
        """Preprocess image for model inference.

        Resizes the image to the specified input size, converts color format if needed,
        normalizes pixel values, and transposes to channel-first format.

        Args:
            image (np.ndarray): Input image array in BGR format (OpenCV default).
            input_size (tuple): Target size as (width, height) for model inference.
            swap (tuple): Axis indices for transpose operation to convert HWC -> CHW.
                Defaults to (2, 0, 1).
            format (str): Desired output color format, 'BGR' or 'RGB'. Defaults to 'RGB'.

        Returns:
            np.ndarray: Preprocessed image as float32 array in CHW format, normalized to [0, 1].

        Raises:
            AssertionError: If format is not 'BGR' or 'RGB'.
        """
        assert format in ['BGR', 'RGB'], "Image format not supported !!! (only support BGR and RGB)"

        w, h = input_size

        # preserve aspect ratio
        resized_img = cv2.resize(
            image,
            (int(w), int(h)),
            interpolation=cv2.INTER_LINEAR,
        ).astype(np.float32)

        # default format of cv image is BGR
        if format == 'RGB':
            # resized_img = resized_img[:, :, ::-1]
            resized_img = cv2.cvtColor(resized_img, cv2.COLOR_BGR2RGB)

        # normalize
        resized_img /= 255.0

        # HWC -> CHW
        resized_img = resized_img.transpose(swap)
        resized_img = np.ascontiguousarray(resized_img, dtype=np.float32)

        return resized_img


    def decode_outputs(self, outputs):
        """Decode raw model outputs into detection results.

        Reshapes and organizes model outputs into a structured dictionary format
        for object detection results.

        Args:
            outputs (tuple): Tuple containing three arrays:
                - labels (np.ndarray): Detection class labels
                - boxes (np.ndarray): Bounding box coordinates
                - scores (np.ndarray): Detection confidence scores

        Returns:
            dict: Dictionary with keys:
                - 'labels': Class labels reshaped to (1, 300)
                - 'boxes': Bounding boxes reshaped to (1, 300, 4)
                - 'scores': Confidence scores reshaped to (1, 300)
        """
        labels, boxes, scores = outputs
        detection_dict = dict()
        detection_dict.update(labels=labels.reshape(1, 300))
        detection_dict.update(boxes=boxes.reshape(1, 300, 4))
        detection_dict.update(scores=scores.reshape(1, 300))

        return detection_dict


# Wrapper class for demo and test package
class DFINEViT:
    def __init__(self, model_name, **kwargs):
        self.model_name = model_name
        current_dir = os.path.dirname(os.path.abspath(__file__))

        # Construct the absolute path to the jsonl file in the same directory
        jsonl_path = os.path.join(current_dir, "models.jsonl")
        self.json_list = readModelListJSONL(jsonl_path)

        self.metadata = kwargs

    def load_model(self, model_path=None):
        if self.model_name in [str(j['model_name']) for j in self.json_list]:
            for json_dict in self.json_list:
                if str(json_dict['model_name']) == self.model_name:
                    if model_path is not None:
                        trt_engine_path = model_path
                    else:
                        trt_engine_path = json_dict['ckpt_path']
                    self.engine = DFINEViTDetectorEngine(trt_engine_path, verbose=self.metadata.get('verbose', False), backend='cudart')
                    if self.engine is not None:
                        print(f"D-FINE-ViT model '{self.model_name}' loaded successfully from checkpoint: {trt_engine_path}")
                    else:
                        print(f"Failed to load D-FINE-ViT model '{self.model_name}' from checkpoint: {trt_engine_path}")
            return self.engine
        else:
            print(f"Model name '{self.model_name}' not found in models.jsonl")
            return None

