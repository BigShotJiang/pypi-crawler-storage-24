import os, jsonpickle
from http import HTTPMethod

from fmconsult.http.api import ApiBase
from fmconsult.utils.url import UrlUtil

class InfoVistApi(ApiBase):

  def __init__(self):
    try:
      self.api_environment = os.environ['infocar.infovist.api.environment']
      self.api_email = os.environ['infocar.infovist.api.email']
      self.api_password = os.environ['infocar.infovist.api.password']
      self.api_token = os.environ['infocar.infovist.api.token']

      api_sandbox_base_url = 'https://api.infovist.com.br/api/v1'
      api_live_base_url = 'https://api.infovist.com.br/api/v1'

      get_base_url = lambda env: api_live_base_url if env == 'live' else api_sandbox_base_url

      self.base_url = get_base_url(self.api_environment)
      self.headers = {}

      self.__login()
    except:
      raise
  def __login(self):
    try:
      res = self.call_request(
        http_method = HTTPMethod.POST, 
        request_url = UrlUtil().make_url(self.base_url, ['auth','login']), 
        payload = {
          'email': self.api_email, 
          'password': self.api_password,
          'api_token': self.api_token
        }
      )
      res = jsonpickle.decode(res)
      if not('errors' in res):
        self.token_type = res['data']['token_type']
        self.access_token = res['data']['access_token']
        self.headers['Authorization'] = f'{self.token_type} {self.access_token}'
      else:
        raise Exception(res['mensagem'])
    except:
      raise