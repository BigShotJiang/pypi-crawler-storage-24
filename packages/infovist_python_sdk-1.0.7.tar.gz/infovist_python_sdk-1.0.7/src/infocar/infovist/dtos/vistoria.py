from dataclasses import dataclass, asdict
from typing import List, Optional

from fmconsult.utils.enum import CustomEnum
from fmconsult.utils.object import CustomObject

class SearchCategory(CustomEnum):
    PLATE = "Placa"
    CHASSI = "Chassi"
    CUSTOMER = "Cliente"
    PROTOCOL = "Protocolo"

@dataclass
class Status(CustomObject):
    value: str
    status_enum: str
    created_at: str

@dataclass
class Vistoria(CustomObject):
    protocol: Optional[str] = None
    customer: Optional[str] = None
    plate: Optional[str] = None
    chassis: Optional[str] = None
    cellphone: Optional[str] = None
    normal_plate: Optional[str] = None
    mercosur_plate: Optional[str] = None
    status: Optional[str] = None
    status_enum: Optional[str] = None
    notes: Optional[str] = None
    statuses: Optional[List[Status]] = None

    def to_dict(self):
        data = asdict(self)
        return data