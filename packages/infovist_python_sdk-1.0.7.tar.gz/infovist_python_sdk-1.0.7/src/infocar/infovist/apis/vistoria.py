import logging, jsonpickle
from http import HTTPMethod

from fmconsult.utils.url import UrlUtil
from infocar.infovist.api import InfoVistApi
from infocar.infovist.dtos.vistoria import Vistoria, SearchCategory

class VistoriaApi(InfoVistApi):
	def __init__(self):
		super().__init__()
		self.endpoint_url = UrlUtil().make_url(self.base_url, ['inspection'])

	def create(self, data:Vistoria):
		logging.info(f'generating vistoria...')
		try:
			res = self.call_request(HTTPMethod.POST, self.endpoint_url, None, payload=data.to_dict())
			res = jsonpickle.decode(res)
			
			item = Vistoria(**res['data'])

			return item
		except:
			raise

	def get_by_protocol(self, protocol: str):
		logging.info(f'getting vistoria by protocol numer...')
		try:
			endpoint_url = UrlUtil().make_url(self.endpoint_url, [protocol])
			res = self.call_request(
				http_method = HTTPMethod.GET, 
				request_url = endpoint_url
			)
			res = jsonpickle.decode(res)
			
			if 'data' not in res:
				raise Exception(res.get('message', 'Erro desconhecido'))

			item = Vistoria(**res['data'])

			return item
		except:
			raise

	def get_all(self, page: int, limit: int, search: str=None, category: SearchCategory=None):
		logging.info(f'getting vistorias list...')
		try:
			req_params = {
				'page': page,
				'limit': limit
			}

			if (search and category):
				req_params['search'] = search
				req_params['category'] = category.value

			res = self.call_request(
				http_method = HTTPMethod.GET, 
				request_url = self.endpoint_url,
				params = req_params
			)

			res = jsonpickle.decode(res)
			
			if 'data' not in res:
				raise Exception(res.get('message', 'Erro desconhecido'))

			items = [Vistoria(**item) for item in res['data']]

			return items
		except:
			raise