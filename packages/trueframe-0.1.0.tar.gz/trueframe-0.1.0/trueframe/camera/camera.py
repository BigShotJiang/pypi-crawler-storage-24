"""This module contains the Camera class, which handles the camera connection and the cv2.VideoCapture object."""
import cv2
import os
from typing import Optional, Union

from trueframe.logger import logger

class Camera:
    """
    A class to manage the connection to a camera and the cv2.VideoCapture object.
    """
    def __init__(self, url: Union[str, int], use_tcp: bool = True):
        """
        Initializes the Camera object.

        Args:
            url (Union[str, int]): The URL of the RTSP stream or the index of the camera.
            use_tcp (bool): If True, uses TCP for the RTSP stream. Defaults to True.
        """
        self.url = url
        self.use_tcp = use_tcp
        self._cap: Optional[cv2.VideoCapture] = None

    def connect(self) -> None:
        """
        Connects to the camera and initializes the cv2.VideoCapture object.
        """
        if self._cap is not None:
            self._cap.release()

        # Configure FFmpeg to use TCP for RTSP transport if requested
        if self.use_tcp:
            logger.info("Setting RTSP transport to TCP.")
            os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp"
        elif "OPENCV_FFMPEG_CAPTURE_OPTIONS" in os.environ:
            del os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"]

        logger.info(f"Connecting to stream: {self.url}")

        self._cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG)
        self._cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        if not self._cap.isOpened():
            logger.warning(f"Failed to open stream: {self.url}. Will retry.")

    def release(self) -> None:
        """
        Releases the cv2.VideoCapture object.
        """
        if self._cap is not None:
            self._cap.release()
            self._cap = None

    @property
    def is_opened(self) -> bool:
        """
        Checks if the camera is opened.

        Returns:
            bool: True if the camera is opened, False otherwise.
        """
        return self._cap is not None and self._cap.isOpened()

    def grab(self) -> bool:
        """
        Grabs a frame from the camera.

        Returns:
            bool: True if a frame was successfully grabbed, False otherwise.
        """
        return self._cap.grab()

    def retrieve(self) -> tuple[bool, Optional[cv2.typing.MatLike]]:
        """
        Retrieves a frame from the camera.

        Returns:
            tuple[bool, Optional[cv2.typing.MatLike]]: A tuple containing a boolean indicating success and the retrieved frame.
        """
        return self._cap.retrieve()