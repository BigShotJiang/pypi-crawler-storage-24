"""Initializes the Camera for the TrueFrame library."""
from .camera import Camera

__all__ = ["Camera"]