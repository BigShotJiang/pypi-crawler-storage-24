"""This module configures and initializes the logger for the TrueFrame library."""
import logging

logger = logging.getLogger(__name__)