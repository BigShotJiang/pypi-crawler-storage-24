"""Initializes the logger for the TrueFrame library."""
from .logger import logger

__all__ = ["logger"]