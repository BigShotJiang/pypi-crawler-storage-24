"""This module contains the TrueFrame class, which is the main entry point for the library."""
from typing import Optional, Union

import numpy as np

from trueframe.stream import Stream

class TrueFrame:
    """
    A robust, latency-free RTSP stream reader designed to fetch the absolute latest
    frame without buffer smearing or artifacting.

    It uses a dedicated background thread to continuously flush the FFmpeg buffer
    via `.grab()` and only decodes the latest frame via `.retrieve()`.
    """

    def __init__(self, url: Union[str, int], timeout: float = 2.0, use_tcp: bool = True):
        """
        Initializes the stream reader.

        Args:
            url (str | int): The RTSP URL or camera device index.
            timeout (float): Maximum seconds to wait for a frame when calling read().
            use_tcp (bool): If True, uses TCP for the RTSP stream. Defaults to True.
        """
        self.stream = Stream(url, timeout, use_tcp=use_tcp)

    def start(self) -> "TrueFrame":
        """
        Starts the background thread to begin fetching frames.

        Returns:
            self: Allows for method chaining upon instantiation.
        """
        self.stream.start()
        return self

    def read(self) -> Optional[np.ndarray]:
        """
        Retrieves the most recent frame from the stream.

        Returns:
            np.ndarray | None: The OpenCV image frame, or None if the queue is empty/timed out.
        """
        return self.stream.read()

    def stop(self) -> None:
        """
        Safely stops the background thread and releases video resources.
        """
        self.stream.stop()

    def __enter__(self) -> "TrueFrame":
        """
        Starts the stream when entering a context.

        Returns:
            TrueFrame: The TrueFrame object.
        """
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """
        Stops the stream when exiting a context.
        """
        self.stop()