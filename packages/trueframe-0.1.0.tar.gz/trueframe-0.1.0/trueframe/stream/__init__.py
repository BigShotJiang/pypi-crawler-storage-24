"""Initializes the Stream for the TrueFrame library."""
from .stream import Stream

__all__ = ["Stream"]