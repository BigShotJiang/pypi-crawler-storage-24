"""This module contains the Stream class, which acts as a facade for the Camera and FrameGrabber classes."""
from typing import Optional, Union

import numpy as np

from trueframe.camera import Camera
from trueframe.grabber import FrameGrabber
from trueframe.logger import logger

class Stream:
    """
    A class to manage the stream of frames from a camera.
    """
    def __init__(self, url: Union[str, int], timeout: float = 2.0, use_tcp: bool = True):
        """
        Initializes the Stream object.

        Args:
            url (Union[str, int]): The URL of the RTSP stream or the index of the camera.
            timeout (float, optional): The maximum time to wait for a frame. Defaults to 2.0.
            use_tcp (bool): If True, uses TCP for the RTSP stream. Defaults to True.
        """
        self.url = url
        self.timeout = timeout
        self.camera = Camera(url, use_tcp=use_tcp)
        self.grabber = FrameGrabber(self.camera)

    def start(self) -> "Stream":
        """
        Starts the stream.

        Returns:
            Stream: The Stream object.
        """
        self.camera.connect()
        self.grabber.start()
        return self

    def read(self) -> Optional[np.ndarray]:
        """
        Reads a frame from the stream.

        Returns:
            Optional[np.ndarray]: The frame, or None if no frame is available.
        """
        return self.grabber.read(self.timeout)

    def stop(self) -> None:
        """
        Stops the stream.
        """
        self.grabber.stop()
        logger.info("Stream stopped and resources released.")

    def __enter__(self) -> "Stream":
        """
        Starts the stream when entering a context.

        Returns:
            Stream: The Stream object.
        """
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """
        Stops the stream when exiting a context.
        """
        self.stop()