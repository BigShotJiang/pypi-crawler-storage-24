"""Initializes the FrameGrabber for the TrueFrame library."""
from .grabber import FrameGrabber

__all__ = ["FrameGrabber"]