"""This module contains the FrameGrabber class, which is responsible for grabbing frames from the camera in a separate thread."""
import queue
import threading
import time
from typing import Optional

import numpy as np

from trueframe.camera import Camera
from trueframe.logger import logger

class FrameGrabber:
    """
    A class to grab frames from a camera in a separate thread.
    """
    def __init__(self, camera: Camera):
        """
        Initializes the FrameGrabber object.

        Args:
            camera (Camera): The camera to grab frames from.
        """
        self.camera = camera
        self._q: queue.Queue = queue.Queue(maxsize=1)
        self._lock = threading.Lock()
        self._stopped = False
        self._thread: Optional[threading.Thread] = None

    def start(self) -> "FrameGrabber":
        """
        Starts the frame grabbing thread.

        Returns:
            FrameGrabber: The FrameGrabber object.
        """
        self._stopped = False
        self._thread = threading.Thread(target=self._update, daemon=True)
        self._thread.start()
        return self

    def _update(self) -> None:
        """
        The main loop of the frame grabbing thread.
        """
        while not self._stopped:
            with self._lock:
                if not self.camera.is_opened:
                    self.camera.connect()
                    time.sleep(1)
                    continue

                if not self.camera.grab():
                    time.sleep(0.01)
                    continue

                success, frame = self.camera.retrieve()

            if success:
                while not self._q.empty():
                    try:
                        self._q.get_nowait()
                    except queue.Empty:
                        break

                try:
                    self._q.put_nowait(frame)
                except queue.Full:
                    pass
            else:
                time.sleep(0.05)

    def read(self, timeout: float) -> Optional[np.ndarray]:
        """
        Reads a frame from the queue.

        Args:
            timeout (float): The maximum time to wait for a frame.

        Returns:
            Optional[np.ndarray]: The frame, or None if no frame is available.
        """
        try:
            return self._q.get(timeout=timeout)
        except queue.Empty:
            logger.debug("Read timeout: No frame received within the timeout window.")
            return None

    def stop(self) -> None:
        """
        Stops the frame grabbing thread.
        """
        self._stopped = True
        if self._thread is not None:
            self._thread.join(timeout=2.0)

        with self._lock:
            self.camera.release()