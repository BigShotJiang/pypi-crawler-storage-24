"""TrueFrame: A robust, latency-free RTSP stream reader."""
from .trueframe import TrueFrame

__all__ = ["TrueFrame"]