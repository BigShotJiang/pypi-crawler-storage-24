"""Verdikt — governance pipeline for AI agent decisions."""

__version__ = "0.1.0"
