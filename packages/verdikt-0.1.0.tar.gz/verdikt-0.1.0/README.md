# Verdikt

Governance pipeline for AI agent decisions.

Full release coming soon.
