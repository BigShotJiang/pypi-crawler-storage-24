"""Message types for WebRTC communication between foundation and viewer."""

from enum import Enum
from typing import Any, Dict, Optional, List
from dataclasses import dataclass, asdict
import json


class MessageType(str, Enum):
    """Types of messages that can be sent over WebRTC."""

    DAG = "@buildr/dag"
    SCREENSHOT_REQUEST = "screenshot_request"
    SCREENSHOT_RESPONSE = "screenshot_response"
    LOG = "log"
    ERROR = "error"
    BUILD_STATUS = "build_status"
    BUILD_RESULT = "build_result"
    PING = "ping"
    PONG = "pong"


@dataclass
class Message:
    """Base message class for all WebRTC communications."""

    type: MessageType

    def to_json(self) -> str:
        """Serialize message to JSON string."""
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, json_str: str) -> "Message":
        """Deserialize message from JSON string."""
        data = json.loads(json_str)
        msg_type = MessageType(data["type"])

        if msg_type == MessageType.DAG:
            return DagMessage.from_dict(data)
        elif msg_type == MessageType.SCREENSHOT_REQUEST:
            return ScreenshotRequest.from_dict(data)
        elif msg_type == MessageType.SCREENSHOT_RESPONSE:
            return ScreenshotResponse.from_dict(data)
        elif msg_type == MessageType.LOG:
            return LogMessage.from_dict(data)
        elif msg_type == MessageType.ERROR:
            return ErrorMessage.from_dict(data)
        elif msg_type == MessageType.BUILD_STATUS:
            return BuildStatusMessage.from_dict(data)
        elif msg_type == MessageType.BUILD_RESULT:
            return BuildResultMessage.from_dict(data)
        else:
            return cls(type=msg_type)


@dataclass
class DagMessage(Message):
    """Message containing DAG data to render in the viewer."""

    dag: Dict[str, Any]
    request_id: Optional[str] = None

    def __post_init__(self):
        self.type = MessageType.DAG

    def to_json(self) -> str:
        return json.dumps(
            {"type": self.type.value, "dag": self.dag, "request_id": self.request_id}
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DagMessage":
        return cls(
            type=MessageType.DAG, dag=data["dag"], request_id=data.get("request_id")
        )


@dataclass
class ScreenshotRequest(Message):
    """Request a screenshot from the viewer."""

    request_id: str
    format: str = "png"  # png, jpg, webp
    full_page: bool = False

    def __post_init__(self):
        self.type = MessageType.SCREENSHOT_REQUEST

    def to_json(self) -> str:
        return json.dumps(
            {
                "type": self.type.value,
                "request_id": self.request_id,
                "format": self.format,
                "full_page": self.full_page,
            }
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ScreenshotRequest":
        return cls(
            type=MessageType.SCREENSHOT_REQUEST,
            request_id=data["request_id"],
            format=data.get("format", "png"),
            full_page=data.get("full_page", False),
        )


@dataclass
class ScreenshotResponse(Message):
    """Response containing screenshot data from the viewer."""

    request_id: str
    data_url: str  # Base64 encoded image data URL
    timestamp: Optional[float] = None

    def __post_init__(self):
        self.type = MessageType.SCREENSHOT_RESPONSE

    def to_json(self) -> str:
        return json.dumps(
            {
                "type": self.type.value,
                "request_id": self.request_id,
                "data_url": self.data_url,
                "timestamp": self.timestamp,
            }
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ScreenshotResponse":
        return cls(
            type=MessageType.SCREENSHOT_RESPONSE,
            request_id=data["request_id"],
            data_url=data["data_url"],
            timestamp=data.get("timestamp"),
        )


@dataclass
class LogMessage(Message):
    """Log message from the viewer (console.log, console.warn, console.error)."""

    level: str  # log, warn, error, debug
    message: str
    timestamp: Optional[float] = None
    source: Optional[str] = None

    def __post_init__(self):
        self.type = MessageType.LOG

    def to_json(self) -> str:
        return json.dumps(
            {
                "type": self.type.value,
                "level": self.level,
                "message": self.message,
                "timestamp": self.timestamp,
                "source": self.source,
            }
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LogMessage":
        return cls(
            type=MessageType.LOG,
            level=data["level"],
            message=data["message"],
            timestamp=data.get("timestamp"),
            source=data.get("source"),
        )


@dataclass
class ErrorMessage(Message):
    """Error message from the viewer or broker."""

    error: str
    stack_trace: Optional[str] = None
    request_id: Optional[str] = None
    timestamp: Optional[float] = None

    def __post_init__(self):
        self.type = MessageType.ERROR

    def to_json(self) -> str:
        return json.dumps(
            {
                "type": self.type.value,
                "error": self.error,
                "stack_trace": self.stack_trace,
                "request_id": self.request_id,
                "timestamp": self.timestamp,
            }
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ErrorMessage":
        return cls(
            type=MessageType.ERROR,
            error=data["error"],
            stack_trace=data.get("stack_trace"),
            request_id=data.get("request_id"),
            timestamp=data.get("timestamp"),
        )


@dataclass
class BuildStatusMessage(Message):
    """Build status message from broker to viewer."""

    request_id: str
    status: str  # pending, building, success, error
    timestamp: Optional[float] = None

    def __post_init__(self):
        self.type = MessageType.BUILD_STATUS

    def to_json(self) -> str:
        return json.dumps(
            {
                "type": self.type.value,
                "request_id": self.request_id,
                "status": self.status,
                "timestamp": self.timestamp,
            }
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BuildStatusMessage":
        return cls(
            type=MessageType.BUILD_STATUS,
            request_id=data["request_id"],
            status=data["status"],
            timestamp=data.get("timestamp"),
        )


@dataclass
class BuildResultMessage(Message):
    """Build result message from viewer back to broker."""

    request_id: str
    success: bool
    errors: List[str]
    logs: List[str]
    timestamp: Optional[float] = None

    def __post_init__(self):
        self.type = MessageType.BUILD_RESULT

    def to_json(self) -> str:
        return json.dumps(
            {
                "type": self.type.value,
                "request_id": self.request_id,
                "success": self.success,
                "errors": self.errors,
                "logs": self.logs,
                "timestamp": self.timestamp,
            }
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BuildResultMessage":
        return cls(
            type=MessageType.BUILD_RESULT,
            request_id=data["request_id"],
            success=data["success"],
            errors=data.get("errors", []),
            logs=data.get("logs", []),
            timestamp=data.get("timestamp"),
        )
