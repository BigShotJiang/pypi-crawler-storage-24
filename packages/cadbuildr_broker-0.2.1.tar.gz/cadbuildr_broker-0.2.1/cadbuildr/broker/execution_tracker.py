"""Execution tracker for managing build states and results."""

import hashlib
import json
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field


@dataclass
class ExecutionState:
    """State of a single execution."""

    request_id: str
    status: str  # pending, building, success, error
    timestamp: float
    dag_hash: str
    dag_data: Optional[Dict[str, Any]] = None
    errors: List[str] = field(default_factory=list)
    logs: List[str] = field(default_factory=list)
    screenshot_data: Optional[str] = None
    screenshot_timestamp: Optional[float] = None


class ExecutionTracker:
    """Tracks execution states for DAG builds."""

    def __init__(self):
        self._executions: Dict[str, ExecutionState] = {}

    def generate_request_id(self, dag_data: Dict[str, Any]) -> str:
        """Generate a request_id as SHA256 hash of the DAG JSON."""
        dag_json = json.dumps(dag_data, sort_keys=True)
        return hashlib.sha256(dag_json.encode()).hexdigest()

    def create_execution(self, dag_data: Dict[str, Any]) -> str:
        """Create a new execution and return its request_id."""
        request_id = self.generate_request_id(dag_data)
        dag_json = json.dumps(dag_data, sort_keys=True)
        dag_hash = hashlib.sha256(dag_json.encode()).hexdigest()

        execution = ExecutionState(
            request_id=request_id,
            status="pending",
            timestamp=time.time(),
            dag_hash=dag_hash,
            dag_data=dag_data,
        )

        self._executions[request_id] = execution
        return request_id

    def update_status(self, request_id: str, status: str) -> None:
        """Update the status of an execution."""
        if request_id in self._executions:
            self._executions[request_id].status = status

    def get_status(self, request_id: str) -> Optional[Dict[str, Any]]:
        """Get the status and details of an execution."""
        execution = self._executions.get(request_id)
        if not execution:
            return None

        return {
            "request_id": execution.request_id,
            "status": execution.status,
            "timestamp": execution.timestamp,
            "dag_hash": execution.dag_hash,
            "errors": execution.errors,
            "logs": execution.logs,
            "has_screenshot": execution.screenshot_data is not None,
            "screenshot_timestamp": execution.screenshot_timestamp,
        }

    def add_error(self, request_id: str, error: str) -> None:
        """Add an error message to an execution."""
        if request_id in self._executions:
            self._executions[request_id].errors.append(error)
            self.update_status(request_id, "error")

    def add_log(self, request_id: str, log: str) -> None:
        """Add a log message to an execution."""
        if request_id in self._executions:
            self._executions[request_id].logs.append(log)

    def set_screenshot(self, request_id: str, data_url: str) -> None:
        """Set the screenshot data for an execution."""
        if request_id in self._executions:
            self._executions[request_id].screenshot_data = data_url
            self._executions[request_id].screenshot_timestamp = time.time()

    def get_screenshot(self, request_id: str) -> Optional[str]:
        """Get the screenshot data_url for an execution."""
        execution = self._executions.get(request_id)
        if execution:
            return execution.screenshot_data
        return None

    def list_executions(self) -> List[str]:
        """List all execution request_ids."""
        return list(self._executions.keys())

    def cleanup_old_executions(self, max_age_seconds: int = 3600) -> int:
        """Remove executions older than max_age_seconds. Returns count removed."""
        current_time = time.time()
        to_remove = []

        for request_id, execution in self._executions.items():
            if current_time - execution.timestamp > max_age_seconds:
                to_remove.append(request_id)

        for request_id in to_remove:
            del self._executions[request_id]

        return len(to_remove)
