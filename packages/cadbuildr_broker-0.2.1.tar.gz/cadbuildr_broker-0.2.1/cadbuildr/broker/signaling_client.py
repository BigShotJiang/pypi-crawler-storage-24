"""Signaling client for WebRTC offer/answer exchange."""

import asyncio
import logging
import aiohttp
from typing import Optional
from .webrtc_handler import WebRTCHandler

logger = logging.getLogger(__name__)


class SignalingClient:
    """Polls Next.js API for WebRTC offers and submits answers."""

    def __init__(
        self,
        signaling_base_url: str,
        webrtc_handler: WebRTCHandler,
        auth_bearer_token: Optional[str] = None,
    ):
        self.base_url = signaling_base_url.rstrip("/")
        self.webrtc_handler = webrtc_handler
        self.auth_bearer_token = auth_bearer_token
        self.connection_id: Optional[str] = None
        # Exponential backoff for polling
        self.min_poll_interval = 0.5  # seconds
        self.max_poll_interval = 5.0  # seconds
        self.current_poll_interval = self.min_poll_interval

    def _request_headers(self) -> dict[str, str]:
        if self.auth_bearer_token:
            return {"Authorization": f"Bearer {self.auth_bearer_token}"}
        return {}

    async def run(self):
        """Main loop: poll for offers and handle connections."""
        async with aiohttp.ClientSession() as session:
            while True:
                try:
                    await self._poll_for_offer(session)
                except Exception as e:
                    logger.error(f"Error in signaling loop: {e}")
                    await asyncio.sleep(self.current_poll_interval)

    async def _poll_for_offer(self, session: aiohttp.ClientSession):
        """Poll the signaling server for new offers."""
        try:
            # Poll for any pending offer; server returns actual connectionId
            # Keep appending the last known connectionId for compatibility/logging
            query_id = self.connection_id or "broker-001"
            url = f"{self.base_url}/poll?connectionId={query_id}"

            async with session.get(url, headers=self._request_headers()) as response:
                if response.status == 200:
                    data = await response.json()
                    # Server may provide connectionId alongside offer
                    polled_id = data.get("connectionId", self.connection_id)
                    offer_sdp = data.get("offer")

                    if offer_sdp:
                        # Update connection id to the actual viewer-provided id
                        if polled_id:
                            self.connection_id = polled_id
                        # Reset backoff on successful offer
                        self.current_poll_interval = self.min_poll_interval
                        logger.info("Received offer from signaling server")
                        await self._handle_offer(session, offer_sdp)
                elif response.status == 404:
                    # No offer available yet - backoff
                    await asyncio.sleep(self.current_poll_interval)
                    self.current_poll_interval = min(
                        self.max_poll_interval, self.current_poll_interval * 1.5
                    )
                else:
                    logger.warning(f"Unexpected response status: {response.status}")
                    await asyncio.sleep(self.current_poll_interval)
                    self.current_poll_interval = min(
                        self.max_poll_interval, self.current_poll_interval * 1.5
                    )

        except aiohttp.ClientError as e:
            logger.debug(f"Connection error (will retry): {e}")
            await asyncio.sleep(self.current_poll_interval)
            self.current_poll_interval = min(
                self.max_poll_interval, self.current_poll_interval * 1.5
            )

    async def _handle_offer(self, session: aiohttp.ClientSession, offer_sdp: str):
        """Handle an offer by creating an answer and posting it back."""
        try:
            # Create answer
            answer_sdp = await self.webrtc_handler.handle_offer(offer_sdp)

            # Post answer back to signaling server
            url = f"{self.base_url}/answer"
            payload = {"connectionId": self.connection_id, "answer": answer_sdp}

            async with session.post(
                url, json=payload, headers=self._request_headers()
            ) as response:
                if response.status == 200:
                    logger.info("Posted answer to signaling server")
                else:
                    logger.error(f"Failed to post answer: {response.status}")

        except Exception as e:
            logger.error(f"Error handling offer: {e}")
