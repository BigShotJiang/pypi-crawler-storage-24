"""CLI entry point for the CADbuildr broker."""

import asyncio
import os
import click
import logging
from .webrtc_handler import WebRTCHandler
from .signaling_client import SignalingClient
from .http_server import HTTPServer
from .execution_tracker import ExecutionTracker

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def _build_signaling_base_url(
    host: str, port: int, signaling_scheme: str, signaling_base_url: str | None
) -> str:
    if signaling_base_url:
        return signaling_base_url.rstrip("/")
    return f"{signaling_scheme}://{host}:{port}/api/webrtc"


@click.command()
@click.option(
    "--host",
    default="hub.cadbuildr.com",
    show_default=True,
    help="Signaling server host (used when --signaling-base-url is not set)",
)
@click.option(
    "--port",
    default=443,
    show_default=True,
    help="Signaling server port (used when --signaling-base-url is not set)",
)
@click.option(
    "--signaling-scheme",
    default="https",
    type=click.Choice(["http", "https"]),
    show_default=True,
    help="URL scheme for signaling server (used when --signaling-base-url is not set)",
)
@click.option(
    "--signaling-base-url",
    default=None,
    help=(
        "Full signaling API base URL (e.g. https://hub.cadbuildr.com/api/webrtc). "
        "Overrides --host/--port/--signaling-scheme."
    ),
)
@click.option(
    "--auth-bearer-token",
    default=None,
    help=(
        "Optional bearer token for signaling API auth. "
        "If unset, reads CADBUILDR_SIGNALING_BEARER_TOKEN."
    ),
)
@click.option(
    "--broker-port", default=5050, help="HTTP server port for receiving DAG data"
)
def main(
    host: str,
    port: int,
    signaling_scheme: str,
    signaling_base_url: str | None,
    auth_bearer_token: str | None,
    broker_port: int,
):
    """Start the CADbuildr WebRTC broker."""
    resolved_signaling_url = _build_signaling_base_url(
        host=host,
        port=port,
        signaling_scheme=signaling_scheme,
        signaling_base_url=signaling_base_url,
    )
    resolved_bearer_token = auth_bearer_token or os.getenv(
        "CADBUILDR_SIGNALING_BEARER_TOKEN"
    )

    logger.info(f"Starting CADbuildr broker...")
    logger.info(f"Signaling server: {resolved_signaling_url}")
    if resolved_bearer_token:
        logger.info("Signaling auth: bearer token enabled")
    logger.info(f"HTTP server port: {broker_port}")

    asyncio.run(
        run_broker(
            signaling_base_url=resolved_signaling_url,
            auth_bearer_token=resolved_bearer_token,
            broker_port=broker_port,
        )
    )


async def run_broker(
    signaling_base_url: str, auth_bearer_token: str | None, broker_port: int
):
    """Main async loop for the broker."""
    # Create shared components
    execution_tracker = ExecutionTracker()
    webrtc_handler = WebRTCHandler(execution_tracker)
    signaling_client = SignalingClient(
        signaling_base_url, webrtc_handler, auth_bearer_token=auth_bearer_token
    )
    http_server = HTTPServer(broker_port, webrtc_handler, execution_tracker)

    # Set reference so webrtc_handler can signal waiting HTTP handlers
    webrtc_handler.http_server = http_server

    # Start HTTP server
    await http_server.start()
    logger.info(f"HTTP server started on port {broker_port}")

    # Start signaling loop
    logger.info("Starting signaling client...")
    await signaling_client.run()


if __name__ == "__main__":
    main()
