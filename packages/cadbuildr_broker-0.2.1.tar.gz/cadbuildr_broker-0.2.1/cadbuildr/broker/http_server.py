"""HTTP server for receiving DAG data from foundation library."""

import asyncio
import logging
from typing import Optional, Dict, Any
from aiohttp import web
from .webrtc_handler import WebRTCHandler
from .messages import DagMessage, MessageType, ScreenshotRequest
from .execution_tracker import ExecutionTracker

logger = logging.getLogger(__name__)


@web.middleware
async def cors_middleware(request: web.Request, handler):
    """Add permissive CORS headers so the viewer can call the broker from the browser."""
    if request.method == "OPTIONS":
        response = web.Response(status=200)
    else:
        response = await handler(request)

    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


class HTTPServer:
    """Simple HTTP server to receive DAG data from foundation library."""

    def __init__(
        self,
        port: int,
        webrtc_handler: WebRTCHandler,
        execution_tracker: ExecutionTracker,
    ):
        self.port = port
        self.webrtc_handler = webrtc_handler
        self.execution_tracker = execution_tracker
        self.app = web.Application(
            middlewares=[cors_middleware],
            client_max_size=50 * 1024**2,  # allow large screenshot payloads (~50MB)
        )
        self.runner = None
        self.pending_screenshot_future: Optional[asyncio.Future[Dict[str, Any]]] = None
        self.pending_screenshot_request_id: Optional[str] = None

        # Set up routes
        self.app.router.add_post("/send", self.handle_send)
        self.app.router.add_get("/health", self.handle_health)
        self.app.router.add_get("/status/{request_id}", self.handle_get_status)
        self.app.router.add_get("/screenshot/{request_id}", self.handle_get_screenshot)
        self.app.router.add_post("/screenshot/request", self.handle_request_screenshot)
        self.app.router.add_route(
            "*", "/screenshot/upload", self.handle_upload_screenshot
        )

    async def handle_send(self, request: web.Request) -> web.Response:
        """Handle POST /send - receive DAG data from foundation."""
        try:
            data = await request.json()
            logger.info("Received DAG data from foundation")

            # Extract DAG data
            if "dag" in data:
                dag_data = data["dag"]
                provided_request_id = data.get("request_id")
            else:
                # Legacy support - treat whole payload as DAG
                dag_data = data
                provided_request_id = None

            # Create execution and get request_id
            request_id = self.execution_tracker.create_execution(dag_data)
            self.execution_tracker.update_status(request_id, "building")

            # Create typed message with request_id
            message = DagMessage(
                type=MessageType.DAG, dag=dag_data, request_id=request_id
            )

            # Forward to viewer via WebRTC
            await self.webrtc_handler.send_message(message)

            logger.info(f"Created execution {request_id}")
            return web.json_response({"status": "submitted", "request_id": request_id})
        except Exception as e:
            logger.error(f"Error handling DAG data: {e}")
            return web.json_response({"status": "error", "message": str(e)}, status=500)

    async def handle_health(self, request: web.Request) -> web.Response:
        """Health check endpoint."""
        return web.json_response(
            {"status": "ok", "connected": self.webrtc_handler.data_channel is not None}
        )

    async def handle_get_status(self, request: web.Request) -> web.Response:
        """Handle GET /status/{request_id} - get execution status."""
        request_id = request.match_info["request_id"]

        status = self.execution_tracker.get_status(request_id)
        if status is None:
            return web.json_response(
                {"status": "error", "message": "Execution not found"}, status=404
            )

        return web.json_response(status)

    async def handle_get_screenshot(self, request: web.Request) -> web.Response:
        """Handle GET /screenshot/{request_id} - get screenshot data."""
        request_id = request.match_info["request_id"]

        screenshot_data = self.execution_tracker.get_screenshot(request_id)
        if screenshot_data is None:
            return web.json_response(
                {"status": "error", "message": "Screenshot not available"}, status=404
            )

        return web.json_response(
            {"request_id": request_id, "data_url": screenshot_data}
        )

    async def handle_request_screenshot(self, request: web.Request) -> web.Response:
        """Handle POST /screenshot/request - request screenshot from viewer and wait for response."""
        import uuid

        try:
            # Check if viewer is connected
            if not self.webrtc_handler.data_channel:
                logger.warning("DataChannel is None")
                return web.json_response(
                    {"status": "error", "message": "Viewer not connected"}, status=503
                )

            channel_state = self.webrtc_handler.data_channel.readyState
            logger.info(f"DataChannel state: {channel_state}")
            if channel_state != "open":
                logger.warning(f"DataChannel not open, state: {channel_state}")
                return web.json_response(
                    {
                        "status": "error",
                        "message": f"Viewer not connected (channel state: {channel_state})",
                    },
                    status=503,
                )

            # Check if there's already a pending screenshot request
            if (
                self.pending_screenshot_future is not None
                and not self.pending_screenshot_future.done()
            ):
                return web.json_response(
                    {
                        "status": "error",
                        "message": "Screenshot request already in progress",
                    },
                    status=429,
                )

            # Generate a temporary request_id for this screenshot request
            request_id = str(uuid.uuid4())
            logger.info(f"Requesting screenshot with request_id: {request_id}")

            # Create a future to wait for the screenshot response
            self.pending_screenshot_future = asyncio.Future()
            self.pending_screenshot_request_id = request_id

            # Send screenshot request to viewer via WebRTC
            screenshot_msg = ScreenshotRequest(
                type=MessageType.SCREENSHOT_REQUEST, request_id=request_id
            )
            logger.info(
                f"Sending screenshot request message: {screenshot_msg.to_json()}"
            )
            await self.webrtc_handler.send_message(screenshot_msg)
            logger.info("Screenshot request message sent, waiting for response...")

            # Wait for screenshot response (timeout after 15 seconds)
            try:
                result = await asyncio.wait_for(
                    self.pending_screenshot_future, timeout=15.0
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "Screenshot request timed out waiting for viewer response"
                )
                return web.json_response(
                    {"status": "error", "message": "Screenshot request timed out"},
                    status=504,
                )
            finally:
                self.pending_screenshot_future = None
                self.pending_screenshot_request_id = None

            if not isinstance(result, dict):
                logger.error(f"Unexpected screenshot result payload: {result}")
                return web.json_response(
                    {"status": "error", "message": "Invalid screenshot response"},
                    status=500,
                )

            if not result.get("success"):
                error_message = result.get("error", "Screenshot failed")
                return web.json_response(
                    {"status": "error", "message": error_message}, status=500
                )

            screenshot_data_url = result.get("data_url")
            if not screenshot_data_url:
                return web.json_response(
                    {"status": "error", "message": "Screenshot data missing"},
                    status=500,
                )

            return web.json_response(
                {"status": "success", "data_url": screenshot_data_url}
            )
        except Exception as e:
            logger.error(f"Error requesting screenshot: {e}")
            self.pending_screenshot_future = None
            self.pending_screenshot_request_id = None
            return web.json_response({"status": "error", "message": str(e)}, status=500)

    async def start(self):
        """Start the HTTP server."""
        self.runner = web.AppRunner(self.app)
        await self.runner.setup()
        site = web.TCPSite(self.runner, "localhost", self.port)
        await site.start()
        logger.info(f"HTTP server listening on http://localhost:{self.port}")

    async def handle_upload_screenshot(self, request: web.Request) -> web.Response:
        """
        Handle POST /screenshot/upload - viewer uploads screenshot data directly via HTTP.
        """
        if request.method == "OPTIONS":
            return web.Response(status=200)
        if request.method != "POST":
            return web.json_response(
                {"status": "error", "message": "Method not allowed"}, status=405
            )

        try:
            payload = await request.json()
            request_id = payload.get("request_id")
            data_url = payload.get("data_url")
            error_message = payload.get("error")

            if not request_id:
                return web.json_response(
                    {"status": "error", "message": "request_id is required"}, status=400
                )

            logger.info(f"Received screenshot upload for request {request_id}")
            result_payload: Dict[str, Any]

            if (
                self.pending_screenshot_request_id
                and request_id != self.pending_screenshot_request_id
            ):
                logger.warning(
                    f"Screenshot upload request_id mismatch. Expected {self.pending_screenshot_request_id}, got {request_id}"
                )

            if error_message:
                logger.error(f"Screenshot upload reported error: {error_message}")
                result_payload = {"success": False, "error": error_message}
            elif data_url:
                result_payload = {"success": True, "data_url": data_url}
                # Store screenshot for future retrieval if execution exists
                self.execution_tracker.set_screenshot(request_id, data_url)
            else:
                return web.json_response(
                    {
                        "status": "error",
                        "message": "data_url or error must be provided",
                    },
                    status=400,
                )

            if (
                self.pending_screenshot_future
                and not self.pending_screenshot_future.done()
            ):
                self.pending_screenshot_future.set_result(result_payload)
                self.pending_screenshot_future = None
                self.pending_screenshot_request_id = None
            else:
                logger.warning(
                    "No pending screenshot future to resolve for upload response"
                )

            return web.json_response({"status": "received"})
        except Exception as e:
            logger.error(f"Error handling screenshot upload: {e}")
            return web.json_response({"status": "error", "message": str(e)}, status=500)
