"""WebRTC connection handler using aiortc."""

import asyncio
import json
import logging
from typing import Optional, Callable
from aiortc import RTCPeerConnection, RTCSessionDescription, RTCDataChannel
from .messages import (
    Message,
    LogMessage,
    ErrorMessage,
    ScreenshotResponse,
    BuildResultMessage,
)
from .execution_tracker import ExecutionTracker

logger = logging.getLogger(__name__)


class WebRTCHandler:
    """Manages WebRTC connections and data channels."""

    def __init__(self, execution_tracker: Optional[ExecutionTracker] = None):
        self.pc: Optional[RTCPeerConnection] = None
        self.data_channel: Optional[RTCDataChannel] = None
        self.connection_ready = asyncio.Event()
        self.message_handlers = (
            []
        )  # List of async callables to handle incoming messages
        self.execution_tracker = execution_tracker or ExecutionTracker()
        self.message_queue = []  # Queue of messages waiting to be sent

    async def handle_offer(self, offer_sdp: str) -> str:
        """
        Handle an incoming WebRTC offer and return an answer.

        Args:
            offer_sdp: SDP string from the offer

        Returns:
            SDP string for the answer
        """
        logger.info("Received WebRTC offer")

        # Create new peer connection
        self.pc = RTCPeerConnection()

        # Set up event handlers
        @self.pc.on("datachannel")
        def on_datachannel(channel: RTCDataChannel):
            logger.info(f"DataChannel received: {channel.label}")
            self.data_channel = channel

            @channel.on("open")
            def on_open():
                logger.info("DataChannel opened")
                self.connection_ready.set()
                # Send any queued messages
                while self.message_queue:
                    queued_message = self.message_queue.pop(0)
                    asyncio.create_task(self._send_message_now(queued_message))

            @channel.on("close")
            def on_close():
                logger.info("DataChannel closed")
                self.connection_ready.clear()
                self.data_channel = None

            @channel.on("message")
            def on_message(message):
                try:
                    msg = Message.from_json(message)
                    logger.debug(f"Received {msg.type} message from viewer")

                    # Handle different message types
                    if isinstance(msg, LogMessage):
                        logger.info(f"[Viewer Log - {msg.level}] {msg.message}")
                    elif isinstance(msg, ErrorMessage):
                        logger.error(f"[Viewer Error] {msg.error}")
                        if msg.stack_trace:
                            logger.error(f"Stack trace: {msg.stack_trace}")
                        # Store error in execution tracker if request_id is present
                        if msg.request_id and self.execution_tracker:
                            self.execution_tracker.add_error(msg.request_id, msg.error)
                    elif isinstance(msg, ScreenshotResponse):
                        logger.info(
                            f"Received screenshot response for request {msg.request_id}"
                        )

                        # Store screenshot in execution tracker (for backward compatibility)
                        if self.execution_tracker:
                            self.execution_tracker.set_screenshot(
                                msg.request_id, msg.data_url
                            )

                        # Signal waiting HTTP handler if there is one
                        if hasattr(self, "http_server") and self.http_server:
                            pending_future = self.http_server.pending_screenshot_future
                            if pending_future and not pending_future.done():
                                pending_future.set_result(
                                    {"success": True, "data_url": msg.data_url}
                                )
                                self.http_server.pending_screenshot_future = None
                                self.http_server.pending_screenshot_request_id = None

                        # Call any registered handlers
                        for handler in self.message_handlers:
                            asyncio.create_task(handler(msg))
                    elif isinstance(msg, BuildResultMessage):
                        logger.info(
                            f"Received build result for {msg.request_id}: success={msg.success}"
                        )
                        # Store build result in execution tracker
                        if self.execution_tracker:
                            status = "success" if msg.success else "error"
                            self.execution_tracker.update_status(msg.request_id, status)
                            # Store errors and logs
                            for error in msg.errors:
                                self.execution_tracker.add_error(msg.request_id, error)
                            for log in msg.logs:
                                self.execution_tracker.add_log(msg.request_id, log)
                        # Call any registered handlers
                        for handler in self.message_handlers:
                            asyncio.create_task(handler(msg))
                except Exception as e:
                    logger.error(f"Error processing message: {e}")

        @self.pc.on("connectionstatechange")
        async def on_connectionstatechange():
            logger.info(f"Connection state: {self.pc.connectionState}")
            if (
                self.pc.connectionState == "failed"
                or self.pc.connectionState == "closed"
            ):
                await self.close()

        # Set remote description (offer)
        offer = RTCSessionDescription(sdp=offer_sdp, type="offer")
        await self.pc.setRemoteDescription(offer)

        # Create answer
        answer = await self.pc.createAnswer()
        await self.pc.setLocalDescription(answer)

        logger.info("Created WebRTC answer")
        return self.pc.localDescription.sdp

    async def send_message(self, message: Message):
        """
        Send a typed message to the viewer via DataChannel.

        Args:
            message: Message object to send
        """
        if not self.data_channel or self.data_channel.readyState != "open":
            logger.warning(f"DataChannel not ready, queuing {message.type} message")
            self.message_queue.append(message)
            return

        await self._send_message_now(message)

    async def _send_message_now(self, message: Message):
        """
        Send a message immediately (assuming datachannel is ready).

        Args:
            message: Message object to send
        """
        try:
            json_str = message.to_json()
            logger.debug(f"Sending {message.type} message: {json_str[:200]}...")
            self.data_channel.send(json_str)
            logger.info(
                f"Sent {message.type} message to viewer ({len(json_str)} bytes)"
            )
        except Exception as e:
            logger.error(f"Error sending message: {e}", exc_info=True)

    def add_message_handler(self, handler: Callable[[Message], None]):
        """Add a handler for incoming messages from the viewer."""
        self.message_handlers.append(handler)

    async def close(self):
        """Close the WebRTC connection."""
        if self.pc:
            await self.pc.close()
            self.pc = None
        self.data_channel = None
        self.connection_ready.clear()
        logger.info("WebRTC connection closed")
