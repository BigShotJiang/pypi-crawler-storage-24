# kDrive Uploader

A small tool to programmatically upload files to [kDrive drop boxes](https://www.infomaniak.com/en/support/faq/2386/manage-kdrive-drop-boxes), used by the author as a poor man's backup solution.

## Quickstart

First install with `pip` then run:

```bash
pip install kdrive-uploader

# upload all files in current folder
kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000

# upload a specific file
kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000 README.md
```

The link can either be just the last part containing the ids as above or a full kDrive drop box link (in the shape `https://kdrive.infomaniak.com/app/collaborate/0000000/00000000-0000-0000-0000-000000000000`).

You can also run it directly using `uv`:

```bash
uvx kdrive-uploader --help
```

Or with docker (still using `uv`):

```bash
docker run --rm --workdir /io -v .:/io -v uv-cache:/root/ ghcr.io/astral-sh/uv:alpine uvx kdrive-uploader --help
```

## More info

A state database (`.kdu_state.sqlite3`) at the root of the backed-up directory tracks each file's hash. Only new or changed files are uploaded on each run. The root is the closest parent directory that already contains a state database, or the target directory itself if none is found.

This works best for append-only cases, since kDrive drop boxes are write-only. Updates are still handled by kDrive, which creates a duplicate with `(1)` appended to the filename. Being write-only and append-only prevents an attacker who takes control of the server from compromising the backup.

Losing the state database would result in a full re-upload and duplicates. In such scenarios, the easiest fix is to clear the drop box first. In the future, a `--fake` argument could allow generating an initial state database from a local kDrive copy, which could then be deployed to the server to avoid a full re-upload.

## Manual

```
Usage: kdrive-uploader [OPTIONS] LINK [PATH]

╭─ Arguments ────────────────────────────────────────────────────────────────────────────────────────╮
│ *    link      TEXT    [required]                                                                  │
│      path      [PATH]  [default: .]                                                                │
╰────────────────────────────────────────────────────────────────────────────────────────────────────╯
╭─ Options ──────────────────────────────────────────────────────────────────────────────────────────╮
│ --first-name                    TEXT  [default: kdrive]                                            │
│ --last-name                     TEXT  [default: uploader]                                          │
│ --email                         TEXT  [default: kdrive-uploader@ik.me]                             │
│ --dry-run       --no-dry-run          [default: no-dry-run]                                        │
│ --help                                Show this message and exit.                                  │
╰────────────────────────────────────────────────────────────────────────────────────────────────────╯
```

## Dev quickstart

```bash
# create dev env
uv sync --dev

# install prek (git hooks manager)
uv run prek install

# run from source
cd test_data
uv run kdrive-uploader 0000000/00000000-0000-0000-0000-000000000000
```
