#!/usr/bin/env python

# PYTHON_ARGCOMPLETE_OK
import argparse
import hashlib
import os
import re
import time

import pywikibot
from pywikibot import config as pwb_config

pwb_config.socket_timeout = 200
# Without this fail on bad connection
# Default is (6.05, 45) for connect, read
# https://github.com/wikimedia/pywikibot/blob/ed4a102236765ea4b2418ca5770af8d4ba9b4c3f/pywikibot/config.py#L784

try:
    import argcomplete
except ImportError:
    argcomplete = None

pwb_config.put_throttle = 0

site = pywikibot.Site()

ALLOWED_EXTENSIONS = ('.bmp', '.gif', '.png', '.jpg', '.jpeg', '.webp', '.webm', '.mkv', '.mp3', '.opus', '.ogg', '.pdf', '.djvu')
ILLEGAL_COMMONS_TITLE_CHARS_RE = re.compile(r'[\x00-\x1f\x7f#<>\[\]|{}]')
# `(?<!\d)` (note the `<`) is a negative lookbehind: previous char is not a digit.
# `(?!\d)` is a negative lookahead: next char is not a digit.
# Match a standalone four-digit year starting with 1 or 2.
FILENAME_YEAR_RE = re.compile(r'(?<!\d)([12]\d{3})(?!\d)')
UPLOAD_MAX_RETRIES = 5
UPLOAD_CHUNK_SIZE = 4 * 1024 * 1024
RETRYABLE_UPLOAD_API_ERROR_CODES = {
    'internal-error',
    'internal_api_error_DBConnectionError',
    'lockmanager-fail-conflict',
    'maxlag',
    'ratelimited',
    'readonly',
    'stashfailed',
}


def collect_files(recursive: bool) -> list[str]:
    if recursive:
        files: list[str] = []
        for root, dirs, filenames in os.walk('.', topdown=True):
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for filename in filenames:
                if filename.startswith('.'):
                    continue
                if filename.lower().endswith(ALLOWED_EXTENSIONS):
                    files.append(os.path.relpath(os.path.join(root, filename), '.'))
        return sorted(files)

    return sorted([
        f
        for f in os.listdir('.')
        if not f.startswith('.')
        and os.path.isfile(f)
        and f.lower().endswith(ALLOWED_EXTENSIONS)
    ])


def enable_autocomplete(parser: argparse.ArgumentParser) -> None:
    if argcomplete is not None:
        argcomplete.autocomplete(parser)


def sanitize_commons_filename(filename: str) -> str:
    sanitized = ILLEGAL_COMMONS_TITLE_CHARS_RE.sub('_', filename)
    sanitized = sanitized.replace("'", 'Ꞌ')
    # MediaWiki treats "_" as a space in titles, so remove both before "." or ","
    sanitized = re.sub(r'[_\s]+([.,])', r'\1', sanitized)
    sanitized = re.sub(r'\s+', ' ', sanitized).strip()
    return sanitized


def resolve_date(date_arg: str | None, date_parse: bool, file_path: str) -> str | None:
    if date_parse:
        match = FILENAME_YEAR_RE.search(os.path.basename(file_path))
        return match.group(1) if match else None
    return date_arg


def validate_license(license_name: str) -> None:
    if license_name == 'PD-Russia-old':
        print('Use PD-Russia-expired')
        raise SystemExit(1)


def calculate_local_sha1(file_path: str) -> str:
    with open(file_path, 'rb') as file_handle:
        return hashlib.file_digest(file_handle, 'sha1').hexdigest()


def is_pywikibot_traceback(message: object) -> bool:
    return str(message).startswith('Traceback (most recent call last):')


def is_retryable_upload_error(error: Exception) -> bool:
    error_code = getattr(error, 'code', None)
    if isinstance(error_code, str) and error_code in RETRYABLE_UPLOAD_API_ERROR_CODES:
        return True

    if type(error).__name__ in {'ConnectionError', 'ServerError', 'TimeoutError'}:
        return True

    return False


def upload_file(file_page: pywikibot.FilePage, file_path: str, description: str) -> bool:
    file_page.text = description
    original_error = pywikibot.error

    def filtered_error(message=None, *args, **kwargs):
        if message is not None and is_pywikibot_traceback(message):
            return
        return original_error(message, *args, **kwargs)

    pywikibot.error = filtered_error
    try:
        return file_page.upload(
            file_path,
            chunk_size=UPLOAD_CHUNK_SIZE,
        )
    finally:
        pywikibot.error = original_error


def run_upload_with_retries(
    file_page: pywikibot.FilePage,
    file_path: str,
    description: str,
) -> bool:
    max_attempts = UPLOAD_MAX_RETRIES + 1
    for attempt in range(1, max_attempts + 1):
        try:
            return upload_file(file_page, file_path, description)
        except Exception as error:
            if attempt >= max_attempts or not is_retryable_upload_error(error):
                raise

            err = getattr(error, 'code', None) or type(error).__name__
            print(
                f'~Attempt {attempt}/{max_attempts} failed with {err}. Retrying after delay...'
            )
            time.sleep(60)

    return False


def build_description(description: str, source: str, _author: str, date: str | None, license: str, categories: list[str]) -> str:

    site.login()
    author = f'[[User:{site.user()}|{site.user()}]]' if _author == 'me' else _author
    categories_block = '\n'.join(f'[[Category:{category}]]' for category in categories)
    if categories_block:
        categories_block += '\n'

    return f'''=={{{{int:filedesc}}}}==
{{{{Information
|description={{{{en|1={description}}}}}
|source={source}
|author={author}
|date={date}
}}}}

=={{{{int:license-header}}}}==
{{{{{license}}}}}

{categories_block}

[[Category:Uploaded with pwb wrapper script by Vitaly Zdanevich]]
'''

def upload_to_commons(file_path: str, description: str, _target: str | None = None, prefix: str | None = None) -> None:
    target = sanitize_commons_filename(_target or os.path.basename(file_path))
    if prefix:
        target = f'{prefix}{target}'

    file_page = pywikibot.FilePage(site, f'File:{target}')
    if file_page.exists():
        commons_file_info = file_page.latest_file_info
        commons_size = f'{commons_file_info.size / 1024 / 1024:.2f} MB'
        local_sha1 = calculate_local_sha1(file_path)
        commons_sha1 = commons_file_info.sha1
        if local_sha1 != commons_sha1:
            print(f'Skipping existing filename on Commons: {target}, Commons size: {commons_size}')
            print(f'WARNING: SHA1 MISMATCH FOR EXISTING FILE ON COMMONS: {target}')
            print(f'LOCAL SHA1: {local_sha1}')
            print(f'COMMONS SHA1: {commons_sha1}')
        else:
            print(f'Wrapper: skipping existing filename: {target}, size: {commons_size}, sha1 is the same')
        return

    run_upload_with_retries(file_page, file_path, description)

def main() -> None:
    print(f'Pywikibot version: {pywikibot.__version__}')

    parser = argparse.ArgumentParser(description='Upload a file to Wikimedia Commons using Pywikibot as a library. Its simpler to use than the official pwb.')
    parser.add_argument('--file', required=False, help='OPTIONAL Path to the local file to upload')
    parser.add_argument('file_posit', nargs='?', help='OPTIONAL Path to the local file to upload')
    parser.add_argument('--source', required=False, help='OPTIONAL For example https://example.com/image', default='{{own}}')
    parser.add_argument('--author', required=False, help='OPTIONAL for example [[User:Globustut|Globustut]]; for the current user use "me"', default = '')
    parser.add_argument('--license', required=False, help='OPTIONAL for example PD-old, default is cc-by-4.0', default='cc-by-4.0')
    parser.add_argument('--category', required=False, action='append', default=[], help='OPTIONAL without brackets. Repeat for multiple categories')
    date_group = parser.add_mutually_exclusive_group()
    date_group.add_argument('--date', required=False, help='OPTIONAL YYYY-MM-DD, for example 2025-12-27')
    date_group.add_argument('--dateParse', action='store_true',
                            help='OPTIONAL extract year from filename: 4 digits starting with 1 or 2')
    parser.add_argument('--desc', required=False, help='OPTIONAL Short description of the file')
    target_group = parser.add_mutually_exclusive_group()
    target_group.add_argument('--target', required=False, help='OPTIONAL target filename on Commons. Ignored if no file specified (if uploading all here)')
    target_group.add_argument('--prefix', required=False, help='OPTIONAL prefix filename on Commons')
    parser.add_argument('--i', required=False, default = 0, help='OPTIONAL start from the specified index', type=int)
    parser.add_argument('--recursive', action='store_true', help='OPTIONAL upload files from subfolders too (only when no file specified)')

    enable_autocomplete(parser)
    args = parser.parse_args()
    validate_license(args.license)
    categories: list[str] = []
    for category in args.category:
        normalized_category = category.strip()
        if normalized_category and normalized_category not in categories:
            categories.append(normalized_category)

    if args.file_posit and os.path.isfile(args.file_posit):
        resolved_date = resolve_date(args.date, args.dateParse, args.file_posit)
        description = build_description(args.desc, args.source, args.author, resolved_date, args.license, categories)
        upload_to_commons(args.file_posit, description, args.target, args.prefix)
    elif args.file and os.path.isfile(args.file):
        resolved_date = resolve_date(args.date, args.dateParse, args.file)
        description = build_description(args.desc, args.source, args.author, resolved_date, args.license, categories)
        upload_to_commons(args.file, description, args.target, args.prefix)
    elif args.file:
        print(f'Error: file not found: {args.file}')
        raise SystemExit(1)
    else:
        files = collect_files(args.recursive)
        for i, f in enumerate(files[args.i:], start = args.i):
            print(f'{i+1}/{len(files)}: {f} {os.path.getsize(f) / 1024 / 1024:.2f} MB')
            resolved_date = resolve_date(args.date, args.dateParse, f)
            description = build_description(args.desc, args.source, args.author, resolved_date, args.license, categories)
            upload_to_commons(f, description, prefix=args.prefix)

def run_with_timer() -> None:
    start_time = time.perf_counter()
    try:
        try:
            main()
        except KeyboardInterrupt:
            print('~Stopped by user.')
            raise SystemExit(130)
    finally:
        elapsed_seconds = int(time.perf_counter() - start_time)
        minutes, seconds = divmod(elapsed_seconds, 60)
        print(f'Total time: {minutes:02d}:{seconds:02d}')


if __name__ == '__main__':
    run_with_timer()
