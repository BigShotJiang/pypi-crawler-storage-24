# AWS Bedrock module
