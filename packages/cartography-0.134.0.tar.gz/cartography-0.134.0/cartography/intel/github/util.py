import base64
import json
import logging
import time
from datetime import datetime
from datetime import timedelta
from datetime import timezone as tz
from typing import Any
from typing import NamedTuple

import requests

logger = logging.getLogger(__name__)
# Connect and read timeouts of 60 seconds each; see https://requests.readthedocs.io/en/master/user/advanced/#timeouts
_TIMEOUT = (60, 60)


def _resolve_token(token: Any) -> str:
    """Resolve a token string or GitHubCredential to a plain token string."""
    if isinstance(token, str):
        return token
    result: str = token.get_token()
    return result


_GRAPHQL_RATE_LIMIT_REMAINING_THRESHOLD = 500
_REST_RATE_LIMIT_REMAINING_THRESHOLD = 100
# Search API has a stricter rate limit (30 requests/minute for authenticated users)
_SEARCH_RATE_LIMIT_REMAINING_THRESHOLD = 5


class PaginatedGraphqlData(NamedTuple):
    nodes: list[dict[str, Any]]
    edges: list[dict[str, Any]]


def _extract_error_message(response: requests.Response) -> str:
    """Extract a readable error message from a GitHub API response."""
    try:
        payload = response.json()
    except ValueError:
        return response.text

    if isinstance(payload, dict):
        message = payload.get("message")
        if isinstance(message, str):
            return message
        errors = payload.get("errors")
        if isinstance(errors, list):
            parts = []
            for error in errors:
                if isinstance(error, dict):
                    error_message = error.get("message")
                    if isinstance(error_message, str):
                        parts.append(error_message)
            if parts:
                return "; ".join(parts)
    return response.text


def _get_rate_limit_reset_sleep_seconds(response: requests.Response) -> int | None:
    """Return seconds to sleep until the primary rate limit resets, if available."""
    remaining = response.headers.get("x-ratelimit-remaining")
    reset = response.headers.get("x-ratelimit-reset")
    if remaining != "0" or not reset:
        return None

    try:
        reset_at = datetime.fromtimestamp(int(reset), tz=tz.utc)
    except ValueError:
        return None

    now = datetime.now(tz.utc)
    sleep_duration = reset_at - now + timedelta(minutes=1)
    return max(0, int(sleep_duration.total_seconds()))


def _get_retry_sleep_seconds_for_http_error(
    err: requests.exceptions.HTTPError,
    retry: int,
) -> int:
    """
    Return a retry delay for HTTP errors, honoring GitHub rate-limit guidance for 403/429.
    """
    response = err.response
    default_sleep_seconds: int = int(2**retry)
    if response is None:
        return int(default_sleep_seconds)

    if response.status_code not in (403, 429):
        return int(default_sleep_seconds)

    retry_after = response.headers.get("retry-after")
    if retry_after:
        try:
            return max(0, int(retry_after))
        except ValueError:
            pass

    reset_sleep_seconds = _get_rate_limit_reset_sleep_seconds(response)
    if reset_sleep_seconds is not None:
        return reset_sleep_seconds

    message = _extract_error_message(response).lower()
    if "secondary rate limit" in message or "abuse detection" in message:
        # GitHub recommends waiting at least one minute before retrying.
        return int(max(60, default_sleep_seconds))

    return int(default_sleep_seconds)


def handle_rate_limit_sleep(token: str) -> None:
    """
    Check the remaining rate limit and sleep if remaining is below threshold
    :param token: The Github API token as string.
    """
    response = requests.get(
        "https://api.github.com/rate_limit",
        headers={"Authorization": f"Bearer {_resolve_token(token)}"},
    )
    response.raise_for_status()
    response_json = response.json()
    rate_limit_obj = response_json["resources"]["graphql"]
    remaining = rate_limit_obj["remaining"]
    threshold = _GRAPHQL_RATE_LIMIT_REMAINING_THRESHOLD
    if remaining > threshold:
        return
    reset_at = datetime.fromtimestamp(rate_limit_obj["reset"], tz=tz.utc)
    now = datetime.now(tz.utc)
    # add an extra minute for safety
    sleep_duration = reset_at - now + timedelta(minutes=1)
    logger.warning(
        f"Github graphql ratelimit has {remaining} remaining and is under threshold {threshold},"
        f" sleeping until reset at {reset_at} for {sleep_duration}",
    )
    time.sleep(sleep_duration.total_seconds())


def call_github_api(query: str, variables: str, token: str, api_url: str) -> dict:
    """
    Calls the GitHub v4 API and executes a query
    :param query: the GraphQL query to run
    :param variables: parameters for the query
    :param token: the Oauth token for the API
    :param api_url: the URL to call for the API
    :return: query results json
    """
    headers = {"Authorization": f"Bearer {_resolve_token(token)}"}
    try:
        response = requests.post(
            api_url,
            json={"query": query, "variables": variables},
            headers=headers,
            timeout=_TIMEOUT,
        )
    except requests.exceptions.Timeout:
        # Add context and re-raise for callers to handle
        logger.warning("GitHub: requests.get('%s') timed out.", api_url)
        raise
    response.raise_for_status()
    response_json = response.json()
    if "errors" in response_json:
        logger.warning(
            f'call_github_api() response has errors, please investigate. Raw response: {response_json["errors"]}; '
            f"continuing sync.",
        )
    return response_json  # type: ignore


def fetch_page(
    token: str,
    api_url: str,
    organization: str,
    query: str,
    cursor: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Return a single page of max size 100 elements from the Github api_url using the given `query` and `cursor` params.
    :param token: The API token as string. Must have permission for the object being paginated.
    :param api_url: The Github API endpoint as string.
    :param organization: The name of the target Github organization as string.
    :param query: The GraphQL query, e.g. `GITHUB_ORG_USERS_PAGINATED_GRAPHQL`
    :param cursor: The GraphQL cursor string (behaves like a page number) for Github objects in the given
    organization. If None, the Github API will return the first page of repos.
    :param kwargs: Other keyword args to add as key-value pairs to the GraphQL query.
    :return: The raw response object from the requests.get().json() call.
    """
    gql_vars = {
        **kwargs,
        "login": organization,
        "cursor": cursor,
    }
    gql_vars_json = json.dumps(gql_vars)
    response = call_github_api(query, gql_vars_json, token, api_url)
    return response


def fetch_all(
    token: str,
    api_url: str,
    organization: str,
    query: str,
    resource_type: str,
    retries: int = 5,
    resource_inner_type: str | None = None,
    **kwargs: Any,
) -> tuple[PaginatedGraphqlData, dict[str, Any]]:
    """
    Fetch and return all data items of the given `resource_type` and `field_name` from Github's paginated GraphQL API as
    a list, along with information on the organization that they belong to.
    :param token: The Github API token as string.
    :param api_url: The Github v4 API endpoint as string.
    :param organization: The name of the target Github organization as string.
    :param query: The GraphQL query, e.g. `GITHUB_ORG_USERS_PAGINATED_GRAPHQL`
    :param resource_type: The name of the paginated resource under the organization e.g. `membersWithRole` or
    `repositories`. See the fields under https://docs.github.com/en/graphql/reference/objects#organization for a full
    list.
    :param retries: Number of retries to perform.  Github APIs are often flakey and retrying the request helps.
    :param resource_inner_type: Optional str. Default = None. Sometimes we need to paginate a field that is inside
    `resource_type` - for example: organization['team']['repositories']. In this case, we specify 'repositories' as the
    `resource_inner_type`.
    :param kwargs: Additional key-value args (other than `login` and `cursor`) to pass to the GraphQL query variables.
    :return: A 2-tuple containing 1. A list of data items of the given `resource_type` and `field_name`,  and 2. a dict
    containing the `url` and the `login` fields of the organization that the items belong to.
    """
    cursor = None
    has_next_page = True
    org_data: dict[str, Any] = {}
    data: PaginatedGraphqlData = PaginatedGraphqlData(nodes=[], edges=[])
    retry = 0
    null_resource_retry = 0

    while has_next_page:
        exc: Any = None
        try:
            # In the future, we may use also use the rateLimit object from the graphql response.
            # But we still need at least one call to the REST endpoint in case the graphql remaining is already 0
            handle_rate_limit_sleep(token)
            resp = fetch_page(token, api_url, organization, query, cursor, **kwargs)
            retry = 0
        except requests.exceptions.Timeout as err:
            retry += 1
            exc = err
        except requests.exceptions.HTTPError as err:
            if (
                err.response is not None
                and err.response.status_code == 502
                and kwargs.get("count")
                and kwargs["count"] > 1
            ):
                kwargs["count"] = max(1, kwargs["count"] // 2)
                logger.warning(
                    "GitHub: Received 502 response. Reducing page size to %s and retrying.",
                    kwargs["count"],
                )
                continue
            retry += 1
            exc = err
        except requests.exceptions.ChunkedEncodingError as err:
            retry += 1
            exc = err
        except requests.exceptions.ConnectionError as err:
            retry += 1
            exc = err

        if retry >= retries:
            logger.error(
                f"GitHub: Could not retrieve page of resource `{resource_type}` due to HTTP error "
                f"after {retry} retries. Raising exception.",
                exc_info=True,
            )
            raise exc
        elif retry > 0:
            sleep_seconds = 2**retry
            if isinstance(exc, requests.exceptions.HTTPError):
                sleep_seconds = _get_retry_sleep_seconds_for_http_error(exc, retry)
                response = exc.response
                status_code = (
                    response.status_code if response is not None else "unknown"
                )
                message = (
                    _extract_error_message(response)
                    if response is not None
                    else str(exc)
                )
                logger.warning(
                    "GitHub: HTTP %s while retrieving resource `%s` for org `%s`; retry %d/%d in %s seconds. Message: %s",
                    status_code,
                    resource_type,
                    organization,
                    retry,
                    retries,
                    sleep_seconds,
                    message,
                )
            time.sleep(sleep_seconds)
            continue

        if "data" not in resp:
            logger.warning(
                f'Got no "data" attribute in response: {resp}. '
                f"Stopping requests for organization: {organization} and "
                f"resource_type: {resource_type}",
            )
            has_next_page = False
            continue

        resource = resp["data"]["organization"][resource_type]
        if resource_inner_type:
            resource = resp["data"]["organization"][resource_type][resource_inner_type]

        if resource is None:
            null_resource_retry += 1
            if null_resource_retry >= retries:
                raise ValueError(
                    f"Got null resource for organization: {organization}, resource_type: {resource_type}, "
                    f"resource_inner_type: {resource_inner_type} after {null_resource_retry} retries. "
                    f"This may indicate a GitHub API timeout on a nested field.",
                )
            logger.warning(
                "Got null resource for organization: %s, resource_type: %s, resource_inner_type: %s. "
                "Retrying (%d/%d).",
                organization,
                resource_type,
                resource_inner_type,
                null_resource_retry,
                retries,
            )
            time.sleep(2**null_resource_retry)
            continue

        # Successful non-null resource; reset null-resource retry counter.
        null_resource_retry = 0

        # Allow for paginating both nodes and edges fields of the GitHub GQL structure.
        data.nodes.extend(resource.get("nodes", []))
        data.edges.extend(resource.get("edges", []))

        cursor = resource["pageInfo"]["endCursor"]
        has_next_page = resource["pageInfo"]["hasNextPage"]
        if not org_data:
            org_data = {
                "url": resp["data"]["organization"]["url"],
                "login": resp["data"]["organization"]["login"],
            }

    if not org_data:
        raise ValueError(
            f"Didn't get any organization data for organization: {organization} and resource_type: {resource_type}",
        )
    return data, org_data


def _get_rest_api_base_url(graphql_url: str) -> str:
    """
    Convert a GitHub GraphQL API URL to a REST API base URL.

    For github.com: https://api.github.com/graphql -> https://api.github.com
    For GitHub Enterprise: https://github.example.com/api/graphql -> https://github.example.com/api/v3

    :param graphql_url: The GitHub GraphQL API URL
    :return: The REST API base URL
    """
    if "api.github.com" in graphql_url:
        return "https://api.github.com"
    # GitHub Enterprise URL format
    # e.g., https://github.example.com/api/graphql -> https://github.example.com/api/v3
    base = graphql_url.replace("/graphql", "").rstrip("/")
    if not base.endswith("/v3"):
        base = f"{base}/v3"
    return base


def handle_rest_rate_limit_sleep(token: str, base_url: str) -> None:
    """
    Check the remaining REST API rate limit and sleep if remaining is below threshold.

    :param token: The GitHub API token as string.
    :param base_url: The REST API base URL.
    """
    rate_limit_url = f"{base_url}/rate_limit"
    response = requests.get(
        rate_limit_url,
        headers={"Authorization": f"Bearer {_resolve_token(token)}"},
        timeout=_TIMEOUT,
    )
    response.raise_for_status()
    response_json = response.json()
    rate_limit_obj = response_json["resources"]["core"]
    remaining = rate_limit_obj["remaining"]
    threshold = _REST_RATE_LIMIT_REMAINING_THRESHOLD
    if remaining > threshold:
        return
    reset_at = datetime.fromtimestamp(rate_limit_obj["reset"], tz=tz.utc)
    now = datetime.now(tz.utc)
    sleep_duration = reset_at - now + timedelta(minutes=1)
    logger.warning(
        f"GitHub REST API rate limit has {remaining} remaining and is under threshold {threshold}, "
        f"sleeping until reset at {reset_at} for {sleep_duration}",
    )
    time.sleep(sleep_duration.total_seconds())


def fetch_all_rest_api_pages(
    token: str,
    base_url: str,
    endpoint: str,
    result_key: str,
    retries: int = 5,
) -> list[dict[str, Any]]:
    """
    Fetch all pages from a GitHub REST API endpoint using Link header pagination.

    :param token: The GitHub API token as string.
    :param base_url: The REST API base URL (e.g., https://api.github.com).
    :param endpoint: The API endpoint path (e.g., /repos/{owner}/{repo}/actions/workflows).
    :param result_key: The key in the response JSON that contains the list of results
                       (e.g., 'workflows', 'secrets', 'variables').
    :param retries: Number of retries to perform on transient errors.
    :return: A list of all items from all pages.
    """
    results: list[dict[str, Any]] = []
    url: str | None = f"{base_url}{endpoint}"
    retry = 0

    while url:
        # Resolve token each iteration so AppCredential can refresh expired tokens
        headers = {
            "Authorization": f"Bearer {_resolve_token(token)}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        exc: Any = None
        try:
            handle_rest_rate_limit_sleep(token, base_url)
            response = requests.get(url, headers=headers, timeout=_TIMEOUT)
            response.raise_for_status()
            retry = 0
        except requests.exceptions.Timeout as err:
            retry += 1
            exc = err
        except requests.exceptions.HTTPError as err:
            # Handle 404 gracefully - resource may not exist (e.g., no environments)
            if err.response is not None and err.response.status_code == 404:
                logger.debug(f"GitHub REST API: 404 for {url}, returning empty list")
                return []
            # Handle 403 gracefully
            if err.response is not None and err.response.status_code == 403:
                logger.warning(
                    f"GitHub REST API: 403 Forbidden for {url}. "
                    "This is likely due to insufficient permissions. "
                    "Skipping this resource and continuing.",
                )
                return []
            retry += 1
            exc = err
        except requests.exceptions.ChunkedEncodingError as err:
            retry += 1
            exc = err
        except requests.exceptions.ConnectionError as err:
            retry += 1
            exc = err

        if retry >= retries:
            logger.error(
                f"GitHub REST API: Could not retrieve {url} after {retry} retries. Raising exception.",
                exc_info=True,
            )
            raise exc
        elif retry > 0:
            time.sleep(2**retry)
            continue

        response_json = response.json()

        # Some endpoints return a list directly, others wrap in an object
        if isinstance(response_json, list):
            results.extend(response_json)
        elif result_key in response_json:
            results.extend(response_json[result_key])
        else:
            logger.warning(
                f"GitHub REST API: Expected key '{result_key}' not found in response from {url}",
            )

        # Parse Link header for pagination
        url = None
        link_header = response.headers.get("Link", "")
        if link_header:
            for link in link_header.split(","):
                if 'rel="next"' in link:
                    # Extract URL from <url>; rel="next"
                    url = link.split(";")[0].strip().strip("<>")
                    break

    return results


def call_github_rest_api(
    endpoint: str,
    token: str,
    api_url: str = "https://api.github.com",
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Calls the GitHub REST API and returns the JSON response.

    :param endpoint: The REST API endpoint path (e.g., "/search/code", "/repos/owner/repo/contents/path")
    :param token: The OAuth token for authentication
    :param api_url: The GitHub API URL (GraphQL or REST base URL - will be converted as needed)
    :param params: Optional query parameters for the request
    :return: The JSON response as a dictionary
    :raises requests.exceptions.HTTPError: If the request fails
    """
    # Use the helper to get correct REST API base URL (handles GitHub Enterprise correctly)
    base_url = (
        _get_rest_api_base_url(api_url)
        if api_url.endswith("/graphql")
        else api_url.rstrip("/")
    )

    headers = {
        "Authorization": f"Bearer {_resolve_token(token)}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    url = f"{base_url}{endpoint}"

    try:
        response = requests.get(url, headers=headers, params=params, timeout=_TIMEOUT)
    except requests.exceptions.Timeout:
        logger.warning("GitHub REST API: requests.get('%s') timed out.", url)
        raise

    # Handle rate limiting for Search API
    if "X-RateLimit-Remaining" in response.headers:
        remaining = int(response.headers["X-RateLimit-Remaining"])
        # Check if this is a search endpoint (stricter limits)
        is_search = "/search/" in endpoint
        threshold = (
            _SEARCH_RATE_LIMIT_REMAINING_THRESHOLD
            if is_search
            else _REST_RATE_LIMIT_REMAINING_THRESHOLD
        )

        if remaining < threshold:
            reset_timestamp = int(response.headers.get("X-RateLimit-Reset", 0))
            if reset_timestamp:
                reset_at = datetime.fromtimestamp(reset_timestamp, tz=tz.utc)
                now = datetime.now(tz.utc)
                sleep_duration = reset_at - now + timedelta(seconds=10)  # Add buffer
                if sleep_duration.total_seconds() > 0:
                    logger.warning(
                        f"GitHub REST API rate limit has {remaining} remaining (threshold: {threshold}), "
                        f"sleeping until reset at {reset_at} for {sleep_duration}",
                    )
                    time.sleep(sleep_duration.total_seconds())

    response.raise_for_status()
    result: dict[str, Any] = response.json()
    return result


def get_file_content(
    token: str,
    owner: str,
    repo: str,
    path: str,
    ref: str = "HEAD",
    base_url: str = "https://api.github.com",
) -> str | None:
    """
    Download the content of a file from a GitHub repository using the Contents API.

    :param token: The GitHub API token
    :param owner: The repository owner
    :param repo: The repository name
    :param path: The path to the file within the repository
    :param ref: The git reference (branch, tag, or commit SHA) to get the file from
    :param base_url: The base URL for the GitHub API
    :return: The file content as a string, or None if retrieval fails
    """
    endpoint = f"/repos/{owner}/{repo}/contents/{path}"
    params: dict[str, Any] = {"ref": ref}

    try:
        response = call_github_rest_api(endpoint, token, base_url, params)

        # The content is base64 encoded
        if response.get("encoding") == "base64":
            content_b64 = response.get("content", "")
            # GitHub returns content with newlines for readability, remove them
            content_b64 = content_b64.replace("\n", "")
            content = base64.b64decode(content_b64).decode("utf-8")
            return content

        # If not base64 encoded, try to get raw content
        return response.get("content")

    except requests.exceptions.HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            logger.debug("File not found: %s/%s/%s", owner, repo, path)
            return None
        raise
