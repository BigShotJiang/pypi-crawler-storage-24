import pytest

from openbias.config.settings import Settings, YamlConfigSource


def test_obias_config_env_var_discovery(monkeypatch):
    """Verify that OBIAS_CONFIG is still used to find the config file path."""
    # This is handled manually in YamlConfigSource, so it should still work
    monkeypatch.setenv("OBIAS_CONFIG", "/tmp/nonexistent.yaml")

    settings = Settings()
    # It won't fail to initialize, but YamlConfigSource will have attempted to load it
    # We can check its internal state or just ensure no other OBIAS_ vars are picked up

    monkeypatch.setenv("OBIAS_DEBUG", "true")
    settings = Settings()
    assert settings.debug is True  # OBIAS_ prefix maps to settings fields


def test_standard_api_keys_work(monkeypatch):
    """Verify that standard API keys are still picked up without OBIAS_ prefix."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-123")
    settings = Settings()
    assert settings.openai_api_key == "sk-test-123"


class TestInlinePolicyMapping:
    """Tests for inline policy handling in YamlConfigSource._map_to_settings()."""

    def _build_source(self, yaml_data):
        """Create a YamlConfigSource with injected YAML data."""
        source = YamlConfigSource.__new__(YamlConfigSource)
        source._yaml_data = yaml_data
        source._config_file = None
        return source

    def test_policy_list_maps_to_inline_policy(self):
        """A list of rules should map to policy.engine.config.inline_policy."""
        source = self._build_source({
            "engine": "judge",
            "policy": ["No PII", "Be helpful"],
        })
        result = source._map_to_settings()
        assert result["policy"]["engine"]["config"]["inline_policy"] == ["No PII", "Be helpful"]
        assert "config_path" not in result["policy"]["engine"]

    def test_policy_dict_maps_to_inline_policy(self):
        """A dict policy should map to policy.engine.config.inline_policy."""
        source = self._build_source({
            "engine": "judge",
            "policy": {"rules": ["No PII"]},
        })
        result = source._map_to_settings()
        assert result["policy"]["engine"]["config"]["inline_policy"] == {"rules": ["No PII"]}

    def test_policy_string_maps_to_config_path(self):
        """A string policy should still map to config_path (backward compat)."""
        source = self._build_source({
            "engine": "judge",
            "policy": "./policy.yaml",
        })
        result = source._map_to_settings()
        assert result["policy"]["engine"]["config_path"] == "./policy.yaml"
        assert "config" not in result["policy"]["engine"] or \
               "inline_policy" not in result["policy"]["engine"].get("config", {})


class TestInterventionDefaults:

    def test_default_strategy_is_user_message_inject(self):
        """PolicyConfig defaults to user_message_inject strategy."""
        settings = Settings()
        assert settings.policy.default_strategy == "user_message_inject"


class TestGetPolicyConfig:
    """Tests for Settings.get_policy_config() model injection."""

    def test_injects_models_from_global_default_model(self):
        """When judge engine has no explicit model, inject from proxy.default_model."""
        settings = Settings()
        settings.proxy.default_model = "gpt-4o"
        settings.policy.engine.type = "judge"
        settings.policy.engine.config = {}

        result = settings.get_policy_config()
        assert result["config"]["models"] == [
            {"name": "primary", "model": "gpt-4o"}
        ]

    def test_no_injection_when_models_already_set(self):
        """When judge engine already has models, don't override."""
        settings = Settings()
        settings.proxy.default_model = "gpt-4o"
        settings.policy.engine.type = "judge"
        settings.policy.engine.config = {
            "models": [{"name": "primary", "model": "claude-sonnet-4-6"}]
        }

        result = settings.get_policy_config()
        assert result["config"]["models"] == [
            {"name": "primary", "model": "claude-sonnet-4-6"}
        ]

    def test_no_injection_for_non_judge_engine(self):
        """Non-judge engines should not get models injected."""
        settings = Settings()
        settings.proxy.default_model = "gpt-4o"
        settings.policy.engine.type = "fsm"
        settings.policy.engine.config = {}

        result = settings.get_policy_config()
        assert "models" not in result["config"]

    def test_no_injection_when_no_default_model(self):
        """When there's no global default_model, don't inject."""
        settings = Settings()
        settings.proxy.default_model = None
        settings.policy.engine.type = "judge"
        settings.policy.engine.config = {}

        result = settings.get_policy_config()
        assert "models" not in result["config"]


class TestFailAction:
    """Tests for fail_action configuration."""

    def _build_source(self, yaml_data):
        source = YamlConfigSource.__new__(YamlConfigSource)
        source._yaml_data = yaml_data
        source._config_file = None
        return source

    def test_default_fail_action_is_intervene(self):
        """PolicyConfig defaults to fail_action='intervene'."""
        settings = Settings()
        assert settings.policy.fail_action == "intervene"

    def test_fail_action_maps_from_yaml(self):
        """Top-level fail_action in YAML maps to policy.fail_action."""
        source = self._build_source({"fail_action": "block"})
        result = source._map_to_settings()
        assert result["policy"]["fail_action"] == "block"

    def test_fail_action_intervene_maps_from_yaml(self):
        """fail_action: intervene maps correctly."""
        source = self._build_source({"fail_action": "intervene"})
        result = source._map_to_settings()
        assert result["policy"]["fail_action"] == "intervene"

    def test_fail_action_shadow_maps_from_yaml(self):
        """fail_action: shadow maps correctly."""
        source = self._build_source({"fail_action": "shadow"})
        result = source._map_to_settings()
        assert result["policy"]["fail_action"] == "shadow"


class TestFailOpen:
    """Tests for fail_open configuration mapping."""

    def _build_source(self, yaml_data):
        source = YamlConfigSource.__new__(YamlConfigSource)
        source._yaml_data = yaml_data
        source._config_file = None
        return source

    def test_default_fail_open_is_true(self):
        """PolicyConfig defaults to fail_open=True."""
        settings = Settings()
        assert settings.policy.fail_open is True

    def test_fail_open_false_maps_from_yaml(self):
        """Top-level fail_open: false in YAML maps to policy.fail_open."""
        source = self._build_source({"fail_open": False})
        result = source._map_to_settings()
        assert result["policy"]["fail_open"] is False

    def test_fail_open_true_maps_from_yaml(self):
        """Top-level fail_open: true in YAML maps to policy.fail_open."""
        source = self._build_source({"fail_open": True})
        result = source._map_to_settings()
        assert result["policy"]["fail_open"] is True


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__]))

