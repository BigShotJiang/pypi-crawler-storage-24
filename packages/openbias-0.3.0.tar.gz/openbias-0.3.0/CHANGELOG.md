# Changelog

All notable changes to this project will be documented in this file.

Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## 0.3.0

### Breaking
- Renamed package from `opensentinel` to `openbias`
- Removed composite engine
- Removed reliability modes, ensemble, and multi-threshold from judge engine
- Rewrote FSM schema and compiler (deterministic pipeline, simplified constraints)
- Removed `mode` and `pass_threshold` config options

### Added
- Eval framework: `openbias eval` with per-engine scenario runners, metrics, and reporting
- Shadow `fail_action` mode — log violations without blocking
- Trace content redaction
- Session TTL, LRU eviction, and per-session async task caps
- Eager policy engine initialization at startup
- Tool call awareness in judge evaluations
- Session ID validation to prevent log/OTEL injection

### Fixed
- Dozens of correctness fixes across all engines (judge scoring, FSM transitions, LLM drift detection, NeMo rail activation)
- Interceptor race conditions, session lifecycle, and async result handling

## 0.2.0

### Added

- **`openbias init -q`**: Quick (non-interactive) init — auto-detects your API key and writes a minimal config in one shot.
- **CLI output formatting**: Rich-formatted console output for all CLI commands (headings, YAML previews, success/error indicators).
- **Model auto-detection**: Automatically resolves the best LLM model from whichever API key is present (`OPENAI_API_KEY` → `gpt-4o-mini`, `GEMINI_API_KEY` → `gemini/gemini-2.5-flash`, etc.).
- **Model & API-key validation**: `openbias serve` and `openbias init` now validate that the required API key exists for the configured model before starting.
- **YAML as single source of truth**: `openbias.yaml` is now the primary configuration surface. Removed the `OBIAS_*` environment-variable prefix; API keys are still read from env vars / `.env`.
- **Path resolution**: Relative paths in `openbias.yaml` (e.g. `policy: ./workflow.yaml`) are resolved relative to the config file location.
- **Config validation at startup**: `openbias serve` checks that referenced policy files exist and that the required API key is present; exits with a clear error if not.
- **API-key syncing**: Keys loaded from `.env` are synced into `os.environ` so downstream libraries (LiteLLM, LangChain) work without explicit `load_dotenv()`.
- **Langfuse env-var aliases**: `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, and `LANGFUSE_HOST` are read directly from the environment alongside YAML config.
- **Engine-specific `openbias compile`**: The policy compiler now accepts `--engine` to target a specific engine format (judge, fsm, llm, nemo).
- **`docs/configuration.md`**: Full configuration reference for `openbias.yaml`.

### Changed

- **Default engine** changed from `nemo` to `judge` — works out of the box with inline rules; no external config directory required.
- **Tracing disabled by default**: `tracing.enabled` now defaults to `false` and `exporter_type` defaults to `none` to avoid noisy OTLP connection errors on first run.
- **`proxy.default_model`** defaults to `None` instead of eagerly auto-detecting; the model is resolved at startup via YAML or auto-detection.
- **Intervention merge logic** refactored for consistency across FSM and LLM engines.
- **Policy compiler** refactored into per-engine modules (`fsm`, `llm`, `judge`, `nemo`).
- **Docs updated**: `developing.md`, `examples/README.md`, and `README.md` updated to reflect YAML-first configuration.

### Fixed

- Judge engine: score clamping, criterion failure checks, JSON validation, timezone-aware timestamps.
- Session ID propagation for internal LLM calls in the Judge engine.
- `intervention` and `classifier` YAML sections now correctly map to `Settings`.

## 0.1.0 (alpha)

Initial release.

### Added

- Transparent LLM proxy built on LiteLLM. Point any OpenAI-compatible client at it with a one-line `base_url` change.
- **Judge engine**: scores responses against plain-English rubrics using a sidecar LLM. Binary pass/fail evaluation with configurable fail action. Async by default -- zero latency on the critical path.
- **FSM engine**: enforces agent behavior as a finite state machine. Three-tier classification cascade (tool call matching, regex, embedding similarity). LTL-lite temporal constraint evaluation.
- **LLM engine**: classifies conversation state and detects drift using LLM-based reasoning.
- **NeMo engine**: integrates NVIDIA NeMo Guardrails for content safety and dialog rails.
- **Composite engine**: runs multiple engines in parallel, merges results (most restrictive wins).
- **Policy compiler**: translates natural language policies to engine-specific YAML via `openbias compile`.
- **CLI**: `openbias init`, `openbias serve`, `openbias compile`, `openbias validate`, `openbias info`.
- **OpenTelemetry tracing**: spans for every proxy call, policy evaluation, and intervention. Console, OTLP, and Langfuse backends.
- Fail-open design: hook failures pass the request through unmodified. Only intentional blocks propagate.
- Deferred intervention: violations detected async are applied as prompt injections on the next turn.
- Session ID extraction from headers, query params, or request body.

### Known Limitations

- Session state is in-memory only. Not persistent across restarts.
- No dashboard UI.
- No pre-built policy library.
- No rate limiting.
