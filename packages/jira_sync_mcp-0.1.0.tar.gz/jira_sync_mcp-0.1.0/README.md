# jira-sync-mcp

MCP server for [Jira Sync App](https://github.com/twoja-org/jira-sync-app) — exposes Jira issues from a local PostgreSQL mirror as MCP tools for Claude Code and other MCP clients.

## Requirements

- A running instance of Jira Sync App (FastAPI backend)
- An API token generated in **Admin → API Tokens**

## Installation and usage

```bash
# Run directly via uvx (no installation needed)
uvx jira-sync-mcp

# Or install globally
pip install jira-sync-mcp
jira-sync-mcp
```

## Configuration in Claude Code

Add to `~/.claude.json`:

```json
{
  "mcpServers": {
    "jira-sync": {
      "command": "uvx",
      "args": ["jira-sync-mcp"],
      "env": {
        "JIRA_SYNC_URL": "http://your-server:8000",
        "JIRA_SYNC_API_TOKEN": "<token from Admin → API Tokens>"
      }
    }
  }
}
```

Claude Code starts and stops the MCP process automatically — no manual startup required. The only service that must be running is the FastAPI backend.

## Available tools

| Tool | Description |
|---|---|
| `get_issue` | Fetch full issue data (links, worklogs, comments, changelog) |
| `search_issues` | Search issues with filters (project, status, assignee, sprint, fix_version…) |
| `get_projects` | List projects available in the app |
| `get_sync_status` | History of the last 20 Jira synchronisations |

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `JIRA_SYNC_URL` | `http://localhost:8000` | Jira Sync App backend URL |
| `JIRA_SYNC_API_TOKEN` | *(required)* | API token from Admin → API Tokens |
