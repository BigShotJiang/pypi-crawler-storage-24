"""Klient HTTP do komunikacji z Jira Sync API.

Konfiguracja przez zmienne środowiskowe:
  JIRA_SYNC_URL        — bazowy URL backendu, np. http://serwer:8000
  JIRA_SYNC_API_TOKEN  — token API (Bearer) wygenerowany w panelu admin
"""

import os
import httpx

_BASE_URL = os.environ.get("JIRA_SYNC_URL", "http://localhost:8000").rstrip("/")
_API_TOKEN = os.environ.get("JIRA_SYNC_API_TOKEN", "")

_HEADERS = {
    "Authorization": f"Bearer {_API_TOKEN}",
    "Content-Type": "application/json",
}


def get(path: str, params: dict | None = None) -> dict | list:
    """Wykonuje GET request do API i zwraca sparsowany JSON.

    Raises:
        httpx.HTTPStatusError: gdy serwer zwróci błąd HTTP.
        RuntimeError: gdy brak konfiguracji tokenu.
    """
    if not _API_TOKEN:
        raise RuntimeError(
            "Brak JIRA_SYNC_API_TOKEN. Ustaw zmienną środowiskową z tokenem API "
            "wygenerowanym w panelu Admin → API Tokens."
        )
    url = f"{_BASE_URL}{path}"
    with httpx.Client(timeout=30.0) as client:
        response = client.get(url, headers=_HEADERS, params=params)
        response.raise_for_status()
        return response.json()
