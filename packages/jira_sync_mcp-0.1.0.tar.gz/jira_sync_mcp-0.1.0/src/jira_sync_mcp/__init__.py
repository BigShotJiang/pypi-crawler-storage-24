"""jira-sync-mcp — MCP server for Jira Sync App."""

import sys

__version__ = "0.1.0"


def main() -> None:
    """Punkt wejścia pakietu — uruchamia serwer MCP w trybie STDIO."""
    # Fix dla Windows: ProactorEventLoop zamiast domyślnego SelectorEventLoop
    if sys.platform == "win32":
        import asyncio
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    from jira_sync_mcp.server import mcp
    mcp.run()
