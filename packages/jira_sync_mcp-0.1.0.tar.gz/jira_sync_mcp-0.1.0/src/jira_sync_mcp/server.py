"""Definicja serwera MCP i rejestracja narzędzi."""

from fastmcp import FastMCP
from jira_sync_mcp.tools.issues import get_issue, search_issues
from jira_sync_mcp.tools.sync import get_projects, get_sync_status

mcp = FastMCP(
    name="jira-sync",
    instructions=(
        "Serwer MCP do pracy z danymi Jiry zsynchronizowanymi do lokalnej bazy PostgreSQL. "
        "Zwraca surowe dane — status, priorytety, assignee, powiązania, worklogi, komentarze i changelog. "
        "Używaj search_issues do filtrowania, get_issue do szczegółów konkretnego zgłoszenia."
    ),
)

mcp.tool()(get_issue)
mcp.tool()(search_issues)
mcp.tool()(get_projects)
mcp.tool()(get_sync_status)
