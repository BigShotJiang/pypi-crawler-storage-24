"""Narzędzia MCP dla synchronizacji — lista projektów i status synchrnonizacji."""

from jira_sync_mcp import client


def get_projects() -> list:
    """Zwraca listę projektów Jiry dostępnych w aplikacji.

    Każdy projekt zawiera: id (klucz), name, is_active, last_synced_at.
    """
    return client.get("/sync/projects")


def get_sync_status() -> list:
    """Zwraca historię ostatnich 20 synchronizacji z Jirą.

    Każdy wpis zawiera: id, project_id, status (success/error/running),
    sync_type (full/incremental/missing), issues_synced, started_at, finished_at,
    error_message (jeśli błąd).
    """
    return client.get("/sync/status")
