"""Narzędzia MCP dla issues — pobieranie i wyszukiwanie zgłoszeń Jiry."""

from jira_sync_mcp import client


def get_issue(issue_id: str) -> dict:
    """Pobiera pełne dane zgłoszenia Jiry z lokalnej bazy.

    Zwraca: id, summary, description, typ, status, priorytet, assignee, reporter,
    etykiety, wersje, daty, pola custom (sprint, profil, produkt, epic, PM),
    powiązania (issue_links), worklogi, changelog i komentarze.

    Args:
        issue_id: Klucz zgłoszenia, np. "PROJ-1234" lub "TEAM-567".
    """
    return client.get(f"/issues/{issue_id}")


def search_issues(
    project_id: str | None = None,
    status: str | None = None,
    assignee: str | None = None,
    issue_type: str | None = None,
    priority: str | None = None,
    fix_version: str | None = None,
    sprint: str | None = None,
    product: str | None = None,
    profile: str | None = None,
    linked_pm_key: str | None = None,
    epic_link: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    search: str | None = None,
    page: int = 1,
    page_size: int = 50,
) -> dict:
    """Wyszukuje zgłoszenia Jiry z opcjonalnymi filtrami.

    Zwraca paginowaną listę z polami: id, summary, typ, status, priorytet,
    assignee, reporter, etykiety, daty.

    Args:
        project_id:     Klucz projektu lub lista po przecinku, np. "PROJ" lub "PROJ,TEAM".
        status:         Status lub lista, np. "Open" lub "Open,In Progress".
        assignee:       Osoba przypisana (displayName) lub lista.
        issue_type:     Typ zgłoszenia, np. "Bug", "Story", "Task".
        priority:       Priorytet, np. "High", "Critical".
        fix_version:    Wersja w formacie YYYY_Rnn, np. "2025_R01".
        sprint:         Sprint w formacie YYYY_Snn, np. "2025_S01".
        product:        Produkt, np. "product-a", "product-b".
        profile:        Profil zespołu, np. "team-profile".
        linked_pm_key:  Klucz projektu PM, np. "PM-1234".
        epic_link:      Klucz epika, np. "PROJ-100".
        date_from:      Data utworzenia od (YYYY-MM-DD).
        date_to:        Data utworzenia do (YYYY-MM-DD).
        search:         Szukaj w id i summary (ILIKE).
        page:           Numer strony (od 1).
        page_size:      Rozmiar strony (1–200, domyślnie 50).
    """
    params = {k: v for k, v in {
        "project_id": project_id,
        "status": status,
        "assignee": assignee,
        "issue_type": issue_type,
        "priority": priority,
        "fix_version": fix_version,
        "sprint": sprint,
        "product": product,
        "profile": profile,
        "linked_pm_key": linked_pm_key,
        "epic_link": epic_link,
        "date_from": date_from,
        "date_to": date_to,
        "search": search,
        "page": page,
        "page_size": page_size,
    }.items() if v is not None}
    return client.get("/issues", params=params)
