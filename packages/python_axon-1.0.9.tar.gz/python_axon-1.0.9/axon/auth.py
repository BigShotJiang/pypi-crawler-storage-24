"""
axon.auth
=========
Authentication guards for protecting routes and route groups.

    from axon.auth import require_auth, require_role, optional_auth

Usage in routes:

    from axon import Router
    from axon.auth import require_auth, require_role

    router = Router(prefix="/orders")

    # Protect a whole group
    protected = router.group("", middleware=[require_auth])
    admin     = router.group("/admin", middleware=[require_role("admin")])

    # Protect a single route
    @router.delete("/{id}", middleware=[require_auth])
    async def destroy(id: int, ctx): ...
"""
from axon.core.auth.guards import (  # noqa: F401
    require_auth,
    optional_auth,
    require_role,
)

from axon.core.auth.services import UserService,TokenService
from axon.core.auth.models import User,PersonalAccessToken

__all__ = ["require_auth", "optional_auth", "require_role","UserService","TokenService","User",PersonalAccessToken]
