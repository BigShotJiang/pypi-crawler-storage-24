"""
Axon Framework
==============
A modular Python backend framework built on FastAPI.

    pip install axon-framework
    axon create_project myapp

Full import surface — everything a module builder needs:

    from axon import Module, Service, Model, Router, Manifest, Context, Log
    from axon import bind, make, override, extend, env, config
    from axon.fields import StringField, BoolField, IntField, ...
    from axon.auth import require_auth, require_role, optional_auth
"""
from __future__ import annotations

__version__ = "1.0.0"
__all__ = [
    # Core classes
    "AxonModule", "AxonService", "AxonModel", "Router", "Context", "Manifest", "Log","VendorProvider",

]

# ── Core classes ──────────────────────────────────────────────────────────────
# Clean public aliases — Module, Service, Model instead of BaseModule, BaseService, AppModel

from axon.core.module.base_module  import BaseModule  as AxonModule   # noqa: F401
from axon.core.module.base_service import BaseService as AxonService  # noqa: F401
from axon.core.db.app_model        import AppModel    as AxonModel    # noqa: F401
from axon.core.routing.router      import Router, Context         # noqa: F401
from axon.core.module.manifest     import Manifest                # noqa: F401
from axon.core.logging.log         import Log                     # noqa: F401
from axon.core.module.vendor_provider import VendorProvider       # noqa: F401

