# kit/cli/adaptive_trainer.py
# v1.2.4 - Statistical Weight Correction Engine

import json
from pathlib import Path
from collections import defaultdict

TELEMETRY_PATH = Path.home() / ".kit" / "routing_telemetry.jsonl"

def run_trainer():
    if not TELEMETRY_PATH.exists():
        print("No telemetry found. Start dogfooding first.")
        return

    print("🚀 v1.2.4 Adaptive Scorer Trainer Initialized")
    
    stats = defaultdict(int)
    feedback_count = 0
    corrections = []

    with open(TELEMETRY_PATH, "r", encoding="utf-8") as f:
        for line in f:
            try:
                data = json.loads(line)
                if data.get("status") == "OK":
                    stats[data["route"]] += 1
                elif data.get("type") == "FEEDBACK":
                    feedback_count += 1
                    corrections.append(data)
            except Exception:
                continue

    print("-" * 30)
    print(f"Stats: GLOBAL={stats['GLOBAL']}, LOCAL={stats['LOCAL']}")
    print(f"Feedback entries: {feedback_count}")
    
    if feedback_count == 0:
        print("\n[ADVICE] System behavior is consistent. No weighting changes suggested yet.")
        return

    # Logic for weight delta calculation based on correction patterns
    # (In v1.2.4 this will propose changes to GLOBAL_KW/LOCAL_KW weights)
    print("\n[v1.2.4 PROPOSAL]")
    for c in corrections:
        print(f"  - Correction: Obs {c['obs_id']} should be {c['correct_label']}")
    
    print("\nRecommendation: Dogfood more data to reach statistical significance (min 50 feedbacks).")

if __name__ == "__main__":
    run_trainer()
