import re
import sys
from dataclasses import dataclass, field

from kit.core.kit_cognitive_core import Memory, SAMBrain

# Standard library modules to ignore in gap detection
STDLIB_MODULES = set(sys.builtin_module_names) | {
    "os",
    "sys",
    "time",
    "datetime",
    "pathlib",
    "re",
    "json",
    "sqlite3",
    "subprocess",
    "shutil",
    "argparse",
    "logging",
    "typing",
    "collections",
    "math",
    "random",
    "hashlib",
    "threading",
    "asyncio",
    "abc",
    "dataclasses",
    "inspect",
    "importlib",
    "functools",
    "itertools",
    "enum",
    "tempfile",
}

SUGGESTION_TEMPLATES = {
    "GAP": "Consider documenting this signal: `kit learn --uid {signal} --content '...'`",
    "BLOCK": "Architectural Invariant violation! Conflicting ID: {id}. Use `kit learn --supersede {id}` to propose an override.",
    "WARN": "Ambiguous conflict detected Between {count} design choices. Critical margin: {margin:.4f}.",
    "DRIFT": "Local pattern differs from global intent. Resolve at {scope}.",
}


@dataclass
class Resolution:
    winner_id: int | None = None
    winner_content: str = ""
    reason: str = ""
    is_violation: bool = False
    confidence: float = 0.0
    overridden: list[int] = field(default_factory=lambda: [])


@dataclass
class ReflectReport:
    score: float = 1.0
    status: str = "PASS"
    gaps: list[str] = field(default_factory=lambda: [])
    drifts: list[str] = field(default_factory=lambda: [])
    violations: list[str] = field(default_factory=lambda: [])
    confirmations: list[str] = field(default_factory=lambda: [])
    suggestions: list[str] = field(default_factory=lambda: [])
    resolutions: dict[str, Resolution] = field(default_factory=lambda: {})


# Low-level signal patterns: Focusing on imports and dependencies (Infra-grade)
IMPORT_PATTERNS = [
    r"^\s*import\s+([\w\.]+)",
    r"^\s*from\s+([\w\.]+)\s+import",
    r'require\(["\']([\w\.-]+)["\']\)',
    r"use\s+([\w:]+);",  # Rust
    r"extern\s+crate\s+([\w]+)",  # Rust
]


def extract_signals(diff_text: str) -> list[str]:
    """
    Extract architectural signals (imports/dependencies) from a diff.
    Limited to 50 signals to maintain < 50ms performance.
    """
    signals: set[str] = set()
    lines = diff_text.splitlines()

    # We only care about added lines (+) or the first 500 lines of a full file
    # For now, let's assume it's a diff or a snippet.
    for line in lines:
        if line.startswith("-"):
            continue
        clean_line = line.lstrip("+").strip()

        for pattern in IMPORT_PATTERNS:
            match = re.search(pattern, clean_line)
            if match:
                # Get root module, handling both Python '.' and Rust '::'
                raw_signal = match.group(1)
                signal = re.split(r"[\.::]+", raw_signal)[0]
                if signal not in STDLIB_MODULES:
                    signals.add(signal)

        if len(signals) >= 50:
            break

    return sorted(list(signals))


def calculate_adaptive_score(m: Memory, current_scope: str) -> float:
    """
    AMSB v1.1: Calculate pure 'Relevance' score (ignoring tag authority).
    Relevance = base_materialized_score + scope_bonus
    """
    brainless_scope = current_scope or ""
    score = m.materialized_score
    if m.scope == brainless_scope:
        score += 0.2
    elif brainless_scope and m.scope and brainless_scope.startswith(m.scope):
        score += 0.15
    elif m.scope in ["", "global", None]:
        score += 0.1
    return score


def resolve_cognitive_conflict(memories: list[Memory], current_scope: str, signal: str) -> Resolution:
    """
    The Supreme Court: Deterministic conflict arbitration.
    Ensures Invariant sanctity and explainable scoped refinements.
    """
    if not memories:
        return Resolution(reason=f"GAP: '{signal}' not in memory.", confidence=0.0)

    # 1. Filter and Sort Invariants specifically to guard the hierarchy
    invariants = sorted(
        [m for m in memories if m.tag == "invariant"],
        key=lambda m: calculate_adaptive_score(m, current_scope),
        reverse=True,
    )

    # 2. Additive Rank all memories
    ranked = sorted(memories, key=lambda m: calculate_adaptive_score(m, current_scope), reverse=True)

    if not ranked:
        return Resolution(reason="No memories found.", confidence=0.0)

    winner = ranked[0]
    losers = ranked[1:]
    winner_score = calculate_adaptive_score(winner, current_scope)

    # 3. Calculate Confidence based on margin
    margin = 0.0
    if losers:
        margin = winner_score - calculate_adaptive_score(losers[0], current_scope)
        # Multi-factor confidence: penalize if many options exist
        conf_penalty = 1.0 / (1.0 + 0.1 * len(losers))  # Slight penalty for high diversity
        confidence = (margin / (abs(winner_score) + 1e-5)) * conf_penalty
    else:
        confidence = 1.0

    # 4. Constitutional Guardrail: Decision CANNOT override Invariant
    # Or multiple Invariants conflict
    if len(invariants) > 1:
        # Check if they are actually different content
        contents = {inv.content for inv in invariants}
        if len(contents) > 1:
            return Resolution(
                winner_id=invariants[0].id,
                winner_content=invariants[0].content,
                is_violation=True,
                reason="CONSTITUTIONAL CONFLICT: Multiple conflicting Invariants detected.",
                confidence=0.0,
                overridden=[inv.id for inv in invariants[1:]],
            )

    if winner.tag != "invariant" and invariants:
        inv = invariants[0]
        return Resolution(
            winner_id=inv.id,
            winner_content=inv.content,
            is_violation=True,
            reason=f"CONSTITUTIONAL VIOLATION: Scoped '{winner.tag}' cannot override Global Invariant.",
            confidence=1.0,
            overridden=[winner.id] + [loser.id for loser in losers if loser.id != inv.id],
        )

    # 5. Explainability & Suggestions
    reason = f"Winner chosen by adaptive score ({winner_score:.2f})."
    if losers:
        reason += f" Overrides {len(losers)} weaker/broader rule(s)."
        if winner.scope == current_scope and losers[0].scope != current_scope:
            reason += " (Reason: Scoped refinement wins)"

    return Resolution(
        winner_id=winner.id,
        winner_content=winner.content,
        reason=reason,
        is_violation=False,
        confidence=confidence,
        overridden=[loser.id for loser in losers],
    )


def run_reflect(brain: SAMBrain, diff_text: str, scope: str | None = None) -> ReflectReport:
    """
    Main reflection pipeline with Calibration (Consistency Engine v2).
    """
    report = ReflectReport()
    signals = extract_signals(diff_text)

    if not signals:
        return report

    current_scope = scope or brain.get_normalized_scope()
    processed_signals = signals[:20]

    for signal in processed_signals:
        memories = brain.recall([signal], limit=10, fast=True)

        # Arbitrate conflicts
        res = resolve_cognitive_conflict(memories, current_scope, signal)
        report.resolutions[signal] = res

        if res.is_violation:
            report.violations.append(signal)
            report.suggestions.append(SUGGESTION_TEMPLATES["BLOCK"].format(id=res.winner_id))
            continue

        if res.winner_id is None:
            report.gaps.append(signal)
            report.suggestions.append(SUGGESTION_TEMPLATES["GAP"].format(signal=signal))
            continue

        if memories:
            winner_memory = next((m for m in memories if m.id == res.winner_id), None)
            # Scope mismatch is treated as drift when the winning memory is scoped elsewhere
            # and does not represent a global/shared rule.
            if winner_memory and current_scope:
                winner_scope = winner_memory.scope or ""
                if (
                    winner_scope not in {"", "global"}
                    and winner_scope != current_scope
                    and not current_scope.startswith(winner_scope)
                ):
                    report.drifts.append(signal)
                    report.suggestions.append(SUGGESTION_TEMPLATES["DRIFT"].format(scope=current_scope))
                    continue

        if res.confidence < 0.3:  # Threshold for Ambiguity (v1.1)
            report.drifts.append(signal)
            report.suggestions.append(SUGGESTION_TEMPLATES["WARN"].format(count=len(memories), margin=res.confidence))
        else:
            report.confirmations.append(signal)

    # Calculate cognitive score (Deterministic Penalty Model)
    total = len(processed_signals)
    if total > 0:
        penalty = (len(report.gaps) * 0.1) + (len(report.drifts) * 0.2) + (len(report.violations) * 0.5)
        report.score = max(0.0, 1.0 - penalty)

    if report.violations:
        report.status = "BLOCK"
    elif report.score < 0.8:
        report.status = "WARN"
    else:
        report.status = "PASS"

    return report
