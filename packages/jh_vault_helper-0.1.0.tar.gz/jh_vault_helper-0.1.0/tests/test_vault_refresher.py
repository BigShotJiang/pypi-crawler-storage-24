from unittest.mock import call, patch

from jh_vault_helper.vault_refresher import VaultSecretRefresher


class FakeThread:
    def __init__(self, target=None, name=None, daemon=None):
        self.target = target
        self.name = name
        self.daemon = daemon
        self.started = False
        self.joined = False
        self.alive = False

    def start(self):
        self.started = True
        self.alive = True

    def is_alive(self):
        return self.alive

    def join(self, timeout=None):
        self.joined = True
        self.alive = False


def test_refresh_secrets_loads_environment_and_shared(monkeypatch):
    monkeypatch.setenv("VAULT_KV_MOUNT", "mentors")
    monkeypatch.setenv("APP_ENV", "staging")
    monkeypatch.setenv("VAULT_SHARED_MOUNT", "shared")
    monkeypatch.setenv("VAULT_SHARED_PATH", "services/common")

    refresher = VaultSecretRefresher(enabled=True, refresh_interval=300)

    with patch("jh_vault_helper.vault_refresher.load_env_from_vault", side_effect=[2, 1]) as mocked_load:
        refresher._refresh_secrets()

    assert mocked_load.call_args_list == [
        call(mount="mentors", secret_path="staging", override_existing=True),
        call(mount="shared", secret_path="services/common", override_existing=False),
    ]


def test_start_only_creates_one_thread_and_stop_joins(monkeypatch):
    created_threads = []

    def fake_thread_factory(*args, **kwargs):
        thread = FakeThread(*args, **kwargs)
        created_threads.append(thread)
        return thread

    with patch("jh_vault_helper.vault_refresher.threading.Thread", side_effect=fake_thread_factory):
        refresher = VaultSecretRefresher(enabled=True, refresh_interval=300)
        refresher.start()
        refresher.start()
        refresher.stop()

    assert len(created_threads) == 1
    assert created_threads[0].started is True
    assert created_threads[0].joined is True
