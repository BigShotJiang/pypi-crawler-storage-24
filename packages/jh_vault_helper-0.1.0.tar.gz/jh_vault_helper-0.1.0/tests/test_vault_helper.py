import os
from unittest.mock import Mock, patch

import pytest

from jh_vault_helper.vault_helper import VaultKVClient, load_env_from_vault, login_with_approle


def test_load_env_from_vault_loads_values_and_respects_override(monkeypatch):
    monkeypatch.setenv("VAULT_ADDR", "https://vault.example.com")
    monkeypatch.setenv("VAULT_TOKEN", "token")
    monkeypatch.setenv("VAULT_KV_MOUNT", "mentors")
    monkeypatch.setenv("APP_ENV", "staging")
    monkeypatch.setenv("EXISTING_KEY", "keep-me")

    with patch.object(VaultKVClient, "read_kv_v2", return_value={"EXISTING_KEY": "new", "API_KEY": "123"}):
        written = load_env_from_vault(override_existing=False)

    assert written == 1
    assert os.environ["EXISTING_KEY"] == "keep-me"
    assert os.environ["API_KEY"] == "123"


def test_load_env_from_vault_requires_mount(monkeypatch):
    monkeypatch.setenv("VAULT_ADDR", "https://vault.example.com")
    monkeypatch.setenv("VAULT_TOKEN", "token")
    monkeypatch.delenv("VAULT_KV_MOUNT", raising=False)

    with pytest.raises(RuntimeError, match="VAULT_KV_MOUNT"):
        load_env_from_vault()


def test_load_env_from_vault_uses_approle_when_token_missing(monkeypatch):
    monkeypatch.setenv("VAULT_ADDR", "https://vault.example.com")
    monkeypatch.setenv("VAULT_ROLE_ID", "role-id")
    monkeypatch.setenv("VAULT_SECRET_ID", "secret-id")
    monkeypatch.setenv("VAULT_KV_MOUNT", "mentors")
    monkeypatch.delenv("VAULT_TOKEN", raising=False)

    with patch("jh_vault_helper.vault_helper.login_with_approle", return_value="approle-token") as mocked_login:
        with patch.object(VaultKVClient, "read_kv_v2", return_value={"API_KEY": "123"}):
            written = load_env_from_vault()

    assert written == 1
    assert os.environ["VAULT_TOKEN"] == "approle-token"
    mocked_login.assert_called_once()


def test_login_with_approle_returns_client_token():
    response = Mock()
    response.json.return_value = {"auth": {"client_token": "token-123"}}

    with patch("jh_vault_helper.vault_helper.requests.post", return_value=response) as mocked_post:
        token = login_with_approle(
            addr="https://vault.example.com",
            role_id="role-id",
            secret_id="secret-id",
        )

    assert token == "token-123"
    mocked_post.assert_called_once()
