import json
import logging
import os
from typing import Any, Dict, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util import Retry


log = logging.getLogger("vault")
log.setLevel(logging.INFO)


def login_with_approle(
    addr: str,
    role_id: str,
    secret_id: str,
    namespace: str | None = None,
    verify: bool | str = True,
    timeout: float = 5.0,
) -> str:
    """
    Exchange AppRole credentials for a Vault client token.
    """
    if not addr:
        raise RuntimeError("Vault configuration incomplete. Missing required environment variable: VAULT_ADDR")

    url = f"{addr.rstrip('/')}/v1/auth/approle/login"
    headers = {}
    if namespace:
        headers["X-Vault-Namespace"] = namespace

    resp = requests.post(
        url,
        json={"role_id": role_id, "secret_id": secret_id},
        headers=headers,
        timeout=timeout,
        verify=verify,
    )
    resp.raise_for_status()
    payload = resp.json()
    return payload["auth"]["client_token"]


class VaultKVClient:
    """
    Minimal client for Vault KV v2.
    """

    def __init__(
        self,
        addr: str,
        token: str,
        *,
        namespace: Optional[str] = None,
        verify: Optional[bool | str] = True,
        timeout: float = 5.0,
        retries: int = 3,
        backoff_factor: float = 0.3,
    ):
        if not addr.startswith("http"):
            raise ValueError("VAULT_ADDR must include scheme, e.g. https://vault.example.com")

        self.addr = addr.rstrip("/")
        self.token = token
        self.namespace = namespace
        self.verify = verify
        self.timeout = timeout

        session = requests.Session()
        retry = Retry(
            total=retries,
            read=retries,
            connect=retries,
            backoff_factor=backoff_factor,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET"]),
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        self.session = session

    def _headers(self) -> Dict[str, str]:
        headers = {"X-Vault-Token": self.token}
        if self.namespace:
            headers["X-Vault-Namespace"] = self.namespace
        return headers

    def read_kv_v2(self, mount: str, path: str, version: Optional[int] = None) -> Dict[str, Any]:
        """
        GET /v1/<mount>/data/<path>?version=N and return the actual secret data.
        """
        url = f"{self.addr}/v1/{mount.strip('/')}/data/{path.strip('/')}"
        params = {"version": version} if version else None

        try:
            resp = self.session.get(
                url,
                headers=self._headers(),
                params=params,
                timeout=self.timeout,
                verify=self.verify,
            )
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(
                f"Failed to connect to Vault at {self.addr}. Check VAULT_ADDR and network connectivity: {exc}"
            ) from exc
        except requests.exceptions.Timeout as exc:
            raise RuntimeError(
                f"Vault request timed out after {self.timeout}s. Check Vault availability: {exc}"
            ) from exc
        except requests.exceptions.RequestException as exc:
            raise RuntimeError(f"Vault request failed: {exc}") from exc

        try:
            resp.raise_for_status()
        except requests.HTTPError as exc:
            body = resp.text[:500]
            if resp.status_code == 403:
                raise RuntimeError(
                    f"Vault access denied (403). Check VAULT_TOKEN permissions for {mount}/{path}: {body}"
                ) from exc
            if resp.status_code == 404:
                raise RuntimeError(
                    f"Vault secret not found (404). Check mount '{mount}' and path '{path}': {body}"
                ) from exc
            if resp.status_code == 401:
                raise RuntimeError(f"Vault authentication failed (401). Check VAULT_TOKEN: {body}") from exc
            raise RuntimeError(f"Vault read failed {resp.status_code} {url}: {body}") from exc

        try:
            payload = resp.json()
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Vault returned invalid JSON response: {resp.text[:500]}") from exc

        try:
            return payload["data"]["data"]
        except (KeyError, TypeError) as exc:
            raise RuntimeError(f"Unexpected Vault KV response shape: {json.dumps(payload)[:500]}") from exc


def load_env_from_vault(
    *,
    addr: Optional[str] = None,
    token: Optional[str] = None,
    namespace: Optional[str] = None,
    mount: Optional[str] = None,
    secret_path: Optional[str] = None,
    verify: Optional[bool | str] = None,
    timeout: Optional[float] = None,
    version: Optional[int] = None,
    override_existing: bool = True,
) -> int:
    """
    Fetch KV data from Vault and write keys to os.environ.
    """
    addr = addr or os.getenv("VAULT_ADDR")
    token = token or os.getenv("VAULT_TOKEN")
    namespace = namespace or os.getenv("VAULT_NAMESPACE")
    mount = mount or os.getenv("VAULT_KV_MOUNT")
    default_env_path = "production" if (os.getenv("APP_ENV") or "").strip().lower() == "production" else "staging"
    secret_path = secret_path or os.getenv("VAULT_KV_PATH", default_env_path)

    if verify is None:
        raw_verify = os.getenv("VAULT_VERIFY", "true").lower()
        verify = False if raw_verify in ("0", "false", "no") else True

    if timeout is None:
        try:
            timeout = float(os.getenv("VAULT_TIMEOUT", "5"))
        except ValueError:
            timeout = 5.0

    if not token:
        role_id = os.getenv("VAULT_ROLE_ID")
        secret_id = os.getenv("VAULT_SECRET_ID")
        if role_id and secret_id:
            token = login_with_approle(
                addr=addr or "",
                role_id=role_id,
                secret_id=secret_id,
                namespace=namespace,
                verify=verify,
                timeout=timeout,
            )
            os.environ["VAULT_TOKEN"] = token

    missing_vars = []
    if not addr:
        missing_vars.append("VAULT_ADDR")
    if not token:
        missing_vars.append("VAULT_TOKEN (or VAULT_ROLE_ID + VAULT_SECRET_ID for AppRole)")
    if not mount:
        missing_vars.append("VAULT_KV_MOUNT (or mount argument)")
    if missing_vars:
        raise RuntimeError(
            f"Vault configuration incomplete. Missing required environment variables: {', '.join(missing_vars)}"
        )

    try:
        client = VaultKVClient(addr, token, namespace=namespace, verify=verify, timeout=timeout)
        data = client.read_kv_v2(mount, secret_path, version=version)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to load secrets from Vault (addr={addr}, mount={mount}, path={secret_path}): {exc}"
        ) from exc

    if not data:
        raise RuntimeError(f"Vault secret at {mount}/{secret_path} is empty or contains no key-value pairs")

    written = 0
    for key, value in data.items():
        if not override_existing and key in os.environ:
            continue
        os.environ[key] = "" if value is None else str(value)
        written += 1

    log.info("Loaded %d env vars from Vault mount=%s path=%s", written, mount, secret_path)
    return written
