import logging
import os
import threading
from typing import List, Optional, Tuple

from .vault_helper import load_env_from_vault


logger = logging.getLogger("vault_refresher")


class VaultSecretRefresher:
    """
    Background thread that periodically refreshes secrets from Vault.
    """

    def __init__(self, *, refresh_interval: Optional[int] = None, enabled: Optional[bool] = None):
        if enabled is None:
            enabled = os.getenv("VAULT_AUTO_REFRESH", "true").lower() not in ("0", "false", "no")

        if refresh_interval is None:
            try:
                refresh_interval = int(os.getenv("VAULT_REFRESH_INTERVAL", "300"))
            except ValueError:
                refresh_interval = 300

        self.enabled = enabled
        self.refresh_interval = max(60, int(refresh_interval))
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

        logger.info(
            "VaultSecretRefresher initialized: enabled=%s, interval=%ds",
            self.enabled,
            self.refresh_interval,
        )

    def start(self) -> None:
        if not self.enabled:
            logger.info("Vault auto-refresh is disabled (VAULT_AUTO_REFRESH=false)")
            return

        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                logger.warning("Refresh thread already running")
                return

            self._stop_event.clear()
            self._thread = threading.Thread(
                target=self._refresh_loop,
                name="VaultSecretRefresher",
                daemon=True,
            )
            self._thread.start()
            logger.info("Vault secret auto-refresh started (interval=%ds)", self.refresh_interval)

    def stop(self, timeout: float = 5.0) -> None:
        if not self.enabled or self._thread is None:
            return

        logger.info("Stopping Vault secret auto-refresh...")
        self._stop_event.set()
        if self._thread.is_alive():
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                logger.warning("Refresh thread did not stop within timeout")
            else:
                logger.info("Vault secret auto-refresh stopped")

    def _refresh_loop(self) -> None:
        consecutive_errors = 0
        max_consecutive_errors = 5

        while not self._stop_event.is_set():
            try:
                self._refresh_secrets()
                consecutive_errors = 0
            except Exception as exc:
                consecutive_errors += 1
                logger.error(
                    "Failed to refresh secrets from Vault (attempt %d/%d): %s",
                    consecutive_errors,
                    max_consecutive_errors,
                    exc,
                    exc_info=True,
                )
                if consecutive_errors >= max_consecutive_errors:
                    logger.critical(
                        "Too many consecutive refresh failures (%d). Stopping auto-refresh.",
                        consecutive_errors,
                    )
                    break
                backoff = min(60 * (2 ** (consecutive_errors - 1)), self.refresh_interval)
                logger.info("Will retry in %ds...", backoff)
                if self._stop_event.wait(timeout=backoff):
                    break
                continue

            if self._stop_event.wait(timeout=self.refresh_interval):
                break

    def _refresh_secrets(self) -> None:
        env_mount = os.getenv("VAULT_KV_MOUNT")
        env_path = os.getenv("VAULT_KV_PATH")
        if not env_path:
            app_env = (os.getenv("APP_ENV") or "").strip().lower()
            env_path = "production" if app_env == "production" else "staging"

        shared_mount = os.getenv("VAULT_SHARED_MOUNT")
        shared_path = os.getenv("VAULT_SHARED_PATH")

        secrets_loaded: List[Tuple[str, int]] = []

        if env_mount and env_path:
            count = load_env_from_vault(
                mount=env_mount,
                secret_path=env_path,
                override_existing=True,
            )
            secrets_loaded.append((f"{env_mount}/{env_path}", count))

        if shared_mount and shared_path:
            try:
                count = load_env_from_vault(
                    mount=shared_mount,
                    secret_path=shared_path,
                    override_existing=False,
                )
                secrets_loaded.append((f"{shared_mount}/{shared_path}", count))
            except Exception as exc:
                logger.warning(
                    "Failed to refresh shared secrets from %s/%s: %s",
                    shared_mount,
                    shared_path,
                    exc,
                )

        if secrets_loaded:
            summary = ", ".join(f"{path}: {count} vars" for path, count in secrets_loaded)
            logger.info("Successfully refreshed secrets: %s", summary)
        else:
            logger.warning("No secrets refreshed (check VAULT_KV_MOUNT and VAULT_KV_PATH)")


_global_refresher: Optional[VaultSecretRefresher] = None


def start_vault_auto_refresh(**kwargs) -> VaultSecretRefresher:
    global _global_refresher
    if _global_refresher is None:
        _global_refresher = VaultSecretRefresher(**kwargs)
    _global_refresher.start()
    return _global_refresher


def stop_vault_auto_refresh() -> None:
    global _global_refresher
    if _global_refresher is not None:
        _global_refresher.stop()
