"""
SecureAuth Python SDK
A secure authentication client for integrating with SecureAuth server
"""

from setuptools import setup, find_packages
import os

# Read the README file
def read_readme():
    with open("README.md", "r", encoding="utf-8") as fh:
        return fh.read()

# Read requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="secureauth-sdk",
    version="1.0.0",
    author="SecureAuth Team",
    author_email="support@secureauth.com",
    description="A secure authentication client for integrating with SecureAuth server",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/secureauth/python-sdk",
    project_urls={
        "Bug Tracker": "https://github.com/secureauth/python-sdk/issues",
        "Documentation": "https://secureauth.com/docs",
        "Source Code": "https://github.com/secureauth/python-sdk",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet",
        "Topic :: Security :: Cryptography",
        "Topic :: System :: Systems Administration :: Authentication/Directory",
    ],
    python_requires=">=3.7",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
        ],
        "docs": [
            "sphinx>=4.0",
            "sphinx-rtd-theme>=0.5",
        ],
    },
    include_package_data=True,
    package_data={
        "secureauth": ["*.py", "*.md", "*.txt"],
    },
    keywords="authentication security jwt api secureauth login oauth",
    entry_points={
        "console_scripts": [
            "secureauth-sdk-cli=secureauth.cli:main",
        ],
    },
    zip_safe=False,
)
