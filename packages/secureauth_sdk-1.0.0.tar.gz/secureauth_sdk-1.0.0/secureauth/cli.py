"""
SecureAuth CLI
Command-line interface for SecureAuth operations
"""

import argparse
import json
import os
import sys
from typing import Dict, Any

from .client import SecureAuthClient, SecureAuthError, SecureAuthException
from . import __version__


def load_config() -> Dict[str, str]:
    """Load configuration from environment variables"""
    config = {
        'api_key': os.getenv('SECUREAUTH_API_KEY'),
        'api_secret': os.getenv('SECUREAUTH_API_SECRET'),
        'base_url': os.getenv('SECUREAUTH_BASE_URL', 'http://localhost:3000')
    }
    
    if not config['api_key'] or not config['api_secret']:
        print("Error: SECUREAUTH_API_KEY and SECUREAUTH_API_SECRET must be set")
        sys.exit(1)
    
    return config


def verify_token_command(args):
    """Verify a JWT token"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        result = client.verify_token(args.token)
        print(json.dumps(result, indent=2))
    except SecureAuthError as e:
        print(f"Error: {e}")
        sys.exit(1)


def get_user_command(args):
    """Get user information"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        result = client.get_user_info(args.user_id)
        print(json.dumps(result, indent=2))
    except SecureAuthError as e:
        print(f"Error: {e}")
        sys.exit(1)


def health_command(args):
    """Check server health"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        import requests
        response = requests.get(f"{config['base_url']}/health", timeout=5)
        if response.status_code == 200:
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"Server returned status code: {response.status_code}")
            sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def create_app_command(args):
    """Create a new application"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        data = {'name': args.name}
        if args.description:
            data['description'] = args.description
        
        result = client.create_application(**data)
        print(json.dumps(result, indent=2))
    except SecureAuthError as e:
        print(f"Error: {e}")
        sys.exit(1)


def list_apps_command(args):
    """List all applications"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        result = client.get_applications()
        print(json.dumps(result, indent=2))
    except SecureAuthError as e:
        print(f"Error: {e}")
        sys.exit(1)


def logs_command(args):
    """Get audit logs"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        result = client.get_audit_logs(limit=args.limit)
        print(json.dumps(result, indent=2))
    except SecureAuthError as e:
        print(f"Error: {e}")
        sys.exit(1)


def events_command(args):
    """Get security events"""
    config = load_config()
    client = SecureAuthClient(**config)
    
    try:
        params = {'limit': args.limit}
        if args.severity:
            params['severity'] = args.severity
        
        result = client.get_security_events(**params)
        print(json.dumps(result, indent=2))
    except SecureAuthError as e:
        print(f"Error: {e}")
        sys.exit(1)


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='SecureAuth CLI - Command-line interface for SecureAuth',
        prog='secureauth-cli'
    )
    parser.add_argument('--version', action='version', version=f'SecureAuth CLI {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Verify token command
    verify_parser = subparsers.add_parser('verify-token', help='Verify a JWT token')
    verify_parser.add_argument('token', help='JWT token to verify')
    verify_parser.set_defaults(func=verify_token_command)
    
    # Get user command
    user_parser = subparsers.add_parser('get-user', help='Get user information')
    user_parser.add_argument('user_id', help='User ID to fetch')
    user_parser.set_defaults(func=get_user_command)
    
    # Health check command
    health_parser = subparsers.add_parser('health', help='Check server health')
    health_parser.set_defaults(func=health_command)
    
    # Create application command
    create_app_parser = subparsers.add_parser('create-app', help='Create a new application')
    create_app_parser.add_argument('name', help='Application name')
    create_app_parser.add_argument('--description', help='Application description')
    create_app_parser.set_defaults(func=create_app_command)
    
    # List applications command
    list_apps_parser = subparsers.add_parser('list-apps', help='List all applications')
    list_apps_parser.set_defaults(func=list_apps_command)
    
    # Logs command
    logs_parser = subparsers.add_parser('logs', help='Get audit logs')
    logs_parser.add_argument('--limit', type=int, default=50, help='Number of logs to retrieve')
    logs_parser.set_defaults(func=logs_command)
    
    # Events command
    events_parser = subparsers.add_parser('events', help='Get security events')
    events_parser.add_argument('--limit', type=int, default=50, help='Number of events to retrieve')
    events_parser.add_argument('--severity', help='Filter by severity')
    events_parser.set_defaults(func=events_command)
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Execute command
    args.func(args)


if __name__ == '__main__':
    main()
