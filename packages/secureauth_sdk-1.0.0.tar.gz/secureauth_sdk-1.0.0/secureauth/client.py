"""
SecureAuth Python Client SDK
A secure authentication client for integrating with SecureAuth server
"""

import hashlib
import hmac
import json
import time
import uuid
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple, Any

import requests
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
import base64


class SecureAuthError(Exception):
    """Base exception for SecureAuth errors"""
    pass


class SecureAuthException(SecureAuthError):
    """Exception for SecureAuth API errors"""
    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data or {}


class SecureAuthClient:
    """SecureAuth client for API interactions"""
    
    def __init__(self, api_key: str, api_secret: str, base_url: str = "http://localhost:3000", timeout: int = 30):
        """
        Initialize SecureAuth client
        
        Args:
            api_key: Your SecureAuth API key
            api_secret: Your SecureAuth API secret
            base_url: Base URL of SecureAuth server
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': f'SecureAuth-Python-SDK/{__version__}',
            'Content-Type': 'application/json'
        })
    
    def _generate_signature(self, method: str, path: str, timestamp: str, body: str = "") -> str:
        """Generate HMAC signature for API requests"""
        message = f"{method.upper()} {path} {timestamp} {body}"
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return signature
    
    def _make_request(self, method: str, path: str, data: dict = None) -> dict:
        """Make authenticated API request"""
        url = f"{self.base_url}{path}"
        timestamp = str(int(time.time()))
        body = json.dumps(data) if data else ""
        
        # Generate signature
        signature = self._generate_signature(method, path, timestamp, body)
        
        # Set headers
        headers = {
            'X-API-Key': self.api_key,
            'X-Timestamp': timestamp,
            'X-Signature': signature
        }
        
        try:
            if method.upper() == 'GET':
                response = self.session.get(url, headers=headers, timeout=self.timeout)
            elif method.upper() == 'POST':
                response = self.session.post(url, headers=headers, data=body, timeout=self.timeout)
            elif method.upper() == 'PUT':
                response = self.session.put(url, headers=headers, data=body, timeout=self.timeout)
            elif method.upper() == 'DELETE':
                response = self.session.delete(url, headers=headers, timeout=self.timeout)
            else:
                raise SecureAuthError(f"Unsupported HTTP method: {method}")
            
            # Handle response
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                raise SecureAuthException("Unauthorized: Invalid API credentials", 401)
            elif response.status_code == 403:
                raise SecureAuthException("Forbidden: Insufficient permissions", 403)
            elif response.status_code == 404:
                raise SecureAuthException("Not Found: Resource not found", 404)
            elif response.status_code == 429:
                raise SecureAuthException("Rate limit exceeded", 429)
            elif response.status_code >= 500:
                raise SecureAuthException("Server error", response.status_code)
            else:
                error_data = response.json() if response.headers.get('content-type') == 'application/json' else {}
                raise SecureAuthException(error_data.get('error', 'Unknown error'), response.status_code)
                
        except requests.exceptions.Timeout:
            raise SecureAuthError(f"Request timeout after {self.timeout} seconds")
        except requests.exceptions.ConnectionError:
            raise SecureAuthError("Connection error: Unable to reach SecureAuth server")
        except requests.exceptions.RequestException as e:
            raise SecureAuthError(f"Request error: {str(e)}")
    
    def verify_token(self, token: str) -> dict:
        """
        Verify a JWT token
        
        Args:
            token: JWT token to verify
            
        Returns:
            Dictionary with verification result and user data
        """
        try:
            response = self._make_request('POST', '/api/v1/auth/verify', {'token': token})
            return response
        except SecureAuthException as e:
            return {
                'success': False,
                'error': str(e),
                'status_code': e.status_code
            }
    
    def get_user_info(self, user_id: str) -> dict:
        """
        Get user information
        
        Args:
            user_id: User ID to fetch
            
        Returns:
            User information dictionary
        """
        return self._make_request('GET', f'/api/v1/users/{user_id}')
    
    def create_user_session(self, user_id: str, device_info: dict = None) -> dict:
        """
        Create a new user session
        
        Args:
            user_id: User ID
            device_info: Device fingerprinting data
            
        Returns:
            Session creation result
        """
        data = {'user_id': user_id}
        if device_info:
            data.update(device_info)
        
        return self._make_request('POST', '/api/v1/sessions', data)
    
    def revoke_session(self, session_id: str) -> dict:
        """
        Revoke a user session
        
        Args:
            session_id: Session ID to revoke
            
        Returns:
            Revocation result
        """
        return self._make_request('DELETE', f'/api/v1/sessions/{session_id}')
    
    def get_user_sessions(self, user_id: str) -> dict:
        """
        Get all active sessions for a user
        
        Args:
            user_id: User ID
            
        Returns:
            List of user sessions
        """
        return self._make_request('GET', f'/api/v1/users/{user_id}/sessions')
    
    def log_security_event(self, event_type: str, severity: str, details: dict) -> dict:
        """
        Log a security event
        
        Args:
            event_type: Type of security event
            severity: Event severity ('low', 'medium', 'high', 'critical')
            details: Event details
            
        Returns:
            Event logging result
        """
        data = {
            'event_type': event_type,
            'severity': severity,
            'details': details
        }
        
        return self._make_request('POST', '/api/v1/security/events', data)
    
    def check_permissions(self, user_id: str, permission: str) -> dict:
        """
        Check if user has specific permission
        
        Args:
            user_id: User ID
            permission: Permission to check
            
        Returns:
            Permission check result
        """
        return self._make_request('GET', f'/api/v1/users/{user_id}/permissions/{permission}')
    
    def update_user_role(self, user_id: str, role: str) -> dict:
        """
        Update user role
        
        Args:
            user_id: User ID
            role: New role ('user', 'admin', 'moderator')
            
        Returns:
            Role update result
        """
        return self._make_request('PUT', f'/api/v1/users/{user_id}/role', {'role': role})
    
    def get_applications(self) -> dict:
        """
        Get all applications
        
        Returns:
            List of applications
        """
        return self._make_request('GET', '/api/v1/applications')
    
    def create_application(self, name: str, description: str = None, allowed_domains: list = None) -> dict:
        """
        Create a new application
        
        Args:
            name: Application name
            description: Application description
            allowed_domains: List of allowed domains
            
        Returns:
            Application creation result
        """
        data = {'name': name}
        if description:
            data['description'] = description
        if allowed_domains:
            data['allowed_domains'] = allowed_domains
        
        return self._make_request('POST', '/api/v1/applications', data)
    
    def get_audit_logs(self, limit: int = 50, offset: int = 0) -> dict:
        """
        Get audit logs
        
        Args:
            limit: Number of logs to retrieve
            offset: Offset for pagination
            
        Returns:
            Audit logs
        """
        params = {'limit': limit, 'offset': offset}
        return self._make_request('GET', '/api/v1/audit/logs')
    
    def get_security_events(self, severity: str = None, limit: int = 50) -> dict:
        """
        Get security events
        
        Args:
            severity: Filter by severity
            limit: Number of events to retrieve
            
        Returns:
            Security events
        """
        params = {'limit': limit}
        if severity:
            params['severity'] = severity
        
        return self._make_request('GET', '/api/v1/security/events')


# Import version
try:
    from . import __version__
except ImportError:
    __version__ = "1.0.0"
