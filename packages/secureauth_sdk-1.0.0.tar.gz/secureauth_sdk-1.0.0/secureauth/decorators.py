"""
SecureAuth Decorators
Authentication and authorization decorators for Flask
"""

from flask import g, request, redirect, url_for, abort, jsonify
from functools import wraps
from typing import Callable, Any


def require_auth(f: Callable) -> Callable:
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not hasattr(g, 'current_user') or not g.current_user:
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'error': 'Authentication required'}), 401
            else:
                return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def require_role(*required_roles: str) -> Callable:
    """Decorator to require specific role(s)"""
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(g, 'current_user') or not g.current_user:
                if request.path.startswith('/api/'):
                    return jsonify({'success': False, 'error': 'Authentication required'}), 401
                else:
                    return redirect(url_for('login'))
            
            user_role = g.current_user.get('role')
            if user_role not in required_roles:
                if request.path.startswith('/api/'):
                    return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
                else:
                    abort(403)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_verification(f: Callable) -> Callable:
    """Decorator to require user verification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not hasattr(g, 'current_user') or not g.current_user:
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'error': 'Authentication required'}), 401
            else:
                return redirect(url_for('login'))
        
        if not g.current_user.get('is_verified', False):
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'error': 'Account not verified'}), 403
            else:
                abort(403)
        
        return f(*args, **kwargs)
    return decorated_function


def require_permission(permission: str) -> Callable:
    """Decorator to require specific permission"""
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(g, 'current_user') or not g.current_user:
                if request.path.startswith('/api/'):
                    return jsonify({'success': False, 'error': 'Authentication required'}), 401
                else:
                    return redirect(url_for('login'))
            
            # Check permission (this would need to be implemented in the API)
            # For now, check if user is admin
            user_role = g.current_user.get('role')
            if user_role != 'admin':
                if request.path.startswith('/api/'):
                    return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403
                else:
                    abort(403)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def optional_auth(f: Callable) -> Callable:
    """Decorator that makes authentication optional"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # User may or may not be authenticated
        return f(*args, **kwargs)
    return decorated_function


def rate_limit(limit: int, window: int = 60) -> Callable:
    """Decorator for rate limiting"""
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # This is a placeholder - implement actual rate limiting
            return f(*args, **kwargs)
        return decorated_function
    return decorator
