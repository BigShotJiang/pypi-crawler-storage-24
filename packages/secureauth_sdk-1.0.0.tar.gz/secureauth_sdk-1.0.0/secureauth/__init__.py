"""
SecureAuth Python SDK
A secure authentication client for integrating with SecureAuth server
"""

__version__ = "1.0.0"
__author__ = "SecureAuth Team"
__email__ = "support@secureauth.com"

from .client import SecureAuthClient
from .middleware import SecureAuthFlask
from .exceptions import SecureAuthError, SecureAuthException
from .decorators import require_auth, require_role, require_verification

__all__ = [
    "SecureAuthClient",
    "SecureAuthFlask", 
    "SecureAuthError",
    "SecureAuthException",
    "require_auth",
    "require_role", 
    "require_verification",
]
