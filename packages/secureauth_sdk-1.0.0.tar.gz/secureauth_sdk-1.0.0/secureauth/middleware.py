"""
SecureAuth Flask Middleware
Provides Flask integration for SecureAuth
"""

from flask import Flask, request, session, g
from functools import wraps
from typing import Dict, Optional, Any

from .client import SecureAuthClient, SecureAuthError, SecureAuthException


class SecureAuthMiddleware:
    """SecureAuth middleware for Flask applications"""
    
    def __init__(self, client: SecureAuthClient):
        """
        Initialize middleware
        
        Args:
            client: SecureAuthClient instance
        """
        self.client = client
    
    def authenticate_request(self, headers: Dict[str, str]) -> tuple[Optional[Dict], Optional[str]]:
        """
        Authenticate incoming request
        
        Args:
            headers: Request headers
            
        Returns:
            Tuple of (user_info, error_message)
        """
        auth_header = headers.get('Authorization', '')
        api_key = headers.get('X-API-Key', '')
        
        # Try JWT authentication first
        if auth_header.startswith('Bearer '):
            token = auth_header[7:]
            try:
                result = self.client.verify_token(token)
                if result.get('success'):
                    return result.get('user'), None
                else:
                    return None, result.get('error', 'Token verification failed')
            except SecureAuthError as e:
                return None, str(e)
        
        # Try API key authentication
        elif api_key:
            try:
                # This would need to be implemented in the API
                # For now, return error
                return None, "API key authentication not implemented in this version"
            except SecureAuthError as e:
                return None, str(e)
        
        return None, "Authentication required"


class SecureAuthFlask:
    """Flask extension for SecureAuth"""
    
    def __init__(self, app: Flask = None):
        """
        Initialize Flask extension
        
        Args:
            app: Flask application instance
        """
        self.app = app
        self.client = None
        self.middleware = None
        
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app: Flask):
        """
        Initialize Flask application
        
        Args:
            app: Flask application instance
        """
        # Get configuration
        api_key = app.config.get('SECUREAUTH_API_KEY')
        api_secret = app.config.get('SECUREAUTH_API_SECRET')
        base_url = app.config.get('SECUREAUTH_BASE_URL', 'http://localhost:3000')
        
        if not api_key or not api_secret:
            raise ValueError("SECUREAUTH_API_KEY and SECUREAUTH_API_SECRET must be configured")
        
        # Initialize client
        self.client = SecureAuthClient(api_key, api_secret, base_url)
        self.middleware = SecureAuthMiddleware(self.client)
        
        # Register before request handler
        app.before_request(self._before_request)
        
        # Store extension in app
        app.secureauth = self
    
    def _before_request(self):
        """Handle authentication before each request"""
        # Skip authentication for certain paths
        if request.endpoint and request.endpoint.startswith('static'):
            return  # Skip static files
        
        # Skip authentication for health checks and options
        if request.path in ['/health', '/favicon.ico'] or request.method == 'OPTIONS':
            return
        
        # Authenticate request
        user_info, error = self.middleware.authenticate_request(dict(request.headers))
        
        if error:
            # Return JSON error for API requests
            if request.path.startswith('/api/'):
                return {'success': False, 'error': error}, 401
            # For web requests, continue without authentication (let decorators handle it)
            g.current_user = None
            g.auth_error = error
        else:
            g.current_user = user_info
            g.auth_error = None
    
    def get_current_user(self) -> Optional[Dict]:
        """Get current authenticated user"""
        return getattr(g, 'current_user', None)
    
    def is_authenticated(self) -> bool:
        """Check if current request is authenticated"""
        return self.get_current_user() is not None
    
    def has_role(self, *roles: str) -> bool:
        """Check if current user has any of the specified roles"""
        user = self.get_current_user()
        if not user:
            return False
        return user.get('role') in roles
    
    def is_verified(self) -> bool:
        """Check if current user is verified"""
        user = self.get_current_user()
        if not user:
            return False
        return user.get('is_verified', False)


# Decorators for Flask routes
def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not hasattr(g, 'current_user') or not g.current_user:
            if request.path.startswith('/api/'):
                return {'success': False, 'error': 'Authentication required'}, 401
            else:
                from flask import redirect, url_for, session
                return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def require_role(*required_roles: str):
    """Decorator to require specific role(s)"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(g, 'current_user') or not g.current_user:
                if request.path.startswith('/api/'):
                    return {'success': False, 'error': 'Authentication required'}, 401
                else:
                    from flask import redirect, url_for
                    return redirect(url_for('login'))
            
            user_role = g.current_user.get('role')
            if user_role not in required_roles:
                if request.path.startswith('/api/'):
                    return {'success': False, 'error': 'Insufficient permissions'}, 403
                else:
                    from flask import abort
                    abort(403)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def require_verification(f):
    """Decorator to require user verification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not hasattr(g, 'current_user') or not g.current_user:
            if request.path.startswith('/api/'):
                return {'success': False, 'error': 'Authentication required'}, 401
            else:
                from flask import redirect, url_for
                return redirect(url_for('login'))
        
        if not g.current_user.get('is_verified', False):
            if request.path.startswith('/api/'):
                return {'success': False, 'error': 'Account not verified'}, 403
            else:
                from flask import abort
                abort(403)
        
        return f(*args, **kwargs)
    return decorated_function


def require_permission(permission: str):
    """Decorator to require specific permission"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(g, 'current_user') or not g.current_user:
                if request.path.startswith('/api/'):
                    return {'success': False, 'error': 'Authentication required'}, 401
                else:
                    from flask import redirect, url_for
                    return redirect(url_for('login'))
            
            # Check permission (this would need to be implemented in the API)
            # For now, check if user is admin
            user_role = g.current_user.get('role')
            if user_role != 'admin':
                if request.path.startswith('/api/'):
                    return {'success': False, 'error': 'Insufficient permissions'}, 403
                else:
                    from flask import abort
                    abort(403)
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator
