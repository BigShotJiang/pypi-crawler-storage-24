"""
SecureAuth Exceptions
Custom exceptions for SecureAuth SDK
"""


class SecureAuthError(Exception):
    """Base exception for SecureAuth errors"""
    pass


class SecureAuthException(SecureAuthError):
    """Exception for SecureAuth API errors"""
    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data or {}


class AuthenticationError(SecureAuthError):
    """Exception for authentication failures"""
    pass


class AuthorizationError(SecureAuthError):
    """Exception for authorization failures"""
    pass


class ConfigurationError(SecureAuthError):
    """Exception for configuration errors"""
    pass


class NetworkError(SecureAuthError):
    """Exception for network-related errors"""
    pass


class ValidationError(SecureAuthError):
    """Exception for validation errors"""
    pass
