"""Database backends for dynawrap.

Available backends:
    - DynamoDBBackend: AWS DynamoDB using boto3 client

Example:
    from dynawrap.backends import DynamoDBBackend
    import boto3

    client = boto3.client('dynamodb')
    backend = DynamoDBBackend(client)
    backend.save('stories', story)
"""

from .base import DBBackend
from .dynamodb import DynamoDBBackend

__all__ = ["DBBackend", "DynamoDBBackend"]
