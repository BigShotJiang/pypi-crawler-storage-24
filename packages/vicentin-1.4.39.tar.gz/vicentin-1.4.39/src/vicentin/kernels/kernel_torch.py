from typing import Callable, Optional
from abc import ABC

import torch
import torch.nn as nn


class KernelBackendTorch(nn.Module, ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[torch.Tensor] = None,
        alpha: float = 1e-6,
        chunk_size: Optional[int] = None,
    ):
        super().__init__()

        if X is None:
            X = torch.empty((0, 0))

        self.register_buffer("_X", X)
        self._N = int(X.shape[0])

        self.func = func
        self.alpha = alpha
        self.chunk_size = chunk_size

        self._full_K = None

    @property
    def X(self) -> torch.Tensor:
        if isinstance(self._X, torch.Tensor):
            return self._X

        raise RuntimeError("Buffer _X is not a tensor.")

    @property
    def N(self) -> int:
        return self._N

    def _get_full_matrix(self) -> torch.Tensor:
        if self._full_K is None:
            K = self.func(self.X, self.X)

            if self.alpha > 0:
                K.diagonal().add_(self.alpha)

            self._full_K = K

        return self._full_K

    def forward(
        self, x: torch.Tensor, y: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        n_x = x.shape[0]
        y_eval = y if y is not None else self.X
        n_y = y_eval.shape[0]

        chunk = self.chunk_size if self.chunk_size is not None else n_x
        result = torch.zeros((n_x, n_y), device=x.device, dtype=x.dtype)

        for i in range(0, n_x, chunk):
            end = min(i + chunk, n_x)
            K_chunk = self.func(x[i:end], y_eval)

            if self.alpha > 0 and (y is None or x is y):
                for row_idx in range(i, end):
                    if row_idx < n_y:
                        K_chunk[row_idx - i, row_idx] += self.alpha

            result[i:end] = K_chunk

        return result

    def __getitem__(self, key):
        with torch.no_grad():
            if self.chunk_size is None:
                return self._get_full_matrix()[key]

            if isinstance(key, tuple):
                row_idx, col_idx = key
                return self.forward(self.X[row_idx], self.X[col_idx])

            return self.forward(self.X[key], self.X)

    def __matmul__(self, v: torch.Tensor) -> torch.Tensor:
        if self.chunk_size is None:
            return torch.matmul(self._get_full_matrix(), v)

        N = self.N
        D = v.shape[1] if v.ndim > 1 else 1
        v_reshaped = v.view(N, D)

        result = torch.zeros((N, D), device=self.X.device, dtype=self.X.dtype)

        for i in range(0, N, self.chunk_size):
            end_i = min(i + self.chunk_size, N)
            K_i = self.func(self.X[i:end_i], self.X)
            result[i:end_i] = torch.mm(K_i, v_reshaped)

        out = result + self.alpha * v_reshaped
        return out.view(v.shape)

    def apply_v(self, X: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        N_new = X.shape[0]
        D_v = v.shape[1] if v.ndim > 1 else 1

        v_reshaped = v.view(self.N, D_v)
        result = torch.zeros((N_new, D_v), device=X.device, dtype=X.dtype)

        chunk = self.chunk_size if self.chunk_size is not None else N_new

        for i in range(0, N_new, chunk):
            end_i = min(i + chunk, N_new)
            K_chunk = self.func(X[i:end_i], self.X)
            result[i:end_i] = torch.mm(K_chunk, v_reshaped)

        if self.alpha > 0 and X is self.X:
            result += self.alpha * v_reshaped

        return result.view(X.shape[0], -1) if v.ndim > 1 else result.view(-1)

    def trace(self):
        if self.chunk_size is None:
            return float(torch.trace(self._get_full_matrix()).item())

        trace_val = 0
        for i in range(0, self.N, self.chunk_size):
            end = min(i + self.chunk_size, self.N)
            x_chunk = self.X[i:end]

            K_diag = torch.diagonal(self.func(x_chunk, x_chunk))
            trace_val += torch.sum(K_diag).item() + (end - i) * self.alpha

        return float(trace_val)
