import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from adyd_detector_api.models.bucket_file_list_dto import BucketFileListDto  # noqa: E501
from adyd_detector_api.models.error_dto import ErrorDto  # noqa: E501
from adyd_detector_api.models.message_dto import MessageDto  # noqa: E501
from adyd_detector_api import util


def execute_detect(bucket_name):  # noqa: E501
    """execute_detect

    v # noqa: E501

    :param bucket_name: 
    :type bucket_name: str

    :rtype: Union[MessageDto, Tuple[MessageDto, int], Tuple[MessageDto, int, Dict[str, str]]
    """
    return 'do some magic!'


def execute_yolo(bucket_name, file_name):  # noqa: E501
    """execute_yolo

    execute_yolo # noqa: E501

    :param bucket_name: 
    :type bucket_name: str
    :param file_name: 
    :type file_name: str

    :rtype: Union[MessageDto, Tuple[MessageDto, int], Tuple[MessageDto, int, Dict[str, str]]
    """
    return 'do some magic!'


def insert_file(bucket_name, file_name):  # noqa: E501
    """insert_file

     # noqa: E501

    :param bucket_name: 
    :type bucket_name: str
    :param file_name: 
    :type file_name: str

    :rtype: Union[MessageDto, Tuple[MessageDto, int], Tuple[MessageDto, int, Dict[str, str]]
    """
    return 'do some magic!'


def list_monster_files(bucket_name):  # noqa: E501
    """list_monster_files

     # noqa: E501

    :param bucket_name: 
    :type bucket_name: str

    :rtype: Union[BucketFileListDto, Tuple[BucketFileListDto, int], Tuple[BucketFileListDto, int, Dict[str, str]]
    """
    return 'do some magic!'


def split_file(bucket_name, file_name):  # noqa: E501
    """split_file

     # noqa: E501

    :param bucket_name: 
    :type bucket_name: str
    :param file_name: 
    :type file_name: str

    :rtype: Union[MessageDto, Tuple[MessageDto, int], Tuple[MessageDto, int, Dict[str, str]]
    """
    return 'do some magic!'
