"""Retrieve endpoint — GET /v1/retrieve for memory-augmented responses."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import List, Optional

try:
    from fastapi import APIRouter, Depends, HTTPException, Query
except ImportError:
    raise ImportError("FastAPI is required. Install with: pip install lore-sdk[server]")

from pydantic import BaseModel

from lore.server.auth import AuthContext, get_auth_context
from lore.server.db import get_pool

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1", tags=["retrieve"])

# Valid output formats
VALID_FORMATS = {"xml", "markdown", "raw"}

# Half-life default for time-adjusted importance scoring (days)
_HALF_LIFE_DEFAULT = 30


# ── Response Models ────────────────────────────────────────────────


class RetrieveMemory(BaseModel):
    id: str
    content: str
    type: str
    tier: str
    score: float
    created_at: str
    source: Optional[str] = None
    project: Optional[str] = None
    tags: List[str] = []


class RetrieveResponse(BaseModel):
    memories: List[RetrieveMemory]
    formatted: str
    count: int
    query_time_ms: float


# ── Embedder singleton ─────────────────────────────────────────────

_embedder = None


def _get_embedder():
    """Lazy-load the local embedder (ONNX MiniLM-L6-v2)."""
    global _embedder
    if _embedder is None:
        from lore.embed.local import LocalEmbedder
        _embedder = LocalEmbedder()
    return _embedder


# ── Formatting ─────────────────────────────────────────────────────


def _format_xml(memories: List[RetrieveMemory], query: str) -> str:
    """Format memories as XML block."""
    if not memories:
        return ""
    lines = [f'<memories query="{query}">']
    for m in memories:
        lines.append(f"  <memory id=\"{m.id}\" score=\"{m.score:.2f}\" type=\"{m.type}\">")
        lines.append(f"    {m.content}")
        lines.append("  </memory>")
    lines.append("</memories>")
    return "\n".join(lines)


def _format_markdown(memories: List[RetrieveMemory], query: str) -> str:
    """Format memories as Markdown list."""
    if not memories:
        return ""
    lines = [f"## Relevant Memories ({len(memories)})\n"]
    for m in memories:
        lines.append(f"- **[{m.score:.2f}]** {m.content}")
    return "\n".join(lines)


def _format_raw(memories: List[RetrieveMemory], query: str) -> str:
    """Format memories as plain newline-separated text."""
    if not memories:
        return ""
    return "\n".join(m.content for m in memories)


_FORMATTERS = {
    "xml": _format_xml,
    "markdown": _format_markdown,
    "raw": _format_raw,
}


# ── Route ──────────────────────────────────────────────────────────


@router.get("/retrieve", response_model=RetrieveResponse)
async def retrieve(
    query: str = Query(..., min_length=1, description="Search query"),
    limit: int = Query(5, ge=1, le=50, description="Max results"),
    min_score: float = Query(0.3, ge=0.0, le=1.0, description="Minimum relevance score"),
    format: str = Query("xml", description="Output format: xml, markdown, raw"),
    project: Optional[str] = Query(None, description="Filter by project"),
    profile: Optional[str] = Query(
        None, description="Retrieval profile name (e.g. precise, broad, balanced)",
    ),
    include_session_context: bool = Query(
        True, description="Append recent session_snapshot memories (last 24h)",
    ),
    auth: AuthContext = Depends(get_auth_context),
) -> RetrieveResponse:
    """Retrieve relevant memories for a query.

    Returns semantically similar memories with formatted output
    suitable for injection into LLM prompts.

    When a --profile is specified, its settings (k, threshold, etc.)
    override the default limit/min_score values.
    """
    start = time.monotonic()

    # Resolve profile if specified — override limit/min_score from profile settings
    if profile:
        from lore.server.routes.profiles import resolve_profile as _resolve_profile

        pool = await get_pool()
        async with pool.acquire() as conn:
            resolved = await _resolve_profile(conn, auth.org_id, profile, None)
        if resolved:
            # Profile k/max_results overrides limit
            if resolved.get("k") is not None:
                limit = resolved["k"]
            elif resolved.get("max_results") is not None:
                limit = resolved["max_results"]
            # Profile threshold/min_score overrides min_score
            if resolved.get("threshold") is not None:
                min_score = resolved["threshold"]
            elif resolved.get("min_score") is not None:
                min_score = resolved["min_score"]
        else:
            raise HTTPException(
                status_code=404,
                detail=f"Profile '{profile}' not found. Use GET /v1/profiles to list available profiles.",
            )

    # Validate format
    if format not in VALID_FORMATS:
        raise HTTPException(
            status_code=422,
            detail=f"Invalid format '{format}'. Must be one of: {', '.join(sorted(VALID_FORMATS))}",
        )

    # Embed the query
    embedder = _get_embedder()
    query_vec = embedder.embed(query)

    # Build SQL query
    where_parts: list[str] = ["org_id = $1"]
    params: list = [auth.org_id]

    # Project scoping: auth key scope overrides query param
    effective_project = project
    if auth.project is not None:
        effective_project = auth.project
    if effective_project is not None:
        params.append(effective_project)
        where_parts.append(f"project = ${len(params)}")

    # Exclude expired
    where_parts.append("(expires_at IS NULL OR expires_at > now())")

    # Embedding must exist
    where_parts.append("embedding IS NOT NULL")

    where_sql = " AND ".join(where_parts)

    # Embedding parameter
    params.append(json.dumps(query_vec))
    emb_idx = len(params)

    # Min score parameter
    params.append(min_score)
    score_idx = len(params)

    # Limit parameter
    params.append(limit)
    limit_idx = len(params)

    # SQL with time-adjusted importance scoring (same formula as memories/search)
    sql = f"""
        SELECT id,
               content,
               COALESCE(meta->>'type', 'unknown') AS type,
               COALESCE(meta->>'tier', 'long') AS tier,
               source, project, tags,
               created_at, importance_score,
               (1 - (embedding <=> ${emb_idx}::vector)) *
               COALESCE(importance_score, 1.0) *
               power(0.5,
                   LEAST(
                       EXTRACT(EPOCH FROM (now() - created_at)) / 86400.0,
                       COALESCE(
                           EXTRACT(EPOCH FROM (now() - last_accessed_at)) / 86400.0,
                           EXTRACT(EPOCH FROM (now() - created_at)) / 86400.0
                       )
                   )
                   / {_HALF_LIFE_DEFAULT}
               )
               AS score
        FROM memories
        WHERE {where_sql}
          AND (1 - (embedding <=> ${emb_idx}::vector)) >= ${score_idx}
        ORDER BY score DESC
        LIMIT ${limit_idx}
    """

    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, *params)

    # Build response
    memories: List[RetrieveMemory] = []
    for r in rows:
        rd = dict(r)
        tags = rd.get("tags") or []
        if isinstance(tags, str):
            tags = json.loads(tags)
        created_at = rd.get("created_at")
        if hasattr(created_at, "isoformat"):
            created_at = created_at.isoformat()

        memories.append(RetrieveMemory(
            id=rd["id"],
            content=rd["content"],
            type=rd.get("type", "general"),
            tier=rd.get("tier", "long"),
            score=round(float(rd.get("score", 0.0)), 4),
            created_at=str(created_at or ""),
            source=rd.get("source"),
            project=rd.get("project"),
            tags=tags,
        ))

    # Auto-inject recent session snapshots (last 24h)
    if include_session_context:
        existing_ids = {m.id for m in memories}
        session_memories = await _fetch_session_snapshots(
            auth=auth,
            effective_project=effective_project,
            exclude_ids=existing_ids,
        )
        memories.extend(session_memories)

    # Format output
    formatter = _FORMATTERS[format]
    formatted = formatter(memories, query)

    elapsed_ms = round((time.monotonic() - start) * 1000, 2)

    # Fire-and-forget: record analytics event and update Prometheus metrics
    asyncio.create_task(_record_retrieval_event(
        auth=auth,
        query_text=query,
        memories=memories,
        min_score=min_score,
        elapsed_ms=elapsed_ms,
        fmt=format,
        effective_project=effective_project,
    ))

    # Fire-and-forget: bump access_count + recalculate importance for returned memories
    if memories:
        asyncio.create_task(_bump_access_counts([m.id for m in memories]))

    return RetrieveResponse(
        memories=memories,
        formatted=formatted,
        count=len(memories),
        query_time_ms=elapsed_ms,
    )


async def _record_retrieval_event(
    *,
    auth: AuthContext,
    query_text: str,
    memories: List[RetrieveMemory],
    min_score: float,
    elapsed_ms: float,
    fmt: str,
    effective_project: Optional[str],
) -> None:
    """Insert a retrieval_events row and update Prometheus metrics (fire-and-forget)."""
    try:
        from lore.server.metrics import (
            retrieve_empty_total,
            retrieve_latency,
            retrieve_max_score,
            retrieve_queries_total,
            retrieve_results_total,
        )

        # Prometheus metrics
        retrieve_queries_total.inc()
        retrieve_results_total.inc(amount=float(len(memories)))
        if not memories:
            retrieve_empty_total.inc()
        retrieve_latency.observe(elapsed_ms / 1000.0)

        scores = [m.score for m in memories]
        max_sc = max(scores) if scores else 0.0
        if scores:
            retrieve_max_score.observe(max_sc)

        avg_sc = sum(scores) / len(scores) if scores else None
        memory_ids = [m.id for m in memories]

        pool = await get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO retrieval_events
                   (org_id, query, results_count, scores, avg_score, max_score,
                    min_score_threshold, query_time_ms, project, format, memory_ids)
                   VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7, $8, $9, $10, $11::jsonb)""",
                auth.org_id,
                query_text,
                len(memories),
                json.dumps(scores),
                avg_sc,
                max_sc if scores else None,
                min_score,
                elapsed_ms,
                effective_project,
                fmt,
                json.dumps(memory_ids),
            )
    except Exception:
        logger.warning("Failed to record retrieval event", exc_info=True)


async def _bump_access_counts(memory_ids: List[str]) -> None:
    """Bump access_count, last_accessed_at, and recalculate importance (fire-and-forget)."""
    try:

        from lore.server.db import get_pool

        pool = await get_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """UPDATE memories
                   SET access_count = COALESCE(access_count, 0) + 1,
                       last_accessed_at = now(),
                       importance_score = COALESCE(confidence, 1.0)
                           * GREATEST(0.1, 1.0 + (COALESCE(upvotes, 0) - COALESCE(downvotes, 0)) * 0.1)
                           * (1.0 + ln(COALESCE(access_count, 0) + 2) / ln(2) * 0.1)
                   WHERE id = ANY($1)""",
                memory_ids,
            )
    except Exception:
        logger.warning("Failed to bump access counts", exc_info=True)


async def _fetch_session_snapshots(
    *,
    auth: AuthContext,
    effective_project: Optional[str],
    exclude_ids: set,
    max_snapshots: int = 3,
) -> List[RetrieveMemory]:
    """Fetch recent session_snapshot memories from the last 24 hours."""
    try:
        where_parts: list[str] = ["org_id = $1"]
        params: list = [auth.org_id]

        if effective_project is not None:
            params.append(effective_project)
            where_parts.append(f"project = ${len(params)}")

        where_parts.append("(expires_at IS NULL OR expires_at > now())")
        where_parts.append("meta->>'type' = 'session_snapshot'")
        where_parts.append("created_at > now() - interval '24 hours'")

        where_sql = " AND ".join(where_parts)

        params.append(max_snapshots)
        limit_idx = len(params)

        sql = f"""
            SELECT id, content,
                   COALESCE(meta->>'type', 'unknown') AS type,
                   COALESCE(meta->>'tier', 'long') AS tier,
                   source, project, tags, created_at
            FROM memories
            WHERE {where_sql}
            ORDER BY created_at DESC
            LIMIT ${limit_idx}
        """

        pool = await get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        result: List[RetrieveMemory] = []
        for r in rows:
            rd = dict(r)
            if rd["id"] in exclude_ids:
                continue
            tags = rd.get("tags") or []
            if isinstance(tags, str):
                tags = json.loads(tags)
            created_at = rd.get("created_at")
            if hasattr(created_at, "isoformat"):
                created_at = created_at.isoformat()
            result.append(RetrieveMemory(
                id=rd["id"],
                content=f"[Session Context] {rd['content']}",
                type=rd.get("type", "session_snapshot"),
                tier=rd.get("tier", "long"),
                score=0.0,
                created_at=str(created_at or ""),
                source=rd.get("source"),
                project=rd.get("project"),
                tags=tags,
            ))
        return result
    except Exception:
        logger.warning("Failed to fetch session snapshots", exc_info=True)
        return []
