"""
HTML report builder — converts all analyser data into a single-file dashboard.
Now includes: duplicates, dead code, dependency graph (D3 force), churn.
"""

from __future__ import annotations

import json
import os

from .constants import LONG_LINE_LIMIT


# ─────────────────────────────────────────────────────────────────────────────
#  Section builders
# ─────────────────────────────────────────────────────────────────────────────

def _kpi(label, value, sub="", cls="ka"):
    sub_html = f'<div class="kpi-sub">{sub}</div>' if sub else ""
    return f'<div class="kpi {cls}"><div class="kpi-label">{label}</div><div class="kpi-value">{value}</div>{sub_html}</div>'


def _lang_table(langs, total_loc):
    rows = ""
    for lang, ls in sorted(langs.items(), key=lambda x: x[1]["loc"], reverse=True):
        bar = round(ls["loc"] / total_loc * 100, 1) if total_loc else 0
        rows += f"""<tr>
          <td class="fw">{lang}</td><td>{ls['files']}</td><td>{ls['loc']:,}</td>
          <td>{ls['code']:,}</td><td>{ls['comments']:,}</td>
          <td>{ls['functions']:,}</td><td>{ls['classes']:,}</td><td>{ls['endpoints']:,}</td>
          <td><div class="bw"><div class="bv" style="width:{bar}%"></div></div><span class="bl">{bar}%</span></td>
        </tr>"""
    return rows


def _file_table(files):
    rows = ""
    for f in files[:50]:
        ec = "var(--accent)" if f["endpoints"] else "inherit"
        rows += f"""<tr>
          <td class="fp" title="{f['path']}">{f['path']}</td>
          <td><span class="lb">{f['lang']}</span></td>
          <td>{f['loc']:,}</td><td>{f['code']:,}</td><td>{f['comments']:,}</td>
          <td>{f['comment_ratio']}%</td><td>{f['functions']:,}</td><td>{f['classes']:,}</td>
          <td style="color:{ec};font-weight:600">{f['endpoints']:,}</td>
          <td>{f['todos']:,}</td><td>{f['long_lines']:,}</td>
        </tr>"""
    return rows


def _endpoint_table(endpoints):
    MC = {"GET":"#22c55e","POST":"#3b82f6","PUT":"#f59e0b","DELETE":"#ef4444",
          "PATCH":"#a855f7","ROUTE":"#6b7280","HEAD":"#06b6d4","OPTIONS":"#ec4899"}
    rows = ""
    for ep in endpoints:
        c = MC.get(ep["method"], "#6b7280")
        rows += f"""<tr>
          <td><span class="mb" style="background:{c}">{ep['method']}</span></td>
          <td class="fp">{ep['file']}</td>
          <td class="ec">{ep['raw'][:90]}</td><td>{ep['line']}</td>
        </tr>"""
    return rows


def _todo_table(todos):
    TC = {"TODO":"#3b82f6","FIXME":"#ef4444","HACK":"#f59e0b",
          "BUG":"#ef4444","XXX":"#f97316","NOTE":"#22c55e"}
    rows = ""
    for t in todos[:80]:
        c = TC.get(t["tag"].upper(), "#6b7280")
        rows += f"""<tr>
          <td><span class="mb" style="background:{c}">{t['tag'].upper()}</span></td>
          <td class="fp">{t['file']}</td><td>{t['line']}</td>
          <td class="ec">{t['text'][:100]}</td>
        </tr>"""
    return rows


def _import_bars(imports):
    if not imports:
        return '<div class="no-data">No imports detected</div>'
    max_v = imports[0][1] if imports else 1
    out = ""
    for pkg, cnt in imports:
        w = round(cnt / max_v * 100)
        out += f"""<div class="ir"><span class="in">{pkg}</span>
          <div class="ibw"><div class="ibv" style="width:{w}%"></div></div>
          <span class="ic">{cnt}</span></div>"""
    return out


# ── Duplicate section ─────────────────────────────────────────────────────────

def _dup_section(clusters):
    if not clusters:
        return '<div class="no-data">No duplicate blocks detected — great job!</div>'

    from .duplicate_detector import duplicate_summary
    summ = duplicate_summary(clusters)

    sev_color = {"high": "#ef4444", "medium": "#f59e0b", "low": "#34d399"}

    cards = ""
    for c in clusters[:60]:
        col   = sev_color[c.severity]
        occ_rows = ""
        for o in c.occurrences:
            occ_rows += f'<div class="dup-occ"><span class="fp">{o.file}</span> <span class="bl">L{o.start_line}–{o.end_line}</span></div>'
        preview = clusters[0].occurrences[0].preview[:80] if c.occurrences else ""
        cards += f"""
        <div class="dup-card" style="border-left:3px solid {col}">
          <div class="dup-head">
            <span class="mb" style="background:{col}">{c.severity.upper()}</span>
            <span class="dup-meta">{c.block_lines} lines · {len(c.occurrences)} locations · {c.file_count} file(s)</span>
          </div>
          <div class="dup-preview">{c.occurrences[0].preview[:80] if c.occurrences else ''}</div>
          <div class="dup-occs">{occ_rows}</div>
        </div>"""

    return f"""
    <div class="dup-summary">
      <div class="dup-kpis">
        {_kpi("Total Clusters", summ['total'], "", "ka")}
        {_kpi("High Severity", summ['high'], "≥20 lines", "kr")}
        {_kpi("Medium Severity", summ['medium'], "10–19 lines", "ky")}
        {_kpi("Low Severity", summ['low'], "6–9 lines", "kg")}
        {_kpi("Files Affected", summ['files_affected'], "", "kp")}
      </div>
    </div>
    <div class="dup-list">{cards}</div>"""


# ── Dead code section ─────────────────────────────────────────────────────────

def _dead_section(report):
    if report is None:
        return '<div class="no-data">Dead code detection was skipped.</div>'
    if report.dead_count == 0:
        return f'<div class="no-data">No dead code detected among {report.total_defined:,} defined symbols.</div>'

    summ = report.summary()
    rows = ""
    for s in report.symbols:
        risk_col = "#ef4444" if s.risk == "high" else "#34d399"
        priv = "🔒" if s.is_private else "🌐"
        rows += f"""<tr>
          <td><span class="mb" style="background:{risk_col}">{s.risk.upper()}</span></td>
          <td class="fw">{priv} {s.name}</td>
          <td><span class="lb">{s.kind}</span></td>
          <td class="fp">{s.file}</td>
          <td>{s.line}</td>
        </tr>"""

    return f"""
    <div class="dup-kpis" style="margin-bottom:20px">
      {_kpi("Defined Symbols", f"{summ['total_defined']:,}", "", "ka")}
      {_kpi("Possibly Unused", f"{summ['dead_count']:,}", f"{summ['dead_pct']}% of total", "kr")}
      {_kpi("High Risk (public)", f"{summ['high_risk']:,}", "never referenced", "kr")}
      {_kpi("Low Risk (private)", f"{summ['low_risk']:,}", "underscore prefix", "ky")}
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Risk</th><th>Name</th><th>Kind</th><th>File</th><th>Line</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
    <p style="color:var(--muted);font-size:11px;margin-top:12px">
      ⚠ Heuristic analysis — verify before deleting. Dynamic dispatch, decorators,
      and string-based lookups may cause false positives.
    </p>"""


# ── Dependency graph section ──────────────────────────────────────────────────

def _graph_section(dep_graph):
    if dep_graph is None:
        return '<div class="no-data">Dependency graph was skipped.</div>'

    g    = dep_graph.summary()
    gj   = json.dumps(dep_graph.to_json_graph())
    # Escape for embedding in a single-quoted HTML data attribute
    gj_safe = gj.replace("&", "&amp;").replace("'", "&#39;")

    cycle_rows = ""
    for cyc in dep_graph.cycles[:20]:
        cycle_rows += f'<div class="cycle-row">🔄 {str(cyc)}</div>'

    hub_rows = ""
    for fpath, cnt in dep_graph.hubs[:15]:
        hub_rows += f"""<tr>
          <td class="fp">{fpath}</td>
          <td>{cnt}</td>
          <td><div class="bw"><div class="bv" style="width:{min(cnt*5,100)}%"></div></div></td>
        </tr>"""

    return f"""
    <div class="dup-kpis" style="margin-bottom:20px">
      {_kpi("Source Files", f"{g['files']:,}", "", "ka")}
      {_kpi("Import Edges", f"{g['edges']:,}", "", "kp")}
      {_kpi("Circular Imports", f"{g['cycles']:,}", "⚠ potential runtime errors" if g['cycles'] else "none found", "kr" if g['cycles'] else "kg")}
      {_kpi("Hub Files", f"{g['hubs']:,}", "imported by 2+ files", "ky")}
      {_kpi("Isolated Files", f"{g['isolated']:,}", "no imports/importers", "ka")}
    </div>

    <div class="graph-wrap">
      <div class="graph-title">Interactive Import Graph <span style="font-size:11px;color:var(--muted)">(drag nodes · scroll to zoom)</span></div>
      <div id="dep-graph" data-graph='{gj_safe}' style="width:100%;height:480px;background:var(--bg);border-radius:8px;overflow:hidden"></div>
    </div>

    {"<div class='st2'>Circular Import Chains</div><div class='cycle-list'>" + cycle_rows + "</div>" if dep_graph.cycles else ""}

    {"<div class='st2' style='margin-top:24px'>Hub Files (Most Imported)</div><div class='table-wrap'><table><thead><tr><th>File</th><th>Importers</th><th>Popularity</th></tr></thead><tbody>" + hub_rows + "</tbody></table></div>" if dep_graph.hubs else ""}
    """


# ── Churn section ─────────────────────────────────────────────────────────────

def _churn_section(report):
    if report is None:
        return '<div class="no-data">Git churn analysis was skipped.</div>'
    if not report.git_available:
        return f'<div class="no-data">Git not available: {report.git_error}</div>'
    if not report.files:
        return '<div class="no-data">No commit history found.</div>'

    summ  = report.summary()
    RC    = {"high":"#ef4444","medium":"#f59e0b","low":"#34d399"}

    rows = ""
    for f in report.files[:60]:
        c    = RC[f.risk_level]
        auths = ", ".join(f.authors[:3]) + ("…" if len(f.authors) > 3 else "")
        rows += f"""<tr>
          <td><span class="mb" style="background:{c}">{f.risk_level.upper()}</span></td>
          <td class="fp">{f.path}</td>
          <td>{f.commit_count}</td>
          <td>{f.author_count}</td>
          <td>{f.churn_rate:.1f}/mo</td>
          <td>{f.lines_added:,}</td>
          <td>{f.lines_deleted:,}</td>
          <td>{f.last_modified}</td>
          <td style="color:{c};font-weight:700">{f.churn_score:.0f}</td>
        </tr>"""

    author_rows = ""
    for author, cnt in report.top_authors:
        author_rows += f'<div class="ir"><span class="in">{author}</span><div class="ibw"><div class="ibv" style="width:{round(cnt/report.top_authors[0][1]*100) if report.top_authors else 0}%"></div></div><span class="ic">{cnt}</span></div>'

    return f"""
    <div class="dup-kpis" style="margin-bottom:20px">
      {_kpi("Total Commits", f"{summ['total_commits']:,}", "", "ka")}
      {_kpi("Repo Age", f"{summ['repo_age_days']:,}d", "", "ka")}
      {_kpi("Files Tracked", f"{summ['files']:,}", "", "kp")}
      {_kpi("High Churn Files", f"{summ['high']:,}", "score ≥ 40", "kr")}
      {_kpi("Medium Churn", f"{summ['medium']:,}", "score 15–39", "ky")}
      {_kpi("Low Churn", f"{summ['low']:,}", "score < 15", "kg")}
    </div>

    <div class="table-wrap" style="margin-bottom:24px">
      <table>
        <thead><tr><th>Risk</th><th>File</th><th>Commits</th><th>Authors</th>
          <th>Churn Rate</th><th>Lines Added</th><th>Lines Del</th><th>Last Modified</th><th>Score</th></tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>

    <div class="st2">Top Contributors</div>
    <div class="chart-card" style="max-width:600px;margin-top:12px">
      <div class="imp-list">{author_rows}</div>
    </div>
    <p style="color:var(--muted);font-size:11px;margin-top:12px">
      Score = (commits × 2) + (authors × 3) + (lines changed ÷ 100).
      High-churn files with many authors carry the highest maintenance risk.
    </p>"""


# ─────────────────────────────────────────────────────────────────────────────
#  Main HTML builder
# ─────────────────────────────────────────────────────────────────────────────

def build_html(
    data: dict,
    *,
    dup_clusters=None,
    dead_report=None,
    dep_graph=None,
    churn_report=None,
) -> str:
    s        = data["summary"]
    langs    = data["by_language"]
    files    = data["file_details"]
    todos    = data["todos"]
    endpoints= data["endpoints"]
    imports  = data["top_imports"]

    total       = s["loc"] or 1
    code_pct    = round(s["code"]     / total * 100, 1)
    comment_pct = round(s["comments"] / total * 100, 1)
    blank_pct   = round(s["blank"]    / total * 100, 1)

    lang_labels  = json.dumps(list(langs.keys()))
    lang_data    = json.dumps([v["loc"] for v in langs.values()])
    donut_labels = json.dumps(["Code", "Comments", "Blank"])
    donut_data   = json.dumps([s["code"], s["comments"], s["blank"]])
    proj         = os.path.basename(s["root"])

    needs_d3 = dep_graph is not None and dep_graph.files

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Code Report — {proj}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
{"<script src='https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js'></script>" if needs_d3 else ""}
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=Syne:wght@400;600;800&display=swap');
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
:root{{
  --bg:#0a0c0f;--panel:#111318;--border:#1e2330;
  --text:#c9d1e0;--muted:#4a5568;
  --accent:#38bdf8;--green:#34d399;--yellow:#fbbf24;
  --red:#f87171;--purple:#a78bfa;
  --fh:'Syne',sans-serif;--fm:'IBM Plex Mono',monospace;
}}
body{{background:var(--bg);color:var(--text);font-family:var(--fm);font-size:13px;line-height:1.6;min-height:100vh}}
header{{padding:48px 56px 36px;border-bottom:1px solid var(--border);background:linear-gradient(135deg,#0d1117,#0a0c14);position:relative;overflow:hidden}}
header::before{{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 60% 80% at 80% 50%,rgba(56,189,248,.06),transparent 70%)}}
.hl{{font-family:var(--fh);font-size:11px;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--accent);margin-bottom:10px}}
h1{{font-family:var(--fh);font-size:clamp(22px,4vw,42px);font-weight:800;color:#fff;letter-spacing:-.02em;line-height:1.1;margin-bottom:6px}}
.meta{{color:var(--muted);font-size:12px}}
/* NAV TABS */
.nav{{display:flex;gap:2px;padding:0 56px;background:#0d1017;border-bottom:1px solid var(--border);overflow-x:auto}}
.nav-tab{{padding:12px 20px;font-family:var(--fh);font-size:11px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);cursor:pointer;border-bottom:2px solid transparent;white-space:nowrap;transition:all .15s}}
.nav-tab:hover{{color:var(--text)}}
.nav-tab.active{{color:var(--accent);border-bottom-color:var(--accent)}}
/* PAGES */
.page{{display:none;padding:40px 56px;max-width:1600px}}
.page.active{{display:block}}
section{{margin-bottom:48px}}
.st{{font-family:var(--fh);font-size:11px;font-weight:600;letter-spacing:.15em;text-transform:uppercase;color:var(--accent);margin-bottom:18px;display:flex;align-items:center;gap:10px}}
.st::after{{content:'';flex:1;height:1px;background:var(--border)}}
.st2{{font-family:var(--fh);font-size:11px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin:16px 0 10px}}
/* KPIs */
.dup-kpis{{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:20px}}
.kpi-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:12px;margin-bottom:28px}}
.kpi{{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:18px 16px;transition:border-color .2s}}
.kpi:hover{{border-color:var(--accent)}}
.kpi-label{{font-size:10px;color:var(--muted);letter-spacing:.05em;text-transform:uppercase;margin-bottom:6px}}
.kpi-value{{font-family:var(--fh);font-size:26px;font-weight:800;color:#fff;letter-spacing:-.02em}}
.kpi-sub{{font-size:11px;color:var(--muted);margin-top:3px}}
.ka{{border-top:2px solid var(--accent)}}.kg{{border-top:2px solid var(--green)}}
.ky{{border-top:2px solid var(--yellow)}}.kr{{border-top:2px solid var(--red)}}
.kp{{border-top:2px solid var(--purple)}}
/* CHARTS */
.charts-row{{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:28px}}
@media(max-width:900px){{.charts-row{{grid-template-columns:1fr}}}}
.chart-card{{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:22px}}
.chart-title{{font-family:var(--fh);font-size:12px;font-weight:600;color:var(--text);margin-bottom:14px}}
.comp-bar{{display:flex;height:10px;border-radius:5px;overflow:hidden;margin:8px 0 14px;gap:2px}}
.comp-seg{{transition:opacity .2s}}.comp-seg:hover{{opacity:.8}}
.comp-legend{{display:flex;gap:18px;flex-wrap:wrap;font-size:11px;color:var(--muted)}}
.comp-dot{{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px}}
/* TABLES */
.table-wrap{{overflow-x:auto;border:1px solid var(--border);border-radius:10px;background:var(--panel)}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
thead th{{background:#0d1017;color:var(--muted);font-size:10px;letter-spacing:.08em;text-transform:uppercase;padding:9px 13px;text-align:left;position:sticky;top:0;z-index:1;border-bottom:1px solid var(--border);white-space:nowrap}}
tbody tr{{border-bottom:1px solid #151820;transition:background .1s}}
tbody tr:last-child{{border-bottom:none}}
tbody tr:hover{{background:rgba(56,189,248,.04)}}
td{{padding:8px 13px;color:var(--text);vertical-align:middle;white-space:nowrap}}
.fw{{color:#fff;font-weight:600}}
.fp{{max-width:300px;overflow:hidden;text-overflow:ellipsis;color:var(--accent)}}
.ec{{max-width:340px;overflow:hidden;text-overflow:ellipsis;color:var(--muted);font-size:11px}}
.bw{{display:inline-flex;width:72px;height:4px;background:var(--border);border-radius:2px;vertical-align:middle;margin-right:5px}}
.bv{{height:100%;background:var(--accent);border-radius:2px}}
.bl{{font-size:11px;color:var(--muted)}}
.lb{{background:rgba(56,189,248,.12);color:var(--accent);font-size:10px;padding:2px 7px;border-radius:4px}}
.mb{{display:inline-block;font-size:10px;font-weight:700;padding:2px 7px;border-radius:4px;color:#fff;letter-spacing:.04em}}
/* IMPORTS */
.imp-list{{display:flex;flex-direction:column;gap:7px}}
.ir{{display:flex;align-items:center;gap:10px}}
.in{{width:150px;color:#fff;font-size:12px;flex-shrink:0;overflow:hidden;text-overflow:ellipsis}}
.ibw{{flex:1;height:5px;background:var(--border);border-radius:3px}}
.ibv{{height:100%;background:var(--purple);border-radius:3px}}
.ic{{width:32px;text-align:right;color:var(--muted);font-size:12px}}
/* DUPLICATES */
.dup-list{{display:flex;flex-direction:column;gap:12px}}
.dup-card{{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:16px;transition:border-color .15s}}
.dup-card:hover{{border-color:var(--accent)}}
.dup-head{{display:flex;align-items:center;gap:10px;margin-bottom:8px}}
.dup-meta{{font-size:11px;color:var(--muted)}}
.dup-preview{{font-family:var(--fm);font-size:11px;color:var(--yellow);background:#0d1017;padding:6px 10px;border-radius:5px;margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.dup-occs{{display:flex;flex-wrap:wrap;gap:6px}}
.dup-occ{{font-size:11px;background:#1a2030;padding:3px 8px;border-radius:4px}}
/* GRAPH */
.graph-wrap{{background:var(--panel);border:1px solid var(--border);border-radius:10px;padding:20px;margin-bottom:20px}}
.graph-title{{font-family:var(--fh);font-size:12px;font-weight:600;color:var(--text);margin-bottom:12px}}
.cycle-list{{display:flex;flex-direction:column;gap:6px;margin-bottom:16px}}
.cycle-row{{background:#1a1020;border:1px solid #3a1a2a;border-radius:6px;padding:8px 12px;font-size:12px;color:var(--red);overflow-x:auto;white-space:nowrap}}
/* MISC */
.no-data{{color:var(--muted);padding:24px;text-align:center;font-style:italic;background:var(--panel);border:1px solid var(--border);border-radius:10px}}
footer{{margin-top:60px;padding:24px 56px;border-top:1px solid var(--border);color:var(--muted);font-size:11px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px}}
</style>
</head>
<body>
<header>
  <div class="hl">Code Intelligence Report</div>
  <h1>{proj}</h1>
  <div class="meta">{s['root']} &nbsp;·&nbsp; {s['generated_at']}</div>
</header>

<!-- NAV -->
<nav class="nav">
  <div class="nav-tab active" data-page="overview">Overview</div>
  <div class="nav-tab" data-page="files">Files</div>
  <div class="nav-tab" data-page="duplicates">Duplicates</div>
  <div class="nav-tab" data-page="deadcode">Dead Code</div>
  <div class="nav-tab" data-page="depgraph">Dependency Graph</div>
  <div class="nav-tab" data-page="churn">Code Churn</div>
  <div class="nav-tab" data-page="endpoints">Endpoints</div>
  <div class="nav-tab" data-page="todos">TODOs</div>
</nav>

<!-- ══ OVERVIEW ══ -->
<div id="page-overview" class="page active">
  <section>
    <div class="st">At a Glance</div>
    <div class="kpi-grid">
      {_kpi("Files", f"{s['files']:,}", "", "ka")}
      {_kpi("Total Lines", f"{s['loc']:,}", f"{s['blank']:,} blank", "ka")}
      {_kpi("Code Lines", f"{s['code']:,}", f"{code_pct}% of total", "kg")}
      {_kpi("Comment Lines", f"{s['comments']:,}", f"{comment_pct}% of total", "ky")}
      {_kpi("Functions", f"{s['functions']:,}", f"{s['async_functions']} async", "kp")}
      {_kpi("Classes", f"{s['classes']:,}", "", "kp")}
      {_kpi("Endpoints", f"{s['endpoints']:,}", "", "kg")}
      {_kpi("TODOs / FIXMEs", f"{s['todos']:,}", "", "kr")}
      {_kpi(f"Long Lines >{LONG_LINE_LIMIT}", f"{s['long_lines']:,}", "", "ky")}
    </div>
    <div class="chart-card">
      <div class="chart-title">Line Composition</div>
      <div class="comp-bar">
        <div class="comp-seg" style="width:{code_pct}%;background:var(--green)"></div>
        <div class="comp-seg" style="width:{comment_pct}%;background:var(--yellow)"></div>
        <div class="comp-seg" style="width:{blank_pct}%;background:var(--border)"></div>
      </div>
      <div class="comp-legend">
        <span><span class="comp-dot" style="background:var(--green)"></span>Code {code_pct}%</span>
        <span><span class="comp-dot" style="background:var(--yellow)"></span>Comments {comment_pct}%</span>
        <span><span class="comp-dot" style="background:var(--muted)"></span>Blank {blank_pct}%</span>
      </div>
    </div>
  </section>
  <section>
    <div class="st">Distribution</div>
    <div class="charts-row">
      <div class="chart-card">
        <div class="chart-title">Lines by Language</div>
        <canvas id="langChart" height="220"></canvas>
      </div>
      <div class="chart-card">
        <div class="chart-title">Code vs Comments vs Blank</div>
        <canvas id="donutChart" height="220"></canvas>
      </div>
    </div>
  </section>
  <section>
    <div class="st">By Language</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Language</th><th>Files</th><th>LOC</th><th>Code</th><th>Comments</th><th>Functions</th><th>Classes</th><th>Endpoints</th><th>Share</th></tr></thead>
        <tbody>{_lang_table(langs, total)}</tbody>
      </table>
    </div>
  </section>
  <section>
    <div class="st">Most Used Packages</div>
    <div class="chart-card" style="max-width:580px">
      <div class="imp-list">{_import_bars(imports)}</div>
    </div>
  </section>
</div>

<!-- ══ FILES ══ -->
<div id="page-files" class="page">
  <section>
    <div class="st">Top 50 Files by Size</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>File</th><th>Lang</th><th>LOC</th><th>Code</th><th>Comments</th><th>Comment%</th><th>Fns</th><th>Classes</th><th>Endpoints</th><th>TODOs</th><th>Long Lines</th></tr></thead>
        <tbody>{_file_table(files) or '<tr><td colspan="11" class="no-data">No files found</td></tr>'}</tbody>
      </table>
    </div>
  </section>
</div>

<!-- ══ DUPLICATES ══ -->
<div id="page-duplicates" class="page">
  <section>
    <div class="st">Duplicate Code Blocks</div>
    {_dup_section(dup_clusters or [])}
  </section>
</div>

<!-- ══ DEAD CODE ══ -->
<div id="page-deadcode" class="page">
  <section>
    <div class="st">Dead Code — Unused Symbols</div>
    {_dead_section(dead_report)}
  </section>
</div>

<!-- ══ DEPENDENCY GRAPH ══ -->
<div id="page-depgraph" class="page">
  <section>
    <div class="st">Dependency Graph</div>
    {_graph_section(dep_graph)}
  </section>
</div>

<!-- ══ CHURN ══ -->
<div id="page-churn" class="page">
  <section>
    <div class="st">Code Churn — Git History Analysis</div>
    {_churn_section(churn_report)}
  </section>
</div>

<!-- ══ ENDPOINTS ══ -->
<div id="page-endpoints" class="page">
  <section>
    <div class="st">API Endpoints ({len(endpoints)} total)</div>
    {"<div class='table-wrap'><table><thead><tr><th>Method</th><th>File</th><th>Source</th><th>Line</th></tr></thead><tbody>" + _endpoint_table(endpoints) + "</tbody></table></div>" if endpoints else "<div class='no-data'>No API endpoints detected.</div>"}
  </section>
</div>

<!-- ══ TODOs ══ -->
<div id="page-todos" class="page">
  <section>
    <div class="st">TODOs &amp; FIXMEs ({len(todos)} total)</div>
    {"<div class='table-wrap'><table><thead><tr><th>Tag</th><th>File</th><th>Line</th><th>Text</th></tr></thead><tbody>" + _todo_table(todos) + "</tbody></table></div>" if todos else "<div class='no-data'>No TODOs found — clean codebase!</div>"}
  </section>
</div>

<footer>
  <span>codereporter v0.2.4</span>
  <span>{s['generated_at']}</span>
</footer>

<script>
// Wrap everything in load event so CDN scripts (Chart.js, D3) are fully ready
window.addEventListener('load', function() {{

// ── Tab navigation ──────────────────────────────────────────────────────────
var graphInited = false;

document.querySelectorAll('.nav-tab').forEach(function(tab) {{
  tab.addEventListener('click', function() {{
    var id = this.getAttribute('data-page');
    document.querySelectorAll('.page').forEach(function(p) {{ p.classList.remove('active'); }});
    document.querySelectorAll('.nav-tab').forEach(function(t) {{ t.classList.remove('active'); }});
    document.getElementById('page-' + id).classList.add('active');
    this.classList.add('active');
    // Lazy-init D3 graph only when that tab is first opened
    if (id === 'depgraph' && !graphInited) {{
      graphInited = true;
      initDepGraph();
    }}
  }});
}});

// ── D3 dependency graph ─────────────────────────────────────────────────────
function initDepGraph() {{
  var el = document.getElementById('dep-graph');
  if (!el || !window.d3) return;
  var raw = el.getAttribute('data-graph');
  if (!raw) return;
  var G;
  try {{ G = JSON.parse(raw); }} catch(e) {{ return; }}
  if (!G.nodes || !G.nodes.length) return;

  var W = el.clientWidth || 900;
  var H = 480;
  var svg = d3.select(el).append('svg').attr('width','100%').attr('height',H);
  var g   = svg.append('g');

  svg.call(d3.zoom().scaleExtent([0.2,4]).on('zoom', function(e) {{
    g.attr('transform', e.transform);
  }}));

  var sim = d3.forceSimulation(G.nodes)
    .force('link',    d3.forceLink(G.links).id(function(d){{return d.id;}}).distance(80))
    .force('charge',  d3.forceManyBody().strength(-120))
    .force('center',  d3.forceCenter(W/2, H/2))
    .force('collide', d3.forceCollide(18));

  svg.append('defs').append('marker')
    .attr('id','arrow').attr('viewBox','0 -5 10 10')
    .attr('refX',20).attr('refY',0)
    .attr('markerWidth',6).attr('markerHeight',6)
    .attr('orient','auto')
    .append('path').attr('d','M0,-5L10,0L0,5').attr('fill','#2a3040');

  var link = g.append('g').selectAll('line').data(G.links).join('line')
    .attr('stroke','#2a3040').attr('stroke-width',1.2)
    .attr('marker-end','url(#arrow)');

  var color = d3.scaleSequential(d3.interpolateCool)
    .domain([0, d3.max(G.nodes, function(d){{return d.in;}}) || 1]);

  var node = g.append('g').selectAll('circle').data(G.nodes).join('circle')
    .attr('r', function(d){{ return 5 + Math.sqrt(d.in + d.out) * 2; }})
    .attr('fill', function(d){{ return color(d.in); }})
    .attr('stroke','#1a2030').attr('stroke-width',1.5)
    .call(d3.drag()
      .on('start', function(e,d){{ if(!e.active) sim.alphaTarget(0.3).restart(); d.fx=d.x; d.fy=d.y; }})
      .on('drag',  function(e,d){{ d.fx=e.x; d.fy=e.y; }})
      .on('end',   function(e,d){{ if(!e.active) sim.alphaTarget(0); d.fx=null; d.fy=null; }}));

  node.append('title').text(function(d){{ return d.name + '\nin: ' + d.in + '  out: ' + d.out; }});

  var label = g.append('g').selectAll('text').data(G.nodes).join('text')
    .text(function(d){{ return d.name.split('/').pop().split('\\').pop(); }})
    .attr('font-size', 9).attr('fill','#8899bb').attr('dx',10).attr('dy',3);

  sim.on('tick', function() {{
    link.attr('x1',function(d){{return d.source.x;}}).attr('y1',function(d){{return d.source.y;}})
        .attr('x2',function(d){{return d.target.x;}}).attr('y2',function(d){{return d.target.y;}});
    node.attr('cx',function(d){{return d.x;}}).attr('cy',function(d){{return d.y;}});
    label.attr('x',function(d){{return d.x;}}).attr('y',function(d){{return d.y;}});
  }});
}}

// ── Charts ──────────────────────────────────────────────────────────────────
var LL={lang_labels}, LD={lang_data};
var DL={donut_labels}, DD={donut_data};
var P=['#38bdf8','#34d399','#a78bfa','#fbbf24','#f87171','#fb923c','#22d3ee','#86efac','#c4b5fd','#fde68a','#f9a8d4','#6ee7b7'];

if (window.Chart) {{
  Chart.defaults.color='#4a5568';
  Chart.defaults.font.family="'IBM Plex Mono',monospace";
  Chart.defaults.font.size=11;

  new Chart(document.getElementById('langChart'),{{
    type:'bar',
    data:{{labels:LL,datasets:[{{label:'LOC',data:LD,backgroundColor:P.slice(0,LD.length),borderRadius:4,borderSkipped:false}}]}},
    options:{{responsive:true,plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{label:function(c){{return ' '+c.parsed.y.toLocaleString()+' lines';}}}}}}}},
      scales:{{x:{{grid:{{color:'#1e2330'}},ticks:{{maxRotation:45}}}},y:{{grid:{{color:'#1e2330'}},ticks:{{callback:function(v){{return v>=1000?(v/1000).toFixed(1)+'k':v;}}}}}}}}
  }});

  new Chart(document.getElementById('donutChart'),{{
    type:'doughnut',
    data:{{labels:DL,datasets:[{{data:DD,backgroundColor:['#34d399','#fbbf24','#1e2330'],borderWidth:0,hoverOffset:6}}]}},
    options:{{responsive:true,cutout:'68%',plugins:{{
      legend:{{position:'bottom',labels:{{padding:16,usePointStyle:true}}}},
      tooltip:{{callbacks:{{label:function(c){{return ' '+c.label+': '+c.parsed.toLocaleString()+' lines';}}}}}}
    }}}}
  }});
}}

}}); // end window load
</script>
</body>
</html>"""