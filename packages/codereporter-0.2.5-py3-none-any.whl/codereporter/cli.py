"""
CLI entry point for codereporter.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import webbrowser

from . import __version__
from .analyser import count_code_stats
from .reporter import build_html


def _step(label: str, fn, *args, **kwargs):
    print(f"  ⠿  {label} ...", end="", flush=True)
    t0  = time.monotonic()
    res = fn(*args, **kwargs)
    ms  = int((time.monotonic() - t0) * 1000)
    print(f"\r  ✓  {label:<42} {ms:>5} ms")
    return res


def _print_summary(s: dict) -> None:
    width = 64
    print()
    print("═" * width)
    print(f"  CODE REPORT — {os.path.basename(s['root'])}")
    print("═" * width)
    print(f"  {'Files analysed':<26}: {s['files']:>10,}")
    print(f"  {'Total lines (LOC)':<26}: {s['loc']:>10,}")
    print(f"  {'Code lines':<26}: {s['code']:>10,}")
    print(f"  {'Comment lines':<26}: {s['comments']:>10,}")
    print(f"  {'Blank lines':<26}: {s['blank']:>10,}")
    print(f"  {'Functions':<26}: {s['functions']:>10,}  ({s['async_functions']} async)")
    print(f"  {'Classes':<26}: {s['classes']:>10,}")
    print(f"  {'Endpoints':<26}: {s['endpoints']:>10,}")
    print(f"  {'TODOs / FIXMEs':<26}: {s['todos']:>10,}")
    print(f"  {'Long lines (>100ch)':<26}: {s['long_lines']:>10,}")
    print("═" * width)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="codereporter",
        description="Generate an HTML code-intelligence report for any repo.",
    )
    parser.add_argument("path", nargs="?", default=".", help="Root directory to analyse")
    parser.add_argument("-o", "--output", default="code_report.html", metavar="FILE")
    parser.add_argument("--no-open",       action="store_true")
    parser.add_argument("--json",          action="store_true")
    parser.add_argument("--no-duplicates", action="store_true")
    parser.add_argument("--no-dead-code",  action="store_true")
    parser.add_argument("--no-graph",      action="store_true")
    parser.add_argument("--no-churn",      action="store_true")
    parser.add_argument("--fast",          action="store_true", help="Skip all advanced analyses")
    parser.add_argument("--version", action="version", version=f"codereporter {__version__}")

    args = parser.parse_args(argv)
    root = os.path.abspath(args.path)

    if not os.path.isdir(root):
        print(f"[error] Not a directory: {root}", file=sys.stderr)
        return 1

    fast       = args.fast
    run_dups   = not (fast or args.no_duplicates)
    run_dead   = not (fast or args.no_dead_code)
    run_graph  = not (fast or args.no_graph)
    run_churn  = not (fast or args.no_churn)

    print(f"\n[codereporter v{__version__}] Analysing: {root}\n")

    data = _step("Scanning files & counting stats", count_code_stats, root, args.output)
    _print_summary(data["summary"])
    print()

    dup_clusters = []
    dead_report  = None
    dep_graph    = None
    churn_report = None

    if run_dups:
        from .duplicate_detector import detect_duplicates
        dup_clusters = _step("Detecting duplicate code blocks", detect_duplicates, root, output_filename=args.output)
        print(f"     → {len(dup_clusters)} duplicate cluster(s) found")

    if run_dead:
        from .dead_code_detector import detect_dead_code
        dead_report = _step("Detecting dead code (unused symbols)", detect_dead_code, root, output_filename=args.output)
        print(f"     → {dead_report.dead_count} potentially unused symbol(s)")

    if run_graph:
        from .dependency_graph import build_dependency_graph
        dep_graph = _step("Building dependency graph", build_dependency_graph, root, output_filename=args.output)
        g = dep_graph.summary()
        print(f"     → {g['edges']} import edges, {g['cycles']} circular import(s)")

    if run_churn:
        from .churn_analyser import analyse_churn
        churn_report = _step("Analysing git code churn", analyse_churn, root)
        if not churn_report.git_available:
            print(f"     → git not available: {churn_report.git_error}")
        else:
            print(f"     → {churn_report.total_commits} commits, {len(churn_report.files)} files tracked")

    print()
    html_path = os.path.join(root, args.output)
    html = _step(
        "Rendering HTML report",
        build_html, data,
        dup_clusters=dup_clusters,
        dead_report=dead_report,
        dep_graph=dep_graph,
        churn_report=churn_report,
    )

    with open(html_path, "w", encoding="utf-8") as fh:
        fh.write(html)

    if args.json:
        import json
        json_path = html_path.replace(".html", ".json")
        with open(json_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, default=str)
        print(f"\n  JSON  →  {json_path}")

    print(f"\n  Report →  {html_path}")

    if not args.no_open:
        url = "file://" + html_path.replace("\\", "/")
        webbrowser.open(url)
        print("  Opened in browser.")

    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())