"""
Duplicate Code Detector
=======================
Finds copy-pasted blocks across files using a sliding-window fingerprint approach.

Algorithm
---------
1. Normalise every non-blank, non-comment line (strip whitespace, collapse runs).
2. Build a sliding window of MIN_LINES consecutive normalised lines per file.
3. Hash each window with a fast hash (hashlib MD5).
4. Group windows that share the same hash → duplicate blocks.
5. Merge adjacent/overlapping windows in the same file to produce clean ranges.

Complexity: O(N) in total lines — suitable for large repos.
"""

from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from .constants import TEXT_EXT, IGNORE_DIRS, SINGLE_COMMENT, MULTI_START, MULTI_END, IGNORE_FILES

# ── Tuning ────────────────────────────────────────────────────────────────────
MIN_LINES   = 6   # minimum block size to consider a duplicate
MAX_LINES   = 50  # cap shown context lines
_WS         = re.compile(rb"\s+")


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class DupOccurrence:
    file:       str
    start_line: int
    end_line:   int
    preview:    str   # first non-blank line of the block, decoded

@dataclass
class DupCluster:
    hash:        str
    block_lines: int                          # size of the fingerprint window
    occurrences: list[DupOccurrence] = field(default_factory=list)

    @property
    def file_count(self) -> int:
        return len({o.file for o in self.occurrences})

    @property
    def severity(self) -> str:
        lines = self.block_lines
        if lines >= 20: return "high"
        if lines >= 10: return "medium"
        return "low"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _normalise(line: bytes) -> bytes:
    """Strip and collapse whitespace — makes indentation-agnostic comparison."""
    return _WS.sub(b" ", line.strip()).lower()


def _is_noise(line: bytes) -> bool:
    """Return True for lines that shouldn't anchor a duplicate block."""
    s = line.strip()
    if not s:
        return True
    if SINGLE_COMMENT.match(s):
        return True
    # single-token lines like `pass`, `}`, `{`, `end`
    if len(s) <= 4:
        return True
    return False


def _read_normalised(path: str) -> list[tuple[int, bytes, str]]:
    """
    Read a file and return a list of (lineno, normalised_bytes, raw_preview)
    for every non-noise line, skipping multi-line comment bodies.
    """
    try:
        raw_lines = Path(path).read_bytes().splitlines()
    except OSError:
        return []

    result       = []
    in_multiline = False

    for i, raw in enumerate(raw_lines, 1):
        stripped = raw.strip()

        if in_multiline:
            if MULTI_END.search(stripped):
                in_multiline = False
            continue

        if MULTI_START.search(stripped):
            if not MULTI_END.search(stripped):
                in_multiline = True
            continue

        if _is_noise(raw):
            continue

        norm    = _normalise(raw)
        preview = raw.decode("utf-8", errors="replace").strip()
        result.append((i, norm, preview))

    return result


def _fingerprint(window: list[bytes]) -> str:
    h = hashlib.md5(b"\n".join(window), usedforsecurity=False)
    return h.hexdigest()


def _merge_ranges(ranges: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """Merge overlapping (start, end) ranges."""
    if not ranges:
        return []
    out = [sorted(ranges, key=lambda r: r[0])[0]]
    for s, e in sorted(ranges, key=lambda r: r[0])[1:]:
        if s <= out[-1][1] + 1:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


# ── Main entry point ──────────────────────────────────────────────────────────

def detect_duplicates(root: str, min_lines: int = MIN_LINES, output_filename: str = 'code_report.html') -> list[DupCluster]:
    """
    Walk *root* and return a list of DupCluster objects, sorted by severity
    (largest blocks first, then by number of occurrences).

    Parameters
    ----------
    root      : repository root path
    min_lines : minimum duplicate block size (default 6)
    """
    import os

    # ── 1. Build fingerprint index ────────────────────────────────────────────
    # hash → list of (file_rel, logical_lineno_start, logical_lineno_end, preview)
    index: dict[str, list[tuple[str, int, int, str]]] = defaultdict(list)

    for dirpath, dirs, filenames in os.walk(root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]

        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in TEXT_EXT:
                continue
            if fname in IGNORE_FILES or fname == output_filename:
                continue

            fpath = os.path.join(dirpath, fname)
            rel   = os.path.relpath(fpath, root)
            lines = _read_normalised(fpath)

            if len(lines) < min_lines:
                continue

            # sliding window
            norms    = [l[1] for l in lines]
            linenos  = [l[0] for l in lines]
            previews = [l[2] for l in lines]

            for i in range(len(lines) - min_lines + 1):
                window  = norms[i:i + min_lines]
                fp      = _fingerprint(window)
                start   = linenos[i]
                end     = linenos[i + min_lines - 1]
                preview = previews[i]
                index[fp].append((rel, start, end, preview))

    # ── 2. Keep only hashes that appear in >1 location ────────────────────────
    clusters: list[DupCluster] = []

    for fp, occurrences in index.items():
        if len(occurrences) < 2:
            continue

        # de-duplicate: same file + overlapping ranges → merge
        by_file: dict[str, list[tuple[int, int, str]]] = defaultdict(list)
        for (rel, s, e, prev) in occurrences:
            by_file[rel].append((s, e, prev))

        merged_occurrences: list[DupOccurrence] = []
        for rel, ranges_previews in by_file.items():
            ranges  = [(s, e) for s, e, _ in ranges_previews]
            preview = ranges_previews[0][2]
            merged  = _merge_ranges(ranges)
            for (ms, me) in merged:
                merged_occurrences.append(
                    DupOccurrence(file=rel, start_line=ms, end_line=me, preview=preview)
                )

        # must appear in at least 2 distinct files OR 2 distinct ranges
        total_locs = len(merged_occurrences)
        distinct_files = len({o.file for o in merged_occurrences})
        if total_locs < 2:
            continue

        clusters.append(DupCluster(
            hash=fp,
            block_lines=min_lines,
            occurrences=merged_occurrences,
        ))

    # ── 3. Deduplicate clusters that are subsets of larger ones ───────────────
    # Sort by block size desc so we keep the largest window per location group
    clusters.sort(key=lambda c: c.block_lines, reverse=True)

    seen_pairs: set[frozenset] = set()
    deduped: list[DupCluster] = []
    for c in clusters:
        key = frozenset((o.file, o.start_line) for o in c.occurrences)
        if key in seen_pairs:
            continue
        seen_pairs.add(key)
        deduped.append(c)

    # ── 4. Final sort: severity desc, then occurrence count desc ──────────────
    severity_rank = {"high": 0, "medium": 1, "low": 2}
    deduped.sort(
        key=lambda c: (severity_rank[c.severity], -len(c.occurrences))
    )

    return deduped[:200]   # cap at 200 clusters for HTML sanity


def duplicate_summary(clusters: list[DupCluster]) -> dict:
    """Return a compact summary dict for the HTML report header."""
    if not clusters:
        return {"total": 0, "high": 0, "medium": 0, "low": 0, "files_affected": 0}

    files_affected = len({o.file for c in clusters for o in c.occurrences})
    return {
        "total":          len(clusters),
        "high":           sum(1 for c in clusters if c.severity == "high"),
        "medium":         sum(1 for c in clusters if c.severity == "medium"),
        "low":            sum(1 for c in clusters if c.severity == "low"),
        "files_affected": files_affected,
    }