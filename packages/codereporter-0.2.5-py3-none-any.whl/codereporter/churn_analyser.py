"""
Code Churn Analyser
===================
Uses `git log` to measure how frequently each file has been modified.

Metrics collected per file
--------------------------
- commit_count   : total commits touching the file
- authors        : set of unique authors
- first_seen     : date of first commit
- last_modified  : date of most recent commit
- age_days       : calendar days since first commit
- churn_rate     : commits per 30 days (normalised velocity)
- lines_added    : cumulative lines added
- lines_deleted  : cumulative lines deleted
- churn_score    : composite risk score (higher = riskier)

Churn Score Formula
-------------------
  churn_score = (commit_count * 2) + (authors * 3) + (lines_changed / 100)

Files with high churn + many authors = highest maintenance risk.

Graceful degradation
--------------------
If git is not available or the directory is not a git repo, returns an
empty ChurnReport with `git_available=False` so the rest of the report
still works.
"""

from __future__ import annotations

import os
import re
import subprocess
import datetime
from dataclasses import dataclass, field
from collections import defaultdict


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class FileChurn:
    path:          str
    commit_count:  int
    authors:       list[str]
    first_seen:    str        # ISO date string
    last_modified: str        # ISO date string
    age_days:      int
    lines_added:   int
    lines_deleted: int
    churn_rate:    float      # commits per 30 days
    churn_score:   float      # composite risk

    @property
    def lines_changed(self) -> int:
        return self.lines_added + self.lines_deleted

    @property
    def risk_level(self) -> str:
        if self.churn_score >= 40:  return "high"
        if self.churn_score >= 15:  return "medium"
        return "low"

    @property
    def author_count(self) -> int:
        return len(self.authors)


@dataclass
class ChurnReport:
    files:         list[FileChurn] = field(default_factory=list)
    git_available: bool            = True
    git_error:     str             = ""
    repo_age_days: int             = 0
    total_commits: int             = 0
    top_authors:   list[tuple[str, int]] = field(default_factory=list)  # (author, commits)

    def summary(self) -> dict:
        if not self.files:
            return {
                "git_available": self.git_available,
                "error": self.git_error,
                "files": 0, "high": 0, "medium": 0, "low": 0,
                "total_commits": 0, "repo_age_days": 0,
            }
        return {
            "git_available": self.git_available,
            "error":         self.git_error,
            "files":         len(self.files),
            "high":          sum(1 for f in self.files if f.risk_level == "high"),
            "medium":        sum(1 for f in self.files if f.risk_level == "medium"),
            "low":           sum(1 for f in self.files if f.risk_level == "low"),
            "total_commits": self.total_commits,
            "repo_age_days": self.repo_age_days,
        }


# ── Git helpers ───────────────────────────────────────────────────────────────

def _run(cmd: list[str], cwd: str, timeout: int = 30) -> tuple[bool, str]:
    """Run a subprocess and return (success, stdout)."""
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        return result.returncode == 0, result.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
        return False, str(e)


def _git_available(root: str) -> tuple[bool, str]:
    ok, _ = _run(["git", "rev-parse", "--is-inside-work-tree"], root)
    if not ok:
        return False, "Not a git repository or git not installed."
    return True, ""


def _parse_date(raw: str) -> str:
    """Normalise git date to YYYY-MM-DD."""
    raw = raw.strip()
    try:
        dt = datetime.datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return raw[:10] if len(raw) >= 10 else raw


def _days_between(d1: str, d2: str) -> int:
    try:
        a = datetime.date.fromisoformat(d1)
        b = datetime.date.fromisoformat(d2)
        return abs((b - a).days)
    except ValueError:
        return 0


# ── Core analysis ─────────────────────────────────────────────────────────────

def analyse_churn(root: str, max_files: int = 100) -> ChurnReport:
    """
    Run git log on *root* and return a ChurnReport.

    Parameters
    ----------
    root      : absolute path to the git repository root
    max_files : cap the number of files returned (sorted by churn_score desc)
    """
    avail, err = _git_available(root)
    if not avail:
        return ChurnReport(git_available=False, git_error=err)

    # ── 1. Get all commits with stats (numstat) ───────────────────────────────
    # Format: hash | author | date
    # Followed by numstat lines: added\tdeleted\tfilename
    ok, log_out = _run(
        ["git", "log", "--numstat", "--format=%H|%aN|%aI", "--no-merges"],
        root,
        timeout=60,
    )
    if not ok:
        return ChurnReport(git_available=False, git_error="git log failed")

    # ── 2. Parse the log ──────────────────────────────────────────────────────
    per_file: dict[str, dict] = defaultdict(lambda: {
        "commits": set(),
        "authors": set(),
        "dates":   [],
        "added":   0,
        "deleted": 0,
    })
    author_commits: dict[str, set] = defaultdict(set)

    current_hash   = ""
    current_author = ""
    current_date   = ""

    for line in log_out.splitlines():
        line = line.rstrip()

        if "|" in line and len(line) < 200:
            parts = line.split("|", 2)
            if len(parts) == 3 and len(parts[0]) == 40:
                current_hash, current_author, current_date = parts
                current_date = _parse_date(current_date)
                author_commits[current_author].add(current_hash)
                continue

        # numstat line: "12\t3\tpath/to/file"
        parts = line.split("\t", 2)
        if len(parts) == 3 and parts[0].isdigit():
            added_s, deleted_s, fpath = parts
            # skip binary files (shown as "-")
            if not added_s.isdigit():
                continue
            d = per_file[fpath]
            d["commits"].add(current_hash)
            d["authors"].add(current_author)
            d["dates"].append(current_date)
            d["added"]   += int(added_s)
            d["deleted"]  += int(deleted_s)

    # ── 3. Compute per-file metrics ───────────────────────────────────────────
    today     = datetime.date.today().isoformat()
    results: list[FileChurn] = []

    for fpath, d in per_file.items():
        if not d["commits"]:
            continue

        dates        = sorted(d["dates"])
        first_seen   = dates[0]  if dates else today
        last_mod     = dates[-1] if dates else today
        age_days     = max(1, _days_between(first_seen, today))
        commit_count = len(d["commits"])
        churn_rate   = round(commit_count / age_days * 30, 2)
        authors      = sorted(d["authors"])

        churn_score = round(
            (commit_count * 2) +
            (len(authors)  * 3) +
            ((d["added"] + d["deleted"]) / 100),
            1
        )

        results.append(FileChurn(
            path=fpath,
            commit_count=commit_count,
            authors=authors,
            first_seen=first_seen,
            last_modified=last_mod,
            age_days=age_days,
            lines_added=d["added"],
            lines_deleted=d["deleted"],
            churn_rate=churn_rate,
            churn_score=churn_score,
        ))

    # ── 4. Sort and trim ──────────────────────────────────────────────────────
    results.sort(key=lambda f: f.churn_score, reverse=True)
    results = results[:max_files]

    # ── 5. Repo-level stats ───────────────────────────────────────────────────
    all_dates: list[str] = []
    for d in per_file.values():
        all_dates.extend(d["dates"])
    repo_age = _days_between(min(all_dates), today) if all_dates else 0

    total_commits = len({
        c for d in per_file.values() for c in d["commits"]
    })

    top_authors = sorted(
        [(a, len(cs)) for a, cs in author_commits.items()],
        key=lambda x: x[1], reverse=True
    )[:10]

    return ChurnReport(
        files=results,
        git_available=True,
        repo_age_days=repo_age,
        total_commits=total_commits,
        top_authors=top_authors,
    )