"""
Dependency Graph Builder
========================
Builds a directed import graph across the entire codebase and detects:

- Which files import which (directed edges)
- Circular import chains (DFS cycle detection)
- Hub files — imported by many others (high in-degree)
- Isolated files — no imports and not imported by anyone

Supports: Python (import / from…import), JS/TS (import…from, require())
"""

from __future__ import annotations

import os
import re
from collections import defaultdict
from dataclasses import dataclass, field

from .constants import TEXT_EXT, IGNORE_DIRS, IGNORE_FILES

# ── Import extraction patterns ────────────────────────────────────────────────
_PY_IMPORT_FROM = re.compile(rb"^\s*from\s+(\.{0,3})([\w.]*)\s+import")
_PY_IMPORT      = re.compile(rb"^\s*import\s+([\w.,\s]+)")
_JS_FROM        = re.compile(rb"""^\s*(?:import|export).*?from\s+['"](\.{1,2}[^'"]+)['"]""")
_JS_REQUIRE     = re.compile(rb"""require\s*\(\s*['"](\.{1,2}[^'"]+)['"]\s*\)""")
_JS_DYN_IMPORT  = re.compile(rb"""import\s*\(\s*['"](\.{1,2}[^'"]+)['"]\s*\)""")

_PY_EXTS = frozenset((".py", ".pyw"))
_JS_EXTS = frozenset((".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs", ".vue", ".svelte"))


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class GraphEdge:
    source: str   # relative file path
    target: str   # relative file path (resolved) or raw module name
    raw:    str   # the original import statement


@dataclass
class CircularChain:
    cycle: list[str]

    def __str__(self) -> str:
        return " → ".join(self.cycle) + " → " + self.cycle[0]


@dataclass
class DependencyGraph:
    edges:           list[GraphEdge]        = field(default_factory=list)
    adj:             dict[str, list[str]]   = field(default_factory=dict)
    radj:            dict[str, list[str]]   = field(default_factory=dict)
    files:           list[str]              = field(default_factory=list)
    cycles:          list[CircularChain]    = field(default_factory=list)
    hubs:            list[tuple[str, int]]  = field(default_factory=list)
    isolated:        list[str]              = field(default_factory=list)
    imports_map:     dict[str, list[str]]   = field(default_factory=dict)
    imported_by_map: dict[str, list[str]]   = field(default_factory=dict)

    def summary(self) -> dict:
        return {
            "files":    len(self.files),
            "edges":    len(self.edges),
            "cycles":   len(self.cycles),
            "hubs":     len(self.hubs),
            "isolated": len(self.isolated),
        }

    def to_json_graph(self) -> dict:
        """Compact node/link structure for D3 force graph."""
        node_index = {f: i for i, f in enumerate(self.files)}
        nodes = [
            {
                "id":   i,
                "name": f,
                "in":   len(self.imported_by_map.get(f, [])),
                "out":  len(self.imports_map.get(f, [])),
            }
            for i, f in enumerate(self.files)
        ]
        links = []
        seen: set[tuple[int, int]] = set()
        for e in self.edges:
            s = node_index.get(e.source)
            t = node_index.get(e.target)
            if s is None or t is None:
                continue
            if (s, t) not in seen:
                seen.add((s, t))
                links.append({"source": s, "target": t})
        return {"nodes": nodes, "links": links}


# ── Import resolution helpers ─────────────────────────────────────────────────

def _resolve_py(module: str, source_rel: str, root: str, all_files: set[str]) -> str | None:
    """Resolve a Python module string to a relative file path, or None."""
    parts = module.lstrip(".").replace(".", os.sep)
    base  = os.path.dirname(source_rel)

    if module.startswith("."):
        dot_count = len(module) - len(module.lstrip("."))
        up = base
        for _ in range(dot_count - 1):
            up = os.path.dirname(up)
        candidates = [
            os.path.join(up, parts + ".py"),
            os.path.join(up, parts, "__init__.py"),
        ]
    else:
        candidates = [
            os.path.join(root, parts + ".py"),
            os.path.join(root, parts, "__init__.py"),
            os.path.join(base,  parts + ".py"),
            os.path.join(base,  parts, "__init__.py"),
        ]

    for c in candidates:
        rel = os.path.relpath(c, root)
        if rel in all_files:
            return rel
    return None


def _resolve_js(spec: str, source_rel: str, root: str, all_files: set[str]) -> str | None:
    """Resolve a JS/TS relative specifier to a relative file path, or None."""
    base = os.path.dirname(os.path.join(root, source_rel))
    raw  = os.path.normpath(os.path.join(base, spec))
    for ext in ("", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".vue", ".svelte",
                "/index.ts", "/index.js", "/index.tsx", "/index.jsx"):
        rel = os.path.relpath(raw + ext, root)
        if rel in all_files:
            return rel
    return None


def _record(
    source: str, target: str, raw_str: str,
    all_files: set[str],
    raw_edges: list, adj: dict, radj: dict, imports_map: dict,
) -> None:
    """Append one resolved edge to all tracking structures."""
    raw_edges.append(GraphEdge(source=source, target=target, raw=raw_str))
    if target in all_files:
        adj[source].append(target)
        radj[target].append(source)
        imports_map[source].append(target)


# ── Cycle detection ───────────────────────────────────────────────────────────

def _find_cycles(adj: dict[str, list[str]]) -> list[CircularChain]:
    """Iterative DFS — returns up to 50 distinct cycles."""
    visited:         set[str]        = set()
    in_stack:        set[str]        = set()
    cycles:          list[CircularChain] = []
    seen_cycle_keys: set[frozenset]  = set()

    def canonical(cycle: list[str]) -> list[str]:
        m = min(range(len(cycle)), key=lambda i: cycle[i])
        return cycle[m:] + cycle[:m]

    for start in sorted(adj):
        if start in visited:
            continue
        stack    = [(start, iter(adj.get(start, [])))]
        path     = [start]
        in_stack.add(start)

        while stack:
            node, neighbours = stack[-1]
            try:
                nxt = next(neighbours)
                if nxt not in adj:
                    continue
                if nxt in in_stack:
                    idx   = path.index(nxt)
                    cycle = canonical(path[idx:])
                    key   = frozenset(cycle)
                    if key not in seen_cycle_keys and len(cycles) < 50:
                        seen_cycle_keys.add(key)
                        cycles.append(CircularChain(cycle=cycle))
                elif nxt not in visited:
                    stack.append((nxt, iter(adj.get(nxt, []))))
                    path.append(nxt)
                    in_stack.add(nxt)
            except StopIteration:
                visited.add(node)
                in_stack.discard(node)
                path.pop()
                stack.pop()

    return cycles


# ── Public API ────────────────────────────────────────────────────────────────

def build_dependency_graph(root: str, output_filename: str = "code_report.html") -> DependencyGraph:
    """
    Walk *root*, parse every import statement, and return a DependencyGraph.
    """

    # ── 1. Collect all source files ───────────────────────────────────────────
    all_files: set[str] = set()
    for dirpath, dirs, filenames in os.walk(root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in TEXT_EXT:
                continue
            if fname in IGNORE_FILES or fname == output_filename:
                continue
            rel = os.path.relpath(os.path.join(dirpath, fname), root)
            all_files.add(rel)

    # ── 2. Parse imports in every file ───────────────────────────────────────
    raw_edges:   list[GraphEdge]       = []
    adj:         dict[str, list[str]] = defaultdict(list)
    radj:        dict[str, list[str]] = defaultdict(list)
    imports_map: dict[str, list[str]] = defaultdict(list)

    for rel in sorted(all_files):
        fpath = os.path.join(root, rel)
        ext   = os.path.splitext(rel)[1].lower()

        try:
            lines = open(fpath, "rb").readlines()
        except OSError:
            continue

        for raw_line in lines:
            stripped = raw_line.strip()
            if not stripped:
                continue
            raw_str = raw_line.decode("utf-8", errors="replace").strip()

            # ── Python ───────────────────────────────────────────────────────
            if ext in _PY_EXTS:

                # "from X import Y"  or  "from .X import Y"
                m = _PY_IMPORT_FROM.match(stripped)
                if m:
                    dots   = m.group(1).decode()
                    module = m.group(2).decode("utf-8", errors="replace")
                    full   = (dots + module) if dots else module
                    if full:
                        resolved = _resolve_py(full, rel, root, all_files)
                        target   = resolved if resolved else (module or dots.rstrip("."))
                        if target:
                            _record(rel, target, raw_str, all_files,
                                    raw_edges, adj, radj, imports_map)
                    continue

                # "import X" or "import X, Y"
                m = _PY_IMPORT.match(stripped)
                if m:
                    for part in m.group(1).decode("utf-8", errors="replace").split(","):
                        module = part.strip().split()[0]   # "X as Y" → "X"
                        if not module:
                            continue
                        resolved = _resolve_py(module, rel, root, all_files)
                        target   = resolved if resolved else module
                        _record(rel, target, raw_str, all_files,
                                raw_edges, adj, radj, imports_map)
                    continue

            # ── JavaScript / TypeScript ───────────────────────────────────────
            elif ext in _JS_EXTS:
                for pat in (_JS_FROM, _JS_REQUIRE, _JS_DYN_IMPORT):
                    m = pat.search(stripped)
                    if m:
                        spec     = m.group(1).decode("utf-8", errors="replace")
                        resolved = _resolve_js(spec, rel, root, all_files)
                        target   = resolved if resolved else spec
                        _record(rel, target, raw_str, all_files,
                                raw_edges, adj, radj, imports_map)
                        break

    # ── 3. Deduplicate ────────────────────────────────────────────────────────
    adj         = {k: list(dict.fromkeys(v)) for k, v in adj.items()}
    radj        = {k: list(dict.fromkeys(v)) for k, v in radj.items()}
    imports_map = {k: list(dict.fromkeys(v)) for k, v in imports_map.items()}

    # ── 4. Cycles ─────────────────────────────────────────────────────────────
    cycles = _find_cycles(adj)

    # ── 5. Hubs (files imported by 2 or more others) ─────────────────────────
    hubs = sorted(
        [(f, len(importers)) for f, importers in radj.items() if len(importers) >= 2],
        key=lambda x: x[1],
        reverse=True,
    )[:20]

    # ── 6. Isolated (no outgoing AND no incoming edges) ───────────────────────
    isolated = [f for f in sorted(all_files) if f not in adj and f not in radj]

    return DependencyGraph(
        edges=raw_edges,
        adj=dict(adj),
        radj=dict(radj),
        files=sorted(all_files),
        cycles=cycles,
        hubs=hubs,
        isolated=isolated,
        imports_map=imports_map,
        imported_by_map=dict(radj),
    )