from .analyser import analyse_file, count_code_stats
from .reporter import build_html
from .duplicate_detector import detect_duplicates, duplicate_summary
from .dead_code_detector import detect_dead_code
from .dependency_graph import build_dependency_graph
from .churn_analyser import analyse_churn

__version__ = "0.2.5"
__all__ = [
    "analyse_file", "count_code_stats", "build_html",
    "detect_duplicates", "duplicate_summary",
    "detect_dead_code",
    "build_dependency_graph",
    "analyse_churn",
]