"""
Dead Code Detector
==================
Finds functions and classes that are defined but never referenced anywhere
else in the codebase.

Approach
--------
1. Collect every function / class name defined across all source files.
2. Build a global "reference index" — every identifier-like token that appears
   anywhere in the codebase (calls, attribute access, type hints, strings…).
3. A symbol is "dead" if its name never appears outside its own definition file,
   OR appears only on definition lines.

Limitations (by design — we stay stdlib-only and fast):
- No type inference or cross-language analysis.
- Private symbols (leading underscore) are flagged separately.
- Dunder methods (__init__, __str__ etc.) are always excluded.
- Entry points (`main`, `run`, `app`, common framework hooks) are excluded.
- Results are heuristic — some false positives are possible in dynamic code.
"""

from __future__ import annotations

import os
import re
from collections import defaultdict
from dataclasses import dataclass, field

from .constants import TEXT_EXT, IGNORE_DIRS, EXT_LANG, IGNORE_FILES

# ── Patterns ──────────────────────────────────────────────────────────────────
_PY_DEF       = re.compile(rb"^\s*(?:async\s+)?def\s+(\w+)\s*\(")
_PY_CLASS     = re.compile(rb"^\s*class\s+(\w+)\s*[:(]")
_JS_FUNC      = re.compile(rb"\bfunction\s+(\w+)\s*\(")
_JS_ARROW     = re.compile(rb"(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(.*?\)\s*=>")
_JS_CLASS     = re.compile(rb"\bclass\s+(\w+)")
_IDENTIFIER   = re.compile(rb"\b([a-zA-Z_]\w{1,79})\b")

# Names that are almost always referenced externally / by frameworks
_ALWAYS_LIVE: set[str] = {
    "main", "run", "app", "create_app", "setup", "teardown",
    "handle", "handler", "middleware", "plugin",
    # pytest
    "conftest", "fixture",
    # Django / Flask / FastAPI lifecycle
    "startup", "shutdown", "lifespan", "on_event",
    # common dunder-adjacent
    "model_post_init", "model_validate",
}

_DUNDER = re.compile(r"^__\w+__$")


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class DeadSymbol:
    name:       str
    kind:       str          # "function" | "class" | "method"
    file:       str
    line:       int
    is_private: bool         # name starts with _

    @property
    def risk(self) -> str:
        """Higher risk = more likely to be truly dead."""
        if not self.is_private:
            return "high"    # public API that's never called = likely real dead code
        return "low"         # private helper — could be intentional


@dataclass
class DeadCodeReport:
    symbols:      list[DeadSymbol] = field(default_factory=list)
    total_defined: int = 0

    @property
    def dead_count(self) -> int:
        return len(self.symbols)

    @property
    def dead_pct(self) -> float:
        if not self.total_defined:
            return 0.0
        return round(self.dead_count / self.total_defined * 100, 1)

    def summary(self) -> dict:
        return {
            "total_defined": self.total_defined,
            "dead_count":    self.dead_count,
            "dead_pct":      self.dead_pct,
            "high_risk":     sum(1 for s in self.symbols if s.risk == "high"),
            "low_risk":      sum(1 for s in self.symbols if s.risk == "low"),
        }


# ── Core logic ────────────────────────────────────────────────────────────────

def _collect_definitions(
    fpath: str, rel: str
) -> list[tuple[str, str, int]]:
    """Return list of (name, kind, lineno) for all defs in the file."""
    defs = []
    try:
        lines = open(fpath, "rb").readlines()
    except OSError:
        return defs

    for i, raw in enumerate(lines, 1):
        s = raw.strip()

        m = _PY_DEF.match(s)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            kind = "function"
            defs.append((name, kind, i))
            continue

        m = _PY_CLASS.match(s)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            defs.append((name, "class", i))
            continue

        m = _JS_FUNC.search(s)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            defs.append((name, "function", i))
            continue

        m = _JS_ARROW.search(s)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            defs.append((name, "function", i))
            continue

        m = _JS_CLASS.search(s)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            defs.append((name, "class", i))

    return defs


def _collect_references(fpath: str) -> set[str]:
    """Return every identifier token present in the file."""
    try:
        content = open(fpath, "rb").read()
    except OSError:
        return set()
    return {m.group(1).decode("utf-8", errors="replace") for m in _IDENTIFIER.finditer(content)}


# ── Public API ────────────────────────────────────────────────────────────────

def detect_dead_code(root: str, output_filename: str = 'code_report.html') -> DeadCodeReport:
    """
    Scan *root* and return a DeadCodeReport listing symbols that appear
    to be defined but never referenced elsewhere.
    """
    # Pass 1 — collect all definitions and all references per file
    definitions: list[tuple[str, str, str, int]] = []   # (name, kind, rel, lineno)
    references_by_file: dict[str, set[str]]       = {}
    global_refs: set[str]                         = set()

    for dirpath, dirs, filenames in os.walk(root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]

        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in TEXT_EXT:
                continue
            if fname in IGNORE_FILES or fname == output_filename:
                continue

            fpath = os.path.join(dirpath, fname)
            rel   = os.path.relpath(fpath, root)

            defs = _collect_definitions(fpath, rel)
            refs = _collect_references(fpath)

            for name, kind, lineno in defs:
                definitions.append((name, kind, rel, lineno))

            references_by_file[rel] = refs
            global_refs |= refs

    total_defined = len(definitions)

    # Pass 2 — build a set of names that appear in ANY file's reference set
    # A name is "referenced" if it appears outside its own definition file,
    # or appears more than once inside (once = the def line itself).
    def_names_by_file: dict[str, set[str]] = defaultdict(set)
    for name, kind, rel, lineno in definitions:
        def_names_by_file[rel].add(name)

    dead_symbols: list[DeadSymbol] = []

    seen: set[tuple[str, str]] = set()   # (name, rel) dedup

    for name, kind, rel, lineno in definitions:
        # Skip dunders
        if _DUNDER.match(name):
            continue
        # Skip known live entry points
        if name in _ALWAYS_LIVE:
            continue
        # Skip very short names (likely local vars that leaked through)
        if len(name) < 3:
            continue

        key = (name, rel)
        if key in seen:
            continue
        seen.add(key)

        # Check if name appears in any OTHER file's tokens
        referenced_elsewhere = any(
            name in refs
            for frel, refs in references_by_file.items()
            if frel != rel
        )
        if referenced_elsewhere:
            continue

        # Check if name appears more than once in its own file
        # (once = just the def keyword; twice+ = also called/used)
        own_content = b""
        try:
            own_content = open(os.path.join(root, rel), "rb").read()
        except OSError:
            pass
        own_occurrences = len(re.findall(rb"\b" + name.encode() + rb"\b", own_content))
        if own_occurrences >= 3:   # def line + maybe decorator + at least one call
            continue

        dead_symbols.append(DeadSymbol(
            name=name,
            kind=kind,
            file=rel,
            line=lineno,
            is_private=name.startswith("_"),
        ))

    # Sort: high risk first, then by file
    dead_symbols.sort(key=lambda s: (0 if s.risk == "high" else 1, s.file, s.line))

    return DeadCodeReport(symbols=dead_symbols[:300], total_defined=total_defined)