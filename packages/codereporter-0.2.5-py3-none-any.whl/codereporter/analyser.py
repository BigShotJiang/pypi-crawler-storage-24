"""
Core analysis engine: per-file stats and full-repo aggregation.
"""

import os
import datetime
from collections import defaultdict

from .constants import (
    IGNORE_FILES,
    SINGLE_COMMENT, MULTI_START, MULTI_END,
    PY_DEF, PY_ASYNC_DEF, CLASS_DEF,
    JS_FUNC, ARROW_FUNC,
    ENDPOINT_DEC, ADD_API_ROUTE, EXPRESS_ROUTE,
    TODO_COMMENT, IMPORT_PY, IMPORT_JS, REQUIRE_JS,
    LONG_LINE_LIMIT, TEXT_EXT, IGNORE_DIRS, EXT_LANG,
)


# ─────────────────────────────────────────────────────────────────────────────
#  Per-file analysis
# ─────────────────────────────────────────────────────────────────────────────

def analyse_file(path: str) -> dict | None:
    """
    Parse a single source file and return a stat dict, or None on read error.

    Returns
    -------
    dict with keys:
        loc, blank, comments, code, functions, async_functions, classes,
        endpoints, imports, todos, long_lines, max_line_len
    """
    try:
        with open(path, "rb") as fh:
            lines = fh.readlines()
    except OSError:
        return None

    stat: dict = {
        "loc": len(lines),
        "blank": 0,
        "comments": 0,
        "code": 0,
        "functions": [],        # list of {"line": int, "name": str, "async": bool}
        "async_functions": [],  # subset of functions where async=True
        "classes": [],          # list of {"line": int, "name": str}
        "endpoints": [],        # list of {"line": int, "method": str, "raw": str}
        "imports": [],          # unique top-level package names
        "todos": [],            # list of {"line": int, "tag": str, "text": str}
        "long_lines": 0,
        "max_line_len": 0,
    }

    in_multiline = False

    for lineno, raw in enumerate(lines, 1):
        line     = raw.rstrip(b"\r\n")
        stripped = line.strip()

        # ── Blank ────────────────────────────────────────────────────────────
        if not stripped:
            stat["blank"] += 1
            continue

        stat["max_line_len"] = max(stat["max_line_len"], len(line))
        if len(line) > LONG_LINE_LIMIT:
            stat["long_lines"] += 1

        # ── TODO / FIXME (scan before comment-skip so we capture the tag) ───
        m = TODO_COMMENT.search(stripped)
        if m:
            stat["todos"].append({
                "line": lineno,
                "text": raw.decode("utf-8", errors="replace").strip(),
                "tag": m.group(1).decode(),
            })

        # ── Multi-line comment continuation ──────────────────────────────────
        if in_multiline:
            stat["comments"] += 1
            if MULTI_END.search(stripped):
                in_multiline = False
            continue

        # ── Single-line comment ───────────────────────────────────────────────
        if SINGLE_COMMENT.match(stripped):
            stat["comments"] += 1
            continue

        # ── Multi-line comment start ──────────────────────────────────────────
        if MULTI_START.search(stripped):
            stat["comments"] += 1
            if not MULTI_END.search(stripped):
                in_multiline = True
            continue

        # ── Code line ────────────────────────────────────────────────────────
        stat["code"] += 1

        # ── Imports ──────────────────────────────────────────────────────────
        for pat in (IMPORT_PY, IMPORT_JS, REQUIRE_JS):
            m = pat.search(stripped)
            if m:
                pkg = (
                    m.group(1)
                    .decode("utf-8", errors="replace")
                    .split(".")[0]
                    .split("/")[0]
                )
                if pkg and pkg not in stat["imports"]:
                    stat["imports"].append(pkg)
                break

        # ── Endpoints ────────────────────────────────────────────────────────
        m = ENDPOINT_DEC.search(stripped)
        if m:
            stat["endpoints"].append({
                "line": lineno,
                "method": m.group(2).decode().upper(),
                "raw": raw.decode("utf-8", errors="replace").strip(),
            })
            continue

        m = ADD_API_ROUTE.search(stripped)
        if m:
            stat["endpoints"].append({
                "line": lineno,
                "method": "ROUTE",
                "raw": raw.decode("utf-8", errors="replace").strip(),
            })
            continue

        m = EXPRESS_ROUTE.search(stripped)
        if m:
            stat["endpoints"].append({
                "line": lineno,
                "method": m.group(2).decode().upper(),
                "raw": raw.decode("utf-8", errors="replace").strip(),
            })
            continue

        # ── Async functions ───────────────────────────────────────────────────
        m = PY_ASYNC_DEF.match(stripped)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            entry = {"line": lineno, "name": name, "async": True}
            stat["async_functions"].append(entry)
            stat["functions"].append(entry)
            continue

        # ── Sync functions ────────────────────────────────────────────────────
        m = PY_DEF.match(stripped)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            stat["functions"].append({"line": lineno, "name": name, "async": False})
            continue

        # ── Classes ───────────────────────────────────────────────────────────
        m = CLASS_DEF.match(stripped)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            stat["classes"].append({"line": lineno, "name": name})
            continue

        # ── JS/TS named functions ─────────────────────────────────────────────
        m = JS_FUNC.search(stripped)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            stat["functions"].append({"line": lineno, "name": name, "async": False})
            continue

        # ── Arrow functions ───────────────────────────────────────────────────
        m = ARROW_FUNC.search(stripped)
        if m:
            name = m.group(1).decode("utf-8", errors="replace")
            stat["functions"].append({"line": lineno, "name": name, "async": False})

    return stat


# ─────────────────────────────────────────────────────────────────────────────
#  Repo-level aggregation
# ─────────────────────────────────────────────────────────────────────────────

def count_code_stats(root: str, output_filename: str = 'code_report.html') -> dict:
    """
    Walk *root* recursively and aggregate code statistics for all source files.

    Parameters
    ----------
    root : str
        Path to the directory to analyse.

    Returns
    -------
    dict with keys:
        summary, by_language, file_details, todos, endpoints, top_imports
    """
    summary: dict = {
        "root": os.path.abspath(root),
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "files": 0,
        "loc": 0,
        "blank": 0,
        "comments": 0,
        "code": 0,
        "functions": 0,
        "async_functions": 0,
        "classes": 0,
        "endpoints": 0,
        "todos": 0,
        "long_lines": 0,
    }

    by_language: dict   = defaultdict(lambda: {
        "files": 0, "loc": 0, "code": 0, "comments": 0,
        "functions": 0, "classes": 0, "endpoints": 0,
    })
    file_details: list  = []
    all_todos: list     = []
    all_endpoints: list = []
    all_imports: dict   = defaultdict(int)

    for dirpath, dirs, filenames in os.walk(root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]

        for fname in sorted(filenames):
            ext = os.path.splitext(fname)[1].lower()
            if ext not in TEXT_EXT:
                continue

            # Skip the report file itself and any known generated outputs
            if fname in IGNORE_FILES or fname == output_filename:
                continue

            fpath = os.path.join(dirpath, fname)
            rel   = os.path.relpath(fpath, root)
            lang  = EXT_LANG.get(ext, ext.lstrip(".").upper())

            stat = analyse_file(fpath)
            if stat is None:
                continue

            # ── Summary totals ────────────────────────────────────────────────
            summary["files"]          += 1
            summary["loc"]            += stat["loc"]
            summary["blank"]          += stat["blank"]
            summary["comments"]       += stat["comments"]
            summary["code"]           += stat["code"]
            summary["functions"]      += len(stat["functions"])
            summary["async_functions"]+= len(stat["async_functions"])
            summary["classes"]        += len(stat["classes"])
            summary["endpoints"]      += len(stat["endpoints"])
            summary["todos"]          += len(stat["todos"])
            summary["long_lines"]     += stat["long_lines"]

            # ── Per-language totals ───────────────────────────────────────────
            bl = by_language[lang]
            bl["files"]     += 1
            bl["loc"]       += stat["loc"]
            bl["code"]      += stat["code"]
            bl["comments"]  += stat["comments"]
            bl["functions"] += len(stat["functions"])
            bl["classes"]   += len(stat["classes"])
            bl["endpoints"] += len(stat["endpoints"])

            # ── Collect todos & endpoints ─────────────────────────────────────
            for t in stat["todos"]:
                all_todos.append({**t, "file": rel})
            for e in stat["endpoints"]:
                all_endpoints.append({**e, "file": rel})

            # ── Import frequency ──────────────────────────────────────────────
            for pkg in stat["imports"]:
                all_imports[pkg] += 1

            # ── File-level record ─────────────────────────────────────────────
            file_details.append({
                "path": rel,
                "lang": lang,
                "ext": ext,
                "loc": stat["loc"],
                "blank": stat["blank"],
                "comments": stat["comments"],
                "code": stat["code"],
                "functions": len(stat["functions"]),
                "classes": len(stat["classes"]),
                "endpoints": len(stat["endpoints"]),
                "todos": len(stat["todos"]),
                "long_lines": stat["long_lines"],
                "max_line_len": stat["max_line_len"],
                "comment_ratio": (
                    round(stat["comments"] / stat["loc"] * 100, 1)
                    if stat["loc"] else 0
                ),
            })

    file_details.sort(key=lambda x: x["loc"], reverse=True)
    top_imports = sorted(all_imports.items(), key=lambda x: x[1], reverse=True)[:20]

    return {
        "summary": summary,
        "by_language": dict(by_language),
        "file_details": file_details,
        "todos": all_todos,
        "endpoints": all_endpoints,
        "top_imports": top_imports,
    }