# llm-trust-guard

**Security guards for LLM-powered applications.** Zero dependencies. Python port of the [npm package](https://www.npmjs.com/package/llm-trust-guard).

## Installation

```bash
pip install llm-trust-guard
```

## Quick Start

```python
from llm_trust_guard import InputSanitizer, EncodingDetector, CompressionDetector

# Check for prompt injection
sanitizer = InputSanitizer(threshold=0.3)
result = sanitizer.sanitize(user_input)
if not result.allowed:
    print(f"Blocked: {result.matches}")

# Check for encoding bypass attacks
encoder = EncodingDetector()
result = encoder.detect(user_input)
if not result.allowed:
    print(f"Encoded threat: {result.violations}")

# Check structural similarity to known attacks (NCD)
detector = CompressionDetector()
result = detector.detect(user_input)
if not result.allowed:
    print(f"Similar to: {result.ncd_analysis.closest_category}")
```

## Guards (Phase 1)

| Guard | Purpose | Method |
|-------|---------|--------|
| `InputSanitizer` | Prompt injection detection (170+ patterns, 11 languages) | Regex + PAP |
| `EncodingDetector` | Encoding bypass (9 formats: Base64, URL, Unicode, Hex, HTML, ROT13, Octal, Base32) | Decode + scan |
| `CompressionDetector` | Structural similarity to known attacks | gzip NCD (135 templates) |
| `HeuristicAnalyzer` | Synonym expansion + structural + statistical analysis | 8 attack categories |
| `OutputFilter` | PII/secret detection and masking in LLM output | Regex + redaction |

## Key Features

- **Zero dependencies** — only Python stdlib (re, zlib, base64, html)
- **Same patterns as the npm package** — feature parity with [llm-trust-guard](https://www.npmjs.com/package/llm-trust-guard) v4.13.1
- **Fast** — all checks complete in <5ms
- **Python 3.9+** compatible

## More Guards Coming

The npm package has 31 guards total. Python Phase 2 will add:
- ExternalDataGuard, AgentSkillGuard, SessionIntegrityGuard
- SchemaValidator, ToolResultGuard, TokenCostGuard

## Links

- [npm package](https://www.npmjs.com/package/llm-trust-guard) (TypeScript — 31 guards)
- [OWASP Top 10 for LLMs 2025](https://genai.owasp.org/resource/owasp-top-10-for-llm-applications-2025/)

## License

MIT
