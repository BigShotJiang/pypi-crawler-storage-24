"""
llm-trust-guard — 31 security guards for LLM-powered applications.

Zero dependencies. Covers OWASP Top 10 for LLMs 2025, Agentic AI 2026, and MCP Security.
"""

# Input Guards
from llm_trust_guard.guards.input_sanitizer import InputSanitizer, SanitizerResult
from llm_trust_guard.guards.encoding_detector import EncodingDetector
from llm_trust_guard.guards.compression_detector import CompressionDetector, CompressionDetectorResult
from llm_trust_guard.guards.heuristic_analyzer import HeuristicAnalyzer, HeuristicResult
from llm_trust_guard.guards.prompt_leakage_guard import PromptLeakageGuard
from llm_trust_guard.guards.conversation_guard import ConversationGuard
from llm_trust_guard.guards.context_budget_guard import ContextBudgetGuard
from llm_trust_guard.guards.multimodal_guard import MultiModalGuard

# Access Control Guards
from llm_trust_guard.guards.tool_registry import ToolRegistry
from llm_trust_guard.guards.policy_gate import PolicyGate
from llm_trust_guard.guards.tenant_boundary import TenantBoundary
from llm_trust_guard.guards.schema_validator import SchemaValidator
from llm_trust_guard.guards.execution_monitor import ExecutionMonitor
from llm_trust_guard.guards.token_cost_guard import TokenCostGuard

# Output Guards
from llm_trust_guard.guards.output_filter import OutputFilter
from llm_trust_guard.guards.output_schema_guard import OutputSchemaGuard
from llm_trust_guard.guards.tool_result_guard import ToolResultGuard

# Agentic Guards
from llm_trust_guard.guards.tool_chain_validator import ToolChainValidator
from llm_trust_guard.guards.agent_communication_guard import AgentCommunicationGuard
from llm_trust_guard.guards.trust_exploitation_guard import TrustExploitationGuard
from llm_trust_guard.guards.autonomy_escalation_guard import AutonomyEscalationGuard
from llm_trust_guard.guards.mcp_security_guard import MCPSecurityGuard
from llm_trust_guard.guards.code_execution_guard import CodeExecutionGuard

# Data Guards
from llm_trust_guard.guards.memory_guard import MemoryGuard
from llm_trust_guard.guards.rag_guard import RAGGuard
from llm_trust_guard.guards.state_persistence_guard import StatePersistenceGuard

# Architectural Guards (v4.13)
from llm_trust_guard.guards.external_data_guard import ExternalDataGuard
from llm_trust_guard.guards.agent_skill_guard import AgentSkillGuard
from llm_trust_guard.guards.session_integrity_guard import SessionIntegrityGuard

# Infrastructure Guards
from llm_trust_guard.guards.circuit_breaker import CircuitBreaker
from llm_trust_guard.guards.drift_detector import DriftDetector

__version__ = "0.2.0"

__all__ = [
    # Input
    "InputSanitizer", "SanitizerResult",
    "EncodingDetector",
    "CompressionDetector", "CompressionDetectorResult",
    "HeuristicAnalyzer", "HeuristicResult",
    "PromptLeakageGuard",
    "ConversationGuard",
    "ContextBudgetGuard",
    "MultiModalGuard",
    # Access Control
    "ToolRegistry",
    "PolicyGate",
    "TenantBoundary",
    "SchemaValidator",
    "ExecutionMonitor",
    "TokenCostGuard",
    # Output
    "OutputFilter",
    "OutputSchemaGuard",
    "ToolResultGuard",
    # Agentic
    "ToolChainValidator",
    "AgentCommunicationGuard",
    "TrustExploitationGuard",
    "AutonomyEscalationGuard",
    "MCPSecurityGuard",
    "CodeExecutionGuard",
    # Data
    "MemoryGuard",
    "RAGGuard",
    "StatePersistenceGuard",
    # Architectural
    "ExternalDataGuard",
    "AgentSkillGuard",
    "SessionIntegrityGuard",
    # Infrastructure
    "CircuitBreaker",
    "DriftDetector",
]
