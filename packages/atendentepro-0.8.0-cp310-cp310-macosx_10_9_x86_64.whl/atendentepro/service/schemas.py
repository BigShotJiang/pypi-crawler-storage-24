# -*- coding: utf-8 -*-
"""Request and response models for the AtendentePro service API."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SetupRequest(BaseModel):
    """Payload for POST /setup — registers or updates a tenant's agent network."""

    tenant_id: str = Field(..., min_length=1)
    yamls: Dict[str, str] = Field(
        ...,
        description="Map of config name to YAML content, e.g. {'flow_config': '...', 'triage_config': '...'}",
    )
    include_agents: Optional[Dict[str, bool]] = Field(
        default=None,
        description=(
            "Agent inclusion overrides. Keys: flow, interview, answer, knowledge, "
            "confirmation, usage, onboarding, escalation, feedback."
        ),
    )
    network_config: Optional[Dict[str, List[str]]] = Field(
        default=None,
        description=(
            "Custom handoff graph. Maps agent name to list of handoff target names. "
            "When set, uses create_custom_network instead of create_standard_network."
        ),
    )


class UserContextPayload(BaseModel):
    """User identity for role-based access filtering."""

    user_id: Optional[str] = None
    role: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class ChatRequest(BaseModel):
    """Payload for POST /chat — sends a message to a tenant's agent network."""

    tenant_id: str = Field(..., min_length=1)
    session_id: str = Field(..., min_length=1)
    message: str = Field(..., min_length=1)
    metadata: Optional[Dict[str, Any]] = None
    user_context: Optional[UserContextPayload] = Field(
        default=None,
        description="User identity for RBAC filtering (user_id, role, metadata).",
    )


class ChatResponse(BaseModel):
    """Response from POST /chat."""

    response: str
    agent_name: Optional[str] = None
    handoff_to: Optional[str] = None


class HealthResponse(BaseModel):
    """Response from GET /health."""

    status: str = "ok"
    version: str
    tenants_loaded: List[str] = Field(default_factory=list)
