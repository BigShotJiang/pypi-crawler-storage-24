# -*- coding: utf-8 -*-
"""Utility modules for AtendentePro library."""

from .openai_client import (
    get_async_client,
    get_provider,
    clear_client_cache,
    AsyncClient,
    Provider,
)
from .tracing import (
    # MonkAI Trace (recommended)
    configure_monkai_trace,
    get_monkai_hooks,
    set_monkai_user,
    set_monkai_input,
    run_with_monkai_tracking,
    # Application Insights (Azure)
    configure_application_insights,
    # Legacy
    configure_tracing,
)
from .user_loader import (
    create_user_loader,
    run_with_user_context,
    extract_phone_from_messages,
    extract_email_from_messages,
    extract_user_id_from_messages,
    load_user_from_csv,
)
from .rate_limiter import RateLimiter, RateLimitExceededError
from .logging_config import configure_logging, JSONFormatter

__all__ = [
    # OpenAI Client
    "get_async_client",
    "get_provider",
    "clear_client_cache",
    "AsyncClient",
    "Provider",
    # MonkAI Trace
    "configure_monkai_trace",
    "get_monkai_hooks",
    "set_monkai_user",
    "set_monkai_input",
    "run_with_monkai_tracking",
    # Application Insights
    "configure_application_insights",
    # Legacy
    "configure_tracing",
    # User Loader
    "create_user_loader",
    "run_with_user_context",
    "extract_phone_from_messages",
    "extract_email_from_messages",
    "extract_user_id_from_messages",
    "load_user_from_csv",
    # Rate Limiter
    "RateLimiter",
    "RateLimitExceededError",
    # Logging
    "configure_logging",
    "JSONFormatter",
]

