"""
edgmo-sdk —— 数据库接口访问 SDK
"""

from .__version__ import __version__

from ._config import configure
from .client import (
    Client,
    list_databases,
    list_tables,
    select,
    stats,
    insert,
    update,
    delete,
)
from .dev_token import get_token, get_headers, verify_token, logout

__all__ = [
    "__version__",
    # 配置
    "configure",
    # 客户端类
    "Client",
    # 模块级便捷函数
    "list_databases",
    "list_tables",
    "select",
    "stats",
    "insert",
    "update",
    "delete",
    # token 工具
    "get_token",
    "get_headers",
    "verify_token",
    "logout",
]
