"""
配置加载器

base_url 和 endpoints 只能通过 sdk.yaml 文件配置。
username / password 支持以下方式（优先级从高到低）：
  1. 运行时调用 configure() 传入的值
  2. 环境变量：EDGMO_SDK_USERNAME / EDGMO_SDK_PASSWORD
  3. sdk.yaml 文件中的 auth 字段

sdk.yaml 查找顺序：
  1. 环境变量 EDGMO_SDK_CONFIG 指定的路径
  2. 当前工作目录 ./sdk.yaml
  3. ~/.edgmo_sdk/sdk.yaml
"""

import os
import threading

_REQUIRED_KEYS = ("base_url", "auth_endpoints", "endpoints")


def _find_config_file() -> str | None:
    candidates = [
        os.environ.get("EDGMO_SDK_CONFIG", ""),
        os.path.join(os.getcwd(), "sdk.yaml"),
        os.path.expanduser("~/.edgmo_sdk/sdk.yaml"),
    ]
    for path in candidates:
        if path and os.path.exists(path):
            return path
    return None


def _load() -> dict:
    config_file = _find_config_file()
    if not config_file:
        raise FileNotFoundError(
            "[edgmo_sdk] 未找到配置文件 sdk.yaml。\n"
            "请在以下位置之一创建该文件：\n"
            "  · 当前工作目录 ./sdk.yaml\n"
            "  · 用户目录 ~/.edgmo_sdk/sdk.yaml\n"
            "  · 或通过环境变量 EDGMO_SDK_CONFIG 指定路径\n"
            "配置文件格式参见 README.md。"
        )

    try:
        import yaml
    except ImportError:
        raise ImportError("读取 sdk.yaml 需要安装 pyyaml：pip install pyyaml")

    with open(config_file, "r", encoding="utf-8") as f:
        file_cfg = yaml.safe_load(f) or {}

    if not isinstance(file_cfg, dict):
        raise ValueError(f"sdk.yaml 格式错误，应为键值映射，实际得到：{type(file_cfg)}")

    for key in _REQUIRED_KEYS:
        if key not in file_cfg:
            raise KeyError(
                f"[edgmo_sdk] sdk.yaml 缺少必填字段：'{key}'"
                f"（必填：base_url / auth_endpoints / endpoints）\n"
                f"配置文件路径：{config_file}"
            )

    token_cfg = file_cfg.get("token") or {}
    if not isinstance(token_cfg, dict):
        token_cfg = {}

    cfg: dict = {
        "base_url": file_cfg["base_url"],
        "auth_endpoints": dict(file_cfg["auth_endpoints"]),
        "endpoints": dict(file_cfg["endpoints"]),
        "auth": {"username": "", "password": ""},
        "token": {
            "cache_file": str(token_cfg.get("cache_file", ".token_cache.json")),
            "expire_buffer": int(token_cfg.get("expire_buffer", 60)),
        },
    }

    if "auth" in file_cfg and isinstance(file_cfg["auth"], dict):
        cfg["auth"].update(file_cfg["auth"])

    # 环境变量仅覆盖认证信息
    if os.environ.get("EDGMO_SDK_USERNAME"):
        cfg["auth"]["username"] = os.environ["EDGMO_SDK_USERNAME"]
    if os.environ.get("EDGMO_SDK_PASSWORD"):
        cfg["auth"]["password"] = os.environ["EDGMO_SDK_PASSWORD"]

    return cfg


class _LazyConfig:
    """
    配置懒加载代理，线程安全。

    import 时不执行任何 I/O；首次通过下标访问配置项时才读取 sdk.yaml。
    使用 RLock 保证懒加载（双重检查）和写操作的线程安全。
    """

    __slots__ = ("_data", "_lock")

    def __init__(self) -> None:
        object.__setattr__(self, "_data", None)
        object.__setattr__(self, "_lock", threading.RLock())

    def _ensure(self) -> dict:
        data = object.__getattribute__(self, "_data")
        if data is None:
            lock = object.__getattribute__(self, "_lock")
            with lock:
                # 双重检查：持有锁后再判断一次，防止多线程同时进入加载
                data = object.__getattribute__(self, "_data")
                if data is None:
                    data = _load()
                    object.__setattr__(self, "_data", data)
        return data

    def __getitem__(self, key: str):
        return self._ensure()[key]

    def __setitem__(self, key: str, value) -> None:
        lock = object.__getattribute__(self, "_lock")
        with lock:
            self._ensure()[key] = value

    def __contains__(self, key: str) -> bool:
        return key in self._ensure()

    def get(self, key: str, default=None):
        return self._ensure().get(key, default)

    def reload(self) -> None:
        """重新从 sdk.yaml 加载配置（切换工作目录或修改文件后可调用）。"""
        lock = object.__getattribute__(self, "_lock")
        with lock:
            object.__setattr__(self, "_data", _load())


# 全局配置对象：import 时不触发任何 I/O，首次访问时才加载
config: _LazyConfig = _LazyConfig()


def configure(
    username: str | None = None,
    password: str | None = None,
) -> None:
    """
    运行时配置认证信息（最高优先级，覆盖文件和环境变量）。

    base_url 和接口地址只能在 sdk.yaml 中配置。

    Args:
        username: 登录用户名
        password: 登录密码

    Example:
        import edgmo_sdk
        edgmo_sdk.configure(username="your_user", password="your_pass")
    """
    lock = object.__getattribute__(config, "_lock")
    with lock:
        auth = config["auth"]  # _ensure() 在锁内执行，RLock 允许同一线程重入
        if username is not None:
            auth["username"] = username
        if password is not None:
            auth["password"] = password
