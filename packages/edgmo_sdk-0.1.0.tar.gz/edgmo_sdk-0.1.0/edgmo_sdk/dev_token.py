"""
Token 工具

使用 RSA+AES-GCM 混合加密登录，token 缓存在 ~/.edgmo_sdk/<cache_file>。
access_token 过期后自动用 refresh_token 静默刷新，refresh_token 也过期时重新登录。
cache_file 和 expire_buffer 可在 sdk.yaml 的 token 节点配置。
"""

import json
import time
import os
import base64
import requests
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from ._config import config

_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".edgmo_sdk")


def _cache_file() -> str:
    return os.path.join(_CACHE_DIR, config["token"]["cache_file"])


def _expire_buffer() -> int:
    return int(config["token"]["expire_buffer"])


def _ensure_cache_dir() -> None:
    os.makedirs(_CACHE_DIR, exist_ok=True)


def _load_cache() -> dict:
    path = _cache_file()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_cache(data: dict) -> None:
    _ensure_cache_dir()
    with open(_cache_file(), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _is_token_valid(cache: dict) -> bool:
    return cache.get("access_token_exp", 0) > time.time() + _expire_buffer()


def _auth_api(name: str) -> str:
    try:
        path = config["auth_endpoints"][name]
    except KeyError:
        raise KeyError(
            f"[edgmo_sdk] sdk.yaml 中未找到认证接口 '{name}'，请检查 auth_endpoints 配置"
        )
    return f"{config['base_url']}{path}"


def _get_public_key() -> str:
    resp = requests.post(_auth_api("publickey"), timeout=10)
    resp.raise_for_status()
    body = resp.json()
    public_key = body.get("publicKey")
    if not public_key:
        raise RuntimeError(f"[edgmo_sdk] 获取公钥失败: {body}")
    return public_key


def _encrypt_login_payload(public_key_pem: str, username: str, password: str) -> str:
    public_key = serialization.load_pem_public_key(public_key_pem.encode())

    aes_key = os.urandom(32)
    iv = os.urandom(12)

    plaintext = json.dumps(
        {"username": username, "password": password, "timestamp": int(time.time())},
        ensure_ascii=False,
    ).encode("utf-8")

    aesgcm = AESGCM(aes_key)
    encrypted = aesgcm.encrypt(iv, plaintext, None)
    ciphertext, tag = encrypted[:-16], encrypted[-16:]

    encrypted_aes_key = public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA512()),
            algorithm=hashes.SHA512(),
            label=None,
        ),
    )

    return base64.b64encode(
        json.dumps(
            {
                "key": base64.b64encode(encrypted_aes_key).decode(),
                "iv": base64.b64encode(iv).decode(),
                "ciphertext": base64.b64encode(ciphertext).decode(),
                "tag": base64.b64encode(tag).decode(),
            },
            ensure_ascii=False,
        ).encode()
    ).decode()


def _login() -> dict:
    username = config["auth"]["username"]
    password = config["auth"]["password"]

    if not username or not password:
        raise RuntimeError(
            "[edgmo_sdk] 未配置用户名或密码。\n"
            "请通过以下方式之一配置：\n"
            "  1. 环境变量：EDGMO_SDK_USERNAME / EDGMO_SDK_PASSWORD\n"
            "  2. 配置文件：~/.edgmo_sdk/sdk.yaml 或 ./sdk.yaml\n"
            "  3. 运行时：edgmo_sdk.configure(username=..., password=...)"
        )

    encrypted_token = _encrypt_login_payload(_get_public_key(), username, password)

    resp = requests.post(
        _auth_api("login"),
        headers={"Authorization": encrypted_token},
        timeout=10,
    )

    try:
        body = resp.json()
    except Exception:
        body = {}

    if resp.status_code == 401:
        msg = body.get("message", "用户名或密码错误")
        details = body.get("details") or {}
        hint = ""
        if details.get("remaining_attempts") is not None:
            hint = f"，剩余尝试次数：{details['remaining_attempts']}"
        elif details.get("remaining_time") is not None:
            hint = f"，账户锁定中，请 {details['remaining_time']} 秒后再试"
        raise RuntimeError(f"[edgmo_sdk] 登录失败（401）：{msg}{hint}")

    if resp.status_code == 423:
        details = body.get("details") or {}
        remaining = details.get("remaining_time", "未知")
        raise RuntimeError(
            f"[edgmo_sdk] 账户已锁定（423）：{body.get('message', '登录失败次数过多')}\n"
            f"  → 锁定剩余时间：{remaining} 秒，请稍后再试"
        )

    if not resp.ok:
        raise RuntimeError(
            f"[edgmo_sdk] 登录请求失败（HTTP {resp.status_code}）：{body.get('message', resp.reason)}"
        )

    if body.get("status") != "success":
        raise RuntimeError(f"[edgmo_sdk] 登录失败：{body.get('message', '未知错误')}")

    tokens = body["data"]["tokens"]
    return {
        "access_token": tokens["access_token"],
        "refresh_token": tokens["refresh_token"],
        "access_token_exp": time.time() + 3 * 3600,
    }


def _refresh(cache: dict) -> dict:
    resp = requests.post(
        _auth_api("refresh"),
        headers={"Authorization": f"Bearer {cache['refresh_token']}"},
        timeout=10,
    )

    if resp.status_code != 200:
        return _login()

    body = resp.json()
    if body.get("status") != "success":
        return _login()

    tokens = body["data"]["tokens"]
    return {
        "access_token": tokens["access_token"],
        "refresh_token": tokens["refresh_token"],
        "access_token_exp": time.time() + 3 * 3600,
    }


def get_token(force_refresh: bool = False) -> str:
    """
    获取有效的 access_token（优先从缓存读取）。

    Args:
        force_refresh: 为 True 时强制重新登录，忽略缓存

    Returns:
        access_token 字符串
    """
    cache = _load_cache()

    if force_refresh or not cache:
        cache = _login()
    elif not _is_token_valid(cache):
        cache = _refresh(cache)

    _save_cache(cache)
    return cache["access_token"]


def get_headers(force_refresh: bool = False) -> dict:
    """
    返回可用于 HTTP 请求的认证 headers 字典。

    Example:
        resp = requests.post(url, json={...}, headers=get_headers())
    """
    return {"Authorization": f"Bearer {get_token(force_refresh)}"}


def verify_token(token: str) -> bool:
    """验证 token 是否有效。"""
    resp = requests.post(
        _auth_api("verify"),
        headers={"Authorization": f"Bearer {token}"},
        timeout=10,
    )
    return resp.status_code == 200 and resp.json().get("status") == "success"


def logout() -> bool:
    """
    注销当前登录（使服务端 token 失效），并清除本地缓存。

    注销后再次调用 get_token() / get_headers() 会自动重新登录。

    Returns:
        True  注销成功
        False 本地无缓存 token，无需注销
    """
    cache = _load_cache()
    if not cache or not cache.get("access_token"):
        return False

    try:
        resp = requests.post(
            _auth_api("logout"),
            headers={"Authorization": f"Bearer {cache['access_token']}"},
            timeout=10,
        )
        body = resp.json() if resp.content else {}
        if not (resp.status_code == 200 and body.get("status") == "success"):
            pass  # token 已过期或服务端报错，继续清除本地缓存
    except Exception:
        pass

    path = _cache_file()
    if os.path.exists(path):
        os.remove(path)

    return True
