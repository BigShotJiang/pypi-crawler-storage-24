# edgmo-sdk

数据库访问 SDK，提供数据库列表、数据表查询、数据增删改等能力。

## 安装

```bash
pip install edgmo-sdk
```

## 配置文件

SDK 通过 `sdk.yaml` 读取服务地址和接口路由。**此文件包含敏感信息，请勿提交到代码仓库。**

按以下顺序查找配置文件：
1. 环境变量 `EDGMO_SDK_CONFIG` 指定的路径
2. 当前工作目录 `./sdk.yaml`
3. 用户目录 `~/.edgmo_sdk/sdk.yaml`

**sdk.yaml 示例：**

```yaml
base_url: "https://your-server.com"

auth:
  username: "your_username"
  password: "your_password"

token:                                 # 可选，以下为默认值
  cache_file:    ".token_cache.json"   # token 缓存文件名（存储在 ~/.edgmo_sdk/ 下）
  expire_buffer: 60                    # access_token 过期前提前刷新的秒数

auth_endpoints:
  publickey: "/your/login/publickey"
  login:     "/your/login/auth/login"
  refresh:   "/your/login/auth/refresh"
  verify:    "/your/login/auth/verify"
  logout:    "/your/login/auth/logout"

endpoints:
  list_database: "/your/api/list/database"
  list_tables:   "/your/api/list/tables"
  table_select:  "/your/api/table/select"
  table_stats:   "/your/api/table/stats"
  table_update:  "/your/api/table/update"
  table_delete:  "/your/api/table/delete"
  table_insert:  "/your/api/table/insert"
```

> `base_url` 和 `endpoints` 只能在 `sdk.yaml` 中配置，不会硬编码在代码中。

## 认证配置

`username` / `password` 支持三种方式（优先级从高到低）：

| 方式 | 示例 |
|------|------|
| 运行时调用 | `edgmo_sdk.configure(username="u", password="p")` |
| 环境变量 | `EDGMO_SDK_USERNAME=u EDGMO_SDK_PASSWORD=p` |
| sdk.yaml | `auth.username` / `auth.password` 字段 |

## 快速上手

```python
import edgmo_sdk

# （可选）运行时覆盖认证信息
edgmo_sdk.configure(username="your_user", password="your_pass")

# 获取数据库列表
dbs = edgmo_sdk.list_databases()

# 获取数据表列表
tables = edgmo_sdk.list_tables("my_db")

# 查询数据
result = edgmo_sdk.select(
    "my_db", "orders",
    fields=["order_id", "amount"],
    where={"status": "paid"},
    start_date="2026-01-01",
    end_date="2026-03-31",
    limit=100,
)
rows = result["data"]["rows"]

# SQL 模式查询
result = edgmo_sdk.select(
    "my_db", "orders",
    mode="sql",
    sql="SELECT * FROM orders WHERE status = %s LIMIT 10",
    params=["paid"],
)

# 插入数据
edgmo_sdk.insert("my_db", "orders", row={"order_id": "abc", "amount": 99.0})

# 更新数据（默认 limit=1，防止误操作）
edgmo_sdk.update("my_db", "orders", values={"status": "done"}, where={"order_id": "abc"})

# 删除数据（默认 limit=1，防止误操作）
edgmo_sdk.delete("my_db", "orders", where={"order_id": "abc"})
```

## 使用 Client 类

```python
from edgmo_sdk import Client

client = Client()
dbs = client.list_databases()
```

## Token 工具

```python
from edgmo_sdk import get_token, get_headers, logout

token = get_token()       # 获取 token 字符串
headers = get_headers()   # 获取认证 headers
logout()                  # 注销并清除本地缓存
```

Token 缓存在 `~/.edgmo_sdk/.dev_token_cache.json`，有效期 3 小时，过期后自动刷新。

## 依赖

- Python >= 3.10
- requests
- cryptography
- pyyaml
