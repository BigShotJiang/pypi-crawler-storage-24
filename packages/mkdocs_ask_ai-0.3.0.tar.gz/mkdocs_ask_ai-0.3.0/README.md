# mkdocs-ask-ai

MkDocs plugin for LLM-friendly documentation that provides:

1. **Direct markdown serving** - Access original markdown at `page.md` URLs
2. **llms.txt generation** - Concise index file for LLM context
3. **llms-full.txt generation** - Complete documentation in single file
4. **Copy-to-markdown button** - Easy copying of source markdown
5. **i18n support** - Works with `mkdocs-static-i18n` (suffix structure)

## Features

- Source-first approach — works with original markdown, no HTML parsing
- LLM optimized — token-efficient formats for AI consumption
- Copy button — one-click markdown copying for developers
- Dual URLs — both human-readable HTML and LLM-friendly markdown
- Multilingual — generates separate `llms.txt` / `llms-full.txt` per locale

> **Origin:** Forked from [mkdocs-llmstxt-md](https://github.com/noklam/mkdocs-llmstxt-md)
> by Nok Lam Chan (MIT). This fork adds i18n support and will diverge
> significantly from the upstream project.

## Installation

```bash
pip install mkdocs-ask-ai
```

## Usage

Add to your `mkdocs.yml`:

```yaml
plugins:
  - ask-ai:
      sections:
        "Getting Started":
          - index.md: "Introduction to the project"
          - quickstart.md
        "API Reference":
          - api/*.md
```

### With mkdocs-static-i18n

Place the `ask-ai` plugin **before** `i18n` in the plugins list. The plugin
automatically detects locale builds and writes `llms.txt` / `llms-full.txt`
to each locale's output directory:

```yaml
plugins:
  - ask-ai:
      sections:
        "Docs":
          - "*.md"
  - i18n:
      docs_structure: suffix
      languages:
        - locale: en
          default: true
          name: English
        - locale: ru
          name: Русский
```

This generates:
- `site/llms.txt` — English index
- `site/ru/llms.txt` — Russian index
- `site/llms-full.txt` — English full docs
- `site/ru/llms-full.txt` — Russian full docs

## Configuration

| Option | Default | Description |
|--------|---------|-------------|
| `sections` | `{}` | Dict of section names to file patterns |
| `enable_markdown_urls` | `true` | Enable `.md` URL serving |
| `enable_llms_txt` | `true` | Generate `llms.txt` |
| `enable_llms_full` | `true` | Generate `llms-full.txt` |
| `enable_copy_button` | `true` | Add copy button to pages |
| `copy_button_text` | `"Copy Markdown"` | Text for the copy button |
| `markdown_description` | — | Optional description in `llms.txt` |

## License

MIT — see [LICENSE](LICENSE).
