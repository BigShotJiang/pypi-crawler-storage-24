"""LLM 客户端封装

支持 OpenAI 兼容 API 的私有化部署服务
"""

import time
from typing import Optional, Generator
from dataclasses import dataclass

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    httpx = None
    HTTPX_AVAILABLE = False


@dataclass
class ChatMessage:
    """聊天消息"""
    role: str
    content: str


@dataclass
class ChatResponse:
    """聊天响应"""
    content: str
    model: str
    usage: dict
    latency_ms: float


class LLMClient:
    """LLM 客户端"""

    def __init__(
        self,
        base_url: str,
        api_key: str = "sk-dummy",
        model: str = "qwen3.5-35b-a3b",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        timeout: int = 120,
    ):
        if not HTTPX_AVAILABLE:
            raise ImportError("请安装 httpx: pip install httpx")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout

        # HTTP 客户端
        self._client = httpx.Client(timeout=timeout)

    def _build_headers(self) -> dict:
        """构建请求头"""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _build_payload(
        self,
        messages: list[ChatMessage],
        stream: bool = False,
        **kwargs
    ) -> dict:
        """构建请求体"""
        return {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
            "stream": stream,
        }

    def chat(
        self,
        messages: list[ChatMessage],
        **kwargs
    ) -> ChatResponse:
        """发送聊天请求"""
        url = f"{self.base_url}/chat/completions"
        headers = self._build_headers()
        payload = self._build_payload(messages, stream=False, **kwargs)

        start_time = time.time()
        response = self._client.post(url, headers=headers, json=payload)
        latency_ms = (time.time() - start_time) * 1000

        response.raise_for_status()

        # 处理可能返回的 SSE 格式响应
        content = response.text
        if content.startswith("data:"):
            # SSE 格式，解析流式响应
            full_content = self._parse_sse_response(content)
            return ChatResponse(
                content=full_content,
                model=self.model,
                usage={},
                latency_ms=latency_ms,
            )

        # 标准 JSON 格式
        data = response.json()
        return ChatResponse(
            content=data["choices"][0]["message"]["content"],
            model=data.get("model", self.model),
            usage=data.get("usage", {}),
            latency_ms=latency_ms,
        )

    def _parse_sse_response(self, text: str) -> str:
        """解析 SSE 格式的响应"""
        import json
        full_content = ""
        for line in text.split("\n"):
            if line.startswith("data:"):
                data_str = line[5:].strip()
                if data_str == "[DONE]" or not data_str:
                    continue
                try:
                    data = json.loads(data_str)
                    if "choices" in data and data["choices"]:
                        choice = data["choices"][0]
                        # 支持两种格式：message (非流式) 和 delta (流式)
                        if "message" in choice:
                            content = choice["message"].get("content", "")
                            if content:
                                full_content = content  # 非流式，直接替换
                        elif "delta" in choice:
                            delta = choice["delta"]
                            if "content" in delta:
                                full_content += delta["content"]
                except json.JSONDecodeError:
                    continue
        return full_content

    def chat_stream(
        self,
        messages: list[ChatMessage],
        **kwargs
    ) -> Generator[str, None, None]:
        """流式聊天"""
        url = f"{self.base_url}/chat/completions"
        headers = self._build_headers()
        payload = self._build_payload(messages, stream=True, **kwargs)

        with self._client.stream("POST", url, headers=headers, json=payload) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    import json
                    data = json.loads(data_str)
                    if "choices" in data and data["choices"]:
                        delta = data["choices"][0].get("delta", {})
                        if "content" in delta:
                            yield delta["content"]

    def simple_chat(self, prompt: str, system: Optional[str] = None) -> str:
        """简单聊天接口"""
        messages = []
        if system:
            messages.append(ChatMessage(role="system", content=system))
        messages.append(ChatMessage(role="user", content=prompt))

        response = self.chat(messages)
        return response.content

    def close(self) -> None:
        """关闭客户端"""
        self._client.close()

    def __enter__(self) -> "LLMClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()
