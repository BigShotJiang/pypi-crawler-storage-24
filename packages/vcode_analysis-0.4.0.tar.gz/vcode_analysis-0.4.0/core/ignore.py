"""统一的过滤规则模块

集中管理所有依赖目录和缓存文件的过滤规则，供各模块使用。
"""

# 依赖目录（各种语言和工具）
DEPENDENCY_DIRS = {
    # Python
    ".venv", "venv", "env", "__pycache__", ".tox", ".pytest_cache",
    ".mypy_cache", ".nox", "site-packages", "dist-info", "egg-info",
    ".eggs", "eggs", "*.egg",

    # Node.js
    "node_modules", ".npm", ".yarn", ".pnpm-store", ".pnp",

    # Java/Kotlin
    "target", ".gradle", ".mvn", "build", "out", ".classpath", ".project",

    # Go
    "vendor",

    # Rust
    # target 已在 Java 中定义

    # Ruby
    ".bundle", ".gem",

    # PHP
    # vendor 已在 Go 中定义

    # .NET/C#
    "bin", "obj", "packages", ".nuget",

    # Swift/iOS/macOS
    "Pods", "Carthage", "DerivedData", ".swiftpm", ".build",

    # 前端框架
    ".next", ".nuxt", ".cache", ".parcel-cache",

    # IDE 和编辑器
    ".git", ".idea", ".vscode", ".sublime-workspace", ".eclipse",

    # 其他工具
    ".hg", ".svn", ".bzr",
}

# 缓存文件模式
CACHE_FILE_PATTERNS = [
    # Python 缓存
    "*.pyc", "*.pyo", "*.pyd", "*.pyi",

    # 编译产物
    "*.o", "*.a", "*.so", "*.so.*", "*.dylib", "*.dll", "*.exe", "*.bin",
    "*.class", "*.jar", "*.war", "*.ear",

    # 临时文件
    "*.log", "*.tmp", "*.temp", "*.bak", "*.swp", "*.swo", "*~",

    # 系统文件
    ".DS_Store", "Thumbs.db", "Desktop.ini", "*.stackdump",

    # 压缩文件
    "*.zip", "*.tar.gz", "*.tar.bz2", "*.tar.xz", "*.rar", "*.7z",

    # 其他
    "*.min.js", "*.min.css", "*.map",
]

# 其他应忽略的目录（非依赖）
IGNORE_DIRS = {
    # 构建输出
    "dist", "build", "output", "release",

    # 测试覆盖率
    "coverage", "htmlcov", ".coverage", ".nyc_output",

    # 文档生成
    "_build", "site", ".docusaurus",

    # 静态资源
    "static", "assets",
}

# 应忽略的文件（精确匹配）
IGNORE_FILES = {
    ".DS_Store", "Thumbs.db", ".gitignore", ".gitattributes",
    ".editorconfig", ".env", ".env.local", ".env.*.local",
}


def get_default_ignore_patterns() -> list[str]:
    """获取默认忽略模式列表

    返回用于文件扫描的默认忽略模式，包含目录名和文件模式。

    Returns:
        忽略模式列表
    """
    patterns = list(DEPENDENCY_DIRS)

    # 添加缓存文件模式
    patterns.extend(CACHE_FILE_PATTERNS)

    # 添加其他忽略目录
    patterns.extend(IGNORE_DIRS)

    return patterns


def get_ignore_dirs() -> set[str]:
    """获取应忽略的目录名集合

    返回所有依赖目录和其他应忽略的目录名。

    Returns:
        目录名集合
    """
    return DEPENDENCY_DIRS | IGNORE_DIRS


def get_ignore_files() -> set[str]:
    """获取应忽略的文件名集合

    Returns:
        文件名集合
    """
    return IGNORE_FILES


def is_dependency_dir(dirname: str) -> bool:
    """判断目录是否为依赖目录

    Args:
        dirname: 目录名

    Returns:
        是否为依赖目录
    """
    return dirname in DEPENDENCY_DIRS


def matches_cache_pattern(filename: str) -> bool:
    """判断文件名是否匹配缓存文件模式

    Args:
        filename: 文件名

    Returns:
        是否匹配缓存模式
    """
    import fnmatch

    for pattern in CACHE_FILE_PATTERNS:
        if fnmatch.fnmatch(filename, pattern):
            return True
    return False
