"""Git 操作处理模块

支持：
- 克隆远程仓库
- 获取提交历史
- 获取提交差异
- 分析指定提交
- 批量 Git 操作
- 批量克隆
"""

import subprocess
import re
import concurrent.futures
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, Callable
from datetime import datetime
from enum import Enum


@dataclass
class CommitInfo:
    """提交信息"""
    hash: str
    short_hash: str
    author: str
    date: datetime
    message: str
    files_changed: list[str]


@dataclass
class FileDiff:
    """文件差异"""
    file_path: str
    old_path: Optional[str]  # 重命名时的原路径
    status: str  # A=新增, M=修改, D=删除, R=重命名
    additions: int
    deletions: int
    diff: str


class GitHandler:
    """Git 操作处理器"""

    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)

    def _run_git(self, *args: str, check: bool = True) -> str:
        """执行 git 命令"""
        cmd = ["git"] + list(args)
        result = subprocess.run(
            cmd,
            cwd=self.repo_path,
            capture_output=True,
            text=True,
            check=check,
        )
        return result.stdout.strip()

    @classmethod
    def clone(cls, url: str, target_dir: Optional[str] = None) -> "GitHandler":
        """克隆仓库"""
        if target_dir:
            Path(target_dir).mkdir(parents=True, exist_ok=True)
        else:
            target_dir = url.split("/")[-1].replace(".git", "")

        subprocess.run(
            ["git", "clone", url, target_dir],
            capture_output=True,
            check=True,
        )
        return cls(target_dir)

    def is_valid_repo(self) -> bool:
        """检查是否为有效的 Git 仓库"""
        try:
            self._run_git("rev-parse", "--git-dir", check=False)
            return True
        except Exception:
            return False

    def get_current_branch(self) -> str:
        """获取当前分支名"""
        return self._run_git("branch", "--show-current")

    def get_commit_info(self, commit_hash: str) -> CommitInfo:
        """获取提交详情"""
        # 格式: hash|short_hash|author|date|message
        format_str = "%H|%h|%an|%aI|%s"
        output = self._run_git("log", "-1", f"--format={format_str}", commit_hash)
        parts = output.split("|", 4)

        # 获取变更的文件列表
        files_output = self._run_git("diff-tree", "--no-commit-id", "--name-only", "-r", commit_hash)
        files_changed = files_output.split("\n") if files_output else []

        return CommitInfo(
            hash=parts[0],
            short_hash=parts[1],
            author=parts[2],
            date=datetime.fromisoformat(parts[3]),
            message=parts[4],
            files_changed=files_changed,
        )

    def get_commit_diff(self, commit_hash: str) -> list[FileDiff]:
        """获取提交的文件差异"""
        diffs = []

        # 获取差异统计
        numstat = self._run_git("diff-tree", "--numstat", "-r", commit_hash)

        # 获取详细差异
        diff_output = self._run_git("show", "--format=", commit_hash)

        # 解析差异
        file_pattern = re.compile(r'^diff --git a/(.+?) b/(.+?)$')
        current_file = None
        current_diff = []

        for line in diff_output.split("\n"):
            match = file_pattern.match(line)
            if match:
                if current_file and current_diff:
                    diffs.append(self._parse_file_diff(current_file, "\n".join(current_diff), numstat))
                current_file = match.group(2)
                current_diff = [line]
            elif current_file:
                current_diff.append(line)

        if current_file and current_diff:
            diffs.append(self._parse_file_diff(current_file, "\n".join(current_diff), numstat))

        return diffs

    def _parse_file_diff(self, file_path: str, diff: str, numstat: str) -> FileDiff:
        """解析文件差异"""
        additions = 0
        deletions = 0
        old_path = None
        status = "M"

        # 从 numstat 获取行数变化
        for line in numstat.split("\n"):
            if line.endswith(file_path):
                parts = line.split("\t")
                if len(parts) >= 3:
                    additions = int(parts[0]) if parts[0] != "-" else 0
                    deletions = int(parts[1]) if parts[1] != "-" else 0
                    break

        # 判断状态
        if diff.startswith("diff --git"):
            if "new file mode" in diff:
                status = "A"
            elif "deleted file mode" in diff:
                status = "D"
            elif "rename from" in diff:
                status = "R"
                match = re.search(r"rename from (.+)", diff)
                if match:
                    old_path = match.group(1)

        return FileDiff(
            file_path=file_path,
            old_path=old_path,
            status=status,
            additions=additions,
            deletions=deletions,
            diff=diff,
        )

    def get_commits(
        self,
        branch: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        author: Optional[str] = None,
        limit: int = 50,
    ) -> list[CommitInfo]:
        """获取提交列表"""
        args = ["log", f"--format=%H", f"-{limit}"]

        if branch:
            args.append(branch)
        if since:
            args.extend(["--since", since])
        if until:
            args.extend(["--until", until])
        if author:
            args.extend(["--author", author])

        output = self._run_git(*args)
        commits = []
        for hash_line in output.split("\n"):
            if hash_line:
                commits.append(self.get_commit_info(hash_line))

        return commits

    def get_file_content(self, file_path: str, commit_hash: Optional[str] = None) -> str:
        """获取文件内容"""
        if commit_hash:
            return self._run_git("show", f"{commit_hash}:{file_path}")
        else:
            return (self.repo_path / file_path).read_text(encoding="utf-8", errors="ignore")

    # ==================== Git 操作方法 ====================

    def pull(self, remote: str = "origin", branch: Optional[str] = None) -> dict:
        """执行 git pull

        Args:
            remote: 远程仓库名
            branch: 分支名

        Returns:
            操作结果 {success, message, changes}
        """
        try:
            args = ["pull", remote]
            if branch:
                args.append(branch)

            output = self._run_git(*args, check=False)

            # 解析结果
            if "Already up to date" in output or "Already up-to-date" in output:
                return {"success": True, "message": "已是最新", "changes": False}
            elif "Updating" in output:
                return {"success": True, "message": "更新成功", "changes": True}
            else:
                return {"success": True, "message": output, "changes": True}

        except subprocess.CalledProcessError as e:
            return {"success": False, "message": e.stderr if hasattr(e, 'stderr') else str(e), "changes": False}

    def fetch(self, remote: str = "origin", prune: bool = True) -> dict:
        """执行 git fetch

        Args:
            remote: 远程仓库名
            prune: 是否清理已删除的远程分支

        Returns:
            操作结果
        """
        try:
            args = ["fetch", remote]
            if prune:
                args.append("--prune")

            output = self._run_git(*args, check=False)
            return {"success": True, "message": output or "获取成功"}

        except subprocess.CalledProcessError as e:
            return {"success": False, "message": str(e)}

    def status(self, porcelain: bool = True) -> dict:
        """获取仓库状态

        Args:
            porcelain: 使用机器可读格式

        Returns:
            状态信息 {branch, staged, unstaged, untracked, is_clean}
        """
        result = {
            "branch": self.get_current_branch(),
            "staged": [],
            "unstaged": [],
            "untracked": [],
            "is_clean": True,
        }

        if porcelain:
            output = self._run_git("status", "--porcelain", check=False)

            for line in output.split("\n"):
                if not line:
                    continue

                result["is_clean"] = False
                status = line[:2]
                file_path = line[3:]

                if status[0] in "MADRC":
                    result["staged"].append({"status": status[0], "file": file_path})
                if status[1] in "MD":
                    result["unstaged"].append({"status": status[1], "file": file_path})
                if status == "??":
                    result["untracked"].append(file_path)

        return result

    def get_remote_url(self, remote: str = "origin") -> Optional[str]:
        """获取远程仓库 URL"""
        try:
            return self._run_git("remote", "get-url", remote, check=False) or None
        except Exception:
            return None

    def get_all_branches(self, include_remote: bool = True) -> list[str]:
        """获取所有分支

        Args:
            include_remote: 是否包含远程分支

        Returns:
            分支名列表
        """
        branches = []

        # 本地分支
        local = self._run_git("branch", "--format=%(refname:short)", check=False)
        branches.extend([b.strip() for b in local.split("\n") if b.strip()])

        # 远程分支
        if include_remote:
            remote = self._run_git("branch", "-r", "--format=%(refname:short)", check=False)
            branches.extend([b.strip() for b in remote.split("\n") if b.strip()])

        return branches

    def has_uncommitted_changes(self) -> bool:
        """检查是否有未提交的更改"""
        status = self.status()
        return not status["is_clean"]

    def get_ahead_behind(self, branch: Optional[str] = None, remote: str = "origin") -> dict:
        """获取分支领先/落后远程的提交数

        Args:
            branch: 分支名，默认当前分支
            remote: 远程仓库名

        Returns:
            {ahead, behind}
        """
        if not branch:
            branch = self.get_current_branch()

        try:
            output = self._run_git(
                "rev-list", "--left-right", "--count",
                f"{remote}/{branch}...{branch}",
                check=False
            )

            parts = output.split()
            if len(parts) == 2:
                return {"ahead": int(parts[1]), "behind": int(parts[0])}
        except Exception:
            pass

        return {"ahead": 0, "behind": 0}


# ==================== 批量操作数据结构 ====================

class RepoStatus(Enum):
    """仓库状态"""
    CLEAN = "clean"
    MODIFIED = "modified"
    AHEAD = "ahead"
    BEHIND = "behind"
    DIVERGED = "diverged"
    ERROR = "error"


@dataclass
class RepoInfo:
    """仓库信息"""
    path: str
    name: str
    branch: str
    remote_url: Optional[str]
    status: RepoStatus
    ahead: int
    behind: int
    staged_files: int
    unstaged_files: int
    untracked_files: int
    error: Optional[str] = None


@dataclass
class BatchResult:
    """批量操作结果"""
    total: int
    success: int
    failed: int
    results: list[dict] = field(default_factory=list)

    def add_success(self, repo: str, message: str = ""):
        self.success += 1
        self.results.append({"repo": repo, "success": True, "message": message})

    def add_failure(self, repo: str, error: str):
        self.failed += 1
        self.results.append({"repo": repo, "success": False, "error": error})


# ==================== 批量操作处理器 ====================

class BatchGitHandler:
    """批量 Git 操作处理器"""

    def __init__(self, base_dir: str, max_workers: int = 4):
        """初始化批量处理器

        Args:
            base_dir: 包含多个仓库的基础目录
            max_workers: 最大并发数
        """
        self.base_dir = Path(base_dir)
        self.max_workers = max_workers

    def discover_repos(self) -> list[Path]:
        """发现目录下的所有 Git 仓库

        Returns:
            仓库路径列表
        """
        repos = []

        if not self.base_dir.exists():
            return repos

        # 检查当前目录是否为仓库
        if (self.base_dir / ".git").exists():
            repos.append(self.base_dir)
            return repos

        # 扫描子目录
        for item in self.base_dir.iterdir():
            if item.is_dir() and (item / ".git").exists():
                repos.append(item)

        return sorted(repos)

    def get_all_repos_info(self) -> list[RepoInfo]:
        """获取所有仓库的状态信息

        Returns:
            仓库信息列表
        """
        repos = self.discover_repos()
        results = []

        for repo_path in repos:
            try:
                handler = GitHandler(str(repo_path))
                status = handler.status()

                # 计算状态
                ahead_behind = handler.get_ahead_behind()

                if status["is_clean"]:
                    if ahead_behind["ahead"] > 0 and ahead_behind["behind"] > 0:
                        repo_status = RepoStatus.DIVERGED
                    elif ahead_behind["ahead"] > 0:
                        repo_status = RepoStatus.AHEAD
                    elif ahead_behind["behind"] > 0:
                        repo_status = RepoStatus.BEHIND
                    else:
                        repo_status = RepoStatus.CLEAN
                else:
                    repo_status = RepoStatus.MODIFIED

                results.append(RepoInfo(
                    path=str(repo_path),
                    name=repo_path.name,
                    branch=status["branch"],
                    remote_url=handler.get_remote_url(),
                    status=repo_status,
                    ahead=ahead_behind["ahead"],
                    behind=ahead_behind["behind"],
                    staged_files=len(status["staged"]),
                    unstaged_files=len(status["unstaged"]),
                    untracked_files=len(status["untracked"]),
                ))

            except Exception as e:
                results.append(RepoInfo(
                    path=str(repo_path),
                    name=repo_path.name,
                    branch="",
                    remote_url=None,
                    status=RepoStatus.ERROR,
                    ahead=0,
                    behind=0,
                    staged_files=0,
                    unstaged_files=0,
                    untracked_files=0,
                    error=str(e),
                ))

        return results

    def batch_pull(self, repos: Optional[list[str]] = None) -> BatchResult:
        """批量拉取更新

        Args:
            repos: 指定仓库列表，None 表示全部

        Returns:
            批量操作结果
        """
        all_repos = self.discover_repos()

        if repos:
            all_repos = [r for r in all_repos if r.name in repos or str(r) in repos]

        result = BatchResult(total=len(all_repos), success=0, failed=0)

        for repo_path in all_repos:
            try:
                handler = GitHandler(str(repo_path))
                pull_result = handler.pull()

                if pull_result["success"]:
                    result.add_success(repo_path.name, pull_result["message"])
                else:
                    result.add_failure(repo_path.name, pull_result["message"])

            except Exception as e:
                result.add_failure(repo_path.name, str(e))

        return result

    def batch_fetch(self, repos: Optional[list[str]] = None) -> BatchResult:
        """批量获取远程信息

        Args:
            repos: 指定仓库列表

        Returns:
            批量操作结果
        """
        all_repos = self.discover_repos()

        if repos:
            all_repos = [r for r in all_repos if r.name in repos or str(r) in repos]

        result = BatchResult(total=len(all_repos), success=0, failed=0)

        for repo_path in all_repos:
            try:
                handler = GitHandler(str(repo_path))
                fetch_result = handler.fetch()

                if fetch_result["success"]:
                    result.add_success(repo_path.name, fetch_result["message"])
                else:
                    result.add_failure(repo_path.name, fetch_result["message"])

            except Exception as e:
                result.add_failure(repo_path.name, str(e))

        return result

    @staticmethod
    def batch_clone(
        urls: list[str],
        target_dir: str,
        parallel: bool = True,
        max_workers: int = 4,
        progress_callback: Optional[Callable[[str, int, int], None]] = None,
    ) -> BatchResult:
        """批量克隆仓库

        Args:
            urls: 仓库 URL 列表
            target_dir: 目标目录
            parallel: 是否并行克隆
            max_workers: 最大并发数
            progress_callback: 进度回调 (url, current, total)

        Returns:
            批量操作结果
        """
        target_path = Path(target_dir)
        target_path.mkdir(parents=True, exist_ok=True)

        result = BatchResult(total=len(urls), success=0, failed=0)

        def clone_single(url: str, index: int) -> dict:
            """克隆单个仓库"""
            # 从 URL 提取仓库名
            name = url.split("/")[-1].replace(".git", "")
            repo_dir = target_path / name

            if repo_dir.exists():
                return {"url": url, "success": False, "error": f"目录已存在: {repo_dir}"}

            try:
                if progress_callback:
                    progress_callback(url, index + 1, len(urls))

                subprocess.run(
                    ["git", "clone", url, str(repo_dir)],
                    capture_output=True,
                    check=True,
                    timeout=300,  # 5 分钟超时
                )
                return {"url": url, "success": True, "path": str(repo_dir)}
            except subprocess.TimeoutExpired:
                return {"url": url, "success": False, "error": "克隆超时"}
            except subprocess.CalledProcessError as e:
                return {"url": url, "success": False, "error": e.stderr.decode() if e.stderr else str(e)}
            except Exception as e:
                return {"url": url, "success": False, "error": str(e)}

        if parallel:
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(clone_single, url, i): url
                    for i, url in enumerate(urls)
                }

                for future in concurrent.futures.as_completed(futures):
                    clone_result = future.result()
                    if clone_result["success"]:
                        result.add_success(clone_result["url"], f"克隆到 {clone_result.get('path', '')}")
                    else:
                        result.add_failure(clone_result["url"], clone_result["error"])
        else:
            for i, url in enumerate(urls):
                clone_result = clone_single(url, i)
                if clone_result["success"]:
                    result.add_success(clone_result["url"], f"克隆到 {clone_result.get('path', '')}")
                else:
                    result.add_failure(clone_result["url"], clone_result["error"])

        return result

    def generate_status_report(self, repos: Optional[list[RepoInfo]] = None) -> str:
        """生成状态报告

        Args:
            repos: 仓库信息列表，None 则自动获取

        Returns:
            Markdown 格式的报告
        """
        if repos is None:
            repos = self.get_all_repos_info()

        lines = [
            "# Git 仓库状态报告",
            "",
            f"**扫描目录**: {self.base_dir}",
            f"**仓库数量**: {len(repos)}",
            "",
            "---",
            "",
            "| 仓库 | 分支 | 状态 | 领先 | 落后 | 已暂存 | 未暂存 |",
            "|------|------|------|------|------|--------|--------|",
        ]

        status_emoji = {
            RepoStatus.CLEAN: "✅",
            RepoStatus.MODIFIED: "📝",
            RepoStatus.AHEAD: "⬆️",
            RepoStatus.BEHIND: "⬇️",
            RepoStatus.DIVERGED: "↔️",
            RepoStatus.ERROR: "❌",
        }

        for repo in repos:
            emoji = status_emoji.get(repo.status, "❓")
            lines.append(
                f"| {repo.name} | {repo.branch} | {emoji} {repo.status.value} | "
                f"{repo.ahead} | {repo.behind} | {repo.staged_files} | {repo.unstaged_files} |"
            )

            if repo.error:
                lines.append(f"| ^ | | 错误: {repo.error} | | | | |")

        # 统计
        status_counts = {}
        for repo in repos:
            status_counts[repo.status] = status_counts.get(repo.status, 0) + 1

        lines.extend([
            "",
            "---",
            "",
            "## 统计",
            "",
        ])

        for status, count in sorted(status_counts.items(), key=lambda x: -x[1]):
            emoji = status_emoji.get(status, "❓")
            lines.append(f"- {emoji} {status.value}: {count} 个仓库")

        # 需要操作的仓库
        need_action = [r for r in repos if r.status in (RepoStatus.MODIFIED, RepoStatus.BEHIND, RepoStatus.DIVERGED, RepoStatus.ERROR)]
        if need_action:
            lines.extend([
                "",
                "## 需要关注的仓库",
                "",
            ])
            for repo in need_action:
                lines.append(f"- **{repo.name}**: {repo.status.value}")
                if repo.status == RepoStatus.BEHIND:
                    lines.append(f"  - 建议: 执行 `git pull` 同步")
                elif repo.status == RepoStatus.MODIFIED:
                    lines.append(f"  - 建议: 提交或暂存更改")
                elif repo.status == RepoStatus.DIVERGED:
                    lines.append(f"  - 建议: 解决分支分歧")

        return "\n".join(lines)
