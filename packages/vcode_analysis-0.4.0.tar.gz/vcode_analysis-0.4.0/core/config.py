"""配置管理模块

支持三种配置方式（优先级从高到低）：
1. CLI 参数
2. 环境变量
3. 配置文件
"""

import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

from .ignore import get_default_ignore_patterns

# YAML 为可选依赖
try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    yaml = None
    YAML_AVAILABLE = False


@dataclass
class LLMConfig:
    """LLM 配置"""
    base_url: str = "http://localhost:8000/v1"
    api_key: str = "sk-dummy"
    model: str = "qwen35-35b-a3b"
    temperature: float = 0.7
    max_tokens: int = 4096
    timeout: int = 180  # 增加到3分钟


@dataclass
class AnalysisConfig:
    """分析配置"""
    max_file_size: int = 100 * 1024  # 100KB
    max_workers: int = 5  # 并发分析线程数
    ignore_patterns: list = field(default_factory=get_default_ignore_patterns)
    supported_extensions: list = field(default_factory=lambda: [
        ".py", ".java", ".kt", ".js", ".ts", ".jsx", ".tsx",
        ".vue", ".c", ".h", ".cpp", ".hpp", ".cc", ".cxx",
        ".json", ".yaml", ".yml", ".md"
    ])


@dataclass
class Config:
    """主配置类"""
    llm: LLMConfig = field(default_factory=LLMConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)

    # CLI 参数（运行时覆盖）
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    model: Optional[str] = None
    target_path: Optional[str] = None
    output_format: str = "markdown"  # markdown, json

    _config_path: Optional[str] = field(default=None, repr=False)

    @classmethod
    def get_default_config_path(cls) -> Path:
        """获取默认配置文件路径"""
        return Path.home() / ".code-analysis" / "config.yaml"

    def load_from_file(self, config_path: Optional[str] = None) -> None:
        """从配置文件加载"""
        if config_path:
            path = Path(config_path)
        else:
            path = self.get_default_config_path()

        if not path.exists():
            return

        if not YAML_AVAILABLE:
            print("警告: 未安装 PyYAML，跳过配置文件加载。运行: pip install pyyaml")
            return

        self._config_path = str(path)
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        # 加载 LLM 配置
        if "llm" in data:
            for key, value in data["llm"].items():
                if hasattr(self.llm, key):
                    setattr(self.llm, key, value)

        # 加载分析配置
        if "analysis" in data:
            for key, value in data["analysis"].items():
                if hasattr(self.analysis, key):
                    setattr(self.analysis, key, value)

    def load_from_env(self) -> None:
        """从环境变量加载"""
        env_mappings = {
            "OPENAI_API_BASE": ("llm", "base_url"),
            "OPENAI_BASE_URL": ("llm", "base_url"),
            "OPENAI_API_KEY": ("llm", "api_key"),
            "CODE_ANALYSIS_MODEL": ("llm", "model"),
            "CODE_ANALYSIS_TEMPERATURE": ("llm", "temperature"),
            "CODE_ANALYSIS_MAX_TOKENS": ("llm", "max_tokens"),
        }

        for env_key, (section, attr) in env_mappings.items():
            value = os.environ.get(env_key)
            if value:
                target = self.llm if section == "llm" else self.analysis
                # 类型转换
                current_value = getattr(target, attr)
                if isinstance(current_value, int):
                    value = int(value)
                elif isinstance(current_value, float):
                    value = float(value)
                setattr(target, attr, value)

    def apply_cli_overrides(self, **kwargs) -> None:
        """应用 CLI 参数覆盖"""
        if kwargs.get("base_url"):
            self.llm.base_url = kwargs["base_url"]
        if kwargs.get("api_key"):
            self.llm.api_key = kwargs["api_key"]
        if kwargs.get("model"):
            self.llm.model = kwargs["model"]
        if kwargs.get("target_path"):
            self.target_path = kwargs["target_path"]
        if kwargs.get("output_format"):
            self.output_format = kwargs["output_format"]
        if kwargs.get("max_workers"):
            self.analysis.max_workers = kwargs["max_workers"]

    @classmethod
    def create(cls, **cli_kwargs) -> "Config":
        """创建配置实例（按优先级加载）"""
        config = cls()

        # 1. 先加载配置文件（最低优先级）
        config.load_from_file(cli_kwargs.get("config_file"))

        # 2. 再加载环境变量（中优先级）
        config.load_from_env()

        # 3. 最后应用 CLI 参数（最高优先级）
        config.apply_cli_overrides(**cli_kwargs)

        return config

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "llm": {
                "base_url": self.llm.base_url,
                "model": self.llm.model,
                "temperature": self.llm.temperature,
                "max_tokens": self.llm.max_tokens,
            },
            "analysis": {
                "max_file_size": self.analysis.max_file_size,
                "max_workers": self.analysis.max_workers,
                "ignore_patterns": self.analysis.ignore_patterns,
            },
            "target_path": self.target_path,
            "output_format": self.output_format,
        }
