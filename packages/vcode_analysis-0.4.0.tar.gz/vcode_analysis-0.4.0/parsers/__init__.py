"""多语言解析器模块

使用 AST (抽象语法树) 解析代码，提供精确的结构分析。
"""

# Python 解析器
from .python_parser import (
    PythonASTParser,
    PythonASTResult,
    FunctionInfo,
    ClassInfo,
    ImportInfo,
    VariableInfo,
    analyze_python_file,
    analyze_python_code,
)

# JavaScript 解析器
try:
    from .javascript_parser import (
        JavaScriptASTParser,
        JavaScriptASTResult,
        JSFunctionInfo,
        JSClassInfo,
        JSImportInfo,
        JSExportInfo,
        JSVariableInfo,
        analyze_javascript_file,
        analyze_javascript_code,
    )
    JS_PARSER_AVAILABLE = True
except ImportError:
    JS_PARSER_AVAILABLE = False

# TypeScript 解析器
try:
    from .typescript_parser import (
        TypeScriptASTParser,
        TypeScriptASTResult,
        TSInterfaceInfo,
        TSTypeAliasInfo,
        TSEnumInfo,
        TSFunctionInfo,
        TSClassInfo,
        analyze_typescript_file,
        analyze_typescript_code,
    )
    TS_PARSER_AVAILABLE = True
except ImportError:
    TS_PARSER_AVAILABLE = False

# Java 解析器
try:
    from .java_parser import (
        JavaASTParser,
        JavaASTResult,
        JavaMethodInfo,
        JavaFieldInfo,
        JavaClassInfo,
        JavaImportInfo,
        JavaPackageInfo,
        analyze_java_file,
        analyze_java_code,
    )
    JAVA_PARSER_AVAILABLE = True
except ImportError:
    JAVA_PARSER_AVAILABLE = False

# Kotlin 解析器
try:
    from .kotlin_parser import (
        KotlinASTParser,
        KotlinParserConfig,
        KotlinASTResult,
        KotlinFunctionInfo,
        KotlinPropertyInfo,
        KotlinClassInfo,
        KotlinImportInfo,
        KotlinSealedClassInfo,
        KotlinWhenExpression,
        KotlinCoroutineInfo,
        KotlinFlowOperator,
        KotlinTypeAlias,
        KotlinValueClass,
        KotlinDelegatedProperty,
        analyze_kotlin_file,
        analyze_kotlin_code,
    )
    KOTLIN_PARSER_AVAILABLE = True
except ImportError:
    KOTLIN_PARSER_AVAILABLE = False

# C 解析器
try:
    from .c_parser import (
        CASTParser,
        CParserConfig,
        CASTResult,
        CFunctionInfo,
        CVariableInfo,
        CStructInfo,
        CUnionInfo,
        CEnumInfo,
        CTypedefInfo,
        CMacroInfo,
        CIncludeInfo,
        CFunctionPointerInfo,
        analyze_c_file,
        analyze_c_code,
    )
    C_PARSER_AVAILABLE = True
except ImportError:
    C_PARSER_AVAILABLE = False


__all__ = [
    # Python
    "PythonASTParser",
    "PythonASTResult",
    "FunctionInfo",
    "ClassInfo",
    "ImportInfo",
    "VariableInfo",
    "analyze_python_file",
    "analyze_python_code",
    # Availability flags
    "JS_PARSER_AVAILABLE",
    "TS_PARSER_AVAILABLE",
    "JAVA_PARSER_AVAILABLE",
    "KOTLIN_PARSER_AVAILABLE",
    "C_PARSER_AVAILABLE",
]

if JS_PARSER_AVAILABLE:
    __all__.extend([
        "JavaScriptASTParser",
        "JavaScriptASTResult",
        "JSFunctionInfo",
        "JSClassInfo",
        "JSImportInfo",
        "JSExportInfo",
        "JSVariableInfo",
        "analyze_javascript_file",
        "analyze_javascript_code",
    ])

if TS_PARSER_AVAILABLE:
    __all__.extend([
        "TypeScriptASTParser",
        "TypeScriptASTResult",
        "TSInterfaceInfo",
        "TSTypeAliasInfo",
        "TSEnumInfo",
        "TSFunctionInfo",
        "TSClassInfo",
        "analyze_typescript_file",
        "analyze_typescript_code",
    ])

if JAVA_PARSER_AVAILABLE:
    __all__.extend([
        "JavaASTParser",
        "JavaASTResult",
        "JavaMethodInfo",
        "JavaFieldInfo",
        "JavaClassInfo",
        "JavaImportInfo",
        "JavaPackageInfo",
        "analyze_java_file",
        "analyze_java_code",
    ])

if KOTLIN_PARSER_AVAILABLE:
    __all__.extend([
        "KotlinASTParser",
        "KotlinParserConfig",
        "KotlinASTResult",
        "KotlinFunctionInfo",
        "KotlinPropertyInfo",
        "KotlinClassInfo",
        "KotlinImportInfo",
        "KotlinSealedClassInfo",
        "KotlinWhenExpression",
        "KotlinCoroutineInfo",
        "KotlinFlowOperator",
        "KotlinTypeAlias",
        "KotlinValueClass",
        "KotlinDelegatedProperty",
        "analyze_kotlin_file",
        "analyze_kotlin_code",
    ])

if C_PARSER_AVAILABLE:
    __all__.extend([
        "CASTParser",
        "CParserConfig",
        "CASTResult",
        "CFunctionInfo",
        "CVariableInfo",
        "CStructInfo",
        "CUnionInfo",
        "CEnumInfo",
        "CTypedefInfo",
        "CMacroInfo",
        "CIncludeInfo",
        "CFunctionPointerInfo",
        "analyze_c_file",
        "analyze_c_code",
    ])
