"""Kotlin 正则解析器

使用正则表达式快速解析 Kotlin 代码结构。
支持 Kotlin 特有语法特性的识别。
"""

import re
from pathlib import Path
from typing import Optional

from .models import (
    KotlinASTResult,
    KotlinFunctionInfo,
    KotlinPropertyInfo,
    KotlinClassInfo,
    KotlinImportInfo,
    KotlinSealedClassInfo,
    KotlinWhenExpression,
    KotlinCoroutineInfo,
    KotlinFlowOperator,
    KotlinTypeAlias,
    KotlinValueClass,
    KotlinDelegatedProperty,
    KotlinExtensionFunction,
    KotlinExtensionProperty,
    KotlinObjectDeclaration,
    KotlinEnumClassInfo,
    KotlinDataClassInfo,
    TERMINAL_FLOW_OPERATORS,
    STANDARD_DELEGATES,
)
from .patterns import KOTLIN_PATTERNS, KOTLIN_ADVANCED_PATTERNS


class KotlinRegexParser:
    """Kotlin 正则解析器（快速模式）"""

    def __init__(self):
        self.patterns = {**KOTLIN_PATTERNS, **KOTLIN_ADVANCED_PATTERNS}
        # 预编译正则表达式
        self._compiled = {}
        for name, pattern in self.patterns.items():
            try:
                self._compiled[name] = re.compile(pattern, re.MULTILINE)
            except re.error:
                pass  # 忽略编译错误的模式

    def parse_file(self, file_path: str) -> KotlinASTResult:
        """解析 Kotlin 文件"""
        path = Path(file_path)

        if not path.exists():
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".kt", ".kts"):
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 Kotlin 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except Exception as e:
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> KotlinASTResult:
        """解析 Kotlin 代码字符串"""
        result = KotlinASTResult(
            file_path=file_path,
            success=True,
            parse_mode="fast",
            total_lines=len(code.splitlines())
        )

        lines = code.split('\n')

        # 基础解析
        self._parse_package(code, result)
        self._parse_imports(code, result, lines)

        # Kotlin 特有特性解析
        self._parse_type_aliases(code, result, lines)
        self._parse_value_classes(code, result, lines)
        self._parse_sealed_classes(code, result, lines)
        self._parse_data_classes(code, result, lines)
        self._parse_enum_classes(code, result, lines)
        self._parse_objects(code, result, lines)
        self._parse_delegated_properties(code, result, lines)
        self._parse_coroutines(code, result, lines)
        self._parse_when_expressions(code, result, lines)
        self._parse_extension_functions(code, result, lines)
        self._parse_extension_properties(code, result, lines)

        # 顶层函数和属性
        self._parse_top_level(code, result, lines)

        # 普通类解析
        self._parse_classes(code, result, lines)

        return result

    def _parse_package(self, code: str, result: KotlinASTResult):
        """解析包声明"""
        match = self._compiled.get('package')
        if match:
            m = match.search(code)
            if m:
                result.package = m.group(1)

    def _parse_imports(self, code: str, result: KotlinASTResult, lines: list):
        """解析导入语句"""
        pattern = self._compiled.get('import')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.match(line.strip())
            if m:
                result.imports.append(KotlinImportInfo(
                    path=m.group(1),
                    alias=m.group(2) if len(m.groups()) > 1 else None,
                    line=i
                ))

    # ==================== 类型系统解析 ====================

    def _parse_type_aliases(self, code: str, result: KotlinASTResult, lines: list):
        """解析类型别名"""
        pattern = self._compiled.get('type_alias')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                name = m.group(1)
                type_params = m.group(2).split(',') if m.group(2) else []
                underlying = m.group(3).strip() if m.group(3) else ""

                result.type_aliases.append(KotlinTypeAlias(
                    name=name,
                    underlying_type=underlying,
                    type_params=type_params,
                    line=i
                ))

    def _parse_value_classes(self, code: str, result: KotlinASTResult, lines: list):
        """解析值类（内联类）"""
        pattern = self._compiled.get('value_class')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                name = m.group(1)
                wrapped = m.group(2).strip() if m.group(2) else ""

                result.value_classes.append(KotlinValueClass(
                    name=name,
                    wrapped_type=wrapped,
                    line=i
                ))

    # ==================== Sealed 类解析 ====================

    def _parse_sealed_classes(self, code: str, result: KotlinASTResult, lines: list):
        """解析 Sealed 类"""
        sealed_pattern = self._compiled.get('sealed_class')
        sealed_interface_pattern = self._compiled.get('sealed_interface')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # 跳过注释
            if stripped.startswith('//') or stripped.startswith('/*'):
                continue

            # 检查 sealed class
            m = None
            class_type = "sealed class"

            if sealed_pattern:
                m = sealed_pattern.search(stripped)

            if not m and sealed_interface_pattern:
                m = sealed_interface_pattern.search(stripped)
                class_type = "sealed interface"

            if m:
                name = m.group(1)
                type_params = m.group(2).split(',') if m.group(2) else []

                # 提取类体
                class_body, end_line = self._extract_block(lines, i)

                # 解析继承
                extends, implements = self._parse_inheritance(stripped)

                sealed_info = KotlinSealedClassInfo(
                    name=name,
                    line_start=i,
                    line_end=end_line,
                    class_type=class_type,
                    type_params=type_params,
                    primary_constructor_params=[],
                    extends=extends,
                    implements=implements,
                    modifiers=['sealed'],
                    annotations=[],
                    functions=[],
                    properties=[],
                    is_sealed=True,
                    permitted_subclasses=[]
                )

                # 解析类体中的成员
                if class_body:
                    self._parse_class_members(class_body, sealed_info)

                result.sealed_classes.append(sealed_info)

    def _parse_inheritance(self, line: str) -> tuple[Optional[str], list[str]]:
        """解析继承关系"""
        extends = None
        implements = []

        # 检查 : 后面的内容
        colon_match = re.search(r':\s*([^{]+?)(?:\s*\{|$)', line)
        if colon_match:
            inherit_str = colon_match.group(1).strip()
            parts = inherit_str.split(',')

            for part in parts:
                part = part.strip()
                if '(' in part:
                    # 有构造函数调用的是继承
                    extends = part.split('(')[0].strip()
                elif part:
                    implements.append(part)

        return extends, implements

    # ==================== 数据类解析 ====================

    def _parse_data_classes(self, code: str, result: KotlinASTResult, lines: list):
        """解析数据类"""
        pattern = self._compiled.get('data_class')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                name = m.group(1)
                type_params = m.group(2).split(',') if m.group(2) else []
                params_str = m.group(3) if m.group(3) else ""

                # 解析主构造函数参数
                primary_params = self._parse_params(params_str)

                # 提取类体
                class_body, end_line = self._extract_block(lines, i)

                extends, implements = self._parse_inheritance(line)

                data_info = KotlinDataClassInfo(
                    name=name,
                    line_start=i,
                    line_end=end_line,
                    class_type="data class",
                    type_params=type_params,
                    primary_constructor_params=primary_params,
                    extends=extends,
                    implements=implements,
                    modifiers=['data'],
                    annotations=[],
                    functions=[],
                    properties=[],
                    component_functions=[f"component{n+1}" for n in range(len(primary_params))],
                    copy_function_params=primary_params.copy()
                )

                if class_body:
                    self._parse_class_members(class_body, data_info)

                result.data_classes.append(data_info)

    # ==================== 枚举类解析 ====================

    def _parse_enum_classes(self, code: str, result: KotlinASTResult, lines: list):
        """解析枚举类"""
        pattern = self._compiled.get('enum_class')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                name = m.group(1)
                # 值类型（如果有）
                value_type = m.group(2).strip() if m.group(2) else None

                # 提取类体
                class_body, end_line = self._extract_block(lines, i)

                # 解析枚举条目
                entries = []
                if class_body:
                    entries = self._parse_enum_entries(class_body)

                enum_info = KotlinEnumClassInfo(
                    name=name,
                    line_start=i,
                    line_end=end_line,
                    class_type="enum class",
                    type_params=[],
                    primary_constructor_params=[],
                    extends=None,
                    implements=[],
                    modifiers=['enum'],
                    annotations=[],
                    functions=[],
                    properties=[],
                    entries=entries
                )

                if class_body:
                    self._parse_class_members(class_body, enum_info)

                result.enum_classes.append(enum_info)

    def _parse_enum_entries(self, class_body: str) -> list[dict]:
        """解析枚举条目"""
        entries = []
        # 查找枚举条目区域（在 ; 之前或 class body 中）
        entry_pattern = re.compile(r'^\s*(\w+)\s*(?:\(([^)]*)\))?\s*(?:,|(?=\n))', re.MULTILINE)

        for m in entry_pattern.finditer(class_body):
            name = m.group(1)
            # 跳过关键字
            if name in ('class', 'interface', 'object', 'fun', 'val', 'var'):
                continue

            params = m.group(2) if m.group(2) else None
            entries.append({
                'name': name,
                'params': params,
                'line': 0  # 简化，不提供精确行号
            })

        return entries

    # ==================== Object 解析 ====================

    def _parse_objects(self, code: str, result: KotlinASTResult, lines: list):
        """解析 Object 声明"""
        pattern = self._compiled.get('object_declaration')
        companion_pattern = self._compiled.get('companion_object')

        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # 跳过 companion object（在类解析中处理）
            if companion_pattern and companion_pattern.search(stripped):
                continue

            m = pattern.search(stripped)
            if m:
                name = m.group(1)
                extends_str = m.group(2) if m.group(2) else None

                extends, implements = self._parse_inheritance(stripped)

                _, end_line = self._extract_block(lines, i)

                obj_decl = KotlinObjectDeclaration(
                    name=name,
                    extends=extends or extends_str,
                    implements=implements,
                    is_companion=False,
                    line_start=i,
                    line_end=end_line
                )

                result.object_declarations.append(obj_decl)

    # ==================== 委托属性解析 ====================

    def _parse_delegated_properties(self, code: str, result: KotlinASTResult, lines: list):
        """解析委托属性"""
        pattern = self._compiled.get('delegated_property')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                is_val = m.group(1) == 'val'
                name = m.group(2)
                prop_type = m.group(3) if m.group(3) else "Unknown"
                delegate_expr = m.group(4).strip() if m.group(4) else ""

                # 判断委托类型
                delegate_type = "custom"
                for std_name in STANDARD_DELEGATES:
                    if delegate_expr.startswith(std_name):
                        delegate_type = std_name
                        break

                result.delegated_properties.append(KotlinDelegatedProperty(
                    name=name,
                    delegate_type=delegate_type,
                    delegate_expression=delegate_expr,
                    is_val=is_val,
                    line=i
                ))

    # ==================== 协程解析 ====================

    def _parse_coroutines(self, code: str, result: KotlinASTResult, lines: list):
        """解析协程和 Flow"""
        suspend_pattern = self._compiled.get('suspend_function')
        flow_pattern = self._compiled.get('flow_type')
        builder_pattern = self._compiled.get('coroutine_builder')
        operator_pattern = self._compiled.get('flow_operator')
        dispatcher_pattern = self._compiled.get('dispatcher')
        scope_pattern = self._compiled.get('coroutine_scope')

        # 解析 suspend 函数
        if suspend_pattern:
            for i, line in enumerate(lines, 1):
                m = suspend_pattern.search(line.strip())
                if m:
                    name = m.group(1)
                    params = m.group(2) if m.group(2) else ""
                    return_type = m.group(3).strip() if m.group(3) else None

                    # 检查 Flow 类型
                    flow_type = None
                    if return_type and flow_pattern:
                        flow_m = flow_pattern.search(return_type)
                        if flow_m:
                            flow_type = f"Flow<{flow_m.group(1)}>"

                    result.coroutines.append(KotlinCoroutineInfo(
                        function_name=name,
                        is_suspend=True,
                        flow_type=flow_type,
                        line=i
                    ))

        # 解析协程构建器
        if builder_pattern:
            for i, line in enumerate(lines, 1):
                for m in builder_pattern.finditer(line):
                    builder_type = m.group(1)

                    # 查找 dispatcher
                    dispatcher = None
                    if dispatcher_pattern:
                        disp_m = dispatcher_pattern.search(line)
                        if disp_m:
                            dispatcher = disp_m.group(1)

                    result.coroutines.append(KotlinCoroutineInfo(
                        function_name="<anonymous>",
                        is_suspend=False,
                        builder_type=builder_type,
                        dispatcher=dispatcher,
                        line=i
                    ))

        # 解析 Flow 操作符
        if operator_pattern:
            for i, line in enumerate(lines, 1):
                for m in operator_pattern.finditer(line):
                    op_name = m.group(1)
                    is_terminal = op_name in TERMINAL_FLOW_OPERATORS

                    result.flow_operators.append(KotlinFlowOperator(
                        name=op_name,
                        is_terminal=is_terminal,
                        line=i
                    ))

    # ==================== When 表达式解析 ====================

    def _parse_when_expressions(self, code: str, result: KotlinASTResult, lines: list):
        """解析 when 表达式"""
        pattern = self._compiled.get('when_expression')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                subject_var = m.group(1).strip() if m.group(1) else None
                subject_type = None

                # 提取 when 体
                when_body, end_line = self._extract_block(lines, i)

                # 解析分支
                branches = []
                if when_body:
                    branches = self._parse_when_branches(when_body)

                result.when_expressions.append(KotlinWhenExpression(
                    subject_type=subject_type,
                    subject_variable=subject_var,
                    branches=branches,
                    is_exhaustive=None,  # 需要类型推断
                    line_start=i,
                    line_end=end_line
                ))

    def _parse_when_branches(self, when_body: str) -> list[dict]:
        """解析 when 分支"""
        branches = []
        lines = when_body.split('\n')

        branch_pattern = re.compile(r'^\s*(.+?)\s*->')

        for line in lines:
            m = branch_pattern.match(line)
            if m:
                pattern_str = m.group(1).strip()
                is_else = pattern_str == 'else'

                branches.append({
                    'pattern': pattern_str,
                    'is_else': is_else,
                    'line': 0
                })

        return branches

    # ==================== 扩展函数/属性解析 ====================

    def _parse_extension_functions(self, code: str, result: KotlinASTResult, lines: list):
        """解析扩展函数"""
        pattern = self._compiled.get('extension_function')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                receiver = m.group(1)
                name = m.group(2)
                params = m.group(3) if m.group(3) else ""
                return_type = m.group(4).strip() if m.group(4) else None

                # 检查是否在类内（分发接收者）
                in_class = self._is_inside_class(code, i)

                result.extension_functions.append(KotlinExtensionFunction(
                    name=name,
                    line_start=i,
                    line_end=i,
                    return_type=return_type,
                    parameters=self._parse_params(params),
                    modifiers=[],
                    type_params=[],
                    receiver_type=receiver,
                    dispatch_receiver=in_class
                ))

    def _parse_extension_properties(self, code: str, result: KotlinASTResult, lines: list):
        """解析扩展属性"""
        pattern = self._compiled.get('extension_property')
        if not pattern:
            return

        for i, line in enumerate(lines, 1):
            m = pattern.search(line.strip())
            if m:
                is_val = m.group(1) == 'val'
                receiver = m.group(2)
                name = m.group(3)

                result.extension_properties.append(KotlinExtensionProperty(
                    name=name,
                    receiver_type=receiver,
                    property_type="Unknown",
                    is_val=is_val,
                    line=i
                ))

    def _is_inside_class(self, code: str, line_num: int) -> bool:
        """检查某行是否在类内部"""
        lines = code.split('\n')
        depth = 0

        for i, line in enumerate(lines, 1):
            if i >= line_num:
                return depth > 0

            depth += line.count('{') - line.count('}')

        return False

    # ==================== 顶层结构解析 ====================

    def _parse_top_level(self, code: str, result: KotlinASTResult, lines: list):
        """解析顶层函数和属性"""
        brace_depth = 0
        in_block_comment = False

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # 处理块注释
            if '/*' in stripped:
                in_block_comment = True
            if '*/' in stripped:
                in_block_comment = False
                continue
            if in_block_comment:
                continue

            # 跳过行注释
            if stripped.startswith('//'):
                brace_depth += line.count('{') - line.count('}')
                continue

            # 只处理顶层
            if brace_depth == 0:
                # 解析顶层函数
                if 'fun ' in stripped and 'class ' not in stripped and 'sealed' not in stripped:
                    func = self._parse_function_line(stripped, i)
                    if func:
                        result.functions.append(func)

                # 解析顶层属性
                elif stripped.startswith('val ') or stripped.startswith('var '):
                    prop = self._parse_property_line(stripped, i)
                    if prop:
                        result.properties.append(prop)

            # 更新大括号深度
            brace_depth += line.count('{') - line.count('}')

    def _parse_function_line(self, line: str, line_num: int) -> Optional[KotlinFunctionInfo]:
        """解析函数行"""
        # 简单提取函数名
        name_match = re.search(r'fun\s+(?:<[^>]+>\s+)?(\w+)\s*\(', line)
        if not name_match:
            return None

        name = name_match.group(1)

        # 提取参数
        params_match = re.search(r'fun\s+\w+\s*\(([^)]*)\)', line)
        params = self._parse_params(params_match.group(1)) if params_match else []

        # 提取返回类型
        return_type = None
        ret_match = re.search(r'\)\s*:\s*([^{=\n]+)', line)
        if ret_match:
            return_type = ret_match.group(1).strip()

        # 提取修饰符
        modifiers = []
        for mod in ['suspend', 'inline', 'tailrec', 'operator', 'infix', 'public', 'private', 'protected', 'internal', 'open', 'override']:
            if re.search(rf'\b{mod}\b', line.split('fun')[0]):
                modifiers.append(mod)

        return KotlinFunctionInfo(
            name=name,
            line_start=line_num,
            line_end=line_num,
            return_type=return_type,
            parameters=params,
            modifiers=modifiers,
            type_params=[]
        )

    def _parse_property_line(self, line: str, line_num: int) -> Optional[KotlinPropertyInfo]:
        """解析属性行"""
        is_val = line.strip().startswith('val')

        # 提取属性名
        name_match = re.search(r'(val|var)\s+(\w+)', line)
        if not name_match:
            return None

        name = name_match.group(2)

        # 提取类型
        prop_type = "Unknown"
        type_match = re.search(r':\s*([^\s=]+)', line)
        if type_match:
            prop_type = type_match.group(1).strip()

        # 提取修饰符
        modifiers = []
        for mod in ['public', 'private', 'protected', 'internal', 'lateinit', 'const', 'override']:
            prefix = line.split('val')[0] if 'val' in line else line.split('var')[0]
            if mod in prefix:
                modifiers.append(mod)

        # 检查是否为委托属性
        is_delegate = ' by ' in line

        return KotlinPropertyInfo(
            name=name,
            type=prop_type,
            line=line_num,
            is_val=is_val,
            modifiers=modifiers,
            is_delegate=is_delegate
        )

    # ==================== 类解析 ====================

    def _parse_classes(self, code: str, result: KotlinASTResult, lines: list):
        """解析普通类声明"""
        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # 跳过已解析的特殊类型
            if any(kw in stripped for kw in ['sealed class', 'sealed interface', 'data class', 'enum class', 'value class']):
                continue

            # 检查普通类声明
            class_match = self._match_class_declaration(stripped)
            if class_match:
                class_info = self._parse_class_declaration(code, lines, i, class_match)
                if class_info:
                    result.classes.append(class_info)

    def _match_class_declaration(self, line: str) -> Optional[re.Match]:
        """匹配类声明"""
        patterns = [
            # interface
            r'(?:(public|private|protected|internal)\s+)*'
            r'(interface)\s+(\w+)(?:<([^>]+)>)?',
            # 普通类
            r'(?:(public|private|protected|internal|open|abstract|final|inner)\s+)*'
            r'(class)\s+(\w+)(?:<([^>]+)>)?',
        ]

        for pattern in patterns:
            match = re.match(pattern, line)
            if match:
                return match
        return None

    def _parse_class_declaration(self, code: str, lines: list, line_num: int, match: re.Match) -> Optional[KotlinClassInfo]:
        """解析类声明"""
        groups = match.groups()

        # 提取类类型和名称
        class_type = "class"
        name = "Unknown"
        type_params_str = None
        modifiers = []

        idx = 0
        # 提取修饰符
        while idx < len(groups) and groups[idx] and groups[idx] in ('public', 'private', 'protected', 'internal', 'open', 'abstract', 'final', 'inner'):
            modifiers.append(groups[idx])
            idx += 1

        # 类类型
        if idx < len(groups) and groups[idx]:
            class_type = groups[idx]
            idx += 1

        # 类名
        if idx < len(groups) and groups[idx]:
            name = groups[idx]
            idx += 1

        # 泛型参数
        if idx < len(groups) and groups[idx]:
            type_params_str = groups[idx]

        type_params = [p.strip() for p in type_params_str.split(',')] if type_params_str else []

        # 解析主构造函数参数
        primary_params = []
        constructor_match = re.search(r'\(([^)]*)\)', lines[line_num - 1])
        if constructor_match:
            primary_params = self._parse_params(constructor_match.group(1))

        # 解析继承
        extends, implements = self._parse_inheritance(lines[line_num - 1])

        # 提取类体
        class_body, end_line = self._extract_block(lines, line_num)

        # 创建类信息
        class_info = KotlinClassInfo(
            name=name,
            line_start=line_num,
            line_end=end_line,
            class_type=class_type,
            type_params=type_params,
            primary_constructor_params=primary_params,
            extends=extends,
            implements=implements,
            modifiers=modifiers,
            annotations=[],
            functions=[],
            properties=[]
        )

        # 解析类体中的成员
        if class_body:
            self._parse_class_members(class_body, class_info)

        return class_info

    def _parse_class_members(self, class_body: str, class_info):
        """解析类成员"""
        for line in class_body.split('\n'):
            stripped = line.strip()

            # 跳过空行和注释
            if not stripped or stripped.startswith('//'):
                continue

            # 解析函数
            if 'fun ' in stripped:
                func = self._parse_function_line(stripped, 0)
                if func:
                    class_info.functions.append(func)

            # 解析属性
            elif stripped.startswith('val ') or stripped.startswith('var '):
                prop = self._parse_property_line(stripped, 0)
                if prop:
                    class_info.properties.append(prop)

    # ==================== 辅助方法 ====================

    def _extract_block(self, lines: list, start_line: int) -> tuple[str, int]:
        """提取代码块（大括号包围）"""
        brace_depth = 0
        body_lines = []
        started = False

        for i in range(start_line - 1, len(lines)):
            line = lines[i]

            if '{' in line:
                started = True

            if started:
                body_lines.append(line)
                brace_depth += line.count('{') - line.count('}')

                if brace_depth == 0:
                    return '\n'.join(body_lines), i + 1

        return '\n'.join(body_lines), len(lines)

    def _parse_params(self, params_str: str) -> list[dict]:
        """解析参数列表"""
        if not params_str.strip():
            return []

        params = []
        # 简单分割（不考虑嵌套的括号）
        for param in params_str.split(','):
            param = param.strip()
            if not param:
                continue

            # 参数格式: name: Type = default
            parts = param.split('=')
            name_type = parts[0].strip()
            default_value = parts[1].strip() if len(parts) > 1 else None

            # 分离名称和类型
            if ':' in name_type:
                name_part, type_part = name_type.split(':', 1)
                params.append({
                    'name': name_part.strip(),
                    'type': type_part.strip(),
                    'default_value': default_value
                })
            else:
                params.append({
                    'name': name_type,
                    'type': 'Any',
                    'default_value': default_value
                })

        return params
