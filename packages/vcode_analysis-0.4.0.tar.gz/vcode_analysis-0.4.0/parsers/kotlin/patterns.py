"""Kotlin 正则表达式模式定义

定义用于快速解析 Kotlin 代码的正则表达式模式。
"""

# 基础模式
KOTLIN_PATTERNS = {
    # 包声明
    "package": r'^package\s+([\w.]+)',

    # 导入
    "import": r'^import\s+([\w.]+)(?:\s+as\s+(\w+))?',

    # 类声明（基础）
    "class": r'(?:(public|private|protected|internal|open|abstract|final|sealed|data|enum|annotation|inner|companion)\s+)*'
             r'(class|interface|object)\s+(\w+)(?:<([^>]+)>)?(?:\s*\(([^)]*)\))?(?:\s*:\s*([^{]+?))?(?:\s*\{|$)',

    # 函数声明
    "function": r'(?:(public|private|protected|internal|open|abstract|final|suspend|inline|tailrec|operator|infix)\s+)*'
                r'fun\s+(?:<([^>]+)>\s+)?(?:([^\s.]+)\.)?(\w+)\s*\(([^)]*)\)(?:\s*:\s*([^{=\n]+))?',

    # 属性声明
    "property": r'(?:(public|private|protected|internal|open|override|lateinit|const)\s+)*'
                r'(val|var)\s+(\w+)\s*(?::\s*([^\s=]+))?(?:\s*=|\s*\{|\s*$)',

    # 注解
    "annotation": r'@(\w+)(?:\([^)]*\))?',
}

# Kotlin 特有模式
KOTLIN_ADVANCED_PATTERNS = {
    # ==================== Sealed 类 ====================

    # Sealed 类声明
    "sealed_class": r'(?:sealed\s+class\s+(\w+)(?:<([^>]+)>)?)',

    # Sealed 接口声明 (Kotlin 1.5+)
    "sealed_interface": r'(?:sealed\s+interface\s+(\w+)(?:<([^>]+)>)?)',

    # When 表达式
    "when_expression": r'when\s*(?:\(([^)]*)\))?\s*\{',

    # When 分支
    "when_branch": r'([^\n]->|is\s+\w+|else)\s*->',

    # ==================== 协程与 Flow ====================

    # Suspend 函数
    "suspend_function": r'suspend\s+fun\s+(\w+)\s*\(([^)]*)\)(?:\s*:\s*([^{=\n]+))?',

    # Flow 类型
    "flow_type": r'(?:Flow|StateFlow|MutableStateFlow|SharedFlow|MutableSharedFlow)<([^>]+)>',

    # 协程构建器
    "coroutine_builder": r'(launch|async|runBlocking|withContext|coroutineScope|supervisorScope)\s*(?:\{|<|.)',

    # Flow 操作符
    "flow_operator": r'\.(map|filter|collect|onEach|onStart|onCompletion|catch|combine|zip|flatMapLatest|flatMapMerge|transform|take|drop|distinctUntilChanged|debounce|throttle|sample|conflate|buffer|flowOn)\s*\(',

    # Dispatcher
    "dispatcher": r'Dispatchers\.(Default|IO|Main|Unconfined)|Dispatcher\.(Default|IO|Main|Unconfined)',

    # 协程作用域
    "coroutine_scope": r'(lifecycleScope|viewModelScope|GlobalScope|CoroutineScope|rememberCoroutineScope)',

    # ==================== 类型系统 ====================

    # 类型别名
    "type_alias": r'typealias\s+(\w+)(?:<([^>]+)>)?\s*=\s*(.+?)(?:\s*$)',

    # 值类 (Value class / 内联类)
    "value_class": r'(?:value\s+class|inline\s+class)\s+(\w+)(?:\s*\(([^)]*)\))?',

    # 泛型变型
    "variance": r'(?:class|interface)\s+\w+<(in|out)\s+(\w+)>',

    # 泛型约束
    "type_constraint": r'where\s+(\w+)\s*:\s*([^,\n]+)',

    # 可空类型
    "nullable_type": r'(\w+)(?:<[^>]+>)?\?',

    # 平台类型 (Java 互操作)
    "platform_type": r'(\w+)!!',

    # ==================== 属性委托 ====================

    # 委托属性
    "delegated_property": r'(val|var)\s+(\w+)\s*(?::\s*([^\s=]+))?\s+by\s+(.+?)(?:\s*$|\s*\n)',

    # 标准委托
    "standard_delegate": r'(lazy|observable|vetoable|delegates)\s*(?:<[^>]+>)?\s*\{',

    # 属性引用
    "property_reference": r'::(\w+)',

    # 提供委托
    "provide_delegate": r'provideDelegate\s*\(',

    # ==================== 其他 Kotlin 特性 ====================

    # 扩展函数
    "extension_function": r'fun\s+([^\s.]+)\.(\w+)\s*\(([^)]*)\)(?:\s*:\s*([^{=\n]+))?',

    # 扩展属性
    "extension_property": r'(val|var)\s+([^\s.]+)\.(\w+)',

    # 数据类
    "data_class": r'data\s+class\s+(\w+)(?:<([^>]+)>)?\s*\(([^)]*)\)',

    # 枚举类
    "enum_class": r'enum\s+class\s+(\w+)(?:\s*\:(.+?))?',

    # 枚举条目
    "enum_entry": r'^\s*(\w+)\s*(?:\(([^)]*)\))?(?:,|\s*$)',

    # Object 声明
    "object_declaration": r'object\s+(\w+)(?:\s*:\s*([^{]+?))?(?:\s*\{|$)',

    # Companion object
    "companion_object": r'companion\s+object\s*(?::\s*(\w+))?\s*\{',

    # 初始化块
    "init_block": r'init\s*\{',

    # 尾递归函数
    "tailrec_function": r'tailrec\s+fun\s+(\w+)',

    # 操作符重载
    "operator_function": r'operator\s+fun\s+(\w+)',

    # 中缀函数
    "infix_function": r'infix\s+fun\s+(\w+)',

    # 内联函数
    "inline_function": r'(?:inline|noinline|crossinline)\s+fun',

    # 具体化类型参数
    "reified_type": r'inline\s+fun\s+<reified\s+(\w+)>',

    # 契约
    "contract": r'contract\s*\{',
}

# 合并所有模式
ALL_KOTLIN_PATTERNS = {**KOTLIN_PATTERNS, **KOTLIN_ADVANCED_PATTERNS}
