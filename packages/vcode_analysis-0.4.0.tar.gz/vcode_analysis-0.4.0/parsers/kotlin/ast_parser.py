"""Kotlin AST 解析器（tree-sitter）

使用 tree-sitter-kotlin 进行精确的语法树解析。
"""

from pathlib import Path
from typing import Optional

try:
    import tree_sitter_kotlin
    from tree_sitter import Language, Parser

    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False
    Parser = None
    Language = None

from .models import (
    KotlinASTResult,
    KotlinFunctionInfo,
    KotlinPropertyInfo,
    KotlinClassInfo,
    KotlinImportInfo,
    KotlinSealedClassInfo,
    KotlinWhenExpression,
    KotlinCoroutineInfo,
    KotlinFlowOperator,
    KotlinTypeAlias,
    KotlinValueClass,
    KotlinDelegatedProperty,
    KotlinExtensionFunction,
    KotlinExtensionProperty,
    KotlinObjectDeclaration,
    KotlinEnumClassInfo,
    KotlinDataClassInfo,
    TERMINAL_FLOW_OPERATORS,
)


class KotlinTreeSitterParser:
    """Kotlin AST 解析器（精确模式）"""

    def __init__(self):
        if not TREE_SITTER_AVAILABLE:
            raise ImportError(
                "请安装 tree-sitter 和 tree-sitter-kotlin: "
                "pip install tree-sitter tree-sitter-kotlin"
            )

        # 初始化 parser
        self.language = Language(tree_sitter_kotlin.language())
        self.parser = Parser(self.language)

    def parse_file(self, file_path: str) -> KotlinASTResult:
        """解析 Kotlin 文件"""
        path = Path(file_path)

        if not path.exists():
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".kt", ".kts"):
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 Kotlin 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except Exception as e:
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> KotlinASTResult:
        """解析 Kotlin 代码字符串"""
        result = KotlinASTResult(
            file_path=file_path,
            success=True,
            parse_mode="precise",
            total_lines=len(code.splitlines())
        )

        try:
            # 解析代码
            tree = self.parser.parse(bytes(code, "utf-8"))
            root = tree.root_node

            # 遍历 AST
            self._traverse_ast(root, code, result)

        except Exception as e:
            result.success = False
            result.error = f"AST 解析错误: {str(e)}"

        return result

    def _traverse_ast(self, node, code: str, result: KotlinASTResult):
        """遍历 AST 节点"""
        source = code.encode('utf-8')

        # 处理顶层声明
        for child in node.children:
            node_type = child.type

            if node_type == 'package_header':
                self._parse_package(child, source, result)

            elif node_type == 'import_header':
                self._parse_import(child, source, result)

            elif node_type == 'class_declaration':
                self._parse_class(child, source, result)

            elif node_type == 'function_declaration':
                func = self._parse_function(child, source)
                if func:
                    result.functions.append(func)

            elif node_type == 'property_declaration':
                prop = self._parse_property(child, source)
                if prop:
                    result.properties.append(prop)

            elif node_type == 'type_alias':
                self._parse_type_alias(child, source, result)

            elif node_type == 'object_declaration':
                self._parse_object(child, source, result)

    def _get_text(self, node, source: bytes) -> str:
        """获取节点文本"""
        return source[node.start_byte:node.end_byte].decode('utf-8')

    def _get_line(self, node) -> int:
        """获取节点起始行号（1-indexed）"""
        return node.start_point[0] + 1

    # ==================== 包和导入 ====================

    def _parse_package(self, node, source: bytes, result: KotlinASTResult):
        """解析包声明"""
        for child in node.children:
            if child.type == 'identifier':
                result.package = self._get_text(child, source)
                break

    def _parse_import(self, node, source: bytes, result: KotlinASTResult):
        """解析导入语句"""
        path = ""
        alias = None

        for child in node.children:
            if child.type == 'identifier':
                path = self._get_text(child, source)
            elif child.type == 'import_alias':
                alias = self._get_text(child, source)

        result.imports.append(KotlinImportInfo(
            path=path,
            alias=alias,
            line=self._get_line(node)
        ))

    # ==================== 类型别名 ====================

    def _parse_type_alias(self, node, source: bytes, result: KotlinASTResult):
        """解析类型别名"""
        name = ""
        underlying = ""
        type_params = []

        for child in node.children:
            if child.type == 'type_identifier':
                name = self._get_text(child, source)
            elif child.type == 'type_parameters':
                type_params = self._parse_type_params(child, source)
            elif child.type == 'user_type':
                underlying = self._get_text(child, source)

        result.type_aliases.append(KotlinTypeAlias(
            name=name,
            underlying_type=underlying,
            type_params=type_params,
            line=self._get_line(node)
        ))

    # ==================== 类声明 ====================

    def _parse_class(self, node, source: bytes, result: KotlinASTResult):
        """解析类声明"""
        # 检查类类型
        modifiers = []
        class_type = "class"
        name = ""
        type_params = []
        extends = None
        implements = []
        primary_params = []

        # 解析修饰符
        for child in node.children:
            if child.type == 'modifiers':
                modifiers = self._parse_modifiers(child, source)

            elif child.type == 'class_body':
                # 类体在后面处理
                pass

            elif child.type == 'primary_constructor':
                primary_params = self._parse_primary_constructor(child, source)

            elif child.type == 'type_identifier':
                name = self._get_text(child, source)

            elif child.type == 'type_parameters':
                type_params = self._parse_type_params(child, source)

            elif child.type == 'delegation_specifier':
                extends, implements = self._parse_delegation(child, source)

        # 判断特殊类类型
        if 'sealed' in modifiers:
            class_info = self._create_sealed_class(node, source, name, modifiers, type_params, primary_params, extends, implements)
            result.sealed_classes.append(class_info)
        elif 'data' in modifiers:
            class_info = self._create_data_class(node, source, name, type_params, primary_params, extends, implements)
            result.data_classes.append(class_info)
        elif 'enum' in modifiers:
            class_info = self._create_enum_class(node, source, name, type_params, primary_params, extends, implements)
            result.enum_classes.append(class_info)
        elif 'value' in modifiers or 'inline' in modifiers:
            result.value_classes.append(KotlinValueClass(
                name=name,
                wrapped_type=primary_params[0].get('type', '') if primary_params else '',
                type_params=type_params,
                line=self._get_line(node)
            ))
        else:
            class_info = self._create_class(node, source, name, class_type, modifiers, type_params, primary_params, extends, implements)
            result.classes.append(class_info)

    def _create_class(self, node, source, name, class_type, modifiers, type_params, primary_params, extends, implements) -> KotlinClassInfo:
        """创建普通类信息"""
        class_info = KotlinClassInfo(
            name=name,
            line_start=self._get_line(node),
            line_end=node.end_point[0] + 1,
            class_type=class_type,
            type_params=type_params,
            primary_constructor_params=primary_params,
            extends=extends,
            implements=implements,
            modifiers=modifiers,
            annotations=[],
            functions=[],
            properties=[]
        )

        # 解析类体
        self._parse_class_body(node, source, class_info)

        return class_info

    def _create_sealed_class(self, node, source, name, modifiers, type_params, primary_params, extends, implements) -> KotlinSealedClassInfo:
        """创建 sealed 类信息"""
        class_info = KotlinSealedClassInfo(
            name=name,
            line_start=self._get_line(node),
            line_end=node.end_point[0] + 1,
            class_type="sealed class",
            type_params=type_params,
            primary_constructor_params=primary_params,
            extends=extends,
            implements=implements,
            modifiers=modifiers,
            annotations=[],
            functions=[],
            properties=[],
            is_sealed=True,
            permitted_subclasses=[]
        )

        self._parse_class_body(node, source, class_info)

        return class_info

    def _create_data_class(self, node, source, name, type_params, primary_params, extends, implements) -> KotlinDataClassInfo:
        """创建数据类信息"""
        class_info = KotlinDataClassInfo(
            name=name,
            line_start=self._get_line(node),
            line_end=node.end_point[0] + 1,
            class_type="data class",
            type_params=type_params,
            primary_constructor_params=primary_params,
            extends=extends,
            implements=implements,
            modifiers=['data'],
            annotations=[],
            functions=[],
            properties=[],
            component_functions=[f"component{n+1}" for n in range(len(primary_params))],
            copy_function_params=primary_params.copy()
        )

        self._parse_class_body(node, source, class_info)

        return class_info

    def _create_enum_class(self, node, source, name, type_params, primary_params, extends, implements) -> KotlinEnumClassInfo:
        """创建枚举类信息"""
        entries = []

        # 查找枚举条目
        for child in node.children:
            if child.type == 'enum_class_body':
                for entry in child.children:
                    if entry.type == 'enum_entry':
                        entry_name = ""
                        entry_params = None

                        for ec in entry.children:
                            if ec.type == 'simple_identifier':
                                entry_name = self._get_text(ec, source)
                            elif ec.type == 'value_arguments':
                                entry_params = self._get_text(ec, source)

                        if entry_name:
                            entries.append({
                                'name': entry_name,
                                'params': entry_params,
                                'line': self._get_line(entry)
                            })

        class_info = KotlinEnumClassInfo(
            name=name,
            line_start=self._get_line(node),
            line_end=node.end_point[0] + 1,
            class_type="enum class",
            type_params=type_params,
            primary_constructor_params=primary_params,
            extends=extends,
            implements=implements,
            modifiers=['enum'],
            annotations=[],
            functions=[],
            properties=[],
            entries=entries
        )

        self._parse_class_body(node, source, class_info)

        return class_info

    def _parse_class_body(self, node, source, class_info):
        """解析类体"""
        for child in node.children:
            if child.type == 'class_body':
                for member in child.children:
                    if member.type == 'function_declaration':
                        func = self._parse_function(member, source)
                        if func:
                            class_info.functions.append(func)

                    elif member.type == 'property_declaration':
                        prop = self._parse_property(member, source)
                        if prop:
                            class_info.properties.append(prop)

    def _parse_modifiers(self, node, source: bytes) -> list[str]:
        """解析修饰符"""
        modifiers = []
        for child in node.children:
            if child.type == 'member_modifier':
                modifiers.append(self._get_text(child, source))
            elif child.type == 'visibility_modifier':
                modifiers.append(self._get_text(child, source))
            elif child.type == 'class_modifier':
                modifiers.append(self._get_text(child, source))
        return modifiers

    def _parse_type_params(self, node, source: bytes) -> list[str]:
        """解析类型参数"""
        params = []
        for child in node.children:
            if child.type == 'type_parameter':
                for tc in child.children:
                    if tc.type == 'simple_identifier':
                        params.append(self._get_text(tc, source))
        return params

    def _parse_primary_constructor(self, node, source: bytes) -> list[dict]:
        """解析主构造函数"""
        params = []
        for child in node.children:
            if child.type == 'class_parameter':
                param_name = ""
                param_type = ""
                default_value = None

                for pc in child.children:
                    if pc.type == 'simple_identifier':
                        param_name = self._get_text(pc, source)
                    elif pc.type == 'type':
                        param_type = self._get_text(pc, source)
                    elif pc.type == '=':
                        # 有默认值
                        pass

                if param_name:
                    params.append({
                        'name': param_name,
                        'type': param_type,
                        'default_value': default_value
                    })

        return params

    def _parse_delegation(self, node, source: bytes) -> tuple[Optional[str], list[str]]:
        """解析继承和实现"""
        extends = None
        implements = []

        text = self._get_text(node, source)

        # 简单解析
        if '(' in text:
            extends = text.split('(')[0].strip()
        else:
            implements.append(text.strip())

        return extends, implements

    # ==================== 函数解析 ====================

    def _parse_function(self, node, source: bytes) -> Optional[KotlinFunctionInfo]:
        """解析函数声明"""
        name = ""
        return_type = None
        parameters = []
        modifiers = []
        type_params = []
        receiver_type = None

        for child in node.children:
            if child.type == 'simple_identifier':
                name = self._get_text(child, source)

            elif child.type == 'function_value_parameters':
                parameters = self._parse_parameters(child, source)

            elif child.type == 'type':
                return_type = self._get_text(child, source)

            elif child.type == 'modifiers':
                modifiers = self._parse_modifiers(child, source)

            elif child.type == 'type_parameters':
                type_params = self._parse_type_params(child, source)

            elif child.type == 'receiver_type':
                receiver_type = self._get_text(child, source)

        if not name:
            return None

        # 检查协程相关
        is_suspend = 'suspend' in modifiers

        return KotlinFunctionInfo(
            name=name,
            line_start=self._get_line(node),
            line_end=node.end_point[0] + 1,
            return_type=return_type,
            parameters=parameters,
            modifiers=modifiers,
            type_params=type_params,
            receiver_type=receiver_type,
            is_operator='operator' in modifiers,
            is_infix='infix' in modifiers,
            is_tailrec='tailrec' in modifiers
        )

    def _parse_parameters(self, node, source: bytes) -> list[dict]:
        """解析参数列表"""
        params = []
        for child in node.children:
            if child.type == 'parameter':
                param_name = ""
                param_type = ""
                default_value = None

                for pc in child.children:
                    if pc.type == 'simple_identifier':
                        param_name = self._get_text(pc, source)
                    elif pc.type == 'type':
                        param_type = self._get_text(pc, source)
                    elif pc.type == '=':
                        # 默认值标记
                        pass

                if param_name:
                    params.append({
                        'name': param_name,
                        'type': param_type,
                        'default_value': default_value
                    })

        return params

    # ==================== 属性解析 ====================

    def _parse_property(self, node, source: bytes) -> Optional[KotlinPropertyInfo]:
        """解析属性声明"""
        name = ""
        prop_type = "Unknown"
        is_val = True
        modifiers = []
        is_delegate = False

        for child in node.children:
            if child.type == 'val':
                is_val = True
            elif child.type == 'var':
                is_val = False
            elif child.type == 'simple_identifier':
                name = self._get_text(child, source)
            elif child.type == 'type':
                prop_type = self._get_text(child, source)
            elif child.type == 'modifiers':
                modifiers = self._parse_modifiers(child, source)
            elif child.type == 'by':
                is_delegate = True

        if not name:
            return None

        return KotlinPropertyInfo(
            name=name,
            type=prop_type,
            line=self._get_line(node),
            is_val=is_val,
            modifiers=modifiers,
            is_delegate=is_delegate
        )

    # ==================== Object 解析 ====================

    def _parse_object(self, node, source: bytes, result: KotlinASTResult):
        """解析 object 声明"""
        name = ""
        extends = None
        implements = []
        is_companion = False

        for child in node.children:
            if child.type == 'simple_identifier':
                name = self._get_text(child, source)
            elif child.type == 'delegation_specifier':
                extends, implements = self._parse_delegation(child, source)
            elif child.type == 'companion':
                is_companion = True

        if name:
            result.object_declarations.append(KotlinObjectDeclaration(
                name=name,
                extends=extends,
                implements=implements,
                is_companion=is_companion,
                line_start=self._get_line(node),
                line_end=node.end_point[0] + 1
            ))


# 如果 tree-sitter 不可用，提供一个占位类
if not TREE_SITTER_AVAILABLE:
    class KotlinTreeSitterParser:
        def __init__(self):
            raise ImportError(
                "请安装 tree-sitter 和 tree-sitter-kotlin: "
                "pip install tree-sitter tree-sitter-kotlin"
            )
