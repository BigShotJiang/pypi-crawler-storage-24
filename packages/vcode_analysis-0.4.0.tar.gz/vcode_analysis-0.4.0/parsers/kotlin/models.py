"""Kotlin 解析数据模型

定义 Kotlin 代码解析结果的数据结构。
"""

from dataclasses import dataclass, field
from typing import Optional, Literal


# ==================== 基础类型 ====================

@dataclass
class KotlinFunctionInfo:
    """Kotlin 函数信息"""
    name: str
    line_start: int
    line_end: int
    return_type: Optional[str]
    parameters: list[dict]  # {name, type, default_value}
    modifiers: list[str]  # public, private, suspend, inline, etc.
    type_params: list[str]  # 泛型参数
    receiver_type: Optional[str] = None  # 扩展函数接收者
    is_operator: bool = False
    is_infix: bool = False
    is_tailrec: bool = False


@dataclass
class KotlinPropertyInfo:
    """Kotlin 属性信息"""
    name: str
    type: str
    line: int
    is_val: bool  # val vs var
    modifiers: list[str]
    is_delegate: bool = False  # 委托属性


@dataclass
class KotlinClassInfo:
    """Kotlin 类信息"""
    name: str
    line_start: int
    line_end: int
    class_type: str  # class, interface, object, enum class, sealed class, data class
    type_params: list[str]  # 泛型参数
    primary_constructor_params: list[dict]
    extends: Optional[str]
    implements: list[str]
    modifiers: list[str]
    annotations: list[str]
    functions: list[KotlinFunctionInfo]
    properties: list[KotlinPropertyInfo]


@dataclass
class KotlinImportInfo:
    """Kotlin 导入信息"""
    path: str
    alias: Optional[str]  # as alias
    line: int


# ==================== Sealed 类层次结构 ====================

@dataclass
class KotlinSealedClassInfo(KotlinClassInfo):
    """Sealed 类信息"""
    is_sealed: bool = True
    permitted_subclasses: list[str] = field(default_factory=list)  # 允许的子类列表
    when_expressions: list['KotlinWhenExpression'] = field(default_factory=list)


@dataclass
class KotlinWhenExpression:
    """When 表达式信息"""
    subject_type: Optional[str]  # 被检查的类型
    subject_variable: Optional[str]  # 被检查的变量名
    branches: list[dict]  # [{pattern: str, is_else: bool, line: int}]
    is_exhaustive: Optional[bool] = None  # 是否穷尽（需要类型推断）
    line_start: int = 0
    line_end: int = 0


# ==================== 协程与 Flow ====================

@dataclass
class KotlinCoroutineInfo:
    """协程信息"""
    function_name: str
    is_suspend: bool
    coroutine_scope: Optional[str] = None  # CoroutineScope, lifecycleScope 等
    flow_type: Optional[str] = None  # Flow, StateFlow, SharedFlow
    dispatcher: Optional[str] = None  # IO, Default, Main, Unconfined
    builder_type: Optional[str] = None  # launch, async, runBlocking
    line: int = 0


@dataclass
class KotlinFlowOperator:
    """Flow 操作符信息"""
    name: str  # map, filter, collect 等
    input_type: Optional[str] = None
    output_type: Optional[str] = None
    is_terminal: bool = False  # 是否为终端操作符 (collect, first, single 等)
    line: int = 0


# Flow 终端操作符列表
TERMINAL_FLOW_OPERATORS = {
    'collect', 'collectLatest', 'collectIndexed', 'collectWhile',
    'first', 'firstOrNull', 'last', 'lastOrNull',
    'single', 'singleOrNull', 'toList', 'toSet', 'count',
    'reduce', 'fold', 'launchIn', 'onEach'
}


# ==================== 类型系统特性 ====================

@dataclass
class KotlinTypeAlias:
    """类型别名"""
    name: str
    underlying_type: str
    type_params: list[str] = field(default_factory=list)
    line: int = 0


@dataclass
class KotlinValueClass:
    """值类（内联类）"""
    name: str
    wrapped_type: str
    type_params: list[str] = field(default_factory=list)
    line: int = 0


@dataclass
class KotlinGenericType:
    """泛型信息"""
    name: str
    variance: Literal['in', 'out', 'none'] = 'none'
    bounds: list[str] = field(default_factory=list)  # 类型上界
    is_reified: bool = False


# ==================== 属性委托 ====================

@dataclass
class KotlinDelegatedProperty:
    """委托属性"""
    name: str
    delegate_type: str  # lazy, observable, vetoable, custom
    delegate_expression: Optional[str] = None
    is_val: bool = True
    line: int = 0


@dataclass
class KotlinPropertyDelegate:
    """属性委托类型"""
    name: str  # lazy, observable, vetoable, by viewModels() 等
    is_standard: bool = True  # 是否为标准库委托
    provides_getter: bool = True
    provides_setter: bool = False


# 标准委托类型
STANDARD_DELEGATES = {
    'lazy': KotlinPropertyDelegate('lazy', True, True, False),
    'observable': KotlinPropertyDelegate('observable', True, True, True),
    'vetoable': KotlinPropertyDelegate('vetoable', True, True, True),
    'notNull': KotlinPropertyDelegate('notNull', True, True, True),
    'lateinit': KotlinPropertyDelegate('lateinit', False, True, True),
}


# ==================== 扩展函数和属性 ====================

@dataclass
class KotlinExtensionFunction(KotlinFunctionInfo):
    """扩展函数信息"""
    receiver_type: str = ""  # 扩展接收者类型
    dispatch_receiver: Optional[str] = None  # 分发接收者（如果在类内）


@dataclass
class KotlinExtensionProperty:
    """扩展属性信息"""
    name: str
    receiver_type: str
    property_type: str
    is_val: bool
    line: int


# ==================== 其他 Kotlin 特性 ====================

@dataclass
class KotlinObjectDeclaration:
    """Object 声明（单例）"""
    name: str
    extends: Optional[str]
    implements: list[str]
    is_companion: bool
    line_start: int
    line_end: int


@dataclass
class KotlinEnumClassInfo(KotlinClassInfo):
    """枚举类信息"""
    entries: list[dict] = field(default_factory=list)  # [{name, params, line}]


@dataclass
class KotlinDataClassInfo(KotlinClassInfo):
    """数据类信息"""
    component_functions: list[str] = field(default_factory=list)  # component1, component2...
    copy_function_params: list[dict] = field(default_factory=list)


# ==================== 解析结果 ====================

@dataclass
class KotlinASTResult:
    """Kotlin AST 解析结果"""
    file_path: str
    success: bool
    error: Optional[str] = None
    parse_mode: str = "fast"  # fast, precise, auto

    # 基础结构信息
    package: Optional[str] = None
    imports: list[KotlinImportInfo] = field(default_factory=list)
    classes: list[KotlinClassInfo] = field(default_factory=list)
    functions: list[KotlinFunctionInfo] = field(default_factory=list)
    properties: list[KotlinPropertyInfo] = field(default_factory=list)

    # Kotlin 特有结构
    sealed_classes: list[KotlinSealedClassInfo] = field(default_factory=list)
    when_expressions: list[KotlinWhenExpression] = field(default_factory=list)
    coroutines: list[KotlinCoroutineInfo] = field(default_factory=list)
    flow_operators: list[KotlinFlowOperator] = field(default_factory=list)
    type_aliases: list[KotlinTypeAlias] = field(default_factory=list)
    value_classes: list[KotlinValueClass] = field(default_factory=list)
    delegated_properties: list[KotlinDelegatedProperty] = field(default_factory=list)
    extension_functions: list[KotlinExtensionFunction] = field(default_factory=list)
    extension_properties: list[KotlinExtensionProperty] = field(default_factory=list)
    object_declarations: list[KotlinObjectDeclaration] = field(default_factory=list)
    enum_classes: list[KotlinEnumClassInfo] = field(default_factory=list)
    data_classes: list[KotlinDataClassInfo] = field(default_factory=list)

    # 统计信息
    total_lines: int = 0

    def merge_from(self, other: 'KotlinASTResult'):
        """合并另一个解析结果（用于增量解析）"""
        self.imports.extend(other.imports)
        self.classes.extend(other.classes)
        self.functions.extend(other.functions)
        self.properties.extend(other.properties)
        self.sealed_classes.extend(other.sealed_classes)
        self.when_expressions.extend(other.when_expressions)
        self.coroutines.extend(other.coroutines)
        self.flow_operators.extend(other.flow_operators)
        self.type_aliases.extend(other.type_aliases)
        self.value_classes.extend(other.value_classes)
        self.delegated_properties.extend(other.delegated_properties)
        self.extension_functions.extend(other.extension_functions)
        self.extension_properties.extend(other.extension_properties)
        self.object_declarations.extend(other.object_declarations)
        self.enum_classes.extend(other.enum_classes)
        self.data_classes.extend(other.data_classes)
