"""Kotlin 解析器子模块

提供双模式解析能力：
- 快速模式：正则表达式解析，无外部依赖
- 精确模式：tree-sitter AST 解析，完整语法信息
"""

from .models import (
    # 基础类型
    KotlinFunctionInfo,
    KotlinPropertyInfo,
    KotlinClassInfo,
    KotlinImportInfo,
    KotlinASTResult,
    # 新增类型
    KotlinSealedClassInfo,
    KotlinWhenExpression,
    KotlinCoroutineInfo,
    KotlinFlowOperator,
    KotlinTypeAlias,
    KotlinValueClass,
    KotlinGenericType,
    KotlinDelegatedProperty,
    KotlinPropertyDelegate,
)

from .regex_parser import KotlinRegexParser
from .patterns import KOTLIN_PATTERNS

# 尝试导入 AST 解析器
try:
    from .ast_parser import KotlinTreeSitterParser
    AST_PARSER_AVAILABLE = True
except ImportError:
    KotlinTreeSitterParser = None
    AST_PARSER_AVAILABLE = False

__all__ = [
    # 基础类型
    "KotlinFunctionInfo",
    "KotlinPropertyInfo",
    "KotlinClassInfo",
    "KotlinImportInfo",
    "KotlinASTResult",
    # 新增类型
    "KotlinSealedClassInfo",
    "KotlinWhenExpression",
    "KotlinCoroutineInfo",
    "KotlinFlowOperator",
    "KotlinTypeAlias",
    "KotlinValueClass",
    "KotlinGenericType",
    "KotlinDelegatedProperty",
    "KotlinPropertyDelegate",
    # 解析器
    "KotlinRegexParser",
    "KotlinTreeSitterParser",
    "AST_PARSER_AVAILABLE",
    # 其他
    "KOTLIN_PATTERNS",
]
