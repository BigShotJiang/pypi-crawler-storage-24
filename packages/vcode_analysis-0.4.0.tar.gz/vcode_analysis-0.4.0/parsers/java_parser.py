"""Java AST 解析器

使用 javalang 库解析 Java 代码结构。
支持 Java 8+ 语法特性。
"""

from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path

try:
    import javalang
    JAVA_PARSER_AVAILABLE = True
except ImportError:
    JAVA_PARSER_AVAILABLE = False


@dataclass
class JavaMethodInfo:
    """Java 方法信息"""
    name: str
    line_start: int
    line_end: int
    return_type: str
    parameters: list[dict]  # {name, type}
    modifiers: list[str]  # public, private, static, etc.
    annotations: list[str]
    throws: list[str]
    is_constructor: bool = False


@dataclass
class JavaFieldInfo:
    """Java 字段信息"""
    name: str
    type: str
    modifiers: list[str]
    annotations: list[str]
    line: int


@dataclass
class JavaClassInfo:
    """Java 类信息"""
    name: str
    line_start: int
    line_end: int
    type_params: list[str]  # 泛型参数
    extends: Optional[str]
    implements: list[str]
    modifiers: list[str]
    annotations: list[str]
    methods: list[JavaMethodInfo]
    fields: list[JavaFieldInfo]
    inner_classes: list[str]
    is_interface: bool = False
    is_enum: bool = False
    is_annotation: bool = False


@dataclass
class JavaImportInfo:
    """Java 导入信息"""
    path: str
    is_static: bool
    is_wildcard: bool
    line: int


@dataclass
class JavaPackageInfo:
    """Java 包信息"""
    name: str
    line: int


@dataclass
class JavaASTResult:
    """Java AST 解析结果"""
    file_path: str
    success: bool
    error: Optional[str] = None

    # 结构信息
    package: Optional[JavaPackageInfo] = None
    imports: list[JavaImportInfo] = field(default_factory=list)
    classes: list[JavaClassInfo] = field(default_factory=list)
    interfaces: list[JavaClassInfo] = field(default_factory=list)
    enums: list[JavaClassInfo] = field(default_factory=list)

    # 统计信息
    total_lines: int = 0


class JavaASTParser:
    """Java AST 解析器"""

    def __init__(self):
        if not JAVA_PARSER_AVAILABLE:
            raise ImportError("请安装 javalang: pip install javalang")

    def parse_file(self, file_path: str) -> JavaASTResult:
        """解析 Java 文件"""
        path = Path(file_path)

        if not path.exists():
            return JavaASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix != ".java":
            return JavaASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 Java 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except Exception as e:
            return JavaASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> JavaASTResult:
        """解析 Java 代码字符串"""
        result = JavaASTResult(
            file_path=file_path,
            success=True,
            total_lines=len(code.splitlines())
        )

        try:
            tree = javalang.parse.parse(code)
        except Exception as e:
            return JavaASTResult(
                file_path=file_path,
                success=False,
                error=f"解析错误: {str(e)}"
            )

        try:
            # 解析包声明
            if tree.package:
                result.package = JavaPackageInfo(
                    name=tree.package.name,
                    line=1
                )

            # 解析导入语句
            for imp in tree.imports:
                result.imports.append(JavaImportInfo(
                    path=imp.path,
                    is_static=imp.static,
                    is_wildcard=imp.wildcard,
                    line=0
                ))

            # 解析类型声明（类、接口、枚举、注解）
            for type_decl in tree.types:
                self._parse_type_declaration(type_decl, result)

        except Exception as e:
            import traceback
            return JavaASTResult(
                file_path=file_path,
                success=False,
                error=f"{str(e)}\n{traceback.format_exc()}"
            )

        return result

        # 解析包声明
        if tree.package:
            result.package = JavaPackageInfo(
                name=tree.package.name,
                line=1  # javalang 不提供行号
            )

        # 解析导入语句
        for imp in tree.imports:
            result.imports.append(JavaImportInfo(
                path=imp.path,
                is_static=imp.static,
                is_wildcard=imp.wildcard,
                line=0  # javalang 不提供行号
            ))

        # 解析类型声明（类、接口、枚举、注解）
        for type_decl in tree.types:
            self._parse_type_declaration(type_decl, result)

        return result

    def _parse_type_declaration(self, type_decl, result: JavaASTResult):
        """解析类型声明"""
        # 判断类型
        is_interface = isinstance(type_decl, javalang.tree.InterfaceDeclaration)
        is_enum = isinstance(type_decl, javalang.tree.EnumDeclaration)
        is_annotation = isinstance(type_decl, javalang.tree.AnnotationDeclaration)

        # 获取修饰符
        modifiers = list(type_decl.modifiers) if type_decl.modifiers else []

        # 获取注解
        annotations = []
        if hasattr(type_decl, 'annotations') and type_decl.annotations:
            for ann in type_decl.annotations:
                annotations.append(ann.name)

        # 获取泛型参数
        type_params = []
        if hasattr(type_decl, 'type_parameters') and type_decl.type_parameters:
            type_params = [tp.name for tp in type_decl.type_parameters]

        # 获取继承和实现
        extends = None
        implements = []

        if hasattr(type_decl, 'extends') and type_decl.extends:
            if isinstance(type_decl.extends, list):
                extends = type_decl.extends[0].name if type_decl.extends else None
            else:
                extends = type_decl.extends.name

        if hasattr(type_decl, 'implements') and type_decl.implements:
            implements = [impl.name for impl in type_decl.implements]

        # 解析成员
        methods = []
        fields = []
        inner_classes = []

        if hasattr(type_decl, 'body') and type_decl.body:
            for member in type_decl.body:
                # 跳过非对象成员（如 enum body 中的 tuple）
                if not hasattr(member, '__class__'):
                    continue

                member_class = member.__class__.__name__

                if isinstance(member, javalang.tree.MethodDeclaration):
                    methods.append(self._parse_method(member))
                elif isinstance(member, javalang.tree.ConstructorDeclaration):
                    methods.append(self._parse_constructor(member))
                elif isinstance(member, javalang.tree.FieldDeclaration):
                    fields.extend(self._parse_field(member))
                elif isinstance(member, javalang.tree.ClassDeclaration):
                    inner_classes.append(member.name)
                elif isinstance(member, javalang.tree.InterfaceDeclaration):
                    inner_classes.append(member.name)
                elif isinstance(member, javalang.tree.EnumDeclaration):
                    inner_classes.append(member.name)
                elif isinstance(member, javalang.tree.EnumConstantDeclaration):
                    # 枚举常量
                    pass
                elif member_class == 'tuple':
                    # Enum body 中的 tuple，跳过
                    pass

        class_info = JavaClassInfo(
            name=type_decl.name,
            line_start=0,  # javalang 不提供精确行号
            line_end=0,
            type_params=type_params,
            extends=extends,
            implements=implements,
            modifiers=modifiers,
            annotations=annotations,
            methods=methods,
            fields=fields,
            inner_classes=inner_classes,
            is_interface=is_interface,
            is_enum=is_enum,
            is_annotation=is_annotation
        )

        if is_enum:
            result.enums.append(class_info)
        elif is_interface:
            result.interfaces.append(class_info)
        else:
            result.classes.append(class_info)

    def _parse_method(self, method_decl) -> JavaMethodInfo:
        """解析方法声明"""
        # 返回类型
        return_type = "void"
        if method_decl.return_type:
            return_type = self._get_type_name(method_decl.return_type)

        # 参数
        parameters = []
        if method_decl.parameters:
            for param in method_decl.parameters:
                param_type = self._get_type_name(param.type) if param.type else "unknown"
                parameters.append({
                    "name": param.name,
                    "type": param_type
                })

        # 异常
        throws = []
        if method_decl.throws:
            for exc in method_decl.throws:
                if isinstance(exc, str):
                    throws.append(exc)
                elif hasattr(exc, 'name'):
                    throws.append(exc.name)

        # 注解
        annotations = []
        if method_decl.annotations:
            annotations = [ann.name for ann in method_decl.annotations]

        return JavaMethodInfo(
            name=method_decl.name,
            line_start=0,
            line_end=0,
            return_type=return_type,
            parameters=parameters,
            modifiers=list(method_decl.modifiers) if method_decl.modifiers else [],
            annotations=annotations,
            throws=throws,
            is_constructor=False
        )

    def _parse_constructor(self, constructor_decl) -> JavaMethodInfo:
        """解析构造函数声明"""
        # 参数
        parameters = []
        if constructor_decl.parameters:
            for param in constructor_decl.parameters:
                param_type = self._get_type_name(param.type) if param.type else "unknown"
                parameters.append({
                    "name": param.name,
                    "type": param_type
                })

        # 异常
        throws = []
        if constructor_decl.throws:
            throws = [exc.name for exc in constructor_decl.throws]

        # 注解
        annotations = []
        if constructor_decl.annotations:
            annotations = [ann.name for ann in constructor_decl.annotations]

        return JavaMethodInfo(
            name=constructor_decl.name,
            line_start=0,
            line_end=0,
            return_type=constructor_decl.name,  # 构造函数返回类型为类名
            parameters=parameters,
            modifiers=list(constructor_decl.modifiers) if constructor_decl.modifiers else [],
            annotations=annotations,
            throws=throws,
            is_constructor=True
        )

    def _parse_field(self, field_decl) -> list[JavaFieldInfo]:
        """解析字段声明"""
        fields = []
        field_type = self._get_type_name(field_decl.type) if field_decl.type else "unknown"

        # 注解
        annotations = []
        if field_decl.annotations:
            annotations = [ann.name for ann in field_decl.annotations]

        # 一个字段声明可能包含多个变量
        for declarator in field_decl.declarators:
            fields.append(JavaFieldInfo(
                name=declarator.name,
                type=field_type,
                modifiers=list(field_decl.modifiers) if field_decl.modifiers else [],
                annotations=annotations,
                line=0
            ))

        return fields

    def _get_type_name(self, type_node) -> str:
        """获取类型名称"""
        if type_node is None:
            return "void"

        if isinstance(type_node, str):
            return type_node

        # 获取类名
        class_name = type_node.__class__.__name__

        # 处理 TypeArgument（泛型参数）
        if class_name == 'TypeArgument':
            if hasattr(type_node, 'type') and type_node.type:
                return self._get_type_name(type_node.type)
            return "?"

        if hasattr(type_node, 'name'):
            name = type_node.name
            # 处理泛型参数
            if hasattr(type_node, 'arguments') and type_node.arguments:
                args = ", ".join([self._get_type_name(arg) for arg in type_node.arguments])
                return f"{name}<{args}>"
            return name

        if hasattr(type_node, 'component_type'):
            # 数组类型
            return f"{self._get_type_name(type_node.component_type)}[]"

        return str(type_node)


def analyze_java_file(file_path: str) -> JavaASTResult:
    """分析 Java 文件的便捷函数"""
    parser = JavaASTParser()
    return parser.parse_file(file_path)


def analyze_java_code(code: str) -> JavaASTResult:
    """分析 Java 代码字符串的便捷函数"""
    parser = JavaASTParser()
    return parser.parse_code(code)
