"""JavaScript AST 解析器

使用 pyjsparser (esprima 的 Python 移植) 解析 JavaScript 代码结构。
支持 ES5 语法，ES6+ 语法使用正则表达式回退解析。
"""

from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path
import re

try:
    from pyjsparser import PyJsParser
    JS_PARSER_AVAILABLE = True
except ImportError:
    JS_PARSER_AVAILABLE = False


# ES6+ 语法的正则表达式模式（用于回退解析）
ES6_PATTERNS = {
    "import": r'import\s+(?:\{[^}]*\}|\w+)\s+from\s+[\'"]([^\'"]+)[\'"]',
    "import_default": r'import\s+(\w+)\s+from\s+[\'"]([^\'"]+)[\'"]',
    "import_all": r'import\s+\*\s+as\s+(\w+)\s+from\s+[\'"]([^\'"]+)[\'"]',
    "require": r'(?:const|let|var)\s+(\w+)\s*=\s*require\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)',
    "export_default": r'export\s+default\s+(\w+)',
    "export_named": r'export\s+\{([^}]+)\}',
    "class": r'class\s+(\w+)(?:\s+extends\s+(\w+))?\s*\{',
    "function": r'(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)',
    "arrow_function": r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>',
    "variable": r'(?:const|let|var)\s+(\w+)\s*=',
}


@dataclass
class JSFunctionInfo:
    """JavaScript 函数信息"""
    name: str
    line_start: int
    line_end: int
    params: list[str]
    is_async: bool
    is_generator: bool
    is_arrow: bool  # 箭头函数
    is_method: bool = False


@dataclass
class JSClassInfo:
    """JavaScript 类信息"""
    name: str
    line_start: int
    line_end: int
    methods: list[JSFunctionInfo]
    properties: list[str]
    extends: Optional[str] = None


@dataclass
class JSImportInfo:
    """JavaScript 导入信息"""
    source: str  # 模块路径
    specifiers: list[str]  # 导入的标识符
    line: int
    import_type: str  # import, require, dynamic


@dataclass
class JSExportInfo:
    """JavaScript 导出信息"""
    name: str
    line: int
    export_type: str  # default, named


@dataclass
class JSVariableInfo:
    """JavaScript 变量信息"""
    name: str
    line: int
    kind: str  # var, let, const
    is_destructured: bool = False


@dataclass
class JavaScriptASTResult:
    """JavaScript AST 解析结果"""
    file_path: str
    success: bool
    error: Optional[str] = None

    # 结构信息
    imports: list[JSImportInfo] = field(default_factory=list)
    exports: list[JSExportInfo] = field(default_factory=list)
    classes: list[JSClassInfo] = field(default_factory=list)
    functions: list[JSFunctionInfo] = field(default_factory=list)
    variables: list[JSVariableInfo] = field(default_factory=list)

    # 统计信息
    total_lines: int = 0


class JavaScriptASTParser:
    """JavaScript AST 解析器"""

    def __init__(self):
        if not JS_PARSER_AVAILABLE:
            raise ImportError("请安装 pyjsparser: pip install pyjsparser")

    def parse_file(self, file_path: str) -> JavaScriptASTResult:
        """解析 JavaScript 文件"""
        path = Path(file_path)

        if not path.exists():
            return JavaScriptASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".js", ".jsx", ".mjs", ".cjs"):
            return JavaScriptASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 JavaScript 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except Exception as e:
            return JavaScriptASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> JavaScriptASTResult:
        """解析 JavaScript 代码字符串"""
        result = JavaScriptASTResult(
            file_path=file_path,
            success=True,
            total_lines=len(code.splitlines())
        )

        # 检测是否包含 ES6+ 语法
        has_es6 = self._detect_es6_syntax(code)

        if has_es6:
            # ES6+ 语法，使用正则表达式回退解析
            self._parse_with_regex(code, result)
        else:
            # ES5 语法，使用 AST 解析器
            try:
                parser = PyJsParser()
                tree = parser.parse(code)
                self._traverse(tree, result)
            except Exception:
                # AST 解析失败，回退到正则表达式
                self._parse_with_regex(code, result)

        return result

    def _detect_es6_syntax(self, code: str) -> bool:
        """检测是否包含 ES6+ 语法"""
        es6_indicators = [
            r'\bimport\s+',           # import 语句
            r'\bexport\s+',           # export 语句
            r'\bclass\s+\w+',         # class 声明
            r'=>',                     # 箭头函数
            r'`[^`]*\$\{',            # 模板字符串
            r'\blet\s+',              # let 声明
            r'\bconst\s+',            # const 声明
            r'\basync\s+',            # async 关键字
            r'\bawait\s+',            # await 关键字
        ]

        for pattern in es6_indicators:
            if re.search(pattern, code):
                return True
        return False

    def _parse_with_regex(self, code: str, result: JavaScriptASTResult):
        """使用正则表达式解析（ES6+ 回退方案）"""
        lines = code.split('\n')

        # 解析 import 语句
        for match in re.finditer(ES6_PATTERNS["import_all"], code):
            result.imports.append(JSImportInfo(
                source=match.group(2),
                specifiers=[f"* as {match.group(1)}"],
                line=code[:match.start()].count('\n') + 1,
                import_type="import"
            ))

        for match in re.finditer(ES6_PATTERNS["import_default"], code):
            if '* as' not in match.group(0):
                result.imports.append(JSImportInfo(
                    source=match.group(2),
                    specifiers=[match.group(1)],
                    line=code[:match.start()].count('\n') + 1,
                    import_type="import"
                ))

        for match in re.finditer(ES6_PATTERNS["import"], code):
            if 'import *' not in match.group(0):
                result.imports.append(JSImportInfo(
                    source=match.group(1),
                    specifiers=[],
                    line=code[:match.start()].count('\n') + 1,
                    import_type="import"
                ))

        # 解析 require 语句
        for match in re.finditer(ES6_PATTERNS["require"], code):
            result.imports.append(JSImportInfo(
                source=match.group(2),
                specifiers=[match.group(1)],
                line=code[:match.start()].count('\n') + 1,
                import_type="require"
            ))

        # 解析 class 声明
        for match in re.finditer(ES6_PATTERNS["class"], code):
            class_name = match.group(1)
            extends = match.group(2) if match.lastindex >= 2 else None
            line = code[:match.start()].count('\n') + 1

            result.classes.append(JSClassInfo(
                name=class_name,
                line_start=line,
                line_end=line,  # 简化处理
                methods=[],
                properties=[],
                extends=extends
            ))

        # 解析 function 声明
        for match in re.finditer(ES6_PATTERNS["function"], code):
            full_match = match.group(0)
            is_async = 'async' in full_match
            # 只取函数名和参数
            groups = match.groups()
            if groups:
                func_name = groups[0] if groups[0] else "anonymous"
                params = groups[1] if len(groups) > 1 and groups[1] else ""
            else:
                continue

            line = code[:match.start()].count('\n') + 1

            result.functions.append(JSFunctionInfo(
                name=func_name,
                line_start=line,
                line_end=line,
                params=[p.strip() for p in params.split(',') if p.strip()],
                is_async=is_async,
                is_generator=False,
                is_arrow=False,
                is_method=False
            ))

        # 解析箭头函数
        for match in re.finditer(ES6_PATTERNS["arrow_function"], code):
            line = code[:match.start()].count('\n') + 1
            result.functions.append(JSFunctionInfo(
                name=match.group(1),
                line_start=line,
                line_end=line,
                params=[],
                is_async='async' in match.group(0),
                is_generator=False,
                is_arrow=True,
                is_method=False
            ))

        # 解析 export 语句
        for match in re.finditer(ES6_PATTERNS["export_default"], code):
            line = code[:match.start()].count('\n') + 1
            result.exports.append(JSExportInfo(
                name=match.group(1),
                line=line,
                export_type="default"
            ))

        for match in re.finditer(ES6_PATTERNS["export_named"], code):
            line = code[:match.start()].count('\n') + 1
            names = [n.strip() for n in match.group(1).split(',')]
            for name in names:
                result.exports.append(JSExportInfo(
                    name=name,
                    line=line,
                    export_type="named"
                ))

        # 解析变量声明
        for match in re.finditer(ES6_PATTERNS["variable"], code):
            line = code[:match.start()].count('\n') + 1
            kind = 'const' if 'const' in match.group(0) else ('let' if 'let' in match.group(0) else 'var')
            result.variables.append(JSVariableInfo(
                name=match.group(1),
                line=line,
                kind=kind,
                is_destructured=False
            ))

    def _traverse(self, node: dict, result: JavaScriptASTResult, in_class: bool = False):
        """遍历 AST 节点"""
        if not isinstance(node, dict):
            return

        node_type = node.get("type")

        # 处理不同类型的节点
        if node_type == "FunctionDeclaration":
            func = self._parse_function(node, is_method=False)
            if func:
                result.functions.append(func)

        elif node_type == "ClassDeclaration":
            cls = self._parse_class(node)
            if cls:
                result.classes.append(cls)

        elif node_type == "VariableDeclaration":
            for decl in node.get("declarations", []):
                var = self._parse_variable(decl, node.get("kind", "var"))
                if var:
                    result.variables.append(var)

        elif node_type == "ImportDeclaration":
            imp = self._parse_import(node)
            if imp:
                result.imports.append(imp)

        elif node_type == "ExportDefaultDeclaration":
            exp = self._parse_export(node, "default")
            if exp:
                result.exports.append(exp)

        elif node_type == "ExportNamedDeclaration":
            for spec in node.get("specifiers", []):
                exp = self._parse_export(spec, "named")
                if exp:
                    result.exports.append(exp)

        elif node_type == "CallExpression":
            # 检测 require() 调用
            callee = node.get("callee", {})
            if callee.get("name") == "require":
                args = node.get("arguments", [])
                if args and args[0].get("type") == "Literal":
                    imp = JSImportInfo(
                        source=args[0].get("value", ""),
                        specifiers=[],
                        line=node.get("loc", {}).get("start", {}).get("line", 0),
                        import_type="require"
                    )
                    result.imports.append(imp)

        # 递归遍历子节点
        for key, value in node.items():
            if key in ("loc", "range", "start", "end"):
                continue
            if isinstance(value, dict):
                self._traverse(value, result, in_class)
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        self._traverse(item, result, in_class)

    def _parse_function(self, node: dict, is_method: bool = False) -> Optional[JSFunctionInfo]:
        """解析函数声明"""
        name = None
        if node.get("id"):
            name = node["id"].get("name")
        elif is_method:
            # 方法的名称在 key 中
            key = node.get("key", {})
            name = key.get("name") if isinstance(key, dict) else None

        if not name:
            return None

        params = []
        for param in node.get("params", []):
            if param.get("type") == "Identifier":
                params.append(param.get("name"))
            elif param.get("type") == "AssignmentPattern":
                # 默认参数
                left = param.get("left", {})
                if left.get("type") == "Identifier":
                    params.append(left.get("name"))
            elif param.get("type") == "RestElement":
                # 剩余参数
                arg = param.get("argument", {})
                if arg.get("type") == "Identifier":
                    params.append(f"...{arg.get('name')}")

        loc = node.get("loc", {})
        start_line = loc.get("start", {}).get("line", 0)
        end_line = loc.get("end", {}).get("line", start_line)

        return JSFunctionInfo(
            name=name,
            line_start=start_line,
            line_end=end_line,
            params=params,
            is_async=node.get("async", False),
            is_generator=node.get("generator", False),
            is_arrow=node.get("type") == "ArrowFunctionExpression",
            is_method=is_method
        )

    def _parse_class(self, node: dict) -> Optional[JSClassInfo]:
        """解析类声明"""
        if not node.get("id"):
            return None

        name = node["id"].get("name")
        loc = node.get("loc", {})
        start_line = loc.get("start", {}).get("line", 0)
        end_line = loc.get("end", {}).get("line", start_line)

        # 获取继承的类
        extends = None
        if node.get("superClass"):
            super_class = node["superClass"]
            if super_class.get("type") == "Identifier":
                extends = super_class.get("name")

        # 解析方法
        methods = []
        properties = []

        body = node.get("body", {})
        for item in body.get("body", []):
            if item.get("type") == "MethodDefinition":
                func = self._parse_method(item)
                if func:
                    methods.append(func)
            elif item.get("type") == "ClassProperty":
                key = item.get("key", {})
                if key.get("type") == "Identifier":
                    properties.append(key.get("name"))

        return JSClassInfo(
            name=name,
            line_start=start_line,
            line_end=end_line,
            methods=methods,
            properties=properties,
            extends=extends
        )

    def _parse_method(self, node: dict) -> Optional[JSFunctionInfo]:
        """解析类方法"""
        key = node.get("key", {})
        name = key.get("name") if isinstance(key, dict) else None

        if not name:
            return None

        value = node.get("value", {})
        params = []
        for param in value.get("params", []):
            if param.get("type") == "Identifier":
                params.append(param.get("name"))

        loc = node.get("loc", {})
        start_line = loc.get("start", {}).get("line", 0)
        end_line = loc.get("end", {}).get("line", start_line)

        return JSFunctionInfo(
            name=name,
            line_start=start_line,
            line_end=end_line,
            params=params,
            is_async=value.get("async", False),
            is_generator=value.get("generator", False),
            is_arrow=False,
            is_method=True
        )

    def _parse_variable(self, node: dict, kind: str) -> Optional[JSVariableInfo]:
        """解析变量声明"""
        if node.get("id", {}).get("type") == "Identifier":
            name = node["id"].get("name")
            loc = node.get("loc", {})
            line = loc.get("start", {}).get("line", 0)

            return JSVariableInfo(
                name=name,
                line=line,
                kind=kind,
                is_destructured=False
            )
        elif node.get("id", {}).get("type") in ("ObjectPattern", "ArrayPattern"):
            # 解构赋值
            loc = node.get("loc", {})
            line = loc.get("start", {}).get("line", 0)
            return JSVariableInfo(
                name="<destructured>",
                line=line,
                kind=kind,
                is_destructured=True
            )
        return None

    def _parse_import(self, node: dict) -> Optional[JSImportInfo]:
        """解析 import 声明"""
        source = node.get("source", {})
        source_path = source.get("value", "") if source.get("type") == "Literal" else ""

        specifiers = []
        for spec in node.get("specifiers", []):
            if spec.get("type") == "ImportDefaultSpecifier":
                local = spec.get("local", {})
                if local.get("type") == "Identifier":
                    specifiers.append(local.get("name"))
            elif spec.get("type") == "ImportSpecifier":
                local = spec.get("local", {})
                if local.get("type") == "Identifier":
                    specifiers.append(local.get("name"))
            elif spec.get("type") == "ImportNamespaceSpecifier":
                local = spec.get("local", {})
                if local.get("type") == "Identifier":
                    specifiers.append(f"* as {local.get('name')}")

        loc = node.get("loc", {})
        line = loc.get("start", {}).get("line", 0)

        return JSImportInfo(
            source=source_path,
            specifiers=specifiers,
            line=line,
            import_type="import"
        )

    def _parse_export(self, node: dict, export_type: str) -> Optional[JSExportInfo]:
        """解析 export 声明"""
        name = None

        if export_type == "default":
            decl = node.get("declaration", {})
            if decl.get("type") == "Identifier":
                name = decl.get("name")
            elif decl.get("type") == "FunctionDeclaration":
                if decl.get("id"):
                    name = decl["id"].get("name")
                else:
                    name = "<anonymous>"
            elif decl.get("type") == "ClassDeclaration":
                if decl.get("id"):
                    name = decl["id"].get("name")
                else:
                    name = "<anonymous>"
            else:
                name = "<default>"
        else:
            # named export
            local = node.get("local", {})
            if local.get("type") == "Identifier":
                name = local.get("name")

        if not name:
            return None

        loc = node.get("loc", {})
        line = loc.get("start", {}).get("line", 0)

        return JSExportInfo(
            name=name,
            line=line,
            export_type=export_type
        )


def analyze_javascript_file(file_path: str) -> JavaScriptASTResult:
    """分析 JavaScript 文件的便捷函数"""
    parser = JavaScriptASTParser()
    return parser.parse_file(file_path)


def analyze_javascript_code(code: str) -> JavaScriptASTResult:
    """分析 JavaScript 代码字符串的便捷函数"""
    parser = JavaScriptASTParser()
    return parser.parse_code(code)
