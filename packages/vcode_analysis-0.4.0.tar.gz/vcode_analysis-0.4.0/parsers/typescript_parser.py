"""TypeScript AST 解析器

解析 TypeScript 代码结构，支持：
- interface、type、enum 声明
- 泛型参数
- 类型注解
- 装饰器
- ES6+ 语法（复用 JavaScript 解析器）

使用正则表达式 + 简化的类型剥离来解析。
"""

from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path
import re

try:
    from .javascript_parser import (
        JavaScriptASTParser,
        JSFunctionInfo,
        JSClassInfo,
        JSImportInfo,
        JSExportInfo,
        JSVariableInfo,
    )
    JS_PARSER_AVAILABLE = True
except ImportError:
    JS_PARSER_AVAILABLE = False


@dataclass
class TSInterfaceInfo:
    """TypeScript 接口信息"""
    name: str
    line_start: int
    line_end: int
    extends: list[str]
    properties: list[dict]  # {name, type, optional}
    methods: list[dict]  # {name, params, return_type, optional}


@dataclass
class TSTypeAliasInfo:
    """TypeScript 类型别名信息"""
    name: str
    line: int
    type_params: list[str]  # 泛型参数
    definition: str  # 类型定义


@dataclass
class TSEnumInfo:
    """TypeScript 枚举信息"""
    name: str
    line: int
    members: list[str]
    is_const: bool


@dataclass
class TSFunctionInfo(JSFunctionInfo):
    """TypeScript 函数信息（扩展 JSFunctionInfo）"""
    return_type: Optional[str] = None
    type_params: list[str] = field(default_factory=list)  # 泛型参数


@dataclass
class TSClassInfo(JSClassInfo):
    """TypeScript 类信息（扩展 JSClassInfo）"""
    implements: list[str] = field(default_factory=list)
    type_params: list[str] = field(default_factory=list)
    decorators: list[str] = field(default_factory=list)


@dataclass
class TypeScriptASTResult:
    """TypeScript AST 解析结果"""
    file_path: str
    success: bool
    error: Optional[str] = None

    # 结构信息
    imports: list[JSImportInfo] = field(default_factory=list)
    exports: list[JSExportInfo] = field(default_factory=list)
    classes: list[TSClassInfo] = field(default_factory=list)
    interfaces: list[TSInterfaceInfo] = field(default_factory=list)
    types: list[TSTypeAliasInfo] = field(default_factory=list)
    enums: list[TSEnumInfo] = field(default_factory=list)
    functions: list[TSFunctionInfo] = field(default_factory=list)
    variables: list[JSVariableInfo] = field(default_factory=list)

    # 统计信息
    total_lines: int = 0


# TypeScript 特有的正则表达式模式
TS_PATTERNS = {
    # 接口定义
    "interface": r'interface\s+(\w+)(?:<([^>]+)>)?(?:\s+extends\s+([^{]+))?\s*\{',
    # 类型别名
    "type_alias": r'type\s+(\w+)(?:<([^>]+)>)?\s*=\s*([^;]+);',
    # 枚举
    "enum": r'(?:const\s+)?enum\s+(\w+)\s*\{([^}]+)\}',
    # 类（带泛型和 implements）
    "class_ts": r'(?:(@\w+(?:\([^)]*\)|))?\s*)*class\s+(\w+)(?:<([^>]+)>)?(?:\s+extends\s+(\w+))?(?:\s+implements\s+([^{]+))?\s*\{',
    # 函数（带类型注解）
    "function_ts": r'(?:export\s+)?(?:async\s+)?function\s+(\w+)(?:<([^>]+)>)?\s*\(([^)]*)\)(?:\s*:\s*([^{=]+))?',
    # 箭头函数（带类型）
    "arrow_ts": r'(?:const|let|var)\s+(\w+)\s*(?::\s*[^=]+)?\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>',
    # 属性（接口中）
    "property": r'(\w+)(\?)?(?::\s*([^;,\n]+))?',
    # 方法（接口中）
    "method": r'(\w+)(\?)?\s*\(([^)]*)\)(?:\s*:\s*([^;,\n]+))?',
    # 泛型参数
    "type_params": r'<([^>]+)>',
    # 装饰器
    "decorator": r'@(\w+)(?:\([^)]*\))?',
}


class TypeScriptASTParser:
    """TypeScript AST 解析器"""

    def __init__(self):
        pass

    def parse_file(self, file_path: str) -> TypeScriptASTResult:
        """解析 TypeScript 文件"""
        path = Path(file_path)

        if not path.exists():
            return TypeScriptASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".ts", ".tsx", ".mts", ".cts"):
            return TypeScriptASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 TypeScript 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except Exception as e:
            return TypeScriptASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> TypeScriptASTResult:
        """解析 TypeScript 代码字符串"""
        result = TypeScriptASTResult(
            file_path=file_path,
            success=True,
            total_lines=len(code.splitlines())
        )

        try:
            # 解析 TypeScript 特有结构
            self._parse_interfaces(code, result)
            self._parse_type_aliases(code, result)
            self._parse_enums(code, result)
            self._parse_ts_classes(code, result)
            self._parse_ts_functions(code, result)

            # 复用 JavaScript 解析器处理 import/export/变量
            if JS_PARSER_AVAILABLE:
                js_parser = JavaScriptASTParser()
                js_result = js_parser.parse_code(self._strip_types(code), file_path)
                if js_result.success:
                    result.imports = js_result.imports
                    result.exports = js_result.exports
                    result.variables = js_result.variables

        except Exception as e:
            result.error = str(e)

        return result

    def _strip_types(self, code: str) -> str:
        """移除类型注解，转换为近似 JavaScript 代码"""
        # 移除类型注解 : Type
        stripped = re.sub(r':\s*[A-Za-z_][\w.<>\[\]|&\s]*(?=,|\)|=|;|\n)', '', code)
        # 移除泛型参数 <T>
        stripped = re.sub(r'<[^>]+>', '', stripped)
        # 移除 as Type 断言
        stripped = re.sub(r'\s+as\s+[A-Za-z_][\w.<>\[\]|&\s]*', '', stripped)
        # 移除 interface 声明
        stripped = re.sub(r'interface\s+\w+(?:<[^>]+>)?(?:\s+extends\s+[^{]+)?\s*\{[^}]*\}', '', stripped)
        # 移除 type 声明
        stripped = re.sub(r'type\s+\w+(?:<[^>]+>)?\s*=\s*[^;]+;', '', stripped)
        # 移除 enum 声明
        stripped = re.sub(r'(?:const\s+)?enum\s+\w+\s*\{[^}]*\}', '', stripped)

        return stripped

    def _parse_interfaces(self, code: str, result: TypeScriptASTResult):
        """解析接口定义"""
        for match in re.finditer(TS_PATTERNS["interface"], code):
            name = match.group(1)
            type_params = match.group(2).split(',') if match.group(2) else []
            extends = [e.strip() for e in match.group(3).split(',')] if match.group(3) else []
            line = code[:match.start()].count('\n') + 1

            # 找到接口体的结束位置
            body_start = match.end() - 1
            brace_count = 1
            body_end = body_start + 1
            while body_end < len(code) and brace_count > 0:
                if code[body_end] == '{':
                    brace_count += 1
                elif code[body_end] == '}':
                    brace_count -= 1
                body_end += 1

            body = code[body_start:body_end]
            properties, methods = self._parse_interface_members(body)

            result.interfaces.append(TSInterfaceInfo(
                name=name,
                line_start=line,
                line_end=code[:body_end].count('\n') + 1,
                extends=extends,
                properties=properties,
                methods=methods
            ))

    def _parse_interface_members(self, body: str) -> tuple[list[dict], list[dict]]:
        """解析接口成员"""
        properties = []
        methods = []

        for line in body.split('\n'):
            line = line.strip().rstrip(';').rstrip(',')
            if not line or line.startswith('//') or line.startswith('/*'):
                continue

            # 检查是否是方法（包含括号）
            if '(' in line:
                match = re.match(TS_PATTERNS["method"], line)
                if match:
                    methods.append({
                        "name": match.group(1),
                        "optional": bool(match.group(2)),
                        "params": match.group(3),
                        "return_type": match.group(4).strip() if match.group(4) else None
                    })
            else:
                match = re.match(TS_PATTERNS["property"], line)
                if match:
                    properties.append({
                        "name": match.group(1),
                        "optional": bool(match.group(2)),
                        "type": match.group(3).strip() if match.group(3) else None
                    })

        return properties, methods

    def _parse_type_aliases(self, code: str, result: TypeScriptASTResult):
        """解析类型别名"""
        for match in re.finditer(TS_PATTERNS["type_alias"], code):
            name = match.group(1)
            type_params = [p.strip() for p in match.group(2).split(',')] if match.group(2) else []
            definition = match.group(3).strip()
            line = code[:match.start()].count('\n') + 1

            result.types.append(TSTypeAliasInfo(
                name=name,
                line=line,
                type_params=type_params,
                definition=definition
            ))

    def _parse_enums(self, code: str, result: TypeScriptASTResult):
        """解析枚举"""
        for match in re.finditer(TS_PATTERNS["enum"], code):
            name = match.group(1)
            members_str = match.group(2)
            is_const = 'const enum' in match.group(0)
            line = code[:match.start()].count('\n') + 1

            members = []
            for member in members_str.split(','):
                member = member.strip()
                if member:
                    # 移除值部分
                    member_name = member.split('=')[0].strip()
                    members.append(member_name)

            result.enums.append(TSEnumInfo(
                name=name,
                line=line,
                members=members,
                is_const=is_const
            ))

    def _parse_ts_classes(self, code: str, result: TypeScriptASTResult):
        """解析 TypeScript 类"""
        for match in re.finditer(TS_PATTERNS["class_ts"], code, re.MULTILINE):
            # 提取装饰器
            full_match = match.group(0)
            decorators = re.findall(TS_PATTERNS["decorator"], full_match)

            name = match.group(2)
            type_params = [p.strip() for p in match.group(3).split(',')] if match.group(3) else []
            extends = match.group(4)
            implements = [i.strip() for i in match.group(5).split(',')] if match.group(5) else []
            line = code[:match.start()].count('\n') + 1

            result.classes.append(TSClassInfo(
                name=name,
                line_start=line,
                line_end=line,
                methods=[],
                properties=[],
                extends=extends,
                implements=implements,
                type_params=type_params,
                decorators=decorators
            ))

    def _parse_ts_functions(self, code: str, result: TypeScriptASTResult):
        """解析 TypeScript 函数"""
        for match in re.finditer(TS_PATTERNS["function_ts"], code):
            name = match.group(1)
            type_params = [p.strip() for p in match.group(2).split(',')] if match.group(2) else []
            params_str = match.group(3)
            return_type = match.group(4).strip() if match.group(4) else None
            line = code[:match.start()].count('\n') + 1

            # 解析参数
            params = self._parse_params(params_str)

            is_async = 'async' in match.group(0)

            result.functions.append(TSFunctionInfo(
                name=name,
                line_start=line,
                line_end=line,
                params=params,
                is_async=is_async,
                is_generator=False,
                is_arrow=False,
                return_type=return_type,
                type_params=type_params
            ))

    def _parse_params(self, params_str: str) -> list[str]:
        """解析函数参数"""
        params = []
        for param in params_str.split(','):
            param = param.strip()
            if not param:
                continue
            # 移除类型注解
            param = re.sub(r':\s*[^,=]+', '', param)
            # 移除默认值
            param = param.split('=')[0].strip()
            # 移除 ? 可选标记
            param = param.rstrip('?').strip()
            if param:
                params.append(param)
        return params


def analyze_typescript_file(file_path: str) -> TypeScriptASTResult:
    """分析 TypeScript 文件的便捷函数"""
    parser = TypeScriptASTParser()
    return parser.parse_file(file_path)


def analyze_typescript_code(code: str) -> TypeScriptASTResult:
    """分析 TypeScript 代码字符串的便捷函数"""
    parser = TypeScriptASTParser()
    return parser.parse_code(code)
