"""Python AST 解析器

使用 Python 内置 ast 模块解析代码结构，提供比正则表达式更精确的分析能力。
"""

import ast
from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path


@dataclass
class FunctionInfo:
    """函数信息"""
    name: str
    line_start: int
    line_end: int
    args: list[str]
    returns: Optional[str]
    docstring: Optional[str]
    decorators: list[str]
    is_async: bool
    is_method: bool = False


@dataclass
class ClassInfo:
    """类信息"""
    name: str
    line_start: int
    line_end: int
    docstring: Optional[str]
    decorators: list[str]
    bases: list[str]
    methods: list[FunctionInfo]
    attributes: list[str]


@dataclass
class ImportInfo:
    """导入信息"""
    module: str
    names: list[str]  # 导入的名称列表
    aliases: dict[str, str]  # 名称 -> 别名
    line: int
    is_from: bool  # from ... import vs import


@dataclass
class VariableInfo:
    """变量信息"""
    name: str
    line: int
    value_type: Optional[str]  # 推断的类型
    is_constant: bool  # 是否为常量（大写命名）


@dataclass
class PythonASTResult:
    """Python AST 解析结果"""
    file_path: str
    success: bool
    error: Optional[str] = None

    # 结构信息
    imports: list[ImportInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    functions: list[FunctionInfo] = field(default_factory=list)
    variables: list[VariableInfo] = field(default_factory=list)

    # 统计信息
    total_lines: int = 0
    docstring_coverage: float = 0.0
    type_hint_coverage: float = 0.0

    # 模块级信息
    module_docstring: Optional[str] = None


class PythonASTParser:
    """Python AST 解析器"""

    def __init__(self):
        pass

    def parse_file(self, file_path: str) -> PythonASTResult:
        """解析 Python 文件"""
        path = Path(file_path)

        if not path.exists():
            return PythonASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix != ".py":
            return PythonASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 Python 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except Exception as e:
            return PythonASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> PythonASTResult:
        """解析 Python 代码字符串"""
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return PythonASTResult(
                file_path=file_path,
                success=False,
                error=f"语法错误: {e.msg} (行 {e.lineno})"
            )

        result = PythonASTResult(
            file_path=file_path,
            success=True,
            total_lines=len(code.splitlines())
        )

        # 获取模块级 docstring
        result.module_docstring = ast.get_docstring(tree)

        # 遍历 AST
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                result.imports.append(self._parse_import(node))
            elif isinstance(node, ast.ImportFrom):
                result.imports.append(self._parse_import_from(node))
            elif isinstance(node, ast.ClassDef):
                result.classes.append(self._parse_class(node))
            elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                # 只收集顶层函数（不在类中的）
                if not self._is_method(tree, node):
                    result.functions.append(self._parse_function(node))
            elif isinstance(node, ast.Assign):
                # 收集顶层变量赋值
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        result.variables.append(self._parse_variable(target, node))

        # 计算统计信息
        result.docstring_coverage = self._calculate_docstring_coverage(result)
        result.type_hint_coverage = self._calculate_type_hint_coverage(result)

        return result

    def _parse_import(self, node: ast.Import) -> ImportInfo:
        """解析 import 语句"""
        names = []
        aliases = {}

        for alias in node.names:
            names.append(alias.name)
            if alias.asname:
                aliases[alias.name] = alias.asname

        return ImportInfo(
            module="",
            names=names,
            aliases=aliases,
            line=node.lineno,
            is_from=False
        )

    def _parse_import_from(self, node: ast.ImportFrom) -> ImportInfo:
        """解析 from ... import 语句"""
        names = []
        aliases = {}

        for alias in node.names:
            names.append(alias.name)
            if alias.asname:
                aliases[alias.name] = alias.asname

        return ImportInfo(
            module=node.module or "",
            names=names,
            aliases=aliases,
            line=node.lineno,
            is_from=True
        )

    def _parse_class(self, node: ast.ClassDef) -> ClassInfo:
        """解析类定义"""
        methods = []
        attributes = []

        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func = self._parse_function(item, is_method=True)
                methods.append(func)
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        attributes.append(target.id)

        bases = []
        for base in node.bases:
            if isinstance(base, ast.Name):
                bases.append(base.id)
            elif isinstance(base, ast.Attribute):
                bases.append(self._get_attribute_name(base))

        return ClassInfo(
            name=node.name,
            line_start=node.lineno,
            line_end=node.end_lineno or node.lineno,
            docstring=ast.get_docstring(node),
            decorators=[d.attr if isinstance(d, ast.Attribute) else d.id
                       for d in node.decorator_list
                       if isinstance(d, (ast.Name, ast.Attribute))],
            bases=bases,
            methods=methods,
            attributes=attributes
        )

    def _parse_function(self, node, is_method: bool = False) -> FunctionInfo:
        """解析函数定义"""
        args = []

        # 处理参数
        for arg in node.args.args:
            args.append(arg.arg)

        if node.args.vararg:
            args.append(f"*{node.args.vararg.arg}")
        if node.args.kwarg:
            args.append(f"**{node.args.kwarg.arg}")

        # 获取返回类型
        returns = None
        if node.returns:
            returns = self._get_annotation_string(node.returns)

        # 获取装饰器
        decorators = []
        for d in node.decorator_list:
            if isinstance(d, ast.Name):
                decorators.append(d.id)
            elif isinstance(d, ast.Attribute):
                decorators.append(self._get_attribute_name(d))
            elif isinstance(d, ast.Call):
                if isinstance(d.func, ast.Name):
                    decorators.append(d.func.id)
                elif isinstance(d.func, ast.Attribute):
                    decorators.append(self._get_attribute_name(d.func))

        return FunctionInfo(
            name=node.name,
            line_start=node.lineno,
            line_end=node.end_lineno or node.lineno,
            args=args,
            returns=returns,
            docstring=ast.get_docstring(node),
            decorators=decorators,
            is_async=isinstance(node, ast.AsyncFunctionDef),
            is_method=is_method
        )

    def _parse_variable(self, target: ast.Name, node: ast.Assign) -> VariableInfo:
        """解析变量赋值"""
        value_type = self._infer_type(node.value)

        return VariableInfo(
            name=target.id,
            line=node.lineno,
            value_type=value_type,
            is_constant=target.id.isupper() or target.id.startswith("_") and target.id[1:].isupper()
        )

    def _is_method(self, tree: ast.Module, node) -> bool:
        """检查函数是否是类方法"""
        for parent in ast.walk(tree):
            if isinstance(parent, ast.ClassDef):
                for child in parent.body:
                    if child is node:
                        return True
        return False

    def _get_annotation_string(self, node) -> str:
        """获取类型注解字符串"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Constant):
            return repr(node.value)
        elif isinstance(node, ast.Subscript):
            value = self._get_annotation_string(node.value)
            slice_str = self._get_annotation_string(node.slice)
            return f"{value}[{slice_str}]"
        elif isinstance(node, ast.Attribute):
            return self._get_attribute_name(node)
        elif isinstance(node, ast.Tuple):
            elements = [self._get_annotation_string(e) for e in node.elts]
            return ", ".join(elements)
        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
            # Python 3.10+ union syntax: X | Y
            left = self._get_annotation_string(node.left)
            right = self._get_annotation_string(node.right)
            return f"{left} | {right}"
        return "Any"

    def _get_attribute_name(self, node: ast.Attribute) -> str:
        """获取属性访问的完整名称"""
        parts = []
        current = node
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        return ".".join(reversed(parts))

    def _infer_type(self, node) -> Optional[str]:
        """推断表达式的类型"""
        if isinstance(node, ast.Constant):
            type_map = {
                str: "str",
                int: "int",
                float: "float",
                bool: "bool",
                type(None): "None",
            }
            return type_map.get(type(node.value), "Any")
        elif isinstance(node, ast.List):
            return "list"
        elif isinstance(node, ast.Dict):
            return "dict"
        elif isinstance(node, ast.Set):
            return "set"
        elif isinstance(node, ast.Tuple):
            return "tuple"
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                return node.func.id
            elif isinstance(node.func, ast.Attribute):
                return self._get_attribute_name(node.func)
        elif isinstance(node, ast.ListComp):
            return "list"
        elif isinstance(node, ast.DictComp):
            return "dict"
        elif isinstance(node, ast.SetComp):
            return "set"
        elif isinstance(node, ast.GeneratorExp):
            return "generator"
        return None

    def _calculate_docstring_coverage(self, result: PythonASTResult) -> float:
        """计算文档字符串覆盖率"""
        total = 0
        documented = 0

        # 模块文档
        total += 1
        if result.module_docstring:
            documented += 1

        # 类文档
        for cls in result.classes:
            total += 1
            if cls.docstring:
                documented += 1
            # 方法文档
            for method in cls.methods:
                total += 1
                if method.docstring:
                    documented += 1

        # 函数文档
        for func in result.functions:
            total += 1
            if func.docstring:
                documented += 1

        return (documented / total * 100) if total > 0 else 100.0

    def _calculate_type_hint_coverage(self, result: PythonASTResult) -> float:
        """计算类型注解覆盖率"""
        total_params = 0
        typed_params = 0
        total_returns = 0
        typed_returns = 0

        def count_function(func: FunctionInfo):
            nonlocal total_params, typed_params, total_returns, typed_returns

            # 统计参数类型注解（跳过 self）
            args_to_check = func.args[1:] if func.is_method else func.args
            total_params += len(args_to_check)

            total_returns += 1
            if func.returns:
                typed_returns += 1

        # 统计类方法
        for cls in result.classes:
            for method in cls.methods:
                count_function(method)

        # 统计顶层函数
        for func in result.functions:
            count_function(func)

        total = total_params + total_returns
        typed = typed_params + typed_returns

        return (typed / total * 100) if total > 0 else 100.0


def analyze_python_file(file_path: str) -> PythonASTResult:
    """分析 Python 文件的便捷函数"""
    parser = PythonASTParser()
    return parser.parse_file(file_path)


def analyze_python_code(code: str) -> PythonASTResult:
    """分析 Python 代码字符串的便捷函数"""
    parser = PythonASTParser()
    return parser.parse_code(code)
