"""C 语言 AST 解析器

提供双模式解析能力：
- fast: 正则表达式快速解析，无外部依赖
- precise: pycparser AST 精确解析
- auto: 根据文件特征自动选择模式
"""

from dataclasses import dataclass
from typing import Optional, Literal
from pathlib import Path

from .c.models import CASTResult
from .c.regex_parser import CRegexParser

# 尝试导入 AST 解析器
try:
    from .c.ast_parser import CPycparserParser, PYCPARSER_AVAILABLE
except ImportError:
    CPycparserParser = None
    PYCPARSER_AVAILABLE = False


# 解析模式类型
ParseMode = Literal['fast', 'precise', 'auto']


@dataclass
class CParserConfig:
    """C 解析器配置"""
    default_mode: ParseMode = 'auto'
    auto_threshold_lines: int = 1000  # 超过此行数使用快速模式
    prefer_precise: bool = True  # 在 AST 可用时优先使用精确模式
    fake_libc_include: bool = True  # 是否使用 fake libc include（pycparser）


class CASTParser:
    """C 语言 AST 解析器（双模式）"""

    def __init__(self, config: Optional[CParserConfig] = None):
        """初始化解析器

        Args:
            config: 解析器配置，如果为 None 则使用默认配置
        """
        self.config = config or CParserConfig()
        self._regex_parser = CRegexParser()
        self._ast_parser = None

        # 延迟初始化 AST 解析器
        if PYCPARSER_AVAILABLE and self.config.prefer_precise:
            try:
                self._ast_parser = CPycparserParser()
            except Exception:
                self._ast_parser = None

    def parse_file(
        self,
        file_path: str,
        mode: Optional[ParseMode] = None
    ) -> CASTResult:
        """解析 C 文件

        Args:
            file_path: 文件路径
            mode: 解析模式
                - 'fast': 正则表达式快速解析
                - 'precise': pycparser AST 解析
                - 'auto': 根据文件特征自动选择

        Returns:
            CASTResult: 解析结果
        """
        path = Path(file_path)

        if not path.exists():
            return CASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".c", ".h", ".inc"):
            return CASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 C 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path, mode)
        except UnicodeDecodeError:
            # 尝试其他编码
            try:
                content = path.read_text(encoding="gbk")
                return self.parse_code(content, file_path, mode)
            except Exception as e:
                return CASTResult(
                    file_path=file_path,
                    success=False,
                    error=str(e)
                )
        except Exception as e:
            return CASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(
        self,
        code: str,
        file_path: str = "<string>",
        mode: Optional[ParseMode] = None
    ) -> CASTResult:
        """解析 C 代码字符串

        Args:
            code: C 代码字符串
            file_path: 文件路径（用于错误报告）
            mode: 解析模式

        Returns:
            CASTResult: 解析结果
        """
        # 确定解析模式
        actual_mode = mode or self.config.default_mode

        if actual_mode == 'auto':
            actual_mode = self._select_mode(code)

        # 执行解析
        if actual_mode == 'precise' and self._ast_parser:
            result = self._ast_parser.parse_code(code, file_path)
            result.parse_mode = 'precise'
            return result
        else:
            result = self._regex_parser.parse_code(code, file_path)
            result.parse_mode = 'fast'
            return result

    def _select_mode(self, code: str) -> ParseMode:
        """根据代码特征选择解析模式

        Args:
            code: 源代码

        Returns:
            选择的解析模式
        """
        lines = code.splitlines()
        line_count = len(lines)

        # 大文件使用快速模式
        if line_count > self.config.auto_threshold_lines:
            return 'fast'

        # 检查是否有复杂的预处理器指令
        preprocess_count = 0
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('#'):
                preprocess_count += 1

        # 预处理器指令过多时使用快速模式
        if preprocess_count > line_count * 0.2:
            return 'fast'

        # 检查是否使用了复杂宏
        complex_macros = [
            '#define',
            '#ifdef',
            '#ifndef',
            '#if defined',
        ]

        has_complex_macros = any(m in code for m in complex_macros)

        # 有复杂宏时，如果 AST 可用则使用精确模式
        if has_complex_macros and self._ast_parser:
            return 'precise'

        # 默认：如果 AST 可用则使用精确模式
        return 'precise' if self._ast_parser else 'fast'

    @property
    def precise_mode_available(self) -> bool:
        """检查精确模式是否可用"""
        return self._ast_parser is not None

    def get_parser_info(self) -> dict:
        """获取解析器信息"""
        return {
            'precise_mode_available': self.precise_mode_available,
            'pycparser_available': PYCPARSER_AVAILABLE,
            'default_mode': self.config.default_mode,
            'auto_threshold_lines': self.config.auto_threshold_lines,
        }


def analyze_c_file(
    file_path: str,
    mode: Optional[ParseMode] = None
) -> CASTResult:
    """分析 C 文件的便捷函数

    Args:
        file_path: 文件路径
        mode: 解析模式

    Returns:
        CASTResult: 解析结果
    """
    parser = CASTParser()
    return parser.parse_file(file_path, mode)


def analyze_c_code(
    code: str,
    mode: Optional[ParseMode] = None
) -> CASTResult:
    """分析 C 代码字符串的便捷函数

    Args:
        code: C 代码字符串
        mode: 解析模式

    Returns:
        CASTResult: 解析结果
    """
    parser = CASTParser()
    return parser.parse_code(code, mode=mode)


# 为了向后兼容，导出类型
from .c.models import (
    CFunctionInfo,
    CVariableInfo,
    CStructInfo,
    CUnionInfo,
    CEnumInfo,
    CTypedefInfo,
    CMacroInfo,
    CIncludeInfo,
    CParameterInfo,
    CStructMember,
    CEnumMember,
    CFunctionPointerInfo,
)


__all__ = [
    # 解析器
    "CASTParser",
    "CParserConfig",
    "ParseMode",
    # 便捷函数
    "analyze_c_file",
    "analyze_c_code",
    # 数据类型
    "CASTResult",
    "CFunctionInfo",
    "CVariableInfo",
    "CStructInfo",
    "CUnionInfo",
    "CEnumInfo",
    "CTypedefInfo",
    "CMacroInfo",
    "CIncludeInfo",
    "CParameterInfo",
    "CStructMember",
    "CEnumMember",
    "CFunctionPointerInfo",
]
