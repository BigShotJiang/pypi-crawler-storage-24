"""Kotlin AST 解析器

提供双模式解析能力：
- fast: 正则表达式快速解析，无外部依赖
- precise: tree-sitter AST 精确解析
- auto: 根据文件特征自动选择模式
"""

from dataclasses import dataclass
from typing import Optional, Literal
from pathlib import Path

from .kotlin.models import KotlinASTResult
from .kotlin.regex_parser import KotlinRegexParser

# 尝试导入 AST 解析器
try:
    from .kotlin.ast_parser import KotlinTreeSitterParser, TREE_SITTER_AVAILABLE
except ImportError:
    KotlinTreeSitterParser = None
    TREE_SITTER_AVAILABLE = False


# 解析模式类型
ParseMode = Literal['fast', 'precise', 'auto']


@dataclass
class KotlinParserConfig:
    """Kotlin 解析器配置"""
    default_mode: ParseMode = 'auto'
    auto_threshold_lines: int = 500  # 超过此行数使用快速模式
    prefer_precise: bool = True  # 在 AST 可用时优先使用精确模式


class KotlinASTParser:
    """Kotlin AST 解析器（双模式）"""

    def __init__(self, config: Optional[KotlinParserConfig] = None):
        """初始化解析器

        Args:
            config: 解析器配置，如果为 None 则使用默认配置
        """
        self.config = config or KotlinParserConfig()
        self._regex_parser = KotlinRegexParser()
        self._ast_parser = None

        # 延迟初始化 AST 解析器
        if TREE_SITTER_AVAILABLE and self.config.prefer_precise:
            try:
                self._ast_parser = KotlinTreeSitterParser()
            except Exception:
                self._ast_parser = None

    def parse_file(
        self,
        file_path: str,
        mode: Optional[ParseMode] = None
    ) -> KotlinASTResult:
        """解析 Kotlin 文件

        Args:
            file_path: 文件路径
            mode: 解析模式
                - 'fast': 正则表达式快速解析
                - 'precise': tree-sitter AST 解析
                - 'auto': 根据文件特征自动选择

        Returns:
            KotlinASTResult: 解析结果
        """
        path = Path(file_path)

        if not path.exists():
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".kt", ".kts"):
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 Kotlin 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path, mode)
        except Exception as e:
            return KotlinASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(
        self,
        code: str,
        file_path: str = "<string>",
        mode: Optional[ParseMode] = None
    ) -> KotlinASTResult:
        """解析 Kotlin 代码字符串

        Args:
            code: Kotlin 代码字符串
            file_path: 文件路径（用于错误报告）
            mode: 解析模式

        Returns:
            KotlinASTResult: 解析结果
        """
        # 确定解析模式
        actual_mode = mode or self.config.default_mode

        if actual_mode == 'auto':
            actual_mode = self._select_mode(code)

        # 执行解析
        if actual_mode == 'precise' and self._ast_parser:
            result = self._ast_parser.parse_code(code, file_path)
            result.parse_mode = 'precise'
            return result
        else:
            result = self._regex_parser.parse_code(code, file_path)
            result.parse_mode = 'fast'
            return result

    def _select_mode(self, code: str) -> ParseMode:
        """根据代码特征选择解析模式

        Args:
            code: 源代码

        Returns:
            选择的解析模式
        """
        lines = code.splitlines()
        line_count = len(lines)

        # 大文件使用快速模式
        if line_count > self.config.auto_threshold_lines:
            return 'fast'

        # 复杂度检查：计算嵌套深度和大括号数量
        max_depth = 0
        current_depth = 0
        brace_count = 0

        for line in lines:
            current_depth += line.count('{') - line.count('}')
            max_depth = max(max_depth, current_depth)
            brace_count += line.count('{')

        # 复杂代码使用快速模式
        if max_depth > 5 or brace_count > 50:
            return 'fast'

        # 检查是否有复杂的 Kotlin 特性
        complex_features = [
            'sealed',
            'inline class',
            'value class',
            'by lazy',
            'suspend fun',
            'Flow<',
            'when (',
            'contract {',
        ]

        for feature in complex_features:
            if feature in code:
                # 有复杂特性时，如果 AST 可用则使用精确模式
                if self._ast_parser:
                    return 'precise'
                break

        # 默认：如果 AST 可用则使用精确模式
        return 'precise' if self._ast_parser else 'fast'

    @property
    def precise_mode_available(self) -> bool:
        """检查精确模式是否可用"""
        return self._ast_parser is not None

    def get_parser_info(self) -> dict:
        """获取解析器信息"""
        return {
            'precise_mode_available': self.precise_mode_available,
            'tree_sitter_available': TREE_SITTER_AVAILABLE,
            'default_mode': self.config.default_mode,
            'auto_threshold_lines': self.config.auto_threshold_lines,
        }


def analyze_kotlin_file(
    file_path: str,
    mode: Optional[ParseMode] = None
) -> KotlinASTResult:
    """分析 Kotlin 文件的便捷函数

    Args:
        file_path: 文件路径
        mode: 解析模式

    Returns:
        KotlinASTResult: 解析结果
    """
    parser = KotlinASTParser()
    return parser.parse_file(file_path, mode)


def analyze_kotlin_code(
    code: str,
    mode: Optional[ParseMode] = None
) -> KotlinASTResult:
    """分析 Kotlin 代码字符串的便捷函数

    Args:
        code: Kotlin 代码字符串
        mode: 解析模式

    Returns:
        KotlinASTResult: 解析结果
    """
    parser = KotlinASTParser()
    return parser.parse_code(code, mode=mode)


# 为了向后兼容，导出原有类型
from .kotlin.models import (
    KotlinFunctionInfo,
    KotlinPropertyInfo,
    KotlinClassInfo,
    KotlinImportInfo,
    KotlinSealedClassInfo,
    KotlinWhenExpression,
    KotlinCoroutineInfo,
    KotlinFlowOperator,
    KotlinTypeAlias,
    KotlinValueClass,
    KotlinDelegatedProperty,
    KotlinExtensionFunction,
    KotlinExtensionProperty,
    KotlinObjectDeclaration,
    KotlinEnumClassInfo,
    KotlinDataClassInfo,
)


__all__ = [
    # 解析器
    "KotlinASTParser",
    "KotlinParserConfig",
    "ParseMode",
    # 便捷函数
    "analyze_kotlin_file",
    "analyze_kotlin_code",
    # 数据类型
    "KotlinASTResult",
    "KotlinFunctionInfo",
    "KotlinPropertyInfo",
    "KotlinClassInfo",
    "KotlinImportInfo",
    "KotlinSealedClassInfo",
    "KotlinWhenExpression",
    "KotlinCoroutineInfo",
    "KotlinFlowOperator",
    "KotlinTypeAlias",
    "KotlinValueClass",
    "KotlinDelegatedProperty",
    "KotlinExtensionFunction",
    "KotlinExtensionProperty",
    "KotlinObjectDeclaration",
    "KotlinEnumClassInfo",
    "KotlinDataClassInfo",
]
