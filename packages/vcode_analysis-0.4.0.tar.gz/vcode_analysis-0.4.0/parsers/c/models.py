"""C 语言解析数据模型

定义 C 代码解析结果的数据结构。
支持 C89/C90 标准。
"""

from dataclasses import dataclass, field
from typing import Optional, Literal


# ==================== 函数相关 ====================

@dataclass
class CParameterInfo:
    """函数参数信息"""
    name: str
    type: str
    is_pointer: bool = False
    is_array: bool = False
    array_size: Optional[str] = None


@dataclass
class CFunctionInfo:
    """C 函数信息"""
    name: str
    line_start: int
    line_end: int
    return_type: str
    parameters: list[CParameterInfo]
    storage_class: Optional[str] = None  # static, extern, inline
    is_declaration: bool = False  # 是声明还是定义
    is_variadic: bool = False  # 是否为可变参数函数
    is_pointer_return: bool = False  # 返回值是否为指针


@dataclass
class CFunctionPointerInfo:
    """函数指针信息"""
    name: str
    return_type: str
    parameters: list[CParameterInfo]
    line: int
    is_typedef: bool = False


# ==================== 变量相关 ====================

@dataclass
class CArrayInfo:
    """数组信息"""
    size: Optional[str]  # 数组大小（可能是常量表达式）
    is_static: bool = False  # static 数组


@dataclass
class CPointerInfo:
    """指针信息"""
    level: int  # 指针级别 (int** -> 2)
    is_const: bool = False  # 指向常量的指针
    is_volatile: bool = False


@dataclass
class CVariableInfo:
    """C 变量信息"""
    name: str
    type: str
    line: int
    storage_class: Optional[str] = None  # static, extern, auto, register
    is_const: bool = False
    is_volatile: bool = False
    is_pointer: bool = False
    pointer_level: int = 0
    is_array: bool = False
    array_size: Optional[str] = None
    initializer: Optional[str] = None
    is_global: bool = False  # 是否为全局变量


# ==================== 结构体/联合体 ====================

@dataclass
class CStructMember:
    """结构体/联合体成员"""
    name: str
    type: str
    bit_field: Optional[int] = None  # 位域大小
    is_pointer: bool = False
    is_array: bool = False
    array_size: Optional[str] = None


@dataclass
class CStructInfo:
    """结构体信息"""
    name: str
    line_start: int
    line_end: int
    members: list[CStructMember]
    is_typedef: bool = False
    typedef_name: Optional[str] = None


@dataclass
class CUnionInfo:
    """联合体信息"""
    name: str
    line_start: int
    line_end: int
    members: list[CStructMember]
    is_typedef: bool = False
    typedef_name: Optional[str] = None


# ==================== 枚举 ====================

@dataclass
class CEnumMember:
    """枚举成员"""
    name: str
    value: Optional[str] = None


@dataclass
class CEnumInfo:
    """枚举信息"""
    name: str
    line_start: int
    line_end: int
    members: list[CEnumMember]
    is_typedef: bool = False
    typedef_name: Optional[str] = None


# ==================== typedef ====================

@dataclass
class CTypedefInfo:
    """typedef 信息"""
    name: str  # 新类型名
    original_type: str  # 原类型
    line: int
    is_struct: bool = False
    is_union: bool = False
    is_enum: bool = False
    is_function_pointer: bool = False


# ==================== 预处理器 ====================

@dataclass
class CIncludeInfo:
    """#include 信息"""
    path: str
    is_system: bool  # <...> vs "..."
    line: int


@dataclass
class CMacroInfo:
    """宏定义信息"""
    name: str
    value: Optional[str]  # 宏值（对象式宏）
    parameters: Optional[list[str]]  # 函数式宏参数
    body: Optional[str]  # 宏体（函数式宏）
    line: int
    is_function_like: bool = False


# ==================== 解析结果 ====================

@dataclass
class CASTResult:
    """C AST 解析结果"""
    file_path: str
    success: bool
    error: Optional[str] = None
    parse_mode: str = "fast"  # fast, precise, auto

    # 预处理器
    includes: list[CIncludeInfo] = field(default_factory=list)
    macros: list[CMacroInfo] = field(default_factory=list)

    # 类型定义
    typedefs: list[CTypedefInfo] = field(default_factory=list)
    structs: list[CStructInfo] = field(default_factory=list)
    unions: list[CUnionInfo] = field(default_factory=list)
    enums: list[CEnumInfo] = field(default_factory=list)

    # 函数
    functions: list[CFunctionInfo] = field(default_factory=list)
    function_pointers: list[CFunctionPointerInfo] = field(default_factory=list)

    # 变量
    global_variables: list[CVariableInfo] = field(default_factory=list)

    # 统计信息
    total_lines: int = 0

    def merge_from(self, other: 'CASTResult'):
        """合并另一个解析结果"""
        self.includes.extend(other.includes)
        self.macros.extend(other.macros)
        self.typedefs.extend(other.typedefs)
        self.structs.extend(other.structs)
        self.unions.extend(other.unions)
        self.enums.extend(other.enums)
        self.functions.extend(other.functions)
        self.function_pointers.extend(other.function_pointers)
        self.global_variables.extend(other.global_variables)
