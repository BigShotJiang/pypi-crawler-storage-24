"""C 语言正则表达式模式定义

定义用于快速解析 C 代码的正则表达式模式。
支持 C89/C90 标准。
"""

# 基础模式
C_PATTERNS = {
    # ==================== 预处理器指令 ====================

    # #include 指令
    "include_angle": r'#include\s*<([^>]+)>',  # #include <stdio.h>
    "include_quote": r'#include\s*"([^"]+)"',  # #include "myheader.h"

    # #define 宏定义
    "define_object": r'#define\s+(\w+)(?:\s+(.+?))?$',  # #define PI 3.14
    "define_function": r'#define\s+(\w+)\s*\(([^)]*)\)\s*(.*)$',  # #define MAX(a,b) ((a)>(b)?(a):(b))

    # 条件编译
    "ifdef": r'#ifdef\s+(\w+)',
    "ifndef": r'#ifndef\s+(\w+)',
    "if_defined": r'#if\s+(?:defined\s*\(\s*(\w+)\s*\)|defined\s+(\w+))',
    "endif": r'#endif',
    "else": r'#else',
    "elif": r'#elif',

    # #pragma
    "pragma": r'#pragma\s+(.+)$',

    # #undef
    "undef": r'#undef\s+(\w+)',

    # ==================== 函数定义 ====================

    # 函数声明/定义
    "function_declaration": r'(?:^|\n)\s*(?:(static|inline|extern)\s+)?'
                           r'(\w+(?:\s*\*)*)\s+'  # 返回类型
                           r'(\w+)\s*'  # 函数名
                           r'\(([^)]*)\)\s*'  # 参数
                           r'(?:;|\{)',  # 声明结束或定义开始

    # 函数原型
    "function_prototype": r'(?:^|\n)\s*(?:(static|inline|extern)\s+)?'
                          r'(\w+(?:\s*\*)*)\s+'
                          r'(\w+)\s*'
                          r'\(([^)]*)\)\s*;',

    # ==================== 变量声明 ====================

    # 全局变量
    "global_variable": r'(?:^|\n)\s*(?:(extern|static|const|volatile)\s+)*'
                       r'(\w+(?:\s*\*)*)\s+'  # 类型
                       r'(\w+)'  # 变量名
                       r'(?:\s*\[([^\]]*)\])?'  # 可选数组大小
                       r'(?:\s*=\s*([^;]+))?\s*;',  # 可选初始化

    # ==================== 结构体/联合体 ====================

    # 结构体定义
    "struct_definition": r'struct\s+(\w*)\s*\{([^}]*?)\}\s*(?:\w+\s*)?;',

    # 结构体声明
    "struct_declaration": r'struct\s+(\w+)\s*(\w+)\s*;',

    # 联合体定义
    "union_definition": r'union\s+(\w*)\s*\{([^}]*?)\}\s*(?:\w+\s*)?;',

    # ==================== 枚举 ====================

    # 枚举定义
    "enum_definition": r'enum\s+(\w*)\s*\{([^}]*?)\}\s*(?:\w+\s*)?;',

    # 枚举成员
    "enum_member": r'(\w+)(?:\s*=\s*([^,]+))?',

    # ==================== typedef ====================

    # typedef 基本类型
    "typedef_basic": r'typedef\s+(?:const\s+)?(\w+(?:\s*\*)*)\s+(\w+)\s*;',

    # typedef 结构体
    "typedef_struct": r'typedef\s+struct\s+(\w*)\s*\{([^}]*?)\}\s*(\w+)\s*;',

    # typedef 联合体
    "typedef_union": r'typedef\s+union\s+(\w*)\s*\{([^}]*?)\}\s*(\w+)\s*;',

    # typedef 枚举
    "typedef_enum": r'typedef\s+enum\s+(\w*)\s*\{([^}]*?)\}\s*(\w+)\s*;',

    # typedef 函数指针
    "typedef_function_pointer": r'typedef\s+(\w+(?:\s*\*)*)\s*\(\s*\*\s*(\w+)\s*\)\s*\(([^)]*)\)\s*;',

    # ==================== 函数指针 ====================

    # 函数指针变量
    "function_pointer": r'(\w+(?:\s*\*)*)\s*\(\s*\*\s*(\w+)\s*\)\s*\(([^)]*)\)',

    # ==================== 注释 ====================

    # 单行注释
    "single_line_comment": r'//.*$',

    # 多行注释
    "multi_line_comment": r'/\*[\s\S]*?\*/',
}

# C 关键字列表
C_KEYWORDS = {
    # 存储类说明符
    'auto', 'register', 'static', 'extern', 'typedef',

    # 类型说明符
    'void', 'char', 'short', 'int', 'long', 'float', 'double',
    'signed', 'unsigned', 'struct', 'union', 'enum',

    # 类型限定符
    'const', 'volatile',

    # 控制语句
    'if', 'else', 'switch', 'case', 'default',
    'for', 'while', 'do', 'break', 'continue', 'goto', 'return',

    # 其他
    'sizeof', 'typedef',
}

# 基本类型
C_BASIC_TYPES = {
    'void', 'char', 'short', 'int', 'long', 'float', 'double',
    'unsigned char', 'unsigned short', 'unsigned int', 'unsigned long',
    'signed char', 'signed short', 'signed int', 'signed long',
    'long long', 'unsigned long long', 'long double',
}

# 存储类说明符
C_STORAGE_CLASSES = {
    'auto', 'register', 'static', 'extern', 'typedef',
}

# 类型限定符
C_TYPE_QUALIFIERS = {
    'const', 'volatile',
}
