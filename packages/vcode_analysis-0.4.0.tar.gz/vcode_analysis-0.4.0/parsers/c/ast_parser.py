"""C 语言 AST 解析器（pycparser）

使用 pycparser 进行精确的语法树解析。
支持 C89/C90 标准。
"""

from pathlib import Path
from typing import Optional

try:
    from pycparser import c_parser, c_ast, parse_file

    PYCPARSER_AVAILABLE = True
except ImportError:
    PYCPARSER_AVAILABLE = False
    c_parser = None
    c_ast = None
    parse_file = None

from .models import (
    CASTResult,
    CFunctionInfo,
    CVariableInfo,
    CStructInfo,
    CUnionInfo,
    CEnumInfo,
    CTypedefInfo,
    CMacroInfo,
    CIncludeInfo,
    CParameterInfo,
    CStructMember,
    CEnumMember,
    CFunctionPointerInfo,
)


class CPycparserParser:
    """C 语言 AST 解析器（精确模式）"""

    def __init__(self):
        if not PYCPARSER_AVAILABLE:
            raise ImportError(
                "请安装 pycparser: pip install pycparser"
            )

        self.parser = c_parser.CParser()

    def parse_file(self, file_path: str) -> CASTResult:
        """解析 C 文件"""
        path = Path(file_path)

        if not path.exists():
            return CASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".c", ".h", ".inc"):
            return CASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 C 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except UnicodeDecodeError:
            try:
                content = path.read_text(encoding="gbk")
                return self.parse_code(content, file_path)
            except Exception as e:
                return CASTResult(
                    file_path=file_path,
                    success=False,
                    error=str(e)
                )
        except Exception as e:
            return CASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> CASTResult:
        """解析 C 代码字符串"""
        result = CASTResult(
            file_path=file_path,
            success=True,
            parse_mode="precise",
            total_lines=len(code.splitlines())
        )

        try:
            # 预处理代码（pycparser 需要预处理后的代码）
            # 注意：对于简单代码，可以直接解析
            # 对于包含 #include 的代码，需要使用 fake_libc_include
            preprocessed = self._fake_preprocess(code)

            # 解析 AST
            ast = self.parser.parse(preprocessed, filename=file_path)

            # 遍历 AST
            self._traverse_ast(ast, result)

        except Exception as e:
            result.success = False
            result.error = f"AST 解析错误: {str(e)}"

        return result

    def _fake_preprocess(self, code: str) -> str:
        """模拟预处理（移除预处理器指令）

        注意：这是一个简化版本，对于复杂代码需要真正的预处理。
        """
        import re

        lines = []
        for line in code.split('\n'):
            stripped = line.strip()

            # 移除 #include 指令
            if stripped.startswith('#include'):
                continue

            # 移除 #define 指令（但保留宏展开结果不可行，所以跳过）
            if stripped.startswith('#define'):
                continue

            # 移除其他预处理指令
            if stripped.startswith('#'):
                continue

            lines.append(line)

        return '\n'.join(lines)

    def _traverse_ast(self, ast, result: CASTResult):
        """遍历 AST"""
        for ext in ast.ext:
            if isinstance(ext, c_ast.FuncDef):
                self._parse_function(ext, result)
            elif isinstance(ext, c_ast.Decl):
                self._parse_declaration(ext, result)
            elif isinstance(ext, c_ast.Typedef):
                self._parse_typedef(ext, result)

    def _parse_function(self, func_def, result: CASTResult):
        """解析函数定义"""
        decl = func_def.decl

        name = decl.name
        return_type = self._get_type(decl.type)
        storage = decl.storage[0] if decl.storage else None

        # 解析参数
        parameters = []
        if hasattr(decl.type, 'args') and decl.type.args:
            for param in decl.type.args.params or []:
                if isinstance(param, c_ast.Decl):
                    parameters.append(CParameterInfo(
                        name=param.name or "",
                        type=self._get_type(param.type),
                        is_pointer=self._is_pointer(param.type),
                        is_array=self._is_array(param.type)
                    ))

        # 计算行号
        line_start = func_def.coord.line if func_def.coord else 0

        result.functions.append(CFunctionInfo(
            name=name,
            line_start=line_start,
            line_end=line_start,  # 需要进一步计算
            return_type=return_type,
            parameters=parameters,
            storage_class=storage,
            is_declaration=False,
            is_variadic=False,
            is_pointer_return=self._is_pointer(decl.type)
        ))

    def _parse_declaration(self, decl, result: CASTResult):
        """解析声明（全局变量、函数声明等）"""
        if isinstance(decl.type, c_ast.FuncDecl):
            # 函数声明
            self._parse_function_declaration(decl, result)
        else:
            # 全局变量
            self._parse_global_variable(decl, result)

    def _parse_function_declaration(self, decl, result: CASTResult):
        """解析函数声明"""
        name = decl.name
        return_type = self._get_type(decl.type)
        storage = decl.storage[0] if decl.storage else None

        # 解析参数
        parameters = []
        if hasattr(decl.type, 'args') and decl.type.args:
            for param in decl.type.args.params or []:
                if isinstance(param, c_ast.Decl):
                    parameters.append(CParameterInfo(
                        name=param.name or "",
                        type=self._get_type(param.type),
                        is_pointer=self._is_pointer(param.type)
                    ))
                elif isinstance(param, c_ast.Typename):
                    # 无名参数
                    parameters.append(CParameterInfo(
                        name="",
                        type=self._get_type(param.type)
                    ))
                elif isinstance(param, c_ast.EllipsisParam):
                    # 可变参数
                    pass

        line = decl.coord.line if decl.coord else 0

        result.functions.append(CFunctionInfo(
            name=name,
            line_start=line,
            line_end=line,
            return_type=return_type,
            parameters=parameters,
            storage_class=storage,
            is_declaration=True,
            is_variadic=False,
            is_pointer_return=self._is_pointer(decl.type)
        ))

    def _parse_global_variable(self, decl, result: CASTResult):
        """解析全局变量"""
        name = decl.name
        var_type = self._get_type(decl.type)
        storage = decl.storage[0] if decl.storage else None

        line = decl.coord.line if decl.coord else 0

        result.global_variables.append(CVariableInfo(
            name=name,
            type=var_type,
            line=line,
            storage_class=storage,
            is_const='const' in str(decl.quals) if decl.quals else False,
            is_volatile='volatile' in str(decl.quals) if decl.quals else False,
            is_pointer=self._is_pointer(decl.type),
            pointer_level=self._pointer_level(decl.type),
            is_array=self._is_array(decl.type),
            is_global=True
        ))

    def _parse_typedef(self, typedef, result: CASTResult):
        """解析 typedef"""
        name = typedef.name
        original_type = self._get_type(typedef.type)
        line = typedef.coord.line if typedef.coord else 0

        is_struct = isinstance(typedef.type, c_ast.Struct)
        is_union = isinstance(typedef.type, c_ast.Union)
        is_enum = isinstance(typedef.type, c_ast.Enum)

        result.typedefs.append(CTypedefInfo(
            name=name,
            original_type=original_type,
            line=line,
            is_struct=is_struct,
            is_union=is_union,
            is_enum=is_enum
        ))

        # 如果是结构体/联合体/枚举，也添加到对应列表
        if is_struct:
            self._parse_struct_from_typedef(typedef.type, result, name)
        elif is_union:
            self._parse_union_from_typedef(typedef.type, result, name)
        elif is_enum:
            self._parse_enum_from_typedef(typedef.type, result, name)

    def _parse_struct_from_typedef(self, struct_type, result: CASTResult, typedef_name: str):
        """从 typedef 解析结构体"""
        name = struct_type.name or typedef_name
        members = []

        if struct_type.decls:
            for decl in struct_type.decls:
                member = CStructMember(
                    name=decl.name or "",
                    type=self._get_type(decl.type),
                    is_pointer=self._is_pointer(decl.type),
                    is_array=self._is_array(decl.type)
                )
                members.append(member)

        result.structs.append(CStructInfo(
            name=name,
            line_start=0,
            line_end=0,
            members=members,
            is_typedef=True,
            typedef_name=typedef_name
        ))

    def _parse_union_from_typedef(self, union_type, result: CASTResult, typedef_name: str):
        """从 typedef 解析联合体"""
        name = union_type.name or typedef_name
        members = []

        if union_type.decls:
            for decl in union_type.decls:
                member = CStructMember(
                    name=decl.name or "",
                    type=self._get_type(decl.type),
                    is_pointer=self._is_pointer(decl.type)
                )
                members.append(member)

        result.unions.append(CUnionInfo(
            name=name,
            line_start=0,
            line_end=0,
            members=members,
            is_typedef=True,
            typedef_name=typedef_name
        ))

    def _parse_enum_from_typedef(self, enum_type, result: CASTResult, typedef_name: str):
        """从 typedef 解析枚举"""
        name = enum_type.name or typedef_name
        members = []

        if enum_type.values:
            for value in enum_type.values.enumerators:
                members.append(CEnumMember(
                    name=value.name,
                    value=str(value.value.value) if value.value else None
                ))

        result.enums.append(CEnumInfo(
            name=name,
            line_start=0,
            line_end=0,
            members=members,
            is_typedef=True,
            typedef_name=typedef_name
        ))

    # ==================== 类型辅助方法 ====================

    def _get_type(self, type_node) -> str:
        """获取类型字符串"""
        if type_node is None:
            return "void"

        if isinstance(type_node, c_ast.TypeDecl):
            type_str = type_node.type.names[0] if hasattr(type_node.type, 'names') else "unknown"
            return type_str

        if isinstance(type_node, c_ast.PtrDecl):
            return self._get_type(type_node.type) + "*"

        if isinstance(type_node, c_ast.ArrayDecl):
            return self._get_type(type_node.type) + "[]"

        if isinstance(type_node, c_ast.FuncDecl):
            return self._get_type(type_node.type) + "(*)()"

        if hasattr(type_node, 'names'):
            return type_node.names[0]

        if hasattr(type_node, 'type'):
            return self._get_type(type_node.type)

        return str(type_node)

    def _is_pointer(self, type_node) -> bool:
        """检查是否为指针类型"""
        if type_node is None:
            return False

        if isinstance(type_node, c_ast.PtrDecl):
            return True

        if hasattr(type_node, 'type'):
            return self._is_pointer(type_node.type)

        return False

    def _is_array(self, type_node) -> bool:
        """检查是否为数组类型"""
        if type_node is None:
            return False

        if isinstance(type_node, c_ast.ArrayDecl):
            return True

        if hasattr(type_node, 'type'):
            return self._is_array(type_node.type)

        return False

    def _pointer_level(self, type_node) -> int:
        """获取指针级别"""
        if type_node is None:
            return 0

        if isinstance(type_node, c_ast.PtrDecl):
            return 1 + self._pointer_level(type_node.type)

        if hasattr(type_node, 'type'):
            return self._pointer_level(type_node.type)

        return 0


# 如果 pycparser 不可用，提供一个占位类
if not PYCPARSER_AVAILABLE:
    class CPycparserParser:
        def __init__(self):
            raise ImportError(
                "请安装 pycparser: pip install pycparser"
            )
