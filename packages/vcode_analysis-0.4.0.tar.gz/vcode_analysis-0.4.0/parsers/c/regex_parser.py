"""C 语言正则解析器

使用正则表达式快速解析 C 代码结构。
支持 C89/C90 标准。
"""

import re
from pathlib import Path
from typing import Optional

from .models import (
    CASTResult,
    CFunctionInfo,
    CVariableInfo,
    CStructInfo,
    CUnionInfo,
    CEnumInfo,
    CTypedefInfo,
    CMacroInfo,
    CIncludeInfo,
    CParameterInfo,
    CStructMember,
    CEnumMember,
    CFunctionPointerInfo,
)
from .patterns import C_PATTERNS, C_KEYWORDS, C_BASIC_TYPES


class CRegexParser:
    """C 语言正则解析器（快速模式）"""

    def __init__(self):
        self.patterns = C_PATTERNS
        # 预编译正则表达式
        self._compiled = {}
        for name, pattern in self.patterns.items():
            try:
                self._compiled[name] = re.compile(pattern, re.MULTILINE)
            except re.error:
                pass

    def parse_file(self, file_path: str) -> CASTResult:
        """解析 C 文件"""
        path = Path(file_path)

        if not path.exists():
            return CASTResult(
                file_path=file_path,
                success=False,
                error=f"文件不存在: {file_path}"
            )

        if path.suffix not in (".c", ".h", ".inc"):
            return CASTResult(
                file_path=file_path,
                success=False,
                error=f"不是 C 文件: {file_path}"
            )

        try:
            content = path.read_text(encoding="utf-8")
            return self.parse_code(content, file_path)
        except UnicodeDecodeError:
            # 尝试其他编码
            try:
                content = path.read_text(encoding="gbk")
                return self.parse_code(content, file_path)
            except Exception as e:
                return CASTResult(
                    file_path=file_path,
                    success=False,
                    error=str(e)
                )
        except Exception as e:
            return CASTResult(
                file_path=file_path,
                success=False,
                error=str(e)
            )

    def parse_code(self, code: str, file_path: str = "<string>") -> CASTResult:
        """解析 C 代码字符串"""
        result = CASTResult(
            file_path=file_path,
            success=True,
            parse_mode="fast",
            total_lines=len(code.splitlines())
        )

        lines = code.split('\n')

        # 预处理：移除注释和字符串字面量（简化解析）
        clean_code = self._preprocess_code(code)

        # 解析预处理器指令
        self._parse_includes(code, result, lines)
        self._parse_macros(code, result, lines)

        # 解析类型定义
        self._parse_typedefs(clean_code, result, lines)
        self._parse_structs(clean_code, result, lines)
        self._parse_unions(clean_code, result, lines)
        self._parse_enums(clean_code, result, lines)

        # 解析函数
        self._parse_functions(clean_code, result, lines)

        # 解析全局变量
        self._parse_global_variables(clean_code, result, lines)

        return result

    def _preprocess_code(self, code: str) -> str:
        """预处理代码：移除注释和字符串"""
        # 移除单行注释
        code = re.sub(r'//.*$', '', code, flags=re.MULTILINE)

        # 移除多行注释
        code = re.sub(r'/\*[\s\S]*?\*/', '', code)

        # 替换字符串字面量为占位符
        code = re.sub(r'"[^"\\]*(?:\\.[^"\\]*)*"', '""', code)

        # 替换字符字面量为占位符
        code = re.sub(r"'[^'\\]*(?:\\.[^'\\]*)*'", "''", code)

        return code

    # ==================== 预处理器指令 ====================

    def _parse_includes(self, code: str, result: CASTResult, lines: list):
        """解析 #include 指令"""
        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # 系统头文件 <...>
            m = self._compiled.get('include_angle')
            if m:
                match = m.match(stripped)
                if match:
                    result.includes.append(CIncludeInfo(
                        path=match.group(1),
                        is_system=True,
                        line=i
                    ))
                    continue

            # 用户头文件 "..."
            m = self._compiled.get('include_quote')
            if m:
                match = m.match(stripped)
                if match:
                    result.includes.append(CIncludeInfo(
                        path=match.group(1),
                        is_system=False,
                        line=i
                    ))

    def _parse_macros(self, code: str, result: CASTResult, lines: list):
        """解析 #define 宏定义"""
        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            if not stripped.startswith('#define'):
                continue

            # 尝试匹配函数式宏
            func_pattern = self._compiled.get('define_function')
            if func_pattern:
                m = func_pattern.match(stripped)
                if m:
                    params = [p.strip() for p in m.group(2).split(',') if p.strip()]
                    result.macros.append(CMacroInfo(
                        name=m.group(1),
                        value=None,
                        parameters=params,
                        body=m.group(3).strip() if m.group(3) else None,
                        line=i,
                        is_function_like=True
                    ))
                    continue

            # 尝试匹配对象式宏
            obj_pattern = self._compiled.get('define_object')
            if obj_pattern:
                m = obj_pattern.match(stripped)
                if m:
                    result.macros.append(CMacroInfo(
                        name=m.group(1),
                        value=m.group(2).strip() if m.group(2) else None,
                        parameters=None,
                        body=None,
                        line=i,
                        is_function_like=False
                    ))

    # ==================== 类型定义 ====================

    def _parse_typedefs(self, code: str, result: CASTResult, lines: list):
        """解析 typedef"""
        pattern = self._compiled.get('typedef_basic')
        if not pattern:
            return

        for m in pattern.finditer(code):
            original_type = m.group(1).strip()
            new_name = m.group(2).strip()

            result.typedefs.append(CTypedefInfo(
                name=new_name,
                original_type=original_type,
                line=self._find_line(code, m.start()),
                is_struct=False,
                is_union=False,
                is_enum=False,
                is_function_pointer=False
            ))

        # 解析函数指针 typedef
        fp_pattern = self._compiled.get('typedef_function_pointer')
        if fp_pattern:
            for m in fp_pattern.finditer(code):
                return_type = m.group(1).strip()
                name = m.group(2).strip()
                params_str = m.group(3)

                result.typedefs.append(CTypedefInfo(
                    name=name,
                    original_type=f"{return_type}(*)({params_str})",
                    line=self._find_line(code, m.start()),
                    is_function_pointer=True
                ))

    def _parse_structs(self, code: str, result: CASTResult, lines: list):
        """解析结构体定义"""
        # typedef struct
        ts_pattern = self._compiled.get('typedef_struct')
        if ts_pattern:
            for m in ts_pattern.finditer(code):
                struct_name = m.group(1) if m.group(1) else None
                body = m.group(2)
                typedef_name = m.group(3).strip()

                members = self._parse_struct_body(body)

                struct_info = CStructInfo(
                    name=struct_name or typedef_name,
                    line_start=self._find_line(code, m.start()),
                    line_end=self._find_line(code, m.end()),
                    members=members,
                    is_typedef=True,
                    typedef_name=typedef_name
                )
                result.structs.append(struct_info)

        # 普通 struct 定义
        s_pattern = self._compiled.get('struct_definition')
        if s_pattern:
            for m in s_pattern.finditer(code):
                name = m.group(1) if m.group(1) else "<anonymous>"
                body = m.group(2)

                members = self._parse_struct_body(body)

                struct_info = CStructInfo(
                    name=name,
                    line_start=self._find_line(code, m.start()),
                    line_end=self._find_line(code, m.end()),
                    members=members,
                    is_typedef=False
                )
                result.structs.append(struct_info)

    def _parse_unions(self, code: str, result: CASTResult, lines: list):
        """解析联合体定义"""
        # typedef union
        tu_pattern = self._compiled.get('typedef_union')
        if tu_pattern:
            for m in tu_pattern.finditer(code):
                union_name = m.group(1) if m.group(1) else None
                body = m.group(2)
                typedef_name = m.group(3).strip()

                members = self._parse_struct_body(body)

                union_info = CUnionInfo(
                    name=union_name or typedef_name,
                    line_start=self._find_line(code, m.start()),
                    line_end=self._find_line(code, m.end()),
                    members=members,
                    is_typedef=True,
                    typedef_name=typedef_name
                )
                result.unions.append(union_info)

        # 普通 union 定义
        u_pattern = self._compiled.get('union_definition')
        if u_pattern:
            for m in u_pattern.finditer(code):
                name = m.group(1) if m.group(1) else "<anonymous>"
                body = m.group(2)

                members = self._parse_struct_body(body)

                union_info = CUnionInfo(
                    name=name,
                    line_start=self._find_line(code, m.start()),
                    line_end=self._find_line(code, m.end()),
                    members=members,
                    is_typedef=False
                )
                result.unions.append(union_info)

    def _parse_struct_body(self, body: str) -> list[CStructMember]:
        """解析结构体/联合体体"""
        members = []

        # 简单解析成员声明
        for line in body.split(';'):
            line = line.strip()
            if not line:
                continue

            # 解析位域
            bit_match = re.match(r'(\w+)\s+(\w+)\s*:\s*(\d+)', line)
            if bit_match:
                members.append(CStructMember(
                    name=bit_match.group(2),
                    type=bit_match.group(1),
                    bit_field=int(bit_match.group(3))
                ))
                continue

            # 解析普通成员
            member_match = re.match(r'(?:const\s+|volatile\s+)*(\w+(?:\s*\*)*)\s+(\w+)(?:\s*\[([^\]]*)\])?', line)
            if member_match:
                type_str = member_match.group(1).strip()
                name = member_match.group(2).strip()
                array_size = member_match.group(3)

                members.append(CStructMember(
                    name=name,
                    type=type_str,
                    is_pointer='*' in type_str,
                    is_array=array_size is not None,
                    array_size=array_size.strip() if array_size else None
                ))

        return members

    def _parse_enums(self, code: str, result: CASTResult, lines: list):
        """解析枚举定义"""
        # typedef enum
        te_pattern = self._compiled.get('typedef_enum')
        if te_pattern:
            for m in te_pattern.finditer(code):
                enum_name = m.group(1) if m.group(1) else None
                body = m.group(2)
                typedef_name = m.group(3).strip()

                members = self._parse_enum_body(body)

                enum_info = CEnumInfo(
                    name=enum_name or typedef_name,
                    line_start=self._find_line(code, m.start()),
                    line_end=self._find_line(code, m.end()),
                    members=members,
                    is_typedef=True,
                    typedef_name=typedef_name
                )
                result.enums.append(enum_info)

        # 普通 enum 定义
        e_pattern = self._compiled.get('enum_definition')
        if e_pattern:
            for m in e_pattern.finditer(code):
                name = m.group(1) if m.group(1) else "<anonymous>"
                body = m.group(2)

                members = self._parse_enum_body(body)

                enum_info = CEnumInfo(
                    name=name,
                    line_start=self._find_line(code, m.start()),
                    line_end=self._find_line(code, m.end()),
                    members=members,
                    is_typedef=False
                )
                result.enums.append(enum_info)

    def _parse_enum_body(self, body: str) -> list[CEnumMember]:
        """解析枚举体"""
        members = []
        member_pattern = self._compiled.get('enum_member')

        if not member_pattern:
            # 简单解析
            for item in body.split(','):
                item = item.strip()
                if not item:
                    continue

                if '=' in item:
                    name, value = item.split('=', 1)
                    members.append(CEnumMember(
                        name=name.strip(),
                        value=value.strip()
                    ))
                else:
                    members.append(CEnumMember(name=item))
        else:
            for m in member_pattern.finditer(body):
                name = m.group(1)
                value = m.group(2).strip() if m.group(2) else None
                members.append(CEnumMember(name=name, value=value))

        return members

    # ==================== 函数 ====================

    def _parse_functions(self, code: str, result: CASTResult, lines: list):
        """解析函数声明和定义"""
        # 使用更通用的正则匹配函数
        func_pattern = re.compile(
            r'(?:^|\n)\s*(?:(static|inline|extern)\s+)?'
            r'((?:const\s+|volatile\s+)?(?:unsigned\s+|signed\s+)?\w+(?:\s*\*)*)\s+'
            r'(\w+)\s*'
            r'\(([^)]*)\)\s*'
            r'(;|\{)',
            re.MULTILINE
        )

        for m in func_pattern.finditer(code):
            storage = m.group(1)
            return_type = m.group(2).strip()
            name = m.group(3).strip()
            params_str = m.group(4)
            end_char = m.group(5)

            # 过滤一些误匹配（如 if, while 等）
            if name in C_KEYWORDS:
                continue

            # 解析参数
            parameters = self._parse_parameters(params_str)

            # 检查是否为可变参数
            is_variadic = '...' in params_str

            func_info = CFunctionInfo(
                name=name,
                line_start=self._find_line(code, m.start()),
                line_end=self._find_line(code, m.end()),
                return_type=return_type,
                parameters=parameters,
                storage_class=storage,
                is_declaration=(end_char == ';'),
                is_variadic=is_variadic,
                is_pointer_return='*' in return_type
            )

            result.functions.append(func_info)

        # 解析函数指针
        self._parse_function_pointers(code, result)

    def _parse_function_pointers(self, code: str, result: CASTResult):
        """解析函数指针"""
        fp_pattern = self._compiled.get('function_pointer')
        if not fp_pattern:
            return

        for m in fp_pattern.finditer(code):
            return_type = m.group(1).strip()
            name = m.group(2).strip()
            params_str = m.group(3)

            parameters = self._parse_parameters(params_str)

            result.function_pointers.append(CFunctionPointerInfo(
                name=name,
                return_type=return_type,
                parameters=parameters,
                line=self._find_line(code, m.start())
            ))

    def _parse_parameters(self, params_str: str) -> list[CParameterInfo]:
        """解析参数列表"""
        if not params_str.strip():
            return []

        params = []
        for param in params_str.split(','):
            param = param.strip()
            if not param or param == 'void' or param == '...':
                continue

            # 解析参数类型和名称
            # 格式: type name 或 type *name 或 type name[]
            param_match = re.match(
                r'(?:const\s+|volatile\s+)?'
                r'((?:unsigned\s+|signed\s+)?\w+)'
                r'(\s*\*+)'
                r'?\s+(\w+)'
                r'(?:\s*\[([^\]]*)\])?',
                param
            )

            if param_match:
                type_str = param_match.group(1)
                pointer = param_match.group(2)
                name = param_match.group(3)
                array_size = param_match.group(4)

                full_type = type_str
                is_pointer = False
                if pointer:
                    full_type += pointer.strip()
                    is_pointer = True

                params.append(CParameterInfo(
                    name=name,
                    type=full_type,
                    is_pointer=is_pointer,
                    is_array=array_size is not None,
                    array_size=array_size.strip() if array_size else None
                ))
            else:
                # 简单格式：只有类型
                params.append(CParameterInfo(
                    name="",
                    type=param,
                    is_pointer='*' in param
                ))

        return params

    # ==================== 变量 ====================

    def _parse_global_variables(self, code: str, result: CASTResult, lines: list):
        """解析全局变量"""
        # 使用更精确的正则
        var_pattern = re.compile(
            r'(?:^|\n)\s*(?:(extern|static|const|volatile)\s+)*'
            r'((?:unsigned\s+|signed\s+)?\w+(?:\s*\*)*)\s+'
            r'(\w+)'
            r'(?:\s*\[([^\]]*)\])?'
            r'(?:\s*=\s*([^;]+))?'
            r'\s*;',
            re.MULTILINE
        )

        # 跟踪大括号深度，只提取全局变量
        brace_depth = 0
        code_lines = code.split('\n')

        for m in var_pattern.finditer(code):
            # 检查是否在函数内部
            pos = m.start()
            depth_before = code[:pos].count('{') - code[:pos].count('}')

            if depth_before > 0:
                continue  # 在函数内部，跳过

            storage = m.group(1)
            type_str = m.group(2).strip()
            name = m.group(3).strip()
            array_size = m.group(4)
            initializer = m.group(5)

            # 过滤函数声明误匹配
            if '(' in m.group(0) or ')' in m.group(0):
                continue

            result.global_variables.append(CVariableInfo(
                name=name,
                type=type_str,
                line=self._find_line(code, m.start()),
                storage_class=storage,
                is_const='const' in m.group(0).split(name)[0],
                is_volatile='volatile' in m.group(0).split(name)[0],
                is_pointer='*' in type_str,
                pointer_level=type_str.count('*'),
                is_array=array_size is not None,
                array_size=array_size.strip() if array_size else None,
                initializer=initializer.strip() if initializer else None,
                is_global=True
            ))

    # ==================== 辅助方法 ====================

    def _find_line(self, code: str, pos: int) -> int:
        """根据位置找到行号"""
        return code[:pos].count('\n') + 1
