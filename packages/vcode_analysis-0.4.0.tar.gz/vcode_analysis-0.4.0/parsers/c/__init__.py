"""C 语言解析器子模块

提供双模式解析能力：
- 快速模式：正则表达式解析，无外部依赖，容错性好
- 精确模式：pycparser AST 解析，完整语法信息
"""

from .models import (
    # 基础类型
    CFunctionInfo,
    CVariableInfo,
    CStructInfo,
    CUnionInfo,
    CEnumInfo,
    CTypedefInfo,
    CMacroInfo,
    CIncludeInfo,
    CASTResult,
    # 扩展类型
    CFunctionPointerInfo,
    CArrayInfo,
    CPointerInfo,
)

from .regex_parser import CRegexParser
from .patterns import C_PATTERNS

# 尝试导入 AST 解析器
try:
    from .ast_parser import CPycparserParser
    AST_PARSER_AVAILABLE = True
except ImportError:
    CPycparserParser = None
    AST_PARSER_AVAILABLE = False

__all__ = [
    # 基础类型
    "CFunctionInfo",
    "CVariableInfo",
    "CStructInfo",
    "CUnionInfo",
    "CEnumInfo",
    "CTypedefInfo",
    "CMacroInfo",
    "CIncludeInfo",
    "CASTResult",
    # 扩展类型
    "CFunctionPointerInfo",
    "CArrayInfo",
    "CPointerInfo",
    # 解析器
    "CRegexParser",
    "CPycparserParser",
    "AST_PARSER_AVAILABLE",
    # 其他
    "C_PATTERNS",
]
