"""C 语言解析器测试"""

import pytest
from parsers import (
    CASTParser,
    CParserConfig,
    CRegexParser,
    analyze_c_code,
    C_PARSER_AVAILABLE,
)


# 测试用 C 代码
SIMPLE_C_CODE = """
#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100
#define MIN(a, b) ((a) < (b) ? (a) : (b))

/* 全局变量 */
static int global_counter = 0;
extern int external_var;

/* 函数声明 */
int add(int a, int b);
void print_message(const char *msg);

/* 函数定义 */
int add(int a, int b) {
    return a + b;
}

void print_message(const char *msg) {
    printf("%s\\n", msg);
}

int main(int argc, char *argv[]) {
    int result = add(1, 2);
    print_message("Hello, World!");
    return 0;
}
"""

STRUCT_UNION_CODE = """
/* 结构体定义 */
struct Point {
    int x;
    int y;
};

/* 结构体 typedef */
typedef struct {
    char name[50];
    int age;
} Person;

/* 联合体定义 */
union Data {
    int i;
    float f;
    char str[20];
};

/* 嵌套结构体 */
struct Rectangle {
    struct Point top_left;
    struct Point bottom_right;
    unsigned int color : 24;
};

/* 不透明指针模式 */
typedef struct Context Context;
"""

ENUM_TYPEDEF_CODE = """
/* 枚举定义 */
enum Color {
    RED,
    GREEN,
    BLUE
};

/* 枚举 typedef */
typedef enum {
    STATUS_OK = 0,
    STATUS_ERROR = -1,
    STATUS_PENDING = 1
} Status;

/* 基本类型 typedef */
typedef unsigned long size_t;
typedef int (*Comparator)(const void *, const void *);

/* 函数指针 typedef */
typedef void (*Callback)(int event, void *data);
"""

POINTER_ARRAY_CODE = """
/* 指针变量 */
int *ptr;
char **str_array;
const char *const_string;

/* 数组 */
int numbers[10];
char buffer[256];

/* 函数指针 */
int (*operation)(int, int);

/* 数组指针和指针数组 */
int (*array_ptr)[10];   /* 指向数组的指针 */
int *pointer_array[10]; /* 指针数组 */
"""

COMPLEX_DECLARATIONS = """
/* 复杂声明 */
int *func1(int x);                    /* 返回指针的函数 */
int (*func2)(int x);                  /* 函数指针 */
int (*func3(int x))(int);             /* 返回函数指针的函数 */
int (*(*func4)(int))(int);            /* 指向返回函数指针的函数的指针 */

/* 数组和指针组合 */
int (*array_of_func_ptrs[5])(int);    /* 函数指针数组 */
"""

HEADER_FILE = """
#ifndef MYHEADER_H
#define MYHEADER_H

#ifdef __cplusplus
extern "C" {
#endif

/* 类型定义 */
typedef struct Node Node;

/* 函数声明 */
Node* create_node(int value);
void destroy_node(Node *node);
int get_value(const Node *node);

#ifdef __cplusplus
}
#endif

#endif /* MYHEADER_H */
"""


class TestCRegexParser:
    """正则解析器测试"""

    @pytest.fixture
    def parser(self):
        return CRegexParser()

    def test_parse_includes(self, parser):
        """测试解析 #include"""
        result = parser.parse_code(SIMPLE_C_CODE)

        assert result.success
        assert len(result.includes) == 2

        system_includes = [i for i in result.includes if i.is_system]
        assert len(system_includes) == 2
        assert any(i.path == "stdio.h" for i in system_includes)

    def test_parse_macros(self, parser):
        """测试解析 #define"""
        result = parser.parse_code(SIMPLE_C_CODE)

        assert result.success
        assert len(result.macros) == 2

        # 对象式宏
        obj_macros = [m for m in result.macros if not m.is_function_like]
        assert len(obj_macros) == 1
        assert obj_macros[0].name == "MAX_SIZE"

        # 函数式宏
        func_macros = [m for m in result.macros if m.is_function_like]
        assert len(func_macros) == 1
        assert func_macros[0].name == "MIN"
        assert len(func_macros[0].parameters) == 2

    def test_parse_functions(self, parser):
        """测试解析函数"""
        result = parser.parse_code(SIMPLE_C_CODE)

        assert result.success
        assert len(result.functions) >= 4

        # 查找 add 函数
        add_func = next((f for f in result.functions if f.name == "add"), None)
        assert add_func is not None
        assert add_func.return_type == "int"
        assert len(add_func.parameters) == 2

    def test_parse_global_variables(self, parser):
        """测试解析全局变量"""
        result = parser.parse_code(SIMPLE_C_CODE)

        assert result.success
        assert len(result.global_variables) >= 1

        counter = next((v for v in result.global_variables if v.name == "global_counter"), None)
        assert counter is not None
        assert counter.storage_class == "static"
        assert counter.initializer == "0"

    def test_parse_structs(self, parser):
        """测试解析结构体"""
        result = parser.parse_code(STRUCT_UNION_CODE)

        assert result.success
        assert len(result.structs) >= 3

        # 普通 struct
        point = next((s for s in result.structs if s.name == "Point"), None)
        assert point is not None
        assert len(point.members) == 2

        # typedef struct
        person = next((s for s in result.structs if s.typedef_name == "Person"), None)
        assert person is not None
        assert person.is_typedef

    def test_parse_unions(self, parser):
        """测试解析联合体"""
        result = parser.parse_code(STRUCT_UNION_CODE)

        assert result.success
        assert len(result.unions) >= 1

        data = next((u for u in result.unions if u.name == "Data"), None)
        assert data is not None
        assert len(data.members) == 3

    def test_parse_enums(self, parser):
        """测试解析枚举"""
        result = parser.parse_code(ENUM_TYPEDEF_CODE)

        assert result.success
        assert len(result.enums) >= 2

        # 普通 enum
        color = next((e for e in result.enums if e.name == "Color"), None)
        assert color is not None
        assert len(color.members) == 3

        # typedef enum
        status = next((e for e in result.enums if e.typedef_name == "Status"), None)
        assert status is not None
        assert status.is_typedef

    def test_parse_typedefs(self, parser):
        """测试解析 typedef"""
        result = parser.parse_code(ENUM_TYPEDEF_CODE)

        assert result.success
        assert len(result.typedefs) >= 2

        # 基本类型 typedef
        size_t = next((t for t in result.typedefs if t.name == "size_t"), None)
        assert size_t is not None
        assert "unsigned long" in size_t.original_type

    def test_parse_pointers(self, parser):
        """测试解析指针"""
        result = parser.parse_code(POINTER_ARRAY_CODE)

        assert result.success

        # 检查全局变量中的指针
        ptr_vars = [v for v in result.global_variables if v.is_pointer]
        assert len(ptr_vars) >= 2


class TestCASTParser:
    """双模式解析器测试"""

    @pytest.fixture
    def parser(self):
        return CASTParser()

    def test_fast_mode(self, parser):
        """测试快速模式"""
        result = parser.parse_code(SIMPLE_C_CODE, mode='fast')

        assert result.success
        assert result.parse_mode == 'fast'

    def test_auto_mode(self, parser):
        """测试自动模式"""
        result = parser.parse_code(SIMPLE_C_CODE, mode='auto')

        assert result.success
        assert result.parse_mode in ('fast', 'precise')

    def test_parser_info(self, parser):
        """测试解析器信息"""
        info = parser.get_parser_info()

        assert 'default_mode' in info
        assert 'auto_threshold_lines' in info
        assert 'pycparser_available' in info

    def test_convenience_functions(self):
        """测试便捷函数"""
        result = analyze_c_code(SIMPLE_C_CODE)

        assert result.success
        assert len(result.includes) >= 1


class TestCParserConfig:
    """解析器配置测试"""

    def test_default_config(self):
        """测试默认配置"""
        config = CParserConfig()

        assert config.default_mode == 'auto'
        assert config.auto_threshold_lines == 1000

    def test_custom_config(self):
        """测试自定义配置"""
        config = CParserConfig(
            default_mode='fast',
            auto_threshold_lines=500,
            prefer_precise=False
        )

        assert config.default_mode == 'fast'
        assert config.auto_threshold_lines == 500
        assert config.prefer_precise == False


class TestHeaderFile:
    """头文件测试"""

    @pytest.fixture
    def parser(self):
        return CRegexParser()

    def test_parse_header_guards(self, parser):
        """测试解析头文件保护"""
        result = parser.parse_code(HEADER_FILE)

        assert result.success

        # 检查宏定义
        ifndef_macros = [m for m in result.macros if 'ifndef' in m.name.lower() or m.name.startswith('_')]
        assert len(result.macros) >= 1

    def test_parse_extern_c(self, parser):
        """测试解析 extern \"C\""""
        result = parser.parse_code(HEADER_FILE)

        assert result.success


# 如果需要运行测试
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
