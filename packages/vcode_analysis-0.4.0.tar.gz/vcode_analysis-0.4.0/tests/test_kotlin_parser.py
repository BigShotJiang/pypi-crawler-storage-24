"""Kotlin 解析器测试"""

import pytest
from parsers import (
    KotlinASTParser,
    KotlinParserConfig,
    KotlinRegexParser,
    analyze_kotlin_code,
    KOTLIN_PARSER_AVAILABLE,
)


# 测试用 Kotlin 代码
SIMPLE_KOTLIN_CODE = """
package com.example

import kotlin.collections.List
import kotlinx.coroutines.flow.Flow

class SimpleClass {
    val name: String = "test"
    var count: Int = 0

    fun greet(): String {
        return "Hello, $name"
    }
}
"""

SEALED_CLASS_CODE = """
package com.example

sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val message: String) : Result<Nothing>()
    object Loading : Result<Nothing>()
}

fun <T> handleResult(result: Result<T>): String {
    return when (result) {
        is Result.Success -> "Success: ${result.data}"
        is Result.Error -> "Error: ${result.message}"
        Result.Loading -> "Loading..."
    }
}
"""

DATA_CLASS_CODE = """
package com.example

data class User(
    val id: Int,
    val name: String,
    val email: String? = null
) {
    fun displayName(): String = name
}
"""

ENUM_CLASS_CODE = """
package com.example

enum class Status {
    ACTIVE,
    INACTIVE,
    PENDING
}

enum class Priority(val level: Int) {
    LOW(1),
    MEDIUM(2),
    HIGH(3)
}
"""

COROUTINE_CODE = """
package com.example

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class CoroutineExample {
    suspend fun fetchData(): String {
        return withContext(Dispatchers.IO) {
            "data"
        }
    }

    fun observeData(): Flow<String> = flow {
        emit("item1")
        emit("item2")
    }

    fun processFlow() {
        observeData()
            .map { it.uppercase() }
            .filter { it.isNotEmpty() }
            .collect { println(it) }
    }
}
"""

DELEGATE_PROPERTY_CODE = """
package com.example

import kotlin.properties.Delegates

class DelegateExample {
    val lazyValue: String by lazy {
        "computed"
    }

    var observedValue: String by Delegates.observable("<initial>") { property, oldValue, newValue ->
        println("$oldValue -> $newValue")
    }

    var vetoableValue: Int by Delegates.vetoable(0) { _, old, new ->
        new > old
    }
}
"""

EXTENSION_FUNCTION_CODE = """
package com.example

fun String.isEmail(): Boolean {
    return this.contains("@")
}

fun List<Int>.sumOfEven(): Int {
    return this.filter { it % 2 == 0 }.sum()
}

val String.wordCount: Int
    get() = this.split(" ").size
"""

TYPE_ALIAS_CODE = """
package com.example

typealias StringMap = Map<String, String>
typealias Predicate<T> = (T) -> Boolean
typealias UserCallback = (User) -> Unit
"""

VALUE_CLASS_CODE = """
package com.example

@JvmInline
value class UserId(val value: Long)

value class Email(val address: String)
"""


class TestKotlinRegexParser:
    """正则解析器测试"""

    @pytest.fixture
    def parser(self):
        return KotlinRegexParser()

    def test_parse_simple_class(self, parser):
        """测试解析简单类"""
        result = parser.parse_code(SIMPLE_KOTLIN_CODE)

        assert result.success
        assert result.package == "com.example"
        assert len(result.imports) == 2
        assert len(result.classes) == 1

        cls = result.classes[0]
        assert cls.name == "SimpleClass"
        assert len(cls.properties) == 2
        assert len(cls.functions) == 1

    def test_parse_sealed_class(self, parser):
        """测试解析 sealed 类"""
        result = parser.parse_code(SEALED_CLASS_CODE)

        assert result.success
        assert len(result.sealed_classes) == 1

        sealed = result.sealed_classes[0]
        assert sealed.name == "Result"
        assert sealed.is_sealed

    def test_parse_data_class(self, parser):
        """测试解析数据类"""
        result = parser.parse_code(DATA_CLASS_CODE)

        assert result.success
        assert len(result.data_classes) == 1

        data = result.data_classes[0]
        assert data.name == "User"
        assert len(data.primary_constructor_params) == 3
        assert len(data.component_functions) == 3

    def test_parse_enum_class(self, parser):
        """测试解析枚举类"""
        result = parser.parse_code(ENUM_CLASS_CODE)

        assert result.success
        assert len(result.enum_classes) >= 1

        enum = result.enum_classes[0]
        assert enum.name == "Status"

    def test_parse_coroutines(self, parser):
        """测试解析协程"""
        result = parser.parse_code(COROUTINE_CODE)

        assert result.success
        assert len(result.coroutines) >= 1

        # 检查 suspend 函数
        suspend_funcs = [c for c in result.coroutines if c.is_suspend]
        assert len(suspend_funcs) >= 1

        # 检查 Flow 操作符
        assert len(result.flow_operators) >= 1
        terminal_ops = [op for op in result.flow_operators if op.is_terminal]
        assert len(terminal_ops) >= 1

    def test_parse_delegated_properties(self, parser):
        """测试解析委托属性"""
        result = parser.parse_code(DELEGATE_PROPERTY_CODE)

        assert result.success
        assert len(result.delegated_properties) >= 2

        lazy_props = [p for p in result.delegated_properties if p.delegate_type == 'lazy']
        assert len(lazy_props) >= 1

    def test_parse_extension_functions(self, parser):
        """测试解析扩展函数"""
        result = parser.parse_code(EXTENSION_FUNCTION_CODE)

        assert result.success
        assert len(result.extension_functions) >= 1

        ext = result.extension_functions[0]
        assert ext.receiver_type == "String"
        assert ext.name == "isEmail"

    def test_parse_type_aliases(self, parser):
        """测试解析类型别名"""
        result = parser.parse_code(TYPE_ALIAS_CODE)

        assert result.success
        assert len(result.type_aliases) >= 2

        alias = result.type_aliases[0]
        assert alias.name == "StringMap"

    def test_parse_value_classes(self, parser):
        """测试解析值类"""
        result = parser.parse_code(VALUE_CLASS_CODE)

        assert result.success
        assert len(result.value_classes) >= 1


class TestKotlinASTParser:
    """双模式解析器测试"""

    @pytest.fixture
    def parser(self):
        return KotlinASTParser()

    def test_fast_mode(self, parser):
        """测试快速模式"""
        result = parser.parse_code(SIMPLE_KOTLIN_CODE, mode='fast')

        assert result.success
        assert result.parse_mode == 'fast'

    def test_auto_mode_small_file(self, parser):
        """测试自动模式 - 小文件"""
        result = parser.parse_code(SIMPLE_KOTLIN_CODE, mode='auto')

        assert result.success
        # 小文件应该使用精确模式（如果可用）或快速模式
        assert result.parse_mode in ('fast', 'precise')

    def test_parser_info(self, parser):
        """测试解析器信息"""
        info = parser.get_parser_info()

        assert 'default_mode' in info
        assert 'auto_threshold_lines' in info

    def test_convenience_functions(self):
        """测试便捷函数"""
        result = analyze_kotlin_code(SIMPLE_KOTLIN_CODE)

        assert result.success
        assert result.package == "com.example"


class TestKotlinParserConfig:
    """解析器配置测试"""

    def test_default_config(self):
        """测试默认配置"""
        config = KotlinParserConfig()

        assert config.default_mode == 'auto'
        assert config.auto_threshold_lines == 500

    def test_custom_config(self):
        """测试自定义配置"""
        config = KotlinParserConfig(
            default_mode='fast',
            auto_threshold_lines=1000,
            prefer_precise=False
        )

        assert config.default_mode == 'fast'
        assert config.auto_threshold_lines == 1000
        assert config.prefer_precise == False


# 如果需要运行测试
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
