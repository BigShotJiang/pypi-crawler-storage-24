"""安全规则测试

测试新增的安全规则是否正确检测到漏洞。
"""

import pytest
from analyzers.security import SecurityAnalyzer, SecurityIssue, SECURITY_RULES


class TestSecurityRules:
    """安全规则测试类"""

    def test_c_buffer_overflow_gets(self):
        """测试 C 语言 gets() 缓冲区溢出检测"""
        code = '''
#include <stdio.h>
int main() {
    char buffer[100];
    gets(buffer);  // 危险函数
    return 0;
}
'''
        issues = self._scan_code(code, "C")
        assert any(i["id"] == "buffer_overflow_gets" for i in issues), \
            "应检测到 gets() 缓冲区溢出风险"

    def test_c_buffer_overflow_strcpy(self):
        """测试 C 语言 strcpy() 缓冲区溢出检测"""
        code = '''
#include <string.h>
void copy_string(char* dest, char* src) {
    strcpy(dest, src);  // 危险函数
}
'''
        issues = self._scan_code(code, "C")
        assert any(i["id"] == "buffer_overflow_strcpy" for i in issues), \
            "应检测到 strcpy() 缓冲区溢出风险"

    def test_c_format_string(self):
        """测试 C 语言格式化字符串漏洞检测"""
        code = '''
#include <stdio.h>
void print_user_input(char* input) {
    printf(input);  // 格式化字符串漏洞
}
'''
        issues = self._scan_code(code, "C")
        assert any(i["id"] == "format_string" for i in issues), \
            "应检测到格式化字符串漏洞"

    def test_c_dangerous_system(self):
        """测试 C 语言 system() 命令注入检测"""
        code = '''
#include <stdlib.h>
void execute_command(char* cmd) {
    system(cmd);  // 命令注入风险
}
'''
        issues = self._scan_code(code, "C")
        assert any(i["id"] == "dangerous_system" for i in issues), \
            "应检测到 system() 命令注入风险"

    def test_cpp_inherits_c_rules(self):
        """测试 C++ 继承 C 规则"""
        code = '''
#include <cstdio>
void func() {
    char buf[100];
    gets(buf);  // 危险函数，应被 C++ 继承的规则检测
}
'''
        issues = self._scan_code(code, "C++")
        assert any(i["id"] == "buffer_overflow_gets" for i in issues), \
            "C++ 应继承 C 的 gets() 检测规则"

    def test_cpp_raw_pointer_delete(self):
        """测试 C++ 手动 delete 检测"""
        code = '''
void func() {
    int* ptr = new int(10);
    delete ptr;  // 应使用智能指针
}
'''
        issues = self._scan_code(code, "C++")
        assert any(i["id"] == "raw_pointer_delete" for i in issues), \
            "应检测到手动 delete 裸指针"

    def test_python_hardcoded_password(self):
        """测试 Python 硬编码密码检测"""
        code = '''
# 配置
password = "my_secret_password123"
db.connect(user="admin", password=password)
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "hardcoded_password" for i in issues), \
            "应检测到硬编码密码"

    def test_python_hardcoded_ip(self):
        """测试 Python 硬编码 IP 检测"""
        code = '''
# 数据库配置
DB_HOST = "192.168.1.100"
db.connect(host=DB_HOST)
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "hardcoded_ip" for i in issues), \
            "应检测到硬编码 IP 地址"

    def test_python_hardcoded_connection_string(self):
        """测试 Python 硬编码连接字符串检测"""
        code = '''
# 数据库连接
conn_str = "mysql://admin:password123@localhost:3306/mydb"
engine.connect(conn_str)
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "hardcoded_connection_string" for i in issues), \
            "应检测到硬编码数据库连接字符串"

    def test_python_hardcoded_aws_key(self):
        """测试 Python 硬编码 AWS 密钥检测"""
        code = '''
# AWS 配置
AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"
s3_client.connect(key=AWS_ACCESS_KEY)
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "hardcoded_aws_key" for i in issues), \
            "应检测到硬编码 AWS 访问密钥"

    def test_python_hardcoded_github_token(self):
        """测试 Python 硬编码 GitHub Token 检测"""
        code = '''
# GitHub 配置
GITHUB_TOKEN = "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
github.auth(token=GITHUB_TOKEN)
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "hardcoded_github_token" for i in issues), \
            "应检测到硬编码 GitHub Token"

    def test_python_path_traversal(self):
        """测试 Python 路径遍历检测"""
        code = '''
import os
def read_user_file(filename):
    path = os.path.join("/data", filename)
    with open(path) as f:  # 路径遍历风险
        return f.read()
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "path_traversal" for i in issues), \
            "应检测到路径遍历风险"

    def test_python_weak_crypto(self):
        """测试 Python 弱加密检测"""
        code = '''
import hashlib
def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()  # 弱加密
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "weak_crypto_hash" for i in issues), \
            "应检测到弱加密算法 MD5"

    def test_python_insecure_random(self):
        """测试 Python 不安全随机数检测"""
        code = '''
import random
def generate_token():
    return random.randint(100000, 999999)  # 不安全随机数
'''
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "insecure_random" for i in issues), \
            "应检测到不安全随机数"

    def test_javascript_hardcoded_ip(self):
        """测试 JavaScript 硬编码 IP 检测"""
        code = '''
// API 配置
const API_HOST = "10.0.0.50";
fetch(`http://${API_HOST}/api/data`);
'''
        issues = self._scan_code(code, "JavaScript")
        assert any(i["id"] == "hardcoded_ip" for i in issues), \
            "应检测到硬编码 IP 地址"

    def test_javascript_path_traversal(self):
        """测试 JavaScript 路径遍历检测"""
        code = '''
const fs = require('fs');
function readFile(userInput) {
    return fs.readFile('/data/' + userInput, 'utf8');  // 路径遍历
}
'''
        issues = self._scan_code(code, "JavaScript")
        assert any(i["id"] == "path_traversal" for i in issues), \
            "应检测到路径遍历风险"

    def test_javascript_ssrf_potential(self):
        """测试 JavaScript 潜在 SSRF 检测"""
        code = '''
async function fetchUrl(userUrl) {
    const response = await fetch(userUrl);  // 潜在 SSRF
    return response.json();
}
'''
        issues = self._scan_code(code, "JavaScript")
        assert any(i["id"] == "ssrf_potential" for i in issues), \
            "应检测到潜在 SSRF 风险"

    def test_typescript_inherits_javascript_rules(self):
        """测试 TypeScript 继承 JavaScript 规则"""
        code = '''
const API_HOST = "172.16.0.1";
fetch(`http://${API_HOST}/api`);
'''
        issues = self._scan_code(code, "TypeScript")
        assert any(i["id"] == "hardcoded_ip" for i in issues), \
            "TypeScript 应继承 JavaScript 的 IP 检测规则"

    def test_private_key_detection(self):
        """测试私钥检测（所有语言）"""
        code = '''
private_key = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF5TkDkLQ...
-----END RSA PRIVATE KEY-----"""
'''
        # 测试 Python
        issues = self._scan_code(code, "Python")
        assert any(i["id"] == "hardcoded_private_key" for i in issues), \
            "Python 应检测到硬编码私钥"

    def _scan_code(self, code: str, language: str) -> list[dict]:
        """辅助方法：扫描代码并返回问题列表"""
        # 创建一个临时的 SecurityAnalyzer 实例
        analyzer = SecurityAnalyzer.__new__(SecurityAnalyzer)
        return analyzer._scan_patterns(code, language)


class TestRuleInheritance:
    """规则继承测试"""

    def test_typescript_inherits_javascript(self):
        """验证 TypeScript 继承 JavaScript 规则"""
        analyzer = SecurityAnalyzer.__new__(SecurityAnalyzer)

        js_rules = SECURITY_RULES.get("JavaScript", [])
        ts_rules = analyzer._get_rules_for_language("TypeScript")

        # TypeScript 应该包含所有 JavaScript 规则
        js_rule_ids = {r["id"] for r in js_rules}
        ts_rule_ids = {r["id"] for r in ts_rules}

        assert js_rule_ids.issubset(ts_rule_ids), \
            "TypeScript 应包含所有 JavaScript 规则"

    def test_cpp_inherits_c(self):
        """验证 C++ 继承 C 规则"""
        analyzer = SecurityAnalyzer.__new__(SecurityAnalyzer)

        c_rules = SECURITY_RULES.get("C", [])
        cpp_rules = analyzer._get_rules_for_language("C++")

        # C++ 应该包含所有 C 规则
        c_rule_ids = {r["id"] for r in c_rules}
        cpp_rule_ids = {r["id"] for r in cpp_rules}

        assert c_rule_ids.issubset(cpp_rule_ids), \
            "C++ 应包含所有 C 规则"


class TestRuleCoverage:
    """规则覆盖测试"""

    def test_all_rules_have_required_fields(self):
        """验证所有规则都有必需字段"""
        required_fields = ["id", "pattern", "severity", "description", "recommendation"]
        valid_severities = {"critical", "high", "medium", "low"}

        for language, rules in SECURITY_RULES.items():
            for rule in rules:
                for field in required_fields:
                    assert field in rule, \
                        f"规则 {rule.get('id', 'unknown')} 缺少字段 {field}"

                assert rule["severity"] in valid_severities, \
                    f"规则 {rule['id']} 的严重性 {rule['severity']} 无效"

    def test_c_rules_count(self):
        """验证 C 规则数量"""
        c_rules = SECURITY_RULES.get("C", [])
        assert len(c_rules) >= 15, \
            f"C 规则应有至少 15 条，实际 {len(c_rules)} 条"

    def test_python_rules_count(self):
        """验证 Python 规则数量（新增后）"""
        python_rules = SECURITY_RULES.get("Python", [])
        assert len(python_rules) >= 15, \
            f"Python 规则应有至少 15 条，实际 {len(python_rules)} 条"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
