"""批量 Git 操作和目录分析测试"""

import pytest
import tempfile
import os
from pathlib import Path

from core import GitHandler, BatchGitHandler, RepoStatus
from analyzers import DirectoryAnalyzer


class TestGitHandler:
    """GitHandler 测试"""

    def test_is_valid_repo(self):
        """测试仓库有效性检查"""
        # 当前目录应该是一个 git 仓库
        handler = GitHandler(".")
        assert handler.is_valid_repo()

    def test_get_current_branch(self):
        """测试获取当前分支"""
        handler = GitHandler(".")
        branch = handler.get_current_branch()
        assert branch  # 应该返回一个分支名

    def test_status(self):
        """测试获取状态"""
        handler = GitHandler(".")
        status = handler.status()

        assert "branch" in status
        assert "staged" in status
        assert "unstaged" in status
        assert "untracked" in status
        assert "is_clean" in status

    def test_get_remote_url(self):
        """测试获取远程 URL"""
        handler = GitHandler(".")
        url = handler.get_remote_url()
        # URL 可能为 None（没有配置远程）
        if url:
            assert "git" in url or "http" in url


class TestBatchGitHandler:
    """BatchGitHandler 测试"""

    @pytest.fixture
    def temp_dir(self):
        """创建临时目录"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir

    def test_discover_repos(self, temp_dir):
        """测试仓库发现"""
        handler = BatchGitHandler(temp_dir)

        # 空目录应该没有仓库
        repos = handler.discover_repos()
        assert repos == []

    def test_get_all_repos_info(self, temp_dir):
        """测试获取所有仓库信息"""
        handler = BatchGitHandler(temp_dir)

        # 空目录
        infos = handler.get_all_repos_info()
        assert infos == []


class TestDirectoryAnalyzer:
    """DirectoryAnalyzer 测试"""

    @pytest.fixture
    def analyzer(self):
        return DirectoryAnalyzer()

    @pytest.fixture
    def temp_project(self):
        """创建临时项目结构"""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "test_project"
            project_dir.mkdir()

            # 创建 Python 文件
            (project_dir / "main.py").write_text("print('hello')\n")
            (project_dir / "utils.py").write_text("def helper(): pass\n")

            # 创建配置文件
            (project_dir / "requirements.txt").write_text("requests>=2.0\n")

            # 创建子目录
            src_dir = project_dir / "src"
            src_dir.mkdir()
            (src_dir / "__init__.py").write_text("")
            (src_dir / "app.py").write_text("# app")

            yield str(project_dir)

    def test_analyze_directory(self, analyzer, temp_project):
        """测试目录分析"""
        result = analyzer.analyze(temp_project)

        assert result.base_path == temp_project
        assert result.total_files >= 4  # 至少 4 个文件
        assert result.total_dirs >= 1   # 至少 src 目录

    def test_detect_project_type(self, analyzer, temp_project):
        """测试项目类型检测"""
        result = analyzer.analyze(temp_project)

        assert len(result.projects) >= 1
        # 应该检测为 Python 项目
        assert result.projects[0].project_type.value == "Python"

    def test_analyze_languages(self, analyzer, temp_project):
        """测试语言分析"""
        result = analyzer.analyze(temp_project)

        if result.projects:
            languages = result.projects[0].languages
            assert "Python" in languages

    def test_file_extensions(self, analyzer, temp_project):
        """测试文件扩展名统计"""
        result = analyzer.analyze(temp_project)

        assert ".py" in result.file_extensions
        assert result.file_extensions[".py"] >= 4

    def test_generate_report(self, analyzer, temp_project):
        """测试报告生成"""
        result = analyzer.analyze(temp_project)
        report = analyzer.generate_report(result)

        assert "# 目录结构分析报告" in report
        assert temp_project in report


class TestProjectTypeDetection:
    """项目类型检测测试"""

    @pytest.fixture
    def analyzer(self):
        return DirectoryAnalyzer()

    def test_detect_python_project(self, analyzer):
        """测试 Python 项目检测"""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "py_project"
            project_dir.mkdir()

            (project_dir / "main.py").write_text("")
            (project_dir / "requirements.txt").write_text("")

            result = analyzer.analyze(str(project_dir))

            assert result.projects[0].project_type.value == "Python"

    def test_detect_nodejs_project(self, analyzer):
        """测试 Node.js 项目检测"""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "node_project"
            project_dir.mkdir()

            (project_dir / "package.json").write_text('{"name": "test"}')
            (project_dir / "index.js").write_text("")

            result = analyzer.analyze(str(project_dir))

            assert result.projects[0].project_type.value == "Node.js"

    def test_detect_java_project(self, analyzer):
        """测试 Java 项目检测"""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "java_project"
            project_dir.mkdir()

            (project_dir / "pom.xml").write_text("<project></project>")
            src_dir = project_dir / "src" / "main" / "java"
            src_dir.mkdir(parents=True)
            (src_dir / "Main.java").write_text("public class Main {}")

            result = analyzer.analyze(str(project_dir))

            assert result.projects[0].project_type.value == "Java"


# 如果需要运行测试
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
