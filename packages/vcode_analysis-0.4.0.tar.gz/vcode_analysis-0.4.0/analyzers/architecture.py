"""架构分析器

分析项目结构、依赖关系、模块耦合度
"""

from dataclasses import dataclass, field
from typing import Optional
from collections import defaultdict
import re
from pathlib import Path

from core.analyzer import Analyzer, FileInfo, AnalysisResult

# Python AST 解析器（可选依赖）
try:
    from parsers.python_parser import PythonASTParser
    PYTHON_AST_AVAILABLE = True
except ImportError:
    PYTHON_AST_AVAILABLE = False

# JavaScript AST 解析器（可选依赖）
try:
    from parsers.javascript_parser import JavaScriptASTParser
    JS_AST_AVAILABLE = True
except ImportError:
    JS_AST_AVAILABLE = False

# TypeScript AST 解析器（可选依赖）
try:
    from parsers.typescript_parser import TypeScriptASTParser
    TS_AST_AVAILABLE = True
except ImportError:
    TS_AST_AVAILABLE = False

# Java AST 解析器（可选依赖）
try:
    from parsers.java_parser import JavaASTParser
    JAVA_AST_AVAILABLE = True
except ImportError:
    JAVA_AST_AVAILABLE = False

# Kotlin AST 解析器（可选依赖）
try:
    from parsers.kotlin_parser import KotlinASTParser
    KOTLIN_AST_AVAILABLE = True
except ImportError:
    KOTLIN_AST_AVAILABLE = False

# C AST 解析器（可选依赖）
try:
    from parsers.c_parser import CASTParser
    C_AST_AVAILABLE = True
except ImportError:
    C_AST_AVAILABLE = False


@dataclass
class DependencyInfo:
    """依赖信息"""
    source: str
    target: str
    import_type: str  # import, from_import, require, include


@dataclass
class ModuleInfo:
    """模块信息"""
    path: str
    language: str
    imports: list[str]
    exports: list[str]
    lines: int
    classes: int
    functions: int


@dataclass
class ArchitectureResult:
    """架构分析结果"""
    total_files: int
    total_lines: int
    languages: dict[str, int]
    modules: list[ModuleInfo]
    dependencies: list[DependencyInfo]
    circular_dependencies: list[tuple[str, str]]
    coupling_score: float  # 0-100, 越低越好
    cohesion_score: float  # 0-100, 越高越好
    summary: str
    suggestions: list[str]


# 架构分析提示词
ARCH_ANALYSIS_PROMPT = """分析以下项目的架构信息并提供改进建议:

项目统计:
- 文件数: {total_files}
- 代码行数: {total_lines}
- 语言分布: {languages}
- 模块数: {modules_count}
- 循环依赖: {circular_deps}

模块列表:
{modules_summary}

请分析项目的架构质量，包括:
1. 模块化程度评价
2. 依赖关系分析
3. 潜在的架构问题
4. 改进建议

以 JSON 格式输出:
{{"summary": "架构评价", "suggestions": ["建议1", "建议2"]}}"""


# 导入语句正则表达式
IMPORT_PATTERNS = {
    "Python": [
        r'^import\s+(\S+)',
        r'^from\s+(\S+)\s+import',
    ],
    "JavaScript": [
        r'^import\s+.*from\s+[\'"]([^\'"]+)[\'"]',
        r'^require\([\'"]([^\'"]+)[\'"]\)',
    ],
    "TypeScript": [
        r'^import\s+.*from\s+[\'"]([^\'"]+)[\'"]',
        r'^import\s+[\'"]([^\'"]+)[\'"]',
    ],
    "Java": [
        r'^import\s+([\w\.]+);',
    ],
    "Kotlin": [
        r'^import\s+([\w\.]+)',
    ],
    "C": [
        r'^#include\s*<([^>]+)>',
        r'^#include\s*"([^"]+)"',
    ],
    "C++": [
        r'^#include\s*<([^>]+)>',
        r'^#include\s*"([^"]+)"',
    ],
    "Go": [
        r'^import\s+"([^"]+)"',
        r'^import\s+\([^)]*\)',
    ],
    "Rust": [
        r'^use\s+([\w:]+)',
    ],
    "Ruby": [
        r'^require\s+[\'"]([^\'"]+)[\'"]',
        r'^require_relative\s+[\'"]([^\'"]+)[\'"]',
    ],
    "PHP": [
        r'^use\s+([\w\\]+);',
        r'^require(?:_once)?\s+[\'"]([^\'"]+)[\'"]',
    ],
}


class ArchitectureAnalyzer:
    """架构分析器"""

    def __init__(self, analyzer: Analyzer):
        self.analyzer = analyzer
        self.modules: list[ModuleInfo] = []
        self.dependencies: list[DependencyInfo] = []

    def _count_lines(self, content: str) -> int:
        """准确计算代码行数"""
        if not content:
            return 0
        # 如果以换行符结尾，换行符数量就是行数
        # 否则，行数 = 换行符数量 + 1
        if content.endswith('\n'):
            return content.count('\n')
        return content.count('\n') + 1

    def _detect_imports(self, content: str, language: str, file_path: str = "") -> list[str]:
        """检测文件中的导入语句"""
        imports = []

        # Python 文件优先使用 AST 解析器
        if language == "Python" and PYTHON_AST_AVAILABLE and file_path:
            try:
                parser = PythonASTParser()
                result = parser.parse_code(content, file_path)
                if result.success:
                    for imp in result.imports:
                        if imp.is_from and imp.module:
                            imports.append(imp.module)
                        else:
                            imports.extend(imp.names)
                    return imports
            except Exception:
                pass  # 回退到正则表达式

        # JavaScript 文件使用 AST 解析器
        if language == "JavaScript" and JS_AST_AVAILABLE and file_path:
            try:
                parser = JavaScriptASTParser()
                result = parser.parse_code(content, file_path)
                if result.success:
                    for imp in result.imports:
                        imports.append(imp.source)
                    return imports
            except Exception:
                pass  # 回退到正则表达式

        # TypeScript 文件使用 AST 解析器
        if language == "TypeScript" and TS_AST_AVAILABLE and file_path:
            try:
                parser = TypeScriptASTParser()
                result = parser.parse_code(content, file_path)
                if result.success:
                    for imp in result.imports:
                        imports.append(imp.source)
                    return imports
            except Exception:
                pass  # 回退到正则表达式

        # Java 文件使用 AST 解析器
        if language == "Java" and JAVA_AST_AVAILABLE and file_path:
            try:
                parser = JavaASTParser()
                result = parser.parse_code(content, file_path)
                if result.success:
                    for imp in result.imports:
                        imports.append(imp.path)
                    return imports
            except Exception:
                pass  # 回退到正则表达式

        # 其他语言或 AST 解析失败时使用正则表达式
        patterns = IMPORT_PATTERNS.get(language, [])
        for line in content.split('\n'):
            line = line.strip()
            for pattern in patterns:
                match = re.match(pattern, line)
                if match:
                    imports.append(match.group(1))

        return imports

    def _count_structures(self, content: str, language: str, file_path: str = "") -> dict:
        """统计代码结构"""
        result = {"classes": 0, "functions": 0, "docstring_coverage": 0.0, "type_hint_coverage": 0.0}

        # Python 文件优先使用 AST 解析器
        if language == "Python" and PYTHON_AST_AVAILABLE and file_path:
            try:
                parser = PythonASTParser()
                ast_result = parser.parse_code(content, file_path)
                if ast_result.success:
                    result["classes"] = len(ast_result.classes)
                    result["functions"] = len(ast_result.functions)
                    # 统计类中的方法
                    for cls in ast_result.classes:
                        result["functions"] += len(cls.methods)
                    result["docstring_coverage"] = ast_result.docstring_coverage
                    result["type_hint_coverage"] = ast_result.type_hint_coverage
                    return result
            except Exception:
                pass  # 回退到正则表达式

        # JavaScript 文件使用 AST 解析器
        if language == "JavaScript" and JS_AST_AVAILABLE and file_path:
            try:
                parser = JavaScriptASTParser()
                ast_result = parser.parse_code(content, file_path)
                if ast_result.success:
                    result["classes"] = len(ast_result.classes)
                    result["functions"] = len(ast_result.functions)
                    # 统计类中的方法
                    for cls in ast_result.classes:
                        result["functions"] += len(cls.methods)
                    return result
            except Exception:
                pass  # 回退到正则表达式

        # TypeScript 文件使用 AST 解析器
        if language == "TypeScript" and TS_AST_AVAILABLE and file_path:
            try:
                parser = TypeScriptASTParser()
                ast_result = parser.parse_code(content, file_path)
                if ast_result.success:
                    result["classes"] = len(ast_result.classes)
                    result["functions"] = len(ast_result.functions)
                    # 统计类中的方法
                    for cls in ast_result.classes:
                        result["functions"] += len(cls.methods)
                    # 统计 TypeScript 特有结构
                    result["interfaces"] = len(ast_result.interfaces)
                    result["types"] = len(ast_result.types)
                    result["enums"] = len(ast_result.enums)
                    return result
            except Exception:
                pass  # 回退到正则表达式

        # Java 文件使用 AST 解析器
        if language == "Java" and JAVA_AST_AVAILABLE and file_path:
            try:
                parser = JavaASTParser()
                ast_result = parser.parse_code(content, file_path)
                if ast_result.success:
                    result["classes"] = len(ast_result.classes) + len(ast_result.interfaces) + len(ast_result.enums)
                    result["functions"] = 0
                    # 统计类中的方法
                    for cls in ast_result.classes:
                        result["functions"] += len(cls.methods)
                    for iface in ast_result.interfaces:
                        result["functions"] += len(iface.methods)
                    for enum in ast_result.enums:
                        result["functions"] += len(enum.methods)
                    return result
            except Exception:
                pass  # 回退到正则表达式

        # Kotlin 文件使用 AST 解析器
        if language == "Kotlin" and KOTLIN_AST_AVAILABLE and file_path:
            try:
                parser = KotlinASTParser()
                ast_result = parser.parse_code(content, file_path)
                if ast_result.success:
                    result["classes"] = len(ast_result.classes)
                    result["functions"] = len(ast_result.functions)
                    # 统计类中的方法
                    for cls in ast_result.classes:
                        result["functions"] += len(cls.functions)
                    return result
            except Exception:
                pass  # 回退到正则表达式

        # 其他语言或 AST 解析失败时使用正则表达式
        if language == "Python":
            result["classes"] = len(re.findall(r'^class\s+\w+', content, re.MULTILINE))
            result["functions"] = len(re.findall(r'^def\s+\w+', content, re.MULTILINE))
        elif language in ["JavaScript", "TypeScript"]:
            result["classes"] = len(re.findall(r'\bclass\s+\w+', content))
            result["functions"] = len(re.findall(r'\bfunction\s+\w+', content))
        elif language == "Java":
            result["classes"] = len(re.findall(r'\bclass\s+\w+', content))
            result["methods"] = len(re.findall(r'\b(public|private|protected)\s+\w+\s+\w+\s*\(', content))
        elif language == "Kotlin":
            result["classes"] = len(re.findall(r'\bclass\s+\w+', content))
            result["functions"] = len(re.findall(r'\bfun\s+\w+', content))

        return result

    def analyze_file(self, file_info: FileInfo) -> ModuleInfo:
        """分析单个文件"""
        try:
            content = self.analyzer.read_file_content(file_info)
            imports = self._detect_imports(content, file_info.language, file_info.relative_path)
            structures = self._count_structures(content, file_info.language, file_info.relative_path)

            return ModuleInfo(
                path=file_info.relative_path,
                language=file_info.language,
                imports=imports,
                exports=[],  # TODO: 实现导出检测
                lines=self._count_lines(content),
                classes=structures.get("classes", 0),
                functions=structures.get("functions", 0),
            )
        except Exception:
            return ModuleInfo(
                path=file_info.relative_path,
                language=file_info.language,
                imports=[],
                exports=[],
                lines=0,
                classes=0,
                functions=0,
            )

    def _detect_circular_dependencies(self) -> list[tuple[str, str]]:
        """检测循环依赖"""
        # 构建依赖图
        graph = defaultdict(set)
        for dep in self.dependencies:
            graph[dep.source].add(dep.target)

        # 检测环
        circular = []
        visited = set()
        rec_stack = set()

        def dfs(node, path):
            visited.add(node)
            rec_stack.add(node)

            for neighbor in graph[node]:
                if neighbor not in visited:
                    cycle = dfs(neighbor, path + [neighbor])
                    if cycle:
                        return cycle
                elif neighbor in rec_stack:
                    # 找到环
                    return (node, neighbor)

            rec_stack.remove(node)
            return None

        for node in list(graph.keys()):
            if node not in visited:
                cycle = dfs(node, [node])
                if cycle:
                    circular.append(cycle)

        return circular

    def _calculate_coupling(self) -> float:
        """计算耦合度分数 (0-100, 越低越好)"""
        if not self.modules:
            return 0

        # 平均每个模块的依赖数
        total_deps = len(self.dependencies)
        avg_deps = total_deps / len(self.modules)

        # 标准化到 0-100
        # 假设平均依赖 5 个为理想值，超过 20 为高耦合
        if avg_deps <= 5:
            return avg_deps * 10  # 0-50
        else:
            return min(100, 50 + (avg_deps - 5) * 5)

    def _calculate_cohesion(self) -> float:
        """计算内聚度分数 (0-100, 越高越好)"""
        if not self.modules:
            return 100

        # 基于模块的功能集中度
        # 简化计算：如果模块内的类/函数比例合理，则内聚度高
        scores = []
        for module in self.modules:
            if module.lines > 0:
                # 功能密度 = (类数 + 函数数) / 代码行数 * 1000
                density = (module.classes + module.functions) / module.lines * 100
                scores.append(min(100, density * 10))

        return sum(scores) / len(scores) if scores else 100

    def analyze(self, target_path: str) -> ArchitectureResult:
        """分析项目架构"""
        # 收集所有文件信息
        file_infos = list(self.analyzer.scan_files(target_path))

        # 分析每个文件
        for file_info in file_infos:
            module = self.analyze_file(file_info)
            self.modules.append(module)

            # 记录依赖关系
            for imp in module.imports:
                self.dependencies.append(DependencyInfo(
                    source=module.path,
                    target=imp,
                    import_type="import"
                ))

        # 统计信息
        languages = defaultdict(int)
        total_lines = 0
        for module in self.modules:
            languages[module.language] += 1
            total_lines += module.lines

        # 检测循环依赖
        circular_deps = self._detect_circular_dependencies()

        # 计算分数
        coupling_score = self._calculate_coupling()
        cohesion_score = self._calculate_cohesion()

        # 使用 LLM 生成总结和建议
        modules_summary = "\n".join([
            f"- {m.path}: {m.language}, {m.lines}行, {m.classes}类, {m.functions}函数"
            for m in self.modules[:20]  # 限制数量
        ])

        prompt = ARCH_ANALYSIS_PROMPT.format(
            total_files=len(self.modules),
            total_lines=total_lines,
            languages=dict(languages),
            modules_count=len(self.modules),
            circular_deps=len(circular_deps),
            modules_summary=modules_summary,
        )

        try:
            response = self.analyzer.llm.simple_chat(prompt)
            import json
            # 尝试解析 JSON
            content = response
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            data = json.loads(content.strip())
            summary = data.get("summary", "")
            suggestions = data.get("suggestions", [])
        except Exception:
            summary = f"项目包含 {len(self.modules)} 个文件，{total_lines} 行代码"
            suggestions = ["建议添加更多文档", "考虑模块化重构"]

        return ArchitectureResult(
            total_files=len(self.modules),
            total_lines=total_lines,
            languages=dict(languages),
            modules=self.modules,
            dependencies=self.dependencies,
            circular_dependencies=circular_deps,
            coupling_score=coupling_score,
            cohesion_score=cohesion_score,
            summary=summary,
            suggestions=suggestions,
        )
