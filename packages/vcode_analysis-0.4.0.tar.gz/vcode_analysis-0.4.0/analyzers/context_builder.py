"""分析上下文构建器

在分析代码前收集项目结构、依赖关系等上下文信息，
帮助 LLM 更好地理解代码关联性。
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from collections import defaultdict
import re

from core.analyzer import Analyzer, FileInfo


@dataclass
class AnalysisContext:
    """分析上下文"""
    project_structure: str           # 项目目录树
    file_dependencies: dict[str, list[str]]  # 文件依赖映射
    reverse_dependencies: dict[str, list[str]]  # 反向依赖（被谁引用）
    language_stats: dict[str, int]   # 语言分布统计
    module_info: dict[str, dict]     # 模块信息摘要


# 导入语句正则表达式（复用自 architecture.py）
IMPORT_PATTERNS = {
    "Python": [
        r'^import\s+(\S+)',
        r'^from\s+(\S+)\s+import',
    ],
    "JavaScript": [
        r'^import\s+.*from\s+[\'"]([^\'"]+)[\'"]',
        r'^require\([\'"]([^\'"]+)[\'"]\)',
    ],
    "TypeScript": [
        r'^import\s+.*from\s+[\'"]([^\'"]+)[\'"]',
        r'^import\s+[\'"]([^\'"]+)[\'"]',
    ],
    "Java": [
        r'^import\s+([\w\.]+);',
    ],
    "Kotlin": [
        r'^import\s+([\w\.]+)',
    ],
    "C": [
        r'^#include\s*<([^>]+)>',
        r'^#include\s*"([^"]+)"',
    ],
    "C++": [
        r'^#include\s*<([^>]+)>',
        r'^#include\s*"([^"]+)"',
    ],
    "Go": [
        r'^import\s+"([^"]+)"',
    ],
    "Rust": [
        r'^use\s+([\w:]+)',
    ],
}


class ContextBuilder:
    """分析上下文构建器"""

    def __init__(self, analyzer: Analyzer):
        self.analyzer = analyzer
        self._file_cache: dict[str, str] = {}  # 文件路径 -> 内容缓存

    def build_context(self, target_path: str) -> AnalysisContext:
        """构建分析上下文

        Args:
            target_path: 目标路径

        Returns:
            分析上下文
        """
        root = Path(target_path)

        # 1. 扫描项目结构
        project_structure = self._build_project_structure(root)

        # 2. 收集所有文件信息
        file_infos = list(self.analyzer.scan_files(target_path))

        # 3. 解析依赖关系
        file_deps, reverse_deps = self._build_dependency_graph(file_infos, root)

        # 4. 统计语言分布
        language_stats = self._count_languages(file_infos)

        # 5. 收集模块信息
        module_info = self._collect_module_info(file_infos, file_deps)

        return AnalysisContext(
            project_structure=project_structure,
            file_dependencies=file_deps,
            reverse_dependencies=reverse_deps,
            language_stats=language_stats,
            module_info=module_info,
        )

    def _build_project_structure(self, root: Path, max_depth: int = 3) -> str:
        """构建项目目录树字符串"""
        lines = []
        ignore_dirs = {'.venv', 'venv', 'node_modules', '.git', '__pycache__',
                       'dist', 'build', 'target', '.idea', '.vscode'}

        def scan_dir(path: Path, prefix: str = "", depth: int = 0):
            if depth > max_depth:
                return

            try:
                items = sorted(path.iterdir(), key=lambda x: (not x.is_dir(), x.name))
            except PermissionError:
                return

            dirs = []
            files = []

            for item in items:
                if item.name in ignore_dirs:
                    continue
                if item.name.startswith('.') and item.name not in {'.github', '.gitlab-ci.yml'}:
                    continue

                if item.is_dir():
                    dirs.append(item)
                else:
                    files.append(item)

            # 限制显示数量
            total = len(dirs) + len(files)
            shown = 0
            max_items = 20

            for d in dirs:
                if shown >= max_items:
                    lines.append(f"{prefix}... ({total - shown} more items)")
                    return
                lines.append(f"{prefix}[D] {d.name}/")
                scan_dir(d, prefix + "  ", depth + 1)
                shown += 1

            for f in files:
                if shown >= max_items:
                    lines.append(f"{prefix}... ({total - shown} more items)")
                    return
                # 显示文件大小
                try:
                    size = f.stat().st_size
                    size_str = self._format_size(size)
                    lines.append(f"{prefix}[F] {f.name} ({size_str})")
                except Exception:
                    lines.append(f"{prefix}[F] {f.name}")
                shown += 1

        lines.append(f"[D] {root.name}/")
        scan_dir(root, "")

        return "\n".join(lines)

    def _format_size(self, size: int) -> str:
        """格式化文件大小"""
        for unit in ["B", "KB", "MB"]:
            if size < 1024:
                return f"{size:.0f}{unit}"
            size /= 1024
        return f"{size:.1f}GB"

    def _build_dependency_graph(
        self,
        file_infos: list[FileInfo],
        root: Path
    ) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
        """构建依赖图

        Returns:
            (正向依赖, 反向依赖)
        """
        file_deps: dict[str, list[str]] = {}
        reverse_deps: dict[str, list[str]] = defaultdict(list)

        # 构建文件路径映射（用于解析相对导入）
        file_map = {}
        for fi in file_infos:
            # 标准化路径
            rel_path = fi.relative_path.replace("\\", "/")
            file_map[rel_path] = fi
            # 也添加不带扩展名的路径
            stem = str(Path(rel_path).stem)
            if stem != rel_path:
                file_map[stem] = fi

        for file_info in file_infos:
            imports = self._extract_imports(file_info)

            # 解析导入到具体文件
            resolved_imports = []
            for imp in imports:
                # 尝试解析为项目内文件
                resolved = self._resolve_import(imp, file_info, root, file_map)
                if resolved:
                    resolved_imports.append(resolved)
                    reverse_deps[resolved].append(file_info.relative_path)

            file_deps[file_info.relative_path] = resolved_imports

        return file_deps, dict(reverse_deps)

    def _extract_imports(self, file_info: FileInfo) -> list[str]:
        """提取文件中的导入语句"""
        imports = []

        try:
            content = self.analyzer.read_file_content(file_info)
        except Exception:
            return imports

        language = file_info.language
        patterns = IMPORT_PATTERNS.get(language, [])

        if not patterns:
            return imports

        for line in content.split('\n'):
            line = line.strip()
            for pattern in patterns:
                match = re.match(pattern, line)
                if match:
                    imports.append(match.group(1))
                    break  # 匹配到一个就够了

        return imports

    def _resolve_import(
        self,
        import_path: str,
        from_file: FileInfo,
        root: Path,
        file_map: dict
    ) -> Optional[str]:
        """解析导入路径到具体文件

        Args:
            import_path: 导入路径（如 'core.analyzer' 或 './utils'）
            from_file: 导入来源文件
            root: 项目根目录
            file_map: 文件路径映射

        Returns:
            解析后的相对路径，或 None 表示外部依赖
        """
        # 跳过标准库和第三方库
        stdlib_modules = {
            'os', 'sys', 're', 'json', 'time', 'datetime', 'pathlib',
            'typing', 'collections', 'functools', 'itertools', 'io',
            'abc', 'dataclasses', 'enum', 'copy', 'math', 'random',
            'threading', 'multiprocessing', 'subprocess', 'shutil',
            'tempfile', 'glob', 'fnmatch', 'pickle', 'hashlib',
            'logging', 'argparse', 'configparser', 'unittest',
            'http', 'urllib', 'email', 'html', 'xml', 'sqlite3',
            'asyncio', 'concurrent', 'contextlib', 'warnings',
            'exceptions', 'traceback', 'inspect', 'dis', 'ast',
        }

        # 检查是否为标准库
        base_module = import_path.split('.')[0]
        if base_module in stdlib_modules:
            return None

        # 第三方库检查
        third_party = {
            'numpy', 'pandas', 'requests', 'httpx', 'flask', 'django',
            'pytest', 'pyyaml', 'docopt', 'click', 'rich', 'typer',
        }
        if base_module in third_party:
            return None

        # 尝试解析为项目内文件
        # 1. 直接匹配
        normalized = import_path.replace('.', '/')

        # 尝试各种可能的路径
        candidates = [
            f"{normalized}.py",
            f"{normalized}/__init__.py",
            f"{normalized}.js",
            f"{normalized}.ts",
            f"{normalized}.java",
            f"{normalized}.kt",
            normalized,
        ]

        for candidate in candidates:
            if candidate in file_map:
                fi = file_map[candidate]
                return fi.relative_path.replace("\\", "/")

        return None

    def _count_languages(self, file_infos: list[FileInfo]) -> dict[str, int]:
        """统计语言分布"""
        stats: dict[str, int] = defaultdict(int)
        for fi in file_infos:
            stats[fi.language] += 1
        return dict(sorted(stats.items(), key=lambda x: -x[1]))

    def _collect_module_info(
        self,
        file_infos: list[FileInfo],
        file_deps: dict[str, list[str]]
    ) -> dict[str, dict]:
        """收集模块摘要信息"""
        info = {}

        for fi in file_infos:
            try:
                content = self.analyzer.read_file_content(fi)
                lines = content.count('\n') + 1
            except Exception:
                lines = 0

            info[fi.relative_path] = {
                "language": fi.language,
                "lines": lines,
                "dependencies": len(file_deps.get(fi.relative_path, [])),
            }

        return info

    def get_related_files(
        self,
        file_path: str,
        context: AnalysisContext,
        max_depth: int = 2
    ) -> list[str]:
        """获取与指定文件相关的其他文件

        Args:
            file_path: 目标文件路径
            context: 分析上下文
            max_depth: 最大搜索深度

        Returns:
            相关文件路径列表
        """
        related = set()

        # 直接依赖
        deps = context.file_dependencies.get(file_path, [])
        related.update(deps)

        # 反向依赖（被引用）
        reverse = context.reverse_dependencies.get(file_path, [])
        related.update(reverse)

        # 二级依赖（可选）
        if max_depth > 1:
            for dep in list(deps)[:3]:  # 限制数量
                secondary = context.file_dependencies.get(dep, [])
                related.update(secondary[:2])

        # 移除自身
        related.discard(file_path)

        return list(related)[:10]  # 限制数量

    def format_context_for_prompt(
        self,
        file_path: str,
        context: AnalysisContext
    ) -> str:
        """格式化上下文信息用于 LLM 提示词

        Args:
            file_path: 当前文件路径
            context: 分析上下文

        Returns:
            格式化的上下文字符串
        """
        lines = []

        # 项目结构摘要
        lines.append("## 项目结构")
        lines.append("```")
        # 只显示前 30 行
        structure_lines = context.project_structure.split('\n')[:30]
        lines.extend(structure_lines)
        lines.append("```")
        lines.append("")

        # 语言分布
        if context.language_stats:
            lines.append("## 语言分布")
            for lang, count in list(context.language_stats.items())[:5]:
                lines.append(f"- {lang}: {count} 个文件")
            lines.append("")

        # 相关文件
        related = self.get_related_files(file_path, context)
        if related:
            lines.append("## 相关文件")
            for rel_file in related[:5]:
                info = context.module_info.get(rel_file, {})
                lang = info.get("language", "Unknown")
                deps_count = info.get("dependencies", 0)
                lines.append(f"- {rel_file} ({lang}, {deps_count} 个依赖)")
            lines.append("")

        # 当前文件的依赖
        deps = context.file_dependencies.get(file_path, [])
        if deps:
            lines.append("## 当前文件依赖")
            lines.append(", ".join(deps[:10]))
            lines.append("")

        return "\n".join(lines)
