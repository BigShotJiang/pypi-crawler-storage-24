"""目录结构分析器

扫描目录结构，识别项目类型和技术栈。
"""

import os
import re
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
from collections import defaultdict
from enum import Enum

from core.ignore import get_ignore_dirs, get_ignore_files


class ProjectType(Enum):
    """项目类型"""
    PYTHON = "Python"
    NODEJS = "Node.js"
    JAVA = "Java"
    KOTLIN = "Kotlin"
    GO = "Go"
    RUST = "Rust"
    CPP = "C/C++"
    CSHARP = "C#"
    RUBY = "Ruby"
    PHP = "PHP"
    DOTNET = ".NET"
    MONOREPO = "Monorepo"
    MIXED = "Mixed"
    UNKNOWN = "Unknown"


@dataclass
class FileInfo:
    """文件信息"""
    path: str
    relative_path: str
    extension: str
    size: int
    is_text: bool


@dataclass
class DirectoryInfo:
    """目录信息"""
    path: str
    relative_path: str
    file_count: int
    dir_count: int
    total_size: int


@dataclass
class TechStack:
    """技术栈信息"""
    category: str  # language, framework, tool, database
    name: str
    version: Optional[str] = None
    confidence: float = 1.0  # 0-1


@dataclass
class ProjectInfo:
    """项目信息"""
    path: str
    name: str
    project_type: ProjectType
    languages: dict[str, float]  # 语言 -> 占比
    tech_stack: list[TechStack]
    entry_points: list[str]  # 入口文件
    config_files: list[str]  # 配置文件
    dependencies: dict[str, list[str]]  # 依赖管理器 -> 依赖列表
    total_files: int
    total_lines: int
    structure_score: float = 0.0  # 结构健康度


@dataclass
class DirectoryAnalysisResult:
    """目录分析结果"""
    base_path: str
    projects: list[ProjectInfo]
    total_size: int
    total_files: int
    total_dirs: int
    file_extensions: dict[str, int]  # 扩展名 -> 文件数
    largest_files: list[FileInfo]
    empty_dirs: list[str]
    duplicate_files: dict[str, list[str]]  # 文件名 -> 路径列表


# 项目类型识别规则
PROJECT_INDICATORS = {
    ProjectType.PYTHON: {
        "files": ["setup.py", "pyproject.toml", "requirements.txt", "Pipfile", "poetry.lock", "tox.ini"],
        "extensions": [".py", ".pyx", ".pyi"],
        "dirs": ["__pycache__", "venv", ".venv"],
    },
    ProjectType.NODEJS: {
        "files": ["package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml", ".npmrc"],
        "extensions": [".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"],
        "dirs": ["node_modules", ".npm"],
    },
    ProjectType.JAVA: {
        "files": ["pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "gradlew"],
        "extensions": [".java", ".kt", ".groovy"],
        "dirs": ["src/main/java", "src/test/java"],
    },
    ProjectType.KOTLIN: {
        "files": ["build.gradle.kts", "settings.gradle.kts"],
        "extensions": [".kt", ".kts"],
        "dirs": ["src/main/kotlin"],
    },
    ProjectType.GO: {
        "files": ["go.mod", "go.sum", "Gopkg.toml", "Gopkg.lock"],
        "extensions": [".go"],
        "dirs": ["pkg", "cmd", "internal"],
    },
    ProjectType.RUST: {
        "files": ["Cargo.toml", "Cargo.lock"],
        "extensions": [".rs"],
        "dirs": ["src", "target"],
    },
    ProjectType.CPP: {
        "files": ["CMakeLists.txt", "Makefile", "configure.ac", "setup.py", "meson.build"],
        "extensions": [".c", ".cpp", ".h", ".hpp", ".cc", ".cxx"],
        "dirs": ["cmake", "CMakeFiles"],
    },
    ProjectType.CSHARP: {
        "files": [".csproj", ".sln", "project.json"],
        "extensions": [".cs", ".csx"],
        "dirs": ["Properties", "obj", "bin"],
    },
    ProjectType.RUBY: {
        "files": ["Gemfile", "Gemfile.lock", ".ruby-version", "Rakefile"],
        "extensions": [".rb", ".rake", ".gemspec"],
        "dirs": ["lib", "spec"],
    },
    ProjectType.PHP: {
        "files": ["composer.json", "composer.lock", "phpunit.xml"],
        "extensions": [".php", ".phtml"],
        "dirs": ["vendor", "public"],
    },
}

# 框架检测规则
FRAMEWORK_INDICATORS = {
    # Python
    "Django": {"files": ["manage.py"], "dirs": ["wsgi.py", "settings.py"]},
    "Flask": {"files": [], "imports": ["flask", "Flask"]},
    "FastAPI": {"files": [], "imports": ["fastapi", "FastAPI"]},
    "Pytest": {"files": ["pytest.ini", "conftest.py"], "dirs": ["tests", "test"]},
    "Poetry": {"files": ["pyproject.toml"]},

    # Node.js
    "React": {"dependencies": ["react"]},
    "Vue": {"dependencies": ["vue"]},
    "Angular": {"dependencies": ["@angular/core"], "files": ["angular.json"]},
    "Next.js": {"dependencies": ["next"]},
    "Express": {"dependencies": ["express"]},
    "TypeScript": {"files": ["tsconfig.json"]},

    # Java/Kotlin
    "Spring Boot": {"dependencies": ["spring-boot"], "files": ["application.yml", "application.properties"]},
    "Maven": {"files": ["pom.xml"]},
    "Gradle": {"files": ["build.gradle", "build.gradle.kts"]},

    # Go
    "Gin": {"imports": ["github.com/gin-gonic/gin"]},
    "Echo": {"imports": ["github.com/labstack/echo"]},

    # Rust
    "Tokio": {"dependencies": ["tokio"]},
    "Actix": {"dependencies": ["actix"]},

    # 数据库
    "PostgreSQL": {"dependencies": ["psycopg", "pg", "postgresql"]},
    "MySQL": {"dependencies": ["mysql", "pymysql"]},
    "MongoDB": {"dependencies": ["mongodb", "mongoose", "pymongo"]},
    "Redis": {"dependencies": ["redis", "aioredis"]},
    "SQLite": {"dependencies": ["sqlite", "sqlite3"]},

    # 工具
    "Docker": {"files": ["Dockerfile", "docker-compose.yml", "docker-compose.yaml"]},
    "Kubernetes": {"files": [], "dirs": ["k8s", "kubernetes"], "extensions": [".yaml", ".yml"]},
    "GitLab CI": {"files": [".gitlab-ci.yml"]},
    "GitHub Actions": {"dirs": [".github/workflows"]},
}

# 忽略的目录（使用统一配置）
IGNORE_DIRS = get_ignore_dirs()

# 忽略的文件（使用统一配置）
IGNORE_FILES = get_ignore_files()


class DirectoryAnalyzer:
    """目录结构分析器"""

    def __init__(self, ignore_dirs: Optional[set[str]] = None):
        """初始化分析器

        Args:
            ignore_dirs: 要忽略的目录名集合
        """
        self.ignore_dirs = ignore_dirs or IGNORE_DIRS

    def analyze(self, path: str, max_depth: int = 5) -> DirectoryAnalysisResult:
        """分析目录结构

        Args:
            path: 目录路径
            max_depth: 最大扫描深度

        Returns:
            分析结果
        """
        base_path = Path(path)

        if not base_path.exists():
            raise FileNotFoundError(f"目录不存在: {path}")

        # 扫描文件
        files = []
        dirs = []
        extensions = defaultdict(int)
        total_size = 0

        for root, dir_names, file_names in os.walk(base_path):
            # 过滤忽略的目录
            dir_names[:] = [d for d in dir_names if d not in self.ignore_dirs]

            current_depth = len(Path(root).relative_to(base_path).parts)
            if current_depth > max_depth:
                dir_names[:] = []
                continue

            for file_name in file_names:
                if file_name.startswith(".") and file_name.endswith((".pyc", ".pyo")):
                    continue

                file_path = Path(root) / file_name
                try:
                    stat = file_path.stat()
                    ext = file_path.suffix.lower()

                    files.append(FileInfo(
                        path=str(file_path),
                        relative_path=str(file_path.relative_to(base_path)),
                        extension=ext,
                        size=stat.st_size,
                        is_text=self._is_text_file(file_path),
                    ))

                    extensions[ext] += 1
                    total_size += stat.st_size
                except Exception:
                    pass

            for dir_name in dir_names:
                dir_path = Path(root) / dir_name
                dirs.append(dir_path)

        # 检测项目
        projects = self._detect_projects(base_path, files)

        # 找出最大的文件
        largest_files = sorted(files, key=lambda f: f.size, reverse=True)[:20]

        # 检测空目录
        empty_dirs = []
        for dir_path in dirs:
            try:
                if not any(dir_path.iterdir()):
                    empty_dirs.append(str(dir_path.relative_to(base_path)))
            except Exception:
                pass

        # 检测重复文件（同名文件）
        name_to_paths = defaultdict(list)
        for f in files:
            name_to_paths[Path(f.path).name].append(f.path)

        duplicate_files = {
            name: paths for name, paths in name_to_paths.items()
            if len(paths) > 1
        }

        return DirectoryAnalysisResult(
            base_path=str(base_path),
            projects=projects,
            total_size=total_size,
            total_files=len(files),
            total_dirs=len(dirs),
            file_extensions=dict(sorted(extensions.items(), key=lambda x: -x[1])),
            largest_files=largest_files,
            empty_dirs=empty_dirs,
            duplicate_files=duplicate_files,
        )

    def _is_text_file(self, file_path: Path) -> bool:
        """判断是否为文本文件"""
        text_extensions = {
            ".txt", ".md", ".py", ".js", ".ts", ".jsx", ".tsx",
            ".java", ".kt", ".go", ".rs", ".c", ".cpp", ".h", ".hpp",
            ".cs", ".rb", ".php", ".html", ".css", ".scss", ".less",
            ".json", ".yaml", ".yml", ".xml", ".toml", ".ini", ".cfg",
            ".sh", ".bash", ".zsh", ".ps1", ".bat", ".cmd",
            ".dockerfile", ".makefile", ".cmake",
        }

        if file_path.suffix.lower() in text_extensions:
            return True

        # 检查文件名
        if file_path.name.lower() in {"dockerfile", "makefile", "readme", "license"}:
            return True

        return False

    def _detect_projects(self, base_path: Path, files: list[FileInfo]) -> list[ProjectInfo]:
        """检测项目"""
        projects = []

        # 检查是否为 monorepo
        sub_projects = self._find_sub_projects(base_path)

        if len(sub_projects) > 1:
            # Monorepo
            for sub_path in sub_projects:
                project = self._analyze_single_project(sub_path)
                projects.append(project)

            # 添加根项目信息
            root_project = self._analyze_single_project(base_path)
            root_project.project_type = ProjectType.MONOREPO
            root_project.name = base_path.name
            projects.insert(0, root_project)
        else:
            # 单一项目
            project = self._analyze_single_project(base_path)
            projects.append(project)

        return projects

    def _find_sub_projects(self, base_path: Path) -> list[Path]:
        """查找子项目"""
        sub_projects = []

        # 检查一级子目录
        for item in base_path.iterdir():
            if not item.is_dir():
                continue
            if item.name in self.ignore_dirs:
                continue

            # 检查是否为项目目录
            if self._is_project_dir(item):
                sub_projects.append(item)

        return sub_projects

    def _is_project_dir(self, path: Path) -> bool:
        """判断是否为项目目录"""
        project_files = {
            "package.json", "pom.xml", "build.gradle", "go.mod",
            "Cargo.toml", "pyproject.toml", "setup.py", "requirements.txt",
            "composer.json", "Gemfile", "*.csproj", "*.sln",
        }

        for pattern in project_files:
            if pattern.startswith("*"):
                if list(path.glob(pattern)):
                    return True
            elif (path / pattern).exists():
                return True

        # 检查典型的项目结构
        typical_dirs = {
            "src", "lib", "app", "cmd", "pkg",
        }
        for dir_name in typical_dirs:
            if (path / dir_name).is_dir():
                return True

        return False

    def _analyze_single_project(self, project_path: Path) -> ProjectInfo:
        """分析单个项目"""
        # 检测项目类型
        project_type = self._detect_project_type(project_path)

        # 分析语言分布
        languages = self._analyze_languages(project_path)

        # 检测技术栈
        tech_stack = self._detect_tech_stack(project_path)

        # 找出入口文件
        entry_points = self._find_entry_points(project_path, project_type)

        # 找出配置文件
        config_files = self._find_config_files(project_path)

        # 解析依赖
        dependencies = self._parse_dependencies(project_path, project_type)

        # 统计文件和行数
        total_files, total_lines = self._count_files_and_lines(project_path)

        return ProjectInfo(
            path=str(project_path),
            name=project_path.name,
            project_type=project_type,
            languages=languages,
            tech_stack=tech_stack,
            entry_points=entry_points,
            config_files=config_files,
            dependencies=dependencies,
            total_files=total_files,
            total_lines=total_lines,
        )

    def _detect_project_type(self, path: Path) -> ProjectType:
        """检测项目类型"""
        scores = defaultdict(int)

        for ptype, indicators in PROJECT_INDICATORS.items():
            # 检查文件
            for file_pattern in indicators.get("files", []):
                if file_pattern.startswith("*"):
                    if list(path.glob(file_pattern)):
                        scores[ptype] += 2
                elif (path / file_pattern).exists():
                    scores[ptype] += 3

            # 检查扩展名
            for ext in indicators.get("extensions", []):
                if list(path.rglob(f"*{ext}")):
                    scores[ptype] += 1

            # 检查目录
            for dir_name in indicators.get("dirs", []):
                if (path / dir_name).exists():
                    scores[ptype] += 1

        if not scores:
            return ProjectType.UNKNOWN

        # 返回得分最高的类型
        return max(scores.items(), key=lambda x: x[1])[0]

    def _analyze_languages(self, path: Path) -> dict[str, float]:
        """分析语言分布"""
        extension_to_lang = {
            ".py": "Python",
            ".js": "JavaScript",
            ".jsx": "JavaScript",
            ".ts": "TypeScript",
            ".tsx": "TypeScript",
            ".java": "Java",
            ".kt": "Kotlin",
            ".kts": "Kotlin",
            ".go": "Go",
            ".rs": "Rust",
            ".c": "C",
            ".cpp": "C++",
            ".cc": "C++",
            ".h": "C/C++ Header",
            ".hpp": "C++ Header",
            ".cs": "C#",
            ".rb": "Ruby",
            ".php": "PHP",
            ".sh": "Shell",
            ".bash": "Shell",
            ".ps1": "PowerShell",
            ".html": "HTML",
            ".css": "CSS",
            ".scss": "SCSS",
            ".less": "Less",
            ".sql": "SQL",
            ".json": "JSON",
            ".yaml": "YAML",
            ".yml": "YAML",
            ".xml": "XML",
            ".toml": "TOML",
            ".md": "Markdown",
        }

        lang_sizes = defaultdict(int)
        total_size = 0

        for ext, lang in extension_to_lang.items():
            for file_path in path.rglob(f"*{ext}"):
                if any(ignored in file_path.parts for ignored in self.ignore_dirs):
                    continue
                try:
                    size = file_path.stat().st_size
                    lang_sizes[lang] += size
                    total_size += size
                except Exception:
                    pass

        if total_size == 0:
            return {}

        # 计算百分比
        return {
            lang: round(size / total_size * 100, 1)
            for lang, size in sorted(lang_sizes.items(), key=lambda x: -x[1])
            if size > 0
        }

    def _detect_tech_stack(self, path: Path) -> list[TechStack]:
        """检测技术栈"""
        tech_stack = []

        # 检查 package.json (Node.js)
        package_json = path / "package.json"
        if package_json.exists():
            tech_stack.extend(self._parse_package_json(package_json))

        # 检查 requirements.txt (Python)
        requirements = path / "requirements.txt"
        if requirements.exists():
            tech_stack.extend(self._parse_requirements(requirements))

        # 检查 pom.xml (Java)
        pom_xml = path / "pom.xml"
        if pom_xml.exists():
            tech_stack.extend(self._parse_pom_xml(pom_xml))

        # 检查 go.mod (Go)
        go_mod = path / "go.mod"
        if go_mod.exists():
            tech_stack.append(TechStack("language", "Go", confidence=1.0))

        # 检查 Dockerfile
        if (path / "Dockerfile").exists() or list(path.glob("Dockerfile*")):
            tech_stack.append(TechStack("tool", "Docker", confidence=1.0))

        # 检查 CI/CD
        if (path / ".github" / "workflows").exists():
            tech_stack.append(TechStack("tool", "GitHub Actions", confidence=1.0))

        if (path / ".gitlab-ci.yml").exists():
            tech_stack.append(TechStack("tool", "GitLab CI", confidence=1.0))

        return tech_stack

    def _parse_package_json(self, file_path: Path) -> list[TechStack]:
        """解析 package.json"""
        import json

        tech_stack = []

        try:
            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)

            # 主要框架检测
            deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}

            framework_map = {
                "react": "React",
                "vue": "Vue",
                "angular": "Angular",
                "next": "Next.js",
                "nuxt": "Nuxt.js",
                "express": "Express",
                "koa": "Koa",
                "fastify": "Fastify",
                "typescript": "TypeScript",
                "tailwindcss": "Tailwind CSS",
                "jest": "Jest",
                "vitest": "Vitest",
                "webpack": "Webpack",
                "vite": "Vite",
                "eslint": "ESLint",
                "prettier": "Prettier",
            }

            for dep, name in framework_map.items():
                if dep in deps:
                    version = deps[dep].replace("^", "").replace("~", "")
                    tech_stack.append(TechStack("framework" if dep in ["react", "vue", "angular", "next", "express"] else "tool", name, version))

        except Exception:
            pass

        return tech_stack

    def _parse_requirements(self, file_path: Path) -> list[TechStack]:
        """解析 requirements.txt"""
        tech_stack = []

        try:
            with open(file_path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    # 解析包名和版本
                    if "==" in line:
                        name, version = line.split("==", 1)
                        name = name.strip().lower()
                    elif ">=" in line or "<=" in line or "~=" in line:
                        name = re.split(r'[><=~]+', line)[0].strip().lower()
                        version = None
                    else:
                        name = line.lower()
                        version = None

                    framework_map = {
                        "django": ("framework", "Django"),
                        "flask": ("framework", "Flask"),
                        "fastapi": ("framework", "FastAPI"),
                        "tornado": ("framework", "Tornado"),
                        "pyramid": ("framework", "Pyramid"),
                        "pytest": ("tool", "Pytest"),
                        "unittest": ("tool", "unittest"),
                        "numpy": ("library", "NumPy"),
                        "pandas": ("library", "Pandas"),
                        "requests": ("library", "Requests"),
                        "sqlalchemy": ("library", "SQLAlchemy"),
                        "celery": ("tool", "Celery"),
                        "redis": ("tool", "Redis"),
                        "gunicorn": ("tool", "Gunicorn"),
                        "uvicorn": ("tool", "Uvicorn"),
                    }

                    if name in framework_map:
                        cat, tech_name = framework_map[name]
                        tech_stack.append(TechStack(cat, tech_name, version))

        except Exception:
            pass

        return tech_stack

    def _parse_pom_xml(self, file_path: Path) -> list[TechStack]:
        """解析 pom.xml"""
        tech_stack = []

        try:
            content = file_path.read_text(encoding="utf-8")

            # 简单提取依赖
            pattern = r'<groupId>([^<]+)</groupId>\s*<artifactId>([^<]+)</artifactId>'
            for match in re.finditer(pattern, content):
                group_id, artifact_id = match.groups()

                framework_map = {
                    "spring-boot-starter": "Spring Boot",
                    "spring-framework": "Spring",
                    "hibernate": "Hibernate",
                    "mybatis": "MyBatis",
                    "junit": "JUnit",
                    "mockito": "Mockito",
                    "lombok": "Lombok",
                    "slf4j": "SLF4J",
                    "log4j": "Log4j",
                    "jackson": "Jackson",
                    "gson": "Gson",
                }

                for key, name in framework_map.items():
                    if key in artifact_id.lower():
                        tech_stack.append(TechStack("framework" if "spring" in key else "library", name))
                        break

        except Exception:
            pass

        return tech_stack

    def _find_entry_points(self, path: Path, project_type: ProjectType) -> list[str]:
        """找出入口文件"""
        entry_patterns = {
            ProjectType.PYTHON: ["main.py", "app.py", "run.py", "wsgi.py", "asgi.py", "manage.py"],
            ProjectType.NODEJS: ["index.js", "app.js", "server.js", "main.js", "index.ts", "main.ts"],
            ProjectType.JAVA: ["Main.java", "Application.java", "*Application.java"],
            ProjectType.GO: ["main.go"],
            ProjectType.RUST: ["main.rs"],
            ProjectType.CPP: ["main.cpp", "main.c"],
        }

        patterns = entry_patterns.get(project_type, [])
        entry_points = []

        for pattern in patterns:
            if pattern.startswith("*"):
                for f in path.rglob(pattern):
                    entry_points.append(str(f.relative_to(path)))
            elif (path / pattern).exists():
                entry_points.append(pattern)

        return entry_points

    def _find_config_files(self, path: Path) -> list[str]:
        """找出配置文件"""
        config_patterns = [
            "*.json", "*.yaml", "*.yml", "*.toml", "*.ini", "*.cfg",
            ".env*", "*.properties", "*.xml",
        ]

        config_files = []

        for pattern in config_patterns:
            for f in path.glob(pattern):
                if f.is_file():
                    config_files.append(f.name)

        return list(set(config_files))

    def _parse_dependencies(self, path: Path, project_type: ProjectType) -> dict[str, list[str]]:
        """解析依赖"""
        dependencies = {}

        # Python
        if (path / "requirements.txt").exists():
            deps = []
            with open(path / "requirements.txt", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        deps.append(line.split("==")[0].split(">=")[0].split("<=")[0])
            dependencies["pip"] = deps

        # Node.js
        package_json = path / "package.json"
        if package_json.exists():
            import json
            with open(package_json, encoding="utf-8") as f:
                data = json.load(f)
            deps = list(data.get("dependencies", {}).keys())
            dev_deps = list(data.get("devDependencies", {}).keys())
            dependencies["npm"] = deps
            dependencies["npm-dev"] = dev_deps

        return dependencies

    def _count_files_and_lines(self, path: Path) -> tuple[int, int]:
        """统计文件数和行数"""
        total_files = 0
        total_lines = 0

        for file_path in path.rglob("*"):
            if not file_path.is_file():
                continue
            if any(ignored in file_path.parts for ignored in self.ignore_dirs):
                continue

            total_files += 1

            # 只统计文本文件
            if self._is_text_file(file_path):
                try:
                    with open(file_path, encoding="utf-8", errors="ignore") as f:
                        total_lines += sum(1 for _ in f)
                except Exception:
                    pass

        return total_files, total_lines

    def generate_report(self, result: DirectoryAnalysisResult) -> str:
        """生成分析报告

        Args:
            result: 分析结果

        Returns:
            Markdown 格式的报告
        """
        lines = [
            "# 目录结构分析报告",
            "",
            f"**分析路径**: {result.base_path}",
            f"**总文件数**: {result.total_files:,}",
            f"**总目录数**: {result.total_dirs:,}",
            f"**总大小**: {self._format_size(result.total_size)}",
            "",
            "---",
            "",
            "## 项目列表",
            "",
        ]

        for project in result.projects:
            lines.append(f"### {project.name}")
            lines.append("")
            lines.append(f"- **类型**: {project.project_type.value}")
            lines.append(f"- **文件数**: {project.total_files:,}")
            lines.append(f"- **代码行数**: {project.total_lines:,}")

            if project.languages:
                lines.append("")
                lines.append("**语言分布**:")
                lines.append("")
                for lang, percent in list(project.languages.items())[:5]:
                    lines.append(f"- {lang}: {percent}%")

            if project.tech_stack:
                lines.append("")
                lines.append("**技术栈**:")
                lines.append("")
                for tech in project.tech_stack[:10]:
                    version_str = f" ({tech.version})" if tech.version else ""
                    lines.append(f"- {tech.category}: {tech.name}{version_str}")

            lines.append("")

        # 文件类型统计
        lines.extend([
            "---",
            "",
            "## 文件类型统计",
            "",
            "| 扩展名 | 文件数 |",
            "|--------|--------|",
        ])

        for ext, count in list(result.file_extensions.items())[:20]:
            ext_display = ext or "(无扩展名)"
            lines.append(f"| {ext_display} | {count:,} |")

        # 大文件
        if result.largest_files:
            lines.extend([
                "",
                "## 最大文件",
                "",
                "| 文件 | 大小 |",
                "|------|------|",
            ])
            for f in result.largest_files[:10]:
                lines.append(f"| {f.relative_path} | {self._format_size(f.size)} |")

        # 空目录
        if result.empty_dirs:
            lines.extend([
                "",
                f"## 空目录 ({len(result.empty_dirs)} 个)",
                "",
            ])
            for dir_path in result.empty_dirs[:10]:
                lines.append(f"- {dir_path}")

        return "\n".join(lines)

    def _format_size(self, size: int) -> str:
        """格式化文件大小"""
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"
