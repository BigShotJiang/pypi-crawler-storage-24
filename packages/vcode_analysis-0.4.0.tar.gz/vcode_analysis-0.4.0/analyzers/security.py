"""安全漏洞扫描分析器

检测常见安全漏洞：
- SQL 注入
- XSS (跨站脚本攻击)
- 硬编码密钥
- 命令注入
- 路径遍历
- 不安全的反序列化
"""

from dataclasses import dataclass, field
from typing import Optional
import re

from core.analyzer import Analyzer, FileInfo, AnalysisResult


@dataclass
class SecurityIssue:
    """安全问题"""
    type: str
    severity: str  # critical, high, medium, low
    file_path: str
    line: int
    description: str
    code_snippet: str
    recommendation: str


@dataclass
class SecurityResult:
    """安全扫描结果"""
    file_path: str
    issues: list[SecurityIssue]
    risk_score: int  # 0-100, 越高越危险
    passed: bool


# 安全规则定义
SECURITY_RULES = {
    # Python 规则
    "Python": [
        {
            "id": "sql_injection",
            "pattern": r'execute\s*\(\s*[f]?["\'].*%s.*["\']|cursor\.execute\s*\(\s*["\'].*\+',
            "severity": "critical",
            "description": "SQL 注入风险：直接拼接用户输入到 SQL 查询",
            "recommendation": "使用参数化查询，如 cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))",
        },
        {
            "id": "hardcoded_password",
            "pattern": r'(password|passwd|pwd)\s*=\s*["\'][^"\']{4,}["\']',
            "severity": "high",
            "description": "硬编码密码：代码中发现明文密码",
            "recommendation": "使用环境变量或密钥管理服务存储密码",
        },
        {
            "id": "hardcoded_api_key",
            "pattern": r'(api_key|apikey|secret_key|access_token)\s*=\s*["\'][^"\']{8,}["\']',
            "severity": "high",
            "description": "硬编码 API 密钥",
            "recommendation": "使用环境变量或配置文件存储密钥",
        },
        {
            "id": "hardcoded_ip",
            "pattern": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            "severity": "medium",
            "description": "硬编码 IP 地址：可能暴露内网结构或生产环境地址",
            "recommendation": "使用 DNS 名称或配置文件管理 IP 地址",
        },
        {
            "id": "hardcoded_url",
            "pattern": r'(https?://|ftp://)[^\s"\']+\.(com|org|net|io|cn|jp|eu)[^\s"\']*(?!.*example)',
            "severity": "medium",
            "description": "硬编码 URL：可能暴露生产环境地址",
            "recommendation": "将 URL 移至配置文件或环境变量",
        },
        {
            "id": "hardcoded_connection_string",
            "pattern": r'(mysql|postgres|postgresql|mongodb|redis|redis)://[^\s"\']+(@|:)',
            "severity": "high",
            "description": "硬编码数据库连接字符串：可能包含凭据",
            "recommendation": "使用环境变量或密钥管理服务存储连接字符串",
        },
        {
            "id": "hardcoded_private_key",
            "pattern": r'-----BEGIN (RSA |EC |DSA )?(PRIVATE KEY|CERTIFICATE)-----',
            "severity": "critical",
            "description": "硬编码私钥或证书：严重安全风险",
            "recommendation": "使用密钥管理服务（如 AWS KMS、Azure Key Vault）存储私钥",
        },
        {
            "id": "hardcoded_aws_key",
            "pattern": r'AKIA[0-9A-Z]{16}',
            "severity": "critical",
            "description": "硬编码 AWS 访问密钥",
            "recommendation": "使用 IAM 角色或环境变量管理 AWS 凭证",
        },
        {
            "id": "hardcoded_github_token",
            "pattern": r'ghp_[a-zA-Z0-9]{36}',
            "severity": "critical",
            "description": "硬编码 GitHub Personal Access Token",
            "recommendation": "使用环境变量或 GitHub Secrets 存储 Token",
        },
        {
            "id": "command_injection",
            "pattern": r'os\.system\s*\(|subprocess\.(call|run|Popen)\s*\([^)]*shell\s*=\s*True',
            "severity": "critical",
            "description": "命令注入风险：使用 shell=True 或 os.system",
            "recommendation": "避免使用 shell=True，使用列表形式传递参数",
        },
        {
            "id": "pickle_deserialize",
            "pattern": r'pickle\.loads?\s*\(',
            "severity": "high",
            "description": "不安全的反序列化：pickle 可能导致代码执行",
            "recommendation": "使用 JSON 或其他安全的序列化格式",
        },
        {
            "id": "eval_usage",
            "pattern": r'\beval\s*\(',
            "severity": "high",
            "description": "危险的 eval() 函数调用",
            "recommendation": "避免使用 eval()，考虑 ast.literal_eval() 或其他安全替代",
        },
        {
            "id": "assert_side_effect",
            "pattern": r'assert\s+.*\.',
            "severity": "medium",
            "description": "assert 语句在生产环境可能被优化掉",
            "recommendation": "使用显式的条件检查和异常",
        },
        {
            "id": "path_traversal",
            "pattern": r'open\s*\([^)]*\+|os\.path\.join\s*\([^)]*request|os\.path\.join\s*\([^)]*input',
            "severity": "critical",
            "description": "路径遍历风险：用户输入可能用于构造文件路径",
            "recommendation": "验证和规范化用户输入，使用 os.path.basename 限制路径",
        },
        {
            "id": "ssrf_potential",
            "pattern": r'requests\.(get|post|put|delete|patch)\s*\([^)]*(url|request\.|input|params)',
            "severity": "high",
            "description": "潜在 SSRF 风险：用户输入可能用于构造请求 URL",
            "recommendation": "验证和限制请求目标，使用白名单机制",
        },
        {
            "id": "weak_crypto_hash",
            "pattern": r'hashlib\.(md5|sha1)\s*\(',
            "severity": "high",
            "description": "弱加密哈希算法：MD5/SHA1 已不安全",
            "recommendation": "使用 SHA-256 或更强的哈希算法",
        },
        {
            "id": "insecure_random",
            "pattern": r'random\.(random|randint|choice|shuffle)\s*\(',
            "severity": "medium",
            "description": "不安全的随机数生成器：不适用于安全场景",
            "recommendation": "安全场景请使用 secrets 模块",
        },
    ],

    # JavaScript/TypeScript 规则
    "JavaScript": [
        {
            "id": "eval_usage",
            "pattern": r'\beval\s*\(|new\s+Function\s*\(',
            "severity": "critical",
            "description": "危险的 eval() 或 Function() 调用",
            "recommendation": "避免动态代码执行",
        },
        {
            "id": "innerHTML",
            "pattern": r'\.innerHTML\s*=',
            "severity": "high",
            "description": "XSS 风险：使用 innerHTML",
            "recommendation": "使用 textContent 或进行 HTML 编码",
        },
        {
            "id": "document_write",
            "pattern": r'document\.write\s*\(',
            "severity": "medium",
            "description": "document.write 可能导致 XSS",
            "recommendation": "使用 DOM 操作方法替代",
        },
        {
            "id": "hardcoded_secret",
            "pattern": r'(password|secret|apiKey|api_key)\s*[:=]\s*["\'][^"\']{8,}["\']',
            "severity": "high",
            "description": "硬编码敏感信息",
            "recommendation": "使用环境变量存储敏感信息",
        },
        {
            "id": "hardcoded_ip",
            "pattern": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            "severity": "medium",
            "description": "硬编码 IP 地址",
            "recommendation": "使用 DNS 名称或配置文件管理 IP 地址",
        },
        {
            "id": "hardcoded_url",
            "pattern": r'(https?://|ftp://)[^\s"\']+\.(com|org|net|io|cn|jp|eu)[^\s"\']*(?!.*example)',
            "severity": "medium",
            "description": "硬编码 URL",
            "recommendation": "将 URL 移至配置文件或环境变量",
        },
        {
            "id": "hardcoded_connection_string",
            "pattern": r'(mysql|postgres|postgresql|mongodb|redis)://[^\s"\']+(@|:)',
            "severity": "high",
            "description": "硬编码数据库连接字符串",
            "recommendation": "使用环境变量存储连接字符串",
        },
        {
            "id": "hardcoded_private_key",
            "pattern": r'-----BEGIN (RSA |EC |DSA )?(PRIVATE KEY|CERTIFICATE)-----',
            "severity": "critical",
            "description": "硬编码私钥或证书",
            "recommendation": "使用密钥管理服务存储私钥",
        },
        {
            "id": "hardcoded_aws_key",
            "pattern": r'AKIA[0-9A-Z]{16}',
            "severity": "critical",
            "description": "硬编码 AWS 访问密钥",
            "recommendation": "使用 IAM 角色或环境变量管理 AWS 凭证",
        },
        {
            "id": "hardcoded_github_token",
            "pattern": r'ghp_[a-zA-Z0-9]{36}',
            "severity": "critical",
            "description": "硬编码 GitHub Token",
            "recommendation": "使用环境变量存储 Token",
        },
        {
            "id": "path_traversal",
            "pattern": r'fs\.(readFile|writeFile|readFileSync|writeFileSync|open)\s*\([^)]*\+',
            "severity": "critical",
            "description": "路径遍历风险：用户输入可能用于构造文件路径",
            "recommendation": "验证和规范化用户输入，使用 path.basename 限制路径",
        },
        {
            "id": "ssrf_potential",
            "pattern": r'fetch\s*\([^)]*\+|axios\.(get|post)\s*\([^)]*\+',
            "severity": "high",
            "description": "潜在 SSRF 风险：用户输入可能用于构造请求 URL",
            "recommendation": "验证和限制请求目标，使用白名单机制",
        },
        {
            "id": "weak_crypto_hash",
            "pattern": r'\.createHash\s*\(\s*["\']md5["\']|\.createHash\s*\(\s*["\']sha1["\']',
            "severity": "high",
            "description": "弱加密哈希算法：MD5/SHA1 已不安全",
            "recommendation": "使用 SHA-256 或更强的哈希算法",
        },
    ],
    # TypeScript 继承 JavaScript 规则
    "TypeScript": [],

    # Java 规则
    "Java": [
        {
            "id": "sql_injection",
            "pattern": r'executeQuery\s*\([^)]*\+|createQuery\s*\([^)]*\+',
            "severity": "critical",
            "description": "SQL 注入风险",
            "recommendation": "使用 PreparedStatement 进行参数化查询",
        },
        {
            "id": "command_injection",
            "pattern": r'Runtime\.getRuntime\(\)\.exec\s*\(',
            "severity": "critical",
            "description": "命令注入风险",
            "recommendation": "验证和清理所有用户输入",
        },
        {
            "id": "object_deserialize",
            "pattern": r'ObjectInputStream|readObject\s*\(',
            "severity": "high",
            "description": "不安全的反序列化",
            "recommendation": "使用安全的序列化方案",
        },
    ],

    # Kotlin 规则 (与 Java 类似)
    "Kotlin": [
        {
            "id": "sql_injection",
            "pattern": r'executeQuery\s*\([^)]*\$|createQuery\s*\([^)]*\$',
            "severity": "critical",
            "description": "SQL 注入风险",
            "recommendation": "使用参数化查询",
        },
        {
            "id": "command_injection",
            "pattern": r'Runtime\.getRuntime\(\)\.exec',
            "severity": "critical",
            "description": "命令注入风险",
            "recommendation": "验证和清理所有用户输入",
        },
    ],

    # C 规则
    "C": [
        # 缓冲区溢出风险
        {
            "id": "buffer_overflow_gets",
            "pattern": r'\bgets\s*\(',
            "severity": "critical",
            "description": "缓冲区溢出风险：gets() 函数不检查缓冲区大小",
            "recommendation": "使用 fgets() 替代，并指定缓冲区大小",
        },
        {
            "id": "buffer_overflow_scanf",
            "pattern": r'\bscanf\s*\(\s*["\'][^"\']*%s',
            "severity": "critical",
            "description": "缓冲区溢出风险：scanf %s 不限制输入长度",
            "recommendation": "使用 fgets() 读取输入，或指定宽度如 %99s",
        },
        {
            "id": "buffer_overflow_strcpy",
            "pattern": r'\bstrcpy\s*\(',
            "severity": "critical",
            "description": "缓冲区溢出风险：strcpy 不检查目标缓冲区大小",
            "recommendation": "使用 strncpy() 或 strlcpy()，并确保以 null 结尾",
        },
        {
            "id": "buffer_overflow_strcat",
            "pattern": r'\bstrcat\s*\(',
            "severity": "critical",
            "description": "缓冲区溢出风险：strcat 不检查目标缓冲区大小",
            "recommendation": "使用 strncat() 或 strlcat()",
        },
        {
            "id": "buffer_overflow_sprintf",
            "pattern": r'\bsprintf\s*\(',
            "severity": "critical",
            "description": "缓冲区溢出风险：sprintf 不检查输出缓冲区大小",
            "recommendation": "使用 snprintf() 并指定缓冲区大小",
        },
        {
            "id": "buffer_overflow_vsprintf",
            "pattern": r'\bvsprintf\s*\(',
            "severity": "critical",
            "description": "缓冲区溢出风险：vsprintf 不检查输出缓冲区大小",
            "recommendation": "使用 vsnprintf() 并指定缓冲区大小",
        },
        # 格式化字符串漏洞
        {
            "id": "format_string",
            "pattern": r'\bprintf\s*\(\s*\w+\s*\)|\bfprintf\s*\([^,]+,\s*\w+\s*\)|\bsprintf\s*\([^,]+,\s*\w+\s*\)',
            "severity": "critical",
            "description": "格式化字符串漏洞：用户输入可能作为格式字符串",
            "recommendation": "使用固定格式字符串，如 printf(\"%s\", user_input)",
        },
        # 硬编码敏感信息
        {
            "id": "hardcoded_password",
            "pattern": r'(password|passwd|pwd)\s*=\s*["\'][^"\']{4,}["\']',
            "severity": "high",
            "description": "硬编码密码",
            "recommendation": "从配置文件或环境变量读取密码",
        },
        {
            "id": "hardcoded_key",
            "pattern": r'(secret|key|token|api_key)\s*=\s*["\'][^"\']{8,}["\']',
            "severity": "high",
            "description": "硬编码密钥或 Token",
            "recommendation": "使用安全的密钥存储机制",
        },
        {
            "id": "hardcoded_ip",
            "pattern": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            "severity": "medium",
            "description": "硬编码 IP 地址",
            "recommendation": "使用 DNS 名称或配置文件管理 IP 地址",
        },
        {
            "id": "hardcoded_private_key",
            "pattern": r'-----BEGIN (RSA |EC |DSA )?(PRIVATE KEY|CERTIFICATE)-----',
            "severity": "critical",
            "description": "硬编码私钥或证书",
            "recommendation": "使用密钥管理服务存储私钥",
        },
        # 内存安全问题
        {
            "id": "use_after_free",
            "pattern": r'\bfree\s*\([^)]+\)[^;]*;\s*[^;]*\b\w+\s*=|\bfree\s*\([^)]+\)[^}]*\b\w+\s*->|\bfree\s*\([^)]+\)[^}]*\*\w+',
            "severity": "critical",
            "description": "潜在的 use-after-free 风险：free 后立即使用指针",
            "recommendation": "free 后将指针设为 NULL，或使用静态分析工具检测",
        },
        {
            "id": "null_deref",
            "pattern": r'\bmalloc\s*\([^)]*\)[^;]*;\s*\w+\s*->|\bmalloc\s*\([^)]*\)[^;]*;\s*\*\w+',
            "severity": "high",
            "description": "潜在空指针解引用：malloc 后未检查返回值",
            "recommendation": "检查 malloc 返回值是否为 NULL",
        },
        {
            "id": "double_free",
            "pattern": r'\bfree\s*\(\s*(\w+)\s*\)[^}]*\bfree\s*\(\s*\1\s*\)',
            "severity": "critical",
            "description": "潜在的 double-free 风险：同一指针被多次 free",
            "recommendation": "free 后将指针设为 NULL",
        },
        # 危险函数
        {
            "id": "dangerous_system",
            "pattern": r'\bsystem\s*\(',
            "severity": "critical",
            "description": "命令注入风险：system() 函数可能执行任意命令",
            "recommendation": "使用 exec 系列函数，并避免 shell 解析",
        },
        {
            "id": "dangerous_popen",
            "pattern": r'\bpopen\s*\(',
            "severity": "high",
            "description": "命令注入风险：popen() 通过 shell 执行命令",
            "recommendation": "使用 pipe() + fork() + exec() 组合",
        },
        # 整数溢出风险
        {
            "id": "integer_overflow",
            "pattern": r'\bmalloc\s*\(\s*\w+\s*\*|\brealloc\s*\(\s*[^,]+,\s*\w+\s*\*|\bcalloc\s*\(\s*\w+\s*,',
            "severity": "high",
            "description": "潜在的整数溢出：乘法运算可能导致缓冲区大小计算错误",
            "recommendation": "检查乘法溢出，使用安全的整数运算函数",
        },
    ],

    # C++ 规则 (包含 C 规则并添加 C++ 特有规则)
    "C++": [
        # C++ 特有的内存安全问题
        {
            "id": "dangling_pointer",
            "pattern": r'\breturn\s+&|\breturn\s+\w+\s*\.\s*\w+\s*;',  # 返回局部变量的地址或引用
            "severity": "critical",
            "description": "潜在的悬垂指针：返回局部变量的地址",
            "recommendation": "不要返回局部变量的指针或引用",
        },
        {
            "id": "unsafe_vector_access",
            "pattern": r'\.at\([^)]+\)',  # vector::at 会进行边界检查，但 operator[] 不会
            "severity": "medium",
            "description": "vector::at() 会抛出异常，确保有异常处理",
            "recommendation": "确保捕获 out_of_range 异常，或使用 operator[] 配合 size 检查",
        },
        {
            "id": "unsafe_smart_pointer",
            "pattern": r'\.get\s*\(\s*\)\s*->|\.get\s*\(\s*\)\s*\.',
            "severity": "medium",
            "description": "智能指针裸指针访问：可能绕过智能指针的安全机制",
            "recommendation": "优先使用智能指针的操作符 -> 和 *",
        },
        {
            "id": "raw_pointer_delete",
            "pattern": r'\bdelete\s+\w+\s*;',
            "severity": "high",
            "description": "手动 delete 裸指针：可能导致内存泄漏或 double-free",
            "recommendation": "使用智能指针（unique_ptr, shared_ptr）管理内存",
        },
        {
            "id": "raw_pointer_new",
            "pattern": r'\bnew\s+\w+',
            "severity": "medium",
            "description": "手动 new 创建对象：建议使用智能指针",
            "recommendation": "使用 make_unique 或 make_shared 创建智能指针",
        },
        # C++ 格式化字符串
        {
            "id": "cpp_format_string",
            "pattern": r'\bstd::cout\s*<<\s*\w+\s*<<|\.format\s*\(\s*\w+\s*\)',
            "severity": "high",
            "description": "潜在的格式化问题：用户输入可能直接输出",
            "recommendation": "验证和清理用户输入",
        },
    ],
}


def _add_line_numbers(content: str) -> str:
    """给代码添加行号前缀，方便 LLM 准确定位问题"""
    lines = content.split('\n')
    max_width = len(str(len(lines)))
    numbered_lines = [f"{i+1:>{max_width}}| {line}" for i, line in enumerate(lines)]
    return '\n'.join(numbered_lines)


# LLM 安全分析提示词
SECURITY_ANALYSIS_PROMPT = """作为安全专家，请审查以下 {language} 代码的安全问题:

文件: {file_path}

```{language}
{content}
```

已检测到的模式匹配问题:
{detected_issues}

请分析:
1. 确认已检测到的问题是否真实存在
2. 是否有其他潜在的安全风险
3. 提供具体的修复建议

以 JSON 格式输出:
{{"confirmed_issues": [{{"type": "类型", "line": 行号, "description": "描述", "recommendation": "建议"}}], "additional_risks": ["额外风险"], "risk_score": 0-100}}"""


class SecurityAnalyzer:
    """安全漏洞扫描分析器"""

    def __init__(self, analyzer: Analyzer):
        self.analyzer = analyzer

    def _get_rules_for_language(self, language: str) -> list[dict]:
        """获取指定语言的规则，支持规则继承"""
        # 语言继承映射
        inheritance_map = {
            "TypeScript": "JavaScript",
            "C++": "C",
        }

        # 获取当前语言的规则
        rules = list(SECURITY_RULES.get(language, []))

        # 如果有父语言，合并父语言规则
        if language in inheritance_map:
            parent_language = inheritance_map[language]
            parent_rules = SECURITY_RULES.get(parent_language, [])
            # 父语言规则放在前面，子语言特有规则放在后面
            rules = list(parent_rules) + rules

        return rules

    def _scan_patterns(self, content: str, language: str) -> list[dict]:
        """使用规则模式扫描"""
        issues = []
        rules = self._get_rules_for_language(language)

        lines = content.split('\n')
        for line_num, line in enumerate(lines, 1):
            for rule in rules:
                if re.search(rule["pattern"], line):
                    issues.append({
                        "id": rule["id"],
                        "severity": rule["severity"],
                        "line": line_num,
                        "description": rule["description"],
                        "code_snippet": line.strip()[:100],
                        "recommendation": rule["recommendation"],
                    })

        return issues

    def scan_file(self, file_info: FileInfo) -> SecurityResult:
        """扫描单个文件"""
        try:
            content = self.analyzer.read_file_content(file_info)

            # 模式匹配扫描
            pattern_issues = self._scan_patterns(content, file_info.language)

            # 转换为 SecurityIssue 对象
            issues = []
            for issue in pattern_issues:
                issues.append(SecurityIssue(
                    type=issue["id"],
                    severity=issue["severity"],
                    file_path=file_info.relative_path,
                    line=issue["line"],
                    description=issue["description"],
                    code_snippet=issue["code_snippet"],
                    recommendation=issue["recommendation"],
                ))

            # 计算风险分数
            risk_score = self._calculate_risk_score(issues)

            return SecurityResult(
                file_path=file_info.relative_path,
                issues=issues,
                risk_score=risk_score,
                passed=risk_score < 30,
            )

        except Exception as e:
            return SecurityResult(
                file_path=file_info.relative_path,
                issues=[],
                risk_score=0,
                passed=True,
            )

    def _calculate_risk_score(self, issues: list[SecurityIssue]) -> int:
        """计算风险分数"""
        if not issues:
            return 0

        severity_weights = {
            "critical": 40,
            "high": 25,
            "medium": 10,
            "low": 5,
        }

        score = sum(severity_weights.get(i.severity, 5) for i in issues)
        return min(100, score)

    def deep_scan(self, file_info: FileInfo) -> SecurityResult:
        """使用 LLM 深度扫描"""
        try:
            content = self.analyzer.read_file_content(file_info)

            # 先进行模式扫描
            pattern_issues = self._scan_patterns(content, file_info.language)
            detected_summary = "\n".join([
                f"- {i['severity']}: {i['description']} (行 {i['line']})"
                for i in pattern_issues
            ]) or "无"

            # 添加行号，方便 LLM 准确定位
            numbered_content = _add_line_numbers(content[:3000])  # 限制长度

            prompt = SECURITY_ANALYSIS_PROMPT.format(
                language=file_info.language,
                file_path=file_info.relative_path,
                content=numbered_content,
                detected_issues=detected_summary,
            )

            response = self.analyzer.llm.simple_chat(prompt)

            # 解析 LLM 响应
            import json
            result_content = response
            if "```json" in result_content:
                result_content = result_content.split("```json")[1].split("```")[0]

            data = json.loads(result_content.strip())

            issues = []
            for issue in data.get("confirmed_issues", []):
                issues.append(SecurityIssue(
                    type=issue.get("type", "unknown"),
                    severity="high",
                    file_path=file_info.relative_path,
                    line=issue.get("line", 0),
                    description=issue.get("description", ""),
                    code_snippet="",
                    recommendation=issue.get("recommendation", ""),
                ))

            risk_score = data.get("risk_score", 0)

            return SecurityResult(
                file_path=file_info.relative_path,
                issues=issues,
                risk_score=risk_score,
                passed=risk_score < 30,
            )

        except Exception as e:
            # 回退到模式扫描
            return self.scan_file(file_info)

    def scan_project(self, target_path: str, deep: bool = False) -> list[SecurityResult]:
        """扫描整个项目（并发）"""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        file_infos = list(self.analyzer.scan_files(target_path))
        total = len(file_infos)
        results: list[SecurityResult] = [None] * total  # type: ignore

        # 选择扫描函数
        scan_func = self.deep_scan if deep else self.scan_file
        max_workers = self.analyzer.config.analysis.max_workers

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_index = {
                executor.submit(scan_func, file_info): i
                for i, file_info in enumerate(file_infos)
            }

            for future in as_completed(future_to_index):
                index = future_to_index[future]
                try:
                    results[index] = future.result()
                except Exception as e:
                    file_info = file_infos[index]
                    results[index] = SecurityResult(
                        file_path=file_info.relative_path,
                        issues=[],
                        risk_score=0,
                        passed=True,
                    )

        return results
