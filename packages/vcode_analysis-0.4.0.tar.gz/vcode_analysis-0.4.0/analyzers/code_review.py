"""代码审查分析器"""

from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING
from core.analyzer import Analyzer, FileInfo, AnalysisResult

if TYPE_CHECKING:
    from .context_builder import AnalysisContext


@dataclass
class CodeReviewResult:
    """代码审查结果"""
    file_path: str
    score: int  # 1-10, 0 表示分析失败
    issues: list[dict]
    suggestions: list[str]
    summary: str
    success: bool = True


def _add_line_numbers(content: str) -> str:
    """给代码添加行号前缀，方便 LLM 准确定位问题"""
    lines = content.split('\n')
    max_width = len(str(len(lines)))
    numbered_lines = [f"{i+1:>{max_width}}| {line}" for i, line in enumerate(lines)]
    return '\n'.join(numbered_lines)


# 代码审查提示词模板
CODE_REVIEW_PROMPT = """请审查以下 {language} 代码:

文件: {file_path}

```{language}
{content}
```

请进行代码审查，必须严格按照以下 JSON 格式输出，不要输出任何其他内容:

{{"score": 评分1-10, "issues": [{{"type": "问题类型", "severity": "high/medium/low", "line": 行号, "description": "问题描述"}}], "suggestions": ["改进建议"], "summary": "代码评价总结"}}"""


# 带上下文的代码审查提示词模板
CODE_REVIEW_PROMPT_V2 = """请审查以下 {language} 代码:

文件: {file_path}

{context_section}

## 当前文件代码
```{language}
{content}
```

请进行代码审查，必须严格按照以下 JSON 格式输出，不要输出任何其他内容:

{{"score": 评分1-10, "issues": [{{"type": "问题类型", "severity": "high/medium/low", "line": 行号, "description": "问题描述", "context": "相关上下文说明(可选)"}}], "suggestions": ["改进建议"], "summary": "代码评价总结", "cross_file_issues": ["跨文件问题(可选)"]}}"""


COMMIT_REVIEW_PROMPT = """你是一位代码审查专家。请审查以下 Git 提交的变更。

提交信息: {commit_message}
作者: {author}

变更内容:
{diff}

请分析：
1. 变更的目的和影响
2. 潜在的问题或风险
3. 代码风格和最佳实践
4. 改进建议

以 Markdown 格式输出审查报告。"""


class CodeReviewAnalyzer:
    """代码审查分析器"""

    def __init__(self, analyzer: Analyzer):
        self.analyzer = analyzer

    def review_file(self, file_info: FileInfo) -> CodeReviewResult:
        """审查单个文件"""
        try:
            # 读取文件内容并添加行号
            content = self.analyzer.read_file_content(file_info)
            numbered_content = _add_line_numbers(content)

            # 构建提示词
            prompt = CODE_REVIEW_PROMPT.format(
                file_path=file_info.relative_path,
                language=file_info.language,
                content=numbered_content,
            )

            # 调用 LLM
            response = self.analyzer.llm.simple_chat(prompt)

            result = AnalysisResult(
                file_path=file_info.relative_path,
                analyzer="code_review",
                success=True,
                content=response,
            )
        except Exception as e:
            result = AnalysisResult(
                file_path=file_info.relative_path,
                analyzer="code_review",
                success=False,
                content="",
                errors=[str(e)],
            )

        if not result.success:
            return CodeReviewResult(
                file_path=file_info.relative_path,
                score=0,
                issues=[{"type": "error", "severity": "high", "description": result.errors[0]}],
                suggestions=[],
                summary="分析失败",
                success=False,
            )

        # 解析 JSON 结果
        import json
        try:
            # 尝试从 markdown 代码块中提取 JSON
            content = result.content
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            data = json.loads(content.strip())
            return CodeReviewResult(
                file_path=file_info.relative_path,
                score=data.get("score", 0),
                issues=data.get("issues", []),
                suggestions=data.get("suggestions", []),
                summary=data.get("summary", ""),
            )
        except json.JSONDecodeError:
            # 如果解析失败，返回原始内容作为总结
            return CodeReviewResult(
                file_path=file_info.relative_path,
                score=0,
                issues=[],
                suggestions=[],
                summary=result.content,
            )

    def review_commit(self, commit_hash: str) -> AnalysisResult:
        """审查指定提交"""
        git = self.analyzer.git
        if not git:
            return AnalysisResult(
                file_path="",
                analyzer="code_review",
                success=False,
                content="",
                errors=["目标路径不是有效的 Git 仓库"],
            )

        commit_info = git.get_commit_info(commit_hash)
        diffs = git.get_commit_diff(commit_hash)

        # 构建差异内容
        diff_content = ""
        for diff in diffs:
            diff_content += f"\n### {diff.file_path}\n"
            diff_content += f"状态: {diff.status} (+{diff.additions}/-{diff.deletions})\n"
            diff_content += f"```diff\n{diff.diff}\n```\n"

        prompt = COMMIT_REVIEW_PROMPT.format(
            commit_message=commit_info.message,
            author=commit_info.author,
            diff=diff_content,
        )

        response = self.analyzer.llm.simple_chat(prompt)

        return AnalysisResult(
            file_path=commit_hash,
            analyzer="code_review",
            success=True,
            content=response,
            metadata={
                "commit_hash": commit_hash,
                "author": commit_info.author,
                "date": commit_info.date.isoformat(),
                "files_changed": commit_info.files_changed,
            },
        )

    def review_files(self, file_infos: list[FileInfo]) -> list[CodeReviewResult]:
        """审查多个文件"""
        results = []
        for file_info in file_infos:
            result = self.review_file(file_info)
            results.append(result)
        return results

    def review_file_with_context(
        self,
        file_info: FileInfo,
        context: "AnalysisContext",
        context_builder=None
    ) -> CodeReviewResult:
        """带上下文的文件审查

        Args:
            file_info: 文件信息
            context: 分析上下文
            context_builder: 上下文构建器（用于格式化）

        Returns:
            审查结果
        """
        try:
            # 读取文件内容并添加行号
            content = self.analyzer.read_file_content(file_info)
            numbered_content = _add_line_numbers(content)

            # 构建上下文部分
            context_section = ""
            if context_builder:
                context_section = context_builder.format_context_for_prompt(
                    file_info.relative_path, context
                )

            # 构建提示词
            prompt = CODE_REVIEW_PROMPT_V2.format(
                file_path=file_info.relative_path,
                language=file_info.language,
                context_section=context_section,
                content=numbered_content,
            )

            # 调用 LLM
            response = self.analyzer.llm.simple_chat(prompt)

            result = AnalysisResult(
                file_path=file_info.relative_path,
                analyzer="code_review",
                success=True,
                content=response,
            )
        except Exception as e:
            result = AnalysisResult(
                file_path=file_info.relative_path,
                analyzer="code_review",
                success=False,
                content="",
                errors=[str(e)],
            )

        if not result.success:
            return CodeReviewResult(
                file_path=file_info.relative_path,
                score=0,
                issues=[{"type": "error", "severity": "high", "description": result.errors[0]}],
                suggestions=[],
                summary="分析失败",
                success=False,
            )

        # 解析 JSON 结果
        import json
        try:
            # 尝试从 markdown 代码块中提取 JSON
            content = result.content
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            data = json.loads(content.strip())

            # 提取跨文件问题并添加到 issues
            issues = data.get("issues", [])
            cross_file = data.get("cross_file_issues", [])
            if cross_file:
                for cf_issue in cross_file:
                    issues.append({
                        "type": "cross_file",
                        "severity": "medium",
                        "description": cf_issue,
                    })

            return CodeReviewResult(
                file_path=file_info.relative_path,
                score=data.get("score", 0),
                issues=issues,
                suggestions=data.get("suggestions", []),
                summary=data.get("summary", ""),
            )
        except json.JSONDecodeError:
            # 如果解析失败，返回原始内容作为总结
            return CodeReviewResult(
                file_path=file_info.relative_path,
                score=0,
                issues=[],
                suggestions=[],
                summary=result.content,
            )
