# Code Analysis - 智能代码分析工具

[![PyPI version](https://img.shields.io/pypi/v/vcode-analysis.svg)](https://pypi.org/project/vcode-analysis/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

基于私有化部署大模型的智能代码分析工具，支持代码审查、文档生成、架构分析和安全扫描。

## ✨ 核心特性

| 特性 | 描述 |
|------|------|
| 🔍 **代码审查** | 自动分析代码质量，识别问题和安全漏洞 |
| 📝 **文档生成** | 自动生成模块文档、API 文档 |
| 🏗️ **架构分析** | 分析项目结构、依赖关系、代码度量 |
| 🔒 **安全扫描** | 检测常见安全漏洞和风险代码 |
| ⚡ **并发分析** | 支持多线程并发分析，默认 5 个线程 |
| 📦 **批量操作** | 批量克隆、批量 Git 操作、多仓库管理 |
| 📂 **目录分析** | 扫描项目结构、识别技术栈 |
| 🌐 **多语言支持** | Python, Java, Kotlin, C, JavaScript, TypeScript 等 |
| 🤖 **私有化部署** | 兼容 OpenAI API 格式，支持任何私有化 LLM |

## 🚀 快速开始

### 安装

**方式一：从 PyPI 安装（推荐）**

```bash
# 基础安装
pip install vcode-analysis

# 安装额外解析器支持
pip install vcode-analysis[parsers]

# 安装所有可选依赖
pip install vcode-analysis[parsers,rich]
```

**方式二：从源码安装**

```bash
git clone https://gitcode.com/wellchang/code-analysis.git
cd code-analysis
pip install -e .
```

### 配置

```bash
# 初始化配置文件
vcode-analysis config --init

# 编辑配置文件
# ~/.code-analysis/config.yaml
```

### 使用

```bash
# 代码审查（结果自动保存到 result/目录名_review_时间戳.md）
vcode-analysis review ./src

# 架构分析
vcode-analysis arch ./src

# 安全扫描
vcode-analysis security ./src --deep

# 使用 10 个并发线程加速分析
vcode-analysis review ./src --workers 10

# 目录扫描
vcode-analysis scan-dir ./project
```

## 📖 命令概览

```bash
Commands:
    review          代码审查
    review-commit   审查指定提交
    doc             生成文档
    arch            架构分析
    security        安全漏洞扫描
    clone           克隆仓库并分析
    batch-clone     批量克隆仓库
    batch-pull      批量拉取更新
    git-status      查看多仓库状态
    scan-dir        扫描目录结构
    config          配置管理
```

## 🌍 支持的语言

| 语言 | 文件扩展名 | 解析模式 |
|------|------------|----------|
| Python | `.py` | AST |
| Java | `.java` | AST |
| Kotlin | `.kt`, `.kts` | 双模式 |
| C | `.c`, `.h` | 双模式 |
| JavaScript | `.js`, `.jsx` | 正则 |
| TypeScript | `.ts`, `.tsx` | 正则 |

## 📚 文档

- [完整使用手册](docs/USER_MANUAL.md)
- [Kotlin 解析器设计](docs/design/kotlin-parser-design.md)
- [C 解析器设计](docs/design/c-parser-design.md)

## 🔧 项目结构

```
code-analysis/
├── cli.py                 # CLI 入口
├── core/
│   ├── analyzer.py        # 分析引擎核心
│   ├── llm_client.py      # LLM 客户端
│   ├── git_handler.py     # Git 操作 + 批量操作
│   ├── config.py          # 配置管理
│   └── ignore.py          # 统一过滤规则
├── analyzers/
│   ├── code_review.py     # 代码审查
│   ├── documentation.py   # 文档生成
│   ├── architecture.py    # 架构分析
│   ├── security.py        # 安全扫描
│   └── directory.py       # 目录分析
└── parsers/
    ├── python_parser.py   # Python AST 解析器
    ├── java_parser.py     # Java AST 解析器
    ├── kotlin_parser.py   # Kotlin 解析器（双模式）
    ├── c_parser.py        # C 语言解析器（双模式）
    └── ...
```

## 💡 使用示例

### 代码审查

```bash
# 审查整个项目（结果保存到 result/src_review_20260320_120000.md）
vcode-analysis review ./src

# 使用 10 个线程加速分析
vcode-analysis review ./src --workers 10

# 自定义输出路径
vcode-analysis review ./src --output custom_report.md

# 审查最新提交
vcode-analysis review-commit HEAD
```

### 安全扫描

```bash
# 深度安全扫描
vcode-analysis security ./src --deep

# 快速扫描
vcode-analysis security ./src
```

### 批量操作

```bash
# 批量克隆（从文件读取 URL 列表）
vcode-analysis batch-clone repos.txt ./projects --parallel

# 查看多仓库状态
vcode-analysis git-status ~/projects
```

## ⚙️ 配置示例

```yaml
# ~/.code-analysis/config.yaml
llm:
  base_url: http://localhost:8000/v1
  api_key: sk-your-api-key
  model: qwen3.5-35b-a3b
  temperature: 0.7
  max_tokens: 4096

analysis:
  max_file_size: 102400
  max_workers: 5                      # 并发分析线程数
  ignore_patterns:
    # 默认已包含多语言依赖目录和缓存文件
    # Python: .venv, venv, __pycache__, .pytest_cache, .mypy_cache
    # Node.js: node_modules, .npm, .yarn
    # Java: target, .gradle
    # Go: vendor
    # .NET: bin, obj
    # 以及: .git, .idea, .vscode, *.pyc, *.min.js 等
    # 用户可在此添加额外的自定义忽略规则
```

## 🤝 扩展开发

### 添加新的分析器

```python
from core import Analyzer

class CustomAnalyzer:
    def __init__(self, analyzer: Analyzer):
        self.analyzer = analyzer

    def analyze(self, file_path: str) -> dict:
        content = self.analyzer.read_file(file_path)
        prompt = f"分析以下代码：\n{content}"
        result = self.analyzer.llm_client.chat(prompt)
        return {"result": result}
```

### 使用解析器 API

```python
from parsers import KotlinASTParser, CASTParser

# Kotlin 解析
parser = KotlinASTParser()
result = parser.parse_file('Example.kt', mode='auto')

# C 解析
parser = CASTParser()
result = parser.parse_file('main.c', mode='fast')
```

## 📦 发布到 PyPI

### 发布新版本

```bash
# 安装发布工具
pip install build twine

# 构建包
python -m build

# 上传到 PyPI
twine upload dist/*
```

### 发布到 TestPyPI（测试）

```bash
# 上传到 TestPyPI
twine upload --repository testpypi dist/*
```

## 📄 许可证

[MIT License](LICENSE)

## 🔗 链接

- [PyPI 包地址](https://pypi.org/project/vcode-analysis/)
- [项目主页](https://gitcode.com/wellchang/code-analysis)
- [问题反馈](https://gitcode.com/wellchang/code-analysis/issues)
