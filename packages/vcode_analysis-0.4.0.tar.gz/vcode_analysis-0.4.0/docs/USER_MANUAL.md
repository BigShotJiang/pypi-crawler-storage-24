# Code Analysis 使用手册

> 智能代码分析工具 - 完整使用指南
>
> 版本: 0.2.0 | 更新日期: 2026-03-20

---

## 目录

1. [项目概述](#1-项目概述)
2. [安装指南](#2-安装指南)
3. [配置说明](#3-配置说明)
4. [命令参考](#4-命令参考)
5. [解析器支持](#5-解析器支持)
6. [高级功能](#6-高级功能)
7. [API 编程接口](#7-api-编程接口)
8. [输出格式](#8-输出格式)
9. [最佳实践](#9-最佳实践)
10. [故障排除](#10-故障排除)

---

## 1. 项目概述

### 1.1 简介

Code Analysis 是一款基于大语言模型（LLM）的智能代码分析工具，支持：

- **代码审查**: 自动分析代码质量，识别问题和安全漏洞
- **文档生成**: 自动生成模块文档、API 文档
- **架构分析**: 分析项目结构、依赖关系、代码度量
- **安全扫描**: 检测常见安全漏洞和风险代码
- **并发分析**: 多线程并发分析，提升处理速度
- **批量操作**: 批量克隆、批量 Git 操作、多仓库管理
- **目录分析**: 扫描项目结构、识别技术栈

### 1.2 核心特性

| 特性 | 描述 |
|------|------|
| 私有化部署 | 兼容 OpenAI API 格式，支持任何私有化 LLM |
| 多语言支持 | Python, Java, Kotlin, C, JavaScript, TypeScript 等 |
| AST 解析 | 精确的语法树分析，支持多种解析器 |
| 双模式架构 | 快速模式（正则）+ 精确模式（AST）|
| 并发分析 | 多线程并发处理，可配置线程数 |
| 批量处理 | 支持多仓库管理和批量操作 |
| 可扩展 | 模块化设计，易于添加新分析器 |

### 1.3 项目结构

```
code-analysis/
├── cli.py                 # CLI 入口
├── core/
│   ├── analyzer.py        # 分析引擎核心
│   ├── llm_client.py      # LLM 客户端
│   ├── git_handler.py     # Git 操作 + 批量操作
│   ├── config.py          # 配置管理
│   └── ignore.py          # 统一过滤规则
├── analyzers/
│   ├── code_review.py     # 代码审查
│   ├── documentation.py   # 文档生成
│   ├── architecture.py    # 架构分析
│   ├── security.py        # 安全扫描
│   └── directory.py       # 目录分析
├── parsers/
│   ├── python_parser.py   # Python AST 解析器
│   ├── java_parser.py     # Java AST 解析器
│   ├── kotlin_parser.py   # Kotlin 解析器（双模式）
│   ├── c_parser.py        # C 语言解析器（双模式）
│   ├── javascript_parser.py
│   └── typescript_parser.py
└── docs/
    └── design/            # 设计文档
```

---

## 2. 安装指南

### 2.1 系统要求

- Python 3.10+
- Git（用于 Git 相关功能）

### 2.2 安装步骤

#### 方式一：从 PyPI 安装（推荐）

```bash
# 基础安装
pip install vcode-analysis

# 安装额外解析器支持
pip install vcode-analysis[parsers]

# 安装所有可选依赖
pip install vcode-analysis[parsers,rich]
```

安装完成后，可使用 `code-analysis` 或 `vcode-analysis` 命令。

#### 方式二：从源码安装

```bash
# 克隆项目
git clone https://gitcode.com/wellchang/code-analysis.git
cd code-analysis

# 开发模式安装
pip install -e .

# 或者安装所有依赖
pip install -e ".[parsers,rich]"
```

### 2.3 可选依赖

| 包名 | 用途 | 安装命令 |
|------|------|----------|
| `javalang` | Java AST 解析 | `pip install vcode-analysis[parsers]` |
| `pycparser` | C AST 解析（精确模式） | `pip install vcode-analysis[parsers]` |
| `tree-sitter` | Kotlin AST（精确模式） | 需单独安装 |
| `rich` | 美化输出 | `pip install vcode-analysis[rich]` |

### 2.4 验证安装

```bash
# 查看版本
vcode-analysis --version

# 查看帮助
vcode-analysis --help

# 初始化配置
vcode-analysis config --init
```

---

## 3. 配置说明

### 3.1 配置方式

支持三种配置方式，优先级从高到低：

1. **CLI 参数** - 命令行直接指定
2. **环境变量** - 系统环境变量
3. **配置文件** - YAML 配置文件

### 3.2 配置文件

#### 初始化配置

```bash
python cli.py config --init
```

配置文件位置：`~/.code-analysis/config.yaml`

#### 配置示例

```yaml
llm:
  # LLM API 配置
  base_url: http://localhost:8000/v1    # API 地址
  api_key: sk-your-api-key              # API 密钥
  model: qwen3.5-35b-a3b                # 模型名称
  temperature: 0.7                       # 温度参数
  max_tokens: 4096                       # 最大 token 数

analysis:
  # 分析配置
  max_file_size: 102400                 # 最大文件大小（字节）
  max_workers: 5                        # 并发分析线程数
  ignore_patterns:                      # 忽略的目录/文件（默认已包含以下规则）
    # 依赖目录（自动过滤）
    # - Python: .venv, venv, __pycache__, .tox, .pytest_cache, .mypy_cache
    # - Node.js: node_modules, .npm, .yarn
    # - Java/Kotlin: target, .gradle, build
    # - Go: vendor
    # - .NET: bin, obj, packages
    # - Swift/iOS: Pods, Carthage
    # 缓存文件（自动过滤）
    # - *.pyc, *.pyo, *.o, *.so, *.dll, *.exe
    # - .DS_Store, Thumbs.db
    # 其他忽略目录
    # - .git, .idea, .vscode, dist, build
```

### 3.3 环境变量

```bash
# API 配置
export OPENAI_API_BASE=http://localhost:8000/v1
export OPENAI_API_KEY=sk-your-api-key
export CODE_ANALYSIS_MODEL=qwen3.5-35b-a3b
```

### 3.4 CLI 参数

```bash
python cli.py review ./src \
    --base-url http://localhost:8000/v1 \
    --api-key sk-your-api-key \
    --model qwen3.5-35b-a3b
```

### 3.5 查看配置

```bash
python cli.py config --show
```

---

## 4. 命令参考

### 4.1 命令概览

| 命令 | 功能 |
|------|------|
| `review` | 代码审查 |
| `review-commit` | 审查 Git 提交 |
| `doc` | 生成文档 |
| `arch` | 架构分析 |
| `security` | 安全扫描 |
| `clone` | 克隆仓库并分析 |
| `batch-clone` | 批量克隆仓库 |
| `batch-pull` | 批量拉取更新 |
| `git-status` | 查看多仓库状态 |
| `scan-dir` | 扫描目录结构 |
| `config` | 配置管理 |

---

### 4.2 代码审查 (review)

分析代码质量，识别问题和改进机会。

#### 语法

```bash
python cli.py review <path> [options]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `<path>` | 要分析的文件或目录路径 |
| `-o, --output <file>` | 输出文件路径 |
| `-f, --format <format>` | 输出格式：`markdown`（默认）或 `json` |
| `-w, --workers <n>` | 并发线程数，默认 5 |

#### 示例

```bash
# 审查整个项目
python cli.py review ./src

# 审查单个文件
python cli.py review ./src/main.py

# 保存报告到文件
python cli.py review ./src --output report.md

# 使用 10 个并发线程加速分析
python cli.py review ./src --workers 10

# JSON 格式输出
python cli.py review ./src --format json --output report.json
```

#### 输出示例

```markdown
# 代码审查报告

**生成时间**: 2024-03-19 10:30:00
**分析文件数**: 15
**平均评分**: 7.5/10
**问题总数**: 23

---

# 代码审查报告: src/main.py

**评分**: 8/10

## 问题列表

- [MEDIUM] **bug** 行 42: 空指针异常风险，建议添加空值检查
- [LOW] **style** 行 15: 变量命名不规范，建议使用 snake_case
- [INFO] **suggestion** 行 30: 可以使用列表推导式简化代码

## 改进建议

1. 添加输入参数验证
2. 使用 try-except 处理可能的异常
3. 考虑添加类型注解提高代码可读性

## 总结

代码整体结构清晰，逻辑正确，但存在一些潜在问题需要关注。
```

---

### 4.3 审查 Git 提交 (review-commit)

审查指定 Git 提交的代码变更。

#### 语法

```bash
python cli.py review-commit <commit> [--path <path>] [options]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `<commit>` | 提交哈希（支持 `HEAD`、短哈希） |
| `--path <path>` | 仓库路径，默认当前目录 |

#### 示例

```bash
# 审查最新提交
python cli.py review-commit HEAD

# 审查指定提交
python cli.py review-commit abc123

# 指定仓库路径
python cli.py review-commit HEAD --path ./my-repo

# 审查提交范围
python cli.py review-commit abc123..def456
```

---

### 4.4 生成文档 (doc)

自动生成代码文档。

#### 语法

```bash
python cli.py doc <path> [--type <type>] [options]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `<path>` | 源代码路径 |
| `--type <type>` | 文档类型：`module`（默认）、`api` |
| `-o, --output <file>` | 输出目录或文件 |

#### 示例

```bash
# 生成模块文档
python cli.py doc ./src --type module

# 生成 API 文档
python cli.py doc ./src --type api

# 保存到指定目录
python cli.py doc ./src --output ./docs/
```

---

### 4.5 架构分析 (arch)

分析项目架构和代码度量。

#### 语法

```bash
python cli.py arch <path> [options]
```

#### 输出内容

- 项目统计（文件数、代码行数、语言分布）
- 架构指标（耦合度、内聚度）
- 循环依赖检测
- 模块依赖关系
- 改进建议

#### 示例

```bash
# 分析项目架构
python cli.py arch ./src

# 保存报告
python cli.py arch ./src --output arch_report.md

# JSON 格式输出
python cli.py arch ./src --format json
```

#### 输出示例

```markdown
# 架构分析报告

**分析时间**: 2024-03-19 10:30:00
**目标路径**: ./src

---

## 项目统计

- 文件总数: 45
- 代码行数: 3,500

### 语言分布

- Python: 30 个文件
- TypeScript: 10 个文件
- JavaScript: 5 个文件

## 架构指标

- **耦合度**: 25.5/100 (越低越好)
- **内聚度**: 78.3/100 (越高越好)

## 改进建议

1. 考虑将 `utils` 模块拆分为更小的模块
2. 减少模块间的直接依赖，考虑使用依赖注入
```

---

### 4.6 安全扫描 (security)

检测代码中的安全漏洞。

#### 语法

```bash
python cli.py security <path> [--deep] [options]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `--deep` | 启用深度扫描（使用 LLM 分析） |

#### 检测的漏洞类型

| 类型 | 说明 |
|------|------|
| SQL 注入 | 不安全的 SQL 查询构造 |
| 命令注入 | 不安全的系统命令执行 |
| XSS | 跨站脚本攻击风险 |
| 硬编码凭证 | 代码中的密码、API 密钥 |
| 不安全的反序列化 | pickle、yaml.load 等风险操作 |
| 危险函数调用 | eval、exec 等危险函数 |

#### 示例

```bash
# 快速扫描
python cli.py security ./src

# 深度扫描（推荐）
python cli.py security ./src --deep

# 保存报告
python cli.py security ./src --deep --output security.md
```

---

### 4.7 克隆仓库 (clone)

克隆远程仓库并可选分析。

#### 语法

```bash
python cli.py clone <url> [--branch <name>] [--analyze] [options]
```

#### 示例

```bash
# 克隆仓库
python cli.py clone https://github.com/user/repo.git

# 克隆指定分支
python cli.py clone https://github.com/user/repo.git --branch develop

# 克隆并自动分析
python cli.py clone https://github.com/user/repo.git --analyze
```

---

### 4.8 批量克隆 (batch-clone)

从文件读取 URL 列表，批量克隆仓库。

#### 语法

```bash
python cli.py batch-clone <file> <target-dir> [--parallel] [--analyze]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `<file>` | 包含仓库 URL 的文件（每行一个） |
| `<target-dir>` | 目标目录 |
| `--parallel` | 并行克隆 |
| `--analyze` | 克隆后自动分析 |

#### URL 文件格式

```text
# repos.txt - 仓库 URL 列表
# 以 # 开头的行为注释

https://github.com/user/repo1.git
https://github.com/user/repo2.git
https://gitlab.com/user/repo3.git
```

#### 示例

```bash
# 批量克隆
python cli.py batch-clone repos.txt ./projects

# 并行克隆
python cli.py batch-clone repos.txt ./projects --parallel

# 克隆并分析
python cli.py batch-clone repos.txt ./projects --parallel --analyze

# 保存报告
python cli.py batch-clone repos.txt ./projects --output report.md
```

---

### 4.9 批量拉取 (batch-pull)

对多个仓库执行 git pull 操作。

#### 语法

```bash
python cli.py batch-pull <dir> [--repos <names>]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `<dir>` | 包含多个仓库的目录 |
| `--repos <names>` | 指定仓库名（逗号分隔），不指定则全部 |

#### 示例

```bash
# 拉取所有仓库
python cli.py batch-pull ~/projects

# 拉取指定仓库
python cli.py batch-pull ~/projects --repos repo1,repo2
```

---

### 4.10 多仓库状态 (git-status)

查看多个仓库的 Git 状态。

#### 语法

```bash
python cli.py git-status <dir> [--output <file>]
```

#### 示例

```bash
# 查看状态
python cli.py git-status ~/projects

# 保存报告
python cli.py git-status ~/projects --output status.md
```

#### 输出示例

```
扫描仓库: ~/projects
发现 5 个仓库:

✅ project-a
   分支: main
   远程: https://github.com/user/project-a.git

📝 project-b
   分支: develop
   变更: +2 staged, +3 unstaged

⬇️ project-c
   分支: main
   同步: ahead 0, behind 5
```

---

### 4.11 目录扫描 (scan-dir)

扫描目录结构，识别项目类型和技术栈。

#### 语法

```bash
python cli.py scan-dir <path> [--depth <n>] [--output <file>]
```

#### 参数

| 参数 | 说明 |
|------|------|
| `--depth <n>` | 扫描深度，默认 5 |

#### 示例

```bash
# 扫描当前目录
python cli.py scan-dir .

# 指定深度
python cli.py scan-dir ./project --depth 3

# 保存报告
python cli.py scan-dir ./project --output scan.md
```

#### 检测的项目类型

- Python
- Node.js
- Java
- Kotlin
- Go
- Rust
- C/C++
- C#
- Ruby
- PHP
- Monorepo
- Mixed（混合项目）

---

## 5. 解析器支持

### 5.1 支持的语言

| 语言 | 文件扩展名 | 解析模式 | 精确模式依赖 |
|------|------------|----------|--------------|
| Python | `.py` | AST | 内置 `ast` 模块 |
| Java | `.java` | AST | `javalang` |
| Kotlin | `.kt`, `.kts` | 双模式 | `tree-sitter-kotlin` |
| C | `.c`, `.h` | 双模式 | `pycparser` |
| JavaScript | `.js`, `.jsx` | 正则 | - |
| TypeScript | `.ts`, `.tsx` | 正则 | - |
| Vue | `.vue` | 正则 | - |
| JSON | `.json` | 内置 | - |
| YAML | `.yaml`, `.yml` | 内置 | - |
| Markdown | `.md` | 正则 | - |

### 5.2 双模式解析

Kotlin 和 C 解析器支持双模式：

| 模式 | 特点 | 适用场景 |
|------|------|----------|
| `fast` | 正则表达式，无依赖 | 快速扫描、CI/CD |
| `precise` | AST 解析，精确 | 深度分析、代码重构 |
| `auto` | 自动选择 | 通用场景 |

#### 启用精确模式

```bash
# Kotlin 精确模式
pip install tree-sitter tree-sitter-kotlin

# C 精确模式
pip install pycparser
```

### 5.3 解析器 API

```python
from parsers import (
    PythonASTParser,
    JavaASTParser,
    KotlinASTParser,
    CASTParser,
)

# Python
parser = PythonASTParser()
result = parser.parse_file('example.py')

# Kotlin（双模式）
parser = KotlinASTParser()
result = parser.parse_file('Example.kt', mode='fast')   # 快速模式
result = parser.parse_file('Example.kt', mode='precise') # 精确模式

# C（双模式）
parser = CASTParser()
result = parser.parse_file('main.c', mode='auto')
```

---

## 6. 高级功能

### 6.1 Kotlin 解析器特性

支持 Kotlin 特有语法：

| 特性 | 说明 |
|------|------|
| Sealed 类 | 密封类层次结构解析 |
| 协程 | suspend 函数、Flow 操作符 |
| 类型别名 | typealias 解析 |
| 值类 | value class / inline class |
| 委托属性 | by lazy, by observable 等 |
| 扩展函数 | 扩展函数和属性 |

### 6.2 C 解析器特性

支持 C89/C90 标准：

| 特性 | 说明 |
|------|------|
| 预处理器 | #include, #define, #ifdef |
| 结构体 | struct 定义和 typedef |
| 联合体 | union 定义 |
| 枚举 | enum 定义 |
| 函数指针 | 函数指针变量和 typedef |
| 全局变量 | 存储类说明符、指针、数组 |

### 6.3 自定义分析器

创建自定义分析器：

```python
from core import Analyzer

class CustomAnalyzer:
    def __init__(self, analyzer: Analyzer):
        self.analyzer = analyzer

    def analyze(self, file_path: str) -> dict:
        # 读取文件
        content = self.analyzer.read_file(file_path)

        # 调用 LLM 分析
        prompt = f"分析以下代码：\n{content}"
        result = self.analyzer.llm_client.chat(prompt)

        return {"result": result}
```

---

## 7. API 编程接口

### 7.1 基本使用

```python
from core import Config, Analyzer
from analyzers import (
    CodeReviewAnalyzer,
    DocumentationAnalyzer,
    ArchitectureAnalyzer,
    SecurityAnalyzer,
    DirectoryAnalyzer,
)

# 创建配置
config = Config.create(
    base_url="http://localhost:8000/v1",
    api_key="sk-your-api-key",
    model="qwen3.5-35b-a3b",
)

# 使用分析器
with Analyzer(config) as analyzer:
    # 代码审查
    reviewer = CodeReviewAnalyzer(analyzer)
    result = reviewer.review_file(file_info)

    # 架构分析
    arch = ArchitectureAnalyzer(analyzer)
    arch_result = arch.analyze("./src")

    # 安全扫描
    security = SecurityAnalyzer(analyzer)
    sec_results = security.scan_project("./src", deep=True)
```

### 7.2 Git 操作

```python
from core import GitHandler, BatchGitHandler

# 单仓库操作
handler = GitHandler("./my-repo")
print(handler.get_current_branch())
print(handler.status())

# 批量操作
batch = BatchGitHandler("~/projects")
repos = batch.get_all_repos_info()

# 批量拉取
result = batch.batch_pull()
print(f"成功: {result.success}, 失败: {result.failed}")

# 批量克隆
BatchGitHandler.batch_clone(
    urls=["https://github.com/user/repo1.git", "https://github.com/user/repo2.git"],
    target_dir="./projects",
    parallel=True,
)
```

### 7.3 目录分析

```python
from analyzers import DirectoryAnalyzer

analyzer = DirectoryAnalyzer()
result = analyzer.analyze("./my-project")

print(f"项目数: {len(result.projects)}")
print(f"文件数: {result.total_files}")

for project in result.projects:
    print(f"项目: {project.name}")
    print(f"类型: {project.project_type.value}")
    print(f"语言: {project.languages}")
    print(f"技术栈: {[t.name for t in project.tech_stack]}")

# 生成报告
report = analyzer.generate_report(result)
```

---

## 8. 输出格式

### 8.1 Markdown 格式

默认输出格式，适合人类阅读。

```bash
python cli.py review ./src --format markdown
```

### 8.2 JSON 格式

适合程序处理和集成。

```bash
python cli.py review ./src --format json --output report.json
```

#### JSON 结构示例

```json
{
  "file_path": "src/main.py",
  "score": 8,
  "issues": [
    {
      "type": "bug",
      "severity": "medium",
      "line": 42,
      "description": "空指针异常风险"
    }
  ],
  "suggestions": [
    "添加输入参数验证",
    "使用 try-except 处理异常"
  ],
  "summary": "代码整体结构清晰..."
}
```

---

## 9. 最佳实践

### 9.1 配置建议

1. **使用配置文件** - 避免每次输入参数
2. **设置合理的 max_file_size** - 避免处理过大文件
3. **配置忽略模式** - 排除生成代码、第三方库

### 9.2 代码审查建议

1. **增量审查** - 使用 `review-commit` 只审查变更
2. **定期审查** - 在 CI/CD 中集成自动审查
3. **关注严重问题** - 优先处理 high 级别问题

### 9.3 安全扫描建议

1. **使用深度扫描** - `--deep` 参数提供更准确的分析
2. **定期扫描** - 在发布前进行安全扫描
3. **结合 SAST 工具** - 与专业安全工具配合使用

### 9.4 批量操作建议

1. **并行克隆** - 使用 `--parallel` 加速批量克隆
2. **定期同步** - 使用 `batch-pull` 保持仓库更新
3. **监控状态** - 定期使用 `git-status` 检查仓库状态

---

## 10. 故障排除

### 10.1 常见问题

#### Q: 连接 LLM API 失败

```
错误: Connection refused
```

**解决方案**：
1. 检查 `base_url` 是否正确
2. 确认 LLM 服务正在运行
3. 检查防火墙设置

#### Q: 解析器不可用

```
错误: 请安装 javalang
```

**解决方案**：
```bash
pip install javalang  # Java
pip install pycparser  # C
pip install tree-sitter tree-sitter-kotlin  # Kotlin
```

#### Q: 内存不足

**解决方案**：
1. 减小 `max_file_size` 配置
2. 分批处理大项目
3. 使用快速模式而非精确模式

### 10.2 调试模式

启用详细输出：

```bash
# 查看配置
python cli.py config --show

# 检查解析器状态
python -c "from parsers import KOTLIN_PARSER_AVAILABLE, C_PARSER_AVAILABLE; print(f'Kotlin: {KOTLIN_PARSER_AVAILABLE}, C: {C_PARSER_AVAILABLE}')"
```

### 10.3 获取帮助

```bash
# 查看命令帮助
python cli.py --help

# 查看版本
python cli.py --version
```

---

## 附录

### A. 依赖列表

| 包名 | 用途 | 必需 |
|------|------|------|
| `httpx` | HTTP 客户端 | ✅ |
| `docopt` | CLI 参数解析 | ✅ |
| `pyyaml` | YAML 配置 | ✅ |
| `javalang` | Java AST 解析 | ❌ |
| `pycparser` | C AST 解析 | ❌ |
| `tree-sitter` | AST 解析框架 | ❌ |
| `tree-sitter-kotlin` | Kotlin AST | ❌ |

### B. 快捷命令

```bash
# 完整分析流程
python cli.py review ./src -o review.md && \
python cli.py arch ./src -o arch.md && \
python cli.py security ./src --deep -o security.md

# 批量操作
python cli.py git-status ~/projects -o status.md && \
python cli.py batch-pull ~/projects

# 克隆分析
python cli.py clone https://github.com/user/repo.git --analyze
```

### C. 版本历史

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| 1.0.0 | 2024-03-19 | 初始版本 |

---

**文档结束**

如有问题，请提交 Issue 或联系维护者。
