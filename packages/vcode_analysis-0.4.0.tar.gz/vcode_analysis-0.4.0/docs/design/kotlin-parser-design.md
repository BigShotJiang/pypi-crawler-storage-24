# Kotlin 解析器设计文档

## 实现状态：✅ 已完成

## 概述

实现一个混合模式的 Kotlin 解析器，结合正则表达式的快速解析和 AST 库的精确解析能力。

## 目标

- 提供两种解析模式：快速模式（正则）和精确模式（AST）
- 支持 Kotlin 特有语法特性的完整解析
- 保持与现有解析器架构的一致性

## 架构设计

### 双模式解析架构

```
┌─────────────────────────────────────────────────────────────┐
│                    KotlinASTParser                          │
├─────────────────────────────────────────────────────────────┤
│  parse_file(file_path, mode='auto')                        │
│  parse_code(code, mode='auto')                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐        ┌─────────────────────────┐   │
│  │  快速模式        │        │  精确模式               │   │
│  │  (RegexParser)  │        │  (ASTParser)           │   │
│  │                 │        │                         │   │
│  │  - 正则表达式    │        │  - ktlint/kt-compiler  │   │
│  │  - 无外部依赖    │        │  - 完整语法树          │   │
│  │  - 基础结构识别  │        │  - 精确类型信息        │   │
│  └─────────────────┘        └─────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 模式选择策略

| 场景 | 推荐模式 | 说明 |
|------|----------|------|
| 快速扫描 | fast | 正则解析，速度快 |
| 代码审查 | precise | AST 解析，信息完整 |
| CI/CD 集成 | auto | 根据文件大小自动选择 |
| 交互式分析 | auto | 平衡速度与精度 |

## 新增数据结构

### 1. Sealed 类层次结构

```python
@dataclass
class KotlinSealedClassInfo(KotlinClassInfo):
    """Sealed 类信息"""
    is_sealed: bool = True
    permitted_subclasses: list[str] = field(default_factory=list)  # 允许的子类
    when_exhaustive: Optional[bool] = None  # when 是否穷尽


@dataclass
class KotlinWhenExpression:
    """When 表达式信息"""
    subject_type: Optional[str]  # 被检查的类型
    branches: list[dict]  # 分支信息
    is_exhaustive: bool
    line_start: int
    line_end: int
```

### 2. 协程与 Flow

```python
@dataclass
class KotlinCoroutineInfo:
    """协程信息"""
    function_name: str
    is_suspend: bool
    coroutine_scope: Optional[str]  # CoroutineScope, lifecycleScope 等
    flow_type: Optional[str]  # Flow, StateFlow, SharedFlow
    dispatcher: Optional[str]  # IO, Default, Main, Unconfined
    line: int


@dataclass
class KotlinFlowOperator:
    """Flow 操作符信息"""
    name: str  # map, filter, collect 等
    input_type: Optional[str]
    output_type: Optional[str]
    is_terminal: bool  # 是否为终端操作符
```

### 3. 类型系统特性

```python
@dataclass
class KotlinTypeAlias:
    """类型别名"""
    name: str
    underlying_type: str
    type_params: list[str]
    line: int


@dataclass
class KotlinValueClass:
    """值类（内联类）"""
    name: str
    wrapped_type: str
    line: int


@dataclass
class KotlinGenericType:
    """泛型信息"""
    name: str
    variance: str  # in, out, none
    bounds: list[str]  # 类型上界
```

### 4. 属性委托

```python
@dataclass
class KotlinDelegatedProperty:
    """委托属性"""
    name: str
    delegate_type: str  # lazy, observable, vetoable, custom
    delegate_expression: Optional[str]
    is_val: bool
    line: int


@dataclass
class KotlinPropertyDelegate:
    """属性委托类型"""
    name: str  # lazy, observable, by viewModels() 等
    is_standard: bool  # 是否为标准库委托
    provides_getter: bool
    provides_setter: bool
```

## 文件结构

```
parsers/
├── kotlin_parser.py          # 主入口，模式选择逻辑
├── kotlin/
│   ├── __init__.py
│   ├── regex_parser.py       # 正则解析器（增强版）
│   ├── ast_parser.py         # AST 解析器
│   ├── models.py             # 数据模型定义
│   ├── patterns.py           # 正则表达式模式
│   ├── sealed.py             # Sealed 类解析
│   ├── coroutine.py          # 协程/Flow 解析
│   ├── types.py              # 类型系统解析
│   └── delegates.py          # 属性委托解析
```

## 实现计划

### 阶段一：数据模型重构（1-2 天）

1. 创建 `parsers/kotlin/` 目录结构
2. 定义所有新增的数据结构
3. 重构现有 `KotlinASTResult` 以支持新特性

### 阶段二：增强正则解析器（2-3 天）

1. 添加 Sealed 类识别正则
2. 添加协程/Flow 函数识别
3. 添加类型别名和值类解析
4. 添加委托属性解析

### 阶段三：AST 解析器集成（3-4 天）

1. 研究并选择 AST 工具：
   - 方案 A：ktlint（推荐，纯 Kotlin，可通过 subprocess 调用）
   - 方案 B：Kotlin 编译器（重但完整）
   - 方案 C：tree-sitter-kotlin（轻量级）
2. 实现 AST 解析器包装
3. 处理 AST 到内部模型的转换

### 阶段四：双模式集成（1-2 天）

1. 实现模式自动选择逻辑
2. 添加配置选项
3. 性能优化

### 阶段五：测试与文档（1-2 天）

1. 编写单元测试
2. 编写集成测试
3. 更新文档

## 依赖选项分析

| 工具 | 优点 | 缺点 | 推荐度 |
|------|------|------|--------|
| ktlint | 官方风格工具，AST 完整 | 需要 Java/Kotlin 环境 | ⭐⭐⭐ |
| tree-sitter-kotlin | 轻量，Python 绑定 | 功能可能不完整 | ⭐⭐⭐⭐ |
| Kotlin compiler | 最完整 | 重量级，启动慢 | ⭐⭐ |

**推荐方案**：tree-sitter-kotlin（如果支持足够）或 ktlint

## 配置示例

```python
# config.py 中添加
KOTLIN_PARSER_CONFIG = {
    'default_mode': 'auto',  # fast, precise, auto
    'auto_threshold_lines': 500,  # 超过此行数使用快速模式
    'ast_tool': 'ktlint',  # ktlint, tree-sitter
    'features': {
        'sealed_classes': True,
        'coroutines': True,
        'type_system': True,
        'delegates': True,
    }
}
```

## API 使用示例

```python
from parsers import KotlinASTParser

# 创建解析器
parser = KotlinASTParser()

# 快速模式
result = parser.parse_file('Example.kt', mode='fast')

# 精确模式
result = parser.parse_file('Example.kt', mode='precise')

# 自动模式
result = parser.parse_file('Example.kt', mode='auto')

# 访问解析结果
if result.success:
    print(f"Package: {result.package}")
    for cls in result.classes:
        if hasattr(cls, 'permitted_subclasses'):
            print(f"Sealed class {cls.name}: {cls.permitted_subclasses}")
    for func in result.functions:
        if func.coroutines:
            print(f"Suspend function: {func.name}")
```

## 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| AST 工具依赖问题 | 精确模式不可用 | 降级到快速模式 |
| 性能下降 | 用户体验差 | 智能缓存，异步解析 |
| Kotlin 语法更新 | 解析不完整 | 正则模式兜底 |

## 验收标准

1. ✅ 快速模式能在 1 秒内解析 1000 行代码
2. ✅ 精确模式能识别所有 Kotlin 特有语法结构
3. ✅ 自动模式能根据文件特征智能选择
4. ✅ 与现有 CLI 集成无问题
5. ✅ 测试覆盖率 > 80%
