# C 语言解析器设计文档

## 实现状态：✅ 已完成

## 概述

实现一个混合模式的 C 语言解析器，结合正则表达式的快速解析和 pycparser 的精确解析能力。支持 C89/C90 标准。

## 架构设计

### 双模式解析架构

```
┌─────────────────────────────────────────────────────────────┐
│                      CASTParser                             │
├─────────────────────────────────────────────────────────────┤
│  parse_file(file_path, mode='auto')                        │
│  parse_code(code, mode='auto')                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐        ┌─────────────────────────┐   │
│  │  快速模式        │        │  精确模式               │   │
│  │  (RegexParser)  │        │  (PycparserParser)     │   │
│  │                 │        │                         │   │
│  │  - 正则表达式    │        │  - pycparser            │   │
│  │  - 无外部依赖    │        │  - 完整语法树          │   │
│  │  - 容错性好      │        │  - 精确类型信息        │   │
│  └─────────────────┘        └─────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 文件结构

```
parsers/
├── c_parser.py              # 主入口，模式选择逻辑
└── c/
    ├── __init__.py          # 模块导出
    ├── models.py            # 数据模型定义
    ├── patterns.py          # 正则表达式模式
    ├── regex_parser.py      # 正则解析器
    └── ast_parser.py        # pycparser 解析器
```

## 支持的 C 语言特性

### 预处理器指令

| 特性 | 快速模式 | 精确模式 |
|------|----------|----------|
| `#include` | ✅ | ✅ |
| `#define`（对象式宏） | ✅ | ✅ |
| `#define`（函数式宏） | ✅ | ✅ |
| `#ifdef`/`#ifndef` | ✅ 识别 | - |
| `#pragma` | ✅ 识别 | - |

### 类型定义

| 特性 | 快速模式 | 精确模式 |
|------|----------|----------|
| `struct` 定义 | ✅ | ✅ |
| `union` 定义 | ✅ | ✅ |
| `enum` 定义 | ✅ | ✅ |
| `typedef` | ✅ | ✅ |
| 函数指针 typedef | ✅ | ✅ |
| 位域 | ✅ | ✅ |

### 函数

| 特性 | 快速模式 | 精确模式 |
|------|----------|----------|
| 函数声明 | ✅ | ✅ |
| 函数定义 | ✅ | ✅ |
| 参数解析 | ✅ | ✅ |
| 可变参数 | ✅ | ✅ |
| 函数指针变量 | ✅ | ✅ |
| 存储类说明符 | ✅ | ✅ |

### 变量

| 特性 | 快速模式 | 精确模式 |
|------|----------|----------|
| 全局变量 | ✅ | ✅ |
| 存储类说明符 | ✅ | ✅ |
| 指针级别 | ✅ | ✅ |
| 数组大小 | ✅ | ✅ |
| 初始化表达式 | ✅ | ✅ |

## 数据模型

### 核心类型

```python
# 函数信息
@dataclass
class CFunctionInfo:
    name: str
    return_type: str
    parameters: list[CParameterInfo]
    storage_class: Optional[str]  # static, extern, inline
    is_declaration: bool
    is_variadic: bool

# 结构体信息
@dataclass
class CStructInfo:
    name: str
    members: list[CStructMember]
    is_typedef: bool
    typedef_name: Optional[str]

# 枚举信息
@dataclass
class CEnumInfo:
    name: str
    members: list[CEnumMember]
    is_typedef: bool

# 宏定义信息
@dataclass
class CMacroInfo:
    name: str
    value: Optional[str]
    parameters: Optional[list[str]]
    is_function_like: bool
```

## API 使用示例

```python
from parsers import CASTParser, analyze_c_code

# 创建解析器
parser = CASTParser()

# 快速模式
result = parser.parse_file('example.c', mode='fast')

# 精确模式（需安装 pycparser）
result = parser.parse_file('example.c', mode='precise')

# 自动模式
result = parser.parse_file('example.c', mode='auto')

# 访问解析结果
if result.success:
    print(f"函数: {[f.name for f in result.functions]}")
    print(f"结构体: {[s.name for s in result.structs]}")
    print(f"宏定义: {[m.name for m in result.macros]}")
```

## 启用精确模式

```bash
pip install pycparser
```

## 注意事项

### 正则解析器限制

1. 无法解析复杂的预处理指令嵌套
2. 宏展开需要真正的预处理
3. 函数体内部结构不解析

### pycparser 限制

1. 需要 C 代码能够通过预处理
2. 不支持 GNU 扩展语法
3. 对于有错误的代码可能失败

### 推荐使用场景

- **快速模式**：大规模代码扫描、容错要求高、CI/CD 集成
- **精确模式**：深度代码分析、类型推断、重构工具

## 测试覆盖

- ✅ `#include` 解析
- ✅ `#define` 对象式宏
- ✅ `#define` 函数式宏
- ✅ 函数声明和定义
- ✅ 全局变量
- ✅ 结构体/联合体/枚举
- ✅ typedef
- ✅ 指针和数组
- ✅ 头文件保护
