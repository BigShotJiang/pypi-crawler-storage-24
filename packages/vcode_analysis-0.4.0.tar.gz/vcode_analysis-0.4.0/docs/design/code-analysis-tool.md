# 代码分析工具设计文档

## 1. 项目概述

基于私有化部署大模型的智能代码分析工具，支持代码审查、文档生成、架构分析和安全扫描。

## 2. 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                        CLI 入口层                            │
│  cli.py - 命令行接口，参数解析，结果输出                       │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                       分析器层                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ CodeReview   │  │Documentation │  │  Security    │       │
│  │ Analyzer     │  │ Analyzer     │  │  Analyzer    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                        核心层                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │   Analyzer   │  │  LLM Client  │  │ Git Handler  │       │
│  │   (引擎)     │  │ (LLM客户端)  │  │ (Git操作)    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
│  ┌──────────────┐                                           │
│  │   Config     │  配置管理 (CLI > 环境变量 > 配置文件)       │
│  └──────────────┘                                           │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                       解析器层                               │
│  Python Parser | Java Parser | JS/TS Parser | Vue Parser    │
│  (预留 AST 解析能力，当前版本使用 LLM 直接分析)               │
└─────────────────────────────────────────────────────────────┘
```

## 3. 核心模块

### 3.1 配置管理 (config.py)

支持三种配置方式，优先级从高到低：
1. **CLI 参数** - 命令行直接指定
2. **环境变量** - `OPENAI_API_BASE`, `OPENAI_API_KEY`, `CODE_ANALYSIS_MODEL`
3. **配置文件** - `~/.code-analysis/config.yaml`

### 3.2 LLM 客户端 (llm_client.py)

- 兼容 OpenAI API 格式
- 支持流式响应
- 支持自定义模型参数

### 3.3 Git 处理器 (git_handler.py)

- 克隆远程仓库
- 获取提交历史和差异
- 支持单次/多次提交分析

### 3.4 分析引擎 (analyzer.py)

- 文件扫描和过滤
- 语言识别
- 协调各类分析器

## 4. 分析器

### 4.1 代码审查 (CodeReviewAnalyzer)

**输入**：源代码文件
**输出**：
- 评分 (1-10)
- 问题列表 (类型、严重程度、行号、描述)
- 改进建议
- 总结

**提示词策略**：
- 明确角色定位
- 结构化输出格式 (JSON)
- 多维度评估

### 4.2 文档生成 (DocumentationAnalyzer)

**支持类型**：
- 模块文档 (module)
- API 文档 (api)
- README 文档 (readme)

## 5. CLI 命令

```bash
# 代码审查
code-analysis review ./src --output report.md

# 审查指定提交
code-analysis review-commit abc123 --path ./repo

# 生成文档
code-analysis doc ./src --type module --output docs/

# 配置管理
code-analysis config --init
code-analysis config --show
```

## 6. 扩展计划

### Phase 2 - 架构分析
- 依赖关系图谱
- 模块耦合度分析
- 架构模式识别

### Phase 3 - 安全扫描
- 常见漏洞检测 (OWASP Top 10)
- 敏感信息泄露检测
- 依赖安全审计

### Phase 4 - 增强功能
- AST 解析支持
- 增量分析
- 多模型对比

## 7. 配置文件示例

```yaml
# ~/.code-analysis/config.yaml
llm:
  base_url: http://your-server:8000/v1
  api_key: your-api-key
  model: qwen3.5-35b-a3b
  temperature: 0.7
  max_tokens: 4096

analysis:
  max_file_size: 102400
  ignore_patterns:
    - node_modules
    - .git
    - __pycache__
    - venv
```
