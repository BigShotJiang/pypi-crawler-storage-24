#!/usr/bin/env python3
"""代码分析工具 CLI 入口

Usage:
    code-analysis review <path> [options]
    code-analysis review-commit <commit> [--path <path>] [options]
    code-analysis doc <path> [--type <type>] [--output <file>] [options]
    code-analysis arch <path> [--output <file>] [options]
    code-analysis security <path> [--deep] [--output <file>] [options]
    code-analysis clone <url> [--branch <name>] [--analyze] [options]
    code-analysis batch-clone <file> <target-dir> [--parallel] [--analyze] [options]
    code-analysis batch-pull <dir> [--repos <names>] [options]
    code-analysis git-status <dir> [--output <file>] [options]
    code-analysis scan-dir <path> [--output <file>] [--depth <n>] [options]
    code-analysis config [--show] [--init]
    code-analysis --version

Commands:
    review          代码审查
    review-commit   审查指定提交
    doc             生成文档
    arch            架构分析
    security        安全漏洞扫描
    clone           克隆仓库并分析
    batch-clone     批量克隆仓库（从文件读取URL列表）
    batch-pull      批量拉取更新
    git-status      查看多仓库状态
    scan-dir        扫描目录结构
    config          配置管理

Options:
    -c, --config <file>     配置文件路径
    --base-url <url>        LLM API 地址
    --api-key <key>         API 密钥
    -m, --model <name>      模型名称
    -o, --output <file>     输出文件路径
    -f, --format <format>   输出格式 (markdown/json)
    -w, --workers <n>       并发线程数 (默认: 5)
    --context               启用上下文增强分析（提供项目结构和依赖关系）
    --init                  初始化配置文件
    --show                  显示当前配置
    --deep                  深度扫描 (安全扫描)
    --branch <name>         克隆的分支名
    --analyze               克隆后自动分析
    --parallel              并行克隆
    --repos <names>         指定仓库名列表（逗号分隔）
    --depth <n>             扫描深度
"""

import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Optional

try:
    from docopt import docopt
except ImportError:
    print("错误: 缺少必要的依赖")
    print("请运行: pip install docopt httpx pyyaml")
    sys.exit(1)

try:
    import yaml
except ImportError:
    yaml = None

try:
    import httpx
except ImportError:
    print("错误: 缺少 httpx 依赖")
    print("请运行: pip install httpx")
    sys.exit(1)

from core import Config, Analyzer, GitHandler, BatchGitHandler
from core.ignore import get_default_ignore_patterns
from analyzers import (
    CodeReviewAnalyzer, DocumentationAnalyzer,
    ArchitectureAnalyzer, SecurityAnalyzer, DirectoryAnalyzer,
    ContextBuilder
)


__version__ = "0.4.0"


def _timestamp() -> str:
    """获取当前时间戳字符串"""
    from datetime import datetime
    return datetime.now().strftime("%H:%M:%S")


def _format_size(size: int) -> str:
    """格式化文件大小"""
    for unit in ["B", "KB", "MB"]:
        if size < 1024:
            return f"{size:.0f}{unit}"
        size /= 1024
    return f"{size:.1f}GB"


def _format_duration(seconds: float) -> str:
    """格式化持续时间"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = seconds % 60
    return f"{minutes}m {secs:.0f}s"


def _log(message: str, level: str = "INFO") -> None:
    """打印带时间戳和级别的日志"""
    level_styles = {
        "INFO": ("", ""),
        "OK": ("[OK] ", ""),
        "WARN": ("[WARN] ", ""),
        "ERROR": ("[ERROR] ", ""),
        "START": (">>> ", ""),
        "END": ("<<< ", ""),
        "DEBUG": ("  -> ", ""),
    }
    prefix, _ = level_styles.get(level, ("", ""))
    print(f"[{_timestamp()}] {prefix}{message}")


def _log_section(title: str) -> None:
    """打印分隔标题"""
    print()
    width = 50
    padding = (width - len(title) - 2) // 2
    print(f"{'=' * padding} {title} {'=' * padding}")


def _log_progress(current: int, total: int, message: str, elapsed: float = None) -> None:
    """打印进度日志，带百分比和预估时间"""
    percent = current / total * 100 if total > 0 else 0
    bar_width = 20
    filled = int(bar_width * current / total) if total > 0 else 0
    # 使用 ASCII 字符避免 Windows GBK 编码问题
    bar = "#" * filled + "-" * (bar_width - filled)

    extra = ""
    if elapsed and current > 0:
        # 预估剩余时间
        avg_time = elapsed / current
        remaining = avg_time * (total - current)
        extra = f" ETA: {_format_duration(remaining)}"

    print(f"[{_timestamp()}] [{bar}] {current}/{total} ({percent:.0f}%) {message}{extra}")


def _log_table(headers: list, rows: list, title: str = None) -> None:
    """打印表格格式的日志"""
    if title:
        print(f"\n  {title}")
        print(f"  {'-' * (len(title) + 2)}")

    # 计算列宽
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))

    # 打印表头
    header_line = "  | " + " | ".join(h.ljust(w) for h, w in zip(headers, widths)) + " |"
    print(header_line)
    print("  |" + "|".join("-" * (w + 2) for w in widths) + "|")

    # 打印数据行
    for row in rows:
        row_line = "  | " + " | ".join(str(c).ljust(w) for c, w in zip(row, widths)) + " |"
        print(row_line)


def get_default_output_path(target_path: str, prefix: str) -> Path:
    """生成默认输出文件路径

    Args:
        target_path: 分析的目标路径
        prefix: 报告类型前缀（如 review, security, arch）

    Returns:
        输出文件路径，格式为 result/目录名_时间戳.md
    """
    # 获取目录名
    target = Path(target_path).resolve()
    if target.is_file():
        dir_name = target.parent.name
    else:
        dir_name = target.name

    # 生成时间戳
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 创建 result 目录
    result_dir = Path("result")
    result_dir.mkdir(exist_ok=True)

    # 生成文件名
    filename = f"{dir_name}_{prefix}_{timestamp}.md"
    return result_dir / filename


def format_review_result(result, output_format: str = "markdown") -> str:
    """格式化审查结果"""
    if output_format == "json":
        return json.dumps({
            "file_path": result.file_path,
            "score": result.score,
            "issues": result.issues,
            "suggestions": result.suggestions,
            "summary": result.summary,
        }, ensure_ascii=False, indent=2)

    # Markdown 格式
    lines = [
        f"# 代码审查报告: {result.file_path}",
        "",
        f"**评分**: {result.score}/10",
        "",
    ]

    if result.issues:
        lines.append("## 问题列表")
        lines.append("")
        for issue in result.issues:
            severity_mark = {"high": "[HIGH]", "medium": "[MEDIUM]", "low": "[LOW]"}.get(
                issue.get("severity", "low"), "[INFO]"
            )
            line_info = f"行 {issue.get('line', '?')}" if issue.get("line") else ""
            lines.append(f"- {severity_mark} **{issue.get('type', 'unknown')}** {line_info}: {issue.get('description', '')}")
        lines.append("")

    if result.suggestions:
        lines.append("## 改进建议")
        lines.append("")
        for i, suggestion in enumerate(result.suggestions, 1):
            lines.append(f"{i}. {suggestion}")
        lines.append("")

    lines.append("## 总结")
    lines.append("")
    lines.append(result.summary)

    return "\n".join(lines)


def format_doc_result(result, output_format: str = "markdown") -> str:
    """格式化文档结果"""
    if output_format == "json":
        return json.dumps({
            "file_path": result.file_path,
            "doc_type": result.doc_type,
            "content": result.content,
            "success": result.success,
        }, ensure_ascii=False, indent=2)

    header = f"# 文档: {result.file_path}\n\n"
    header += f"**类型**: {result.doc_type}\n\n"
    header += "---\n\n"
    return header + result.content


def cmd_review(args: dict) -> int:
    """执行代码审查"""
    import time
    from collections import Counter

    target_path = args.get("<path>", ".")
    output_file = args.get("--output")
    output_format = args.get("--format", "markdown")
    workers = args.get("--workers")
    use_context = args.get("--context", False)

    # 处理 workers 参数
    max_workers = int(workers) if workers else None

    # 生成默认输出路径
    if not output_file:
        output_file = str(get_default_output_path(target_path, "review"))

    config = Config.create(
        config_file=args.get("--config"),
        base_url=args.get("--base-url"),
        api_key=args.get("--api-key"),
        model=args.get("--model"),
        target_path=target_path,
        output_format=output_format,
        max_workers=max_workers,
    )

    # 启动信息
    _log_section("代码审查")
    _log(f"目标: {target_path}", "START")
    _log(f"模型: {config.llm.model}")
    _log(f"API: {config.llm.base_url}")
    _log(f"并发: {config.analysis.max_workers} 线程")
    if use_context:
        _log("上下文增强: 已启用")

    results = []
    overall_start = time.time()

    with Analyzer(config) as analyzer:
        reviewer = CodeReviewAnalyzer(analyzer)

        # 扫描文件
        scan_start = time.time()
        _log("扫描文件中...")
        file_infos = list(analyzer.scan_files(target_path))
        scan_time = time.time() - scan_start
        total = len(file_infos)

        if total == 0:
            _log("未找到可分析的文件", "WARN")
            return 0

        # 统计文件类型和大小
        lang_count = Counter(fi.language for fi in file_infos)
        total_size = sum(fi.size for fi in file_infos)
        _log(f"扫描完成: {total} 个文件, {_format_size(total_size)} ({scan_time:.2f}s)", "OK")

        # 文件类型表格
        _log_table(
            ["语言", "文件数", "占比"],
            [(lang, str(count), f"{count/total*100:.1f}%")
             for lang, count in lang_count.most_common()],
            "语言分布"
        )

        # 构建上下文（如果启用）
        context = None
        context_builder = None
        if use_context:
            ctx_start = time.time()
            _log("构建分析上下文...")
            context_builder = ContextBuilder(analyzer)
            context = context_builder.build_context(target_path)
            ctx_time = time.time() - ctx_start

            dep_count = sum(len(v) for v in context.file_dependencies.values())
            _log(f"依赖解析: {len(context.file_dependencies)} 文件, {dep_count} 依赖 ({ctx_time:.2f}s)", "OK")

        # 进度回调
        completed_count = 0
        task_start_time = time.time()

        def progress_callback(current: int, total: int, file_path: str, status: str):
            nonlocal completed_count
            elapsed = time.time() - task_start_time

            if status == "started":
                # 简洁的启动日志
                pass  # 不显示启动，减少日志量
            else:
                completed_count = current
                _log_progress(current, total, f"完成: {file_path}", elapsed)

        # 选择分析函数
        if use_context and context_builder:
            analyze_func = lambda fi: reviewer.review_file_with_context(
                fi, context, context_builder
            )
        else:
            analyze_func = reviewer.review_file

        # 执行分析
        _log_section("分析中")
        results = analyzer.analyze_files_batch(
            file_infos,
            analyze_func,
            progress_callback=progress_callback,
        )

        # 汇总结果
        total_time = time.time() - overall_start
        _log_section("分析完成")

        success_count = sum(1 for r in results if r.success)
        fail_count = total - success_count

        # 统计摘要
        _log_table(
            ["指标", "值"],
            [
                ("成功", f"{success_count}/{total} ({success_count/total*100:.0f}%)"),
                ("失败", f"{fail_count}" if fail_count > 0 else "0"),
                ("总耗时", _format_duration(total_time)),
                ("平均耗时", f"{total_time/max(total, 1):.2f}s/文件"),
                ("处理速度", f"{total/max(total_time, 0.1):.1f} 文件/秒"),
            ],
            "执行统计"
        )

        # 问题统计
        if success_count > 0:
            total_issues = sum(len(r.issues) for r in results if r.success)
            avg_score = sum(r.score for r in results if r.success) / success_count

            # 按严重程度统计
            severity_count = {"high": 0, "medium": 0, "low": 0}
            for r in results:
                if r.success:
                    for issue in r.issues:
                        sev = issue.get("severity", "low")
                        if sev in severity_count:
                            severity_count[sev] += 1

            print()
            _log_table(
                ["指标", "值"],
                [
                    ("平均评分", f"{avg_score:.1f}/10"),
                    ("问题总数", str(total_issues)),
                    ("高危", f"{severity_count['high']} 个"),
                    ("中危", f"{severity_count['medium']} 个"),
                    ("低危", f"{severity_count['low']} 个"),
                ],
                "代码质量"
            )

        # 失败文件列表
        if fail_count > 0:
            print()
            _log("失败文件:", "WARN")
            for result in results:
                if not result.success:
                    error_msg = result.errors[0] if result.errors else "未知错误"
                    _log(f"  - {result.file_path}: {error_msg[:50]}", "ERROR")

    # 生成报告
    report_lines = [
        "# 代码审查报告",
        "",
        f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"**分析文件数**: {len(results)}",
        f"**总耗时**: {_format_duration(total_time)}",
        "",
        "---",
        "",
    ]

    total_score = 0
    total_issues = 0

    for result in results:
        total_score += result.score
        total_issues += len(result.issues)
        report_lines.append(format_review_result(result, output_format))
        report_lines.append("\n---\n")

    # 统计信息
    avg_score = total_score / len(results) if results else 0
    report_lines.insert(5, f"**平均评分**: {avg_score:.1f}/10")
    report_lines.insert(6, f"**问题总数**: {total_issues}")

    report = "\n".join(report_lines)

    if output_file:
        Path(output_file).write_text(report, encoding="utf-8")
        print()
        _log(f"报告已保存: {output_file}", "OK")

    return 0


def cmd_review_commit(args: dict) -> int:
    """审查指定提交"""
    commit_hash = args.get("<commit>", "HEAD")
    target_path = args.get("--path", ".")

    config = Config.create(
        config_file=args.get("--config"),
        base_url=args.get("--base-url"),
        api_key=args.get("--api-key"),
        model=args.get("--model"),
        target_path=target_path,
    )

    print(f"审查提交: {commit_hash}")
    print(f"仓库路径: {target_path}")
    print()

    with Analyzer(config) as analyzer:
        reviewer = CodeReviewAnalyzer(analyzer)
        result = reviewer.review_commit(commit_hash)

        if not result.success:
            print(f"错误: {result.errors}")
            return 1

        print(f"提交: {commit_hash}")
        print(f"作者: {result.metadata.get('author')}")
        print(f"变更文件: {len(result.metadata.get('files_changed', []))}")
        print()
        print(result.content)

    return 0


def cmd_doc(args: dict) -> int:
    """生成文档"""
    import time
    from collections import Counter

    target_path = args.get("<path>", ".")
    # docopt 在没有指定值时返回 True，需要处理
    doc_type = args.get("--type") or "module"
    if doc_type is True:
        doc_type = "module"
    output_file = args.get("--output")
    output_format = args.get("--format", "markdown")
    workers = args.get("--workers")

    max_workers = int(workers) if workers else None

    # 生成默认输出路径
    if not output_file:
        output_file = str(get_default_output_path(target_path, "doc"))

    config = Config.create(
        config_file=args.get("--config"),
        base_url=args.get("--base-url"),
        api_key=args.get("--api-key"),
        model=args.get("--model"),
        target_path=target_path,
        output_format=output_format,
        max_workers=max_workers,
    )

    _log(f"生成文档: {target_path}", "START")
    _log(f"文档类型: {doc_type}")
    _log(f"模型: {config.llm.model}")
    _log(f"并发数: {config.analysis.max_workers}")
    print()

    with Analyzer(config) as analyzer:
        doc_gen = DocumentationAnalyzer(analyzer)

        _log("扫描文件...")
        file_infos = list(analyzer.scan_files(target_path))
        total = len(file_infos)

        if total == 0:
            _log("未找到可分析的文件", "WARN")
            return 0

        # 统计文件类型
        lang_count = Counter(fi.language for fi in file_infos)
        _log(f"发现 {total} 个文件")
        for lang, count in lang_count.most_common(5):
            _log(f"  - {lang}: {count} 个文件")

        # 选择生成函数
        if doc_type == "api":
            generate_func = doc_gen.generate_api_doc
        else:
            generate_func = lambda f: doc_gen.generate_module_doc(f, doc_type)

        # 定义进度回调
        def progress_callback(current: int, total: int, file_path: str, status: str):
            if status == "started":
                _log(f"[{current}/{total}] 生成: {file_path}")
            else:
                _log(f"[{current}/{total}] 完成: {file_path}")

        # 使用并发分析
        start_time = time.time()
        _log_section("开始生成")
        results = analyzer.analyze_files_batch(
            file_infos,
            generate_func,
            progress_callback=progress_callback,
        )

        total_time = time.time() - start_time
        _log_section("生成完成")

        success_count = sum(1 for r in results if r.success)
        fail_count = total - success_count
        _log(f"成功: {success_count}/{total}", "OK" if success_count == total else "WARN")
        if fail_count > 0:
            _log(f"失败: {fail_count} 个文件", "ERROR")
        _log(f"总耗时: {total_time:.1f} 秒")

    # 输出结果到单个文件
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        for result in results:
            if not result.success:
                continue
            content = format_doc_result(result, output_format)
            f.write(content)
            f.write("\n\n---\n\n")

    print()
    _log(f"文档已保存: {output_path}", "OK")
    return 0


def cmd_config(args: dict) -> int:
    """配置管理"""
    if args.get("--init"):
        config_path = Config.get_default_config_path()
        config_path.parent.mkdir(parents=True, exist_ok=True)

        default_config = {
            "llm": {
                "base_url": "http://localhost:8000/v1",
                "api_key": "sk-dummy",
                "model": "qwen35-35b-a3b",
                "temperature": 0.7,
                "max_tokens": 4096,
            },
            "analysis": {
                "max_file_size": 102400,
                "max_workers": 5,
                "ignore_patterns": get_default_ignore_patterns(),
            },
        }

        if yaml is None:
            print("错误: 需要安装 PyYAML 才能初始化配置文件")
            print("运行: pip install pyyaml")
            return 1

        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(default_config, f, default_flow_style=False, allow_unicode=True)

        print(f"配置文件已创建: {config_path}")
        return 0

    if args.get("--show"):
        config = Config.create()
        if yaml:
            print(yaml.dump(config.to_dict(), default_flow_style=False, allow_unicode=True))
        else:
            print(config.to_dict())
        return 0

    print("使用 --init 初始化配置文件，或使用 --show 查看当前配置")
    return 1


def cmd_arch(args: dict) -> int:
    """执行架构分析"""
    target_path = args.get("<path>", ".")
    output_file = args.get("--output")
    output_format = args.get("--format", "markdown")

    # 生成默认输出路径
    if not output_file:
        output_file = str(get_default_output_path(target_path, "arch"))

    config = Config.create(
        config_file=args.get("--config"),
        base_url=args.get("--base-url"),
        api_key=args.get("--api-key"),
        model=args.get("--model"),
        target_path=target_path,
        output_format=output_format,
    )

    print(f"架构分析: {target_path}")
    print(f"使用模型: {config.llm.model}")
    print()

    with Analyzer(config) as analyzer:
        arch_analyzer = ArchitectureAnalyzer(analyzer)
        result = arch_analyzer.analyze(target_path)

    # 格式化输出
    if output_format == "json":
        output = json.dumps({
            "total_files": result.total_files,
            "total_lines": result.total_lines,
            "languages": result.languages,
            "coupling_score": result.coupling_score,
            "cohesion_score": result.cohesion_score,
            "circular_dependencies": result.circular_dependencies,
            "summary": result.summary,
            "suggestions": result.suggestions,
        }, ensure_ascii=False, indent=2)
    else:
        lines = [
            "# 架构分析报告",
            "",
            f"**分析时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"**目标路径**: {target_path}",
            "",
            "---",
            "",
            "## 项目统计",
            "",
            f"- 文件总数: {result.total_files}",
            f"- 代码行数: {result.total_lines}",
            "",
            "### 语言分布",
            "",
        ]
        for lang, count in result.languages.items():
            lines.append(f"- {lang}: {count} 个文件")

        lines.extend([
            "",
            "## 架构指标",
            "",
            f"- **耦合度**: {result.coupling_score:.1f}/100 (越低越好)",
            f"- **内聚度**: {result.cohesion_score:.1f}/100 (越高越好)",
            "",
        ])

        if result.circular_dependencies:
            lines.append("### 循环依赖")
            lines.append("")
            for src, tgt in result.circular_dependencies:
                lines.append(f"- {src} <-> {tgt}")
            lines.append("")

        lines.extend([
            "## 总结",
            "",
            result.summary,
            "",
            "## 改进建议",
            "",
        ])
        for i, suggestion in enumerate(result.suggestions, 1):
            lines.append(f"{i}. {suggestion}")

        output = "\n".join(lines)

    if output_file:
        Path(output_file).write_text(output, encoding="utf-8")
        print(f"\n报告已保存到: {output_file}")
    else:
        print(output)

    return 0


def cmd_security(args: dict) -> int:
    """执行安全扫描"""
    target_path = args.get("<path>", ".")
    deep_scan = args.get("--deep", False)
    output_file = args.get("--output")
    output_format = args.get("--format", "markdown")
    workers = args.get("--workers")

    max_workers = int(workers) if workers else None

    # 生成默认输出路径
    if not output_file:
        output_file = str(get_default_output_path(target_path, "security"))

    config = Config.create(
        config_file=args.get("--config"),
        base_url=args.get("--base-url"),
        api_key=args.get("--api-key"),
        model=args.get("--model"),
        target_path=target_path,
        output_format=output_format,
        max_workers=max_workers,
    )

    print(f"安全扫描: {target_path}")
    print(f"扫描模式: {'深度扫描' if deep_scan else '快速扫描'}")
    print(f"使用模型: {config.llm.model}")
    print(f"并发线程: {config.analysis.max_workers}")
    print()

    with Analyzer(config) as analyzer:
        security = SecurityAnalyzer(analyzer)
        results = security.scan_project(target_path, deep=deep_scan)

    # 统计
    total_issues = sum(len(r.issues) for r in results)
    total_risk = sum(r.risk_score for r in results) / len(results) if results else 0

    print(f"扫描完成: {len(results)} 个文件, {total_issues} 个问题")
    print(f"风险评分: {total_risk:.1f}/100")

    # 格式化输出
    if output_format == "json":
        output = json.dumps({
            "total_files": len(results),
            "total_issues": total_issues,
            "average_risk_score": total_risk,
            "files": [
                {
                    "path": r.file_path,
                    "issues": [
                        {
                            "type": i.type,
                            "severity": i.severity,
                            "line": i.line,
                            "description": i.description,
                            "recommendation": i.recommendation,
                        }
                        for i in r.issues
                    ],
                    "risk_score": r.risk_score,
                    "passed": r.passed,
                }
                for r in results if r.issues
            ],
        }, ensure_ascii=False, indent=2)
    else:
        lines = [
            "# 安全扫描报告",
            "",
            f"**扫描时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"**目标路径**: {target_path}",
            f"**扫描模式**: {'深度扫描' if deep_scan else '快速扫描'}",
            "",
            "---",
            "",
            "## 扫描摘要",
            "",
            f"- 扫描文件数: {len(results)}",
            f"- 发现问题数: {total_issues}",
            f"- 风险评分: {total_risk:.1f}/100",
            "",
        ]

        severity_count = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for r in results:
            for issue in r.issues:
                severity_count[issue.severity] += 1

        lines.append("### 问题严重程度分布")
        lines.append("")
        lines.append(f"- [CRITICAL] {severity_count['critical']} 个")
        lines.append(f"- [HIGH] {severity_count['high']} 个")
        lines.append(f"- [MEDIUM] {severity_count['medium']} 个")
        lines.append(f"- [LOW] {severity_count['low']} 个")
        lines.append("")

        # 详细问题
        lines.append("## 详细问题列表")
        lines.append("")

        for result in results:
            if result.issues:
                lines.append(f"### {result.file_path}")
                lines.append(f"风险评分: {result.risk_score}")
                lines.append("")
                for issue in result.issues:
                    severity_mark = {
                        "critical": "[CRITICAL]",
                        "high": "[HIGH]",
                        "medium": "[MEDIUM]",
                        "low": "[LOW]",
                    }.get(issue.severity, "[INFO]")
                    lines.append(f"- {severity_mark} **{issue.type}** 行 {issue.line}: {issue.description}")
                    lines.append(f"  建议: {issue.recommendation}")
                lines.append("")

        output = "\n".join(lines)

    if output_file:
        Path(output_file).write_text(output, encoding="utf-8")
        print(f"\n报告已保存到: {output_file}")
    else:
        print("\n" + "=" * 50)
        print(output)

    return 0


def cmd_clone(args: dict) -> int:
    """克隆仓库并分析"""
    repo_url = args.get("<url>")
    branch = args.get("--branch")
    analyze = args.get("--analyze", False)
    output_file = args.get("--output")

    print(f"克隆仓库: {repo_url}")

    # 克隆仓库
    try:
        handler = GitHandler.clone(repo_url)
        repo_path = str(handler.repo_path)
        print(f"克隆完成: {repo_path}")
    except Exception as e:
        print(f"克隆失败: {e}")
        return 1

    if not analyze:
        print(f"仓库已克隆到: {repo_path}")
        print("使用 --analyze 参数进行自动分析")
        return 0

    # 执行分析
    print("\n开始分析...")

    config = Config.create(
        config_file=args.get("--config"),
        base_url=args.get("--base-url"),
        api_key=args.get("--api-key"),
        model=args.get("--model"),
        target_path=repo_path,
    )

    with Analyzer(config) as analyzer:
        # 代码审查
        print("\n=== 代码审查 ===")
        reviewer = CodeReviewAnalyzer(analyzer)
        file_infos = list(analyzer.scan_files(repo_path))

        for i, file_info in enumerate(file_infos[:5], 1):  # 限制数量
            print(f"[{i}] {file_info.relative_path}")
            result = reviewer.review_file(file_info)
            if result.success:
                print(f"    评分: {result.score}/10")

    return 0


def cmd_batch_clone(args: dict) -> int:
    """批量克隆仓库"""
    file_path = args.get("<file>")
    target_dir = args.get("<target-dir>")
    parallel = args.get("--parallel", False)
    analyze = args.get("--analyze", False)
    output_file = args.get("--output")

    # 读取 URL 列表
    urls = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    urls.append(line)
    except FileNotFoundError:
        print(f"错误: 文件不存在: {file_path}")
        return 1

    if not urls:
        print("错误: 未找到有效的仓库 URL")
        return 1

    print(f"批量克隆: {len(urls)} 个仓库")
    print(f"目标目录: {target_dir}")
    print(f"并行模式: {'是' if parallel else '否'}")
    print()

    # 执行批量克隆
    def progress_callback(url: str, current: int, total: int):
        print(f"[{current}/{total}] 克隆: {url}")

    result = BatchGitHandler.batch_clone(
        urls=urls,
        target_dir=target_dir,
        parallel=parallel,
        max_workers=4,
        progress_callback=progress_callback if not output_file else None,
    )

    print()
    print(f"完成: 成功 {result.success} 个, 失败 {result.failed} 个")

    # 生成报告
    lines = [
        "# 批量克隆报告",
        "",
        f"**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"**目标目录**: {target_dir}",
        "",
        f"- 总数: {result.total}",
        f"- 成功: {result.success}",
        f"- 失败: {result.failed}",
        "",
    ]

    if result.results:
        lines.append("## 详细结果")
        lines.append("")
        for r in result.results:
            if r["success"]:
                lines.append(f"- ✅ {r['repo']}: {r.get('message', '')}")
            else:
                lines.append(f"- ❌ {r['repo']}: {r.get('error', '')}")

    report = "\n".join(lines)

    if output_file:
        Path(output_file).write_text(report, encoding="utf-8")
        print(f"\n报告已保存到: {output_file}")

    # 如果需要分析
    if analyze and result.success > 0:
        print("\n开始批量分析...")
        cmd_scan_dir({"<path>": target_dir, "--output": output_file, "--depth": 3})

    return 0 if result.failed == 0 else 1


def cmd_batch_pull(args: dict) -> int:
    """批量拉取更新"""
    dir_path = args.get("<dir>")
    repos_str = args.get("--repos")
    output_file = args.get("--output")

    # 解析指定仓库
    repos = None
    if repos_str:
        repos = [r.strip() for r in repos_str.split(",")]

    print(f"批量拉取: {dir_path}")
    if repos:
        print(f"指定仓库: {repos}")
    print()

    handler = BatchGitHandler(dir_path)

    # 先获取状态
    print("获取仓库状态...")
    repo_infos = handler.get_all_repos_info()
    print(f"发现 {len(repo_infos)} 个仓库")
    print()

    # 执行拉取
    print("开始拉取更新...")
    result = handler.batch_pull(repos)

    print()
    print(f"完成: 成功 {result.success} 个, 失败 {result.failed} 个")

    # 生成报告
    report = handler.generate_status_report(repo_infos)

    if output_file:
        Path(output_file).write_text(report, encoding="utf-8")
        print(f"\n报告已保存到: {output_file}")
    else:
        print("\n" + "=" * 50)
        print(report)

    return 0 if result.failed == 0 else 1


def cmd_git_status(args: dict) -> int:
    """查看多仓库状态"""
    dir_path = args.get("<dir>")
    output_file = args.get("--output")

    # 生成默认输出路径
    if not output_file:
        output_file = str(get_default_output_path(dir_path, "git_status"))

    print(f"扫描仓库: {dir_path}")
    print()

    handler = BatchGitHandler(dir_path)
    repo_infos = handler.get_all_repos_info()

    if not repo_infos:
        print("未找到 Git 仓库")
        return 0

    print(f"发现 {len(repo_infos)} 个仓库:")
    print()

    # 状态标记
    status_marks = {
        "clean": "✅",
        "modified": "📝",
        "ahead": "⬆️",
        "behind": "⬇️",
        "diverged": "↔️",
        "error": "❌",
    }

    for info in repo_infos:
        mark = status_marks.get(info.status.value, "❓")
        print(f"{mark} {info.name}")
        print(f"   分支: {info.branch}")
        if info.remote_url:
            print(f"   远程: {info.remote_url}")
        if info.staged_files or info.unstaged_files:
            print(f"   变更: +{info.staged_files} staged, +{info.unstaged_files} unstaged")
        if info.ahead or info.behind:
            print(f"   同步: ahead {info.ahead}, behind {info.behind}")
        if info.error:
            print(f"   错误: {info.error}")
        print()

    # 生成报告
    report = handler.generate_status_report(repo_infos)

    # 保存报告
    Path(output_file).write_text(report, encoding="utf-8")
    print(f"报告已保存到: {output_file}")

    return 0


def cmd_scan_dir(args: dict) -> int:
    """扫描目录结构"""
    path = args.get("<path>")
    output_file = args.get("--output")
    depth = int(args.get("--depth", 5))

    # 生成默认输出路径
    if not output_file:
        output_file = str(get_default_output_path(path, "scan"))

    print(f"扫描目录: {path}")
    print(f"深度: {depth}")
    print()

    analyzer = DirectoryAnalyzer()

    try:
        result = analyzer.analyze(path, max_depth=depth)
    except FileNotFoundError as e:
        print(f"错误: {e}")
        return 1

    # 输出摘要
    print(f"总文件数: {result.total_files:,}")
    print(f"总目录数: {result.total_dirs:,}")
    print(f"总大小: {analyzer._format_size(result.total_size)}")
    print()

    # 项目信息
    if result.projects:
        print("发现项目:")
        for project in result.projects:
            print(f"  - {project.name} ({project.project_type.value})")
            if project.languages:
                top_lang = list(project.languages.items())[0]
                print(f"    主要语言: {top_lang[0]} ({top_lang[1]}%)")
            if project.tech_stack:
                print(f"    技术栈: {', '.join(t.name for t in project.tech_stack[:5])}")
        print()

    # 文件类型
    print("文件类型分布 (前 10):")
    for ext, count in list(result.file_extensions.items())[:10]:
        ext_display = ext or "(无扩展名)"
        print(f"  {ext_display}: {count:,}")
    print()

    # 生成报告
    report = analyzer.generate_report(result)

    # 保存报告
    Path(output_file).write_text(report, encoding="utf-8")
    print(f"\n报告已保存到: {output_file}")

    return 0


def main():
    """主入口"""
    args = docopt(__doc__, version=f"code-analysis {__version__}")

    if args.get("review"):
        return cmd_review(args)
    elif args.get("review-commit"):
        return cmd_review_commit(args)
    elif args.get("doc"):
        return cmd_doc(args)
    elif args.get("arch"):
        return cmd_arch(args)
    elif args.get("security"):
        return cmd_security(args)
    elif args.get("clone"):
        return cmd_clone(args)
    elif args.get("batch-clone"):
        return cmd_batch_clone(args)
    elif args.get("batch-pull"):
        return cmd_batch_pull(args)
    elif args.get("git-status"):
        return cmd_git_status(args)
    elif args.get("scan-dir"):
        return cmd_scan_dir(args)
    elif args.get("config"):
        return cmd_config(args)

    return 0


if __name__ == "__main__":
    sys.exit(main())
