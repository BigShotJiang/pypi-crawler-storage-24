class ReplayError(Exception):
    pass