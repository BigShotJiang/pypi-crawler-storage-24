"""HTTP API client for pillfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install pillfyi[api]``

Usage::

    from pillfyi.api import PillFYI

    with PillFYI() as api:
        items = api.list_conditions()
        detail = api.get_condition("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class PillFYI:
    """API client for the pillfyi.com REST API.

    Provides typed access to all pillfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://pillfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://pillfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_conditions(self, **params: Any) -> dict[str, Any]:
        """List all conditions."""
        return self._get("/api/v1/conditions/", **params)

    def get_condition(self, slug: str) -> dict[str, Any]:
        """Get condition by slug."""
        return self._get(f"/api/v1/conditions/" + slug + "/")

    def list_drug_classes(self, **params: Any) -> dict[str, Any]:
        """List all drug classes."""
        return self._get("/api/v1/drug-classes/", **params)

    def get_drug_classe(self, slug: str) -> dict[str, Any]:
        """Get drug classe by slug."""
        return self._get(f"/api/v1/drug-classes/" + slug + "/")

    def list_drug_conditions(self, **params: Any) -> dict[str, Any]:
        """List all drug conditions."""
        return self._get("/api/v1/drug-conditions/", **params)

    def get_drug_condition(self, slug: str) -> dict[str, Any]:
        """Get drug condition by slug."""
        return self._get(f"/api/v1/drug-conditions/" + slug + "/")

    def list_drug_side_effects(self, **params: Any) -> dict[str, Any]:
        """List all drug side effects."""
        return self._get("/api/v1/drug-side-effects/", **params)

    def get_drug_side_effect(self, slug: str) -> dict[str, Any]:
        """Get drug side effect by slug."""
        return self._get(f"/api/v1/drug-side-effects/" + slug + "/")

    def list_drugs(self, **params: Any) -> dict[str, Any]:
        """List all drugs."""
        return self._get("/api/v1/drugs/", **params)

    def get_drug(self, slug: str) -> dict[str, Any]:
        """Get drug by slug."""
        return self._get(f"/api/v1/drugs/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_interactions(self, **params: Any) -> dict[str, Any]:
        """List all interactions."""
        return self._get("/api/v1/interactions/", **params)

    def get_interaction(self, slug: str) -> dict[str, Any]:
        """Get interaction by slug."""
        return self._get(f"/api/v1/interactions/" + slug + "/")

    def list_manufacturers(self, **params: Any) -> dict[str, Any]:
        """List all manufacturers."""
        return self._get("/api/v1/manufacturers/", **params)

    def get_manufacturer(self, slug: str) -> dict[str, Any]:
        """Get manufacturer by slug."""
        return self._get(f"/api/v1/manufacturers/" + slug + "/")

    def list_side_effects(self, **params: Any) -> dict[str, Any]:
        """List all side effects."""
        return self._get("/api/v1/side-effects/", **params)

    def get_side_effect(self, slug: str) -> dict[str, Any]:
        """Get side effect by slug."""
        return self._get(f"/api/v1/side-effects/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> PillFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
