"""Core simulator components."""
