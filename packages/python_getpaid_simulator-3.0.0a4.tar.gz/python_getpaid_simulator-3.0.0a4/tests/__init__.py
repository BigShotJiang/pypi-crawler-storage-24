"""Tests for getpaid-simulator."""
