"""Centralized notebook utilities for CxO-grade JupyterLab interactivity.

Install: pip install runbooks[jupyter]

Usage in any .ipynb:
    from runbooks.notebooks.widgets import build_config_form
    from runbooks.notebooks.helpers import run_cli, validate_auth
"""

from runbooks.notebooks.helpers import (
    run_cli,
    risk_level,
    filter_expiring,
    filter_removable,
    build_email,
    validate_auth,
    detect_workspace,
    assign_tier,
    format_cost,
    build_cli_command,
    parse_dashboard_json,
    render_cost_summary,
    export_evidence,
)

__all__ = [
    "run_cli",
    "risk_level",
    "filter_expiring",
    "filter_removable",
    "build_email",
    "validate_auth",
    "detect_workspace",
    "assign_tier",
    "format_cost",
    "build_cli_command",
    "parse_dashboard_json",
    "render_cost_summary",
    "export_evidence",
]
