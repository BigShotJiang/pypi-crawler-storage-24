"""
Math utilities for FinOps calculations.

SSOT for $/day normalized percentage change — used by all dashboard renderers.
"""


def calculate_daily_rate_change(
    current_cost: float, previous_cost: float, current_days: int, previous_days: int
) -> float:
    """
    Calculate % change using $/day normalization.

    Same unit of measure ($/day) ensures fair comparison between periods
    of different lengths (e.g., 28-day Feb vs 31-day Jan).

    Args:
        current_cost: Cost for current period
        previous_cost: Cost for previous period
        current_days: Number of days in current period
        previous_days: Number of days in previous period

    Returns:
        Percentage change between daily rates. None if no baseline.
    """
    if previous_cost <= 0 or previous_days <= 0:
        return 100.0 if current_cost > 0 else 0.0

    current_daily = current_cost / max(current_days, 1)
    previous_daily = previous_cost / max(previous_days, 1)

    if previous_daily <= 0:
        return 100.0 if current_daily > 0 else 0.0

    return ((current_daily - previous_daily) / previous_daily) * 100
