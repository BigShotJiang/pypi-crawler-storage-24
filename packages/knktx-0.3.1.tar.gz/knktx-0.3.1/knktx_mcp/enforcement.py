"""Step renderer — converts workflows and rules into human-readable markdown.

Used by both the MCP server (get_workflows output) and the CLI (CLAUDE.md injection).
No runtime enforcement — just rendering.
"""

from __future__ import annotations

import json
from collections import defaultdict
from typing import Any, TypedDict

__all__ = ["StepData", "WorkflowData", "RuleData", "render_workflows", "render_rules"]


class StepData(TypedDict, total=False):
    """Expected shape of a workflow step from the API."""

    type: str
    action: str
    label: str
    config: dict[str, Any]
    position: int
    agents: list[str] | None


class WorkflowData(TypedDict, total=False):
    """Expected shape of a workflow from the API."""

    id: str
    name: str
    enabled: bool
    description: str
    project_id: str | None
    trigger_type: str
    trigger_config: dict[str, Any]
    steps: list[StepData]
    agents: list[str] | None


class RuleData(TypedDict, total=False):
    """Expected shape of a rule from the API."""

    name: str
    description: str
    rule_type: str
    config: dict[str, Any]
    source: str
    enabled: bool
    agents: list[str] | None


def _step_visible(step: StepData, agent: str | None) -> bool:
    """Return True if *step* should be rendered for *agent*.

    Steps with no ``agents`` restriction (``None`` or empty list) are always
    visible.  Steps with a non-empty ``agents`` list are only visible when
    *agent* is in the list.
    """
    if agent is None:
        return True
    step_agents = step.get("agents")
    if not step_agents:
        return True
    return agent in step_agents


def render_workflows(workflows: list[WorkflowData], *, agent: str | None = None) -> str:
    """Render enabled workflows as structured markdown.

    When *agent* is set, steps whose ``agents`` list does not include that agent
    are silently skipped.
    """
    enabled = [w for w in workflows if w.get("enabled", True)]
    if not enabled:
        return "No active workflows found."

    lines: list[str] = []
    for wf in enabled:
        wf_id = wf.get("id", "")
        scope = "project" if wf.get("project_id") else "global"

        # Header
        lines.append(f"# {wf.get('name', '(unnamed)')}")
        meta_parts: list[str] = []
        if wf_id:
            meta_parts.append(f"ID: {wf_id}")
        if wf.get("trigger_type") == "event" and wf.get("trigger_config"):
            tc = wf["trigger_config"]
            trigger = f"Trigger: {tc.get('entity_type', '?')}.{tc.get('action', '?')}"
            if tc.get("filter"):
                trigger += f" -> {json.dumps(tc['filter'])}"
            meta_parts.append(trigger)
        elif wf.get("trigger_type") == "manual":
            meta_parts.append("Trigger: manual")
        meta_parts.append(f"Scope: {scope}")
        lines.append(" | ".join(meta_parts))

        if wf.get("description"):
            lines.append(wf["description"])
        lines.append("")

        steps = [s for s in wf.get("steps", []) if _step_visible(s, agent)]
        if not steps:
            if agent and wf.get("steps"):
                lines.append(f"(no steps for agent '{agent}')")
            else:
                lines.append("(no steps defined)")
        for i, step in enumerate(steps, 1):
            step_type = step.get("type", "?")
            label = step.get("label", "")

            if step_type == "instruction":
                text = step.get("config", {}).get("text", label)
                lines.append(f"{i}. {text}")
            elif step_type == "knktx_action":
                action = step.get("action", "")
                lines.append(f"{i}. [{action}] {label}")
            else:
                # Unrecognized step types — render generically
                action = step.get("action", "")
                if action:
                    lines.append(f"{i}. [{step_type}: {action}] {label}")
                else:
                    lines.append(f"{i}. [{step_type}] {label}")
        lines.append("")

    return "\n".join(lines).strip()


def render_rules(rules: list[RuleData]) -> str:
    """Render rules as human-readable markdown."""
    if not rules:
        return ""

    grouped: defaultdict[str, list[RuleData]] = defaultdict(list)
    for rule in rules:
        grouped[rule.get("rule_type", "unknown")].append(rule)

    type_order = ["prohibition", "obligation", "preference"]
    type_labels = {
        "prohibition": "Prohibitions",
        "obligation": "Obligations",
        "preference": "Preferences",
    }

    def _rule_line(rule: RuleData) -> str:
        name = rule.get("name", "(unnamed)")
        desc = rule.get("description") or rule.get("config", {}).get("message", "")
        hook_tag = " *(shell hook)*" if rule.get("config", {}).get("enforce_hooks") else ""
        return f"- **{name}**: {desc}{hook_tag}" if desc else f"- **{name}**{hook_tag}"

    lines: list[str] = ["# Rules", ""]

    for rt in type_order:
        group = grouped.get(rt, [])
        if not group:
            continue
        lines.append(f"## {type_labels[rt]}")
        for rule in group:
            lines.append(_rule_line(rule))
        lines.append("")

    # Unrecognized rule types
    for rt, group in grouped.items():
        if rt in type_order:
            continue
        lines.append(f"## {rt.title()}")
        for rule in group:
            lines.append(_rule_line(rule))
        lines.append("")

    return "\n".join(lines).strip()
