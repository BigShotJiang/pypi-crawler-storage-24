"""knktx MCP server — pip-installable MCP server for AI agents."""
