class TestResult:
    """
    Unified result object for statistical tests.
    """

    def __init__(self, statistic, pvalue, ci=None, method=None):
        self.statistic = statistic
        self.pvalue = pvalue
        self.ci = ci
        self.method = method

    def __repr__(self):

        ci_str = ""
        if self.ci:
            ci_str = f"\nCI: {self.ci}"

        return (
            f"TestResult\n"
            f"Statistic: {self.statistic}\n"
            f"P-value: {self.pvalue}\n"
            f"Method: {self.method}"
            f"{ci_str}"
        )