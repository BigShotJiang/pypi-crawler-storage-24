import numpy as np


def bootstrap_mean_test(x, y, n_resamples=10000, confidence=0.95):

    x = np.asarray(x)
    y = np.asarray(y)

    observed = np.mean(x) - np.mean(y)

    combined = np.concatenate([x, y])

    stats = []

    for _ in range(n_resamples):

        xb = np.random.choice(x, size=len(x), replace=True)
        yb = np.random.choice(y, size=len(y), replace=True)

        stats.append(np.mean(xb) - np.mean(yb))

    stats = np.array(stats)

    pvalue = np.mean(np.abs(stats) >= abs(observed))

    alpha = 1 - confidence

    lower = np.percentile(stats, 100 * alpha / 2)
    upper = np.percentile(stats, 100 * (1 - alpha / 2))

    return observed, pvalue, (lower, upper)