from .test import mean

__all__ = ["mean"]