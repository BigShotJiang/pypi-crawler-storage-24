import numpy as np
from scipy import stats

from .bootstrap import bootstrap_mean_test
from .permutation import permutation_mean_test
from .result import TestResult


def mean(x, y, method="parametric", confidence=0.95, n_resamples=10000):

    x = np.asarray(x)
    y = np.asarray(y)

    if method == "parametric":

        statistic, pvalue = stats.ttest_ind(x, y)

        return TestResult(statistic, pvalue, method="t-test")

    elif method == "bootstrap":

        statistic, pvalue, ci = bootstrap_mean_test(
            x, y, n_resamples=n_resamples, confidence=confidence
        )

        return TestResult(statistic, pvalue, ci=ci, method="bootstrap")

    elif method == "permutation":

        statistic, pvalue = permutation_mean_test(
            x, y, n_resamples=n_resamples
        )

        return TestResult(statistic, pvalue, method="permutation")

    else:
        raise ValueError("method must be parametric, bootstrap, or permutation")