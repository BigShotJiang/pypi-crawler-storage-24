import numpy as np


def permutation_mean_test(x, y, n_resamples=10000):

    x = np.asarray(x)
    y = np.asarray(y)

    observed = np.mean(x) - np.mean(y)

    combined = np.concatenate([x, y])

    n_x = len(x)

    stats = []

    for _ in range(n_resamples):

        np.random.shuffle(combined)

        new_x = combined[:n_x]
        new_y = combined[n_x:]

        stats.append(np.mean(new_x) - np.mean(new_y))

    stats = np.array(stats)

    pvalue = np.mean(np.abs(stats) >= abs(observed))

    return observed, pvalue