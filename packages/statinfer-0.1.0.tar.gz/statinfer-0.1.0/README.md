# statinfer

Simple statistical inference library.

Features:

- Mean test
- Bootstrap inference
- Permutation tests

## Installation

pip install statinfer

## Example

from statinfer import mean

x = [1,2,3]
y = [4,5,6]

result = mean(x,y,method="bootstrap")

print(result)