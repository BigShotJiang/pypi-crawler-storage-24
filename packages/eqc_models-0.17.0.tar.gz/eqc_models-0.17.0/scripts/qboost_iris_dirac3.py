# (C) Quantum Computing Inc., 2024.
import os
import sys
from collections import Counter
import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    confusion_matrix,
    precision_score,
    recall_score,
    accuracy_score,
)

from eqc_models.ml.classifierqboost import QBoostClassifier
from eqc_models.ml.utils import get_binary_classification_metrics


# Set parameters
TEST_SIZE = 0.2
SOLVER_ACCESS = "cloud"
API_URL = os.environ.get("QCI_API_URL")
API_TOKEN = os.environ.get("QCI_TOKEN")
IP_ADDR = os.environ.get("DEVICE_IP_ADDRESS", "172.18.41.58")
PORT = os.environ.get("DEVICE_PORT", "50051")

# Read dataset
iris = datasets.load_iris()
X = iris.data
y = iris.target

# Pre-Process
scaler = MinMaxScaler()
X = scaler.fit_transform(X)

for i in range(len(y)):
    if y[i] == 0:
        y[i] = -1
    elif y[i] == 2:
        y[i] = 1

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=TEST_SIZE,
    random_state=42,
)
print(Counter(y_train))
print(X_train.shape)
print(y_train.shape)

print(Counter(y_test))
print(X_test.shape)
print(y_test.shape)

# Get QBoost model
obj = QBoostClassifier(
    relaxation_schedule=2,
    num_samples=1,
    solver_access=SOLVER_ACCESS,
    api_url=API_URL,
    api_token=API_TOKEN,
    ip_addr=IP_ADDR,
    port=PORT,
    lambda_coef=0.0,
    weak_cls_schedule=1,
    weak_cls_pair_count=None,
)

# Train
obj.fit(X_train, y_train)

y_train_prd = obj.predict_raw(X_train)
y_test_prd = obj.predict_raw(X_test)

print(Counter(y_train_prd))
print(Counter(y_test_prd))

print(
    "Train data metrics:",
    get_binary_classification_metrics(
        y_train,
        y_train_prd,
        positive_label=1,
        negative_label=-1,
        threshold=0,
    ),
)

print(
    "Test data metrics:",
    get_binary_classification_metrics(
        y_test,
        y_test_prd,
        positive_label=1,
        negative_label=-1,
        threshold=0,
    ),
)
