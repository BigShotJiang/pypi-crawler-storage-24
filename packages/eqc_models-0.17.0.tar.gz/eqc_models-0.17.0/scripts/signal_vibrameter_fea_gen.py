import numpy as np
from eqc_models.ml.signal import VibrometerFeatureGenerator

# Create a simple toy signal
fs = 1000  # sampling frequency (Hz)
T = 1.0  # duration (seconds)
times = np.linspace(0, T, int(fs * T), endpoint=False)

# 50 Hz sine wave + small noise
freq = 200.0
photon_counts = np.sin(2 * np.pi * freq * times) + 0.01 * np.random.randn(
    len(times)
)

# Call feature generator
obj = VibrometerFeatureGenerator(use_reservoir=False)
features = obj.get_features(times, photon_counts)

print(features)
# Inspect results
print("Number of features:", len(features))
for k, v in features.items():
    print(f"{k:20s}: {v:.6f}")
