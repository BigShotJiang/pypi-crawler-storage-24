import os
import sys
import numpy as np
import pandas as pd

from eqc_models.ml.feature_selection import FeatureSelector

# Parameters
NUM_RECORDS = 200
SEL_FEA_COUNT = 2

RELAXATION_SCHEDULE = 1
NUM_SAMPELS = 1
SOLVER_ACCESS = "cloud"
API_URL = os.environ.get("QCI_API_URL")
API_TOKEN = os.environ.get("QCI_TOKEN")
IP_ADDR = os.environ.get("DEVICE_IP_ADDRESS", "172.18.41.79")
PORT = os.environ.get("DEVICE_PORT", "50051")

# Build features
np.random.seed(0)
x1 = np.random.uniform(-1, 1, NUM_RECORDS)
x2 = np.random.uniform(-1, 1, NUM_RECORDS)
x3 = x1 + 0.01 * np.random.randn(NUM_RECORDS)
x4 = np.random.randn(NUM_RECORDS)
x5 = np.random.randn(NUM_RECORDS)
X = np.column_stack([x1, x2, x3, x4, x5])

# Target depends nonlinearly
y = np.sin(3 * x1) + (x2 ** 2) + 0.05 * np.random.randn(NUM_RECORDS)

# Run feature selection
obj = FeatureSelector(
    selected_fea_count=SEL_FEA_COUNT,
    fea_target_coef=1.0,
    gamma=0.1,
    correlation_type="mutual_information",
    solver_access=SOLVER_ACCESS,
    relaxation_schedule=RELAXATION_SCHEDULE,
    num_samples=NUM_SAMPELS,
    api_url=API_URL,
    api_token=API_TOKEN,
    ip_addr=IP_ADDR,
    port=PORT,
)

sel_fea_inds = obj.select_features(X, y)

print(sel_fea_inds)

assert (sel_fea_inds[0] == 1 or sel_fea_inds[2] == 1)
assert sel_fea_inds[1] == 1
assert sum(sel_fea_inds) == SEL_FEA_COUNT
