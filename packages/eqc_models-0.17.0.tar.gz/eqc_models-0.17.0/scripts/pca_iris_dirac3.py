# (C) Quantum Computing Inc., 2024.
import os
import numpy as np
from sklearn import datasets
from sklearn.preprocessing import normalize, StandardScaler
from sklearn.decomposition import PCA as PCA_cls
from eqc_models.ml.decomposition import PCA

# Set parameters
N_COMPONENTS = 4
SOLVER_ACCESS = "cloud"
API_URL = os.environ.get("QCI_API_URL")
API_TOKEN = os.environ.get("QCI_TOKEN")
IP_ADDR = os.environ.get("DEVICE_IP_ADDRESS", "172.18.41.58")
PORT = os.environ.get("DEVICE_PORT", "50051")

# Read dataset
iris = datasets.load_iris()
X = iris.data

# Train/test split (minimal)
np.random.seed(42)
perm = np.random.permutation(X.shape[0])
n_test = int(0.25 * X.shape[0])
test_id = perm[:n_test]
train_id = perm[n_test:]

X_train = X[train_id]
X_test = X[test_id]

# Scale on train only (avoid leakage)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

print("Train data shape:", X_train.shape)
print("Test  data shape:", X_test.shape)

# Apply PCA using QCi's model (fit then transform -> tests new transform)
obj = PCA(
    n_components=N_COMPONENTS,
    relaxation_schedule=2,
    num_samples=1,
    solver_access=SOLVER_ACCESS,
    api_url=API_URL,
    api_token=API_TOKEN,
    ip_addr=IP_ADDR,
    port=PORT,
)
obj.fit(X_train)
X_pca = obj.transform(X_test)

# Apply PCA using sklearn model (fit then transform)
obj = PCA_cls(
    n_components=N_COMPONENTS,
)
obj.fit(X_train)
X_pca_cls = obj.transform(X_test)

# Compare QCi to sklearn (note: sign flips are expected, so take abs)
X_pca = normalize(X_pca, axis=0, norm="l2")
X_pca_cls = normalize(X_pca_cls, axis=0, norm="l2")

print(abs(np.diag(np.matmul(X_pca.transpose(), X_pca_cls))))
