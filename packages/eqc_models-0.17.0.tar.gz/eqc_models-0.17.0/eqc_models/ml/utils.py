import time
import logging
from functools import wraps
import numpy as np
from sklearn.metrics import (
    auc,
    precision_recall_curve,
    roc_auc_score,
    precision_score,
    recall_score,
    accuracy_score,
    f1_score,
    confusion_matrix,
)
from scipy.signal import welch, get_window

try:
    from eqc_models.ml.reservoir import QciReservoir
except:
    pass

MIN_NUM_FFT_SAMPLES = 10

log = logging.getLogger(name=__name__)

def timer(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        beg_time = time.time()
        val = func(*args, **kwargs)
        end_time = time.time()
        tot_time = end_time - beg_time

        log.info(
            "Runtime of %s: %0.2f seconds!",
            func.__name__,
            tot_time,
        )

        return val

    return wrapper


def smooth_bins(x, k):
    kernel = np.ones(k) / k
    return np.convolve(x, kernel, mode="same")


def get_power_spectrum(
    times,
    values,
    window_func="hann",
    n_segments=8,
    overlap=0.5,
    n_smooth_bins=7,
):
    """Compute a smoothed power spectrum using Welch averaging.

    Parameters
    ----------
    times: array_like
        Time stamps (seconds), assumed uniformly spaced.

    values: array_like
        Signal values at each time.

    window_func: str or tuple, optional
        Window function type (default: "hann").

    n_segments: int, optional
        Number of Welch segments to split the data into (default: 8).

    overlap: float, optional
        Fractional overlap between segments in [0, 1) (default: 0.5).

    Returns
    -------
    freqs: ndarray
        Frequency axis in Hz.
    vec: ndarray
        Power spectrum (smoothed).

    """

    assert overlap >= 0 and overlap < 1, "Invalid overlap value!"

    times = np.asarray(times)
    values = np.asarray(values)

    # Sampling frequency
    dt = np.median(np.diff(times))

    assert dt > 0, "Invalid time vector!"

    fs = 1.0 / dt

    # Segment length
    n = len(values)
    nperseg = max(MIN_NUM_FFT_SAMPLES, n // n_segments)

    # Overlap in samples
    noverlap = int(overlap * nperseg)

    # Build window
    win = get_window(window_func, nperseg)

    freqs, vec = welch(
        values,
        fs=fs,
        window=win,
        nperseg=nperseg,
        noverlap=noverlap,
        detrend="constant",
        scaling="spectrum",
        average="mean",
    )

    # Smooth bins
    if n_smooth_bins is not None and n_smooth_bins > 0:
        vec = smooth_bins(vec, n_smooth_bins)

    return freqs, vec


def get_binary_classification_metrics(
    y_true, y_pred, positive_label=1, negative_label=-1, threshold=0
):
    """Compute classifier merits.

    Parameters
    ----------
    y_true: Actual labels (array-like of shape (n_samples,)).

    y_pred: Predicted scores between negative and positive labels
    (array-like of shape (n_samples,)).

    positive_label: The positive label (integer; default: 1).

    negative_label: The negative label (integer; default: -1).

    threshold: Threshold for converting y_pred scores to predicted
    labels, float; default: 0.

    Returns
    -------
    Dict.

    """

    # Convert to numpy arrays
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()

    # Some sanity checks
    if y_true.ndim != 1 or y_pred.ndim != 1:
        raise ValueError(
            "y_true and y_pred must be 1D arrays (or array-like)."
        )
    if y_true.shape[0] != y_pred.shape[0]:
        raise ValueError(
            f"Size mismatch: y_true has {y_true.shape[0]} elements, "
            f"y_pred has {y_pred.shape[0]} elements."
        )
    if y_true.shape[0] == 0:
        raise ValueError(
            "Empty inputs: y_true/y_pred must have at least 1 element."
        )

    try:
        positive_label = int(positive_label)
    except Exception as e:
        raise TypeError("positive_label must be an integer.") from e

    try:
        negative_label = int(negative_label)
    except Exception as e:
        raise TypeError("negative_label must be an integer.") from e

    try:
        threshold = float(threshold)
    except Exception as e:
        raise TypeError("threshold must be a float.") from e

    assert (
        positive_label != negative_label
    ), "Positive and negative labels should not be equal!"

    y_true = y_true.astype(int)
    assert set(y_true).issubset(
        {
            positive_label,
            negative_label,
        }
    ), f"Incorrect labels! Got: {set(y_true)} Expected: {set([negative_label, positive_label])}"

    # Convert predicted scores to labels
    y_pred_label = np.where(
        y_pred >= threshold, positive_label, negative_label
    )

    assert set(y_pred_label).issubset(
        {
            positive_label,
            negative_label,
        }
    ), f"Incorrect labels! Got: {set(y_pred_label)} Expected: {set([negative_label, positive_label])}"

    # Calculate the metrics
    precision, recall, _ = precision_recall_curve(y_true, y_pred)
    pr_auc = auc(recall, precision)

    out_hash = {
        "positive_label": positive_label,
        "negative_label": negative_label,
        "threshold": threshold,
        "pr_auc": pr_auc,
        "roc_auc": roc_auc_score(y_true, y_pred),
        "precision": precision_score(
            y_true,
            y_pred_label,
            zero_division=0,
            labels=[negative_label, positive_label],
            pos_label=positive_label,
        ),
        "recall": recall_score(
            y_true,
            y_pred_label,
            zero_division=0,
            labels=[negative_label, positive_label],
            pos_label=positive_label,
        ),
        "accuracy": accuracy_score(y_true, y_pred_label),
        "f1_score": f1_score(
            y_true,
            y_pred_label,
            zero_division=0,
            labels=[negative_label, positive_label],
            pos_label=positive_label,
        ),
        "confusion_matrix": confusion_matrix(
            y_true, y_pred_label, labels=[negative_label, positive_label]
        ),
    }

    return out_hash
