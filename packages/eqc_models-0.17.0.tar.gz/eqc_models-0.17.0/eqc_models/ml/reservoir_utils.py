import os
import sys
import time
import logging
from functools import wraps
import numpy as np
import tensorflow as tf

log = logging.getLogger(name=__name__)

gpus = tf.config.list_physical_devices("GPU")
if gpus:
    for gpu in gpus:
        tf.config.experimental.set_memory_growth(gpu, True)


def sin_squared(x):
    return tf.math.sin(x) ** 2


class ESNLayer(tf.keras.layers.Layer):
    """
    Echo State Network (reservoir) layer.

    Input:  (B, T, F)
    Output: (B, T, num_reservoir_nodes) if return_sequences=True
            (B, num_reservoir_nodes)    if return_sequences=False
    """

    def __init__(
        self,
        num_reservoir_nodes,
        spectral_radius=0.95,
        sparsity=0.1,
        input_scaling=0.1,
        return_sequences=True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.num_reservoir_nodes = int(num_reservoir_nodes)
        self.spectral_radius = float(spectral_radius)
        self.sparsity = float(sparsity)
        self.input_scaling = float(input_scaling)
        self.return_sequences = bool(return_sequences)

    def build(self, input_shape):
        # input_shape is (B, T, F)
        num_features = int(input_shape[-1])

        # Initialize weights
        W_in_np = (
            np.random.uniform(
                -1.0, 1.0, size=(num_features, self.num_reservoir_nodes)
            ).astype(np.float32)
            * self.input_scaling
        )

        W_res_np = np.random.uniform(
            -1.0,
            1.0,
            size=(self.num_reservoir_nodes, self.num_reservoir_nodes),
        ).astype(np.float32)

        # Sparsify reservoir (set some elements to zero)
        mask = (
            np.random.rand(
                self.num_reservoir_nodes, self.num_reservoir_nodes
            )
            < self.sparsity
        ).astype(np.float32)
        W_res_np *= mask

        # Spectral radius normalization
        eigvals = np.linalg.eigvals(W_res_np)
        max_abs = float(np.max(np.abs(eigvals)) + 1e-12)
        W_res_np = (W_res_np / max_abs) * self.spectral_radius

        # Store as non-trainable weights
        self.W_in = self.add_weight(
            name="W_in",
            shape=(num_features, self.num_reservoir_nodes),
            initializer=tf.constant_initializer(W_in_np),
            trainable=False,
            dtype=tf.float32,
        )
        self.W_res = self.add_weight(
            name="W_res",
            shape=(self.num_reservoir_nodes, self.num_reservoir_nodes),
            initializer=tf.constant_initializer(W_res_np),
            trainable=False,
            dtype=tf.float32,
        )

        super().build(input_shape)

    def call(self, inputs):
        # inputs: (B, T, F)
        inputs = tf.convert_to_tensor(inputs, dtype=tf.float32)
        B = tf.shape(inputs)[0]

        # initial state: (B, num_reservoir_nodes)
        s0 = tf.zeros((B, self.num_reservoir_nodes), dtype=inputs.dtype)

        # Make time-major for tf.scan: (T, B, F)
        x_time_major = tf.transpose(inputs, perm=[1, 0, 2])

        def step(prev_s, u_t):
            # prev_s: (B, num_reservoir_nodes)
            # u_t:    (B, F)
            pre = tf.matmul(u_t, self.W_in) + tf.matmul(prev_s, self.W_res)
            s_t = sin_squared(pre)
            return s_t

        # states_time_major: (T, B, num_reservoir_nodes)
        states_time_major = tf.scan(step, x_time_major, initializer=s0)

        if self.return_sequences:
            # back to batch-major: (B, T, num_reservoir_nodes)
            return tf.transpose(states_time_major, perm=[1, 0, 2])
        else:
            # final state: (B, num_reservoir_nodes)
            return states_time_major[-1]


@tf.function
def forward(model, x):
    return model(x, training=False)


def push_cls_reservoir(X, num_nodes, num_pad_zeros=0):
    X = np.asarray(X, dtype=np.float32)
    if X.ndim != 2:
        raise ValueError(f"Expected X with shape (T, F). Got {X.shape}")

    num_time_steps, num_dims = X.shape

    # Optional time padding (prepend zeros)
    if num_pad_zeros is not None and num_pad_zeros > 0:
        num_pad_zeros = int(num_pad_zeros)
        pad_vec = np.zeros((num_pad_zeros, num_dims), dtype=np.float32)
        X_in = np.concatenate(
            [pad_vec, X], axis=0
        )  # (num_time_steps+pad, num_dims)
    else:
        X_in = X  # (num_time_steps, num_dims)

    # Add batch dimension -> (1, num_time_steps(+pad), num_dims)
    X_in = tf.convert_to_tensor(X_in[None, ...], dtype=tf.float32)

    # Build model with dynamic time length
    esn_layer = ESNLayer(
        num_reservoir_nodes=num_nodes, return_sequences=True
    )
    inputs = tf.keras.layers.Input(shape=(None, num_dims))
    outputs = esn_layer(inputs)  # (B, num_time_steps, num_reservoir_nodes)
    model = tf.keras.Model(inputs, outputs)

    # Run on whatever device TF chooses (GPU if available)
    states = forward(model, X_in)  # (1, T(+pad), num_reservoir_nodes)
    states = states.numpy()

    # Remove padding along TIME axis (axis=1)
    if num_pad_zeros is not None and num_pad_zeros > 0:
        states = states[
            :, num_pad_zeros:, :
        ]  # (1, num_time_steps, num_reservoir_nodes)

    # Drop batch dim -> (num_time_steps, num_reservoir_nodes)
    return states[0]


def push_emucore_reservoir(
    X, num_out_nodes, ip_addr, num_pad_zeros, chunk_size
):
    X_resp_list = []
    for i in range(0, len(X), chunk_size):
        log.info(
            "Pushing a vector of size %d through reservoir...", chunk_size
        )
        reservoir = QciReservoir(
            ip_addr=ip_addr,
            num_nodes=num_out_nodes,
        )
        reservoir.init_reservoir()

        if num_pad_zeros is not None and num_pad_zeros > 0:
            zero_pad = np.zeros(shape=(num_pad_zeros, X.shape[1]))
            input_data = np.concatenate(
                (zero_pad, X[i : i + chunk_size]), axis=0
            )
        else:
            input_data = X[i : i + chunk_size]

        for itr in range(MAX_TRIES):
            try:
                X_resp_list.append(
                    reservoir.push_reservoir(input_data)[num_pad_zeros:]
                )
                break
            except:
                log.warn("Retrying...")
                time.sleep(5)

        reservoir.release_lock()

    X_resp = np.vstack(X_resp_list)

    return X_resp
