import sys
import logging
import numpy as np
from scipy.signal import find_peaks, peak_widths

from eqc_models.ml.utils import get_power_spectrum, timer
from eqc_models.ml.reservoir_utils import (
    push_emucore_reservoir,
    push_cls_reservoir,
)


class VibrometerFeatureGenerator:
    def __init__(
        self,
        use_reservoir=False,
        reservoir_type="classical",
        power_spectrum_params={
            "window_func": "hann",
            "n_segments": 3,
            "overlap": 0.5,
            "n_smooth_bins": 50,
        },
        reservoir_params={
            "num_out_nodes": 10,
            "num_pad_zeros": 20,
            "chunk_size": None,
            "emucore_ip_addr": None,
        },
    ):
        assert reservoir_type in ["emucore", "classical"]

        self.use_reservoir = use_reservoir
        self.reservoir_type = reservoir_type
        self.window_func = power_spectrum_params["window_func"]
        self.n_segments = power_spectrum_params["n_segments"]
        self.overlap = power_spectrum_params["overlap"]
        self.n_smooth_bins = power_spectrum_params["n_smooth_bins"]
        self.num_out_nodes = reservoir_params["num_out_nodes"]
        self.num_pad_zeros = reservoir_params["num_pad_zeros"]
        self.chunk_size = reservoir_params["chunk_size"]
        self.emucore_ip_addr = reservoir_params["emucore_ip_addr"]
        self.log = logging.getLogger(name=__name__)

    def _extract_time_features(self, x, reservoir_flag=False):
        """
        Extract time-domain features from a time series or reservoir output.

        Parameters
        ----------
        x : ndarray
            Shape (n_samples,) or (n_channels, n_samples)

        Returns
        -------
        features : dict
        """

        self.log.info("Extracting features in time domain")

        x = np.asarray(x)
        if x.ndim == 1:
            x = x[None, :]

        feats = []

        for ch in x:
            mu = np.mean(ch)
            sigma = np.std(ch)
            rms = np.sqrt(np.mean(ch**2))
            peak = np.max(np.abs(ch))
            crest = peak / rms if rms > 0 else 0.0

            # Skewness and kurtosis (population moments)
            if sigma > 0:
                z = (ch - mu) / sigma
                skew = np.mean(z**3)
                kurt = np.mean(z**4)
            else:
                skew = 0.0
                kurt = 0.0

            # Normalized autocorrelation
            s = ch - mu
            denom = np.sum(s**2)
            if denom > 0:
                ac = np.correlate(s, s, mode="full")
                ac = ac[len(ac) // 2 :] / denom
                ac[0] = 0.0  # ignore zero-lag
                lag = np.argmax(ac)
                ac_peak = ac[lag]
            else:
                lag = 0
                ac_peak = 0.0

            feats.append(
                [mu, sigma, rms, peak, crest, skew, kurt, lag, ac_peak]
            )

        feats = np.asarray(feats)

        names = [
            "mu",
            "sigma",
            "rms",
            "peak",
            "crest",
            "skew",
            "kurt",
            "ac_lag",
            "ac_peak",
        ]

        out = {}
        for i, name in enumerate(names):
            if reservoir_flag:
                out[name + "_reservoir_mean"] = feats[:, i].mean()
                out[name + "_reservoir_std"] = feats[:, i].std()
            else:
                out[name] = feats[:, i].mean()

        return out

    def _extract_frequency_features(self, freqs, ps_vec, reservoir_flag):
        """
        Extract frequency-domain features from a smoothed power spectrum.

        Parameters
        ----------
        freqs : ndarray
            Frequency axis, shape (n_freqs,)
        ps_vec : ndarray
            Power spectrum, shape (n_freqs,) or (n_channels, n_freqs)

        Returns
        -------
        features : dict
        """

        self.log.info("Extracting features in frequency domain")

        ps_vec = np.asarray(ps_vec)
        if ps_vec.ndim == 1:
            ps_vec = ps_vec[None, :]

        feats = []

        for P in ps_vec:
            peaks, props = find_peaks(P, prominence=0.0)

            if len(peaks) > 0:
                order = np.argsort(props["prominences"])[::-1]
                i = peaks[order[0]]
                prom = props["prominences"][order[0]]
                f_peak = freqs[i]
                p_peak = P[i]

                if len(order) > 1:
                    j = peaks[order[1]]
                    second_peak_freq = freqs[j]
                    second_peak_prom = props["prominences"][order[1]]
                    peak_spacing = second_peak_freq - f_peak
                else:
                    second_peak_freq = 0.0
                    second_peak_prom = 0.0
                    peak_spacing = 0.0

                widths, _, _, _ = peak_widths(P, [i], rel_height=0.5)
                peak_width = widths[0] if len(widths) > 0 else 0.0
            else:
                prom = 0.0
                f_peak = 0.0
                p_peak = 0.0
                second_peak_freq = 0.0
                second_peak_prom = 0.0
                peak_spacing = 0.0
                peak_width = 0.0

            floor = np.median(P)
            contrast = p_peak / floor if floor > 0 else 0.0

            feats.append(
                [
                    f_peak,
                    prom,
                    contrast,
                    second_peak_freq,
                    second_peak_prom,
                    peak_spacing,
                    peak_width,
                ]
            )

        feats = np.asarray(feats)

        names = [
            "peak_freq",
            "peak_prominence",
            "peak_to_floor",
            "second_peak_freq",
            "second_peak_prom",
            "peak_spacing",
            "peak_width",
        ]

        out = {}
        for i, name in enumerate(names):
            if reservoir_flag:
                out[name + "_reservoir_mean"] = feats[:, i].mean()
                out[name + "_reservoir_std"] = feats[:, i].std()
            else:
                out[name] = feats[:, i].mean()

        return out

    @timer
    def get_features(self, time_vec, photon_count_vec):
        """
        Extract features from a vibrameter signal.

        Parameters
        ----------
        time_vec : ndarray
            Time vector, shape (n_times,)
        photon_count_vec : ndarray
            Vibrameter output, shape (n_times,)

        Returns
        -------
        features : dict
        """

        assert time_vec.ndim == 1, "Incorrect time_vec dimension!"
        assert (
            photon_count_vec.ndim == 1
        ), "Incorrect photon_count_vec dimension!"
        assert (
            time_vec.shape[0] == photon_count_vec.shape[0]
        ), "Inconsistent sizes!"

        self.log.info("Time series length: %d", photon_count_vec.shape[0])

        time_fea_hash = self._extract_time_features(
            photon_count_vec, False
        )

        freq_vec, ps_vec = get_power_spectrum(
            time_vec,
            photon_count_vec,
            window_func=self.window_func,
            n_segments=self.n_segments,
            overlap=self.overlap,
            n_smooth_bins=self.n_smooth_bins,
        )
        freq_fea_hash = self._extract_frequency_features(
            freq_vec, ps_vec, False
        )
        fea_hash = {**time_fea_hash, **freq_fea_hash}

        if not self.use_reservoir:
            return fea_hash

        if self.reservoir_type == "emucore":
            vec = push_emucore_reservoir(
                photon_count_vec.reshape((-1, 1)),
                self.num_out_nodes,
                self.emucore_ip_addr,
                self.num_pad_zeros,
                self.chunk_size,
            )
        else:
            vec = push_cls_reservoir(
                photon_count_vec.reshape((-1, 1)),
                self.num_out_nodes,
                self.num_pad_zeros,
            )

        assert vec.shape[0] == photon_count_vec.shape[0]
        assert vec.shape[1] == self.num_out_nodes

        vec = vec.T

        assert vec.shape[0] == self.num_out_nodes
        assert vec.shape[1] == photon_count_vec.shape[0]

        reservoir_time_fea_hash = self._extract_time_features(
            vec,
            True,
        )

        ps_vec = []
        for tmp_vec in vec:
            assert len(tmp_vec) == len(time_vec)
            freq_vec, tmp_ps_vec = get_power_spectrum(
                time_vec,
                tmp_vec,
                window_func=self.window_func,
                n_segments=self.n_segments,
                overlap=self.overlap,
                n_smooth_bins=self.n_smooth_bins,
            )
            ps_vec.append(tmp_ps_vec)

        ps_vec = np.array(ps_vec)

        assert ps_vec.shape[0] == self.num_out_nodes
        assert ps_vec.shape[1] == len(freq_vec)

        reservoir_freq_fea_hash = self._extract_frequency_features(
            freq_vec,
            ps_vec,
            True,
        )

        fea_hash.update(reservoir_time_fea_hash)
        fea_hash.update(reservoir_freq_fea_hash)

        return fea_hash
