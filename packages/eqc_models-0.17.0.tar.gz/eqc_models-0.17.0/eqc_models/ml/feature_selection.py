import time
from typing import Optional
from functools import wraps
import numpy as np
from sklearn.feature_selection import (
    mutual_info_regression,
    mutual_info_classif,
)

from eqc_models import QuadraticModel
from eqc_models.solvers.qciclient import Dirac3CloudSolver
from eqc_models.solvers.eqcdirect import Dirac3DirectSolver


def timer(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        beg_time = time.time()
        val = func(*args, **kwargs)
        end_time = time.time()
        tot_time = end_time - beg_time

        print(
            "Runtime of %s: %0.2f seconds!"
            % (
                func.__name__,
                tot_time,
            )
        )

        return val

    return wrapper


class FeatureSelector(QuadraticModel):
    """Feature selector class for Dirac-3. Chooses a subset of features.

    Parameters
    ----------
    selected_fea_count (int): Number of selected features.

    fea_target_coef (float): Coefficient of the feature/target
    inteaction; default: 1.0.

    gamma (float): Penalty multiplier to enforce integrality; default:
    0.1.

    correlation_type (str): Correlation type; "pearson" or
    "mutual_information"; default: "pearson".

    mi_n_neighbors (int): Number of neighbors used to estimate mutual
    information; default: 3.

    relaxation_schedule: Relaxation schedule used by Dirac-3;
    default: 2.

    num_samples: Number of samples used by Dirac-3; default: 1.

    solver_access: Solver access type: cloud or direct; default:
    cloud.

    api_url: API URL used when cloud access is used; default: None.

    api_token: API token used when cloud access is used; default:
    None.

    ip_addr: IP address of the device when direct access is used;
    default: None.

    port: Port number of the device when direct access is used;
    default: None.

    """

    def __init__(
        self,
        selected_fea_count: int,
        fea_target_coef: float = 1.0,
        gamma: float = 0.1,
        correlation_type: str = "pearson",
        mi_n_neighbors: int = 3,
        relaxation_schedule: int = 1,
        num_samples: int = 1,
        solver_access: str = "cloud",
        api_url: str = None,
        api_token: str = None,
        ip_addr: str = None,
        port: int = None,
    ) -> None:
        if selected_fea_count <= 0:
            raise ValueError("k must be positive.")
        if min(fea_target_coef, gamma) < 0:
            raise ValueError(
                "fea_target_coef, gamma must be non-negative."
            )
        if correlation_type not in ("pearson", "mutual_information"):
            raise ValueError(
                'correlation_type must be "pearson" or "mutual_information".'
            )

        assert solver_access in ["cloud", "direct"]

        self.selected_fea_count = int(selected_fea_count)
        self.fea_target_coef = float(fea_target_coef)
        self.gamma = float(gamma)
        self.correlation_type = correlation_type
        self.mi_n_neighbors = int(mi_n_neighbors)
        self.relaxation_schedule = relaxation_schedule
        self.num_samples = num_samples
        self.solver_access = solver_access
        self.api_url = api_url
        self.api_token = api_token
        self.ip_addr = ip_addr
        self.port = port

        self.supervised_flag: bool = False

    def _pearson_J(self, X: np.ndarray) -> np.ndarray:
        """Compute |corr(X_i, X_j)| matrix with zero diagonal."""
        X = np.asarray(X, dtype=float)
        J = np.corrcoef(X, rowvar=False)
        J = np.abs(J)

        return J

    def _pearson_C(self, X: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Compute |corr(X_i, y)| for each feature using numpy.corrcoef."""
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float).ravel()
        C = np.zeros(X.shape[1], dtype=float)
        for i in range(X.shape[1]):
            C[i] = np.abs(np.corrcoef(X[:, i], y)[0, 1])

        return C

    def _mi_J(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        n = X.shape[1]
        J = np.zeros((n, n), dtype=float)
        for j in range(n):
            yj = X[:, j]
            for i in range(j + 1, n):
                mij = mutual_info_regression(
                    X[:, [i]],
                    yj,
                    discrete_features="auto",
                    n_neighbors=self.mi_n_neighbors,
                )[0]
                J[i, j] = float(mij)

        J = J + J.T

        for i in range(n):
            J[i, i] = 1.0

        return np.maximum(J, 0.0)

    def _mi_C(
        self,
        X: np.ndarray,
        y: np.ndarray,
        discrete_target_flag: Optional[bool] = None,
    ) -> np.ndarray:
        if discrete_target_flag is None:
            unique_count = np.unique(y).size
            discrete_target_flag = unique_count <= 3

        if discrete_target_flag:
            mi = mutual_info_classif(
                X,
                np.asarray(y).ravel(),
                discrete_features="auto",
                n_neighbors=self.mi_n_neighbors,
            )
        else:
            mi = mutual_info_regression(
                X,
                np.asarray(y).ravel(),
                discrete_features="auto",
                n_neighbors=self.mi_n_neighbors,
            )

        C = np.maximum(np.asarray(mi, dtype=float), 0.0)

        return C

    def _get_hamiltonian(
        self, X, y, discrete_target_flag: Optional[bool] = None
    ):
        self.supervised_flag = y is not None

        if self.correlation_type == "pearson":
            J = self._pearson_J(X)
            C = (
                self._pearson_C(X, y)
                if self.supervised_flag
                else np.zeros(X.shape[1])
            )
        else:
            J = self._mi_J(X)
            C = (
                self._mi_C(X, y, discrete_target_flag=discrete_target_flag)
                if self.supervised_flag
                else np.zeros(X.shape[1])
            )

        assert J.shape[0] == J.shape[1]
        assert J.shape[0] == C.shape[0]

        J = 0.5 * J - self.gamma * np.eye(J.shape[0])

        fea_target_coef = (
            self.fea_target_coef if self.supervised_flag else 0.0
        )

        C = -fea_target_coef * C + self.gamma * np.ones(C.shape[0])

        return J, C

    def _set_model(self, J, C, sum_constraint):
        self._C = C
        self._J = J
        self._H = C, J
        self._sum_constraint = sum_constraint

        # Set upper_bound
        num_variables = C.shape[0]
        self.upper_bound = np.ones((num_variables,))

        return

    @timer
    def _solve(self):
        if self.solver_access == "direct":
            solver = Dirac3DirectSolver()
            solver.connect(self.ip_addr, self.port)
        else:
            solver = Dirac3CloudSolver()
            solver.connect(self.api_url, self.api_token)

        response = solver.solve(
            self,
            sum_constraint=self._sum_constraint,
            relaxation_schedule=self.relaxation_schedule,
            num_samples=self.num_samples,
        )

        if self.solver_access == "cloud":
            energies = response["results"]["energies"]
            solutions = response["results"]["solutions"]
        elif self.solver_access == "direct":
            energies = response["energy"]
            solutions = response["solution"]

        min_id = np.argmin(energies)
        sol = solutions[min_id]

        print(response)

        return sol, response

    def _convert_to_binary(self, sol: np.ndarray) -> np.ndarray:
        sol = np.asarray(sol, dtype=float).ravel()
        if self.selected_fea_count > sol.size:
            raise ValueError("sol length can't be < selected_fea_count")

        bin_sol = np.zeros_like(sol)
        top_inds = np.argsort(sol)[-self.selected_fea_count :]
        bin_sol[top_inds] = 1

        return bin_sol

    @timer
    def select_features(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None,
        discrete_target_flag: Optional[bool] = None,
    ):
        """Select features subset.

        Parameters
        ----------

        X (np.array): The features array (n_samples, n_features).

        y (np.array): Target vector (n_samples,); default: None.

        discrete_target_flag (bool): Flag indicating whether target is
        discrete; default: None (infer automatically).

        Return
        ----------
        A list of 0 or 1 indicating whether a feature is selected.

        """

        X = np.asarray(X)
        if X.ndim != 2:
            raise ValueError("X must be 2D (n_samples, n_features).")
        if self.selected_fea_count > X.shape[1]:
            raise ValueError(
                "selected_fea_count cannot exceed the number of features."
            )

        J, C = self._get_hamiltonian(
            X, y, discrete_target_flag=discrete_target_flag
        )

        self._set_model(J, C, sum_constraint=self.selected_fea_count)

        sol, response = self._solve()

        assert len(sol) == C.shape[0], "Inconsistent solution size!"

        bin_sol = self._convert_to_binary(sol)

        assert len(bin_sol) == len(sol)
        assert sum(bin_sol) == self.selected_fea_count

        return bin_sol
