# (C) Quantum Computing Inc., 2024.
from .eqcdirect import (Dirac3DirectSolver, Dirac3IntegerDirectSolver)
from .qciclient import (Dirac1CloudSolver, Dirac3CloudSolver, QciClientSolver,
                        Dirac3IntegerCloudSolver, Dirac3ContinuousCloudSolver)
from .mip import MIPMixin

class Dirac3MIPCloudSolver(MIPMixin, Dirac3ContinuousCloudSolver):
    pass

class Dirac3MIPDirectSolver(MIPMixin, Dirac3DirectSolver):
    pass

# naming the continuous direct solver
Dirac3ContinuousDirectSolver = Dirac3DirectSolver

__all__ = ["Dirac3DirectSolver", "Dirac3ContinuousDirectSolver", 
           "Dirac3IntegerDirectSolver",
           "Dirac1CloudSolver", "Dirac3CloudSolver", 
           "QciClientSolver", "Dirac3IntegerCloudSolver",
           "Dirac3ContinuousCloudSolver", "MIPMixin",
           "Dirac3MIPCloudSolver", "Dirac3MIPDirectSolver",]
