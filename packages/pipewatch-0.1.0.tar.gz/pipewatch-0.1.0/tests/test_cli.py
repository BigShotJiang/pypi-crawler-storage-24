"""Integration tests for the Pipewatch CLI.

Tests use Click's CliRunner for command invocation and respx for mocking
GitHub API HTTP calls. The DB and config are redirected to tmp_path via
monkeypatching so tests are fully isolated from the developer's local
~/.pipewatch/ directory.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pytest
import respx
from click.testing import CliRunner
from httpx import Response

from pipewatch.cli import main

# ---------------------------------------------------------------------------
# Fixtures and helpers
# ---------------------------------------------------------------------------

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "github"
REPO = "owner/repo"
WORKFLOW_ID = 9876

# Individual run dicts (mirrors list_runs.json workflow_runs entries)
_RUN_001: dict[str, Any] = {
    "id": 12345001,
    "workflow_id": WORKFLOW_ID,
    "name": "CI",
    "head_branch": "main",
    "head_sha": "abc123def456",
    "display_title": "feat: add user authentication",
    "status": "completed",
    "conclusion": "success",
    "event": "push",
    "run_started_at": "2025-06-15T10:00:00Z",
    "created_at": "2025-06-15T09:59:50Z",
    "updated_at": "2025-06-15T10:04:32Z",
}
_RUN_002: dict[str, Any] = {
    "id": 12345002,
    "workflow_id": WORKFLOW_ID,
    "name": "CI",
    "head_branch": "main",
    "head_sha": "def456ghi789",
    "display_title": "fix: resolve login timeout",
    "status": "completed",
    "conclusion": "failure",
    "event": "push",
    "run_started_at": "2025-06-15T11:00:00Z",
    "created_at": "2025-06-15T10:59:50Z",
    "updated_at": "2025-06-15T11:06:18Z",
}
_RUN_003: dict[str, Any] = {
    "id": 12345003,
    "workflow_id": WORKFLOW_ID,
    "name": "CI",
    "head_branch": "feature/api-v2",
    "head_sha": "ghi789jkl012",
    "display_title": "wip: new API endpoints",
    "status": "completed",
    "conclusion": "success",
    "event": "pull_request",
    "run_started_at": "2025-06-15T12:00:00Z",
    "created_at": "2025-06-15T11:59:50Z",
    "updated_at": "2025-06-15T12:03:45Z",
}

_ALL_RUNS = [_RUN_001, _RUN_002, _RUN_003]

_JOBS_RESPONSE: dict[str, Any] = {
    "total_count": 3,
    "jobs": [
        {
            "id": 98001,
            "name": "build",
            "status": "completed",
            "conclusion": "success",
            "started_at": "2025-06-15T10:00:10Z",
            "completed_at": "2025-06-15T10:01:22Z",
        },
        {
            "id": 98002,
            "name": "test",
            "status": "completed",
            "conclusion": "success",
            "started_at": "2025-06-15T10:01:25Z",
            "completed_at": "2025-06-15T10:03:36Z",
        },
        {
            "id": 98003,
            "name": "deploy",
            "status": "completed",
            "conclusion": "success",
            "started_at": "2025-06-15T10:03:40Z",
            "completed_at": "2025-06-15T10:04:30Z",
        },
    ],
}


@pytest.fixture()
def runner() -> CliRunner:
    """CliRunner instance. Click 8.x merges stdout and stderr into output."""
    return CliRunner()


@pytest.fixture()
def isolated_dirs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> dict[str, Path]:
    """Redirect ~/.pipewatch DB and config paths to a temp directory.

    PipewatchDB's default db_path argument is bound at import time (it is a
    module-level Path constant), so patching DEFAULT_DB_PATH after import has
    no effect on the already-baked default. Instead we replace PipewatchDB in
    every module that calls it with a wrapper that injects the tmp db_path
    whenever the class is constructed without an explicit argument.

    Patches:
    - PipewatchDB in pipewatch.storage.db  (the canonical class)
    - PipewatchDB imported into pipewatch.cli  (the call site)
    - pipewatch.cli.PIPEWATCH_DIR           (config file resolution)
    """
    from pipewatch.storage.db import PipewatchDB as _RealDB

    pipewatch_dir = tmp_path / ".pipewatch"
    pipewatch_dir.mkdir()
    db_path = pipewatch_dir / "data.db"
    config_path = pipewatch_dir / "config.yml"

    class _IsolatedDB(_RealDB):
        """Thin subclass that defaults db_path to the test-specific tmp path."""

        def __init__(self, db_path_arg: Path = db_path) -> None:
            super().__init__(db_path_arg)

    # Patch the class in both the storage module and the cli's import namespace
    monkeypatch.setattr("pipewatch.storage.db.PipewatchDB", _IsolatedDB)
    monkeypatch.setattr("pipewatch.cli.PipewatchDB", _IsolatedDB, raising=False)

    monkeypatch.setattr("pipewatch.cli.PIPEWATCH_DIR", pipewatch_dir)

    return {
        "dir": pipewatch_dir,
        "db": db_path,
        "config": config_path,
    }


def _config_args(isolated_dirs: dict[str, Path]) -> list[str]:
    """Return CLI args that point to the isolated config file."""
    return ["--config", str(isolated_dirs["config"])]


def _mock_github_routes(mocked: respx.MockRouter, run_limit: int = 3) -> None:
    """Register all GitHub API routes needed by `pipewatch init`.

    Mocks:
    - GET /repos/owner/repo/actions/runs  → list of runs
    - GET /repos/owner/repo/actions/runs/{id}  → individual run
    - GET /repos/owner/repo/actions/runs/{id}/jobs  → jobs fixture
    """
    list_payload = {"total_count": len(_ALL_RUNS), "workflow_runs": _ALL_RUNS[:run_limit]}
    mocked.get(f"https://api.github.com/repos/{REPO}/actions/runs").mock(
        return_value=Response(200, json=list_payload)
    )

    for run in _ALL_RUNS[:run_limit]:
        run_id = run["id"]
        mocked.get(f"https://api.github.com/repos/{REPO}/actions/runs/{run_id}").mock(
            return_value=Response(200, json=run)
        )
        mocked.get(f"https://api.github.com/repos/{REPO}/actions/runs/{run_id}/jobs").mock(
            return_value=Response(200, json=_JOBS_RESPONSE)
        )


def _prepopulate_db(db_path: Path) -> str:
    """Seed the DB with minimal run + baseline data so status/budget work.

    Returns the pipeline_id used.
    """
    # Import here so the patch on DEFAULT_DB_PATH is already active
    from pipewatch.storage.db import PipewatchDB
    from pipewatch.storage.models import (
        Baseline,
        PipelineRun,
        RunStatus,
        Stage,
    )

    pipeline_id = f"{REPO}/{WORKFLOW_ID}"

    run = PipelineRun(
        id="12345001",
        pipeline_id=pipeline_id,
        branch="main",
        status=RunStatus.SUCCESS,
        started_at=datetime(2025, 6, 15, 10, 0, 0, tzinfo=UTC),
        finished_at=datetime(2025, 6, 15, 10, 4, 32, tzinfo=UTC),
        stages=[
            Stage(
                name="build",
                status=RunStatus.SUCCESS,
                duration_seconds=72.0,
                started_at=datetime(2025, 6, 15, 10, 0, 10, tzinfo=UTC),
                finished_at=datetime(2025, 6, 15, 10, 1, 22, tzinfo=UTC),
            ),
            Stage(
                name="test",
                status=RunStatus.SUCCESS,
                duration_seconds=131.0,
                started_at=datetime(2025, 6, 15, 10, 1, 25, tzinfo=UTC),
                finished_at=datetime(2025, 6, 15, 10, 3, 36, tzinfo=UTC),
            ),
            Stage(
                name="deploy",
                status=RunStatus.SUCCESS,
                duration_seconds=50.0,
                started_at=datetime(2025, 6, 15, 10, 3, 40, tzinfo=UTC),
                finished_at=datetime(2025, 6, 15, 10, 4, 30, tzinfo=UTC),
            ),
        ],
        commit_sha="abc123def456",
        commit_message="feat: add user authentication",
        trigger="push",
    )

    now = datetime.now(UTC)
    baselines = [
        Baseline(
            pipeline_id=pipeline_id,
            stage_name="build",
            median_duration=72.0,
            mad=5.0,
            mean_duration=72.0,
            std_duration=5.0,
            sample_size=3,
            p25_duration=68.0,
            p75_duration=76.0,
            min_duration=65.0,
            max_duration=80.0,
            pass_rate=1.0,
            computed_at=now,
        ),
        Baseline(
            pipeline_id=pipeline_id,
            stage_name="test",
            median_duration=131.0,
            mad=10.0,
            mean_duration=131.0,
            std_duration=10.0,
            sample_size=3,
            p25_duration=125.0,
            p75_duration=137.0,
            min_duration=120.0,
            max_duration=145.0,
            pass_rate=1.0,
            computed_at=now,
        ),
        Baseline(
            pipeline_id=pipeline_id,
            stage_name="deploy",
            median_duration=50.0,
            mad=3.0,
            mean_duration=50.0,
            std_duration=3.0,
            sample_size=3,
            p25_duration=48.0,
            p75_duration=52.0,
            min_duration=45.0,
            max_duration=55.0,
            pass_rate=1.0,
            computed_at=now,
        ),
    ]

    db = PipewatchDB(db_path)
    try:
        db.store_run(run)
        db.store_baselines(baselines)
    finally:
        db.close()

    return pipeline_id


# ---------------------------------------------------------------------------
# 1. pipewatch --help lists all commands
# ---------------------------------------------------------------------------


def test_help_shows_all_commands(runner: CliRunner) -> None:
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    output = result.output

    # Core commands from cli.py
    expected = (
        "init",
        "status",
        "diagnose",
        "doctor",
        "compare",
        "budget",
        "notify",
        "providers",
        "watch",
    )
    for command in expected:
        assert command in output, f"Expected command '{command}' in --help output"


# ---------------------------------------------------------------------------
# 2. pipewatch providers
# ---------------------------------------------------------------------------


def test_providers_lists_supported_platforms(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    result = runner.invoke(main, _config_args(isolated_dirs) + ["providers"])
    assert result.exit_code == 0
    output = result.output

    assert "GitHub Actions" in output
    assert "GitLab CI" in output
    assert "Jenkins" in output


def test_providers_shows_auth_methods(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(main, _config_args(isolated_dirs) + ["providers"])
    assert result.exit_code == 0
    assert "GITHUB_TOKEN" in result.output


# ---------------------------------------------------------------------------
# 3. pipewatch init with mocked GitHub API
# ---------------------------------------------------------------------------


@respx.mock
def test_init_github_fetches_runs_and_builds_baseline(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    _mock_github_routes(respx.mock, run_limit=3)

    result = runner.invoke(
        main,
        _config_args(isolated_dirs)
        + ["init", "--provider", "github", "--repo", REPO, "--runs", "3"],
    )

    assert result.exit_code == 0, f"Exit code {result.exit_code}. Output:\n{result.output}"
    output = result.output
    assert "Fetched 3 runs" in output
    assert "Got stage details for 3 runs" in output
    assert "Baseline computed" in output


@respx.mock
def test_init_saves_config_file(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    _mock_github_routes(respx.mock, run_limit=3)

    runner.invoke(
        main,
        _config_args(isolated_dirs)
        + ["init", "--provider", "github", "--repo", REPO, "--runs", "3"],
    )

    config_path = isolated_dirs["config"]
    assert config_path.exists(), "Config file was not created by init"

    import yaml

    with open(config_path) as f:
        saved = yaml.safe_load(f)

    assert saved["provider"] == "github"
    assert saved["repo"] == REPO


@respx.mock
def test_init_stores_runs_in_db(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    _mock_github_routes(respx.mock, run_limit=3)

    runner.invoke(
        main,
        _config_args(isolated_dirs)
        + ["init", "--provider", "github", "--repo", REPO, "--runs", "3"],
    )

    from pipewatch.storage.db import PipewatchDB

    db = PipewatchDB(isolated_dirs["db"])
    try:
        pipeline_id = f"{REPO}/{WORKFLOW_ID}"
        count = db.get_run_count(pipeline_id)
        assert count == 3
        baselines = db.get_baselines(pipeline_id)
        assert len(baselines) > 0
        assert "build" in baselines
        assert "test" in baselines
        assert "deploy" in baselines
    finally:
        db.close()


@respx.mock
def test_init_with_token_option(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    _mock_github_routes(respx.mock, run_limit=3)

    result = runner.invoke(
        main,
        _config_args(isolated_dirs)
        + [
            "init",
            "--provider",
            "github",
            "--repo",
            REPO,
            "--token",
            "ghp_testtoken123",
            "--runs",
            "3",
        ],
    )

    # The token should not cause failure; command should succeed
    assert result.exit_code == 0, f"Exit code {result.exit_code}. Output:\n{result.output}"


# ---------------------------------------------------------------------------
# 4. pipewatch status (pre-populated DB)
# ---------------------------------------------------------------------------


def test_status_shows_pipeline_health(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    _prepopulate_db(isolated_dirs["db"])

    # Write a minimal config so the provider check passes
    isolated_dirs["config"].write_text(f"provider: github\nrepo: {REPO}\n")

    result = runner.invoke(main, _config_args(isolated_dirs) + ["status"])
    assert result.exit_code == 0, f"Exit code {result.exit_code}. Output:\n{result.output}"

    output = result.output
    assert "Pipeline Status" in output
    assert f"{REPO}/{WORKFLOW_ID}" in output


def test_status_without_init_exits_with_error(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    # No config file — provider is empty, should fail gracefully
    result = runner.invoke(main, _config_args(isolated_dirs) + ["status"])
    assert result.exit_code != 0


def test_status_with_config_but_no_db_data_exits_with_error(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    # Config has provider but DB has no baselines
    isolated_dirs["config"].write_text(f"provider: github\nrepo: {REPO}\n")

    result = runner.invoke(main, _config_args(isolated_dirs) + ["status"])
    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# 5. pipewatch notify --slack URL
# ---------------------------------------------------------------------------


def test_notify_slack_configures_channel(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    slack_url = "https://hooks.slack.com/services/T000/B000/XXXX"

    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["notify", "--slack", slack_url],
    )
    assert result.exit_code == 0, f"Exit code {result.exit_code}. Output:\n{result.output}"
    assert "Slack" in result.output or "configured" in result.output.lower()


def test_notify_slack_persists_to_config(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    slack_url = "https://hooks.slack.com/services/T000/B000/XXXX"

    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["notify", "--slack", slack_url],
    )

    # Re-load the config and verify Slack channel was saved
    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    slack_channels = [ch for ch in config.notifications if ch.type == "slack"]
    assert len(slack_channels) == 1
    assert slack_channels[0].webhook == slack_url


def test_notify_discord_configures_channel(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    discord_url = "https://discord.com/api/webhooks/123/abc"

    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["notify", "--discord", discord_url],
    )
    assert result.exit_code == 0
    assert "Discord" in result.output or "configured" in result.output.lower()


def test_notify_generic_webhook_configures_channel(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    webhook_url = "https://example.com/ci-webhook"

    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["notify", "--webhook", webhook_url],
    )
    assert result.exit_code == 0

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    webhook_channels = [ch for ch in config.notifications if ch.type == "webhook"]
    assert len(webhook_channels) == 1
    assert webhook_channels[0].webhook == webhook_url


# ---------------------------------------------------------------------------
# 6. pipewatch notify --list
# ---------------------------------------------------------------------------


def test_notify_list_shows_no_channels_when_empty(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    result = runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--list"])
    assert result.exit_code == 0
    assert "No notification channels" in result.output


def test_notify_list_shows_configured_channels(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    slack_url = "https://hooks.slack.com/services/T000/B000/XXXX"

    # First configure a Slack channel
    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["notify", "--slack", slack_url],
    )

    # Then list channels
    result = runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--list"])
    assert result.exit_code == 0
    output = result.output
    assert "slack" in output.lower()
    # The URL should appear (possibly truncated with "...")
    assert "hooks.slack.com" in output


def test_notify_list_shows_multiple_channels(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    slack_url = "https://hooks.slack.com/services/T000/B000/XXXX"
    discord_url = "https://discord.com/api/webhooks/123/abc"

    runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--slack", slack_url])
    runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--discord", discord_url])

    result = runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--list"])
    assert result.exit_code == 0
    output = result.output.lower()
    assert "slack" in output
    assert "discord" in output


def test_notify_remove_deletes_channel(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    slack_url = "https://hooks.slack.com/services/T000/B000/XXXX"

    runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--slack", slack_url])
    runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--remove", "slack"])

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    slack_channels = [ch for ch in config.notifications if ch.type == "slack"]
    assert len(slack_channels) == 0


# ---------------------------------------------------------------------------
# 7. pipewatch budget --stage test --max 3m
# ---------------------------------------------------------------------------


def test_budget_sets_stage_budget(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "test", "--max", "3m"],
    )
    assert result.exit_code == 0, f"Exit code {result.exit_code}. Output:\n{result.output}"
    assert "test" in result.output
    assert "3m" in result.output


def test_budget_persists_to_config(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "test", "--max", "3m"],
    )

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    test_budgets = [b for b in config.budgets if b.name == "test"]
    assert len(test_budgets) == 1
    assert test_budgets[0].max_seconds == 180  # 3m = 180s


def test_budget_multiple_stages(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "build", "--max", "2m"],
    )
    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "test", "--max", "5m"],
    )

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    budget_map = {b.name: b.max_seconds for b in config.budgets}
    assert budget_map["build"] == 120
    assert budget_map["test"] == 300


def test_budget_overrides_existing_stage(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "test", "--max", "5m"],
    )
    runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "test", "--max", "90s"],
    )

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    test_budgets = [b for b in config.budgets if b.name == "test"]
    # Only one entry should remain with the updated value
    assert len(test_budgets) == 1
    assert test_budgets[0].max_seconds == 90


def test_budget_accepts_seconds_format(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "deploy", "--max", "90s"],
    )
    assert result.exit_code == 0

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    deploy_budgets = [b for b in config.budgets if b.name == "deploy"]
    assert deploy_budgets[0].max_seconds == 90


def test_budget_accepts_hours_format(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "integration", "--max", "1h"],
    )
    assert result.exit_code == 0

    from pipewatch.config import load_config

    config = load_config(isolated_dirs["config"])
    budgets = [b for b in config.budgets if b.name == "integration"]
    assert budgets[0].max_seconds == 3600


# ---------------------------------------------------------------------------
# 8. init without --repo gives error
# ---------------------------------------------------------------------------


def test_init_github_without_repo_fails(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["init", "--provider", "github"],
    )
    assert result.exit_code != 0
    # Error message should mention --repo requirement (stderr is mixed into output in Click 8.x)
    assert "repo" in result.output.lower() or "github" in result.output.lower()


def test_init_gitlab_without_project_id_fails(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["init", "--provider", "gitlab"],
    )
    assert result.exit_code != 0
    out = result.output.lower()
    assert "project-id" in out or "project_id" in out or "gitlab" in out


def test_init_jenkins_without_url_fails(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["init", "--provider", "jenkins"],
    )
    assert result.exit_code != 0
    assert "url" in result.output.lower() or "jenkins" in result.output.lower()


def test_init_requires_provider_flag(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["init", "--repo", REPO],
    )
    # Click enforces required=True on --provider; should exit non-zero
    assert result.exit_code != 0


def test_init_rejects_unknown_provider(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["init", "--provider", "circleci", "--repo", REPO],
    )
    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Additional edge-case / coverage tests
# ---------------------------------------------------------------------------


def test_version_flag(runner: CliRunner) -> None:
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_notify_slack_url_is_truncated_in_list_when_long(
    runner: CliRunner, isolated_dirs: dict[str, Path]
) -> None:
    # URLs longer than 40 chars are truncated with "..." in the Rich table
    long_url = (
        "https://hooks.slack.com/services/TAAABBB/BCCCCDDD/very-long-secret-token-here-1234567890"
    )

    runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--slack", long_url])

    result = runner.invoke(main, _config_args(isolated_dirs) + ["notify", "--list"])
    assert result.exit_code == 0
    # Rich truncates with ellipsis character "…" not "..."
    assert "…" in result.output or "..." in result.output


@respx.mock
def test_init_github_404_error_message(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    respx.mock.get(f"https://api.github.com/repos/{REPO}/actions/runs").mock(
        return_value=Response(404, json={"message": "Not Found"})
    )

    result = runner.invoke(
        main,
        _config_args(isolated_dirs)
        + ["init", "--provider", "github", "--repo", REPO, "--runs", "3"],
    )
    assert result.exit_code != 0
    # Should show a user-friendly error, not a raw traceback
    assert "not found" in result.output.lower() or "404" in result.output


@respx.mock
def test_init_github_auth_error_message(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    respx.mock.get(f"https://api.github.com/repos/{REPO}/actions/runs").mock(
        return_value=Response(401, json={"message": "Bad credentials"})
    )

    result = runner.invoke(
        main,
        _config_args(isolated_dirs)
        + ["init", "--provider", "github", "--repo", REPO, "--runs", "3"],
    )
    assert result.exit_code != 0
    combined = result.output.lower()
    assert "auth" in combined or "token" in combined or "401" in combined


def test_budget_missing_stage_flag_fails(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--max", "3m"],
    )
    # Click enforces required=True; should exit non-zero
    assert result.exit_code != 0


def test_budget_missing_max_flag_fails(runner: CliRunner, isolated_dirs: dict[str, Path]) -> None:
    result = runner.invoke(
        main,
        _config_args(isolated_dirs) + ["budget", "--stage", "test"],
    )
    assert result.exit_code != 0
