"""Tests for flaky test detection."""

from pipewatch.engine.flaky import build_test_history, detect_flaky_tests
from pipewatch.storage.models import RunStatus, TestResult


class TestDetectFlakyTests:
    def test_detects_flaky_test(self) -> None:
        history = {
            "test_login": [
                RunStatus.SUCCESS,
                RunStatus.FAILURE,
                RunStatus.SUCCESS,
                RunStatus.FAILURE,
                RunStatus.SUCCESS,
                RunStatus.FAILURE,
            ],
        }

        flaky = detect_flaky_tests(history, "test/repo", threshold=0.1)
        assert len(flaky) == 1
        assert flaky[0].name == "test_login"
        assert flaky[0].flip_count == 5

    def test_stable_passing_test_not_flagged(self) -> None:
        history = {
            "test_stable": [RunStatus.SUCCESS] * 20,
        }

        flaky = detect_flaky_tests(history, "test/repo", threshold=0.1)
        assert len(flaky) == 0

    def test_consistently_failing_test_not_flagged(self) -> None:
        history = {
            "test_broken": [RunStatus.FAILURE] * 20,
        }

        flaky = detect_flaky_tests(history, "test/repo", threshold=0.1)
        assert len(flaky) == 0

    def test_insufficient_history_skipped(self) -> None:
        history = {
            "test_new": [RunStatus.SUCCESS, RunStatus.FAILURE],  # Only 2 runs
        }

        flaky = detect_flaky_tests(history, "test/repo", threshold=0.1)
        assert len(flaky) == 0

    def test_sorted_by_flip_rate(self) -> None:
        history = {
            "test_mild": [
                RunStatus.SUCCESS,
                RunStatus.SUCCESS,
                RunStatus.FAILURE,
                RunStatus.SUCCESS,
                RunStatus.SUCCESS,
            ],
            "test_severe": [
                RunStatus.SUCCESS,
                RunStatus.FAILURE,
                RunStatus.SUCCESS,
                RunStatus.FAILURE,
                RunStatus.SUCCESS,
            ],
        }

        flaky = detect_flaky_tests(history, "test/repo", threshold=0.05)
        assert len(flaky) == 2
        assert flaky[0].name == "test_severe"  # Higher flip rate first


class TestBuildTestHistory:
    def test_builds_history(self) -> None:
        runs = [
            [
                TestResult(
                    name="test_a",
                    suite="auth",
                    status=RunStatus.SUCCESS,
                    duration_seconds=1.0,
                )
            ],
            [
                TestResult(
                    name="test_a",
                    suite="auth",
                    status=RunStatus.FAILURE,
                    duration_seconds=1.2,
                )
            ],
        ]

        history = build_test_history(runs)
        assert "auth::test_a" in history
        assert history["auth::test_a"] == [RunStatus.SUCCESS, RunStatus.FAILURE]
