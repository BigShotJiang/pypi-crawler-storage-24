"""Integration tests for the SQLite database layer.

Tests cover store/retrieve round-trips for all entity types, filtering,
and empty-database edge cases. Uses tmp_path so no test pollutes
~/.pipewatch/data.db.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from pathlib import Path

from pipewatch.storage.db import PipewatchDB
from pipewatch.storage.models import (
    Baseline,
    DriftEvent,
    PipelineRun,
    RunStatus,
    Stage,
    TrendDirection,
)

# ---------------------------------------------------------------------------
# Shared test data factories
# ---------------------------------------------------------------------------

_NOW = datetime(2026, 3, 9, 12, 0, 0, tzinfo=UTC)
_LATER = datetime(2026, 3, 9, 12, 5, 0, tzinfo=UTC)


def _make_stage(
    name: str = "build",
    status: RunStatus = RunStatus.SUCCESS,
    duration: float = 120.0,
) -> Stage:
    return Stage(
        name=name,
        status=status,
        duration_seconds=duration,
        started_at=_NOW,
        finished_at=_LATER,
    )


def _make_run(
    run_id: str = "run-1",
    pipeline_id: str = "org/repo",
    branch: str = "main",
    status: RunStatus = RunStatus.SUCCESS,
    stages: list[Stage] | None = None,
    commit_sha: str = "abc123",
    commit_message: str = "chore: update deps",
    trigger: str = "push",
) -> PipelineRun:
    return PipelineRun(
        id=run_id,
        pipeline_id=pipeline_id,
        branch=branch,
        status=status,
        started_at=_NOW,
        finished_at=_LATER,
        stages=stages if stages is not None else [_make_stage()],
        commit_sha=commit_sha,
        commit_message=commit_message,
        trigger=trigger,
    )


def _make_baseline(
    pipeline_id: str = "org/repo",
    stage_name: str = "build",
    median_duration: float = 120.0,
    sample_size: int = 25,
) -> Baseline:
    return Baseline(
        pipeline_id=pipeline_id,
        stage_name=stage_name,
        median_duration=median_duration,
        mad=5.0,
        mean_duration=122.0,
        std_duration=8.0,
        sample_size=sample_size,
        p25_duration=115.0,
        p75_duration=128.0,
        min_duration=100.0,
        max_duration=150.0,
        pass_rate=0.96,
        computed_at=_NOW,
    )


def _make_drift_event(
    run_id: str = "run-1",
    pipeline_id: str = "org/repo",
    stage_name: str = "build",
    trend: TrendDirection = TrendDirection.INCREASING,
    probable_causes: list[str] | None = None,
) -> DriftEvent:
    return DriftEvent(
        run_id=run_id,
        pipeline_id=pipeline_id,
        stage_name=stage_name,
        metric="duration",
        expected=120.0,
        actual=210.0,
        z_score=4.2,
        trend=trend,
        probable_causes=probable_causes if probable_causes is not None else ["dep update"],
        detected_at=_NOW,
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def db(tmp_path: Path) -> PipewatchDB:
    """Provide a fresh PipewatchDB backed by a temporary file."""
    instance = PipewatchDB(db_path=tmp_path / "test.db")
    yield instance
    instance.close()


# ---------------------------------------------------------------------------
# Store and retrieve runs
# ---------------------------------------------------------------------------


class TestStoreAndGetRuns:
    def test_store_and_retrieve_run(self, db: PipewatchDB) -> None:
        run = _make_run()
        db.store_run(run)

        runs = db.get_runs("org/repo")

        assert len(runs) == 1
        retrieved = runs[0]
        assert retrieved.id == "run-1"
        assert retrieved.pipeline_id == "org/repo"
        assert retrieved.branch == "main"
        assert retrieved.status == RunStatus.SUCCESS
        assert retrieved.commit_sha == "abc123"
        assert retrieved.commit_message == "chore: update deps"
        assert retrieved.trigger == "push"

    def test_run_started_at_roundtrip(self, db: PipewatchDB) -> None:
        run = _make_run()
        db.store_run(run)

        retrieved = db.get_runs("org/repo")[0]

        assert retrieved.started_at == _NOW
        assert retrieved.finished_at == _LATER

    def test_run_with_null_finished_at(self, db: PipewatchDB) -> None:
        run = PipelineRun(
            id="run-running",
            pipeline_id="org/repo",
            branch="main",
            status=RunStatus.RUNNING,
            started_at=_NOW,
            finished_at=None,
            stages=[],
        )
        db.store_run(run)

        retrieved = db.get_runs("org/repo")[0]

        assert retrieved.finished_at is None
        assert retrieved.status == RunStatus.RUNNING

    def test_stages_are_persisted(self, db: PipewatchDB) -> None:
        stages = [
            _make_stage("build", RunStatus.SUCCESS, 90.0),
            _make_stage("test", RunStatus.SUCCESS, 240.0),
            _make_stage("deploy", RunStatus.FAILURE, 30.0),
        ]
        run = _make_run(stages=stages)
        db.store_run(run)

        retrieved = db.get_runs("org/repo")[0]

        assert len(retrieved.stages) == 3
        names = [s.name for s in retrieved.stages]
        assert names == ["build", "test", "deploy"]

    def test_stage_fields_roundtrip(self, db: PipewatchDB) -> None:
        stage = _make_stage("build", RunStatus.FAILURE, 77.5)
        db.store_run(_make_run(stages=[stage]))

        retrieved_stage = db.get_runs("org/repo")[0].stages[0]

        assert retrieved_stage.name == "build"
        assert retrieved_stage.status == RunStatus.FAILURE
        assert retrieved_stage.duration_seconds == 77.5
        assert retrieved_stage.started_at == _NOW
        assert retrieved_stage.finished_at == _LATER

    def test_run_with_no_stages(self, db: PipewatchDB) -> None:
        run = _make_run(stages=[])
        db.store_run(run)

        retrieved = db.get_runs("org/repo")[0]

        assert retrieved.stages == []

    def test_store_overwrites_existing_run(self, db: PipewatchDB) -> None:
        """INSERT OR REPLACE should update an existing run with the same id."""
        original = _make_run(status=RunStatus.RUNNING, stages=[])
        updated = _make_run(status=RunStatus.SUCCESS, stages=[_make_stage()])

        db.store_run(original)
        db.store_run(updated)

        runs = db.get_runs("org/repo")
        assert len(runs) == 1
        assert runs[0].status == RunStatus.SUCCESS

    def test_multiple_runs_ordered_newest_first(self, db: PipewatchDB) -> None:
        early = PipelineRun(
            id="run-old",
            pipeline_id="org/repo",
            branch="main",
            status=RunStatus.SUCCESS,
            started_at=datetime(2026, 3, 8, 10, 0, 0, tzinfo=UTC),
            finished_at=datetime(2026, 3, 8, 10, 5, 0, tzinfo=UTC),
        )
        recent = PipelineRun(
            id="run-new",
            pipeline_id="org/repo",
            branch="main",
            status=RunStatus.SUCCESS,
            started_at=datetime(2026, 3, 9, 10, 0, 0, tzinfo=UTC),
            finished_at=datetime(2026, 3, 9, 10, 5, 0, tzinfo=UTC),
        )
        db.store_run(early)
        db.store_run(recent)

        runs = db.get_runs("org/repo")

        assert runs[0].id == "run-new"
        assert runs[1].id == "run-old"

    def test_get_runs_respects_limit(self, db: PipewatchDB) -> None:
        for i in range(5):
            db.store_run(
                PipelineRun(
                    id=f"run-{i}",
                    pipeline_id="org/repo",
                    branch="main",
                    status=RunStatus.SUCCESS,
                    started_at=datetime(2026, 3, i + 1, 0, 0, 0, tzinfo=UTC),
                )
            )

        runs = db.get_runs("org/repo", limit=3)

        assert len(runs) == 3

    def test_runs_isolated_by_pipeline_id(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r1", pipeline_id="org/repo-a"))
        db.store_run(_make_run(run_id="r2", pipeline_id="org/repo-b"))

        assert len(db.get_runs("org/repo-a")) == 1
        assert len(db.get_runs("org/repo-b")) == 1


# ---------------------------------------------------------------------------
# Branch filter
# ---------------------------------------------------------------------------


class TestGetRunsWithBranchFilter:
    def test_filter_returns_only_matching_branch(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r-main", branch="main"))
        db.store_run(_make_run(run_id="r-feat", branch="feature/x"))

        main_runs = db.get_runs("org/repo", branch="main")
        feat_runs = db.get_runs("org/repo", branch="feature/x")

        assert len(main_runs) == 1
        assert main_runs[0].id == "r-main"
        assert len(feat_runs) == 1
        assert feat_runs[0].id == "r-feat"

    def test_filter_excludes_other_branches(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r-main", branch="main"))
        db.store_run(_make_run(run_id="r-dev", branch="develop"))

        result = db.get_runs("org/repo", branch="main")

        assert all(r.branch == "main" for r in result)

    def test_filter_on_nonexistent_branch_returns_empty(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r-main", branch="main"))

        result = db.get_runs("org/repo", branch="no-such-branch")

        assert result == []

    def test_no_branch_filter_returns_all_branches(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r1", branch="main"))
        db.store_run(_make_run(run_id="r2", branch="develop"))
        db.store_run(_make_run(run_id="r3", branch="feature/y"))

        result = db.get_runs("org/repo")

        assert len(result) == 3


# ---------------------------------------------------------------------------
# Store and retrieve baselines
# ---------------------------------------------------------------------------


class TestStoreAndGetBaselines:
    def test_store_and_retrieve_single_baseline(self, db: PipewatchDB) -> None:
        baseline = _make_baseline()
        db.store_baselines([baseline])

        result = db.get_baselines("org/repo")

        assert "build" in result
        b = result["build"]
        assert b.pipeline_id == "org/repo"
        assert b.stage_name == "build"
        assert b.median_duration == 120.0
        assert b.mad == 5.0
        assert b.mean_duration == 122.0
        assert b.std_duration == 8.0
        assert b.sample_size == 25
        assert b.p25_duration == 115.0
        assert b.p75_duration == 128.0
        assert b.min_duration == 100.0
        assert b.max_duration == 150.0
        assert b.pass_rate == 0.96

    def test_computed_at_roundtrip(self, db: PipewatchDB) -> None:
        baseline = _make_baseline()
        db.store_baselines([baseline])

        result = db.get_baselines("org/repo")

        assert result["build"].computed_at == _NOW

    def test_store_multiple_baselines(self, db: PipewatchDB) -> None:
        baselines = [
            _make_baseline(stage_name="build"),
            _make_baseline(stage_name="test", median_duration=240.0),
            _make_baseline(stage_name="deploy", median_duration=60.0),
        ]
        db.store_baselines(baselines)

        result = db.get_baselines("org/repo")

        assert set(result.keys()) == {"build", "test", "deploy"}
        assert result["test"].median_duration == 240.0
        assert result["deploy"].median_duration == 60.0

    def test_baseline_keyed_by_stage_name(self, db: PipewatchDB) -> None:
        db.store_baselines([_make_baseline(stage_name="lint")])

        result = db.get_baselines("org/repo")

        assert list(result.keys()) == ["lint"]

    def test_store_baselines_overwrites_on_conflict(self, db: PipewatchDB) -> None:
        """INSERT OR REPLACE should update an existing (pipeline_id, stage_name) row."""
        original = _make_baseline(median_duration=100.0)
        updated = _make_baseline(median_duration=200.0)

        db.store_baselines([original])
        db.store_baselines([updated])

        result = db.get_baselines("org/repo")
        assert result["build"].median_duration == 200.0

    def test_baselines_isolated_by_pipeline_id(self, db: PipewatchDB) -> None:
        db.store_baselines([_make_baseline(pipeline_id="org/repo-a")])
        db.store_baselines([_make_baseline(pipeline_id="org/repo-b")])

        assert "build" in db.get_baselines("org/repo-a")
        assert "build" in db.get_baselines("org/repo-b")
        assert db.get_baselines("org/repo-c") == {}


# ---------------------------------------------------------------------------
# Store and retrieve drift events
# ---------------------------------------------------------------------------


class TestStoreAndGetDriftEvents:
    def test_store_and_retrieve_single_event(self, db: PipewatchDB) -> None:
        event = _make_drift_event()
        db.store_drift_event(event)

        events = db.get_recent_drift_events("org/repo")

        assert len(events) == 1
        e = events[0]
        assert e.run_id == "run-1"
        assert e.pipeline_id == "org/repo"
        assert e.stage_name == "build"
        assert e.metric == "duration"
        assert e.expected == 120.0
        assert e.actual == 210.0
        assert e.z_score == pytest.approx(4.2)
        assert e.trend == TrendDirection.INCREASING

    def test_probable_causes_roundtrip(self, db: PipewatchDB) -> None:
        causes = ["dep update", "test suite expanded", "cache miss"]
        event = _make_drift_event(probable_causes=causes)
        db.store_drift_event(event)

        e = db.get_recent_drift_events("org/repo")[0]

        assert e.probable_causes == causes

    def test_empty_probable_causes(self, db: PipewatchDB) -> None:
        event = _make_drift_event(probable_causes=[])
        db.store_drift_event(event)

        e = db.get_recent_drift_events("org/repo")[0]

        assert e.probable_causes == []

    def test_detected_at_roundtrip(self, db: PipewatchDB) -> None:
        event = _make_drift_event()
        db.store_drift_event(event)

        e = db.get_recent_drift_events("org/repo")[0]

        assert e.detected_at == _NOW

    def test_all_trend_directions_roundtrip(self, db: PipewatchDB) -> None:
        for i, trend in enumerate(TrendDirection):
            db.store_drift_event(_make_drift_event(run_id=f"run-{i}", trend=trend))

        events = db.get_recent_drift_events("org/repo")
        retrieved_trends = {e.trend for e in events}

        assert retrieved_trends == set(TrendDirection)

    def test_multiple_events_ordered_newest_first(self, db: PipewatchDB) -> None:
        early = DriftEvent(
            run_id="run-old",
            pipeline_id="org/repo",
            stage_name="build",
            metric="duration",
            expected=120.0,
            actual=200.0,
            z_score=3.0,
            trend=TrendDirection.STABLE,
            detected_at=datetime(2026, 3, 8, 0, 0, 0, tzinfo=UTC),
        )
        recent = DriftEvent(
            run_id="run-new",
            pipeline_id="org/repo",
            stage_name="build",
            metric="duration",
            expected=120.0,
            actual=210.0,
            z_score=4.0,
            trend=TrendDirection.INCREASING,
            detected_at=datetime(2026, 3, 9, 0, 0, 0, tzinfo=UTC),
        )
        db.store_drift_event(early)
        db.store_drift_event(recent)

        events = db.get_recent_drift_events("org/repo")

        assert events[0].run_id == "run-new"
        assert events[1].run_id == "run-old"

    def test_get_recent_drift_events_respects_limit(self, db: PipewatchDB) -> None:
        for i in range(10):
            db.store_drift_event(_make_drift_event(run_id=f"run-{i}"))

        events = db.get_recent_drift_events("org/repo", limit=4)

        assert len(events) == 4

    def test_drift_events_isolated_by_pipeline_id(self, db: PipewatchDB) -> None:
        db.store_drift_event(_make_drift_event(run_id="r1", pipeline_id="org/repo-a"))
        db.store_drift_event(_make_drift_event(run_id="r2", pipeline_id="org/repo-b"))

        assert len(db.get_recent_drift_events("org/repo-a")) == 1
        assert len(db.get_recent_drift_events("org/repo-b")) == 1

    def test_drift_events_allow_duplicate_run_ids(self, db: PipewatchDB) -> None:
        """drift_events has no unique constraint on run_id — multiple events per run are valid."""
        db.store_drift_event(_make_drift_event(run_id="run-1", stage_name="build"))
        db.store_drift_event(_make_drift_event(run_id="run-1", stage_name="test"))

        events = db.get_recent_drift_events("org/repo")

        assert len(events) == 2


# ---------------------------------------------------------------------------
# get_latest_run_id
# ---------------------------------------------------------------------------


class TestGetLatestRunId:
    def test_returns_id_of_most_recent_run(self, db: PipewatchDB) -> None:
        db.store_run(
            PipelineRun(
                id="run-old",
                pipeline_id="org/repo",
                branch="main",
                status=RunStatus.SUCCESS,
                started_at=datetime(2026, 3, 8, 0, 0, 0, tzinfo=UTC),
            )
        )
        db.store_run(
            PipelineRun(
                id="run-new",
                pipeline_id="org/repo",
                branch="main",
                status=RunStatus.SUCCESS,
                started_at=datetime(2026, 3, 9, 0, 0, 0, tzinfo=UTC),
            )
        )

        assert db.get_latest_run_id("org/repo") == "run-new"

    def test_returns_only_run_when_single_entry(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="solo"))

        assert db.get_latest_run_id("org/repo") == "solo"

    def test_isolated_by_pipeline_id(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r-a", pipeline_id="org/repo-a"))
        db.store_run(_make_run(run_id="r-b", pipeline_id="org/repo-b"))

        assert db.get_latest_run_id("org/repo-a") == "r-a"
        assert db.get_latest_run_id("org/repo-b") == "r-b"


# ---------------------------------------------------------------------------
# get_run_count
# ---------------------------------------------------------------------------


class TestGetRunCount:
    def test_count_reflects_stored_runs(self, db: PipewatchDB) -> None:
        for i in range(3):
            db.store_run(_make_run(run_id=f"run-{i}"))

        assert db.get_run_count("org/repo") == 3

    def test_count_isolated_by_pipeline_id(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(run_id="r1", pipeline_id="org/repo-a"))
        db.store_run(_make_run(run_id="r2", pipeline_id="org/repo-a"))
        db.store_run(_make_run(run_id="r3", pipeline_id="org/repo-b"))

        assert db.get_run_count("org/repo-a") == 2
        assert db.get_run_count("org/repo-b") == 1

    def test_upsert_does_not_inflate_count(self, db: PipewatchDB) -> None:
        """Storing the same run id twice should not increment the count."""
        db.store_run(_make_run(run_id="run-1", status=RunStatus.RUNNING))
        db.store_run(_make_run(run_id="run-1", status=RunStatus.SUCCESS))

        assert db.get_run_count("org/repo") == 1


# ---------------------------------------------------------------------------
# Empty DB edge cases
# ---------------------------------------------------------------------------


class TestEmptyDatabase:
    def test_get_runs_empty(self, db: PipewatchDB) -> None:
        assert db.get_runs("org/repo") == []

    def test_get_baselines_empty(self, db: PipewatchDB) -> None:
        assert db.get_baselines("org/repo") == {}

    def test_get_recent_drift_events_empty(self, db: PipewatchDB) -> None:
        assert db.get_recent_drift_events("org/repo") == []

    def test_get_latest_run_id_empty(self, db: PipewatchDB) -> None:
        assert db.get_latest_run_id("org/repo") is None

    def test_get_run_count_empty(self, db: PipewatchDB) -> None:
        assert db.get_run_count("org/repo") == 0

    def test_get_runs_unknown_pipeline(self, db: PipewatchDB) -> None:
        db.store_run(_make_run(pipeline_id="org/other"))

        assert db.get_runs("org/repo") == []

    def test_get_baselines_unknown_pipeline(self, db: PipewatchDB) -> None:
        db.store_baselines([_make_baseline(pipeline_id="org/other")])

        assert db.get_baselines("org/repo") == {}
