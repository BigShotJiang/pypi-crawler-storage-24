"""Tests for the drift detection engine."""

from datetime import UTC, datetime

from pipewatch.engine.drift import (
    detect_drift,
    detect_failure_spike,
    detect_trend,
    modified_z_score,
)
from pipewatch.storage.models import (
    Baseline,
    PipelineRun,
    RunStatus,
    Stage,
    TrendDirection,
)


class TestModifiedZScore:
    def test_value_at_median_returns_zero(self) -> None:
        assert modified_z_score(100.0, 100.0, 5.0) == 0.0

    def test_positive_deviation(self) -> None:
        z = modified_z_score(120.0, 100.0, 5.0)
        assert z > 0  # Slower than baseline

    def test_negative_deviation(self) -> None:
        z = modified_z_score(80.0, 100.0, 5.0)
        assert z < 0  # Faster than baseline

    def test_zero_mad_identical_value(self) -> None:
        z = modified_z_score(100.0, 100.0, 0.0)
        assert z == 0.0

    def test_zero_mad_different_value(self) -> None:
        z = modified_z_score(120.0, 100.0, 0.0)
        assert z == float("inf")


class TestDetectDrift:
    def _make_baseline(self, median: float = 100.0, mad: float = 5.0) -> Baseline:
        return Baseline(
            pipeline_id="test/repo",
            stage_name="build",
            median_duration=median,
            mad=mad,
            mean_duration=median,
            std_duration=mad * 1.4826,
            sample_size=50,
            p25_duration=median - mad,
            p75_duration=median + mad,
            min_duration=median - 3 * mad,
            max_duration=median + 3 * mad,
            pass_rate=0.95,
        )

    def _make_run(self, duration: float) -> PipelineRun:
        return PipelineRun(
            id="run-1",
            pipeline_id="test/repo",
            branch="main",
            status=RunStatus.SUCCESS,
            started_at=datetime(2025, 1, 1, tzinfo=UTC),
            stages=[Stage(name="build", status=RunStatus.SUCCESS, duration_seconds=duration)],
        )

    def test_no_drift_within_threshold(self) -> None:
        baselines = {"build": self._make_baseline(100.0, 5.0)}
        run = self._make_run(108.0)  # Within normal range

        events = detect_drift(run, baselines, z_threshold=3.0)
        assert len(events) == 0

    def test_detects_significant_drift(self) -> None:
        baselines = {"build": self._make_baseline(100.0, 5.0)}
        run = self._make_run(200.0)  # Way above baseline

        events = detect_drift(run, baselines, z_threshold=3.0)
        assert len(events) == 1
        assert events[0].stage_name == "build"
        assert events[0].metric == "duration"
        assert events[0].actual == 200.0

    def test_skips_stages_with_no_baseline(self) -> None:
        baselines = {"build": self._make_baseline()}
        run = PipelineRun(
            id="run-1",
            pipeline_id="test/repo",
            branch="main",
            status=RunStatus.SUCCESS,
            started_at=datetime(2025, 1, 1, tzinfo=UTC),
            stages=[
                Stage(name="build", status=RunStatus.SUCCESS, duration_seconds=100.0),
                Stage(name="deploy", status=RunStatus.SUCCESS, duration_seconds=500.0),
            ],
        )

        events = detect_drift(run, baselines, z_threshold=3.0)
        # deploy has no baseline, should not trigger
        assert all(e.stage_name != "deploy" for e in events)

    def test_skips_small_baselines(self) -> None:
        small_baseline = Baseline(
            pipeline_id="test/repo",
            stage_name="build",
            median_duration=100.0,
            mad=5.0,
            mean_duration=100.0,
            std_duration=7.0,
            sample_size=2,  # Too few samples
            p25_duration=95.0,
            p75_duration=105.0,
            min_duration=90.0,
            max_duration=110.0,
            pass_rate=1.0,
        )
        baselines = {"build": small_baseline}
        run = self._make_run(500.0)

        events = detect_drift(run, baselines, z_threshold=3.0)
        assert len(events) == 0  # Skipped due to small sample


class TestDetectTrend:
    def test_increasing_trend(self) -> None:
        durations = [100, 102, 105, 108, 112, 118, 125, 133, 142, 155]
        direction, p_value = detect_trend(durations)
        assert direction == TrendDirection.INCREASING
        assert p_value < 0.05

    def test_decreasing_trend(self) -> None:
        durations = [200, 195, 188, 180, 172, 165, 158, 150, 143, 135]
        direction, p_value = detect_trend(durations)
        assert direction == TrendDirection.DECREASING
        assert p_value < 0.05

    def test_stable_no_trend(self) -> None:
        durations = [100, 102, 98, 101, 99, 103, 97, 100, 102, 98]
        direction, _ = detect_trend(durations)
        assert direction == TrendDirection.STABLE

    def test_insufficient_data(self) -> None:
        durations = [100, 200, 300]  # Only 3 points, need 8
        direction, p_value = detect_trend(durations)
        assert direction == TrendDirection.STABLE
        assert p_value == 1.0


class TestDetectFailureSpike:
    def _make_run(self, status: RunStatus) -> PipelineRun:
        return PipelineRun(
            id="r",
            pipeline_id="test/repo",
            branch="main",
            status=status,
            started_at=datetime(2025, 1, 1, tzinfo=UTC),
        )

    def test_detects_spike(self) -> None:
        # Baseline: 95% pass rate. Recent: 50% failure
        recent = [self._make_run(RunStatus.FAILURE)] * 5 + [self._make_run(RunStatus.SUCCESS)] * 5
        assert detect_failure_spike(recent, baseline_pass_rate=0.95) is True

    def test_no_spike(self) -> None:
        recent = [self._make_run(RunStatus.SUCCESS)] * 9 + [self._make_run(RunStatus.FAILURE)]
        assert detect_failure_spike(recent, baseline_pass_rate=0.95) is False
