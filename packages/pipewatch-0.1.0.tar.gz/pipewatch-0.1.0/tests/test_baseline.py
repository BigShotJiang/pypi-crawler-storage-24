"""Tests for the baseline builder engine.

Engine tests are pure — feed in data, assert output. No mocks needed.
"""

from datetime import UTC, datetime

from pipewatch.engine.baseline import compute_baseline, format_duration
from pipewatch.storage.models import PipelineRun, RunStatus, Stage


def _make_run(
    stages: list[tuple[str, float, RunStatus]] | None = None,
    run_id: str = "run-1",
) -> PipelineRun:
    """Helper to create a PipelineRun with stages."""
    if stages is None:
        stages = [("build", 120.0, RunStatus.SUCCESS)]

    return PipelineRun(
        id=run_id,
        pipeline_id="test/repo",
        branch="main",
        status=RunStatus.SUCCESS,
        started_at=datetime(2025, 1, 1, tzinfo=UTC),
        finished_at=datetime(2025, 1, 1, 0, 5, tzinfo=UTC),
        stages=[
            Stage(name=name, status=status, duration_seconds=dur) for name, dur, status in stages
        ],
    )


class TestComputeBaseline:
    def test_empty_runs_returns_empty(self) -> None:
        result = compute_baseline("test/repo", [])
        assert result == []

    def test_single_stage_baseline(self) -> None:
        runs = [
            _make_run([("build", 100.0, RunStatus.SUCCESS)], "r1"),
            _make_run([("build", 110.0, RunStatus.SUCCESS)], "r2"),
            _make_run([("build", 105.0, RunStatus.SUCCESS)], "r3"),
            _make_run([("build", 108.0, RunStatus.SUCCESS)], "r4"),
            _make_run([("build", 103.0, RunStatus.SUCCESS)], "r5"),
        ]

        baselines = compute_baseline("test/repo", runs)
        assert len(baselines) == 1

        b = baselines[0]
        assert b.stage_name == "build"
        assert b.sample_size == 5
        assert b.median_duration == 105.0  # Median of [100, 103, 105, 108, 110]
        assert b.pass_rate == 1.0

    def test_multiple_stages(self) -> None:
        runs = [
            _make_run(
                [
                    ("build", 60.0, RunStatus.SUCCESS),
                    ("test", 180.0, RunStatus.SUCCESS),
                    ("deploy", 45.0, RunStatus.SUCCESS),
                ],
                f"r{i}",
            )
            for i in range(5)
        ]

        baselines = compute_baseline("test/repo", runs)
        assert len(baselines) == 3
        stage_names = {b.stage_name for b in baselines}
        assert stage_names == {"build", "test", "deploy"}

    def test_pass_rate_calculation(self) -> None:
        runs = [
            _make_run([("test", 60.0, RunStatus.SUCCESS)], "r1"),
            _make_run([("test", 65.0, RunStatus.SUCCESS)], "r2"),
            _make_run([("test", 70.0, RunStatus.FAILURE)], "r3"),
            _make_run([("test", 62.0, RunStatus.SUCCESS)], "r4"),
        ]

        baselines = compute_baseline("test/repo", runs)
        b = baselines[0]
        assert b.pass_rate == 0.75  # 3 out of 4

    def test_zero_duration_stages_excluded(self) -> None:
        runs = [
            _make_run([("build", 100.0, RunStatus.SUCCESS)], "r1"),
            _make_run([("build", 0.0, RunStatus.CANCELLED)], "r2"),  # Skipped
            _make_run([("build", 110.0, RunStatus.SUCCESS)], "r3"),
        ]

        baselines = compute_baseline("test/repo", runs)
        b = baselines[0]
        assert b.sample_size == 2  # Only non-zero durations

    def test_mad_computation(self) -> None:
        # MAD of [100, 105, 110, 200] with median=107.5
        # Deviations: [7.5, 2.5, 2.5, 92.5]
        # MAD = median of deviations = 5.0
        runs = [
            _make_run([("build", 100.0, RunStatus.SUCCESS)], "r1"),
            _make_run([("build", 105.0, RunStatus.SUCCESS)], "r2"),
            _make_run([("build", 110.0, RunStatus.SUCCESS)], "r3"),
            _make_run([("build", 200.0, RunStatus.SUCCESS)], "r4"),  # Outlier
        ]

        baselines = compute_baseline("test/repo", runs)
        b = baselines[0]
        assert b.mad == 5.0  # Robust against the 200s outlier


class TestFormatDuration:
    def test_seconds(self) -> None:
        assert format_duration(45.0) == "45s"

    def test_minutes_and_seconds(self) -> None:
        assert format_duration(132.0) == "2m 12s"

    def test_hours(self) -> None:
        assert format_duration(3672.0) == "1h 1m 12s"

    def test_exact_minute(self) -> None:
        assert format_duration(60.0) == "1m 0s"
