"""Tests for Pipewatch notification dispatchers.

Tests cover Slack, Discord, and generic webhook dispatchers, as well as
the top-level dispatch_notifications router. HTTP calls are mocked with
respx so no real network traffic is made.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock

import httpx
import pytest
import respx

from pipewatch.config import NotificationChannel
from pipewatch.notify import dispatch_notifications
from pipewatch.notify.discord import send_discord_notification
from pipewatch.notify.slack import send_slack_notification
from pipewatch.notify.webhook import send_webhook_notification
from pipewatch.storage.models import DriftEvent, TrendDirection

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

SLACK_URL = "https://hooks.slack.com/services/TEST/SLACK/WEBHOOK"
DISCORD_URL = "https://discord.com/api/webhooks/123456/test-token"
GENERIC_URL = "https://example.com/webhook"


def _make_drift_event(
    *,
    run_id: str = "run-42",
    pipeline_id: str = "org/repo",
    stage_name: str = "build",
    metric: str = "duration",
    expected: float = 100.0,
    actual: float = 180.0,
    z_score: float = 4.2,
    trend: TrendDirection = TrendDirection.INCREASING,
    probable_causes: list[str] | None = None,
    detected_at: datetime | None = None,
) -> DriftEvent:
    """Return a DriftEvent with sensible defaults for testing."""
    return DriftEvent(
        run_id=run_id,
        pipeline_id=pipeline_id,
        stage_name=stage_name,
        metric=metric,
        expected=expected,
        actual=actual,
        z_score=z_score,
        trend=trend,
        probable_causes=probable_causes or ["dependency update", "new test suite"],
        detected_at=detected_at or datetime(2026, 3, 9, 12, 0, 0, tzinfo=UTC),
    )


# ---------------------------------------------------------------------------
# Slack tests
# ---------------------------------------------------------------------------


class TestSendSlackNotification:
    @pytest.mark.asyncio
    @respx.mock
    async def test_posts_to_webhook_url(self) -> None:
        """Slack notifier must POST to the exact webhook URL provided."""
        route = respx.post(SLACK_URL).mock(return_value=httpx.Response(200))

        await send_slack_notification(SLACK_URL, [_make_drift_event()])

        assert route.called

    @pytest.mark.asyncio
    @respx.mock
    async def test_payload_contains_blocks_key(self) -> None:
        """Slack payload must use the 'blocks' format expected by the API."""
        route = respx.post(SLACK_URL).mock(return_value=httpx.Response(200))

        await send_slack_notification(SLACK_URL, [_make_drift_event()])

        sent_json = route.calls.last.request.content
        import json

        body = json.loads(sent_json)
        assert "blocks" in body
        assert isinstance(body["blocks"], list)

    @pytest.mark.asyncio
    @respx.mock
    async def test_payload_has_header_block(self) -> None:
        """First block must be the 'Pipewatch Drift Alert' header."""
        route = respx.post(SLACK_URL).mock(return_value=httpx.Response(200))

        await send_slack_notification(SLACK_URL, [_make_drift_event()])

        import json

        body = json.loads(route.calls.last.request.content)
        header = body["blocks"][0]
        assert header["type"] == "header"
        assert "Pipewatch Drift Alert" in header["text"]["text"]

    @pytest.mark.asyncio
    @respx.mock
    async def test_payload_contains_stage_name(self) -> None:
        """Each event must produce a section block mentioning the stage name."""
        route = respx.post(SLACK_URL).mock(return_value=httpx.Response(200))
        event = _make_drift_event(stage_name="integration-tests")

        await send_slack_notification(SLACK_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        section_texts = [b["text"]["text"] for b in body["blocks"] if b.get("type") == "section"]
        assert any("integration-tests" in t for t in section_texts)

    @pytest.mark.asyncio
    @respx.mock
    async def test_multiple_events_produce_multiple_section_blocks(self) -> None:
        """One section block per event must be added to the blocks list."""
        route = respx.post(SLACK_URL).mock(return_value=httpx.Response(200))
        events = [
            _make_drift_event(stage_name="build"),
            _make_drift_event(stage_name="test"),
            _make_drift_event(stage_name="deploy"),
        ]

        await send_slack_notification(SLACK_URL, events)

        import json

        body = json.loads(route.calls.last.request.content)
        section_blocks = [b for b in body["blocks"] if b.get("type") == "section"]
        assert len(section_blocks) == 3

    @pytest.mark.asyncio
    @respx.mock
    async def test_probable_causes_included_in_text(self) -> None:
        """Probable causes must appear inside the section block text."""
        route = respx.post(SLACK_URL).mock(return_value=httpx.Response(200))
        event = _make_drift_event(probable_causes=["flaky network", "cache miss"])

        await send_slack_notification(SLACK_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        full_text = " ".join(
            b["text"]["text"] for b in body["blocks"] if b.get("type") == "section"
        )
        assert "flaky network" in full_text
        assert "cache miss" in full_text

    @pytest.mark.asyncio
    @respx.mock
    async def test_raises_on_http_error(self) -> None:
        """An HTTP 500 from Slack must propagate as an exception."""
        respx.post(SLACK_URL).mock(return_value=httpx.Response(500))

        with pytest.raises(httpx.HTTPStatusError):
            await send_slack_notification(SLACK_URL, [_make_drift_event()])


# ---------------------------------------------------------------------------
# Discord tests
# ---------------------------------------------------------------------------


class TestSendDiscordNotification:
    @pytest.mark.asyncio
    @respx.mock
    async def test_posts_to_webhook_url(self) -> None:
        """Discord notifier must POST to the exact webhook URL provided."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))

        await send_discord_notification(DISCORD_URL, [_make_drift_event()])

        assert route.called

    @pytest.mark.asyncio
    @respx.mock
    async def test_payload_contains_embeds_key(self) -> None:
        """Discord payload must use the 'embeds' format expected by the API."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))

        await send_discord_notification(DISCORD_URL, [_make_drift_event()])

        import json

        body = json.loads(route.calls.last.request.content)
        assert "embeds" in body
        assert isinstance(body["embeds"], list)

    @pytest.mark.asyncio
    @respx.mock
    async def test_embed_contains_required_fields(self) -> None:
        """Each embed must contain Stage, Metric, Z-Score, Expected, Actual, Trend fields."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))
        event = _make_drift_event(stage_name="deploy", metric="duration")

        await send_discord_notification(DISCORD_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        embed = body["embeds"][0]
        field_names = {f["name"] for f in embed["fields"]}
        assert {"Stage", "Metric", "Z-Score", "Expected", "Actual", "Trend"} <= field_names

    @pytest.mark.asyncio
    @respx.mock
    async def test_embed_footer_contains_pipeline_id(self) -> None:
        """Embed footer must include the pipeline_id for traceability."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))
        event = _make_drift_event(pipeline_id="acme/backend")

        await send_discord_notification(DISCORD_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        footer_text = body["embeds"][0]["footer"]["text"]
        assert "acme/backend" in footer_text

    @pytest.mark.asyncio
    @respx.mock
    async def test_embed_color_red_for_positive_deviation(self) -> None:
        """Embed color must be red (0xFF0000) when actual > expected (slowdown)."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))
        event = _make_drift_event(expected=100.0, actual=200.0)

        await send_discord_notification(DISCORD_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        assert body["embeds"][0]["color"] == 0xFF0000

    @pytest.mark.asyncio
    @respx.mock
    async def test_embed_color_green_for_negative_deviation(self) -> None:
        """Embed color must be green (0x00FF00) when actual < expected (speedup)."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))
        event = _make_drift_event(expected=200.0, actual=100.0)

        await send_discord_notification(DISCORD_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        assert body["embeds"][0]["color"] == 0x00FF00

    @pytest.mark.asyncio
    @respx.mock
    async def test_embeds_capped_at_ten(self) -> None:
        """Discord limits embeds to 10 per message; excess events must be dropped."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))
        events = [_make_drift_event(stage_name=f"stage-{i}") for i in range(15)]

        await send_discord_notification(DISCORD_URL, events)

        import json

        body = json.loads(route.calls.last.request.content)
        assert len(body["embeds"]) == 10

    @pytest.mark.asyncio
    @respx.mock
    async def test_probable_causes_appear_as_embed_field(self) -> None:
        """Probable causes must appear as a dedicated 'Probable Causes' embed field."""
        route = respx.post(DISCORD_URL).mock(return_value=httpx.Response(204))
        event = _make_drift_event(probable_causes=["large diff", "slow disk"])

        await send_discord_notification(DISCORD_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        field_names = [f["name"] for f in body["embeds"][0]["fields"]]
        assert "Probable Causes" in field_names

    @pytest.mark.asyncio
    @respx.mock
    async def test_raises_on_http_error(self) -> None:
        """An HTTP 4xx/5xx from Discord must propagate as an exception."""
        respx.post(DISCORD_URL).mock(return_value=httpx.Response(400))

        with pytest.raises(httpx.HTTPStatusError):
            await send_discord_notification(DISCORD_URL, [_make_drift_event()])


# ---------------------------------------------------------------------------
# Generic webhook tests
# ---------------------------------------------------------------------------


class TestSendWebhookNotification:
    @pytest.mark.asyncio
    @respx.mock
    async def test_posts_to_webhook_url(self) -> None:
        """Generic webhook notifier must POST to the exact URL provided."""
        route = respx.post(GENERIC_URL).mock(return_value=httpx.Response(200))

        await send_webhook_notification(GENERIC_URL, [_make_drift_event()])

        assert route.called

    @pytest.mark.asyncio
    @respx.mock
    async def test_sends_json_content_type_header(self) -> None:
        """Request must carry Content-Type: application/json."""
        route = respx.post(GENERIC_URL).mock(return_value=httpx.Response(200))

        await send_webhook_notification(GENERIC_URL, [_make_drift_event()])

        content_type = route.calls.last.request.headers.get("content-type", "")
        assert "application/json" in content_type

    @pytest.mark.asyncio
    @respx.mock
    async def test_payload_top_level_structure(self) -> None:
        """Payload must contain 'source', 'event_type', and 'events' keys."""
        route = respx.post(GENERIC_URL).mock(return_value=httpx.Response(200))

        await send_webhook_notification(GENERIC_URL, [_make_drift_event()])

        import json

        body = json.loads(route.calls.last.request.content)
        assert body["source"] == "pipewatch"
        assert body["event_type"] == "drift_alert"
        assert isinstance(body["events"], list)

    @pytest.mark.asyncio
    @respx.mock
    async def test_event_fields_are_serialized(self) -> None:
        """Each event entry must contain all expected fields with correct values."""
        route = respx.post(GENERIC_URL).mock(return_value=httpx.Response(200))
        detected = datetime(2026, 3, 9, 12, 0, 0, tzinfo=UTC)
        event = _make_drift_event(
            run_id="run-99",
            pipeline_id="org/service",
            stage_name="lint",
            metric="duration",
            expected=30.0,
            actual=90.0,
            z_score=5.1,
            trend=TrendDirection.INCREASING,
            probable_causes=["new linter rules"],
            detected_at=detected,
        )

        await send_webhook_notification(GENERIC_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        entry = body["events"][0]

        assert entry["run_id"] == "run-99"
        assert entry["pipeline_id"] == "org/service"
        assert entry["stage_name"] == "lint"
        assert entry["metric"] == "duration"
        assert entry["expected"] == 30.0
        assert entry["actual"] == 90.0
        assert entry["z_score"] == 5.1
        assert entry["trend"] == "increasing"
        assert entry["probable_causes"] == ["new linter rules"]
        assert entry["detected_at"] == "2026-03-09T12:00:00+00:00"

    @pytest.mark.asyncio
    @respx.mock
    async def test_deviation_pct_is_included(self) -> None:
        """Payload must include the computed deviation_pct for each event."""
        route = respx.post(GENERIC_URL).mock(return_value=httpx.Response(200))
        event = _make_drift_event(expected=100.0, actual=150.0)

        await send_webhook_notification(GENERIC_URL, [event])

        import json

        body = json.loads(route.calls.last.request.content)
        assert body["events"][0]["deviation_pct"] == pytest.approx(50.0)

    @pytest.mark.asyncio
    @respx.mock
    async def test_multiple_events_all_serialized(self) -> None:
        """All events in the list must appear in the payload."""
        route = respx.post(GENERIC_URL).mock(return_value=httpx.Response(200))
        events = [
            _make_drift_event(stage_name="build"),
            _make_drift_event(stage_name="test"),
        ]

        await send_webhook_notification(GENERIC_URL, events)

        import json

        body = json.loads(route.calls.last.request.content)
        stage_names = [e["stage_name"] for e in body["events"]]
        assert stage_names == ["build", "test"]

    @pytest.mark.asyncio
    @respx.mock
    async def test_raises_on_http_error(self) -> None:
        """An HTTP error response must propagate as an exception."""
        respx.post(GENERIC_URL).mock(return_value=httpx.Response(503))

        with pytest.raises(httpx.HTTPStatusError):
            await send_webhook_notification(GENERIC_URL, [_make_drift_event()])


# ---------------------------------------------------------------------------
# dispatch_notifications router tests
# ---------------------------------------------------------------------------


class TestDispatchNotifications:
    def _slack_channel(self) -> NotificationChannel:
        return NotificationChannel(type="slack", webhook=SLACK_URL)

    def _discord_channel(self) -> NotificationChannel:
        return NotificationChannel(type="discord", webhook=DISCORD_URL)

    def _webhook_channel(self) -> NotificationChannel:
        return NotificationChannel(type="webhook", webhook=GENERIC_URL)

    @pytest.mark.asyncio
    async def test_routes_to_slack(self) -> None:
        """dispatch_notifications must call send_slack_notification for 'slack' type."""
        import pipewatch.notify.slack as slack_mod

        mock_fn = AsyncMock()
        events = [_make_drift_event()]
        original = slack_mod.send_slack_notification
        slack_mod.send_slack_notification = mock_fn  # type: ignore[assignment]
        try:
            await dispatch_notifications([self._slack_channel()], events)
            mock_fn.assert_awaited_once_with(SLACK_URL, events)
        finally:
            slack_mod.send_slack_notification = original  # type: ignore[assignment]

    @pytest.mark.asyncio
    async def test_routes_to_discord(self) -> None:
        """dispatch_notifications must call send_discord_notification for 'discord' type."""
        import pipewatch.notify.discord as discord_mod

        mock_fn = AsyncMock()
        events = [_make_drift_event()]
        original = discord_mod.send_discord_notification
        discord_mod.send_discord_notification = mock_fn  # type: ignore[assignment]
        try:
            await dispatch_notifications([self._discord_channel()], events)
            mock_fn.assert_awaited_once_with(DISCORD_URL, events)
        finally:
            discord_mod.send_discord_notification = original  # type: ignore[assignment]

    @pytest.mark.asyncio
    async def test_routes_to_generic_webhook(self) -> None:
        """dispatch_notifications must call send_webhook_notification for 'webhook' type."""
        import pipewatch.notify.webhook as webhook_mod

        mock_fn = AsyncMock()
        events = [_make_drift_event()]
        original = webhook_mod.send_webhook_notification
        webhook_mod.send_webhook_notification = mock_fn  # type: ignore[assignment]
        try:
            await dispatch_notifications([self._webhook_channel()], events)
            mock_fn.assert_awaited_once_with(GENERIC_URL, events)
        finally:
            webhook_mod.send_webhook_notification = original  # type: ignore[assignment]

    @pytest.mark.asyncio
    async def test_dispatches_to_multiple_channels(self) -> None:
        """All channels in the list must each receive their notification."""
        import pipewatch.notify.discord as discord_mod
        import pipewatch.notify.slack as slack_mod

        slack_mock = AsyncMock()
        discord_mock = AsyncMock()
        events = [_make_drift_event()]

        original_slack = slack_mod.send_slack_notification
        original_discord = discord_mod.send_discord_notification
        slack_mod.send_slack_notification = slack_mock  # type: ignore[assignment]
        discord_mod.send_discord_notification = discord_mock  # type: ignore[assignment]
        try:
            await dispatch_notifications(
                [self._slack_channel(), self._discord_channel()],
                events,
            )
            slack_mock.assert_awaited_once()
            discord_mock.assert_awaited_once()
        finally:
            slack_mod.send_slack_notification = original_slack  # type: ignore[assignment]
            discord_mod.send_discord_notification = original_discord  # type: ignore[assignment]

    @pytest.mark.asyncio
    async def test_unknown_channel_type_is_silently_skipped(self) -> None:
        """An unrecognized channel type must not dispatch or raise."""
        channel = NotificationChannel(type="pagerduty", webhook="https://example.com")
        # Should complete without error and without making any network calls
        await dispatch_notifications([channel], [_make_drift_event()])

    @pytest.mark.asyncio
    async def test_error_in_one_channel_does_not_abort_others(self) -> None:
        """A failure in one dispatcher must not prevent subsequent channels from running."""
        import pipewatch.notify.discord as discord_mod
        import pipewatch.notify.slack as slack_mod

        failing_slack = AsyncMock(side_effect=httpx.ConnectError("timeout"))
        succeeding_discord = AsyncMock()
        events = [_make_drift_event()]

        original_slack = slack_mod.send_slack_notification
        original_discord = discord_mod.send_discord_notification
        slack_mod.send_slack_notification = failing_slack  # type: ignore[assignment]
        discord_mod.send_discord_notification = succeeding_discord  # type: ignore[assignment]
        try:
            # Must not raise even though Slack failed
            await dispatch_notifications(
                [self._slack_channel(), self._discord_channel()],
                events,
            )
            succeeding_discord.assert_awaited_once()
        finally:
            slack_mod.send_slack_notification = original_slack  # type: ignore[assignment]
            discord_mod.send_discord_notification = original_discord  # type: ignore[assignment]

    @pytest.mark.asyncio
    async def test_empty_channel_list_does_not_raise(self) -> None:
        """Calling dispatch_notifications with no channels must be a no-op."""
        await dispatch_notifications([], [_make_drift_event()])

    @pytest.mark.asyncio
    async def test_empty_events_list_still_dispatches(self) -> None:
        """dispatch_notifications must still call the dispatcher even with zero events."""
        import pipewatch.notify.slack as slack_mod

        mock_fn = AsyncMock()
        original = slack_mod.send_slack_notification
        slack_mod.send_slack_notification = mock_fn  # type: ignore[assignment]
        try:
            await dispatch_notifications([self._slack_channel()], [])
            mock_fn.assert_awaited_once_with(SLACK_URL, [])
        finally:
            slack_mod.send_slack_notification = original  # type: ignore[assignment]
