---
name: New Provider Request
about: Request support for a new CI/CD platform
title: "[Provider] Add support for <PLATFORM>"
labels: enhancement, new-provider
assignees: ''
---

## CI/CD Platform

**Name:** (e.g., CircleCI, Bitbucket Pipelines, Azure DevOps)

**API Documentation:** (link to their REST API docs)

## Authentication

How does the API authenticate? (API token, OAuth, etc.)

## Data Available

- [ ] Workflow/pipeline run history
- [ ] Per-job/stage durations
- [ ] Test results
- [ ] Commit information
- [ ] Artifacts/build output size

## Additional Context

Any quirks or limitations of this platform's API?
