"""Slack webhook notification dispatcher."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from pipewatch.engine.baseline import format_duration

if TYPE_CHECKING:
    from pipewatch.storage.models import DriftEvent


async def send_slack_notification(webhook_url: str, events: list[DriftEvent]) -> None:
    """Send drift alerts to a Slack webhook."""
    blocks = []

    blocks.append(
        {
            "type": "header",
            "text": {"type": "plain_text", "text": "Pipewatch Drift Alert"},
        }
    )

    for event in events:
        dev_pct = event.deviation_pct
        trend_icon = {"increasing": "↗", "decreasing": "↘", "stable": "→"}
        icon = trend_icon.get(event.trend.value, "?")

        text = (
            f"*Stage:* `{event.stage_name}`\n"
            f"*Metric:* {event.metric}\n"
            f"*Expected:* {format_duration(event.expected)} → "
            f"*Actual:* {format_duration(event.actual)} ({dev_pct:+.0f}%)\n"
            f"*Z-Score:* {event.z_score:.1f} {icon}\n"
        )

        if event.probable_causes:
            text += "*Probable causes:*\n"
            for cause in event.probable_causes:
                text += f"  • {cause}\n"

        blocks.append(
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": text},
            }
        )

    payload = {"blocks": blocks}

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(webhook_url, json=payload)
        response.raise_for_status()
