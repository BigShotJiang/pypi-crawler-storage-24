"""Notification dispatchers for Pipewatch drift alerts."""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import urlparse

if TYPE_CHECKING:
    from pipewatch.config import NotificationChannel
    from pipewatch.storage.models import DriftEvent

_ALLOWED_SCHEMES = {"https", "http"}


def _validate_webhook_url(url: str) -> None:
    """Validate that a webhook URL uses an allowed scheme.

    Raises:
        ValueError: If the URL scheme is not http/https.
    """
    parsed = urlparse(url)
    if parsed.scheme not in _ALLOWED_SCHEMES:
        msg = f"Webhook URL must use http:// or https://, got {parsed.scheme!r}"
        raise ValueError(msg)
    if not parsed.netloc:
        msg = f"Webhook URL has no host: {url!r}"
        raise ValueError(msg)


async def dispatch_notifications(
    channels: list[NotificationChannel],
    events: list[DriftEvent],
) -> None:
    """Dispatch drift events to all configured notification channels."""
    for channel in channels:
        try:
            _validate_webhook_url(channel.webhook)

            if channel.type == "slack":
                from pipewatch.notify.slack import send_slack_notification

                await send_slack_notification(channel.webhook, events)
            elif channel.type == "discord":
                from pipewatch.notify.discord import send_discord_notification

                await send_discord_notification(channel.webhook, events)
            elif channel.type == "webhook":
                from pipewatch.notify.webhook import send_webhook_notification

                await send_webhook_notification(channel.webhook, events)
        except Exception:
            import structlog

            structlog.get_logger().warning("notification_failed", channel_type=channel.type)
