"""Generic webhook notification dispatcher."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from pipewatch.storage.models import DriftEvent


async def send_webhook_notification(webhook_url: str, events: list[DriftEvent]) -> None:
    """Send drift alerts to a generic webhook endpoint as JSON."""
    payload = {
        "source": "pipewatch",
        "event_type": "drift_alert",
        "events": [
            {
                "run_id": e.run_id,
                "pipeline_id": e.pipeline_id,
                "stage_name": e.stage_name,
                "metric": e.metric,
                "expected": e.expected,
                "actual": e.actual,
                "z_score": e.z_score,
                "deviation_pct": e.deviation_pct,
                "trend": e.trend.value,
                "probable_causes": e.probable_causes,
                "detected_at": e.detected_at.isoformat(),
            }
            for e in events
        ],
    }

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(
            webhook_url,
            json=payload,
            headers={"Content-Type": "application/json"},
        )
        response.raise_for_status()
