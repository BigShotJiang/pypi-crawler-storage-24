"""Discord webhook notification dispatcher."""

from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from pipewatch.engine.baseline import format_duration

if TYPE_CHECKING:
    from pipewatch.storage.models import DriftEvent


async def send_discord_notification(webhook_url: str, events: list[DriftEvent]) -> None:
    """Send drift alerts to a Discord webhook."""
    embeds = []

    for event in events:
        dev_pct = event.deviation_pct
        color = 0xFF0000 if dev_pct > 0 else 0x00FF00

        fields = [
            {"name": "Stage", "value": f"`{event.stage_name}`", "inline": True},
            {"name": "Metric", "value": event.metric, "inline": True},
            {"name": "Z-Score", "value": f"{event.z_score:.1f}", "inline": True},
            {
                "name": "Expected",
                "value": format_duration(event.expected),
                "inline": True,
            },
            {
                "name": "Actual",
                "value": f"{format_duration(event.actual)} ({dev_pct:+.0f}%)",
                "inline": True,
            },
            {"name": "Trend", "value": event.trend.value, "inline": True},
        ]

        if event.probable_causes:
            causes_text = "\n".join(f"• {c}" for c in event.probable_causes)
            fields.append({"name": "Probable Causes", "value": causes_text})

        embeds.append(
            {
                "title": "Pipewatch Drift Alert",
                "color": color,
                "fields": fields,
                "footer": {"text": f"Pipeline: {event.pipeline_id}"},
            }
        )

    payload = {"embeds": embeds[:10]}

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(webhook_url, json=payload)
        response.raise_for_status()
