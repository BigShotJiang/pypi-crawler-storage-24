"""GitHub Actions provider adapter.

Fetches workflow run data from the GitHub REST API.
Docs: https://docs.github.com/en/rest/actions/workflow-runs
"""

from __future__ import annotations

import os
import re
from datetime import UTC, datetime

import httpx
import structlog

from pipewatch.providers.base import PipelineProvider
from pipewatch.storage.models import PipelineRun, RunStatus, Stage

logger = structlog.get_logger()

GITHUB_API_BASE = "https://api.github.com"

# Validation patterns to prevent URL path injection
_REPO_PATTERN = re.compile(r"^[a-zA-Z0-9._-]+/[a-zA-Z0-9._-]+$")
_RUN_ID_PATTERN = re.compile(r"^[0-9]+$")
_SHA_PATTERN = re.compile(r"^[0-9a-fA-F]{7,40}$")


def _parse_status(status: str, conclusion: str | None) -> RunStatus:
    """Map GitHub's status/conclusion to our RunStatus."""
    if status == "in_progress":
        return RunStatus.RUNNING
    if status == "queued":
        return RunStatus.PENDING

    match conclusion:
        case "success":
            return RunStatus.SUCCESS
        case "failure":
            return RunStatus.FAILURE
        case "cancelled":
            return RunStatus.CANCELLED
        case _:
            return RunStatus.UNKNOWN


def _parse_dt(s: str | None) -> datetime | None:
    """Parse ISO datetime string from GitHub API."""
    if not s:
        return None
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


class GitHubProvider(PipelineProvider):
    """GitHub Actions CI/CD provider."""

    def __init__(self, repo: str, token: str | None = None) -> None:
        """Initialize GitHub provider.

        Args:
            repo: Repository in 'owner/repo' format.
            token: GitHub personal access token. Falls back to GITHUB_TOKEN env var.

        Raises:
            ValueError: If repo format is invalid.
        """
        if not _REPO_PATTERN.match(repo):
            msg = f"Invalid repo format: {repo!r}. Expected 'owner/repo'."
            raise ValueError(msg)
        self.repo = repo
        self._token = token or os.environ.get("GITHUB_TOKEN", "")
        self._client = httpx.AsyncClient(
            base_url=GITHUB_API_BASE,
            headers=self._build_headers(),
            timeout=30.0,
        )

    @property
    def name(self) -> str:
        return "GitHub Actions"

    def _build_headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    async def fetch_runs(self, limit: int = 50) -> list[PipelineRun]:
        """Fetch recent workflow runs from GitHub Actions."""
        runs: list[PipelineRun] = []
        per_page = min(limit, 100)

        response = await self._client.get(
            f"/repos/{self.repo}/actions/runs",
            params={"per_page": per_page, "page": 1},
        )
        response.raise_for_status()
        self._log_rate_limit(response)

        data = response.json()

        for run_data in data.get("workflow_runs", [])[:limit]:
            started = _parse_dt(run_data.get("run_started_at") or run_data.get("created_at"))
            if not started:
                continue

            runs.append(
                PipelineRun(
                    id=str(run_data["id"]),
                    pipeline_id=f"{self.repo}/{run_data.get('workflow_id', 'unknown')}",
                    branch=run_data.get("head_branch", "unknown"),
                    status=_parse_status(
                        run_data.get("status", ""),
                        run_data.get("conclusion"),
                    ),
                    started_at=started,
                    finished_at=_parse_dt(run_data.get("updated_at")),
                    commit_sha=run_data.get("head_sha", ""),
                    commit_message=run_data.get("display_title", ""),
                    trigger=run_data.get("event", ""),
                )
            )

        logger.info("fetched_runs", provider="github", repo=self.repo, count=len(runs))
        return runs

    async def fetch_run_detail(self, run_id: str) -> PipelineRun:
        """Fetch a single run with full job/stage details."""
        if not _RUN_ID_PATTERN.match(run_id):
            msg = f"Invalid run ID: {run_id!r}. Expected numeric."
            raise ValueError(msg)
        # Fetch the run itself
        run_resp = await self._client.get(f"/repos/{self.repo}/actions/runs/{run_id}")
        run_resp.raise_for_status()
        run_data = run_resp.json()

        # Fetch jobs (stages) for this run
        jobs_resp = await self._client.get(f"/repos/{self.repo}/actions/runs/{run_id}/jobs")
        jobs_resp.raise_for_status()
        jobs_data = jobs_resp.json()

        stages: list[Stage] = []
        for job in jobs_data.get("jobs", []):
            started = _parse_dt(job.get("started_at"))
            finished = _parse_dt(job.get("completed_at"))

            duration = 0.0
            if started and finished:
                duration = (finished - started).total_seconds()

            stages.append(
                Stage(
                    name=job.get("name", "unknown"),
                    status=_parse_status(job.get("status", ""), job.get("conclusion")),
                    duration_seconds=duration,
                    started_at=started,
                    finished_at=finished,
                )
            )

        started_at = _parse_dt(run_data.get("run_started_at") or run_data.get("created_at"))
        if not started_at:
            started_at = datetime.now(UTC)

        return PipelineRun(
            id=str(run_data["id"]),
            pipeline_id=f"{self.repo}/{run_data.get('workflow_id', 'unknown')}",
            branch=run_data.get("head_branch", "unknown"),
            status=_parse_status(run_data.get("status", ""), run_data.get("conclusion")),
            started_at=started_at,
            finished_at=_parse_dt(run_data.get("updated_at")),
            stages=stages,
            commit_sha=run_data.get("head_sha", ""),
            commit_message=run_data.get("display_title", ""),
            trigger=run_data.get("event", ""),
        )

    async def fetch_commit_diff(self, sha: str) -> dict[str, list[str]]:
        """Fetch files changed in a commit."""
        if not _SHA_PATTERN.match(sha):
            msg = f"Invalid commit SHA: {sha!r}. Expected hex string."
            raise ValueError(msg)
        response = await self._client.get(f"/repos/{self.repo}/commits/{sha}")
        response.raise_for_status()
        data = response.json()

        result: dict[str, list[str]] = {"added": [], "modified": [], "removed": []}
        for file_info in data.get("files", []):
            status = file_info.get("status", "modified")
            filename = file_info.get("filename", "")
            if status in result:
                result[status].append(filename)
            else:
                result["modified"].append(filename)

        return result

    def _log_rate_limit(self, response: httpx.Response) -> None:
        """Log GitHub API rate limit status."""
        remaining = response.headers.get("X-RateLimit-Remaining")
        limit = response.headers.get("X-RateLimit-Limit")
        if remaining and limit:
            logger.debug("github_rate_limit", remaining=remaining, limit=limit)
            if int(remaining) < 100:
                logger.warning("github_rate_limit_low", remaining=remaining)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()
