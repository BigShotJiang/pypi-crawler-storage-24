"""Abstract base class for CI/CD pipeline providers.

Every provider adapter (GitHub, GitLab, Jenkins, etc.) must implement
this interface. Adding a new provider = creating one new file that
subclasses PipelineProvider.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pipewatch.storage.models import PipelineRun, TestResult


class PipelineProvider(ABC):
    """Abstract interface for CI/CD platform adapters."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable provider name (e.g., 'GitHub Actions')."""
        ...

    @abstractmethod
    async def fetch_runs(self, limit: int = 50) -> list[PipelineRun]:
        """Fetch recent pipeline runs.

        Args:
            limit: Maximum number of runs to fetch.

        Returns:
            List of PipelineRun objects, most recent first.
        """
        ...

    @abstractmethod
    async def fetch_run_detail(self, run_id: str) -> PipelineRun:
        """Fetch detailed information about a specific run.

        Args:
            run_id: The unique identifier of the run.

        Returns:
            PipelineRun with full stage information.
        """
        ...

    async def fetch_test_results(self, run_id: str) -> list[TestResult]:
        """Fetch test results for a specific run.

        Optional — not all providers expose test results via API.
        Default implementation returns empty list.

        Args:
            run_id: The unique identifier of the run.

        Returns:
            List of TestResult objects.
        """
        return []

    async def fetch_commit_diff(self, sha: str) -> dict[str, list[str]]:
        """Fetch files changed in a commit.

        Optional — used by the correlator for root cause analysis.
        Default implementation returns empty dict.

        Args:
            sha: The commit SHA.

        Returns:
            Dict with keys 'added', 'modified', 'removed', each a list of file paths.
        """
        return {"added": [], "modified": [], "removed": []}
