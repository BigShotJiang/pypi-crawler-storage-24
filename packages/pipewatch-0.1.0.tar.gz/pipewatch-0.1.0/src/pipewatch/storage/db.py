"""SQLite storage layer for Pipewatch.

All data is stored locally in ~/.pipewatch/data.db.
Zero infrastructure — ships with Python.
"""

from __future__ import annotations

import json
import os
import sqlite3
import stat
from datetime import datetime
from pathlib import Path

from pipewatch.storage.models import (
    Baseline,
    DriftEvent,
    PipelineRun,
    RunStatus,
    Stage,
    TrendDirection,
)

DEFAULT_DB_PATH = Path.home() / ".pipewatch" / "data.db"

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY,
    pipeline_id TEXT NOT NULL,
    branch TEXT NOT NULL,
    status TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    commit_sha TEXT,
    commit_message TEXT,
    trigger_type TEXT,
    stages_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS baselines (
    pipeline_id TEXT NOT NULL,
    stage_name TEXT NOT NULL,
    median_duration REAL NOT NULL,
    mad REAL NOT NULL,
    mean_duration REAL NOT NULL,
    std_duration REAL NOT NULL,
    sample_size INTEGER NOT NULL,
    p25_duration REAL NOT NULL,
    p75_duration REAL NOT NULL,
    min_duration REAL NOT NULL,
    max_duration REAL NOT NULL,
    pass_rate REAL NOT NULL,
    computed_at TEXT NOT NULL,
    PRIMARY KEY (pipeline_id, stage_name)
);

CREATE TABLE IF NOT EXISTS drift_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    pipeline_id TEXT NOT NULL,
    stage_name TEXT NOT NULL,
    metric TEXT NOT NULL,
    expected REAL NOT NULL,
    actual REAL NOT NULL,
    z_score REAL NOT NULL,
    trend TEXT NOT NULL DEFAULT 'stable',
    probable_causes_json TEXT NOT NULL DEFAULT '[]',
    detected_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_runs_pipeline ON runs(pipeline_id);
CREATE INDEX IF NOT EXISTS idx_runs_branch ON runs(branch);
CREATE INDEX IF NOT EXISTS idx_drift_pipeline ON drift_events(pipeline_id);
"""


class PipewatchDB:
    """Local SQLite database for Pipewatch data."""

    def __init__(self, db_path: Path = DEFAULT_DB_PATH) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        # Restrict directory to owner-only on Unix systems
        if os.name != "nt":
            db_path.parent.chmod(stat.S_IRWXU)
        self._conn = sqlite3.connect(str(db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_schema()
        # Restrict DB file to owner-only on Unix systems
        if db_path.exists() and os.name != "nt":
            db_path.chmod(stat.S_IRUSR | stat.S_IWUSR)

    def _init_schema(self) -> None:
        self._conn.executescript(SCHEMA_SQL)
        self._conn.commit()

    def store_run(self, run: PipelineRun) -> None:
        """Store a pipeline run."""
        stages_json = json.dumps(
            [
                {
                    "name": s.name,
                    "status": s.status.value,
                    "duration_seconds": s.duration_seconds,
                    "started_at": s.started_at.isoformat() if s.started_at else None,
                    "finished_at": s.finished_at.isoformat() if s.finished_at else None,
                }
                for s in run.stages
            ]
        )

        self._conn.execute(
            """INSERT OR REPLACE INTO runs
            (id, pipeline_id, branch, status, started_at, finished_at,
             commit_sha, commit_message, trigger_type, stages_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                run.id,
                run.pipeline_id,
                run.branch,
                run.status.value,
                run.started_at.isoformat(),
                run.finished_at.isoformat() if run.finished_at else None,
                run.commit_sha,
                run.commit_message,
                run.trigger,
                stages_json,
            ),
        )
        self._conn.commit()

    def store_baselines(self, baselines: list[Baseline]) -> None:
        """Store or update baselines."""
        for b in baselines:
            self._conn.execute(
                """INSERT OR REPLACE INTO baselines
                (pipeline_id, stage_name, median_duration, mad, mean_duration,
                 std_duration, sample_size, p25_duration, p75_duration,
                 min_duration, max_duration, pass_rate, computed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    b.pipeline_id,
                    b.stage_name,
                    b.median_duration,
                    b.mad,
                    b.mean_duration,
                    b.std_duration,
                    b.sample_size,
                    b.p25_duration,
                    b.p75_duration,
                    b.min_duration,
                    b.max_duration,
                    b.pass_rate,
                    b.computed_at.isoformat(),
                ),
            )
        self._conn.commit()

    def get_baselines(self, pipeline_id: str) -> dict[str, Baseline]:
        """Get all baselines for a pipeline, keyed by stage name."""
        rows = self._conn.execute(
            "SELECT * FROM baselines WHERE pipeline_id = ?", (pipeline_id,)
        ).fetchall()

        return {
            row["stage_name"]: Baseline(
                pipeline_id=row["pipeline_id"],
                stage_name=row["stage_name"],
                median_duration=row["median_duration"],
                mad=row["mad"],
                mean_duration=row["mean_duration"],
                std_duration=row["std_duration"],
                sample_size=row["sample_size"],
                p25_duration=row["p25_duration"],
                p75_duration=row["p75_duration"],
                min_duration=row["min_duration"],
                max_duration=row["max_duration"],
                pass_rate=row["pass_rate"],
                computed_at=datetime.fromisoformat(row["computed_at"]),
            )
            for row in rows
        }

    def store_drift_event(self, event: DriftEvent) -> None:
        """Store a drift event."""
        self._conn.execute(
            """INSERT INTO drift_events
            (run_id, pipeline_id, stage_name, metric, expected, actual,
             z_score, trend, probable_causes_json, detected_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                event.run_id,
                event.pipeline_id,
                event.stage_name,
                event.metric,
                event.expected,
                event.actual,
                event.z_score,
                event.trend.value,
                json.dumps(event.probable_causes),
                event.detected_at.isoformat(),
            ),
        )
        self._conn.commit()

    def get_recent_drift_events(self, pipeline_id: str, limit: int = 20) -> list[DriftEvent]:
        """Fetch recent drift events for a pipeline."""
        rows = self._conn.execute(
            """SELECT * FROM drift_events
            WHERE pipeline_id = ?
            ORDER BY detected_at DESC LIMIT ?""",
            (pipeline_id, limit),
        ).fetchall()

        return [
            DriftEvent(
                run_id=row["run_id"],
                pipeline_id=row["pipeline_id"],
                stage_name=row["stage_name"],
                metric=row["metric"],
                expected=row["expected"],
                actual=row["actual"],
                z_score=row["z_score"],
                trend=TrendDirection(row["trend"]),
                probable_causes=json.loads(row["probable_causes_json"]),
                detected_at=datetime.fromisoformat(row["detected_at"]),
            )
            for row in rows
        ]

    def get_runs(
        self, pipeline_id: str, limit: int = 50, branch: str | None = None
    ) -> list[PipelineRun]:
        """Fetch stored runs for a pipeline."""
        if branch:
            rows = self._conn.execute(
                """SELECT * FROM runs
                WHERE pipeline_id = ? AND branch = ?
                ORDER BY started_at DESC LIMIT ?""",
                (pipeline_id, branch, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                """SELECT * FROM runs
                WHERE pipeline_id = ?
                ORDER BY started_at DESC LIMIT ?""",
                (pipeline_id, limit),
            ).fetchall()

        return [self._row_to_run(row) for row in rows]

    def get_latest_run_id(self, pipeline_id: str) -> str | None:
        """Get the ID of the most recent run for a pipeline."""
        row = self._conn.execute(
            """SELECT id FROM runs
            WHERE pipeline_id = ?
            ORDER BY started_at DESC LIMIT 1""",
            (pipeline_id,),
        ).fetchone()
        return row["id"] if row else None

    def get_run_count(self, pipeline_id: str) -> int:
        """Get total number of stored runs for a pipeline."""
        row = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM runs WHERE pipeline_id = ?",
            (pipeline_id,),
        ).fetchone()
        return row["cnt"] if row else 0

    def _row_to_run(self, row: sqlite3.Row) -> PipelineRun:
        """Convert a database row to a PipelineRun."""
        stages_data = json.loads(row["stages_json"])
        stages = [
            Stage(
                name=s["name"],
                status=RunStatus(s["status"]),
                duration_seconds=s["duration_seconds"],
                started_at=(
                    datetime.fromisoformat(s["started_at"]) if s.get("started_at") else None
                ),
                finished_at=(
                    datetime.fromisoformat(s["finished_at"]) if s.get("finished_at") else None
                ),
            )
            for s in stages_data
        ]

        return PipelineRun(
            id=row["id"],
            pipeline_id=row["pipeline_id"],
            branch=row["branch"],
            status=RunStatus(row["status"]),
            started_at=datetime.fromisoformat(row["started_at"]),
            finished_at=datetime.fromisoformat(row["finished_at"]) if row["finished_at"] else None,
            stages=stages,
            commit_sha=row["commit_sha"] or "",
            commit_message=row["commit_message"] or "",
            trigger=row["trigger_type"] or "",
        )

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()
