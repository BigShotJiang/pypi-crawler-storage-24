"""Data models for Pipewatch.

All models are frozen dataclasses — immutable by design.
These are the canonical representations of pipeline data used across
providers, engine, storage, and UI layers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum


class RunStatus(Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    CANCELLED = "cancelled"
    RUNNING = "running"
    PENDING = "pending"
    UNKNOWN = "unknown"


class TrendDirection(Enum):
    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"


@dataclass(frozen=True)
class Stage:
    """A single stage/job within a pipeline run."""

    name: str
    status: RunStatus
    duration_seconds: float
    started_at: datetime | None = None
    finished_at: datetime | None = None


@dataclass(frozen=True)
class PipelineRun:
    """A complete pipeline run with all its stages."""

    id: str
    pipeline_id: str
    branch: str
    status: RunStatus
    started_at: datetime
    finished_at: datetime | None = None
    stages: list[Stage] = field(default_factory=list)
    commit_sha: str = ""
    commit_message: str = ""
    trigger: str = ""  # push, pr, schedule, manual


@dataclass(frozen=True)
class TestResult:
    """A single test case result."""

    name: str
    suite: str
    status: RunStatus
    duration_seconds: float
    error_message: str = ""


@dataclass(frozen=True)
class Baseline:
    """Statistical baseline for a pipeline stage."""

    pipeline_id: str
    stage_name: str
    median_duration: float
    mad: float  # Median Absolute Deviation
    mean_duration: float
    std_duration: float
    sample_size: int
    p25_duration: float
    p75_duration: float
    min_duration: float
    max_duration: float
    pass_rate: float
    computed_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass(frozen=True)
class DriftEvent:
    """A detected drift from the baseline."""

    run_id: str
    pipeline_id: str
    stage_name: str
    metric: str  # "duration", "failure_rate", "artifact_size"
    expected: float
    actual: float
    z_score: float
    trend: TrendDirection
    probable_causes: list[str] = field(default_factory=list)
    detected_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    @property
    def deviation_pct(self) -> float:
        """Percentage deviation from expected."""
        if self.expected == 0:
            return 0.0
        return ((self.actual - self.expected) / self.expected) * 100


@dataclass(frozen=True)
class FlakyTest:
    """A test identified as flaky (non-deterministic)."""

    name: str
    suite: str
    pipeline_id: str
    total_runs: int
    failure_count: int
    flip_count: int  # Number of pass→fail or fail→pass transitions
    flip_rate: float  # Bayesian estimate of flip probability
    last_seen: datetime = field(default_factory=lambda: datetime.now(UTC))

    @property
    def failure_rate(self) -> float:
        if self.total_runs == 0:
            return 0.0
        return self.failure_count / self.total_runs


@dataclass(frozen=True)
class PipelineHealth:
    """Overall health summary for a pipeline."""

    pipeline_id: str
    health_score: int  # 0–100
    total_runs_analyzed: int
    active_drift_events: list[DriftEvent]
    flaky_tests: list[FlakyTest]
    stage_baselines: list[Baseline]
    last_updated: datetime = field(default_factory=lambda: datetime.now(UTC))
