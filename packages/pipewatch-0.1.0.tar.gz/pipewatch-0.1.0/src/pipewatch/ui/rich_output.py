"""Rich terminal output for Pipewatch.

All user-facing console output goes through this module.
Never use print() directly — always use these functions.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from pipewatch.engine.baseline import format_duration
from pipewatch.storage.models import Baseline, DriftEvent, FlakyTest, TrendDirection

console = Console()

BANNER = """
[bold cyan]╔═══════════════════════════════════════════════╗
║              [bold white]P I P E W A T C H[/bold white]                ║
║     [dim]Your pipeline is drifting.[/dim]                ║
║     [dim]You just don't know it yet.[/dim]               ║
╚═══════════════════════════════════════════════╝[/bold cyan]
"""


def print_banner() -> None:
    """Print the Pipewatch banner."""
    console.print(BANNER)


def print_success(message: str) -> None:
    """Print a success message."""
    console.print(f"[bold green]✅ {message}[/]")


def print_error(message: str) -> None:
    """Print an error message."""
    console.print(f"[bold red]❌ {message}[/]")


def print_warning(message: str) -> None:
    """Print a warning message."""
    console.print(f"[bold yellow]⚠️  {message}[/]")


def print_info(message: str) -> None:
    """Print an info message."""
    console.print(f"[bold blue]ℹ️  {message}[/]")


def print_baseline_summary(baselines: list[Baseline], pipeline_id: str) -> None:
    """Print a summary of the computed baseline."""
    table = Table(
        title=f"[bold]Baseline: {pipeline_id}[/]",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Stage", style="bold")
    table.add_column("Median", justify="right")
    table.add_column("MAD", justify="right")
    table.add_column("Range", justify="right")
    table.add_column("Pass Rate", justify="right")
    table.add_column("Samples", justify="right")

    for b in baselines:
        pass_color = "green" if b.pass_rate > 0.95 else "yellow" if b.pass_rate > 0.8 else "red"
        table.add_row(
            b.stage_name,
            format_duration(b.median_duration),
            format_duration(b.mad),
            f"{format_duration(b.min_duration)} – {format_duration(b.max_duration)}",
            f"[{pass_color}]{b.pass_rate:.0%}[/]",
            str(b.sample_size),
        )

    console.print(table)
    console.print()


def print_drift_alert(event: DriftEvent, baseline: Baseline | None = None) -> None:
    """Print a drift alert with full details."""
    trend_icon = {
        TrendDirection.INCREASING: "↗",
        TrendDirection.DECREASING: "↘",
        TrendDirection.STABLE: "→",
    }

    alert_text = Text()
    alert_text.append("PIPEWATCH DRIFT ALERT\n", style="bold red")
    alert_text.append(f"\nPipeline:  {event.pipeline_id}\n")
    alert_text.append(f"Stage:     {event.stage_name}\n")
    alert_text.append(f"Metric:    {event.metric}\n\n")

    alert_text.append(f"  Expected:  {format_duration(event.expected)}", style="dim")
    if baseline:
        alert_text.append(f"  (σ = {format_duration(baseline.mad)})", style="dim")
    alert_text.append("\n")

    deviation = event.deviation_pct
    dev_color = "red" if deviation > 0 else "green"
    alert_text.append(f"  Actual:    {format_duration(event.actual)}", style=f"bold {dev_color}")
    alert_text.append(f"  ({deviation:+.0f}%)\n", style=dev_color)

    alert_text.append(f"  Z-score:   {event.z_score:.1f}\n")
    alert_text.append(f"  Trend:     {trend_icon.get(event.trend, '?')} {event.trend.value}\n")

    if event.probable_causes:
        alert_text.append("\nProbable causes:\n", style="bold")
        for cause in event.probable_causes:
            alert_text.append(f"  → {cause}\n", style="yellow")

    console.print(Panel(alert_text, border_style="red", padding=(1, 2)))


def print_flaky_tests(tests: list[FlakyTest]) -> None:
    """Print a table of flaky tests."""
    if not tests:
        print_success("No flaky tests detected!")
        return

    table = Table(
        title="[bold yellow]Flaky Tests[/]",
        show_header=True,
        header_style="bold yellow",
    )
    table.add_column("Test", style="bold")
    table.add_column("Flip Rate", justify="right")
    table.add_column("Failures", justify="right")
    table.add_column("Total Runs", justify="right")

    for t in tests[:20]:  # Show top 20
        rate_color = "red" if t.flip_rate > 0.3 else "yellow"
        table.add_row(
            t.name,
            f"[{rate_color}]{t.flip_rate:.0%}[/]",
            str(t.failure_count),
            str(t.total_runs),
        )

    console.print(table)
