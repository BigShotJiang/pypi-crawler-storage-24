"""Pipewatch CLI — Self-learning CI/CD pipeline observability."""

from __future__ import annotations

import asyncio
import contextlib
from datetime import UTC
from pathlib import Path

import click
from rich.console import Console

from pipewatch.config import PipewatchConfig, load_config, save_config

console = Console()

PIPEWATCH_DIR = Path.home() / ".pipewatch"


def _handle_provider_error(
    exc: Exception, repo: str, print_error: object  # callable
) -> None:
    """Handle provider errors with sanitized messages (no raw exception leakage)."""
    error_msg = str(exc)
    if "401" in error_msg or "403" in error_msg:
        print_error("Authentication failed. Set GITHUB_TOKEN env var or use PIPEWATCH_TOKEN.")  # type: ignore[operator]
    elif "404" in error_msg:
        print_error(f"Repository not found: {repo}")  # type: ignore[operator]
    elif "rate limit" in error_msg.lower():
        print_error("GitHub API rate limit exceeded. Try again later.")  # type: ignore[operator]
    elif isinstance(exc, ValueError):
        print_error(str(exc))  # type: ignore[operator]
    else:
        # Don't leak full exception details — they may contain URLs, tokens, or internal paths
        print_error(f"Operation failed ({type(exc).__name__}). Use --verbose for details.")  # type: ignore[operator]
        import structlog

        structlog.get_logger().error("operation_failed", error=str(exc))


@click.group()
@click.version_option(version="0.1.0", prog_name="pipewatch")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output.")
@click.option("--json", "json_output", is_flag=True, help="Machine-readable JSON output.")
@click.option("--no-color", is_flag=True, help="Disable colored output.")
@click.option("--config", "config_path", type=click.Path(), help="Custom config file path.")
@click.pass_context
def main(
    ctx: click.Context,
    verbose: bool,
    json_output: bool,
    no_color: bool,
    config_path: str | None,
) -> None:
    """Pipewatch — Your pipeline is drifting. You just don't know it yet."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["json_output"] = json_output
    ctx.obj["no_color"] = no_color

    config_file = Path(config_path) if config_path else PIPEWATCH_DIR / "config.yml"
    ctx.obj["config_path"] = config_file
    ctx.obj["config"] = load_config(config_file)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@main.command()
@click.option(
    "--provider",
    type=click.Choice(["github", "gitlab", "jenkins"]),
    required=True,
    help="CI/CD platform to connect to.",
)
@click.option("--repo", help="Repository identifier (e.g., owner/repo for GitHub).")
@click.option("--project-id", help="Project ID (for GitLab).")
@click.option("--url", help="Server URL (for Jenkins).")
@click.option(
    "--token",
    help="API token. Prefer PIPEWATCH_TOKEN env var to avoid exposing tokens in process list.",
    envvar="PIPEWATCH_TOKEN",
)
@click.option(
    "--runs",
    default=50,
    type=click.IntRange(1, 500),
    help="Number of historical runs to analyze (1-500).",
)
@click.pass_context
def init(
    ctx: click.Context,
    provider: str,
    repo: str | None,
    project_id: str | None,
    url: str | None,
    token: str | None,
    runs: int,
) -> None:
    """Connect to a CI/CD platform and build initial baseline."""
    from pipewatch.ui.rich_output import print_banner, print_error

    print_banner()

    if provider == "github" and not repo:
        print_error("GitHub provider requires --repo (e.g., owner/repo).")
        raise SystemExit(1)
    if provider == "gitlab" and not project_id:
        print_error("GitLab provider requires --project-id.")
        raise SystemExit(1)
    if provider == "jenkins" and not url:
        print_error("Jenkins provider requires --url.")
        raise SystemExit(1)

    config = PipewatchConfig(
        provider=provider,
        repo=repo or "",
        project_id=project_id or "",
        server_url=url or "",
        token=token or "",
        baseline=ctx.obj["config"].baseline,
        detection=ctx.obj["config"].detection,
    )

    asyncio.run(_init_async(config, runs, ctx.obj["config_path"], ctx.obj["verbose"]))


async def _init_async(
    config: PipewatchConfig, num_runs: int, config_path: Path, verbose: bool
) -> None:
    from pipewatch.engine.baseline import compute_baseline
    from pipewatch.providers.github import GitHubProvider
    from pipewatch.storage.db import PipewatchDB
    from pipewatch.ui.rich_output import (
        print_baseline_summary,
        print_error,
        print_info,
        print_success,
        print_warning,
    )

    if config.provider != "github":
        print_error(f"Provider '{config.provider}' is not yet implemented.")
        return

    provider = GitHubProvider(repo=config.repo, token=config.token or None)

    try:
        print_info(f"Fetching last {num_runs} runs from {provider.name}...")
        raw_runs = await provider.fetch_runs(limit=num_runs)

        if not raw_runs:
            print_warning("No runs found. Make sure the repo has workflow runs.")
            return

        print_success(f"Fetched {len(raw_runs)} runs.")

        print_info("Fetching stage details for each run...")
        detailed_runs = []
        for run in raw_runs:
            try:
                detail = await provider.fetch_run_detail(run.id)
                detailed_runs.append(detail)
            except Exception as e:
                if verbose:
                    print_warning(f"Skipped run {run.id}: {e}")

        if not detailed_runs:
            print_error("Could not fetch any run details.")
            return

        print_success(f"Got stage details for {len(detailed_runs)} runs.")

        pipeline_id = detailed_runs[0].pipeline_id

        print_info("Computing statistical baseline...")
        baselines = compute_baseline(pipeline_id, detailed_runs)

        if not baselines:
            print_warning("No stages with duration data found. Cannot build baseline.")
            return

        db = PipewatchDB()
        try:
            for run in detailed_runs:
                db.store_run(run)
            db.store_baselines(baselines)
        finally:
            db.close()

        save_config(config, config_path)

        print_success(f"Baseline computed from {len(detailed_runs)} runs.")
        print_baseline_summary(baselines, pipeline_id)
        print_success(f"Config saved to {config_path}")
        print_info("Run `pipewatch watch` to start monitoring for drift.")

    except Exception as e:
        _handle_provider_error(e, config.repo, print_error)
        raise SystemExit(1) from None
    finally:
        await provider.close()


# ---------------------------------------------------------------------------
# watch
# ---------------------------------------------------------------------------


@main.command()
@click.option("--interval", default="5m", help="Check interval (e.g., 5m, 1h).")
@click.option("--daemon", is_flag=True, help="Run as background daemon.")
@click.pass_context
def watch(ctx: click.Context, interval: str, daemon: bool) -> None:
    """Start monitoring pipeline for drift."""
    from pipewatch.config import _parse_duration
    from pipewatch.ui.rich_output import print_error, print_info

    config: PipewatchConfig = ctx.obj["config"]
    if not config.provider:
        print_error("No provider configured. Run `pipewatch init` first.")
        raise SystemExit(1)

    interval_secs = _parse_duration(interval)
    print_info(f"Watching {config.repo} every {interval} (Ctrl+C to stop)...")

    asyncio.run(_watch_async(config, interval_secs, ctx.obj["verbose"]))


async def _watch_async(config: PipewatchConfig, interval_secs: int, verbose: bool) -> None:
    from pipewatch.engine.correlator import correlate_drift
    from pipewatch.engine.drift import detect_drift, detect_trend
    from pipewatch.notify import dispatch_notifications
    from pipewatch.providers.github import GitHubProvider
    from pipewatch.storage.db import PipewatchDB
    from pipewatch.storage.models import DriftEvent
    from pipewatch.ui.rich_output import print_drift_alert, print_error, print_info, print_success

    if config.provider != "github":
        print_error(f"Provider '{config.provider}' is not yet implemented.")
        return

    provider = GitHubProvider(repo=config.repo, token=config.token or None)
    db = PipewatchDB()

    try:
        while True:
            try:
                # Find pipeline_id from baselines
                row = db._conn.execute(
                    "SELECT DISTINCT pipeline_id FROM baselines LIMIT 1"
                ).fetchone()
                if not row:
                    print_error("No baselines found. Run `pipewatch init` first.")
                    return

                pipeline_id = row["pipeline_id"]
                baselines = db.get_baselines(pipeline_id)

                latest_runs = await provider.fetch_runs(limit=5)

                for run in latest_runs:
                    # Skip already-processed runs
                    existing = db.get_latest_run_id(pipeline_id)
                    if existing and run.id <= existing:
                        continue

                    try:
                        detail = await provider.fetch_run_detail(run.id)
                    except Exception:
                        continue

                    drift_events = detect_drift(detail, baselines, config.detection.z_threshold)

                    stored_runs = db.get_runs(pipeline_id, limit=config.detection.trend_window)
                    enriched_events: list[DriftEvent] = []

                    for event in drift_events:
                        stage_durations = [
                            s.duration_seconds
                            for r in stored_runs
                            for s in r.stages
                            if s.name == event.stage_name and s.duration_seconds > 0
                        ]
                        trend_dir, _ = detect_trend(stage_durations)

                        causes: list[str] = []
                        if detail.commit_sha:
                            try:
                                changed = await provider.fetch_commit_diff(detail.commit_sha)
                                hints = correlate_drift(
                                    changed, event.stage_name, event.deviation_pct
                                )
                                causes = [h.description for h in hints]
                            except Exception:
                                pass

                        enriched = DriftEvent(
                            run_id=event.run_id,
                            pipeline_id=event.pipeline_id,
                            stage_name=event.stage_name,
                            metric=event.metric,
                            expected=event.expected,
                            actual=event.actual,
                            z_score=event.z_score,
                            trend=trend_dir,
                            probable_causes=causes,
                        )
                        enriched_events.append(enriched)

                        baseline = baselines.get(event.stage_name)
                        print_drift_alert(enriched, baseline)
                        db.store_drift_event(enriched)

                    db.store_run(detail)

                    if not enriched_events and verbose:
                        print_success(f"Run {run.id}: no drift detected.")

                    if enriched_events and config.notifications:
                        await dispatch_notifications(config.notifications, enriched_events)

            except KeyboardInterrupt:
                raise
            except Exception as e:
                print_error(f"Watch cycle error: {e}")

            await asyncio.sleep(interval_secs)

    except KeyboardInterrupt:
        print_info("Watch stopped.")
    finally:
        db.close()
        await provider.close()


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@main.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show current pipeline health summary."""
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    from pipewatch.storage.db import PipewatchDB
    from pipewatch.storage.models import RunStatus
    from pipewatch.ui.rich_output import print_error

    config: PipewatchConfig = ctx.obj["config"]
    if not config.provider:
        print_error("No provider configured. Run `pipewatch init` first.")
        raise SystemExit(1)

    db = PipewatchDB()
    try:
        row = db._conn.execute("SELECT DISTINCT pipeline_id FROM baselines LIMIT 1").fetchone()
        if not row:
            print_error("No baselines found. Run `pipewatch init` first.")
            raise SystemExit(1)

        pipeline_id = row["pipeline_id"]
        baselines = db.get_baselines(pipeline_id)
        drift_events = db.get_recent_drift_events(pipeline_id, limit=10)
        runs = db.get_runs(pipeline_id, limit=50)
        run_count = db.get_run_count(pipeline_id)

        # Compute health score
        score = 100
        if drift_events:
            score -= min(len(drift_events) * 10, 50)

        recent_runs = runs[:10]
        if recent_runs:
            fail_count = sum(1 for r in recent_runs if r.status == RunStatus.FAILURE)
            fail_pct = fail_count / len(recent_runs)
            score -= int(fail_pct * 30)

        score = max(0, min(100, score))

        if score >= 80:
            score_color, score_label = "green", "Healthy"
        elif score >= 50:
            score_color, score_label = "yellow", "Degraded"
        else:
            score_color, score_label = "red", "Critical"

        text = Text()
        text.append("Pipeline: ", style="bold")
        text.append(f"{pipeline_id}\n")
        text.append("Health:   ", style="bold")
        text.append(f"{score}/100 — {score_label}\n", style=f"bold {score_color}")
        text.append("Runs:     ", style="bold")
        text.append(f"{run_count} total\n")
        text.append("Stages:   ", style="bold")
        text.append(f"{len(baselines)} tracked\n")
        text.append("Drift:    ", style="bold")
        text.append(f"{len(drift_events)} recent events\n")

        console.print(Panel(text, title="[bold]Pipeline Status[/]", border_style="cyan"))

        if drift_events:
            table = Table(title="[bold yellow]Recent Drift Events[/]", show_header=True)
            table.add_column("Stage", style="bold")
            table.add_column("Metric")
            table.add_column("Z-Score", justify="right")
            table.add_column("Deviation", justify="right")
            table.add_column("Trend")

            for event in drift_events[:10]:
                dev_pct = event.deviation_pct
                dev_color = "red" if dev_pct > 0 else "green"
                trend_icon = {"increasing": "↗", "decreasing": "↘", "stable": "→"}
                table.add_row(
                    event.stage_name,
                    event.metric,
                    f"{event.z_score:.1f}",
                    f"[{dev_color}]{dev_pct:+.0f}%[/]",
                    trend_icon.get(event.trend.value, "?"),
                )

            console.print(table)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# diagnose
# ---------------------------------------------------------------------------


@main.command()
@click.argument("run_id")
@click.pass_context
def diagnose(ctx: click.Context, run_id: str) -> None:
    """Deep-dive analysis of a specific pipeline run."""
    from pipewatch.ui.rich_output import print_error

    config: PipewatchConfig = ctx.obj["config"]
    if not config.provider:
        print_error("No provider configured. Run `pipewatch init` first.")
        raise SystemExit(1)

    asyncio.run(_diagnose_async(config, run_id, ctx.obj["verbose"]))


async def _diagnose_async(config: PipewatchConfig, run_id: str, verbose: bool) -> None:
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    from pipewatch.engine.baseline import format_duration
    from pipewatch.engine.correlator import correlate_drift
    from pipewatch.engine.drift import detect_drift, modified_z_score
    from pipewatch.providers.github import GitHubProvider
    from pipewatch.storage.db import PipewatchDB
    from pipewatch.ui.rich_output import print_error, print_info, print_success, print_warning

    if config.provider != "github":
        print_error(f"Provider '{config.provider}' is not yet implemented.")
        return

    provider = GitHubProvider(repo=config.repo, token=config.token or None)
    db = PipewatchDB()

    try:
        print_info(f"Fetching run {run_id}...")
        detail = await provider.fetch_run_detail(run_id)

        baselines = db.get_baselines(detail.pipeline_id)
        if not baselines:
            print_warning("No baselines found. Run `pipewatch init` first.")
            return

        # Run header
        status_color = "green" if detail.status.value == "success" else "red"
        header = Text()
        header.append("PIPELINE RUN DIAGNOSIS\n\n", style="bold")
        header.append(f"  Run ID:    {detail.id}\n")
        header.append(f"  Branch:    {detail.branch}\n")
        header.append("  Status:    ", style="bold")
        header.append(f"{detail.status.value}\n", style=f"bold {status_color}")
        header.append(f"  Commit:    {detail.commit_sha[:8] if detail.commit_sha else 'N/A'}\n")
        header.append(
            f"  Message:   {detail.commit_message[:60] if detail.commit_message else 'N/A'}\n"
        )
        header.append(f"  Trigger:   {detail.trigger}\n")
        if detail.started_at:
            header.append(f"  Started:   {detail.started_at.strftime('%Y-%m-%d %H:%M:%S UTC')}\n")

        console.print(Panel(header, border_style="cyan"))

        # Stage breakdown
        table = Table(title="[bold]Stage Analysis[/]", show_header=True, header_style="bold cyan")
        table.add_column("Stage", style="bold")
        table.add_column("Status")
        table.add_column("Duration", justify="right")
        table.add_column("Baseline", justify="right")
        table.add_column("Deviation", justify="right")
        table.add_column("Z-Score", justify="right")
        table.add_column("Verdict")

        for stage in detail.stages:
            baseline = baselines.get(stage.name)
            status_icon = "✅" if stage.status.value == "success" else "❌"

            if baseline and stage.duration_seconds > 0:
                z = modified_z_score(stage.duration_seconds, baseline.median_duration, baseline.mad)
                dev_pct = (
                    (stage.duration_seconds - baseline.median_duration)
                    / baseline.median_duration
                    * 100
                    if baseline.median_duration > 0
                    else 0
                )
                dev_color = "red" if dev_pct > 20 else "green" if dev_pct < -10 else "white"
                verdict = "DRIFT" if abs(z) > config.detection.z_threshold else "OK"

                table.add_row(
                    stage.name,
                    status_icon,
                    format_duration(stage.duration_seconds),
                    format_duration(baseline.median_duration),
                    f"[{dev_color}]{dev_pct:+.0f}%[/]",
                    f"{z:.1f}",
                    verdict,
                )
            else:
                table.add_row(
                    stage.name,
                    status_icon,
                    format_duration(stage.duration_seconds) if stage.duration_seconds > 0 else "—",
                    "—",
                    "—",
                    "—",
                    "N/A",
                )

        console.print(table)

        # Correlations
        if detail.commit_sha:
            try:
                changed_files = await provider.fetch_commit_diff(detail.commit_sha)
                if any(changed_files.values()):
                    all_files = (
                        changed_files.get("added", [])
                        + changed_files.get("modified", [])
                        + changed_files.get("removed", [])
                    )
                    console.print(f"\n[bold]Files changed:[/] {len(all_files)}")

                    events = detect_drift(detail, baselines, config.detection.z_threshold)
                    if events:
                        console.print("\n[bold yellow]Probable Causes:[/]")
                        for event in events:
                            hints = correlate_drift(
                                changed_files, event.stage_name, event.deviation_pct
                            )
                            for hint in hints:
                                console.print(
                                    f"  [yellow]→[/] {hint.description} "
                                    f"[dim](confidence: {hint.confidence:.0%})[/]"
                                )
                    else:
                        print_success("No drift detected in this run.")
            except Exception:
                pass

    except Exception as e:
        _handle_provider_error(e, config.repo, print_error)
        raise SystemExit(1) from None
    finally:
        db.close()
        await provider.close()


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


@main.command()
@click.option("--output", "-o", type=click.Path(), help="Save report to file.")
@click.pass_context
def doctor(ctx: click.Context, output: str | None) -> None:
    """One-shot pipeline health report. Great for PR comments."""
    from pipewatch.ui.rich_output import print_error

    config: PipewatchConfig = ctx.obj["config"]
    if not config.provider:
        print_error("No provider configured. Run `pipewatch init` first.")
        raise SystemExit(1)

    asyncio.run(_doctor_async(config, output))


async def _doctor_async(config: PipewatchConfig, output_path: str | None) -> None:
    from datetime import datetime

    from pipewatch.engine.baseline import format_duration
    from pipewatch.engine.drift import detect_failure_spike, detect_trend
    from pipewatch.providers.github import GitHubProvider
    from pipewatch.storage.db import PipewatchDB
    from pipewatch.storage.models import RunStatus
    from pipewatch.ui.rich_output import print_error, print_success

    if config.provider != "github":
        print_error(f"Provider '{config.provider}' is not yet implemented.")
        return

    provider = GitHubProvider(repo=config.repo, token=config.token or None)
    db = PipewatchDB()

    try:
        row = db._conn.execute("SELECT DISTINCT pipeline_id FROM baselines LIMIT 1").fetchone()
        if not row:
            print_error("No baselines found. Run `pipewatch init` first.")
            return

        pipeline_id = row["pipeline_id"]
        baselines = db.get_baselines(pipeline_id)
        drift_events = db.get_recent_drift_events(pipeline_id, limit=20)
        stored_runs = db.get_runs(pipeline_id, limit=50)

        # Health score
        score = 100
        issues: list[str] = []

        if drift_events:
            score -= min(len(drift_events) * 5, 30)
            issues.append(f"{len(drift_events)} drift events detected recently")

        recent_runs = stored_runs[:20]
        if recent_runs:
            fail_count = sum(1 for r in recent_runs if r.status == RunStatus.FAILURE)
            fail_pct = fail_count / len(recent_runs)
            if fail_pct > 0.3:
                score -= 20
                issues.append(f"High failure rate: {fail_pct:.0%} in last {len(recent_runs)} runs")
            elif fail_pct > 0.1:
                score -= 10
                issues.append(f"Elevated failure rate: {fail_pct:.0%}")

        for stage_name in baselines:
            stage_durations = [
                s.duration_seconds
                for r in stored_runs
                for s in r.stages
                if s.name == stage_name and s.duration_seconds > 0
            ]
            if len(stage_durations) >= 8:
                trend_dir, p_val = detect_trend(stage_durations)
                if trend_dir.value == "increasing":
                    score -= 5
                    issues.append(f"'{stage_name}' is trending slower (p={p_val:.3f})")

        for stage_name, baseline in baselines.items():
            computed = baseline.computed_at
            if computed.tzinfo is None:
                computed = computed.replace(tzinfo=UTC)
            age_days = (datetime.now(UTC) - computed).days
            if age_days > 7:
                score -= 5
                issues.append(f"Baseline for '{stage_name}' is {age_days} days old")
                break

        if recent_runs:
            avg_pass = sum(b.pass_rate for b in baselines.values()) / max(len(baselines), 1)
            if detect_failure_spike(recent_runs, avg_pass):
                score -= 15
                issues.append("Failure spike detected in recent runs")

        score = max(0, min(100, score))

        # Build markdown
        lines: list[str] = []
        lines.append("# Pipewatch Health Report")
        lines.append("")
        lines.append(f"**Pipeline:** `{pipeline_id}`")
        lines.append(f"**Runs analyzed:** {len(stored_runs)}")

        if score >= 80:
            lines.append(f"**Health Score:** {score}/100 Healthy")
        elif score >= 50:
            lines.append(f"**Health Score:** {score}/100 Degraded")
        else:
            lines.append(f"**Health Score:** {score}/100 Critical")

        lines.append("")
        lines.append("## Stage Baselines")
        lines.append("")
        lines.append("| Stage | Median | MAD | Range | Pass Rate | Samples |")
        lines.append("|-------|--------|-----|-------|-----------|---------|")
        for b in baselines.values():
            lines.append(
                f"| {b.stage_name} | {format_duration(b.median_duration)} | "
                f"{format_duration(b.mad)} | "
                f"{format_duration(b.min_duration)}-{format_duration(b.max_duration)} | "
                f"{b.pass_rate:.0%} | {b.sample_size} |"
            )
        lines.append("")

        if issues:
            lines.append("## Issues Found")
            lines.append("")
            for issue in issues:
                lines.append(f"- {issue}")
            lines.append("")

        if drift_events:
            lines.append("## Recent Drift Events")
            lines.append("")
            lines.append("| Stage | Metric | Expected | Actual | Z-Score | Trend |")
            lines.append("|-------|--------|----------|--------|---------|-------|")
            for evt in drift_events[:10]:
                lines.append(
                    f"| {evt.stage_name} | {evt.metric} | "
                    f"{format_duration(evt.expected)} | {format_duration(evt.actual)} | "
                    f"{evt.z_score:.1f} | {evt.trend.value} |"
                )
            lines.append("")

        if not issues:
            lines.append("## No Issues Found")
            lines.append("")
            lines.append("All pipeline stages are within expected parameters.")
            lines.append("")

        lines.append("---")
        lines.append("*Generated by Pipewatch*")

        report = "\n".join(lines)

        if output_path:
            Path(output_path).write_text(report)
            print_success(f"Report saved to {output_path}")
        else:
            console.print()
            from rich.markdown import Markdown

            console.print(Markdown(report))

    finally:
        db.close()
        await provider.close()


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------


@main.command()
@click.argument("branch_a")
@click.argument("branch_b")
@click.pass_context
def compare(ctx: click.Context, branch_a: str, branch_b: str) -> None:
    """Compare pipeline behavior between two branches."""
    from pipewatch.ui.rich_output import print_error

    config: PipewatchConfig = ctx.obj["config"]
    if not config.provider:
        print_error("No provider configured. Run `pipewatch init` first.")
        raise SystemExit(1)

    asyncio.run(_compare_async(config, branch_a, branch_b))


async def _compare_async(config: PipewatchConfig, branch_a: str, branch_b: str) -> None:
    from rich.table import Table

    from pipewatch.engine.baseline import compute_baseline, format_duration
    from pipewatch.providers.github import GitHubProvider
    from pipewatch.ui.rich_output import print_error, print_info

    if config.provider != "github":
        print_error(f"Provider '{config.provider}' is not yet implemented.")
        return

    provider = GitHubProvider(repo=config.repo, token=config.token or None)

    try:
        print_info(f"Fetching runs for '{branch_a}' and '{branch_b}'...")
        all_runs = await provider.fetch_runs(limit=100)

        runs_a = [r for r in all_runs if r.branch == branch_a]
        runs_b = [r for r in all_runs if r.branch == branch_b]

        if not runs_a:
            print_error(f"No runs found for branch '{branch_a}'.")
            return
        if not runs_b:
            print_error(f"No runs found for branch '{branch_b}'.")
            return

        detailed_a = []
        for run in runs_a[:20]:
            with contextlib.suppress(Exception):
                detailed_a.append(await provider.fetch_run_detail(run.id))

        detailed_b = []
        for run in runs_b[:20]:
            with contextlib.suppress(Exception):
                detailed_b.append(await provider.fetch_run_detail(run.id))

        if not detailed_a or not detailed_b:
            print_error("Could not fetch enough run details for comparison.")
            return

        pipeline_id = detailed_a[0].pipeline_id
        baselines_a = compute_baseline(pipeline_id, detailed_a)
        baselines_b = compute_baseline(pipeline_id, detailed_b)

        map_a = {b.stage_name: b for b in baselines_a}
        map_b = {b.stage_name: b for b in baselines_b}
        all_stages = sorted(set(map_a.keys()) | set(map_b.keys()))

        table = Table(
            title=f"[bold]Branch Comparison: {branch_a} vs {branch_b}[/]",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Stage", style="bold")
        table.add_column(f"{branch_a}\nMedian", justify="right")
        table.add_column(f"{branch_b}\nMedian", justify="right")
        table.add_column("Diff", justify="right")
        table.add_column(f"{branch_a}\nPass Rate", justify="right")
        table.add_column(f"{branch_b}\nPass Rate", justify="right")

        for stage_name in all_stages:
            a = map_a.get(stage_name)
            b = map_b.get(stage_name)

            if a and b:
                diff_secs = b.median_duration - a.median_duration
                diff_pct = (diff_secs / a.median_duration * 100) if a.median_duration > 0 else 0
                diff_color = "red" if diff_pct > 10 else "green" if diff_pct < -10 else "white"
                pr_a = "green" if a.pass_rate > 0.95 else "yellow"
                pr_b = "green" if b.pass_rate > 0.95 else "yellow"

                table.add_row(
                    stage_name,
                    format_duration(a.median_duration),
                    format_duration(b.median_duration),
                    f"[{diff_color}]{diff_pct:+.0f}% ({format_duration(abs(diff_secs))})[/]",
                    f"[{pr_a}]{a.pass_rate:.0%}[/]",
                    f"[{pr_b}]{b.pass_rate:.0%}[/]",
                )
            elif a:
                table.add_row(
                    stage_name,
                    format_duration(a.median_duration),
                    "—",
                    "—",
                    f"{a.pass_rate:.0%}",
                    "—",
                )
            elif b:
                table.add_row(
                    stage_name,
                    "—",
                    format_duration(b.median_duration),
                    "—",
                    "—",
                    f"{b.pass_rate:.0%}",
                )

        console.print(table)
        console.print(
            f"\n[dim]{branch_a}: {len(detailed_a)} runs | {branch_b}: {len(detailed_b)} runs[/]"
        )

    finally:
        await provider.close()


# ---------------------------------------------------------------------------
# budget
# ---------------------------------------------------------------------------


@main.command()
@click.option("--stage", required=True, help="Stage name to set budget for.")
@click.option("--max", "max_duration", required=True, help="Max allowed duration (e.g., 3m, 90s).")
@click.option("--fail-ci", is_flag=True, help="Exit with code 1 if budget exceeded.")
@click.pass_context
def budget(ctx: click.Context, stage: str, max_duration: str, fail_ci: bool) -> None:
    """Set time budgets per pipeline stage."""
    from pipewatch.config import StageBudget, _parse_duration
    from pipewatch.ui.rich_output import print_error, print_success

    config: PipewatchConfig = ctx.obj["config"]
    config_path: Path = ctx.obj["config_path"]

    budget_seconds = _parse_duration(max_duration)

    existing_budgets = [b for b in config.budgets if b.name != stage]
    existing_budgets.append(StageBudget(name=stage, max_seconds=budget_seconds))

    new_config = PipewatchConfig(
        provider=config.provider,
        repo=config.repo,
        project_id=config.project_id,
        server_url=config.server_url,
        token=config.token,
        baseline=config.baseline,
        detection=config.detection,
        notifications=config.notifications,
        ignored_stages=config.ignored_stages,
        budgets=existing_budgets,
    )
    save_config(new_config, config_path)
    print_success(f"Budget set: {stage} → max {max_duration}")

    if fail_ci:
        from pipewatch.storage.db import PipewatchDB

        db = PipewatchDB()
        try:
            row = db._conn.execute("SELECT DISTINCT pipeline_id FROM baselines LIMIT 1").fetchone()
            if row:
                runs = db.get_runs(row["pipeline_id"], limit=1)
                if runs:
                    for s in runs[0].stages:
                        if s.name == stage and s.duration_seconds > budget_seconds:
                            print_error(
                                f"Budget exceeded! {stage}: "
                                f"{s.duration_seconds:.0f}s > {budget_seconds}s"
                            )
                            raise SystemExit(1)
                    print_success("Latest run is within budget.")
        finally:
            db.close()


# ---------------------------------------------------------------------------
# notify
# ---------------------------------------------------------------------------


@main.command()
@click.option("--slack", help="Slack webhook URL.")
@click.option("--discord", help="Discord webhook URL.")
@click.option("--webhook", help="Generic webhook URL.")
@click.option("--remove", help="Remove a notification channel by type.")
@click.option("--list", "list_channels", is_flag=True, help="List configured channels.")
@click.pass_context
def notify(
    ctx: click.Context,
    slack: str | None,
    discord: str | None,
    webhook: str | None,
    remove: str | None,
    list_channels: bool,
) -> None:
    """Configure notification channels for drift alerts."""
    from rich.table import Table

    from pipewatch.config import NotificationChannel
    from pipewatch.ui.rich_output import print_info, print_success

    config: PipewatchConfig = ctx.obj["config"]
    config_path: Path = ctx.obj["config_path"]

    if list_channels:
        if not config.notifications:
            print_info("No notification channels configured.")
            return
        table = Table(title="[bold]Notification Channels[/]", show_header=True)
        table.add_column("Type", style="bold")
        table.add_column("Webhook")
        table.add_column("Events")
        for ch in config.notifications:
            webhook_display = ch.webhook[:40] + "..." if len(ch.webhook) > 40 else ch.webhook
            table.add_row(ch.type, webhook_display, ", ".join(ch.events))
        console.print(table)
        return

    channels = list(config.notifications)

    if remove:
        channels = [ch for ch in channels if ch.type != remove]
        print_success(f"Removed '{remove}' notification channel.")

    if slack:
        channels = [ch for ch in channels if ch.type != "slack"]
        channels.append(NotificationChannel(type="slack", webhook=slack))
        print_success("Slack notification channel configured.")

    if discord:
        channels = [ch for ch in channels if ch.type != "discord"]
        channels.append(NotificationChannel(type="discord", webhook=discord))
        print_success("Discord notification channel configured.")

    if webhook:
        channels = [ch for ch in channels if ch.type != "webhook"]
        channels.append(NotificationChannel(type="webhook", webhook=webhook))
        print_success("Generic webhook notification channel configured.")

    new_config = PipewatchConfig(
        provider=config.provider,
        repo=config.repo,
        project_id=config.project_id,
        server_url=config.server_url,
        token=config.token,
        baseline=config.baseline,
        detection=config.detection,
        notifications=channels,
        ignored_stages=config.ignored_stages,
        budgets=config.budgets,
    )
    save_config(new_config, config_path)


# ---------------------------------------------------------------------------
# providers
# ---------------------------------------------------------------------------


@main.command()
@click.pass_context
def providers(ctx: click.Context) -> None:
    """List supported CI/CD platforms and their status."""
    from rich.table import Table

    table = Table(title="Supported Providers")
    table.add_column("Provider", style="bold")
    table.add_column("Status", style="green")
    table.add_column("Auth Method")

    table.add_row("GitHub Actions", "Supported", "GITHUB_TOKEN or PAT")
    table.add_row("GitLab CI", "Coming Soon", "Personal Access Token")
    table.add_row("Jenkins", "Coming Soon", "API Token")
    table.add_row("CircleCI", "Coming Soon", "API Token")
    table.add_row("Bitbucket Pipelines", "Coming Soon", "App Password")

    console.print(table)


if __name__ == "__main__":
    main()
