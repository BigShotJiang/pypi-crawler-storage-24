"""Baseline builder using robust statistics.

Computes per-stage statistical baselines from historical pipeline runs.
Uses median + MAD (Median Absolute Deviation) instead of mean + stddev
for resistance to outliers.

This module is pure — no I/O, no DB calls. Takes data in, returns results.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

import numpy as np

from pipewatch.storage.models import Baseline, PipelineRun, RunStatus

if TYPE_CHECKING:
    from numpy.typing import NDArray


def compute_baseline(
    pipeline_id: str,
    runs: list[PipelineRun],
) -> list[Baseline]:
    """Compute statistical baselines for each stage across pipeline runs.

    Args:
        pipeline_id: Identifier for the pipeline.
        runs: Historical pipeline runs to analyze.

    Returns:
        List of Baseline objects, one per unique stage.
    """
    if not runs:
        return []

    # Group stage durations by stage name
    stage_data: dict[str, list[float]] = {}
    stage_pass_counts: dict[str, int] = {}
    stage_total_counts: dict[str, int] = {}

    for run in runs:
        for stage in run.stages:
            if stage.name not in stage_data:
                stage_data[stage.name] = []
                stage_pass_counts[stage.name] = 0
                stage_total_counts[stage.name] = 0

            stage_total_counts[stage.name] += 1

            if stage.status == RunStatus.SUCCESS:
                stage_pass_counts[stage.name] += 1

            # Only include completed stages in duration analysis
            if stage.duration_seconds > 0:
                stage_data[stage.name].append(stage.duration_seconds)

    baselines: list[Baseline] = []
    now = datetime.now(UTC)

    for stage_name, durations in stage_data.items():
        if not durations:
            continue

        arr: NDArray[np.float64] = np.array(durations, dtype=np.float64)

        median = float(np.median(arr))
        mad = _compute_mad(arr)
        total = stage_total_counts.get(stage_name, 0)
        passes = stage_pass_counts.get(stage_name, 0)

        baselines.append(
            Baseline(
                pipeline_id=pipeline_id,
                stage_name=stage_name,
                median_duration=median,
                mad=mad,
                mean_duration=float(np.mean(arr)),
                std_duration=float(np.std(arr)),
                sample_size=len(durations),
                p25_duration=float(np.percentile(arr, 25)),
                p75_duration=float(np.percentile(arr, 75)),
                min_duration=float(np.min(arr)),
                max_duration=float(np.max(arr)),
                pass_rate=passes / total if total > 0 else 0.0,
                computed_at=now,
            )
        )

    return baselines


def _compute_mad(arr: NDArray[np.float64]) -> float:
    """Compute Median Absolute Deviation.

    MAD = median(|x_i - median(x)|)

    More robust than standard deviation against outliers.
    A single extreme value won't skew the baseline.
    """
    median = np.median(arr)
    deviations = np.abs(arr - median)
    return float(np.median(deviations))


def format_duration(seconds: float) -> str:
    """Format seconds into human-readable duration string.

    Examples:
        45.0 → '45s'
        132.0 → '2m 12s'
        3672.0 → '1h 1m 12s'
    """
    if seconds < 60:
        return f"{seconds:.0f}s"

    minutes = int(seconds // 60)
    remaining_secs = int(seconds % 60)

    if minutes < 60:
        return f"{minutes}m {remaining_secs}s"

    hours = minutes // 60
    remaining_mins = minutes % 60
    return f"{hours}h {remaining_mins}m {remaining_secs}s"
