"""Flaky test detector using Bayesian flip rate analysis.

A "flaky" test is one that non-deterministically passes or fails on the
same code. This module detects them by analyzing the flip rate — how often
a test's result changes between consecutive runs.

A truly broken test fails consistently (flip rate ≈ 0).
A truly passing test passes consistently (flip rate ≈ 0).
A flaky test oscillates (flip rate > threshold).
"""

from __future__ import annotations

from pipewatch.storage.models import FlakyTest, RunStatus, TestResult


def detect_flaky_tests(
    test_history: dict[str, list[RunStatus]],
    pipeline_id: str,
    threshold: float = 0.1,
) -> list[FlakyTest]:
    """Identify flaky tests from historical test results.

    Args:
        test_history: Dict mapping test name → ordered list of pass/fail statuses.
        pipeline_id: The pipeline these tests belong to.
        threshold: Flip rate above which a test is flagged as flaky.

    Returns:
        List of FlakyTest objects for tests exceeding the threshold.
    """
    flaky_tests: list[FlakyTest] = []

    for test_name, statuses in test_history.items():
        if len(statuses) < 5:
            # Need minimum history to detect flakiness
            continue

        flip_count = _count_flips(statuses)
        total = len(statuses)
        failures = sum(1 for s in statuses if s == RunStatus.FAILURE)

        # Bayesian flip rate with Beta prior
        # Using Beta(1, 1) uniform prior → posterior is Beta(flips + 1, non_flips + 1)
        # Point estimate = posterior mean
        possible_flips = max(total - 1, 1)
        flip_rate = (flip_count + 1) / (possible_flips + 2)

        if flip_rate > threshold:
            flaky_tests.append(
                FlakyTest(
                    name=test_name,
                    suite="",  # Populated by caller if available
                    pipeline_id=pipeline_id,
                    total_runs=total,
                    failure_count=failures,
                    flip_count=flip_count,
                    flip_rate=flip_rate,
                )
            )

    # Sort by flip rate descending — worst offenders first
    flaky_tests.sort(key=lambda t: t.flip_rate, reverse=True)
    return flaky_tests


def _count_flips(statuses: list[RunStatus]) -> int:
    """Count the number of status transitions in a sequence.

    A flip is when consecutive statuses differ:
    [PASS, PASS, FAIL, PASS, FAIL] → 3 flips (P→F, F→P, P→F)
    """
    flips = 0
    for i in range(1, len(statuses)):
        if statuses[i] != statuses[i - 1]:
            flips += 1
    return flips


def build_test_history(
    runs_test_results: list[list[TestResult]],
) -> dict[str, list[RunStatus]]:
    """Build per-test status history from multiple runs' test results.

    Args:
        runs_test_results: List of test results per run, in chronological order.

    Returns:
        Dict mapping test name → ordered list of statuses.
    """
    history: dict[str, list[RunStatus]] = {}

    for run_results in runs_test_results:
        for result in run_results:
            key = f"{result.suite}::{result.name}" if result.suite else result.name
            if key not in history:
                history[key] = []
            history[key].append(result.status)

    return history
