"""Root cause correlator.

When drift is detected, this module analyzes concurrent changes
(commits, dependency updates, config changes) to suggest probable causes.

This module is pure — takes data in, returns suggestions.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CorrelationHint:
    """A probable cause suggestion for a drift event."""

    description: str
    confidence: float  # 0.0 to 1.0
    evidence: str


# File patterns that commonly affect pipeline performance
DEPENDENCY_PATTERNS = {
    "package.json",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "requirements.txt",
    "Pipfile.lock",
    "poetry.lock",
    "go.sum",
    "Cargo.lock",
    "Gemfile.lock",
    "composer.lock",
}

CI_CONFIG_PATTERNS = {
    ".github/workflows/",
    ".gitlab-ci.yml",
    "Jenkinsfile",
    ".circleci/",
    "bitbucket-pipelines.yml",
    "azure-pipelines.yml",
    "Dockerfile",
    "docker-compose",
    ".dockerignore",
}

BUILD_CONFIG_PATTERNS = {
    "webpack.config",
    "vite.config",
    "tsconfig.json",
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "Makefile",
    "CMakeLists.txt",
    "build.gradle",
    "pom.xml",
}


def correlate_drift(
    changed_files: dict[str, list[str]],
    stage_name: str,
    deviation_pct: float,
) -> list[CorrelationHint]:
    """Analyze changed files to suggest probable causes for drift.

    Args:
        changed_files: Dict with keys 'added', 'modified', 'removed'.
        stage_name: The pipeline stage that drifted.
        deviation_pct: Percentage deviation from baseline.

    Returns:
        List of CorrelationHint sorted by confidence (highest first).
    """
    all_files = (
        changed_files.get("added", [])
        + changed_files.get("modified", [])
        + changed_files.get("removed", [])
    )

    if not all_files:
        return []

    hints: list[CorrelationHint] = []

    # Check for dependency changes
    dep_changes = [f for f in all_files if _matches_patterns(f, DEPENDENCY_PATTERNS)]
    if dep_changes:
        hints.append(
            CorrelationHint(
                description=f"Dependency files changed: {', '.join(dep_changes)}",
                confidence=0.8,
                evidence=f"Dependency updates often affect install/build times. "
                f"Stage '{stage_name}' deviated {deviation_pct:+.0f}%.",
            )
        )

    # Check for CI config changes
    ci_changes = [f for f in all_files if _matches_patterns(f, CI_CONFIG_PATTERNS)]
    if ci_changes:
        hints.append(
            CorrelationHint(
                description=f"CI/CD configuration changed: {', '.join(ci_changes)}",
                confidence=0.9,
                evidence="Pipeline config changes directly impact stage behavior.",
            )
        )

    # Check for build config changes
    build_changes = [f for f in all_files if _matches_patterns(f, BUILD_CONFIG_PATTERNS)]
    if build_changes:
        hints.append(
            CorrelationHint(
                description=f"Build configuration changed: {', '.join(build_changes)}",
                confidence=0.7,
                evidence="Build config changes can affect compilation and bundling times.",
            )
        )

    # Check for large number of files changed
    total_files = len(all_files)
    added = len(changed_files.get("added", []))
    if total_files > 50:
        hints.append(
            CorrelationHint(
                description=f"Large commit: {total_files} files changed ({added} added)",
                confidence=0.5,
                evidence="Large changesets can increase build, lint, and test times.",
            )
        )

    # Sort by confidence
    hints.sort(key=lambda h: h.confidence, reverse=True)
    return hints


def _matches_patterns(filepath: str, patterns: set[str]) -> bool:
    """Check if a filepath matches any of the given patterns."""
    return any(pattern in filepath for pattern in patterns)
