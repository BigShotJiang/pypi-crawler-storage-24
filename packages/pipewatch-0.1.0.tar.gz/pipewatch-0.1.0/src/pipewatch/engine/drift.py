"""Drift detection engine.

Detects anomalous pipeline runs using:
1. Modified Z-score — flags individual runs that deviate from baseline
2. Mann-Kendall trend test — detects slow, monotonic drift over time

This module is pure — no I/O, no side effects.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy import stats as scipy_stats

if TYPE_CHECKING:
    from numpy.typing import NDArray

from pipewatch.storage.models import (
    Baseline,
    DriftEvent,
    PipelineRun,
    RunStatus,
    TrendDirection,
)

# Scaling constant for MAD → consistent estimator of stddev for normal distributions
# 1.4826 ≈ 1 / Φ⁻¹(3/4) where Φ⁻¹ is the inverse normal CDF
MAD_SCALE = 1.4826


def detect_drift(
    run: PipelineRun,
    baselines: dict[str, Baseline],
    z_threshold: float = 3.0,
) -> list[DriftEvent]:
    """Check a single pipeline run for drift against baselines.

    Args:
        run: The pipeline run to analyze.
        baselines: Dict mapping stage name → Baseline.
        z_threshold: Modified Z-score threshold for flagging drift.

    Returns:
        List of DriftEvent objects for any stages that have drifted.
    """
    events: list[DriftEvent] = []

    for stage in run.stages:
        baseline = baselines.get(stage.name)
        if not baseline or baseline.sample_size < 3:
            continue

        # Duration drift
        if stage.duration_seconds > 0:
            z = modified_z_score(stage.duration_seconds, baseline.median_duration, baseline.mad)

            if abs(z) > z_threshold:
                events.append(
                    DriftEvent(
                        run_id=run.id,
                        pipeline_id=run.pipeline_id,
                        stage_name=stage.name,
                        metric="duration",
                        expected=baseline.median_duration,
                        actual=stage.duration_seconds,
                        z_score=z,
                        trend=TrendDirection.STABLE,  # Trend computed separately
                    )
                )

    return events


def modified_z_score(value: float, median: float, mad: float) -> float:
    """Compute modified Z-score using MAD.

    Modified Z-score = 0.6745 * (x - median) / MAD

    The 0.6745 factor normalizes so that the modified Z-score equals
    the standard Z-score for normally distributed data.

    If MAD is zero (all values identical), falls back to deviation from median.

    Args:
        value: The observed value.
        median: Baseline median.
        mad: Baseline MAD (Median Absolute Deviation).

    Returns:
        Modified Z-score. Positive = slower than baseline.
    """
    if mad == 0:
        # All historical values were identical.
        # Use a small epsilon to avoid division by zero.
        if value == median:
            return 0.0
        return float("inf") if value > median else float("-inf")

    return 0.6745 * (value - median) / mad


def detect_trend(
    durations: list[float],
    min_samples: int = 8,
) -> tuple[TrendDirection, float]:
    """Detect monotonic trend in a time series using the Mann-Kendall test.

    The Mann-Kendall test is non-parametric and doesn't assume normality.
    It detects whether there's a consistent upward or downward trend,
    which is exactly what we want for catching slow pipeline drift.

    Args:
        durations: Time-ordered list of stage durations.
        min_samples: Minimum data points required. Mann-Kendall needs ≥8.

    Returns:
        Tuple of (TrendDirection, p_value).
        TrendDirection.INCREASING = builds getting slower.
        TrendDirection.DECREASING = builds getting faster.
        TrendDirection.STABLE = no significant trend.
    """
    if len(durations) < min_samples:
        return TrendDirection.STABLE, 1.0

    arr: NDArray[np.float64] = np.array(durations, dtype=np.float64)

    # Mann-Kendall uses Kendall's tau rank correlation against time indices
    time_indices = np.arange(len(arr), dtype=np.float64)
    tau, p_value = scipy_stats.kendalltau(time_indices, arr)

    # Significance level of 0.05
    if p_value > 0.05:
        return TrendDirection.STABLE, float(p_value)

    if tau > 0:
        return TrendDirection.INCREASING, float(p_value)
    else:
        return TrendDirection.DECREASING, float(p_value)


def detect_failure_spike(
    recent_runs: list[PipelineRun],
    baseline_pass_rate: float,
    window: int = 10,
    threshold: float = 0.3,
) -> bool:
    """Detect if recent failure rate has spiked above baseline.

    Args:
        recent_runs: Most recent runs in chronological order.
        baseline_pass_rate: Historical pass rate (0.0 to 1.0).
        window: Number of recent runs to consider.
        threshold: Minimum drop in pass rate to trigger alert.

    Returns:
        True if a failure spike is detected.
    """
    windowed = recent_runs[-window:]
    if not windowed:
        return False

    recent_passes = sum(1 for r in windowed if r.status == RunStatus.SUCCESS)
    recent_pass_rate = recent_passes / len(windowed)

    return (baseline_pass_rate - recent_pass_rate) > threshold
