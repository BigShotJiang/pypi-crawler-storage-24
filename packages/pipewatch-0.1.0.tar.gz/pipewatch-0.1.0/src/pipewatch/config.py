"""Configuration management for Pipewatch."""

from __future__ import annotations

import os
import stat
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

import yaml


@dataclass(frozen=True)
class BaselineConfig:
    window: int = 50
    refresh: str = "daily"


@dataclass(frozen=True)
class DetectionConfig:
    z_threshold: float = 3.0
    trend_window: int = 20
    flaky_threshold: float = 0.1


@dataclass(frozen=True)
class NotificationChannel:
    type: str
    webhook: str = ""
    events: list[str] = field(
        default_factory=lambda: ["drift", "failure_spike", "flaky_escalation"]
    )


@dataclass(frozen=True)
class StageBudget:
    name: str
    max_seconds: int


@dataclass(frozen=True)
class PipewatchConfig:
    provider: str = ""
    repo: str = ""
    project_id: str = ""
    server_url: str = ""
    token: str = ""
    baseline: BaselineConfig = field(default_factory=BaselineConfig)
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    notifications: list[NotificationChannel] = field(default_factory=list)
    ignored_stages: list[str] = field(default_factory=list)
    budgets: list[StageBudget] = field(default_factory=list)


def load_config(path: Path) -> PipewatchConfig:
    """Load configuration from a YAML file. Returns defaults if file doesn't exist."""
    if not path.exists():
        return PipewatchConfig()

    with open(path) as f:
        raw: dict[str, Any] = yaml.safe_load(f) or {}

    return PipewatchConfig(
        provider=raw.get("provider", ""),
        repo=raw.get("repo", ""),
        project_id=raw.get("project_id", ""),
        server_url=raw.get("server_url", ""),
        token=raw.get("token", ""),
        baseline=BaselineConfig(
            window=raw.get("baseline", {}).get("window", 50),
            refresh=raw.get("baseline", {}).get("refresh", "daily"),
        ),
        detection=DetectionConfig(
            z_threshold=raw.get("detection", {}).get("z_threshold", 3.0),
            trend_window=raw.get("detection", {}).get("trend_window", 20),
            flaky_threshold=raw.get("detection", {}).get("flaky_threshold", 0.1),
        ),
        notifications=[
            NotificationChannel(
                type=ch.get("type", ""),
                webhook=ch.get("webhook", ""),
                events=ch.get("events", ["drift"]),
            )
            for ch in raw.get("notifications", {}).get("channels", [])
        ],
        ignored_stages=raw.get("stages", {}).get("ignore", []),
        budgets=[
            StageBudget(name=name, max_seconds=_parse_duration(dur))
            for name, dur in raw.get("stages", {}).get("budgets", {}).items()
        ],
    )


def save_config(config: PipewatchConfig, path: Path) -> None:
    """Save configuration to a YAML file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    # Restrict directory to owner-only on Unix systems
    if os.name != "nt":
        path.parent.chmod(stat.S_IRWXU)

    data: dict[str, Any] = {
        "provider": config.provider,
        "repo": config.repo,
    }

    if config.project_id:
        data["project_id"] = config.project_id
    if config.server_url:
        data["server_url"] = config.server_url

    data["baseline"] = {
        "window": config.baseline.window,
        "refresh": config.baseline.refresh,
    }
    data["detection"] = {
        "z_threshold": config.detection.z_threshold,
        "trend_window": config.detection.trend_window,
        "flaky_threshold": config.detection.flaky_threshold,
    }

    if config.notifications:
        data["notifications"] = {
            "channels": [
                {
                    "type": ch.type,
                    "webhook": ch.webhook,
                    "events": list(ch.events),
                }
                for ch in config.notifications
            ]
        }

    stages_data: dict[str, Any] = {}
    if config.ignored_stages:
        stages_data["ignore"] = list(config.ignored_stages)
    if config.budgets:
        stages_data["budgets"] = {b.name: f"{b.max_seconds}s" for b in config.budgets}
    if stages_data:
        data["stages"] = stages_data

    with open(path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    # Restrict config file to owner-only on Unix systems
    if os.name != "nt":
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)


def _parse_duration(s: str) -> int:
    """Parse duration string like '3m', '90s', '1h' into seconds.

    Raises:
        ValueError: If duration is negative or invalid.
    """
    s = s.strip().lower()
    if s.endswith("h"):
        result = int(s[:-1]) * 3600
    elif s.endswith("m"):
        result = int(s[:-1]) * 60
    elif s.endswith("s"):
        result = int(s[:-1])
    else:
        result = int(s)
    if result < 0:
        msg = f"Duration must be non-negative, got: {s!r}"
        raise ValueError(msg)
    return result
