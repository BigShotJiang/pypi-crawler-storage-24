"""Pipewatch — Self-learning CI/CD pipeline observability."""

__version__ = "0.1.0"
