Run the full quality check suite before committing:

1. Run `ruff format src/ tests/` to auto-format
2. Run `ruff check src/ tests/` to lint
3. Run `mypy src/` for type checking
4. Run `pytest -v` for tests
5. Report any failures with suggested fixes
