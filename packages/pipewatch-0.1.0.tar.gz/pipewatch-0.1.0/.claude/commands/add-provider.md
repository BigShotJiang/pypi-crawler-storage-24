Add a new CI/CD provider adapter for: $ARGUMENTS

Steps:
1. Read `src/pipewatch/providers/base.py` for the abstract interface
2. Read `src/pipewatch/providers/github.py` as the reference implementation
3. Create `src/pipewatch/providers/<provider_name>.py` implementing `PipelineProvider`
4. Create test fixtures in `tests/fixtures/<provider_name>/` with sample API responses
5. Create `tests/test_providers/test_<provider_name>.py` with tests using the fixtures
6. Add the provider as a choice in `cli.py`'s `init` command
7. Update the providers table in `README.md`
8. Run `/check` to verify everything passes
