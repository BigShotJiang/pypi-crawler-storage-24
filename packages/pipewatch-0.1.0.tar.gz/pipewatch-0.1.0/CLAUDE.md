# Pipewatch

Self-learning CI/CD pipeline observability CLI. Zero config, one command.

## Project Overview

Python CLI tool that connects to CI/CD platforms (GitHub Actions, GitLab CI, Jenkins), learns pipeline behavior baselines using robust statistics, and alerts on drift — duration changes, failure spikes, flaky tests, dependency bloat.

**Target user:** DevOps engineers, platform teams, any developer with a CI/CD pipeline.

## Tech Stack

- Python 3.11+ with type hints on all functions
- `click` for CLI framework
- `rich` for terminal UI/output
- `httpx` for async HTTP (CI/CD API calls)
- `scipy.stats` + `numpy` for statistical analysis
- SQLite via `sqlite3` for local storage (~/.pipewatch/data.db)
- `pytest` + `pytest-asyncio` for testing
- `hatch` for build/packaging

## Commands

- `hatch run dev`: Run CLI in dev mode
- `pytest`: Run all tests
- `pytest tests/test_baseline.py -v`: Run specific test file
- `pytest -k "test_drift"`: Run tests matching pattern
- `ruff check src/`: Lint
- `ruff format src/`: Format
- `mypy src/`: Type check

## Architecture

```
src/pipewatch/
├── cli.py              # Click entrypoint — all commands defined here
├── config.py           # YAML config loading from ~/.pipewatch/config.yml
├── providers/          # CI/CD platform adapters (one file per provider)
│   ├── base.py         # Abstract PipelineProvider interface
│   ├── github.py       # GitHub Actions REST API
│   ├── gitlab.py       # GitLab CI API
│   └── jenkins.py      # Jenkins API
├── engine/             # Core analysis — pure functions, no side effects
│   ├── baseline.py     # Rolling median + MAD baseline builder
│   ├── drift.py        # Modified Z-score + Mann-Kendall trend detection
│   ├── flaky.py        # Bayesian flip rate for flaky test detection
│   └── correlator.py   # Links drift to commits/deps/config changes
├── notify/             # Notification dispatchers
├── storage/            # SQLite operations + data models
│   ├── db.py           # Database operations (create, query, upsert)
│   └── models.py       # Dataclasses for Run, Stage, Baseline, DriftEvent
└── ui/                 # Rich terminal output formatters
    └── rich_output.py  # All console rendering lives here
```

## Key Design Rules

- **Local-first**: All data in ~/.pipewatch/. No cloud, no accounts, no telemetry.
- **Provider interface**: Adding a new CI/CD provider = one Python file implementing `PipelineProvider` ABC in providers/base.py.
- **Engine is pure**: engine/ modules take data in, return results. No I/O, no DB calls. Makes testing trivial.
- **Statistics over ML**: Use robust stats (median, MAD, Z-score, Mann-Kendall). No training, no GPUs, no API keys for analysis.
- **Rich output everywhere**: All user-facing output goes through ui/rich_output.py. Never print() directly.

## Data Models (storage/models.py)

Key dataclasses — keep these in sync:
- `PipelineRun`: id, pipeline_id, branch, status, started_at, finished_at, stages[]
- `Stage`: name, status, duration_seconds, started_at, finished_at
- `Baseline`: pipeline_id, stage_name, median_duration, mad, sample_size, computed_at
- `DriftEvent`: run_id, stage_name, metric, expected, actual, z_score, trend_direction, probable_cause

## Provider Interface (providers/base.py)

Every provider must implement:
- `async fetch_runs(limit: int) -> list[PipelineRun]`
- `async fetch_run_detail(run_id: str) -> PipelineRun`
- `async fetch_test_results(run_id: str) -> list[TestResult]` (optional)
- `name: str` property

## Coding Conventions

- Use `async/await` for all provider API calls
- Dataclasses with `@dataclass(frozen=True)` for immutable data models
- Use `pathlib.Path` not `os.path`
- f-strings for string formatting
- Imports: stdlib → third-party → local, separated by blank lines
- All exceptions should be specific (no bare `except:`)
- Use `structlog` for internal logging (not print, not logging module)

## Testing

- Fixtures in tests/fixtures/ contain sample JSON responses from each CI/CD API
- Use `pytest-asyncio` for async provider tests
- Engine tests should be pure — feed in data, assert output, no mocks needed
- Provider tests mock httpx responses using fixtures
- Aim for >80% coverage on engine/ modules

## Important Notes

- NEVER hardcode API tokens. Always read from env vars or ~/.pipewatch/config.yml
- The SQLite DB schema is in storage/db.py — any schema changes need a migration function
- GitHub API rate limits: 5000 req/hr with token, 60 without. Always check X-RateLimit-Remaining header
- Mann-Kendall test from scipy requires minimum 8 data points — handle gracefully when baseline is small
