# Architecture

## Overview

Pipewatch follows a layered architecture with strict boundaries:

```
CLI → Engine → Storage
 ↕       ↕
 UI    Providers
```

## Layer Rules

### Providers (I/O boundary)
- Talk to external CI/CD APIs
- Convert API responses into internal data models
- Handle authentication, rate limiting, pagination
- One file per provider, implementing the `PipelineProvider` ABC

### Engine (pure logic)
- **No I/O, no DB calls, no side effects**
- Takes data models in, returns analysis results
- All statistical computation lives here
- Trivially testable — feed data, assert output

### Storage (persistence)
- SQLite operations only
- Schema defined in code, auto-created on first run
- All data lives in `~/.pipewatch/data.db`

### UI (presentation)
- All Rich console output goes through `ui/rich_output.py`
- Never `print()` directly from other modules
- Handles both human-readable and JSON output modes

### CLI (orchestration)
- Wires providers, engine, storage, and UI together
- Click commands are thin — delegate to engine functions
- Handles argument parsing and config loading

## Statistical Methods

### Baseline: Median + MAD
- **Why not mean + stddev?** A single 10x outlier run would skew the entire baseline. Median and MAD (Median Absolute Deviation) are resistant to outliers.
- **MAD formula:** `MAD = median(|xi - median(x)|)`

### Drift Detection: Modified Z-score
- **Formula:** `z = 0.6745 * (x - median) / MAD`
- **Threshold:** Default 3.0 (configurable). Flags runs deviating >3 MADs.
- **Why 0.6745?** Normalizing constant so modified Z-score matches standard Z-score for normal data.

### Trend Detection: Mann-Kendall
- **Why?** Non-parametric test for monotonic trends. Perfect for catching slow, steady drift.
- **Requirement:** Minimum 8 data points for statistical validity.
- **Output:** Direction (increasing/decreasing/stable) + p-value.

### Flaky Detection: Bayesian Flip Rate
- **Flip:** When a test's status changes between consecutive runs (pass→fail or fail→pass).
- **Rate:** Posterior mean of Beta(flips + 1, non_flips + 1) with uniform prior.
- **Threshold:** Default 0.1 (10% flip rate → flagged as flaky).
