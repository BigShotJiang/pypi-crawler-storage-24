# Adding a New CI/CD Provider

Adding a new provider is the easiest and most impactful way to contribute to Pipewatch.

## Step-by-Step

### 1. Create the provider file

Create `src/pipewatch/providers/<name>.py`. Use `github.py` as your template.

### 2. Implement the interface

```python
from pipewatch.providers.base import PipelineProvider
from pipewatch.storage.models import PipelineRun, TestResult

class YourProvider(PipelineProvider):
    def __init__(self, **kwargs):
        # Accept provider-specific config (repo, project_id, url, token)
        ...

    @property
    def name(self) -> str:
        return "Your Platform Name"

    async def fetch_runs(self, limit: int = 50) -> list[PipelineRun]:
        # Fetch recent runs from the API
        # Map API response → PipelineRun data model
        ...

    async def fetch_run_detail(self, run_id: str) -> PipelineRun:
        # Fetch a single run with stage/job details
        # Map API response → PipelineRun with stages populated
        ...
```

### 3. Map API data to our models

The critical mapping is:
- API's "workflow/pipeline" → `PipelineRun`
- API's "job/step/stage" → `Stage`
- API's status strings → `RunStatus` enum

### 4. Add test fixtures

Save sample API responses as JSON in `tests/fixtures/<name>/`:
- `list_runs.json` — response from listing runs
- `run_detail.json` — response from getting a single run
- `jobs.json` — response from listing jobs/stages

### 5. Write tests

```python
# tests/test_providers/test_<name>.py

import json
from pathlib import Path
import respx
import httpx

FIXTURES = Path(__file__).parent.parent / "fixtures" / "<name>"

@respx.mock
async def test_fetch_runs():
    fixture = json.loads((FIXTURES / "list_runs.json").read_text())
    respx.get("https://api.example.com/runs").mock(
        return_value=httpx.Response(200, json=fixture)
    )

    provider = YourProvider(...)
    runs = await provider.fetch_runs(limit=10)
    assert len(runs) > 0
    assert runs[0].pipeline_id  # Verify mapping
```

### 6. Register in CLI

Add your provider as a choice in `cli.py`'s `init` command and add the provider-specific arguments.

## Checklist

- [ ] Provider implements `PipelineProvider` ABC
- [ ] Maps API data correctly to `PipelineRun` and `Stage` models
- [ ] Handles authentication via token/env var (never hardcoded)
- [ ] Handles API rate limits gracefully
- [ ] Has test fixtures with real-ish API responses
- [ ] Has async tests using `respx` for HTTP mocking
- [ ] Passes `ruff check`, `ruff format`, and `mypy`
