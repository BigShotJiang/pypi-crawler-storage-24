# Contributing to Pipewatch

Thanks for your interest in contributing! Pipewatch is designed to make contribution easy — especially adding new CI/CD providers.

## Quick Setup

```bash
git clone https://github.com/SaqibInTech/pipewatch.git
cd pipewatch
python -m venv venv && source venv/bin/activate
pip install -e ".[dev]"
pytest  # Verify everything works
```

## Adding a New CI/CD Provider

This is the #1 way to contribute. Each provider is a single Python file.

1. Create `src/pipewatch/providers/your_provider.py`
2. Subclass `PipelineProvider` from `providers/base.py`
3. Implement `fetch_runs()` and `fetch_run_detail()`
4. Add test fixtures in `tests/fixtures/your_provider/`
5. Add tests in `tests/test_providers/test_your_provider.py`

See `providers/github.py` as a reference implementation.

## Adding a Notification Channel

1. Create `src/pipewatch/notify/your_channel.py`
2. Implement a `send_alert(event: DriftEvent, baseline: Baseline)` function
3. Wire it into the CLI's `notify` command

## Code Standards

- Type hints on all functions
- Tests for all engine logic (engine/ modules should be 100% pure — no I/O)
- `ruff check` and `ruff format` must pass
- `mypy --strict` must pass

## Pull Request Process

1. Fork the repo and create a branch from `main`
2. Write tests for your changes
3. Ensure all checks pass: `pytest && ruff check src/ && mypy src/`
4. Open a PR with a clear description of what and why

## Good First Issues

Look for issues tagged `good-first-issue` — these are specifically scoped for new contributors.
