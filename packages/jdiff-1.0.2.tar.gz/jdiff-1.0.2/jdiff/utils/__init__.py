"""Utils for jdiff."""
