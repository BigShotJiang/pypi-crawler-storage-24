# AzerAI - Azərbaycan dilində qabaqcıl səsli AI asistent

Plugin əsaslı, çoxdilli AI asistent sistemi.

## Xüsusiyyətlər

- 🇦🇿 **Azərbaycan dili** - Əsas dil Azərbaycan dili
- 🔌 **Plugin sistemi** - Genişlənəbilən plugin arxitekturası
- 🧠 **Memory sistemi** - Konuşma tarixçəsi
- 🎤 **Səsli interfeys** - LiveKit əsaslı səsli AI
- 📦 **Pip paketləri** - 8 plugin pip ilə qurulur

## Quraşdırma

```bash
pip install azerai
```

## Pluginlər

```bash
pip install azerai-browser azerai-datetime azerai-display-control azerai-reminder azerai-file-management azerai-search azerai-speedtest azerai-weather
```

## İstifadə

```bash
python -m azerai console
```

## Lisenziya

MIT License
