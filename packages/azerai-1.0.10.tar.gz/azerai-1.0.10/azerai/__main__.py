#!/usr/bin/env python3
"""
AzerAI - Azərbaycan dilində qabaqcıl səsli AI asistent

Bu modul `python -m azerai` komutu ilə işə salınır.
"""

if __name__ == "__main__":
    from . import main
    main()
