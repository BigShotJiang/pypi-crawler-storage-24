"""
AzerAI Plugin Sistemi - Pip Paketləri üçün Uyğunlaşdırılmış Versiya

Bu sistem həm local plugins/ klasoründəki, həm də pip ilə qurulmuş
plugin paketlərini avtomatik olaraq aşkarlayır və yükləyir.
"""

import os
import importlib
import importlib.util
import inspect
import pkgutil
import logging
from typing import Dict, List, Any
from pathlib import Path

logger = logging.getLogger(__name__)


class PluginManager:
    """Plugin keşfini və yükləmeyi idarə edir - həm local, həm pip paketləri"""
    
    def __init__(self, plugins_dir: str = "plugins"):
        self.plugins_dir = Path(plugins_dir)
        self.loaded_plugins = {}
        self.plugin_tools = {}
        self.plugin_info = {}
        self.plugin_prompts = {}
        logger.info("PluginManager initialized")

    def discover_plugins(self):
        """Yalnız pip pluginlərini kəşf edir - local pluginləri skip edir"""
        discovered_plugins = {}
        
        # Local pluginləri tamamilən skip et
        logger.info("Skipping local plugins due to NumPy compatibility issues")
        
        # Yalnız pip pluginlərini kəşf et
        pip_plugins = [
            'azerai_browser', 'azerai_datetime', 'azerai_display_control',
            'azerai_reminder', 'azerai_file_management', 'azerai_search',
            'azerai_speedtest', 'azerai_weather'
        ]
        
        for plugin_name in pip_plugins:
            try:
                # Pip pluginini import etməyə cəhd et
                module_name = plugin_name.replace('-', '_')
                spec = importlib.util.find_spec(module_name)
                if spec is not None:
                    discovered_plugins[plugin_name] = {
                        'type': 'pip',
                        'module': module_name,
                        'name': plugin_name
                    }
            except ImportError:
                continue
        
        return discovered_plugins

    def load_plugin(self, plugin_name: str, plugin_info: Dict[str, Any]):
        """Bir plugin yükləyir"""
        try:
            if plugin_info['type'] == 'local':
                # Local plugin
                spec = importlib.util.spec_from_file_location(
                    plugin_name, plugin_info['path']
                )
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
            else:
                # Pip plugin
                module = importlib.import_module(plugin_info['module'])
            
            self.loaded_plugins[plugin_name] = module
            logger.info(f"Loaded plugin: {plugin_name}")
            
            # Plugin məlumatlarını topla
            self._extract_plugin_info(plugin_name, module)
            
        except Exception as e:
            logger.error(f"Failed to load plugin {plugin_name}: {e}")

    def _extract_plugin_info(self, plugin_name: str, module):
        """Plugin məlumatlarını və alətlərini çıxarır"""
        try:
            # Plugin məlumatları
            info_file = Path(module.__file__).parent / "info.py"
            if info_file.exists():
                info_spec = importlib.util.spec_from_file_location(
                    f"{plugin_name}_info", info_file
                )
                info_module = importlib.util.module_from_spec(info_spec)
                info_spec.loader.exec_module(info_module)
                
                if hasattr(info_module, 'PLUGIN_INFO'):
                    self.plugin_info[plugin_name] = info_module.PLUGIN_INFO
                else:
                    self.plugin_info[plugin_name] = f"# {plugin_name.title()} Plugin\nNo description available."
            else:
                self.plugin_info[plugin_name] = f"# {plugin_name.title()} Plugin\nNo description available."
            
            # Plugin promots
            prompts_file = Path(module.__file__).parent / "prompts.py"
            if prompts_file.exists():
                prompts_spec = importlib.util.spec_from_file_location(
                    f"{plugin_name}_prompts", prompts_file
                )
                prompts_module = importlib.util.module_from_spec(prompts_spec)
                prompts_spec.loader.exec_module(prompts_module)
                
                if hasattr(prompts_module, 'PLUGIN_INSTRUCTION'):
                    self.plugin_prompts[plugin_name] = prompts_module.PLUGIN_INSTRUCTION
                else:
                    self.plugin_prompts[plugin_name] = ""
            else:
                self.plugin_prompts[plugin_name] = ""
            
            # Plugin alətlərini topla
            tools = []
            for name, obj in inspect.getmembers(module):
                if hasattr(obj, '__livekit_tool__'):
                    tools.append(obj)
            
            self.plugin_tools[plugin_name] = tools
            
        except Exception as e:
            logger.error(f"Error extracting plugin info for {plugin_name}: {e}")

    def load_all_plugins(self):
        """Bütün pluginləri yükləyir"""
        discovered = self.discover_plugins()
        
        for plugin_name, plugin_info in discovered.items():
            self.load_plugin(plugin_name, plugin_info)
        
        return self.loaded_plugins

    def get_all_tools(self) -> List[Any]:
        """Bütün plugin alətlərini qaytarır"""
        all_tools = []
        for tools in self.plugin_tools.values():
            all_tools.extend(tools)
        return all_tools

    def get_plugin_info(self) -> str:
        """Bütün plugin məlumatlarını qaytarır"""
        info_parts = []
        for plugin_name, info in self.plugin_info.items():
            info_parts.append(info)
            info_parts.append("")
        return "\n\n".join(info_parts)

    def get_plugin_prompts(self) -> str:
        """Bütün plugin promotslarını qaytarır"""
        prompt_parts = []
        for plugin_name, prompt in self.plugin_prompts.items():
            if prompt:
                prompt_parts.append(prompt)
        return "\n\n".join(prompt_parts)


# Global instance
plugin_manager = PluginManager()

# Convenience functions
def get_all_tools() -> List[Any]:
    """Bütün plugin alətlərini qaytarır"""
    return plugin_manager.get_all_tools()

def get_plugin_info() -> str:
    """Bütün plugin məlumatlarını qaytarır"""
    return plugin_manager.get_plugin_info()

def get_plugin_prompts() -> str:
    """Bütün plugin promotslarını qaytarır"""
    return plugin_manager.get_plugin_prompts()

# Auto-load plugins
plugin_manager.load_all_plugins()
