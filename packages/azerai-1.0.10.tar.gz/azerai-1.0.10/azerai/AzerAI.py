from dotenv import load_dotenv
import asyncio

from livekit import agents, rtc
from livekit.agents import AgentServer, AgentSession, Agent, room_io
from livekit.plugins import (
    google,
    silero,
)
from .plugins import get_all_tools, get_plugin_info, get_plugin_prompts
from .prompts import AGENT_INSTRUCTION, SESSION_INSTRUCTION
from .memory import MemoryManager
load_dotenv(".env")

class Assistant(Agent):
    def __init__(self) -> None:
        # Bellek yöneticisini başlat
        self.memory = MemoryManager()
        # Bellek bağlamını al ve talimatlara ekle
        memory_context = self.memory.get_memory_context()

        plugin_info = get_plugin_info()
        plugin_prompts = get_plugin_prompts()
        super().__init__(instructions=plugin_info + plugin_prompts + AGENT_INSTRUCTION + memory_context)

    async def on_user_turn_completed(self, turn_ctx, new_message):
        """Kullanıcı konuşmayı bitirdiğinde çağrılır - bellek bağlamı ekle"""
        # Bellek bağlamını al ve varsa kullanıcı mesajının başına ekle
        memory_context = self.memory.get_memory_context()
        if memory_context and new_message.content:
            # İçeriği işle - bir string veya liste olabilir
            if isinstance(new_message.content, list):
                # Eğer içerik bir liste ise, bellek bağlamını ilk metin öğesinin başına ekle
                context_note = "\n[Önceki konuşmalardan hatırla: Yukarıdaki konuşma geçmişine göre cevap ver]\n"
                if new_message.content and isinstance(new_message.content[0], str):
                    new_message.content[0] = memory_context + context_note + new_message.content[0]
            elif isinstance(new_message.content, str):
                # Eğer içerik bir string ise, bellek bağlamını başına ekle
                context_note = "\n[Önceki konuşmalardan hatırla: Yukarıdaki konuşma geçmişine göre cevap ver]\n"
                new_message.content = memory_context + context_note + new_message.content
        
        await super().on_user_turn_completed(turn_ctx, new_message)
    
    async def store_conversation(self, user_message: str, assistant_message: str):
        """Konuşmayı bellekte sakla"""
        if user_message and assistant_message:
            self.memory.add_conversation(user_message, assistant_message)

def main():
    """AzerAI asistanını başlat"""
    server = AgentServer()

    @server.rtc_session(agent_name="AzerAI")
    async def my_agent(ctx: agents.JobContext):
        plugin_info = get_plugin_info()
        plugin_prompts = get_plugin_prompts()
        all_tools = get_all_tools()
        # Bellekte saklamak için konuşma çiftlerini takip et
        last_user_message = None

        # Asistan örneği oluştur
        assistant = Assistant()

        session = AgentSession(
            vad=silero.VAD.load(),
            llm=google.realtime.RealtimeModel(
                voice="Puck"
            ),
            tools=all_tools,
        )

        # Mesajları takip etmek için konuşma öğelerini dinle
        @session.on("conversation_item_added")
        def on_conversation_item(event):
            nonlocal last_user_message
            message = event.item
            
            # Kullanıcı mesajı olup olmadığını kontrol et
            if message.role == "user" and message.text_content:
                last_user_message = message.text_content
            
            # Asistan mesajı olup olmadığını ve eşleştirmek için bir kullanıcı mesajı olup olmadığını kontrol et
            elif message.role == "assistant" and message.text_content and last_user_message:
                # Konuşma çiftini sakla
                asyncio.create_task(assistant.store_conversation(
                    last_user_message, 
                    message.text_content
                ))
                last_user_message = None  # Sakladıktan sonra sıfırla

        await session.start(
            room=ctx.room,
            agent=assistant,
            room_options=room_io.RoomOptions(
                audio_input=room_io.AudioInputOptions(
                    #noise_cancellation=lambda params: noise_cancellation.BVCTelephony() if params.participant.kind == rtc.ParticipantKind.PARTICIPANT_KIND_SIP else noise_cancellation.BVC(),
                ),
            ),
        )

        # Reminder plugin'ine session referansını geç
        try:
            from azerai_reminder.plugins.reminder.main import reminder_tools
            reminder_tools.session_ref = session
            reminder_tools.loop_ref = __import__('asyncio').get_running_loop()
            print(" Reminder plugin'ine session referansı verildi")
        except Exception as e:
            print(f" Reminder session ayarlanamadı: {e}")

        await session.generate_reply(
            instructions=SESSION_INSTRUCTION
        )

    agents.cli.run_app(server)

if __name__ == "__main__":
    main()
