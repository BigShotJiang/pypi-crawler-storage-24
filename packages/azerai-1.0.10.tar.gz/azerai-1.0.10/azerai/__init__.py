"""
AzerAI - Azərbaycan dilində qabaqcıl səsli AI asistent

Plugin əsaslı, çoxdilli AI asistent sistemi.
"""

__version__ = "1.0.6"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .AzerAI import Assistant, main
from .plugins import get_all_tools, get_plugin_info, get_plugin_prompts

__all__ = [
    "Assistant",
    "main",
    "get_all_tools",
    "get_plugin_info", 
    "get_plugin_prompts"
]
