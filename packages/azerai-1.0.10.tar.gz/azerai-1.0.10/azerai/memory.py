import json
import os
from datetime import datetime
from typing import List, Dict, Optional


class MemoryManager:
    """Manages conversation history stored in JSON file"""
    
    def __init__(self, memory_file: str = "conversation_history.json"):
        self.memory_file = memory_file
        self.conversations = []
        self.max_conversations = 100  # Keep last 100 conversations
        self._load_conversations()
    
    def _load_conversations(self):
        """Load conversations from JSON file"""
        try:
            if os.path.exists(self.memory_file):
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.conversations = data.get('conversations', [])
            else:
                self.conversations = []
        except Exception as e:
            print(f"Error loading memory: {e}")
            self.conversations = []
    
    def _save_conversations(self):
        """Save conversations to JSON file"""
        try:
            data = {
                'conversations': self.conversations,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Error saving memory: {e}")
    
    def add_conversation(self, user_message: str, assistant_message: str):
        """Add a new conversation pair"""
        conversation = {
            'user': user_message,
            'assistant': assistant_message,
            'timestamp': datetime.now().isoformat()
        }
        
        self.conversations.append(conversation)
        
        # Keep only the last N conversations
        if len(self.conversations) > self.max_conversations:
            self.conversations = self.conversations[-self.max_conversations:]
        
        self._save_conversations()
    
    def get_memory_context(self) -> str:
        """Get formatted memory context for AI"""
        if not self.conversations:
            return ""
        
        # Get last few relevant conversations
        recent_conversations = self.conversations[-5:]  # Last 5 conversations
        
        context_parts = ["Əvvəlki söhbətlərdən məlumat:"]
        
        for conv in recent_conversations:
            timestamp = datetime.fromisoformat(conv['timestamp'])
            formatted_time = timestamp.strftime('%d.%m.%Y %H:%M')
            context_parts.append(f"[{formatted_time}]")
            context_parts.append(f"İstifadəçi: {conv['user']}")
            context_parts.append(f"Azer: {conv['assistant']}")
            context_parts.append("")
        
        return "\n".join(context_parts)
    
    def clear_memory(self):
        """Clear all conversation history"""
        self.conversations = []
        self._save_conversations()
