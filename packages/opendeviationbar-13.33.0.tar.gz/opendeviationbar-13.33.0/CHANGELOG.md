# [13.33.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.32.1...v13.33.0) (2026-03-20)


### Features

* Rust-side bar dedup — prevent overlaps at the source ([65a28ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/65a28ae076a7dd53eac79e9c47aae5c055475e88))

## [13.32.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.32.0...v13.32.1) (2026-03-20)


### Bug Fixes

* **deploy:** incorporate playbook patterns into deploy task ([a6af7c1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a6af7c1e0f70ae54046a7cedb54e8c156c48caac))


### Reverts

* overlap_strategy back to "off" — "replace" causes mutation storms ([20d64c8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/20d64c835f1e588a995bc7b08b7e6475b6b91e79))

# [13.32.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.31.0...v13.32.0) (2026-03-20)


### Bug Fixes

* sidecar overlap_strategy "off" → "replace" (auto-delete+rewrite guard) ([e407dca](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e407dca3b38b8ed1aa95fe4f4cecda857dcb0ccd))


### Features

* deploy hardening — safety gates + git SHA logging ([eea0c89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/eea0c8977b5a90744019d5303cf4d83c15cb06b5))
* sidecar overlap self-heal — detect and repair today's overlaps ([317a3a9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/317a3a94024348d436e12075737a73797b6a03c3))

# [13.31.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.30.0...v13.31.0) (2026-03-20)


### Bug Fixes

* **06-02:** fix trade_count field name and unused policy warning in live_engine ([0f3e004](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f3e0043c21f6fb12f86d79480bfe93caaeb64f0))
* **kintsugi:** deferred shards don't exhaust budget — prevents tight loop ([bb10135](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bb10135deb5ea31ae9db76ea434ca519c7ef034d))
* rename plan files to match gsd-tools pattern ([4f13a28](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4f13a28e496df8b3a4a80efe26d9a9ecacbe7d65))
* roadmap phase heading format (em-dash → colon) ([893fcf0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/893fcf0d32e0bcfcdfda12852900028fe06bc5f4))
* **sidecar:** fill_from_rest runs when ANY pairs lack checkpoints ([b695580](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b6955809895a9002a68a4c0cb62b16db7e529864))
* **streaming:** fill_from_rest must not break on partial chunks ([979ddcc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/979ddcc1bb755dbf8d7740061fe43e441ea701ea))
* **streaming:** robust fill_from_rest + enable Rust tracing to journal ([1e3084e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1e3084e31b26575a1c5e4e221899fa9d23fda31f))


### Features

* **01-01:** add junction fill between REST and WS in symbol_task ([4d2b9a9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4d2b9a9e12910618a2c914ebbe0ce3e37c1ba605))
* **02-01:** add event_type parameter to puck_fill for junction vs normal differentiation ([ab47293](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ab472931b101c9af3ccdec224efd535016f33630))
* **02-01:** add junction telemetry with gap size, forming bar trades, WS buffer depth ([ff8aac0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ff8aac0f209d48b8475e7d4e1e33a87335621a4d))
* **02-01:** add per-symbol fill_from_rest timing and summary telemetry ([cf6e0dd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cf6e0ddbbbc8250527646c662d177cbf6da6083e))
* **06-01:** add CombinedWebSocketStream with envelope parsing and demux ([c54d686](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c54d686ce22b6d354dd797c4c83774adec9eb4aa))
* **06-02:** remove per-symbol fallback WS creation in symbol_task() ([5ade3f2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5ade3f2a93528aea350ae32b0233a6b0f99246e8))
* **06-02:** replace per-symbol WS spawn in start_ws() with CombinedWebSocketStream ([27b5345](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/27b534597a968457dc9f6b36b3aacfb70c0a7e8d))
* **combined-ws:** add proactive overlapping reconnection at 23h (COMB-05) ([9f8505f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9f8505fed1fa9f00ab85aa9925c612a39c66aff9))
* **rate-limiter:** convert ceiling to AtomicU32 + add set_ceiling() ([657f308](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/657f308418440cd21492e6bb49ac698fe1467221))
* **streaming:** increase WS channel capacity from 1000 to 50000 (PARA-04) ([fd4a0e4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fd4a0e4aa88a32901548030aad59285cab430a17))
* **streaming:** parallel fill_from_rest with JoinSet + Semaphore(4) (PARA-01, PARA-02, PARA-03) ([c247b76](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c247b765066d6a1d11448af8055eb71ee77b62d1))

# [13.30.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.29.0...v13.30.0) (2026-03-19)


### Bug Fixes

* **heartbeat:** classify midnight-boundary gaps separately from backfill ([a5d00fa](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a5d00faa176c0e84e6df07c160dbffe4220c621e))
* **heartbeat:** emergency alert uses HTML parse_mode correctly ([a737b29](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a737b29984bf2f3e52fb70ed490583a3af79b401))
* **heartbeat:** explicit HEALTH_GATE_KEYS instead of fragile all-bools ([1e79928](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1e79928fa05714cb151413c8f6d826c495ee6a27))
* **heartbeat:** use satellite emoji for streaming symbols instead of star ([201b387](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/201b387e40375bc51d035a2b52acac8638404764))
* **sidecar:** remove Python inline backfill — replaced by chunked fill_from_rest ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([a47c2c4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a47c2c4525899bb9d651307f7961097eb30915f7))
* symbols.toml is sole SSoT for streaming symbols ([0132283](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0132283f9463c798fb275839aa45f70ba3ea6565))


### Features

* add full-symbol-streaming-spike skill ([a950546](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a95054675250225d06a3748e172700b4ed29ee5d))
* add heartbeat-refactor-execute skill — autonomous self-validating pipeline ([1062cec](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1062cec2129d2ff1bd203e91aeb3ef17c7e3073c))
* **heartbeat:** add dead letter count check ([18d6d4f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/18d6d4ff4b49b17c50e5ac14ba877c83596b8b7c))

# [13.29.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.28.2...v13.29.0) (2026-03-19)


### Bug Fixes

* **kintsugi:** skip streaming symbols in trailing-edge fill — Writer Ownership [#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280) ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([aa51476](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/aa51476d6d2ffa07b6b590c27cb27afe36d9ff11))
* **sidecar:** re-enable Python inline backfill — Rust fill_from_rest OOMs ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([761fa1f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/761fa1f18ea6d2cca590030f2b9430414d03bd93))


### Features

* add streaming-writer-exclusion-spike skill scaffold ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([437edc9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/437edc97b27dff1e621fae55c108351dd620c015))
* **heartbeat:** classify Stathera gaps — intra-day vs backfill progression ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286) Spike F) ([0651b6c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0651b6cc6473b036724e0f8f97d1686e1f395dde))
* **streaming:** chunked fill_from_rest — 50K trades/chunk eliminates OOM ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([15fbbcc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/15fbbcc39173a99236a7777228161b13bf39d82b))

## [13.28.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.28.1...v13.28.2) (2026-03-19)


### Bug Fixes

* **streaming:** cap fill_from_rest to_id — i64::MAX caused integer overflow ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([ab36bf8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ab36bf81d7deb4f740fd4227701421aac2ff64f5)), closes [hi#volume](https://github.com-terrylica/hi/issues/volume)

## [13.28.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.28.0...v13.28.1) (2026-03-19)


### Bug Fixes

* **streaming:** propagate trade-ID seeds to engine before fill_from_rest ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([0fce196](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0fce196c7a0231b9e49d68f07b242f541b010313))

# [13.28.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.27.0...v13.28.0) (2026-03-19)


### Bug Fixes

* **backfill:** Ariadne end_ms filter used wrong timestamp key — fetched past boundary ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([7169807](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7169807c72d490bc900f5bf85aeb7e040322f05e))


### Features

* **sidecar:** inline startup backfill — zero manual intervention on restart ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([e475d1f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e475d1f71847f15bf2a68692bcd5445e34309ad1))
* **streaming:** Rust fill_from_rest() — zero-gap restart via same-processor REST→WS transition ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([21cf4a6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/21cf4a6f19d0d583f6a687b26c6cde9f207e1d93))

# [13.27.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.26.1...v13.27.0) (2026-03-18)


### Bug Fixes

* **sidecar:** auto-delete stale checkpoint files on rejection ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([562a2dc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/562a2dcb86eb6f0dc8e9cff5e38dadab20fc2aac))
* **sidecar:** autonomous overlap prevention on checkpoint restore ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([6113e0e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6113e0ea242e154a3bf8a03267e646532302c892))
* **sidecar:** preserve checkpoint files on stale rejection + min-TID overlap guard ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([a3d179c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a3d179cd096f4cb6b692a96d9036b4850d599674))
* **sidecar:** reject stale checkpoints that point beyond CH last bar ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([8a78a91](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a78a910dd731b2a34b686d3093af4ba02b11fd2))
* **sidecar:** remove startup DELETE — RMT overwrites by first_agg_trade_id ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([2961b1e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2961b1e1e517eb1c4622e75320e003be31a6b7f8))
* **sidecar:** revert individual overlap deletion — cascades make it worse ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([8121ee5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8121ee59f32282f1f0367099e14b5a79c8149c1f))


### Features

* **sidecar:** day-boundary healer handles overlaps + gaps autonomously ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([51b8af0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51b8af0ea75312a35add3fcbb4409b11199b453a))
* **sidecar:** deterministic day-boundary gap heal on startup ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([5c2ec3f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5c2ec3f5b537ff56f896224340dad2ed38750c1a))
* **sidecar:** reinstate clean-slate DELETE on startup ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([715d8f3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/715d8f377f34c647e76d6d246b4244111dad9912))

## [13.26.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.26.0...v13.26.1) (2026-03-18)


### Bug Fixes

* update streaming tests for 6000 rate limit default ([a130440](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a130440c11874083e3a1eb18818934355435bd51))

# [13.26.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.25.0...v13.26.0) (2026-03-18)


### Bug Fixes

* correct comment — checkpoint restore + Puck produces zero overlaps ([a319d2c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a319d2c2ffa755ba890bffd685bd1842ae75f6cc))
* **heartbeat:** clarify Stathera reporting — bar-level artifacts, not data loss ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([cfd3737](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cfd3737c84c8665be68337e2d652e2ae866270cc))
* **sidecar:** remove clean-slate DELETE — keep existing bars for data continuity ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([c712ef1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c712ef106573cfe08c78f2f84f75367a53e40611))
* **streaming:** remove Puck 100K trade limit — fill any gap regardless of size ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([03697e3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/03697e3cbe820b4a3bd806381cd2a9d6633fe914))


### Features

* **sidecar:** clean-slate startup — DELETE today's bars, Puck fills from yesterday ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([17490c1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/17490c11e5b0a47b5207bb77257a5ea8476f5c11))

# [13.26.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.25.0...v13.26.0) (2026-03-18)


### Bug Fixes

* correct comment — checkpoint restore + Puck produces zero overlaps ([a319d2c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a319d2c2ffa755ba890bffd685bd1842ae75f6cc))
* **heartbeat:** clarify Stathera reporting — bar-level artifacts, not data loss ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([cfd3737](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cfd3737c84c8665be68337e2d652e2ae866270cc))
* **sidecar:** remove clean-slate DELETE — keep existing bars for data continuity ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([c712ef1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c712ef106573cfe08c78f2f84f75367a53e40611))
* **streaming:** remove Puck 100K trade limit — fill any gap regardless of size ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([03697e3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/03697e3cbe820b4a3bd806381cd2a9d6633fe914))


### Features

* **sidecar:** clean-slate startup — DELETE today's bars, Puck fills from yesterday ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([17490c1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/17490c11e5b0a47b5207bb77257a5ea8476f5c11))

# [13.25.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.24.0...v13.25.0) (2026-03-18)


### Features

* buffered WS start — zero-gap restart via start_ws() → start() ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([3754c32](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3754c32c4fc1798b4af82b4b229486894072d5e9))

# [13.24.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.23.2...v13.24.0) (2026-03-18)


### Bug Fixes

* **sidecar:** remove startup _gap_fill — fresh processor creates boundary gaps ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([a20e477](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a20e4773a814b79244f4e407a0bac70f2d5f0282))


### Features

* expose fetch_aggtrades_parallel to Python — 5x faster kintsugi REST ([#291](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/291)) ([7b6e50d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7b6e50d4f0a11bf244beb3549d1bc724d5deff42))
* unified REST rate limiting — 6000 budget, OnceLock singleton, per-process ceiling ([#291](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/291)) ([77c8d8f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/77c8d8fc7f2af044e7b24bb6b07b8be375679fe5))

## [13.23.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.23.1...v13.23.2) (2026-03-17)


### Bug Fixes

* **streaming:** propagate CH seeds to gap detector — eliminate startup gaps ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([3457f05](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457f05920fcae3ae356d8317803d7a2ceff141d))

## [13.23.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.23.0...v13.23.1) (2026-03-17)


### Bug Fixes

* **streaming:** update gap detector after on-demand fill_gap ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([aed6a71](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/aed6a7156b33ba944580f2f7d37435f514568967))

# [13.23.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.22.0...v13.23.0) (2026-03-17)


### Bug Fixes

* **asclepius:** permanently disable — fill_gap() on live engine causes cascade ([#284](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/284)) ([023e947](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/023e947c099d971b9c0e832e63e2f421289ff658))
* **asclepius:** use Puck fill_gap() instead of backfill_gap() ([#284](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/284)) ([37d169b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/37d169b45f6b3b7e6fdbd071534ba7d9a2d6f314))
* **core:** monotonic guards on last_agg_trade_id and close_time ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([338a8b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/338a8b454554353149bc6e62224e65c84b88b2b8))
* **deploy:** disable Asclepius — backfill_gap() produces malformed bars ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([ce73490](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ce73490d519c45bf2b3ef001e6e49bec35d74ab9))
* **heartbeat:** stathera_all_gaps_known should not gate health ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([c53cb15](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c53cb159e3976e5195d9a4d52b04f48738a3e65e))
* **kintsugi:** always try Vision before REST — remove static T-7 cutoff ([#285](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/285)) ([b97dc1b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b97dc1ba6a8b8bc1203654fdb0276f31192d2be1))
* **reconstruct:** use 1-hour chunks to prevent OOM with multi-threshold fan-out ([#285](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/285)) ([2a1ac86](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2a1ac86ba429eae70a260ed2c824d9216c210337))
* **sidecar:** expose Asclepius metrics in /health endpoint ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([02f1e2b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/02f1e2b1c76cf9f345ddb53dafa874dd962ccc61))
* **sidecar:** limit live streaming to BTCUSDT,ETHUSDT until combined WS ([#286](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/286)) ([4715951](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/47159515fd758ddb82dfe2f7b0cdc91315ac7342))
* **sidecar:** remove reconstruct_today + bump MemoryMax 2.5G→4G ([#290](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/290)) ([580f34b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/580f34b46db36f9c48c85315433e7e36ba15416f))
* **write-gate:** reject physically impossible bars before ClickHouse insert ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([d9ba4f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d9ba4f9d2863e3e8a56a1a1b039bb65db84b6fea))


### Features

* reconstruct_today fetches trades ONCE per symbol, all thresholds simultaneously ([#285](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/285)) ([8f8416a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8f8416ad5c649c2665dfbafd9c1024480af5b5e4))
* **registry:** enable all 16 Tier 1 symbols — Parquet tick cache pre-seeded ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([ae7d2b1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ae7d2b1433c24e71b9b01747ed84e683075136af))
* **sidecar:** reconstruct today's bars on every startup ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([04c4e4d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/04c4e4d1722ac3501cd7a85b09237fcbf6dd56e9))

# [13.22.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.21.0...v13.22.0) (2026-03-16)


### Features

* sidecar owns today, kintsugi owns yesterday — ownership boundary ([#280](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/280)) ([275950b](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/275950b852a9ce99591de644e1dbbfe51e664c34)), closes [#281](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/281) [#282](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/282) [#283](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/283)

# [13.21.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.20.0...v13.21.0) (2026-03-16)


### Bug Fixes

* **repair:** combine_chunks() before to_batches() — was processing 3% of trades ([517e200](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/517e200b1c4df83dfbea1eb6bab993d9b7e55fbb))
* **repair:** convert Arrow Table to RecordBatch for process_trades_arrow() ([8b8fbc5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8b8fbc5c7e75363a2e3bae64118ee71483dc765e))
* **repair:** revert to dict path — Arrow schema mismatch needs separate fix ([1a24341](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1a2434171c51950f9a7d49c6ddc9b9b7be0f5488))
* **repair:** write bars and orphan separately (Arrow vs dict schema differ) ([8369cca](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8369cca5d1278a3143fe8f3a14396ae4218b1941))
* **scripts:** thread-local CH cache reuse to prevent fd exhaustion ([0961428](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0961428eedd8a35b30cc9c050c4cf582116f65e2))


### Features

* **seeder:** support Binance Vision UM futures aggTrades ([#278](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/278)) ([8bffc30](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8bffc307c1873eb4b5588a71ec0c12c716e343ff))


### Performance Improvements

* **repair:** Arrow zero-copy + bounded futures + allocator purge ([6fcd796](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6fcd796cbfb2f7010c5cdd94b21b4220b7672a76))
* **repair:** use overlap_strategy=warn instead of replace ([084be64](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/084be64e0de43f53a9d3f55074f5197324bdbe9d))

# [13.20.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.19.0...v13.20.0) (2026-03-14)


### Bug Fixes

* **backfill:** wire OPENDEVIATIONBAR_MEMORY_MAX_BYTES into BackfillConfig ([217ba84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/217ba8460454ddcfa63bb6bb25fc2cad65de8e37))
* **core:** compute microstructure features for orphan bars ([#275](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/275)) ([48e0674](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/48e0674d995d348e72b29f9260d039237f812e9f))
* **heartbeat:** auto-heal editable .pth shadowing when wheel dist-info is present ([cce4224](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cce4224edbacafed69f1e1b6d5b64370f3246f4c))
* **heartbeat:** distinguish genesis seeding from kintsugi gap repair ([d4865d4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4865d424d649d9bec77ada6c1018ceb026f9f36))
* **heartbeat:** escape HTML in version_drift_detail to fix Telegram 400 Bad Request ([19fad41](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/19fad410237ea81736dd1f8c6660621776c18158))
* **heartbeat:** notify with sound on auto-heal pth removal, show detail in message ([4b560b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4b560b403c46527b8e1346bfa343f2b4f9020a83))
* **heartbeat:** use direct_url.json to distinguish editable from wheel before auto-heal ([0ea16a6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0ea16a6c606ee82e1a4285c108329b447e4d2649))
* **kintsugi:** downgrade genesis verify_repair log from WARNING to DEBUG ([6501f43](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6501f43ed1c1d4ab2db7ff500c33ac74ef11f663))
* **streaming:** burst-atomic frame processing for same-ms trades ([#273](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/273)) ([9f44a09](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9f44a096a5c1b86a2536cea929bd9e90667eab0f))
* **systemd:** add OPENDEVIATIONBAR_BACKFILL_MEMORY_MAX_BYTES to service files ([2c283f7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2c283f77db8c98a6add799ec915eb395cf166572))


### Features

* **kintsugi:** genesis shard detection for newly-enabled symbols (Issue [#274](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/274)) ([99dc992](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/99dc9929d5415270c7fe12010a14ea78a30fcdba))

# [13.19.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.18.0...v13.19.0) (2026-03-14)


### Bug Fixes

* **providers:** fromId pagination in fetch_aggtrades_rest to prevent same-ms trade drops ([536d61a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/536d61ad2b729c159d56ef5c0f892ac2716e6a5c))


### Features

* **kintsugi:** registry-driven shard priority via kintsugi_priority field ([0b7b9ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0b7b9ae59cfe122c51125f5a0968d571faea9b0c))

# [13.18.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.17.1...v13.18.0) (2026-03-14)


### Bug Fixes

* **heartbeat:** flag symbols with sparse ClickHouse coverage in Freshness section ([81919cd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/81919cd57059bd72e094bbed18f6ed93e65bcb33))
* **heartbeat:** prune dead code and align truth with production state ([889b6b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/889b6b495b00199f98899ab07c823a2084acebdd))
* **heartbeat:** remove 2 dead result keys ([1a575f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1a575f938cee9d6ea97465ebf1aded7056993120))
* **monitoring:** show live seeder journal progress as fallback during running state ([299a999](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/299a9991b9f1740e3342695ef5975d41416e5c35))
* **monitoring:** show live seeder progress during multi-hour bulk runs ([1739451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/173945118e9e91d59c7e3593eb00946c135d8970))
* **scripts:** fail-loud hardening for heartbeat and seeder ([37cd820](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/37cd8206695cef1099a56e1d118041604f3dbe1d))
* **seeder:** normalize Vision timestamps from µs to ms (Binance format change ~2025) ([5752f98](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5752f98002bf785682bba11855ec6cfbbe8c1f62))


### Features

* **heartbeat:** fingerprint known Stathera gaps with detailed Telegram diagnostic ([1e60077](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/1e6007782e67361153c8800040a0f0071ef8dfe3))
* **monitoring:** add seeder to all monitoring layers ([8c2e613](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8c2e613d8e7acbbdf4848049da76e528187bb77d))
* **registry:** enable ETHUSDT at 250/500/750/1000 dbps ([0f4c1d6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f4c1d6a9cf8632c67b0e94ce323342743e5882a))

## [13.17.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.17.0...v13.17.1) (2026-03-13)


### Bug Fixes

* **release:** crates publish skips correctly when no new version ([dffa29c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/dffa29ca10e09dd79981962a9030ba44e5d09c80))

# [13.17.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.16.1...v13.17.0) (2026-03-13)


### Bug Fixes

* **cache:** per-threshold error isolation + configurable workers in multi-threshold fan-out ([e32ac14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e32ac1443decf88a81a3c0ac980cb14320116891))
* **checkpoint:** eliminate 4× redundant Vision downloads in multi-threshold network path ([91f8e17](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/91f8e17cfafb79c573cd273fd72f8590c0f899f2))
* **kintsugi:** add lightweight_mutation_projection_mode=drop for DELETE FROM ([ad43bd1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad43bd1e09119247509e8757b1d34b7d52f149e6))
* **kintsugi:** auto-delete stale left-straddling bars after _do_replace async race ([ad06650](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad06650705b3a1597c8c477c8d2f0e094f3397ad))
* **kintsugi:** reduce batch_days 3650→365 to prevent RSS memory pressure ([8d8c6cc](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8d8c6ccf57b73bd85096d83491ff71720abb7c26))
* **kintsugi:** replace heavyweight ALTER TABLE DELETE with lightweight DELETE FROM ([c9cb5c5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9cb5c5531a8b789fde0b8583ae6db15c6cc6a3b)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)
* **kintsugi:** split Vision exception handling to avoid false negative cache entries ([fa40c9d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fa40c9d85408b2c11510b6c00dc1f523c55921a2))
* **kintsugi:** T-7 Vision cutoff + remove batch-level Redis write lock ([28100f9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/28100f9329e18a39398012d5b89c4e6e24e4a77e))
* **monit:** raise all memory thresholds to 70% of bigblack RAM ([7f11333](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7f11333a9c393eb7ba6d1804244a313616c062d6))
* **monit:** set kintsugi memory alert at 70% of bigblack RAM (42700 MB) ([4e4ae29](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4e4ae29d9f4c293794b97190af06d0d2f37ba7dc))
* **seeder:** 16→8 workers, raise MemoryMax 2G→6G ([191137f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/191137f8875c317c79af8e4eab68a518537ca9be))
* **seeder:** MEM-016v2 — per-day staging files + streaming merge ([0e64dbd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0e64dbd361d495af429f8385a0e303dbb9214273))
* **seeder:** MEM-017 sequential per-day streaming appends ([2f55034](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2f55034741429460f6de1fb1ebdc1052ae7345ad))
* **seeder:** MEM-018 bounded future submission — prevent DataFrame accumulation ([d941fb2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d941fb2f07947b3a40a09db5ea7d3732aea830ac))
* **seeder:** MEM-021 mimalloc + MEM-024 malloc_trim to eliminate glibc arena RSS plateau ([c416024](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c41602446f75cd6a8047501fb451e150510876f9)), closes [hi#water-mark](https://github.com-terrylica/hi/issues/water-mark)
* **seeder:** move state file /tmp → /var/tmp (monit PrivateTmp isolation) ([063c0f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/063c0f8fddd5e7b83921f1b523fdeef46631d910))
* **seeder:** raise MemoryMax to 2G (4 workers × 300-400MB polars DataFrames) ([14775f3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/14775f3d8f67e3e872c198ec697cf0f41a44341e))
* **seeder:** resilient staging merge — skip corrupt days instead of aborting month ([f8eb374](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8eb374150ef8baacdb31d42aba1286876f5cc81))
* **seeder:** use httpx for Vision downloads (add as dependency) ([df2ab4e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/df2ab4eb4e758a8b0977699047561d5d042a3ab2))
* **seeder:** use requests instead of httpx for Vision downloads (requests in venv) ([ea5bb40](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ea5bb40fd74db51c4d1d468ab66a7ea34f411cbf))
* **storage:** convert us Int64 timestamps to ms in write_ticks ([bbb1545](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bbb154583c9c8effac87cdad588395a7dfec5213))
* **storage:** use diagonal_relaxed in lazy concat to tolerate schema drift (column_8) ([44d1c09](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44d1c0978e6b86dbf5a262d94a3f10d126954a21))
* **systemd:** remove LimitNPROC=4096 from all service templates ([9bdb1e1](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bdb1e119e6655007581091ae08ec64b9e1fc5a7)), closes [#107](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/107)


### Features

* **audit:** Task 9 cross-cutting synthesis - hardcoded values resolution strategy ([19e70d0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/19e70d0a65e2d1702c68eea2c2af297ea2dd6f98))
* **cache:** multi-threshold single-Parquet-read fast path + populate_range script ([9bf5dd2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bf5dd2d79646e253fd5fa41ac961d101a27c6d8))
* **docs:** add symbol registry implementation plan ([4454b0e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4454b0e8e8b238fc14e6d466eb5715e615f16c3e))
* implement quick-win fixes for symbol registry integration ([21a3d08](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/21a3d088f5861ad61a68e40c22256743a6e9df4c))
* **kintsugi:** add Parquet-first data source priority (local cache > Vision > REST) ([ffebf2e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ffebf2e2621b014673e5e916917d4339ea4fc15c))
* **seeder:** proactive Parquet tick cache seeder for bigblack (Issue [#270](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/270)) ([302717d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/302717d7c7f6305a7c669302a3e701f0dc0785bc))


### Performance Improvements

* **kintsugi:** increase batch_days from 60 to 3650 for single-pass gap closure ([e2db49e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/e2db49e0b0e8f61c378b78aabfb37e1299836445))
* **kintsugi:** raise MAX_CONCURRENT_REPAIRS 8→24 based on empirical step-up profiling ([cd881ec](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cd881eca23fd5d24bf5b8158db4aa8494f318066))
* reuse thread-local ClickHouse connection in fatal_cache_write ([9efa17d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9efa17d6770d2feebd417106111aa5507c70d1f7))
* **seeder:** MEM-016 month-level batch writes — eliminate O(N²) file scan accumulation ([7353c5f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7353c5f2567f55acaf6cd6c199218dfa9ad5849c))
* **storage:** MEM-015 anti-join dedup — avoid is_in deprecation path (+1954 MB) ([32aac52](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32aac52cf5fddf24b0fff45e633e0b17d2bdbac7))
* **storage:** MEM-015 column projection in write_ticks() — 95.7% memory reduction ([8b07931](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8b0793133e72aa73eb9383b7910f7df6dbb4362e))
* **storage:** MEM-015 schema-normalize before sink_parquet to enable streaming engine ([ad3283e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ad3283e29b950e0e0a2106e6ff16da1d877e81b6))
* **storage:** MEM-015 streaming sink_parquet — bounded memory for write_ticks() ([3e1cd78](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3e1cd780a4d9edd1bb97b81ccc643941370c82c4))
* **storage:** MEM-015 two-source scan_parquet streaming — write new rows to temp file first ([40f8588](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/40f8588ffcb6636fa34f16df1e110b407488aec0))

## [13.16.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.16.0...v13.16.1) (2026-03-12)


### Bug Fixes

* restore BTCUSDT thresholds [250,500,750,1000] — focus mode complete ([7e5c653](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7e5c65398069c4271d1977a742ccc1cf1f74064a))
* **stathera:** exclude first-bar artifacts from gap count + active repair visibility ([4facb9f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/4facb9f074de649da6685fe7f5da5ac4fd861dee)), closes [#269](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/269)

# [13.16.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.4...v13.16.0) (2026-03-12)


### Features

* dynamic Parquet parallelism + peak resource tracking in heartbeat ([79d9512](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/79d9512396d133a82f619e27f1ab8c61f84e9fd0))
* increase max_concurrent_parquet to 64, unleash full 5115-shard backfill ([f19311e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f19311e184a3b179b0d91098a3f4ce309963878f))


### Performance Improvements

* eliminate Redis lock serialization bottleneck in kintsugi ([8f2b7aa](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8f2b7aac198bcaaf70b8aa1126329e35d498a3bf))
* tune MAX_CONCURRENT_REPAIRS=13 (Vision download safe) ([f6ecee9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f6ecee930465b2c42b9ac0cd9de4487c520f53a8))

## [13.15.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.3...v13.15.4) (2026-03-12)


### Bug Fixes

* kintsugi override false-positive UNHEALTHY + persist parallelism settings ([ea14a97](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ea14a97d75e565158d57be3b58f9527895331d6a))

## [13.15.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.2...v13.15.3) (2026-03-12)


### Bug Fixes

* resolve kintsugi connection pool exhaustion + schema.sql loading resilience ([#295](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/295), [#296](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/296)) ([d686a49](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d686a4906f0e04db496ac9d0dd64bc5b89c8524d))

## [13.15.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.1...v13.15.2) (2026-03-12)


### Bug Fixes

* **test:** update BTCUSDT threshold expectation to match registry focus mode ([3a20942](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3a20942b43c97ac3fae9018865308338f22a299a))

## [13.15.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.15.0...v13.15.1) (2026-03-12)


### Bug Fixes

* **test:** update KintsugiResult ariadne_used→had_anchor_tid ([d9cb378](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d9cb37819dbfc506c0f59272b9c7f2ad93e31caf))

# [13.15.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.14.0...v13.15.0) (2026-03-12)


### Bug Fixes

* **kintsugi:** cast incomplete bar column types to match Arrow schema ([0092d26](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0092d26a8f14c6ac8b28242d3f5e8f4a11760f46))
* **kintsugi:** CLI max_repairs falls through to KintsugiConfig env var when unset ([5372dbb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5372dbb0a3b580856bbc2a62aee26686ebcfff7a))
* **kintsugi:** normalize incomplete bar schema to match Arrow frames ([900adad](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/900adadc1e6b62a8842f53a560ac0d4006ab81c8))
* **registry:** filter_pairs_by_registry checks thresholds, not just symbol enabled ([bd90565](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/bd905652359847e4d16956723256bf1c16416acb))


### Features

* **registry+kintsugi:** symbols.toml as SSoT (BTCUSDT@250 only); day-start-fill invariant ([#265](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/265)) ([5d5624f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d5624f8b74470065e2edbee0d492f28919c7dbb))

# [13.14.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.13.0...v13.14.0) (2026-03-11)


### Bug Fixes

* **config:** remove unnecessary lambda in default_factory ([82f2ba5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/82f2ba5e276776b69533506f70e9ed378fd9a104))
* **data-source:** enforce spot-only policy, remove structural gap concept ([89921f5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/89921f5d24fb7a0fd6e7f078c91a6f04877b86fc)), closes [#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264) [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)
* **monit:** remove kintsugi memory limit, revert workers to 4 ([5164126](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5164126bf819e4b43a1abf1a64331ff0b4da5470))
* restore _is_valid_parquet re-export removed by ruff auto-fix ([2c0f636](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2c0f636da76ad02a73e98f7b5d81e1a95b5c47b7))
* **stathera:** day_boundary_exclusion time-gap check + symbol registry gating ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([0f35ce2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/0f35ce28addc66bc64600268b78806906003149d))
* **stathera:** remove day_boundary_exclusion — all tid_delta > 0 are gaps ([26fae60](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/26fae60130d03b8249589ab457d90ec484f7b034))


### Features

* **config:** centralize 60+ hardcoded constants into pydantic-settings ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2dcc2c5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/2dcc2c59d503dc0ed872c4e1fc825e4b3f1e89f4))
* **kintsugi:** outer shard parallelism via ThreadPoolExecutor ([fe8571f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/fe8571f6ed3f78e7bb31a2134815dd03305a461b))
* **streaming:** Rust-native UTC midnight processor reset in LiveBarEngine ([47bf2c9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/47bf2c9f29d578d80e92f99aee29da8665a0749c)), closes [#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)

# [13.13.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.12.0...v13.13.0) (2026-03-11)


### Features

* **kintsugi:** parallel day repairs within batch via ThreadPoolExecutor ([db710a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db710a7352fcde1101600b3de57ddf0dbd0592a6))

# [13.12.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.2...v13.12.0) (2026-03-11)


### Features

* **kintsugi:** multi-day batch processing per shard repair ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2340338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/23403389334dc95b72a0bd79c9030d53223aac40))

## [13.11.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.1...v13.11.2) (2026-03-11)


### Bug Fixes

* improve sidecar_api log clarity — no more exc_info tracebacks for expected fallbacks ([9bb64c2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bb64c2feeb108a07dc03b72ee59ab66f86de318))
* invert cross_midnight health logic — healthy when kintsugi IS healing ([db591d3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db591d32d099e4eac30264e3303ebf10fe4bf8b5))
* pre-filter disabled symbols in sidecar gap-fill ([857659f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/857659fa75bf6f1b1e316c9b86b485c6eb9a84cd))

## [13.11.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.0...v13.11.1) (2026-03-11)


### Bug Fixes

* make symbol registry tests work with disabled symbols ([cb553d7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb553d79d51b0658403054980a8c82499cf5126b))

# [13.11.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.10.0...v13.11.0) (2026-03-11)


### Bug Fixes

* cross-midnight bars no longer clobber stathera_gaps health check ([5d05a14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d05a14a2b312ff410cb6ca06b006421ea553c09))
* day_boundary_exclusion() was hiding 172 real gaps from kintsugi ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([96c5c76](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/96c5c76a55a3df638b8c61773c6b2e77ded9023c))
* enforce symbol registry enabled gate in kintsugi, backfill, detect_gaps ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([a83689a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a83689a75bafd09cc51bf58e1eb4da2834334edc))
* heartbeat Telegram respects symbol registry + reduce lock noise ([0512827](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/05128276cb95beba7c8c8c4ffaa916cb5278a6d1))


### Features

* adaptive sleep in kintsugi daemon — skip idle time when shards remain ([441e7c6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/441e7c6c60057056f2077f5c6f2db7232460099f))

# [13.10.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.9.0...v13.10.0) (2026-03-11)


### Bug Fixes

* filter cross-midnight bars in streaming + dead-letter replay ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([ba02338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ba023386c8e46e26b9c133bedca48f7db2b082f8)), closes [hi#threshold](https://github.com-terrylica/hi/issues/threshold) [264/#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)


### Features

* add odb-telemetry skill for production monitoring and diagnostics ([264fed3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/264fed3a64fbfa13d5b5ccc0922b7880d473c366))

# [13.9.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.8.0...v13.9.0) (2026-03-11)


### Bug Fixes

* eliminate cross-midnight bar sources causing Sisyphean kintsugi cascade ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264), [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)) ([7bf3721](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7bf3721a521701b4fe37f4e1d1b41269e59462c6))


### Features

* **skill:** add auto-healing guards to odb-deploy-verification ([#261](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/261)) ([7469d31](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7469d31dd1036cb0b1011ce0385798d3bc7d73c2))

# [13.8.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.7.0...v13.8.0) (2026-03-10)


### Bug Fixes

* allow kintsugi to repair interior intra-day gaps ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([b26c343](https://github.com/terrylica/opendeviationbar-py/commit/b26c3433df3c7632a1f6baf7682e6a3c63d9fa27))
* **skill:** correct kintsugi_log column names in deploy verification ([df83aee](https://github.com/terrylica/opendeviationbar-py/commit/df83aeef6ce20bb4c08740d41f0ea14b9fc9d041))


### Features

* gap repair acceleration with Puck + Niffler (Issue [#257](https://github.com/terrylica/opendeviationbar-py/issues/257), [#158](https://github.com/terrylica/opendeviationbar-py/issues/158)) ([bf5b2e8](https://github.com/terrylica/opendeviationbar-py/commit/bf5b2e8b49316562fc8acdfa96dbab9b4bec5ac6))

# [13.7.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.6.6...v13.7.0) (2026-03-10)


### Bug Fixes

* prevent sidecar state loss on brief CH blips ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([bbb53b1](https://github.com/terrylica/opendeviationbar-py/commit/bbb53b14c87f178b043195bd190e837a02f94ac8)), closes [#198](https://github.com/terrylica/opendeviationbar-py/issues/198)


### Features

* add odb-deploy-verification skill (58-point checklist) ([848e46a](https://github.com/terrylica/opendeviationbar-py/commit/848e46afd1710c0b34934569284e45286564c47e))

## [13.6.6](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.5...v13.6.6) (2026-03-10)


### Bug Fixes

* resolve circular import in CLICKHOUSE_TRANSIENT_ERRORS ([25368b9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/25368b914c05ea484d2dfdfc64d3c79ffe42e1df))

## [13.6.5](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.4...v13.6.5) (2026-03-10)


### Bug Fixes

* sync workspace dep versions in semantic-release prepareCmd ([6998d47](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6998d470eab55810463322ecb4e8685335683440))

## [13.6.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.3...v13.6.4) (2026-03-10)


### Bug Fixes

* wire internal crate deps to workspace SSoT via inheritance ([c46d8bd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c46d8bd327044e9ac70fee3c7a01e8117ecfba1f))

## [13.6.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.2...v13.6.3) (2026-03-10)


### Bug Fixes

* add take_gap_event_watcher mock to all sidecar watchdog tests ([32580cd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32580cdea482f69d1a000a22d9bedd616bee6000))

## [13.6.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.1...v13.6.2) (2026-03-10)


### Bug Fixes

* mock take_gap_event_watcher in watchdog test to prevent JSON serialization error ([a89d488](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a89d4882c72864d9f70a40d1daffd99905ae8fcc))

## [13.6.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.0...v13.6.1) (2026-03-10)


### Bug Fixes

* test default watchdog timeout (600s, not 300s) ([cb47d6c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb47d6c9ebb2f37b6784c85d3946709a2073790e))

# [13.6.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.1...v13.6.0) (2026-03-10)


### Bug Fixes

* **#257 phase 0a:** rate limiter CAS loop, fetch_max, Spot weight=4 for aggTrades ([abac1f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/abac1f8dc7abaa9d64f804a6acc25fd4fe4c0492)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#259:** critical row-index bug in kintsugi, dangling forex test imports ([c9972a5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9972a5cdca5204a958e1cbe61de55380ba6ec76)), closes [#259](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/259)
* **heartbeat+kintsugi:** day-boundary gap classification, today-guard sentinel, human-readable Telegram ([1294131](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/12941312b36e2aca9d3e10c311c87969e9849898))
* pre-release formatting and config test fixes ([95ff444](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/95ff444b62f03e8fa47a09f6356786fb68ee2d37))
* use loguru instead of warnings.warn for invalid TELEGRAM_LOG_LEVEL ([5b25f8e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5b25f8e554b13a7571cb6e087300912abe4de0fa))
* validate FLUSH_THRESHOLD env var + add bounded flush tests ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([a06e086](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a06e08649f5a082046be3dc8732e97f8c86eccf2))


### Features

* **#257 phase 1:** SSE gap_detected event broadcast in sidecar ([acb0d0d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/acb0d0d787d07fa08248080c52ac83aafd02b5e6)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phase 2a:** parallel aggTrades fetcher with JoinSet+Semaphore ([78bb30d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/78bb30dd9776db370dcdd611a79c3f8d79ddb9fb)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1-2a:** gap detection submodule (event, command, detector) ([f8404a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8404a7f65778ade75f1fb7bc3d42f522deabf29)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1,2c:** PyO3 gap bindings (PyGapEventWatcher, fill_gap) ([7080d2a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7080d2ad808af2f7223da132e97e21ab849d6b71)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 2-2c:** live engine gap detection + command channel fill_gap() ([b4f9041](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b4f9041c8d0de1728a01a00ee72876b9c8cd4951)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* bounded ClickHouse INSERT — flush every 10K bars during day processing ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([44f4f54](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44f4f54cb1a8ad99db71705d20b853c6ddfa97c6)), closes [hi#volume](https://github.com-terrylica/hi/issues/volume)

## [13.5.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.0...v13.5.1) (2026-03-09)


### Bug Fixes

* **release:** fetch and reconcile with remote in preflight ([04aedeb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/04aedeb7ea8284c482914bb21813353b11da4c5b))

# [13.5.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.4.0...v13.5.0) (2026-03-09)


### Features

* add ClickHouse password auth support ([#201](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/201)) ([8a70953](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a70953ddff20f8b2e52bef5493f3d283debbd42))
* add OPENDEVIATIONBAR_TELEGRAM_LOG_LEVEL env var ([#243](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/243)) ([9595fa4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9595fa433b6c7663a284fca3bea2f48c98e7aa22))
* **monit:** detailed Telegram health reports with UUID and LOUD failure alerts ([87e20e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/87e20e0e9e16de4b127a3675c88deede6bfd4509))

# [13.4.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.3.0...v13.4.0) (2026-03-09)


### Bug Fixes

* **clickhouse:** crash-safe replace with overlapping DELETE predicate ([9b343b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9b343b493c808623953eb46fb6f4340e98194c20))
* **kintsugi:** cap day-recompute to one day per pass in day-mode Ouroboros ([be30451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/be304519217e81e39e61c9a4cf86826f6b0c639f))
* **vision:** cache ALL failures in Redis negative cache, not just 404s ([51d2d84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51d2d847c4db37a938103d9b6e8f9e1e7b6d2a67))


### Features

* **heartbeat:** deterministic hotfix detection via mtime comparison ([31984ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31984aedb606e41eb0c6d40291541449ce17bce9))
* **kintsugi:** Vision-first data source priority for day-recompute ([d4eaae0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4eaae01e42788030ae7cb27e09bf0767872e973))

# [13.3.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.2.0...v13.3.0) (2026-03-09)


### Features

* **issue-256:** add write-time registry gate to ClickHouse layer ([969af12](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/969af12f4c367981eecbd140f834e12faa6d4445))
* **monitoring:** add delta tracking to heartbeat for repair progress visibility ([3457e89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457e89ebc33f98efb98f125fc8fea7a202a85c0))
