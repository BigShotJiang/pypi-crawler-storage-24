from typing import Any
from typing import Dict
from typing import Type


class Singleton:
    _instances: Dict[Type, Any] = {}

    def __new__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__new__(cls)
        return cls._instances[cls]

    def __init__(self):
        if not hasattr(self, '_initialized'):
            self._initialized = True
            self._init_once()

    def _init_once(self):
        pass
