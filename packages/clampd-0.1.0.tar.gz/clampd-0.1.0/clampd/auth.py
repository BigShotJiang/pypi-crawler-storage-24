"""JWT helper for Clampd agent authentication."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def make_agent_jwt(
    agent_id: str,
    *,
    secret: str | None = None,
    scopes: list[str] | None = None,
    ttl_seconds: int = 3600,
) -> str:
    """Create a JWT with ``sub`` = *agent_id*.

    Uses HMAC-SHA256 when *secret* or ``CLAMPD_JWT_SECRET`` env var is set.
    Falls back to unsigned ``alg: none`` for dev/demo.
    """
    signing_key = secret or os.environ.get("CLAMPD_JWT_SECRET", "")
    now = int(time.time())

    payload_dict: dict = {
        "sub": agent_id,
        "iss": "clampd-sdk",
        "iat": now,
        "exp": now + ttl_seconds,
    }
    if scopes:
        payload_dict["scopes"] = scopes

    if signing_key:
        header = _b64url(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
        payload = _b64url(json.dumps(payload_dict, separators=(",", ":")).encode())
        signing_input = f"{header}.{payload}".encode()
        signature = _b64url(
            hmac.new(signing_key.encode(), signing_input, hashlib.sha256).digest()
        )
        return f"{header}.{payload}.{signature}"

    import warnings
    warnings.warn(
        "[clampd] Creating unsigned JWT (alg: none). "
        "Set CLAMPD_JWT_SECRET or pass secret= to enable HMAC-SHA256 signing. "
        "Unsigned tokens are rejected by gateways with JWT_SECRET configured.",
        stacklevel=2,
    )
    header = _b64url(json.dumps({"alg": "none", "typ": "JWT"}).encode())
    payload = _b64url(json.dumps(payload_dict).encode())
    return f"{header}.{payload}.nosig"
