"""Clampd MCP Proxy Server -- intercepts all tool calls through the 9-stage pipeline.

Architecture:

    LLM Client --> Clampd MCP Proxy --> [9-stage pipeline] --> Real MCP Tool Server

The proxy connects to one or more downstream MCP servers, discovers their tools,
and exposes them to the upstream LLM client. Every tool invocation is routed
through the Clampd gateway for security classification, policy evaluation,
scope enforcement, and audit logging before the call reaches the real tool.

Usage (CLI)::

    python -m clampd.mcp_server \\
        --downstream "npx -y @modelcontextprotocol/server-filesystem /tmp" \\
        --agent-id "b0000000-0000-0000-0000-000000000001" \\
        --gateway http://localhost:8080

Usage (Claude Desktop config)::

    {
      "mcpServers": {
        "filesystem-guarded": {
          "command": "python",
          "args": ["-m", "clampd.mcp_server",
                   "--downstream", "npx -y @modelcontextprotocol/server-filesystem /tmp",
                   "--agent-id", "b0000000-0000-0000-0000-000000000001",
                   "--gateway", "http://localhost:8080"]
        }
      }
    }
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import shlex
import sys
from typing import Any, Sequence

from clampd.client import ClampdClient, ProxyResponse

# ---------------------------------------------------------------------------
# Lazy import for the ``mcp`` package -- give a friendly error if missing.
# ---------------------------------------------------------------------------

_MCP_INSTALL_HINT = (
    "The 'mcp' package is required for the Clampd MCP proxy server.\n"
    "Install it with:  pip install 'clampd[mcp]'"
)


def _import_mcp():
    """Import and return MCP SDK modules, raising a clear error if absent."""
    try:
        from mcp.server import Server  # noqa: F811
        from mcp.server.stdio import stdio_server  # noqa: F811
        from mcp.types import (  # noqa: F811
            CallToolResult,
            ImageContent,
            TextContent,
            Tool,
        )
        from mcp.client.stdio import StdioServerParameters, stdio_client  # noqa: F811
        from mcp.client.session import ClientSession  # noqa: F811
    except ImportError as exc:
        raise ImportError(_MCP_INSTALL_HINT) from exc

    return {
        "Server": Server,
        "stdio_server": stdio_server,
        "CallToolResult": CallToolResult,
        "ImageContent": ImageContent,
        "TextContent": TextContent,
        "Tool": Tool,
        "StdioServerParameters": StdioServerParameters,
        "stdio_client": stdio_client,
        "ClientSession": ClientSession,
    }


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logger = logging.getLogger("clampd.mcp_proxy")

# MCP servers communicate over stdio -- all diagnostic output goes to stderr
# so it never corrupts the JSON-RPC stream.
_LOG_HANDLER = logging.StreamHandler(sys.stderr)
_LOG_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s")
)
logger.addHandler(_LOG_HANDLER)


# ---------------------------------------------------------------------------
# ClampdMCPProxy
# ---------------------------------------------------------------------------


class ClampdMCPProxy:
    """Proxy MCP server that interposes the Clampd 9-stage security pipeline
    between an LLM client and a real (downstream) MCP tool server.

    Parameters
    ----------
    gateway_url:
        Base URL of the Clampd ag-gateway (e.g. ``http://localhost:8080``).
    agent_id:
        UUID of the Clampd-registered agent identity.
    api_key:
        API key for the Clampd gateway (``X-AG-Key`` header).
    downstream_command:
        Shell command (or executable) to spawn the downstream MCP server.
        Examples: ``"npx -y @modelcontextprotocol/server-filesystem /tmp"``,
        ``"python -m some_mcp_server"``.
    downstream_args:
        Optional extra arguments appended to *downstream_command* when it is
        provided as a single token.  If *downstream_command* already contains
        spaces it is shell-parsed with :func:`shlex.split`.
    downstream_env:
        Optional environment variable overrides passed to the subprocess.
    dry_run:
        When ``True``, the proxy calls ``/v1/verify`` (stages 1-6 only)
        instead of ``/v1/proxy``.  The tool call is **never** forwarded to
        the downstream server -- useful for policy testing.
    timeout:
        HTTP timeout (seconds) for Clampd gateway requests.
    """

    def __init__(
        self,
        *,
        gateway_url: str = "http://localhost:8080",
        agent_id: str,
        api_key: str = "clmpd_demo_key",
        downstream_command: str,
        downstream_args: Sequence[str] | None = None,
        downstream_env: dict[str, str] | None = None,
        dry_run: bool = False,
        timeout: float = 30.0,
    ) -> None:
        self.gateway_url = gateway_url.rstrip("/")
        self.agent_id = agent_id
        self.api_key = api_key
        self.dry_run = dry_run
        self.timeout = timeout

        # Parse the downstream command into (executable, args).
        parts = shlex.split(downstream_command)
        if downstream_args:
            parts.extend(downstream_args)
        if not parts:
            raise ValueError("downstream_command must not be empty")
        self._downstream_cmd = parts[0]
        self._downstream_args = parts[1:]
        self._downstream_env = downstream_env

        # Populated after _discover_tools().
        self._downstream_tools: list[Any] = []

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_clampd_client(self) -> ClampdClient:
        """Create a fresh synchronous ClampdClient."""
        return ClampdClient(
            gateway_url=self.gateway_url,
            agent_id=self.agent_id,
            api_key=self.api_key,
            timeout=self.timeout,
        )

    def _check_with_clampd(
        self,
        clampd: ClampdClient,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> ProxyResponse:
        """Route a tool call through the Clampd gateway.

        In normal mode this calls ``/v1/proxy``; in dry-run mode it calls
        ``/v1/verify`` (stages 1-6 only, no forwarding).

        The *target_url* is set to ``mcp://downstream`` as a passthrough
        marker -- actual forwarding to the downstream server is handled by
        this proxy, not by the gateway.
        """
        target_url = "mcp://downstream"
        if self.dry_run:
            return clampd.verify(
                tool=tool_name,
                params=arguments,
                target_url=target_url,
            )
        return clampd.proxy(
            tool=tool_name,
            params=arguments,
            target_url=target_url,
            prompt_context=f"MCP tool call: {tool_name}",
        )

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Start the proxy.

        1. Connect to the downstream MCP server via stdio subprocess.
        2. Discover its tools.
        3. Start our own MCP server on stdio, mirroring those tools.
        4. Intercept every ``call_tool`` through the Clampd pipeline.
        """
        mcp = _import_mcp()

        Server = mcp["Server"]
        stdio_server = mcp["stdio_server"]
        CallToolResult = mcp["CallToolResult"]
        TextContent = mcp["TextContent"]
        ImageContent = mcp["ImageContent"]
        Tool = mcp["Tool"]
        StdioServerParameters = mcp["StdioServerParameters"]
        stdio_client = mcp["stdio_client"]
        ClientSession = mcp["ClientSession"]

        # ---- 1. Connect to downstream ---------------------------------

        downstream_params = StdioServerParameters(
            command=self._downstream_cmd,
            args=self._downstream_args,
            env={**os.environ, **(self._downstream_env or {})},
        )

        logger.info(
            "Connecting to downstream MCP server: %s %s",
            self._downstream_cmd,
            " ".join(self._downstream_args),
        )

        async with stdio_client(downstream_params) as (ds_read, ds_write):
            async with ClientSession(ds_read, ds_write) as downstream:
                await downstream.initialize()

                # ---- 2. Discover tools --------------------------------

                tools_response = await downstream.list_tools()
                self._downstream_tools = tools_response.tools
                logger.info(
                    "Discovered %d tool(s) from downstream: %s",
                    len(self._downstream_tools),
                    ", ".join(t.name for t in self._downstream_tools),
                )

                if not self._downstream_tools:
                    logger.warning(
                        "Downstream server exposed zero tools -- the proxy "
                        "will start but has nothing to serve."
                    )

                # ---- 3. Build the proxy server ------------------------

                # Keep a reference so handlers can close-over it.
                _downstream = downstream
                _tools = self._downstream_tools
                _proxy = self  # capture for closures

                server = Server("clampd-proxy")

                @server.list_tools()
                async def handle_list_tools() -> list[Tool]:
                    """Return the same tool list the downstream exposes."""
                    return [
                        Tool(
                            name=t.name,
                            description=_make_guarded_description(t.description),
                            inputSchema=t.inputSchema,
                        )
                        for t in _tools
                    ]

                @server.call_tool()
                async def handle_call_tool(
                    name: str, arguments: dict[str, Any] | None
                ) -> list[Any]:
                    """Intercept tool call, run Clampd pipeline, optionally forward."""
                    arguments = arguments or {}
                    logger.info(
                        "Intercepted tool call: %s(%s)",
                        name,
                        _truncate_json(arguments),
                    )

                    # -- Clampd check (sync client, run in thread) ------
                    clampd_client = _proxy._make_clampd_client()
                    try:
                        result = await asyncio.to_thread(
                            _proxy._check_with_clampd,
                            clampd_client,
                            name,
                            arguments,
                        )
                    finally:
                        clampd_client.close()

                    logger.info(
                        "Clampd decision for %s: allowed=%s risk=%.2f latency=%dms%s",
                        name,
                        result.allowed,
                        result.risk_score,
                        result.latency_ms,
                        f" denied={result.denial_reason}" if not result.allowed else "",
                    )

                    # -- Blocked ----------------------------------------
                    if not result.allowed:
                        denial = _format_denial(name, result)
                        return [TextContent(type="text", text=denial)]

                    # -- Dry-run: allowed but do not forward -------------
                    if _proxy.dry_run:
                        msg = (
                            f"[clampd dry-run] Tool '{name}' ALLOWED "
                            f"(risk={result.risk_score:.2f}, "
                            f"scope={result.scope_granted}). "
                            f"Call was NOT forwarded to the downstream server."
                        )
                        return [TextContent(type="text", text=msg)]

                    # -- Forward to downstream --------------------------
                    try:
                        ds_result = await _downstream.call_tool(name, arguments)
                    except Exception as exc:
                        logger.error(
                            "Downstream call_tool(%s) failed: %s", name, exc
                        )
                        return [
                            TextContent(
                                type="text",
                                text=f"[clampd] Downstream tool error: {exc}",
                            )
                        ]

                    # Pass through all content items (text, image, etc.)
                    return _normalise_downstream_content(
                        ds_result, TextContent, ImageContent
                    )

                # ---- 4. Serve on stdio --------------------------------

                mode_label = "DRY-RUN" if self.dry_run else "LIVE"
                logger.info(
                    "Clampd MCP proxy ready [%s] -- serving %d tool(s) "
                    "via gateway %s for agent %s",
                    mode_label,
                    len(_tools),
                    self.gateway_url,
                    self.agent_id,
                )

                async with stdio_server() as (read, write):
                    init_options = server.create_initialization_options()
                    await server.run(read, write, init_options)


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def _make_guarded_description(original: str | None) -> str:
    """Prepend a security notice to the tool description."""
    prefix = "[Guarded by Clampd]"
    if original:
        return f"{prefix} {original}"
    return prefix


def _truncate_json(obj: Any, limit: int = 200) -> str:
    """Return a JSON string truncated to *limit* characters for logging."""
    try:
        raw = json.dumps(obj, default=str)
    except (TypeError, ValueError):
        raw = str(obj)
    if len(raw) > limit:
        return raw[:limit] + "..."
    return raw


def _format_denial(tool_name: str, result: ProxyResponse) -> str:
    """Build a human-readable denial message."""
    parts = [
        f"[clampd] Tool call '{tool_name}' was BLOCKED.",
        f"Reason: {result.denial_reason or 'policy violation'}",
        f"Risk score: {result.risk_score:.2f}",
        f"Request ID: {result.request_id}",
    ]
    if result.session_flags:
        parts.append(f"Session flags: {', '.join(result.session_flags)}")
    if result.degraded_stages:
        parts.append(f"Degraded stages: {', '.join(result.degraded_stages)}")
    return "\n".join(parts)


def _normalise_downstream_content(ds_result: Any, TextContent: type, ImageContent: type) -> list[Any]:
    """Extract content items from a downstream CallToolResult.

    The MCP SDK returns a ``CallToolResult`` whose ``.content`` is a list of
    typed content objects (``TextContent``, ``ImageContent``, etc.).  We pass
    them through unchanged so the upstream client sees exactly what the
    downstream produced.
    """
    contents: list[Any] = []
    if ds_result is None:
        return [TextContent(type="text", text="[clampd] Tool returned no content.")]

    # CallToolResult has a .content list
    raw_content = getattr(ds_result, "content", None)
    if raw_content is None:
        # Fallback: treat the whole thing as text
        return [TextContent(type="text", text=str(ds_result))]

    for item in raw_content:
        item_type = getattr(item, "type", None)
        if item_type == "text":
            contents.append(TextContent(type="text", text=item.text))
        elif item_type == "image":
            contents.append(
                ImageContent(
                    type="image",
                    data=item.data,
                    mimeType=item.mimeType,
                )
            )
        else:
            # Unknown content type -- serialize to text
            try:
                serialized = item.model_dump_json() if hasattr(item, "model_dump_json") else str(item)
            except Exception:
                serialized = str(item)
            contents.append(TextContent(type="text", text=serialized))

    if not contents:
        contents.append(TextContent(type="text", text="[clampd] Tool returned empty content."))

    return contents


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="clampd.mcp_server",
        description=(
            "Clampd MCP Proxy Server -- routes all MCP tool calls through "
            "the Clampd 9-stage security pipeline."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python -m clampd.mcp_server \\\n"
            '    --downstream "npx -y @modelcontextprotocol/server-filesystem /tmp" \\\n'
            '    --agent-id "b0000000-0000-0000-0000-000000000001" \\\n'
            "    --gateway http://localhost:8080\n"
            "\n"
            "  # Dry-run mode (stages 1-6 only, no forwarding):\n"
            "  python -m clampd.mcp_server \\\n"
            '    --downstream "npx -y @modelcontextprotocol/server-filesystem /tmp" \\\n'
            '    --agent-id "b0000000-0000-0000-0000-000000000001" \\\n'
            "    --gateway http://localhost:8080 \\\n"
            "    --dry-run\n"
        ),
    )

    parser.add_argument(
        "--downstream",
        required=True,
        help=(
            "Shell command to spawn the downstream MCP server. "
            'Example: "npx -y @modelcontextprotocol/server-filesystem /tmp"'
        ),
    )
    parser.add_argument(
        "--agent-id",
        required=True,
        help="Clampd agent UUID.",
    )
    parser.add_argument(
        "--gateway",
        default="http://localhost:8080",
        help="Clampd gateway URL (default: http://localhost:8080).",
    )
    parser.add_argument(
        "--api-key",
        default="clmpd_demo_key",
        help="Clampd API key (default: clmpd_demo_key).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help=(
            "Run in dry-run mode: call /v1/verify (stages 1-6) instead of "
            "/v1/proxy. The tool call is never forwarded to the downstream "
            "server."
        ),
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        help="HTTP timeout in seconds for gateway requests (default: 30).",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=False,
        help="Enable debug logging.",
    )

    return parser


def main(argv: Sequence[str] | None = None) -> None:
    """CLI entry point for ``python -m clampd.mcp_server``."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.verbose:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    proxy = ClampdMCPProxy(
        gateway_url=args.gateway,
        agent_id=args.agent_id,
        api_key=args.api_key,
        downstream_command=args.downstream,
        dry_run=args.dry_run,
        timeout=args.timeout,
    )

    try:
        asyncio.run(proxy.run())
    except KeyboardInterrupt:
        logger.info("Shutting down Clampd MCP proxy.")


if __name__ == "__main__":
    main()
