# bluefox-cli

Scaffolding tool for the [Bluefox Stack](https://bluefox-stack.bluefox.software). One command to generate a complete, ready-to-run FastAPI project with auth, Postgres, and Redis.

```bash
uv tool install bluefox-cli
bluefox init myapp
cd myapp
bfx db migrate initial
bfx dev
```

`bfx dev` starts Postgres, Redis, runs migrations, and launches the app with hot reload. Zero manual setup.

## What it generates

A complete project with:

- **FastAPI app** using `bluefox-core` settings and app factory
- **Authentication** via `bluefox-auth` — JWT tokens, cookie sessions, user management
- **SQLAlchemy models** inheriting `BluefoxBase`
- **Alembic migrations** configured with `configure_alembic()`
- **Docker Compose** for production (dokploy-network) and dev (local Postgres + Redis)
- **Multi-stage Dockerfile** with uv
- **Test suite** with `bluefox-test` fixtures and a health check smoke test
- **Makefile** with `dev`, `test`, `migrate`, and `run` targets
- **Environment files** with all `BluefoxSettings` variables

## Install

```bash
uv tool install bluefox-cli
```

This makes `bluefox` (and the `bfx` alias) available globally.

## Usage

```bash
bluefox init myapp
```

No interactive prompts, no config files — just one command to scaffold. Then use `bfx dev` and `bfx db migrate` to develop.

## Next steps

- [Getting started](getting-started.md) — walkthrough of your first project
- [Generated files](reference/generated-files.md) — what each file does
- [CLI commands](reference/cli-commands.md) — `bfx dev`, `bfx db migrate`
- [Makefile targets](reference/makefile-targets.md) — alternative make commands
