# Makefile targets

The generated Makefile provides all the commands you need for daily development.

## dev

```bash
make dev
```

Starts the full development stack via Docker Compose:

1. Postgres 17 container starts and waits for health check
2. Redis 7 container starts and waits for health check
3. Migrate service runs `alembic upgrade head`
4. App starts with `uvicorn --reload`

All services use the dev compose overlay, so everything runs locally with no external dependencies.

## dev-down

```bash
make dev-down
```

Stops and removes all dev containers. Postgres data is preserved in the `pgdata` volume.

## run

```bash
make run
```

Runs the app directly with uvicorn (no Docker). Useful when you have Postgres running separately. Uses the `DB_URL` variable from the Makefile.

## migrate

```bash
make migrate
```

Applies all pending Alembic migrations against the local database.

## migrate-make

```bash
make migrate-make name=add_users_table
```

Generates a new Alembic migration by comparing your models against the current database schema. The `name` parameter is required and becomes part of the migration filename.

## test

```bash
make test
```

Runs the test suite with pytest. Tests use bluefox-test which automatically starts a Postgres container via testcontainers — no local database needed.
