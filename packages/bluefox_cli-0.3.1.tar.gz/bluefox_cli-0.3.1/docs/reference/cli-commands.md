# CLI commands

The `bfx` command (alias for `bluefox`) provides the primary workflow for Bluefox projects.

## init

```bash
bfx init <project_name>
```

Scaffolds a new Bluefox project. Creates the project directory, writes all template files, and installs dependencies via `uv`.

## dev

```bash
bfx dev
```

Starts the full development stack via Docker Compose:

1. Postgres 17 container starts and waits for health check
2. Redis 7 container starts and waits for health check
3. Migrate service runs `alembic upgrade head`
4. App starts with `uvicorn --reload`

Must be run from inside a Bluefox project directory (one containing `docker-compose.dev.yml`).

## db migrate

```bash
bfx db migrate <name>
```

Generates a new Alembic migration by comparing your models against the database schema:

1. Starts a temporary Postgres container via Docker Compose
2. Waits for it to become healthy
3. Runs `alembic revision --autogenerate -m <name>`
4. Stops the temporary container

The migration file is written to `migrations/versions/`. The next time you run `bfx dev`, it will be applied automatically.

### Example

```bash
# After creating a new project
bfx db migrate initial

# After adding a new model
bfx db migrate add_orders_table
```
