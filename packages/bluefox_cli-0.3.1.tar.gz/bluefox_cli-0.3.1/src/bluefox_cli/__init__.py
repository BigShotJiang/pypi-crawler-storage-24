"""Bluefox CLI — scaffolding tool for the Bluefox Stack."""

__version__ = "0.1.1"
