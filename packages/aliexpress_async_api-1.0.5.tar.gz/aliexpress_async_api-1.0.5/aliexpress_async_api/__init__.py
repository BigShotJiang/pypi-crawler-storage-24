"""AliExpress Async API - Async SDK for AliExpress Open Platform"""

__version__ = "1.0.5"
__author__ = "GitHub Copilot"
__license__ = "MIT"

from .auth import AliExpressAuth
from .client import AliExpressIOPClient
from .endpoints.affiliates import AffiliatesEndpoint
from .endpoints.auth import AuthEndpoint
from .endpoints.business import BusinessEndpoint
from .endpoints.categories import CategoriesEndpoint
from .endpoints.orders import OrdersEndpoint
from .endpoints.products import ProductsEndpoint
from .endpoints.shipping import ShippingEndpoint
from .exceptions import (
    AliExpressException,
    APIRequestException,
    InvalidCredentialsException,
    ProductNotFoundException,
)
from .models import (
    AffiliateLink,
    Category,
    Order,
    Product,
    ProductSearchResponse,
    PromoInfo,
    ShippingInfo,
    SKUInfo,
    TokenResponse,
)
from .utils.logging import log_request, setup_logging
from .utils.rate_limiter import RateLimiter, rate_limit
from .utils.retry import RetryPolicy, retry
from .utils.webhooks import WebhookEvent, WebhookManager, WebhookPayload

# Backward compatibility alias
AliExpressClient = AliExpressIOPClient

__all__ = [
    "__version__",
    "AliExpressIOPClient",
    "AliExpressClient",
    "AliExpressAuth",
    "AffiliatesEndpoint",
    "AuthEndpoint",
    "BusinessEndpoint",
    "CategoriesEndpoint",
    "OrdersEndpoint",
    "ProductsEndpoint",
    "ShippingEndpoint",
    "Product",
    "AffiliateLink",
    "ProductSearchResponse",
    "TokenResponse",
    "Category",
    "PromoInfo",
    "ShippingInfo",
    "SKUInfo",
    "Order",
    "AliExpressException",
    "InvalidCredentialsException",
    "ProductNotFoundException",
    "APIRequestException",
    "RateLimiter",
    "rate_limit",
    "RetryPolicy",
    "retry",
    "log_request",
    "setup_logging",
    "WebhookManager",
    "WebhookEvent",
    "WebhookPayload",
]
