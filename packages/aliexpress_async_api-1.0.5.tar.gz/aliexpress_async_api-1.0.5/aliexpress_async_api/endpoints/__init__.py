from __future__ import annotations

"""Package initialization - endpoints module"""

__all__: list[str] = []
