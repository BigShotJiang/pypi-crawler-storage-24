from __future__ import annotations

"""Package initialization - utils module"""

__all__: list[str] = []
