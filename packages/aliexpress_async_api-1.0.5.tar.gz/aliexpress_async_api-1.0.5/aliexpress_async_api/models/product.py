"""Product-related models"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Product:
    """AliExpress affiliate product"""

    product_id: int
    product_title: str
    product_main_image_url: str
    sale_price: str
    original_price: str
    promotion_link: str
    shop_url: str | None = None
    evaluate_rate: str | None = None
    lastest_volume: int | None = None
    raw_data: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProductSearchResponse:
    """Response from product search/query endpoints"""

    products: list[Product]
    total_record_count: int
    current_record_count: int
    page_no: int
    raw_data: dict[str, Any] = field(default_factory=dict)
