"""Affiliate link models"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AffiliateLink:
    """Track able affiliate link"""

    promotion_link: str
    source_value: str
    raw_data: dict[str, Any] = field(default_factory=dict)
