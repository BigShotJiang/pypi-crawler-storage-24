"""
Tests for order endpoints - aliexpress_async_api.endpoints.orders
"""

from unittest.mock import AsyncMock

import pytest

from aliexpress_async_api.endpoints.orders import OrdersEndpoint
from aliexpress_async_api.models import Order

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ORDER_FIXTURE = {
    "order_id": 1001,
    "order_status": "Completed",
    "order_time": "2026-01-15 10:00:00",
    "estimated_commission": "1.50",
    "product_title": "Test Widget",
    "product_count": 2,
    "product_price": "29.99",
}


def _make_order_list_response(orders: list[dict] | None = None) -> dict:
    return {
        "aliexpress_affiliate_order_list_response": {
            "resp_result": {"result": {"orders": {"order": orders or []}}}
        }
    }


def _make_order_listbyindex_response(orders: list[dict] | None = None) -> dict:
    return {
        "aliexpress_affiliate_order_listbyindex_response": {
            "resp_result": {"result": {"orders": {"order": orders or []}}}
        }
    }


def _make_order_get_response(orders: list[dict] | None = None) -> dict:
    return {
        "aliexpress_affiliate_order_get_response": {
            "resp_result": {"result": {"orders": {"order": orders or []}}}
        }
    }


# ---------------------------------------------------------------------------
# Endpoint behaviour tests
# ---------------------------------------------------------------------------


class TestOrderEndpoints:
    """Order endpoint tests"""

    @pytest.mark.asyncio
    async def test_get_order_list_returns_list(self) -> None:
        """get_order_list returns a list of Order objects"""
        mock_request = AsyncMock(
            return_value=_make_order_list_response([_ORDER_FIXTURE])
        )
        endpoint = OrdersEndpoint(mock_request)

        result = await endpoint.get_order_list("2026-01-01", "2026-01-31")

        assert isinstance(result, list)
        assert len(result) == 1
        assert isinstance(result[0], Order)
        assert result[0].order_id == 1001

    @pytest.mark.asyncio
    async def test_get_order_list_with_date_range(self) -> None:
        """start_time and end_time are forwarded as business params"""
        mock_request = AsyncMock(return_value=_make_order_list_response())
        endpoint = OrdersEndpoint(mock_request)

        await endpoint.get_order_list("2026-03-01", "2026-03-31")

        _args, _kwargs = mock_request.call_args
        api_method, business_params = _args[0], _args[1]
        assert api_method == "aliexpress.affiliate.order.list"
        assert business_params["start_time"] == "2026-03-01"
        assert business_params["end_time"] == "2026-03-31"

    @pytest.mark.asyncio
    async def test_get_order_list_by_index(self) -> None:
        """get_order_list_by_index uses the listbyindex endpoint"""
        mock_request = AsyncMock(
            return_value=_make_order_listbyindex_response([_ORDER_FIXTURE])
        )
        endpoint = OrdersEndpoint(mock_request)

        result = await endpoint.get_order_list_by_index("0", "2026-01-01", "2026-01-31")

        assert isinstance(result, list)
        assert len(result) == 1
        _args, _kwargs = mock_request.call_args
        assert _args[0] == "aliexpress.affiliate.order.listbyindex"
        assert _args[1]["start_query_index_id"] == "0"

    @pytest.mark.asyncio
    async def test_get_order_info_by_ids(self) -> None:
        """get_order_info returns orders for the given IDs"""
        mock_request = AsyncMock(
            return_value=_make_order_get_response([_ORDER_FIXTURE])
        )
        endpoint = OrdersEndpoint(mock_request)

        result = await endpoint.get_order_info(["1001"])

        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0].order_id == 1001
        _args, _kwargs = mock_request.call_args
        assert _args[1]["order_ids"] == "1001"

    @pytest.mark.asyncio
    async def test_order_status_filtering(self) -> None:
        """status param is forwarded to the API call"""
        mock_request = AsyncMock(return_value=_make_order_list_response())
        endpoint = OrdersEndpoint(mock_request)

        await endpoint.get_order_list("2026-01-01", "2026-01-31", status="Pending")

        _args, _kwargs = mock_request.call_args
        assert _args[1]["status"] == "Pending"


# ---------------------------------------------------------------------------
# Response parsing tests (pure model construction)
# ---------------------------------------------------------------------------


class TestOrderResponseParsing:
    """Order response parsing tests"""

    def test_parse_order_response(self) -> None:
        """Order dataclass is populated correctly from raw dict"""
        order = Order(
            **{k: v for k, v in _ORDER_FIXTURE.items() if k in Order.__annotations__}
        )
        assert order.order_id == 1001
        assert order.order_status == "Completed"
        assert order.estimated_commission == "1.50"

    def test_handle_no_orders(self) -> None:
        """Empty order list returns [] without raising"""
        raw = _make_order_list_response(orders=[])
        orders_data = (
            raw["aliexpress_affiliate_order_list_response"]
            .get("resp_result", {})
            .get("result", {})
            .get("orders", {})
            .get("order", [])
        )
        assert orders_data == []

    def test_commission_amount_parsing(self) -> None:
        """estimated_commission is preserved as a string from the raw response"""
        order = Order(
            order_id=2002,
            order_status="Completed",
            order_time="2026-02-01 00:00:00",
            estimated_commission="3.75",
            product_title="Widget",
            product_count=1,
            product_price="14.99",
        )
        assert order.estimated_commission == "3.75"
