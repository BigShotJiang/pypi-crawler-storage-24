"""
Tests for product endpoints - aliexpress_async_api.endpoints.products
"""

from unittest.mock import AsyncMock

import pytest

from aliexpress_async_api.endpoints.products import ProductsEndpoint
from aliexpress_async_api.exceptions import ProductNotFoundException
from aliexpress_async_api.models import Product, ProductSearchResponse

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_PRODUCT_FIXTURE = {
    "product_id": 123,
    "product_title": "Test Shoes",
    "product_main_image_url": "https://img.example.com/shoes.jpg",
    "sale_price": "9.99",
    "original_price": "19.99",
    "promotion_link": "https://promo.example.com/shoes",
    "shop_url": "https://shop.example.com",
    "evaluate_rate": "98%",
    "lastest_volume": 500,
}


def _make_search_response(
    products: list[dict] | None = None, total: int = 1, current: int = 1
) -> dict:
    return {
        "aliexpress_affiliate_product_query_response": {
            "resp_result": {
                "result": {
                    "products": {"product": products or []},
                    "total_record_count": total,
                    "current_record_count": current,
                }
            }
        }
    }


def _make_smartmatch_response(
    products: list[dict] | None = None, total: int = 1, current: int = 1
) -> dict:
    return {
        "aliexpress_affiliate_product_smartmatch_response": {
            "resp_result": {
                "result": {
                    "products": {"product": products or []},
                    "total_record_count": total,
                    "current_record_count": current,
                }
            }
        }
    }


def _make_hotproducts_response(
    products: list[dict] | None = None, total: int = 1, current: int = 1
) -> dict:
    return {
        "aliexpress_affiliate_hotproduct_query_response": {
            "resp_result": {
                "result": {
                    "products": {"product": products or []},
                    "total_record_count": total,
                    "current_record_count": current,
                }
            }
        }
    }


# ---------------------------------------------------------------------------
# Endpoint behaviour tests
# ---------------------------------------------------------------------------


class TestProductEndpoints:
    """Product endpoint tests"""

    @pytest.mark.asyncio
    async def test_search_products_returns_product_search_response(self) -> None:
        """search_products wraps results in ProductSearchResponse"""
        mock_request = AsyncMock(
            return_value=_make_search_response([_PRODUCT_FIXTURE], total=1, current=1)
        )
        endpoint = ProductsEndpoint(mock_request)

        result = await endpoint.search_products("shoes")

        assert isinstance(result, ProductSearchResponse)
        assert len(result.products) == 1
        assert isinstance(result.products[0], Product)
        assert result.products[0].product_title == "Test Shoes"
        assert result.total_record_count == 1
        assert result.page_no == 1

    @pytest.mark.asyncio
    async def test_search_products_with_pagination(self) -> None:
        """page_no and page_size are forwarded to the API call"""
        mock_request = AsyncMock(return_value=_make_search_response())
        endpoint = ProductsEndpoint(mock_request)

        await endpoint.search_products("shoes", page_no=3, page_size=50)

        _args, kwargs = mock_request.call_args
        api_method, business_params = _args[0], _args[1]
        assert api_method == "aliexpress.affiliate.product.query"
        assert business_params["page_no"] == "3"
        assert business_params["page_size"] == "50"

    @pytest.mark.asyncio
    async def test_get_product_details_returns_list(self) -> None:
        """get_product_details returns a list of Product objects"""
        mock_request = AsyncMock(
            return_value={
                "aliexpress_affiliate_productdetail_get_response": {
                    "resp_result": {
                        "result": {"products": {"product": [_PRODUCT_FIXTURE]}}
                    }
                }
            }
        )
        endpoint = ProductsEndpoint(mock_request)

        result = await endpoint.get_product_details(["123"])

        assert isinstance(result, list)
        assert len(result) == 1
        assert isinstance(result[0], Product)
        assert result[0].product_id == 123

    @pytest.mark.asyncio
    async def test_get_product_details_raises_when_empty(self) -> None:
        """get_product_details raises ProductNotFoundException on empty list"""
        mock_request = AsyncMock(
            return_value={
                "aliexpress_affiliate_productdetail_get_response": {
                    "resp_result": {"result": {"products": {"product": []}}}
                }
            }
        )
        endpoint = ProductsEndpoint(mock_request)

        with pytest.raises(ProductNotFoundException):
            await endpoint.get_product_details(["999"])

    @pytest.mark.asyncio
    async def test_smart_match_products_with_keywords(self) -> None:
        """smart_match sends 'keywords' param and returns ProductSearchResponse"""
        mock_request = AsyncMock(
            return_value=_make_smartmatch_response([_PRODUCT_FIXTURE])
        )
        endpoint = ProductsEndpoint(mock_request)

        result = await endpoint.smart_match_products(keywords="sneakers")

        assert isinstance(result, ProductSearchResponse)
        assert len(result.products) == 1
        _args, _kwargs = mock_request.call_args
        assert _args[1].get("keywords") == "sneakers"

    @pytest.mark.asyncio
    async def test_smart_match_products_with_product_id(self) -> None:
        """smart_match sends 'product_id' param when provided"""
        mock_request = AsyncMock(
            return_value=_make_smartmatch_response([_PRODUCT_FIXTURE])
        )
        endpoint = ProductsEndpoint(mock_request)

        await endpoint.smart_match_products(product_id="123")

        _args, _kwargs = mock_request.call_args
        assert _args[1].get("product_id") == "123"
        assert "keywords" not in _args[1]

    @pytest.mark.asyncio
    async def test_get_hotproducts_returns_response(self) -> None:
        """get_hotproducts returns a ProductSearchResponse"""
        mock_request = AsyncMock(
            return_value=_make_hotproducts_response([_PRODUCT_FIXTURE], total=5)
        )
        endpoint = ProductsEndpoint(mock_request)

        result = await endpoint.get_hotproducts()

        assert isinstance(result, ProductSearchResponse)
        assert len(result.products) == 1
        assert result.total_record_count == 5


# ---------------------------------------------------------------------------
# Response-parsing tests (no I/O — pure model construction)
# ---------------------------------------------------------------------------


class TestResponseParsing:
    """Response parsing tests"""

    def test_product_search_response_parsing(self) -> None:
        """ProductSearchResponse stores counts and product list"""
        products = [
            Product(
                product_id=1,
                product_title="T-Shirt",
                product_main_image_url="https://img.example.com/t.jpg",
                sale_price="5.00",
                original_price="10.00",
                promotion_link="https://promo.example.com/t",
            )
        ]
        resp = ProductSearchResponse(
            products=products,
            total_record_count=100,
            current_record_count=20,
            page_no=2,
        )
        assert resp.total_record_count == 100
        assert resp.current_record_count == 20
        assert resp.page_no == 2
        assert len(resp.products) == 1

    def test_product_list_extraction(self) -> None:
        """Product list is correctly extracted from nested response dict"""
        raw = _make_search_response([_PRODUCT_FIXTURE])
        resp = raw["aliexpress_affiliate_product_query_response"]
        product_list = (
            resp.get("resp_result", {})
            .get("result", {})
            .get("products", {})
            .get("product", [])
        )
        assert len(product_list) == 1
        assert product_list[0]["product_title"] == "Test Shoes"

    def test_handle_empty_results(self) -> None:
        """Empty product list is handled without errors"""
        raw = _make_search_response(products=[], total=0, current=0)
        resp = raw["aliexpress_affiliate_product_query_response"]
        product_list = (
            resp.get("resp_result", {})
            .get("result", {})
            .get("products", {})
            .get("product", [])
        )
        assert product_list == []

    def test_handle_missing_optional_fields(self) -> None:
        """Product can be constructed without optional fields"""
        minimal = {
            "product_id": 42,
            "product_title": "Minimal",
            "product_main_image_url": "https://img.example.com/m.jpg",
            "sale_price": "1.00",
            "original_price": "2.00",
            "promotion_link": "https://promo.example.com/m",
        }
        p = Product(
            **{k: v for k, v in minimal.items() if k in Product.__annotations__}
        )
        assert p.shop_url is None
        assert p.evaluate_rate is None
        assert p.lastest_volume is None
