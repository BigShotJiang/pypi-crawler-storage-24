"""
Tapestry configuration system.

Loads config from tapestry.toml + .env for secrets.
Searches upward from CWD to find tapestry.toml.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


@dataclass
class LLMFallbackConfig:
    enabled: bool = False
    api_url: str = "http://localhost:11434/v1/chat/completions"
    model: str = "qwen3-4b-instruct"


@dataclass
class LLMConfig:
    provider: str = "groq"
    api_url: str = "https://api.groq.com/openai/v1/chat/completions"
    api_key: str = ""
    content_model: str = "openai/gpt-oss-120b"
    title_model: str = "openai/gpt-oss-120b"
    max_tokens_title: int | None = None
    max_tokens_content: int | None = None
    temperature: float = 0.3
    request_timeout: int = 60
    chunk_size_tokens: int = 20_000
    fallback: LLMFallbackConfig = field(default_factory=LLMFallbackConfig)


@dataclass
class AgentConfig:
    parser: str = "claude-code"
    conversations_dir: str = ""


@dataclass
class TapestryConfig:
    db_path: str = "db/tapestry.db"
    first_day_of_week: str = "monday"
    exclude_today: bool = True
    agent_name: str = "Assistant"
    user_name: str = "User"
    llm: LLMConfig = field(default_factory=LLMConfig)
    agents: dict[str, AgentConfig] = field(default_factory=dict)
    project_dir: str = ""  # Directory where tapestry.toml lives


def find_config_file(start_dir: str | None = None) -> Path | None:
    """Search upward from start_dir for tapestry.toml."""
    current = Path(start_dir) if start_dir else Path.cwd()
    for parent in [current, *current.parents]:
        candidate = parent / "tapestry.toml"
        if candidate.exists():
            return candidate
    return None


def load_config(config_path: str | None = None, **overrides: Any) -> TapestryConfig:
    """Load configuration from tapestry.toml and .env.

    Args:
        config_path: Explicit path to tapestry.toml. If None, searches upward from CWD.
        **overrides: Override any config value (e.g., db_path="custom.db").

    Returns:
        TapestryConfig with all values resolved.
    """
    config = TapestryConfig()

    # Find and load TOML
    if config_path:
        toml_path = Path(config_path)
    else:
        toml_path = find_config_file()

    if toml_path and toml_path.exists():
        config.project_dir = str(toml_path.parent)
        with open(toml_path, "rb") as f:
            data = tomllib.load(f)
        _apply_toml(config, data)
    else:
        config.project_dir = str(Path.cwd())

    # Load .env from project directory
    env_path = Path(config.project_dir) / ".env"
    if env_path.exists():
        load_dotenv(env_path)

    # Resolve API key from environment
    if not config.llm.api_key:
        config.llm.api_key = os.environ.get("TAPESTRY_API_KEY", "")

    # Resolve db_path relative to project directory
    if not Path(config.db_path).is_absolute():
        config.db_path = str(Path(config.project_dir) / config.db_path)

    # Apply overrides
    for key, value in overrides.items():
        if hasattr(config, key):
            setattr(config, key, value)

    # Ensure at least a default agent
    if not config.agents:
        config.agents["default"] = AgentConfig()

    return config


def _apply_toml(config: TapestryConfig, data: dict[str, Any]) -> None:
    """Apply TOML data to config object."""
    # [tapestry]
    tap = data.get("tapestry", {})
    if "db_path" in tap:
        config.db_path = tap["db_path"]

    # [llm]
    llm = data.get("llm", {})
    for key in ("provider", "api_url", "api_key", "content_model", "title_model",
                "temperature", "request_timeout", "max_tokens_title", "max_tokens_content",
                "chunk_size_tokens"):
        if key in llm:
            setattr(config.llm, key, llm[key])

    # [llm.fallback]
    fb = llm.get("fallback", {})
    for key in ("enabled", "api_url", "model"):
        if key in fb:
            setattr(config.llm.fallback, key, fb[key])

    # [defaults]
    defaults = data.get("defaults", {})
    for key in ("first_day_of_week", "exclude_today", "agent_name", "user_name"):
        if key in defaults:
            setattr(config, key, defaults[key])

    # [agents.*]
    agents = data.get("agents", {})
    for name, agent_data in agents.items():
        agent = AgentConfig()
        if "parser" in agent_data:
            agent.parser = agent_data["parser"]
        if "conversations_dir" in agent_data:
            agent.conversations_dir = agent_data["conversations_dir"]
        config.agents[name] = agent


def write_config(config: TapestryConfig, path: str | None = None) -> Path:
    """Write a tapestry.toml file from config. Returns the path written to."""
    out_path = Path(path) if path else Path(config.project_dir) / "tapestry.toml"

    lines = []
    lines.append("[tapestry]")
    # Store db_path as relative
    db_rel = config.db_path
    if Path(db_rel).is_absolute() and config.project_dir:
        try:
            db_rel = str(Path(db_rel).relative_to(config.project_dir))
        except ValueError:
            pass
    lines.append(f'db_path = "{db_rel}"')
    lines.append("")

    lines.append("[llm]")
    lines.append(f'provider = "{config.llm.provider}"')
    lines.append(f'api_url = "{config.llm.api_url}"')
    lines.append(f'content_model = "{config.llm.content_model}"')
    lines.append(f'title_model = "{config.llm.title_model}"')
    lines.append(f"temperature = {config.llm.temperature}")
    lines.append(f"chunk_size_tokens = {config.llm.chunk_size_tokens}")
    lines.append("")

    lines.append("[defaults]")
    lines.append(f'first_day_of_week = "{config.first_day_of_week}"')
    lines.append(f"exclude_today = {'true' if config.exclude_today else 'false'}")
    lines.append(f'agent_name = "{config.agent_name}"')
    lines.append(f'user_name = "{config.user_name}"')
    lines.append("")

    for name, agent in config.agents.items():
        lines.append(f"[agents.{name}]")
        lines.append(f'parser = "{agent.parser}"')
        if agent.conversations_dir:
            lines.append(f'conversations_dir = "{agent.conversations_dir}"')
        lines.append("")

    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path
