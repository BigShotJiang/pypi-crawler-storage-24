"""Hierarchy tree display for tapestry records."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def tree(db: Database, agent: str, agent_id: int) -> dict:
    """Build the full tapestry hierarchy tree.

    Walks monthlies -> weeklies -> dailies -> L0 counts. Also finds
    orphaned records (weeklies/dailies without a parent).

    Args:
        db: Database instance.
        agent: Agent name string.

    Returns:
        Dict with keys:
            monthlies: list of monthly dicts, each containing 'weeklies' list,
                       each containing 'dailies' list with l0_count.
            orphaned_weeklies: list of weekly dicts without parent.
            orphaned_dailies: list of daily dicts without parent.
    """
    # Get all monthlies
    monthlies = db.sql(
        """SELECT tap_id, tap_title, tap_date_start, tap_date_end,
                  LENGTH(tap_content) as content_len
           FROM tapestry
           WHERE tap_level = 3 AND tap_agent_id = ?
           ORDER BY tap_date_start""",
        (agent_id,),
    )

    result_monthlies = []
    for monthly in (monthlies or []):
        # Get weeklies for this monthly
        weeklies = db.sql(
            """SELECT tap_id, tap_title, tap_date_start, tap_date_end,
                      LENGTH(tap_content) as content_len
               FROM tapestry
               WHERE tap_level = 2 AND tap_parent_id = ?
               ORDER BY tap_date_start""",
            (monthly["tap_id"],),
        )

        result_weeklies = []
        for weekly in (weeklies or []):
            # Get dailies for this weekly
            dailies = db.sql(
                """SELECT tap_id, tap_title, tap_date,
                          LENGTH(tap_content) as content_len
                   FROM tapestry
                   WHERE tap_level = 1 AND tap_parent_id = ?
                   ORDER BY tap_date""",
                (weekly["tap_id"],),
            )

            result_dailies = []
            for daily in (dailies or []):
                # Count L0s for this daily
                l0_row = db.sql(
                    "SELECT COUNT(*) as c FROM tapestry WHERE tap_parent_id = ? AND tap_level = 0",
                    (daily["tap_id"],),
                    single=True,
                )
                l0_count = l0_row["c"] if l0_row else 0

                result_dailies.append({
                    "tap_id": daily["tap_id"],
                    "title": daily["tap_title"],
                    "date": daily["tap_date"],
                    "content_len": daily["content_len"] or 0,
                    "l0_count": l0_count,
                })

            result_weeklies.append({
                "tap_id": weekly["tap_id"],
                "title": weekly["tap_title"],
                "date_start": weekly["tap_date_start"],
                "date_end": weekly["tap_date_end"],
                "content_len": weekly["content_len"] or 0,
                "dailies": result_dailies,
            })

        result_monthlies.append({
            "tap_id": monthly["tap_id"],
            "title": monthly["tap_title"],
            "date_start": monthly["tap_date_start"],
            "date_end": monthly["tap_date_end"],
            "content_len": monthly["content_len"] or 0,
            "weeklies": result_weeklies,
        })

    # Orphaned weeklies (no parent)
    orphaned_weeklies = db.sql(
        """SELECT tap_id, tap_title, tap_date_start, tap_date_end,
                  LENGTH(tap_content) as content_len
           FROM tapestry
           WHERE tap_level = 2 AND tap_agent_id = ? AND tap_parent_id IS NULL
           ORDER BY tap_date_start""",
        (agent_id,),
    )

    # Orphaned dailies (no parent)
    orphaned_dailies = db.sql(
        """SELECT tap_id, tap_title, tap_date,
                  LENGTH(tap_content) as content_len
           FROM tapestry
           WHERE tap_level = 1 AND tap_agent_id = ? AND tap_parent_id IS NULL
           ORDER BY tap_date""",
        (agent_id,),
    )

    return {
        "monthlies": result_monthlies,
        "orphaned_weeklies": [
            {
                "tap_id": r["tap_id"],
                "title": r["tap_title"],
                "date_start": r["tap_date_start"],
                "date_end": r["tap_date_end"],
                "content_len": r["content_len"] or 0,
            }
            for r in (orphaned_weeklies or [])
        ],
        "orphaned_dailies": [
            {
                "tap_id": r["tap_id"],
                "title": r["tap_title"],
                "date": r["tap_date"],
                "content_len": r["content_len"] or 0,
            }
            for r in (orphaned_dailies or [])
        ],
    }
