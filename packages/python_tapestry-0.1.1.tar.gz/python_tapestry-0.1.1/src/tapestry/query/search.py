"""Keyword search across tapestry messages and summaries."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def search(db: Database, agent: str, agent_id: int, query: str, level: int | None = None) -> list[dict]:
    """Search conversation messages for a keyword/phrase.

    Args:
        db: Database instance.
        agent: Agent name string.
        query: Search term (case-insensitive LIKE match).
        level: If set, only return results that have a summary at this level.

    Returns:
        List of dicts with keys: conv_id, date, match_count, tap_id, title, sample.
        Ordered by date descending (most recent first).
    """
    pattern = f"%{query}%"

    rows = db.sql(
        """SELECT tmsg_ref_conv_id,
                  DATE(MAX(tmsg_timestamp)) as conv_date,
                  COUNT(*) as match_count
           FROM tapestry_messages
           WHERE tmsg_agent_id = ? AND LOWER(tmsg_content) LIKE LOWER(?)
           GROUP BY tmsg_ref_conv_id
           ORDER BY conv_date DESC""",
        (agent_id, pattern),
    )

    if not rows:
        return []

    results = []
    for row in rows:
        conv_id = row["tmsg_ref_conv_id"]

        # Look up L0 summary for this conversation
        l0 = db.sql(
            """SELECT tap_id, tap_title FROM tapestry
               WHERE tap_source = ? AND tap_level = 0 AND tap_agent_id = ?""",
            (conv_id, agent_id),
            single=True,
        )

        tap_id = l0["tap_id"] if l0 else None
        title = l0["tap_title"] if l0 else None

        if level is not None and tap_id is None:
            continue
        if level is not None and level > 0:
            # Check if a summary exists at the requested level covering this date
            continue

        # Get a sample matching message
        sample_row = db.sql(
            """SELECT tmsg_role, tmsg_content FROM tapestry_messages
               WHERE tmsg_ref_conv_id = ? AND tmsg_agent_id = ?
               AND LOWER(tmsg_content) LIKE LOWER(?)
               ORDER BY tmsg_order LIMIT 1""",
            (conv_id, agent_id, pattern),
            single=True,
        )

        sample = None
        if sample_row:
            content = sample_row["tmsg_content"]
            sample = {
                "role": sample_row["tmsg_role"],
                "preview": content[:200] if content else "",
            }

        results.append({
            "conv_id": conv_id,
            "date": row["conv_date"],
            "match_count": row["match_count"],
            "tap_id": tap_id,
            "title": title,
            "sample": sample,
        })

    return results


def search_summaries(db: Database, agent: str, agent_id: int, query: str, level: int | None = None) -> list[dict]:
    """Search tapestry summary content for a keyword/phrase.

    Args:
        db: Database instance.
        agent: Agent name string.
        query: Search term (case-insensitive LIKE match).
        level: If set, only search summaries at this level.

    Returns:
        List of dicts with keys: tap_id, level, title, date, date_start, date_end, preview.
        Ordered by date descending.
    """
    pattern = f"%{query}%"

    if level is not None:
        rows = db.sql(
            """SELECT tap_id, tap_level, tap_title, tap_date, tap_date_start, tap_date_end,
                      SUBSTR(tap_content, 1, 300) as preview
               FROM tapestry
               WHERE tap_agent_id = ? AND tap_level = ?
               AND (LOWER(tap_title) LIKE LOWER(?) OR LOWER(tap_content) LIKE LOWER(?))
               ORDER BY COALESCE(tap_date, tap_date_start) DESC""",
            (agent_id, level, pattern, pattern),
        )
    else:
        rows = db.sql(
            """SELECT tap_id, tap_level, tap_title, tap_date, tap_date_start, tap_date_end,
                      SUBSTR(tap_content, 1, 300) as preview
               FROM tapestry
               WHERE tap_agent_id = ?
               AND (LOWER(tap_title) LIKE LOWER(?) OR LOWER(tap_content) LIKE LOWER(?))
               ORDER BY COALESCE(tap_date, tap_date_start) DESC""",
            (agent_id, pattern, pattern),
        )

    if not rows:
        return []

    return [
        {
            "tap_id": r["tap_id"],
            "level": r["tap_level"],
            "title": r["tap_title"],
            "date": r["tap_date"],
            "date_start": r["tap_date_start"],
            "date_end": r["tap_date_end"],
            "preview": r["preview"],
        }
        for r in rows
    ]
