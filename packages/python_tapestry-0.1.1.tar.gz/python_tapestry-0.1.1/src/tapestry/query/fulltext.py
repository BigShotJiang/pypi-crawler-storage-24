"""Full-text search across tapestry summaries and messages using FTS5."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def fulltext_search(
    db: Database,
    agent: str,
    agent_id: int,
    query: str,
    level: int | None = None,
    top_n: int = 20,
    max_level: int | None = None,
    min_date: str | None = None,
) -> list[dict]:
    """Search both summaries and messages using FTS5 with BM25 ranking.

    Args:
        db: Database instance.
        agent: Agent name string.
        query: Search query (supports FTS5 syntax: AND, OR, NOT, "phrases").
        level: If set, only return summary results at this level.
        top_n: Max results per source (summaries + messages each capped).
        max_level: If set, exclude records above this level.
        min_date: If set (YYYY-MM-DD), exclude records before this date.

    Returns:
        List of result dicts ordered by BM25 score descending.
    """
    results = []
    results.extend(fulltext_summaries(db, agent, agent_id, query, level=level, top_n=top_n,
                                      max_level=max_level, min_date=min_date))
    results.extend(fulltext_messages(db, agent, agent_id, query, top_n=top_n, min_date=min_date))
    results.sort(key=lambda r: r["score"], reverse=True)
    return results


def fulltext_summaries(
    db: Database,
    agent: str,
    agent_id: int,
    query: str,
    level: int | None = None,
    top_n: int = 20,
    max_level: int | None = None,
    min_date: str | None = None,
) -> list[dict]:
    """FTS5 search on tapestry summaries (tap_title + tap_content)."""
    fts_query = _sanitize_fts_query(query)
    if not fts_query:
        return []

    extra_filters = ""
    params: list = [fts_query, agent_id]
    if level is not None:
        extra_filters += " AND t.tap_level = ?"
        params.append(level)
    if max_level is not None:
        extra_filters += " AND t.tap_level <= ?"
        params.append(max_level)
    if min_date is not None:
        extra_filters += " AND COALESCE(t.tap_date, t.tap_date_start) >= ?"
        params.append(min_date)
    params.append(top_n)

    rows = db.sql(
        f"""SELECT t.tap_id, t.tap_level, t.tap_title, t.tap_date,
                   t.tap_date_start, t.tap_date_end,
                   SUBSTR(t.tap_content, 1, 300) as preview,
                   -rank as score
            FROM tapestry_fts fts
            JOIN tapestry t ON t.tap_id = fts.rowid
            WHERE tapestry_fts MATCH ?
              AND t.tap_agent_id = ?
              {extra_filters}
            ORDER BY rank
            LIMIT ?""",
        tuple(params),
    )

    if not rows:
        return []

    return [
        {
            "tap_id": r["tap_id"],
            "level": r["tap_level"],
            "title": r["tap_title"],
            "date": r["tap_date"],
            "date_start": r["tap_date_start"],
            "date_end": r["tap_date_end"],
            "score": round(float(r["score"]), 4),
            "preview": r["preview"],
            "source": "summary",
            "conv_id": None,
        }
        for r in rows
    ]


def fulltext_messages(
    db: Database,
    agent: str,
    agent_id: int,
    query: str,
    top_n: int = 20,
    min_date: str | None = None,
) -> list[dict]:
    """FTS5 search on tapestry_messages, grouped by conversation.

    Returns one result per conversation (best-matching message),
    enriched with L0 summary info when available.
    """
    fts_query = _sanitize_fts_query(query)
    if not fts_query:
        return []

    date_filter = ""
    params: list = [fts_query, agent_id]
    if min_date is not None:
        date_filter = "AND DATE(m.tmsg_timestamp) >= ?"
        params.append(min_date)
    params.append(top_n)

    rows = db.sql(
        f"""SELECT m.tmsg_ref_conv_id as conv_id,
                  m.tmsg_role as role,
                  SUBSTR(m.tmsg_content, 1, 300) as preview,
                  DATE(MAX(m.tmsg_timestamp)) as msg_date,
                  COUNT(*) as match_count,
                  MAX(-fts.rank) as score
           FROM tapestry_messages_fts fts
           JOIN tapestry_messages m ON m.tmsg_id = fts.rowid
           WHERE tapestry_messages_fts MATCH ?
             AND m.tmsg_agent_id = ?
             {date_filter}
           GROUP BY m.tmsg_ref_conv_id
           ORDER BY score DESC
           LIMIT ?""",
        tuple(params),
    )

    if not rows:
        return []

    results = []
    for r in rows:
        conv_id = r["conv_id"]

        l0 = db.sql(
            """SELECT tap_id, tap_title, tap_date FROM tapestry
               WHERE tap_source = ? AND tap_level = 0 AND tap_agent_id = ?""",
            (conv_id, agent_id),
            single=True,
        )

        results.append(
            {
                "tap_id": l0["tap_id"] if l0 else None,
                "level": 0,
                "title": l0["tap_title"] if l0 else f"({r['match_count']} message hits)",
                "date": l0["tap_date"] if l0 else r["msg_date"],
                "date_start": None,
                "date_end": None,
                "score": round(float(r["score"]), 4),
                "preview": r["preview"],
                "source": "message",
                "conv_id": conv_id,
            }
        )

    return results


def _sanitize_fts_query(query: str) -> str:
    """Sanitize user input for FTS5 MATCH syntax.

    Wraps each word in double quotes to treat as literal terms,
    preventing syntax errors from accidental FTS5 operators.
    Passes through explicit operator usage (OR, AND, NOT, quoted phrases).
    """
    cleaned = query.strip()
    if not cleaned:
        return ""

    # If user explicitly used quotes or operators, pass through
    if '"' in cleaned or " OR " in cleaned or " AND " in cleaned or " NOT " in cleaned:
        return cleaned

    # Quote each word to prevent column-prefix and operator issues
    words = cleaned.split()
    return " ".join(f'"{w}"' for w in words if w)
