"""Record counts and size statistics for tapestry data."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database

LEVEL_NAMES = {0: "conversation", 1: "daily", 2: "weekly", 3: "monthly", 4: "yearly"}


def stats(db: Database, agent: str, agent_id: int) -> dict:
    """Compute record counts and size statistics by level.

    Args:
        db: Database instance.
        agent: Agent name string.

    Returns:
        Dict with keys:
            levels: dict keyed by level (0-4), each with count, chars, avg_chars.
            messages: total message count.
            conversations: total unique conversation count.
            total_records: sum of all level counts.
            total_chars: sum of all level chars.
            est_tokens: estimated token count (chars / 4).
    """
    levels = {}
    total_records = 0
    total_chars = 0

    for level in range(5):
        row = db.sql(
            """SELECT COUNT(*) as cnt,
                      COALESCE(SUM(LENGTH(tap_content)), 0) as chars
               FROM tapestry
               WHERE tap_level = ? AND tap_agent_id = ?""",
            (level, agent_id),
            single=True,
        )

        count = row["cnt"] if row else 0
        chars = row["chars"] if row else 0
        avg = chars // count if count > 0 else 0

        levels[level] = {
            "name": LEVEL_NAMES[level],
            "count": count,
            "chars": chars,
            "avg_chars": avg,
        }
        total_records += count
        total_chars += chars

    # Message counts
    msg_row = db.sql(
        "SELECT COUNT(*) as c FROM tapestry_messages WHERE tmsg_agent_id = ?",
        (agent_id,),
        single=True,
    )
    messages = msg_row["c"] if msg_row else 0

    conv_row = db.sql(
        "SELECT COUNT(DISTINCT tmsg_ref_conv_id) as c FROM tapestry_messages WHERE tmsg_agent_id = ?",
        (agent_id,),
        single=True,
    )
    conversations = conv_row["c"] if conv_row else 0

    return {
        "levels": levels,
        "messages": messages,
        "conversations": conversations,
        "total_records": total_records,
        "total_chars": total_chars,
        "est_tokens": total_chars // 4,
    }


def status(db: Database, agent: str, agent_id: int, config_path: str | None = None) -> dict:
    """Build a status dashboard for the agent's tapestry.

    Args:
        db: Database instance.
        agent: Agent name string.
        config_path: Path to tapestry.toml (for display).

    Returns:
        Dict with keys:
            agent, db_path, config_path,
            stats (from stats()),
            date_range: {first, last} or None,
            unsummarized: count of conversations without L0,
            missing_dailies: count of dates with L0s but no daily,
            health: "healthy", "needs_catchup", or "empty".
    """
    s = stats(db, agent, agent_id)

    # Date range
    first_row = db.sql(
        """SELECT DATE(MIN(last_ts)) as first_date,
                  DATE(MAX(last_ts)) as last_date
           FROM (
               SELECT MAX(tmsg_timestamp) as last_ts
               FROM tapestry_messages WHERE tmsg_agent_id = ?
               GROUP BY tmsg_ref_conv_id
           )""",
        (agent_id,),
        single=True,
    )

    date_range = None
    if first_row and first_row["first_date"]:
        date_range = {
            "first": first_row["first_date"],
            "last": first_row["last_date"],
        }

    # Unsummarized conversations
    unsumm_row = db.sql(
        """SELECT COUNT(*) as c FROM (
               SELECT tmsg_ref_conv_id
               FROM tapestry_messages WHERE tmsg_agent_id = ?
               GROUP BY tmsg_ref_conv_id
               HAVING tmsg_ref_conv_id NOT IN (
                   SELECT tap_source FROM tapestry
                   WHERE tap_level = 0 AND tap_agent_id = ?
               )
           )""",
        (agent_id, agent_id),
        single=True,
    )
    unsummarized = unsumm_row["c"] if unsumm_row else 0

    # Missing dailies: dates that have L0s but no L1
    missing_row = db.sql(
        """SELECT COUNT(DISTINCT tap_date) as c
           FROM tapestry
           WHERE tap_level = 0 AND tap_agent_id = ?
           AND tap_date NOT IN (
               SELECT tap_date FROM tapestry
               WHERE tap_level = 1 AND tap_agent_id = ?
           )""",
        (agent_id, agent_id),
        single=True,
    )
    missing_dailies = missing_row["c"] if missing_row else 0

    # Health assessment
    if s["conversations"] == 0:
        health = "empty"
    elif unsummarized > 0 or missing_dailies > 0:
        health = "needs_catchup"
    else:
        health = "healthy"

    return {
        "agent": agent,
        "db_path": db.db_path,
        "config_path": config_path,
        "stats": s,
        "date_range": date_range,
        "unsummarized": unsummarized,
        "missing_dailies": missing_dailies,
        "health": health,
    }
