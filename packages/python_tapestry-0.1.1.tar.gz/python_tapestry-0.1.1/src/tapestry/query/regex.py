"""Regex search across tapestry summaries and messages."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def regex_search(
    db: Database,
    agent: str,
    agent_id: int,
    pattern: str,
    level: int | None = None,
    top_n: int = 20,
    max_level: int | None = None,
    min_date: str | None = None,
) -> list[dict]:
    """Search summaries and messages using Python regex post-filter.

    SQLite has no native regex — this fetches candidate rows and filters
    with re.search() in Python. Searches tap_content (summaries) and
    tmsg_content (messages).

    Args:
        db: Database instance.
        agent: Agent name string.
        pattern: Python regex pattern (re.search syntax).
        level: If set, only return summary results at this level.
        top_n: Max total results to return.
        max_level: If set, exclude records above this level.
        min_date: If set (YYYY-MM-DD), exclude records before this date.

    Returns:
        List of result dicts with keys matching unified search format.
    """
    try:
        compiled = re.compile(pattern, re.IGNORECASE)
    except re.error as e:
        return [{"error": f"Invalid regex: {e}"}]

    results: list[dict] = []
    results.extend(_regex_summaries(db, agent, agent_id, compiled, level, top_n, max_level, min_date))
    results.extend(_regex_messages(db, agent, agent_id, compiled, top_n - len(results), min_date))
    return results[:top_n]


def _regex_summaries(
    db: Database,
    agent: str,
    agent_id: int,
    compiled: re.Pattern,
    level: int | None,
    top_n: int,
    max_level: int | None,
    min_date: str | None,
) -> list[dict]:
    """Search tapestry summaries with regex."""
    conditions = ["tap_agent_id = ?"]
    params: list = [agent_id]

    if level is not None:
        conditions.append("tap_level = ?")
        params.append(level)
    if max_level is not None:
        conditions.append("tap_level <= ?")
        params.append(max_level)
    if min_date:
        conditions.append("COALESCE(tap_date, tap_date_start) >= ?")
        params.append(min_date)

    where = " AND ".join(conditions)
    rows = db.sql(
        f"""SELECT tap_id, tap_level, tap_title, tap_content,
                   tap_date, tap_date_start, tap_date_end
            FROM tapestry
            WHERE {where}
            ORDER BY COALESCE(tap_date, tap_date_start) DESC""",
        tuple(params),
    ) or []

    results = []
    for r in rows:
        content = r["tap_content"] or ""
        title = r["tap_title"] or ""
        match = compiled.search(content) or compiled.search(title)
        if not match:
            continue

        # Build preview around the match
        start = max(0, match.start() - 50)
        end = min(len(match.string), match.end() + 100)
        preview = match.string[start:end]

        results.append({
            "tap_id": r["tap_id"],
            "level": r["tap_level"],
            "title": r["tap_title"],
            "date": r["tap_date"],
            "date_start": r["tap_date_start"],
            "date_end": r["tap_date_end"],
            "preview": preview,
            "source": "summary",
            "conv_id": None,
            "score": None,
        })
        if len(results) >= top_n:
            break

    return results


def _regex_messages(
    db: Database,
    agent: str,
    agent_id: int,
    compiled: re.Pattern,
    top_n: int,
    min_date: str | None,
) -> list[dict]:
    """Search tapestry messages with regex, grouped by conversation."""
    if top_n <= 0:
        return []

    conditions = ["tmsg_agent_id = ?"]
    params: list = [agent_id]
    if min_date:
        conditions.append("tmsg_timestamp >= ?")
        params.append(min_date)

    where = " AND ".join(conditions)
    rows = db.sql(
        f"""SELECT tmsg_ref_conv_id, tmsg_content, tmsg_timestamp
            FROM tapestry_messages
            WHERE {where}
            ORDER BY tmsg_timestamp DESC""",
        tuple(params),
    ) or []

    # Group matches by conversation, keep first match per conv
    seen_convs: set[str] = set()
    results: list[dict] = []

    for r in rows:
        conv_id = r["tmsg_ref_conv_id"]
        if conv_id in seen_convs:
            continue

        content = r["tmsg_content"] or ""
        match = compiled.search(content)
        if not match:
            continue

        seen_convs.add(conv_id)

        # Look up L0 summary for this conversation
        l0 = db.sql(
            """SELECT tap_id, tap_title, tap_date FROM tapestry
               WHERE tap_source = ? AND tap_level = 0 AND tap_agent_id = ?""",
            (conv_id, agent_id),
            single=True,
        )

        start = max(0, match.start() - 50)
        end = min(len(content), match.end() + 100)
        preview = content[start:end]

        results.append({
            "tap_id": l0["tap_id"] if l0 else None,
            "level": 0 if l0 else None,
            "title": l0["tap_title"] if l0 else None,
            "date": (l0["tap_date"] if l0 else str(r["tmsg_timestamp"])[:10]),
            "date_start": None,
            "date_end": None,
            "preview": preview,
            "source": "message",
            "conv_id": conv_id,
            "score": None,
        })
        if len(results) >= top_n:
            break

    return results
