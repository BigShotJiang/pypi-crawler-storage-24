"""Unified two-layer search -- merges FTS5 fulltext and TF-IDF semantic results."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def unified_search(
    db: Database,
    agent: str,
    agent_id: int,
    query: str,
    mode: str = "auto",
    level: int | None = None,
    top_n: int = 20,
    max_level: int | None = None,
    min_date: str | None = None,
) -> list[dict]:
    """Two-layer search across summaries and messages.

    Modes:
        auto:     Semantic on summaries + FTS5 on messages, merged.
        semantic: TF-IDF cosine on summaries only.
        fulltext: FTS5 on both summaries and messages.
        regex:    Python regex post-filter on summaries and messages.

    Args:
        db: Database instance.
        agent: Agent name string.
        query: Search query.
        mode: Search mode (auto/semantic/fulltext/regex).
        level: Filter summary results by level.
        top_n: Max total results to return.
        max_level: If set, exclude records above this level.
        min_date: If set (YYYY-MM-DD), exclude records before this date.

    Returns:
        List of unified result dicts.
    """
    if mode == "semantic":
        return _semantic_search(db, agent, agent_id, query, level, top_n, max_level, min_date)
    elif mode == "fulltext":
        return _fulltext_search(db, agent, agent_id, query, level, top_n, max_level, min_date)
    elif mode == "regex":
        return _regex_search(db, agent, agent_id, query, level, top_n, max_level, min_date)
    else:
        return _auto_search(db, agent, agent_id, query, level, top_n, max_level, min_date)


def _semantic_search(
    db: Database, agent: str, agent_id: int, query: str, level: int | None, top_n: int,
    max_level: int | None = None, min_date: str | None = None,
) -> list[dict]:
    """Semantic-only: TF-IDF cosine on summaries."""
    from tapestry.query.cosine import cosine_search

    results = cosine_search(db, agent, agent_id, query, level=level, top_n=top_n,
                            max_level=max_level, min_date=min_date)
    for r in results:
        r["source"] = "summary"
        r["conv_id"] = None
        r["mode_used"] = "semantic"
    return results


def _fulltext_search(
    db: Database, agent: str, agent_id: int, query: str, level: int | None, top_n: int,
    max_level: int | None = None, min_date: str | None = None,
) -> list[dict]:
    """Fulltext-only: FTS5 on both tables."""
    from tapestry.query.fulltext import fulltext_search

    results = fulltext_search(db, agent, agent_id, query, level=level, top_n=top_n,
                              max_level=max_level, min_date=min_date)
    for r in results:
        r["mode_used"] = "fulltext"
    return results[:top_n]


def _auto_search(
    db: Database, agent: str, agent_id: int, query: str, level: int | None, top_n: int,
    max_level: int | None = None, min_date: str | None = None,
) -> list[dict]:
    """Auto mode: semantic on summaries + FTS5 on messages, merged."""
    from tapestry.query.fulltext import fulltext_messages

    # Layer 1: Semantic on summaries
    semantic_results: list[dict] = []
    try:
        from tapestry.query.cosine import cosine_search

        semantic_results = cosine_search(db, agent, agent_id, query, level=level, top_n=top_n,
                                         max_level=max_level, min_date=min_date)
        for r in semantic_results:
            r["source"] = "summary"
            r["conv_id"] = None
            r["mode_used"] = "semantic"
    except ImportError:
        # scikit-learn not installed -- fall back to FTS5 on summaries
        from tapestry.query.fulltext import fulltext_summaries

        semantic_results = fulltext_summaries(db, agent, agent_id, query, level=level, top_n=top_n,
                                              max_level=max_level, min_date=min_date)
        for r in semantic_results:
            r["mode_used"] = "fulltext_fallback"

    # Layer 2: FTS5 on messages (proper nouns, exact terms)
    message_results = fulltext_messages(db, agent, agent_id, query, top_n=top_n, min_date=min_date)
    for r in message_results:
        r["mode_used"] = "fulltext"

    return _merge_results(semantic_results, message_results, top_n)


def _merge_results(
    summary_results: list[dict],
    message_results: list[dict],
    top_n: int,
) -> list[dict]:
    """Merge summary and message results, deduplicating by tap_id.

    Summary hits take priority (richer context). Message hits for
    conversations already covered by a summary hit are dropped.
    """
    merged = []
    seen_tap_ids: set[int] = set()

    for r in summary_results:
        if r.get("tap_id") is not None:
            seen_tap_ids.add(r["tap_id"])
        merged.append(r)

    for r in message_results:
        if r.get("tap_id") is not None and r["tap_id"] in seen_tap_ids:
            continue
        merged.append(r)

    return merged[:top_n]


def _regex_search(
    db: Database, agent: str, agent_id: int, query: str, level: int | None, top_n: int,
    max_level: int | None = None, min_date: str | None = None,
) -> list[dict]:
    """Regex mode: Python re post-filter on summaries and messages."""
    from tapestry.query.regex import regex_search

    results = regex_search(db, agent, agent_id, query, level=level, top_n=top_n,
                           max_level=max_level, min_date=min_date)
    for r in results:
        r["mode_used"] = "regex"
    return results
