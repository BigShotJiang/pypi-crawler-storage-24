"""Date-based recall and record display."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database

LEVEL_NAMES = {0: "conversation", 1: "daily", 2: "weekly", 3: "monthly", 4: "yearly"}


def show(db: Database, tap_id: int) -> dict | None:
    """Get a single tapestry record by ID.

    Returns dict with all tapestry columns, or None if not found.
    """
    row = db.sql(
        "SELECT * FROM tapestry WHERE tap_id = ?",
        (tap_id,),
        single=True,
    )
    if not row:
        return None

    return dict(row)


def recall(
    db: Database,
    agent: str,
    agent_id: int | None,
    date_str: str,
    end_date: str | None = None,
    max_level: int | None = None,
    min_date: str | None = None,
) -> list[dict]:
    """Recall the best-level summaries for a date or date range.

    Single date fallback chain: daily (L1) -> L0 conversations.
    Range fallback chain: weekly/monthly (L2/L3) -> dailies (L1) in range.

    Args:
        db: Database instance.
        agent: Agent name string.
        date_str: Start date (YYYY-MM-DD).
        end_date: Optional end date for range queries.
        max_level: If set, exclude records above this level.
        min_date: If set (YYYY-MM-DD), exclude records before this date.

    Returns:
        List of tapestry record dicts.
    """
    if end_date is None:
        return _recall_single(db, agent, agent_id, date_str, max_level, min_date)
    return _recall_range(db, agent, agent_id, date_str, end_date, max_level, min_date)


def _recall_single(
    db: Database, agent: str, agent_id: int | None, date_str: str,
    max_level: int | None = None, min_date: str | None = None,
) -> list[dict]:
    """Recall for a single date. Try daily first, fall back to L0s."""
    # If date is before min_date, nothing to return
    if min_date and date_str < min_date:
        return []

    # Try daily (L1) — only if allowed by max_level
    if max_level is None or max_level >= 1:
        daily = db.sql(
            """SELECT * FROM tapestry
               WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?""",
            (date_str, agent_id),
            single=True,
        )
        if daily:
            return [dict(daily)]

    # Fall back to L0 conversations
    l0s = db.sql(
        """SELECT * FROM tapestry
           WHERE tap_level = 0 AND tap_date = ? AND tap_agent_id = ?
           ORDER BY tap_id""",
        (date_str, agent_id),
    )
    return [dict(r) for r in l0s] if l0s else []


def _recall_range(
    db: Database, agent: str, agent_id: int | None, start: str, end: str,
    max_level: int | None = None, min_date: str | None = None,
) -> list[dict]:
    """Recall for a date range. Try weekly/monthly first, fall back to dailies."""
    # Clamp start to min_date if needed
    if min_date and start < min_date:
        start = min_date

    # Build allowed levels for higher-level lookup
    allowed_higher = [l for l in (2, 3) if max_level is None or l <= max_level]

    if allowed_higher:
        placeholders = ",".join("?" * len(allowed_higher))
        higher = db.sql(
            f"""SELECT * FROM tapestry
               WHERE tap_level IN ({placeholders})
               AND tap_date_start <= ? AND tap_date_end >= ?
               AND tap_agent_id = ?
               ORDER BY tap_level ASC LIMIT 1""",
            (*allowed_higher, start, end, agent_id),
            single=True,
        )
        if higher:
            return [dict(higher)]

    # Fall back to dailies in range (L1)
    if max_level is None or max_level >= 1:
        dailies = db.sql(
            """SELECT * FROM tapestry
               WHERE tap_level = 1
               AND tap_date >= ? AND tap_date <= ?
               AND tap_agent_id = ?
               ORDER BY tap_date""",
            (start, end, agent_id),
        )
        if dailies:
            return [dict(r) for r in dailies]

    return []


def conversations(db: Database, agent: str | None = None, agent_id: int | None = None) -> list[dict]:
    """List all imported conversations with message counts.

    Args:
        db: Database instance.
        agent: Optional agent filter. If None, shows all agents.

    Returns:
        List of dicts: conv_id, agent, msg_count, first_msg, last_msg, date.
    """
    if agent_id is not None:
        rows = db.sql(
            """SELECT tmsg_ref_conv_id, tmsg_agent,
                      COUNT(*) as msg_count,
                      MIN(tmsg_timestamp) as first_msg,
                      MAX(tmsg_timestamp) as last_msg,
                      DATE(MAX(tmsg_timestamp)) as conv_date
               FROM tapestry_messages
               WHERE tmsg_agent_id = ?
               GROUP BY tmsg_ref_conv_id
               ORDER BY last_msg DESC""",
            (agent_id,),
        )
    else:
        rows = db.sql(
            """SELECT tmsg_ref_conv_id, tmsg_agent,
                      COUNT(*) as msg_count,
                      MIN(tmsg_timestamp) as first_msg,
                      MAX(tmsg_timestamp) as last_msg,
                      DATE(MAX(tmsg_timestamp)) as conv_date
               FROM tapestry_messages
               GROUP BY tmsg_ref_conv_id
               ORDER BY last_msg DESC""",
        )

    if not rows:
        return []

    return [
        {
            "conv_id": r["tmsg_ref_conv_id"],
            "agent": r["tmsg_agent"],
            "msg_count": r["msg_count"],
            "first_msg": r["first_msg"],
            "last_msg": r["last_msg"],
            "date": r["conv_date"],
        }
        for r in rows
    ]


def show_conversation(db: Database, conv_id_prefix: str) -> dict | None:
    """Display messages from a conversation by ID or prefix.

    Args:
        db: Database instance.
        conv_id_prefix: Full or partial conversation ID.

    Returns:
        Dict with conv_id, msg_count, messages list, or None if not found.
    """
    rows = db.sql(
        """SELECT tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_timestamp
           FROM tapestry_messages
           WHERE tmsg_ref_conv_id LIKE ?
           ORDER BY tmsg_order""",
        (f"{conv_id_prefix}%",),
    )

    if not rows:
        return None

    conv_id = rows[0]["tmsg_ref_conv_id"]
    messages = [
        {
            "role": r["tmsg_role"],
            "content": r["tmsg_content"],
            "timestamp": r["tmsg_timestamp"],
        }
        for r in rows
    ]

    return {
        "conv_id": conv_id,
        "msg_count": len(messages),
        "messages": messages,
    }
