"""Cosine similarity search across tapestry summaries using TF-IDF."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def _check_sklearn() -> None:
    """Raise a helpful error if scikit-learn is not installed."""
    try:
        import sklearn  # noqa: F401
    except ImportError:
        raise ImportError(
            "scikit-learn is required for cosine similarity search. "
            "Install it with: pip install total-recall[search]"
        )


def cosine_search(
    db: Database,
    agent: str,
    agent_id: int,
    query: str,
    level: int | None = None,
    top_n: int = 10,
    max_level: int | None = None,
    min_date: str | None = None,
) -> list[dict]:
    """Find tapestry records most similar to a query string using TF-IDF cosine similarity.

    Builds a TF-IDF matrix over all tap_content for the agent, then ranks
    records by cosine similarity to the query.

    Args:
        db: Database instance.
        agent: Agent name string.
        query: Natural language query to match against.
        level: If set, only search summaries at this level (0-4).
        top_n: Number of top results to return (default 10).
        max_level: If set, exclude records above this level.
        min_date: If set (YYYY-MM-DD), exclude records before this date.

    Returns:
        List of dicts with keys: tap_id, level, title, date, date_start,
        date_end, score, preview. Ordered by similarity score descending.
    """
    _check_sklearn()

    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    # Build dynamic WHERE clause
    conditions = ["tap_agent_id = ?", "tap_content IS NOT NULL", "tap_content != ''"]
    params: list = [agent_id]

    if level is not None:
        conditions.append("tap_level = ?")
        params.append(level)
    if max_level is not None:
        conditions.append("tap_level <= ?")
        params.append(max_level)
    if min_date is not None:
        conditions.append("COALESCE(tap_date, tap_date_start) >= ?")
        params.append(min_date)

    where = " AND ".join(conditions)
    rows = db.sql(
        f"""SELECT tap_id, tap_level, tap_title, tap_date, tap_date_start,
                   tap_date_end, tap_content
            FROM tapestry
            WHERE {where}
            ORDER BY tap_id""",
        tuple(params),
    )

    if not rows:
        return []

    # Build corpus: summaries + query as the last document
    documents = [row["tap_content"] for row in rows]
    documents.append(query)

    # Fit TF-IDF on entire corpus (including query for shared vocabulary)
    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf_matrix = vectorizer.fit_transform(documents)

    # Query vector is the last row
    query_vec = tfidf_matrix[-1:]
    doc_matrix = tfidf_matrix[:-1]

    # Compute similarities
    similarities = cosine_similarity(query_vec, doc_matrix)[0]

    # Pair scores with records and sort
    scored = []
    for i, row in enumerate(rows):
        score = float(similarities[i])
        if score > 0.0:
            scored.append((score, row))

    scored.sort(key=lambda x: x[0], reverse=True)

    # Return top N
    results = []
    for score, row in scored[:top_n]:
        content = row["tap_content"] or ""
        results.append({
            "tap_id": row["tap_id"],
            "level": row["tap_level"],
            "title": row["tap_title"],
            "date": row["tap_date"],
            "date_start": row["tap_date_start"],
            "date_end": row["tap_date_end"],
            "score": round(score, 4),
            "preview": content[:300],
        })

    return results
