"""Drift detection — measure how summary changes propagate through the hierarchy.

Quantifies the Butiri Effect: when a summary at any level is regenerated,
how much do its ancestors change? Uses TF-IDF cosine similarity to compare
current content against what would be generated from current children.

This is a read-only measurement tool. No database writes occur.
"""

from __future__ import annotations

import calendar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.db import Database
    from tapestry.llm import LLMClient


# ── Severity thresholds ──────────────────────────────────────────────

SEVERITY_THRESHOLDS = [
    (0.95, "negligible"),   # 95-100% similar
    (0.85, "minor"),        # 85-95%
    (0.70, "moderate"),     # 70-85%
    (0.50, "significant"),  # 50-70%
    (0.0,  "major"),        # 0-50%
]

LEVEL_NAMES = {0: "L0 conversation", 1: "L1 daily", 2: "L2 weekly", 3: "L3 monthly", 4: "L4 yearly"}


def severity_label(score: float) -> str:
    """Map a cosine similarity score (0.0-1.0) to a human-readable severity label."""
    for threshold, label in SEVERITY_THRESHOLDS:
        if score >= threshold:
            return label
    return "major"


def severity_description(scores: list[dict]) -> str:
    """Generate a one-line UX description of drift impact.

    Example: "This change will significantly alter your monthly but barely touch your yearly."
    """
    if not scores:
        return "No ancestors — drift cannot propagate."

    parts = []
    for s in scores:
        level_name = LEVEL_NAMES.get(s["level"], f"L{s['level']}")
        # Strip the "LN " prefix for natural language
        short_name = level_name.split(" ", 1)[1] if " " in level_name else level_name
        sev = s["severity"]
        if sev == "negligible":
            parts.append(f"barely touch your {short_name}")
        elif sev == "minor":
            parts.append(f"slightly alter your {short_name}")
        elif sev == "moderate":
            parts.append(f"moderately change your {short_name}")
        elif sev == "significant":
            parts.append(f"significantly alter your {short_name}")
        else:  # major
            parts.append(f"fundamentally reshape your {short_name}")

    if len(parts) == 1:
        return f"This change will {parts[0]}."

    return "This change will " + ", ".join(parts[:-1]) + f" and {parts[-1]}."


# ── Core comparison ──────────────────────────────────────────────────

def _compute_similarity(text_a: str, text_b: str) -> float:
    """TF-IDF cosine similarity between two texts."""
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    if not text_a.strip() or not text_b.strip():
        return 0.0

    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf = vectorizer.fit_transform([text_a, text_b])
    return float(cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0])


# ── Regeneration (ephemeral — no DB writes) ──────────────────────────

def _regenerate_content(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    tap_id: int,
    level: int,
    date_str: str,
    date_start: str | None,
    date_end: str | None,
) -> str | None:
    """Regenerate content for a node from its children WITHOUT saving.

    Returns the regenerated text, or None if no children found.
    """
    from tapestry.engine.prompts import (
        daily_prompt,
        monthly_prompt,
        title_prompt,
        weekly_prompt,
        yearly_prompt,
    )

    if level == 1:
        # Daily — regenerate from L0 children
        children = db.sql(
            """SELECT tap_id, tap_title, tap_content
               FROM tapestry
               WHERE tap_parent_id = ? AND tap_level = 0
               ORDER BY tap_id""",
            (tap_id,),
        )
        if not children:
            return None

        input_parts = []
        for i, s in enumerate(children):
            input_parts.append(f"### Session {i+1}: {s['tap_title']}")
            input_parts.append(s["tap_content"])
            input_parts.append("")
        input_text = "\n".join(input_parts)

        return llm.request([
            {"role": "system", "content": daily_prompt(config.agent_name, date_str)},
            {"role": "user", "content": input_text},
        ])

    elif level == 2:
        # Weekly — regenerate from L1 children
        children = db.sql(
            """SELECT tap_id, tap_date, tap_title, tap_content
               FROM tapestry
               WHERE tap_parent_id = ? AND tap_level = 1
               ORDER BY tap_date""",
            (tap_id,),
        )
        if not children:
            return None

        input_parts = []
        for d in children:
            input_parts.append(f"### {d['tap_date']}: {d['tap_title']}")
            input_parts.append(d["tap_content"])
            input_parts.append("")
        input_text = "\n".join(input_parts)

        return llm.request([
            {"role": "system", "content": weekly_prompt(config.agent_name, date_start or date_str, date_end or date_str)},
            {"role": "user", "content": input_text},
        ])

    elif level == 3:
        # Monthly — regenerate from L2 children
        children = db.sql(
            """SELECT tap_id, tap_date_start, tap_date_end, tap_title, tap_content
               FROM tapestry
               WHERE tap_parent_id = ? AND tap_level = 2
               ORDER BY tap_date_start""",
            (tap_id,),
        )
        if not children:
            return None

        input_parts = []
        for w in children:
            input_parts.append(f"### {w['tap_date_start']} to {w['tap_date_end']}: {w['tap_title']}")
            input_parts.append(w["tap_content"])
            input_parts.append("")
        input_text = "\n".join(input_parts)

        # Parse month/year from date_start
        year = int((date_start or date_str)[:4])
        month = int((date_start or date_str)[5:7])
        month_name = calendar.month_name[month]

        return llm.request([
            {"role": "system", "content": monthly_prompt(config.agent_name, month_name, year)},
            {"role": "user", "content": input_text},
        ])

    elif level == 4:
        # Yearly — regenerate from L3 children
        children = db.sql(
            """SELECT tap_id, tap_date_start, tap_date_end, tap_title, tap_content
               FROM tapestry
               WHERE tap_parent_id = ? AND tap_level = 3
               ORDER BY tap_date_start""",
            (tap_id,),
        )
        if not children:
            return None

        input_parts = []
        for m in children:
            input_parts.append(f"### {m['tap_date_start']} to {m['tap_date_end']}: {m['tap_title']}")
            input_parts.append(m["tap_content"])
            input_parts.append("")
        input_text = "\n".join(input_parts)

        year = int((date_start or date_str)[:4])

        return llm.request([
            {"role": "system", "content": yearly_prompt(config.agent_name, year)},
            {"role": "user", "content": input_text},
        ])

    return None


# ── Main drift measurement ───────────────────────────────────────────

def measure_drift(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    tap_id: int,
) -> dict:
    """Measure drift at every ancestor level when a node is regenerated.

    Walks from the target node up through tap_parent_id to the root.
    At each ancestor: regenerates from current children and compares
    against the stored content using TF-IDF cosine similarity.

    Args:
        db: Database instance.
        llm: LLM client for regeneration.
        config: Tapestry configuration.
        agent: Agent name string.
        tap_id: The tapestry record ID to measure drift from.

    Returns:
        Dict with keys:
            target: dict with tap_id, level, title, date
            ancestors: list of dicts per ancestor level with
                tap_id, level, level_name, score, severity, chars_current, chars_regen
            description: one-line UX summary
    """
    from sklearn.feature_extraction.text import TfidfVectorizer  # noqa: F401 — ensure available

    # Load the target node
    target = db.sql(
        """SELECT tap_id, tap_level, tap_title, tap_date, tap_date_start,
                  tap_date_end, tap_content, tap_parent_id
           FROM tapestry WHERE tap_id = ?""",
        (tap_id,),
        single=True,
    )
    if not target:
        return {"error": f"tap_id {tap_id} not found"}

    result = {
        "target": {
            "tap_id": target["tap_id"],
            "level": target["tap_level"],
            "level_name": LEVEL_NAMES.get(target["tap_level"], f"L{target['tap_level']}"),
            "title": target["tap_title"],
            "date": target["tap_date"],
        },
        "ancestors": [],
        "description": "",
    }

    # Walk up the parent chain
    current_id = target["tap_parent_id"]
    while current_id is not None:
        ancestor = db.sql(
            """SELECT tap_id, tap_level, tap_title, tap_date, tap_date_start,
                      tap_date_end, tap_content, tap_parent_id
               FROM tapestry WHERE tap_id = ?""",
            (current_id,),
            single=True,
        )
        if not ancestor:
            break

        current_content = ancestor["tap_content"] or ""

        # Regenerate from children
        regen_content = _regenerate_content(
            db, llm, config, agent, agent_id,
            ancestor["tap_id"],
            ancestor["tap_level"],
            ancestor["tap_date"],
            ancestor["tap_date_start"],
            ancestor["tap_date_end"],
        )

        if regen_content is not None and current_content:
            score = _compute_similarity(current_content, regen_content)
        else:
            score = 1.0  # Can't compare — treat as unchanged

        result["ancestors"].append({
            "tap_id": ancestor["tap_id"],
            "level": ancestor["tap_level"],
            "level_name": LEVEL_NAMES.get(ancestor["tap_level"], f"L{ancestor['tap_level']}"),
            "title": ancestor["tap_title"],
            "score": round(score, 4),
            "severity": severity_label(score),
            "chars_current": len(current_content),
            "chars_regen": len(regen_content) if regen_content else 0,
        })

        current_id = ancestor["tap_parent_id"]

    result["description"] = severity_description(result["ancestors"])
    return result
