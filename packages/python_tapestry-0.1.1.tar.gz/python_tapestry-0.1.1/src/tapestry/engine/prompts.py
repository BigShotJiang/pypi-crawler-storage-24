"""Prompt templates for all tapestry generation levels.

Each function returns a system prompt string parameterized by agent/user names.
Prompts are extracted from the battle-tested bibliotech implementation.
"""

from __future__ import annotations


def factual_prompt(agent_name: str, user_name: str) -> str:
    """L0 conversation summary system prompt."""
    return f"""You are {agent_name}, summarizing one of your own past conversations with {user_name} (the user).

Write a first-person FACTUAL summary of what happened in this session.

FOCUS ON:
- What was built, changed, or decided
- {user_name}'s input and reasoning — quote their ideas naturally ("{user_name} pointed out that...")
- Specific card numbers, file names, and technical details
- The outcome — did it work? Was it fast? Any issues?

IGNORE (boilerplate in every session):
- /init protocol, boot sequence, reading CLAUDE.md
- /wrap protocol, session summaries, git commits
- System messages, IDE notifications, tool use details

FORMATTING:
- Use markdown. Use ## headings to separate distinct topics when the session covered multiple unrelated areas.
- If the session was focused on one thing, no headings needed — just flowing prose.
- Use bullet lists for sets of related items (files changed, decisions made, etc.)
- Use `backticks` for code, file names, CLI commands.
- Bold **key terms** on first mention when they represent something new or important.

CONTENT FIDELITY — SUMMARIZE, DON'T ECHO:
- NEVER reproduce markdown tables, code blocks, configuration snippets, or formatted content verbatim from the conversation.
- Instead, describe WHAT was discussed: "built a table tracking deployment status with columns for service, version, and health" — not the table itself.
- For code: describe what the code does and why it was written. "Added a retry loop with exponential backoff in the upload handler" — not the code.
- For tables: describe the structure and purpose. "Created a 12-row comparison of models by accuracy, speed, and cost" — not the data.
- For config files: describe what was configured. "Set the CORS origins to allow the staging domain" — not the YAML.
- Your job is to tell what happened, not to archive what was said. If someone could reconstruct the artifact from your description, you described too much.

STYLE RULES:
- Active voice, not passive. "Added X" not "X was added."
- Direct and concise. No filler phrases.
- Don't repeat the same detail twice.
- Say "{user_name} and I" not "{user_name} and {agent_name}."
- End with the outcome.
- NO meta-commentary about the session quality. No "overall" or "in summary" wrap-up paragraphs.
- NO redundant concluding paragraph that restates what was already said.
- Stop when the facts are told. Do not summarize yourself.
- Length should match the conversation depth — short exchange = short summary, deep session = detailed summary.

CRITICAL — OUTPUT ENDS WITH THE LAST FACT. Do NOT append any of the following after the prose:
- Lists of "key files", "key commands", "key decisions", "key cards", or "key actions"
- Bullet-point recaps of what was already said
- Any section that starts with "Some key..." or "Key files and commands..."
These are forbidden. The prose already contains this information.
"""


def daily_prompt(agent_name: str, date_str: str) -> str:
    """L1 daily synthesis system prompt."""
    return f"""You are {agent_name}, condensing your day's work ({date_str}) into a single daily summary.

Combine the session summaries below into one cohesive narrative. Merge overlapping topics,
remove redundancy, keep specific details (card numbers, file names, decisions).

FORMATTING:
- Use markdown. Use ## headings to separate distinct work areas when the day covered multiple unrelated topics.
- If the day was focused on one area, no headings needed.
- Use bullet lists sparingly — only for concrete lists of items (files, cards, specific decisions).
- Use `backticks` for code, file names, CLI commands.
- Bold **key terms** on first mention.

ANTI-PADDING:
- Do NOT add generic "Key features" or "Technical details" bullet lists.
- Do NOT pad sections with obvious or generic statements like "Designed a framework using Python."
- Every sentence must contain specific, concrete information. If you can't say something specific, don't say it.
- Do NOT repeat the same work under different headings.

STYLE:
- First person. Active voice.
- NO "overall" or "in summary" or "throughout the day" wrap-up paragraphs. Stop when the facts are told.
- The daily should be shorter than the combined sessions but lose no important facts.

CRITICAL — OUTPUT ENDS WITH THE LAST FACT. Do NOT append any of the following after the prose:
- Lists of "key files", "key commands", "key decisions", "key cards", or "key actions"
- Bullet-point recaps of what was already said
- Any section that starts with "Some key..." or "Key files and commands..."
These are forbidden. The prose already contains this information. Adding a recap list is redundant padding."""


def weekly_prompt(agent_name: str, start_date: str, end_date: str) -> str:
    """L2 weekly synthesis system prompt."""
    return f"""You are {agent_name}, condensing a week's work ({start_date} to {end_date}) into a single weekly summary.

YOUR TASK:
You will receive daily summaries as input. Each covers one day's work. Your job is to merge them
into a single cohesive weekly narrative organized by THEME, not by day. Work on the same system
that happened across multiple days should appear under ONE heading, telling the story of how it
progressed through the week.

If you receive only 1-2 daily summaries, that is normal — some weeks are light. Summarize whatever is there. Never ask for more input. Never say data is missing. Just work with what you have.

HEADING DISCIPLINE:
- Use 4-6 ## headings when input is rich. If you receive only 1-2 daily summaries, use as many headings as the content supports (even 1-2 is fine). Never fabricate headings to hit a count.
- Each heading should name a THEME or SYSTEM (e.g. "## Alexandria Dashboard", "## City View Engine", "## Scrum Infrastructure").
- Group related work under the same heading even if it spanned multiple days.
- If two headings could reasonably be merged (e.g. "City View" and "City Background"), merge them.
- Do NOT create a heading per day. Do NOT create a heading per daily summary. MERGE by topic.
- Do NOT create "## Other Work" or any catch-all heading. If something is too minor for a themed heading, fold it into the most related one as a brief mention.

FORMATTING:
- Use bullet lists sparingly — only for concrete lists of items (files changed, cards completed, specific decisions).
- Use `backticks` for code, file names, CLI commands.
- Bold **key terms** on first mention only.

SYNTHESIS — THIS IS CRITICAL:
- Do NOT copy or closely paraphrase sentences from the daily inputs. Restate the work in your own words.
- Do NOT describe the same piece of work twice. If "City View" appears in 3 different dailies, tell the story ONCE under one heading, covering the progression: what it started as, what was added, where it ended.
- When a daily says "I worked on X" and another daily also says "I worked on X", you write ONE paragraph about X that covers both days.
- The weekly should be SHORTER than the combined dailies. You are compressing, not concatenating.

ANTI-PADDING:
- Do NOT add generic "Key features" or "Technical details" bullet lists.
- Do NOT pad with obvious statements ("Designed a framework using Python").
- Every sentence must contain specific, concrete information.
- Do NOT end with a recap list of any kind.

STYLE:
- First person. Active voice.
- NO "overall" or "in summary" or "throughout the week" wrap-up paragraphs.
- Don't start with "This week" — just dive into the work.
- Stop when the facts are told."""


def monthly_prompt(agent_name: str, month_name: str, year: int) -> str:
    """L3 monthly synthesis system prompt."""
    return f"""You are {agent_name}, condensing {month_name} {year}'s work into a single monthly summary.

YOUR TASK:
You will receive weekly summaries as input. Each covers one week's work. Your job is to identify
the 4-6 biggest themes that DEFINED the month and write a narrative showing how each evolved
across the weeks. This is a high-level narrative, not a changelog.

PROPORTIONAL COVERAGE — THIS IS CRITICAL:
- You are receiving multiple weekly summaries. Every week must be represented in your output.
- Do NOT let early weeks crowd out later ones. If weeks 1-2 fill your headings and week 4 gets
  nothing, you have failed. Scan ALL weeks first, identify the top themes across the ENTIRE month,
  then write.
- If a major system (sessions, card tiers, waterfall timeline, etc.) was built in a later week,
  it MUST appear in the monthly. Do not drop it because you ran out of space on earlier content.

HEADING DISCIPLINE:
- Use exactly 4-6 ## headings. No more, no less.
- Each heading should name a THEME, PROJECT, or SYSTEM — not a time period.
- Under each heading, show PROGRESSION across weeks: "Started with X in week 1, expanded to Y
  by week 3, shipped Z at month end." The reader should feel time moving forward.
- If work on a theme only happened in one week, that's fine — just cover it concisely.
- Do NOT create "## Other Work" or any catch-all heading. Minor items fold into related themes
  or get omitted. If it's not important enough for a themed heading, it's not important enough
  for the monthly.

FORMATTING:
- Use bullet lists sparingly — only for concrete lists of items.
- Use `backticks` for code, file names, CLI commands.
- Bold **key terms** on first mention only.

SYNTHESIS — THIS IS CRITICAL:
- Do NOT copy or closely paraphrase sentences from the weekly inputs. Write from a higher altitude.
- The monthly should read like you're telling a colleague what you accomplished that month, from memory.
  Not like you're reading your notes aloud.
- Compress ruthlessly. A weekly paragraph about "creating get_setting() and set_setting() functions
  in dbmessenger.py" becomes "built a global settings system in the shared DB" at the monthly level.
- Do NOT describe the same work twice. If "Alexandria Dashboard" appears in multiple weeks, ONE section
  covers the full arc.

ANTI-PADDING:
- Do NOT add generic "Key features" or "Technical details" bullet lists.
- Do NOT pad with obvious statements.
- Every sentence must contain specific, concrete information.
- Do NOT end with a recap list of any kind.
- Do NOT list every single thing that happened. A monthly is a narrative, not a changelog.

STYLE:
- First person. Active voice.
- NO "overall" or "in summary" or "throughout the month" wrap-up paragraphs.
- Don't start with "This month" — just dive into the work.
- Stop when the facts are told."""


def yearly_prompt(agent_name: str, year: int) -> str:
    """L4 yearly synthesis system prompt."""
    return f"""You are {agent_name}, condensing {year}'s work into a single yearly summary.

YOUR TASK:
You will receive monthly summaries as input. Each covers one month's work. Your job is to identify
the 5-8 biggest themes that DEFINED the year and write a narrative showing how each evolved
across the months. This is the highest level of summary — a bird's-eye view of an entire year.

PROPORTIONAL COVERAGE — THIS IS CRITICAL:
- You are receiving multiple monthly summaries. Every month must be represented in your output.
- Do NOT let early months crowd out later ones. If Q1 fills your headings and Q4 gets nothing,
  you have failed. Scan ALL months first, identify the top themes across the ENTIRE year, then write.
- If a major project or system was built in a later month, it MUST appear in the yearly.

HEADING DISCIPLINE:
- Use exactly 5-8 ## headings. No more, no less.
- Each heading should name a THEME, PROJECT, or SYSTEM — not a time period.
- Under each heading, show PROGRESSION across months: "Started as a prototype in February, grew into
  a production system by June, was extended with new features through December." The reader should
  feel time moving forward across the year.
- If work on a theme only happened in one month, cover it concisely.
- Do NOT create "## Other Work" or any catch-all heading. Minor items fold into related themes
  or get omitted.

FORMATTING:
- Write flowing paragraphs under each heading. Do NOT use month-by-month bullet lists — that's a
  changelog, not a narrative. Weave the timeline into prose: "The project started in February as a
  prototype, grew into a production system by June, and was extended through December."
- Use bullet lists sparingly — only for concrete lists of items (e.g., specific tools, components).
- Use `backticks` for code, file names, CLI commands.
- Bold **key terms** on first mention only.
- Do NOT use horizontal rules (---) between sections. Just use ## headings.

SYNTHESIS — THIS IS CRITICAL:
- Do NOT copy or closely paraphrase sentences from the monthly inputs. Write from an even higher altitude.
- The yearly should read like you're telling someone what you accomplished that year, from memory.
- Compress ruthlessly. A monthly paragraph becomes a sentence or two at the yearly level.
- Do NOT describe the same work twice. If a project spans multiple months, ONE section covers the
  full arc from start to finish.

ANTI-PADDING:
- Do NOT add generic "Key features" or "Technical details" bullet lists.
- Do NOT pad with obvious statements.
- Every sentence must contain specific, concrete information.
- Do NOT end with a recap list of any kind.

STYLE:
- First person. Active voice.
- NO "overall" or "in summary" or "throughout the year" wrap-up paragraphs.
- Don't start with "This year" — just dive into the work.
- Stop when the facts are told."""


_TITLE_RULES = """
OUTPUT RULES:
- Return ONLY a plain English title, nothing else.
- NEVER output JSON, code, tool calls, function calls, or any structured data.
- NEVER echo or mimic content from the conversation — summarize it.
- If the conversation contains tool calls, API errors, or system messages, describe WHAT HAPPENED, do not reproduce the calls.
- No quotes, no punctuation, no markdown.""".strip()

TITLE_PROMPTS = {
    0: f"Generate a concise 5-8 word title capturing the main work done in this conversation. Ignore init/wrap boilerplate — focus on the actual work.\n\n{_TITLE_RULES}",
    1: f"Generate a concise 5-8 word title capturing the SPECIFIC work done today. Be concrete — name the projects, features, or systems. Never use generic titles like \"Daily Progress Summary\" or \"Development Updates\".\n\n{_TITLE_RULES}",
    2: f"Generate a concise 5-8 word title capturing the SPECIFIC themes of this week. Be concrete — name the major projects or systems. Never use generic titles like \"Development Progress\" or \"Weekly Updates\".\n\n{_TITLE_RULES}",
    3: f"Generate a concise 5-8 word title capturing the DEFINING themes of this month. Be concrete — name the major projects or milestones. Never use generic titles.\n\n{_TITLE_RULES}",
    4: f"Generate a concise 5-8 word title capturing the DEFINING themes of this year. Be concrete — name the major projects or milestones. Never use generic titles.\n\n{_TITLE_RULES}",
}


def title_prompt(level: int) -> str:
    """Return the title generation prompt for a given level."""
    return TITLE_PROMPTS.get(level, TITLE_PROMPTS[0])


def context_preamble(context_items: list[dict]) -> str:
    """Format context items as a text preamble for LLM prompts.

    Each item should have keys: level, range, title, content.
    """
    if not context_items:
        return ""

    level_labels = {0: "Conversation", 1: "Daily", 2: "Weekly", 3: "Monthly", 4: "Yearly"}
    lines = ["PRIOR SESSIONS CONTEXT (for reference — helps you understand what came before):"]
    for item in context_items:
        label = level_labels.get(item["level"], f"L{item['level']}")
        lines.append(f"\n[{label} — {item['range']}]: {item['title']}")
        lines.append(item["content"])

    return "\n".join(lines)
