"""Incremental tapestry rebuild (catchup) and context-aware iterate.

catchup: Fast 5-step rebuild — ingest new conversations, generate missing
summaries at all levels. Designed for automated runs (e.g., init_check).

iterate: Slower, context-aware processing — resolves context before each L0
generation and repairs gaps as it walks through dates.
"""

from __future__ import annotations

import calendar
import time
from collections import OrderedDict
from datetime import date, timedelta
from typing import TYPE_CHECKING

from tqdm import tqdm

from tapestry.engine.context import _ctx, _repair, resolve_context
from tapestry.engine.generate import (
    auto_generate_daily,
    auto_generate_l0,
    auto_generate_monthly,
    auto_generate_weekly,
)
from tapestry.engine.repair import repair_monthly, repair_weekly
from tapestry.engine.rollup import conversations_in_range, weeks_in_month

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.db import Database
    from tapestry.llm import LLMClient


def catchup(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    log: callable | None = None,
    delay: float = 1.0,
) -> dict[str, int]:
    """Bulk rebuild WITHOUT telescoping context. For testing/initial ingest only.

    WARNING: Generates L0s with no prior context — every summary is written
    in isolation. This degrades all higher-level rollups (the Butiri Effect).
    Use iterate() for production-quality data. Catchup is only useful for
    quickly populating a database to test the pipeline.

    5-step process:
    1. Generate L0s for conversations without summaries (NO context)
    2. Generate L1 dailies for dates with L0s but no daily (exclude today)
    3. Integrity sweep — L2 weeklies for completed weeks
    4. Integrity sweep — L3 monthlies for completed months
    5. Return generation counts

    On API failure (after retries in LLMClient), raises LLMError to stop
    the run. The process is resumable — restart picks up where it left off
    because existing summaries are skipped.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        log: Optional callable for progress output.
        delay: Seconds to wait between API calls (default 1.0).

    Returns:
        Dict with l0, l1, l2, l3 generation counts.
    """
    today_str = date.today().isoformat()
    generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}

    # Step 1: Generate L0s for conversations without summaries
    unsummarized = db.sql(
        """SELECT tmsg_ref_conv_id, DATE(MAX(tmsg_timestamp)) as conv_date
           FROM tapestry_messages
           WHERE tmsg_agent_id = ?
           GROUP BY tmsg_ref_conv_id
           HAVING tmsg_ref_conv_id NOT IN (
               SELECT tap_source FROM tapestry WHERE tap_level = 0 AND tap_source IS NOT NULL
           )
           ORDER BY conv_date""",
        (agent_id,),
    )
    if log:
        log(f"Step 1: {len(unsummarized)} conversations need L0 summaries")
    l0_bar = tqdm(unsummarized, desc="L0 summaries", unit="conv",
                   disable=not unsummarized)
    for i, conv in enumerate(l0_bar, 1):
        conv_id = conv["tmsg_ref_conv_id"]
        if log:
            log(f"  L0 {i}/{len(unsummarized)} conv {conv_id[:12]}... ({conv['conv_date']})")
        tap_id = auto_generate_l0(db, llm, config, agent, agent_id, conv_id)
        if tap_id:
            generated["l0"] += 1
            title = db.sql(
                "SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True
            )
            l0_bar.set_postfix_str(title["tap_title"][:40])
            if log:
                log(f"    -> tap_id={tap_id}: {title['tap_title'][:60]}")
        time.sleep(delay)

    # Step 2: Generate L1 dailies for dates with L0s but no daily (exclude today)
    dates_needing_daily = db.sql(
        """SELECT DISTINCT tap_date
           FROM tapestry
           WHERE tap_level = 0 AND tap_agent_id = ? AND tap_date < ?
           AND tap_date NOT IN (
               SELECT tap_date FROM tapestry WHERE tap_level = 1 AND tap_agent_id = ?
           )
           ORDER BY tap_date""",
        (agent_id, today_str, agent_id),
    )
    if log:
        log(f"Step 2: {len(dates_needing_daily)} dates need L1 dailies")
    l1_bar = tqdm(dates_needing_daily, desc="L1 dailies", unit="day",
                   disable=not dates_needing_daily)
    for i, row in enumerate(l1_bar, 1):
        if log:
            log(f"  L1 {i}/{len(dates_needing_daily)} daily {row['tap_date']}")
        tap_id = auto_generate_daily(db, llm, config, agent, agent_id, row["tap_date"])
        if tap_id:
            generated["l1"] += 1
            title = db.sql(
                "SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True
            )
            l1_bar.set_postfix_str(f"{row['tap_date']} {title['tap_title'][:30]}")
            if log:
                log(f"    -> tap_id={tap_id}: {title['tap_title'][:60]}")
        time.sleep(delay)

    # Step 3: Integrity sweep — L2 weeklies for completed weeks
    if log:
        log("Step 3: Checking for missing L2 weeklies")
    first_conv = db.sql(
        "SELECT DATE(MIN(tmsg_timestamp)) as d FROM tapestry_messages WHERE tmsg_agent_id = ?",
        (agent_id,),
        single=True,
    )
    if first_conv and first_conv["d"]:
        first_date = date.fromisoformat(first_conv["d"])
        today = date.today()
        current_monday = today - timedelta(days=today.weekday())

        current = date(first_date.year, first_date.month, 1)
        while current <= today:
            for ws, we in weeks_in_month(current.year, current.month):
                if we >= current_monday:
                    continue  # current/future week
                week_convs = conversations_in_range(db, agent, agent_id, str(ws), str(we))
                if not week_convs:
                    continue
                weekly_exists = db.sql(
                    """SELECT tap_id FROM tapestry WHERE tap_level = 2 AND tap_agent_id = ?
                       AND tap_date_start = ? AND tap_date_end = ?""",
                    (agent_id, str(ws), str(we)),
                    single=True,
                )
                if weekly_exists:
                    continue
                # Ensure dailies exist for this week first
                for conv in week_convs:
                    d = conv["conv_date"]
                    daily_exists = db.sql(
                        "SELECT tap_id FROM tapestry WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?",
                        (d, agent_id),
                        single=True,
                    )
                    if not daily_exists:
                        if log:
                            log(f"  L1 repair daily {d} (needed for weekly {ws} to {we})")
                        tid = auto_generate_daily(db, llm, config, agent, agent_id, d)
                        if tid:
                            generated["l1"] += 1
                            if log:
                                log(f"    -> tap_id={tid}")
                        time.sleep(delay)
                if log:
                    log(f"  L2 weekly {ws} to {we}")
                tap_id = auto_generate_weekly(db, llm, config, agent, agent_id, str(ws), str(we))
                if tap_id:
                    generated["l2"] += 1
                    title = db.sql(
                        "SELECT tap_title FROM tapestry WHERE tap_id = ?",
                        (tap_id,),
                        single=True,
                    )
                    if log:
                        log(f"    -> tap_id={tap_id}: {title['tap_title'][:60]}")
                time.sleep(delay)

            # Next month
            if current.month == 12:
                current = date(current.year + 1, 1, 1)
            else:
                current = date(current.year, current.month + 1, 1)

    # Step 4: Integrity sweep — L3 monthlies for completed months
    if log:
        log("Step 4: Checking for missing L3 monthlies")
    if first_conv and first_conv["d"]:
        first_date = date.fromisoformat(first_conv["d"])
        today = date.today()
        current = date(first_date.year, first_date.month, 1)
        current_month_start = date(today.year, today.month, 1)

        while current < current_month_start:
            month_end_day = calendar.monthrange(current.year, current.month)[1]
            month_end = date(current.year, current.month, month_end_day)
            month_convs = conversations_in_range(db, agent, agent_id, str(current), str(month_end))
            if month_convs:
                monthly_exists = db.sql(
                    """SELECT tap_id FROM tapestry WHERE tap_level = 3 AND tap_agent_id = ?
                       AND tap_date_start = ? AND tap_date_end = ?""",
                    (agent_id, str(current), str(month_end)),
                    single=True,
                )
                if not monthly_exists:
                    if log:
                        log(f"  L3 monthly {calendar.month_name[current.month]} {current.year}")
                    tap_id = auto_generate_monthly(
                        db, llm, config, agent, agent_id, current.year, current.month
                    )
                    if tap_id:
                        generated["l3"] += 1
                        title = db.sql(
                            "SELECT tap_title FROM tapestry WHERE tap_id = ?",
                            (tap_id,),
                            single=True,
                        )
                        if log:
                            log(f"    -> tap_id={tap_id}: {title['tap_title'][:60]}")
                    time.sleep(delay)

            if current.month == 12:
                current = date(current.year + 1, 1, 1)
            else:
                current = date(current.year, current.month + 1, 1)

    if log:
        log(
            f"\nDone. L0={generated['l0']}, L1={generated['l1']},"
            f" L2={generated['l2']}, L3={generated['l3']}"
        )

    return generated


def iterate(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    end_date_str: str,
    save: bool = False,
    log: callable | None = None,
) -> dict[str, int]:
    """Context-aware date-by-date processing with repair cascade.

    For each date up to end_date:
    1. Resolve telescoping context
    2. Repair higher-level gaps (dailies, weeklies, monthlies)
    3. Re-resolve context after repairs
    4. Generate L0s with context
    5. Generate daily
    Then: integrity sweep for missing weeklies/monthlies.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        end_date_str: YYYY-MM-DD last date to process.
        save: If False, dry run (report only). If True, generate and store.
        log: Optional callable for progress output.

    Returns:
        Dict with l0, l1, l2, l3 generation counts.
    """
    end_date = date.fromisoformat(end_date_str)

    # Get all conversations up to end_date, ordered by end timestamp
    all_convs = db.sql(
        """SELECT tmsg_ref_conv_id,
                  DATE(MAX(tmsg_timestamp)) as conv_date,
                  MIN(tmsg_timestamp) as first_ts,
                  MAX(tmsg_timestamp) as last_ts
           FROM tapestry_messages
           WHERE tmsg_agent_id = ?
           GROUP BY tmsg_ref_conv_id
           HAVING conv_date <= ?
           ORDER BY last_ts""",
        (agent_id, end_date_str),
    )

    if not all_convs:
        if log:
            log("No conversations found.")
        return {"l0": 0, "l1": 0, "l2": 0, "l3": 0}

    # Group by date, preserving chronological order within each day
    by_date: OrderedDict[str, list[dict]] = OrderedDict()
    for conv in all_convs:
        d = conv["conv_date"]
        if d not in by_date:
            by_date[d] = []
        by_date[d].append(conv)

    if log:
        log(f"Processing {len(all_convs)} conversations across {len(by_date)} dates")
        dates = list(by_date.keys())
        log(f"Range: {dates[0]} to {dates[-1]}")

    generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}

    date_bar = tqdm(by_date.items(), desc="Dates", unit="day",
                     total=len(by_date), disable=not save)
    for date_str, convs in date_bar:
        date_bar.set_postfix_str(date_str)

        # Check if fully processed (all L0s + daily exist)
        all_done = True
        for conv in convs:
            existing = db.sql(
                "SELECT tap_id FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                (conv["tmsg_ref_conv_id"],),
                single=True,
            )
            if not existing:
                all_done = False
                break
        if all_done:
            daily_exists = db.sql(
                "SELECT tap_id FROM tapestry WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?",
                (date_str, agent_id),
                single=True,
            )
            if daily_exists:
                if log and not save:
                    log(f"  {date_str}: {len(convs)} conv(s) — complete, skip")
                continue

        current = date.fromisoformat(date_str)
        if log and not save:
            log(f"\n{'=' * 60}")
            log(f"  {date_str} ({current.strftime('%A')}) — {len(convs)} conversation(s)")
            log(f"{'=' * 60}")

        # Step 1: Resolve context for this date
        context, repairs = resolve_context(db, agent, agent_id, date_str)

        # Step 2: Repair higher-level gaps (bottom-up: L1 dailies then L2 weeklies)
        for repair_item in sorted(repairs, key=lambda r: r["level"]):
            if repair_item["level"] == 0:
                continue  # L0s handled in step 4

            if repair_item["level"] == 1:
                if not save:
                    if log:
                        log(f"  WOULD REPAIR L1 daily {repair_item['range']}")
                    continue
                if log:
                    log(f"  REPAIR L1 daily {repair_item['range']}...")
                tap_id = auto_generate_daily(db, llm, config, agent, agent_id, repair_item["start"])
                if tap_id:
                    generated["l1"] += 1

            elif repair_item["level"] == 2:
                if not save:
                    if log:
                        log(f"  WOULD REPAIR L2 weekly {repair_item['range']}")
                    continue
                repair_weekly(db, llm, config, agent, agent_id, repair_item, generated, log)

            elif repair_item["level"] == 3:
                if not save:
                    if log:
                        log(f"  WOULD REPAIR L3 monthly {repair_item['range']}")
                    continue
                repair_monthly(db, llm, config, agent, agent_id, repair_item, generated, log)

        if not save:
            unsummarized = sum(
                1
                for c in convs
                if not db.sql(
                    "SELECT tap_id FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                    (c["tmsg_ref_conv_id"],),
                    single=True,
                )
            )
            if log:
                log(
                    f"  Context: {len(context)} items"
                    f" | Repairs: {len([r for r in repairs if r['level'] > 0])}"
                )
                log(f"  L0s to generate: {unsummarized}")
            continue

        # Step 3: Re-resolve context after repairs
        context, _ = resolve_context(db, agent, agent_id, date_str)
        higher_context = [c for c in context if c["level"] > 0]

        # Step 4: Generate L0s for each conversation (ordered by start time)
        running_l0s: list[dict] = []
        for conv in convs:
            conv_id = conv["tmsg_ref_conv_id"]

            existing = db.sql(
                "SELECT tap_id, tap_title, tap_content FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                (conv_id,),
                single=True,
            )
            if existing:
                running_l0s.append(_ctx(0, existing, date_str))
                continue

            conv_context = higher_context + running_l0s
            if log:
                log(f"  L0 {conv_id[:8]}... (context: {len(conv_context)} items)")
            tap_id = auto_generate_l0(db, llm, config, agent, agent_id, conv_id, conv_context)
            if tap_id:
                new_l0 = db.sql(
                    "SELECT tap_id, tap_title, tap_content FROM tapestry WHERE tap_id = ?",
                    (tap_id,),
                    single=True,
                )
                if log:
                    log(f"    -> tap_id={tap_id}: {new_l0['tap_title']}")
                running_l0s.append(_ctx(0, new_l0, date_str))
                generated["l0"] += 1

        # Step 5: Generate daily for this date
        if log:
            log(f"  L1 daily {date_str}...")
        tap_id = auto_generate_daily(db, llm, config, agent, agent_id, date_str)
        if tap_id:
            generated["l1"] += 1
            if log:
                title = db.sql(
                    "SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True
                )
                log(f"    -> tap_id={tap_id}: {title['tap_title']}")

    # Final pass: integrity sweep for missing higher-level summaries
    if log:
        log("\n  Checking higher-level summaries...")
    repaired_any = False

    first_conv = db.sql(
        "SELECT DATE(MIN(tmsg_timestamp)) as d FROM tapestry_messages WHERE tmsg_agent_id = ?",
        (agent_id,),
        single=True,
    )
    if first_conv and first_conv["d"]:
        first_date = date.fromisoformat(first_conv["d"])

        # Check weeklies
        current = date(first_date.year, first_date.month, 1)
        while current <= end_date:
            for ws, we in weeks_in_month(current.year, current.month):
                if we >= end_date:
                    continue
                week_convs = conversations_in_range(db, agent, agent_id, str(ws), str(we))
                if not week_convs:
                    continue
                weekly_exists = db.sql(
                    """SELECT tap_id FROM tapestry WHERE tap_level = 2 AND tap_agent_id = ?
                       AND tap_date_start = ? AND tap_date_end = ?""",
                    (agent_id, str(ws), str(we)),
                    single=True,
                )
                if weekly_exists:
                    continue
                repaired_any = True
                if not save:
                    if log:
                        log(f"  WOULD REPAIR L2 weekly {ws} to {we}")
                else:
                    week_repair = _repair(
                        2,
                        f"{ws.strftime('%b %d')}-{we.strftime('%b %d')}",
                        str(ws),
                        str(we),
                        len(week_convs),
                    )
                    repair_weekly(db, llm, config, agent, agent_id, week_repair, generated, log)
            if current.month == 12:
                current = date(current.year + 1, 1, 1)
            else:
                current = date(current.year, current.month + 1, 1)

        # Check monthlies
        current = date(first_date.year, first_date.month, 1)
        while current < date(end_date.year, end_date.month, 1):
            month_end = date(
                current.year, current.month, calendar.monthrange(current.year, current.month)[1]
            )
            month_convs = conversations_in_range(db, agent, agent_id, str(current), str(month_end))
            if month_convs:
                monthly_exists = db.sql(
                    """SELECT tap_id FROM tapestry WHERE tap_level = 3 AND tap_agent_id = ?
                       AND tap_date_start = ? AND tap_date_end = ?""",
                    (agent_id, str(current), str(month_end)),
                    single=True,
                )
                if not monthly_exists:
                    repaired_any = True
                    if not save:
                        if log:
                            log(
                                f"  WOULD REPAIR L3 monthly"
                                f" {calendar.month_name[current.month]} {current.year}"
                            )
                    else:
                        if log:
                            log(
                                f"  REPAIR L3 monthly"
                                f" {calendar.month_name[current.month]} {current.year}..."
                            )
                        tap_id = auto_generate_monthly(
                            db, llm, config, agent, agent_id, current.year, current.month
                        )
                        if tap_id:
                            generated["l3"] += 1
                            if log:
                                title = db.sql(
                                    "SELECT tap_title FROM tapestry WHERE tap_id = ?",
                                    (tap_id,),
                                    single=True,
                                )
                                log(f"    -> tap_id={tap_id}: {title['tap_title']}")
            if current.month == 12:
                current = date(current.year + 1, 1, 1)
            else:
                current = date(current.year, current.month + 1, 1)

    if not repaired_any and log:
        log("  All higher-level summaries intact.")

    if log:
        log(
            f"\n{'=' * 60}\n"
            f"Done. L0s: {generated['l0']}, Dailies: {generated['l1']},"
            f" Weeklies: {generated['l2']}, Monthlies: {generated['l3']}"
        )

    return generated
