"""Benchmark automation engine -- full pipeline runner.

Chains the complete benchmark pipeline end-to-end:
  1. Import messages from production DB
  2. Import context (pre-range + in-range summaries)
  3. Build CA hierarchy (iterate with telescoping context)
  4. Build CF hierarchy (generate without context)
  5. Extract CA topics from L0 summaries
  6. Extract CF topics from L0 summaries
  7. SBERT match CF topics against CA topics
  8. LLM verify matched pairs
  9. Compute RY factor

Supports single runs and batch mode (multiple agent/date-range combos).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.db import Database
    from tapestry.llm import LLMClient


# ---------------------------------------------------------------------------
# Step percentages for progress reporting
# ---------------------------------------------------------------------------

_STEPS = {
    "import":         (0,  3),
    "import-context": (3,  5),
    "build-ca":       (5,  20),
    "build-cf":       (20, 50),
    "extract-ca":     (50, 65),
    "extract-cf":     (65, 80),
    "sbert-match":    (80, 85),
    "llm-verify":     (85, 98),
    "score":          (98, 100),
}


def _notify(progress, step: str, detail: str = "") -> None:
    """Call progress callback if provided."""
    if progress:
        pct = _STEPS.get(step, (0, 0))[0]
        progress(step, detail, pct)


_DEBUG_LOG = "D:/Dropbox/bibliotech/logs/benchmark_debug.log"


def _debug_log(msg: str) -> None:
    """Write to both stdout and the debug log file."""
    print(msg)
    # with open(_DEBUG_LOG, "a", encoding="utf-8") as f:
    #     f.write(msg + "\n")


def _debug_dump(db, agent: str, bt_id: int, step: str, date_start: str = "", date_end: str = "") -> None:
    """Dump detailed table counts to stdout and debug log file."""
    _debug_log(f"\n[DEBUG] === After {step} (bt_id={bt_id}, agent={agent}) ===")

    # tapestry counts
    total = db.sql("SELECT COUNT(*) as c FROM tapestry WHERE tap_agent = ?", (agent,), single=True)
    by_bt = db.sql("SELECT COUNT(*) as c FROM tapestry WHERE tap_agent = ? AND bt_id = ?", (agent, bt_id), single=True)
    nulls = db.sql("SELECT COUNT(*) as c FROM tapestry WHERE tap_agent = ? AND bt_id IS NULL", (agent,), single=True)
    _debug_log(f"  tapestry: total={total['c']}, bt_id={bt_id}: {by_bt['c']}, NULL: {nulls['c']}")

    # tapestry L0s in date range
    if date_start and date_end:
        ca_in_range = db.sql(
            "SELECT COUNT(*) as c FROM tapestry WHERE tap_agent = ? AND tap_level = 0 AND bt_id = ? AND tap_date BETWEEN ? AND ?",
            (agent, bt_id, date_start, date_end), single=True)
        _debug_log(f"  CA L0s in range ({date_start} to {date_end}): {ca_in_range['c']}")

    # benchmark_summaries
    bs_total = db.sql("SELECT COUNT(*) as c FROM benchmark_summaries WHERE bsum_agent = ?", (agent,), single=True)
    bs_bt = db.sql("SELECT COUNT(*) as c FROM benchmark_summaries WHERE bsum_agent = ? AND bt_id = ?", (agent, bt_id), single=True)
    _debug_log(f"  benchmark_summaries: total={bs_total['c']}, bt_id={bt_id}: {bs_bt['c']}")

    # CF L0s in date range
    if date_start and date_end:
        cf_in_range = db.sql(
            "SELECT COUNT(*) as c FROM benchmark_summaries WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_track = 'context-free' AND bt_id = ? AND bsum_date BETWEEN ? AND ?",
            (agent, bt_id, date_start, date_end), single=True)
        _debug_log(f"  CF L0s in range ({date_start} to {date_end}): {cf_in_range['c']}")

    # topics
    ca_topics = db.sql(
        "SELECT COUNT(*) as c FROM benchmark_topics WHERE btop_agent = ? AND btop_track = 'context-aware' AND bt_id = ?",
        (agent, bt_id), single=True)
    cf_topics = db.sql(
        "SELECT COUNT(*) as c FROM benchmark_topics WHERE btop_agent = ? AND btop_track = 'context-free' AND bt_id = ?",
        (agent, bt_id), single=True)
    _debug_log(f"  topics: CA={ca_topics['c']}, CF={cf_topics['c']}")

    # matches
    try:
        matches = db.sql(
            "SELECT COUNT(*) as c FROM benchmark_matches WHERE bt_id = ?",
            (bt_id,), single=True)
        confirmed = db.sql(
            "SELECT COUNT(*) as c FROM benchmark_matches WHERE bt_id = ? AND bmatch_confirmed = 1",
            (bt_id,), single=True)
        _debug_log(f"  matches: total={matches['c']}, confirmed={confirmed['c']}")
    except Exception:
        _debug_log(f"  matches: (table not queried)")

    # tapestry_messages
    msgs = db.sql("SELECT COUNT(*) as c FROM tapestry_messages WHERE tmsg_agent = ? AND bt_id = ?", (agent, bt_id), single=True)
    _debug_log(f"  messages: {msgs['c']}")
    _debug_log("")


# ---------------------------------------------------------------------------
# Import helpers (extracted from dashboard inline SQL)
# ---------------------------------------------------------------------------

def import_messages(
    prod_db_path: str,
    test_db: Database,
    agent: str,
    date_start: str,
    date_end: str,
    bt_id: int | None = None,
) -> dict:
    """Copy messages from production DB into test DB for a date range.

    Clears existing test data first -- scoped by bt_id when provided,
    otherwise falls back to agent-based deletion.

    Returns:
        Dict with 'conversations' and 'messages' counts.
    """
    test_db.sql("PRAGMA foreign_keys = OFF")

    # Clear ALL existing test data for this agent — not just by bt_id.
    # iterate() creates summaries with NULL bt_id, so bt_id-scoped deletes
    # leave orphans that contaminate the post-iterate UPDATE.
    test_db.sql("DELETE FROM benchmark_topics WHERE btop_agent = ?", (agent,))
    test_db.sql("DELETE FROM benchmark_results WHERE bench_agent = ?", (agent,))
    test_db.sql("DELETE FROM benchmark_summaries WHERE bsum_agent = ?", (agent,))
    test_db.sql("DELETE FROM tapestry WHERE tap_agent = ?", (agent,))
    test_db.sql("DELETE FROM tapestry_messages WHERE tmsg_agent = ?", (agent,))

    # Copy messages from production (prod won't have bt_id column)
    test_db.sql("ATTACH DATABASE ? AS prod", (prod_db_path,))

    # Get prod columns (excludes bt_id which doesn't exist in prod)
    prod_cols = ", ".join(
        c["name"] for c in test_db.sql("PRAGMA prod.table_info(tapestry_messages)")
    )
    test_db.sql(
        f"""INSERT OR IGNORE INTO tapestry_messages ({prod_cols})
           SELECT {prod_cols} FROM prod.tapestry_messages
           WHERE tmsg_agent = ? AND DATE(tmsg_timestamp) BETWEEN ? AND ?""",
        (agent, date_start, date_end),
    )
    test_db.sql("DETACH DATABASE prod")

    # Stamp bt_id on imported rows
    if bt_id is not None:
        test_db.sql(
            "UPDATE tapestry_messages SET bt_id = ? WHERE tmsg_agent = ? AND bt_id IS NULL",
            (bt_id, agent),
        )

    test_db.sql("PRAGMA foreign_keys = ON")

    # Count scoped by bt_id
    if bt_id is not None:
        msgs = test_db.sql(
            "SELECT COUNT(*) as cnt FROM tapestry_messages WHERE bt_id = ?",
            (bt_id,), single=True,
        )
        convs = test_db.sql(
            "SELECT COUNT(DISTINCT tmsg_ref_conv_id) as cnt FROM tapestry_messages WHERE bt_id = ?",
            (bt_id,), single=True,
        )
    else:
        msgs = test_db.sql(
            "SELECT COUNT(*) as cnt FROM tapestry_messages WHERE tmsg_agent = ?",
            (agent,), single=True,
        )
        convs = test_db.sql(
            "SELECT COUNT(DISTINCT tmsg_ref_conv_id) as cnt FROM tapestry_messages WHERE tmsg_agent = ?",
            (agent,), single=True,
        )

    return {
        "conversations": convs["cnt"] if convs else 0,
        "messages": msgs["cnt"] if msgs else 0,
    }


def import_context(
    prod_db_path: str,
    test_db: Database,
    agent: str,
    date_start: str,
    date_end: str,
    mode: str = "both",
    bt_id: int | None = None,
) -> dict:
    """Import production summaries into test DB. Additive, non-destructive.

    Args:
        mode: 'pre' (before date_start), 'in' (within range), or 'both'.
        bt_id: Benchmark test ID to stamp on imported rows.

    Returns:
        Dict with 'summaries' count.
    """
    # Disable FKs during import — parent summaries and agents may not exist yet
    test_db.sql("PRAGMA foreign_keys = OFF")
    test_db.sql("ATTACH DATABASE ? AS prod", (prod_db_path,))

    # Ensure agents exist in test DB with prod IDs (FK target for tap_agent_id)
    test_db.sql("DELETE FROM tapestry_agents")
    test_db.sql(
        """INSERT INTO tapestry_agents (agent_id, agent_name, agent_color, agent_created)
           SELECT agent_id, agent_name, agent_color, agent_created FROM prod.tapestry_agents"""
    )

    # Get prod columns (excludes bt_id which doesn't exist in prod)
    shared_cols = ", ".join(
        c["name"] for c in test_db.sql("PRAGMA prod.table_info(tapestry)")
    )

    if mode in ("pre", "both"):
        test_db.sql(
            f"""INSERT OR IGNORE INTO tapestry ({shared_cols})
               SELECT {shared_cols} FROM prod.tapestry
               WHERE tap_agent = ? AND tap_date < ?""",
            (agent, date_start),
        )

    if mode in ("in", "both"):
        test_db.sql(
            f"""INSERT OR IGNORE INTO tapestry ({shared_cols})
               SELECT {shared_cols} FROM prod.tapestry
               WHERE tap_agent = ? AND tap_date BETWEEN ? AND ?""",
            (agent, date_start, date_end),
        )

    test_db.sql("DETACH DATABASE prod")
    test_db.sql("PRAGMA foreign_keys = ON")

    # Stamp bt_id on imported rows
    if bt_id is not None:
        test_db.sql(
            "UPDATE tapestry SET bt_id = ? WHERE tap_agent = ? AND bt_id IS NULL",
            (bt_id, agent),
        )

    if bt_id is not None:
        sums = test_db.sql(
            "SELECT COUNT(*) as cnt FROM tapestry WHERE bt_id = ?",
            (bt_id,), single=True,
        )
    else:
        sums = test_db.sql(
            "SELECT COUNT(*) as cnt FROM tapestry WHERE tap_agent = ?",
            (agent,), single=True,
        )

    return {"summaries": sums["cnt"] if sums else 0}


def wipe_test_data(
    test_db: Database,
    agent: str,
    prod_db_path: str | None = None,
    bt_id: int | None = None,
) -> None:
    """Wipe generated data from test DB. Keep messages.

    When bt_id is provided, deletes only data for that test run.
    Otherwise falls back to agent-based deletion.

    If prod_db_path is given, also clears benchmark_matches by bt_id
    (benchmark_tests lives in production DB).
    """
    if bt_id is not None:
        # Scoped wipe -- only this test run
        test_db.sql("PRAGMA foreign_keys = OFF")
        test_db.sql("DELETE FROM benchmark_matches WHERE bt_id = ?", (bt_id,))
        test_db.sql("DELETE FROM benchmark_topics WHERE bt_id = ?", (bt_id,))
        test_db.sql("DELETE FROM benchmark_results WHERE bt_id = ?", (bt_id,))
        test_db.sql("DELETE FROM benchmark_summaries WHERE bt_id = ?", (bt_id,))
        test_db.sql("DELETE FROM tapestry WHERE bt_id = ?", (bt_id,))
        test_db.sql("PRAGMA foreign_keys = ON")
        return

    # Legacy agent-scoped wipe
    if prod_db_path:
        test_db.sql("ATTACH DATABASE ? AS prod", (prod_db_path,))
        test_ids = test_db.sql(
            "SELECT bt_id FROM prod.benchmark_tests WHERE bt_agent = ?", (agent,),
        )
        test_db.sql("DETACH DATABASE prod")
        if test_ids:
            placeholders = ",".join("?" * len(test_ids))
            test_db.sql(
                f"DELETE FROM benchmark_matches WHERE bt_id IN ({placeholders})",
                tuple(r["bt_id"] for r in test_ids),
            )

    test_db.sql("PRAGMA foreign_keys = OFF")
    test_db.sql("DELETE FROM benchmark_topics WHERE btop_agent = ?", (agent,))
    test_db.sql("DELETE FROM benchmark_results WHERE bench_agent = ?", (agent,))
    test_db.sql("DELETE FROM benchmark_summaries WHERE bsum_agent = ?", (agent,))
    test_db.sql("DELETE FROM tapestry WHERE tap_agent = ?", (agent,))
    test_db.sql("PRAGMA foreign_keys = ON")


# ---------------------------------------------------------------------------
# RY score computation
# ---------------------------------------------------------------------------

def _compute_ry(test_db: Database, agent: str, bt_id: int) -> dict:
    """Compute RY factor from benchmark_matches and benchmark_topics.

    RY = CA_only / (Matched + CA_only)
    where Matched = LLM-confirmed distinct CA topics.

    Returns:
        Dict with 'ry_score', 'matched', 'ca_only', 'cf_only'.
    """
    ca_total = test_db.sql(
        "SELECT COUNT(*) as cnt FROM benchmark_topics WHERE btop_agent = ? AND btop_track = 'context-aware' AND bt_id = ?",
        (agent, bt_id), single=True,
    )
    matched_ca = test_db.sql(
        """SELECT COUNT(DISTINCT btop_ca_id) as cnt FROM benchmark_matches
           WHERE bt_id = ? AND btop_ca_id IS NOT NULL AND llm_confirmed = 1""",
        (bt_id,), single=True,
    )
    cf_only = test_db.sql(
        """SELECT COUNT(*) as cnt FROM benchmark_matches
           WHERE bt_id = ? AND btop_ca_id IS NULL""",
        (bt_id,), single=True,
    )

    ca_count = ca_total["cnt"] if ca_total else 0
    m_count = matched_ca["cnt"] if matched_ca else 0
    ca_only_count = ca_count - m_count
    total = m_count + ca_only_count
    ry_score = round(ca_only_count / total, 4) if total > 0 else 0

    return {
        "ry_score": ry_score,
        "matched": m_count,
        "ca_only": ca_only_count,
        "cf_only": cf_only["cnt"] if cf_only else 0,
    }


# ---------------------------------------------------------------------------
# Main orchestrator
# ---------------------------------------------------------------------------

def run_benchmark(
    prod_db_path: str,
    test_db_path: str,
    agent: str,
    date_start: str,
    date_end: str,
    bt_id: int,
    *,
    llm: LLMClient | None = None,
    config: TapestryConfig | None = None,
    delay: float = 0.5,
    progress: callable | None = None,
) -> dict:
    """Run the full benchmark pipeline end-to-end.

    Args:
        prod_db_path: Path to production tapestry.db.
        test_db_path: Path to test_benchmark.db.
        agent: Agent name to benchmark.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        bt_id: benchmark_tests record ID (in production DB).
        llm: LLM client (created automatically if None).
        config: Tapestry config (created automatically if None).
        delay: Seconds between LLM calls.
        progress: Optional callback(step, detail, pct).

    Returns:
        Dict with ry_score, matched, ca_only, cf_only, and per-step results.
    """
    from tapestry import Tapestry
    from tapestry.db import Database
    from tapestry.schema import init_db
    from tapestry.engine.benchmark import generate_context_free
    from tapestry.engine.topic_benchmark import (
        extract_topics_per_conversation,
        llm_verify_matches,
        sbert_match_per_conversation,
    )

    results = {}

    # Open test DB
    test_db = Database(test_db_path)
    init_db(test_db)

    # Get LLM client from a production Tapestry instance if not provided
    own_tapestry = None
    if llm is None or config is None:
        own_tapestry = Tapestry()
        llm = own_tapestry.llm
        config = own_tapestry.config

    try:
        # -- Step 1: Import messages --
        _notify(progress, "import", "Importing messages from production")
        results["import"] = import_messages(
            prod_db_path, test_db, agent, date_start, date_end, bt_id=bt_id,
        )
        _notify(progress, "import",
                f'{results["import"]["conversations"]} conversations, '
                f'{results["import"]["messages"]} messages')
        _debug_dump(test_db, agent, bt_id, "Step 1: import_messages", date_start, date_end)

        # -- Step 2: Import context --
        _notify(progress, "import-context", "Importing pre-range and in-range summaries")
        results["import_context"] = import_context(
            prod_db_path, test_db, agent, date_start, date_end, mode="both",
            bt_id=bt_id,
        )
        _notify(progress, "import-context",
                f'{results["import_context"]["summaries"]} summaries imported')
        _debug_dump(test_db, agent, bt_id, "Step 2: import_context", date_start, date_end)

        # -- Step 3: Build CA hierarchy --
        _notify(progress, "build-ca", "Building context-aware hierarchy via iterate")
        with Tapestry(db_path=str(test_db_path)) as t_test:
            ca_stats = t_test.iterate(
                end_date=date_end, agent=agent, save=True,
            )
        results["build_ca"] = ca_stats

        # Stamp bt_id on newly generated CA summaries
        test_db = Database(test_db_path)
        init_db(test_db)
        test_db.sql(
            "UPDATE tapestry SET bt_id = ? WHERE tap_agent = ? AND bt_id IS NULL",
            (bt_id, agent),
        )
        _notify(progress, "build-ca",
                f'L0:{ca_stats.get("l0", 0)} L1:{ca_stats.get("l1", 0)} '
                f'L2:{ca_stats.get("l2", 0)} L3:{ca_stats.get("l3", 0)}')
        _debug_dump(test_db, agent, bt_id, "Step 3: build_ca", date_start, date_end)

        # -- Step 4: Build CF hierarchy --
        _notify(progress, "build-cf", "Generating context-free hierarchy")
        cf_stats = generate_context_free(
            test_db, llm, config, agent,
            date_start, date_end, delay=delay, bt_id=bt_id,
        )
        results["build_cf"] = cf_stats
        _notify(progress, "build-cf",
                f'L0:{cf_stats.get("l0", 0)} L1:{cf_stats.get("l1", 0)} '
                f'L2:{cf_stats.get("l2", 0)} L3:{cf_stats.get("l3", 0)}')
        _debug_dump(test_db, agent, bt_id, "Step 4: build_cf", date_start, date_end)

        # -- Step 5: Extract CA topics --
        _notify(progress, "extract-ca", "Extracting topics from CA L0 summaries")
        ca_topics = extract_topics_per_conversation(
            test_db, llm, agent, "context-aware",
            date_start=date_start, date_end=date_end, delay=delay, bt_id=bt_id,
        )
        results["extract_ca"] = ca_topics
        _notify(progress, "extract-ca",
                f'{ca_topics.get("topics", 0)} topics from '
                f'{ca_topics.get("conversations", 0)} conversations')
        _debug_dump(test_db, agent, bt_id, "Step 5: extract_ca", date_start, date_end)

        # -- Step 6: Extract CF topics --
        _notify(progress, "extract-cf", "Extracting topics from CF L0 summaries")
        cf_topics = extract_topics_per_conversation(
            test_db, llm, agent, "context-free",
            date_start=date_start, date_end=date_end, delay=delay, bt_id=bt_id,
        )
        results["extract_cf"] = cf_topics
        _notify(progress, "extract-cf",
                f'{cf_topics.get("topics", 0)} topics from '
                f'{cf_topics.get("conversations", 0)} conversations')
        _debug_dump(test_db, agent, bt_id, "Step 6: extract_cf", date_start, date_end)

        # -- Step 7: SBERT match --
        _notify(progress, "sbert-match", "Running SBERT pairwise matching")
        match_result = sbert_match_per_conversation(test_db, agent, bt_id)
        results["sbert_match"] = match_result
        _notify(progress, "sbert-match",
                f'{match_result["matched_count"]} matched, '
                f'{match_result["ca_only_count"]} CA-only, '
                f'{match_result["cf_only_count"]} CF-only')
        _debug_dump(test_db, agent, bt_id, "Step 7: sbert_match", date_start, date_end)

        # -- Step 8: LLM verify --
        _notify(progress, "llm-verify", "Verifying matches via LLM")
        verify_result = llm_verify_matches(test_db, llm, bt_id)
        results["llm_verify"] = verify_result
        _notify(progress, "llm-verify",
                f'{verify_result.get("confirmed_count", 0)} confirmed, '
                f'{verify_result.get("rejected_count", 0)} rejected')
        _debug_dump(test_db, agent, bt_id, "Step 8: llm_verify", date_start, date_end)

        # -- Step 9: Compute RY --
        _notify(progress, "score", "Computing RY factor")
        ry = _compute_ry(test_db, agent, bt_id)
        results["ry"] = ry

        # Update benchmark_tests in production DB
        prod_db = Database(prod_db_path)
        prod_db.sql(
            "UPDATE benchmark_tests SET bt_ry_score = ?, bt_matched = ?, bt_ca_only = ?, bt_cf_only = ?, bt_method = 'topics' WHERE bt_id = ?",
            (ry["ry_score"], ry["matched"], ry["ca_only"], ry["cf_only"], bt_id),
        )
        prod_db.close()

        _notify(progress, "score",
                f'RY = {ry["ry_score"]:.3f} '
                f'(matched={ry["matched"]}, CA-only={ry["ca_only"]}, CF-only={ry["cf_only"]})')

    finally:
        test_db.close()
        if own_tapestry:
            own_tapestry.close()

    return {
        "ry_score": ry["ry_score"],
        "matched": ry["matched"],
        "ca_only": ry["ca_only"],
        "cf_only": ry["cf_only"],
        "steps": results,
    }


# ---------------------------------------------------------------------------
# Batch mode
# ---------------------------------------------------------------------------

def run_batch(
    prod_db_path: str,
    test_db_path: str,
    specs: list[dict],
    *,
    delay: float = 0.5,
    progress: callable | None = None,
) -> list[dict]:
    """Run benchmarks for multiple agent/date-range combos sequentially.

    Args:
        specs: List of dicts with 'agent', 'date_start', 'date_end' keys.
        progress: Optional callback(step, detail, pct).

    Returns:
        List of result dicts, one per spec.
    """
    from tapestry import Tapestry
    from tapestry.db import Database
    from tapestry.schema import init_db

    results = []

    # Open one Tapestry instance for LLM access across all runs
    with Tapestry() as t:
        prod_db = Database(prod_db_path)

        for i, spec in enumerate(specs):
            agent = spec["agent"]
            date_start = spec["date_start"]
            date_end = spec["date_end"]

            if progress:
                progress("batch", f"Run {i + 1}/{len(specs)}: {agent} {date_start} to {date_end}", 0)

            # Reuse existing bt_id if provided, otherwise create new record
            existing_bt_id = spec.get("bt_id")
            if existing_bt_id:
                bt_id = existing_bt_id
            else:
                bt_id = prod_db.sql(
                    """INSERT INTO benchmark_tests (bt_agent, bt_date_start, bt_date_end, bt_method)
                       VALUES (?, ?, ?, 'topics')""",
                    (agent, date_start, date_end),
                )

            # Wipe test data between runs
            test_db = Database(test_db_path)
            init_db(test_db)
            wipe_test_data(test_db, agent, prod_db_path, bt_id=bt_id)
            # Also wipe messages for a clean slate
            test_db.sql("DELETE FROM tapestry_messages WHERE bt_id = ?", (bt_id,))
            test_db.close()

            result = run_benchmark(
                prod_db_path, test_db_path, agent, date_start, date_end, bt_id,
                llm=t.llm, config=t.config, delay=delay, progress=progress,
            )
            result["agent"] = agent
            result["date_start"] = date_start
            result["date_end"] = date_end
            result["bt_id"] = bt_id
            results.append(result)

        prod_db.close()

    return results
