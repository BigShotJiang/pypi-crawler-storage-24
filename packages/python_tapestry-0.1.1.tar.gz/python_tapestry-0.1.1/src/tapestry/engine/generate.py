"""Summary generation for all tapestry levels (L0 through L4).

All functions are idempotent — they skip if a summary already exists.
"""

from __future__ import annotations

import calendar
from datetime import datetime
from typing import TYPE_CHECKING

from tapestry.engine.chunking import (
    format_transcript,
    needs_chunking,
    summarize_chunked,
)
from tapestry.engine.prompts import (
    context_preamble,
    daily_prompt,
    factual_prompt,
    monthly_prompt,
    title_prompt,
    weekly_prompt,
    yearly_prompt,
)

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.db import Database
    from tapestry.llm import LLMClient


def auto_generate_l0(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    conv_id: str,
    context_items: list[dict] | None = None,
) -> int | None:
    """Generate and store a Level 0 factual summary.

    Args:
        db: Database instance.
        llm: LLM client for API calls.
        config: Tapestry configuration (for agent_name, user_name).
        agent: Agent name string.
        conv_id: Conversation ID to summarize.
        context_items: Optional prior context for richer summaries.

    Returns:
        tap_id of the created record, or existing tap_id if already exists,
        or None if no messages found.
    """
    # Idempotent — skip if L0 already exists for this conversation
    existing = db.sql(
        "SELECT tap_id FROM tapestry WHERE tap_source = ? AND tap_level = 0",
        (conv_id,),
        single=True,
    )
    if existing:
        return existing["tap_id"]

    # Fetch messages
    rows = db.sql(
        """SELECT tmsg_role, tmsg_content, tmsg_timestamp
           FROM tapestry_messages WHERE tmsg_ref_conv_id = ?
           ORDER BY tmsg_order""",
        (conv_id,),
    )
    if not rows:
        return None

    # Build transcript
    agent_label = config.agent_name.upper()
    user_label = config.user_name.upper()
    transcript_text = format_transcript(rows, agent_label, user_label)

    # Generate title
    title = llm.title([
        {"role": "system", "content": title_prompt(0)},
        {"role": "user", "content": transcript_text},
    ])

    # Build system prompt with optional context
    system = factual_prompt(config.agent_name, config.user_name)
    preamble = context_preamble(context_items) if context_items else ""
    if preamble:
        system = preamble + "\n\n---\n\n" + system

    # Generate content — chunked if conversation exceeds context window
    chunk_size = config.llm.chunk_size_tokens
    from tapestry.engine.chunking import estimate_tokens
    total_tokens = estimate_tokens(transcript_text)
    if needs_chunking(rows, agent_label, user_label, chunk_size):
        print(f"[L0] Conversation {conv_id}: ~{total_tokens:,} tokens — using chunked summarization")
        content, _stats = summarize_chunked(
            rows, llm, config, system, agent_label, user_label, chunk_size,
        )
    else:
        print(f"[L0] Conversation {conv_id}: ~{total_tokens:,} tokens — single pass")
        content = llm.request([
            {"role": "system", "content": system},
            {"role": "user", "content": transcript_text},
        ])

    # Determine date from last message timestamp
    last_ts = rows[-1]["tmsg_timestamp"]
    conv_date = last_ts[:10] if last_ts else datetime.now().strftime("%Y-%m-%d")

    # Store
    tap_id = db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
           VALUES (?, ?, 0, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, conv_date, conv_id),
    )

    # Link messages to this L0
    db.sql(
        "UPDATE tapestry_messages SET tmsg_tap_id = ? WHERE tmsg_ref_conv_id = ?",
        (tap_id, conv_id),
    )

    # Re-link to existing daily if one exists for this date
    daily = db.sql(
        "SELECT tap_id FROM tapestry WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?",
        (conv_date, agent_id),
        single=True,
    )
    if daily:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (daily["tap_id"], tap_id),
        )

    return tap_id


def auto_generate_daily(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    date_str: str,
) -> int | None:
    """Generate and store a Level 1 daily summary from L0s.

    Args:
        db: Database instance.
        llm: LLM client for API calls.
        config: Tapestry configuration.
        agent: Agent name string.
        date_str: YYYY-MM-DD date to summarize.

    Returns:
        tap_id of the created record, or existing tap_id if already exists,
        or None if no L0s found for the date.
    """
    # Idempotent
    existing = db.sql(
        "SELECT tap_id FROM tapestry WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?",
        (date_str, agent_id),
        single=True,
    )
    if existing:
        return existing["tap_id"]

    # Fetch L0s for this date
    l0s = db.sql(
        """SELECT tap_id, tap_title, tap_content
           FROM tapestry
           WHERE tap_level = 0 AND tap_date = ? AND tap_agent_id = ?
           ORDER BY tap_id""",
        (date_str, agent_id),
    )
    if not l0s:
        return None

    # Build input
    input_parts = []
    for i, s in enumerate(l0s):
        input_parts.append(f"### Session {i+1}: {s['tap_title']}")
        input_parts.append(s["tap_content"])
        input_parts.append("")
    input_text = "\n".join(input_parts)

    # Generate title
    title = llm.title([
        {"role": "system", "content": title_prompt(1)},
        {"role": "user", "content": input_text},
    ])

    # Generate content
    content = llm.request([
        {"role": "system", "content": daily_prompt(config.agent_name, date_str)},
        {"role": "user", "content": input_text},
    ])

    # Store
    source = ",".join(str(s["tap_id"]) for s in l0s)
    tap_id = db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source)
           VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, date_str, date_str, date_str, source),
    )

    # Link L0s as children
    for s in l0s:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (tap_id, s["tap_id"]),
        )

    # Re-link to existing weekly if one covers this date
    weekly = db.sql(
        """SELECT tap_id FROM tapestry WHERE tap_level = 2 AND tap_agent_id = ?
           AND tap_date_start <= ? AND tap_date_end >= ?""",
        (agent_id, date_str, date_str),
        single=True,
    )
    if weekly:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (weekly["tap_id"], tap_id),
        )

    return tap_id


def auto_generate_weekly(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    start_date: str,
    end_date: str,
) -> int | None:
    """Generate and store a Level 2 weekly summary from dailies.

    Args:
        db: Database instance.
        llm: LLM client for API calls.
        config: Tapestry configuration.
        agent: Agent name string.
        start_date: YYYY-MM-DD week start.
        end_date: YYYY-MM-DD week end.

    Returns:
        tap_id of the created record, or existing tap_id if already exists,
        or None if no dailies found in the range.
    """
    # Idempotent
    existing = db.sql(
        """SELECT tap_id FROM tapestry WHERE tap_level = 2 AND tap_agent_id = ?
           AND tap_date_start = ? AND tap_date_end = ?""",
        (agent_id, start_date, end_date),
        single=True,
    )
    if existing:
        return existing["tap_id"]

    # Fetch dailies in this range
    dailies = db.sql(
        """SELECT tap_id, tap_date, tap_title, tap_content
           FROM tapestry
           WHERE tap_level = 1 AND tap_date >= ? AND tap_date <= ? AND tap_agent_id = ?
           ORDER BY tap_date""",
        (start_date, end_date, agent_id),
    )
    if not dailies:
        return None

    # Build input
    input_parts = []
    for d in dailies:
        input_parts.append(f"### {d['tap_date']}: {d['tap_title']}")
        input_parts.append(d["tap_content"])
        input_parts.append("")
    input_text = "\n".join(input_parts)

    # Generate title
    title = llm.title([
        {"role": "system", "content": title_prompt(2)},
        {"role": "user", "content": input_text},
    ])

    # Generate content
    content = llm.request([
        {"role": "system", "content": weekly_prompt(config.agent_name, start_date, end_date)},
        {"role": "user", "content": input_text},
    ])

    # Store
    source = ",".join(str(d["tap_id"]) for d in dailies)
    tap_id = db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source)
           VALUES (?, ?, 2, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, start_date, start_date, end_date, source),
    )

    # Link dailies as children
    for d in dailies:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (tap_id, d["tap_id"]),
        )

    # Re-link to existing monthly if one covers this range
    monthly = db.sql(
        """SELECT tap_id FROM tapestry WHERE tap_level = 3 AND tap_agent_id = ?
           AND tap_date_start <= ? AND tap_date_end >= ?""",
        (agent_id, start_date, end_date),
        single=True,
    )
    if monthly:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (monthly["tap_id"], tap_id),
        )

    return tap_id


def auto_generate_monthly(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    year: int,
    month: int,
) -> int | None:
    """Generate and store a Level 3 monthly summary from weeklies.

    Args:
        db: Database instance.
        llm: LLM client for API calls.
        config: Tapestry configuration.
        agent: Agent name string.
        year: Calendar year.
        month: Calendar month (1-12).

    Returns:
        tap_id of the created record, or existing tap_id if already exists,
        or None if no weeklies found for the month.
    """
    month_start = f"{year}-{month:02d}-01"
    month_end = f"{year}-{month:02d}-{calendar.monthrange(year, month)[1]:02d}"

    # Idempotent
    existing = db.sql(
        """SELECT tap_id FROM tapestry WHERE tap_level = 3 AND tap_agent_id = ?
           AND tap_date_start = ? AND tap_date_end = ?""",
        (agent_id, month_start, month_end),
        single=True,
    )
    if existing:
        return existing["tap_id"]

    # Fetch weeklies whose range falls within this month
    weeklies = db.sql(
        """SELECT tap_id, tap_date_start, tap_date_end, tap_title, tap_content
           FROM tapestry
           WHERE tap_level = 2 AND tap_agent_id = ?
           AND tap_date_start >= ? AND tap_date_end <= ?
           ORDER BY tap_date_start""",
        (agent_id, month_start, month_end),
    )
    if not weeklies:
        return None

    # Build input
    input_parts = []
    for w in weeklies:
        input_parts.append(f"### {w['tap_date_start']} to {w['tap_date_end']}: {w['tap_title']}")
        input_parts.append(w["tap_content"])
        input_parts.append("")
    input_text = "\n".join(input_parts)

    # Generate title
    month_name = calendar.month_name[month]
    title = llm.title([
        {"role": "system", "content": title_prompt(3)},
        {"role": "user", "content": input_text},
    ])

    # Generate content
    content = llm.request([
        {"role": "system", "content": monthly_prompt(config.agent_name, month_name, year)},
        {"role": "user", "content": input_text},
    ])

    # Store
    source = ",".join(str(w["tap_id"]) for w in weeklies)
    tap_id = db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source)
           VALUES (?, ?, 3, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, month_start, month_start, month_end, source),
    )

    # Link weeklies as children
    for w in weeklies:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (tap_id, w["tap_id"]),
        )

    return tap_id


def auto_generate_yearly(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    year: int,
) -> int | None:
    """Generate and store a Level 4 yearly summary from monthlies.

    Args:
        db: Database instance.
        llm: LLM client for API calls.
        config: Tapestry configuration.
        agent: Agent name string.
        year: Calendar year.

    Returns:
        tap_id of the created record, or existing tap_id if already exists,
        or None if no monthlies found for the year.
    """
    year_start = f"{year}-01-01"
    year_end = f"{year}-12-31"

    # Idempotent
    existing = db.sql(
        """SELECT tap_id FROM tapestry WHERE tap_level = 4 AND tap_agent_id = ?
           AND tap_date_start = ? AND tap_date_end = ?""",
        (agent_id, year_start, year_end),
        single=True,
    )
    if existing:
        return existing["tap_id"]

    # Fetch monthlies for this year
    monthlies = db.sql(
        """SELECT tap_id, tap_date_start, tap_date_end, tap_title, tap_content
           FROM tapestry
           WHERE tap_level = 3 AND tap_agent_id = ?
           AND tap_date_start >= ? AND tap_date_end <= ?
           ORDER BY tap_date_start""",
        (agent_id, year_start, year_end),
    )
    if not monthlies:
        return None

    # Build input
    input_parts = []
    for m in monthlies:
        input_parts.append(f"### {m['tap_date_start']} to {m['tap_date_end']}: {m['tap_title']}")
        input_parts.append(m["tap_content"])
        input_parts.append("")
    input_text = "\n".join(input_parts)

    # Generate title
    title = llm.title([
        {"role": "system", "content": title_prompt(4)},
        {"role": "user", "content": input_text},
    ])

    # Generate content
    content = llm.request([
        {"role": "system", "content": yearly_prompt(config.agent_name, year)},
        {"role": "user", "content": input_text},
    ])

    # Store
    source = ",".join(str(m["tap_id"]) for m in monthlies)
    tap_id = db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source)
           VALUES (?, ?, 4, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, year_start, year_start, year_end, source),
    )

    # Link monthlies as children
    for m in monthlies:
        db.sql(
            "UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?",
            (tap_id, m["tap_id"]),
        )

    return tap_id
