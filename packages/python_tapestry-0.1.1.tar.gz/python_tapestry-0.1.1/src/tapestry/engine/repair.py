"""Self-repair cascade for tapestry hierarchy gaps.

When a summary is missing at any level, repair walks downward ensuring
all child summaries exist before generating the missing parent.
"""

from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import TYPE_CHECKING

from tapestry.engine.context import _repair
from tapestry.engine.generate import (
    auto_generate_daily,
    auto_generate_l0,
    auto_generate_monthly,
    auto_generate_weekly,
    auto_generate_yearly,
)
from tapestry.engine.rollup import conversations_in_range, weeks_in_month

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.db import Database
    from tapestry.llm import LLMClient


def repair_weekly(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    repair_item: dict,
    generated: dict[str, int],
    log: callable | None = None,
) -> None:
    """Repair a single weekly summary — ensure dailies exist, then generate weekly.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        repair_item: Dict with 'start', 'end', 'range' keys.
        generated: Mutable counter dict (l0, l1, l2, l3 keys).
        log: Optional callable for progress output.
    """
    if log:
        log(f"  REPAIR L2 weekly {repair_item['range']}...")

    range_start = date.fromisoformat(repair_item["start"])
    range_end = date.fromisoformat(repair_item["end"])
    d = range_start

    while d <= range_end:
        day_convs = conversations_in_range(db, agent, agent_id, str(d), str(d))
        if day_convs:
            daily_exists = db.sql(
                "SELECT tap_id FROM tapestry WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?",
                (str(d), agent_id),
                single=True,
            )
            if not daily_exists:
                # Ensure L0s exist for this day first
                for conv in day_convs:
                    existing_l0 = db.sql(
                        "SELECT tap_id FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                        (conv["tmsg_ref_conv_id"],),
                        single=True,
                    )
                    if not existing_l0:
                        if log:
                            log(f"    REPAIR L0 {conv['tmsg_ref_conv_id'][:8]}...")
                        tid = auto_generate_l0(db, llm, config, agent, agent_id, conv["tmsg_ref_conv_id"])
                        if tid:
                            generated["l0"] += 1

                if log:
                    log(f"    REPAIR L1 daily {d}...")
                tid = auto_generate_daily(db, llm, config, agent, agent_id, str(d))
                if tid:
                    generated["l1"] += 1
        d += timedelta(days=1)

    # Now generate weekly
    tap_id = auto_generate_weekly(db, llm, config, agent, agent_id, repair_item["start"], repair_item["end"])
    if tap_id:
        generated["l2"] += 1
        if log:
            title = db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            log(f"    -> tap_id={tap_id}: {title['tap_title']}")


def repair_monthly(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    repair_item: dict,
    generated: dict[str, int],
    log: callable | None = None,
) -> None:
    """Repair a monthly summary — ensure all weeks exist, then generate monthly.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        repair_item: Dict with 'start', 'end', 'range' keys.
        generated: Mutable counter dict.
        log: Optional callable for progress output.
    """
    repair_month = date.fromisoformat(repair_item["start"])
    if log:
        log(f"  REPAIR L3 monthly {repair_item['range']}...")

    # Build all weeks in this month
    for ws, we in weeks_in_month(repair_month.year, repair_month.month):
        weekly_exists = db.sql(
            """SELECT tap_id FROM tapestry WHERE tap_level = 2 AND tap_agent_id = ?
               AND tap_date_start = ? AND tap_date_end = ?""",
            (agent_id, str(ws), str(we)),
            single=True,
        )
        if weekly_exists:
            continue
        # Check if any conversations exist in this week
        week_convs = conversations_in_range(db, agent, agent_id, str(ws), str(we))
        if not week_convs:
            continue
        week_repair = _repair(
            2,
            f"{ws.strftime('%b %d')}-{we.strftime('%b %d')}",
            str(ws),
            str(we),
            len(week_convs),
        )
        repair_weekly(db, llm, config, agent, agent_id, week_repair, generated, log)

    # Now generate monthly
    tap_id = auto_generate_monthly(db, llm, config, agent, agent_id, repair_month.year, repair_month.month)
    if tap_id:
        generated["l3"] += 1
        if log:
            title = db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            log(f"    -> tap_id={tap_id}: {title['tap_title']}")


def repair_yearly(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    repair_item: dict,
    generated: dict[str, int],
    log: callable | None = None,
) -> None:
    """Repair a yearly summary — ensure all monthlies exist, then generate yearly.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        repair_item: Dict with 'start', 'end', 'range' keys.
        generated: Mutable counter dict.
        log: Optional callable for progress output.
    """
    year = date.fromisoformat(repair_item["start"]).year
    if log:
        log(f"  REPAIR L4 yearly {year}...")

    # Check each month in this year for missing monthlies
    for month in range(1, 13):
        month_start = f"{year}-{month:02d}-01"
        last_day = calendar.monthrange(year, month)[1]
        month_end = f"{year}-{month:02d}-{last_day:02d}"

        monthly_exists = db.sql(
            """SELECT tap_id FROM tapestry WHERE tap_level = 3 AND tap_agent_id = ?
               AND tap_date_start = ? AND tap_date_end = ?""",
            (agent_id, month_start, month_end),
            single=True,
        )
        if monthly_exists:
            continue

        # Check if any conversations exist in this month
        month_convs = conversations_in_range(db, agent, agent_id, month_start, month_end)
        if not month_convs:
            continue

        month_repair = _repair(
            3,
            f"{calendar.month_name[month]} {year}",
            month_start,
            month_end,
            len(month_convs),
        )
        repair_monthly(db, llm, config, agent, agent_id, month_repair, generated, log)

    # Now generate yearly
    tap_id = auto_generate_yearly(db, llm, config, agent, agent_id, year)
    if tap_id:
        generated["l4"] += 1
        if log:
            title = db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            log(f"    -> tap_id={tap_id}: {title['tap_title']}")


def repair_from_first_gap(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    agent_id: int,
    repairs: list[dict],
    log: callable | None = None,
) -> dict[str, int]:
    """Repair all gaps detected by resolve_context.

    Processes repairs bottom-up (L0 -> L1 -> L2 -> L3 -> L4) so children
    exist before parents are generated. Follows the Butiri Effect rule:
    sequential, bottom-up, with full context.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        repairs: The repairs_needed list from resolve_context().
        log: Optional callable for progress output.

    Returns:
        Dict with l0, l1, l2, l3, l4 generation counts.
    """
    generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0, "l4": 0}

    if not repairs:
        return generated

    if log:
        log(f"Self-healing: {len(repairs)} gap(s) detected, repairing...")

    # Sort by level — bottom-up repair
    for repair_item in sorted(repairs, key=lambda r: r["level"]):
        level = repair_item["level"]

        if level == 0:
            # Generate missing L0s for conversations on this date
            convs = conversations_in_range(db, agent, agent_id, repair_item["start"], repair_item["end"])
            for conv in convs:
                existing = db.sql(
                    "SELECT tap_id FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                    (conv["tmsg_ref_conv_id"],),
                    single=True,
                )
                if not existing:
                    if log:
                        log(f"  REPAIR L0 {conv['tmsg_ref_conv_id'][:8]}...")
                    tid = auto_generate_l0(db, llm, config, agent, agent_id, conv["tmsg_ref_conv_id"])
                    if tid:
                        generated["l0"] += 1

        elif level == 1:
            if log:
                log(f"  REPAIR L1 daily {repair_item['range']}...")
            # Ensure L0s exist first
            convs = conversations_in_range(db, agent, agent_id, repair_item["start"], repair_item["end"])
            for conv in convs:
                existing = db.sql(
                    "SELECT tap_id FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                    (conv["tmsg_ref_conv_id"],),
                    single=True,
                )
                if not existing:
                    tid = auto_generate_l0(db, llm, config, agent, agent_id, conv["tmsg_ref_conv_id"])
                    if tid:
                        generated["l0"] += 1
            tid = auto_generate_daily(db, llm, config, agent, agent_id, repair_item["start"])
            if tid:
                generated["l1"] += 1

        elif level == 2:
            repair_weekly(db, llm, config, agent, agent_id, repair_item, generated, log)

        elif level == 3:
            repair_monthly(db, llm, config, agent, agent_id, repair_item, generated, log)

        elif level == 4:
            repair_yearly(db, llm, config, agent, agent_id, repair_item, generated, log)

    total = sum(generated.values())
    if log:
        log(
            f"Self-healing complete: {total} summaries generated"
            f" (L0={generated['l0']}, L1={generated['l1']}, L2={generated['l2']},"
            f" L3={generated['l3']}, L4={generated['l4']})"
        )

    return generated
