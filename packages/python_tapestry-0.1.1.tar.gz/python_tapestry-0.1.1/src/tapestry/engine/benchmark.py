"""Benchmark engine for measuring Recall Yield (RY Factor).

Compares context-aware summaries (generated with telescoping context via iterate)
against context-free summaries (generated in isolation via catchup-style prompts).

Flow:
1. snapshot_context_aware() — copies existing tapestry summaries into benchmark_summaries
2. generate_context_free() — generates new summaries without telescoping context,
   stores them in benchmark_summaries
3. score() — runs similarity scoring across both tracks, writes to benchmark_results

Both tracks are frozen snapshots. Scoring never touches the production tapestry table.
"""

from __future__ import annotations

import calendar
import time
from datetime import date
from typing import TYPE_CHECKING

from tqdm import tqdm

from tapestry.engine.scoring import SCORING_METHODS, score_pair
from tapestry.engine.prompts import (
    context_preamble,
    daily_prompt,
    factual_prompt,
    monthly_prompt,
    title_prompt,
    weekly_prompt,
    yearly_prompt,
)
from tapestry.engine.rollup import conversations_in_range, weeks_in_month

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.db import Database
    from tapestry.llm import LLMClient


# ---------------------------------------------------------------------------
# 1. Snapshot context-aware summaries from production tapestry table
# ---------------------------------------------------------------------------

def snapshot_context_aware(
    db: Database,
    agent: str,
    date_start: str,
    date_end: str,
    log: callable | None = None,
    bt_id: int | None = None,
) -> int:
    """Copy context-aware summaries from tapestry into benchmark_summaries.

    Copies all summaries (L0-L4) for the given agent whose tap_date falls
    within the date range. Skips records already snapshotted (by tap_id).

    Args:
        db: Database instance.
        agent: Agent name.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        log: Optional progress callback.

    Returns:
        Number of records copied.
    """
    # Fetch all summaries in range
    rows = db.sql(
        """SELECT tap_id, tap_agent, tap_level, tap_date, tap_date_start,
                  tap_date_end, tap_title, tap_content, tap_source
           FROM tapestry
           WHERE tap_agent = ? AND tap_date >= ? AND tap_date <= ?
           ORDER BY tap_level, tap_date""",
        (agent, date_start, date_end),
    )

    if not rows:
        if log:
            log(f"No summaries found for {agent} in {date_start} to {date_end}")
        return 0

    copied = 0
    for row in rows:
        # Skip if already snapshotted
        existing = db.sql(
            """SELECT bsum_id FROM benchmark_summaries
               WHERE bsum_tap_id = ? AND bsum_track = 'context-aware'""",
            (row["tap_id"],),
            single=True,
        )
        if existing:
            continue

        db.sql(
            """INSERT INTO benchmark_summaries
               (bsum_agent, bsum_level, bsum_date, bsum_date_start, bsum_date_end,
                bsum_track, bsum_title, bsum_content, bsum_source, bsum_tap_id, bt_id)
               VALUES (?, ?, ?, ?, ?, 'context-aware', ?, ?, ?, ?, ?)""",
            (
                row["tap_agent"],
                row["tap_level"],
                row["tap_date"],
                row["tap_date_start"],
                row["tap_date_end"],
                row["tap_title"],
                row["tap_content"],
                row["tap_source"],
                row["tap_id"],
                bt_id,
            ),
        )
        copied += 1

    if log:
        log(f"Snapshotted {copied} context-aware summaries for {agent}")
    return copied


# ---------------------------------------------------------------------------
# 2. Generate context-free summaries (no telescoping context)
# ---------------------------------------------------------------------------

def _generate_cf_l0(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    conv_id: str,
    conv_date: str,
    bt_id: int | None = None,
) -> dict | None:
    """Generate a context-free L0 summary and store in benchmark_summaries.

    Same as auto_generate_l0 but WITHOUT context_items (no telescoping)
    and writes to benchmark_summaries instead of tapestry.

    Returns:
        Dict with bsum_id, bsum_title, bsum_content, or None if no messages.
    """
    # Skip if already generated
    if bt_id is not None:
        existing = db.sql(
            """SELECT bsum_id, bsum_title, bsum_content FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_source = ?
               AND bsum_track = 'context-free' AND bt_id = ?""",
            (agent, conv_id, bt_id),
            single=True,
        )
    else:
        existing = db.sql(
            """SELECT bsum_id, bsum_title, bsum_content FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_source = ?
               AND bsum_track = 'context-free'""",
            (agent, conv_id),
            single=True,
        )
    if existing:
        return existing

    # Fetch raw messages
    rows = db.sql(
        """SELECT tmsg_role, tmsg_content, tmsg_timestamp
           FROM tapestry_messages WHERE tmsg_ref_conv_id = ?
           ORDER BY tmsg_order""",
        (conv_id,),
    )
    if not rows:
        return None

    # Build transcript
    agent_label = config.agent_name.upper()
    user_label = config.user_name.upper()
    transcript = []
    for r in rows:
        role = user_label if r["tmsg_role"] == "user" else agent_label
        transcript.append(f"[{role}]: {r['tmsg_content']}")
    transcript_text = "\n\n".join(transcript)
    # Generate title
    title = llm.title([
        {"role": "system", "content": title_prompt(0)},
        {"role": "user", "content": transcript_text},
    ])

    # Generate content — NO context preamble (context-free)
    system = factual_prompt(config.agent_name, config.user_name)
    content = llm.request([
        {"role": "system", "content": system},
        {"role": "user", "content": transcript_text},
    ])

    # Store in benchmark_summaries
    bsum_id = db.sql(
        """INSERT INTO benchmark_summaries
           (bsum_agent, bsum_level, bsum_date, bsum_track, bsum_title,
            bsum_content, bsum_source, bt_id)
           VALUES (?, 0, ?, 'context-free', ?, ?, ?, ?)""",
        (agent, conv_date, title, content, conv_id, bt_id),
    )

    return {"bsum_id": bsum_id, "bsum_title": title, "bsum_content": content}


def _generate_cf_rollup(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    level: int,
    date_str: str,
    date_start: str,
    date_end: str,
    children: list[dict],
    prompt_fn: callable,
    prompt_args: tuple,
    bt_id: int | None = None,
) -> dict | None:
    """Generate a context-free rollup summary (L1-L4) and store in benchmark_summaries.

    Rolls up child benchmark_summaries records. No telescoping context.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        level: Summary level (1-4).
        date_str: Primary date for the record.
        date_start: Range start.
        date_end: Range end.
        children: List of dicts with bsum_id, bsum_title, bsum_content, bsum_date.
        prompt_fn: Prompt function (daily_prompt, weekly_prompt, etc.).
        prompt_args: Args to pass to prompt_fn.

    Returns:
        Dict with bsum_id, bsum_title, bsum_content, or None if no children.
    """
    if not children:
        return None

    # Skip if already generated
    if bt_id is not None:
        existing = db.sql(
            """SELECT bsum_id, bsum_title, bsum_content FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = ? AND bsum_date = ?
               AND bsum_date_start = ? AND bsum_date_end = ?
               AND bsum_track = 'context-free' AND bt_id = ?""",
            (agent, level, date_str, date_start, date_end, bt_id),
            single=True,
        )
    else:
        existing = db.sql(
            """SELECT bsum_id, bsum_title, bsum_content FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = ? AND bsum_date = ?
               AND bsum_date_start = ? AND bsum_date_end = ?
               AND bsum_track = 'context-free'""",
            (agent, level, date_str, date_start, date_end),
            single=True,
        )
    if existing:
        return existing

    # Build input text from children
    input_parts = []
    for child in children:
        header = child.get("bsum_date", "") or ""
        title = child.get("bsum_title", "")
        if header and title:
            input_parts.append(f"### {header}: {title}")
        elif title:
            input_parts.append(f"### {title}")
        input_parts.append(child["bsum_content"])
        input_parts.append("")
    input_text = "\n".join(input_parts)

    # Generate title
    title = llm.title([
        {"role": "system", "content": title_prompt(level)},
        {"role": "user", "content": input_text},
    ])

    # Generate content — no context preamble
    content = llm.request([
        {"role": "system", "content": prompt_fn(*prompt_args)},
        {"role": "user", "content": input_text},
    ])

    # Store
    source = ",".join(str(c["bsum_id"]) for c in children)
    bsum_id = db.sql(
        """INSERT INTO benchmark_summaries
           (bsum_agent, bsum_level, bsum_date, bsum_date_start, bsum_date_end,
            bsum_track, bsum_title, bsum_content, bsum_source, bt_id)
           VALUES (?, ?, ?, ?, ?, 'context-free', ?, ?, ?, ?)""",
        (agent, level, date_str, date_start, date_end, title, content, source, bt_id),
    )

    return {"bsum_id": bsum_id, "bsum_title": title, "bsum_content": content}


def generate_context_free(
    db: Database,
    llm: LLMClient,
    config: TapestryConfig,
    agent: str,
    date_start: str,
    date_end: str,
    log: callable | None = None,
    delay: float = 1.0,
    max_level: int = 4,
    bt_id: int | None = None,
) -> dict[str, int]:
    """Generate context-free summaries for an agent within a date range.

    Builds the full L0-L3 hierarchy without telescoping context (catchup-style).
    All summaries are stored in benchmark_summaries with track='context-free'.

    Args:
        db: Database instance.
        llm: LLM client.
        config: Tapestry configuration.
        agent: Agent name.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        log: Optional progress callback.
        delay: Seconds between LLM calls (rate limiting).

    Returns:
        Dict with l0, l1, l2, l3 generation counts.
    """
    generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}

    # Step 1: Generate L0s for all conversations in range
    if bt_id is not None:
        convs = db.sql(
            """SELECT tmsg_ref_conv_id, DATE(MAX(tmsg_timestamp)) as conv_date
               FROM tapestry_messages
               WHERE tmsg_agent = ? AND bt_id = ?
               GROUP BY tmsg_ref_conv_id
               HAVING conv_date >= ? AND conv_date <= ?
               ORDER BY conv_date""",
            (agent, bt_id, date_start, date_end),
        )
    else:
        convs = db.sql(
            """SELECT tmsg_ref_conv_id, DATE(MAX(tmsg_timestamp)) as conv_date
               FROM tapestry_messages
               WHERE tmsg_agent = ?
               GROUP BY tmsg_ref_conv_id
               HAVING conv_date >= ? AND conv_date <= ?
               ORDER BY conv_date""",
            (agent, date_start, date_end),
        )
    if not convs:
        # Try without the HAVING pre-filter
        # Resolve agent_id for conversations_in_range (needs int ID post-#561)
        _agent_row = db.sql(
            "SELECT agent_id FROM tapestry_agents WHERE agent_name = ?",
            (agent,), single=True,
        )
        _aid = _agent_row["agent_id"] if _agent_row else 0
        convs = conversations_in_range(db, agent, _aid, date_start, date_end)

    if log:
        log(f"Step 1: {len(convs)} conversations need context-free L0s")

    l0_bar = tqdm(convs, desc="CF L0s", unit="conv", disable=not convs)
    for conv in l0_bar:
        conv_id = conv["tmsg_ref_conv_id"]
        conv_date = conv["conv_date"]
        result = _generate_cf_l0(db, llm, config, agent, conv_id, conv_date, bt_id=bt_id)
        if result:
            generated["l0"] += 1
            l0_bar.set_postfix_str(result["bsum_title"][:40])
        time.sleep(delay)

    if max_level < 1:
        return generated

    # Step 2: Generate L1 dailies from context-free L0s
    # Get distinct dates that have context-free L0s
    if bt_id is not None:
        cf_dates = db.sql(
            """SELECT DISTINCT bsum_date FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_track = 'context-free'
               AND bsum_date >= ? AND bsum_date <= ? AND bt_id = ?
               ORDER BY bsum_date""",
            (agent, date_start, date_end, bt_id),
        )
    else:
        cf_dates = db.sql(
            """SELECT DISTINCT bsum_date FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_track = 'context-free'
               AND bsum_date >= ? AND bsum_date <= ?
               ORDER BY bsum_date""",
            (agent, date_start, date_end),
        )
    if log:
        log(f"Step 2: {len(cf_dates)} dates need context-free L1 dailies")

    l1_bar = tqdm(cf_dates, desc="CF L1s", unit="day", disable=not cf_dates)
    for row in l1_bar:
        d = row["bsum_date"]
        # Get context-free L0s for this date
        if bt_id is not None:
            l0s = db.sql(
                """SELECT bsum_id, bsum_title, bsum_content, bsum_date
                   FROM benchmark_summaries
                   WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_track = 'context-free'
                   AND bsum_date = ? AND bt_id = ?
                   ORDER BY bsum_id""",
                (agent, d, bt_id),
            )
        else:
            l0s = db.sql(
                """SELECT bsum_id, bsum_title, bsum_content, bsum_date
                   FROM benchmark_summaries
                   WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_track = 'context-free'
                   AND bsum_date = ?
                   ORDER BY bsum_id""",
                (agent, d),
            )
        result = _generate_cf_rollup(
            db, llm, config, agent,
            level=1, date_str=d, date_start=d, date_end=d,
            children=l0s,
            prompt_fn=daily_prompt,
            prompt_args=(config.agent_name, d),
            bt_id=bt_id,
        )
        if result:
            generated["l1"] += 1
            l1_bar.set_postfix_str(f"{d} {result['bsum_title'][:30]}")
        time.sleep(delay)

    if max_level < 2:
        return generated

    # Step 3: Generate L2 weeklies from context-free L1s
    if log:
        log("Step 3: Generating context-free L2 weeklies")
    start_d = date.fromisoformat(date_start)
    end_d = date.fromisoformat(date_end)
    current = date(start_d.year, start_d.month, 1)

    while current <= end_d:
        for ws, we in weeks_in_month(current.year, current.month):
            if ws > end_d or we < start_d:
                continue
            # Get context-free dailies in this week range
            if bt_id is not None:
                dailies = db.sql(
                    """SELECT bsum_id, bsum_title, bsum_content, bsum_date
                       FROM benchmark_summaries
                       WHERE bsum_agent = ? AND bsum_level = 1 AND bsum_track = 'context-free'
                       AND bsum_date >= ? AND bsum_date <= ? AND bt_id = ?
                       ORDER BY bsum_date""",
                    (agent, str(ws), str(we), bt_id),
                )
            else:
                dailies = db.sql(
                    """SELECT bsum_id, bsum_title, bsum_content, bsum_date
                       FROM benchmark_summaries
                       WHERE bsum_agent = ? AND bsum_level = 1 AND bsum_track = 'context-free'
                       AND bsum_date >= ? AND bsum_date <= ?
                       ORDER BY bsum_date""",
                    (agent, str(ws), str(we)),
                )
            if not dailies:
                continue
            result = _generate_cf_rollup(
                db, llm, config, agent,
                level=2, date_str=str(ws), date_start=str(ws), date_end=str(we),
                children=dailies,
                prompt_fn=weekly_prompt,
                prompt_args=(config.agent_name, str(ws), str(we)),
                bt_id=bt_id,
            )
            if result:
                generated["l2"] += 1
                if log:
                    log(f"  L2 weekly {ws} to {we}: {result['bsum_title'][:50]}")
            time.sleep(delay)

        if current.month == 12:
            current = date(current.year + 1, 1, 1)
        else:
            current = date(current.year, current.month + 1, 1)

    if max_level < 3:
        return generated

    # Step 4: Generate L3 monthlies from context-free L2s
    if log:
        log("Step 4: Generating context-free L3 monthlies")
    current = date(start_d.year, start_d.month, 1)

    while current <= end_d:
        month_end_day = calendar.monthrange(current.year, current.month)[1]
        month_end = date(current.year, current.month, month_end_day)
        ms = str(current)
        me = str(month_end)

        # Get context-free weeklies in this month
        if bt_id is not None:
            weeklies = db.sql(
                """SELECT bsum_id, bsum_title, bsum_content, bsum_date,
                          bsum_date_start, bsum_date_end
                   FROM benchmark_summaries
                   WHERE bsum_agent = ? AND bsum_level = 2 AND bsum_track = 'context-free'
                   AND bsum_date_start >= ? AND bsum_date_end <= ? AND bt_id = ?
                   ORDER BY bsum_date_start""",
                (agent, ms, me, bt_id),
            )
        else:
            weeklies = db.sql(
                """SELECT bsum_id, bsum_title, bsum_content, bsum_date,
                          bsum_date_start, bsum_date_end
                   FROM benchmark_summaries
                   WHERE bsum_agent = ? AND bsum_level = 2 AND bsum_track = 'context-free'
                   AND bsum_date_start >= ? AND bsum_date_end <= ?
                   ORDER BY bsum_date_start""",
                (agent, ms, me),
            )
        if weeklies:
            month_name = calendar.month_name[current.month]
            result = _generate_cf_rollup(
                db, llm, config, agent,
                level=3, date_str=ms, date_start=ms, date_end=me,
                children=weeklies,
                prompt_fn=monthly_prompt,
                prompt_args=(config.agent_name, month_name, current.year),
                bt_id=bt_id,
            )
            if result:
                generated["l3"] += 1
                if log:
                    log(f"  L3 monthly {month_name} {current.year}: {result['bsum_title'][:50]}")
            time.sleep(delay)

        if current.month == 12:
            current = date(current.year + 1, 1, 1)
        else:
            current = date(current.year, current.month + 1, 1)

    if log:
        log(
            f"\nContext-free generation complete. "
            f"L0={generated['l0']}, L1={generated['l1']}, "
            f"L2={generated['l2']}, L3={generated['l3']}"
        )

    return generated


# ---------------------------------------------------------------------------
# 3. Scoring — compare tracks and write results to benchmark_results
# ---------------------------------------------------------------------------

def _get_raw_text(db: Database, agent: str, conv_id: str, config: TapestryConfig) -> str:
    """Build raw chat text for a conversation (for raw_vs_L0 scoring).

    Strips role labels, returns plain text — just the content, no [USER]/[AGENT] tags.
    """
    rows = db.sql(
        """SELECT tmsg_content FROM tapestry_messages
           WHERE tmsg_ref_conv_id = ? ORDER BY tmsg_order""",
        (conv_id,),
    )
    if not rows:
        return ""
    return "\n\n".join(r["tmsg_content"] for r in rows)


def _get_raw_text_for_date(db: Database, agent: str, date_str: str, config: TapestryConfig) -> str:
    """Build combined raw chat text for all conversations on a given date."""
    convs = conversations_in_range(db, agent, date_str, date_str)
    parts = []
    for conv in convs:
        text = _get_raw_text(db, agent, conv["tmsg_ref_conv_id"], config)
        if text:
            parts.append(text)
    return "\n\n---\n\n".join(parts)


def score_benchmarks(
    db: Database,
    config: TapestryConfig,
    agent: str,
    date_start: str,
    date_end: str,
    methods: list[str] | None = None,
    log: callable | None = None,
    max_level: int = 4,
    bt_id: int | None = None,
) -> dict[str, int]:
    """Score benchmark summaries and write results to benchmark_results.

    Runs the validation phase (same-track scoring) and cross-track phase.

    Validation phase (per track):
    - raw_vs_L0: raw chat text vs L0 summary
    - L0_vs_L1: combined L0s vs L1 daily

    Cross-track phase:
    - cross_L0_vs_L1: context-free L0 vs context-aware L1 (and vice versa)

    Args:
        db: Database instance.
        config: Tapestry configuration.
        agent: Agent name.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        methods: List of scoring methods (default: all four).
        log: Optional progress callback.

    Returns:
        Dict with count of scores written.
    """
    if methods is None:
        methods = list(SCORING_METHODS.keys())

    # Pre-load SBERT model if needed (avoid reloading per call)
    sbert_model = None
    if "sbert" in methods:
        if log:
            log("Loading SBERT model...")
        import warnings
        from sentence_transformers import SentenceTransformer
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sbert_model = SentenceTransformer("all-MiniLM-L6-v2")

    written = {"same_track": 0, "cross_track": 0}

    # --- Validation Phase: raw_vs_L0 ---
    if log:
        log("Phase 1: raw_vs_L0 scoring (both tracks)")

    _bt_filter = " AND bt_id = ?" if bt_id is not None else ""
    _bt_params = (bt_id,) if bt_id is not None else ()

    for track in ["context-aware", "context-free"]:
        l0s = db.sql(
            f"""SELECT bsum_id, bsum_date, bsum_content, bsum_source
               FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_track = ?
               AND bsum_date >= ? AND bsum_date <= ?{_bt_filter}
               ORDER BY bsum_date""",
            (agent, track, date_start, date_end) + _bt_params,
        )
        if log:
            log(f"  {track}: {len(l0s)} L0s to score against raw text")

        l0_bar = tqdm(l0s, desc=f"raw_vs_L0 ({track[:4]})", unit="conv", disable=not l0s)
        for l0 in l0_bar:
            raw_text = _get_raw_text(db, agent, l0["bsum_source"], config)
            if not raw_text:
                continue

            for method in methods:
                # Skip if already scored
                existing = db.sql(
                    f"""SELECT bench_id, bench_score FROM benchmark_results
                       WHERE bench_agent = ? AND bench_date = ? AND bench_level = 0
                       AND bench_comparison = 'raw_vs_L0' AND bench_track = ?
                       AND bench_method = ? AND bench_date_start = ? AND bench_date_end = ?{_bt_filter}""",
                    (agent, l0["bsum_date"], track, method, date_start, date_end) + _bt_params,
                    single=True,
                )
                if existing:
                    tqdm.write(f"  raw_vs_L0 [{track}] [{method}] {l0['bsum_date']}: {existing['bench_score']:.4f} (cached)")
                    continue

                s = score_pair(raw_text, l0["bsum_content"], method, sbert_model)
                db.sql(
                    """INSERT INTO benchmark_results
                       (bench_agent, bench_date, bench_level, bench_comparison,
                        bench_track, bench_method, bench_score,
                        bench_date_start, bench_date_end, bt_id)
                       VALUES (?, ?, 0, 'raw_vs_L0', ?, ?, ?, ?, ?, ?)""",
                    (agent, l0["bsum_date"], track, method, s, date_start, date_end, bt_id),
                )
                written["same_track"] += 1
                tqdm.write(f"  raw_vs_L0 [{track}] [{method}] {l0['bsum_date']}: {s:.4f}")

    # --- Validation Phase: L(N-1)_vs_L(N) same-track ---
    level_pairs = [
        (0, 1, "L0_vs_L1"),
        (1, 2, "L1_vs_L2"),
        (2, 3, "L2_vs_L3"),
    ]
    level_pairs = [(s, t, c) for s, t, c in level_pairs if t <= max_level]

    for source_level, target_level, comparison in level_pairs:
        if log:
            log(f"Phase 2: {comparison} scoring (both tracks)")

        for track in ["context-aware", "context-free"]:
            targets = db.sql(
                f"""SELECT bsum_id, bsum_date, bsum_date_start, bsum_date_end,
                          bsum_content, bsum_source
                   FROM benchmark_summaries
                   WHERE bsum_agent = ? AND bsum_level = ? AND bsum_track = ?
                   AND bsum_date >= ? AND bsum_date <= ?{_bt_filter}
                   ORDER BY bsum_date""",
                (agent, target_level, track, date_start, date_end) + _bt_params,
            )
            if not targets:
                continue

            target_bar = tqdm(targets, desc=f"{comparison} ({track[:4]})", unit="rec", disable=not targets)
            for target in target_bar:
                # Get source children for this target
                source_ids = (target["bsum_source"] or "").split(",")
                if not source_ids or source_ids == [""]:
                    continue

                # Build combined source text from children
                # Context-aware bsum_source always contains tap_ids (original tapestry IDs)
                # Context-free bsum_source contains bsum_ids
                if track == "context-aware":
                    sources = db.sql(
                        f"""SELECT bsum_content FROM benchmark_summaries
                           WHERE bsum_tap_id IN ({','.join('?' * len(source_ids))})
                           AND bsum_track = 'context-aware'""",
                        tuple(source_ids),
                    )
                else:
                    sources = db.sql(
                        f"""SELECT bsum_content FROM benchmark_summaries
                           WHERE bsum_id IN ({','.join('?' * len(source_ids))})""",
                        tuple(source_ids),
                    )

                if not sources:
                    continue
                source_text = "\n\n".join(s["bsum_content"] for s in sources)

                for method in methods:
                    existing = db.sql(
                        f"""SELECT bench_id, bench_score FROM benchmark_results
                           WHERE bench_agent = ? AND bench_date = ? AND bench_level = ?
                           AND bench_comparison = ? AND bench_track = ?
                           AND bench_method = ? AND bench_date_start = ? AND bench_date_end = ?{_bt_filter}""",
                        (agent, target["bsum_date"], target_level, comparison,
                         track, method, date_start, date_end) + _bt_params,
                        single=True,
                    )
                    if existing:
                        tqdm.write(f"  {comparison} [{track}] [{method}] {target['bsum_date']}: {existing['bench_score']:.4f} (cached)")
                        continue

                    s = score_pair(source_text, target["bsum_content"], method, sbert_model)
                    db.sql(
                        """INSERT INTO benchmark_results
                           (bench_agent, bench_date, bench_level, bench_comparison,
                            bench_track, bench_method, bench_score,
                            bench_date_start, bench_date_end, bt_id)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                        (agent, target["bsum_date"], target_level, comparison,
                         track, method, s, date_start, date_end, bt_id),
                    )
                    written["same_track"] += 1
                    tqdm.write(f"  {comparison} [{track}] [{method}] {target['bsum_date']}: {s:.4f}")

    # --- Cross-Track Phase ---
    if log:
        log("Phase 3: Cross-track scoring")

    for source_level, target_level, _ in level_pairs:
        comparison = f"cross_L{source_level}_vs_L{target_level}"

        # Context-free source vs context-aware target
        ca_targets = db.sql(
            f"""SELECT bsum_id, bsum_date, bsum_date_start, bsum_date_end, bsum_content
               FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = ? AND bsum_track = 'context-aware'
               AND bsum_date >= ? AND bsum_date <= ?{_bt_filter}
               ORDER BY bsum_date""",
            (agent, target_level, date_start, date_end) + _bt_params,
        )
        cf_sources_by_date = {}
        cf_sources = db.sql(
            f"""SELECT bsum_date, bsum_date_start, bsum_date_end, bsum_content
               FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = ? AND bsum_track = 'context-free'
               AND bsum_date >= ? AND bsum_date <= ?{_bt_filter}
               ORDER BY bsum_date""",
            (agent, source_level, date_start, date_end) + _bt_params,
        )
        # Group context-free sources by date for matching
        for s in cf_sources:
            d = s["bsum_date"]
            if d not in cf_sources_by_date:
                cf_sources_by_date[d] = []
            cf_sources_by_date[d].append(s["bsum_content"])

        cross_bar = tqdm(ca_targets, desc=f"{comparison} cross", unit="rec", disable=not ca_targets)
        for target in cross_bar:
            # Match source by date range
            target_date = target["bsum_date"]
            target_start = target.get("bsum_date_start") or target_date
            target_end = target.get("bsum_date_end") or target_date

            # Collect all context-free sources within this target's date range
            source_parts = []
            for d, texts in cf_sources_by_date.items():
                if d >= target_start and d <= target_end:
                    source_parts.extend(texts)

            if not source_parts:
                continue
            source_text = "\n\n".join(source_parts)

            for method in methods:
                existing = db.sql(
                    f"""SELECT bench_id FROM benchmark_results
                       WHERE bench_agent = ? AND bench_date = ? AND bench_level = ?
                       AND bench_comparison = ? AND bench_track = 'cross'
                       AND bench_method = ? AND bench_date_start = ? AND bench_date_end = ?{_bt_filter}""",
                    (agent, target_date, target_level, comparison,
                     method, date_start, date_end) + _bt_params,
                    single=True,
                )
                if existing:
                    continue

                s = score_pair(source_text, target["bsum_content"], method, sbert_model)

                # Also score the reverse: CA source vs CF target
                cf_target = db.sql(
                    f"""SELECT bsum_content FROM benchmark_summaries
                       WHERE bsum_agent = ? AND bsum_level = ? AND bsum_track = 'context-free'
                       AND bsum_date = ?{_bt_filter}""",
                    (agent, target_level, target_date) + _bt_params,
                    single=True,
                )
                ca_source_parts = []
                ca_sources = db.sql(
                    f"""SELECT bsum_date, bsum_content FROM benchmark_summaries
                       WHERE bsum_agent = ? AND bsum_level = ? AND bsum_track = 'context-aware'
                       AND bsum_date >= ? AND bsum_date <= ?{_bt_filter}""",
                    (agent, source_level, target_start, target_end) + _bt_params,
                )
                for cas in ca_sources:
                    ca_source_parts.append(cas["bsum_content"])

                s_reverse = 0.0
                if cf_target and ca_source_parts:
                    ca_source_text = "\n\n".join(ca_source_parts)
                    s_reverse = score_pair(
                        ca_source_text, cf_target["bsum_content"], method, sbert_model
                    )

                # RY factor = context-aware cross score minus context-free cross score
                ry = s - s_reverse

                db.sql(
                    """INSERT INTO benchmark_results
                       (bench_agent, bench_date, bench_level, bench_comparison,
                        bench_track, bench_method, bench_score, bench_ry_factor,
                        bench_date_start, bench_date_end, bt_id)
                       VALUES (?, ?, ?, ?, 'cross', ?, ?, ?, ?, ?, ?)""",
                    (agent, target_date, target_level, comparison,
                     method, s, ry, date_start, date_end, bt_id),
                )
                written["cross_track"] += 1
                tqdm.write(f"  {comparison} [cross] [{method}] {target_date}: score={s:.4f} reverse={s_reverse:.4f} RY={ry:+.4f}")

    if log:
        log(
            f"\nScoring complete. Same-track: {written['same_track']}, "
            f"Cross-track: {written['cross_track']}"
        )

    return written
