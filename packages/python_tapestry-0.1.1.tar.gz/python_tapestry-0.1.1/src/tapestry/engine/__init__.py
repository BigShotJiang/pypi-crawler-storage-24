"""Tapestry engine — context resolution, generation, rollup, repair, and catchup."""

from tapestry.engine.catchup import catchup, iterate
from tapestry.engine.context import resolve_context
from tapestry.engine.generate import (
    auto_generate_daily,
    auto_generate_l0,
    auto_generate_monthly,
    auto_generate_weekly,
)
from tapestry.engine.prompts import context_preamble
from tapestry.engine.repair import repair_from_first_gap, repair_monthly, repair_weekly, repair_yearly
from tapestry.engine.rollup import conversations_in_range, weeks_in_month

__all__ = [
    "auto_generate_daily",
    "auto_generate_l0",
    "auto_generate_monthly",
    "auto_generate_weekly",
    "catchup",
    "context_preamble",
    "conversations_in_range",
    "iterate",
    "repair_from_first_gap",
    "repair_monthly",
    "repair_weekly",
    "repair_yearly",
    "resolve_context",
    "weeks_in_month",
]
