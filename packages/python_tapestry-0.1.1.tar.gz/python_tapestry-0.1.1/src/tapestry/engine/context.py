"""Telescoping context resolution.

Walks the tapestry hierarchy (L4 yearly → L0 conversation) to build a
context stack for generating new summaries. Flags gaps that need repair.
"""

from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import TYPE_CHECKING

from tapestry.engine.rollup import conversations_in_range

if TYPE_CHECKING:
    from tapestry.db import Database


def _ctx(level: int, row: dict, range_str: str) -> dict:
    """Build a context item dict."""
    return {
        "level": level,
        "tap_id": row["tap_id"],
        "title": row["tap_title"],
        "content": row["tap_content"],
        "range": range_str,
    }


def _repair(level: int, range_str: str, start: str, end: str, conv_count: int) -> dict:
    """Build a repair-needed item dict."""
    return {
        "level": level,
        "range": range_str,
        "start": start,
        "end": end,
        "conv_count": conv_count,
    }


def resolve_context(
    db: Database,
    agent: str,
    agent_id: int,
    anchor_date_str: str,
    anchor_start_ts: str | None = None,
    max_level: int | None = None,
    min_date: str | None = None,
) -> tuple[list[dict], list[dict]]:
    """Walk the telescoping context resolution algorithm.

    Checks each level (yearly → monthly → weekly → daily → conversation)
    for existing summaries or gaps needing repair.

    Args:
        db: Database instance.
        agent: Agent name string.
        anchor_date_str: YYYY-MM-DD date of the conversation's last message.
        anchor_start_ts: ISO timestamp of conversation's first message (optional).
            When provided, only L0s whose last message is before this timestamp
            are included in context.
        max_level: If set, skip levels above this (e.g. 1 = only L0-L1).
        min_date: If set (YYYY-MM-DD), skip records before this date.

    Returns:
        (context_items, repairs_needed) tuple.
        context_items: list of dicts with level, tap_id, title, content, range.
        repairs_needed: list of dicts with level, range, start, end, conv_count.
    """
    anchor = date.fromisoformat(anchor_date_str)
    min_d = date.fromisoformat(min_date) if min_date else None

    # Find earliest conversation date for this agent
    first_row = db.sql(
        """SELECT DATE(MIN(last_ts)) as first_date FROM (
               SELECT MAX(tmsg_timestamp) as last_ts
               FROM tapestry_messages WHERE tmsg_agent_id = ?
               GROUP BY tmsg_ref_conv_id
           )""",
        (agent_id,),
        single=True,
    )

    if not first_row or not first_row["first_date"]:
        return [], []

    first_date = date.fromisoformat(first_row["first_date"])

    context: list[dict] = []
    repairs_needed: list[dict] = []

    # Helper: check if a level is allowed
    def _level_ok(lvl: int) -> bool:
        return max_level is None or lvl <= max_level

    # Helper: check if a date range is within retention window
    def _date_ok(end_str: str) -> bool:
        if min_d is None:
            return True
        return date.fromisoformat(end_str) >= min_d

    # ─── LEVEL 4 — YEARLY ─────────────────────────────────────────
    if _level_ok(4):
        for year in range(first_date.year, anchor.year):
            year_start = f"{year}-01-01"
            year_end = f"{year}-12-31"

            if not _date_ok(year_end):
                continue

            existing = db.sql(
                """SELECT tap_id, tap_title, tap_content FROM tapestry
                   WHERE tap_level = 4 AND tap_agent_id = ?
                   AND tap_date_start = ? AND tap_date_end = ?""",
                (agent_id, year_start, year_end),
                single=True,
            )
            if existing:
                context.append(_ctx(4, existing, str(year)))
                continue

            convs = conversations_in_range(db, agent, agent_id, year_start, year_end)
            if convs:
                repairs_needed.append(_repair(4, str(year), year_start, year_end, len(convs)))

    # ─── LEVEL 3 — MONTHLY ────────────────────────────────────────
    if _level_ok(3) and anchor.month > 1:
        for month in range(1, anchor.month):
            month_start = f"{anchor.year}-{month:02d}-01"
            last_day = calendar.monthrange(anchor.year, month)[1]
            month_end = f"{anchor.year}-{month:02d}-{last_day:02d}"

            if not _date_ok(month_end):
                continue

            existing = db.sql(
                """SELECT tap_id, tap_title, tap_content FROM tapestry
                   WHERE tap_level = 3 AND tap_agent_id = ?
                   AND tap_date_start = ? AND tap_date_end = ?""",
                (agent_id, month_start, month_end),
                single=True,
            )
            if existing:
                month_name = calendar.month_name[month]
                context.append(_ctx(3, existing, f"{month_name} {anchor.year}"))
                continue

            convs = conversations_in_range(db, agent, agent_id, month_start, month_end)
            if convs:
                month_name = calendar.month_name[month]
                repairs_needed.append(
                    _repair(3, f"{month_name} {anchor.year}", month_start, month_end, len(convs))
                )

    # ─── LEVEL 2 — WEEKLY ─────────────────────────────────────────
    month_first = date(anchor.year, anchor.month, 1)

    if _level_ok(2):
        # Find Sundays in current month before anchor date
        sundays: list[date] = []
        d = month_first
        while d.month == anchor.month and d < anchor:
            if d.weekday() == 6:  # Sunday
                sundays.append(d)
            d += timedelta(days=1)

        for sunday in sundays:
            monday = sunday - timedelta(days=6)
            week_start = max(monday, month_first)
            week_end = sunday

            if not _date_ok(str(week_end)):
                continue

            existing = db.sql(
                """SELECT tap_id, tap_title, tap_content FROM tapestry
                   WHERE tap_level = 2 AND tap_agent_id = ?
                   AND tap_date_start = ? AND tap_date_end = ?""",
                (agent_id, str(week_start), str(week_end)),
                single=True,
            )
            range_label = f"{week_start.strftime('%b %d')}-{week_end.strftime('%b %d')}"
            if existing:
                context.append(_ctx(2, existing, range_label))
                continue

            convs = conversations_in_range(db, agent, agent_id, str(week_start), str(week_end))
            if convs:
                repairs_needed.append(
                    _repair(2, range_label, str(week_start), str(week_end), len(convs))
                )

    # ─── LEVEL 1 — DAILY ──────────────────────────────────────────
    if _level_ok(1):
        # When higher levels are blocked (max_level <= 1), expand dailies
        # to cover the full retention window since weeklies/monthlies won't
        # be there to provide coverage.
        if max_level is not None and max_level <= 1 and min_d:
            daily_start = min_d
        else:
            monday_of_anchor = anchor - timedelta(days=anchor.weekday())
            daily_start = max(monday_of_anchor, month_first)
            if min_d and daily_start < min_d:
                daily_start = min_d
        daily_end = anchor - timedelta(days=1)

        if daily_start <= daily_end:
            d = daily_start
            while d <= daily_end:
                existing = db.sql(
                    """SELECT tap_id, tap_title, tap_content FROM tapestry
                       WHERE tap_level = 1 AND tap_date = ? AND tap_agent_id = ?""",
                    (str(d), agent_id),
                    single=True,
                )
                if existing:
                    context.append(_ctx(1, existing, str(d)))
                else:
                    convs = conversations_in_range(db, agent, agent_id, str(d), str(d))
                    if convs:
                        repairs_needed.append(_repair(1, str(d), str(d), str(d), len(convs)))
                d += timedelta(days=1)

    # ─── LEVEL 0 — SAME-DAY ───────────────────────────────────────
    if _level_ok(0) and _date_ok(str(anchor)):
        l0s = db.sql(
            """SELECT tap_id, tap_title, tap_content, tap_source
               FROM tapestry WHERE tap_level = 0 AND tap_date = ? AND tap_agent_id = ?
               ORDER BY tap_id""",
            (str(anchor), agent_id),
        )

        if not l0s:
            convs = conversations_in_range(db, agent, agent_id, str(anchor), str(anchor))
            if convs:
                repairs_needed.append(_repair(0, str(anchor), str(anchor), str(anchor), len(convs)))
        elif not anchor_start_ts:
            for l0 in l0s:
                context.append(_ctx(0, l0, str(anchor)))
        else:
            for l0 in l0s:
                conv_id = l0["tap_source"]
                last_msg = db.sql(
                    "SELECT MAX(tmsg_timestamp) as last_ts FROM tapestry_messages WHERE tmsg_ref_conv_id = ?",
                    (conv_id,),
                    single=True,
                )
                if last_msg and last_msg["last_ts"] and last_msg["last_ts"] < anchor_start_ts:
                    context.append(_ctx(0, l0, str(anchor)))

    return context, repairs_needed
