"""Scoring engine for RY Factor benchmarks.

Four similarity methods:
- TF-IDF cosine similarity (lexical, sklearn)
- SBERT sentence embeddings cosine similarity (semantic, sentence-transformers)
- ROUGE-L (n-gram overlap, rouge-score)
- BM25 relevance scoring (rank-bm25)

All methods score a source text against a summary text, returning 0.0-1.0.
"""

from __future__ import annotations

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def score_tfidf(source: str, summary: str) -> float:
    """TF-IDF cosine similarity between source and summary.

    Builds a TF-IDF matrix over both texts and computes cosine similarity.
    Returns 0.0-1.0.
    """
    vectorizer = TfidfVectorizer()
    try:
        matrix = vectorizer.fit_transform([source, summary])
        sim = cosine_similarity(matrix[0:1], matrix[1:2])[0][0]
        return float(max(0.0, min(1.0, sim)))
    except ValueError:
        return 0.0


def score_sbert(source: str, summary: str, model=None) -> float:
    """SBERT sentence embedding cosine similarity.

    Uses a pre-loaded SentenceTransformer model. Pass the model in to avoid
    reloading on every call.

    Returns 0.0-1.0.
    """
    if model is None:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("all-MiniLM-L6-v2")

    embeddings = model.encode([source, summary], convert_to_numpy=True)
    sim = cosine_similarity(embeddings[0:1], embeddings[1:2])[0][0]
    return float(max(0.0, min(1.0, sim)))


def score_rouge_l(source: str, summary: str) -> float:
    """ROUGE-L F1 score between source and summary.

    Measures longest common subsequence overlap. Returns 0.0-1.0.
    """
    from rouge_score import rouge_scorer
    scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
    scores = scorer.score(source, summary)
    return float(scores["rougeL"].fmeasure)


def score_bm25(source: str, summary: str) -> float:
    """BM25 relevance score, normalized to 0.0-1.0.

    Splits source into paragraphs (or sentences if short), builds a BM25 index,
    queries with the summary text. Normalizes by computing the self-similarity
    score (source queried against itself) as the theoretical maximum.
    """
    from rank_bm25 import BM25Okapi

    # Split source into chunks — paragraphs first, fall back to sentences
    paragraphs = [p.strip() for p in source.split("\n\n") if p.strip()]
    if len(paragraphs) < 3:
        paragraphs = [s.strip() for s in source.split(". ") if s.strip()]
    if not paragraphs:
        return 0.0
    tokenized = [p.lower().split() for p in paragraphs]

    bm25 = BM25Okapi(tokenized)

    query_tokens = summary.lower().split()
    if not query_tokens:
        return 0.0

    scores = bm25.get_scores(query_tokens)
    query_score = float(np.mean(np.maximum(scores, 0)))

    # Self-similarity as normalization baseline
    self_tokens = source.lower().split()
    self_scores = bm25.get_scores(self_tokens)
    self_score = float(np.mean(np.maximum(self_scores, 0)))

    if self_score <= 0:
        return 0.0

    return float(min(1.0, max(0.0, query_score / self_score)))


# Registry of scoring methods
SCORING_METHODS = {
    "tfidf": score_tfidf,
    "sbert": score_sbert,
    "rouge_l": score_rouge_l,
    "bm25": score_bm25,
}


def score_pair(
    source: str,
    summary: str,
    method: str,
    sbert_model=None,
) -> float:
    """Score a source-summary pair using the named method.

    Args:
        source: The reference text (e.g., L0 content).
        summary: The summary text (e.g., L1 content).
        method: One of 'tfidf', 'sbert', 'rouge_l', 'bm25'.
        sbert_model: Pre-loaded SentenceTransformer (avoids reload per call).

    Returns:
        Similarity score 0.0-1.0.
    """
    if method == "sbert":
        return score_sbert(source, summary, model=sbert_model)
    fn = SCORING_METHODS.get(method)
    if fn is None:
        raise ValueError(f"Unknown scoring method: {method}")
    return fn(source, summary)
