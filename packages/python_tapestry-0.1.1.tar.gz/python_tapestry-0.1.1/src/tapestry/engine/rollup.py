"""Date math helpers for tapestry rollup boundaries.

Handles week-in-month splitting, month boundaries, and conversation date queries.
"""

from __future__ import annotations

import calendar
from datetime import date, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database


def weeks_in_month(year: int, month: int) -> list[tuple[date, date]]:
    """Return (start_date, end_date) for all week ranges belonging to a month.

    Weeks are Mon-Sun, split at month boundaries per tapestry spec.
    A week spanning a month boundary is split: the portion in each month
    becomes its own entry.
    """
    month_first = date(year, month, 1)
    last_day = date(year, month, calendar.monthrange(year, month)[1])
    weeks: list[tuple[date, date]] = []

    # Find all Sundays in this month
    d = month_first
    while d <= last_day:
        if d.weekday() == 6:  # Sunday
            monday = d - timedelta(days=6)
            week_start = max(monday, month_first)
            weeks.append((week_start, d))
        d += timedelta(days=1)

    # Trailing partial week (Mon through end of month, no Sunday)
    if last_day.weekday() != 6:
        monday = last_day - timedelta(days=last_day.weekday())
        trail_start = max(monday, month_first)
        weeks.append((trail_start, last_day))

    return weeks


def conversations_in_range(
    db: Database, agent: str, agent_id: int, start_date: str, end_date: str
) -> list[dict]:
    """Find conversations whose date (last message) falls within a date range.

    Groups tapestry_messages by conversation ID and filters by the date
    of the last message in each conversation.

    Returns list of dicts with 'tmsg_ref_conv_id' and 'conv_date' keys.
    """
    return db.sql(
        """SELECT tmsg_ref_conv_id, DATE(MAX(tmsg_timestamp)) as conv_date
           FROM tapestry_messages
           WHERE tmsg_agent_id = ?
           GROUP BY tmsg_ref_conv_id
           HAVING conv_date >= ? AND conv_date <= ?
           ORDER BY conv_date""",
        (agent_id, start_date, end_date),
    )
