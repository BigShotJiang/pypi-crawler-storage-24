"""Topic-based benchmark for measuring Recall Yield (RY Factor).

Instead of cosine similarity between summaries, this extracts topic-specific
information from both tracks and compares information volume. The delta
between context-aware and context-free retrieval = RY Factor.

Flow:
1. Define topics (curated list across frequency tiers)
2. Extract topic information from both tracks using LLM prompts
3. Measure information volume per topic per track
4. Compare: how much richer is context-aware retrieval?
"""

from __future__ import annotations

import json
import time
from typing import TYPE_CHECKING

from tapestry.engine.scoring import score_pair

if TYPE_CHECKING:
    from tapestry.db import Database
    from tapestry.llm import LLMClient


# ---------------------------------------------------------------------------
# Test topics — curated across frequency tiers
# ---------------------------------------------------------------------------

TOPICS = {
    "high": [
        {
            "name": "Uni/Unibot",
            "query": "Uni, Unibot, UNI AI, ai-os, AI assistant, AI evolution, Cody, Rasa, chatbot development, consciousness.py",
        },
    ],
    "medium": [
        {
            "name": "ESP32",
            "query": "ESP32, Communicator3, I2S audio, MAX98357A, ESP8266, clock, OLED, BME280, SPIFFS, WiFi, NTP, PlatformIO, firmware",
        },
    ],
    "low": [
        {
            "name": "CRISPR/Genetic",
            "query": "CRISPR, Cas9, CRISPR-Cas9, tomato, gene editing, genetic marker, biofeedback, dimmer switch, telomere",
        },
        {
            "name": "ATtiny85/SoilSensor",
            "query": "ATtiny85, ATtiny13, SoilSensor, soil moisture, low-power, CR2032, PlatformIO, microcontroller, enclosure",
        },
    ],
}


def _all_topics() -> list[dict]:
    """Flatten TOPICS dict into a single list with tier labels."""
    result = []
    for tier, topics in TOPICS.items():
        for t in topics:
            result.append({**t, "tier": tier})
    return result


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

FREE_EXTRACT_PROMPT = """You are an information extraction specialist.

Extract all action-specific topics from this conversation.

Rules:
- Each topic is ONE technically precise sentence describing one thing that happened AND why.
- Include: what was done, what changed, what was decided, what was discovered — and the reason or significance.
- Use correct names, versions, file paths, function names, and relationships.
- No vague labels. No summaries. No "discussed X". Specific actions with context only.
- If something was fixed, say what was broken and why it mattered.
- If something was built, say what it does and why it was needed.

Examples of GOOD topics:
- Fixed hardcoded D: drive path in scrumconnector.py to support dual-machine Dropbox setup where Coffee Shop uses C: drive
- Chose TF-IDF over SBERT for initial topic scoring because it runs locally without GPU and handles exact technical terms better
- Discovered MAOA-H variant means normal MAO-A enzyme activity, which degrades dopamine at baseline rates unlike the low-activity 3R variant

Examples of BAD topics (too vague):
- Discussed drive path issue
- Worked on scoring
- Talked about genetics

IMPORTANT OUTPUT RULES:
- Return ONLY a JSON array of strings. No explanation, no markdown, no other text.
- Use ONLY straight ASCII quotes (") for JSON delimiters. Never use smart/curly quotes.
- No emojis. No Unicode symbols. ASCII only in the output.
- If quoting a term inside a string, use single quotes: 'term' not "term".
Example: ["Topic one because reason", "Topic two because reason"]"""


EXTRACT_PROMPT = """You are an information extraction specialist.

Given the following text, extract ALL information related to this topic:

**Topic: {topic_name}**
**Search terms: {topic_query}**

Rules:
- Extract every fact, name, date, file path, technical detail, decision, and relationship mentioned.
- Include direct references AND indirect/contextual references.
- If nothing relevant is found, return exactly: {{"facts": [], "summary": ""}}
- Return valid JSON only.

Return format:
{{
    "facts": ["fact 1", "fact 2", ...],
    "summary": "A brief paragraph synthesizing all extracted information about this topic."
}}"""


GROUND_TRUTH_PROMPT = """You are an information extraction specialist.

Given these raw conversation transcripts, extract ALL information related to this topic:

**Topic: {topic_name}**
**Search terms: {topic_query}**

This is ground truth extraction — be exhaustive. Include:
- Every mention, no matter how brief
- Technical details (file paths, function names, configurations)
- Decisions made about this topic
- Problems encountered and solutions
- Relationships to other topics

Return valid JSON:
{{
    "facts": ["fact 1", "fact 2", ...],
    "summary": "Comprehensive paragraph of everything known about this topic from these conversations."
}}"""


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------

def extract_topic_from_text(
    llm: LLMClient,
    text: str,
    topic: dict,
    *,
    is_ground_truth: bool = False,
) -> dict:
    """Extract topic-relevant information from a block of text using LLM.

    Args:
        llm: LLM client.
        text: The text to extract from (summary or raw transcript).
        topic: Dict with 'name' and 'query' keys.
        is_ground_truth: Use exhaustive ground truth prompt if True.

    Returns:
        Dict with 'facts' (list[str]) and 'summary' (str).
    """
    prompt_template = GROUND_TRUTH_PROMPT if is_ground_truth else EXTRACT_PROMPT
    system = prompt_template.format(
        topic_name=topic["name"],
        topic_query=topic["query"],
    )

    response = llm.request(
        [
            {"role": "system", "content": system},
            {"role": "user", "content": text},
        ],
    )

    # Parse JSON from response
    try:
        cleaned = response.strip()
        # Strip markdown code fences
        if "```" in cleaned:
            # Find content between first ``` and last ```
            parts = cleaned.split("```")
            # Take the part after the first fence (skip language tag)
            inner = parts[1] if len(parts) >= 3 else parts[-1]
            if inner.startswith("json"):
                inner = inner[4:]
            cleaned = inner.strip()
        # Try direct parse first
        result = json.loads(cleaned)
        return {
            "facts": result.get("facts", []),
            "summary": result.get("summary", ""),
        }
    except (json.JSONDecodeError, KeyError, IndexError):
        # Last resort: find JSON object in the response
        import re
        match = re.search(r'\{[\s\S]*"facts"[\s\S]*\}', response)
        if match:
            try:
                result = json.loads(match.group())
                return {
                    "facts": result.get("facts", []),
                    "summary": result.get("summary", ""),
                }
            except json.JSONDecodeError:
                pass
        return {"facts": [], "summary": response}


# ---------------------------------------------------------------------------
# Ground truth generation
# ---------------------------------------------------------------------------

def build_ground_truth(
    db: Database,
    llm: LLMClient,
    agent: str,
    date_start: str,
    date_end: str,
    topics: list[dict] | None = None,
    log: callable | None = None,
) -> list[dict]:
    """Extract ground truth topic information from raw conversation data.

    Pulls all raw messages for the agent in the date range, then runs
    exhaustive topic extraction against them.

    Args:
        db: Database instance.
        llm: LLM client.
        agent: Agent name.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        topics: Topic list (default: all curated topics).
        log: Optional progress callback.

    Returns:
        List of dicts: {topic, tier, facts, summary, fact_count, word_count}
    """
    if topics is None:
        topics = _all_topics()

    # Use L0 summaries as ground truth source — denser than raw messages
    # and guaranteed to contain the actual content that got summarized
    rows = db.sql(
        """SELECT tap_content, tap_title, tap_date
           FROM tapestry
           WHERE tap_agent = ? AND tap_level = 0
           AND tap_date >= ? AND tap_date <= ?
           ORDER BY tap_date""",
        (agent, date_start, date_end),
    )

    if not rows:
        # Fall back to raw messages
        rows = db.sql(
            """SELECT tmsg_content as tap_content
               FROM tapestry_messages
               WHERE tmsg_agent = ?
               AND DATE(tmsg_timestamp) >= ? AND DATE(tmsg_timestamp) <= ?
               ORDER BY tmsg_timestamp""",
            (agent, date_start, date_end),
        )

    if not rows:
        if log:
            log(f"No data found for {agent} in {date_start} to {date_end}")
        return []

    # Build ground truth text from L0 summaries
    raw_text = "\n\n---\n\n".join(
        r["tap_content"] for r in rows if r.get("tap_content")
    )

    # Truncate if massive (LLM context limit)

    if log:
        log(f"Ground truth: {len(rows)} L0 summaries, {len(raw_text)} chars")

    results = []
    for topic in topics:
        if log:
            log(f"  Extracting ground truth for: {topic['name']}")

        extraction = extract_topic_from_text(
            llm, raw_text, topic, is_ground_truth=True
        )

        results.append({
            "topic": topic["name"],
            "tier": topic["tier"],
            "facts": extraction["facts"],
            "summary": extraction["summary"],
            "fact_count": len(extraction["facts"]),
            "word_count": len(extraction["summary"].split()),
        })
        time.sleep(1)

    return results


# ---------------------------------------------------------------------------
# Track extraction — pull topic info from benchmark summaries
# ---------------------------------------------------------------------------

def extract_from_track(
    db: Database,
    llm: LLMClient,
    agent: str,
    track: str,
    date_start: str,
    date_end: str,
    topics: list[dict] | None = None,
    log: callable | None = None,
) -> list[dict]:
    """Extract topic information from a benchmark track's summaries.

    Concatenates all summaries for the track and runs topic extraction.

    Args:
        db: Database instance.
        llm: LLM client.
        agent: Agent name.
        track: 'context-aware' or 'context-free'.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        topics: Topic list (default: all curated topics).
        log: Optional progress callback.

    Returns:
        List of dicts: {topic, tier, track, facts, summary, fact_count, word_count}
    """
    if topics is None:
        topics = _all_topics()

    # Get all summaries for this track (all levels)
    summaries = db.sql(
        """SELECT bsum_level, bsum_date, bsum_title, bsum_content
           FROM benchmark_summaries
           WHERE bsum_agent = ? AND bsum_track = ?
           AND bsum_date >= ? AND bsum_date <= ?
           ORDER BY bsum_level DESC, bsum_date""",
        (agent, track, date_start, date_end),
    )

    if not summaries:
        if log:
            log(f"No {track} summaries found")
        return []

    # Use highest-level summaries first (they should contain rolled-up info)
    # This mirrors how tapestry_get works — top-down retrieval
    max_level = max(s["bsum_level"] for s in summaries)
    top_summaries = [s for s in summaries if s["bsum_level"] == max_level]

    track_text = "\n\n---\n\n".join(
        f"## {s['bsum_title']}\n{s['bsum_content']}" for s in top_summaries
    )


    if log:
        log(f"  {track}: {len(top_summaries)} L{max_level} summaries, {len(track_text)} chars")

    results = []
    for topic in topics:
        if log:
            log(f"    Extracting {topic['name']} from {track}...")

        extraction = extract_topic_from_text(llm, track_text, topic)

        results.append({
            "topic": topic["name"],
            "tier": topic["tier"],
            "track": track,
            "facts": extraction["facts"],
            "summary": extraction["summary"],
            "fact_count": len(extraction["facts"]),
            "word_count": len(extraction["summary"].split()),
        })
        time.sleep(1)

    return results


# ---------------------------------------------------------------------------
# Comparison — compute RY Factor per topic
# ---------------------------------------------------------------------------

def compare_tracks(
    ground_truth: list[dict],
    ca_results: list[dict],
    cf_results: list[dict],
    sbert_model=None,
    log: callable | None = None,
) -> list[dict]:
    """Compare context-aware vs context-free topic extraction.

    For each topic, measures:
    - fact_count: how many facts each track extracted
    - word_count: how many words in the summary
    - sbert_vs_ground_truth: semantic similarity of each track's summary
      against the ground truth summary
    - ry_factor: delta between CA and CF scores (positive = CA wins)

    Args:
        ground_truth: Output from build_ground_truth().
        ca_results: Output from extract_from_track() for context-aware.
        cf_results: Output from extract_from_track() for context-free.
        sbert_model: Pre-loaded SentenceTransformer (optional).
        log: Optional progress callback.

    Returns:
        List of comparison dicts per topic.
    """
    # Load SBERT if not provided
    if sbert_model is None:
        from sentence_transformers import SentenceTransformer
        sbert_model = SentenceTransformer("all-MiniLM-L6-v2")

    # Index by topic name
    gt_by_topic = {r["topic"]: r for r in ground_truth}
    ca_by_topic = {r["topic"]: r for r in ca_results}
    cf_by_topic = {r["topic"]: r for r in cf_results}

    comparisons = []
    for topic_name, gt in gt_by_topic.items():
        ca = ca_by_topic.get(topic_name, {"facts": [], "summary": "", "fact_count": 0, "word_count": 0})
        cf = cf_by_topic.get(topic_name, {"facts": [], "summary": "", "fact_count": 0, "word_count": 0})

        # Semantic similarity against ground truth
        gt_summary = gt["summary"]
        ca_sbert = score_pair(gt_summary, ca["summary"], "sbert", sbert_model) if ca["summary"] else 0.0
        cf_sbert = score_pair(gt_summary, cf["summary"], "sbert", sbert_model) if cf["summary"] else 0.0

        # TF-IDF similarity against ground truth
        ca_tfidf = score_pair(gt_summary, ca["summary"], "tfidf") if ca["summary"] else 0.0
        cf_tfidf = score_pair(gt_summary, cf["summary"], "tfidf") if cf["summary"] else 0.0

        ry_sbert = ca_sbert - cf_sbert
        ry_tfidf = ca_tfidf - cf_tfidf
        ry_facts = ca["fact_count"] - cf["fact_count"]

        result = {
            "topic": topic_name,
            "tier": gt["tier"],
            "ground_truth_facts": gt["fact_count"],
            "ground_truth_words": gt["word_count"],
            "ca_facts": ca["fact_count"],
            "cf_facts": cf["fact_count"],
            "ca_words": ca["word_count"],
            "cf_words": cf["word_count"],
            "ca_sbert": round(ca_sbert, 4),
            "cf_sbert": round(cf_sbert, 4),
            "ca_tfidf": round(ca_tfidf, 4),
            "cf_tfidf": round(cf_tfidf, 4),
            "ry_sbert": round(ry_sbert, 4),
            "ry_tfidf": round(ry_tfidf, 4),
            "ry_facts": ry_facts,
        }

        if log:
            winner = "CA" if ry_sbert > 0 else "CF" if ry_sbert < 0 else "TIE"
            log(
                f"  {topic_name} ({gt['tier']}): "
                f"CA={ca_sbert:.3f} CF={cf_sbert:.3f} "
                f"RY={ry_sbert:+.3f} [{winner}]"
            )

        comparisons.append(result)

    return comparisons


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------

def run_topic_benchmark(
    db: Database,
    llm: LLMClient,
    agent: str,
    date_start: str,
    date_end: str,
    topics: list[dict] | None = None,
    log: callable | None = None,
) -> dict:
    """Run the full topic-based benchmark pipeline.

    1. Build ground truth from raw conversations
    2. Extract topics from context-aware track
    3. Extract topics from context-free track
    4. Compare and compute RY Factor per topic

    Args:
        db: Database instance.
        llm: LLM client.
        agent: Agent name.
        date_start: YYYY-MM-DD inclusive start.
        date_end: YYYY-MM-DD inclusive end.
        topics: Optional curated topic list.
        log: Optional progress callback.

    Returns:
        Dict with ground_truth, ca_results, cf_results, comparisons.
    """
    if topics is None:
        topics = _all_topics()

    if log:
        log(f"Topic benchmark: {len(topics)} topics, {date_start} to {date_end}")
        log("=" * 60)

    # Step 1: Ground truth
    if log:
        log("\nStep 1: Building ground truth from raw conversations...")
    ground_truth = build_ground_truth(db, llm, agent, date_start, date_end, topics, log)

    # Step 2: Context-aware extraction
    if log:
        log("\nStep 2: Extracting topics from context-aware track...")
    ca_results = extract_from_track(
        db, llm, agent, "context-aware", date_start, date_end, topics, log
    )

    # Step 3: Context-free extraction
    if log:
        log("\nStep 3: Extracting topics from context-free track...")
    cf_results = extract_from_track(
        db, llm, agent, "context-free", date_start, date_end, topics, log
    )

    # Step 4: Compare
    if log:
        log("\nStep 4: Comparing tracks...")

    comparisons = compare_tracks(ground_truth, ca_results, cf_results, log=log)

    # Summary
    if log:
        log("\n" + "=" * 60)
        log("RESULTS")
        log("=" * 60)
        for c in comparisons:
            log(
                f"  {c['topic']:25s} | GT:{c['ground_truth_facts']:3d} facts | "
                f"CA:{c['ca_facts']:3d} CF:{c['cf_facts']:3d} | "
                f"RY(sbert):{c['ry_sbert']:+.4f} RY(tfidf):{c['ry_tfidf']:+.4f}"
            )

    return {
        "ground_truth": ground_truth,
        "ca_results": ca_results,
        "cf_results": cf_results,
        "comparisons": comparisons,
    }


# ---------------------------------------------------------------------------
# Token counting
# ---------------------------------------------------------------------------

def _count_tokens(text: str) -> int:
    """Count tokens using tiktoken cl100k_base, fallback to char estimate."""
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except ImportError:
        return len(text) // 4


# ---------------------------------------------------------------------------
# Per-conversation bulk topic extraction (track-aware)
# ---------------------------------------------------------------------------

def _parse_topic_list(response: str) -> list[str]:
    """Parse LLM response into a list of topic strings."""
    cleaned = response.strip()
    if "```" in cleaned:
        parts = cleaned.split("```")
        inner = parts[1] if len(parts) >= 3 else parts[-1]
        if inner.startswith("json"):
            inner = inner[4:]
        cleaned = inner.strip()
    try:
        topics = json.loads(cleaned)
        if isinstance(topics, list):
            return [str(t) for t in topics]
    except (ValueError, TypeError):
        pass
    # Fallback: line split
    return [line.strip() for line in cleaned.splitlines() if line.strip()]


def extract_topics_per_conversation(
    db: "Database",
    llm: "LLMClient",
    agent: str,
    track: str,
    *,
    date_start: str | None = None,
    date_end: str | None = None,
    delay: float = 1.0,
    log: callable | None = None,
    bt_id: int | None = None,
) -> dict:
    """Extract topics from every L0 summary for a given track.

    Args:
        db: Test database instance.
        llm: LLM client.
        agent: Agent name.
        track: 'context-aware' or 'context-free'.
        date_start: Only extract from L0s on or after this date (YYYY-MM-DD).
        date_end: Only extract from L0s on or before this date (YYYY-MM-DD).
        delay: Seconds between LLM calls.
        log: Optional progress callback.
        bt_id: Benchmark test ID to scope and tag topics.

    Returns:
        Dict with 'conversations' (int) and 'topics' (int) counts.
    """
    _bt_filter = " AND bt_id = ?" if bt_id is not None else ""
    _bt_params = (bt_id,) if bt_id is not None else ()

    _date_filter = ""
    _date_params: tuple = ()
    if date_start and date_end:
        _date_filter = " AND {date_col} BETWEEN ? AND ?"
        _date_params = (date_start, date_end)

    # Fetch L0 summaries for the requested track
    if track == "context-aware":
        date_clause = _date_filter.format(date_col="tap_date") if _date_filter else ""
        rows = db.sql(
            f"""SELECT tap_source as conv_id, tap_content as content
               FROM tapestry
               WHERE tap_agent = ? AND tap_level = 0{_bt_filter}{date_clause}
               ORDER BY tap_date""",
            (agent,) + _bt_params + _date_params,
        )
    elif track == "context-free":
        date_clause = _date_filter.format(date_col="bsum_date") if _date_filter else ""
        rows = db.sql(
            f"""SELECT bsum_source as conv_id, bsum_content as content
               FROM benchmark_summaries
               WHERE bsum_agent = ? AND bsum_level = 0
               AND bsum_track = 'context-free'{_bt_filter}{date_clause}
               ORDER BY bsum_date""",
            (agent,) + _bt_params + _date_params,
        )
    else:
        raise ValueError(f"Invalid track: {track!r}")

    if not rows:
        if log:
            log(f"No L0 summaries found for {agent} track={track}")
        return {"conversations": 0, "topics": 0}

    if log:
        log(f"Extracting topics from {len(rows)} {track} L0 summaries")

    # Disable FK enforcement -- bt_id references benchmark_tests in production DB, not test DB
    db.sql("PRAGMA foreign_keys = OFF")

    # Clear existing topics for this agent+track (scoped by bt_id)
    if bt_id is not None:
        db.sql(
            "DELETE FROM benchmark_topics WHERE btop_agent = ? AND btop_track = ? AND bt_id = ?",
            (agent, track, bt_id),
        )
    else:
        db.sql(
            "DELETE FROM benchmark_topics WHERE btop_agent = ? AND btop_track = ?",
            (agent, track),
        )

    total_topics = 0

    for i, row in enumerate(rows, 1):
        conv_id = row["conv_id"]
        content = row["content"] or ""

        if not content.strip():
            continue

        if log:
            log(f"  [{i}/{len(rows)}] {conv_id[:20]}...")

        # LLM extraction
        response = llm.request(
            [
                {"role": "system", "content": FREE_EXTRACT_PROMPT},
                {"role": "user", "content": content},
            ],
            max_tokens=16000,
        )

        topics = _parse_topic_list(response)
        tokens = _count_tokens(content)

        for order, topic_str in enumerate(topics, 1):
            db.sql(
                """INSERT INTO benchmark_topics
                   (btop_agent, btop_source, btop_level, btop_is_conversation,
                    btop_content, btop_order, btop_track, btop_tokens, bt_id)
                   VALUES (?, ?, 0, 0, ?, ?, ?, ?, ?)""",
                (agent, conv_id, topic_str, order, track, tokens, bt_id),
            )

        total_topics += len(topics)

        if delay and i < len(rows):
            time.sleep(delay)

    if log:
        log(f"Done: {len(rows)} conversations, {total_topics} topics extracted")

    return {"conversations": len(rows), "topics": total_topics}


# ---------------------------------------------------------------------------
# SBERT pairwise topic matching
# ---------------------------------------------------------------------------

SBERT_MATCH_THRESHOLD = 0.4


def sbert_match_topics(
    db: "Database",
    agent: str,
    bt_id: int,
    *,
    threshold: float = SBERT_MATCH_THRESHOLD,
    sbert_model=None,
    log: callable | None = None,
) -> dict:
    """Match CF topics against CA topics using SBERT cosine similarity.

    For each CF topic, finds the best-matching CA topic above threshold.
    Stores results in benchmark_matches table.

    Returns dict with matched_count, ca_only_count, cf_only_count.
    """
    # Load topics (scoped by bt_id)
    ca_rows = db.sql(
        """SELECT btop_id, btop_content FROM benchmark_topics
           WHERE btop_agent = ? AND btop_track = 'context-aware'
           AND bt_id = ?
           ORDER BY btop_id""",
        (agent, bt_id))
    cf_rows = db.sql(
        """SELECT btop_id, btop_content FROM benchmark_topics
           WHERE btop_agent = ? AND btop_track = 'context-free'
           AND bt_id = ?
           ORDER BY btop_id""",
        (agent, bt_id))

    if not ca_rows or not cf_rows:
        if log:
            log(f"Missing topics: CA={len(ca_rows or [])}, CF={len(cf_rows or [])}")
        return {"matched_count": 0, "ca_only_count": len(ca_rows or []),
                "cf_only_count": len(cf_rows or [])}

    if log:
        log(f"Matching {len(cf_rows)} CF topics against {len(ca_rows)} CA topics...")

    # Load SBERT model once
    if sbert_model is None:
        import warnings
        from sentence_transformers import SentenceTransformer
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sbert_model = SentenceTransformer("all-MiniLM-L6-v2")

    # Batch encode all topics
    from sklearn.metrics.pairwise import cosine_similarity
    ca_texts = [r["btop_content"] for r in ca_rows]
    cf_texts = [r["btop_content"] for r in cf_rows]

    ca_embeddings = sbert_model.encode(ca_texts, convert_to_numpy=True)
    cf_embeddings = sbert_model.encode(cf_texts, convert_to_numpy=True)

    # Compute full similarity matrix: cf_count x ca_count
    sim_matrix = cosine_similarity(cf_embeddings, ca_embeddings)

    # Clear previous matches for this bt_id
    db.sql("DELETE FROM benchmark_matches WHERE bt_id = ?", (bt_id,))

    matched_ca_ids = set()
    matched_count = 0
    cf_only_count = 0

    for cf_idx, cf_row in enumerate(cf_rows):
        scores = sim_matrix[cf_idx]
        best_ca_idx = int(scores.argmax())
        best_score = float(scores[best_ca_idx])

        if best_score >= threshold:
            ca_row = ca_rows[best_ca_idx]
            # Skip if this CA topic already matched a higher-scoring CF topic
            if ca_row["btop_id"] not in matched_ca_ids:
                db.sql(
                    """INSERT INTO benchmark_matches
                       (bt_id, btop_cf_id, btop_ca_id, sbert_score)
                       VALUES (?, ?, ?, ?)""",
                    (bt_id, cf_row["btop_id"], ca_row["btop_id"], best_score))
                matched_ca_ids.add(ca_row["btop_id"])
                matched_count += 1
            else:
                # CA already taken — this CF topic is unmatched
                db.sql(
                    """INSERT INTO benchmark_matches
                       (bt_id, btop_cf_id, btop_ca_id, sbert_score)
                       VALUES (?, ?, NULL, ?)""",
                    (bt_id, cf_row["btop_id"], best_score))
                cf_only_count += 1
        else:
            # Below threshold — CF-only
            db.sql(
                """INSERT INTO benchmark_matches
                   (bt_id, btop_cf_id, btop_ca_id, sbert_score)
                   VALUES (?, ?, NULL, ?)""",
                (bt_id, cf_row["btop_id"], best_score))
            cf_only_count += 1

    ca_only_count = len(ca_rows) - len(matched_ca_ids)

    if log:
        log(f"Done: {matched_count} matched, {ca_only_count} CA-only, {cf_only_count} CF-only")

    return {
        "matched_count": matched_count,
        "ca_only_count": ca_only_count,
        "cf_only_count": cf_only_count,
    }


def sbert_match_per_conversation(
    db: "Database",
    agent: str,
    bt_id: int,
    *,
    threshold: float = SBERT_MATCH_THRESHOLD,
    log: callable | None = None,
) -> dict:
    """Match CF topics against CA topics per conversation using SBERT.

    Loops through conversations in chronological order, matching only topics
    from the same conversation. Stores match_conv_id on each row so the
    Review chart can compute cumulative RY over time.

    Returns dict with matched_count, ca_only_count, cf_only_count, per_conv (list).
    """
    import warnings
    from sentence_transformers import SentenceTransformer
    from sklearn.metrics.pairwise import cosine_similarity

    # Get ordered conversations (by date)
    convos = db.sql(
        """SELECT DISTINCT btop_source FROM benchmark_topics
           WHERE btop_agent = ? AND btop_track = 'context-aware'
           AND bt_id = ?
           ORDER BY btop_source""",
        (agent, bt_id))
    if not convos:
        return {"matched_count": 0, "ca_only_count": 0, "cf_only_count": 0, "per_conv": []}

    # Load model once
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        sbert_model = SentenceTransformer("all-MiniLM-L6-v2")

    # Clear previous matches
    db.sql("DELETE FROM benchmark_matches WHERE bt_id = ?", (bt_id,))

    total_matched = 0
    total_ca_only = 0
    total_cf_only = 0
    per_conv = []

    for conv in convos:
        conv_id = conv["btop_source"]

        ca_rows = db.sql(
            """SELECT btop_id, btop_content FROM benchmark_topics
               WHERE btop_agent = ? AND btop_track = 'context-aware'
                 AND btop_source = ? AND bt_id = ? ORDER BY btop_id""",
            (agent, conv_id, bt_id))
        cf_rows = db.sql(
            """SELECT btop_id, btop_content FROM benchmark_topics
               WHERE btop_agent = ? AND btop_track = 'context-free'
                 AND btop_source = ? AND bt_id = ? ORDER BY btop_id""",
            (agent, conv_id, bt_id))

        ca_count = len(ca_rows or [])
        cf_count = len(cf_rows or [])

        if not ca_rows or not cf_rows:
            # All topics are unmatched for this conversation
            for r in (ca_rows or []):
                total_ca_only += 1
            for r in (cf_rows or []):
                db.sql(
                    """INSERT INTO benchmark_matches
                       (bt_id, btop_cf_id, btop_ca_id, sbert_score, match_conv_id)
                       VALUES (?, ?, NULL, 0, ?)""",
                    (bt_id, r["btop_id"], conv_id))
                total_cf_only += 1
            per_conv.append({"conv_id": conv_id, "matched": 0,
                             "ca_only": ca_count, "cf_only": cf_count})
            continue

        # Encode and match within this conversation
        ca_texts = [r["btop_content"] for r in ca_rows]
        cf_texts = [r["btop_content"] for r in cf_rows]
        ca_emb = sbert_model.encode(ca_texts, convert_to_numpy=True)
        cf_emb = sbert_model.encode(cf_texts, convert_to_numpy=True)
        sim_matrix = cosine_similarity(cf_emb, ca_emb)

        matched_ca_ids = set()
        conv_matched = 0
        conv_cf_only = 0

        for cf_idx, cf_row in enumerate(cf_rows):
            scores = sim_matrix[cf_idx]
            best_ca_idx = int(scores.argmax())
            best_score = float(scores[best_ca_idx])

            if best_score >= threshold:
                ca_row = ca_rows[best_ca_idx]
                if ca_row["btop_id"] not in matched_ca_ids:
                    db.sql(
                        """INSERT INTO benchmark_matches
                           (bt_id, btop_cf_id, btop_ca_id, sbert_score, match_conv_id)
                           VALUES (?, ?, ?, ?, ?)""",
                        (bt_id, cf_row["btop_id"], ca_row["btop_id"], best_score, conv_id))
                    matched_ca_ids.add(ca_row["btop_id"])
                    conv_matched += 1
                else:
                    db.sql(
                        """INSERT INTO benchmark_matches
                           (bt_id, btop_cf_id, btop_ca_id, sbert_score, match_conv_id)
                           VALUES (?, ?, NULL, ?, ?)""",
                        (bt_id, cf_row["btop_id"], best_score, conv_id))
                    conv_cf_only += 1
            else:
                db.sql(
                    """INSERT INTO benchmark_matches
                       (bt_id, btop_cf_id, btop_ca_id, sbert_score, match_conv_id)
                       VALUES (?, ?, NULL, ?, ?)""",
                    (bt_id, cf_row["btop_id"], best_score, conv_id))
                conv_cf_only += 1

        conv_ca_only = ca_count - len(matched_ca_ids)
        total_matched += conv_matched
        total_ca_only += conv_ca_only
        total_cf_only += conv_cf_only

        per_conv.append({"conv_id": conv_id, "matched": conv_matched,
                         "ca_only": conv_ca_only, "cf_only": conv_cf_only})

    if log:
        log(f"Per-conv match: {total_matched} matched, {total_ca_only} CA-only, "
            f"{total_cf_only} CF-only across {len(per_conv)} conversations")

    return {
        "matched_count": total_matched,
        "ca_only_count": total_ca_only,
        "cf_only_count": total_cf_only,
        "per_conv": per_conv,
    }


# ---------------------------------------------------------------------------
# LLM verification of SBERT matches
# ---------------------------------------------------------------------------

LLM_VERIFY_PROMPT = """You are a topic-matching judge. For each pair below, judge whether the CF topic and CA topic genuinely refer to the same subject matter.

Consider:
- Do they describe the same work, feature, or concept?
- Minor wording differences are OK if the core subject is the same.
- A match is WRONG if the topics cover fundamentally different subjects despite surface similarity.

## Pairs to judge
{matches}

Return a JSON array of objects, one per pair, in this exact format:
[
  {{"cf_id": 123, "ca_id": 456, "confirmed": true}},
  {{"cf_id": 789, "ca_id": 012, "confirmed": false}}
]

Set "confirmed" to true if the match is genuine, false if not.
Return ONLY the JSON array, no other text."""


VERIFY_CHUNK_SIZE = 25


def llm_verify_matches(
    db: "Database",
    llm: "LLMClient",
    bt_id: int,
    *,
    log: callable | None = None,
) -> dict:
    """Verify SBERT matches via chunked LLM calls.

    Sends matched pairs in chunks of VERIFY_CHUNK_SIZE to avoid
    exceeding context window limits. Updates llm_confirmed column.
    Returns dict with confirmed_count, rejected_count.
    """
    # Load current matches with topic text
    matches = db.sql(
        """SELECT m.match_id, m.btop_cf_id, m.btop_ca_id, m.sbert_score,
                  cf.btop_content as cf_topic, ca.btop_content as ca_topic
           FROM benchmark_matches m
           JOIN benchmark_topics cf ON cf.btop_id = m.btop_cf_id
           LEFT JOIN benchmark_topics ca ON ca.btop_id = m.btop_ca_id
           WHERE m.bt_id = ? AND m.btop_ca_id IS NOT NULL
           ORDER BY m.sbert_score DESC""",
        (bt_id,))

    if not matches:
        if log:
            log("No matches to verify.")
        return {"confirmed_count": 0, "rejected_count": 0}

    # Process in chunks
    confirmed_count = 0
    rejected_count = 0
    total_chunks = (len(matches) + VERIFY_CHUNK_SIZE - 1) // VERIFY_CHUNK_SIZE

    if log:
        log(f"Verifying {len(matches)} matches in {total_chunks} chunks...")

    for chunk_idx in range(0, len(matches), VERIFY_CHUNK_SIZE):
        chunk = matches[chunk_idx:chunk_idx + VERIFY_CHUNK_SIZE]
        chunk_num = chunk_idx // VERIFY_CHUNK_SIZE + 1

        if log:
            log(f"Chunk {chunk_num}/{total_chunks} ({len(chunk)} pairs)...")

        # Format only the paired topics for this chunk
        match_list = "\n".join(
            f"- CF [{m['btop_cf_id']}] \"{m['cf_topic']}\" <-> CA [{m['btop_ca_id']}] \"{m['ca_topic']}\" (score: {m['sbert_score']:.3f})"
            for m in chunk)

        prompt = LLM_VERIFY_PROMPT.format(matches=match_list)
        response = llm.request([{"role": "user", "content": prompt}], max_tokens=4000)

        # Parse JSON response
        try:
            text = response.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[1]
                text = text.rsplit("```", 1)[0]
            verdicts = json.loads(text)
        except (json.JSONDecodeError, IndexError):
            if log:
                log(f"Chunk {chunk_num} parse failed: {response[:200]}")
            continue

        # Apply verdicts for this chunk
        verdict_map = {v["cf_id"]: v for v in verdicts}
        for m in chunk:
            verdict = verdict_map.get(m["btop_cf_id"])
            if verdict:
                confirmed = 1 if verdict.get("confirmed") else 0
                db.sql(
                    "UPDATE benchmark_matches SET llm_confirmed = ? WHERE match_id = ?",
                    (confirmed, m["match_id"]))
                if confirmed:
                    confirmed_count += 1
                else:
                    db.sql(
                        "UPDATE benchmark_matches SET btop_ca_id = NULL, llm_confirmed = 0 WHERE match_id = ?",
                        (m["match_id"],))
                    rejected_count += 1

    if log:
        log(f"Done: {confirmed_count} confirmed, {rejected_count} rejected")

    return {"confirmed_count": confirmed_count, "rejected_count": rejected_count}
