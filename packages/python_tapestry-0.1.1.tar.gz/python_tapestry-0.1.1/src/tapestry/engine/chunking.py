"""Chunked summarization for large conversations.

When a conversation transcript exceeds the LLM context window,
splits into chunks at message boundaries and produces intermediate
summaries that are combined in a final pass.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig
    from tapestry.llm import LLMClient


# Default chunk size in tokens. 20K is optimal for large models (120b+)
# based on SBERT ground truth retention benchmarks (12.6% at 20K vs 8.9% at 5K).
# Smaller models (8b, 20b) may benefit from lower values (5K-10K).
DEFAULT_CHUNK_TOKENS = 20_000

# Minimum remainder size in tokens. If the last chunk would be
# smaller than this, absorb it into the previous chunk.
MIN_REMAINDER_TOKENS = 10_000

# Threshold above which chunking kicks in.
# Between chunk_size and chunk_size + MIN_REMAINDER, send in one shot.
CHUNK_THRESHOLD_BUFFER = 10_000

# Buffer for merge passes — tighter than chunking threshold.
# Merge batches when combined summaries exceed chunk_size + this buffer.
MERGE_THRESHOLD_BUFFER = 2_000


def estimate_tokens(text: str) -> int:
    """Estimate token count from text using chars/4 heuristic."""
    return len(text) // 4


def chunk_messages(
    messages: list[dict],
    agent_label: str,
    user_label: str,
    chunk_size_tokens: int = DEFAULT_CHUNK_TOKENS,
    overlap: int = 0,
) -> list[list[dict]]:
    """Split messages into chunks that fit within the token budget.

    Each chunk is a list of message dicts. Splits always occur at
    message boundaries — never mid-message.

    If the last chunk would be smaller than MIN_REMAINDER_TOKENS,
    it gets absorbed into the previous chunk.

    Args:
        messages: List of message dicts with tmsg_role, tmsg_content.
        agent_label: Uppercase agent name for transcript formatting.
        user_label: Uppercase user name for transcript formatting.
        chunk_size_tokens: Max tokens per chunk.
        overlap: Number of messages from the end of the previous chunk
                 to include at the start of the next chunk for continuity.

    Returns:
        List of message groups (each group is a list of message dicts).
    """
    chunks = []
    current_chunk = []
    current_tokens = 0

    for msg in messages:
        role = user_label if msg["tmsg_role"] == "user" else agent_label
        msg_text = f"[{role}]: {msg['tmsg_content']}"
        msg_tokens = estimate_tokens(msg_text)

        if current_tokens + msg_tokens > chunk_size_tokens and current_chunk:
            chunks.append(current_chunk)
            # Start next chunk with overlap messages from the end of this one
            if overlap > 0:
                overlap_msgs = current_chunk[-overlap:]
                current_chunk = list(overlap_msgs)
                current_tokens = sum(
                    estimate_tokens(f"[{user_label if m['tmsg_role'] == 'user' else agent_label}]: {m['tmsg_content']}")
                    for m in overlap_msgs
                )
            else:
                current_chunk = []
                current_tokens = 0

        current_chunk.append(msg)
        current_tokens += msg_tokens

    if current_chunk:
        # Absorb small remainder into previous chunk
        if chunks and current_tokens < MIN_REMAINDER_TOKENS:
            chunks[-1].extend(current_chunk)
        else:
            chunks.append(current_chunk)

    return chunks


def format_transcript(
    messages: list[dict],
    agent_label: str,
    user_label: str,
) -> str:
    """Format messages into transcript text."""
    parts = []
    for r in messages:
        role = user_label if r["tmsg_role"] == "user" else agent_label
        parts.append(f"[{role}]: {r['tmsg_content']}")
    return "\n\n".join(parts)


def needs_chunking(
    messages: list[dict],
    agent_label: str,
    user_label: str,
    chunk_size_tokens: int = DEFAULT_CHUNK_TOKENS,
) -> bool:
    """Check if a conversation needs chunked summarization.

    Returns False if total tokens <= chunk_size + buffer (send in one shot).
    Returns True if total tokens > chunk_size + buffer.
    """
    transcript = format_transcript(messages, agent_label, user_label)
    total_tokens = estimate_tokens(transcript)
    return total_tokens > chunk_size_tokens + CHUNK_THRESHOLD_BUFFER


def summarize_chunked(
    messages: list[dict],
    llm: LLMClient,
    config: TapestryConfig,
    system_prompt: str,
    agent_label: str,
    user_label: str,
    chunk_size_tokens: int = DEFAULT_CHUNK_TOKENS,
    overlap: int = 0,
) -> str:
    """Produce a summary from a conversation that exceeds the context window.

    Process:
    1. Split messages into chunks at message boundaries (with optional overlap)
    2. Summarize each chunk, prepending the previous chunk's summary as context
    3. Hierarchical merge of chunk summaries into final L0

    Args:
        messages: All messages for the conversation.
        llm: LLM client.
        config: Tapestry config.
        system_prompt: The factual summary system prompt.
        agent_label: Uppercase agent name.
        user_label: Uppercase user name.
        chunk_size_tokens: Max tokens per chunk.
        overlap: Number of messages to overlap between adjacent chunks.

    Returns:
        Tuple of (final_summary_string, stats_dict).
        Stats dict keys: chunks, llm_calls, merge_levels, intermediate_tokens, final_tokens.
    """
    total_transcript = format_transcript(messages, agent_label, user_label)
    total_tokens = estimate_tokens(total_transcript)
    chunks = chunk_messages(messages, agent_label, user_label, chunk_size_tokens, overlap)

    stats = {
        "chunks": len(chunks),
        "llm_calls": 0,
        "merge_levels": 0,
        "intermediate_tokens": 0,
        "final_tokens": 0,
    }

    print(f"[CHUNKING] {len(messages)} messages, ~{total_tokens:,} tokens, "
          f"chunk size: {chunk_size_tokens:,} tokens")
    print(f"[CHUNKING] Split into {len(chunks)} chunks: "
          + ", ".join(f"{len(c)} msgs" for c in chunks))

    chunk_summaries = []
    prev_summary = None

    for i, chunk in enumerate(chunks):
        transcript = format_transcript(chunk, agent_label, user_label)
        chunk_tokens = estimate_tokens(transcript)
        print(f"[CHUNKING] Chunk {i + 1}/{len(chunks)}: "
              f"{len(chunk)} messages, ~{chunk_tokens:,} tokens")

        # Prepend previous chunk's summary as context
        if prev_summary:
            context_header = (
                f"--- PRIOR CONTEXT (summary of earlier part of this conversation) ---\n\n"
                f"{prev_summary}\n\n"
                f"--- CONTINUATION (summarize this next section) ---\n\n"
            )
            user_content = context_header + transcript
            total_input = estimate_tokens(user_content)
            print(f"[CHUNKING]   + prior summary context, total input: ~{total_input:,} tokens")
        else:
            user_content = transcript

        chunk_prompt = system_prompt
        if len(chunks) > 1:
            chunk_prompt += (
                f"\n\nNOTE: This is part {i + 1} of {len(chunks)} of a long conversation. "
                f"Summarize this section thoroughly. Your summary will be combined with "
                f"summaries of other sections to produce the final summary."
            )

        print(f"[CHUNKING]   Sending to LLM...")
        summary = llm.request([
            {"role": "system", "content": chunk_prompt},
            {"role": "user", "content": user_content},
        ])
        stats["llm_calls"] += 1

        summary_tokens = estimate_tokens(summary)
        print(f"[CHUNKING]   Got summary: ~{summary_tokens:,} tokens")
        chunk_summaries.append(summary)
        prev_summary = summary

    # Hierarchical merge — batch summaries into groups that fit within
    # chunk_size_tokens, merge each group, repeat until one summary remains
    merge_prompt = (
        system_prompt + "\n\n"
        "NOTE: Below are summaries of consecutive sections of one long conversation. "
        "Combine them into a single cohesive summary. Merge overlapping topics, "
        "remove redundancy, maintain chronological flow. The result should read "
        "as one unified summary, not as separate parts."
    )

    stats["intermediate_tokens"] = sum(estimate_tokens(s) for s in chunk_summaries)

    current_summaries = chunk_summaries
    merge_level = 0

    while len(current_summaries) > 1:
        merge_level += 1
        combined_tokens = sum(estimate_tokens(s) for s in current_summaries)

        if combined_tokens <= chunk_size_tokens + MERGE_THRESHOLD_BUFFER:
            # Fits in one pass — final merge
            combined = "\n\n---\n\n".join(
                f"### Part {i + 1}\n\n{s}" for i, s in enumerate(current_summaries)
            )
            print(f"[CHUNKING] Merge level {merge_level}: combining {len(current_summaries)} "
                  f"summaries (~{combined_tokens:,} tokens) into final L0")

            final_summary = llm.request([
                {"role": "system", "content": merge_prompt},
                {"role": "user", "content": combined},
            ])
            stats["llm_calls"] += 1
            stats["merge_levels"] = merge_level
            stats["final_tokens"] = estimate_tokens(final_summary)
            return final_summary, stats

        # Too large for one pass — batch into groups
        batches = _batch_summaries(current_summaries, chunk_size_tokens)
        print(f"[CHUNKING] Merge level {merge_level}: {len(current_summaries)} summaries "
              f"(~{combined_tokens:,} tokens) too large for one pass, "
              f"batching into {len(batches)} groups")

        merged = []
        for j, batch in enumerate(batches):
            batch_text = "\n\n---\n\n".join(
                f"### Part {k + 1}\n\n{s}" for k, s in enumerate(batch)
            )
            batch_tokens = estimate_tokens(batch_text)
            print(f"[CHUNKING]   Batch {j + 1}/{len(batches)}: "
                  f"{len(batch)} summaries, ~{batch_tokens:,} tokens")

            result = llm.request([
                {"role": "system", "content": merge_prompt},
                {"role": "user", "content": batch_text},
            ])
            stats["llm_calls"] += 1
            result_tokens = estimate_tokens(result)
            print(f"[CHUNKING]   Got merged summary: ~{result_tokens:,} tokens")
            merged.append(result)

        current_summaries = merged

    # Single summary remaining (edge case: only 1 chunk)
    stats["merge_levels"] = merge_level
    stats["final_tokens"] = estimate_tokens(current_summaries[0])
    return current_summaries[0], stats


def _batch_summaries(
    summaries: list[str],
    batch_size_tokens: int,
) -> list[list[str]]:
    """Group summaries into batches that fit within the token budget."""
    batches = []
    current_batch = []
    current_tokens = 0

    for s in summaries:
        s_tokens = estimate_tokens(s)
        if current_tokens + s_tokens > batch_size_tokens and current_batch:
            batches.append(current_batch)
            current_batch = []
            current_tokens = 0
        current_batch.append(s)
        current_tokens += s_tokens

    if current_batch:
        batches.append(current_batch)

    return batches
