"""
Tapestry - Hierarchical long-term memory for AI conversations.

Your AI forgets everything. Tapestry doesn't.

Usage::

    from tapestry import Tapestry

    t = Tapestry()
    t.ingest("conversations/")
    t.catchup()
    context = t.get_context(agent="default")

Or as a context manager::

    with Tapestry() as t:
        results = t.search("bug fix", agent="chatgpt")
"""

from __future__ import annotations

import os
from collections import defaultdict
from datetime import date
from typing import Any, TYPE_CHECKING

from tapestry._version import __version__
from tapestry.config import load_config
from tapestry.db import Database
from tapestry.schema import init_db

if TYPE_CHECKING:
    from collections.abc import Callable

    from tapestry.config import TapestryConfig
    from tapestry.llm import LLMClient


class Tapestry:
    """High-level API for the tapestry memory system.

    Handles configuration, database, and LLM client lifecycle.
    The LLM client is created lazily -- query methods work without an API key.

    Args:
        config_path: Path to tapestry.toml. If None, searches upward from CWD.
        **overrides: Override any TapestryConfig field (e.g., db_path="custom.db").
    """

    def __init__(self, config_path: str | None = None, **overrides: Any) -> None:
        self._default_agent: str | None = overrides.pop("agent", None)
        self.config: TapestryConfig = load_config(config_path, **overrides)
        self.db: Database = Database(self.config.db_path)
        self.db.ensure_directory()
        init_db(self.db)
        self._llm: LLMClient | None = None
        self._agent_cache: dict[str, int] = {}

    @property
    def llm(self) -> LLMClient:
        """LLM client, created on first access."""
        if self._llm is None:
            from tapestry.llm import LLMClient as _LLMClient
            self._llm = _LLMClient(self.config.llm)
        return self._llm

    def _agent(self, agent: str | None) -> str:
        """Resolve agent name: use provided, or constructor default, or first from config."""
        if agent:
            return agent
        if self._default_agent:
            return self._default_agent
        return next(iter(self.config.agents))

    def _resolve_agent(self, agent: str | int | None) -> tuple[str, int]:
        """Resolve agent name or ID to (name, agent_id). Creates agent if not found.

        Accepts:
            int or digit string — lookup by agent_id
            str — lookup by agent_name
            None — use default agent
        """
        # Handle integer IDs (int or digit string)
        if isinstance(agent, int) or (isinstance(agent, str) and agent.isdigit()):
            aid = int(agent)
            # Check cache (reverse lookup)
            for cached_name, cached_id in self._agent_cache.items():
                if cached_id == aid:
                    return cached_name, cached_id
            row = self.db.sql(
                "SELECT agent_name FROM tapestry_agents WHERE agent_id = ?",
                (aid,),
                single=True,
            )
            if row:
                self._agent_cache[row["agent_name"]] = aid
                return row["agent_name"], aid
            raise ValueError(f"No agent with ID {aid}")

        name = self._agent(agent)
        if name in self._agent_cache:
            return name, self._agent_cache[name]

        row = self.db.sql(
            "SELECT agent_id FROM tapestry_agents WHERE agent_name = ?",
            (name,),
            single=True,
        )
        if row:
            self._agent_cache[name] = row["agent_id"]
            return name, row["agent_id"]

        # Auto-create on first use
        agent_id = self.db.sql(
            "INSERT INTO tapestry_agents (agent_name) VALUES (?)",
            (name,),
        )
        self._agent_cache[name] = agent_id
        return name, agent_id

    # ── Ingest ────────────────────────────────────────────────────────

    def ingest(
        self,
        path: str,
        agent: str | None = None,
        parser_name: str | None = None,
    ) -> dict[str, int]:
        """Import conversation files into the database.

        Args:
            path: File or directory path. Directories are scanned recursively.
            agent: Agent name. Defaults to first configured agent.
            parser_name: Parser to use (chatgpt, claude-code, generic).
                Auto-detects if omitted.

        Returns:
            Dict with keys: conversations (imported count), skipped, messages.
        """
        from tapestry.parsers import detect_parser, get_parser

        agent = self._agent(agent)

        if parser_name is None and agent in self.config.agents:
            parser_name = self.config.agents[agent].parser

        totals = {"conversations": 0, "skipped": 0, "messages": 0}

        if os.path.isdir(path):
            for filepath in sorted(_collect_files(path)):
                result = self._ingest_file(filepath, agent, parser_name)
                totals["conversations"] += result["conversations"]
                totals["skipped"] += result["skipped"]
                totals["messages"] += result["messages"]
        elif os.path.isfile(path):
            result = self._ingest_file(path, agent, parser_name)
            totals.update(result)
        else:
            raise FileNotFoundError(f"Path not found: {path}")

        return totals

    def _ingest_file(
        self,
        filepath: str,
        agent: str,
        parser_name: str | None,
    ) -> dict[str, int]:
        """Ingest a single file. Returns import stats."""
        from tapestry.parsers import detect_parser, get_parser

        if parser_name:
            parser = get_parser(parser_name)
        else:
            parser = detect_parser(filepath)
            if parser is None:
                return {"conversations": 0, "skipped": 0, "messages": 0}

        messages = parser.parse(filepath)
        if not messages:
            return {"conversations": 0, "skipped": 0, "messages": 0}

        _name, agent_id = self._resolve_agent(agent)

        grouped: dict[str, list] = defaultdict(list)
        for msg in messages:
            cid = msg.conversation_id or os.path.basename(filepath)
            grouped[cid].append(msg)

        imported = 0
        skipped = 0
        total_msgs = 0

        for conv_id, conv_msgs in grouped.items():
            existing = self.db.sql(
                "SELECT COUNT(*) as cnt FROM tapestry_messages WHERE tmsg_ref_conv_id = ? AND tmsg_agent_id = ?",
                (conv_id, agent_id),
                single=True,
            )
            existing_count = existing["cnt"] if existing else 0
            if existing_count >= len(conv_msgs):
                skipped += 1
                continue

            # Insert only new messages (incremental)
            msgs_to_insert = conv_msgs[existing_count:]
            for i, msg in enumerate(msgs_to_insert):
                self.db.sql(
                    """INSERT OR IGNORE INTO tapestry_messages
                       (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role,
                        tmsg_content, tmsg_order, tmsg_timestamp)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (agent, agent_id, msg.uuid, conv_id, msg.role, msg.content, existing_count + i, msg.timestamp),
                )

            imported += 1
            total_msgs += len(msgs_to_insert)

        return {"conversations": imported, "skipped": skipped, "messages": total_msgs}

    # ── Engine ────────────────────────────────────────────────────────

    def catchup(
        self,
        agent: str | None = None,
        delay: float = 1.0,
        log: Callable | None = None,
    ) -> dict[str, int]:
        """Bulk rebuild WITHOUT telescoping context. For testing/initial ingest only.

        Args:
            agent: Agent name. Defaults to first configured agent.
            delay: Seconds between API calls.
            log: Optional callable for progress output.

        Returns:
            Dict with l0, l1, l2, l3 generation counts.
        """
        from tapestry.engine import catchup as _catchup
        name, agent_id = self._resolve_agent(agent)
        return _catchup(self.db, self.llm, self.config, name, agent_id, log=log, delay=delay)

    def iterate(
        self,
        end_date: str,
        agent: str | None = None,
        save: bool = False,
        log: Callable | None = None,
    ) -> dict[str, int]:
        """Context-aware date-by-date processing with repair cascade.

        This is the production-quality build command. Loads full telescoping
        context before generating each node.

        Args:
            end_date: YYYY-MM-DD last date to process.
            agent: Agent name. Defaults to first configured agent.
            save: If False, dry run. If True, generate and store.
            log: Optional callable for progress output.

        Returns:
            Dict with l0, l1, l2, l3 generation counts.
        """
        from tapestry.engine import iterate as _iterate
        name, agent_id = self._resolve_agent(agent)
        return _iterate(
            self.db, self.llm, self.config, name, agent_id,
            end_date, save=save, log=log,
        )

    # ── Query ─────────────────────────────────────────────────────────

    def get_context(
        self,
        agent: str | None = None,
        anchor_date: str | None = None,
        max_level: int | None = None,
        min_date: str | None = None,
        auto_repair: bool = True,
    ) -> list[dict]:
        """Get telescoping context for a date.

        Walks the hierarchy (yearly -> monthly -> weekly -> daily -> L0)
        and returns context items suitable for injection into a prompt.
        When gaps are detected and auto_repair is True, missing summaries
        are generated before returning results.

        Args:
            agent: Agent name. Defaults to first configured agent.
            anchor_date: YYYY-MM-DD date to anchor on. Defaults to today.
            max_level: If set, exclude levels above this.
            min_date: If set (YYYY-MM-DD), exclude records before this date.
            auto_repair: If True (default), auto-generate missing summaries.

        Returns:
            List of context item dicts: level, tap_id, title, content, range.
        """
        from tapestry.engine.context import resolve_context
        if anchor_date is None:
            anchor_date = date.today().isoformat()
        name, agent_id = self._resolve_agent(agent)
        context_items, repairs = resolve_context(
            self.db, name, agent_id, anchor_date,
            max_level=max_level, min_date=min_date,
        )

        if repairs and auto_repair:
            from tapestry.engine.repair import repair_from_first_gap
            repair_from_first_gap(
                self.db, self.llm, self.config, name, agent_id, repairs,
            )
            # Re-resolve to pick up newly generated summaries
            context_items, _ = resolve_context(
                self.db, name, agent_id, anchor_date,
                max_level=max_level, min_date=min_date,
            )

        return context_items

    def search(
        self,
        query: str,
        agent: str | None = None,
        level: int | None = None,
    ) -> list[dict]:
        """Search conversation messages for a keyword.

        Args:
            query: Search term (case-insensitive).
            agent: Agent name. Defaults to first configured agent.
            level: If set, only return results with a summary at this level.

        Returns:
            List of dicts: conv_id, date, match_count, tap_id, title, sample.
        """
        from tapestry.query import search as _search
        name, agent_id = self._resolve_agent(agent)
        return _search(self.db, name, agent_id, query, level=level)

    def search_summaries(
        self,
        query: str,
        agent: str | None = None,
        level: int | None = None,
    ) -> list[dict]:
        """Search tapestry summary content for a keyword.

        Args:
            query: Search term (case-insensitive).
            agent: Agent name. Defaults to first configured agent.
            level: If set, only search summaries at this level.

        Returns:
            List of dicts: tap_id, level, title, date, date_start, date_end, preview.
        """
        from tapestry.query import search_summaries as _search_summaries
        name, agent_id = self._resolve_agent(agent)
        return _search_summaries(self.db, name, agent_id, query, level=level)

    def similar(
        self,
        query: str,
        agent: str | None = None,
        level: int | None = None,
        top_n: int = 10,
    ) -> list[dict]:
        """Find tapestry records most similar to a query using TF-IDF cosine similarity.

        Requires scikit-learn: pip install total-recall[search]

        Args:
            query: Natural language query to match against.
            agent: Agent name. Defaults to first configured agent.
            level: If set, only search summaries at this level (0-4).
            top_n: Number of top results to return (default 10).

        Returns:
            List of dicts: tap_id, level, title, date, date_start, date_end, score, preview.
        """
        from tapestry.query import cosine_search as _cosine_search
        name, agent_id = self._resolve_agent(agent)
        return _cosine_search(self.db, name, agent_id, query, level=level, top_n=top_n)

    def fulltext(
        self,
        query: str,
        agent: str | None = None,
        level: int | None = None,
        top_n: int = 20,
    ) -> list[dict]:
        """Full-text search across summaries and messages using FTS5.

        Args:
            query: Search query (supports FTS5 syntax: "phrases", OR, AND, NOT).
            agent: Agent name. Defaults to first configured agent.
            level: If set, only return summary results at this level (0-4).
            top_n: Max results (default 20).

        Returns:
            List of dicts: tap_id, level, title, date, score, preview, source, conv_id.
        """
        from tapestry.query import fulltext_search as _fulltext_search
        name, agent_id = self._resolve_agent(agent)
        return _fulltext_search(
            self.db, name, agent_id, query, level=level, top_n=top_n
        )

    def regex(
        self,
        pattern: str,
        agent: str | None = None,
        level: int | None = None,
        top_n: int = 20,
    ) -> list[dict]:
        """Search summaries and messages using Python regex.

        Args:
            pattern: Python regex pattern (re.search syntax, case-insensitive).
            agent: Agent name. Defaults to first configured agent.
            level: If set, only return summary results at this level (0-4).
            top_n: Max results (default 20).

        Returns:
            List of result dicts matching unified search format.
        """
        from tapestry.query import regex_search as _regex_search
        name, agent_id = self._resolve_agent(agent)
        return _regex_search(self.db, name, agent_id, pattern, level=level, top_n=top_n)

    def unified_search(
        self,
        query: str,
        agent: str | None = None,
        mode: str = "auto",
        level: int | None = None,
        top_n: int = 20,
        max_level: int | None = None,
        min_date: str | None = None,
    ) -> list[dict]:
        """Two-layer search combining semantic and fulltext.

        Modes:
            auto:     Semantic on summaries + FTS5 on messages (default).
            semantic: TF-IDF cosine on summaries only.
            fulltext: FTS5 on both summaries and messages.

        Args:
            query: Search query.
            agent: Agent name. Defaults to first configured agent.
            mode: Search mode (auto/semantic/fulltext).
            level: Filter summary results by level (0-4).
            top_n: Max results (default 20).
            max_level: If set, exclude records above this level.
            min_date: If set (YYYY-MM-DD), exclude records before this date.

        Returns:
            Unified result list with source and mode_used fields.
        """
        from tapestry.query import unified_search as _unified_search
        name, agent_id = self._resolve_agent(agent)
        return _unified_search(
            self.db, name, agent_id, query, mode=mode, level=level, top_n=top_n,
            max_level=max_level, min_date=min_date,
        )

    def recall(
        self,
        date_str: str,
        agent: str | None = None,
        end_date: str | None = None,
        max_level: int | None = None,
        min_date: str | None = None,
    ) -> list[dict]:
        """Recall the best-level summaries for a date or range.

        Single date: tries daily first, falls back to L0 conversations.
        Range: tries weekly/monthly first, falls back to dailies.

        Args:
            date_str: Start date (YYYY-MM-DD).
            agent: Agent name. Defaults to first configured agent.
            end_date: Optional end date for range queries.
            max_level: If set, exclude records above this level.
            min_date: If set (YYYY-MM-DD), exclude records before this date.

        Returns:
            List of tapestry record dicts.
        """
        from tapestry.query import recall as _recall
        name, agent_id = self._resolve_agent(agent)
        return _recall(self.db, name, agent_id, date_str, end_date,
                        max_level=max_level, min_date=min_date)

    def show(self, tap_id: int) -> dict | None:
        """Get a single tapestry record by ID.

        Returns:
            Dict with all tapestry columns, or None if not found.
        """
        from tapestry.query import show as _show
        return _show(self.db, tap_id)

    def conversations(self, agent: str | None = None) -> list[dict]:
        """List all imported conversations with message counts.

        Args:
            agent: Agent filter. If None, shows all agents.

        Returns:
            List of dicts: conv_id, agent, msg_count, first_msg, last_msg, date.
        """
        from tapestry.query import conversations as _conversations
        if agent is not None:
            name, agent_id = self._resolve_agent(agent)
            return _conversations(self.db, name, agent_id)
        return _conversations(self.db, None, None)

    def agents(self) -> list[dict]:
        """List all agents in the database with record counts.

        Returns:
            List of dicts: id, name, color, count. Ordered alphabetically.
        """
        rows = self.db.sql(
            """SELECT a.agent_id, a.agent_name, a.agent_color,
                      COUNT(t.tap_id) as count
               FROM tapestry_agents a
               LEFT JOIN tapestry t ON t.tap_agent_id = a.agent_id
               GROUP BY a.agent_id
               ORDER BY a.agent_name"""
        ) or []
        return [
            {
                "id": r["agent_id"],
                "name": r["agent_name"],
                "color": r["agent_color"],
                "count": r["count"],
            }
            for r in rows
        ]

    def show_conversation(self, conv_id_prefix: str) -> dict | None:
        """Display messages from a conversation by ID or prefix.

        Returns:
            Dict with conv_id, msg_count, messages list, or None.
        """
        from tapestry.query import show_conversation as _show_conversation
        return _show_conversation(self.db, conv_id_prefix)

    def tree(self, agent: str | None = None) -> dict:
        """Build the full tapestry hierarchy tree.

        Returns:
            Dict with monthlies (nested weeklies/dailies),
            orphaned_weeklies, orphaned_dailies.
        """
        from tapestry.query import tree as _tree
        name, agent_id = self._resolve_agent(agent)
        return _tree(self.db, name, agent_id)

    def stats(self, agent: str | None = None) -> dict:
        """Compute record counts and size statistics by level.

        Returns:
            Dict with levels, messages, conversations, total_records,
            total_chars, est_tokens.
        """
        from tapestry.query import stats as _stats
        name, agent_id = self._resolve_agent(agent)
        return _stats(self.db, name, agent_id)

    def drift(self, tap_id: int, agent: str | None = None) -> dict:
        """Measure how regenerating a node would change its ancestors.

        Walks up the hierarchy from tap_id, regenerating each ancestor
        from its current children, and compares via TF-IDF cosine similarity.

        Requires scikit-learn: pip install total-recall[search]

        Args:
            tap_id: The tapestry record ID to measure drift from.
            agent: Agent name. Defaults to first configured agent.

        Returns:
            Dict with target info, ancestor drift scores, and UX description.
        """
        from tapestry.engine.drift import measure_drift
        name, agent_id = self._resolve_agent(agent)
        return measure_drift(self.db, self.llm, self.config, name, agent_id, tap_id)

    def status(self, agent: str | None = None) -> dict:
        """Build a status dashboard for the agent's tapestry.

        Returns:
            Dict with agent, db_path, stats, date_range, unsummarized,
            missing_dailies, health.
        """
        from tapestry.query import status as _status
        name, agent_id = self._resolve_agent(agent)
        config_path = str(self.config.project_dir) if self.config.project_dir else None
        return _status(self.db, name, agent_id, config_path=config_path)

    # ── Write ──────────────────────────────────────────────────────────

    def save(self, agent, title: str, content: str) -> dict:
        """Save a conversation summary as a Level 0 memory.

        Use this to write an L0 record directly — no LLM processing.
        The caller is responsible for the summary quality.

        Args:
            agent: Agent name (must exist in the database).
            title: Short descriptive title (max 200 chars).
            content: Full summary text (markdown).

        Returns:
            Dict with tap_id, tap_agent, tap_title, tap_date, size.

        Raises:
            ValueError: If title or content is empty.
        """
        if not title or not title.strip():
            raise ValueError("title is required")
        if not content or not content.strip():
            raise ValueError("content is required")

        title = title.strip()[:200]
        content = content.strip()

        import uuid
        from datetime import datetime

        name, agent_id = self._resolve_agent(agent)
        today = datetime.now().strftime('%Y-%m-%d')
        source_id = f"api-{name}-{uuid.uuid4().hex[:12]}"

        tap_id = self.db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            (name, agent_id, title, content, today, source_id),
        )

        try:
            self.db.sql(
                "INSERT INTO tapestry_fts(rowid, tap_title, tap_content) VALUES (?, ?, ?)",
                (tap_id, title, content),
            )
        except Exception:
            pass  # FTS rebuild will catch it

        return {
            "tap_id": tap_id,
            "tap_agent": name,
            "tap_title": title,
            "tap_date": today,
            "size": len(content),
        }

    # ── Lifecycle ─────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the database connection."""
        self.db.close()

    def __enter__(self) -> Tapestry:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        agent_count = len(self.config.agents)
        return f"Tapestry(db={self.config.db_path!r}, agents={agent_count})"


def _collect_files(directory: str) -> list[str]:
    """Walk a directory and return all supported conversation files."""
    supported = (".jsonl", ".json")
    files: list[str] = []
    for root, _dirs, filenames in os.walk(directory):
        for fname in filenames:
            if any(fname.endswith(ext) for ext in supported):
                files.append(os.path.join(root, fname))
    return files


__all__ = ["Tapestry", "__version__"]
