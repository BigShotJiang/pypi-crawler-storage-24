"""Tapestry web UI — Flask calendar application."""

from __future__ import annotations

import importlib.resources
from typing import TYPE_CHECKING

from flask import Flask

if TYPE_CHECKING:
    from tapestry import Tapestry as TapestryClass


def create_app(tapestry: TapestryClass) -> Flask:
    """Create the Flask app for the tapestry calendar UI.

    Args:
        tapestry: A Tapestry instance (provides DB access).

    Returns:
        Configured Flask application.
    """
    pkg = importlib.resources.files('tapestry.web')
    template_dir = str(pkg / 'templates')
    static_dir = str(pkg / 'static')

    app = Flask(
        __name__,
        template_folder=template_dir,
        static_folder=static_dir,
    )

    app.config['TAPESTRY'] = tapestry
    app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024 * 1024  # 2GB for large exports

    from tapestry.web.routes import cal
    app.register_blueprint(cal, url_prefix='/cal')

    @app.route('/')
    def root():
        from flask import redirect, url_for
        return redirect(url_for('cal.index'))

    return app
