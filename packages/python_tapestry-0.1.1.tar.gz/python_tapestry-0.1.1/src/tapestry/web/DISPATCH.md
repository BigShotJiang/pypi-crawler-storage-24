# Dispatch Framework — Quick Reference

Declarative AJAX system for Flask apps. Backend routes return JSON with DOM manipulation instructions.

## HTML Triggers

```html
<!-- Click triggers AJAX -->
<a class="tmbtn" data-module="cal" data-action="grid/2026/3">Load March</a>

<!-- Form submit triggers AJAX -->
<form class="ajaxform" data-module="cal" data-action="upload">
    <input type="file" name="file">
    <button type="submit">Upload</button>
</form>
```

## Data Attributes

| Attribute | Purpose |
|-----------|---------|
| `data-module` | Blueprint/URL prefix (e.g., `cal`) |
| `data-action` | Route path (e.g., `grid/2026/3`) |
| `data-data` | Extra POST params (e.g., `agent=chatgpt`) |
| `data-noload` | Skip loading spinner |
| `data-vboxclose` | Close modal without AJAX |

URL construction: `/{module}/{action}`

## Backend Response Format

Routes return JSON. The framework executes commands in order:

```python
return jsonify({
    'htmls': {'#selector': 'new html'},       # Replace element content
    'appends': {'#container': 'new html'},     # Append to element
    'values': {'#input': 'new value'},         # Set input values
    'vbox': '<modal html>',                    # Open modal
    'vboxclose': True,                         # Close modal
    'alert': json.dumps({'title': '...', 'type': 'success'}),  # Notification
    'redirect': '/url',                        # Navigate
    'removes': ['#element'],                   # Remove elements
})
```

## Programmatic AJAX

```javascript
dispatchPost('cal', 'grid/2026/3', 'agent=chatgpt');
```

## Dependencies

- jQuery 3.7.1
- PNotify (notifications)
- Font Awesome (icons)
