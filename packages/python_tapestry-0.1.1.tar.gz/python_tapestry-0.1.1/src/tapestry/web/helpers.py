"""Helper functions for building calendar data."""

from __future__ import annotations

import calendar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tapestry.db import Database

def _resolve_agent_id(db: Database, agent: str) -> int | None:
    """Resolve agent name to integer ID. Returns None if not found."""
    row = db.sql(
        "SELECT agent_id FROM tapestry_agents WHERE agent_name = ?",
        (agent,),
        single=True,
    )
    return row["agent_id"] if row else None


# Default agent colors
DEFAULT_COLORS = {
    'chatgpt': '#10A37F',
    'claude': '#D97706',
    'claude-code': '#8B5CF6',
}


def get_agents(db: Database) -> list[dict]:
    """Get all agents from the tapestry_agents table."""
    rows = db.sql(
        "SELECT agent_id, agent_name, agent_color FROM tapestry_agents ORDER BY agent_name"
    )
    return [{"id": r["agent_id"], "name": r["agent_name"], "color": r["agent_color"]} for r in rows] if rows else []


def get_agent_color(db: Database, agent: str) -> str:
    """Get hex color for an agent. Checks tapestry_agents, falls back to defaults."""
    row = db.sql(
        "SELECT agent_color FROM tapestry_agents WHERE agent_name = ?",
        (agent,),
        single=True,
    )
    if row and row['agent_color']:
        return row['agent_color']
    return DEFAULT_COLORS.get(agent, '#6C757D')


def get_agent_colors(db: Database) -> dict[str, str]:
    """Get all agent colors as {agent_name: hex_color}."""
    agents = get_agents(db)
    return {a["name"]: a["color"] or DEFAULT_COLORS.get(a["name"], '#6C757D') for a in agents}


def set_agent_color(db: Database, agent: str, color: str) -> None:
    """Set hex color for an agent in tapestry_agents."""
    db.sql(
        "UPDATE tapestry_agents SET agent_color = ? WHERE agent_name = ?",
        (color, agent),
    )


def get_dailies_for_month(
    db: Database, year: int, month: int, agent: str | None = None
) -> dict[str, list[dict]]:
    """Get L1 daily summaries for a month, grouped by date.

    Returns: {date_str: [{'tap_id': ..., 'title': ..., 'agent': ...}, ...]}
    """
    start = f"{year:04d}-{month:02d}-01"
    last_day = calendar.monthrange(year, month)[1]
    end = f"{year:04d}-{month:02d}-{last_day:02d}"

    params: list = [start, end]
    agent_clause = ""
    if agent:
        agent_clause = "AND tap_agent_id = ?"
        params.append(_resolve_agent_id(db, agent))

    rows = db.sql(
        f"""SELECT tap_id, tap_title, tap_date, tap_agent
            FROM tapestry
            WHERE tap_level = 1
            AND tap_date >= ? AND tap_date <= ?
            {agent_clause}
            ORDER BY tap_date, tap_agent""",
        tuple(params),
    )

    result: dict[str, list[dict]] = {}
    if rows:
        for r in rows:
            d = r['tap_date']
            if d not in result:
                result[d] = []
            result[d].append({
                'tap_id': r['tap_id'],
                'title': r['tap_title'],
                'agent': r['tap_agent'],
            })
    return result


def get_weeklies_for_month(
    db: Database, year: int, month: int, agent: str | None = None
) -> list[dict]:
    """Get L2 weekly summaries that overlap with a month."""
    start = f"{year:04d}-{month:02d}-01"
    last_day = calendar.monthrange(year, month)[1]
    end = f"{year:04d}-{month:02d}-{last_day:02d}"

    params: list = [end, start]
    agent_clause = ""
    if agent:
        agent_clause = "AND tap_agent_id = ?"
        params.append(_resolve_agent_id(db, agent))

    rows = db.sql(
        f"""SELECT tap_id, tap_title, tap_date_start, tap_date_end, tap_agent
            FROM tapestry
            WHERE tap_level = 2
            AND tap_date_start <= ? AND tap_date_end >= ?
            {agent_clause}
            ORDER BY tap_date_start""",
        tuple(params),
    )

    return [dict(r) for r in rows] if rows else []


def get_monthly_for_month(
    db: Database, year: int, month: int, agent: str | None = None
) -> dict | None:
    """Get L3 monthly summary for exact month."""
    start = f"{year:04d}-{month:02d}-01"
    last_day = calendar.monthrange(year, month)[1]
    end = f"{year:04d}-{month:02d}-{last_day:02d}"

    params: list = [start, end]
    agent_clause = ""
    if agent:
        agent_clause = "AND tap_agent_id = ?"
        params.append(_resolve_agent_id(db, agent))

    row = db.sql(
        f"""SELECT tap_id, tap_title, tap_content, tap_agent
            FROM tapestry
            WHERE tap_level = 3
            AND tap_date_start = ? AND tap_date_end = ?
            {agent_clause}
            ORDER BY tap_id LIMIT 1""",
        tuple(params),
        single=True,
    )

    return dict(row) if row else None


def get_yearly_for_year(
    db: Database, year: int, agent: str | None = None
) -> dict | None:
    """Get L4 yearly summary for a year."""
    start = f"{year:04d}-01-01"
    end = f"{year:04d}-12-31"

    params: list = [start, end]
    agent_clause = ""
    if agent:
        agent_clause = "AND tap_agent_id = ?"
        params.append(_resolve_agent_id(db, agent))

    row = db.sql(
        f"""SELECT tap_id, tap_title, tap_content, tap_agent
            FROM tapestry
            WHERE tap_level = 4
            AND tap_date_start = ? AND tap_date_end = ?
            {agent_clause}
            ORDER BY tap_id LIMIT 1""",
        tuple(params),
        single=True,
    )

    return dict(row) if row else None


def get_all_monthlies_for_month(db: Database, year: int, month: int) -> list[dict]:
    """Get ALL agents' L3 monthly summaries for a given month."""
    start = f"{year:04d}-{month:02d}-01"
    last_day = calendar.monthrange(year, month)[1]
    end = f"{year:04d}-{month:02d}-{last_day:02d}"
    rows = db.sql(
        """SELECT tap_id, tap_title, tap_content, tap_agent
           FROM tapestry
           WHERE tap_level = 3
           AND tap_date_start = ? AND tap_date_end = ?
           ORDER BY tap_agent""",
        (start, end),
    )
    return [dict(r) for r in rows] if rows else []


def get_all_yearlies_for_year(db: Database, year: int) -> list[dict]:
    """Get ALL agents' L4 yearly summaries for a given year."""
    start = f"{year:04d}-01-01"
    end = f"{year:04d}-12-31"
    rows = db.sql(
        """SELECT tap_id, tap_title, tap_content, tap_agent
           FROM tapestry
           WHERE tap_level = 4
           AND tap_date_start = ? AND tap_date_end = ?
           ORDER BY tap_agent""",
        (start, end),
    )
    return [dict(r) for r in rows] if rows else []


def get_day_detail(
    db: Database, date_str: str, agent: str | None = None
) -> dict:
    """Get full day detail: L1 daily + L0 conversations."""
    params: list = [date_str]
    agent_clause = ""
    if agent:
        agent_clause = "AND tap_agent_id = ?"
        params.append(_resolve_agent_id(db, agent))

    dailies = db.sql(
        f"""SELECT tap_id, tap_title, tap_content, tap_agent
            FROM tapestry
            WHERE tap_level = 1 AND tap_date = ?
            {agent_clause}
            ORDER BY tap_agent""",
        tuple(params),
    )

    l0s = db.sql(
        f"""SELECT tap_id, tap_title, tap_content, tap_source, tap_agent
            FROM tapestry
            WHERE tap_level = 0 AND tap_date = ?
            {agent_clause}
            ORDER BY tap_id""",
        tuple(params),
    )

    return {
        'date': date_str,
        'dailies': [dict(r) for r in dailies] if dailies else [],
        'conversations': [dict(r) for r in l0s] if l0s else [],
    }


def build_month_grid(year: int, month: int) -> list[list[dict]]:
    """Build month grid as weeks of day cells.

    Returns: [[{'day': 0, 'date': ''}, ...], ...]
    Empty cells have day=0 and empty date.
    """
    cal = calendar.Calendar(firstweekday=0)  # Monday first
    weeks = []

    for week in cal.monthdayscalendar(year, month):
        week_cells = []
        for day in week:
            if day == 0:
                week_cells.append({'day': 0, 'date': ''})
            else:
                d = f"{year:04d}-{month:02d}-{day:02d}"
                week_cells.append({'day': day, 'date': d})
        weeks.append(week_cells)

    return weeks


def week_date_range(week: list[dict]) -> tuple[str, str]:
    """Get date range (start, end) for a week row."""
    dates = [c['date'] for c in week if c['date']]
    return (dates[0], dates[-1]) if dates else ('', '')


def find_weekly_for_range(
    weeklies: list[dict], start: str, end: str
) -> dict | None:
    """Find the weekly summary that overlaps a given date range."""
    for w in weeklies:
        ws = w.get('tap_date_start', '')
        we = w.get('tap_date_end', '')
        if ws and we and ws <= end and we >= start:
            return w
    return None
