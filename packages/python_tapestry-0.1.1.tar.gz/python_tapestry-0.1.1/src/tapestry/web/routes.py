"""Flask blueprint for tapestry calendar UI."""

from __future__ import annotations

import calendar as cal_mod
import json

from flask import Blueprint, current_app, jsonify, render_template, request

from tapestry.web.helpers import (
    build_month_grid,
    find_weekly_for_range,
    get_agent_colors,
    get_agents,
    get_all_monthlies_for_month,
    get_all_yearlies_for_year,
    get_dailies_for_month,
    get_day_detail,
    get_monthly_for_month,
    get_weeklies_for_month,
    get_yearly_for_year,
    set_agent_color,
    week_date_range,
)

cal = Blueprint('cal', __name__)


def _tapestry():
    """Get the Tapestry instance from app config."""
    return current_app.config['TAPESTRY']


def _find_conversations_json(tmpdir: str) -> str | None:
    """Find conversations.json in an extracted ZIP.

    Both Anthropic and ChatGPT exports bundle conversations.json
    alongside metadata files. Returns the path if found, None otherwise.
    """
    import os

    for root, _dirs, files in os.walk(tmpdir):
        for f in files:
            if f.lower() == 'conversations.json':
                return os.path.join(root, f)
    return None


@cal.route('/')
def index():
    """Serve the full calendar page with current month grid."""
    from datetime import date

    t = _tapestry()
    today = date.today()
    year, month = today.year, today.month
    agent = request.args.get('agent') or None

    agents = get_agents(t.db)
    colors = get_agent_colors(t.db)
    grid = build_month_grid(year, month)
    dailies = get_dailies_for_month(t.db, year, month, agent)
    weeklies = get_weeklies_for_month(t.db, year, month, agent)
    monthly = get_monthly_for_month(t.db, year, month)
    yearly = get_yearly_for_year(t.db, year)
    month_label = _build_month_label(
        cal_mod.month_name[month], year, month,
        bool(monthly), bool(yearly), 'cal')

    return render_template('calendar.html',
        year=year, month=month,
        month_name=cal_mod.month_name[month],
        month_label=month_label,
        grid=grid, dailies=dailies,
        weeklies=weeklies,
        agents=agents, colors=colors,
        selected_agent=agent,
        week_date_range=week_date_range,
        find_weekly_for_range=find_weekly_for_range,
    )


@cal.route('/grid/<int:year>/<int:month>', methods=['POST'])
def grid(year, month):
    """Return month grid partial via dispatch htmls."""
    t = _tapestry()
    agent = request.form.get('agent') or None

    grid_data = build_month_grid(year, month)
    dailies = get_dailies_for_month(t.db, year, month, agent)
    weeklies = get_weeklies_for_month(t.db, year, month, agent)
    monthly = get_monthly_for_month(t.db, year, month)
    yearly = get_yearly_for_year(t.db, year)
    colors = get_agent_colors(t.db)

    html = render_template('partials/grid.html',
        year=year, month=month,
        grid=grid_data, dailies=dailies,
        weeklies=weeklies,
        colors=colors,
        selected_agent=agent,
        week_date_range=week_date_range,
        find_weekly_for_range=find_weekly_for_range,
    )

    month_label = _build_month_label(
        cal_mod.month_name[month], year, month,
        bool(monthly), bool(yearly), 'cal')

    return jsonify({
        'htmls': {
            '#calendar-grid': html,
            '#month-label': month_label,
        },
        'values': {
            '#nav-year': str(year),
            '#nav-month': str(month),
        },
    })


@cal.route('/day/<date_str>', methods=['POST'])
def day(date_str):
    """Return day detail partial via dispatch htmls."""
    t = _tapestry()
    agent = request.form.get('agent') or None
    colors = get_agent_colors(t.db)
    detail = get_day_detail(t.db, date_str, agent)

    html = render_template('partials/day_detail.html',
        detail=detail, colors=colors,
    )

    return jsonify({
        'htmls': {'#day-detail': html},
    })


@cal.route('/monthly/<int:year>/<int:month>', methods=['POST'])
def monthly(year, month):
    """Return tabbed monthly summary modal for all agents."""
    t = _tapestry()
    agents = get_agents(t.db)
    colors = get_agent_colors(t.db)
    records = get_all_monthlies_for_month(t.db, year, month)
    month_name = cal_mod.month_name[month]
    html = _build_tabbed_summary_modal(
        f"Monthly Summary - {month_name} {year}",
        agents, records, colors)
    return jsonify({'vbox': html})


@cal.route('/yearly/<int:year>', methods=['POST'])
def yearly(year):
    """Return tabbed yearly summary modal for all agents."""
    t = _tapestry()
    agents = get_agents(t.db)
    colors = get_agent_colors(t.db)
    records = get_all_yearlies_for_year(t.db, year)
    html = _build_tabbed_summary_modal(
        f"Yearly Summary - {year}",
        agents, records, colors)
    return jsonify({'vbox': html})


@cal.route('/record/<int:tap_id>', methods=['POST'])
def record(tap_id):
    """Return full record content in a vbox modal."""
    t = _tapestry()
    rec = t.show(tap_id)

    if not rec:
        return jsonify({'alert': json.dumps({'title': 'Not found', 'type': 'error'})})

    level_names = {0: 'Conversation', 1: 'Daily', 2: 'Weekly', 3: 'Monthly', 4: 'Yearly'}
    level = level_names.get(rec.get('tap_level', 0), 'Record')
    content_html = _content_to_html(rec.get('tap_content', ''))
    date_display = rec.get('tap_date', '') or rec.get('tap_date_start', '')
    if rec.get('tap_date_end'):
        date_display += f" to {rec['tap_date_end']}"

    html = render_template('partials/record_modal.html',
        rec=rec, level=level,
        content_html=content_html,
        date_display=date_display,
    )

    return jsonify({'vbox': html})


# ── Upload + Agent Management ─────────────────────────────────────


@cal.route('/upload-modal', methods=['POST'])
def upload_modal():
    """Render upload modal in vbox."""
    t = _tapestry()
    agents = get_agents(t.db)
    html = render_template('partials/upload_modal.html', agents=agents)
    return jsonify({'vbox': html})


@cal.route('/upload', methods=['POST'])
def upload():
    """Handle file upload, run ingest, return results."""
    import os
    import shutil
    import tempfile
    import zipfile

    t = _tapestry()

    if 'upl' not in request.files:
        return jsonify({'alert': json.dumps({
            'title': 'Upload Error', 'message': 'No file received.', 'type': 'error',
        })})

    file = request.files['upl']
    if not file.filename:
        return jsonify({'alert': json.dumps({
            'title': 'Upload Error', 'message': 'No file selected.', 'type': 'error',
        })})

    agent = request.form.get('agent', '').strip() or None
    parser_name = request.form.get('parser', '').strip() or None

    tmpdir = tempfile.mkdtemp(prefix='tapestry_upload_')
    try:
        filename = file.filename
        filepath = os.path.join(tmpdir, filename)
        file.save(filepath)

        # Handle zip extraction
        if filename.lower().endswith('.zip'):
            with zipfile.ZipFile(filepath, 'r') as zf:
                zf.extractall(tmpdir)
            os.remove(filepath)
            # If the zip contains conversations.json (Anthropic/ChatGPT export),
            # target it directly — skip other files (users.json, projects.json, etc.)
            conv_file = _find_conversations_json(tmpdir)
            if conv_file:
                filepath = conv_file
            else:
                # Fall back to directory walk for multi-file zips
                has_data = any(
                    f.lower().endswith(('.json', '.jsonl'))
                    for _root, _dirs, files in os.walk(tmpdir)
                    for f in files
                )
                if not has_data:
                    return jsonify({'alert': json.dumps({
                        'title': 'Upload Error',
                        'message': 'No .json or .jsonl found in zip.',
                        'type': 'error',
                    })})
                filepath = tmpdir

        result = t.ingest(filepath, agent=agent, parser_name=parser_name)

        # Refresh agent list in case a new agent appeared
        agents = get_agents(t.db)
        colors = get_agent_colors(t.db)
        agent_list_html = render_template('partials/agent_list.html',
            agents=agents, colors=colors, selected_agent=None)

        return jsonify({
            'vboxclose': True,
            'alert': json.dumps({
                'title': 'Import Complete',
                'message': (
                    f"Imported {result['conversations']} conversations "
                    f"({result['messages']} messages). "
                    f"Skipped {result['skipped']} duplicates."
                ),
                'type': 'success',
            }),
            'htmls': {'#agent-list': agent_list_html},
        })

    except Exception as e:
        return jsonify({'alert': json.dumps({
            'title': 'Import Error', 'message': str(e), 'type': 'error',
        })})
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


@cal.route('/agents-modal', methods=['POST'])
def agents_modal():
    """Render agent management modal in vbox."""
    t = _tapestry()
    agents = get_agents(t.db)
    colors = get_agent_colors(t.db)
    html = render_template('partials/agents_modal.html',
        agents=agents, colors=colors)
    return jsonify({'vbox': html})


@cal.route('/agent-color', methods=['POST'])
def agent_color():
    """Update agent color and refresh UI."""
    from datetime import date

    t = _tapestry()
    agent_name = request.form.get('agent', '')
    color = request.form.get('color', '#6C757D')

    set_agent_color(t.db, agent_name, color)

    # Refresh agent list
    agents = get_agents(t.db)
    colors = get_agent_colors(t.db)
    selected_agent = request.form.get('selected_agent') or None
    agent_list_html = render_template('partials/agent_list.html',
        agents=agents, colors=colors, selected_agent=selected_agent)

    # Refresh grid with updated colors
    today = date.today()
    year = int(request.form.get('year', today.year))
    month = int(request.form.get('month', today.month))

    grid_data = build_month_grid(year, month)
    dailies = get_dailies_for_month(t.db, year, month, selected_agent)
    weeklies = get_weeklies_for_month(t.db, year, month, selected_agent)

    grid_html = render_template('partials/grid.html',
        year=year, month=month,
        grid=grid_data, dailies=dailies,
        weeklies=weeklies, monthly=None,
        colors=colors, selected_agent=selected_agent,
        week_date_range=week_date_range,
        find_weekly_for_range=find_weekly_for_range)

    return jsonify({
        'vboxclose': True,
        'htmls': {
            '#agent-list': agent_list_html,
            '#calendar-grid': grid_html,
        },
    })


def _build_month_label(
    month_name: str, year: int, month_num: int,
    has_monthly: bool, has_yearly: bool, module: str,
) -> str:
    """Build the month/year header HTML with clickable summary links."""
    if has_monthly:
        m = (f'<a href="#" class="tmbtn cal-summary-link" data-module="{module}" '
             f'data-action="monthly/{year}/{month_num}" '
             f'title="Monthly Summary">{month_name}</a>')
    else:
        m = month_name

    if has_yearly:
        y = (f'<a href="#" class="tmbtn cal-summary-link" data-module="{module}" '
             f'data-action="yearly/{year}" '
             f'title="Yearly Summary">{year}</a>')
    else:
        y = str(year)

    return f'{m} {y}'


def _build_tabbed_summary_modal(
    title: str, agents: list[str], records: list[dict], colors: dict[str, str],
) -> str:
    """Build a vbox modal with Bootstrap nav-tabs for each agent's summary."""
    by_agent = {r['tap_agent']: r for r in records}

    tabs = ''
    panes = ''
    first = True
    for agent in agents:
        active_cls = ' active' if first else ''
        show_active = ' show active' if first else ''
        selected = 'true' if first else 'false'
        safe_id = agent.replace('-', '_').replace(' ', '_')
        color = colors.get(agent, '#6C757D')

        tabs += (
            f'<li class="nav-item" role="presentation">'
            f'<button class="nav-link{active_cls}" data-bs-toggle="tab" '
            f'data-bs-target="#tab-{safe_id}" type="button" role="tab" '
            f'aria-selected="{selected}">'
            f'<span class="agent-dot" style="background-color: {color};"></span> '
            f'{agent}</button></li>')

        rec = by_agent.get(agent)
        content = ''
        if rec:
            html = _content_to_html(rec.get('tap_content', ''))
            content = (
                f'<h6 style="color: #4a9eff;">{rec["tap_title"]}</h6>'
                f'<div class="record-content">{html}</div>')

        panes += (
            f'<div class="tab-pane fade{show_active}" '
            f'id="tab-{safe_id}" role="tabpanel">{content}</div>')

        first = False

    return (
        f'<div class="p-3">'
        f'<h5 style="color: #4a9eff;">{title}</h5>'
        f'<style>'
        f'.summary-tabs .nav-link {{ color: #aaa; border-color: transparent; }}'
        f'.summary-tabs .nav-link:hover {{ color: #e0e0e0; border-color: #1e2a3a #1e2a3a transparent; }}'
        f'.summary-tabs .nav-link.active {{ color: #4a9eff; background-color: #0a0e17; '
        f'border-color: #1e2a3a #1e2a3a #0a0e17; }}'
        f'</style>'
        f'<ul class="nav nav-tabs summary-tabs mt-3" role="tablist">{tabs}</ul>'
        f'<div class="tab-content mt-3" style="max-height: 60vh; overflow-y: auto;">'
        f'{panes}</div></div>')


def _content_to_html(text: str) -> str:
    """Convert markdown to HTML using the markdown library."""
    if not text:
        return ''
    import markdown
    return markdown.markdown(text, extensions=['tables', 'fenced_code'])
