"""
LLM client for Tapestry.

Provider-agnostic — works with any OpenAI-compatible API endpoint
(Groq, OpenAI, Anthropic via proxy, Ollama, vLLM, etc.).

NOTE: Debug prints are intentional pipeline tracing. Do NOT remove them.
      This is pre-production code. All debug output stays until launch.
"""

from __future__ import annotations

import random
import time
from typing import TYPE_CHECKING

import requests

MAX_RETRIES = 5
RETRY_BACKOFF_BASE = 2  # seconds: 2, 4, 8, 16, 32
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

if TYPE_CHECKING:
    from tapestry.config import LLMConfig


class LLMClient:
    """Provider-agnostic LLM client using OpenAI chat completions format."""

    def __init__(self, config: LLMConfig) -> None:
        self.config = config

    def request(
        self,
        messages: list[dict[str, str]],
        *,
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> str:
        """Send a chat completion request.

        Args:
            messages: List of {role, content} dicts.
            model: Override model name. Defaults to config.content_model.
            max_tokens: Override max tokens. Defaults to config.max_tokens_content.
            temperature: Override temperature. Defaults to config.temperature.

        Returns:
            Response content string.

        Raises:
            LLMError: On API failure.
        """
        resolved_model = model or self.config.content_model
        resolved_tokens = max_tokens if max_tokens is not None else self.config.max_tokens_content
        resolved_temp = temperature if temperature is not None else self.config.temperature

        # --- DEBUG: LLM request params ---
        print(f"[LLM DEBUG] model={resolved_model}, max_tokens={resolved_tokens}, temp={resolved_temp}")
        print(f"[LLM DEBUG] api_url={self.config.api_url}")
        print(f"[LLM DEBUG] message count={len(messages)}, roles={[m['role'] for m in messages]}")
        for i, m in enumerate(messages):
            print(f"[LLM DEBUG] msg[{i}] role={m['role']} content_len={len(m['content'])}")

        # Random pre-call delay (2-5s) to avoid rate limits during batch runs
        delay = random.uniform(2.0, 5.0)
        time.sleep(delay)

        try:
            content = self._call_api(
                self.config.api_url,
                self.config.api_key,
                resolved_model,
                messages,
                resolved_tokens,
                resolved_temp,
                self.config.request_timeout,
            )
        except LLMError:
            if self.config.fallback.enabled:
                print(f"[LLM DEBUG] Primary failed, falling back to {self.config.fallback.model}")
                content = self._call_api(
                    self.config.fallback.api_url,
                    "",
                    self.config.fallback.model,
                    messages,
                    resolved_tokens,
                    resolved_temp,
                    120,
                )
            else:
                raise

        # --- DEBUG: LLM response ---
        print(f"[LLM DEBUG] response length={len(content)} chars")
        print(f"[LLM DEBUG] response first 200 chars: {content[:200]}")

        return content

    def title(
        self,
        messages: list[dict[str, str]],
        *,
        max_tokens: int | None = None,
    ) -> str:
        """Shortcut for title generation using the title model.

        Validates the result is a plain English title. If the model returns
        JSON, tool calls, or other garbage, retries once with a correction prompt.
        """
        result = self.request(
            messages,
            model=self.config.title_model,
            max_tokens=max_tokens or self.config.max_tokens_title,
        )

        if _is_bad_title(result):
            # Retry with explicit correction
            retry_messages = messages + [
                {"role": "assistant", "content": result},
                {"role": "user", "content": "That is not a valid title. Return ONLY a plain English title of 5-8 words. No JSON, no code, no tool calls."},
            ]
            result = self.request(
                retry_messages,
                model=self.config.title_model,
                max_tokens=max_tokens or self.config.max_tokens_title,
            )

            # If still bad, generate a fallback from the content
            if _is_bad_title(result):
                result = "Untitled Conversation"

        return result

    @staticmethod
    def _call_api(
        api_url: str,
        api_key: str,
        model: str,
        messages: list[dict[str, str]],
        max_tokens: int,
        temperature: float,
        timeout: int,
    ) -> str:
        """Make a single OpenAI-compatible chat completion request.

        Retries up to MAX_RETRIES times on transient failures (429, 5xx, timeouts)
        with exponential backoff. Raises LLMError after all retries exhausted.
        """
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        last_error = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = requests.post(
                    api_url, headers=headers, json=payload, timeout=timeout
                )
            except requests.RequestException as exc:
                last_error = LLMError(f"Request failed (attempt {attempt}/{MAX_RETRIES}): {exc}")
                if attempt < MAX_RETRIES:
                    wait = RETRY_BACKOFF_BASE ** attempt
                    time.sleep(wait)
                    continue
                raise last_error from exc

            if response.status_code == 200:
                result = response.json()
                content = result["choices"][0]["message"]["content"].strip()
                return _strip_fences(content)

            # Retry on transient errors (rate limits, server errors,
            # and 400 output_parse_failed from reasoning models)
            retryable = response.status_code in RETRYABLE_STATUS_CODES or (
                response.status_code == 400
                and ("output_parse_failed" in response.text or "tool_use_failed" in response.text)
            )
            if retryable and attempt < MAX_RETRIES:
                wait = RETRY_BACKOFF_BASE ** attempt
                last_error = LLMError(
                    f"API error {response.status_code} (attempt {attempt}/{MAX_RETRIES},"
                    f" retrying in {wait}s): {response.text[:200]}"
                )
                time.sleep(wait)
                continue

            # On final attempt for output_parse_failed, extract failed_generation as fallback
            if response.status_code == 400 and "output_parse_failed" in response.text:
                try:
                    err_data = response.json()
                    failed_gen = err_data.get("error", {}).get("failed_generation", "")
                    if failed_gen:
                        return _strip_fences(failed_gen.strip())
                except Exception:
                    pass

            # Non-retryable error or final attempt
            raise LLMError(
                f"API error {response.status_code} (attempt {attempt}/{MAX_RETRIES}): {response.text}"
            )

        raise last_error


class LLMError(Exception):
    """Raised when an LLM API call fails."""


def _is_bad_title(text: str) -> bool:
    """Check if a title looks like JSON, tool calls, or other non-title output."""
    stripped = text.strip()
    if not stripped:
        return True
    if stripped.startswith("{") or stripped.startswith("["):
        return True
    if '"action"' in stripped or '"name"' in stripped or '"arguments"' in stripped:
        return True
    if len(stripped.splitlines()) > 2:
        return True
    return False


def _normalize_unicode(text: str) -> str:
    """Replace problematic Unicode characters with ASCII equivalents.

    LLMs produce characters like non-breaking hyphens (U+2011) and narrow
    no-break spaces (U+202F) that crash on Windows cp1252 terminals.
    """
    replacements = {
        "\u2011": "-",   # non-breaking hyphen
        "\u2013": "-",   # en dash
        "\u2014": "-",   # em dash
        "\u202f": " ",   # narrow no-break space
        "\u00a0": " ",   # non-breaking space
        "\u2018": "'",   # left single quote
        "\u2019": "'",   # right single quote
        # Smart double quotes left as-is — they are valid JSON/unicode
        # and converting to straight " breaks JSON string delimiters
    }
    for char, replacement in replacements.items():
        text = text.replace(char, replacement)
    return text


def _strip_fences(text: str) -> str:
    """Remove markdown code fences and normalize Unicode in LLM output."""
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    return _normalize_unicode(text.strip())
