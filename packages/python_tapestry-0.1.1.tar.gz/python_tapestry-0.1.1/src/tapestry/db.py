"""
Tapestry database layer.

SQLite connector with parameterized queries. Each Database instance
manages its own connection to a specific db file.
"""

from __future__ import annotations

import logging
import sqlite3
import time
from pathlib import Path
from typing import Any


class Database:
    """SQLite database connection manager."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._conn: sqlite3.Connection | None = None

    def _connect(self, attempts: int = 3, delay: int = 5) -> bool:
        """Establish or validate connection with retry logic."""
        if self._conn is not None:
            try:
                self._conn.execute("SELECT 1")
                return True
            except sqlite3.Error:
                self._conn = None

        try:
            self._conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA foreign_keys = ON")
            return True
        except sqlite3.Error:
            if attempts > 1:
                time.sleep(delay)
                return self._connect(attempts - 1, delay)
            return False

    def sql(
        self,
        query: str,
        params: tuple[Any, ...] = (),
        single: bool = False,
        commit: bool = True,
    ) -> list[dict[str, Any]] | dict[str, Any] | int | None:
        """Execute SQL query.

        Returns:
            SELECT: list of dicts, or single dict if single=True
            INSERT: lastrowid (int)
            Other: None
        """
        query = query.replace("%s", "?")

        if not self._connect():
            logging.error("Failed to connect to %s", self.db_path)
            return None

        cursor = self._conn.cursor()  # type: ignore[union-attr]
        try:
            cursor.execute(query, params)
            stmt = query.lower().strip()

            if stmt.startswith("select") or stmt.startswith("pragma"):
                if single:
                    return self._to_dict(cursor.fetchone(), single=True)
                return self._to_dict(cursor.fetchall())

            if stmt.startswith("insert"):
                return cursor.lastrowid

            return None
        finally:
            cursor.close()
            if commit and self._conn:
                self._conn.commit()

    @staticmethod
    def _to_dict(
        result: Any, single: bool = False
    ) -> list[dict[str, Any]] | dict[str, Any] | None:
        """Convert sqlite3.Row objects to Python dicts."""
        if not result:
            return None if single else []
        if single:
            return dict(result)
        return [dict(row) for row in result]

    def commit(self) -> None:
        if self._conn:
            self._conn.commit()

    def rollback(self) -> None:
        if self._conn:
            self._conn.rollback()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def ensure_directory(self) -> None:
        """Create parent directory for the database file if needed."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
