"""
Tapestry database schema.

Creates tables on first run. Uses tapestry_meta for version tracking.
"""

from __future__ import annotations

from tapestry.db import Database

SCHEMA_VERSION = 13

TABLES = {
    "tapestry": """
        CREATE TABLE IF NOT EXISTS tapestry (
            tap_id INTEGER PRIMARY KEY AUTOINCREMENT,
            tap_agent TEXT NOT NULL,
            tap_level INTEGER NOT NULL CHECK (tap_level BETWEEN 0 AND 4),
            tap_title TEXT NOT NULL,
            tap_content TEXT NOT NULL,
            tap_date TEXT,
            tap_date_start TEXT,
            tap_date_end TEXT,
            tap_source TEXT,
            tap_parent_id INTEGER REFERENCES tapestry(tap_id),
            tap_reflection TEXT,
            bt_id INTEGER,
            tap_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            tap_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "tapestry_messages": """
        CREATE TABLE IF NOT EXISTS tapestry_messages (
            tmsg_id INTEGER PRIMARY KEY AUTOINCREMENT,
            tmsg_agent TEXT NOT NULL,
            tmsg_ref_uuid TEXT NOT NULL,
            tmsg_ref_conv_id TEXT NOT NULL,
            tmsg_role TEXT NOT NULL,
            tmsg_content TEXT NOT NULL,
            tmsg_order INTEGER NOT NULL,
            tmsg_timestamp TEXT,
            tmsg_tap_id INTEGER REFERENCES tapestry(tap_id),
            bt_id INTEGER,
            UNIQUE(tmsg_ref_conv_id, tmsg_order)
        )
    """,
    "tapestry_meta": """
        CREATE TABLE IF NOT EXISTS tapestry_meta (
            meta_key TEXT PRIMARY KEY,
            meta_value TEXT
        )
    """,
    "tapestry_agents": """
        CREATE TABLE IF NOT EXISTS tapestry_agents (
            agent_id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_name TEXT NOT NULL UNIQUE,
            agent_color TEXT,
            agent_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "benchmark_summaries": """
        CREATE TABLE IF NOT EXISTS benchmark_summaries (
            bsum_id INTEGER PRIMARY KEY AUTOINCREMENT,
            bsum_agent TEXT NOT NULL,
            bsum_level INTEGER NOT NULL CHECK (bsum_level BETWEEN 0 AND 4),
            bsum_date TEXT,
            bsum_date_start TEXT,
            bsum_date_end TEXT,
            bsum_track TEXT NOT NULL CHECK (bsum_track IN ('context-aware', 'context-free')),
            bsum_title TEXT NOT NULL,
            bsum_content TEXT NOT NULL,
            bsum_source TEXT,
            bsum_tap_id INTEGER,
            bt_id INTEGER,
            bsum_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "benchmark_results": """
        CREATE TABLE IF NOT EXISTS benchmark_results (
            bench_id INTEGER PRIMARY KEY AUTOINCREMENT,
            bench_agent TEXT NOT NULL,
            bench_date TEXT,
            bench_level INTEGER NOT NULL CHECK (bench_level BETWEEN 0 AND 4),
            bench_comparison TEXT NOT NULL,
            bench_track TEXT NOT NULL,
            bench_method TEXT NOT NULL,
            bench_score REAL NOT NULL,
            bench_ry_factor REAL,
            bench_date_start TEXT,
            bench_date_end TEXT,
            bt_id INTEGER,
            bench_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "benchmark_tests": """
        CREATE TABLE IF NOT EXISTS benchmark_tests (
            bt_id INTEGER PRIMARY KEY AUTOINCREMENT,
            bt_agent TEXT NOT NULL,
            bt_date_start TEXT NOT NULL,
            bt_date_end TEXT NOT NULL,
            bt_method TEXT NOT NULL DEFAULT '',
            bt_status TEXT NOT NULL DEFAULT '',
            bt_ry_score REAL,
            bt_matched INTEGER,
            bt_ca_only INTEGER,
            bt_cf_only INTEGER,
            bt_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "benchmark_topics": """
        CREATE TABLE IF NOT EXISTS benchmark_topics (
            btop_id INTEGER PRIMARY KEY AUTOINCREMENT,
            btop_agent TEXT NOT NULL,
            btop_source TEXT NOT NULL,
            btop_level INTEGER NOT NULL CHECK (btop_level BETWEEN -1 AND 4),
            btop_is_conversation INTEGER NOT NULL DEFAULT 0,
            btop_content TEXT NOT NULL,
            btop_order INTEGER NOT NULL,
            btop_track TEXT,
            btop_tokens INTEGER,
            bt_id INTEGER REFERENCES benchmark_tests(bt_id),
            btop_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "benchmark_jobs": """
        CREATE TABLE IF NOT EXISTS benchmark_jobs (
            job_id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_agent TEXT NOT NULL,
            job_track TEXT NOT NULL,
            job_action TEXT NOT NULL,
            job_status TEXT NOT NULL DEFAULT 'running',
            job_total INTEGER NOT NULL DEFAULT 0,
            job_completed INTEGER NOT NULL DEFAULT 0,
            job_detail TEXT,
            job_error TEXT,
            job_bt_id INTEGER,
            job_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            job_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "benchmark_matches": """
        CREATE TABLE IF NOT EXISTS benchmark_matches (
            match_id INTEGER PRIMARY KEY AUTOINCREMENT,
            bt_id INTEGER NOT NULL,
            btop_cf_id INTEGER NOT NULL,
            btop_ca_id INTEGER,
            sbert_score REAL,
            llm_confirmed INTEGER,
            match_conv_id TEXT,
            match_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "chunk_benchmark_runs": """
        CREATE TABLE IF NOT EXISTS chunk_benchmark_runs (
            cbr_id INTEGER PRIMARY KEY AUTOINCREMENT,
            cbr_conv_id TEXT NOT NULL,
            cbr_model TEXT NOT NULL,
            cbr_chunk_size INTEGER NOT NULL,
            cbr_merge_buffer INTEGER NOT NULL DEFAULT 0,
            cbr_temperature REAL NOT NULL DEFAULT 0.3,
            cbr_total_runs INTEGER NOT NULL DEFAULT 1,
            cbr_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
    "chunk_benchmarks": """
        CREATE TABLE IF NOT EXISTS chunk_benchmarks (
            cb_id INTEGER PRIMARY KEY AUTOINCREMENT,
            cbr_id INTEGER NOT NULL REFERENCES chunk_benchmark_runs(cbr_id),
            cb_run_number INTEGER NOT NULL DEFAULT 1,
            cb_chunks INTEGER NOT NULL,
            cb_llm_calls INTEGER NOT NULL,
            cb_merge_levels INTEGER NOT NULL DEFAULT 1,
            cb_intermediate_tokens INTEGER NOT NULL,
            cb_final_tokens INTEGER NOT NULL,
            cb_topic_count INTEGER,
            cb_output_file TEXT,
            cb_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """,
}

INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_tapestry_agent ON tapestry(tap_agent)",
    "CREATE INDEX IF NOT EXISTS idx_tapestry_level ON tapestry(tap_level)",
    "CREATE INDEX IF NOT EXISTS idx_tapestry_date ON tapestry(tap_date)",
    "CREATE INDEX IF NOT EXISTS idx_tapestry_date_range ON tapestry(tap_date_start, tap_date_end)",
    "CREATE INDEX IF NOT EXISTS idx_tapestry_source ON tapestry(tap_source)",
    "CREATE INDEX IF NOT EXISTS idx_tapestry_parent ON tapestry(tap_parent_id)",
    "CREATE INDEX IF NOT EXISTS idx_tmsg_agent ON tapestry_messages(tmsg_agent)",
    "CREATE INDEX IF NOT EXISTS idx_tmsg_conv ON tapestry_messages(tmsg_ref_conv_id)",
    "CREATE INDEX IF NOT EXISTS idx_tmsg_tap ON tapestry_messages(tmsg_tap_id)",
    "CREATE INDEX IF NOT EXISTS idx_bsum_agent ON benchmark_summaries(bsum_agent)",
    "CREATE INDEX IF NOT EXISTS idx_bsum_track ON benchmark_summaries(bsum_track)",
    "CREATE INDEX IF NOT EXISTS idx_bsum_level ON benchmark_summaries(bsum_level)",
    "CREATE INDEX IF NOT EXISTS idx_bsum_date ON benchmark_summaries(bsum_date)",
    "CREATE INDEX IF NOT EXISTS idx_bench_agent ON benchmark_results(bench_agent)",
    "CREATE INDEX IF NOT EXISTS idx_bench_method ON benchmark_results(bench_method)",
    "CREATE INDEX IF NOT EXISTS idx_bench_level ON benchmark_results(bench_level)",
    "CREATE INDEX IF NOT EXISTS idx_bench_test ON benchmark_results(bt_id)",
    "CREATE INDEX IF NOT EXISTS idx_bt_agent ON benchmark_tests(bt_agent)",
    "CREATE INDEX IF NOT EXISTS idx_btop_agent ON benchmark_topics(btop_agent)",
    "CREATE INDEX IF NOT EXISTS idx_btop_source ON benchmark_topics(btop_source)",
    "CREATE INDEX IF NOT EXISTS idx_btop_level ON benchmark_topics(btop_level)",
    "CREATE INDEX IF NOT EXISTS idx_btop_test ON benchmark_topics(bt_id)",
    "CREATE INDEX IF NOT EXISTS idx_bjob_agent ON benchmark_jobs(job_agent)",
    "CREATE INDEX IF NOT EXISTS idx_bmatch_test ON benchmark_matches(bt_id)",
    "CREATE INDEX IF NOT EXISTS idx_bmatch_cf ON benchmark_matches(btop_cf_id)",
    "CREATE INDEX IF NOT EXISTS idx_bmatch_ca ON benchmark_matches(btop_ca_id)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_tagent_name ON tapestry_agents(agent_name)",
]

# FTS5 virtual tables — external content (no data duplication)
FTS_TABLES = [
    """CREATE VIRTUAL TABLE IF NOT EXISTS tapestry_fts
       USING fts5(
           tap_title, tap_content,
           content=tapestry, content_rowid=tap_id,
           tokenize='porter unicode61'
       )""",
    """CREATE VIRTUAL TABLE IF NOT EXISTS tapestry_messages_fts
       USING fts5(
           tmsg_content,
           content=tapestry_messages, content_rowid=tmsg_id,
           tokenize='porter unicode61'
       )""",
]

# Triggers to keep FTS indexes in sync with source tables
FTS_TRIGGERS = [
    # tapestry insert
    """CREATE TRIGGER IF NOT EXISTS tapestry_ai AFTER INSERT ON tapestry BEGIN
        INSERT INTO tapestry_fts(rowid, tap_title, tap_content)
        VALUES (new.tap_id, new.tap_title, new.tap_content);
    END""",
    # tapestry update
    """CREATE TRIGGER IF NOT EXISTS tapestry_au AFTER UPDATE ON tapestry BEGIN
        INSERT INTO tapestry_fts(tapestry_fts, rowid, tap_title, tap_content)
        VALUES ('delete', old.tap_id, old.tap_title, old.tap_content);
        INSERT INTO tapestry_fts(rowid, tap_title, tap_content)
        VALUES (new.tap_id, new.tap_title, new.tap_content);
    END""",
    # tapestry delete
    """CREATE TRIGGER IF NOT EXISTS tapestry_ad AFTER DELETE ON tapestry BEGIN
        INSERT INTO tapestry_fts(tapestry_fts, rowid, tap_title, tap_content)
        VALUES ('delete', old.tap_id, old.tap_title, old.tap_content);
    END""",
    # tapestry_messages insert
    """CREATE TRIGGER IF NOT EXISTS tmsg_ai AFTER INSERT ON tapestry_messages BEGIN
        INSERT INTO tapestry_messages_fts(rowid, tmsg_content)
        VALUES (new.tmsg_id, new.tmsg_content);
    END""",
    # tapestry_messages update
    """CREATE TRIGGER IF NOT EXISTS tmsg_au AFTER UPDATE ON tapestry_messages BEGIN
        INSERT INTO tapestry_messages_fts(tapestry_messages_fts, rowid, tmsg_content)
        VALUES ('delete', old.tmsg_id, old.tmsg_content);
        INSERT INTO tapestry_messages_fts(rowid, tmsg_content)
        VALUES (new.tmsg_id, new.tmsg_content);
    END""",
    # tapestry_messages delete
    """CREATE TRIGGER IF NOT EXISTS tmsg_ad AFTER DELETE ON tapestry_messages BEGIN
        INSERT INTO tapestry_messages_fts(tapestry_messages_fts, rowid, tmsg_content)
        VALUES ('delete', old.tmsg_id, old.tmsg_content);
    END""",
]


def init_db(db: Database) -> None:
    """Create all tables, indexes, FTS5 tables, and triggers. Safe to call multiple times."""
    for table_sql in TABLES.values():
        db.sql(table_sql)

    for index_sql in INDEXES:
        db.sql(index_sql)

    for fts_sql in FTS_TABLES:
        db.sql(fts_sql)

    for trigger_sql in FTS_TRIGGERS:
        db.sql(trigger_sql)

    # Migrations — safe to re-run (ALTER fails silently if column exists)
    try:
        db.sql("ALTER TABLE benchmark_results ADD COLUMN bt_id INTEGER")
    except Exception:
        pass  # Column already exists

    # v6: topic retention tracking columns
    try:
        db.sql("ALTER TABLE benchmark_topics ADD COLUMN btop_track TEXT")
    except Exception:
        pass
    try:
        db.sql("ALTER TABLE benchmark_topics ADD COLUMN btop_tokens INTEGER")
    except Exception:
        pass

    # v8: bt_status column for report lifecycle tracking
    try:
        db.sql("ALTER TABLE benchmark_tests ADD COLUMN bt_status TEXT NOT NULL DEFAULT ''")
    except Exception:
        pass

    # v9: match_conv_id for per-conversation matching
    try:
        db.sql("ALTER TABLE benchmark_matches ADD COLUMN match_conv_id TEXT")
    except Exception:
        pass

    # v11: bt_id isolation for benchmark test tables
    for stmt in [
        "ALTER TABLE tapestry ADD COLUMN bt_id INTEGER",
        "ALTER TABLE benchmark_summaries ADD COLUMN bt_id INTEGER",
        "ALTER TABLE tapestry_messages ADD COLUMN bt_id INTEGER",
        "ALTER TABLE benchmark_jobs ADD COLUMN job_bt_id INTEGER",
    ]:
        try:
            db.sql(stmt)
        except Exception:
            pass

    # v11 indexes (must run after ALTER TABLE adds the columns)
    for idx in [
        "CREATE INDEX IF NOT EXISTS idx_tapestry_bt ON tapestry(bt_id)",
        "CREATE INDEX IF NOT EXISTS idx_bsum_bt ON benchmark_summaries(bt_id)",
        "CREATE INDEX IF NOT EXISTS idx_tmsg_bt ON tapestry_messages(bt_id)",
    ]:
        db.sql(idx)

    # v12: tapestry_agents table + integer FK columns on core tables
    for stmt in [
        "ALTER TABLE tapestry ADD COLUMN tap_agent_id INTEGER REFERENCES tapestry_agents(agent_id)",
        "ALTER TABLE tapestry_messages ADD COLUMN tmsg_agent_id INTEGER REFERENCES tapestry_agents(agent_id)",
    ]:
        try:
            db.sql(stmt)
        except Exception:
            pass

    # v12: backfill agent rows from existing data
    db.sql(
        """INSERT OR IGNORE INTO tapestry_agents (agent_name)
           SELECT DISTINCT tap_agent FROM tapestry WHERE tap_agent IS NOT NULL
           UNION
           SELECT DISTINCT tmsg_agent FROM tapestry_messages WHERE tmsg_agent IS NOT NULL"""
    )

    # v12: populate FK columns from text columns
    db.sql(
        """UPDATE tapestry SET tap_agent_id = (
               SELECT agent_id FROM tapestry_agents WHERE agent_name = tap_agent
           ) WHERE tap_agent_id IS NULL AND tap_agent IS NOT NULL"""
    )
    db.sql(
        """UPDATE tapestry_messages SET tmsg_agent_id = (
               SELECT agent_id FROM tapestry_agents WHERE agent_name = tmsg_agent
           ) WHERE tmsg_agent_id IS NULL AND tmsg_agent IS NOT NULL"""
    )

    # v12: migrate colors from tapestry_meta to tapestry_agents
    color_rows = db.sql(
        "SELECT meta_key, meta_value FROM tapestry_meta WHERE meta_key LIKE 'agent_color:%'"
    )
    for row in (color_rows or []):
        name = row["meta_key"].split(":", 1)[1]
        db.sql(
            "UPDATE tapestry_agents SET agent_color = ? WHERE agent_name = ?",
            (row["meta_value"], name),
        )

    # v12 indexes (must run after ALTER TABLE adds the columns)
    for idx in [
        "CREATE INDEX IF NOT EXISTS idx_tap_agent_id ON tapestry(tap_agent_id)",
        "CREATE INDEX IF NOT EXISTS idx_tmsg_agent_id ON tapestry_messages(tmsg_agent_id)",
    ]:
        db.sql(idx)

    # Set schema version
    db.sql(
        "INSERT OR REPLACE INTO tapestry_meta (meta_key, meta_value) VALUES (?, ?)",
        ("schema_version", str(SCHEMA_VERSION)),
    )


def rebuild_fts(db: Database) -> dict[str, int]:
    """Rebuild FTS5 indexes from existing data. Run after migration or to repair."""
    db.sql("INSERT INTO tapestry_fts(tapestry_fts) VALUES('rebuild')")
    db.sql("INSERT INTO tapestry_messages_fts(tapestry_messages_fts) VALUES('rebuild')")

    tap_count = db.sql(
        "SELECT COUNT(*) as c FROM tapestry WHERE tap_content IS NOT NULL",
        single=True,
    )
    msg_count = db.sql(
        "SELECT COUNT(*) as c FROM tapestry_messages",
        single=True,
    )
    return {
        "summaries": tap_count["c"] if tap_count else 0,
        "messages": msg_count["c"] if msg_count else 0,
    }


def get_schema_version(db: Database) -> int | None:
    """Get current schema version, or None if not initialized."""
    row = db.sql(
        "SELECT meta_value FROM tapestry_meta WHERE meta_key = ?",
        ("schema_version",),
        single=True,
    )
    if row:
        return int(row["meta_value"])
    return None
