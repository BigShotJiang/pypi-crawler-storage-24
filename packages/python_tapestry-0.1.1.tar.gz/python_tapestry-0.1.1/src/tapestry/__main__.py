"""Allow running tapestry as `python -m tapestry`."""

from tapestry.cli.main import cli

cli()
