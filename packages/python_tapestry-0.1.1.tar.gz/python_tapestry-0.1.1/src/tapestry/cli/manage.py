"""CLI commands for tapestry management.

Commands:
    status    Show system status dashboard
    agents    List all known agents
    retitle   Re-generate oversized titles
"""

from __future__ import annotations

import time

import click
from tqdm import tqdm

from tapestry import Tapestry
from tapestry.engine.prompts import title_prompt

LEVEL_NAMES = {0: "conversation", 1: "daily", 2: "weekly", 3: "monthly", 4: "yearly"}


@click.command()
@click.option("--agent", "-a", default=None, help="Agent name")
def status(agent: str | None) -> None:
    """Show tapestry system status dashboard."""
    with Tapestry() as t:
        st = t.status(agent=agent)

    click.echo("Tapestry Status")
    click.echo("=" * 60)
    click.echo(f"  Agent:    {st['agent']}")
    click.echo(f"  Database: {st['db_path']}")
    if st["config_path"]:
        click.echo(f"  Config:   {st['config_path']}")

    click.echo()

    s = st["stats"]
    for level in range(5):
        info = s["levels"][level]
        name = f"L{level} ({info['name']})"
        click.echo(f"  {name:22s}  {info['count']:5d} records  {info['chars']:>10,} chars")

    click.echo()
    click.echo(f"  Messages:       {s['messages']:,} across {s['conversations']} conversations")
    click.echo(f"  Total:          {s['total_records']} records, ~{s['est_tokens']:,} tokens")

    if st["date_range"]:
        click.echo(f"\n  Date range:     {st['date_range']['first']} to {st['date_range']['last']}")

    click.echo()
    if st["health"] == "empty":
        click.echo("  Health: empty (no conversations ingested)")
        click.echo("\n  Next: tapestry ingest <path>")
    elif st["health"] == "needs_catchup":
        issues = []
        if st["unsummarized"] > 0:
            issues.append(f"{st['unsummarized']} unsummarized conversation(s)")
        if st["missing_dailies"] > 0:
            issues.append(f"{st['missing_dailies']} missing daily(ies)")
        click.echo(f"  Health: needs catchup ({', '.join(issues)})")
        click.echo("\n  Next: tapestry catchup")
    else:
        click.echo("  Health: healthy")


@click.command()
def agents() -> None:
    """List all known agents from config and database."""
    with Tapestry() as t:
        config_agents = set(t.config.agents.keys())

        # Query distinct agents from DB with counts via tapestry_agents
        db_rows = t.db.sql(
            """SELECT a.agent_name,
                      COUNT(DISTINCT m.tmsg_ref_conv_id) as convos,
                      COUNT(m.tmsg_id) as msgs
               FROM tapestry_agents a
               LEFT JOIN tapestry_messages m ON m.tmsg_agent_id = a.agent_id
               GROUP BY a.agent_id
               ORDER BY a.agent_name"""
        ) or []
        db_agents = {r["agent_name"]: r for r in db_rows}

        # Query L0 counts per agent
        l0_rows = t.db.sql(
            """SELECT a.agent_name, COUNT(*) as cnt
               FROM tapestry t
               JOIN tapestry_agents a ON a.agent_id = t.tap_agent_id
               WHERE t.tap_level = 0
               GROUP BY t.tap_agent_id"""
        ) or []
        l0_counts = {r["agent_name"]: r["cnt"] for r in l0_rows}

        # Merge all agent names
        all_agents = sorted(config_agents | set(db_agents.keys()))

        if not all_agents:
            click.echo("No agents found. Run 'tapestry init' or 'tapestry ingest' first.")
            return

        # Header
        click.echo(f"{'Agent':<20s} {'Source':<10s} {'Parser':<14s} {'Convos':>8s} {'L0s':>8s} {'Msgs':>10s}")
        click.echo("-" * 72)

        for name in all_agents:
            in_config = name in config_agents
            in_db = name in db_agents

            if in_config and in_db:
                source = "both"
            elif in_config:
                source = "config"
            else:
                source = "db-only"

            parser = t.config.agents[name].parser if in_config and t.config.agents[name].parser else "-"
            convos = db_agents[name]["convos"] if in_db else 0
            l0s = l0_counts.get(name, 0)
            msgs = db_agents[name]["msgs"] if in_db else 0

            click.echo(f"{name:<20s} {source:<10s} {parser:<14s} {convos:>8d} {l0s:>8d} {msgs:>10,d}")


@click.command("rebuild-fts")
def rebuild_fts_cmd() -> None:
    """Rebuild FTS5 indexes from existing data.

    Run once after upgrading to two-layer search, or to repair indexes.
    Safe to run multiple times.
    """
    from tapestry.schema import rebuild_fts

    with Tapestry() as t:
        click.echo("Rebuilding FTS5 indexes...")
        counts = rebuild_fts(t.db)
        click.echo(f"  Summaries indexed: {counts['summaries']}")
        click.echo(f"  Messages indexed:  {counts['messages']}")
        click.echo("Done.")


@click.command()
@click.option("--agent", "-a", default=None, help="Filter by agent name")
@click.option("--threshold", "-t", default=100, help="Title length threshold (default 100)")
@click.option("--level", "-l", default=None, type=int, help="Filter by level (0-4)")
@click.option("--dry-run", is_flag=True, help="Preview without saving")
@click.option("--delay", default=1.0, type=float, help="Delay between LLM calls (seconds)")
def retitle(agent: str | None, threshold: int, level: int | None, dry_run: bool, delay: float) -> None:
    """Re-generate titles that exceed a character threshold."""
    with Tapestry() as t:
        # Build query for oversized titles
        conditions = ["LENGTH(tap_title) > ?"]
        params: list = [threshold]

        if agent:
            _name, agent_id = t._resolve_agent(agent)
            conditions.append("tap_agent_id = ?")
            params.append(agent_id)

        if level is not None:
            conditions.append("tap_level = ?")
            params.append(level)

        where = " AND ".join(conditions)
        rows = t.db.sql(
            f"""SELECT tap_id, tap_level, tap_agent, tap_title, tap_content
                FROM tapestry
                WHERE {where}
                ORDER BY tap_level, tap_agent, tap_date""",
            tuple(params),
        ) or []

        if not rows:
            click.echo(f"No titles over {threshold} chars found.")
            return

        # Summary by agent and level
        from collections import Counter
        by_agent = Counter(r["tap_agent"] for r in rows)
        by_level = Counter(r["tap_level"] for r in rows)

        click.echo(f"Found {len(rows)} titles over {threshold} chars")
        click.echo(f"  By agent: {', '.join(f'{a}={c}' for a, c in sorted(by_agent.items()))}")
        click.echo(f"  By level: {', '.join(f'L{lv}={c}' for lv, c in sorted(by_level.items()))}")
        click.echo()

        if dry_run:
            click.echo("DRY RUN — generating new titles but not saving\n")

        updated = 0
        errors = 0
        for row in tqdm(rows, desc="Retitling", unit="title"):
            content = row["tap_content"]
            if not content or not content.strip():
                continue

            content_for_title = content

            try:
                new_title = t.llm.title([
                    {"role": "system", "content": title_prompt(row["tap_level"])},
                    {"role": "user", "content": content_for_title},
                ])
            except Exception as exc:
                errors += 1
                tqdm.write(f"  ERROR tap_id={row['tap_id']}: {exc}")
                continue

            # Skip if LLM produced another oversized title
            if len(new_title) > threshold:
                errors += 1
                tqdm.write(f"  SKIP tap_id={row['tap_id']}: new title still {len(new_title)} chars")
                continue

            old_short = row["tap_title"][:60] + "..." if len(row["tap_title"]) > 60 else row["tap_title"]
            # Sanitize for Windows terminal encoding
            old_short = old_short.encode("ascii", errors="replace").decode("ascii")
            safe_new = new_title.encode("ascii", errors="replace").decode("ascii")
            level_name = LEVEL_NAMES.get(row["tap_level"], f"L{row['tap_level']}")

            if dry_run:
                tqdm.write(f"  [{level_name}] tap_id={row['tap_id']} ({row['tap_agent']})")
                tqdm.write(f"    OLD: {old_short}")
                tqdm.write(f"    NEW: {safe_new}")
            else:
                t.db.sql(
                    "UPDATE tapestry SET tap_title = ? WHERE tap_id = ?",
                    (new_title, row["tap_id"]),
                )
                updated += 1
                tqdm.write(f"  [{level_name}] tap_id={row['tap_id']}: {safe_new}")

            if delay > 0:
                time.sleep(delay)

        click.echo()
        if dry_run:
            click.echo(f"DRY RUN complete. {len(rows)} titles would be updated ({errors} errors).")
        else:
            click.echo(f"Updated {updated} titles ({errors} errors).")
