"""CLI utilities shared across tapestry commands."""

from __future__ import annotations

import difflib
from typing import TYPE_CHECKING

import click

if TYPE_CHECKING:
    from tapestry.config import TapestryConfig


def validate_agent(config: TapestryConfig, agent: str) -> None:
    """Warn if agent name is not in tapestry.toml config.

    Does NOT block execution — the agent may be intentionally new.
    Shows known agents and suggests closest match via difflib.
    """
    if agent in config.agents:
        return

    known = sorted(config.agents.keys())
    click.echo(f"Warning: agent '{agent}' not found in tapestry.toml", err=True)

    if known:
        click.echo(f"  Known agents: {', '.join(known)}", err=True)
        matches = difflib.get_close_matches(agent, known, n=1, cutoff=0.5)
        if matches:
            click.echo(f"  Did you mean: {matches[0]}?", err=True)
