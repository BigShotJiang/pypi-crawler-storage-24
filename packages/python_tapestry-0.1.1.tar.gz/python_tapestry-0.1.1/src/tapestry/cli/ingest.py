"""Ingest command — import conversation files into tapestry."""

from __future__ import annotations

import os
from collections import defaultdict

import click
from tqdm import tqdm

from tapestry import Tapestry
from tapestry.cli import validate_agent
from tapestry.db import Database
from tapestry.parsers import detect_parser, get_parser


@click.command()
@click.argument("path")
@click.option("--agent", default=None, help="Agent name (default: uses config default)")
@click.option("--parser", "parser_name", default=None,
              help="Parser name (chatgpt, claude-code, generic). Auto-detects if omitted.")
@click.option("--dry-run", is_flag=True, help="Show what would be imported without writing")
def ingest(path: str, agent: str | None, parser_name: str | None, dry_run: bool) -> None:
    """Import conversation files into tapestry.

    PATH can be a single file or a directory. Directories are scanned
    for supported file types.
    """
    t = Tapestry()

    # Resolve agent name and ID
    agent, agent_id = t._resolve_agent(agent)
    validate_agent(t.config, agent)

    # Get parser preference from config if not specified on CLI
    if parser_name is None and agent in t.config.agents:
        parser_name = t.config.agents[agent].parser

    if os.path.isdir(path):
        files = _collect_files(path)
        if not files:
            click.echo(f"No supported files found in {path}")
            return
        click.echo(f"Found {len(files)} file(s) in {path}")
        total_imported = 0
        total_skipped = 0
        for filepath in tqdm(sorted(files), desc="Ingesting", unit="file",
                             disable=dry_run):
            imported, skipped = _ingest_file(t.db, filepath, agent, agent_id, parser_name, dry_run)
            total_imported += imported
            total_skipped += skipped
        if not dry_run:
            click.echo(f"\nDone: {total_imported} imported, {total_skipped} skipped")
    elif os.path.isfile(path):
        _ingest_file(t.db, path, agent, agent_id, parser_name, dry_run)
    else:
        click.echo(f"Path not found: {path}")
        raise SystemExit(1)

    t.close()


def _ingest_file(
    db: Database,
    filepath: str,
    agent: str,
    agent_id: int,
    parser_name: str | None,
    dry_run: bool,
) -> tuple[int, int]:
    """Ingest a single file. Returns (imported_count, skipped_count)."""
    # Get parser
    if parser_name:
        try:
            parser = get_parser(parser_name)
        except ValueError as exc:
            click.echo(f"  {filepath}: {exc}")
            return (0, 0)
    else:
        parser = detect_parser(filepath)
        if parser is None:
            click.echo(f"  {os.path.basename(filepath)}: unknown format, skipping")
            return (0, 0)

    # Parse
    click.echo(f"Parsing {os.path.basename(filepath)}...")
    try:
        messages = parser.parse(filepath)
    except Exception as exc:
        click.echo(f"  {os.path.basename(filepath)}: parse error: {exc}")
        return (0, 0)

    if not messages:
        click.echo(f"  {os.path.basename(filepath)}: no messages found")
        return (0, 0)

    # Group messages by conversation_id.
    # Single-conversation files (claude-code, generic) produce one group.
    # Multi-conversation files (chatgpt) produce many groups.
    grouped: dict[str, list] = defaultdict(list)
    for msg in messages:
        cid = msg.conversation_id or os.path.basename(filepath)
        grouped[cid].append(msg)

    imported = 0
    skipped = 0
    total_msgs = 0

    use_progress = len(grouped) > 1 and not dry_run
    items = tqdm(grouped.items(), desc="Ingesting", unit="conv",
                 disable=not use_progress)

    for conv_id, conv_msgs in items:
        result = _ingest_conversation(db, conv_id, conv_msgs, agent, agent_id, dry_run)
        if result > 0:
            imported += 1
            total_msgs += result
            if use_progress:
                items.set_postfix(imported=imported, msgs=total_msgs)
        elif result == 0:
            skipped += 1

    if len(grouped) > 1:
        label = "would import" if dry_run else "imported"
        click.echo(f"  {imported} {label}, {skipped} skipped (of {len(grouped)} conversations, {total_msgs} messages)")

    return (imported, skipped)


def _ingest_conversation(
    db: Database,
    conv_id: str,
    messages: list,
    agent: str,
    agent_id: int,
    dry_run: bool,
) -> int:
    """Ingest one conversation. Returns msg count (>0 imported, 0 skipped, -1 error)."""
    # Check for existing import (filter by agent — same conv_id can exist under different agents)
    existing = db.sql(
        "SELECT COUNT(*) as cnt FROM tapestry_messages WHERE tmsg_ref_conv_id = ? AND tmsg_agent_id = ?",
        (conv_id, agent_id),
        single=True,
    )
    existing_count = existing["cnt"] if existing else 0
    if existing_count >= len(messages):
        return 0  # up to date — skip

    if dry_run:
        new_count = len(messages) - existing_count
        label = f"{new_count} new" if existing_count > 0 else f"{len(messages)} msgs"
        click.echo(f"  {conv_id[:12]}: {label}")
        return new_count

    # Insert only new messages (incremental)
    msgs_to_insert = messages[existing_count:]
    for i, msg in enumerate(msgs_to_insert):
        db.sql(
            """INSERT OR IGNORE INTO tapestry_messages
               (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role,
                tmsg_content, tmsg_order, tmsg_timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (agent, agent_id, msg.uuid, conv_id, msg.role, msg.content, existing_count + i, msg.timestamp),
        )

    return len(msgs_to_insert)


def _collect_files(directory: str) -> list[str]:
    """Walk a directory and return all supported conversation files."""
    supported_extensions = (".jsonl", ".json")
    files: list[str] = []
    for root, _dirs, filenames in os.walk(directory):
        for fname in filenames:
            if any(fname.endswith(ext) for ext in supported_extensions):
                files.append(os.path.join(root, fname))
    return files
