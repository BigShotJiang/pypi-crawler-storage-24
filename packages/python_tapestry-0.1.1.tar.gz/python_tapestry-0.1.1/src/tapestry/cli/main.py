"""
Tapestry CLI entry point.

Usage: tapestry <command> [options]
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import click

from tapestry._version import __version__


@click.group()
@click.version_option(__version__, prog_name="total-recall")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Tapestry - Hierarchical long-term memory for AI conversations."""
    ctx.ensure_object(dict)


@cli.command()
@click.option("--provider", type=click.Choice(["groq", "openai", "ollama", "anthropic"]),
              default=None, help="LLM provider")
@click.option("--api-key", default=None, help="API key (or set TAPESTRY_API_KEY env var)")
@click.option("--db-path", default="db/tapestry.db", help="Database path")
@click.option("--non-interactive", is_flag=True, help="Skip prompts, use defaults")
def init(provider: str | None, api_key: str | None, db_path: str,
         non_interactive: bool) -> None:
    """Initialize a new tapestry project in the current directory."""
    project_dir = Path.cwd()
    toml_path = project_dir / "tapestry.toml"
    env_path = project_dir / ".env"

    # Check if already initialized
    if toml_path.exists():
        click.echo(f"tapestry.toml already exists at {toml_path}")
        if not click.confirm("Overwrite?", default=False):
            raise SystemExit(0)

    # Interactive setup
    if not non_interactive:
        if provider is None:
            provider = click.prompt(
                "LLM provider",
                type=click.Choice(["groq", "openai", "ollama", "anthropic"]),
                default="groq",
            )

        if api_key is None and provider != "ollama":
            api_key = click.prompt(
                f"API key for {provider} (or press Enter to set later via .env)",
                default="",
                show_default=False,
            )

        db_path = click.prompt("Database path", default=db_path)
    else:
        provider = provider or "groq"

    # Provider-specific API URLs
    api_urls = {
        "groq": "https://api.groq.com/openai/v1/chat/completions",
        "openai": "https://api.openai.com/v1/chat/completions",
        "ollama": "http://localhost:11434/v1/chat/completions",
        "anthropic": "https://api.anthropic.com/v1/messages",
    }

    # Build config
    from tapestry.config import AgentConfig, LLMConfig, TapestryConfig, write_config

    llm_config = LLMConfig(
        provider=provider,
        api_url=api_urls.get(provider, api_urls["groq"]),
        api_key=api_key or "",
    )

    config = TapestryConfig(
        db_path=db_path,
        llm=llm_config,
        agents={"default": AgentConfig()},
        project_dir=str(project_dir),
    )

    # Write tapestry.toml
    write_config(config, str(toml_path))
    click.echo(f"Created {toml_path}")

    # Write .env if API key provided
    if api_key:
        if env_path.exists():
            # Append if .env exists
            content = env_path.read_text(encoding="utf-8")
            if "TAPESTRY_API_KEY" not in content:
                with open(env_path, "a", encoding="utf-8") as f:
                    f.write(f"\nTAPESTRY_API_KEY={api_key}\n")
                click.echo(f"Added TAPESTRY_API_KEY to {env_path}")
        else:
            env_path.write_text(f"TAPESTRY_API_KEY={api_key}\n", encoding="utf-8")
            click.echo(f"Created {env_path}")
    elif not env_path.exists():
        env_path.write_text("# TAPESTRY_API_KEY=your-key-here\n", encoding="utf-8")
        click.echo(f"Created {env_path} (add your API key)")

    # Create database
    from tapestry.db import Database
    from tapestry.schema import init_db

    full_db_path = str(project_dir / db_path)
    db = Database(full_db_path)
    db.ensure_directory()
    init_db(db)
    db.close()
    click.echo(f"Created database at {full_db_path}")

    click.echo("\nTapestry initialized. Next steps:")
    click.echo("  tapestry ingest <file_or_folder>  - import conversations")
    click.echo("  tapestry catchup                  - build summaries")
    click.echo("  tapestry status                   - check system status")


# Register subcommands
from tapestry.cli.ingest import ingest  # noqa: E402
from tapestry.cli.build import (  # noqa: E402
    catchup,
    chunk_benchmark,
    generate_daily,
    generate_l0,
    generate_monthly,
    generate_weekly,
    generate_yearly,
    iterate,
    summarize,
)
from tapestry.cli.query import (  # noqa: E402
    context,
    conversations,
    drift,
    export,
    fulltext,
    recall,
    regex,
    search,
    show_cmd,
    similar,
    stats_cmd,
    tree_cmd,
)
from tapestry.cli.manage import agents, rebuild_fts_cmd, retitle, status  # noqa: E402
from tapestry.cli.benchmark import benchmark, bench_score, bench_topic, extract_topics, run_benchmark_cmd  # noqa: E402

cli.add_command(ingest)
cli.add_command(generate_l0)
cli.add_command(generate_daily)
cli.add_command(generate_weekly)
cli.add_command(generate_monthly)
cli.add_command(generate_yearly)
cli.add_command(summarize)
cli.add_command(iterate)
cli.add_command(catchup)
cli.add_command(search)
cli.add_command(recall)
cli.add_command(show_cmd)
cli.add_command(context)
cli.add_command(tree_cmd)
cli.add_command(stats_cmd)
cli.add_command(conversations)
cli.add_command(export)
cli.add_command(similar)
cli.add_command(drift)
cli.add_command(fulltext)
cli.add_command(regex)
cli.add_command(status)
cli.add_command(agents)
cli.add_command(retitle)
cli.add_command(rebuild_fts_cmd)
cli.add_command(benchmark)
cli.add_command(bench_score)
cli.add_command(bench_topic)
cli.add_command(extract_topics)
cli.add_command(chunk_benchmark)
cli.add_command(run_benchmark_cmd)


@cli.command()
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--port", default=5008, help="Port to listen on")
@click.option("--debug/--no-debug", default=True, help="Enable debug mode")
@click.option("--browser", is_flag=True, help="Open browser automatically")
def calendar(host: str, port: int, debug: bool, browser: bool) -> None:
    """Launch the calendar web UI."""
    try:
        from flask import Flask  # noqa: F401
    except ImportError:
        click.echo("Flask not installed. Run: pip install total-recall[web]")
        raise SystemExit(1)

    from tapestry import Tapestry
    from tapestry.web import create_app

    import os

    t = Tapestry()
    app = create_app(t)
    url = f"http://{host}:{port}/"

    # Only print and open browser in the main process, not the reloader child
    if os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        click.echo(f"Tapestry Calendar: {url}")
        if browser:
            import threading
            import webbrowser
            threading.Timer(1.0, webbrowser.open, args=[url]).start()

    app.run(host=host, port=port, debug=debug)
