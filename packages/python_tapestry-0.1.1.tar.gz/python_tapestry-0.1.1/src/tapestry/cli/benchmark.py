"""CLI commands for RY Factor benchmarking.

Commands:
    benchmark    Run the full benchmark pipeline (snapshot + generate + score)
    bench-score  Re-score existing benchmark summaries with different methods
    bench-topic  Run topic-based benchmark (extract + compare information volume)

NOTE: Debug prints are intentional pipeline tracing. Do NOT remove them.
      This is pre-production code. All debug output stays until launch.
"""

from __future__ import annotations

import os
from datetime import datetime

import click

from tapestry import Tapestry
from tapestry.cli import validate_agent


class BenchLogger:
    """Logger for benchmark runs — writes to stdout and logs/benchmark.log."""

    def __init__(self):
        log_dir = "logs"
        os.makedirs(log_dir, exist_ok=True)
        self.fh = open(os.path.join(log_dir, "benchmark.log"), "a", encoding="utf-8")
        self.start = datetime.now()
        header = (
            f"\n{'=' * 60}\n"
            f"Benchmark started: {self.start.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"{'=' * 60}"
        )
        self.fh.write(header + "\n")
        self.fh.flush()
        click.echo(header)

    def __call__(self, msg: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        click.echo(msg)
        self.fh.write(f"[{ts}] {msg}\n")
        self.fh.flush()

    def close(self, error: str | None = None) -> None:
        elapsed = datetime.now() - self.start
        if error:
            footer = f"\nSTOPPED after {elapsed}: {error}"
        else:
            footer = f"\nCompleted in {elapsed}"
        click.echo(footer)
        self.fh.write(footer + "\n")
        self.fh.close()


@click.command("benchmark")
@click.argument("date_start")
@click.argument("date_end")
@click.option("--agent", required=True, help="Agent name to benchmark")
@click.option("--methods", default="tfidf,sbert,rouge_l,bm25",
              help="Comma-separated scoring methods (default: all four)")
@click.option("--delay", default=1.0, type=float, help="Seconds between LLM calls")
@click.option("--score-only", is_flag=True,
              help="Skip generation, only score existing benchmark summaries")
@click.option("--snapshot-only", is_flag=True,
              help="Only snapshot context-aware summaries (no generation or scoring)")
@click.option("--generate-only", is_flag=True,
              help="Only generate context-free summaries (no scoring)")
@click.option("--db", "db_path", default=None, help="Path to database (default: tapestry.toml db_path)")
@click.option("--max-level", default=4, type=int, help="Max summary level to generate and score (0=L0 only, default: 4)")
@click.option("--force", is_flag=True, help="Clear existing benchmark data for this agent/date range before running")
def benchmark(
    date_start: str,
    date_end: str,
    agent: str,
    methods: str,
    delay: float,
    score_only: bool,
    snapshot_only: bool,
    generate_only: bool,
    db_path: str | None,
    max_level: int,
    force: bool,
) -> None:
    """Run RY Factor benchmark for an agent over a date range.

    Phases:
    1. Snapshot context-aware summaries from tapestry into benchmark_summaries
    2. Generate context-free summaries (LLM calls — the expensive part)
    3. Score both tracks and write results to benchmark_results

    DATE_START and DATE_END are inclusive YYYY-MM-DD dates.
    """
    method_list = [m.strip() for m in methods.split(",")]
    log = BenchLogger()

    try:
        overrides = {}
        if db_path:
            overrides["db_path"] = db_path
        with Tapestry(**overrides) as t:
            if not db_path:
                validate_agent(t.config, agent)
            log(f"Agent: {agent}")
            log(f"Date range: {date_start} to {date_end}")
            log(f"Methods: {', '.join(method_list)}")

            if force:
                log("--force: clearing existing benchmark data for this agent/date range")
                t.db.sql("DELETE FROM benchmark_results WHERE bench_agent = ? AND bench_date_start = ? AND bench_date_end = ?", (agent, date_start, date_end))
                t.db.sql("DELETE FROM benchmark_summaries WHERE bsum_agent = ? AND bsum_date >= ? AND bsum_date <= ?", (agent, date_start, date_end))

            from tapestry.engine.benchmark import (
                generate_context_free,
                score_benchmarks,
                snapshot_context_aware,
            )

            # Create benchmark_tests record
            bt_id = t.db.sql(
                """INSERT INTO benchmark_tests (bt_agent, bt_date_start, bt_date_end, bt_method)
                   VALUES (?, ?, ?, ?)""",
                (agent, date_start, date_end, ",".join(method_list)),
            )
            log(f"Test ID: {bt_id}")

            if not score_only:
                # Phase 1: Snapshot context-aware
                log("\n--- Phase 1: Snapshot context-aware summaries ---")
                copied = snapshot_context_aware(
                    t.db, agent, date_start, date_end, log=log,
                )
                log(f"Copied {copied} records")

                if snapshot_only:
                    log.close()
                    return

                # Phase 2: Generate context-free
                log("\n--- Phase 2: Generate context-free summaries ---")
                generated = generate_context_free(
                    t.db, t.llm, t.config, agent,
                    date_start, date_end,
                    log=log, delay=delay, max_level=max_level,
                )
                log(
                    f"Generated: L0={generated['l0']}, L1={generated['l1']}, "
                    f"L2={generated['l2']}, L3={generated['l3']}"
                )

                if generate_only:
                    log.close()
                    return

            # Phase 3: Score
            log("\n--- Phase 3: Score benchmarks ---")
            written = score_benchmarks(
                t.db, t.config, agent,
                date_start, date_end,
                methods=method_list, log=log, max_level=max_level,
            )
            log(
                f"Scores written: same-track={written['same_track']}, "
                f"cross-track={written['cross_track']}"
            )

            # Link results to this test
            t.db.sql(
                """UPDATE benchmark_results SET bt_id = ?
                   WHERE bench_agent = ? AND bench_date_start = ?
                   AND bench_date_end = ? AND bt_id IS NULL""",
                (bt_id, agent, date_start, date_end),
            )

            # Calculate and store overall RY score
            ry_row = t.db.sql(
                """SELECT AVG(bench_ry_factor) as avg_ry
                   FROM benchmark_results
                   WHERE bt_id = ? AND bench_ry_factor IS NOT NULL""",
                (bt_id,), single=True,
            )
            ry_score = ry_row["avg_ry"] if ry_row and ry_row["avg_ry"] else 0.0
            t.db.sql(
                "UPDATE benchmark_tests SET bt_ry_score = ? WHERE bt_id = ?",
                (ry_score, bt_id),
            )
            log(f"Overall RY Factor: {ry_score:+.4f}")

        log.close()

    except Exception as e:
        log.close(error=str(e))
        raise


@click.command("bench-score")
@click.argument("date_start")
@click.argument("date_end")
@click.option("--agent", required=True, help="Agent name")
@click.option("--methods", default="tfidf,sbert,rouge_l,bm25",
              help="Comma-separated scoring methods")
def bench_score(date_start: str, date_end: str, agent: str, methods: str) -> None:
    """Re-score existing benchmark summaries without regenerating.

    Use this to add new scoring methods to existing benchmark data.
    """
    method_list = [m.strip() for m in methods.split(",")]
    log = BenchLogger()

    try:
        with Tapestry() as t:
            validate_agent(t.config, agent)
            from tapestry.engine.benchmark import score_benchmarks

            written = score_benchmarks(
                t.db, t.config, agent,
                date_start, date_end,
                methods=method_list, log=log,
            )
            log(
                f"Scores written: same-track={written['same_track']}, "
                f"cross-track={written['cross_track']}"
            )
        log.close()

    except Exception as e:
        log.close(error=str(e))
        raise


@click.command("run-benchmark")
@click.option("--agent", default=None, help="Agent name to benchmark")
@click.option("--start", "date_start", default=None, help="Start date YYYY-MM-DD")
@click.option("--end", "date_end", default=None, help="End date YYYY-MM-DD")
@click.option("--delay", default=0.5, type=float, help="Seconds between LLM calls (default: 0.5)")
@click.option("--test-db", "test_db_path", default=None, help="Path to test DB (default: db/test_benchmark.db)")
@click.option("--batch", "batch_file", default=None, type=click.Path(exists=True),
              help="JSON file with list of {agent, date_start, date_end} specs")
@click.option("--bt-id", "bt_id_override", default=None, type=int,
              help="Re-run an existing benchmark test by ID (updates in place)")
def run_benchmark_cmd(
    agent: str | None,
    date_start: str | None,
    date_end: str | None,
    delay: float,
    test_db_path: str | None,
    batch_file: str | None,
    bt_id_override: int | None,
) -> None:
    """Run the full topic-based benchmark pipeline end-to-end.

    Single run:
      tapestry run-benchmark --agent X --start 2025-01-01 --end 2025-03-31

    Batch mode:
      tapestry run-benchmark --batch benchmarks.json

    The JSON file should contain a list of objects:
      [{"agent": "...", "date_start": "YYYY-MM-DD", "date_end": "YYYY-MM-DD"}, ...]

    Pipeline: import messages -> import context -> build CA -> build CF ->
    extract CA topics -> extract CF topics -> SBERT match -> LLM verify -> score RY
    """
    import json

    from tapestry.engine.benchmark_runner import run_batch, run_benchmark

    log = BenchLogger()

    def _progress(step, detail, pct):
        log(f"[{step}] {detail} ({pct}%)")

    try:
        with Tapestry() as t:
            prod_db_path = t.config.db_path

            if not test_db_path:
                from pathlib import Path
                test_db_path = str(Path(t.config.project_dir) / "db" / "test_benchmark.db")

            if batch_file:
                # Batch mode
                with open(batch_file, "r", encoding="utf-8") as f:
                    specs = json.load(f)

                if not isinstance(specs, list) or not specs:
                    click.echo("Batch file must contain a non-empty JSON array.")
                    return

                log(f"Batch mode: {len(specs)} runs")
                log(f"Production DB: {prod_db_path}")
                log(f"Test DB: {test_db_path}")

                results = run_batch(
                    prod_db_path, test_db_path, specs,
                    delay=delay, progress=_progress,
                )

                log(f"\n{'=' * 60}")
                log(f"{'Agent':20s} {'Date Range':25s} {'RY':>8s} {'Matched':>8s} {'CA-Only':>8s}")
                log(f"{'-' * 60}")
                for r in results:
                    log(f"{r['agent']:20s} {r['date_start']} to {r['date_end']}  "
                        f"{r['ry_score']:8.3f} {r['matched']:8d} {r['ca_only']:8d}")

            else:
                # Single run mode
                if bt_id_override:
                    # Re-run existing test — read agent/dates from DB
                    row = t.db.sql(
                        "SELECT bt_agent, bt_date_start, bt_date_end FROM benchmark_tests WHERE bt_id = ?",
                        (bt_id_override,), single=True,
                    )
                    if not row:
                        click.echo(f"No benchmark test found with bt_id={bt_id_override}")
                        return
                    agent = row["bt_agent"]
                    date_start = row["bt_date_start"]
                    date_end = row["bt_date_end"]
                    bt_id = bt_id_override
                    log(f"Re-running existing test bt_id={bt_id}")
                else:
                    if not agent or not date_start or not date_end:
                        click.echo("--agent, --start, and --end are required for single runs.")
                        click.echo("Use --batch for batch mode, or --bt-id to re-run an existing test.")
                        return

                    # Create benchmark_tests record
                    bt_id = t.db.sql(
                        """INSERT INTO benchmark_tests (bt_agent, bt_date_start, bt_date_end, bt_method)
                           VALUES (?, ?, ?, 'topics')""",
                        (agent, date_start, date_end),
                    )

                log(f"Agent: {agent}")
                log(f"Date range: {date_start} to {date_end}")
                log(f"Production DB: {prod_db_path}")
                log(f"Test DB: {test_db_path}")
                log(f"Test ID: {bt_id}")

                result = run_benchmark(
                    prod_db_path, test_db_path, agent, date_start, date_end, bt_id,
                    llm=t.llm, config=t.config, delay=delay, progress=_progress,
                )

                log(f"\n{'=' * 60}")
                log(f"RY Factor: {result['ry_score']:.3f}")
                log(f"Matched: {result['matched']}, CA-only: {result['ca_only']}, CF-only: {result['cf_only']}")

        log.close()

    except Exception as e:
        log.close(error=str(e))
        raise


@click.command("extract-topics")
@click.option("--conv-id", required=True, help="Conversation ID")
@click.option("--agent", required=True, help="Agent name")
@click.option("--source", default="chat", type=click.Choice(["chat", "summary"]), help="Source: raw chat or L0 summary (default: chat)")
@click.option("--db", "db_path", default=None, help="Path to database (default: tapestry.toml db_path)")
@click.option("--save", is_flag=True, help="Persist extracted topics to benchmark_topics table")
def extract_topics(conv_id: str, agent: str, source: str, db_path: str | None, save: bool) -> None:
    """Extract action-specific topics from a conversation or its L0 summary.

    --source chat    (default) Extract from raw conversation messages
    --source summary Extract from the context-free L0 summary in benchmark_summaries
    """
    overrides = {}
    if db_path:
        overrides["db_path"] = db_path

    with Tapestry(**overrides) as t:
        from tapestry.engine.topic_benchmark import FREE_EXTRACT_PROMPT

        if source == "summary":
            row = t.db.sql(
                """SELECT bsum_content, bsum_title FROM benchmark_summaries
                   WHERE bsum_agent = ? AND bsum_level = 0 AND bsum_source = ?
                   AND bsum_track = 'context-free'""",
                (agent, conv_id),
                single=True,
            )
            if not row:
                click.echo(f"No context-free L0 summary found for conv_id={conv_id[:8]}")
                return
            text = row["bsum_content"]
            click.echo(f"Extracting topics from L0 summary: {row['bsum_title'][:60]}")
        else:
            rows = t.db.sql(
                """SELECT tmsg_role, tmsg_content
                   FROM tapestry_messages
                   WHERE tmsg_ref_conv_id = ? AND tmsg_agent = ?
                   ORDER BY tmsg_order""",
                (conv_id, agent),
            )
            if not rows:
                click.echo(f"No messages found for conv_id={conv_id} agent={agent}")
                return
            # Join messages as plain text — no role markers in body
            text = "\n\n".join(
                r['tmsg_content'] for r in rows if r['tmsg_content']
            )
            click.echo(f"Extracting topics from chat {conv_id[:8]}... ({len(rows)} messages)")

        # --- PIPELINE TRACE: INPUT ---
        click.echo(f"\n{'=' * 60}")
        click.echo("PIPELINE TRACE: INPUT")
        click.echo(f"{'=' * 60}")
        click.echo(f"Text length: {len(text)} chars")
        click.echo(f"Text preview (first 300 chars):\n{text[:300].encode('ascii', 'replace').decode()}")
        click.echo(f"Text preview (last 200 chars):\n{text[-200:].encode('ascii', 'replace').decode()}")

        # --- PIPELINE TRACE: PROMPT ASSEMBLY ---
        click.echo(f"\n{'=' * 60}")
        click.echo("PIPELINE TRACE: PROMPT ASSEMBLY")
        click.echo(f"{'=' * 60}")
        click.echo(f"System prompt length: {len(FREE_EXTRACT_PROMPT)} chars")
        click.echo(f"User content length: {len(text)} chars")
        click.echo(f"Model: {t.llm.config.content_model}")
        click.echo(f"Max tokens: {t.llm.config.max_tokens_content}")
        click.echo(f"Temperature: {t.llm.config.temperature}")
        click.echo(f"API URL: {t.llm.config.api_url}")

        # --- PIPELINE TRACE: LLM CALL ---
        click.echo(f"\n{'=' * 60}")
        click.echo("PIPELINE TRACE: LLM CALL")
        click.echo(f"{'=' * 60}")
        click.echo("Sending request...")

        response = t.llm.request(
            [
                {"role": "system", "content": FREE_EXTRACT_PROMPT},
                {"role": "user", "content": text},
            ],
            max_tokens=16000,
        )

        # --- PIPELINE TRACE: RAW RESULT ---
        click.echo(f"\n{'=' * 60}")
        click.echo("PIPELINE TRACE: RAW RESULT")
        click.echo(f"{'=' * 60}")
        click.echo(f"Response length: {len(response) if response else 0} chars")
        click.echo(f"Response type: {type(response).__name__}")
        click.echo(f"Full raw response:\n{response}")

        # --- PIPELINE TRACE: PARSING ---
        click.echo(f"\n{'=' * 60}")
        click.echo("PIPELINE TRACE: PARSING")
        click.echo(f"{'=' * 60}")

        import json
        try:
            topics = json.loads(response.strip())
            click.echo(f"JSON parse: SUCCESS — type={type(topics).__name__}, count={len(topics) if isinstance(topics, list) else 'N/A'}")
        except Exception as parse_err:
            click.echo(f"JSON parse: FAILED — {parse_err}")
            click.echo(f"Falling back to line split")
            topics = [line.strip() for line in response.strip().splitlines() if line.strip()]
            click.echo(f"Line split produced {len(topics)} items")

        # --- DB PERSISTENCE ---
        if save and isinstance(topics, list):
            level = -1 if source == "chat" else 0
            is_conv = 1 if source == "chat" else 0
            t.db.sql(
                "DELETE FROM benchmark_topics WHERE btop_agent = ? AND btop_source = ? AND btop_level = ?",
                (agent, conv_id, level),
            )
            for i, topic_str in enumerate(topics, 1):
                t.db.sql(
                    """INSERT INTO benchmark_topics
                       (btop_agent, btop_source, btop_level, btop_is_conversation, btop_content, btop_order)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (agent, conv_id, level, is_conv, topic_str, i),
                )
            click.echo(f"\nSaved {len(topics)} topics to benchmark_topics (level={level})")

        # --- PIPELINE TRACE: FORMATTED RESULT ---
        click.echo(f"\n{'=' * 60}")
        click.echo(f"PIPELINE TRACE: FORMATTED RESULT — {len(topics)} topics")
        click.echo(f"{'=' * 60}\n")
        for i, topic in enumerate(topics, 1):
            click.echo(f"{i:3}. {topic}")


@click.command("bench-topic")
@click.argument("date_start")
@click.argument("date_end")
@click.option("--agent", required=True, help="Agent name to benchmark")
@click.option("--db", "db_path", default=None, help="Path to database (default: tapestry.toml db_path)")
def bench_topic(date_start: str, date_end: str, agent: str, db_path: str | None) -> None:
    """Run topic-based RY Factor benchmark.

    Extracts topic-specific information from both tracks and compares
    information volume against ground truth from raw conversations.

    Tests 4 topics across frequency tiers:
    - High: Uni/Unibot
    - Medium: ESP32
    - Low: Genetic Marker, ATtiny85/SoilSensor

    DATE_START and DATE_END are inclusive YYYY-MM-DD dates.
    """
    log = BenchLogger()

    try:
        overrides = {}
        if db_path:
            overrides["db_path"] = db_path
        with Tapestry(**overrides) as t:
            if not db_path:
                validate_agent(t.config, agent)
            log(f"Agent: {agent}")
            log(f"Database: {t.config.db_path}")
            log(f"Date range: {date_start} to {date_end}")

            from tapestry.engine.topic_benchmark import run_topic_benchmark

            results = run_topic_benchmark(
                t.db, t.llm, agent,
                date_start, date_end,
                log=log,
            )

            log("\n" + "-" * 70)
            log(f"{'Topic':25s} {'Tier':8s} {'CA':>6s} {'CF':>6s} {'RY':>8s}")
            log("-" * 70)
            for c in results["comparisons"]:
                log(
                    f"{c['topic']:25s} {c['tier']:8s} "
                    f"{c['ca_sbert']:6.3f} {c['cf_sbert']:6.3f} "
                    f"{c['ry_sbert']:+8.4f}"
                )

        log.close()

    except Exception as e:
        log.close(error=str(e))
        raise
