"""CLI commands for tapestry summary generation.

Commands:
    generate-l0     Generate a single L0 conversation summary
    generate-daily  Generate a single L1 daily summary
    summarize       Show context + generate L0s for a date, then daily
    iterate         Context-aware date-by-date processing with repair cascade
    catchup         Incremental rebuild — fill all missing summaries
"""

from __future__ import annotations

import os
from datetime import datetime

import click

from tapestry import Tapestry
from tapestry.cli import validate_agent


class RunLogger:
    """Dual-output logger: writes to both click.echo (stdout) and a log file."""

    def __init__(self, log_path: str):
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        self.fh = open(log_path, "a", encoding="utf-8")
        self.start = datetime.now()
        header = f"\n{'=' * 60}\nCatchup started: {self.start.strftime('%Y-%m-%d %H:%M:%S')}\n{'=' * 60}"
        self.fh.write(header + "\n")
        self.fh.flush()
        click.echo(header)

    def __call__(self, msg: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        click.echo(msg)
        self.fh.write(f"[{ts}] {msg}\n")
        self.fh.flush()

    def close(self, error: str | None = None) -> None:
        elapsed = datetime.now() - self.start
        if error:
            footer = f"\nSTOPPED after {elapsed}: {error}"
        else:
            footer = f"\nCompleted in {elapsed}"
        click.echo(footer)
        self.fh.write(footer + "\n")
        self.fh.close()


@click.command("generate-l0")
@click.argument("conv_id")
@click.option("--agent", default="default", help="Agent name")
@click.option("--chunk-size", type=int, default=None, help="Override chunk size in tokens (default: from config)")
def generate_l0(conv_id: str, agent: str, chunk_size: int | None) -> None:
    """Generate a Level 0 conversation summary."""
    from tapestry.engine.context import resolve_context
    from tapestry.engine.generate import auto_generate_l0

    with Tapestry() as t:
        if chunk_size is not None:
            t.config.llm.chunk_size_tokens = chunk_size
        _name, agent_id = t._resolve_agent(agent)
        # Find the date of this conversation's last message
        last_msg = t.db.sql(
            "SELECT DATE(MAX(tmsg_timestamp)) as conv_date FROM tapestry_messages WHERE tmsg_ref_conv_id = ?",
            (conv_id,),
            single=True,
        )
        if not last_msg or not last_msg["conv_date"]:
            click.echo(f"No messages found for conversation {conv_id}")
            return

        context_items, _ = resolve_context(t.db, agent, agent_id, last_msg["conv_date"])

        tap_id = auto_generate_l0(t.db, t.llm, t.config, agent, agent_id, conv_id, context_items=context_items)
        if tap_id is None:
            click.echo(f"No messages found for conversation {conv_id}")
        else:
            row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            click.echo(f"L0 tap_id={tap_id}: {row['tap_title']}")


@click.command("generate-daily")
@click.argument("date_str", metavar="DATE")
@click.option("--agent", default="default", help="Agent name")
def generate_daily(date_str: str, agent: str) -> None:
    """Generate a Level 1 daily summary for DATE (YYYY-MM-DD)."""
    from tapestry.engine.generate import auto_generate_daily

    with Tapestry() as t:
        _name, agent_id = t._resolve_agent(agent)
        tap_id = auto_generate_daily(t.db, t.llm, t.config, agent, agent_id, date_str)
        if tap_id is None:
            click.echo(f"No L0 summaries found for {date_str}")
        else:
            row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            click.echo(f"L1 tap_id={tap_id}: {row['tap_title']}")


@click.command()
@click.argument("date_str", metavar="DATE")
@click.option("--agent", default="default", help="Agent name")
@click.option("--save", is_flag=True, help="Actually generate and store (default is dry run)")
def summarize(date_str: str, agent: str, save: bool) -> None:
    """Show context and generate summaries for DATE (YYYY-MM-DD).

    Without --save, shows what would be generated (context + conversation list).
    With --save, generates L0s for all unsummarized conversations, then the daily.
    """
    from tapestry.engine.context import resolve_context
    from tapestry.engine.generate import auto_generate_daily, auto_generate_l0
    from tapestry.engine.rollup import conversations_in_range

    with Tapestry() as t:
        _name, agent_id = t._resolve_agent(agent)
        # Show context
        context_items, repairs = resolve_context(t.db, agent, agent_id, date_str)

        if context_items:
            click.echo(f"Context: {len(context_items)} items loaded")
            for c in context_items:
                click.echo(f"  L{c['level']} [{c['range']}]: {c['title']}")
            click.echo()

        if repairs:
            click.echo(f"Repairs needed: {len(repairs)}")
            level_names = {0: "L0", 1: "L1 daily", 2: "L2 weekly", 3: "L3 monthly", 4: "L4 yearly"}
            for r in repairs:
                lvl = r["level"]
                label = level_names.get(lvl, f"L{lvl}")
                click.echo(f"  {label} — {r['range']} ({r['conv_count']} conversations)")
            click.echo()

        # Find conversations for this date
        convs = conversations_in_range(t.db, agent, agent_id, date_str, date_str)
        if not convs:
            click.echo(f"No conversations found for {date_str}")
            return

        click.echo(f"Conversations on {date_str}: {len(convs)}")
        for c in convs:
            # Check if L0 exists
            existing = t.db.sql(
                "SELECT tap_id, tap_title FROM tapestry WHERE tap_source = ? AND tap_level = 0",
                (c["tmsg_ref_conv_id"],),
                single=True,
            )
            if existing:
                click.echo(f"  {c['tmsg_ref_conv_id'][:12]}... -> L0 exists (tap_id={existing['tap_id']})")
            else:
                click.echo(f"  {c['tmsg_ref_conv_id'][:12]}... -> needs L0")

        if not save:
            click.echo("\nDry run. Use --save to generate.")
            return

        # Generate L0s
        click.echo("\nGenerating L0s...")
        for c in convs:
            tap_id = auto_generate_l0(t.db, t.llm, t.config, agent, agent_id, c["tmsg_ref_conv_id"],
                                      context_items=context_items)
            if tap_id:
                row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
                click.echo(f"  L0 tap_id={tap_id}: {row['tap_title']}")

        # Generate daily
        click.echo("\nGenerating daily...")
        daily_id = auto_generate_daily(t.db, t.llm, t.config, agent, agent_id, date_str)
        if daily_id:
            row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (daily_id,), single=True)
            click.echo(f"  L1 tap_id={daily_id}: {row['tap_title']}")

        click.echo("\nDone.")


@click.command("generate-weekly")
@click.argument("start_date", metavar="START")
@click.argument("end_date", metavar="END")
@click.option("--agent", default="default", help="Agent name")
def generate_weekly(start_date: str, end_date: str, agent: str) -> None:
    """Generate a Level 2 weekly summary for START to END date range."""
    from tapestry.engine.generate import auto_generate_weekly

    with Tapestry() as t:
        _name, agent_id = t._resolve_agent(agent)
        tap_id = auto_generate_weekly(t.db, t.llm, t.config, agent, agent_id, start_date, end_date)
        if tap_id is None:
            click.echo(f"No dailies found for {start_date} to {end_date}")
        else:
            row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            click.echo(f"L2 tap_id={tap_id}: {row['tap_title']}")


@click.command("generate-monthly")
@click.argument("year", type=int)
@click.argument("month", type=int)
@click.option("--agent", default="default", help="Agent name")
def generate_monthly(year: int, month: int, agent: str) -> None:
    """Generate a Level 3 monthly summary for YEAR MONTH."""
    from tapestry.engine.generate import auto_generate_monthly

    with Tapestry() as t:
        _name, agent_id = t._resolve_agent(agent)
        tap_id = auto_generate_monthly(t.db, t.llm, t.config, agent, agent_id, year, month)
        if tap_id is None:
            click.echo(f"No weeklies found for {year}-{month:02d}")
        else:
            row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            click.echo(f"L3 tap_id={tap_id}: {row['tap_title']}")


@click.command("generate-yearly")
@click.argument("year", type=int)
@click.option("--agent", default="default", help="Agent name")
def generate_yearly(year: int, agent: str) -> None:
    """Generate a Level 4 yearly summary for YEAR."""
    from tapestry.engine.generate import auto_generate_yearly

    with Tapestry() as t:
        _name, agent_id = t._resolve_agent(agent)
        tap_id = auto_generate_yearly(t.db, t.llm, t.config, agent, agent_id, year)
        if tap_id is None:
            click.echo(f"No monthlies found for {year}")
        else:
            row = t.db.sql("SELECT tap_title FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
            click.echo(f"L4 tap_id={tap_id}: {row['tap_title']}")


@click.command()
@click.argument("end_date", metavar="DATE", default=None, required=False)
@click.option("--agent", default="default", help="Agent name")
@click.option("--save", is_flag=True, help="Actually generate and store (default is dry run)")
@click.option("--chunk-size", type=int, default=None, help="Override chunk size in tokens (default: from config)")
def iterate(end_date: str | None, agent: str, save: bool, chunk_size: int | None) -> None:
    """Context-aware processing of conversations up to DATE.

    DATE defaults to today if omitted.

    Walks each date chronologically, resolves telescoping context,
    repairs gaps, generates L0s with context, then builds dailies.
    Final pass sweeps for missing weeklies and monthlies.

    Without --save, shows what would be generated (dry run).
    With --save, generates and stores all summaries.
    """
    if end_date is None:
        from datetime import date
        end_date = date.today().isoformat()
    with Tapestry() as t:
        if chunk_size is not None:
            t.config.llm.chunk_size_tokens = chunk_size
        validate_agent(t.config, agent)
        t.iterate(end_date, agent=agent, save=save, log=click.echo)


@click.command()
@click.option("--agent", default="default", help="Agent name")
@click.option("--delay", default=1.0, type=float, help="Seconds between API calls (default 1.0)")
@click.option("--log-file", default=None, help="Log file path (default: logs/catchup.log)")
@click.option("--chunk-size", type=int, default=None, help="Override chunk size in tokens (default: from config)")
def catchup(agent: str, delay: float, log_file: str | None, chunk_size: int | None) -> None:
    """Bulk rebuild WITHOUT telescoping context. For testing/initial ingest only.

    WARNING: Generates L0s with no prior context. Every summary is written in
    isolation, which degrades higher-level rollups (the Butiri Effect). Use
    'iterate' for production-quality data. Catchup is only useful for quickly
    populating a database to test the pipeline — the data MUST be rebuilt with
    'iterate' before it is considered usable.

    Fast 5-step process: generate missing L0s (no context), build dailies,
    sweep for missing weeklies and monthlies. Skips today's conversations.
    Stops on API failure after 5 retries. Resumable.
    """
    from tapestry.llm import LLMError

    t = Tapestry()
    if chunk_size is not None:
        t.config.llm.chunk_size_tokens = chunk_size
    validate_agent(t.config, agent)
    log_path = log_file or os.path.join(os.path.dirname(t.config.db_path), "..", "logs", "catchup.log")
    log_path = os.path.normpath(log_path)
    logger = RunLogger(log_path)
    logger(f"Agent: {agent}, Delay: {delay}s, Log: {log_path}")

    try:
        generated = t.catchup(agent=agent, delay=delay, log=logger)
        total = sum(generated.values())
        if total:
            logger(
                f"Catchup complete: L0={generated['l0']}, L1={generated['l1']},"
                f" L2={generated['l2']}, L3={generated['l3']}"
            )
        else:
            logger("Tapestry up to date.")
        logger.close()
    except LLMError as e:
        logger.close(error=f"LLM API failure: {e}")
        raise SystemExit(1)
    except KeyboardInterrupt:
        logger.close(error="Interrupted by user (Ctrl+C)")
        raise SystemExit(1)
    except Exception as e:
        logger.close(error=f"Unexpected error: {e}")
        raise
    finally:
        t.close()


@click.command("chunk-benchmark")
@click.option("--agent", default="default", help="Agent name")
@click.option("--conv-id", default=None, help="Conversation ID (default: largest)")
@click.option("--chunk-size", type=int, default=20000, help="Chunk size in tokens (default: 20000)")
@click.option("--merge-buffer", type=int, default=2000, help="Merge threshold buffer (default: 2000)")
@click.option("--overlap", type=int, default=0, help="Message overlap between chunks (default: 0)")
@click.option("--model", default=None, help="Override LLM model")
@click.option("--output", default=None, help="Write summary to file")
def chunk_benchmark(agent: str, conv_id: str | None, chunk_size: int,
                    merge_buffer: int, overlap: int, model: str | None,
                    output: str | None) -> None:
    """Run a single chunked summarization benchmark.

    Tests chunked L0 generation on a conversation and prints stats.
    Results are saved to the chunk_benchmarks table.
    """
    import sqlite3
    from tapestry.engine.chunking import (
        estimate_tokens, format_transcript, needs_chunking,
        summarize_chunked, MERGE_THRESHOLD_BUFFER,
    )
    import tapestry.engine.chunking as chunking_mod
    from tapestry.engine.prompts import factual_prompt

    with Tapestry() as t:
        if model:
            t.config.llm.content_model = model
        t.config.llm.chunk_size_tokens = chunk_size
        chunking_mod.MERGE_THRESHOLD_BUFFER = merge_buffer

        db_raw = sqlite3.connect(t.config.db_path)
        db_raw.row_factory = sqlite3.Row

        # Find conversation
        if conv_id:
            row = db_raw.execute("""
                SELECT tmsg_ref_conv_id, tmsg_agent, COUNT(*) as msg_count,
                       SUM(LENGTH(tmsg_content)) as total_chars
                FROM tapestry_messages WHERE tmsg_ref_conv_id = ?
                GROUP BY tmsg_ref_conv_id
            """, (conv_id,)).fetchone()
        else:
            row = db_raw.execute("""
                SELECT tmsg_ref_conv_id, tmsg_agent, COUNT(*) as msg_count,
                       SUM(LENGTH(tmsg_content)) as total_chars
                FROM tapestry_messages
                GROUP BY tmsg_ref_conv_id
                ORDER BY total_chars DESC LIMIT 1
            """).fetchone()

        if not row:
            click.echo("No conversation found.")
            db_raw.close()
            return

        cid = row["tmsg_ref_conv_id"]
        total_tokens = row["total_chars"] // 4
        click.echo(f"Target: {cid}")
        click.echo(f"Model: {t.config.llm.content_model}")
        click.echo(f"Agent: {row['tmsg_agent']}, {row['msg_count']} msgs, ~{total_tokens:,} tokens")
        click.echo(f"Chunk: {chunk_size}, Buffer: {merge_buffer}, Overlap: {overlap}")

        messages = [dict(r) for r in db_raw.execute("""
            SELECT tmsg_role, tmsg_content, tmsg_timestamp, tmsg_order
            FROM tapestry_messages WHERE tmsg_ref_conv_id = ?
            ORDER BY tmsg_order
        """, (cid,)).fetchall()]

        agent_label = t.config.agent_name.upper()
        user_label = t.config.user_name.upper()

        if not needs_chunking(messages, agent_label, user_label, chunk_size):
            click.echo("Conversation does not need chunking at this size.")
            db_raw.close()
            return

        system = factual_prompt(t.config.agent_name, t.config.user_name)

        result, stats = summarize_chunked(
            messages, t.llm, t.config, system, agent_label, user_label,
            chunk_size, overlap=overlap,
        )

        click.echo(f"\nFinal: ~{stats['final_tokens']:,} tokens | "
                    f"{stats['chunks']} chunks | {stats['llm_calls']} calls | "
                    f"{stats['merge_levels']} merge levels")

        # Persist
        cur = db_raw.execute("""
            INSERT INTO chunk_benchmark_runs
            (cbr_conv_id, cbr_model, cbr_chunk_size, cbr_merge_buffer,
             cbr_temperature, cbr_total_runs)
            VALUES (?, ?, ?, ?, ?, 1)
        """, (cid, t.config.llm.content_model, chunk_size, merge_buffer,
              t.config.llm.temperature))
        cbr_id = cur.lastrowid
        db_raw.execute("""
            INSERT INTO chunk_benchmarks
            (cbr_id, cb_run_number, cb_chunks, cb_llm_calls, cb_merge_levels,
             cb_intermediate_tokens, cb_final_tokens, cb_output_file)
            VALUES (?, 1, ?, ?, ?, ?, ?, ?)
        """, (cbr_id, stats["chunks"], stats["llm_calls"], stats["merge_levels"],
              stats["intermediate_tokens"], stats["final_tokens"], output))
        db_raw.commit()
        click.echo("Results saved to chunk_benchmarks table")

        if output:
            os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            click.echo(f"Summary written to {output}")
        else:
            click.echo(f"\n{result}")

        db_raw.close()
