"""CLI commands for tapestry query operations.

Commands:
    search          Search messages or summaries by keyword
    recall          Recall summaries for a date or date range
    show            Display a single tapestry record
    context         Show telescoping context for a date
    tree            Display the full hierarchy tree
    stats           Show record counts and size statistics
    conversations   List imported conversations
"""

from __future__ import annotations

import json

import click

from tapestry import Tapestry
from tapestry.cli.formatters import (
    _json_dumps,
    _safe,
    fmt_context,
    fmt_conversations,
    fmt_drift,
    fmt_fulltext,
    fmt_recall,
    fmt_search,
    fmt_show,
    fmt_similar,
    fmt_stats,
    fmt_tree,
)

FORMAT_OPTION = click.option(
    "--format", "-f", "fmt", type=click.Choice(["text", "json", "jsonl"]),
    default="text", help="Output format (default: text)",
)
EXPORT_FORMAT_OPTION = click.option(
    "--format", "-f", "fmt", type=click.Choice(["json", "jsonl", "text"]),
    default="json", help="Output format (default: json)",
)


# ── search ────────────────────────────────────────────────────────────

@click.command()
@click.argument("query")
@click.option("--agent", "-a", default=None, help="Agent name (default: first in config)")
@click.option("--level", "-l", type=int, default=None, help="Filter by summary level (0-4)")
@click.option("--summaries", "-s", is_flag=True, help="Search summary content instead of messages")
@FORMAT_OPTION
def search(query: str, agent: str | None, level: int | None, summaries: bool, fmt: str) -> None:
    """Search conversations or summaries by keyword."""
    with Tapestry() as t:
        if summaries:
            results = t.search_summaries(query, agent=agent, level=level)
        else:
            results = t.search(query, agent=agent, level=level)

    click.echo(fmt_search(results, summaries, query, fmt))


# ── similar (cosine) ──────────────────────────────────────────────────

@click.command()
@click.argument("query")
@click.option("--agent", "-a", default=None, help="Agent name (default: first in config)")
@click.option("--level", "-l", type=int, default=None, help="Filter by summary level (0-4)")
@click.option("--top", "-n", "top_n", type=int, default=10, help="Number of results (default: 10)")
@FORMAT_OPTION
def similar(query: str, agent: str | None, level: int | None, top_n: int, fmt: str) -> None:
    """Find similar summaries using TF-IDF cosine similarity.

    Searches across all tapestry summaries for the agent, ranking by
    semantic similarity to the query. Requires: pip install total-recall[search]
    """
    with Tapestry() as t:
        results = t.similar(query, agent=agent, level=level, top_n=top_n)

    click.echo(fmt_similar(results, query, fmt))


# ── fulltext (unified) ────────────────────────────────────────────────

@click.command()
@click.argument("query")
@click.option("--agent", "-a", default=None, help="Agent name (default: first in config)")
@click.option("--level", "-l", type=int, default=None, help="Filter summary results by level (0-4)")
@click.option("--top", "-n", "top_n", type=int, default=20, help="Number of results (default: 20)")
@click.option("--mode", "-m", type=click.Choice(["auto", "semantic", "fulltext"]),
              default="auto", help="Search mode (default: auto)")
@FORMAT_OPTION
def fulltext(query: str, agent: str | None, level: int | None, top_n: int,
             mode: str, fmt: str) -> None:
    """Two-layer search: semantic on summaries + fulltext on messages.

    Modes:
      auto      - Semantic on summaries + FTS5 on messages (default)
      semantic  - TF-IDF cosine on summaries only
      fulltext  - FTS5 BM25 on both summaries and messages
    """
    with Tapestry() as t:
        results = t.unified_search(query, agent=agent, mode=mode, level=level, top_n=top_n)

    click.echo(fmt_fulltext(results, query, mode, fmt))


# ── regex ────────────────────────────────────────────────────────────

@click.command()
@click.argument("pattern")
@click.option("--agent", "-a", default=None, help="Agent name (default: first in config)")
@click.option("--level", "-l", type=int, default=None, help="Filter summary results by level (0-4)")
@click.option("--top", "-n", "top_n", type=int, default=20, help="Number of results (default: 20)")
@FORMAT_OPTION
def regex(pattern: str, agent: str | None, level: int | None, top_n: int,
          fmt: str) -> None:
    """Search summaries and messages using Python regex patterns.

    PATTERN is a Python regular expression (case-insensitive).
    Searches both summary content and raw conversation messages.

    Examples:
      tapestry regex "T\\.\\s*A\\.\\s*P"
      tapestry regex "def\\s+\\w+_search"
    """
    with Tapestry() as t:
        results = t.regex(pattern, agent=agent, level=level, top_n=top_n)

    click.echo(fmt_fulltext(results, pattern, "regex", fmt))


# ── recall ────────────────────────────────────────────────────────────

@click.command()
@click.argument("date_str")
@click.argument("end_date", required=False, default=None)
@click.option("--agent", "-a", default=None, help="Agent name")
@FORMAT_OPTION
def recall(date_str: str, end_date: str | None, agent: str | None, fmt: str) -> None:
    """Recall summaries for a date or date range."""
    with Tapestry() as t:
        records = t.recall(date_str, agent=agent, end_date=end_date)

    click.echo(fmt_recall(records, date_str, end_date, fmt))


# ── show ──────────────────────────────────────────────────────────────

@click.command("show")
@click.argument("tap_id", type=int)
@FORMAT_OPTION
def show_cmd(tap_id: int, fmt: str) -> None:
    """Display a single tapestry record by ID."""
    with Tapestry() as t:
        record = t.show(tap_id)

    click.echo(fmt_show(record, tap_id, fmt))


# ── context ───────────────────────────────────────────────────────────

@click.command()
@click.argument("date_str")
@click.option("--agent", "-a", default=None, help="Agent name")
@FORMAT_OPTION
def context(date_str: str, agent: str | None, fmt: str) -> None:
    """Show telescoping context for a date."""
    with Tapestry() as t:
        from tapestry.engine.context import resolve_context
        agent_name, agent_id = t._resolve_agent(agent)
        ctx_items, repairs = resolve_context(t.db, agent_name, agent_id, date_str)

    click.echo(fmt_context(ctx_items, repairs, date_str, fmt))


# ── tree ──────────────────────────────────────────────────────────────

@click.command("tree")
@click.option("--agent", "-a", default=None, help="Agent name")
@FORMAT_OPTION
def tree_cmd(agent: str | None, fmt: str) -> None:
    """Display the full tapestry hierarchy tree."""
    with Tapestry() as t:
        data = t.tree(agent=agent)

    click.echo(fmt_tree(data, fmt))


# ── stats ─────────────────────────────────────────────────────────────

@click.command("stats")
@click.option("--agent", "-a", default=None, help="Agent name")
@FORMAT_OPTION
def stats_cmd(agent: str | None, fmt: str) -> None:
    """Show record counts and size statistics."""
    with Tapestry() as t:
        s = t.stats(agent=agent)

    click.echo(fmt_stats(s, fmt))


# ── conversations ─────────────────────────────────────────────────────

@click.command()
@click.option("--agent", "-a", default=None, help="Agent name (omit for all)")
@FORMAT_OPTION
def conversations(agent: str | None, fmt: str) -> None:
    """List imported conversations."""
    with Tapestry() as t:
        convs = t.conversations(agent=agent)

    click.echo(fmt_conversations(convs, fmt))


# ── export ────────────────────────────────────────────────────────────

@click.command()
@click.option("--agent", "-a", default=None, help="Agent name (required)")
@click.option("--level", "-l", type=int, default=None, help="Filter by level (0-4)")
@EXPORT_FORMAT_OPTION
def export(agent: str | None, level: int | None, fmt: str) -> None:
    """Export all tapestry records for an agent.

    Dumps the full hierarchy (or a specific level) as JSON, JSONL, or text.
    Pipe to a file: tapestry export --agent X --format json > history.json
    """
    with Tapestry() as t:
        agent_name, agent_id = t._resolve_agent(agent)

        conditions = ["tap_agent_id = ?"]
        params: list = [agent_id]

        if level is not None:
            conditions.append("tap_level = ?")
            params.append(level)

        where = " AND ".join(conditions)
        rows = t.db.sql(
            f"""SELECT * FROM tapestry
                WHERE {where}
                ORDER BY tap_level, tap_date, tap_date_start, tap_id""",
            tuple(params),
        ) or []

        records = [dict(r) for r in rows]

    if not records:
        click.echo(f"No records found for agent={agent_name}" +
                   (f" level={level}" if level is not None else ""), err=True)
        return

    if fmt == "json":
        click.echo(_json_dumps(records))
    elif fmt == "jsonl":
        for rec in records:
            click.echo(json.dumps(rec, default=str, ensure_ascii=True))
    else:
        # text — use record formatter
        from tapestry.cli.formatters import _fmt_record_text
        parts = [_fmt_record_text(r) for r in records]
        click.echo(_safe("\n\n".join(parts)))


# ── drift ────────────────────────────────────────────────────────────

@click.command()
@click.argument("tap_id", type=int)
@click.option("--agent", "-a", default=None, help="Agent name (default: first in config)")
@FORMAT_OPTION
def drift(tap_id: int, agent: str | None, fmt: str) -> None:
    """Measure how regenerating a node would change its ancestors.

    Walks up the hierarchy from TAP_ID, regenerating each ancestor from
    its current children, and compares against stored content using
    TF-IDF cosine similarity. Reports drift severity at each level.

    Requires: pip install total-recall[search]

    This is a read-only operation — no database changes are made.
    """
    with Tapestry() as t:
        from tapestry.engine.drift import measure_drift
        agent_name, agent_id = t._resolve_agent(agent)
        result = measure_drift(t.db, t.llm, t.config, agent_name, agent_id, tap_id)

    click.echo(fmt_drift(result, fmt))
