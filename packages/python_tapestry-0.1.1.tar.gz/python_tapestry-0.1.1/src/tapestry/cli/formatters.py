"""Output formatters for tapestry CLI commands.

Serialize query results to text (default), json, or jsonl format.
Text format preserves the existing CLI output. JSON and JSONL output
the raw dicts from the Python API for piping into other tools.
"""

from __future__ import annotations

import json
from typing import Any

LEVEL_NAMES = {0: "conversation", 1: "daily", 2: "weekly", 3: "monthly", 4: "yearly"}


def _safe(text: str) -> str:
    """Strip non-BMP and non-cp1252 chars for safe Windows terminal output."""
    return text.encode("cp1252", errors="replace").decode("cp1252")


def _json_dumps(obj: Any) -> str:
    """JSON serialize with consistent settings."""
    return json.dumps(obj, indent=2, default=str, ensure_ascii=True)


def _jsonl_dumps(records: list[dict]) -> str:
    """One JSON object per line."""
    return "\n".join(json.dumps(r, default=str, ensure_ascii=True) for r in records)


# ── search ────────────────────────────────────────────────────────────


def fmt_search(results: list[dict], summaries: bool, query: str, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(results)
    if fmt == "jsonl":
        return _jsonl_dumps(results)

    # text
    if not results:
        kind = "summaries" if summaries else "conversations"
        return f"No {kind} matching: {query}"

    lines: list[str] = []
    if summaries:
        lines.append(f"Found {len(results)} summary(ies) matching: {query}")
        lines.append("")
        for r in results:
            lvl = LEVEL_NAMES.get(r["level"], f"L{r['level']}")
            date_str = r["date"] or f"{r['date_start']} to {r['date_end']}"
            lines.append(f"  #{r['tap_id']}  {lvl:12s}  {date_str}  {r['title'][:50]}")
    else:
        lines.append(f"Found {len(results)} conversation(s) matching: {query}")
        lines.append("")
        for r in results:
            title = r["title"][:50] if r["title"] else "(no L0)"
            tap_label = f"tap_id={r['tap_id']}" if r["tap_id"] else "no L0"
            lines.append(f"  {r['date']}  {title:50s}  ({r['match_count']} hits, {tap_label})")
            if r.get("sample"):
                preview = r["sample"]["preview"][:100].replace("\n", " ")
                lines.append(f"           [{r['sample']['role'].upper()}] {preview}...")

    return _safe("\n".join(lines))


# ── recall ────────────────────────────────────────────────────────────


def fmt_recall(records: list[dict], date_str: str, end_date: str | None, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(records)
    if fmt == "jsonl":
        return _jsonl_dumps(records)

    if not records:
        if end_date:
            return f"No records found for {date_str} to {end_date}"
        return f"No records found for {date_str}"

    parts: list[str] = []
    for rec in records:
        parts.append(_fmt_record_text(rec))
    return _safe("\n\n".join(parts))


# ── show ──────────────────────────────────────────────────────────────


def fmt_show(record: dict | None, tap_id: int, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(record) if record else _json_dumps(None)
    if fmt == "jsonl":
        return json.dumps(record, default=str, ensure_ascii=True) if record else ""

    if not record:
        return f"No record with tap_id={tap_id}"
    return _safe(_fmt_record_text(record))


# ── context ───────────────────────────────────────────────────────────


def fmt_context(ctx_items: list[dict], repairs: list[dict], date_str: str, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps({"context": ctx_items, "repairs": repairs})
    if fmt == "jsonl":
        return _jsonl_dumps(ctx_items)

    lines: list[str] = []
    lines.append(f"Telescoping context for {date_str}")
    lines.append("=" * 60)

    by_level: dict[int, list[dict]] = {}
    for item in ctx_items:
        by_level.setdefault(item["level"], []).append(item)

    total_chars = 0
    for level in (4, 3, 2, 1, 0):
        items = by_level.get(level, [])
        if not items:
            continue
        name = LEVEL_NAMES.get(level, f"L{level}").upper()
        lines.append(f"\n  {name} ({len(items)}):")
        for item in items:
            chars = len(item["content"]) if item["content"] else 0
            total_chars += chars
            title = item["title"][:50] if item["title"] else "(untitled)"
            lines.append(f"    {item['range']:20s}  {title}  ({chars:,} chars)")

    lines.append(f"\n  TOTAL: {total_chars:,} chars (~{total_chars // 4:,} tokens)")

    if repairs:
        lines.append(f"\n  REPAIRS NEEDED ({len(repairs)}):")
        for r in repairs:
            lvl = LEVEL_NAMES.get(r["level"], f"L{r['level']}")
            lines.append(f"    {lvl} {r['range']}: {r['conv_count']} conversation(s)")

    return _safe("\n".join(lines))


# ── tree ──────────────────────────────────────────────────────────────


def fmt_tree(data: dict, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(data)
    if fmt == "jsonl":
        # flatten: one line per monthly
        return _jsonl_dumps(data.get("monthlies", []))

    lines: list[str] = []
    lines.append("Tapestry Hierarchy")
    lines.append("=" * 60)

    if not data["monthlies"] and not data["orphaned_weeklies"] and not data["orphaned_dailies"]:
        lines.append("\n  (empty)")
        return "\n".join(lines)

    for monthly in data["monthlies"]:
        title = monthly["title"][:50] if monthly["title"] else "(untitled)"
        lines.append(
            f"\n  Monthly: {title}  "
            f"({monthly['date_start']} to {monthly['date_end']}, "
            f"{monthly['content_len']:,} chars)"
        )
        for weekly in monthly["weeklies"]:
            w_title = weekly["title"][:45] if weekly["title"] else "(untitled)"
            lines.append(
                f"    Weekly: {w_title}  "
                f"({weekly['date_start']} to {weekly['date_end']}, "
                f"{weekly['content_len']:,} chars)"
            )
            for daily in weekly["dailies"]:
                d_title = daily["title"][:40] if daily["title"] else "(untitled)"
                lines.append(
                    f"      Daily: {daily['date']}  {d_title}  "
                    f"({daily['l0_count']} L0s, {daily['content_len']:,} chars)"
                )

    if data["orphaned_weeklies"]:
        lines.append(f"\n  Orphaned Weeklies ({len(data['orphaned_weeklies'])}):")
        for w in data["orphaned_weeklies"]:
            title = w["title"][:50] if w["title"] else "(untitled)"
            lines.append(f"    {w['date_start']} to {w['date_end']}  {title}")

    if data["orphaned_dailies"]:
        lines.append(f"\n  Orphaned Dailies ({len(data['orphaned_dailies'])}):")
        for d in data["orphaned_dailies"]:
            title = d["title"][:50] if d["title"] else "(untitled)"
            lines.append(f"    {d['date']}  {title}")

    return _safe("\n".join(lines))


# ── stats ─────────────────────────────────────────────────────────────


def fmt_stats(s: dict, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(s)
    if fmt == "jsonl":
        # one line per level
        records = [{"level": lvl, **info} for lvl, info in s["levels"].items()]
        return _jsonl_dumps(records)

    lines: list[str] = []
    lines.append("Tapestry Stats")
    lines.append("=" * 60)

    for level in range(5):
        info = s["levels"][level]
        name = f"L{level} ({info['name']})"
        avg = f"avg {info['avg_chars']:,}" if info["count"] > 0 else ""
        lines.append(f"  {name:22s}  {info['count']:5d} records  {info['chars']:>10,} chars  {avg}")

    lines.append("")
    lines.append(f"  {'Messages':22s}  {s['messages']:,} messages across {s['conversations']} conversations")
    lines.append(
        f"  {'Total':22s}  {s['total_records']:5d} records  "
        f"{s['total_chars']:>10,} chars  (~{s['est_tokens']:,} tokens)"
    )

    return "\n".join(lines)


# ── conversations ─────────────────────────────────────────────────────


def fmt_conversations(convs: list[dict], fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(convs)
    if fmt == "jsonl":
        return _jsonl_dumps(convs)

    if not convs:
        return "No conversations found."

    lines: list[str] = []
    lines.append(f"{'Conv ID':12s}  {'Agent':10s}  {'Msgs':>5s}  {'Date':10s}")
    lines.append("-" * 45)
    for c in convs:
        cid = c["conv_id"][:10] + ".." if len(c["conv_id"]) > 10 else c["conv_id"]
        lines.append(f"{cid:12s}  {c['agent']:10s}  {c['msg_count']:5d}  {c['date']}")
    lines.append(f"\n{len(convs)} conversation(s)")

    return "\n".join(lines)


# ── similar (cosine) ──────────────────────────────────────────────────


def fmt_similar(results: list[dict], query: str, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(results)
    if fmt == "jsonl":
        return _jsonl_dumps(results)

    # text
    if not results:
        return f"No similar records found for: {query}"

    lines: list[str] = []
    lines.append(f"Top {len(results)} result(s) similar to: {query}")
    lines.append("")
    for r in results:
        lvl = LEVEL_NAMES.get(r["level"], f"L{r['level']}")
        date_str = r["date"] or f"{r['date_start']} to {r['date_end']}"
        title = r["title"][:50] if r["title"] else "(untitled)"
        lines.append(f"  #{r['tap_id']}  {r['score']:.4f}  {lvl:12s}  {date_str}  {title}")

    return _safe("\n".join(lines))


# ── drift ─────────────────────────────────────────────────────────────


def fmt_drift(result: dict, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(result)
    if fmt == "jsonl":
        return _jsonl_dumps(result.get("ancestors", []))

    if "error" in result:
        return result["error"]

    lines: list[str] = []
    target = result["target"]
    lines.append(f"Drift Analysis for #{target['tap_id']} ({target['level_name']})")
    lines.append(f"  Title: {target['title']}")
    lines.append(f"  Date:  {target['date']}")
    lines.append("=" * 60)

    ancestors = result.get("ancestors", [])
    if not ancestors:
        lines.append("\n  No ancestors — drift cannot propagate.")
    else:
        lines.append(f"\n  {'Level':<16s}  {'Score':>6s}  {'Severity':<12s}  {'Current':>8s}  {'Regen':>8s}  tap_id")
        lines.append("  " + "-" * 68)
        for a in ancestors:
            lines.append(
                f"  {a['level_name']:<16s}  {a['score']:>6.4f}  {a['severity']:<12s}  "
                f"{a['chars_current']:>7,}c  {a['chars_regen']:>7,}c  #{a['tap_id']}"
            )

    lines.append("")
    lines.append(f"  {result['description']}")

    return _safe("\n".join(lines))


# ── fulltext (unified) ────────────────────────────────────────────────


def fmt_fulltext(results: list[dict], query: str, mode: str, fmt: str) -> str:
    if fmt == "json":
        return _json_dumps(results)
    if fmt == "jsonl":
        return _jsonl_dumps(results)

    if not results:
        return f"No results for: {query} (mode: {mode})"

    lines: list[str] = []
    lines.append(f"Search ({mode}): '{query}' -- {len(results)} result(s)")
    lines.append("")
    for r in results:
        lvl = LEVEL_NAMES.get(r.get("level"), f"L{r.get('level', '?')}")
        date_str = r.get("date") or f"{r.get('date_start', '?')} to {r.get('date_end', '?')}"
        title = (r.get("title") or "(untitled)")[:50]
        score = r.get("score") or 0
        source = r.get("source", "?")
        tap_id = r.get("tap_id", "?")

        lines.append(f"  #{tap_id}  {score:.4f}  {lvl:12s}  {date_str}  {title}")
        lines.append(f"         [{source}]")
        if r.get("preview"):
            preview = str(r["preview"])[:120].replace("\n", " ")
            lines.append(f"         {preview}...")

    return _safe("\n".join(lines))


# ── record helper ─────────────────────────────────────────────────────


def _fmt_record_text(rec: dict) -> str:
    """Format a single tapestry record as text."""
    level = rec.get("tap_level", "?")
    name = LEVEL_NAMES.get(level, f"L{level}")
    tap_id = rec.get("tap_id", "?")

    lines: list[str] = []
    lines.append(f"tap_id={tap_id}  L{level} ({name})")
    lines.append("--")
    lines.append(f"  Title:  {rec.get('tap_title', '(none)')}")

    if rec.get("tap_date"):
        lines.append(f"  Date:   {rec['tap_date']}")
    elif rec.get("tap_date_start"):
        lines.append(f"  Range:  {rec['tap_date_start']} to {rec['tap_date_end']}")

    if rec.get("tap_parent_id"):
        lines.append(f"  Parent: tap_id={rec['tap_parent_id']}")

    content = rec.get("tap_content", "")
    chars = len(content) if content else 0
    lines.append(f"  Size:   {chars:,} chars (~{chars // 4:,} tokens)")
    lines.append("")
    if content:
        lines.append(content)

    return "\n".join(lines)
