"""Parser for historical Uni SQLite databases.

Reads conversation data from various Uni-era databases, handling
multiple schema variants:
  - llm_messages: sum_id/sum_ref_id grouping (uni-app/uni-foxtrot.db)
  - messages with sum_id: conversation grouping (uni-app, uni-vid, unibot)
  - messages with conv_id: old_uni/groq.db
  - messages without grouping: single-conversation DBs (school, ai-project-117)

When a database contains multiple conversation tables (e.g., both
llm_messages and messages), all tables are read and combined.
"""

from __future__ import annotations

import os
import sqlite3

from tapestry.parsers.base import BaseParser, ParsedMessage

# Tables that contain conversation data, in order of preference
CONVERSATION_TABLES = ["llm_messages", "messages"]


class UniParser(BaseParser):
    """Parser for Uni historical SQLite databases."""

    name = "uni"

    def __init__(self, table: str = ""):
        """Initialize with optional table override.

        Args:
            table: Force a specific table name. If empty, reads all
                   conversation tables found in the database.
        """
        self.table = table

    def parse(self, filepath: str) -> list[ParsedMessage]:
        """Parse a Uni SQLite database and return messages."""
        conn = sqlite3.connect(f"file:{filepath}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row

        if self.table:
            tables = [self.table] if self.table in self._list_tables(conn) else []
        else:
            tables = self._detect_tables(conn)

        if not tables:
            conn.close()
            return []

        messages = []
        for table in tables:
            columns = self._get_columns(conn, table)
            messages.extend(self._extract_messages(conn, table, columns, filepath))

        conn.close()
        return messages

    @classmethod
    def can_handle(cls, filepath: str) -> bool:
        """Return True for .db files containing Uni message tables."""
        if not filepath.endswith(".db"):
            return False
        try:
            conn = sqlite3.connect(f"file:{filepath}?mode=ro", uri=True)
            tables = cls._list_tables(conn)
            conn.close()
            return bool(tables & set(CONVERSATION_TABLES))
        except Exception:
            return False

    @staticmethod
    def _list_tables(conn: sqlite3.Connection) -> set[str]:
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        return {r[0] for r in cursor.fetchall()}

    def _detect_tables(self, conn: sqlite3.Connection) -> list[str]:
        """Find all conversation tables with data."""
        db_tables = self._list_tables(conn)
        found = []
        for table in CONVERSATION_TABLES:
            if table in db_tables:
                count = conn.execute(
                    f"SELECT COUNT(*) FROM [{table}]"
                ).fetchone()[0]
                if count > 0:
                    found.append(table)
        return found

    @staticmethod
    def _get_columns(conn: sqlite3.Connection, table: str) -> set[str]:
        cursor = conn.execute(f"PRAGMA table_info([{table}])")
        return {r[1] for r in cursor.fetchall()}

    def _extract_messages(
        self,
        conn: sqlite3.Connection,
        table: str,
        columns: set[str],
        filepath: str,
    ) -> list[ParsedMessage]:
        """Query and convert messages to ParsedMessage objects."""
        db_name = os.path.splitext(os.path.basename(filepath))[0]

        # Determine grouping column
        if "sum_id" in columns:
            group_col = "sum_id"
        elif "conv_id" in columns:
            group_col = "conv_id"
        else:
            group_col = None

        # Determine UUID column
        uuid_col = "msg_ref_id" if "msg_ref_id" in columns else None

        # Build SELECT
        select_cols = ["msg_role", "msg_content", "msg_created"]
        if group_col:
            select_cols.append(group_col)
        if uuid_col:
            select_cols.append(uuid_col)

        query = f"SELECT {', '.join(select_cols)} FROM [{table}] ORDER BY msg_id"
        rows = conn.execute(query).fetchall()

        messages = []
        for row in rows:
            role = row["msg_role"]
            content = row["msg_content"]

            # Skip empty messages
            if not content or not content.strip():
                continue
            # Keep user and assistant roles only
            if role not in ("user", "assistant"):
                continue

            # Build conversation ID
            if group_col:
                group_val = row[group_col]
                conv_id = f"{db_name}:{table}:{group_val}"
            else:
                conv_id = f"{db_name}:{table}"

            uuid = row[uuid_col] if uuid_col else ""
            timestamp = row["msg_created"] or ""

            messages.append(ParsedMessage(
                role=role,
                content=content,
                uuid=uuid,
                conversation_id=conv_id,
                timestamp=str(timestamp),
            ))

        return messages
