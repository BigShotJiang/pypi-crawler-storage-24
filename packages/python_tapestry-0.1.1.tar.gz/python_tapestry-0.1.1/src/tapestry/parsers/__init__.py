"""Conversation parsers with auto-detection."""

from __future__ import annotations

from tapestry.parsers.anthropic import AnthropicParser
from tapestry.parsers.base import BaseParser, ParsedMessage
from tapestry.parsers.chatgpt import ChatGPTParser
from tapestry.parsers.claude_code import ClaudeCodeParser
from tapestry.parsers.generic import GenericParser
from tapestry.parsers.uni import UniParser

# Registry of all available parsers, keyed by name.
PARSERS: dict[str, type[BaseParser]] = {
    "anthropic": AnthropicParser,
    "chatgpt": ChatGPTParser,
    "claude-code": ClaudeCodeParser,
    "generic": GenericParser,
    "uni": UniParser,
}


def get_parser(name: str) -> BaseParser:
    """Get a parser instance by name.

    Args:
        name: Parser name (e.g., "claude-code", "generic").

    Returns:
        Parser instance.

    Raises:
        ValueError: If parser name is not registered.
    """
    cls = PARSERS.get(name)
    if cls is None:
        available = ", ".join(sorted(PARSERS))
        raise ValueError(f"Unknown parser: {name!r}. Available: {available}")
    return cls()


def detect_parser(filepath: str) -> BaseParser | None:
    """Auto-detect the appropriate parser for a file.

    Tries each registered parser's can_handle() method.

    Returns:
        Parser instance, or None if no parser matches.
    """
    for cls in PARSERS.values():
        if cls.can_handle(filepath):
            return cls()
    return None


__all__ = [
    "AnthropicParser",
    "BaseParser",
    "ParsedMessage",
    "ChatGPTParser",
    "ClaudeCodeParser",
    "GenericParser",
    "UniParser",
    "PARSERS",
    "get_parser",
    "detect_parser",
]
