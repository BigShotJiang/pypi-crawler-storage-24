"""Parser for generic JSON conversation exports.

Expected format: a JSON array of objects with at minimum
`role` and `content` fields. Optional: `uuid`, `conversation_id`,
`timestamp`.

Example:
[
    {"role": "user", "content": "Hello", "timestamp": "2026-01-01T10:00:00Z"},
    {"role": "assistant", "content": "Hi there!", "timestamp": "2026-01-01T10:00:05Z"}
]
"""

from __future__ import annotations

import json

from tapestry.parsers.base import BaseParser, ParsedMessage


class GenericParser(BaseParser):
    """Parses simple JSON array conversation files."""

    name = "generic"

    def parse(self, filepath: str) -> list[ParsedMessage]:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            return []

        messages: list[ParsedMessage] = []
        for i, entry in enumerate(data):
            if not isinstance(entry, dict):
                continue
            role = entry.get("role", "")
            content = entry.get("content", "")
            if role not in ("user", "assistant") or not content:
                continue

            messages.append(
                ParsedMessage(
                    role=role,
                    content=content.strip(),
                    uuid=entry.get("uuid", ""),
                    conversation_id=entry.get("conversation_id", ""),
                    timestamp=entry.get("timestamp", ""),
                )
            )
        return messages

    @classmethod
    def can_handle(cls, filepath: str) -> bool:
        """Check if file is a JSON array of role/content objects."""
        if not filepath.endswith(".json"):
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list) or not data:
                return False
            first = data[0]
            return isinstance(first, dict) and "role" in first and "content" in first
        except (json.JSONDecodeError, OSError):
            return False
