"""Parser for Claude Code JSONL conversation exports."""

from __future__ import annotations

import json

from tapestry.parsers.base import BaseParser, ParsedMessage


class ClaudeCodeParser(BaseParser):
    """Parses Claude Code VSCode extension JSONL files.

    Each line is a JSON object with type, message.content, uuid,
    sessionId, and timestamp fields.
    """

    name = "claude-code"

    def parse(self, filepath: str) -> list[ParsedMessage]:
        messages: list[ParsedMessage] = []
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg_type = obj.get("type", "")
                if msg_type not in ("user", "assistant"):
                    continue

                msg = obj.get("message", {})
                content = msg.get("content", "")
                text = _extract_text(content)
                if not text:
                    continue

                messages.append(
                    ParsedMessage(
                        role=msg_type,
                        content=text,
                        uuid=obj.get("uuid", ""),
                        conversation_id=obj.get("sessionId", ""),
                        timestamp=obj.get("timestamp", ""),
                    )
                )
        return messages

    @classmethod
    def can_handle(cls, filepath: str) -> bool:
        """Check if file is JSONL with Claude Code structure."""
        if not filepath.endswith(".jsonl"):
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                first_line = f.readline().strip()
                if not first_line:
                    return False
                obj = json.loads(first_line)
                return "type" in obj and "message" in obj
        except (json.JSONDecodeError, OSError):
            return False


def _extract_text(content: object) -> str:
    """Extract readable text from message content (string or block list)."""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                text = block.get("text", "").strip()
                if text:
                    parts.append(text)
        return "\n".join(parts)
    return ""
