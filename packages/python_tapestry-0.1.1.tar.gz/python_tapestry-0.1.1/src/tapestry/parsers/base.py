"""Base parser interface for conversation imports."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ParsedMessage:
    """A single extracted message from a conversation."""

    role: str  # "user" or "assistant"
    content: str
    uuid: str = ""
    conversation_id: str = ""
    timestamp: str = ""


class BaseParser(ABC):
    """Abstract base for conversation file parsers.

    Each parser knows how to read one export format and yield
    a list of ParsedMessage objects.
    """

    name: str = ""

    @abstractmethod
    def parse(self, filepath: str) -> list[ParsedMessage]:
        """Parse a conversation file and return messages.

        Args:
            filepath: Path to the conversation export file.

        Returns:
            List of ParsedMessage in chronological order.
        """

    @classmethod
    def can_handle(cls, filepath: str) -> bool:
        """Return True if this parser can likely handle the given file.

        Used by auto-detect. Default implementation returns False.
        Subclasses should override with format-specific checks.
        """
        return False
