"""Parser for Anthropic (claude.ai) conversation exports.

Expected format: a JSON array of conversation objects, each with a
``chat_messages`` list of message dicts in chronological order.

Only ``human`` and ``assistant`` messages with text content are kept.
Thinking blocks (``type: "thinking"``) are skipped.
"""

from __future__ import annotations

import json

from tapestry.parsers.base import BaseParser, ParsedMessage


class AnthropicParser(BaseParser):
    """Parses the Anthropic ``conversations.json`` export file.

    One file contains many conversations.  ``parse()`` returns a flat
    list of :class:`ParsedMessage` objects -- each carries its own
    ``conversation_id`` so the caller can group them.
    """

    name = "anthropic"

    def parse(self, filepath: str) -> list[ParsedMessage]:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            return []

        messages: list[ParsedMessage] = []
        for conv in data:
            messages.extend(_parse_conversation(conv))
        return messages

    @classmethod
    def can_handle(cls, filepath: str) -> bool:
        """Check if file is an Anthropic conversations export."""
        if not filepath.endswith(".json"):
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                chunk = f.read(4096)
            chunk = chunk.lstrip()
            if not chunk.startswith("["):
                return False
            # Anthropic exports have chat_messages and sender fields,
            # no mapping (that's ChatGPT)
            return '"chat_messages"' in chunk and '"sender"' in chunk
        except OSError:
            return False


def _parse_conversation(conv: dict) -> list[ParsedMessage]:
    """Extract messages from one Anthropic conversation."""
    conv_id = conv.get("uuid", "")
    chat_messages = conv.get("chat_messages")
    if not chat_messages:
        return []

    messages: list[ParsedMessage] = []
    for msg in chat_messages:
        parsed = _extract_message(msg, conv_id)
        if parsed:
            messages.append(parsed)
    return messages


def _extract_message(msg: dict, conv_id: str) -> ParsedMessage | None:
    """Turn an Anthropic message dict into a ParsedMessage, or None."""
    sender = msg.get("sender", "")
    if sender == "human":
        role = "user"
    elif sender == "assistant":
        role = "assistant"
    else:
        return None

    # Extract text from content blocks, skipping thinking blocks
    text = _extract_text_content(msg)
    if not text:
        return None

    # Timestamps are already ISO 8601; use the first content block's
    # start_timestamp, falling back to stop_timestamp
    timestamp = _extract_timestamp(msg)

    return ParsedMessage(
        role=role,
        content=text,
        uuid=msg.get("uuid", ""),
        conversation_id=conv_id,
        timestamp=timestamp,
    )


def _extract_text_content(msg: dict) -> str:
    """Join text content blocks, skipping thinking blocks."""
    # The top-level "text" field is a convenience duplicate;
    # use the structured content array for precision.
    content_blocks = msg.get("content", [])
    if not content_blocks:
        # Fall back to top-level text field
        text = msg.get("text", "")
        return text.strip() if isinstance(text, str) else ""

    texts = []
    for block in content_blocks:
        if not isinstance(block, dict):
            continue
        block_type = block.get("type", "")
        if block_type == "thinking":
            continue
        text = block.get("text", "")
        if isinstance(text, str) and text.strip():
            texts.append(text.strip())
    return "\n".join(texts)


def _extract_timestamp(msg: dict) -> str:
    """Get the best available timestamp from a message."""
    content_blocks = msg.get("content", [])
    for block in content_blocks:
        if not isinstance(block, dict):
            continue
        ts = block.get("start_timestamp") or block.get("stop_timestamp")
        if ts:
            return ts
    return ""
