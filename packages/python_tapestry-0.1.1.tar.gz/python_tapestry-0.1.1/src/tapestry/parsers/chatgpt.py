"""Parser for ChatGPT conversation exports.

Expected format: a JSON array of conversation objects, each with a
``mapping`` dict of message nodes connected by ``parent``/``children``
pointers.  We walk the tree from root to ``current_node`` to reconstruct
the linear message thread.

Only ``user`` and ``assistant`` messages with text content are kept.
System nodes, tool calls, images, and ``user_editable_context`` entries
are skipped.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from tapestry.parsers.base import BaseParser, ParsedMessage


class ChatGPTParser(BaseParser):
    """Parses the ChatGPT ``conversations.json`` export file.

    One file contains many conversations.  ``parse()`` returns a flat
    list of :class:`ParsedMessage` objects — each carries its own
    ``conversation_id`` so the caller can group them.
    """

    name = "chatgpt"

    def parse(self, filepath: str) -> list[ParsedMessage]:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            return []

        messages: list[ParsedMessage] = []
        for conv in data:
            messages.extend(self._parse_conversation(conv))
        return messages

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_conversation(conv: dict) -> list[ParsedMessage]:
        """Extract the linear message thread from one conversation."""
        mapping = conv.get("mapping")
        if not mapping:
            return []

        conv_id = conv.get("conversation_id", "")

        # Build the linear path by walking children from the root.
        # The root node has parent=None (or parent not in mapping).
        root_ids = [
            nid for nid, node in mapping.items()
            if node.get("parent") is None
        ]
        if not root_ids:
            return []

        # Walk depth-first, always following the *last* child
        # (ChatGPT trees branch on edits; last child = latest edit).
        messages: list[ParsedMessage] = []
        current = root_ids[0]
        while current:
            node = mapping.get(current)
            if not node:
                break
            msg = node.get("message")
            if msg:
                parsed = _extract_message(msg, conv_id)
                if parsed:
                    messages.append(parsed)
            children = node.get("children", [])
            current = children[-1] if children else None

        return messages

    @classmethod
    def can_handle(cls, filepath: str) -> bool:
        """Check if file is a ChatGPT conversations export."""
        if not filepath.endswith(".json"):
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                # Read just enough to detect the format without loading 185MB
                chunk = f.read(4096)
            # Must start with [ (JSON array) and contain ChatGPT markers
            chunk = chunk.lstrip()
            if not chunk.startswith("["):
                return False
            return '"mapping"' in chunk and '"conversation_id"' in chunk
        except OSError:
            return False


def _extract_message(msg: dict, conv_id: str) -> ParsedMessage | None:
    """Turn a ChatGPT message node into a ParsedMessage, or None."""
    author = msg.get("author", {})
    role = author.get("role", "")
    if role not in ("user", "assistant"):
        return None

    content = msg.get("content", {})
    content_type = content.get("content_type", "")

    # Skip non-text content types (user_editable_context, etc.)
    if content_type not in ("text", "multimodal_text"):
        return None

    parts = content.get("parts", [])
    text = _extract_text_parts(parts)
    if not text:
        return None

    # Timestamp: unix float → ISO 8601
    ts_raw = msg.get("create_time")
    timestamp = ""
    if ts_raw:
        try:
            dt = datetime.fromtimestamp(float(ts_raw), tz=timezone.utc)
            timestamp = dt.isoformat()
        except (ValueError, TypeError, OSError):
            pass

    return ParsedMessage(
        role=role,
        content=text,
        uuid=msg.get("id", ""),
        conversation_id=conv_id,
        timestamp=timestamp,
    )


def _extract_text_parts(parts: list) -> str:
    """Join text-only parts, skipping images/videos/dicts."""
    texts = []
    for part in parts:
        if isinstance(part, str):
            stripped = part.strip()
            if stripped:
                texts.append(stripped)
        elif isinstance(part, dict):
            # multimodal_text dict parts may have a "text" key
            if part.get("content_type") == "text" or "text" in part:
                t = part.get("text", "")
                if isinstance(t, str) and t.strip():
                    texts.append(t.strip())
    return "\n".join(texts)
