"""Tests for the tapestry web calendar UI routes."""

import io
import json
import zipfile

import pytest

from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.web import create_app


# ── Fixtures ──────────────────────────────────────────────────────


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "tapestry.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


@pytest.fixture
def tapestry_obj(db, tmp_path):
    """Minimal Tapestry-like object with .db attribute."""

    class FakeTapestry:
        def __init__(self, database):
            self.db = database

        def show(self, tap_id):
            row = db.sql(
                "SELECT * FROM tapestry WHERE tap_id = ?",
                (tap_id,), single=True,
            )
            return dict(row) if row else None

        def ingest(self, path, agent=None, parser_name=None):
            return {"conversations": 0, "skipped": 0, "messages": 0}

    return FakeTapestry(db)


@pytest.fixture
def client(tapestry_obj):
    app = create_app(tapestry_obj)
    app.config['TESTING'] = True
    with app.test_client() as c:
        yield c


def _ensure_agent(db, agent_name):
    """Ensure agent exists in tapestry_agents and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent_name,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent_name,), single=True)
    return row["agent_id"]


def _tap(db, agent, level, title, content, tap_date=None,
         date_start=None, date_end=None, source=None, parent_id=None):
    """Insert a tapestry record and return tap_id."""
    agent_id = _ensure_agent(db, agent)
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date,
            tap_date_start, tap_date_end, tap_source, tap_parent_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, level, title, content, tap_date,
         date_start, date_end, source, parent_id),
    )


def _seed(db):
    """Seed a small hierarchy for testing."""
    _tap(db, "test-agent", 0, "Built search", "Worked on search feature.",
         tap_date="2026-03-01", source="conv-a")
    _tap(db, "test-agent", 0, "Fixed bugs", "Debugged the parser.",
         tap_date="2026-03-01", source="conv-b")
    _tap(db, "test-agent", 1, "Daily March 1", "Summary of March 1 work.",
         tap_date="2026-03-01")
    _tap(db, "test-agent", 2, "Weekly Feb 24-Mar 2", "Weekly rollup.",
         date_start="2026-02-24", date_end="2026-03-02")
    _tap(db, "test-agent", 3, "Monthly March", "Monthly rollup.",
         date_start="2026-03-01", date_end="2026-03-31")


# ── Root Redirect ─────────────────────────────────────────────────


def test_root_redirects_to_calendar(client):
    resp = client.get('/')
    assert resp.status_code == 302
    assert '/cal/' in resp.headers['Location']


# ── Index ─────────────────────────────────────────────────────────


def test_index_empty_db(client):
    resp = client.get('/cal/')
    assert resp.status_code == 200
    assert b'calendar-grid' in resp.data


def test_index_with_data(client, db):
    _seed(db)
    resp = client.get('/cal/')
    assert resp.status_code == 200
    assert b'calendar-grid' in resp.data
    assert b'agent-list' in resp.data


def test_index_agent_filter(client, db):
    _seed(db)
    resp = client.get('/cal/?agent=test-agent')
    assert resp.status_code == 200


# ── Grid ──────────────────────────────────────────────────────────


def test_grid_returns_dispatch_json(client, db):
    _seed(db)
    resp = client.post('/cal/grid/2026/3', data={'agent': ''})
    assert resp.status_code == 200
    data = resp.get_json()
    assert '#calendar-grid' in data['htmls']
    assert '#month-label' in data['htmls']
    assert 'March' in data['htmls']['#month-label']
    assert data['values']['#nav-year'] == '2026'
    assert data['values']['#nav-month'] == '3'


def test_grid_with_agent_filter(client, db):
    _seed(db)
    resp = client.post('/cal/grid/2026/3', data={'agent': 'test-agent'})
    assert resp.status_code == 200
    data = resp.get_json()
    assert '#calendar-grid' in data['htmls']


def test_grid_empty_month(client, db):
    resp = client.post('/cal/grid/2025/1', data={'agent': ''})
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'January' in data['htmls']['#month-label']


# ── Day Detail ────────────────────────────────────────────────────


def test_day_detail_with_data(client, db):
    _seed(db)
    resp = client.post('/cal/day/2026-03-01', data={'agent': ''})
    assert resp.status_code == 200
    data = resp.get_json()
    assert '#day-detail' in data['htmls']
    assert 'Built search' in data['htmls']['#day-detail']


def test_day_detail_empty_day(client, db):
    resp = client.post('/cal/day/2025-01-15', data={'agent': ''})
    assert resp.status_code == 200
    data = resp.get_json()
    assert '#day-detail' in data['htmls']


def test_day_detail_agent_filter(client, db):
    _seed(db)
    resp = client.post('/cal/day/2026-03-01', data={'agent': 'test-agent'})
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'Built search' in data['htmls']['#day-detail']


# ── Record Modal ──────────────────────────────────────────────────


def test_record_found(client, db):
    tap_id = _tap(db, "test-agent", 0, "Test Record", "Full content here.",
                  tap_date="2026-03-01", source="conv-x")
    resp = client.post(f'/cal/record/{tap_id}')
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'vbox' in data
    assert 'Test Record' in data['vbox']
    assert 'Full content here.' in data['vbox']


def test_record_not_found(client, db):
    resp = client.post('/cal/record/99999')
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'alert' in data
    alert = json.loads(data['alert'])
    assert alert['type'] == 'error'


# ── Upload Modal ──────────────────────────────────────────────────


def test_upload_modal(client, db):
    _seed(db)
    resp = client.post('/cal/upload-modal')
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'vbox' in data
    assert 'upload' in data['vbox'].lower() or 'drop' in data['vbox'].lower()


# ── Upload ────────────────────────────────────────────────────────


def test_upload_no_file(client):
    resp = client.post('/cal/upload', data={})
    assert resp.status_code == 200
    data = resp.get_json()
    alert = json.loads(data['alert'])
    assert alert['type'] == 'error'
    assert 'No file' in alert['message']


def test_upload_json_file(client):
    """Upload a simple JSON file — FakeTapestry.ingest returns zeros."""
    data = {
        'upl': (io.BytesIO(b'[]'), 'conversations.json'),
        'agent': 'test',
        'parser': 'generic',
    }
    resp = client.post('/cal/upload', data=data, content_type='multipart/form-data')
    assert resp.status_code == 200
    result = resp.get_json()
    assert 'vboxclose' in result
    alert = json.loads(result['alert'])
    assert alert['type'] == 'success'
    assert 'Imported' in alert['message']


def test_upload_zip_file(client):
    """Upload a zip containing a JSON file."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as zf:
        zf.writestr('conversations.json', '[]')
    buf.seek(0)

    data = {
        'upl': (buf, 'export.zip'),
        'agent': 'test',
        'parser': 'generic',
    }
    resp = client.post('/cal/upload', data=data, content_type='multipart/form-data')
    assert resp.status_code == 200
    result = resp.get_json()
    assert 'vboxclose' in result
    alert = json.loads(result['alert'])
    assert alert['type'] == 'success'


def test_upload_anthropic_zip(client):
    """Upload an Anthropic-style zip with conversations.json + metadata files.
    Should target conversations.json only, not users.json/projects.json."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as zf:
        zf.writestr('conversations.json', '[]')
        zf.writestr('users.json', '[{"name": "George"}]')
        zf.writestr('projects.json', '[]')
        zf.writestr('memories.json', '[]')
    buf.seek(0)

    data = {
        'upl': (buf, 'data-2026-03-04-batch-0000.zip'),
        'agent': 'anthropic',
        'parser': 'anthropic',
    }
    resp = client.post('/cal/upload', data=data, content_type='multipart/form-data')
    assert resp.status_code == 200
    result = resp.get_json()
    assert 'vboxclose' in result
    alert = json.loads(result['alert'])
    assert alert['type'] == 'success'


def test_upload_zip_no_json(client):
    """Upload a zip with no JSON files."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as zf:
        zf.writestr('readme.txt', 'nothing here')
    buf.seek(0)

    data = {
        'upl': (buf, 'empty.zip'),
    }
    resp = client.post('/cal/upload', data=data, content_type='multipart/form-data')
    assert resp.status_code == 200
    result = resp.get_json()
    alert = json.loads(result['alert'])
    assert alert['type'] == 'error'
    assert 'No .json' in alert['message']


# ── Agents Modal ──────────────────────────────────────────────────


def test_agents_modal(client, db):
    _seed(db)
    resp = client.post('/cal/agents-modal')
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'vbox' in data
    assert 'test-agent' in data['vbox']


def test_agents_modal_empty(client):
    resp = client.post('/cal/agents-modal')
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'vbox' in data
    assert 'No agents found' in data['vbox']


# ── Agent Color ───────────────────────────────────────────────────


def test_agent_color_update(client, db):
    _seed(db)
    resp = client.post('/cal/agent-color', data={
        'agent': 'test-agent',
        'color': '#FF0000',
        'year': '2026',
        'month': '3',
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert 'vboxclose' in data
    assert '#agent-list' in data['htmls']
    assert '#calendar-grid' in data['htmls']

    # Verify color was persisted in tapestry_agents
    row = db.sql(
        "SELECT agent_color FROM tapestry_agents WHERE agent_name = ?",
        ("test-agent",), single=True,
    )
    assert row['agent_color'] == '#FF0000'


def test_agent_color_refreshes_grid(client, db):
    _seed(db)
    resp = client.post('/cal/agent-color', data={
        'agent': 'test-agent',
        'color': '#00FF00',
        'year': '2026',
        'month': '3',
        'selected_agent': 'test-agent',
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert '#calendar-grid' in data['htmls']


# ── Helpers ───────────────────────────────────────────────────────


def test_content_to_html():
    from tapestry.web.routes import _content_to_html

    assert _content_to_html('') == ''
    assert '<strong>bold</strong>' in _content_to_html('**bold**')
    assert '<h2' in _content_to_html('## Heading')
    assert '<h3' in _content_to_html('### Subheading')
    assert '<p>' in _content_to_html('A paragraph.')
    # Markdown table rendering
    table_md = '| Col1 | Col2 |\n|------|------|\n| a | b |'
    table_html = _content_to_html(table_md)
    assert '<table' in table_html
    assert '<th' in table_html
    # Code fence rendering
    code_md = '```python\nprint("hello")\n```'
    code_html = _content_to_html(code_md)
    assert '<code' in code_html
