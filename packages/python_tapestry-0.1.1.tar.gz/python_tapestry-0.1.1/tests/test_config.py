"""Tests for the configuration system."""

from pathlib import Path

from tapestry.config import (
    AgentConfig,
    LLMConfig,
    TapestryConfig,
    find_config_file,
    load_config,
    write_config,
)


def test_default_config():
    """Default config has sensible values."""
    config = TapestryConfig()
    assert config.db_path == "db/tapestry.db"
    assert config.llm.provider == "groq"
    assert config.first_day_of_week == "monday"
    assert config.exclude_today is True


def test_write_and_load_config(tmp_path):
    """Write config to TOML and load it back."""
    config = TapestryConfig(
        db_path="db/tapestry.db",
        project_dir=str(tmp_path),
        llm=LLMConfig(provider="openai", api_url="https://api.openai.com/v1/chat/completions"),
        agents={"john": AgentConfig(parser="claude-code", conversations_dir="/some/path")},
    )

    toml_path = write_config(config, str(tmp_path / "tapestry.toml"))
    assert toml_path.exists()

    # Load it back
    loaded = load_config(str(toml_path))
    assert loaded.llm.provider == "openai"
    assert "john" in loaded.agents
    assert loaded.agents["john"].parser == "claude-code"
    assert loaded.agents["john"].conversations_dir == "/some/path"


def test_find_config_file(tmp_path):
    """Finds tapestry.toml in parent directory."""
    # Create config in parent
    (tmp_path / "tapestry.toml").write_text('[tapestry]\ndb_path = "db/test.db"\n')

    # Search from child directory
    child = tmp_path / "subdir" / "deep"
    child.mkdir(parents=True)

    found = find_config_file(str(child))
    assert found is not None
    assert found == tmp_path / "tapestry.toml"


def test_find_config_file_not_found(tmp_path):
    """Returns None when no config found."""
    found = find_config_file(str(tmp_path))
    # May or may not find one depending on system — just check it doesn't crash
    # In a clean tmp_path with no tapestry.toml up the tree, should be None
    # But we can't guarantee nothing exists above tmp_path


def test_env_loading(tmp_path):
    """API key loaded from .env file."""
    (tmp_path / "tapestry.toml").write_text('[tapestry]\ndb_path = "db/test.db"\n')
    (tmp_path / ".env").write_text("TAPESTRY_API_KEY=test-secret-key\n")

    config = load_config(str(tmp_path / "tapestry.toml"))
    assert config.llm.api_key == "test-secret-key"


def test_default_agent_created(tmp_path, monkeypatch):
    """Config without agents gets a default agent."""
    monkeypatch.chdir(tmp_path)
    config = load_config()  # No toml file, uses defaults
    assert "default" in config.agents


def test_overrides():
    """Keyword overrides are applied."""
    config = load_config(db_path="/custom/path.db")
    assert config.db_path == "/custom/path.db"
