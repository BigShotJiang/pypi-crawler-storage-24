"""Tests for tapestry.parsers module."""

import json
import os

import pytest

from tapestry.parsers import detect_parser, get_parser, PARSERS
from tapestry.parsers.anthropic import AnthropicParser, _extract_text_content
from tapestry.parsers.chatgpt import ChatGPTParser, _extract_text_parts
from tapestry.parsers.claude_code import ClaudeCodeParser, _extract_text
from tapestry.parsers.generic import GenericParser


class TestExtractText:
    def test_string_content(self):
        assert _extract_text("hello world") == "hello world"

    def test_block_list(self):
        blocks = [
            {"type": "text", "text": "Part 1"},
            {"type": "tool_use", "name": "bash"},
            {"type": "text", "text": "Part 2"},
        ]
        assert _extract_text(blocks) == "Part 1\nPart 2"

    def test_empty_blocks(self):
        assert _extract_text([{"type": "tool_use"}]) == ""

    def test_none(self):
        assert _extract_text(None) == ""

    def test_empty_string(self):
        assert _extract_text("  ") == ""


class TestClaudeCodeParser:
    @pytest.fixture
    def sample_jsonl(self, tmp_path):
        filepath = tmp_path / "conv.jsonl"
        lines = [
            {"type": "user", "message": {"content": "Hello"}, "uuid": "u1",
             "sessionId": "sess1", "timestamp": "2026-01-01T10:00:00Z"},
            {"type": "assistant", "message": {"content": "Hi there!"},
             "uuid": "u2", "sessionId": "sess1", "timestamp": "2026-01-01T10:00:05Z"},
            {"type": "tool_use", "message": {"content": "..."}, "uuid": "u3",
             "sessionId": "sess1", "timestamp": "2026-01-01T10:00:03Z"},
            {"type": "user", "message": {"content": [
                {"type": "text", "text": "Block content"}
            ]}, "uuid": "u4", "sessionId": "sess1", "timestamp": "2026-01-01T10:00:10Z"},
        ]
        with open(filepath, "w") as f:
            for obj in lines:
                f.write(json.dumps(obj) + "\n")
        return str(filepath)

    def test_parse_basic(self, sample_jsonl):
        parser = ClaudeCodeParser()
        messages = parser.parse(sample_jsonl)
        assert len(messages) == 3  # user, assistant, user (block content)
        assert messages[0].role == "user"
        assert messages[0].content == "Hello"
        assert messages[0].conversation_id == "sess1"
        assert messages[1].role == "assistant"
        assert messages[1].content == "Hi there!"
        assert messages[2].content == "Block content"

    def test_can_handle_jsonl(self, sample_jsonl):
        assert ClaudeCodeParser.can_handle(sample_jsonl) is True

    def test_can_handle_wrong_ext(self, tmp_path):
        filepath = tmp_path / "data.json"
        filepath.write_text('{"type": "user"}')
        assert ClaudeCodeParser.can_handle(str(filepath)) is False

    def test_empty_file(self, tmp_path):
        filepath = tmp_path / "empty.jsonl"
        filepath.write_text("")
        parser = ClaudeCodeParser()
        assert parser.parse(str(filepath)) == []

    def test_skips_empty_content(self, tmp_path):
        filepath = tmp_path / "conv.jsonl"
        line = {"type": "user", "message": {"content": ""}, "uuid": "u1",
                "sessionId": "s1", "timestamp": ""}
        filepath.write_text(json.dumps(line) + "\n")
        parser = ClaudeCodeParser()
        assert parser.parse(str(filepath)) == []


class TestGenericParser:
    @pytest.fixture
    def sample_json(self, tmp_path):
        filepath = tmp_path / "conv.json"
        data = [
            {"role": "user", "content": "Question?", "timestamp": "2026-01-01T10:00:00Z"},
            {"role": "assistant", "content": "Answer.", "timestamp": "2026-01-01T10:00:05Z"},
        ]
        filepath.write_text(json.dumps(data))
        return str(filepath)

    def test_parse_basic(self, sample_json):
        parser = GenericParser()
        messages = parser.parse(sample_json)
        assert len(messages) == 2
        assert messages[0].role == "user"
        assert messages[0].content == "Question?"
        assert messages[1].role == "assistant"

    def test_can_handle_json(self, sample_json):
        assert GenericParser.can_handle(sample_json) is True

    def test_can_handle_wrong_ext(self, tmp_path):
        filepath = tmp_path / "data.jsonl"
        filepath.write_text('{"role": "user"}')
        assert GenericParser.can_handle(str(filepath)) is False

    def test_skips_invalid_roles(self, tmp_path):
        filepath = tmp_path / "conv.json"
        data = [
            {"role": "system", "content": "You are a bot."},
            {"role": "user", "content": "Hello"},
        ]
        filepath.write_text(json.dumps(data))
        parser = GenericParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 1
        assert messages[0].role == "user"

    def test_not_a_list(self, tmp_path):
        filepath = tmp_path / "conv.json"
        filepath.write_text('{"role": "user", "content": "hello"}')
        parser = GenericParser()
        assert parser.parse(str(filepath)) == []


class TestChatGPTParser:
    """Tests for the ChatGPT conversations.json parser."""

    @staticmethod
    def _make_node(node_id, parent_id, children, role=None, content_parts=None,
                   create_time=None, content_type="text"):
        """Build a ChatGPT mapping node."""
        node = {"id": node_id, "parent": parent_id, "children": children}
        if role is not None:
            msg = {
                "id": node_id,
                "author": {"role": role, "name": None, "metadata": {}},
                "create_time": create_time,
                "content": {"content_type": content_type, "parts": content_parts or []},
            }
            node["message"] = msg
        return node

    @pytest.fixture
    def sample_chatgpt(self, tmp_path):
        """Two conversations in one file."""
        conv1_mapping = {
            "root1": {"id": "root1", "parent": None, "children": ["sys1"]},
            "sys1": TestChatGPTParser._make_node(
                "sys1", "root1", ["u1"], role="system", content_parts=[""],
            ),
            "u1": TestChatGPTParser._make_node(
                "u1", "sys1", ["a1"], role="user",
                content_parts=["Hello there"], create_time=1695600000.0,
            ),
            "a1": TestChatGPTParser._make_node(
                "a1", "u1", [], role="assistant",
                content_parts=["Hi! How can I help?"], create_time=1695600010.0,
            ),
        }
        conv2_mapping = {
            "root2": {"id": "root2", "parent": None, "children": ["u2"]},
            "u2": TestChatGPTParser._make_node(
                "u2", "root2", ["a2"], role="user",
                content_parts=["What is Python?"], create_time=1695700000.0,
            ),
            "a2": TestChatGPTParser._make_node(
                "a2", "u2", [], role="assistant",
                content_parts=["A programming language."], create_time=1695700005.0,
            ),
        }
        data = [
            {"conversation_id": "conv-aaa", "title": "Greeting",
             "mapping": conv1_mapping, "current_node": "a1",
             "create_time": 1695600000, "update_time": 1695600010},
            {"conversation_id": "conv-bbb", "title": "Python Q",
             "mapping": conv2_mapping, "current_node": "a2",
             "create_time": 1695700000, "update_time": 1695700005},
        ]
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps(data))
        return str(filepath)

    def test_parse_multi_conversation(self, sample_chatgpt):
        parser = ChatGPTParser()
        messages = parser.parse(sample_chatgpt)
        # 2 messages from conv1 (system skipped) + 2 from conv2 = 4
        assert len(messages) == 4

        # Check conversation IDs
        conv_ids = {m.conversation_id for m in messages}
        assert conv_ids == {"conv-aaa", "conv-bbb"}

        # Check ordering within each conversation
        aaa = [m for m in messages if m.conversation_id == "conv-aaa"]
        assert aaa[0].role == "user"
        assert aaa[0].content == "Hello there"
        assert aaa[1].role == "assistant"
        assert aaa[1].content == "Hi! How can I help?"

    def test_timestamps_iso(self, sample_chatgpt):
        parser = ChatGPTParser()
        messages = parser.parse(sample_chatgpt)
        user_msg = messages[0]
        assert "2023-09-25" in user_msg.timestamp
        assert user_msg.timestamp.endswith("+00:00")

    def test_skips_system_and_tool_roles(self, tmp_path):
        mapping = {
            "root": {"id": "root", "parent": None, "children": ["sys"]},
            "sys": TestChatGPTParser._make_node(
                "sys", "root", ["tool"], role="system", content_parts=["sys"],
            ),
            "tool": TestChatGPTParser._make_node(
                "tool", "sys", ["u"], role="tool", content_parts=["result"],
            ),
            "u": TestChatGPTParser._make_node(
                "u", "tool", [], role="user",
                content_parts=["Real question"], create_time=1695600000.0,
            ),
        }
        data = [{"conversation_id": "conv-c", "mapping": mapping}]
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps(data))

        parser = ChatGPTParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 1
        assert messages[0].content == "Real question"

    def test_skips_non_text_content(self, tmp_path):
        mapping = {
            "root": {"id": "root", "parent": None, "children": ["u"]},
            "u": TestChatGPTParser._make_node(
                "u", "root", [], role="user",
                content_parts=[], content_type="user_editable_context",
            ),
        }
        data = [{"conversation_id": "conv-d", "mapping": mapping}]
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps(data))

        parser = ChatGPTParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 0

    def test_multimodal_text_with_dict_parts(self, tmp_path):
        mapping = {
            "root": {"id": "root", "parent": None, "children": ["u"]},
            "u": TestChatGPTParser._make_node(
                "u", "root", [], role="user",
                content_parts=[
                    "Check this image",
                    {"content_type": "image_asset_pointer", "asset_pointer": "file://x"},
                ],
                content_type="multimodal_text", create_time=1695600000.0,
            ),
        }
        data = [{"conversation_id": "conv-e", "mapping": mapping}]
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps(data))

        parser = ChatGPTParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 1
        assert messages[0].content == "Check this image"

    def test_follows_last_child_on_edits(self, tmp_path):
        """When a user edits a message, ChatGPT creates a branch.
        The parser should follow the last child (latest edit)."""
        mapping = {
            "root": {"id": "root", "parent": None, "children": ["u1"]},
            "u1": TestChatGPTParser._make_node(
                "u1", "root", ["a1_old", "a1_new"], role="user",
                content_parts=["Question"], create_time=1695600000.0,
            ),
            "a1_old": TestChatGPTParser._make_node(
                "a1_old", "u1", [], role="assistant",
                content_parts=["Old answer"], create_time=1695600005.0,
            ),
            "a1_new": TestChatGPTParser._make_node(
                "a1_new", "u1", [], role="assistant",
                content_parts=["New answer"], create_time=1695600010.0,
            ),
        }
        data = [{"conversation_id": "conv-f", "mapping": mapping}]
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps(data))

        parser = ChatGPTParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 2
        assert messages[1].content == "New answer"

    def test_can_handle(self, sample_chatgpt, tmp_path):
        assert ChatGPTParser.can_handle(sample_chatgpt) is True

        # Wrong format
        wrong = tmp_path / "generic.json"
        wrong.write_text(json.dumps([{"role": "user", "content": "hi"}]))
        assert ChatGPTParser.can_handle(str(wrong)) is False

        # Wrong extension
        txt = tmp_path / "data.txt"
        txt.write_text("plain text")
        assert ChatGPTParser.can_handle(str(txt)) is False

    def test_empty_conversation(self, tmp_path):
        data = [{"conversation_id": "conv-empty", "mapping": {}}]
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps(data))

        parser = ChatGPTParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 0


class TestExtractTextParts:
    def test_strings_only(self):
        assert _extract_text_parts(["Hello", "World"]) == "Hello\nWorld"

    def test_dict_with_text_key(self):
        parts = [{"content_type": "text", "text": "Translated text"}]
        assert _extract_text_parts(parts) == "Translated text"

    def test_skips_image_dicts(self):
        parts = [
            "Check this",
            {"content_type": "image_asset_pointer", "asset_pointer": "file://x"},
        ]
        assert _extract_text_parts(parts) == "Check this"

    def test_empty(self):
        assert _extract_text_parts([]) == ""


class TestAnthropicParser:
    """Tests for the Anthropic (claude.ai) conversations.json parser."""

    @staticmethod
    def _make_conversation(conv_id, messages):
        """Build an Anthropic conversation dict."""
        return {
            "uuid": conv_id,
            "name": "Test conversation",
            "summary": "",
            "created_at": "2025-10-06T12:00:00Z",
            "updated_at": "2025-10-06T13:00:00Z",
            "account": {"uuid": "acct-1"},
            "chat_messages": messages,
        }

    @staticmethod
    def _make_message(uuid, sender, text, timestamp="2025-10-06T12:09:33Z",
                      content_type="text"):
        """Build an Anthropic message dict."""
        return {
            "uuid": uuid,
            "sender": sender,
            "text": text,
            "content": [
                {
                    "type": content_type,
                    "text": text,
                    "start_timestamp": timestamp,
                    "stop_timestamp": timestamp,
                }
            ],
            "files": [],
            "attachments": [],
        }

    @pytest.fixture
    def sample_anthropic(self, tmp_path):
        """Two conversations in one file."""
        conv1 = self._make_conversation("conv-111", [
            self._make_message("m1", "human", "Hello Claude",
                               "2025-10-06T12:00:00Z"),
            self._make_message("m2", "assistant", "Hello! How can I help?",
                               "2025-10-06T12:00:05Z"),
        ])
        conv2 = self._make_conversation("conv-222", [
            self._make_message("m3", "human", "What is Python?",
                               "2025-10-06T13:00:00Z"),
            self._make_message("m4", "assistant", "A programming language.",
                               "2025-10-06T13:00:10Z"),
        ])
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps([conv1, conv2]))
        return str(filepath)

    def test_parse_multi_conversation(self, sample_anthropic):
        parser = AnthropicParser()
        messages = parser.parse(sample_anthropic)
        assert len(messages) == 4

        conv_ids = {m.conversation_id for m in messages}
        assert conv_ids == {"conv-111", "conv-222"}

        c1 = [m for m in messages if m.conversation_id == "conv-111"]
        assert c1[0].role == "user"
        assert c1[0].content == "Hello Claude"
        assert c1[1].role == "assistant"
        assert c1[1].content == "Hello! How can I help?"

    def test_timestamps_preserved(self, sample_anthropic):
        parser = AnthropicParser()
        messages = parser.parse(sample_anthropic)
        assert messages[0].timestamp == "2025-10-06T12:00:00Z"

    def test_uuids_preserved(self, sample_anthropic):
        parser = AnthropicParser()
        messages = parser.parse(sample_anthropic)
        assert messages[0].uuid == "m1"
        assert messages[2].uuid == "m3"

    def test_skips_thinking_blocks(self, tmp_path):
        msg = {
            "uuid": "m1",
            "sender": "assistant",
            "text": "visible text",
            "content": [
                {"type": "thinking", "text": "let me reason..."},
                {"type": "text", "text": "The answer is 42."},
            ],
        }
        conv = self._make_conversation("conv-t", [msg])
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps([conv]))

        parser = AnthropicParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 1
        assert messages[0].content == "The answer is 42."
        assert "reason" not in messages[0].content

    def test_skips_unknown_sender(self, tmp_path):
        msg = self._make_message("m1", "system", "You are helpful")
        conv = self._make_conversation("conv-s", [msg])
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps([conv]))

        parser = AnthropicParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 0

    def test_empty_chat_messages(self, tmp_path):
        conv = self._make_conversation("conv-e", [])
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps([conv]))

        parser = AnthropicParser()
        assert parser.parse(str(filepath)) == []

    def test_fallback_to_text_field(self, tmp_path):
        """When content array is empty, falls back to top-level text."""
        msg = {"uuid": "m1", "sender": "human", "text": "Hello", "content": []}
        conv = self._make_conversation("conv-f", [msg])
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps([conv]))

        parser = AnthropicParser()
        messages = parser.parse(str(filepath))
        assert len(messages) == 1
        assert messages[0].content == "Hello"

    def test_can_handle(self, sample_anthropic, tmp_path):
        assert AnthropicParser.can_handle(sample_anthropic) is True

        # ChatGPT format should not match
        chatgpt = tmp_path / "chatgpt.json"
        chatgpt.write_text(json.dumps([{"conversation_id": "x", "mapping": {}}]))
        assert AnthropicParser.can_handle(str(chatgpt)) is False

        # Wrong extension
        txt = tmp_path / "data.txt"
        txt.write_text("plain text")
        assert AnthropicParser.can_handle(str(txt)) is False

    def test_not_a_list(self, tmp_path):
        filepath = tmp_path / "conversations.json"
        filepath.write_text('{"uuid": "x", "chat_messages": []}')
        parser = AnthropicParser()
        assert parser.parse(str(filepath)) == []


class TestExtractTextContentAnthropic:
    def test_text_blocks(self):
        msg = {"content": [{"type": "text", "text": "Hello"}]}
        assert _extract_text_content(msg) == "Hello"

    def test_multiple_text_blocks(self):
        msg = {"content": [
            {"type": "text", "text": "Part 1"},
            {"type": "text", "text": "Part 2"},
        ]}
        assert _extract_text_content(msg) == "Part 1\nPart 2"

    def test_skips_thinking(self):
        msg = {"content": [
            {"type": "thinking", "text": "reasoning"},
            {"type": "text", "text": "answer"},
        ]}
        assert _extract_text_content(msg) == "answer"

    def test_empty_content_falls_back(self):
        msg = {"content": [], "text": "fallback text"}
        assert _extract_text_content(msg) == "fallback text"

    def test_no_content_key(self):
        msg = {"text": "top level only"}
        assert _extract_text_content(msg) == "top level only"


class TestRegistry:
    def test_get_parser_valid(self):
        parser = get_parser("claude-code")
        assert isinstance(parser, ClaudeCodeParser)

    def test_get_parser_invalid(self):
        with pytest.raises(ValueError, match="Unknown parser"):
            get_parser("nonexistent")

    def test_detect_jsonl(self, tmp_path):
        filepath = tmp_path / "conv.jsonl"
        line = {"type": "user", "message": {"content": "Hi"}, "uuid": "u1",
                "sessionId": "s1", "timestamp": ""}
        filepath.write_text(json.dumps(line) + "\n")
        parser = detect_parser(str(filepath))
        assert isinstance(parser, ClaudeCodeParser)

    def test_detect_json(self, tmp_path):
        filepath = tmp_path / "conv.json"
        data = [{"role": "user", "content": "Hi"}]
        filepath.write_text(json.dumps(data))
        parser = detect_parser(str(filepath))
        assert isinstance(parser, GenericParser)

    def test_detect_unknown(self, tmp_path):
        filepath = tmp_path / "data.txt"
        filepath.write_text("plain text")
        assert detect_parser(str(filepath)) is None

    def test_detect_anthropic(self, tmp_path):
        conv = {
            "uuid": "c1",
            "chat_messages": [
                {"uuid": "m1", "sender": "human", "text": "Hi",
                 "content": [{"type": "text", "text": "Hi"}]}
            ],
        }
        filepath = tmp_path / "conversations.json"
        filepath.write_text(json.dumps([conv]))
        parser = detect_parser(str(filepath))
        assert isinstance(parser, AnthropicParser)

    def test_all_parsers_registered(self):
        assert "anthropic" in PARSERS
        assert "chatgpt" in PARSERS
        assert "claude-code" in PARSERS
        assert "generic" in PARSERS


class TestIngestIntegration:
    """Test the full ingest pipeline: parse -> insert -> verify in DB."""

    @pytest.fixture
    def conv_file(self, tmp_path):
        filepath = tmp_path / "conv.jsonl"
        lines = [
            {"type": "user", "message": {"content": "What is tapestry?"},
             "uuid": "uuid-1", "sessionId": "conv-abc123",
             "timestamp": "2026-03-01T10:00:00Z"},
            {"type": "assistant", "message": {"content": "Tapestry is a memory system."},
             "uuid": "uuid-2", "sessionId": "conv-abc123",
             "timestamp": "2026-03-01T10:00:30Z"},
        ]
        with open(filepath, "w") as f:
            for obj in lines:
                f.write(json.dumps(obj) + "\n")
        return str(filepath)

    def test_parse_and_insert(self, db, conv_file):
        parser = ClaudeCodeParser()
        messages = parser.parse(conv_file)
        assert len(messages) == 2

        # Insert into DB
        for i, msg in enumerate(messages):
            db.sql(
                """INSERT INTO tapestry_messages
                   (tmsg_agent, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role,
                    tmsg_content, tmsg_order, tmsg_timestamp)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                ("default", msg.uuid, msg.conversation_id, msg.role,
                 msg.content, i, msg.timestamp),
            )

        # Verify
        rows = db.sql("SELECT * FROM tapestry_messages ORDER BY tmsg_order")
        assert len(rows) == 2
        assert rows[0]["tmsg_role"] == "user"
        assert rows[0]["tmsg_ref_conv_id"] == "conv-abc123"
        assert rows[1]["tmsg_role"] == "assistant"
        assert rows[1]["tmsg_content"] == "Tapestry is a memory system."

    def test_dedup_prevents_reimport(self, db, conv_file):
        parser = ClaudeCodeParser()
        messages = parser.parse(conv_file)

        # First import
        for i, msg in enumerate(messages):
            db.sql(
                """INSERT INTO tapestry_messages
                   (tmsg_agent, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role,
                    tmsg_content, tmsg_order, tmsg_timestamp)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                ("default", msg.uuid, msg.conversation_id, msg.role,
                 msg.content, i, msg.timestamp),
            )

        # Check dedup
        existing = db.sql(
            "SELECT COUNT(*) as cnt FROM tapestry_messages WHERE tmsg_ref_conv_id = ?",
            ("conv-abc123",),
            single=True,
        )
        assert existing["cnt"] == 2  # Already imported
