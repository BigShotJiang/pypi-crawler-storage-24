"""Tests for tapestry.llm module."""

from unittest.mock import MagicMock, patch

import pytest

from tapestry.config import LLMConfig, LLMFallbackConfig
from tapestry.llm import LLMClient, LLMError, _strip_fences


class TestStripFences:
    def test_json_fence(self):
        assert _strip_fences('```json\n{"a": 1}\n```') == '{"a": 1}'

    def test_plain_fence(self):
        assert _strip_fences("```\nhello\n```") == "hello"

    def test_no_fence(self):
        assert _strip_fences("hello world") == "hello world"

    def test_empty(self):
        assert _strip_fences("") == ""


class TestLLMClient:
    @pytest.fixture
    def llm_config(self):
        return LLMConfig(
            provider="groq",
            api_url="https://api.groq.com/openai/v1/chat/completions",
            api_key="test-key",
            content_model="test-model",
            title_model="test-title-model",
            max_tokens_content=8000,
            max_tokens_title=500,
            temperature=0.3,
            request_timeout=60,
            fallback=LLMFallbackConfig(enabled=False),
        )

    @pytest.fixture
    def client(self, llm_config):
        return LLMClient(llm_config)

    @patch("tapestry.llm.requests.post")
    def test_request_success(self, mock_post, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Hello back!"}}]
        }
        mock_post.return_value = mock_response

        result = client.request([{"role": "user", "content": "Hello"}])
        assert result == "Hello back!"

        # Verify call args
        call_kwargs = mock_post.call_args
        assert call_kwargs[1]["json"]["model"] == "test-model"
        assert call_kwargs[1]["json"]["max_tokens"] == 8000

    @patch("tapestry.llm.requests.post")
    def test_request_with_overrides(self, mock_post, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "result"}}]
        }
        mock_post.return_value = mock_response

        client.request(
            [{"role": "user", "content": "test"}],
            model="custom-model",
            max_tokens=100,
            temperature=0.9,
        )

        call_kwargs = mock_post.call_args
        assert call_kwargs[1]["json"]["model"] == "custom-model"
        assert call_kwargs[1]["json"]["max_tokens"] == 100
        assert call_kwargs[1]["json"]["temperature"] == 0.9

    @patch("tapestry.llm.requests.post")
    def test_title_uses_title_model(self, mock_post, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "A Title"}}]
        }
        mock_post.return_value = mock_response

        result = client.title([{"role": "user", "content": "give title"}])
        assert result == "A Title"

        call_kwargs = mock_post.call_args
        assert call_kwargs[1]["json"]["model"] == "test-title-model"
        assert call_kwargs[1]["json"]["max_tokens"] == 500

    @patch("tapestry.llm.requests.post")
    def test_api_error_raises(self, mock_post, client):
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.text = "Rate limited"
        mock_post.return_value = mock_response

        with pytest.raises(LLMError, match="429"):
            client.request([{"role": "user", "content": "test"}])

    @patch("tapestry.llm.requests.post")
    def test_fallback_on_error(self, mock_post):
        config = LLMConfig(
            api_url="https://primary.example.com",
            api_key="key",
            fallback=LLMFallbackConfig(
                enabled=True,
                api_url="http://localhost:11434/v1/chat/completions",
                model="local-model",
            ),
        )
        client = LLMClient(config)

        # First call fails, second succeeds
        fail_response = MagicMock()
        fail_response.status_code = 500
        fail_response.text = "Server error"

        ok_response = MagicMock()
        ok_response.status_code = 200
        ok_response.json.return_value = {
            "choices": [{"message": {"content": "fallback result"}}]
        }
        mock_post.side_effect = [fail_response, ok_response]

        result = client.request([{"role": "user", "content": "test"}])
        assert result == "fallback result"
        assert mock_post.call_count == 2

    @patch("tapestry.llm.requests.post")
    def test_strips_code_fences(self, mock_post, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": '```json\n{"key": "val"}\n```'}}]
        }
        mock_post.return_value = mock_response

        result = client.request([{"role": "user", "content": "test"}])
        assert result == '{"key": "val"}'
