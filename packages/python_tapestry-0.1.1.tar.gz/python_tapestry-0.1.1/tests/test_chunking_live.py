"""Live test: chunked summarization against a real large conversation.

Pulls messages from tapestry.db, runs summarize_chunked, prints results.
Persists benchmark results to chunk_benchmarks table.

Usage: env_tapestry/Scripts/python.exe tests/test_chunking_live.py
"""

import sqlite3
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from tapestry.config import load_config
from tapestry.llm import LLMClient
from tapestry.engine.chunking import (
    estimate_tokens,
    format_transcript,
    needs_chunking,
    summarize_chunked,
)
from tapestry.engine.prompts import factual_prompt
from tapestry.engine.topic_benchmark import FREE_EXTRACT_PROMPT, _parse_topic_list


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Live chunked summarization test")
    parser.add_argument("--chunk-size", type=int, default=None,
                        help="Override chunk size in tokens (default: from config)")
    parser.add_argument("--merge-buffer", type=int, default=0,
                        help="Merge threshold buffer in tokens (default: 0)")
    parser.add_argument("--model", type=str, default=None,
                        help="Override LLM model (default: from config)")
    parser.add_argument("--output", type=str, default=None,
                        help="Write final summary to file (default: print to console)")
    parser.add_argument("--overlap", type=int, default=0,
                        help="Number of messages to overlap between chunks (default: 0)")
    parser.add_argument("--no-db", action="store_true",
                        help="Skip persisting results to database")
    args = parser.parse_args()

    config = load_config(os.path.join(os.path.dirname(__file__), "..", "tapestry.toml"))
    if args.chunk_size is not None:
        config.llm.chunk_size_tokens = args.chunk_size
    if args.model is not None:
        config.llm.content_model = args.model
    import tapestry.engine.chunking as chunking_mod
    chunking_mod.MERGE_THRESHOLD_BUFFER = args.merge_buffer
    llm = LLMClient(config.llm)

    db = sqlite3.connect(config.db_path)
    db.row_factory = sqlite3.Row

    # Find the largest conversation
    row = db.execute("""
        SELECT tmsg_ref_conv_id, tmsg_agent, COUNT(*) as msg_count,
               SUM(LENGTH(tmsg_content)) as total_chars
        FROM tapestry_messages
        GROUP BY tmsg_ref_conv_id
        ORDER BY total_chars DESC
        LIMIT 1
    """).fetchone()

    conv_id = row["tmsg_ref_conv_id"]
    total_tokens = row["total_chars"] // 4
    print(f"Target: {conv_id}")
    print(f"Model: {config.llm.content_model}")
    print(f"Agent: {row['tmsg_agent']}, {row['msg_count']} messages, ~{total_tokens:,} tokens")
    print()

    # Fetch messages
    messages = [dict(r) for r in db.execute("""
        SELECT tmsg_role, tmsg_content, tmsg_timestamp, tmsg_order
        FROM tapestry_messages
        WHERE tmsg_ref_conv_id = ?
        ORDER BY tmsg_order
    """, (conv_id,)).fetchall()]

    agent_label = config.agent_name.upper()
    user_label = config.user_name.upper()

    if not needs_chunking(messages, agent_label, user_label, config.llm.chunk_size_tokens):
        print("This conversation does not need chunking. Exiting.")
        db.close()
        return

    system = factual_prompt(config.agent_name, config.user_name)

    print("Starting chunked summarization...")
    print("=" * 60)

    result, stats = summarize_chunked(
        messages, llm, config, system, agent_label, user_label,
        config.llm.chunk_size_tokens, overlap=args.overlap,
    )

    print("=" * 60)
    print(f"\nFinal summary: ~{stats['final_tokens']:,} tokens")
    print(f"Stats: {stats['chunks']} chunks, {stats['llm_calls']} LLM calls, "
          f"{stats['merge_levels']} merge levels, "
          f"~{stats['intermediate_tokens']:,} intermediate tokens")

    # Extract topics from final summary
    print("Extracting topics...")
    topic_response = llm.request(
        [
            {"role": "system", "content": FREE_EXTRACT_PROMPT},
            {"role": "user", "content": result},
        ],
        max_tokens=16000,
    )
    topics = _parse_topic_list(topic_response)
    topic_count = len(topics)
    print(f"Topics extracted: {topic_count}")

    # Persist to database
    if not args.no_db:
        # Create run record
        cur = db.execute("""
            INSERT INTO chunk_benchmark_runs
            (cbr_conv_id, cbr_model, cbr_chunk_size, cbr_merge_buffer, cbr_temperature, cbr_total_runs)
            VALUES (?, ?, ?, ?, ?, 1)
        """, (
            conv_id,
            config.llm.content_model,
            config.llm.chunk_size_tokens,
            args.merge_buffer,
            config.llm.temperature,
        ))
        cbr_id = cur.lastrowid

        # Create result record
        db.execute("""
            INSERT INTO chunk_benchmarks
            (cbr_id, cb_run_number, cb_chunks, cb_llm_calls, cb_merge_levels,
             cb_intermediate_tokens, cb_final_tokens, cb_topic_count, cb_output_file)
            VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)
        """, (
            cbr_id,
            stats["chunks"],
            stats["llm_calls"],
            stats["merge_levels"],
            stats["intermediate_tokens"],
            stats["final_tokens"],
            topic_count,
            args.output,
        ))
        db.commit()
        print(f"Results saved to chunk_benchmarks table")

    # Write output file
    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(f"Model: {config.llm.content_model}\n")
            f.write(f"Chunk size: {config.llm.chunk_size_tokens}\n")
            f.write(f"Merge buffer: {args.merge_buffer}\n")
            f.write(f"Chunks: {stats['chunks']}\n")
            f.write(f"LLM calls: {stats['llm_calls']}\n")
            f.write(f"Merge levels: {stats['merge_levels']}\n")
            f.write(f"Intermediate tokens: ~{stats['intermediate_tokens']:,}\n")
            f.write(f"Final tokens: ~{stats['final_tokens']:,}\n")
            f.write(f"{'=' * 60}\n\n")
            f.write(result)
        print(f"Summary written to {args.output}")
    else:
        print()
        print(result)

    db.close()


if __name__ == "__main__":
    main()
