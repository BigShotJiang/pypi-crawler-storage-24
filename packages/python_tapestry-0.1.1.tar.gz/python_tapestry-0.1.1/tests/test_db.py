"""Tests for the database layer."""

from tapestry.db import Database
from tapestry.schema import SCHEMA_VERSION, get_schema_version, init_db


def test_database_create_and_connect(tmp_path):
    """Database creates file and connects."""
    db_path = str(tmp_path / "db" / "test.db")
    db = Database(db_path)
    db.ensure_directory()
    init_db(db)

    version = get_schema_version(db)
    assert version == SCHEMA_VERSION
    db.close()


def test_sql_insert_and_select(db):
    """Insert and retrieve a record."""
    tap_id = db.sql(
        """INSERT INTO tapestry (tap_agent, tap_level, tap_title, tap_content, tap_date)
           VALUES (?, ?, ?, ?, ?)""",
        ("test-agent", 0, "Test Title", "Test content body.", "2026-03-02"),
    )
    assert isinstance(tap_id, int)
    assert tap_id > 0

    row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
    assert row is not None
    assert row["tap_agent"] == "test-agent"
    assert row["tap_level"] == 0
    assert row["tap_title"] == "Test Title"
    assert row["tap_content"] == "Test content body."
    assert row["tap_date"] == "2026-03-02"


def test_sql_select_multiple(db):
    """Select returns list of dicts."""
    for i in range(3):
        db.sql(
            """INSERT INTO tapestry (tap_agent, tap_level, tap_title, tap_content, tap_date)
               VALUES (?, ?, ?, ?, ?)""",
            ("agent", 0, f"Title {i}", f"Content {i}", "2026-03-02"),
        )

    rows = db.sql("SELECT * FROM tapestry WHERE tap_agent = ?", ("agent",))
    assert isinstance(rows, list)
    assert len(rows) == 3


def test_sql_select_empty(db):
    """Select with no results returns empty list."""
    rows = db.sql("SELECT * FROM tapestry WHERE tap_agent = ?", ("nonexistent",))
    assert rows == []


def test_sql_select_single_none(db):
    """Select single with no results returns None."""
    row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (999,), single=True)
    assert row is None


def test_tapestry_messages_table(db):
    """tapestry_messages table works."""
    msg_id = db.sql(
        """INSERT INTO tapestry_messages
           (tmsg_agent, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        ("agent", "uuid-1", "conv-1", "user", "Hello!", 1, "2026-03-02T10:00:00"),
    )
    assert isinstance(msg_id, int)

    row = db.sql("SELECT * FROM tapestry_messages WHERE tmsg_id = ?", (msg_id,), single=True)
    assert row["tmsg_role"] == "user"
    assert row["tmsg_content"] == "Hello!"


def test_unique_constraint_on_messages(db):
    """Duplicate (conv_id, order) should fail."""
    db.sql(
        """INSERT INTO tapestry_messages
           (tmsg_agent, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("agent", "uuid-1", "conv-1", "user", "First", 1),
    )

    # Same conv_id + order should raise
    import sqlite3
    import pytest

    with pytest.raises(sqlite3.IntegrityError):
        db.sql(
            """INSERT INTO tapestry_messages
               (tmsg_agent, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order)
               VALUES (?, ?, ?, ?, ?, ?)""",
            ("agent", "uuid-2", "conv-1", "user", "Duplicate", 1),
            commit=False,
        )
    db.rollback()


def test_parent_reference(db):
    """tap_parent_id links records."""
    parent_id = db.sql(
        """INSERT INTO tapestry (tap_agent, tap_level, tap_title, tap_content, tap_date)
           VALUES (?, ?, ?, ?, ?)""",
        ("agent", 1, "Daily", "Daily summary", "2026-03-02"),
    )

    child_id = db.sql(
        """INSERT INTO tapestry (tap_agent, tap_level, tap_title, tap_content, tap_date, tap_parent_id)
           VALUES (?, ?, ?, ?, ?, ?)""",
        ("agent", 0, "Conv", "Conversation summary", "2026-03-02", parent_id),
    )

    child = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (child_id,), single=True)
    assert child["tap_parent_id"] == parent_id
