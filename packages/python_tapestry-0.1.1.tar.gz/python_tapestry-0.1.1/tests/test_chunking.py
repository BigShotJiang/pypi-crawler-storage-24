"""Tests for engine/chunking.py — chunked summarization for large conversations."""

from unittest.mock import MagicMock, call

import pytest

from tapestry.config import AgentConfig, LLMConfig, TapestryConfig
from tapestry.engine.chunking import (
    chunk_messages,
    estimate_tokens,
    format_transcript,
    needs_chunking,
    summarize_chunked,
)


AGENT_LABEL = "TESTAGENT"
USER_LABEL = "TESTUSER"


def _make_msg(role, content, order=1):
    return {
        "tmsg_role": role,
        "tmsg_content": content,
        "tmsg_order": order,
        "tmsg_timestamp": "2026-03-22T10:00:00",
    }


def _make_config(**overrides):
    defaults = dict(
        db_path="test.db",
        project_dir="/tmp",
        agent_name="TestAgent",
        user_name="TestUser",
        llm=LLMConfig(provider="groq", api_key="test"),
        agents={"default": AgentConfig()},
    )
    defaults.update(overrides)
    return TapestryConfig(**defaults)


class TestEstimateTokens:
    def test_empty_string(self):
        assert estimate_tokens("") == 0

    def test_short_string(self):
        assert estimate_tokens("hello world") == 2  # 11 chars / 4 = 2

    def test_long_string(self):
        text = "x" * 400_000
        assert estimate_tokens(text) == 100_000


class TestFormatTranscript:
    def test_formats_messages(self):
        msgs = [
            _make_msg("user", "Hello"),
            _make_msg("assistant", "Hi there"),
        ]
        result = format_transcript(msgs, AGENT_LABEL, USER_LABEL)
        assert "[TESTUSER]: Hello" in result
        assert "[TESTAGENT]: Hi there" in result
        assert "\n\n" in result

    def test_empty_messages(self):
        assert format_transcript([], AGENT_LABEL, USER_LABEL) == ""


class TestChunkMessages:
    def test_single_chunk_when_small(self):
        msgs = [_make_msg("user", "short message", i) for i in range(5)]
        chunks = chunk_messages(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=10_000)
        assert len(chunks) == 1
        assert len(chunks[0]) == 5

    def test_splits_at_message_boundaries(self):
        # Each message ~250 tokens (1000 chars), chunk size 600 tokens
        msgs = [_make_msg("user", "x" * 1000, i) for i in range(5)]
        chunks = chunk_messages(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=600)
        assert len(chunks) > 1
        # All messages accounted for
        total = sum(len(c) for c in chunks)
        assert total == 5

    def test_absorbs_small_remainder(self):
        # 4 messages of ~250 tokens each, chunk size 700
        # First chunk: 2 msgs (~500 tokens), second would be 2 msgs (~500 tokens)
        # But with MIN_REMAINDER_TOKENS=10000, small remainders get absorbed
        msgs = [_make_msg("user", "x" * 1000, i) for i in range(4)]
        chunks = chunk_messages(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=700)
        # With these sizes the remainder should be absorbed
        total = sum(len(c) for c in chunks)
        assert total == 4

    def test_single_large_message(self):
        # One message bigger than chunk size — still goes in one chunk
        msgs = [_make_msg("user", "x" * 500_000)]
        chunks = chunk_messages(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=10_000)
        assert len(chunks) == 1
        assert len(chunks[0]) == 1


class TestNeedsChunking:
    def test_small_conversation_no_chunking(self):
        msgs = [_make_msg("user", "Hello", i) for i in range(3)]
        assert needs_chunking(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=100_000) is False

    def test_large_conversation_needs_chunking(self):
        # 500K chars = ~125K tokens, exceeds 100K + 10K buffer
        msgs = [_make_msg("user", "x" * 100_000, i) for i in range(5)]
        assert needs_chunking(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=100_000) is True

    def test_borderline_no_chunking(self):
        # Under chunk_size + buffer — no chunking
        # format_transcript adds "[TESTUSER]: " prefix (13 chars)
        # Total must be <= 110K tokens = 440K chars including prefix
        content_chars = 440_000 - 13  # account for prefix
        msgs = [_make_msg("user", "x" * content_chars)]
        assert needs_chunking(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=100_000) is False

    def test_just_over_threshold(self):
        # 444K chars = 111K tokens > 110K threshold
        msgs = [_make_msg("user", "x" * 444_001)]
        assert needs_chunking(msgs, AGENT_LABEL, USER_LABEL, chunk_size_tokens=100_000) is True


class TestSummarizeChunked:
    def test_produces_final_summary(self):
        config = _make_config()
        llm = MagicMock()
        llm.request.return_value = "Chunk summary."

        # Make messages big enough to require 2 chunks at 500 token limit
        msgs = [_make_msg("user", "x" * 2000, i) for i in range(5)]
        result, stats = summarize_chunked(
            msgs, llm, config, "System prompt", AGENT_LABEL, USER_LABEL,
            chunk_size_tokens=500,
        )

        assert result == "Chunk summary."
        # Should have called request multiple times: chunk summaries + final pass
        assert llm.request.call_count >= 2

    def test_final_pass_receives_all_chunk_summaries(self):
        config = _make_config()
        llm = MagicMock()
        call_count = [0]

        def mock_request(messages):
            call_count[0] += 1
            return f"Summary {call_count[0]}"

        llm.request.side_effect = mock_request

        msgs = [_make_msg("user", "x" * 2000, i) for i in range(5)]
        result, stats = summarize_chunked(
            msgs, llm, config, "System prompt", AGENT_LABEL, USER_LABEL,
            chunk_size_tokens=500,
        )

        # Last call is the final pass — its user content should contain
        # all prior chunk summaries
        final_call = llm.request.call_args_list[-1]
        final_user_content = final_call[0][0][1]["content"]
        # Should contain at least Part 1 and Part 2
        assert "Part 1" in final_user_content
        assert "Part 2" in final_user_content

    def test_prior_summary_prepended_to_subsequent_chunks(self):
        config = _make_config()
        llm = MagicMock()
        call_count = [0]

        def mock_request(messages):
            call_count[0] += 1
            return f"Summary {call_count[0]}"

        llm.request.side_effect = mock_request

        msgs = [_make_msg("user", "x" * 2000, i) for i in range(5)]
        summarize_chunked(
            msgs, llm, config, "System prompt", AGENT_LABEL, USER_LABEL,
            chunk_size_tokens=500,
        )

        # Second chunk call should have PRIOR CONTEXT in user content
        if llm.request.call_count >= 3:
            second_call = llm.request.call_args_list[1]
            second_user = second_call[0][0][1]["content"]
            assert "PRIOR CONTEXT" in second_user
