"""Tests for engine/context.py — telescoping context resolution."""

import pytest

from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.engine.context import resolve_context
from tapestry.engine.prompts import context_preamble


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "test.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


def _ensure_agent(db, agent="default"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _insert_message(db, agent, conv_id, timestamp, order=1, agent_id=None):
    """Insert a minimal tapestry_messages row."""
    db.sql(
        """INSERT INTO tapestry_messages
           (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, f"uuid-{conv_id}-{order}", conv_id, "user", "test content", order, timestamp),
    )


def _insert_tapestry(db, agent, level, title, content, tap_date=None,
                     date_start=None, date_end=None, source=None, parent_id=None, agent_id=None):
    """Insert a tapestry record and return tap_id."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source, tap_parent_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, level, title, content, tap_date, date_start, date_end, source, parent_id),
    )


class TestResolveContextEmpty:
    def test_no_conversations(self, db):
        """Empty DB returns empty results."""
        agent_id = _ensure_agent(db, "default")
        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-02")
        assert ctx == []
        assert repairs == []


class TestResolveContextL0:
    def test_loads_same_day_l0s(self, db):
        """L0 summaries for anchor date are loaded into context."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2026-03-02T10:00:00", agent_id=agent_id)
        _insert_tapestry(db, "default", 0, "Test L0", "Content here",
                         tap_date="2026-03-02", source="conv-1", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-02")
        assert len(ctx) == 1
        assert ctx[0]["level"] == 0
        assert ctx[0]["title"] == "Test L0"

    def test_flags_missing_l0(self, db):
        """Conversations without L0 summaries are flagged for repair."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2026-03-02T10:00:00", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-02")
        assert len(ctx) == 0
        assert len(repairs) == 1
        assert repairs[0]["level"] == 0

    def test_anchor_start_filters_l0s(self, db):
        """L0s after anchor_start_ts are excluded."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-early", "2026-03-02T08:00:00", agent_id=agent_id)
        _insert_message(db, "default", "conv-late", "2026-03-02T14:00:00", agent_id=agent_id)
        _insert_tapestry(db, "default", 0, "Early", "Early content",
                         tap_date="2026-03-02", source="conv-early", agent_id=agent_id)
        _insert_tapestry(db, "default", 0, "Late", "Late content",
                         tap_date="2026-03-02", source="conv-late", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-02",
                                       anchor_start_ts="2026-03-02T10:00:00")
        assert len(ctx) == 1
        assert ctx[0]["title"] == "Early"


class TestResolveContextDaily:
    def test_loads_prior_daily(self, db):
        """Daily summaries from earlier in the week are loaded."""
        agent_id = _ensure_agent(db, "default")
        # Need messages so first_date is found
        _insert_message(db, "default", "conv-1", "2026-03-02T10:00:00", agent_id=agent_id)
        # Wed Mar 4 anchor, Mon Mar 2 daily exists
        _insert_tapestry(db, "default", 1, "Monday Daily", "Monday work",
                         tap_date="2026-03-02", date_start="2026-03-02", date_end="2026-03-02", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-04")
        daily_items = [c for c in ctx if c["level"] == 1]
        assert len(daily_items) == 1
        assert daily_items[0]["title"] == "Monday Daily"

    def test_flags_missing_daily(self, db):
        """Days with conversations but no daily are flagged."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2026-03-02T10:00:00", agent_id=agent_id)
        # Anchor is Mar 4, Mar 2 has conversations but no daily
        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-04")
        daily_repairs = [r for r in repairs if r["level"] == 1]
        assert len(daily_repairs) == 1
        assert daily_repairs[0]["start"] == "2026-03-02"


class TestResolveContextWeekly:
    def test_loads_prior_weekly(self, db):
        """Weekly summaries from earlier in the month are loaded."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2026-03-02T10:00:00", agent_id=agent_id)
        # Week Mar 2-8 (Mon-Sun) — anchor on Mar 10 (next Monday)
        _insert_tapestry(db, "default", 2, "Week 1", "Week 1 content",
                         tap_date="2026-03-02", date_start="2026-03-02", date_end="2026-03-08", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-10")
        weekly_items = [c for c in ctx if c["level"] == 2]
        assert len(weekly_items) == 1
        assert weekly_items[0]["title"] == "Week 1"


class TestResolveContextMonthly:
    def test_loads_prior_monthly(self, db):
        """Monthly summaries from earlier months are loaded."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2026-02-15T10:00:00", agent_id=agent_id)
        _insert_tapestry(db, "default", 3, "February", "Feb content",
                         tap_date="2026-02-01", date_start="2026-02-01", date_end="2026-02-28", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-10")
        monthly_items = [c for c in ctx if c["level"] == 3]
        assert len(monthly_items) == 1
        assert monthly_items[0]["title"] == "February"

    def test_flags_missing_monthly(self, db):
        """Months with conversations but no summary are flagged."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2026-02-15T10:00:00", agent_id=agent_id)
        # Another message in March so first_date < anchor
        _insert_message(db, "default", "conv-2", "2026-03-10T10:00:00", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-10")
        monthly_repairs = [r for r in repairs if r["level"] == 3]
        assert len(monthly_repairs) == 1
        assert "February" in monthly_repairs[0]["range"]


class TestResolveContextYearly:
    def test_loads_prior_yearly(self, db):
        """Yearly summaries from prior years are loaded."""
        agent_id = _ensure_agent(db, "default")
        _insert_message(db, "default", "conv-1", "2025-06-15T10:00:00", agent_id=agent_id)
        _insert_tapestry(db, "default", 4, "Year 2025", "2025 content",
                         tap_date="2025-01-01", date_start="2025-01-01", date_end="2025-12-31", agent_id=agent_id)
        _insert_message(db, "default", "conv-2", "2026-03-02T10:00:00", agent_id=agent_id)

        ctx, repairs = resolve_context(db, "default", agent_id, "2026-03-02")
        yearly_items = [c for c in ctx if c["level"] == 4]
        assert len(yearly_items) == 1
        assert yearly_items[0]["title"] == "Year 2025"


class TestContextPreamble:
    def test_empty(self):
        assert context_preamble([]) == ""

    def test_formats_items(self):
        items = [
            {"level": 3, "range": "February 2026", "title": "Feb Work", "content": "Did stuff."},
            {"level": 1, "range": "2026-03-01", "title": "Saturday", "content": "Weekend work."},
        ]
        result = context_preamble(items)
        assert "PRIOR SESSIONS CONTEXT" in result
        assert "[Monthly — February 2026]: Feb Work" in result
        assert "[Daily — 2026-03-01]: Saturday" in result
        assert "Did stuff." in result
        assert "Weekend work." in result
