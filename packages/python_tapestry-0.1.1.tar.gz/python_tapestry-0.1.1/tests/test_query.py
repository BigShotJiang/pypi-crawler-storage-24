"""Tests for query module — search, recall, tree, stats, status."""

import pytest

from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.query.search import search, search_summaries
from tapestry.query.recall import recall, show, conversations, show_conversation
from tapestry.query.tree import tree
from tapestry.query.stats import stats, status


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "test.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


def _ensure_agent(db, agent="default"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _msg(db, agent, conv_id, content, timestamp, order=1, role="user", agent_id=None):
    """Insert a tapestry_messages row."""
    db.sql(
        """INSERT INTO tapestry_messages
           (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, f"uuid-{conv_id}-{order}", conv_id, role, content, order, timestamp),
    )


def _tap(db, agent, level, title, content, tap_date=None,
         date_start=None, date_end=None, source=None, parent_id=None, agent_id=None):
    """Insert a tapestry record and return tap_id."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source, tap_parent_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, level, title, content, tap_date, date_start, date_end, source, parent_id),
    )


def _seed(db):
    """Seed a small hierarchy for testing."""
    agent_id = _ensure_agent(db, "default")

    # Messages for 2 conversations
    _msg(db, "default", "conv-a", "Built the search feature today", "2026-03-01T10:00:00", 1, agent_id=agent_id)
    _msg(db, "default", "conv-a", "Search works with keyword matching", "2026-03-01T10:05:00", 2, "assistant", agent_id=agent_id)
    _msg(db, "default", "conv-b", "Fixed the database bug", "2026-03-01T14:00:00", 1, agent_id=agent_id)
    _msg(db, "default", "conv-c", "Added tree display", "2026-03-02T09:00:00", 1, agent_id=agent_id)

    # L0 summaries
    l0_a = _tap(db, "default", 0, "Search Feature Build", "Built keyword search with LIKE queries.",
                tap_date="2026-03-01", source="conv-a", agent_id=agent_id)
    l0_b = _tap(db, "default", 0, "Database Bug Fix", "Fixed connection retry logic.",
                tap_date="2026-03-01", source="conv-b", agent_id=agent_id)
    l0_c = _tap(db, "default", 0, "Tree Display", "Added hierarchy tree view.",
                tap_date="2026-03-02", source="conv-c", agent_id=agent_id)

    # L1 daily
    daily = _tap(db, "default", 1, "Search and Bug Fixes", "Built search feature and fixed DB bug.",
                 tap_date="2026-03-01", source=f"{l0_a},{l0_b}", agent_id=agent_id)

    # Link L0s to daily
    db.sql("UPDATE tapestry SET tap_parent_id = ? WHERE tap_id IN (?, ?)", (daily, l0_a, l0_b))

    # L2 weekly
    weekly = _tap(db, "default", 2, "Week of Mar 1", "Search, bug fixes, and tree display.",
                  date_start="2026-03-01", date_end="2026-03-07", source=str(daily), agent_id=agent_id)
    db.sql("UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?", (weekly, daily))

    # L3 monthly
    monthly = _tap(db, "default", 3, "March 2026", "Full month of development.",
                   date_start="2026-03-01", date_end="2026-03-31", source=str(weekly), agent_id=agent_id)
    db.sql("UPDATE tapestry SET tap_parent_id = ? WHERE tap_id = ?", (monthly, weekly))

    return {
        "l0_a": l0_a, "l0_b": l0_b, "l0_c": l0_c,
        "daily": daily, "weekly": weekly, "monthly": monthly,
        "agent_id": agent_id,
    }


# ── search tests ──────────────────────────────────────────────────────

class TestSearch:
    def test_empty_db(self, db):
        agent_id = _ensure_agent(db, "default")
        results = search(db, "default", agent_id, "anything")
        assert results == []

    def test_finds_matching_messages(self, db):
        ids = _seed(db)
        results = search(db, "default", ids["agent_id"], "search")
        assert len(results) >= 1
        assert results[0]["conv_id"] == "conv-a"
        assert results[0]["match_count"] >= 1
        assert results[0]["title"] == "Search Feature Build"
        assert results[0]["tap_id"] is not None

    def test_no_match(self, db):
        ids = _seed(db)
        results = search(db, "default", ids["agent_id"], "nonexistent_xyz_term")
        assert results == []

    def test_returns_sample(self, db):
        ids = _seed(db)
        results = search(db, "default", ids["agent_id"], "database bug")
        assert len(results) == 1
        assert results[0]["sample"] is not None
        assert results[0]["sample"]["role"] == "user"

    def test_wrong_agent(self, db):
        _seed(db)
        other_id = _ensure_agent(db, "other-agent")
        results = search(db, "other-agent", other_id, "search")
        assert results == []


class TestSearchSummaries:
    def test_finds_in_title(self, db):
        ids = _seed(db)
        results = search_summaries(db, "default", ids["agent_id"], "Search Feature")
        assert len(results) >= 1
        assert any(r["tap_id"] and r["title"] == "Search Feature Build" for r in results)

    def test_finds_in_content(self, db):
        ids = _seed(db)
        results = search_summaries(db, "default", ids["agent_id"], "keyword")
        assert len(results) >= 1

    def test_filter_by_level(self, db):
        ids = _seed(db)
        results = search_summaries(db, "default", ids["agent_id"], "search", level=1)
        assert all(r["level"] == 1 for r in results)

    def test_empty(self, db):
        agent_id = _ensure_agent(db, "default")
        results = search_summaries(db, "default", agent_id, "xyz")
        assert results == []


# ── recall tests ──────────────────────────────────────────────────────

class TestRecall:
    def test_single_date_returns_daily(self, db):
        ids = _seed(db)
        records = recall(db, "default", ids["agent_id"], "2026-03-01")
        assert len(records) == 1
        assert records[0]["tap_level"] == 1
        assert records[0]["tap_title"] == "Search and Bug Fixes"

    def test_single_date_falls_back_to_l0(self, db):
        ids = _seed(db)
        records = recall(db, "default", ids["agent_id"], "2026-03-02")
        assert len(records) == 1
        assert records[0]["tap_level"] == 0
        assert records[0]["tap_title"] == "Tree Display"

    def test_single_date_no_data(self, db):
        ids = _seed(db)
        records = recall(db, "default", ids["agent_id"], "2026-04-01")
        assert records == []

    def test_range_returns_weekly(self, db):
        ids = _seed(db)
        records = recall(db, "default", ids["agent_id"], "2026-03-01", "2026-03-07")
        assert len(records) == 1
        assert records[0]["tap_level"] == 2

    def test_range_falls_back_to_dailies(self, db):
        ids = _seed(db)
        records = recall(db, "default", ids["agent_id"], "2026-03-01", "2026-03-02")
        # Range doesn't fully match the weekly (which is 01-07), so falls back
        # The weekly covers this range, so it should match
        assert len(records) >= 1


class TestShow:
    def test_existing_record(self, db):
        ids = _seed(db)
        record = show(db, ids["daily"])
        assert record is not None
        assert record["tap_title"] == "Search and Bug Fixes"
        assert record["tap_level"] == 1

    def test_missing_record(self, db):
        record = show(db, 9999)
        assert record is None


class TestConversations:
    def test_lists_all(self, db):
        ids = _seed(db)
        convs = conversations(db, "default", agent_id=ids["agent_id"])
        assert len(convs) == 3
        # Most recent first
        assert convs[0]["conv_id"] == "conv-c"

    def test_lists_with_counts(self, db):
        ids = _seed(db)
        convs = conversations(db, "default", agent_id=ids["agent_id"])
        conv_a = [c for c in convs if c["conv_id"] == "conv-a"][0]
        assert conv_a["msg_count"] == 2

    def test_empty(self, db):
        agent_id = _ensure_agent(db, "default")
        convs = conversations(db, "default", agent_id=agent_id)
        assert convs == []

    def test_no_agent_filter(self, db):
        _seed(db)
        convs = conversations(db, None)
        assert len(convs) == 3


class TestShowConversation:
    def test_full_id(self, db):
        _seed(db)
        result = show_conversation(db, "conv-a")
        assert result is not None
        assert result["conv_id"] == "conv-a"
        assert result["msg_count"] == 2
        assert result["messages"][0]["role"] == "user"

    def test_prefix(self, db):
        _seed(db)
        result = show_conversation(db, "conv-a")
        assert result is not None

    def test_not_found(self, db):
        result = show_conversation(db, "nonexistent")
        assert result is None


# ── tree tests ────────────────────────────────────────────────────────

class TestTree:
    def test_full_hierarchy(self, db):
        ids = _seed(db)
        data = tree(db, "default", ids["agent_id"])
        assert len(data["monthlies"]) == 1

        monthly = data["monthlies"][0]
        assert monthly["title"] == "March 2026"
        assert len(monthly["weeklies"]) == 1

        weekly = monthly["weeklies"][0]
        assert weekly["title"] == "Week of Mar 1"
        assert len(weekly["dailies"]) == 1

        daily = weekly["dailies"][0]
        assert daily["title"] == "Search and Bug Fixes"
        assert daily["l0_count"] == 2

    def test_empty(self, db):
        agent_id = _ensure_agent(db, "default")
        data = tree(db, "default", agent_id)
        assert data["monthlies"] == []
        assert data["orphaned_weeklies"] == []
        assert data["orphaned_dailies"] == []

    def test_orphaned_daily(self, db):
        agent_id = _ensure_agent(db, "default")
        _tap(db, "default", 1, "Orphan Daily", "No parent.",
             tap_date="2026-02-15", agent_id=agent_id)
        data = tree(db, "default", agent_id)
        assert len(data["orphaned_dailies"]) == 1
        assert data["orphaned_dailies"][0]["title"] == "Orphan Daily"

    def test_orphaned_weekly(self, db):
        agent_id = _ensure_agent(db, "default")
        _tap(db, "default", 2, "Orphan Weekly", "No parent.",
             date_start="2026-02-10", date_end="2026-02-16", agent_id=agent_id)
        data = tree(db, "default", agent_id)
        assert len(data["orphaned_weeklies"]) == 1


# ── stats tests ───────────────────────────────────────────────────────

class TestStats:
    def test_counts(self, db):
        ids = _seed(db)
        s = stats(db, "default", ids["agent_id"])
        assert s["levels"][0]["count"] == 3  # 3 L0s
        assert s["levels"][1]["count"] == 1  # 1 daily
        assert s["levels"][2]["count"] == 1  # 1 weekly
        assert s["levels"][3]["count"] == 1  # 1 monthly
        assert s["levels"][4]["count"] == 0  # no yearly
        assert s["conversations"] == 3
        assert s["messages"] == 4
        assert s["total_records"] == 6
        assert s["total_chars"] > 0
        assert s["est_tokens"] == s["total_chars"] // 4

    def test_empty(self, db):
        agent_id = _ensure_agent(db, "default")
        s = stats(db, "default", agent_id)
        assert s["total_records"] == 0
        assert s["conversations"] == 0


class TestStatus:
    def test_healthy(self, db):
        ids = _seed(db)
        # conv-c has an L0 but no daily — mark it summarized
        # Actually _seed already creates L0 for conv-c, but no daily for Mar 2
        st = status(db, "default", ids["agent_id"])
        assert st["agent"] == "default"
        assert st["date_range"] is not None
        assert st["date_range"]["first"] == "2026-03-01"

    def test_empty(self, db):
        agent_id = _ensure_agent(db, "default")
        st = status(db, "default", agent_id)
        assert st["health"] == "empty"
        assert st["unsummarized"] == 0

    def test_needs_catchup(self, db):
        # Add a conversation with no L0
        agent_id = _ensure_agent(db, "default")
        _msg(db, "default", "conv-x", "Unsummarized content", "2026-03-03T10:00:00", 1, agent_id=agent_id)
        st = status(db, "default", agent_id)
        assert st["health"] == "needs_catchup"
        assert st["unsummarized"] == 1

    def test_missing_dailies(self, db):
        ids = _seed(db)
        # conv-c has L0 on 2026-03-02 but no daily for that date
        st = status(db, "default", ids["agent_id"])
        assert st["missing_dailies"] >= 1
