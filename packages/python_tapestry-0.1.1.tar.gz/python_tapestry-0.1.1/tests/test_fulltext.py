"""Tests for FTS5 fulltext search and unified two-layer search."""

import pytest

from tapestry.db import Database
from tapestry.schema import init_db, rebuild_fts
from tapestry.query.fulltext import (
    _sanitize_fts_query,
    fulltext_messages,
    fulltext_search,
    fulltext_summaries,
)
from tapestry.query.unified import unified_search


# ── helpers ──────────────────────────────────────────────────────────


def _ensure_agent(db, agent="test"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _tap(db, agent, level, title, content, tap_date=None,
         date_start=None, date_end=None, source=None, agent_id=None):
    """Insert a tapestry summary record."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date,
            tap_date_start, tap_date_end, tap_source)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, level, title, content, tap_date, date_start, date_end, source),
    )


def _msg(db, agent, conv_id, content, timestamp, order=1, role="user", agent_id=None):
    """Insert a tapestry message record."""
    db.sql(
        """INSERT INTO tapestry_messages
           (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role,
            tmsg_content, tmsg_order, tmsg_timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, f"uuid-{conv_id}-{order}", conv_id, role, content, order, timestamp),
    )


def _seed(db):
    """Seed test data. Triggers auto-populate FTS on insert."""
    agent_id_test = _ensure_agent(db, "test")
    agent_id_other = _ensure_agent(db, "other")

    _msg(db, "test", "conv-1", "Built the FTS5 search feature today", "2026-03-01T10:00:00", 1, agent_id=agent_id_test)
    _msg(db, "test", "conv-1", "It uses BM25 ranking for relevance", "2026-03-01T10:05:00", 2, "assistant", agent_id=agent_id_test)
    _msg(db, "test", "conv-2", "Fixed the database migration bug", "2026-03-01T14:00:00", 1, agent_id=agent_id_test)
    _msg(db, "test", "conv-3", "Discussed patent filing with Sue Breault", "2026-03-02T09:00:00", 1, agent_id=agent_id_test)
    _msg(db, "other", "conv-4", "This belongs to a different agent", "2026-03-02T10:00:00", 1, agent_id=agent_id_other)

    _tap(db, "test", 0, "FTS5 Search Feature", "Built fulltext search with BM25 ranking.",
         tap_date="2026-03-01", source="conv-1", agent_id=agent_id_test)
    _tap(db, "test", 0, "Database Migration Fix", "Fixed connection retry and migration logic.",
         tap_date="2026-03-01", source="conv-2", agent_id=agent_id_test)
    _tap(db, "test", 0, "Patent Strategy", "Discussed patent filing for the DI platform.",
         tap_date="2026-03-02", source="conv-3", agent_id=agent_id_test)
    _tap(db, "test", 1, "Search and DB Work", "Built FTS5 search and fixed migration bugs.",
         tap_date="2026-03-01", agent_id=agent_id_test)

    return agent_id_test


# ── fulltext_summaries ───────────────────────────────────────────────


class TestFulltextSummaries:
    def test_empty_db(self, db):
        agent_id = _ensure_agent(db, "test")
        results = fulltext_summaries(db, "test", agent_id, "anything")
        assert results == []

    def test_finds_matching_title(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "FTS5")
        assert len(results) >= 1
        assert results[0]["title"] == "FTS5 Search Feature"
        assert results[0]["source"] == "summary"

    def test_finds_matching_content(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "BM25 ranking")
        assert len(results) >= 1

    def test_filter_by_level(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "search", level=1)
        assert all(r["level"] == 1 for r in results)

    def test_level_excludes_other_levels(self, db):
        agent_id = _seed(db)
        results_l0 = fulltext_summaries(db, "test", agent_id, "search", level=0)
        results_l1 = fulltext_summaries(db, "test", agent_id, "search", level=1)
        tap_ids_l0 = {r["tap_id"] for r in results_l0}
        tap_ids_l1 = {r["tap_id"] for r in results_l1}
        assert tap_ids_l0.isdisjoint(tap_ids_l1)

    def test_wrong_agent(self, db):
        _seed(db)
        nonexistent_id = _ensure_agent(db, "nonexistent")
        results = fulltext_summaries(db, "nonexistent", nonexistent_id, "search")
        assert results == []

    def test_agent_isolation(self, db):
        _seed(db)
        other_id = _ensure_agent(db, "other")
        results = fulltext_summaries(db, "other", other_id, "search")
        assert results == []

    def test_bm25_scores_non_negative(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "search")
        assert len(results) >= 1
        for r in results:
            assert r["score"] >= 0

    def test_top_n_limits(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "search", top_n=1)
        assert len(results) <= 1

    def test_empty_query(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "")
        assert results == []

    def test_result_fields(self, db):
        agent_id = _seed(db)
        results = fulltext_summaries(db, "test", agent_id, "patent")
        assert len(results) >= 1
        r = results[0]
        assert "tap_id" in r
        assert "level" in r
        assert "title" in r
        assert "date" in r
        assert "score" in r
        assert "preview" in r
        assert r["source"] == "summary"
        assert r["conv_id"] is None


# ── fulltext_messages ────────────────────────────────────────────────


class TestFulltextMessages:
    def test_empty_db(self, db):
        agent_id = _ensure_agent(db, "test")
        results = fulltext_messages(db, "test", agent_id, "anything")
        assert results == []

    def test_finds_messages(self, db):
        agent_id = _seed(db)
        results = fulltext_messages(db, "test", agent_id, "BM25")
        assert len(results) >= 1
        assert results[0]["source"] == "message"

    def test_groups_by_conversation(self, db):
        agent_id = _seed(db)
        results = fulltext_messages(db, "test", agent_id, "FTS5")
        conv_ids = [r["conv_id"] for r in results]
        assert len(conv_ids) == len(set(conv_ids))

    def test_enriches_with_l0(self, db):
        agent_id = _seed(db)
        results = fulltext_messages(db, "test", agent_id, "FTS5")
        hit = [r for r in results if r["conv_id"] == "conv-1"]
        assert len(hit) == 1
        assert hit[0]["tap_id"] is not None
        assert hit[0]["title"] == "FTS5 Search Feature"

    def test_no_l0_fallback(self, db):
        """Messages without an L0 summary still return results."""
        agent_id = _ensure_agent(db, "test")
        _msg(db, "test", "conv-orphan", "Orphan conversation about testing", "2026-03-03T10:00:00", 1, agent_id=agent_id)
        results = fulltext_messages(db, "test", agent_id, "orphan")
        assert len(results) == 1
        assert results[0]["tap_id"] is None
        assert "message hit" in results[0]["title"]

    def test_agent_isolation(self, db):
        agent_id = _seed(db)
        results = fulltext_messages(db, "test", agent_id, "different agent")
        assert results == []

    def test_proper_noun_search(self, db):
        agent_id = _seed(db)
        results = fulltext_messages(db, "test", agent_id, "Sue Breault")
        assert len(results) >= 1
        assert results[0]["conv_id"] == "conv-3"


# ── fulltext_search (combined) ───────────────────────────────────────


class TestFulltextCombined:
    def test_returns_both_sources(self, db):
        agent_id = _seed(db)
        results = fulltext_search(db, "test", agent_id, "search")
        sources = {r["source"] for r in results}
        assert "summary" in sources or "message" in sources

    def test_sorted_by_score(self, db):
        agent_id = _seed(db)
        results = fulltext_search(db, "test", agent_id, "search")
        if len(results) > 1:
            scores = [r["score"] for r in results]
            assert scores == sorted(scores, reverse=True)

    def test_top_n_per_source(self, db):
        agent_id = _seed(db)
        results = fulltext_search(db, "test", agent_id, "search", top_n=1)
        # top_n applies per source, so max 2 results (1 summary + 1 message)
        assert len(results) <= 2


# ── unified_search ───────────────────────────────────────────────────


class TestUnifiedSearch:
    def test_auto_mode(self, db):
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "patent filing", mode="auto")
        assert len(results) >= 1

    def test_fulltext_mode(self, db):
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "patent", mode="fulltext")
        assert len(results) >= 1
        assert all(r.get("mode_used") == "fulltext" for r in results)

    def test_semantic_mode(self, db):
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "patent intellectual property", mode="semantic")
        assert len(results) >= 1
        assert all(r.get("mode_used") == "semantic" for r in results)

    def test_deduplication(self, db):
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "search", mode="auto")
        tap_ids = [r["tap_id"] for r in results if r["tap_id"] is not None]
        assert len(tap_ids) == len(set(tap_ids))

    def test_invalid_mode_defaults_to_auto(self, db):
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "patent", mode="invalid")
        assert len(results) >= 1

    def test_top_n_respected(self, db):
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "search", mode="auto", top_n=2)
        assert len(results) <= 2

    def test_proper_noun_via_auto(self, db):
        """Auto mode should find proper nouns in messages even if summaries miss them."""
        agent_id = _seed(db)
        results = unified_search(db, "test", agent_id, "Sue Breault", mode="auto")
        assert len(results) >= 1


# ── rebuild_fts ──────────────────────────────────────────────────────


class TestRebuildFts:
    def test_rebuild_populates_index(self, db):
        _seed(db)
        counts = rebuild_fts(db)
        assert counts["summaries"] >= 4
        assert counts["messages"] >= 5

    def test_search_works_after_rebuild(self, db):
        agent_id = _seed(db)
        rebuild_fts(db)
        results = fulltext_summaries(db, "test", agent_id, "patent")
        assert len(results) >= 1

    def test_rebuild_idempotent(self, db):
        _seed(db)
        counts1 = rebuild_fts(db)
        counts2 = rebuild_fts(db)
        assert counts1 == counts2


# ── _sanitize_fts_query ─────────────────────────────────────────────


class TestSanitizeFtsQuery:
    def test_normal_query(self):
        assert _sanitize_fts_query("hello world") == '"hello" "world"'

    def test_single_word(self):
        assert _sanitize_fts_query("patent") == '"patent"'

    def test_preserves_explicit_or(self):
        assert _sanitize_fts_query("patent OR filing") == "patent OR filing"

    def test_preserves_explicit_and(self):
        assert _sanitize_fts_query("patent AND filing") == "patent AND filing"

    def test_preserves_explicit_not(self):
        assert _sanitize_fts_query("patent NOT filing") == "patent NOT filing"

    def test_preserves_phrases(self):
        assert _sanitize_fts_query('"exact phrase"') == '"exact phrase"'

    def test_empty_query(self):
        assert _sanitize_fts_query("") == ""

    def test_whitespace_only(self):
        assert _sanitize_fts_query("   ") == ""
