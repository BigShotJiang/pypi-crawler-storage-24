"""Tests for drift detection (engine/drift.py)."""

import pytest

from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.engine.drift import (
    _compute_similarity,
    measure_drift,
    severity_description,
    severity_label,
)


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "test.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


def _ensure_agent(db, agent="test"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _tap(db, agent, level, title, content, tap_date=None,
         date_start=None, date_end=None, source=None, parent_id=None, agent_id=None):
    """Insert a tapestry record and return tap_id."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date,
            tap_date_start, tap_date_end, tap_source, tap_parent_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, level, title, content, tap_date, date_start, date_end, source, parent_id),
    )


class FakeLLM:
    """Fake LLM that returns deterministic content for testing."""

    def __init__(self, response="Regenerated summary content about testing and development."):
        self.response = response
        self.call_count = 0

    def request(self, messages, max_tokens=4000):
        self.call_count += 1
        return self.response

    def title(self, messages):
        return "Test Title"


class FakeConfig:
    """Minimal config for drift tests."""

    def __init__(self):
        self.agent_name = "TestAgent"
        self.user_name = "TestUser"


# ── severity_label ───────────────────────────────────────────────────


class TestSeverityLabel:
    def test_negligible(self):
        assert severity_label(0.98) == "negligible"
        assert severity_label(0.95) == "negligible"
        assert severity_label(1.0) == "negligible"

    def test_minor(self):
        assert severity_label(0.90) == "minor"
        assert severity_label(0.85) == "minor"

    def test_moderate(self):
        assert severity_label(0.80) == "moderate"
        assert severity_label(0.70) == "moderate"

    def test_significant(self):
        assert severity_label(0.60) == "significant"
        assert severity_label(0.50) == "significant"

    def test_major(self):
        assert severity_label(0.40) == "major"
        assert severity_label(0.0) == "major"

    def test_boundary_values(self):
        assert severity_label(0.9499) == "minor"
        assert severity_label(0.8499) == "moderate"
        assert severity_label(0.6999) == "significant"
        assert severity_label(0.4999) == "major"


# ── severity_description ─────────────────────────────────────────────


class TestSeverityDescription:
    def test_no_ancestors(self):
        desc = severity_description([])
        assert "No ancestors" in desc

    def test_single_ancestor(self):
        desc = severity_description([
            {"level": 1, "severity": "minor"}
        ])
        assert "slightly alter your daily" in desc

    def test_multiple_ancestors(self):
        desc = severity_description([
            {"level": 1, "severity": "significant"},
            {"level": 2, "severity": "minor"},
        ])
        assert "significantly alter your daily" in desc
        assert "slightly alter your weekly" in desc

    def test_all_severities(self):
        for sev in ("negligible", "minor", "moderate", "significant", "major"):
            desc = severity_description([{"level": 1, "severity": sev}])
            assert "daily" in desc


# ── _compute_similarity ──────────────────────────────────────────────


class TestComputeSimilarity:
    def test_identical_texts(self):
        score = _compute_similarity("hello world test", "hello world test")
        assert score == pytest.approx(1.0)

    def test_completely_different(self):
        score = _compute_similarity(
            "python database migration schema",
            "garden irrigation soil moisture"
        )
        assert score < 0.3

    def test_partially_similar(self):
        score = _compute_similarity(
            "python database migration schema queries",
            "database schema update migration tool"
        )
        assert 0.3 < score < 1.0

    def test_empty_text_returns_zero(self):
        assert _compute_similarity("", "hello") == 0.0
        assert _compute_similarity("hello", "") == 0.0
        assert _compute_similarity("", "") == 0.0


# ── measure_drift ────────────────────────────────────────────────────


class TestMeasureDrift:
    def test_nonexistent_tap_id(self, db):
        agent_id = _ensure_agent(db, "test")
        llm = FakeLLM()
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, 9999)
        assert "error" in result

    def test_l0_no_parents(self, db):
        """An L0 with no parent should return empty ancestors."""
        agent_id = _ensure_agent(db, "test")
        l0_id = _tap(db, "test", 0, "Session One",
                      "Built a new feature for the dashboard.",
                      tap_date="2026-03-01", source="conv-1", agent_id=agent_id)
        llm = FakeLLM()
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)
        assert result["target"]["tap_id"] == l0_id
        assert result["ancestors"] == []
        assert "No ancestors" in result["description"]

    def test_l0_with_daily_parent(self, db):
        """An L0 under a daily should measure drift at the daily level."""
        agent_id = _ensure_agent(db, "test")
        daily_id = _tap(db, "test", 1, "Daily Summary",
                        "Worked on dashboard and API integration.",
                        tap_date="2026-03-01", agent_id=agent_id)
        l0_id = _tap(db, "test", 0, "Session One",
                      "Built the dashboard feature with React components.",
                      tap_date="2026-03-01", source="conv-1", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("A regenerated daily about dashboard and API work.")
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)

        assert result["target"]["tap_id"] == l0_id
        assert len(result["ancestors"]) == 1
        assert result["ancestors"][0]["level"] == 1
        assert result["ancestors"][0]["level_name"] == "L1 daily"
        assert 0.0 <= result["ancestors"][0]["score"] <= 1.0
        assert result["ancestors"][0]["severity"] in (
            "negligible", "minor", "moderate", "significant", "major"
        )

    def test_full_hierarchy_walk(self, db):
        """L0 → daily → weekly → monthly should measure drift at all 3 ancestor levels."""
        agent_id = _ensure_agent(db, "test")
        monthly_id = _tap(db, "test", 3, "March Monthly",
                          "Full monthly summary of March development work.",
                          tap_date="2026-03-01",
                          date_start="2026-03-01", date_end="2026-03-31", agent_id=agent_id)
        weekly_id = _tap(db, "test", 2, "Week 1",
                         "Weekly summary covering dashboard and API.",
                         tap_date="2026-03-01",
                         date_start="2026-03-01", date_end="2026-03-07",
                         parent_id=monthly_id, agent_id=agent_id)
        daily_id = _tap(db, "test", 1, "March 1 Daily",
                        "Daily summary for March 1.",
                        tap_date="2026-03-01", parent_id=weekly_id, agent_id=agent_id)
        l0_id = _tap(db, "test", 0, "Session One",
                      "Built the main dashboard component.",
                      tap_date="2026-03-01", source="conv-1", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("Regenerated content about development work.")
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)

        assert len(result["ancestors"]) == 3
        levels = [a["level"] for a in result["ancestors"]]
        assert levels == [1, 2, 3]  # daily, weekly, monthly — bottom to top

    def test_drift_scores_populated(self, db):
        """Each ancestor should have score, severity, and char counts."""
        agent_id = _ensure_agent(db, "test")
        daily_id = _tap(db, "test", 1, "Daily",
                        "Original daily content about testing.",
                        tap_date="2026-03-01", agent_id=agent_id)
        l0_id = _tap(db, "test", 0, "Session",
                      "Testing session content.",
                      tap_date="2026-03-01", source="conv-1", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("Regenerated daily about testing session work.")
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)

        ancestor = result["ancestors"][0]
        assert "score" in ancestor
        assert "severity" in ancestor
        assert "chars_current" in ancestor
        assert "chars_regen" in ancestor
        assert ancestor["chars_current"] > 0
        assert ancestor["chars_regen"] > 0

    def test_llm_called_per_ancestor(self, db):
        """LLM should be called once per ancestor for regeneration."""
        agent_id = _ensure_agent(db, "test")
        weekly_id = _tap(db, "test", 2, "Weekly",
                         "Weekly content.",
                         tap_date="2026-03-01",
                         date_start="2026-03-01", date_end="2026-03-07", agent_id=agent_id)
        daily_id = _tap(db, "test", 1, "Daily",
                        "Daily content.",
                        tap_date="2026-03-01", parent_id=weekly_id, agent_id=agent_id)
        l0_id = _tap(db, "test", 0, "Session",
                      "Session content.",
                      tap_date="2026-03-01", source="conv-1", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("Regenerated content.")
        config = FakeConfig()
        measure_drift(db, llm, config, "test", agent_id, l0_id)

        assert llm.call_count == 2  # daily + weekly

    def test_no_children_returns_score_1(self, db):
        """An ancestor with no children can't be regenerated — score defaults to 1.0."""
        agent_id = _ensure_agent(db, "test")
        daily_id = _tap(db, "test", 1, "Empty Daily",
                        "Daily with no L0 children.",
                        tap_date="2026-03-01", agent_id=agent_id)
        # Create an L0 that points to this daily, but daily has no children in query
        # because we link via parent_id, and the query looks for children OF the daily
        l0_id = _tap(db, "test", 0, "Orphan Session",
                      "Session content.",
                      tap_date="2026-03-01", source="conv-orphan", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("Should not be called.")
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)

        # The daily's children query finds L0s with parent_id=daily_id
        # Our L0 IS the child, so regeneration should work
        assert len(result["ancestors"]) == 1

    def test_result_has_description(self, db):
        """Result should include a human-readable description."""
        agent_id = _ensure_agent(db, "test")
        daily_id = _tap(db, "test", 1, "Daily",
                        "Daily summary content.",
                        tap_date="2026-03-01", agent_id=agent_id)
        l0_id = _tap(db, "test", 0, "Session",
                      "Session content.",
                      tap_date="2026-03-01", source="conv-1", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("Regenerated daily content.")
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)

        assert "description" in result
        assert isinstance(result["description"], str)
        assert len(result["description"]) > 0

    def test_l4_yearly_in_chain(self, db):
        """Full chain through yearly should work."""
        agent_id = _ensure_agent(db, "test")
        yearly_id = _tap(db, "test", 4, "2026 Yearly",
                         "Yearly summary of all work.",
                         tap_date="2026-01-01",
                         date_start="2026-01-01", date_end="2026-12-31", agent_id=agent_id)
        monthly_id = _tap(db, "test", 3, "March Monthly",
                          "Monthly summary.",
                          tap_date="2026-03-01",
                          date_start="2026-03-01", date_end="2026-03-31",
                          parent_id=yearly_id, agent_id=agent_id)
        weekly_id = _tap(db, "test", 2, "Week 1",
                         "Weekly summary.",
                         tap_date="2026-03-01",
                         date_start="2026-03-01", date_end="2026-03-07",
                         parent_id=monthly_id, agent_id=agent_id)
        daily_id = _tap(db, "test", 1, "March 1",
                        "Daily summary.",
                        tap_date="2026-03-01", parent_id=weekly_id, agent_id=agent_id)
        l0_id = _tap(db, "test", 0, "Session",
                      "Session work.",
                      tap_date="2026-03-01", source="conv-1", parent_id=daily_id, agent_id=agent_id)

        llm = FakeLLM("Regenerated content.")
        config = FakeConfig()
        result = measure_drift(db, llm, config, "test", agent_id, l0_id)

        assert len(result["ancestors"]) == 4
        levels = [a["level"] for a in result["ancestors"]]
        assert levels == [1, 2, 3, 4]
