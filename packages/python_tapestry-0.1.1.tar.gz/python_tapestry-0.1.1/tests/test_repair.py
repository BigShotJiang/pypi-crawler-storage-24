"""Tests for engine/repair.py and engine/catchup.py."""

from unittest.mock import MagicMock

import pytest

from tapestry.config import AgentConfig, LLMConfig, TapestryConfig
from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.engine.repair import repair_weekly, repair_monthly


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "test.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


@pytest.fixture
def config(tmp_path):
    return TapestryConfig(
        db_path=str(tmp_path / "db" / "test.db"),
        project_dir=str(tmp_path),
        agent_name="TestAgent",
        user_name="TestUser",
        llm=LLMConfig(provider="groq", api_key="test"),
        agents={"default": AgentConfig()},
    )


@pytest.fixture
def mock_llm():
    llm = MagicMock()
    llm.title.return_value = "Repaired Title"
    llm.request.return_value = "Repaired content."
    return llm


def _ensure_agent(db, agent="default"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _insert_messages(db, agent, conv_id, timestamps, agent_id=None):
    """Insert test messages for a conversation."""
    for i, ts in enumerate(timestamps):
        db.sql(
            """INSERT INTO tapestry_messages
               (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (agent, agent_id, f"uuid-{conv_id}-{i}", conv_id, "user" if i % 2 == 0 else "assistant",
             f"Message {i}", i + 1, ts),
        )


class TestRepairWeekly:
    def test_repairs_missing_l0s_dailies_and_weekly(self, db, config, mock_llm):
        """Repair cascade: creates L0s, dailies, then weekly."""
        agent_id = _ensure_agent(db, "default")
        # Insert raw messages for two days
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00", "2026-03-02T11:00:00"], agent_id=agent_id)
        _insert_messages(db, "default", "conv-2", ["2026-03-03T10:00:00"], agent_id=agent_id)

        generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}
        repair_item = {"start": "2026-03-02", "end": "2026-03-08", "range": "Mar 02-Mar 08"}

        repair_weekly(db, mock_llm, config, "default", agent_id, repair_item, generated)

        # Should have created 2 L0s, 2 dailies, 1 weekly
        assert generated["l0"] == 2
        assert generated["l1"] == 2
        assert generated["l2"] == 1

        # Weekly should exist
        weekly = db.sql(
            """SELECT tap_id FROM tapestry WHERE tap_level = 2 AND tap_agent = 'default'
               AND tap_date_start = '2026-03-02' AND tap_date_end = '2026-03-08'""",
            single=True,
        )
        assert weekly is not None

    def test_skips_existing_l0s_and_dailies(self, db, config, mock_llm):
        """Doesn't regenerate L0s or dailies that already exist."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)

        # Pre-create L0 and daily
        l0_id = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "Existing L0", "Content", "2026-03-02", "conv-1"),
        )
        daily_id = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end)
               VALUES (?, ?, 1, ?, ?, ?, ?, ?)""",
            ("default", agent_id, "Existing Daily", "Content", "2026-03-02", "2026-03-02", "2026-03-02"),
        )

        generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}
        repair_item = {"start": "2026-03-02", "end": "2026-03-08", "range": "Mar 02-Mar 08"}

        repair_weekly(db, mock_llm, config, "default", agent_id, repair_item, generated)

        # Only the weekly should be new
        assert generated["l0"] == 0
        assert generated["l1"] == 0
        assert generated["l2"] == 1


class TestRepairMonthly:
    def test_repairs_full_cascade(self, db, config, mock_llm):
        """Repairs missing weeklies and generates monthly."""
        agent_id = _ensure_agent(db, "default")
        # Insert raw messages across two weeks in March 2026
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)
        _insert_messages(db, "default", "conv-2", ["2026-03-09T10:00:00"], agent_id=agent_id)

        generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}
        repair_item = {"start": "2026-03-01", "end": "2026-03-31", "range": "March 2026"}

        repair_monthly(db, mock_llm, config, "default", agent_id, repair_item, generated)

        # L0s + dailies + weeklies + monthly
        assert generated["l0"] == 2
        assert generated["l1"] == 2
        assert generated["l2"] >= 1  # At least the weeks with data
        assert generated["l3"] == 1

    def test_skips_weeks_with_no_data(self, db, config, mock_llm):
        """Weeks with no conversations are skipped."""
        agent_id = _ensure_agent(db, "default")
        # Only one conversation in the whole month
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)

        generated = {"l0": 0, "l1": 0, "l2": 0, "l3": 0}
        repair_item = {"start": "2026-03-01", "end": "2026-03-31", "range": "March 2026"}

        repair_monthly(db, mock_llm, config, "default", agent_id, repair_item, generated)

        # Only 1 L0, 1 daily, 1 weekly (for the week with data), 1 monthly
        assert generated["l0"] == 1
        assert generated["l1"] == 1
        assert generated["l2"] == 1
        assert generated["l3"] == 1
