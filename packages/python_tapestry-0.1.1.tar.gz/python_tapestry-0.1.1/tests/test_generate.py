"""Tests for engine/generate.py — L0 through L3 generation."""

from unittest.mock import MagicMock

import pytest

from tapestry.config import AgentConfig, LLMConfig, TapestryConfig
from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.engine.generate import (
    auto_generate_daily,
    auto_generate_l0,
    auto_generate_monthly,
    auto_generate_weekly,
)


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "test.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


@pytest.fixture
def config(tmp_path):
    return TapestryConfig(
        db_path=str(tmp_path / "db" / "test.db"),
        project_dir=str(tmp_path),
        agent_name="TestAgent",
        user_name="TestUser",
        llm=LLMConfig(provider="groq", api_key="test"),
        agents={"default": AgentConfig()},
    )


@pytest.fixture
def mock_llm():
    llm = MagicMock()
    llm.title.return_value = "Generated Title"
    llm.request.return_value = "Generated content summary."
    return llm


def _ensure_agent(db, agent="default"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _insert_messages(db, agent, conv_id, timestamps, agent_id=None):
    """Insert test messages for a conversation."""
    for i, ts in enumerate(timestamps):
        db.sql(
            """INSERT INTO tapestry_messages
               (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (agent, agent_id, f"uuid-{conv_id}-{i}", conv_id, "user" if i % 2 == 0 else "assistant",
             f"Message {i} content", i + 1, ts),
        )


class TestAutoGenerateL0:
    def test_generates_l0(self, db, config, mock_llm):
        """Generates L0 from conversation messages."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1",
                         ["2026-03-02T10:00:00", "2026-03-02T10:05:00"], agent_id=agent_id)

        tap_id = auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1")

        assert tap_id is not None
        row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
        assert row["tap_level"] == 0
        assert row["tap_title"] == "Generated Title"
        assert row["tap_content"] == "Generated content summary."
        assert row["tap_date"] == "2026-03-02"
        assert row["tap_source"] == "conv-1"

    def test_idempotent(self, db, config, mock_llm):
        """Skips if L0 already exists for conversation."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)

        tap_id_1 = auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1")
        tap_id_2 = auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1")

        assert tap_id_1 == tap_id_2
        # LLM should only be called once (2 calls: title + content)
        assert mock_llm.title.call_count == 1
        assert mock_llm.request.call_count == 1

    def test_no_messages_returns_none(self, db, config, mock_llm):
        """Returns None if no messages found for conversation."""
        agent_id = _ensure_agent(db, "default")
        result = auto_generate_l0(db, mock_llm, config, "default", agent_id, "nonexistent")
        assert result is None

    def test_links_messages(self, db, config, mock_llm):
        """Messages are linked to the generated L0 via tmsg_tap_id."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1",
                         ["2026-03-02T10:00:00", "2026-03-02T10:05:00"], agent_id=agent_id)

        tap_id = auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1")

        msgs = db.sql("SELECT tmsg_tap_id FROM tapestry_messages WHERE tmsg_ref_conv_id = ?",
                       ("conv-1",))
        assert all(m["tmsg_tap_id"] == tap_id for m in msgs)

    def test_relinks_to_existing_daily(self, db, config, mock_llm):
        """If a daily exists for the same date, L0 gets parent_id set."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)
        daily_id = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end)
               VALUES (?, ?, 1, ?, ?, ?, ?, ?)""",
            ("default", agent_id, "Daily", "Daily content", "2026-03-02", "2026-03-02", "2026-03-02"),
        )

        tap_id = auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1")
        row = db.sql("SELECT tap_parent_id FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
        assert row["tap_parent_id"] == daily_id

    def test_uses_config_names_in_transcript(self, db, config, mock_llm):
        """Transcript uses agent_name and user_name from config."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)

        auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1")

        # Check the user content passed to llm.request
        call_args = mock_llm.request.call_args
        messages = call_args[0][0]
        user_msg = messages[1]["content"]
        assert "[TESTUSER]" in user_msg

    def test_with_context(self, db, config, mock_llm):
        """Context preamble is prepended to system prompt when provided."""
        agent_id = _ensure_agent(db, "default")
        _insert_messages(db, "default", "conv-1", ["2026-03-02T10:00:00"], agent_id=agent_id)
        context = [{"level": 1, "tap_id": 99, "title": "Prior", "content": "Prior work.", "range": "2026-03-01"}]

        auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-1", context_items=context)

        call_args = mock_llm.request.call_args
        system_msg = call_args[0][0][0]["content"]
        assert "PRIOR SESSIONS CONTEXT" in system_msg

    def test_passes_full_long_transcripts(self, db, config, mock_llm):
        """Long transcripts are passed through in full, never truncated."""
        agent_id = _ensure_agent(db, "default")
        # Insert a message with very long content
        db.sql(
            """INSERT INTO tapestry_messages
               (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            ("default", agent_id, "uuid-long", "conv-long", "user", "x" * 15000, 1, "2026-03-02T10:00:00"),
        )

        auto_generate_l0(db, mock_llm, config, "default", agent_id, "conv-long")

        call_args = mock_llm.request.call_args
        user_msg = call_args[0][0][1]["content"]
        assert "[TRUNCATED]" not in user_msg
        assert "x" * 15000 in user_msg


class TestAutoGenerateDaily:
    def test_generates_daily(self, db, config, mock_llm):
        """Generates L1 daily from L0s."""
        agent_id = _ensure_agent(db, "default")
        # Insert two L0s for the same date
        db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "Session 1", "Content 1", "2026-03-02", "conv-1"),
        )
        db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "Session 2", "Content 2", "2026-03-02", "conv-2"),
        )

        tap_id = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")

        assert tap_id is not None
        row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
        assert row["tap_level"] == 1
        assert row["tap_date"] == "2026-03-02"
        assert row["tap_date_start"] == "2026-03-02"
        assert row["tap_date_end"] == "2026-03-02"

    def test_idempotent(self, db, config, mock_llm):
        """Skips if daily already exists for date."""
        agent_id = _ensure_agent(db, "default")
        db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "Session 1", "Content 1", "2026-03-02", "conv-1"),
        )

        tap_id_1 = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")
        tap_id_2 = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")

        assert tap_id_1 == tap_id_2
        assert mock_llm.title.call_count == 1

    def test_no_l0s_returns_none(self, db, config, mock_llm):
        """Returns None if no L0s found for date."""
        agent_id = _ensure_agent(db, "default")
        result = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")
        assert result is None

    def test_links_l0s_as_children(self, db, config, mock_llm):
        """L0s get parent_id set to the daily."""
        agent_id = _ensure_agent(db, "default")
        l0_id = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "Session 1", "Content 1", "2026-03-02", "conv-1"),
        )

        daily_id = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")

        l0_row = db.sql("SELECT tap_parent_id FROM tapestry WHERE tap_id = ?", (l0_id,), single=True)
        assert l0_row["tap_parent_id"] == daily_id

    def test_source_tracks_l0_ids(self, db, config, mock_llm):
        """tap_source contains comma-separated L0 tap_ids."""
        agent_id = _ensure_agent(db, "default")
        id1 = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "S1", "C1", "2026-03-02", "conv-1"),
        )
        id2 = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "S2", "C2", "2026-03-02", "conv-2"),
        )

        daily_id = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")
        row = db.sql("SELECT tap_source FROM tapestry WHERE tap_id = ?", (daily_id,), single=True)
        assert str(id1) in row["tap_source"]
        assert str(id2) in row["tap_source"]

    def test_relinks_to_existing_weekly(self, db, config, mock_llm):
        """If a weekly covers this date, daily gets parent_id set."""
        agent_id = _ensure_agent(db, "default")
        weekly_id = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end)
               VALUES (?, ?, 2, ?, ?, ?, ?, ?)""",
            ("default", agent_id, "Week 1", "Weekly content", "2026-03-02", "2026-03-02", "2026-03-08"),
        )
        db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "Session 1", "Content 1", "2026-03-02", "conv-1"),
        )

        daily_id = auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")
        row = db.sql("SELECT tap_parent_id FROM tapestry WHERE tap_id = ?", (daily_id,), single=True)
        assert row["tap_parent_id"] == weekly_id

    def test_input_format(self, db, config, mock_llm):
        """Input to LLM contains session headings."""
        agent_id = _ensure_agent(db, "default")
        db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_source)
               VALUES (?, ?, 0, ?, ?, ?, ?)""",
            ("default", agent_id, "My Session", "Session content here", "2026-03-02", "conv-1"),
        )

        auto_generate_daily(db, mock_llm, config, "default", agent_id, "2026-03-02")

        call_args = mock_llm.request.call_args
        user_msg = call_args[0][0][1]["content"]
        assert "### Session 1: My Session" in user_msg
        assert "Session content here" in user_msg


def _insert_daily(db, agent, date_str, title="Daily Title", content="Daily content", agent_id=None):
    """Insert a L1 daily summary."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end)
           VALUES (?, ?, 1, ?, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, date_str, date_str, date_str),
    )


def _insert_weekly(db, agent, start, end, title="Weekly Title", content="Weekly content", agent_id=None):
    """Insert a L2 weekly summary."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end)
           VALUES (?, ?, 2, ?, ?, ?, ?, ?)""",
        (agent, agent_id, title, content, start, start, end),
    )


class TestAutoGenerateWeekly:
    def test_generates_weekly(self, db, config, mock_llm):
        """Generates L2 weekly from dailies."""
        agent_id = _ensure_agent(db, "default")
        _insert_daily(db, "default", "2026-03-02", "Mon work", "Built thing A", agent_id=agent_id)
        _insert_daily(db, "default", "2026-03-03", "Tue work", "Built thing B", agent_id=agent_id)

        tap_id = auto_generate_weekly(
            db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08"
        )

        assert tap_id is not None
        row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
        assert row["tap_level"] == 2
        assert row["tap_date_start"] == "2026-03-02"
        assert row["tap_date_end"] == "2026-03-08"

    def test_idempotent(self, db, config, mock_llm):
        """Skips if weekly already exists for date range."""
        agent_id = _ensure_agent(db, "default")
        _insert_daily(db, "default", "2026-03-02", agent_id=agent_id)

        id1 = auto_generate_weekly(db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08")
        id2 = auto_generate_weekly(db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08")

        assert id1 == id2
        assert mock_llm.title.call_count == 1

    def test_no_dailies_returns_none(self, db, config, mock_llm):
        """Returns None if no dailies found in range."""
        agent_id = _ensure_agent(db, "default")
        result = auto_generate_weekly(
            db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08"
        )
        assert result is None

    def test_links_dailies_as_children(self, db, config, mock_llm):
        """Dailies get parent_id set to the weekly."""
        agent_id = _ensure_agent(db, "default")
        d1 = _insert_daily(db, "default", "2026-03-02", agent_id=agent_id)
        d2 = _insert_daily(db, "default", "2026-03-03", agent_id=agent_id)

        weekly_id = auto_generate_weekly(
            db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08"
        )

        for did in (d1, d2):
            row = db.sql("SELECT tap_parent_id FROM tapestry WHERE tap_id = ?", (did,), single=True)
            assert row["tap_parent_id"] == weekly_id

    def test_source_tracks_daily_ids(self, db, config, mock_llm):
        """tap_source contains comma-separated daily tap_ids."""
        agent_id = _ensure_agent(db, "default")
        d1 = _insert_daily(db, "default", "2026-03-02", agent_id=agent_id)
        d2 = _insert_daily(db, "default", "2026-03-04", agent_id=agent_id)

        weekly_id = auto_generate_weekly(
            db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08"
        )
        row = db.sql("SELECT tap_source FROM tapestry WHERE tap_id = ?", (weekly_id,), single=True)
        assert str(d1) in row["tap_source"]
        assert str(d2) in row["tap_source"]

    def test_relinks_to_existing_monthly(self, db, config, mock_llm):
        """If a monthly covers this range, weekly gets parent_id set."""
        agent_id = _ensure_agent(db, "default")
        monthly_id = db.sql(
            """INSERT INTO tapestry
               (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end)
               VALUES (?, ?, 3, ?, ?, ?, ?, ?)""",
            ("default", agent_id, "March", "Monthly content", "2026-03-01", "2026-03-01", "2026-03-31"),
        )
        _insert_daily(db, "default", "2026-03-02", agent_id=agent_id)

        weekly_id = auto_generate_weekly(
            db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08"
        )
        row = db.sql(
            "SELECT tap_parent_id FROM tapestry WHERE tap_id = ?", (weekly_id,), single=True
        )
        assert row["tap_parent_id"] == monthly_id

    def test_input_format(self, db, config, mock_llm):
        """Input to LLM contains daily headings with dates."""
        agent_id = _ensure_agent(db, "default")
        _insert_daily(db, "default", "2026-03-02", "Dashboard Work", "Built the dashboard", agent_id=agent_id)

        auto_generate_weekly(db, mock_llm, config, "default", agent_id, "2026-03-02", "2026-03-08")

        call_args = mock_llm.request.call_args
        user_msg = call_args[0][0][1]["content"]
        assert "### 2026-03-02: Dashboard Work" in user_msg
        assert "Built the dashboard" in user_msg


class TestAutoGenerateMonthly:
    def test_generates_monthly(self, db, config, mock_llm):
        """Generates L3 monthly from weeklies."""
        agent_id = _ensure_agent(db, "default")
        _insert_weekly(db, "default", "2026-03-02", "2026-03-08", "Week 1", "Week 1 work", agent_id=agent_id)
        _insert_weekly(db, "default", "2026-03-09", "2026-03-15", "Week 2", "Week 2 work", agent_id=agent_id)

        tap_id = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)

        assert tap_id is not None
        row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
        assert row["tap_level"] == 3
        assert row["tap_date_start"] == "2026-03-01"
        assert row["tap_date_end"] == "2026-03-31"

    def test_idempotent(self, db, config, mock_llm):
        """Skips if monthly already exists."""
        agent_id = _ensure_agent(db, "default")
        _insert_weekly(db, "default", "2026-03-02", "2026-03-08", agent_id=agent_id)

        id1 = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)
        id2 = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)

        assert id1 == id2
        assert mock_llm.title.call_count == 1

    def test_no_weeklies_returns_none(self, db, config, mock_llm):
        """Returns None if no weeklies found for month."""
        agent_id = _ensure_agent(db, "default")
        result = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)
        assert result is None

    def test_links_weeklies_as_children(self, db, config, mock_llm):
        """Weeklies get parent_id set to the monthly."""
        agent_id = _ensure_agent(db, "default")
        w1 = _insert_weekly(db, "default", "2026-03-02", "2026-03-08", agent_id=agent_id)
        w2 = _insert_weekly(db, "default", "2026-03-09", "2026-03-15", agent_id=agent_id)

        monthly_id = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)

        for wid in (w1, w2):
            row = db.sql("SELECT tap_parent_id FROM tapestry WHERE tap_id = ?", (wid,), single=True)
            assert row["tap_parent_id"] == monthly_id

    def test_source_tracks_weekly_ids(self, db, config, mock_llm):
        """tap_source contains comma-separated weekly tap_ids."""
        agent_id = _ensure_agent(db, "default")
        w1 = _insert_weekly(db, "default", "2026-03-02", "2026-03-08", agent_id=agent_id)
        w2 = _insert_weekly(db, "default", "2026-03-09", "2026-03-15", agent_id=agent_id)

        monthly_id = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)
        row = db.sql("SELECT tap_source FROM tapestry WHERE tap_id = ?", (monthly_id,), single=True)
        assert str(w1) in row["tap_source"]
        assert str(w2) in row["tap_source"]

    def test_input_format(self, db, config, mock_llm):
        """Input to LLM contains weekly headings with date ranges."""
        agent_id = _ensure_agent(db, "default")
        _insert_weekly(db, "default", "2026-03-02", "2026-03-08", "Scrum Work", "Built scrum", agent_id=agent_id)

        auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 3)

        call_args = mock_llm.request.call_args
        user_msg = call_args[0][0][1]["content"]
        assert "### 2026-03-02 to 2026-03-08: Scrum Work" in user_msg
        assert "Built scrum" in user_msg

    def test_february_date_boundaries(self, db, config, mock_llm):
        """Correct date boundaries for February."""
        agent_id = _ensure_agent(db, "default")
        _insert_weekly(db, "default", "2026-02-02", "2026-02-08", agent_id=agent_id)

        tap_id = auto_generate_monthly(db, mock_llm, config, "default", agent_id, 2026, 2)

        row = db.sql("SELECT * FROM tapestry WHERE tap_id = ?", (tap_id,), single=True)
        assert row["tap_date_start"] == "2026-02-01"
        assert row["tap_date_end"] == "2026-02-28"
