"""Tests for cosine similarity search (query/cosine.py)."""

import pytest

from tapestry.db import Database
from tapestry.schema import init_db
from tapestry.query.cosine import cosine_search


@pytest.fixture
def db(tmp_path):
    database = Database(str(tmp_path / "db" / "test.db"))
    database.ensure_directory()
    init_db(database)
    yield database
    database.close()


def _ensure_agent(db, agent="test"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


def _tap(db, agent, level, title, content, tap_date=None,
         date_start=None, date_end=None, source=None, agent_id=None):
    """Insert a tapestry record and return tap_id."""
    return db.sql(
        """INSERT INTO tapestry
           (tap_agent, tap_agent_id, tap_level, tap_title, tap_content, tap_date, tap_date_start, tap_date_end, tap_source)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent, agent_id, level, title, content, tap_date, date_start, date_end, source),
    )


def _seed_diverse(db):
    """Seed summaries about clearly different topics for cosine matching."""
    agent_id = _ensure_agent(db, "test")

    _tap(db, "test", 0, "Python Database Migration",
         "Migrated the SQLite database schema using Alembic. Added new columns for user "
         "preferences and updated all queries to use parameterized statements. Tested the "
         "migration rollback procedure.",
         tap_date="2026-03-01", source="conv-1", agent_id=agent_id)

    _tap(db, "test", 0, "React Component Refactor",
         "Refactored the dashboard React components to use hooks instead of class components. "
         "Converted lifecycle methods to useEffect and useState. Added PropTypes validation.",
         tap_date="2026-03-01", source="conv-2", agent_id=agent_id)

    _tap(db, "test", 0, "Patent Filing Strategy",
         "Discussed the patent filing strategy for the deterministic intelligence platform. "
         "Provisional patent covers the orchestrator and marketplace architecture. Need to file "
         "before publishing the package to PyPI. Sequence is critical.",
         tap_date="2026-03-02", source="conv-3", agent_id=agent_id)

    _tap(db, "test", 0, "Garden Irrigation System",
         "Designed an ESP32-based garden irrigation controller with soil moisture sensors. "
         "Uses deep sleep to conserve battery. Communicates readings via WiFi to the home server.",
         tap_date="2026-03-02", source="conv-4", agent_id=agent_id)

    _tap(db, "test", 1, "Database and Frontend Work",
         "Migrated the database schema and refactored React dashboard components.",
         tap_date="2026-03-01", agent_id=agent_id)

    _tap(db, "test", 1, "Patent and Hardware Projects",
         "Filed patent strategy for DI platform and designed ESP32 irrigation controller.",
         tap_date="2026-03-02", agent_id=agent_id)

    return agent_id


class TestCosineSearch:
    def test_empty_db(self, db):
        agent_id = _ensure_agent(db, "test")
        results = cosine_search(db, "test", agent_id, "anything")
        assert results == []

    def test_finds_relevant_results(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database migration schema")
        assert len(results) > 0
        # The database migration summary should be in top results
        top_titles = [r["title"] for r in results[:3]]
        assert "Python Database Migration" in top_titles

    def test_patent_query(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "patent filing intellectual property")
        assert len(results) > 0
        assert results[0]["title"] == "Patent Filing Strategy"

    def test_hardware_query(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "ESP32 microcontroller sensor")
        assert len(results) > 0
        top_titles = [r["title"] for r in results[:3]]
        assert "Garden Irrigation System" in top_titles

    def test_scores_are_sorted_descending(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database queries SQL")
        scores = [r["score"] for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_scores_between_0_and_1(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database")
        for r in results:
            assert 0.0 < r["score"] <= 1.0

    def test_zero_score_excluded(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database")
        for r in results:
            assert r["score"] > 0.0

    def test_top_n_limits_results(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database", top_n=2)
        assert len(results) <= 2

    def test_filter_by_level(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database", level=0)
        assert all(r["level"] == 0 for r in results)

    def test_filter_by_level_1(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database migration", level=1)
        assert all(r["level"] == 1 for r in results)
        assert len(results) > 0

    def test_wrong_agent_returns_empty(self, db):
        _seed_diverse(db)
        nonexistent_id = _ensure_agent(db, "nonexistent")
        results = cosine_search(db, "nonexistent", nonexistent_id, "database")
        assert results == []

    def test_result_has_expected_keys(self, db):
        agent_id = _seed_diverse(db)
        results = cosine_search(db, "test", agent_id, "database")
        assert len(results) > 0
        expected_keys = {"tap_id", "level", "title", "date", "date_start", "date_end", "score", "preview"}
        assert set(results[0].keys()) == expected_keys

    def test_preview_is_truncated(self, db):
        agent_id = _ensure_agent(db, "test")
        # Insert a record with long content
        long_content = "word " * 200  # 1000 chars
        _tap(db, "test", 0, "Long Record", long_content, tap_date="2026-03-01", source="conv-long", agent_id=agent_id)
        results = cosine_search(db, "test", agent_id, "word")
        assert len(results) > 0
        assert len(results[0]["preview"]) <= 300

    def test_no_matching_terms(self, db):
        agent_id = _seed_diverse(db)
        # Query with completely unrelated terms — TF-IDF may still return 0-score matches
        results = cosine_search(db, "test", agent_id, "xyzzyplugh42 foobarbaz99")
        # All results should be filtered out (score == 0)
        assert results == []
