"""Tests for engine/rollup.py — date math helpers."""

from datetime import date

import pytest

from tapestry.engine.rollup import weeks_in_month, conversations_in_range
from tapestry.db import Database
from tapestry.schema import init_db


class TestWeeksInMonth:
    def test_february_2026(self):
        """Feb 2026 starts on Sunday. First week is just Sun Feb 1."""
        weeks = weeks_in_month(2026, 2)
        # Feb 1 (Sun) = first Sunday → week is Feb 1-1 (partial, Mon would be Jan 26)
        assert weeks[0] == (date(2026, 2, 1), date(2026, 2, 1))
        # Feb 2 (Mon) to Feb 8 (Sun)
        assert weeks[1] == (date(2026, 2, 2), date(2026, 2, 8))
        # Feb 9 to Feb 15
        assert weeks[2] == (date(2026, 2, 9), date(2026, 2, 15))
        # Feb 16 to Feb 22
        assert weeks[3] == (date(2026, 2, 16), date(2026, 2, 22))
        # Feb 23 to Feb 28 (trailing partial, no Sunday)
        assert weeks[-1] == (date(2026, 2, 23), date(2026, 2, 28))

    def test_march_2026(self):
        """March 2026 starts on Sunday."""
        weeks = weeks_in_month(2026, 3)
        # Mar 1 (Sun) = partial week
        assert weeks[0] == (date(2026, 3, 1), date(2026, 3, 1))
        # Mar 2 (Mon) to Mar 8 (Sun)
        assert weeks[1] == (date(2026, 3, 2), date(2026, 3, 8))
        # Trailing: Mar 30 (Mon) to Mar 31 (Tue)
        assert weeks[-1] == (date(2026, 3, 30), date(2026, 3, 31))

    def test_month_ending_on_sunday(self):
        """May 2025 ends on Saturday, not Sunday — should have trailing."""
        weeks = weeks_in_month(2025, 5)
        # May 31 2025 is Saturday → trailing partial
        assert weeks[-1][1] == date(2025, 5, 31)

    def test_january_2026(self):
        """January 2026 starts on Thursday."""
        weeks = weeks_in_month(2026, 1)
        # First Sunday is Jan 4 → week_start = max(Dec 29, Jan 1) = Jan 1
        assert weeks[0] == (date(2026, 1, 1), date(2026, 1, 4))
        # Last Sunday is Jan 25 → Jan 19-25
        # Trailing: Jan 26-31
        assert weeks[-1] == (date(2026, 1, 26), date(2026, 1, 31))

    def test_all_weeks_cover_full_month(self):
        """Every day in the month should be covered by exactly one week."""
        for month in range(1, 13):
            weeks = weeks_in_month(2026, month)
            last_day = date(2026, month, 1)
            while True:
                try:
                    next_month = last_day.replace(month=month + 1)
                except ValueError:
                    next_month = last_day.replace(year=2027, month=1)
                break
            import calendar as cal
            month_days = cal.monthrange(2026, month)[1]
            all_days = set()
            for start, end in weeks:
                d = start
                while d <= end:
                    all_days.add(d)
                    d += __import__('datetime').timedelta(days=1)
            assert len(all_days) == month_days, f"Month {month}: expected {month_days} days, got {len(all_days)}"

    def test_no_overlap(self):
        """Week ranges should not overlap."""
        weeks = weeks_in_month(2026, 2)
        for i in range(len(weeks) - 1):
            assert weeks[i][1] < weeks[i + 1][0], f"Overlap: {weeks[i]} and {weeks[i+1]}"


def _ensure_agent(db, agent="default"):
    """Ensure agent row exists and return agent_id."""
    db.sql("INSERT OR IGNORE INTO tapestry_agents (agent_name) VALUES (?)", (agent,))
    row = db.sql("SELECT agent_id FROM tapestry_agents WHERE agent_name = ?", (agent,), single=True)
    return row["agent_id"]


class TestConversationsInRange:
    def test_finds_conversations(self, tmp_path):
        db = Database(str(tmp_path / "db" / "test.db"))
        db.ensure_directory()
        init_db(db)
        agent_id = _ensure_agent(db, "default")

        # Insert messages for two conversations
        db.sql(
            "INSERT INTO tapestry_messages (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("default", agent_id, "u1", "conv-a", "user", "hello", 1, "2026-02-15T10:00:00"),
        )
        db.sql(
            "INSERT INTO tapestry_messages (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("default", agent_id, "u2", "conv-b", "user", "world", 1, "2026-02-20T10:00:00"),
        )

        result = conversations_in_range(db, "default", agent_id, "2026-02-01", "2026-02-28")
        assert len(result) == 2
        assert result[0]["tmsg_ref_conv_id"] == "conv-a"
        assert result[1]["tmsg_ref_conv_id"] == "conv-b"
        db.close()

    def test_filters_by_date(self, tmp_path):
        db = Database(str(tmp_path / "db" / "test.db"))
        db.ensure_directory()
        init_db(db)
        agent_id = _ensure_agent(db, "default")

        db.sql(
            "INSERT INTO tapestry_messages (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("default", agent_id, "u1", "conv-a", "user", "in range", 1, "2026-02-15T10:00:00"),
        )
        db.sql(
            "INSERT INTO tapestry_messages (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("default", agent_id, "u2", "conv-b", "user", "out of range", 1, "2026-03-15T10:00:00"),
        )

        result = conversations_in_range(db, "default", agent_id, "2026-02-01", "2026-02-28")
        assert len(result) == 1
        assert result[0]["tmsg_ref_conv_id"] == "conv-a"
        db.close()

    def test_filters_by_agent(self, tmp_path):
        db = Database(str(tmp_path / "db" / "test.db"))
        db.ensure_directory()
        init_db(db)
        agent_id_a = _ensure_agent(db, "agent-a")
        agent_id_b = _ensure_agent(db, "agent-b")

        db.sql(
            "INSERT INTO tapestry_messages (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("agent-a", agent_id_a, "u1", "conv-a", "user", "hello", 1, "2026-02-15T10:00:00"),
        )
        db.sql(
            "INSERT INTO tapestry_messages (tmsg_agent, tmsg_agent_id, tmsg_ref_uuid, tmsg_ref_conv_id, tmsg_role, tmsg_content, tmsg_order, tmsg_timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("agent-b", agent_id_b, "u2", "conv-b", "user", "world", 1, "2026-02-15T10:00:00"),
        )

        result = conversations_in_range(db, "agent-a", agent_id_a, "2026-02-01", "2026-02-28")
        assert len(result) == 1
        assert result[0]["tmsg_ref_conv_id"] == "conv-a"
        db.close()

    def test_empty_range(self, tmp_path):
        db = Database(str(tmp_path / "db" / "test.db"))
        db.ensure_directory()
        init_db(db)
        agent_id = _ensure_agent(db, "default")

        result = conversations_in_range(db, "default", agent_id, "2026-01-01", "2026-01-31")
        assert result == []
        db.close()
