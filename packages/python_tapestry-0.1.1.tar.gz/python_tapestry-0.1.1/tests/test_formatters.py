"""Tests for CLI formatters — text, json, jsonl output modes."""

import json

import pytest

from tapestry.cli.formatters import (
    fmt_search,
    fmt_recall,
    fmt_show,
    fmt_context,
    fmt_tree,
    fmt_stats,
    fmt_conversations,
)


# ── sample data ──────────────────────────────────────────────────────

SEARCH_RESULTS = [
    {
        "conv_id": "conv-1",
        "date": "2026-03-01",
        "match_count": 3,
        "tap_id": 100,
        "title": "Test Conversation",
        "sample": {"role": "user", "preview": "hello world"},
    },
]

SUMMARY_RESULTS = [
    {
        "tap_id": 200,
        "level": 1,
        "title": "Daily Summary",
        "date": "2026-03-01",
        "date_start": None,
        "date_end": None,
        "preview": "A daily summary...",
    },
]

RECALL_RECORDS = [
    {
        "tap_id": 300,
        "tap_level": 1,
        "tap_title": "Daily for March 1",
        "tap_content": "Content of the daily.",
        "tap_date": "2026-03-01",
        "tap_date_start": None,
        "tap_date_end": None,
        "tap_parent_id": None,
    },
]

SHOW_RECORD = {
    "tap_id": 400,
    "tap_level": 0,
    "tap_title": "A conversation",
    "tap_content": "Some content here.",
    "tap_date": "2026-03-01",
    "tap_date_start": None,
    "tap_date_end": None,
    "tap_parent_id": 300,
}

CONTEXT_ITEMS = [
    {"level": 1, "title": "Daily", "range": "2026-03-01", "content": "Daily content."},
    {"level": 0, "title": "Conv 1", "range": "2026-03-01", "content": "Conv content."},
]

TREE_DATA = {
    "monthlies": [
        {
            "title": "March 2026",
            "date_start": "2026-03-01",
            "date_end": "2026-03-31",
            "content_len": 5000,
            "weeklies": [
                {
                    "title": "Week 1",
                    "date_start": "2026-03-01",
                    "date_end": "2026-03-07",
                    "content_len": 2000,
                    "dailies": [
                        {
                            "date": "2026-03-01",
                            "title": "Saturday",
                            "l0_count": 3,
                            "content_len": 800,
                        },
                    ],
                },
            ],
        },
    ],
    "orphaned_weeklies": [],
    "orphaned_dailies": [],
}

STATS_DATA = {
    "levels": {
        0: {"name": "conversation", "count": 10, "chars": 5000, "avg_chars": 500},
        1: {"name": "daily", "count": 3, "chars": 2000, "avg_chars": 666},
        2: {"name": "weekly", "count": 1, "chars": 800, "avg_chars": 800},
        3: {"name": "monthly", "count": 0, "chars": 0, "avg_chars": 0},
        4: {"name": "yearly", "count": 0, "chars": 0, "avg_chars": 0},
    },
    "messages": 100,
    "conversations": 10,
    "total_records": 14,
    "total_chars": 7800,
    "est_tokens": 1950,
}

CONVERSATIONS_DATA = [
    {"conv_id": "abc123def456", "agent": "test", "msg_count": 5, "date": "2026-03-01"},
]


# ── search ───────────────────────────────────────────────────────────


class TestFmtSearch:
    def test_text_conversations(self):
        out = fmt_search(SEARCH_RESULTS, False, "test", "text")
        assert "Found 1 conversation(s)" in out
        assert "Test Conversation" in out

    def test_text_summaries(self):
        out = fmt_search(SUMMARY_RESULTS, True, "test", "text")
        assert "Found 1 summary(ies)" in out
        assert "Daily Summary" in out

    def test_text_empty(self):
        out = fmt_search([], False, "test", "text")
        assert "No conversations matching" in out

    def test_json(self):
        out = fmt_search(SEARCH_RESULTS, False, "test", "json")
        data = json.loads(out)
        assert len(data) == 1
        assert data[0]["conv_id"] == "conv-1"

    def test_jsonl(self):
        out = fmt_search(SEARCH_RESULTS, False, "test", "jsonl")
        lines = out.strip().split("\n")
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["tap_id"] == 100


# ── recall ───────────────────────────────────────────────────────────


class TestFmtRecall:
    def test_text(self):
        out = fmt_recall(RECALL_RECORDS, "2026-03-01", None, "text")
        assert "tap_id=300" in out
        assert "Daily for March 1" in out

    def test_text_empty(self):
        out = fmt_recall([], "2026-03-01", None, "text")
        assert "No records found" in out

    def test_json(self):
        out = fmt_recall(RECALL_RECORDS, "2026-03-01", None, "json")
        data = json.loads(out)
        assert len(data) == 1
        assert data[0]["tap_id"] == 300

    def test_jsonl(self):
        out = fmt_recall(RECALL_RECORDS, "2026-03-01", None, "jsonl")
        data = json.loads(out.strip())
        assert data["tap_level"] == 1


# ── show ─────────────────────────────────────────────────────────────


class TestFmtShow:
    def test_text(self):
        out = fmt_show(SHOW_RECORD, 400, "text")
        assert "tap_id=400" in out
        assert "Parent: tap_id=300" in out

    def test_text_missing(self):
        out = fmt_show(None, 999, "text")
        assert "No record with tap_id=999" in out

    def test_json(self):
        out = fmt_show(SHOW_RECORD, 400, "json")
        data = json.loads(out)
        assert data["tap_id"] == 400

    def test_json_missing(self):
        out = fmt_show(None, 999, "json")
        assert json.loads(out) is None


# ── context ──────────────────────────────────────────────────────────


class TestFmtContext:
    def test_text(self):
        out = fmt_context(CONTEXT_ITEMS, [], "2026-03-01", "text")
        assert "Telescoping context" in out
        assert "DAILY (1):" in out
        assert "CONVERSATION (1):" in out

    def test_json(self):
        out = fmt_context(CONTEXT_ITEMS, [], "2026-03-01", "json")
        data = json.loads(out)
        assert "context" in data
        assert len(data["context"]) == 2


# ── tree ─────────────────────────────────────────────────────────────


class TestFmtTree:
    def test_text(self):
        out = fmt_tree(TREE_DATA, "text")
        assert "March 2026" in out
        assert "Week 1" in out
        assert "Saturday" in out

    def test_json(self):
        out = fmt_tree(TREE_DATA, "json")
        data = json.loads(out)
        assert len(data["monthlies"]) == 1

    def test_empty(self):
        empty = {"monthlies": [], "orphaned_weeklies": [], "orphaned_dailies": []}
        out = fmt_tree(empty, "text")
        assert "(empty)" in out


# ── stats ────────────────────────────────────────────────────────────


class TestFmtStats:
    def test_text(self):
        out = fmt_stats(STATS_DATA, "text")
        assert "Tapestry Stats" in out
        assert "10 records" in out

    def test_json(self):
        out = fmt_stats(STATS_DATA, "json")
        data = json.loads(out)
        assert data["total_records"] == 14

    def test_jsonl(self):
        out = fmt_stats(STATS_DATA, "jsonl")
        lines = out.strip().split("\n")
        assert len(lines) == 5  # one per level


# ── conversations ────────────────────────────────────────────────────


class TestFmtConversations:
    def test_text(self):
        out = fmt_conversations(CONVERSATIONS_DATA, "text")
        assert "abc123def4.." in out
        assert "1 conversation(s)" in out

    def test_text_empty(self):
        out = fmt_conversations([], "text")
        assert "No conversations found" in out

    def test_json(self):
        out = fmt_conversations(CONVERSATIONS_DATA, "json")
        data = json.loads(out)
        assert len(data) == 1
