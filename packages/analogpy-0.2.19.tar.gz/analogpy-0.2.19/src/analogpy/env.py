"""Environment detection for analogpy — display, SSH, and remote workflow guidance."""

import os
import sys
from dataclasses import dataclass


@dataclass
class DisplayEnvironment:
    """Describes the current display environment."""
    has_display: bool       # Can GUI apps (matplotlib, xdg-open) show windows?
    is_ssh: bool            # Running inside an SSH session?
    platform: str           # "darwin", "linux", etc.


def detect_display() -> DisplayEnvironment:
    """Detect if the current environment supports GUI display.

    Checks SSH_CONNECTION/SSH_TTY for SSH sessions, DISPLAY for X11,
    and WAYLAND_DISPLAY for Wayland. macOS local always has display.
    """
    platform = sys.platform
    is_ssh = bool(os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY"))

    if platform == "darwin" and not is_ssh:
        has_display = True
    elif is_ssh:
        has_display = bool(os.environ.get("DISPLAY"))
    else:
        has_display = bool(
            os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
        )

    return DisplayEnvironment(has_display=has_display, is_ssh=is_ssh, platform=platform)


def get_viewing_suggestion(path: str) -> str:
    """Return a platform-appropriate suggestion for viewing/transferring a file."""
    env = detect_display()
    abspath = os.path.abspath(path)

    if env.has_display and env.platform == "darwin":
        return f"View with: code {abspath}  (or: open {abspath})"
    elif env.has_display:
        return f"View with: xdg-open {abspath}"
    else:
        hostname = os.environ.get("HOSTNAME", os.uname().nodename)
        user = os.environ.get("USER", "user")
        return (
            f"No GUI display available (SSH session detected).\n"
            f"  Transfer to local machine:  scp {user}@{hostname}:{abspath} ~/Downloads/\n"
            f"  Or run analogpy locally on this server (VNC/desktop session)."
        )


def check_environment():
    """Print a summary of the current environment for analogpy users.

    Useful as a quick diagnostic when starting work on a remote server.
    Reports: platform, SSH status, display capability, and guidance for
    large simulation data workflows.
    """
    env = detect_display()
    hostname = os.environ.get("HOSTNAME", os.uname().nodename)

    print("analogpy environment check")
    print(f"  Platform:    {env.platform}")
    print(f"  Host:        {hostname}")
    print(f"  SSH session: {'yes' if env.is_ssh else 'no'}")
    print(f"  GUI display: {'yes' if env.has_display else 'NO'}")

    if not env.has_display:
        print()
        print("  WARNING: No GUI display available.")
        print("  Interactive plots (matplotlib plt.show()) will not work.")
        print()
        print("  Options for viewing results:")
        print("    1. Save plots to files: plt.savefig('plot.png')")
        print("       Then transfer small files: scp user@host:plot.png ~/Downloads/")
        print("    2. For large simulation data (transient, hundreds of GB):")
        print("       - Run analysis scripts directly on this server")
        print("       - Save only reduced results (CSV, numpy .npy) for transfer")
        print("       - Use a VNC/desktop session for interactive plotting")
        print("    3. Use SSH X11 forwarding (ssh -X) for occasional GUI use")
        print("       (can be slow for large plots)")
