# Zaku - High-Performance Distributed Task Queue

A high-throughput distributed task queue system built on **Redis + S3**,
designed for machine learning workloads with support for large payloads, batch
concurrent processing, and multiple consumption patterns.

## Core Features

- **High-Throughput Architecture**: Metadata stored in Redis, payloads stored
  in S3
- **Large Payload Support**: Breaks through MongoDB's 16MB limit, supports
  arbitrarily large data
- **Batch Concurrent Downloads**: Supports batch metadata retrieval with
  concurrent payload downloads
- **Sync/Async Dual Modes**: Both synchronous and asynchronous clients
  supported
- **Multiple Consumption Patterns**: take/download, pop (auto-download), batch
  consumption
- **Rich Data Types**: Native support for dict, numpy arrays, torch tensors,
  PIL Images
- **Task State Management**: Supports pending, in_progress, completed/reset
  state transitions
- **PubSub/RPC Support**: Built-in publish-subscribe and RPC call functionality

---

## Architecture Design

### Pure Redis + S3 Architecture

```
┌─────────────┐
│   Client    │
│             │
│  1. Add     │──────────┐
│  2. Take    │          │
│  3. Download│          ▼
│  4. Process │    ┌──────────┐         ┌──────────┐
│  5. Done    │◀───│  Redis   │         │   S3     │
└─────────────┘    │          │         │          │
                   │ • Queue  │         │ Payload  │
                   │ • State  │         │ Storage  │
                   │ • Meta   │         │          │
                   └──────────┘         └──────────┘
```

**Data Flow:**

1. **Add**: Client uploads payload to S3 → Server stores metadata in Redis
2. **Take**: Server returns metadata from Redis (including s3_key)
3. **Download**: Client downloads payload from S3 using s3_key
4. **Done**: Server deletes Redis metadata and S3 object

**Advantages:**

- Redis only stores lightweight metadata, avoiding large value problems
- S3 stores large payloads with low cost and unlimited capacity
- Batch concurrent downloads maximize throughput
- Client connects directly to S3, reducing server load

---

## Installation

### Quick Start

```bash
uv venv --python 3.11
source .venv/bin/activate
```

**Server only (no PyTorch required):**
```bash
uv pip install -e ".[server]"
```

**Server + GPU (CUDA PyTorch, ~2GB):**
```bash
uv pip install -e ".[server,gpu]"
```

**Server + CPU PyTorch (lightweight, ~200MB):**
```bash
uv pip install -e ".[server]"
uv pip install torch --index-url https://download.pytorch.org/whl/cpu
```

**Client + GPU:**
```bash
uv pip install -e ".[gpu]"
```

**Client + CPU PyTorch:**
```bash
uv pip install -e .
uv pip install torch --index-url https://download.pytorch.org/whl/cpu
```

> **Do you need PyTorch?**
> - **No**: Running the queue server or basic task operations — use `.[server]` or base install
> - **Yes**: Sending/receiving `torch.Tensor` payloads — add GPU or CPU torch as above

**See [INSTALL.md](INSTALL.md) for detailed installation options and troubleshooting.**

---

**Core Dependencies:**

- Python >= 3.11
- Redis >= 6.0 (with RedisJSON support)
- AWS S3 or compatible storage

---

## Environment Configuration

Create a `.env` file:

```bash
# ============================================
# Redis Configuration (server must)
# ============================================
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=your_redis_password  # Optional, leave empty if no password
REDIS_DB=0  # Redis database index (default: 0)
REDIS_SSL=False | True # Use SSL for Redis connection

# ============================================
# S3 Storage Configuration (client must)
# ============================================
S3_BUCKET=your-bucket-name           # Required: S3 bucket name
S3_REGION=us-east-1                  # S3 region
AWS_ACCESS_KEY_ID=your_access_key    # Required: AWS access key
AWS_SECRET_ACCESS_KEY=your_secret    # Required: AWS secret key

# ============================================
# Zaku Server Configuration (for clients)
# ============================================
ZAKU_URI=http://localhost:9000       # Zaku server address
```

### Environment Variables

| Variable                | Required | Default               | Description           |
|-------------------------|----------|-----------------------|-----------------------|
| `REDIS_HOST`            | Yes      | localhost             | Redis server address  |
| `REDIS_PORT`            | No       | 6379                  | Redis port            |
| `REDIS_PASSWORD`        | No       | -                     | Redis password        |
| `REDIS_SSL`             | No       | False                 | SSL connection        |
| `S3_BUCKET`             | **Yes**  | -                     | **S3 bucket name**    |
| `S3_REGION`             | No       | us-east-1             | S3 region             |
| `AWS_ACCESS_KEY_ID`     | **Yes**  | -                     | **AWS access key**    |
| `AWS_SECRET_ACCESS_KEY` | **Yes**  | -                     | **AWS secret key**    |
| `ZAKU_URI`              | No       | http://localhost:9000 | Zaku server address   |

---

## Starting the Server

```bash
# Method 1: Direct run
zaku --port 9000 --verbose

# Method 2: Using gunicorn + uvloop (Recommended for better performance)
gunicorn zaku.server:get_app \
  --bind 0.0.0.0:9000 \
  --workers 4 \
  --worker-class aiohttp.GunicornUVLoopWebWorker \
  --capture-output \
  --enable-stdio-inheritance \
  --log-level info \
  --timeout 180 \
  --max-requests 100000 \
  --max-requests-jitter 100000
```

**Server Startup Success Output:**

```
2024-01-01 12:00:00 | INFO | serving at 0.0.0.0:9000
2024-01-01 12:00:00 | INFO | Redis server is connected
2024-01-01 12:00:00 | INFO | S3 connected to bucket your-bucket-name
```

---

## Synchronous Client Usage

### Basic Setup

```python
from dotenv import load_dotenv
from zaku import TaskQ
from zaku.interfaces import Payload

# Load environment variables
load_dotenv()

# Create queue
queue = TaskQ(name="my-queue")
```

### 1. Adding Tasks

```python
# Add simple task
job_id = queue.add({"task": "process_data", "id": 123})
print(f"Task added: {job_id}")

# Add task with numpy array
import numpy as np

job_id = queue.add({
    "data": np.random.rand(100, 100),
    "label": "training_data"
})

# Add large data (automatically uploaded to S3)
large_data = np.random.rand(1000, 1000)  # 8MB
job_id = queue.add({"tensor": large_data})
```

### 2. Consuming Tasks - Method 1: Manual Download

```python
# Step 1: Get task metadata (lightweight, only a few bytes)
result = queue.take()
if result:
    job_id, metadata = result
    print(f"Task ID: {job_id}")
    print(f"S3 Key: {metadata['_s3_key']}")
    print(f"Size: {metadata['_size']} bytes")

    # Step 2: Download payload from S3
    payload_bytes = queue.download_from_s3(metadata["_s3_key"])

    # Step 3: Deserialize
    payload = Payload.deserialize(payload_bytes)

    # Step 4: Process task
    print(f"Processing task: {payload}")

    # Step 5: Mark as done (deletes Redis metadata and S3 object)
    queue.mark_done(job_id)
```

### 3. Consuming Tasks - Method 2: Auto-Download (Recommended)

```python
# Use pop() context manager for automatic download, deserialize, and cleanup
with queue.pop() as job:
    if job:
        print(f"Processing task: {job}")
        # Processing logic...
        # Automatically marked as done when exiting the with block
```

### 4. Batch Concurrent Consumption (High Throughput Mode)

```python
# ============================================
# High-Performance Batch Consumption Mode
# ============================================

# Step 1: Batch get metadata (lightweight, fast)
batch = []
for _ in range(100):
    result = queue.take()
    if result:
        batch.append(result)

print(f"Retrieved metadata for {len(batch)} tasks")

# Step 2: Extract s3_keys
s3_keys = [meta["_s3_key"] for _, meta in batch]

# Step 3: Batch concurrent download (using ThreadPoolExecutor)
payloads_bytes = queue.download_payloads(s3_keys)

# Step 4: Batch deserialize
payloads = [Payload.deserialize(p) for p in payloads_bytes]

print(f"Downloaded {len(payloads)} payloads")

# Step 5: Batch process
for (job_id, meta), payload in zip(batch, payloads):
    # Process task
    result = process(payload)
    print(f"Processed task {job_id}: {result}")

    # Mark as done
    queue.mark_done(job_id)
```

### 5. Queue Management Operations

```python
# Get queue length
count = queue.count()
print(f"Queue has {count} tasks")

# Clear queue (deletes all tasks and S3 objects)
queue.clear_queue()

# Reset task state (return to pending)
queue.mark_reset(job_id)
```

---

## Asynchronous Client Usage

### Basic Setup

```python
import asyncio
from dotenv import load_dotenv
from zaku import TaskQAsync
from zaku.interfaces import Payload

load_dotenv()


async def main():
    # Create async queue (using context manager)
    async with TaskQAsync(name="my-async-queue") as queue:
        # Use queue...
        pass


asyncio.run(main())
```

### 1. Adding Tasks

```python
async def producer():
    async with TaskQAsync(name="my-queue") as queue:
        # Add single task
        job_id = await queue.add({"task": "process", "id": 1})
        print(f"Task added: {job_id}")

        # Batch concurrent add (using gather for high performance)
        tasks = [
            queue.add({"task": f"task-{i}", "index": i})
            for i in range(100)
        ]
        job_ids = await asyncio.gather(*tasks)
        print(f"Batch add completed: {len(job_ids)} tasks")


asyncio.run(producer())
```

### 2. Consuming Tasks - Method 1: Manual Download

```python
async def consumer():
    async with TaskQAsync(name="my-queue") as queue:
        # Get metadata
        result = await queue.take()
        if result:
            job_id, metadata = result

            # Download payload
            payload_bytes = await queue.download_from_s3(metadata["_s3_key"])
            payload = Payload.deserialize(payload_bytes)

            # Process
            print(f"Processing: {payload}")

            # Mark as done
            await queue.mark_done(job_id)


asyncio.run(consumer())
```

### 3. Consuming Tasks - Method 2: Auto-Download (Recommended)

```python
async def consumer():
    async with TaskQAsync(name="my-queue") as queue:
        # Automatic download, deserialize, and cleanup
        async with queue.pop() as job:
            if job:
                print(f"Processing task: {job}")
                # Processing logic...
                # Automatically marked as done


asyncio.run(consumer())
```

### 4. Batch Concurrent Consumption (Maximum Throughput)

```python
async def batch_consumer():
    async with TaskQAsync(name="my-queue") as queue:
        # ============================================
        # High-Performance Async Batch Consumption
        # ============================================

        # Step 1: Batch concurrent get metadata (using gather)
        take_tasks = [queue.take() for _ in range(100)]
        results = await asyncio.gather(*take_tasks)
        batch = [r for r in results if r is not None]

        print(f"Retrieved {len(batch)} tasks")

        # Step 2: Extract s3_keys
        s3_keys = [meta["_s3_key"] for _, meta in batch]

        # Step 3: Batch concurrent download (using asyncio.gather, maximum performance)
        payloads_bytes = await queue.download_payloads(s3_keys)

        # Step 4: Deserialize
        payloads = [Payload.deserialize(p) for p in payloads_bytes]

        print(f"Downloaded {len(payloads)} payloads")

        # Step 5: Batch concurrent processing (using gather)
        async def process_task(job_id, payload):
            result = await process(payload)
            print(f"Processed task {job_id}: {result}")
            await queue.mark_done(job_id)
            return result

        process_tasks = [
            process_task(job_id, payload)
            for (job_id, meta), payload in zip(batch, payloads)
        ]
        await asyncio.gather(*process_tasks)


asyncio.run(batch_consumer())
```

### 5. Concurrent Consumer Pattern (Multi-Worker)

```python
async def worker(worker_id: int, queue_name: str):
    """Single worker process"""
    async with TaskQAsync(name=queue_name) as queue:
        print(f"Worker {worker_id} started")

        while True:
            async with queue.pop() as job:
                if job is None:
                    # Queue is empty, wait
                    await asyncio.sleep(0.1)
                    continue

                # Process task
                print(f"Worker {worker_id} processing: {job}")
                await asyncio.sleep(0.5)  # Simulate processing


async def main():
    queue_name = "my-queue"

    # Start 10 concurrent workers
    workers = [
        worker(i, queue_name)
        for i in range(10)
    ]

    # Run all workers concurrently
    await asyncio.gather(*workers)


asyncio.run(main())
```

### 6. Async For Style (Clean Syntax + High Performance)

Zaku provides `async for` style methods that combine clean syntax with high
performance through internal batching and prefetching.

#### iter_consume() - Recommended for Production

```python
async def consumer():
    async with TaskQAsync(name="my-queue") as queue:
        # Clean async for syntax with auto mark_done and prefetching
        async for job_id, payload in queue.iter_consume(
                batch_size=100,  # Internal batch size (high performance)
                auto_mark_done=True,  # Auto cleanup
                prefetch=False  # Prefetch next batch (maximize throughput)
        ):
            # Process task
            result = process(payload)
            print(f"Processed: {result}")
            # Automatically marked as done


asyncio.run(consumer())
```

**Performance:** Internally uses `asyncio.gather()` for concurrent downloads
and prefetching for maximum throughput.

#### iter_consume() with Manual Control

```python
async def consumer_with_retry():
    async with TaskQAsync(name="my-queue") as queue:
        # Manual mark_done for error handling
        async for job_id, payload in queue.iter_consume(
                batch_size=50,
                auto_mark_done=False  # Manual control
        ):
            try:
                result = process(payload)
                await queue.mark_done(job_id)
            except Exception as e:
                print(f"Error: {e}, resetting task")
                await queue.mark_reset(job_id)


asyncio.run(consumer_with_retry())
```

#### iter_tasks() - Lightweight Iteration

```python
async def metadata_scanner():
    async with TaskQAsync(name="my-queue") as queue:
        # Iterate metadata only (no S3 download, very fast)
        async for job_id, metadata in queue.iter_tasks(
                batch_size=100,
                download=False  # Metadata only
        ):
            s3_key = metadata['_s3_key']
            size = metadata.get('_size', 0)
            print(f"Task {job_id}: {s3_key} ({size} bytes)")


asyncio.run(metadata_scanner())
```

#### iter_download_stream() - Stream Downloads

```python
async def stream_processor():
    async with TaskQAsync(name="my-queue") as queue:
        # Get metadata batch
        batch = await queue.take_batch(100)
        s3_keys = [meta["_s3_key"] for _, meta in batch]

        # Stream payloads as they download (memory-efficient)
        async for s3_key, payload_bytes in queue.iter_download_stream(
                s3_keys,
                batch_size=50  # Concurrent download limit
        ):
            import msgpack
            payload = msgpack.unpackb(payload_bytes, raw=False)
            # Process immediately without waiting for all downloads
            process(payload)


asyncio.run(stream_processor())
```

#### watch_queue() - Monitor Queue

```python
async def monitor():
    async with TaskQAsync(name="my-queue") as queue:
        # Monitor queue size in real-time
        async for count in queue.watch_queue(
                interval=1.0,  # Poll every 1 second
                stop_when_empty=True  # Stop when empty
        ):
            print(f"Queue size: {count}")
            if count > 10000:
                print("Warning: queue is getting large!")


asyncio.run(monitor())
```

#### gather_stream() - MapReduce Pattern

```python
async def mapreduce():
    async with TaskQAsync(name="my-queue") as queue:
        # Submit multiple jobs
        jobs = [{"seed": i, "operation": "train"} for i in range(100)]

        # Stream results as they complete
        async for token, result in queue.gather_stream(jobs):
            print(f"Job {token} completed: {result}")
            # Process result immediately


asyncio.run(mapreduce())
```

**Summary of Async For Methods:**

| Method                   | Use Case                   | Performance                | Memory |
|--------------------------|----------------------------|----------------------------|--------|
| `iter_consume()`         | Production consumption     | Highest (prefetch + batch) | Medium |
| `iter_tasks()`           | Metadata scanning          | High (no S3 download)      | Low    |
| `iter_download_stream()` | Large batch downloads      | High (streaming)           | Low    |
| `watch_queue()`          | Monitoring                 | Low overhead               | Low    |
| `gather_stream()`        | MapReduce/distributed jobs | High                       | Medium |

**See:** `examples/example_async_for.py` for complete examples.

---

## Advanced Features

### 1. Supported Data Types

Zaku natively supports serialization of multiple data types:

```python
import numpy as np
import torch
from PIL import Image

# ============================================
# 1. Python Native Types
# ============================================
queue.add({"key": "value", "number": 123})

# ============================================
# 2. Numpy Array
# ============================================
queue.add({
    "array": np.random.rand(100, 100),
    "dtype": "float32"
})

# ============================================
# 3. PyTorch Tensor
# ============================================
queue.add({
    "tensor": torch.rand(100, 100),
    "requires_grad": True
})

# ============================================
# 4. PIL Image
# ============================================
img = Image.open("image.png")
queue.add({
    "image": img,
    "format": "PNG"
})

# ============================================
# 5. Mixed Types (Recommended)
# ============================================
queue.add({
    "model_weights": torch.rand(1000, 1000),  # PyTorch
    "training_data": np.array([1, 2, 3]),  # Numpy
    "metadata": {  # Dict
        "version": "1.0",
        "timestamp": "2024-01-01"
    }
})
```

### 2. PubSub (Publish-Subscribe Pattern)

```python
from zaku import TaskQ

queue = TaskQ(name="my-queue")

# ============================================
# Publisher
# ============================================
subscribers = queue.publish(
    {"event": "user_login", "user_id": 123},
    topic="user-events"
)
print(f"Sent to {subscribers} subscribers")

# ============================================
# Subscriber - Single Message
# ============================================
message = queue.subscribe_one("user-events", timeout=5)
if message:
    print(f"Received message: {message}")

# ============================================
# Subscriber - Streaming Consumption
# ============================================
for message in queue.subscribe_stream("user-events", timeout=10):
    print(f"Received: {message}")
    # Process message...
```

### 3. RPC (Remote Procedure Call)

```python
from multiprocessing import Process
from zaku import TaskQ


# ============================================
# Worker Side (Process RPC Requests)
# ============================================
def rpc_worker():
    queue = TaskQ(name="rpc-queue")

    while True:
        with queue.pop() as job:
            if job is None:
                continue

            # Extract RPC info
            topic = job.pop("_request_id")

            # Process request
            result = {
                "answer": job["x"] + job["y"],
                "status": "success"
            }

            # Send response
            queue.publish(result, topic=topic)


# ============================================
# Client Side (Make RPC Call)
# ============================================
# Start worker
p = Process(target=rpc_worker)
p.start()

# Make RPC call
queue = TaskQ(name="rpc-queue")
result = queue.rpc(x=10, y=20, _timeout=5)
print(f"RPC result: {result}")  # {"answer": 30, "status": "success"}

p.join()
```

### 4. Gather Pattern (MapReduce)

```python
from multiprocessing import Process
from zaku import TaskQ


# ============================================
# Worker Process
# ============================================
def gather_worker(queue_name):
    queue = TaskQ(name=queue_name)

    while True:
        with queue.pop() as job:
            if job is None:
                continue

            # Extract gather info
            gather_id = job.pop("_gather_id")
            gather_token = job.pop("_gather_token")

            # Process task
            result = process_data(job["data"])

            # Return result to gather queue
            gather_queue = TaskQ(name=gather_id)
            gather_queue.add({
                "_gather_token": gather_token,
                "result": result
            })


# ============================================
# Main Process (Distribute Tasks and Collect Results)
# ============================================
# Start multiple workers
queue_name = "my-queue"
workers = []
for i in range(10):
    p = Process(target=gather_worker, args=(queue_name,))
    p.start()
    workers.append(p)

# Distribute batch tasks
queue = TaskQ(name=queue_name)
jobs = [{"data": i} for i in range(100)]
is_done, tokens = queue.gather(jobs)

# Wait for all tasks to complete
print("Waiting for tasks to complete...")
is_done(blocking=True, sleep=0.1)
print("All tasks completed!")

# Cleanup
for p in workers:
    p.terminate()
    p.join()
```

---

## Performance Optimization Tips

### 1. Batch Consumption vs Individual Consumption

**Low Throughput (Not Recommended):**

```python
# Individual get and download - slow!
for _ in range(100):
    with queue.pop() as job:
        process(job)
```

**High Throughput (Recommended):**

```python
# Batch get + concurrent download - fast!
batch = [queue.take() for _ in range(100) if queue.take()]
s3_keys = [meta["_s3_key"] for _, meta in batch]
payloads_bytes = queue.download_payloads(s3_keys)  # Concurrent download
payloads = [Payload.deserialize(p) for p in payloads_bytes]
for payload in payloads:
    process(payload)
```

**Performance Comparison:**

- Individual consumption: ~10 tasks/s
- Batch consumption: ~200+ tasks/s (**20x improvement**)

### 2. Async vs Sync

For I/O-intensive tasks, using async clients provides better performance:

```python
# Sync: ThreadPoolExecutor concurrent download
payloads = queue.download_payloads(s3_keys)  # ~100 tasks/s

# Async: asyncio.gather concurrent download
payloads = await queue.download_payloads(s3_keys)  # ~300+ tasks/s
```

### 3. Batch Size Tuning

```python
# Recommended batch size
batch_size = 100  # Recommended: 50-200

# Too small: cannot fully utilize concurrency
batch_size = 10  # Not recommended

# Too large: high memory pressure
batch_size = 1000  # Be careful with memory
```

### 4. Connection Pool Optimization

Async client automatically configures high-performance connection pool:

```python
async with TaskQAsync(name="queue") as queue:
    # Automatically configured:
    # - ClientTimeout(total=300)
    # - TCPConnector(limit=1000, limit_per_host=1000)
    pass
```

---

## Troubleshooting

### 1. NoCredentialsError

**Error:**

```
botocore.exceptions.NoCredentialsError: Unable to locate credentials
```

**Cause:** AWS credentials not configured or not loaded

**Solution:**

1. Check `.env` file:

```bash
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
```

2. Ensure `load_dotenv()` is called:

```python
from dotenv import load_dotenv

load_dotenv()  # ← Important!
```

### 2. NoSuchBucket

**Error:**

```
NoSuchBucket: The specified bucket does not exist
```

**Cause:** S3 bucket does not exist or is misconfigured

**Solution:**

1. Check bucket name:

```bash
S3_BUCKET=your-existing-bucket  # Ensure bucket exists
```

2. Create bucket in AWS console

### 3. Connection Refused

**Error:**

```
Connection refused to localhost:9000
```

**Cause:** Zaku server is not running

**Solution:**

```bash
# Start server
python -m zaku.server
```

### 4. Redis Connection Error

**Error:**

```
redis.exceptions.ConnectionError: Error connecting to Redis
```

**Cause:** Redis is not running or is misconfigured

**Solution:**

```bash
# Check Redis status
redis-cli ping  # Should return PONG

# Or start Redis
redis-server
```

### 5. Deserialization Error

**Error:**

```python
# Wrong usage
payload = msgpack.unpackb(payload_bytes)  # Cannot deserialize numpy/torch
```

**Correct Usage:**

```python
from zaku.interfaces import Payload

payload = Payload.deserialize(payload_bytes)  # Correct
```

---

## Complete API Reference

### TaskQ (Synchronous Client)

#### Initialization

```python
TaskQ(
    name: str,  # Queue name
uri: str = None,  # Server address (default: http://localhost:9000)
s3_bucket: str = None,  # S3 bucket (default: from environment variable)
s3_region: str = "us-east-1"  # S3 region
)
```

#### Core Methods

| Method                       | Description                    | Parameters      | Returns                        |
|------------------------------|--------------------------------|-----------------|--------------------------------|
| `add(payload)`               | Add task                       | `payload: dict` | `job_id: str`                  |
| `take()`                     | Get task metadata              | -               | `(job_id, metadata)` or `None` |
| `pop()`                      | Context manager, auto-download | -               | `payload: dict`                |
| `download_from_s3(s3_key)`   | Download single payload        | `s3_key: str`   | `bytes`                        |
| `download_payloads(s3_keys)` | Batch concurrent download      | `s3_keys: list` | `list[bytes]`                  |
| `mark_done(job_id)`          | Mark as done and delete        | `job_id: str`   | `bool`                         |
| `mark_reset(job_id)`         | Reset task to pending          | `job_id: str`   | `bool`                         |
| `count()`                    | Get queue length               | -               | `int`                          |
| `clear_queue()`              | Clear queue                    | -               | `bool`                         |

#### PubSub/RPC Methods

| Method                             | Description              | Parameters                   | Returns                  |
|------------------------------------|--------------------------|------------------------------|--------------------------|
| `publish(payload, topic)`          | Publish message          | `payload: dict, topic: str`  | `int` (subscriber count) |
| `subscribe_one(topic, timeout)`    | Subscribe single message | `topic: str, timeout: float` | `dict` or `None`         |
| `subscribe_stream(topic, timeout)` | Streaming subscribe      | `topic: str, timeout: float` | `Iterator[dict]`         |
| `rpc(timeout, **kwargs)`           | RPC call                 | `_timeout: float, **kwargs`  | `dict`                   |
| `gather(jobs)`                     | Batch task collection    | `jobs: list[dict]`           | `(is_done, tokens)`      |

### TaskQAsync (Asynchronous Client)

All methods are the same as `TaskQ`, but require `await`:

```python
async with TaskQAsync(name="queue") as queue:
    job_id = await queue.add(payload)
    result = await queue.take()
    payloads = await queue.download_payloads(s3_keys)
    await queue.mark_done(job_id)
    # ...
```

---

## E2E Testing

### 1. Set Up Environment

```bash
uv venv --python 3.11
source .venv/bin/activate
```

**CPU:**
```bash
uv pip install -e ".[server]"
uv pip install torch --index-url https://download.pytorch.org/whl/cpu
```

**GPU:**
```bash
uv pip install -e ".[server,gpu]"
```

### 2. Configure `.env.dev`

```bash
cp .env.dev.template .env.dev
# then edit .env.dev with your S3 credentials
```

```bash
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_DB=0
REDIS_SSL=False

S3_BUCKET=your-bucket
S3_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
```

### 3. Run Tests

`mprocs` automatically starts the Zaku server before running tests — no manual
server startup needed.

**Option A — Run all test suites in parallel with mprocs:**

```bash
# Install mprocs (macOS)
brew install mprocs

mprocs --config mprocs.yaml
```

Then select a test suite and press `s` to start it.

**Option B — Run a single test suite with pytest (manual server required):**

```bash
# Start server first
zaku --port 9000 --verbose

# Then in another terminal
pytest specs/test_task_management.py -v -s
pytest specs/test_server.py -v -s
```

---

## Changelog

### v2.0.0 - Pure Redis + S3 Architecture (Current Version)

**Major Updates:**

- **Completely removed MongoDB dependency**
- Metadata stored in Redis JSON
- Payloads stored in S3
- Support for batch concurrent downloads (ThreadPoolExecutor / asyncio.gather)
- New async client `TaskQAsync`
- Optimized high-throughput consumption mode

**Performance Improvements:**

- Batch consumption throughput increased by **20x**
- Async mode throughput increased by **3x**

### v1.x - MongoDB Architecture (Deprecated)

- Used MongoDB + GridFS for payload storage
- No support for batch concurrent downloads
- Single synchronous client only

---

## Development

### Local Development Setup

1. **Install dependencies with uv:**

```bash
# Create virtual environment
uv venv

# Install with all dependencies (includes server, development tools, and extras)
uv pip install -e ".[all,server,dev]"
```

2. **Set up environment:**

```bash
# Copy template
cp .env.dev.template .env.dev

# Edit .env.dev with your configuration
# S3_BUCKET=zaku-dev-bucket
# S3_REGION=us-east-1
```

3. **Start development environment with mprocs:**

```bash
# Start Docker services (Redis) and Zaku server
mprocs --config mprocs.yaml
```

This will start:
- Docker containers (Redis Stack)
- Zaku server on http://localhost:9000
- Test suites ready to run (autostart: false)

<img src="./figures/mprocs_output.png" alt="mprocs development environment" width="75%">

### Running Tests

From within mprocs, you can start individual test suites:
- `test-local`: Basic local queue tests
- `test-interfaces`: Data type serialization tests
- `test-async-client`: Async client tests
- `test-task-manager`: Task management API tests
- `test-shared-queue`: Server, lifecycle, gather, and pubsub tests

Or run all tests from command line:

```bash
source .venv/bin/activate
ZAKU_URI=http://localhost:9000 pytest specs -v
```

---