import{t as x,d as P,ab as se,ac as re,j as e,S as G,Y as Q,ad as ie,r as R,P as k,v as _,E as W,G as w,ae as H,af as ae,ag as le,F as N,H as A,J as M,K as L,M as I,N as J,ah as ce,Q as Y,R as C,V as X,U as O,D as z,ai as de,aj as me,a7 as q,ak as he,x as ue,y as pe,al as K,am as ge,an as xe,ao as je,ap as fe,a0 as be,aq as Se,ar as ve,q as ye}from"./index-CM55kbki.js";import{L as Ce}from"./common-D633BMet.js";import{b as D,c as ee,f as te,a as ne,S as _e}from"./field-DjdabSXB.js";import{g as oe,i as Pe}from"./string-CqChYP_-.js";import"./NativeSelect-CHzTlSY3.js";const $e=P.div`
  margin-bottom: ${x.spacings.comfortable.medium};

  button + button {
    margin-left: ${x.spacings.comfortable.small} !important;
  }
`,we=P(se)`
  max-height: ${({$maxHeight:t})=>t};
  pointer-events: ${({$disablePointerEvents:t})=>t?"none":"auto"};

  display: flex;
  flex-direction: column;
`,Re=P.div.attrs(({$numStratColumns:t})=>({style:{gridTemplateColumns:`minmax(max-content, 2fr) repeat(${t}, 3fr)`}}))`
  display: grid;
  font-weight: ${x.typography.table.cell_header.fontWeight};
  font-size: ${x.typography.table.cell_text.fontSize};

  div {
    padding: ${x.spacings.comfortable.x_small} ${x.spacings.comfortable.small};

    &:nth-child(2) {    
      display: flex;
      justify-content: center;
      grid-column: 2 / -1;
    }
  }
`,Me=P(re).attrs(t=>({style:{gridTemplateRows:`repeat(${t.$numRows}, 14px)`,gridTemplateColumns:`minmax(max-content, 2fr) repeat(${t.$numStratColumns}, 3fr)`}}))`
  display: grid;
  overflow: auto;
  padding: ${x.spacings.comfortable.medium} ${x.spacings.comfortable.small};
`,Ee=P.div`
  padding: ${x.spacings.comfortable.x_small};

  button {
    width: 100%;
    height: 100%;
    display: block;

    background-color: ${x.colors.infographic.primary__moss_green_21.rgba}; 
    &:hover {
      background-color: ${x.colors.infographic.primary__moss_green_34.rgba};
    }

    &.unselected {
      background-color: ${x.colors.interactive.disabled__fill.rgba};
      &:hover {
        background-color: ${x.colors.infographic.primary__moss_green_21.rgba};
      }
    }
  }
`,Ie=P.div`
  grid-column: 1;

  button {
    height: 100%;  
    width: 100%;
    padding: ${x.spacings.comfortable.x_small};
    background-color: ${x.colors.ui.background__default.hex};

    span {
      justify-content: flex-start;
    }

    &:disabled:not(.orphan) {    
      background-color: ${x.colors.ui.background__default.hex};
      color: ${x.colors.text.static_icons__default.hex};
    }
    &.unselected:not(:hover) {
      color: ${x.colors.interactive.disabled__text.hex};
    }
  }
`,Te=P.div`
  grid-column: 1 / -1;
  border-bottom: 1px ${x.colors.ui.background__overlay.hex};
  border-bottom-style: ${({$lineStyle:t})=>t};
`;function F(t,o){return t.findIndex(s=>s.name===o)}function ke(t,o){return t.sort((s,i)=>{const c=F(o,s.name),r=F(o,i.name);return c-r})}const T=(t,o)=>t.filter(s=>!o.find(i=>i.name===s.name)).map(s=>s.name);function Ae(t,o,s,i){const c=D();return{removeItems:(d,m)=>{const b=new Set(m),n=(d==="horizons"?t:o).filter(l=>!b.has(l.name));c.setFieldValue(d,n)},addItems:(d,m)=>{const b=d==="horizons"?s:i,f=d==="horizons"?t:o,n=new Set(f.map(j=>j.name)),l=new Map(b.map(j=>[j.name,j])),S=m.filter(j=>!n.has(j)).flatMap(j=>l.get(j)??[]);if(S.length){const j=ke([...f,...S],b);c.setFieldValue(d,j)}},addAll:()=>{c.setFieldValue("horizons",s),c.setFieldValue("zones",i)},removeAll:()=>{c.setFieldValue("horizons",[]),c.setFieldValue("zones",[])}}}function Fe(t,o){const i=new Map;t.forEach(r=>{const a=F(o,r.top_horizon_name),g=F(o,r.base_horizon_name),p=[];for(let d=a;d<g;d++)p.push(d);i.set(r.name,{horizonIndices:p,rowStart:a,rowEnd:g,gridColumn:1})});const c=new Map;return Array.from(i.values()).sort((r,a)=>r.horizonIndices.length-a.horizonIndices.length).forEach(r=>{let a=1,g=!1;for(;!g;){c.has(a)||c.set(a,new Set);const p=c.get(a);if(!p)throw new Error("Invalid stratigraphy grid state");r.horizonIndices.some(m=>p.has(m))?a++:(r.horizonIndices.forEach(m=>{p.add(m)}),r.gridColumn=a,g=!0)}}),i}function ze(t,o){return e.jsxs(e.Fragment,{children:[t.name,e.jsx("br",{}),"Top: ",t.top_horizon_name,e.jsx("br",{}),"Base: ",t.base_horizon_name,e.jsx("br",{}),o?"Zone does not exist in RMS":""]})}function He(t,o,s){return e.jsxs(e.Fragment,{children:[t.name,e.jsx("br",{}),"Type: ",t.type,e.jsx("br",{}),o?"Horizon does not exist in RMS":s?"Horizon is used by one or more zones":""]})}function B({horizons:t,zones:o,unselectedHorizonNames:s,unselectedZoneNames:i,orphanHorizonNames:c,orphanZoneNames:r,onZoneClick:a,onHorizonClick:g,maxHeight:p}){const d=a??g,m=Fe(o,t),b=Math.max(1,t.length*2),f=Math.max(1,...Array.from(m.values(),u=>u.gridColumn)),n=new Set(c),l=new Set(r),S=new Set(s),j=new Set(i),E=new Set(o.filter(u=>!j.has(u.name)).flatMap(u=>[u.top_horizon_name,u.base_horizon_name]));return e.jsxs(we,{$disablePointerEvents:!d,$maxHeight:p,children:[e.jsxs(Re,{$numStratColumns:f,children:[e.jsx("div",{children:"Horizons"}),e.jsx("div",{children:"Zones"})]}),e.jsxs(Me,{$numStratColumns:f,$numRows:b,children:[t.map((u,y)=>{const h=y*2+1,v=n.has(u.name),$=E.has(u.name),V=S.has(u.name);return e.jsxs(e.Fragment,{children:[e.jsx(Ie,{style:{gridRow:`${h} / span 2`},children:e.jsx(G,{title:He(u,v,$),children:e.jsx(Q,{className:v?"orphan":V?"unselected":"",onClick:()=>g==null?void 0:g(u,V),variant:"ghost",color:v?"danger":"primary",disabled:$&&!v,children:u.name})})}),e.jsx(Te,{$lineStyle:u.type.startsWith("interpreted")?"solid":"dashed",style:{gridRow:h}})]},u.name)}),o.map(u=>{const y=m.get(u.name);if(!y)return null;const h=l.has(u.name),v=j.has(u.name);return e.jsx(Ee,{style:{gridRow:`${y.rowStart*2+2} / ${y.rowEnd*2+2}`,gridColumn:y.gridColumn+1},children:e.jsx(G,{title:ze(u,h),children:e.jsx(Q,{className:h?"orphan":v?"unselected":"",onClick:()=>a==null?void 0:a(u,v),variant:"ghost",color:h?"danger":"secondary",children:u.name})})},u.name)})]})]})}const Be=P.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: ${x.spacings.comfortable.xx_large};

  > div {
    overflow: auto;
  }

  h4 {
    text-decoration: underline;
  }
`,Z=P.div`
  margin-bottom: ${x.spacings.comfortable.medium};

  button + button {
    margin-left: ${x.spacings.comfortable.small} !important;
  }
`,Ne=P(ie)`
  margin-top: ${x.spacings.comfortable.medium};
`,{useAppForm:Oe}=ee({fieldContext:te,formContext:ne,fieldComponents:{},formComponents:{StratigraphyEditor:Qe,CancelButton:O,SubmitButton:X}});function Ve({setConfirmAction:t,onConfirm:o,confirmAction:s}){const i=()=>{t("")};return e.jsxs(de,{open:!!s,$minWidth:"25em",children:[e.jsx(C.Header,{children:"Confirm action"}),e.jsxs(C.CustomContent,{children:[e.jsx(_,{children:s==="add"?"This will add all available stratigraphy to the project.":"This will remove all stratigraphy from the project."}),e.jsx(_,{$marginBottom:"0",children:"Do you want to continue? "})]}),e.jsxs(C.Actions,{children:[e.jsx(w,{label:"Ok",onClick:()=>{o(),i()}}),e.jsx(O,{onClick:i})]})]})}function Ge({orphanZoneNames:t,orphanHorizonNames:o}){return e.jsxs(Ne,{children:[e.jsx(_,{children:"There are horizons or zones in the project stratigraphy that are no longer available in RMS. They need to be removed before data can be saved."}),e.jsxs(z,{children:[o.length>0&&e.jsx(z.Item,{children:o.join(", ")}),t.length>0&&e.jsx(z.Item,{children:t.join(", ")})]})]})}function Qe({availableHorizons:t,availableZones:o}){const s=D(),[i,c]=R.useState(""),r=s.getFieldValue("horizons"),a=s.getFieldValue("zones"),{removeItems:g,addItems:p,addAll:d,removeAll:m}=Ae(r,a,t,o),b=T(o,a),f=T(t,r),n=h=>{p("horizons",[h.name])},l=h=>{p("zones",[h.name]),p("horizons",[h.top_horizon_name,h.base_horizon_name])},S=h=>{g("horizons",[h.name]);const v=a.filter($=>$.top_horizon_name===h.name||$.base_horizon_name===h.name).map($=>$.name);g("zones",v)},j=h=>{g("zones",[h.name])},E=T(a,o),u=T(r,t),y=u.length>0||E.length>0;return R.useEffect(()=>{s.setErrorMap({onChange:y?["Orphan horizons or zones present"]:void 0})},[s,y]),e.jsxs(Be,{children:[e.jsxs("div",{children:[e.jsx(k,{$variant:"h4",children:"Project stratigraphy"}),e.jsx(B,{maxHeight:"55vh",horizons:r,zones:a,orphanHorizonNames:u,orphanZoneNames:E,onZoneClick:h=>{j(h)},onHorizonClick:h=>{S(h)}}),y&&e.jsx(Ge,{orphanZoneNames:E,orphanHorizonNames:u}),e.jsx(Z,{children:e.jsx(w,{label:"Remove all",variant:"outlined",disabled:!r.length&&!a.length,onClick:()=>{c("remove")}})})]}),e.jsxs("div",{children:[e.jsx(k,{$variant:"h4",children:"Available RMS stratigraphy"}),e.jsx(B,{maxHeight:"55vh",horizons:t,zones:o,unselectedHorizonNames:f,unselectedZoneNames:b,onZoneClick:(h,v)=>{v?l(h):j(h)},onHorizonClick:(h,v)=>{v?n(h):S(h)}}),e.jsx(Z,{children:e.jsx(w,{variant:"outlined",label:"Add all",disabled:r.length===t.length&&a.length===o.length,onClick:()=>{c("add")}})}),e.jsx(_,{children:"💡 Click on horizons or zones to add or remove them from the project stratigraphy."})]}),e.jsx(Ve,{confirmAction:i,setConfirmAction:c,onConfirm:i==="add"?d:m})]})}function qe({projectHorizons:t,projectZones:o,projectReadOnly:s,isDialogOpen:i,closeDialog:c,isRmsProjectOpen:r}){const{data:a}=H({...ae(),enabled:r}),{data:g}=H({...le(),enabled:r}),p=N(),d=A({...ce(),onSuccess:()=>{p.refetchQueries({queryKey:J()})},onError:n=>{var l;if(((l=n.response)==null?void 0:l.status)===M){const S=L(n);console.error(S),I.error(S)}},meta:{errorPrefix:"Error updating project stratigraphy",preventDefaultErrorHandling:[M]}}),m=Oe({defaultValues:{zones:o,horizons:t},onSubmit:({value:n,formApi:l})=>{s||b({formValue:n,formSubmitCallback:f,formReset:l.reset})}}),b=({formValue:n,formSubmitCallback:l,formReset:S})=>{d.mutate({body:n},{onSuccess:j=>{l({message:j.message,formReset:S}),c()}})},f=({message:n,formReset:l})=>{I.info(n),l()};return e.jsx(Y,{open:i,$minWidth:"60em",$maxWidth:"",children:e.jsxs("form",{onSubmit:n=>{n.preventDefault(),n.stopPropagation(),m.handleSubmit()},children:[e.jsx(C.Header,{children:"Set project stratigraphy"}),e.jsx(C.CustomContent,{children:e.jsx(m.AppForm,{children:e.jsx(m.Subscribe,{selector:n=>n.values,children:()=>e.jsx(m.StratigraphyEditor,{availableHorizons:a??[],availableZones:g??[]})})})}),e.jsxs(C.Actions,{children:[e.jsx(m.Subscribe,{selector:n=>[n.isDefaultValue,n.canSubmit],children:([n,l])=>e.jsx(m.SubmitButton,{label:"Save",disabled:n||!l||s,isPending:d.isPending,helperTextDisabled:s?"Project is read-only":"Form can be submitted when the values have changed"})}),e.jsx(m.CancelButton,{onClick:n=>{n.preventDefault(),m.reset(),c()}})]})]})})}function Ke({rmsData:t,projectReadOnly:o,isRmsProjectOpen:s}){const[i,c]=R.useState(!1),r=(t==null?void 0:t.horizons)??[],a=(t==null?void 0:t.zones)??[],g=()=>{c(!1)},p=()=>{c(!0)};return e.jsxs(e.Fragment,{children:[e.jsx(k,{$variant:"h3",children:"Stratigraphy"}),e.jsx(_,{children:"The following is the model stratigraphy stored in the project, this can be a subset or the full RMS stratigraphy. It is only the stored stratigraphy that will be possible to map to official stratigraphic names."}),r.length?e.jsx(B,{horizons:r,zones:a}):e.jsx(W,{children:"No stratigraphy information currently stored in the project."}),e.jsx(w,{label:r.length?"Edit":"Add",disabled:o||!s,tooltipText:o?"Project is read-only":s?void 0:"RMS project is not open",onClick:p}),e.jsx(qe,{projectHorizons:r,projectZones:a,projectReadOnly:o,isDialogOpen:i,closeDialog:g,isRmsProjectOpen:s})]})}const{useAppForm:Ze}=ee({fieldComponents:{Select:_e},formComponents:{SubmitButton:X,CancelButton:O},fieldContext:te,formContext:ne});function U(t){return{label:oe(t),value:t}}function Ue({rmsData:t,isDialogOpen:o,setIsDialogOpen:s}){const i=({formReset:n})=>{n(),s(!1)},c=N(),{data:r,isPending:a}=H(Se()),{mutate:g,isPending:p}=A({...ve(),onSuccess:()=>{c.invalidateQueries({queryKey:J()})},onError:n=>{var l;if(((l=n.response)==null?void 0:l.status)===M){const S=L(n);console.error(S),I.error(S)}},meta:{errorPrefix:"Error saving the RMS project",preventDefaultErrorHandling:[M]}}),d=Ze({defaultValues:{rmsPath:(t==null?void 0:t.path)??""},onSubmit:({value:n,formApi:l})=>{g({body:{path:n.rmsPath}},{onSuccess:()=>{I.info("Successfully set the RMS project"),i({formReset:l.reset})}})}}),m=(r==null?void 0:r.results)??[];function b(n){return m.some(l=>l.path===n)}const f=m.map(n=>U(n.path));return t?b(t.path)||f.unshift(U(t.path)):f.unshift({label:"(none)",value:""}),e.jsx(Y,{open:o,$minWidth:"32em",children:e.jsxs("form",{onSubmit:n=>{n.preventDefault(),n.stopPropagation(),d.handleSubmit()},children:[e.jsx(C.Header,{children:e.jsx(C.Title,{children:"RMS project"})}),e.jsx(C.Content,{children:e.jsx(d.AppField,{name:"rmsPath",validators:{onMount:()=>m.length===0?"Could not detect any RMS projects in the rms/model directory":t&&!b(t.path)?"Selected project does not exist":void 0,onChange:({value:n})=>b(n)?void 0:"Selected project does not exist"},children:n=>e.jsx(n.Select,{label:"RMS project",value:n.state.value,options:f,loadingOptions:a,onChange:l=>{n.handleChange(l)}})})}),e.jsxs(C.Actions,{children:[e.jsx(d.Subscribe,{selector:n=>[n.isDefaultValue,n.canSubmit],children:([n,l])=>e.jsx(d.SubmitButton,{label:"Save",disabled:n||!l,isPending:p,helperTextDisabled:"Value can be submitted when it has been changed and is valid"})}),e.jsx(d.CancelButton,{onClick:n=>{n.preventDefault(),i({formReset:d.reset})}})]})]})})}function We({rmsData:t}){return e.jsx(pe,{children:e.jsx("table",{children:e.jsxs("tbody",{children:[e.jsxs("tr",{children:[e.jsx("th",{children:"Project"}),e.jsx("td",{children:oe(t.path)})]}),e.jsxs("tr",{children:[e.jsx("th",{children:"Version"}),e.jsx("td",{children:t.version})]})]})})})}function Le({rmsData:t,projectReadOnly:o,setIsRmsProjectOpen:s,isRmsProjectOpen:i}){const c=N(),[r,a]=R.useState(!1),g=t&&Pe(t.version,K)?K:void 0,p=A({...je(),onSuccess:()=>{s(!0),c.invalidateQueries({queryKey:ge()}),c.invalidateQueries({queryKey:xe()})},onError:(m,b)=>{var f,n;if(s(!1),(f=b.body)!=null&&f.version){p.mutate({});return}if(((n=m.response)==null?void 0:n.status)===M){const l=m.response.data.detail;console.error(l),I.error(l)}},meta:{errorPrefix:"Error opening the RMS project",preventDefaultErrorHandling:[M]}}),d=A({...fe(),onSuccess:()=>{s(!1)},meta:{errorPrefix:"Error closing the RMS project"}});return e.jsxs(e.Fragment,{children:[(t==null?void 0:t.path)&&(p.isPending?e.jsx(_,{children:"⏳ Opening the RMS project. This might take a while..."}):i?e.jsx(_,{children:"✅ The RMS project is open and data is accessible"}):e.jsx(_,{children:"⛔ The RMS project needs to be opened to access data"})),e.jsxs($e,{children:[e.jsx(w,{label:t!=null&&t.path?"Change project":"Select project",disabled:!!o||i||p.isPending,tooltipText:o?"Project is read-only":i?"Close the RMS project to select a new one":"",onClick:()=>{c.invalidateQueries({queryKey:be()}),a(!0)}}),(t==null?void 0:t.path)&&e.jsxs(e.Fragment,{children:[e.jsx(w,{label:i?"Reload project":"Open project",isPending:p.isPending,disabled:d.isPending,variant:i?"outlined":"contained",onClick:()=>{p.mutate({body:g?{version:g}:void 0})}}),i&&!p.isPending&&e.jsx(w,{label:"Close project",variant:"outlined",isPending:d.isPending,onClick:()=>{d.mutate({})}})]})]}),e.jsx(Ue,{rmsData:t,isDialogOpen:r,setIsDialogOpen:a})]})}function Je({rmsData:t,projectReadOnly:o}){const[s,i]=R.useState(me(sessionStorage,q,"boolean"));return R.useEffect(()=>{he(sessionStorage,q,s)},[s]),e.jsxs(e.Fragment,{children:[e.jsxs(_,{children:["The following is the main RMS project located in the ",e.jsx("i",{children:"rms/model"})," ","directory. The version is detected automatically:"]}),t?e.jsx(We,{rmsData:t}):e.jsx(W,{children:"No RMS project information found in the project."}),e.jsx(Le,{rmsData:t,projectReadOnly:o,setIsRmsProjectOpen:i,isRmsProjectOpen:s}),e.jsx(ue,{}),e.jsx(Ke,{rmsData:t,projectReadOnly:o,isRmsProjectOpen:s})]})}function Ye(){var o;const t=ye();return t.status&&t.data?e.jsx(Je,{rmsData:t.data.config.rms,projectReadOnly:!(((o=t.lockStatus)==null?void 0:o.is_lock_acquired)??!1)}):e.jsx(_,{children:"Project not set."})}const ot=function(){return e.jsxs(e.Fragment,{children:[e.jsx(k,{children:"RMS"}),e.jsx(R.Suspense,{fallback:e.jsx(Ce,{}),children:e.jsx(Ye,{})})]})};export{ot as component};
