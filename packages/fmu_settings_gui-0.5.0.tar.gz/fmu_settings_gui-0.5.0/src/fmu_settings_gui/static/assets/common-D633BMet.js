import{j as n,v as o}from"./index-CM55kbki.js";function t(){return n.jsx(o,{children:"Loading..."})}export{t as L};
