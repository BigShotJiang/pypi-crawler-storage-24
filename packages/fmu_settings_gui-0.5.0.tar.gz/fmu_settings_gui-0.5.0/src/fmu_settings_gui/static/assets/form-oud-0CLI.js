import{t as c,d as x,r as b,j as e,V as F,G as D,U as E,M as T}from"./index-CM55kbki.js";import{c as h,T as V,f as S,a as j,k}from"./field-DjdabSXB.js";import{h as y}from"./validator-DsEsAMFG.js";const R=x.div`
  form > div {
    margin-bottom: ${c.spacings.comfortable.medium};
  }

  button + button {
    margin-left: ${c.spacings.comfortable.small};
  }
`,G=x.div`
  display: flex;
  gap: ${c.spacings.comfortable.small}
`,{useAppForm:P}=h({fieldContext:S,formContext:j,fieldComponents:{TextField:V},formComponents:{CancelButton:E,GeneralButton:D,SubmitButton:F}});function H({name:a,label:i,value:r,placeholder:l,helperText:n,length:o,minLength:d,mutationCallback:v,mutationIsPending:C}){const[p,m]=b.useState(!0),[g,A]=b.useState(!0),f=y({length:o,minLength:d,initialValue:r}),B=({message:t,formReset:u})=>{T.info(t),u(),m(!0)},s=P({defaultValues:{[a]:r},onSubmit:({formApi:t,value:u})=>{v({formValue:u,formSubmitCallback:B,formReset:t.reset})}});return e.jsx(R,{children:e.jsxs("form",{onSubmit:t=>{t.preventDefault(),t.stopPropagation(),s.handleSubmit()},children:[e.jsx(s.AppField,{name:a,...f&&{validators:{onBlur:f}},children:t=>e.jsx(t.TextField,{label:i,placeholder:l,helperText:n,isReadOnly:p,setSubmitDisabled:A})}),e.jsx(s.AppForm,{children:p?e.jsx(s.GeneralButton,{label:"Edit",onClick:()=>{m(!1)}}):e.jsxs(e.Fragment,{children:[e.jsx(s.SubmitButton,{label:"Save",disabled:g,isPending:C,helperTextDisabled:"Value can be submitted when it has been changed and is valid"}),e.jsx(s.CancelButton,{onClick:t=>{t.preventDefault(),s.reset(),m(!0)},onMouseDown:t=>{t.preventDefault()}})]})})]})})}const{useAppForm:$}=h({fieldContext:S,formContext:j,fieldComponents:{SearchField:k},formComponents:{SubmitButton:F}});function I({name:a,value:i,helperText:r,setStateCallback:l}){const n=$({defaultValues:{[a]:i},onSubmit:({formApi:o,value:d})=>{l(d[a]),o.reset()}});return e.jsx("form",{onSubmit:o=>{o.preventDefault(),o.stopPropagation(),n.handleSubmit()},children:e.jsxs(G,{children:[e.jsx(n.AppField,{name:a,children:o=>e.jsx(o.SearchField,{helperText:r,toUpperCase:!0})}),e.jsx(n.AppForm,{children:e.jsx(n.SubmitButton,{label:"Search"})})]})})}export{H as E,I as S};
