import{z as ie,j as e,t as a,d as h,y as oe,ab as ae,ac as w,F as le,r as d,ae as F,bt as ce,bu as de,H as he,N as ue,bv as pe,M as ge,bw as xe,v as c,ai as Y,R as x,C as je,bx as I,G as W,Y as Z,U as fe,P as me,q as be}from"./index-CM55kbki.js";import{L as $e}from"./common-D633BMet.js";import{N as ye}from"./NativeSelect-CHzTlSY3.js";const ve=["config.json","mappings.json"],V={"config.json":"Project configuration","mappings.json":"Mappings"},z=["identifier","source_id","target_id","name","uuid","id"];function J(s){return typeof s=="object"&&s!==null&&!Array.isArray(s)}function X(s){return"added"in s&&"removed"in s&&"updated"in s}function ke(s){const n=s.split("/").pop()??s,r=/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})\.(\d+)Z/.exec(n);if(!r)return null;const[,t,i,l,p,u,k,f]=r,$=f.slice(0,3).padEnd(3,"0");return new Date(`${t}-${i}-${l}T${p}:${u}:${k}.${$}Z`)}function De(s){const n=ke(s);return n?ie(n.toISOString()):"Unknown date"}function N(s){return s.split(".").join(" > ")}function j(s){if(s===null)return"null";if(s===void 0)return"(missing)";if(typeof s=="string")return s===""?"(empty string)":s;if(typeof s=="number"||typeof s=="boolean")return String(s);if(Array.isArray(s))return s.length===0?"(empty list)":`${String(s.length)} values`;if(J(s)){const n=z.find(r=>r in s);return n!==void 0?`${n}: ${j(s[n])}`:`(${String(Object.keys(s).length)} fields)`}return typeof s=="bigint"?s.toString():typeof s=="symbol"?s.description?`symbol(${s.description})`:"symbol":"(unavailable)"}function Se(s){const n=z.find(t=>t in s);return n!==void 0?`${n}-${j(s[n])}`:Object.entries(s).map(([t,i])=>`${t}:${j(i)}`).join("|")||"empty-item"}function we(s){const n=s.before===null||s.before===void 0,r=s.after===null||s.after===void 0;return n&&!r?"added":!n&&r?"removed":"updated"}function Q(s){return`Snapshot ${s+1}`}function _({value:s}){if(Array.isArray(s))return s.length===0?e.jsx("p",{children:"(empty list)"}):e.jsx("ul",{children:s.map((n,r)=>e.jsx("li",{children:j(n)},`${String(r)}-${j(n)}`))});if(J(s)){const n=Object.entries(s);return n.length===0?e.jsx("p",{children:"(empty object)"}):e.jsx("table",{children:e.jsx("tbody",{children:n.map(([r,t])=>e.jsxs("tr",{children:[e.jsx("th",{children:r}),e.jsx("td",{children:j(t)})]},r))})})}return e.jsx("p",{children:j(s)})}const K={added:{background:a.colors.interactive.success__highlight.hex,color:a.colors.interactive.success__resting.hex},removed:{background:a.colors.ui.background__danger.hex,color:a.colors.interactive.danger__resting.hex},updated:{background:a.colors.ui.background__info.hex,color:a.colors.interactive.primary__resting.hex}},_e=h.div`
  max-width: 15em;
  margin-bottom: ${a.spacings.comfortable.medium};
`,E=h.div`
  > div + div {
    margin-top: ${a.spacings.comfortable.small};
  }
`,Pe=h(oe)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: ${a.spacings.comfortable.small};
  flex-wrap: wrap;
  margin-bottom: 0;
  border-left: 0.25rem solid
    ${({$selected:s,$isAutoBackup:n})=>s||n?a.colors.interactive.primary__resting.hex:a.colors.ui.background__medium.hex};
  ${({$isAutoBackup:s})=>s&&`background: ${a.colors.ui.background__info.hex};`}
`,Re=h(ae)`
  background: ${a.colors.ui.background__info.hex};
  margin-bottom: 0;

  ul {
    padding-right: 40px;
  }
`,Ce=h.div`
  display: flex;
  flex-direction: column;
  gap: ${a.spacings.comfortable.small};
  max-height: 70vh;
  overflow: auto;
`,R=h.div`
  display: flex;
  flex-direction: column;
  gap: ${a.spacings.comfortable.small};
`,S=h.div`
  margin-bottom: ${a.spacings.comfortable.small};
`,B=h.div`
  border: 1px solid ${({$kind:s})=>K[s].color};
  background: ${({$kind:s})=>K[s].background};
  border-radius: ${a.shape.corners.borderRadius};
  padding: ${a.spacings.comfortable.small};
`,ee=h.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: ${a.spacings.comfortable.small};

  @media (max-width: 48em) {
    grid-template-columns: 1fr;
  }
`,P=h(w)`
  th {
    text-align: left;
    vertical-align: top;
    padding-right: ${a.spacings.comfortable.small};
    white-space: nowrap;
  }

  td {
    vertical-align: top;
    word-break: break-word;
  }

  p {
    margin-top: 0;
  }
`;function H({kind:s,title:n,values:r}){return r.length===0?null:e.jsxs(B,{$kind:s,children:[e.jsx(S,{children:e.jsxs("strong",{children:[n," (",String(r.length),")"]})}),e.jsx(R,{children:r.map((t,i)=>e.jsx(P,{children:e.jsx(_,{value:t})},`${n}-${String(i)}-${Se(t)}`))})]})}function Te({updated:s}){return s.length===0?null:e.jsxs(B,{$kind:"updated",children:[e.jsx(S,{children:e.jsxs("strong",{children:["Updated (",String(s.length),")"]})}),e.jsx(R,{children:s.map((n,r)=>e.jsx(w,{children:e.jsxs(ee,{children:[e.jsxs(P,{children:[e.jsx("strong",{children:"Before restore"}),e.jsx(_,{value:n.before})]}),e.jsxs(P,{children:[e.jsx("strong",{children:"After restore"}),e.jsx(_,{value:n.after})]})]})},`updated-${String(r)}-${j(n.key)}`))})]})}function Ae({diff:s}){if(X(s))return e.jsxs(w,{children:[e.jsx(S,{children:e.jsx("strong",{children:N(s.field_path)})}),e.jsxs(R,{children:[e.jsx(H,{kind:"added",title:"Added",values:s.added}),e.jsx(H,{kind:"removed",title:"Removed",values:s.removed}),e.jsx(Te,{updated:s.updated})]})]});const n=we(s);return e.jsxs(w,{children:[e.jsx(S,{children:e.jsx("strong",{children:N(s.field_path)})}),e.jsxs(B,{$kind:n,children:[e.jsx(S,{children:e.jsxs("strong",{children:[n.charAt(0).toUpperCase()+n.slice(1)," (1)"]})}),e.jsxs(ee,{children:[e.jsxs(P,{children:[e.jsx("strong",{children:"Before restore"}),e.jsx(_,{value:s.before})]}),e.jsxs(P,{children:[e.jsx("strong",{children:"After restore"}),e.jsx(_,{value:s.after})]})]})]})]})}function Le({entry:s,isSelected:n,onViewDetails:r}){return e.jsxs(Pe,{$selected:n,$isAutoBackup:s.isAutoBackup,children:[e.jsxs(E,{children:[e.jsx("div",{children:e.jsx("strong",{children:s.label})}),e.jsx("div",{children:s.dateTimeLabel})]}),e.jsx(Z,{onClick:()=>{r(s.cacheId)},children:"View details"})]})}function Ie({isOpen:s,resourceLabel:n,selectedCacheEntry:r,diffEntries:t,isDiffPending:i,isDiffError:l,isRestorePending:p,isRestoreDisabled:u,restoreTooltipText:k,onRestore:f,onClose:$}){return e.jsxs(Y,{open:s,$maxWidth:"56em",children:[e.jsx(x.Header,{children:e.jsxs(x.Title,{children:[n," -"," ",(r==null?void 0:r.dateTimeLabel)??"Unknown date"]})}),e.jsx(x.CustomContent,{children:e.jsxs(Ce,{children:[t&&t.length>0&&e.jsxs(Re,{children:[e.jsx(c,{children:"These changes show what will happen if you restore this snapshot."}),e.jsxs(je,{children:[e.jsxs(I,{children:[e.jsx("strong",{children:"Added:"})," Values that will be added to the current resource"]}),e.jsxs(I,{children:[e.jsx("strong",{children:"Removed:"})," Values that will be removed from the current resource"]}),e.jsxs(I,{children:[e.jsx("strong",{children:"Updated:"})," Values that will be replaced in the current resource"]})]})]}),i&&e.jsx(c,{$marginBottom:"0",children:"Loading differences..."}),l&&e.jsx(c,{$marginBottom:"0",children:"Unable to load differences for this snapshot."}),(t==null?void 0:t.length)===0&&e.jsx(c,{$marginBottom:"0",children:"No differences found between current version and this snapshot."}),e.jsx(R,{children:t==null?void 0:t.map((y,g)=>e.jsx(Ae,{diff:y},`${y.field_path}-${String(g)}-${X(y)?"list":"scalar"}`))})]})}),e.jsxs(x.Actions,{children:[e.jsx(W,{label:"Restore",isPending:p,disabled:u,tooltipText:k,onClick:f}),e.jsx(Z,{variant:"outlined",onClick:$,children:"Close"})]})]})}function Be({isOpen:s,resourceLabel:n,selectedCacheEntry:r,isRestorePending:t,isRestoreDisabled:i,restoreTooltipText:l,onRestore:p,onCancel:u}){return e.jsxs(Y,{open:s,$maxWidth:"36em",children:[e.jsx(x.Header,{children:e.jsx(x.Title,{children:"Restore from snapshot"})}),e.jsxs(x.Content,{children:[e.jsxs(c,{children:["This will overwrite the current",e.jsxs("span",{className:"emphasis",children:[" ",n]})," with",e.jsxs("span",{className:"emphasis",children:[" ",(r==null?void 0:r.label)??"this snapshot"]}),"."]}),e.jsx(w,{children:e.jsxs(E,{children:[e.jsx("div",{children:e.jsx("strong",{children:(r==null?void 0:r.label)??"Selected snapshot"})}),e.jsx("div",{children:(r==null?void 0:r.dateTimeLabel)??"Unknown date"})]})})]}),e.jsxs(x.Actions,{children:[e.jsx(W,{label:"Restore",isPending:t,disabled:i,tooltipText:l,onClick:p}),e.jsx(fe,{onClick:u})]})]})}function Oe({projectReadOnly:s}){var G,q,M;const n=le(),[r,t]=d.useState("config.json"),[i,l]=d.useState(null),[p,u]=d.useState(!1),[k,f]=d.useState(!1),[$,y]=d.useState(null),g=F({...ce({query:{resource:r}}),refetchOnMount:"always",meta:{errorPrefix:"Error loading snapshot history"}}),m=d.useMemo(()=>{var o;return[...((o=g.data)==null?void 0:o.revisions)??[]].reverse()},[(G=g.data)==null?void 0:G.revisions]),A=d.useMemo(()=>m.map((o,b)=>{const C=$!==null&&b===0;return{cacheId:o,label:C?`${Q(b)} (pre-restore)`:Q(b),dateTimeLabel:De(o),isAutoBackup:C}}),[m,$]),O=A.find(o=>o.cacheId===i),L=V[r];d.useEffect(()=>{if(m.length===0){l(null);return}(i===null||!m.includes(i))&&l(m[0])},[m,i]);const v=F({...de({path:{revision_id:i??""},query:{resource:r}}),enabled:p&&i!==null,staleTime:0,refetchOnMount:"always",meta:{errorPrefix:"Error loading snapshot details"}}),D=he({...xe(),meta:{errorPrefix:"Error restoring snapshot"},onSuccess:(o,b)=>{n.invalidateQueries({queryKey:ue()}),n.invalidateQueries({queryKey:pe({query:{resource:b.query.resource}})}),n.invalidateQueries({predicate:C=>{var U;const T=C.queryKey[0];return(T==null?void 0:T._id)==="projectGetCacheDiff"&&((U=T.query)==null?void 0:U.resource)===b.query.resource}}),ge.info("Restore successful. An auto-backup of your previous state has been saved at the top of the list"),y(b.path.revision_id),f(!1),l(null)}});function se(o){l(o),u(!0)}function ne(o){l(o),f(!0)}function re(){u(!1),i&&ne(i)}function te(){i&&D.mutate({path:{revision_id:i},query:{resource:r}})}return d.useEffect(()=>{y(null)},[r]),e.jsxs(e.Fragment,{children:[e.jsx(Ie,{isOpen:p,resourceLabel:L,selectedCacheEntry:O,diffEntries:v.data,isDiffPending:v.isPending,isDiffError:v.isError,isRestorePending:D.isPending,isRestoreDisabled:s||D.isPending||i===null||v.isPending||((q=v.data)==null?void 0:q.length)===0,restoreTooltipText:s?"Project is read-only":((M=v.data)==null?void 0:M.length)===0?"No differences to restore":void 0,onRestore:re,onClose:()=>{u(!1)}}),e.jsx(Be,{isOpen:k,resourceLabel:L,selectedCacheEntry:O,isRestorePending:D.isPending,isRestoreDisabled:s||D.isPending||i===null,restoreTooltipText:s?"Project is read-only":void 0,onRestore:te,onCancel:()=>{f(!1)}}),e.jsx(c,{children:"Choose a resource to view its snapshots, listed from newest to oldest."}),e.jsxs(c,{children:["Use ",e.jsx("strong",{children:'"View details"'})," to see what has changed between the snapshot and the current version."," ",s?e.jsx(e.Fragment,{children:"The project is currently read-only, so restore of the snapshot is not possible."}):e.jsxs(e.Fragment,{children:["You can also ",e.jsx("strong",{children:"restore"})," from the snapshot."]})]}),e.jsx(_e,{children:e.jsx(ye,{id:"history-resource",label:"Resource",value:r,onChange:o=>{t(o.target.value)},children:ve.map(o=>e.jsx("option",{value:o,children:V[o]},o))})}),g.isPending&&e.jsx(c,{children:"Loading snapshots..."}),g.isError&&e.jsx(c,{children:"Unable to load snapshot history."}),!g.isPending&&!g.isError&&m.length===0&&e.jsxs(c,{children:["No snapshots found for ",L,"."]}),A.length>0&&e.jsx(R,{children:A.map(o=>e.jsx(Le,{entry:o,isSelected:i===o.cacheId,onViewDetails:se},o.cacheId))})]})}function Ge(){var r,t;const s=be(),n=!(((r=s.lockStatus)==null?void 0:r.is_lock_acquired)??!1);return s.status?e.jsx(Oe,{projectReadOnly:n},((t=s.data)==null?void 0:t.path)??"history-no-project"):e.jsx(c,{children:"Project not set."})}const Fe=function(){return e.jsxs(e.Fragment,{children:[e.jsx(me,{children:"History"}),e.jsx(d.Suspense,{fallback:e.jsx($e,{}),children:e.jsx(Ge,{})})]})};export{Fe as component};
