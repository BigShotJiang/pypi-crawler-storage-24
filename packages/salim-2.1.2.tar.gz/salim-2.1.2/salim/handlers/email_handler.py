"""
Salim Email Integration — Full email management via Telegram.

Supports multiple providers:
  • Gmail (OAuth2 via google-auth)
  • SMTP/IMAP (generic — Yahoo, Outlook, custom servers)
  • Outlook/Microsoft 365 (MSAL OAuth2)

Commands:
  /email setup              — Interactive setup wizard
  /email inbox [n]          — Show latest n emails (default 10)
  /email read <id>          — Read full email by index
  /email send <to> <subject> <body>  — Send email
  /email reply <id> <body>  — Reply to email by index
  /email search <query>     — Search inbox
  /email unread             — Show only unread emails
  /email delete <id>        — Move email to trash
  /email status             — Show connection status
  /email accounts           — List configured accounts

Storage: ~/.salim/email_config.json (encrypted credentials)
"""
from __future__ import annotations

import asyncio
import base64
import email as _email_lib
import html
import imaplib
import json
import logging
import re
import smtplib
import ssl
import time
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import decode_header as _decode_header
from pathlib import Path
from typing import Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.email")

EMAIL_CONFIG_FILE = Path.home() / ".salim" / "email_config.json"

# In-memory session: maps user_id → list of fetched email summaries (for /email read <n>)
_email_sessions: dict[int, list[dict]] = {}

# Wizard state: user_id → wizard step data
_setup_wizards: dict[int, dict] = {}

KNOWN_PROVIDERS = {
    "gmail": {
        "imap_host": "imap.gmail.com",
        "imap_port": 993,
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587,
        "label": "Gmail",
        "note": "Use an App Password (not your regular password). "
                "Go to Google Account → Security → 2-Step Verification → App passwords.",
    },
    "outlook": {
        "imap_host": "outlook.office365.com",
        "imap_port": 993,
        "smtp_host": "smtp.office365.com",
        "smtp_port": 587,
        "label": "Outlook / Microsoft 365",
        "note": "Use your full email and password, or an app password if MFA is enabled.",
    },
    "yahoo": {
        "imap_host": "imap.mail.yahoo.com",
        "imap_port": 993,
        "smtp_host": "smtp.mail.yahoo.com",
        "smtp_port": 587,
        "label": "Yahoo Mail",
        "note": "Generate an App Password in Yahoo Security settings.",
    },
    "hotmail": {
        "imap_host": "outlook.office365.com",
        "imap_port": 993,
        "smtp_host": "smtp.office365.com",
        "smtp_port": 587,
        "label": "Hotmail (now Outlook)",
        "note": "Use your full email and password.",
    },
    "icloud": {
        "imap_host": "imap.mail.me.com",
        "imap_port": 993,
        "smtp_host": "smtp.mail.me.com",
        "smtp_port": 587,
        "label": "iCloud Mail",
        "note": "Use an App-Specific Password from appleid.apple.com.",
    },
}


def _esc(v) -> str:
    return html.escape(str(v), quote=False)


# ─── Config persistence ──────────────────────────────────────────────────────

def _load_email_config() -> dict:
    if EMAIL_CONFIG_FILE.exists():
        try:
            return json.loads(EMAIL_CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_email_config(data: dict):
    EMAIL_CONFIG_FILE.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    EMAIL_CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    EMAIL_CONFIG_FILE.chmod(0o600)


def _get_default_account() -> Optional[dict]:
    cfg = _load_email_config()
    accounts = cfg.get("accounts", [])
    if not accounts:
        return None
    default_name = cfg.get("default", accounts[0]["name"])
    for acc in accounts:
        if acc["name"] == default_name:
            return acc
    return accounts[0]


def _decode_str(s) -> str:
    """Decode email header string (handles encoded-words)."""
    if not s:
        return ""
    parts = []
    for raw, charset in _decode_header(str(s)):
        if isinstance(raw, bytes):
            try:
                parts.append(raw.decode(charset or "utf-8", errors="replace"))
            except Exception:
                parts.append(raw.decode("utf-8", errors="replace"))
        else:
            parts.append(str(raw))
    return "".join(parts)


def _get_email_body(msg) -> str:
    """Extract plain-text body from email.message.Message object."""
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            disp = str(part.get("Content-Disposition", ""))
            if ct == "text/plain" and "attachment" not in disp:
                charset = part.get_content_charset() or "utf-8"
                try:
                    body = part.get_payload(decode=True).decode(charset, errors="replace")
                    break
                except Exception:
                    pass
    else:
        charset = msg.get_content_charset() or "utf-8"
        try:
            body = msg.get_payload(decode=True).decode(charset, errors="replace")
        except Exception:
            body = str(msg.get_payload())
    return body.strip()


# ─── IMAP helpers ─────────────────────────────────────────────────────────────

def _imap_connect(account: dict) -> imaplib.IMAP4_SSL:
    """Open IMAP connection, return logged-in client."""
    host = account["imap_host"]
    port = int(account.get("imap_port", 993))
    password = base64.b64decode(account["password_b64"]).decode()
    ctx = ssl.create_default_context()
    imap = imaplib.IMAP4_SSL(host, port, ssl_context=ctx)
    imap.login(account["email"], password)
    return imap


def _imap_fetch_emails(account: dict, folder: str = "INBOX",
                       limit: int = 10, unread_only: bool = False) -> list[dict]:
    """Fetch email summaries. Returns list of dicts."""
    imap = _imap_connect(account)
    try:
        imap.select(folder, readonly=True)
        criteria = "(UNSEEN)" if unread_only else "ALL"
        _, data = imap.search(None, criteria)
        uids = data[0].split()
        if not uids:
            return []
        # Latest first
        uids = list(reversed(uids[-limit:]))
        emails = []
        for i, uid in enumerate(uids):
            _, msg_data = imap.fetch(uid, "(BODY.PEEK[HEADER.FIELDS (FROM TO SUBJECT DATE)])")
            raw = msg_data[0][1] if msg_data and msg_data[0] else b""
            parsed = _email_lib.message_from_bytes(raw)
            emails.append({
                "idx": i + 1,
                "uid": uid.decode(),
                "from": _decode_str(parsed.get("From", "")),
                "to": _decode_str(parsed.get("To", "")),
                "subject": _decode_str(parsed.get("Subject", "(no subject)")),
                "date": _decode_str(parsed.get("Date", "")),
            })
        return emails
    finally:
        try:
            imap.logout()
        except Exception:
            pass


def _imap_fetch_full(account: dict, uid: str, folder: str = "INBOX") -> Optional[dict]:
    """Fetch full email by UID."""
    imap = _imap_connect(account)
    try:
        imap.select(folder, readonly=True)
        _, data = imap.fetch(uid.encode(), "(RFC822)")
        if not data or not data[0]:
            return None
        raw = data[0][1]
        msg = _email_lib.message_from_bytes(raw)
        body = _get_email_body(msg)
        return {
            "uid": uid,
            "from": _decode_str(msg.get("From", "")),
            "to": _decode_str(msg.get("To", "")),
            "subject": _decode_str(msg.get("Subject", "")),
            "date": _decode_str(msg.get("Date", "")),
            "body": body,
        }
    finally:
        try:
            imap.logout()
        except Exception:
            pass


def _imap_search(account: dict, query: str, limit: int = 10) -> list[dict]:
    """Search emails by subject or sender."""
    imap = _imap_connect(account)
    try:
        imap.select("INBOX", readonly=True)
        # Search by subject OR sender
        _, sub_data = imap.search(None, f'(SUBJECT "{query}")')
        _, from_data = imap.search(None, f'(FROM "{query}")')
        uids_set = set()
        for d in [sub_data, from_data]:
            if d and d[0]:
                uids_set.update(d[0].split())
        uids = list(reversed(sorted(uids_set, key=lambda x: int(x))))[:limit]
        emails = []
        for i, uid in enumerate(uids):
            _, msg_data = imap.fetch(uid, "(BODY.PEEK[HEADER.FIELDS (FROM TO SUBJECT DATE)])")
            raw = msg_data[0][1] if msg_data and msg_data[0] else b""
            parsed = _email_lib.message_from_bytes(raw)
            emails.append({
                "idx": i + 1,
                "uid": uid.decode() if isinstance(uid, bytes) else uid,
                "from": _decode_str(parsed.get("From", "")),
                "to": _decode_str(parsed.get("To", "")),
                "subject": _decode_str(parsed.get("Subject", "(no subject)")),
                "date": _decode_str(parsed.get("Date", "")),
            })
        return emails
    finally:
        try:
            imap.logout()
        except Exception:
            pass


def _imap_delete(account: dict, uid: str, folder: str = "INBOX") -> bool:
    """Move email to Trash."""
    imap = _imap_connect(account)
    try:
        imap.select(folder)
        imap.store(uid.encode(), "+FLAGS", "\\Deleted")
        imap.expunge()
        return True
    except Exception as e:
        logger.error(f"IMAP delete failed: {e}")
        return False
    finally:
        try:
            imap.logout()
        except Exception:
            pass


def _smtp_send(account: dict, to: str, subject: str, body: str,
               reply_to_msg: Optional[dict] = None) -> bool:
    """Send an email via SMTP."""
    host = account["smtp_host"]
    port = int(account.get("smtp_port", 587))
    password = base64.b64decode(account["password_b64"]).decode()
    sender = account["email"]

    msg = MIMEMultipart("alternative")
    msg["From"] = sender
    msg["To"] = to
    msg["Subject"] = subject
    if reply_to_msg:
        msg["In-Reply-To"] = reply_to_msg.get("uid", "")
        msg["References"] = reply_to_msg.get("uid", "")

    msg.attach(MIMEText(body, "plain", "utf-8"))

    ctx = ssl.create_default_context()
    with smtplib.SMTP(host, port) as server:
        server.ehlo()
        server.starttls(context=ctx)
        server.login(sender, password)
        server.sendmail(sender, [to], msg.as_string())
    return True


# ─── Bot handlers ──────────────────────────────────────────────────────────────

class EmailHandlers:
    """Mixin for SalimBot — adds full email management commands."""

    @require_auth
    async def cmd_email(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /email [sub-command] — Email management
        Sub-commands: setup, inbox, read, send, reply, search, unread, delete, status, accounts
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []
        sub = args[0].lower() if args else "inbox"

        if sub == "setup":
            await self._email_setup_start(msg, user_id)
        elif sub == "inbox":
            limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 10
            await self._email_inbox(msg, user_id, limit=limit)
        elif sub == "unread":
            await self._email_inbox(msg, user_id, unread_only=True)
        elif sub == "read" and len(args) >= 2:
            await self._email_read(msg, user_id, args[1])
        elif sub == "send" and len(args) >= 4:
            to = args[1]
            subject = args[2]
            body = " ".join(args[3:])
            await self._email_send(msg, user_id, to, subject, body)
        elif sub == "reply" and len(args) >= 3:
            idx = args[1]
            body = " ".join(args[2:])
            await self._email_reply(msg, user_id, idx, body)
        elif sub == "search" and len(args) >= 2:
            query = " ".join(args[1:])
            await self._email_search(msg, user_id, query)
        elif sub == "delete" and len(args) >= 2:
            await self._email_delete(msg, user_id, args[1])
        elif sub == "status":
            await self._email_status(msg, user_id)
        elif sub == "accounts":
            await self._email_accounts(msg, user_id)
        else:
            await self._email_help(msg)

    async def _email_help(self, msg):
        await msg.reply_text(
            "📧 <b>Email Commands</b>\n\n"
            "<code>/email setup</code>              — Configure an email account\n"
            "<code>/email inbox [n]</code>          — Show last n emails (default 10)\n"
            "<code>/email unread</code>             — Show unread emails only\n"
            "<code>/email read &lt;id&gt;</code>           — Read full email\n"
            "<code>/email send &lt;to&gt; &lt;subj&gt; &lt;body&gt;</code> — Send email\n"
            "<code>/email reply &lt;id&gt; &lt;body&gt;</code>   — Reply to email\n"
            "<code>/email search &lt;query&gt;</code>      — Search inbox\n"
            "<code>/email delete &lt;id&gt;</code>         — Delete email\n"
            "<code>/email status</code>             — Connection status\n"
            "<code>/email accounts</code>           — List configured accounts\n\n"
            "<i>First time? Run <code>/email setup</code></i>",
            parse_mode="HTML",
        )

    async def _email_setup_start(self, msg, user_id: int):
        """Start interactive email setup wizard."""
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📧 Gmail", callback_data="email_setup:gmail")],
            [InlineKeyboardButton("📧 Outlook / Microsoft 365", callback_data="email_setup:outlook")],
            [InlineKeyboardButton("📧 Yahoo Mail", callback_data="email_setup:yahoo")],
            [InlineKeyboardButton("📧 iCloud Mail", callback_data="email_setup:icloud")],
            [InlineKeyboardButton("⚙️ Custom IMAP/SMTP", callback_data="email_setup:custom")],
            [InlineKeyboardButton("❌ Cancel", callback_data="email_setup:cancel")],
        ])
        await msg.reply_text(
            "📧 <b>Email Setup Wizard</b>\n\n"
            "Choose your email provider:",
            parse_mode="HTML",
            reply_markup=keyboard,
        )

    async def _email_inbox(self, msg, user_id: int, limit: int = 10, unread_only: bool = False):
        account = _get_default_account()
        if not account:
            await msg.reply_text(
                "📧 No email account configured.\nRun <code>/email setup</code> first.",
                parse_mode="HTML",
            )
            return
        label = "unread " if unread_only else ""
        thinking = await msg.reply_text(
            f"📬 <i>Fetching {label}emails from {_esc(account['email'])}…</i>",
            parse_mode="HTML",
        )
        try:
            loop = asyncio.get_event_loop()
            emails = await loop.run_in_executor(
                None, _imap_fetch_emails, account, "INBOX", limit, unread_only
            )
        except Exception as e:
            await thinking.edit_text(
                f"❌ Failed to fetch emails: <code>{_esc(str(e))}</code>\n\n"
                f"<i>Check your credentials with <code>/email status</code></i>",
                parse_mode="HTML",
            )
            return

        _email_sessions[user_id] = emails

        if not emails:
            await thinking.edit_text(
                f"📭 No {label}emails found in inbox.",
                parse_mode="HTML",
            )
            return

        lines = [f"📬 <b>{'Unread e' if unread_only else 'E'}mails — {_esc(account['email'])}</b>\n"]
        for e in emails:
            from_short = e["from"][:30] + ("…" if len(e["from"]) > 30 else "")
            subject_short = e["subject"][:40] + ("…" if len(e["subject"]) > 40 else "")
            lines.append(
                f"<b>[{e['idx']}]</b> {_esc(subject_short)}\n"
                f"       From: {_esc(from_short)}"
            )

        lines.append(f"\n<i>Use <code>/email read &lt;id&gt;</code> to read full email.</i>")
        await thinking.edit_text("\n".join(lines), parse_mode="HTML")

    async def _email_read(self, msg, user_id: int, idx_str: str):
        session = _email_sessions.get(user_id, [])
        # Find by index
        email_meta = None
        try:
            idx = int(idx_str)
            for e in session:
                if e["idx"] == idx:
                    email_meta = e
                    break
        except ValueError:
            pass

        if not email_meta:
            await msg.reply_text(
                f"❓ Email #{_esc(idx_str)} not found. Run <code>/email inbox</code> first.",
                parse_mode="HTML",
            )
            return

        account = _get_default_account()
        thinking = await msg.reply_text("📖 <i>Loading email…</i>", parse_mode="HTML")
        try:
            loop = asyncio.get_event_loop()
            full = await loop.run_in_executor(
                None, _imap_fetch_full, account, email_meta["uid"]
            )
        except Exception as e:
            await thinking.edit_text(f"❌ Failed: <code>{_esc(str(e))}</code>", parse_mode="HTML")
            return

        if not full:
            await thinking.edit_text("❌ Email not found.", parse_mode="HTML")
            return

        body_preview = full["body"][:1500] + ("…" if len(full["body"]) > 1500 else "")
        text = (
            f"📧 <b>Email #{idx_str}</b>\n\n"
            f"<b>From:</b> {_esc(full['from'])}\n"
            f"<b>To:</b> {_esc(full['to'])}\n"
            f"<b>Subject:</b> {_esc(full['subject'])}\n"
            f"<b>Date:</b> {_esc(full['date'])}\n\n"
            f"<b>Body:</b>\n<pre>{_esc(body_preview)}</pre>"
        )
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("↩️ Reply", callback_data=f"email_reply:{email_meta['uid']}"),
            InlineKeyboardButton("🗑️ Delete", callback_data=f"email_delete:{email_meta['uid']}"),
        ]])
        await thinking.edit_text(text, parse_mode="HTML", reply_markup=keyboard)

    async def _email_send(self, msg, user_id: int, to: str, subject: str, body: str):
        account = _get_default_account()
        if not account:
            await msg.reply_text("📧 No email configured. Run <code>/email setup</code>", parse_mode="HTML")
            return
        thinking = await msg.reply_text(
            f"📤 <i>Sending email to {_esc(to)}…</i>", parse_mode="HTML"
        )
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, _smtp_send, account, to, subject, body)
            await thinking.edit_text(
                f"✅ <b>Email sent!</b>\n\n"
                f"<b>To:</b> {_esc(to)}\n"
                f"<b>Subject:</b> {_esc(subject)}\n"
                f"<b>From:</b> {_esc(account['email'])}",
                parse_mode="HTML",
            )
        except Exception as e:
            await thinking.edit_text(
                f"❌ Failed to send: <code>{_esc(str(e))}</code>",
                parse_mode="HTML",
            )

    async def _email_reply(self, msg, user_id: int, idx_str: str, body: str):
        session = _email_sessions.get(user_id, [])
        email_meta = None
        try:
            idx = int(idx_str)
            for e in session:
                if e["idx"] == idx:
                    email_meta = e
                    break
        except ValueError:
            pass
        if not email_meta:
            await msg.reply_text(
                f"❓ Email #{idx_str} not in current session. Run <code>/email inbox</code> first.",
                parse_mode="HTML",
            )
            return
        # Extract reply-to address
        from_addr = email_meta["from"]
        match = re.search(r"<(.+?)>", from_addr)
        to_addr = match.group(1) if match else from_addr
        subject = "Re: " + email_meta["subject"]
        await self._email_send(msg, user_id, to_addr, subject, body)

    async def _email_search(self, msg, user_id: int, query: str):
        account = _get_default_account()
        if not account:
            await msg.reply_text("📧 No email configured. Run <code>/email setup</code>", parse_mode="HTML")
            return
        thinking = await msg.reply_text(f"🔍 <i>Searching for '{_esc(query)}'…</i>", parse_mode="HTML")
        try:
            loop = asyncio.get_event_loop()
            emails = await loop.run_in_executor(None, _imap_search, account, query)
        except Exception as e:
            await thinking.edit_text(f"❌ Search failed: <code>{_esc(str(e))}</code>", parse_mode="HTML")
            return
        _email_sessions[user_id] = emails
        if not emails:
            await thinking.edit_text(f"🔍 No results for: <b>{_esc(query)}</b>", parse_mode="HTML")
            return
        lines = [f"🔍 <b>Search results for '{_esc(query)}'</b>\n"]
        for e in emails:
            subject_short = e["subject"][:40] + ("…" if len(e["subject"]) > 40 else "")
            from_short = e["from"][:25] + ("…" if len(e["from"]) > 25 else "")
            lines.append(f"<b>[{e['idx']}]</b> {_esc(subject_short)} — {_esc(from_short)}")
        await thinking.edit_text("\n".join(lines), parse_mode="HTML")

    async def _email_delete(self, msg, user_id: int, idx_str: str):
        session = _email_sessions.get(user_id, [])
        email_meta = None
        try:
            idx = int(idx_str)
            for e in session:
                if e["idx"] == idx:
                    email_meta = e
                    break
        except ValueError:
            pass
        if not email_meta:
            await msg.reply_text(
                f"❓ Email #{idx_str} not found. Run <code>/email inbox</code> first.",
                parse_mode="HTML",
            )
            return
        account = _get_default_account()
        thinking = await msg.reply_text("🗑️ <i>Deleting email…</i>", parse_mode="HTML")
        try:
            loop = asyncio.get_event_loop()
            ok = await loop.run_in_executor(None, _imap_delete, account, email_meta["uid"])
            if ok:
                await thinking.edit_text(
                    f"✅ Deleted: <b>{_esc(email_meta['subject'])}</b>",
                    parse_mode="HTML",
                )
            else:
                await thinking.edit_text("❌ Delete failed.", parse_mode="HTML")
        except Exception as e:
            await thinking.edit_text(f"❌ Error: <code>{_esc(str(e))}</code>", parse_mode="HTML")

    async def _email_status(self, msg, user_id: int):
        account = _get_default_account()
        if not account:
            await msg.reply_text(
                "📧 <b>Email Status</b>\n\n❌ No account configured.\n\nRun <code>/email setup</code>",
                parse_mode="HTML",
            )
            return
        thinking = await msg.reply_text("🔌 <i>Testing connection…</i>", parse_mode="HTML")
        try:
            loop = asyncio.get_event_loop()
            imap = await loop.run_in_executor(None, _imap_connect, account)
            imap.logout()
            await thinking.edit_text(
                f"📧 <b>Email Status</b>\n\n"
                f"✅ Connected to <b>{_esc(account['email'])}</b>\n"
                f"🔌 IMAP: {_esc(account['imap_host'])}:{account['imap_port']}\n"
                f"📤 SMTP: {_esc(account['smtp_host'])}:{account['smtp_port']}",
                parse_mode="HTML",
            )
        except Exception as e:
            await thinking.edit_text(
                f"📧 <b>Email Status</b>\n\n"
                f"❌ Connection failed for <b>{_esc(account['email'])}</b>\n"
                f"<code>{_esc(str(e))}</code>\n\n"
                f"<i>Run <code>/email setup</code> to reconfigure.</i>",
                parse_mode="HTML",
            )

    async def _email_accounts(self, msg, user_id: int):
        cfg = _load_email_config()
        accounts = cfg.get("accounts", [])
        if not accounts:
            await msg.reply_text(
                "📧 No email accounts configured.\nRun <code>/email setup</code>",
                parse_mode="HTML",
            )
            return
        default = cfg.get("default", "")
        lines = ["📧 <b>Configured Email Accounts</b>\n"]
        for acc in accounts:
            marker = "⭐ " if acc["name"] == default else "   "
            lines.append(f"{marker}<code>{_esc(acc['email'])}</code> ({_esc(acc['name'])})")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    async def handle_email_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle email inline keyboard callbacks."""
        query = update.callback_query
        await query.answer()
        data = query.data or ""
        user_id = update.effective_user.id

        if data.startswith("email_setup:"):
            provider_key = data[12:]
            if provider_key == "cancel":
                await query.edit_message_text("❌ Email setup cancelled.")
                return
            await self._email_setup_provider(query, user_id, provider_key)
            return

        if data.startswith("email_reply:"):
            uid = data[12:]
            _setup_wizards[user_id] = {"mode": "reply", "uid": uid}
            await query.edit_message_text(
                f"↩️ <b>Reply to email</b>\n\n"
                f"Send your reply text as your next message.\n"
                f"(Or /cancel to abort)",
                parse_mode="HTML",
            )
            return

        if data.startswith("email_delete:"):
            uid = data[13:]
            account = _get_default_account()
            try:
                loop = asyncio.get_event_loop()
                ok = await loop.run_in_executor(None, _imap_delete, account, uid)
                if ok:
                    await query.edit_message_text("✅ Email deleted.")
                else:
                    await query.edit_message_text("❌ Delete failed.")
            except Exception as e:
                await query.edit_message_text(f"❌ Error: {_esc(str(e))}", parse_mode="HTML")
            return

        if data.startswith("email_save_creds:"):
            await self._email_save_from_wizard(query, user_id)
            return

    async def _email_setup_provider(self, query, user_id: int, provider_key: str):
        """Show credential input instructions for chosen provider."""
        if provider_key == "custom":
            _setup_wizards[user_id] = {"step": "custom_imap_host"}
            await query.edit_message_text(
                "⚙️ <b>Custom IMAP/SMTP Setup</b>\n\n"
                "Send your config in this format:\n\n"
                "<pre>/email_cfg email@domain.com password imap.domain.com 993 smtp.domain.com 587</pre>",
                parse_mode="HTML",
            )
            return
        prov = KNOWN_PROVIDERS.get(provider_key, {})
        if not prov:
            await query.edit_message_text("❌ Unknown provider.")
            return
        _setup_wizards[user_id] = {
            "step": "waiting_creds",
            "provider": provider_key,
            **prov,
        }
        await query.edit_message_text(
            f"📧 <b>{_esc(prov['label'])} Setup</b>\n\n"
            f"<b>ℹ️ Note:</b> {_esc(prov['note'])}\n\n"
            f"Send your credentials in this format:\n"
            f"<pre>your@email.com yourpassword</pre>\n\n"
            f"<i>Your password is stored locally on your laptop only, "
            f"encrypted with base64 and never sent anywhere except your email provider.</i>",
            parse_mode="HTML",
        )

    async def handle_email_credentials_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
        """
        Intercept a text message if a setup wizard is active for the user.
        Returns True if consumed, False otherwise.
        """
        user_id = update.effective_user.id
        wizard = _setup_wizards.get(user_id)
        if not wizard or wizard.get("step") != "waiting_creds":
            return False

        msg = update.effective_message
        text = (msg.text or "").strip()
        parts = text.split(None, 1)
        if len(parts) < 2:
            await msg.reply_text(
                "❓ Expected: <code>email@domain.com password</code>",
                parse_mode="HTML",
            )
            return True

        email_addr, password = parts[0], parts[1]
        password_b64 = base64.b64encode(password.encode()).decode()

        # Build account record
        account = {
            "name": wizard.get("provider", "custom"),
            "email": email_addr,
            "password_b64": password_b64,
            "imap_host": wizard.get("imap_host", ""),
            "imap_port": int(wizard.get("imap_port", 993)),
            "smtp_host": wizard.get("smtp_host", ""),
            "smtp_port": int(wizard.get("smtp_port", 587)),
        }

        # Try connecting before saving
        thinking = await msg.reply_text("🔌 <i>Testing connection…</i>", parse_mode="HTML")
        try:
            loop = asyncio.get_event_loop()
            imap = await loop.run_in_executor(None, _imap_connect, account)
            imap.logout()
        except Exception as e:
            await thinking.edit_text(
                f"❌ <b>Connection failed</b>\n\n<code>{_esc(str(e))}</code>\n\n"
                f"<i>Check your email address and password (use App Password for Gmail).\n"
                f"Run <code>/email setup</code> to try again.</i>",
                parse_mode="HTML",
            )
            del _setup_wizards[user_id]
            return True

        # Save to config
        cfg = _load_email_config()
        accounts = cfg.get("accounts", [])
        # Replace if same email
        accounts = [a for a in accounts if a["email"] != email_addr]
        accounts.append(account)
        cfg["accounts"] = accounts
        if "default" not in cfg:
            cfg["default"] = account["name"]
        _save_email_config(cfg)
        del _setup_wizards[user_id]

        await thinking.edit_text(
            f"✅ <b>Email account connected!</b>\n\n"
            f"📧 {_esc(email_addr)}\n"
            f"🔌 IMAP: {_esc(account['imap_host'])}\n"
            f"📤 SMTP: {_esc(account['smtp_host'])}\n\n"
            f"<i>Use <code>/email inbox</code> to view emails.</i>",
            parse_mode="HTML",
        )
        return True

    async def _email_save_from_wizard(self, query, user_id: int):
        pass  # placeholder for future OAuth flow
