"""
HOW TO INTEGRATE document_writer.py INTO YOUR SALIM BOT
========================================================

STEP 1 — Install required library:
    pip install openpyxl

STEP 2 — Edit salim/bot.py

    A) Add import at top (with other handler imports):
    
        from salim.handlers.document_writer import DocumentHandlers

    B) Add DocumentHandlers to the class definition:
    
        class SalimBot(
            SystemHandlers, ShellHandlers, FileHandlers,
            ScreenHandlers, PowerHandlers,
            AIHandler,
            DocumentHandlers,     # ← ADD THIS
        ):

    C) Add the /doc command inside _register_handlers():
        Find the line with "# ── Power" section and add before it:
        
        # ── Document Writer ───────────────────────────────────────────────────
        app.add_handler(CommandHandler("doc", self.cmd_doc))


STEP 3 — Edit salim/handlers/ai_handler.py

    Find the method that handles plain text messages (usually `handle_message`
    or `cmd_ai` or similar). At the TOP of that method, add:

        # Check if user wants to create a document
        if hasattr(self, 'handle_natural_doc'):
            handled = await self.handle_natural_doc(update, ctx, user_text)
            if handled:
                return

    This lets users say things like:
        "write me a resume for Ahmed"
        "create an invoice for Acme Corp"
    ...and Salim will create the document automatically without needing /doc.


STEP 4 — That's it! Test with:
    /doc resume for John Smith, software engineer with 5 years experience
    /doc invoice for client ABC Corp, web design services
    /doc resignation letter effective March 15
    /doc monthly budget tracker for March 2026
    /doc meeting minutes, team sync about Q2 goals


SUPPORTED DOCUMENT TYPES
=========================

Word (.docx):
  resume / CV
  cover letter
  job application
  business letter
  resignation letter
  internship application
  NOC (No Objection Certificate)
  memo / memorandum
  meeting minutes
  business report

Excel (.xlsx):
  invoice
  budget tracker
  expense report
  project plan / gantt
  attendance sheet
  salary sheet / payroll
  inventory list


FORMATTING STANDARDS USED
===========================
  ✓ Font: Calibri (letters/reports) | Times New Roman (formal/legal)
  ✓ Body size: 11pt (22 half-points in docx)
  ✓ Margins: 1 inch (1440 DXA) all sides
  ✓ Page size: US Letter (8.5 x 11 inches)
  ✓ Headings: Bold, color-coded, with underline rule
  ✓ Paragraph spacing: 6pt after body, 12pt after headings
  ✓ Alignment: Justified for body text in formal documents
  ✓ Excel: Color-coded headers, currency formatting, live formulas
"""
