"""Tests for daemon scheduler."""

import asyncio
import json
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock

import pytest

from tsugite.daemon.scheduler import RunResult, ScheduleEntry, Scheduler


@pytest.fixture
def schedules_path(tmp_path):
    return tmp_path / "schedules.json"


@pytest.fixture
def run_callback():
    return AsyncMock(return_value=RunResult(output="done"))


@pytest.fixture
def scheduler(schedules_path, run_callback):
    return Scheduler(schedules_path, run_callback)


class TestScheduleEntry:
    def test_cron_entry(self):
        entry = ScheduleEntry(id="test", agent="bot", prompt="hello", schedule_type="cron", cron_expr="0 9 * * *")
        assert entry.schedule_type == "cron"
        assert entry.enabled is True
        assert entry.created_at  # auto-set

    def test_once_entry(self):
        entry = ScheduleEntry(
            id="test", agent="bot", prompt="hello", schedule_type="once", run_at="2099-01-01T00:00:00Z"
        )
        assert entry.schedule_type == "once"

    def test_invalid_type(self):
        with pytest.raises(ValueError, match="schedule_type must be"):
            ScheduleEntry(id="test", agent="bot", prompt="hello", schedule_type="bad")

    def test_cron_requires_expr(self):
        with pytest.raises(ValueError, match="cron_expr required"):
            ScheduleEntry(id="test", agent="bot", prompt="hello", schedule_type="cron")

    def test_once_requires_run_at(self):
        with pytest.raises(ValueError, match="run_at required"):
            ScheduleEntry(id="test", agent="bot", prompt="hello", schedule_type="once")


class TestSchedulerCRUD:
    def test_add_and_list(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        assert len(scheduler.list()) == 1
        assert scheduler.get("job1").id == "job1"

    def test_add_duplicate_raises(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        with pytest.raises(ValueError, match="already exists"):
            scheduler.add(entry)

    def test_remove(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        scheduler.remove("job1")
        assert len(scheduler.list()) == 0

    def test_remove_not_found(self, scheduler):
        with pytest.raises(ValueError, match="not found"):
            scheduler.remove("nonexistent")

    def test_enable_disable(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        scheduler.disable("job1")
        assert not scheduler.get("job1").enabled
        scheduler.enable("job1")
        assert scheduler.get("job1").enabled

    def test_invalid_cron_rejected(self, scheduler):
        entry = ScheduleEntry(id="bad", agent="bot", prompt="hi", schedule_type="cron", cron_expr="not-a-cron")
        with pytest.raises(ValueError, match="Invalid cron"):
            scheduler.add(entry)


class TestSchedulerPersistence:
    def test_save_and_load(self, schedules_path, run_callback):
        sched1 = Scheduler(schedules_path, run_callback)
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        sched1.add(entry)

        # Load from same file
        sched2 = Scheduler(schedules_path, run_callback)
        sched2._load()
        assert len(sched2.list()) == 1
        assert sched2.get("job1").agent == "bot"

    def test_load_missing_file(self, tmp_path, run_callback):
        sched = Scheduler(tmp_path / "does-not-exist.json", run_callback)
        sched._load()
        assert len(sched.list()) == 0

    def test_load_corrupt_file(self, schedules_path, run_callback):
        schedules_path.write_text("not json at all")
        sched = Scheduler(schedules_path, run_callback)
        sched._load()
        assert len(sched.list()) == 0

    def test_atomic_write(self, schedules_path, run_callback):
        sched = Scheduler(schedules_path, run_callback)
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        sched.add(entry)

        # Verify no .tmp file left behind
        assert not schedules_path.with_suffix(".tmp").exists()
        # Verify JSON is valid
        data = json.loads(schedules_path.read_text())
        assert "job1" in data["schedules"]


class TestNextRunComputation:
    def test_cron_next_run_is_future(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        stored = scheduler.get("job1")
        assert stored.next_run is not None
        next_dt = datetime.fromisoformat(stored.next_run)
        assert next_dt > datetime.now(timezone.utc)

    def test_once_future(self, scheduler):
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="once", run_at=future)
        scheduler.add(entry)
        assert scheduler.get("job1").next_run is not None

    def test_once_past_returns_none(self, scheduler):
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="once", run_at=past)
        scheduler.add(entry)
        assert scheduler.get("job1").next_run is None

    def test_cron_with_timezone(self, scheduler):
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *", timezone="US/Eastern"
        )
        scheduler.add(entry)
        stored = scheduler.get("job1")
        assert stored.next_run is not None


class TestSchedulerExecution:
    @pytest.mark.asyncio
    async def test_fire_schedule_success(self, scheduler, run_callback):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        await scheduler._fire_schedule(scheduler.get("job1"))

        run_callback.assert_awaited_once()
        called_entry = run_callback.call_args[0][0]
        assert called_entry.agent == "bot"
        assert called_entry.prompt == "hi"
        assert called_entry.id == "job1"
        stored = scheduler.get("job1")
        assert stored.last_status == "success"
        assert stored.last_run is not None

    @pytest.mark.asyncio
    async def test_fire_schedule_error(self, scheduler, run_callback):
        run_callback.side_effect = RuntimeError("agent crashed")
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        await scheduler._fire_schedule(scheduler.get("job1"))

        stored = scheduler.get("job1")
        assert stored.last_status == "error"
        assert "agent crashed" in stored.last_error

    @pytest.mark.asyncio
    async def test_once_auto_removed(self, scheduler, run_callback):
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="once", run_at=future)
        scheduler.add(entry)
        await scheduler._fire_schedule(scheduler.get("job1"))

        # One-off schedules are auto-removed after firing
        with pytest.raises(ValueError, match="not found"):
            scheduler.get("job1")

    @pytest.mark.asyncio
    async def test_misfire_grace(self, scheduler):
        entry = ScheduleEntry(
            id="job1",
            agent="bot",
            prompt="hi",
            schedule_type="cron",
            cron_expr="* * * * *",
            misfire_grace_seconds=0,
        )
        scheduler.add(entry)
        # Set next_run far in the past
        scheduler.get("job1").next_run = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        scheduler._save()

        scheduler._fire_due_schedules()
        # Should have been skipped (past grace), next_run advanced
        stored = scheduler.get("job1")
        next_dt = datetime.fromisoformat(stored.next_run)
        assert next_dt > datetime.now(timezone.utc)


class TestSchedulerUpdate:
    def test_update_prompt(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="old", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        scheduler.update("job1", prompt="new prompt")
        assert scheduler.get("job1").prompt == "new prompt"

    def test_update_cron_expr(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        scheduler.update("job1", cron_expr="30 8 * * *")
        assert scheduler.get("job1").cron_expr == "30 8 * * *"

    def test_update_notify_tool(self, scheduler):
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *", notify=["discord"]
        )
        scheduler.add(entry)
        scheduler.update("job1", notify_tool=True)
        assert scheduler.get("job1").notify_tool is True


class TestSchedulerCleanup:
    def test_cleanup_removes_disabled_once(self, scheduler):
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        entry = ScheduleEntry(id="oneshot", agent="bot", prompt="hi", schedule_type="once", run_at=future)
        scheduler.add(entry)
        # Simulate fired: disable + clear next_run
        scheduler.get("oneshot").enabled = False
        scheduler.get("oneshot").next_run = None
        scheduler._save()

        removed = scheduler.cleanup()
        assert removed == ["oneshot"]
        assert len(scheduler.list()) == 0

    def test_cleanup_skips_cron(self, scheduler):
        entry = ScheduleEntry(id="cron1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        scheduler.add(entry)
        scheduler.disable("cron1")

        removed = scheduler.cleanup()
        assert removed == []
        assert len(scheduler.list()) == 1

    def test_cleanup_skips_enabled_once(self, scheduler):
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        entry = ScheduleEntry(id="pending", agent="bot", prompt="hi", schedule_type="once", run_at=future)
        scheduler.add(entry)

        removed = scheduler.cleanup()
        assert removed == []
        assert len(scheduler.list()) == 1

    def test_cleanup_empty(self, scheduler):
        removed = scheduler.cleanup()
        assert removed == []


class TestModelField:
    def test_model_defaults_none(self):
        entry = ScheduleEntry(id="test", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        assert entry.model is None

    def test_model_serialization_roundtrip(self, schedules_path, run_callback):
        sched1 = Scheduler(schedules_path, run_callback)
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *", model="openai:gpt-4o-mini"
        )
        sched1.add(entry)

        sched2 = Scheduler(schedules_path, run_callback)
        sched2._load()
        assert sched2.get("job1").model == "openai:gpt-4o-mini"

    def test_model_none_serialization_roundtrip(self, schedules_path, run_callback):
        sched1 = Scheduler(schedules_path, run_callback)
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        sched1.add(entry)

        sched2 = Scheduler(schedules_path, run_callback)
        sched2._load()
        assert sched2.get("job1").model is None


class TestScriptEntry:
    def test_script_entry_creation(self):
        entry = ScheduleEntry(
            id="test",
            agent="bot",
            prompt="",
            schedule_type="cron",
            cron_expr="0 * * * *",
            execution_type="script",
            command="echo hello",
        )
        assert entry.execution_type == "script"
        assert entry.command == "echo hello"
        assert entry.script_timeout == 60

    def test_script_requires_command(self):
        with pytest.raises(ValueError, match="command required"):
            ScheduleEntry(
                id="test",
                agent="bot",
                prompt="",
                schedule_type="cron",
                cron_expr="0 * * * *",
                execution_type="script",
            )

    def test_invalid_execution_type(self):
        with pytest.raises(ValueError, match="execution_type must be"):
            ScheduleEntry(
                id="test",
                agent="bot",
                prompt="hi",
                schedule_type="cron",
                cron_expr="0 * * * *",
                execution_type="bad",
            )

    def test_agent_defaults(self):
        entry = ScheduleEntry(id="test", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        assert entry.execution_type == "agent"
        assert entry.command is None
        assert entry.script_timeout == 60

    def test_custom_script_timeout(self):
        entry = ScheduleEntry(
            id="test",
            agent="bot",
            prompt="",
            schedule_type="cron",
            cron_expr="0 * * * *",
            execution_type="script",
            command="curl http://example.com",
            script_timeout=120,
        )
        assert entry.script_timeout == 120


class TestScriptDispatch:
    @pytest.mark.asyncio
    async def test_script_uses_script_callback(self, schedules_path):
        run_cb = AsyncMock(return_value="agent result")
        script_cb = AsyncMock(return_value="script result")
        sched = Scheduler(schedules_path, run_cb, script_callback=script_cb)

        entry = ScheduleEntry(
            id="s1",
            agent="bot",
            prompt="",
            schedule_type="cron",
            cron_expr="* * * * *",
            execution_type="script",
            command="echo hi",
        )
        sched.add(entry)
        await sched._fire_schedule(sched.get("s1"))

        script_cb.assert_awaited_once()
        run_cb.assert_not_awaited()
        assert sched.get("s1").last_status == "success"

    @pytest.mark.asyncio
    async def test_agent_uses_run_callback(self, schedules_path):
        run_cb = AsyncMock(return_value="agent result")
        script_cb = AsyncMock(return_value="script result")
        sched = Scheduler(schedules_path, run_cb, script_callback=script_cb)

        entry = ScheduleEntry(
            id="a1",
            agent="bot",
            prompt="hi",
            schedule_type="cron",
            cron_expr="* * * * *",
        )
        sched.add(entry)
        await sched._fire_schedule(sched.get("a1"))

        run_cb.assert_awaited_once()
        script_cb.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_missing_script_callback_raises(self, schedules_path):
        run_cb = AsyncMock(return_value="done")
        sched = Scheduler(schedules_path, run_cb)  # no script_callback

        entry = ScheduleEntry(
            id="s1",
            agent="bot",
            prompt="",
            schedule_type="cron",
            cron_expr="* * * * *",
            execution_type="script",
            command="echo hi",
        )
        sched.add(entry)
        await sched._fire_schedule(sched.get("s1"))

        assert sched.get("s1").last_status == "error"
        assert "No script callback" in sched.get("s1").last_error


class TestScriptPersistence:
    def test_script_entry_roundtrip(self, schedules_path, run_callback):
        sched1 = Scheduler(schedules_path, run_callback)
        entry = ScheduleEntry(
            id="script1",
            agent="bot",
            prompt="",
            schedule_type="cron",
            cron_expr="0 * * * *",
            execution_type="script",
            command="df -h /",
            script_timeout=30,
        )
        sched1.add(entry)

        sched2 = Scheduler(schedules_path, run_callback)
        sched2._load()
        loaded = sched2.get("script1")
        assert loaded.execution_type == "script"
        assert loaded.command == "df -h /"
        assert loaded.script_timeout == 30

    def test_backward_compat_agent_entry(self, schedules_path, run_callback):
        """Old entries without execution_type fields load fine with defaults."""
        sched1 = Scheduler(schedules_path, run_callback)
        entry = ScheduleEntry(id="old1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="0 9 * * *")
        sched1.add(entry)

        sched2 = Scheduler(schedules_path, run_callback)
        sched2._load()
        loaded = sched2.get("old1")
        assert loaded.execution_type == "agent"
        assert loaded.command is None


class TestCallHelper:
    """Test the _call helper in schedule tools forwards kwargs."""

    def test_call_forwards_kwargs(self):
        """Regression: _call must forward **kwargs to the target function."""
        from threading import Thread
        from unittest.mock import MagicMock

        from tsugite.tools.schedule import _call, set_scheduler

        loop = asyncio.new_event_loop()
        t = Thread(target=loop.run_forever, daemon=True)
        t.start()

        try:
            captured = {}

            def fake_update(id, **fields):
                captured.update({"id": id, **fields})
                return id

            mock_sched = MagicMock()
            set_scheduler(mock_sched, loop)

            result = _call(fake_update, "job1", prompt="new", cron_expr="0 8 * * *")
            assert result == "job1"
            assert captured == {"id": "job1", "prompt": "new", "cron_expr": "0 8 * * *"}
        finally:
            loop.call_soon_threadsafe(loop.stop)
            t.join(timeout=2)
            loop.close()
            set_scheduler(None)


class TestAutoExpiry:
    @pytest.mark.asyncio
    async def test_expires_at_disables(self, scheduler, run_callback):
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *", expires_at=past
        )
        scheduler.add(entry)
        scheduler._fire_due_schedules()

        stored = scheduler.get("job1")
        assert not stored.enabled
        assert stored.disabled_reason == "expired"
        assert stored.next_run is None
        run_callback.assert_not_called()

    @pytest.mark.asyncio
    async def test_expires_at_future_fires(self, scheduler, run_callback):
        future_expires = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *", expires_at=future_expires
        )
        scheduler.add(entry)
        # Set next_run to the past so it fires
        scheduler.get("job1").next_run = (datetime.now(timezone.utc) - timedelta(seconds=5)).isoformat()
        scheduler._fire_due_schedules()

        # Should have created a task (fires normally)
        assert run_callback.call_count == 0  # callback is async, check task was created
        stored = scheduler.get("job1")
        assert stored.enabled

    @pytest.mark.asyncio
    async def test_max_runs_disables(self, scheduler, run_callback):
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *", max_runs=2
        )
        scheduler.add(entry)

        # Fire twice
        await scheduler._fire_schedule(scheduler.get("job1"))
        assert scheduler.get("job1").run_count == 1
        await scheduler._fire_schedule(scheduler.get("job1"))
        assert scheduler.get("job1").run_count == 2

        # Next fire_due_schedules should disable it
        scheduler.get("job1").next_run = (datetime.now(timezone.utc) - timedelta(seconds=5)).isoformat()
        scheduler._fire_due_schedules()
        stored = scheduler.get("job1")
        assert not stored.enabled
        assert stored.disabled_reason == "max_runs_reached"

    @pytest.mark.asyncio
    async def test_run_count_not_incremented_on_error(self, scheduler, run_callback):
        run_callback.side_effect = RuntimeError("boom")
        entry = ScheduleEntry(
            id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *", max_runs=2
        )
        scheduler.add(entry)
        await scheduler._fire_schedule(scheduler.get("job1"))

        assert scheduler.get("job1").run_count == 0
        assert scheduler.get("job1").last_status == "error"

    @pytest.mark.asyncio
    async def test_enable_clears_disabled_reason(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        scheduler.get("job1").enabled = False
        scheduler.get("job1").disabled_reason = "expired"
        scheduler._save()

        scheduler.enable("job1")
        stored = scheduler.get("job1")
        assert stored.enabled
        assert stored.disabled_reason is None

    def test_expiry_fields_serialization_roundtrip(self, schedules_path, run_callback):
        sched1 = Scheduler(schedules_path, run_callback)
        expires = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        entry = ScheduleEntry(
            id="job1",
            agent="bot",
            prompt="hi",
            schedule_type="cron",
            cron_expr="* * * * *",
            expires_at=expires,
            max_runs=10,
            run_count=3,
            disabled_reason=None,
        )
        sched1.add(entry)

        sched2 = Scheduler(schedules_path, run_callback)
        sched2._load()
        stored = sched2.get("job1")
        assert stored.expires_at == expires
        assert stored.max_runs == 10
        assert stored.run_count == 3


class TestAutoCleanup:
    def test_cleanup_removes_disabled_with_reason(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        scheduler.get("job1").enabled = False
        scheduler.get("job1").disabled_reason = "expired"
        scheduler._save()

        removed = scheduler.cleanup()
        assert "job1" in removed

    def test_cleanup_skips_manually_disabled_cron(self, scheduler):
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        scheduler.disable("job1")

        removed = scheduler.cleanup()
        assert removed == []
        assert len(scheduler.list()) == 1


class TestAgentSkippedError:
    @pytest.mark.asyncio
    async def test_skipped_sets_status(self, scheduler, run_callback):
        from tsugite.agent_runner.models import AgentSkippedError

        run_callback.side_effect = AgentSkippedError("run_if guard")
        entry = ScheduleEntry(id="job1", agent="bot", prompt="hi", schedule_type="cron", cron_expr="* * * * *")
        scheduler.add(entry)
        await scheduler._fire_schedule(scheduler.get("job1"))

        stored = scheduler.get("job1")
        assert stored.last_status == "skipped"
        assert stored.last_error is None
        assert stored.run_count == 0  # skipped runs don't count
