from e80.create_project import create_project
import rich_click as click

from typing import Any, cast
from rich.tree import Tree
from rich import print as rich_print
from rich.prompt import Prompt, IntPrompt
from collections import defaultdict
from pathlib import Path
from e80_sdk import Eighty80

from e80.oauth_handler import start_oauth_flow
from e80.init import init_project
from e80.archive import archive_project
from e80.deploy import deploy_project
from e80.dev import run_dev_server
from e80.lib.constants import E80_VERSION, E80_COMMAND
from e80.lib.sdk import get_sdk_environment
from e80.lib.dependencies import require_uv, require_docker
from e80.lib.prompt import require_tty, tty_or_pipe
from e80.lib.context import E80ContextObject, must_get_ctx_object
from e80.lib.project import ConfigFormat, ProjectFiles
from e80.lib.platform import PlatformClient
from e80.lib.user import get_auth_info, get_project_api_key, set_project_api_key


@click.group()
@click.option(
    "--config",
    type=click.Path(path_type=Path, dir_okay=False, file_okay=True, exists=False),
    help="Path to 8080.yaml or the directory containing it.",
)
@click.option("--e80-api-host", type=str, envvar="E80_API_HOST", hidden=True)
@click.option("--e80-platform-host", type=str, envvar="E80_PLATFORM_HOST", hidden=True)
@click.version_option(E80_VERSION)
@click.option("--verbose", is_flag=True)
@click.pass_context
def cli(
    ctx: click.Context,
    config: Path | None,
    e80_api_host: str | None,
    e80_platform_host: str | None,
    verbose: bool,
) -> None:
    """CLI tool for creating projects and interacting with the 8080 platform."""
    ctx.obj = E80ContextObject(
        api_host=e80_api_host.rstrip("/") if e80_api_host else "https://api.8080.io",
        config_path=config,
        platform_host=e80_platform_host.rstrip("/")
        if e80_platform_host
        else "https://app.8080.io",
        verbose=verbose,
    )


@cli.command()
@click.option(
    "--force",
    is_flag=True,
    help="Force rebuilding the archive, even if no changes are detected.",
)
@click.pass_context
def archive(ctx: click.Context, force: bool) -> None:
    """Just build this project."""
    require_uv()
    require_docker()

    archive_project(must_get_ctx_object(ctx), force)


@cli.command()
@click.option("--bind", default="0.0.0.0", help="Interface to bind the dev server to")
@click.option(
    "--port", default=8080, type=int, help="The port to bind the dev server to"
)
@click.option("--no-reload", is_flag=True, default=False, help="Disable hot reloading")
@click.pass_context
def dev(ctx: click.Context, bind, port, no_reload) -> None:
    """Runs the dev server."""
    run_dev_server(
        must_get_ctx_object(ctx),
        bind,
        port,
        not no_reload,
    )


@cli.command()
@click.option("--artifact-id", default=None, help="Redeploy this artifact ID")
@click.option(
    "--force",
    is_flag=True,
    help="Force rebuilding and deploying a new artifact, even if no changes are detected.",
)
@click.pass_context
def deploy(ctx: click.Context, artifact_id, force: bool) -> None:
    """Builds and deploys this project."""
    require_uv()
    require_docker()

    deploy_project(must_get_ctx_object(ctx), artifact_id, force)


@cli.command()
@click.argument(
    "directory",
    help="Optional. The name of the directory to create and initialize the project in. If not given, it will initialize the project inside the current directory.",
    type=str,
    required=False,
)
@click.option(
    "--git/--no-git",
    is_flag=True,
    help="Initialize a git repository inside the directory",
)
@click.option(
    "--config-format",
    type=click.Choice(ConfigFormat, case_sensitive=False),
    required=False,
    help="The format of the 8080 config file. Must be either 'toml' or 'yaml'",
)
@click.option(
    "--gpu-count",
    type=int,
    required=False,
    help="Number of GPUs. Setting this to a value over 0 will add 'torch' as a dependency.",
)
@click.option("--cpu-mhz", "cpu", type=int, required=False, help="CPU reserved MHz.")
@click.option(
    "--memory-size-mb",
    "memory_size_mb",
    type=int,
    required=False,
    help="Memory size in MB.",
)
@click.option(
    "--org",
    "organization_slug",
    help="Organization slug to create the project under (skips prompt).",
)
@click.option("--project", "project_slug", help="The existing project slug")
@click.pass_context
def init(
    ctx: click.Context,
    directory: str | None,
    config_format: ConfigFormat | None,
    gpu_count: int | None,
    cpu: int | None,
    memory_size_mb: int | None,
    organization_slug: str | None,
    project_slug: str | None,
    git: bool,
) -> None:
    """Initializes an 8080 cloud project."""
    require_uv()
    init_project(
        must_get_ctx_object(ctx),
        install_path=directory,
        gpu_count=gpu_count,
        cpu=cpu,
        memory_size_mb=memory_size_mb,
        organization_slug=organization_slug,
        project_slug=project_slug,
        use_git=git,
        config_format=config_format,
    )


@cli.command()
@click.pass_context
def login(ctx: click.Context) -> None:
    """Login into 8080 and fetch an access token."""
    start_oauth_flow(must_get_ctx_object(ctx))


@cli.command()
@click.option(
    "--json",
    "json_output",
    default=False,
    is_flag=True,
    help="Return the response as JSON",
)
@click.pass_context
def models(ctx: click.Context, json_output: bool) -> None:
    """List all models."""
    env, secrets = get_sdk_environment(must_get_ctx_object(ctx))
    models = Eighty80(env=env, secrets=secrets).completion_sdk().models.list()

    if json_output:
        click.echo(models.model_dump_json())
    else:
        by_provider = defaultdict(list)
        for model in models.data:
            by_provider[model.owned_by].append(model)
        for provider, model_list in by_provider.items():
            tree = Tree(f"[bold]{provider}[/]", guide_style="grey42")
            for model in sorted(model_list, key=lambda x: x.id):
                tree.add(f"{model.id}")
            rich_print(tree)


@cli.command()
@click.argument("text", type=str, required=False)
@click.option("--model", default=None, help="Model to use (optional)")
@click.option("--system", help="System message (optional)")
@click.option(
    "--temperature",
    default=1,
    type=float,
    show_default=True,
    help="Sampling temperature",
)
@click.option(
    "--max-tokens",
    type=int,
    default=None,
    help="Maximum tokens to generate (leave empty for model default)",
)
@click.option("--stream", default=False, is_flag=True, help="Stream the response")
@click.option(
    "--json",
    "json_output",
    default=False,
    is_flag=True,
    help="Return the response as JSON",
)
@click.pass_context
def chat(
    ctx: click.Context,
    text: str | None,
    model: str | None,
    system: str | None,
    temperature: float,
    max_tokens: int,
    stream: bool,
    json_output: bool,
) -> None:
    """Chat with a model."""
    env, secrets = get_sdk_environment(must_get_ctx_object(ctx))
    app = Eighty80(env=env, secrets=secrets).completion_sdk()

    _emph = "bold bright_blue"

    if text is None:
        text = tty_or_pipe()
    if text is None:
        text = Prompt.ask("[white]Message[/white]")

    if model is None:
        models_resp = app.models.list()
        if not models_resp.data:
            raise click.ClickException("No models available to select.")
        rich_print("[white]Available models:[/white]")
        for idx, m in enumerate(models_resp.data):
            rich_print(f"[{_emph}][{idx}][/{_emph}] {m.id} ({m.owned_by})")

        require_tty("--model")
        selection = IntPrompt.ask(
            "[white]Select a model[/white]",
            default=0,
            choices=[str(i) for i in range(0, len(models_resp.data))],
        )

        model = models_resp.data[selection].id

    # OpenAI SDK makes typing this hard, since we can't import the type
    messages: Any = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": text})

    # We want to use custom fields, which won't be part of the type.
    # For the sake of ease, we type the CompletionUsage as Any.
    completion_usage: Any = None

    if stream:
        sresp = app.chat.completions.create(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            stream_options={"include_usage": True},
            stream=True,
        )
        for stream_chunk in sresp:
            if json_output:
                click.echo(stream_chunk.model_dump_json())
            else:
                if stream_chunk.choices:
                    click.echo(stream_chunk.choices[0].delta.content)
                if stream_chunk.usage:
                    completion_usage = stream_chunk.usage

    else:
        resp = app.chat.completions.create(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=False,
        )
        if json_output:
            click.echo(resp.model_dump_json())
        else:
            click.echo(resp.choices[0].message.content)
            completion_usage = resp.usage

    if hasattr(completion_usage, "prefill_tokens"):
        completion_usage = cast(Any, completion_usage)  # Hack for type check.
        usage_values = [
            ("time", completion_usage.total_time, "s"),
            (
                "prefill_tokens",
                completion_usage.prefill_tokens,
                " tokens",
            ),
            ("decode_tokens", completion_usage.decode_tokens, " tokens"),
            ("prefill_rate", completion_usage.prefill_rate, "tps"),
            ("decode_rate", completion_usage.decode_rate, "tps"),
        ]
        rich_print(
            " ".join(f"{n}: [{_emph}]{v}{u}[/{_emph}]" for n, v, u in usage_values)
        )


@cli.group()
def sandbox() -> None:
    """Manage sandboxes for code execution."""
    pass


@sandbox.command("create")
@click.option(
    "--json",
    "json_output",
    default=False,
    is_flag=True,
    help="Return the response as JSON",
)
@click.option(
    "--connect",
    "auto_connect",
    default=False,
    is_flag=True,
    help="Automatically connect to the sandbox after creation",
)
@click.pass_context
def sandbox_create(ctx: click.Context, json_output: bool, auto_connect: bool) -> None:
    """Create a new sandbox and return its ID."""
    ctx_obj = must_get_ctx_object(ctx)
    create_project(ctx_obj)
    project = ProjectFiles(ctx_obj)
    project_config = project.read_project_config()
    auth_info = get_auth_info(ctx_obj)

    if project_config.project_slug is None:
        raise Exception(
            "This should not have happened! We couldn't create your project."
        )

    if auth_info is None:
        raise click.UsageError(
            f"You are not logged in! Please run '{E80_COMMAND} login'."
        )

    pc = PlatformClient(ctx_obj, api_key=auth_info.auth_token)
    resp = pc.create_sandbox(project_config)

    if auto_connect:
        from e80.sandbox_connect import run_connect_with_retry

        click.echo(f"Sandbox created: {resp.id}")
        click.echo("Connecting (waiting up to 30s for sandbox to be ready)...")
        exit_code = run_connect_with_retry(
            ctx_obj.platform_host,
            project_config.organization_slug,
            project_config.project_slug,
            resp.id,
            auth_info.auth_token,
        )
        raise SystemExit(exit_code)
    elif json_output:
        click.echo(resp.model_dump_json())
    else:
        click.echo(f"Sandbox created: {resp.id}")
        click.echo(f"Connect to it with: {E80_COMMAND} sandbox connect {resp.id}")


@sandbox.command("connect")
@click.argument("sandbox_id", type=str)
@click.pass_context
def sandbox_connect(ctx: click.Context, sandbox_id: str) -> None:
    """Connect to a sandbox with an SSH-like terminal session."""
    from e80.sandbox_connect import run_connect

    ctx_obj = must_get_ctx_object(ctx)
    project = ProjectFiles(ctx_obj)
    project_config = project.read_project_config()
    auth_info = get_auth_info(ctx_obj)

    if project_config.project_slug is None:
        raise click.UsageError(
            f"Sandbox '{sandbox_id}' was not found! Please create a sandbox first."
        )

    if auth_info is None:
        raise click.UsageError(
            f"You are not logged in! Please run '{E80_COMMAND} login'."
        )

    exit_code = run_connect(
        ctx_obj.platform_host,
        project_config.organization_slug,
        project_config.project_slug,
        sandbox_id,
        auth_info.auth_token,
    )
    raise SystemExit(exit_code)


@sandbox.command("list")
@click.option(
    "--json",
    "json_output",
    default=False,
    is_flag=True,
    help="Return the response as JSON",
)
@click.pass_context
def sandbox_list(ctx: click.Context, json_output: bool) -> None:
    """List all sandboxes for the current project."""
    ctx_obj = must_get_ctx_object(ctx)
    auth_info = get_auth_info(ctx_obj)

    if auth_info is None:
        raise click.UsageError(
            f"You are not logged in! Please run '{E80_COMMAND} login'."
        )

    project = ProjectFiles(ctx_obj)
    project_config = project.read_project_config()
    if project_config.project_slug is None:
        click.echo("No sandboxes found.")
        return

    pc = PlatformClient(ctx_obj, api_key=auth_info.auth_token)
    resp = pc.list_sandboxes(project_config)

    if json_output:
        click.echo(resp.model_dump_json())
    else:
        if not resp.sandboxes:
            click.echo("No sandboxes found.")
        else:
            tree = Tree("Sandboxes:")
            for sb in resp.sandboxes:
                if sb.terminated:
                    status = "[grey50]ended[/grey50]"
                else:
                    status = "[green]running[/green]"
                tree.add(f"{status}\t{sb.id} [grey50](started {sb.created})[/grey50]")
            rich_print(tree)


@sandbox.command("stop")
@click.argument("sandbox_id", type=str)
@click.pass_context
def sandbox_stop(ctx: click.Context, sandbox_id: str) -> None:
    """Stop a running sandbox."""
    ctx_obj = must_get_ctx_object(ctx)
    config = read_project_config(ctx_obj)
    auth_info = get_auth_info(ctx_obj)

    if auth_info is None:
        raise click.UsageError(
            f"You are not logged in! Please run '{E80_COMMAND} login'."
        )

    pc = PlatformClient(ctx_obj, api_key=auth_info.auth_token)
    pc.stop_sandbox(config, sandbox_id)
    click.echo(f"Sandbox {sandbox_id} stopped.")




@cli.command()
@click.argument("path", type=str)
@click.argument("body", type=str, required=False)
@click.option("--host", default=None, help="Override the default hostname")
@click.option(
    "--method",
    "-X",
    default="POST",
    type=click.Choice(["GET", "POST", "PUT", "DELETE", "PATCH"], case_sensitive=False),
    help="HTTP method to use",
)
@click.pass_context
def call(
    ctx: click.Context, path: str, body: str | None, host: str | None, method: str
) -> None:
    """Call your deployed project's API endpoint.

    Example: 8080 call translate '{"text": "hello"}'
    """
    import json
    import requests

    ctx_obj = must_get_ctx_object(ctx)
    config = read_project_config(ctx_obj)

    # Get the stored project API key
    api_key = get_project_api_key(config.project_slug)
    if api_key is None:
        raise click.UsageError(
            f"No API key set for project '{config.project_slug}'. "
            f"Run '{E80_COMMAND} apikey set' to set one."
        )

    # Build the URL
    if host:
        base_url = host if host.startswith("http") else f"https://{host}"
    else:
        base_url = f"https://{config.project_slug}.hosted.8080.io"

    url = f"{base_url}/{path.lstrip('/')}"

    # Parse body if provided
    json_body = None
    if body:
        # If body starts with @, read from file
        if body.startswith("@"):
            file_path = Path(body[1:])
            try:
                body_content = file_path.read_text()
            except FileNotFoundError:
                raise click.UsageError(f"File not found: {file_path}")
            except IOError as e:
                raise click.UsageError(f"Error reading file: {e}")
        else:
            body_content = body

        try:
            json_body = json.loads(body_content)
        except json.JSONDecodeError as e:
            print(body_content)
            raise click.UsageError(f"Invalid JSON body: {e}")

    # Build headers with project API key
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
    }

    # Make the request
    try:
        resp = requests.request(method.upper(), url, json=json_body, headers=headers)

        # Try to pretty-print JSON response
        try:
            response_json = resp.json()
            click.echo(json.dumps(response_json, indent=2))
        except (json.JSONDecodeError, requests.exceptions.JSONDecodeError):
            click.echo(resp.text)

        if not resp.ok:
            raise SystemExit(1)
    except requests.exceptions.RequestException as e:
        raise click.ClickException(f"Request failed: {e}")


@cli.group()
def apikey() -> None:
    """Manage API keys for projects."""
    pass


@apikey.command("set")
@click.argument("key", type=str)
@click.pass_context
def apikey_set(ctx: click.Context, key: str) -> None:
    """Set the API key for the current project."""
    ctx_obj = must_get_ctx_object(ctx)
    config = read_project_config(ctx_obj)

    if config.project_slug is None:
        raise click.UsageError(
            "Project has not been deployed yet. Deploy your project first to get a project slug."
        )

    set_project_api_key(config.project_slug, key)
    click.echo(f"API key set for project '{config.project_slug}'")


@apikey.command("show")
@click.pass_context
def apikey_show(ctx: click.Context) -> None:
    """Show the API key for the current project."""
    ctx_obj = must_get_ctx_object(ctx)
    config = read_project_config(ctx_obj)

    if config.project_slug is None:
        raise click.UsageError(
            "Project has not been deployed yet. Deploy your project first to get a project slug."
        )

    api_key = get_project_api_key(config.project_slug)
    if api_key is None:
        click.echo(f"No API key set for project '{config.project_slug}'")
    else:
        # Show truncated key for security
        preview = api_key[:12] + "..." if len(api_key) > 12 else api_key
        click.echo(f"API key for '{config.project_slug}': {preview}")


@cli.command()
@click.pass_context
def info(ctx: click.Context) -> None:
    """Display current user and project information."""
    from rich.panel import Panel
    from rich.table import Table
    from rich.console import Console

    console = Console()
    ctx_obj = must_get_ctx_object(ctx)

    # Auth info section
    auth_info = get_auth_info(ctx_obj)
    auth_table = Table(show_header=False, box=None, padding=(0, 2))
    auth_table.add_column("Key", style="bold")
    auth_table.add_column("Value")

    auth_table.add_row("Platform", ctx_obj.platform_host)
    auth_table.add_row("API Host", ctx_obj.api_host)
    if auth_info:
        # Show truncated token for security
        token_preview = auth_info.auth_token.split("_")[0]
        auth_table.add_row("Status", "[green]Logged in[/green]")
        auth_table.add_row("Token", f"[dim]{token_preview}[/dim]")
    else:
        auth_table.add_row("Status", "[red]Not logged in[/red]")

    console.print(Panel(auth_table, title="[bold]Auth[/bold]", border_style="blue"))

    # Project info section
    try:
        config = read_project_config(ctx_obj)
        project_table = Table(show_header=False, box=None, padding=(0, 2))
        project_table.add_column("Key", style="bold")
        project_table.add_column("Value")

        project_table.add_row("Name", config.project)
        project_table.add_row("Slug", config.project_slug or "[dim]not deployed[/dim]")
        project_table.add_row("Organization", config.organization_slug)
        project_table.add_row("Entrypoint", config.entrypoint)
        project_table.add_row("CPU", f"{config.cpu_mhz} MHz")
        project_table.add_row("Memory", f"{config.memory_size_mb} MB")
        if config.gpu_count > 0:
            project_table.add_row("GPUs", str(config.gpu_count))
        if config.project_slug:
            project_table.add_row("URL", f"[cyan]https://{config.project_slug}.hosted.8080.io[/cyan]")

        console.print(Panel(project_table, title="[bold]Project[/bold]", border_style="green"))
    except click.ClickException:
        console.print(Panel("[dim]No project found in current directory[/dim]", title="[bold]Project[/bold]", border_style="yellow"))


def main():
    """Entry point for the CLI tool."""
    cli()
