import shutil
import click
import zipfile
import subprocess
import requirements
import os
import time
import uuid
from pathlib import Path
from rich.console import Console
from e80.lib.context import E80ContextObject
from e80.lib.project import ProjectFiles, ArtifactMetadata
from e80.lib.constants import E80_HTTP_CUDA_PACKAGES

console = Console()


def _is_truthy(value: str | None) -> bool:
    return value is not None and value.strip().lower()[0] in {
        "1",
        "t",  # true
        "y",  # yes
        "o",  # on
    }


def _run_docker_build_detached(
    docker_args: list[str],
    cwd: Path,
    build_logs: Path,
) -> None:
    container_name = f"e80-archive-build-{uuid.uuid4().hex[:8]}"
    run_cmd = [
        "docker",
        "run",
        "-d",
        "--name",
        container_name,
        *docker_args,
    ]
    created = subprocess.run(
        run_cmd,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if created.returncode != 0:
        raise click.ClickException(
            f"Docker build failed to start. Please check stderr: {created.stderr.strip()}"
        )

    try:
        deadline = time.time() + 30 * 60
        while time.time() < deadline:
            inspect = subprocess.run(
                [
                    "docker",
                    "inspect",
                    "--format",
                    "{{.State.Status}} {{.State.ExitCode}}",
                    container_name,
                ],
                cwd=cwd,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            if inspect.returncode != 0:
                break

            parts = inspect.stdout.strip().split()
            if len(parts) >= 2 and parts[0] in {"exited", "dead"}:
                exit_code = int(parts[1])
                logs = subprocess.run(
                    ["docker", "logs", container_name],
                    cwd=cwd,
                    text=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                )
                with open(build_logs, "w") as f:
                    f.write(logs.stdout)
                if exit_code != 0:
                    raise click.ClickException(
                        f"Docker build failed. Please check {build_logs}"
                    )
                return
            time.sleep(1)
        raise click.ClickException(
            f"Docker build timed out. Please check {build_logs}"
        )
    finally:
        subprocess.run(
            ["docker", "rm", "-f", container_name],
            cwd=cwd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


def _build_dependencies(
    ctx_obj: E80ContextObject,
    project_files: ProjectFiles,
    python_version: str,
    output_dir: Path,
) -> None:
    project_config = project_files.read_project_config()
    cuda_base_image = (
        project_config.gpu_count is not None and project_config.gpu_count > 0
    )

    unfiltered_requirements = (
        project_files.get_cache_root() / "unfiltered_requirements.txt"
    )
    if unfiltered_requirements.exists():
        unfiltered_requirements.unlink()
    tmp_constraints = project_files.get_cache_root() / "constraints.txt"
    if tmp_constraints.exists():
        tmp_constraints.unlink()
    filtered_requirements = project_files.get_cache_root() / "requirements.txt"
    if filtered_requirements.exists():
        filtered_requirements.unlink()
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir()

    with console.status("[bold bright_blue]Compiling requirements..."):
        compile_logs = project_files.get_cache_root() / "uv-pip-compile.logs.txt"

        with open(compile_logs, "w") as f:
            result = subprocess.run(
                [
                    "uv",
                    "pip",
                    "compile",
                    "pyproject.toml",
                    "--python-version",
                    python_version,
                    "-o",
                    unfiltered_requirements.relative_to(project_files.get_root()),
                ],
                cwd=project_files.get_root(),
                stdout=f,
                stderr=subprocess.STDOUT,
            )
            if result.returncode != 0:
                raise click.ClickException(
                    f"Compiling requirements failed. Please check {compile_logs}."
                )

        with open(tmp_constraints, "w") as f:
            f.write(E80_HTTP_CUDA_PACKAGES if cuda_base_image else "")

        # Run pip compile again, this time with the constraints.
        # That way, if this one fails, we know for certain it is because of
        # constraints.txt and can return a suitable error message.
        compatibility_logs = (
            project_files.get_cache_root() / "pip-compatibility.logs.txt"
        )
        with open(compatibility_logs, "w") as f:
            result = subprocess.run(
                [
                    "uv",
                    "pip",
                    "compile",
                    "pyproject.toml",
                    "--python-version",
                    python_version,
                    "-c",
                    tmp_constraints.relative_to(project_files.get_root()),
                    "-o",
                    unfiltered_requirements.relative_to(project_files.get_root()),
                ],
                cwd=project_files.get_root(),
                stdout=f,
                stderr=subprocess.STDOUT,
            )
            if result.returncode != 0:
                raise click.ClickException(
                    f"Your package dependencies is incompatible with the 8080 runtime environment. Please see {compatibility_logs} for more info."
                )

        # If we got to this point, we know for a fact the user's packages
        # are compatible with the packages on the base image.
        # We now remove them if they are part of requirements.txt, so as to
        # not shadow the packages on the base image.
        # This should reduce the archive size by a lot, as the CUDA packages
        # are hefty.
        shadow_packages_set: set[str] = set()
        if cuda_base_image:
            for req in requirements.parse(E80_HTTP_CUDA_PACKAGES):
                if req.name:
                    shadow_packages_set.add(req.name)
        with open(filtered_requirements, "w") as fr:
            with open(unfiltered_requirements, "r") as f:
                for line in f:
                    try:
                        reqs = list(requirements.parse(line))
                    except Exception as e:
                        click.echo(
                            f"WARNING: Error parsing requirements: {e}. This could be okay if you have tool.uv.sources set"
                        )
                    if not reqs:
                        continue
                    if reqs[0].name not in shadow_packages_set:
                        fr.write(line)
                    elif ctx_obj.verbose:
                        click.echo(
                            f"WARNING: Not including dependency: {line.strip()}, as it shadows a dependency on the 8080 runtime environment. This should be okay."
                        )
    console.log("Compiled requirements")

    with console.status("[bold bright_blue]Building dependencies in Docker..."):
        base_image = (
            "ghcr.io/astral-sh/uv:python3.13-trixie"
            if cuda_base_image
            else "ghcr.io/astral-sh/uv:python3.13-alpine"
        )
        build_logs = project_files.get_cache_root() / "docker-build.logs.txt"
        shell_command = "; ".join(
            [
                "set -e",
                # --no-deps is required for CUDA, as we will not bundle torch and nvidia packages
                f"uv pip install --target /tmp/output --no-deps --python-version {python_version} -r /builder/requirements.txt",
                # We first install to a temporary directory, then move into the final directory.
                # We MUST run the Docker image as root to take advantage of cache binding.
                # However, if we pip install to the final directory then chown, and the user cancels the pip install,
                # the cache directory will be full of files owned by root because the chown never runs.
                # The fix is to only move into the final directory after the chown.
                f"chown -R {os.getuid()}:{os.getgid()} /tmp/output/*",
                "mv /tmp/output/* /builder/output",
            ]
        )
        with open(build_logs, "w") as f:
            docker_args = [
                "--platform",
                "linux/amd64",
                "-v",
                f"{filtered_requirements.resolve()}:/builder/requirements.txt",
                "-v",
                f"{output_dir.resolve()}:/builder/output",
                "-w",
                "/builder",
                base_image,
                "/bin/sh",
                "-c",
                shell_command,
            ]
            if _is_truthy(os.environ.get("_8080_CLI_DETACH_DOCKER")):
                _run_docker_build_detached(
                    docker_args=docker_args,
                    cwd=project_files.get_root(),
                    build_logs=build_logs,
                )
            else:
                result = subprocess.run(
                    ["docker", "run", "--rm", "-a", "stderr", "-a", "stdout", *docker_args],
                    cwd=project_files.get_root(),
                    stdout=f,
                    stderr=subprocess.STDOUT,
                )
                if result.returncode != 0:
                    raise click.ClickException(
                        f"Docker build failed. Please check {build_logs}"
                    )
    console.log("Built dependencies in Docker")


def archive_project(ctx_obj: E80ContextObject, force_build: bool) -> None:
    project_files = ProjectFiles(ctx_obj)

    pv_process = subprocess.run(
        [
            "uv",
            "run",
            "python",
            "-c",
            "import sys; sv = sys.version_info; print(f'{sv.major}.{sv.minor}')",
        ],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if pv_process.returncode != 0:
        raise click.ClickException(
            f"Failed to determine Python version:\n{pv_process.stderr}"
        )
    python_version = pv_process.stdout.strip()

    if not project_files.get_cache_root().exists():
        project_files.get_cache_root().mkdir()

    artifact_metadata = project_files.read_artifact_metadata()

    python_version_diff = True
    pyproject_checksum_diff = True
    mtime_diff = True
    if artifact_metadata:
        python_version_diff = artifact_metadata.python_version != python_version
        pyproject_checksum_diff = (
            artifact_metadata.dependencies_checksum
            != project_files.read_pyproject_checksum()
        )
        mtime_diff = (
            artifact_metadata.project_files_mtime
            < project_files.read_project_code_mtime()
        )

    if (
        not python_version_diff
        and not pyproject_checksum_diff
        and not mtime_diff
        and not force_build
    ):
        console.print("No changes detected.")
        return

    packages_path = project_files.get_cache_root() / "artifact"

    # Commit to a new artifact by deleting the old metadata.
    # If the archive process gets stopped in the middle, no metadata means
    # it starts from the beginning again.
    project_files.delete_artifact_metadata()

    if python_version_diff or pyproject_checksum_diff or force_build:
        _build_dependencies(ctx_obj, project_files, python_version, packages_path)
    else:
        console.log("No changes to dependencies detected.")

    with console.status("[bold bright_blue]Creating final archive..."):
        archive_path = project_files.get_artifact_path()

        with zipfile.ZipFile(
            archive_path, "w", compression=zipfile.ZIP_DEFLATED
        ) as archive:
            # 1. Archive the fully-linked dependencies and local sources
            # packages_path contains everything installed via the --target commands
            for file_path in packages_path.rglob("*"):
                if file_path.is_file():
                    # We store the file relative to the packages directory
                    # so 'packages/pydantic/main.py' becomes 'pydantic/main.py' in the zip
                    archive_name = "dependencies" / file_path.relative_to(packages_path)
                    archive.write(file_path, arcname=archive_name)

            for source in project_files.read_pyproject_local_sources():
                console.log(f"Packaging local source: {source.path}")
                source_path = Path(source.path)
                for root, _, files in source_path.walk():
                    stripped = root.relative_to(source_path)
                    if root == source_path:
                        continue
                    for file in files:
                        archive.write(root / file, "dependencies" / stripped / file)

            for path in project_files.all_project_code_paths():
                archive_name = "project" / path.relative_to(project_files.get_root())
                archive.write(path, arcname=archive_name)

    project_files.write_artifact_metadata(
        ArtifactMetadata(
            artifact_id=None,
            dependencies_checksum=project_files.read_pyproject_checksum(),
            project_files_mtime=project_files.read_project_code_mtime(),
            python_version=python_version,
        )
    )

    console.log("Created archive")
