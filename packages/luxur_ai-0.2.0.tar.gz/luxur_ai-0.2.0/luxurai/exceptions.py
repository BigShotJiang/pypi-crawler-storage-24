"""
LuxurAI SDK — exceptions.py
All exceptions raised by the SDK.
"""


class LuxurAIError(Exception):
    """Base exception for all LuxurAI errors."""
    def __init__(self, message: str, status_code: int = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(LuxurAIError):
    """Invalid or missing API key.
    Get your key at https://luxurai.in → Dashboard → API Keys
    """
    pass


class InsufficientBalanceError(LuxurAIError):
    """Not enough LuxurCoins (LC) to generate.
    Top up at https://luxurai.in/pages/payment.html
    """
    def __init__(self, required: float = None, available: float = None):
        self.required  = required
        self.available = available
        msg = "Insufficient LC balance."
        if required and available is not None:
            msg = f"Need {required} LC but only have {available} LC. Top up at luxurai.in"
        super().__init__(msg, status_code=402)


class ModelTrainingError(LuxurAIError):
    """brainAI model is still training — generation not available yet."""
    pass


class RateLimitError(LuxurAIError):
    """Too many requests. Slow down."""
    pass


class JobFailedError(LuxurAIError):
    """Generation job failed on the server."""
    pass


class JobTimeoutError(LuxurAIError):
    """Job did not complete within the timeout period."""
    pass
