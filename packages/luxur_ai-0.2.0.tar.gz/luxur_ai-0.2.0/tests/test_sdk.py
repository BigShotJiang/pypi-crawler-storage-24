"""
LuxurAI SDK — tests
Run: pytest tests/
"""

import pytest
from luxurai import LuxurAI
from luxurai.exceptions import AuthenticationError, LuxurAIError
from luxurai.models import JobStatus, Resolution, WalletBalance, GenerationJob


# ── Auth validation ────────────────────────────────────────────────

def test_missing_api_key():
    with pytest.raises(AuthenticationError):
        LuxurAI(api_key="")

def test_invalid_api_key_format():
    with pytest.raises(AuthenticationError):
        LuxurAI(api_key="not_a_valid_key")

def test_valid_key_format():
    # Should not raise — just validates format
    client = LuxurAI(api_key="lxr_v1_test_abc123")
    assert "lxr_v1_" in repr(client)


# ── Resolution enum ────────────────────────────────────────────────

def test_resolutions():
    assert Resolution.HD    == "1024x1024"
    assert Resolution.SD    == "512x512"
    assert Resolution.SQ_2K == "1152x1152"


# ── Models ─────────────────────────────────────────────────────────

def test_wallet_balance():
    b = WalletBalance(lc=45.0, inr=11.25)
    assert b.lc  == 45.0
    assert b.inr == 11.25
    assert "45.0" in repr(b)

def test_generation_job_repr():
    job = GenerationJob(
        id             = "test_id",
        prompt         = "a red dragon",
        status         = JobStatus.QUEUED,
        cost_lc        = 5.0,
        resolution     = "1024x1024",
    )
    assert "queued" in repr(job)
    assert "5.0LC"  in repr(job)


# ── Live tests (need real API key) ─────────────────────────────────
# Run with: pytest tests/ -m live --api-key lxr_v1_xxxx

def pytest_addoption(parser):
    parser.addoption("--api-key", action="store", default=None)

@pytest.fixture
def live_client(request):
    key = request.config.getoption("--api-key")
    if not key:
        pytest.skip("No --api-key provided")
    return LuxurAI(api_key=key)

@pytest.mark.live
def test_live_status(live_client):
    status = live_client.status()
    assert "available" in status
    assert "coming_soon" in status

@pytest.mark.live
def test_live_wallet(live_client):
    balance = live_client.wallet.balance()
    assert balance.lc >= 0
    assert balance.inr >= 0

@pytest.mark.live
def test_live_keys_list(live_client):
    keys = live_client.keys.list()
    assert isinstance(keys, list)
