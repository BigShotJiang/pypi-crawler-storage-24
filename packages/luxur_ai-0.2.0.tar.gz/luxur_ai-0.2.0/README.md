# LuxurAI Python SDK

Official Python client for [LuxurAI](https://luxurai.in) — AI image generation.

## Install

```bash
pip install luxurai
```

## Quick Start

```python
from luxurai import LuxurAI

client = LuxurAI(api_key="lxr_v1_xxxx")

# Generate an image (blocks until done)
image = client.generate("a red dragon flying over mountains")
image.save("dragon.png")
```

Get your API key at [luxurai.in](https://luxurai.in) → Dashboard → API Keys.

---

## Usage

### Generate image

```python
# Basic
image = client.generate("a sunset over the ocean")
image.save("sunset.png")

# With options
image = client.generate(
    "divine krishna playing flute, golden light",
    model      = "brainai-v1",   # only model currently
    resolution = "1152x1152",    # brainAI natural size
    fast       = False,          # fast mode = cheaper
)

# Non-blocking
job = client.generate("anime girl with blue hair", wait=False)
print(f"Queue position: #{job.queue_position}")
print(f"ETA: ~{job.eta_seconds}s")

# ... do other stuff ...

image = job.wait()   # block when you're ready
image.save("output.png")
```

### Resolutions

```python
from luxurai import Resolution

client.generate("a mountain", resolution=Resolution.HD)    # 1024x1024
client.generate("a mountain", resolution=Resolution.SQ_2K) # 1152x1152 — brainAI native
client.generate("a mountain", resolution="1920x1080")      # any WxH works
```

### GeneratedImage

```python
image = client.generate("a cat")

image.save("cat.png")         # save to file
image.save("cat.jpg")         # format from extension
raw  = image.bytes()          # raw bytes
pil  = image.to_pil()         # PIL.Image (needs: pip install Pillow)
image.show()                  # display in Jupyter / IPython
print(image.url)              # permanent S3 URL
```

### Wallet / LC balance

```python
balance = client.wallet.balance()
print(f"{balance.lc} LC  ≈  ₹{balance.inr:.2f}")
# 45.0 LC  ≈  ₹11.25
```

### Job history

```python
jobs = client.jobs.list(limit=10)
for job in jobs:
    print(job.id, job.status, job.cost_lc, "LC")
```

### API key management

```python
# List keys
keys = client.keys.list()
for key in keys:
    print(key.prefix, key.created_at)

# Create new key
new_key = client.keys.create(label="my-app")
print(new_key)   # lxr_v1_xxxx — save this!

# Revoke
client.keys.revoke(key_id="key_id_here")
```

### Check model status

```python
status = client.status()
if status["coming_soon"]:
    print("Model still training — coming soon!")
else:
    print("Generation available!")
```

---

## Models

| Model | Description | Status |
|---|---|---|
| `brainai-v1` | LuxurAI's ~761M JAX/Flax model | Training |

---

## Error handling

```python
from luxurai import (
    LuxurAI,
    AuthenticationError,
    InsufficientBalanceError,
    ModelTrainingError,
    JobFailedError,
    JobTimeoutError,
)

client = LuxurAI(api_key="lxr_v1_xxxx")

try:
    image = client.generate("a dragon")
except AuthenticationError:
    print("Invalid API key")
except InsufficientBalanceError as e:
    print(f"Need more LC — top up at luxurai.in")
except ModelTrainingError:
    print("Model still training — coming soon!")
except JobFailedError:
    print("Generation failed — try again")
except JobTimeoutError:
    print("Timed out — try again")
```

---

## Requirements

- Python 3.8+
- No required dependencies — pure stdlib
- Optional: `pip install Pillow` for `.to_pil()` and `.show()`

---

## License

MIT © [LuxurAI](https://luxurai.in)
