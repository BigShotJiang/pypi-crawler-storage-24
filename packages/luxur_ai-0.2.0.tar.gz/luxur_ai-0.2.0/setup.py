from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name = "luxur-ai",
    version                       = "0.1.0",
    author                        = "LuxurAI",
    author_email                  = "achyut@luxurai.in",
    description                   = "Official Python SDK for LuxurAI — AI image generation",
    long_description              = long_description,
    long_description_content_type = "text/markdown",
    url                           = "https://github.com/luxurai/luxurai-python",
    project_urls = {
        "Homepage":      "https://luxurai.in",
        "Documentation": "https://docs.luxurai.in",
        "Bug Tracker":   "https://github.com/luxurai/luxurai-python/issues",
    },
    packages         = find_packages(exclude=["tests*"]),
    python_requires  = ">=3.8",
    install_requires = [],          # zero required dependencies — pure stdlib
    extras_require   = {
        "pillow": ["Pillow>=10.0.0"],    # for image.to_pil() and image.show()
        "dev":    ["pytest", "black", "mypy"],
    },
    classifiers = [
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Multimedia :: Graphics",
    ],
    keywords = "luxurai ai image generation art generative",
)
