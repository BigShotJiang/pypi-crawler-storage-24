# Changelog

All notable changes to kryten-cli will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.7.0] - 2026-03-14

### Removed

- **Legacy Compatibility Paths**: Removed pre-v3 compatibility behaviors from the CLI
  - Legacy `cytube` config conversion is no longer supported
  - Implicit channel auto-discovery was removed; `--channel` is now required for network commands
  - Deprecated `mod` alias was removed in favor of `moderator`

### Fixed

- **Playlist File Path Handling**: Restored the missing `os` import used by file-based playlist commands
  - Fixes `playlist add <file>` and `playlist addnext <file>` under `uv run`

- **Repository Artifact Noise**: Removed tracked local environment and cache artifacts from version control
  - Stops `venv/`, `venv_clean/`, and `__pycache__/` files from polluting the working tree

## [2.6.4] - 2026-03-14

### Added

- **About Command**: Added `kryten about` to display project metadata
  - Project name and current version
  - Credits and project link
  - Thank-you message for the people who make Cytu.be's Channel-Z excellent

## [2.6.3] - 2026-03-14

### Fixed

- **Command Surface Restore**: Restored missing `moderator` and `userstats` command sections
  - Re-added argparse command trees for `moderator`/`mod` and `userstats`
  - Re-added command routing and handlers in `kryten_cli.py`

- **Version Single Source of Truth**: Version now consistently resolves from `pyproject.toml`
  - `setup.py` no longer hardcodes a package version
  - `__init__.py` no longer hardcodes `__version__`

## [2.6.2] - 2026-03-14

### Changed

- **Playlist Batch Pacing**: Restored a 1-second delay between file-based media adds
  - Applies to `playlist add <file>` and `playlist addnext <file>`
  - Helps prevent command bursts from overwhelming downstream services

- **Packaging Metadata Alignment**: Restored the richer 2.6.x package metadata layout in `pyproject.toml`
  - Uses Hatchling build backend
  - Restores `kryten-py>=0.9.8` dependency floor
  - Restores Ruff/Mypy tool configuration and dev dependency group

## [2.6.1] - 2026-03-14

### Changed

- **Playlist File Comments**: `playlist add` and `playlist addnext` now ignore comment lines in input files
  - Lines starting with `#` (including after leading whitespace) are skipped
  - Blank lines continue to be ignored
  - Useful for annotated playlist files under `./playlists`

## [2.6.0] - 2026-02-13

### Added

- **Dropsugar URL Support**: `playlist add` and `playlist addnext` now automatically convert dropsugar.co/io view URLs to manifest URLs
  - Accepts URLs in either view format (`https://www.dropsugar.co/view?m=Q2PRZmXxm`) or manifest format
  - Automatically converts view URLs to CyTube-compatible manifest URLs
  - Works with both dropsugar.co and dropsugar.io domains

- **Batch Playlist Operations**: `playlist add` and `playlist addnext` now accept text files containing multiple URLs
  - Provide a file path with one URL per line
  - `playlist add` adds videos in file order to the end of the playlist
  - `playlist addnext` inserts videos in correct order (automatically reverses list for proper playback sequence)
  - Displays progress for each video added

### Changed

- **Version Management**: Consolidated version definition to pyproject.toml as single source of truth
  - setup.py now reads version dynamically from pyproject.toml
  - Ensures version consistency across the project

## [2.5.0] - 2025-12-15

### Added

- **System Services Command**: `kryten system services` shows registered microservices
  - Lists all services with version, hostname, and heartbeat status
  - Shows health and metrics endpoint URLs for each service
  - Indicates active vs stale services (stale = no heartbeat in 90+ seconds)
  - Supports `--format json` for machine-readable output

### Changed

- **Updated kryten-py dependency** to >=0.9.8 (includes `get_services()` method)

## [2.3.3] - 2025-12-14

### Changed

- **Userstats Display Improvements**: Streamlined `userstats all` command output
  - Removed redundant "Message Leaderboard" section (duplicated by "Top Active Users")
  - Increased "Top Active Users" list from 10 to 20 users (default)
  - Increased "Recent Media" history from 10 to 15 items (default)
  - Kept Kudos and Emote leaderboards at 10 entries each

## [2.3.2] - 2025-12-13

### Changed

- **Build system**: Migrated from setuptools to Poetry for consistent build/publish workflow
- Now uses `poetry build` and `poetry publish` like other kryten packages

## [2.3.1] - 2025-12-13

### Changed

- **Sync release**: Version sync with kryten ecosystem
- **Updated kryten-py dependency** to >=0.9.4 (includes aiohttp as required dependency)

## [2.3.0] - 2025-12-09

### Added

- **Automatic Channel Discovery**: `--channel` is now optional
  - CLI automatically queries running Kryten-Robot instances for available channels
  - If only one channel is found, it's used automatically without specifying `--channel`
  - If multiple channels exist, displays list and prompts user to specify one
  - Falls back gracefully with helpful error messages if discovery fails
- Enhanced user experience with informative messages during auto-discovery

### Changed

- Updated dependency to kryten-py>=0.5.8 (adds `get_channels()` method)
- `--channel` argument is now optional instead of required
- Improved help text and documentation to explain auto-discovery feature

## [2.2.0] - 2025-12-09

### Changed

- **BREAKING**: Configuration file is now optional - all settings can be provided via command-line
- **BREAKING**: `--channel` is now a required command-line argument
- Improved command-line interface with better defaults:
  - `--domain` defaults to `cytu.be` (optional)
  - `--nats` defaults to `nats://localhost:4222` (optional, can be specified multiple times)
  - `--config` is now optional and overrides command-line options when present
- Enhanced usage examples in help text and documentation

### Added

- Command-line options: `--channel` (required), `--domain`, `--nats` (repeatable)
- More flexible deployment: works without config file for quick commands
- Better default values for common use cases

## [2.1.1] - 2025-12-09

### Changed

- Version bump to trigger PyPI release after project name reservation
- All changes from v2.1.0 included

## [2.1.0] - 2025-12-09

### Changed

- **Compatibility**: Lowered minimum Python version requirement from 3.11 to 3.10
  - Updated dependency to kryten-py>=0.5.7 which supports Python 3.10
  - Added Python 3.10 classifier
  - Enhanced PyPI packaging with proper metadata and README

### Added

- **PyPI Publishing**: Added GitHub Actions workflow for automated PyPI releases
- Enhanced setup.py with comprehensive metadata for PyPI
- MANIFEST.in for proper file inclusion in distribution
- MIT License file

## [2.0.0] - 2025-12-08

### Changed
- **BREAKING**: Complete rewrite to use `kryten-py` library instead of direct NATS calls
- Replaced all direct NATS publish operations with high-level KrytenClient methods
- Updated configuration format to support `channels` array (maintains backward compatibility with legacy `cytube.channel` format)
- Improved error handling and user feedback messages
- Added URL parsing for media commands (YouTube, Vimeo, Dailymotion)
- Updated dependency from `nats-py` to `kryten-py>=1.0.0`

### Added
- Media URL parsing for automatic type detection (YouTube, Vimeo, Dailymotion)
- Support for new kryten-py configuration format
- Better success messages showing channel and action details
- `config.example.json` template file

### Improved
- Code is now cleaner and more maintainable
- Type safety through kryten-py's typed API
- Better separation of concerns
- Consistent error handling

### Removed
- Direct NATS client usage
- Manual subject construction
- Manual message encoding/decoding

## [1.0.0] - 2024

### Added
- Initial release with direct NATS implementation
- Chat commands (say, pm)
- Playlist commands (add, addnext, del, move, jump, clear, shuffle, settemp)
- Playback commands (pause, play, seek)
- Moderation commands (kick, ban, voteskip)
