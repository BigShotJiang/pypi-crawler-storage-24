"""Tests for PACT HTTP Server."""

import json

from starlette.testclient import TestClient

from pact.agent import Agent
from pact.crypto import generate_nonce
from pact.handshake import (
    HandshakeRequest,
    HandshakeResponse,
    build_handshake_response,
    verify_handshake_response,
)
from pact.server import PACTServer, MAX_REQUEST_BYTES


def _make_server(name: str = "TestAgent", port: int = 8100) -> PACTServer:
    agent = Agent.create(name=name, service_endpoint=f"http://localhost:{port}")
    return PACTServer(agent)


class TestDIDEndpoint:
    def test_returns_valid_did_document(self):
        server = _make_server()
        client = TestClient(server.app)
        resp = client.get("/pact/did")
        assert resp.status_code == 200
        doc = resp.json()
        assert doc["id"] == server.agent.did
        assert "verificationMethod" in doc
        assert doc["id"].startswith("did:pact:")

    def test_includes_service_endpoint(self):
        server = _make_server()
        client = TestClient(server.app)
        doc = client.get("/pact/did").json()
        services = doc.get("service", [])
        assert len(services) == 1
        assert services[0]["type"] == "PACTEndpoint"


class TestAttestationsEndpoint:
    def test_returns_empty_list_initially(self):
        server = _make_server()
        client = TestClient(server.app)
        resp = client.get("/pact/attestations")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_attestations_after_receiving(self):
        server = _make_server()
        # Create another agent to attest about the server's agent
        other = Agent.create(name="Other")
        att = other.attest(
            server.agent.did,
            interaction_type="task_completion",
            outcome="success",
        )
        server.agent.receive_attestation(att)

        client = TestClient(server.app)
        resp = client.get("/pact/attestations")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["subject"] == server.agent.did


class TestHandshakeEndpoint:
    def test_valid_handshake_request(self):
        server = _make_server()
        client = TestClient(server.app)

        requester = Agent.create(name="Requester")
        challenge = generate_nonce()
        request_data = HandshakeRequest(
            requester_did=requester.did, challenge=challenge
        ).to_dict()

        resp = client.post("/pact/handshake", json=request_data)
        assert resp.status_code == 200

        data = resp.json()
        assert data["type"] == "PACTHandshakeResponse"
        assert data["didDocument"]["id"] == server.agent.did
        assert data["challengeProof"].startswith("z")
        assert len(data["counterChallenge"]) >= 32

    def test_response_verifies_correctly(self):
        """Full verification: send challenge, get response, verify signature."""
        server = _make_server()
        client = TestClient(server.app)

        requester = Agent.create(name="Requester")
        challenge = generate_nonce()
        request_data = HandshakeRequest(
            requester_did=requester.did, challenge=challenge
        ).to_dict()

        resp = client.post("/pact/handshake", json=request_data)
        hs_response = HandshakeResponse.from_dict(resp.json())
        result = verify_handshake_response(hs_response, challenge)

        assert result.verified is True
        assert result.peer_did == server.agent.did
        assert result.trust_score >= 0.0

    def test_malformed_request_returns_400(self):
        server = _make_server()
        client = TestClient(server.app)

        # Missing requesterDID
        resp = client.post("/pact/handshake", json={"challenge": generate_nonce()})
        assert resp.status_code == 400

    def test_missing_challenge_returns_400(self):
        server = _make_server()
        client = TestClient(server.app)

        resp = client.post("/pact/handshake", json={"requesterDID": "did:pact:zFake"})
        assert resp.status_code == 400

    def test_short_challenge_returns_400(self):
        server = _make_server()
        client = TestClient(server.app)

        resp = client.post(
            "/pact/handshake",
            json={"requesterDID": "did:pact:zFake", "challenge": "short"},
        )
        assert resp.status_code == 400

    def test_invalid_json_returns_400(self):
        server = _make_server()
        client = TestClient(server.app)

        resp = client.post(
            "/pact/handshake",
            content=b"not json",
            headers={"content-type": "application/json"},
        )
        assert resp.status_code == 400

    def test_includes_attestations_in_response(self):
        server = _make_server()
        other = Agent.create(name="Attestor")
        att = other.attest(
            server.agent.did,
            interaction_type="task_completion",
            outcome="success",
        )
        server.agent.receive_attestation(att)

        client = TestClient(server.app)
        challenge = generate_nonce()
        request_data = HandshakeRequest(
            requester_did=other.did, challenge=challenge
        ).to_dict()

        resp = client.post("/pact/handshake", json=request_data)
        data = resp.json()
        assert len(data["attestations"]) == 1


class TestHandshakeCompleteEndpoint:
    def _do_initial_handshake(self, server, client, initiator):
        """Perform the initial handshake to register a pending challenge."""
        from pact.handshake import HandshakeRequest
        req = HandshakeRequest(requester_did=initiator.did, challenge=generate_nonce())
        resp = client.post("/pact/handshake", json=req.to_dict())
        assert resp.status_code == 200
        return resp.json()

    def test_valid_counter_proof(self):
        server = _make_server()
        client = TestClient(server.app)

        initiator = Agent.create(name="Initiator")
        # Step 1: Initial handshake to register pending challenge
        hs_data = self._do_initial_handshake(server, client, initiator)

        # Step 2: Build counter-proof using the ACTUAL counter-challenge from server
        counter_proof = build_handshake_response(
            initiator.key_pair,
            initiator.did_document(),
            hs_data["counterChallenge"],
            [],
            [],
        )

        resp = client.post("/pact/handshake/complete", json=counter_proof.to_dict())
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    def test_stores_peer_after_complete(self):
        server = _make_server()
        client = TestClient(server.app)

        initiator = Agent.create(
            name="Initiator", service_endpoint="http://localhost:9999"
        )
        # Step 1: Initial handshake
        hs_data = self._do_initial_handshake(server, client, initiator)

        # Step 2: Complete with correct counter-challenge
        counter_proof = build_handshake_response(
            initiator.key_pair,
            initiator.did_document(),
            hs_data["counterChallenge"],
            [],
            [],
        )

        client.post("/pact/handshake/complete", json=counter_proof.to_dict())
        assert initiator.did in server.peers

    def test_rejects_without_pending_handshake(self):
        server = _make_server()
        client = TestClient(server.app)

        initiator = Agent.create(name="Initiator")
        # Try to complete without doing initial handshake
        counter_proof = build_handshake_response(
            initiator.key_pair,
            initiator.did_document(),
            generate_nonce(),
            [],
            [],
        )

        resp = client.post("/pact/handshake/complete", json=counter_proof.to_dict())
        assert resp.status_code == 400
        assert "No pending handshake" in resp.json()["error"]

    def test_malformed_counter_proof_returns_400(self):
        server = _make_server()
        client = TestClient(server.app)

        resp = client.post("/pact/handshake/complete", json={"garbage": True})
        assert resp.status_code == 400


class TestRequestSizeLimit:
    def test_oversized_content_length_rejected(self):
        server = _make_server()
        client = TestClient(server.app)

        resp = client.post(
            "/pact/handshake",
            content=b"{}",
            headers={
                "content-type": "application/json",
                "content-length": str(MAX_REQUEST_BYTES + 1),
            },
        )
        assert resp.status_code == 400

    def test_oversized_body_rejected(self):
        server = _make_server()
        client = TestClient(server.app)

        huge = b"{" + b'"x":' + b'"' + b"A" * (MAX_REQUEST_BYTES + 100) + b'"}'
        resp = client.post(
            "/pact/handshake",
            content=huge,
            headers={"content-type": "application/json"},
        )
        assert resp.status_code == 400


class TestFullHandshakeFlow:
    def test_client_handshakes_with_server(self):
        """Simulate the full perform_handshake flow via TestClient."""
        server = _make_server("Bob", 8101)
        client = TestClient(server.app)

        alice = Agent.create(name="Alice", service_endpoint="http://localhost:8100")
        challenge = generate_nonce()

        # Step 1: Send handshake request
        request_data = HandshakeRequest(
            requester_did=alice.did, challenge=challenge
        ).to_dict()
        resp = client.post("/pact/handshake", json=request_data)
        assert resp.status_code == 200

        # Step 2: Verify response
        hs_response = HandshakeResponse.from_dict(resp.json())
        result = verify_handshake_response(hs_response, challenge)
        assert result.verified is True
        assert result.peer_did == server.agent.did

        # Step 3: Send counter-proof
        counter_proof = build_handshake_response(
            alice.key_pair,
            alice.did_document(),
            hs_response.counter_challenge,
            [],
            [],
        )
        resp2 = client.post("/pact/handshake/complete", json=counter_proof.to_dict())
        assert resp2.status_code == 200

        # Bob now knows Alice
        assert alice.did in server.peers

    def test_two_servers_handshake(self):
        """Two PACTServers handshake with each other via TestClient."""
        server_a = _make_server("Alice", 8100)
        server_b = _make_server("Bob", 8101)
        client_a = TestClient(server_a.app)
        client_b = TestClient(server_b.app)

        # Alice handshakes with Bob
        challenge_ab = generate_nonce()
        req_ab = HandshakeRequest(
            requester_did=server_a.agent.did, challenge=challenge_ab
        ).to_dict()
        resp_b = client_b.post("/pact/handshake", json=req_ab)
        assert resp_b.status_code == 200

        hs_resp_b = HandshakeResponse.from_dict(resp_b.json())
        result_ab = verify_handshake_response(hs_resp_b, challenge_ab)
        assert result_ab.verified is True

        # Send counter-proof to Bob
        counter_ab = build_handshake_response(
            server_a.agent.key_pair,
            server_a.agent.did_document(),
            hs_resp_b.counter_challenge,
            [],
            [],
        )
        client_b.post("/pact/handshake/complete", json=counter_ab.to_dict())
        assert server_a.agent.did in server_b.peers

        # Bob handshakes with Alice
        challenge_ba = generate_nonce()
        req_ba = HandshakeRequest(
            requester_did=server_b.agent.did, challenge=challenge_ba
        ).to_dict()
        resp_a = client_a.post("/pact/handshake", json=req_ba)
        assert resp_a.status_code == 200

        hs_resp_a = HandshakeResponse.from_dict(resp_a.json())
        result_ba = verify_handshake_response(hs_resp_a, challenge_ba)
        assert result_ba.verified is True

        # Send counter-proof to Alice
        counter_ba = build_handshake_response(
            server_b.agent.key_pair,
            server_b.agent.did_document(),
            hs_resp_a.counter_challenge,
            [],
            [],
        )
        client_a.post("/pact/handshake/complete", json=counter_ba.to_dict())
        assert server_b.agent.did in server_a.peers
