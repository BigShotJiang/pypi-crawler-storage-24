"""Tests for PACT Agent Pact (Commitment)."""

from pact.agent import Agent
from pact.pact import Pact, PactStatus


class TestPactPropose:
    def test_create_proposal(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Agent A will provide market data analysis",
            deliverables=["Daily market summary", "Price alerts"],
        )

        assert pact.status == PactStatus.PROPOSED
        assert pact.proposer == a1.did
        assert pact.counterparty == a2.did
        assert len(pact.deliverables) == 2

    def test_with_sla(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Real-time data feed",
            deliverables=["Streaming price data"],
            sla={"maxResponseTimeMs": 1000, "minAvailability": 0.99},
        )

        d = pact.to_dict()
        assert d["sla"]["maxResponseTimeMs"] == 1000


class TestPactLifecycle:
    def test_full_lifecycle(self):
        a1 = Agent.create(name="Proposer")
        a2 = Agent.create(name="Counterparty")

        # Propose
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Data analysis service",
            deliverables=["Weekly report"],
        )
        assert pact.status == PactStatus.PROPOSED

        # Sign as proposer
        pact = pact.sign_as_proposer(a1.key_pair)
        assert pact.verify_proposer()

        # Accept (counterparty signs)
        pact = pact.accept(a2.key_pair)
        assert pact.status == PactStatus.ACTIVE
        assert pact.verify_both()

        # Complete (requires authorization)
        pact = pact.complete(a1.key_pair)
        assert pact.status == PactStatus.COMPLETED

    def test_breach(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Service agreement",
            deliverables=["API endpoint"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)

        pact = pact.breach("Failed to deliver API endpoint on time", a2.key_pair)
        assert pact.status == PactStatus.BREACHED
        d = pact.to_dict()
        assert d["breachReason"] == "Failed to deliver API endpoint on time"


class TestPactVerification:
    def test_verify_proposer(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        assert pact.verify_proposer()

    def test_wrong_proposer_key_rejected(self):
        a1 = Agent.create()
        a2 = Agent.create()
        imposter = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )

        import pytest
        with pytest.raises(ValueError, match="does not match"):
            pact.sign_as_proposer(imposter.key_pair)

    def test_verify_both(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        assert pact.verify_both()

    def test_unsigned_not_verified(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        assert not pact.verify_proposer()
        assert not pact.verify_counterparty()


class TestPactSerialization:
    def test_roundtrip(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Agreement",
            deliverables=["item1", "item2"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)

        d = pact.to_dict()
        restored = Pact.from_dict(d)
        assert restored.proposer == a1.did
        assert restored.counterparty == a2.did
        assert restored.status == PactStatus.ACTIVE


class TestPactFromDictValidation:
    def test_non_list_proof_rejected(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        d = pact.to_dict()
        d["proof"] = {"bad": "not a list"}
        with pytest.raises(ValueError, match="must be a list"):
            Pact.from_dict(d)

    def test_deep_copy_isolation(self):
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["item"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        d = pact.to_dict()
        original_terms = d["terms"]
        restored = Pact.from_dict(d)
        # Mutating source dict should not affect restored pact
        d["terms"] = "MUTATED"
        assert restored.terms == original_terms


class TestPactSecurityChecks:
    def test_self_pact_rejected(self):
        import pytest
        a1 = Agent.create()
        with pytest.raises(ValueError, match="yourself"):
            Pact.propose(
                proposer_did=a1.did,
                counterparty_did=a1.did,
                terms="Test",
                deliverables=["test"],
            )

    def test_accept_without_proposer_sig(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        with pytest.raises(ValueError, match="not been signed by the proposer"):
            pact.accept(a2.key_pair)

    def test_complete_requires_party_key(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        outsider = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        with pytest.raises(ValueError, match="does not match"):
            pact.complete(outsider.key_pair)

    def test_breach_requires_party_key(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        outsider = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        with pytest.raises(ValueError, match="does not match"):
            pact.breach("reason", outsider.key_pair)

    def test_complete_requires_active_status(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        # Pact is still PROPOSED, not ACTIVE
        with pytest.raises(ValueError, match="must be active"):
            pact.complete(a1.key_pair)

    def test_breach_requires_active_status(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        completed = pact.complete(a1.key_pair)
        # Already completed, can't breach
        with pytest.raises(ValueError, match="must be active"):
            completed.breach("reason", a1.key_pair)

    def test_cannot_complete_twice(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        completed = pact.complete(a1.key_pair)
        with pytest.raises(ValueError, match="must be active"):
            completed.complete(a1.key_pair)

    def test_cancel_pact(self):
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        cancelled = pact.cancel(a1.key_pair)
        assert cancelled.status == PactStatus.CANCELLED

    def test_cancel_requires_active(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        with pytest.raises(ValueError, match="must be active"):
            pact.cancel(a1.key_pair)

    def test_cancel_requires_party_key(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        outsider = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        with pytest.raises(ValueError, match="does not match"):
            pact.cancel(outsider.key_pair)

    def test_verify_both_after_roundtrip(self):
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        restored = Pact.from_dict(pact.to_dict())
        assert restored.verify_both()

    def test_from_dict_reversed_proofs(self):
        """Proofs matched by DID, not list order."""
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
        )
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        d = pact.to_dict()
        # Reverse the proof list order
        d["proof"] = list(reversed(d["proof"]))
        restored = Pact.from_dict(d)
        assert restored.verify_both()


class TestPactFromDictValidation:
    def test_missing_proposer(self):
        import pytest
        with pytest.raises(ValueError, match="proposer"):
            Pact.from_dict({"id": "x", "counterparty": "x", "terms": "x", "deliverables": ["x"], "status": "proposed"})

    def test_missing_deliverables(self):
        import pytest
        with pytest.raises(ValueError, match="deliverables"):
            Pact.from_dict({"id": "x", "proposer": "x", "counterparty": "x", "terms": "x", "status": "proposed"})

    def test_empty_deliverables(self):
        import pytest
        with pytest.raises(ValueError, match="non-empty"):
            Pact.from_dict({"id": "x", "proposer": "x", "counterparty": "x", "terms": "x", "deliverables": [], "status": "proposed"})

    def test_self_pact_from_dict_rejected(self):
        import pytest
        with pytest.raises(ValueError, match="[Ss]elf"):
            Pact.from_dict({
                "id": "x", "proposer": "did:pact:z6MkTest",
                "counterparty": "did:pact:z6MkTest",
                "terms": "x", "deliverables": ["x"], "status": "proposed",
            })

    def test_invalid_status_from_dict_rejected(self):
        import pytest
        with pytest.raises(ValueError, match="[Ss]tatus"):
            Pact.from_dict({
                "id": "x", "proposer": "did:pact:z6MkA",
                "counterparty": "did:pact:z6MkB",
                "terms": "x", "deliverables": ["x"], "status": "invalid_status",
            })

    def test_verify_both_after_cancel_roundtrip(self):
        a1 = Agent.create()
        a2 = Agent.create()
        pact = Pact.propose(proposer_did=a1.did, counterparty_did=a2.did, terms="Test", deliverables=["test"])
        pact = pact.sign_as_proposer(a1.key_pair)
        pact = pact.accept(a2.key_pair)
        cancelled = pact.cancel(a1.key_pair)
        assert cancelled.status == PactStatus.CANCELLED
        restored = Pact.from_dict(cancelled.to_dict())
        assert restored.verify_both()


class TestPactExpiry:
    def test_not_expired(self):
        a1 = Agent.create()
        a2 = Agent.create()

        pact = Pact.propose(
            proposer_did=a1.did,
            counterparty_did=a2.did,
            terms="Test",
            deliverables=["test"],
            effective_days=30,
        )
        assert not pact.is_expired
