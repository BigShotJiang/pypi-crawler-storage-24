"""Tests for PACT DID operations."""

from pact.crypto import KeyPair
from pact.did import (
    create_did,
    create_did_document,
    did_to_public_key,
    resolve_did_document,
    validate_did,
)


class TestCreateDID:
    def test_format(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        assert did.startswith("did:pact:z")

    def test_deterministic(self):
        seed = b"\x42" * 32
        kp1 = KeyPair.from_seed(seed)
        kp2 = KeyPair.from_seed(seed)
        assert create_did(kp1) == create_did(kp2)

    def test_unique(self):
        kp1 = KeyPair.generate()
        kp2 = KeyPair.generate()
        assert create_did(kp1) != create_did(kp2)


class TestDIDToPublicKey:
    def test_roundtrip(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        recovered = did_to_public_key(did)
        assert recovered == kp.public_bytes

    def test_invalid_format(self):
        import pytest
        with pytest.raises(ValueError):
            did_to_public_key("not-a-did")

    def test_unsupported_method(self):
        import pytest
        with pytest.raises(ValueError):
            did_to_public_key("did:ethr:0x1234")


class TestDIDDocument:
    def test_basic_document(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        doc = create_did_document(did, kp)

        assert doc["id"] == did
        assert "https://www.w3.org/ns/did/v1" in doc["@context"]
        assert len(doc["verificationMethod"]) == 1
        assert doc["verificationMethod"][0]["type"] == "Multikey"
        assert doc["verificationMethod"][0]["controller"] == did
        assert f"{did}#key-0" in doc["authentication"]
        assert f"{did}#key-0" in doc["assertionMethod"]

    def test_with_name(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        doc = create_did_document(did, kp, name="Wren")
        assert doc["name"] == "Wren"

    def test_with_services(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        services = [
            {
                "id": f"{did}#pact",
                "type": "PACTEndpoint",
                "serviceEndpoint": "https://agent.example.com/pact",
            }
        ]
        doc = create_did_document(did, kp, service_endpoints=services)
        assert len(doc["service"]) == 1
        assert doc["service"][0]["type"] == "PACTEndpoint"


class TestResolveDIDDocument:
    def test_resolve(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        doc = resolve_did_document(did)

        assert doc["id"] == did
        assert len(doc["verificationMethod"]) == 1


class TestValidateDID:
    def test_valid(self):
        kp = KeyPair.generate()
        did = create_did(kp)
        assert validate_did(did)

    def test_invalid(self):
        assert not validate_did("not-a-did")
        assert not validate_did("did:ethr:something")
