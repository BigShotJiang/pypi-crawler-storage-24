"""Tests for the RegistryClient."""

import pytest

from pact.agent import Agent
from pact.registry import RegistryClient


class TestRegistryClientInit:
    def test_rejects_http(self):
        with pytest.raises(ValueError, match="HTTPS"):
            RegistryClient("http://registry.example.com")

    def test_accepts_https(self):
        client = RegistryClient("https://registry.example.com")
        assert client._url == "https://registry.example.com"

    def test_strips_trailing_slash(self):
        client = RegistryClient("https://registry.example.com/")
        assert client._url == "https://registry.example.com"


class TestRegistryKeyValidation:
    @pytest.mark.asyncio
    async def test_register_rejects_mismatched_key(self):
        client = RegistryClient("https://registry.example.com")
        agent = Agent.create()
        other = Agent.create()
        with pytest.raises(ValueError, match="does not match"):
            await client.register(agent.did, other.key_pair)

    @pytest.mark.asyncio
    async def test_deregister_rejects_mismatched_key(self):
        client = RegistryClient("https://registry.example.com")
        agent = Agent.create()
        other = Agent.create()
        with pytest.raises(ValueError, match="does not match"):
            await client.deregister(agent.did, other.key_pair)
