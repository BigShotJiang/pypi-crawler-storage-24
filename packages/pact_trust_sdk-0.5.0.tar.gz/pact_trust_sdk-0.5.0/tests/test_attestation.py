"""Tests for PACT Trust Attestations."""

from pact.agent import Agent
from pact.attestation import Attestation, AttestationStore


class TestAttestationCreate:
    def test_basic(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )

        assert att.attestor_did == a1.did
        assert att.subject_did == a2.did
        assert att.interaction_type == "task_completion"
        assert att.outcome == "success"
        assert att.id.startswith("urn:uuid:")

    def test_with_metrics(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="information_quality",
            outcome="success",
            metrics={"accuracy": 0.95, "response_time_ms": 1200},
        )

        assert att.metrics["accuracy"] == 0.95

    def test_with_context(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="partial",
            context="Data retrieval task with partial results",
        )

        d = att.to_dict()
        assert d["context"] == "Data retrieval task with partial results"


class TestAttestationValidation:
    def test_invalid_interaction_type(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        with pytest.raises(ValueError, match="Invalid interaction_type"):
            Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type="fake_type",
                outcome="success",
            )

    def test_invalid_outcome(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        with pytest.raises(ValueError, match="Invalid outcome"):
            Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type="task_completion",
                outcome="maybe",
            )


    def test_self_attestation_rejected(self):
        import pytest
        a1 = Agent.create()
        with pytest.raises(ValueError, match="Self-attestation"):
            Attestation.create(
                attestor_did=a1.did,
                subject_did=a1.did,
                interaction_type="task_completion",
                outcome="success",
            )


class TestAttestationSign:
    def test_sign_and_verify(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )

        signed = att.sign(a1.key_pair)
        assert signed.is_signed
        assert signed.verify()

    def test_unsigned_fails_verify(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )

        assert not att.is_signed
        assert not att.verify()

    def test_wrong_signer_rejected(self):
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )

        # Signing with wrong key must raise ValueError
        import pytest
        with pytest.raises(ValueError, match="does not match"):
            att.sign(a3.key_pair)


class TestAttestationSerialization:
    def test_roundtrip(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="commitment_honored",
            outcome="success",
            metrics={"completeness": 1.0},
        )
        signed = att.sign(a1.key_pair)

        d = signed.to_dict()
        restored = Attestation.from_dict(d)
        assert restored.attestor_did == a1.did
        assert restored.verify()


class TestAttestationStore:
    def test_add_and_count(self):
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        ).sign(a1.key_pair)

        store.add(att)
        assert store.count == 1

    def test_filter_by_type(self):
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()

        for itype in ["task_completion", "information_quality", "task_completion"]:
            att = Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type=itype,
                outcome="success",
            ).sign(a1.key_pair)
            store.add(att)

        assert len(store.get_by_type("task_completion")) == 2
        assert len(store.get_by_type("information_quality")) == 1

    def test_filter_by_attestor(self):
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()

        for attestor in [a1, a2, a1]:
            att = Attestation.create(
                attestor_did=attestor.did,
                subject_did=a3.did,
                interaction_type="task_completion",
                outcome="success",
            ).sign(attestor.key_pair)
            store.add(att)

        assert len(store.get_by_attestor(a1.did)) == 2
        assert len(store.get_by_attestor(a2.did)) == 1

    def test_get_successful(self):
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()

        for outcome in ["success", "failure", "success", "partial"]:
            att = Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type="task_completion",
                outcome=outcome,
            ).sign(a1.key_pair)
            store.add(att)

        assert len(store.get_successful()) == 2

    def test_get_best(self):
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()

        # Add various attestations
        for outcome in ["success", "failure", "success"]:
            att = Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type="task_completion",
                outcome=outcome,
                metrics={"accuracy": 0.9} if outcome == "success" else None,
            ).sign(a1.key_pair)
            store.add(att)

        best = store.get_best(limit=2)
        assert len(best) == 2
        # Best should be successful ones
        assert all(a.outcome == "success" for a in best)

    def test_rejects_unsigned(self):
        import pytest
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()
        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )
        with pytest.raises(ValueError, match="unverified"):
            store.add(att)

    def test_deduplicates(self):
        store = AttestationStore()
        a1 = Agent.create()
        a2 = Agent.create()
        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        ).sign(a1.key_pair)
        store.add(att)
        store.add(att)  # duplicate
        assert store.count == 1

    def test_max_size(self):
        store = AttestationStore(max_size=3)
        a1 = Agent.create()
        a2 = Agent.create()
        for _ in range(5):
            att = Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type="task_completion",
                outcome="success",
            ).sign(a1.key_pair)
            store.add(att)
        assert store.count == 3


class TestAttestationFromDictValidation:
    def test_missing_field(self):
        import pytest
        with pytest.raises(ValueError, match="missing required"):
            Attestation.from_dict({"attestor": "did:pact:z123"})

    def test_invalid_type_in_from_dict(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )
        d = att.to_dict()
        d["interactionType"] = "hacked"
        with pytest.raises(ValueError, match="Invalid interaction_type"):
            Attestation.from_dict(d)

    def test_self_attestation_in_from_dict(self):
        import pytest
        a1 = Agent.create()
        a2 = Agent.create()
        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
        )
        d = att.to_dict()
        d["subject"] = d["attestor"]  # make self-attestation
        with pytest.raises(ValueError, match="Self-attestation"):
            Attestation.from_dict(d)
