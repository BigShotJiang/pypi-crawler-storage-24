"""Integration tests — full PACT lifecycle end-to-end.

These tests verify that all primitives work together correctly in
realistic multi-step workflows.
"""

from pact.agent import Agent
from pact.attestation import Attestation
from pact.crypto import generate_nonce
from pact.handshake import (
    build_handshake_response,
    verify_handshake_response,
)
from pact.mandate import Mandate, validate_delegation_chain
from pact.pact import Pact, PactStatus
from pact.resolver import DIDResolver
from pact.trust import TrustEvaluator


class TestFullLifecycle:
    """Complete lifecycle: identity → delegation → handshake → pact → attestation → trust."""

    def test_two_agents_full_workflow(self):
        # === Phase 1: Identity ===
        human = Agent.create(name="Human Operator")
        alice = Agent.create(name="Alice", service_endpoint="https://alice.example.com/pact")
        bob = Agent.create(name="Bob", service_endpoint="https://bob.example.com/pact")

        assert alice.did != bob.did
        assert alice.did.startswith("did:pact:z")

        # === Phase 2: Delegation ===
        # Human delegates trading authority to Alice
        mandate_alice = Mandate.issue(
            issuer=human.did,
            subject=alice.did,
            scope=["trade:read", "trade:execute", "data:read"],
            expires_in_days=90,
        ).sign(human.key_pair)

        assert mandate_alice.verify()
        assert not mandate_alice.is_expired()

        # Alice sub-delegates read-only to Bob (scope narrows)
        mandate_bob = Mandate.issue(
            issuer=alice.did,
            subject=bob.did,
            scope=["trade:read", "data:read"],
            parent_mandate_id=mandate_alice.id,
        ).sign(alice.key_pair)

        assert validate_delegation_chain([mandate_alice, mandate_bob])

        # === Phase 3: Handshake ===
        # Alice initiates handshake with Bob
        challenge = generate_nonce()

        bob_response = build_handshake_response(
            bob.key_pair,
            bob.did_document(),
            challenge,
            mandates=[mandate_bob.to_dict()],
            attestations=[],
        )

        result = verify_handshake_response(bob_response, challenge)

        assert result.verified
        assert result.peer_did == bob.did
        assert len(result.mandates) == 1
        assert result.mandates[0].subject == bob.did

        # === Phase 4: Form a Pact ===
        pact = Pact.propose(
            proposer_did=alice.did,
            counterparty_did=bob.did,
            terms="Alice provides market data, Bob provides analysis reports",
            deliverables=["Real-time price feed", "Daily analysis summary"],
            sla={"maxResponseTimeMs": 2000, "minAvailability": 0.99},
            effective_days=30,
        )

        pact = pact.sign_as_proposer(alice.key_pair)
        assert pact.verify_proposer()

        pact = pact.accept(bob.key_pair)
        assert pact.status == PactStatus.ACTIVE
        assert pact.verify_both()

        # === Phase 5: Work and Attestation ===
        # After successful work, both attest positively
        att_alice = alice.attest(
            bob.did,
            interaction_type="task_completion",
            outcome="success",
            metrics={"accuracy": 0.92, "response_time_ms": 800},
        )
        bob.receive_attestation(att_alice)

        att_bob = bob.attest(
            alice.did,
            interaction_type="commitment_honored",
            outcome="success",
            metrics={"availability": 0.998},
        )
        alice.receive_attestation(att_bob)

        # === Phase 6: Complete Pact ===
        pact = pact.complete(alice.key_pair)
        assert pact.status == PactStatus.COMPLETED

        # === Phase 7: Trust Evaluation ===
        evaluator = TrustEvaluator()

        bob_trust = evaluator.evaluate(
            bob.attestation_store.get_all(),
            [mandate_bob],
        )
        assert bob_trust > 0.5  # Should be positive with success + mandate

        alice_trust = evaluator.evaluate(
            alice.attestation_store.get_all(),
        )
        assert alice_trust > 0.3  # Positive with success attestation

        # === Phase 8: Serialization Roundtrip ===
        pact_dict = pact.to_dict()
        restored_pact = Pact.from_dict(pact_dict)
        assert restored_pact.status == PactStatus.COMPLETED
        assert restored_pact.verify_both()

    def test_breach_workflow(self):
        alice = Agent.create(name="Alice")
        bob = Agent.create(name="Bob")

        pact = Pact.propose(
            proposer_did=alice.did,
            counterparty_did=bob.did,
            terms="Bob provides daily reports",
            deliverables=["Daily report by 6am UTC"],
        )
        pact = pact.sign_as_proposer(alice.key_pair)
        pact = pact.accept(bob.key_pair)

        # Bob fails to deliver — Alice reports breach
        pact = pact.breach("Failed to deliver daily report for 3 consecutive days", alice.key_pair)
        assert pact.status == PactStatus.BREACHED

        # Alice attests negatively about Bob
        att = alice.attest(
            bob.did,
            interaction_type="commitment_honored",
            outcome="failure",
        )

        evaluator = TrustEvaluator()
        score = evaluator.evaluate([att])
        assert score < 0.3  # Failure should result in low trust

    def test_delegation_chain_three_levels(self):
        org = Agent.create(name="Organization")
        manager = Agent.create(name="Manager")
        worker = Agent.create(name="Worker")

        # Org → Manager: broad scope
        m1 = Mandate.issue(
            issuer=org.did,
            subject=manager.did,
            scope=["finance:read", "finance:write", "hr:read", "hr:write"],
            expires_in_days=365,
        ).sign(org.key_pair)

        # Manager → Worker: narrowed scope
        m2 = Mandate.issue(
            issuer=manager.did,
            subject=worker.did,
            scope=["finance:read"],
            parent_mandate_id=m1.id,
            expires_in_days=30,
        ).sign(manager.key_pair)

        assert validate_delegation_chain([m1, m2])

        # Worker cannot expand scope
        m3_bad = Mandate.issue(
            issuer=worker.did,
            subject=Agent.create().did,
            scope=["finance:read", "finance:write"],  # Trying to expand
            parent_mandate_id=m2.id,
        ).sign(worker.key_pair)

        assert not validate_delegation_chain([m1, m2, m3_bad])

    def test_selective_disclosure(self):
        """Agent chooses which attestations to reveal in handshake."""
        attestor1 = Agent.create()
        attestor2 = Agent.create()
        subject = Agent.create()

        # Subject receives mix of good and bad attestations
        good1 = attestor1.attest(subject.did, interaction_type="task_completion", outcome="success")
        good2 = attestor2.attest(subject.did, interaction_type="information_quality", outcome="success")
        bad = attestor1.attest(subject.did, interaction_type="availability", outcome="failure")

        subject.receive_attestation(good1)
        subject.receive_attestation(good2)
        subject.receive_attestation(bad)

        assert subject.attestation_store.count == 3

        # Selective disclosure: get_best prioritizes successes
        best = subject.attestation_store.get_best(limit=2)
        assert len(best) == 2
        assert all(a.outcome == "success" for a in best)

        # Use best attestations in handshake
        challenge = generate_nonce()
        response = build_handshake_response(
            subject.key_pair,
            subject.did_document(),
            challenge,
            mandates=[],
            attestations=[a.to_dict() for a in best],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.attestations) == 2


class TestHandshakeEdgeCases:
    def test_mandate_wrong_subject_filtered(self):
        """Mandates whose subject doesn't match peer DID are rejected."""
        from pact.mandate import Mandate

        alice = Agent.create()
        bob = Agent.create()
        unrelated = Agent.create()

        # Mandate is for unrelated agent, not bob
        stolen_mandate = Mandate.issue(
            issuer=alice.did,
            subject=unrelated.did,
            scope=["read"],
        ).sign(alice.key_pair)

        challenge = generate_nonce()
        response = build_handshake_response(
            bob.key_pair,
            bob.did_document(),
            challenge,
            mandates=[stolen_mandate.to_dict()],
            attestations=[],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.mandates) == 0  # Stolen mandate filtered out

    def test_invalid_attestation_in_handshake_filtered(self):
        """Attestations with invalid signatures are silently filtered."""
        alice = Agent.create()
        bob = Agent.create()

        # Create valid attestation then tamper with it
        att = alice.attest(bob.did, interaction_type="task_completion", outcome="success")
        d = att.to_dict()
        d["outcome"] = "tampered"  # Invalidates signature

        challenge = generate_nonce()
        response = build_handshake_response(
            bob.key_pair,
            bob.did_document(),
            challenge,
            mandates=[],
            attestations=[d],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.attestations) == 0  # Tampered attestation filtered

    def test_handshake_with_many_credentials(self):
        """Handshake handles maximum-sized credential sets."""
        from pact.handshake import MAX_HANDSHAKE_MANDATES, MAX_HANDSHAKE_ATTESTATIONS

        alice = Agent.create()
        bob = Agent.create()

        # Create more mandates than the limit
        mandates = []
        for _ in range(MAX_HANDSHAKE_MANDATES + 10):
            m = Mandate.issue(
                issuer=alice.did,
                subject=bob.did,
                scope=["read"],
            ).sign(alice.key_pair)
            mandates.append(m.to_dict())

        challenge = generate_nonce()
        response = build_handshake_response(
            bob.key_pair,
            bob.did_document(),
            challenge,
            mandates=mandates,
            attestations=[],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.mandates) <= MAX_HANDSHAKE_MANDATES


class TestResolverIntegration:
    def test_resolve_agent_did(self):
        resolver = DIDResolver()
        agent = Agent.create(name="Test")

        doc = resolver.resolve(agent.did)
        assert doc is not None
        assert doc["id"] == agent.did

    def test_cache_isolation(self):
        """Mutating a resolved doc doesn't affect cached version."""
        resolver = DIDResolver()
        agent = Agent.create()

        doc1 = resolver.resolve(agent.did)
        doc1["POISONED"] = True

        doc2 = resolver.resolve(agent.did)
        assert "POISONED" not in doc2

    def test_unknown_method(self):
        resolver = DIDResolver()
        assert resolver.resolve("did:unknown:abc123") is None


class TestTrustEvaluatorEdgeCases:
    def test_extreme_metrics_clamped(self):
        """Extreme metric values should not break scoring."""
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
            metrics={"accuracy": 99999.0, "response_time_ms": -1000},
        ).sign(a1.key_pair)

        evaluator = TrustEvaluator()
        score = evaluator.evaluate([att])
        assert 0.0 <= score <= 1.0

    def test_string_metrics_ignored(self):
        """Non-numeric metrics should not crash."""
        a1 = Agent.create()
        a2 = Agent.create()

        att = Attestation.create(
            attestor_did=a1.did,
            subject_did=a2.did,
            interaction_type="task_completion",
            outcome="success",
            metrics={"accuracy": "not a number", "response_time_ms": "fast"},
        ).sign(a1.key_pair)

        evaluator = TrustEvaluator()
        score = evaluator.evaluate([att])
        assert 0.0 <= score <= 1.0

    def test_detailed_breakdown_completeness(self):
        a1 = Agent.create()
        a2 = Agent.create()

        atts = []
        for itype, outcome in [
            ("task_completion", "success"),
            ("task_completion", "failure"),
            ("information_quality", "partial"),
        ]:
            att = Attestation.create(
                attestor_did=a1.did,
                subject_did=a2.did,
                interaction_type=itype,
                outcome=outcome,
            ).sign(a1.key_pair)
            atts.append(att)

        evaluator = TrustEvaluator()
        detail = evaluator.evaluate_detailed(atts)

        assert "score" in detail
        assert "breakdown_by_type" in detail
        assert detail["attestation_count"] == 3
        assert "task_completion" in detail["breakdown_by_type"]
        assert detail["breakdown_by_type"]["task_completion"]["success"] == 1
        assert detail["breakdown_by_type"]["task_completion"]["failure"] == 1
