"""Tests for the PACT MCP server tools."""

from __future__ import annotations

import pytest

from pact.mcp import (
    _agents,
    _mandates,
    _pacts,
    accept_pact,
    agent_attestations,
    agent_did_document,
    breach_pact,
    complete_pact,
    create_agent,
    create_attestation,
    evaluate_trust,
    get_agent_info,
    get_attestations,
    get_pact_info,
    handshake,
    issue_mandate,
    list_agents,
    list_mandates,
    list_pacts,
    propose_pact,
    resolve_did,
    validate_chain,
    verify_mandate,
)


@pytest.fixture(autouse=True)
def _clear_state():
    """Clear module-level state between tests."""
    _agents.clear()
    _mandates.clear()
    _pacts.clear()
    yield
    _agents.clear()
    _mandates.clear()
    _pacts.clear()


# ===== Agent Identity =======================================================

class TestCreateAgent:
    def test_basic(self):
        result = create_agent("alice")
        assert result["name"] == "alice"
        assert result["did"].startswith("did:pact:")
        assert result["service_endpoint"] is None

    def test_with_endpoint(self):
        result = create_agent("bob", service_endpoint="https://bob.example.com")
        assert result["service_endpoint"] == "https://bob.example.com"

    def test_duplicate_name_raises(self):
        create_agent("alice")
        with pytest.raises(ValueError, match="already exists"):
            create_agent("alice")

    def test_empty_name_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            create_agent("")

    def test_whitespace_name_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            create_agent("   ")

    def test_leading_whitespace_raises(self):
        with pytest.raises(ValueError, match="whitespace"):
            create_agent(" alice")

    def test_long_name_raises(self):
        with pytest.raises(ValueError, match="exceeds"):
            create_agent("a" * 65)


class TestListAgents:
    def test_empty(self):
        assert list_agents() == []

    def test_multiple(self):
        create_agent("alice")
        create_agent("bob")
        result = list_agents()
        assert len(result) == 2
        names = {a["name"] for a in result}
        assert names == {"alice", "bob"}


class TestGetAgentInfo:
    def test_full_info(self):
        create_agent("alice")
        info = get_agent_info("alice")
        assert info["name"] == "alice"
        assert "did_document" in info
        assert info["did_document"]["id"].startswith("did:pact:")
        assert info["mandate_count"] == 0
        assert info["attestation_count"] == 0

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown agent"):
            get_agent_info("ghost")


# ===== Delegation Mandates ==================================================

class TestIssueMandate:
    def test_basic(self):
        create_agent("alice")
        create_agent("bob")
        result = issue_mandate("alice", "bob", ["trade:read"])
        assert "mandate_id" in result
        assert result["issuer"] == "alice"
        assert result["subject"] == "bob"
        assert result["scope"] == ["trade:read"]

    def test_stored_in_state(self):
        create_agent("alice")
        create_agent("bob")
        result = issue_mandate("alice", "bob", ["trade:read"])
        assert result["mandate_id"] in _mandates

    def test_with_expiry(self):
        create_agent("alice")
        create_agent("bob")
        result = issue_mandate("alice", "bob", ["trade:read"], expires_in_days=7)
        assert result["mandate_id"] in _mandates


class TestVerifyMandate:
    def test_valid(self):
        create_agent("alice")
        create_agent("bob")
        m = issue_mandate("alice", "bob", ["trade:read"])
        result = verify_mandate(m["mandate_id"])
        assert result["signature_valid"] is True
        assert result["expired"] is False
        assert result["issuer"] == "alice"
        assert result["subject"] == "bob"

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown mandate"):
            verify_mandate("nonexist")


class TestValidateChain:
    def test_single_mandate_chain(self):
        create_agent("alice")
        create_agent("bob")
        m = issue_mandate("alice", "bob", ["trade:read"])
        result = validate_chain([m["mandate_id"]])
        assert result["valid"] is True
        assert result["chain_length"] == 1

    def test_two_mandate_chain(self):
        create_agent("root")
        create_agent("middle")
        create_agent("leaf")
        m1 = issue_mandate("root", "middle", ["trade:read", "trade:execute"])
        m2 = issue_mandate("middle", "leaf", ["trade:read"], parent_mandate_id=m1["mandate_id"])
        result = validate_chain([m1["mandate_id"], m2["mandate_id"]])
        assert result["valid"] is True
        assert result["chain_length"] == 2

    def test_unknown_in_chain_raises(self):
        with pytest.raises(ValueError, match="Unknown mandate"):
            validate_chain(["nonexist"])


# ===== Trust Attestations ===================================================

class TestCreateAttestation:
    def test_basic(self):
        create_agent("alice")
        create_agent("bob")
        result = create_attestation("alice", "bob", "task_completion", "success")
        assert result["attestor"] == "alice"
        assert result["subject"] == "bob"
        assert result["outcome"] == "success"

    def test_with_metrics(self):
        create_agent("alice")
        create_agent("bob")
        result = create_attestation(
            "alice", "bob", "task_completion", "success",
            metrics={"accuracy": 0.95},
        )
        assert result["outcome"] == "success"

    def test_stored_on_subject(self):
        create_agent("alice")
        create_agent("bob")
        create_attestation("alice", "bob", "task_completion", "success")
        assert _agents["bob"].attestation_store.count == 1


class TestGetAttestations:
    def test_empty(self):
        create_agent("alice")
        assert get_attestations("alice") == []

    def test_with_attestations(self):
        create_agent("alice")
        create_agent("bob")
        create_attestation("alice", "bob", "task_completion", "success")
        result = get_attestations("bob")
        assert len(result) == 1
        assert result[0]["outcome"] == "success"
        assert result[0]["attestor"] == "alice"

    def test_filter_by_type(self):
        create_agent("alice")
        create_agent("bob")
        create_attestation("alice", "bob", "task_completion", "success")
        create_attestation("alice", "bob", "availability", "success")
        result = get_attestations("bob", filter_type="availability")
        assert len(result) == 1
        assert result[0]["interaction_type"] == "availability"


class TestEvaluateTrust:
    def test_no_attestations(self):
        create_agent("alice")
        result = evaluate_trust("alice")
        assert result["agent"] == "alice"
        assert "score" in result
        assert result["attestation_count"] == 0

    def test_with_attestations(self):
        create_agent("alice")
        create_agent("bob")
        create_attestation("alice", "bob", "task_completion", "success")
        create_attestation("alice", "bob", "task_completion", "success")
        create_attestation("alice", "bob", "task_completion", "success")
        result = evaluate_trust("bob")
        assert result["score"] > 0.5
        assert result["attestation_count"] == 3


# ===== Agent Handshake =====================================================

class TestHandshake:
    def test_local(self):
        create_agent("alice")
        create_agent("bob")
        result = handshake("alice", "bob")
        assert result["verified"] is True
        assert result["initiator"] == "alice"
        assert result["responder"] == "bob"
        assert result["peer_did"].startswith("did:pact:")

    def test_with_attestations(self):
        create_agent("alice")
        create_agent("bob")
        create_attestation("alice", "bob", "task_completion", "success")
        result = handshake("alice", "bob")
        assert result["verified"] is True
        assert result["attestations_received"] >= 1


# ===== Agent Pacts ==========================================================

class TestProposePact:
    def test_basic(self):
        create_agent("alice")
        create_agent("bob")
        result = propose_pact(
            "alice", "bob",
            terms="Alice will provide data analysis",
            deliverables=["Weekly report"],
        )
        assert "pact_id" in result
        assert result["status"] == "proposed"
        assert result["proposer"] == "alice"

    def test_with_sla(self):
        create_agent("alice")
        create_agent("bob")
        result = propose_pact(
            "alice", "bob",
            terms="Data analysis",
            deliverables=["Report"],
            sla={"response_time": "24h"},
            effective_days=60,
        )
        assert result["status"] == "proposed"


class TestAcceptPact:
    def test_accept(self):
        create_agent("alice")
        create_agent("bob")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        result = accept_pact(p["pact_id"], "bob")
        assert result["status"] == "active"

    def test_unknown_pact_raises(self):
        create_agent("alice")
        with pytest.raises(ValueError, match="Unknown pact"):
            accept_pact("nonexist", "alice")


class TestCompletePact:
    def test_complete(self):
        create_agent("alice")
        create_agent("bob")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        accept_pact(p["pact_id"], "bob")
        result = complete_pact(p["pact_id"], "alice")
        assert result["status"] == "completed"


class TestBreachPact:
    def test_breach(self):
        create_agent("alice")
        create_agent("bob")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        accept_pact(p["pact_id"], "bob")
        result = breach_pact(p["pact_id"], "alice", "Failed to deliver")
        assert result["status"] == "breached"
        assert result["reason"] == "Failed to deliver"


# ===== Utility ==============================================================

class TestGetPactInfo:
    def test_info(self):
        create_agent("alice")
        create_agent("bob")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        info = get_pact_info(p["pact_id"])
        assert info["proposer"] == "alice"
        assert info["counterparty"] == "bob"
        assert info["terms"] == "Terms"
        assert info["deliverables"] == ["D1"]

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown pact"):
            get_pact_info("nonexist")


class TestListPacts:
    def test_all(self):
        create_agent("alice")
        create_agent("bob")
        propose_pact("alice", "bob", "T1", ["D1"])
        propose_pact("bob", "alice", "T2", ["D2"])
        result = list_pacts()
        assert len(result) == 2

    def test_filtered(self):
        create_agent("alice")
        create_agent("bob")
        create_agent("carol")
        propose_pact("alice", "bob", "T1", ["D1"])
        propose_pact("bob", "carol", "T2", ["D2"])
        result = list_pacts(agent="alice")
        assert len(result) == 1

    def test_empty(self):
        assert list_pacts() == []


class TestResolveDid:
    def test_valid(self):
        create_agent("alice")
        did = _agents["alice"].did
        doc = resolve_did(did)
        assert doc["id"] == did

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Invalid DID"):
            resolve_did("not-a-did")


# ===== Full Workflow ========================================================

class TestFullWorkflow:
    def test_end_to_end(self):
        """Full workflow: create agents, delegate, attest, handshake, pact."""
        # Create agents
        create_agent("alice")
        create_agent("bob")

        # Delegate
        m = issue_mandate("alice", "bob", ["analyze:data"])
        v = verify_mandate(m["mandate_id"])
        assert v["signature_valid"] is True

        # Attest
        create_attestation("alice", "bob", "task_completion", "success")
        create_attestation("alice", "bob", "task_completion", "success")
        create_attestation("alice", "bob", "task_completion", "success")

        # Trust
        trust = evaluate_trust("bob")
        assert trust["score"] > 0.3

        # Handshake
        hs = handshake("alice", "bob")
        assert hs["verified"] is True

        # Pact lifecycle
        p = propose_pact("alice", "bob", "Analyze quarterly data", ["Q1 report"])
        accept_pact(p["pact_id"], "bob")
        result = complete_pact(p["pact_id"], "alice")
        assert result["status"] == "completed"


# ===== MCP Resources =======================================================

class TestResources:
    def test_did_document_resource(self):
        create_agent("alice")
        doc = agent_did_document("alice")
        assert doc["id"] == _agents["alice"].did
        assert "verificationMethod" in doc

    def test_attestations_resource_empty(self):
        create_agent("alice")
        assert agent_attestations("alice") == []

    def test_attestations_resource_with_data(self):
        create_agent("alice")
        create_agent("bob")
        create_attestation("alice", "bob", "task_completion", "success")
        result = agent_attestations("bob")
        assert len(result) == 1
        assert result[0]["outcome"] == "success"

    def test_resource_unknown_agent_raises(self):
        with pytest.raises(ValueError, match="Unknown agent"):
            agent_did_document("ghost")


# ===== Negative Paths =======================================================

class TestNegativePaths:
    def test_accept_pact_wrong_agent(self):
        """Non-counterparty cannot accept a pact."""
        create_agent("alice")
        create_agent("bob")
        create_agent("eve")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        with pytest.raises(ValueError):
            accept_pact(p["pact_id"], "eve")

    def test_complete_proposed_pact_raises(self):
        """Cannot complete a pact that is still PROPOSED."""
        create_agent("alice")
        create_agent("bob")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        with pytest.raises(ValueError):
            complete_pact(p["pact_id"], "alice")

    def test_breach_completed_pact_raises(self):
        """Cannot breach an already-completed pact."""
        create_agent("alice")
        create_agent("bob")
        p = propose_pact("alice", "bob", "Terms", ["D1"])
        accept_pact(p["pact_id"], "bob")
        complete_pact(p["pact_id"], "alice")
        with pytest.raises(ValueError):
            breach_pact(p["pact_id"], "alice", "too late")

    def test_self_attestation_raises(self):
        """Agent cannot attest about itself."""
        create_agent("alice")
        with pytest.raises(ValueError):
            create_attestation("alice", "alice", "task_completion", "success")

    def test_self_handshake_raises(self):
        """Cannot handshake with self."""
        create_agent("alice")
        with pytest.raises(ValueError, match="self"):
            handshake("alice", "alice")

    def test_empty_chain_raises(self):
        """Empty delegation chain is invalid."""
        with pytest.raises(ValueError, match="at least one"):
            validate_chain([])


# ===== List Mandates ========================================================

class TestListMandates:
    def test_empty(self):
        assert list_mandates() == []

    def test_all(self):
        create_agent("alice")
        create_agent("bob")
        issue_mandate("alice", "bob", ["trade:read"])
        issue_mandate("bob", "alice", ["trade:write"])
        result = list_mandates()
        assert len(result) == 2

    def test_filtered(self):
        create_agent("alice")
        create_agent("bob")
        create_agent("carol")
        issue_mandate("alice", "bob", ["trade:read"])
        issue_mandate("bob", "carol", ["trade:write"])
        result = list_mandates(agent="alice")
        assert len(result) == 1
        assert result[0]["issuer"] == "alice"

    def test_returns_names(self):
        create_agent("alice")
        create_agent("bob")
        issue_mandate("alice", "bob", ["trade:read"])
        result = list_mandates()
        assert result[0]["issuer"] == "alice"
        assert result[0]["subject"] == "bob"


# ===== List Pacts Name Resolution ===========================================

class TestListPactsNames:
    def test_returns_names_not_dids(self):
        create_agent("alice")
        create_agent("bob")
        propose_pact("alice", "bob", "Terms", ["D1"])
        result = list_pacts()
        assert result[0]["proposer"] == "alice"
        assert result[0]["counterparty"] == "bob"
