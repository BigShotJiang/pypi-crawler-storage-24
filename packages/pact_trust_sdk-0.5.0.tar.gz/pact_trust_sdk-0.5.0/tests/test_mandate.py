"""Tests for PACT Delegation Mandates."""

from pact.agent import Agent
from pact.mandate import Mandate, validate_delegation_chain


class TestMandateIssue:
    def test_basic_mandate(self):
        human = Agent.create(name="Human")
        agent = Agent.create(name="Agent")

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["trade:read", "trade:execute"],
        )

        assert mandate.issuer == human.did
        assert mandate.subject == agent.did
        assert mandate.scope == ["trade:read", "trade:execute"]
        assert mandate.id.startswith("urn:uuid:")

    def test_with_expiry(self):
        human = Agent.create()
        agent = Agent.create()

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["read"],
            expires_in_days=90,
        )

        assert not mandate.is_expired()

    def test_with_constraints(self):
        human = Agent.create()
        agent = Agent.create()

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["trade:execute"],
            constraints={"max_amount": 1000, "currency": "USD"},
        )

        d = mandate.to_dict()
        assert d["credentialSubject"]["constraints"]["max_amount"] == 1000


class TestMandateSign:
    def test_sign_and_verify(self):
        human = Agent.create()
        agent = Agent.create()

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["read"],
        )

        signed = mandate.sign(human.key_pair)
        assert signed.verify()

    def test_wrong_signer_rejected(self):
        human = Agent.create()
        agent = Agent.create()
        imposter = Agent.create()

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["read"],
        )

        # Signing with wrong key must raise ValueError
        import pytest
        with pytest.raises(ValueError, match="does not match"):
            mandate.sign(imposter.key_pair)


class TestMandateSerialization:
    def test_roundtrip(self):
        human = Agent.create()
        agent = Agent.create()

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["read", "write"],
        )
        signed = mandate.sign(human.key_pair)

        d = signed.to_dict()
        restored = Mandate.from_dict(d)
        assert restored.issuer == human.did
        assert restored.subject == agent.did
        assert restored.verify()


class TestDelegationChain:
    def test_valid_chain(self):
        human = Agent.create(name="Human")
        agent_a = Agent.create(name="AgentA")
        agent_b = Agent.create(name="AgentB")

        # Human delegates to Agent A
        m1 = Mandate.issue(
            issuer=human.did,
            subject=agent_a.did,
            scope=["trade:read", "trade:execute", "trade:cancel"],
        ).sign(human.key_pair)

        # Agent A sub-delegates to Agent B (narrower scope)
        m2 = Mandate.issue(
            issuer=agent_a.did,
            subject=agent_b.did,
            scope=["trade:read"],
            parent_mandate_id=m1.id,
        ).sign(agent_a.key_pair)

        assert validate_delegation_chain([m1, m2])

    def test_broken_chain(self):
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()
        unrelated = Agent.create()

        m1 = Mandate.issue(
            issuer=a1.did, subject=a2.did, scope=["read"]
        ).sign(a1.key_pair)

        # Break: m2 issuer is unrelated, not a2
        m2 = Mandate.issue(
            issuer=unrelated.did, subject=a3.did, scope=["read"]
        ).sign(unrelated.key_pair)

        assert not validate_delegation_chain([m1, m2])

    def test_scope_expansion_rejected(self):
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()

        m1 = Mandate.issue(
            issuer=a1.did, subject=a2.did, scope=["read"]
        ).sign(a1.key_pair)

        # Try to expand scope (should fail)
        m2 = Mandate.issue(
            issuer=a2.did, subject=a3.did, scope=["read", "write"]
        ).sign(a2.key_pair)

        assert not validate_delegation_chain([m1, m2])

    def test_empty_chain(self):
        assert not validate_delegation_chain([])


class TestMandateFromDictValidation:
    def test_missing_issuer(self):
        import pytest
        with pytest.raises(ValueError, match="issuer"):
            Mandate.from_dict({"credentialSubject": {"id": "did:pact:z123", "scope": ["read"]}})

    def test_missing_credential_subject(self):
        import pytest
        with pytest.raises(ValueError, match="credentialSubject"):
            Mandate.from_dict({"issuer": "did:pact:z123"})

    def test_empty_scope(self):
        import pytest
        with pytest.raises(ValueError, match="non-empty"):
            Mandate.from_dict({
                "issuer": "did:pact:z123",
                "credentialSubject": {"id": "did:pact:z456", "scope": []},
            })

    def test_expires_in_zero_days(self):
        """expires_in_days=0 should set an expiration (not be treated as falsy)."""
        a1 = Agent.create()
        a2 = Agent.create()
        mandate = Mandate.issue(
            issuer=a1.did,
            subject=a2.did,
            scope=["read"],
            expires_in_days=0,
        )
        assert mandate.is_expired()  # 0 days = already expired
