"""Tests for the DIDResolver."""

import time

import pytest

from pact.agent import Agent
from pact.resolver import DIDResolver


class TestResolverLocal:
    def test_resolve_did_pact(self):
        resolver = DIDResolver()
        agent = Agent.create(name="Test")
        doc = resolver.resolve(agent.did)
        assert doc is not None
        assert doc["id"] == agent.did

    def test_resolve_unknown_method(self):
        resolver = DIDResolver()
        assert resolver.resolve("did:unknown:abc123") is None

    def test_resolve_invalid_did(self):
        resolver = DIDResolver()
        assert resolver.resolve("not-a-did") is None


class TestResolverCache:
    def test_cache_hit(self):
        resolver = DIDResolver()
        agent = Agent.create()
        doc1 = resolver.resolve(agent.did)
        doc2 = resolver.resolve(agent.did)
        assert doc1 == doc2

    def test_cache_isolation(self):
        """Mutating a resolved doc doesn't affect cached version."""
        resolver = DIDResolver()
        agent = Agent.create()
        doc1 = resolver.resolve(agent.did)
        doc1["POISONED"] = True
        doc2 = resolver.resolve(agent.did)
        assert "POISONED" not in doc2

    def test_cache_eviction(self):
        resolver = DIDResolver(cache_size=2)
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()
        resolver.resolve(a1.did)
        resolver.resolve(a2.did)
        resolver.resolve(a3.did)  # Should evict a1
        # a1 should be evicted — resolving it again still works (re-resolves locally)
        doc = resolver.resolve(a1.did)
        assert doc is not None

    def test_cache_ttl_expiry(self):
        resolver = DIDResolver(cache_ttl=0.01)  # 10ms TTL
        agent = Agent.create()
        resolver.resolve(agent.did)
        time.sleep(0.02)
        # Cache should be expired, but local resolution still works
        doc = resolver.resolve(agent.did)
        assert doc is not None

    def test_clear_cache(self):
        resolver = DIDResolver()
        agent = Agent.create()
        resolver.resolve(agent.did)
        resolver.clear_cache()
        # Still resolves (local), but cache was cleared
        doc = resolver.resolve(agent.did)
        assert doc is not None


class TestSafeDomain:
    def test_blocks_localhost(self):
        assert not DIDResolver._is_safe_domain("localhost")

    def test_blocks_localhost_localdomain(self):
        assert not DIDResolver._is_safe_domain("localhost.localdomain")

    def test_blocks_zero_ip(self):
        assert not DIDResolver._is_safe_domain("0.0.0.0")

    def test_blocks_loopback(self):
        assert not DIDResolver._is_safe_domain("127.0.0.1")

    def test_blocks_private_10(self):
        assert not DIDResolver._is_safe_domain("10.0.0.1")

    def test_blocks_private_172(self):
        assert not DIDResolver._is_safe_domain("172.16.0.1")

    def test_blocks_private_192(self):
        assert not DIDResolver._is_safe_domain("192.168.1.1")

    def test_blocks_link_local(self):
        assert not DIDResolver._is_safe_domain("169.254.1.1")

    def test_blocks_ipv6_loopback(self):
        assert not DIDResolver._is_safe_domain("::1")

    def test_blocks_null_byte(self):
        assert not DIDResolver._is_safe_domain("example.com\x00.evil.com")

    def test_blocks_null_escape(self):
        assert not DIDResolver._is_safe_domain("example.com\0.evil.com")

    def test_blocks_with_port(self):
        assert not DIDResolver._is_safe_domain("127.0.0.1:8080")

    def test_allows_public_ip(self):
        assert DIDResolver._is_safe_domain("8.8.8.8")


class TestResolverWebPathTraversal:
    """Test did:web path sanitization (tested via _resolve_web indirectly)."""

    @pytest.mark.asyncio
    async def test_rejects_dotdot_path(self):
        resolver = DIDResolver()
        result = await resolver._resolve_web("did:web:example.com:..:etc:passwd")
        assert result is None

    @pytest.mark.asyncio
    async def test_rejects_dot_path(self):
        resolver = DIDResolver()
        result = await resolver._resolve_web("did:web:example.com:.")
        assert result is None

    @pytest.mark.asyncio
    async def test_rejects_slash_in_segment(self):
        resolver = DIDResolver()
        result = await resolver._resolve_web("did:web:example.com:foo%2Fbar")
        assert result is None

    @pytest.mark.asyncio
    async def test_rejects_short_did(self):
        resolver = DIDResolver()
        result = await resolver._resolve_web("did:web")
        assert result is None


class TestHandshakeFromDictValidation:
    """Test handshake from_dict validation (findings 2 & 3)."""

    def test_request_missing_requester_did(self):
        from pact.handshake import HandshakeRequest
        with pytest.raises(ValueError, match="requesterDID"):
            HandshakeRequest.from_dict({"challenge": "a" * 64})

    def test_request_missing_challenge(self):
        from pact.handshake import HandshakeRequest
        with pytest.raises(ValueError, match="challenge"):
            HandshakeRequest.from_dict({"requesterDID": "did:pact:z6Mk..."})

    def test_request_short_challenge(self):
        from pact.handshake import HandshakeRequest
        with pytest.raises(ValueError, match="entropy"):
            HandshakeRequest.from_dict({"requesterDID": "did:pact:z6Mk...", "challenge": "short"})

    def test_response_missing_did_document(self):
        from pact.handshake import HandshakeResponse
        with pytest.raises(ValueError, match="didDocument"):
            HandshakeResponse.from_dict({
                "challengeProof": "z...",
                "counterChallenge": "a" * 64,
            })

    def test_response_missing_challenge_proof(self):
        from pact.handshake import HandshakeResponse
        with pytest.raises(ValueError, match="challengeProof"):
            HandshakeResponse.from_dict({
                "didDocument": {"id": "did:pact:z6Mk..."},
                "counterChallenge": "a" * 64,
            })

    def test_response_did_document_missing_id(self):
        from pact.handshake import HandshakeResponse
        with pytest.raises(ValueError, match="id"):
            HandshakeResponse.from_dict({
                "didDocument": {"notId": "foo"},
                "challengeProof": "z...",
                "counterChallenge": "a" * 64,
            })
