"""Tests for PACT Agent class."""

from pact.agent import Agent
from pact.attestation import Attestation


class TestAgentCreate:
    def test_create(self):
        agent = Agent.create(name="TestBot")
        assert agent.did.startswith("did:pact:z")
        assert agent.name == "TestBot"

    def test_create_unnamed(self):
        agent = Agent.create()
        assert agent.did.startswith("did:pact:z")
        assert agent.name is None

    def test_deterministic_from_seed(self):
        seed = b"\x01" * 32
        a1 = Agent.from_seed(seed, name="Same")
        a2 = Agent.from_seed(seed, name="Same")
        assert a1.did == a2.did

    def test_unique_identities(self):
        a1 = Agent.create()
        a2 = Agent.create()
        assert a1.did != a2.did


class TestAgentDIDDocument:
    def test_basic_document(self):
        agent = Agent.create(name="Wren")
        doc = agent.did_document()
        assert doc["id"] == agent.did
        assert doc["name"] == "Wren"

    def test_with_endpoint(self):
        agent = Agent.create(service_endpoint="https://wren.example.com/pact")
        doc = agent.did_document()
        assert len(doc["service"]) == 1
        assert doc["service"][0]["type"] == "PACTEndpoint"

    def test_without_endpoint(self):
        agent = Agent.create()
        doc = agent.did_document()
        assert doc["service"] == []


class TestAgentSign:
    def test_sign(self):
        agent = Agent.create()
        sig = agent.sign(b"hello")
        assert len(sig) == 64


class TestAgentAttest:
    def test_create_attestation(self):
        agent = Agent.create(name="Attestor")
        peer = Agent.create(name="Peer")

        attestation = agent.attest(
            peer.did,
            interaction_type="task_completion",
            outcome="success",
            metrics={"accuracy": 0.95},
        )

        assert attestation.attestor_did == agent.did
        assert attestation.subject_did == peer.did
        assert attestation.outcome == "success"
        assert attestation.is_signed
        assert attestation.verify()

    def test_receive_attestation(self):
        a1 = Agent.create()
        a2 = Agent.create()

        att = a1.attest(a2.did, interaction_type="task_completion", outcome="success")
        a2.receive_attestation(att)
        assert a2.attestation_store.count == 1

    def test_receive_wrong_subject(self):
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()

        att = a1.attest(a3.did, interaction_type="task_completion", outcome="success")

        import pytest
        with pytest.raises(ValueError):
            a2.receive_attestation(att)


class TestAgentPersistence:
    def test_export_import(self):
        agent = Agent.create(name="Persistent")
        private = agent.export_private_key()
        did = agent.did

        restored = Agent.from_private_key(private, name="Persistent")
        assert restored.did == did


class TestAgentHandshakePayload:
    def test_payload_structure(self):
        agent = Agent.create(name="Test", service_endpoint="https://test.com/pact")
        payload = agent.get_handshake_payload()

        assert "did_document" in payload
        assert "mandates" in payload
        assert "attestations" in payload
        assert payload["did_document"]["id"] == agent.did


class TestAgentServiceEndpointValidation:
    def test_valid_https(self):
        agent = Agent.create(service_endpoint="https://example.com/pact")
        assert agent.service_endpoint == "https://example.com/pact"

    def test_valid_http(self):
        agent = Agent.create(service_endpoint="http://localhost:8080/pact")
        assert agent.service_endpoint == "http://localhost:8080/pact"

    def test_invalid_scheme(self):
        import pytest
        with pytest.raises(ValueError, match="HTTP"):
            Agent.create(service_endpoint="ftp://example.com/pact")

    def test_setter_validates(self):
        import pytest
        agent = Agent.create()
        with pytest.raises(ValueError, match="HTTP"):
            agent.service_endpoint = "javascript:alert(1)"


class TestAgentRepr:
    def test_with_name(self):
        agent = Agent.create(name="Wren")
        r = repr(agent)
        assert "Wren" in r
        assert agent.did in r

    def test_without_name(self):
        agent = Agent.create()
        r = repr(agent)
        assert agent.did in r
