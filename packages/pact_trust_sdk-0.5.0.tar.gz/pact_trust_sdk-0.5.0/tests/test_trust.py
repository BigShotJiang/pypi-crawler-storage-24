"""Tests for PACT Trust Evaluation."""

from pact.agent import Agent
from pact.attestation import Attestation
from pact.mandate import Mandate
from pact.trust import TrustEvaluator


class TestTrustEvaluator:
    def setup_method(self):
        self.evaluator = TrustEvaluator()
        self.a1 = Agent.create()
        self.a2 = Agent.create()

    def _make_attestation(self, outcome="success", itype="task_completion", metrics=None):
        return Attestation.create(
            attestor_did=self.a1.did,
            subject_did=self.a2.did,
            interaction_type=itype,
            outcome=outcome,
            metrics=metrics,
        ).sign(self.a1.key_pair)

    def test_no_attestations(self):
        score = self.evaluator.evaluate([])
        assert 0.0 <= score <= 1.0
        # Baseline for unknown agent
        assert score == 0.3

    def test_all_success(self):
        atts = [self._make_attestation("success") for _ in range(5)]
        score = self.evaluator.evaluate(atts)
        assert score > 0.5

    def test_all_failure(self):
        atts = [self._make_attestation("failure") for _ in range(5)]
        score = self.evaluator.evaluate(atts)
        assert score < 0.3

    def test_mixed(self):
        atts = [
            self._make_attestation("success"),
            self._make_attestation("success"),
            self._make_attestation("failure"),
        ]
        score = self.evaluator.evaluate(atts)
        all_success = self.evaluator.evaluate([self._make_attestation("success") for _ in range(3)])
        assert score < all_success

    def test_with_metrics(self):
        # Use partial outcome so scores don't hit the 1.0 ceiling
        atts_no_metrics = [self._make_attestation("partial") for _ in range(3)]
        atts_with_metrics = [
            self._make_attestation("partial", metrics={"accuracy": 0.95, "response_time_ms": 500})
            for _ in range(3)
        ]

        score_no = self.evaluator.evaluate(atts_no_metrics)
        score_with = self.evaluator.evaluate(atts_with_metrics)
        assert score_with > score_no

    def test_mandate_bonus(self):
        # Use partial so scores don't hit the 1.0 ceiling
        atts = [self._make_attestation("partial") for _ in range(3)]

        human = Agent.create()
        mandate = Mandate.issue(
            issuer=human.did,
            subject=self.a2.did,
            scope=["read"],
        ).sign(human.key_pair)

        score_without = self.evaluator.evaluate(atts)
        score_with = self.evaluator.evaluate(atts, [mandate])
        assert score_with > score_without

    def test_confidence_scaling(self):
        # 1 attestation should have less impact than 5
        one = self.evaluator.evaluate([self._make_attestation("success")])
        five = self.evaluator.evaluate([self._make_attestation("success") for _ in range(5)])
        # More attestations should give higher confidence and score for all-success
        assert five >= one

    def test_score_bounds(self):
        # Score should always be [0, 1]
        for outcome in ["success", "failure", "partial"]:
            atts = [self._make_attestation(outcome) for _ in range(10)]
            score = self.evaluator.evaluate(atts)
            assert 0.0 <= score <= 1.0

    def test_different_interaction_types(self):
        commitment = self._make_attestation("success", itype="commitment_honored")
        availability = self._make_attestation("success", itype="availability")

        score_commit = self.evaluator.evaluate([commitment, commitment, commitment])
        score_avail = self.evaluator.evaluate([availability, availability, availability])

        # commitment_honored has higher weight
        assert score_commit >= score_avail


class TestTrustDetailed:
    def test_detailed_breakdown(self):
        evaluator = TrustEvaluator()
        a1 = Agent.create()
        a2 = Agent.create()

        atts = []
        for itype, outcome in [
            ("task_completion", "success"),
            ("task_completion", "failure"),
            ("information_quality", "success"),
        ]:
            atts.append(
                Attestation.create(
                    attestor_did=a1.did,
                    subject_did=a2.did,
                    interaction_type=itype,
                    outcome=outcome,
                ).sign(a1.key_pair)
            )

        result = evaluator.evaluate_detailed(atts)
        assert "score" in result
        assert result["attestation_count"] == 3
        assert "task_completion" in result["breakdown_by_type"]
        assert result["breakdown_by_type"]["task_completion"]["success"] == 1
        assert result["breakdown_by_type"]["task_completion"]["failure"] == 1
