"""Tests for PACT cryptographic operations."""

from pact.crypto import (
    KeyPair,
    base58_decode,
    base58_encode,
    canonical_json,
    generate_nonce,
    multibase_decode,
    multibase_encode,
    multikey_to_public_key,
    public_key_to_multikey,
    sign_json,
    verify_signature,
    verify_signed_json,
)


class TestBase58:
    def test_roundtrip(self):
        data = b"hello world"
        encoded = base58_encode(data)
        decoded = base58_decode(encoded)
        assert decoded == data

    def test_leading_zeros(self):
        data = b"\x00\x00\x01"
        encoded = base58_encode(data)
        decoded = base58_decode(encoded)
        assert decoded == data

    def test_empty(self):
        assert base58_encode(b"") == ""
        assert base58_decode("") == b""


class TestMultibase:
    def test_encode_prefix(self):
        encoded = multibase_encode(b"test")
        assert encoded.startswith("z")

    def test_roundtrip(self):
        data = b"cryptographic data"
        encoded = multibase_encode(data)
        decoded = multibase_decode(encoded)
        assert decoded == data

    def test_invalid_prefix(self):
        import pytest
        with pytest.raises(ValueError):
            multibase_decode("Xinvalid")

    def test_empty_string(self):
        import pytest
        with pytest.raises(ValueError, match="at least one character"):
            multibase_decode("")

    def test_prefix_only(self):
        import pytest
        with pytest.raises(ValueError, match="at least one character"):
            multibase_decode("z")


class TestKeyPair:
    def test_generate(self):
        kp = KeyPair.generate()
        assert len(kp.public_bytes) == 32
        assert len(kp.private_bytes) == 32

    def test_from_seed(self):
        seed = b"\x01" * 32
        kp1 = KeyPair.from_seed(seed)
        kp2 = KeyPair.from_seed(seed)
        assert kp1.public_bytes == kp2.public_bytes

    def test_sign_verify(self):
        kp = KeyPair.generate()
        message = b"hello pact"
        signature = kp.sign(message)
        assert len(signature) == 64
        assert kp.verify(message, signature)

    def test_verify_wrong_message(self):
        kp = KeyPair.generate()
        signature = kp.sign(b"original")
        assert not kp.verify(b"tampered", signature)

    def test_verify_wrong_key(self):
        kp1 = KeyPair.generate()
        kp2 = KeyPair.generate()
        signature = kp1.sign(b"message")
        assert not kp2.verify(b"message", signature)

    def test_multikey(self):
        kp = KeyPair.generate()
        mk = kp.multikey
        assert mk.startswith("z")
        recovered = multikey_to_public_key(mk)
        assert recovered == kp.public_bytes


class TestMultikey:
    def test_roundtrip(self):
        kp = KeyPair.generate()
        mk = public_key_to_multikey(kp.public_bytes)
        recovered = multikey_to_public_key(mk)
        assert recovered == kp.public_bytes

    def test_invalid_prefix(self):
        import pytest
        # Encode with wrong prefix
        bad = multibase_encode(b"\x00\x00" + b"\x01" * 32)
        with pytest.raises(ValueError):
            multikey_to_public_key(bad)


class TestVerifySignature:
    def test_valid(self):
        kp = KeyPair.generate()
        msg = b"test message"
        sig = kp.sign(msg)
        assert verify_signature(kp.public_bytes, msg, sig)

    def test_invalid(self):
        kp = KeyPair.generate()
        msg = b"test message"
        sig = kp.sign(msg)
        assert not verify_signature(kp.public_bytes, b"wrong", sig)


class TestCanonicalJson:
    def test_sorted_keys(self):
        result = canonical_json({"b": 1, "a": 2})
        assert result == b'{"a":2,"b":1}'

    def test_no_whitespace(self):
        result = canonical_json({"key": "value"})
        assert b" " not in result

    def test_deterministic(self):
        obj = {"z": 1, "a": 2, "m": [3, 4]}
        assert canonical_json(obj) == canonical_json(obj)

    def test_rejects_nan(self):
        import pytest
        with pytest.raises(ValueError):
            canonical_json({"value": float("nan")})

    def test_rejects_infinity(self):
        import pytest
        with pytest.raises(ValueError):
            canonical_json({"value": float("inf")})

    def test_unicode_nfc_normalization(self):
        # e-acute: composed (NFC) vs decomposed (NFD)
        obj_nfc = {"key": "\u00e9"}  # composed
        obj_nfd = {"key": "e\u0301"}  # decomposed
        assert canonical_json(obj_nfc) == canonical_json(obj_nfd)


class TestNonce:
    def test_length(self):
        nonce = generate_nonce(16)
        assert len(nonce) == 32  # hex encoding doubles length

    def test_unique(self):
        n1 = generate_nonce()
        n2 = generate_nonce()
        assert n1 != n2


class TestSignJson:
    def test_sign_and_verify(self):
        kp = KeyPair.generate()
        payload = {"action": "test", "value": 42}
        signed = sign_json(kp, payload)

        assert "proof" in signed
        assert signed["proof"]["type"] == "Ed25519Signature2020"
        assert verify_signed_json(kp.public_bytes, signed)

    def test_tampered_payload(self):
        kp = KeyPair.generate()
        payload = {"action": "test"}
        signed = sign_json(kp, payload)
        signed["action"] = "tampered"
        assert not verify_signed_json(kp.public_bytes, signed)

    def test_wrong_key(self):
        kp1 = KeyPair.generate()
        kp2 = KeyPair.generate()
        signed = sign_json(kp1, {"data": "value"})
        assert not verify_signed_json(kp2.public_bytes, signed)
