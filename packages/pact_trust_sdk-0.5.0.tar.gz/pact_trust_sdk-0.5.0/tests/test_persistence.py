"""Tests for the PACT encrypted persistence layer."""

from __future__ import annotations

import json
import os
import struct
from pathlib import Path

import pytest

from pact.agent import Agent
from pact.mandate import Mandate
from pact.pact import Pact
from pact.persistence import (
    FORMAT_VERSION,
    HEADER_FORMAT,
    MAGIC,
    SCHEMA_VERSION,
    PACTStore,
    PACTStoreError,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_store_dir(tmp_path: Path) -> str:
    """Return a temp directory path for the store."""
    return str(tmp_path / "pact-store")


@pytest.fixture
def two_agents() -> tuple[Agent, Agent]:
    """Create two fresh agents."""
    alice = Agent.create(name="alice")
    bob = Agent.create(name="bob")
    return alice, bob


def _build_state(
    alice: Agent, bob: Agent
) -> tuple[dict[str, Agent], dict[str, Mandate], dict[str, Pact]]:
    """Build a realistic state with agents, mandate, attestation, and pact."""
    agents: dict[str, Agent] = {"alice": alice, "bob": bob}

    # Issue a mandate from alice to bob
    mandate = Mandate.issue(
        issuer=alice.did, subject=bob.did, scope=["trade:read"]
    )
    signed_mandate = mandate.sign(alice.key_pair)
    bob.add_mandate(signed_mandate.to_dict())
    mandates = {"abcd1234": signed_mandate}

    # Create attestation from alice about bob
    att = alice.attest(
        bob.did, interaction_type="task_completion", outcome="success"
    )
    bob.receive_attestation(att)

    # Propose a pact
    pact = Pact.propose(
        proposer_did=alice.did,
        counterparty_did=bob.did,
        terms="Test agreement",
        deliverables=["item1"],
    )
    signed_pact = pact.sign_as_proposer(alice.key_pair)
    pacts = {"efgh5678": signed_pact}

    return agents, mandates, pacts


# ---------------------------------------------------------------------------
# 1. Unencrypted round-trip
# ---------------------------------------------------------------------------


def test_unencrypted_round_trip(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """Save and load state without encryption — all data survives."""
    alice, bob = two_agents
    agents, mandates, pacts = _build_state(alice, bob)

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, mandates, pacts)

    # Verify file exists
    assert (Path(tmp_store_dir) / "state.json").exists()

    # Load into fresh state
    loaded_agents, loaded_mandates, loaded_pacts = store.load()

    assert set(loaded_agents.keys()) == {"alice", "bob"}
    assert loaded_agents["alice"].did == alice.did
    assert loaded_agents["bob"].did == bob.did
    assert set(loaded_mandates.keys()) == {"abcd1234"}
    assert loaded_mandates["abcd1234"].verify()
    assert set(loaded_pacts.keys()) == {"efgh5678"}
    assert loaded_pacts["efgh5678"].terms == "Test agreement"

    # Attestation survived
    assert loaded_agents["bob"].attestation_store.count == 1
    # Mandate on agent survived
    assert len(loaded_agents["bob"].mandates) == 1


# ---------------------------------------------------------------------------
# 2. Encrypted round-trip
# ---------------------------------------------------------------------------


def test_encrypted_round_trip(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """Save and load state with encryption — all data survives."""
    alice, bob = two_agents
    agents, mandates, pacts = _build_state(alice, bob)

    store = PACTStore(store_dir=tmp_store_dir, passphrase="test-secret")
    store.save(agents, mandates, pacts)

    # Verify encrypted file exists (not JSON)
    state_file = Path(tmp_store_dir) / "state.pact"
    assert state_file.exists()
    raw = state_file.read_bytes()
    assert raw[:4] == MAGIC

    # Load back
    loaded_agents, loaded_mandates, loaded_pacts = store.load()

    assert set(loaded_agents.keys()) == {"alice", "bob"}
    assert loaded_agents["alice"].did == alice.did
    assert set(loaded_mandates.keys()) == {"abcd1234"}
    assert loaded_mandates["abcd1234"].verify()
    assert set(loaded_pacts.keys()) == {"efgh5678"}
    assert loaded_agents["bob"].attestation_store.count == 1


# ---------------------------------------------------------------------------
# 3. Wrong passphrase
# ---------------------------------------------------------------------------


def test_wrong_passphrase(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """Loading with wrong passphrase raises PACTStoreError."""
    alice, bob = two_agents
    agents, mandates, pacts = _build_state(alice, bob)

    store = PACTStore(store_dir=tmp_store_dir, passphrase="correct")
    store.save(agents, mandates, pacts)

    wrong_store = PACTStore(store_dir=tmp_store_dir, passphrase="wrong")
    with pytest.raises(PACTStoreError, match="wrong passphrase"):
        wrong_store.load()


# ---------------------------------------------------------------------------
# 4. First run (empty dir)
# ---------------------------------------------------------------------------


def test_first_run_empty_dir(tmp_store_dir: str) -> None:
    """Loading when no state file exists returns empty state."""
    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    agents, mandates, pacts = store.load()
    assert agents == {}
    assert mandates == {}
    assert pacts == {}


# ---------------------------------------------------------------------------
# 5. Corrupt file
# ---------------------------------------------------------------------------


def test_corrupt_encrypted_file(tmp_store_dir: str) -> None:
    """Corrupted ciphertext raises PACTStoreError."""
    store = PACTStore(store_dir=tmp_store_dir, passphrase="test")

    # Write a valid header but garbage ciphertext
    os.makedirs(tmp_store_dir, exist_ok=True)
    import nacl.pwhash

    salt = os.urandom(nacl.pwhash.argon2id.SALTBYTES)
    header = struct.pack(
        HEADER_FORMAT,
        MAGIC,
        FORMAT_VERSION,
        salt,
        nacl.pwhash.argon2id.OPSLIMIT_MODERATE,
        nacl.pwhash.argon2id.MEMLIMIT_MODERATE,
    )
    corrupt = header + b"this is not valid ciphertext at all"
    (Path(tmp_store_dir) / "state.pact").write_bytes(corrupt)

    with pytest.raises(PACTStoreError, match="wrong passphrase|corrupted"):
        store.load()


# ---------------------------------------------------------------------------
# 6. Truncated binary header
# ---------------------------------------------------------------------------


def test_truncated_header(tmp_store_dir: str) -> None:
    """File shorter than header raises PACTStoreError."""
    store = PACTStore(store_dir=tmp_store_dir, passphrase="test")

    os.makedirs(tmp_store_dir, exist_ok=True)
    (Path(tmp_store_dir) / "state.pact").write_bytes(b"PAC")  # Too short

    with pytest.raises(PACTStoreError, match="truncated"):
        store.load()


# ---------------------------------------------------------------------------
# 7. Atomic write (no temp files remain)
# ---------------------------------------------------------------------------


def test_no_temp_files_after_save(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """After save, no .tmp files remain in the directory."""
    alice, bob = two_agents
    agents = {"alice": alice, "bob": bob}

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, {}, {})

    tmp_files = list(Path(tmp_store_dir).glob("*.tmp.*"))
    assert tmp_files == []


# ---------------------------------------------------------------------------
# 8. File permissions
# ---------------------------------------------------------------------------


def test_file_permissions(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """Directory is 0o700, state file is 0o600."""
    alice, bob = two_agents
    agents = {"alice": alice, "bob": bob}

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, {}, {})

    dir_stat = os.stat(tmp_store_dir)
    assert oct(dir_stat.st_mode & 0o777) == oct(0o700)

    file_stat = os.stat(Path(tmp_store_dir) / "state.json")
    assert oct(file_stat.st_mode & 0o777) == oct(0o600)


# ---------------------------------------------------------------------------
# 9. Lock contention
# ---------------------------------------------------------------------------


def test_lock_contention(tmp_store_dir: str) -> None:
    """Second lock acquisition raises PACTStoreError."""
    store1 = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store1.acquire_lock()

    store2 = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    with pytest.raises(PACTStoreError, match="Another PACT instance"):
        store2.acquire_lock()

    store1.release_lock()


# ---------------------------------------------------------------------------
# 10. Schema version forward-compat
# ---------------------------------------------------------------------------


def test_schema_version_too_new(tmp_store_dir: str) -> None:
    """Schema version newer than supported raises PACTStoreError."""
    os.makedirs(tmp_store_dir, exist_ok=True)
    state = {"schema_version": 999, "agents": {}, "mandates": {}, "pacts": {}}
    (Path(tmp_store_dir) / "state.json").write_text(json.dumps(state))

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    with pytest.raises(PACTStoreError, match="newer than supported"):
        store.load()


# ---------------------------------------------------------------------------
# 11. Attestation signature integrity on load
# ---------------------------------------------------------------------------


def test_attestation_integrity_on_load(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """Attestations with valid signatures survive load; tampered ones are skipped."""
    alice, bob = two_agents
    agents, mandates, pacts = _build_state(alice, bob)

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, mandates, pacts)

    # Tamper with the attestation in the JSON
    state_file = Path(tmp_store_dir) / "state.json"
    data = json.loads(state_file.read_text())
    bob_data = data["agents"]["bob"]
    if bob_data["attestations"]:
        # Corrupt the proof value
        bob_data["attestations"][0]["proof"]["proofValue"] = "zINVALID"
    state_file.write_text(json.dumps(data))

    loaded_agents, _, _ = store.load()
    # Tampered attestation should be skipped
    assert loaded_agents["bob"].attestation_store.count == 0


# ---------------------------------------------------------------------------
# 12. Agent DID consistency check
# ---------------------------------------------------------------------------


def test_agent_did_consistency(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """Agent DIDs match between agent objects and their reconstructed keys."""
    alice, bob = two_agents
    agents, mandates, pacts = _build_state(alice, bob)

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, mandates, pacts)
    loaded_agents, loaded_mandates, _ = store.load()

    # The mandate's issuer DID should match alice's DID
    m = loaded_mandates["abcd1234"]
    assert m.issuer == loaded_agents["alice"].did
    assert m.subject == loaded_agents["bob"].did


# ---------------------------------------------------------------------------
# 13. Multiple save cycles
# ---------------------------------------------------------------------------


def test_multiple_save_cycles(tmp_store_dir: str) -> None:
    """Create → save → create more → save → load shows all state."""
    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)

    # Cycle 1
    alice = Agent.create(name="alice")
    agents: dict[str, Agent] = {"alice": alice}
    store.save(agents, {}, {})

    # Cycle 2
    bob = Agent.create(name="bob")
    agents["bob"] = bob
    store.save(agents, {}, {})

    # Load
    loaded_agents, _, _ = store.load()
    assert set(loaded_agents.keys()) == {"alice", "bob"}
    assert loaded_agents["alice"].did == alice.did
    assert loaded_agents["bob"].did == bob.did


# ---------------------------------------------------------------------------
# 14. Empty state round-trip
# ---------------------------------------------------------------------------


def test_empty_state_round_trip(tmp_store_dir: str) -> None:
    """Saving and loading empty state works."""
    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save({}, {}, {})

    agents, mandates, pacts = store.load()
    assert agents == {}
    assert mandates == {}
    assert pacts == {}


# ---------------------------------------------------------------------------
# 15. Invalid magic bytes
# ---------------------------------------------------------------------------


def test_invalid_magic_bytes(tmp_store_dir: str) -> None:
    """File with wrong magic bytes raises PACTStoreError."""
    os.makedirs(tmp_store_dir, exist_ok=True)
    # Write enough bytes for header but wrong magic
    bad = b"XACT" + b"\x01" + (b"\x00" * 24)
    (Path(tmp_store_dir) / "state.pact").write_bytes(bad)

    store = PACTStore(store_dir=tmp_store_dir, passphrase="test")
    with pytest.raises(PACTStoreError, match="invalid magic"):
        store.load()


# ---------------------------------------------------------------------------
# 16. Format version too new
# ---------------------------------------------------------------------------


def test_format_version_too_new(tmp_store_dir: str) -> None:
    """File with future format version raises PACTStoreError."""
    os.makedirs(tmp_store_dir, exist_ok=True)
    header = struct.pack(
        HEADER_FORMAT,
        MAGIC,
        0xFF,  # Future version
        b"\x00" * 16,
        3,
        268435456,
    )
    (Path(tmp_store_dir) / "state.pact").write_bytes(header + b"data")

    store = PACTStore(store_dir=tmp_store_dir, passphrase="test")
    with pytest.raises(PACTStoreError, match="newer than supported"):
        store.load()


# ---------------------------------------------------------------------------
# 17. Encrypt required without passphrase
# ---------------------------------------------------------------------------


def test_encrypt_without_passphrase_raises(tmp_store_dir: str) -> None:
    """Creating a store with encrypt=True but no passphrase raises."""
    with pytest.raises(PACTStoreError, match="no passphrase"):
        PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=True)


# ---------------------------------------------------------------------------
# 18. Pact lifecycle survives round-trip
# ---------------------------------------------------------------------------


def test_pact_accept_survives_round_trip(tmp_store_dir: str) -> None:
    """An accepted pact maintains its status through save/load."""
    alice = Agent.create(name="alice")
    bob = Agent.create(name="bob")

    pact = Pact.propose(
        proposer_did=alice.did,
        counterparty_did=bob.did,
        terms="Accepted pact",
        deliverables=["d1"],
    )
    signed = pact.sign_as_proposer(alice.key_pair)
    accepted = signed.accept(bob.key_pair)

    agents = {"alice": alice, "bob": bob}
    pacts = {"pact0001": accepted}

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, {}, pacts)

    _, _, loaded_pacts = store.load()
    p = loaded_pacts["pact0001"]
    assert p.status.value == "active"
    assert p.verify_both()


# ---------------------------------------------------------------------------
# 19. verify_on_load path (T-5)
# ---------------------------------------------------------------------------


def test_verify_on_load(tmp_store_dir: str, two_agents: tuple[Agent, Agent]) -> None:
    """verify_on_load=True re-verifies mandate/pact signatures without error."""
    alice, bob = two_agents
    agents, mandates, pacts = _build_state(alice, bob)

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    store.save(agents, mandates, pacts)

    verify_store = PACTStore(
        store_dir=tmp_store_dir, passphrase=None, encrypt=False, verify_on_load=True
    )
    loaded_agents, loaded_mandates, loaded_pacts = verify_store.load()
    assert loaded_mandates["abcd1234"].verify()
    assert loaded_pacts["efgh5678"].verify_proposer()


# ---------------------------------------------------------------------------
# 20. Save overwrite replaces state completely (T-8)
# ---------------------------------------------------------------------------


def test_save_overwrite_replaces_state(tmp_store_dir: str) -> None:
    """A save with fewer agents correctly overwrites (not merges) previous state."""
    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)

    alice = Agent.create(name="alice")
    bob = Agent.create(name="bob")
    store.save({"alice": alice, "bob": bob}, {}, {})

    # Save again with only alice
    store.save({"alice": alice}, {}, {})

    loaded_agents, _, _ = store.load()
    assert set(loaded_agents.keys()) == {"alice"}
    assert "bob" not in loaded_agents


# ---------------------------------------------------------------------------
# 21. Auto-save failure adds warning to result (T-1)
# ---------------------------------------------------------------------------


def test_auto_save_failure_warning() -> None:
    """When auto-save fails, the result dict gets a persistence warning."""
    from unittest.mock import MagicMock, patch

    from pact import mcp as mcp_module

    # Backup originals
    orig_store = mcp_module._store
    orig_agents = mcp_module._agents

    try:
        mock_store = MagicMock()
        mock_store.save.side_effect = OSError("disk full")
        mcp_module._store = mock_store
        mcp_module._agents = {}

        # Call create_agent directly (bypasses MCP transport)
        result = mcp_module.create_agent("test_agent")
        assert "_persistence_warning" in result
        assert "failed to persist" in result["_persistence_warning"].lower()
    finally:
        mcp_module._store = orig_store
        mcp_module._agents = orig_agents


# ---------------------------------------------------------------------------
# 22. Max file size check
# ---------------------------------------------------------------------------


def test_max_file_size_rejected(tmp_store_dir: str) -> None:
    """State file exceeding max size raises PACTStoreError."""
    from pact.persistence import MAX_STATE_FILE_SIZE

    os.makedirs(tmp_store_dir, exist_ok=True)
    state_file = Path(tmp_store_dir) / "state.json"
    # Write a file just over the limit (use sparse if possible, else small marker)
    with open(state_file, "wb") as f:
        f.seek(MAX_STATE_FILE_SIZE + 1)
        f.write(b"\x00")

    store = PACTStore(store_dir=tmp_store_dir, passphrase=None, encrypt=False)
    with pytest.raises(PACTStoreError, match="max"):
        store.load()
