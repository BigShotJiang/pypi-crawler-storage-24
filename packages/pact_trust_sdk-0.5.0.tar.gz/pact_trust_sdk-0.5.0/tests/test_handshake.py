"""Tests for PACT Agent Handshake."""

from pact.agent import Agent
from pact.handshake import (
    HandshakeRequest,
    HandshakeResponse,
    build_handshake_response,
    verify_handshake_response,
)
from pact.crypto import generate_nonce


class TestHandshakeRequest:
    def test_create(self):
        agent = Agent.create()
        req = HandshakeRequest(requester_did=agent.did, challenge=generate_nonce())
        d = req.to_dict()
        assert d["type"] == "PACTHandshakeRequest"
        assert d["requesterDID"] == agent.did

    def test_roundtrip(self):
        agent = Agent.create()
        challenge = generate_nonce()
        req = HandshakeRequest(requester_did=agent.did, challenge=challenge)
        d = req.to_dict()
        restored = HandshakeRequest.from_dict(d)
        assert restored.requester_did == agent.did
        assert restored.challenge == challenge


class TestHandshakeResponse:
    def test_build_response(self):
        agent = Agent.create(name="Responder", service_endpoint="https://test.com/pact")
        challenge = generate_nonce()

        response = build_handshake_response(
            agent.key_pair,
            agent.did_document(),
            challenge,
            mandates=[],
            attestations=[],
        )

        assert response.did_document["id"] == agent.did
        assert response.challenge_proof.startswith("z")
        assert len(response.counter_challenge) > 0

    def test_roundtrip(self):
        agent = Agent.create()
        response = build_handshake_response(
            agent.key_pair, agent.did_document(), generate_nonce(), [], []
        )
        d = response.to_dict()
        restored = HandshakeResponse.from_dict(d)
        assert restored.did_document["id"] == agent.did


class TestHandshakeVerification:
    def test_valid_handshake(self):
        requester = Agent.create(name="Requester")
        responder = Agent.create(name="Responder")

        challenge = generate_nonce()

        # Responder builds response
        response = build_handshake_response(
            responder.key_pair,
            responder.did_document(),
            challenge,
            mandates=[],
            attestations=[],
        )

        # Requester verifies
        result = verify_handshake_response(response, challenge)

        assert result.verified
        assert result.peer_did == responder.did
        assert result.trust_score > 0

    def test_wrong_challenge(self):
        responder = Agent.create()
        real_challenge = generate_nonce()
        fake_challenge = generate_nonce()

        response = build_handshake_response(
            responder.key_pair,
            responder.did_document(),
            real_challenge,
            [], [],
        )

        # Verify with wrong challenge
        result = verify_handshake_response(response, fake_challenge)
        assert not result.verified
        assert result.trust_score == 0.0

    def test_with_attestations(self):
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()

        # a1 attests about a2
        att = a1.attest(a2.did, interaction_type="task_completion", outcome="success")

        challenge = generate_nonce()
        response = build_handshake_response(
            a2.key_pair,
            a2.did_document(),
            challenge,
            mandates=[],
            attestations=[att.to_dict()],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.attestations) == 1

    def test_rejects_attestations_about_wrong_subject(self):
        a1 = Agent.create()
        a2 = Agent.create()
        a3 = Agent.create()

        # a1 attests about a3 (not a2) — should be filtered out
        att = a1.attest(a3.did, interaction_type="task_completion", outcome="success")

        challenge = generate_nonce()
        response = build_handshake_response(
            a2.key_pair,
            a2.did_document(),
            challenge,
            mandates=[],
            attestations=[att.to_dict()],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.attestations) == 0  # filtered: subject != peer

    def test_with_mandates(self):
        from pact.mandate import Mandate

        human = Agent.create(name="Human")
        agent = Agent.create(name="Agent")

        mandate = Mandate.issue(
            issuer=human.did,
            subject=agent.did,
            scope=["trade:read"],
        ).sign(human.key_pair)

        challenge = generate_nonce()
        response = build_handshake_response(
            agent.key_pair,
            agent.did_document(),
            challenge,
            mandates=[mandate.to_dict()],
            attestations=[],
        )

        result = verify_handshake_response(response, challenge)
        assert result.verified
        assert len(result.mandates) == 1
