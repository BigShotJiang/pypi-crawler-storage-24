"""Trust Evaluation — reference algorithm for computing trust from attestations.

This is a REFERENCE implementation. The PACT protocol is verifier-determined:
each agent can compute trust however it wants. This module provides a reasonable
default that agents can use out of the box.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pact.attestation import Attestation
from pact.mandate import Mandate


class TrustEvaluator:
    """Reference trust computation algorithm.

    Computes a [0.0, 1.0] trust score from raw attestations and mandates.
    Agents can subclass this to implement custom trust logic.
    """

    def __init__(
        self,
        *,
        outcome_weights: dict[str, float] | None = None,
        type_weights: dict[str, float] | None = None,
        recency_halflife_days: float = 30.0,
        mandate_bonus: float = 0.1,
        min_attestations_for_confidence: int = 3,
    ) -> None:
        self.outcome_weights = outcome_weights or {
            "success": 1.0,
            "partial": 0.5,
            "failure": -0.5,
        }
        self.type_weights = type_weights or {
            "task_completion": 1.0,
            "commitment_honored": 1.2,
            "information_quality": 0.8,
            "delegation_compliance": 1.0,
            "availability": 0.6,
        }
        self.recency_halflife_days = recency_halflife_days
        self.mandate_bonus = mandate_bonus
        self.min_attestations_for_confidence = min_attestations_for_confidence

    def evaluate(
        self,
        attestations: list[Attestation],
        mandates: list[Mandate] | None = None,
    ) -> float:
        """Compute trust score from attestations and mandates.

        Returns a float in [0.0, 1.0].
        """
        if not attestations:
            # No attestations = unknown agent, baseline trust
            return 0.3 + (self.mandate_bonus if mandates else 0.0)

        total_weight = 0.0
        weighted_score = 0.0

        now = datetime.now(timezone.utc)

        for attestation in attestations:
            # Base score from outcome
            outcome_score = self.outcome_weights.get(attestation.outcome, 0.0)

            # Weight by interaction type importance
            type_weight = self.type_weights.get(attestation.interaction_type, 0.8)

            # Recency decay
            try:
                ts = datetime.fromisoformat(attestation.timestamp.replace("Z", "+00:00"))
                age_days = (now - ts).total_seconds() / 86400
                recency_factor = 2 ** (-age_days / self.recency_halflife_days)
            except (ValueError, AttributeError):
                recency_factor = 0.5

            # Metrics bonus (if available)
            metrics_bonus = self._metrics_bonus(attestation.metrics)

            # Combined weight for this attestation
            weight = type_weight * recency_factor
            score = outcome_score + metrics_bonus

            total_weight += weight
            weighted_score += score * weight

        if total_weight == 0:
            raw_score = 0.0
        else:
            raw_score = weighted_score / total_weight

        # Confidence adjustment — fewer attestations means less certainty
        confidence = min(len(attestations) / self.min_attestations_for_confidence, 1.0)
        baseline = 0.3
        adjusted = baseline + (raw_score - baseline) * confidence

        # Mandate bonus
        if mandates:
            valid_mandates = sum(1 for m in mandates if m.verify() and not m.is_expired())
            adjusted += self.mandate_bonus * min(valid_mandates, 3) / 3

        # Clamp to [0, 1]
        return max(0.0, min(1.0, adjusted))

    def _metrics_bonus(self, metrics: dict[str, Any]) -> float:
        """Extract a bonus score from quantitative metrics."""
        if not metrics:
            return 0.0

        bonus = 0.0
        if "accuracy" in metrics:
            acc = metrics["accuracy"]
            if isinstance(acc, (int, float)):
                # Clamp to valid range [0.0, 1.0]
                acc = max(0.0, min(1.0, float(acc)))
                bonus += (acc - 0.5) * 0.2
        if "response_time_ms" in metrics:
            rt = metrics["response_time_ms"]
            if isinstance(rt, (int, float)):
                # Clamp to non-negative
                rt = max(0.0, float(rt))
                if rt < 1000:
                    bonus += 0.1
                elif rt < 5000:
                    bonus += 0.05

        return bonus

    def evaluate_detailed(
        self,
        attestations: list[Attestation],
        mandates: list[Mandate] | None = None,
    ) -> dict[str, Any]:
        """Compute trust with detailed breakdown."""
        score = self.evaluate(attestations, mandates)

        # Breakdown by type
        type_counts: dict[str, dict[str, int]] = {}
        for a in attestations:
            t = a.interaction_type
            if t not in type_counts:
                type_counts[t] = {"success": 0, "partial": 0, "failure": 0}
            if a.outcome in type_counts[t]:
                type_counts[t][a.outcome] += 1

        return {
            "score": score,
            "attestation_count": len(attestations),
            "mandate_count": len(mandates) if mandates else 0,
            "breakdown_by_type": type_counts,
            "confidence": min(len(attestations) / self.min_attestations_for_confidence, 1.0),
        }
