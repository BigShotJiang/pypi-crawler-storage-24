"""Agent — the primary high-level interface for PACT.

An Agent represents an autonomous AI entity with a cryptographic identity,
the ability to issue and receive credentials, and participate in the PACT protocol.
"""

from __future__ import annotations

from typing import Any

from pact.attestation import Attestation, AttestationStore
from pact.crypto import KeyPair
from pact.did import create_did, create_did_document


class Agent:
    """A PACT agent with cryptographic identity and credential management."""

    def __init__(
        self,
        key_pair: KeyPair,
        *,
        name: str | None = None,
        service_endpoint: str | None = None,
    ) -> None:
        self._key_pair = key_pair
        self._name = name
        self._did = create_did(key_pair)
        if service_endpoint is not None:
            from urllib.parse import urlparse
            parsed = urlparse(service_endpoint)
            if parsed.scheme not in ("https", "http"):
                raise ValueError("Service endpoint must be an HTTP(S) URL")
            if not parsed.netloc:
                raise ValueError("Service endpoint must have a valid hostname")
        self._service_endpoint = service_endpoint
        self._attestation_store = AttestationStore()
        self._mandates: list[dict[str, Any]] = []
        self._pacts: list[dict[str, Any]] = []

    @classmethod
    def create(cls, *, name: str | None = None, service_endpoint: str | None = None) -> Agent:
        """Create a new agent with a fresh identity.

        This is the primary entry point — generating a key pair IS creating an identity.
        """
        key_pair = KeyPair.generate()
        return cls(key_pair, name=name, service_endpoint=service_endpoint)

    @classmethod
    def from_seed(cls, seed: bytes, *, name: str | None = None, service_endpoint: str | None = None) -> Agent:
        """Restore an agent from a deterministic seed."""
        key_pair = KeyPair.from_seed(seed)
        return cls(key_pair, name=name, service_endpoint=service_endpoint)

    @classmethod
    def from_private_key(cls, private_bytes: bytes, *, name: str | None = None, service_endpoint: str | None = None) -> Agent:
        """Restore an agent from a saved private key."""
        key_pair = KeyPair.from_private_bytes(private_bytes)
        return cls(key_pair, name=name, service_endpoint=service_endpoint)

    @property
    def did(self) -> str:
        return self._did

    @property
    def name(self) -> str | None:
        return self._name

    @property
    def key_pair(self) -> KeyPair:
        return self._key_pair

    @property
    def public_key(self) -> bytes:
        return self._key_pair.public_bytes

    @property
    def service_endpoint(self) -> str | None:
        return self._service_endpoint

    @service_endpoint.setter
    def service_endpoint(self, url: str) -> None:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        if parsed.scheme not in ("https", "http"):
            raise ValueError("Service endpoint must be an HTTP(S) URL")
        if not parsed.netloc:
            raise ValueError("Service endpoint must have a valid hostname")
        self._service_endpoint = url

    @property
    def attestation_store(self) -> AttestationStore:
        return self._attestation_store

    @property
    def mandates(self) -> list[dict[str, Any]]:
        return list(self._mandates)

    def did_document(self) -> dict[str, Any]:
        """Generate the agent's DID Document."""
        services = []
        if self._service_endpoint:
            services.append(
                {
                    "id": f"{self._did}#pact",
                    "type": "PACTEndpoint",
                    "serviceEndpoint": self._service_endpoint,
                }
            )

        return create_did_document(
            self._did,
            self._key_pair,
            name=self._name,
            service_endpoints=services,
        )

    def sign(self, message: bytes) -> bytes:
        """Sign arbitrary bytes."""
        return self._key_pair.sign(message)

    def attest(
        self,
        subject_did: str,
        *,
        interaction_type: str,
        outcome: str,
        metrics: dict[str, Any] | None = None,
    ) -> Attestation:
        """Create a trust attestation about another agent."""
        attestation = Attestation.create(
            attestor_did=self._did,
            subject_did=subject_did,
            interaction_type=interaction_type,
            outcome=outcome,
            metrics=metrics,
        )
        signed = attestation.sign(self._key_pair)
        return signed

    def receive_attestation(self, attestation: Attestation) -> None:
        """Store an attestation received about this agent."""
        if attestation.subject_did != self._did:
            raise ValueError("Attestation subject does not match this agent")
        self._attestation_store.add(attestation)

    def add_mandate(self, mandate: dict[str, Any]) -> None:
        """Store a delegation mandate."""
        self._mandates.append(mandate)

    def add_pact(self, pact: dict[str, Any]) -> None:
        """Store a pact agreement."""
        self._pacts.append(pact)

    def get_handshake_payload(self, selected_attestations: list[Attestation] | None = None) -> dict[str, Any]:
        """Build the payload for a handshake response.

        The agent selectively discloses attestations — choosing what to reveal.
        """
        attestations = selected_attestations or self._attestation_store.get_best()
        return {
            "did_document": self.did_document(),
            "mandates": list(self._mandates),
            "attestations": [a.to_dict() for a in attestations],
        }

    def export_private_key(self) -> bytes:
        """Export the private key bytes for persistence."""
        return self._key_pair.private_bytes

    def __repr__(self) -> str:
        name_part = f" name={self._name!r}" if self._name else ""
        return f"Agent(did={self._did!r}{name_part})"
