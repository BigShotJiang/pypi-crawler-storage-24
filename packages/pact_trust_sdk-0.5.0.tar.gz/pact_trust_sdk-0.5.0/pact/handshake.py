"""Agent Handshake — mutual identity verification between agents.

The handshake is an HTTP POST exchange where two agents verify each other's
identity, check delegation mandates, and assess trustworthiness. The protocol
is challenge-response based with Ed25519 signatures.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

# Maximum age for handshake messages (seconds)
HANDSHAKE_MAX_AGE_SECONDS = 300  # 5 minutes

# Maximum number of mandates/attestations accepted in a handshake
MAX_HANDSHAKE_MANDATES = 50
MAX_HANDSHAKE_ATTESTATIONS = 100

from pact.attestation import Attestation
from pact.crypto import (
    KeyPair,
    canonical_json,
    generate_nonce,
    multibase_decode,
    multibase_encode,
    verify_signature,
    _iso_now,
)
from pact.did import did_to_public_key, validate_did
from pact.mandate import Mandate
from pact.trust import TrustEvaluator


class HandshakeRequest:
    """Outgoing handshake request."""

    def __init__(self, requester_did: str, challenge: str, timestamp: str | None = None) -> None:
        self.requester_did = requester_did
        self.challenge = challenge
        self.timestamp = timestamp or _iso_now()

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "PACTHandshakeRequest",
            "requesterDID": self.requester_did,
            "challenge": self.challenge,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HandshakeRequest:
        for field in ("requesterDID", "challenge"):
            if field not in data:
                raise ValueError(f"HandshakeRequest missing required field: {field!r}")
        if len(data["challenge"]) < 32:
            raise ValueError("HandshakeRequest challenge has insufficient entropy")
        return cls(
            requester_did=data["requesterDID"],
            challenge=data["challenge"],
            timestamp=data.get("timestamp"),
        )


class HandshakeResponse:
    """Response to a handshake request."""

    def __init__(
        self,
        did_document: dict[str, Any],
        challenge_proof: str,
        mandates: list[dict[str, Any]],
        attestations: list[dict[str, Any]],
        counter_challenge: str,
        timestamp: str | None = None,
    ) -> None:
        self.did_document = did_document
        self.challenge_proof = challenge_proof
        self.mandates = mandates
        self.attestations = attestations
        self.counter_challenge = counter_challenge
        self.timestamp = timestamp or _iso_now()

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "PACTHandshakeResponse",
            "didDocument": self.did_document,
            "challengeProof": self.challenge_proof,
            "mandates": self.mandates,
            "attestations": self.attestations,
            "counterChallenge": self.counter_challenge,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HandshakeResponse:
        for field in ("didDocument", "challengeProof", "counterChallenge"):
            if field not in data:
                raise ValueError(f"HandshakeResponse missing required field: {field!r}")
        did_doc = data["didDocument"]
        if not isinstance(did_doc, dict) or "id" not in did_doc:
            raise ValueError("HandshakeResponse didDocument must contain an 'id' field")
        import copy
        return cls(
            did_document=copy.deepcopy(did_doc),
            challenge_proof=data["challengeProof"],
            mandates=copy.deepcopy(data.get("mandates", [])),
            attestations=copy.deepcopy(data.get("attestations", [])),
            counter_challenge=data["counterChallenge"],
            timestamp=data.get("timestamp"),
        )


class HandshakeResult:
    """Result of a completed handshake, including trust evaluation."""

    def __init__(
        self,
        peer_did: str,
        peer_document: dict[str, Any],
        verified: bool,
        mandates: list[Mandate],
        attestations: list[Attestation],
        trust_score: float,
    ) -> None:
        self.peer_did = peer_did
        self.peer_document = peer_document
        self.verified = verified
        self.mandates = mandates
        self.attestations = attestations
        self.trust_score = trust_score

    def __repr__(self) -> str:
        return (
            f"HandshakeResult(peer={self.peer_did!r}, "
            f"verified={self.verified}, trust={self.trust_score:.2f})"
        )


def build_handshake_response(
    agent_key_pair: KeyPair,
    agent_did_document: dict[str, Any],
    challenge: str,
    mandates: list[dict[str, Any]],
    attestations: list[dict[str, Any]],
) -> HandshakeResponse:
    """Build a handshake response, proving identity by signing the challenge."""
    # Sign the challenge to prove key ownership
    challenge_bytes = challenge.encode("utf-8")
    signature = agent_key_pair.sign(challenge_bytes)
    challenge_proof = multibase_encode(signature)

    counter_challenge = generate_nonce()

    return HandshakeResponse(
        did_document=agent_did_document,
        challenge_proof=challenge_proof,
        mandates=mandates,
        attestations=attestations,
        counter_challenge=counter_challenge,
    )


def verify_handshake_response(
    response: HandshakeResponse,
    original_challenge: str,
) -> HandshakeResult:
    """Verify a handshake response — check identity, signatures, and compute trust."""
    did_doc = response.did_document
    peer_did = did_doc["id"]

    _fail = HandshakeResult(
        peer_did=peer_did,
        peer_document=did_doc,
        verified=False,
        mandates=[],
        attestations=[],
        trust_score=0.0,
    )

    # Enforce timestamp freshness
    resp_timestamp = response.timestamp
    if resp_timestamp:
        try:
            ts = datetime.fromisoformat(resp_timestamp.replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - ts).total_seconds()
            if abs(age) > HANDSHAKE_MAX_AGE_SECONDS:
                return _fail
        except (ValueError, TypeError):
            return _fail

    # Validate DID document id is consistent
    try:
        validate_did(peer_did)
    except ValueError:
        return _fail

    # Extract public key from DID and verify DID document consistency
    try:
        public_key = did_to_public_key(peer_did)
    except ValueError:
        return _fail

    # Cross-check: if DID document has verificationMethod, ensure key matches
    vm_list = did_doc.get("verificationMethod", [])
    if vm_list:
        try:
            doc_key = vm_list[0].get("publicKeyMultibase", "")
            from pact.crypto import multikey_to_public_key
            doc_pub = multikey_to_public_key(doc_key)
            if doc_pub != public_key:
                return _fail
        except (ValueError, KeyError, IndexError):
            return _fail

    # Verify challenge proof
    challenge_bytes = original_challenge.encode("utf-8")
    try:
        signature = multibase_decode(response.challenge_proof)
        challenge_valid = verify_signature(public_key, challenge_bytes, signature)
    except (ValueError, IndexError):
        challenge_valid = False

    if not challenge_valid:
        return _fail

    # Validate counter-challenge has sufficient entropy
    if len(response.counter_challenge) < 32:
        return _fail

    # Parse and verify mandates (with size limit + subject must match peer)
    mandates = []
    for m_dict in response.mandates[:MAX_HANDSHAKE_MANDATES]:
        try:
            m = Mandate.from_dict(dict(m_dict))
        except (ValueError, KeyError):
            continue
        if m.verify() and not m.is_expired() and m.subject == peer_did:
            mandates.append(m)

    # Parse and verify attestations (with size limit)
    attestations = []
    for a_dict in response.attestations[:MAX_HANDSHAKE_ATTESTATIONS]:
        try:
            a = Attestation.from_dict(dict(a_dict))
        except (ValueError, KeyError):
            continue
        if a.verify() and a.subject_did == peer_did:
            attestations.append(a)

    # Compute trust score
    evaluator = TrustEvaluator()
    trust_score = evaluator.evaluate(attestations, mandates)

    return HandshakeResult(
        peer_did=peer_did,
        peer_document=did_doc,
        verified=True,
        mandates=mandates,
        attestations=attestations,
        trust_score=trust_score,
    )


async def perform_handshake(
    agent_key_pair: KeyPair,
    agent_did: str,
    peer_endpoint: str,
    agent_did_document: dict[str, Any] | None = None,
    mandates: list[dict[str, Any]] | None = None,
    attestations: list[dict[str, Any]] | None = None,
    *,
    allow_insecure: bool = False,
) -> HandshakeResult:
    """Perform a full handshake with a remote agent.

    1. Send challenge
    2. Receive response with challenge proof + counter-challenge
    3. Verify response
    4. Send counter-challenge proof
    """
    if not allow_insecure and not peer_endpoint.startswith("https://"):
        raise ValueError(
            "Peer endpoint must use HTTPS. Pass allow_insecure=True for development only."
        )

    # SSRF protection: validate the peer endpoint hostname
    from urllib.parse import urlparse
    parsed = urlparse(peer_endpoint)
    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Peer endpoint URL is missing a hostname")
    from pact.resolver import DIDResolver
    if not DIDResolver._is_safe_domain(hostname):
        raise ValueError(
            f"Peer endpoint hostname '{hostname}' resolves to a private/reserved address"
        )

    challenge = generate_nonce()

    request = HandshakeRequest(requester_did=agent_did, challenge=challenge)

    # Maximum response size (1 MB)
    MAX_RESPONSE_BYTES = 1_000_000

    async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
        # Step 1: Send handshake request
        resp = await client.post(
            f"{peer_endpoint}/pact/handshake",
            json=request.to_dict(),
        )
        resp.raise_for_status()

        # Guard against oversized responses
        content_length = resp.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > MAX_RESPONSE_BYTES:
                    raise ValueError("Handshake response exceeds maximum allowed size")
            except (ValueError, OverflowError):
                raise ValueError("Handshake response has invalid Content-Length header")
        if len(resp.content) > MAX_RESPONSE_BYTES:
            raise ValueError("Handshake response exceeds maximum allowed size")

        try:
            response = HandshakeResponse.from_dict(resp.json())
        except (KeyError, TypeError) as e:
            raise ValueError(f"Malformed handshake response: {e}") from e

        # Step 2: Verify the response
        result = verify_handshake_response(response, challenge)

        # Step 3: Prove our identity with counter-challenge
        if result.verified and agent_did_document:
            counter_proof = build_handshake_response(
                agent_key_pair,
                agent_did_document,
                response.counter_challenge,
                mandates or [],
                attestations or [],
            )

            await client.post(
                f"{peer_endpoint}/pact/handshake/complete",
                json=counter_proof.to_dict(),
            )

    return result
