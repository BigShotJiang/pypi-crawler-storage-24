"""Encrypted file-based persistence for the PACT MCP server.

Stores agent identities (Ed25519 keypairs), mandates, pacts, and attestations
to disk with optional XSalsa20-Poly1305 encryption (Argon2id KDF).

File format (encrypted mode):
    [4B]  Magic: b"PACT"
    [1B]  Format version: 0x01
    [16B] Argon2id salt
    [4B]  opslimit (uint32 BE)
    [4B]  memlimit (uint32 BE)
    [NB]  SecretBox ciphertext (nonce prepended by PyNaCl)

Unencrypted mode writes plain JSON to state.json (dev only).
"""

from __future__ import annotations

import fcntl
import json
import logging
import os
import struct
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import nacl.pwhash
import nacl.secret
import nacl.utils

from pact.agent import Agent
from pact.attestation import Attestation
from pact.mandate import Mandate
from pact.pact import Pact

logger = logging.getLogger(__name__)

MAGIC = b"PACT"
FORMAT_VERSION = 0x01
SCHEMA_VERSION = 1

# Header: 4B magic + 1B version + 16B salt + 4B opslimit + 4B memlimit = 29 bytes
HEADER_FORMAT = "!4sB16sII"
HEADER_SIZE = struct.calcsize(HEADER_FORMAT)
MAX_STATE_FILE_SIZE = 100 * 1024 * 1024  # 100 MB


class PACTStoreError(Exception):
    """Raised for persistence-layer errors."""


class PACTStore:
    """Encrypted file-based persistence for PACT state.

    Usage:
        store = PACTStore(store_dir="~/.pact", passphrase="secret")
        agents, mandates, pacts = store.load()
        # ... mutate state ...
        store.save(agents, mandates, pacts)
    """

    def __init__(
        self,
        *,
        store_dir: str = "~/.pact",
        passphrase: str | None = None,
        encrypt: bool = True,
        verify_on_load: bool = False,
    ) -> None:
        self._dir = Path(store_dir).expanduser()
        self._encrypt = encrypt and passphrase is not None
        self._passphrase = passphrase
        self._verify_on_load = verify_on_load
        self._lock_fd: int | None = None

        if encrypt and passphrase is None:
            raise PACTStoreError(
                "Encryption enabled but no passphrase provided. "
                "Set PACT_PASSPHRASE or use PACT_ENCRYPT=false."
            )

    @property
    def _state_file(self) -> Path:
        if self._encrypt:
            return self._dir / "state.pact"
        return self._dir / "state.json"

    @property
    def _lock_file(self) -> Path:
        return self._dir / ".lock"

    # ------------------------------------------------------------------
    # Directory & locking
    # ------------------------------------------------------------------

    def _ensure_dir(self) -> None:
        """Create state directory with owner-only permissions."""
        self._dir.mkdir(parents=True, exist_ok=True)
        os.chmod(self._dir, 0o700)

    def acquire_lock(self) -> None:
        """Acquire an advisory file lock (held for process lifetime)."""
        self._ensure_dir()
        fd = os.open(str(self._lock_file), os.O_CREAT | os.O_RDWR, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(fd)
            raise PACTStoreError(
                "Another PACT instance is running (lock held). "
                "Stop the other instance or remove ~/.pact/.lock"
            )
        self._lock_fd = fd

    def release_lock(self) -> None:
        """Release the advisory file lock."""
        if self._lock_fd is not None:
            try:
                fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
                os.close(self._lock_fd)
            except OSError:
                pass
            self._lock_fd = None

    # ------------------------------------------------------------------
    # Encryption
    # ------------------------------------------------------------------

    def _derive_key(
        self,
        salt: bytes,
        opslimit: int = nacl.pwhash.argon2id.OPSLIMIT_MODERATE,
        memlimit: int = nacl.pwhash.argon2id.MEMLIMIT_MODERATE,
    ) -> bytes:
        """Derive a 32-byte key from passphrase using Argon2id."""
        if self._passphrase is None:
            raise PACTStoreError("No passphrase available for key derivation.")
        return nacl.pwhash.argon2id.kdf(
            nacl.secret.SecretBox.KEY_SIZE,
            self._passphrase.encode("utf-8"),
            salt,
            opslimit=opslimit,
            memlimit=memlimit,
        )

    def _encrypt_data(self, plaintext: bytes) -> bytes:
        """Encrypt plaintext and return binary blob with header."""
        salt = nacl.utils.random(nacl.pwhash.argon2id.SALTBYTES)
        key = self._derive_key(salt)
        box = nacl.secret.SecretBox(key)
        ciphertext = box.encrypt(plaintext)

        header = struct.pack(
            HEADER_FORMAT,
            MAGIC,
            FORMAT_VERSION,
            salt,
            nacl.pwhash.argon2id.OPSLIMIT_MODERATE,
            nacl.pwhash.argon2id.MEMLIMIT_MODERATE,
        )
        return header + ciphertext

    def _decrypt_data(self, blob: bytes) -> bytes:
        """Decrypt binary blob, returning plaintext."""
        if len(blob) < HEADER_SIZE:
            raise PACTStoreError("State file is truncated (too short for header).")

        magic, version, salt, opslimit, memlimit = struct.unpack(
            HEADER_FORMAT, blob[:HEADER_SIZE]
        )

        if magic != MAGIC:
            raise PACTStoreError("State file has invalid magic bytes (not a PACT file).")
        if version > FORMAT_VERSION:
            raise PACTStoreError(
                f"State file format version {version} is newer than supported ({FORMAT_VERSION}). "
                "Update PACT to read this file."
            )

        # Validate KDF parameters to prevent DoS via tampered file headers
        if opslimit > nacl.pwhash.argon2id.OPSLIMIT_SENSITIVE or opslimit < 1:
            raise PACTStoreError(
                f"State file has invalid opslimit ({opslimit}). File may be corrupted."
            )
        if memlimit > nacl.pwhash.argon2id.MEMLIMIT_SENSITIVE or memlimit < 1:
            raise PACTStoreError(
                f"State file has invalid memlimit ({memlimit}). File may be corrupted."
            )

        key = self._derive_key(salt, opslimit=opslimit, memlimit=memlimit)
        box = nacl.secret.SecretBox(key)
        try:
            return box.decrypt(blob[HEADER_SIZE:])
        except nacl.exceptions.CryptoError:
            raise PACTStoreError(
                "Decryption failed — wrong passphrase or corrupted file. "
                "Check PACT_PASSPHRASE or delete the state file to start fresh."
            )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    @staticmethod
    def _serialize_state(
        agents: dict[str, Agent],
        mandates: dict[str, Mandate],
        pacts: dict[str, Pact],
    ) -> dict[str, Any]:
        """Serialize in-memory state to a JSON-compatible dict."""
        agents_data: dict[str, Any] = {}
        for name, agent in agents.items():
            agents_data[name] = {
                "private_key_hex": agent.export_private_key().hex(),
                "name": agent.name,
                "service_endpoint": agent.service_endpoint,
                "mandates": agent.mandates,  # list[dict]
                "pacts": list(agent._pacts),  # list[dict]
                "attestations": [
                    a.to_dict() for a in agent.attestation_store.get_all()
                ],
            }

        mandates_data = {sid: m.to_dict() for sid, m in mandates.items()}
        pacts_data = {sid: p.to_dict() for sid, p in pacts.items()}

        return {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "agents": agents_data,
            "mandates": mandates_data,
            "pacts": pacts_data,
        }

    @staticmethod
    def _deserialize_state(
        data: dict[str, Any],
        verify_on_load: bool = False,
    ) -> tuple[dict[str, Agent], dict[str, Mandate], dict[str, Pact]]:
        """Reconstruct in-memory state from deserialized JSON."""
        sv = data.get("schema_version", 0)
        if sv > SCHEMA_VERSION:
            raise PACTStoreError(
                f"State schema version {sv} is newer than supported ({SCHEMA_VERSION}). "
                "Update PACT to read this file."
            )

        agents: dict[str, Agent] = {}
        mandates: dict[str, Mandate] = {}
        pacts: dict[str, Pact] = {}

        # 1. Reconstruct agents
        for name, agent_data in data.get("agents", {}).items():
            private_key = bytes.fromhex(agent_data["private_key_hex"])
            agent = Agent.from_private_key(
                private_key,
                name=agent_data.get("name"),
                service_endpoint=agent_data.get("service_endpoint"),
            )

            # Replay mandates
            for mandate_dict in agent_data.get("mandates", []):
                agent.add_mandate(mandate_dict)

            # Replay pacts
            for pact_dict in agent_data.get("pacts", []):
                agent.add_pact(pact_dict)

            # Replay attestations (re-verifies signatures via AttestationStore.add)
            for att_dict in agent_data.get("attestations", []):
                try:
                    att = Attestation.from_dict(att_dict)
                    agent.receive_attestation(att)
                except (ValueError, KeyError) as e:
                    logger.warning("Skipping invalid attestation on load: %s", e)

            agents[name] = agent

        # 2. Reconstruct top-level mandates
        for sid, mandate_dict in data.get("mandates", {}).items():
            m = Mandate.from_dict(mandate_dict)
            if verify_on_load and not m.verify():
                logger.warning("Mandate %s failed signature verification on load", sid)
            mandates[sid] = m

        # 3. Reconstruct top-level pacts
        for sid, pact_dict in data.get("pacts", {}).items():
            p = Pact.from_dict(pact_dict)
            if verify_on_load:
                if not p.verify_proposer():
                    logger.warning("Pact %s failed proposer verification on load", sid)
            pacts[sid] = p

        # 4. Post-load integrity: verify agent DIDs match mandates/pacts
        agent_dids = {a.did for a in agents.values()}
        for sid, m in mandates.items():
            if m.issuer not in agent_dids and m.subject not in agent_dids:
                logger.warning(
                    "Mandate %s references unknown DIDs (orphaned)", sid
                )
        for sid, p in pacts.items():
            if p.proposer not in agent_dids and p.counterparty not in agent_dids:
                logger.warning(
                    "Pact %s references unknown DIDs (orphaned)", sid
                )

        return agents, mandates, pacts

    # ------------------------------------------------------------------
    # Load / Save
    # ------------------------------------------------------------------

    def load(
        self,
    ) -> tuple[dict[str, Agent], dict[str, Mandate], dict[str, Pact]]:
        """Load state from disk. Returns empty state if no file exists."""
        if not self._state_file.exists():
            logger.info("No state file found — starting with empty state.")
            return {}, {}, {}

        file_size = self._state_file.stat().st_size
        if file_size > MAX_STATE_FILE_SIZE:
            raise PACTStoreError(
                f"State file is {file_size} bytes (max {MAX_STATE_FILE_SIZE}). "
                "File may be corrupted or tampered with."
            )

        raw = self._state_file.read_bytes()
        if not raw:
            logger.info("Empty state file — starting with empty state.")
            return {}, {}, {}

        if self._encrypt:
            plaintext = self._decrypt_data(raw)
        else:
            plaintext = raw

        try:
            data = json.loads(plaintext)
        except json.JSONDecodeError as e:
            raise PACTStoreError(f"State file contains invalid JSON: {e}")

        return self._deserialize_state(data, verify_on_load=self._verify_on_load)

    def save(
        self,
        agents: dict[str, Agent],
        mandates: dict[str, Mandate],
        pacts: dict[str, Pact],
    ) -> None:
        """Atomically save state to disk."""
        if not self._encrypt:
            logger.warning(
                "Saving state UNENCRYPTED — private keys are in plaintext! "
                "Set PACT_PASSPHRASE for production use."
            )
        self._ensure_dir()

        # Clean up orphaned temp files from previous crashes
        for tmp in self._dir.glob("state.pact.tmp.*"):
            try:
                tmp.unlink()
            except OSError:
                pass
        for tmp in self._dir.glob("state.json.tmp.*"):
            try:
                tmp.unlink()
            except OSError:
                pass

        state = self._serialize_state(agents, mandates, pacts)
        plaintext = json.dumps(state, separators=(",", ":")).encode("utf-8")

        if self._encrypt:
            payload = self._encrypt_data(plaintext)
        else:
            # Pretty-print for dev readability
            payload = json.dumps(state, indent=2).encode("utf-8")

        # Atomic write: temp file → os.replace()
        fd, tmp_path = tempfile.mkstemp(
            prefix=self._state_file.name + ".tmp.",
            dir=str(self._dir),
        )
        closed = False
        try:
            os.write(fd, payload)
            os.fsync(fd)
            os.fchmod(fd, 0o600)
            os.close(fd)
            closed = True
            os.replace(tmp_path, str(self._state_file))
        except BaseException:
            if not closed:
                os.close(fd)
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
