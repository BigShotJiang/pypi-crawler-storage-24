"""Ed25519 cryptographic operations for PACT.

Provides key generation, signing, verification, and multibase/multicodec encoding
compatible with W3C DID standards.
"""

from __future__ import annotations

import os
import unicodedata
from typing import Any

import nacl.encoding
import nacl.signing
import nacl.utils

# Multicodec prefix for Ed25519 public key (0xed01)
ED25519_MULTICODEC_PREFIX = b"\xed\x01"

# Base58btc alphabet
BASE58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def base58_encode(data: bytes) -> str:
    """Encode bytes to base58btc string."""
    n = int.from_bytes(data, "big")
    result = bytearray()
    while n > 0:
        n, remainder = divmod(n, 58)
        result.append(BASE58_ALPHABET[remainder])
    # Handle leading zeros
    for byte in data:
        if byte == 0:
            result.append(BASE58_ALPHABET[0])
        else:
            break
    return bytes(reversed(result)).decode("ascii")


def base58_decode(s: str) -> bytes:
    """Decode base58btc string to bytes."""
    n = 0
    for char in s:
        try:
            idx = BASE58_ALPHABET.index(char.encode("ascii"))
        except (ValueError, UnicodeEncodeError):
            raise ValueError(f"Invalid base58 character: {char!r}")
        n = n * 58 + idx
    # Calculate byte length
    byte_length = (n.bit_length() + 7) // 8
    result = n.to_bytes(byte_length, "big") if byte_length > 0 else b""
    # Handle leading '1's (zeros in base58)
    leading_zeros = 0
    for char in s:
        if char == "1":
            leading_zeros += 1
        else:
            break
    return b"\x00" * leading_zeros + result


def multibase_encode(data: bytes) -> str:
    """Encode bytes with multibase prefix (z = base58btc)."""
    return "z" + base58_encode(data)


def multibase_decode(s: str) -> bytes:
    """Decode multibase-encoded string."""
    if not s or len(s) < 2:
        raise ValueError("Multibase string must have a prefix and at least one character of data")
    if not s.startswith("z"):
        raise ValueError(f"Unsupported multibase prefix: {s[0]!r}")
    return base58_decode(s[1:])


def public_key_to_multikey(public_key: bytes) -> str:
    """Encode Ed25519 public key as multicodec + multibase string.

    This produces the identifier portion of a did:pact DID.
    Format: z + base58btc(0xed01 + public_key_bytes)
    """
    return multibase_encode(ED25519_MULTICODEC_PREFIX + public_key)


def multikey_to_public_key(multikey: str) -> bytes:
    """Decode multikey string back to raw Ed25519 public key bytes."""
    data = multibase_decode(multikey)
    if not data.startswith(ED25519_MULTICODEC_PREFIX):
        raise ValueError("Invalid multicodec prefix for Ed25519 key")
    key = data[len(ED25519_MULTICODEC_PREFIX) :]
    if len(key) != 32:
        raise ValueError(f"Invalid Ed25519 public key length: expected 32 bytes, got {len(key)}")
    return key


class KeyPair:
    """Ed25519 key pair.

    Private key material is stored internally and never exposed in repr/str.
    Use export_private_bytes() for explicit, intentional export only.
    """

    __slots__ = ("_signing_key", "_verify_key")

    def __init__(self, signing_key: nacl.signing.SigningKey, verify_key: nacl.signing.VerifyKey) -> None:
        object.__setattr__(self, "_signing_key", signing_key)
        object.__setattr__(self, "_verify_key", verify_key)

    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError("KeyPair is immutable")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("KeyPair is immutable")

    @classmethod
    def generate(cls) -> KeyPair:
        """Generate a new random Ed25519 key pair."""
        sk = nacl.signing.SigningKey.generate()
        return cls(signing_key=sk, verify_key=sk.verify_key)

    @classmethod
    def from_seed(cls, seed: bytes) -> KeyPair:
        """Create key pair from a 32-byte seed."""
        if len(seed) != 32:
            raise ValueError("Seed must be exactly 32 bytes")
        sk = nacl.signing.SigningKey(seed)
        return cls(signing_key=sk, verify_key=sk.verify_key)

    @classmethod
    def from_private_bytes(cls, private_bytes: bytes) -> KeyPair:
        """Restore key pair from raw private key bytes (seed)."""
        return cls.from_seed(private_bytes)

    @property
    def public_bytes(self) -> bytes:
        return bytes(self._verify_key)

    @property
    def private_bytes(self) -> bytes:
        """Export raw private key bytes. Handle with care."""
        return bytes(self._signing_key)

    @property
    def multikey(self) -> str:
        return public_key_to_multikey(self.public_bytes)

    def sign(self, message: bytes) -> bytes:
        """Sign a message, returning the 64-byte signature."""
        signed = self._signing_key.sign(message)
        return signed.signature

    def verify(self, message: bytes, signature: bytes) -> bool:
        """Verify a signature against a message."""
        return verify_signature(self.public_bytes, message, signature)

    def __repr__(self) -> str:
        return f"KeyPair(public={self.multikey!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, KeyPair):
            return NotImplemented
        return self.public_bytes == other.public_bytes

    def __hash__(self) -> int:
        return hash(self.public_bytes)


def verify_signature(public_key: bytes, message: bytes, signature: bytes) -> bool:
    """Verify an Ed25519 signature.

    Returns True if valid, False otherwise.
    """
    try:
        vk = nacl.signing.VerifyKey(public_key)
        vk.verify(message, signature)
        return True
    except nacl.exceptions.BadSignatureError:
        return False


def generate_nonce(length: int = 32) -> str:
    """Generate a cryptographic random nonce as hex string."""
    if not isinstance(length, int) or length < 1:
        raise ValueError("Nonce length must be a positive integer")
    return os.urandom(length).hex()


def canonical_json(obj: Any) -> bytes:
    """Produce canonical JSON bytes for signing.

    Uses a custom serializer that matches JavaScript's JSON.stringify behavior
    for cross-language signature compatibility. Keys are sorted, no whitespace,
    UTF-8 encoded, Unicode NFC normalized. Rejects NaN/Infinity.
    """
    raw = _stable_stringify(obj)
    normalized = unicodedata.normalize("NFC", raw)
    return normalized.encode("utf-8")


def _format_float_js(value: float) -> str:
    """Format a float to match JavaScript's JSON.stringify / Number.toString().

    ECMAScript Number::toString rules (ECMA-262 7.1.12.1):
    - Let s × 10^(n-k) = value with k minimal significant digits
    - If k ≤ n ≤ 21: digits + zeros (e.g., 1e20 → '100000000000000000000')
    - If 0 < n ≤ 21 and n < k: fixed with decimal point (e.g., 3.14)
    - If -6 < n ≤ 0: '0.' + zeros + digits (e.g., 1e-6 → '0.000001')
    - Otherwise: scientific notation with no zero-padded exponent
    """
    import re

    s = repr(value)

    # For non-scientific repr output, Python and JS produce the same string
    if 'e' not in s and 'E' not in s:
        return s

    # Parse Python's scientific notation: e.g., "1e-07", "1.5e+20", "-3.14e+10"
    match = re.match(r'^(-?)(\d+)\.?(\d*)[eE]([+-]?\d+)$', s)
    if not match:
        return s  # fallback — should not happen

    sign, int_part, frac_part, exp_str = match.groups()
    exp = int(exp_str)
    digits = (int_part + frac_part).rstrip('0') or '0'
    k = len(digits)
    # In Python's repr, scientific notation is always d.ddd × 10^e
    # where int_part is a single digit. So n = exp + 1.
    n = exp + 1

    if k <= n <= 21:
        return sign + digits + '0' * (n - k)
    elif 0 < n <= 21:
        return sign + digits[:n] + '.' + digits[n:]
    elif -6 < n <= 0:
        return sign + '0.' + '0' * (-n) + digits
    else:
        e_val = n - 1
        e_sign = '+' if e_val >= 0 else '-'
        if k == 1:
            return sign + digits + 'e' + e_sign + str(abs(e_val))
        else:
            return sign + digits[0] + '.' + digits[1:] + 'e' + e_sign + str(abs(e_val))


def _stable_stringify(obj: Any) -> str:
    """Stable JSON stringify matching JavaScript's JSON.stringify output."""
    import json
    import math

    if obj is None:
        return "null"
    if isinstance(obj, bool):  # Must check before int (bool is subclass of int)
        return "true" if obj else "false"
    if isinstance(obj, int):
        return str(obj)
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("canonical_json rejects NaN and Infinity")
        # Match JavaScript: whole-number floats format as integers
        if obj == int(obj) and abs(obj) < 2**53:
            return str(int(obj))
        return _format_float_js(obj)
    if isinstance(obj, str):
        return json.dumps(obj, ensure_ascii=False)
    if isinstance(obj, (list, tuple)):
        return "[" + ",".join(_stable_stringify(v) for v in obj) + "]"
    if isinstance(obj, dict):
        pairs = []
        for k in sorted(obj.keys()):
            pairs.append(json.dumps(k, ensure_ascii=False) + ":" + _stable_stringify(obj[k]))
        return "{" + ",".join(pairs) + "}"
    raise TypeError(f"Cannot serialize type: {type(obj).__name__}")


def sign_json(key_pair: KeyPair, payload: dict) -> dict:
    """Sign a JSON payload, returning payload + proof block.

    The proof uses Ed25519Signature2020-style structure.
    """
    payload_bytes = canonical_json(payload)
    signature = key_pair.sign(payload_bytes)

    proof = {
        "type": "Ed25519Signature2020",
        "created": _iso_now(),
        "verificationMethod": f"did:pact:{key_pair.multikey}#key-0",
        "proofPurpose": "assertionMethod",
        "proofValue": multibase_encode(signature),
    }

    return {**payload, "proof": proof}


def verify_signed_json(public_key: bytes, signed_payload: dict) -> bool:
    """Verify a signed JSON payload.

    Extracts proof, reconstructs original payload, verifies signature.
    """
    proof = signed_payload.get("proof")
    if not proof:
        return False

    # Reconstruct original payload (everything except proof)
    payload = {k: v for k, v in signed_payload.items() if k != "proof"}
    payload_bytes = canonical_json(payload)

    signature_multibase = proof.get("proofValue", "")
    try:
        signature = multibase_decode(signature_multibase)
    except (ValueError, IndexError):
        return False

    return verify_signature(public_key, payload_bytes, signature)


def _iso_now() -> str:
    """Current UTC time in ISO 8601 format."""
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
