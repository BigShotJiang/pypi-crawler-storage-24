"""Delegation Mandates — W3C Verifiable Credentials for agent authority.

A Mandate is a signed credential that grants an agent specific permissions
within defined constraints. Mandates can chain (Human -> Agent A -> Agent B)
with scope narrowing at each delegation step.
"""

from __future__ import annotations

import copy
import uuid
from datetime import datetime, timezone, timedelta
from typing import Any

from pact.crypto import KeyPair, canonical_json, multibase_encode, multibase_decode, verify_signature, _iso_now
from pact.did import did_to_public_key


class Mandate:
    """A delegation mandate granting authority from one entity to another."""

    def __init__(self, payload: dict[str, Any], proof: dict[str, Any] | None = None) -> None:
        self._payload = copy.deepcopy(payload)
        self._proof = copy.deepcopy(proof) if proof else None

    @classmethod
    def issue(
        cls,
        *,
        issuer: str,
        subject: str,
        scope: list[str],
        constraints: dict[str, Any] | None = None,
        expires_in_days: int | None = None,
        parent_mandate_id: str | None = None,
    ) -> Mandate:
        """Create a new delegation mandate.

        Args:
            issuer: DID of the entity granting authority
            subject: DID of the agent receiving authority
            scope: List of permission strings (e.g. ["trade:read", "trade:execute"])
            constraints: Optional restrictions (rate limits, IP ranges, etc.)
            expires_in_days: Optional expiry in days from now
            parent_mandate_id: ID of parent mandate if this is a sub-delegation
        """
        now = datetime.now(timezone.utc)

        credential_subject: dict[str, Any] = {
            "id": subject,
            "scope": scope,
        }
        if constraints:
            credential_subject["constraints"] = constraints
        if parent_mandate_id:
            credential_subject["parentMandate"] = parent_mandate_id

        expiration = None
        if expires_in_days is not None:
            expiration = (now + timedelta(days=expires_in_days)).strftime("%Y-%m-%dT%H:%M:%SZ")

        payload = {
            "@context": [
                "https://www.w3.org/2018/credentials/v1",
                "https://pact-protocol.org/v1",
            ],
            "id": f"urn:uuid:{uuid.uuid4()}",
            "type": ["VerifiableCredential", "PACTMandate"],
            "issuer": issuer,
            "issuanceDate": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "credentialSubject": credential_subject,
        }

        if expiration:
            payload["expirationDate"] = expiration

        return cls(payload)

    def sign(self, key_pair: KeyPair) -> Mandate:
        """Sign the mandate with the issuer's key pair."""
        issuer_pub = did_to_public_key(self._payload["issuer"])
        if issuer_pub != key_pair.public_bytes:
            raise ValueError("Key pair does not match the mandate issuer DID")

        payload_bytes = canonical_json(self._payload)
        signature = key_pair.sign(payload_bytes)

        proof = {
            "type": "Ed25519Signature2020",
            "created": _iso_now(),
            "verificationMethod": f"{self._payload['issuer']}#key-0",
            "proofPurpose": "assertionMethod",
            "proofValue": multibase_encode(signature),
        }

        return Mandate(copy.deepcopy(self._payload), proof)

    def verify(self) -> bool:
        """Verify the mandate's signature."""
        if not self._proof:
            return False

        try:
            issuer_did = self._payload["issuer"]
            public_key = did_to_public_key(issuer_did)
            payload_bytes = canonical_json(self._payload)
            signature = multibase_decode(self._proof["proofValue"])
            return verify_signature(public_key, payload_bytes, signature)
        except (ValueError, KeyError, IndexError):
            return False

    def is_expired(self) -> bool:
        """Check if the mandate has expired."""
        exp = self._payload.get("expirationDate")
        if not exp:
            return False
        expiry = datetime.fromisoformat(exp.replace("Z", "+00:00"))
        return datetime.now(timezone.utc) > expiry

    @property
    def id(self) -> str:
        return self._payload["id"]

    @property
    def issuer(self) -> str:
        return self._payload["issuer"]

    @property
    def subject(self) -> str:
        return self._payload["credentialSubject"]["id"]

    @property
    def scope(self) -> list[str]:
        return list(self._payload["credentialSubject"]["scope"])

    @property
    def parent_mandate_id(self) -> str | None:
        return self._payload["credentialSubject"].get("parentMandate")

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict (deep copy to prevent mutation)."""
        result = copy.deepcopy(self._payload)
        if self._proof:
            result["proof"] = copy.deepcopy(self._proof)
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Mandate:
        """Deserialize from dict (deep copy to prevent mutation of caller data)."""
        data = copy.deepcopy(data)
        proof = data.pop("proof", None)
        # Validate required fields
        if "issuer" not in data:
            raise ValueError("Mandate missing required field: 'issuer'")
        cs = data.get("credentialSubject")
        if not isinstance(cs, dict):
            raise ValueError("Mandate missing required field: 'credentialSubject'")
        if "id" not in cs:
            raise ValueError("Mandate credentialSubject missing required field: 'id'")
        scope = cs.get("scope")
        if not isinstance(scope, list) or len(scope) == 0:
            raise ValueError("Mandate credentialSubject must have a non-empty 'scope' list")
        return cls(data, proof)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Mandate):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def __repr__(self) -> str:
        return f"Mandate(id={self.id!r}, issuer={self.issuer!r}, subject={self.subject!r}, scope={self.scope!r})"


def validate_delegation_chain(mandates: list[Mandate]) -> bool:
    """Validate a chain of delegation mandates.

    Each mandate in the chain must:
    1. Have a valid signature
    2. Not be expired
    3. Have its subject as the issuer of the next mandate
    4. Have scope that is a superset of the next mandate's scope
    """
    if not mandates:
        return False

    for i, mandate in enumerate(mandates):
        if not mandate.verify():
            return False
        if mandate.is_expired():
            return False

        # Check chain continuity: current subject must be next issuer
        if i < len(mandates) - 1:
            next_mandate = mandates[i + 1]
            if mandate.subject != next_mandate.issuer:
                return False
            # Child must reference parent
            if next_mandate.parent_mandate_id != mandate.id:
                return False
            # Scope must narrow or stay same
            if not set(next_mandate.scope).issubset(set(mandate.scope)):
                return False

    return True
