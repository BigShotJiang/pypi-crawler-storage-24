"""Trust Attestations — signed statements about agent behavior.

An attestation is a first-hand account from one agent about another's behavior
during an interaction. Attestations are NOT centralized scores — they are raw
evidence that verifiers evaluate independently.
"""

from __future__ import annotations

import copy
import uuid
from datetime import datetime, timezone
from typing import Any

from pact.crypto import (
    KeyPair,
    canonical_json,
    multibase_decode,
    multibase_encode,
    verify_signature,
    _iso_now,
)
from pact.did import did_to_public_key


INTERACTION_TYPES = {
    "task_completion",
    "information_quality",
    "commitment_honored",
    "delegation_compliance",
    "availability",
}

OUTCOMES = {"success", "partial", "failure"}


class Attestation:
    """A signed trust attestation about an agent's behavior."""

    def __init__(self, payload: dict[str, Any], proof: dict[str, Any] | None = None) -> None:
        self._payload = copy.deepcopy(payload)
        self._proof = copy.deepcopy(proof) if proof else None

    @classmethod
    def create(
        cls,
        *,
        attestor_did: str,
        subject_did: str,
        interaction_type: str,
        outcome: str,
        metrics: dict[str, Any] | None = None,
        context: str | None = None,
    ) -> Attestation:
        """Create a new trust attestation.

        Args:
            attestor_did: DID of the agent making the attestation
            subject_did: DID of the agent being attested about
            interaction_type: Type of interaction (task_completion, information_quality, etc.)
            outcome: Result of the interaction (success, partial, failure)
            metrics: Optional quantitative metrics (accuracy, response_time_ms, etc.)
            context: Optional description of the interaction context
        """
        if attestor_did == subject_did:
            raise ValueError("Self-attestation is not allowed: attestor and subject DIDs must differ")
        if interaction_type not in INTERACTION_TYPES:
            raise ValueError(
                f"Invalid interaction_type: {interaction_type!r}. "
                f"Must be one of: {', '.join(sorted(INTERACTION_TYPES))}"
            )
        if outcome not in OUTCOMES:
            raise ValueError(
                f"Invalid outcome: {outcome!r}. "
                f"Must be one of: {', '.join(sorted(OUTCOMES))}"
            )

        payload: dict[str, Any] = {
            "@context": "https://pact-protocol.org/attestation/v1",
            "id": f"urn:uuid:{uuid.uuid4()}",
            "type": "PACTAttestation",
            "attestor": attestor_did,
            "subject": subject_did,
            "interactionType": interaction_type,
            "outcome": outcome,
            "timestamp": _iso_now(),
        }

        if metrics:
            payload["metrics"] = metrics
        if context:
            payload["context"] = context

        return cls(payload)

    def sign(self, key_pair: KeyPair) -> Attestation:
        """Sign the attestation with the attestor's key pair."""
        from pact.did import did_to_public_key

        attestor_pub = did_to_public_key(self._payload["attestor"])
        if attestor_pub != key_pair.public_bytes:
            raise ValueError("Key pair does not match the attestor DID")

        payload_bytes = canonical_json(self._payload)
        signature = key_pair.sign(payload_bytes)

        proof = {
            "type": "Ed25519Signature2020",
            "created": _iso_now(),
            "verificationMethod": f"{self._payload['attestor']}#key-0",
            "proofPurpose": "assertionMethod",
            "proofValue": multibase_encode(signature),
        }

        return Attestation(copy.deepcopy(self._payload), proof)

    def verify(self) -> bool:
        """Verify the attestation's signature."""
        if not self._proof:
            return False

        try:
            attestor_did = self._payload["attestor"]
            public_key = did_to_public_key(attestor_did)
            payload_bytes = canonical_json(self._payload)
            signature = multibase_decode(self._proof["proofValue"])
            return verify_signature(public_key, payload_bytes, signature)
        except (ValueError, KeyError, IndexError):
            return False

    @property
    def id(self) -> str:
        return self._payload["id"]

    @property
    def attestor_did(self) -> str:
        return self._payload["attestor"]

    @property
    def subject_did(self) -> str:
        return self._payload["subject"]

    @property
    def interaction_type(self) -> str:
        return self._payload["interactionType"]

    @property
    def outcome(self) -> str:
        return self._payload["outcome"]

    @property
    def metrics(self) -> dict[str, Any]:
        m = self._payload.get("metrics")
        return copy.deepcopy(m) if m else {}

    @property
    def timestamp(self) -> str:
        return self._payload["timestamp"]

    @property
    def is_signed(self) -> bool:
        return self._proof is not None

    def to_dict(self) -> dict[str, Any]:
        result = copy.deepcopy(self._payload)
        if self._proof:
            result["proof"] = copy.deepcopy(self._proof)
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Attestation:
        data = copy.deepcopy(data)
        proof = data.pop("proof", None)
        # Validate required fields
        for field in ("attestor", "subject", "interactionType", "outcome"):
            if field not in data:
                raise ValueError(f"Attestation missing required field: {field!r}")
        if data["interactionType"] not in INTERACTION_TYPES:
            raise ValueError(f"Invalid interaction_type in attestation: {data['interactionType']!r}")
        if data["outcome"] not in OUTCOMES:
            raise ValueError(f"Invalid outcome in attestation: {data['outcome']!r}")
        if data["attestor"] == data["subject"]:
            raise ValueError("Self-attestation is not allowed")
        return cls(data, proof)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Attestation):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def __repr__(self) -> str:
        return (
            f"Attestation(attestor={self.attestor_did!r}, "
            f"subject={self.subject_did!r}, "
            f"type={self.interaction_type!r}, "
            f"outcome={self.outcome!r})"
        )


class AttestationStore:
    """Local store for attestations about this agent.

    Supports selective disclosure — the agent chooses which attestations to share.
    """

    DEFAULT_MAX_SIZE = 10000

    def __init__(self, *, max_size: int = DEFAULT_MAX_SIZE) -> None:
        self._attestations: list[Attestation] = []
        self._max_size = max_size
        self._seen_ids: set[str] = set()

    def add(self, attestation: Attestation) -> None:
        if not attestation.verify():
            raise ValueError("Cannot store unverified attestation")
        # Deduplicate by ID
        if attestation.id in self._seen_ids:
            return
        # Evict oldest if at capacity
        if len(self._attestations) >= self._max_size:
            evicted = self._attestations.pop(0)
            self._seen_ids.discard(evicted.id)
        self._attestations.append(attestation)
        self._seen_ids.add(attestation.id)

    def get_all(self) -> list[Attestation]:
        return list(self._attestations)

    def get_by_type(self, interaction_type: str) -> list[Attestation]:
        return [a for a in self._attestations if a.interaction_type == interaction_type]

    def get_by_attestor(self, attestor_did: str) -> list[Attestation]:
        return [a for a in self._attestations if a.attestor_did == attestor_did]

    def get_successful(self) -> list[Attestation]:
        return [a for a in self._attestations if a.outcome == "success"]

    def get_best(self, limit: int = 10) -> list[Attestation]:
        """Get the best attestations for selective disclosure.

        Prioritizes successful, recent attestations with metrics.
        """
        scored: list[tuple[float, Attestation]] = []
        for a in self._attestations:
            score = 0.0
            if a.outcome == "success":
                score += 1.0
            elif a.outcome == "partial":
                score += 0.5
            if a.metrics:
                score += 0.5
            if a.is_signed:
                score += 0.5
            scored.append((score, a))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [a for _, a in scored[:limit]]

    @property
    def count(self) -> int:
        return len(self._attestations)
