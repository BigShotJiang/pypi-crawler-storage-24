"""Agent Pact — dual-signed commitment agreements between agents.

A Pact is a binding agreement between two agents, defining terms, deliverables,
and SLAs. Both parties sign, both hold a copy. Breach or completion generates
trust attestations, creating reputation consequences.
"""

from __future__ import annotations

import copy
import uuid
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Any

from pact.crypto import (
    KeyPair,
    canonical_json,
    multibase_decode,
    multibase_encode,
    verify_signature,
    _iso_now,
)
from pact.did import did_to_public_key


class PactStatus(str, Enum):
    PROPOSED = "proposed"
    ACTIVE = "active"
    COMPLETED = "completed"
    BREACHED = "breached"
    CANCELLED = "cancelled"


class Pact:
    """A dual-signed commitment agreement between two agents."""

    def __init__(
        self,
        payload: dict[str, Any],
        proposer_proof: dict[str, Any] | None = None,
        acceptor_proof: dict[str, Any] | None = None,
    ) -> None:
        self._payload = copy.deepcopy(payload)
        self._proposer_proof = copy.deepcopy(proposer_proof) if proposer_proof else None
        self._acceptor_proof = copy.deepcopy(acceptor_proof) if acceptor_proof else None

    @classmethod
    def propose(
        cls,
        *,
        proposer_did: str,
        counterparty_did: str,
        terms: str,
        deliverables: list[str],
        sla: dict[str, Any] | None = None,
        effective_days: int = 30,
    ) -> Pact:
        """Create a new pact proposal.

        Args:
            proposer_did: DID of the proposing agent
            counterparty_did: DID of the other party
            terms: Human-readable description of the agreement
            deliverables: List of specific deliverable descriptions
            sla: Optional service level agreement parameters
            effective_days: How many days the pact is effective once accepted
        """
        if proposer_did == counterparty_did:
            raise ValueError("Cannot propose a pact with yourself: proposer and counterparty must differ")
        now = datetime.now(timezone.utc)

        payload: dict[str, Any] = {
            "@context": "https://pact-protocol.org/pact/v1",
            "id": f"urn:uuid:{uuid.uuid4()}",
            "type": "PACTPact",
            "status": PactStatus.PROPOSED.value,
            "proposer": proposer_did,
            "counterparty": counterparty_did,
            "terms": terms,
            "deliverables": deliverables,
            "createdAt": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "effectiveDate": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "expiryDate": (now + timedelta(days=effective_days)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

        if sla:
            payload["sla"] = sla

        return cls(payload)

    def sign_as_proposer(self, key_pair: KeyPair) -> Pact:
        """Sign the pact as the proposer."""
        proposer_pub = did_to_public_key(self._payload["proposer"])
        if proposer_pub != key_pair.public_bytes:
            raise ValueError("Key pair does not match the proposer DID")

        payload_bytes = canonical_json(self._payload)
        signature = key_pair.sign(payload_bytes)

        proof = {
            "type": "Ed25519Signature2020",
            "created": _iso_now(),
            "verificationMethod": f"{self._payload['proposer']}#key-0",
            "proofPurpose": "assertionMethod",
            "proofValue": multibase_encode(signature),
        }

        return Pact(
            copy.deepcopy(self._payload),
            proposer_proof=proof,
            acceptor_proof=copy.deepcopy(self._acceptor_proof) if self._acceptor_proof else None,
        )

    def accept(self, key_pair: KeyPair) -> Pact:
        """Accept and sign the pact as the counterparty.

        Requires the proposer to have already signed.
        """
        if not self._proposer_proof:
            raise ValueError("Cannot accept a pact that has not been signed by the proposer")
        if self.is_expired:
            raise ValueError("Cannot accept an expired pact")

        counterparty_pub = did_to_public_key(self._payload["counterparty"])
        if counterparty_pub != key_pair.public_bytes:
            raise ValueError("Key pair does not match the counterparty DID")

        payload_bytes = canonical_json(self._payload)
        signature = key_pair.sign(payload_bytes)

        proof = {
            "type": "Ed25519Signature2020",
            "created": _iso_now(),
            "verificationMethod": f"{self._payload['counterparty']}#key-0",
            "proofPurpose": "assertionMethod",
            "proofValue": multibase_encode(signature),
        }

        new_payload = copy.deepcopy(self._payload)
        new_payload["status"] = PactStatus.ACTIVE.value

        return Pact(
            new_payload,
            proposer_proof=copy.deepcopy(self._proposer_proof),
            acceptor_proof=proof,
        )

    def complete(self, key_pair: KeyPair) -> Pact:
        """Mark the pact as completed. Requires authorization from proposer or counterparty."""
        if self.status != PactStatus.ACTIVE:
            raise ValueError(f"Cannot complete a pact in '{self.status.value}' state; pact must be active")
        if self.is_expired:
            raise ValueError("Cannot complete an expired pact")
        self._require_party_key(key_pair)
        new_payload = copy.deepcopy(self._payload)
        new_payload["status"] = PactStatus.COMPLETED.value
        new_payload["completedAt"] = _iso_now()
        return Pact(
            new_payload,
            copy.deepcopy(self._proposer_proof),
            copy.deepcopy(self._acceptor_proof),
        )

    def breach(self, reason: str, key_pair: KeyPair) -> Pact:
        """Mark the pact as breached. Requires authorization from proposer or counterparty."""
        if self.status != PactStatus.ACTIVE:
            raise ValueError(f"Cannot breach a pact in '{self.status.value}' state; pact must be active")
        if self.is_expired:
            raise ValueError("Cannot breach an expired pact")
        self._require_party_key(key_pair)
        new_payload = copy.deepcopy(self._payload)
        new_payload["status"] = PactStatus.BREACHED.value
        new_payload["breachReason"] = reason
        new_payload["breachedAt"] = _iso_now()
        return Pact(
            new_payload,
            copy.deepcopy(self._proposer_proof),
            copy.deepcopy(self._acceptor_proof),
        )

    def cancel(self, key_pair: KeyPair) -> Pact:
        """Cancel the pact by mutual agreement. Requires authorization from proposer or counterparty."""
        if self.status != PactStatus.ACTIVE:
            raise ValueError(f"Cannot cancel a pact in '{self.status.value}' state; pact must be active")
        if self.is_expired:
            raise ValueError("Cannot cancel an expired pact")
        self._require_party_key(key_pair)
        new_payload = copy.deepcopy(self._payload)
        new_payload["status"] = PactStatus.CANCELLED.value
        new_payload["cancelledAt"] = _iso_now()
        return Pact(
            new_payload,
            copy.deepcopy(self._proposer_proof),
            copy.deepcopy(self._acceptor_proof),
        )

    def _require_party_key(self, key_pair: KeyPair) -> None:
        """Verify that key_pair belongs to either the proposer or counterparty."""
        proposer_pub = did_to_public_key(self._payload["proposer"])
        counterparty_pub = did_to_public_key(self._payload["counterparty"])
        if key_pair.public_bytes not in (proposer_pub, counterparty_pub):
            raise ValueError("Key pair does not match either the proposer or counterparty DID")

    def verify_proposer(self) -> bool:
        """Verify the proposer's signature."""
        if not self._proposer_proof:
            return False
        try:
            public_key = did_to_public_key(self._payload["proposer"])
            original = self._get_original_payload()
            payload_bytes = canonical_json(original)
            signature = multibase_decode(self._proposer_proof["proofValue"])
            return verify_signature(public_key, payload_bytes, signature)
        except (ValueError, KeyError, IndexError):
            return False

    def verify_counterparty(self) -> bool:
        """Verify the counterparty's signature."""
        if not self._acceptor_proof:
            return False
        try:
            public_key = did_to_public_key(self._payload["counterparty"])
            original = self._get_original_payload()
            payload_bytes = canonical_json(original)
            signature = multibase_decode(self._acceptor_proof["proofValue"])
            return verify_signature(public_key, payload_bytes, signature)
        except (ValueError, KeyError, IndexError):
            return False

    def verify_both(self) -> bool:
        """Verify both signatures."""
        return self.verify_proposer() and self.verify_counterparty()

    def _get_original_payload(self) -> dict[str, Any]:
        """Get the original proposed payload (before status changes)."""
        original = copy.deepcopy(self._payload)
        original["status"] = PactStatus.PROPOSED.value
        original.pop("completedAt", None)
        original.pop("breachReason", None)
        original.pop("breachedAt", None)
        original.pop("cancelledAt", None)
        return original

    @property
    def id(self) -> str:
        return self._payload["id"]

    @property
    def status(self) -> PactStatus:
        return PactStatus(self._payload["status"])

    @property
    def proposer(self) -> str:
        return self._payload["proposer"]

    @property
    def counterparty(self) -> str:
        return self._payload["counterparty"]

    @property
    def terms(self) -> str:
        return self._payload["terms"]

    @property
    def deliverables(self) -> list[str]:
        return list(self._payload["deliverables"])

    @property
    def is_active(self) -> bool:
        return self.status == PactStatus.ACTIVE

    @property
    def is_expired(self) -> bool:
        expiry_str = self._payload.get("expiryDate")
        if not expiry_str:
            return False
        expiry = datetime.fromisoformat(expiry_str.replace("Z", "+00:00"))
        return datetime.now(timezone.utc) > expiry

    def to_dict(self) -> dict[str, Any]:
        result = copy.deepcopy(self._payload)
        proofs = []
        if self._proposer_proof:
            proofs.append(copy.deepcopy(self._proposer_proof))
        if self._acceptor_proof:
            proofs.append(copy.deepcopy(self._acceptor_proof))
        if proofs:
            result["proof"] = proofs
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Pact:
        data = copy.deepcopy(data)
        proofs = data.pop("proof", [])
        if not isinstance(proofs, list):
            raise ValueError("Pact 'proof' field must be a list")
        for field in ("id", "proposer", "counterparty", "terms", "deliverables", "status"):
            if field not in data:
                raise ValueError(f"Pact missing required field: {field!r}")
        if not isinstance(data["deliverables"], list) or len(data["deliverables"]) == 0:
            raise ValueError("Pact must have a non-empty 'deliverables' list")
        if data["proposer"] == data["counterparty"]:
            raise ValueError("Self-pact is not allowed: proposer and counterparty must differ")
        valid_statuses = {s.value for s in PactStatus}
        if data["status"] not in valid_statuses:
            raise ValueError(f"Invalid pact status: {data['status']!r}")

        # Match proofs to roles by verificationMethod DID
        proposer_did = data.get("proposer", "")
        counterparty_did = data.get("counterparty", "")
        proposer_proof = None
        acceptor_proof = None

        for proof in proofs:
            vm = proof.get("verificationMethod", "")
            # verificationMethod must be "did:pact:z6Mk...#key-0"
            if not vm.endswith("#key-0"):
                continue
            proof_did = vm[:-6]  # strip '#key-0'
            if proof_did == proposer_did:
                proposer_proof = proof
            elif proof_did == counterparty_did:
                acceptor_proof = proof

        return cls(data, proposer_proof, acceptor_proof)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Pact):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def __repr__(self) -> str:
        return (
            f"Pact(id={self.id!r}, status={self.status.value!r}, "
            f"proposer={self.proposer!r}, counterparty={self.counterparty!r})"
        )
