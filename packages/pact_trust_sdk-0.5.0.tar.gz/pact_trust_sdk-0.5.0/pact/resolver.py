"""DID Resolver — resolve DIDs to DID Documents.

Supports multiple resolution strategies:
1. Local resolution for did:pact and did:key (self-resolving from public key)
2. HTTP resolution (fetch DID document from agent endpoint)
3. Registry resolution (query a PACT registry)
"""

from __future__ import annotations

import copy
import time
import urllib.parse
from typing import Any

import httpx

from pact.did import did_to_public_key, resolve_did_document

# Maximum response body size for remote resolution (1 MB)
MAX_RESOLUTION_RESPONSE_BYTES = 1_000_000

# Default cache TTL in seconds
DEFAULT_CACHE_TTL = 300  # 5 minutes


class _CacheEntry:
    __slots__ = ("doc", "expires_at")

    def __init__(self, doc: dict[str, Any], ttl: float) -> None:
        self.doc = doc
        self.expires_at = time.monotonic() + ttl

    @property
    def is_expired(self) -> bool:
        return time.monotonic() > self.expires_at


class DIDResolver:
    """Multi-strategy DID resolver."""

    def __init__(
        self,
        *,
        registry_url: str | None = None,
        cache_size: int = 1000,
        cache_ttl: float = DEFAULT_CACHE_TTL,
    ) -> None:
        self._registry_url = registry_url
        self._cache: dict[str, _CacheEntry] = {}
        self._cache_size = cache_size
        self._cache_ttl = cache_ttl

    def resolve(self, did: str) -> dict[str, Any] | None:
        """Resolve a DID to its DID Document (synchronous, local only)."""
        cached = self._cache_get(did)
        if cached is not None:
            return cached

        method = self._extract_method(did)

        if method in ("pact", "key"):
            doc = self._resolve_local(did)
            if doc:
                self._cache_put(did, doc)
            return doc

        return None

    async def resolve_async(self, did: str) -> dict[str, Any] | None:
        """Resolve a DID using all available strategies."""
        cached = self._cache_get(did)
        if cached is not None:
            return cached

        method = self._extract_method(did)

        # Local resolution for self-resolving methods
        if method in ("pact", "key"):
            doc = self._resolve_local(did)
            if doc:
                self._cache_put(did, doc)
                return doc

        # Try registry
        if self._registry_url:
            doc = await self._resolve_via_registry(did)
            if doc:
                self._cache_put(did, doc)
                return doc

        # Try HTTP (.well-known for did:web)
        if method == "web":
            doc = await self._resolve_web(did)
            if doc:
                self._cache_put(did, doc)
                return doc

        return None

    def _resolve_local(self, did: str) -> dict[str, Any] | None:
        """Resolve a self-resolving DID locally."""
        try:
            return resolve_did_document(did)
        except (ValueError, KeyError, IndexError):
            return None

    async def _resolve_via_registry(self, did: str) -> dict[str, Any] | None:
        """Query a PACT registry for DID resolution."""
        if not self._registry_url:
            return None

        try:
            safe_did = urllib.parse.quote(did, safe="")
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
                resp = await client.get(f"{self._registry_url}/did/{safe_did}")
                if resp.status_code != 200:
                    return None
                if len(resp.content) > MAX_RESOLUTION_RESPONSE_BYTES:
                    return None
                return resp.json()
        except (httpx.HTTPError, ValueError, KeyError):
            pass
        return None

    async def _resolve_web(self, did: str) -> dict[str, Any] | None:
        """Resolve did:web via .well-known."""
        parts = did.split(":")
        if len(parts) < 3:
            return None

        domain = parts[2].replace("%3A", ":")

        # SSRF protection: block internal/reserved IP ranges and localhost
        if not self._is_safe_domain(domain):
            return None

        # Sanitize path segments — reject traversal attempts
        if len(parts) > 3:
            path_segments = parts[3:]
            for seg in path_segments:
                decoded = urllib.parse.unquote(seg)
                if decoded in (".", "..") or "/" in decoded or "\\" in decoded:
                    return None
            path = "/".join(urllib.parse.quote(seg, safe="") for seg in path_segments)
        else:
            path = ""

        url = f"https://{domain}/{path}/.well-known/did.json" if path else f"https://{domain}/.well-known/did.json"

        try:
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
                resp = await client.get(url)
                if resp.status_code != 200:
                    return None
                # Enforce response size limit
                if len(resp.content) > MAX_RESOLUTION_RESPONSE_BYTES:
                    return None
                return resp.json()
        except (httpx.HTTPError, ValueError):
            pass
        return None

    @staticmethod
    def _is_safe_domain(domain: str) -> bool:
        """Check that a domain is not an internal/reserved address."""
        import ipaddress
        import socket

        # Block null bytes (bypass attempt)
        if "\x00" in domain or "\0" in domain:
            return False

        # Strip port if present
        host = domain.split(":")[0]

        # Block obvious internal hostnames
        blocked_hosts = {"localhost", "localhost.localdomain", "0.0.0.0"}
        if host.lower() in blocked_hosts:
            return False

        # Try to parse as IP address
        try:
            addr = ipaddress.ip_address(host)
            # Block private, loopback, link-local, reserved ranges
            if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
                return False
        except ValueError:
            # It's a hostname, not an IP — attempt DNS resolution to check
            try:
                results = socket.getaddrinfo(host, None, socket.AF_UNSPEC)
                for _, _, _, _, sockaddr in results:
                    ip = sockaddr[0]
                    addr = ipaddress.ip_address(ip)
                    if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
                        return False
            except socket.gaierror:
                return False

        return True

    def _extract_method(self, did: str) -> str:
        """Extract the DID method from a DID string."""
        parts = did.split(":")
        return parts[1] if len(parts) >= 3 else ""

    def _cache_get(self, did: str) -> dict[str, Any] | None:
        """Get from cache, returning None if missing or expired. Returns a deep copy."""
        entry = self._cache.get(did)
        if entry is None:
            return None
        if entry.is_expired:
            del self._cache[did]
            return None
        return copy.deepcopy(entry.doc)

    def _cache_put(self, did: str, doc: dict[str, Any]) -> None:
        """Add to cache with TTL, evicting oldest if full. Deep copies on store."""
        if len(self._cache) >= self._cache_size:
            first_key = next(iter(self._cache))
            del self._cache[first_key]
        self._cache[did] = _CacheEntry(copy.deepcopy(doc), self._cache_ttl)

    def clear_cache(self) -> None:
        """Clear the resolution cache."""
        self._cache.clear()
