"""PACT Agent HTTP Server — expose the PACT spec endpoints over HTTP.

Wraps an Agent instance in a Starlette ASGI application with:
    POST /pact/handshake          — Receive handshake, return signed response
    POST /pact/handshake/complete — Receive counter-proof from initiator
    GET  /pact/did                — Return this agent's DID Document
    GET  /pact/attestations       — Return selectively disclosed attestations
"""

from __future__ import annotations

import json
from typing import Any

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from pact.agent import Agent
from pact.handshake import (
    HANDSHAKE_MAX_AGE_SECONDS,
    HandshakeRequest,
    HandshakeResponse,
    HandshakeResult,
    build_handshake_response,
    verify_handshake_response,
)

# Maximum request body size (1 MB)
MAX_REQUEST_BYTES = 1_000_000

# Maximum pending handshake challenges before eviction
MAX_PENDING_CHALLENGES = 10_000


class PACTServer:
    """HTTP server that exposes PACT protocol endpoints for an Agent.

    Usage::

        agent = Agent.create(name="MyAgent", service_endpoint="http://localhost:8100")
        server = PACTServer(agent)

        # Use as ASGI app (e.g. with uvicorn)
        app = server.app

        # Or run directly
        server.run(host="0.0.0.0", port=8100)
    """

    def __init__(self, agent: Agent) -> None:
        self._agent = agent
        self._peers: dict[str, HandshakeResult] = {}  # peer_did -> result
        self._pacts: list[dict[str, Any]] = []
        self._pending_challenges: dict[str, tuple[str, float]] = {}  # peer_did -> (counter_challenge, timestamp)
        self._app = self._build_app()

    @property
    def agent(self) -> Agent:
        return self._agent

    @property
    def peers(self) -> dict[str, HandshakeResult]:
        return dict(self._peers)

    @property
    def pacts(self) -> list[dict[str, Any]]:
        return list(self._pacts)

    @property
    def app(self) -> Starlette:
        return self._app

    def _build_app(self) -> Starlette:
        routes = [
            Route("/pact/handshake", self._handle_handshake, methods=["POST"]),
            Route("/pact/handshake/complete", self._handle_handshake_complete, methods=["POST"]),
            Route("/pact/did", self._handle_did, methods=["GET"]),
            Route("/pact/attestations", self._handle_attestations, methods=["GET"]),
        ]
        return Starlette(routes=routes)

    async def _read_json(self, request: Request) -> dict[str, Any]:
        """Read and parse JSON body with size limit enforcement."""
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > MAX_REQUEST_BYTES:
                    raise ValueError("Request body too large")
            except (ValueError, OverflowError) as e:
                if "too large" in str(e):
                    raise
                raise ValueError("Invalid Content-Length header")

        body = await request.body()
        if len(body) > MAX_REQUEST_BYTES:
            raise ValueError("Request body too large")

        return json.loads(body)

    async def _handle_handshake(self, request: Request) -> JSONResponse:
        """POST /pact/handshake — respond to a handshake challenge."""
        try:
            data = await self._read_json(request)
            hs_request = HandshakeRequest.from_dict(data)
        except (ValueError, KeyError, json.JSONDecodeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception as e:
            return JSONResponse({"error": "Internal server error"}, status_code=500)

        try:
            # Validate request timestamp freshness
            import time
            from datetime import datetime, timezone
            req_ts = data.get("timestamp")
            if req_ts:
                try:
                    ts_dt = datetime.fromisoformat(req_ts.replace("Z", "+00:00"))
                    age = abs((datetime.now(timezone.utc) - ts_dt).total_seconds())
                    if age > HANDSHAKE_MAX_AGE_SECONDS:
                        return JSONResponse({"error": "Handshake request timestamp is stale"}, status_code=400)
                except (ValueError, TypeError):
                    return JSONResponse({"error": "Invalid timestamp format"}, status_code=400)

            # Evict stale pending challenges before adding new ones
            now = time.monotonic()
            stale = [k for k, (_, t) in self._pending_challenges.items() if now - t > HANDSHAKE_MAX_AGE_SECONDS]
            for k in stale:
                del self._pending_challenges[k]

            # Enforce max pending challenges
            if len(self._pending_challenges) >= MAX_PENDING_CHALLENGES:
                oldest_key = min(self._pending_challenges, key=lambda k: self._pending_challenges[k][1])
                del self._pending_challenges[oldest_key]

            payload = self._agent.get_handshake_payload()
            response = build_handshake_response(
                self._agent.key_pair,
                payload["did_document"],
                hs_request.challenge,
                payload["mandates"],
                payload["attestations"],
            )
            # Store the counter-challenge with timestamp for TTL eviction
            peer_did = hs_request.requester_did
            self._pending_challenges[peer_did] = (response.counter_challenge, now)

            return JSONResponse(response.to_dict())
        except Exception:
            return JSONResponse({"error": "Internal server error"}, status_code=500)

    async def _handle_handshake_complete(self, request: Request) -> JSONResponse:
        """POST /pact/handshake/complete — verify counter-proof from initiator."""
        try:
            data = await self._read_json(request)
            counter_response = HandshakeResponse.from_dict(data)
        except (ValueError, KeyError, json.JSONDecodeError) as e:
            return JSONResponse({"error": str(e)}, status_code=400)
        except Exception:
            return JSONResponse({"error": "Internal server error"}, status_code=500)

        try:
            peer_did = counter_response.did_document.get("id", "")
            if not peer_did:
                return JSONResponse({"error": "Missing peer DID"}, status_code=400)

            # Look up the counter-challenge we sent to this peer
            pending = self._pending_challenges.pop(peer_did, None)
            if not pending:
                return JSONResponse(
                    {"error": "No pending handshake for this peer"},
                    status_code=400,
                )

            original_challenge, _ = pending

            # Verify against the ORIGINAL challenge we sent, not one the peer chose
            result = verify_handshake_response(
                counter_response,
                original_challenge,
            )

            if result.verified:
                self._peers[peer_did] = result

            return JSONResponse({"status": "ok", "verified": result.verified})
        except Exception:
            return JSONResponse({"error": "Internal server error"}, status_code=500)

    async def _handle_did(self, request: Request) -> JSONResponse:
        """GET /pact/did — return this agent's DID Document."""
        try:
            return JSONResponse(self._agent.did_document())
        except Exception:
            return JSONResponse({"error": "Internal server error"}, status_code=500)

    async def _handle_attestations(self, request: Request) -> JSONResponse:
        """GET /pact/attestations — return selectively disclosed attestations."""
        try:
            best = self._agent.attestation_store.get_best()
            return JSONResponse([a.to_dict() for a in best])
        except Exception:
            return JSONResponse({"error": "Internal server error"}, status_code=500)

    def run(self, host: str = "0.0.0.0", port: int = 8100) -> None:
        """Run the server with uvicorn (blocking)."""
        try:
            import uvicorn
        except ImportError:
            raise ImportError(
                "uvicorn is required to run the server. "
                "Install it with: pip install pact-protocol[server]"
            )
        uvicorn.run(self._app, host=host, port=port)
