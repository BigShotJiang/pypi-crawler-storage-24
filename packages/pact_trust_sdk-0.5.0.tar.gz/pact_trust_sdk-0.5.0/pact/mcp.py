"""PACT MCP Server — Model Context Protocol interface for the PACT SDK.

Exposes PACT agent identity, delegation, trust, handshake, and pact tools
as MCP tools for use by LLM agents (Claude, etc.).

Run:  python -m pact.mcp
"""

from __future__ import annotations

import functools
import logging
import os
import secrets
from typing import Any

from mcp.server.fastmcp import FastMCP

from pact.agent import Agent
from pact.did import validate_did
from pact.handshake import (
    build_handshake_response,
    perform_handshake,
    verify_handshake_response,
)
from pact.mandate import Mandate, validate_delegation_chain
from pact.pact import Pact
from pact.persistence import PACTStore, PACTStoreError
from pact.resolver import DIDResolver
from pact.trust import TrustEvaluator

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Server & state
# ---------------------------------------------------------------------------

mcp = FastMCP("pact", instructions="PACT Protocol — agent identity, delegation, trust, and agreements")

_agents: dict[str, Agent] = {}
_mandates: dict[str, Mandate] = {}
_pacts: dict[str, Pact] = {}

# Resource limits to prevent memory exhaustion
_MAX_AGENTS = 100
_MAX_MANDATES = 10_000
_MAX_PACTS = 10_000
_resolver = DIDResolver()
_trust_evaluator = TrustEvaluator()
_store: PACTStore | None = None

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_MAX_NAME_LENGTH = 64


def _short_id(full_id: str) -> str:
    """Last 8 chars of a UUID for ergonomic referencing."""
    return full_id[-8:]


def _store_mandate(mandate: Mandate) -> str:
    """Store mandate with collision-safe short ID."""
    if len(_mandates) >= _MAX_MANDATES:
        raise ValueError(f"Maximum number of mandates ({_MAX_MANDATES}) reached.")
    sid = _short_id(mandate.id)
    if sid in _mandates:
        raise ValueError(f"Short ID collision for mandate '{sid}'. Re-issue to get a new ID.")
    _mandates[sid] = mandate
    return sid


def _store_pact(pact: Pact) -> str:
    """Store pact with collision-safe short ID."""
    if len(_pacts) >= _MAX_PACTS:
        raise ValueError(f"Maximum number of pacts ({_MAX_PACTS}) reached.")
    sid = _short_id(pact.id)
    if sid in _pacts:
        raise ValueError(f"Short ID collision for pact '{sid}'. Re-propose to get a new ID.")
    _pacts[sid] = pact
    return sid


def _validate_name(name: str) -> None:
    """Validate agent name is non-empty and reasonable length."""
    stripped = name.strip()
    if not stripped:
        raise ValueError("Agent name must be non-empty.")
    if len(stripped) > _MAX_NAME_LENGTH:
        raise ValueError(f"Agent name exceeds {_MAX_NAME_LENGTH} characters.")
    if stripped != name:
        raise ValueError("Agent name must not have leading/trailing whitespace.")


def _require_agent(name: str) -> Agent:
    if name not in _agents:
        raise ValueError(f"Unknown agent '{name}'. Use create_agent first.")
    return _agents[name]


def _did_to_name(did: str) -> str | None:
    """Resolve a DID to a human-readable agent name, or None if unknown."""
    for name, agent in _agents.items():
        if agent.did == did:
            return name
    return None


def _auto_save(fn):  # type: ignore[type-arg]
    """Decorator that auto-saves state after a mutating tool succeeds."""
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        result = fn(*args, **kwargs)
        if _store is not None:
            try:
                _store.save(_agents, _mandates, _pacts)
            except Exception:
                logger.exception("Auto-save failed after %s", fn.__name__)
                if isinstance(result, dict):
                    result["_persistence_warning"] = "State saved in memory but failed to persist to disk."
        return result
    return wrapper


# ===== Agent Identity (3) ===================================================

@mcp.tool()
@_auto_save
def create_agent(name: str, service_endpoint: str | None = None) -> dict[str, Any]:
    """Create a new PACT agent identity with a fresh Ed25519 keypair.

    Args:
        name: Unique human-readable name for the agent.
        service_endpoint: Optional HTTP(S) endpoint for this agent.

    Returns:
        Agent summary with DID and name.
    """
    _validate_name(name)
    if name in _agents:
        raise ValueError(f"Agent '{name}' already exists.")
    if len(_agents) >= _MAX_AGENTS:
        raise ValueError(f"Maximum number of agents ({_MAX_AGENTS}) reached.")
    agent = Agent.create(name=name, service_endpoint=service_endpoint)
    _agents[name] = agent
    return {"name": name, "did": agent.did, "service_endpoint": agent.service_endpoint}


@mcp.tool()
def list_agents() -> list[dict[str, Any]]:
    """List all created agents with their DIDs."""
    return [
        {"name": a.name, "did": a.did, "service_endpoint": a.service_endpoint}
        for a in _agents.values()
    ]


@mcp.tool()
def get_agent_info(name: str) -> dict[str, Any]:
    """Get full details for an agent including its DID document.

    Args:
        name: Agent name.
    """
    agent = _require_agent(name)
    return {
        "name": agent.name,
        "did": agent.did,
        "service_endpoint": agent.service_endpoint,
        "did_document": agent.did_document(),
        "mandate_count": len(agent.mandates),
        "attestation_count": agent.attestation_store.count,
    }


# ===== Delegation Mandates (3) =============================================

@mcp.tool()
@_auto_save
def issue_mandate(
    issuer: str, subject: str, scope: list[str], expires_in_days: int | None = None,
    parent_mandate_id: str | None = None,
) -> dict[str, Any]:
    """Issue a signed delegation mandate from issuer to subject.

    Args:
        issuer: Name of the issuing agent.
        subject: Name of the receiving agent.
        scope: List of permission strings (e.g. ["trade:read"]).
        expires_in_days: Optional expiry in days from now.
        parent_mandate_id: Short ID of the parent mandate (for sub-delegation chains).

    Returns:
        Signed mandate summary with short ID.
    """
    issuer_agent = _require_agent(issuer)
    subject_agent = _require_agent(subject)

    # Resolve short parent ID to full mandate ID
    full_parent_id = None
    if parent_mandate_id:
        if parent_mandate_id not in _mandates:
            raise ValueError(f"Unknown parent mandate '{parent_mandate_id}'.")
        full_parent_id = _mandates[parent_mandate_id].id

    mandate = Mandate.issue(
        issuer=issuer_agent.did,
        subject=subject_agent.did,
        scope=scope,
        expires_in_days=expires_in_days,
        parent_mandate_id=full_parent_id,
    )
    signed = mandate.sign(issuer_agent.key_pair)
    sid = _store_mandate(signed)
    subject_agent.add_mandate(signed.to_dict())
    return {"mandate_id": sid, "issuer": issuer, "subject": subject, "scope": scope}


@mcp.tool()
def verify_mandate(mandate_id: str) -> dict[str, Any]:
    """Verify a mandate's signature and check expiry.

    Args:
        mandate_id: Short mandate ID (last 8 chars).
    """
    if mandate_id not in _mandates:
        raise ValueError(f"Unknown mandate '{mandate_id}'.")
    m = _mandates[mandate_id]
    return {
        "mandate_id": mandate_id,
        "signature_valid": m.verify(),
        "expired": m.is_expired(),
        "issuer": _did_to_name(m.issuer) or m.issuer,
        "subject": _did_to_name(m.subject) or m.subject,
        "scope": m.scope,
    }


@mcp.tool()
def validate_chain(mandate_ids: list[str]) -> dict[str, Any]:
    """Validate a delegation chain of mandates.

    Args:
        mandate_ids: Ordered list of short mandate IDs forming the chain.
    """
    if not mandate_ids:
        raise ValueError("Chain must contain at least one mandate.")
    mandates = []
    for mid in mandate_ids:
        if mid not in _mandates:
            raise ValueError(f"Unknown mandate '{mid}'.")
        mandates.append(_mandates[mid])
    return {"valid": validate_delegation_chain(mandates), "chain_length": len(mandates)}


@mcp.tool()
def list_mandates(agent: str | None = None) -> list[dict[str, Any]]:
    """List all stored mandates, optionally filtered by agent name.

    Args:
        agent: Optional agent name to filter by (as issuer or subject).
    """
    agent_did = _require_agent(agent).did if agent else None
    results = []
    for sid, m in _mandates.items():
        if agent_did and m.issuer != agent_did and m.subject != agent_did:
            continue
        results.append({
            "mandate_id": sid,
            "issuer": _did_to_name(m.issuer) or m.issuer,
            "subject": _did_to_name(m.subject) or m.subject,
            "scope": m.scope,
            "expired": m.is_expired(),
        })
    return results


# ===== Trust Attestations (3) ==============================================

@mcp.tool()
@_auto_save
def create_attestation(
    attestor: str,
    subject: str,
    interaction_type: str,
    outcome: str,
    metrics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create and sign a trust attestation about another agent.

    Args:
        attestor: Name of the attesting agent.
        subject: Name of the agent being attested about.
        interaction_type: One of task_completion, information_quality,
            commitment_honored, delegation_compliance, availability.
        outcome: One of success, partial, failure.
        metrics: Optional quantitative metrics dict.
    """
    attestor_agent = _require_agent(attestor)
    subject_agent = _require_agent(subject)
    att = attestor_agent.attest(
        subject_agent.did,
        interaction_type=interaction_type,
        outcome=outcome,
        metrics=metrics,
    )
    subject_agent.receive_attestation(att)
    return {
        "attestation_id": _short_id(att.id),
        "attestor": attestor,
        "subject": subject,
        "interaction_type": interaction_type,
        "outcome": outcome,
    }


@mcp.tool()
def get_attestations(agent: str, filter_type: str | None = None) -> list[dict[str, Any]]:
    """Query an agent's received attestations.

    Args:
        agent: Agent name.
        filter_type: Optional interaction type to filter by.
    """
    a = _require_agent(agent)
    store = a.attestation_store
    atts = store.get_by_type(filter_type) if filter_type else store.get_all()
    return [
        {
            "id": _short_id(att.id),
            "attestor": _did_to_name(att.attestor_did) or att.attestor_did,
            "interaction_type": att.interaction_type,
            "outcome": att.outcome,
            "timestamp": att.timestamp,
        }
        for att in atts
    ]


@mcp.tool()
def evaluate_trust(agent: str) -> dict[str, Any]:
    """Evaluate an agent's trust score from attestations and mandates.

    Args:
        agent: Agent name.
    """
    a = _require_agent(agent)
    mandates = [Mandate.from_dict(m) for m in a.mandates]
    result = _trust_evaluator.evaluate_detailed(a.attestation_store.get_all(), mandates)
    return {"agent": agent, **result}


# ===== Agent Handshake (2) ==================================================

@mcp.tool()
def handshake(initiator: str, responder: str) -> dict[str, Any]:
    """Perform a local handshake between two in-memory agents.

    Args:
        initiator: Name of the initiating agent.
        responder: Name of the responding agent.
    """
    _require_agent(initiator)
    resp_agent = _require_agent(responder)
    if initiator == responder:
        raise ValueError("Cannot handshake with self.")

    challenge = secrets.token_hex(32)

    # Responder builds response
    resp_payload = resp_agent.get_handshake_payload()
    response = build_handshake_response(
        agent_key_pair=resp_agent.key_pair,
        agent_did_document=resp_agent.did_document(),
        challenge=challenge,
        mandates=resp_payload["mandates"],
        attestations=resp_payload["attestations"],
    )

    # Initiator verifies
    result = verify_handshake_response(response, challenge)

    return {
        "verified": result.verified,
        "initiator": initiator,
        "responder": responder,
        "peer_did": result.peer_did,
        "trust_score": result.trust_score,
        "mandates_received": len(result.mandates),
        "attestations_received": len(result.attestations),
    }


@mcp.tool()
async def handshake_remote(
    agent: str, peer_endpoint: str, allow_insecure: bool = False
) -> dict[str, Any]:
    """Perform an HTTP handshake with a remote PACT agent.

    Args:
        agent: Name of the local agent.
        peer_endpoint: Remote agent's HTTP endpoint (e.g. http://localhost:8100).
        allow_insecure: Allow non-HTTPS endpoints (for local dev).
    """
    a = _require_agent(agent)
    payload = a.get_handshake_payload()
    result = await perform_handshake(
        agent_key_pair=a.key_pair,
        agent_did=a.did,
        peer_endpoint=peer_endpoint,
        agent_did_document=a.did_document(),
        mandates=payload["mandates"],
        attestations=payload["attestations"],
        allow_insecure=allow_insecure,
    )
    return {
        "verified": result.verified,
        "peer_did": result.peer_did,
        "trust_score": result.trust_score,
        "mandates_received": len(result.mandates),
        "attestations_received": len(result.attestations),
    }


# ===== Agent Pacts (4) =====================================================

@mcp.tool()
@_auto_save
def propose_pact(
    proposer: str,
    counterparty: str,
    terms: str,
    deliverables: list[str],
    sla: dict[str, Any] | None = None,
    effective_days: int = 30,
) -> dict[str, Any]:
    """Propose a new pact and sign as proposer.

    Args:
        proposer: Name of the proposing agent.
        counterparty: Name of the counterparty agent.
        terms: Agreement terms text.
        deliverables: List of deliverable descriptions.
        sla: Optional SLA parameters dict.
        effective_days: Days until pact expires (default 30).
    """
    prop = _require_agent(proposer)
    counter = _require_agent(counterparty)
    pact = Pact.propose(
        proposer_did=prop.did,
        counterparty_did=counter.did,
        terms=terms,
        deliverables=deliverables,
        sla=sla,
        effective_days=effective_days,
    )
    signed = pact.sign_as_proposer(prop.key_pair)
    sid = _store_pact(signed)
    return {
        "pact_id": sid,
        "proposer": proposer,
        "counterparty": counterparty,
        "status": signed.status.value,
        "terms": terms,
    }


@mcp.tool()
@_auto_save
def accept_pact(pact_id: str, agent: str) -> dict[str, Any]:
    """Accept a proposed pact as the counterparty.

    Args:
        pact_id: Short pact ID.
        agent: Name of the accepting agent (must be counterparty).
    """
    if pact_id not in _pacts:
        raise ValueError(f"Unknown pact '{pact_id}'.")
    a = _require_agent(agent)
    _pacts[pact_id] = _pacts[pact_id].accept(a.key_pair)
    p = _pacts[pact_id]
    return {"pact_id": pact_id, "status": p.status.value}


@mcp.tool()
@_auto_save
def complete_pact(pact_id: str, agent: str) -> dict[str, Any]:
    """Mark an active pact as completed.

    Args:
        pact_id: Short pact ID.
        agent: Name of the agent marking completion.
    """
    if pact_id not in _pacts:
        raise ValueError(f"Unknown pact '{pact_id}'.")
    a = _require_agent(agent)
    _pacts[pact_id] = _pacts[pact_id].complete(a.key_pair)
    p = _pacts[pact_id]
    return {"pact_id": pact_id, "status": p.status.value}


@mcp.tool()
@_auto_save
def breach_pact(pact_id: str, agent: str, reason: str) -> dict[str, Any]:
    """Mark an active pact as breached.

    Args:
        pact_id: Short pact ID.
        agent: Name of the agent reporting the breach.
        reason: Description of the breach.
    """
    if pact_id not in _pacts:
        raise ValueError(f"Unknown pact '{pact_id}'.")
    a = _require_agent(agent)
    _pacts[pact_id] = _pacts[pact_id].breach(reason, a.key_pair)
    p = _pacts[pact_id]
    return {"pact_id": pact_id, "status": p.status.value, "reason": reason}


# ===== Utility (3) =========================================================

@mcp.tool()
def get_pact_info(pact_id: str) -> dict[str, Any]:
    """Get full details for a pact.

    Args:
        pact_id: Short pact ID.
    """
    if pact_id not in _pacts:
        raise ValueError(f"Unknown pact '{pact_id}'.")
    p = _pacts[pact_id]
    proposer_name = _did_to_name(p.proposer)
    counter_name = _did_to_name(p.counterparty)
    return {
        "pact_id": pact_id,
        "status": p.status.value,
        "proposer": proposer_name,
        "counterparty": counter_name,
        "terms": p.terms,
        "deliverables": p.deliverables,
        "is_active": p.is_active,
        "is_expired": p.is_expired,
    }


@mcp.tool()
def list_pacts(agent: str | None = None) -> list[dict[str, Any]]:
    """List all pacts, optionally filtered by agent name.

    Args:
        agent: Optional agent name to filter by.
    """
    results = []
    agent_did = _require_agent(agent).did if agent else None
    for sid, p in _pacts.items():
        if agent_did and p.proposer != agent_did and p.counterparty != agent_did:
            continue
        results.append({
            "pact_id": sid,
            "status": p.status.value,
            "proposer": _did_to_name(p.proposer) or p.proposer,
            "counterparty": _did_to_name(p.counterparty) or p.counterparty,
            "terms": p.terms,
        })
    return results


@mcp.tool()
def resolve_did(did: str) -> dict[str, Any]:
    """Resolve a DID to its DID document.

    Args:
        did: The DID string to resolve (e.g. did:pact:z...).
    """
    if not validate_did(did):
        raise ValueError(f"Invalid DID: {did}")
    doc = _resolver.resolve(did)
    if doc is None:
        raise ValueError(f"Could not resolve DID: {did}")
    return doc


# ===== MCP Resources (2) ===================================================

@mcp.resource("pact://agents/{name}/did-document")
def agent_did_document(name: str) -> dict[str, Any]:
    """Get an agent's DID document."""
    return _require_agent(name).did_document()


@mcp.resource("pact://agents/{name}/attestations")
def agent_attestations(name: str) -> list[dict[str, Any]]:
    """Get an agent's attestation store contents."""
    return [att.to_dict() for att in _require_agent(name).attestation_store.get_all()]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    global _agents, _mandates, _pacts, _store

    encrypt = os.environ.get("PACT_ENCRYPT", "true").lower() != "false"
    passphrase = os.environ.get("PACT_PASSPHRASE")
    store_dir = os.environ.get("PACT_STORE_DIR", "~/.pact")
    verify_on_load = os.environ.get("PACT_VERIFY_ON_LOAD", "false").lower() == "true"

    if passphrase or not encrypt:
        if not encrypt:
            logger.warning("PACT_ENCRYPT=false — state will be stored unencrypted!")
        try:
            _store = PACTStore(
                store_dir=store_dir,
                passphrase=passphrase,
                encrypt=encrypt,
                verify_on_load=verify_on_load,
            )
            _store.acquire_lock()
            _agents, _mandates, _pacts = _store.load()
            agent_count = len(_agents)
            if agent_count:
                logger.info("Loaded %d agent(s) from %s", agent_count, store_dir)
        except PACTStoreError:
            logger.exception("Failed to initialize persistence")
            raise
    else:
        logger.info(
            "No PACT_PASSPHRASE set — running without persistence (in-memory only)."
        )

    try:
        mcp.run()
    finally:
        if _store is not None:
            _store.release_lock()


if __name__ == "__main__":
    main()
