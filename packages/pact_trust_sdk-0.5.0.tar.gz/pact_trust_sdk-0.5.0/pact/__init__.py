"""PACT — Protocol for Agent Credentials and Trust.

The trust infrastructure layer for autonomous AI agents.
"""

from pact.agent import Agent
from pact.attestation import Attestation, AttestationStore
from pact.crypto import KeyPair
from pact.did import create_did, validate_did
from pact.handshake import (
    HandshakeRequest,
    HandshakeResponse,
    HandshakeResult,
    perform_handshake,
    verify_handshake_response,
)
from pact.mandate import Mandate, validate_delegation_chain
from pact.pact import Pact, PactStatus
from pact.resolver import DIDResolver
from pact.trust import TrustEvaluator

__version__ = "0.5.0"


def __getattr__(name: str):
    if name == "PACTServer":
        try:
            from pact.server import PACTServer

            return PACTServer
        except ImportError:
            raise ImportError(
                "PACTServer requires starlette. "
                "Install it with: pip install pact-trust-sdk[server]"
            ) from None
    raise AttributeError(f"module 'pact' has no attribute {name!r}")

__all__ = [
    "Agent",
    "Attestation",
    "AttestationStore",
    "DIDResolver",
    "HandshakeRequest",
    "HandshakeResponse",
    "HandshakeResult",
    "KeyPair",
    "Mandate",
    "PACTServer",
    "Pact",
    "PactStatus",
    "TrustEvaluator",
    "create_did",
    "perform_handshake",
    "validate_delegation_chain",
    "validate_did",
    "verify_handshake_response",
]
