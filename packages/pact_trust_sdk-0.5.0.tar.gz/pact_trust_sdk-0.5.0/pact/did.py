"""W3C DID operations for PACT.

Implements did:pact method — self-resolving DIDs derived from Ed25519 public keys,
compatible with did:key but using the pact method namespace.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pact.crypto import KeyPair, multikey_to_public_key, public_key_to_multikey


DID_METHOD = "pact"


def create_did(key_pair: KeyPair) -> str:
    """Create a did:pact DID from a key pair.

    Format: did:pact:<multibase-multicodec-public-key>
    """
    return f"did:{DID_METHOD}:{key_pair.multikey}"


def did_to_public_key(did: str) -> bytes:
    """Extract the raw Ed25519 public key bytes from a did:pact DID."""
    parts = did.split(":")
    if len(parts) != 3 or parts[0] != "did":
        raise ValueError(f"Invalid DID format: {did}")

    method = parts[1]
    if method not in ("pact", "key"):
        raise ValueError(f"Unsupported DID method: {method}")

    multikey = parts[2]
    return multikey_to_public_key(multikey)


def create_did_document(
    did: str,
    key_pair: KeyPair,
    *,
    name: str | None = None,
    service_endpoints: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Create a W3C DID Document for an agent.

    The document contains the public key and optional service endpoints
    for agent communication.
    """
    multikey = key_pair.multikey
    key_id = f"{did}#key-0"

    doc: dict[str, Any] = {
        "@context": [
            "https://www.w3.org/ns/did/v1",
            "https://w3id.org/security/multikey/v1",
        ],
        "id": did,
        "verificationMethod": [
            {
                "id": key_id,
                "type": "Multikey",
                "controller": did,
                "publicKeyMultibase": multikey,
            }
        ],
        "authentication": [key_id],
        "assertionMethod": [key_id],
        "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

    if name:
        doc["name"] = name

    if service_endpoints:
        doc["service"] = service_endpoints
    else:
        doc["service"] = []

    return doc


def resolve_did_document(did: str) -> dict[str, Any]:
    """Resolve a did:pact DID to its DID Document.

    Since did:pact is self-resolving (like did:key), the document can be
    reconstructed from the DID itself. However, this only provides the
    minimal document — the agent's full document with service endpoints
    requires fetching from the agent's endpoint or a registry.
    """
    public_key = did_to_public_key(did)
    multikey = public_key_to_multikey(public_key)
    key_id = f"{did}#key-0"

    return {
        "@context": [
            "https://www.w3.org/ns/did/v1",
            "https://w3id.org/security/multikey/v1",
        ],
        "id": did,
        "verificationMethod": [
            {
                "id": key_id,
                "type": "Multikey",
                "controller": did,
                "publicKeyMultibase": multikey,
            }
        ],
        "authentication": [key_id],
        "assertionMethod": [key_id],
    }


def validate_did(did: str) -> bool:
    """Check if a DID string is valid and parseable."""
    try:
        did_to_public_key(did)
        return True
    except ValueError:
        return False
