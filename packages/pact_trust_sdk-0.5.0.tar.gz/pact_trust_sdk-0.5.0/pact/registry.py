"""Optional Public Registry — agent discovery and lookup.

The registry is NOT required for PACT to work. It provides convenience
for agent discovery — searching by capability, finding endpoints, etc.
The protocol works fully peer-to-peer without any registry.
"""

from __future__ import annotations

import urllib.parse
from typing import Any

import httpx

from pact.crypto import KeyPair, canonical_json, generate_nonce, multibase_encode
from pact.did import did_to_public_key


class RegistryClient:
    """Client for an optional PACT agent registry.

    All write operations require a signed proof-of-control to prevent
    unauthorized registration of DIDs you don't own.
    """

    def __init__(self, registry_url: str) -> None:
        if not registry_url.startswith("https://"):
            raise ValueError("Registry URL must use HTTPS")
        self._url = registry_url.rstrip("/")

    async def register(
        self,
        did: str,
        key_pair: KeyPair,
        *,
        endpoint: str | None = None,
        name: str | None = None,
        capabilities: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Register an agent in the registry.

        Includes a signed proof-of-control to prove DID ownership.
        """
        # Verify the key pair matches the DID
        did_pub = did_to_public_key(did)
        if did_pub != key_pair.public_bytes:
            raise ValueError("Key pair does not match the DID being registered")

        payload: dict[str, Any] = {"did": did}
        if endpoint:
            payload["endpoint"] = endpoint
        if name:
            payload["name"] = name
        if capabilities:
            payload["capabilities"] = capabilities
        if metadata:
            payload["metadata"] = metadata

        # Sign the registration payload as proof-of-control
        nonce = generate_nonce()
        payload["nonce"] = nonce
        proof_bytes = canonical_json(payload)
        signature = key_pair.sign(proof_bytes)
        payload["proof"] = {
            "type": "Ed25519Signature2020",
            "proofValue": multibase_encode(signature),
        }

        async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
            resp = await client.post(f"{self._url}/agents", json=payload)
            resp.raise_for_status()
            return resp.json()

    async def lookup(self, did: str) -> dict[str, Any] | None:
        """Look up an agent by DID."""
        safe_did = urllib.parse.quote(did, safe="")
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
            resp = await client.get(f"{self._url}/agents/{safe_did}")
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            return resp.json()

    async def search(
        self,
        *,
        capability: str | None = None,
        name: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Search for agents by capability or name."""
        params: dict[str, Any] = {"limit": limit}
        if capability:
            params["capability"] = capability
        if name:
            params["name"] = name

        async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
            resp = await client.get(f"{self._url}/agents", params=params)
            resp.raise_for_status()
            return resp.json().get("agents", [])

    async def deregister(self, did: str, key_pair: KeyPair) -> bool:
        """Remove an agent from the registry. Requires proof-of-control."""
        did_pub = did_to_public_key(did)
        if did_pub != key_pair.public_bytes:
            raise ValueError("Key pair does not match the DID")

        nonce = generate_nonce()
        payload = {"did": did, "action": "deregister", "nonce": nonce}
        proof_bytes = canonical_json(payload)
        signature = key_pair.sign(proof_bytes)
        payload["proof"] = {
            "type": "Ed25519Signature2020",
            "proofValue": multibase_encode(signature),
        }

        safe_did = urllib.parse.quote(did, safe="")
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=False) as client:
            resp = await client.post(f"{self._url}/agents/{safe_did}/deregister", json=payload)
            return resp.status_code == 200
