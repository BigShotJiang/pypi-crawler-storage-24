# PACT Python SDK

Trust infrastructure for autonomous AI agents. Implements the [PACT Protocol](https://pact-protocol.org) (Protocol for Agent Credentials and Trust) -- DIDs, mandates, attestations, pacts, and handshakes for machine-to-machine identity and delegation.

## Installation

```bash
pip install pact-trust-sdk
```

Optional extras:

```bash
pip install pact-trust-sdk[server]   # HTTP server (starlette + uvicorn)
pip install pact-trust-sdk[mcp]      # MCP tool integration
```

## Quick Start

```python
from pact import Agent, Mandate, Attestation

# Create an agent identity
agent = Agent.create(name="Wren")
print(agent.did)  # did:pact:z6Mk...

# Issue a delegation mandate
mandate = Mandate.issue(
    issuer=principal.did,
    subject=agent.did,
    scope=["trade:read", "trade:execute"],
    expires_in_days=90,
)

# Create a trust attestation
attestation = agent.attest(
    subject=peer.did,
    interaction_type="task_completion",
    outcome="success",
    metrics={"accuracy": 0.95},
)
```

## Features

The SDK implements all five PACT primitives:

- **Agents** -- Ed25519 key pairs with `did:pact:` decentralized identifiers
- **Mandates** -- Scoped, time-bound delegation from principal to agent
- **Attestations** -- Signed records of interaction outcomes that build trust
- **Pacts** -- Bilateral agreements between agents with lifecycle tracking
- **Handshakes** -- Cryptographic mutual authentication between agents

Plus: DID resolution, delegation chain validation, and trust evaluation.

## Links

- [Documentation](https://pact-protocol.org)
- [Specification](https://github.com/bkauhl3/pact-protocol/blob/main/SPECIFICATION.md)
- [Repository](https://github.com/bkauhl3/pact-protocol)
- [Security & Audit Trail](https://github.com/bkauhl3/pact-protocol/blob/main/SECURITY.md)

## License

Apache 2.0
