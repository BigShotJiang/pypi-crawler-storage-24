"""DTOs for pipeline cost tracking endpoints."""

import datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, Field


# ============================================================================
# Execution Cost DTOs
# ============================================================================


class PipelineExecutionCostSummary(BaseModel):
    """Cost summary for a single pipeline execution.

    Includes breakdown of LLM costs (from agent_executions) and RAG costs
    (from retrieval_logs linked via agent_execution_id).
    """

    pipeline_execution_id: UUID
    llm_cost_usd: Decimal = Field(
        description="Total cost from LLM API calls (agent_executions.total_cost_usd)"
    )
    rag_cost_usd: Decimal = Field(
        description="Total cost from RAG operations (retrieval_logs.total_cost_usd)"
    )
    total_cost_usd: Decimal = Field(description="Sum of llm_cost_usd and rag_cost_usd")
    agent_execution_count: int = Field(
        description="Number of agent executions in this pipeline run"
    )
    retrieval_count: int = Field(
        description="Number of RAG retrievals in this pipeline run"
    )


class ModelCostBreakdown(BaseModel):
    """Cost breakdown by provider and model.

    Groups costs by the provider_key and model_name used in agent executions.
    """

    provider_key: str = Field(
        description="Provider identifier (e.g., 'openrouter', 'anthropic')"
    )
    model_name: str = Field(description="Model name as used by the provider")
    execution_count: int = Field(
        description="Number of agent executions using this model"
    )
    total_tokens: int = Field(description="Total tokens consumed by this model")
    llm_cost_usd: Decimal = Field(description="LLM costs for this model")
    rag_cost_usd: Decimal = Field(
        description="RAG costs associated with executions using this model"
    )
    total_cost_usd: Decimal = Field(description="Sum of llm_cost_usd and rag_cost_usd")


# ============================================================================
# Definition Cost DTOs
# ============================================================================


class PipelineDefinitionCostSummary(BaseModel):
    """Aggregated cost summary for a pipeline definition over a time period.

    Provides execution statistics and cost aggregations for analytics.
    """

    pipeline_definition_id: UUID
    period_start: datetime.datetime = Field(
        description="Start of the aggregation period"
    )
    period_end: datetime.datetime = Field(description="End of the aggregation period")
    execution_count: int = Field(description="Total number of executions in the period")
    completed_count: int = Field(description="Number of completed executions")
    failed_count: int = Field(description="Number of failed executions")
    total_cost_usd: Decimal = Field(description="Total cost across all executions")
    avg_cost_usd: Decimal = Field(description="Average cost per execution")
    min_cost_usd: Decimal | None = Field(
        default=None, description="Minimum execution cost (None if no executions)"
    )
    max_cost_usd: Decimal | None = Field(
        default=None, description="Maximum execution cost (None if no executions)"
    )


class DailyCostEntry(BaseModel):
    """Daily cost aggregation entry for time series data."""

    date: datetime.date = Field(description="Date of the aggregation (UTC)")
    execution_count: int = Field(description="Number of executions on this date")
    total_cost_usd: Decimal = Field(description="Total cost on this date")
    avg_cost_usd: Decimal = Field(description="Average cost per execution on this date")
