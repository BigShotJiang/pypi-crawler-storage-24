"""DTOs for AI model listing."""

from pydantic import BaseModel, Field


class ModelProviderResponse(BaseModel):
    """Provider information for a specific model."""

    provider_key: str = Field(..., description="Provider identifier")
    display_name: str = Field(..., description="Provider friendly name")
    provider_model_name: str = Field(..., description="Provider-specific model name")
    is_active: bool = Field(
        ..., description="Whether this provider-model combination is active"
    )
    priority: int | None = Field(
        default=None,
        description="Provider preference ranking (lower = higher priority)",
    )
    context_window: int | None = Field(
        default=None,
        description="Maximum context size in tokens for this provider",
    )
    max_output_tokens: int | None = Field(
        default=None,
        description="Maximum output tokens for this provider",
    )


class ModelListItemResponse(BaseModel):
    """Individual provider model in list response."""

    provider_key: str = Field(..., description="Provider identifier")
    provider_model_name: str = Field(..., description="Exact model name from provider")
    description: str | None = Field(default=None, description="Model description")
    is_active: bool = Field(..., description="Whether this provider model is active")
    priority: int | None = Field(
        default=None,
        description="Provider preference ranking (lower = higher priority)",
    )
    context_window: int | None = Field(
        default=None, description="Maximum context size in tokens"
    )
    max_output_tokens: int | None = Field(
        default=None, description="Maximum output tokens"
    )
    input_modalities: list[str] = Field(..., description="Supported input types")
    output_modalities: list[str] = Field(..., description="Supported output types")


class ListModelsResponse(BaseModel):
    """Response for list models endpoint."""

    models: list[ModelListItemResponse] = Field(..., description="List of models")
    total_count: int = Field(..., description="Total matching models across all pages")
    has_more: bool = Field(
        default=False,
        description="Whether additional results exist beyond this page",
    )
    limit: int = Field(
        default=100,
        ge=1,
        description="Page size used to fetch this result set",
    )
    offset: int = Field(
        default=0,
        ge=0,
        description="Zero-based offset used to fetch this result set",
    )
