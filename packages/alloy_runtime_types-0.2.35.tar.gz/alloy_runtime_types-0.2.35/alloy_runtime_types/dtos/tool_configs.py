"""DTOs for tool configuration operations."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field

from alloy_runtime_types.enums.ownership_scope import OwnershipScope


class CreateToolConfigRequest(BaseModel):
    """Request to create a reusable tool configuration."""

    name: str = Field(
        min_length=1,
        max_length=255,
        description="Human-readable name for this tool configuration",
    )
    tool_id: str = Field(
        min_length=1,
        description="The tool this configuration applies to (e.g., 'rag_search')",
    )
    config: dict[str, Any] = Field(
        description="Tool configuration. Validated against tool's parameter_schema.",
    )
    description: str | None = Field(
        default=None,
        description="Optional description of what this configuration is for",
    )
    scope: OwnershipScope = Field(
        default=OwnershipScope.ORGANIZATION,
        description="Ownership scope: user, organization, or global. Defaults to organization scope when omitted.",
    )


class ToolConfigResponse(BaseModel):
    """Full tool config response used for create, get, update, and delete operations."""

    id: UUID
    name: str
    slug: str
    tool_id: str
    config: dict[str, Any]
    description: str | None
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime
    updated_at: datetime


# Type aliases for operation-specific responses (all have identical structure)
CreateToolConfigResponse = ToolConfigResponse
GetToolConfigResponse = ToolConfigResponse
UpdateToolConfigResponse = ToolConfigResponse
DeletedToolConfigResponse = ToolConfigResponse


# ============================================================================
# List Tool Configs DTOs
# ============================================================================


class ToolConfigSummary(BaseModel):
    """Summary of a tool config for list responses."""

    id: UUID
    name: str
    slug: str
    tool_id: str
    description: str | None
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime
    updated_at: datetime


class ListToolConfigsResponse(BaseModel):
    """Response for listing tool configs."""

    tool_configs: list[ToolConfigSummary]
    total: int


# ============================================================================
# Update Tool Config DTOs
# ============================================================================


class UpdateToolConfigRequest(BaseModel):
    """Request to update a tool configuration.

    All fields are optional - None means no change to that field.
    """

    name: str | None = Field(
        default=None,
        min_length=1,
        max_length=255,
        description="New name for the tool config",
    )
    config: dict[str, Any] | None = Field(
        default=None,
        description="New configuration. Validated against tool's parameter_schema.",
    )
    description: str | None = Field(
        default=None,
        description="Updated description. Set to empty string to clear.",
    )


# ============================================================================
# Delete Tool Config DTOs
# ============================================================================


class DeleteToolConfigResponse(BaseModel):
    """Response for deleting a tool config."""

    deleted_tool_config: DeletedToolConfigResponse
