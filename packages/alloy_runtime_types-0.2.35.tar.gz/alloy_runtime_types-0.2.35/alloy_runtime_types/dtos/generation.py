"""DTOs for text generation endpoints."""

import ipaddress
import json
from datetime import datetime
from decimal import Decimal
from typing import Any, Literal, Self
from urllib.parse import urlparse
from uuid import UUID

from pydantic import BaseModel, Field, field_validator, model_validator

from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.enums.schema_enums import SchemaFormat

type ReasoningEffort = Literal["none", "minimal", "low", "medium", "high", "xhigh"]


REASONING_EFFORT_VALUES: tuple[ReasoningEffort, ...] = (
    "none",
    "minimal",
    "low",
    "medium",
    "high",
    "xhigh",
)


class GenerationParameters(BaseModel):
    """Type-safe generation parameters for AI models.

    These parameters can be used in:
    - Agent configuration (stored in agent.default_parameters)
    - Direct generation requests (passed per-request)

    All parameters are optional and provider-specific support varies.
    """

    # Core generation parameters
    temperature: float | None = Field(
        default=None,
        ge=0.0,
        le=2.0,
        description="Sampling temperature (0.0-2.0). Higher values = more random.",
    )
    max_tokens: int | None = Field(
        default=None,
        gt=0,
        description="Maximum number of tokens to generate",
    )

    # Advanced sampling parameters
    top_p: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Nucleus sampling parameter (0.0-1.0)",
    )
    top_k: int | None = Field(
        default=None,
        gt=0,
        description="Top-k sampling parameter",
    )

    # Penalty parameters
    frequency_penalty: float | None = Field(
        default=None,
        ge=-2.0,
        le=2.0,
        description="Frequency penalty (-2.0 to 2.0)",
    )
    presence_penalty: float | None = Field(
        default=None,
        ge=-2.0,
        le=2.0,
        description="Presence penalty (-2.0 to 2.0)",
    )

    reasoning_effort: ReasoningEffort | None = Field(
        default=None,
        description="Reasoning effort level for reasoning-capable models.",
    )

    # Reproducibility
    seed: int | None = Field(
        default=None,
        description="Random seed for reproducible outputs",
    )

    # Stop sequences
    stop: str | list[str] | None = Field(
        default=None,
        description="Stop sequences - generation stops when encountered",
    )

    # Logging parameters
    logprobs: bool | None = Field(
        default=None,
        description="Include log probabilities in response",
    )
    top_logprobs: int | None = Field(
        default=None,
        gt=0,
        le=20,
        description="Number of top log probabilities to return (1-20)",
    )

    # Tracking
    user: str | None = Field(
        default=None,
        description="End-user ID for tracking and abuse monitoring",
    )


# =============================================================================
# Output Schema Types (Union)
# =============================================================================


class InlineOutputSchema(BaseModel):
    """Inline output schema definition.

    Use this when you want to define a schema directly in the request
    without creating a reusable schema in the database.

    Examples:
        # JSON Schema for structured output
        InlineOutputSchema(
            schema_format=SchemaFormat.JSON_SCHEMA,
            schema_definition='{"type": "object", "properties": {"name": {"type": "string"}}}'
        )

        # Regex pattern for extraction
        InlineOutputSchema(
            schema_format=SchemaFormat.REGEX,
            schema_definition="```python\\n([\\s\\S]*?)\\n```"
        )
    """

    schema_format: SchemaFormat = Field(
        description="Type of schema: json_schema or regex"
    )
    schema_definition: str = Field(
        min_length=1,
        description="For json_schema: JSON string of the schema. For regex: the pattern string.",
    )


class SchemaReference(BaseModel):
    """Reference to an existing schema by ID or name.

    Use this when you have a pre-defined schema in the database.
    Names are resolved with priority: user-owned > org-owned > global.

    Examples:
        # Reference by UUID
        SchemaReference(schema_id="019377f5-1234-7000-8000-000000000001")

        # Reference by name
        SchemaReference(schema_id="my-response-schema")
    """

    schema_id: str | UUID = Field(
        description="Schema identifier - can be UUID or schema name. "
        "Names are resolved with priority: user-owned > org-owned > global."
    )


OutputSchemaSource = InlineOutputSchema | SchemaReference
"""Union for output schema specification.

Either define a schema inline (InlineOutputSchema) or reference an existing
schema by ID or name (SchemaReference). Pydantic automatically determines
which type based on the fields present.

JSON Examples:
    # Inline JSON Schema
    {"schema_format": "json_schema", "schema_definition": "{\\"type\\": \\"object\\"}"}

    # Inline Regex
    {"schema_format": "regex", "schema_definition": "```python\\\\n([\\\\s\\\\S]*?)\\\\n```"}

    # Reference by UUID
    {"schema_id": "019377f5-1234-7000-8000-000000000001"}

    # Reference by name
    {"schema_id": "my-response-schema"}
"""


# =============================================================================
# Model Source Types (Union)
# =============================================================================


class AgentSource(BaseModel):
    """Model source using a pre-configured agent.

    Use this when you want to leverage an agent's pre-configured settings
    (model, system instruction, tools, etc.). Generation parameters can
    optionally override the agent's defaults.

    Example:
        AgentSource(agent="my-agent")
        AgentSource(agent="my-agent", generation_params=GenerationParameters(temperature=0.9))
    """

    agent: str | UUID = Field(
        description="Agent identifier - can be UUID or agent name. "
        "Names are resolved with priority: user-owned > org-owned > global."
    )
    generation_params: GenerationParameters | None = Field(
        default=None,
        description="Generation parameters to override agent defaults (temperature, max_tokens, etc.)",
    )


class DirectModelSource(BaseModel):
    """Model source using direct provider/model specification.

    Use this when you want full control over the model and parameters
    without using a pre-configured agent.

    Example:
        DirectModelSource(
            provider_key=Provider.OPENAI,
            provider_model_name="gpt-4o",
            generation_params=GenerationParameters(temperature=0.7, max_tokens=1000),
        )
    """

    provider_key: Provider = Field(description="AI provider (e.g., openai, anthropic)")
    provider_model_name: str = Field(
        min_length=1,
        description="Model identifier (e.g., gpt-4o, claude-3-5-sonnet-20241022)",
    )
    generation_params: GenerationParameters | None = Field(
        default=None,
        description="Generation parameters (temperature, max_tokens, etc.)",
    )
    request_headers: dict[str, str] | None = Field(
        default=None,
        description="Custom HTTP headers to pass to the AI provider. "
        "Useful for provider-specific features like anthropic-beta headers.",
    )


ModelSource = AgentSource | DirectModelSource
"""Union for model source configuration.

Either use a pre-configured agent (AgentSource) or specify a model directly
(DirectModelSource). Pydantic automatically determines which type based on
the fields present - no discriminator needed.

JSON Examples:
    # Using an agent
    {"agent": "my-agent"}

    # Using an agent with params override
    {"agent": "my-agent", "generation_params": {"temperature": 0.9}}

    # Using direct model
    {"provider_key": "openai", "provider_model_name": "gpt-4o"}

    # Using direct model with params
    {
        "provider_key": "openai",
        "provider_model_name": "gpt-4o",
        "generation_params": {"temperature": 0.7, "max_tokens": 1000}
    }
"""


MAX_USER_METADATA_BYTES = 16_384
BLOCKED_WEBHOOK_HOSTNAMES = frozenset({"localhost"})


class GenerateTextRequest(BaseModel):
    """Request for text generation endpoint.

    Examples:
        # Using an agent
        GenerateTextRequest(
            model_source=AgentSource(agent="my-agent"),
            user_message="Hello",
        )

        # Using an agent with generation params override
        GenerateTextRequest(
            model_source=AgentSource(
                agent="my-agent",
                generation_params=GenerationParameters(temperature=0.9),
            ),
            user_message="Hello",
        )

        # Using direct model
        GenerateTextRequest(
            model_source=DirectModelSource(
                provider_key=Provider.OPENAI,
                provider_model_name="gpt-4o",
                generation_params=GenerationParameters(temperature=0.7),
            ),
            user_message="Hello",
        )
    """

    # Model Source (required)
    model_source: ModelSource = Field(
        description="Model source configuration. Use AgentSource for agents or "
        "DirectModelSource for direct model access.",
    )

    # User Message (mutually exclusive - ONE required)
    user_message: str | None = Field(
        default=None,
        min_length=1,
        description="Direct user message. If contains Jinja2 syntax ({{ }}, {% %}), "
        "will be rendered as a template using user_message_variables. "
        "Supports {% include 'fragment_name' %} to include DB-stored templates.",
    )
    user_message_template: str | UUID | None = Field(
        default=None,
        description="User message template identifier - can be UUID or template name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    user_message_variables: dict[str, Any] | None = Field(
        default=None,
        description="Variables for user_message_template OR for inline Jinja syntax "
        "in user_message. Also passed to any included fragments.",
    )

    # System Instruction (optional, mutually exclusive)
    system_instruction: str | None = Field(
        default=None,
        min_length=1,
        description="Direct system instruction. If contains Jinja2 syntax ({{ }}, {% %}), "
        "will be rendered as a template using system_instruction_variables. "
        "Supports {% include 'fragment_name' %} to include DB-stored templates. "
        "Only available in direct model mode (not with agent).",
    )
    system_instruction_template: str | UUID | None = Field(
        default=None,
        description="System instruction template identifier - can be UUID or template name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    system_instruction_variables: dict[str, Any] | None = Field(
        default=None,
        description="Variables for system_instruction_template OR for inline Jinja syntax "
        "in system_instruction. Also passed to any included fragments.",
    )

    # Tools (for direct model usage)
    tools: list[Any] | None = None

    # Output Schema (for direct model usage)
    output_schema: OutputSchemaSource | None = Field(
        default=None,
        description="Output schema for structured output. Can be an inline definition "
        "(InlineOutputSchema) or a reference to an existing schema (SchemaReference). "
        "JSON schema output cannot be used with streaming. "
        "Cannot be specified when using an agent (agents have their own output schema).",
    )

    # Context
    chat_session_id: UUID | None = None
    parent_execution_id: UUID | None = None
    chat_history: list[dict[str, str]] | None = None
    max_history_messages: int | None = Field(
        default=None,
        gt=0,
        le=1000,
        description="Limit chat history to N most recent messages",
    )

    # Regeneration
    regenerate: bool = Field(
        default=False,
        description="If True, regenerate response to the last user message in the session. "
        "Requires chat_session_id. Previous assistant response will be excluded from context.",
    )

    # Streaming Control
    stream: bool = False

    # Tags
    tags: list[str] = Field(
        default_factory=list,
        description="Tag paths for generated content (e.g., ['marketing.email'])",
    )

    # External ID
    external_id: str | None = Field(
        default=None,
        description="Optional caller-provided identifier for idempotency and correlation. "
        "Must be unique per organization. Use to track processed items.",
    )

    # Pipeline Execution ID
    pipeline_execution_id: UUID | None = Field(
        default=None,
        description="Pipeline execution ID for lineage tracking. "
        "Set automatically by SDK for pipeline-originated calls.",
    )

    # Billing Project
    billing_project_id: str | UUID | None = Field(
        default=None,
        description="Optional billing project identifier for cost tracking and aggregation. "
        "Can be UUID or project name within the authenticated organization.",
    )

    # Execution Purpose
    execution_purpose: str | None = Field(
        default=None,
        min_length=1,
        description="Label for why this execution exists (e.g., 'pipeline_step'). "
        "Defaults to 'agent' if not specified. Auto-set to 'pipeline_step' for pipeline executions.",
    )

    # Async Generation
    run_async: bool = Field(
        default=False,
        alias="async",
        description="If True, queue generation for background processing and return immediately. "
        "Returns 202 Accepted with execution_id for polling. Cannot be used with stream=True.",
    )
    user_metadata: dict[str, Any] | None = Field(
        default=None,
        description="Optional user-provided metadata attached to the async execution. "
        "Returned in status polling responses and webhook payloads.",
    )
    webhook_url: str | None = Field(
        default=None,
        max_length=2048,
        description="Optional webhook URL to receive completion notification. "
        "POST request with AsyncGenerationStatusResponse body when generation completes.",
    )

    @field_validator("webhook_url")
    @classmethod
    def validate_webhook_url(cls, value: str | None) -> str | None:
        if value is None:
            return value

        parsed = urlparse(value)
        if parsed.scheme.lower() != "https":
            raise ValueError("webhook_url must use HTTPS scheme")

        hostname = parsed.hostname
        if hostname is None:
            raise ValueError("webhook_url must have a valid hostname")

        normalized_hostname = hostname.rstrip(".").lower()
        if normalized_hostname in BLOCKED_WEBHOOK_HOSTNAMES:
            raise ValueError(
                "webhook_url must not target private or reserved addresses"
            )

        try:
            ip_address = ipaddress.ip_address(normalized_hostname)
        except ValueError:
            return value

        if (
            ip_address.is_private
            or ip_address.is_reserved
            or ip_address.is_loopback
            or ip_address.is_link_local
            or ip_address.is_unspecified
        ):
            raise ValueError(
                "webhook_url must not target private or reserved addresses"
            )

        return value

    @field_validator("user_metadata")
    @classmethod
    def validate_user_metadata_size(
        cls,
        value: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        if value is None:
            return value

        serialized = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        if len(serialized.encode("utf-8")) > MAX_USER_METADATA_BYTES:
            raise ValueError(
                "user_metadata must not exceed "
                f"{MAX_USER_METADATA_BYTES} bytes when serialized"
            )
        return value

    @model_validator(mode="after")
    def validate_stream_and_async(self) -> Self:
        """Streaming and async generation are mutually exclusive."""
        if self.stream and self.run_async:
            raise ValueError(
                "stream=True and async=True are mutually exclusive. "
                "Use streaming for real-time responses or async for background processing."
            )
        return self


class TokenUsageDTO(BaseModel):
    """Token usage information."""

    input_tokens: int
    output_tokens: int
    cache_creation_tokens: int | None = None
    cache_read_tokens: int | None = None


class CostBreakdownDTO(BaseModel):
    """Cost breakdown for execution."""

    input_cost_usd: Decimal
    output_cost_usd: Decimal
    cache_cost_usd: Decimal | None = None
    total_cost_usd: Decimal


class GenerateTextResponse(BaseModel):
    """Response from non-streaming text generation."""

    execution_id: UUID
    chat_session_id: UUID
    output_text: str
    content_part_id: UUID
    structured_output: dict[str, Any] | None = None
    usage: TokenUsageDTO
    cost: CostBreakdownDTO
    finish_reason: str
    provider_key: str
    provider_model_name: str
    # Fallback tracking fields
    actual_provider_key: str | None = Field(
        default=None,
        description="Actual provider used if fallback was triggered (None if primary succeeded)",
    )
    actual_provider_model_name: str | None = Field(
        default=None,
        description="Actual model used if fallback was triggered (None if primary succeeded)",
    )
    used_fallback: bool = Field(
        default=False,
        description="True if a fallback model was used (primary model failed)",
    )
    tags: list[str]
    external_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class GenerateTextStreamChunk(BaseModel):
    """Individual chunk from streaming generation (SSE payload)."""

    execution_id: UUID
    sequence: int
    content: str
    chunk_type: str = "text"  # text, thinking, metadata, error
    is_first: bool = False
    reasoning_content: str | None = (
        None  # Reasoning/thinking content for models that support it
    )
    metadata: dict[str, Any] = Field(default_factory=dict)


# =============================================================================
# Async Generation DTOs
# =============================================================================


# Async generation status type alias
AsyncGenerationStatus = Literal[
    "pending", "running", "completed", "failed", "cancelled", "timeout"
]

# Terminal statuses - indicates polling should stop
TERMINAL_ASYNC_STATUSES: frozenset[AsyncGenerationStatus] = frozenset(
    {"completed", "failed", "cancelled", "timeout"}
)


def is_terminal_async_status(status: AsyncGenerationStatus) -> bool:
    """Check if an async generation status is terminal (polling should stop)."""
    return status in TERMINAL_ASYNC_STATUSES


class AsyncGenerationSubmitResponse(BaseModel):
    """Response returned when async generation is submitted (HTTP 202).

    Returned when run_async=True in GenerateTextRequest. The client should
    poll GET /generate/{execution_id} for status updates.
    """

    execution_id: UUID
    status: str = "pending"
    message: str = "Generation queued"
    user_metadata: dict[str, Any] | None = None
    external_id: str | None = None
    webhook_signing_secret: str | None = None


class AsyncGenerationStatusResponse(BaseModel):
    """Response from polling async generation status.

    Returned by GET /generate/{execution_id}. Fields are populated
    as the generation progresses. Check is_terminal to know when to stop polling.
    """

    execution_id: UUID
    status: AsyncGenerationStatus
    is_terminal: bool = Field(
        description="True when generation reached terminal status (completed, failed, cancelled, timeout). "
        "Clients should stop polling when this is True."
    )
    # Populated when completed
    chat_session_id: UUID | None = None
    output_text: str | None = None
    structured_output: dict[str, Any] | None = None
    usage: TokenUsageDTO | None = None
    cost: CostBreakdownDTO | None = None
    finish_reason: str | None = None
    provider_key: str | None = None
    provider_model_name: str | None = None
    # Timing
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = None
    # User context
    user_metadata: dict[str, Any] | None = None
    external_id: str | None = None
    # Error info (when failed)
    error_message: str | None = None
    error_type: str | None = None


class AsyncGenerationCancelResponse(BaseModel):
    """Response from cancelling an async generation.

    Returned by DELETE /generate/{execution_id}. Only pending or running
    generations can be cancelled.
    """

    execution_id: UUID
    status: str = "cancelled"
    message: str = "Generation cancelled"
    was_running: bool = Field(
        description="True if generation was actively running when cancelled. "
        "False if it was still pending in queue."
    )
