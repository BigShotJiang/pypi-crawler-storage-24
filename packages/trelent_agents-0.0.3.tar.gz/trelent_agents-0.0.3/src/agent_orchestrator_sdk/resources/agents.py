"""Agents resource."""

from __future__ import annotations

from .._base import BaseResource
from ..types import Agent, AgentCreate


class AgentsResource(BaseResource):

    def register(self, image: str, name: str) -> Agent:
        body = AgentCreate(image=image, name=name)
        resp = self._session.post(self._url("/agents"), data=body.model_dump_json())
        self._raise_for_status(resp)
        return Agent.model_validate(resp.json())

    def list(self) -> list[Agent]:
        resp = self._session.get(self._url("/agents"))
        self._raise_for_status(resp)
        return [Agent.model_validate(a) for a in resp.json()]

    def get(self, agent_id: str) -> Agent:
        resp = self._session.get(self._url(f"/agents/{agent_id}"))
        self._raise_for_status(resp)
        return Agent.model_validate(resp.json())
