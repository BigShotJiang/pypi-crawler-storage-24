"""Images resource."""

from __future__ import annotations

from .._base import BaseResource
from ..types import RegistryImage


class ImagesResource(BaseResource):

    def list(self) -> list[RegistryImage]:
        resp = self._session.get(self._url("/images"))
        self._raise_for_status(resp)
        return [RegistryImage.model_validate(i) for i in resp.json()]
