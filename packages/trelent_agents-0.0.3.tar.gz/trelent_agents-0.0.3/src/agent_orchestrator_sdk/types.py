"""Pydantic types mirroring the Agent Orchestration API schema."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


# --- Enums ---


class RunStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


# --- Common ---


class HealthResponse(BaseModel):
    status: str


class CancelRunResponse(BaseModel):
    status: str


# --- Images ---


class ImageRef(BaseModel):
    name: str
    tag: str


class RegistryImage(BaseModel):
    name: str
    tags: list[str]


# --- Agents ---


class AgentCreate(BaseModel):
    image: str = Field(..., description="Agent image reference (e.g. example-agent:latest)")
    name: str = Field(..., description="Human-readable agent name")


class Agent(BaseModel):
    id: str
    name: str
    image: ImageRef
    created_at: datetime


# --- Connector specs ---


class RunSnapshotSourceSpec(BaseModel):
    target: str = "run_snapshot"
    include: str | list[str] = Field(default_factory=lambda: ["/workspace/**"])
    exclude: str | list[str] = Field(default_factory=list)
    run_id: str | None = None


class DataBallSourceSpec(BaseModel):
    target: str = "data_ball"
    data: str


class S3DumpDrainSpec(BaseModel):
    target: str = "s3_dump"
    bucket: str | None = None
    prefix: str | None = None


class AgentWorkspaceDrainSpec(BaseModel):
    target: str = "agent_workspace"


class ExportConnectorSpec(BaseModel):
    source: RunSnapshotSourceSpec | None = None
    drain: S3DumpDrainSpec


class ImportConnectorSpec(BaseModel):
    source: RunSnapshotSourceSpec | DataBallSourceSpec | None = None
    drain: AgentWorkspaceDrainSpec


# --- Runs ---


class RunResult(BaseModel):
    run_id: str
    status: str
    output: str | None = None


class WorkflowIds(BaseModel):
    infra: str
    agent: str


class OutputFile(BaseModel):
    path: str
    presigned_url: str | None = None


class FileOutput(BaseModel):
    delivery: str
    files: list[OutputFile]


class RunCreate(BaseModel):
    agent_id: str
    prompt: str
    model: str = Field(default="gpt-5.2", description="OpenAI model to use")
    openai_api_key: str | None = Field(default=None, description="User-supplied OpenAI API key")
    input_files: list[str] = Field(default_factory=list)
    timeout_seconds: int = Field(default=3600, ge=60, le=86400)
    import_connectors: list[ImportConnectorSpec] = Field(default_factory=list)
    export_connectors: list[ExportConnectorSpec] = Field(default_factory=list)


class RunResumeRequest(BaseModel):
    prompt: str
    model: str = Field(default="gpt-5.2", description="OpenAI model to use")
    openai_api_key: str | None = Field(default=None, description="User-supplied OpenAI API key")
    timeout_seconds: int = Field(default=3600, ge=60, le=86400)
    import_connectors: list[ImportConnectorSpec] = Field(default_factory=list)
    export_connectors: list[ExportConnectorSpec] = Field(default_factory=list)


class Run(BaseModel):
    run_id: str
    agent_id: str
    parent_run_id: str | None = None
    prompt: str
    model: str
    status: RunStatus
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    result: RunResult | None = None
    file_outputs: list[FileOutput] = Field(default_factory=list)
    error: str | None = None
    workflow_ids: WorkflowIds | None = None


class RunStatusResponse(BaseModel):
    run_id: str
    status: RunStatus


# --- Checkpoints ---


class ChatHistoryEntry(BaseModel):
    model_config = ConfigDict(extra="allow")


class CheckpointResponse(BaseModel):
    checkpoint_id: str
    index: int
    layer_sha: str
    s3_path: str
    created_at: datetime
    download_url: str | None = None
    chat_history: list[ChatHistoryEntry] | None = None


# --- Validation errors ---


class ValidationErrorItem(BaseModel):
    loc: list[str | int]
    msg: str
    type: str


class HTTPValidationError(BaseModel):
    detail: list[ValidationErrorItem] = Field(default_factory=list)
