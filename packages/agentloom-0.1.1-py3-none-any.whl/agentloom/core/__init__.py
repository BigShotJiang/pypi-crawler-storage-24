"""Core workflow engine components."""
