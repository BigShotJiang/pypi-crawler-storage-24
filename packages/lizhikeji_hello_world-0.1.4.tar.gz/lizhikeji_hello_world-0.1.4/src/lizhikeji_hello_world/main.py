def say_hello():
    print(f"Hello, World! 砺智科技!")