# mylib/core.py
from typing import Union


def greet(name: str) -> str:
    """向指定名称的人发送问候"""
    return f"Hello, {name}! 这是我用 Python 制作的开源库~"


def multiply(a: Union[int, float], b: Union[int, float]) -> Union[int, float]:
    """计算两个数的乘积"""
    return a * b


def process_atmospheric_data(temp: float, humidity: float) -> dict:
    """示例：处理大气数据"""
    return {
        "temperature": round(temp, 2),
        "humidity": round(humidity, 2),
        "status": "processed"
    }
