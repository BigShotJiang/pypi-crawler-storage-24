# mylib/__init__.py
from .core import greet, multiply, process_atmospheric_data

__version__ = "0.0.2"
__author__ = "dkj"
__description__ = "一个用于大气数据处理的 Python 示例库"