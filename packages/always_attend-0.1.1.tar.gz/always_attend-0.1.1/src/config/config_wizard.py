#!/usr/bin/env python3
"""
 █████╗ ██╗     ██╗    ██╗ █████╗ ██╗   ██╗███████╗
██╔══██╗██║     ██║    ██║██╔══██╗╚██╗ ██╔╝██╔════╝
███████║██║     ██║ █╗ ██║███████║ ╚████╔╝ ███████╗
██╔══██║██║     ██║███╗██║██╔══██║  ╚██╔╝  ╚════██║
██║  ██║███████╗╚███╔███╔╝██║  ██║   ██║   ███████║
╚═╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝

 █████╗ ████████╗████████╗███████╗███╗   ██╗██████╗
██╔══██╗╚══██╔══╝╚══██╔══╝██╔════╝████╗  ██║██╔══██╗
███████║   ██║      ██║   █████╗  ██╔██╗ ██║██║  ██║
██╔══██║   ██║      ██║   ██╔══╝  ██║╚██╗██║██║  ██║
██║  ██║   ██║      ██║   ███████╗██║ ╚████║██████╔╝
╚═╝  ╚═╝   ╚═╝      ╚═╝   ╚══════╝╚═╝  ╚═══╝╚═════╝
src/config/config_wizard.py
Interactive configuration wizard for Always Attend.
"""

import os
import sys
import shutil
import getpass
from pathlib import Path
from typing import Dict, Optional

from always_attend.paths import default_env_template, env_file as default_env_file, env_template_file, setup_sentinel_file
from utils.logger import logger

class ConfigWizard:
    """Interactive configuration wizard for first-time setup"""
    
    def __init__(self, env_file: str | None = None):
        self.env_file = str(default_env_file() if env_file is None else Path(env_file).expanduser())
        self.config = {}
        
    def run(self) -> bool:
        """Run the configuration wizard"""
        print("\n" + "="*60)
        print("🎯 Welcome to Always Attend Configuration Wizard")
        print("="*60)
        
        # Ensure .env file exists by copying from .env.example
        self._ensure_env_file()
        
        # Language selection first
        print("\n" + "🌍 Language Selection".center(60, "-"))
        self._configure_language()
        
        # Check existing configuration
        existing_config = self._load_existing_config()
        
        # Basic credentials
        print("\n" + "🔐 Authentication Setup".center(60, "-"))
        self._configure_credentials()
        
        # Gmail/OCR/GitHub features removed
        
        # Browser configuration
        print("\n" + "🌐 Browser Settings".center(60, "-"))
        self._configure_browser()
        
        # UI preferences
        print("\n" + "🎨 Interface Style".center(60, "-"))
        self._configure_ui()
            
        # Save configuration
        if self.config:
            self._save_config()
            print(f"\n✅ Configuration saved to {self.env_file}")
            
        print("\n" + "🎉 Setup Complete!".center(60, "="))
        print("\nYou can now run the attendance automation:")
        print("  attend")
        print("\nOr test with dry run:")
        print("  attend --dry-run")
        
        self.mark_setup_complete()
        return True
        
    def _ensure_env_file(self) -> None:
        """Ensure .env file exists by copying from .env.example if needed"""
        env_example = env_template_file()
        env_example_path = str(env_example) if env_example is not None else None
        Path(self.env_file).parent.mkdir(parents=True, exist_ok=True)
        
        if not os.path.exists(self.env_file):
            if env_example_path and os.path.exists(env_example_path):
                try:
                    shutil.copy2(env_example_path, self.env_file)
                    logger.info(f"Created {self.env_file} from {env_example_path}")
                    print(f"✅ Created {self.env_file} from template")
                except Exception as e:
                    logger.error(f"Failed to copy {env_example_path} to {self.env_file}: {e}")
                    with open(self.env_file, 'w', encoding='utf-8') as f:
                        f.write(default_env_template())
                    print(f"⚠️ Created minimal {self.env_file} file")
            else:
                logger.warning("Configuration template not found, creating minimal %s", self.env_file)
                with open(self.env_file, 'w', encoding='utf-8') as f:
                    f.write(default_env_template())
                print(f"⚠️ Created minimal {self.env_file} file")
        else:
            logger.debug(f"{self.env_file} already exists")
        
    def _load_existing_config(self) -> Dict[str, str]:
        """Load existing configuration from .env file"""
        config = {}
        if os.path.exists(self.env_file):
            try:
                with open(self.env_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#') and '=' in line:
                            key, value = line.split('=', 1)
                            # Remove quotes if present
                            value = value.strip().strip('"\'')
                            if value:
                                config[key.strip()] = value
            except Exception as e:
                logger.warning(f"Error reading existing config: {e}")
        return config
        
    # Gmail/OCR removed
        
    def _configure_language(self) -> None:
        """Configure language preference"""
        from utils.localization import get_available_languages, create_language_menu, set_language
        
        print("\n🌍 Choose your preferred language:")
        print(create_language_menu())
        
        try:
            available_langs = list(get_available_languages().keys())
            choice = input("\nEnter your choice (1-3): ").strip()
            
            if choice in ['1', '2', '3']:
                lang_index = int(choice) - 1
                if 0 <= lang_index < len(available_langs):
                    selected_lang = available_langs[lang_index]
                    set_language(selected_lang)
                    self.config['LANGUAGE_PREFERENCE'] = selected_lang
                    print(f"✅ Language set to: {get_available_languages()[selected_lang]}")
            else:
                print("📝 Using default language (English)")
                self.config['LANGUAGE_PREFERENCE'] = 'en'
                
        except (ValueError, EOFError, KeyboardInterrupt):
            print("📝 Using default language (English)")
            self.config['LANGUAGE_PREFERENCE'] = 'en'
    
    def _configure_credentials(self) -> None:
        """Configure basic authentication"""
        print("\n🔐 Enter your university credentials:")
        print("This will be used to log into the attendance portal.")
        
        # Username/Email
        username = input("\nUsername/Email: ").strip()
        if username:
            self.config['USERNAME'] = username
            # Automatically set SCHOOL_EMAIL if it looks like an email
            if '@' in username:
                self.config['SCHOOL_EMAIL'] = username
        
        # Password (hidden input)
        password = getpass.getpass("Password: ")
        if password:
            self.config['PASSWORD'] = password
            
        # Portal URL (default to Monash)
        print("\nPortal URL:")
        print("1) Monash University Malaysia (https://attendance.monash.edu.my)")
        print("2) Other university")
        
        portal_choice = input("\nChoose (1-2): ").strip()
        if portal_choice == '1':
            self.config['PORTAL_URL'] = 'https://attendance.monash.edu.my'
            print("✅ Using Monash University Malaysia portal")
        else:
            portal_url = input("Enter your portal URL: ").strip()
            if portal_url:
                self.config['PORTAL_URL'] = portal_url
                
    def _configure_browser(self) -> None:
        """Configure browser settings"""
        print("\n🌐 Browser Configuration:")
        print("For better compatibility, we recommend using your system browser.")
        
        print("\n1) Use system Chrome (Recommended)")
        print("2) Use system Edge")  
        print("3) Use Playwright's Chrome")
        print("4) Use Firefox")
        
        browser_choice = input("\nChoose (1-4): ").strip()
        
        if browser_choice == '1':
            self.config['BROWSER'] = 'chromium'
            self.config['BROWSER_CHANNEL'] = 'chrome'
            print("✅ Using system Chrome browser")
        elif browser_choice == '2':
            self.config['BROWSER'] = 'chromium'
            self.config['BROWSER_CHANNEL'] = 'msedge'
            print("✅ Using system Edge browser")
        elif browser_choice == '3':
            self.config['BROWSER'] = 'chromium'
            self.config['BROWSER_CHANNEL'] = ''
            print("✅ Using Playwright's Chrome (requires: playwright install)")
        elif browser_choice == '4':
            self.config['BROWSER'] = 'firefox'
            self.config['BROWSER_CHANNEL'] = ''
            print("✅ Using Firefox browser")
        else:
            # Default to system Chrome
            self.config['BROWSER'] = 'chromium'
            self.config['BROWSER_CHANNEL'] = 'chrome'
            print("✅ Using system Chrome browser (default)")
    
    def _configure_ui(self) -> None:
        """Configure CLI UI preferences."""
        print("\nDo you prefer the new fancy animated interface?")
        print("You can switch styles any time by editing CLI_STYLE in .env.")
        
        preference = input("\nEnjoy fancy UI with animations? (Y/n): ").strip().lower()
        if preference in ("", "y", "yes"):
            self.config["CLI_STYLE"] = "fancy"
            self.config["CLI_PROGRESS_RICH"] = "1"
            print("✨ Fancy Rich UI enabled (typewriter banner + live progress).")
            return
        
        print("\nPick your preferred style:")
        print("1) Simple — colored banner without animations")
        print("2) Minimal — plain text, no animations")
        style_choice = input("\nChoose (1-2): ").strip()
        
        if style_choice == "2":
            self.config["CLI_STYLE"] = "minimal"
            self.config["CLI_PROGRESS_RICH"] = "0"
            print("📄 Minimal UI selected.")
        else:
            self.config["CLI_STYLE"] = "simple"
            self.config["CLI_PROGRESS_RICH"] = "1"
            print("✅ Simple UI selected (no fancy animation).")
        
    def _configure_ocr(self) -> bool:
        """Legacy OCR config removed; no-op."""
        return False
                
    # Gemini/OpenAI setup removed
            
    def _configure_github_fallback(self) -> None:
        """Legacy GitHub fallback removed; no-op."""
        return None
            
    # Gmail/OCR removed
            
    def _save_config(self) -> None:
        """Save configuration to .env file"""
        try:
            # Read existing content
            existing_lines = []
            if os.path.exists(self.env_file):
                with open(self.env_file, 'r') as f:
                    existing_lines = f.readlines()
                    
            # Update or add new configuration
            updated_lines = []
            keys_added = set()
            
            for line in existing_lines:
                stripped = line.strip()
                if stripped and not stripped.startswith('#') and '=' in stripped:
                    key = stripped.split('=', 1)[0].strip()
                    if key in self.config:
                        # Update existing key (ensure proper newline)
                        updated_lines.append(f'{key}="{self.config[key]}"\n')
                        keys_added.add(key)
                    else:
                        # Keep existing line
                        updated_lines.append(line)
                else:
                    # Keep comments and empty lines
                    updated_lines.append(line)
                    
            # Add new keys
            if keys_added != set(self.config.keys()):
                for key, value in self.config.items():
                    if key not in keys_added:
                        updated_lines.append(f'{key}="{value}"\n')
                        
            # Write back to file
            with open(self.env_file, 'w') as f:
                f.writelines(updated_lines)
                
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            print(f"❌ Error saving configuration: {e}")
            
    @staticmethod
    def should_run_wizard() -> bool:
        """Check if the wizard should run (first time setup)"""
        # If launchers have already completed first-time setup, skip
        if setup_sentinel_file().exists():
            return False
        # Check if .env exists and has some configuration
        target_env = default_env_file()
        if target_env.exists():
            try:
                with target_env.open('r', encoding='utf-8') as f:
                    content = f.read()
                    # If .env has more than just basic configuration, assume setup is done
                    config_lines = [line for line in content.split('\\n') 
                                  if line.strip() and not line.strip().startswith('#') and '=' in line]
                    if len(config_lines) > 3:  # More than bare-minimum config
                        return False
            except Exception:
                pass
                
        return True
        
    @staticmethod
    def prompt_user_for_wizard() -> bool:
        """Prompt user to run the configuration wizard"""
        print("\n🎯 First-time Configuration Setup")
        print("=" * 40)
        print("This wizard will help you set portal URL, credentials, and browser settings.")
        
        try:
            run_wizard = input("Run configuration wizard? (Y/n): ").strip().lower()
            return run_wizard != 'n'
        except EOFError:
            # Non-interactive environment, skip wizard
            return False

    @staticmethod
    def mark_setup_complete(flag_path: str | None = None) -> None:
        """Persist a sentinel file so the wizard runs only once."""
        try:
            target = setup_sentinel_file() if flag_path is None else Path(flag_path).expanduser()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.touch(exist_ok=True)
        except Exception as exc:
            logger.warning("Unable to mark setup completion: %s", exc)

def main():
    """Run the configuration wizard standalone"""
    wizard = ConfigWizard()
    wizard.run()

if __name__ == "__main__":
    main()
