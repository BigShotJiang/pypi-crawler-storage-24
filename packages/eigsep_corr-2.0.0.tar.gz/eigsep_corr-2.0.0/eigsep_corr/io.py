import json
import os
import struct
import numpy as np
from . import utils

HEADER_LEN_BYTES = 8
HEADER_LEN_DTYPE = ">Q"


def build_dtype(dtype, endian=None):
    """
    Build a numpy dtype from a tuple of (dtype, endian).

    Parameters
    ----------
    dtype : str
        The data type (e.g., 'int32', 'float64').
    endian : str
        The byte order ('>' for big-endian, '<' for little-endian).
        If None, uses the system default.

    Returns
    -------
    dt : np.dtype

    Notes
    -----
    It is possible to pass a single string to `dtype` specifying both
    type and endian (e.g., '>i4' for big-endian int32).

    """
    dt = np.dtype(dtype)
    if endian:
        dt = dt.newbyteorder(endian)
    return dt


def unpack_raw_header(buf, header_size=None):
    if header_size is None:
        header_size = len(buf)
    else:
        buf = buf[:header_size]
    header = json.loads(buf)  # trim trailing nulls
    if isinstance(header["dtype"], str):
        dt = build_dtype(header["dtype"])
    else:
        dt = build_dtype(*header["dtype"])
    data_start = header_size + HEADER_LEN_BYTES + (8 - (header_size % 8))
    header["header_size"] = header_size
    header["data_start"] = data_start
    header["pam_atten"] = {int(k): v for k, v in header["pam_atten"].items()}
    header["acc_cnt"] = np.array(header["acc_cnt"], dtype=dt)
    return header


def pack_raw_header(header):
    if isinstance(header["dtype"], str):
        dt = build_dtype(header["dtype"])
    else:
        dt = build_dtype(*header["dtype"])
    header = dict(header)  # copy to avoid mutating the original
    header["acc_cnt"] = np.array(header["acc_cnt"], dtype=dt).tolist()
    buf = json.dumps(header)
    return buf


def _read_header_size(fh):
    """Read size of header from first word in file."""
    fh.seek(0, 0)  # go to beginning of file
    return struct.unpack(HEADER_LEN_DTYPE, fh.read(HEADER_LEN_BYTES))[0]


def _read_raw_header(fh):
    header_size = _read_header_size(fh)  # leaves us after ``header size''
    header = unpack_raw_header(fh.read(header_size).decode("utf-8"))
    return header


def _write_raw_header(fh, header):
    buf = pack_raw_header(header).encode("utf-8")
    header_size = len(buf)
    fh.write(struct.pack(HEADER_LEN_DTYPE, header_size))
    fh.write(buf)
    fh.write((8 - (header_size % 8)) * b"\x00")  # pad with trailing nulls


def read_header(filename):
    with open(filename, "rb") as fh:
        h = _read_raw_header(fh)
    # augment raw header with useful calculated values
    h["filename"] = filename
    h["filesize"] = filesize = os.path.getsize(filename)
    intlen = calc_pair_offsets(
        h["pairs"], h["acc_bins"], h["nchan"], h["dtype"]
    )[-1]
    h["nspec"] = (filesize - h["data_start"]) // intlen
    assert h["nspec"] == len(h["acc_cnt"]), (
        "Check file size matches integration cnts"
    )
    h["freqs"], h["dfreq"] = utils.calc_freqs_dfreq(
        h["sample_rate"], h["nchan"]
    )
    h["inttime"] = inttime = utils.calc_inttime(
        h["sample_rate"], h["corr_acc_len"], acc_bins=h["acc_bins"]
    )
    h["times"] = utils.calc_times(h["acc_cnt"], inttime, h["sync_time"])
    return h


def calc_pair_offsets(pairs, acc_bins, nchan, dtype):
    if isinstance(dtype, str):
        dt = build_dtype(dtype)
    else:
        dt = build_dtype(*dtype)
    nspec = np.array([0] + [1 if len(p) == 1 else 2 for p in pairs])
    offsets = np.cumsum(nspec)
    return offsets * dt.itemsize * acc_bins * nchan


def unpack_raw_data(buf, pair, acc_bins=2, nchan=1024, dtype=">i4"):
    if isinstance(dtype, str):
        dt = build_dtype(dtype)
    else:
        dt = build_dtype(*dtype)
    if type(buf) is not bytes:
        buf = b"".join(buf)
    data = np.frombuffer(buf, dtype=dt)
    if len(pair) == 1:
        data.shape = (-1, acc_bins, nchan, 1)  # auto
    else:
        data.shape = (-1, acc_bins, nchan, 2)  # cross (real/imag last axis)
    return data


def pack_raw_data(data, dtype=">i4"):
    if isinstance(dtype, str):
        dt = build_dtype(dtype)
    else:
        dt = build_dtype(*dtype)
    buf = data.astype(dt).tobytes()
    return buf


def unpack_data(fh_buf, h, nspec=-1, skip=0):
    pair_offs = calc_pair_offsets(
        h["pairs"], h["acc_bins"], h["nchan"], h["dtype"]
    )
    integration_len = pair_offs[-1]
    if type(fh_buf) is bytes:
        buf = fh_buf
    else:
        fh = fh_buf
        start = h["data_start"] + skip * integration_len
        fh.seek(start, 0)
        if nspec < 0:
            buf = fh.read()
        else:
            buf = fh.read(nspec * integration_len)
    data = {
        p: [
            buf[b + pair_offs[i] : b + pair_offs[i + 1]]
            for b in range(0, len(buf), integration_len)
        ]
        for i, p in enumerate(h["pairs"])
    }
    data = {
        p: unpack_raw_data(v, p, h["acc_bins"], h["nchan"], h["dtype"])
        for p, v in data.items()
    }
    return data


def pack_data(data, h):
    ntimes = list(data.values())[0].shape[0]
    buf = [
        pack_raw_data(data[p][i], dtype=h["dtype"])
        for i in range(ntimes)
        for p in h["pairs"]
    ]
    buf = b"".join(buf)
    return buf


def pack_corr_data(dict_list, h):
    """
    For use with a list of dicts of binary data read straight from correlator.
    """
    buf = b"".join([d[k] for d in dict_list for k in h["pairs"]])
    return buf


def read_file(filename, header=None, nspec=-1, skip=0):
    if header is None:
        header = read_header(filename)
    with open(filename, "rb") as fh:
        data = unpack_data(fh, header, nspec=nspec, skip=skip)
    return header, data


def write_file(filename, header, data):
    """
    Write binary data to file.

    Parameters
    ----------
    filename : str
    header : dict
    data : dict

    """
    with open(filename, "wb") as fh:
        _write_raw_header(fh, header)
        if type(data) is bytes:
            fh.write(data)
        else:
            fh.write(pack_data(data, header))
