.. automodule:: vivarium.framework.configuration
