"""Protocol Monk package metadata."""

__version__ = "0.1.0"
