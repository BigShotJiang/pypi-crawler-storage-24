"""Protocol Monk plugin packages."""
