import json
import logging
import time
import uuid
from pathlib import Path
from typing import List, Optional, Dict, Any

from protocol_monk.config.settings import Settings
from protocol_monk.agent.structs import Message, ContextStats, ToolResult
from .store import ContextStore
from .file_tracker import FileTracker
from . import logic


class ContextCoordinator:
    """
    High-level facade for context management.
    The AgentService talks ONLY to this, not to the Store or Logic directly.
    """

    FILE_READ_TOOL = "read_file"
    FILE_MUTATION_TOOLS = {
        "create_file",
        "append_to_file",
        "replace_lines",
        "delete_lines",
        "insert_in_file",
    }

    def __init__(self, store: ContextStore, tracker: FileTracker, settings: Settings):
        self._store = store
        self._tracker = tracker
        self._settings = settings
        self._logger = logging.getLogger("ContextCoordinator")

        # Use computed values from settings
        self._limit = settings.context_window_limit
        self._pruning_target = max(1, int(self._limit * settings.pruning_threshold))

        # Initialize token estimator with model family
        from protocol_monk.utils.token_estimation import SmartTokenEstimator

        self._token_estimator = SmartTokenEstimator(settings.model_family)

        # Set system prompt (already loaded by Pydantic)
        sys_msg = Message(
            role="system", content=settings.system_prompt, timestamp=time.time()
        )
        self._store.set_system_prompt(sys_msg)

    def _estimate_tokens(self, text: str) -> int:
        try:
            return self._token_estimator.estimate_tokens(text or "")
        except Exception:
            return logic.count_tokens(text)

    def _count_history_tokens(self, history: List[Message]) -> int:
        """Count tokens for replayable history only."""
        total = 0
        for m in history:
            total += self._estimate_tokens(m.content or "")

            images = m.metadata.get("images") if isinstance(m.metadata, dict) else None
            if images:
                total += self._estimate_tokens(
                    json.dumps(images, ensure_ascii=False, default=str)
                )

            if m.tool_call_id:
                total += self._estimate_tokens(m.tool_call_id)
            if m.name:
                total += self._estimate_tokens(m.name)
            if m.tool_calls:
                total += self._estimate_tokens(
                    json.dumps(m.tool_calls, ensure_ascii=False, default=str)
                )
        return total

    def _normalize_workspace_path(self, filepath: str) -> str:
        workspace_root = Path(self._settings.workspace_root)
        target = Path(filepath.strip())
        if not target.is_absolute():
            target = workspace_root / target
        try:
            return str(target.resolve(strict=False))
        except Exception:
            return str(target)

    def _record_file_tracking(self, result: ToolResult, message_id: str) -> None:
        if not result.success:
            return

        request_parameters = result.request_parameters or {}
        raw_path = request_parameters.get("filepath")
        if not isinstance(raw_path, str) or not raw_path.strip():
            return

        file_path = self._normalize_workspace_path(raw_path)
        if result.tool_name == self.FILE_READ_TOOL:
            self._tracker.mark_loaded(file_path, message_id)
            return

        if result.tool_name in self.FILE_MUTATION_TOOLS:
            self._tracker.remove_file(file_path)

    async def add_user_message(self, text: str) -> ContextStats:
        """
        Adds user input, calculates tokens, and auto-prunes if needed.
        """
        msg = Message(
            role="user",
            content=text,
            timestamp=time.time(),
            metadata={"id": str(uuid.uuid4())},
        )

        # 1. Add to store
        self._store.add(msg)

        # 2. Check and Prune
        self._ensure_limits()

        return self._get_stats()

    def _ensure_limits(self) -> None:
        """
        Private method to enforce context window limits.
        """
        history = self._store.get_full_history()

        # Calculate current load
        total_tokens = self._count_history_tokens(history)

        stats = ContextStats(
            total_tokens=total_tokens,
            message_count=len(history),
            loaded_files_count=self._tracker.count(),
        )

        if self._limit > 0 and logic.should_prune(stats, self._limit):
            # Perform Pruning
            # Use the pre-calculated pruning target (80% of limit by default)
            target = self._pruning_target
            new_history = logic.prune_messages(history, target)

            # Update Store
            self._store.replace_history(new_history)

            # Sync File Tracker (Garbage Collection)
            active_ids = {
                m.metadata.get("id") for m in new_history if m.metadata.get("id")
            }
            self._tracker.sync_with_history(active_ids)
            pruned_total_tokens = self._count_history_tokens(new_history)
            self._logger.info(
                "Pruned context window: tokens %s -> %s, messages %s -> %s, loaded_files=%s",
                total_tokens,
                pruned_total_tokens,
                len(history),
                len(new_history),
                self._tracker.count(),
            )

    def _get_stats(self) -> ContextStats:
        history = self._store.get_full_history()
        return ContextStats(
            total_tokens=self._count_history_tokens(history),
            message_count=len(history),
            loaded_files_count=self._tracker.count(),
        )

    def get_stats(self) -> ContextStats:
        return self._get_stats()

    def get_full_history(self) -> List[Message]:
        """Return the complete context history (system + conversation)."""
        return self._store.get_full_history()

    def get_system_prompt(self) -> Optional[Message]:
        """Return the active system prompt."""
        return self._store.get_system_prompt()

    def replace_history(self, history: List[Message]) -> ContextStats:
        """Replace persisted history and sync file tracking to the new message set."""
        self._store.replace_history(history)
        active_ids = {
            m.metadata.get("id")
            for m in history
            if isinstance(m.metadata, dict) and m.metadata.get("id")
        }
        self._tracker.sync_with_history(active_ids)
        return self._get_stats()

    async def set_system_prompt_text(self, text: str) -> None:
        """Replace the active system prompt for this session."""
        msg = Message(
            role="system",
            content=str(text or "").strip(),
            timestamp=time.time(),
            metadata={"id": str(uuid.uuid4())},
        )
        self._store.set_system_prompt(msg)

    async def reset(self) -> None:
        """
        Reset the context by clearing all messages except the system prompt.
        """
        self._store.clear_messages()

        # Reset file tracker
        self._tracker.clear()

        # Note: System prompt remains intact

    async def add_tool_result(self, result: ToolResult) -> ContextStats:
        """
        Add a tool execution result so the next model pass can consume it.
        """
        envelope = {
            "type": "tool_result",
            "tool_name": result.tool_name,
            "tool_call_id": result.call_id,
            "success": result.success,
            "duration_seconds": result.duration,
            "output_kind": result.output_kind,
            "error_code": result.error_code,
            "error": result.error,
            "error_details": result.error_details,
            "output": result.output,
            "request_parameters": result.request_parameters,
        }
        content = json.dumps(envelope, ensure_ascii=False, default=str)
        message_id = str(uuid.uuid4())

        msg = Message(
            role="tool",
            content=content,
            timestamp=time.time(),
            # First-class tool fields for proper serialization
            tool_call_id=result.call_id,
            name=result.tool_name,
            metadata={
                "id": message_id,
                "tool_name": result.tool_name,
                "tool_call_id": result.call_id,
                "success": result.success,
                "duration": result.duration,
                "request_parameters": result.request_parameters or {},
            },
        )
        self._store.add(msg)
        self._record_file_tracking(result, message_id)
        self._ensure_limits()
        return self._get_stats()

    async def add_assistant_pass(
        self,
        content: str,
        thinking: str = "",
        pass_id: str = "",
        tokens: int = 0,
        tool_call_count: int = 0,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
    ) -> ContextStats:
        """
        Persist each assistant pass in-order so follow-up model calls keep continuity.
        """
        content = content or ""
        thinking = thinking or ""

        msg = Message(
            role="assistant",
            content=content,
            timestamp=time.time(),
            # First-class tool field for proper serialization
            tool_calls=tool_calls,
            metadata={
                "id": str(uuid.uuid4()),
                "pass_id": pass_id,
                "tokens": tokens,
                "tool_call_count": tool_call_count,
                "content_length": len(content),
                "thinking": thinking,
                "thinking_length": len(thinking),
                "tool_calls": tool_calls or [],  # Kept for backward compatibility
            },
        )
        self._store.add(msg)
        self._ensure_limits()
        return self._get_stats()
