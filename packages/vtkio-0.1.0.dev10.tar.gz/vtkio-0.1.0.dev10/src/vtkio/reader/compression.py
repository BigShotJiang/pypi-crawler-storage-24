#!/usr/bin/env python
"""
Compression support module for VTK readers.

Handles zlib, lzma, and lz4 compression commonly used in VTK files.
"""

import struct
import zlib
import lzma
import logging
from pathlib import Path
from typing import Optional, Union, Dict, Any
from enum import Enum

from vtkio.config import VTKConfig, ReaderSettings

logger = logging.getLogger(__name__)

# Optional import for lz4 (not always available)
try:
    import lz4.block
    HAS_LZ4 = True
except ImportError:
    HAS_LZ4 = False
    logger.debug("lz4 not available - lz4 compression will not be supported")


class CompressionType(Enum):
    """Compression types using config constants."""
    NONE = 'none'
    ZLIB = 'zlib'
    LZMA = 'lzma'
    LZ4 = 'lz4'

    @classmethod
    def from_string(cls, compression_str: str) -> 'CompressionType':
        """Create CompressionType from string using config validation."""
        normalized = VTKConfig.normalize_compression_type(compression_str)
        return cls(normalized)


class CompressionHandler:
    """Unified handler for VTK compression/decompression operations."""

    @staticmethod
    def detect_compression(data: bytes, compression_header: Optional[str] = None) -> CompressionType:
        """
        Detect compression type from data or header information.

        Parameters
        ----------
        data : bytes
            Raw data to analyze
        compression_header : str, optional
            Header information from XML attributes

        Returns
        -------
        CompressionType
            Detected compression type
        """
        if compression_header:
            header_lower = compression_header.lower()
            if 'zlib' in header_lower:
                return CompressionType.ZLIB
            elif 'lzma' in header_lower or 'xz' in header_lower:
                return CompressionType.LZMA
            elif 'lz4' in header_lower:
                return CompressionType.LZ4

        # Try to detect from magic bytes
        if len(data) >= 4:
            # zlib magic bytes (RFC 1950)
            if data[:2] in [b'\x78\x9c', b'\x78\xda', b'\x78\x01']:
                return CompressionType.ZLIB
            # LZMA/XZ magic bytes
            elif data[:6] == b'\xfd7zXZ\x00':
                return CompressionType.LZMA
            elif data[:4] == b'\x04"M\x18':  # LZ4 magic
                return CompressionType.LZ4

        return CompressionType.NONE

    @staticmethod
    def decompress_data(data: bytes,
                        compression_type: CompressionType,
                        uncompressed_size: Optional[int] = None) -> bytes:
        """
        Decompress data using the specified compression method.

        Parameters
        ----------
        data : bytes
            Compressed data
        compression_type : CompressionType
            Type of compression to use for decompression
        uncompressed_size : int, optional
            Expected uncompressed size (helps with validation)

        Returns
        -------
        bytes
            Decompressed data

        Raises
        ------
        ValueError
            If compression type is not supported or decompression fails
        """
        if compression_type == CompressionType.NONE:
            return data

        try:
            if compression_type == CompressionType.ZLIB:
                decompressed = zlib.decompress(data)
            elif compression_type == CompressionType.LZMA:
                decompressed = lzma.decompress(data)
            elif compression_type == CompressionType.LZ4:
                if not HAS_LZ4:
                    raise ValueError("lz4 library not available")
                # LZ4 requires uncompressed size for decompression
                if uncompressed_size is None:
                    raise ValueError("uncompressed_size required for LZ4 decompression")
                decompressed = lz4.block.decompress(data, uncompressed_size=uncompressed_size)
            else:
                raise ValueError(f"Unsupported compression type: {compression_type}")

            # Validate size if provided
            if uncompressed_size is not None and len(decompressed) != uncompressed_size:
                logger.warning(f"Decompressed size mismatch: expected {uncompressed_size}, got {len(decompressed)}")

            return decompressed

        except Exception as e:
            raise ValueError(f"Decompression failed for {compression_type.value}: {e}")


class CompressedDataProcessor:
    """Processor for handling compressed data arrays in VTK files."""

    def __init__(self, byte_order: str = 'little', header_type: str = 'UInt32'):
        """
        Initialize processor with byte order and header type information.

        Parameters
        ----------
        byte_order : str
            Byte order ('little' or 'big')
        header_type : str
            VTK header type ('UInt32', 'UInt64', etc.)
        """
        self.byte_order = byte_order
        self.endian_char = '<' if byte_order == 'little' else '>'
        self.header_type = header_type

        # Get header format info from config
        self._setup_header_format()

    def _setup_header_format(self):
        """Setup header format based on header_type using config mapping."""
        # Map VTK types to struct format characters and sizes
        type_mapping = {
            'UInt32': ('I', 4),  # unsigned int, 4 bytes
            'UInt64': ('Q', 8),  # unsigned long long, 8 bytes
            'Int32': ('i', 4),  # signed int, 4 bytes
            'Int64': ('q', 8)  # signed long long, 8 bytes
        }

        if self.header_type not in type_mapping:
            logger.warning(f"Unknown header type {self.header_type}, defaulting to UInt32")
            self.header_type = 'UInt32'

        format_char, size = type_mapping[self.header_type]
        self.header_format = f'{self.endian_char}{format_char}'
        self.header_size = size

        logger.debug(f"Header format: {self.header_format}, size: {self.header_size}")

    def process_compressed_array(self,
                                 compressed_data: bytes,
                                 compression_info: Dict[str, Any]) -> bytes:
        """
        Process a compressed data array from VTK files - FIXED VERSION.
        """
        compression_type = CompressionType(compression_info.get('type', 'none'))

        if compression_type == CompressionType.NONE:
            return compressed_data

        try:
            logger.debug(
                f"Processing VTK compressed array: {len(compressed_data)} bytes, type: {compression_type.value}")

            # Parse compression header
            header_info = self._parse_compression_header(compressed_data)
            logger.debug(f"Parsed header: {header_info['num_blocks']} blocks")

            # Extract and decompress blocks
            decompressed_blocks = []
            offset = header_info['data_offset']

            for i, (block_size, uncompressed_size) in enumerate(header_info['blocks']):
                logger.debug(f"Processing block {i}: {block_size} compressed -> {uncompressed_size} uncompressed")

                if offset + block_size > len(compressed_data):
                    raise ValueError(
                        f"Block {i} extends beyond data bounds: offset {offset} + size {block_size} > total {len(compressed_data)}")

                block_data = compressed_data[offset:offset + block_size]

                try:
                    decompressed_block = CompressionHandler.decompress_data(
                        block_data, compression_type, uncompressed_size
                    )
                    decompressed_blocks.append(decompressed_block)
                    logger.debug(f"Block {i} decompressed: {len(decompressed_block)} bytes")

                except Exception as e:
                    logger.error(f"Failed to decompress block {i}: {e}")
                    raise ValueError(f"Decompression failed for block {i}: {e}")

                offset += block_size

            result = b''.join(decompressed_blocks)
            logger.debug(f"Total decompressed data: {len(result)} bytes")
            return result

        except Exception as e:
            logger.error(f"Error processing compressed array: {e}")
            raise ValueError(f"Compressed array processing failed: {e}")

    def _parse_compression_header(self, data: bytes) -> Dict[str, Any]:
        """
        Parse VTK compression header with dynamic header type.

        Format: [#blocks][#u-size][#p-size][#c-size-1][#c-size-2]...[DATA]
        All values use the header_type specified in the XML file.
        """
        offset = 0

        logger.debug(f"Parsing compression header from {len(data)} bytes")
        logger.debug(f"Header format: {self.header_format}, size: {self.header_size}")
        logger.debug(f"First 32 bytes of data: {data[:32].hex()}")

        try:
            # Ensure we have enough data for minimum header (3 header tokens)
            min_header_size = 3 * self.header_size
            if len(data) < min_header_size:
                raise ValueError(
                    f"Insufficient data for VTK compression header: {len(data)} bytes, need at least {min_header_size}")

            # Read number of blocks
            num_blocks_bytes = data[offset:offset + self.header_size]
            logger.debug(f"num_blocks bytes: {num_blocks_bytes.hex()}")
            num_blocks = struct.unpack_from(self.header_format, data, offset)[0]
            offset += self.header_size
            logger.debug(f"VTK compression: {num_blocks} blocks")

            # Sanity check - num_blocks should be reasonable
            if num_blocks > 1000000 or num_blocks <= 0:
                raise ValueError(f"Unreasonable number of blocks: {num_blocks}")

            # Read standard block size (uncompressed)
            block_size_bytes = data[offset:offset + self.header_size]
            logger.debug(f"block_size bytes: {block_size_bytes.hex()}")
            standard_block_size = struct.unpack_from(self.header_format, data, offset)[0]
            offset += self.header_size
            logger.debug(f"VTK compression: standard block size {standard_block_size}")

            # Sanity check - block size should be reasonable
            if standard_block_size > 100000000 or standard_block_size <= 0:
                raise ValueError(f"Unreasonable block size: {standard_block_size}")

            # Read last partial block size (uncompressed)
            partial_size_bytes = data[offset:offset + self.header_size]
            logger.debug(f"partial_size bytes: {partial_size_bytes.hex()}")
            last_partial_size = struct.unpack_from(self.header_format, data, offset)[0]
            offset += self.header_size
            logger.debug(f"VTK compression: last partial block size {last_partial_size}")

            # Calculate total header size needed
            total_header_size = min_header_size + num_blocks * self.header_size
            if len(data) < total_header_size:
                raise ValueError(f"Insufficient data for all block sizes: need {total_header_size}, have {len(data)}")

            # Read compressed block sizes
            compressed_sizes = []
            for i in range(num_blocks):
                block_size_bytes = data[offset:offset + self.header_size]
                logger.debug(f"block {i} compressed size bytes: {block_size_bytes.hex()}")
                compressed_size = struct.unpack_from(self.header_format, data, offset)[0]
                compressed_sizes.append(compressed_size)
                offset += self.header_size
                logger.debug(f"Block {i}: compressed size {compressed_size}")

                # Sanity check
                if compressed_size > 100000000 or compressed_size <= 0:
                    raise ValueError(f"Unreasonable compressed size for block {i}: {compressed_size}")

            # Calculate uncompressed size for each block
            blocks = []
            for i, compressed_size in enumerate(compressed_sizes):
                if i == num_blocks - 1 and last_partial_size > 0:
                    uncompressed_size = last_partial_size
                else:
                    uncompressed_size = standard_block_size

                blocks.append((compressed_size, uncompressed_size))

            return {
                'num_blocks': num_blocks,
                'standard_block_size': standard_block_size,
                'last_partial_size': last_partial_size,
                'blocks': blocks,
                'data_offset': offset
            }

        except struct.error as e:
            logger.error(f"Struct unpacking error with format {self.header_format}: {e}")
            logger.error(f"Data at offset {offset}: {data[offset:offset + 16].hex()}")
            raise ValueError(f"Struct unpacking error: {e}")
        except Exception as e:
            logger.error(f"Error parsing VTK compression header: {e}")
            raise ValueError(f"Failed to parse VTK compression header: {e}")



# Configuration additions for compression
class CompressionSettings:
    """Compression settings using config defaults."""

    def __init__(self,
                 enable_compression: bool = True,
                 preferred_compression: str = None,
                 max_memory_mb: int = None,
                 block_size: int = None):
        """
        Initialize compression settings using config defaults.

        Parameters
        ----------
        enable_compression : bool
            Whether to enable compression support
        preferred_compression : str, optional
            Preferred compression type (uses config default if None)
        max_memory_mb : int, optional
            Max memory for decompression (uses config default if None)
        block_size : int, optional
            Compression block size (uses config default if None)
        """
        self.enable_compression = enable_compression

        # Use config defaults
        self.preferred_compression = CompressionType.from_string(
            preferred_compression or VTKConfig.DEFAULT_COMPRESSION_TYPE
        )
        self.max_memory_mb = max_memory_mb or VTKConfig.MAX_DECOMPRESSION_MEMORY_MB
        self.block_size = block_size or VTKConfig.DEFAULT_COMPRESSION_BLOCK_SIZE

        # Validate using config
        if not VTKConfig.validate_compression_type(self.preferred_compression.value):
            logger.warning(f"Unsupported compression type, falling back to zlib")
            self.preferred_compression = CompressionType.ZLIB


# Example usage in the main API
# def load_vtk_data_with_compression(file_path: Union[str, Path],
#                                   settings: Optional[ReaderSettings] = None,
#                                   compression_settings: Optional[CompressionSettings] = None):
#     """
#     Load VTK data with compression support.
#
#     Parameters
#     ----------
#     file_path : Union[str, Path]
#         Path to potentially compressed VTK file
#     compression_settings : CompressionSettings, optional
#         Compression handling settings
#
#     Returns
#     -------
#     VTK data structure
#     """
#     file_path = Path(file_path)
#     # Use config-based factory
#     factory = VTKReaderFactory(settings, compression_settings)
#
#     # Create reader using config logic
#     reader = factory.create_reader(file_path)
#
#     return reader.parse()
