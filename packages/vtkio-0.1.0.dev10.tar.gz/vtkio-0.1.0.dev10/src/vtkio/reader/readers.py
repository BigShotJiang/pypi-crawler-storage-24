#!/usr/bin/env python
"""
Concrete implementations of HDF5 and XML readers using the base class pattern.

This shows how the simplified error handling and extracted common patterns
work in practice.
"""
__author__ = 'J.P. Morrissey'
__copyright__ = 'Copyright 2022-2025'
__maintainer__ = 'J.P. Morrissey'
__email__ = 'morrissey.jp@gmail.com'
__status__ = 'Development'

# Standard Library
import struct
import logging
import numpy as np
import pybase64
import xmltodict
import zlib
import lzma
from typing import Dict, Any, Optional, Union
from pathlib import Path
import re
import h5py

from .base_reader import BaseVTKReader, handle_vtk_errors_with_compression
from .exceptions import InvalidVTKFileError, MissingDataError, DataCorruptionError, UnsupportedFormatError
from .compression import CompressionType
from .data_processors import (
    DataArrayProcessor, PolyDataTopologyProcessor, GridTopologyProcessor,
    determine_points_key, safe_get_hdf5_attr, safe_array_conversion
)
from ..config import VTKConfig
from ..helpers import _parse_bytecount_type
from ..utilities import dict_extract_generator, get_recursively
from ..vtk_structures import PolyDataTopology, Grid, GridCoordinates

logger = logging.getLogger(__name__)


class UnifiedHDF5Reader(BaseVTKReader):
    """HDF5 reader with built-in compression support."""

    def __init__(self, file_path: Union[str, Path], compression_settings=None):
        extension = Path(file_path).suffix.lower()
        if extension not in VTKConfig.SUPPORTED_HDF5_EXTENSIONS:
            raise UnsupportedFormatError(f"Not an HDF5 file: {extension}")

        super().__init__(file_path, compression_settings)
        self._hdf5_file = None
        self._vtkhdf_group = None
        self._compression_info = {}

    def _is_supported_format(self) -> bool:
        return Path(self.file_path).suffix.lower() in VTKConfig.SUPPORTED_HDF5_EXTENSIONS

    def _detect_compression(self) -> CompressionType:
        """Detect compression from XML root attributes - IMPROVED VERSION."""
        try:
            # Check for compression at the VTKFile root level
            compressor = self._xml_data.get('@compressor', '')

            if compressor:
                logger.debug(f"Found compressor attribute: {compressor}")
                normalized = VTKConfig.normalize_vtk_compressor(compressor)
                detected = CompressionType(normalized)

                # IMPORTANT: Set a flag to indicate this is XML-level compression
                # not VTK block-format compression
                self._xml_compression_format = 'xml_native'

                return detected

            # Check if any DataArrays have format="binary" which might be compressed
            # This is a fallback check
            try:
                from ..utilities import dict_extract_generator
                format_values = list(dict_extract_generator('@format', self._xml_data))
                if 'binary' in format_values and hasattr(self, '_xml_data'):
                    # Could be compressed binary, but we can't know for sure yet
                    # Let the individual array processing handle it
                    logger.debug("Found binary format, compression detection deferred to array level")
            except:
                pass

            # No compression found
            logger.debug("No compression detected in XML file")
            return CompressionType.NONE

        except Exception as e:
            logger.debug(f"Error detecting compression: {e}")
            return CompressionType.NONE

    @handle_vtk_errors_with_compression
    def _load_file_structure(self):
        """Load HDF5 structure and detect compression."""
        try:
            self._hdf5_file = h5py.File(self.file_path, 'r')

            if 'VTKHDF' not in self._hdf5_file:
                raise InvalidVTKFileError("File does not contain VTKHDF group")

            self._vtkhdf_group = self._hdf5_file['VTKHDF']
            self._scan_compression()

        except OSError as e:
            raise InvalidVTKFileError(f"Cannot open HDF5 file: {e}")

    def _scan_compression(self):
        """Scan for compression in HDF5 datasets."""

        def scan_group(group, path=""):
            for name, item in group.items():
                full_path = f"{path}/{name}" if path else name

                if isinstance(item, h5py.Dataset) and item.compression:
                    self._compression_info[full_path] = {
                        'type': item.compression,
                        'opts': getattr(item, 'compression_opts', None),
                        'shape': item.shape,
                        'dtype': item.dtype
                    }
                    logger.debug(f"Dataset {full_path} uses {item.compression} compression")
                elif isinstance(item, h5py.Group):
                    scan_group(item, full_path)

        scan_group(self._vtkhdf_group)

    def _get_data_type(self) -> str:
        data_type = safe_get_hdf5_attr(self._vtkhdf_group, 'Type')
        if not data_type:
            raise MissingDataError("Missing 'Type' attribute")
        if isinstance(data_type, bytes):
            data_type = data_type.decode('utf-8')
        return data_type

    def _get_source_type(self) -> str:
        return 'hdf5'

    @handle_vtk_errors_with_compression
    def _extract_raw_data_arrays(self, data_section: str, decompress: bool = True) -> Optional[Dict]:
        """Extract HDF5 data arrays (decompression handled transparently by h5py)."""
        try:
            if data_section in self._vtkhdf_group:
                return self._vtkhdf_group[data_section]
            return None
        except Exception as e:
            logger.warning(f"Error accessing {data_section}: {e}")
            return None

    def _process_compressed_xml_arrays(self, xml_data: Dict) -> Dict:
        """Not applicable for HDF5 reader."""
        return {}

    def _process_compressed_hdf5_arrays(self, hdf5_data: Dict) -> Optional[Dict]:
        """Process HDF5 data with compression awareness."""
        if not hdf5_data:
            return None

        # For HDF5, compression is handled transparently by h5py
        # We just need to process the arrays normally
        return DataArrayProcessor._process_hdf5_arrays(hdf5_data, None)

    # @handle_vtk_errors_with_compression
    # def _extract_points(self) -> Dict:
    #     """Extract points from HDF5."""
    #     try:
    #         points = self._vtkhdf_group['Points'][:]
    #         return {'points': points}
    #     except KeyError:
    #         raise MissingDataError("Points dataset not found")
    #     except Exception as e:
    #         raise DataCorruptionError(f"Corrupted points data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_points(self) -> Dict:
        """Extract points from HDF5."""
        try:
            points = self._vtkhdf_group['Points'][:]
            return {'points': points}
        except KeyError:
            raise MissingDataError("Points dataset not found")
        except Exception as e:
            raise DataCorruptionError(f"Corrupted points data: {e}")

    def _safe_extract_data_arrays(self, data_section: str) -> Optional[Dict]:
        """Enhanced data array extraction for HDF5 with proper processing."""
        try:
            raw_data = self._extract_raw_data_arrays(data_section)
            if raw_data is None:
                return None
            return DataArrayProcessor._process_hdf5_arrays(raw_data, None)
        except Exception as e:
            logger.warning(f"Error extracting {data_section} from HDF5: {e}")
            return None

    @handle_vtk_errors_with_compression
    def _extract_connectivity(self) -> Dict:
        """Extract connectivity data from HDF5."""
        try:
            return {
                'connectivity': self._vtkhdf_group['Connectivity'][:],
                'offsets': self._vtkhdf_group['Offsets'][1:],  # Skip first zero
                'types': self._vtkhdf_group['Types'][:]
            }
        except KeyError as e:
            raise MissingDataError(f"Missing connectivity data: {e}")
        except Exception as e:
            raise DataCorruptionError(f"Corrupted connectivity data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_polydata_topology(self) -> Dict:
        """Extract polydata topology from HDF5."""
        topology = {}

        # Check each polydata topology section
        for section_name, vtk_name in VTKConfig.POLYDATA_TOPOLOGY_SECTIONS.items():
            if section_name in self._vtkhdf_group:
                topology_obj = PolyDataTopologyProcessor.process_hdf5_topology(
                    self._vtkhdf_group, section_name
                )
                if topology_obj:
                    topology[vtk_name] = topology_obj

        return topology

    @handle_vtk_errors_with_compression
    def _extract_image_grid(self) -> Grid:
        """Extract image data grid from HDF5 attributes."""
        try:
            whole_extents = safe_get_hdf5_attr(self._vtkhdf_group, 'WholeExtent')
            origin = safe_get_hdf5_attr(self._vtkhdf_group, 'Origin')
            spacing = safe_get_hdf5_attr(self._vtkhdf_group, 'Spacing')
            direction = safe_get_hdf5_attr(self._vtkhdf_group, 'Direction')

            if whole_extents is None or origin is None or spacing is None:
                raise MissingDataError("Missing required grid attributes")

            return GridTopologyProcessor.create_grid_from_attributes(
                whole_extents, origin, spacing, direction
            )

        except Exception as e:
            raise DataCorruptionError(f"Invalid image grid data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_extents(self) -> np.ndarray:
        """Extract extents for structured grid from HDF5."""
        try:
            extents = safe_get_hdf5_attr(self._vtkhdf_group, 'WholeExtent')
            if extents is None:
                raise MissingDataError("WholeExtent attribute not found")

            if isinstance(extents, str):
                extents = np.fromstring(extents, dtype=int, sep=' ')

            return extents

        except Exception as e:
            raise DataCorruptionError(f"Invalid extents data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_grid_coordinates(self) -> GridCoordinates:
        """Extract rectilinear grid coordinates from HDF5."""
        try:
            x_coords = self._vtkhdf_group['XCoordinates'][:]
            y_coords = self._vtkhdf_group['YCoordinates'][:]
            z_coords = self._vtkhdf_group['ZCoordinates'][:]

            whole_extents = safe_get_hdf5_attr(self._vtkhdf_group, 'WholeExtent')
            if whole_extents is None:
                # Calculate extents from coordinate arrays
                whole_extents = np.array([
                    0, len(x_coords) - 1,
                    0, len(y_coords) - 1,
                    0, len(z_coords) - 1
                ])

            return GridTopologyProcessor.create_grid_coordinates(
                x_coords, y_coords, z_coords, whole_extents
            )

        except KeyError as e:
            raise MissingDataError(f"Missing coordinate data: {e}")
        except Exception as e:
            raise DataCorruptionError(f"Invalid coordinate data: {e}")

    def __del__(self):
        """Cleanup HDF5 file handle."""
        if hasattr(self, '_hdf5_file') and self._hdf5_file:
            try:
                self._hdf5_file.close()
            except:
                pass


class UnifiedXMLReader(BaseVTKReader):
    """Complete XML reader with comprehensive compression support."""

    def __init__(self, file_path: Union[str, Path], encoding: str = None, compression_settings=None):
        extension = Path(file_path).suffix.lower()
        if extension not in VTKConfig.SUPPORTED_XML_EXTENSIONS:
            raise UnsupportedFormatError(f"Not an XML VTK file: {extension}")

        super().__init__(file_path, compression_settings)
        self.encoding = encoding or VTKConfig.DEFAULT_ENCODING
        self._piece_data = None

        # XML-specific attributes
        self.data_type = None
        self.file_version = 1.0
        self.byte_order = 'little'
        self.byte_count_type = 'UInt32'
        self.byte_count_format = None
        self.data_format = None

    # ==================================================================================
    # Abstract method implementations
    # ==================================================================================

    def _is_supported_format(self) -> bool:
        return Path(self.file_path).suffix.lower() in VTKConfig.SUPPORTED_XML_EXTENSIONS

    def _detect_compression(self) -> CompressionType:
        """Detect compression from XML root attributes."""
        try:
            # Check for compression at the VTKFile root level
            compressor = self._xml_data.get('@compressor', '')

            if compressor:
                logger.debug(f"Found compressor attribute: {compressor}")
                normalized = VTKConfig.normalize_vtk_compressor(compressor)
                return CompressionType(normalized)

            # No compression found
            logger.debug("No compression detected in XML file")
            return CompressionType.NONE

        except Exception as e:
            logger.debug(f"Error detecting compression: {e}")
            return CompressionType.NONE

    @handle_vtk_errors_with_compression
    def _load_file_structure(self):
        """Load XML structure with compression detection."""
        try:
            raw_bytes = self.file_path.read_bytes()

            try:
                self._xml_data = xmltodict.parse(raw_bytes)['VTKFile']
                self._handle_appended_data()
            except:
                self._xml_data = self._parse_invalid_xml_with_binary(raw_bytes)

            self._extract_xml_metadata()

        except Exception as e:
            raise InvalidVTKFileError(f"Cannot parse XML file: {e}")

    def _get_data_type(self) -> str:
        return self._xml_data['@type']

    def _get_source_type(self) -> str:
        return 'xml'

    @handle_vtk_errors_with_compression
    def _extract_raw_data_arrays(self, data_section: str, decompress: bool = True) -> Optional[Dict]:
        """Extract XML data arrays."""
        try:
            if data_section in self._piece_data:
                section_data = self._piece_data[data_section]
                if section_data:
                    array_key = 'DataArray' if 'DataArray' in section_data else 'Array'
                    if array_key in section_data:
                        return section_data[array_key]
            return None
        except Exception as e:
            logger.warning(f"Error accessing {data_section}: {e}")
            return None

    def _process_compressed_xml_arrays(self, xml_data: Dict) -> Dict:
        """Process compressed XML arrays - delegated to individual array processing."""
        # This method is kept for compatibility but actual processing
        # is handled in extract_data_array
        return {}

    def _process_compressed_hdf5_arrays(self, hdf5_data: Dict) -> Dict:
        """Not applicable for XML reader."""
        return {}

    # ==================================================================================
    # Data extraction methods
    # ==================================================================================

    @handle_vtk_errors_with_compression
    def _extract_points(self) -> Dict:
        """Extract points from XML."""
        try:
            raw_points = self._safe_extract_data_arrays('Points')
            if not raw_points:
                raise MissingDataError("No points data found")
            points = determine_points_key(raw_points)
            return {'points': points}
        except Exception as e:
            raise DataCorruptionError(f"Corrupted points data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_connectivity(self) -> Dict:
        """Extract connectivity data from XML."""
        try:
            raw_cells = self._safe_extract_data_arrays('Cells')
            if not raw_cells:
                raise MissingDataError("No cells data found")

            connectivity = raw_cells.get('connectivity')
            offsets = raw_cells.get('offsets')
            types = raw_cells.get('types')

            if connectivity is None or offsets is None or types is None:
                raise MissingDataError("Missing connectivity components")

            return {
                'connectivity': connectivity,
                'offsets': offsets,
                'types': types
            }

        except Exception as e:
            raise DataCorruptionError(f"Corrupted connectivity data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_polydata_topology(self) -> Dict:
        """Extract polydata topology from XML."""
        topology = {}

        logger.debug(f"Available sections in XML piece: {list(self._piece_data.keys())}")

        for section_name, vtk_name in VTKConfig.POLYDATA_TOPOLOGY_SECTIONS.items():
            logger.debug(f"Looking for topology section: {section_name}")

            if section_name in self._piece_data:
                logger.debug(f"Found {section_name} section")
                topology_obj = PolyDataTopologyProcessor.process_xml_topology(
                    self._piece_data, self, section_name
                )
                if topology_obj:
                    topology[vtk_name] = topology_obj
                    logger.debug(f"Successfully processed {section_name} -> {vtk_name}")
                else:
                    logger.debug(f"Failed to process {section_name}")
            else:
                logger.debug(f"Section {section_name} not found in XML")

        logger.debug(f"Final topology keys: {list(topology.keys())}")
        return topology

    @handle_vtk_errors_with_compression
    def _extract_image_grid(self) -> Grid:
        """Extract image data grid from XML attributes."""
        try:
            piece_attrs = self._piece_data

            whole_extents = piece_attrs.get('@WholeExtent')
            origin = piece_attrs.get('@Origin')
            spacing = piece_attrs.get('@Spacing')
            direction = piece_attrs.get('@Direction')

            if not whole_extents or not origin or not spacing:
                raise MissingDataError("Missing required grid attributes")

            return GridTopologyProcessor.create_grid_from_attributes(
                whole_extents, origin, spacing, direction
            )

        except Exception as e:
            raise DataCorruptionError(f"Invalid image grid data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_extents(self) -> np.ndarray:
        """Extract extents for structured grid from XML."""
        try:
            extents_str = self._piece_data.get('@WholeExtent')
            if not extents_str:
                raise MissingDataError("WholeExtent attribute not found")

            extents = np.fromstring(extents_str, dtype=int, sep=' ')
            return extents

        except Exception as e:
            raise DataCorruptionError(f"Invalid extents data: {e}")

    @handle_vtk_errors_with_compression
    def _extract_grid_coordinates(self) -> GridCoordinates:
        """Extract rectilinear grid coordinates from XML."""
        try:
            # Extract coordinate arrays from XML
            coordinates_data = self._safe_extract_data_arrays('Coordinates')
            if not coordinates_data:
                raise MissingDataError("No coordinates data found")

            x_coords = coordinates_data.get('XCoordinates')
            y_coords = coordinates_data.get('YCoordinates')
            z_coords = coordinates_data.get('ZCoordinates')

            if x_coords is None or y_coords is None or z_coords is None:
                raise MissingDataError("Missing coordinate arrays")

            # Get extents from attributes
            whole_extents = self._piece_data.get('@WholeExtent')
            if not whole_extents:
                # Calculate from coordinate lengths
                whole_extents = np.array([
                    0, len(x_coords) - 1,
                    0, len(y_coords) - 1,
                    0, len(z_coords) - 1
                ])

            return GridTopologyProcessor.create_grid_coordinates(
                x_coords, y_coords, z_coords, whole_extents
            )

        except Exception as e:
            raise DataCorruptionError(f"Invalid coordinate data: {e}")

    # ==================================================================================
    # Core data array extraction methods
    # ==================================================================================

    def extract_data_array(self, array_data: Dict) -> tuple:
        """
        Extract data array with proper compression handling - MAIN METHOD.
        """
        try:
            array_name = array_data.get('@Name', 'unknown_name')
            logger.debug(f"Extracting array: {array_name}")

            # Determine the data format and handle accordingly
            if self.data_format == 'binary':
                return self._extract_binary_array(array_data)
            elif self.data_format == 'appended':
                return self._extract_appended_array(array_data)
            elif self.data_format == 'ascii':
                return self._extract_ascii_array(array_data)
            else:
                raise ValueError(f"Unknown data format: {self.data_format}")

        except Exception as e:
            logger.error(f"Failed to extract data array {array_data.get('@Name', 'unknown')}: {e}")
            raise DataCorruptionError(f"Array extraction failed: {e}")

    def _extract_binary_array(self, array_data: dict) -> tuple:
        """
        Extract binary format array with proper compression support.
        """
        array_name = array_data.get('@Name', 'unknown')
        data_text = array_data.get('#text', '')

        if not data_text:
            raise ValueError(f"No binary data found for array {array_name}")

        try:
            # Check if compression is detected at file level
            if self._detected_compression != CompressionType.NONE:
                logger.debug(f"Reading compressed binary array {array_name}")
                raw_data = self._read_compressed_binary(data_text, array_data)
            else:
                logger.debug(f"Reading uncompressed binary array {array_name}")
                raw_data = self._read_uncompressed_binary(data_text, array_data)

            # Convert to numpy array with proper validation
            array = self._bytes_to_array_robust(raw_data, array_data)
            return array_name, array

        except Exception as e:
            logger.error(f"Error extracting binary array {array_name}: {e}")
            raise

    def _extract_appended_array(self, array_data: Dict) -> tuple:
        """Extract appended format array."""
        array_name = array_data.get('@Name', 'unknown')
        offset = array_data.get('@offset')

        if self.appended_data_bstr is None:
            raise ValueError("Appended data is required for 'appended' format")

        if offset not in self.appended_data_arrays:
            raise ValueError(f"Offset {offset} not found in appended data")

        try:
            raw_data = self.appended_data_arrays[offset]
            array = self._bytes_to_array_robust(raw_data, array_data)
            return array_name, array
        except Exception as e:
            logger.error(f"Error extracting appended array {array_name}: {e}")
            raise

    def _extract_ascii_array(self, array_data: Dict) -> tuple:
        """Extract ASCII format array."""
        array_name = array_data.get('@Name', 'unknown')
        data_text = array_data.get('#text', '')
        vtk_type = array_data.get('@type', 'Float32')

        try:
            if vtk_type.lower() == 'string':
                chars = list(map(chr, map(int, data_text.split())))
                array = np.array(''.join(chars).rstrip('\x00').split('\x00'))
            else:
                numpy_dtype = VTKConfig.get_numpy_dtype(vtk_type) or self.parse_data_type(vtk_type)
                array = np.fromstring(data_text, dtype=numpy_dtype, sep=' ')

                # Handle multi-component data
                num_components = int(array_data.get('@NumberOfComponents', 1))
                if num_components > 1:
                    array = array.reshape(-1, num_components)

            return array_name, array
        except Exception as e:
            logger.error(f"Error extracting ASCII array {array_name}: {e}")
            raise

    # ==================================================================================
    # Compression handling methods
    # ==================================================================================

    def _read_compressed_binary_robust(self, data_text: str, array_data: dict) -> bytes:
        """
        Main entry point for reading compressed binary data with fallbacks.
        """
        array_name = array_data.get('@Name', 'unknown')

        try:
            # Primary method - proper VTK compressed format
            return self._read_compressed_binary(data_text, array_data)
        except Exception as e:
            logger.debug(f"Compressed read failed for {array_name}: {e}")

            # Fallback to uncompressed
            try:
                logger.warning(f"Falling back to uncompressed for {array_name}")
                return self._read_uncompressed_binary(data_text, array_data)
            except Exception as e2:
                logger.error(f"All read methods failed for {array_name}")
                # Return empty data rather than failing completely
                return b''

    def _parse_simple_compressed(self, data: bytes, array_data: dict) -> bytes:
        """
        Parse simple compressed format (single block with size header).
        """
        header_dtype = self._get_numpy_header_dtype()
        header_size = header_dtype.itemsize

        if len(data) < header_size:
            raise ValueError("Insufficient data for size header")

        # Read uncompressed size
        uncompressed_size = self._read_header_value(data, 0, header_dtype)

        if uncompressed_size <= 0 or uncompressed_size > 100000000:
            raise ValueError(f"Invalid uncompressed size: {uncompressed_size}")

        # Extract and decompress
        compressed_data = data[header_size:]
        decompressed = self._decompress_block(compressed_data, uncompressed_size)

        return decompressed

    def _read_compressed_binary(self, data_text: str, array_data: dict) -> bytes:
        """
        Read compressed binary data using VTK's block format.
        """
        array_name = array_data.get('@Name', 'unknown')

        # Decode base64
        byte_string = pybase64.b64decode(data_text)

        # VTK compressed format always uses blocks
        try:
            return self._parse_vtk_compressed_blocks(byte_string, array_data)
        except Exception as e:
            logger.error(f"Failed to parse compressed data for {array_name}: {e}")
            # Try fallback to simple format
            try:
                return self._parse_simple_compressed(byte_string, array_data)
            except:
                raise ValueError(f"Unable to decompress {array_name}")

    def _parse_vtk_compressed_blocks(self, data: bytes, array_data: dict) -> bytes:
        """
        Parse VTK's block-based compression format.

        Format: [num_blocks][block_size][last_block_size][compressed_sizes...][compressed_data...]
        All header values use the header_type from the VTK file.
        """
        array_name = array_data.get('@Name', 'unknown')

        # Determine header dtype
        header_dtype = self._get_numpy_header_dtype()
        header_size = header_dtype.itemsize

        logger.debug(f"Parsing VTK compressed blocks for {array_name}")
        logger.debug(f"Header type: {self.byte_count_type}, size: {header_size} bytes")
        logger.debug(f"Total data size: {len(data)} bytes")

        if len(data) < 3 * header_size:
            raise ValueError(f"Insufficient data for compression header: {len(data)} bytes")

        offset = 0

        # Read compression header
        num_blocks = self._read_header_value(data, offset, header_dtype)
        offset += header_size

        block_size = self._read_header_value(data, offset, header_dtype)
        offset += header_size

        last_block_size = self._read_header_value(data, offset, header_dtype)
        offset += header_size

        logger.debug(f"Compression header: {num_blocks} blocks, block_size={block_size}, last_size={last_block_size}")

        # Validate header values
        if num_blocks <= 0 or num_blocks > 100000:
            raise ValueError(f"Invalid number of blocks: {num_blocks}")
        if block_size <= 0 or block_size > 100000000:
            raise ValueError(f"Invalid block size: {block_size}")

        # Read compressed block sizes
        compressed_sizes = []
        for i in range(num_blocks):
            if offset + header_size > len(data):
                raise ValueError(f"Insufficient data for block {i} size")
            size = self._read_header_value(data, offset, header_dtype)
            compressed_sizes.append(size)
            offset += header_size

        logger.debug(f"Compressed sizes: {compressed_sizes[:5]}..." if len(compressed_sizes) > 5 else compressed_sizes)

        # Decompress blocks
        decompressed_blocks = []
        for i, comp_size in enumerate(compressed_sizes):
            if offset + comp_size > len(data):
                raise ValueError(f"Insufficient data for block {i}")

            compressed_block = data[offset:offset + comp_size]
            offset += comp_size

            # Expected uncompressed size
            if i == num_blocks - 1 and last_block_size > 0:
                expected_size = last_block_size
            else:
                expected_size = block_size

            # Decompress
            decompressed = self._decompress_block(compressed_block, expected_size)
            decompressed_blocks.append(decompressed)

            logger.debug(f"Block {i}: {comp_size} -> {len(decompressed)} bytes")

        result = b''.join(decompressed_blocks)
        logger.debug(f"Total decompressed size: {len(result)} bytes")

        return result

    def _read_vtk_block_compressed_format(self, data_text: str, array_data: dict) -> bytes:
        """
        Read VTK's block-based compressed format.

        VTK compressed format structure:
        [num_blocks][uncompressed_block_size][last_block_size][compressed_size_1]...[compressed_size_n][compressed_data]
        """
        # Decode base64
        byte_string = pybase64.b64decode(data_text)

        # Get header dtype based on header_type attribute
        header_dtype = self._get_numpy_header_dtype()
        header_size = header_dtype.itemsize

        logger.debug(f"Reading VTK block compressed format, header size: {header_size}")

        # Minimum header: 3 values + at least 1 block size
        min_header_size = 4 * header_size
        if len(byte_string) < min_header_size:
            raise ValueError(f"Insufficient data for VTK compression header: {len(byte_string)} < {min_header_size}")

        offset = 0

        # Read number of blocks
        num_blocks = struct.unpack_from(header_dtype.str, byte_string, offset)[0]
        offset += header_size
        logger.debug(f"Number of blocks: {num_blocks}")

        if num_blocks <= 0 or num_blocks > 100000:
            raise ValueError(f"Invalid number of blocks: {num_blocks}")

        # Read uncompressed block size (standard block size)
        uncompressed_block_size = struct.unpack_from(header_dtype.str, byte_string, offset)[0]
        offset += header_size
        logger.debug(f"Uncompressed block size: {uncompressed_block_size}")

        # Read last block size (can be smaller than standard block size)
        last_block_size = struct.unpack_from(header_dtype.str, byte_string, offset)[0]
        offset += header_size
        logger.debug(f"Last block size: {last_block_size}")

        # Read compressed block sizes
        compressed_sizes = []
        for i in range(num_blocks):
            if offset + header_size > len(byte_string):
                raise ValueError(f"Insufficient data for block {i} size header")
            compressed_size = struct.unpack_from(header_dtype.str, byte_string, offset)[0]
            compressed_sizes.append(compressed_size)
            offset += header_size
            logger.debug(f"Block {i} compressed size: {compressed_size}")

        # Now decompress each block
        decompressed_blocks = []

        for i, compressed_size in enumerate(compressed_sizes):
            if offset + compressed_size > len(byte_string):
                raise ValueError(
                    f"Insufficient data for block {i}: need {compressed_size}, have {len(byte_string) - offset}")

            # Extract compressed block
            compressed_block = byte_string[offset:offset + compressed_size]
            offset += compressed_size

            # Determine expected uncompressed size for this block
            if i == num_blocks - 1 and last_block_size > 0:
                expected_size = last_block_size
            else:
                expected_size = uncompressed_block_size

            # Decompress block
            try:
                if self._detected_compression == CompressionType.ZLIB:
                    decompressed = zlib.decompress(compressed_block)
                elif self._detected_compression == CompressionType.LZMA:
                    decompressed = lzma.decompress(compressed_block)
                else:
                    raise ValueError(f"Unsupported compression: {self._detected_compression}")

                # Validate size
                if len(decompressed) != expected_size:
                    logger.warning(f"Block {i} size mismatch: got {len(decompressed)}, expected {expected_size}")

                decompressed_blocks.append(decompressed)
                logger.debug(f"Decompressed block {i}: {compressed_size} -> {len(decompressed)} bytes")

            except Exception as e:
                raise ValueError(f"Failed to decompress block {i}: {e}")

        # Concatenate all decompressed blocks
        result = b''.join(decompressed_blocks)
        logger.debug(f"Total decompressed: {len(result)} bytes")

        return result

    def _read_simple_compressed_format(self, data_text: str, array_data: dict) -> bytes:
        """
        Read simple compressed format: base64(size_header + compressed_data)
        This is for single-block compression.
        """
        # Decode base64
        byte_string = pybase64.b64decode(data_text)

        # Get header size
        header_dtype = self._get_numpy_header_dtype()
        header_size = header_dtype.itemsize

        if len(byte_string) < header_size:
            raise ValueError("Insufficient data for size header")

        # Read expected uncompressed size
        uncompressed_size = struct.unpack_from(header_dtype.str, byte_string, 0)[0]
        logger.debug(f"Expected uncompressed size: {uncompressed_size}")

        if uncompressed_size <= 0 or uncompressed_size > 100000000:
            raise ValueError(f"Unreasonable uncompressed size: {uncompressed_size}")

        # Extract compressed data
        compressed_data = byte_string[header_size:]

        if len(compressed_data) == 0:
            raise ValueError("No compressed data after header")

        # Decompress
        decompressed = self._decompress_data(compressed_data, uncompressed_size)

        # Validate result
        if len(decompressed) != uncompressed_size:
            logger.warning(f"Size mismatch: got {len(decompressed)}, expected {uncompressed_size}")
            if len(decompressed) > uncompressed_size:
                decompressed = decompressed[:uncompressed_size]

        return decompressed

    def _read_raw_compressed_format(self, data_text: str, array_data: dict) -> bytes:
        """
        Try reading as raw compressed data (no size header).
        """
        # Decode base64
        byte_string = pybase64.b64decode(data_text)

        # Try to decompress directly
        return self._decompress_data(byte_string, None)

    def _decompress_block(self, compressed_data: bytes, expected_size: int) -> bytes:
        """
        Decompress a single block of data.
        """
        if len(compressed_data) == 0:
            raise ValueError("Empty compressed data")

        try:
            if self._detected_compression == CompressionType.ZLIB:
                decompressed = zlib.decompress(compressed_data)
            elif self._detected_compression == CompressionType.LZMA:
                decompressed = lzma.decompress(compressed_data)
            elif self._detected_compression == CompressionType.LZ4:
                try:
                    import lz4.block
                    decompressed = lz4.block.decompress(compressed_data, uncompressed_size=expected_size)
                except ImportError:
                    raise ValueError("LZ4 support not available")
            else:
                raise ValueError(f"Unsupported compression: {self._detected_compression}")

            # Validate size
            if len(decompressed) != expected_size:
                logger.warning(f"Decompressed size mismatch: got {len(decompressed)}, expected {expected_size}")

            return decompressed

        except Exception as e:
            raise ValueError(f"Decompression failed: {e}")

    def _decompress_data(self, compressed_data: bytes, expected_size: int = None) -> bytes:
        """
        Decompress data using the detected compression method.
        """
        if len(compressed_data) == 0:
            raise ValueError("Empty compressed data")

        try:
            if self._detected_compression == CompressionType.ZLIB:
                decompressed = zlib.decompress(compressed_data)
            elif self._detected_compression == CompressionType.LZMA:
                decompressed = lzma.decompress(compressed_data)
            elif self._detected_compression == CompressionType.LZ4:
                # LZ4 requires the lz4 package
                try:
                    import lz4.block
                    if expected_size:
                        decompressed = lz4.block.decompress(compressed_data, uncompressed_size=expected_size)
                    else:
                        # Try without size hint
                        decompressed = lz4.block.decompress(compressed_data)
                except ImportError:
                    raise ValueError("LZ4 decompression requires the lz4 package")
            else:
                raise ValueError(f"Unsupported compression: {self._detected_compression}")

            logger.debug(f"Decompressed {len(compressed_data)} -> {len(decompressed)} bytes")
            return decompressed

        except Exception as e:
            raise ValueError(f"Decompression failed: {e}")

    def _read_uncompressed_binary(self, data_text: str, array_data: dict) -> bytes:
        """
        Read uncompressed binary data with size header.
        """
        byte_string = pybase64.b64decode(data_text)

        header_dtype = self._get_numpy_header_dtype()
        header_size = header_dtype.itemsize

        if len(byte_string) < header_size:
            raise ValueError("Insufficient data for header")

        # Read size
        total_bytes = self._read_header_value(byte_string, 0, header_dtype)
        logger.debug(f"Uncompressed data size: {total_bytes}")

        # Extract data (skip size header)
        if header_size + total_bytes > len(byte_string):
            logger.warning(f"Data size mismatch: expected {total_bytes}, have {len(byte_string) - header_size}")
            return byte_string[header_size:]

        return byte_string[header_size:header_size + total_bytes]

    # ==================================================================================
    # Data conversion and validation methods
    # ==================================================================================

    def _bytes_to_array_robust(self, data_bytes: bytes, array_info: dict) -> np.ndarray:
        """
        Convert bytes to numpy array with robust error handling.
        """
        try:
            vtk_type = array_info.get('@type', 'Float32')
            num_components = int(array_info.get('@NumberOfComponents', 1))
            array_name = array_info.get('@Name', 'unknown')

            logger.debug(f"Converting {len(data_bytes)} bytes to array {array_name} "
                         f"(type: {vtk_type}, components: {num_components})")

            # Handle empty data
            if len(data_bytes) == 0:
                logger.warning(f"Empty data for array {array_name}")
                return np.array([])

            # Get numpy dtype
            from ..config import VTKConfig
            numpy_dtype = VTKConfig.get_numpy_dtype(vtk_type)
            if numpy_dtype is None:
                # Fallback to parsing
                numpy_dtype = self.parse_data_type(vtk_type)
                if numpy_dtype is None:
                    raise ValueError(f"Unknown VTK type: {vtk_type}")

            numpy_dtype = np.dtype(numpy_dtype)

            # Apply byte order
            if self.byte_order.lower() in ['little', 'littleendian']:
                numpy_dtype = numpy_dtype.newbyteorder('<')
            else:
                numpy_dtype = numpy_dtype.newbyteorder('>')

            # Handle string data
            if vtk_type.lower() == 'string':
                try:
                    data_str = data_bytes.decode('utf-8').rstrip('\x00')
                    return np.array(data_str.split('\x00'))
                except UnicodeDecodeError:
                    data_str = data_bytes.decode('latin1').rstrip('\x00')
                    return np.array(data_str.split('\x00'))

            # Convert to array
            element_size = numpy_dtype.itemsize

            # Fix alignment if needed
            if len(data_bytes) % element_size != 0:
                aligned_size = (len(data_bytes) // element_size) * element_size
                if aligned_size > 0:
                    logger.debug(f"Aligning {array_name}: {len(data_bytes)} -> {aligned_size} bytes")
                    data_bytes = data_bytes[:aligned_size]
                else:
                    logger.warning(f"Cannot align {array_name} data")
                    return np.array([])

            array = np.frombuffer(data_bytes, dtype=numpy_dtype)

            # Reshape for multi-component data
            if num_components > 1 and len(array) > 0:
                if len(array) % num_components != 0:
                    valid_length = (len(array) // num_components) * num_components
                    array = array[:valid_length]
                array = array.reshape(-1, num_components)

            logger.debug(f"Created array {array_name}: shape={array.shape}, dtype={array.dtype}")
            return array

        except Exception as e:
            logger.error(f"Error converting bytes to array: {e}")
            # Return empty array rather than failing
            return np.array([])

    # ==================================================================================
    # XML parsing and metadata methods
    # ==================================================================================

    def _extract_xml_metadata(self):
        """Extract XML metadata including header type for compression."""
        try:
            self.data_type = self._xml_data['@type']
            self.file_version = float(self._xml_data['@version'])
            self.byte_order = self._xml_data['@byte_order'].lower()

            # Get header type - critical for compression parsing
            self.byte_count_type = self._xml_data.get('@header_type', 'UInt32')

            # Set up byte count format for regular binary data parsing
            self.byte_count_format = _parse_bytecount_type(
                self.byte_count_type, self.byte_order
            )

            # Get data format
            try:
                self.data_format = next(dict_extract_generator(
                    '@format', self._xml_data[self.data_type]['Piece']
                ))
            except StopIteration:
                self.data_format = None

            self._piece_data = self._xml_data[self.data_type]['Piece']

            logger.debug(
                f"XML metadata: header_type={self.byte_count_type}, byte_order={self.byte_order}, format={self.data_format}")

        except KeyError as e:
            raise MissingDataError(f"Missing required XML attribute: {e}")
        except Exception as e:
            raise DataCorruptionError(f"Invalid XML metadata: {e}")

    def _parse_invalid_xml_with_binary(self, raw_bytes: bytes) -> Dict:
        """Parse XML files that have binary data mixed in."""
        try:
            # Find the end of the XML part
            xml_end_pattern = b'</VTKFile>'
            xml_end_pos = raw_bytes.find(xml_end_pattern)

            if xml_end_pos == -1:
                raise InvalidVTKFileError("Cannot find end of XML section")

            xml_end_pos += len(xml_end_pattern)
            xml_part = raw_bytes[:xml_end_pos]

            # Parse just the XML part
            xml_data = xmltodict.parse(xml_part)['VTKFile']

            # Handle appended data separately
            if xml_end_pos < len(raw_bytes):
                appended_part = raw_bytes[xml_end_pos:]
                self._handle_separated_appended_data(appended_part)

            return xml_data

        except Exception as e:
            raise InvalidVTKFileError(f"Failed to parse malformed XML: {e}")

    def _handle_appended_data(self):
        """Handle appended data from valid XML structure."""
        try:
            appended = self._xml_data.get('AppendedData', {})
            if appended:
                self.appended_data_bstr = appended.get('#text', '').strip('_')
                self.binary_data_encoding = appended.get('@encoding')

                if self.appended_data_bstr:
                    self._process_appended_data()

        except Exception as e:
            logger.warning(f"Error processing appended data: {e}")

    def _handle_separated_appended_data(self, appended_bytes: bytes):
        """Handle appended data that was separated from XML."""
        import re

        # Look for AppendedData marker
        appended_marker = b'<AppendedData'
        marker_pos = appended_bytes.find(appended_marker)

        if marker_pos != -1:
            # Extract encoding information
            encoding_pattern = rb'encoding="([^"]+)"'
            encoding_match = re.search(encoding_pattern, appended_bytes[marker_pos:marker_pos + 100])

            if encoding_match:
                self.binary_data_encoding = encoding_match.group(1).decode('utf-8')

            # Find the actual data (after the underscore marker)
            data_start = appended_bytes.find(b'_', marker_pos)
            if data_start != -1:
                self.appended_data_bstr = appended_bytes[data_start + 1:].decode('latin1')

    def _process_appended_data(self):
        """Process appended data."""
        if not self.appended_data_bstr:
            return

        try:
            # Get offset information from XML
            offset_keys = get_recursively(
                self._xml_data[self.data_type]['Piece'], '@offset'
            )

            if self.binary_data_encoding == 'base64':
                self._process_base64_appended_data(offset_keys)
            elif self.binary_data_encoding == 'raw':
                self._process_raw_appended_data(offset_keys)

        except Exception as e:
            logger.warning(f"Error processing appended data: {e}")

    def _process_base64_appended_data(self, offset_keys: list):
        """Process base64 encoded appended data."""
        try:
            # Decode base64 data
            decoded_data = pybase64.b64decode(self.appended_data_bstr)
            # Split data by offsets
            self._split_appended_data_by_offsets(decoded_data, offset_keys)
        except Exception as e:
            logger.error(f"Error processing base64 appended data: {e}")
            raise DataCorruptionError(f"Invalid base64 appended data: {e}")

    def _process_raw_appended_data(self, offset_keys: list):
        """Process raw binary appended data."""
        try:
            # Convert string back to bytes
            raw_data = self.appended_data_bstr.encode('latin1')
            # Split data by offsets
            self._split_appended_data_by_offsets(raw_data, offset_keys)
        except Exception as e:
            logger.error(f"Error processing raw appended data: {e}")
            raise DataCorruptionError(f"Invalid raw appended data: {e}")

    def _split_appended_data_by_offsets(self, data: bytes, offset_keys: list):
        """Split appended data into arrays based on offsets."""
        self.appended_data_arrays = {}
        sorted_offsets = sorted(set(int(offset) for offset in offset_keys))

        for i, offset in enumerate(sorted_offsets):
            try:
                if i < len(sorted_offsets) - 1:
                    next_offset = sorted_offsets[i + 1]
                    size_data = data[offset:offset + struct.calcsize(self.byte_count_format)]
                    if len(size_data) < struct.calcsize(self.byte_count_format):
                        continue

                    array_size = struct.unpack(self.byte_count_format, size_data)[0]
                    start_pos = offset + struct.calcsize(self.byte_count_format)
                    end_pos = min(start_pos + array_size, next_offset)
                else:
                    size_data = data[offset:offset + struct.calcsize(self.byte_count_format)]
                    if len(size_data) < struct.calcsize(self.byte_count_format):
                        continue

                    array_size = struct.unpack(self.byte_count_format, size_data)[0]
                    start_pos = offset + struct.calcsize(self.byte_count_format)
                    end_pos = start_pos + array_size

                if end_pos <= len(data):
                    array_data = data[start_pos:end_pos]
                    self.appended_data_arrays[offset] = array_data

            except Exception as e:
                logger.warning(f"Error processing array at offset {offset}: {e}")

    def _read_header_value(self, data: bytes, offset: int, dtype: np.dtype) -> int:
        """
        Read a single header value at the given offset.
        """
        if offset + dtype.itemsize > len(data):
            raise ValueError(f"Insufficient data at offset {offset}")

        value = np.frombuffer(data[offset:offset + dtype.itemsize], dtype=dtype)[0]
        return int(value)

    # ==================================================================================
    # Utility and helper methods
    # ==================================================================================

    def safe_array_conversion(data_bytes: bytes, target_dtype: np.dtype,
                              array_name: str = "unknown") -> np.ndarray:
        """
        Safely convert bytes to numpy array with automatic alignment fixing.
        """
        try:
            element_size = target_dtype.itemsize

            # Handle alignment issues
            if len(data_bytes) % element_size != 0:
                logger.warning(f"Fixing alignment for array {array_name}: "
                               f"{len(data_bytes)} bytes -> {(len(data_bytes) // element_size) * element_size}")
                data_bytes = data_bytes[:(len(data_bytes) // element_size) * element_size]

            if len(data_bytes) == 0:
                return np.array([], dtype=target_dtype)

            return np.frombuffer(data_bytes, dtype=target_dtype)

        except Exception as e:
            logger.error(f"Safe array conversion failed for {array_name}: {e}")
            return np.array([], dtype=target_dtype)

    def _safe_extract_data_arrays(self, data_section: str) -> Optional[Dict]:
        """Enhanced data array extraction with proper context."""
        try:
            raw_data = self._extract_raw_data_arrays(data_section)
            if raw_data is None:
                return None

            compression_context = {
                'xml_reader': self,
                'compression_processor': getattr(self, '_compression_processor', None)
            }

            return DataArrayProcessor.process_data_arrays(
                raw_data, 'xml', compression_context
            )
        except Exception as e:
            logger.warning(f"Error extracting {data_section} from XML: {e}")
            return None

    def _decode_array_legacy(self, array_data: Dict) -> np.ndarray:
        """
        Legacy decode_array implementation for backward compatibility.
        """
        try:
            data_text = array_data.get('#text', '')
            offset = array_data.get('@offset')
            vtk_type = array_data.get('@type', 'Float32')
            num_components = int(array_data.get('@NumberOfComponents', 1))

            # Get numpy dtype
            numpy_dtype = VTKConfig.get_numpy_dtype(vtk_type) or self.parse_data_type(vtk_type)

            if self.data_format == 'ascii':
                if vtk_type.lower() == 'string':
                    chars = list(map(chr, map(int, data_text.split())))
                    return ''.join(chars).rstrip('\x00').split('\x00')
                else:
                    array = np.fromstring(data_text, dtype=numpy_dtype, sep=' ')

            elif self.data_format == 'binary':
                binary_data = pybase64.b64decode(data_text)
                array = self._decode_byte_data(binary_data, numpy_dtype)

            elif self.data_format == 'appended':
                if self.appended_data_bstr is None:
                    raise ValueError("Appended data is required for 'appended' format")
                array = self._decode_byte_data(self.appended_data_arrays[offset], numpy_dtype)

            else:
                raise ValueError(f"Unknown format type: {self.data_format}")

            # Reshape if multi-component
            if num_components > 1 and vtk_type.lower() != 'string':
                array = array.reshape(-1, num_components)

            return array

        except Exception as e:
            raise DataCorruptionError(f"Legacy decode failed: {e}")

    def _get_numpy_header_dtype(self):
        """
        Get numpy dtype for header values based on XML header_type attribute.
        """
        # Map VTK header types to numpy dtypes
        type_map = {
            'UInt32': np.uint32,
            'UInt64': np.uint64,
            'Int32': np.int32,
            'Int64': np.int64
        }

        header_type = getattr(self, 'byte_count_type', 'UInt32')
        numpy_type = type_map.get(header_type, np.uint32)

        # Apply byte order
        if self.byte_order.lower() in ['little', 'littleendian']:
            return np.dtype(numpy_type).newbyteorder('<')
        else:
            return np.dtype(numpy_type).newbyteorder('>')

    def parse_data_type(self, vtk_type: str):
        """
        Parse VTK data type to numpy dtype.
        """
        type_map = {
            'Float32': np.float32,
            'Float64': np.float64,
            'Int8': np.int8,
            'UInt8': np.uint8,
            'Int16': np.int16,
            'UInt16': np.uint16,
            'Int32': np.int32,
            'UInt32': np.uint32,
            'Int64': np.int64,
            'UInt64': np.uint64,
        }
        return type_map.get(vtk_type)

    def validate_array_shape(array: np.ndarray, expected_components: int,
                             array_name: str = "unknown") -> np.ndarray:
        """
        Validate and fix array shape for multi-component data.
        """
        if expected_components <= 1:
            return array

        if len(array) == 0:
            return array

        # Check if reshaping is possible
        if len(array) % expected_components != 0:
            logger.warning(f"Array {array_name} length {len(array)} not divisible by {expected_components}")
            # Truncate to make it divisible
            valid_length = (len(array) // expected_components) * expected_components
            if valid_length > 0:
                array = array[:valid_length]
                logger.warning(f"Truncated array {array_name} to length {valid_length}")
            else:
                logger.error(f"No valid data for array {array_name} after component alignment")
                return np.array([])

        return array.reshape(-1, expected_components)

    def _validate_xml_structure(self):
        """Validate basic XML structure requirements."""
        try:
            # Check for required root attributes
            required_attrs = ['@type', '@version', '@byte_order']
            for attr in required_attrs:
                if attr not in self._xml_data:
                    raise InvalidVTKFileError(f"Missing required attribute: {attr}")

            # Check for data type piece
            data_type = self._xml_data['@type']
            if data_type not in self._xml_data:
                raise InvalidVTKFileError(f"Missing {data_type} section")

            if 'Piece' not in self._xml_data[data_type]:
                raise InvalidVTKFileError(f"Missing Piece section in {data_type}")

        except Exception as e:
            raise InvalidVTKFileError(f"Invalid XML structure: {e}")

    def _estimate_array_size(self, array_info: Dict) -> int:
        """Estimate the expected size of an array from its metadata."""
        try:
            vtk_type = array_info.get('@type', 'Float32')
            num_components = int(array_info.get('@NumberOfComponents', 1))

            # Try to get number of tuples from piece info
            num_tuples = None
            if 'NumberOfPoints' in self._piece_data:
                num_tuples = int(self._piece_data.get('@NumberOfPoints', 0))
            elif 'NumberOfCells' in self._piece_data:
                num_tuples = int(self._piece_data.get('@NumberOfCells', 0))

            if num_tuples is None:
                return -1  # Cannot estimate

            # Calculate size
            numpy_dtype = VTKConfig.get_numpy_dtype(vtk_type) or self.parse_data_type(vtk_type)
            if numpy_dtype is None:
                return -1

            element_size = np.dtype(numpy_dtype).itemsize
            return num_tuples * num_components * element_size

        except Exception as e:
            logger.debug(f"Cannot estimate array size: {e}")
            return -1

    def _log_compression_info(self):
        """Log detailed compression information for debugging."""
        if self._detected_compression != CompressionType.NONE:
            logger.info(f"Compression detected: {self._detected_compression.value}")
            logger.info(f"Data format: {self.data_format}")
            logger.info(f"Header type: {self.byte_count_type}")
            logger.info(f"Byte order: {self.byte_order}")

            # Log compressor attribute if present
            compressor = self._xml_data.get('@compressor', 'None')
            logger.info(f"Compressor attribute: {compressor}")

    def _check_data_integrity(self, array_name: str, expected_size: int, actual_size: int):
        """Check data integrity and log warnings."""
        if expected_size > 0 and actual_size != expected_size:
            ratio = actual_size / expected_size if expected_size > 0 else 0
            if ratio < 0.9 or ratio > 1.1:  # More than 10% difference
                logger.warning(f"Array {array_name} size mismatch: "
                               f"expected ~{expected_size}, got {actual_size} bytes (ratio: {ratio:.2f})")
            else:
                logger.debug(f"Array {array_name} size close to expected: "
                             f"{actual_size} vs {expected_size} bytes")

    def _try_repair_data(self, data_bytes: bytes, target_dtype: np.dtype,
                         expected_elements: int = None) -> bytes:
        """
        Try to repair data that doesn't align properly.
        """
        element_size = target_dtype.itemsize

        # Try padding if we're close to the expected size
        if expected_elements is not None:
            expected_size = expected_elements * element_size
            if len(data_bytes) < expected_size and len(data_bytes) > expected_size * 0.9:
                # Pad with zeros to reach expected size
                padding_needed = expected_size - len(data_bytes)
                logger.warning(f"Padding data with {padding_needed} zero bytes")
                return data_bytes + b'\x00' * padding_needed

        # Truncate to alignment boundary
        if len(data_bytes) % element_size != 0:
            aligned_size = (len(data_bytes) // element_size) * element_size
            logger.warning(f"Truncating data from {len(data_bytes)} to {aligned_size} bytes")
            return data_bytes[:aligned_size]

        return data_bytes

    def _get_data_section_info(self) -> Dict[str, Any]:
        """Get information about available data sections."""
        info = {
            'has_points': 'Points' in self._piece_data,
            'has_cells': 'Cells' in self._piece_data,
            'has_point_data': 'PointData' in self._piece_data,
            'has_cell_data': 'CellData' in self._piece_data,
            'has_field_data': 'FieldData' in self._piece_data,
            'data_format': self.data_format,
            'compression': self._detected_compression.value if self._detected_compression else 'none',
        }

        # Add counts if available
        try:
            if '@NumberOfPoints' in self._piece_data:
                info['num_points'] = int(self._piece_data['@NumberOfPoints'])
            if '@NumberOfCells' in self._piece_data:
                info['num_cells'] = int(self._piece_data['@NumberOfCells'])
        except (ValueError, KeyError):
            pass

        return info

    def _create_debug_report(self) -> Dict[str, Any]:
        """Create a debug report for troubleshooting."""
        report = {
            'file_path': str(self.file_path),
            'file_size': self.file_path.stat().st_size,
            'xml_metadata': {
                'type': getattr(self, 'data_type', 'unknown'),
                'version': getattr(self, 'file_version', 'unknown'),
                'byte_order': getattr(self, 'byte_order', 'unknown'),
                'header_type': getattr(self, 'byte_count_type', 'unknown'),
                'data_format': getattr(self, 'data_format', 'unknown'),
            },
            'compression': {
                'detected': self._detected_compression.value if self._detected_compression else 'none',
                'compressor_attr': self._xml_data.get('@compressor', 'none') if self._xml_data else 'none',
            },
            'data_sections': self._get_data_section_info(),
        }

        if hasattr(self, 'appended_data_bstr') and self.appended_data_bstr:
            report['appended_data'] = {
                'encoding': getattr(self, 'binary_data_encoding', 'unknown'),
                'size': len(self.appended_data_bstr),
                'num_arrays': len(getattr(self, 'appended_data_arrays', {})),
            }

        return report
