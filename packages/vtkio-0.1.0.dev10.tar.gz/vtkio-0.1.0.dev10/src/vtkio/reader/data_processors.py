# !/usr/bin/env python
"""
Unified data processing layer for VTK readers.

This module provides standardised processing for data arrays and VTK data structures,
reducing duplication between XML and HDF5 readers.
"""

__author__ = 'J.P. Morrissey'
__copyright__ = 'Copyright 2022-2025'
__maintainer__ = 'J.P. Morrissey'
__email__ = 'morrissey.jp@gmail.com'
__status__ = 'Development'


from typing import Dict, Any, Optional, Union, List
import numpy as np
import h5py
import logging

from .compression import CompressionType
# Import your existing VTK structures
from ..vtk_structures import (
    Cell, Grid, GridCoordinates, ImageData, PolyData, PolyDataTopology,
    RectilinearData, StructuredData, UnstructuredGrid
)

logger = logging.getLogger(__name__)


class DataArrayProcessor:
    """Unified processor for data arrays from both XML and HDF5 sources with compression support."""

    @staticmethod
    def process_data_arrays(data_source: Union[h5py.Group, Dict, List],
                            source_type: str = 'hdf5',
                            compression_context: Optional[Dict] = None) -> Optional[Dict[str, np.ndarray]]:
        """
        Process data arrays from either HDF5 or XML sources with compression support.

        Parameters
        ----------
        data_source : Union[h5py.Group, Dict, List]
            Source data from HDF5 group or XML dictionary/list
        source_type : str
            Type of source: 'hdf5' or 'xml'
        compression_context : dict, optional
            Compression context including processor and settings

        Returns
        -------
        Optional[Dict[str, np.ndarray]]
            Dictionary of processed arrays or None if no data
        """
        if source_type == 'hdf5':
            return DataArrayProcessor._process_hdf5_arrays(data_source, compression_context)
        elif source_type == 'xml':
            return DataArrayProcessor._process_xml_arrays(data_source, compression_context)
        else:
            raise ValueError(f"Unsupported source type: {source_type}")

    @staticmethod
    def _process_hdf5_arrays(hdf5_group: h5py.Group,
                             compression_context: Optional[Dict] = None) -> Optional[Dict[str, np.ndarray]]:
        """Process HDF5 group data arrays with compression awareness."""

        if not hdf5_group:
            return None

        data = {}
        try:
            # Handle both h5py.Group and dict cases
            if hasattr(hdf5_group, 'items'):  # h5py.Group
                items = hdf5_group.items()
            else:  # Dictionary
                items = hdf5_group.items()

            for dname, darray in items:
                # Skip if it's a group (not a dataset)
                if hasattr(darray, 'shape'):  # It's a dataset
                    # HDF5 handles compression transparently, but log if detected
                    if compression_context and hasattr(darray, 'compression'):
                        if darray.compression:
                            logger.debug(f"Reading compressed HDF5 dataset {dname} ({darray.compression})")

                    if len(darray.shape) == 0:
                        # Scalar dataset
                        data[dname] = darray[()]
                    else:
                        num_comp = darray.shape[-1] if len(darray.shape) > 1 else 1

                        if num_comp <= 1:
                            data[dname] = darray[:].reshape(-1, num_comp).flatten()
                        else:
                            data[dname] = darray[:].reshape(-1, num_comp)

        except Exception as e:
            logger.warning(f"Error processing HDF5 arrays: {e}")
            return None

        return data if data else None

    @staticmethod
    def _process_xml_arrays(xml_data: Union[Dict, List],
                            compression_context: Optional[Dict] = None) -> Optional[Dict[str, np.ndarray]]:
        """Process XML data arrays - SIMPLIFIED VERSION."""
        if not xml_data:
            return None

        try:
            xml_reader = compression_context.get('xml_reader') if compression_context else None
            if not xml_reader:
                logger.error("XML reader required for processing XML arrays")
                return None

            if isinstance(xml_data, list):
                data_arrays = {}
                for data in xml_data:
                    name, array = DataArrayProcessor._extract_single_xml_array(
                        data, xml_reader, compression_context
                    )
                    if name and array is not None:
                        data_arrays[name] = array
            else:
                name, array = DataArrayProcessor._extract_single_xml_array(
                    xml_data, xml_reader, compression_context
                )
                if name and array is not None:
                    data_arrays = {name: array}
                else:
                    return None

            return data_arrays if data_arrays else None

        except Exception as e:
            logger.error(f"Error processing XML arrays: {e}")
            return None

    @staticmethod
    def _extract_single_xml_array(xml_array_data: Dict[str, Any],
                                  xml_reader,
                                  compression_context: Optional[Dict] = None) -> tuple:
        """Extract single XML array - COMPLETE REWRITE."""
        array_name = xml_array_data.get('@Name', 'unknown')

        try:
            # Always delegate to XML reader - it knows its own data format
            return xml_reader.extract_data_array(xml_array_data)
        except Exception as e:
            logger.error(f"Error extracting array {array_name}: {e}")
            return array_name, None


class VTKDataProcessor:
    """Unified processor for creating VTK data structures."""

    @staticmethod
    def create_unstructured_grid(points: np.ndarray,
                                 connectivity: np.ndarray,
                                 offsets: np.ndarray,
                                 types: np.ndarray,
                                 point_data: Optional[Dict] = None,
                                 cell_data: Optional[Dict] = None,
                                 field_data: Optional[Dict] = None) -> UnstructuredGrid:
        """Create UnstructuredGrid with standardized validation."""
        # Validate inputs
        if points is None or len(points) == 0:
            raise ValueError("Points array is required and cannot be empty")
        if connectivity is None or offsets is None or types is None:
            raise ValueError("Connectivity, offsets, and types are required")

        topology = Cell(connectivity=connectivity, offsets=offsets, types=types)

        return UnstructuredGrid(
            points=points,
            cells=topology,
            point_data=point_data,
            cell_data=cell_data,
            field_data=field_data
        )

    @staticmethod
    def create_polydata(points: np.ndarray,
                        verts: Optional[PolyDataTopology] = None,
                        lines: Optional[PolyDataTopology] = None,
                        strips: Optional[PolyDataTopology] = None,
                        polys: Optional[PolyDataTopology] = None,
                        point_data: Optional[Dict] = None,
                        cell_data: Optional[Dict] = None,
                        field_data: Optional[Dict] = None) -> PolyData:
        """Create PolyData with standardized validation."""
        if points is None or len(points) == 0:
            logger.warning("PolyData created with empty or missing points")

        return PolyData(
            points=points,
            verts=verts,
            lines=lines,
            strips=strips,
            polys=polys,
            point_data=point_data,
            cell_data=cell_data,
            field_data=field_data
        )

    @staticmethod
    def create_image_data(grid_topology: Grid,
                          point_data: Optional[Dict] = None,
                          cell_data: Optional[Dict] = None,
                          field_data: Optional[Dict] = None) -> ImageData:
        """Create ImageData with standardized validation."""
        if grid_topology is None:
            raise ValueError("Grid topology is required for ImageData")

        return ImageData(
            point_data=point_data,
            cell_data=cell_data,
            field_data=field_data,
            grid=grid_topology
        )

    @staticmethod
    def create_structured_data(points: np.ndarray,
                               whole_extents: np.ndarray,
                               point_data: Optional[Dict] = None,
                               cell_data: Optional[Dict] = None,
                               field_data: Optional[Dict] = None) -> StructuredData:
        """Create StructuredData with standardized validation."""
        if points is None or whole_extents is None:
            raise ValueError("Points and whole_extents are required for StructuredData")

        return StructuredData(
            point_data=point_data,
            cell_data=cell_data,
            field_data=field_data,
            points=points,
            whole_extents=whole_extents
        )

    @staticmethod
    def create_rectilinear_data(coordinates: GridCoordinates,
                                point_data: Optional[Dict] = None,
                                cell_data: Optional[Dict] = None,
                                field_data: Optional[Dict] = None) -> RectilinearData:
        """Create RectilinearData with standardized validation."""
        if coordinates is None:
            raise ValueError("Grid coordinates are required for RectilinearData")

        return RectilinearData(
            point_data=point_data,
            cell_data=cell_data,
            field_data=field_data,
            coordinates=coordinates
        )


class PolyDataTopologyProcessor:
    """Specialized processor for PolyData topology elements."""

    @staticmethod
    def process_hdf5_topology(hdf5_group: h5py.Group,
                              topology_name: str) -> Optional[PolyDataTopology]:
        """Process topology from HDF5 source."""
        try:
            if topology_name not in hdf5_group:
                logger.debug(f"No {topology_name} topology found in HDF5")
                return None

            topology_group = hdf5_group[topology_name]

            # Extract connectivity and offsets
            connectivity = None
            offsets = None

            if 'Connectivity' in topology_group:
                connectivity = topology_group['Connectivity'][:]
            if 'Offsets' in topology_group:
                offsets = topology_group['Offsets'][:]
                # HDF5 format typically includes the first offset (0), remove it
                if len(offsets) > 0 and offsets[0] == 0:
                    offsets = offsets[1:]

            if connectivity is not None and offsets is not None:
                return PolyDataTopology(
                    connectivity=connectivity,
                    offsets=offsets
                )

        except (KeyError, Exception) as e:
            logger.debug(f"Error processing {topology_name} topology from HDF5: {e}")

        return None

    @staticmethod
    def process_xml_topology(xml_data: Dict,
                             xml_reader: 'XMLVTKReader',
                             topology_name: str) -> Optional[PolyDataTopology]:
        """Process topology from XML source."""
        try:
            # Check if the topology section exists
            if topology_name not in xml_data:
                logger.debug(f"No {topology_name} topology found in XML")
                return None

            topology_section = xml_data[topology_name]

            # Handle both 'DataArray' and 'Array' keys
            array_key = None
            for key in ['DataArray', 'Array']:
                if key in topology_section:
                    array_key = key
                    break

            if not array_key:
                logger.debug(f"No array data found in {topology_name}")
                return None

            # Create compression context for XML processing
            compression_context = {'xml_reader': xml_reader}

            topology_data = DataArrayProcessor._process_xml_arrays(
                topology_section[array_key],
                compression_context
            )

            if topology_data and 'connectivity' in topology_data and 'offsets' in topology_data:
                return PolyDataTopology(
                    connectivity=topology_data['connectivity'],
                    offsets=topology_data['offsets']
                )

        except (KeyError, Exception) as e:
            logger.debug(f"No {topology_name} topology found in XML: {e}")

        return None


class GridTopologyProcessor:
    """Processor for grid topology structures."""

    @staticmethod
    def create_grid_from_attributes(whole_extents: Union[np.ndarray, str],
                                    origin: Union[np.ndarray, str],
                                    spacing: Union[np.ndarray, str],
                                    direction: Union[np.ndarray, str] = None) -> Grid:
        """Create Grid topology from attributes (handles both HDF5 and XML)."""
        # Convert string attributes to numpy arrays if needed
        if isinstance(whole_extents, str):
            whole_extents = np.fromstring(whole_extents, dtype=int, sep=' ')
        if isinstance(origin, str):
            origin = np.fromstring(origin, dtype=np.float32, sep=' ')
        if isinstance(spacing, str):
            spacing = np.fromstring(spacing, dtype=np.float32, sep=' ')
        if isinstance(direction, str):
            direction = np.fromstring(direction, dtype=np.float32, sep=' ')

        return Grid(
            whole_extents=whole_extents,
            origin=origin,
            spacing=spacing,
            direction=direction
        )

    @staticmethod
    def create_grid_coordinates(x_coords: np.ndarray,
                                y_coords: np.ndarray,
                                z_coords: np.ndarray,
                                whole_extents: Union[np.ndarray, str]) -> GridCoordinates:
        """Create GridCoordinates structure."""
        if isinstance(whole_extents, str):
            whole_extents = np.fromstring(whole_extents, sep=' ')

        return GridCoordinates(
            x=x_coords,
            y=y_coords,
            z=z_coords,
            whole_extents=whole_extents
        )


# Utility functions for common operations
# def determine_points_key(raw_points: Dict[str, np.ndarray]) -> np.ndarray:
#     """Determine the correct points array from raw point data."""
#     # Try common point array names
#     point_keys = ['points', 'Points', 'coordinates', 'Coordinates']
#
#     for key in point_keys:
#         if key in raw_points:
#             return raw_points[key]
#
#     # If no standard key found, return the first array
#     if raw_points:
#         return next(iter(raw_points.values()))
#
#     raise ValueError("No point data found in raw_points dictionary")


def determine_points_key(raw_points: Dict[str, np.ndarray]) -> np.ndarray:
    """Determine the correct points array from raw point data with debugging."""
    logger.debug(f"determine_points_key called with keys: {list(raw_points.keys()) if raw_points else 'None'}")

    if not raw_points:
        raise ValueError("No point data found in raw_points dictionary")

    # Try common point array names
    point_keys = ['points', 'Points', 'coordinates', 'Coordinates']

    for key in point_keys:
        if key in raw_points:
            logger.debug(f"Found points using key: {key}")
            return raw_points[key]

    # If no standard key found, return the first array
    if raw_points:
        first_key = next(iter(raw_points.keys()))
        logger.debug(f"Using first available key: {first_key}")
        return raw_points[first_key]

    raise ValueError("No point data found in raw_points dictionary")


def safe_get_hdf5_attr(hdf5_obj: h5py.Group, attr_name: str, default=None):
    """Safely get HDF5 attribute with default fallback."""
    try:
        attr = hdf5_obj.attrs[attr_name]
        # Decode bytes to string if necessary
        if isinstance(attr, bytes):
            return attr.decode('utf-8')
        return attr
    except KeyError:
        logger.debug(f"Attribute {attr_name} not found, using default: {default}")
        return default


def safe_array_conversion(data_bytes: bytes, target_dtype: np.dtype,
                          array_name: str = "unknown") -> np.ndarray:
    """
    Safely convert bytes to numpy array with automatic alignment fixing.
    """
    try:
        element_size = target_dtype.itemsize

        # Handle alignment issues
        if len(data_bytes) % element_size != 0:
            logger.warning(f"Fixing alignment for array {array_name}: "
                           f"{len(data_bytes)} bytes -> {(len(data_bytes) // element_size) * element_size}")
            data_bytes = data_bytes[:(len(data_bytes) // element_size) * element_size]

        if len(data_bytes) == 0:
            return np.array([], dtype=target_dtype)

        return np.frombuffer(data_bytes, dtype=target_dtype)

    except Exception as e:
        logger.error(f"Safe array conversion failed for {array_name}: {e}")
        return np.array([], dtype=target_dtype)


def validate_array_shape(array: np.ndarray, expected_components: int,
                         array_name: str = "unknown") -> np.ndarray:
    """
    Validate and fix array shape for multi-component data.
    """
    if expected_components <= 1:
        return array

    if len(array) == 0:
        return array

    # Check if reshaping is possible
    if len(array) % expected_components != 0:
        logger.warning(f"Array {array_name} length {len(array)} not divisible by {expected_components}")
        # Truncate to make it divisible
        valid_length = (len(array) // expected_components) * expected_components
        if valid_length > 0:
            array = array[:valid_length]
            logger.warning(f"Truncated array {array_name} to length {valid_length}")
        else:
            logger.error(f"No valid data for array {array_name} after component alignment")
            return np.array([])

    return array.reshape(-1, expected_components)