#!/usr/bin/env python
"""
Module documentation goes here.

Created at 20:22, 26 Apr, 2022
"""

__author__ = 'J.P. Morrissey'
__copyright__ = 'Copyright 2022-2025'
__maintainer__ = 'J.P. Morrissey'
__email__ = 'morrissey.jp@gmail.com'
__status__ = 'Development'

# Standard Library


# Imports
import numpy as np

from vtkio.config import ReaderSettings, create_performance_settings
# Local Sources
from vtkio.reader import read_vtkxml_data
from vtkio.reader.api import load_vtk_data

from vtkio.reader.readers import UnifiedXMLReader, UnifiedHDF5Reader

#%% test xml polydata reading
plate_data = read_vtkxml_data('../TestData/vtp/plate_vectors.vtp')
map_data = read_vtkxml_data('../TestData/vtp/map.vtp')
poly_verts_data = read_vtkxml_data('../TestData/vtp/polytest.vtp')
lines_data = read_vtkxml_data('../TestData/vtp/ibm_with_data.vtp')
cow_data = read_vtkxml_data('../TestData/vtp/cow.vtp')

#%%text new xml polydata reader
# Basic usage (uses config defaults)
data = load_vtk_data('../TestData/vtp/plate_vectors.vtp')

# With custom settings
settings = ReaderSettings(validate_topology=False)
data2 = load_vtk_data('../TestData/vtp/plate_vectors.vtp', settings=settings)

# Performance optimised
data3 = load_vtk_data('../TestData/vtkhdf/plate_vectors.vtkhdf', create_performance_settings())

# read compressed xml data
data4 = load_vtk_data('../TestData/vtp/plate_vectors_compressed_binary.vtp')

print(data)