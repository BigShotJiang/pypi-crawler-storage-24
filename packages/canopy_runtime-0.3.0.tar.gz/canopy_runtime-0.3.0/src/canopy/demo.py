from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .core import authorize_action


def _print_decision(label: str, decision: Dict[str, Any]) -> None:
    d = decision.get("decision")
    reason = decision.get("reason")
    severity = decision.get("severity", "")
    layers = decision.get("layers", {})
    auth_id = decision.get("authorization_id", "")
    avid = decision.get("avid", "")

    print(label)
    print(f"  Decision  : {d} [{severity}]")
    print(f"  Reason    : {reason}")
    print(f"  Layers    : {layers}")
    print(f"  AVID      : {avid}")
    print(f"  Audit ID  : {auth_id}")
    print("")


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Canopy demo: authorize actions and write an audit log.")
    p.add_argument("--env", default="production", help="agent_ctx env label (default: production)")
    p.add_argument(
        "--safe-path",
        action="append",
        default=[],
        help='repeatable; adds to agent_ctx["safe_paths"] (example: --safe-path /tmp/)',
    )
    p.add_argument("--policy-file", default=None, help="path to a YAML policy file (defaults to bundled policy)")
    p.add_argument("--audit-log-path", default=None, help="path to audit log (default: ./audit.log)")
    p.add_argument("--no-write", action="store_true", help="do not write any files (default: writes are simulated)")
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)
    agent_ctx: Dict[str, Any] = {
        "env": args.env,
        # For production: use a real ECDSA public key unique per agent instance.
        # For development: any unique string per agent is sufficient.
        "public_key": "pk-demo-agent-001",
        "created_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    }
    if args.safe_path:
        agent_ctx["safe_paths"] = list(args.safe_path)

    policy_file = args.policy_file
    audit_log_path = args.audit_log_path

    print("Canopy demo — decisions + audit log")
    print(f"agent_ctx={agent_ctx}")
    print(f"audit_log_path={audit_log_path or 'audit.log'}")
    print("")

    _print_decision(
        "1) execute_shell rm -rf",
        authorize_action(
            agent_ctx,
            "execute_shell",
            {"command": "rm -rf /tmp/logs"},
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        ),
    )
    _print_decision(
        "2) execute_shell curl http",
        authorize_action(
            agent_ctx,
            "execute_shell",
            {"command": "curl http://example.com"},
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        ),
    )
    _print_decision(
        "3) modify_file /etc/passwd",
        authorize_action(
            agent_ctx,
            "modify_file",
            {"path": "/etc/passwd"},
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        ),
    )

    demo_path = str(Path("/tmp/canopy_demo.txt"))
    decision = authorize_action(
        agent_ctx,
        "modify_file",
        {"path": demo_path},
        policy_file=policy_file,
        audit_log_path=audit_log_path,
    )
    _print_decision(f"4) modify_file {demo_path}", decision)
    if not args.no_write and decision.get("decision") == "ALLOW":
        Path(demo_path).write_text("hello from canopy\n", encoding="utf-8")
        print(f"   wrote {demo_path}")
    else:
        print("   (no write performed)")

    _print_decision(
        "5) call_external_api https://example.com",
        authorize_action(
            agent_ctx,
            "call_external_api",
            {"url": "https://example.com"},
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        ),
    )

    log_path = Path(audit_log_path or "audit.log")
    if log_path.exists():
        print(f"Audit log written to: {log_path.resolve()}")
        print(f"Verify integrity with: canopy-verify {log_path}")
        print("")
        print("Last entry:")
        lines = log_path.read_text(encoding="utf-8").strip().splitlines()
        if lines:
            last = json.loads(lines[-1])
            print(f"  timestamp : {last.get('timestamp')}")
            print(f"  decision  : {last.get('decision')}")
            print(f"  entry_hash: {last.get('entry_hash')}")
            print(f"  prev_hash : {last.get('prev_hash')}")
            print("")

    print("")
    print("Tip: to allow writes, run with e.g. `--safe-path /tmp/`.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
