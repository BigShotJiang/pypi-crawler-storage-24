from __future__ import annotations

import os
import textwrap
from pathlib import Path
from typing import Any, Callable, Dict

from .audit import HashChainAuditLog
from .errors import CanopyPermissionError


def _audit_path() -> Path:
    return Path(os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"))


def _blocked_layers_text(result: Dict[str, Any]) -> str:
    layers = result.get("layers") if isinstance(result.get("layers"), dict) else {}
    parts = [f"{key}={value}" for key, value in layers.items() if value != "pass"]
    return ", ".join(parts) if parts else "(none)"


def _append_approval_event(result: Dict[str, Any], *, event: str, decision: str, reason: str) -> None:
    try:
        HashChainAuditLog(_audit_path()).append(
            avid=str(result.get("avid") or ""),
            action_type=str(result.get("action_type") or "approval"),
            decision=decision,
            reason=reason,
            severity=str(result.get("severity") or "low"),
            layers=result.get("layers") if isinstance(result.get("layers"), dict) else {},
            witness=result.get("witness") if isinstance(result.get("witness"), dict) else None,
            event=event,
            authorization_id=str(result.get("authorization_id") or "") or None,
            override_possible=result.get("override_possible"),
            override_key=result.get("override_key"),
        )
    except Exception:
        return


def format_approval_request(result: Dict[str, Any]) -> str:
    reason = str(result.get("reason") or "")
    reason_lines = textwrap.wrap(reason, width=49) or [""]
    header = "╔══ APPROVAL REQUIRED ═══════════════════════════════╗"
    footer = "╚═════════════════════════════════════════════════════╝"

    body = [
        "║                                                     ║",
        f"║  Agent    : {str(result.get('avid') or '')[:38]:<38}║",
        f"║  Action   : {str(result.get('action_type') or 'approval')[:38]:<38}║",
        f"║  Severity : {str(result.get('severity') or '')[:38]:<38}║",
        "║                                                     ║",
    ]
    for idx, line in enumerate(reason_lines):
        label = "Reason" if idx == 0 else ""
        body.append(f"║  {label:<8}: {line[:38]:<38}║")
    body.extend(
        [
            "║                                                     ║",
            f"║  Layers   : {_blocked_layers_text(result)[:38]:<38}║",
            "║                                                     ║",
            f"║  Audit ID : {str(result.get('authorization_id') or '')[:38]:<38}║",
        ]
    )
    if result.get("override_key"):
        body.append(f"║  Override : {str(result.get('override_key'))[:38]:<38}║")
    body.extend(
        [
            "║                                                     ║",
            footer,
            "",
            "Approve this action? [y/N]: ",
        ]
    )
    return "\n".join([header, *body])


def prompt_for_approval(result: Dict[str, Any], func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    prompt = format_approval_request(result)
    approved = input(prompt).strip().lower().startswith("y")
    if approved:
        _append_approval_event(
            result,
            event="approval_granted",
            decision="APPROVED",
            reason="Human approved the action via prompt_for_approval.",
        )
        return func(*args, **kwargs)

    _append_approval_event(
        result,
        event="approval_rejected",
        decision="REJECTED",
        reason="Human rejected the action via prompt_for_approval.",
    )
    raise CanopyPermissionError({**result, "reason": "Human rejected the action"})


def format_approval_webhook(result: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "type": "canopy.approval_required",
        "decision": result.get("decision"),
        "reason": result.get("reason"),
        "severity": result.get("severity"),
        "avid": result.get("avid"),
        "audit_id": result.get("authorization_id"),
        "layers": result.get("layers", {}),
        "override_key": result.get("override_key"),
        "override_possible": result.get("override_possible", False),
        "message": format_approval_request(result),
    }
