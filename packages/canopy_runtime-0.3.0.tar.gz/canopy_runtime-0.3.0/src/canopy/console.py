from __future__ import annotations

import argparse
import io
from contextlib import redirect_stdout
from pathlib import Path
from typing import Any, Dict, Optional

from rich.console import Console
from rich.panel import Panel

from .audit import HashChainAuditLog
from .demo import main as demo_main
from .lint import main as lint_main
from .report import main as report_main
from .verify import main as verify_main


VERSION = "0.3.0"

_INTEGRATION_GUIDES: dict[str, dict[str, str]] = {
    "1": {
        "title": "LangChain Integration",
        "body": """Step 1 — Install
──────────────────
pip install canopy-runtime

Step 2 — Wrap your tool
────────────────────────
from canopy import safe_tool
from langchain.tools import tool

@safe_tool(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    }
)
@tool
def run_shell(command: str) -> str:
    import subprocess
    return subprocess.check_output(command, shell=True, text=True)

Step 3 — Check your audit log
─────────────────────────────
canopy-console  (you're already here)

⚠ REQUIRE_APPROVAL → ask a human, not the LLM""",
    },
    "2": {
        "title": "OpenAI Agents SDK Integration",
        "body": """Step 1 — Install
──────────────────
pip install canopy-runtime

Step 2 — Wrap your tool
────────────────────────
from agents import function_tool
from canopy import safe_tool

@function_tool
@safe_tool(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    }
)
def run_shell(command: str) -> str:
    import subprocess
    return subprocess.check_output(command, shell=True, text=True)

Step 3 — Review decisions
─────────────────────────
Use canopy-console to inspect the audit log after runs.

⚠ REQUIRE_APPROVAL → trigger human UX, not another model call""",
    },
    "3": {
        "title": "CrewAI Integration",
        "body": """Step 1 — Install
──────────────────
pip install canopy-runtime

Step 2 — Use the Canopy mixin
─────────────────────────────
from crewai.tools import BaseTool
from canopy import CanopyCrewAITool

class ShellTool(CanopyCrewAITool, BaseTool):
    name = "shell"
    description = "Runs shell commands"
    canopy_action_type = "execute_shell"
    canopy_agent_ctx = {
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    }

    def _run(self, command: str) -> str:
        import subprocess
        return subprocess.check_output(command, shell=True, text=True)

Step 3 — Review with canopy-console
───────────────────────────────────
Open the audit log and verify the chain after runs.""",
    },
    "4": {
        "title": "AutoGen Integration",
        "body": """Step 1 — Install
──────────────────
pip install canopy-runtime

Step 2 — Wrap before register_for_execution
───────────────────────────────────────────
from canopy import canopy_autogen_tool

@canopy_autogen_tool(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    },
)
def run_shell(command: str) -> str:
    import subprocess
    return subprocess.check_output(command, shell=True, text=True)

Step 3 — Register as usual
──────────────────────────
agent.register_for_execution()(run_shell)

⚠ Approval requests should go to a human callback, not back to the LLM""",
    },
    "5": {
        "title": "LangGraph Integration",
        "body": """Step 1 — Install
──────────────────
pip install canopy-runtime

Step 2 — Wrap the node
──────────────────────
from canopy import canopy_node

@canopy_node(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    },
    payload_extractor=lambda state: {"command": state["command"]},
)
def shell_node(state: dict) -> dict:
    import subprocess
    result = subprocess.run(state["command"], shell=True, capture_output=True, text=True)
    return {"output": result.stdout}

Step 3 — Inspect audit decisions
────────────────────────────────
Use canopy-console to review what the graph attempted.""",
    },
    "6": {
        "title": "Custom Runner / No Framework",
        "body": """Step 1 — Install
──────────────────
pip install canopy-runtime

Step 2 — Gate every action before execution
────────────────────────────────────────────
from canopy import authorize_action

result = authorize_action(
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    },
    action_type="execute_shell",
    action_payload={"command": command},
)

if result["decision"] == "ALLOW":
    run_the_tool()
elif result["decision"] == "REQUIRE_APPROVAL":
    ask_a_human()
else:
    block_the_action()

Step 3 — Audit everything
─────────────────────────
Review audit.log with canopy-console / canopy-report / canopy-verify.""",
    },
}


def _capture(fn, argv: list[str]) -> tuple[int, str]:
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        rc = fn(argv)
    return int(rc), buffer.getvalue().strip()


def _audit_status(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {
            "found": False,
            "entries": 0,
            "chain": "N/A",
            "last_timestamp": "",
            "last_decision": "",
            "last_severity": "",
        }

    log = HashChainAuditLog(path)
    entries = list(log.iter_entries())
    last = entries[-1] if entries else {}
    return {
        "found": True,
        "entries": len(entries),
        "chain": "✓ VALID" if log.verify_integrity() else "✗ INVALID",
        "last_timestamp": str(last.get("timestamp", "")),
        "last_decision": str(last.get("decision", "")),
        "last_severity": str(last.get("severity", "")),
    }


def render_screen(audit_log_path: Path, *, policy_file: Optional[str] = None, version: str = VERSION) -> str:
    status = _audit_status(audit_log_path)
    lines: list[str] = [
        "",
        f"       ▓▓▓ CANOPY GOVERNANCE CONSOLE v{version} ▓▓▓",
        "            Agent Safety Runtime — MIT",
        "",
    ]
    if status["found"]:
        lines.extend(
            [
                f"  Audit Log   : {audit_log_path}",
                f"  Entries     : {status['entries']}          Chain : {status['chain']}",
                f"  Last event  : {status['last_timestamp']}   Decision : {status['last_decision']} [{status['last_severity']}]",
                "",
                "  What would you like to do?",
                "",
                "  [1]  View audit log",
                "  [2]  Verify chain integrity",
                "  [3]  Export audit log to Excel",
                "  [4]  Lint policy file",
                "  [5]  Run demo",
                "  [6]  How to connect Canopy to your agent",
                "",
                "  [q]  Quit",
            ]
        )
    else:
        lines.extend(
            [
                "  Audit Log   : not found",
                "  Run [5] to generate a demo log, or point Canopy to your",
                "  existing audit.log with:",
                "",
                "  canopy-console --audit-log path/to/audit.log",
                "",
            ]
        )
        if policy_file:
            lines.append(f"  Policy file : {policy_file}")
            lines.append("")
        lines.extend(
            [
                "  [5]  Run demo",
                "  [q]  Quit",
            ]
        )
    return "\n".join(lines)


def _show(console: Console, title: str, content: str) -> None:
    console.clear()
    console.print(Panel.fit(content or "(no output)", title=title, border_style="cyan"))
    console.input("\nPress Enter to return to menu")


def _integration_menu(console: Console) -> None:
    while True:
        console.clear()
        body = "\n".join(
            [
                "  What are you using?",
                "",
                "  [1]  LangChain",
                "  [2]  OpenAI Agents SDK",
                "  [3]  CrewAI",
                "  [4]  AutoGen",
                "  [5]  LangGraph",
                "  [6]  My own runner / no framework",
                "",
                "  [b]  Back",
            ]
        )
        console.print(Panel.fit(body, title="How to connect Canopy to your agent", border_style="magenta"))
        choice = console.input(" → Select framework: ").strip().lower()
        if choice == "b":
            return
        guide = _INTEGRATION_GUIDES.get(choice)
        if guide is None:
            _show(console, "Unknown Option", f"Unknown framework selection: {choice!r}")
            continue

        while True:
            console.clear()
            content = guide["body"] + "\n\n[b] Back to frameworks    [q] Quit"
            console.print(Panel.fit(content, title=guide["title"], border_style="blue"))
            next_choice = console.input(" → Select option: ").strip().lower()
            if next_choice == "b":
                break
            if next_choice == "q":
                console.print("\nGoodbye. Your agents are governed.")
                raise SystemExit(0)
            _show(console, "Unknown Option", f"Unknown selection: {next_choice!r}")


def _run_option(console: Console, choice: str, *, audit_log_path: Path, policy_file: Optional[str]) -> Optional[int]:
    if choice == "1":
        rc, output = _capture(report_main, [str(audit_log_path)])
        _show(console, "Audit Report", output)
        return rc

    if choice == "2":
        rc, output = _capture(verify_main, [str(audit_log_path)])
        _show(console, "Chain Verification", output)
        return rc

    if choice == "3":
        filename = console.input("Export filename [audit_report.xlsx]: ").strip() or "audit_report.xlsx"
        rc, output = _capture(report_main, [str(audit_log_path), "--all", "--export", filename])
        _show(console, "Excel Export", output)
        return rc

    if choice == "4":
        default = policy_file or "src/canopy/policies/default.yaml"
        entered = console.input(f"Policy file path [{default}]: ").strip() or default
        rc, output = _capture(lint_main, [entered])
        _show(console, "Policy Lint", output)
        return rc

    if choice == "5":
        confirm = console.input(
            "This will run the Canopy demo and write to a temporary audit log.\nContinue? [y/N]: "
        ).strip().lower()
        if confirm.startswith("y"):
            temp_log = "/tmp/canopy-demo.log"
            argv = ["--audit-log-path", temp_log]
            if policy_file:
                argv.extend(["--policy-file", policy_file])
            rc, output = _capture(demo_main, argv)
            _show(console, "Demo Output", output)
            return rc
        _show(console, "Demo Cancelled", "Demo was not executed.")
        return 0

    if choice == "6":
        _integration_menu(console)
        return 0

    if choice.lower() == "q":
        console.print("\nGoodbye. Your agents are governed.")
        return 0

    _show(console, "Unknown Option", f"Unknown selection: {choice!r}")
    return None


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Interactive terminal console for Canopy governance tools.")
    parser.add_argument("--audit-log", default="audit.log", help="path to audit log (default: ./audit.log)")
    parser.add_argument("--policy", default=None, help="path to policy file for lint/demo shortcuts")
    args = parser.parse_args(argv)

    audit_log_path = Path(args.audit_log)
    policy_file = args.policy
    console = Console()

    while True:
        console.clear()
        body = render_screen(audit_log_path, policy_file=policy_file)
        console.print(Panel.fit(body, border_style="green"))
        choice = console.input(" → Select option: ").strip()
        rc = _run_option(console, choice, audit_log_path=audit_log_path, policy_file=policy_file)
        if choice.lower() == "q":
            return 0 if rc is None else rc


if __name__ == "__main__":
    raise SystemExit(main())
