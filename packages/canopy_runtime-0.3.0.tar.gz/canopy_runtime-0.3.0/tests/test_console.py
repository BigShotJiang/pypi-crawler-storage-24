from __future__ import annotations

from pathlib import Path

from canopy.audit import HashChainAuditLog
from canopy.console import VERSION, main, render_screen


def test_render_screen_with_log_shows_valid_status(tmp_path: Path):
    log_path = tmp_path / "audit.log"
    HashChainAuditLog(log_path).append(
        avid="AVID-1",
        action_type="execute_shell",
        decision="DENY",
        reason="Denied",
        severity="critical",
        layers={
            "constitution": "blocked (Art.0)",
            "civil_code": "skipped",
            "firewall": "skipped",
            "policy": "skipped",
        },
    )
    text = render_screen(log_path)
    assert f"CANOPY GOVERNANCE CONSOLE v{VERSION}" in text
    assert "Chain : ✓ VALID" in text
    assert "Audit Log   : " in text
    assert "[6]  How to connect Canopy to your agent" in text


def test_render_screen_without_log_shows_not_found(tmp_path: Path):
    text = render_screen(tmp_path / "missing.log")
    assert "Audit Log   : not found" in text
    assert "canopy-console --audit-log path/to/audit.log" in text


def test_main_quit_exits_zero(monkeypatch, capsys, tmp_path: Path):
    answers = iter(["q"])

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    rc = main(["--audit-log", str(tmp_path / "missing.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Goodbye. Your agents are governed." in out


def test_header_contains_version(tmp_path: Path):
    text = render_screen(tmp_path / "missing.log")
    assert f"v{VERSION}" in text


def test_console_can_open_integration_guide(monkeypatch, capsys, tmp_path: Path):
    answers = iter(["6", "1", "b", "b", "q"])

    class FakePanel:
        @staticmethod
        def fit(content, title=None, border_style=None):
            return f"{title or ''}\n{content}"

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    monkeypatch.setattr("canopy.console.Panel", FakePanel)
    rc = main(["--audit-log", str(tmp_path / "missing.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "How to connect Canopy to your agent" in out
    assert "LangChain Integration" in out
