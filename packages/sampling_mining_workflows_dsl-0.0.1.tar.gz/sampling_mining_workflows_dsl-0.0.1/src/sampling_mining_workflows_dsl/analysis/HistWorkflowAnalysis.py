from typing import TypeVar

from sampling_mining_workflows_dsl.analysis.HistAnalysis import HistAnalysis
from sampling_mining_workflows_dsl.analysis.WorkflowAnalysis import WorkflowAnalysis
from sampling_mining_workflows_dsl.metadata.Metadata import Metadata
from sampling_mining_workflows_dsl.operator.clustering.GroupingOperator import GroupingOperator

T = TypeVar("T")


class HistWorkflowAnalysis(WorkflowAnalysis):
    def __init__(
        self,
        metadata: Metadata[T],
        top_x: int = -1,
        category: bool = True,
        sort: bool = False,
        output_path: str = "hist_analysis/",
        log_y: bool = False,
        fixed_bins: int = None,
        max_x_bound: float = None,
        x_label: str = None,
        fig_size=(10,6)
    ):
        super().__init__()
        self.category = category
        self.sort = sort
        self.metadata = metadata
        self.file_path = output_path
        self.top_x = top_x
        self.log_y = log_y
        self.fixed_bins = fixed_bins
        self.max_x_bound = max_x_bound
        self.x_label = x_label
        self.fig_size = fig_size

    def analyze(
        self, workflow, workflow_name: str = "main workflow", op_number: int = 1
    ):
        op = workflow.get_root()
        analysis = HistAnalysis(
            self.file_path, self.metadata, self.top_x, self.category, self.sort, 
            show=False, log_y=self.log_y, fixed_bins=self.fixed_bins, 
            max_x_bound=self.max_x_bound, x_label=self.x_label,fig_size=self.fig_size
        )
        analysis.analyze(
            op.get_input(),
            f"{self.metadata.name}_{workflow_name}_op{op_number}_input.svg",
            f"",
        )

        while op is not None:
            if isinstance(op, GroupingOperator):
                analysis.analyze(
                    op.get_merged_output(),
                    f"{self.metadata.name}_{workflow_name}_op{op_number}_output.svg",
                    f"",
                )
                for i, internal_w in enumerate(op.get_workflows(), start=1):
                    # Recursively analyze subworkflows
                    subworkflow_name = f"subworkflow {i}"
                    self.analyze(
                        internal_w, subworkflow_name, 1
                    )  # Reset operator numbering for subworkflows
            else:
                analysis.analyze(
                    op.get_output(),
                    f"{self.metadata.name}_{workflow_name}_op{op_number}_output.svg",
                    f"",
                )
            op = op.get_next_operator()
            op_number += 1
