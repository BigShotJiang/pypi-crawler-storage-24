from typing import TypeVar

from sampling_mining_workflows_dsl.element.Repository import Repository
from sampling_mining_workflows_dsl.element.Set import Set
from sampling_mining_workflows_dsl.operator.Operator import Operator

from sampling_mining_workflows_dsl.operator.set_algebra.SetOperator import SetOperator

T = TypeVar("T")


class DifferenceOperator(SetOperator):
        def __init__(self, workflow,indexes=[-1]):
            super().__init__(workflow)
            self.set_function = Set.difference      
