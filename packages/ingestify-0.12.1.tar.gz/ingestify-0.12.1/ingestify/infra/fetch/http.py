import json
from datetime import datetime
from email.utils import format_datetime, parsedate
from hashlib import sha1
from io import BytesIO
from typing import BinaryIO, Optional, Callable, Tuple, Union

import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry

from ingestify.domain.models import DraftFile, File
from ingestify.domain.models.dataset.file import NotModifiedFile
from ingestify.utils import (
    utcnow,
    BufferedStream,
    detect_compression,
    gzip_uncompressed_size,
)

_session = None


def get_session():
    """Initialize the session when it's needed. This will make sure it's initialized
    within the correct context, and we don't get issues when the session is created
    in process #1 and used in process #2
    """
    global _session

    if not _session:
        retry_strategy = Retry(
            total=4,  # Maximum number of retries
            backoff_factor=2,  # Exponential backoff factor (e.g., 2 means 1, 2, 4, 8 seconds, ...)
            status_forcelist=[429, 500, 502, 503, 504],  # HTTP status codes to retry on
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)

        # Create a new session object
        _session = requests.Session()
        _session.mount("http://", adapter)
        _session.mount("https://", adapter)

    return _session


def retrieve_http(
    url,
    current_file: Optional[File] = None,
    headers: Optional[dict] = None,
    pager: Optional[Tuple[str, Callable[[str, dict], Optional[str]]]] = None,
    last_modified: Optional[datetime] = None,
    **kwargs,
) -> Union[DraftFile, NotModifiedFile]:
    headers = headers or {}
    if current_file:
        if last_modified and current_file.modified_at >= last_modified:
            # Not changed
            return NotModifiedFile(
                modified_at=last_modified,
                reason=f"last-modified same as current file: {current_file.modified_at} >= {last_modified}",
            )
        # else:
        #     print(f"{current_file.modified_at=} {last_modified=}")
        headers["if-modified-since"] = format_datetime(
            current_file.modified_at, usegmt=True
        )
        headers["if-none-match"] = current_file.tag

    http_kwargs = {}
    file_attributes = {}
    for key, item in kwargs.items():
        if key.startswith("http_"):
            http_kwargs[key[5:]] = item
        elif key.startswith("file_"):
            file_attributes[key[5:]] = item
        else:
            raise Exception(f"Don't know how to use {key}")

    ignore_not_found = http_kwargs.pop("ignore_not_found", False)

    response = get_session().get(url, headers=headers, stream=True, **http_kwargs)
    if response.status_code == 404 and ignore_not_found:
        return NotModifiedFile(
            modified_at=last_modified, reason="404 http code and ignore-not-found"
        )

    response.raise_for_status()
    if response.status_code == 304:
        # Not modified
        return NotModifiedFile(modified_at=last_modified, reason="304 http code")

    if last_modified:
        # From metadata received from api in discover_datasets
        modified_at = last_modified
    elif "last-modified" in response.headers:
        # Received from the webserver
        modified_at = parsedate(response.headers["last-modified"])
    else:
        modified_at = utcnow()

    tag = response.headers.get("etag")

    if pager:
        # Pager assembles multiple small JSON responses — load fully into memory
        data_path, pager_fn = pager
        data = []
        while True:
            current_page_data = response.json()
            data.extend(current_page_data[data_path])
            next_url = pager_fn(url, current_page_data)
            if not next_url:
                break
            else:
                response = requests.get(
                    next_url, headers=headers, stream=True, **http_kwargs
                )

        content_bytes = json.dumps({data_path: data}).encode("utf-8")
        if not tag:
            tag = sha1(content_bytes).hexdigest()
        if current_file and current_file.tag == tag:
            return NotModifiedFile(
                modified_at=last_modified, reason="tag matched current_file"
            )
        stream = BufferedStream.from_stream(BytesIO(content_bytes))
        content_length = len(content_bytes)
    else:
        # Stream response body directly into BufferedStream, hashing on the fly
        raw_stream = BufferedStream()
        hasher = sha1()
        for chunk in response.iter_content(chunk_size=1024 * 1024):
            hasher.update(chunk)
            raw_stream.write(chunk)

        if not tag:
            tag = hasher.hexdigest()

        if current_file and current_file.tag == tag:
            return NotModifiedFile(
                modified_at=last_modified, reason="tag matched current_file"
            )

        raw_stream.seek(0)
        content_compression_method = detect_compression(raw_stream)
        if content_compression_method == "gzip":
            content_length = gzip_uncompressed_size(raw_stream)
        else:
            raw_stream.seek(0, 2)
            content_length = raw_stream.tell()
            raw_stream.seek(0)
        stream = raw_stream

    return DraftFile(
        created_at=utcnow(),
        modified_at=modified_at,
        tag=tag,
        size=content_length,
        content_type=response.headers.get("content-type"),
        content_compression_method=content_compression_method,
        stream=stream,
        **file_attributes,
    )
