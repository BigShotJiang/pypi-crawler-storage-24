import os
from collections.abc import Iterable
from dataclasses import dataclass
from decimal import Decimal
from logging import Logger
from logging import getLogger
from traceback import format_exc
from typing import Any
from typing import Self

from niquests import AsyncResponse
from niquests import AsyncSession
from niquests import PreparedRequest
from niquests import Request
from niquests import Response
from niquests import Session
from niquests.auth import AsyncAuthBase
from niquests.auth import AuthBase
from niquests.typing import TLSClientCertType
from niquests.typing import TLSVerifyType
from urllib3_future.exceptions import RequestError

from .conf import SERVICE_REQUEST_CONTENT_LOG_LIMIT
from .conf import SERVICE_REQUEST_SHOW_HEADERS
from .conf import SERVICE_RESPONSE_CONTENT_LOG_LIMIT
from .conf import SERVICE_RESPONSE_SHOW_HEADERS
from .consts import LINE_LENGTH
from .consts import THICK_LINE
from .exceptions import DecodeError
from .exceptions import ExhaustedRetriesError
from .exceptions import InternalServiceError
from .exceptions import OpenServiceError
from .exceptions import RetryableError
from .exceptions import RetryableStatusError
from .exceptions import UnexpectedStatusError
from .exceptions import get_event_id


@dataclass(kw_only=True)
class HTTPServiceResponse:
    status: int
    http_response: Response | AsyncResponse
    event_id: str
    json: None | list | dict = None

    def __getattr__(self, name):
        return getattr(self.http_response, name)


class HTTPServiceAuth(AuthBase):
    context: HTTPServiceContext
    service: HTTPService

    def __init__(self, context: HTTPServiceContext, service: HTTPService):
        self.context = context
        self.service = service

    def __call__(self, request: PreparedRequest) -> PreparedRequest:
        authed_request = self.service.auth(request, self.context)
        assert isinstance(authed_request, PreparedRequest), f"{self.service.auth} must return a PreparedRequest"
        return authed_request


class AsyncHTTPServiceAuth(AsyncAuthBase):
    context: AsyncHTTPServiceContext
    service: AsyncHTTPService

    def __init__(self, context: AsyncHTTPServiceContext, service: AsyncHTTPService):
        self.context = context
        self.service = service

    async def __call__(self, request: PreparedRequest) -> PreparedRequest:
        authed_request = await self.service.auth(request, self.context)
        assert isinstance(authed_request, PreparedRequest), f"{self.service.auth} must return a PreparedRequest"
        return authed_request


class HTTPServiceContext[RTYPE = HTTPServiceResponse]:
    auth_class = HTTPServiceAuth
    client_class = Session
    client: Session
    logger: Logger
    request_content_log_limit = SERVICE_REQUEST_CONTENT_LOG_LIMIT
    response_content_log_limit = SERVICE_RESPONSE_CONTENT_LOG_LIMIT

    def __init__(self, service: HTTPService[Self], event_id=None, auth=None, proxy=None, **kwargs):
        if auth is None:
            auth = self.auth_class(self, service)
        self.client = self.client_class(
            timeout=service.timeout,
            base_url=service.base_url,
            **kwargs,
        )
        self.client.auth = auth
        self.client.cert = service.cert
        self.client.verify = service.verify
        self.client.hooks["response"] = [self.log_response]
        self.proxy = proxy
        self.logger = service.logger
        self.retries = service.retries
        if event_id:
            if ":" not in event_id:
                raise ValueError("Expected a 'date:random:time' structured event id.")
        else:
            event_id = get_event_id()
        date, self.short_id = event_id.split(":", 1)
        self.event_id = f"{date}:{self.short_id}"

    def __enter__(self) -> Self:
        self.client.__enter__()
        return self

    def log_request(self, request: PreparedRequest):
        self.handle_log_request(request)

    def handle_log_request(self, request: PreparedRequest):
        if SERVICE_REQUEST_SHOW_HEADERS:
            header = " request headers ".center(LINE_LENGTH, "-"), "\n  ".join(f"{k}: {v!r}" for k, v in sorted(request.headers.items()))
        else:
            header = (request.headers.get("authorization", ""),)

        if request.body:
            size = len(request.body)
            limit = self.request_content_log_limit
            if limit and size > limit:
                content = f"{request.body!r:.{limit}}\n   ... {size - limit} more bytes"
            else:
                content = f"{request.body!r}"
            content_type = request.headers.get("content-type")
            content_type = "no content-type" if content_type is None else repr(content_type)
            request_line = f" request body ({content_type} - {size} bytes) ".center(LINE_LENGTH, "-")
        else:
            content = request_line = None

        if content is None:
            if SERVICE_REQUEST_SHOW_HEADERS:
                self.logger.info("[%s] %s %s\n%s\n  %s", self.short_id, request.method, request.url, *header)
            else:
                self.logger.info("[%s] %s %s +[%s]", self.short_id, request.method, request.url, *header)
        else:
            if SERVICE_REQUEST_SHOW_HEADERS:
                self.logger.info(
                    "[%s] %s %s\n%s\n  %s\n%s\n   %s\n%s",
                    self.short_id,
                    request.method,
                    request.url,
                    *header,
                    request_line,
                    content,
                    THICK_LINE,
                )
            else:
                self.logger.info(
                    "[%s] %s %s +[%s]\n%s\n   %s\n%s",
                    self.short_id,
                    request.method,
                    request.url,
                    *header,
                    request_line,
                    content,
                    THICK_LINE,
                )

    def log_response(self, response: Response):
        self.handle_log_response(response, response.content)

    def handle_log_response(self, response: Response | AsyncResponse, content):
        size = len(content)
        content_type = response.headers.get("content-type")
        content_type = "no content-type" if content_type is None else repr(content_type)
        response_line = f" response body ({content_type} - {size} bytes) ".center(LINE_LENGTH, "-")
        limit = self.response_content_log_limit
        if limit and size > limit:
            content = f"{content!r:.{limit}}\n   ... {size - limit} more bytes"
        else:
            content = f"{content!r}"
        if SERVICE_RESPONSE_SHOW_HEADERS:
            headers_line = " response headers ".center(LINE_LENGTH, "-")
            headers = "\n  ".join(f"{k}: {v!r}" for k, v in sorted(response.headers.items()))
            self.logger.info(
                "[%s] %s %s => %s in %.4fs (H%r)\n%s\n  %s\n%s\n  %s\n%s",
                self.short_id,
                response.request.method,
                response.url,
                response.status_code,
                response.elapsed.total_seconds(),
                response.http_version,
                headers_line,
                headers,
                response_line,
                content,
                THICK_LINE,
            )
        else:
            self.logger.info(
                "[%s] %s %s => %s in %.4fs (H%r)\n%s\n  %s\n%s",
                self.short_id,
                response.request.method,
                response.url,
                response.status_code,
                response.elapsed.total_seconds(),
                response.http_version,
                response_line,
                content,
                THICK_LINE,
            )

    def __exit__(self, exc_type, exc_val: Exception, exc_tb):
        self.client.__exit__(exc_type, exc_val, exc_tb)
        self.handle_exit(exc_type, exc_val, exc_tb)

    def handle_exit(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            return
        else:
            self.logger.warning("[%s] __exit__ !> %r", self.short_id, exc_val)

    def handle_process_response(
        self,
        response: Response,
        *,
        retry_statuses: set[int],
        accept_statuses: set[int],
        json,
    ) -> RTYPE:
        if response.status_code in retry_statuses:
            raise RetryableStatusError(response, accept_statuses, retry_statuses, event_id=self.event_id)
        elif response.status_code not in accept_statuses:
            raise UnexpectedStatusError(response, accept_statuses, event_id=self.event_id)

        return HTTPServiceResponse(
            status=response.status_code,
            http_response=response,
            json=json,
            event_id=self.event_id,
        )

    def handle_prepare_request(
        self,
        method,
        url,
        *,
        accept_statuses: set[int],
        expect_json: bool,
        follow_redirects: bool,
        retries_left: int,
        retry_count: int,
        retry_statuses: set[int],
        **kwargs,
    ) -> PreparedRequest:
        request = Request(method=method, url=url, **kwargs, base_url=self.client.base_url)
        return self.client.prepare_request(request)

    def handle_retriable_failure(self, method, url, exc, retries_left, retry_budget):
        if retries_left:
            self.logger.error("[%s] %s %s !> %r (will retry %s more times)\n%s", self.short_id, method, url, exc, retries_left, format_exc(limit=5))
        else:
            if retry_budget:
                self.logger.error("[%s] %s %s !> %r (exhausted retries)", self.short_id, method, url, exc)
            else:
                self.logger.error("[%s] %s %s !> %r (no retry)", self.short_id, method, url, exc)
                raise InternalServiceError(exc, event_id=self.event_id) from exc

    def request(
        self,
        method: str,
        url: str,
        *,
        accept_statuses: Iterable[int] = (200,),
        expect_json: bool = True,
        follow_redirects: bool = False,
        retry_statuses: Iterable[int] = (500, 502, 503, 504),
        retry: bool = True,
        proxy: str | None = None,
        stream: bool | None = None,
        verify: TLSVerifyType | None = None,
        cert: TLSClientCertType | None = None,
        **kwargs,
    ) -> RTYPE:
        retry_statuses = set(retry_statuses)
        accept_statuses = set(accept_statuses)
        assert not (common := sorted(retry_statuses & accept_statuses)), f"{common} is in both retry_statuses and accept_statuses!"
        retry_failures = []
        retry_budget = self.retries if retry else 0
        for retries_left in reversed(range(retry_budget + 1)):
            prepared_request = self.handle_prepare_request(
                method,
                url,
                accept_statuses=accept_statuses,
                expect_json=expect_json,
                follow_redirects=follow_redirects,
                retries_left=retries_left,
                retry_statuses=retry_statuses,
                retry_count=retry_budget - retries_left,
                **kwargs,
            )
            proxy = proxy or self.proxy
            proxies = {"http": proxy, "https": proxy} if proxy else {}
            settings = self.client.merge_environment_settings(prepared_request.url, proxies, stream, verify, cert)
            try:
                self.log_request(prepared_request)
                response = self.client.send(prepared_request, timeout=self.client.timeout, allow_redirects=follow_redirects, **settings)
                if expect_json:
                    try:
                        json = response.json(parse_float=Decimal)
                    except Exception as exc:
                        raise DecodeError(response, exc, event_id=self.event_id) from exc
                else:
                    json = None
                return self.handle_process_response(response, retry_statuses=retry_statuses, accept_statuses=accept_statuses, json=json)
            except (RequestError, RetryableError) as exc:
                retry_failures.append(exc)
                self.handle_retriable_failure(method, prepared_request.url, exc, retries_left, retry_budget)
            except (InternalServiceError, OpenServiceError) as exc:
                self.logger.warning("[%s] %s %s !> failed: %r", self.short_id, method, prepared_request.url, exc)
                raise
            except Exception as exc:
                self.logger.error("[%s] %s %s !> %r (not retryable)", self.short_id, method, prepared_request.url, exc)
                raise InternalServiceError(exc, event_id=self.event_id) from exc
        else:
            raise ExhaustedRetriesError(retry_budget, retry_failures, event_id=self.event_id)


class AsyncHTTPServiceContext[RT = HTTPServiceResponse](HTTPServiceContext[RT]):
    auth_class = AsyncHTTPServiceAuth
    client_class = AsyncSession
    client: AsyncSession
    logger: Logger

    async def __aenter__(self) -> Self:
        await self.client.__aenter__()
        return self

    async def log_request(self, request: PreparedRequest):
        self.handle_log_request(request)

    async def log_response(self, response: AsyncResponse | Response):
        if isinstance(response, AsyncResponse):
            content = await response.content
        else:
            content = response.content
        self.handle_log_response(response, content)

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.__aexit__(exc_type, exc_val, exc_tb)
        self.handle_exit(exc_type, exc_val, exc_tb)

    async def request(
        self,
        method,
        url,
        *,
        accept_statuses: Iterable[int] = (200,),
        expect_json: bool = True,
        follow_redirects: bool = False,
        retry_statuses: Iterable[int] = (500, 502, 503, 504),
        retry: bool = True,
        proxy: str | None = None,
        stream: bool | None = None,
        verify: TLSVerifyType | None = None,
        cert: TLSClientCertType | None = None,
        **kwargs,
    ) -> RT:
        retry_statuses = set(retry_statuses)
        accept_statuses = set(accept_statuses)
        assert not (common := sorted(retry_statuses & accept_statuses)), f"{common} is in both retry_statuses and accept_statuses!"
        retry_failures = []
        retry_budget = self.retries if retry else 0
        for retries_left in reversed(range(retry_budget + 1)):
            prepared_request = self.handle_prepare_request(
                method,
                url,
                accept_statuses=accept_statuses,
                expect_json=expect_json,
                follow_redirects=follow_redirects,
                retries_left=retries_left,
                retry_statuses=retry_statuses,
                retry_count=retry_budget - retries_left,
                **kwargs,
            )
            if prepared_request._asynchronous_auth:
                # needs a solution with less internals coupling
                r = await prepared_request._pending_async_auth(prepared_request)
                prepared_request.__dict__.update(r.__dict__)
                prepared_request.prepare_content_length(prepared_request.body)
                del prepared_request._pending_async_auth
            proxy = proxy or self.proxy
            proxies = {"http": proxy, "https": proxy} if proxy else {}
            settings = self.client.merge_environment_settings(prepared_request.url, proxies, stream, verify, cert)
            try:
                await self.log_request(prepared_request)
                response = await self.client.send(prepared_request, timeout=self.client.timeout, allow_redirects=follow_redirects, **settings)
                if expect_json:
                    try:
                        if isinstance(response, AsyncResponse):
                            json = await response.json(parse_float=Decimal)
                        else:
                            json = response.json(parse_float=Decimal)
                    except Exception as exc:
                        raise DecodeError(response, exc, event_id=self.event_id) from exc
                else:
                    json = None
                return self.handle_process_response(response, retry_statuses=retry_statuses, accept_statuses=accept_statuses, json=json)
            except (RequestError, RetryableError) as exc:
                retry_failures.append(exc)
                self.handle_retriable_failure(method, prepared_request.url, exc, retries_left, retry_budget)
            except (InternalServiceError, OpenServiceError) as exc:
                self.logger.warning("[%s] %s %s !> failed: %r", self.short_id, method, prepared_request.url, exc)
                raise
            except Exception as exc:
                self.logger.error("[%s] %s %s !> %r (not retryable)", self.short_id, method, prepared_request.url, exc)
                raise InternalServiceError(exc, event_id=self.event_id) from exc
        else:
            raise ExhaustedRetriesError(retry_budget, retry_failures, event_id=self.event_id)


class HTTPService[CT = HTTPServiceContext]:
    context_class: type[CT] = HTTPServiceContext
    logger_name: str = "service"
    logger: Logger
    base_url: str
    timeout: int
    retries: int
    verify: bool
    cert: str

    def __init__(self, config: dict[str, Any]):
        self.base_url = config["BASE_URL"]
        self.timeout = config.get("TIMEOUT", 60)
        self.retries = config.get("RETRIES", 3)
        self.verify = config.get("VERIFY", True)
        self.cert = config.get("CERT")
        self.logger = getLogger(self.logger_name)
        self.logger.info(
            "[pid:%s] Setting up %s with BASE_URL=%r TIMEOUT=%s RETRIES=%s VERIFY=%s",
            os.getpid(),
            type(self).__name__,
            self.base_url,
            self.timeout,
            self.retries,
            self.verify,
        )

    def context(self, **kwargs) -> CT:
        return self.context_class(self, **kwargs)

    def auth(self, request: PreparedRequest, context: CT) -> PreparedRequest:
        return request


class AsyncHTTPService[ACT = AsyncHTTPServiceContext](HTTPService[ACT]):
    context_class: type[AsyncHTTPServiceContext] = AsyncHTTPServiceContext

    def context(self, **kwargs) -> ACT:
        return self.context_class(self, **kwargs)

    async def auth(self, request: PreparedRequest, context: ACT) -> PreparedRequest:
        return request
