from os import getpid

import pytest
from inline_snapshot import snapshot
from niquests import PreparedRequest

from csu.service import AsyncHTTPService
from csu.service import HTTPService
from csu.service import HTTPServiceContext


class AuthedService(HTTPService):
    def __init__(self, url, **config):
        super().__init__(config={"BASE_URL": url, **config})
        self.config = {"custom": "config"}

    def auth(self, request: PreparedRequest, context: HTTPServiceContext) -> PreparedRequest:
        response = context.request("POST", "post", json={"foobar": 123}, auth=False)
        assert response.json["json"] == {"foobar": 123}
        request.headers["X-Auth"] = "123"
        return request

    def test(self):
        with self.context(proxy=None) as ctx:
            ctx.request("GET", "json")


class AsyncAuthedService(AsyncHTTPService):
    def __init__(self, url, **config):
        super().__init__(config={"BASE_URL": url, **config})
        self.config = {"custom": "config"}

    async def auth(self, request: PreparedRequest, context: HTTPServiceContext) -> PreparedRequest:
        response = await context.request("POST", "post", json={"foobar": 123}, auth=False)
        assert response.json["json"] == {"foobar": 123}
        request.headers["X-Auth"] = "123"
        return request

    async def test(self):
        async with self.context(proxy=None) as ctx:
            await ctx.request("GET", "json")


@pytest.mark.vcr
def test_sync(httpbin, fake_accident_id, caplogs):
    srv = AuthedService(httpbin.url)
    srv.test()
    assert caplogs.get(
        HTTPBIN=f"{httpbin.host}:{httpbin.port}",
        PID=f"[pid:{getpid()}]",
    ) == snapshot(
        [
            "INFO    | [&PID] Setting up AuthedService with BASE_URL='http://[&HTTPBIN]' TIMEOUT=60 RETRIES=3 VERIFY=True",
            """\
INFO    | [01:000000.00] POST http://[&HTTPBIN]/post
------------------------------------------------------------- request headers --------------------------------------------------------------
  Accept: '*/*'
  Accept-Encoding: 'gzip, deflate, br'
  Connection: 'keep-alive'
  Content-Length: '15'
  Content-Type: 'application/json;charset=utf-8'
  User-Agent: 'niquests/3.18.1'
---------------------------------------- request body ('application/json;charset=utf-8' - 15 bytes) ----------------------------------------
   b'{"foobar": 123}'
============================================================================================================================================\
""",
            """\
INFO    | [01:000000.00] POST http://[&HTTPBIN]/post => 200 in 0.0000s (HNone)
------------------------------------------------------------- response headers -------------------------------------------------------------
  Access-Control-Allow-Credentials: 'true'
  Access-Control-Allow-Origin: '*'
  Connection: 'Close'
  Content-Length: '356'
  Content-Type: 'application/json'
  Date: 'Thu, 12 Mar 2026 20:22:10 GMT'
  Server: 'Pytest-HTTPBIN/0.1.0'
---------------------------------------------- response body ('application/json' - 356 bytes) ----------------------------------------------
  b'{"args":{},"data":"{\\\\"foobar\\\\": 123}","files":{},"form":{},"headers":{"Accept":"*/*","Accept-Encoding":"gzip, deflate, br","Connection":"keep-alive","Content-Length":"15","Content-Type":"application/json;charset=utf-8","Host":"127.0.0.1:38893","User-Agent":"niquests/3.18.1"},"json":{"foobar":123},"origin":"127.0.0.1","url":"http://127.0.0.1:38893/post"}\\n'
============================================================================================================================================\
""",
            """\
INFO    | [01:000000.00] GET http://[&HTTPBIN]/json
------------------------------------------------------------- request headers --------------------------------------------------------------
  Accept: '*/*'
  Accept-Encoding: 'gzip, deflate, br'
  Connection: 'keep-alive'
  User-Agent: 'niquests/3.18.1'
  X-Auth: '123'\
""",
            """\
INFO    | [01:000000.00] GET http://[&HTTPBIN]/json => 200 in 0.0000s (HNone)
------------------------------------------------------------- response headers -------------------------------------------------------------
  Access-Control-Allow-Credentials: 'true'
  Access-Control-Allow-Origin: '*'
  Connection: 'Close'
  Content-Length: '275'
  Content-Type: 'application/json'
  Date: 'Thu, 12 Mar 2026 20:22:10 GMT'
  Server: 'Pytest-HTTPBIN/0.1.0'
---------------------------------------------- response body ('application/json' - 275 bytes) ----------------------------------------------
  b'{"slideshow":{"author":"Yours Truly","date":"date of publication","slides":[{"title":"Wake up to WonderWidgets!","type":"all"},{"items":["Why <em>WonderWidgets</em> are great","Who <em>buys</em> WonderWidgets"],"title":"Overview","type":"all"}],"title":"Sample Slide Show"}}\\n'
============================================================================================================================================\
""",
        ]
    )


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_async(httpbin, fake_accident_id, caplogs):
    srv = AsyncAuthedService(httpbin.url)
    await srv.test()
    assert caplogs.get(
        HTTPBIN=httpbin.url,
        PID=f"[pid:{getpid()}]",
    ) == snapshot(
        [
            "INFO    | [&PID] Setting up AsyncAuthedService with BASE_URL='[&HTTPBIN]' TIMEOUT=60 RETRIES=3 VERIFY=True",
            """\
INFO    | [01:000000.00] POST [&HTTPBIN]/post
------------------------------------------------------------- request headers --------------------------------------------------------------
  Accept: '*/*'
  Accept-Encoding: 'gzip, deflate, br'
  Connection: 'keep-alive'
  Content-Length: '15'
  Content-Type: 'application/json;charset=utf-8'
  User-Agent: 'niquests/3.18.1'
------------------------------------------------------------- request content --------------------------------------------------------------
   b'{"foobar": 123}'
============================================================================================================================================\
""",
            """\
INFO    | [01:000000.00] POST [&HTTPBIN]/post => 200 in 0.0105s (H11)
------------------------------------------------------------- response headers -------------------------------------------------------------
  Access-Control-Allow-Credentials: 'true'
  Access-Control-Allow-Origin: '*'
  Connection: 'Close'
  Content-Length: '356'
  Content-Type: 'application/json'
  Date: 'Thu, 12 Mar 2026 20:29:34 GMT'
  Server: 'Pytest-HTTPBIN/0.1.0'
---------------------------------------------- response body ('application/json' - 356) bytes ----------------------------------------------
  b'{"args":{},"data":"{\\\\"foobar\\\\": 123}","files":{},"form":{},"headers":{"Accept":"*/*","Accept-Encoding":"gzip, deflate, br","Connection":"keep-alive","Content-Length":"15","Content-Type":"application/json;charset=utf-8","Host":"127.0.0.1:35321","User-Agent":"niquests/3.18.1"},"json":{"foobar":123},"origin":"127.0.0.1","url":"[&HTTPBIN]/post"}\\n'
============================================================================================================================================\
""",
            """\
INFO    | [01:000000.00] GET [&HTTPBIN]/json
------------------------------------------------------------- request headers --------------------------------------------------------------
  Accept: '*/*'
  Accept-Encoding: 'gzip, deflate, br'
  Connection: 'keep-alive'
  User-Agent: 'niquests/3.18.1'
  X-Auth: '123'\
""",
            """\
INFO    | [01:000000.00] GET [&HTTPBIN]/json => 200 in 0.0021s (H11)
------------------------------------------------------------- response headers -------------------------------------------------------------
  Access-Control-Allow-Credentials: 'true'
  Access-Control-Allow-Origin: '*'
  Connection: 'Close'
  Content-Length: '275'
  Content-Type: 'application/json'
  Date: 'Thu, 12 Mar 2026 20:29:34 GMT'
  Server: 'Pytest-HTTPBIN/0.1.0'
---------------------------------------------- response body ('application/json' - 275) bytes ----------------------------------------------
  b'{"slideshow":{"author":"Yours Truly","date":"date of publication","slides":[{"title":"Wake up to WonderWidgets!","type":"all"},{"items":["Why <em>WonderWidgets</em> are great","Who <em>buys</em> WonderWidgets"],"title":"Overview","type":"all"}],"title":"Sample Slide Show"}}\\n'
============================================================================================================================================\
""",
        ]
    )
