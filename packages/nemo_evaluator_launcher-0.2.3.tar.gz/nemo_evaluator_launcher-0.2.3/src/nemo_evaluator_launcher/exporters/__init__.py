# SPDX-FileCopyrightText: Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Exporter registration and factory."""

from nemo_evaluator_launcher.exporters.base import ExportConfig
from nemo_evaluator_launcher.exporters.gsheets import (
    GSheetsExporter,
    GSheetsExporterConfig,
)
from nemo_evaluator_launcher.exporters.local import LocalExporter, LocalExporterConfig
from nemo_evaluator_launcher.exporters.mlflow import (
    MLflowExporter,
    MLflowExporterConfig,
)
from nemo_evaluator_launcher.exporters.registry import available_exporters, get_exporter
from nemo_evaluator_launcher.exporters.wandb import WandBExporter, WandBExporterConfig


def create_exporter(name: str, config: dict = None):
    return get_exporter(name)(config)


__all__ = [
    "ExportConfig",
    "GSheetsExporter",
    "GSheetsExporterConfig",
    "LocalExporter",
    "LocalExporterConfig",
    "MLflowExporter",
    "MLflowExporterConfig",
    "WandBExporter",
    "WandBExporterConfig",
    "available_exporters",
    "get_exporter",
]
