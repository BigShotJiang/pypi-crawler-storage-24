# Thingking Machine
A Machine that thingks.
```bash
  echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
    | uvx thingking-machine \
        --provider-api-key=sk-ant-api... \
        --github-token=ghp_... 
```
Or:
```bash
  pip install thingking-machine
```
Then:
```Python
  # Python
  import thingking_machine
```
