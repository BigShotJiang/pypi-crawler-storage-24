from setuptools import setup, find_packages

setup(
    name="titan-sdk",
    version="0.1.0",
    description="Python SDK for the Titan API",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "requests>=2.31.0",
        "websocket-client>=1.7.0",
    ],
)
