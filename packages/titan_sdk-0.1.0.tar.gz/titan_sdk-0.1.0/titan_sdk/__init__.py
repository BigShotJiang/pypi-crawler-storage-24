"""
Titan SDK — Python client for the Titan API.

    from titan_sdk import TitanClient
"""

from .client import TitanClient
from .exceptions import (
    AuthenticationError,
    DeviceNotFoundError,
    NoModeError,
    TenantAccessError,
    TitanSDKError,
    UploadError,
)

__all__ = [
    "TitanClient",
    "TitanSDKError",
    "AuthenticationError",
    "TenantAccessError",
    "UploadError",
    "DeviceNotFoundError",
    "NoModeError",
]

__version__ = "0.1.0"
