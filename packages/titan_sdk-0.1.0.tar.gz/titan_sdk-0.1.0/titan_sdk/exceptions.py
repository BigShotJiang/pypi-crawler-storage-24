class TitanSDKError(Exception):
    """Base exception for all Titan SDK errors."""


class AuthenticationError(TitanSDKError):
    """Raised when the API key is invalid or revoked."""


class TenantAccessError(TitanSDKError):
    """Raised when the API key does not have access to the requested tenant."""


class UploadError(TitanSDKError):
    """Raised when a photo upload fails."""


class DeviceNotFoundError(TitanSDKError):
    """Raised when the target device does not exist."""


class NoModeError(TitanSDKError):
    """Raised when upload() is called without a mode and none has been
    received yet from the WebSocket."""
