"""
Background WebSocket listener.

Connects to /tenants/:uuid/devices/ws?system_id=<system_id> and keeps
the connection alive with automatic reconnect.  Incoming messages update
the shared `current_mode` so TitanClient.upload() always knows which
mode the server has set for this device.

Message shape from server (DevicesMessage):
    {
        "origin_system_id": "...",
        "action_type": "enroll" | "scan" | "refetch" | ...,
        "device_id": 123,           # optional
        "device_local_id": "..."    # optional
    }

The listener only cares about "enroll" and "scan" action types.
Everything else is silently ignored.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Callable, Optional

import websocket  # websocket-client

logger = logging.getLogger(__name__)

# Action types
_ACTION_ENROLL  = "enroll"
_ACTION_SCAN    = "scan"
_ACTION_REFETCH = "refetch"

# Reconnect back-off: wait up to 30 s between attempts
_RECONNECT_INITIAL_WAIT = 1.0
_RECONNECT_MAX_WAIT = 30.0


class WSListener:
    """
    Runs a websocket-client connection in a daemon thread.

    Parameters
    ----------
    ws_url:
        Full WebSocket URL including the system_id query param.
        e.g. ws://localhost:3000/tenants/<uuid>/devices/ws?system_id=<sid>
    api_key:
        Raw API key value — sent as 'Authorization: ApiKey <key>'.
    on_mode_change:
        Called with the new mode string ("enroll" or "scan") whenever
        the server broadcasts a mode-change action for any device.
    on_connect:
        Optional callback invoked each time the WebSocket successfully
        opens (including reconnects).  Takes no arguments.
    on_refetch:
        Optional callback invoked when the server sends a ``"refetch"``
        action.  Called with the ``origin_system_id`` string so the
        recipient can decide whether the message is addressed to it.
    """

    def __init__(
        self,
        ws_url: str,
        api_key: str,
        on_mode_change: Callable[[str, Optional[int]], None],
        on_connect: Optional[Callable[[], None]] = None,
        on_custom_action: Optional[Callable[[str], None]] = None,
        on_refetch: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._ws_url = ws_url
        self._api_key = api_key
        self._on_mode_change = on_mode_change
        self._on_custom_action = on_custom_action
        self._on_connect = on_connect
        self._on_refetch = on_refetch
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the background listener thread (idempotent)."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name="titan-ws-listener",
            daemon=True,
        )
        self._thread.start()
        logger.debug("WebSocket listener thread started")

    def stop(self) -> None:
        """Signal the listener to stop and wait for the thread to exit."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.debug("WebSocket listener thread stopped")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        """Reconnect loop — keeps retrying until stop() is called."""
        wait = _RECONNECT_INITIAL_WAIT
        while not self._stop_event.is_set():
            try:
                self._connect()
                wait = _RECONNECT_INITIAL_WAIT  # reset back-off on clean exit
            except Exception as exc:
                logger.warning("WebSocket error: %s — reconnecting in %.0fs", exc, wait)
            if not self._stop_event.is_set():
                time.sleep(wait)
                wait = min(wait * 2, _RECONNECT_MAX_WAIT)

    def _connect(self) -> None:
        """Open one WebSocket connection and block until it closes."""
        ws = websocket.WebSocketApp(
            self._ws_url,
            header={"Authorization": f"ApiKey {self._api_key}"},
            on_open=self._on_open,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close,
        )
        # run_forever blocks; ping_interval keeps idle connections alive
        ws.run_forever(ping_interval=20, ping_timeout=10)

    # ------------------------------------------------------------------
    # websocket-client callbacks
    # ------------------------------------------------------------------

    def _on_open(self, ws: websocket.WebSocketApp) -> None:
        logger.info("WebSocket connected: %s", self._ws_url)
        if self._on_connect is not None:
            try:
                self._on_connect()
            except Exception:
                logger.exception("on_connect callback raised an exception")

    def _on_message(self, ws: websocket.WebSocketApp, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Received non-JSON WebSocket message: %s", raw)
            return

        action           = msg.get("action_type")
        device_id        = msg.get("device_id")        # may be None
        origin_system_id = msg.get("origin_system_id", "")

        if action in (_ACTION_ENROLL, _ACTION_SCAN):
            logger.debug("Mode change received: action=%s device_id=%s", action, device_id)
            self._on_mode_change(action, device_id)

        elif action == _ACTION_REFETCH and self._on_refetch is not None:
            logger.debug("Refetch received: origin_system_id=%s", origin_system_id)
            try:
                self._on_refetch(origin_system_id)
            except Exception:
                logger.exception("on_refetch callback raised an exception")
        
        else: 
            logger.debug("received custom action: %s", action)
            if self._on_custom_action is not None:
                try:
                    self._on_custom_action(action)
                except Exception:
                    logger.exception("on_custom_action callback raised an exception")

    def _on_error(self, ws: websocket.WebSocketApp, error: Exception) -> None:
        logger.warning("WebSocket error: %s", error)

    def _on_close(
        self,
        ws: websocket.WebSocketApp,
        close_status_code: Optional[int],
        close_msg: Optional[str],
    ) -> None:
        logger.info(
            "WebSocket closed (code=%s msg=%s)",
            close_status_code,
            close_msg,
        )
