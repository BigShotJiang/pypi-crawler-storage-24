class DeviceAction:
    ENROLL = "enroll"
    SCAN = "scan"
    OPEN_DOOR = "open_door"


class DeviceStatus:
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"