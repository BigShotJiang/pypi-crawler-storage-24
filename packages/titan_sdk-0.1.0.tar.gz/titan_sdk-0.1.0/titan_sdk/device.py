"""
Device identity management.

On first run, system_id and device_local_id are generated and written to
~/.titan-sdk/device.json.  The server-assigned numeric device_id is stored
in the same file after the first successful registration so it can be reused
on every subsequent run without re-registering.

JSON schema:
    {
        "system_id":       "<uuid4>",   // stable machine-level ID for WS auth
        "device_local_id": "<uuid4>",   // stable hardware-level local ID sent to server
        "device_name":     "My Device", // display name registered on the server
        "device_type":     "camera_qr", // server-validated type
        "device_id":       42           // numeric ID assigned by the server (null until registered)
    }
"""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

_STORE_PATH = Path.home() / ".titan-sdk" / "device.json"

DEVICE_TYPES = ("camera_qr", "camera_face_recognition", "fingerprint_reader")


@dataclass
class DeviceIdentity:
    system_id: str        # sent on every WS connection and upload
    device_local_id: str  # hardware-level local identifier
    device_name: str      # human-readable name registered on the server
    device_type: str      # one of DEVICE_TYPES
    device_id: Optional[int] = None  # server-assigned numeric ID; None until registered


def load_or_create(device_name: str, device_type: str) -> DeviceIdentity:
    """
    Return the persisted identity.

    If no identity file exists yet, a new one is created with generated IDs.
    ``device_id`` will be ``None`` until :func:`save` is called with the
    server-assigned value after registration.
    """
    if device_type not in DEVICE_TYPES:
        raise ValueError(
            f"Invalid device_type '{device_type}'. Must be one of: {DEVICE_TYPES}"
        )

    if _STORE_PATH.exists():
        return _load()

    return _create(device_name, device_type)


def save(identity: DeviceIdentity) -> None:
    """Persist the identity (called after device_id is filled in by the client)."""
    _STORE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _STORE_PATH.open("w") as f:
        json.dump(asdict(identity), f, indent=2)


def _load() -> DeviceIdentity:
    with _STORE_PATH.open() as f:
        data = json.load(f)
    return DeviceIdentity(
        system_id=data["system_id"],
        device_local_id=data["device_local_id"],
        device_name=data["device_name"],
        device_type=data["device_type"],
        device_id=data.get("device_id"),
    )


def _create(device_name: str, device_type: str) -> DeviceIdentity:
    identity = DeviceIdentity(
        system_id=str(uuid.uuid4()),
        device_local_id=str(uuid.uuid4()),
        device_name=device_name,
        device_type=device_type,
        device_id=None,
    )
    save(identity)
    return identity
