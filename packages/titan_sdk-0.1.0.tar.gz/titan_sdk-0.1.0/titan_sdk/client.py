"""
TitanClient — main entry point for the Titan SDK.

Usage
-----
    from titan_sdk import TitanClient

    # First run: registers the device on the server and stores the
    # server-assigned device_id in ~/.titan-sdk/device.json.
    # Subsequent runs reuse the stored identity and skip registration.
    client = TitanClient(
        tenant_uuid="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
        api_key="your-static-api-key",
        device_name="Front Door Camera",
        device_type="camera_face_recognition",
    )

    # Upload — mode is taken from the latest WebSocket message.
    result = client.upload("photo.jpg")

    # Or force a specific mode explicitly:
    result = client.upload("photo.jpg", mode="enroll")

    client.close()
"""

from __future__ import annotations

from collections.abc import Callable
import logging
import mimetypes
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Literal, Optional

import requests

from titan_sdk.types import DeviceAction, DeviceStatus

from .device import DeviceIdentity, load_or_create, save
from .exceptions import (
    AuthenticationError,
    DeviceNotFoundError,
    NoModeError,
    TenantAccessError,
    UploadError,
)
from .ws_listener import WSListener

logger = logging.getLogger(__name__)

Mode = Literal["enroll", "scan"]

_ENROLL = "enroll"
_SCAN = "scan"


class TitanClient:
    """
    Authenticated SDK client for the Titan API.

    On the very first run the device is registered via
    ``POST /tenants/:uuid/devices/`` and the returned numeric ``device_id``
    is stored locally so that subsequent runs skip registration entirely.

    Parameters
    ----------
    tenant_uuid:
        UUID of the tenant this device belongs to.
    api_key:
        Long-lived SDK key issued via ``POST /tenants/:uuid/api-keys``.
        Sent as ``Authorization: ApiKey <key>`` on every request.
    device_name:
        Human-readable name for this device (e.g. "Front Door Camera").
        Only used on the first run when the device is registered.
    device_type:
        One of ``"camera_qr"``, ``"camera_face_recognition"``,
        ``"fingerprint_reader"``.
        Only used on the first run when the device is registered.
    base_url:
        Root URL of the Titan backend, without trailing slash.
    auto_connect_ws:
        If ``True`` (default) the WebSocket listener starts automatically
        so mode changes from the server are picked up in the background.
    """

    def __init__(
        self,
        tenant_uuid: str,
        api_key: str,
        device_name: str,
        device_type: str,
        base_url: str = "http://powergym.app",
        auto_connect_ws: bool = True,
    ) -> None:
        self.tenant_uuid = tenant_uuid
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")

        # Persistent HTTP session with auth header pre-set
        self._session = requests.Session()
        self._session.headers.update({"Authorization": f"ApiKey {self._api_key}"})

        # Load or generate the stable local identity
        self.identity: DeviceIdentity = load_or_create(device_name, device_type)

        # Register with the server on first run (device_id is None until then)
        if self.identity.device_id is None:
            self._register_device()

        logger.info(
            "TitanClient ready | system_id=%s device_local_id=%s device_id=%s",
            self.identity.system_id,
            self.identity.device_local_id,
            self.identity.device_id,
        )

        # Shared mode state — updated by WS listener, read by upload()
        self._mode_lock = threading.Lock()
        self._current_mode: Optional[str] = DeviceAction.SCAN
        self._status = DeviceStatus.CONNECTED
        self._open_door_callback: Optional[Callable[[], None]] = None

        # Background WebSocket listener
        self._ws: Optional[WSListener] = None
        if auto_connect_ws:
            self.connect_ws()

    # ------------------------------------------------------------------
    # Device registration
    # ------------------------------------------------------------------

    def _register_device(self) -> None:
        """
        Call ``POST /tenants/:uuid/devices/`` to register this device on the
        server and persist the returned numeric ``device_id`` locally.
        Only runs once — subsequent inits skip this entirely.
        """
        url = f"{self._base_url}/tenants/{self.tenant_uuid}/devices/"
        payload = {
            "name":          self.identity.device_name,
            "type":          self.identity.device_type,
            "system_id":     self.identity.system_id,
            "device_local_id": self.identity.device_local_id,
        }
        logger.info("Registering device with server: %s", payload)
        resp = self._session.post(url, json=payload)
        self._raise_for_status(resp)

        data = resp.json()
        self.identity.device_id = data["id"]
        save(self.identity)
        logger.info("Device registered | device_id=%s", self.identity.device_id)

    # ------------------------------------------------------------------
    # WebSocket
    # ------------------------------------------------------------------

    def connect_ws(self) -> None:
        """Start (or restart) the background WebSocket listener."""
        if self._ws:
            self._ws.stop()

        ws_scheme = "wss" if self._base_url.startswith("https") else "ws"
        host = self._base_url.split("://", 1)[-1]
        ws_url = (
            f"{ws_scheme}://{host}"
            f"/tenants/{self.tenant_uuid}/devices/ws"
            f"?system_id={self.identity.system_id}"
        )
        self._ws = WSListener(
            ws_url=ws_url,
            api_key=self._api_key,
            on_mode_change=self._handle_mode_change,
            on_custom_action=self._handle_custom_action,
            on_connect=self._handle_ws_connect,
            on_refetch=self._handle_refetch,
        )
        self._ws.start()

    def _handle_ws_connect(self) -> None:
        """Called by WSListener each time the WebSocket opens (including reconnects)."""
        self._patch_device_status("connected")

    def _patch_device_status(self, status: str) -> None:
        """
        PATCH /tenants/:uuid/devices/:device_id

        Sends ``{"system_id": "<system_id>", "status": "<status>"}`` to
        update the device's connection status on the server.
        Failures are logged but never raised — the SDK keeps running.
        """
        device_id = self.identity.device_id
        if device_id is None:
            logger.warning("Cannot patch device status — device_id not yet assigned")
            return

        url = f"{self._base_url}/tenants/{self.tenant_uuid}/devices/{device_id}"
        payload = {
            "system_id": self.identity.system_id,
            "status": status,
        }
        try:
            resp = self._session.patch(url, json=payload)
            if resp.ok:
                logger.info("Device status updated to '%s' (device_id=%s)", status, device_id)
            else:
                logger.warning(
                    "Failed to update device status: HTTP %s — %s",
                    resp.status_code,
                    resp.text,
                )
        except Exception:
            logger.exception("Exception while patching device status")

    def _handle_mode_change(self, mode: str, device_id: Optional[int]) -> None:
        with self._mode_lock:
            self._current_mode = mode
        logger.info("Mode updated by server: mode=%s device_id=%s", mode, device_id)

    def _handle_custom_action(self, action: str) -> None:
        logger.info("Custom action received from server: action=%s", action)
        if action == DeviceAction.OPEN_DOOR:
            if self._open_door_callback:
                logger.info("Executing open door callback...")
                try:
                    self._open_door_callback()
                except Exception:
                    logger.exception("Open door callback raised an exception")
            else:
                logger.warning("No open door callback set — cannot execute action")


    def _handle_refetch(self, origin_system_id: str) -> None:
        """
        Fired by WSListener on a ``"refetch"`` action.

        Only processes the message when it targets this device's system_id.
        """
        if origin_system_id != self.identity.system_id:
            logger.debug(
                "Ignoring refetch for system_id=%s (ours=%s)",
                origin_system_id,
                self.identity.system_id,
            )
            return
        logger.info("Refetch triggered for this device — fetching latest device state")
        self._fetch_device()

    def _fetch_device(self) -> None:
        """
        ``GET /tenants/:uuid/devices/:device_id``

        Refreshes local device state (name, type, status) from the server.
        Failures are logged and never raised.
        """
        device_id = self.identity.device_id
        if device_id is None:
            logger.warning("Cannot fetch device — device_id not yet assigned")
            return

        url = f"{self._base_url}/tenants/{self.tenant_uuid}/devices/{device_id}"
        try:
            resp = self._session.get(url)
            if not resp.ok:
                logger.warning(
                    "Failed to fetch device (HTTP %s): %s",
                    resp.status_code,
                    resp.text,
                )
                return

            data = resp.json()

            # Refresh mutable identity fields
            if "name" in data:
                self.identity.device_name = data["name"]
            if "type" in data:
                self.identity.device_type = data["type"]
            if "device_local_id" in data:
                self.identity.device_local_id = data["device_local_id"]

            # Refresh local status
            if "status" in data:
                self._status = data["status"]

            logger.info(
                "Device state refreshed | device_id=%s name=%s type=%s status=%s",
                device_id,
                self.identity.device_name,
                self.identity.device_type,
                self._status,
            )

        except Exception:
            logger.exception("Exception while fetching device state")

    @property
    def current_mode(self) -> Optional[str]:
        """The latest mode received from the server (``"enroll"`` or ``"scan"``), or ``None``."""
        with self._mode_lock:
            return self._current_mode

    # ------------------------------------------------------------------
    # Upload abstraction
    # ------------------------------------------------------------------

    def upload(
        self,
        photo: str | Path,
        mode: Optional[Mode] = None,
    ) -> Dict[str, Any]:
        """
        Upload a photo for the registered device in either enroll or scan mode.

        Parameters
        ----------
        photo:
            Path to the image file to upload.
        mode:
            ``"enroll"`` or ``"scan"``.  When omitted the mode last received
            from the WebSocket is used.  Raises ``NoModeError`` if neither
            an explicit mode nor a WS mode is available yet.

        Returns
        -------
        dict
            Parsed JSON response, or ``{"message": "<text>"}`` if the server
            returns plain text.
        """
        resolved_mode = mode or self.current_mode
        if resolved_mode is None:
            raise NoModeError(
                "No mode available. Either pass mode='enroll'/'scan' explicitly "
                "or wait until the WebSocket delivers a mode-change message."
            )

        photo_path = Path(photo)
        if not photo_path.exists():
            raise FileNotFoundError(f"Photo not found: {photo_path}")

        device_id = self.identity.device_id  # always present after __init__
        if resolved_mode == _ENROLL:
            return self._upload_enroll(photo_path, device_id)
        else:
            return self._upload_verify(photo_path, device_id)

    def _upload_enroll(self, photo: Path, device_id: int) -> Dict[str, Any]:
        url = f"{self._base_url}/tenants/{self.tenant_uuid}/devices/{device_id}/enroll"
        return self._post_photo(url, photo, device_id, mode=_ENROLL)

    def _upload_verify(self, photo: Path, device_id: int) -> Dict[str, Any]:
        url = f"{self._base_url}/tenants/{self.tenant_uuid}/devices/{device_id}/verify"
        return self._post_photo(url, photo, device_id, mode=_SCAN)

    def _post_photo(
        self,
        url: str,
        photo: Path,
        device_id: int,
        mode: str,
    ) -> Dict[str, Any]:
        mime = mimetypes.guess_type(photo.name)[0] or "image/jpeg"
        with photo.open("rb") as f:
            files = {"photo": (photo.name, f, mime)}
            data  = {"system_id": self.identity.system_id}
            logger.debug("Uploading | mode=%s device_id=%s url=%s", mode, device_id, url)
            resp = self._session.post(url, files=files, data=data)

        self._raise_for_status(resp, mode=mode, device_id=device_id)

        try:
            return resp.json()
        except ValueError:
            return {"message": resp.text}

    # ------------------------------------------------------------------
    # Fingerprint check-in
    # ------------------------------------------------------------------

    def fingerprint_checkin(self) -> Dict[str, Any]:
        """
        Verify the fingerprint stored on the device and create a check-in.

        Flow
        ----
        1. ``GET /tenants/:uuid/members/fingerprint-verify?device_id=<id>``

           The server reads the verify photo from the device, runs it through
           the fingerprint matcher, and returns the matched ``Member`` object.

        2a. **Match** — ``POST /tenants/:uuid/members/check-ins`` with the
            member's ``access_code`` and this device's ``device_local_id``.
            The server decides the final status (``"checkin"`` or
            ``"invalid-checkin"``) based on subscription, ban, etc.

        2b. **No match** — ``POST /tenants/:uuid/members/check-ins`` *without*
            an ``access_code``.  The server always sets the status to
            ``"invalid-checkin"`` when no access code is present.

        Returns
        -------
        dict
            The ``Check`` object returned by the server::

                {
                    "id": 123,
                    "tenant_id": 456,
                    "member_id": 789,          # null for unmatched
                    "date": "2026-03-14T10:30:00Z",
                    "status": "checkin",       # or "invalid-checkin"
                    "type": "fingerprint_reader",
                    "image_url": "https://...",
                    "device_local_id": "...",
                    "member": { ... }          # null for unmatched
                }
        """
        device_id     = self.identity.device_id
        device_loc_id = self.identity.device_local_id

        # Step 1 — fingerprint verify
        access_code: Optional[str] = None
        verify_url = (
            f"{self._base_url}/tenants/{self.tenant_uuid}"
            f"/members/fingerprint-verify"
            f"?device_id={device_id}"
        )
        verify_resp = self._session.get(verify_url)

        if verify_resp.status_code == 200:
            member      = verify_resp.json()
            access_code = member.get("access_code")
            logger.info(
                "Fingerprint matched | member access_code=%s", access_code
            )
        else:
            logger.info(
                "Fingerprint not matched (HTTP %s) — creating invalid check-in",
                verify_resp.status_code,
            )

        # Step 2 — create check-in
        # Date must be sent without timezone; the server parses it in the
        # tenant's configured timezone.
        now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        payload: Dict[str, Any] = {
            "date":           now,
            "type":           "fingerprint_reader",
            "device_local_id": device_loc_id,
        }
        if access_code is not None:
            payload["access_code"] = access_code

        checkin_url = (
            f"{self._base_url}/tenants/{self.tenant_uuid}/members/check-ins"
        )
        checkin_resp = self._session.post(checkin_url, json=payload)
        self._raise_for_status(checkin_resp)

        checkin = checkin_resp.json()
        logger.info(
            "Check-in created | id=%s status=%s",
            checkin.get("id"),
            checkin.get("status"),
        )
        return checkin

    def set_open_door_callback(self, callback: Callable[[], None]) -> None:
        """Set a callback function to be called when an 'open_door' action is received from the server."""
        self._open_door_callback = callback
    
    # ------------------------------------------------------------------
    # Device helpers
    # ------------------------------------------------------------------

    def list_devices(self) -> list[Dict[str, Any]]:
        """Return all devices registered to this tenant."""
        url = f"{self._base_url}/tenants/{self.tenant_uuid}/devices/"
        resp = self._session.get(url)
        self._raise_for_status(resp)
        return resp.json()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _raise_for_status(
        self,
        resp: requests.Response,
        mode: Optional[str] = None,
        device_id: Optional[int] = None,
    ) -> None:
        if resp.status_code == 401:
            raise AuthenticationError("API key is invalid or has been revoked.")
        if resp.status_code == 403:
            raise TenantAccessError(
                f"API key does not have access to tenant {self.tenant_uuid}."
            )
        if resp.status_code == 404:
            raise DeviceNotFoundError(f"Device {device_id} not found.")
        if not resp.ok:
            raise UploadError(
                f"Upload failed (mode={mode} device_id={device_id}): "
                f"HTTP {resp.status_code} — {resp.text}"
            )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Stop the WebSocket listener and close the HTTP session."""
        if self._ws:
            self._ws.stop()
        self._session.close()
        logger.info("TitanClient closed")

    def __enter__(self) -> "TitanClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()
