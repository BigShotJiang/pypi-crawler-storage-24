# orcus

A Python toolkit for system-level automation and process management.

## Installation

```bash
pip install orcus
```

## Status

Currently in early development. First release coming soon.
