"""Admin test package."""
