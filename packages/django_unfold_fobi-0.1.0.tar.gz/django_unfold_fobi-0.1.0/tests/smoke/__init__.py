"""Smoke test package."""
