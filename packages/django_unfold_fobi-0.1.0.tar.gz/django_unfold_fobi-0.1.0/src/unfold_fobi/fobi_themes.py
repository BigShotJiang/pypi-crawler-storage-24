__all__ = ("UnfoldSimpleTheme",)

from django.utils.translation import gettext_lazy as _
from fobi.base import theme_registry
from fobi.contrib.themes.simple.fobi_themes import SimpleTheme


class UnfoldSimpleTheme(SimpleTheme):
    """
    Unfold theme for fobi — T10 POC simplified.

    Only overrides templates still used by element/handler config views.
    The edit_form_entry_ajax_template is no longer referenced since
    the custom builder edit view was replaced by native admin change view.
    """

    uid = "unfold"
    name = _("Django Unfold admin style")
    html_classes = [
        "unfold",
    ]
    base_edit_template = "override_simple_theme/base_edit.html"
    form_edit_ajax = "override_simple_theme/snippets/form_edit_ajax.html"
    form_edit_snippet_template_name = (
        "override_simple_theme/snippets/form_edit_snippet.html"
    )
    form_properties_snippet_template_name = (
        "override_simple_theme/snippets/form_properties_snippet.html"
    )
    form_snippet_template_name = "override_simple_theme/snippets/form_snippet.html"
    form_wizard_properties_snippet_template_name = (
        "override_simple_theme/snippets/form_wizard_properties_snippet.html"
    )

    media_css = (
        "simple/css/fobi.simple.css",
        "simple/css/fobi.simple.edit.css",
        "unfold_fobi/css/fobi_unfold.css",
    )

    media_js = (
        "js/jquery-1.10.2.min.js",
        "jquery-ui/js/jquery-ui-1.10.4.custom.min.js",
        "js/jquery.slugify.js",
        "js/fobi.core.js",
        "simple/js/fobi.simple.edit.js",
    )


theme_registry.register(UnfoldSimpleTheme, force=True)
