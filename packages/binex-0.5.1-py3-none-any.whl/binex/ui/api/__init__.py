"""Web UI API endpoints."""
