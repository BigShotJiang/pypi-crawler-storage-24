# Project Context

You are working in the project root with full access to all project files including input data, output results, and scripts.

## How to Understand the Data

When asked about the data (what's in it, what columns exist, what the data looks like, etc.):

1. **Read `app_folder/meta_data/input_metadata.txt`** - This contains descriptions of all available files, their columns, data types, and sample values
2. You can also directly read files from `input_folder/` if you need more details

## Answering Questions About Data

When asked a question that requires analyzing the data (e.g., "What are the top 10 states for sales?", "Which customers are most likely to churn?", "Show me the monthly trends"):

**Create and run a Python script** that:
1. Reads the relevant input file(s)
2. Performs the analysis
3. **Saves the result as a CSV to output_folder** (REQUIRED)

**Whenever you create a Python script to answer a question, always ensure that it has a dataframe output saved to the output_folder.** This is how results are displayed in the UI.

## Folder Structure

```
project_folder/           <- You are here
├── CLAUDE.md             <- Instructions for Claude Code
├── AGENTS.md             <- This file
├── input_folder/         <- Source data files
├── output_folder/        <- Scripts save results here
└── app_folder/
    ├── meta_data/        <- Metadata describing available data
    └── scripts/          <- Save Python scripts here
```

## Script Template

**ALWAYS use this template** so scripts work from any directory:

```python
import os
import pandas as pd

# Get absolute paths (works from any directory)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(os.path.dirname(SCRIPT_DIR))
INPUT_FOLDER = os.path.join(PROJECT_DIR, "input_folder")
OUTPUT_FOLDER = os.path.join(PROJECT_DIR, "output_folder")

# Read input files using absolute paths
df = pd.read_csv(os.path.join(INPUT_FOLDER, "your_file.csv"))

# Perform analysis
result = df.groupby("column").sum()

# ALWAYS save result to output folder
result.to_csv(os.path.join(OUTPUT_FOLDER, "result.csv"), index=False)
print(f"Saved result to {os.path.join(OUTPUT_FOLDER, 'result.csv')}")
```

Using absolute paths ensures scripts work regardless of the current working directory.

## Metadata Files

The metadata files in `app_folder/meta_data/` contain:
- File paths for each data file
- File names and row counts
- Column names and data types
- Sample values

Metadata is automatically refreshed when files change.

## Building React + Python Apps

When building a React frontend with a Python backend (Flask/FastAPI), follow this architecture exactly.

### App Folder Structure

```
project_folder/
├── CLAUDE.md
├── AGENTS.md
├── input_folder/
├── output_folder/
├── backend/
│   ├── app.py              <- Flask/FastAPI backend (port 5000)
│   └── requirements.txt    <- Python dependencies
├── frontend/
│   ├── package.json
│   ├── public/
│   └── src/
│       ├── App.js
│       └── index.js
└── app_folder/
    ├── meta_data/
    └── scripts/
        ├── run_app.sh      <- macOS/Linux launcher
        └── run_app.bat     <- Windows launcher
```

### Rules

- **Backend MUST run on port 5000**
- **Frontend MUST run on port 3000**
- Backend must enable CORS for `http://localhost:3000`
- Frontend API calls must target `http://localhost:5000`
- All dependencies go in `requirements.txt` and `package.json`

### Backend Template (backend/app.py)

```python
from flask import Flask, jsonify, request
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app, origins=["http://localhost:3000"])

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT_FOLDER = os.path.join(PROJECT_DIR, "input_folder")
OUTPUT_FOLDER = os.path.join(PROJECT_DIR, "output_folder")

@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})

# Add your API routes here

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
```

### backend/requirements.txt

```
flask
flask-cors
pandas
```

### Frontend Setup

Use Create React App or Vite. In `package.json`, add a proxy for development:

```json
{
  "proxy": "http://localhost:5000"
}
```

## Launcher Scripts (REQUIRED)

When building any app with a frontend/backend, you **MUST** create both launcher scripts in `app_folder/scripts/`. These scripts are how the IDE runs your app.

### CRITICAL rules for launcher scripts:

1. **Always create BOTH** `run_app.sh` and `run_app.bat`
2. **Always include the run command as a comment at the top**
3. **Always kill existing processes on ports 5000 and 3000 before starting**
4. **Always install dependencies before launching**
5. **Always use `call` before `npm` commands in .bat files** (without `call`, the .bat exits after npm runs)
6. **Always use `cd /d` in .bat files** (handles drive letter changes on Windows)
7. **Always use named windows with `start "Name"`** so students can identify them

### Windows Launcher (run_app.bat)

```batch
@echo off
REM Run: app_folder\scripts\run_app.bat

REM Navigate to project root
cd /d "%~dp0\..\.."

echo ========================================
echo  Launching App
echo ========================================

REM Kill any existing processes on ports 5000 and 3000
echo Cleaning up old processes...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5000 ^| findstr LISTENING') do taskkill /PID %%a /F >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do taskkill /PID %%a /F >nul 2>&1

REM Install Python dependencies
echo Installing Python dependencies...
pip install -r backend\requirements.txt -q

REM Install Node dependencies
echo Installing Node dependencies...
cd frontend
call npm install --silent
cd ..

REM Start backend in a new named window
echo Starting backend on http://localhost:5000 ...
start "Backend - Port 5000" cmd /k "cd /d "%cd%" && python backend\app.py"

REM Wait for backend to initialize
timeout /t 3 >nul

REM Start frontend in a new named window
echo Starting frontend on http://localhost:3000 ...
start "Frontend - Port 3000" cmd /k "cd /d "%cd%\frontend" && call npm start"

echo ========================================
echo  App is starting!
echo  Backend:  http://localhost:5000
echo  Frontend: http://localhost:3000
echo ========================================
```

### macOS/Linux Launcher (run_app.sh)

```bash
#!/bin/bash
# Run: bash app_folder/scripts/run_app.sh

# Navigate to project root
cd "$(dirname "$0")/../.."

echo "========================================"
echo " Launching App"
echo "========================================"

# Kill any existing processes on ports 5000 and 3000
echo "Cleaning up old processes..."
lsof -ti:5000 | xargs kill -9 2>/dev/null
lsof -ti:3000 | xargs kill -9 2>/dev/null

# Install Python dependencies
echo "Installing Python dependencies..."
pip install -r backend/requirements.txt -q

# Install Node dependencies
echo "Installing Node dependencies..."
cd frontend
npm install --silent
cd ..

# Start backend in background
echo "Starting backend on http://localhost:5000 ..."
python backend/app.py &
BACKEND_PID=$!

# Wait for backend to initialize
sleep 3

# Start frontend (this opens the browser automatically)
echo "Starting frontend on http://localhost:3000 ..."
cd frontend
npm start

# When frontend is stopped (Ctrl+C), also kill backend
kill $BACKEND_PID 2>/dev/null
```

### Non-React Apps (Simple Python Scripts)

For simple Python scripts or Streamlit apps, the launcher is simpler:

**run_app.bat:**
```batch
@echo off
REM Run: app_folder\scripts\run_app.bat
cd /d "%~dp0\..\.."
pip install -r requirements.txt -q
python app_folder\scripts\your_script.py
```

**run_app.sh:**
```bash
#!/bin/bash
# Run: bash app_folder/scripts/run_app.sh
cd "$(dirname "$0")/../.."
pip install -r requirements.txt -q
python app_folder/scripts/your_script.py
```
