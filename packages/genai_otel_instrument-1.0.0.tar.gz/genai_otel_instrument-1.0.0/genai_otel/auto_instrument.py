"""Module for setting up OpenTelemetry auto-instrumentation for GenAI applications."""

# isort: skip_file

import logging
import sys

from opentelemetry import metrics, trace
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
    OTLPMetricExporter as GrpcOTLPMetricExporter,
)
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
    OTLPSpanExporter as GrpcOTLPSpanExporter,
)
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import ConsoleMetricExporter, PeriodicExportingMetricReader
from opentelemetry.sdk.metrics.view import View
from opentelemetry.sdk.metrics._internal.aggregation import ExplicitBucketHistogramAggregation
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

from .config import OTelConfig
from .cost_calculator import CostCalculator
from .cost_enrichment_processor import CostEnrichmentSpanProcessor
from .cost_enriching_exporter import CostEnrichingSpanExporter
from .evaluation.config import (
    BiasConfig,
    HallucinationConfig,
    PIIConfig,
    PIIEntityType,
    PIIMode,
    PromptInjectionConfig,
    RestrictedTopicsConfig,
    ToxicityConfig,
)
from .evaluation_enriching_exporter import EvaluationEnrichingSpanExporter
from .gpu_metrics import GPUMetricsCollector
from .litellm_span_enrichment_processor import LiteLLMSpanEnrichmentProcessor
from .mcp_instrumentors import MCPInstrumentorManager
from .mcp_span_enrichment_processor import MCPSpanEnrichmentProcessor
from .server_metrics import initialize_server_metrics
from .smolagents_span_enrichment_processor import SmolagentsSpanEnrichmentProcessor
from .metrics import (
    _GEN_AI_CLIENT_OPERATION_DURATION_BUCKETS,
    _GEN_AI_CLIENT_TOKEN_USAGE_BUCKETS,
    _GEN_AI_SERVER_TBT,
    _GEN_AI_SERVER_TFTT,
    _MCP_CLIENT_OPERATION_DURATION_BUCKETS,
    _MCP_PAYLOAD_SIZE_BUCKETS,
)

from .semconv import SemanticConvention as SC

# Import instrumentors - fix the import path based on your actual structure
try:
    from .instrumentors import (
        AnthropicInstrumentor,
        AnyscaleInstrumentor,
        AutoGenAgentChatInstrumentor,
        AutoGenInstrumentor,
        AWSBedrockInstrumentor,
        AzureOpenAIInstrumentor,
        BedrockAgentsInstrumentor,
        CohereInstrumentor,
        CrewAIInstrumentor,
        DSPyInstrumentor,
        GoogleADKInstrumentor,
        GoogleAIInstrumentor,
        GroqInstrumentor,
        GuardrailsAIInstrumentor,
        HaystackInstrumentor,
        HuggingFaceInstrumentor,
        HyperbolicInstrumentor,
        InstructorInstrumentor,
        LangChainInstrumentor,
        LangGraphInstrumentor,
        LlamaIndexInstrumentor,
        MistralAIInstrumentor,
        OllamaInstrumentor,
        OpenAIInstrumentor,
        OpenAIAgentsInstrumentor,
        OpenRouterInstrumentor,
        PydanticAIInstrumentor,
        ReplicateInstrumentor,
        SambaNovaInstrumentor,
        SarvamAIInstrumentor,
        TogetherAIInstrumentor,
        VertexAIInstrumentor,
    )
except ImportError:
    # Fallback for testing or if instrumentors are in different structure
    from genai_otel.instrumentors import (
        AnthropicInstrumentor,
        AnyscaleInstrumentor,
        AutoGenAgentChatInstrumentor,
        AutoGenInstrumentor,
        AWSBedrockInstrumentor,
        AzureOpenAIInstrumentor,
        BedrockAgentsInstrumentor,
        CohereInstrumentor,
        CrewAIInstrumentor,
        DSPyInstrumentor,
        GoogleADKInstrumentor,
        GoogleAIInstrumentor,
        GroqInstrumentor,
        GuardrailsAIInstrumentor,
        HaystackInstrumentor,
        HuggingFaceInstrumentor,
        HyperbolicInstrumentor,
        InstructorInstrumentor,
        LangChainInstrumentor,
        LangGraphInstrumentor,
        LlamaIndexInstrumentor,
        MistralAIInstrumentor,
        OllamaInstrumentor,
        OpenAIInstrumentor,
        OpenAIAgentsInstrumentor,
        OpenRouterInstrumentor,
        PydanticAIInstrumentor,
        ReplicateInstrumentor,
        SambaNovaInstrumentor,
        SarvamAIInstrumentor,
        TogetherAIInstrumentor,
        VertexAIInstrumentor,
    )

logger = logging.getLogger(__name__)

# OpenInference instrumentors are loaded lazily to avoid importing litellm (~10s)
# at module import time. They are resolved in setup_auto_instrumentation() instead.
OPENINFERENCE_AVAILABLE = None  # Tri-state: None=not checked, True/False=result

# Re-entrancy guard to prevent double-instrumentation
_INSTRUMENTATION_INITIALIZED = False
# Track active providers/collectors for uninstrument()
_active_tracer_provider = None
_active_meter_provider = None
_active_gpu_collector = None


def _check_openinference():
    """Lazily check and import OpenInference instrumentors (requires Python >= 3.10)."""
    global OPENINFERENCE_AVAILABLE
    if OPENINFERENCE_AVAILABLE is not None:
        return OPENINFERENCE_AVAILABLE
    try:
        from openinference.instrumentation.litellm import LiteLLMInstrumentor  # noqa: E402
        from openinference.instrumentation.mcp import MCPInstrumentor  # noqa: E402
        from openinference.instrumentation.smolagents import (  # noqa: E402
            SmolagentsInstrumentor,
        )

        INSTRUMENTORS.update(
            {
                "smolagents": SmolagentsInstrumentor,
                "litellm": LiteLLMInstrumentor,
                "mcp": MCPInstrumentor,
            }
        )
        OPENINFERENCE_AVAILABLE = True
    except ImportError:
        OPENINFERENCE_AVAILABLE = False
    return OPENINFERENCE_AVAILABLE


# Defines the available instrumentors. This is now at the module level for easier mocking in tests.
INSTRUMENTORS = {
    "openai": OpenAIInstrumentor,
    "agents": OpenAIAgentsInstrumentor,  # OpenAI Agents SDK
    "openai_agents": OpenAIAgentsInstrumentor,  # OpenAI Agents SDK (alias)
    "openrouter": OpenRouterInstrumentor,  # OpenRouter unified API aggregator
    "anthropic": AnthropicInstrumentor,
    "google.generativeai": GoogleAIInstrumentor,
    "google_adk": GoogleADKInstrumentor,  # Google Agent Development Kit
    "boto3": AWSBedrockInstrumentor,
    "azure.ai.openai": AzureOpenAIInstrumentor,
    "autogen": AutoGenInstrumentor,  # AutoGen multi-agent framework (legacy)
    "autogen_agentchat": AutoGenAgentChatInstrumentor,  # AutoGen AgentChat v0.4+
    "bedrock_agents": BedrockAgentsInstrumentor,  # AWS Bedrock Agents
    "cohere": CohereInstrumentor,
    "crewai": CrewAIInstrumentor,  # CrewAI multi-agent framework
    "dspy": DSPyInstrumentor,  # DSPy declarative LM programming framework
    "mistralai": MistralAIInstrumentor,
    "together": TogetherAIInstrumentor,
    "groq": GroqInstrumentor,
    "guardrails": GuardrailsAIInstrumentor,  # Guardrails AI validation framework
    "haystack": HaystackInstrumentor,  # Haystack NLP pipeline framework
    "instructor": InstructorInstrumentor,  # Instructor structured output extraction
    "ollama": OllamaInstrumentor,
    "vertexai": VertexAIInstrumentor,
    "replicate": ReplicateInstrumentor,
    "anyscale": AnyscaleInstrumentor,
    "sambanova": SambaNovaInstrumentor,
    "sarvamai": SarvamAIInstrumentor,  # Sarvam AI sovereign Indian AI platform
    "hyperbolic": HyperbolicInstrumentor,
    "langchain": LangChainInstrumentor,
    "langgraph": LangGraphInstrumentor,  # LangGraph stateful workflow framework
    "llama_index": LlamaIndexInstrumentor,
    "pydantic_ai": PydanticAIInstrumentor,  # Pydantic AI type-safe agent framework
    "transformers": HuggingFaceInstrumentor,
}

# OpenInference instrumentors (smolagents, litellm, mcp) are added to INSTRUMENTORS
# lazily via _check_openinference() called in setup_auto_instrumentation()


def _setup_meter_provider(resource, metric_reader):
    """Create and configure the MeterProvider with histogram Views.

    Args:
        resource: OpenTelemetry Resource for the meter provider.
        metric_reader: The metric reader (OTLP or Console).
    """
    views = [
        View(
            instrument_name=SC.GEN_AI_CLIENT_OPERATION_DURATION,
            aggregation=ExplicitBucketHistogramAggregation(
                boundaries=_GEN_AI_CLIENT_OPERATION_DURATION_BUCKETS
            ),
        ),
        View(
            instrument_name="mcp.client.operation.duration",
            aggregation=ExplicitBucketHistogramAggregation(
                boundaries=_MCP_CLIENT_OPERATION_DURATION_BUCKETS
            ),
        ),
        View(
            instrument_name="mcp.request.size",
            aggregation=ExplicitBucketHistogramAggregation(boundaries=_MCP_PAYLOAD_SIZE_BUCKETS),
        ),
        View(
            instrument_name="mcp.response.size",
            aggregation=ExplicitBucketHistogramAggregation(boundaries=_MCP_PAYLOAD_SIZE_BUCKETS),
        ),
        View(
            instrument_name=SC.GEN_AI_SERVER_TTFT,
            aggregation=ExplicitBucketHistogramAggregation(boundaries=_GEN_AI_SERVER_TFTT),
        ),
        View(
            instrument_name=SC.GEN_AI_SERVER_TBT,
            aggregation=ExplicitBucketHistogramAggregation(boundaries=_GEN_AI_SERVER_TBT),
        ),
        View(
            instrument_name="gen_ai.client.token.usage.prompt",
            aggregation=ExplicitBucketHistogramAggregation(
                boundaries=_GEN_AI_CLIENT_TOKEN_USAGE_BUCKETS
            ),
        ),
        View(
            instrument_name="gen_ai.client.token.usage.completion",
            aggregation=ExplicitBucketHistogramAggregation(
                boundaries=_GEN_AI_CLIENT_TOKEN_USAGE_BUCKETS
            ),
        ),
    ]
    meter_provider = MeterProvider(resource=resource, metric_readers=[metric_reader], views=views)
    metrics.set_meter_provider(meter_provider)
    return meter_provider


def setup_auto_instrumentation(config: OTelConfig):
    """
    Set up OpenTelemetry with auto-instrumentation for LLM frameworks and MCP tools.

    Args:
        config: OTelConfig instance with configuration parameters.
    """
    global _INSTRUMENTATION_INITIALIZED
    if _INSTRUMENTATION_INITIALIZED:
        logger.warning("Auto-instrumentation already initialized, skipping re-initialization")
        return
    logger.info("Starting auto-instrumentation setup...")

    # Lazily check and register OpenInference instrumentors (smolagents, litellm, mcp)
    # This defers the heavy litellm import (~10s) to instrumentation time, not package import.
    _check_openinference()

    # Configure OpenTelemetry SDK (TracerProvider, MeterProvider, etc.)
    import os

    service_instance_id = os.getenv("OTEL_SERVICE_INSTANCE_ID")
    environment = os.getenv("OTEL_ENVIRONMENT")
    from .__version__ import __version__ as _pkg_version

    resource_attributes = {
        "service.name": config.service_name,
        "telemetry.auto.name": "genai-otel-instrument",
        "telemetry.auto.version": _pkg_version,
    }
    if service_instance_id:
        resource_attributes["service.instance.id"] = service_instance_id
    if environment:
        resource_attributes["environment"] = environment
    resource = Resource.create(resource_attributes)

    # Configure Tracing
    global _active_tracer_provider, _active_meter_provider

    # Apply sampling rate if configured (< 1.0 means probabilistic sampling)
    sampler = None
    if config.sampling_rate < 1.0:
        from opentelemetry.sdk.trace.sampling import TraceIdRatioBased

        sampler = TraceIdRatioBased(config.sampling_rate)
        logger.info("Trace sampling rate set to %s", config.sampling_rate)

    tracer_provider = TracerProvider(resource=resource, sampler=sampler)
    _active_tracer_provider = tracer_provider
    trace.set_tracer_provider(tracer_provider)
    from opentelemetry.propagate import set_global_textmap
    from opentelemetry.trace.propagation.tracecontext import (
        TraceContextTextMapPropagator,
    )

    set_global_textmap(TraceContextTextMapPropagator())

    # Add cost enrichment processor for custom instrumentors (OpenAI, Ollama, etc.)
    # These instrumentors set cost attributes directly, so processor is mainly for logging
    # Also attempts to enrich OpenInference spans (smolagents, litellm, mcp), though
    # the processor can't modify ReadableSpan - the exporter below handles that
    cost_calculator = None
    if config.enable_cost_tracking:
        try:
            cost_calculator = CostCalculator()
            cost_processor = CostEnrichmentSpanProcessor(cost_calculator)
            tracer_provider.add_span_processor(cost_processor)
            logger.info("Cost enrichment processor added")
        except Exception as e:
            logger.warning("Failed to add cost enrichment processor: %s", e, exc_info=True)

    # Add LiteLLM span enrichment processor for evaluation support
    # This enriches LiteLLM spans (created by OpenInference) with standardized attributes
    # enabling evaluation metrics (PII, toxicity, bias, etc.) for LiteLLM calls
    if OPENINFERENCE_AVAILABLE and "litellm" in config.enabled_instrumentors:
        try:
            litellm_enrichment_processor = LiteLLMSpanEnrichmentProcessor()
            tracer_provider.add_span_processor(litellm_enrichment_processor)
            logger.info("LiteLLM span enrichment processor added for evaluation support")
        except Exception as e:
            logger.warning("Failed to add LiteLLM span enrichment processor: %s", e, exc_info=True)

    # Add Smolagents span enrichment processor for evaluation support
    # This enriches Smolagents spans (created by OpenInference) with standardized attributes
    if OPENINFERENCE_AVAILABLE and "smolagents" in config.enabled_instrumentors:
        try:
            smolagents_enrichment_processor = SmolagentsSpanEnrichmentProcessor()
            tracer_provider.add_span_processor(smolagents_enrichment_processor)
            logger.info("Smolagents span enrichment processor added for evaluation support")
        except Exception as e:
            logger.warning(
                "Failed to add Smolagents span enrichment processor: %s", e, exc_info=True
            )

    # Add MCP span enrichment processor for evaluation support
    # This enriches MCP tool spans (created by OpenInference) with standardized attributes
    if OPENINFERENCE_AVAILABLE and "mcp" in config.enabled_instrumentors:
        try:
            mcp_enrichment_processor = MCPSpanEnrichmentProcessor()
            tracer_provider.add_span_processor(mcp_enrichment_processor)
            logger.info("MCP span enrichment processor added for evaluation support")
        except Exception as e:
            logger.warning("Failed to add MCP span enrichment processor: %s", e, exc_info=True)

    # Add evaluation and safety span processor (v0.2.0)
    # Store the evaluation processor so we can wrap it in the exporter chain
    evaluation_processor = None
    if any(
        [
            config.enable_pii_detection,
            config.enable_toxicity_detection,
            config.enable_bias_detection,
            config.enable_prompt_injection_detection,
            config.enable_restricted_topics,
            config.enable_hallucination_detection,
        ]
    ):
        try:
            # Build PII config from OTelConfig
            pii_config = None
            if config.enable_pii_detection:
                pii_config = PIIConfig(
                    enabled=True,
                    mode=PIIMode(config.pii_mode),
                    threshold=config.pii_threshold,
                    gdpr_mode=config.pii_gdpr_mode,
                    hipaa_mode=config.pii_hipaa_mode,
                    pci_dss_mode=config.pii_pci_dss_mode,
                )

            # Build Toxicity config
            toxicity_config = None
            if config.enable_toxicity_detection:
                toxicity_config = ToxicityConfig(
                    enabled=True,
                    threshold=config.toxicity_threshold,
                    use_perspective_api=config.toxicity_use_perspective_api,
                    perspective_api_key=config.toxicity_perspective_api_key,
                    block_on_detection=config.toxicity_block_on_detection,
                )

            # Build Bias config
            bias_config = None
            if config.enable_bias_detection:
                bias_config = BiasConfig(
                    enabled=True,
                    threshold=config.bias_threshold,
                    block_on_detection=config.bias_block_on_detection,
                )

            # Build Prompt Injection config
            prompt_injection_config = None
            if config.enable_prompt_injection_detection:
                prompt_injection_config = PromptInjectionConfig(
                    enabled=True,
                    threshold=config.prompt_injection_threshold,
                    block_on_detection=config.prompt_injection_block_on_detection,
                )

            # Build Restricted Topics config
            restricted_topics_config = None
            if config.enable_restricted_topics:
                restricted_topics_config = RestrictedTopicsConfig(
                    enabled=True,
                    threshold=config.restricted_topics_threshold,
                    block_on_detection=config.restricted_topics_block_on_detection,
                )

            # Build Hallucination config
            hallucination_config = None
            if config.enable_hallucination_detection:
                hallucination_config = HallucinationConfig(
                    enabled=True,
                    threshold=config.hallucination_threshold,
                )

            # Create and add evaluation processor (lazy import to avoid loading
            # heavy ML dependencies like spacy/torch at package import time)
            from .evaluation.span_processor import EvaluationSpanProcessor

            evaluation_processor = EvaluationSpanProcessor(
                pii_config=pii_config,
                toxicity_config=toxicity_config,
                bias_config=bias_config,
                prompt_injection_config=prompt_injection_config,
                restricted_topics_config=restricted_topics_config,
                hallucination_config=hallucination_config,
            )
            tracer_provider.add_span_processor(evaluation_processor)
            logger.info("Evaluation and safety span processor added")
        except Exception as e:
            logger.warning("Failed to add evaluation span processor: %s", e, exc_info=True)

    logger.debug("OTelConfig endpoint: %s", config.endpoint)
    if config.endpoint:
        # Use timeout from config (already validated as int)
        timeout = config.exporter_timeout

        # CRITICAL FIX: Set endpoint in environment variable so exporters can append correct paths
        # The exporters only call _append_trace_path() when reading from env vars
        from urllib.parse import urlparse

        # Set the base endpoint in environment variable
        os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = config.endpoint

        parsed = urlparse(config.endpoint)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        # Build list of URLs to exclude from instrumentation
        excluded_urls = [
            base_url,
            config.endpoint,
            f"{base_url}/v1/traces",
            f"{base_url}/v1/metrics",
            config.endpoint.rstrip("/") + "/v1/traces",
            config.endpoint.rstrip("/") + "/v1/metrics",
        ]

        # Add to environment variable (comma-separated)
        existing = os.environ.get("OTEL_PYTHON_REQUESTS_EXCLUDED_URLS", "")
        if existing:
            excluded_urls.append(existing)
        os.environ["OTEL_PYTHON_REQUESTS_EXCLUDED_URLS"] = ",".join(excluded_urls)
        logger.info("Excluded OTLP endpoints from instrumentation: %s", base_url)

        # Set timeout in environment variable as integer string (OTLP exporters expect int)
        os.environ["OTEL_EXPORTER_OTLP_TIMEOUT"] = str(timeout)

        # Detect OTLP protocol (grpc or http)
        # Priority: OTEL_EXPORTER_OTLP_PROTOCOL env var > port-based detection > default (http)
        otlp_protocol = os.getenv("OTEL_EXPORTER_OTLP_PROTOCOL", "").lower()
        if not otlp_protocol:
            # Detect from port: 4317 = gRPC, 4318 = HTTP
            parsed_endpoint = urlparse(base_url)
            if parsed_endpoint.port == 4317:
                otlp_protocol = "grpc"
            else:
                otlp_protocol = "http"

        # Create exporters based on protocol
        if otlp_protocol == "grpc":
            span_exporter = GrpcOTLPSpanExporter(
                headers=config.headers,
            )
            metric_exporter = GrpcOTLPMetricExporter(
                headers=config.headers,
            )
            logger.info("Using OTLP gRPC protocol (endpoint: %s)", base_url)
        else:
            # Default to HTTP
            span_exporter = OTLPSpanExporter(
                headers=config.headers,
            )
            metric_exporter = OTLPMetricExporter(
                headers=config.headers,
            )
            logger.info("Using OTLP HTTP protocol (endpoint: %s)", base_url)

        # Build the exporter chain: span_exporter -> cost enrichment -> evaluation enrichment
        # Each wrapper enriches ReadableSpan objects before passing to the next exporter
        final_exporter = span_exporter

        # Wrap with cost enrichment if cost tracking is enabled
        if cost_calculator:
            final_exporter = CostEnrichingSpanExporter(final_exporter, cost_calculator)
            logger.info("Cost-enriching span exporter enabled for OTLP")

        # Wrap with evaluation enrichment if evaluation features are enabled
        if evaluation_processor:
            final_exporter = EvaluationEnrichingSpanExporter(final_exporter, evaluation_processor)
            logger.info("Evaluation-enriching span exporter enabled for OTLP")

        tracer_provider.add_span_processor(BatchSpanProcessor(final_exporter))
        logger.info(
            "OpenTelemetry tracing configured with OTLP endpoint: %s", span_exporter._endpoint
        )

        # Configure Metrics with Views for histogram buckets
        metric_reader = PeriodicExportingMetricReader(exporter=metric_exporter)
        _active_meter_provider = _setup_meter_provider(resource, metric_reader)
        logger.info(
            "OpenTelemetry metrics configured with OTLP endpoint: %s", metric_exporter._endpoint
        )
    else:
        # Configure Console Exporters if no OTLP endpoint is set
        span_exporter = ConsoleSpanExporter()
        # Build the exporter chain for console output
        final_exporter = span_exporter

        if cost_calculator:
            final_exporter = CostEnrichingSpanExporter(final_exporter, cost_calculator)
            logger.info("Cost-enriching span exporter enabled for console")

        if evaluation_processor:
            final_exporter = EvaluationEnrichingSpanExporter(final_exporter, evaluation_processor)
            logger.info("Evaluation-enriching span exporter enabled for console")

        tracer_provider.add_span_processor(BatchSpanProcessor(final_exporter))
        logger.info("No OTLP endpoint configured, traces will be exported to console.")

        metric_exporter = ConsoleMetricExporter()
        metric_reader = PeriodicExportingMetricReader(exporter=metric_exporter)
        _active_meter_provider = _setup_meter_provider(resource, metric_reader)
        logger.info("No OTLP endpoint configured, metrics will be exported to console.")

    # OpenInference instrumentors that use different API (no config parameter)
    # Only include if OpenInference is available (Python >= 3.10)
    OPENINFERENCE_INSTRUMENTORS = (
        {"smolagents", "mcp", "litellm"} if OPENINFERENCE_AVAILABLE else set()
    )

    # Auto-instrument LLM libraries based on the configuration
    for name in config.enabled_instrumentors:
        if name in INSTRUMENTORS:
            try:
                instrumentor_class = INSTRUMENTORS[name]
                instrumentor = instrumentor_class()

                # OpenInference instrumentors don't take config parameter
                if name in OPENINFERENCE_INSTRUMENTORS:
                    instrumentor.instrument()
                else:
                    instrumentor.instrument(config=config)

                logger.info("%s instrumentation enabled", name)
            except Exception as e:
                logger.error("Failed to instrument %s: %s", name, e, exc_info=True)
                if config.fail_on_error:
                    raise
        else:
            logger.warning("Unknown instrumentor '%s' requested.", name)

    # Auto-instrument MCP tools (databases, APIs, etc.)
    # NOTE: OTLP endpoints are excluded via OTEL_PYTHON_REQUESTS_EXCLUDED_URLS set above
    if config.enable_mcp_instrumentation:
        try:
            mcp_manager = MCPInstrumentorManager(config)
            mcp_manager.instrument_all(config.fail_on_error)
            logger.info("MCP tools instrumentation enabled and set up.")
        except Exception as e:
            logger.error("Failed to set up MCP tools instrumentation: %s", e, exc_info=True)
            if config.fail_on_error:
                raise

    # Start GPU metrics collection if enabled
    if config.enable_gpu_metrics:
        try:
            meter_provider = metrics.get_meter_provider()
            global _active_gpu_collector
            _active_gpu_collector = GPUMetricsCollector(
                meter_provider.get_meter("genai.gpu"),
                config,
                interval=config.gpu_collection_interval,
            )
            _active_gpu_collector.start()
            logger.info(
                "GPU metrics collection started (interval: %ss).", config.gpu_collection_interval
            )
        except Exception as e:
            logger.error("Failed to start GPU metrics collection: %s", e, exc_info=True)
            if config.fail_on_error:
                raise

    # Initialize server metrics collector (KV cache, request queue, etc.)
    try:
        meter_provider = metrics.get_meter_provider()
        initialize_server_metrics(meter_provider.get_meter("genai.server"))
        logger.info("Server metrics collector initialized (KV cache, request queue)")
    except Exception as e:
        logger.error("Failed to initialize server metrics: %s", e, exc_info=True)
        if config.fail_on_error:
            raise

    _INSTRUMENTATION_INITIALIZED = True
    logger.info("Auto-instrumentation setup complete")

    # Report anonymous usage telemetry (opt-in only, see telemetry.py)
    try:
        from .telemetry import report_usage

        report_usage(config)
    except Exception:
        pass  # Never let telemetry affect instrumentation


def instrument(**kwargs):
    """
    Convenience wrapper for setup_auto_instrumentation that accepts kwargs.

    Set up OpenTelemetry with auto-instrumentation for LLM frameworks and MCP tools.

    Args:
        **kwargs: Keyword arguments to configure OTelConfig. These will override
                  environment variables.

    Example:
        >>> instrument(service_name="my-app", endpoint="http://localhost:4318")
    """
    # Load configuration from environment variables or use provided kwargs
    config = OTelConfig(**kwargs)

    # Call the main setup function
    setup_auto_instrumentation(config)


def uninstrument():
    """Shut down OpenTelemetry providers and allow re-instrumentation.

    Stops GPU metrics collection, flushes and shuts down the TracerProvider
    and MeterProvider, and resets the initialization guard so that
    ``instrument()`` can be called again.
    """
    global _INSTRUMENTATION_INITIALIZED, _active_tracer_provider
    global _active_meter_provider, _active_gpu_collector

    if not _INSTRUMENTATION_INITIALIZED:
        logger.debug("Instrumentation not initialized, nothing to uninstrument")
        return

    # Stop GPU collector
    if _active_gpu_collector is not None:
        try:
            _active_gpu_collector.stop()
            logger.info("GPU metrics collector stopped")
        except Exception as e:
            logger.debug("Error stopping GPU collector: %s", e)
        _active_gpu_collector = None

    # Shut down TracerProvider (flushes pending spans)
    if _active_tracer_provider is not None:
        try:
            _active_tracer_provider.shutdown()
            logger.info("TracerProvider shut down")
        except Exception as e:
            logger.debug("Error shutting down TracerProvider: %s", e)
        _active_tracer_provider = None

    # Shut down MeterProvider (flushes pending metrics)
    if _active_meter_provider is not None:
        try:
            _active_meter_provider.shutdown()
            logger.info("MeterProvider shut down")
        except Exception as e:
            logger.debug("Error shutting down MeterProvider: %s", e)
        _active_meter_provider = None

    _INSTRUMENTATION_INITIALIZED = False
    logger.info("Instrumentation teardown complete")
