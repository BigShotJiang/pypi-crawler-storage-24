#!/usr/bin/env python3
"""
Shared path validation utilities for artifact path security.

Phase 5A.2b: Hardening for path validation
- Rejects absolute paths
- Rejects parent directory escapes (..)
- Rejects nested quant_current_scope duplicates
- Verifies containment under repo root
"""

from pathlib import Path
import os


def validate_artifact_path(path: str, repo_root: Path) -> tuple[bool, str]:
    """
    Validate artifact path for security and correctness.

    Args:
        path: Artifact path string (should be repo-root-relative)
        repo_root: Repository root directory

    Returns:
        (is_valid, error_message): Tuple of validation result and error description
    """
    # Reject empty paths
    if not path or not path.strip():
        return False, "Empty path"

    path = path.strip()

    # Reject absolute paths (Unix-style or Windows drive letters)
    if path.startswith('/') or (len(path) >= 2 and path[1] == ':'):
        return False, f"Absolute path not allowed: {path}"

    # Reject parent directory escapes
    if '..' in path.split(os.sep):
        return False, f"Parent directory escape (..) not allowed: {path}"

    # Reject single repo-root-prefix (e.g., "quant_current_scope/docs/...")
    parts = path.replace('\\', '/').split('/')
    if parts[0] == repo_root.resolve().name:
        return False, f"Path must not start with repo root name '{repo_root.resolve().name}'"

    # Reject nested quant_current_scope duplicates
    # Example: "quant_current_scope/quant_current_scope/docs/..."
    path_parts = path.replace('\\', '/').split('/')
    if path_parts.count('quant_current_scope') > 1:
        return False, f"Nested 'quant_current_scope' duplicate detected: {path}"

    # Resolve path and verify containment under repo root
    try:
        repo_root_resolved = repo_root.resolve()
        artifact_path = (repo_root / path).resolve()

        # Check if artifact_path is under repo_root
        try:
            artifact_path.relative_to(repo_root_resolved)
        except ValueError:
            return False, f"Path escapes repository root: {path}"

    except Exception as e:
        return False, f"Path resolution error: {path} ({str(e)})"

    return True, ""
