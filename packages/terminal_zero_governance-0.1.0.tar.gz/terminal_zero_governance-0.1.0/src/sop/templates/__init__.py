"""SOP kernel templates package."""
