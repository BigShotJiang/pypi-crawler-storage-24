# django-vcache

Django cache backend for Valkey/Redis with a Rust I/O driver (PyO3 + maturin). Used by GlitchTip.

## Production stack (MUST match in all benchmarks)

- **ASGI server**: granian (never uvicorn)
- **Event loop**: uvloop (always `--loop uvloop`)
- **Network latency**: 2ms RTT via `tc netem` (never benchmark at 0ms — it hides real bugs)
- **Python**: 3.14
- **OS**: Debian (not Alpine/musl)

These are non-negotiable. Shipped regressions were caused by benchmarking
without production settings (missing uvloop, missing latency, missing libvalkey
C parser). If a benchmark script doesn't use all of the above, the results are
meaningless. libvalkey is already a dev dependency so it's always installed.

## Build and test

Tests require Docker (volume mount means the .so must be built in-container):

```sh
docker compose build && docker compose up -d valkey
docker compose run --rm app bash -c \
  "pip install maturin && rm -f target/wheels/*.whl && \
   maturin build --release --interpreter python && \
   pip install --force-reinstall --no-deps target/wheels/*.whl && \
   python manage.py test"
```

### Docker build gotchas

1. **Volume mount shadows the .so**: The `.:/app` volume mount replaces any pip-installed
   `.so` in `/app/django_vcache/` with whatever is on the host. If a stale
   `_driver.cpython-314-*.so` exists on the host, the container uses that instead of the
   freshly built one. **Fix**: delete the host `.so` first, then build with `cargo build
   --release` and `cp target/release/lib_driver.so django_vcache/_driver.cpython-314-x86_64-linux-gnu.so`.
   Or use the wheel approach but copy the installed `.so` back to the mounted dir.

2. **`maturin develop` picks up wrong Python**: The host `.venv/` (Python 3.13) is also
   mounted at `/app/.venv`. `maturin develop` finds it first and builds a cp313 wheel,
   which fails to install on the container's cp314. **Fix**: use `maturin build` (not
   `develop`) or `cargo build --release` + manual copy.

3. **Permission issues**: Docker runs as root but the mounted files are owned by the host
   user. Root can't `chmod` or overwrite host-owned files. **Fix**: delete the target file
   from the host first (outside Docker), then copy inside Docker creates a new root-owned
   file.

4. **Multiple .whl files**: Old wheels accumulate in `target/wheels/`. A glob like
   `target/wheels/*.whl` may pick the wrong one (e.g., cp313 instead of cp314).
   **Fix**: always `rm -f target/wheels/*.whl` before `maturin build`, or use a specific
   glob: `target/wheels/django_vcache-*cp314*.whl`.

5. **Fastest Docker rebuild cycle**: Delete host `.so`, `cargo build --release` in Docker,
   copy the output:
   ```sh
   rm -f django_vcache/_driver.cpython-314-*.so
   docker compose run --rm app bash -c \
     "cargo build --release && \
      cp target/release/lib_driver.so django_vcache/_driver.cpython-314-x86_64-linux-gnu.so && \
      python manage.py test"
   ```

## Benchmarking

**`benchmark.py` is the single source of truth.** Every change must pass all levels.

```sh
# Build and run full benchmark suite (after fixing .so per above)
docker compose run --rm app bash -c \
  "python benchmark.py --level all redis://valkey:6379/1"

# Levels:
#   driver  — raw I/O throughput (set/get ops/s)
#   cache   — Django cache backend (serialization + I/O)
#   mixed   — CRITICAL: blocking ops + fast ops concurrency (reproduces staging bug)
#   asgi    — full ASGI stack with granian + uvloop
#   all     — everything
```

### The mixed workload test is mandatory

Level 4 (`--level mixed`) simulates an embedded task worker (BLMOVE/BLMPOP with timeouts)
running alongside fast cache ops on the same asyncio event loop. This is the exact production
scenario in GlitchTip and any app using django-vtasks.

**Acceptance criteria:** Fast cache ops must complete in ~1ms regardless of concurrent blocking
ops. If they're blocked until BLMOVE/BLMPOP timeouts expire, that's the staging regression that
made all v2.x versions unusable.

Fixed in v2.0.7 via dual-connection architecture (separate TCP for blocking ops) and
busy-yield threshold (`polls <= 5`) in async_bridge.rs. vcache now achieves p99=1.1ms
with 2 blockers, matching valkey-py.

## Linting

CI enforces ruff format + ruff check. Always verify:

```sh
uvx ruff format --check .
uvx ruff check .
```

Fix with: `uvx ruff format . && uvx ruff check --fix .`

## Architecture

- `src/` — Rust I/O driver (PyO3). Raw bytes only, no serialization.
  - `async_bridge.rs` — Deferred-callback awaitable bridge between tokio and asyncio.
  - `client.rs` — `RustValkeyDriver` PyO3 class, all Redis commands.
  - `connection.rs` — ConnectionManager setup (standalone, cluster, sentinel).
- `django_vcache/backend.py` — Python cache backend. Serialization (ormsgpack + zstd).
- `sample/` — Test Django app with benchmark endpoints.

## Key invariants

- Integers stored as raw strings for native Redis INCRBY — never GET+SET for incr/decr.
- Tokio worker threads must NEVER block on the Python GIL. Use `spawn_blocking` for any code that calls `Python::try_attach` or `Python::with_gil`.
- The oneshot channel fast path (`try_recv` in `__next__`) must remain zero-overhead.
- **Multiple concurrent RustAwaitables must not block each other.** A fast cache GET must complete in ~1ms even when BLMOVE/BLMPOP awaitables with multi-second timeouts are active on the same event loop. Fixed via dual-connection (blocking ops on separate TCP) + busy-yield (`polls <= 5`).
- **Blocking ops (BLMOVE, BLMPOP) must use a separate connection** with `response_timeout = None`. The redis crate defaults to 500ms response timeout which breaks blocking commands.
