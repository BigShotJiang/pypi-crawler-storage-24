"""
Phase 3: Fork-Safety Tests

Verify that the Rust tokio runtime and Redis connections are safe across
os.fork(), as used by prefork WSGI servers (gunicorn sync workers).

Key invariants:
  1. Connections created before fork are NOT shared with children
  2. The tokio runtime in the child is a fresh instance (not the parent's)
  3. Children can create new connections and execute commands independently
"""

import os
import subprocess
import sys
import textwrap
import unittest

VALKEY_URL = os.environ.get("VALKEY_URL", "redis://valkey:6379/1")

_is_cluster = os.environ.get("VALKEY_CLUSTER_MODE") == "true"
_is_sentinel = VALKEY_URL.startswith("sentinel://")
_skip_reason = (
    "Fork tests use RustValkeyDriver.connect() directly, "
    "which only handles redis:// URLs."
)


@unittest.skipIf(_is_cluster or _is_sentinel, _skip_reason)
class ForkSafetyTests(unittest.TestCase):
    """Test that fork() doesn't corrupt connections or crash."""

    def test_child_can_use_driver_after_fork(self):
        """A forked child process can create a new driver and use it.

        This tests the core fork-safety guarantee: the tokio runtime
        detects the PID change and creates a fresh runtime in the child.
        """
        script = textwrap.dedent(f"""\
            import os
            import sys
            from django_vcache._driver import RustValkeyDriver

            # Create a driver in the parent
            parent_drv = RustValkeyDriver.connect("{VALKEY_URL}")
            parent_drv.set_sync("fork:parent", b"from_parent", 60)

            pid = os.fork()
            if pid == 0:
                # Child process
                try:
                    # Create a NEW driver in the child (should get fresh runtime)
                    child_drv = RustValkeyDriver.connect("{VALKEY_URL}")
                    child_drv.set_sync("fork:child", b"from_child", 60)
                    result = child_drv.get_sync("fork:child")
                    if result == b"from_child":
                        print("CHILD_OK", flush=True)
                    else:
                        print(f"CHILD_FAIL: got {{result}}", flush=True)
                except Exception as e:
                    print(f"CHILD_ERROR: {{e}}", flush=True)
                os._exit(0)
            else:
                # Parent waits for child
                _, status = os.waitpid(pid, 0)
                exit_code = os.waitstatus_to_exitcode(status)
                if exit_code != 0:
                    print(f"CHILD_EXIT_CODE: {{exit_code}}", flush=True)
                    sys.exit(1)

                # Verify parent's driver still works
                result = parent_drv.get_sync("fork:parent")
                if result == b"from_parent":
                    print("PARENT_OK", flush=True)
                else:
                    print(f"PARENT_FAIL: got {{result}}", flush=True)
                    sys.exit(1)
        """)

        proc = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            timeout=10,
        )
        stdout = proc.stdout.strip()
        self.assertIn("CHILD_OK", stdout, f"Child failed:\n{stdout}\n{proc.stderr}")
        self.assertIn("PARENT_OK", stdout, f"Parent failed:\n{stdout}\n{proc.stderr}")
        self.assertEqual(
            proc.returncode, 0, f"Exit code {proc.returncode}\n{proc.stderr}"
        )

    def test_django_cache_works_after_fork(self):
        """Django cache in a forked child creates fresh connections.

        PID tracking in _get_or_create_driver() detects the fork and creates
        a new driver/connection, preventing FD sharing with the parent.
        """
        script = textwrap.dedent(f"""\
            import os
            import sys

            os.environ["DJANGO_SETTINGS_MODULE"] = "sample.settings"
            os.environ["VALKEY_URL"] = "{VALKEY_URL}"
            import django
            django.setup()

            from django.core.cache import cache

            # Warm up the cache in the parent (creates a driver + tokio runtime)
            cache.set("fork:warm", "parent_value", 60)
            result = cache.get("fork:warm")
            assert result == "parent_value", f"Parent warmup failed: {{result}}"

            pid = os.fork()
            if pid == 0:
                # Child: cache operations must work with fresh connections
                try:
                    cache.set("fork:child_val", "from_child", 60)
                    result = cache.get("fork:child_val")
                    if result == "from_child":
                        print("CHILD_CACHE_OK", flush=True)
                    else:
                        print(f"CHILD_CACHE_FAIL: got {{result}}", flush=True)

                    # Verify isolation: parent's value is readable
                    parent_val = cache.get("fork:warm")
                    if parent_val == "parent_value":
                        print("CHILD_READ_PARENT_OK", flush=True)
                    else:
                        print(f"CHILD_READ_PARENT_FAIL: {{parent_val}}", flush=True)
                except Exception as e:
                    print(f"CHILD_ERROR: {{e}}", flush=True)
                os._exit(0)
            else:
                _, status = os.waitpid(pid, 0)
                exit_code = os.waitstatus_to_exitcode(status)
                if exit_code != 0:
                    print(f"CHILD_EXIT: {{exit_code}}", flush=True)
                    sys.exit(1)

                # Parent still works after child exits
                result = cache.get("fork:warm")
                if result == "parent_value":
                    print("PARENT_OK", flush=True)
                else:
                    print(f"PARENT_FAIL: {{result}}", flush=True)
                    sys.exit(1)
        """)

        proc = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            timeout=15,
        )
        stdout = proc.stdout.strip()
        self.assertIn(
            "CHILD_CACHE_OK", stdout, f"Child cache failed:\n{stdout}\n{proc.stderr}"
        )
        self.assertIn(
            "CHILD_READ_PARENT_OK",
            stdout,
            f"Child read failed:\n{stdout}\n{proc.stderr}",
        )
        self.assertIn("PARENT_OK", stdout, f"Parent failed:\n{stdout}\n{proc.stderr}")
        self.assertEqual(
            proc.returncode, 0, f"Exit code {proc.returncode}\n{proc.stderr}"
        )

    def test_multiple_forks(self):
        """Multiple sequential forks each get independent connections."""
        script = textwrap.dedent(f"""\
            import os
            import sys
            from django_vcache._driver import RustValkeyDriver

            results = []
            for i in range(3):
                pid = os.fork()
                if pid == 0:
                    try:
                        drv = RustValkeyDriver.connect("{VALKEY_URL}")
                        drv.set_sync(f"fork:multi_{{i}}", f"child_{{i}}".encode(), 60)
                        result = drv.get_sync(f"fork:multi_{{i}}")
                        if result == f"child_{{i}}".encode():
                            print(f"FORK_{{i}}_OK", flush=True)
                        else:
                            print(f"FORK_{{i}}_FAIL: {{result}}", flush=True)
                    except Exception as e:
                        print(f"FORK_{{i}}_ERROR: {{e}}", flush=True)
                    os._exit(0)
                else:
                    _, status = os.waitpid(pid, 0)

            print("ALL_DONE", flush=True)
        """)

        proc = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            timeout=15,
        )
        stdout = proc.stdout.strip()
        for i in range(3):
            self.assertIn(
                f"FORK_{i}_OK", stdout, f"Fork {i} failed:\n{stdout}\n{proc.stderr}"
            )
        self.assertEqual(
            proc.returncode, 0, f"Exit code {proc.returncode}\n{proc.stderr}"
        )
