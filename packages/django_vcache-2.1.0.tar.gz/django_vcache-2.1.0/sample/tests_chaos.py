"""
Phase 1: Chaos Tests — Cancellation & Deadlocks

Tests that the Rust tokio runtime correctly handles Python asyncio.CancelledError
across the FFI boundary. Verifies that:
  1. Cancelling a RustAwaitable in callback mode fires done-callbacks
  2. Cancelling during busy-yield mode raises CancelledError on next poll
  3. asyncio.run() cleanup cancels all tasks including blocked BLMOVE
  4. An ASGI worker process exits cleanly on SIGTERM within 2s
"""

import asyncio
import os
import signal
import subprocess
import sys
import textwrap
import time
import unittest

VALKEY_URL = os.environ.get("VALKEY_URL", "redis://valkey:6379/1")

_is_cluster = os.environ.get("VALKEY_CLUSTER_MODE") == "true"
_is_sentinel = VALKEY_URL.startswith("sentinel://")
_skip_reason = (
    "Chaos tests use RustValkeyDriver.connect() directly and BLMOVE, "
    "which are not compatible with cluster/sentinel topologies."
)


@unittest.skipIf(_is_cluster or _is_sentinel, _skip_reason)
class CancellationTests(unittest.TestCase):
    """Test RustAwaitable cancellation at the asyncio level."""

    def _run(self, coro):
        """Run an async test via asyncio.run()."""
        return asyncio.run(coro)

    def test_cancel_blocking_op_callback_mode(self):
        """Cancelling a BLMOVE (infinite timeout) in callback mode must not hang.

        This is the core bug: without firing done-callbacks in cancel(),
        the Task suspends forever waiting for callbacks that never fire.
        """
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.delete_sync("chaos:cb_src")
            drv.delete_sync("chaos:cb_dst")

            async def do_blmove():
                return await drv.blmove(
                    "chaos:cb_src", "chaos:cb_dst", "RIGHT", "LEFT", 0
                )

            task = asyncio.create_task(do_blmove())
            # Wait long enough to enter callback mode (polls > 5)
            await asyncio.sleep(0.3)

            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task

        self._run(go())

    def test_cancel_during_busy_yield(self):
        """Cancel during busy-yield phase raises CancelledError."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.delete_sync("chaos:by_src")
            drv.delete_sync("chaos:by_dst")

            async def do_blmove():
                return await drv.blmove(
                    "chaos:by_src", "chaos:by_dst", "RIGHT", "LEFT", 0
                )

            task = asyncio.create_task(do_blmove())
            # Single yield — task is still in busy-yield phase
            await asyncio.sleep(0)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task

        self._run(go())

    def test_cancel_resolved_noop(self):
        """cancel() on an already-resolved awaitable returns False."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.set_sync("chaos:resolved", b"value", 60)

            async def do_get():
                return await drv.get("chaos:resolved")

            task = asyncio.create_task(do_get())
            result = await task
            self.assertEqual(result, b"value")
            self.assertFalse(task.cancel())

        self._run(go())

    def test_multiple_cancellations_safe(self):
        """Calling cancel() multiple times doesn't crash or double-fire."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.delete_sync("chaos:mc_src")
            drv.delete_sync("chaos:mc_dst")

            async def do_blmove():
                return await drv.blmove(
                    "chaos:mc_src", "chaos:mc_dst", "RIGHT", "LEFT", 0
                )

            task = asyncio.create_task(do_blmove())
            await asyncio.sleep(0.3)

            self.assertTrue(task.cancel())
            with self.assertRaises(asyncio.CancelledError):
                await task
            self.assertFalse(task.cancel())

        self._run(go())

    def test_cancel_fast_op_race(self):
        """Cancel a fast op (GET) — should raise CancelledError or complete."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.set_sync("chaos:fast", b"data", 60)

            async def do_get():
                return await drv.get("chaos:fast")

            task = asyncio.create_task(do_get())
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass  # Expected — cancel won the race
            # No hang, no crash — that's the requirement

        self._run(go())

    def test_concurrent_cancel_and_fast_ops(self):
        """Cancelling a blocking op doesn't affect concurrent fast ops."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.delete_sync("chaos:conc_src")
            drv.delete_sync("chaos:conc_dst")
            drv.set_sync("chaos:conc_val", b"hello", 60)

            async def do_blmove():
                return await drv.blmove(
                    "chaos:conc_src", "chaos:conc_dst", "RIGHT", "LEFT", 0
                )

            blocking_task = asyncio.create_task(do_blmove())
            await asyncio.sleep(0.3)

            # Fast ops complete while blocking task is pending
            for _ in range(10):
                result = await drv.get("chaos:conc_val")
                self.assertEqual(result, b"hello")

            blocking_task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await blocking_task

        self._run(go())

    def test_asyncio_run_cleanup_cancels_blmove(self):
        """asyncio.run() cleanup must cancel a blocked BLMOVE without hanging.

        When asyncio.run() finishes, it calls _cancel_all_tasks() which
        calls cancel() on every pending task. Our cancel() must fire callbacks
        so the task can be cleaned up. Without this, asyncio.run() hangs.
        """
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            drv.delete_sync("chaos:run_src")
            drv.delete_sync("chaos:run_dst")

            async def do_blmove():
                return await drv.blmove(
                    "chaos:run_src", "chaos:run_dst", "RIGHT", "LEFT", 0
                )

            # Start BLMOVE but DON'T await it — let asyncio.run() clean it up
            asyncio.create_task(do_blmove())
            await asyncio.sleep(0.3)  # Let it enter callback mode
            # Return without cancelling — asyncio.run() must handle cleanup

        # This must complete without hanging
        self._run(go())


@unittest.skipIf(_is_cluster or _is_sentinel, _skip_reason)
class SIGTERMTests(unittest.TestCase):
    """Test that processes blocked on BLMOVE exit cleanly on SIGTERM."""

    def test_sigterm_asyncio_worker(self):
        """An asyncio worker blocked on BLMOVE must exit on SIGTERM within 2s.

        Simulates a background task worker (like django-vtasks) that polls
        BLMOVE in a loop. On SIGTERM, asyncio.run() cancels all tasks.
        Our cancel() must fire callbacks so the task gets CancelledError.
        """
        worker_script = textwrap.dedent("""\
            import asyncio
            import os
            import signal
            import sys

            async def main():
                from django_vcache._driver import RustValkeyDriver
                url = os.environ.get("VALKEY_URL", "redis://valkey:6379/1")
                drv = RustValkeyDriver.connect(url)
                drv.delete_sync("chaos:sigterm_src")
                drv.delete_sync("chaos:sigterm_dst")

                shutdown = asyncio.Event()
                loop = asyncio.get_running_loop()
                loop.add_signal_handler(signal.SIGTERM, shutdown.set)

                async def blmove_worker():
                    await drv.blmove(
                        "chaos:sigterm_src", "chaos:sigterm_dst",
                        "RIGHT", "LEFT", 0
                    )

                task = asyncio.create_task(blmove_worker())
                print("READY", flush=True)

                # Wait for SIGTERM
                await shutdown.wait()

                # Cancel the blocked BLMOVE task
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    print("CANCELLED", flush=True)

            asyncio.run(main())
            print("EXIT", flush=True)
        """)

        proc = subprocess.Popen(
            [sys.executable, "-c", worker_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=os.environ.copy(),
        )

        try:
            # Wait for READY
            line = proc.stdout.readline()
            self.assertIn(b"READY", line, f"Worker didn't start: {line}")

            # Let it enter callback mode
            time.sleep(0.5)
            self.assertIsNone(proc.poll(), "Worker died before SIGTERM")

            # Send SIGTERM
            proc.send_signal(signal.SIGTERM)

            # Must exit within 2 seconds
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                stderr = proc.stderr.read().decode(errors="replace")
                self.fail(
                    f"Worker did not exit within 2s after SIGTERM.\n"
                    f"Cancellation is not propagating.\nStderr:\n{stderr[-2000:]}"
                )

            stdout = proc.stdout.read().decode(errors="replace")
            self.assertIn("CANCELLED", stdout, "BLMOVE was not cancelled")
            self.assertIn("EXIT", stdout, "Worker did not exit cleanly")
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()

    def test_sigterm_granian_exits(self):
        """A granian ASGI worker must exit on SIGTERM within 5s.

        Tests the full production stack: granian + uvloop + Django + BLMOVE.
        granian's shutdown timeout may add latency, so we allow 5s (still
        well under docker's 10s SIGKILL default).
        """
        proc = subprocess.Popen(
            [
                "granian",
                "--interface",
                "asgi",
                "--host",
                "127.0.0.1",
                "--port",
                "8765",
                "--workers",
                "1",
                "--loop",
                "uvloop",
                "sample.asgi:application",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env={**os.environ, "DJANGO_SETTINGS_MODULE": "sample.settings"},
        )

        try:
            # Wait for granian to start
            time.sleep(2)
            self.assertIsNone(proc.poll(), "granian failed to start")

            # Fire a request to start a background BLMOVE via the vtasks endpoint
            import threading
            import urllib.request

            def fire_request(url):
                try:
                    urllib.request.urlopen(url, timeout=5)
                except Exception:
                    pass

            # Start the vtasks background worker (BLMOVE in a loop)
            t = threading.Thread(
                target=fire_request,
                args=("http://127.0.0.1:8765/bench/vtasks-start/",),
                daemon=True,
            )
            t.start()
            t.join(timeout=3)

            # Let the background BLMOVE enter callback mode
            time.sleep(1)
            self.assertIsNone(proc.poll(), "granian died before SIGTERM")

            # Send SIGTERM
            proc.send_signal(signal.SIGTERM)

            # granian should exit within 5s (includes its own shutdown grace period)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                stderr = proc.stderr.read().decode(errors="replace")
                self.fail(
                    f"granian did not exit within 5s after SIGTERM.\n"
                    f"A blocked BLMOVE is preventing shutdown.\n"
                    f"Stderr:\n{stderr[-2000:]}"
                )

            # granian typically exits with 0 or -SIGTERM
            self.assertIn(
                proc.returncode,
                (0, -signal.SIGTERM),
                f"Unexpected exit code: {proc.returncode}",
            )
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
