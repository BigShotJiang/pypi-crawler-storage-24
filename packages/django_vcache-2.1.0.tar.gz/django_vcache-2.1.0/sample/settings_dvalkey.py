"""django-valkey AsyncValkeyCache with libvalkey, msgpack, and zstd."""

import os

from sample.settings import *  # noqa: F401, F403

CACHES = {
    "default": {
        "BACKEND": "django_valkey.async_cache.cache.AsyncValkeyCache",
        "LOCATION": os.environ.get("VALKEY_URL", "redis://valkey:6379/1"),
        "OPTIONS": {
            "SERIALIZER": "django_valkey.serializers.msgpack.MSGPackSerializer",
            "COMPRESSOR": "django_valkey.compressors.zstd.ZStdCompressor",
        },
    },
}
