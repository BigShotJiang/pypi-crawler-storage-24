"""
Phase 2: Exception Handling Regression Tests

Regression wall to prevent native Rust panics (PanicException) from leaking
into the Python runtime. Every Redis error must map to either:
  - ConnectionError: transient/network errors (swallowed by IGNORE_EXCEPTIONS)
  - RuntimeError: data/application errors (always propagated)

If a pyo3_runtime.PanicException or raw Rust string leaks, the test fails.
"""

import asyncio
import os
import unittest

VALKEY_URL = os.environ.get("VALKEY_URL", "redis://valkey:6379/1")

_is_cluster = os.environ.get("VALKEY_CLUSTER_MODE") == "true"
_is_sentinel = VALKEY_URL.startswith("sentinel://")
_skip_reason = (
    "Exception tests use RustValkeyDriver.connect() directly, "
    "which only handles redis:// URLs."
)


def _run(coro):
    return asyncio.run(coro)


@unittest.skipIf(_is_cluster or _is_sentinel, _skip_reason)
class ConnectionErrorTests(unittest.TestCase):
    """Verify network failures raise ConnectionError, never PanicException."""

    def test_connect_refused(self):
        """Connection to a closed port raises ConnectionError at connect time."""
        from django_vcache._driver import RustValkeyDriver

        with self.assertRaises(ConnectionError):
            RustValkeyDriver.connect("redis://127.0.0.1:1/0")

    def test_tls_to_plain_raises_connection_error(self):
        """rediss:// URL to a non-TLS server raises ConnectionError, not PanicException.

        NOTE: connect() may timeout (~30s) on TLS handshake failure. The existing
        TLSConnectionTests in tests.py already cover this with @override_settings.
        This test verifies the raw driver behavior.
        """
        from django_vcache._driver import RustValkeyDriver

        tls_url = VALKEY_URL.replace("redis://", "rediss://", 1)
        with self.assertRaises(ConnectionError):
            RustValkeyDriver.connect(tls_url)


@unittest.skipIf(_is_cluster or _is_sentinel, _skip_reason)
class ServerErrorTests(unittest.TestCase):
    """Verify data/application errors raise RuntimeError, never PanicException."""

    def test_incr_on_non_integer_sync(self):
        """INCRBY on a non-integer value raises an exception (not PanicException)."""
        from django_vcache._driver import RustValkeyDriver

        drv = RustValkeyDriver.connect(VALKEY_URL)
        drv.set_sync("exc:str_val", b"not_a_number", 60)
        with self.assertRaises((RuntimeError, ConnectionError)):
            drv.incr_by_sync("exc:str_val", 1)

    def test_incr_on_non_integer_async(self):
        """Async INCRBY on a non-integer value raises an exception."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            await drv.set("exc:str_val2", b"not_a_number", 60)
            with self.assertRaises((RuntimeError, ConnectionError)):
                await drv.incr_by("exc:str_val2", 1)

        _run(go())

    def test_wrong_type_lpush_on_string_key(self):
        """LPUSH on a key holding a string raises an exception (not PanicException)."""
        from django_vcache._driver import RustValkeyDriver

        drv = RustValkeyDriver.connect(VALKEY_URL)
        drv.set_sync("exc:string_key", b"value", 60)
        with self.assertRaises((RuntimeError, ConnectionError)):
            drv.lpush_sync("exc:string_key", [b"item"])

    def test_wrong_type_lpush_async(self):
        """Async LPUSH on a string key raises an exception (not PanicException)."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            await drv.set("exc:string_key2", b"value", 60)
            with self.assertRaises((RuntimeError, ConnectionError)):
                await drv.lpush("exc:string_key2", [b"item"])

        _run(go())

    def test_eval_bad_script_sync(self):
        """Invalid Lua script raises RuntimeError, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        drv = RustValkeyDriver.connect(VALKEY_URL)
        with self.assertRaises((RuntimeError, ConnectionError)):
            drv.eval_sync("this is not valid lua!!!", [], [])

    def test_eval_bad_script_async(self):
        """Async invalid Lua script raises RuntimeError, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            with self.assertRaises((RuntimeError, ConnectionError)):
                await drv.eval("this is not valid lua!!!", [], [])

        _run(go())


@unittest.skipIf(_is_cluster or _is_sentinel, _skip_reason)
class NoPanicExceptionTests(unittest.TestCase):
    """Meta-tests: verify PanicException is NOT raised for any error scenario.

    These tests explicitly catch all exceptions and assert none is PanicException.
    This is the ultimate regression wall.
    """

    def _assert_no_panic(self, fn, msg=""):
        """Call fn, assert that if it raises, it's not PanicException."""
        try:
            fn()
        except Exception as e:
            exc_type = type(e).__name__
            self.assertNotEqual(
                exc_type,
                "PanicException",
                f"PanicException leaked to Python: {e} {msg}",
            )
            module = getattr(type(e), "__module__", "") or ""
            self.assertNotIn(
                "pyo3_runtime",
                module,
                f"PyO3 runtime exception leaked: {type(e)} {msg}",
            )

    async def _assert_no_panic_async(self, coro, msg=""):
        """Await coro, assert that if it raises, it's not PanicException."""
        try:
            await coro
        except Exception as e:
            exc_type = type(e).__name__
            self.assertNotEqual(
                exc_type,
                "PanicException",
                f"PanicException leaked to Python: {e} {msg}",
            )
            module = getattr(type(e), "__module__", "") or ""
            self.assertNotIn(
                "pyo3_runtime",
                module,
                f"PyO3 runtime exception leaked: {type(e)} {msg}",
            )

    def test_no_panic_on_connect_refused(self):
        """connect() to a closed port raises ConnectionError, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        self._assert_no_panic(
            lambda: RustValkeyDriver.connect("redis://127.0.0.1:1/0"),
            "connect refused",
        )

    def test_no_panic_on_tls_mismatch(self):
        """rediss:// to plaintext: ConnectionError, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        tls_url = VALKEY_URL.replace("redis://", "rediss://", 1)
        self._assert_no_panic(
            lambda: RustValkeyDriver.connect(tls_url),
            "tls mismatch",
        )

    def test_no_panic_on_wrong_type(self):
        """WRONGTYPE errors raise RuntimeError, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        drv = RustValkeyDriver.connect(VALKEY_URL)
        drv.set_sync("exc:nopanic_str", b"value", 60)
        self._assert_no_panic(
            lambda: drv.lpush_sync("exc:nopanic_str", [b"x"]),
            "lpush on string",
        )

    def test_no_panic_on_wrong_type_async(self):
        """Async WRONGTYPE errors raise RuntimeError, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            await drv.set("exc:nopanic_str2", b"value", 60)
            await self._assert_no_panic_async(
                drv.lpush("exc:nopanic_str2", [b"x"]),
                "async lpush on string",
            )

        _run(go())

    def test_no_panic_on_incr_non_integer(self):
        """INCRBY of non-integer raises an error, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        drv = RustValkeyDriver.connect(VALKEY_URL)
        drv.set_sync("exc:nopanic_incr", b"hello", 60)
        self._assert_no_panic(
            lambda: drv.incr_by_sync("exc:nopanic_incr", 1),
            "incr on string",
        )

    def test_no_panic_on_eval_bad_script(self):
        """Invalid Lua script raises an error, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        drv = RustValkeyDriver.connect(VALKEY_URL)
        self._assert_no_panic(
            lambda: drv.eval_sync("this is not valid lua!!!", [], []),
            "bad lua script",
        )

    def test_no_panic_on_eval_bad_script_async(self):
        """Async invalid Lua script raises an error, not PanicException."""
        from django_vcache._driver import RustValkeyDriver

        async def go():
            drv = RustValkeyDriver.connect(VALKEY_URL)
            await self._assert_no_panic_async(
                drv.eval("this is not valid lua!!!", [], []),
                "async bad lua script",
            )

        _run(go())
