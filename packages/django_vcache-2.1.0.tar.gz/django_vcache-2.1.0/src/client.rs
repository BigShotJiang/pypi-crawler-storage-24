use pyo3::prelude::*;
use pyo3::types::PyBytes;

use crate::async_bridge::{get_runtime, RawResult, RustAwaitable};
use crate::connection::{
    connect_cluster, connect_sentinel, connect_standard, ClientCacheOpts, ValkeyConn,
};

/// Thin async Valkey driver. Python handles serialization and compression.
#[pyclass]
pub struct RustValkeyDriver {
    connection: ValkeyConn,
}

// Async: create RustAwaitable, spawn tokio task, send result via oneshot.
// The tokio task never touches the GIL — zero Python interaction.
// If the result arrives before __next__, it's consumed directly (fast path).
// If not, __next__ spawns a lightweight watcher for callback-based wakeup.
macro_rules! async_op {
    ($self:expr, $py:expr, $conn:ident, $body:expr) => {{
        let (tx, rx) = tokio::sync::oneshot::channel();
        let awaitable = RustAwaitable::new(rx);
        let mut $conn = $self.connection.clone();
        get_runtime().spawn(async move {
            let result: RawResult = async { $body }.await;
            let _ = tx.send(result);
        });
        Ok(awaitable.into_pyobject($py)?.into_any().unbind())
    }};
}

// Sync: release GIL, block on tokio runtime
macro_rules! sync_op {
    ($py:expr, $self:expr, $conn:ident, $body:expr) => {{
        let mut $conn = $self.connection.clone();
        $py.detach(|| get_runtime().block_on(async { $body }))
    }};
}

// =========================================================================
// Error classification — separate connection errors from data errors
// =========================================================================

/// Classify a Redis error as connection/transient (→ PyConnectionError,
/// swallowed by IGNORE_EXCEPTIONS) or data/server error (→ PyRuntimeError,
/// always propagated). Mirrors SentinelConn::is_failover_error() for
/// consistency with sentinel retry logic.
fn classify(e: redis::RedisError) -> RawResult {
    if is_connection_error(&e) {
        RawResult::Error(e.to_string())
    } else {
        RawResult::ServerError(e.to_string())
    }
}

/// Convert a Redis error to the appropriate Python exception for sync methods.
pub fn to_py_err(e: redis::RedisError) -> PyErr {
    if is_connection_error(&e) {
        pyo3::exceptions::PyConnectionError::new_err(e.to_string())
    } else {
        pyo3::exceptions::PyRuntimeError::new_err(e.to_string())
    }
}

fn is_connection_error(e: &redis::RedisError) -> bool {
    matches!(
        e.kind(),
        redis::ErrorKind::Io
            | redis::ErrorKind::Server(redis::ServerErrorKind::BusyLoading)
            | redis::ErrorKind::Server(redis::ServerErrorKind::TryAgain)
            | redis::ErrorKind::Server(redis::ServerErrorKind::ReadOnly)
    ) || e.is_connection_dropped()
        || e.is_connection_refusal()
        || e.is_timeout()
}

// Helpers to convert redis Result to RawResult
fn r_opt_bytes(r: Result<Option<Vec<u8>>, redis::RedisError>) -> RawResult {
    match r {
        Ok(v) => RawResult::OptBytes(v),
        Err(e) => classify(e),
    }
}

fn r_bool(r: Result<bool, redis::RedisError>) -> RawResult {
    match r {
        Ok(v) => RawResult::Bool(v),
        Err(e) => classify(e),
    }
}

fn r_int(r: Result<i64, redis::RedisError>) -> RawResult {
    match r {
        Ok(v) => RawResult::Int(v),
        Err(e) => classify(e),
    }
}

fn r_unit(r: Result<(), redis::RedisError>) -> RawResult {
    match r {
        Ok(()) => RawResult::Bool(true),
        Err(e) => classify(e),
    }
}

/// Convert redis::Value to RawResult for eval/evalsha.
/// Handles the common return types from Lua scripts.
fn r_value(r: Result<redis::Value, redis::RedisError>) -> RawResult {
    match r {
        Err(e) => classify(e),
        Ok(v) => match v {
            redis::Value::Int(i) => RawResult::Int(i),
            redis::Value::Nil => RawResult::OptBytes(None),
            redis::Value::BulkString(b) => RawResult::OptBytes(Some(b)),
            redis::Value::SimpleString(s) => RawResult::OptBytes(Some(s.into_bytes())),
            redis::Value::Boolean(b) => RawResult::Bool(b),
            redis::Value::Okay => RawResult::Bool(true),
            // For arrays, return as list of bytes (each element coerced)
            redis::Value::Array(items) => {
                let bytes_list: Vec<Option<Vec<u8>>> = items
                    .into_iter()
                    .map(|item| match item {
                        redis::Value::BulkString(b) => Some(b),
                        redis::Value::SimpleString(s) => Some(s.into_bytes()),
                        redis::Value::Int(i) => Some(i.to_string().into_bytes()),
                        redis::Value::Nil => None,
                        _ => None,
                    })
                    .collect();
                RawResult::OptBytesList(bytes_list)
            }
            _ => RawResult::OptBytes(None),
        },
    }
}

fn make_cache_opts(max_size: Option<usize>, ttl_secs: Option<u64>) -> Option<ClientCacheOpts> {
    if max_size.is_some() || ttl_secs.is_some() {
        Some(ClientCacheOpts {
            max_size: max_size.unwrap_or(10_000),
            ttl_secs: ttl_secs.unwrap_or(300),
        })
    } else {
        None
    }
}

#[pymethods]
impl RustValkeyDriver {
    // =================================================================
    // Connection constructors
    // =================================================================

    #[staticmethod]
    #[pyo3(signature = (url, cache_max_size=None, cache_ttl_secs=None))]
    fn connect(
        py: Python<'_>,
        url: &str,
        cache_max_size: Option<usize>,
        cache_ttl_secs: Option<u64>,
    ) -> PyResult<Self> {
        let url = url.to_string();
        let cache_opts = make_cache_opts(cache_max_size, cache_ttl_secs);
        let conn = py
            .detach(|| get_runtime().block_on(connect_standard(&url, cache_opts)))
            .map_err(|e| pyo3::exceptions::PyConnectionError::new_err(e))?;
        Ok(Self { connection: conn })
    }

    #[staticmethod]
    fn connect_to_cluster(py: Python<'_>, urls: Vec<String>) -> PyResult<Self> {
        let conn = py
            .detach(|| get_runtime().block_on(connect_cluster(urls)))
            .map_err(|e| pyo3::exceptions::PyConnectionError::new_err(e))?;
        Ok(Self { connection: conn })
    }

    #[staticmethod]
    #[pyo3(signature = (sentinel_urls, service_name, db, cache_max_size=None, cache_ttl_secs=None))]
    fn connect_via_sentinel(
        py: Python<'_>,
        sentinel_urls: Vec<String>,
        service_name: &str,
        db: i64,
        cache_max_size: Option<usize>,
        cache_ttl_secs: Option<u64>,
    ) -> PyResult<Self> {
        let service_name = service_name.to_string();
        let cache_opts = make_cache_opts(cache_max_size, cache_ttl_secs);
        let conn = py
            .detach(|| {
                get_runtime().block_on(connect_sentinel(
                    sentinel_urls,
                    &service_name,
                    db,
                    cache_opts,
                ))
            })
            .map_err(|e| pyo3::exceptions::PyConnectionError::new_err(e))?;
        Ok(Self { connection: conn })
    }

    // =================================================================
    // Client-side cache statistics
    // =================================================================

    /// Returns (hits, misses, invalidations) or None if caching is not enabled.
    #[pyo3(signature = ())]
    fn cache_statistics(&self) -> Option<(usize, usize, usize)> {
        self.connection
            .cache_statistics()
            .map(|s| (s.hit, s.miss, s.invalidate))
    }

    // =================================================================
    // Key/value operations — async
    // =================================================================

    #[pyo3(signature = (key))]
    fn get(&self, py: Python<'_>, key: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_opt_bytes(conn.get_bytes(&key).await)
        })
    }

    #[pyo3(signature = (key))]
    fn get_sync(&self, py: Python<'_>, key: &str) -> PyResult<Option<Py<PyAny>>> {
        let result: Result<Option<Vec<u8>>, _> =
            sync_op!(py, self, conn, conn.get_bytes(key).await);
        match result
            .map_err(|e| to_py_err(e))?
        {
            Some(bytes) => Ok(Some(PyBytes::new(py, &bytes).into_any().unbind())),
            None => Ok(None),
        }
    }

    #[pyo3(signature = (key, value, ttl=None))]
    fn set(
        &self,
        py: Python<'_>,
        key: &str,
        value: &[u8],
        ttl: Option<u64>,
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        let value = value.to_vec();
        async_op!(self, py, conn, {
            r_unit(conn.set_bytes(&key, value, ttl).await)
        })
    }

    #[pyo3(signature = (key, value, ttl=None))]
    fn set_sync(
        &self,
        py: Python<'_>,
        key: &str,
        value: &[u8],
        ttl: Option<u64>,
    ) -> PyResult<bool> {
        let value = value.to_vec();
        sync_op!(py, self, conn, conn.set_bytes(key, value, ttl).await)
            .map_err(|e| to_py_err(e))?;
        Ok(true)
    }

    #[pyo3(signature = (key, value, ttl=None))]
    fn set_nx(
        &self,
        py: Python<'_>,
        key: &str,
        value: &[u8],
        ttl: Option<u64>,
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        let value = value.to_vec();
        async_op!(self, py, conn, {
            r_bool(conn.set_nx(&key, value, ttl).await)
        })
    }

    #[pyo3(signature = (key, value, ttl=None))]
    fn set_nx_sync(
        &self,
        py: Python<'_>,
        key: &str,
        value: &[u8],
        ttl: Option<u64>,
    ) -> PyResult<bool> {
        let value = value.to_vec();
        sync_op!(py, self, conn, conn.set_nx(key, value, ttl).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key))]
    fn delete(&self, py: Python<'_>, key: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_int(conn.del(&key).await)
        })
    }

    #[pyo3(signature = (key))]
    fn delete_sync(&self, py: Python<'_>, key: &str) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.del(key).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (keys))]
    fn delete_many(&self, py: Python<'_>, keys: Vec<String>) -> PyResult<Py<PyAny>> {
        async_op!(self, py, conn, {
            r_int(conn.del_many(&keys).await)
        })
    }

    #[pyo3(signature = (key))]
    fn exists(&self, py: Python<'_>, key: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_bool(conn.exists(&key).await)
        })
    }

    #[pyo3(signature = (key))]
    fn exists_sync(&self, py: Python<'_>, key: &str) -> PyResult<bool> {
        sync_op!(py, self, conn, conn.exists(key).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key, seconds))]
    fn expire(&self, py: Python<'_>, key: &str, seconds: u64) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_bool(conn.expire(&key, seconds).await)
        })
    }

    #[pyo3(signature = (key, seconds))]
    fn expire_sync(&self, py: Python<'_>, key: &str, seconds: u64) -> PyResult<bool> {
        sync_op!(py, self, conn, conn.expire(key, seconds).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key))]
    fn persist(&self, py: Python<'_>, key: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_bool(conn.persist(&key).await)
        })
    }

    #[pyo3(signature = (key))]
    fn persist_sync(&self, py: Python<'_>, key: &str) -> PyResult<bool> {
        sync_op!(py, self, conn, conn.persist(key).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (keys))]
    fn mget(&self, py: Python<'_>, keys: Vec<String>) -> PyResult<Py<PyAny>> {
        async_op!(self, py, conn, {
            match conn.mget_bytes(&keys).await {
                Ok(results) => RawResult::OptBytesList(results),
                Err(e) => classify(e),
            }
        })
    }

    #[pyo3(signature = (entries, ttl=None))]
    fn pipeline_set(
        &self,
        py: Python<'_>,
        entries: Vec<(String, Vec<u8>)>,
        ttl: Option<u64>,
    ) -> PyResult<Py<PyAny>> {
        async_op!(self, py, conn, {
            r_unit(conn.pipeline_set(&entries, ttl).await)
        })
    }

    #[pyo3(signature = (keys))]
    fn mget_sync(&self, py: Python<'_>, keys: Vec<String>) -> PyResult<Py<PyAny>> {
        let results: Vec<Option<Vec<u8>>> =
            sync_op!(py, self, conn, conn.mget_bytes(&keys).await)
                .map_err(|e| to_py_err(e))?;
        let py_items: Vec<Py<PyAny>> = results
            .into_iter()
            .map(|r| match r {
                Some(bytes) => PyBytes::new(py, &bytes).into_any().unbind(),
                None => py.None(),
            })
            .collect();
        Ok(pyo3::types::PyList::new(py, py_items)?.into_any().unbind())
    }

    #[pyo3(signature = (entries, ttl=None))]
    fn pipeline_set_sync(
        &self,
        py: Python<'_>,
        entries: Vec<(String, Vec<u8>)>,
        ttl: Option<u64>,
    ) -> PyResult<()> {
        sync_op!(py, self, conn, conn.pipeline_set(&entries, ttl).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (keys))]
    fn delete_many_sync(&self, py: Python<'_>, keys: Vec<String>) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.del_many(&keys).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key, delta))]
    fn incr_by(&self, py: Python<'_>, key: &str, delta: i64) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_int(conn.incr_by(&key, delta).await)
        })
    }

    #[pyo3(signature = (key, delta))]
    fn incr_by_sync(&self, py: Python<'_>, key: &str, delta: i64) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.incr_by(key, delta).await)
            .map_err(to_py_err)
    }

    fn flushdb(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        async_op!(self, py, conn, {
            r_unit(conn.flushdb().await)
        })
    }

    #[pyo3(signature = ())]
    fn flushdb_sync(&self, py: Python<'_>) -> PyResult<()> {
        sync_op!(py, self, conn, conn.flushdb().await)
            .map_err(to_py_err)
    }

    // =================================================================
    // Lock operations
    // =================================================================

    #[pyo3(signature = (key, token, timeout_ms=None))]
    fn lock_acquire(
        &self,
        py: Python<'_>,
        key: &str,
        token: &str,
        timeout_ms: Option<u64>,
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        let token = token.to_string();
        async_op!(self, py, conn, {
            r_bool(conn.lock_acquire(&key, &token, timeout_ms).await)
        })
    }

    #[pyo3(signature = (key, token, timeout_ms=None))]
    fn lock_acquire_sync(
        &self,
        py: Python<'_>,
        key: &str,
        token: &str,
        timeout_ms: Option<u64>,
    ) -> PyResult<bool> {
        sync_op!(py, self, conn, {
            conn.lock_acquire(key, token, timeout_ms).await
        })
        .map_err(to_py_err)
    }

    #[pyo3(signature = (key, token))]
    fn lock_release(&self, py: Python<'_>, key: &str, token: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        let token = token.to_string();
        async_op!(self, py, conn, {
            r_int(conn.lock_release(&key, &token).await)
        })
    }

    #[pyo3(signature = (key, token))]
    fn lock_release_sync(&self, py: Python<'_>, key: &str, token: &str) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.lock_release(key, token).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key, token, additional_ms))]
    fn lock_extend(
        &self,
        py: Python<'_>,
        key: &str,
        token: &str,
        additional_ms: u64,
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        let token = token.to_string();
        async_op!(self, py, conn, {
            r_int(conn.lock_extend(&key, &token, additional_ms).await)
        })
    }

    // =================================================================
    // List operations (raw bytes)
    // =================================================================

    #[pyo3(signature = (key, values))]
    fn lpush(&self, py: Python<'_>, key: &str, values: Vec<Vec<u8>>) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_int(conn.lpush(&key, values).await)
        })
    }

    #[pyo3(signature = (key, values))]
    fn lpush_sync(&self, py: Python<'_>, key: &str, values: Vec<Vec<u8>>) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.lpush(key, values).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key, values))]
    fn rpush(&self, py: Python<'_>, key: &str, values: Vec<Vec<u8>>) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_int(conn.rpush(&key, values).await)
        })
    }

    #[pyo3(signature = (key, values))]
    fn rpush_sync(&self, py: Python<'_>, key: &str, values: Vec<Vec<u8>>) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.rpush(key, values).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (key))]
    fn rpop(&self, py: Python<'_>, key: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_opt_bytes(conn.rpop(&key).await)
        })
    }

    #[pyo3(signature = (key))]
    fn rpop_sync(&self, py: Python<'_>, key: &str) -> PyResult<Option<Py<PyAny>>> {
        let result: Result<Option<Vec<u8>>, _> =
            sync_op!(py, self, conn, conn.rpop(key).await);
        match result
            .map_err(|e| to_py_err(e))?
        {
            Some(bytes) => Ok(Some(PyBytes::new(py, &bytes).into_any().unbind())),
            None => Ok(None),
        }
    }

    #[pyo3(signature = (key, start, stop))]
    fn lrange(
        &self,
        py: Python<'_>,
        key: &str,
        start: i64,
        stop: i64,
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            match conn.lrange(&key, start, stop).await {
                Ok(items) => RawResult::BytesList(items),
                Err(e) => classify(e),
            }
        })
    }

    #[pyo3(signature = (key, start, stop))]
    fn lrange_sync(
        &self,
        py: Python<'_>,
        key: &str,
        start: i64,
        stop: i64,
    ) -> PyResult<Py<PyAny>> {
        let items: Vec<Vec<u8>> =
            sync_op!(py, self, conn, conn.lrange(key, start, stop).await)
                .map_err(|e| to_py_err(e))?;
        let py_items: Vec<Py<PyAny>> = items
            .iter()
            .map(|b| PyBytes::new(py, b).into_any().unbind())
            .collect();
        Ok(pyo3::types::PyList::new(py, py_items)?.into_any().unbind())
    }

    #[pyo3(signature = (key, count, value))]
    fn lrem(
        &self,
        py: Python<'_>,
        key: &str,
        count: i64,
        value: &[u8],
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        let value = value.to_vec();
        async_op!(self, py, conn, {
            r_int(conn.lrem(&key, count, &value).await)
        })
    }

    #[pyo3(signature = (key, start, stop))]
    fn ltrim(
        &self,
        py: Python<'_>,
        key: &str,
        start: i64,
        stop: i64,
    ) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_unit(conn.ltrim(&key, start, stop).await)
        })
    }

    #[pyo3(signature = (key))]
    fn llen(&self, py: Python<'_>, key: &str) -> PyResult<Py<PyAny>> {
        let key = key.to_string();
        async_op!(self, py, conn, {
            r_int(conn.llen(&key).await)
        })
    }

    #[pyo3(signature = (key))]
    fn llen_sync(&self, py: Python<'_>, key: &str) -> PyResult<i64> {
        sync_op!(py, self, conn, conn.llen(key).await)
            .map_err(to_py_err)
    }

    #[pyo3(signature = (source, destination, wherefrom, whereto, timeout))]
    fn blmove(
        &self,
        py: Python<'_>,
        source: &str,
        destination: &str,
        wherefrom: &str,
        whereto: &str,
        timeout: f64,
    ) -> PyResult<Py<PyAny>> {
        let source = source.to_string();
        let destination = destination.to_string();
        let wherefrom = wherefrom.to_string();
        let whereto = whereto.to_string();
        async_op!(self, py, conn, {
            r_opt_bytes(
                conn.blmove(&source, &destination, &wherefrom, &whereto, timeout)
                    .await,
            )
        })
    }

    #[pyo3(signature = (source, destination, wherefrom, whereto, timeout))]
    fn blmove_sync(
        &self,
        py: Python<'_>,
        source: &str,
        destination: &str,
        wherefrom: &str,
        whereto: &str,
        timeout: f64,
    ) -> PyResult<Option<Py<PyAny>>> {
        let result: Result<Option<Vec<u8>>, _> = sync_op!(py, self, conn, {
            conn.blmove(source, destination, wherefrom, whereto, timeout)
                .await
        });
        match result
            .map_err(|e| to_py_err(e))?
        {
            Some(bytes) => Ok(Some(PyBytes::new(py, &bytes).into_any().unbind())),
            None => Ok(None),
        }
    }

    #[pyo3(signature = (timeout, keys, direction, count))]
    fn blmpop(
        &self,
        py: Python<'_>,
        timeout: f64,
        keys: Vec<String>,
        direction: &str,
        count: i64,
    ) -> PyResult<Py<PyAny>> {
        let direction = direction.to_string();
        async_op!(self, py, conn, {
            match conn.blmpop(timeout, &keys, &direction, count).await {
                Ok(v) => RawResult::OptKeyAndBytesList(v),
                Err(e) => classify(e),
            }
        })
    }

    // =================================================================
    // Scan
    // =================================================================

    #[pyo3(signature = (pattern, count=100))]
    fn scan_all(&self, py: Python<'_>, pattern: &str, count: i64) -> PyResult<Py<PyAny>> {
        let pattern = pattern.to_string();
        async_op!(self, py, conn, {
            match conn.scan_all(&pattern, count).await {
                Ok(keys) => RawResult::StringList(keys),
                Err(e) => classify(e),
            }
        })
    }

    #[pyo3(signature = (pattern, count=100))]
    fn scan_all_sync(&self, py: Python<'_>, pattern: &str, count: i64) -> PyResult<Vec<String>> {
        sync_op!(py, self, conn, conn.scan_all(pattern, count).await)
            .map_err(to_py_err)
    }

    // =================================================================
    // Eval (Lua scripting)
    // =================================================================

    #[pyo3(signature = (script, keys, args))]
    fn eval(
        &self,
        py: Python<'_>,
        script: &str,
        keys: Vec<String>,
        args: Vec<Vec<u8>>,
    ) -> PyResult<Py<PyAny>> {
        let script = script.to_string();
        async_op!(self, py, conn, {
            r_value(conn.eval(&script, &keys, &args).await)
        })
    }

    #[pyo3(signature = (script, keys, args))]
    fn eval_sync(
        &self,
        py: Python<'_>,
        script: &str,
        keys: Vec<String>,
        args: Vec<Vec<u8>>,
    ) -> PyResult<Py<PyAny>> {
        let result: redis::Value =
            sync_op!(py, self, conn, conn.eval(script, &keys, &args).await)
                .map_err(|e| to_py_err(e))?;
        r_value(Ok(result))
            .into_py(py)
    }

    // =================================================================
    // EVALSHA / SCRIPT LOAD
    // =================================================================

    #[pyo3(signature = (sha, keys, args))]
    fn evalsha(
        &self,
        py: Python<'_>,
        sha: &str,
        keys: Vec<String>,
        args: Vec<Vec<u8>>,
    ) -> PyResult<Py<PyAny>> {
        let sha = sha.to_string();
        async_op!(self, py, conn, {
            r_value(conn.evalsha(&sha, &keys, &args).await)
        })
    }

    #[pyo3(signature = (sha, keys, args))]
    fn evalsha_sync(
        &self,
        py: Python<'_>,
        sha: &str,
        keys: Vec<String>,
        args: Vec<Vec<u8>>,
    ) -> PyResult<Py<PyAny>> {
        let result: redis::Value =
            sync_op!(py, self, conn, conn.evalsha(sha, &keys, &args).await)
                .map_err(|e| to_py_err(e))?;
        r_value(Ok(result))
            .into_py(py)
    }

    #[pyo3(signature = (script))]
    fn script_load(&self, py: Python<'_>, script: &str) -> PyResult<Py<PyAny>> {
        let script = script.to_string();
        async_op!(self, py, conn, {
            match conn.script_load(&script).await {
                Ok(sha) => RawResult::OptBytes(Some(sha.into_bytes())),
                Err(e) => classify(e),
            }
        })
    }

    #[pyo3(signature = (script))]
    fn script_load_sync(&self, py: Python<'_>, script: &str) -> PyResult<String> {
        sync_op!(py, self, conn, conn.script_load(script).await)
            .map_err(to_py_err)
    }

    // =================================================================
    // Pipeline (general-purpose)
    // =================================================================

    /// Execute a pipeline of commands. Each command is a list [name, arg1, arg2, ...].
    /// Returns a list of results (each as Value).
    #[pyo3(signature = (commands))]
    fn pipeline_exec(
        &self,
        py: Python<'_>,
        commands: Vec<(String, Vec<Vec<u8>>)>,
    ) -> PyResult<Py<PyAny>> {
        async_op!(self, py, conn, {
            match conn.pipeline_exec(commands).await {
                Ok(values) => {
                    // Convert Vec<Value> to a list representation
                    let items: Vec<Option<Vec<u8>>> = values
                        .into_iter()
                        .map(|v| match v {
                            redis::Value::Int(i) => Some(i.to_string().into_bytes()),
                            redis::Value::BulkString(b) => Some(b),
                            redis::Value::SimpleString(s) => Some(s.into_bytes()),
                            redis::Value::Okay => Some(b"OK".to_vec()),
                            redis::Value::Nil => None,
                            _ => None,
                        })
                        .collect();
                    RawResult::OptBytesList(items)
                }
                Err(e) => classify(e),
            }
        })
    }

    #[pyo3(signature = (commands))]
    fn pipeline_exec_sync(
        &self,
        py: Python<'_>,
        commands: Vec<(String, Vec<Vec<u8>>)>,
    ) -> PyResult<Py<PyAny>> {
        let values: Vec<redis::Value> =
            sync_op!(py, self, conn, conn.pipeline_exec(commands).await)
                .map_err(|e| to_py_err(e))?;
        let items: Vec<Option<Vec<u8>>> = values
            .into_iter()
            .map(|v| match v {
                redis::Value::Int(i) => Some(i.to_string().into_bytes()),
                redis::Value::BulkString(b) => Some(b),
                redis::Value::SimpleString(s) => Some(s.into_bytes()),
                redis::Value::Okay => Some(b"OK".to_vec()),
                redis::Value::Nil => None,
                _ => None,
            })
            .collect();
        let py_items: Vec<Py<PyAny>> = items
            .into_iter()
            .map(|r| match r {
                Some(bytes) => PyBytes::new(py, &bytes).into_any().unbind(),
                None => py.None(),
            })
            .collect();
        Ok(pyo3::types::PyList::new(py, py_items)?.into_any().unbind())
    }
}
