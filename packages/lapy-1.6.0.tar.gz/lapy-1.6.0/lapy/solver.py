import importlib
import inspect
import logging
import sys

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh as _eigsh

from .tet_mesh import TetMesh
from .tria_mesh import TriaMesh
from .utils._imports import import_optional_dependency

logger = logging.getLogger(__name__)

# Evaluated once at import time; avoids repeated introspection on every eigs() call.
_EIGSH_SUPPORTS_RNG = "rng" in inspect.signature(_eigsh).parameters

class Solver:
    """FEM solver for Laplace Eigenvalue and Poisson Equation.

    Inputs can be geometry classes, which have vertices and elements.
    Currently, `~lapy.TriaMesh` and `~lapy.TetMesh` are implemented.
    FEM matrices (stiffness (or A) and mass matrix (or B)) are computed
    during the construction. After that the Eigenvalue solver (`lapy.Solver.eigs`) or
    Poisson Solver (`lapy.Solver.poisson`) can be called.

    Parameters
    ----------
    geometry : TriaMesh | TetMesh
        Mesh geometry.
    lump : bool
        If True, lump the mass matrix (diagonal).
    aniso : float | tuple of shape (2,)
        Anisotropy for curvature-based anisotopic Laplace.
        If a tuple ``(a_min, a_max), differentially affects the minimum and maximum
        curvature directions. e.g. ``(0, 50)`` will set scaling to 1 into the minimum
        curvature direction, even if the maximum curvature is large in those regions
        (i.e. isotropic in regions with large maximum curvature and minimum curvature
        close to 0, i.e. a concave cylinder).
    aniso_smooth : int | None
        Number of smoothing iterations for curvature computation on vertices.
    use_cholmod : bool, default: False
        If True, attempts to use the Cholesky decomposition for improved execution
        speed. Requires the ``scikit-sparse`` library. If it can not be found, an error
        will be thrown.
        If False, will use slower LU decomposition.
    dtype : numpy.dtype, default=np.float64
        Data type for the stiffness and mass matrices. Defaults to ``np.float64``
        for numerical stability. Use ``np.float32`` explicitly if memory is constrained
        and precision is less critical.

    Notes
    -----
    The class has a static member to create the mass matrix of `~lapy.TriaMesh` for
    external functions that do not need stiffness.
    """

    def __init__(
        self,
        geometry: TriaMesh | TetMesh,
        lump: bool = False,
        aniso: float | tuple[float, float] | None = None,
        aniso_smooth: int = 10,
        use_cholmod: bool = False,
        dtype: np.dtype = np.float64,
    ) -> None:
        if use_cholmod:
            self.sksparse = import_optional_dependency("sksparse", raise_error=True)
            importlib.import_module(".cholmod", self.sksparse.__name__)
        else:
            self.sksparse = None

        # Ensure dtype is a numpy dtype object
        dtype = np.dtype(dtype)

        if type(geometry).__name__ == "TriaMesh":
            if aniso is not None:
                # anisotropic Laplace
                logger.info("TriaMesh with anisotropic Laplace-Beltrami")
                u1, u2, c1, c2 = geometry.curvature_tria(smoothit=aniso_smooth)
                # Diag mat to specify anisotropy strength
                if isinstance(aniso, (list, tuple, set, np.ndarray)):
                    if len(aniso) != 2:
                        raise ValueError(
                            "aniso should be scalar or tuple/array of length 2!"
                        )
                    aniso0 = aniso[0]
                    aniso1 = aniso[1]
                else:
                    aniso0 = aniso
                    aniso1 = aniso
                aniso_mat = np.empty((geometry.t.shape[0], 2), dtype=dtype)
                aniso_mat[:, 1] = np.exp(-aniso1 * np.abs(c1))
                aniso_mat[:, 0] = np.exp(-aniso0 * np.abs(c2))
                a, b = self._fem_tria_aniso(geometry, u1, u2, aniso_mat, lump, dtype)
            else:
                logger.info("TriaMesh with regular Laplace-Beltrami")
                a, b = self._fem_tria(geometry, lump, dtype)
        elif type(geometry).__name__ == "TetMesh":
            logger.info("TetMesh with regular Laplace")
            a, b = self._fem_tetra(geometry, lump, dtype)
        else:
            raise ValueError('Geometry type "' + type(geometry).__name__ + '" unknown')
        self.stiffness = a
        self.mass = b
        self.geotype = type(geometry)
        self.use_cholmod = use_cholmod

    @staticmethod
    def _fem_tria(
        tria: TriaMesh, lump: bool = False, dtype: np.dtype = np.float64
    ) -> tuple[sparse.csc_matrix, sparse.csc_matrix]:
        r"""Compute the 2 sparse symmetric matrices of the Laplace-Beltrami operator for a triangle mesh.

        The 2 sparse symmetric matrices are computed for a given triangle mesh
        using the linear finite element method (assuming a closed mesh or
        Neumann boundary condition).

        Parameters
        ----------
        tria : TriaMesh
            Triangle mesh.
        lump : bool, default=False
            If True, ``B`` should be lumped (diagonal).
        dtype : numpy.dtype, default=np.float64
            Data type for the output matrices. Defaults to ``np.float64`` for numerical stability.

        Returns
        -------
        A : scipy.sparse.csc_matrix
            Sparse symmetric positive semi-definite stiffness matrix, shape (n, n).
        B : scipy.sparse.csc_matrix
            Sparse symmetric positive definite mass matrix, shape (n, n).

        Notes
        -----
        This static method can be used to solve:

        * Sparse generalized Eigenvalue problem: ``A x = lambda B x``
        * Poisson equation: ``A x = B f`` (where f is a function on mesh vertices)
        * Laplace equation: ``A x = 0``

        Or to model the operator's action on a vector ``x``: ``y = B\(Ax)``.
        """
        # Ensure dtype is a numpy dtype object
        dtype = np.dtype(dtype)

        # Compute vertex coordinates and a difference vector for each triangle:
        t1 = tria.t[:, 0]
        t2 = tria.t[:, 1]
        t3 = tria.t[:, 2]
        v1 = tria.v[t1, :]
        v2 = tria.v[t2, :]
        v3 = tria.v[t3, :]
        v2mv1 = v2 - v1
        v3mv2 = v3 - v2
        v1mv3 = v1 - v3
        # Compute cross product and 4*vol for each triangle:
        cr = np.cross(v3mv2, v1mv3)
        vol = 2 * np.sqrt(np.sum(cr * cr, axis=1))
        # zero vol will cause division by zero below, so set to small value:
        vol_mean = max(0.0001 * np.mean(vol), sys.float_info.epsilon)
        vol[vol < sys.float_info.epsilon] = vol_mean
        # compute cotangents for A
        # using that v2mv1 = - (v3mv2 + v1mv3) this can also be seen by
        # summing the local matrix entries in the old algorithm
        a12 = np.sum(v3mv2 * v1mv3, axis=1) / vol
        a23 = np.sum(v1mv3 * v2mv1, axis=1) / vol
        a31 = np.sum(v2mv1 * v3mv2, axis=1) / vol
        # compute diagonals (from row sum = 0)
        a11 = -a12 - a31
        a22 = -a12 - a23
        a33 = -a31 - a23
        # stack columns to assemble data
        local_a = np.column_stack(
            (a12, a12, a23, a23, a31, a31, a11, a22, a33)
        ).reshape(-1).astype(dtype, copy=False)
        i = np.column_stack((t1, t2, t2, t3, t3, t1, t1, t2, t3)).reshape(-1)
        j = np.column_stack((t2, t1, t3, t2, t1, t3, t1, t2, t3)).reshape(-1)
        # Construct sparse matrix:
        # a = sparse.csr_matrix((local_a, (i, j)))
        a = sparse.csc_matrix((local_a, (i, j)), dtype=dtype)
        # construct mass matrix (sparse or diagonal if lumped)
        if not lump:
            # create b matrix data (account for that vol is 4 times area)
            b_ii = vol / 24
            b_ij = vol / 48
            local_b = np.column_stack(
                (b_ij, b_ij, b_ij, b_ij, b_ij, b_ij, b_ii, b_ii, b_ii)
            ).reshape(-1).astype(dtype, copy=False)
            b = sparse.csc_matrix((local_b, (i, j)), dtype=dtype)
        else:
            # when lumping put all onto diagonal  (area/3 for each vertex)
            b_ii = vol / 12
            local_b = np.column_stack((b_ii, b_ii, b_ii)).reshape(-1).astype(dtype, copy=False)
            i = np.column_stack((t1, t2, t3)).reshape(-1)
            b = sparse.csc_matrix((local_b, (i, i)), dtype=dtype)
        return a, b

    @staticmethod
    def _fem_tria_aniso(
        tria: TriaMesh,
        u1: np.ndarray,
        u2: np.ndarray,
        aniso_mat: np.ndarray,
        lump: bool = False,
        dtype: np.dtype = np.float64,
    ) -> tuple[sparse.csc_matrix, sparse.csc_matrix]:
        r"""Compute the 2 sparse symmetric matrices of the Laplace-Beltrami operator for a triangle mesh.

        The 2 sparse symmetric matrices are computed for a given triangle mesh
        using the linear finite element method (assuming a closed mesh or
        Neumann boundary condition).

        Parameters
        ----------
        tria : TriaMesh
            Triangle mesh.
        u1 : np.ndarray
            Minimum curvature direction per triangle, shape (n_triangles, 3).
        u2 : np.ndarray
            Maximum curvature direction per triangle, shape (n_triangles, 3).
        aniso_mat : np.ndarray
            Anisotropy matrix. Diagonal elements in ``u1``, ``u2`` basis per
            triangle, shape (n_triangles, 2).
        lump : bool, default=False
            If True, ``B`` should be lumped (diagonal).
        dtype : numpy.dtype, default=np.float64
            Data type for the output matrices. Defaults to ``np.float64`` for numerical stability.

        Returns
        -------
        A : scipy.sparse.csc_matrix
            Sparse symmetric positive semi-definite stiffness matrix, shape (n, n).
        B : scipy.sparse.csc_matrix
            Sparse symmetric positive definite mass matrix, shape (n, n).

        Notes
        -----
        This static method can be used to solve:

        * Sparse generalized Eigenvalue problem: ``A x = lambda B x``
        * Poisson equation: ``A x = B f`` (where f is function on mesh vertices)
        * Laplace equation: ``A x = 0``

        Or to model the operator's action on a vector ``x``: ``y = B\(Ax)``.
        """
        # Ensure dtype is a numpy dtype object
        dtype = np.dtype(dtype)

        # Compute vertex coordinates and a difference vector for each triangle:
        t1 = tria.t[:, 0]
        t2 = tria.t[:, 1]
        t3 = tria.t[:, 2]
        v1 = tria.v[t1, :]
        v2 = tria.v[t2, :]
        v3 = tria.v[t3, :]
        v2mv1 = v2 - v1
        v3mv2 = v3 - v2
        v1mv3 = v1 - v3
        # transform edge e to basis U = (U1,U2) via U^T * e
        # Ui is n x 3, e is n x 1, result is n x 2
        uv2mv1 = np.column_stack(
            (np.sum(u1 * v2mv1, axis=1), np.sum(u2 * v2mv1, axis=1))
        )
        uv3mv2 = np.column_stack(
            (np.sum(u1 * v3mv2, axis=1), np.sum(u2 * v3mv2, axis=1))
        )
        uv1mv3 = np.column_stack(
            (np.sum(u1 * v1mv3, axis=1), np.sum(u2 * v1mv3, axis=1))
        )
        # Compute cross product and 4*vol for each triangle:
        cr = np.cross(v3mv2, v1mv3)
        vol = 2 * np.sqrt(np.sum(cr * cr, axis=1))
        # zero vol will cause division by zero below, so set to small value:
        vol_mean = max(0.0001 * np.mean(vol), sys.float_info.epsilon)
        vol[vol < sys.float_info.epsilon] = vol_mean
        # compute cotangents for A
        # using that v2mv1 = - (v3mv2 + v1mv3) this can also be seen by
        # summing the local matrix entries in the old algorithm
        # Also: here aniso_mat is the two diagonal entries, not full matrices
        a12 = np.sum(uv3mv2 * aniso_mat * uv1mv3, axis=1) / vol
        a23 = np.sum(uv1mv3 * aniso_mat * uv2mv1, axis=1) / vol
        a31 = np.sum(uv2mv1 * aniso_mat * uv3mv2, axis=1) / vol
        # compute diagonals (from row sum = 0)
        a11 = -a12 - a31
        a22 = -a12 - a23
        a33 = -a31 - a23
        # stack columns to assemble data
        local_a = np.column_stack(
            (a12, a12, a23, a23, a31, a31, a11, a22, a33)
        ).reshape(-1).astype(dtype, copy=False)
        i = np.column_stack((t1, t2, t2, t3, t3, t1, t1, t2, t3)).reshape(-1)
        j = np.column_stack((t2, t1, t3, t2, t1, t3, t1, t2, t3)).reshape(-1)
        # Construct sparse matrix:
        # a = sparse.csr_matrix((local_a, (i, j)))
        a = sparse.csc_matrix((local_a, (i, j)), dtype=dtype)
        if not lump:
            # create b matrix data (account for that vol is 4 times area)
            b_ii = vol / 24
            b_ij = vol / 48
            local_b = np.column_stack(
                (b_ij, b_ij, b_ij, b_ij, b_ij, b_ij, b_ii, b_ii, b_ii)
            ).reshape(-1).astype(dtype, copy=False)
            b = sparse.csc_matrix((local_b, (i, j)), dtype=dtype)
        else:
            # when lumping put all onto diagonal  (area/3 for each vertex)
            b_ii = vol / 12
            local_b = np.column_stack((b_ii, b_ii, b_ii)).reshape(-1).astype(dtype, copy=False)
            i = np.column_stack((t1, t2, t3)).reshape(-1)
            b = sparse.csc_matrix((local_b, (i, i)), dtype=dtype)
        return a, b

    @staticmethod
    def fem_tria_mass(tria: TriaMesh, lump: bool = False, dtype: np.dtype = np.float64) -> sparse.csc_matrix:
        """Compute the sparse symmetric mass matrix of the Laplace-Beltrami operator for a given triangle mesh.

        The sparse symmetric matrix is computed for a given triangle mesh using
        the linear finite element method (assuming a closed mesh or Neumann
        boundary condition). This function is faster than the constructor above
        and can be used when only a mass matrix is needed.

        Parameters
        ----------
        tria : TriaMesh
            Triangle mesh.
        lump : bool, default=False
            If True, ``B`` should be lumped (diagonal).
        dtype : numpy.dtype, default=np.float64
            Data type for the output matrix. Defaults to ``np.float64`` for numerical stability.

        Returns
        -------
        scipy.sparse.csc_matrix
            Sparse symmetric positive definite mass matrix ``B``, shape (n, n).

        Notes
        -----
        This only returns the mass matrix ``B`` of the Eigenvalue problem:
        ``A x = lambda B x``. The area of the surface mesh can be obtained
        via ``B.sum()``.
        """
        # Ensure dtype is a numpy dtype object
        dtype = np.dtype(dtype)

        # Compute vertex coordinates and a difference vector for each triangle:
        t1 = tria.t[:, 0]
        t2 = tria.t[:, 1]
        t3 = tria.t[:, 2]
        v1 = tria.v[t1, :]
        v2 = tria.v[t2, :]
        v3 = tria.v[t3, :]
        # v2mv1 = v2 - v1
        v3mv2 = v3 - v2
        v1mv3 = v1 - v3

        # Compute cross product and 4*vol for each triangle:
        cr = np.cross(v3mv2, v1mv3)
        vol = 0.5 * np.sqrt(np.sum(cr * cr, axis=1))
        # zero vol will cause division by zero below, so set to small value:
        vol_mean = max(0.0001 * np.mean(vol), sys.float_info.epsilon)
        vol[vol < sys.float_info.epsilon] = vol_mean
        # create b matrix data
        if not lump:
            b_ii = vol / 6
            b_ij = vol / 12
            local_b = np.column_stack(
                (b_ij, b_ij, b_ij, b_ij, b_ij, b_ij, b_ii, b_ii, b_ii)
            ).reshape(-1).astype(dtype, copy=False)
            # stack edge and diag coords for matrix indices
            i = np.column_stack((t1, t2, t2, t3, t3, t1, t1, t2, t3)).reshape(-1)
            j = np.column_stack((t2, t1, t3, t2, t1, t3, t1, t2, t3)).reshape(-1)
            # Construct sparse matrix:
            b = sparse.csc_matrix((local_b, (i, j)), dtype=dtype)
        else:
            # when lumping put all onto diagonal
            b_ii = vol / 3
            local_b = np.column_stack((b_ii, b_ii, b_ii)).reshape(-1).astype(dtype, copy=False)
            i = np.column_stack((t1, t2, t3)).reshape(-1)
            b = sparse.csc_matrix((local_b, (i, i)), dtype=dtype)
        return b

    @staticmethod
    def _fem_tetra(
        tetra: TetMesh, lump: bool = False, dtype: np.dtype = np.float64
    ) -> tuple[sparse.csc_matrix, sparse.csc_matrix]:
        r"""Compute the 2 sparse symmetric matrices of the Laplace-Beltrami operator for a tetrahedral mesh.

        The 2 sparse symmetric matrices are computed for a given tetrahedral
        mesh using the linear finite element method (Neumann boundary condition).

        Parameters
        ----------
        tetra : TetMesh
            Tetrahedral mesh.
        lump : bool, default=False
            If True, ``B`` should be lumped (diagonal).
        dtype : numpy.dtype, default=np.float64
            Data type for the output matrices. Defaults to ``np.float64`` for numerical stability.

        Returns
        -------
        A : scipy.sparse.csc_matrix
            Sparse symmetric positive semi-definite stiffness matrix, shape (n, n).
        B : scipy.sparse.csc_matrix
            Sparse symmetric positive definite mass matrix, shape (n, n).

        Notes
        -----
        This static method can be used to solve:

        * Sparse generalized Eigenvalue problem: ``A x = lambda B x``
        * Poisson equation: ``A x = B f`` (where f is function on mesh vertices)
        * Laplace equation: ``A x = 0``

        Or to model the operator's action on a vector ``x``: ``y = B\(Ax)``.
        """
        # Ensure dtype is a numpy dtype object
        dtype = np.dtype(dtype)

        # Compute vertex coordinates and a difference vector for each triangle:
        t1 = tetra.t[:, 0]
        t2 = tetra.t[:, 1]
        t3 = tetra.t[:, 2]
        t4 = tetra.t[:, 3]
        v1 = tetra.v[t1, :]
        v2 = tetra.v[t2, :]
        v3 = tetra.v[t3, :]
        v4 = tetra.v[t4, :]
        e1 = v2 - v1
        e2 = v3 - v2
        e3 = v1 - v3
        e4 = v4 - v1
        e5 = v4 - v2
        e6 = v4 - v3
        # Compute cross product and 6 * vol for each triangle:
        cr = np.cross(e1, e3)
        vol = np.abs(np.sum(e4 * cr, axis=1))
        # zero vol will cause division by zero below, so set to small value:
        vol_mean = max(0.0001 * np.mean(vol), sys.float_info.epsilon)
        vol[vol < sys.float_info.epsilon] = vol_mean
        # compute dot products of edge vectors
        e11 = np.sum(e1 * e1, axis=1)
        e22 = np.sum(e2 * e2, axis=1)
        e33 = np.sum(e3 * e3, axis=1)
        e44 = np.sum(e4 * e4, axis=1)
        e55 = np.sum(e5 * e5, axis=1)
        e66 = np.sum(e6 * e6, axis=1)
        e12 = np.sum(e1 * e2, axis=1)
        e13 = np.sum(e1 * e3, axis=1)
        e14 = np.sum(e1 * e4, axis=1)
        e15 = np.sum(e1 * e5, axis=1)
        e23 = np.sum(e2 * e3, axis=1)
        e25 = np.sum(e2 * e5, axis=1)
        e26 = np.sum(e2 * e6, axis=1)
        e34 = np.sum(e3 * e4, axis=1)
        e36 = np.sum(e3 * e6, axis=1)
        # compute entries for A (negations occur when one edge direction is flipped)
        # these can be computed multiple ways
        # basically for ij, take opposing edge (call it Ek) and two edges from the
        # starting point of Ek to point i (=El) and to point j (=Em), then these are of
        # the scheme:   (El * Ek)  (Em * Ek) - (El * Em) (Ek * Ek)
        # where * is vector dot product
        a12 = (-e36 * e26 + e23 * e66) / vol
        a13 = (-e15 * e25 + e12 * e55) / vol
        a14 = (e23 * e26 - e36 * e22) / vol
        a23 = (-e14 * e34 + e13 * e44) / vol
        a24 = (e13 * e34 - e14 * e33) / vol
        a34 = (-e14 * e13 + e11 * e34) / vol
        # compute diagonals (from row sum = 0)
        a11 = -a12 - a13 - a14
        a22 = -a12 - a23 - a24
        a33 = -a13 - a23 - a34
        a44 = -a14 - a24 - a34
        # stack columns to assemble data
        local_a = np.column_stack(
            (
                a12,
                a12,
                a23,
                a23,
                a13,
                a13,
                a14,
                a14,
                a24,
                a24,
                a34,
                a34,
                a11,
                a22,
                a33,
                a44,
            )
        ).reshape(-1)
        i = np.column_stack(
            (t1, t2, t2, t3, t3, t1, t1, t4, t2, t4, t3, t4, t1, t2, t3, t4)
        ).reshape(-1)
        j = np.column_stack(
            (t2, t1, t3, t2, t1, t3, t4, t1, t4, t2, t4, t3, t1, t2, t3, t4)
        ).reshape(-1)
        local_a = local_a / 6.0
        # Construct sparse matrix:
        # a = sparse.csr_matrix((local_a, (i, j)))
        a = sparse.csc_matrix((local_a.astype(dtype, copy=False), (i, j)), dtype=dtype)
        if not lump:
            # create b matrix data (account for that vol is 6 times tet volume)
            bii = vol / 60.0
            bij = vol / 120.0
            local_b = np.column_stack(
                (
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bij,
                    bii,
                    bii,
                    bii,
                    bii,
                )
            ).reshape(-1).astype(dtype, copy=False)
            b = sparse.csc_matrix((local_b, (i, j)), dtype=dtype)
        else:
            # when lumping put all onto diagonal (volume/4 for each vertex)
            bii = vol / 24.0
            local_b = np.column_stack((bii, bii, bii, bii)).reshape(-1).astype(dtype, copy=False)
            i = np.column_stack((t1, t2, t3, t4)).reshape(-1)
            b = sparse.csc_matrix((local_b, (i, i)), dtype=dtype)
        return a, b

    @staticmethod
    def _fem_voxels(
        vox, lump: bool = False, dtype: np.dtype = np.float64
    ) -> tuple[sparse.csc_matrix, sparse.csc_matrix]:
        r"""Compute the 2 sparse symmetric matrices of the Laplace-Beltrami operator for a voxel mesh.

        The 2 sparse symmetric matrices are computed for a given voxel mesh
        using the linear finite element method (Neumann boundary condition).

        Parameters
        ----------
        vox : object
            Voxel mesh object with vertices (v) and voxel indices (t).
        lump : bool, default=False
            If True, ``B`` should be lumped (diagonal).
        dtype : numpy.dtype, default=np.float64
            Data type for the output matrices. Defaults to ``np.float64`` for numerical stability.

        Returns
        -------
        A : scipy.sparse.csc_matrix
            Sparse symmetric positive semi-definite stiffness matrix, shape (n, n).
        B : scipy.sparse.csc_matrix
            Sparse symmetric positive definite mass matrix, shape (n, n).

        Notes
        -----
        This static method can be used to solve:

        * Sparse generalized Eigenvalue problem: ``A x = lambda B x``
        * Poisson equation: ``A x = B f`` (where f is function on mesh vertices)
        * Laplace equation: ``A x = 0``

        Or to model the operator's action on a vector ``x``: ``y = B\(Ax)``.
        """
        # Ensure dtype is a numpy dtype object
        dtype = np.dtype(dtype)

        # Inputs:   v - vertices : list of lists of 3 floats
        #           t - voxels   : list of lists of 8 int of indices (>=0) into v array
        #                          Ordering: base counter-clockwise, then top counter-
        #                          clockwise when looking from above
        #
        # Outputs:  A - sparse sym. (n x n) positive semi definite numpy matrix
        #           B - sparse sym. (n x n) positive definite numpy matrix (inner
        #               product)
        tnum = vox.t.shape[0]
        # Linear local matrices on unit voxel
        tb = (
            np.array(
                [
                    [8.0, 4.0, 2.0, 4.0, 4.0, 2.0, 1.0, 2.0],
                    [4.0, 8.0, 4.0, 2.0, 2.0, 4.0, 2.0, 1.0],
                    [2.0, 4.0, 8.0, 4.0, 1.0, 2.0, 4.0, 2.0],
                    [4.0, 2.0, 4.0, 8.0, 2.0, 1.0, 2.0, 4.0],
                    [4.0, 2.0, 1.0, 2.0, 8.0, 4.0, 2.0, 4.0],
                    [2.0, 4.0, 2.0, 1.0, 4.0, 8.0, 4.0, 2.0],
                    [1.0, 2.0, 4.0, 2.0, 2.0, 4.0, 8.0, 4.0],
                    [2.0, 1.0, 2.0, 4.0, 4.0, 2.0, 4.0, 8.0],
                ]
            )
            / 216.0
        )
        x = 1.0 / 9.0
        y = 1.0 / 18.0
        z = 1.0 / 36.0
        ta00 = np.array(
            [
                [x, -x, -y, y, y, -y, -z, z],
                [-x, x, y, -y, -y, y, z, -z],
                [-y, y, x, -x, -z, z, y, -y],
                [y, -y, -x, x, z, -z, -y, y],
                [y, -y, -z, z, x, -x, -y, y],
                [-y, y, z, -z, -x, x, y, -y],
                [-z, z, y, -y, -y, y, x, -x],
                [z, -z, -y, y, y, -y, -x, x],
            ]
        )
        ta11 = np.array(
            [
                [x, y, -y, -x, y, z, -z, -y],
                [y, x, -x, -y, z, y, -y, -z],
                [-y, -x, x, y, -z, -y, y, z],
                [-x, -y, y, x, -y, -z, z, y],
                [y, z, -z, -y, x, y, -y, -x],
                [z, y, -y, -z, y, x, -x, -y],
                [-z, -y, y, z, -y, -x, x, y],
                [-y, -z, z, y, -x, -y, y, x],
            ]
        )
        ta22 = np.array(
            [
                [x, y, z, y, -x, -y, -z, -y],
                [y, x, y, z, -y, -x, -y, -z],
                [z, y, x, y, -z, -y, -x, -y],
                [y, z, y, x, -y, -z, -y, -x],
                [-x, -y, -z, -y, x, y, z, y],
                [-y, -x, -y, -z, y, x, y, z],
                [-z, -y, -x, -y, z, y, x, y],
                [-y, -z, -y, -x, y, z, y, x],
            ]
        )
        # here we assume all voxels have the same dimensions (side lengths)
        v0 = vox.v[vox.t[0, 0], :]
        v1 = vox.v[vox.t[0, 1], :]
        v2 = vox.v[vox.t[0, 3], :]
        v3 = vox.v[vox.t[0, 4], :]
        v1mv0 = v1 - v0
        v2mv0 = v2 - v0
        v3mv0 = v3 - v0
        g11 = np.sum(v1mv0 * v1mv0)
        g22 = np.sum(v2mv0 * v2mv0)
        g33 = np.sum(v3mv0 * v3mv0)
        vol = np.sqrt(g11 * g22 * g33)
        a0 = 1.0 / g11
        a1 = 1.0 / g22
        a2 = 1.0 / g33
        if lump:
            local_b = (vol / 8.0) * np.ones([8, 8])
        else:
            local_b = tb * vol
        local_a = vol * (a0 * ta00 + a1 * ta11 + a2 * ta22)
        local_b = np.repeat(local_b[np.newaxis, :, :], tnum, axis=0).reshape(-1).astype(dtype, copy=False)
        local_a = np.repeat(local_a[np.newaxis, :, :], tnum, axis=0).reshape(-1).astype(dtype, copy=False)
        # Construct row and col indices.
        i = np.array([np.tile(x, (8, 1)) for x in vox.t]).reshape(-1)
        j = np.array([np.transpose(np.tile(x, (8, 1))) for x in vox.t]).reshape(-1)
        # Construct sparse matrix:
        a = sparse.csc_matrix((local_a, (i, j)), dtype=dtype)
        b = sparse.csc_matrix((local_b, (i, j)), dtype=dtype)
        return a, b

    def eigs(
        self,
        k: int = 10,
        sigma: float = -0.01,
        which: str = "LM",
        v0: np.ndarray | None = None,
        mode: str = "normal",
        rng: int | np.random.Generator | None = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Compute the linear finite-element method Laplace-Beltrami spectrum.

        Parameters
        ----------
        k : int, default=10
            The number of eigenvalues and eigenvectors desired. ``k`` must be
            smaller than ``N`` (number of vertices). It is not possible to
            compute all eigenvectors of a matrix.
        sigma : float, default=-0.01
            Shift value for the shift-invert mode. The solver finds eigenvalues
            near ``sigma``. The default small negative value works well for
            finding the smallest non-negative Laplacian eigenvalues. Adjust if
            convergence issues occur. The returned eigenvalues are always sorted
            in ascending order regardless of ``sigma``.
        which : str, default="LM"
            Which ``k`` eigenvalues to find. With shift-invert (``sigma`` set),
            ``"LM"`` selects the ``k`` eigenvalues of the original problem
            closest to ``sigma`` — this is the standard choice for computing
            the smallest Laplacian eigenvalues. Other options accepted by
            ``scipy.sparse.linalg.eigsh`` are ``"SM"``, ``"LA"``, ``"SA"``,
            and ``"BE"``.
        v0 : np.ndarray of shape (n_vertices,), default=None
            Starting vector for the ARPACK iteration. Providing a fixed vector
            makes results reproducible. If ``None``, ARPACK uses a random
            starting vector seeded by ``rng``.
        mode : str, default="normal"
            Shift-invert mode passed to ``scipy.sparse.linalg.eigsh``.
            ``"normal"`` is the standard choice for Laplacian spectra.
            Other valid values are ``"buckling"`` and ``"cayley"``.
        rng : int or numpy.random.Generator, default=None
            Seed or generator used to produce a reproducible starting vector
            when ``v0`` is ``None``. An integer seed is the most convenient
            choice, e.g. ``rng=0``.
            When ``scipy.sparse.linalg.eigsh`` exposes an ``rng`` parameter,
            both ``v0`` and ``rng`` are forwarded directly to it, which owns
            all consistency checking. Otherwise the behaviour is replicated
            locally: ``numpy.random.default_rng(rng)`` is used to generate a
            starting vector with ``uniform(-1, 1)`` (matching scipy's own
            initialisation); ``rng`` is ignored when ``v0`` is provided.

        Returns
        -------
        eigenvalues : np.ndarray
            Array of k eigenvalues, shape (k,), sorted in ascending order.
            For closed meshes or Neumann boundary condition with the default
            small negative ``sigma``, ``0`` will be the first eigenvalue
            (with constant eigenvector).
        eigenvectors : np.ndarray
            Array representing the k eigenvectors, shape (n_vertices, k).
            The column ``eigenvectors[:, i]`` is the eigenvector corresponding
            to ``eigenvalues[i]``.
        """
        from scipy.sparse.linalg import LinearOperator

        if _EIGSH_SUPPORTS_RNG:
            # eigsh supports rng natively: pass v0 and rng verbatim and let
            # eigsh own all consistency checking (v0 takes precedence over rng).
            start_kwargs: dict = {"v0": v0, "rng": rng}
        else:
            # eigsh has no rng parameter: replicate its behaviour locally.
            # Only generate v0 from rng when no explicit v0 is provided.
            if v0 is None and rng is not None:
                v0 = np.random.default_rng(rng).uniform(
                    -1.0, 1.0, self.stiffness.shape[0]
                ).astype(self.stiffness.dtype)
            start_kwargs = {"v0": v0}

        if self.use_cholmod:
            logger.info("Solver: Cholesky decomposition from scikit-sparse cholmod ...")
            chol = self.sksparse.cholmod.cholesky(self.stiffness - sigma * self.mass)
            op_inv = LinearOperator(
                matvec=chol,
                shape=self.stiffness.shape,
                dtype=self.stiffness.dtype,
            )
        else:
            from scipy.sparse.linalg import splu

            logger.info("Solver: spsolve (LU decomposition) ...")
            # turns out it is much faster to use cholesky and pass operator
            lu = splu(self.stiffness - sigma * self.mass)
            op_inv = LinearOperator(
                matvec=lu.solve,
                shape=self.stiffness.shape,
                dtype=self.stiffness.dtype,
            )
        eigenvalues, eigenvectors = _eigsh(
            self.stiffness,
            k,
            self.mass,
            sigma=sigma,
            which=which,
            mode=mode,
            OPinv=op_inv,
            **start_kwargs,
        )
        # eigsh with shift-invert does not guarantee sorted output (especially
        # for sigma values far from 0). Always sort ascending for consistency.
        sort_idx = np.argsort(eigenvalues)
        return eigenvalues[sort_idx], eigenvectors[:, sort_idx]

    def poisson(
        self,
        h: float | np.ndarray = 0.0,
        dtup: tuple = (),
        ntup: tuple = (),
    ) -> np.ndarray:
        """Solver for the Poisson equation with boundary conditions.

        This solver is based on the ``A`` and ``B`` Laplace matrices where
        ``A x = B h`` and ``A`` is a sparse symmetric positive semi-definite
        matrix of shape ``(n, n)`` and B is a sparse symmetric positive
        definite matrix of shape ``(n, n)``.

        Parameters
        ----------
        h : float or np.ndarray, default=0.0
            Right hand side, can be a scalar, a 1-D array of shape
            ``(n_vertices,)``, or a 2-D array of shape
            ``(n_vertices, n_functions)`` to solve for multiple functions
            simultaneously.  The default ``0.0`` corresponds to the Laplace
            equation ``A x = 0``.
        dtup : tuple, default=()
            Dirichlet boundary condition as a tuple containing the index and
            data arrays of same length. The default, an empty tuple,
            corresponds to no Dirichlet condition.
        ntup : tuple, default=()
            Neumann boundary condition as a tuple containing the index and
            data arrays of same length. The default, an empty tuple,
            corresponds to Neumann on all boundaries.

        Returns
        -------
        np.ndarray
            Array with vertex values of the solution, shape ``(n_vertices,)``
            for a scalar or 1-D input, or ``(n_vertices, n_functions)`` for a
            2-D input.

        Raises
        ------
        ValueError
            If input matrices are not square or have different dimensions.
            If h is not scalar or array matching matrix dimensions.
            If dtup or ntup don't contain exactly 2 arrays.
            If dtup indices are not unique.
            If dtup or ntup arrays have mismatched lengths.
            If matrix format is not CSC or CSR.

        Notes
        -----
        ``A`` and ``B`` are obtained via ``computeAB`` for either triangle
        or tetrahedral mesh.
        """
        # check matrices
        dim = self.stiffness.shape[0]
        dtype = self.stiffness.dtype
        if self.stiffness.shape != self.mass.shape or self.stiffness.shape[1] != dim:
            raise ValueError(
                "Error: Square input matrices should have same number of rows and "
                "columns."
            )
        # create vector/matrix h
        if np.isscalar(h):
            h = np.full((dim, 1), h, dtype=dtype)
        else:
            h = np.asarray(h, dtype=dtype)
            if h.ndim == 1:
                if h.size != dim:
                    raise ValueError(
                        "h should be either scalar or column vector with row num of A"
                    )
                h = h[:, np.newaxis]
            elif h.ndim == 2:
                if h.shape[0] != dim:
                    raise ValueError(
                        "h should be either scalar or array with first dim matching A"
                    )
            else:
                raise ValueError(
                    "h should be either scalar or 1-D/2-D array"
                )
        # number of right-hand sides
        n_rhs = h.shape[1]
        scalar_rhs = n_rhs == 1  # remember whether caller passed 1-D / scalar

        # create vector d
        didx = []
        dvec = []
        ddat = []
        if dtup:
            if len(dtup) != 2:
                raise ValueError("dtup should contain index and data arrays")
            didx = dtup[0]
            ddat = dtup[1]
            if np.unique(didx).size != len(didx):
                raise ValueError("dtup indices need to be unique")
            if not (len(didx) > 0 and len(didx) == len(ddat)):
                raise ValueError(
                    "dtup should contain index and data arrays (same lengths > 0)"
                )
            # broadcast Dirichlet values across all rhs columns
            dvec = sparse.csc_matrix(
                (np.tile(ddat, n_rhs),
                 (np.tile(didx, n_rhs),
                  np.repeat(np.arange(n_rhs), len(didx)))),
                (dim, n_rhs), dtype=dtype
            )

        # create vector n
        nvec = 0
        if ntup:
            if len(ntup) != 2:
                raise ValueError("ntup should contain index and data arrays")
            nidx = ntup[0]
            ndat = ntup[1]
            if not (len(nidx) > 0 and len(nidx) == len(ndat)):
                raise ValueError(
                    "ntup should contain index and data arrays (same lengths > 0)"
                )
            nvec = sparse.csc_matrix(
                (np.tile(ndat, n_rhs),
                 (np.tile(nidx, n_rhs),
                  np.repeat(np.arange(n_rhs), len(nidx)))),
                (dim, n_rhs), dtype=dtype
            )
        # compute right hand side
        mass = self.mass.astype(dtype, copy=False)
        b = mass * (h - nvec)
        if len(didx) > 0:
            b = b - self.stiffness * dvec
        # remove Dirichlet Nodes
        mask = []
        if len(didx) > 0:
            mask = np.full(dim, True, dtype=bool)
            mask[didx] = False
            b = b[mask]
            # we need to keep A sparse and do col and row slicing
            # only on the right format:
            if self.stiffness.getformat() == "csc":
                a = self.stiffness[:, mask].tocsr()
                a = a[mask, :]
                a = a.tocsc()
            elif self.stiffness.getformat() == "csr":
                a = self.stiffness[mask, :].tocsr()
                a = a[:, mask]
            else:
                raise ValueError("A matrix needs to be sparse CSC or CSR")
        else:
            a = self.stiffness
        # solve A x = b  (both splu.solve and cholmod accept 2-D b natively)
        logger.debug("Matrix format now: %s", a.getformat())
        if self.use_cholmod:
            logger.info("Solver: Cholesky decomposition from scikit-sparse cholmod ...")
            chol = self.sksparse.cholmod.cholesky(a)
            x = chol(b.astype(dtype))
        else:
            from scipy.sparse.linalg import splu

            logger.info("Solver: spsolve (LU decomposition) ...")
            lu = splu(a)
            x = lu.solve(b.astype(dtype))
        # pad Dirichlet nodes back in
        if len(didx) > 0:
            xfull = np.zeros((dim, n_rhs), dtype=dtype)
            xfull[mask, :] = x
            xfull[didx, :] = dvec[didx, :].toarray()
            x = xfull
        # squeeze back to 1-D if the caller passed a scalar or 1-D rhs
        if scalar_rhs:
            x = np.squeeze(np.array(x))
        else:
            x = np.array(x)
        return x
