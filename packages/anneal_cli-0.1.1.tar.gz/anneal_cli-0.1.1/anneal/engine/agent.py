"""Agent invoker — supports Claude Code subprocess mode and API mode.

Dispatches based on AgentConfig.mode to either shell out to Claude Code
or call an OpenAI-compatible chat completions endpoint directly.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import signal
from pathlib import Path

from anneal.engine.client import compute_cost, make_client, strip_provider_prefix
from anneal.engine.types import AgentConfig, AgentInvocationResult, DomainTier

logger = logging.getLogger(__name__)


class AgentInvocationError(Exception):
    """Base error for agent invocation failures."""


class AgentTimeoutError(AgentInvocationError):
    """Agent exceeded time budget."""


def _extract_hypothesis(text: str) -> str | None:
    """Extract hypothesis text after '## Hypothesis' header."""
    match = re.search(
        r"## Hypothesis\s*\n(.*?)(?=\n## |\Z)", text, re.DOTALL
    )
    if match:
        content = match.group(1).strip()
        return content if content else None
    return None


def _extract_tags(text: str) -> list[str]:
    """Extract comma-separated tags after '## Tags' header."""
    match = re.search(r"## Tags\s*\n(.*?)(?=\n## |\Z)", text, re.DOTALL)
    if match:
        raw = match.group(1).strip()
        if raw:
            return [tag.strip() for tag in raw.split(",") if tag.strip()]
    return []


# Backward compatibility aliases (gate scripts import these)
_make_api_client = make_client
_compute_cost = compute_cost


class AgentInvoker:
    """Invokes a mutation agent via Claude Code subprocess or direct API call."""

    async def invoke(
        self,
        config: AgentConfig,
        prompt: str,
        worktree_path: Path,
        time_budget_seconds: int,
        deployment_mode: bool = False,
    ) -> AgentInvocationResult:
        if config.mode == "claude_code":
            return await self._invoke_claude_code(
                config, prompt, worktree_path, time_budget_seconds,
                deployment_mode=deployment_mode,
            )
        elif config.mode == "api":
            return await self._invoke_api(config, prompt, worktree_path, time_budget_seconds)
        else:
            raise AgentInvocationError(f"Unknown agent mode: {config.mode}")

    async def invoke_deployment(
        self,
        config: AgentConfig,
        prompt: str,
        worktree_path: Path,
        time_budget_seconds: int,
    ) -> AgentInvocationResult:
        """Invoke agent in deployment mode — read-only, no file modifications.

        The agent outputs proposed changes as text only.
        """
        return await self.invoke(
            config, prompt, worktree_path, time_budget_seconds,
            deployment_mode=True,
        )

    async def invoke_meta(
        self,
        config: AgentConfig,
        meta_prompt: str,
        worktree_path: Path,
        time_budget_seconds: int,
        program_md_path: Path,
    ) -> AgentInvocationResult:
        """Invoke agent to mutate program.md instead of the artifact.

        Uses a special prompt that instructs the agent to modify program.md.
        Only Edit tool is allowed, scoped to the program.md file.
        """
        content = program_md_path.read_text()
        full_prompt = (
            "You are meta-optimizing. Instead of modifying the artifact, "
            f"modify the program.md file at {program_md_path} to improve "
            f"the optimization strategy. Current program.md:\n{content}"
            f"\n\n{meta_prompt}"
        )

        if config.mode == "claude_code":
            return await self._invoke_claude_code(
                config, full_prompt, worktree_path, time_budget_seconds,
                meta_mode=True,
            )
        elif config.mode == "api":
            return await self._invoke_api(
                config, full_prompt, worktree_path, time_budget_seconds,
            )
        else:
            raise AgentInvocationError(f"Unknown agent mode: {config.mode}")

    async def _invoke_claude_code(
        self,
        config: AgentConfig,
        prompt: str,
        worktree_path: Path,
        time_budget_seconds: int,
        deployment_mode: bool = False,
        meta_mode: bool = False,
    ) -> AgentInvocationResult:
        if meta_mode:
            allowed_tools = "Edit"
        elif deployment_mode:
            allowed_tools = "Read"
        else:
            allowed_tools = "Edit,Write"
        assert "Bash" not in allowed_tools, (
            "Bash must never appear in --allowedTools"
        )

        cmd = [
            "claude",
            "-p",
            "--output-format", "json",
            "--no-session-persistence",
            "--allowedTools", allowed_tools,
            "--max-budget-usd", str(config.max_budget_usd),
            "--model", config.model,
        ]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(worktree_path.resolve()),
            start_new_session=True,
        )

        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(input=prompt.encode()),
                timeout=time_budget_seconds,
            )
        except asyncio.TimeoutError:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except ProcessLookupError:
                pass
            raise AgentTimeoutError(
                f"Agent exceeded time budget of {time_budget_seconds}s"
            )

        stderr_text = stderr_bytes.decode(errors="replace")

        if proc.returncode != 0:
            raise AgentInvocationError(
                f"Claude Code exited with code {proc.returncode}: {stderr_text}"
            )

        stdout_text = stdout_bytes.decode(errors="replace")

        try:
            response = json.loads(stdout_text)
        except json.JSONDecodeError as exc:
            raise AgentInvocationError(
                f"Invalid JSON response from Claude Code: {exc}"
            ) from exc

        cost_usd = float(response.get("total_cost_usd", response.get("cost_usd", 0.0)))
        usage = response.get("usage", {})
        input_tokens = int(usage.get("input_tokens", 0))
        output_tokens = int(usage.get("output_tokens", 0))
        raw_output = response.get("result", "")

        hypothesis = _extract_hypothesis(raw_output)
        hypothesis_source: str = "agent" if hypothesis is not None else "synthesized"
        tags = _extract_tags(raw_output)

        return AgentInvocationResult(
            success=True,
            cost_usd=cost_usd,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            hypothesis=hypothesis,
            hypothesis_source=hypothesis_source,
            tags=tags,
            raw_output=raw_output,
        )

    async def _invoke_api(
        self,
        config: AgentConfig,
        prompt: str,
        worktree_path: Path,
        time_budget_seconds: int,
    ) -> AgentInvocationResult:
        client = make_client(config.model)
        api_model = strip_provider_prefix(config.model)

        try:
            response = await asyncio.wait_for(
                client.chat.completions.create(
                    model=api_model,
                    temperature=config.temperature,
                    messages=[{"role": "user", "content": prompt}],
                ),
                timeout=time_budget_seconds,
            )
        except asyncio.TimeoutError:
            raise AgentTimeoutError(
                f"API agent exceeded time budget of {time_budget_seconds}s"
            )

        raw_output = response.choices[0].message.content or ""

        usage = response.usage
        input_tokens = usage.prompt_tokens if usage else 0
        output_tokens = usage.completion_tokens if usage else 0
        cost_usd = compute_cost(config.model, input_tokens, output_tokens)

        hypothesis = _extract_hypothesis(raw_output)
        hypothesis_source: str = "agent" if hypothesis is not None else "synthesized"
        tags = _extract_tags(raw_output)

        return AgentInvocationResult(
            success=True,
            cost_usd=cost_usd,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            hypothesis=hypothesis,
            hypothesis_source=hypothesis_source,
            tags=tags,
            raw_output=raw_output,
        )
