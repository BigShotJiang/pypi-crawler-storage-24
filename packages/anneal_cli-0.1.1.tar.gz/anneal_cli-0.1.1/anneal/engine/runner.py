"""Experiment runner — state machine orchestrating single experiment cycles.

Wires together GitEnvironment, AgentInvoker, EvalEngine, GreedySearch,
Registry, and scope enforcement into the per-experiment cycle described
in the system design.
"""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from anneal.engine.agent import AgentInvocationError, AgentInvoker, AgentTimeoutError
from anneal.engine.context import build_target_context
from anneal.engine.environment import GitEnvironment
from anneal.engine.eval import EvalEngine, EvalError
from anneal.engine.knowledge import KnowledgeStore
from anneal.engine.learning_pool import LearningPool, extract_learning
from anneal.engine.notifications import NotificationManager
from anneal.engine.registry import Registry
from anneal.engine.safety import pre_experiment_check
from anneal.engine.scope import enforce_scope, load_scope, verify_scope_hash
from anneal.engine.search import GreedySearch, SearchStrategy
from anneal.engine.types import (
    DeterministicEval,
    Direction,
    DomainTier,
    EvalConfig,
    ExperimentRecord,
    OptimizationTarget,
    Outcome,
    RunnerState,
)

logger = logging.getLogger(__name__)

DIVERGENCE_WARNING = 0.10   # 10%
DIVERGENCE_CRITICAL = 0.25  # 25%


class ScopeIntegrityError(Exception):
    """Raised when scope.yaml hash has drifted since registration."""


class ExperimentRunner:
    """Orchestrates single experiment cycles and experiment loops for a target."""

    def __init__(
        self,
        git: GitEnvironment,
        agent_invoker: AgentInvoker,
        eval_engine: EvalEngine,
        search: GreedySearch | SearchStrategy,
        registry: Registry,
        repo_root: Path | None = None,
        knowledge: KnowledgeStore | None = None,
        notifications: NotificationManager | None = None,
        learning_pool: LearningPool | None = None,
    ) -> None:
        self._git = git
        self._agent = agent_invoker
        self._eval = eval_engine
        self._search = search
        self._registry = registry
        self._repo_root = repo_root
        self._knowledge = knowledge
        self._notifications = notifications
        self._learning_pool = learning_pool
        self._stop_flags: set[str] = set()
        self._stop_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Stop flag (thread-safe)
    # ------------------------------------------------------------------

    def request_stop(self, target_id: str) -> None:
        """Signal the runner to stop after the current experiment."""
        with self._stop_lock:
            self._stop_flags.add(target_id)

    def is_stop_requested(self, target_id: str) -> bool:
        with self._stop_lock:
            return target_id in self._stop_flags

    def _clear_stop(self, target_id: str) -> None:
        with self._stop_lock:
            self._stop_flags.discard(target_id)

    # ------------------------------------------------------------------
    # Single experiment cycle
    # ------------------------------------------------------------------

    async def run_one(self, target: OptimizationTarget) -> ExperimentRecord:
        """Run a single experiment: context -> mutate -> validate -> eval -> decide -> log."""
        worktree = Path(target.worktree_path)
        start_time = time.monotonic()
        experiment_id = str(uuid.uuid4())
        cost_usd = 0.0

        # 1. Record pre-experiment state
        pre_experiment_sha = await self._git.rev_parse(worktree, "HEAD")

        # 2. Verify scope integrity (scope lives in repo root, not worktree)
        base = self._repo_root if self._repo_root else worktree
        scope_path = base / target.scope_path
        if not verify_scope_hash(scope_path, target.scope_hash):
            raise ScopeIntegrityError(
                f"scope.yaml hash mismatch for target {target.id}. "
                f"Re-register with: anneal re-register --target {target.id}"
            )
        scope = load_scope(scope_path)

        # Read artifact content for prompt building and stochastic eval
        artifact_content = self._read_artifacts(worktree, target.artifact_paths)

        # Snapshot pre-agent git status to distinguish agent changes from pre-existing content
        pre_agent_status = set(
            path for _, path in await self._git.status_porcelain(worktree)
        )

        # Load recent history and knowledge context (opt-in per target)
        # Gate 3 validated that knowledge context injection does not improve
        # convergence at small scale. Structured logging (append_record,
        # consolidation) is always active; context injection is opt-in.
        history: list[ExperimentRecord] = []
        knowledge_context = ""
        if self._knowledge and target.inject_knowledge_context:
            history = self._knowledge.load_records(limit=10)
            knowledge_context = self._knowledge.get_context()

        prompt, context_tokens = build_target_context(
            target=target,
            worktree_path=worktree,
            repo_root=self._repo_root or worktree,
            history=history,
            knowledge_context=knowledge_context,
        )
        # F6: Use deployment-mode invocation for DEPLOYMENT-tier targets
        try:
            if target.domain_tier is DomainTier.DEPLOYMENT:
                agent_result = await self._agent.invoke_deployment(
                    target.agent_config,
                    prompt,
                    worktree,
                    target.time_budget_seconds,
                )
                # Approval gate: require callback for DEPLOYMENT targets
                if target.approval_callback is None:
                    raise ValueError(
                        f"DEPLOYMENT target {target.id} requires approval_callback. "
                        f"Set approval_callback during registration."
                    )
                if not target.approval_callback(agent_result.raw_output):
                        duration = time.monotonic() - start_time
                        return ExperimentRecord(
                            id=experiment_id,
                            target_id=target.id,
                            git_sha=pre_experiment_sha,
                            pre_experiment_sha=pre_experiment_sha,
                            timestamp=datetime.now(tz=timezone.utc),
                            hypothesis=agent_result.hypothesis or "Deployment change rejected",
                            hypothesis_source=agent_result.hypothesis_source,
                            mutation_diff_summary="",
                            score=target.baseline_score,
                            score_ci_lower=None,
                            score_ci_upper=None,
                            raw_scores=None,
                            baseline_score=target.baseline_score,
                            outcome=Outcome.DISCARDED,
                            failure_mode="approval_rejected",
                            duration_seconds=duration,
                            tags=agent_result.tags,
                            learnings="",
                            cost_usd=agent_result.cost_usd,
                            bootstrap_seed=0,
                        )
            else:
                agent_result = await self._agent.invoke(
                    target.agent_config,
                    prompt,
                    worktree,
                    target.time_budget_seconds,
                )
        except AgentTimeoutError as exc:
            duration = time.monotonic() - start_time
            # KILLED recovery: clean up index.lock, restore worktree
            await self._handle_killed(worktree, pre_experiment_sha)
            return ExperimentRecord(
                id=experiment_id,
                target_id=target.id,
                git_sha=pre_experiment_sha,
                pre_experiment_sha=pre_experiment_sha,
                timestamp=datetime.now(tz=timezone.utc),
                hypothesis="Agent timed out",
                hypothesis_source="synthesized",
                mutation_diff_summary="",
                score=target.baseline_score,
                score_ci_lower=None,
                score_ci_upper=None,
                raw_scores=None,
                baseline_score=target.baseline_score,
                outcome=Outcome.KILLED,
                failure_mode=str(exc),
                duration_seconds=duration,
                tags=[],
                learnings="",
                cost_usd=0.0,
                bootstrap_seed=0,
            )
        except AgentInvocationError as exc:
            duration = time.monotonic() - start_time
            await self._safe_restore(worktree, pre_experiment_sha)
            return ExperimentRecord(
                id=experiment_id,
                target_id=target.id,
                git_sha=pre_experiment_sha,
                pre_experiment_sha=pre_experiment_sha,
                timestamp=datetime.now(tz=timezone.utc),
                hypothesis="Agent invocation failed",
                hypothesis_source="synthesized",
                mutation_diff_summary="",
                score=target.baseline_score,
                score_ci_lower=None,
                score_ci_upper=None,
                raw_scores=None,
                baseline_score=target.baseline_score,
                outcome=Outcome.CRASHED,
                failure_mode=str(exc),
                duration_seconds=duration,
                tags=[],
                learnings="",
                cost_usd=0.0,
                bootstrap_seed=0,
            )

        cost_usd += agent_result.cost_usd
        hypothesis = agent_result.hypothesis or "No hypothesis provided"
        hypothesis_source = agent_result.hypothesis_source
        tags = agent_result.tags

        # 4. Validate scope — only check changes the agent made (delta from pre-agent state)
        _INTERNAL_FILES = {".anneal-status", ".anneal.lock"}
        git_status = [
            (code, path) for code, path in await self._git.status_porcelain(worktree)
            if path not in _INTERNAL_FILES and path not in pre_agent_status
        ]
        scope_result = await enforce_scope(worktree, scope, git_status)

        logger.info(
            "Scope check for %s: status=%s valid=%s violated=%s all_blocked=%s",
            target.id,
            git_status,
            scope_result.valid_paths,
            scope_result.violated_paths,
            scope_result.all_blocked,
        )

        if scope_result.all_blocked:
            duration = time.monotonic() - start_time
            # Reset all violating files
            await self._reset_violated(worktree, scope_result.violated_paths, git_status)
            await self._git.clean_untracked(worktree)
            return ExperimentRecord(
                id=experiment_id,
                target_id=target.id,
                git_sha=pre_experiment_sha,
                pre_experiment_sha=pre_experiment_sha,
                timestamp=datetime.now(tz=timezone.utc),
                hypothesis=hypothesis,
                hypothesis_source=hypothesis_source,
                mutation_diff_summary="",
                score=target.baseline_score,
                score_ci_lower=None,
                score_ci_upper=None,
                raw_scores=None,
                baseline_score=target.baseline_score,
                outcome=Outcome.BLOCKED,
                failure_mode=f"All changes violated scope: {scope_result.violated_paths}",
                duration_seconds=duration,
                tags=tags,
                learnings="",
                cost_usd=cost_usd,
                bootstrap_seed=0,
            )

        # Reset violations, keep valid edits
        if scope_result.has_violations:
            await self._reset_violated(worktree, scope_result.violated_paths, git_status)
            logger.warning(
                "Scope violations reset for target %s: %s",
                target.id,
                scope_result.violated_paths,
            )

        # 5. Commit valid edits (skip if agent made no changes)
        if not scope_result.valid_paths:
            duration = time.monotonic() - start_time
            return ExperimentRecord(
                id=experiment_id,
                target_id=target.id,
                git_sha=pre_experiment_sha,
                pre_experiment_sha=pre_experiment_sha,
                timestamp=datetime.now(tz=timezone.utc),
                hypothesis=hypothesis,
                hypothesis_source=hypothesis_source,
                mutation_diff_summary="",
                score=target.baseline_score,
                score_ci_lower=None,
                score_ci_upper=None,
                raw_scores=None,
                baseline_score=target.baseline_score,
                outcome=Outcome.BLOCKED,
                failure_mode="Agent made no file changes",
                duration_seconds=duration,
                tags=tags,
                learnings="",
                cost_usd=cost_usd,
                bootstrap_seed=0,
            )

        commit_sha = await self._git.commit(
            worktree,
            f"hypothesis: {hypothesis}",
            scope_result.valid_paths,
        )

        # Re-read artifact content after mutation for stochastic eval
        artifact_content = self._read_artifacts(worktree, target.artifact_paths)

        # 5b. Fast constraint pre-check (before expensive eval)
        if target.eval_config.constraint_commands:
            fast_results = await self._eval.check_constraints(
                worktree, target.eval_config, artifact_content,
            )
            for name, passed, actual in fast_results:
                if not passed:
                    duration = time.monotonic() - start_time
                    await self._git.reset_hard(worktree, pre_experiment_sha)
                    logger.warning("Fast constraint %s failed for target %s: actual=%.4f", name, target.id, actual)
                    early_record = ExperimentRecord(
                        id=experiment_id,
                        target_id=target.id,
                        git_sha=pre_experiment_sha,
                        pre_experiment_sha=pre_experiment_sha,
                        timestamp=datetime.now(tz=timezone.utc),
                        hypothesis=hypothesis,
                        hypothesis_source=hypothesis_source,
                        mutation_diff_summary="",
                        score=target.baseline_score,
                        score_ci_lower=None,
                        score_ci_upper=None,
                        raw_scores=None,
                        baseline_score=target.baseline_score,
                        outcome=Outcome.DISCARDED,
                        failure_mode=f"constraint_violated:{name}",
                        duration_seconds=duration,
                        tags=tags,
                        learnings="",
                        cost_usd=cost_usd,
                        bootstrap_seed=0,
                        agent_model=target.agent_config.model,
                    )
                    if self._learning_pool is not None:
                        self._learning_pool.add(extract_learning(early_record, source_target=target.id))
                    return early_record

        # 5c. Multi-fidelity pre-filter (cheap deterministic stages before expensive eval)
        if target.eval_config.fidelity_stages:
            for stage in target.eval_config.fidelity_stages:
                stage_config = EvalConfig(
                    metric_name=f"fidelity_{stage.name}",
                    direction=target.eval_config.direction,
                    deterministic=DeterministicEval(
                        run_command=stage.run_command,
                        parse_command=stage.parse_command,
                        timeout_seconds=stage.timeout_seconds,
                    ),
                )
                try:
                    stage_result = await self._eval.evaluate(
                        worktree, stage_config, artifact_content,
                    )
                except EvalError as exc:
                    logger.warning("Fidelity stage %s failed: %s", stage.name, exc)
                    continue  # Skip failed stages, don't block

                if target.eval_config.direction is Direction.HIGHER_IS_BETTER:
                    passed = stage_result.score >= stage.min_pass_score
                else:
                    passed = stage_result.score <= stage.min_pass_score

                if not passed:
                    duration = time.monotonic() - start_time
                    await self._git.reset_hard(worktree, pre_experiment_sha)
                    logger.info(
                        "Fidelity stage %s rejected mutation for %s: score=%.4f (min=%.4f)",
                        stage.name, target.id, stage_result.score, stage.min_pass_score,
                    )
                    fidelity_record = ExperimentRecord(
                        id=experiment_id,
                        target_id=target.id,
                        git_sha=pre_experiment_sha,
                        pre_experiment_sha=pre_experiment_sha,
                        timestamp=datetime.now(tz=timezone.utc),
                        hypothesis=hypothesis,
                        hypothesis_source=hypothesis_source,
                        mutation_diff_summary="",
                        score=stage_result.score,
                        score_ci_lower=None,
                        score_ci_upper=None,
                        raw_scores=None,
                        baseline_score=target.baseline_score,
                        outcome=Outcome.DISCARDED,
                        failure_mode=f"fidelity_stage:{stage.name}",
                        duration_seconds=duration,
                        tags=tags,
                        learnings="",
                        cost_usd=cost_usd,
                        bootstrap_seed=0,
                        agent_model=target.agent_config.model,
                    )
                    if self._learning_pool is not None:
                        self._learning_pool.add(extract_learning(fidelity_record, source_target=target.id))
                    return fidelity_record

        # 6. Evaluate
        try:
            eval_result = await self._eval.evaluate(
                worktree,
                target.eval_config,
                artifact_content,
            )
        except EvalError as exc:
            duration = time.monotonic() - start_time
            await self._safe_restore(worktree, pre_experiment_sha)
            return ExperimentRecord(
                id=experiment_id,
                target_id=target.id,
                git_sha=pre_experiment_sha,
                pre_experiment_sha=pre_experiment_sha,
                timestamp=datetime.now(tz=timezone.utc),
                hypothesis=hypothesis,
                hypothesis_source=hypothesis_source,
                mutation_diff_summary="",
                score=target.baseline_score,
                score_ci_lower=None,
                score_ci_upper=None,
                raw_scores=None,
                baseline_score=target.baseline_score,
                outcome=Outcome.CRASHED,
                failure_mode=str(exc),
                duration_seconds=duration,
                tags=tags,
                learnings="",
                cost_usd=cost_usd,
                bootstrap_seed=0,
            )

        cost_usd += eval_result.cost_usd

        # 7. Decide: keep or discard
        stochastic_conf = target.eval_config.stochastic
        confidence = stochastic_conf.confidence_level if stochastic_conf else 0.95

        if isinstance(self._search, GreedySearch) and self._knowledge:
            experiments_in_window = self._knowledge.record_count() % self._knowledge.CONSOLIDATION_INTERVAL
            window_size = self._knowledge.CONSOLIDATION_INTERVAL
            adjusted_alpha = GreedySearch._adjusted_alpha(
                1 - confidence, experiments_in_window, window_size,
            )
            confidence = 1 - adjusted_alpha

        if (
            target.eval_config.stochastic is not None
            and (not target.baseline_raw_scores)
        ):
            logger.info(
                "Cold-start for stochastic target %s: accepting first evaluation as baseline",
                target.id,
            )
            keep = True
        else:
            keep = self._search.should_keep(
                eval_result,
                target.baseline_score,
                target.baseline_raw_scores or None,
                target.eval_config.direction,
                target.eval_config.min_improvement_threshold,
                confidence,
            )

        # F2: Check constraints before finalizing KEEP
        constraint_failure: str | None = None
        if keep:
            constraint_results = await self._eval.check_constraints(
                worktree, target.eval_config, artifact_content,
            )
            for name, passed, actual in constraint_results:
                if not passed:
                    constraint_failure = f"constraint_violated:{name}"
                    logger.warning(
                        "Constraint %s failed for target %s: actual=%.4f",
                        name, target.id, actual,
                    )
                    break

        if keep and constraint_failure is None:
            outcome = Outcome.KEPT
            # Update baseline in target and persist
            target.baseline_score = eval_result.score
            if eval_result.raw_scores is not None:
                target.baseline_raw_scores = list(eval_result.raw_scores)
            self._registry.update_target(target)
            git_sha = commit_sha
        else:
            outcome = Outcome.DISCARDED
            await self._git.reset_hard(worktree, pre_experiment_sha)
            git_sha = pre_experiment_sha

        duration = time.monotonic() - start_time

        # 8. Build ExperimentRecord
        record = ExperimentRecord(
            id=experiment_id,
            target_id=target.id,
            git_sha=git_sha,
            pre_experiment_sha=pre_experiment_sha,
            timestamp=datetime.now(tz=timezone.utc),
            hypothesis=hypothesis,
            hypothesis_source=hypothesis_source,
            mutation_diff_summary="",
            score=eval_result.score,
            score_ci_lower=eval_result.ci_lower,
            score_ci_upper=eval_result.ci_upper,
            raw_scores=eval_result.raw_scores,
            baseline_score=target.baseline_score,
            outcome=outcome,
            failure_mode=constraint_failure,
            duration_seconds=duration,
            tags=tags,
            learnings="",
            cost_usd=cost_usd,
            bootstrap_seed=0,
            agent_model=target.agent_config.model,
            criterion_names=eval_result.criterion_names,
            per_criterion_scores=eval_result.per_criterion_scores,
        )

        # 9. Persist to knowledge store + check consolidation
        if self._knowledge:
            self._knowledge.append_record(record)
            self._knowledge.update_index(record)
            self._knowledge.consolidate_if_due()

        # F5: Extract and store cross-project learning
        if self._learning_pool is not None:
            learning = extract_learning(
                record, source_target=target.id,
            )
            self._learning_pool.add(learning)

        return record

    # ------------------------------------------------------------------
    # Experiment loop
    # ------------------------------------------------------------------

    async def run_loop(
        self,
        target: OptimizationTarget,
        max_experiments: int | None = None,
        stop_score: float | None = None,
        on_experiment: Callable[[ExperimentRecord], None] | None = None,
    ) -> list[ExperimentRecord]:
        """Run experiments in a loop until stopped."""
        self._clear_stop(target.id)
        records: list[ExperimentRecord] = []
        consecutive_failures = 0
        kept_count = 0
        consecutive_no_kept = 0

        while True:
            # Check stop conditions
            if self.is_stop_requested(target.id):
                logger.info("Stop requested for target %s", target.id)
                break

            # Check for .stop file (from CLI `anneal stop`)
            stop_file = Path(target.knowledge_path) / ".stop"
            if stop_file.exists():
                stop_file.unlink()
                logger.info("Stop file detected for target %s", target.id)
                break

            if max_experiments is not None and len(records) >= max_experiments:
                break

            if stop_score is not None and target.baseline_score >= stop_score:
                break

            if consecutive_failures >= target.max_consecutive_failures:
                logger.warning(
                    "Target %s halted: %d consecutive failures",
                    target.id,
                    consecutive_failures,
                )
                await self._write_status(target, RunnerState.HALTED, records[-1] if records else None)
                if self._notifications:
                    await self._notifications.notify_state(
                        target.id, RunnerState.HALTED,
                        f"{consecutive_failures} consecutive failures",
                        score=target.baseline_score,
                        experiment_count=len(records),
                    )
                break

            # Pre-experiment safety checks
            safe, reason = pre_experiment_check(
                target, Path(target.worktree_path), context_tokens=0,
            )
            if not safe:
                logger.warning("Target %s paused: %s", target.id, reason)
                await self._write_status(target, RunnerState.PAUSED, records[-1] if records else None)
                if self._notifications:
                    await self._notifications.notify_state(
                        target.id, RunnerState.PAUSED, reason,
                        score=target.baseline_score,
                        experiment_count=len(records),
                    )
                break

            # Run one experiment
            await self._write_status(target, RunnerState.RUNNING, records[-1] if records else None)
            record = await self.run_one(target)
            records.append(record)

            # Track consecutive failures
            if record.outcome in (Outcome.KILLED, Outcome.CRASHED):
                consecutive_failures += 1
            else:
                consecutive_failures = 0

            # Track kept count for held-out eval and plateau detection
            if record.outcome is Outcome.KEPT:
                kept_count += 1
                consecutive_no_kept = 0
            else:
                consecutive_no_kept += 1

            # F1: Held-out evaluation at regular intervals
            held_out_interval = target.eval_config.held_out_interval
            stochastic_conf = target.eval_config.stochastic
            if (
                record.outcome is Outcome.KEPT
                and stochastic_conf is not None
                and stochastic_conf.held_out_prompts
                and kept_count % held_out_interval == 0
            ):
                worktree = Path(target.worktree_path)
                artifact_content = self._read_artifacts(worktree, target.artifact_paths)
                try:
                    held_out_result = await self._eval.evaluate_held_out(
                        worktree, target.eval_config, artifact_content,
                    )
                    record.held_out_score = held_out_result.score
                    logger.info(
                        "Held-out eval for %s: score=%.4f (main=%.4f)",
                        target.id, held_out_result.score, record.score,
                    )
                    if record.score > 0:
                        divergence = abs(held_out_result.score - record.score) / record.score
                        if divergence > DIVERGENCE_CRITICAL:
                            logger.error(
                                "CRITICAL: Held-out diverges %.0f%% from main for %s. "
                                "Evaluator may be compromised.",
                                divergence * 100, target.id,
                            )
                        elif divergence > DIVERGENCE_WARNING:
                            logger.warning(
                                "Held-out diverges %.0f%% from main for %s",
                                divergence * 100, target.id,
                            )
                except EvalError as exc:
                    logger.warning("Held-out eval failed for %s: %s", target.id, exc)

            # F8: Meta-optimization on plateau
            meta_m = min(target.max_consecutive_failures, 10)
            if (
                target.meta_depth > 0
                and consecutive_no_kept >= meta_m
                and len(records) >= meta_m
            ):
                logger.info(
                    "Plateau detected for %s (%d consecutive non-KEPT). Triggering meta-optimization.",
                    target.id, consecutive_no_kept,
                )
                recent_scores = [r.score for r in records[-meta_m:]]
                trajectory = ", ".join(f"{s:.4f}" for s in recent_scores)
                meta_prompt = (
                    f"The optimization for target '{target.id}' has plateaued. "
                    f"No improvements in the last {consecutive_no_kept} experiments. "
                    f"Recent score trajectory: [{trajectory}]. "
                    f"Current baseline: {target.baseline_score:.4f}. "
                    f"Revise the optimization strategy in program.md to break through."
                )
                base = self._repo_root if self._repo_root else Path(target.worktree_path)
                program_md = base / target.knowledge_path / "program.md"
                if program_md.exists():
                    try:
                        await self._agent.invoke_meta(
                            target.agent_config,
                            meta_prompt,
                            Path(target.worktree_path),
                            target.time_budget_seconds,
                            program_md,
                        )
                        logger.info("Meta-optimization completed for %s", target.id)
                        consecutive_no_kept = 0  # Reset plateau counter
                    except (AgentTimeoutError, AgentInvocationError) as exc:
                        logger.warning("Meta-optimization failed for %s: %s", target.id, exc)

            # Callback
            if on_experiment is not None:
                on_experiment(record)

            # Milestone notification
            if self._notifications and record.outcome is Outcome.KEPT:
                await self._notifications.notify_milestone(
                    target.id, kept_count, record.score,
                )

            # Update status
            state = RunnerState.RUNNING
            if record.outcome is Outcome.BLOCKED:
                state = RunnerState.BLOCKED
            elif record.outcome is Outcome.KILLED:
                state = RunnerState.KILLED
            await self._write_status(target, state, record)

        return records

    # ------------------------------------------------------------------
    # Status file
    # ------------------------------------------------------------------

    async def _write_status(
        self,
        target: OptimizationTarget,
        state: RunnerState,
        last_record: ExperimentRecord | None,
    ) -> None:
        """Write .anneal-status JSON file in the worktree."""
        worktree = Path(target.worktree_path)
        status_path = worktree / target.notifications.status_file

        payload = {
            "target_id": target.id,
            "state": state.value,
            "last_score": last_record.score if last_record else target.baseline_score,
            "experiment_count": 0,  # caller tracks; status is a snapshot
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }

        status_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    # ------------------------------------------------------------------
    # Prompt building
    # ------------------------------------------------------------------

    def _build_prompt(
        self,
        target: OptimizationTarget,
        history: list[ExperimentRecord],
    ) -> str:
        """Build prompt from program.md, artifact content, and experiment history."""
        worktree = Path(target.worktree_path)

        # Read program.md if it exists
        program_path = worktree / "targets" / target.id / "program.md"
        if program_path.exists():
            program_content = program_path.read_text(encoding="utf-8")
        else:
            program_content = self._default_program(target)

        # Read artifact content
        artifact_content = self._read_artifacts(worktree, target.artifact_paths)

        # Format recent history (last 5)
        history_text = self._format_history(history[-5:])

        # Knowledge context (retrieved similar experiments + learnings)
        knowledge_context = ""
        if self._knowledge:
            knowledge_context = self._knowledge.get_context()

        # Assemble prompt
        parts = [
            program_content,
            "",
            "## Previous Results",
            "",
            history_text if history_text else "No previous experiments.",
        ]
        if knowledge_context:
            parts.extend(["", knowledge_context])
        parts.extend([
            "",
            "--- ARTIFACT CONTENT ---",
            artifact_content,
        ])

        return "\n".join(parts)

    def _default_program(self, target: OptimizationTarget) -> str:
        """Generate a default program.md prompt when none exists."""
        editable_list = "\n".join(f"- {p}" for p in target.artifact_paths)
        return (
            f"# {target.id} — Optimization Program\n"
            f"\n"
            f"## Your Role\n"
            f"\n"
            f"You are optimizing the artifact files listed below. Your goal is to "
            f"improve the evaluation metric: {target.eval_config.metric_name} "
            f"({target.eval_config.direction.value}).\n"
            f"\n"
            f"## Editable Files\n"
            f"\n"
            f"{editable_list}\n"
            f"\n"
            f"## Constraints\n"
            f"\n"
            f"- Only modify files listed above\n"
            f"- Produce a ## Hypothesis block before making edits\n"
            f"- Produce a ## Tags block with comma-separated mutation categories\n"
        )

    @staticmethod
    def _read_artifacts(worktree: Path, artifact_paths: list[str]) -> str:
        """Read and concatenate artifact file contents from the worktree."""
        parts: list[str] = []
        for rel_path in artifact_paths:
            full_path = worktree / rel_path
            if full_path.exists():
                content = full_path.read_text(encoding="utf-8")
                parts.append(f"### {rel_path}\n\n{content}")
        return "\n\n".join(parts)

    @staticmethod
    def _format_history(records: list[ExperimentRecord]) -> str:
        """Format experiment records for inclusion in the prompt."""
        if not records:
            return ""
        lines: list[str] = []
        for i, rec in enumerate(records, 1):
            lines.append(
                f"{i}. [{rec.outcome.value}] score={rec.score:.4f} "
                f"| hypothesis: {rec.hypothesis}"
            )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Recovery helpers
    # ------------------------------------------------------------------

    async def _reset_violated(
        self,
        worktree: Path,
        violated_paths: list[str],
        git_status: list[tuple[str, str]],
    ) -> None:
        """Reset violated files: checkout tracked files, delete untracked ones."""
        import shutil

        untracked_codes = {"??"}
        status_map = {path: code for code, path in git_status}

        tracked = [p for p in violated_paths if status_map.get(p) not in untracked_codes]
        untracked = [p for p in violated_paths if status_map.get(p) in untracked_codes]

        if tracked:
            await self._git.checkout_paths(worktree, tracked)
        for path in untracked:
            full = worktree / path
            if full.is_dir():
                shutil.rmtree(full)
            elif full.exists():
                full.unlink()

    async def _handle_killed(self, worktree: Path, pre_experiment_sha: str) -> None:
        """State-aware KILLED recovery with integrity verification."""
        await self._git.cleanup_index_lock(worktree)
        await self._git.reset_hard(worktree, pre_experiment_sha)
        await self._git.clean_untracked(worktree)

        # Verify git object integrity
        fsck_ok = await self._git.fsck(worktree)
        if not fsck_ok:
            logger.error(
                "Git object database corruption detected in %s after kill recovery. "
                "Manual repair required: git -C %s fsck --full",
                worktree, worktree,
            )

    async def _safe_restore(self, worktree: Path, pre_experiment_sha: str) -> None:
        """Restore worktree to pre-experiment state on error."""
        await self._git.reset_hard(worktree, pre_experiment_sha)
        await self._git.clean_untracked(worktree)
