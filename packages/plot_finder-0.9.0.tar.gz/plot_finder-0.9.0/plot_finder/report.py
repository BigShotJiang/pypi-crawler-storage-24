from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING

from pydantic import BaseModel

from plot_finder.air import AirQuality
from plot_finder.climate import Climate
from plot_finder.elevation import Elevation
from plot_finder.exceptions import (
    OpenMeteoError,
    OpenWeatherAuthError,
    OverpassError,
)
from plot_finder.gugik import GugikEntry
from plot_finder.kuit import KUIT
from plot_finder.land_use import LandUse
from plot_finder.mpzp import MPZP
from plot_finder.noise import Noise
from plot_finder.pog import POG
from plot_finder.suikzp import SUIKZP
from plot_finder.place import Place
from plot_finder.risks import RiskReport
from plot_finder.sun import SeasonalSun, SunInfo

if TYPE_CHECKING:
    from plot_finder.analyzer import PlotAnalyzer


class PlotReport(BaseModel):
    plot_id: str
    lat: float
    lon: float
    radius: int
    education: list[Place] = []
    finance: list[Place] = []
    transport: list[Place] = []
    infrastructure: list[Place] = []
    green_areas: list[Place] = []
    water: list[Place] = []
    nuisances: list[Place] = []
    air_quality: AirQuality | None = None
    climate: Climate | None = None
    elevation: Elevation | None = None
    sunlight: SunInfo | None = None
    seasonal_sun: SeasonalSun | None = None
    noise: Noise | None = None
    risks: RiskReport | None = None
    mpzp: MPZP | None = None
    suikzp: SUIKZP | None = None
    pog: POG | None = None
    kuit: KUIT | None = None
    land_use: LandUse | None = None
    gugik: list[GugikEntry] | None = None
    geometry: list[list[float]] | None = None


class PlotReporter:
    def __init__(self, analyzer: PlotAnalyzer) -> None:
        self._analyzer = analyzer

    def report(self, for_date: date | None = None) -> PlotReport:
        a = self._analyzer
        data: dict = {
            "plot_id": a.plot.plot_id,
            "lat": a.lat,
            "lon": a.lon,
            "radius": a.radius,
        }

        if a.plot.geom_wkt:
            data["geometry"] = self._geometry_wgs84(a.plot.geom_wkt)

        try:
            places = a.all_places()
            for category in ("education", "finance", "transport", "infrastructure", "green_areas", "water", "nuisances"):
                if places.get(category):
                    data[category] = places[category]
        except OverpassError:
            pass

        try:
            data["air_quality"] = a.air_quality()
        except (OpenWeatherAuthError, Exception):
            pass

        try:
            data["climate"] = a.climate()
        except (OpenMeteoError, Exception):
            pass

        try:
            data["elevation"] = a.elevation()
        except Exception:
            pass

        try:
            data["sunlight"] = a.sunlight(for_date=for_date)
        except Exception:
            pass

        try:
            data["seasonal_sun"] = a.sunlight_seasonal()
        except Exception:
            pass

        try:
            data["noise"] = a.noise()
        except Exception:
            pass

        try:
            data["risks"] = a.risks()
        except Exception:
            pass

        try:
            data["mpzp"] = a.mpzp()
        except Exception:
            pass

        try:
            data["suikzp"] = a.suikzp()
        except Exception:
            pass

        try:
            data["pog"] = a.pog()
        except Exception:
            pass

        try:
            data["kuit"] = a.kuit()
        except Exception:
            pass

        try:
            data["land_use"] = a.land_use()
        except Exception:
            pass

        try:
            data["gugik"] = a.plot.gugik()
        except Exception:
            pass

        return PlotReport(**data)

    @staticmethod
    def _geometry_wgs84(geom_wkt: str) -> list[list[float]]:
        import shapely.wkt
        from pyproj import Transformer

        transformer = Transformer.from_crs("EPSG:2180", "EPSG:4326", always_xy=True)
        geom = shapely.wkt.loads(geom_wkt)
        coords = geom.exterior.coords if hasattr(geom, "exterior") else []
        return [
            [lat, lon]
            for x, y in coords
            for lon, lat in [transformer.transform(x, y)]
        ]
