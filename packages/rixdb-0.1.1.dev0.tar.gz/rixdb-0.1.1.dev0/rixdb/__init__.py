__version__ = "0.1.0.dev0"

raise ImportError(
    "RixDB is currently in development. "
    "Follow https://github.com/Pranav1173/RixDB for updates."
)