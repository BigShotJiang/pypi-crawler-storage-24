# Copyright 2026 The kauldron Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Base data loader."""

import abc
from typing import Optional

from etils import edc
from kauldron.ktyping import PRNGKeyLike
import tensorflow as tf


class DataLoader(abc.ABC):

  def __call__(self, seed: Optional[PRNGKeyLike] = None) -> tf.data.Dataset:
    raise NotImplementedError

  __repr__ = edc.repr
