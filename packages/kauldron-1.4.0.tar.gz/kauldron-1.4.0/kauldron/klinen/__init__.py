# Copyright 2026 The kauldron Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Wrapper aound `flax.linen.Module` to add torch-like API."""

# pylint: disable=g-importing-member
from kauldron.klinen.convert_utils import convert
from kauldron.klinen.intermediate import Intermediate
from kauldron.klinen.layers import Dense
from kauldron.klinen.layers import Dropout
from kauldron.klinen.layers import Sequential
from kauldron.klinen.module import Module
# pylint: enable=g-importing-member
