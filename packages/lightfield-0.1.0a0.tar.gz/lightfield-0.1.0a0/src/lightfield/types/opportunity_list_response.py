# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import builtins
from typing import TYPE_CHECKING, Dict, List, Union, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["OpportunityListResponse", "Data", "DataFields", "DataRelationships"]


class DataFields(BaseModel):
    value: Union[
        str,
        float,
        bool,
        List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        None,
    ] = None

    value_type: str = FieldInfo(alias="valueType")


class DataRelationships(BaseModel):
    entity: str

    relationship_type: str = FieldInfo(alias="relationshipType")

    values: List[str]


class Data(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    fields: Dict[str, DataFields]

    link_to_object: Optional[str] = FieldInfo(alias="linkToObject", default=None)

    object: str

    relationships: Dict[str, DataRelationships]

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[builtins.object]], Dict[str, builtins.object], None]],
                Dict[str, Union[str, float, bool, List[Optional[builtins.object]], Dict[str, builtins.object], None]],
                None,
            ],
        ] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(
            self, attr: str
        ) -> Union[
            str,
            float,
            bool,
            List[Union[str, float, bool, List[Optional[builtins.object]], Dict[str, builtins.object], None]],
            Dict[str, Union[str, float, bool, List[Optional[builtins.object]], Dict[str, builtins.object], None]],
            None,
        ]: ...
    else:
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[builtins.object]], Dict[str, builtins.object], None]],
                Dict[str, Union[str, float, bool, List[Optional[builtins.object]], Dict[str, builtins.object], None]],
                None,
            ],
        ]


class OpportunityListResponse(BaseModel):
    data: List[Data]

    object: str

    total_count: int
