# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "ContactUpdateParams",
    "Fields",
    "FieldsSystemName",
    "Relationships",
    "RelationshipsSystemAccountContact",
    "Relationship",
]


class ContactUpdateParams(TypedDict, total=False):
    fields: Fields

    relationships: Relationships


class FieldsSystemName(TypedDict, total=False):
    first_name: Annotated[str, PropertyInfo(alias="firstName")]

    last_name: Annotated[str, PropertyInfo(alias="lastName")]


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    system_email: Optional[SequenceNotStr[str]]

    system_name: Optional[FieldsSystemName]

    system_profile_photo_url: Annotated[Optional[str], PropertyInfo(alias="system_profilePhotoUrl")]


class RelationshipsSystemAccountContact(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class Relationship(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class Relationships(TypedDict, total=False, extra_items=Relationship):  # type: ignore[call-arg]
    system_account_contact: Annotated[RelationshipsSystemAccountContact, PropertyInfo(alias="system_account-contact")]
