# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["OpportunityCreateParams", "Fields", "Relationships"]


class OpportunityCreateParams(TypedDict, total=False):
    fields: Required[Fields]

    relationships: Required[Relationships]


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    system_name: Required[str]

    system_stage: Required[str]


class Relationships(TypedDict, total=False, extra_items=Union[str, SequenceNotStr[str]]):  # type: ignore[call-arg]
    system_account: Required[Union[str, SequenceNotStr[str]]]

    system_champion: Union[str, SequenceNotStr[str]]

    system_evaluator: Union[str, SequenceNotStr[str]]

    system_owner: Union[str, SequenceNotStr[str]]
