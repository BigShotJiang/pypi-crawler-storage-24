# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import TypedDict

from .._types import SequenceNotStr

__all__ = [
    "OpportunityUpdateParams",
    "Fields",
    "Relationships",
    "RelationshipsSystemAccount",
    "RelationshipsSystemChampion",
    "RelationshipsSystemEvaluator",
    "RelationshipsSystemOwner",
    "Relationship",
]


class OpportunityUpdateParams(TypedDict, total=False):
    fields: Fields

    relationships: Relationships


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    system_name: Optional[str]

    system_stage: Optional[str]


class RelationshipsSystemAccount(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class RelationshipsSystemChampion(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class RelationshipsSystemEvaluator(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class RelationshipsSystemOwner(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class Relationship(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]


class Relationships(TypedDict, total=False, extra_items=Relationship):  # type: ignore[call-arg]
    system_account: RelationshipsSystemAccount

    system_champion: RelationshipsSystemChampion

    system_evaluator: RelationshipsSystemEvaluator

    system_owner: RelationshipsSystemOwner
