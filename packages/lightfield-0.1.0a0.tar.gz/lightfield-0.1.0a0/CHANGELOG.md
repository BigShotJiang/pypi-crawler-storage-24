# Changelog

## 0.1.0-alpha (2026-03-07)

Full Changelog: [v0.0.1...v0.1.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.0.1...v0.1.0-alpha)

### Features

* **api:** manual update - split up endpoints and harden schemas ([ddfa8da](https://github.com/Lightfld/lightfield-python/commit/ddfa8da2714c874d4e4bd617cf24353a128f23cc))
* **api:** manual updates ([d699c8c](https://github.com/Lightfld/lightfield-python/commit/d699c8c22c87a33ca0a9d761bc67e77f84ea17af))
* **api:** manual updates ([807c1ac](https://github.com/Lightfld/lightfield-python/commit/807c1ac1e1b5bfa50b89a5172ad001533738bb65))
* **api:** manual updates ([6d6db6c](https://github.com/Lightfld/lightfield-python/commit/6d6db6c14f97d4ae2565ad1ce13132ab7163795d))


### Chores

* configure new SDK language ([078c58b](https://github.com/Lightfld/lightfield-python/commit/078c58b97819ca30245a35851cea1c1d89b95893))
* configure new SDK language ([2e251a4](https://github.com/Lightfld/lightfield-python/commit/2e251a4b900102671a8004b8c344bc97edd5401d))
* update SDK settings ([8ac4102](https://github.com/Lightfld/lightfield-python/commit/8ac4102852bd4a46f1af4f3070c114f563483905))
* update SDK settings ([2740ec3](https://github.com/Lightfld/lightfield-python/commit/2740ec3eba755516cb5db0e44d96dca81407ea2d))
* update SDK settings ([5725ac1](https://github.com/Lightfld/lightfield-python/commit/5725ac17fd2fbbb10a5721a0b03b0e584db41f27))
* update SDK settings ([c3d8388](https://github.com/Lightfld/lightfield-python/commit/c3d83883a671e7945d713f18f58be4cee4bccdcd))
* update SDK settings ([ff1d73c](https://github.com/Lightfld/lightfield-python/commit/ff1d73c367590d0a578519bce74c49fc608303bb))
* update SDK settings ([3bd4e46](https://github.com/Lightfld/lightfield-python/commit/3bd4e466acd4555e98e7049ca0c1fc17e7f62b4a))
* update SDK settings ([b1bed0e](https://github.com/Lightfld/lightfield-python/commit/b1bed0efbd5ec5100e12bc87b17d32546c7bb255))
* update SDK settings ([5bdad3c](https://github.com/Lightfld/lightfield-python/commit/5bdad3c9d8713ac4a996224aaf707c7847be379f))
