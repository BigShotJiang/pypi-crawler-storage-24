"""
Setup script for django-google-places-autocomplete.
"""

import os
import re
import setuptools


def read_package_variable(key, filename='__init__.py'):
    """Read the value of a variable from the package without importing it."""
    path = os.path.join(os.path.dirname(__file__), 'django_google_places_autocomplete', filename)
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            m = re.match(rf"^{key}\s*=\s*['\"]([^'\"]+)['\"]", line.strip())
            if m:
                return m.group(1)
    return None


setuptools.setup(
    name=read_package_variable('__project__'),
    version=read_package_variable('__version__'),
    author='FlavienLouis',
    author_email='flouis@reptile.tech',
    description='Django widget and field for Google Places Autocomplete (address autofill)',
    long_description=open('README.md', 'r', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/FlavienLouis/django-google-places-autocomplete',
    packages=setuptools.find_packages(),
    include_package_data=True,
    package_data={
        'django_google_places_autocomplete': [
            'static/django_google_places_autocomplete/js/*.js',
        ],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Framework :: Django',
        'Framework :: Django :: 2.2',
        'Framework :: Django :: 3.2',
        'Framework :: Django :: 4.0',
        'Framework :: Django :: 4.1',
        'Framework :: Django :: 4.2',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Internet :: WWW/HTTP',
    ],
    python_requires='>=3.7',
    install_requires=[
        'Django>=2.2',
    ],
)
