"""
Django app config for django_google_places_autocomplete.
Add to INSTALLED_APPS to enable static file discovery (optional if static path is used).
"""

from django.apps import AppConfig


class DjangoGooglePlacesAutocompleteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_google_places_autocomplete'
    verbose_name = 'Django Google Places Autocomplete'
