/**
 * Google Places Autocomplete - inputs with data-google-places="true"
 */
(function() {
    'use strict';

    function componentByType(components, type) {
        var i, j, t, comp;
        if (!components || !components.length) {
            return '';
        }
        for (i = 0; i < components.length; i++) {
            comp = components[i];
            t = comp.types || [];
            for (j = 0; j < t.length; j++) {
                if (t[j] === type) {
                    return comp.long_name || '';
                }
            }
        }
        return '';
    }

    function formatAddressFromComponents(place, includeCountry) {
        var c = place.address_components;
        var line1, locality, admin1, postal, country, parts, cityLine;

        if (!c || !c.length) {
            return place.formatted_address || '';
        }

        line1 = [componentByType(c, 'street_number'), componentByType(c, 'route')]
            .filter(Boolean).join(' ').trim();
        locality = componentByType(c, 'locality') || componentByType(c, 'sublocality_level_1') ||
            componentByType(c, 'sublocality');
        admin1 = componentByType(c, 'administrative_area_level_1');
        postal = componentByType(c, 'postal_code');
        country = componentByType(c, 'country');

        parts = [];
        if (line1) {
            parts.push(line1);
        }
        if (locality) {
            parts.push(locality);
        }
        cityLine = [];
        if (admin1) {
            cityLine.push(admin1);
        }
        if (postal) {
            cityLine.push(postal);
        }
        if (cityLine.length) {
            parts.push(cityLine.join(' '));
        }
        if (includeCountry && country) {
            parts.push(country);
        }
        return parts.join(', ');
    }

    function setPlaceIdField(input, placeId) {
        var idAttr = input.getAttribute('data-place-id-field');
        var hidden;
        if (!idAttr) {
            return;
        }
        hidden = document.getElementById(idAttr);
        if (hidden) {
            hidden.value = placeId || '';
        }
    }

    function bindInputClearPlaceId(input) {
        input.addEventListener('input', function(e) {
            if (e && e.isTrusted === false) {
                return;
            }
            setPlaceIdField(input, '');
        });
    }

    function attachAutocomplete(input) {
        var countryRestriction = input.dataset.countryRestriction ||
            input.getAttribute('data-country-restriction') || 'ca';
        var options = { types: ['address'] };
        var includeCountry;
        var fromComponents;
        var autocomplete;
        var includeCountryAttr;
        var fromComponentsAttr;

        if (countryRestriction) {
            options.componentRestrictions = { country: countryRestriction };
        }

        includeCountryAttr = input.getAttribute('data-include-country');
        includeCountry = includeCountryAttr === '1' || includeCountryAttr === 'true';
        fromComponentsAttr = input.getAttribute('data-format-from-components');
        fromComponents = fromComponentsAttr !== '0' && fromComponentsAttr !== 'false';

        autocomplete = new google.maps.places.Autocomplete(input, options);

        autocomplete.addListener('place_changed', function() {
            var place = autocomplete.getPlace();
            var text;
            var ev;

            if (!place) {
                return;
            }

            if (fromComponents) {
                text = formatAddressFromComponents(place, includeCountry);
            } else {
                text = place.formatted_address || '';
            }

            if (text) {
                input.value = text;
            }

            if (place.place_id) {
                setPlaceIdField(input, place.place_id);
            }

            try {
                input.dispatchEvent(new Event('change', { bubbles: true }));
            } catch (err) {
                ev = document.createEvent('HTMLEvents');
                ev.initEvent('change', true, true);
                input.dispatchEvent(ev);
            }
        });

        if (input.getAttribute('data-place-id-field')) {
            bindInputClearPlaceId(input);
        }
    }

    function initializeAutocomplete() {
        var addressInputs;
        var i;
        var input;

        if (typeof google === 'undefined' || !google.maps || !google.maps.places) {
            return;
        }

        addressInputs = document.querySelectorAll('input[data-google-places="true"]');

        for (i = 0; i < addressInputs.length; i++) {
            input = addressInputs[i];
            if (input.dataset.initialized === 'true') {
                continue;
            }

            attachAutocomplete(input);
            input.dataset.initialized = 'true';
        }
    }

    function runWhenReady() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function onReady() {
                document.removeEventListener('DOMContentLoaded', onReady);
                if (typeof google !== 'undefined' && google.maps && google.maps.places) {
                    initializeAutocomplete();
                } else {
                    window.addEventListener('load', initializeAutocomplete);
                }
            });
        } else if (typeof google !== 'undefined' && google.maps && google.maps.places) {
            initializeAutocomplete();
        } else {
            window.addEventListener('load', initializeAutocomplete);
        }
    }

    runWhenReady();
})();
