"""
Django Google Places Autocomplete - Widget and field for address autocomplete.
"""

default_app_config = 'django_google_places_autocomplete.apps.DjangoGooglePlacesAutocompleteConfig'

__version__ = '0.1.1'
__project__ = 'django-google-places-autocomplete'

from .fields import GooglePlacesAddressField
from .validation import require_places_selection
from .widgets import GooglePlacesAutocompleteWidget

__all__ = [
    'GooglePlacesAddressField',
    'GooglePlacesAutocompleteWidget',
    'require_places_selection',
]
