"""
Validation helpers for Google Places selection.
"""

from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


def require_places_selection(form, *address_field_names, error_message=None):
    """
    Enforce that non-empty address fields were filled via Places (place_id present).

    For each ``address_field`` in *address_field_names*, expect a companion
    ``CharField`` (usually ``HiddenInput``) named ``{address_field}_place_id``.

    Call from ``Form.clean()`` after ``super().clean()``.

    Args:
        form: Bound form instance (``self`` inside ``clean``).
        *address_field_names: Base field names, e.g. ``'signatory_company_adress'``.
        error_message: Optional custom ``ValidationError`` message.
    """
    message = error_message or _(
        'Please choose an address from the list of suggestions.'
    )
    for fname in address_field_names:
        pid_field = f'{fname}_place_id'
        addr = (form.cleaned_data.get(fname) or '').strip()
        pid = (form.cleaned_data.get(pid_field) or '').strip()
        if addr and not pid:
            form.add_error(fname, ValidationError(message))
