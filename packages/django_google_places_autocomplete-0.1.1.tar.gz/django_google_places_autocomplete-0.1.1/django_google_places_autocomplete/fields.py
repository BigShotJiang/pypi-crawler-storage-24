"""
Google Places Address form field for Django.
"""

from django import forms

from .widgets import GooglePlacesAutocompleteWidget


class GooglePlacesAddressField(forms.CharField):
    """
    Form field with Google Places Autocomplete widget.
    Use for address inputs that should offer Google Places suggestions.
    """

    def __init__(self, country_restriction='ca', widget=None, **kwargs):
        if widget is None:
            widget = GooglePlacesAutocompleteWidget(country_restriction=country_restriction)
        kwargs.setdefault('widget', widget)
        super().__init__(**kwargs)
