"""
Google Places Autocomplete widget for Django forms.
"""

from django import forms
from django.conf import settings


def _get_places_api_key():
    """Return the Google Places API key from settings."""
    return getattr(settings, 'GOOGLE_PLACES_API_KEY', '')


def _get_places_script_url():
    """Build the Google Maps/Places API script URL with API key."""
    api_key = _get_places_api_key()
    if not api_key:
        return None
    lang = getattr(settings, 'LANGUAGE_CODE', 'en')[:2]
    return (
        f'https://maps.googleapis.com/maps/api/js?key={api_key}'
        f'&libraries=places&language={lang}'
    )


class GooglePlacesAutocompleteWidget(forms.TextInput):
    """
    Widget that adds Google Places Autocomplete to address fields.
    Requires GOOGLE_PLACES_API_KEY in Django settings.

    Options:
        country_restriction: ISO country code for suggestions (default 'ca').
        include_country_in_address: Append country name to the filled address
            (default False; set True if you want e.g. '..., Canada').
        format_address_from_components: Build the text from address_components
            so postal_code is included (default True). If False, uses
            Google's formatted_address (postal code may be missing).
        require_place_selection: If True, set data-place-id-field so JS writes
            Google place_id into the companion hidden input id_{name}_place_id.
            Declare a matching CharField(widget=HiddenInput) named {name}_place_id
            and validate with require_places_selection().
    """

    def __init__(
        self,
        country_restriction=None,
        include_country_in_address=False,
        format_address_from_components=True,
        require_place_selection=False,
        attrs=None,
    ):
        self.country_restriction = country_restriction if country_restriction is not None else 'ca'
        self.include_country_in_address = include_country_in_address
        self.format_address_from_components = format_address_from_components
        self.require_place_selection = require_place_selection
        super().__init__(attrs)

    def build_attrs(self, base_attrs, extra_attrs=None):
        attrs = super().build_attrs(base_attrs, extra_attrs)
        attrs['data-google-places'] = 'true'
        attrs['data-country-restriction'] = self.country_restriction or ''
        attrs['data-include-country'] = '1' if self.include_country_in_address else '0'
        attrs['data-format-from-components'] = (
            '1' if self.format_address_from_components else '0'
        )
        if 'autocomplete' not in attrs:
            attrs['autocomplete'] = 'off'
        return attrs

    def render(self, name, value, attrs=None, renderer=None):
        attrs = {} if attrs is None else dict(attrs)
        if self.require_place_selection:
            attrs['data-place-id-field'] = f'id_{name}_place_id'
        return super().render(name, value, attrs, renderer)

    @property
    def media(self):
        script_url = _get_places_script_url()
        js = [script_url] if script_url else []
        js.append('django_google_places_autocomplete/js/google-places-autocomplete.js')
        return forms.Media(js=js)
