"""
MCP Tools exposed by docs-kit:

- search_docs(query, limit=5): Hybrid RAG search. Returns JSON array of {source, chunk_index, score, text}.
- list_sources(): Returns JSON array of all ingested source strings.
- get_collection_info(): Returns JSON object with collection stats.
- get_full_document(source): Returns full reconstructed text of a document.

Tools are registered in server.py via the mcp SDK.
"""
