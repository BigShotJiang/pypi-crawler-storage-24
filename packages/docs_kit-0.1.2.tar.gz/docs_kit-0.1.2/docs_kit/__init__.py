"""docs-kit: Fetch docs, embed locally, expose via MCP for AI agents."""

from docs_kit._version import __version__

__all__ = [
    "__version__",
    "DocsKitAgent",
    "DocsKitConfig",
    "Chunk",
    "Document",
    "RetrievedChunk",
]


def __getattr__(name: str):
    if name == "DocsKitAgent":
        from docs_kit.agent import DocsKitAgent

        return DocsKitAgent
    if name == "DocsKitConfig":
        from docs_kit.core.config import DocsKitConfig

        return DocsKitConfig
    if name in {"Chunk", "Document", "RetrievedChunk"}:
        from docs_kit.core.models import Chunk, Document, RetrievedChunk

        return {
            "Chunk": Chunk,
            "Document": Document,
            "RetrievedChunk": RetrievedChunk,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
