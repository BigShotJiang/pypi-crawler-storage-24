import json
import sys
import tomllib
import unittest
from pathlib import Path
from click.testing import CliRunner
from unittest.mock import patch
from docs_kit.cli.__main__ import cli

FAKE_DOCS_KIT_BIN = "/usr/local/bin/docs-kit"


class FakeDocsKitConfig:
    def __init__(self, data=None):
        self._data = data or {
            "embedding": {"provider": "fastembed", "model": "BAAI/bge-small-en-v1.5"},
            "vector_store": {
                "provider": "qdrant",
                "url": "",
                "collection_name": "knowledge_base",
                "local_path": ".docs-kit/qdrant",
            },
            "ingestion": {"chunk_size": 800, "chunk_overlap": 120, "bm25_model": "Qdrant/bm25"},
            "mcp": {"transport": "stdio", "host": "localhost", "port": 3001},
        }
        vector_store = type("VectorStore", (), {})()
        vector_store.local_path = self._data["vector_store"]["local_path"]
        self.vector_store = vector_store

    def model_dump(self):
        self._data["vector_store"]["local_path"] = self.vector_store.local_path
        return self._data

    @classmethod
    def from_yaml(cls, path):
        import yaml

        with open(path) as f:
            data = yaml.safe_load(f) or {}
        return cls(data)


class TestInstallCmd(unittest.TestCase):

    def test_install_claude_code_creates_settings(self):
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertIn("Installed docs-kit MCP server", result.output)

    def test_install_writes_absolute_command_path(self):
        """Resolved docs-kit binary is written as an absolute path."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                self.assertTrue(settings_file.exists())
                with open(settings_file) as f:
                    data = json.load(f)
                self.assertIn("mcpServers", data)
                self.assertIn("docs-kit", data["mcpServers"])
                entry = data["mcpServers"]["docs-kit"]
                self.assertEqual(entry["command"], str(Path(FAKE_DOCS_KIT_BIN).resolve()))
                self.assertEqual(
                    entry["args"],
                    ["serve", "--config", str((fake_home / ".docs-kit" / "docs-kit.yaml").resolve())],
                )

    def test_install_python_module_fallback_when_no_binary(self):
        """Falls back to sys.executable -m docs_kit when docs-kit is not on PATH."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=None), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                with open(settings_file) as f:
                    data = json.load(f)
                entry = data["mcpServers"]["docs-kit"]
                self.assertEqual(entry["command"], sys.executable)
                self.assertEqual(
                    entry["args"],
                    ["-m", "docs_kit", "serve", "--config", str((fake_home / ".docs-kit" / "docs-kit.yaml").resolve())],
                )

    def test_install_with_config_writes_absolute_config_path(self):
        """--config is resolved to an absolute path in the written settings."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            # Create a real file so Path.resolve() can work on it
            config_file = Path(tmp_dir) / "custom.yaml"
            config_file.write_text("vector_store:\n  local_path: .docs-kit/qdrant\n")
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--config", str(config_file)])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                with open(settings_file) as f:
                    data = json.load(f)
                args = data["mcpServers"]["docs-kit"]["args"]
                # Must be absolute
                self.assertIn("--config", args)
                config_arg = args[args.index("--config") + 1]
                self.assertTrue(Path(config_arg).is_absolute(), f"Expected absolute path, got: {config_arg}")
                self.assertEqual(config_arg, str(config_file.resolve()))

    def test_install_auto_discovers_config_yaml(self):
        """docs-kit.yaml in CWD is auto-discovered and written as absolute --config."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            # Create docs-kit.yaml in CWD (isolated filesystem)
            config_file = Path(tmp_dir) / "docs-kit.yaml"
            config_file.write_text("vector_store:\n  local_path: .docs-kit/qdrant\n")
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"], catch_exceptions=False)
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                with open(settings_file) as f:
                    data = json.load(f)
                args = data["mcpServers"]["docs-kit"]["args"]
                self.assertIn("--config", args)
                config_arg = args[args.index("--config") + 1]
                self.assertTrue(Path(config_arg).is_absolute())

    def test_install_warns_when_no_config_on_global_install(self):
        """Global install bootstraps a user config when no config is present."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertNotIn("Warning", result.output)
                self.assertIn("Created user config", result.output)
                settings_file = fake_home / ".claude" / "settings.json"
                user_config = fake_home / ".docs-kit" / "docs-kit.yaml"
                self.assertTrue(user_config.exists())
                with open(settings_file) as f:
                    data = json.load(f)
                args = data["mcpServers"]["docs-kit"]["args"]
                self.assertIn("--config", args)
                self.assertEqual(args[args.index("--config") + 1], str(user_config.resolve()))

    def test_install_no_warning_on_project_install_without_config(self):
        """--project install does not warn about missing config (project-local is expected)."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            with patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--project"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertNotIn("Warning", result.output)

    def test_install_merges_with_existing_settings(self):
        """Existing mcpServers entries are preserved."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            settings_dir = fake_home / ".claude"
            settings_dir.mkdir(parents=True)
            settings_file = settings_dir / "settings.json"
            settings_file.write_text(json.dumps({
                "mcpServers": {"other-tool": {"command": "other", "args": []}}
            }))
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code"])
                self.assertEqual(result.exit_code, 0, result.output)
                with open(settings_file) as f:
                    data = json.load(f)
                self.assertIn("other-tool", data["mcpServers"])
                self.assertIn("docs-kit", data["mcpServers"])

    def test_install_project_flag_uses_local_path(self):
        """--project flag writes to .claude/settings.json in current dir."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            with patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--project"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = Path(tmp_dir) / ".claude" / "settings.json"
                self.assertTrue(settings_file.exists())

    def test_install_invalid_agent_rejected(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["install", "vscode"])
        self.assertNotEqual(result.exit_code, 0)

    def test_install_codex_writes_toml_config(self):
        """Codex install writes bootstrap config path when no local config exists."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "codex"])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".codex" / "config.toml"
                self.assertTrue(settings_file.exists())
                with open(settings_file, "rb") as f:
                    data = tomllib.load(f)
                self.assertIn("mcp_servers", data)
                self.assertIn("docs-kit", data["mcp_servers"])
                entry = data["mcp_servers"]["docs-kit"]
                self.assertEqual(entry["command"], str(Path(FAKE_DOCS_KIT_BIN).resolve()))
                self.assertEqual(
                    entry["args"],
                    ["serve", "--config", str((fake_home / ".docs-kit" / "docs-kit.yaml").resolve())],
                )

    def test_install_codex_with_config_uses_absolute_path(self):
        """Codex install resolves --config to an absolute path."""
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            config_file = Path(tmp_dir) / "custom.yaml"
            config_file.write_text("vector_store:\n  local_path: .docs-kit/qdrant\n")
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "codex", "--config", str(config_file)])
                self.assertEqual(result.exit_code, 0, result.output)
                settings_file = fake_home / ".codex" / "config.toml"
                with open(settings_file, "rb") as f:
                    data = tomllib.load(f)
                args = data["mcp_servers"]["docs-kit"]["args"]
                self.assertIn("--config", args)
                config_arg = args[args.index("--config") + 1]
                self.assertTrue(Path(config_arg).is_absolute())

    def test_install_codex_aliases_use_same_config(self):
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "codex-desktop"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertIn(".codex/config.toml", result.output)

    def test_install_project_does_not_bootstrap_user_config(self):
        runner = CliRunner()
        with runner.isolated_filesystem() as tmp_dir:
            fake_home = Path(tmp_dir) / "home"
            fake_home.mkdir()
            with patch("docs_kit.cli.commands.Path.home", return_value=fake_home), \
                 patch("docs_kit.cli.commands.shutil.which", return_value=FAKE_DOCS_KIT_BIN), \
                 patch("docs_kit.cli.commands._get_config_class", return_value=FakeDocsKitConfig):
                result = runner.invoke(cli, ["install", "claude-code", "--project"])
                self.assertEqual(result.exit_code, 0, result.output)
                self.assertFalse((fake_home / ".docs-kit" / "docs-kit.yaml").exists())

    def test_install_chatgpt_shows_remote_mcp_guidance(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["install", "chatgpt"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("does not use a local stdio MCP config file", result.output)
        self.assertIn("Settings > Apps/Connectors", result.output)
