# docs-kit

[![PyPI version](https://img.shields.io/pypi/v/docs-kit)](https://pypi.org/project/docs-kit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python](https://img.shields.io/pypi/pyversions/docs-kit)](https://pypi.org/project/docs-kit/)
[![CI](https://github.com/docs-kit/docs-kit/actions/workflows/ci.yml/badge.svg)](https://github.com/docs-kit/docs-kit/actions/workflows/ci.yml)

Fetch docs from GitBook, Mintlify, or local files, embed them locally, and expose retrieval to AI tools over MCP.

No API keys are required for the default local embedding path.

## What it does

- Fetches public docs from GitBook and Mintlify sites via `llms-full.txt` / `llms.txt` (with sitemap.xml fallback for Mintlify)
- Ingests local `.md` and `.txt` files
- Stores vectors in local Qdrant by default
- Serves an MCP server over `stdio` or SSE
- Exposes MCP tools to ingest, remove, and list sources at runtime
- Installs MCP config for supported AI clients

## Install

The recommended install method is **`pipx`** — it puts `docs-kit` on your global PATH without touching your system Python or any project venv:

```bash
pipx install docs-kit
```

Install `pipx` first if you don't have it:

```bash
brew install pipx
pipx ensurepath   # adds ~/.local/bin to PATH
```

This matters for MCP installs. When `docs-kit` is on PATH, `docs-kit install claude-code` writes the absolute binary path into the agent config (e.g. `/Users/you/.local/pipx/venvs/docs-kit/bin/docs-kit`) so the MCP server works from any directory, not just your project folder.

If you install globally with `pipx` and do not have a project yet, `docs-kit install <agent>` will bootstrap a user config at `~/.docs-kit/docs-kit.yaml` and point the MCP entry at it automatically.

Or with plain `pip` (works, but binary won't be on global PATH unless you're in the right venv):

```bash
pip install docs-kit
```

## Quickstart

```bash
# 0. Install (once)
pipx install docs-kit

# 1. Install into your client
docs-kit install codex
docs-kit install claude-code

# 2. Ingest docs (uses ~/.docs-kit/docs-kit.yaml if no local config exists)
docs-kit ingest https://docs.elevenlabs.io

# 3. Check the collection
docs-kit inspect

# 4. Optional: create a project-local config instead
docs-kit init
```

## Commands

### `docs-kit init`

Create a project-local `docs-kit.yaml`.

```bash
docs-kit init
docs-kit init --dir ./sandbox
```

### `docs-kit ingest <path-or-url>`

Ingest a local file, directory, or documentation URL into the vector store. Supports GitBook and Mintlify sites out of the box — auto-detected by default.

```bash
docs-kit ingest ./docs
docs-kit ingest https://docs.example.com
docs-kit ingest https://docs.mintlify-site.com --provider mintlify
docs-kit ingest https://docs.gitbook-site.com --provider gitbook
docs-kit ingest ./docs --recreate
```

`--provider` accepts `auto` (default), `gitbook`, or `mintlify`. In `auto` mode, the fetcher tries `/llms-full.txt` → `/llms.txt` → `/sitemap.xml` in order.

### `docs-kit fetch <url>`

Download GitBook docs as Markdown without ingesting them.

```bash
docs-kit fetch https://docs.example.com
docs-kit fetch https://docs.example.com --output ./downloaded-docs
```

### `docs-kit serve`

Run the MCP server. `stdio` is the default. Use SSE for HTTP clients.

```bash
docs-kit serve
docs-kit serve --transport sse --port 3001
docs-kit serve --config ./docs-kit.yaml
```

Without `--config`, `docs-kit` uses this precedence:
1. `./docs-kit.yaml`
2. `~/.docs-kit/docs-kit.yaml` (auto-created on first global use)

### `docs-kit install <agent>`

Install docs-kit into a supported client config.

```bash
docs-kit install claude-code
docs-kit install codex
docs-kit install claude-code --project
docs-kit install cursor --config ./docs-kit.yaml
```

If you run `docs-kit install <agent>` outside a project and omit `--config`, docs-kit creates `~/.docs-kit/docs-kit.yaml` and installs the MCP server with an absolute `--config` pointing there.

### `docs-kit query <text>`

Run retrieval directly from the CLI.

```bash
docs-kit query "How do I authenticate?"
docs-kit query "getting started" --limit 3
```

### `docs-kit inspect`

Show collection and embedding configuration details.

```bash
docs-kit inspect
docs-kit inspect --config ./docs-kit.yaml
```

### `docs-kit doctor`

Check environment variables, config presence, and Qdrant connectivity.

```bash
docs-kit doctor
docs-kit doctor --config ./docs-kit.yaml
```

### `docs-kit list`

List ingested sources with their ingestion timestamps.

```bash
docs-kit list
docs-kit list --config ./docs-kit.yaml
```

### `docs-kit remove <source>`

Remove an ingested source by URL or file path.

```bash
docs-kit remove https://docs.example.com/page
docs-kit remove ./docs/getting-started.md
```

## MCP Tools

When connected to an MCP client, docs-kit exposes:

| Tool | Description |
|------|-------------|
| `search_docs(query, limit=5)` | Hybrid dense + BM25 retrieval |
| `list_sources()` | List all ingested source URLs/paths |
| `list_ingested_sources()` | List sources with ingestion timestamps |
| `get_collection_info()` | Collection stats (exists, point count) |
| `get_full_document(source)` | Retrieve full stored document by source |
| `ingest_urls(urls, provider="auto")` | Ingest comma-separated URLs at runtime |
| `remove_source(source)` | Remove a source and all its chunks |

## Install Targets

Local config install is supported for:

- `claude-code`
- `claude-desktop`
- `cursor`
- `codex`

Codex aliases:

- `codex-app`

ChatGPT aliases are accepted for guidance only:

- `chatgpt`
- `chatgpt-desktop`

`chatgpt` and `chatgpt-desktop` do not currently use a local stdio config written by this command. The installer prints guidance for the current OpenAI flow, which uses remote MCP apps/connectors in ChatGPT settings.

## Configuration

Project-local `docs-kit.yaml` created by `docs-kit init`:

```yaml
embedding:
  provider: fastembed
  model: BAAI/bge-small-en-v1.5

vector_store:
  provider: qdrant
  local_path: .docs-kit/qdrant
  collection_name: knowledge_base

ingestion:
  chunk_size: 800
  chunk_overlap: 120
  bm25_model: Qdrant/bm25

mcp:
  transport: stdio
  host: localhost
  port: 3001
```

Global installs can also use a user config at `~/.docs-kit/docs-kit.yaml`, with data stored under `~/.docs-kit/qdrant`.

## Supported Sources

| Source | Strategy |
|--------|----------|
| GitBook sites | `/llms-full.txt` → `/llms.txt` |
| Mintlify sites | `/llms-full.txt` → `/llms.txt` → `/sitemap.xml` |
| Local `.md` files | Direct file read |
| Local `.txt` files | Direct file read |

Both GitBook and Mintlify support the [`llms.txt` standard](https://llmstxt.org), so in most cases the same auto strategy works for both. The Mintlify fetcher adds a `/sitemap.xml` fallback for sites where `llms.txt` is disabled.

## Requirements

- Python 3.11–3.13 (3.14+ not yet supported — `onnxruntime` wheels are unavailable for 3.14)
- Disk space for the local embedding model download
- Local Qdrant storage under `.docs-kit/` by default

If your system Python is 3.14, pass an explicit version to pipx:

```bash
pipx install docs-kit --python python3.13
```
