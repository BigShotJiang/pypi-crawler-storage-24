# MUDBASE PYTHON SDK

Auto-generated SDK for MUDBASE API.

## Installation

```bash
pip install mudbase
```

## Usage

```python
from mudbase import Client

client = Client(api_key="YOUR_API_KEY")
users = client.users.list()
```

## Documentation

Full API documentation: https://docs.mudbase.dev

## Support

For issues and questions, visit: https://github.com/mudbase/sdk-python
