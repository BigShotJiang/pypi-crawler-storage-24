# ResourceListLLMModel


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[LLMModel]**](LLMModel.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_llm_model import ResourceListLLMModel

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListLLMModel from a JSON string
resource_list_llm_model_instance = ResourceListLLMModel.from_json(json)
# print the JSON string representation of the object
print(ResourceListLLMModel.to_json())

# convert the object into a dict
resource_list_llm_model_dict = resource_list_llm_model_instance.to_dict()
# create an instance of ResourceListLLMModel from a dict
resource_list_llm_model_from_dict = ResourceListLLMModel.from_dict(resource_list_llm_model_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


