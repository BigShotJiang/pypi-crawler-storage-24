# ResourceListTool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[Tool]**](Tool.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_tool import ResourceListTool

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListTool from a JSON string
resource_list_tool_instance = ResourceListTool.from_json(json)
# print the JSON string representation of the object
print(ResourceListTool.to_json())

# convert the object into a dict
resource_list_tool_dict = resource_list_tool_instance.to_dict()
# create an instance of ResourceListTool from a dict
resource_list_tool_from_dict = ResourceListTool.from_dict(resource_list_tool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


