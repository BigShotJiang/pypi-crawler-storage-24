"""
BitPulse API Schema

This module provides the BitPulse Trace API format for the new simplified
4-field trace record structure.
"""

from typing import Any, Dict

from pydantic import BaseModel, Field


class TraceRecord(BaseModel):
    """
    GraphBit trace record for the new simplified API format.

    Structure: tracing_api_key, traceable_project_name, run_type, run_data.

    - run_type: "WorkFlow" for workflow executions, "LLM Client" for standalone calls.
    - run_data: For workflows, populated by result.get_all_node_response_metadata().
                For standalone LLM calls, built from collected attributes.
    """

    tracing_api_key: str = Field(..., description="API key for BitPulse tracing service (from env)")
    traceable_project_name: str = Field(..., description="Project name for grouping traces (from env)")
    run_type: str = Field("LLM Client", description="Type of run: 'WorkFlow' or 'LLM Client'")
    run_data: Dict[str, Any] = Field(default_factory=dict, description="Run data payload")
