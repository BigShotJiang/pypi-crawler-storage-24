# utils/validation.py or common/validators.py
from typing import Any, Optional, Type


def validate_type(param_name: str, value: Any, expected_type: Type, allow_none: bool = False) -> None:
    """
    Validate that a parameter has the expected type.

    Args:
        param_name: Name of the parameter being validated
        value: The value to validate
        expected_type: The expected type
        allow_none: Whether None is an acceptable value

    Raises:
        TypeError: If value doesn't match expected_type
    """
    if allow_none and value is None:
        return

    if not isinstance(value, expected_type):
        actual_type = type(value).__name__
        expected_name = expected_type.__name__
        none_suffix = " or None" if allow_none else ""
        raise TypeError(f"Expected '{param_name}' to be {expected_name}{none_suffix}, " f"got {actual_type}")


def validate_dict_types(param_name: str, dict_value: Optional[dict], key_type: Type, value_type: Type) -> None:
    """
    Validate that all keys and values in a dict match expected types.

    Args:
        param_name: Name of the parameter being validated
        dict_value: The dict to validate (can be None)
        key_type: Expected type for all keys
        value_type: Expected type for all values

    Raises:
        TypeError: If any key or value doesn't match expected types
    """
    if dict_value is None:
        return

    for key, value in dict_value.items():
        if not isinstance(key, key_type):
            raise TypeError(
                f"Expected all keys in '{param_name}' to be {key_type.__name__}, "
                f"got {type(key).__name__} for key {key!r}"
            )
        if not isinstance(value, value_type):
            raise TypeError(
                f"Expected all values in '{param_name}' to be {value_type.__name__}, "
                f"got {type(value).__name__} for key {key!r}"
            )
