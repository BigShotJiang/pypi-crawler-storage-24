"""Single source of truth for exit codes. Import this everywhere."""
from enum import IntEnum


class ExitCode(IntEnum):
    SUCCESS = 0
    PARTIAL = 1          # Some elements written, some failed
    QUARANTINE = 2       # File rejected before parsing
    UNSUPPORTED = 3      # No parser available for this format
    PARSER_CRASH = 4     # Unrecoverable parser error
    OUTPUT_ERROR = 5     # Cannot write to output path
    CONFIG_ERROR = 6     # Invalid CLI flags/options
