"""
extractor — Production-grade document extraction to versioned RAG-ready JSON/JSONL.

Public API:
    from extractor import extract
    for element in extract("paper.pdf", mode="elements"):
        print(element.element_type, element.section_path, element.text[:80])
"""
from __future__ import annotations

import asyncio
import concurrent.futures
from pathlib import Path
from typing import AsyncIterator, Iterable, Iterator, Literal, overload

from .schema import BaseElement, ChunkRecord, ManifestRecord, ELEMENT_TYPES, ATOMIC_TYPES, RunConfig, SCHEMA_VERSION
from .errors import ExtractorError, ParserError, QuarantineError, UnsupportedFormatError

__version__ = "0.1.0"
__all__ = [
    "extract", "extract_batch", "aextract", "aextract_batch",
    "SCHEMA_VERSION", "__version__",
    "ExtractorError", "ParserError", "QuarantineError", "UnsupportedFormatError",
    "BaseElement", "ChunkRecord", "ManifestRecord",
    "ELEMENT_TYPES", "ATOMIC_TYPES",
    "RunConfig",
]


@overload
def extract(
    source: Path | str,
    mode: Literal["elements"] = ...,
    *,
    chunk_size: int = ...,
    overlap: int = ...,
    strategy: str = ...,
    include_types: list[str] | None = ...,
    exclude_types: list[str] | None = ...,
    tokenizer: str = ...,
    inject_context_prefix: bool = ...,
    parent_size: int = ...,
    child_size: int = ...,
) -> Iterator[BaseElement]: ...

@overload
def extract(
    source: Path | str,
    mode: Literal["chunks", "dual-chunks"],
    *,
    chunk_size: int = ...,
    overlap: int = ...,
    strategy: str = ...,
    include_types: list[str] | None = ...,
    exclude_types: list[str] | None = ...,
    tokenizer: str = ...,
    inject_context_prefix: bool = ...,
    parent_size: int = ...,
    child_size: int = ...,
) -> Iterator[ChunkRecord]: ...


def extract(
    source: str | Path,
    mode: str = "elements",
    chunk_size: int = 512,
    overlap: int = 0,
    strategy: str = "fast",
    include_types: list[str] | None = None,
    exclude_types: list[str] | None = None,
    parent_size: int = 512,
    child_size: int = 128,
) -> Iterator[BaseElement]:
    """
    Extract a document and yield BaseElement records.

    Args:
        source: Path to the source file or URL
        mode: "elements" (raw semantic units), "chunks" (section-aware), or
              "dual-chunks" (paired coarse+fine chunks for ParentDocumentRetriever)
        chunk_size: Maximum tokens per chunk (default 512)
        overlap: Overlap tokens between chunks (default 0, disabled)
        strategy: "fast" | "accurate" | "ocr"
        include_types: Only emit these element types (default: all)
        exclude_types: Suppress these element types
        parent_size: Token budget for coarse (parent) chunks in dual-chunks mode
        child_size: Token budget for fine (child) chunks in dual-chunks mode

    Yields:
        BaseElement records in document order
    """
    from . import pipeline
    yield from pipeline.run(
        path=Path(source),
        mode=mode,
        chunk_size=chunk_size,
        overlap=overlap,
        strategy=strategy,
        include_types=include_types,
        exclude_types=exclude_types,
        parent_size=parent_size,
        child_size=child_size,
    )


def extract_batch(
    sources: Iterable[Path | str],
    *,
    workers: int = 4,
    on_error: Literal["skip", "raise"] = "skip",
    **kwargs,
) -> Iterator[tuple[Path, list[BaseElement] | Exception]]:
    """Extract multiple files in parallel. Yields (path, elements_or_exception) tuples."""
    paths = [Path(s) for s in sources]

    def _extract_one(p: Path) -> tuple[Path, list[BaseElement] | Exception]:
        try:
            return (p, list(extract(p, **kwargs)))
        except Exception as e:
            if on_error == "raise":
                raise
            return (p, e)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_extract_one, p): p for p in paths}
        for future in concurrent.futures.as_completed(futures):
            yield future.result()


async def aextract(
    source: Path | str,
    **kwargs,
) -> AsyncIterator[BaseElement]:
    """Async streaming extraction — wraps extract() to avoid blocking the event loop."""
    queue: asyncio.Queue = asyncio.Queue()

    def _run_sync():
        try:
            for el in extract(source, **kwargs):
                queue.put_nowait(el)
        finally:
            queue.put_nowait(None)  # sentinel

    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, _run_sync)

    while True:
        item = await queue.get()
        if item is None:
            break
        yield item


async def aextract_batch(
    sources: Iterable[Path | str],
    *,
    workers: int = 4,
    **kwargs,
) -> AsyncIterator[tuple[Path, list[BaseElement] | Exception]]:
    """Async batch extraction with concurrency control."""
    semaphore = asyncio.Semaphore(workers)
    paths = [Path(s) for s in sources]

    async def _extract_one(p: Path) -> tuple[Path, list[BaseElement] | Exception]:
        async with semaphore:
            try:
                elements = []
                async for el in aextract(p, **kwargs):
                    elements.append(el)
                return (p, elements)
            except Exception as e:
                return (p, e)

    tasks = [asyncio.create_task(_extract_one(p)) for p in paths]
    for coro in asyncio.as_completed(tasks):
        yield await coro
