"""
Integration adapters for LangChain and LlamaIndex.
Import guards ensure no hard dependency on either framework.
"""
from __future__ import annotations


def get_langchain_loader():
    try:
        from .langchain import ExtractorLoader
        return ExtractorLoader
    except ImportError as e:
        raise ImportError(
            "LangChain not installed. Run: pip install langchain-core"
        ) from e


def get_llamaindex_reader():
    try:
        from .llamaindex import ExtractorReader
        return ExtractorReader
    except ImportError as e:
        raise ImportError(
            "LlamaIndex not installed. Run: pip install llama-index-core"
        ) from e


__all__ = ["get_langchain_loader", "get_llamaindex_reader"]
