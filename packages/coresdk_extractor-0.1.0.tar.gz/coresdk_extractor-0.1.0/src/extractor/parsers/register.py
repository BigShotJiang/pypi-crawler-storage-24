"""
Parser registration — imports all parser implementations and registers them
with the global registry.

Import this module (or call register_all()) once at startup to make all
parsers available via registry.get().
"""
from __future__ import annotations

from ..registry import registry
from .csv import CSVParser
from .docx import DOCXParser
from .epub import EPUBParser
from .html import HTMLParser
from .json_pass import JSONParser
from .markdown import MarkdownParser
from .pdf_digital import PDFDigitalParser
from .pdf_scientific import PDFScientificParser
from .pdf_ocr import PDFOCRParser
from .audio import AudioParser
from .latex import LaTeXParser
from .plaintext import PlaintextParser
from .pptx import PPTXParser
from .xlsx import XLSXParser
from .xml import XMLParser


def register_all() -> None:
    """Register all built-in parsers with the global registry."""
    # PDF
    registry.register("application/pdf", "digital", PDFDigitalParser())
    registry.register("application/pdf", "scientific", PDFScientificParser())
    registry.register("application/pdf", "scanned", PDFOCRParser())

    # Office formats
    registry.register(
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        None,
        DOCXParser(),
    )
    registry.register(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        None,
        XLSXParser(),
    )
    registry.register("application/vnd.ms-excel", None, XLSXParser())
    registry.register(
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        None,
        PPTXParser(),
    )

    # Web / text
    registry.register("text/html", None, HTMLParser())
    registry.register("text/csv", None, CSVParser())
    registry.register("text/plain", None, PlaintextParser())
    registry.register("text/markdown", None, MarkdownParser())
    registry.register("text/x-markdown", None, MarkdownParser())

    # Document formats
    registry.register("application/epub+zip", None, EPUBParser())

    # Data formats
    registry.register("application/json", None, JSONParser())
    registry.register("text/xml", None, XMLParser())
    registry.register("application/xml", None, XMLParser())

    # Scientific / LaTeX
    registry.register("text/x-tex", None, LaTeXParser())
    registry.register("application/x-tex", None, LaTeXParser())

    # Audio
    _audio = AudioParser()
    registry.register("audio/mpeg", None, _audio)
    registry.register("audio/wav", None, _audio)
    registry.register("audio/mp4", None, _audio)
    registry.register("audio/flac", None, _audio)
    registry.register("audio/ogg", None, _audio)


register_all()
