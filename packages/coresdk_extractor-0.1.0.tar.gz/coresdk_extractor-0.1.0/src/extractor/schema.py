"""
Extractor Protocol Schema — Version 1.0.0

All element records emitted by extractor conform to these models.
The element_type field uses the canonical enum defined in ELEMENT_TYPES.
"""
from __future__ import annotations

import hashlib
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

SCHEMA_VERSION = "1.0.0"

# ---------------------------------------------------------------------------
# Element type registry — single source of truth
# ---------------------------------------------------------------------------

ELEMENT_TYPES: set[str] = {
    # Structural
    "structural:title",
    "structural:subtitle",
    "structural:section_header",
    "structural:page_header",
    "structural:page_footer",
    "structural:page_number",
    "structural:divider",
    # Text
    "text:narrative",
    "text:paragraph",
    "text:caption",
    "text:footnote",
    "text:endnote",
    "text:pull_quote",
    "text:admonition",
    "text:sidebar",
    "text:abstract",
    "text:note",
    "text:transcript_segment",
    "text:uncategorized",
    # List
    "list:item",
    "list:item_ordered",
    "list:item_definition",
    # Table
    "table:simple",
    "table:complex",
    "table:continuation",
    # Code
    "code:block",
    "code:inline",
    "code:cell",
    # Media
    "media:figure",
    "media:image",
    "media:audio",
    "media:video",
    # Scientific
    "scientific:equation_display",
    "scientific:equation_inline",
    "scientific:citation",
    "scientific:reference_entry",
    "scientific:theorem",
    "scientific:proof",
    "scientific:definition",
    # Form
    "form:field",
    "form:label",
    "form:checkbox",
    # Meta
    "meta:document_title",
    "meta:author",
    "meta:date",
    "meta:address",
    "meta:email",
    "meta:url",
    "meta:page_number",
    "meta:extraction_error",
    # Composite
    "composite:chunk",
    "composite:parent_chunk",
}

# Types that are NEVER split across chunk boundaries
ATOMIC_TYPES: frozenset[str] = frozenset({
    "table:simple",
    "table:complex",
    "table:continuation",
    "media:figure",
    "media:image",
    "code:block",
    "scientific:equation_display",
})


# ---------------------------------------------------------------------------
# ID derivation helpers
# ---------------------------------------------------------------------------

def element_id(
    text: str,
    page: int | None,
    sequence_index: int,
    source_sha256: str,
) -> str:
    """Derive a stable content-addressed element ID (16 hex chars = 64-bit space)."""
    raw = f"{source_sha256}:{page}:{sequence_index}:{text}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return f"el_{digest}"


def chunk_id(
    element_ids: list[str],
    source_sha256: str,
    sequence_index: int,
) -> str:
    """Derive a stable content-addressed chunk ID."""
    raw = f"{source_sha256}:{sequence_index}:{','.join(element_ids)}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return f"ch_{digest}"


def list_id(source_sha256: str, first_item_sequence_index: int) -> str:
    """Derive a list group ID from the first item's position."""
    raw = f"{source_sha256}:list:{first_item_sequence_index}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return f"li_{digest}"


# ---------------------------------------------------------------------------
# Sub-object models
# ---------------------------------------------------------------------------

class TableStructured(BaseModel):
    headers: list[str] = Field(default_factory=list)
    rows: list[list[Any]] = Field(default_factory=list)


class MergedCell(BaseModel):
    row: int
    col: int
    rowspan: int = 1
    colspan: int = 1
    value: str | None = None


class HeaderLevel(BaseModel):
    level: int
    labels: list[str]


class TableData(BaseModel):
    markdown: str
    structured: TableStructured
    has_header_row: bool = True
    row_count: int = 0          # data rows only (excludes header rows)
    header_row_count: int = 1   # number of header rows
    col_count: int = 0
    caption: str | None = None
    merged_continuation_ids: list[str] = Field(default_factory=list)
    merge_map: list[MergedCell] = Field(default_factory=list)
    multi_level_headers: list[HeaderLevel] = Field(default_factory=list)
    footnotes: list[str] = Field(default_factory=list)
    html: str | None = None
    table_extraction_method: str | None = None


class EquationData(BaseModel):
    latex: str
    plain_text: str | None = None
    mathml: str | None = None


class CitationData(BaseModel):
    reference_entry_id: str | None = None
    citation_text: str


class ReferenceData(BaseModel):
    authors: list[str] = Field(default_factory=list)
    year: str | None = None
    title: str | None = None
    venue: str | None = None
    doi: str | None = None
    url: str | None = None
    raw: str = ""


class FigureData(BaseModel):
    caption: str | None = None
    caption_id: str | None = None
    image_ref: str | None = None
    image_sha256: str | None = None
    ocr_text: str | None = None
    width_px: int | None = None
    height_px: int | None = None


class ImageData(BaseModel):
    image_ref: str | None = None
    image_sha256: str | None = None
    format: str | None = None
    width_px: int | None = None
    height_px: int | None = None
    alt_text: str | None = None
    ocr_text: str | None = None
    storage: str = "ref"  # "ref" | "inline" | "skip"


class AdmonitionData(BaseModel):
    kind: str  # "note" | "warning" | "tip" | "caution" | "important" | "danger" | "custom"
    title: str | None = None


class TranscriptData(BaseModel):
    speaker: str | None = None
    start_time_s: float
    end_time_s: float
    word_timestamps: list[dict[str, Any]] | None = None


class ChunkMetadata(BaseModel):
    element_ids: list[str] = Field(default_factory=list)
    chunking_strategy: str = "section-aware-v1"
    max_tokens: int = 512
    overlap_tokens: int = 0
    overlap_source: str = "none"  # "none" | "element" | "sentence_split"
    has_table: bool = False
    has_code: bool = False
    has_equation: bool = False
    prefix_tokens: int = 0
    granularity: Literal["fine", "coarse", "single"] = "single"
    parent_size: int | None = None  # token budget of the parent pass


class ElementMetadata(BaseModel):
    """Optional metadata bag — parser-specific extras."""
    page_number: int | None = None
    bbox: list[float] | None = None
    style_name: str | None = None
    language: str | None = None
    is_speaker_note: bool | None = None
    merged_cell: bool | None = None
    parent_id: str | None = None
    continuation_of: str | None = None


# ---------------------------------------------------------------------------
# Base element model
# ---------------------------------------------------------------------------

class BaseElement(BaseModel):
    id: str
    element_type: str
    text: str
    section_path: list[str] = Field(default_factory=list)
    section_path_tier: int = Field(ge=1, le=4)
    sequence_index: int = Field(ge=0)
    extraction_method: str
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    schema_version: str = SCHEMA_VERSION
    page: int | None = None
    heading_level: int | None = None  # 1-6 for headings, None otherwise

    # Provenance (strongly recommended, required on chunks)
    source_filename: str | None = None
    source_sha256: str | None = None
    source_media_type: str | None = None

    # Optional sub-objects — populated based on element_type
    table: TableData | None = None
    equation: EquationData | None = None
    citation: CitationData | None = None
    reference: ReferenceData | None = None
    figure: FigureData | None = None
    image: ImageData | None = None
    admonition: AdmonitionData | None = None
    transcript: TranscriptData | None = None

    # List grouping
    list_id: str | None = None
    list_index: int | None = None
    list_depth: int | None = None

    # Metadata bag
    metadata: ElementMetadata = Field(default_factory=ElementMetadata)

    @field_validator("element_type")
    @classmethod
    def validate_element_type(cls, v: str) -> str:
        if v not in ELEMENT_TYPES:
            raise ValueError(
                f"Unknown element_type: {v!r}. "
                f"Must be one of: {sorted(ELEMENT_TYPES)}"
            )
        return v

    @field_validator("schema_version")
    @classmethod
    def validate_schema_version(cls, v: str) -> str:
        if v != SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {SCHEMA_VERSION!r}, got {v!r}")
        return v

    @property
    def is_heading(self) -> bool:
        """True for title, section_header, page_header elements."""
        return self.element_type in (
            "structural:title", "structural:subtitle",
            "structural:section_header", "structural:page_header",
        )

    @property
    def is_table(self) -> bool:
        """True for any table:* element."""
        return self.element_type.startswith("table:")

    @property
    def is_atomic(self) -> bool:
        """True for element types that are never split across chunk boundaries."""
        return self.element_type in ATOMIC_TYPES

    @property
    def category(self) -> str:
        """The namespace prefix of the element type (e.g. 'structural', 'table', 'text')."""
        return self.element_type.split(":")[0]


# ---------------------------------------------------------------------------
# Chunk record
# ---------------------------------------------------------------------------

class ChunkRecord(BaseElement):
    element_type: str = "composite:chunk"
    token_count: int = Field(ge=1)
    chunk_metadata: ChunkMetadata = Field(default_factory=ChunkMetadata)

    # Provenance required on chunks
    source_filename: str
    source_sha256: str
    source_media_type: str

    # Context prefix injection
    context_prefix: str | None = None
    raw_text: str | None = None

    # Dual-granularity: links a fine chunk to its coarse parent
    parent_chunk_id: str | None = None


# ---------------------------------------------------------------------------
# Envelope record (first line of JSONL)
# ---------------------------------------------------------------------------

class SourceInfo(BaseModel):
    filename: str
    path: str
    sha256: str
    size_bytes: int
    media_type: str
    subtype: str | None = None  # "digital" | "scientific" | "scanned" for PDFs


class RunConfig(BaseModel):
    mode: str  # "elements" | "chunks" | "dual-chunks"
    chunk_size: int = 512
    overlap: int = 0
    strategy: str = "fast"  # "fast" | "accurate" | "ocr"
    include_types: list[str] | None = None
    exclude_types: list[str] | None = None
    tokenizer: str = "cl100k_base"
    inject_context_prefix: bool = False
    parent_size: int = 512
    child_size: int = 128


class EnvelopeRecord(BaseModel):
    type: str = "envelope"
    schema_version: str = SCHEMA_VERSION
    extractor_version: str
    source: SourceInfo
    run_config: RunConfig
    created_at: str  # ISO 8601


# ---------------------------------------------------------------------------
# Manifest record
# ---------------------------------------------------------------------------

class ConfidenceStats(BaseModel):
    mean: float
    p10: float
    p90: float
    below_0_5: int = 0
    below_0_7: int = 0


class SectionPathTierStats(BaseModel):
    t1: int = Field(alias="1", default=0)
    t2: int = Field(alias="2", default=0)
    t3: int = Field(alias="3", default=0)
    t4: int = Field(alias="4", default=0)

    model_config = {"populate_by_name": True}


class TableStats(BaseModel):
    total: int = 0
    with_header: int = 0
    continuation_segments: int = 0
    continuation_pairs_merged: int = 0


class ChunkStats(BaseModel):
    total: int = 0
    min_tokens: int = 0
    max_tokens: int = 0
    mean_tokens: float = 0.0
    atomic_solo: int = 0


class StatsRecord(BaseModel):
    total_elements: int = 0
    total_chunks: int = 0
    total_tokens: int = 0
    elements_by_type: dict[str, int] = Field(default_factory=dict)
    suppressed_by_filter: int = 0
    confidence: ConfidenceStats | None = None
    section_path_tiers: dict[str, int] = Field(default_factory=dict)
    tables: TableStats = Field(default_factory=TableStats)
    chunks: ChunkStats = Field(default_factory=ChunkStats)


class ManifestWarning(BaseModel):
    code: str
    message: str
    element_id: str | None = None
    page: int | None = None


class ManifestRecord(BaseModel):
    type: str = "manifest"
    manifest_id: str
    schema_version: str = SCHEMA_VERSION
    status: str  # "complete" | "partial"
    source: SourceInfo
    run_config: RunConfig
    parser_chain: list[str] = Field(default_factory=list)
    stats: StatsRecord = Field(default_factory=StatsRecord)
    warnings: list[ManifestWarning] = Field(default_factory=list)
    errors: list[dict[str, Any]] = Field(default_factory=list)
    toc: list[dict[str, Any]] = Field(default_factory=list)
    output_files: list[str] = Field(default_factory=list)
    created_at: str
    completed_at: str | None = None
