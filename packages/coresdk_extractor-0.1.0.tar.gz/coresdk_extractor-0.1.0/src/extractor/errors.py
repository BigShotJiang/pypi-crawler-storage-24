"""Exception hierarchy for extractor. All errors map to an ExitCode."""
from __future__ import annotations
from .exit_codes import ExitCode


class ExtractorError(Exception):
    """Base class for all extractor errors."""
    exit_code: ExitCode = ExitCode.PARSER_CRASH
    error_code: str = "E_UNKNOWN"


class QuarantineError(ExtractorError):
    """File rejected at the quarantine gate before parsing."""
    exit_code = ExitCode.QUARANTINE
    error_code = "E_QUARANTINE"

    def __init__(self, code: str, message: str) -> None:
        self.error_code = code
        super().__init__(message)


class UnsupportedFormatError(ExtractorError):
    """No parser registered for this file format."""
    exit_code = ExitCode.UNSUPPORTED
    error_code = "E_UNSUPPORTED_FORMAT"

    def __init__(self, message: str = "", mime_type: str | None = None):
        if mime_type and not message:
            message = (
                f"No parser found for {mime_type!r}. "
                f"Run 'extractor info' to list all supported formats."
            )
        elif not message:
            message = "Unsupported file format. Run 'extractor info' to list all supported formats."
        super().__init__(message)


class ParserError(ExtractorError):
    """Parser failed — may allow partial output."""
    exit_code = ExitCode.PARSER_CRASH
    error_code = "E_PARSER_CRASH"

    def __init__(self, message: str, recoverable: bool = False) -> None:
        self.recoverable = recoverable
        super().__init__(message)


class OutputError(ExtractorError):
    """Cannot write to the specified output path."""
    exit_code = ExitCode.OUTPUT_ERROR
    error_code = "E_OUTPUT_ERROR"


class ConfigurationError(ExtractorError):
    """Invalid CLI flags or configuration options."""
    exit_code = ExitCode.CONFIG_ERROR
    error_code = "E_CONFIG_ERROR"
