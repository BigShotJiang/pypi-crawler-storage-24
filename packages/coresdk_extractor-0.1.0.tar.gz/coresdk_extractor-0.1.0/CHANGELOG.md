# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — 2026-03-24

### Added
- 15 parsers: PDF (digital/scientific/OCR), DOCX, PPTX, XLSX, HTML, EPUB, Markdown, LaTeX, JSON, XML, CSV, plain text, audio
- 52-type element schema (schema v1.0.0) with content-addressed IDs
- Dual-mode output: elements and chunks (section-aware, token-budget chunker)
- Dual-granularity chunks (`--mode dual-chunks`) with parent/child linking
- Incremental processing cache (`--incremental`)
- Context prefix injection (`--inject-context-prefix`)
- Async API (`aextract`, `aextract_batch`) and batch API (`extract_batch`)
- LangChain and LlamaIndex integration adapters (`extractor.integrations`)
- JSON Schema definitions published at `schemas/v1/`
- Table merge topology detection: `table:complex` for DOCX and PPTX merged cells
- Three-tier PDF reading order: surya LayoutPredictor → pdfplumber XY-cut → pymupdf4llm fallback
- Integration test scaffold for all 12 non-audio parsers

[Unreleased]: https://github.com/your-org/extractor/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/your-org/extractor/releases/tag/v0.1.0
