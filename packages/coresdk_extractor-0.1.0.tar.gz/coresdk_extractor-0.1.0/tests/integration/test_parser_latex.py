"""Integration tests for LaTeX parser."""
from __future__ import annotations
import pytest

from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_latex_no_crash(latex_fixture):
    assert len(list(extract(latex_fixture, mode="elements"))) > 0


def test_latex_element_types_valid(latex_fixture):
    for el in extract(latex_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_latex_chunks_mode(latex_fixture):
    assert len(list(extract(latex_fixture, mode="chunks"))) > 0


def test_latex_required_fields(latex_fixture):
    for el in extract(latex_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_latex_has_section_headers(latex_fixture):
    elements = list(extract(latex_fixture, mode="elements"))
    headings = [e for e in elements if e.element_type == "structural:section_header"]
    assert len(headings) >= 1


def test_latex_has_equation(latex_fixture):
    elements = list(extract(latex_fixture, mode="elements"))
    types = [e.element_type for e in elements]
    assert any("equation" in t for t in types)


def test_latex_regression(data_regression):
    from collections import Counter
    from pathlib import Path
    p = Path(__file__).parent.parent.parent / "sample_data" / "complex.tex"
    if not p.exists():
        pytest.skip("sample_data/complex.tex not found")
    elements = list(extract(p, mode="elements"))
    data_regression.check({
        "total": len(elements),
        "by_type": dict(Counter(e.element_type for e in elements)),
    })
