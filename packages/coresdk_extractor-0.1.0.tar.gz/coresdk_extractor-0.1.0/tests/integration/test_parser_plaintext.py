"""Integration tests for plaintext parser."""
from __future__ import annotations
import pytest
from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_txt_no_crash(txt_fixture):
    assert len(list(extract(txt_fixture, mode="elements"))) > 0


def test_txt_element_types_valid(txt_fixture):
    for el in extract(txt_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_txt_chunks_mode(txt_fixture):
    assert len(list(extract(txt_fixture, mode="chunks"))) > 0


def test_txt_required_fields(txt_fixture):
    for el in extract(txt_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_txt_has_narrative(txt_fixture):
    elements = list(extract(txt_fixture, mode="elements"))
    types = [e.element_type for e in elements]
    assert "text:narrative" in types
