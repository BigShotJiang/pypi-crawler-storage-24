"""Integration tests for HTML parser."""
from __future__ import annotations
import pytest
from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_html_no_crash(html_fixture):
    assert len(list(extract(html_fixture, mode="elements"))) > 0


def test_html_element_types_valid(html_fixture):
    for el in extract(html_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_html_chunks_mode(html_fixture):
    assert len(list(extract(html_fixture, mode="chunks"))) > 0


def test_html_required_fields(html_fixture):
    for el in extract(html_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_html_headings(html_fixture):
    elements = list(extract(html_fixture, mode="elements"))
    headings = [e for e in elements if e.element_type == "structural:section_header"]
    assert len(headings) >= 1


def test_html_table(html_fixture):
    elements = list(extract(html_fixture, mode="elements"))
    tables = [e for e in elements if e.element_type in ("table:simple", "table:complex")]
    assert len(tables) >= 1


def test_html_regression(data_regression):
    from collections import Counter
    from pathlib import Path
    p = Path(__file__).parent.parent.parent / "sample_data" / "api_docs.html"
    if not p.exists():
        pytest.skip("sample_data/api_docs.html not found")
    elements = list(extract(p, mode="elements"))
    data_regression.check({
        "total": len(elements),
        "by_type": dict(Counter(e.element_type for e in elements)),
    })
