"""Integration tests for JSON parser."""
from __future__ import annotations
import pytest
from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_json_no_crash(json_fixture):
    assert len(list(extract(json_fixture, mode="elements"))) > 0


def test_json_element_types_valid(json_fixture):
    for el in extract(json_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_json_chunks_mode(json_fixture):
    assert len(list(extract(json_fixture, mode="chunks"))) > 0


def test_json_required_fields(json_fixture):
    for el in extract(json_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_json_has_narrative(json_fixture):
    elements = list(extract(json_fixture, mode="elements"))
    types = [e.element_type for e in elements]
    assert "text:narrative" in types


def test_json_regression(data_regression):
    from collections import Counter
    from pathlib import Path
    p = Path(__file__).parent.parent.parent / "sample_data" / "config.json"
    if not p.exists():
        pytest.skip("sample_data/config.json not found")
    elements = list(extract(p, mode="elements"))
    data_regression.check({
        "total": len(elements),
        "by_type": dict(Counter(e.element_type for e in elements)),
    })
