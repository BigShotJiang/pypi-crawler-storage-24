"""Integration tests for XML parser."""
from __future__ import annotations
import pytest
from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_xml_no_crash(xml_fixture):
    assert len(list(extract(xml_fixture, mode="elements"))) > 0


def test_xml_element_types_valid(xml_fixture):
    for el in extract(xml_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_xml_chunks_mode(xml_fixture):
    assert len(list(extract(xml_fixture, mode="chunks"))) > 0


def test_xml_required_fields(xml_fixture):
    for el in extract(xml_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_xml_has_content(xml_fixture):
    elements = list(extract(xml_fixture, mode="elements"))
    texts = [e for e in elements if e.element_type in ("text:narrative", "structural:section_header")]
    assert len(texts) >= 1
