"""Integration tests for EPUB parser."""
from __future__ import annotations
import importlib.util
import pytest

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("ebooklib") is None, reason="ebooklib not installed"
)

from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_epub_no_crash(epub_fixture):
    assert len(list(extract(epub_fixture, mode="elements"))) > 0


def test_epub_element_types_valid(epub_fixture):
    for el in extract(epub_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_epub_chunks_mode(epub_fixture):
    assert len(list(extract(epub_fixture, mode="chunks"))) > 0


def test_epub_required_fields(epub_fixture):
    for el in extract(epub_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_epub_has_content(epub_fixture):
    elements = list(extract(epub_fixture, mode="elements"))
    types = [e.element_type for e in elements]
    assert any(t in types for t in ("text:narrative", "structural:section_header"))
