"""Integration tests for PPTX parser."""
from __future__ import annotations
import importlib.util
import pytest

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("pptx") is None, reason="python-pptx not installed"
)

from extractor import extract
from extractor.schema import ELEMENT_TYPES


def test_pptx_no_crash(pptx_fixture):
    assert len(list(extract(pptx_fixture, mode="elements"))) > 0


def test_pptx_element_types_valid(pptx_fixture):
    for el in extract(pptx_fixture, mode="elements"):
        assert el.element_type in ELEMENT_TYPES


def test_pptx_chunks_mode(pptx_fixture):
    assert len(list(extract(pptx_fixture, mode="chunks"))) > 0


def test_pptx_required_fields(pptx_fixture):
    for el in extract(pptx_fixture, mode="elements"):
        assert el.id and el.source_filename and el.schema_version


def test_pptx_slide_headings(pptx_fixture):
    elements = list(extract(pptx_fixture, mode="elements"))
    headings = [e for e in elements if e.element_type == "structural:section_header"]
    assert len(headings) >= 3  # 3 slides


def test_pptx_page_field_set(pptx_fixture):
    elements = list(extract(pptx_fixture, mode="elements"))
    for el in elements:
        if el.element_type in ("structural:section_header", "list:item", "text:narrative"):
            assert el.page is not None


def test_pptx_has_table(pptx_fixture):
    elements = list(extract(pptx_fixture, mode="elements"))
    tables = [e for e in elements if e.element_type in ("table:simple", "table:complex")]
    assert len(tables) >= 1


def test_pptx_regression(data_regression):
    from collections import Counter
    from pathlib import Path
    p = Path(__file__).parent.parent.parent / "sample_data" / "presentation.pptx"
    if not p.exists():
        pytest.skip("sample_data/presentation.pptx not found")
    elements = list(extract(p, mode="elements"))
    data_regression.check({
        "total": len(elements),
        "by_type": dict(Counter(e.element_type for e in elements)),
    })
