"""Sanity check: schema version constant is consistent."""
from extractor.schema import SCHEMA_VERSION

def test_schema_version_is_semver():
    parts = SCHEMA_VERSION.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)

def test_schema_version_matches_expected():
    # Update this when bumping the schema version
    assert SCHEMA_VERSION == "1.0.0"
