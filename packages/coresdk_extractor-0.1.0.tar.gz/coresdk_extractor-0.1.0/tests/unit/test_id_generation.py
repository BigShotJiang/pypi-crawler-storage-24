"""Unit tests for ID generation functions."""
from __future__ import annotations

from extractor.schema import element_id, chunk_id, list_id


class TestElementId:
    def test_prefix(self):
        assert element_id("text", 1, 0, "sha").startswith("el_")

    def test_length(self):
        eid = element_id("text", 1, 0, "sha")
        assert len(eid) == 19  # "el_" (3) + 16 hex chars

    def test_deterministic(self):
        assert element_id("a", 1, 0, "x") == element_id("a", 1, 0, "x")

    def test_page_none_vs_int(self):
        assert element_id("a", None, 0, "x") != element_id("a", 1, 0, "x")

    def test_unique_across_sequence(self):
        sha = "deadbeef" * 8
        ids = {element_id("same text", 1, i, sha) for i in range(100)}
        assert len(ids) == 100


class TestChunkId:
    def test_prefix(self):
        assert chunk_id(["el_a", "el_b"], "sha", 0).startswith("ch_")

    def test_length(self):
        cid = chunk_id(["el_a"], "sha", 0)
        assert len(cid) == 19


class TestListId:
    def test_prefix(self):
        assert list_id("sha", 0).startswith("li_")

    def test_length(self):
        lid = list_id("sha", 0)
        assert len(lid) == 19

    def test_deterministic(self):
        assert list_id("sha", 42) == list_id("sha", 42)
