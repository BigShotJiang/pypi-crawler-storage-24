"""Shared pytest fixtures."""
from __future__ import annotations
import pytest
from pathlib import Path

FIXTURES_DIR = Path(__file__).parent / "integration" / "fixtures"


@pytest.fixture
def fixtures_dir() -> Path:
    return FIXTURES_DIR
