"""Version information for anomalyarmor-cli."""

__version__ = "0.4.0"
