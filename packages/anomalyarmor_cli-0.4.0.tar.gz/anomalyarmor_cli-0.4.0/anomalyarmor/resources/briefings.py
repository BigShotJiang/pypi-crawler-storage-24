"""Briefings resource for the Armor SDK."""

from __future__ import annotations

from typing import Any

from anomalyarmor.resources.base import BaseResource


class BriefingsResource(BaseResource):
    """Resource for interacting with daily briefings.

    Example:
        >>> from anomalyarmor import Client
        >>> client = Client()
        >>>
        >>> # Get today's briefing
        >>> briefing = client.briefings.today()
        >>> print(briefing.get("title"))
    """

    def today(self) -> dict[str, Any]:
        """Get today's daily briefing digest.

        Generates the briefing on-demand if it hasn't been created yet today.

        Returns:
            Dict with briefing data including title, sections, and insights.
        """
        response = self._get("/briefings/today")
        data: dict[str, Any] = response.get("data", {})
        return data
