"""Resource classes for the Armor SDK."""

from anomalyarmor.resources.alerts import AlertsResource
from anomalyarmor.resources.api_keys import APIKeysResource
from anomalyarmor.resources.assets import AssetsResource
from anomalyarmor.resources.badges import BadgesResource
from anomalyarmor.resources.briefings import BriefingsResource
from anomalyarmor.resources.freshness import FreshnessResource
from anomalyarmor.resources.health import HealthResource
from anomalyarmor.resources.intelligence import IntelligenceResource
from anomalyarmor.resources.jobs import JobsResource
from anomalyarmor.resources.lineage import LineageResource
from anomalyarmor.resources.metrics import MetricsResource
from anomalyarmor.resources.recommendations import RecommendationsResource
from anomalyarmor.resources.referential import ReferentialResource
from anomalyarmor.resources.schema import SchemaResource
from anomalyarmor.resources.tags import TagsResource
from anomalyarmor.resources.validity import ValidityResource

__all__ = [
    "AlertsResource",
    "APIKeysResource",
    "AssetsResource",
    "BadgesResource",
    "BriefingsResource",
    "FreshnessResource",
    "HealthResource",
    "IntelligenceResource",
    "JobsResource",
    "LineageResource",
    "MetricsResource",
    "RecommendationsResource",
    "ReferentialResource",
    "SchemaResource",
    "TagsResource",
    "ValidityResource",
]
