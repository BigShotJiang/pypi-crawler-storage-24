"""Alerts resource for the Armor SDK."""

from __future__ import annotations

import builtins
from datetime import datetime
from typing import Any

from anomalyarmor.models import (
    Alert,
    AlertDestination,
    AlertPreviewResponse,
    AlertRule,
    AlertSummary,
    InboxAlert,
)
from anomalyarmor.resources.base import BaseResource


class AlertsResource(BaseResource):
    """Resource for interacting with alerts.

    Example:
        >>> from anomalyarmor import Client
        >>> client = Client()
        >>>
        >>> # Get summary
        >>> summary = client.alerts.summary()
        >>> if summary.unresolved_alerts > 0:
        ...     print(f"You have {summary.unresolved_alerts} unresolved alerts")
        >>>
        >>> # List critical alerts
        >>> critical = client.alerts.list(severity="critical")
        >>>
        >>> # List alert rules
        >>> rules = client.alerts.rules()
        >>>
        >>> # Create destination and rule (TECH-646)
        >>> dest = client.alerts.create_destination(
        ...     name="Slack #alerts",
        ...     destination_type="slack",
        ...     config={"webhook_url": "https://..."}
        ... )
        >>> rule = client.alerts.create_rule(
        ...     name="Critical Alerts",
        ...     destination_ids=[dest.id],
        ...     severities=["critical"]
        ... )
    """

    def summary(self) -> AlertSummary:
        """Get a summary of alerts and rules.

        Returns:
            AlertSummary with counts
        """
        response = self._get("/alerts/summary")
        return AlertSummary.model_validate(response.get("data", {}))

    def list(
        self,
        status: str | None = None,
        severity: str | None = None,
        asset_id: str | None = None,
        from_date: datetime | str | None = None,
        to_date: datetime | str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> builtins.list[Alert]:
        """List alerts with optional filters.

        Args:
            status: Filter by status ("triggered", "acknowledged", "resolved")
            severity: Filter by severity ("info", "warning", "critical")
            asset_id: Filter by asset UUID or qualified name
            from_date: Start of date range (ISO string or datetime)
            to_date: End of date range (ISO string or datetime)
            limit: Maximum number of results (default 50, max 100)
            offset: Number of results to skip

        Returns:
            List of Alert objects

        Example:
            >>> from datetime import datetime, timedelta
            >>>
            >>> # Get alerts from yesterday
            >>> yesterday = datetime.now() - timedelta(days=1)
            >>> alerts = client.alerts.list(from_date=yesterday)
            >>>
            >>> # Get alerts for specific date range
            >>> alerts = client.alerts.list(
            ...     from_date="2026-01-01T00:00:00Z",
            ...     to_date="2026-01-31T23:59:59Z",
            ...     severity="critical"
            ... )
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        if severity:
            params["severity"] = severity
        if asset_id:
            params["asset_id"] = asset_id
        if from_date:
            params["from_date"] = (
                from_date.isoformat() if isinstance(from_date, datetime) else from_date
            )
        if to_date:
            params["to_date"] = (
                to_date.isoformat() if isinstance(to_date, datetime) else to_date
            )

        response = self._get("/alerts", params=params)
        data = response.get("data", {}).get("data", [])
        return [Alert.model_validate(item) for item in data]

    def list_inbox(
        self,
        state: str | None = None,
        severity: str | None = None,
        event_type: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> builtins.list[InboxAlert]:
        """List inbox alerts (active alerts that can be acknowledged/resolved).

        Unlike list(), this returns alerts from the inbox that support
        acknowledge(), resolve(), and dismiss() actions.

        Args:
            state: Filter by state ("new", "acknowledged", "resolved", "dismissed")
            severity: Filter by severity ("info", "warning", "critical")
            event_type: Filter by event type (e.g., "freshness_stale", "schema_drift")
            limit: Maximum number of results (default 50, max 100)
            offset: Number of results to skip

        Returns:
            List of InboxAlert objects

        Example:
            >>> # Get all new alerts
            >>> alerts = client.alerts.list_inbox(state="new")
            >>> for alert in alerts:
            ...     print(f"[{alert.severity}] {alert.title}")
            ...     client.alerts.acknowledge(alert.id)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if state:
            params["state"] = state
        if severity:
            params["severity"] = severity
        if event_type:
            params["event_type"] = event_type

        response = self._get("/alerts/inbox", params=params)
        data = response.get("data", {}).get("alerts", [])
        return [InboxAlert.model_validate(item) for item in data]

    def rules(
        self,
        enabled_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> builtins.list[AlertRule]:
        """List alert rules.

        Args:
            enabled_only: Only return enabled rules
            limit: Maximum number of results (default 50, max 100)
            offset: Number of results to skip

        Returns:
            List of AlertRule objects
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if enabled_only:
            params["enabled_only"] = True

        response = self._get("/alerts/rules", params=params)
        data = response.get("data", {}).get("data", [])
        return [AlertRule.model_validate(item) for item in data]

    # =========================================================================
    # TECH-646: Alert Rules CRUD
    # =========================================================================

    def create_rule(
        self,
        name: str,
        destination_ids: builtins.list[str],
        description: str | None = None,
        is_active: bool = True,
        event_types: builtins.list[str] | None = None,
        severities: builtins.list[str] | None = None,
        tag_filter_mode: str | None = None,
        tag_filter_tags: builtins.list[str] | None = None,
        is_notify_code_authors: bool | None = None,
        code_author_min_confidence: float | None = None,
    ) -> AlertRule:
        """Create a new alert rule.

        Args:
            name: Rule name
            destination_ids: List of destination UUIDs to send alerts to
            description: Optional rule description
            is_active: Whether the rule is active (default True)
            event_types: Event types to alert on (e.g., ["freshness_alert", "schema_drift"])
            severities: Severity levels to alert on (e.g., ["critical", "warning"])
            tag_filter_mode: Tag filter mode ("any" or "all")
            tag_filter_tags: List of tags to filter by
            is_notify_code_authors: Whether to notify code authors on alert
            code_author_min_confidence: Minimum git blame confidence (0.0-1.0)

        Returns:
            Created AlertRule object

        Example:
            >>> rule = client.alerts.create_rule(
            ...     name="Critical Freshness Alerts",
            ...     destination_ids=["dest-uuid-1"],
            ...     event_types=["freshness_alert"],
            ...     severities=["critical"]
            ... )
            >>> print(f"Created rule: {rule.id}")
        """
        payload: dict[str, Any] = {
            "name": name,
            "destination_ids": destination_ids,
            "is_active": is_active,
        }
        for key, val in {
            "description": description,
            "event_types": event_types,
            "severities": severities,
            "tag_filter_mode": tag_filter_mode,
            "tag_filter_tags": tag_filter_tags,
            "is_notify_code_authors": is_notify_code_authors,
            "code_author_min_confidence": code_author_min_confidence,
        }.items():
            if val is not None:
                payload[key] = val

        response = self._post("/alerts/rules", json=payload)
        return AlertRule.model_validate(response.get("data", {}))

    def get_rule(self, rule_id: str) -> AlertRule:
        """Get a specific alert rule by ID.

        Args:
            rule_id: Rule public UUID

        Returns:
            AlertRule object

        Example:
            >>> rule = client.alerts.get_rule("rule-uuid")
            >>> print(f"Rule: {rule.name}, Active: {rule.is_active}")
        """
        response = self._get(f"/alerts/rules/{rule_id}")
        return AlertRule.model_validate(response.get("data", {}))

    def update_rule(
        self,
        rule_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        is_active: bool | None = None,
        event_types: builtins.list[str] | None = None,
        severities: builtins.list[str] | None = None,
        tag_filter_mode: str | None = None,
        tag_filter_tags: builtins.list[str] | None = None,
        is_notify_code_authors: bool | None = None,
        code_author_min_confidence: float | None = None,
    ) -> AlertRule:
        """Update an existing alert rule.

        Args:
            rule_id: Rule public UUID
            name: New rule name
            description: Updated description
            is_active: Whether the rule is active
            event_types: Event types to alert on
            severities: Severity levels to alert on
            tag_filter_mode: Tag filter mode ("any" or "all")
            tag_filter_tags: List of tags to filter by
            is_notify_code_authors: Whether to notify code authors
            code_author_min_confidence: Minimum git blame confidence (0.0-1.0)

        Returns:
            Updated AlertRule object

        Example:
            >>> rule = client.alerts.update_rule(
            ...     "rule-uuid",
            ...     name="Updated Rule Name",
            ...     is_notify_code_authors=True,
            ...     code_author_min_confidence=0.8,
            ... )
        """
        payload: dict[str, Any] = {}
        for key, val in {
            "name": name,
            "description": description,
            "is_active": is_active,
            "event_types": event_types,
            "severities": severities,
            "tag_filter_mode": tag_filter_mode,
            "tag_filter_tags": tag_filter_tags,
            "is_notify_code_authors": is_notify_code_authors,
            "code_author_min_confidence": code_author_min_confidence,
        }.items():
            if val is not None:
                payload[key] = val
        response = self._put(f"/alerts/rules/{rule_id}", json=payload)
        return AlertRule.model_validate(response.get("data", {}))

    def delete_rule(self, rule_id: str) -> bool:
        """Delete an alert rule.

        Args:
            rule_id: Rule public UUID

        Returns:
            True if deleted successfully

        Example:
            >>> client.alerts.delete_rule("rule-uuid")
        """
        self._delete(f"/alerts/rules/{rule_id}")
        return True

    # =========================================================================
    # TECH-646: Alert Destinations CRUD
    # =========================================================================

    def list_destinations(
        self,
        active_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> builtins.list[AlertDestination]:
        """List alert destinations.

        Args:
            active_only: Only return active destinations
            limit: Maximum results
            offset: Pagination offset

        Returns:
            List of AlertDestination objects

        Example:
            >>> destinations = client.alerts.list_destinations()
            >>> for dest in destinations:
            ...     print(f"{dest.name} ({dest.destination_type})")
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if active_only:
            params["active_only"] = True

        response = self._get("/alerts/destinations", params=params)
        data = response.get("data", {}).get("destinations", [])
        return [AlertDestination.model_validate(item) for item in data]

    def create_destination(
        self,
        name: str,
        destination_type: str,
        config: dict[str, Any],
    ) -> AlertDestination:
        """Create a new alert destination.

        Args:
            name: Destination name
            destination_type: Type: email, slack, webhook, teams, pagerduty
            config: Configuration dict (varies by type)
                - email: {"email": "user@example.com"} or {"recipients": ["email1", "email2"]}
                - slack: {"webhook_url": "https://hooks.slack.com/..."}
                - webhook: {"url": "https://...", "headers": {...}}
                - teams: {"webhook_url": "https://..."}
                - pagerduty: {"api_token": "...", "routing_key": "..."}

        Returns:
            Created AlertDestination

        Example:
            >>> dest = client.alerts.create_destination(
            ...     name="Slack #alerts",
            ...     destination_type="slack",
            ...     config={"webhook_url": "https://hooks.slack.com/..."}
            ... )
            >>> print(f"Created: {dest.id}")
        """
        payload = {
            "name": name,
            "destination_type": destination_type,
            "config": config,
        }
        response = self._post("/alerts/destinations", json=payload)
        return AlertDestination.model_validate(response.get("data", {}))

    def get_destination(self, destination_id: str) -> AlertDestination:
        """Get a specific alert destination by ID.

        Args:
            destination_id: Destination public UUID

        Returns:
            AlertDestination object

        Example:
            >>> dest = client.alerts.get_destination("dest-uuid")
            >>> print(f"{dest.name}: {dest.destination_type}")
        """
        response = self._get(f"/alerts/destinations/{destination_id}")
        return AlertDestination.model_validate(response.get("data", {}))

    def delete_destination(self, destination_id: str) -> bool:
        """Delete an alert destination.

        Args:
            destination_id: Destination public UUID

        Returns:
            True if deleted successfully

        Example:
            >>> client.alerts.delete_destination("dest-uuid")
        """
        self._delete(f"/alerts/destinations/{destination_id}")
        return True

    def update_destination(
        self,
        destination_id: str,
        *,
        name: str | None = None,
        config: dict[str, Any] | None = None,
        is_active: bool | None = None,
    ) -> AlertDestination:
        """Update an alert destination.

        Args:
            destination_id: Destination public UUID
            name: New destination name
            config: Updated configuration dict
            is_active: Active status

        Returns:
            Updated AlertDestination object

        Example:
            >>> dest = client.alerts.update_destination(
            ...     "dest-uuid",
            ...     name="Updated Slack",
            ...     is_active=False,
            ... )
        """
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if config is not None:
            payload["config"] = config
        if is_active is not None:
            payload["is_active"] = is_active
        response = self._put(f"/alerts/destinations/{destination_id}", json=payload)
        return AlertDestination.model_validate(response.get("data", {}))

    def test_destination(self, destination_id: str) -> dict[str, Any]:
        """Test an alert destination by sending a test notification.

        For email destinations, sends a real test email.
        For Slack, sends a real test message.
        For other types, validates configuration format.

        Args:
            destination_id: Destination public UUID

        Returns:
            Dict with test results (destination_id, test_sent, message)

        Example:
            >>> result = client.alerts.test_destination("dest-uuid")
            >>> print(result["message"])
        """
        response = self._post(f"/alerts/destinations/{destination_id}/test", json={})
        data: dict[str, Any] = response.get("data", {})
        return data

    # =========================================================================
    # TECH-767: Alert Resolution APIs
    # =========================================================================

    # Resolution fields exposed to SDK users (excludes internal-only
    # suggestion_pattern_id and suggestion_was_helpful)
    _RESOLUTION_FIELDS = (
        "action_category",
        "action_detail",
        "root_cause_category",
        "root_cause_detail",
        "pr_url",
        "job_run_id",
        "external_link",
    )

    def _action_with_resolution(
        self,
        alert_id: str,
        action: str,
        notes: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Shared logic for resolve/dismiss with resolution metadata."""
        payload: dict[str, Any] = {}
        if notes is not None:
            payload["notes"] = notes
        for key in self._RESOLUTION_FIELDS:
            val = kwargs.get(key)
            if val is not None:
                payload[key] = val
        response = self._post(f"/alerts/{alert_id}/{action}", json=payload)
        data: dict[str, Any] = response.get("data", {})
        return data

    def acknowledge(self, alert_id: str, notes: str | None = None) -> dict[str, Any]:
        """Acknowledge an alert, marking it as seen/being worked on.

        Args:
            alert_id: Alert public UUID
            notes: Optional notes about the acknowledgment

        Returns:
            Dict with alert id and new status

        Example:
            >>> result = client.alerts.acknowledge("alert-uuid", notes="Looking into this")
            >>> print(f"Alert {result['id']} is now {result['status']}")
        """
        payload: dict[str, Any] = {}
        if notes is not None:
            payload["notes"] = notes
        response = self._post(f"/alerts/{alert_id}/acknowledge", json=payload)
        data: dict[str, Any] = response.get("data", {})
        return data

    def resolve(
        self,
        alert_id: str,
        notes: str | None = None,
        *,
        action_category: str | None = None,
        action_detail: str | None = None,
        root_cause_category: str | None = None,
        root_cause_detail: str | None = None,
        pr_url: str | None = None,
        job_run_id: str | None = None,
        external_link: str | None = None,
    ) -> dict[str, Any]:
        """Resolve an alert with optional resolution metadata.

        Args:
            alert_id: Alert public UUID
            notes: Optional resolution notes
            action_category: Action taken (e.g., "reran_job", "updated_sql", "code_change")
            action_detail: Details about the action taken
            root_cause_category: Root cause (e.g., "pipeline_failure", "schema_change")
            root_cause_detail: Details about the root cause
            pr_url: URL to the pull request that fixes this
            job_run_id: ID of the job run related to the fix
            external_link: Link to external tracking system

        Returns:
            Dict with alert id and new status

        Example:
            >>> result = client.alerts.resolve(
            ...     "alert-uuid",
            ...     notes="Fixed the pipeline",
            ...     action_category="code_change",
            ...     pr_url="https://github.com/org/repo/pull/123",
            ... )
        """
        return self._action_with_resolution(
            alert_id,
            "resolve",
            notes=notes,
            action_category=action_category,
            action_detail=action_detail,
            root_cause_category=root_cause_category,
            root_cause_detail=root_cause_detail,
            pr_url=pr_url,
            job_run_id=job_run_id,
            external_link=external_link,
        )

    def dismiss(
        self,
        alert_id: str,
        notes: str | None = None,
        *,
        action_category: str | None = None,
        action_detail: str | None = None,
        root_cause_category: str | None = None,
        root_cause_detail: str | None = None,
        pr_url: str | None = None,
        job_run_id: str | None = None,
        external_link: str | None = None,
    ) -> dict[str, Any]:
        """Dismiss an alert with optional resolution metadata.

        Args:
            alert_id: Alert public UUID
            notes: Optional notes explaining the dismissal
            action_category: Action taken (e.g., "false_positive", "expected_behavior")
            action_detail: Details about the action taken
            root_cause_category: Root cause category
            root_cause_detail: Details about the root cause
            pr_url: URL to the pull request
            job_run_id: ID of the related job run
            external_link: Link to external tracking system

        Returns:
            Dict with alert id and new status

        Example:
            >>> result = client.alerts.dismiss(
            ...     "alert-uuid",
            ...     notes="Expected maintenance window",
            ...     action_category="expected_behavior",
            ... )
        """
        return self._action_with_resolution(
            alert_id,
            "dismiss",
            notes=notes,
            action_category=action_category,
            action_detail=action_detail,
            root_cause_category=root_cause_category,
            root_cause_detail=root_cause_detail,
            pr_url=pr_url,
            job_run_id=job_run_id,
            external_link=external_link,
        )

    def snooze(
        self, alert_id: str, duration_hours: int, notes: str | None = None
    ) -> dict[str, Any]:
        """Snooze an alert for a specified duration.

        Args:
            alert_id: Alert public UUID
            duration_hours: Hours to snooze (1-720, max 30 days)
            notes: Optional notes

        Returns:
            Dict with alert id, status, and snoozed_until timestamp

        Example:
            >>> # Snooze for 24 hours
            >>> result = client.alerts.snooze("alert-uuid", duration_hours=24)
            >>> print(f"Snoozed until {result['snoozed_until']}")
        """
        payload: dict[str, Any] = {"duration_hours": duration_hours}
        if notes is not None:
            payload["notes"] = notes
        response = self._post(f"/alerts/{alert_id}/snooze", json=payload)
        data: dict[str, Any] = response.get("data", {})
        return data

    def history(self, alert_id: str) -> builtins.list[dict[str, Any]]:
        """Get resolution history for an alert.

        Args:
            alert_id: Alert public UUID

        Returns:
            List of history entries (action, timestamp, user_id, notes)

        Example:
            >>> history = client.alerts.history("alert-uuid")
            >>> for entry in history:
            ...     print(f"{entry['action']} at {entry['timestamp']}")
        """
        response = self._get(f"/alerts/{alert_id}/history")
        history: list[dict[str, Any]] = response.get("data", {}).get("history", [])
        return history

    def trends(self, period: str = "7d") -> dict[str, Any]:
        """Get alert volume trends over time.

        Args:
            period: Time period - "24h", "7d", "30d", or "90d" (default "7d")

        Returns:
            Dict with period and trends data

        Example:
            >>> trends = client.alerts.trends(period="30d")
            >>> print(f"Trends for {trends['period']}: {len(trends['trends'])} data points")
        """
        response = self._get("/alerts/trends", params={"period": period})
        data: dict[str, Any] = response.get("data", {})
        return data

    # =========================================================================
    # TECH-771: Alert Preview APIs
    # =========================================================================

    def preview(
        self,
        rule_id: str | None = None,
        event_types: builtins.list[str] | None = None,
        severities: builtins.list[str] | None = None,
        lookback_days: int = 7,
    ) -> AlertPreviewResponse:
        """Preview what alerts would have been sent with a rule configuration.

        Simulates alert rule matching over historical alerts to help understand
        alert volume before enabling a rule.

        Args:
            rule_id: Existing rule UUID to preview (optional)
            event_types: Event types to match (if not using rule_id)
            severities: Severities to match (if not using rule_id)
            lookback_days: Days of history to analyze (default 7)

        Returns:
            AlertPreviewResponse with alert volume simulation

        Example:
            >>> # Preview an existing rule
            >>> result = client.alerts.preview(rule_id="rule-uuid")
            >>> print(f"Matching alerts: {result.alerts_would_match}")
            >>>
            >>> # Preview a hypothetical rule
            >>> result = client.alerts.preview(
            ...     event_types=["freshness_alert"],
            ...     severities=["critical"],
            ...     lookback_days=30,
            ... )
            >>> print(f"By severity: {result.alerts_by_severity}")
        """
        payload: dict[str, Any] = {
            "lookback_days": lookback_days,
        }
        if rule_id is not None:
            payload["rule_id"] = rule_id
        if event_types is not None:
            payload["event_types"] = event_types
        if severities is not None:
            payload["severities"] = severities
        response = self._post("/alerts/preview", json=payload)
        return AlertPreviewResponse.model_validate(response.get("data", {}))

    # =========================================================================
    # TECH-895: Slack OAuth
    # =========================================================================

    def list_slack_connections(self) -> builtins.list[dict[str, Any]]:
        """List connected Slack workspaces.

        Returns a list of OAuth connections available for creating
        Slack alert destinations. Use get_slack_channels() to list
        channels for a specific connection.

        Returns:
            List of connection dicts with id (UUID), team_name,
            connected_at, and is_valid fields.

        Example:
            >>> connections = client.alerts.list_slack_connections()
            >>> for conn in connections:
            ...     print(f"{conn['team_name']} ({conn['id']})")
        """
        response = self._get("/slack/connections")
        connections: builtins.list[dict[str, Any]] = response.get("data", {}).get(
            "connections", []
        )
        return connections

    def get_slack_channels(self, connection_id: str) -> builtins.list[dict[str, Any]]:
        """List channels for a Slack workspace.

        Args:
            connection_id: Connection UUID from list_slack_connections()

        Returns:
            List of channel dicts with id, name, is_member, num_members.

        Example:
            >>> channels = client.alerts.get_slack_channels(conn["id"])
            >>> for ch in channels:
            ...     print(f"#{ch['name']}")
        """
        response = self._get(f"/slack/connections/{connection_id}/channels")
        channels: builtins.list[dict[str, Any]] = response.get("data", {}).get(
            "channels", []
        )
        return channels

    def create_slack_destination(
        self,
        connection_id: str,
        channel_id: str,
        channel_name: str,
        name: str | None = None,
    ) -> AlertDestination:
        """Create an alert destination from a Slack OAuth connection and channel.

        Args:
            connection_id: Connection UUID from list_slack_connections()
            channel_id: Channel ID from get_slack_channels()
            channel_name: Channel name (e.g., "alerts-prod-critical")
            name: Optional display name (defaults to "#channel_name")

        Returns:
            Created AlertDestination

        Example:
            >>> dest = client.alerts.create_slack_destination(
            ...     connection_id=conn["id"],
            ...     channel_id="C0123456",
            ...     channel_name="alerts-prod-critical",
            ... )
        """
        payload: dict[str, Any] = {
            "channel_id": channel_id,
            "channel_name": channel_name,
        }
        if name is not None:
            payload["name"] = name
        response = self._post(
            f"/slack/connections/{connection_id}/destinations", json=payload
        )
        return AlertDestination.model_validate(response.get("data", {}))

    def get_slack_oauth_url(self) -> dict[str, Any]:
        """Get Slack OAuth authorization URL.

        Returns a URL that the user must open in their browser to
        authorize AnomalyArmor in their Slack workspace. After
        authorization, use list_slack_connections() to see the
        new connection.

        Returns:
            Dict with auth_url key.

        Example:
            >>> result = client.alerts.get_slack_oauth_url()
            >>> print(f"Open this URL: {result['auth_url']}")
        """
        response = self._get("/slack/oauth-url")
        data: dict[str, Any] = response.get("data", {})
        return data

    # =========================================================================
    # TECH-895: Rule-Destination Linking
    # =========================================================================

    def list_rule_destinations(self, rule_id: str) -> builtins.list[AlertDestination]:
        """List destinations linked to an alert rule.

        Args:
            rule_id: Rule public UUID

        Returns:
            List of AlertDestination objects linked to the rule.

        Example:
            >>> dests = client.alerts.list_rule_destinations("rule-uuid")
            >>> for d in dests:
            ...     print(f"{d.name} ({d.destination_type})")
        """
        response = self._get(f"/alerts/rules/{rule_id}/destinations")
        data = response.get("data", {}).get("destinations", [])
        return [AlertDestination.model_validate(item) for item in data]

    def link_destinations_to_rule(
        self,
        rule_id: str,
        destination_ids: builtins.list[str],
    ) -> dict[str, Any]:
        """Link one or more destinations to an alert rule.

        Args:
            rule_id: Rule public UUID
            destination_ids: List of destination UUIDs to link

        Returns:
            Dict with linked_count and rule_id.

        Example:
            >>> client.alerts.link_destinations_to_rule(
            ...     "rule-uuid", ["dest-uuid-1", "dest-uuid-2"]
            ... )
        """
        response = self._post(
            f"/alerts/rules/{rule_id}/destinations",
            json={"destination_ids": destination_ids},
        )
        data: dict[str, Any] = response.get("data", {})
        return data

    def unlink_destination_from_rule(
        self,
        rule_id: str,
        destination_id: str,
    ) -> bool:
        """Unlink a destination from an alert rule.

        Args:
            rule_id: Rule public UUID
            destination_id: Destination UUID to unlink

        Returns:
            True if unlinked successfully.

        Example:
            >>> client.alerts.unlink_destination_from_rule(
            ...     "rule-uuid", "dest-uuid"
            ... )
        """
        self._delete(f"/alerts/rules/{rule_id}/destinations/{destination_id}")
        return True

    # =========================================================================
    # TECH-895: Bulk Operations
    # =========================================================================

    def bulk_create_destinations(
        self,
        destinations: builtins.list[dict[str, Any]],
    ) -> builtins.list[AlertDestination]:
        """Create multiple destinations in a single transaction.

        Args:
            destinations: List of dicts, each with name, destination_type,
                and config keys. Maximum 20 per call.

        Returns:
            List of created AlertDestination objects.

        Example:
            >>> dests = client.alerts.bulk_create_destinations([
            ...     {"name": "Email", "destination_type": "email",
            ...      "config": {"email": "ops@example.com"}},
            ...     {"name": "PagerDuty", "destination_type": "pagerduty",
            ...      "config": {"routing_key": "..."}},
            ... ])
        """
        response = self._post(
            "/alerts/destinations/bulk", json={"destinations": destinations}
        )
        data = response.get("data", {}).get("destinations", [])
        return [AlertDestination.model_validate(item) for item in data]

    def bulk_create_slack_destinations(
        self,
        connection_id: str,
        channels: builtins.list[dict[str, str]],
    ) -> builtins.list[AlertDestination]:
        """Create multiple Slack destinations from one OAuth connection.

        Args:
            connection_id: Connection UUID from list_slack_connections()
            channels: List of dicts, each with channel_id and channel_name
                keys, and optional name key. Maximum 20 per call.

        Returns:
            List of created AlertDestination objects.

        Example:
            >>> dests = client.alerts.bulk_create_slack_destinations(
            ...     connection_id=conn["id"],
            ...     channels=[
            ...         {"channel_id": "C01", "channel_name": "alerts-critical"},
            ...         {"channel_id": "C02", "channel_name": "alerts-warning"},
            ...     ],
            ... )
        """
        response = self._post(
            f"/slack/connections/{connection_id}/destinations/bulk",
            json={"channels": channels},
        )
        data = response.get("data", {}).get("destinations", [])
        return [AlertDestination.model_validate(item) for item in data]
