"""Claude OAuth-based OmniComp provider"""

__version__ = "0.0.0a1"
