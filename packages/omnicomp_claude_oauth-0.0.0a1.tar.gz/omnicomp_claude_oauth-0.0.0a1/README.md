# omnicomp-claude-oauth

Claude OAuth-based OmniComp provider
