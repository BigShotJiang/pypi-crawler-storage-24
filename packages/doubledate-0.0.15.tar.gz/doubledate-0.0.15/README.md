[![pythons](https://img.shields.io/badge/python-3.8%20%7C%203.9%20%7C%203.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-blue)](https://pypi.org/project/doubledate)
[![build](https://github.com/dschenck/doubledate/actions/workflows/testing-and-linting.yml/badge.svg?branch=main)](https://github.com/dschenck/doubledate/actions/workflows/testing-and-linting.yml)
[![PyPI version](https://badge.fury.io/py/doubledate.svg)](https://badge.fury.io/py/doubledate)
[![Documentation Status](https://readthedocs.org/projects/doubledate/badge/?version=latest)](https://doubledate.readthedocs.io/en/latest/?badge=latest)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![codecov](https://codecov.io/gh/dschenck/doubledate/graph/badge.svg?token=TIJJGYZYK5)](https://codecov.io/gh/dschenck/doubledate)
[![Downloads](https://static.pepy.tech/badge/doubledate/week)](https://pepy.tech/project/doubledate)

## doubledate: another datetime library

doubledate, yet another datetime library, exposes a set of 20+ utility functions as well as an immutable `Calendar` object representing a sorted-set of dates.

## Documentation

Documentation is hosted on [read the docs](https://doubledate.readthedocs.io/en/latest/)
