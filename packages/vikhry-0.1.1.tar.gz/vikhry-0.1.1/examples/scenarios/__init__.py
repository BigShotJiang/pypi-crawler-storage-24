"""Example load scenarios."""

