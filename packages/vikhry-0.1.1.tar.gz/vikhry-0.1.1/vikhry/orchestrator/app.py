from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path

import redis.asyncio as redis
import uvloop
from robyn import ALLOW_CORS, Robyn

from vikhry.orchestrator.api.routes import register_routes
from vikhry.orchestrator.models.settings import OrchestratorSettings
from vikhry.orchestrator.redis_repo.state_repo import TestStateRepository
from vikhry.orchestrator.scenario_loader import (
    load_on_init_spec_from_scenario,
    load_resource_names_from_scenario,
)
from vikhry.orchestrator.services.lifecycle_service import LifecycleService
from vikhry.orchestrator.services.metrics_service import MetricsService
from vikhry.orchestrator.services.resource_service import ResourceService
from vikhry.orchestrator.services.worker_monitor import WorkerMonitor
from vikhry.orchestrator.services.user_orchestration import UserOrchestrationService
from vikhry.orchestrator.services.worker_presence import WorkerPresenceService
from vikhry.ui_assets import resolve_ui_assets_dir

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class OrchestratorRuntime:
    redis_client: redis.Redis
    state_repo: TestStateRepository
    metrics_service: MetricsService
    resource_service: ResourceService
    lifecycle_service: LifecycleService
    worker_presence: WorkerPresenceService
    user_orchestration: UserOrchestrationService
    worker_monitor: WorkerMonitor
    ui_assets_dir: Path | None


def build_app(settings: OrchestratorSettings) -> tuple[Robyn, OrchestratorRuntime]:
    app = Robyn(file_object=__file__)
    ALLOW_CORS(app, origins="*", headers="*")
    redis_client = redis.Redis.from_url(settings.redis_url, decode_responses=True)
    state_repo = TestStateRepository(redis_client)
    scenario_resource_names = load_resource_names_from_scenario(settings.scenario)
    scenario_on_init_spec = load_on_init_spec_from_scenario(settings.scenario)
    worker_presence = WorkerPresenceService(
        state_repo=state_repo,
        heartbeat_timeout_s=settings.heartbeat_timeout_s,
    )
    metrics_service = MetricsService(
        state_repo=state_repo,
        poll_interval_s=settings.metrics_poll_interval_s,
        window_s=settings.metrics_window_s,
        max_events_per_metric_per_poll=settings.metrics_max_events_per_poll,
        max_recent_events_per_metric=settings.metrics_recent_events_per_metric,
        max_subscriber_queue=settings.metrics_subscriber_queue_size,
    )
    resource_service = ResourceService(
        state_repo=state_repo,
        scenario_resource_names=scenario_resource_names,
        default_prepare_counts={},
    )
    user_orchestration = UserOrchestrationService(
        state_repo=state_repo,
        worker_presence=worker_presence,
    )
    lifecycle_service = LifecycleService(
        state_repo=state_repo,
        user_orchestration=user_orchestration,
        resource_service=resource_service,
        on_before_start_test=metrics_service.reset_for_new_run,
    )
    worker_monitor = WorkerMonitor(
        scan_interval_s=settings.worker_scan_interval_s,
        heartbeat_timeout_s=settings.heartbeat_timeout_s,
        on_tick=worker_presence.refresh_cache,
    )

    runtime = OrchestratorRuntime(
        redis_client=redis_client,
        state_repo=state_repo,
        metrics_service=metrics_service,
        resource_service=resource_service,
        lifecycle_service=lifecycle_service,
        worker_presence=worker_presence,
        user_orchestration=user_orchestration,
        worker_monitor=worker_monitor,
        ui_assets_dir=resolve_ui_assets_dir(),
    )

    register_routes(
        app=app,
        state_repo=state_repo,
        lifecycle_service=lifecycle_service,
        worker_presence=worker_presence,
        resource_service=resource_service,
        metrics_service=metrics_service,
        scenario_on_init_spec=scenario_on_init_spec,
        ui_assets_dir=runtime.ui_assets_dir,
    )

    @app.startup_handler
    async def on_startup() -> None:
        await _wait_for_redis_or_retry(
            redis_client=runtime.redis_client,
            redis_url=settings.redis_url,
            retry_delay_s=5.0,
        )
        await runtime.state_repo.initialize_defaults()
        await runtime.worker_presence.refresh_cache()
        await runtime.metrics_service.start()
        await runtime.metrics_service.refresh_now()
        await runtime.worker_monitor.start()
        if runtime.ui_assets_dir is not None:
            logger.info("UI assets enabled from %s", runtime.ui_assets_dir)
        else:
            logger.info("UI assets are not available; API-only mode is enabled")
        logger.info("orchestrator started")

    @app.shutdown_handler
    async def on_shutdown() -> None:
        await runtime.worker_monitor.stop()
        await runtime.metrics_service.stop()
        await runtime.redis_client.aclose()
        logger.info("orchestrator stopped")

    return app, runtime


def run_orchestrator(settings: OrchestratorSettings) -> None:
    uvloop.install()
    app, _ = build_app(settings)
    app.start(host=settings.host, port=settings.port)


async def _wait_for_redis_or_retry(
    *,
    redis_client: redis.Redis,
    redis_url: str,
    retry_delay_s: float,
) -> None:
    attempt = 1
    while True:
        try:
            await redis_client.ping()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "Redis is unavailable (url=%s, attempt=%s): %s. Retrying in %.1fs",
                redis_url,
                attempt,
                exc,
                retry_delay_s,
            )
            attempt += 1
            await asyncio.sleep(retry_delay_s)
            continue

        if attempt > 1:
            logger.info(
                "Redis connection established after retries (url=%s, attempts=%s)",
                redis_url,
                attempt,
            )
        else:
            logger.info("Redis connectivity check passed (url=%s)", redis_url)
        return
