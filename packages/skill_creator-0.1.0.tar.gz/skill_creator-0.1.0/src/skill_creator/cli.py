"""CLI interface for skill-creator."""

import click


@click.group()
@click.version_option(version="0.1.0")
def main() -> int:
    """Skill Creator - Create, improve, and evaluate skills."""
    return 0


@main.command()
@click.argument("skill_name")
@click.option("--description", "-d", required=True, help="Skill description")
@click.option("--output-dir", "-o", default=".", help="Output directory for skill")
def create(skill_name: str, description: str, output_dir: str) -> int:
    """Create a new skill with the given name and description."""
    from skill_creator._core import create_skill as _create_skill

    _create_skill(skill_name, description, output_dir)
    click.echo(f"Created skill '{skill_name}' in {output_dir}")
    return 0


@main.command()
@click.argument("skill_path")
@click.option("--test-prompts", "-t", multiple=True, help="Test prompts to run")
def evaluate(skill_path: str, test_prompts: tuple[str, ...]) -> int:
    """Evaluate a skill with test prompts."""
    from skill_creator._core import evaluate_skill as _evaluate_skill

    results = _evaluate_skill(skill_path, list(test_prompts))
    for result in results:
        click.echo(f"Eval: {result}")
    return 0


@main.command()
@click.argument("skill_path")
@click.option("--feedback", "-f", required=True, help="User feedback from evaluation")
def improve(skill_path: str, feedback: str) -> int:
    """Improve a skill based on user feedback."""
    from skill_creator._core import improve_skill as _improve_skill

    _improve_skill(skill_path, feedback)
    click.echo(f"Improved skill at {skill_path}")
    return 0


@main.command()
@click.argument("skill_path")
@click.option("--eval-set", "-e", required=True, help="Path to trigger eval JSON")
@click.option("--model", "-m", default="claude-sonnet-4-20250514", help="Model to use")
@click.option(
    "--max-iterations", "-i", default=5, type=int, help="Max optimization iterations"
)
def optimize(skill_path: str, eval_set: str, model: str, max_iterations: int) -> int:
    """Optimize skill description for better triggering."""
    from skill_creator._core import optimize_description

    result = optimize_description(skill_path, eval_set, model, max_iterations)
    click.echo(f"Best description: {result['best_description']}")
    click.echo(f"Test score: {result['test_score']}")
    return 0


@main.command()
@click.argument("skill_path")
@click.option("--output", "-o", required=True, help="Output .skill file path")
def package(skill_path: str, output: str) -> int:
    """Package a skill into a .skill file."""
    from skill_creator._core import package_skill as _package_skill

    _package_skill(skill_path, output)
    click.echo(f"Packaged skill to {output}")
    return 0


@main.command()
@click.argument("workspace")
@click.option("--skill-name", "-s", required=True, help="Skill name for benchmark")
def benchmark(workspace: str, skill_name: str) -> int:
    """Generate benchmark from evaluation results."""
    from skill_creator._scripts.aggregate_benchmark import aggregate

    aggregate(workspace, skill_name)
    click.echo(f"Benchmark generated for {skill_name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
