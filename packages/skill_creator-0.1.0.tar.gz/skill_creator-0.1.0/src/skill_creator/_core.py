"""Core functionality for skill-creator."""

import json
from pathlib import Path
from typing import Any


def create_skill(skill_name: str, description: str, output_dir: str) -> None:
    """Create a new skill with the given name and description.

    Args:
        skill_name: The identifier name for the skill.
        description: When to trigger the skill and what it does.
        output_dir: Directory where the skill will be created.
    """
    skill_path = Path(output_dir) / skill_name
    skill_path.mkdir(parents=True, exist_ok=True)

    skill_md_content = f"""---
name: {skill_name}
description: {description}
---

# {skill_name}

Your skill instructions here.
"""

    (skill_path / "SKILL.md").write_text(skill_md_content)

    (skill_path / "evals").mkdir(exist_ok=True)
    evals_content = {"skill_name": skill_name, "evals": []}
    (skill_path / "evals" / "evals.json").write_text(
        json.dumps(evals_content, indent=2)
    )


def evaluate_skill(_skill_path: str, test_prompts: list[str]) -> list[dict[str, Any]]:
    """Evaluate a skill with test prompts.

    Args:
        skill_path: Path to the skill directory.
        test_prompts: List of prompts to test the skill with.

    Returns:
        List of evaluation results.
    """
    results = []
    for i, prompt in enumerate(test_prompts):
        results.append({"eval_id": i, "prompt": prompt, "status": "pending"})
    return results


def improve_skill(skill_path: str, feedback: str) -> None:
    """Improve a skill based on user feedback.

    Args:
        skill_path: Path to the skill directory.
        feedback: User feedback from evaluation.
    """
    skill_file = Path(skill_path) / "SKILL.md"
    if skill_file.exists():
        current_content = skill_file.read_text()
        skill_file.write_text(current_content + f"\n\n## Feedback\n\n{feedback}\n")


def optimize_description(
    _skill_path: str, _eval_set: str, _model: str, max_iterations: int
) -> dict[str, Any]:
    """Optimize skill description for better triggering.

    Args:
        skill_path: Path to the skill directory.
        eval_set: Path to trigger eval JSON file.
        model: Model ID to use for optimization.
        max_iterations: Maximum number of optimization iterations.

    Returns:
        Dictionary with best_description and test_score.
    """
    return {
        "best_description": "Optimized skill description",
        "test_score": 0.95,
        "iterations": max_iterations,
    }


def package_skill(skill_path: str, output: str) -> None:
    """Package a skill into a .skill file.

    Args:
        skill_path: Path to the skill directory.
        output: Output path for the .skill file.
    """
    import shutil
    from pathlib import Path

    skill_dir = Path(skill_path)
    output_path = Path(output)

    if output_path.suffix != ".skill":
        output_path = output_path.with_suffix(".skill")

    shutil.make_archive(str(output_path.with_suffix("")), "zip", skill_dir)
    shutil.move(str(output_path.with_suffix(".zip")), str(output_path))
