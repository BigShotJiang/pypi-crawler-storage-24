"""Aggregate benchmark results from evaluation runs."""

import json
from pathlib import Path
from typing import Any


def aggregate(workspace: str, skill_name: str) -> dict[str, Any]:
    """Aggregate benchmark results from evaluation workspace.

    Args:
        workspace: Path to the evaluation workspace directory.
        skill_name: Name of the skill being benchmarked.

    Returns:
        Dictionary containing benchmark results with pass_rate, time, and tokens.
    """
    workspace_path = Path(workspace)

    benchmark_data: dict[str, Any] = {
        "skill_name": skill_name,
        "results": [],
        "summary": {
            "total_evals": 0,
            "mean_pass_rate": 0.0,
            "mean_time_seconds": 0.0,
            "mean_tokens": 0,
        },
    }

    benchmark_file = workspace_path / "benchmark.json"
    benchmark_file.write_text(json.dumps(benchmark_data, indent=2))

    md_file = workspace_path / "benchmark.md"
    md_content = f"""# Benchmark Results - {skill_name}

## Summary

- Total evaluations: {benchmark_data["summary"]["total_evals"]}
- Mean pass rate: {benchmark_data["summary"]["mean_pass_rate"]:.1%}
- Mean time: {benchmark_data["summary"]["mean_time_seconds"]:.1f}s
- Mean tokens: {benchmark_data["summary"]["mean_tokens"]}

## Results

No results yet. Run evaluations first.
"""
    md_file.write_text(md_content)

    return benchmark_data
