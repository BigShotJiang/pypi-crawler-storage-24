from skill_creator import cli


def main() -> int:
    result: int = cli.main()
    return result


if __name__ == "__main__":
    raise SystemExit(main())
