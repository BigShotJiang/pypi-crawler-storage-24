# skill-creator

> Create new skills, modify and improve existing skills, and measure skill performance.

[![PyPI](https://img.shields.io/pypi/v/skill-creator.svg)](https://pypi.org/project/skill-creator/)
[![Python](https://img.shields.io/pypi/pyversions/skill-creator.svg)](https://pypi.org/project/skill-creator/)
[![Coverage](https://codecov.io/gh/daedalus/skill-creator/branch/main/graph/badge.svg)](https://codecov.io/gh/daedalus/skill-creator)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

## Install

```bash
pip install skill-creator
```

## Usage

```python
from skill_creator import create_skill, evaluate_skill, improve_skill

# Create a new skill
create_skill("my-skill", "Description of what the skill does", "./output")

# Evaluate a skill
results = evaluate_skill("./my-skill", ["Test prompt 1", "Test prompt 2"])

# Improve based on feedback
improve_skill("./my-skill", "User feedback from evaluation")
```

## CLI

```bash
skill-creator --help
```

### Commands

- `create` - Create a new skill
- `evaluate` - Evaluate a skill with test prompts
- `improve` - Improve a skill based on feedback
- `optimize` - Optimize skill description for better triggering
- `package` - Package a skill into a .skill file
- `benchmark` - Generate benchmark from evaluation results

## Development

```bash
git clone https://github.com/daedalus/skill-creator.git
cd skill-creator
pip install -e ".[test]"

# run tests
pytest

# format
ruff format src/ tests/

# lint
ruff check src/ tests/

# type check
mypy src/
```

## Reference Files

The project includes reference files for skill development:

- `agents/grader.md` - How to evaluate assertions against outputs
- `agents/comparator.md` - How to do blind A/B comparison
- `agents/analyzer.md` - How to analyze benchmark results
- `references/schemas.md` - JSON schemas for evals, benchmarks, etc.
