"""Consolidated Markdown export renderer."""
