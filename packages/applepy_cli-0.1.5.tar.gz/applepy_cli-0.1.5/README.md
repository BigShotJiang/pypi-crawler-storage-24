# 🍎 applepy-cli

**Build tool for [ApplePy](https://github.com/jagtesh/ApplePy)** — scaffold, build, and publish Swift-powered Python packages.

The equivalent of [maturin](https://github.com/PyO3/maturin) for PyO3, but for Swift.

## Install

```bash
# pip
pip install applepy-cli

# uv
uv pip install applepy-cli
```

## Quick Start

```bash
applepy new myproject
cd myproject
applepy develop
python myproject/examples/demo.py
# → Hello, World! 🍎
```

## Commands

| Command | Description |
|---------|-------------|
| `applepy new <name>` | Scaffold a new project with Swift source, `pyproject.toml`, demo |
| `applepy develop` | Build Swift extension and install into current environment |
| `applepy build` | Build a distributable wheel (`.whl`) |
| `applepy publish` | Publish to PyPI (or `--test` for TestPyPI) |

## `applepy new` Options

```bash
applepy new myproject                     # Uses GitHub ApplePy (default)
applepy new myproject --local             # Uses local ApplePy checkout
applepy new myproject --applepy-path ../ApplePy  # Explicit local path
applepy new myproject -d "My description" # Set project description
```

## Generated Project Structure

```
myproject/
├── pyproject.toml
├── setup.py
├── README.md
├── myproject/
│   ├── __init__.py
│   └── examples/demo.py
└── swift/
    ├── Package.swift
    └── Sources/MyProject/MyProject.swift
```

## Requirements

- **macOS** (Apple frameworks require macOS)
- **Swift 6.0+** toolchain
- **Python 3.10+**

## License

BSD-3-Clause © Jagtesh Chadha
