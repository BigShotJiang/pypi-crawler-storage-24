"""
Пример использования TpLogger с FastAPI: middleware для trace_id и dependency для логгера.

Показывает:
- инициализацию фабрики и setup_standard_loggers при старте приложения;
- middleware, который выставляет trace_id из заголовка X-Request-ID или генерирует новый;
- dependency get_request_logger (logger: TpLogger = Depends(get_request_logger)) с trace_id запроса;
- логи в эндпоинтах с автоматическим trace_id в JSON;
- TraceIdMiddleware: trace_id из заголовка/генерация + перехват необработанных исключений с логом.

Запуск из корня репозитория:
    uvicorn tp_common.tp_logger.example.example_fastapi:app --reload --port 8000

Проверка (trace_id попадёт в логи и в заголовок ответа):
    curl -i http://127.0.0.1:8000/
    curl -i -H "X-Request-ID: my-trace-123" http://127.0.0.1:8000/items/1
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.tp_logger.fastapi_integration import (
    TraceIdMiddleware,
    get_request_logger,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    """При старте приложения: фабрика в app.state и настройка uvicorn/fastapi логгеров."""
    env = EnvironmentType.DEV
    app.state.log_factory = TpLoggerFactory(env)
    TpLoggerFactory.setup_standard_loggers(env)
    yield
    # при shutdown при необходимости можно вызвать shutdown логгера


app = FastAPI(title="TpLogger FastAPI example", lifespan=lifespan)

# Middleware: trace_id из заголовка/генерация + перехват необработанных исключений с логом (trace_id в логе).
app.add_middleware(TraceIdMiddleware)


@app.get("/")
def root(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    """Логгер с trace_id текущего запроса (Depends(get_request_logger))."""
    logger.info("Обработка запроса к корню")
    return {"message": "ok", "trace_id": logger.trace_id or ""}


@app.get("/items/{item_id}")
def get_item(
    item_id: int, logger: TpLogger = Depends(get_request_logger)
) -> dict[str, str | int]:
    logger.info("Запрос элемента", extra={"item_id": item_id})
    if item_id < 0:
        logger.warning("Отрицательный item_id", extra={"item_id": item_id})
    return {"item_id": item_id, "trace_id": logger.trace_id or ""}


@app.get("/slow")
async def slow(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    """Асинхронный эндпоинт — dependency работает так же."""
    logger.info("Начало медленной операции")
    import asyncio

    await asyncio.sleep(0.1)
    logger.info("Медленная операция завершена")
    return {"message": "done", "trace_id": logger.trace_id or ""}


@app.get("/error")
def raise_error(logger: TpLogger = Depends(get_request_logger)) -> None:
    """При exception логируется stack trace в JSON (error, error_message, stack_trace)."""
    logger.error("Сейчас выбросим исключение")
    raise ValueError("Пример ошибки для логов")


# Сервис с методом под @retry_forever(max_errors): после N одинаковых ошибок исключение пробрасывается.
class _FlakyService:
    def __init__(self, logger: TpLogger) -> None:
        self.logger = logger

    @retry_forever(
        start_message="Вызов flaky-операции",
        error_message="Ошибка flaky: {e}",
        max_errors=3,
        delay=1,
    )
    async def do_something(self) -> str:
        raise ValueError("Имитация сбоя (после 3 повторов исключение уйдёт в эндпоинт)")


@app.get("/flaky")
async def flaky(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    """
    Вызов метода с @retry_forever(max_errors=3). После 3 одинаковых ошибок исключение
    ловится здесь, пишем ясный лог и отдаём 500.
    """
    from fastapi import HTTPException

    try:
        service = _FlakyService(logger)
        result = await service.do_something()
        return {"result": result}
    except Exception as e:
        logger.exception("Flaky-операция не удалась после повторов: %s", e)
        raise HTTPException(status_code=500, detail="Internal Server Error") from e


@app.get("/explicit")
def explicit_depends(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    logger.debug("Явная зависимость get_request_logger")
    return {"trace_id": logger.trace_id or ""}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "tp_common.tp_logger.example.example_fastapi:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
