# tp_common.devtools

Инструменты для создания и настройки проектов на базе tp-common.

## project_scaffold — новый проект, инициализация и обновление конфигурации

Скрипт поддерживает три сценария. Все команды кроссплатформенные (Linux, macOS, Windows).

### 1. Создание нового проекта с нуля

Проект создаётся через Poetry в режиме «только менеджер зависимостей» (`package-mode = false`). Копируются настройки из [template_project](template_project): pre-commit, alembic, .gitignore, ruff, mypy, pyright. В конце выполняются `poetry install` и `poetry run pre-commit install`.

**Linux / macOS:**

```bash
curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py" | python3 - PROJECT_NAME
```

**Windows (PowerShell):**

```powershell
(Invoke-WebRequest -Uri "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py").Content | python - PROJECT_NAME
```

**Windows (через сохранение скрипта):**

```cmd
curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py" -o scaffold.py
python scaffold.py create PROJECT_NAME
```

### 2. Инициализация уже существующего проекта

Если проект уже создан через `poetry new` (или вручную с `pyproject.toml`):

```bash
poetry new my-project && cd my-project
poetry add tp-common
poetry run tp-bootstrap
```

Без аргументов `tp-bootstrap` выполняет **init** в текущей директории. При этом:

- подтягиваются все файлы шаблона (pre-commit, alembic, .gitignore, ruff, mypy, pyright);
- в `pyproject.toml` добавляются `package-mode = false` и dev-зависимости (линтеры, форматеры);
- выполняются `poetry lock`, `poetry install` и `poetry run pre-commit install`.

Явно:

```bash
poetry run tp-bootstrap init [--target .] [-f]
```

`-f` перезаписывает существующие конфиги из шаблона.

### 3. Обновление конфигурации (без перезаписи)

Подтянуть только отсутствующие конфиги и выровнять dev-зависимости:

```bash
poetry run tp-bootstrap update [--target .] [-f]
```

или:

```bash
poetry run python -m tp_common.devtools.project_scaffold update [--target .] [-f]
```

По умолчанию существующие файлы не перезаписываются; `-f` перезаписывает.

### Требования

- Python 3.12+
- [Poetry](https://python-poetry.org/) установлен и доступен как `python -m poetry`.
