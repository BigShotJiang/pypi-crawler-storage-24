"""
Скрипт для создания нового проекта и инициализации/обновления конфигурации.

Сценарии:

1) Создание нового проекта с нуля (через curl или сохранённый скрипт):

   Linux/macOS:
     curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py" | python3 - PROJECT_NAME

   Windows (PowerShell):
     (Invoke-WebRequest -Uri "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py").Content | python - PROJECT_NAME

   Windows (сохранение скрипта и запуск):
     curl -sSL "..." -o scaffold.py
     python scaffold.py create PROJECT_NAME

   Создаётся директория с Poetry (package-mode = false), конфиги из template_project,
   poetry install и pre-commit install.

2) Инициализация уже существующего проекта (poetry new -> poetry add tp-common -> tp-bootstrap):

   poetry new my-project && cd my-project
   poetry add tp-common
   poetry run tp-bootstrap

   или явно: poetry run tp-bootstrap init [--target .] [-f]

   Подтягиваются все файлы шаблона (pre-commit, alembic, .gitignore, ruff, mypy, pyright),
   в pyproject.toml добавляются package-mode = false и dev-зависимости (линтеры, форматеры),
   выполняется poetry install и poetry run pre-commit install. Кроссплатформенно.

3) Обновление конфигурации (без перезаписи существующих файлов):

   poetry run tp-bootstrap update [--target .] [-f]
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

# Путь к шаблону в репозитории (для загрузки по HTTP)
BASE_URL = "https://gitlab.8525.ru/modules/tp-common/-/raw/main/"
TEMPLATE_REL = "src/tp_common/devtools/template_project"

# Файлы шаблона: (путь в template_project,) или (источник, назначение)
TEMPLATE_FILES: list[tuple[str, str]] = [
    (".gitignore", ".gitignore"),
    (".pre-commit-config.yaml", ".pre-commit-config.yaml"),
    ("ruff.toml", "ruff.toml"),
    ("mypy.ini", "mypy.ini"),
    ("pyrightconfig.json", "pyrightconfig.json"),
    ("alembic/README", "alembic/README"),
    ("alembic/env.py.example", "alembic/env.py"),
    ("alembic/run.cmd", "alembic/run.cmd"),
    ("alembic/script.py.mako", "alembic/script.py.mako"),
]

# Обязательные dev-зависимости: всегда добавляются при init/update (версии по умолчанию, если нет источника)
REQUIRED_DEV_DEPS: dict[str, str] = {
    "black": 'black = "^25.12.0"',
    "ruff": 'ruff = "^0.13.0"',
    "mypy": 'mypy = "^1.19.1"',
    "pyright": 'pyright = "^1.1.408"',
    "pre-commit": 'pre-commit = "^4.3.0"',
}

# Минимальный pyproject.toml для нового проекта (только менеджер зависимостей)
PYPROJECT_TEMPLATE = """[tool.poetry]
name = "{name}"
version = "0.1.0"
description = ""
authors = []
readme = "README.md"
package-mode = false

[tool.poetry.dependencies]
python = ">=3.12"
tp-common = "*"

[tool.poetry.group.dev.dependencies]
ruff = "^0.13.0"
pre-commit = "^4.3.0"
pylint = "^3.3.8"
mypy = "^1.19.1"
pyright = "^1.1.408"
black = "^25.12.0"
pytest = "^8.0.0"

[build-system]
requires = ["poetry-core>=2.0.0,<3.0.0"]
build-backend = "poetry.core.masonry.api"
"""


def _template_dir() -> Path | None:
    """Путь к template_project рядом со скриптом (если запущен из пакета)."""
    try:
        this_file = Path(__file__).resolve()
    except NameError:
        return None
    candidate = this_file.parent / "template_project"
    return candidate if candidate.is_dir() else None


def _http_get(relative_path: str) -> str:
    url = f"{BASE_URL}{TEMPLATE_REL}/{relative_path}"
    try:
        with urlopen(url) as resp:
            return resp.read().decode("utf-8")
    except URLError as exc:
        raise RuntimeError(f"Не удалось скачать {relative_path!r}: {exc}") from exc


def _copy_template_to_target(
    target_root: Path,
    *,
    force: bool = False,
    from_package: bool = True,
) -> None:
    """Копирует файлы шаблона в target_root. from_package=False — качать по HTTP."""
    template_dir = _template_dir() if from_package else None

    for src_rel, dest_rel in TEMPLATE_FILES:
        dest = target_root / dest_rel
        if dest.is_file() and not force:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)

        if template_dir is not None:
            src_file = template_dir / src_rel
            if not src_file.is_file():
                content = _http_get(src_rel)
            else:
                content = src_file.read_text(encoding="utf-8")
        else:
            content = _http_get(src_rel)

        dest.write_text(content, encoding="utf-8")

    # Пустая директория alembic/versions
    (target_root / "alembic" / "versions").mkdir(parents=True, exist_ok=True)


POETRY_NOT_FOUND_MSG = (
    "Poetry не найден. Установите: https://python-poetry.org/docs/#installation "
    "и добавьте poetry в PATH, либо запускайте скрипт тем интерпретатором Python, "
    "в окружении которого установлен poetry (не из виртуального окружения проекта)."
)


def _poetry_cmd_base() -> list[str]:
    """Возвращает команду для запуска poetry: сначала из PATH, иначе python -m poetry."""
    if shutil.which("poetry") is not None:
        return ["poetry"]
    return [sys.executable, "-m", "poetry"]


def _run_poetry(cwd: Path, *args: str) -> None:
    """Запускает poetry в cwd. Сначала ищет бинарник в PATH, иначе python -m poetry. Кроссплатформенно."""
    base = _poetry_cmd_base()
    cmd = [*base, *args]
    use_capture = base[0] != "poetry"
    result = subprocess.run(
        cmd,
        cwd=cwd,
        shell=False,
        capture_output=use_capture,
        text=use_capture,
    )
    if result.returncode == 0:
        return
    if use_capture and result.stderr and "No module named poetry" in result.stderr:
        raise RuntimeError(POETRY_NOT_FOUND_MSG)
    raise RuntimeError(f"poetry завершился с кодом {result.returncode}")


def _run_precommit_install(cwd: Path) -> None:
    """Запускает poetry run pre-commit install в cwd. Кроссплатформенно."""
    base = _poetry_cmd_base()
    cmd = [*base, "run", "pre-commit", "install"]
    use_capture = base[0] != "poetry"
    result = subprocess.run(
        cmd,
        cwd=cwd,
        shell=False,
        capture_output=use_capture,
        text=use_capture,
    )
    if result.returncode == 0:
        return
    if use_capture and result.stderr and "No module named poetry" in result.stderr:
        raise RuntimeError(POETRY_NOT_FOUND_MSG)
    print(
        "Предупреждение: pre-commit install завершился с ошибкой (например, нет git-репозитория)."
    )
    print("Выполните вручную: poetry run pre-commit install")


def _ensure_package_mode_false(target_root: Path) -> None:
    """Добавляет или выставляет package-mode = false в [tool.poetry] в pyproject.toml."""
    pyproject = target_root / "pyproject.toml"
    if not pyproject.is_file():
        return
    lines = pyproject.read_text(encoding="utf-8").splitlines()
    header = "[tool.poetry]"
    new_line = "package-mode = false"
    idx = None
    for i, line in enumerate(lines):
        if line.strip() == header:
            idx = i
            break
    if idx is None:
        return
    # Ищем конец секции [tool.poetry] и есть ли уже package-mode
    start = idx + 1
    has_package_mode = False
    package_mode_line_idx = None
    for i in range(start, len(lines)):
        stripped = lines[i].strip()
        if stripped.startswith("[") and not stripped.startswith("#["):
            break
        if stripped.startswith("package-mode"):
            has_package_mode = True
            package_mode_line_idx = i
        i + 1
    if has_package_mode and package_mode_line_idx is not None:
        # Проверяем значение
        if "false" in lines[package_mode_line_idx].lower():
            return
        lines[package_mode_line_idx] = new_line
    else:
        # Вставляем после заголовка [tool.poetry]
        lines.insert(idx + 1, new_line)
    pyproject.write_text("\n".join(lines) + "\n", encoding="utf-8")


def cmd_create(project_name: str, target_parent: Path) -> None:
    """Создаёт новый проект с указанным именем в target_parent."""
    project_name = project_name.strip()
    if not project_name or "/" in project_name or "\\" in project_name:
        raise ValueError("Некорректное имя проекта")

    project_root = (target_parent / project_name).resolve()
    if project_root.exists():
        raise FileExistsError(f"Директория уже существует: {project_root}")

    project_root.mkdir(parents=True)

    # pyproject.toml без пакетной структуры
    pyproject = project_root / "pyproject.toml"
    pyproject.write_text(
        PYPROJECT_TEMPLATE.format(name=project_name),
        encoding="utf-8",
    )

    # Копируем шаблон (при создании через curl шаблон только по HTTP)
    from_package = _template_dir() is not None
    _copy_template_to_target(project_root, force=True, from_package=from_package)

    # Минимальная структура: src для линтеров
    (project_root / "src").mkdir(exist_ok=True)
    readme = project_root / "README.md"
    if not readme.exists():
        readme.write_text(f"# {project_name}\n", encoding="utf-8")

    _run_poetry(project_root, "lock", "--no-interaction")
    _run_poetry(project_root, "install", "--no-interaction")
    _run_precommit_install(project_root)

    print(f"Проект создан: {project_root}")


def cmd_init(target_root: Path, force: bool) -> None:
    """Инициализирует существующий проект: конфиги, package-mode = false, dev-зависимости, pre-commit."""
    target_root = target_root.resolve()
    if not target_root.is_dir():
        raise NotADirectoryError(f"Не директория: {target_root}")
    pyproject = target_root / "pyproject.toml"
    if not pyproject.is_file():
        raise FileNotFoundError(
            "В директории нет pyproject.toml. Создайте проект через poetry new или poetry init, "
            "затем poetry add tp-common и снова запустите tp-bootstrap init."
        )

    from_package = _template_dir() is not None
    _copy_template_to_target(target_root, force=force, from_package=from_package)
    _ensure_package_mode_false(target_root)
    _sync_dev_deps(target_root)

    _run_poetry(target_root, "lock", "--no-interaction")
    _run_poetry(target_root, "install", "--no-interaction")
    _run_precommit_install(target_root)

    print("Проект инициализирован: пре-коммиты и конфиги установлены.")


def cmd_update(target_root: Path, force: bool) -> None:
    """Обновляет конфигурацию проекта из шаблона (не перезаписывает существующие, если не --force)."""
    target_root = target_root.resolve()
    if not target_root.is_dir():
        raise NotADirectoryError(f"Не директория: {target_root}")

    from_package = _template_dir() is not None
    _copy_template_to_target(target_root, force=force, from_package=from_package)

    # Синхронизация dev-зависимостей (black, ruff, mypy, pyright, pre-commit и при возможности остальные из tp-common)
    target_pyproject = target_root / "pyproject.toml"
    if target_pyproject.is_file():
        _sync_dev_deps(target_root)

    print("Конфигурация обновлена.")


def _sync_dev_deps(target_root: Path) -> None:
    """Добавляет/обновляет dev-зависимости в целевом pyproject: black, ruff, mypy, pyright, pre-commit всегда; при наличии источника — остальные из tp-common."""
    target_pyproject = target_root / "pyproject.toml"
    if not target_pyproject.is_file():
        return

    section = "[tool.poetry.group.dev.dependencies]"
    # Сначала обязательные (всегда добавляем), затем опциональные из источника
    optional_keys = ("pylint", "pytest")
    required_keys = tuple(REQUIRED_DEV_DEPS.keys())

    source_deps: dict[str, str] = {}
    template_dir = _template_dir()
    if template_dir is not None:
        repo_root = template_dir.parent.parent.parent.parent
        source_pyproject = repo_root / "pyproject.toml"
        if source_pyproject.is_file():
            src_text = source_pyproject.read_text(encoding="utf-8")
            src_lines = src_text.splitlines()
            src_idx = _find_section(src_lines, section)
            if src_idx is not None:
                src_start, src_end = _section_range(src_lines, src_idx)
                for line in src_lines[src_start:src_end]:
                    s = line.strip()
                    if not s or s.startswith("#"):
                        continue
                    for key in required_keys + optional_keys:
                        if s.startswith(f"{key} ") or s.startswith(f"{key}="):
                            source_deps[key] = line
                            break

    # Итоговый набор: обязательные из источника или дефолт, плюс опциональные из источника
    merged: dict[str, str] = {}
    for k in required_keys:
        merged[k] = source_deps.get(k) or REQUIRED_DEV_DEPS[k]
    for k in optional_keys:
        if k in source_deps:
            merged[k] = source_deps[k]

    tgt_lines = target_pyproject.read_text(encoding="utf-8").splitlines()
    tgt_idx = _find_section(tgt_lines, section)
    if tgt_idx is None:
        if tgt_lines and tgt_lines[-1].strip():
            tgt_lines.append("")
        tgt_lines.append(section)
        for k in required_keys + optional_keys:
            if k in merged:
                tgt_lines.append(merged[k])
        target_pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")
        return

    tgt_start, tgt_end = _section_range(tgt_lines, tgt_idx)
    for key in required_keys + optional_keys:
        _l = merged.get(key)
        if _l is None:
            continue
        line = _l

        found = False
        for i in range(tgt_start, tgt_end):
            if tgt_lines[i].strip().startswith(f"{key} ") or tgt_lines[
                i
            ].strip().startswith(f"{key}="):
                tgt_lines[i] = line
                found = True
                break
        if not found:
            tgt_lines.insert(tgt_end, line)
            tgt_end += 1

    target_pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")


def _find_section(lines: list[str], header: str) -> int | None:
    for i, line in enumerate(lines):
        if line.strip() == header:
            return i
    return None


def _section_range(lines: list[str], start: int) -> tuple[int, int]:
    end = start + 1
    for i in range(end, len(lines)):
        if lines[i].strip().startswith("[") and not lines[i].strip().startswith("#["):
            return end, i
    return end, len(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Создание нового проекта или обновление конфигурации из tp-common.",
        epilog=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Команда")

    create_parser = subparsers.add_parser("create", help="Создать новый проект")
    create_parser.add_argument(
        "project_name",
        help="Имя проекта (имя директории)",
    )
    create_parser.add_argument(
        "-t",
        "--target",
        type=Path,
        default=Path("."),
        help="Родительская директория для нового проекта (по умолчанию текущая)",
    )

    init_parser = subparsers.add_parser(
        "init",
        help="Инициализировать существующий проект (конфиги, package-mode, dev-зависимости, pre-commit)",
    )
    init_parser.add_argument(
        "-t",
        "--target",
        type=Path,
        default=Path("."),
        help="Корень проекта (по умолчанию текущая директория)",
    )
    init_parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Перезаписать существующие конфиги из шаблона",
    )

    update_parser = subparsers.add_parser(
        "update", help="Обновить конфигурацию текущего проекта"
    )
    update_parser.add_argument(
        "-t",
        "--target",
        type=Path,
        default=Path("."),
        help="Корень проекта (по умолчанию текущая директория)",
    )
    update_parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Перезаписать существующие конфиги",
    )

    # Удобство: один аргумент без подкоманды = create (для curl | python - PROJECT_NAME)
    argv = sys.argv[1:]
    if argv:
        if argv[0] == "-" and len(argv) >= 2:
            argv = ["create", argv[1]] + argv[2:]
        elif argv[0] not in ("create", "update", "init") and not argv[0].startswith(
            "-"
        ):
            argv = ["create", argv[0]] + argv[1:]
    else:
        # Без аргументов — инициализация текущей директории (poetry run tp-bootstrap)
        argv = ["init"]

    args = parser.parse_args(argv)

    if args.command == "create":
        cmd_create(args.project_name, args.target)
    elif args.command == "init":
        cmd_init(args.target, args.force)
    elif args.command == "update":
        cmd_update(args.target, args.force)
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
