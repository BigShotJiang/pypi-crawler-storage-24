"""
Пример FastAPI: эндпоинт списка событий с timestamp по дате.

GET /events возвращает сообщения с указанной даты (timestamp в мс).
Варианты ответа:
  - 200: успех, схема {"messages": [...], "next_timestamp": <ms>}. messages может быть пустым,
    если за таймаут не пришло сообщений. Следующий запрос — с timestamp=next_timestamp.
  - 500: ошибка (например, после исчерпания повторов при сбоях Kafka); в логе trace_id.

Запуск (из корня репозитория, Kafka должен быть доступен):
  uvicorn tp_common.kafka.examples.main:app --reload --port 8000

Примеры запросов (timestamp в мс, source_system обязателен):
  curl "http://127.0.0.1:8000/events?timestamp=1710000000000&source_system=my_client&limit=100"
"""

import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse, Response

from tp_common.kafka.connector import KafkaConnector
from tp_common.kafka.examples.service import ExampleEventService
from tp_common.tp_logger.fastapi_integration import (
    TraceIdMiddleware,
    get_request_logger,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory

logging.basicConfig(level=logging.INFO)
logger_factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
logger = logger_factory.get_logger("example_api")


def get_kafka_connector() -> KafkaConnector:
    url = os.environ.get("KAFKA_URL", "plaintext://localhost:9092")
    return KafkaConnector(url, logger=logger)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    app.state.log_factory = logger_factory
    TpLoggerFactory.setup_standard_loggers(EnvironmentType.LOCAL)
    yield


app = FastAPI(
    title="Example Events API (список с timestamp)",
    description="Эндпоинт /events возвращает список сообщений с указанной даты (timestamp).",
    lifespan=lifespan,
)
app.add_middleware(TraceIdMiddleware)


@app.get(
    "/events",
    summary="Список сообщений с даты (timestamp)",
    description="Возвращает сообщения с timestamp >= timestamp. "
    "Три варианта: 200 — схема с messages (может быть пустой) и next_timestamp; "
    "500 — ошибка после повторов (Kafka/таймаут и т.д.), в логе trace_id. "
    "timeout — максимум секунд ожидания чтения (по умолчанию 25).",
)
async def events_list(
    logger: TpLogger = Depends(get_request_logger),
    timestamp: int = Query(
        ...,
        description="Начальная дата: timestamp в миллисекундах (UTC).",
    ),
    source_system: str = Query(
        ...,
        description="Система-источник: топик example.events.<source_system>.",
    ),
    limit: int | None = Query(
        default=None,
        ge=1,
        le=10_000,
        description="Максимум сообщений в ответе (без ограничения, если не задан).",
    ),
    timeout: float = Query(
        default=25.0,
        ge=1.0,
        le=120.0,
        description="Максимум секунд ожидания чтения из Kafka (таймаут запроса).",
    ),
) -> Response:
    connector = get_kafka_connector()
    async with ExampleEventService(
        connector=connector,
        logger=logger,
        consumer_group="example_events_list_api",
        source_system=source_system,
    ) as service:
        try:
            async with service.subscription():
                messages, next_timestamp = await service.read_from_timestamp_ready(
                    timestamp,
                    limit=limit,
                    read_timeout_sec=timeout,
                    assignment_timeout_sec=15.0,
                )
            payload = {
                "messages": [m.model_dump(mode="json") for m in messages],
                "next_timestamp": next_timestamp,
            }
            return JSONResponse(content=payload)
        except Exception as e:
            logger.exception(
                "Чтение событий не удалось (исчерпаны повторы или ошибка): %s", e
            )
            raise HTTPException(status_code=500, detail="Internal Server Error") from e


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}
