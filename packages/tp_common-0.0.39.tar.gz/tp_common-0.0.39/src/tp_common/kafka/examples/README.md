# Примеры: продюсер и FastAPI long-polling

Для запуска примеров нужен доступный Kafka.

**Проверка всего процесса одним запуском:**

```bash
python -m tp_common.kafka.examples.run_full_flow
```

Скрипт поднимает API, запускает продюсер, делает запрос к `/events` и выводит ответ.

## 1. Продюсер (запись событий)

Пишет три тестовых сообщения в топик `example.events` (или `example.events.<SOURCE_SYSTEM>`).

```bash
export KAFKA_URL="plaintext://localhost:9092"   # при необходимости
export SOURCE_SYSTEM="my_client"                # опционально: топик example.events.my_client
python -m tp_common.kafka.examples.producer
```

## 2. FastAPI с long-polling

Эндпоинт `GET /events` ждёт одно событие до `timeout` секунд. Если событие пришло — 200 + JSON, иначе 204.

```bash
uvicorn tp_common.kafka.examples.main:app --reload --port 8000
```

Примеры запросов:

- `curl "http://127.0.0.1:8000/events?timeout=30"` — ждать до 30 сек
- `curl "http://127.0.0.1:8000/events?timeout=5&source_system=my_client"` — топик для системы `my_client`

Порядок проверки:

1. Запустить Kafka.
2. Запустить API: `uvicorn tp_common.kafka.examples.main:app --port 8000`
3. В другом терминале: `python -m tp_common.kafka.examples.producer`
4. Сразу после этого: `curl "http://127.0.0.1:8000/events?timeout=10"` — должен вернуть 200 и JSON события (если consumer успел подписаться до отправки, иначе повторить запрос и снова запустить producer).
