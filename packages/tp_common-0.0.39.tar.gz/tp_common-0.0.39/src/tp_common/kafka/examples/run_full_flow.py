"""
Один файл для проверки процесса целиком: API → продюсер → запрос к API → ответ.

Подключение к Kafka задаётся константой KAFKA_URL ниже в скрипте.

Запуск (Kafka должен быть доступен):
  python -m tp_common.kafka.examples.run_full_flow

Скрипт:
  1. Поднимает FastAPI (uvicorn) на порту 8765
  2. Ждёт готовности API, прогревает топик
  3. Запускает продюсер в фоне, затем GET /events?timestamp=<мс> — возвращается список сообщений и next_timestamp
  4. Останавливает сервер

Если «API не поднялся за отведённое время» — в лог выводится stderr uvicorn.
Частые причины: порт занят, Kafka недоступен при импорте, ошибка импорта модуля.
"""

import asyncio
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory

_logger_factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
logger = _logger_factory.get_logger("run_full_flow")

# Подключение к Kafka — задайте свой URL здесь
# KAFKA_URL = "plaintext://localhost:9092"
KAFKA_URL = "sasl_plaintext://user:user1122@@192.168.81.61:9094"
SOURCE_SYSTEM = "test"

PORT = 8765
BASE_URL = f"http://127.0.0.1:{PORT}"
HEALTH_URL = f"{BASE_URL}/health"
REQUEST_TIMEOUT = 35
PRODUCER_DELAY_SEC = 2


def wait_for_server(max_attempts: int = 60, interval: float = 0.5) -> bool:
    for _i in range(max_attempts):
        try:
            req = urllib.request.Request(HEALTH_URL, method="GET")
            with urllib.request.urlopen(req, timeout=2) as r:
                if r.status == 200:
                    logger.info("API готов")
                    return True
        except (urllib.error.URLError, OSError) as e:
            logger.debug("Ожидание API: %s", e, exc_info=False)
        time.sleep(interval)
    return False


def delete_topic(kafka_url: str, source_system: str) -> None:
    """Удаляет топик через Kafka Admin API (игнорирует, если топика нет)."""
    from tp_common.kafka.connector import KafkaConnector

    topic_name = f"example.events.{source_system}"
    connector = KafkaConnector(kafka_url, logger=logger)
    admin = connector.get_admin_client()
    fs = admin.delete_topics([topic_name])
    for topic, f in fs.items():
        try:
            f.result(timeout=10)
            logger.info("Топик удалён: %s", topic)
        except Exception as e:
            if "unknown topic" in str(e).lower() or "topic_not_found" in str(e).lower():
                logger.debug("Топик не существовал: %s", topic)
            else:
                logger.warning("Удаление топика %s: %s", topic, e)


def ensure_topic(kafka_url: str, source_system: str) -> None:
    """Создаёт топик через Kafka Admin API, если его ещё нет."""
    from confluent_kafka.cimpl import NewTopic

    from tp_common.kafka.connector import KafkaConnector

    topic_name = f"example.events.{source_system}"
    connector = KafkaConnector(kafka_url, logger=logger)
    admin = connector.get_admin_client()
    fs = admin.create_topics(
        [NewTopic(topic_name, num_partitions=1, replication_factor=1)]
    )
    for topic, f in fs.items():
        try:
            f.result(timeout=10)
            logger.info("Топик создан: %s", topic)
        except Exception as e:
            if (
                "already exists" in str(e).lower()
                or "topic_already_exists" in str(e).lower()
            ):
                logger.info("Топик уже существует: %s", topic)
            else:
                logger.warning("Создание топика %s: %s", topic, e)


def run_producer(kafka_url: str, source_system: str) -> None:
    """Запуск продюсера в отдельном потоке: коннектор создаётся здесь из kafka_url."""
    time.sleep(PRODUCER_DELAY_SEC)
    from tp_common.kafka.connector import KafkaConnector
    from tp_common.kafka.examples.producer import send_example_events

    logger.info("Запуск продюсера (source_system=%s)...", source_system)
    connector = KafkaConnector(kafka_url, logger=logger)
    asyncio.run(send_example_events(connector, logger, source_system=source_system))
    logger.info("Продюсер завершил отправку")


def main() -> int:
    kafka_url = KAFKA_URL
    logger.info("Kafka: %s", kafka_url)
    logger.info("Запуск API на порту %s...", PORT)
    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "tp_common.kafka.examples.main:app",
            "--port",
            str(PORT),
            "--host",
            "127.0.0.1",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        env={**os.environ, "KAFKA_URL": kafka_url},
    )
    try:
        if not wait_for_server():
            logger.error("API не поднялся за отведённое время")
            if proc.stderr:
                try:
                    err = proc.stderr.read().decode("utf-8", errors="replace")
                    if err:
                        logger.error("Вывод uvicorn (stderr):\n%s", err.strip())
                except Exception as e:
                    logger.warning("Не удалось прочитать stderr процесса: %s", e)
            return 1

        delete_topic(kafka_url, SOURCE_SYSTEM)
        time.sleep(1)
        ensure_topic(kafka_url, SOURCE_SYSTEM)

        producer_thread = threading.Thread(
            target=run_producer, args=(kafka_url, SOURCE_SYSTEM), daemon=True
        )
        producer_thread.start()
        time.sleep(PRODUCER_DELAY_SEC + 2)

        timestamp_ms = int((time.time() - 300) * 1000)
        events_url = (
            f"{BASE_URL}/events?timestamp={timestamp_ms}&source_system={SOURCE_SYSTEM}"
        )
        logger.info("Запрос GET %s", events_url)
        req = urllib.request.Request(events_url, method="GET")
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as r:
            body = r.read().decode("utf-8")
            logger.info("Ответ: HTTP %s", r.status)
            if body:
                logger.info("Тело ответа (messages + next_timestamp):\n%s", body)
                print(body)
            else:
                logger.info("Тело пустое")
        return 0
    except urllib.error.HTTPError as e:
        logger.info("Ответ: HTTP %s", e.code)
        body = e.read().decode("utf-8") if e.fp else ""
        if body:
            logger.info("Тело ответа:\n%s", body)
            print(body)
        return 0 if e.code in (200, 204) else 1
    except urllib.error.URLError as e:
        logger.error("Ошибка запроса: %s", e)
        return 1
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        logger.info("Сервер остановлен")


if __name__ == "__main__":
    sys.exit(main())
