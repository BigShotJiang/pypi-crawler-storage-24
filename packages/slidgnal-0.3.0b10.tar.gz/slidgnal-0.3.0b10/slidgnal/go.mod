module codeberg.org/slidge/slidgnal/slidgnal

go 1.25.0

require (
	github.com/go-python/gopy v0.4.10
	github.com/google/uuid v1.6.0
	github.com/h2non/filetype v1.1.3
	github.com/mattn/go-sqlite3 v1.14.37
	github.com/rs/zerolog v1.34.0
	go.mau.fi/mautrix-signal v0.2603.0
	go.mau.fi/util v0.9.7
)

require (
	github.com/coder/websocket v1.8.14 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mattn/go-pointer v0.0.1 // indirect
	github.com/petermattis/goid v0.0.0-20260226131333-17d1149c6ac6 // indirect
	github.com/tidwall/gjson v1.18.0 // indirect
	github.com/tidwall/match v1.2.0 // indirect
	github.com/tidwall/pretty v1.2.1 // indirect
	golang.org/x/crypto v0.49.0 // indirect
	golang.org/x/exp v0.0.0-20260312153236-7ab1446f8b90 // indirect
	golang.org/x/sys v0.42.0 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)
