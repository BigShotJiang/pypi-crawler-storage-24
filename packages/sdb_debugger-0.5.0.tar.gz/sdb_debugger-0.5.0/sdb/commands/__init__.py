#
# Copyright 2019 Delphix
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import glob
import importlib
import os

for path in glob.glob(f"{os.path.dirname(__file__)}/*.py"):
    if path != __file__:
        module = os.path.splitext(os.path.basename(path))[0]
        importlib.import_module(f"sdb.commands.{module}")

for path in glob.glob(f"{os.path.dirname(__file__)}/*/__init__.py"):
    module = os.path.basename(os.path.dirname(path))
    importlib.import_module(f"sdb.commands.{module}")
