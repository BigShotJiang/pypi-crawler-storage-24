"""TuringPulse SDK integration for AWS Bedrock."""

from ._wrapper import patch_bedrock, unpatch_bedrock

__version__ = "0.1.0"
__all__ = ["patch_bedrock", "unpatch_bedrock"]
