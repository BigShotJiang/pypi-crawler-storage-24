# turingpulse-sdk-bedrock

TuringPulse SDK integration for AWS Bedrock — automatic tracing for Bedrock Converse API calls.

## Installation

```bash
pip install turingpulse-sdk-bedrock
```

## Quick Start

```python
import boto3
from turingpulse_sdk import init, TuringPulseConfig
from turingpulse_sdk_bedrock import patch_bedrock

init(TuringPulseConfig(api_key="sk_live_...", workflow_name="my-project"))
patch_bedrock(name="my-project")

client = boto3.client("bedrock-runtime")
response = client.converse(
    modelId="anthropic.claude-3-sonnet-20240229-v1:0",
    messages=[{"role": "user", "content": [{"text": "Hello!"}]}]
)
```

## Documentation

Full documentation: [turingpulse.ai/docs/sdk/bedrock](https://turingpulse.ai/docs/sdk/bedrock)

## Requirements

- Python >= 3.11
- turingpulse-sdk >= 1.0.0
- boto3 >= 1.35.0
