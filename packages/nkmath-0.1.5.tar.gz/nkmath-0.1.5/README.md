# nkmath

nkmath is a simple Python math utility library that provides basic mathematical helper functions for beginners and small projects.

## Features
- Basic arithmetic helpers
- Easy to use
- Lightweight
- Use 
```bash
nkmath.help() 
```
- for list of commands

## Installation
```bash
pip install nkmath
