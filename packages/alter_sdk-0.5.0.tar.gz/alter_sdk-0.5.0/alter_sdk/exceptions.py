"""
Exception hierarchy for Alter SDK.

All exceptions inherit from AlterSDKError for easy catching.
The hierarchy is organized by **developer action** — what you should do
when you catch each error:

AlterSDKError
├── BackendError                         # Alter Vault backend returned an error
│   ├── ReAuthRequiredError              # User must re-authorize via Alter Connect
│   │   ├── ConnectionExpiredError       # TTL elapsed
│   │   ├── ConnectionRevokedError       # Auth permanently broken
│   │   └── ConnectionDeletedError       # User disconnected via Wallet
│   ├── ConnectionNotFoundError          # Wrong connection_id — fix your code
│   └── PolicyViolationError             # Policy denied — may resolve on its own
├── ConnectFlowError                     # Connect flow failed
│   ├── ConnectDeniedError               # User clicked Deny
│   ├── ConnectConfigError               # OAuth app misconfigured
│   └── ConnectTimeoutError              # User didn't complete in time
├── ProviderAPIError                     # Provider returned 4xx/5xx
│   └── ScopeReauthRequiredError        # 403 + scope mismatch, user must re-authorize
└── NetworkError                         # Connection/timeout errors
    └── TimeoutError                     # Request timed out
"""

from typing import Any


class AlterSDKError(Exception):
    """Base exception for all Alter SDK errors."""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        """Initialize exception with message and optional details."""
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        """Return string representation."""
        if self.details:
            return f"{self.message} (details: {self.details})"
        return self.message


# ============================================================================
# Backend Errors — Alter Vault backend returned an error
# ============================================================================


class BackendError(AlterSDKError):
    """Raised when the Alter Vault backend returns an error."""


class ReAuthRequiredError(BackendError):
    """
    Raised when the user must re-authorize via Alter Connect.

    This is the parent class for all errors that require the user to go through
    the Connect flow again. Catch this to handle all re-auth cases in one place.
    """


class ConnectionExpiredError(ReAuthRequiredError):
    """
    Raised when a connection's TTL has expired.

    The time-limited access granted during the Connect flow has elapsed.
    The user must re-authorize to restore access.
    """

    def __init__(
        self,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Initialize with expiry details."""
        super().__init__(message, details)


class ConnectionRevokedError(ReAuthRequiredError):
    """
    Raised when a connection's auth is permanently broken.

    This happens when:
    - The user revoked your app at the provider (e.g., Google Account settings)
    - The refresh token expired or was invalidated
    - Token refresh permanently failed (invalid_grant)

    The user must re-authorize via Alter Connect.
    """

    def __init__(
        self,
        message: str,
        connection_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Initialize with revoked connection details."""
        super().__init__(message, details)
        self.connection_id = connection_id


class ConnectionDeletedError(ReAuthRequiredError):
    """
    Raised when a connection has been deliberately deleted.

    The end user disconnected the account via the Wallet dashboard.
    Re-authorization via Alter Connect will generate a **new** ``connection_id``
    — update your stored reference from the ``ConnectResult``.
    """


class ConnectionNotFoundError(BackendError):
    """
    Raised when OAuth connection not found.

    No connection exists for the given connection_id.
    Check for typos or stale references.
    """


class PolicyViolationError(BackendError):
    """
    Raised when token access is denied by policy enforcement.

    The connection exists but access was denied by a Cerbos policy
    (e.g., outside business hours, IP allowlist, rate limit exceeded).
    This may resolve on its own (e.g., wait until business hours).
    """

    def __init__(
        self,
        message: str,
        policy_error: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Initialize with policy violation details."""
        super().__init__(message, details)
        self.policy_error = policy_error


# ============================================================================
# Connect Flow Errors — OAuth connect flow failed
# ============================================================================


class ConnectFlowError(AlterSDKError):
    """
    Raised when the headless connect() flow fails.

    This can happen when:
    - The user denies authorization
    - The provider returns an error
    - The OAuth app is misconfigured
    - The session expires before completion
    """


class ConnectDeniedError(ConnectFlowError):
    """
    Raised when the user denies authorization during the Connect flow.

    The user explicitly clicked "Deny" or "Cancel" on the provider's
    authorization page.
    """


class ConnectConfigError(ConnectFlowError):
    """
    Raised when the OAuth app is misconfigured.

    Check your OAuth app configuration in the Developer Portal.
    Common causes: wrong redirect URI, invalid client ID/secret.
    """


class ConnectTimeoutError(ConnectFlowError):
    """
    Raised when the connect() flow times out.

    The user did not complete OAuth within the specified timeout period.
    """


# ============================================================================
# Provider & Network Errors
# ============================================================================


class ProviderAPIError(AlterSDKError):
    """
    Raised when provider API call fails.

    This is raised by wrapper classes when the actual provider API returns an error.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Initialize with provider API error details."""
        super().__init__(message, details)
        self.status_code = status_code
        self.response_body = response_body


class ScopeReauthRequiredError(ProviderAPIError):
    """
    Raised when a provider API returns 403 and the connection has a scope mismatch.

    This indicates the connection's OAuth scopes don't match the provider config's
    required scopes — typically because the developer added new scopes after the
    user originally authorized. The user needs to re-authorize via a Connect session
    to grant the updated permissions.

    Recovery:
        ```python
        try:
            result = await vault.request(conn_id, HttpMethod.GET, url)
        except ScopeReauthRequiredError as e:
            session = await vault.create_connect_session(
                allowed_providers=[e.provider_id],
            )
            notify_user(e.connection_id, session.connect_url)
        ```

    Extends ProviderAPIError so existing ``except ProviderAPIError`` blocks
    continue to catch it without code changes.
    """

    def __init__(
        self,
        message: str,
        connection_id: str | None = None,
        provider_id: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Initialize with connection and provider context for recovery."""
        super().__init__(message, status_code, response_body, details)
        self.connection_id = connection_id
        self.provider_id = provider_id


class NetworkError(AlterSDKError):
    """
    Raised when network operations fail.

    This includes connection errors and DNS failures when communicating
    with Alter Vault backend or provider APIs.

    For timeout-specific errors, see :class:`TimeoutError`.
    """


class TimeoutError(NetworkError):  # noqa: A001
    """
    Raised when a request times out.

    Extends NetworkError so callers catching NetworkError will still catch timeouts,
    but callers can also catch TimeoutError specifically to implement retry strategies
    (e.g., retry on timeout but not on connection refused).
    """
