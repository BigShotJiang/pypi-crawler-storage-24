"""
Alter Vault Python SDK

OAuth token management with policy enforcement and automatic token injection.

Zero Token Exposure Architecture:
- Tokens are NEVER exposed to developers
- SDK handles all token operations internally
- Developers only see API results, never credentials
"""

from alter_sdk.client import AlterVault
from alter_sdk.exceptions import (
    AlterSDKError,
    BackendError,
    ConnectConfigError,
    ConnectDeniedError,
    ConnectFlowError,
    ConnectionDeletedError,
    ConnectionExpiredError,
    ConnectionNotFoundError,
    ConnectionRevokedError,
    ConnectTimeoutError,
    NetworkError,
    PolicyViolationError,
    ProviderAPIError,
    ReAuthRequiredError,
    ScopeReauthRequiredError,
    TimeoutError,
)
from alter_sdk.models import (
    ActorType,
    APICallAuditLog,
    ConnectionInfo,
    ConnectionListResult,
    ConnectResult,
    ConnectSession,
    TokenResponse,
)
from alter_sdk.providers.enums import HttpMethod, Provider

__version__ = "0.5.0"

__all__ = [
    "AlterVault",
    "ActorType",
    "HttpMethod",
    "Provider",
    "TokenResponse",
    "APICallAuditLog",
    "ConnectionInfo",
    "ConnectResult",
    "ConnectSession",
    "ConnectionListResult",
    "AlterSDKError",
    "BackendError",
    "ReAuthRequiredError",
    "ConnectFlowError",
    "ConnectDeniedError",
    "ConnectConfigError",
    "ConnectTimeoutError",
    "PolicyViolationError",
    "ConnectionDeletedError",
    "ConnectionExpiredError",
    "ConnectionNotFoundError",
    "ConnectionRevokedError",
    "ProviderAPIError",
    "ScopeReauthRequiredError",
    "NetworkError",
    "TimeoutError",
]
