"""Version information for CIAF Core package."""

__version__ = "0.2.0"
__schema_version__ = "1.0.0"
