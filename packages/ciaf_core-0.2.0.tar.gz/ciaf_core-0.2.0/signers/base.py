"""Base protocol and types for signer implementations.

Defines the abstract interface that all signer backends must implement,
allowing for pluggable key management solutions (local, HSM, KMS, etc.).
"""

from typing import Protocol, Literal, runtime_checkable

SignatureAlgorithm = Literal["RSA-PSS-SHA256", "Ed25519", "ECDSA-P256-SHA256"]


@runtime_checkable
class SignerBackend(Protocol):
    """Protocol defining the interface for cryptographic signing backends.
    
    All signer implementations (local, HSM, cloud KMS) must implement this interface
    to be compatible with the CIAF signing framework.
    """

    def sign(self, payload: str, key_identifier: str, algorithm: SignatureAlgorithm) -> str:
        """Sign a payload using the specified key and algorithm.
        
        Args:
            payload: The string payload to sign (typically canonical JSON)
            key_identifier: Backend-specific key reference (PEM, ARN, key name, etc.)
            algorithm: Signature algorithm to use
            
        Returns:
            Base64-encoded signature string
            
        Raises:
            CIAFSigningError: If signing fails
            
        Examples:
            >>> signer = LocalSigner()
            >>> signature = signer.sign(payload, private_key_pem, "Ed25519")
            
            >>> signer = AWSKMSSigner(region="us-east-1")
            >>> signature = signer.sign(payload, "arn:aws:kms:...", "RSA-PSS-SHA256")
        """
        ...

    def verify(
        self,
        payload: str,
        signature: str,
        key_identifier: str,
        algorithm: SignatureAlgorithm,
    ) -> bool:
        """Verify a signature against a payload.
        
        Args:
            payload: The string payload that was signed
            signature: Base64-encoded signature to verify
            key_identifier: Backend-specific key reference (public key PEM, ARN, etc.)
            algorithm: Signature algorithm used
            
        Returns:
            True if signature is valid, False otherwise
            
        Raises:
            CIAFVerificationError: If verification process fails (not invalid signature)
        """
        ...

    def get_public_key(self, key_identifier: str) -> bytes:
        """Retrieve the public key for a given key identifier.
        
        Args:
            key_identifier: Backend-specific key reference
            
        Returns:
            Public key in PEM format as bytes
            
        Raises:
            CIAFSigningError: If public key cannot be retrieved
        """
        ...

    @property
    def backend_name(self) -> str:
        """Return the name of this signer backend.
        
        Returns:
            Human-readable backend name (e.g., "local", "aws-kms", "azure-kv")
        """
        ...

    def supports_algorithm(self, algorithm: SignatureAlgorithm) -> bool:
        """Check if this backend supports a given algorithm.
        
        Args:
            algorithm: Signature algorithm to check
            
        Returns:
            True if algorithm is supported, False otherwise
        """
        ...


class SignerConfig:
    """Configuration for signer backends.
    
    Provides a type-safe way to configure signer instances with
    backend-specific parameters.
    """

    def __init__(
        self,
        backend: str,
        region: str | None = None,
        endpoint_url: str | None = None,
        credentials: dict | None = None,
        **kwargs,
    ):
        """Initialize signer configuration.
        
        Args:
            backend: Backend type ("local", "aws-kms", "azure-kv", "gcp-kms", "hsm")
            region: Cloud region (for AWS, Azure, GCP)
            endpoint_url: Custom endpoint URL (optional)
            credentials: Backend-specific credentials dictionary
            **kwargs: Additional backend-specific configuration
        """
        self.backend = backend
        self.region = region
        self.endpoint_url = endpoint_url
        self.credentials = credentials or {}
        self.extra = kwargs


__all__ = [
    "SignerBackend",
    "SignerConfig",
    "SignatureAlgorithm",
]
