"""AWS KMS (Key Management Service) signer implementation.

Provides enterprise-grade key management using AWS KMS for cryptographic
signing operations. Private keys never leave the HSM-backed KMS service.

Requirements:
    pip install ciaf-core[aws-kms]
    
Setup:
    - Configure AWS credentials (via environment, ~/.aws/credentials, or IAM roles)
    - Create a KMS key with SIGN_VERIFY key usage
    - Grant kms:Sign and kms:GetPublicKey permissions
    
Examples:
    >>> from ciaf_core.signers import AWSKMSSigner
    >>> 
    >>> signer = AWSKMSSigner(region_name="us-east-1")
    >>> key_id = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"
    >>> 
    >>> signature = signer.sign(payload, key_id, "RSA-PSS-SHA256")
    >>> is_valid = signer.verify(payload, signature, key_id, "RSA-PSS-SHA256")
"""

from __future__ import annotations

import base64
from typing import Any

try:
    import boto3
    from botocore.exceptions import ClientError, BotoCoreError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

from ..signing import CIAFSigningError, CIAFVerificationError
from .base import SignerBackend, SignatureAlgorithm


# AWS KMS signing algorithm mapping
ALGORITHM_MAP = {
    "RSA-PSS-SHA256": "RSASSA_PSS_SHA_256",
    "ECDSA-P256-SHA256": "ECDSA_SHA_256",
    # Note: AWS KMS does not support Ed25519
}


class AWSKMSSigner:
    """AWS KMS-backed cryptographic signer.
    
    Uses AWS Key Management Service for signing operations with hardware-backed
    keys. Private keys are stored in FIPS 140-2 validated HSMs and never exposed.
    
    Supported Algorithms:
        - RSA-PSS-SHA256 (2048, 3072, 4096-bit keys)
        - ECDSA-P256-SHA256 (NIST P-256 curve)
        
    Not Supported:
        - Ed25519 (AWS KMS does not support this algorithm)
        
    Security Benefits:
        - Hardware-backed key storage (FIPS 140-2 Level 2+)
        - Fine-grained IAM access control
        - CloudTrail audit logging
        - Automatic key rotation
        - Multi-region key replication
        
    Examples:
        >>> # Using ARN
        >>> signer = AWSKMSSigner(region_name="us-east-1")
        >>> key_arn = "arn:aws:kms:us-east-1:123456789012:key/abc-123"
        >>> signature = signer.sign(payload, key_arn, "RSA-PSS-SHA256")
        >>> 
        >>> # Using key alias
        >>> signature = signer.sign(payload, "alias/ciaf-signing-key", "RSA-PSS-SHA256")
        >>> 
        >>> # Custom endpoint (for LocalStack testing)
        >>> signer = AWSKMSSigner(
        ...     region_name="us-east-1",
        ...     endpoint_url="http://localhost:4566"
        ... )
    """

    def __init__(
        self,
        region_name: str = "us-east-1",
        endpoint_url: str | None = None,
        aws_access_key_id: str | None = None,
        aws_secret_access_key: str | None = None,
        aws_session_token: str | None = None,
        **kwargs,
    ):
        """Initialize AWS KMS signer.
        
        Args:
            region_name: AWS region (default: us-east-1)
            endpoint_url: Custom KMS endpoint (for LocalStack/testing)
            aws_access_key_id: AWS access key (optional, uses default credential chain)
            aws_secret_access_key: AWS secret key (optional)
            aws_session_token: AWS session token (optional, for temporary credentials)
            **kwargs: Additional boto3 client parameters
            
        Raises:
            ImportError: If boto3 is not installed
        """
        if not BOTO3_AVAILABLE:
            raise ImportError(
                "AWS KMS support requires boto3. Install with: pip install ciaf-core[aws-kms]"
            )

        client_kwargs: dict[str, Any] = {
            "service_name": "kms",
            "region_name": region_name,
            **kwargs,
        }

        if endpoint_url:
            client_kwargs["endpoint_url"] = endpoint_url
        if aws_access_key_id:
            client_kwargs["aws_access_key_id"] = aws_access_key_id
        if aws_secret_access_key:
            client_kwargs["aws_secret_access_key"] = aws_secret_access_key
        if aws_session_token:
            client_kwargs["aws_session_token"] = aws_session_token

        self.client = boto3.client(**client_kwargs)
        self.region_name = region_name

    @property
    def backend_name(self) -> str:
        """Return backend name."""
        return "aws-kms"

    def sign(self, payload: str, key_identifier: str, algorithm: SignatureAlgorithm) -> str:
        """Sign payload using AWS KMS key.
        
        Args:
            payload: String payload to sign
            key_identifier: KMS key ID, ARN, or alias (e.g., "alias/my-key")
            algorithm: Signature algorithm (RSA-PSS-SHA256 or ECDSA-P256-SHA256)
            
        Returns:
            Base64-encoded signature
            
        Raises:
            CIAFSigningError: If signing fails or algorithm not supported
            
        Examples:
            >>> signature = signer.sign(payload, "arn:aws:kms:...", "RSA-PSS-SHA256")
        """
        if algorithm not in ALGORITHM_MAP:
            raise CIAFSigningError(
                f"AWS KMS does not support {algorithm}. "
                f"Supported: {list(ALGORITHM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            kms_algorithm = ALGORITHM_MAP[algorithm]

            response = self.client.sign(
                KeyId=key_identifier,
                Message=payload_bytes,
                MessageType="RAW",
                SigningAlgorithm=kms_algorithm,
            )

            signature_bytes = response["Signature"]
            return base64.b64encode(signature_bytes).decode("ascii")

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            raise CIAFSigningError(
                f"AWS KMS signing failed [{error_code}]: {error_msg}"
            ) from e
        except BotoCoreError as e:
            raise CIAFSigningError(f"AWS KMS signing failed: {e}") from e
        except Exception as e:
            raise CIAFSigningError(f"Unexpected error during AWS KMS signing: {e}") from e

    def verify(
        self,
        payload: str,
        signature: str,
        key_identifier: str,
        algorithm: SignatureAlgorithm,
    ) -> bool:
        """Verify signature using AWS KMS.
        
        AWS KMS can verify signatures created with its keys. This is useful for
        validating signatures without retrieving the public key.
        
        Args:
            payload: String payload that was signed
            signature: Base64-encoded signature
            key_identifier: KMS key ID, ARN, or alias
            algorithm: Signature algorithm used
            
        Returns:
            True if signature is valid, False otherwise
            
        Raises:
            CIAFVerificationError: If verification process fails
        """
        if algorithm not in ALGORITHM_MAP:
            raise CIAFVerificationError(
                f"AWS KMS does not support {algorithm}. "
                f"Supported: {list(ALGORITHM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            signature_bytes = base64.b64decode(signature)
            kms_algorithm = ALGORITHM_MAP[algorithm]

            response = self.client.verify(
                KeyId=key_identifier,
                Message=payload_bytes,
                MessageType="RAW",
                Signature=signature_bytes,
                SigningAlgorithm=kms_algorithm,
            )

            return response.get("SignatureValid", False)

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            # InvalidSignatureException means signature is invalid (not an error)
            if error_code == "InvalidSignatureException":
                return False
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            raise CIAFVerificationError(
                f"AWS KMS verification failed [{error_code}]: {error_msg}"
            ) from e
        except Exception as e:
            raise CIAFVerificationError(
                f"Unexpected error during AWS KMS verification: {e}"
            ) from e

    def get_public_key(self, key_identifier: str) -> bytes:
        """Retrieve public key from AWS KMS.
        
        Args:
            key_identifier: KMS key ID, ARN, or alias
            
        Returns:
            Public key in PEM format (DER-encoded SubjectPublicKeyInfo)
            
        Raises:
            CIAFSigningError: If public key retrieval fails
        """
        try:
            response = self.client.get_public_key(KeyId=key_identifier)
            
            # AWS returns DER-encoded public key, convert to PEM
            public_key_der = response["PublicKey"]
            
            # Convert DER to PEM format
            pem_header = b"-----BEGIN PUBLIC KEY-----\n"
            pem_footer = b"\n-----END PUBLIC KEY-----\n"
            encoded = base64.b64encode(public_key_der)
            
            # Split into 64-character lines
            pem_body = b"\n".join(
                encoded[i : i + 64] for i in range(0, len(encoded), 64)
            )
            
            return pem_header + pem_body + pem_footer

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            raise CIAFSigningError(
                f"Failed to get public key from AWS KMS [{error_code}]: {error_msg}"
            ) from e
        except Exception as e:
            raise CIAFSigningError(
                f"Unexpected error getting public key from AWS KMS: {e}"
            ) from e

    def supports_algorithm(self, algorithm: SignatureAlgorithm) -> bool:
        """Check if algorithm is supported by AWS KMS.
        
        Args:
            algorithm: Algorithm to check
            
        Returns:
            True if supported (RSA-PSS-SHA256, ECDSA-P256-SHA256)
        """
        return algorithm in ALGORITHM_MAP


__all__ = ["AWSKMSSigner"]
