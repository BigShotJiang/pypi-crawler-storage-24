"""Google Cloud KMS signer implementation.

Provides enterprise-grade key management using Google Cloud KMS for
cryptographic signing operations. Supports both software and HSM-backed keys.

Requirements:
    pip install ciaf-core[gcp-kms]
    
Setup:
    - Configure GCP credentials (via GOOGLE_APPLICATION_CREDENTIALS, ADC, or service account)
    - Create a key ring and asymmetric signing key
    - Grant cloudkms.signer and cloudkms.publicKeyViewer permissions
    
Examples:
    >>> from ciaf_core.signers import GCPKMSSigner
    >>> 
    >>> signer = GCPKMSSigner(project_id="my-project", location="us-east1")
    >>> 
    >>> key_path = "projects/my-project/locations/us-east1/keyRings/my-ring/cryptoKeys/my-key/cryptoKeyVersions/1"
    >>> signature = signer.sign(payload, key_path, "RSA-PSS-SHA256")
"""

from __future__ import annotations

import base64
from typing import Any

try:
    from google.cloud import kms
    from google.api_core import exceptions as gcp_exceptions
    from google.auth import credentials as gcp_credentials
    GCP_AVAILABLE = True
    
    # Google Cloud KMS algorithm mapping (only when SDK is available)
    ALGORITHM_MAP = {
        "RSA-PSS-SHA256": kms.CryptoKeyVersion.CryptoKeyVersionAlgorithm.RSA_SIGN_PSS_2048_SHA256,
        "ECDSA-P256-SHA256": kms.CryptoKeyVersion.CryptoKeyVersionAlgorithm.EC_SIGN_P256_SHA256,
        # Note: Google Cloud KMS does not support Ed25519
    }
except ImportError:
    GCP_AVAILABLE = False
    ALGORITHM_MAP = {}  # Empty when not available

from ..signing import CIAFSigningError, CIAFVerificationError
from .base import SignerBackend, SignatureAlgorithm


class GCPKMSSigner:
    """Google Cloud KMS cryptographic signer.
    
    Uses Google Cloud Key Management Service for signing operations with
    optionally HSM-backed keys. Private keys are stored in FIPS 140-2
    validated storage and never exposed.
    
    Supported Algorithms:
        - RSA-PSS-SHA256 (2048, 3072, 4096-bit keys)
        - ECDSA-P256-SHA256 (NIST P-256 curve)
        
    Not Supported:
        - Ed25519 (Google Cloud KMS does not support this algorithm)
        
    Protection Levels:
        - SOFTWARE: Software-protected keys in Google datacenters
        - HSM: FIPS 140-2 Level 3 validated HSM keys
        - EXTERNAL: Keys stored in external key management partner
        
    Security Benefits:
        - Hardware-backed key storage (HSM keys)
        - IAM-based access control
        - Cloud Audit Logs for all operations
        - Automatic key rotation
        - Global key replication
        - VPC Service Controls
        
    Key Path Format:
        projects/{project}/locations/{location}/keyRings/{ring}/cryptoKeys/{key}/cryptoKeyVersions/{version}
        
    Examples:
        >>> # Using default credentials
        >>> signer = GCPKMSSigner(project_id="my-project", location="us-east1")
        >>> 
        >>> # Full key version path
        >>> key_path = "projects/my-project/locations/us-east1/keyRings/ciaf/cryptoKeys/signing-key/cryptoKeyVersions/1"
        >>> signature = signer.sign(payload, key_path, "RSA-PSS-SHA256")
        >>> 
        >>> # Using shorthand (will use latest version)
        >>> signature = signer.sign(payload, "ciaf/signing-key", "ECDSA-P256-SHA256")
        >>> 
        >>> # Custom credentials
        >>> from google.oauth2 import service_account
        >>> credentials = service_account.Credentials.from_service_account_file("key.json")
        >>> signer = GCPKMSSigner(
        ...     project_id="my-project",
        ...     location="us-east1",
        ...     credentials=credentials
        ... )
    """

    def __init__(
        self,
        project_id: str,
        location: str = "global",
        credentials: Any | None = None,
        **kwargs,
    ):
        """Initialize Google Cloud KMS signer.
        
        Args:
            project_id: Google Cloud project ID
            location: KMS location/region (default: "global")
            credentials: Google Cloud credentials (defaults to ADC)
            **kwargs: Additional KMS client parameters
            
        Raises:
            ImportError: If google-cloud-kms is not installed
        """
        if not GCP_AVAILABLE:
            raise ImportError(
                "Google Cloud KMS support requires google-cloud-kms. "
                "Install with: pip install ciaf-core[gcp-kms]"
            )

        client_kwargs = {}
        if credentials:
            client_kwargs["credentials"] = credentials

        self.client = kms.KeyManagementServiceClient(**client_kwargs, **kwargs)
        self.project_id = project_id
        self.location = location

    @property
    def backend_name(self) -> str:
        """Return backend name."""
        return "gcp-kms"

    def _build_key_path(self, key_identifier: str) -> str:
        """Build full key path from identifier.
        
        Args:
            key_identifier: Full path or shorthand (keyRing/cryptoKey)
            
        Returns:
            Full key version path
        """
        if key_identifier.startswith("projects/"):
            # Already a full path
            return key_identifier
        
        # Shorthand: keyRing/cryptoKey or keyRing/cryptoKey/version
        parts = key_identifier.split("/")
        if len(parts) == 2:
            # Use latest version
            key_ring, crypto_key = parts
            # Get the latest version
            key_name = self.client.crypto_key_path(
                self.project_id, self.location, key_ring, crypto_key
            )
            # Return primary version path
            return f"{key_name}/cryptoKeyVersions/1"
        elif len(parts) == 3:
            key_ring, crypto_key, version = parts
            return self.client.crypto_key_version_path(
                self.project_id, self.location, key_ring, crypto_key, version
            )
        else:
            raise CIAFSigningError(
                f"Invalid key identifier: {key_identifier}. "
                "Use 'keyRing/cryptoKey' or full resource path."
            )

    def sign(self, payload: str, key_identifier: str, algorithm: SignatureAlgorithm) -> str:
        """Sign payload using Google Cloud KMS key.
        
        Args:
            payload: String payload to sign
            key_identifier: Key path or shorthand (keyRing/cryptoKey/version)
            algorithm: Signature algorithm (RSA-PSS-SHA256 or ECDSA-P256-SHA256)
            
        Returns:
            Base64-encoded signature
            
        Raises:
            CIAFSigningError: If signing fails or algorithm not supported
            
        Examples:
            >>> signature = signer.sign(payload, "my-ring/my-key/1", "RSA-PSS-SHA256")
        """
        if algorithm not in ALGORITHM_MAP:
            raise CIAFSigningError(
                f"Google Cloud KMS does not support {algorithm}. "
                f"Supported: {list(ALGORITHM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            key_path = self._build_key_path(key_identifier)
            
            # Calculate digest for signing
            import hashlib
            digest = hashlib.sha256(payload_bytes).digest()
            
            # Create digest object
            digest_obj = {"sha256": digest}
            
            # Asymmetric sign
            response = self.client.asymmetric_sign(
                request={
                    "name": key_path,
                    "digest": digest_obj,
                }
            )
            
            return base64.b64encode(response.signature).decode("ascii")

        except gcp_exceptions.GoogleAPICallError as e:
            raise CIAFSigningError(f"Google Cloud KMS signing failed: {e}") from e
        except Exception as e:
            raise CIAFSigningError(
                f"Unexpected error during Google Cloud KMS signing: {e}"
            ) from e

    def verify(
        self,
        payload: str,
        signature: str,
        key_identifier: str,
        algorithm: SignatureAlgorithm,
    ) -> bool:
        """Verify signature using local public key from GCP KMS.
        
        Note: Google Cloud KMS does not provide a native verification API,
        so we retrieve the public key and verify locally.
        
        Args:
            payload: String payload that was signed
            signature: Base64-encoded signature
            key_identifier: Key path
            algorithm: Signature algorithm used
            
        Returns:
            True if signature is valid, False otherwise
            
        Raises:
            CIAFVerificationError: If verification process fails
        """
        try:
            # Get public key from KMS
            public_key_pem = self.get_public_key(key_identifier)
            
            # Use local verification
            from ..signing import verify_signature as local_verify
            return local_verify(payload, signature, public_key_pem, algorithm)

        except Exception as e:
            raise CIAFVerificationError(
                f"Google Cloud KMS verification failed: {e}"
            ) from e

    def get_public_key(self, key_identifier: str) -> bytes:
        """Retrieve public key from Google Cloud KMS.
        
        Args:
            key_identifier: Key path or shorthand
            
        Returns:
            Public key in PEM format
            
        Raises:
            CIAFSigningError: If public key retrieval fails
        """
        try:
            key_path = self._build_key_path(key_identifier)
            
            # Get public key
            response = self.client.get_public_key(request={"name": key_path})
            
            # Response already contains PEM-encoded public key
            return response.pem.encode("utf-8")

        except gcp_exceptions.GoogleAPICallError as e:
            raise CIAFSigningError(
                f"Failed to get public key from Google Cloud KMS: {e}"
            ) from e
        except Exception as e:
            raise CIAFSigningError(
                f"Unexpected error getting public key from Google Cloud KMS: {e}"
            ) from e

    def supports_algorithm(self, algorithm: SignatureAlgorithm) -> bool:
        """Check if algorithm is supported by Google Cloud KMS.
        
        Args:
            algorithm: Algorithm to check
            
        Returns:
            True if supported (RSA-PSS-SHA256, ECDSA-P256-SHA256)
        """
        return algorithm in ALGORITHM_MAP


__all__ = ["GCPKMSSigner"]
