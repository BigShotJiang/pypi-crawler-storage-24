"""Local in-memory signer implementation.

Provides backward-compatible signing using locally-stored PEM keys.
This is the default signer and matches the original ciaf_core behavior.
"""

from ..signing import (
    sign_payload as _legacy_sign_payload,
    verify_signature as _legacy_verify_signature,
    generate_rsa_keypair,
    generate_ed25519_keypair,
    generate_ecdsa_keypair,
    CIAFSigningError,
    CIAFVerificationError,
)
from .base import SignerBackend, SignatureAlgorithm


class LocalSigner:
    """Signer implementation using local PEM-encoded keys.
    
    This signer performs all cryptographic operations in-memory using
    the Python cryptography library. Private keys must be provided as
    PEM-encoded bytes.
    
    This is the default signer and provides backward compatibility with
    existing ciaf_core signing behavior.
    
    Security Note:
        Private keys are loaded into memory during signing operations.
        For production use with sensitive keys, consider using an HSM
        or cloud KMS backend instead.
    
    Examples:
        >>> from ciaf_core.signers import LocalSigner
        >>> from ciaf_core.signing import generate_ed25519_keypair
        >>> 
        >>> # Generate keypair
        >>> private_pem, public_pem = generate_ed25519_keypair()
        >>> 
        >>> # Create signer
        >>> signer = LocalSigner()
        >>> 
        >>> # Sign payload
        >>> payload = '{"event": "data"}'
        >>> signature = signer.sign(payload, private_pem, "Ed25519")
        >>> 
        >>> # Verify signature
        >>> is_valid = signer.verify(payload, signature, public_pem, "Ed25519")
        >>> assert is_valid
    """

    def __init__(self):
        """Initialize local signer."""
        pass

    @property
    def backend_name(self) -> str:
        """Return backend name."""
        return "local"

    def sign(self, payload: str, key_identifier: str | bytes, algorithm: SignatureAlgorithm) -> str:
        """Sign a payload using a local PEM key.
        
        Args:
            payload: String payload to sign
            key_identifier: Private key in PEM format (bytes or string)
            algorithm: Signature algorithm
            
        Returns:
            Base64-encoded signature
            
        Raises:
            CIAFSigningError: If signing fails
        """
        # Convert string to bytes if needed
        if isinstance(key_identifier, str):
            private_key_pem = key_identifier.encode("utf-8")
        else:
            private_key_pem = key_identifier

        return _legacy_sign_payload(payload, private_key_pem, algorithm)

    def verify(
        self,
        payload: str,
        signature: str,
        key_identifier: str | bytes,
        algorithm: SignatureAlgorithm,
    ) -> bool:
        """Verify a signature using a local PEM public key.
        
        Args:
            payload: String payload that was signed
            signature: Base64-encoded signature
            key_identifier: Public key in PEM format (bytes or string)
            algorithm: Signature algorithm used
            
        Returns:
            True if valid, False otherwise
            
        Raises:
            CIAFVerificationError: If verification process fails
        """
        # Convert string to bytes if needed
        if isinstance(key_identifier, str):
            public_key_pem = key_identifier.encode("utf-8")
        else:
            public_key_pem = key_identifier

        return _legacy_verify_signature(payload, signature, public_key_pem, algorithm)

    def get_public_key(self, key_identifier: str | bytes) -> bytes:
        """Return the public key (assumes key_identifier is already the public key).
        
        Args:
            key_identifier: Public key in PEM format
            
        Returns:
            Public key PEM bytes
        """
        if isinstance(key_identifier, str):
            return key_identifier.encode("utf-8")
        return key_identifier

    def supports_algorithm(self, algorithm: SignatureAlgorithm) -> bool:
        """Check if algorithm is supported.
        
        All three standard algorithms are supported by local signer.
        
        Args:
            algorithm: Algorithm to check
            
        Returns:
            True for RSA-PSS-SHA256, Ed25519, ECDSA-P256-SHA256
        """
        return algorithm in ("RSA-PSS-SHA256", "Ed25519", "ECDSA-P256-SHA256")

    @staticmethod
    def generate_keypair(algorithm: SignatureAlgorithm, **kwargs) -> tuple[bytes, bytes]:
        """Generate a new keypair for local signing.
        
        Args:
            algorithm: Algorithm to generate keys for
            **kwargs: Algorithm-specific parameters (e.g., key_size for RSA)
            
        Returns:
            Tuple of (private_key_pem, public_key_pem)
            
        Raises:
            CIAFSigningError: If key generation fails
            
        Examples:
            >>> private_pem, public_pem = LocalSigner.generate_keypair("Ed25519")
            >>> private_pem, public_pem = LocalSigner.generate_keypair("RSA-PSS-SHA256", key_size=4096)
        """
        if algorithm == "Ed25519":
            return generate_ed25519_keypair()
        elif algorithm == "RSA-PSS-SHA256":
            key_size = kwargs.get("key_size", 2048)
            return generate_rsa_keypair(key_size)
        elif algorithm == "ECDSA-P256-SHA256":
            return generate_ecdsa_keypair()
        else:
            raise CIAFSigningError(f"Unsupported algorithm: {algorithm}")


__all__ = ["LocalSigner"]
