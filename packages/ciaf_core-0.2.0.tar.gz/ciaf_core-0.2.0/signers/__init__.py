"""Pluggable signer backends for CIAF Core.

Provides cryptographic signing with multiple backend options:
- Local: In-memory signing with PEM keys (default)
- AWS KMS: Hardware-backed signing via AWS Key Management Service
- Azure Key Vault: Hardware-backed signing via Azure Key Vault
- Google Cloud KMS: Hardware-backed signing via Google Cloud KMS
- PKCS#11 HSM: On-premise hardware security module support

Examples:
    >>> # Local signing (default)
    >>> from ciaf_core.signers import LocalSigner
    >>> from ciaf_core.signing import generate_ed25519_keypair
    >>> 
    >>> private_key, public_key = generate_ed25519_keypair()
    >>> signer = LocalSigner()
    >>> signature = signer.sign(payload, private_key, "Ed25519")
    >>> 
    >>> # AWS KMS signing
    >>> from ciaf_core.signers import AWSKMSSigner
    >>> signer = AWSKMSSigner(region_name="us-east-1")
    >>> signature = signer.sign(payload, "arn:aws:kms:...", "RSA-PSS-SHA256")
    >>> 
    >>> # Using factory
    >>> from ciaf_core.signers import create_signer
    >>> signer = create_signer("azure-kv", vault_url="https://my-vault.vault.azure.net")
    >>> 
    >>> # Configure default signer
    >>> from ciaf_core.signers import set_default_signer, configure_signer_from_env
    >>> signer = configure_signer_from_env()
    >>> set_default_signer(signer)
"""

# Base types
from .base import (
    SignerBackend,
    SignerConfig,
    SignatureAlgorithm,
)

# Signer implementations
from .local import LocalSigner

# Cloud KMS signers (lazy import to avoid dependencies)
def _lazy_import_aws():
    from .aws_kms import AWSKMSSigner
    return AWSKMSSigner

def _lazy_import_azure():
    from .azure_kv import AzureKeyVaultSigner
    return AzureKeyVaultSigner

def _lazy_import_gcp():
    from .gcp_kms import GCPKMSSigner
    return GCPKMSSigner

def _lazy_import_hsm():
    from .hsm import PKCS11Signer
    return PKCS11Signer


# Factory functions
from .factory import (
    create_signer,
    create_signer_from_config,
    set_default_signer,
    get_default_signer,
    configure_signer_from_env,
)


# Conditional exports based on availability
__all__ = [
    # Base types
    "SignerBackend",
    "SignerConfig",
    "SignatureAlgorithm",
    # Local signer (always available)
    "LocalSigner",
    # Factory functions
    "create_signer",
    "create_signer_from_config",
    "set_default_signer",
    "get_default_signer",
    "configure_signer_from_env",
]

# Add cloud KMS signers to exports (they handle import errors internally)
try:
    from .aws_kms import AWSKMSSigner
    __all__.append("AWSKMSSigner")
except ImportError:
    pass

try:
    from .azure_kv import AzureKeyVaultSigner
    __all__.append("AzureKeyVaultSigner")
except ImportError:
    pass

try:
    from .gcp_kms import GCPKMSSigner
    __all__.append("GCPKMSSigner")
except ImportError:
    pass

try:
    from .hsm import PKCS11Signer
    __all__.append("PKCS11Signer")
except ImportError:
    pass


def __getattr__(name):
    """Lazy import for cloud signers to avoid dependency errors."""
    if name == "AWSKMSSigner":
        return _lazy_import_aws()
    elif name == "AzureKeyVaultSigner":
        return _lazy_import_azure()
    elif name == "GCPKMSSigner":
        return _lazy_import_gcp()
    elif name == "PKCS11Signer":
        return _lazy_import_hsm()
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
