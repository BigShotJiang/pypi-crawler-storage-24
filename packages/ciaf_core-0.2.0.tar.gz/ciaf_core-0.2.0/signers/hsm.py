"""PKCS#11 HSM signer implementation.

Provides support for on-premise Hardware Security Modules (HSMs) via the
PKCS#11 standard interface. Compatible with devices from Thales, Utimaco,
SafeNet, SoftHSM, and other PKCS#11-compliant HSMs.

Requirements:
    pip install ciaf-core[hsm]
    
Setup:
    - Install HSM vendor's PKCS#11 library (e.g., /usr/lib/softhsm/libsofthsm2.so)
    - Initialize HSM token and create signing keys
    - Configure token PIN for access
    
Examples:
    >>> from ciaf_core.signers import PKCS11Signer
    >>> 
    >>> signer = PKCS11Signer(
    ...     library_path="/usr/lib/softhsm/libsofthsm2.so",
    ...     token_label="my-token",
    ...     pin="1234"
    ... )
    >>> 
    >>> # Sign using key label
    >>> signature = signer.sign(payload, "signing-key", "RSA-PSS-SHA256")
"""

from __future__ import annotations

import base64
from typing import Any

try:
    import pkcs11
    from pkcs11 import Mechanism, KeyType, ObjectClass
    from pkcs11.util.rsa import PKCS1v15Signature, PSS
    from pkcs11.util.ec import encode_ecdsa_signature, decode_ecdsa_signature
    PKCS11_AVAILABLE = True
except ImportError:
    PKCS11_AVAILABLE = False

from ..signing import CIAFSigningError, CIAFVerificationError
from .base import SignerBackend, SignatureAlgorithm


# PKCS#11 mechanism mapping
MECHANISM_MAP = {
    "RSA-PSS-SHA256": Mechanism.SHA256_RSA_PKCS_PSS if PKCS11_AVAILABLE else None,
    "ECDSA-P256-SHA256": Mechanism.ECDSA_SHA256 if PKCS11_AVAILABLE else None,
    # Ed25519 support varies by HSM vendor
}


class PKCS11Signer:
    """PKCS#11 HSM-backed cryptographic signer.
    
    Uses hardware security modules via the PKCS#11 standard interface for
    signing operations. Private keys are stored in FIPS 140-2 Level 2/3
    validated hardware and never exposed.
    
    Supported Algorithms:
        - RSA-PSS-SHA256 (2048, 3072, 4096-bit keys)
        - ECDSA-P256-SHA256 (NIST P-256 curve)
        - Ed25519 (vendor-dependent)
        
    Compatible HSMs:
        - Thales nShield
        - Utimaco SecurityServer
        - SafeNet Luna
        - AWS CloudHSM
        - SoftHSMv2 (software HSM for testing)
        - YubiHSM
        - And other PKCS#11-compliant devices
        
    Security Benefits:
        - Hardware-backed key storage (FIPS 140-2 Level 2+)
        - Keys never leave HSM boundary
        - Tamper-resistant hardware
        - Dual control and M-of-N authentication
        - On-premise key management
        - No cloud dependency
        
    Key Identification:
        Keys are identified by label (CKA_LABEL attribute) or ID (CKA_ID).
        Labels are more user-friendly: "my-signing-key"
        IDs are byte strings (often hex): "01:02:03:04"
        
    Examples:
        >>> # Using SoftHSM for testing
        >>> signer = PKCS11Signer(
        ...     library_path="/usr/lib/softhsm/libsofthsm2.so",
        ...     token_label="test-token",
        ...     pin="1234"
        ... )
        >>> 
        >>> # Sign with key label
        >>> signature = signer.sign(payload, "ciaf-signing-key", "RSA-PSS-SHA256")
        >>> 
        >>> # Using slot number instead of label
        >>> signer = PKCS11Signer(
        ...     library_path="/usr/lib/libCryptoki2_64.so",
        ...     slot=0,
        ...     pin="changeme"
        ... )
        >>> 
        >>> # Production HSM with dual control
        >>> signer = PKCS11Signer(
        ...     library_path="/opt/nfast/toolkits/pkcs11/libcknfast.so",
        ...     token_label="production-token",
        ...     pin=lambda: get_pin_from_secure_store()
        ... )
    """

    def __init__(
        self,
        library_path: str,
        token_label: str | None = None,
        slot: int | None = None,
        pin: str | callable | None = None,
        **kwargs,
    ):
        """Initialize PKCS#11 HSM signer.
        
        Args:
            library_path: Path to PKCS#11 library (e.g., libsofthsm2.so)
            token_label: Token label to use (mutually exclusive with slot)
            slot: Slot number to use (mutually exclusive with token_label)
            pin: Token PIN (string or callable that returns PIN)
            **kwargs: Additional PKCS#11 library parameters
            
        Raises:
            ImportError: If python-pkcs11 is not installed
            CIAFSigningError: If HSM initialization fails
        """
        if not PKCS11_AVAILABLE:
            raise ImportError(
                "PKCS#11 HSM support requires python-pkcs11. "
                "Install with: pip install ciaf-core[hsm]"
            )

        if token_label is None and slot is None:
            raise CIAFSigningError("Must specify either token_label or slot")
        
        if token_label is not None and slot is not None:
            raise CIAFSigningError("Cannot specify both token_label and slot")

        try:
            self.library_path = library_path
            self.lib = pkcs11.lib(library_path)
            
            # Find token/slot
            if token_label:
                self.token = self.lib.get_token(token_label=token_label)
            else:
                self.token = self.lib.get_slots(slot)[0].get_token()
            
            # Store PIN (can be callable for dynamic retrieval)
            self._pin = pin
            self._session = None

        except Exception as e:
            raise CIAFSigningError(f"Failed to initialize PKCS#11 HSM: {e}") from e

    @property
    def backend_name(self) -> str:
        """Return backend name."""
        return "pkcs11-hsm"

    def _get_pin(self) -> str:
        """Get PIN (call if callable)."""
        if callable(self._pin):
            return self._pin()
        return self._pin

    def _get_session(self):
        """Get or create HSM session."""
        if self._session is None:
            pin = self._get_pin()
            self._session = self.token.open(user_pin=pin)
        return self._session

    def _find_private_key(self, key_identifier: str):
        """Find private key by label or ID.
        
        Args:
            key_identifier: Key label (string) or ID (hex string with colons)
            
        Returns:
            Private key object
        """
        session = self._get_session()
        
        try:
            # Try as label first
            keys = list(session.get_objects({
                ObjectClass.PRIVATE_KEY: True,
                pkcs11.Attribute.LABEL: key_identifier
            }))
            
            if keys:
                return keys[0]
            
            # Try as ID (hex format: "01:02:03")
            if ":" in key_identifier:
                key_id = bytes.fromhex(key_identifier.replace(":", ""))
                keys = list(session.get_objects({
                    ObjectClass.PRIVATE_KEY: True,
                    pkcs11.Attribute.ID: key_id
                }))
                
                if keys:
                    return keys[0]
            
            raise CIAFSigningError(f"Private key not found: {key_identifier}")
            
        except Exception as e:
            raise CIAFSigningError(f"Error finding private key: {e}") from e

    def _find_public_key(self, key_identifier: str):
        """Find public key by label or ID."""
        session = self._get_session()
        
        try:
            # Try as label first
            keys = list(session.get_objects({
                ObjectClass.PUBLIC_KEY: True,
                pkcs11.Attribute.LABEL: key_identifier
            }))
            
            if keys:
                return keys[0]
            
            # Try as ID
            if ":" in key_identifier:
                key_id = bytes.fromhex(key_identifier.replace(":", ""))
                keys = list(session.get_objects({
                    ObjectClass.PUBLIC_KEY: True,
                    pkcs11.Attribute.ID: key_id
                }))
                
                if keys:
                    return keys[0]
            
            raise CIAFSigningError(f"Public key not found: {key_identifier}")
            
        except Exception as e:
            raise CIAFSigningError(f"Error finding public key: {e}") from e

    def sign(self, payload: str, key_identifier: str, algorithm: SignatureAlgorithm) -> str:
        """Sign payload using PKCS#11 HSM key.
        
        Args:
            payload: String payload to sign
            key_identifier: Key label or ID (hex with colons)
            algorithm: Signature algorithm
            
        Returns:
            Base64-encoded signature
            
        Raises:
            CIAFSigningError: If signing fails
            
        Examples:
            >>> signature = signer.sign(payload, "my-key", "RSA-PSS-SHA256")
            >>> signature = signer.sign(payload, "01:02:03:04", "ECDSA-P256-SHA256")
        """
        if algorithm not in MECHANISM_MAP:
            raise CIAFSigningError(
                f"PKCS#11 HSM does not support {algorithm}. "
                f"Supported: {list(MECHANISM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            private_key = self._find_private_key(key_identifier)
            mechanism = MECHANISM_MAP[algorithm]
            
            # Sign using HSM
            signature_bytes = private_key.sign(payload_bytes, mechanism=mechanism)
            
            return base64.b64encode(signature_bytes).decode("ascii")

        except Exception as e:
            raise CIAFSigningError(f"PKCS#11 HSM signing failed: {e}") from e

    def verify(
        self,
        payload: str,
        signature: str,
        key_identifier: str,
        algorithm: SignatureAlgorithm,
    ) -> bool:
        """Verify signature using PKCS#11 HSM.
        
        Args:
            payload: String payload that was signed
            signature: Base64-encoded signature
            key_identifier: Public key label or ID
            algorithm: Signature algorithm used
            
        Returns:
            True if signature is valid, False otherwise
            
        Raises:
            CIAFVerificationError: If verification process fails
        """
        if algorithm not in MECHANISM_MAP:
            raise CIAFVerificationError(
                f"PKCS#11 HSM does not support {algorithm}. "
                f"Supported: {list(MECHANISM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            signature_bytes = base64.b64decode(signature)
            public_key = self._find_public_key(key_identifier)
            mechanism = MECHANISM_MAP[algorithm]
            
            # Verify using HSM
            public_key.verify(payload_bytes, signature_bytes, mechanism=mechanism)
            return True

        except Exception:
            # Verification failure raises exception in pkcs11 library
            return False

    def get_public_key(self, key_identifier: str) -> bytes:
        """Retrieve public key from HSM in PEM format.
        
        Args:
            key_identifier: Key label or ID
            
        Returns:
            Public key in PEM format
            
        Raises:
            CIAFSigningError: If public key retrieval fails
        """
        try:
            public_key = self._find_public_key(key_identifier)
            
            # Export public key and convert to PEM
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import rsa, ec
            from cryptography.hazmat.backends import default_backend
            
            key_type = public_key[pkcs11.Attribute.KEY_TYPE]
            
            if key_type == KeyType.RSA:
                # RSA key
                modulus = int.from_bytes(public_key[pkcs11.Attribute.MODULUS], "big")
                exponent = int.from_bytes(public_key[pkcs11.Attribute.PUBLIC_EXPONENT], "big")
                
                from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
                public_numbers = RSAPublicNumbers(exponent, modulus)
                public_key_obj = public_numbers.public_key(default_backend())
                
            elif key_type == KeyType.EC:
                # ECDSA key
                ec_point = public_key[pkcs11.Attribute.EC_POINT]
                # EC point is DER-encoded, parse it
                # For P-256, point is 65 bytes (0x04 prefix + 32-byte X + 32-byte Y)
                if ec_point[0:2] == b'\x04\x41' and len(ec_point) == 67:
                    # Skip DER wrapping (first 2 bytes)
                    point = ec_point[2:]
                    if point[0] == 0x04:  # Uncompressed point
                        x = int.from_bytes(point[1:33], "big")
                        y = int.from_bytes(point[33:65], "big")
                        
                        public_numbers = ec.EllipticCurvePublicNumbers(
                            x, y, ec.SECP256R1()
                        )
                        public_key_obj = public_numbers.public_key(default_backend())
                else:
                    raise CIAFSigningError("Unsupported EC point format")
                    
            else:
                raise CIAFSigningError(f"Unsupported key type: {key_type}")
            
            # Convert to PEM
            pem = public_key_obj.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
            
            return pem

        except Exception as e:
            raise CIAFSigningError(
                f"Failed to get public key from PKCS#11 HSM: {e}"
            ) from e

    def supports_algorithm(self, algorithm: SignatureAlgorithm) -> bool:
        """Check if algorithm is supported.
        
        Args:
            algorithm: Algorithm to check
            
        Returns:
            True if supported
        """
        return algorithm in MECHANISM_MAP

    def close(self):
        """Close HSM session."""
        if self._session:
            self._session.close()
            self._session = None


__all__ = ["PKCS11Signer"]
