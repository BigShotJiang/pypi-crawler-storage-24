"""Factory for creating signer instances.

Provides convenient factory functions and a global signer registry
for easy configuration of signing backends.
"""

from typing import Any
from .base import SignerBackend, SignerConfig, SignatureAlgorithm
from .local import LocalSigner
from ..signing import CIAFSigningError


# Global default signer (starts as LocalSigner)
_default_signer: SignerBackend | None = None


def create_signer(backend: str, **kwargs) -> SignerBackend:
    """Create a signer instance for the specified backend.
    
    Args:
        backend: Backend type ("local", "aws-kms", "azure-kv", "gcp-kms", "hsm")
        **kwargs: Backend-specific configuration parameters
        
    Returns:
        Configured signer instance
        
    Raises:
        CIAFSigningError: If backend is not supported or initialization fails
        
    Examples:
        >>> # Local signer (default)
        >>> signer = create_signer("local")
        >>> 
        >>> # AWS KMS
        >>> signer = create_signer("aws-kms", region_name="us-east-1")
        >>> 
        >>> # Azure Key Vault
        >>> signer = create_signer("azure-kv", vault_url="https://my-vault.vault.azure.net")
        >>> 
        >>> # Google Cloud KMS
        >>> signer = create_signer("gcp-kms", project_id="my-project", location="us-east1")
        >>> 
        >>> # PKCS#11 HSM
        >>> signer = create_signer(
        ...     "hsm",
        ...     library_path="/usr/lib/softhsm/libsofthsm2.so",
        ...     token_label="my-token",
        ...     pin="1234"
        ... )
    """
    backend = backend.lower()
    
    if backend == "local":
        return LocalSigner()
    
    elif backend == "aws-kms":
        from .aws_kms import AWSKMSSigner
        return AWSKMSSigner(**kwargs)
    
    elif backend == "azure-kv" or backend == "azure":
        from .azure_kv import AzureKeyVaultSigner
        return AzureKeyVaultSigner(**kwargs)
    
    elif backend == "gcp-kms" or backend == "gcp" or backend == "google":
        from .gcp_kms import GCPKMSSigner
        return GCPKMSSigner(**kwargs)
    
    elif backend == "hsm" or backend == "pkcs11":
        from .hsm import PKCS11Signer
        return PKCS11Signer(**kwargs)
    
    else:
        raise CIAFSigningError(
            f"Unknown signer backend: {backend}. "
            f"Supported: local, aws-kms, azure-kv, gcp-kms, hsm"
        )


def create_signer_from_config(config: SignerConfig) -> SignerBackend:
    """Create a signer from a SignerConfig object.
    
    Args:
        config: Signer configuration
        
    Returns:
        Configured signer instance
        
    Examples:
        >>> config = SignerConfig(
        ...     backend="aws-kms",
        ...     region="us-east-1"
        ... )
        >>> signer = create_signer_from_config(config)
    """
    kwargs = {}
    
    if config.region:
        if config.backend == "aws-kms":
            kwargs["region_name"] = config.region
        elif config.backend == "gcp-kms":
            kwargs["location"] = config.region
    
    if config.endpoint_url:
        kwargs["endpoint_url"] = config.endpoint_url
    
    if config.credentials:
        kwargs.update(config.credentials)
    
    kwargs.update(config.extra)
    
    return create_signer(config.backend, **kwargs)


def set_default_signer(signer: SignerBackend | None):
    """Set the global default signer.
    
    This allows signing functions to use a configured signer without
    passing it explicitly every time.
    
    Args:
        signer: Signer instance to use as default (None for LocalSigner)
        
    Examples:
        >>> from ciaf_core.signers import set_default_signer, create_signer
        >>> 
        >>> # Configure AWS KMS as default
        >>> aws_signer = create_signer("aws-kms", region_name="us-east-1")
        >>> set_default_signer(aws_signer)
        >>> 
        >>> # Now all signing operations use AWS KMS
        >>> from ciaf_core.signers import get_default_signer
        >>> signer = get_default_signer()
        >>> signature = signer.sign(payload, key_id, "RSA-PSS-SHA256")
    """
    global _default_signer
    _default_signer = signer


def get_default_signer() -> SignerBackend:
    """Get the global default signer.
    
    Returns LocalSigner if no default has been set.
    
    Returns:
        Current default signer instance
        
    Examples:
        >>> signer = get_default_signer()
        >>> signature = signer.sign(payload, key_id, algorithm)
    """
    global _default_signer
    if _default_signer is None:
        _default_signer = LocalSigner()
    return _default_signer


def configure_signer_from_env() -> SignerBackend:
    """Configure signer from environment variables.
    
    Reads configuration from environment:
        - CIAF_SIGNER_BACKEND: Backend type (local, aws-kms, azure-kv, gcp-kms, hsm)
        - CIAF_SIGNER_REGION: Cloud region
        - CIAF_AWS_REGION: AWS region (alternative)
        - CIAF_AZURE_VAULT_URL: Azure Key Vault URL
        - CIAF_GCP_PROJECT: Google Cloud project ID
        - CIAF_GCP_LOCATION: Google Cloud location
        - CIAF_HSM_LIBRARY: PKCS#11 library path
        - CIAF_HSM_TOKEN: HSM token label
        - CIAF_HSM_PIN: HSM PIN
        
    Returns:
        Configured signer instance
        
    Examples:
        >>> # Set environment variables
        >>> import os
        >>> os.environ["CIAF_SIGNER_BACKEND"] = "aws-kms"
        >>> os.environ["CIAF_AWS_REGION"] = "us-east-1"
        >>> 
        >>> # Configure from environment
        >>> signer = configure_signer_from_env()
        >>> set_default_signer(signer)
    """
    import os
    
    backend = os.getenv("CIAF_SIGNER_BACKEND", "local").lower()
    
    if backend == "local":
        return LocalSigner()
    
    elif backend == "aws-kms":
        from .aws_kms import AWSKMSSigner
        region = os.getenv("CIAF_SIGNER_REGION") or os.getenv("CIAF_AWS_REGION", "us-east-1")
        return AWSKMSSigner(region_name=region)
    
    elif backend in ("azure-kv", "azure"):
        from .azure_kv import AzureKeyVaultSigner
        vault_url = os.getenv("CIAF_AZURE_VAULT_URL")
        if not vault_url:
            raise CIAFSigningError(
                "CIAF_AZURE_VAULT_URL environment variable required for Azure Key Vault"
            )
        return AzureKeyVaultSigner(vault_url=vault_url)
    
    elif backend in ("gcp-kms", "gcp", "google"):
        from .gcp_kms import GCPKMSSigner
        project_id = os.getenv("CIAF_GCP_PROJECT")
        if not project_id:
            raise CIAFSigningError(
                "CIAF_GCP_PROJECT environment variable required for Google Cloud KMS"
            )
        location = os.getenv("CIAF_GCP_LOCATION", "global")
        return GCPKMSSigner(project_id=project_id, location=location)
    
    elif backend in ("hsm", "pkcs11"):
        from .hsm import PKCS11Signer
        library_path = os.getenv("CIAF_HSM_LIBRARY")
        token_label = os.getenv("CIAF_HSM_TOKEN")
        pin = os.getenv("CIAF_HSM_PIN")
        
        if not library_path:
            raise CIAFSigningError(
                "CIAF_HSM_LIBRARY environment variable required for PKCS#11 HSM"
            )
        
        return PKCS11Signer(
            library_path=library_path,
            token_label=token_label,
            pin=pin
        )
    
    else:
        raise CIAFSigningError(f"Unknown signer backend in CIAF_SIGNER_BACKEND: {backend}")


__all__ = [
    "create_signer",
    "create_signer_from_config",
    "set_default_signer",
    "get_default_signer",
    "configure_signer_from_env",
]
