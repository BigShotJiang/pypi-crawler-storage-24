"""Azure Key Vault signer implementation.

Provides enterprise-grade key management using Azure Key Vault for
cryptographic signing operations. Supports both standard and premium
(HSM-backed) key vaults.

Requirements:
    pip install ciaf-core[azure-kv]
    
Setup:
    - Configure Azure credentials (via environment, DefaultAzureCredential, or CLI)
    - Create a Key Vault with appropriate access policies
    - Create a key with "Sign" permission
    - Grant your identity the "Key Vault Crypto User" role
    
Examples:
    >>> from ciaf_core.signers import AzureKeyVaultSigner
    >>> 
    >>> signer = AzureKeyVaultSigner(vault_url="https://my-vault.vault.azure.net")
    >>> signature = signer.sign(payload, "my-signing-key", "RSA-PSS-SHA256")
    >>> is_valid = signer.verify(payload, signature, "my-signing-key", "RSA-PSS-SHA256")
"""

from __future__ import annotations

import base64
from typing import Any

try:
    from azure.identity import DefaultAzureCredential
    from azure.keyvault.keys import KeyClient
    from azure.keyvault.keys.crypto import CryptographyClient, SignatureAlgorithm as AzSignAlgorithm
    from azure.core.exceptions import AzureError, ResourceNotFoundError
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False

from ..signing import CIAFSigningError, CIAFVerificationError
from .base import SignerBackend, SignatureAlgorithm


# Azure Key Vault signing algorithm mapping
ALGORITHM_MAP = {
    "RSA-PSS-SHA256": "PS256",  # Azure uses PS256 for RSA-PSS with SHA-256
    "ECDSA-P256-SHA256": "ES256",  # Azure uses ES256 for ECDSA P-256
    # Note: Azure Key Vault does not support Ed25519
}


class AzureKeyVaultSigner:
    """Azure Key Vault cryptographic signer.
    
    Uses Azure Key Vault for signing operations with optionally HSM-backed keys.
    Private keys are stored in FIPS 140-2 validated storage and never exposed.
    
    Supported Algorithms:
        - RSA-PSS-SHA256 (2048, 3072, 4096-bit keys)
        - ECDSA-P256-SHA256 (NIST P-256 curve)
        
    Not Supported:
        - Ed25519 (Azure Key Vault does not support this algorithm)
        
    Key Types:
        - Standard: Software-protected keys in Azure datacenters
        - Premium/HSM: FIPS 140-2 Level 2 validated HSM keys
        
    Security Benefits:
        - Hardware-backed key storage (Premium SKU)
        - Azure RBAC and access policies
        - Azure Monitor audit logging
        - Managed key rotation
        - Geo-replication for disaster recovery
        - Virtual network integration
        
    Examples:
        >>> # Using DefaultAzureCredential (recommended)
        >>> signer = AzureKeyVaultSigner(vault_url="https://my-vault.vault.azure.net")
        >>> signature = signer.sign(payload, "ciaf-signing-key", "RSA-PSS-SHA256")
        >>> 
        >>> # Using specific credential
        >>> from azure.identity import ClientSecretCredential
        >>> credential = ClientSecretCredential(tenant_id, client_id, client_secret)
        >>> signer = AzureKeyVaultSigner(
        ...     vault_url="https://my-vault.vault.azure.net",
        ...     credential=credential
        ... )
        >>> 
        >>> # With custom key version
        >>> signature = signer.sign(payload, "my-key/abc123version", "RSA-PSS-SHA256")
    """

    def __init__(
        self,
        vault_url: str,
        credential: Any | None = None,
        **kwargs,
    ):
        """Initialize Azure Key Vault signer.
        
        Args:
            vault_url: Key Vault URL (e.g., "https://my-vault.vault.azure.net")
            credential: Azure credential object (defaults to DefaultAzureCredential)
            **kwargs: Additional Key Vault client parameters
            
        Raises:
            ImportError: If azure-keyvault-keys or azure-identity not installed
        """
        if not AZURE_AVAILABLE:
            raise ImportError(
                "Azure Key Vault support requires azure-keyvault-keys and azure-identity. "
                "Install with: pip install ciaf-core[azure-kv]"
            )

        self.vault_url = vault_url
        self.credential = credential or DefaultAzureCredential()
        self.key_client = KeyClient(vault_url=vault_url, credential=self.credential, **kwargs)
        
        # Cache for CryptographyClient instances (one per key)
        self._crypto_clients: dict[str, CryptographyClient] = {}

    @property
    def backend_name(self) -> str:
        """Return backend name."""
        return "azure-kv"

    def _get_crypto_client(self, key_name: str) -> CryptographyClient:
        """Get or create a CryptographyClient for a specific key.
        
        Args:
            key_name: Key name (may include version like "key-name/version")
            
        Returns:
            CryptographyClient instance
        """
        if key_name not in self._crypto_clients:
            # Get the key to construct the full key ID
            try:
                key = self.key_client.get_key(key_name)
                self._crypto_clients[key_name] = CryptographyClient(key, credential=self.credential)
            except ResourceNotFoundError as e:
                raise CIAFSigningError(f"Key '{key_name}' not found in vault: {e}") from e
        
        return self._crypto_clients[key_name]

    def sign(self, payload: str, key_identifier: str, algorithm: SignatureAlgorithm) -> str:
        """Sign payload using Azure Key Vault key.
        
        Args:
            payload: String payload to sign
            key_identifier: Key name (e.g., "my-key" or "my-key/version")
            algorithm: Signature algorithm (RSA-PSS-SHA256 or ECDSA-P256-SHA256)
            
        Returns:
            Base64-encoded signature
            
        Raises:
            CIAFSigningError: If signing fails or algorithm not supported
            
        Examples:
            >>> signature = signer.sign(payload, "ciaf-key", "RSA-PSS-SHA256")
            >>> signature = signer.sign(payload, "ciaf-key/v123", "RSA-PSS-SHA256")
        """
        if algorithm not in ALGORITHM_MAP:
            raise CIAFSigningError(
                f"Azure Key Vault does not support {algorithm}. "
                f"Supported: {list(ALGORITHM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            azure_algorithm = getattr(AzSignAlgorithm, ALGORITHM_MAP[algorithm])
            
            crypto_client = self._get_crypto_client(key_identifier)
            result = crypto_client.sign(azure_algorithm, payload_bytes)
            
            return base64.b64encode(result.signature).decode("ascii")

        except AzureError as e:
            raise CIAFSigningError(f"Azure Key Vault signing failed: {e}") from e
        except Exception as e:
            raise CIAFSigningError(
                f"Unexpected error during Azure Key Vault signing: {e}"
            ) from e

    def verify(
        self,
        payload: str,
        signature: str,
        key_identifier: str,
        algorithm: SignatureAlgorithm,
    ) -> bool:
        """Verify signature using Azure Key Vault.
        
        Azure Key Vault can verify signatures created with its keys.
        
        Args:
            payload: String payload that was signed
            signature: Base64-encoded signature
            key_identifier: Key name (e.g., "my-key")
            algorithm: Signature algorithm used
            
        Returns:
            True if signature is valid, False otherwise
            
        Raises:
            CIAFVerificationError: If verification process fails
        """
        if algorithm not in ALGORITHM_MAP:
            raise CIAFVerificationError(
                f"Azure Key Vault does not support {algorithm}. "
                f"Supported: {list(ALGORITHM_MAP.keys())}"
            )

        try:
            payload_bytes = payload.encode("utf-8")
            signature_bytes = base64.b64decode(signature)
            azure_algorithm = getattr(AzSignAlgorithm, ALGORITHM_MAP[algorithm])
            
            crypto_client = self._get_crypto_client(key_identifier)
            result = crypto_client.verify(azure_algorithm, payload_bytes, signature_bytes)
            
            return result.is_valid

        except AzureError as e:
            raise CIAFVerificationError(
                f"Azure Key Vault verification failed: {e}"
            ) from e
        except Exception as e:
            raise CIAFVerificationError(
                f"Unexpected error during Azure Key Vault verification: {e}"
            ) from e

    def get_public_key(self, key_identifier: str) -> bytes:
        """Retrieve public key from Azure Key Vault.
        
        Args:
            key_identifier: Key name (e.g., "my-key")
            
        Returns:
            Public key in PEM format
            
        Raises:
            CIAFSigningError: If public key retrieval fails
        """
        try:
            key = self.key_client.get_key(key_identifier)
            
            # Azure returns public key in JWK format, convert to PEM
            # The key object has a .key property with the public key material
            if not key.key:
                raise CIAFSigningError(f"No public key material for key '{key_identifier}'")
            
            # Use cryptography library to convert to PEM
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric import rsa, ec
            from cryptography.hazmat.backends import default_backend
            
            # Build public key from JWK components
            if key.key.kty == "RSA":
                # RSA key
                from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
                n = int.from_bytes(base64.urlsafe_b64decode(key.key.n + "=="), "big")
                e = int.from_bytes(base64.urlsafe_b64decode(key.key.e + "=="), "big")
                public_numbers = RSAPublicNumbers(e, n)
                public_key = public_numbers.public_key(default_backend())
            elif key.key.kty == "EC":
                # ECDSA key
                curve = ec.SECP256R1()  # P-256
                x = int.from_bytes(base64.urlsafe_b64decode(key.key.x + "=="), "big")
                y = int.from_bytes(base64.urlsafe_b64decode(key.key.y + "=="), "big")
                public_numbers = ec.EllipticCurvePublicNumbers(x, y, curve)
                public_key = public_numbers.public_key(default_backend())
            else:
                raise CIAFSigningError(f"Unsupported key type: {key.key.kty}")
            
            # Convert to PEM
            pem = public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
            
            return pem

        except ResourceNotFoundError as e:
            raise CIAFSigningError(f"Key '{key_identifier}' not found: {e}") from e
        except AzureError as e:
            raise CIAFSigningError(
                f"Failed to get public key from Azure Key Vault: {e}"
            ) from e
        except Exception as e:
            raise CIAFSigningError(
                f"Unexpected error getting public key from Azure Key Vault: {e}"
            ) from e

    def supports_algorithm(self, algorithm: SignatureAlgorithm) -> bool:
        """Check if algorithm is supported by Azure Key Vault.
        
        Args:
            algorithm: Algorithm to check
            
        Returns:
            True if supported (RSA-PSS-SHA256, ECDSA-P256-SHA256)
        """
        return algorithm in ALGORITHM_MAP


__all__ = ["AzureKeyVaultSigner"]
