# CIAF Core

[![Tests](https://github.com/DenzilGreenwood/ciaf_core/workflows/Tests/badge.svg)](https://github.com/DenzilGreenwood/ciaf_core/actions)
[![PyPI version](https://badge.fury.io/py/ciaf-core.svg)](https://badge.fury.io/py/ciaf-core)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: BUSL-1.1](https://img.shields.io/badge/License-BUSL--1.1-blue.svg)](LICENSE)

**The canonical schema and cryptographic contract layer for the CIAF ecosystem.**

It standardizes AI events, evidence, policy, execution, and inference metadata so CIAF packages remain interoperable, deterministic, and verifiable.

---

## Part of the Cognitive Insight / CIAF Ecosystem

CIAF Core is the foundational package in the [Cognitive Insight Audit Framework](https://cognitiveinsight.ai) ecosystem. It provides the shared schema contract that ensures consistency across all CIAF components:

- **ciaf_agents** - Agent instrumentation and governance
- **ciaf_web** - Web interfaces and dashboards
- **ciaf_vault** - Evidence storage and retrieval
- Model lifecycle pipelines
- Employee AI monitoring systems
- SDKs and APIs

Learn more at [cognitiveinsight.ai/packages/ciaf-core](https://cognitiveinsight.ai/packages/ciaf-core)

---

## Overview

`ciaf_core` is the canonical shared package that defines the common event, evidence, policy, lineage, and execution schemas used across all CIAF (Cognitive Insight Audit Framework) processes, ensuring interoperability, deterministic validation, and cryptographic consistency across the CIAF ecosystem.

## Why This Package Exists

Without a shared schema layer, individual packages can drift in how they represent actions, outcomes, and cryptographic evidence, making interoperability, validation, and auditability much harder. By centralizing schemas, serialization, validation, and cryptographic preparation in one package, `ciaf_core` makes CIAF systems consistent, composable, and verifiable.

This package serves as the **shared contract layer** that all CIAF components depend on for:
- Consistent event structure and validation
- Deterministic serialization for cryptographic operations
- Standardized evidence and policy metadata
- AI inference tracking aligned with industry standards

## Key Features

- **Canonical Event Models** - Standardized schemas for all CIAF events
- **AI Inference Metadata** - Standards-aligned inference tracking (OpenTelemetry, OpenInference, OpenLineage, W3C PROV)
- **Deterministic Serialization** - Canonical JSON encoding for consistent hashing
- **Cryptographic Helpers** - SHA-256 hashing and payload preparation
- **ID Generation** - Unique identifier generation for events and entities
- **Validation Logic** - Pydantic-based validation for all schemas
- **Builder Functions** - Convenience constructors for common workflows
- **Extensible Design** - Support for custom extensions while maintaining core stability

## Installation

```bash
pip install ciaf-core
```

For development:

```bash
pip install ciaf-core[dev]
```

## Quick Start

```python
from ciaf_core import CIAFEvent, build_agent_tool_call_event, to_canonical_json, sha256_hex

# Build an event
event = build_agent_tool_call_event(
    tenant_id="tenant-123",
    source_system="ciaf_agents",
    actor_id="agent-456",
    actor_name="DataAnalysisAgent",
    subject_id="workflow-789",
    subject_name="Customer Data Analysis",
    tool_name="query_database",
    outcome="success",
)

# Canonicalize and hash
canonical = to_canonical_json(event)
content_hash = sha256_hex(canonical)

print(f"Event ID: {event.event_id}")
print(f"Content Hash: {content_hash}")
```

### Cryptographic Signing (Evidence Envelope)

Sign events for non-repudiation and authenticity:

```python
from ciaf_core import (
    CIAFEvent,
    SignedEvent,
    generate_ed25519_keypair,
    sign_payload,
    to_canonical_json,
    compute_payload_hash,
)

# Generate keypair (do this once, store private key securely)
private_key, public_key = generate_ed25519_keypair()

# Create an event
event = build_agent_tool_call_event(
    tenant_id="tenant-123",
    source_system="ciaf_agents",
    actor_id="agent-456",
    actor_name="DataAnalysisAgent",
    subject_id="workflow-789",
    subject_name="Customer Data Analysis",
    tool_name="query_database",
    outcome="success",
)

# Create signed envelope
payload_json = to_canonical_json(event)
signature = sign_payload(payload_json, private_key, "Ed25519")
payload_hash = compute_payload_hash(payload_json)

signed_event = SignedEvent(
    payload=event.model_dump(),
    payload_hash=payload_hash,
    signer_id="agent:data-analysis-v1",
    signature=signature,
    signature_algorithm="Ed25519",
    public_key_ref="key:vault:/agents/data-analysis.pub",
)

# Later: Verify the signature
is_valid = signed_event.verify(public_key)
if not is_valid:
    raise Exception("Invalid signature - event may have been tampered with!")

# Extract the original event
original_event = signed_event.get_event()
```

#### Supported Signature Algorithms

- **Ed25519** (recommended) - Fast, modern, secure elliptic curve signatures
- **RSA-PSS-SHA256** - Traditional RSA with PSS padding (2048, 3072, or 4096 bit keys)
- **ECDSA-P256-SHA256** - NIST P-256 elliptic curve signatures

#### Benefits of SignedEvent

1. **Non-repudiation** - Cryptographic proof of who created the event
2. **Integrity** - Detect any tampering with event data
3. **Authentication** - Verify the source before accepting events
4. **Chain of Custody** - Support for parent signatures and delegation
5. **Self-Contained Verification** - Optional inline public keys for portability

### Enterprise Key Management (HSM/KMS)

For production environments, CIAF Core supports enterprise key management solutions for enhanced security:

#### Supported Backends

- **Local** (default) - In-memory signing with PEM keys
- **AWS KMS** - Hardware-backed signing via AWS Key Management Service
- **Azure Key Vault** - Hardware-backed signing via Azure Key Vault  
- **Google Cloud KMS** - Hardware-backed signing via Google Cloud KMS
- **PKCS#11 HSM** - On-premise hardware security modules (Thales, Utimaco, SafeNet, etc.)

#### Installation

Install with your preferred backend(s):

```bash
# AWS KMS support
pip install ciaf-core[aws-kms]

# Azure Key Vault support
pip install ciaf-core[azure-kv]

# Google Cloud KMS support
pip install ciaf-core[gcp-kms]

# PKCS#11 HSM support
pip install ciaf-core[hsm]

# All backends
pip install ciaf-core[all-signers]
```

#### Quick Examples

**AWS KMS:**
```python
from ciaf_core.signers import AWSKMSSigner

signer = AWSKMSSigner(region_name="us-east-1")
key_arn = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"

signature = signer.sign(payload, key_arn, "RSA-PSS-SHA256")
is_valid = signer.verify(payload, signature, key_arn, "RSA-PSS-SHA256")
```

**Azure Key Vault:**
```python
from ciaf_core.signers import AzureKeyVaultSigner

signer = AzureKeyVaultSigner(vault_url="https://my-vault.vault.azure.net")
signature = signer.sign(payload, "ciaf-signing-key", "RSA-PSS-SHA256")
```

**Google Cloud KMS:**
```python
from ciaf_core.signers import GCPKMSSigner

signer = GCPKMSSigner(project_id="my-project", location="us-east1")
key_path = "my-keyring/ciaf-key/1"  # keyring/key/version
signature = signer.sign(payload, key_path, "ECDSA-P256-SHA256")
```

**PKCS#11 HSM:**
```python
from ciaf_core.signers import PKCS11Signer

signer = PKCS11Signer(
    library_path="/usr/lib/softhsm/libsofthsm2.so",
    token_label="production-token",
    pin="secure-pin"
)
signature = signer.sign(payload, "signing-key", "RSA-PSS-SHA256")
```

#### Factory Pattern

Use the factory for flexible configuration:

```python
from ciaf_core.signers import create_signer, set_default_signer

# Create signer dynamically
signer = create_signer("aws-kms", region_name="us-east-1")

# Set as default for all operations
set_default_signer(signer)

# Or configure from environment variables
from ciaf_core.signers import configure_signer_from_env
signer = configure_signer_from_env()
```

#### Environment Configuration

Set environment variables to configure the signer:

```bash
# AWS KMS
export CIAF_SIGNER_BACKEND=aws-kms
export CIAF_AWS_REGION=us-east-1

# Azure Key Vault
export CIAF_SIGNER_BACKEND=azure-kv
export CIAF_AZURE_VAULT_URL=https://my-vault.vault.azure.net

# Google Cloud KMS
export CIAF_SIGNER_BACKEND=gcp-kms
export CIAF_GCP_PROJECT=my-project
export CIAF_GCP_LOCATION=us-east1

# PKCS#11 HSM
export CIAF_SIGNER_BACKEND=hsm
export CIAF_HSM_LIBRARY=/usr/lib/softhsm/libsofthsm2.so
export CIAF_HSM_TOKEN=production-token
export CIAF_HSM_PIN=secure-pin
```

#### Security Benefits

- **Hardware-backed keys** - Private keys stored in FIPS 140-2 validated HSMs
- **Keys never exposed** - Signing operations performed within secure boundary
- **Audit logging** - CloudTrail, Azure Monitor, Cloud Logging integration
- **Access control** - IAM/RBAC-based key usage policies
- **Key rotation** - Managed key lifecycle and automatic rotation
- **Compliance** - Meet regulatory requirements (HIPAA, PCI-DSS, SOC 2, etc.)

## Core Schemas

### Actor
Represents the entity performing an action (human, agent, service, model, system).

### Subject
Represents the target of an action (agent, model, dataset, workflow, policy, case, document).

### Action
Represents the operation performed and its outcome.

### CIAFEvent
The canonical event structure containing actor, subject, action, and metadata.

### PolicyDecision
Records policy evaluation results and enforcement decisions.

### RiskAssessment
Captures risk analysis and scoring information.

### ExecutionContext
Describes the runtime environment and execution parameters.

### EvidenceRecord
Links events to cryptographic evidence in the vault.

### SignedEvent
Cryptographically signed envelope wrapping a CIAFEvent with signature metadata, providing non-repudiation and tamper detection.

### InferenceMetadata
Standards-aligned AI inference metadata for tracking inference events with OpenTelemetry, OpenInference, OpenLineage, and W3C PROV compatibility.

## AI Inference Metadata

CIAF Core includes a standards-aligned inference metadata model for AI inference events. This allows consistent tracking of AI operations across the ecosystem with:

- **Canonical envelope** - Structured inference event format
- **Namespaced attributes** - OpenTelemetry (`gen_ai.*`) and OpenInference semantic conventions
- **Facets** - OpenLineage-style structured extensions (policy, provenance, risk, execution, dataset)
- **Provenance** - W3C PROV concepts for lineage tracking

### Quick Example

```python
from ciaf_core.schemas.inference import (
    InferenceMetadata,
    InferenceActor,
    InferenceSystem,
    InferenceModel,
    CIAFPolicyFacet,
)
from ciaf_core.enums import ActorType
from datetime import datetime, timezone

# Create inference metadata
inference = InferenceMetadata(
    inference_id="inf_01HXYZ123",
    event_time=datetime.now(timezone.utc),
    actor=InferenceActor(
        agent_id="user_123",
        agent_type=ActorType.HUMAN,
    ),
    system=InferenceSystem(
        service_name="ciaf_agents",
        environment="production",
    ),
    model=InferenceModel(
        provider="openai",
        model_name="gpt-4.1",
        endpoint="chat.completions",
    ),
    # OpenTelemetry/OpenInference aligned attributes
    attributes={
        "gen_ai.operation.name": "chat",
        "gen_ai.conversation.id": "conv_789",
        "ciaf.policy.decision": "allow",
        "ciaf.risk.score": 0.18,
    },
    # Structured governance metadata
    facets={
        "ciaf_policy": CIAFPolicyFacet(
            decision="allow",
            rule_hits=["safe_usage", "no_pii_detected"],
            policy_version="3.2.1",
        ),
    },
)

# Serialize for hashing/signing
from ciaf_core.canonicalization import to_canonical_json
canonical = to_canonical_json(inference)
```

### Why Inference Metadata is Included

The inference metadata model enables CIAF systems to tag AI inference events with governance, execution, and evidence context in a format that is:

- **Structured** - Well-defined schemas prevent metadata drift
- **Interoperable** - Aligned with OpenTelemetry, OpenInference, and OpenLineage standards
- **Cryptographically stable** - Deterministic serialization enables reliable hashing and signing

See [INFERENCE_METADATA.md](INFERENCE_METADATA.md) for complete design documentation, field naming conventions, and usage patterns.


## Package Structure

```python
ciaf_core/
├── pyproject.toml
├── README.md
├── LICENSE
├── __init__.py
├── version.py
├── enums.py
├── exceptions.py
├── schemas/
│   ├── __init__.py
│   ├── event.py
│   ├── actor.py
│   ├── subject.py
│   ├── action.py
│   ├── policy.py
│   ├── risk.py
│   ├── execution.py
│   ├── evidence.py
│   ├── signed_event.py
│   └── ...
├── canonicalization/
│   └── __init__.py
├── hashing/
│   └── __init__.py
├── signing/
│   └── __init__.py
├── IDs/
│   └── __init__.py
├── validation_helpers/
│   └── __init__.py
└── builders/
    └── __init__.py

```

## Versioning

This package uses semantic versioning:
- **Package version**: `0.1.0` (this package)
- **Schema version**: `1.0.0` (embedded in event records)

### Compatibility Rules

- Minor version bumps: backward-compatible additions only
- Major version bumps: breaking field changes
- Patch version bumps: bug fixes, documentation

## Contributing

This is the foundational package for the CIAF ecosystem. Changes must be carefully reviewed to ensure:

1. Backward compatibility is maintained (or properly versioned)
2. Canonical serialization remains deterministic
3. All changes include tests
4. Documentation is updated

## License

Business Source License 1.1 (BUSL-1.1) - See [LICENSE](LICENSE) file for details.

**Key Points:**
- Free for non-commercial use, research, and evaluation
- Converts to Apache 2.0 on January 1, 2029
- Commercial use requires a license from Founder@CognitiveInsight.ai

For commercial licensing inquiries: **Founder@CognitiveInsight.ai**

## Contact & Support

- **Repository**: https://github.com/DenzilGreenwood/ciaf_core
- **Issues**: https://github.com/DenzilGreenwood/ciaf_core/issues
- **Commercial Licensing**: Founder@CognitiveInsight.ai
- **Website**: https://CognitiveInsight.ai

## Schema Version

Current schema version: **1.0.0**

## Author

**Denzil James Greenwood**  
Founder@CognitiveInsight.ai  
CognitiveInsight.ai
