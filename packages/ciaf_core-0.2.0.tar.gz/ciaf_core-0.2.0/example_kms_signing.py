"""Example demonstrating enterprise key management with KMS/HSM signers.

This example shows how to use CIAF Core's pluggable signer backends for
production-grade cryptographic signing with hardware-backed key storage.

Requirements:
    - For local signing: No additional dependencies (default)
    - For AWS KMS: pip install ciaf-core[aws-kms]
    - For Azure Key Vault: pip install ciaf-core[azure-kv]
    - For Google Cloud KMS: pip install ciaf-core[gcp-kms]
    - For PKCS#11 HSM: pip install ciaf-core[hsm]
"""

from datetime import datetime, timezone
from ciaf_core import (
    CIAFEvent,
    SignedEvent,
    Actor,
    Subject,
    Action,
    ActorType,
    SubjectType,
    ActionType,
    ActionOutcome,
    EventCategory,
    to_canonical_json,
    compute_payload_hash,
    new_event_id,
)


def create_sample_event() -> CIAFEvent:
    """Create a sample CIAF event for signing."""
    now = datetime.now(timezone.utc)
    
    return CIAFEvent(
        event_id=new_event_id(),
        event_type="agent.tool_call",
        event_category=EventCategory.EXECUTION,
        timestamp_utc=now,
        recorded_at_utc=now,
        tenant_id="tenant-123",
        source_system="ciaf_agents",
        actor=Actor(
            actor_id="agent-456",
            actor_type=ActorType.AGENT,
            actor_name="DataAnalysisAgent",
        ),
        subject=Subject(
            subject_id="workflow-789",
            subject_type=SubjectType.AGENT,
            subject_name="Customer Data Analysis",
        ),
        action=Action(
            action_type=ActionType.EXECUTE,
            action_name="tool_call",
            outcome=ActionOutcome.SUCCESS,
            parameters={"tool": "query_database", "query": "SELECT * FROM customers"},
        ),
    )


def example_local_signer():
    """Example: Local signing with in-memory keys (default)."""
    print("\n" + "=" * 80)
    print("EXAMPLE 1: Local Signer (In-Memory Keys)")
    print("=" * 80)
    
    from ciaf_core.signers import LocalSigner
    from ciaf_core.signing import generate_ed25519_keypair
    
    # Generate keypair
    print("Generating Ed25519 keypair...")
    private_key, public_key = generate_ed25519_keypair()
    
    # Create signer
    signer = LocalSigner()
    print(f"✓ Created {signer.backend_name} signer")
    
    # Create and sign event
    event = create_sample_event()
    payload = to_canonical_json(event)
    
    print("Signing event...")
    signature = signer.sign(payload, private_key, "Ed25519")
    print(f"✓ Signature: {signature[:60]}...")
    
    # Verify signature
    print("Verifying signature...")
    is_valid = signer.verify(payload, signature, public_key, "Ed25519")
    print(f"✓ Signature valid: {is_valid}")
    
    # Create SignedEvent envelope
    signed_event = SignedEvent(
        payload=event.model_dump(),
        payload_hash=compute_payload_hash(payload),
        signer_id="local:data-analysis-agent",
        signature=signature,
        signature_algorithm="Ed25519",
        public_key_ref="inline",
        public_key_inline=public_key.decode("utf-8"),
    )
    
    print(f"✓ Created SignedEvent envelope")
    print(f"  Event ID: {event.event_id}")
    print(f"  Signer ID: {signed_event.signer_id}")
    print(f"  Algorithm: {signed_event.signature_algorithm}")


def example_aws_kms_signer():
    """Example: AWS KMS signing (requires boto3 and AWS credentials)."""
    print("\n" + "=" * 80)
    print("EXAMPLE 2: AWS KMS Signer (Hardware-Backed Keys)")
    print("=" * 80)
    
    try:
        from ciaf_core.signers import AWSKMSSigner
        
        # NOTE: Replace with your actual KMS key ARN
        # Create key with: aws kms create-key --key-usage SIGN_VERIFY
        key_arn = "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012"
        
        print("Creating AWS KMS signer...")
        signer = AWSKMSSigner(region_name="us-east-1")
        print(f"✓ Created {signer.backend_name} signer")
        
        # Create event
        event = create_sample_event()
        payload = to_canonical_json(event)
        
        print(f"Signing with KMS key: {key_arn[:50]}...")
        signature = signer.sign(payload, key_arn, "RSA-PSS-SHA256")
        print(f"✓ Signature: {signature[:60]}...")
        
        # Verify using KMS
        print("Verifying signature via KMS...")
        is_valid = signer.verify(payload, signature, key_arn, "RSA-PSS-SHA256")
        print(f"✓ Signature valid: {is_valid}")
        
        # Get public key for distribution
        print("Retrieving public key from KMS...")
        public_key = signer.get_public_key(key_arn)
        print(f"✓ Public key retrieved ({len(public_key)} bytes)")
        
        print("\n💡 Benefits:")
        print("   - Private key stored in FIPS 140-2 validated HSM")
        print("   - CloudTrail logs all signing operations")
        print("   - IAM policies control key usage")
        print("   - Automatic key rotation available")
        
    except ImportError:
        print("❌ AWS KMS support not available")
        print("   Install with: pip install ciaf-core[aws-kms]")
    except Exception as e:
        print(f"❌ Error: {e}")
        print("   Ensure AWS credentials are configured and key ARN is valid")


def example_azure_keyvault_signer():
    """Example: Azure Key Vault signing (requires azure-keyvault-keys)."""
    print("\n" + "=" * 80)
    print("EXAMPLE 3: Azure Key Vault Signer (Hardware-Backed Keys)")
    print("=" * 80)
    
    try:
        from ciaf_core.signers import AzureKeyVaultSigner
        
        # NOTE: Replace with your actual Key Vault URL and key name
        vault_url = "https://my-vault.vault.azure.net"
        key_name = "ciaf-signing-key"
        
        print("Creating Azure Key Vault signer...")
        signer = AzureKeyVaultSigner(vault_url=vault_url)
        print(f"✓ Created {signer.backend_name} signer")
        
        # Create event
        event = create_sample_event()
        payload = to_canonical_json(event)
        
        print(f"Signing with key: {key_name}...")
        signature = signer.sign(payload, key_name, "RSA-PSS-SHA256")
        print(f"✓ Signature: {signature[:60]}...")
        
        # Verify
        print("Verifying signature...")
        is_valid = signer.verify(payload, signature, key_name, "RSA-PSS-SHA256")
        print(f"✓ Signature valid: {is_valid}")
        
        print("\n💡 Benefits:")
        print("   - Keys stored in Azure Key Vault (Premium SKU has HSM)")
        print("   - Azure RBAC for fine-grained access control")
        print("   - Azure Monitor logs all operations")
        print("   - VNet integration for network isolation")
        
    except ImportError:
        print("❌ Azure Key Vault support not available")
        print("   Install with: pip install ciaf-core[azure-kv]")
    except Exception as e:
        print(f"❌ Error: {e}")
        print("   Ensure Azure credentials are configured and Key Vault URL is valid")


def example_gcp_kms_signer():
    """Example: Google Cloud KMS signing (requires google-cloud-kms)."""
    print("\n" + "=" * 80)
    print("EXAMPLE 4: Google Cloud KMS Signer (Hardware-Backed Keys)")
    print("=" * 80)
    
    try:
        from ciaf_core.signers import GCPKMSSigner
        
        # NOTE: Replace with your actual project, keyring, and key
        project_id = "my-project"
        key_path = "my-keyring/ciaf-signing-key/1"  # keyring/key/version
        
        print("Creating Google Cloud KMS signer...")
        signer = GCPKMSSigner(project_id=project_id, location="us-east1")
        print(f"✓ Created {signer.backend_name} signer")
        
        # Create event
        event = create_sample_event()
        payload = to_canonical_json(event)
        
        print(f"Signing with key: {key_path}...")
        signature = signer.sign(payload, key_path, "ECDSA-P256-SHA256")
        print(f"✓ Signature: {signature[:60]}...")
        
        # Verify (GCP KMS doesn't have native verify, so gets public key)
        print("Verifying signature...")
        is_valid = signer.verify(payload, signature, key_path, "ECDSA-P256-SHA256")
        print(f"✓ Signature valid: {is_valid}")
        
        print("\n💡 Benefits:")
        print("   - Keys stored in Cloud HSM (FIPS 140-2 Level 3)")
        print("   - IAM policies for access control")
        print("   - Cloud Audit Logs for all operations")
        print("   - Multi-region replication available")
        
    except ImportError:
        print("❌ Google Cloud KMS support not available")
        print("   Install with: pip install ciaf-core[gcp-kms]")
    except Exception as e:
        print(f"❌ Error: {e}")
        print("   Ensure GCP credentials are configured and project ID is valid")


def example_hsm_signer():
    """Example: PKCS#11 HSM signing (requires python-pkcs11 and HSM library)."""
    print("\n" + "=" * 80)
    print("EXAMPLE 5: PKCS#11 HSM Signer (On-Premise Hardware)")
    print("=" * 80)
    
    try:
        from ciaf_core.signers import PKCS11Signer
        
        # NOTE: This example uses SoftHSMv2 for testing
        # In production, use actual HSM library paths:
        # - Thales: /opt/nfast/toolkits/pkcs11/libcknfast.so
        # - Utimaco: /usr/lib/libcs_pkcs11_R2.so
        # - SafeNet Luna: /usr/safenet/lunaclient/lib/libCryptoki2_64.so
        
        library_path = "/usr/lib/softhsm/libsofthsm2.so"  # SoftHSM for testing
        token_label = "test-token"
        key_label = "ciaf-signing-key"
        
        print("Creating PKCS#11 HSM signer...")
        signer = PKCS11Signer(
            library_path=library_path,
            token_label=token_label,
            pin="1234"  # In production, use secure PIN management
        )
        print(f"✓ Created {signer.backend_name} signer")
        
        # Create event
        event = create_sample_event()
        payload = to_canonical_json(event)
        
        print(f"Signing with HSM key: {key_label}...")
        signature = signer.sign(payload, key_label, "RSA-PSS-SHA256")
        print(f"✓ Signature: {signature[:60]}...")
        
        # Verify
        print("Verifying signature via HSM...")
        is_valid = signer.verify(payload, signature, key_label, "RSA-PSS-SHA256")
        print(f"✓ Signature valid: {is_valid}")
        
        signer.close()
        
        print("\n💡 Benefits:")
        print("   - Keys stored in FIPS 140-2 Level 2/3 hardware")
        print("   - Keys never leave HSM boundary")
        print("   - Tamper-resistant hardware")
        print("   - On-premise key management")
        print("   - No cloud dependency")
        
    except ImportError:
        print("❌ PKCS#11 HSM support not available")
        print("   Install with: pip install ciaf-core[hsm]")
    except Exception as e:
        print(f"❌ Error: {e}")
        print("   Ensure HSM library is installed and token is available")


def example_factory_pattern():
    """Example: Using factory pattern for flexible configuration."""
    print("\n" + "=" * 80)
    print("EXAMPLE 6: Factory Pattern (Dynamic Configuration)")
    print("=" * 80)
    
    from ciaf_core.signers import create_signer, set_default_signer, get_default_signer
    
    # Create signer dynamically based on backend type
    backend_types = ["local", "aws-kms", "azure-kv", "gcp-kms", "hsm"]
    
    for backend in backend_types:
        try:
            if backend == "local":
                signer = create_signer(backend)
                print(f"✓ Created {signer.backend_name} signer")
            elif backend == "aws-kms":
                signer = create_signer(backend, region_name="us-east-1")
                print(f"✓ Created {signer.backend_name} signer (would use AWS KMS)")
            elif backend == "azure-kv":
                print(f"  {backend} signer available (requires vault URL)")
            elif backend == "gcp-kms":
                print(f"  {backend} signer available (requires project ID)")
            elif backend == "hsm":
                print(f"  {backend} signer available (requires library path)")
        except ImportError:
            print(f"  {backend} signer not installed")
        except Exception as e:
            print(f"  {backend} signer: {e}")
    
    # Set default signer
    local_signer = create_signer("local")
    set_default_signer(local_signer)
    print(f"\n✓ Set default signer to: {get_default_signer().backend_name}")


def example_environment_config():
    """Example: Configuration from environment variables."""
    print("\n" + "=" * 80)
    print("EXAMPLE 7: Environment-Based Configuration")
    print("=" * 80)
    
    import os
    from ciaf_core.signers import configure_signer_from_env
    
    print("Environment variable examples:\n")
    
    print("For AWS KMS:")
    print("  export CIAF_SIGNER_BACKEND=aws-kms")
    print("  export CIAF_AWS_REGION=us-east-1\n")
    
    print("For Azure Key Vault:")
    print("  export CIAF_SIGNER_BACKEND=azure-kv")
    print("  export CIAF_AZURE_VAULT_URL=https://my-vault.vault.azure.net\n")
    
    print("For Google Cloud KMS:")
    print("  export CIAF_SIGNER_BACKEND=gcp-kms")
    print("  export CIAF_GCP_PROJECT=my-project")
    print("  export CIAF_GCP_LOCATION=us-east1\n")
    
    print("For PKCS#11 HSM:")
    print("  export CIAF_SIGNER_BACKEND=hsm")
    print("  export CIAF_HSM_LIBRARY=/usr/lib/softhsm/libsofthsm2.so")
    print("  export CIAF_HSM_TOKEN=production-token")
    print("  export CIAF_HSM_PIN=secure-pin\n")
    
    # Try to configure from current environment
    backend = os.getenv("CIAF_SIGNER_BACKEND", "local")
    print(f"Current CIAF_SIGNER_BACKEND: {backend}")
    
    try:
        signer = configure_signer_from_env()
        print(f"✓ Configured signer: {signer.backend_name}")
    except Exception as e:
        print(f"  Could not configure from environment: {e}")


def main():
    """Run all examples."""
    print("\n" + "=" * 80)
    print("CIAF Core: Enterprise Key Management Examples")
    print("=" * 80)
    print("\nDemonstrating pluggable signer backends for production-grade cryptography")
    
    # Run examples
    example_local_signer()
    example_aws_kms_signer()
    example_azure_keyvault_signer()
    example_gcp_kms_signer()
    example_hsm_signer()
    example_factory_pattern()
    example_environment_config()
    
    print("\n" + "=" * 80)
    print("Examples Complete!")
    print("=" * 80)
    print("\nFor more information:")
    print("  - Documentation: https://github.com/DenzilGreenwood/ciaf_core#readme")
    print("  - Signing backends: ciaf_core.signers module")
    print("  - Install backends: pip install ciaf-core[aws-kms|azure-kv|gcp-kms|hsm]")
    print()


if __name__ == "__main__":
    main()
