"""
Inference metadata schema for AI inference events.

Provides standards-aligned metadata for AI inference operations following
OpenTelemetry, OpenInference, OpenLineage, and W3C PROV conventions.
"""

from typing import Any, Dict, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field
from ..enums import ActorType


class InferenceActor(BaseModel):
    """Actor who initiated or is responsible for the inference."""

    agent_id: str = Field(..., description="Unique identifier for the actor")
    agent_type: ActorType = Field(..., description="Type of actor (human, service, ai_agent)")
    delegated_by: Optional[str] = Field(None, description="ID of delegating entity if applicable")


class InferenceSystem(BaseModel):
    """System context for the inference execution."""

    service_name: str = Field(..., description="Name of the service executing the inference")
    environment: str = Field(..., description="Deployment environment (e.g., production, staging)")
    region: Optional[str] = Field(None, description="Geographic region or deployment zone")
    version: Optional[str] = Field(None, description="Service version")


class InferenceModel(BaseModel):
    """AI model information for the inference."""

    provider: str = Field(..., description="Model provider (e.g., openai, anthropic, custom)")
    model_name: str = Field(..., description="Model identifier")
    model_version: Optional[str] = Field(None, description="Model version or snapshot")
    endpoint: Optional[str] = Field(None, description="API endpoint or operation type")
    parameters: Optional[Dict[str, Any]] = Field(
        None, description="Model invocation parameters (temperature, max_tokens, etc.)"
    )

    model_config = ConfigDict(protected_namespaces=())


class InferenceFacet(BaseModel):
    """
    Base class for facet metadata blocks.

    Facets follow OpenLineage's extension pattern with schema versioning.
    """

    schema_url: Optional[str] = Field(
        None, alias="_schema_url", description="URL to facet schema definition"
    )

    model_config = ConfigDict(populate_by_name=True)


class CIAFPolicyFacet(InferenceFacet):
    """Policy decision and governance metadata."""

    decision: str = Field(..., description="Policy decision (allow, deny, flag, review)")
    rule_hits: list[str] = Field(default_factory=list, description="Policy rules that matched")
    policy_version: str = Field(..., description="Version of policy evaluated")
    policy_id: Optional[str] = Field(None, description="Unique policy identifier")
    violations: Optional[list[str]] = Field(None, description="Any policy violations detected")


class CIAFProvenanceFacet(InferenceFacet):
    """
    W3C PROV-aligned provenance metadata.

    Maps CIAF concepts to PROV entities, activities, and agents.
    """

    prov_activity_id: str = Field(..., description="PROV activity identifier")
    prov_agent_id: str = Field(..., description="PROV agent identifier")
    prov_entity_input_id: Optional[str] = Field(None, description="PROV entity representing input")
    prov_entity_output_id: Optional[str] = Field(
        None, description="PROV entity representing output"
    )
    derived_from: Optional[list[str]] = Field(
        None, description="Entity IDs this output was derived from"
    )
    used_entities: Optional[list[str]] = Field(None, description="Entity IDs used in this activity")


class CIAFRiskFacet(InferenceFacet):
    """Risk assessment metadata."""

    risk_score: float = Field(..., ge=0.0, le=1.0, description="Normalized risk score")
    risk_level: str = Field(..., description="Risk classification (low, medium, high, critical)")
    risk_factors: list[str] = Field(default_factory=list, description="Identified risk factors")
    mitigation_applied: Optional[list[str]] = Field(
        None, description="Risk mitigation measures applied"
    )


class CIAFExecutionFacet(InferenceFacet):
    """Execution context and performance metadata."""

    duration_ms: float = Field(..., description="Execution duration in milliseconds")
    token_count_input: Optional[int] = Field(None, description="Input token count")
    token_count_output: Optional[int] = Field(None, description="Output token count")
    retry_count: int = Field(default=0, description="Number of retries attempted")
    error_type: Optional[str] = Field(None, description="Error type if failed")
    success: bool = Field(..., description="Whether execution succeeded")


class CIAFDatasetFacet(InferenceFacet):
    """Dataset and retrieval context metadata."""

    dataset_ids: list[str] = Field(default_factory=list, description="Dataset identifiers used")
    retrieval_method: Optional[str] = Field(
        None, description="Retrieval method (vector, keyword, hybrid)"
    )
    retrieval_count: Optional[int] = Field(None, description="Number of items retrieved")
    document_ids: Optional[list[str]] = Field(None, description="Document identifiers")


class InferenceMetadata(BaseModel):
    """
    Standards-aligned AI inference metadata.

    Combines:
    - CIAF canonical envelope (consistent event structure)
    - Namespaced attributes (OpenTelemetry/OpenInference alignment)
    - Facets (OpenLineage-style extensions)
    - Provenance semantics (W3C PROV concepts)
    """

    # Canonical CIAF envelope
    inference_id: str = Field(..., description="Unique inference event identifier")
    event_type: str = Field(default="ai.inference", description="Event type classification")
    event_time: datetime = Field(..., description="When the inference occurred (UTC)")

    actor: InferenceActor = Field(..., description="Actor who initiated the inference")
    system: InferenceSystem = Field(..., description="System execution context")
    model: InferenceModel = Field(..., description="AI model information")

    # Input/output references
    input_ref: Optional[str] = Field(None, description="Reference to input data/prompt")
    output_ref: Optional[str] = Field(None, description="Reference to output/response")

    # Context references
    policy_context: Optional[str] = Field(None, description="Policy context identifier")
    risk_context: Optional[str] = Field(None, description="Risk context identifier")
    evidence_context: Optional[str] = Field(None, description="Evidence context identifier")

    # Namespaced semantic attributes (OpenTelemetry/OpenInference aligned)
    attributes: Dict[str, Any] = Field(
        default_factory=dict,
        description="Flat key/value attributes with namespace prefixes (gen_ai.*, ciaf.*, etc.)",
    )

    # Facets (OpenLineage-style structured extensions)
    facets: Dict[str, InferenceFacet] = Field(
        default_factory=dict,
        description="Structured metadata facets (ciaf_policy, ciaf_provenance, etc.)",
    )

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "inference_id": "inf_01HXYZ123",
                "event_type": "ai.inference",
                "event_time": "2026-03-22T14:10:22Z",
                "actor": {
                    "agent_id": "user_123",
                    "agent_type": "human",
                    "delegated_by": "workflow_abc",
                },
                "system": {
                    "service_name": "ciaf_agents",
                    "environment": "production",
                    "region": "us-central1",
                },
                "model": {
                    "provider": "openai",
                    "model_name": "gpt-4.1",
                    "model_version": "2026-02",
                    "endpoint": "chat.completions",
                },
                "attributes": {
                    "gen_ai.operation.name": "chat",
                    "gen_ai.conversation.id": "conv_789",
                    "gen_ai.output.type": "text",
                    "ciaf.policy.decision": "allow",
                    "ciaf.risk.score": 0.18,
                },
                "facets": {
                    "ciaf_policy": {
                        "decision": "allow",
                        "rule_hits": ["safe_usage", "no_pii_detected"],
                        "policy_version": "3.2.1",
                    }
                },
            }
        },
    )


__all__ = [
    "InferenceMetadata",
    "InferenceActor",
    "InferenceSystem",
    "InferenceModel",
    "InferenceFacet",
    "CIAFPolicyFacet",
    "CIAFProvenanceFacet",
    "CIAFRiskFacet",
    "CIAFExecutionFacet",
    "CIAFDatasetFacet",
]
