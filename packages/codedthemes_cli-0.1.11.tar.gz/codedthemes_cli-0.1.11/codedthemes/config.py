import json
import socket
import hashlib
import uuid
from pathlib import Path

# Stores token at ~/.codedthemes/config.json
CONFIG_DIR = Path.home() / ".codedthemes"
CONFIG_FILE = CONFIG_DIR / "config.json"


def ensure_config_dir():
    """
    Ensures the configuration directory exists.
    """
    CONFIG_DIR.mkdir(exist_ok=True)


def save_config(data: dict):
    """
    Saves the provided configuration data to the config file (merging with existing).
    """
    ensure_config_dir()
    existing = load_config()
    existing.update(data)
    with open(CONFIG_FILE, "w") as f:
        json.dump(existing, f, indent=2)


def get_device_id():
    """
    Generates or retrieves a unique device ID for the machine.
    """
    
    config = load_config()
    if "device_id" in config:
        return config["device_id"]
        
    # Generate a stable device ID based on hostname and machine UUID
    try:
        hostname = socket.gethostname()
        device_uuid = str(uuid.getnode()) # MAC address based
        raw_id = f"{hostname}-{device_uuid}"
        device_id = hashlib.sha256(raw_id.encode()).hexdigest()[:12]
    except:
        device_id = str(uuid.uuid4())[:12]
        
    save_config({"device_id": device_id})
    return device_id



def load_config():
    """
    Loads the configuration data from the config file.
    """
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}
