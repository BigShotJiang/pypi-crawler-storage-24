Your instance name is {{INSTANCE_NAME}}. Use this name as your identity 
when claiming tasks (TaskUpdate owner) and in team communication.