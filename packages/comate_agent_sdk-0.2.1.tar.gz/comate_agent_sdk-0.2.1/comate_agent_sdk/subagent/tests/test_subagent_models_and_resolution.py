import unittest
from pathlib import Path
import tempfile

from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.subagent.agent_tool import create_agent_tool, resolve_model
from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic
from comate_agent_sdk.tools.registry import ToolRegistry


class TestSubagentModelsAndResolution(unittest.TestCase):
    def test_agent_definition_parses_level_and_inherit_model(self) -> None:
        md = """---
name: researcher
description: Research things
level: low
model: inherit
tools: []
---

You are a researcher.
"""
        agent_def = AgentDefinition.from_markdown(md)
        self.assertEqual(agent_def.level, "LOW")
        self.assertIsNone(agent_def.model)
        self.assertFalse(agent_def.allow_team_coordination)

    def test_agent_definition_parses_allow_team_coordination(self) -> None:
        md = """---
name: researcher
description: Research things
allow_team_coordination: true
tools: []
---

You are a researcher.
"""
        agent_def = AgentDefinition.from_markdown(md)

        self.assertTrue(agent_def.allow_team_coordination)

    def test_resolve_model_precedence_and_pool_mapping(self) -> None:
        parent = object()
        low = object()
        mid = parent
        high = object()
        llm_levels = {"LOW": low, "MID": mid, "HIGH": high}

        self.assertIs(
            resolve_model(model=None, level=None, parent_llm=parent, llm_levels=llm_levels),
            parent,
        )
        self.assertIs(
            resolve_model(model=None, level="LOW", parent_llm=parent, llm_levels=llm_levels),
            low,
        )
        self.assertIs(
            resolve_model(model="opus", level=None, parent_llm=parent, llm_levels=llm_levels),
            high,
        )
        self.assertIs(
            resolve_model(model="haiku", level="HIGH", parent_llm=parent, llm_levels=llm_levels),
            low,
        )

    def test_resolve_model_rejects_invalid_model(self) -> None:
        """测试：不支持的model值被忽略，回退到继承parent"""
        parent = ChatAnthropic(model="claude-sonnet-4-5")

        # 无效的model应该被忽略，返回parent
        result = resolve_model(
            model="gpt-4o",  # 无效值
            level=None,
            parent_llm=parent,
            llm_levels=None,
        )

        assert result is parent, "无效的model应该被忽略，返回parent_llm"

    def test_resolve_model_invalid_model_with_level_fallback(self) -> None:
        """测试：无效model被忽略后，回退到level"""
        parent = ChatAnthropic(model="claude-sonnet-4-5")
        low_llm = ChatAnthropic(model="claude-haiku-4-5")
        levels = {"LOW": low_llm, "MID": parent, "HIGH": parent}

        # 无效model + level: 应该回退到level
        result = resolve_model(
            model="gpt-4o",  # 无效值
            level="LOW",
            parent_llm=parent,
            llm_levels=levels,
        )

        assert result is low_llm, "无效model应该被忽略，使用level"

    def test_agent_definition_rejects_invalid_model(self) -> None:
        """测试：AgentDefinition解析时拒绝无效model"""
        content = """---
name: test-agent
description: Test
model: gpt-4o
---
Test prompt
"""
        agent_def = AgentDefinition.from_markdown(content)

        # 无效的model应该被置为None
        assert agent_def.model is None, "无效的model应该被置为None"

    def test_create_agent_tool_definition_matches_schema_contract(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            agent_tool = create_agent_tool(
                agents=[
                    AgentDefinition(
                        name="general-purpose",
                        description="General worker",
                        prompt="You are a worker.",
                        tools=[],
                    )
                ],
                parent_tools=[],
                tool_registry=ToolRegistry(),
                parent_cwd=Path(td),
                parent_llm=object(),  # type: ignore[arg-type]
            )

        schema = agent_tool.definition.parameters

        self.assertEqual(schema["type"], "object")
        self.assertFalse(schema.get("additionalProperties", True))
        self.assertEqual(schema["required"], ["subagent_type", "prompt"])
        self.assertEqual(
            schema["properties"]["subagent_type"]["description"],
            "Agent type: 'Explorer', 'Plan', 'general-purpose', or custom agent name",
        )
        self.assertEqual(
            schema["properties"]["prompt"]["description"],
            "Complete task description. Must be self-contained - subagent has no prior context.",
        )
        self.assertEqual(
            schema["properties"]["description"]["description"],
            "3-5 word task summary for display",
        )
        self.assertEqual(
            schema["properties"]["team_name"]["description"],
            "Join this team as a persistent teammate (requires prior TeamCreate)",
        )
        self.assertEqual(
            schema["properties"]["name"]["description"],
            "Teammate display name. Required when team_name is set.",
        )
        self.assertEqual(
            schema["properties"]["isolation"]["enum"],
            ["", "worktree"],
        )
        self.assertEqual(
            schema["properties"]["isolation"]["description"],
            "'' = share parent cwd; 'worktree' = isolated git worktree",
        )


if __name__ == "__main__":
    unittest.main()
