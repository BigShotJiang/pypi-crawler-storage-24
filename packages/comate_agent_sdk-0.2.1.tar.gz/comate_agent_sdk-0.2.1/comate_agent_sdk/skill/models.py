"""Skill 定义模型（兼容 Claude Code SKILL.md 格式）"""

import logging
from dataclasses import dataclass
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


def _parse_yaml_frontmatter(
    frontmatter_text: str,
    *,
    used_legacy_opening: bool,
    used_legacy_closing: bool,
    skill_path: str | None = None,
) -> dict[str, object]:
    location = f" (skill: {skill_path})" if skill_path else ""
    if used_legacy_opening:
        logger.warning(
            f"Skill frontmatter is missing opening fence '---'; parsing legacy format{location}"
        )

    if used_legacy_closing:
        logger.warning(
            f"Skill frontmatter uses legacy closing fence '--'; prefer '---'{location}"
        )

    frontmatter = yaml.safe_load(frontmatter_text) or {}
    if not isinstance(frontmatter, dict):
        raise ValueError(f"Skill frontmatter must be a YAML mapping{location}")

    return frontmatter


def _try_split_legacy_frontmatter_without_opening(
    content: str, skill_path: str | None = None
) -> tuple[dict[str, object], str] | None:
    """兼容历史遗留格式：没有 opening fence，但存在 YAML 头和 closing fence。"""
    lines = content.splitlines()
    closing_index: int | None = None
    used_legacy_closing = False

    for index, line in enumerate(lines):
        stripped_line = line.strip()
        if stripped_line == "---":
            closing_index = index
            break
        if stripped_line == "--":
            closing_index = index
            used_legacy_closing = True
            break
        if not stripped_line or ":" not in stripped_line:
            return None

    if closing_index is None or closing_index == 0:
        return None

    frontmatter_text = "\n".join(lines[:closing_index])
    prompt = "\n".join(lines[closing_index + 1 :]).strip()
    frontmatter = _parse_yaml_frontmatter(
        frontmatter_text,
        used_legacy_opening=True,
        used_legacy_closing=used_legacy_closing,
        skill_path=skill_path,
    )
    return frontmatter, prompt


def _split_frontmatter(content: str, skill_path: str | None = None) -> tuple[dict[str, object], str]:
    """分离 Skill frontmatter 和正文。

    兼容两种 closing fence：
    - `---`：标准 YAML frontmatter 结束符
    - `--`：历史遗留写法，保持兼容并记录 warning
    """
    if not content.startswith("---"):
        legacy_split = _try_split_legacy_frontmatter_without_opening(content, skill_path=skill_path)
        if legacy_split is not None:
            return legacy_split
        return {}, content

    lines = content.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, content

    closing_index: int | None = None
    used_legacy_closing = False

    for index, line in enumerate(lines[1:], start=1):
        stripped_line = line.strip()
        if stripped_line == "---":
            closing_index = index
            break
        if stripped_line == "--":
            closing_index = index
            used_legacy_closing = True
            break

    if closing_index is None:
        return {}, content

    frontmatter_text = "\n".join(lines[1:closing_index])
    prompt = "\n".join(lines[closing_index + 1 :]).strip()
    frontmatter = _parse_yaml_frontmatter(
        frontmatter_text,
        used_legacy_opening=False,
        used_legacy_closing=used_legacy_closing,
        skill_path=skill_path,
    )
    return frontmatter, prompt


@dataclass(frozen=True, slots=True)
class SkillDefinition:
    """Skill 定义（兼容 Claude Code SKILL.md 格式）"""

    # 核心字段
    name: str  # 如果 frontmatter 没有 name，使用目录名
    description: str  # 如果 frontmatter 没有 description，使用 prompt 第一段
    prompt: str  # Markdown 正文

    # 可选字段（Frontmatter）
    model: str | None = None  # [已弃用] 该字段已被忽略，请使用 Subagent 代替
    argument_hint: str | None = None  # 暂时保留但不使用
    disable_model_invocation: bool = False
    user_invocable: bool = True  # 暂时保留但不使用

    # 资源路径（自动发现）
    base_dir: Path | None = None
    scripts_dir: Path | None = None
    references_dir: Path | None = None
    assets_dir: Path | None = None

    @classmethod
    def from_markdown(cls, content: str, dir_name: str, base_dir: Path | None = None) -> "SkillDefinition":
        """从 Markdown 内容解析 Skill

        Args:
            content: SKILL.md 文件内容
            dir_name: Skill 目录名（用作 name 的后备值）
            base_dir: Skill 基础目录路径
        """
        skill_path = str(base_dir) if base_dir else dir_name
        frontmatter, prompt = _split_frontmatter(content, skill_path=skill_path)

        # 提取 name（优先 frontmatter，后备为目录名）
        name = frontmatter.get("name") or dir_name

        # 提取 description（优先 frontmatter，后备为 prompt 第一段）
        description = frontmatter.get("description")
        if not description and prompt:
            # 使用第一段作为 description
            first_paragraph = prompt.split("\n\n")[0].strip()
            description = first_paragraph[:200]  # 限制长度
            # 移除 markdown 标题标记
            if description.startswith("#"):
                description = description.lstrip("#").strip()

        if not description:
            description = f"Skill: {name}"

        return cls(
            name=name,
            description=description,
            prompt=prompt,
            model=frontmatter.get("model"),
            argument_hint=frontmatter.get("argument-hint") or frontmatter.get("argument_hint"),
            disable_model_invocation=frontmatter.get("disable-model-invocation", False)
            or frontmatter.get("disable_model_invocation", False),
            user_invocable=frontmatter.get("user-invocable", True) or frontmatter.get("user_invocable", True),
            base_dir=base_dir,
        )

    @classmethod
    def from_directory(cls, skill_dir: Path) -> "SkillDefinition":
        """从目录加载 Skill（支持资源打包）

        目录结构：
        .agent/skills/skillname/
        ├── SKILL.md  (必需)
        ├── scripts/  (可选)
        ├── references/  (可选)
        └── assets/  (可选)
        """
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            raise ValueError(f"No SKILL.md found in {skill_dir}")

        content = skill_md.read_text(encoding="utf-8")
        skill = cls.from_markdown(content, dir_name=skill_dir.name, base_dir=skill_dir)

        scripts_dir = skill_dir / "scripts" if (skill_dir / "scripts").exists() else None
        references_dir = skill_dir / "references" if (skill_dir / "references").exists() else None
        assets_dir = skill_dir / "assets" if (skill_dir / "assets").exists() else None

        return cls(
            name=skill.name,
            description=skill.description,
            prompt=skill.prompt,
            model=skill.model,
            argument_hint=skill.argument_hint,
            disable_model_invocation=skill.disable_model_invocation,
            user_invocable=skill.user_invocable,
            base_dir=skill.base_dir,
            scripts_dir=scripts_dir,
            references_dir=references_dir,
            assets_dir=assets_dir,
        )

    def get_prompt(self) -> str:
        """获取完整 prompt（替换变量）"""
        prompt = self.prompt
        if self.base_dir:
            prompt = prompt.replace("{baseDir}", str(self.base_dir))
        return prompt
