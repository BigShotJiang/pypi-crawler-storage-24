from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.tools import tool


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


@tool("fake mcp tool")
async def MCPDemo() -> str:
    return "ok"


setattr(MCPDemo, "_comate_agent_sdk_mcp_tool", True)


class _FakeMcpManager:
    last_servers = None

    def __init__(self, servers):  # type: ignore[no-untyped-def]
        self._servers = servers
        type(self).last_servers = servers
        self.tools = [MCPDemo]

    async def start(self) -> None:
        return None

    async def aclose(self) -> None:
        return None

    def build_overview_text(self) -> str:
        return "NEW_MCP_OVERVIEW"

    def build_metadata(self) -> dict[str, str]:
        return {"source": "fake"}


class _BlockingFakeMcpManager(_FakeMcpManager):
    start_calls = 0
    started_event: asyncio.Event | None = None
    release_event: asyncio.Event | None = None

    async def start(self) -> None:
        type(self).start_calls += 1
        started_event = type(self).started_event
        if started_event is not None:
            started_event.set()
        release_event = type(self).release_event
        if release_event is not None:
            await release_event.wait()


class TestMcpHeaderLock(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        _FakeMcpManager.last_servers = None
        _BlockingFakeMcpManager.start_calls = 0
        _BlockingFakeMcpManager.started_event = None
        _BlockingFakeMcpManager.release_event = None

    async def test_snapshot_lock_does_not_block_mcp_session_state_updates(self) -> None:
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        runtime = template.create_runtime()
        runtime._lock_header_from_snapshot = True

        header_calls: list[str] = []
        runtime._context.set_mcp_tools = lambda *args, **kwargs: header_calls.append("set")  # type: ignore[method-assign]
        runtime._context.remove_mcp_tools = lambda *args, **kwargs: header_calls.append("remove")  # type: ignore[method-assign]

        with (
            patch("comate_agent_sdk.mcp.config.resolve_mcp_servers", return_value=[{"name": "fake"}]),
            patch("comate_agent_sdk.mcp.manager.McpManager", _FakeMcpManager),
        ):
            await runtime.ensure_mcp_tools_loaded(force=True)

        self.assertEqual(header_calls, ["set"])

    async def test_create_runtime_with_str_cwd_loads_project_mcp_config(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            home = Path(td) / "home"
            project_root = Path(td) / "project"
            project_file = project_root / ".agent" / ".mcp.json"
            project_file.parent.mkdir(parents=True, exist_ok=True)
            project_file.write_text(
                json.dumps(
                    {
                        "mcpServers": {
                            "project-calc": {
                                "type": "stdio",
                                "command": "npx",
                                "args": ["-y", "@example/calc-mcp"],
                            }
                        }
                    }
                ),
                encoding="utf-8",
            )

            template = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(
                session_id="runtime-str-cwd",
                cwd=str(project_root),
            )

            with (
                patch("pathlib.Path.home", return_value=home),
                patch("comate_agent_sdk.mcp.manager.McpManager", _FakeMcpManager),
            ):
                await runtime.ensure_mcp_tools_loaded(force=True)

            self.assertEqual(runtime.options.cwd, project_root.resolve())
            self.assertIsNotNone(_FakeMcpManager.last_servers)
            assert _FakeMcpManager.last_servers is not None
            self.assertIn("project-calc", _FakeMcpManager.last_servers)
            self.assertEqual(
                _FakeMcpManager.last_servers["project-calc"]["command"],
                "npx",
            )

    async def test_runtime_keeps_mcp_dirty_when_config_changes_during_load(self) -> None:
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        runtime = template.create_runtime()
        runtime._mcp_dirty = True
        started = asyncio.Event()
        release = asyncio.Event()
        _BlockingFakeMcpManager.started_event = started
        _BlockingFakeMcpManager.release_event = release

        with (
            patch("comate_agent_sdk.mcp.config.resolve_mcp_servers", return_value=[{"name": "fake"}]),
            patch("comate_agent_sdk.mcp.manager.McpManager", _BlockingFakeMcpManager),
        ):
            load_task = asyncio.create_task(runtime.ensure_mcp_tools_loaded())
            await started.wait()
            runtime.invalidate_mcp_tools(reason="during_load")
            release.set()
            await load_task

            self.assertTrue(runtime._mcp_dirty)

            await runtime.ensure_mcp_tools_loaded()

        self.assertEqual(_BlockingFakeMcpManager.start_calls, 2)
        self.assertFalse(runtime._mcp_dirty)
