"""Tests for protqc.tools.structure_scorer — PDB pLDDT extraction."""

import tempfile
from pathlib import Path

import pytest

from protqc.tools.structure_scorer import StructurePredictor


@pytest.fixture
def scorer() -> StructurePredictor:
    return StructurePredictor()


@pytest.fixture
def colabfold_pdb(fixtures_dir: Path) -> Path:
    return fixtures_dir / "colabfold_sample.pdb"


@pytest.fixture
def low_conf_pdb(fixtures_dir: Path) -> Path:
    return fixtures_dir / "low_confidence.pdb"


# ---------------------------------------------------------------------------
# Happy path — ColabFold output
# ---------------------------------------------------------------------------


class TestColabFoldExtraction:
    # Known values from colabfold_sample.pdb CA atoms:
    # MET1=95.20, SER2=97.10, LYS3=96.80, GLY4=92.50,
    # GLU5=98.30, GLU6=94.60, LEU7=88.40, PHE8=91.00
    EXPECTED_VALUES = [95.20, 97.10, 96.80, 92.50, 98.30, 94.60, 88.40, 91.00]
    EXPECTED_MEAN = sum(EXPECTED_VALUES) / len(EXPECTED_VALUES)

    def test_success(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        assert result["success"] is True
        assert result["error"] is None
        assert result["tool_name"] == "structure_scorer"

    def test_plddt_mean(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        m = result["metrics"]
        assert abs(m["plddt_mean"] - self.EXPECTED_MEAN) < 0.1

    def test_plddt_min(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        assert result["metrics"]["plddt_min"] == 88.40

    def test_plddt_max(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        assert result["metrics"]["plddt_max"] == 98.30

    def test_per_residue_count(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        m = result["metrics"]
        assert len(m["plddt_per_residue"]) == 8
        assert m["sequence_length"] == 8

    def test_per_residue_values(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        per_res = result["metrics"]["plddt_per_residue"]
        for actual, expected in zip(per_res, self.EXPECTED_VALUES):
            assert abs(actual - expected) < 0.01

    def test_low_confidence_none(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        assert result["metrics"]["low_confidence_residues"] == 0

    def test_high_confidence_pct(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        # All 8 residues have pLDDT > 70
        assert result["metrics"]["high_confidence_pct"] == 100.0

    def test_plddt_detected(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        assert result["metrics"]["plddt_detected"] is True


# ---------------------------------------------------------------------------
# Low confidence prediction
# ---------------------------------------------------------------------------


class TestLowConfidenceExtraction:
    # Known values: ALA1=35.20, GLY2=42.80, VAL3=58.10, ASP4=28.50, LEU5=61.30
    EXPECTED_VALUES = [35.20, 42.80, 58.10, 28.50, 61.30]

    def test_success(self, scorer: StructurePredictor, low_conf_pdb: Path):
        result = scorer.extract_plddt(low_conf_pdb)
        assert result["success"] is True

    def test_low_confidence_count(self, scorer: StructurePredictor, low_conf_pdb: Path):
        result = scorer.extract_plddt(low_conf_pdb)
        # ALA1=35.20, GLY2=42.80, and ASP4=28.50 are below 50
        assert result["metrics"]["low_confidence_residues"] == 3

    def test_sequence_length(self, scorer: StructurePredictor, low_conf_pdb: Path):
        result = scorer.extract_plddt(low_conf_pdb)
        assert result["metrics"]["sequence_length"] == 5

    def test_plddt_min(self, scorer: StructurePredictor, low_conf_pdb: Path):
        result = scorer.extract_plddt(low_conf_pdb)
        assert result["metrics"]["plddt_min"] == 28.50

    def test_high_confidence_pct(self, scorer: StructurePredictor, low_conf_pdb: Path):
        result = scorer.extract_plddt(low_conf_pdb)
        # VAL3=58.10 and LEU5=61.30 are > 70? No, both < 70. None > 70.
        # Wait: 58.10 < 70, 61.30 < 70. So 0% high confidence.
        assert result["metrics"]["high_confidence_pct"] == 0.0


# ---------------------------------------------------------------------------
# Mini PDB (B-factors = 0.00 — standard PDB without pLDDT)
# ---------------------------------------------------------------------------


class TestMiniPdb:
    def test_success(self, scorer: StructurePredictor, mini_pdb: Path):
        result = scorer.extract_plddt(mini_pdb)
        assert result["success"] is True

    def test_zero_bfactors(self, scorer: StructurePredictor, mini_pdb: Path):
        result = scorer.extract_plddt(mini_pdb)
        m = result["metrics"]
        assert m["plddt_mean"] == 0.0
        assert m["plddt_min"] == 0.0

    def test_plddt_detected_with_zeros(self, scorer: StructurePredictor, mini_pdb: Path):
        result = scorer.extract_plddt(mini_pdb)
        # B-factors are 0.0 — technically in 0-100 range, so plddt_detected=True
        # but all values are 0 which is meaningless
        assert result["metrics"]["plddt_detected"] is True


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_file(self, scorer: StructurePredictor):
        result = scorer.extract_plddt("nonexistent.pdb")
        assert result["success"] is False
        assert "not found" in result["error"].lower()
        assert result["metrics"] == {}

    def test_empty_file(self, scorer: StructurePredictor, tmp_path: Path):
        empty = tmp_path / "empty.pdb"
        empty.write_text("")
        result = scorer.extract_plddt(empty)
        assert result["success"] is False
        assert "empty" in result["error"].lower()

    def test_no_atom_records(self, scorer: StructurePredictor, tmp_path: Path):
        no_atoms = tmp_path / "no_atoms.pdb"
        no_atoms.write_text("HEADER    TEST\nREMARK    No atoms here\nEND\n")
        result = scorer.extract_plddt(no_atoms)
        assert result["success"] is False
        assert "no atom" in result["error"].lower()

    def test_directory_not_file(self, scorer: StructurePredictor, tmp_path: Path):
        result = scorer.extract_plddt(tmp_path)
        assert result["success"] is False
        assert "not a file" in result["error"].lower()

    def test_result_is_tool_result_shape(self, scorer: StructurePredictor):
        """Even failure results must have all ToolResult keys."""
        result = scorer.extract_plddt("nonexistent.pdb")
        assert "tool_name" in result
        assert "success" in result
        assert "metrics" in result
        assert "error" in result


# ---------------------------------------------------------------------------
# String path and Path object both work
# ---------------------------------------------------------------------------


class TestPathTypes:
    def test_string_path(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(str(colabfold_pdb))
        assert result["success"] is True

    def test_path_object(self, scorer: StructurePredictor, colabfold_pdb: Path):
        result = scorer.extract_plddt(colabfold_pdb)
        assert result["success"] is True
