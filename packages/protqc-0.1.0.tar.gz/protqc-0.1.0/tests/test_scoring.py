"""Tests for protqc.scoring — risk score calculation."""

import pytest

from protqc.scoring import calculate_risk_score, normalize_metric


# ---------------------------------------------------------------------------
# normalize_metric
# ---------------------------------------------------------------------------


class TestNormalizeMetric:
    def test_lower_better_zero(self):
        assert normalize_metric(0.0, 5.0, "lower_better") == 0.0

    def test_lower_better_at_threshold(self):
        # threshold → 0.5 risk (midpoint, not max)
        assert abs(normalize_metric(5.0, 5.0, "lower_better") - 0.5) < 0.01

    def test_lower_better_half(self):
        # half of threshold → 0.25 risk
        assert abs(normalize_metric(2.5, 5.0, "lower_better") - 0.25) < 0.01

    def test_lower_better_double_threshold(self):
        # 2× threshold → 1.0 risk (capped)
        assert normalize_metric(10.0, 5.0, "lower_better") == 1.0

    def test_lower_better_clamped(self):
        assert normalize_metric(20.0, 5.0, "lower_better") == 1.0

    def test_higher_better_perfect(self):
        # value == threshold means risk = 0.0
        assert normalize_metric(100.0, 100.0, "higher_better") == 0.0

    def test_higher_better_zero(self):
        assert normalize_metric(0.0, 100.0, "higher_better") == 1.0

    def test_higher_better_half(self):
        assert abs(normalize_metric(50.0, 100.0, "higher_better") - 0.5) < 0.01

    def test_zero_threshold(self):
        assert normalize_metric(5.0, 0.0, "lower_better") == 0.0


# ---------------------------------------------------------------------------
# Full config fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def full_config() -> dict:
    return {
        "structure_scorer": {"plddt_min": 70},
        "physics_verifier": {"md_rmsd_max_angstrom": 3.0},
        "stability": {"rasp_ddg_max_kcal": 3.0},
        "cavity": {
            "fpocket_total_volume_max_cubic_angstrom": 1500,
            "fpocket_volume_per_residue_max": 5.0,
        },
        "surface": {"sasa_polar_ratio_min": 0.55, "sasa_polar_ratio_max": 0.85},
        "hbond": {"persistence_min_pct": 70},
        "secondary_structure": {"preservation_min_pct": 75},
        "risk_weights": {
            "plddt": 0.10,
            "md_rmsd": 0.25,
            "stability_ddg": 0.15,
            "cavity": 0.10,
            "hbond_persistence": 0.20,
            "ss_preservation": 0.15,
            "sasa_ratio": 0.05,
        },
        "verdicts": {"pass_threshold": 0.30, "warn_threshold": 0.50},
    }


# ---------------------------------------------------------------------------
# calculate_risk_score — full metrics
# ---------------------------------------------------------------------------


class TestFullMetrics:
    def test_perfect_metrics_pass(self, full_config: dict):
        metrics = {
            "plddt_mean": 95.0,
            "rmsd_max_A": 0.5,
            "ddg_kcal": 0.1,
            "suspicious_volume_A3": 0.0,
            "hbond_persistence_pct": 90.0,
            "ss_preservation_pct": 95.0,
            "polar_ratio": 0.70,
        }
        result = calculate_risk_score(metrics, full_config)
        assert result["verdict"] == "PASS"
        assert result["risk_score"] < 0.30

    def test_terrible_metrics_fail(self, full_config: dict):
        metrics = {
            "plddt_mean": 20.0,
            "rmsd_max_A": 15.0,
            "ddg_kcal": 10.0,
            "suspicious_volume_A3": 1500.0,
            "sequence_length": 100,
            "hbond_persistence_pct": 5.0,
            "ss_preservation_pct": 10.0,
            "polar_ratio": 0.95,
        }
        result = calculate_risk_score(metrics, full_config)
        assert result["verdict"] == "FAIL"
        assert result["risk_score"] >= 0.50

    def test_result_has_all_keys(self, full_config: dict):
        result = calculate_risk_score({"plddt_mean": 80.0}, full_config)
        assert "risk_score" in result
        assert "verdict" in result
        assert "breakdown" in result
        assert "weights" in result
        assert "explanation" in result

    def test_breakdown_matches_available(self, full_config: dict):
        metrics = {
            "plddt_mean": 85.0,
            "suspicious_volume_A3": 0.0,
            "polar_ratio": 0.70,
        }
        result = calculate_risk_score(metrics, full_config)
        assert "plddt" in result["breakdown"]
        assert "cavity" in result["breakdown"]
        assert "sasa_ratio" in result["breakdown"]
        # MD metrics not provided, should not be in breakdown
        assert "md_rmsd" not in result["breakdown"]


# ---------------------------------------------------------------------------
# Partial / missing metrics
# ---------------------------------------------------------------------------


class TestPartialMetrics:
    def test_empty_metrics(self, full_config: dict):
        result = calculate_risk_score({}, full_config)
        assert result["verdict"] in ("PASS", "WARNING", "FAIL")
        assert result["risk_score"] == 0.0
        assert result["breakdown"] == {}

    def test_single_metric(self, full_config: dict):
        result = calculate_risk_score({"plddt_mean": 50.0}, full_config)
        assert "plddt" in result["breakdown"]
        # Only plddt weight active, renormalized to 1.0
        assert abs(result["weights"]["plddt"] - 1.0) < 0.01

    def test_weights_renormalize(self, full_config: dict):
        metrics = {
            "plddt_mean": 80.0,
            "suspicious_volume_A3": 100.0,
            "sequence_length": 100,
        }
        result = calculate_risk_score(metrics, full_config)
        total_w = sum(result["weights"].values())
        assert abs(total_w - 1.0) < 0.01


# ---------------------------------------------------------------------------
# SASA range handling
# ---------------------------------------------------------------------------


class TestSASARange:
    def test_normal_range_zero_risk(self, full_config: dict):
        result = calculate_risk_score({"polar_ratio": 0.70}, full_config)
        assert result["breakdown"]["sasa_ratio"] == 0.0

    def test_too_hydrophobic(self, full_config: dict):
        result = calculate_risk_score({"polar_ratio": 0.40}, full_config)
        assert result["breakdown"]["sasa_ratio"] > 0.0

    def test_too_hydrophilic(self, full_config: dict):
        result = calculate_risk_score({"polar_ratio": 0.95}, full_config)
        assert result["breakdown"]["sasa_ratio"] > 0.0


# ---------------------------------------------------------------------------
# Verdict thresholds
# ---------------------------------------------------------------------------


class TestVerdicts:
    def test_pass_verdict(self, full_config: dict):
        # Perfect metrics -> PASS
        metrics = {
            "plddt_mean": 95.0,
            "rmsd_max_A": 0.5,
            "ddg_kcal": 0.1,
            "suspicious_volume_A3": 0.0,
            "hbond_persistence_pct": 90.0,
            "ss_preservation_pct": 95.0,
            "polar_ratio": 0.70,
        }
        result = calculate_risk_score(metrics, full_config)
        assert result["verdict"] == "PASS"

    def test_explanation_string(self, full_config: dict):
        result = calculate_risk_score({"plddt_mean": 10.0}, full_config)
        assert isinstance(result["explanation"], str)
        assert "Risk Score" in result["explanation"]


# ---------------------------------------------------------------------------
# Cavity risk — suspicious cavity scoring
# ---------------------------------------------------------------------------


class TestCavitySuspicious:
    def test_no_suspicious_cavities_zero_risk(self, full_config: dict):
        """No suspicious cavities → cavity risk = 0.0."""
        metrics = {
            "suspicious_volume_A3": 0.0,
            "sequence_length": 76,
        }
        result = calculate_risk_score(metrics, full_config)
        assert result["breakdown"]["cavity"] == 0.0

    def test_ubiquitin_no_suspicious_zero_risk(self, full_config: dict):
        """Ubiquitin (76 aa): no suspicious cavities → risk 0.0."""
        metrics = {
            "suspicious_volume_A3": 0.0,
            "sequence_length": 76,
        }
        result = calculate_risk_score(metrics, full_config)
        assert result["breakdown"]["cavity"] == 0.0

    def test_suspicious_void_per_residue_risk(self, full_config: dict):
        """Suspicious void normalized per residue against threshold."""
        metrics = {
            "suspicious_volume_A3": 900.0,
            "sequence_length": 200,
        }
        result = calculate_risk_score(metrics, full_config)
        # 900/200 = 4.5 A³/residue, threshold 5.0 → 4.5/(2*5.0) = 0.45
        assert abs(result["breakdown"]["cavity"] - 0.45) < 0.01

    def test_suspicious_void_clamped_at_one(self, full_config: dict):
        """Very large suspicious void → risk clamped at 1.0."""
        metrics = {
            "suspicious_volume_A3": 2000.0,
            "sequence_length": 100,
        }
        result = calculate_risk_score(metrics, full_config)
        # 2000/100 = 20.0 A³/residue >> threshold 5.0 → clamped to 1.0
        assert result["breakdown"]["cavity"] == 1.0

    def test_fallback_to_filtered_volume(self, full_config: dict):
        """Old data without suspicious_volume_A3 falls back to filtered_volume_A3."""
        metrics = {
            "filtered_volume_A3": 100.0,
            "sequence_length": 100,
        }
        result = calculate_risk_score(metrics, full_config)
        assert "cavity" in result["breakdown"]

    def test_fallback_to_total_volume(self, full_config: dict):
        """Old data without filtered or suspicious falls back to total_volume_A3."""
        metrics = {
            "total_volume_A3": 100.0,
            "sequence_length": 100,
        }
        result = calculate_risk_score(metrics, full_config)
        assert "cavity" in result["breakdown"]

    def test_no_sequence_length_uses_absolute(self, full_config: dict):
        """Without sequence_length, falls back to absolute volume threshold."""
        metrics = {"suspicious_volume_A3": 750.0}
        result = calculate_risk_score(metrics, full_config)
        # 750 / (2 * 1500) = 0.25
        assert abs(result["breakdown"]["cavity"] - 0.25) < 0.01
