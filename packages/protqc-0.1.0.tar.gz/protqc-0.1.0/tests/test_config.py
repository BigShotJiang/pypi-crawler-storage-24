"""Tests for protqc.config — config loading, validation, and error handling."""

import os
import tempfile
from pathlib import Path

import pytest
import yaml

from protqc.config import ConfigError, load_config, REQUIRED_KEYS


def test_load_default_config():
    """load_config() with no args finds configs/thresholds.yaml from CWD."""
    # This test runs from the project root where configs/thresholds.yaml exists
    config = load_config()
    assert isinstance(config, dict)
    for key in REQUIRED_KEYS:
        assert key in config, f"Missing required key: {key}"


def test_load_config_explicit_path():
    """load_config(path=...) loads a specific file."""
    config = load_config(path="configs/thresholds.yaml")
    assert "risk_weights" in config
    assert "verdicts" in config


def test_load_config_missing_file():
    """load_config raises ConfigError for nonexistent file."""
    with pytest.raises(ConfigError, match="not found"):
        load_config(path="nonexistent_config.yaml")


def test_load_config_invalid_yaml():
    """load_config raises ConfigError for malformed YAML."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False
    ) as f:
        f.write("invalid: yaml: content: [unterminated")
        f.flush()
        try:
            with pytest.raises(ConfigError, match="Failed to parse"):
                load_config(path=f.name)
        finally:
            os.unlink(f.name)


def test_load_config_missing_keys():
    """load_config raises ConfigError when required sections are missing."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False
    ) as f:
        yaml.dump({"only_one_key": True}, f)
        f.flush()
        try:
            with pytest.raises(ConfigError, match="missing required sections"):
                load_config(path=f.name)
        finally:
            os.unlink(f.name)


def test_load_config_non_dict():
    """load_config raises ConfigError when YAML parses as non-dict."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".yaml", delete=False
    ) as f:
        f.write("- just\n- a\n- list\n")
        f.flush()
        try:
            with pytest.raises(ConfigError, match="did not parse as a dict"):
                load_config(path=f.name)
        finally:
            os.unlink(f.name)


def test_risk_weights_sum_approximately_one():
    """Risk weights should sum to approximately 1.0."""
    config = load_config()
    weights = config["risk_weights"]
    total = sum(weights.values())
    assert 0.99 <= total <= 1.01, f"Risk weights sum to {total}, expected ~1.0"


def test_verdict_thresholds_ordered():
    """pass_threshold must be less than warn_threshold."""
    config = load_config()
    verdicts = config["verdicts"]
    assert verdicts["pass_threshold"] < verdicts["warn_threshold"]


def test_config_has_all_metric_thresholds():
    """Config must have thresholds for every metric the risk scorer uses."""
    config = load_config()
    assert config["structure_scorer"]["plddt_min"] > 0
    assert config["physics_verifier"]["md_rmsd_max_angstrom"] > 0
    assert config["cavity"]["fpocket_total_volume_max_cubic_angstrom"] > 0
    assert config["surface"]["sasa_polar_ratio_min"] > 0
    assert config["hbond"]["persistence_min_pct"] > 0
    assert config["secondary_structure"]["preservation_min_pct"] > 0


def test_fixture_pdb_exists(mini_pdb: Path):
    """The fixture PDB file must exist and have content."""
    assert mini_pdb.exists()
    content = mini_pdb.read_text()
    assert "ATOM" in content
    assert len(content) > 100
