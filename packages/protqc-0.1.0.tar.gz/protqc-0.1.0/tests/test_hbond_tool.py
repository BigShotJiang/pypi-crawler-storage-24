"""Tests for protqc.tools.hbond_tool — H-bond persistence."""

from pathlib import Path
from unittest.mock import patch

import pytest

from protqc.tools.hbond_tool import MDTRAJ_AVAILABLE, HBondAnalyzer

SKIP_MDTRAJ = pytest.mark.skipif(
    not MDTRAJ_AVAILABLE,
    reason="mdtraj not installed",
)


@pytest.fixture
def analyzer() -> HBondAnalyzer:
    return HBondAnalyzer(config={})


# ---------------------------------------------------------------------------
# Availability guard
# ---------------------------------------------------------------------------


class TestAvailabilityGuard:
    def test_unavailable_returns_error(self, analyzer: HBondAnalyzer):
        with patch("protqc.tools.hbond_tool.MDTRAJ_AVAILABLE", False):
            result = analyzer.analyze("topo.pdb", "traj.dcd")
            assert result["success"] is False
            assert "not installed" in result["error"].lower()

    def test_result_shape(self, analyzer: HBondAnalyzer):
        with patch("protqc.tools.hbond_tool.MDTRAJ_AVAILABLE", False):
            result = analyzer.analyze("topo.pdb", "traj.dcd")
            assert result["tool_name"] == "hbond"
            assert "success" in result
            assert "metrics" in result
            assert "error" in result


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_topology(self, analyzer: HBondAnalyzer):
        result = analyzer.analyze("nonexistent.pdb", "nonexistent.dcd")
        assert result["success"] is False

    def test_missing_trajectory(self, analyzer: HBondAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(mini_pdb, "nonexistent.dcd")
        assert result["success"] is False
