"""Tests for protqc.types — verify TypedDict definitions are importable and well-formed."""

from protqc.types import (
    ToolResult,
    VerificationMetrics,
    RiskVerdict,
    PipelineResult,
)


def test_tool_result_has_required_keys():
    """ToolResult must define tool_name, success, metrics, error."""
    annotations = ToolResult.__annotations__
    assert "tool_name" in annotations
    assert "success" in annotations
    assert "metrics" in annotations
    assert "error" in annotations


def test_verification_metrics_has_core_fields():
    """VerificationMetrics must include all risk-weight-relevant fields."""
    annotations = VerificationMetrics.__annotations__
    core_fields = [
        "plddt_mean",
        "rmsd_max_A",
        "total_volume_A3",
        "polar_ratio",
        "hbond_persistence_pct",
        "ss_preservation_pct",
    ]
    for field in core_fields:
        assert field in annotations, f"Missing field: {field}"


def test_risk_verdict_has_required_keys():
    """RiskVerdict must define risk_score, verdict, breakdown, weights, explanation."""
    annotations = RiskVerdict.__annotations__
    for key in ["risk_score", "verdict", "breakdown", "weights", "explanation"]:
        assert key in annotations, f"Missing key: {key}"


def test_pipeline_result_has_required_keys():
    """PipelineResult must define design_name, pdb_path, metrics, verdict, etc."""
    annotations = PipelineResult.__annotations__
    for key in ["design_name", "pdb_path", "metrics", "verdict", "input_mode"]:
        assert key in annotations, f"Missing key: {key}"


def test_verification_metrics_is_total_false():
    """VerificationMetrics should be total=False (not all fields required)."""
    # TypedDict with total=False has __required_keys__ as empty or partial
    # The important thing: we can create a partial instance without error
    partial: VerificationMetrics = {"plddt_mean": 0.85}  # type: ignore[typeddict-item]
    assert partial["plddt_mean"] == 0.85


def test_types_importable_from_top_level():
    """Types should be importable from the top-level package."""
    from protqc import ToolResult, VerificationMetrics, RiskVerdict, PipelineResult

    assert ToolResult is not None
    assert VerificationMetrics is not None
    assert RiskVerdict is not None
    assert PipelineResult is not None
