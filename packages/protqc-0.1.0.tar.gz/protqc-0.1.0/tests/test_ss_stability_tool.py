"""Tests for protqc.tools.ss_stability_tool — DSSP secondary structure."""

from pathlib import Path
from unittest.mock import patch

import pytest

from protqc.tools.ss_stability_tool import MDTRAJ_AVAILABLE, SSStabilityAnalyzer

SKIP_MDTRAJ = pytest.mark.skipif(
    not MDTRAJ_AVAILABLE,
    reason="mdtraj not installed",
)


@pytest.fixture
def analyzer() -> SSStabilityAnalyzer:
    return SSStabilityAnalyzer(config={})


# ---------------------------------------------------------------------------
# Availability guard
# ---------------------------------------------------------------------------


class TestAvailabilityGuard:
    def test_unavailable_returns_error(self, analyzer: SSStabilityAnalyzer):
        with patch(
            "protqc.tools.ss_stability_tool.MDTRAJ_AVAILABLE", False
        ):
            result = analyzer.analyze("topo.pdb", "traj.dcd")
            assert result["success"] is False
            assert "not installed" in result["error"].lower()

    def test_result_shape(self, analyzer: SSStabilityAnalyzer):
        with patch(
            "protqc.tools.ss_stability_tool.MDTRAJ_AVAILABLE", False
        ):
            result = analyzer.analyze("topo.pdb", "traj.dcd")
            assert result["tool_name"] == "ss_stability"
            assert "success" in result
            assert "metrics" in result
            assert "error" in result


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_topology(self, analyzer: SSStabilityAnalyzer):
        result = analyzer.analyze("nonexistent.pdb", "nonexistent.dcd")
        assert result["success"] is False

    def test_missing_trajectory(self, analyzer: SSStabilityAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(mini_pdb, "nonexistent.dcd")
        assert result["success"] is False
