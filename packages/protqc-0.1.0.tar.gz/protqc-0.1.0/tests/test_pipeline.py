"""Tests for protqc.pipeline — orchestration."""

from pathlib import Path
from unittest.mock import patch

import pytest

from protqc.pipeline import run_pipeline
from protqc.types import ToolResult


@pytest.fixture
def pipeline_config() -> dict:
    return {
        "structure_scorer": {"plddt_min": 0.70},
        "physics_verifier": {
            "md_duration_ns": 10,
            "md_rmsd_max_angstrom": 5.0,
            "md_rmsd_drift_max_angstrom": 3.0,
            "md_rmsf_core_max_angstrom": 2.0,
        },
        "cavity": {
            "fpocket_total_volume_max_cubic_angstrom": 200,
            "fpocket_druggability_min": 0.0,
        },
        "surface": {
            "sasa_polar_ratio_min": 0.20,
            "sasa_polar_ratio_max": 0.65,
        },
        "hbond": {"persistence_min_pct": 60},
        "secondary_structure": {"preservation_min_pct": 70},
        "risk_weights": {
            "plddt": 0.12,
            "md_rmsd": 0.25,
            "cavity": 0.12,
            "hbond_persistence": 0.24,
            "ss_preservation": 0.18,
            "sasa_ratio": 0.05,
        },
        "verdicts": {"pass_threshold": 0.35, "warn_threshold": 0.55},
    }


# ---------------------------------------------------------------------------
# Pipeline with skip_md (static analysis only)
# ---------------------------------------------------------------------------


class TestPipelineSkipMD:
    def test_returns_pipeline_result(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        assert "design_name" in result
        assert "verdict" in result
        assert "tool_results" in result
        assert "metrics" in result

    def test_design_name_from_filename(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        assert result["design_name"] == "colabfold_sample"

    def test_verdict_present(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        assert result["verdict"]["verdict"] in ("PASS", "WARNING", "FAIL")
        assert 0.0 <= result["verdict"]["risk_score"] <= 1.0

    def test_tool_results_list(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        # At minimum: structure_scorer, fpocket, freesasa
        assert len(result["tool_results"]) >= 3
        for tr in result["tool_results"]:
            assert "tool_name" in tr
            assert "success" in tr

    def test_plddt_metrics_present(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        assert "plddt_mean" in result["metrics"]

    def test_skip_md_no_trajectory_metrics(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        # MD metrics should not be present
        assert "rmsd_max_A" not in result["metrics"]
        assert "hbond_persistence_pct" not in result["metrics"]
        assert "ss_preservation_pct" not in result["metrics"]


# ---------------------------------------------------------------------------
# Report generation (always None without Ollama)
# ---------------------------------------------------------------------------


class TestReportGeneration:
    def test_no_report_by_default(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(pdb, config=pipeline_config, skip_md=True)
        assert result["report"] is None

    def test_report_graceful_without_ollama(
        self, pipeline_config: dict, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = run_pipeline(
            pdb, config=pipeline_config, skip_md=True, generate_report=True
        )
        # Should not crash, just return None
        assert result["report"] is None or isinstance(result["report"], str)
