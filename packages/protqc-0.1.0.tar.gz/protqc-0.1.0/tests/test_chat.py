"""Tests for protqc.chat — AI chat assistant module."""

from __future__ import annotations

import json
from pathlib import Path
from unittest import mock

import pytest
import yaml

from protqc.chat import (
    FUNCTION_DISPATCH,
    METRIC_EXPLANATIONS,
    PROVIDERS,
    SYSTEM_PROMPT,
    TOOL_SCHEMAS,
    _MD_DURATION_MAX,
    _MD_DURATION_MIN,
    _build_model_string,
    _display_tool_fallback,
    _sanitize_md_duration,
    _serialize_assistant_msg,
    _verify_verdict,
    load_ai_config,
    save_ai_config,
)


# ---------------------------------------------------------------------------
# AI Config
# ---------------------------------------------------------------------------


class TestAIConfig:
    def test_load_missing_returns_none(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setattr("protqc.chat.AI_CONFIG_PATH", tmp_path / "nonexistent.yaml")
        assert load_ai_config() is None

    def test_save_and_load_roundtrip(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        config_path = tmp_path / ".protqc" / "ai_config.yaml"
        monkeypatch.setattr("protqc.chat.AI_CONFIG_PATH", config_path)

        config = {"provider": "openai", "model": "gpt-4o", "api_key": "sk-test123"}
        save_ai_config(config)

        assert config_path.is_file()
        # Check permissions (owner read/write only)
        assert oct(config_path.stat().st_mode)[-3:] == "600"

        loaded = load_ai_config()
        assert loaded == config

    def test_save_creates_parent_dirs(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        config_path = tmp_path / "deep" / "nested" / "config.yaml"
        monkeypatch.setattr("protqc.chat.AI_CONFIG_PATH", config_path)
        save_ai_config({"provider": "ollama", "model": "llama3"})
        assert config_path.is_file()


# ---------------------------------------------------------------------------
# Function Schemas
# ---------------------------------------------------------------------------


class TestFunctionSchemas:
    def test_schema_count(self):
        assert len(TOOL_SCHEMAS) == 4

    def test_all_schemas_have_required_keys(self):
        for schema in TOOL_SCHEMAS:
            assert schema["type"] == "function"
            fn = schema["function"]
            assert "name" in fn
            assert "description" in fn
            assert "parameters" in fn
            assert fn["parameters"]["type"] == "object"

    def test_schema_names(self):
        names = {s["function"]["name"] for s in TOOL_SCHEMAS}
        assert names == {"analyze", "explain_metric", "show_config", "fetch_pdb"}

    def test_analyze_required_params(self):
        analyze = next(s for s in TOOL_SCHEMAS if s["function"]["name"] == "analyze")
        assert "pdb_path" in analyze["function"]["parameters"]["required"]

    def test_explain_metric_enum(self):
        explain = next(
            s for s in TOOL_SCHEMAS if s["function"]["name"] == "explain_metric"
        )
        enum = explain["function"]["parameters"]["properties"]["metric_name"]["enum"]
        assert len(enum) == 6
        assert "plddt" in enum
        assert "md_rmsd" in enum


# ---------------------------------------------------------------------------
# Function Handlers
# ---------------------------------------------------------------------------


class TestFunctionHandlers:
    def test_dispatch_has_all_tools(self):
        assert set(FUNCTION_DISPATCH.keys()) == {
            "analyze",
            "explain_metric",
            "show_config",
            "fetch_pdb",
        }

    def test_explain_metric_known(self):
        from protqc.chat import _handle_explain_metric

        result = _handle_explain_metric({"metric_name": "plddt"})
        assert "pLDDT" in result
        assert "confidence" in result.lower()

    def test_explain_metric_unknown(self):
        from protqc.chat import _handle_explain_metric

        result = _handle_explain_metric({"metric_name": "nonexistent"})
        assert "Unknown metric" in result

    def test_show_config(self):
        from protqc.chat import _handle_show_config

        config = {
            "structure_scorer": {"plddt_min": 70},
            "physics_verifier": {"md_rmsd_max_angstrom": 3.0},
            "cavity": {},
            "surface": {},
            "hbond": {},
            "secondary_structure": {},
            "risk_weights": {"plddt": 0.12, "md_rmsd": 0.29},
            "verdicts": {"pass_threshold": 0.30, "warn_threshold": 0.50},
        }
        result = _handle_show_config({}, config)
        assert "plddt_min: 70" in result
        assert "PASS < 0.3" in result

    @mock.patch("webbrowser.open")
    @mock.patch("protqc.report.generate_html_report")
    @mock.patch("protqc.pipeline.run_pipeline")
    @mock.patch("protqc.cli._resolve_pdb_input")
    def test_handle_analyze(self, mock_resolve, mock_pipeline, mock_html, mock_browser):
        from protqc.chat import _handle_analyze

        mock_resolve.return_value = (Path("/tmp/test.pdb"), False)
        mock_pipeline.return_value = {
            "design_name": "test",
            "pdb_path": "/tmp/test.pdb",
            "sequence_length": 76,
            "metrics": {"plddt_mean": 85.0},
            "verdict": {
                "verdict": "PASS",
                "risk_score": 0.1,
                "breakdown": {"plddt": 0.05},
                "explanation": "Risk Score: 0.1 -> PASS",
                "weights": {"plddt": 1.0},
            },
            "tool_results": [
                {"tool_name": "structure_scorer", "success": True, "error": None}
            ],
        }
        mock_html.return_value = Path("/tmp/protqc_test_report.html")

        result = _handle_analyze({"pdb_path": "test.pdb", "skip_md": True}, {})
        parsed = json.loads(result)
        assert parsed["verdict"]["verdict"] == "PASS"
        assert parsed["design_name"] == "test"
        assert parsed["html_report"] == "/tmp/protqc_test_report.html"
        mock_html.assert_called_once()
        mock_browser.assert_called_once()

    @mock.patch("protqc.cli._fetch_rcsb_pdb")
    def test_handle_fetch_pdb(self, mock_fetch):
        from protqc.chat import _handle_fetch_pdb

        mock_fetch.return_value = Path("/tmp/1UBQ.pdb")
        result = _handle_fetch_pdb({"pdb_id": "1UBQ"})
        assert "1UBQ" in result
        assert "/tmp/1UBQ.pdb" in result


# ---------------------------------------------------------------------------
# Verdict Verification
# ---------------------------------------------------------------------------


class TestVerdictVerification:
    def test_matching_verdict_returns_none(self):
        assert _verify_verdict("The result is PASS with low risk.", "PASS") is None

    def test_contradiction_detected(self):
        result = _verify_verdict("This protein gets a PASS verdict.", "FAIL")
        assert result is not None
        assert "FAIL" in result
        assert "Correction" in result

    def test_no_verdict_mentioned_returns_none(self):
        assert _verify_verdict("The metrics look interesting.", "PASS") is None

    def test_multiple_verdicts_with_actual_returns_none(self):
        # Mentioning actual + others for comparison is OK
        result = _verify_verdict(
            "This is a WARNING, not a PASS or FAIL.", "WARNING"
        )
        assert result is None

    def test_wrong_verdict_in_context(self):
        result = _verify_verdict(
            "Based on the analysis, the protein receives a WARNING.", "PASS"
        )
        assert result is not None
        assert "PASS" in result  # actual verdict in correction


# ---------------------------------------------------------------------------
# Model String Building
# ---------------------------------------------------------------------------


class TestModelString:
    def test_bare_model_name(self):
        config = {"provider": "anthropic", "model": "claude-sonnet-4-6"}
        assert _build_model_string(config) == "anthropic/claude-sonnet-4-6"

    def test_already_prefixed(self):
        config = {"provider": "openai", "model": "openai/gpt-4o"}
        assert _build_model_string(config) == "openai/gpt-4o"

    def test_openrouter_nested_prefix(self):
        config = {"provider": "openrouter", "model": "openrouter/deepseek/deepseek-chat"}
        assert _build_model_string(config) == "openrouter/deepseek/deepseek-chat"

    def test_deepseek(self):
        config = {"provider": "deepseek", "model": "deepseek/deepseek-chat"}
        assert _build_model_string(config) == "deepseek/deepseek-chat"


# ---------------------------------------------------------------------------
# Providers Config
# ---------------------------------------------------------------------------


class TestProviders:
    def test_all_providers_have_required_keys(self):
        for name, info in PROVIDERS.items():
            assert "default_model" in info
            assert "env_var" in info

    def test_default_models_include_prefix(self):
        for name, info in PROVIDERS.items():
            assert "/" in info["default_model"], f"{name} default_model missing prefix"

    def test_openai_config(self):
        assert PROVIDERS["openai"]["env_var"] == "OPENAI_API_KEY"
        assert PROVIDERS["openai"]["default_model"] == "openai/gpt-4o"

    def test_deepseek_config(self):
        assert PROVIDERS["deepseek"]["env_var"] == "DEEPSEEK_API_KEY"
        assert PROVIDERS["deepseek"]["default_model"] == "deepseek/deepseek-chat"


# ---------------------------------------------------------------------------
# System Prompt
# ---------------------------------------------------------------------------


class TestSystemPrompt:
    def test_contains_critical_rules(self):
        assert "NEVER" in SYSTEM_PROMPT
        assert "ONLY report" in SYSTEM_PROMPT

    def test_mentions_available_tools(self):
        assert "analyze" in SYSTEM_PROMPT
        assert "explain_metric" in SYSTEM_PROMPT
        assert "show_config" in SYSTEM_PROMPT
        assert "fetch_pdb" in SYSTEM_PROMPT


# ---------------------------------------------------------------------------
# Metric Explanations
# ---------------------------------------------------------------------------


class TestMetricExplanations:
    def test_all_metrics_covered(self):
        expected = {"plddt", "md_rmsd", "cavity", "hbond_persistence", "ss_preservation", "sasa_ratio"}
        assert set(METRIC_EXPLANATIONS.keys()) == expected

    def test_explanations_have_content(self):
        for name, text in METRIC_EXPLANATIONS.items():
            assert len(text) > 50, f"Explanation for {name} is too short"
            assert "Reference" in text or "threshold" in text.lower()


# ---------------------------------------------------------------------------
# Chat Loop (integration-style with mocked LLM)
# ---------------------------------------------------------------------------


class TestChatLoop:
    def _make_mock_litellm(self):
        """Create a mock litellm module."""
        return mock.MagicMock()

    @mock.patch("protqc.chat.load_ai_config")
    @mock.patch("protqc.chat.Prompt")
    def test_simple_conversation(self, mock_prompt, mock_load_config):
        """Test basic chat loop with a non-tool response."""
        mock_load_config.return_value = {
            "provider": "ollama",
            "model": "llama3",
        }

        mock_prompt.ask = mock.Mock(side_effect=["hello", "/quit"])

        mock_msg = mock.Mock()
        mock_msg.tool_calls = None
        mock_msg.content = "Hello! I'm ProtQC Assistant."
        mock_choice = mock.Mock()
        mock_choice.message = mock_msg
        mock_response = mock.Mock()
        mock_response.choices = [mock_choice]

        mock_litellm = self._make_mock_litellm()
        mock_litellm.completion.return_value = mock_response

        with mock.patch.dict("sys.modules", {"litellm": mock_litellm}):
            from protqc.chat import run_chat

            run_chat({"risk_weights": {}, "verdicts": {}})

        mock_litellm.completion.assert_called_once()
        # Verify max_tokens is set to prevent infinite generation
        call_kwargs = mock_litellm.completion.call_args
        assert call_kwargs.kwargs.get("max_tokens") == 1024

    @mock.patch("protqc.chat.load_ai_config")
    @mock.patch("protqc.chat.Prompt")
    def test_tool_call_flow(self, mock_prompt, mock_load_config):
        """Test that tool calls are dispatched and followed up."""
        mock_load_config.return_value = {
            "provider": "ollama",
            "model": "llama3",
        }

        mock_prompt.ask = mock.Mock(side_effect=["explain plddt", "/quit"])

        # First response: tool call
        mock_tool_call = mock.Mock()
        mock_tool_call.id = "call_123"
        mock_tool_call.function.name = "explain_metric"
        mock_tool_call.function.arguments = '{"metric_name": "plddt"}'

        mock_msg1 = mock.Mock()
        mock_msg1.tool_calls = [mock_tool_call]
        mock_msg1.content = None
        mock_msg1.model_dump.return_value = {
            "role": "assistant",
            "content": None,
            "tool_calls": [{
                "id": "call_123",
                "type": "function",
                "function": {"name": "explain_metric", "arguments": '{"metric_name": "plddt"}'},
            }],
        }

        # Second response: interpretation
        mock_msg2 = mock.Mock()
        mock_msg2.tool_calls = None
        mock_msg2.content = "pLDDT measures prediction confidence."

        mock_choice1 = mock.Mock()
        mock_choice1.message = mock_msg1
        mock_choice2 = mock.Mock()
        mock_choice2.message = mock_msg2

        mock_litellm = self._make_mock_litellm()
        mock_litellm.completion.side_effect = [
            mock.Mock(choices=[mock_choice1]),
            mock.Mock(choices=[mock_choice2]),
        ]

        with mock.patch.dict("sys.modules", {"litellm": mock_litellm}):
            from protqc.chat import run_chat

            run_chat({"risk_weights": {}, "verdicts": {}})

        assert mock_litellm.completion.call_count == 2

    @mock.patch("protqc.chat.load_ai_config")
    @mock.patch("protqc.chat.Prompt")
    def test_fallback_on_null_content(self, mock_prompt, mock_load_config):
        """When LLM returns content=None after tool call, show raw result."""
        mock_load_config.return_value = {
            "provider": "ollama",
            "model": "llama3",
        }

        mock_prompt.ask = mock.Mock(side_effect=["explain plddt", "/quit"])

        # First response: tool call
        mock_tool_call = mock.Mock()
        mock_tool_call.id = "call_456"
        mock_tool_call.function.name = "explain_metric"
        mock_tool_call.function.arguments = '{"metric_name": "plddt"}'

        mock_msg1 = mock.Mock()
        mock_msg1.tool_calls = [mock_tool_call]
        mock_msg1.content = None

        # Second response: content=None (the bug scenario)
        mock_msg2 = mock.Mock()
        mock_msg2.tool_calls = None
        mock_msg2.content = None

        mock_litellm = self._make_mock_litellm()
        mock_litellm.completion.side_effect = [
            mock.Mock(choices=[mock.Mock(message=mock_msg1)]),
            mock.Mock(choices=[mock.Mock(message=mock_msg2)]),
        ]

        with mock.patch.dict("sys.modules", {"litellm": mock_litellm}):
            from protqc.chat import run_chat

            # Should not raise — should display fallback
            run_chat({"risk_weights": {}, "verdicts": {}})

        assert mock_litellm.completion.call_count == 2

    @mock.patch("protqc.chat.load_ai_config")
    @mock.patch("protqc.chat.Prompt")
    def test_fallback_on_followup_error(self, mock_prompt, mock_load_config):
        """When second LLM call fails, show raw tool result."""
        mock_load_config.return_value = {
            "provider": "ollama",
            "model": "llama3",
        }

        mock_prompt.ask = mock.Mock(side_effect=["explain plddt", "/quit"])

        mock_tool_call = mock.Mock()
        mock_tool_call.id = "call_789"
        mock_tool_call.function.name = "explain_metric"
        mock_tool_call.function.arguments = '{"metric_name": "plddt"}'

        mock_msg1 = mock.Mock()
        mock_msg1.tool_calls = [mock_tool_call]
        mock_msg1.content = None

        mock_litellm = self._make_mock_litellm()
        mock_litellm.completion.side_effect = [
            mock.Mock(choices=[mock.Mock(message=mock_msg1)]),
            Exception("Connection refused"),
        ]

        with mock.patch.dict("sys.modules", {"litellm": mock_litellm}):
            from protqc.chat import run_chat

            # Should not raise — should show error + fallback
            run_chat({"risk_weights": {}, "verdicts": {}})

        assert mock_litellm.completion.call_count == 2


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


class TestSerializeAssistantMsg:
    def test_clean_serialization(self):
        msg = mock.Mock()
        msg.content = "hello"
        msg.tool_calls = None
        result = _serialize_assistant_msg(msg)
        assert result == {"role": "assistant", "content": "hello"}
        assert "refusal" not in result
        assert "function_call" not in result

    def test_with_tool_calls(self):
        tc = mock.Mock()
        tc.id = "call_1"
        tc.function.name = "analyze"
        tc.function.arguments = '{"pdb_path": "test.pdb"}'

        msg = mock.Mock()
        msg.content = None
        msg.tool_calls = [tc]

        result = _serialize_assistant_msg(msg)
        assert result["content"] == ""
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["id"] == "call_1"
        assert result["tool_calls"][0]["type"] == "function"
        assert result["tool_calls"][0]["function"]["name"] == "analyze"

    def test_null_content_becomes_empty_string(self):
        msg = mock.Mock()
        msg.content = None
        msg.tool_calls = None
        result = _serialize_assistant_msg(msg)
        assert result["content"] == ""


# ---------------------------------------------------------------------------
# Tool fallback display
# ---------------------------------------------------------------------------


class TestToolFallback:
    def test_analyze_result_shows_verdict_and_metrics(self):
        """Analyze results render verdict, metrics, and breakdown."""
        result = json.dumps({
            "design_name": "ubiquitin",
            "pdb_path": "/tmp/ubiquitin.pdb",
            "sequence_length": 76,
            "metrics": {"plddt_mean": 85.2, "polar_ratio": 0.72},
            "verdict": {
                "verdict": "PASS",
                "risk_score": 0.1,
                "breakdown": {"plddt": 0.05, "sasa_ratio": 0.0},
                "explanation": "Risk Score: 0.1 -> PASS",
            },
            "tool_results": [
                {"tool_name": "structure_scorer", "success": True, "error": None},
            ],
        })
        # Should not raise
        _display_tool_fallback(result, ["analyze"])

    def test_json_without_metrics_shows_raw(self):
        """JSON with verdict but no metrics key falls through to raw display."""
        result = json.dumps({"some_key": "some_value"})
        _display_tool_fallback(result, ["some_tool"])

    def test_plain_text_result(self):
        """Non-JSON results are displayed as-is."""
        _display_tool_fallback("Downloaded 1UBQ to /tmp/1UBQ.pdb", ["fetch_pdb"])

    def test_integer_breakdown_values(self):
        """Breakdown values that are ints (from JSON) don't crash formatting."""
        result = json.dumps({
            "design_name": "test",
            "metrics": {"plddt_mean": 90},
            "verdict": {
                "verdict": "PASS",
                "risk_score": 0,
                "breakdown": {"plddt": 0, "cavity": 0},
            },
            "tool_results": [],
        })
        _display_tool_fallback(result, ["analyze"])


# ---------------------------------------------------------------------------
# MD Duration Sanitization
# ---------------------------------------------------------------------------


class TestSanitizeMdDuration:
    def test_none_returns_none(self):
        assert _sanitize_md_duration(None) is None

    def test_normal_value_passes_through(self):
        assert _sanitize_md_duration(5.0) == 5.0

    def test_absurdly_large_clamped(self):
        result = _sanitize_md_duration(10_000_000_000_000_000_000)
        assert result == _MD_DURATION_MAX

    def test_negative_clamped_to_min(self):
        result = _sanitize_md_duration(-5.0)
        assert result == _MD_DURATION_MIN

    def test_zero_clamped_to_min(self):
        result = _sanitize_md_duration(0.0)
        assert result == _MD_DURATION_MIN

    def test_string_number(self):
        assert _sanitize_md_duration("5") == 5.0

    def test_garbage_string_returns_default(self):
        result = _sanitize_md_duration("not_a_number")
        assert result == 10.0

    def test_nan_returns_default(self):
        result = _sanitize_md_duration(float("nan"))
        assert result == 10.0

    def test_boundary_min(self):
        assert _sanitize_md_duration(0.1) == _MD_DURATION_MIN

    def test_boundary_max(self):
        assert _sanitize_md_duration(1000.0) == _MD_DURATION_MAX

    def test_just_above_min(self):
        assert _sanitize_md_duration(0.5) == 0.5

    def test_bool_true_becomes_one(self):
        # bool is a subclass of int in Python; True=1.0 is within range
        result = _sanitize_md_duration(True)
        assert result == 1.0
