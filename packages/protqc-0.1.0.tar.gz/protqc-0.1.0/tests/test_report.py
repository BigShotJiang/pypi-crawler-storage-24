"""Tests for protqc.report — HTML report generation."""

import tempfile
from pathlib import Path

import pytest

from protqc.report import generate_html_report, _build_context, _plot_plddt, _plot_rmsd


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def sample_config():
    """Minimal config dict for testing."""
    return {
        "structure_scorer": {"plddt_min": 70},
        "physics_verifier": {
            "md_rmsd_max_angstrom": 3.0,
            "md_rmsd_drift_max_angstrom": 2.0,
            "md_duration_ns": 10,
        },
        "cavity": {
            "fpocket_total_volume_max_cubic_angstrom": 1500,
            "fpocket_volume_per_residue_max": 5.0,
        },
        "surface": {
            "sasa_polar_ratio_min": 0.55,
            "sasa_polar_ratio_max": 0.85,
        },
        "hbond": {"persistence_min_pct": 70},
        "secondary_structure": {"preservation_min_pct": 75},
        "risk_weights": {
            "plddt": 0.12,
            "md_rmsd": 0.29,
            "cavity": 0.12,
            "hbond_persistence": 0.24,
            "ss_preservation": 0.18,
            "sasa_ratio": 0.05,
        },
        "verdicts": {"pass_threshold": 0.30, "warn_threshold": 0.50},
    }


@pytest.fixture()
def sample_result():
    """Minimal PipelineResult for testing."""
    return {
        "design_name": "test_protein",
        "sequence": None,
        "sequence_length": 76,
        "pdb_path": "/tmp/test_protein.pdb",
        "input_mode": "pdb",
        "metrics": {
            "plddt_mean": 85.3,
            "plddt_median": 88.0,
            "plddt_min": 42.1,
            "plddt_per_residue": [85.0 + i * 0.2 for i in range(76)],
            "plddt_detected": True,
            "sequence_length": 76,
            "total_volume_A3": 120.5,
            "polar_ratio": 0.72,
        },
        "verdict": {
            "risk_score": 0.215,
            "verdict": "PASS",
            "breakdown": {
                "plddt": 0.15,
                "cavity": 0.05,
                "sasa_ratio": 0.0,
            },
            "weights": {
                "plddt": 0.40,
                "cavity": 0.40,
                "sasa_ratio": 0.20,
            },
            "explanation": "Risk Score: 0.215 -> PASS (all metrics normal)",
        },
        "tool_results": [
            {"tool_name": "structure_scorer", "success": True, "metrics": {}, "error": None},
            {"tool_name": "fpocket", "success": True, "metrics": {}, "error": None},
            {"tool_name": "freesasa", "success": True, "metrics": {}, "error": None},
            {"tool_name": "openmm", "success": False, "metrics": {}, "error": "skipped"},
        ],
        "report": None,
    }


# ---------------------------------------------------------------------------
# HTML report generation
# ---------------------------------------------------------------------------

class TestGenerateHtmlReport:
    def test_creates_file(self, sample_result, sample_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            result_path = generate_html_report(sample_result, sample_config, out)
            assert result_path.is_file()
            assert result_path == out

    def test_html_structure(self, sample_result, sample_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "<!DOCTYPE html>" in html
            assert "test_protein" in html
            assert "PASS" in html

    def test_self_contained(self, sample_result, sample_config):
        """Report should not reference external URLs (except citation link)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            # No external CSS/JS references
            assert "<link rel=" not in html
            assert "<script src=" not in html

    def test_embeds_plddt_plot(self, sample_result, sample_config):
        pytest.importorskip("matplotlib")
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "data:image/png;base64," in html

    def test_verdict_colors(self, sample_result, sample_config):
        """Each verdict type should get its own CSS class."""
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "verdict-PASS" in html

    def test_creates_parent_dirs(self, sample_result, sample_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "sub" / "dir" / "report.html"
            generate_html_report(sample_result, sample_config, out)
            assert out.is_file()

    def test_tool_status_table(self, sample_result, sample_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "structure_scorer" in html
            assert "openmm" in html

    def test_threshold_config_shown(self, sample_result, sample_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "pLDDT minimum" in html
            assert "70" in html

    def test_footer_with_version(self, sample_result, sample_config):
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "ProtQC v" in html


# ---------------------------------------------------------------------------
# B-factor warning detection
# ---------------------------------------------------------------------------

class TestBfactorWarning:
    def test_no_warning_for_plddt(self, sample_result, sample_config):
        ctx = _build_context(sample_result, sample_config)
        assert ctx["bfactor_warning"] is False

    def test_warning_for_experimental(self, sample_result, sample_config):
        sample_result["metrics"]["plddt_detected"] = False
        ctx = _build_context(sample_result, sample_config)
        assert ctx["bfactor_warning"] is True

    def test_warning_text_in_html(self, sample_result, sample_config):
        sample_result["metrics"]["plddt_detected"] = False
        with tempfile.TemporaryDirectory() as tmpdir:
            out = Path(tmpdir) / "report.html"
            generate_html_report(sample_result, sample_config, out)
            html = out.read_text()
            assert "Experimental PDB detected" in html


# ---------------------------------------------------------------------------
# Plot generation
# ---------------------------------------------------------------------------

class TestPlots:
    def test_plddt_plot_returns_base64(self):
        pytest.importorskip("matplotlib")
        data = [85.0 + i * 0.1 for i in range(50)]
        result = _plot_plddt(data, plddt_detected=True)
        assert result is not None
        assert len(result) > 100  # Non-trivial base64 string

    def test_plddt_plot_empty_data(self):
        assert _plot_plddt([], plddt_detected=True) is None

    def test_rmsd_plot_returns_base64(self):
        pytest.importorskip("matplotlib")
        data = [0.5 + i * 0.01 for i in range(100)]
        result = _plot_rmsd(data, threshold=3.0)
        assert result is not None
        assert len(result) > 100

    def test_rmsd_plot_empty_data(self):
        assert _plot_rmsd([], threshold=3.0) is None

    def test_bfactor_label_when_not_plddt(self):
        """Plot title should say B-factor, not pLDDT, for experimental PDBs."""
        pytest.importorskip("matplotlib")
        # We can't easily check the plot title from base64, but we verify
        # the function runs without error for both modes
        data = [25.0 + i * 0.5 for i in range(100)]
        result = _plot_plddt(data, plddt_detected=False)
        assert result is not None


# ---------------------------------------------------------------------------
# Context builder
# ---------------------------------------------------------------------------

class TestBuildContext:
    def test_required_keys(self, sample_result, sample_config):
        ctx = _build_context(sample_result, sample_config)
        required = [
            "design_name", "date", "timestamp", "version", "verdict",
            "verdict_color", "risk_score", "breakdown", "tools",
            "thresholds", "plddt_plot",
        ]
        for key in required:
            assert key in ctx, f"Missing key: {key}"

    def test_breakdown_structure(self, sample_result, sample_config):
        ctx = _build_context(sample_result, sample_config)
        for item in ctx["breakdown"]:
            assert "name" in item
            assert "score" in item
            assert "bar_class" in item
            assert "bar_pct" in item

    def test_risk_bar_classes(self, sample_result, sample_config):
        """Bar classes should reflect risk levels."""
        ctx = _build_context(sample_result, sample_config)
        classes = {item["bar_class"] for item in ctx["breakdown"]}
        # Our sample has low scores (0.15, 0.05, 0.0)
        assert "risk-low" in classes

    def test_no_rmsd_plot_without_md(self, sample_result, sample_config):
        ctx = _build_context(sample_result, sample_config)
        assert ctx["rmsd_plot"] is None

    def test_rmsd_plot_with_md_data(self, sample_result, sample_config):
        pytest.importorskip("matplotlib")
        sample_result["metrics"]["rmsd_per_frame_A"] = [
            0.5 + i * 0.02 for i in range(50)
        ]
        ctx = _build_context(sample_result, sample_config)
        assert ctx["rmsd_plot"] is not None


# ---------------------------------------------------------------------------
# CLI --html flag
# ---------------------------------------------------------------------------

class TestCliHtmlFlag:
    def test_html_flag_in_parser(self):
        from protqc.cli import build_parser
        parser = build_parser()
        # Parsing should accept --html
        args = parser.parse_args(["analyze", "--skip-md", "--html", "out.html", "test.pdb"])
        assert args.html == "out.html"

    def test_html_flag_default_none(self):
        from protqc.cli import build_parser
        parser = build_parser()
        args = parser.parse_args(["analyze", "--skip-md", "test.pdb"])
        assert args.html is None
