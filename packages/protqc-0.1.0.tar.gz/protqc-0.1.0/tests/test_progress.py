"""Tests for protqc.progress — pipeline stage progress display."""

import time
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest
from rich.console import Console

from protqc.progress import (
    STAGE_LABELS,
    STAGE_MESSAGES,
    _MD_ROTATE_INTERVAL,
    _format_elapsed,
    create_stage_display,
)


# ---------------------------------------------------------------------------
# _format_elapsed
# ---------------------------------------------------------------------------


class TestFormatElapsed:
    def test_seconds(self):
        assert _format_elapsed(3.14) == "3.1s"

    def test_zero(self):
        assert _format_elapsed(0.0) == "0.0s"

    def test_one_minute(self):
        assert _format_elapsed(60.0) == "1m 0s"

    def test_minutes_and_seconds(self):
        assert _format_elapsed(125.7) == "2m 6s"

    def test_just_under_one_minute(self):
        assert _format_elapsed(59.9) == "59.9s"


# ---------------------------------------------------------------------------
# STAGE_MESSAGES / STAGE_LABELS coverage
# ---------------------------------------------------------------------------


class TestStageConfig:
    def test_all_stages_have_labels(self):
        for stage in STAGE_MESSAGES:
            assert stage in STAGE_LABELS, f"{stage} missing from STAGE_LABELS"

    def test_all_labels_have_messages(self):
        for stage in STAGE_LABELS:
            assert stage in STAGE_MESSAGES, f"{stage} missing from STAGE_MESSAGES"

    def test_openmm_has_rotating_messages(self):
        assert isinstance(STAGE_MESSAGES["openmm"], list)
        assert len(STAGE_MESSAGES["openmm"]) >= 3

    def test_non_md_stages_have_string_messages(self):
        for stage, msg in STAGE_MESSAGES.items():
            if stage != "openmm":
                assert isinstance(msg, str), f"{stage} should have a string message"

    def test_rotate_interval_is_positive(self):
        assert _MD_ROTATE_INTERVAL > 0


# ---------------------------------------------------------------------------
# create_stage_display — single-message stages
# ---------------------------------------------------------------------------


class TestSingleMessageStage:
    def test_context_manager_completes(self):
        console = Console(file=StringIO(), stderr=False)
        show = create_stage_display(console)
        with show("structure_scorer"):
            pass  # stage runs instantly

    def test_prints_checkmark_on_completion(self):
        buf = StringIO()
        console = Console(file=buf, stderr=False, force_terminal=True)
        show = create_stage_display(console)
        with show("fpocket"):
            pass
        output = buf.getvalue()
        assert "✓" in output
        assert "Cavity detection" in output

    def test_shows_elapsed_time(self):
        buf = StringIO()
        console = Console(file=buf, stderr=False, force_terminal=True)
        show = create_stage_display(console)
        with show("scoring"):
            time.sleep(0.05)
        output = buf.getvalue()
        assert "s" in output  # elapsed time ends with 's'

    def test_unknown_stage_uses_fallback(self):
        buf = StringIO()
        console = Console(file=buf, stderr=False, force_terminal=True)
        show = create_stage_display(console)
        with show("unknown_tool"):
            pass
        output = buf.getvalue()
        assert "✓" in output
        assert "unknown_tool" in output


# ---------------------------------------------------------------------------
# create_stage_display — rotating messages (MD stage)
# ---------------------------------------------------------------------------


class TestRotatingMessageStage:
    def test_md_stage_completes(self):
        console = Console(file=StringIO(), stderr=False)
        show = create_stage_display(console)
        with show("openmm"):
            time.sleep(0.05)

    def test_md_stage_prints_checkmark(self):
        buf = StringIO()
        console = Console(file=buf, stderr=False, force_terminal=True)
        show = create_stage_display(console)
        with show("openmm"):
            time.sleep(0.05)
        output = buf.getvalue()
        assert "✓" in output
        assert "MD simulation" in output

    def test_md_stage_shows_elapsed(self):
        buf = StringIO()
        console = Console(file=buf, stderr=False, force_terminal=True)
        show = create_stage_display(console)
        with show("openmm"):
            time.sleep(0.05)
        output = buf.getvalue()
        assert "s" in output


# ---------------------------------------------------------------------------
# Integration with pipeline on_stage parameter
# ---------------------------------------------------------------------------


class TestPipelineIntegration:
    def test_pipeline_accepts_on_stage(self, fixtures_dir):
        """Pipeline runs with on_stage callback without errors."""
        from protqc.pipeline import run_pipeline

        stages_seen: list[str] = []

        from contextlib import contextmanager

        @contextmanager
        def track_stage(name):
            stages_seen.append(name)
            yield

        pdb = fixtures_dir / "colabfold_sample.pdb"
        config = {
            "structure_scorer": {"plddt_min": 0.70},
            "cavity": {
                "fpocket_total_volume_max_cubic_angstrom": 200,
                "fpocket_druggability_min": 0.0,
            },
            "surface": {
                "sasa_polar_ratio_min": 0.20,
                "sasa_polar_ratio_max": 0.65,
            },
            "risk_weights": {"plddt": 0.12, "cavity": 0.13, "sasa_ratio": 0.05},
            "verdicts": {"pass_threshold": 0.35, "warn_threshold": 0.55},
        }
        result = run_pipeline(pdb, config=config, skip_md=True, on_stage=track_stage)

        assert "structure_scorer" in stages_seen
        assert "fpocket" in stages_seen
        assert "freesasa" in stages_seen
        assert "scoring" in stages_seen
        # MD stages should NOT appear when skip_md=True
        assert "openmm" not in stages_seen
        assert "hbond" not in stages_seen
        assert "ss_stability" not in stages_seen

    def test_pipeline_works_without_on_stage(self, fixtures_dir):
        """Pipeline still works when on_stage is None (default)."""
        from protqc.pipeline import run_pipeline

        pdb = fixtures_dir / "colabfold_sample.pdb"
        config = {
            "structure_scorer": {"plddt_min": 0.70},
            "cavity": {
                "fpocket_total_volume_max_cubic_angstrom": 200,
                "fpocket_druggability_min": 0.0,
            },
            "surface": {
                "sasa_polar_ratio_min": 0.20,
                "sasa_polar_ratio_max": 0.65,
            },
            "risk_weights": {"plddt": 0.12, "cavity": 0.13, "sasa_ratio": 0.05},
            "verdicts": {"pass_threshold": 0.35, "warn_threshold": 0.55},
        }
        result = run_pipeline(pdb, config=config, skip_md=True)
        assert result["verdict"]["verdict"] in ("PASS", "WARNING", "FAIL")


# ---------------------------------------------------------------------------
# JSON mode does NOT get spinners
# ---------------------------------------------------------------------------


class TestJsonModeNoSpinners:
    def test_cmd_analyze_json_no_stage_display(self, mini_pdb):
        """In --json mode, on_stage should be None (no spinners)."""
        import subprocess
        import sys

        result = subprocess.run(
            [sys.executable, "-m", "protqc.cli",
             "analyze", "--json", "--skip-md", str(mini_pdb)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # stderr should NOT contain spinner completion markers
        assert "✓" not in result.stderr
        # stdout should be valid JSON
        import json
        data = json.loads(result.stdout)
        assert "verdict" in data
