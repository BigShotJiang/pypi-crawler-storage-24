"""Tests for protqc.tools.openmm_tool — MD simulation."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from protqc.tools.openmm_tool import (
    MDTRAJ_AVAILABLE,
    OPENMM_AVAILABLE,
    PDBFIXER_AVAILABLE,
    OpenMMSimulator,
)

SKIP_OPENMM = pytest.mark.skipif(
    not OPENMM_AVAILABLE or not MDTRAJ_AVAILABLE,
    reason="openmm/mdtraj not installed",
)


@pytest.fixture
def simulator() -> OpenMMSimulator:
    return OpenMMSimulator(config={})


# ---------------------------------------------------------------------------
# Availability guard
# ---------------------------------------------------------------------------


class TestAvailabilityGuard:
    def test_no_openmm_returns_error(self, simulator: OpenMMSimulator):
        with patch("protqc.tools.openmm_tool.OPENMM_AVAILABLE", False):
            result = simulator.simulate("any.pdb")
            assert result["success"] is False
            assert "openmm" in result["error"].lower()

    def test_no_mdtraj_returns_error(self, simulator: OpenMMSimulator):
        with patch("protqc.tools.openmm_tool.MDTRAJ_AVAILABLE", False):
            result = simulator.simulate("any.pdb")
            assert result["success"] is False

    def test_result_shape(self, simulator: OpenMMSimulator):
        with patch("protqc.tools.openmm_tool.OPENMM_AVAILABLE", False):
            result = simulator.simulate("any.pdb")
            assert result["tool_name"] == "openmm_md"
            assert "success" in result
            assert "metrics" in result
            assert "error" in result


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_file(self, simulator: OpenMMSimulator):
        result = simulator.simulate("nonexistent.pdb")
        assert result["success"] is False

    def test_directory_not_file(self, simulator: OpenMMSimulator, tmp_path: Path):
        result = simulator.simulate(tmp_path)
        assert result["success"] is False


# ---------------------------------------------------------------------------
# Structure preparation (PDBFixer integration)
# ---------------------------------------------------------------------------


class TestPrepareStructure:
    """Test _prepare_structure with and without PDBFixer."""

    def test_fallback_without_pdbfixer(self, simulator: OpenMMSimulator, tmp_path: Path):
        """When PDBFixer is unavailable, falls back to raw PDBFile loading."""
        pdb_file = tmp_path / "test.pdb"
        pdb_file.write_text("DUMMY")

        with patch("protqc.tools.openmm_tool.PDBFIXER_AVAILABLE", False), \
             patch("protqc.tools.openmm_tool.PDBFile", create=True) as mock_pdb:
            mock_pdb.return_value.topology = "topo"
            mock_pdb.return_value.positions = "pos"
            topo, pos = simulator._prepare_structure(pdb_file)
            mock_pdb.assert_called_once_with(str(pdb_file))
            assert topo == "topo"
            assert pos == "pos"

    def test_uses_pdbfixer_when_available(self, simulator: OpenMMSimulator, tmp_path: Path):
        """When PDBFixer is available, uses it to repair the structure."""
        pdb_file = tmp_path / "test.pdb"
        pdb_file.write_text("DUMMY")

        mock_fixer = MagicMock()
        mock_fixer.topology = "fixed_topo"
        mock_fixer.positions = "fixed_pos"

        with patch("protqc.tools.openmm_tool.PDBFIXER_AVAILABLE", True), \
             patch("protqc.tools.openmm_tool.PDBFixer", create=True, return_value=mock_fixer) as mock_cls:
            topo, pos = simulator._prepare_structure(pdb_file)
            mock_cls.assert_called_once_with(filename=str(pdb_file))
            mock_fixer.findMissingResidues.assert_called_once()
            mock_fixer.findMissingAtoms.assert_called_once()
            mock_fixer.addMissingAtoms.assert_called_once()
            mock_fixer.addMissingHydrogens.assert_called_once_with(7.0)
            assert topo == "fixed_topo"
            assert pos == "fixed_pos"
