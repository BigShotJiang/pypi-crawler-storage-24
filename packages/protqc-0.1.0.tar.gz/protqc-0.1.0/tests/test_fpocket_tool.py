"""Tests for protqc.tools.fpocket_tool — cavity detection."""

import shutil
from pathlib import Path
from unittest.mock import patch

import pytest

from protqc.tools.fpocket_tool import FpocketAnalyzer

SKIP_FPOCKET = pytest.mark.skipif(
    shutil.which("fpocket") is None,
    reason="fpocket binary not installed",
)


@pytest.fixture
def analyzer() -> FpocketAnalyzer:
    return FpocketAnalyzer(config={})


# ---------------------------------------------------------------------------
# Availability guard
# ---------------------------------------------------------------------------


class TestAvailabilityGuard:
    def test_unavailable_returns_error(self, analyzer: FpocketAnalyzer):
        with patch("protqc.tools.fpocket_tool.FPOCKET_AVAILABLE", False):
            result = analyzer.analyze("any.pdb")
            assert result["success"] is False
            assert "not found" in result["error"].lower()

    def test_unavailable_result_shape(self, analyzer: FpocketAnalyzer):
        with patch("protqc.tools.fpocket_tool.FPOCKET_AVAILABLE", False):
            result = analyzer.analyze("any.pdb")
            assert "tool_name" in result
            assert "success" in result
            assert "metrics" in result
            assert "error" in result


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_file(self, analyzer: FpocketAnalyzer):
        result = analyzer.analyze("nonexistent.pdb")
        # Either fpocket-not-found or file-not-found depending on availability
        assert result["success"] is False

    def test_directory_not_file(self, analyzer: FpocketAnalyzer, tmp_path: Path):
        result = analyzer.analyze(tmp_path)
        assert result["success"] is False

    def test_result_shape_on_error(self, analyzer: FpocketAnalyzer):
        result = analyzer.analyze("nonexistent.pdb")
        assert result["tool_name"] == "fpocket"
        assert result["metrics"] == {}
        assert result["error"] is not None


# ---------------------------------------------------------------------------
# Info.txt parsing
# ---------------------------------------------------------------------------


class TestInfoParsing:
    def test_parse_empty_file(self, analyzer: FpocketAnalyzer, tmp_path: Path):
        info = tmp_path / "test_info.txt"
        info.write_text("")
        pockets = analyzer._parse_info_txt(info)
        assert pockets == []

    def test_parse_nonexistent_file(self, analyzer: FpocketAnalyzer, tmp_path: Path):
        pockets = analyzer._parse_info_txt(tmp_path / "missing.txt")
        assert pockets == []

    def test_parse_single_pocket(self, analyzer: FpocketAnalyzer, tmp_path: Path):
        info = tmp_path / "test_info.txt"
        info.write_text(
            "Header info\n\n"
            "Pocket 1 :\n"
            "\tScore :                         0.1234\n"
            "\tDruggability Score :             0.567\n"
            "\tNumber of Alpha Spheres :        42\n"
            "\tTotal SASA :                     123.45\n"
            "\tVolume (Monte Carlo) :           456.78\n"
        )
        pockets = analyzer._parse_info_txt(info)
        assert len(pockets) == 1
        assert abs(pockets[0]["volume"] - 456.78) < 0.01
        assert abs(pockets[0]["score"] - 0.1234) < 0.001
        assert abs(pockets[0]["druggability"] - 0.567) < 0.001

    def test_parse_multiple_pockets(self, analyzer: FpocketAnalyzer, tmp_path: Path):
        info = tmp_path / "test_info.txt"
        info.write_text(
            "Header\n\n"
            "Pocket 1 :\n"
            "\tScore :            0.50\n"
            "\tVolume (Monte Carlo) :  100.00\n\n"
            "Pocket 2 :\n"
            "\tScore :            0.30\n"
            "\tVolume (Monte Carlo) :  200.00\n"
        )
        pockets = analyzer._parse_info_txt(info)
        assert len(pockets) == 2
        assert abs(pockets[0]["volume"] - 100.0) < 0.01
        assert abs(pockets[1]["volume"] - 200.0) < 0.01


# ---------------------------------------------------------------------------
# Pocket filtering (surface vs significant)
# ---------------------------------------------------------------------------


class TestPocketFiltering:
    """Test that shallow surface pockets are excluded from filtered metrics."""

    def _make_analyzer_and_run(self, tmp_path, pocket_text):
        """Helper: write info.txt, parse, then compute filtered metrics."""
        # We test filtering by directly calling analyze on a crafted scenario.
        # Since we can't run fpocket, we test the filtering logic via the
        # parsed pocket dicts and the metrics computation path.
        analyzer = FpocketAnalyzer(config={})
        info = tmp_path / "test_info.txt"
        info.write_text(pocket_text)
        return analyzer._parse_info_txt(info), analyzer

    def test_surface_pockets_excluded(self, tmp_path: Path):
        """Ubiquitin-like: 5 pockets, all low score + low druggability."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.05\n\tDruggability Score : 0.02\n"
            "\tVolume (Monte Carlo) : 280.00\n\n"
            "Pocket 2 :\n\tScore : 0.08\n\tDruggability Score : 0.01\n"
            "\tVolume (Monte Carlo) : 350.00\n\n"
            "Pocket 3 :\n\tScore : 0.04\n\tDruggability Score : 0.03\n"
            "\tVolume (Monte Carlo) : 310.00\n\n"
            "Pocket 4 :\n\tScore : 0.10\n\tDruggability Score : 0.05\n"
            "\tVolume (Monte Carlo) : 260.00\n\n"
            "Pocket 5 :\n\tScore : 0.06\n\tDruggability Score : 0.04\n"
            "\tVolume (Monte Carlo) : 272.00\n",
        )
        assert len(pockets) == 5
        # All below filter thresholds (score <= 0.2 AND druggability <= 0.1)
        filtered = [
            p for p in pockets
            if p.get("druggability", 0.0) > analyzer.druggability_min_filter
            or p.get("score", 0.0) > analyzer.score_min_filter
        ]
        assert len(filtered) == 0

    def test_significant_pocket_kept(self, tmp_path: Path):
        """GFP-like: one large pocket with high druggability amid surface noise."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.45\n\tDruggability Score : 0.72\n"
            "\tVolume (Monte Carlo) : 420.00\n\n"
            "Pocket 2 :\n\tScore : 0.05\n\tDruggability Score : 0.02\n"
            "\tVolume (Monte Carlo) : 150.00\n\n"
            "Pocket 3 :\n\tScore : 0.03\n\tDruggability Score : 0.01\n"
            "\tVolume (Monte Carlo) : 80.00\n",
        )
        assert len(pockets) == 3
        filtered = [
            p for p in pockets
            if p.get("druggability", 0.0) > analyzer.druggability_min_filter
            or p.get("score", 0.0) > analyzer.score_min_filter
        ]
        assert len(filtered) == 1
        assert abs(filtered[0]["volume"] - 420.0) < 0.01

    def test_score_only_passes_filter(self, tmp_path: Path):
        """Pocket with high score but no druggability still passes filter."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.35\n\tDruggability Score : 0.05\n"
            "\tVolume (Monte Carlo) : 200.00\n",
        )
        filtered = [
            p for p in pockets
            if p.get("druggability", 0.0) > analyzer.druggability_min_filter
            or p.get("score", 0.0) > analyzer.score_min_filter
        ]
        assert len(filtered) == 1


# ---------------------------------------------------------------------------
# Suspicious cavity detection (large buried voids)
# ---------------------------------------------------------------------------


class TestSuspiciousCavityDetection:
    """Test that suspicious cavities are detected based on volume + druggability."""

    def _make_analyzer_and_run(self, tmp_path, pocket_text):
        analyzer = FpocketAnalyzer(config={})
        info = tmp_path / "test_info.txt"
        info.write_text(pocket_text)
        return analyzer._parse_info_txt(info), analyzer

    def test_ubiquitin_no_suspicious_cavities(self, tmp_path: Path):
        """Ubiquitin: largest pocket 461 ų, druggability 0.001 — below 800 ų."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.05\n\tDruggability Score : 0.001\n"
            "\tVolume (Monte Carlo) : 461.00\n\n"
            "Pocket 2 :\n\tScore : 0.03\n\tDruggability Score : 0.002\n"
            "\tVolume (Monte Carlo) : 280.00\n",
        )
        suspicious = [
            p for p in pockets
            if p.get("volume", 0.0) >= analyzer.suspicious_volume_min
            and p.get("druggability", 1.0) < analyzer.suspicious_druggability_max
        ]
        assert len(suspicious) == 0

    def test_hallucination_void_flagged(self, tmp_path: Path):
        """Large buried void (900 ų, low druggability) → suspicious."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.15\n\tDruggability Score : 0.05\n"
            "\tVolume (Monte Carlo) : 900.00\n",
        )
        suspicious = [
            p for p in pockets
            if p.get("volume", 0.0) >= analyzer.suspicious_volume_min
            and p.get("druggability", 1.0) < analyzer.suspicious_druggability_max
        ]
        assert len(suspicious) == 1

    def test_functional_large_pocket_not_suspicious(self, tmp_path: Path):
        """Large pocket with high druggability (functional site) → not suspicious."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.45\n\tDruggability Score : 0.72\n"
            "\tVolume (Monte Carlo) : 850.00\n",
        )
        suspicious = [
            p for p in pockets
            if p.get("volume", 0.0) >= analyzer.suspicious_volume_min
            and p.get("druggability", 1.0) < analyzer.suspicious_druggability_max
        ]
        assert len(suspicious) == 0

    def test_borderline_druggability_not_suspicious(self, tmp_path: Path):
        """Pocket at druggability boundary (0.4) → not suspicious (>= excludes)."""
        pockets, analyzer = self._make_analyzer_and_run(
            tmp_path,
            "Header\n\n"
            "Pocket 1 :\n\tScore : 0.30\n\tDruggability Score : 0.40\n"
            "\tVolume (Monte Carlo) : 850.00\n",
        )
        suspicious = [
            p for p in pockets
            if p.get("volume", 0.0) >= analyzer.suspicious_volume_min
            and p.get("druggability", 1.0) < analyzer.suspicious_druggability_max
        ]
        assert len(suspicious) == 0


# ---------------------------------------------------------------------------
# Happy path (requires fpocket binary)
# ---------------------------------------------------------------------------


@SKIP_FPOCKET
class TestHappyPath:
    def test_analyze_mini_pdb(self, analyzer: FpocketAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(mini_pdb)
        assert result["success"] is True
        assert result["tool_name"] == "fpocket"
        assert "num_pockets" in result["metrics"]
        assert "total_volume_A3" in result["metrics"]
        assert "cavity_flag" in result["metrics"]
        assert "suspicious_cavity_flag" in result["metrics"]
        assert "suspicious_volume_A3" in result["metrics"]

    def test_analyze_colabfold_pdb(
        self, analyzer: FpocketAnalyzer, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = analyzer.analyze(pdb)
        assert result["success"] is True
        assert isinstance(result["metrics"]["num_pockets"], int)
        assert isinstance(result["metrics"]["total_volume_A3"], (int, float))

    def test_string_path(self, analyzer: FpocketAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(str(mini_pdb))
        assert result["success"] is True
