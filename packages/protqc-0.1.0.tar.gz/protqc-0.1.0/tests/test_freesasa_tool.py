"""Tests for protqc.tools.freesasa_tool — solvent accessibility."""

from pathlib import Path
from unittest.mock import patch

import pytest

from protqc.tools.freesasa_tool import FREESASA_AVAILABLE, FreeSASAAnalyzer

SKIP_FREESASA = pytest.mark.skipif(
    not FREESASA_AVAILABLE,
    reason="freesasa not installed",
)


@pytest.fixture
def analyzer() -> FreeSASAAnalyzer:
    return FreeSASAAnalyzer(config={})


# ---------------------------------------------------------------------------
# Availability guard
# ---------------------------------------------------------------------------


class TestAvailabilityGuard:
    def test_unavailable_returns_error(self, analyzer: FreeSASAAnalyzer):
        with patch("protqc.tools.freesasa_tool.FREESASA_AVAILABLE", False):
            result = analyzer.analyze("any.pdb")
            assert result["success"] is False
            assert "not installed" in result["error"].lower()

    def test_unavailable_result_shape(self, analyzer: FreeSASAAnalyzer):
        with patch("protqc.tools.freesasa_tool.FREESASA_AVAILABLE", False):
            result = analyzer.analyze("any.pdb")
            assert result["tool_name"] == "freesasa"
            assert result["metrics"] == {}


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_missing_file(self, analyzer: FreeSASAAnalyzer):
        result = analyzer.analyze("nonexistent.pdb")
        assert result["success"] is False

    def test_directory_not_file(self, analyzer: FreeSASAAnalyzer, tmp_path: Path):
        result = analyzer.analyze(tmp_path)
        assert result["success"] is False

    def test_result_shape_on_error(self, analyzer: FreeSASAAnalyzer):
        result = analyzer.analyze("nonexistent.pdb")
        assert "tool_name" in result
        assert "success" in result
        assert "metrics" in result
        assert "error" in result


# ---------------------------------------------------------------------------
# Happy path (requires freesasa)
# ---------------------------------------------------------------------------


@SKIP_FREESASA
class TestHappyPath:
    def test_analyze_mini_pdb(self, analyzer: FreeSASAAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(mini_pdb)
        assert result["success"] is True
        assert result["tool_name"] == "freesasa"
        m = result["metrics"]
        assert "total_sasa_A2" in m
        assert "polar_sasa_A2" in m
        assert "apolar_sasa_A2" in m
        assert "polar_ratio" in m
        assert "sasa_normal" in m

    def test_sasa_values_positive(self, analyzer: FreeSASAAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(mini_pdb)
        m = result["metrics"]
        assert m["total_sasa_A2"] > 0
        assert m["polar_sasa_A2"] >= 0
        assert m["apolar_sasa_A2"] >= 0

    def test_polar_ratio_in_range(self, analyzer: FreeSASAAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(mini_pdb)
        ratio = result["metrics"]["polar_ratio"]
        assert 0.0 <= ratio <= 1.0

    def test_colabfold_pdb(
        self, analyzer: FreeSASAAnalyzer, fixtures_dir: Path
    ):
        pdb = fixtures_dir / "colabfold_sample.pdb"
        result = analyzer.analyze(pdb)
        assert result["success"] is True
        assert isinstance(result["metrics"]["sasa_normal"], bool)

    def test_string_path(self, analyzer: FreeSASAAnalyzer, mini_pdb: Path):
        result = analyzer.analyze(str(mini_pdb))
        assert result["success"] is True
