"""Tests for protqc.cli — CLI entry point, subcommands, input detection."""

import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from protqc.cli import detect_input_mode, main, build_parser, _is_pdb_id, _resolve_pdb_input, _prompt_md_choice


# ---------------------------------------------------------------------------
# Helper: run CLI as subprocess (tests the installed entry point)
# ---------------------------------------------------------------------------

def run_cli(*args: str) -> subprocess.CompletedProcess:
    """Run protqc CLI as a subprocess."""
    return subprocess.run(
        [sys.executable, "-m", "protqc.cli", *args],
        capture_output=True,
        text=True,
    )


# ---------------------------------------------------------------------------
# --help and --version
# ---------------------------------------------------------------------------

class TestHelpAndVersion:
    def test_top_level_help(self):
        result = run_cli("--help")
        assert result.returncode == 0
        assert "analyze" in result.stdout
        assert "batch" in result.stdout

    def test_version(self):
        result = run_cli("--version")
        assert result.returncode == 0
        assert "0.1.0" in result.stdout

    def test_analyze_help(self):
        result = run_cli("analyze", "--help")
        assert result.returncode == 0
        assert "input" in result.stdout.lower()

    def test_batch_help(self):
        result = run_cli("batch", "--help")
        assert result.returncode == 0
        assert "directory" in result.stdout.lower()


# ---------------------------------------------------------------------------
# analyze subcommand
# ---------------------------------------------------------------------------

class TestAnalyze:
    def test_pdb_mode(self, mini_pdb: Path):
        result = run_cli("analyze", "--skip-md", str(mini_pdb))
        assert result.returncode == 0
        # Banner and status go to stderr, results to stdout
        assert "Analyzing" in result.stderr

    def test_pdb_produces_verdict(self, mini_pdb: Path):
        result = run_cli("analyze", "--skip-md", str(mini_pdb))
        assert result.returncode == 0
        # Rich output: verdict appears in stdout panel
        combined = result.stdout + result.stderr
        assert any(v in combined for v in ("PASS", "WARNING", "FAIL"))

    def test_json_flag(self, mini_pdb: Path):
        result = run_cli("analyze", "--skip-md", "--json", str(mini_pdb))
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert "verdict" in data
        assert "metrics" in data
        assert data["verdict"]["verdict"] in ("PASS", "WARNING", "FAIL")

    def test_sequence_mode_requires_pdb(self):
        result = run_cli("analyze", "ACDEFGHIKLMNPQRSTVWY")
        assert result.returncode != 0
        assert "pdb" in result.stderr.lower()

    def test_nonexistent_pdb(self):
        result = run_cli("analyze", "nonexistent.pdb")
        assert result.returncode != 0
        assert "not found" in result.stderr.lower()

    def test_nonexistent_fasta(self):
        result = run_cli("analyze", "nonexistent.fasta")
        assert result.returncode != 0
        assert "not found" in result.stderr.lower()

    def test_invalid_sequence_characters(self):
        result = run_cli("analyze", "ACXZJB123")
        assert result.returncode != 0
        assert "invalid" in result.stderr.lower()

    def test_too_short_sequence(self):
        result = run_cli("analyze", "A")
        assert result.returncode != 0
        assert "too short" in result.stderr.lower()

    def test_case_insensitive_sequence(self):
        # Sequence input now exits with error (requires PDB)
        result = run_cli("analyze", "acdefghiklmnpqrstvwy")
        assert result.returncode != 0


# ---------------------------------------------------------------------------
# batch subcommand
# ---------------------------------------------------------------------------

class TestBatch:
    def test_nonexistent_directory(self):
        result = run_cli("batch", "nonexistent_dir/")
        assert result.returncode != 0
        assert "not found" in result.stderr.lower()

    def test_valid_directory(self, fixtures_dir: Path):
        result = run_cli("batch", str(fixtures_dir))
        assert result.returncode == 0
        # Banner/status go to stderr, CSV data to stdout
        assert "Batch" in result.stderr
        assert "file,verdict,risk_score" in result.stdout

    def test_no_subcommand_launches_interactive(self):
        """No-args launches interactive mode; EOF on stdin exits cleanly."""
        result = subprocess.run(
            [sys.executable, "-m", "protqc.cli"],
            capture_output=True,
            text=True,
            input="",  # EOF immediately
        )
        assert result.returncode == 0
        assert "Physics-based verification" in result.stderr


# ---------------------------------------------------------------------------
# PDB ID detection
# ---------------------------------------------------------------------------

class TestPdbIdDetection:
    def test_valid_pdb_ids(self):
        assert _is_pdb_id("1UBQ")
        assert _is_pdb_id("2xwr")
        assert _is_pdb_id("4HHB")
        assert _is_pdb_id("1a2B")

    def test_invalid_pdb_ids(self):
        assert not _is_pdb_id("1UB")        # too short
        assert not _is_pdb_id("1UBQX")      # too long
        assert not _is_pdb_id("1UB!")        # special char
        assert not _is_pdb_id("")            # empty
        assert not _is_pdb_id("test.pdb")    # file path


# ---------------------------------------------------------------------------
# _resolve_pdb_input
# ---------------------------------------------------------------------------

class TestResolvePdbInput:
    def test_local_file_returns_tuple(self, mini_pdb: Path):
        path, is_rcsb = _resolve_pdb_input(str(mini_pdb))
        assert path == mini_pdb
        assert is_rcsb is False

    def test_nonexistent_file_raises(self):
        with pytest.raises(ValueError, match="not found"):
            _resolve_pdb_input("nonexistent_file.pdb")

    def test_pdb_id_detected(self):
        """A 4-char alphanumeric triggers RCSB download (which we don't
        actually run here — just verify the ID detection path)."""
        # Mocking the download so we don't hit the network
        with patch("protqc.cli._fetch_rcsb_pdb") as mock_fetch:
            mock_fetch.return_value = Path("/tmp/1UBQ.pdb")
            path, is_rcsb = _resolve_pdb_input("1UBQ")
            assert is_rcsb is True
            mock_fetch.assert_called_once_with("1UBQ")


# ---------------------------------------------------------------------------
# --trajectory flag
# ---------------------------------------------------------------------------

class TestTrajectoryFlag:
    def test_trajectory_in_parser(self):
        parser = build_parser()
        args = parser.parse_args(["analyze", "--trajectory", "traj.dcd", "test.pdb"])
        assert args.trajectory == "traj.dcd"

    def test_trajectory_default_none(self):
        parser = build_parser()
        args = parser.parse_args(["analyze", "--skip-md", "test.pdb"])
        assert args.trajectory is None


# ---------------------------------------------------------------------------
# MD prompt
# ---------------------------------------------------------------------------


class TestMdPrompt:
    def test_choice_1_full_analysis(self):
        with patch("protqc.cli.Prompt.ask", return_value="1"):
            skip_md, duration = _prompt_md_choice()
        assert skip_md is False
        assert duration is None

    def test_choice_2_skip_md(self):
        with patch("protqc.cli.Prompt.ask", return_value="2"):
            skip_md, duration = _prompt_md_choice()
        assert skip_md is True
        assert duration is None

    def test_choice_3_custom_duration(self):
        with patch("protqc.cli.Prompt.ask", side_effect=["3", "5.0"]):
            skip_md, duration = _prompt_md_choice()
        assert skip_md is False
        assert duration == 5.0

    def test_choice_3_invalid_falls_back(self):
        with patch("protqc.cli.Prompt.ask", side_effect=["3", "abc"]):
            skip_md, duration = _prompt_md_choice()
        assert skip_md is False
        assert duration == 10.0

    def test_choice_3_negative_falls_back(self):
        with patch("protqc.cli.Prompt.ask", side_effect=["3", "-5"]):
            skip_md, duration = _prompt_md_choice()
        assert skip_md is False
        assert duration == 10.0

    def test_not_triggered_with_skip_md_flag(self, mini_pdb):
        """--skip-md should bypass the MD prompt entirely."""
        result = subprocess.run(
            [sys.executable, "-m", "protqc.cli",
             "analyze", "--skip-md", str(mini_pdb)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # Should NOT contain the MD selection prompt
        assert "MD Simulation" not in result.stderr

    def test_not_triggered_in_json_mode(self, mini_pdb):
        """--json mode should not prompt."""
        result = subprocess.run(
            [sys.executable, "-m", "protqc.cli",
             "analyze", "--json", "--skip-md", str(mini_pdb)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0
        assert "MD Simulation" not in result.stderr


# ---------------------------------------------------------------------------
# detect_input_mode unit tests
# ---------------------------------------------------------------------------

class TestDetectInputMode:
    def test_pdb_file(self, mini_pdb: Path):
        mode, value = detect_input_mode(str(mini_pdb))
        assert mode == "pdb"
        assert str(mini_pdb) in value

    def test_raw_sequence(self):
        mode, value = detect_input_mode("ACDEFGHIKLMNPQRSTVWY")
        assert mode == "sequence"
        assert value == "ACDEFGHIKLMNPQRSTVWY"
