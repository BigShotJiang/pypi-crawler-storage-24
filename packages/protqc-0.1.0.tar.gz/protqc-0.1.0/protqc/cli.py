"""
ProtQC CLI — primary user interface.

Usage:
    protqc analyze <sequence_or_file>   Run verification on a single protein
    protqc batch <directory>             Batch-process multiple candidates
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, DownloadColumn, Progress, TransferSpeedColumn
from rich.prompt import Prompt
from rich.table import Table
from rich.text import Text

import protqc
from protqc.config import load_config
from protqc.pipeline import run_pipeline
from protqc.progress import create_stage_display
from protqc.report import generate_html_report
from protqc.types import PipelineResult

console = Console(stderr=True)
out = Console()

# Valid single-letter amino acid codes (standard 20)
VALID_AA = set("ACDEFGHIKLMNPQRSTVWY")

# File extensions that trigger specific input modes
PDB_EXTENSIONS = {".pdb", ".ent"}
FASTA_EXTENSIONS = {".fasta", ".fa", ".faa", ".fas"}

# Banner — compact, scientific, not flashy
_BANNER = Text.from_markup(
    "[bold cyan]ProtQC[/] "
    f"[dim]v{protqc.__version__}[/]\n"
    "[dim]Physics-based verification of AI-generated protein designs[/]"
)

# Verdict styling
_VERDICT_STYLE = {
    "PASS": ("bold green", "green"),
    "WARNING": ("bold yellow", "yellow"),
    "FAIL": ("bold red", "red"),
}


_ASCII_LOGO = r"""[bold cyan]
  ____            _    ___   ____
 |  _ \ _ __ ___ | |_ / _ \ / ___|
 | |_) | '__/ _ \| __| | | | |
 |  __/| | | (_) | |_| |_| | |___
 |_|   |_|  \___/ \__|\__\_\\____|[/]
"""

_PDB_ID_RE = re.compile(r"^[A-Za-z0-9]{4}$")

_MD_DEFAULT_NS = 10.0


def _prompt_md_choice() -> tuple[bool, float | None]:
    """Prompt the user for MD simulation preference when not specified via flags.

    Called only in interactive (non-JSON) mode when none of --skip-md,
    --md-duration, or --trajectory were provided.

    Returns:
        (skip_md, md_duration_ns) — True/None to skip MD entirely,
        False/None for default 10 ns, or False/float for custom duration.
    """
    console.print()
    console.print(
        "  [bold cyan]MD Simulation[/] — takes ~5-50 min depending on protein size"
    )
    console.print()
    console.print("    [cyan]1[/]  Full analysis with 10 ns MD [dim](recommended)[/]")
    console.print("    [cyan]2[/]  Quick static check only     [dim](~30 seconds, no MD)[/]")
    console.print("    [cyan]3[/]  Custom MD duration")
    console.print()

    choice = Prompt.ask("  Select", choices=["1", "2", "3"], default="1")

    if choice == "1":
        return False, None
    elif choice == "2":
        return True, None
    else:
        raw = Prompt.ask("  Duration in nanoseconds", default=str(_MD_DEFAULT_NS))
        try:
            ns = float(raw)
            if ns <= 0:
                console.print(
                    f"  [yellow]Invalid duration, using {_MD_DEFAULT_NS} ns.[/]"
                )
                ns = _MD_DEFAULT_NS
        except ValueError:
            console.print(
                f"  [yellow]Invalid number, using {_MD_DEFAULT_NS} ns.[/]"
            )
            ns = _MD_DEFAULT_NS
        return False, ns


def _is_pdb_id(s: str) -> bool:
    """Check if a string looks like a 4-character RCSB PDB ID."""
    return bool(_PDB_ID_RE.match(s))


def _fetch_rcsb_pdb(pdb_id: str, dest_dir: str | Path | None = None) -> Path:
    """Download a PDB file from RCSB with progress display.

    Args:
        pdb_id: 4-character PDB identifier (e.g. '1UBQ').
        dest_dir: Directory to save the file. Uses a temp dir if None.

    Returns:
        Path to the downloaded PDB file.

    Raises:
        SystemExit: If the download fails.
    """
    pdb_id = pdb_id.upper()
    url = f"https://files.rcsb.org/download/{pdb_id}.pdb"

    if dest_dir is None:
        dest_dir = Path(tempfile.mkdtemp(prefix="protqc_"))
    else:
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)

    dest_path = dest_dir / f"{pdb_id}.pdb"

    console.print(f"  Downloading [bold]{pdb_id}[/] from RCSB…")

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ProtQC/0.1"})
        response = urllib.request.urlopen(req, timeout=30)  # noqa: S310
        total = int(response.headers.get("Content-Length", 0))

        with Progress(
            "[progress.description]{task.description}",
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(f"  {pdb_id}.pdb", total=total or None)
            with open(dest_path, "wb") as f:
                while chunk := response.read(8192):
                    f.write(chunk)
                    progress.update(task, advance=len(chunk))

    except urllib.error.HTTPError as e:
        if e.code == 404:
            msg = f"PDB ID '{pdb_id}' not found on RCSB."
        else:
            msg = f"RCSB download failed: HTTP {e.code}"
        console.print(f"  [red]{msg}[/]")
        raise ValueError(msg) from e
    except urllib.error.URLError as e:
        msg = f"Download failed: {e}"
        console.print(f"  [red]{msg}[/]")
        raise ValueError(msg) from e

    console.print(f"  [green]✓[/] Saved to {dest_path}")
    return dest_path


def _resolve_pdb_input(user_input: str) -> tuple[Path, bool]:
    """Resolve user input to a PDB file path.

    If the input is a 4-character alphanumeric string, downloads from RCSB.
    Otherwise, treats it as a file path.

    Returns:
        (path, is_rcsb) — path to PDB on disk and whether it was from RCSB.

    Raises:
        ValueError: If resolution fails (file not found, download error).
    """
    user_input = user_input.strip()

    if _is_pdb_id(user_input):
        return _fetch_rcsb_pdb(user_input), True

    path = Path(user_input)
    if not path.is_file():
        msg = f"File not found: {user_input}"
        console.print(f"  [red]{msg}[/]")
        raise ValueError(msg)

    return path, False


_RCSB_WARNING = (
    "[yellow]Note:[/] Experimental PDB detected. B-factors are crystallographic, "
    "not pLDDT. pLDDT risk score may be unreliable."
)


def _print_banner() -> None:
    """Print startup banner to stderr (not captured by --json)."""
    console.print()
    console.print(
        Panel(
            _BANNER,
            border_style="cyan",
            padding=(0, 2),
        )
    )


def detect_input_mode(input_arg: str) -> tuple[str, str]:
    """Detect whether input is a PDB file, FASTA file, or raw sequence.

    Args:
        input_arg: The positional argument from CLI.

    Returns:
        (mode, description) where mode is "pdb", "fasta", or "sequence".

    Raises:
        SystemExit: If a file path is given but doesn't exist,
                    or a sequence contains invalid characters.
    """
    path = Path(input_arg)
    ext = path.suffix.lower()

    # Check if it looks like a file path (has a recognized extension or exists on disk)
    if ext in PDB_EXTENSIONS:
        if not path.is_file():
            print(f"Error: PDB file not found: {input_arg}", file=sys.stderr)
            sys.exit(1)
        return "pdb", str(path)

    if ext in FASTA_EXTENSIONS:
        if not path.is_file():
            print(f"Error: FASTA file not found: {input_arg}", file=sys.stderr)
            sys.exit(1)
        return "fasta", str(path)

    # If it exists as a file, infer from extension or treat as PDB
    if path.is_file():
        if ext in PDB_EXTENSIONS:
            return "pdb", str(path)
        if ext in FASTA_EXTENSIONS:
            return "fasta", str(path)
        # Unknown extension but file exists — guess PDB
        return "pdb", str(path)

    # Not a file path — treat as raw sequence string
    sequence = input_arg.upper().strip()
    invalid_chars = set(sequence) - VALID_AA
    if invalid_chars:
        print(
            f"Error: Invalid amino acid characters: {', '.join(sorted(invalid_chars))}\n"
            f"Valid characters: {''.join(sorted(VALID_AA))}",
            file=sys.stderr,
        )
        sys.exit(1)

    if len(sequence) < 2:
        print("Error: Sequence too short (minimum 2 residues).", file=sys.stderr)
        sys.exit(1)

    return "sequence", sequence


def _risk_bar(score: float, width: int = 20) -> Text:
    """Render a colored risk bar: green→yellow→red."""
    filled = int(score * width)
    if score < 0.3:
        color = "green"
    elif score < 0.6:
        color = "yellow"
    else:
        color = "red"
    bar = Text()
    bar.append("█" * filled, style=color)
    bar.append("░" * (width - filled), style="dim")
    return bar


def _display_rich(result: PipelineResult) -> None:
    """Display pipeline result with rich formatting."""
    v = result["verdict"]
    verdict_str = v["verdict"]
    verdict_style, border_color = _VERDICT_STYLE.get(
        verdict_str, ("bold white", "white")
    )

    # Header info
    header = Text()
    header.append(f"{result['design_name']}", style="bold")
    header.append(f"  {result['input_mode']}", style="dim")
    if result.get("sequence_length"):
        header.append(f"  {result['sequence_length']} residues", style="dim")

    # Verdict panel
    verdict_body = Text()
    verdict_body.append(verdict_str, style=verdict_style)
    verdict_body.append(f"   Risk: {v['risk_score']:.3f}", style="dim")

    out.print()
    out.print(Panel(
        verdict_body,
        title=header,
        title_align="left",
        border_style=border_color,
        padding=(0, 2),
    ))

    # Partial analysis warning
    n_available = len(v["breakdown"])
    n_total = 6
    if n_available < n_total:
        out.print(
            f"  [yellow dim]⚠ Partial analysis: {n_available}/{n_total} metrics "
            "available (MD skipped). Run without --skip-md for full verification.[/]"
        )
        out.print()

    # Risk breakdown table
    if v["breakdown"]:
        table = Table(
            show_header=True,
            header_style="bold",
            border_style="dim",
            padding=(0, 1),
            expand=False,
        )
        table.add_column("Metric", style="cyan", min_width=20)
        table.add_column("Score", justify="right", min_width=6)
        table.add_column("Risk", min_width=22)

        for key, score in sorted(v["breakdown"].items(), key=lambda x: -x[1]):
            if score >= 0.6:
                score_style = "red"
            elif score >= 0.3:
                score_style = "yellow"
            else:
                score_style = "green"

            table.add_row(
                key,
                Text(f"{score:.3f}", style=score_style),
                _risk_bar(score),
            )

        out.print(table)

    # Tool results
    out.print()
    for tr in result["tool_results"]:
        if tr["success"]:
            out.print(f"  [green]✓[/] {tr['tool_name']}")
        else:
            reason = tr["error"] or "unknown error"
            out.print(f"  [yellow]○[/] {tr['tool_name']}  [dim]{reason}[/]")

    out.print()

    if result.get("report"):
        out.print(Panel(result["report"], title="Report", border_style="dim"))


def _display_json(result: PipelineResult) -> None:
    """Display pipeline result as JSON to stdout."""
    output = {
        "design_name": result["design_name"],
        "pdb_path": result["pdb_path"],
        "input_mode": result["input_mode"],
        "sequence_length": result.get("sequence_length"),
        "metrics": {
            k: v for k, v in result["metrics"].items()
            if not isinstance(v, (list,)) and k != "pdb_path"
        },
        "verdict": {
            "verdict": result["verdict"]["verdict"],
            "risk_score": result["verdict"]["risk_score"],
            "breakdown": result["verdict"]["breakdown"],
        },
        "tool_results": [
            {
                "tool_name": tr["tool_name"],
                "success": tr["success"],
                "error": tr["error"],
            }
            for tr in result["tool_results"]
        ],
    }
    print(json.dumps(output, indent=2))


def cmd_analyze(args: argparse.Namespace) -> None:
    """Handle the 'analyze' subcommand."""
    json_mode = getattr(args, "json", False) or getattr(args, "format", "text") == "json"

    if not json_mode:
        _print_banner()

    mode, value = detect_input_mode(args.input)

    if mode == "sequence":
        print(f"[ProtQC] Sequence input requires a PDB file.", file=sys.stderr)
        print(
            "[ProtQC] Run structure prediction first (ColabFold/ESMFold) "
            "and provide the output PDB.",
            file=sys.stderr,
        )
        sys.exit(1)

    if mode == "fasta":
        print(f"[ProtQC] FASTA input not yet supported.", file=sys.stderr)
        print(
            "[ProtQC] Run structure prediction first and provide the PDB.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load config
    try:
        config = load_config(args.config)
    except Exception as e:
        print(f"Error loading config: {e}", file=sys.stderr)
        sys.exit(1)

    skip_md = getattr(args, "skip_md", False)
    trajectory = getattr(args, "trajectory", None)
    md_duration_ns = getattr(args, "md_duration", None)

    # When the user hasn't explicitly chosen an MD strategy, prompt them.
    # Skip the prompt in JSON mode (non-interactive) or when any MD-related
    # flag was provided (--skip-md, --md-duration, --trajectory).
    user_chose_md = skip_md or trajectory or md_duration_ns is not None
    if not json_mode and not user_chose_md and sys.stdin.isatty():
        skip_md, md_duration_ns = _prompt_md_choice()

    if not json_mode:
        console.print(f"  Analyzing [bold]{Path(value).name}[/]", highlight=False)
        if trajectory:
            console.print(f"  [dim]Using existing trajectory: {trajectory}[/]")
        elif skip_md:
            console.print("  [dim]Skipping MD simulation[/]")
        elif md_duration_ns:
            console.print(f"  [dim]MD simulation: {md_duration_ns} ns[/]")
        console.print()

    on_stage = create_stage_display(console) if not json_mode else None

    result = run_pipeline(
        pdb_path=value,
        config=config,
        input_mode=mode,
        skip_md=skip_md,
        md_duration_ns=md_duration_ns,
        generate_report=getattr(args, "report", False),
        output_dir=args.output_dir,
        trajectory=trajectory,
        on_stage=on_stage,
    )

    if json_mode:
        _display_json(result)
    else:
        _display_rich(result)

    # HTML report generation
    html_path = getattr(args, "html", None)
    if html_path:
        out_path = generate_html_report(result, config, html_path)
        console.print(f"  [green]✓[/] HTML report: [bold]{out_path}[/]")
        console.print()
        webbrowser.open(out_path.as_uri())


def cmd_batch(args: argparse.Namespace) -> None:
    """Handle the 'batch' subcommand."""
    directory = Path(args.directory)
    if not directory.is_dir():
        print(f"Error: Directory not found: {args.directory}", file=sys.stderr)
        sys.exit(1)

    # Find eligible PDB files
    eligible = sorted(
        f
        for f in directory.iterdir()
        if f.is_file() and f.suffix.lower() in PDB_EXTENSIONS
    )

    if not eligible:
        print(f"No PDB files found in {directory}", file=sys.stderr)
        sys.exit(1)

    # Load config
    try:
        config = load_config(args.config)
    except Exception as e:
        print(f"Error loading config: {e}", file=sys.stderr)
        sys.exit(1)

    json_mode = getattr(args, "format", "csv") == "json"

    if not json_mode:
        _print_banner()
        console.print(f"  Batch: [bold]{len(eligible)}[/] PDB files from {directory}")
        console.print()

    results: list[dict[str, Any]] = []
    for pdb_file in eligible:
        if not json_mode:
            console.print(f"  Processing [bold]{pdb_file.name}[/]…", highlight=False)
        result = run_pipeline(
            pdb_path=pdb_file,
            config=config,
            skip_md=True,  # Batch always skips MD for speed
        )
        v = result["verdict"]
        results.append({
            "file": pdb_file.name,
            "verdict": v["verdict"],
            "risk_score": v["risk_score"],
            "plddt_mean": result["metrics"].get("plddt_mean", ""),
        })

    # Output
    fmt = getattr(args, "format", "csv")
    if fmt == "json":
        output = json.dumps(results, indent=2)
    else:
        header = "file,verdict,risk_score,plddt_mean"
        rows = [
            f"{r['file']},{r['verdict']},{r['risk_score']},{r['plddt_mean']}"
            for r in results
        ]
        output = header + "\n" + "\n".join(rows)

    if args.output:
        Path(args.output).write_text(output + "\n")
        if not json_mode:
            console.print(f"\n  Results written to [bold]{args.output}[/]")
    else:
        print(output)


def cmd_chat(args: argparse.Namespace) -> None:
    """Handle the 'chat' subcommand."""
    try:
        import litellm  # noqa: F401
    except ImportError:
        print(
            "Error: litellm is required for the chat command.\n"
            "Install it with: pip install 'protqc[chat]'",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        config = load_config(args.config)
    except Exception as e:
        print(f"Error loading config: {e}", file=sys.stderr)
        sys.exit(1)

    from protqc.chat import run_chat

    run_chat(config)


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="protqc",
        description=(
            "ProtQC — Physics-based verification of AI-generated protein designs.\n"
            "Catches structural hallucinations before wet-lab."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"protqc {protqc.__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # -- analyze --
    analyze_parser = subparsers.add_parser(
        "analyze",
        help="Analyze a single protein design (sequence, FASTA, or PDB)",
    )
    analyze_parser.add_argument(
        "input",
        help="Amino acid sequence, path to .fasta file, or path to .pdb file",
    )
    analyze_parser.add_argument(
        "--config",
        "-c",
        default=None,
        help="Path to custom thresholds.yaml (default: configs/thresholds.yaml)",
    )
    analyze_parser.add_argument(
        "--output-dir",
        "-o",
        default=None,
        help="Directory for output files (default: temp directory)",
    )
    analyze_parser.add_argument(
        "--format",
        "-f",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    analyze_parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Machine-readable JSON output (shorthand for --format json)",
    )
    analyze_parser.add_argument(
        "--skip-md",
        action="store_true",
        default=False,
        help="Skip MD simulation (quick local analysis with fpocket/FreeSASA only)",
    )
    analyze_parser.add_argument(
        "--md-duration",
        type=float,
        default=None,
        help="MD simulation duration in nanoseconds (default: from config, typically 10)",
    )
    analyze_parser.add_argument(
        "--report",
        action="store_true",
        default=False,
        help="Generate LLM report (requires Ollama with qwen3:8b)",
    )
    analyze_parser.add_argument(
        "--html",
        default=None,
        metavar="FILE",
        help="Generate self-contained HTML report to FILE",
    )
    analyze_parser.add_argument(
        "--trajectory",
        default=None,
        metavar="FILE",
        help="Use existing trajectory (DCD/XTC) instead of running MD",
    )

    # -- batch --
    batch_parser = subparsers.add_parser(
        "batch",
        help="Batch-process multiple protein designs from a directory",
    )
    batch_parser.add_argument(
        "directory",
        help="Directory containing .pdb and/or .fasta files",
    )
    batch_parser.add_argument(
        "--config",
        "-c",
        default=None,
        help="Path to custom thresholds.yaml (default: configs/thresholds.yaml)",
    )
    batch_parser.add_argument(
        "--output",
        "-o",
        default=None,
        help="Output CSV file path (default: stdout)",
    )
    batch_parser.add_argument(
        "--format",
        "-f",
        choices=["csv", "json"],
        default="csv",
        help="Batch output format (default: csv)",
    )

    # -- chat --
    chat_parser = subparsers.add_parser(
        "chat",
        help="AI chat assistant for protein analysis",
    )
    chat_parser.add_argument(
        "--config",
        "-c",
        default=None,
        help="Path to custom thresholds.yaml (default: configs/thresholds.yaml)",
    )

    return parser


def _interactive_session() -> None:
    """Run the interactive REPL session."""
    console.print(_ASCII_LOGO)
    console.print(
        f"  [dim]v{protqc.__version__} — "
        "Physics-based verification of AI-generated protein designs[/]"
    )
    console.print()
    console.print("  Commands: [cyan]/analyze[/]  [cyan]/batch[/]  "
                   "[cyan]/config[/]  [cyan]/help[/]  "
                   "[cyan]/version[/]  [cyan]/quit[/]")
    console.print()

    # Load config once for the session
    try:
        config = load_config()
    except Exception as e:
        console.print(f"  [yellow]Warning: Could not load config: {e}[/]")
        config = None

    while True:
        try:
            cmd = Prompt.ask("[bold cyan]protqc[/]").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n  [dim]Goodbye.[/]")
            break

        if not cmd:
            continue

        if cmd in ("/quit", "/exit", "/q"):
            console.print("  [dim]Goodbye.[/]")
            break

        elif cmd == "/help":
            console.print()
            console.print("  [cyan]/analyze[/]   Analyze a protein structure (PDB file or RCSB ID)")
            console.print("  [cyan]/batch[/]     Batch-process a directory of PDB files")
            console.print("  [cyan]/config[/]    Show current threshold configuration")
            console.print("  [cyan]/version[/]   Show version")
            console.print("  [cyan]/quit[/]      Exit interactive mode")
            console.print()

        elif cmd == "/version":
            console.print(f"  ProtQC v{protqc.__version__}")

        elif cmd == "/config":
            if config is None:
                console.print("  [red]No config loaded.[/]")
                continue
            console.print()
            # Show risk weights
            weights = config.get("risk_weights", {})
            table = Table(title="Risk Weights", border_style="dim", expand=False)
            table.add_column("Metric", style="cyan")
            table.add_column("Weight", justify="right")
            for k, v in sorted(weights.items()):
                table.add_row(k, f"{v:.2f}")
            console.print(table)
            # Show verdict thresholds
            verdicts_cfg = config.get("verdicts", {})
            console.print(f"\n  Verdict thresholds: "
                          f"PASS < {verdicts_cfg.get('pass_threshold', '?')}, "
                          f"WARNING < {verdicts_cfg.get('warn_threshold', '?')}, "
                          f"FAIL >= {verdicts_cfg.get('warn_threshold', '?')}")
            console.print()

        elif cmd == "/analyze":
            pdb_input = Prompt.ask("  PDB file or RCSB ID (e.g. 1UBQ)")
            if not pdb_input.strip():
                console.print("  [yellow]No input provided.[/]")
                continue

            try:
                pdb_path, is_rcsb = _resolve_pdb_input(pdb_input)
            except ValueError:
                continue

            if is_rcsb:
                console.print(f"  {_RCSB_WARNING}")

            # Skip MD first — determines whether to ask duration/trajectory
            skip_md_str = Prompt.ask("  Skip MD simulation?", choices=["y", "n"], default="n")
            skip_md = skip_md_str.lower() == "y"

            md_ns = 10.0
            trajectory: str | None = None

            if skip_md:
                # Offer to use an existing trajectory for analysis
                traj_input = Prompt.ask(
                    "  Existing trajectory (DCD/XTC, blank for static-only)", default=""
                )
                if traj_input.strip():
                    traj_p = Path(traj_input.strip())
                    if traj_p.is_file():
                        trajectory = str(traj_p)
                    else:
                        console.print(f"  [yellow]File not found: {traj_input}. Running static-only.[/]")
            else:
                md_str = Prompt.ask("  MD duration (ns)", default="10")
                try:
                    md_ns = float(md_str)
                except ValueError:
                    console.print("  [yellow]Invalid duration, using 10 ns.[/]")
                    md_ns = 10.0

            default_html = f"/tmp/protqc_{pdb_path.stem}_report.html"
            html_path = Prompt.ask("  HTML report path", default=default_html)

            if config is None:
                console.print("  [red]No config loaded. Cannot run analysis.[/]")
                continue

            console.print()
            console.print(f"  Analyzing [bold]{pdb_path.name}[/]…")
            if trajectory:
                console.print(f"  [dim]Using existing trajectory: {trajectory}[/]")
            elif skip_md:
                console.print("  [dim]Skipping MD simulation[/]")
            console.print()

            result = run_pipeline(
                pdb_path=pdb_path,
                config=config,
                input_mode="pdb",
                skip_md=skip_md if not trajectory else False,
                md_duration_ns=md_ns,
                trajectory=trajectory,
                on_stage=create_stage_display(console),
            )
            _display_rich(result)

            if html_path.strip():
                out_path = generate_html_report(result, config, html_path.strip())
                console.print(f"  [green]✓[/] HTML report: [bold]{out_path}[/]")
                webbrowser.open(out_path.as_uri())
                console.print()

        elif cmd == "/batch":
            dir_input = Prompt.ask("  Directory containing PDB files")
            if not dir_input.strip():
                console.print("  [yellow]No directory provided.[/]")
                continue

            directory = Path(dir_input.strip())
            if not directory.is_dir():
                console.print(f"  [red]Directory not found: {dir_input}[/]")
                continue

            eligible = sorted(
                f for f in directory.iterdir()
                if f.is_file() and f.suffix.lower() in PDB_EXTENSIONS
            )
            if not eligible:
                console.print(f"  [yellow]No PDB files found in {directory}[/]")
                continue

            if config is None:
                console.print("  [red]No config loaded. Cannot run batch.[/]")
                continue

            console.print(f"  Processing [bold]{len(eligible)}[/] PDB files…")
            console.print()

            for pdb_file in eligible:
                console.print(f"  Analyzing [bold]{pdb_file.name}[/]…", highlight=False)
                result = run_pipeline(pdb_path=pdb_file, config=config, skip_md=True)
                v = result["verdict"]
                style = _VERDICT_STYLE.get(v["verdict"], ("white", "white"))[0]
                console.print(
                    f"    [{style}]{v['verdict']}[/]  "
                    f"Risk: {v['risk_score']:.3f}  "
                    f"pLDDT: {result['metrics'].get('plddt_mean', 'N/A')}"
                )
            console.print()

        else:
            console.print(f"  [yellow]Unknown command: {cmd}[/]")
            console.print("  Type [cyan]/help[/] for available commands.")


def main(argv: list[str] | None = None) -> None:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        _interactive_session()
        return

    if args.command == "analyze":
        cmd_analyze(args)
    elif args.command == "batch":
        cmd_batch(args)
    elif args.command == "chat":
        cmd_chat(args)


if __name__ == "__main__":
    main()
