"""
Shared type definitions for ProtQC pipeline.

All tool modules, the risk scorer, and the orchestrator use these types
to pass structured data through the pipeline.
"""

from __future__ import annotations

from typing import Any, TypedDict


class ToolResult(TypedDict):
    """Generic result from any verification tool.

    Every tool in protqc.tools returns this shape.
    The 'metrics' dict contains tool-specific key-value pairs
    that the risk scorer reads by known keys.
    """

    tool_name: str
    success: bool
    metrics: dict[str, Any]
    error: str | None


class VerificationMetrics(TypedDict, total=False):
    """Aggregated metrics from all verification tools.

    Keys correspond to risk_weights keys in thresholds.yaml.
    'total=False' because not every run populates every field
    (e.g., PDB input skips pLDDT).
    """

    # Structure prediction (ESMFold)
    plddt_mean: float
    plddt_median: float
    plddt_min: float
    plddt_per_residue: list[float]
    low_confidence_residues: int
    high_confidence_pct: float

    # MD simulation (OpenMM + MDTraj)
    rmsd_mean_A: float
    rmsd_max_A: float
    rmsd_final_A: float
    rmsd_drift_A: float
    rmsf_mean_A: float
    rmsf_max_A: float
    n_flexible_residues: int
    md_stable: bool

    # Cavity detection (fpocket)
    num_pockets: int
    total_volume_A3: float
    max_pocket_volume_A3: float
    cavity_flag: bool

    # Solvent accessibility (FreeSASA)
    total_sasa_A2: float
    polar_sasa_A2: float
    apolar_sasa_A2: float
    polar_ratio: float
    sasa_normal: bool

    # H-bond persistence (MDTraj)
    hbond_initial_count: int
    hbond_final_count: int
    hbond_persistence_pct: float
    hbond_mean_count: float
    hbond_stable: bool

    # Secondary structure stability (MDTraj DSSP)
    ss_preservation_pct: float
    helix_initial: int
    helix_final: int
    sheet_initial: int
    sheet_final: int
    ss_stable: bool


class RiskVerdict(TypedDict):
    """Composite risk assessment output.

    Produced by protqc.scoring.calculate_risk_score().
    The 'breakdown' dict maps metric names to their individual
    normalized risk contributions (0.0 = perfect, 1.0 = certain failure).
    """

    risk_score: float  # 0.0 (perfect) to 1.0 (certain failure)
    verdict: str  # "PASS", "WARNING", or "FAIL"
    breakdown: dict[str, float]  # per-metric normalized scores
    weights: dict[str, float]  # weights used for this run
    explanation: str  # human-readable summary of key risk drivers


class PipelineResult(TypedDict):
    """Full pipeline output — everything a report generator or CLI needs."""

    design_name: str
    sequence: str | None
    sequence_length: int | None
    pdb_path: str
    input_mode: str  # "sequence", "fasta", or "pdb"
    metrics: VerificationMetrics
    verdict: RiskVerdict
    tool_results: list[ToolResult]
    report: str | None  # LLM-generated report, None if skipped
