"""
Configuration loader for ProtQC threshold and scoring parameters.

Loads thresholds.yaml and validates required sections exist.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml


class ConfigError(Exception):
    """Raised when configuration is missing, malformed, or incomplete."""

    pass


# Keys that must exist at the top level of thresholds.yaml
REQUIRED_KEYS = frozenset(
    {
        "structure_scorer",
        "physics_verifier",
        "cavity",
        "surface",
        "hbond",
        "secondary_structure",
        "risk_weights",
        "verdicts",
    }
)


def _find_default_config() -> Path:
    """Locate configs/thresholds.yaml relative to CWD or package root."""
    # Try CWD first (normal usage)
    cwd_path = Path.cwd() / "configs" / "thresholds.yaml"
    if cwd_path.is_file():
        return cwd_path

    # Try relative to this file's package root
    pkg_root = Path(__file__).resolve().parent.parent
    pkg_path = pkg_root / "configs" / "thresholds.yaml"
    if pkg_path.is_file():
        return pkg_path

    raise ConfigError(
        "Could not find configs/thresholds.yaml. "
        "Searched:\n"
        f"  - {cwd_path}\n"
        f"  - {pkg_path}\n"
        "Provide an explicit path via load_config(path=...)."
    )


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load and validate the ProtQC threshold configuration.

    Args:
        path: Explicit path to a YAML config file.
              If None, searches CWD and package root for configs/thresholds.yaml.

    Returns:
        Parsed configuration dict with all threshold sections.

    Raises:
        ConfigError: If the file is missing, unreadable, or lacks required keys.
    """
    if path is not None:
        config_path = Path(path)
        if not config_path.is_file():
            raise ConfigError(f"Config file not found: {config_path}")
    else:
        config_path = _find_default_config()

    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ConfigError(f"Failed to parse YAML config {config_path}: {e}") from e

    if not isinstance(config, dict):
        raise ConfigError(
            f"Config file {config_path} did not parse as a dict "
            f"(got {type(config).__name__})"
        )

    # Validate required top-level keys
    present_keys = set(config.keys())
    missing = REQUIRED_KEYS - present_keys
    if missing:
        raise ConfigError(
            f"Config {config_path} is missing required sections: "
            f"{', '.join(sorted(missing))}"
        )

    return config
