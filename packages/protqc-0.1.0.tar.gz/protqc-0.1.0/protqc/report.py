"""
ProtQC HTML Report Generator — self-contained single-file HTML reports.

Generates publication-quality HTML reports with embedded base64 plots.
All CSS, JS, and images are inlined so the output is a single portable file.
"""

from __future__ import annotations

import base64
import io
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jinja2 import BaseLoader, Environment

import protqc
from protqc.types import PipelineResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Matplotlib setup (non-interactive backend for headless rendering)
# ---------------------------------------------------------------------------

_MPL_AVAILABLE = False
try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    _MPL_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Plot generators — return base64-encoded PNGs
# ---------------------------------------------------------------------------

def _fig_to_base64(fig: Any) -> str:
    """Convert a matplotlib figure to a base64-encoded PNG string."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight", facecolor="#ffffff")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("ascii")


def _plot_plddt(per_residue: list[float], plddt_detected: bool) -> str | None:
    """Generate per-residue pLDDT (or B-factor) bar plot as base64 PNG."""
    if not _MPL_AVAILABLE or not per_residue:
        return None

    fig, ax = plt.subplots(figsize=(10, 3))

    residue_ids = list(range(1, len(per_residue) + 1))

    # Color by confidence band (AlphaFold convention)
    colors = []
    for v in per_residue:
        if v >= 90:
            colors.append("#0053D6")  # Very high
        elif v >= 70:
            colors.append("#65CBF3")  # Confident
        elif v >= 50:
            colors.append("#FFDB13")  # Low
        else:
            colors.append("#FF7D45")  # Very low

    ax.bar(residue_ids, per_residue, color=colors, width=1.0, edgecolor="none")

    # Threshold lines
    ax.axhline(y=90, color="#0053D6", linestyle="--", linewidth=0.8, alpha=0.5)
    ax.axhline(y=70, color="#65CBF3", linestyle="--", linewidth=0.8, alpha=0.5)
    ax.axhline(y=50, color="#FFDB13", linestyle="--", linewidth=0.8, alpha=0.5)

    ylabel = "pLDDT" if plddt_detected else "B-factor (Å²)"
    ax.set_xlabel("Residue Index", fontsize=10)
    ax.set_ylabel(ylabel, fontsize=10)
    ax.set_title(
        "Per-Residue Confidence" if plddt_detected else "Per-Residue B-factors",
        fontsize=11,
        fontweight="bold",
    )
    if plddt_detected:
        ax.set_ylim(0, 100)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()

    return _fig_to_base64(fig)


def _plot_rmsd(rmsd_per_frame: list[float], threshold: float) -> str | None:
    """Generate RMSD trajectory plot as base64 PNG."""
    if not _MPL_AVAILABLE or not rmsd_per_frame:
        return None

    fig, ax = plt.subplots(figsize=(10, 3))

    n_frames = len(rmsd_per_frame)
    # Approximate time axis (frames are evenly spaced across the simulation)
    time = [i / max(1, n_frames - 1) * 100 for i in range(n_frames)]

    ax.plot(time, rmsd_per_frame, color="#2563EB", linewidth=1.0, alpha=0.9)
    ax.fill_between(time, rmsd_per_frame, alpha=0.15, color="#2563EB")

    # Threshold line
    ax.axhline(
        y=threshold,
        color="#DC2626",
        linestyle="--",
        linewidth=1.0,
        label=f"Threshold ({threshold:.1f} Å)",
    )

    ax.set_xlabel("Simulation Progress (%)", fontsize=10)
    ax.set_ylabel("Backbone RMSD (Å)", fontsize=10)
    ax.set_title("RMSD Trajectory", fontsize=11, fontweight="bold")
    ax.legend(loc="upper left", fontsize=9)
    ax.set_xlim(0, 100)
    ax.set_ylim(bottom=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()

    return _fig_to_base64(fig)


# ---------------------------------------------------------------------------
# Jinja2 HTML template
# ---------------------------------------------------------------------------

_HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ProtQC Report — {{ design_name }}</title>
<style>
  :root {
    --pass: #16A34A;
    --warn: #CA8A04;
    --fail: #DC2626;
    --bg: #FAFAFA;
    --card: #FFFFFF;
    --border: #E5E7EB;
    --text: #1F2937;
    --muted: #6B7280;
    --accent: #2563EB;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                 "Helvetica Neue", Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.6;
    padding: 2rem;
    max-width: 960px;
    margin: 0 auto;
  }

  /* Header */
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 2px solid var(--border);
    padding-bottom: 1rem;
    margin-bottom: 2rem;
  }
  .header-left h1 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--accent);
  }
  .header-left .subtitle {
    font-size: 0.85rem;
    color: var(--muted);
  }
  .verdict-badge {
    display: inline-block;
    padding: 0.4rem 1.2rem;
    border-radius: 6px;
    font-size: 1.1rem;
    font-weight: 700;
    color: #fff;
  }
  .verdict-PASS { background: var(--pass); }
  .verdict-WARNING { background: var(--warn); }
  .verdict-FAIL { background: var(--fail); }

  /* Warning banner */
  .warning-banner {
    background: #FEF3C7;
    border: 1px solid #F59E0B;
    border-radius: 6px;
    padding: 0.75rem 1rem;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    color: #92400E;
  }
  .warning-banner strong { color: #B45309; }

  /* Cards */
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1.25rem;
    margin-bottom: 1.5rem;
  }
  .card h2 {
    font-size: 1rem;
    font-weight: 600;
    margin-bottom: 0.75rem;
    color: var(--text);
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.4rem;
  }

  /* Summary grid */
  .summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
  }
  .summary-item {
    text-align: center;
    padding: 0.75rem;
    background: var(--bg);
    border-radius: 6px;
  }
  .summary-item .label {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--muted);
  }
  .summary-item .value {
    font-size: 1.4rem;
    font-weight: 700;
  }

  /* Risk table */
  .risk-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.9rem;
  }
  .risk-table th {
    text-align: left;
    padding: 0.5rem 0.75rem;
    border-bottom: 2px solid var(--border);
    font-weight: 600;
    color: var(--muted);
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }
  .risk-table td {
    padding: 0.5rem 0.75rem;
    border-bottom: 1px solid var(--border);
  }
  .risk-bar-bg {
    width: 100%;
    height: 12px;
    background: #F3F4F6;
    border-radius: 6px;
    overflow: hidden;
    min-width: 120px;
  }
  .risk-bar-fill {
    height: 100%;
    border-radius: 6px;
    transition: width 0.3s;
  }
  .risk-low { background: var(--pass); }
  .risk-med { background: var(--warn); }
  .risk-high { background: var(--fail); }

  /* Tool status */
  .tool-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.9rem;
  }
  .tool-table th {
    text-align: left;
    padding: 0.5rem 0.75rem;
    border-bottom: 2px solid var(--border);
    font-weight: 600;
    color: var(--muted);
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }
  .tool-table td {
    padding: 0.5rem 0.75rem;
    border-bottom: 1px solid var(--border);
  }
  .status-ok { color: var(--pass); font-weight: 600; }
  .status-skip { color: var(--muted); }

  /* Plots */
  .plot-img {
    width: 100%;
    height: auto;
    border-radius: 4px;
  }

  /* Threshold config */
  .config-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 0.5rem;
    font-size: 0.85rem;
  }
  .config-item {
    display: flex;
    justify-content: space-between;
    padding: 0.25rem 0.5rem;
    background: var(--bg);
    border-radius: 4px;
  }
  .config-item .key { color: var(--muted); }
  .config-item .val { font-weight: 600; font-family: monospace; }

  /* Footer */
  .footer {
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid var(--border);
    font-size: 0.8rem;
    color: var(--muted);
    text-align: center;
  }
  .footer a { color: var(--accent); text-decoration: none; }

  @media print {
    body { padding: 1rem; max-width: 100%; }
    .card { break-inside: avoid; }
  }
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <div class="header-left">
    <h1>ProtQC</h1>
    <div class="subtitle">Physics-based verification of AI-generated protein designs</div>
    <div class="subtitle" style="margin-top:0.25rem">
      <strong>{{ design_name }}</strong> &mdash; {{ date }}
    </div>
  </div>
  <div>
    <span class="verdict-badge verdict-{{ verdict }}">{{ verdict }}</span>
  </div>
</div>

{% if bfactor_warning %}
<div class="warning-banner">
  <strong>⚠ Experimental PDB detected.</strong>
  B-factor values in this file appear to be crystallographic thermal displacement
  factors (B<sub>iso</sub>), not AlphaFold/ESMFold pLDDT confidence scores.
  The pLDDT-based risk contribution may not be meaningful for this structure.
  Consider using a predicted structure from ColabFold or ESMFold instead.
</div>
{% endif %}

<!-- Summary -->
<div class="card">
  <h2>Summary</h2>
  <div class="summary-grid">
    <div class="summary-item">
      <div class="label">Risk Score</div>
      <div class="value" style="color:{{ verdict_color }}">{{ risk_score }}</div>
    </div>
    <div class="summary-item">
      <div class="label">Verdict</div>
      <div class="value" style="color:{{ verdict_color }}">{{ verdict }}</div>
    </div>
    <div class="summary-item">
      <div class="label">Residues</div>
      <div class="value">{{ sequence_length or "N/A" }}</div>
    </div>
    <div class="summary-item">
      <div class="label">PDB Source</div>
      <div class="value" style="font-size:0.9rem">{{ pdb_name }}</div>
    </div>
    <div class="summary-item">
      <div class="label">Input Mode</div>
      <div class="value" style="font-size:0.9rem">{{ input_mode }}</div>
    </div>
    {% if plddt_mean is not none %}
    <div class="summary-item">
      <div class="label">pLDDT Mean</div>
      <div class="value">{{ plddt_mean }}</div>
    </div>
    {% endif %}
  </div>
</div>

{% if partial_warning %}
<div class="warning-banner">
  <strong>⚠ Partial analysis:</strong> {{ n_available }}/{{ n_total }} metrics available
  (MD skipped). Run without <code>--skip-md</code> for full verification.
</div>
{% endif %}

<!-- Risk Breakdown -->
<div class="card">
  <h2>Risk Breakdown</h2>
  <table class="risk-table">
    <thead>
      <tr>
        <th>Metric</th>
        <th>Score</th>
        <th>Weight</th>
        <th style="min-width:140px">Risk</th>
      </tr>
    </thead>
    <tbody>
    {% for item in breakdown %}
      <tr>
        <td>{{ item.name }}</td>
        <td style="font-weight:600; color:{{ item.color }}">{{ item.score }}</td>
        <td style="color:var(--muted)">{{ item.weight }}</td>
        <td>
          <div class="risk-bar-bg">
            <div class="risk-bar-fill {{ item.bar_class }}"
                 style="width:{{ item.bar_pct }}%"></div>
          </div>
        </td>
      </tr>
    {% endfor %}
    </tbody>
  </table>
</div>

<!-- pLDDT Plot -->
{% if plddt_plot %}
<div class="card">
  <h2>{{ "Per-Residue pLDDT" if plddt_detected else "Per-Residue B-factors" }}</h2>
  <img class="plot-img" src="data:image/png;base64,{{ plddt_plot }}"
       alt="Per-residue confidence plot">
  {% if plddt_detected %}
  <div style="margin-top:0.5rem; font-size:0.8rem; color:var(--muted)">
    Color bands: <span style="color:#0053D6">■</span> Very high (≥90)
    <span style="color:#65CBF3">■</span> Confident (70–90)
    <span style="color:#FFDB13">■</span> Low (50–70)
    <span style="color:#FF7D45">■</span> Very low (&lt;50)
  </div>
  {% endif %}
</div>
{% endif %}

<!-- RMSD Plot -->
{% if rmsd_plot %}
<div class="card">
  <h2>RMSD Trajectory</h2>
  <img class="plot-img" src="data:image/png;base64,{{ rmsd_plot }}"
       alt="RMSD trajectory plot">
</div>
{% endif %}

<!-- Tool Status -->
<div class="card">
  <h2>Tool Status</h2>
  <table class="tool-table">
    <thead>
      <tr><th>Tool</th><th>Status</th><th>Details</th></tr>
    </thead>
    <tbody>
    {% for tool in tools %}
      <tr>
        <td>{{ tool.name }}</td>
        <td class="{{ tool.status_class }}">{{ tool.status }}</td>
        <td style="color:var(--muted); font-size:0.85rem">{{ tool.detail }}</td>
      </tr>
    {% endfor %}
    </tbody>
  </table>
</div>

<!-- Thresholds -->
<div class="card">
  <h2>Threshold Configuration</h2>
  <div class="config-grid">
  {% for item in thresholds %}
    <div class="config-item">
      <span class="key">{{ item.key }}</span>
      <span class="val">{{ item.value }}</span>
    </div>
  {% endfor %}
  </div>
</div>

<!-- Footer -->
<div class="footer">
  ProtQC v{{ version }} &mdash; Generated {{ timestamp }}<br>
  If you use ProtQC in published work, please cite:<br>
  Güzel, Ö.K. (2026). <em>ProtQC: Physics-based verification of AI-generated protein designs.</em>
  <a href="https://github.com/korayguzel/protqc">github.com/korayguzel/protqc</a>
</div>

</body>
</html>"""


# ---------------------------------------------------------------------------
# Template context builder
# ---------------------------------------------------------------------------

_VERDICT_COLORS = {
    "PASS": "#16A34A",
    "WARNING": "#CA8A04",
    "FAIL": "#DC2626",
}

_THRESHOLD_DISPLAY = [
    ("structure_scorer", "plddt_min", "pLDDT minimum"),
    ("physics_verifier", "md_rmsd_max_angstrom", "MD RMSD max (Å)"),
    ("physics_verifier", "md_rmsd_drift_max_angstrom", "MD RMSD drift max (Å)"),
    ("physics_verifier", "md_duration_ns", "MD duration (ns)"),
    ("cavity", "fpocket_total_volume_max_cubic_angstrom", "Cavity volume max (ų)"),
    ("cavity", "fpocket_volume_per_residue_max", "Cavity vol/residue max (ų/aa)"),
    ("surface", "sasa_polar_ratio_min", "SASA polar ratio min"),
    ("surface", "sasa_polar_ratio_max", "SASA polar ratio max"),
    ("hbond", "persistence_min_pct", "H-bond persistence min (%)"),
    ("secondary_structure", "preservation_min_pct", "SS preservation min (%)"),
    ("verdicts", "pass_threshold", "PASS threshold"),
    ("verdicts", "warn_threshold", "WARNING threshold"),
]


def _build_context(
    result: PipelineResult,
    config: dict[str, Any],
) -> dict[str, Any]:
    """Build the Jinja2 template context from pipeline results."""
    metrics = result["metrics"]
    v = result["verdict"]
    verdict_str = v["verdict"]

    # Risk breakdown table data
    breakdown = []
    for name, score in sorted(v["breakdown"].items(), key=lambda x: -x[1]):
        if score >= 0.6:
            color = _VERDICT_COLORS["FAIL"]
            bar_class = "risk-high"
        elif score >= 0.3:
            color = _VERDICT_COLORS["WARNING"]
            bar_class = "risk-med"
        else:
            color = _VERDICT_COLORS["PASS"]
            bar_class = "risk-low"

        breakdown.append({
            "name": name,
            "score": f"{score:.3f}",
            "weight": f"{v['weights'].get(name, 0):.2f}",
            "color": color,
            "bar_class": bar_class,
            "bar_pct": min(100, max(2, score * 100)),
        })

    # Tool status
    tools = []
    for tr in result["tool_results"]:
        if tr["success"]:
            tools.append({
                "name": tr["tool_name"],
                "status": "OK",
                "status_class": "status-ok",
                "detail": "",
            })
        else:
            tools.append({
                "name": tr["tool_name"],
                "status": "SKIP",
                "status_class": "status-skip",
                "detail": tr["error"] or "unavailable",
            })

    # Threshold config items
    thresholds = []
    for section, key, label in _THRESHOLD_DISPLAY:
        val = config.get(section, {}).get(key)
        if val is not None:
            thresholds.append({"key": label, "value": str(val)})

    # Risk weight entries
    for wk, wv in sorted(config.get("risk_weights", {}).items()):
        thresholds.append({"key": f"Weight: {wk}", "value": f"{wv:.2f}"})

    # Detect experimental PDB (B-factors not pLDDT)
    plddt_detected = metrics.get("plddt_detected", True)
    bfactor_warning = not plddt_detected

    # Plots
    per_residue = metrics.get("plddt_per_residue", [])
    plddt_plot = _plot_plddt(per_residue, plddt_detected)

    rmsd_per_frame = metrics.get("rmsd_per_frame_A", [])
    rmsd_threshold = config.get("physics_verifier", {}).get(
        "md_rmsd_max_angstrom", 3.0
    )
    rmsd_plot = _plot_rmsd(rmsd_per_frame, rmsd_threshold)

    now = datetime.now(timezone.utc)

    return {
        "design_name": result["design_name"],
        "date": now.strftime("%Y-%m-%d"),
        "timestamp": now.strftime("%Y-%m-%d %H:%M UTC"),
        "version": protqc.__version__,
        "verdict": verdict_str,
        "verdict_color": _VERDICT_COLORS.get(verdict_str, "#6B7280"),
        "risk_score": f"{v['risk_score']:.3f}",
        "sequence_length": result.get("sequence_length"),
        "pdb_name": Path(result["pdb_path"]).name,
        "input_mode": result["input_mode"],
        "plddt_mean": metrics.get("plddt_mean"),
        "plddt_detected": plddt_detected,
        "bfactor_warning": bfactor_warning,
        "n_available": len(breakdown),
        "n_total": 6,
        "partial_warning": len(breakdown) < 6,
        "breakdown": breakdown,
        "tools": tools,
        "thresholds": thresholds,
        "plddt_plot": plddt_plot,
        "rmsd_plot": rmsd_plot,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_html_report(
    result: PipelineResult,
    config: dict[str, Any],
    output_path: str | Path,
) -> Path:
    """Generate a self-contained HTML report from pipeline results.

    Args:
        result: Full PipelineResult from run_pipeline().
        config: Configuration dict used for the analysis run.
        output_path: Where to write the HTML file.

    Returns:
        Path to the generated HTML file.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    ctx = _build_context(result, config)

    env = Environment(loader=BaseLoader(), autoescape=True)
    template = env.from_string(_HTML_TEMPLATE)
    html = template.render(**ctx)

    output_path.write_text(html, encoding="utf-8")
    return output_path
