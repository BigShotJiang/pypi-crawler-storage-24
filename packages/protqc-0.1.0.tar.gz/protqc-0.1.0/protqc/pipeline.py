"""
ProtQC Pipeline — orchestrates all verification tools.

Runs each tool sequentially and aggregates metrics into a PipelineResult.

Usage:
    from protqc.pipeline import run_pipeline
    result = run_pipeline("design.pdb", config=config, skip_md=True)
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.scoring import calculate_risk_score
from protqc.tools.fpocket_tool import FpocketAnalyzer
from protqc.tools.freesasa_tool import FreeSASAAnalyzer
from protqc.tools.hbond_tool import HBondAnalyzer
from protqc.tools.openmm_tool import OpenMMSimulator
from protqc.tools.ss_stability_tool import SSStabilityAnalyzer
from protqc.tools.structure_scorer import StructurePredictor
from protqc.types import PipelineResult, ToolResult, VerificationMetrics

logger = logging.getLogger(__name__)


def run_pipeline(
    pdb_path: str | Path,
    config: dict[str, Any] | None = None,
    sequence: str | None = None,
    input_mode: str = "pdb",
    skip_md: bool = False,
    md_duration_ns: float | None = None,
    generate_report: bool = False,
    output_dir: str | Path | None = None,
    trajectory: str | Path | None = None,
    on_stage: Any = None,
) -> PipelineResult:
    """Run the full ProtQC verification pipeline.

    Args:
        pdb_path: Path to input PDB file.
        config: Configuration dict. Loaded from thresholds.yaml if None.
        sequence: Original amino acid sequence (optional metadata).
        input_mode: "pdb", "fasta", or "sequence".
        skip_md: If True, skip OpenMM/hbond/ss_stability (quick local check).
        md_duration_ns: Override MD simulation duration (nanoseconds).
        generate_report: If True, generate LLM report (requires Ollama).
        output_dir: Directory for MD output files.
        trajectory: Path to an existing trajectory file (DCD/XTC). When provided,
                    skip MD simulation but run trajectory analysis tools.
        on_stage: Optional callable(stage_name) -> context manager for progress
                  display. Created by ``progress.create_stage_display()``.

    Returns:
        PipelineResult with all metrics, verdict, and tool results.
    """
    pdb_path = Path(pdb_path)

    if config is None:
        config = load_config()

    @contextmanager
    def _noop(name: str):
        yield

    stage = on_stage or _noop

    tool_results: list[ToolResult] = []
    metrics: dict[str, Any] = {}

    # --- Step 1: Structure scoring (pLDDT from B-factors) ---
    with stage("structure_scorer"):
        scorer = StructurePredictor(config)
        plddt_result = scorer.extract_plddt(pdb_path)
    tool_results.append(plddt_result)
    if plddt_result["success"]:
        metrics.update(plddt_result["metrics"])

    # --- Step 2: Cavity detection (fpocket) ---
    with stage("fpocket"):
        fpocket = FpocketAnalyzer(config)
        fpocket_result = fpocket.analyze(pdb_path)
    tool_results.append(fpocket_result)
    if fpocket_result["success"]:
        metrics.update(fpocket_result["metrics"])

    # --- Step 3: Surface accessibility (FreeSASA) ---
    with stage("freesasa"):
        freesasa = FreeSASAAnalyzer(config)
        sasa_result = freesasa.analyze(pdb_path)
    tool_results.append(sasa_result)
    if sasa_result["success"]:
        metrics.update(sasa_result["metrics"])

    # --- Steps 4-6: MD-dependent tools ---
    trajectory_path: str | None = None
    topology_path: str | None = None

    if trajectory is not None:
        # Use pre-existing trajectory — skip MD simulation, run analysis tools
        with stage("openmm_traj"):
            trajectory_path = str(trajectory)
            topology_path = str(pdb_path)
            logger.info("Using existing trajectory: %s", trajectory_path)

            md = OpenMMSimulator(config)
            traj_file = Path(trajectory_path)
            topo_file = Path(topology_path)
            if traj_file.is_file() and topo_file.is_file():
                try:
                    md_metrics = md._analyze_trajectory(topo_file, traj_file)
                    metrics.update(md_metrics)
                    metrics["trajectory_path"] = trajectory_path
                    metrics["topology_path"] = topology_path
                    tool_results.append(ToolResult(
                        tool_name="openmm",
                        success=True,
                        metrics=md_metrics,
                        error=None,
                    ))
                except Exception as e:
                    logger.warning("Trajectory analysis failed: %s", e)
                    tool_results.append(ToolResult(
                        tool_name="openmm",
                        success=False,
                        metrics={},
                        error=f"Trajectory analysis failed: {e}",
                    ))
            else:
                msg = f"Trajectory or topology file not found: {traj_file}, {topo_file}"
                logger.warning(msg)
                tool_results.append(ToolResult(
                    tool_name="openmm",
                    success=False,
                    metrics={},
                    error=msg,
                ))

    elif not skip_md:
        # Step 4: MD simulation
        with stage("openmm"):
            md = OpenMMSimulator(config)
            md_result = md.simulate(
                pdb_path, output_dir=output_dir, duration_ns=md_duration_ns
            )
        tool_results.append(md_result)
        if md_result["success"]:
            metrics.update(md_result["metrics"])
            trajectory_path = md_result["metrics"].get("trajectory_path")
            topology_path = md_result["metrics"].get("topology_path")

    # Step 5: H-bond persistence (needs trajectory)
    if trajectory_path and topology_path:
        with stage("hbond"):
            hbond = HBondAnalyzer(config)
            hbond_result = hbond.analyze(topology_path, trajectory_path)
        tool_results.append(hbond_result)
        if hbond_result["success"]:
            metrics.update(hbond_result["metrics"])

        # Step 6: Secondary structure stability (needs trajectory)
        with stage("ss_stability"):
            ss = SSStabilityAnalyzer(config)
            ss_result = ss.analyze(topology_path, trajectory_path)
        tool_results.append(ss_result)
        if ss_result["success"]:
            metrics.update(ss_result["metrics"])

    # --- Step 7: Risk assessment ---
    with stage("scoring"):
        verdict = calculate_risk_score(metrics, config)

    # --- Step 9: Report generation (optional) ---
    report: str | None = None
    if generate_report:
        report = _generate_report(metrics, verdict, pdb_path, sequence)

    # Build PipelineResult
    design_name = pdb_path.stem

    # Compute sequence length from pLDDT if available
    seq_length = metrics.get("sequence_length")

    return PipelineResult(
        design_name=design_name,
        sequence=sequence,
        sequence_length=seq_length,
        pdb_path=str(pdb_path),
        input_mode=input_mode,
        metrics=metrics,  # type: ignore[arg-type]
        verdict=verdict,
        tool_results=tool_results,
        report=report,
    )


def _generate_report(
    metrics: dict[str, Any],
    verdict: dict[str, Any],
    pdb_path: Path,
    sequence: str | None,
) -> str | None:
    """Generate an LLM-based report using Ollama via LiteLLM (if available)."""
    try:
        import litellm
    except ImportError:
        logger.warning("litellm not installed, skipping report generation")
        return None

    prompt = (
        "You are ProtQC, an expert protein design verification system.\n"
        "Generate a concise scientific report for the following protein analysis.\n\n"
        f"PDB: {pdb_path.name}\n"
        f"Sequence length: {metrics.get('sequence_length', 'N/A')}\n\n"
        f"=== METRICS ===\n"
        f"pLDDT mean: {metrics.get('plddt_mean', 'N/A')}\n"
        f"Max RMSD: {metrics.get('rmsd_max_A', 'N/A')} A\n"
        f"Cavity volume: {metrics.get('total_volume_A3', 'N/A')} A^3\n"
        f"Polar SASA ratio: {metrics.get('polar_ratio', 'N/A')}\n"
        f"H-bond persistence: {metrics.get('hbond_persistence_pct', 'N/A')}%\n"
        f"SS preservation: {metrics.get('ss_preservation_pct', 'N/A')}%\n\n"
        f"=== VERDICT: {verdict.get('verdict', 'N/A')} "
        f"(Risk: {verdict.get('risk_score', 'N/A')}) ===\n\n"
        "Write:\n1. Summary verdict (1-2 sentences)\n"
        "2. Key concerns with specific metrics\n"
        "3. Recommendations\nKeep under 300 words."
    )

    try:
        response = litellm.completion(
            model="ollama/qwen3:8b",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_tokens=2048,
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.warning("Report generation failed: %s", e)
        return None
