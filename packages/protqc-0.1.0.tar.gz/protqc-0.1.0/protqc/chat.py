"""
ProtQC AI Chat Assistant — natural-language interface for protein analysis.

Uses LiteLLM as a multi-provider LLM gateway with function-calling to invoke
ProtQC tools. The LLM interprets results but never fabricates metrics.

Usage:
    from protqc.chat import run_chat
    run_chat(config)
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

import yaml
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

from protqc.config import load_config

console = Console(stderr=True)

# ---------------------------------------------------------------------------
# A. AI Config Management
# ---------------------------------------------------------------------------

AI_CONFIG_PATH = Path.home() / ".protqc" / "ai_config.yaml"

PROVIDERS: dict[str, dict[str, Any]] = {
    "openai": {
        "default_model": "openai/gpt-4o",
        "env_var": "OPENAI_API_KEY",
    },
    "anthropic": {
        "default_model": "anthropic/claude-sonnet-4-6",
        "env_var": "ANTHROPIC_API_KEY",
    },
    "google": {
        "default_model": "gemini/gemini-2.5-flash",
        "env_var": "GEMINI_API_KEY",
    },
    "deepseek": {
        "default_model": "deepseek/deepseek-chat",
        "env_var": "DEEPSEEK_API_KEY",
    },
    "openrouter": {
        "default_model": "openrouter/deepseek/deepseek-chat",
        "env_var": "OPENROUTER_API_KEY",
    },
    "moonshot": {
        "default_model": "moonshot/kimi-k2.5",
        "env_var": "MOONSHOT_API_KEY",
    },
    "minimax": {
        "default_model": "minimax/MiniMax-M2.1",
        "env_var": "MINIMAX_API_KEY",
    },
    "zhipu": {
        "default_model": "zhipu/glm-4",
        "env_var": "ZHIPU_API_KEY",
    },
}


def load_ai_config() -> dict | None:
    """Load AI configuration from ~/.protqc/ai_config.yaml.

    Returns None if file doesn't exist.
    """
    if not AI_CONFIG_PATH.is_file():
        return None
    with open(AI_CONFIG_PATH) as f:
        return yaml.safe_load(f)


def save_ai_config(config: dict) -> None:
    """Save AI configuration, creating parent directory if needed.

    Sets file permissions to 0o600 (owner read/write only) since
    the file may contain API keys.
    """
    AI_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(AI_CONFIG_PATH, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False)
    AI_CONFIG_PATH.chmod(0o600)


def run_setup_wizard() -> dict:
    """Interactive setup wizard for AI provider configuration.

    Returns:
        Config dict with provider, model, and optionally api_key.
    """
    console.print()
    console.print(Panel(
        "[bold cyan]ProtQC AI Setup[/]\n"
        "Configure your LLM provider for the chat assistant.",
        border_style="cyan",
    ))

    provider_names = list(PROVIDERS.keys())
    console.print()
    for i, name in enumerate(provider_names, 1):
        console.print(f"  {i}. [cyan]{name}[/]")

    console.print()
    choice = Prompt.ask(
        "  Select provider",
        choices=[str(i) for i in range(1, len(provider_names) + 1)],
        default="1",
    )
    provider = provider_names[int(choice) - 1]
    info = PROVIDERS[provider]

    model = Prompt.ask(
        "  Model name",
        default=info["default_model"],
    )

    config: dict[str, Any] = {"provider": provider, "model": model}

    api_key = Prompt.ask("  API key", password=True)
    config["api_key"] = api_key

    save_ai_config(config)
    console.print("  [green]✓[/] Configuration saved.")
    console.print()
    return config


# ---------------------------------------------------------------------------
# B. Function Schemas (OpenAI function-calling format)
# ---------------------------------------------------------------------------

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "analyze",
            "description": (
                "Run the full ProtQC verification pipeline on a protein structure. "
                "Returns metrics and a PASS/WARNING/FAIL verdict."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "pdb_path": {
                        "type": "string",
                        "description": "Path to PDB file or 4-character RCSB PDB ID",
                    },
                    "md_duration": {
                        "type": "number",
                        "description": "MD simulation duration in nanoseconds (default: from config)",
                    },
                    "skip_md": {
                        "type": "boolean",
                        "description": "Skip MD simulation for a quick static-only analysis",
                    },
                },
                "required": ["pdb_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "explain_metric",
            "description": "Explain what a specific ProtQC metric means and how it's scored.",
            "parameters": {
                "type": "object",
                "properties": {
                    "metric_name": {
                        "type": "string",
                        "enum": [
                            "plddt",
                            "md_rmsd",
                            "cavity",
                            "hbond_persistence",
                            "ss_preservation",
                            "sasa_ratio",
                        ],
                        "description": "Name of the metric to explain",
                    },
                },
                "required": ["metric_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "show_config",
            "description": "Show current ProtQC threshold configuration and risk weights.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "fetch_pdb",
            "description": "Download a PDB file from the RCSB database by its 4-character ID.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pdb_id": {
                        "type": "string",
                        "description": "4-character RCSB PDB identifier (e.g. '1UBQ')",
                    },
                },
                "required": ["pdb_id"],
            },
        },
    },
]


# ---------------------------------------------------------------------------
# C. Metric Explanations
# ---------------------------------------------------------------------------

METRIC_EXPLANATIONS: dict[str, str] = {
    "plddt": (
        "**pLDDT (predicted Local Distance Difference Test)**\n\n"
        "Confidence score from structure prediction models (AlphaFold2, ESMFold). "
        "Range: 0-100. Extracted from PDB B-factor columns.\n\n"
        "- >80: High confidence — backbone well-determined\n"
        "- 70-80: Acceptable — minor uncertainty in loops/termini\n"
        "- <70: Low confidence — potential disordered regions or prediction failure\n\n"
        "**ProtQC threshold:** plddt_min = 70 (from config)\n"
        "**Risk weight:** 0.12 — pLDDT alone is a poor stability filter; "
        "AI models can produce high-pLDDT structures that still fail physics checks.\n\n"
        "Reference: Jumper et al. 2021 (Nature)"
    ),
    "md_rmsd": (
        "**MD RMSD (Root Mean Square Deviation from MD simulation)**\n\n"
        "Measures how far the structure drifts from its starting conformation "
        "during molecular dynamics simulation. Units: Angstroms.\n\n"
        "- <2 A: Highly stable — structure maintains fold\n"
        "- 2-3 A: Acceptable — normal thermal fluctuation\n"
        "- >3 A: Unstable — possible partial unfolding or conformational change\n\n"
        "**ProtQC threshold:** md_rmsd_max = 3.0 A\n"
        "**Risk weight:** 0.29 — highest weight; physics-based stability is the "
        "most informative single metric for AI-designed proteins.\n\n"
        "Reference: Lindorff-Larsen et al. 2011; Dauparas et al. 2022"
    ),
    "cavity": (
        "**Cavity Analysis (fpocket)**\n\n"
        "Detects internal voids and pockets. AI-designed proteins sometimes have "
        "large buried cavities that indicate packing defects — these won't appear "
        "in confidence scores but compromise stability.\n\n"
        "ProtQC distinguishes *suspicious* cavities (large volume, low druggability) "
        "from normal binding pockets (high druggability score).\n\n"
        "- Suspicious volume = 0: No structural defects detected\n"
        "- Suspicious volume > 800 A^3: Likely packing defect\n\n"
        "**ProtQC threshold:** volume per residue max = 5.0 A^3/aa\n"
        "**Risk weight:** 0.12\n\n"
        "Reference: Le Guilloux et al. 2009; Schmidtke et al. 2010"
    ),
    "hbond_persistence": (
        "**H-bond Persistence**\n\n"
        "Percentage of backbone hydrogen bonds that persist throughout the MD "
        "trajectory. Backbone H-bonds are the primary stabilizing force of "
        "secondary structure (alpha helices, beta sheets).\n\n"
        "- >80%: Stable backbone network\n"
        "- 70-80%: Acceptable — some dynamic flexibility\n"
        "- <70%: Concerning — potential unfolding or misfolded regions\n\n"
        "**ProtQC threshold:** persistence_min = 70%\n"
        "**Risk weight:** 0.24 — second highest weight; backbone H-bond loss "
        "is a strong unfolding signal.\n\n"
        "Reference: Dauparas et al. 2022; Ferruz et al. 2022"
    ),
    "ss_preservation": (
        "**Secondary Structure Preservation**\n\n"
        "Percentage of DSSP-assigned secondary structure (helix/sheet) that is "
        "maintained from the start to the end of an MD simulation.\n\n"
        "- >85%: Excellent fold stability\n"
        "- 75-85%: Acceptable — minor loop rearrangements\n"
        "- <75%: Partial unfolding — significant helix/sheet loss\n\n"
        "**ProtQC threshold:** preservation_min = 75%\n"
        "**Risk weight:** 0.18\n\n"
        "Reference: Kabsch & Sander 1983; Ferruz et al. 2022"
    ),
    "sasa_ratio": (
        "**Polar SASA Ratio (Solvent Accessible Surface Area)**\n\n"
        "Ratio of polar to total solvent-accessible surface area. Indicates "
        "whether the surface hydrophilicity is appropriate for a soluble protein.\n\n"
        "- 0.55-0.85: Normal range for soluble proteins\n"
        "- <0.55: Too hydrophobic — aggregation risk\n"
        "- >0.85: Too hydrophilic — may not fold stably\n\n"
        "**ProtQC threshold:** 0.55-0.85 (range)\n"
        "**Risk weight:** 0.06 — qualitative indicator, low weight.\n\n"
        "Reference: Miller et al. 1987; Levy 2010"
    ),
}


# ---------------------------------------------------------------------------
# D. Function Handlers
# ---------------------------------------------------------------------------


_MD_DURATION_MIN = 0.1
_MD_DURATION_MAX = 1000.0
_MD_DURATION_DEFAULT = 10.0


def _sanitize_md_duration(raw: Any) -> float | None:
    """Clamp md_duration to a sane range, return None if not provided."""
    if raw is None:
        return None
    try:
        val = float(raw)
    except (TypeError, ValueError):
        return _MD_DURATION_DEFAULT
    if not (val == val):  # NaN check
        return _MD_DURATION_DEFAULT
    return max(_MD_DURATION_MIN, min(_MD_DURATION_MAX, val))


def _handle_analyze(args: dict, config: dict) -> str:
    """Run ProtQC pipeline, generate HTML report, return JSON result."""
    import webbrowser

    from protqc.cli import _resolve_pdb_input
    from protqc.pipeline import run_pipeline
    from protqc.progress import create_stage_display
    from protqc.report import generate_html_report

    pdb_input = args["pdb_path"]
    pdb_path, _is_rcsb = _resolve_pdb_input(pdb_input)

    md_duration = _sanitize_md_duration(args.get("md_duration"))

    result = run_pipeline(
        pdb_path=pdb_path,
        config=config,
        input_mode="pdb",
        skip_md=args.get("skip_md", False),
        md_duration_ns=md_duration,
        on_stage=create_stage_display(console),
    )

    # Generate HTML report
    design_name = result["design_name"]
    html_path = Path(f"/tmp/protqc_{design_name}_report.html")
    html_report_path: str | None = None
    try:
        out_path = generate_html_report(result, config, html_path)
        html_report_path = str(out_path)
        webbrowser.open(out_path.as_uri())
        console.print(f"  [green]✓[/] HTML report: [bold]{out_path}[/]")
    except Exception as e:
        console.print(f"  [yellow]HTML report generation failed: {e}[/]")

    # Serialize to JSON-safe dict
    output = {
        "design_name": design_name,
        "pdb_path": result["pdb_path"],
        "sequence_length": result.get("sequence_length"),
        "html_report": html_report_path,
        "metrics": {
            k: v
            for k, v in result["metrics"].items()
            if not isinstance(v, list) and k != "pdb_path"
        },
        "verdict": {
            "verdict": result["verdict"]["verdict"],
            "risk_score": result["verdict"]["risk_score"],
            "breakdown": result["verdict"]["breakdown"],
            "explanation": result["verdict"]["explanation"],
        },
        "tool_results": [
            {
                "tool_name": tr["tool_name"],
                "success": tr["success"],
                "error": tr["error"],
            }
            for tr in result["tool_results"]
        ],
    }
    return json.dumps(output, indent=2)


def _handle_explain_metric(args: dict) -> str:
    """Return hardcoded scientific explanation for a metric."""
    name = args["metric_name"]
    explanation = METRIC_EXPLANATIONS.get(name)
    if explanation:
        return explanation
    return f"Unknown metric: {name}. Available: {', '.join(METRIC_EXPLANATIONS)}"


def _handle_show_config(args: dict, config: dict) -> str:
    """Format current thresholds config as readable text."""
    lines = ["Current ProtQC Configuration:", ""]

    sections = [
        ("Structure Scoring", "structure_scorer"),
        ("MD Simulation", "physics_verifier"),
        ("Cavity Detection", "cavity"),
        ("Surface Accessibility", "surface"),
        ("H-bond Analysis", "hbond"),
        ("Secondary Structure", "secondary_structure"),
    ]
    for title, key in sections:
        section = config.get(key, {})
        if section:
            lines.append(f"## {title}")
            for k, v in section.items():
                lines.append(f"  {k}: {v}")
            lines.append("")

    weights = config.get("risk_weights", {})
    if weights:
        lines.append("## Risk Weights")
        for k, v in sorted(weights.items(), key=lambda x: -x[1]):
            lines.append(f"  {k}: {v}")
        lines.append("")

    verdicts = config.get("verdicts", {})
    if verdicts:
        lines.append("## Verdict Thresholds")
        lines.append(f"  PASS < {verdicts.get('pass_threshold', '?')}")
        lines.append(f"  WARNING < {verdicts.get('warn_threshold', '?')}")
        lines.append(f"  FAIL >= {verdicts.get('warn_threshold', '?')}")

    return "\n".join(lines)


def _handle_fetch_pdb(args: dict) -> str:
    """Download PDB from RCSB and return path."""
    from protqc.cli import _fetch_rcsb_pdb

    pdb_id = args["pdb_id"]
    path = _fetch_rcsb_pdb(pdb_id)
    return f"Downloaded {pdb_id} to {path}"


FUNCTION_DISPATCH: dict[str, Any] = {
    "analyze": _handle_analyze,
    "explain_metric": _handle_explain_metric,
    "show_config": _handle_show_config,
    "fetch_pdb": _handle_fetch_pdb,
}


# ---------------------------------------------------------------------------
# E. System Prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are ProtQC Assistant, helping researchers verify AI-designed protein structures.

CRITICAL RULES:
- NEVER make claims about protein stability/structure/function from your own knowledge
- ONLY report what ProtQC tools return — cite exact numbers from results
- If a metric was not computed (tool skipped), say "this metric was not computed" — do NOT estimate
- If asked something outside ProtQC's scope, say "this is beyond ProtQC's current capabilities"
- When explaining metrics, use the exact thresholds from config, not your own estimates
- Always distinguish between "ProtQC reports..." and general biology knowledge
- If the user asks you to interpret results differently than the verdict, refuse

MD SIMULATION RULE:
- When the user asks to analyze a protein without specifying skip_md or md_duration, ALWAYS ask before running:
  "Would you like to run MD simulation? Options: (1) Full analysis with 10ns MD (~5-50 min), (2) Quick static check only (~30 seconds), (3) Custom MD duration."
  Do NOT run MD without user confirmation.

Available tools: analyze, explain_metric, show_config, fetch_pdb
"""


# ---------------------------------------------------------------------------
# F. Verdict Verification
# ---------------------------------------------------------------------------

_VERDICT_RE = re.compile(r"\b(PASS|WARNING|FAIL)\b")


def _verify_verdict(llm_response: str, actual_verdict: str) -> str | None:
    """Check if the LLM's response contradicts the actual verdict.

    Scans the response for PASS/WARNING/FAIL keywords and returns a
    correction string if the LLM mentions a different verdict than
    what scoring.py actually returned.

    Returns None if no contradiction detected.
    """
    mentioned = set(_VERDICT_RE.findall(llm_response))

    if not mentioned:
        return None

    # If the actual verdict is mentioned, that's fine — even if others are
    # mentioned for comparison (e.g. "this is a PASS, not a FAIL")
    if actual_verdict in mentioned:
        return None

    # LLM mentioned verdict(s) but not the actual one — contradiction
    wrong = ", ".join(sorted(mentioned))
    return (
        f"[Correction: ProtQC's actual verdict is **{actual_verdict}**. "
        f"The assistant incorrectly mentioned {wrong}. "
        f"Please rely on the actual verdict above.]"
    )


# ---------------------------------------------------------------------------
# G. Chat Loop
# ---------------------------------------------------------------------------

_CHAT_BANNER = (
    "[bold cyan]ProtQC Chat[/] — AI assistant for protein analysis\n\n"
    "  [dim]Commands:[/]  /quit  /settings  /clear\n"
    "  [dim]Example:[/]   analyze tests/fixtures/mini.pdb with skip-md\n"
)


def _build_model_string(ai_config: dict) -> str:
    """Build the LiteLLM model string from provider config.

    If the model already contains a '/' (e.g. 'openai/gpt-4o'), use it
    as-is. Otherwise, prepend the provider name as the LiteLLM prefix.
    """
    provider = ai_config["provider"]
    model = ai_config["model"]
    if "/" in model:
        return model
    return f"{provider}/{model}"


def _set_api_key(ai_config: dict) -> None:
    """Set the appropriate environment variable for the provider's API key."""
    provider = ai_config["provider"]
    info = PROVIDERS.get(provider, {})
    env_var = info.get("env_var")
    api_key = ai_config.get("api_key")
    if env_var and api_key:
        os.environ[env_var] = api_key


def _execute_tool_call(tool_call: Any, config: dict) -> tuple[str, str]:
    """Execute a single tool call and return (function_name, result_string)."""
    fn_name = tool_call.function.name
    try:
        fn_args = json.loads(tool_call.function.arguments)
    except json.JSONDecodeError:
        fn_args = {}

    handler = FUNCTION_DISPATCH.get(fn_name)
    if handler is None:
        return fn_name, f"Unknown function: {fn_name}"

    try:
        # Handlers that need config get it passed
        if fn_name in ("analyze", "show_config"):
            result = handler(fn_args, config)
        else:
            result = handler(fn_args)
    except Exception as e:
        result = f"Error running {fn_name}: {e}"

    return fn_name, result


def _serialize_assistant_msg(msg: Any) -> dict[str, Any]:
    """Serialize an assistant message with tool_calls for the messages list.

    model_dump() can include extra fields (refusal, function_call, audio, etc.)
    that some providers reject on the next request. Build a clean dict with
    only the keys the API expects.
    """
    serialized: dict[str, Any] = {
        "role": "assistant",
        "content": msg.content or "",
    }
    if msg.tool_calls:
        serialized["tool_calls"] = [
            {
                "id": tc.id,
                "type": "function",
                "function": {
                    "name": tc.function.name,
                    "arguments": tc.function.arguments,
                },
            }
            for tc in msg.tool_calls
        ]
    return serialized


def _display_tool_fallback(result: str, tool_names: list[str]) -> None:
    """Display tool execution result when LLM interpretation is unavailable.

    For analyze results, renders a structured summary (verdict, metrics,
    risk breakdown). For other tools, shows the result text directly.
    """
    label = ", ".join(tool_names)

    try:
        parsed = json.loads(result)
    except (json.JSONDecodeError, ValueError):
        # Not JSON — show as plain text
        console.print(Panel(
            result,
            title=f"[bold yellow]{label}[/] [dim](LLM interpretation unavailable)[/]",
            border_style="yellow",
            padding=(1, 2),
        ))
        return

    # Detect analyze pipeline output by checking for verdict + metrics
    if "verdict" in parsed and "metrics" in parsed:
        verdict = parsed["verdict"]
        metrics = parsed.get("metrics", {})
        lines: list[str] = []

        # Header: design name + verdict
        name = parsed.get("design_name", "?")
        seq_len = parsed.get("sequence_length")
        header = f"{name}"
        if seq_len:
            header += f" ({seq_len} residues)"
        lines.append(header)
        lines.append("")

        v_str = verdict.get("verdict", "?")
        risk = verdict.get("risk_score", "?")
        lines.append(f"  Verdict:    {v_str}")
        lines.append(f"  Risk Score: {risk}")
        lines.append("")

        # Key metrics
        metric_labels = [
            ("plddt_mean", "pLDDT mean"),
            ("rmsd_max_A", "RMSD max (A)"),
            ("total_volume_A3", "Cavity volume (A^3)"),
            ("polar_ratio", "Polar SASA ratio"),
            ("hbond_persistence_pct", "H-bond persistence (%)"),
            ("ss_preservation_pct", "SS preservation (%)"),
        ]
        shown_any = False
        for key, display_name in metric_labels:
            val = metrics.get(key)
            if val is not None:
                lines.append(f"  {display_name}: {val}")
                shown_any = True
        if not shown_any:
            lines.append("  (no metrics available)")
        lines.append("")

        # Risk breakdown
        breakdown = verdict.get("breakdown", {})
        if breakdown:
            lines.append("  Risk Breakdown:")
            for k, v in sorted(breakdown.items(), key=lambda x: -float(x[1])):
                try:
                    lines.append(f"    {k}: {float(v):.3f}")
                except (TypeError, ValueError):
                    lines.append(f"    {k}: {v}")

        # Tool status
        tool_results = parsed.get("tool_results", [])
        if tool_results:
            lines.append("")
            for tr in tool_results:
                status = "[green]OK[/green]" if tr.get("success") else f"[red]{tr.get('error', 'failed')}[/red]"
                lines.append(f"  {tr.get('tool_name', '?')}: {status}")

        from rich.text import Text

        console.print(Panel(
            "\n".join(lines),
            title=f"[bold yellow]{label}[/] [dim](LLM interpretation unavailable)[/]",
            border_style="yellow",
            padding=(1, 2),
        ))
    else:
        # Other JSON result — compact pretty-print
        console.print(Panel(
            json.dumps(parsed, indent=2),
            title=f"[bold yellow]{label}[/] [dim](LLM interpretation unavailable)[/]",
            border_style="yellow",
            padding=(1, 2),
        ))


def run_chat(config: dict) -> None:
    """Main chat loop — interactive conversation with LLM + ProtQC tools.

    Args:
        config: ProtQC thresholds configuration dict.
    """
    import litellm

    # Load or create AI config
    ai_config = load_ai_config()
    if ai_config is None:
        ai_config = run_setup_wizard()

    _set_api_key(ai_config)
    model = _build_model_string(ai_config)

    # Initialize conversation
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
    ]

    console.print()
    console.print(Panel(_CHAT_BANNER, border_style="cyan"))

    last_actual_verdict: str | None = None

    while True:
        try:
            user_input = Prompt.ask("[bold cyan]you[/]")
        except (EOFError, KeyboardInterrupt):
            console.print("\n  [dim]Goodbye.[/]")
            break

        user_input = user_input.strip()
        if not user_input:
            continue

        # Slash commands
        if user_input in ("/quit", "/exit", "/q"):
            console.print("  [dim]Goodbye.[/]")
            break
        if user_input == "/settings":
            ai_config = run_setup_wizard()
            _set_api_key(ai_config)
            model = _build_model_string(ai_config)
            continue
        if user_input == "/clear":
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            last_actual_verdict = None
            console.print("  [dim]Conversation cleared.[/]")
            continue

        messages.append({"role": "user", "content": user_input})

        # LLM call with tool schemas
        try:
            response = litellm.completion(
                model=model,
                messages=messages,
                tools=TOOL_SCHEMAS,
                max_tokens=1024,
            )
        except Exception as e:
            console.print(f"  [red]LLM error: {e}[/]")
            messages.pop()  # Remove failed user message
            continue

        choice = response.choices[0]
        assistant_msg = choice.message

        # Process tool calls — loop handles chained calls (LLM may call
        # tools multiple rounds, e.g. analyze → explain_metric)
        tool_calls_made: list[str] = []
        last_tool_result: str | None = None
        max_tool_rounds = 5
        follow_up_failed = False

        for _round in range(max_tool_rounds):
            if not assistant_msg.tool_calls:
                break

            # Append the assistant message that requested tool calls
            messages.append(_serialize_assistant_msg(assistant_msg))

            for tool_call in assistant_msg.tool_calls:
                fn_name, result = _execute_tool_call(tool_call, config)
                tool_calls_made.append(fn_name)
                last_tool_result = result

                # Extract actual verdict if analyze was called
                if fn_name == "analyze":
                    try:
                        parsed = json.loads(result)
                        last_actual_verdict = parsed.get("verdict", {}).get("verdict")
                    except (json.JSONDecodeError, AttributeError):
                        pass

                console.print(f"  [dim]⚙ {fn_name}[/]")

                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result,
                })

            # Follow-up LLM call to interpret tool results
            try:
                response = litellm.completion(
                    model=model,
                    messages=messages,
                    tools=TOOL_SCHEMAS,
                    max_tokens=1024,
                )
                choice = response.choices[0]
                assistant_msg = choice.message
            except Exception as e:
                console.print(f"  [red]LLM follow-up error: {e}[/]")
                follow_up_failed = True
                break

        # Display assistant response
        content = assistant_msg.content if not follow_up_failed else None

        if content:
            messages.append({"role": "assistant", "content": content})
            console.print()
            console.print(Panel(
                Markdown(content),
                title="[bold cyan]ProtQC Assistant[/]",
                border_style="cyan",
                padding=(1, 2),
            ))

            # Verdict verification after analyze
            if "analyze" in tool_calls_made and last_actual_verdict:
                correction = _verify_verdict(content, last_actual_verdict)
                if correction:
                    console.print(f"  [bold red]{correction}[/]")
                    messages.append({"role": "system", "content": correction})

        elif tool_calls_made and last_tool_result is not None:
            # Fallback: LLM returned no content (or follow-up failed)
            # but the tool ran successfully — show the raw result
            console.print()
            _display_tool_fallback(last_tool_result, tool_calls_made)
            messages.append({
                "role": "assistant",
                "content": f"[Tool result displayed directly — LLM interpretation unavailable]",
            })
