"""
Shared stderr suppression for MDTraj's dcdplugin C-level noise.

MDTraj's DCD reader prints informational messages via a C plugin that writes
directly to file descriptor 2, bypassing Python's sys.stderr. The only way
to suppress it is to redirect the OS-level file descriptor.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Iterator


@contextmanager
def suppress_stderr() -> Iterator[None]:
    """Temporarily redirect fd 2 to /dev/null.

    This suppresses C-level writes (like MDTraj's dcdplugin) that bypass
    Python's sys.stderr. Safe to nest and always restores the original fd.
    """
    devnull_fd = os.open(os.devnull, os.O_WRONLY)
    saved_fd = os.dup(2)
    try:
        os.dup2(devnull_fd, 2)
        yield
    finally:
        os.dup2(saved_fd, 2)
        os.close(devnull_fd)
        os.close(saved_fd)
