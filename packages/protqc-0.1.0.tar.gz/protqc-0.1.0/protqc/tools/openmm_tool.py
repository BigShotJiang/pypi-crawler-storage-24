"""
OpenMM Tool — short MD simulation + MDTraj trajectory analysis.

Runs a short (default 10 ns) molecular dynamics simulation to check whether
an AI-generated protein structure remains stable under physical forces.
Large backbone RMSD or drift indicates the structure may collapse in water.

Requires: conda install -c conda-forge openmm && pip install mdtraj
GPU recommended (Colab T4 sufficient), CPU works but is much slower.
"""

from __future__ import annotations

import tempfile
import warnings
from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.types import ToolResult

warnings.filterwarnings("ignore", category=DeprecationWarning)

try:
    import openmm
    import openmm
    from openmm import CustomExternalForce, LangevinMiddleIntegrator, MonteCarloBarostat, Platform
    from openmm.app import (
        DCDReporter,
        ForceField,
        HBonds,
        Modeller,
        PDBFile,
        PME,
        Simulation,
        StateDataReporter,
    )
    from openmm.unit import (
        atmosphere,
        femtoseconds,
        kelvin,
        molar,
        nanometers,
        picosecond,
        picoseconds,
    )

    OPENMM_AVAILABLE = True
except ImportError:
    OPENMM_AVAILABLE = False

try:
    import mdtraj
    import numpy as np

    MDTRAJ_AVAILABLE = True
except ImportError:
    MDTRAJ_AVAILABLE = False

try:
    from pdbfixer import PDBFixer

    PDBFIXER_AVAILABLE = True
except ImportError:
    PDBFIXER_AVAILABLE = False


class OpenMMSimulator:
    """Run short MD simulation and analyze trajectory for structural stability."""

    TOOL_NAME = "openmm_md"

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            try:
                config = load_config()
            except Exception:
                config = {}
        self.config = config
        phys_cfg = config.get("physics_verifier", {})
        self.duration_ns = phys_cfg.get("md_duration_ns", 10)
        self.rmsd_max_threshold = phys_cfg.get("md_rmsd_max_angstrom", 5.0)
        self.rmsd_drift_threshold = phys_cfg.get("md_rmsd_drift_max_angstrom", 3.0)
        self.rmsf_core_threshold = phys_cfg.get("md_rmsf_core_max_angstrom", 2.0)

    def simulate(
        self,
        pdb_path: str | Path,
        output_dir: str | Path | None = None,
        duration_ns: float | None = None,
        temperature_k: float = 300.0,
        save_interval_ps: float = 10.0,
    ) -> ToolResult:
        """Run MD simulation and return trajectory analysis metrics.

        Args:
            pdb_path: Path to input PDB file.
            output_dir: Directory for output files. Uses temp dir if None.
            duration_ns: Override simulation duration (nanoseconds).
            temperature_k: Temperature in Kelvin.
            save_interval_ps: Frame save interval in picoseconds.

        Returns:
            ToolResult with RMSD/RMSF metrics and trajectory paths.
        """
        import time

        pdb_path = Path(pdb_path)

        if not OPENMM_AVAILABLE:
            return self._error(
                "OpenMM not installed. "
                "Install with: conda install -c conda-forge openmm"
            )

        if not MDTRAJ_AVAILABLE:
            return self._error(
                "MDTraj not installed. Install with: pip install mdtraj"
            )

        if not pdb_path.exists():
            return self._error(f"PDB file not found: {pdb_path}")

        if not pdb_path.is_file():
            return self._error(f"Path is not a file: {pdb_path}")

        ns = duration_ns if duration_ns is not None else self.duration_ns

        # Set up output directory
        cleanup_dir = False
        if output_dir is None:
            output_dir = Path(tempfile.mkdtemp(prefix="protqc_md_"))
            cleanup_dir = False  # keep for downstream tools
        else:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

        traj_path = output_dir / "trajectory.dcd"
        log_path = output_dir / "md_log.csv"
        topology_path = output_dir / "topology.pdb"

        try:
            # MD protocol based on:
            # - Gill et al. 2019 PEDS (CHARMM36m/TIP3P, NPT, 150mM KCl, 5x100ns)
            # - Barros et al. 2019 JCTC (OpenMM, explicit solvent, 500-1000ns)
            # Adapted for rapid pre-screening: Amber14SB/TIP3P, NPT, 150mM NaCl,
            # 10ns default with 4-stage equilibration.
            start_time = time.time()

            # Load and prepare PDB — fix missing atoms/termini
            # ColabFold/AlphaFold2 PDBs lack proper chain termini,
            # causing ForceField template matching to fail.
            topology, positions = self._prepare_structure(pdb_path)

            # Force field — standard TIP3P (literature consensus)
            forcefield = ForceField("amber14-all.xml", "amber14/tip3p.xml")

            # Prepare model: add hydrogens and solvent (1.2nm padding)
            modeller = Modeller(topology, positions)
            modeller.addHydrogens(forcefield)
            modeller.addSolvent(
                forcefield,
                padding=1.2 * nanometers,
                ionicStrength=0.15 * molar,
            )

            # Save solvated topology for MDTraj
            PDBFile.writeFile(
                modeller.topology, modeller.positions, open(str(topology_path), "w")
            )

            # Create system
            system = forcefield.createSystem(
                modeller.topology,
                nonbondedMethod=PME,
                nonbondedCutoff=1.0 * nanometers,
                constraints=HBonds,
            )

            # NPT barostat (1 atm, coupled every 25 steps)
            system.addForce(
                MonteCarloBarostat(1.0 * atmosphere, temperature_k * kelvin, 25)
            )

            # Backbone restraint force for equilibration stages
            restraint_force = CustomExternalForce(
                "k*periodicdistance(x, y, z, x0, y0, z0)^2"
            )
            restraint_force.addGlobalParameter(
                "k", 5.0 * 4.184 * 100  # 5 kcal/mol/A^2 in kJ/mol/nm^2
            )
            restraint_force.addPerParticleParameter("x0")
            restraint_force.addPerParticleParameter("y0")
            restraint_force.addPerParticleParameter("z0")
            for atom in modeller.topology.atoms():
                if atom.name in ("CA", "C", "N", "O") and atom.residue.name != "HOH":
                    pos = modeller.positions[atom.index]
                    restraint_force.addParticle(
                        atom.index, [pos.x, pos.y, pos.z]
                    )
            system.addForce(restraint_force)

            # Integrator
            integrator = LangevinMiddleIntegrator(
                temperature_k * kelvin,
                1.0 / picosecond,
                2.0 * femtoseconds,
            )

            # Platform selection
            platform = self._select_platform()

            # Simulation
            simulation = Simulation(
                modeller.topology, system, integrator, platform
            )
            simulation.context.setPositions(modeller.positions)

            # === Stage 1: Energy minimization (5000 steps) ===
            simulation.minimizeEnergy(maxIterations=5000)

            # === Stage 2: NVT heating with backbone restraints (50 ps) ===
            simulation.step(25000)  # 50 ps at 2 fs/step

            # === Stage 3: NPT equilibration with backbone restraints (100 ps) ===
            simulation.step(50000)  # 100 ps at 2 fs/step

            # === Stage 4: NPT unrestrained equilibration (200 ps) ===
            simulation.context.setParameter("k", 0.0)
            simulation.step(100000)  # 200 ps at 2 fs/step

            # === Production run ===
            timestep_ps = 0.002  # 2 fs
            save_interval_steps = int(save_interval_ps / timestep_ps)
            n_steps = int(ns * 1e3 / timestep_ps)  # ns→ps is *1e3
            n_frames = n_steps // save_interval_steps

            simulation.reporters.append(
                DCDReporter(str(traj_path), save_interval_steps)
            )
            simulation.reporters.append(
                StateDataReporter(
                    str(log_path),
                    save_interval_steps,
                    step=True,
                    potentialEnergy=True,
                    temperature=True,
                    speed=True,
                    totalSteps=n_steps,
                )
            )

            # Run production
            simulation.step(n_steps)

            wall_time = (time.time() - start_time) / 60

        except Exception as e:
            return self._error(f"MD simulation failed: {e}")

        # Analyze trajectory
        try:
            analysis = self._analyze_trajectory(topology_path, traj_path)
        except Exception as e:
            return self._error(f"Trajectory analysis failed: {e}")

        metrics: dict[str, Any] = {
            **analysis,
            "trajectory_path": str(traj_path),
            "topology_path": str(topology_path),
            "log_path": str(log_path),
            "n_frames": n_frames,
            "duration_ns": ns,
            "wall_time_minutes": round(wall_time, 1),
            "platform": platform.getName(),
            "pdb_path": str(pdb_path),
        }

        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=True,
            metrics=metrics,
            error=None,
        )

    def _prepare_structure(self, pdb_path: Path):
        """Prepare PDB structure for simulation, fixing missing atoms/termini.

        Uses PDBFixer when available to repair AI-predicted structures
        (e.g. ColabFold/AlphaFold2) that lack proper chain termini.
        Falls back to raw PDB loading if PDBFixer is not installed.

        Returns:
            Tuple of (topology, positions) ready for Modeller.
        """
        if PDBFIXER_AVAILABLE:
            fixer = PDBFixer(filename=str(pdb_path))
            fixer.findMissingResidues()
            fixer.findMissingAtoms()
            fixer.addMissingAtoms()
            fixer.addMissingHydrogens(7.0)
            return fixer.topology, fixer.positions
        else:
            pdb = PDBFile(str(pdb_path))
            return pdb.topology, pdb.positions

    def _select_platform(self) -> "Platform":
        """Select best available OpenMM platform."""
        for name in ("CUDA", "OpenCL", "CPU"):
            try:
                return Platform.getPlatformByName(name)
            except Exception:
                continue
        return Platform.getPlatformByName("Reference")

    def _analyze_trajectory(
        self, topology_path: Path, trajectory_path: Path
    ) -> dict[str, Any]:
        """Analyze MD trajectory for RMSD and RMSF metrics."""
        from protqc.tools._suppress import suppress_stderr

        with suppress_stderr():
            traj = mdtraj.load(str(trajectory_path), top=str(topology_path))

        # Backbone RMSD relative to first frame
        backbone = traj.topology.select("backbone")
        rmsd_nm = mdtraj.rmsd(traj, traj, frame=0, atom_indices=backbone)
        rmsd_A = rmsd_nm * 10.0  # nm -> Angstrom

        # RMSF per backbone atom
        rmsf_nm = mdtraj.rmsf(traj, traj, frame=0, atom_indices=backbone)
        rmsf_A = rmsf_nm * 10.0

        return {
            "rmsd_mean_A": round(float(np.mean(rmsd_A)), 2),
            "rmsd_max_A": round(float(np.max(rmsd_A)), 2),
            "rmsd_final_A": round(float(rmsd_A[-1]), 2),
            "rmsd_drift_A": round(float(rmsd_A[-1] - rmsd_A[0]), 2),
            "rmsd_per_frame_A": [round(float(v), 3) for v in rmsd_A],
            "rmsf_mean_A": round(float(np.mean(rmsf_A)), 2),
            "rmsf_max_A": round(float(np.max(rmsf_A)), 2),
            "n_flexible_residues": int(np.sum(rmsf_A > self.rmsf_core_threshold)),
            "md_stable": (
                float(np.max(rmsd_A)) < self.rmsd_max_threshold
                and float(rmsd_A[-1] - rmsd_A[0]) < self.rmsd_drift_threshold
            ),
        }

    def _error(self, message: str) -> ToolResult:
        """Create a failure ToolResult with the given error message."""
        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=False,
            metrics={},
            error=message,
        )
