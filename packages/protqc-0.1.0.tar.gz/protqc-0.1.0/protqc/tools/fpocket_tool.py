"""
fpocket Tool — protein cavity/pocket detection via subprocess.

fpocket detects internal cavities that may indicate structural hallucinations:
AI models sometimes generate cavities that would not exist in a stable fold.

Requires: fpocket binary (conda install -c conda-forge fpocket)
"""

from __future__ import annotations

import re
import shutil
import tempfile
from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.types import ToolResult

FPOCKET_AVAILABLE = shutil.which("fpocket") is not None


class FpocketAnalyzer:
    """Detect internal cavities using the fpocket binary.

    fpocket writes output files next to the input PDB, so we copy the
    PDB to a temp directory before running to avoid polluting the
    source directory.
    """

    TOOL_NAME = "fpocket"

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            try:
                config = load_config()
            except Exception:
                config = {}
        self.config = config
        cavity_cfg = config.get("cavity", {})
        self.volume_max = cavity_cfg.get(
            "fpocket_total_volume_max_cubic_angstrom", 200
        )
        self.druggability_min = cavity_cfg.get("fpocket_druggability_min", 0.0)
        # Filter thresholds: pocket must meet at least one to be "significant"
        self.score_min_filter = cavity_cfg.get("fpocket_score_min_filter", 0.2)
        self.druggability_min_filter = cavity_cfg.get(
            "fpocket_druggability_min_filter", 0.1
        )
        # Suspicious cavity detection (literature: buried void > 800 ų with
        # druggability < 0.4 indicates structural defect, not functional pocket)
        self.suspicious_volume_min = cavity_cfg.get(
            "fpocket_suspicious_volume_min", 800
        )
        self.suspicious_druggability_max = cavity_cfg.get(
            "fpocket_suspicious_druggability_max", 0.4
        )

    def analyze(self, pdb_path: str | Path) -> ToolResult:
        """Run fpocket on a PDB file and parse cavity metrics.

        Args:
            pdb_path: Path to a PDB file.

        Returns:
            ToolResult with cavity metrics or error.
        """
        import subprocess

        pdb_path = Path(pdb_path)

        if not FPOCKET_AVAILABLE:
            return self._error(
                "fpocket binary not found. "
                "Install with: conda install -c conda-forge fpocket"
            )

        if not pdb_path.exists():
            return self._error(f"PDB file not found: {pdb_path}")

        if not pdb_path.is_file():
            return self._error(f"Path is not a file: {pdb_path}")

        # Copy PDB to temp dir (fpocket writes output next to input)
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_pdb = Path(tmp_dir) / pdb_path.name
            shutil.copy2(pdb_path, tmp_pdb)

            try:
                result = subprocess.run(
                    ["fpocket", "-f", str(tmp_pdb)],
                    capture_output=True,
                    text=True,
                    timeout=120,
                    cwd=tmp_dir,
                )
            except subprocess.TimeoutExpired:
                return self._error("fpocket timed out after 120 seconds")
            except Exception as e:
                return self._error(f"fpocket execution failed: {e}")

            if result.returncode != 0:
                return self._error(
                    f"fpocket returned exit code {result.returncode}: "
                    f"{result.stderr.strip()}"
                )

            # Parse output
            stem = tmp_pdb.stem
            info_path = Path(tmp_dir) / f"{stem}_out" / f"{stem}_info.txt"
            pockets = self._parse_info_txt(info_path)

        # Raw totals (all pockets including shallow surface clefts)
        volumes = [p.get("volume", 0.0) for p in pockets]
        total_volume = sum(volumes)
        max_volume = max(volumes) if volumes else 0.0

        # Filtered: only significant pockets (druggability OR score above threshold)
        filtered = [
            p for p in pockets
            if p.get("druggability", 0.0) > self.druggability_min_filter
            or p.get("score", 0.0) > self.score_min_filter
        ]
        filtered_volumes = [p.get("volume", 0.0) for p in filtered]
        filtered_volume = sum(filtered_volumes)
        filtered_max = max(filtered_volumes) if filtered_volumes else 0.0

        # Suspicious cavities: large buried voids with low druggability
        # (literature: volume > 800 ų AND druggability < 0.4)
        suspicious = [
            p for p in pockets
            if p.get("volume", 0.0) >= self.suspicious_volume_min
            and p.get("druggability", 1.0) < self.suspicious_druggability_max
        ]
        suspicious_volumes = [p.get("volume", 0.0) for p in suspicious]
        suspicious_volume = sum(suspicious_volumes)

        metrics: dict[str, Any] = {
            # Raw (all pockets)
            "num_pockets": len(pockets),
            "total_volume_A3": round(total_volume, 2),
            "max_pocket_volume_A3": round(max_volume, 2),
            # Filtered (significant pockets only)
            "filtered_count": len(filtered),
            "filtered_volume_A3": round(filtered_volume, 2),
            "filtered_max_pocket_volume_A3": round(filtered_max, 2),
            "cavity_flag": filtered_volume > self.volume_max,
            # Suspicious cavities (large buried voids, likely structural defects)
            "suspicious_cavity_count": len(suspicious),
            "suspicious_volume_A3": round(suspicious_volume, 2),
            "suspicious_cavity_flag": len(suspicious) > 0,
            "pockets": pockets,
            "pdb_path": str(pdb_path),
        }

        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=True,
            metrics=metrics,
            error=None,
        )

    def _parse_info_txt(self, info_path: Path) -> list[dict[str, Any]]:
        """Parse fpocket info.txt for pocket volumes and scores."""
        if not info_path.exists():
            return []

        try:
            content = info_path.read_text(errors="replace")
        except Exception:
            return []

        pockets: list[dict[str, Any]] = []
        # Split on "Pocket" headers
        blocks = re.split(r"Pocket\s+\d+\s*:", content)
        for block in blocks[1:]:  # skip preamble before first Pocket
            pocket: dict[str, Any] = {}

            vol_match = re.search(
                r"Volume\s*(?:\(Monte Carlo\))?\s*:\s*([\d.]+)", block
            )
            if vol_match:
                pocket["volume"] = float(vol_match.group(1))

            score_match = re.search(r"^\s*Score\s*:\s*([\d.]+)", block, re.MULTILINE)
            if score_match:
                pocket["score"] = float(score_match.group(1))

            drug_match = re.search(r"Druggability Score\s*:\s*([\d.]+)", block)
            if drug_match:
                pocket["druggability"] = float(drug_match.group(1))

            if pocket:
                pockets.append(pocket)

        return pockets

    def _error(self, message: str) -> ToolResult:
        """Create a failure ToolResult with the given error message."""
        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=False,
            metrics={},
            error=message,
        )
