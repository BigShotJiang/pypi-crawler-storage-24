"""
Structure Scorer — extracts pLDDT confidence from PDB B-factor columns.

ColabFold and ESMFold both store per-residue pLDDT (0-100) in the B-factor
field of output PDB files. This tool reads those values without running
any prediction model.

Primary backend: ColabFold AlphaFold2 (user runs notebook separately)
Optional backend: ESMFold API (for quick sequence-based checks)
"""

from __future__ import annotations

import statistics
from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.types import ToolResult


class StructurePredictor:
    """Extracts pLDDT confidence scores from structure prediction PDB output.

    Does NOT run structure prediction itself. The user runs ColabFold
    (or ESMFold) separately and provides the output PDB file.
    """

    TOOL_NAME = "structure_scorer"

    # pLDDT values are in 0-100 range. Crystallographic B-factors
    # can exceed 100 (they represent thermal displacement in ų).
    PLDDT_MAX = 100.0
    LOW_CONFIDENCE_THRESHOLD = 50.0
    HIGH_CONFIDENCE_THRESHOLD = 70.0

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            try:
                config = load_config()
            except Exception:
                config = {}
        self.config = config
        scorer_cfg = config.get("structure_scorer", {})
        self.plddt_min_threshold = scorer_cfg.get("plddt_min", 0.70)

    def extract_plddt(self, pdb_path: str | Path) -> ToolResult:
        """Extract per-residue pLDDT from PDB B-factor column.

        Reads CA (alpha-carbon) atoms from ATOM records. Falls back to
        all ATOM records grouped by residue if no CA atoms are found.

        Args:
            pdb_path: Path to a PDB file from ColabFold, ESMFold, or
                      any tool that stores pLDDT in B-factors.

        Returns:
            ToolResult with metrics including plddt_mean, plddt_per_residue, etc.
            On failure, returns ToolResult with success=False and error message.
        """
        pdb_path = Path(pdb_path)

        # --- Input validation ---
        if not pdb_path.exists():
            return self._error(f"PDB file not found: {pdb_path}")

        if not pdb_path.is_file():
            return self._error(f"Path is not a file: {pdb_path}")

        try:
            content = pdb_path.read_text(errors="replace")
        except Exception as e:
            return self._error(f"Could not read PDB file: {e}")

        if not content.strip():
            return self._error(f"PDB file is empty: {pdb_path}")

        # --- Parse ATOM records ---
        ca_bfactors: list[tuple[int, float]] = []  # (residue_seq, bfactor)
        all_bfactors: dict[int, list[float]] = {}  # residue_seq -> [bfactors]

        for line in content.splitlines():
            if not (line.startswith("ATOM  ") or line.startswith("HETATM")):
                continue

            if len(line) < 66:
                continue

            try:
                atom_name = line[12:16].strip()
                res_seq = int(line[22:26].strip())
                bfactor = float(line[60:66].strip())
            except (ValueError, IndexError):
                continue

            # Collect all atoms by residue
            if res_seq not in all_bfactors:
                all_bfactors[res_seq] = []
            all_bfactors[res_seq].append(bfactor)

            # Collect CA atoms specifically
            if atom_name == "CA":
                ca_bfactors.append((res_seq, bfactor))

        if not all_bfactors:
            return self._error(
                f"No ATOM records found in PDB file: {pdb_path}"
            )

        # Prefer CA atoms (one per residue); fall back to per-residue mean
        if ca_bfactors:
            # Sort by residue sequence number
            ca_bfactors.sort(key=lambda x: x[0])
            per_residue = [bf for _, bf in ca_bfactors]
        else:
            # No CA atoms — compute mean B-factor per residue
            sorted_residues = sorted(all_bfactors.keys())
            per_residue = [
                statistics.mean(all_bfactors[r]) for r in sorted_residues
            ]

        # --- Detect whether B-factors look like pLDDT ---
        # pLDDT: 0-100 scale. Crystallographic B-factors can exceed 100.
        max_bfactor = max(per_residue)
        min_bfactor = min(per_residue)
        plddt_detected = max_bfactor <= self.PLDDT_MAX and min_bfactor >= 0.0

        # --- Compute summary statistics ---
        n_residues = len(per_residue)
        mean_plddt = statistics.mean(per_residue)
        median_plddt = statistics.median(per_residue)
        min_plddt = min(per_residue)
        max_plddt = max(per_residue)
        low_conf = sum(
            1 for v in per_residue if v < self.LOW_CONFIDENCE_THRESHOLD
        )
        high_conf_pct = (
            sum(1 for v in per_residue if v > self.HIGH_CONFIDENCE_THRESHOLD)
            / n_residues
            * 100.0
        )

        metrics: dict[str, Any] = {
            "plddt_mean": round(mean_plddt, 2),
            "plddt_median": round(median_plddt, 2),
            "plddt_min": round(min_plddt, 2),
            "plddt_max": round(max_plddt, 2),
            "plddt_per_residue": [round(v, 2) for v in per_residue],
            "sequence_length": n_residues,
            "low_confidence_residues": low_conf,
            "high_confidence_pct": round(high_conf_pct, 1),
            "plddt_detected": plddt_detected,
            "pdb_path": str(pdb_path),
        }

        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=True,
            metrics=metrics,
            error=None,
        )

    def _error(self, message: str) -> ToolResult:
        """Create a failure ToolResult with the given error message."""
        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=False,
            metrics={},
            error=message,
        )
