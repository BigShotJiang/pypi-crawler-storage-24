"""
H-Bond Persistence Tool — MDTraj baker_hubbard analysis.

Low H-bond persistence across an MD trajectory indicates the protein's
hydrogen bond network is unstable and may dissolve in solution.

Requires: pip install mdtraj
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.types import ToolResult

try:
    import mdtraj
    import numpy as np

    MDTRAJ_AVAILABLE = True
except ImportError:
    MDTRAJ_AVAILABLE = False


class HBondAnalyzer:
    """Analyze H-bond persistence across an MD trajectory."""

    TOOL_NAME = "hbond"

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            try:
                config = load_config()
            except Exception:
                config = {}
        self.config = config
        hbond_cfg = config.get("hbond", {})
        self.persistence_min_pct = hbond_cfg.get("persistence_min_pct", 60)

    def analyze(
        self,
        topology_path: str | Path,
        trajectory_path: str | Path,
    ) -> ToolResult:
        """Compute H-bond persistence between first and last trajectory frames.

        Args:
            topology_path: Path to topology PDB file.
            trajectory_path: Path to trajectory DCD file.

        Returns:
            ToolResult with H-bond persistence metrics.
        """
        topology_path = Path(topology_path)
        trajectory_path = Path(trajectory_path)

        if not MDTRAJ_AVAILABLE:
            return self._error(
                "MDTraj not installed. Install with: pip install mdtraj"
            )

        if not topology_path.exists():
            return self._error(f"Topology file not found: {topology_path}")

        if not trajectory_path.exists():
            return self._error(f"Trajectory file not found: {trajectory_path}")

        try:
            from protqc.tools._suppress import suppress_stderr

            with suppress_stderr():
                traj = mdtraj.load(str(trajectory_path), top=str(topology_path))
        except Exception as e:
            return self._error(f"Failed to load trajectory: {e}")

        if traj.n_frames < 2:
            return self._error("Trajectory has fewer than 2 frames")

        try:
            # H-bonds in first and last frames
            hbonds_first = mdtraj.baker_hubbard(traj[0], freq=0.0)
            hbonds_last = mdtraj.baker_hubbard(traj[-1], freq=0.0)

            # Sample frames for mean count
            n_samples = min(50, traj.n_frames)
            sample_indices = np.linspace(
                0, traj.n_frames - 1, n_samples
            ).astype(int)
            counts = []
            for idx in sample_indices:
                hb = mdtraj.baker_hubbard(traj[idx], freq=0.0)
                counts.append(len(hb))

            # Persistence: H-bonds present in first frame that survive to last
            set_first = set(map(tuple, hbonds_first))
            set_last = set(map(tuple, hbonds_last))
            if len(set_first) > 0:
                persistence = len(set_first & set_last) / len(set_first) * 100
            else:
                persistence = 0.0

        except Exception as e:
            return self._error(f"H-bond analysis failed: {e}")

        metrics: dict[str, Any] = {
            "hbond_initial_count": len(hbonds_first),
            "hbond_final_count": len(hbonds_last),
            "hbond_persistence_pct": round(persistence, 1),
            "hbond_mean_count": round(float(np.mean(counts)), 1),
            "hbond_stable": persistence >= self.persistence_min_pct,
        }

        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=True,
            metrics=metrics,
            error=None,
        )

    def _error(self, message: str) -> ToolResult:
        """Create a failure ToolResult with the given error message."""
        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=False,
            metrics={},
            error=message,
        )
