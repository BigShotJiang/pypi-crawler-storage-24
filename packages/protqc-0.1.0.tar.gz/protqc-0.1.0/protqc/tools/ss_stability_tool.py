"""
Secondary Structure Stability Tool — MDTraj DSSP analysis.

Compares DSSP secondary structure assignments between the first and last
frames of an MD trajectory. Loss of helix/sheet content indicates the
designed fold may not be stable.

Requires: pip install mdtraj
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.types import ToolResult

try:
    import mdtraj
    import numpy as np

    MDTRAJ_AVAILABLE = True
except ImportError:
    MDTRAJ_AVAILABLE = False


class SSStabilityAnalyzer:
    """Analyze secondary structure preservation across an MD trajectory."""

    TOOL_NAME = "ss_stability"

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            try:
                config = load_config()
            except Exception:
                config = {}
        self.config = config
        ss_cfg = config.get("secondary_structure", {})
        self.preservation_min_pct = ss_cfg.get("preservation_min_pct", 70)

    def analyze(
        self,
        topology_path: str | Path,
        trajectory_path: str | Path,
    ) -> ToolResult:
        """Compare DSSP assignments between first and last trajectory frames.

        Args:
            topology_path: Path to topology PDB file.
            trajectory_path: Path to trajectory DCD file.

        Returns:
            ToolResult with secondary structure preservation metrics.
        """
        topology_path = Path(topology_path)
        trajectory_path = Path(trajectory_path)

        if not MDTRAJ_AVAILABLE:
            return self._error(
                "MDTraj not installed. Install with: pip install mdtraj"
            )

        if not topology_path.exists():
            return self._error(f"Topology file not found: {topology_path}")

        if not trajectory_path.exists():
            return self._error(f"Trajectory file not found: {trajectory_path}")

        try:
            from protqc.tools._suppress import suppress_stderr

            with suppress_stderr():
                traj = mdtraj.load(str(trajectory_path), top=str(topology_path))
        except Exception as e:
            return self._error(f"Failed to load trajectory: {e}")

        if traj.n_frames < 2:
            return self._error("Trajectory has fewer than 2 frames")

        try:
            ss_initial = mdtraj.compute_dssp(traj[0])[0]
            ss_final = mdtraj.compute_dssp(traj[-1])[0]
        except Exception as e:
            return self._error(f"DSSP computation failed: {e}")

        n_residues = len(ss_initial)

        # Count secondary structure elements
        ss_i = list(ss_initial)
        ss_f = list(ss_final)
        helix_initial = ss_i.count("H")
        helix_final = ss_f.count("H")
        sheet_initial = ss_i.count("E")
        sheet_final = ss_f.count("E")

        # Preservation: fraction of residues that kept their assignment
        preserved = sum(1 for a, b in zip(ss_initial, ss_final) if a == b)
        preservation = preserved / n_residues * 100 if n_residues > 0 else 0.0

        metrics: dict[str, Any] = {
            "ss_preservation_pct": round(preservation, 1),
            "helix_initial": helix_initial,
            "helix_final": helix_final,
            "sheet_initial": sheet_initial,
            "sheet_final": sheet_final,
            "ss_stable": preservation >= self.preservation_min_pct,
        }

        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=True,
            metrics=metrics,
            error=None,
        )

    def _error(self, message: str) -> ToolResult:
        """Create a failure ToolResult with the given error message."""
        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=False,
            metrics={},
            error=message,
        )
