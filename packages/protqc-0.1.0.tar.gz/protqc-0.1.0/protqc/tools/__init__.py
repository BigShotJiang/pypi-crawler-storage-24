"""
ProtQC verification tools.

Each tool module exposes a class that takes a PDB path
(and optionally a trajectory path) and returns a ToolResult dict.
"""

from protqc.tools.structure_scorer import StructurePredictor

# Optional-dep tools: import succeeds even if the underlying library
# is missing — each class checks availability at runtime.
try:
    from protqc.tools.fpocket_tool import FpocketAnalyzer
except ImportError:
    pass

try:
    from protqc.tools.freesasa_tool import FreeSASAAnalyzer
except ImportError:
    pass

try:
    from protqc.tools.openmm_tool import OpenMMSimulator
except ImportError:
    pass

try:
    from protqc.tools.hbond_tool import HBondAnalyzer
except ImportError:
    pass

try:
    from protqc.tools.ss_stability_tool import SSStabilityAnalyzer
except ImportError:
    pass

__all__ = [
    "StructurePredictor",
    "FpocketAnalyzer",
    "FreeSASAAnalyzer",
    "OpenMMSimulator",
    "HBondAnalyzer",
    "SSStabilityAnalyzer",
]
