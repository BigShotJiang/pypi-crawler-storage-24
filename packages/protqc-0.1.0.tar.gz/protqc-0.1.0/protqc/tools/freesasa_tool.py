"""
FreeSASA Tool — Solvent Accessible Surface Area analysis.

Abnormal SASA polar/apolar ratios can indicate misfolding:
too hydrophobic a surface suggests buried residues are exposed,
too hydrophilic may indicate an unfolded or disordered structure.

Requires: pip install freesasa
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from protqc.config import load_config
from protqc.types import ToolResult

try:
    import freesasa

    FREESASA_AVAILABLE = True
except ImportError:
    FREESASA_AVAILABLE = False


class FreeSASAAnalyzer:
    """Compute solvent-accessible surface area from a PDB file."""

    TOOL_NAME = "freesasa"

    def __init__(self, config: dict[str, Any] | None = None):
        if config is None:
            try:
                config = load_config()
            except Exception:
                config = {}
        self.config = config
        surface_cfg = config.get("surface", {})
        self.polar_ratio_min = surface_cfg.get("sasa_polar_ratio_min", 0.20)
        self.polar_ratio_max = surface_cfg.get("sasa_polar_ratio_max", 0.65)

    def analyze(self, pdb_path: str | Path) -> ToolResult:
        """Calculate SASA and polar/apolar classification.

        Args:
            pdb_path: Path to a PDB file.

        Returns:
            ToolResult with SASA metrics or error.
        """
        pdb_path = Path(pdb_path)

        if not FREESASA_AVAILABLE:
            return self._error(
                "freesasa not installed. Install with: pip install freesasa"
            )

        if not pdb_path.exists():
            return self._error(f"PDB file not found: {pdb_path}")

        if not pdb_path.is_file():
            return self._error(f"Path is not a file: {pdb_path}")

        try:
            structure = freesasa.Structure(str(pdb_path))
        except Exception as e:
            return self._error(f"Failed to parse PDB structure: {e}")

        try:
            result = freesasa.calc(structure)
        except Exception as e:
            return self._error(f"SASA calculation failed: {e}")

        total = result.totalArea()
        if total <= 0:
            return self._error("Total SASA is zero — PDB may have no atoms")

        # Classify into polar/apolar
        polar = 0.0
        apolar = 0.0
        try:
            classes = freesasa.classifyResults(result, structure)
            polar = classes.get("Polar", 0.0)
            apolar = classes.get("Apolar", 0.0)
        except Exception:
            # Fallback: rough estimate from literature averages
            polar = total * 0.4
            apolar = total * 0.6

        ratio = polar / total

        metrics: dict[str, Any] = {
            "total_sasa_A2": round(total, 2),
            "polar_sasa_A2": round(polar, 2),
            "apolar_sasa_A2": round(apolar, 2),
            "polar_ratio": round(ratio, 4),
            "sasa_normal": self.polar_ratio_min <= ratio <= self.polar_ratio_max,
            "pdb_path": str(pdb_path),
        }

        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=True,
            metrics=metrics,
            error=None,
        )

    def _error(self, message: str) -> ToolResult:
        """Create a failure ToolResult with the given error message."""
        return ToolResult(
            tool_name=self.TOOL_NAME,
            success=False,
            metrics={},
            error=message,
        )
