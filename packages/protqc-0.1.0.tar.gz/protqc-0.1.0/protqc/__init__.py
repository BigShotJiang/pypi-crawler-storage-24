"""
ProtQC — Physics-based verification of AI-generated protein designs.

A multi-agent framework that catches structural hallucinations before wet-lab.
"""

__version__ = "0.1.0"

from protqc.types import (
    ToolResult,
    VerificationMetrics,
    RiskVerdict,
    PipelineResult,
)
from protqc.config import load_config

__all__ = [
    "ToolResult",
    "VerificationMetrics",
    "RiskVerdict",
    "PipelineResult",
    "load_config",
]
