"""
ProtQC Risk Scorer — weighted composite risk from verification metrics.

Normalizes each tool's metrics to a 0.0-1.0 risk scale, then computes a
weighted sum. Missing metrics (tool was skipped or unavailable) are excluded
and remaining weights are renormalized.

Risk scale: 0.0 = perfect, 1.0 = certain failure
Verdicts: PASS < pass_threshold, WARNING < warn_threshold, FAIL >= warn_threshold
"""

from __future__ import annotations

from typing import Any

from protqc.types import RiskVerdict, VerificationMetrics


def normalize_metric(
    value: float, threshold: float, direction: str = "lower_better"
) -> float:
    """Normalize a metric to a 0.0-1.0 risk score.

    Args:
        value: Raw metric value.
        threshold: Reference value — risk ~0.5 when value equals threshold
                   for lower_better; risk ~0.5 when value equals threshold
                   for higher_better.
        direction: "lower_better" (RMSD, cavity — low is good) or
                   "higher_better" (pLDDT, persistence — high is good).

    Returns:
        Float in [0.0, 1.0] where 0.0 = no risk, 1.0 = maximum risk.
    """
    if threshold == 0:
        return 0.0

    if direction == "lower_better":
        # Scale so threshold → 0.5 risk, 2×threshold → 1.0 risk
        return min(1.0, max(0.0, value / (2.0 * threshold)))
    else:
        return min(1.0, max(0.0, 1.0 - (value / threshold)))


# Mapping from risk_weight key -> (metric_key, direction, config_section, config_key)
_METRIC_MAP: list[tuple[str, str, str, str, str]] = [
    ("plddt", "plddt_mean", "higher_better", "structure_scorer", "plddt_min"),
    ("md_rmsd", "rmsd_max_A", "lower_better", "physics_verifier", "md_rmsd_max_angstrom"),
    # cavity is handled specially (per-residue normalization), not in this map
    ("hbond_persistence", "hbond_persistence_pct", "higher_better", "hbond", "persistence_min_pct"),
    ("ss_preservation", "ss_preservation_pct", "higher_better", "secondary_structure", "preservation_min_pct"),
]

# SASA uses special "range" logic, handled separately
_SASA_WEIGHT_KEY = "sasa_ratio"
_SASA_METRIC_KEY = "polar_ratio"


def calculate_risk_score(
    metrics: VerificationMetrics | dict[str, Any],
    config: dict[str, Any],
) -> RiskVerdict:
    """Compute weighted composite risk from all available metrics.

    Metrics that are not present in the input dict are skipped and their
    weights are redistributed proportionally among the remaining metrics.

    Args:
        metrics: Aggregated metrics from all tools (partial is OK).
        config: Full config dict with risk_weights and verdicts sections.

    Returns:
        RiskVerdict with score, verdict string, breakdown, weights, explanation.
    """
    weights = config.get("risk_weights", {})
    verdicts_cfg = config.get("verdicts", {})
    pass_threshold = verdicts_cfg.get("pass_threshold", 0.35)
    warn_threshold = verdicts_cfg.get("warn_threshold", 0.55)

    # Compute individual normalized scores for available metrics
    scores: dict[str, float] = {}
    active_weights: dict[str, float] = {}

    for weight_key, metric_key, direction, cfg_section, cfg_key in _METRIC_MAP:
        if metric_key not in metrics:
            continue
        if weight_key not in weights:
            continue

        threshold_val = config.get(cfg_section, {}).get(cfg_key, 1.0)
        # For higher_better, use a reference slightly above threshold for scaling
        if direction == "higher_better":
            # Scale so threshold maps to ~0.3 risk (not terrible, but flagged)
            ref = threshold_val / 0.7 if threshold_val > 0 else 1.0
        else:
            ref = threshold_val

        scores[weight_key] = normalize_metric(
            float(metrics[metric_key]), ref, direction
        )
        active_weights[weight_key] = weights[weight_key]

    # Cavity — suspicious cavities only (large buried voids with low druggability).
    # Normal binding pockets (high druggability) are ignored; only structurally
    # problematic voids contribute to cavity risk.
    _cavity_key = "cavity"
    if _cavity_key in weights:
        suspicious_vol = metrics.get("suspicious_volume_A3")
        if suspicious_vol is not None:
            if float(suspicious_vol) == 0.0:
                scores[_cavity_key] = 0.0
            else:
                seq_len = metrics.get("sequence_length")
                per_res_max = config.get("cavity", {}).get(
                    "fpocket_volume_per_residue_max", 5.0
                )
                if seq_len and seq_len > 0:
                    vol_per_res = float(suspicious_vol) / seq_len
                    scores[_cavity_key] = min(1.0, vol_per_res / (2.0 * per_res_max))
                else:
                    abs_max = config.get("cavity", {}).get(
                        "fpocket_total_volume_max_cubic_angstrom", 200
                    )
                    scores[_cavity_key] = normalize_metric(
                        float(suspicious_vol), abs_max, "lower_better"
                    )
            active_weights[_cavity_key] = weights[_cavity_key]
        else:
            # Fall back to filtered_volume_A3 for old data without suspicious detection
            filtered_vol = metrics.get("filtered_volume_A3")
            if filtered_vol is None:
                filtered_vol = metrics.get("total_volume_A3")
            if filtered_vol is not None:
                seq_len = metrics.get("sequence_length")
                per_res_max = config.get("cavity", {}).get(
                    "fpocket_volume_per_residue_max", 5.0
                )
                abs_max = config.get("cavity", {}).get(
                    "fpocket_total_volume_max_cubic_angstrom", 200
                )
                if seq_len and seq_len > 0:
                    vol_per_res = float(filtered_vol) / seq_len
                    scores[_cavity_key] = normalize_metric(
                        vol_per_res, per_res_max, "lower_better"
                    )
                else:
                    scores[_cavity_key] = normalize_metric(
                        float(filtered_vol), abs_max, "lower_better"
                    )
                active_weights[_cavity_key] = weights[_cavity_key]

    # SASA range metric
    if _SASA_METRIC_KEY in metrics and _SASA_WEIGHT_KEY in weights:
        ratio = float(metrics[_SASA_METRIC_KEY])
        sasa_min = config.get("surface", {}).get("sasa_polar_ratio_min", 0.20)
        sasa_max = config.get("surface", {}).get("sasa_polar_ratio_max", 0.65)
        midpoint = (sasa_min + sasa_max) / 2
        half_range = (sasa_max - sasa_min) / 2

        if sasa_min <= ratio <= sasa_max:
            scores[_SASA_WEIGHT_KEY] = 0.0
        else:
            scores[_SASA_WEIGHT_KEY] = min(
                1.0, abs(ratio - midpoint) / (half_range + 0.30)
            )
        active_weights[_SASA_WEIGHT_KEY] = weights[_SASA_WEIGHT_KEY]

    # Renormalize weights to sum to 1.0
    total_weight = sum(active_weights.values())
    if total_weight > 0:
        norm_weights = {k: v / total_weight for k, v in active_weights.items()}
    else:
        norm_weights = {}

    # Weighted sum
    risk = sum(scores.get(k, 0.0) * norm_weights.get(k, 0.0) for k in norm_weights)
    risk = round(min(1.0, max(0.0, risk)), 3)

    # Verdict
    if risk < pass_threshold:
        verdict = "PASS"
    elif risk < warn_threshold:
        verdict = "WARNING"
    else:
        verdict = "FAIL"

    # Explanation — top risk drivers
    explanations = []
    for k, v in sorted(scores.items(), key=lambda x: -x[1]):
        if v > 0.6:
            explanations.append(f"  [HIGH RISK] {k}: {v:.2f}")
        elif v > 0.3:
            explanations.append(f"  [MODERATE]  {k}: {v:.2f}")

    if explanations:
        explanation = f"Risk Score: {risk} -> {verdict}\n" + "\n".join(explanations)
    else:
        explanation = f"Risk Score: {risk} -> {verdict} (all metrics normal)"

    return RiskVerdict(
        risk_score=risk,
        verdict=verdict,
        breakdown={k: round(v, 3) for k, v in scores.items()},
        weights=dict(norm_weights),
        explanation=explanation,
    )
