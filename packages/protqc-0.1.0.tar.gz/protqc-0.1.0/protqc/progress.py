"""Pipeline stage progress display using rich spinners.

Shows science-themed loading messages while each pipeline tool runs.
For the MD simulation stage, messages rotate every 10 seconds to reflect
the different phases of the simulation protocol.

Usage:
    from protqc.progress import create_stage_display
    on_stage = create_stage_display(console)

    with on_stage("structure_scorer"):
        result = scorer.extract_plddt(pdb_path)
"""

from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from typing import Generator

from rich.console import Console

# Spinner messages shown while each stage runs.
# Lists trigger rotating display (for long-running stages).
STAGE_MESSAGES: dict[str, str | list[str]] = {
    "structure_scorer": "Reading atomic coordinates...",
    "fpocket": "Probing cavities and pockets...",
    "freesasa": "Rolling solvent sphere across surface...",
    "openmm": [
        "Solvating protein in virtual water box...",
        "Adding ions to 150mM NaCl...",
        "Minimizing energy (removing steric clashes)...",
        "Heating system to 300K...",
        "Equilibrating pressure at 1 atm...",
        "Running molecular dynamics \u2014 atoms in motion...",
        "Sampling conformational space...",
        "Monitoring backbone stability...",
    ],
    "openmm_traj": "Analyzing existing trajectory...",
    "hbond": "Counting hydrogen bonds across trajectory...",
    "ss_stability": "Tracking secondary structure over time...",
    "scoring": "Computing composite risk score...",
}

# Human-readable labels for the completion line.
STAGE_LABELS: dict[str, str] = {
    "structure_scorer": "Structure scoring",
    "fpocket": "Cavity detection",
    "freesasa": "Surface accessibility",
    "openmm": "MD simulation",
    "openmm_traj": "Trajectory analysis",
    "hbond": "H-bond analysis",
    "ss_stability": "SS stability",
    "scoring": "Risk scoring",
}

_MD_ROTATE_INTERVAL = 10  # seconds between message rotations


def _format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as human-readable string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = seconds % 60
    return f"{minutes}m {secs:.0f}s"


def create_stage_display(console: Console):
    """Create a stage progress display using rich spinners.

    Returns a context-manager factory: call it with a stage name,
    and use the returned context manager around the stage's work.
    While inside the ``with`` block a spinner is shown; on exit the
    spinner is replaced with a green checkmark and elapsed time.

    For stages with a list of messages (e.g. MD simulation), messages
    rotate every 10 seconds in a background thread.

    Example::

        show = create_stage_display(console)
        with show("fpocket"):
            result = fpocket.analyze(pdb)
        # prints: ✓ Cavity detection  (1.3s)
    """

    @contextmanager
    def show_stage(stage: str) -> Generator[None, None, None]:
        messages = STAGE_MESSAGES.get(stage, f"Running {stage}...")
        label = STAGE_LABELS.get(stage, stage)
        start = time.monotonic()

        if isinstance(messages, list):
            # Rotating messages for long-running stages (MD simulation)
            stop_event = threading.Event()
            status = console.status(f"  {messages[0]}", spinner="dots")
            status.start()

            def _rotate() -> None:
                idx = 0
                while not stop_event.wait(_MD_ROTATE_INTERVAL):
                    idx = (idx + 1) % len(messages)
                    elapsed = _format_elapsed(time.monotonic() - start)
                    status.update(
                        f"  {messages[idx]}  [dim]({elapsed})[/]"
                    )

            thread = threading.Thread(target=_rotate, daemon=True)
            thread.start()
            try:
                yield
            finally:
                stop_event.set()
                thread.join(timeout=2)
                status.stop()
                elapsed = _format_elapsed(time.monotonic() - start)
                console.print(f"  [green]\u2713[/] {label}  [dim]({elapsed})[/]")
        else:
            # Single message for quick stages
            with console.status(f"  {messages}", spinner="dots"):
                yield
            elapsed = _format_elapsed(time.monotonic() - start)
            console.print(f"  [green]\u2713[/] {label}  [dim]({elapsed})[/]")

    return show_stage
