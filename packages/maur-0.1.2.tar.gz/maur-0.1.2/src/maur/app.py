import logging

from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlmodel import SQLModel

from maur.api import router
from maur.models import engine

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    import logging
    logging.basicConfig(level=logging.INFO)

    logger.info("Creating db models")
    async with engine().begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)
    logger.info("Created all models")

    yield


app = FastAPI(
    title="Maur Agent",
    description="Autonomous code agent that processes coding tasks from exception, Slack, and Linear.",
    version="0.1.0",
    lifespan=lifespan,
)


@app.get("/health")
def health() -> str:
    return "ok"


app.include_router(router)
