import uuid
from pydantic import BaseModel

class LinearWebhookPayload(BaseModel):
    action: str
    data: dict


class ExceptionPayload(BaseModel):
    repo_branch: str = "main"
    fingerprint: str
    title: str
    description: str
    extra: dict = {}


class ManualTaskPayload(BaseModel):
    repo_branch: str = "main"
    prompt: str
    source_id: str


class TaskResponse(BaseModel):
    task_id: uuid.UUID
    status: str
    message: str
