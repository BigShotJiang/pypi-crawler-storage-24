# diffstep

diffstep is a lightweight Python library for algorithmic differentiation.

It lets you:

- Differentiate expressions like `x^2 + 3x + 2`
- Evaluate gradients at specific points

## Installation

Install from PyPI:

```bash
pip install diffstep
```

## Quick Start

### Basic Access (`from diffstep import diffstep`)

```python
from diffstep import diffstep

diffstep("x^2 + 3x + 2")
# 2*x + 3
```

### Advanced Access (`import diffstep`)

```python
import diffstep

diffstep.differentiate("x^2 + 3x + 2")
# 2*x + 3

diffstep.gradient("x^2 + 3x + 2", 1)
# 5
```

## Public API

- `diffstep(expression: str)`
  Main entry point. Returns the simplified symbolic derivative.

- `differentiate(expression: str)`
  Alias of `diffstep()`.

- `gradient(expression: str, x_value: float)`
  Evaluates the derivative at a specific `x` value.

- `normalise_expression(expression: str)`
  Returns the normalized expression string used internally by the parser.

- `DiffStep(expression: str)`
  Deprecated alias for backward compatibility.

## Supported Expression Features

- Variables: `x`
- Constants and arithmetic: `+`, `-`, `*`, `/`, `^`
- Common functions such as `sin`, `cosec`, `arctan`, `ln`, and `sqrt`

## Project Structure

- `diffstep/core/`: validation, tokenization, parsing, AST nodes
- `diffstep/differentiation/`: differentiation rules
- `diffstep/simplify/`: simplification logic
- `diffstep/printer/`: AST-to-expression string conversion
- `diffstep/pipeline.py`: user-facing workflow functions

## License

MIT License. See `LICENSE.txt` for details.
