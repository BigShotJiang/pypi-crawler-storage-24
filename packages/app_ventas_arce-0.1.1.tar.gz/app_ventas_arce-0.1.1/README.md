# App de Ventas

Este Paquete proporciona funcionalidades para Gestionar Ventas,
incluyendo el Cálculo de Precios, Impuestos y Descuentos.

## Instalación

Puedes Instalar el Paquete usando:

<>bash
pip install .
"