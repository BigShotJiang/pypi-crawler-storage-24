import unittest
from Ventas_App.Gestor import Gestor_Ventas
from Ventas_App.Exceptions import ImpuestoInvalidoError,DescuentoInvalidoError

class TestGestorVentas(unittest.TestCase):
    
    def test_calculo_precio_final(self):
        gestor=Gestor_Ventas(100.0,0.05,0.10)
        self .assertEqual(gestor.precio_final(),95.0)
    
    def test_impuesto(self):
        with self.assertRaises(ImpuestoInvalidoError):
            Gestor_Ventas(100.0,1.5,0.10)
    
    def test_descuento(self):
        with self.assertRaises(DescuentoInvalidoError):
            Gestor_Ventas(100.0,0.05,1.5)

if __name__=='__main__':
    unittest.main()





