from setuptools import setup,find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='app_ventas_arce',
    version='0.1.1',
    author='Jorge A. Arce',
    author_email='aemj220895@gmail.com',
    description='Paquete para Gestionar Ventas,Precios, Impuestos y Descuentos',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/curso_python_camara/App_Ventas',
    packages= find_packages(),
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent'
    ],
    python_requires='>=3.7'
)








