import os
import sys

# Make sure the package root is importable when running the file directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ats_resume_checker import analyze_resume, extract_keywords, extract_keywords_strict, get_keyword_set

JOB_DESC = (
    "Looking for a Python developer with strong SQL and machine learning skills. "
    "Experience with scikit-learn, data analysis, and REST API development is required. "
    "Must have good communication and problem solving abilities."
)

SAMPLE_PDF = os.path.join(os.path.dirname(__file__), "..", "sample.pdf")


def test_analyze_resume():
    result = analyze_resume(SAMPLE_PDF, JOB_DESC)

    assert isinstance(result, dict), "Result should be a dict"
    assert "ats_score" in result
    assert "match_rate" in result
    assert "matched_keywords" in result
    assert "missing_keywords" in result
    assert "resume_word_count" in result
    assert "suggestions" in result

    assert 0.0 <= result["ats_score"] <= 100.0, "ATS score must be between 0 and 100"
    assert 0.0 <= result["match_rate"] <= 100.0, "Match rate must be between 0 and 100"
    assert isinstance(result["matched_keywords"], list)
    assert isinstance(result["missing_keywords"], list)
    assert isinstance(result["suggestions"], list)
    assert result["resume_word_count"] > 0, "Word count must be positive"

    print("test_analyze_resume PASSED")
    return result


def test_extract_keywords():
    text = "Python developer with machine learning and SQL experience"
    kws = extract_keywords(text)
    assert isinstance(kws, list), "Keywords should be a list"
    assert len(kws) > 0, "Should extract at least one keyword"
    # Lemmatization: 'experience' -> 'experience', stopwords removed
    assert "python" in kws or "sql" in kws, "Common terms should be in keywords"
    print("test_extract_keywords PASSED")


def test_get_keyword_set():
    text = "data science and machine learning engineer"
    ks = get_keyword_set(text)
    assert isinstance(ks, set)
    assert len(ks) > 0
    print("test_get_keyword_set PASSED")


def test_known_phrase_detection():
    """Known multi-word phrases should be detected."""
    text = "Experienced in machine learning and deep learning for NLP tasks"
    kws = extract_keywords(text)
    assert "machine learning" in kws, "'machine learning' should be detected as a phrase"
    assert "deep learning" in kws, "'deep learning' should be detected as a phrase"
    print("test_known_phrase_detection PASSED")


if __name__ == "__main__":
    print("\n--- Running ATS Resume Checker Tests ---\n")

    test_extract_keywords()
    test_get_keyword_set()
    test_known_phrase_detection()

    result = test_analyze_resume()

    print("\n--- Full Analysis Output ---")
    print(f"  ATS Score     : {result['ats_score']}%")
    print(f"  Keyword Match : {result['match_rate']}%")
    print(f"  Resume Words  : {result['resume_word_count']}")
    print(f"  Matched       : {result['matched_keywords']}")
    print(f"  Missing       : {result['missing_keywords']}")
    print(f"  Suggestions   :")
    for tip in result['suggestions']:
        print(f"    * {tip}")

    print("\nAll tests passed!")