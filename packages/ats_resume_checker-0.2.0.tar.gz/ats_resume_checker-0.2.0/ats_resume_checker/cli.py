"""
Command-line interface for ats-resume-checker.

Usage:
    ats-check resume.pdf "Job description text here"
    ats-check resume.docx job.txt --json
"""

import argparse
import json
import sys
from pathlib import Path

from .analyzer import analyze_resume


def _load_job_description(value: str) -> str:
    """Accept either a file path or a raw string as job description."""
    p = Path(value)
    if p.is_file():
        return p.read_text(encoding="utf-8", errors="ignore")
    return value


def _print_pretty(result: dict) -> None:
    divider = "=" * 46
    print(f"\n{divider}")
    print("   ATS RESUME ANALYSIS REPORT")
    print(divider)
    print(f"  ATS Score       : {result['ats_score']}%")
    print(f"  Keyword Match   : {result['match_rate']}%")
    print(f"  Resume Words    : {result['resume_word_count']}")

    print(f"\n  Matched Keywords ({len(result['matched_keywords'])}):")
    if result["matched_keywords"]:
        for kw in result["matched_keywords"]:
            print(f"    + {kw}")
    else:
        print("    (none)")

    print(f"\n  Missing Keywords ({len(result['missing_keywords'])}):")
    if result["missing_keywords"]:
        for kw in result["missing_keywords"]:
            print(f"    - {kw}")
    else:
        print("    (none – great coverage!)")

    print(f"\n  Suggestions:")
    for tip in result["suggestions"]:
        print(f"    * {tip}")

    print(divider + "\n")


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(
        prog="ats-check",
        description="Analyze a resume against a job description for ATS compatibility.",
    )
    parser.add_argument(
        "resume",
        help="Path to resume file (.pdf, .docx, or .txt)",
    )
    parser.add_argument(
        "job_description",
        help="Job description: raw text string OR path to a .txt file",
    )
    parser.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="Output results as JSON (useful for scripting)",
    )

    args = parser.parse_args(argv)

    try:
        job_desc = _load_job_description(args.job_description)
        result = analyze_resume(args.resume, job_desc)
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    if args.as_json:
        print(json.dumps(result, indent=2))
    else:
        _print_pretty(result)


if __name__ == "__main__":
    main()
