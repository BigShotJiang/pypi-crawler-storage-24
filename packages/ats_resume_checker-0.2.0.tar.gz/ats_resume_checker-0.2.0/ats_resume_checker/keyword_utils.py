import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.util import ngrams

# Download all needed NLTK data quietly on first use
for _resource in ["stopwords", "wordnet", "omw-1.4", "punkt", "punkt_tab",
                  "averaged_perceptron_tagger", "averaged_perceptron_tagger_eng"]:
    nltk.download(_resource, quiet=True)

stop_words = set(stopwords.words("english"))
_lemmatizer = WordNetLemmatizer()

# Common multi-word tech/professional skills to detect as phrases
KNOWN_PHRASES = {
    "machine learning", "deep learning", "natural language processing",
    "data science", "data analysis", "data engineering", "data visualization",
    "computer vision", "artificial intelligence", "neural network",
    "project management", "software development", "web development",
    "cloud computing", "continuous integration", "continuous deployment",
    "unit testing", "version control", "object oriented", "object oriented programming",
    "time management", "problem solving", "critical thinking", "team player",
    "power bi", "tableau", "microsoft excel", "google analytics",
    "a b testing", "restful api", "rest api", "agile methodology",
    "big data", "feature engineering", "model deployment",
}


def _tokenize_and_clean(text: str) -> list[str]:
    """Lowercase, remove punctuation, tokenize, remove stopwords, lemmatize."""
    text = re.sub(r'[^a-zA-Z\s]', ' ', text.lower())
    tokens = text.split()
    return [
        _lemmatizer.lemmatize(w)
        for w in tokens
        if w not in stop_words and len(w) > 1
    ]


def _extract_known_phrases(text: str) -> list[str]:
    """Find known multi-word phrases present in the text."""
    clean = re.sub(r'[^a-zA-Z\s]', ' ', text.lower())
    found = []
    for phrase in KNOWN_PHRASES:
        if phrase in clean:
            found.append(phrase)
    return found


def extract_keywords(text: str, top_n: int = 50, include_bigrams: bool = True) -> list[str]:
    """
    Extract ranked keywords (unigrams + bigrams + known phrases) from text.
    Returns a list of terms sorted by frequency, highest first.
    """
    tokens = _tokenize_and_clean(text)

    freq: dict[str, int] = {}

    # Unigrams
    for word in tokens:
        freq[word] = freq.get(word, 0) + 1

    # Bigrams from token stream
    if include_bigrams:
        for gram in ngrams(tokens, 2):
            phrase = " ".join(gram)
            freq[phrase] = freq.get(phrase, 0) + 1

    # Known multi-word phrases (boost them so they surface at the top)
    for phrase in _extract_known_phrases(text):
        freq[phrase] = freq.get(phrase, 0) + 3  # small boost

    ranked = sorted(freq, key=lambda k: freq[k], reverse=True)
    return ranked[:top_n]


def extract_keywords_strict(text: str, top_n: int = 50) -> list[str]:
    """
    Like extract_keywords but ONLY includes unigrams and KNOWN_PHRASES
    (no ad-hoc bigrams). Ideal for job-description gap analysis where
    noise-free results matter more than recall.
    """
    tokens = _tokenize_and_clean(text)

    freq: dict[str, int] = {}

    for word in tokens:
        freq[word] = freq.get(word, 0) + 1

    for phrase in _extract_known_phrases(text):
        freq[phrase] = freq.get(phrase, 0) + 3

    ranked = sorted(freq, key=lambda k: freq[k], reverse=True)
    return ranked[:top_n]


def get_keyword_set(text: str, top_n: int = 50) -> set[str]:
    """Convenience wrapper returning a set of top keywords (unigrams + known phrases only)."""
    return set(extract_keywords_strict(text, top_n=top_n))