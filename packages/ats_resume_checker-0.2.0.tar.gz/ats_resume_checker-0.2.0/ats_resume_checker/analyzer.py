from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .pdf_utils import extract_text
from .keyword_utils import extract_keywords, get_keyword_set

# Minimum recommended resume word count
_MIN_WORDS = 200
_MAX_WORDS = 1000


def _tfidf_similarity(text_a: str, text_b: str) -> float:
    """Return cosine similarity (0-100) between two texts using TF-IDF."""
    try:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        vectors = vectorizer.fit_transform([text_a, text_b])
        score = cosine_similarity(vectors[0], vectors[1])[0][0]
        return round(float(score) * 100, 2)
    except ValueError:
        return 0.0


def _generate_suggestions(
    ats_score: float,
    match_rate: float,
    missing: list[str],
    word_count: int,
) -> list[str]:
    tips = []

    if ats_score < 40:
        tips.append(
            "ATS score is low. Rewrite your resume to mirror the language "
            "used in the job description."
        )
    elif ats_score < 60:
        tips.append(
            "ATS score is moderate. Align your bullet points more closely "
            "with the job description's wording."
        )

    if match_rate < 50 and missing:
        sample = ", ".join(missing[:8])
        tips.append(f"Include more job-specific keywords. Missing: {sample}.")

    if word_count < _MIN_WORDS:
        tips.append(
            f"Resume is very short ({word_count} words). "
            "Expand descriptions of your experience and skills."
        )
    elif word_count > _MAX_WORDS:
        tips.append(
            f"Resume is long ({word_count} words). "
            "Consider condensing to 1-2 pages for better readability."
        )

    if not tips:
        tips.append(
            "Great match! Make sure to quantify achievements "
            "(e.g. 'Improved performance by 30%') where possible."
        )

    return tips


def analyze_resume(resume_path: str, job_description: str) -> dict:
    """
    Analyze a resume file against a job description.

    Args:
        resume_path:     Path to the resume (.pdf, .docx, or .txt).
        job_description: Plain-text job description string.

    Returns:
        dict with keys:
            ats_score        – TF-IDF cosine similarity score (0-100)
            match_rate       – % of JD keywords found in resume (0-100)
            matched_keywords – keywords present in both resume and JD
            missing_keywords – important JD keywords absent from resume
            resume_word_count
            suggestions      – actionable improvement tips
    """
    resume_text = extract_text(resume_path)

    # Similarity score via TF-IDF (better than bag-of-words counts)
    ats_score = _tfidf_similarity(resume_text, job_description)

    # Keyword overlap analysis
    jd_keywords = get_keyword_set(job_description, top_n=40)
    resume_keywords = get_keyword_set(resume_text, top_n=100)

    matched = sorted(jd_keywords & resume_keywords)
    missing = sorted(jd_keywords - resume_keywords)

    match_rate = (
        round(len(matched) / len(jd_keywords) * 100, 1)
        if jd_keywords else 0.0
    )

    word_count = len(resume_text.split())

    return {
        "ats_score": ats_score,
        "match_rate": match_rate,
        "matched_keywords": matched,
        "missing_keywords": missing,
        "resume_word_count": word_count,
        "suggestions": _generate_suggestions(ats_score, match_rate, missing, word_count),
    }