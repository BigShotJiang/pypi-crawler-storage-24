import os
from PyPDF2 import PdfReader


def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract and return lowercased text from a PDF file."""
    text = ""
    reader = PdfReader(pdf_path)
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + " "
    if not text.strip():
        raise ValueError(
            f"No text could be extracted from '{pdf_path}'. "
            "The PDF may be image-based (scanned). Consider converting it to a text-based PDF."
        )
    return text.lower()


def extract_text_from_docx(docx_path: str) -> str:
    """Extract and return lowercased text from a .docx file."""
    try:
        import docx  # python-docx
    except ImportError:
        raise ImportError(
            "python-docx is required for .docx support. "
            "Install it with: pip install python-docx"
        )
    doc = docx.Document(docx_path)
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    # Also pull text from tables
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text.strip():
                    paragraphs.append(cell.text)
    text = " ".join(paragraphs)
    if not text.strip():
        raise ValueError(f"No text could be extracted from '{docx_path}'.")
    return text.lower()


def extract_text_from_txt(txt_path: str) -> str:
    """Extract and return lowercased text from a plain .txt file."""
    with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read().lower()


def extract_text(file_path: str) -> str:
    """
    Auto-detect file type and extract text.
    Supports: .pdf, .docx, .txt
    """
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(file_path)
    elif ext in (".docx", ".doc"):
        return extract_text_from_docx(file_path)
    elif ext == ".txt":
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(
            f"Unsupported file type: '{ext}'. Supported formats: .pdf, .docx, .txt"
        )