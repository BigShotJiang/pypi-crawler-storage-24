# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ClientSpanInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'global_trace_id': 'str',
        'global_path': 'str',
        'trace_id': 'str',
        'span_id': 'str',
        'env_id': 'int',
        'instance_id': 'int',
        'app_id': 'int',
        'biz_id': 'int',
        'domain_id': 'int',
        'source': 'str',
        'real_source': 'str',
        'start_time': 'int',
        'time_used': 'int',
        'code': 'int',
        'class_name': 'str',
        'is_async': 'bool',
        'tags': 'dict(str, str)',
        'has_error': 'bool',
        'error_reasons': 'str',
        'type': 'str',
        'http_method': 'str',
        'biz_code': 'str'
    }

    attribute_map = {
        'global_trace_id': 'global_trace_id',
        'global_path': 'global_path',
        'trace_id': 'trace_id',
        'span_id': 'span_id',
        'env_id': 'env_id',
        'instance_id': 'instance_id',
        'app_id': 'app_id',
        'biz_id': 'biz_id',
        'domain_id': 'domain_id',
        'source': 'source',
        'real_source': 'real_source',
        'start_time': 'start_time',
        'time_used': 'time_used',
        'code': 'code',
        'class_name': 'class_name',
        'is_async': 'is_async',
        'tags': 'tags',
        'has_error': 'has_error',
        'error_reasons': 'error_reasons',
        'type': 'type',
        'http_method': 'http_method',
        'biz_code': 'biz_code'
    }

    def __init__(self, global_trace_id=None, global_path=None, trace_id=None, span_id=None, env_id=None, instance_id=None, app_id=None, biz_id=None, domain_id=None, source=None, real_source=None, start_time=None, time_used=None, code=None, class_name=None, is_async=None, tags=None, has_error=None, error_reasons=None, type=None, http_method=None, biz_code=None):
        r"""ClientSpanInfo

        The model defined in huaweicloud sdk

        :param global_trace_id: vTraceId，虚拟traceI。
        :type global_trace_id: str
        :param global_path: 虚拟traceId经过的path路径。
        :type global_path: str
        :param trace_id: traceId。
        :type trace_id: str
        :param span_id: span id。
        :type span_id: str
        :param env_id: 环境Iid。
        :type env_id: int
        :param instance_id: 实例id。
        :type instance_id: int
        :param app_id: 组件id。
        :type app_id: int
        :param biz_id: 应用id。
        :type biz_id: int
        :param domain_id: 租户id。
        :type domain_id: int
        :param source: 只有是根event也就是span的时候有值。
        :type source: str
        :param real_source: 根event 的时候存在，实际调用的url。
        :type real_source: str
        :param start_time: 开始时间。
        :type start_time: int
        :param time_used: 耗时。
        :type time_used: int
        :param code: 状态码，针对http的调用有效。
        :type code: int
        :param class_name: 类名。
        :type class_name: str
        :param is_async: 是否异步。
        :type is_async: bool
        :param tags: 包含用户自定义参数，header或body体里的内容，httpMethod, bizCode，以及后续可能新增参数。
        :type tags: dict(str, str)
        :param has_error: 是否报错。
        :type has_error: bool
        :param error_reasons: 报错原因。
        :type error_reasons: str
        :param type: 类型，mysql，kafka等。
        :type type: str
        :param http_method: 这里的method实际上是tags里面的http_method，只有url监控项才有。
        :type http_method: str
        :param biz_code: 业务状态码的采集。
        :type biz_code: str
        """
        
        

        self._global_trace_id = None
        self._global_path = None
        self._trace_id = None
        self._span_id = None
        self._env_id = None
        self._instance_id = None
        self._app_id = None
        self._biz_id = None
        self._domain_id = None
        self._source = None
        self._real_source = None
        self._start_time = None
        self._time_used = None
        self._code = None
        self._class_name = None
        self._is_async = None
        self._tags = None
        self._has_error = None
        self._error_reasons = None
        self._type = None
        self._http_method = None
        self._biz_code = None
        self.discriminator = None

        if global_trace_id is not None:
            self.global_trace_id = global_trace_id
        if global_path is not None:
            self.global_path = global_path
        if trace_id is not None:
            self.trace_id = trace_id
        if span_id is not None:
            self.span_id = span_id
        if env_id is not None:
            self.env_id = env_id
        if instance_id is not None:
            self.instance_id = instance_id
        if app_id is not None:
            self.app_id = app_id
        if biz_id is not None:
            self.biz_id = biz_id
        if domain_id is not None:
            self.domain_id = domain_id
        if source is not None:
            self.source = source
        if real_source is not None:
            self.real_source = real_source
        if start_time is not None:
            self.start_time = start_time
        if time_used is not None:
            self.time_used = time_used
        if code is not None:
            self.code = code
        if class_name is not None:
            self.class_name = class_name
        if is_async is not None:
            self.is_async = is_async
        if tags is not None:
            self.tags = tags
        if has_error is not None:
            self.has_error = has_error
        if error_reasons is not None:
            self.error_reasons = error_reasons
        if type is not None:
            self.type = type
        if http_method is not None:
            self.http_method = http_method
        if biz_code is not None:
            self.biz_code = biz_code

    @property
    def global_trace_id(self):
        r"""Gets the global_trace_id of this ClientSpanInfo.

        vTraceId，虚拟traceI。

        :return: The global_trace_id of this ClientSpanInfo.
        :rtype: str
        """
        return self._global_trace_id

    @global_trace_id.setter
    def global_trace_id(self, global_trace_id):
        r"""Sets the global_trace_id of this ClientSpanInfo.

        vTraceId，虚拟traceI。

        :param global_trace_id: The global_trace_id of this ClientSpanInfo.
        :type global_trace_id: str
        """
        self._global_trace_id = global_trace_id

    @property
    def global_path(self):
        r"""Gets the global_path of this ClientSpanInfo.

        虚拟traceId经过的path路径。

        :return: The global_path of this ClientSpanInfo.
        :rtype: str
        """
        return self._global_path

    @global_path.setter
    def global_path(self, global_path):
        r"""Sets the global_path of this ClientSpanInfo.

        虚拟traceId经过的path路径。

        :param global_path: The global_path of this ClientSpanInfo.
        :type global_path: str
        """
        self._global_path = global_path

    @property
    def trace_id(self):
        r"""Gets the trace_id of this ClientSpanInfo.

        traceId。

        :return: The trace_id of this ClientSpanInfo.
        :rtype: str
        """
        return self._trace_id

    @trace_id.setter
    def trace_id(self, trace_id):
        r"""Sets the trace_id of this ClientSpanInfo.

        traceId。

        :param trace_id: The trace_id of this ClientSpanInfo.
        :type trace_id: str
        """
        self._trace_id = trace_id

    @property
    def span_id(self):
        r"""Gets the span_id of this ClientSpanInfo.

        span id。

        :return: The span_id of this ClientSpanInfo.
        :rtype: str
        """
        return self._span_id

    @span_id.setter
    def span_id(self, span_id):
        r"""Sets the span_id of this ClientSpanInfo.

        span id。

        :param span_id: The span_id of this ClientSpanInfo.
        :type span_id: str
        """
        self._span_id = span_id

    @property
    def env_id(self):
        r"""Gets the env_id of this ClientSpanInfo.

        环境Iid。

        :return: The env_id of this ClientSpanInfo.
        :rtype: int
        """
        return self._env_id

    @env_id.setter
    def env_id(self, env_id):
        r"""Sets the env_id of this ClientSpanInfo.

        环境Iid。

        :param env_id: The env_id of this ClientSpanInfo.
        :type env_id: int
        """
        self._env_id = env_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ClientSpanInfo.

        实例id。

        :return: The instance_id of this ClientSpanInfo.
        :rtype: int
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ClientSpanInfo.

        实例id。

        :param instance_id: The instance_id of this ClientSpanInfo.
        :type instance_id: int
        """
        self._instance_id = instance_id

    @property
    def app_id(self):
        r"""Gets the app_id of this ClientSpanInfo.

        组件id。

        :return: The app_id of this ClientSpanInfo.
        :rtype: int
        """
        return self._app_id

    @app_id.setter
    def app_id(self, app_id):
        r"""Sets the app_id of this ClientSpanInfo.

        组件id。

        :param app_id: The app_id of this ClientSpanInfo.
        :type app_id: int
        """
        self._app_id = app_id

    @property
    def biz_id(self):
        r"""Gets the biz_id of this ClientSpanInfo.

        应用id。

        :return: The biz_id of this ClientSpanInfo.
        :rtype: int
        """
        return self._biz_id

    @biz_id.setter
    def biz_id(self, biz_id):
        r"""Sets the biz_id of this ClientSpanInfo.

        应用id。

        :param biz_id: The biz_id of this ClientSpanInfo.
        :type biz_id: int
        """
        self._biz_id = biz_id

    @property
    def domain_id(self):
        r"""Gets the domain_id of this ClientSpanInfo.

        租户id。

        :return: The domain_id of this ClientSpanInfo.
        :rtype: int
        """
        return self._domain_id

    @domain_id.setter
    def domain_id(self, domain_id):
        r"""Sets the domain_id of this ClientSpanInfo.

        租户id。

        :param domain_id: The domain_id of this ClientSpanInfo.
        :type domain_id: int
        """
        self._domain_id = domain_id

    @property
    def source(self):
        r"""Gets the source of this ClientSpanInfo.

        只有是根event也就是span的时候有值。

        :return: The source of this ClientSpanInfo.
        :rtype: str
        """
        return self._source

    @source.setter
    def source(self, source):
        r"""Sets the source of this ClientSpanInfo.

        只有是根event也就是span的时候有值。

        :param source: The source of this ClientSpanInfo.
        :type source: str
        """
        self._source = source

    @property
    def real_source(self):
        r"""Gets the real_source of this ClientSpanInfo.

        根event 的时候存在，实际调用的url。

        :return: The real_source of this ClientSpanInfo.
        :rtype: str
        """
        return self._real_source

    @real_source.setter
    def real_source(self, real_source):
        r"""Sets the real_source of this ClientSpanInfo.

        根event 的时候存在，实际调用的url。

        :param real_source: The real_source of this ClientSpanInfo.
        :type real_source: str
        """
        self._real_source = real_source

    @property
    def start_time(self):
        r"""Gets the start_time of this ClientSpanInfo.

        开始时间。

        :return: The start_time of this ClientSpanInfo.
        :rtype: int
        """
        return self._start_time

    @start_time.setter
    def start_time(self, start_time):
        r"""Sets the start_time of this ClientSpanInfo.

        开始时间。

        :param start_time: The start_time of this ClientSpanInfo.
        :type start_time: int
        """
        self._start_time = start_time

    @property
    def time_used(self):
        r"""Gets the time_used of this ClientSpanInfo.

        耗时。

        :return: The time_used of this ClientSpanInfo.
        :rtype: int
        """
        return self._time_used

    @time_used.setter
    def time_used(self, time_used):
        r"""Sets the time_used of this ClientSpanInfo.

        耗时。

        :param time_used: The time_used of this ClientSpanInfo.
        :type time_used: int
        """
        self._time_used = time_used

    @property
    def code(self):
        r"""Gets the code of this ClientSpanInfo.

        状态码，针对http的调用有效。

        :return: The code of this ClientSpanInfo.
        :rtype: int
        """
        return self._code

    @code.setter
    def code(self, code):
        r"""Sets the code of this ClientSpanInfo.

        状态码，针对http的调用有效。

        :param code: The code of this ClientSpanInfo.
        :type code: int
        """
        self._code = code

    @property
    def class_name(self):
        r"""Gets the class_name of this ClientSpanInfo.

        类名。

        :return: The class_name of this ClientSpanInfo.
        :rtype: str
        """
        return self._class_name

    @class_name.setter
    def class_name(self, class_name):
        r"""Sets the class_name of this ClientSpanInfo.

        类名。

        :param class_name: The class_name of this ClientSpanInfo.
        :type class_name: str
        """
        self._class_name = class_name

    @property
    def is_async(self):
        r"""Gets the is_async of this ClientSpanInfo.

        是否异步。

        :return: The is_async of this ClientSpanInfo.
        :rtype: bool
        """
        return self._is_async

    @is_async.setter
    def is_async(self, is_async):
        r"""Sets the is_async of this ClientSpanInfo.

        是否异步。

        :param is_async: The is_async of this ClientSpanInfo.
        :type is_async: bool
        """
        self._is_async = is_async

    @property
    def tags(self):
        r"""Gets the tags of this ClientSpanInfo.

        包含用户自定义参数，header或body体里的内容，httpMethod, bizCode，以及后续可能新增参数。

        :return: The tags of this ClientSpanInfo.
        :rtype: dict(str, str)
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this ClientSpanInfo.

        包含用户自定义参数，header或body体里的内容，httpMethod, bizCode，以及后续可能新增参数。

        :param tags: The tags of this ClientSpanInfo.
        :type tags: dict(str, str)
        """
        self._tags = tags

    @property
    def has_error(self):
        r"""Gets the has_error of this ClientSpanInfo.

        是否报错。

        :return: The has_error of this ClientSpanInfo.
        :rtype: bool
        """
        return self._has_error

    @has_error.setter
    def has_error(self, has_error):
        r"""Sets the has_error of this ClientSpanInfo.

        是否报错。

        :param has_error: The has_error of this ClientSpanInfo.
        :type has_error: bool
        """
        self._has_error = has_error

    @property
    def error_reasons(self):
        r"""Gets the error_reasons of this ClientSpanInfo.

        报错原因。

        :return: The error_reasons of this ClientSpanInfo.
        :rtype: str
        """
        return self._error_reasons

    @error_reasons.setter
    def error_reasons(self, error_reasons):
        r"""Sets the error_reasons of this ClientSpanInfo.

        报错原因。

        :param error_reasons: The error_reasons of this ClientSpanInfo.
        :type error_reasons: str
        """
        self._error_reasons = error_reasons

    @property
    def type(self):
        r"""Gets the type of this ClientSpanInfo.

        类型，mysql，kafka等。

        :return: The type of this ClientSpanInfo.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this ClientSpanInfo.

        类型，mysql，kafka等。

        :param type: The type of this ClientSpanInfo.
        :type type: str
        """
        self._type = type

    @property
    def http_method(self):
        r"""Gets the http_method of this ClientSpanInfo.

        这里的method实际上是tags里面的http_method，只有url监控项才有。

        :return: The http_method of this ClientSpanInfo.
        :rtype: str
        """
        return self._http_method

    @http_method.setter
    def http_method(self, http_method):
        r"""Sets the http_method of this ClientSpanInfo.

        这里的method实际上是tags里面的http_method，只有url监控项才有。

        :param http_method: The http_method of this ClientSpanInfo.
        :type http_method: str
        """
        self._http_method = http_method

    @property
    def biz_code(self):
        r"""Gets the biz_code of this ClientSpanInfo.

        业务状态码的采集。

        :return: The biz_code of this ClientSpanInfo.
        :rtype: str
        """
        return self._biz_code

    @biz_code.setter
    def biz_code(self, biz_code):
        r"""Sets the biz_code of this ClientSpanInfo.

        业务状态码的采集。

        :param biz_code: The biz_code of this ClientSpanInfo.
        :type biz_code: str
        """
        self._biz_code = biz_code

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ClientSpanInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
