# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListBusinessEnvResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'env_entry_list': 'list[EnvEntry]'
    }

    attribute_map = {
        'env_entry_list': 'env_entry_list'
    }

    def __init__(self, env_entry_list=None):
        r"""ListBusinessEnvResponse

        The model defined in huaweicloud sdk

        :param env_entry_list: 环境列表。
        :type env_entry_list: list[:class:`huaweicloudsdkapm.v1.EnvEntry`]
        """
        
        super().__init__()

        self._env_entry_list = None
        self.discriminator = None

        if env_entry_list is not None:
            self.env_entry_list = env_entry_list

    @property
    def env_entry_list(self):
        r"""Gets the env_entry_list of this ListBusinessEnvResponse.

        环境列表。

        :return: The env_entry_list of this ListBusinessEnvResponse.
        :rtype: list[:class:`huaweicloudsdkapm.v1.EnvEntry`]
        """
        return self._env_entry_list

    @env_entry_list.setter
    def env_entry_list(self, env_entry_list):
        r"""Sets the env_entry_list of this ListBusinessEnvResponse.

        环境列表。

        :param env_entry_list: The env_entry_list of this ListBusinessEnvResponse.
        :type env_entry_list: list[:class:`huaweicloudsdkapm.v1.EnvEntry`]
        """
        self._env_entry_list = env_entry_list

    def to_dict(self):
        import warnings
        warnings.warn("ListBusinessEnvResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListBusinessEnvResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
