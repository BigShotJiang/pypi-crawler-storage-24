use diesel::prelude::*;

use super::super::models::ArchivedJobRow;
use super::super::schema::archived_jobs;
use super::PostgresStorage;
use crate::error::Result;
use crate::job::{Job, JobStatus};

impl PostgresStorage {
    pub fn archive_old_jobs(&self, cutoff_ms: i64) -> Result<u64> {
        let mut conn = self.conn()?;

        let archivable_statuses = format!(
            "{}, {}, {}",
            JobStatus::Complete as i32,
            JobStatus::Dead as i32,
            JobStatus::Cancelled as i32,
        );

        conn.transaction(|conn| {
            let affected = diesel::sql_query(format!(
                "INSERT INTO archived_jobs SELECT * FROM jobs \
                 WHERE status IN ({archivable_statuses}) AND completed_at IS NOT NULL AND completed_at < $1 \
                 ON CONFLICT (id) DO NOTHING",
            ))
            .bind::<diesel::sql_types::BigInt, _>(cutoff_ms)
            .execute(conn)?;

            diesel::sql_query(format!(
                "DELETE FROM jobs WHERE status IN ({archivable_statuses}) AND completed_at IS NOT NULL AND completed_at < $1",
            ))
            .bind::<diesel::sql_types::BigInt, _>(cutoff_ms)
            .execute(conn)?;

            Ok(affected as u64)
        })
    }

    pub fn list_archived(&self, limit: i64, offset: i64) -> Result<Vec<Job>> {
        let mut conn = self.conn()?;

        let rows: Vec<ArchivedJobRow> = archived_jobs::table
            .order(archived_jobs::completed_at.desc())
            .limit(limit)
            .offset(offset)
            .select(ArchivedJobRow::as_select())
            .load(&mut conn)?;

        Ok(rows
            .into_iter()
            .map(|row| Job {
                id: row.id,
                queue: row.queue,
                task_name: row.task_name,
                payload: row.payload,
                status: JobStatus::from_i32(row.status).unwrap_or(JobStatus::Pending),
                priority: row.priority,
                created_at: row.created_at,
                scheduled_at: row.scheduled_at,
                started_at: row.started_at,
                completed_at: row.completed_at,
                retry_count: row.retry_count,
                max_retries: row.max_retries,
                result: row.result,
                error: row.error,
                timeout_ms: row.timeout_ms,
                unique_key: row.unique_key,
                progress: row.progress,
                metadata: row.metadata,
                cancel_requested: row.cancel_requested != 0,
                expires_at: row.expires_at,
                result_ttl_ms: row.result_ttl_ms,
                namespace: row.namespace,
            })
            .collect())
    }
}
