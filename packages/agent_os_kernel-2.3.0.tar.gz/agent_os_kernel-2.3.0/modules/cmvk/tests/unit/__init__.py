"""Unit tests for CMVK."""
