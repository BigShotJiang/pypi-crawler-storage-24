from ._simple import (
    WideFlange,
    HalfFlange,
    DoubleFlange,
    Circle,
    Ellipse,
    Equigon,
    HollowRectangle,
    Angle,
    Channel,
    Pipe
)
from ._rectangle import Rectangle
from ._asbi import SingleCellGirder, create_asbi

from ._rebar import Rebar
from pathlib import Path
import json

def _shape_units(source_length):
    return {
        "A"  :     source_length**2 ,
        "Ix" :     source_length**4 ,
        "Iy" :     source_length**4 ,
        "J"  :     source_length**4 ,
        "Cw" :     source_length**6 ,
        "Zx" :     source_length**3 ,
        "Zy" :     source_length**3 ,
        "Sx" :     source_length**3 ,
        "Sy" :     source_length**3 ,
        "rx" :     source_length ,
        "ry" :     source_length ,

        # Wide Flange and Channl
        "d"  :     source_length ,
        "k1"  :    source_length ,
        "h/tdes":  1 ,
        "b/tdes":  1 ,
        "tdes":    source_length ,
        "bf" :     source_length ,
        "tw" :     source_length ,
        "tf" :     source_length ,
        # Angle
        "b": source_length,
        "t":  source_length,
        "kdes": source_length
    }

def load_library(library_name):
    with open(Path(__file__).parents[1] / "assets"/(library_name+".json"), "r") as f:
        data = json.load(f)
    return data


def load_shape(identifier, library=None, units=None, fillet=False, **kwds):

    if units is None:
        import xara.units.english as _units
        units = _units
    elif isinstance(units, str):
        import xara.units as _units_mod
        units = getattr(_units_mod, units)


    with open(Path(__file__).parents[1] / "assets"/(library+".json"), "r") as f:
        data = json.load(f)

    source_length_name = data["units"]["length"]
    if source_length_name == "in":
        source_length_name = "inch"
    print(source_length_name)
    source_length = getattr(units, source_length_name)
    # target_length = getattr(units, units.Length)
    shape_units = _shape_units(source_length)
    
    shape_data = None
    for shape in data["shapes"]:
        if shape["label"].lower() == identifier.lower():
            shape_name = shape["shape"]
            shape_data = {
                k: v*shape_units.get(k,1) for k, v in shape["dimensions"].items() if v is not None
            }
            break

    if shape_data is None:
        raise ValueError(f"Cannot find section with identifier {identifier}")

    
    if shape_name == "SingleFlange":
        return HalfFlange(d=shape_data["d"],
                          b=shape_data["bf"],
                          tf=shape_data["tf"],
                          tw=shape_data["tw"],
                          k=shape_data.get("k1", None),
                          **kwds)

    elif shape_name == "DoubleFlange":
        if fillet and "k1" in shape_data and shape_data["k1"]:
            k1 = shape_data["k1"] - 1/8*units.inch
        else:
            k1 = None
        if fillet and "kdes" in shape_data and shape_data["kdes"]:
            k = shape_data["kdes"] - 1/8*units.inch
        else:
            k = None
        return WideFlange(d=shape_data["d"],
                          b=shape_data["bf"],
                          tf=shape_data["tf"],
                          tw=shape_data["tw"],
                          k=k,
                          k1=k1,
                          **kwds)

    elif shape_name == "Angle":
        if shape_data["tf"] != shape_data["tw"]:
            raise ValueError(f"Cannot create Angle section with tf != tw (tf={shape_data['tf']}, tw={shape_data['tw']})")
        return Angle(d=shape_data["d"],
                     b=shape_data["b"],
                     t=shape_data["tf"],
                    #  k=shape_data["kdes"],
                     **kwds)

    elif shape_name == "Channel":

        if fillet and "kdes" in shape_data and shape_data["kdes"]:
            k = shape_data["kdes"] - 1/8*units.inch
        else:
            k = None
        return Channel(d=shape_data["d"],
                       b=shape_data["bf"],
                       tf=shape_data["tf"],
                       tw=shape_data["tw"],
                       k=k,
                       sf=2/12,
                       **kwds)

    elif shape_name == "HollowRectangle":
        return HollowRectangle(d=shape_data["ht"],
                               b=shape_data["b"],
                               t=shape_data["tf"],
        )

    else:
        raise ValueError(f"Cannot create section from identifier {identifier}")



def from_aisc(identifier: str, units=None, fillet=True, **kwds):
    """Create a homogeneous cross-section from an AISC identifier.

    Parameters:
        identifier: str
            AISC section identifier (e.g., "W10x15").

        units: object
            Units object to use for conversion (default: ``english``).
        
        fillet: bool
            Whether to include fillets in the section geometry (default: True).

        **kwds:
            Additional keyword arguments for the section constructor.

    Returns:
        section: a subclass of :class:`~xsection.PolygonSection` representing the cross-section.
    """
    # return load_shape(identifier, library="AISC16", units=units, fillet=fillet, **kwds)
    
    if units is None:
        import xara.units.english as _units
        units = _units
    elif isinstance(units, str):
        import xara.units as _units_mod
        units = getattr(_units_mod, units)

    shape_data = aisc_data(identifier, units=units)

    if shape_data is None:
        raise ValueError(f"Cannot find section with identifier {identifier}")

    if identifier[0:2] == "WT":
        return HalfFlange(d=shape_data["d"],
                          b=shape_data["bf"],
                          tf=shape_data["tf"],
                          tw=shape_data["tw"],
                          k=shape_data.get("k1", None),
                          **kwds)

    elif identifier[0] == "W":
        if fillet and "k1" in shape_data and shape_data["k1"]:
            k1 = shape_data["k1"] - 1/8*units.inch
        else:
            k1 = None
        if fillet and "kdes" in shape_data and shape_data["kdes"]:
            k = shape_data["kdes"] - 1/8*units.inch
        else:
            k = None
        return WideFlange(d=shape_data["d"],
                          b=shape_data["bf"],
                          tf=shape_data["tf"],
                          tw=shape_data["tw"],
                          k=k,
                          k1=k1,
                          **kwds)

    elif identifier[0] == "L":
        return Angle(d=shape_data["d"],
                     b=shape_data["b2"],
                     t=shape_data["t"],
                     k=shape_data["kdes"],
                     **kwds)

    elif identifier[0] == "C":

        if fillet and "kdes" in shape_data and shape_data["kdes"]:
            k = shape_data["kdes"] - 1/8*units.inch
        else:
            k = None
        return Channel(d=shape_data["d"],
                       b=shape_data["bf"],
                       tf=shape_data["tf"]*0.9,
                       tw=shape_data["tw"],
                       k=k,
                       sf=2/12,
                       **kwds)

    elif identifier[:3] == "HSS":
        return HollowRectangle(d=shape_data["h/tdes"]*shape_data["tdes"],
                               b=shape_data["b/tdes"]*shape_data["tdes"],
                               t=shape_data["tdes"],
        )

    else:
        raise ValueError(f"Cannot create section from identifier {identifier}")



def aisc_data(identifier: str, props="", units=None)->dict:
    """Return a dictionary of cross section properties from the AISC database.

    To automatically create a Section object from the AISC database, use the
    :func:`~xsection.library.from_aisc` function.

    Parameters:
        identifier: str
            The name of the section (e.g., "W10x15").
        units: object
            Units object to use for conversion (default: ``english``).

    Example:

    >>> from xsection.library import aisc_data
    >>> aisc_data("W12x136")
    >>> # {'d': 13.4, 'bf': 12.4, 'tw': 0.79, 'tf': 1.25, 'A': 39.9, 'Ix': 1240.0, 'Iy': 398.0, 'kdes': 1.85}
    """

    if units is None:
        import xara.units.english as _units
        units = _units

    from shps.frame.shapes.aisc_imperial import imperial
    SectData = imperial[identifier.upper()]


    if props == "simple":
        props = ""
        return

    elif props:
        props = props.replace(" ", "").split(",")
        sectData = {k: v for k, v in SectData.items() if k in props}
        if "I" in props:
            sectData.update({"I": SectData["Ix"]})
        return sectData

    for k,v in list(SectData.items()):
        try:
            SectData[k] = float(v)
        except:
            continue

    UNITS = [
        ("A"  ,     units.inch**2 ),
        ("Ix" ,     units.inch**4 ),
        ("Iy" ,     units.inch**4 ),
        ("J"  ,     units.inch**4 ),
        ("Cw" ,     units.inch**6 ),
        ("Zx" ,     units.inch**3 ),
        ("Zy" ,     units.inch**3 ),
        ("Sx" ,     units.inch**3 ),
        ("Sy" ,     units.inch**3 ),
        ("rx" ,     units.inch ),
        ("ry" ,     units.inch ),
        # Wide Flange and Channel
        ("d"  ,     units.inch ),
        ("k1"  ,    units.inch ),
        ("h/tdes",  1 ),
        ("b/tdes",  1 ),
        ("tdes",    units.inch ),
        ("bf" ,     units.inch ),
        ("tw" ,     units.inch ),
        ("tf" ,     units.inch ),
        # Angle
        ("b2", units.inch),
        ("t",  units.inch),
        ("kdes", units.inch)
    ]

    return {
        k: SectData[k]*scale
        for k, scale in UNITS if k in SectData and isinstance(SectData[k], (float, int))
    }

# Alias for backwards compatibility
load_aisc = aisc_data



if __name__ == "__main__":
    import veux
    d  = 100
    tw = 3
    bf = 75
    tf = 3

    mesh = WideFlange(d=d, b=bf, t=tf, tw=tw).create_shape()

    print(mesh.summary())

#   from shps.frame.solvers.plastic import PlasticLocus
#   PlasticLocus(mesh).plot()#(phi=0.5, ip=5)
#   import matplotlib.pyplot as plt
#   plt.show()

    artist = veux.create_artist(((mesh.mesh.nodes, mesh.mesh.cells())), ndf=1)

    field = mesh.torsion.warping()
    field = {node: value for node, value in enumerate(field)}

    artist.draw_surfaces(field = field)
    artist.draw_origin()
#   R = artist._plot_rotation
#   artist.canvas.plot_vectors([R@[*geometry.centroid, 0] for i in range(3)], R.T)
    artist.draw_outlines()
    veux.serve(artist)
