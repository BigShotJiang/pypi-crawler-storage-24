from xsection.library import load_shape, load_library
from xsection.plotting import draw_surfaces, plt
import fnmatch 

if __name__ == "__main__":
    import argparse
    # cmd list AISC16 ; list all shapes in AISC16 library
    # cmd list AISC16 WideFlange ; list all wide flange shapes in AISC16 library
    # cmd show AISC16 W14x48 ; show the W14x48 shape from AISC16 library
    parser = argparse.ArgumentParser(description="List or show shapes from the library")
    parser.add_argument("command", choices=["list", "show"], help="Command to execute")
    parser.add_argument("library", help="Library name")
    parser.add_argument("shape", nargs="?", help="Shape name (required for 'show' command)")
    args = parser.parse_args()

    if args.command == "list":
        data = load_library(args.library)
        if args.shape:
            shapes = [s for s in data["shapes"] if fnmatch.fnmatch(s["label"], args.shape)]
        else:
            shapes = data["shapes"]
        for shape in shapes:
            print(shape["label"])
    elif args.command == "show":
        if not args.shape:
            print("Shape name is required for 'show' command")
            exit(1)
        shape = load_shape(args.shape, library=args.library)
        print(shape.summary())
        fig, ax = draw_surfaces(shape)
        fig.suptitle(f"{args.library} {args.shape}")
        plt.show()
