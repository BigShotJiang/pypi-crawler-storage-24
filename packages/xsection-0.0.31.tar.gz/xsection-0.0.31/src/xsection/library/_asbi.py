
from xsection.polygon import PolygonSection
from xsection.library._simple import _SimpleShape
import numpy as np

# 
# AASHTO-PCI-ASBI Single-Cell Box Girder Sections
#
#
#     |          Symmetric               |<-- br6    ---------------------->|
#                                        |    br5                    |      .
#                                        |    br4                |   .      .
#                                        |    br3            |   .   .      .
#                                        |    br2         |  .   .   .      .
#                                        |    br1         .  .   .   .      .
#                                               .         .  .   .   .      .
#                                               .         .  .   .   .      .
#                                        z      .         .  .   .   .      .
#                                        ^      .         .  .   .   .      .
#                                        |      .         .  .   .   .      .
# _   |_________________________________________|_________|__|___|___|______|
#     |-------____      _________.--------------._________   |   |,..-------|
#                 \    /                                   \ |  /
# d                \  /                  |                  \| /
#                   \ \                  |                  / /
#                    \ `----._________________________,----  /
# _                   \__________________+__________________/  ---> y
#                                        |   bs3      .    .|
#                                        |   bs2      .    |
#                                        |   bs1      |



class SingleCellGirder(_SimpleShape):
    """Single-cell box girder

    Standard AASHTO-PCI-ASBI sections are available through the :py:func:`create_asbi` function.
    """

    d: float
    "Depth of the girder"
    br6: float
    "Distance from the centerline to the outer face of the top flange"
    br5: float
    "Distance from the centerline to the start of the overhang (point 5) on the top flange"
    br4: float
    "Distance from the centerline to the outer start of the web (point 4) on the top flange"
    br3: float
    "Distance from the centerline to the inner start of the web (point 3) on the top flange"
    br2: float
    "Distance from the centerline to the start of the fillet (point 2) on the top flange"
    br1: float
    "Distance from the centerline to the inner face of the top flange (point 1) on the top flange"
    tr5: float
    "Thickness of the top flange at point 5"
    tr4: float
    "Thickness of the top flange at point 4"
    tr3: float
    "Thickness of the top flange at point 3"
    tr2: float
    "Thickness of the top flange at point 2"
    tr1: float
    "Thickness of the top flange at point 1"
    bs3: float
    "Distance from the centerline to the outer face of the soffit"
    bs2: float
    "Distance from the centerline to the start of the overhang (point 2) on the soffit"
    bs1: float
    "Distance from the centerline to the inner face of the soffit (point 1) on the soffit"
    ts1: float
    "Thickness of the soffit at point 1"
    ts2: float
    "Thickness of the soffit at point 2"

    _parameters = [
        "d",
        "br6",
        "br5",
        "br4",
        "br3",
        "br2",
        "br1",
        "tr5",
        "tr4",
        "tr3",
        "tr2",
        "tr1",
        "bs3",
        "bs2",
        "bs1",
        "ts1",
        "ts2",
    ]
    def __init__(self,
                 d      : float,
                 # Roadway
                 br6    : float,
                 br4    : float,
                 br3    : float,
                 br1    : float,
                 tr5    : float,
                 tr4    : float,
                 tr3    : float,
                 tr1    : float,
                 # Soffit
                 bs3    : float,
                 ts1    : float = None,

                 br5    : float = None,
                 bs1    : float = None,
                 bs2    : float = None,
                 ts2    : float = None,

                 br2   : float = None,
                 tr2   : float = None,
                 web_slope : float = None,
                 sof_run : float = None,
                 rr2   : float = 0.0,
                 rr1   : float = 0.0,
        mesh_scale     : float = 1/2,
        **kwds
        ):

        if web_slope is not None:
            # Compute br2 and tr2 from the web slope
            bs2 = br3 - web_slope*(d - (tr3 + ts2 + ts1))
            bs1 = bs2 - sof_run

        if rr1 > 0.0:
            raise NotImplementedError("Roundings are not implemented yet")
        if rr2 > 0.0:
            raise NotImplementedError("Roundings are not implemented yet")

        self.d = d
        self.br6 = br6
        self.br5 = br5
        self.br4 = br4
        self.br3 = br3
        self.br2 = br2
        self.br1 = br1
        self.tr5 = tr5
        self.tr4 = tr4
        self.tr3 = tr3
        self.tr2 = tr2
        self.tr1 = tr1
        self.bs3 = bs3
        self.bs2 = bs2
        self.bs1 = bs1
        self.ts1 = ts1
        self.ts2 = ts2

        self.width_top = br6*2
        self.width_bot = bs3*2



        mesh_size = tr1*mesh_scale

        H = d

        # 1) exterior ring (cw)
        exterior = np.array([
            (-br6,         H),
            (+br6,         H),
            (+br6,         H-tr5),
        ] + ([
            (+br5,         H-tr5),  #
        ] if br5 is not None else []) + [
            (+br4,         H-tr4),
            (+bs3,         0),
            (-bs3,         0),
            (-br4,         H-tr4),
        ] + ([
            (-br5,         H-tr5),  #
        ] if br5 is not None else []) + [
            (-br6,         H-tr5),
        ])

        interiors = [np.array([
                (-br3, H-tr3),
            ] + ([
                (-br2, H-tr2), # fillet
            ] if tr2 is not None else []) + [
                (-br1, H-tr1),
                (+br1, H-tr1),
            ] + ([
                (+br2, H-tr2), # fillet
            ] if tr2 is not None else []) + [
                (+br3, H-tr3),
            ] + ([
                (+bs2,  +ts2),
            ] if ts2 is not None else []) + [
                (+bs1,  +ts1),
                (-bs1,  +ts1),
            ] + ([
                (-bs2,  +ts2),
            ] if ts2 is not None else [])
        )]
        

        super().__init__(exterior, interiors, mesh_size=mesh_size, **kwds)

    def _annotate_views(self):
        return [
            "main",
            "detail 1"
        ]

    def _annotate_parameters(self, view=None):
        if view is None:
            parameters = [
                "br6",
                "br5",
                "bs3",
                "d",
                "tr5",
                "ts1",
                "tr1"
            ]
            if self.bs2 is not None:
                parameters.append("bs1")
            return parameters

        elif view == "detail 1":
            parameters = [
                "ts2",
                "br4",
                "br3",
                "br2",
                "tr4",
                "tr3"
            ]
            if self.bs2 is None:
                parameters.append("bs1")
            if self.tr2 is not None:
                parameters.append("tr2")
            return parameters

    def _annotate_view(self, view):
        if view == None:
            return [
                (-self.br6, self.d), # top left
                (self.br6,       0), # bot right
            ]
        
        elif view == "detail 1":
            return [
                (0, 0),
                (self.br6, self.d),
            ]
        else:
            return None

    def _annotate_dimension(self, key):
        H = self.d

        # Skip if the underlying attribute is None
        val = getattr(self, key, None)
        if val is None:
            return None

        br1 = self.br1
        br3 = self.br3
        br4 = self.br4
        bs1 = self.bs1

        dims = {
            # Full depth
            "d":   (((-self.br6, 0), (-self.br6, H)),                 (-1, 0), "inside"),

            # Top flange horizontal widths (from centerline)
            "br6": (((-self.br6, H),            (0, H)),              (0,  1.0), "inside"),
            "br5": (((0, H-self.tr5),    (self.br5, H-self.tr5)),     (0,  1.0), "inside"),
            "br4": (((0, H-self.tr4),    (self.br4, H-self.tr4)),     (0,  3), "inside"),
            "br3": (((0, H-self.tr3),    (br3, H-self.tr3)),          (0,  1.5), "inside"),
            "br2": (((0, H-self.tr2),    (self.br2, H-self.tr2)),     (0,  -0.5), "inside") if self.tr2 is not None else None,
            "br1": (((0, H-self.tr1),    (br1, H-self.tr1)),     (0, -1), "inside"),

            # Soffit horizontal widths (from centerline)
            "bs3": (((-self.bs3, 0),            (0, 0)),              (0, -1), "inside"),
            "bs2": (((0, self.ts2),      (self.bs2, self.ts2)),       (0, -1), "inside"),
            "bs1": (((0, self.ts1),      (bs1, self.ts1)),       (0, -1), "inside"),

            # Top flange vertical thicknesses
            "tr5": (((self.br6, H),      (self.br6, H-self.tr5)),    ( 1, 0), "-outside"),
            "tr4": (((br4, H),           (br4, H-self.tr4)),         ( 1.2, 0), "-outside"),
            "tr3": (((self.br3, H),      (self.br3, H-self.tr3)),    ( 1, 0), "-outside"),
            "tr2": (((self.br2, H),      (self.br2, H-self.tr2)),    (-1, 0), "-outside") if self.tr2 is not None else None,
            "tr1": (((self.br1, H),      (self.br1, H-self.tr1)),    (-0.5, 0), "-outside"),

            # Soffit vertical thicknesses
            "ts1": (((self.bs1, 0),      (self.bs1, self.ts1)),      (1, 0), "-outside"),
            "ts2": (((self.bs2, 0),      (self.bs2, self.ts2)),      ( 1, 0), "-outside"),
        }

        if key not in dims or dims[key] is None:
            return None


        endpoints, offset, style = dims[key]
        # Guard against any None coordinates leaking through from None attributes
        if any(v is None for pt in endpoints for v in pt):
            return None

        return endpoints, offset, style


class MultiCellGirder(SingleCellGirder):
    """Multi-cell box girder with explicit internal webs.

    `web_centers` are signed y-coordinates of the internal-web centerlines.
    `web_widths` are the corresponding web thicknesses.
    """

    web_centers: list
    "Signed y-coordinates of the internal-web centerlines"
    web_widths: list
    "Widths of the internal webs"

    _parameters = SingleCellGirder._parameters + ["web_centers", "web_widths"]

    @staticmethod
    def _same_point(p, q, tol=1e-12):
        return max(abs(p[0] - q[0]), abs(p[1] - q[1])) <= tol

    @classmethod
    def _dedupe_points(cls, pts, tol=1e-12):
        out = []
        for p in pts:
            p = np.asarray(p, dtype=float)
            if not out or not cls._same_point(out[-1], p, tol):
                out.append(p)
        return out

    @staticmethod
    def _point_on_polyline(poly, y, tol=1e-12):
        poly = [np.asarray(p, dtype=float) for p in poly]

        if y < poly[0][0] - tol or y > poly[-1][0] + tol:
            raise ValueError(
                f"Requested y={y} lies outside the polyline domain "
                f"[{poly[0][0]}, {poly[-1][0]}]."
            )

        for p0, p1 in zip(poly[:-1], poly[1:]):
            y0, z0 = p0
            y1, z1 = p1

            if y0 - tol <= y <= y1 + tol:
                if abs(y - y0) <= tol:
                    return np.array([y0, z0], dtype=float)
                if abs(y - y1) <= tol:
                    return np.array([y1, z1], dtype=float)
                if abs(y1 - y0) <= tol:
                    raise ValueError("Polyline clipping requires strictly monotone y-values.")
                t = (y - y0) / (y1 - y0)
                return np.array([y, z0 + t * (z1 - z0)], dtype=float)

        return np.array(poly[-1], dtype=float)

    @classmethod
    def _clip_polyline(cls, poly, y_left, y_right, tol=1e-12):
        if y_right < y_left - tol:
            raise ValueError("Polyline clipping requires y_left <= y_right.")

        poly = [np.asarray(p, dtype=float) for p in poly]
        out = [cls._point_on_polyline(poly, y_left, tol)]

        for p in poly[1:-1]:
            if y_left + tol < p[0] < y_right - tol:
                out.append(np.array(p, dtype=float))

        out.append(cls._point_on_polyline(poly, y_right, tol))
        return cls._dedupe_points(out, tol)

    @classmethod
    def _cell_polygon(
        cls,
        top_poly,
        bottom_poly,
        y_top_left,
        y_bot_left,
        y_top_right,
        y_bot_right,
        tol=1e-12,
    ):
        top = cls._clip_polyline(top_poly, y_top_left, y_top_right, tol)
        bottom = cls._clip_polyline(bottom_poly, y_bot_left, y_bot_right, tol)

        poly = list(top)
        poly.append(cls._point_on_polyline(bottom_poly, y_bot_right, tol))
        poly.extend(reversed(bottom[:-1]))

        return np.asarray(cls._dedupe_points(poly, tol), dtype=float)

    def __init__(
        self,
        d      : float,
        # Roadway
        br6    : float,
        br4    : float,
        br3    : float,
        tr5    : float,
        tr4    : float,
        tr3    : float,
        tr1    : float,
        # Soffit
        bs3    : float,
        ts1    : float = None,

        br5    : float = None,
        br1    : float = None,
        bs1    : float = None,
        bs2    : float = None,
        ts2    : float = None,

        br2    : float = None,
        tr2    : float = None,
        web_slope : float = None,
        sof_run   : float = None,
        rr2    : float = 0.0,
        rr1    : float = 0.0,
        mesh_scale : float = 1/2,
        *,
        web_centers = None,
        web_widths  = None,
        **kwds
    ):

        if web_centers is None:
            web_centers = []
        if web_widths is None:
            web_widths = []

        if web_slope is not None:
            # Compute br2 and tr2 from the web slope
            bs2 = br3 - web_slope * (d - (tr3 + ts2 + ts1))
            bs1 = bs2 - sof_run

        if rr1 > 0.0:
            raise NotImplementedError("Roundings are not implemented yet")
        if rr2 > 0.0:
            raise NotImplementedError("Roundings are not implemented yet")

        if len(web_centers) != len(web_widths):
            raise ValueError("web_centers and web_widths must have the same length.")
        if bs1 is None or ts1 is None:
            raise ValueError("bs1 and ts1 are required to define the inner soffit.")
        if ts2 is not None and bs2 is None:
            raise ValueError("bs2 must be provided when ts2 is provided.")

        H = d
        y_bot_outer = bs2 if ts2 is not None else bs1

        top_poly = [
            (-br3, H - tr3),
        ] + ([
            (-br2, H - tr2),
        ] if tr2 is not None else []) + ([
            (-br1, H - tr1),
            (+br1, H - tr1),
        ] if br1 is not None else []) + ([
            (+br2, H - tr2),
        ] if tr2 is not None else []) + [
            (+br3, H - tr3),
        ]

        bottom_poly = ([
            (-bs2, ts2),
        ] if ts2 is not None else []) + [
            (-bs1, ts1),
            (+bs1, ts1),
        ] + ([
            (+bs2, ts2),
        ] if ts2 is not None else [])

        # Sort web definitions left-to-right
        webs = sorted((float(c), float(w)) for c, w in zip(web_centers, web_widths))

        # Every internal web must fit inside the clear void for the full depth.
        clear_half_width = min(br3, y_bot_outer)
        web_faces = []

        for c, w in webs:
            if w <= 0.0:
                raise ValueError("All web widths must be strictly positive.")

            y_left = c - 0.5 * w
            y_right = c + 0.5 * w

            if y_left <= -clear_half_width or y_right >= clear_half_width:
                raise ValueError(
                    "Every internal web must lie inside the clear void over the full depth."
                )

            web_faces.append((y_left, y_right))

        for (_, prev_right), (next_left, _) in zip(web_faces[:-1], web_faces[1:]):
            if next_left <= prev_right:
                raise ValueError("Internal webs overlap or leave zero-width cells.")

        # Persist the same scalar attributes as SingleCellGirder
        self.d = d
        self.br6 = br6
        self.br5 = br5
        self.br4 = br4
        self.br3 = br3
        self.br2 = br2
        self.br1 = br1
        self.tr5 = tr5
        self.tr4 = tr4
        self.tr3 = tr3
        self.tr2 = tr2
        self.tr1 = tr1
        self.bs3 = bs3
        self.bs2 = bs2
        self.bs1 = bs1
        self.ts1 = ts1
        self.ts2 = ts2

        self.web_centers = [c for c, _ in webs]
        self.web_widths = [w for _, w in webs]
        self.num_webs = len(self.web_centers)
        self.num_cells = self.num_webs + 1

        self.width_top = br6 * 2
        self.width_bot = bs3 * 2

        # Also resolve the smallest internal web in the mesh.
        mesh_size = min([tr1] + self.web_widths) * mesh_scale

        exterior = np.array([
            (-br6,         H),
            (+br6,         H),
            (+br6,         H - tr5),
        ] + ([
            (+br5,         H - tr5),
        ] if br5 is not None else []) + [
            (+br4,         H - tr4),
            (+bs3,         0),
            (-bs3,         0),
            (-br4,         H - tr4),
        ] + ([
            (-br5,         H - tr5),
        ] if br5 is not None else []) + [
            (-br6,         H - tr5),
        ], dtype=float)

        # Each cell is one interior polygon. Internal webs are the concrete
        # left between adjacent cell polygons.
        left_bounds = [(-br3, -y_bot_outer)] + [(yr, yr) for _, yr in web_faces]
        right_bounds = [(yl, yl) for yl, _ in web_faces] + [(+br3, +y_bot_outer)]

        interiors = [
            self._cell_polygon(
                top_poly,
                bottom_poly,
                y_top_left=ytl,
                y_bot_left=ybl,
                y_top_right=ytr,
                y_bot_right=ybr,
            )
            for (ytl, ybl), (ytr, ybr) in zip(left_bounds, right_bounds)
        ]

        _SimpleShape.__init__(self, exterior, interiors, mesh_size=mesh_size, **kwds)

_MetricKeys = {
    "1800-1",
    "1800-2",
    "2100-1", # TODO(SS)
    "2100-2", # TODO(SS)
    "2400-1", # TODO(SS,BC)
    "2400-2", # TODO(SS,BC)
    "2700-1", #
    "2700-2", # TODO(BC)
    "3000-1", # NOTE: Only BC
    "3000-2", # TODO(BC)
}

# https://asbi-assoc.org/wp-content/uploads/2023/07/Box-Girder-Segments-PCIASBIEnglish.pdf

_EnglishKeys = {
    "6-1",
    "6-2",
    "7-1",
    "7-2",
    "8-1",
    "8-2",  # SS,BC
    "9-1",  # BC
    "9-2",  # BC
    "10-1", # BC
    "10-2", # BC
}


def create_asbi(name, units=None, fillet=False, **kwds)->SingleCellGirder:
    """
    Create a single-cell box girder section from the AASHTO-PCI-ASBI specification.

    Parameters:
        identifier: str
            Identifier with the form <type>-<depth>-<variant>+<overhang>
        units: object


    https://asbi-assoc.org/wp-content/uploads/2023/07/Box-Girder-Segments-PCIASBIMetric.pdf
    https://asbi-assoc.org/wp-content/uploads/2023/07/Box-Girder-Segments-PCIASBIEnglish.pdf
    """

    key = name.split("+")[0]
    construction = key.split("-")[0]
    key = key[len(construction)+1:]

    if fillet:
        raise NotImplementedError

    if "+" in name:
        A = float(name.split("+")[1])
        overhang = True 
    else:
        A = 0.0
        overhang = False


    if units is None:
        if key in _MetricKeys:
            import xara.units.si as units


    shape = None

    match construction:
        case "SS":
            # Span-by-span
            match key:
                case "1800-1":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1361+1200+269+1370+A)*units.mm,
                        br5=(1361+1200+269+1370)*units.mm if overhang else None,
                        br4=(1361+1200+269)*units.mm,
                        br3=(1361+1200)*units.mm,
                        br1=1361*units.mm,
                        tr5=225*units.mm,
                        tr4=350*units.mm,
                        tr3=350*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2061+189)*units.mm,
                        bs1= 2061*units.mm,
                        ts1= 200*units.mm,
                        **kwds,
                    )
                case "1800-2":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1607+1500+323+1970+A)*units.mm,
                        br5=(1607+1500+323+1970)*units.mm if overhang else None,
                        br4=(1607+1500+323)*units.mm,
                        br3=(1607+1500)*units.mm,
                        br1=1607*units.mm,
                        tr5=225*units.mm,
                        tr4=350*units.mm,
                        tr3=350*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2607+243)*units.mm,
                        bs1= 2607*units.mm,
                        ts1= 200*units.mm,
                        **kwds,
                    )
        case "BC":
            # Balanced cantilever construction with raised soffit
            match key:
                case "1800-1":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1255+1200+323+1422+A)*units.mm,
                        br5=(1255+1200+323+1422)*units.mm if overhang else None,
                        br4=(1255+1200+323)*units.mm,
                        br3=(1255+1200)*units.mm,
                        br1=1255*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2107+143)*units.mm,
                        bs2= 2107*units.mm,
                        bs1=(2107-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds,
                    )
                case "1800-2":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1528+1500+350+2022+A)*units.mm,
                        br5=(1528+1500+350+2022)*units.mm if overhang else None,
                        br4=(1528+1500+350)*units.mm,
                        br3=(1528+1500)*units.mm,
                        br1=1528*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2680+170)*units.mm,
                        bs2= 2680*units.mm,
                        bs1=(2680-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds,
                    )
                case "2100-1":
                    # Page 7
                    shape = SingleCellGirder(
                        d=2100*units.mm,
                        br6=(1228+1200+350+1422+A)*units.mm,
                        br5=(1228+1200+350+1422)*units.mm if overhang else None,
                        br4=(1228+1200+350)*units.mm,
                        br3=(1228+1200)*units.mm,
                        br1=1228*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(1960+170)*units.mm,
                        bs2= 1960*units.mm,
                        bs1=(1960-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )

                case "2100-2":
                    shape = SingleCellGirder(
                        d=2100*units.mm,
                        br6=(1501+1500+377+2022+A)*units.mm,
                        br5=(1501+1500+377+2022)*units.mm if overhang else None,
                        br4=(1501+1500+377)*units.mm,
                        br3=(1501+1500)*units.mm,
                        br1=1501*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2533+197)*units.mm,
                        bs2= 2533*units.mm,
                        bs1=(2533-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )

                case "2700-1":
                    shape = SingleCellGirder(
                        d=2700*units.mm,
                        br6=(1174+1200+404+1422+A)*units.mm,
                        br5=(1174+1200+404+1422)*units.mm if overhang else None,
                        br4=(1174+1200+404)*units.mm,
                        br3=(1174+1200)*units.mm,
                        br1=1174*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(1666+224)*units.mm,
                        bs2= 1666*units.mm,
                        bs1=(1666-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )
                case "3000-1":
                    shape = SingleCellGirder(
                        d=3000*units.mm,
                        br6=(1147+1200+431+1422+A)*units.mm,
                        br5=(1147+1200+431+1422)*units.mm if overhang else None,
                        br4=(1147+1200+431)*units.mm,
                        br3=(1147+1200)*units.mm,
                        br1=1147*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(1519+251)*units.mm,
                        bs2= 1519*units.mm,
                        bs1=(1519-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )

    if shape is None:
        raise ValueError(f"Unknown ASBI section: {name}")
    shape.units = units
    return shape