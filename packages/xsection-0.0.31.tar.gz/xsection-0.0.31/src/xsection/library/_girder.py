#
#                                ^ y
#                                |
# _  |_______________________________________________________|
#    |_____  _______________ _________ _______________  _____|
#          \ \             | |       | |             / /
#           \ \            | |   |   | |            / /
#            \ \___________| |_______| |___________/ /
# _           \__________________+__________________/  ---> x
#             |                                     |


from xsection.polygon import PolygonSection
from xsection.library._simple import _SimpleShape
import numpy as np

class GirderSection(_SimpleShape):
    _parameters = [
        "thickness_top",
        "thickness_bot",
        "height",
        "width_top",
        "width_webs",
        "web_spacing",
        "web_slope",
        "overhang",
    ]
    def __init__(self,
        thickness_top  : float,
        thickness_bot  : float,
        height         : float,
        width_top      : float,
        width_webs     : list,
        web_spacing    : float,
        web_slope      : float = 0.0,
        overhang       : float = None,
        mesh_scale     : float = 1/2,
        **kwds
        ):
        self.thickness_top  = thickness_top
        self.thickness_bot  = thickness_bot
        self.height         = height
        self.width_top      = width_top
        self.width_webs     = width_webs
        self.web_spacing    = web_spacing
        self.web_slope      = web_slope
        self.overhang       = overhang

        mesh_size = (min(thickness_bot, thickness_top, *width_webs))*mesh_scale

        t_top = self.thickness_top
        t_bot = self.thickness_bot
        H     = self.height
        Wt    = self.width_top
        tw    = self.width_webs
        sp    = self.web_spacing
        s     = self.web_slope
        oh    = self.overhang

        if len(tw) < 2:
            raise ValueError("need at least 2 webs")

        # clear height between flanges
        Ho = H - t_top
        Hi = Ho - t_bot
        # bottom‐flange width
        if oh is not None:
            Wb = Wt - 2*(oh + s*Ho)
        else:
            # fallback: make bottom flange same as top
            Wb = Wt

        # outer webs:
        x0 = -Wb/2 + tw[ 0]/2
        xN = +Wb/2 - tw[-1]/2

        # 1) exterior ring (ccw)
        exterior = np.array([
            # top flange
            (-Wt/2,         H),
            (+Wt/2,         H),
            (+Wt/2,         Ho),
            # Right web
            (xN + tw[-1]/2 + s*Ho,     Ho),  # down the right sloped web
            # (+Wb/2+t_bot*s,   t_bot),
            (+Wb/2,         0.0),
            (-Wb/2,         0.0),
            # (-Wb/2,         t_bot),
            (x0 - tw[ 0]/2 - s*Ho,     Ho),  # up the left sloped web
            (-Wt/2,         Ho),
        ])

        # compute web‐center x‐locations
        nweb = len(tw)
        if nweb > 2:
            # evenly spaced internal webs
            intern = np.linspace(x0 + sp, xN - sp, nweb-2)
            centers = np.hstack(([x0], intern, [xN]))
        else:
            centers = np.array([x0, xN])
        
        # 2) holes between webs
        interiors = []
        m = len(centers)-1
        for i in range(m):
            left  = centers[i]   + tw[i]/2
            right = centers[i+1] - tw[i+1]/2
            if right <= left:
                continue

            y0, y1 = t_bot, t_bot+Hi

            if i == 0:
                # leftmost gap: left side sloped
                hole = np.array([
                    ( left,         y0       ),
                    ( right,        y0       ),
                    ( right,        y1       ),
                    ( left - s*Hi,  y1       ),
                ], float)

            elif i == m-1:
                # rightmost gap: right side sloped
                hole = np.array([
                    ( left,         y0       ),
                    ( right,        y0       ),
                    ( right + s*Hi, y1       ),
                    ( left,         y1       ),
                ], float)

            else:
                # pure rectangle
                hole = np.array([
                    ( left, y0 ),
                    ( right, y0 ),
                    ( right, y1 ),
                    ( left, y1 ),
                ])

            interiors.append(np.array(list(reversed(hole))))



        super().__init__(exterior, interiors, mesh_size=mesh_size, **kwds)

    @property
    def d(self):
        return self.height

    def _annotate_parameters(self, view=None):
        params = []
        if view == "detail 1":
            return [
            ]

        for key in self._parameters:
            if key == "width_webs":
                for i in range(len(self.width_webs) - 2):
                    params.append(f"w_{i}")
            elif key == "width_top":
                params.append("b_r")
            elif key == "height":
                params.append("d")
            elif key == "thickness_top":
                params.append("t_r")
            elif key == "thickness_bot":
                params.append("t_s")
            elif key == "overhang":
                params.append("b_o")
            else:
                continue
                params.append(key)
        return params
    
    def _annotate_views(self):
        return [
            "main",
            "detail 1"
        ]
    
    def _annotate_view(self, view):
        if view == "main":
            return [
                (-self.width_top/2, self.height),
                (self.width_top/2, 0),
            ]
        elif view == "detail 1":
            return [
                (-self.width_top/2, self.height),
            ]
        else:
            return None

    def _annotate_dimension(self, key):
        t_top = self.thickness_top
        t_bot = self.thickness_bot
        H     = self.height
        Wt    = self.width_top
        tw    = self.width_webs
        sp    = self.web_spacing
        s     = self.web_slope
        oh    = self.overhang

        Ho = H - t_top
        Hi = Ho - t_bot

        if oh is not None:
            Wb = Wt - 2*(oh + s*Ho)
        else:
            Wb = Wt

        x0 = -Wb/2 + tw[0]/2
        xN = +Wb/2 - tw[-1]/2

        nweb = len(tw)
        if nweb > 2:
            intern = np.linspace(x0 + sp, xN - sp, nweb - 2)
            centers = np.hstack(([x0], intern, [xN]))
        else:
            centers = np.array([x0, xN])

        mid_y = t_bot + Hi / 2

        dims = {
            "d":             (((-Wt/2, 0),         (-Wt/2, H)),           (-2, 0),  "inside"),
            "b_r":           (((-Wt/2, H),         (Wt/2, H)),            (0, 1),   "inside"),
            "t_r":           (((Wt/2, H),          (Wt/2, Ho)),           (1, 0),   "+outside"),
            "t_s":           ((( Wb/2, 0),         ( Wb/2, t_bot)),       (1, 0),  "-outside"),
            "web_spacing":   (((centers[0], mid_y), (centers[1], mid_y)), (0, 0),   "inside"),
        }

        if oh is not None:
            web_top_x = x0 - tw[0]/2 - s*Ho
            dims["b_o"] = ((-Wt/2, Ho), (web_top_x, Ho)), (0,  0.75), "-outside"
        else:
            web_top_x = x0 - tw[0]/2

        # Hole widths between adjacent webs, measured at bottom of holes
        for i in range(len(centers) - 2):
            k = f"w_{i}"
            if i == 0:
                left = web_top_x
            else:
                left  = centers[i] #+ tw[i]/2
            right = centers[i+1] #- tw[i+1]/2
            if right <= left:
                continue
            y = t_bot
            dims[k] = ((left, y), (right, y)), (0, -1), "inside"

        if key not in dims:
            return None

        val = dims[key]
        if val is None:
            return None

        endpoints, offset, style = val
        if any(v is None for pt in endpoints for v in pt):
            return None

        return endpoints, offset, style