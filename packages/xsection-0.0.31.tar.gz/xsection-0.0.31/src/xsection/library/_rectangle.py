from xsection.library._simple import _SimpleShape
try:
    from jax import jit
    import jax.numpy as np
except ImportError:
    jit = lambda f: f
    import numpy as np
# import numpy as np
from itertools import product, count
from typing import Tuple


class Rectangle(_SimpleShape):
    """A rectanglular section.
    """
    b: float
    "Width of the section :math:`b`."
    d: float
    "Depth of the section :math:`d`."

    _parameters = ["b", "d", "mesh_scale"]
    def __init__(self, b, d, mesh_scale=None, centroid=None, **kwds):
        self.b = b
        self.d = d
        if centroid is None:
            centroid = np.zeros(2)

        self.mesh_scale = mesh_scale or 1/10

        mesh_size = min(b,d)*self.mesh_scale

        super().__init__(mesh_size=mesh_size,
                         interior=None,
                         exterior =  np.array([
                            [-b / 2,  -d / 2],
                            [ b / 2,  -d / 2],
                            [ b / 2,   d / 2],
                            [-b / 2,   d / 2],
                        ])-centroid,
                        **kwds)
    

    def create_plane_mesh(self, mesh_type):
        pass 

    # Rectangle
    def _annotate_dimension(self, key):
        b, d = self.b, self.d
        if key == "b":
            return ((-b/2,  d/2), (b/2,  d/2)), ( 0,  1), "inside"
        elif key == "d":
            return ((-b/2, -d/2), (-b/2, d/2)), (-1,  0), "inside"
        return None


@jit
def _rect_map(p0, p1, p3, xi, eta):
    e1 = p1 - p0
    e2 = p3 - p0
    return p0 + 0.5*(1.0 + xi)*e1 + 0.5*(1.0 + eta)*e2


def create_fibers(b, d, nx,ny):
    """
    Create a fiber mesh for a rectangle with dimensions b x d, using 9-node quadrilateral elements.
    """
    # nodes, elements = _mesh_r9(b, d, nx, ny)
    nodes, elements = block(ne=(nx, ny), nn=(3,3), corners=((-b/2, b/2), (-d/2, d/2)))

    _G3_PTS = np.array([-np.sqrt(3.0/5.0), 0.0, np.sqrt(3.0/5.0)])
    _G3_WTS = np.array([5.0/9.0, 8.0/9.0, 5.0/9.0])
    _quadrature = [
        ((xi, eta), (wx*wy)/4.0)
        for xi, wx in zip(_G3_PTS, _G3_WTS)
        for eta, wy in zip(_G3_PTS, _G3_WTS)
    ]

    fibers = []
    for element in elements:
        P = [nodes[i] for i in element[:4]] # Only use the corner nodes for mapping
        p0, p1, p3 = P[0], P[1], P[3]

        e1 = p1 - p0
        e2 = p3 - p0
        A = (np.abs(e1[0]*e2[1] - e1[1]*e2[0])).astype(float)
        for (xi, eta), w in _quadrature:
            r = _rect_map(p0, p1, p3, xi, eta)
            fibers.append([r[0], r[1], A*w])
    return fibers


def create_mesh(bdc, n):
    b, d, c = bdc
    nx,ny,nc = n

    return block(ne=(nx, ny), nn=(3,3), corners=((-b/2, b/2), (-d/2, d/2)))


def create_mesh_fibers(nodes, elements):
    """
    Create a fiber mesh for a rectangle with dimensions b x d, using 9-node quadrilateral elements.
    """
    # nodes, elements = _mesh_r9(b, d, nx, ny)

    _G3_PTS = np.array([-np.sqrt(3.0/5.0), 0.0, np.sqrt(3.0/5.0)])
    _G3_WTS = np.array([5.0/9.0, 8.0/9.0, 5.0/9.0])
    _quadrature = [
        ((xi, eta), (wx*wy)/4.0)
        for xi, wx in zip(_G3_PTS, _G3_WTS)
        for eta, wy in zip(_G3_PTS, _G3_WTS)
    ]

    fibers = []
    for element in elements:
        P = [nodes[i] for i in element[:4]] # Only use the corner nodes for mapping
        p0, p1, p3 = P[0], P[1], P[3]

        e1 = p1 - p0
        e2 = p3 - p0
        A = (np.abs(e1[0]*e2[1] - e1[1]*e2[0])).astype(float)
        for (xi, eta), w in _quadrature:
            r = _rect_map(p0, p1, p3, xi, eta)
            fibers.append([r[0], r[1], A*w])
    return fibers


def block(ne: Tuple[int,int],
          nn: Tuple[int,int],
          corners   = None,
          ): # -> nodes, elems
    """
    Use a regular subdivision of a parent master element to create
    a mesh within its perimeter.
    """
    if corners is None:
        corners = ((-1,1),(-1,1))


    ref_nodes = {
        1: (-1, -1),
        2: ( 1, -1),
        3: ( 1,  1),
        4: (-1,  1),
        5: ( 0, -1),
        6: ( 1,  0),
        7: ( 0,  1),
        8: (-1,  0),
        9: ( 0,  0)
    }
    quadratic = True


    #
    # 1. Create edge grid in natural coordinates (-1, 1)
    #
    xl, cells = grid(ne, nn, corners=corners)


    #
    # 2. Create internal nodes
    #
    taggen = filter(lambda i: i > len(xl) or i not in xl, count(1))

    for i in cells:
        elem = cells[i]
        conn = [
            elem[0],
            elem[nn[0]-1],
            elem[nn[0]+nn[1]-2],
            elem[-nn[0]+1]
        ]

        if quadratic:
            conn += [i for i in elem if i not in conn]

            cell_nodes={
                1: xl[elem[0]],
                2: xl[elem[nn[0]-1]],
                3: xl[elem[nn[0]+nn[1]-2]],
                4: xl[elem[-nn[0]+1]]
            }
            tag = next(taggen)
            xl[tag] = (
                (cell_nodes[1][0] + cell_nodes[3][0])/2,
                (cell_nodes[2][1] + cell_nodes[4][1])/2
            )
            conn.insert(9-1, tag)
        cells[i] = conn

    # 3. Renumber nodes and elements, return nodes in array form
    ia = {tag: i for i, tag in enumerate(sorted(xl.keys()))}
    xa = np.array([xl[i] for i in sorted(xl.keys())])
    ca = np.array([
         [ia[i] for i in cell] for cell in cells.values()
    ], dtype=int)


    return xa, ca



def grid(ne: Tuple[int,int], nn=(2,2), corners=((-1,1),(-1,1))):
    """
               |           ne[0] = 2       |

               |             | nn[0] = 3   |

          ---- +------+------+------+------+ ----
               |             |             |
               |             |             |
               |             |             | nn[1] = 2
               |             |             |
               |             |             |
               +------+------+------+------+ ----
               |             |             |
  ne[1] = 3    |             |             |
               |             |             |---------> s
               |             |             |
               |             |             |
               +------+------+------+------+
               |             |             |
               |             |             |
               |             |             |
               |             |             |
               |             |             |
          ---- +------+------+------+------+

    """
    nnx,nny = nn
    nex,ney = ne

    nx = nnx - 1
    ny = nny - 1

    cells = {
        k: [*(   (1+l) + i*nx + (j*ny+    0)*(nex*nx+1) for l in range(nnx)),
            *(    nnx  + i*nx + (j*ny+    l)*(nex*nx+1) for l in range(1,nny-1)),
            *(   (1+l) + i*nx + (j*ny+nny-1)*(nex*nx+1) for l in reversed(range(nnx))),
            *( -nex*nx + i*nx + (j*ny+nny-l)*(nex*nx+1) for l in range(1,nny-1))]

        for k,(j,i) in enumerate(product(range(ney), range(nex)))
    }

    used = {i for cell in cells.values() for i in cell}

    x, y = map(lambda n: np.linspace(*n[2], n[0]*(n[1]-1)+1), 
               ((nex,nnx,corners[0]),(ney,nny,corners[1])))

    nodes = {
        i+1: (xi, yi) for i,(yi,xi) in enumerate(product(y,x)) if i+1 in used
    }

    return nodes, cells

