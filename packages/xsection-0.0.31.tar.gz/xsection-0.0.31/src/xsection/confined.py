from xsection.composite import CompositeSection

class ConfinedSection(CompositeSection):
    def __init__(self, cover, core, steel=None, **kwds):
        self.cover = cover
        self.core = core
        self.steel = steel
        
        super().__init__([cover, core, *steel], **kwds)

