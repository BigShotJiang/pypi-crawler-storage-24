
from xsection.analysis import SaintVenantSectionAnalysis

import numpy as np 

try:
    from numba import njit as jit 
    from numba import prange
    jit(lambda x: x**2)(1.0)  # test if numba is available

except:
    prange = range
    def jit(*_, **__):
        def _decorator(func):
            return func
        return _decorator


@jit
def _hat(r):
    return np.array([[    0,-r[1], r[0]],
                     [ r[1],    0,    0],
                     [-r[0],    0,    0]])


def _strain_matrix(r, warp, A):
    A[:3,:3] = np.eye(3)
    A[:3,3:6] = _hat(-r)
    A[0,6:9] = warp[0,:]
    A[1:3,9:12] = warp[1:3,:]

def _section_stiffness(shape,warp, r, weights):
    K = np.zeros((12,12))
    A = np.zeros((3,12))
    model = shape.model
    E = shape.material.E
    G = shape.material.G
    C = np.array([[E, 0, 0],
                  [0, G, 0],
                  [0, 0, G]])
    for ri, wi in zip(r, weights):
        warp = ...
        _strain_matrix(ri, warp, A)
        K += wi * A.T @ C @ A

def create_fibers(shape, n, ys=None, zs=None):
    pass