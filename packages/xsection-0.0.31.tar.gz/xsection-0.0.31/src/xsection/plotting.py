
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch

from matplotlib.patches import FancyArrowPatch


_SKIP_KEYS = {"mesh_scale", "k", "k1", "divisions", "sf"}

_LABEL_KEYS = {
    "tf": "t_f",
    "tw": "t_w",
    "bf": "b_f",
    "br6": "b_r",
    "bs3": "b_s",
    "tr5": "t_r",
    "ts1": "t_s",
}
_LABEL_KEYS.update({
    f"ts{i}": f"t_s^{{({i})}}" for i in range(2, 3)
})
_LABEL_KEYS.update({
    f"tr{i}": f"t_r^{{({i})}}" for i in range(1, 5)
})
_LABEL_KEYS.update({
    f"br{i}": f"b_r^{{({i})}}" for i in range(1, 6)
})
_LABEL_KEYS.update({
    f"bs{i}": f"b_s^{{({i})}}" for i in range(1, 3)
})

_ARROW_COMMON = dict(
    linewidth=0.8,
    shrinkA=0,
    shrinkB=0,
)

def _arrow_style(style, head_length=6, head_width=3):
    """Return a filled-triangle arrow style string."""
    hl, hw = head_length, head_width
    if style == "both":
        return f"<|-|>,head_length={hl},head_width={hw}"
    elif style == "right":
        return f"-|>,head_length={hl},head_width={hw}"
    elif style == "left":
        return f"<|-,head_length={hl},head_width={hw}"


def draw_dimensions(shape, 
                    ax, 
                    gap=None, 
                    fontsize=8, 
                    color="0.3",
                    head_length=6, 
                    head_width=3,
                    view=None,
                    label="symbol"):
    if gap is None:
        if view is None:
            ext = shape.exterior()
            span = np.ptp(ext, axis=0).max()
        else:
            bbox = shape._annotate_view(view)
            (x0, y0), (x1, y1) = bbox
            span = max(abs(x1 - x0), abs(y1 - y0))
        gap = span * 0.08

    for key in shape._annotate_parameters(view=view):
        if key in _SKIP_KEYS:
            continue

        try:
            result = shape._annotate_dimension(key)
        except Exception as e:
            print(f"Error occurred while annotating dimension for key '{key}': {e}")
            raise e

        if result is None:
            continue

        (p1, p2), offset_dir, dim_type = result
        p1 = np.asarray(p1, dtype=float)
        p2 = np.asarray(p2, dtype=float)
        offset_dir = np.asarray(offset_dir, dtype=float)

        delta = p2 - p1
        length = np.linalg.norm(delta)
        if length < 1e-12:
            continue

        tangent = delta / length
        normal  = np.array([-tangent[1], tangent[0]])
        if np.dot(normal, offset_dir) < 0:
            normal = np.dot(normal, offset_dir/np.linalg.norm(offset_dir)) * normal

        # Separate magnitude (controls offset distance) from direction (controls side)
        offset_mag = np.linalg.norm(offset_dir)
        shift_dist = offset_mag * gap
        if offset_mag > 1e-12:
            direction = offset_dir / offset_mag
        else:
            direction = np.zeros(2)

        shift = offset_dir * gap
        p1 = p1 + shift
        p2 = p2 + shift

        kw = dict(head_length=head_length, head_width=head_width,
                  direction=direction, shift_dist=shift_dist)

        dim_label = key 
        if label == "value":
            dim_label = length
        elif label == "imperial":
            dim_label = _label_imperial(length, "inch")
        
        if dim_type == "inside":
            _draw_inside(ax, p1, p2, dim_label, normal, fontsize, color,
                         gap=gap, **kw)
        elif dim_type in ("+outside", "-outside"):
            _draw_sided_outside(ax, p1, p2, dim_label, tangent, normal,
                                fontsize, color, gap,
                                side=dim_type, **kw)
        else:
            _draw_outside(ax, p1, p2, dim_label, tangent, normal, length,
                          fontsize, color, gap, **kw)


def _draw_witness_lines(ax, p1, p2, direction, shift_dist, gap, color):
    """Draw witness lines from shape surface through dimension line."""
    if shift_dist < 1e-12:
        return
    overshoot = gap * 0.3
    for p in (p1, p2):
        shape_end = p - direction * shift_dist       # back to the shape
        outer_end = p + direction * overshoot         # just past the arrowhead
        ax.plot([shape_end[0], outer_end[0]],
                [shape_end[1], outer_end[1]],
                color=color, linewidth=0.5)


# def _draw_inside(ax, p1, p2, key, normal, fontsize, color,
#                  gap,
#                  direction, shift_dist,
#                  head_length=6, head_width=3):
#     arrow = FancyArrowPatch(
#         posA=p1, posB=p2,
#         arrowstyle=_arrow_style("both", head_length, head_width),
#         mutation_scale=1,
#         color=color,
#         **_ARROW_COMMON,
#     )
#     ax.add_patch(arrow)

#     _draw_witness_lines(ax, p1, p2, direction, shift_dist, gap, color)
#     _draw_label(ax, (p1 + p2) / 2, normal, key, fontsize, color)

def _draw_inside(ax, p1, p2, key, normal, fontsize, color,
                 gap,
                 direction, shift_dist,
                 head_length=6, head_width=3):
    arrow = FancyArrowPatch(
        posA=p1, posB=p2,
        arrowstyle=_arrow_style("both", head_length, head_width),
        mutation_scale=1,
        color=color,
        **_ARROW_COMMON,
    )
    ax.add_patch(arrow)

    _draw_witness_lines(ax, p1, p2, direction, shift_dist, gap, color)

    mid = (p1 + p2) / 2

    label = f"${_LABEL_KEYS.get(key, key)}$"

    n_norm = np.linalg.norm(normal)
    if n_norm > 1e-12:
        n_hat = normal / n_norm
    else:
        n_hat = np.array([0.0, 1.0])

    # Determine ha/va so text sits on the correct side of mid
    # without needing a bbox measurement
    abs_nx, abs_ny = abs(n_hat[0]), abs(n_hat[1])

    if abs_ny > abs_nx:
        # Mostly vertical shift — use va to align
        ha = "center"
        va = "bottom" if n_hat[1] > 0 else "top"
    else:
        # Mostly horizontal shift — use ha to align
        va = "center"
        ha = "left" if n_hat[0] > 0 else "right"

    # Small padding in data coords along normal
    pad = gap * 0.5 #0.05
    pos = mid + n_hat * pad

    ax.text(
        pos[0], pos[1],
        label,
        fontsize=fontsize,
        color=color,
        ha=ha,
        va=va,
        bbox=dict(
            facecolor="white",
            edgecolor="none",
            pad=1.0,
            alpha=0.85,
        ),
    )

def _draw_outside(ax, p1, p2, key, tangent, normal, length,
                  fontsize, color, gap,
                  direction, shift_dist,
                  head_length=6, head_width=3):
    ext = gap * 0.1
    outer1 = p1 - tangent * ext
    outer2 = p2 + tangent * ext

    a1 = FancyArrowPatch(
        posA=outer1, posB=p1,
        arrowstyle=_arrow_style("right", head_length, head_width),
        mutation_scale=1,
        color=color,
        **_ARROW_COMMON,
    )
    ax.add_patch(a1)

    a2 = FancyArrowPatch(
        posA=outer2, posB=p2,
        arrowstyle=_arrow_style("right", head_length, head_width),
        mutation_scale=1,
        color=color,
        **_ARROW_COMMON,
    )
    ax.add_patch(a2)

    ax.plot([p1[0], p2[0]], [p1[1], p2[1]],
            color=color, linewidth=0.5, linestyle=":")

    _draw_witness_lines(ax, p1, p2, direction, shift_dist, gap, color)

    label_pos = (outer1 + outer2) / 2
    _draw_label(ax, label_pos, normal, key, fontsize, color)


def _draw_sided_outside(ax, p1, p2, key, tangent, normal,
                        fontsize, color, gap,
                        direction, shift_dist,
                        side="+outside",
                        head_length=6, head_width=3):
    ext = gap #* 0.1
    outer1 = p1 - tangent * ext
    outer2 = p2 + tangent * ext

    a1 = FancyArrowPatch(
        posA=outer1, posB=p1,
        arrowstyle=_arrow_style("right", head_length, head_width),
        mutation_scale=1,
        color=color,
        **_ARROW_COMMON,
    )
    ax.add_patch(a1)

    a2 = FancyArrowPatch(
        posA=outer2, posB=p2,
        arrowstyle=_arrow_style("right", head_length, head_width),
        mutation_scale=1,
        color=color,
        **_ARROW_COMMON,
    )
    ax.add_patch(a2)

    ax.plot([p1[0], p2[0]], [p1[1], p2[1]],
            color=color, linewidth=0.5, linestyle=":")

    _draw_witness_lines(ax, p1, p2, direction, shift_dist, gap, color)

    label_margin = gap * 0.6
    if side == "+outside":
        label_pos = outer2 + tangent*label_margin
    else:
        label_pos = outer1 - tangent*label_margin

    ax.text(
        label_pos[0], label_pos[1],
        f"${_LABEL_KEYS.get(key, key)}$",
        fontsize=fontsize,
        color=color,
        ha="center",
        va="center",
        bbox=dict(
            facecolor="white",
            edgecolor="none",
            pad=1.0,
            alpha=0.85,
        ),
    )

def _draw_label(ax, pos, normal, key, fontsize, color):
    offset = normal * fontsize * 0.1
    ax.text(
        pos[0] + offset[0],
        pos[1] + offset[1],
        f"${_LABEL_KEYS.get(key, key)}$",
        fontsize=fontsize,
        color=color,
        ha="center",
        va="center",
        bbox=dict(
            facecolor="white",
            edgecolor="none",
            pad=1.0,
            alpha=0.85,
        ),
    )

# def _label_imperial(value: float, unit: str = "inch") -> str:
#     if unit == "foot":
#         total_inches = value * 12
#     else:
#         total_inches = value

#     feet = int(total_inches // 12)
#     inches = round(total_inches % 12)

#     if inches == 12:
#         feet += 1
#         inches = 0

#     if inches == 0:
#         return f"{feet}'"
#     elif feet == 0:
#         return f'{inches}"'
#     else:
#         return f'{feet}\' {inches}"'
def _label_imperial(value: float, unit: str = "inch", precision: int = 16) -> str:
    if unit == "foot":
        total_inches = value * 12
    else:
        total_inches = value

    feet = int(total_inches // 12)
    remaining = total_inches % 12

    whole_inches = int(remaining)
    frac = remaining - whole_inches

    # Snap to nearest fraction of `precision` (e.g. 16 -> nearest 1/16)
    numerator = round(frac * precision)
    if numerator == precision:
        whole_inches += 1
        numerator = 0
    if whole_inches == 12:
        feet += 1
        whole_inches = 0

    # Simplify the fraction
    from math import gcd
    if numerator > 0:
        common = gcd(numerator, precision)
        num = numerator // common
        den = precision // common
        frac_str = f"\\sfrac{{{num}}}{{{den}}}"
    else:
        frac_str = ""

    # Build the inch part
    if whole_inches and frac_str:
        inch_part = f'{whole_inches} {frac_str}"'
    elif whole_inches:
        inch_part = f'{whole_inches}"'
    elif frac_str:
        inch_part = f'{frac_str}"'
    else:
        inch_part = ""

    # Combine feet and inches
    if feet and inch_part:
        return f"{feet}' {inch_part}"
    elif feet:
        return f"{feet}'"
    elif inch_part:
        return inch_part
    else:
        return "0\""

def draw_surfaces(shape, 
                  facecolor="lightgrey", 
                  edgecolor="k", 
                  alpha=0.4, 
                  fontsize=20,
                  dimension=True,
                  ax=None,
                  label="symbol",
                  view=None):

    if ax is None:
        fig, ax = plt.subplots()
        ax.set_aspect("equal")
        ax.axis("off")
    else:
        fig = ax.figure

    ext = shape.exterior()
    holes = shape.interior()

    # Build compound path: exterior + all holes
    vertices = []
    codes = []

    # Exterior (close the ring)
    ring = np.vstack([ext, ext[0]])
    codes += [Path.MOVETO] + [Path.LINETO] * (len(ring) - 2) + [Path.CLOSEPOLY]
    vertices.append(ring)

    # Holes
    for hole in holes:
        ring = np.vstack([hole, hole[0]])
        codes += [Path.MOVETO] + [Path.LINETO] * (len(ring) - 2) + [Path.CLOSEPOLY]
        vertices.append(ring)

    all_verts = np.concatenate(vertices)
    path = Path(all_verts, codes)

    patch = PathPatch(
        path,
        facecolor=facecolor,
        edgecolor=edgecolor,
        alpha=alpha,
        linewidth=1.0,
    )
    ax.add_patch(patch)
    ax.autoscale_view()

    if dimension:
        if hasattr(shape, "_shapes"):
            for cshape in shape._shapes:
                draw_dimensions(cshape, ax, fontsize=fontsize)
        else:
            draw_dimensions(shape, ax, fontsize=fontsize, label=label, view=view)
    return fig, ax

def draw_detail(shape, view,
                facecolor="lightgrey",
                edgecolor="k",
                alpha=0.4,
                fontsize=20,
                padding=0.1,
                label="symbol",
                ax=None):
    """Draw shape cropped to the bounding box of a named view."""

    bbox = shape._annotate_view(view)
    if bbox is None:
        raise ValueError(f"No view '{view}' defined for {type(shape).__name__}")

    (x0, y0), (x1, y1) = bbox
    xmin, xmax = min(x0, x1), max(x0, x1)
    ymin, ymax = min(y0, y1), max(y0, y1)

    # Pad by a fraction of the view extent
    dx = (xmax - xmin) * padding
    dy = (ymax - ymin) * padding

    fig, ax = draw_surfaces(
        shape,
        facecolor=facecolor,
        edgecolor=edgecolor,
        alpha=alpha,
        fontsize=fontsize,
        dimension=True,
        ax=ax,
        view=view,
        label=label,
    )

    ax.set_xlim(xmin - dx, xmax + dx)
    # ax.set_ylim(ymin - dy, ymax + dy)

    return fig, ax

# class Artist:
#     def __init__(self, shape):
#         self.shape = shape

#         fig, ax = plt.subplots()
#         ax.set_aspect("equal")
#         ax.axis("off")
#         self.canvas = ax

#     def draw_surfaces(self, 
#                       state=None,
#                       facecolor="lightgrey", edgecolor="k", alpha=0.4):

#         if state is None:
#             return draw_surfaces(self.shape, 
#                                 facecolor, 
#                                 edgecolor, 
#                                 alpha, 
#                                 dimension=False,
#                                 ax=self.canvas)
        

if __name__ == "__main__":
    from xsection.analysis import SaintVenantSectionAnalysis
    from xsection._benchmarks import load_shape
    shape = load_shape("R01", mesh_type="T3")
    sv = SaintVenantSectionAnalysis(shape)

    import veux
    from veux.plane import PlaneArtist, PlaneModel



    artist = PlaneArtist(PlaneModel(shape.model.mesh))

    artist.draw_surfaces(
        field=sv.solve_twist(),
        cbar_label=r"$\omega$",
    )
    artist.draw_outlines()

    artist.draw()
    veux.serve(artist)

    