from cmath import pi
import re
from xsection import CompositeSection
from xsection.library import (
    Channel, Rectangle, WideFlange, 
    HollowRectangle, 
    Angle, 
    Circle, Equigon,
    SingleCellGirder,
    from_aisc
)

from xsection.library._girder import GirderSection
from xsection.library._asbi import MultiCellGirder



def load_shape(shape_name, nu=None, units=None, 
               material=None, 
               mesher="triangle",
               mesh_type="T6", mesh_scale=1/3):
    import os
    ms = os.getenv("nf", None)
    if ms is not None:
        ms = int(ms)


    match shape_name:
        case 1 | "R01":
            shape = Rectangle(d=14, 
                              b=8, 
                                poisson=nu,
                                mesh_scale=1/(ms or 20), 
                                mesher="gmsh",
                                material=material,
                                mesh_type=mesh_type
                    ) #

        # Hollow Rectangle
        case str() as name if re.fullmatch(r"H0[1-6]", name):
            # Armero
            pass 

        case 2 | "H07": # h07
            # T = T or 0.0
            shape = HollowRectangle(d=14, b=8, t=1,
                                    mesh_scale=1/(ms or 5),
                                    poisson=nu,
                                    mesher="gmsh",
                                    material=material,
                                    mesh_type=mesh_type)
        case 3 | "H08": # h08
            # Le Corvec, Figure 3.25
            if units is None:
                import xara.units.english as units
            shape = HollowRectangle(d=1*units.ft, 
                                    b=1*units.ft, 
                                    tw=0.05*units.ft,
                                    tf=0.1*units.ft,
                                    mesh_scale=1/(ms or 5),
                                    poisson=nu,
                                    material=material,
                                    mesh_type=mesh_type,
                                    mesher="gmsh")
        case "H09":
            shape = HollowRectangle(
                d=18,
                tf=1,
                tw=0.3,
                b=6.0,
                material=material,
                mesh_scale=mesh_scale,
                mesh_type=mesh_type,
                mesher="gmsh"
            )
        #
        # Channels
        #
        case "C01" | "c01":
            # G, S & W, 6.2
            if nu is None and material is None:
                nu = 0.3
            shape = Channel(
                    tf =  1.6,
                    tw =  1.0,
                    b  = 10.0,
                    d  = 30.0,
                    poisson=nu,
                    material=material,
                    mesh_scale=1/(ms or 10),
                    # centroid=(0,0),
                    mesher="gmsh"
                )

        case "C02":
            # G, S & W, 6.1
            shape = Channel(
                tf =  0.2,
                tw =  0.2,
                b  = 10.0,
                d  = 10.0,
                material=material,
            )

        case "C04":
            # Pilkey, Table 6.2
            c = 1.0
            shape = Channel(
                tf=c/10,
                tw=c/10,
                b=c + 1/10,
                d = 2*c + 2*c/10,
                mesh_scale=1/25,
                mesh_type=mesh_type,
                material=material,
                mesher="gmsh",
                poisson=nu,
            )
            # shape = shape.translate(-shape.centroid)
        case 4 | "C10": # was C05
            shape = Channel(d=14, 
                            b=8, 
                            t=1,
                            mesh_scale=1/(ms or 4),
                            poisson=nu,
                            material=material,
                            mesh_type=mesh_type,
                            mesher="gmsh")
        #
        # Angles
        #
        case "A02":
            # frame-1041
            if units is None:
                import xara.units.ips as units

            shape = Angle(b=1*units.inch,
                          d=1*units.inch,
                          t=0.03*units.inch,
                          poisson=0.3,
                          mesh_scale=1/200)

        case "A04":
            # Pilkey, Table 6.8, also Schramm (1994)
            pass

        case "A08":
            shape = from_aisc("L7x4x3/4", 
                               mesh_scale=1/8,#(ms or 4), 
                               mesher="gmsh",
                               mesh_type=mesh_type,
                               material=material
                    )
        #
        # Wide Flanges
        #
        case "W01" | 5:
            #   18x40
            shape = from_aisc("W14x48", 
                              units=units, 
                              mesh_scale=1, 
                              fillet=True, 
                              mesher="gmsh")
        case "W02":
            shape = WideFlange(
                bf=0.1509,
                d =0.1524,
                tw=0.008 ,
                tf=0.0122,
            )

        case 6:
            # Le Corvec
            shape = WideFlange(
                    d  = 1,
                    b  = 1,
                    tf = 0.05,
                    tw = 0.05,
                    poisson=nu,
                    material=material,
                    mesh_scale=1/(ms or 5),
                    mesher="gmsh"
            )
        case "W03":
            # Hjelmstad shear link
            return from_aisc("W18x40", mesh_scale=1, material=material, fillet=False, mesher="gmsh", mesh_type="T6")
            pass
            
        # Girders
        case "G01" | "painter-girder":
            if units is None:
                import xara.units.english as u 
            else:
                u = units
                
            shape = GirderSection(
                web_slope      = 0.5,
                thickness_top  = (7 + 1/2)  * u.inch,
                thickness_bot  = (5 + 1/2)  * u.inch,
                height         = 5*u.ft + 8*u.inch,
                width_top      = 2*26 * u.ft,
                width_webs     = [12*u.inch]*7,
                web_spacing    = 7*u.ft + 9*u.inch,
                overhang       = 2*u.ft + 6*u.inch,
                mesh_scale     = 1/(ms or 3),
                # poisson=0.3,
                material=material,
                mesher="gmsh"
            )

        case "G01M" | "painter-girder":
            if units is None:
                import xara.units.english as u 
            else:
                u = units
            d = 5*u.ft + 8*u.inch
            shape = MultiCellGirder(
                # web_slope      = 0.5,
                d=d,
                tr5  = (7 + 1/2)  * u.inch,
                tr4  = 11*u.inch,
                tr3  = 11*u.inch,
                tr2  = 7.5*u.inch,
                tr1  = 7.5*u.inch,
                br6  = 26*u.ft,
                br4  = 26*u.ft - 2.5*u.ft,
                br3  = 26*u.ft - 2.5*u.ft - 1*u.ft,
                br2  = 26*u.ft - 2.5*u.ft - 1.5*u.ft,
                # br1  = 26*u.ft - 2.5*u.ft - 1.5*u.ft - 1*u.ft,
                bs3  = 26*u.ft - 2.5*u.ft - 0.5*(d-11*u.inch),
                # bs2  = 26*u.ft - 2.5*u.ft - 1*u.ft - 0.5*(d-11*u.inch-5.5*u.inch),
                bs1  = 26*u.ft - 2.5*u.ft - 1*u.ft - 0.5*(d-11*u.inch-5.5*u.inch),
                ts1  = 5.5*u.inch,
                # ts2  = 5.5*u.inch,
                web_centers=[
                    -(7*u.ft + 9*u.inch)*2,
                    -(7*u.ft + 9*u.inch),
                    0,
                    (7*u.ft + 9*u.inch),
                    (7*u.ft + 9*u.inch)*2
                ],
                web_widths=[1*u.foot]*5,
                material=material,
            )
        case "G02":
            # Gruttmann, Wagner (2001)
            if material is not None:
                raise ValueError("Material is defined in the shape definition for G02")
            shape = SingleCellGirder(
                d=3.45, 
                br6=7.60,
                # br5=7.50,
                br4=4.50,
                br3=3.75,
                br2=3.50,
                br1=2.00,

                tr5=0.3,
                tr4=0.45,
                tr3=0.75,
                tr2=0.45,
                tr1=0.30,

                bs1=2.50,
                bs2=3.30,
                bs3=3.65,
                ts1=0.3,
                ts2=0.60,
                material={"E": 1, "G": 1/(2*(1+0.2))},
                mesh_scale=mesh_scale, 
                mesh_type=mesh_type,
                mesher="gmsh"
            )

        case "G03":
            from xara.units import fks as u
            slope = 1/2.5
            roadway = (
                    4*u.ft+9*u.inch,
                    4*u.ft+11*u.inch,
                    1*u.ft+5*u.inch,
                    6*u.ft+6*u.inch,
                    4*u.ft
                )
            shape = SingleCellGirder(
                d = 8*u.ft + 10*u.inch,
                br6=sum(roadway),
                br5=sum(roadway[:-1]),
                br4=sum(roadway[:-2]),
                br3=sum(roadway[:-3]),
                br1=roadway[0],
                tr5=9*u.inch,
                tr4=1*u.ft+7*u.inch,
                tr3=1*u.ft+7*u.inch,
                tr1=9*u.inch,
                #
                ts1=9*u.inch,
                ts2=9*u.inch+9*u.inch,
                bs3=8*u.ft+2*u.inch,
                web_slope=1/2.5,
                sof_run=3*u.ft,
                material=material,
                mesher=mesher,
                mesh_scale=mesh_scale,
                mesh_type=mesh_type,
            )
            shape.units = u
        
        case "M01":
            # Armero Section 7.5
            if material is not None:
                raise ValueError("Material is defined in the shape definition for M01")
            shape = ShapeM01(mesh_type=mesh_type)

    return shape



def ShapeM01(mesh_type="T3"):
    # Section 7.5 of Armero's report

    from xsection.library import DoubleFlange, Rectangle
    from xsection import CompositeSection
    from xara import Section, Material 
    G = 76.92
    E = 200.0

    materials = {
        "1": Material(E=E, G=G),
        "2": Material(E=E/10, G=G/10)
    }

    h = 50
    t = 0.04*h
    bot = DoubleFlange(d=h, 
                       b2=0.3*h, 
                       b1=0.6*h, 
                       t2=1.25*t,
                       t1=t, 
                       tw=t, 
                       group="1", 
                       material=materials["1"],
                       mesh_scale=1/30
    )

    d = 0.2*h
    top = Rectangle(d=d, b=h, group="2", mesh_scale=1/40, material=materials["2"])
    top = top.translate([0, d/2+t/2])

    return CompositeSection([top, bot])


def ShapeM02():
    """
    El Fatmi, Rached, and Hatem Zenzri. 
      “A Numerical Method for the Exact Elastic Beam Theory. Applications to Homogeneous and Composite Beams.” 
      International Journal of Solids and Structures 41, nos. 9–10 (2004): 2521–37. 
      https://doi.org/10.1016/j.ijsolstr.2003.12.011.
    """
    materials = {
        "1": {"E": 72.95e3, "G": 27.51e3},
        "2": {"E": 10.67e3, "G":  4.02e3}
    }
    s1 = Rectangle(d=40, b=30, material=materials["1"], group="1", mesh_scale=1/30, z=1)
    s2 = Rectangle(d=35, b=20, material=materials["2"], group="2", mesh_scale=1/20, z=2)
    s2 = s2.translate([0, 2.5])
    # s2 = Channel(d=30, b=40, t=5, material=materials["2"], group="2", mesh_scale=1/10, z=1)
    # s2 = s2.translate([-15, 0]).rotate(pi/2)#.translate([0, -15])
    return CompositeSection([s1,s2])


def ShapeM03():
    "Circle"
    from xara import Material, Section
    from xara.units.iks import inch, foot, ksi, kip
    # Define materials
    materials = {
        "core": Material(
            type = "Concrete02",
            Fc  =   7.08*ksi,
            nu  =  0.2,
            ec0 =  0.00295,
            Fcu =  5*ksi,
            ecu =  0.014
        ),
        "cover": Material(
            type = "Concrete02",
            Fc  =   -6.5*ksi,
            nu  =   0.2,
            ec0 =  -0.002,
            Fcu =  -0.5*ksi,
            ecu =  -0.005,
            # "lambda": 0.1,
            # "Ft": 0.65*ksi,
            # "Ets": 500. # Tension stiffening
        ),
        "rebar": Material(
            type = "Steel01",
            nu = 0.3,
            E  =   29e3*ksi,
            Fy =     40*ksi,
            b =   0.05
        )
    }

    d =  7/8*inch
    ds = 2/8*inch # diameter of the shear spiral
    cover = 1*inch + ds
    diameter = 15*inch
    core_radius = diameter/2 - cover - ds - d/2
    nr = 20 # number of longitudinal reinforcing bars


    properties = {
        "gross": {
            "A": diameter**2/4*pi,
            "Iy": diameter**4/64*pi,
            "Iz": diameter**4/64*pi,
        },
        "rebar": {
            "A": nr*d**2/4*pi,
        }
    }

    # Define the exterior shape
    exterior = Circle(diameter/2, z=0,
                    group="cover", 
                    material=materials["cover"],
                    divisions=60, 
                    mesh_scale=1/80)

    interior = Equigon(core_radius, z=1,
                    material=materials["core"],
                    group="core", 
                    divisions=nr, mesh_scale=1/20)

    # A single representative rebar
    one_bar = Circle(d/2, z=2, 
                    mesh_scale=1/2, 
                    divisions=4, 
                    material=materials["rebar"],
                    group="rebar")

    # Location of the first bar; the rest will be generated 
    # by linearly spacing them around an arc 
    xr = ((diameter/2) - cover - ds - d/2, 0)

    bars = one_bar.linspace(xr, xr, nr, endpoint=False, center=(0,0))
    # Create the composite section
    shape = CompositeSection([
                exterior,
                interior,
                *bars
            ], poisson=0.2)
    
    return shape, properties


def ShapeM04():
    h = 24
    b = 15
    d = 7/8
    r = 0 #d/2

    c = 1.5
    from xara import Material, Section
    from xara.units.iks import inch, foot, ksi, kip
    # Define materials
    materials = {
        "core": Material(
            type = "Concrete02",
            Fc  =   7.08*ksi,
            nu  =  0.2,
            ec0 =  0.00295,
            Fcu =  5*ksi,
            ecu =  0.014
        ),
        "cover": Material(
            type = "Concrete02",
            Fc  =   -6.5*ksi,
            nu  =   0.2,
            ec0 =  -0.002,
            Fcu =  -0.5*ksi,
            ecu =  -0.005,
            # "lambda": 0.1,
            # "Ft": 0.65*ksi,
            # "Ets": 500. # Tension stiffening
        ),
        "rebar": Material(
            type = "Steel01",
            nu = 0.3,
            E  =   29e3*ksi,
            Fy =     40*ksi,
            b =   0.05
        )
    }

    bar = Circle(d/2, z=2, 
                material=materials["rebar"],
                mesh_scale=1/2, divisions=4, group="rebar")

    shape = CompositeSection([
                Rectangle(    b, h,     z=0, group="cover", material=materials["cover"]),
                Rectangle(b-2*c, h-2*c, z=1, group="core", material=materials["core"]),
                *bar.linspace([-b/2+c+r, -h/2+c+r], [ b/2-c-r,-h/2+c+r], 3), # Top bars
                *bar.linspace([-b/2+c+r,        0], [ b/2-c-r,       0], 2), # Center bars
                *bar.linspace([-b/2+c+r,  h/2-c-r], [ b/2-c-r, h/2-c-r], 3)  # Bottom bars
            ])


def ShapeM05():
    "Octagonal section with rebar"
    from xara_units.iks import inch, foot 
    d = 11/8*inch
    ds = 4/8*inch # diameter of the shear spiral
    cover = (3 + 1/8)*inch
    core_radius = 5/2*foot - cover - ds - d/2
    nr = 12

    octagon  = Equigon(5*foot/2, z=0,
                        name="cover", divisions=8)

    interior = Equigon(core_radius, z=1,
                        name="core", divisions=nr)

    bar = Circle(d/2, z=2, mesh_scale=1/2, divisions=4, name="rebar")

    xr = ((5*foot/2) - cover - ds - d/2, 0)


    shape = CompositeSection([
                octagon,
                interior,
                *bar.linspace(xr, xr, nr, endpoint=False, center=(0,0))
            ])
