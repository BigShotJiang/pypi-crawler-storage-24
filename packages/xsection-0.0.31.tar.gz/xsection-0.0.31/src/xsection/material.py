from dataclasses import dataclass

@dataclass
class Material:
    name: str
    E : float
    poisson : float


def elastic_moduli(material):
    E = None
    G = None
    nu = None 

    try:
        E = material["E"]
    except:
        E = None
    try:
        G = material["G"]
    except:
        G = None

    if G is None and E is not None:
        try:
            nu = material["nu"]
            G = E/(2*(1+nu))
        except:
            pass

    return E,G