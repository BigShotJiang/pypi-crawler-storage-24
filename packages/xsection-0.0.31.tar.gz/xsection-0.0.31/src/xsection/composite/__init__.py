#
# Claudio Perez
#
import warnings
from ..warping import WarpingSection
from ..polygon import PolygonSection
from xsection.material import elastic_moduli

import numpy as np
class Backbone: pass


class Measure:
    def __init__(self, E, nu=None, G=None):
        self.E = E 
        if G is not None:
            self.G = G
        else:
            self.G = E/(2*(1+nu))

    def __getitem__(self, key):
        if key == "e":
            return self.E
        elif key == "g":
            return self.G
        elif key is None:
            return 1
        else:
            raise KeyError(f"Material has no property '{key}'")



class CompositeSection(WarpingSection):
    """
    A non-homogeneous cross-section composed from multiple sections.

    Parameters
    ----------
    patches: list[Section]
        A list of sections to combine into a composite section.
    materials: dict[str, Material], optional
        Mapping of material names to material properties. If provided, materials will be assigned to patches based on their "group" attribute.
    """

    def __init__(self, patches, 
                 materials=None, poisson=None, holes=None,
                 measure_e=None,  **kwds):
        self._shapes = patches
        self._patches = _clip_sections(patches)
        self._fibers = None
        self._mesh_size = [patch.mesh_size for patch in patches]
        self._mesher = kwds.get("mesher", "gmsh")
        self._c_model = None
        self._c_models = []
        self._exterior = None
        self._area   = None
        if holes is None:
            holes = []
        self._holes = holes

        self.materials = self._collect_materials()

        self._is_composite = True

        # Check for materials in individual patches
        # if materials is None:
        #     materials = {}
        #     for patch in patches:
        #         if patch.material is not None:
        #             materials[patch._c_group] = patch.material
        self._c_materials = materials
        self._shear_poisson = poisson
        # self._c_reference = reference


    def add_patch(self, patch):
        self._fibers = None
        self._exterior = None
        self._patches.append(patch)

    def add_patches(self, patch):
        self._fibers = None
        self._exterior = None
        self._patches.extend(patch)

    def translate(self, dr):
        return CompositeSection(
            [patch.translate(dr) for patch in self._patches],
            materials=self._c_materials,
            # reference=self._c_reference,
            # measure_e=self._measure_e,
            holes=[hole.translate(dr) for hole in self._holes],
        )

    @property 
    def centroid(self):
        pass

    @property 
    def depth(self):
        if self._patches:
            return max(p.z for p in self._patches) - min(p.z for p in self._patches)
        return 0.0

    @property
    def width(self):
        if self._patches:
            return max(p.x for p in self._patches) - min(p.x for p in self._patches)
        return 0.0

    def exterior(self):

        if self._exterior is not None:
            return self._exterior

        import shapely.geometry
        from shapely.ops import unary_union

        shapes = []

        for patch in self._patches:
            shapes.append(shapely.geometry.Polygon(patch.exterior(),
                                                   patch.interior()))
            
        if len(shapes) > 1:
            self._exterior = np.asarray(unary_union(shapes).exterior.coords)
        else:
            self._exterior = np.asarray(shapes[0].exterior.coords)
        
        return self._exterior
        
    def interior(self):
        holes = []
        for patch in self._patches:
            if patch.interior() is not None:
                holes.extend(patch.interior())
        return holes

    def _collect_materials(self):
        # Either all or none of the patches must have materials assigned, 
        # and if so they should have group names for material assignment
        group = 1
        materials = {
            # patch._c_group: patch.material 
            # for patch in self._patches if patch.material is not None
        }
        patches_without_material = []
        for patch in self._patches:
            if patch.material is not None:
                if patch._c_group is None:
                    warnings.warn("Patch with material should have a group name for material assignment")
                    materials[f"group_{group}"] = patch.material
                    group += 1
                else:
                    if patch._c_group in materials:
                        if id(materials[patch._c_group]) != id(patch.material):
                            raise ValueError(f"Conflicting materials assigned to group '{patch._c_group}'")
                    materials[patch._c_group] = patch.material
            else:
                patches_without_material.append(patch)

        if materials and patches_without_material:
            raise ValueError("Either all or none of the patches must have materials assigned")
        return materials

    def _find_group_patches(self, patch_name: str)->set:
        patches = set()
        for i, patch in enumerate(self._patches):
            if patch._c_group == patch_name:
                patches.add(i)
        if len(patches) == 0:
            raise ValueError(f"No patch found with name '{patch_name}'")
        return patches



    @property 
    def model(self):
        if self._c_model is None:
            self._c_model = self._create_mesh()
        return self._c_model
    
    def create_model(self, materials):
        return self.model
        if materials is None:
            if self._c_materials is None:
                raise ValueError("No materials provided for model creation")
            materials = self._c_materials

        def check_materials(mats_a, mats_b):
            if len(mats_a) != len(mats_b):
                return False

            for k in mats_a:
                if mats_a[k]["E"] != mats_b[k]["E"]:
                    return False
                if mats_a[k]["G"] != mats_b[k]["G"]:
                    return False
            return True

        for model, mats_a in self._c_models:
            if check_materials(mats_a, materials):
                return model 
        model = self._create_model(materials)
        self._c_models.append((model, materials))
        return model



    def _create_model(self, materials):
        return self.model

        mesh = _mesh_cytri(self._patches, 
                           holes=self._holes, 
                           mesh_size=self._mesh_size, 
                           min_angle=25.0)

        from shps.frame.solvers import TriangleModel

        measures = {}
        groups = set(p._c_group for p in self._patches)
        if None in groups:
            raise ValueError("All patches must have a group name for material assignment")

        for group in groups:

            if group not in materials:
                raise ValueError(f"Material for group '{group}' not found in provided materials")

            material = materials[group]

            for patch in self._find_group_patches(group):
                E, G = elastic_moduli(material)

                measures[patch] = Measure(E=E, G=G)

        return TriangleModel.from_meshio(mesh, measures=measures)


    def _create_mesh(self, mesh_size: list=None, engine=None):

        mesh = _mesh_cytri(self._patches,
                           holes=self._holes, 
                           mesh_size=self._mesh_size, 
                           min_angle=25.0)

        from shps.frame.solvers import TriangleModel

        measures = None
        if self.materials:
            measures = {}
            for i,patch in enumerate(self._patches):
                if patch.material is None:
                    raise ValueError(f"Patch {i} has no material assigned")
                else:
                    E, G = elastic_moduli(patch.material)
                    measures[i] = Measure(E=E, G=G)


        return TriangleModel.from_meshio(mesh, measures=measures)


    @property
    def patches(self):
        return [p for p in self._patches]
    
    @property 
    def groups(self):
        for shape in self._shapes:
            yield from shape.groups

    @property
    def area(self):
        if self._area is None:
            self._area = sum(i.area for i in self._patches)
        return self._area


    @property
    def ixc(self):
        # TODO: cache
        yc = self.centroid[1]
        return sum(
            p.ixc + (p.centroid[1] - yc)**2*p.area for p in self._patches
        )

    @property
    def iyc(self):
        # TODO: cache
        xc = self.centroid[0]
        return sum(
            p.iyc + (p.centroid[0]-xc)**2*p.area for p in self._patches
        )

    @property
    def moic(self):
        # TODO: cache
        return [
            [p.moi[i] + p.centroid[i]**2*p.area for i in range(2)] + [p.moi[-1]]
            for p in self._patches
        ]

    def __contains__(self, point):
        return any(point in area for area in self._shapes)


def _clip_sections(sections):
    """
    Return each section clipped by all higher-z sections individually.
    Preserves the original number, order, and attributes.
    """
    from shapely.geometry import Polygon
    import numpy as np

    # Sort with index to restore original order later
    indexed = sorted([(i, getattr(s, "z", 0), s) for i, s in enumerate(sections)],
                     key=lambda t: -t[1])  # High z first

    result = [None for i in range(len(sections))]

    for i, (idx_i, z_i, sec_i) in enumerate(indexed):
        poly_i = Polygon(sec_i.exterior(), sec_i.interior()).buffer(0)

        # Subtract each higher-priority section
        for j in range(i):
            _, z_j, sec_j = indexed[j]
            poly_j = Polygon(sec_j.exterior(), sec_j.interior())
            poly_i = poly_i.difference(poly_j)

        # Build section

        ext = np.array(poly_i.exterior.coords)
        ints = [np.array(ring.coords) for ring in poly_i.interiors]


        result[idx_i] = PolygonSection(ext, ints,
                                       mesh_size=sec_i.mesh_size,
                                    #    poisson=sec_i._poisson,
                                       material=sec_i.material,
                                       group=sec_i._c_group,
                                       z=z_i)

    return result



def _mesh_cytri(sections, holes=None, mesh_size=0.05, min_angle=25.0, coarse=False, quadratic=False):
    """
    Generate a triangular mesh with material interfaces using Shewchuk's Triangle.
    """
    import cytriangle as triangle
    import numpy as np
    import shapely

    points         = []
    hole_points    = []
    facets         = []
    control_points = []
    mesh_sizes     = []
    z_indices      = []

    vertex_map = {}
    def get_vertex_index(pt):
        key = tuple(np.round(pt, 12))  # prevent numerical duplicates
        if key in vertex_map:
            return vertex_map[key]
        idx = len(points)
        points.append(key)
        vertex_map[key] = idx
        return idx
    
    s_polygons = [
        shapely.Polygon(section.exterior(), section.interior()) 
        for section in sections
    ]

    for i,(section,s_polygon) in enumerate(zip(sections, s_polygons)):
        ext       = section.exterior()
        interiors = section.interior()
        # material  = section.material

        z_indices.append(section.z)

        # Exterior
        ext_idx = [get_vertex_index(p) for p in ext]
        facets.extend([(ext_idx[i], ext_idx[(i + 1) % len(ext_idx)]) 
                        for i in range(len(ext_idx))])

        # Holes
        for hole,hole_poly in zip(interiors, s_polygon.interiors):
            rh = shapely.Polygon(hole_poly).representative_point()

            if any(shapely.contains(p,rh) for p in s_polygons if p != s_polygon):
                continue

            hole_idx = [get_vertex_index(p) for p in hole]
            facets.extend([
                (hole_idx[i], hole_idx[(i + 1) % len(hole_idx)]) for i in range(len(hole_idx))
            ])
            hole_points.append(tuple(rh.coords[0]))


        # Control point for region interior
        control_points.append(s_polygon.representative_point().coords[0]) #tuple(np.mean(ext, axis=0)))

        # Region mesh size
        # if isinstance(mesh_size, dict):
        #     mesh_sizes.append(mesh_size.get(material, 0.05))

        if isinstance(mesh_size, list):
            if len(mesh_size) != len(sections):
                raise ValueError("mesh_size list must match number of sections")
            mesh_sizes.append(mesh_size[i])

        else:
            mesh_sizes.append(mesh_size)


    for shole in holes or []:
        hole_points.append(tuple(shole.centroid))
        hole_idx = [get_vertex_index(p) for p in shole.exterior()]
        facets.extend([
            (hole_idx[i], hole_idx[(i + 1) % len(hole_idx)]) for i in range(len(hole_idx))
        ])

    # Prepare Triangle input
    tri_input = {
        "vertices": points,
        "segments": facets,
        "holes": hole_points,
        "regions": [
            [
                cp[0], cp[1], # vertex 
                i,            # marker; _find_group_patches depends on this being the patch index
                mesh_sizes[i] # max_area
             ]
            for i, (cp,z) in enumerate(zip(control_points, z_indices))
        ]
    }

    for i, r in enumerate(tri_input["regions"]):
        if len(r) != 4 or not all(isinstance(v, (float, int)) for v in r):
            raise ValueError(f"Bad region entry at index {i}: {r}")

    # - "A" switch enables regional attributes.
    opts = "pA" if coarse else f"pq{min_angle:.1f}Aa"

    # Use quadratic (6-node) triangles
    if quadratic:
        opts += "o2"

    tri_output = triangle.triangulate(tri_input, opts)


    points = np.array(tri_output["vertices"], dtype=np.double)


    element = "triangle6" if quadratic else "triangle"
    cells = [(element, np.array(tri_output["triangles"], dtype=np.int32))]
    if quadratic:
        # reorder mid-side nodes to standard convention
        for i in range(len(cells[0][1])):
            cells[0][1][i] = cells[0][1][i][[np.array([0, 1, 2, 5, 3, 4])]]

    # Optional cell data (e.g., region markers)
    cell_data = {}
    if "triangle_attributes" in tri_output:
        triangle_attr = list(
            map(int, np.array(tri_output["triangle_attributes"], dtype=int).flatten()
        ))
        cell_data = {"region": [triangle_attr]}

    import meshio
    return meshio.Mesh(
        points=points,
        cells=cells,
        cell_data=cell_data
    )



def _create_mesh_cyt(
    points: list[tuple[float, float]],
    facets: list[tuple[int, int]],
    holes: list[tuple[float, float]],
    control_points: list[tuple[float, float]],
    mesh_sizes: list[float] | float,
    min_angle: float,
    coarse: bool,
) -> dict[str, list[list[float]] | list[list[int]]]:
    """Discretize a 2D region by triangles.
    """
    import cytriangle as triangle
    if not isinstance(mesh_sizes, list):
        mesh_sizes = [mesh_sizes]

    tri = {}                  # create tri dictionary
    tri["vertices"] = points  # set point
    tri["segments"] = facets  # set facets

    if holes:
        tri["holes"] = holes  # set holes

    # prepare regions
    regions = []

    for i, cp in enumerate(control_points):
        rg = [cp[0], cp[1], i, mesh_sizes[i]]
        regions.append(rg)

    tri["regions"] = regions  # set regions

    # generate mesh
    if coarse:
        mesh = triangle.triangulate(tri, "pAo2")
    else:
        mesh = triangle.triangulate(tri, f"pq{min_angle:.1f}Aao2")

    return mesh
