from __future__ import annotations

import numpy as np


class LimitMetric:
    keys = {
        0: "No damage",
        1: "Minor damage: flexural cracks",
        2: "Minor spalling",
        3: "Extensive cracks and spalling",
        4: "Visible reinforcing bars",
        5: "Core edge failure",
        6: "Bar fracture",
    }

    def __init__(self, shape, model, element, section):
        self.shape = shape
        self.model = model
        self.element = element
        self.section = section
        self._state = 0

        fibers = getattr(getattr(shape, "model", None), "fibers", None)
        if fibers is None:
            fibers = getattr(model, "fibers", None)
        if fibers is None:
            raise AttributeError("Could not find fibers on shape.model.fibers or model.fibers.")

        self._fibers = list(fibers)
        self._fibers_by_tag = {fiber.tag: fiber for fiber in self._fibers}

    def update(self):
        raise NotImplementedError

    def value(self):
        return self._state

    def label(self):
        return self.keys.get(self._state, f"State {self._state}")

    def _resolve_fiber(self, fiber):
        if hasattr(fiber, "tag"):
            return fiber
        return self._fibers_by_tag[fiber]

    def _fiber_axial_strain(self, fiber) -> float:
        fiber = self._resolve_fiber(fiber)

        for attr in ("axial_strain", "strain", "eps", "epsilon"):
            if hasattr(fiber, attr):
                return float(getattr(fiber, attr))

        if hasattr(self.model, "fiber_axial_strain"):
            return float(self.model.fiber_axial_strain(self.element, self.section, fiber.tag))

        raise AttributeError(
            f"Could not recover axial strain for fiber {fiber.tag}. "
            "Add fiber.axial_strain or implement "
            "model.fiber_axial_strain(element, section, fiber_tag)."
        )

    def _fiber_axial_stress(self, fiber) -> float:
        fiber = self._resolve_fiber(fiber)

        for attr in ("axial_stress", "stress", "sig", "sigma"):
            if hasattr(fiber, attr):
                return float(getattr(fiber, attr))

        if hasattr(self.model, "fiber_axial_stress"):
            return float(self.model.fiber_axial_stress(self.element, self.section, fiber.tag))

        raise AttributeError(
            f"Could not recover axial stress for fiber {fiber.tag}. "
            "Add fiber.axial_stress or implement "
            "model.fiber_axial_stress(element, section, fiber_tag)."
        )


class StrainActivation:
    """
    Region-based strain trigger.

    region:
        * "steel", "cover", "core", ... -> all fibers in the named patch group
        * ("cover", a, b)               -> normalized cover-depth band, a <= delta_cov <= b
        * ("core",  a, b)               -> normalized core-depth band,  a <= delta_core <= b

    sense:
        * "tension"      -> epsilon >= threshold
        * "compression"  -> -epsilon >= threshold
        * "abs"          -> |epsilon| >= threshold

    aggregator:
        * "any"       -> any fiber in the region trips
        * "all"       -> every fiber in the region trips
        * "fraction"  -> at least `min_fraction` of the region trips
    """

    def __init__(
        self,
        shape,
        region,
        threshold: float,
        label: int,
        *,
        sense: str = "tension",
        aggregator: str = "any",
        min_fraction: float | None = None,
        depth_tol: float = 0.05,
    ):
        self.region = region
        self.threshold = float(threshold)
        self.label = int(label)
        self.sense = sense
        self.aggregator = aggregator
        self.min_fraction = 0.5 if min_fraction is None else float(min_fraction)
        self.depth_tol = float(depth_tol)

        self._shape = shape
        self._fibers = self._all_fibers(shape)
        self._fiber_tags = self._resolve_region(shape, region)
        if not self._fiber_tags:
            raise ValueError(f"Region {region!r} resolved to no fibers.")

    @staticmethod
    def _all_fibers(shape):
        fibers = getattr(getattr(shape, "model", None), "fibers", None)
        if fibers is None:
            fibers = getattr(shape, "fibers", None)
        if fibers is None:
            raise AttributeError("Could not find fibers on shape.model.fibers or shape.fibers.")
        return list(fibers)

    @staticmethod
    def _coord(fiber) -> np.ndarray:
        xy = np.asarray(fiber.coord, dtype=float).reshape(-1)
        if xy.size < 2:
            raise ValueError(f"Fiber {fiber.tag} has invalid coord={fiber.coord!r}")
        return xy[:2]

    def _patch_groups(self, shape, name: str) -> set:
        groups = set(shape._find_patch_groups(name))
        if not groups:
            raise ValueError(f"No patch groups found for region {name!r}")
        return groups

    def _fibers_in_named_region(self, shape, name: str):
        groups = self._patch_groups(shape, name)
        return [fiber for fiber in self._fibers if getattr(fiber, "group", None) in groups]

    def _resolve_region(self, shape, region):
        if isinstance(region, str):
            return [fiber.tag for fiber in self._fibers_in_named_region(shape, region)]

        if isinstance(region, tuple) and len(region) == 3:
            which, a, b = region
            a = float(a)
            b = float(b)

            if which not in {"core", "cover"}:
                raise ValueError(f"Unknown tuple region type {which!r}; expected 'core' or 'cover'.")
            if not (0.0 <= a <= b <= 1.0):
                raise ValueError(f"Need 0 <= a <= b <= 1 for region {region!r}")

            if which == "cover":
                return self._cover_band_tags(shape, a, b)
            return self._core_band_tags(shape, a, b)

        raise TypeError(
            "region must be a patch name such as 'steel' or a tuple "
            "like ('cover', a, b) or ('core', a, b)."
        )

    @staticmethod
    def _cross(o, a, b) -> float:
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    @classmethod
    def _convex_hull(cls, points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=float)
        if len(points) == 0:
            raise ValueError("Cannot construct a hull from zero points.")
        if len(points) == 1:
            return points.copy()

        pts = np.unique(points, axis=0)
        if len(pts) <= 2:
            return pts.copy()

        order = np.lexsort((pts[:, 1], pts[:, 0]))
        pts = pts[order]

        lower = []
        for p in pts:
            while len(lower) >= 2 and cls._cross(lower[-2], lower[-1], p) <= 0.0:
                lower.pop()
            lower.append(tuple(p))

        upper = []
        for p in reversed(pts):
            while len(upper) >= 2 and cls._cross(upper[-2], upper[-1], p) <= 0.0:
                upper.pop()
            upper.append(tuple(p))

        return np.asarray(lower[:-1] + upper[:-1], dtype=float)

    @staticmethod
    def _point_to_segment_distance(p: np.ndarray, a: np.ndarray, b: np.ndarray) -> float:
        ab = b - a
        denom = float(np.dot(ab, ab))
        if denom == 0.0:
            return float(np.linalg.norm(p - a))
        t = float(np.dot(p - a, ab) / denom)
        t = min(1.0, max(0.0, t))
        proj = a + t * ab
        return float(np.linalg.norm(p - proj))

    @classmethod
    def _point_to_polygon_distance(cls, p: np.ndarray, poly: np.ndarray) -> float:
        poly = np.asarray(poly, dtype=float)
        if len(poly) == 1:
            return float(np.linalg.norm(p - poly[0]))
        if len(poly) == 2:
            return cls._point_to_segment_distance(p, poly[0], poly[1])

        q = np.roll(poly, -1, axis=0)
        return min(cls._point_to_segment_distance(p, a, b) for a, b in zip(poly, q))

    @staticmethod
    def _layer_tol(values: np.ndarray) -> float:
        values = np.asarray(values, dtype=float)
        uniq = np.unique(np.round(values, 12))
        if uniq.size <= 1:
            return 0.0
        gaps = np.diff(np.sort(uniq))
        gaps = gaps[gaps > 1e-12]
        if gaps.size == 0:
            return 0.0
        return 0.5 * float(np.min(gaps))

    def _select_band(self, delta, a, b, *, outer_metric=None, inner_metric=None):
        delta = np.asarray(delta, dtype=float)

        if np.isclose(a, b):
            target = float(a)

            if np.isclose(target, 0.0):
                metric = delta if outer_metric is None else np.asarray(outer_metric, dtype=float)
                tol = self._layer_tol(metric)
                return np.flatnonzero(metric <= np.min(metric) + tol)

            if np.isclose(target, 1.0):
                if inner_metric is not None:
                    metric = np.asarray(inner_metric, dtype=float)
                    tol = self._layer_tol(metric)
                    return np.flatnonzero(metric <= np.min(metric) + tol)
                tol = self._layer_tol(delta)
                return np.flatnonzero(delta >= np.max(delta) - tol)

            tol = max(self.depth_tol, self._layer_tol(delta))
            return np.flatnonzero(np.abs(delta - target) <= tol)

        lo = max(0.0, a - self.depth_tol)
        hi = min(1.0, b + self.depth_tol)
        return np.flatnonzero((delta >= lo) & (delta <= hi))

    def _cover_band_tags(self, shape, a: float, b: float):
        cover_fibers = self._fibers_in_named_region(shape, "cover")
        core_fibers = self._fibers_in_named_region(shape, "core")

        outer_points = np.vstack([self._coord(f) for f in cover_fibers + core_fibers])
        inner_points = np.vstack([self._coord(f) for f in core_fibers])

        outer_poly = self._convex_hull(outer_points)
        inner_poly = self._convex_hull(inner_points)

        pts = np.vstack([self._coord(f) for f in cover_fibers])
        d_o = np.array([self._point_to_polygon_distance(p, outer_poly) for p in pts], dtype=float)
        d_i = np.array([self._point_to_polygon_distance(p, inner_poly) for p in pts], dtype=float)

        denom = d_o + d_i
        delta = np.divide(d_o, denom, out=np.zeros_like(d_o), where=denom > 0.0)

        idx = self._select_band(delta, a, b, outer_metric=d_o, inner_metric=d_i)
        return [cover_fibers[i].tag for i in idx]

    def _core_band_tags(self, shape, a: float, b: float):
        core_fibers = self._fibers_in_named_region(shape, "core")
        core_points = np.vstack([self._coord(f) for f in core_fibers])

        outer_poly = self._convex_hull(core_points)
        d = np.array(
            [self._point_to_polygon_distance(self._coord(f), outer_poly) for f in core_fibers],
            dtype=float,
        )

        d_max = float(np.max(d))
        delta = np.zeros_like(d) if d_max <= 0.0 else d / d_max

        idx = self._select_band(delta, a, b, outer_metric=d, inner_metric=None)
        return [core_fibers[i].tag for i in idx]

    def _pass_strain(self, eps: float) -> bool:
        if self.sense == "tension":
            return eps >= self.threshold
        if self.sense == "compression":
            return -eps >= self.threshold
        if self.sense == "abs":
            return abs(eps) >= self.threshold
        raise ValueError(f"Unknown sense {self.sense!r}")

    def check(self, metric) -> bool:
        if not self._fiber_tags:
            return False

        passed = np.array(
            [self._pass_strain(metric._fiber_axial_strain(tag)) for tag in self._fiber_tags],
            dtype=bool,
        )

        if self.aggregator == "any":
            return bool(np.any(passed))
        if self.aggregator == "all":
            return bool(np.all(passed))
        if self.aggregator == "fraction":
            return bool(np.mean(passed) >= self.min_fraction)

        raise ValueError(f"Unknown aggregator {self.aggregator!r}")


class StrainRecorder(LimitMetric):
    def __init__(self, shape, model, element, section, activations):
        super().__init__(shape, model, element, section)
        self._activations = sorted(activations, key=lambda a: a.label)

    def update(self):
        for activation in reversed(self._activations):
            if activation.check(self):
                self._state = max(self._state, activation.label)
                break
        return self._state
