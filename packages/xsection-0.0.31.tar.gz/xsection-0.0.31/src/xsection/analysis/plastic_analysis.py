from typing import Any, Callable, Sequence

import numpy as np

# try:
#     from numba import njit as jit 
#     from numba import prange
#     jit(lambda x: x**2)(1.0)  # test if numba is available

# except:
#     prange = range
#     def jit(*_, **__):
#         def _decorator(func):
#             return func
#         return _decorator
    

class _Fiber:
    __slots__ = ("id", "area", "Fy", "r")

    def __init__(self, id: int, y: float, z: float, area: float, Fy: float):
        self.id = id
        self.area = area
        self.Fy = Fy
        self.r = np.array([0.0, y, z], dtype=float)

    @property
    def stress_limit(self) -> float:
        return self.area * self.Fy


class PlasticAnalysis:
    def __init__(self, shape: Any):
        self.shape = shape

        self._Ks = np.zeros((6, 6)) 
        from xsection.analysis import SaintVenantSectionAnalysis
        sv = SaintVenantSectionAnalysis(shape)
        self._Ks[0,0] = sv.axial_rigidity()
        self._Ks[3:,3:] = sv.axial_inertia()

        self._i = np.array([1.0, 0.0, 0.0], dtype=float)
        self.fibers = self._load_fibers(shape)
        if not self.fibers:
            raise ValueError("shape.create_fibers() produced no fibers.")
        
        self._r_all = np.array([f.r for f in self.fibers], dtype=float)          # (N, 3)
        self._stress_limits = np.array([f.stress_limit for f in self.fibers], dtype=float)  # (N,)


    def _load_fibers(self, shape: Any) -> list[_Fiber]:
        if not hasattr(shape, "create_fibers"):
            raise TypeError("shape must expose a create_fibers() method.")

        fibers = []
        for idx, fiber in enumerate(shape.create_fibers()):
            fibers.append(
                _Fiber(
                    id=idx,
                    y=fiber["y"],
                    z=fiber["z"],
                    area=fiber["area"],
                    Fy= 1.0,
                )
            )
        return fibers



    def elastic_surface(
        self,
        K0: Sequence[Sequence[float]] | Sequence[float],
        e0_values: Sequence[float] | None = None,
    ) -> list[dict[str, Any]]:
        if e0_values is None:
            e0_values = np.linspace(-1.0, 1.0, 3)

        surface = []
        for k0 in self._iter_axes(K0):
            for e0 in e0_values:
                surface.append(self.elastic_limit(k0, e0=float(e0)))
        return surface


    def elastic_contour(
        self,
        K0: Sequence[Sequence[float]] | Sequence[float],
        e0_values: Sequence[float] | None = None,
        x_getter: Callable[[dict[str, Any]], float] | None = None,
        y_getter: Callable[[dict[str, Any]], float] | None = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Contour extracted from `elastic_surface(...)`."""
        surface = self.elastic_surface(K0, e0_values=e0_values)
        return _extract_contour(surface, x_getter=x_getter, y_getter=y_getter)


    def elastic_limit(self, k0: Sequence[float], e0: float = 0.0) -> dict[str, Any]:
        """Compute the elastic limit state for a single reference curvature."""

        k0 = self._as_k0_vector(k0)
        r0, _, _, _, rtop, rbot, _ = self._extreme_fiber_data(k0)

        emp =  1.0 - e0
        emn = -1.0 - e0
        ep = float(np.dot(self._i, np.cross(k0, rtop)))
        en = float(np.dot(self._i, np.cross(k0, rbot)))

        scale_candidates = []
        if not np.isclose(ep, 0.0):
            scale_candidates.append(emp / ep)
        if not np.isclose(en, 0.0):
            scale_candidates.append(emn / en)
        if not scale_candidates:
            raise ValueError("Degenerate curvature/fiber geometry: cannot scale k0 to unit strain.")

        kappa = k0 * min(scale_candidates)

        Cnn = self._Ks[:3, :3]
        Cnm = self._Ks[:3, 3:]
        Cmm = self._Ks[3:, 3:]

        N = Cnn @ (self._i * e0) + Cnm @ kappa
        M = Cnm.T @ (self._i * e0) + Cmm @ kappa

        return {
            "N": N,
            "M": M,
            "P": float(self._i @ N),
            "My": float(k0 @ M),
            "rneg": rbot,
            "rpos": rtop,
            "Depth": abs(float(np.dot(r0, rtop - rbot))),
        }


    def plastic_surface(self, k0: Sequence[float]) -> list[dict[str, Any]]:
        k0 = self._as_k0_vector(k0)

        surface = []
        nsign = 1.0
        for k in (k0, -k0):
            _, _, _, _, rtop, rbot, _ = self._extreme_fiber_data(k)
            rneg = rbot
            rpos = rtop
            r0 = self._direction_from_k_cross_i(k)
            for n in range(len(self.fibers)):
                surface.append(self._plastic_limit_internal(r0, n, rneg, rpos, nsign))
            nsign = -nsign

        if surface:
            surface.append(self._copy_state(surface[0]))
        return surface


    def plastic_contour(
        self,
        k0: Sequence[float],
        x_getter: Callable[[dict[str, Any]], float] | None = None,
        y_getter: Callable[[dict[str, Any]], float] | None = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Contour extracted from `plastic_surface(...)`."""
        surface = self.plastic_surface(k0)
        return _extract_contour(surface, x_getter=x_getter, y_getter=y_getter)

    def plastic_limit(
        self,
        K0: Sequence[Sequence[float]] | Sequence[float] | None = None,
    ) -> dict[str, np.ndarray]:
        """Compute directional plastic limit resultants for one or more reference curvatures."""
        if K0 is None:
            K0 = np.array([[0.0, 1.0, 0.0], 
                           [0.0, 0.0, 1.0]], dtype=float)

        Mp = []
        Np = []
        Depth = []

        for k0 in self._iter_axes(K0):
            ext = self.extreme_fibers(k0)
            rpos = ext["Bot"]["ro"]
            rneg = ext["Top"]["ro"]
            r0 = self._direction_from_k_cross_i(k0)
            nsign = -1.0

            n = int(ext["Mid"]["id"])
            M_limit = self._plastic_limit_internal(r0, n, rneg, rpos, nsign)

            n = int(ext["Bot"]["id"])
            N_limit = self._plastic_limit_internal(r0, n, rneg, rpos, -nsign)

            Mp.append(float(k0 @ M_limit["M"]))
            Np.append(float(self._i @ N_limit["N"]))
            Depth.append(float(ext["Depth"]))

        return {
            "Mp": np.asarray(Mp, dtype=float),
            "Np": np.asarray(Np, dtype=float),
            "Depth": np.asarray(Depth, dtype=float),
        }

    def _plastic_limit_internal(self, r0, n, rneg, rpos, nsign):
        d = abs(float(r0 @ (rpos - rneg)))
        if np.isclose(d, 0.0):
            raise ValueError("Degenerate fiber layout: plastic depth is zero.")

        c = float(r0 @ (self._r_all[n] - rneg) / d)

        # Vectorized projection for all fibers
        proj = (self._r_all - rneg) @ r0 / d      # (N,)
        signs = np.where(proj < c, 1.0, -1.0)     # below PNA → tension
        signs[n] = nsign                           # neutral fiber override

        F = signs * self._stress_limits            # (N,)

        N = np.zeros(3)
        N[0] = F.sum()
        # M = sum( cross(r_m, i*F_m) )
        iF = np.outer(F, self._i)                  # (N, 3) — each row is i*F_m
        M  = np.cross(self._r_all, iF).sum(axis=0)  # (3,)

        return {"c": c, "N": N, "M": M}

    # def _plastic_limit_internal(
    #     self,
    #     r0: np.ndarray,
    #     n: int,
    #     rneg: np.ndarray,
    #     rpos: np.ndarray,
    #     nsign: float,
    # ) -> dict[str, Any]:

    #     d = abs(float(np.dot(r0, rpos - rneg)))
    #     if np.isclose(d, 0.0):
    #         raise ValueError("Degenerate fiber layout: plastic depth is zero.")

    #     rn = self.fibers[n].r
    #     c = float(np.dot(r0, rn - rneg) / d)

    #     N = np.zeros(3)
    #     M = np.zeros(3)

    #     for m, fiber in enumerate(self.fibers):
    #         rm = fiber.r
    #         strength = fiber.stress_limit
    #         if m == n:
    #             F = nsign * strength
    #         elif float(np.dot(r0, rm - rneg) / d) < c:
    #             F = strength
    #         else:
    #             F = -strength
    #         N[0] += F
    #         M += np.cross(rm, self._i*F)

    #     return {"c": c, "N": N, "M": M}


    @staticmethod
    def _copy_state(state: dict[str, Any]) -> dict[str, Any]:
        copied: dict[str, Any] = {}
        for key, value in state.items():
            if isinstance(value, np.ndarray):
                copied[key] = value.copy()
            else:
                copied[key] = value
        return copied

    def extreme_fibers(self, k0: Sequence[float]) -> dict[str, Any]:
        """Find the extreme fibers in the direction orthogonal to ``k0``."""
        k0 = self._as_k0_vector(k0)
        r0, itop, ibot, imid, rtop, rbot, rmid = self._extreme_fiber_data(k0)

        return {
            "Top": {"id": itop, "ro": rtop},
            "Bot": {"id": ibot, "ro": rbot},
            "Mid": {"id": imid, "ro": rmid},
            "Depth": abs(float(np.dot(r0, rtop - rbot))),
        }

    def _extreme_fiber_data(self, k0):
        r0 = self._direction_from_i_cross_k(k0)
        projections = self._r_all @ r0
        norms = np.linalg.norm(self._r_all, axis=1)

        itop = int(np.argmax(projections))
        ibot = int(np.argmin(projections))
        imid = int(np.argmin(norms))
        return r0, itop, ibot, imid, self._r_all[itop], self._r_all[ibot], self._r_all[imid]

    def _direction_from_i_cross_k(self, k0: np.ndarray) -> np.ndarray:
        r0 = np.cross(self._i, k0)
        nr0 = np.linalg.norm(r0)
        if np.isclose(nr0, 0.0):
            raise ValueError("k0 must not be parallel to the axial direction [1, 0, 0].")
        return r0 / nr0

    def _direction_from_k_cross_i(self, k0: np.ndarray) -> np.ndarray:
        r0 = np.cross(k0, self._i)
        nr0 = np.linalg.norm(r0)
        if np.isclose(nr0, 0.0):
            raise ValueError("k0 must not be parallel to the axial direction [1, 0, 0].")
        return r0 / nr0

    def _as_k0_vector(self, k0: Sequence[float]) -> np.ndarray:
        arr = np.asarray(k0, dtype=float).reshape(-1)
        if arr.size == 2:
            return np.array([0.0, arr[0], arr[1]], dtype=float)
        if arr.size == 3:
            return arr.astype(float)
        raise ValueError(f"k0 must have length 2 or 3, got {arr.size}.")

    def _iter_axes(self, K0: Sequence[Sequence[float]] | Sequence[float]) -> np.ndarray:
        arr = np.asarray(K0, dtype=float)
        if arr.ndim == 1:
            return np.asarray([self._as_k0_vector(arr)], dtype=float)
        if arr.ndim != 2:
            raise ValueError(f"K0 must be a vector or matrix, got array with ndim={arr.ndim}.")

        if arr.shape == (3, 2):
            return np.asarray([self._as_k0_vector(col) for col in arr.T], dtype=float)
        if arr.shape == (2, 3):
            return np.asarray([self._as_k0_vector(row) for row in arr], dtype=float)

        if arr.shape[0] in (2, 3) and arr.shape[1] not in (2, 3):
            return np.asarray([self._as_k0_vector(col) for col in arr.T], dtype=float)
        if arr.shape[1] in (2, 3) and arr.shape[0] not in (2, 3):
            return np.asarray([self._as_k0_vector(row) for row in arr], dtype=float)

        if arr.shape in {(2, 2), (3, 3)}:
            return np.asarray([self._as_k0_vector(row) for row in arr], dtype=float)

        raise ValueError(
            "K0 must have shape (m, 2), (m, 3), (2, m), or (3, m)."
        )


def _extract_contour(
    surface: Sequence[dict[str, Any]],
    x_getter: Callable[[dict[str, Any]], float] | None = None,
    y_getter: Callable[[dict[str, Any]], float] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Extract the convex contour of a limit surface.

    By default this reproduces MATLAB `Extract_Contour`:
    X = state["M"][1], Y = state["N"][0].
    """
    if x_getter is None:
        x_getter = lambda state: float(np.asarray(state["M"], dtype=float)[1])
    if y_getter is None:
        y_getter = lambda state: float(np.asarray(state["N"], dtype=float)[0])

    points = [(x_getter(state), y_getter(state)) for state in surface]
    hull = _convex_hull(points)
    if not hull:
        return np.empty(0, dtype=float), np.empty(0, dtype=float)

    X = np.asarray([p[0] for p in hull], dtype=float)
    Y = np.asarray([p[1] for p in hull], dtype=float)
    return X, Y

# @jit
def _plane_cross(o: tuple[float, float], a: tuple[float, float], b: tuple[float, float]) -> float:
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

def _convex_hull(points: Sequence[tuple[float, float]]) -> list[tuple[float, float]]:
    pts = sorted({(float(x), float(y)) for x, y in points})
    if len(pts) <= 1:
        return pts.copy()


    lower: list[tuple[float, float]] = []
    for p in pts:
        while len(lower) >= 2 and _plane_cross(lower[-2], lower[-1], p) <= 0.0:
            lower.pop()
        lower.append(p)

    upper: list[tuple[float, float]] = []
    for p in reversed(pts):
        while len(upper) >= 2 and _plane_cross(upper[-2], upper[-1], p) <= 0.0:
            upper.pop()
        upper.append(p)

    hull = lower[:-1] + upper[:-1]
    if hull and hull[0] != hull[-1]:
        hull.append(hull[0])
    return hull


def _lin_clip(XY: Sequence[Sequence[float]], xref: float):
    XY = np.asarray(XY, dtype=float)
    if XY.ndim != 2 or XY.shape[1] != 2:
        raise ValueError(f"XY must have shape (n, 2), got {XY.shape}.")

    X = XY[:, 0]
    n = XY.shape[0]
    yref_vals: list[float] = []
    slopes: list[float] = []
    y_limits: list[np.ndarray] = []

    for target in (1.0, -1.0):
        for i in range(n):
            ys = target - XY[i, 1]
            Yt = XY[:, 1] + ys
            x = X[i]

            if np.max(Yt) <= 1.001 and np.min(Yt) >= -1.001:
                yref_vals.append(float(ys))
                slopes.append(0.0)
                y_limits.append(Yt.copy())

            for j in list(range(i)) + list(range(i + 1, n)):
                denom = X[j] - x
                if np.isclose(denom, 0.0):
                    continue

                for bound in (1.0, -1.0):
                    m = -(Yt[j] - bound) / denom
                    Yr = Yt + m * (X - x)
                    if np.max(Yr) <= 1.001 and np.min(Yr) >= -1.001:
                        yref_vals.append(float(ys + m * (x - xref)))
                        slopes.append(float(m))
                        y_limits.append(Yr.copy())

    if y_limits:
        Y_lim = np.column_stack(y_limits)
    else:
        Y_lim = np.empty((n, 0), dtype=float)

    return (
        np.asarray(yref_vals, dtype=float),
        np.asarray(slopes, dtype=float),
        Y_lim,
    )
