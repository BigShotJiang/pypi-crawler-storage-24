"""
PlasticAnalysis – fiber-based elastic/plastic limit analysis of cross-sections.

Ported from FEDEASLab MATLAB functions by F.C. Filippou & C.M. Perez (2025).
"""

from __future__ import annotations

import numpy as np
from scipy.spatial import ConvexHull
from dataclasses import dataclass, field
from typing import Sequence


def _cross(a, b):
    """Cross product for 3-vectors stored as 1-D numpy arrays."""
    return np.cross(a, b)


def _dot(a, b):
    return float(np.dot(a, b))


def _unit(v):
    """Return *v* / ||v|| (assumes v ≠ 0)."""
    return v / np.linalg.norm(v)


@dataclass
class _ExtremeFibers:
    top_id:    int
    top_r:     np.ndarray
    bot_id:    int
    bot_r:     np.ndarray
    mid_id:    int
    mid_r:     np.ndarray
    depth:     float


@dataclass
class _SectionLimit:
    N:     np.ndarray          # 3×1 force resultant
    M:     np.ndarray          # 3×1 moment resultant
    c:     float = 0.0         # normalized neutral-axis coordinate (plastic)
    P:     float = 0.0         # axial component  i'·N
    My:    float = 0.0         # moment component k0'·M
    r_neg: np.ndarray = field(default_factory=lambda: np.zeros(3))
    r_pos: np.ndarray = field(default_factory=lambda: np.zeros(3))
    depth: float = 0.0


class PlasticAnalysis:
    """
    Fiber-based elastic and plastic limit-surface analysis of a cross-section.

    Parameters
    ----------
    shape : object
        Any object that exposes ``shape.create_fibers()`` returning an iterable
        of dicts with keys ``"y"``, ``"z"``, ``"area"``, and optionally ``"Fy"``
        (yield stress; defaults to 1.0 if absent).
    """

    # unit vector along the member axis
    _i = np.array([1.0, 0.0, 0.0])

    # ------------------------------------------------------------------ init
    def __init__(self, shape):
        self.shape = shape
        self._Ks = np.zeros((6, 6)) 
        from xsection.analysis import SaintVenantSectionAnalysis
        sv = SaintVenantSectionAnalysis(shape)
        self._Ks[0,0] = sv.axial_rigidity()
        self._Ks[3:,3:] = sv.axial_inertia()

        # Pre-build the internal fiber list once
        self._fibers = self._build_fibers()

    # --------------------------------------------------------- fiber helpers
    def _build_fibers(self):
        """Convert shape fibers into an internal list of dicts with numpy r."""
        fibers = []
        for f in self.shape.create_fibers():
            fibers.append({
                "r":    np.array([0.0, f["y"], f["z"]]),   # position vector
                "area": f["area"],
                "Fy":   f.get("Fy", 1.0),
            })
        return fibers

    # ============================================================ PUBLIC API
    # --------------------------------------------- extreme fibers (helper)
    def extreme_fibers(self, k0: np.ndarray) -> _ExtremeFibers:
        """
        Find the extreme (top / bottom / nearest-to-origin) fibers in the
        direction orthogonal to a reference curvature *k0* (3-vector).

        Corresponds to ``Extreme_Fibers.m``.
        """
        k0 = np.asarray(k0, dtype=float).ravel()
        r0 = _unit(_cross(self._i, k0))

        top_id, top_r = -1, np.zeros(3)
        bot_id, bot_r = -1, np.zeros(3)
        mid_id, mid_r = -1, np.zeros(3)

        for m, fb in enumerate(self._fibers):
            rm = fb["r"]
            if _dot(r0, top_r) < _dot(r0, rm):
                top_r, top_id = rm.copy(), m
            if _dot(r0, bot_r) > _dot(r0, rm):
                bot_r, bot_id = rm.copy(), m
            if mid_id == -1 or np.linalg.norm(rm) < np.linalg.norm(mid_r):
                mid_r, mid_id = rm.copy(), m

        depth = abs(_dot(r0, top_r - bot_r))
        return _ExtremeFibers(top_id, top_r, bot_id, bot_r, mid_id, mid_r, depth)

    # -------------------------------------------- elastic limit (single k0)
    def elastic_limit(self, k0: np.ndarray, e0: float = 0.0) -> _SectionLimit:
        """
        Elastic limit state ``(N, M)`` for a given reference curvature *k0*
        and normalized axial strain *e0* ∈ [-1, 1].

        Requires ``self._Ks`` to be set (6×6 section stiffness).

        Corresponds to ``FiberElasticLimit.m``.
        """
        k0 = np.asarray(k0, dtype=float).ravel()
        i  = self._i

        # target max strains
        emp =  1.0 - e0
        emn = -1.0 - e0

        r0 = _unit(_cross(i, k0))

        # find extreme fibers
        rtop = np.zeros(3)
        rbot = np.zeros(3)
        for fb in self._fibers:
            rm = fb["r"]
            if _dot(r0, rtop) < _dot(r0, rm):
                rtop = rm.copy()
            if _dot(r0, rbot) > _dot(r0, rm):
                rbot = rm.copy()

        # max strains at extreme fibers
        ep = _dot(i, _cross(k0, rtop))
        en = _dot(i, _cross(k0, rbot))

        # scale kappa so that the max fibre strain equals ±1
        kappa = k0 * min(emp / ep, emn / en)

        # --- section stiffness blocks from 6×6 Ks ----
        if self._Ks is None:
            raise RuntimeError(
                "Set ._Ks (6×6 section stiffness) before calling elastic_limit."
            )
        Ks = self._Ks
        # Ks layout: rows/cols ordered (N, Vy, Vz, T, My, Mz)
        #   Cnn → Ks[0:3, 0:3]   Cnm → Ks[0:3, 3:6]   Cmm → Ks[3:6, 3:6]
        Cnn = Ks[:3, :3]
        Cnm = Ks[:3, 3:]
        Cmm = Ks[3:, 3:]

        N = Cnn @ (i * e0) + Cnm @ kappa
        M = Cnm.T @ (i * e0) + Cmm @ kappa

        return _SectionLimit(
            N=N, M=M,
            P=float(i @ N),
            My=float(k0 @ M),
            r_neg=rbot, r_pos=rtop,
            depth=abs(_dot(r0, rtop - rbot)),
        )

    def elastic_contour(self, *args, **kwargs):
        """
        """
        K = np.array([[0, 0],
                      [1, 0],
                      [0, 1]], dtype=float)
        return _extract_contour(self._elastic_contour(K, *args, **kwargs))

    # ----------------------------------------- elastic contour (sweep of k0)
    def _elastic_contour(self, K0: np.ndarray, n_axial: int = 10):
        """
        Sweep over several reference curvatures and axial strains to map
        out the elastic limit surface.

        Parameters
        ----------
        K0 : (3, n_k) array
            Each column is a reference curvature vector.
        n_axial : int
            Number of axial-strain levels between -1 and 1.

        Returns
        -------
        limits : list[_SectionLimit]

        Corresponds to ``FiberElasticContour.m``.
        """
        K0 = np.asarray(K0, dtype=float)
        if K0.ndim == 1:
            K0 = K0.reshape(3, 1)

        limits = []
        for j in range(K0.shape[1]):
            k0 = K0[:, j]
            for e0 in np.linspace(-1, 1, n_axial):
                limits.append(self.elastic_limit(k0, e0))
        return limits
    
    def plastic_contour(self, *args, **kwargs):
        """
        """
        K = np.array([[0, 0],
                      [1, 0],
                      [0, 1]], dtype=float).T
        return _extract_contour(self._plastic_contour(K, *args, **kwargs))

    # ----------------------------------- plastic limit (single pivot fiber)
    def _plastic_limit_internal(
        self,
        r0: np.ndarray,
        n: int,
        r_neg: np.ndarray,
        r_pos: np.ndarray,
        nsign: float,
    ) -> _SectionLimit:
        """
        Plastic limit resultant when fibre *n* is the neutral-axis pivot.

        Corresponds to ``FiberPlasticLimit_Internal.m``.
        """
        i = self._i
        d = abs(_dot(r0, r_pos - r_neg))

        rn = self._fibers[n]["r"]
        c  = _dot(r0, rn - r_neg) / d          # normalised NA coordinate

        N = np.zeros(3)
        M = np.zeros(3)
        for m, fb in enumerate(self._fibers):
            rm   = fb["r"]
            Fy   = fb["Fy"]
            area = fb["area"]
            if m == n:
                F = area * Fy * i * nsign
            elif _dot(r0, rm - r_neg) / d < c:
                F =  area * Fy * i
            else:
                F = -area * Fy * i
            N += F
            M += _cross(rm, F)

        return _SectionLimit(N=N, M=M, c=c)

    # ----------------------------------------- plastic contour (single k0)
    def _plastic_contour(self, k0: np.ndarray):
        """
        Full plastic interaction contour for one reference curvature *k0*.

        Returns
        -------
        limits : list[_SectionLimit]

        Corresponds to ``FiberPlasticContour.m`` (``FiberPlasticSurface``).
        """
        k0 = np.asarray(k0, dtype=float).ravel()
        i  = self._i
        limits = []
        nsign = 1

        for k in (k0, -k0):
            el = self.elastic_limit(k)   # only used for r_neg / r_pos
            r_neg = el.r_neg
            r_pos = el.r_pos
            r0    = _unit(_cross(k, i))

            for n in range(len(self._fibers)):
                lim = self._plastic_limit_internal(r0, n, r_neg, r_pos, nsign)
                limits.append(lim)
            nsign = -nsign

        # close the contour
        limits.append(limits[0])
        return limits

    # ---- plastic contour (no elastic stiffness needed) -------------------
    def plastic_contour_direct(self, k0: np.ndarray):
        """
        Full plastic interaction contour for one reference curvature *k0*,
        using only fiber geometry (no ``_Ks`` required).

        Returns
        -------
        limits : list[_SectionLimit]
        """
        k0 = np.asarray(k0, dtype=float).ravel()
        i  = self._i
        limits = []
        nsign = 1

        for k in (k0, -k0):
            ext = self.extreme_fibers(k)
            r_neg = ext.top_r
            r_pos = ext.bot_r
            r0    = _unit(_cross(k, i))

            for n in range(len(self._fibers)):
                lim = self._plastic_limit_internal(r0, n, r_neg, r_pos, nsign)
                limits.append(lim)
            nsign = -nsign

        # close the contour
        limits.append(limits[0])
        return limits

    # ------------------------------------------ plastic limit (multi-k0)
    def plastic_limit(self, K0: np.ndarray | None = None):
        """
        Plastic moment *Mp* and axial capacity *Np* for each reference
        curvature in *K0*.

        Parameters
        ----------
        K0 : (3, n_k) array, optional
            Defaults to ``[[0,0],[1,0],[0,1]]``.

        Returns
        -------
        Mp, Np, Depth : 1-D arrays of length n_k.

        Corresponds to ``FiberPlasticLimit.m``.
        """
        if K0 is None:
            K0 = np.array([[0, 0],
                           [1, 0],
                           [0, 1]], dtype=float)
        K0 = np.asarray(K0, dtype=float)
        if K0.ndim == 1:
            K0 = K0.reshape(3, 1)

        i  = self._i
        n_k = K0.shape[1]
        Mp    = np.zeros(n_k)
        Np    = np.zeros(n_k)
        Depth = np.zeros(n_k)

        for j in range(n_k):
            k0  = K0[:, j]
            ext = self.extreme_fibers(k0)
            r_pos = ext.bot_r
            r_neg = ext.top_r
            r0    = _unit(_cross(k0, i))
            nsign = -1

            # moment capacity – pivot at mid fiber
            n_mid    = ext.mid_id
            m_limit  = self._plastic_limit_internal(r0, n_mid, r_neg, r_pos, nsign)

            # axial capacity – pivot at bottom fiber
            n_bot    = ext.bot_id
            n_limit  = self._plastic_limit_internal(r0, n_bot, r_neg, r_pos, -nsign)

            Mp[j]    = float(k0 @ m_limit.M)
            Np[j]    = float(i  @ n_limit.N)
            Depth[j] = ext.depth

        return Mp, Np, Depth


def _extract_contour(limits: Sequence[_SectionLimit]):
    """
    Extract a 2-D (M_y , N) interaction contour from a list of limit
    states using the convex hull.

    Returns
    -------
    X, Y : 1-D arrays  (moment, axial force)

    Corresponds to ``Extract_Contour.m``.
    """
    Xp = np.array([s.M[2] for s in limits])   # M about z  (index 2)
    Yp = np.array([s.N[0] for s in limits])   # axial N    (index 0)

    pts = np.column_stack([Xp, Yp])
    hull = ConvexHull(pts)
    idx  = np.append(hull.vertices, hull.vertices[0])   # close polygon
    return Xp[idx], Yp[idx]