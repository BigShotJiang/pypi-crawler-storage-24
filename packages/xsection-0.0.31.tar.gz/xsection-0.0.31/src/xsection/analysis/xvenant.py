from xara.auto import Array 


def venant_warping(mesh, nu: float)->Array[:,3,3]:
    """
    mesh is a tuple of 
    - nodes: Array[nn, 2]
    - elems: IntArray[ne, 9] (Quadrilaterals with 9 nodes)
    - material: Array[ne,2] (E, G)
    """
    pass 



def energy_trace(mesh, nu):
    pass