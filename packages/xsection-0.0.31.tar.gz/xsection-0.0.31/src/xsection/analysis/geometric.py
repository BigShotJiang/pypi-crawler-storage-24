


class GeometricProperties:
    def __init__(self, shape):
        self.shape = shape


        self._A   = None 
        self._Iy  = None
        self._Iz  = None
        self._Iyz = None
        self._centroid = None
    

    @property
    def A(self):
        if self._A is None:
            self._A = 0.0
            for fiber in self.shape.create_fibers():
                self._A += fiber["area"]
        return self._A

    @property
    def centroid(self):
        if self._centroid is None:
            A = self.A
            x_sum = 0.0
            y_sum = 0.0
            for fiber in self.shape.create_fibers():
                x_sum += fiber["x"]*fiber["area"]
                y_sum += fiber["y"]*fiber["area"]
            self._centroid = (x_sum/A, y_sum/A)
        return self._centroid
    

    @property
    def Iy(self):
        if self._Iy is None:
            self._Iy = 0.0
            for fiber in self.shape.create_fibers():
                self._Iy += fiber["area"]*fiber["y"]**2
        return self._Iy
    

    @property
    def Iz(self):
        if self._Iz is None:
            self._Iz = 0.0
            for fiber in self.shape.create_fibers():
                self._Iz += fiber["area"]*fiber["x"]**2
        return self._Iz