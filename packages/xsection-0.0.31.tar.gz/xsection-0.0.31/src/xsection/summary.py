import textwrap
import numpy as np
class Summary:
    def __init__(self, shape, material=None, sv=None):
        self.shape = shape
        self.material = material
        if sv is None:
            from xsection.analysis import SaintVenantSectionAnalysis
            sv = SaintVenantSectionAnalysis(self.shape)
        self._sv = sv


        self.cmm = sv.axial_inertia
        self.cnn = np.zeros((3,3))
        self.cnn[0,0] = sv.axial_rigidity()

    
    def string(self, format="console"):
        if format is None:
            format = "console"

        if format in {"texsec", "texsection"}:
            return self.texsec()
        elif format == "console":
            return self.console()
        else:
            raise ValueError(f"Unsupported format: {format}")



    def texsec(self):
        material = self.material
        sv = self._sv

        shape = self.shape
        if material is None and hasattr(shape,"material") and shape.material is not None:
            material = shape.material

        if material is not None:
            E = material["E"]
            G = material["G"]
        else:
            E = G = 1.0
        
        A = shape.area

        GJ = sv.twist_rigidity()
        te = sv.create_trace("energetic")
        tg = sv.create_trace("geometric")
        GA = sv._GA
        eGAs = te.shear_rigidity()
        gGAs = tg.shear_rigidity()
        eGJ = te.twist_rigidity()
        gGJ = tg.twist_rigidity()
        eShiftTwist = te.shift_twist_gamma()
        eShiftAxial = te.shift_twist_axial()
        gShiftTwist = tg.shift_twist_gamma()
        gShiftAxial = tg.shift_twist_axial()

        EIo = sv.axial_inertia()
        EIc = sv.axial_inertia_centroid()

        return textwrap.dedent(f"""
        E=\\num{{{E}}},
        G=\\num{{{G}}},
        A=\\num{{{A}}},
        EA={{\\num{{{sv._EA/E}}} $E$}},
        EIy={{\\num{{{EIo[1,1]/E}}} $E$}},
        EIz={{\\num{{{EIo[2,2]/E}}} $E$}},
        EIcy={{\\num{{{EIc[1,1]/E}}} $E$}},
        EIcz={{\\num{{{EIc[2,2]/E}}} $E$}},
        GJ={{\\num{{{GJ/G}}} $G$}},
        %
        energetic/TwistScale={{\\num{{{eGJ/GJ}}}}},
        energetic/GAy={{\\num{{{eGAs[0,0]/GA}}}  $\\widehat{{GA}}$}},
        energetic/GAz={{\\num{{{eGAs[1,1]/GA}}}  $\\widehat{{GA}}$}},
        energetic/GAyz={{\\num{{{eGAs[0,1]/GA}}} $\\widehat{{GA}}$}},
        energetic/GAzy={{\\num{{{eGAs[1,0]/GA}}} $\\widehat{{GA}}$}},
        energetic/ShiftTwistY={{\\num{{{eShiftTwist[0]}}}}},
        energetic/ShiftTwistZ={{\\num{{{eShiftTwist[1]}}}}},
        energetic/ShiftAxialY={{\\num{{{eShiftAxial[0]}}}}},
        energetic/ShiftAxialZ={{\\num{{{eShiftAxial[1]}}}}},
        %
        geometric/TwistScale={{\\num{{{gGJ/GJ}}}}},
        geometric/GAy={{\\num{{{gGAs[0,0]/GA}}}  $\\widehat{{GA}}$}},
        geometric/GAz={{\\num{{{gGAs[1,1]/GA}}}  $\\widehat{{GA}}$}},
        geometric/GAyz={{\\num{{{gGAs[0,1]/GA}}} $\\widehat{{GA}}$}},
        geometric/GAzy={{\\num{{{gGAs[1,0]/GA}}} $\\widehat{{GA}}$}},
        geometric/ShiftTwistY={{\\num{{{gShiftTwist[0]}}}}},
        geometric/ShiftTwistZ={{\\num{{{gShiftTwist[1]}}}}},
        geometric/ShiftAxialY={{\\num{{{gShiftAxial[0]}}}}},
        geometric/ShiftAxialZ={{\\num{{{gShiftAxial[1]}}}}},
        """)

    def console(self):
        material = self.material
        sv = self._sv
        shape = self.shape

        if material is None and hasattr(shape, "material") and shape.material is not None:
            material = shape.material

        if material is not None:
            E = material["E"]
            G = material["G"]
        else:
            E = G = 1.0

        A = shape.area
        GJ = sv.twist_rigidity()
        te = sv.create_trace("energetic")
        tg = sv.create_trace("geometric")
        GA = sv._GA
        eGAs = te.shear_rigidity()
        gGAs = tg.shear_rigidity()
        eGJ = te.twist_rigidity()
        gGJ = tg.twist_rigidity()
        eShiftTwist = te.shift_twist_gamma()
        eShiftAxial = te.shift_twist_axial()
        gShiftTwist = tg.shift_twist_gamma()
        gShiftAxial = tg.shift_twist_axial()
        EIo = sv.axial_inertia()
        EIc = sv.axial_inertia_centroid()

        # TODO
        EIw = 0.0
        EIv = 0.0

        def fmt(v, w=12):
            return f"{v:>{w}.6g}"

        lines = []
        W = 38
        sep = " │ "
        rule_single = "-" + "─" * W + "─┼─" + "─" * W
        rule_full   = "-" + "─" * W + "─┼─" + "─" * W

        def row2(c1, c2):
            return f" {c1:<{W}}{sep}{c2:<{W}}"

        #  Header: reference material
        lines.append(f"  E = {fmt(E)}    G = {fmt(G)}    A = {fmt(A)}")
        lines.append("")

        #  Top section: Flexure | Torsion
        lines.append(row2("FLEXURE", "TORSION"))
        lines.append(rule_single)
        lines.append(row2(
            f"EA   = {fmt(sv._EA/E)} E",
            f"GJ   = {fmt(GJ/G)} G",
        ))
        lines.append(row2(
            f"EIy  = {fmt(EIo[1,1]/E)} E",
            f"EIw  = {fmt(EIw/E)} E",
        ))
        lines.append(row2(
            f"EIz  = {fmt(EIo[2,2]/E)} E",
            f"EIv  = {fmt(EIv/E)} E",
        ))
        lines.append(row2(
            f"EIcy = {fmt(EIc[1,1]/E)} E",
            "",
        ))
        lines.append(row2(
            f"EIcz = {fmt(EIc[2,2]/E)} E",
            "",
        ))
        lines.append("")

        #  Bottom section: Energetic | Geometric traces
        lines.append(row2("ENERGETIC TRACE", "GEOMETRIC TRACE"))
        lines.append(rule_single)
        lines.append(row2(
            f"TwistScale  = {fmt(eGJ/GJ)}",
            f"TwistScale  = {fmt(gGJ/GJ)}",
        ))
        lines.append(row2(
            f"GAy         = {fmt(eGAs[0,0]/GA)} GA",
            f"GAy         = {fmt(gGAs[0,0]/GA)} GA",
        ))
        lines.append(row2(
            f"GAz         = {fmt(eGAs[1,1]/GA)} GA",
            f"GAz         = {fmt(gGAs[1,1]/GA)} GA",
        ))
        lines.append(row2(
            f"GAyz        = {fmt(eGAs[0,1]/GA)} GA",
            f"GAyz        = {fmt(gGAs[0,1]/GA)} GA",
        ))
        lines.append(row2(
            f"GAzy        = {fmt(eGAs[1,0]/GA)} GA",
            f"GAzy        = {fmt(gGAs[1,0]/GA)} GA",
        ))
        lines.append(row2(
            f"ShiftTwistY = {fmt(eShiftTwist[0])}",
            f"ShiftTwistY = {fmt(gShiftTwist[0])}",
        ))
        lines.append(row2(
            f"ShiftTwistZ = {fmt(eShiftTwist[1])}",
            f"ShiftTwistZ = {fmt(gShiftTwist[1])}",
        ))
        lines.append(row2(
            f"ShiftAxialY = {fmt(eShiftAxial[0])}",
            f"ShiftAxialY = {fmt(gShiftAxial[0])}",
        ))
        lines.append(row2(
            f"ShiftAxialZ = {fmt(eShiftAxial[1])}",
            f"ShiftAxialZ = {fmt(gShiftAxial[1])}",
        ))

        return "\n".join(lines)