"""Custom exceptions for privacy-creds."""


class PrivacyCredsError(Exception):
    """Base exception for all privacy-creds errors."""


class CredentialError(PrivacyCredsError):
    """Raised when a credential is invalid, expired, or cannot be issued."""


class SignatureError(PrivacyCredsError):
    """Raised when a cryptographic signature fails verification."""


class DeviceBindingError(PrivacyCredsError):
    """Raised when a device binding check fails — key was used on wrong device."""


class WalletError(PrivacyCredsError):
    """Raised when a wallet operation fails — missing files, corrupt data, etc."""


class VerificationError(PrivacyCredsError):
    """Raised when proof verification fails for any reason."""
