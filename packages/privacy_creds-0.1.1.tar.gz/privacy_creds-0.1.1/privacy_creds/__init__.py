"""
privacy-creds: Privacy-preserving identity verification for games.

Players prove who they are without exposing personal data.
"""

from .sdk import PlayerWallet, GameVerifier, VerificationResult
from .issuer import Issuer, Credential, Claims
from .storage import FileStorage
from .exceptions import (
    PrivacyCredsError,
    CredentialError,
    SignatureError,
    DeviceBindingError,
    WalletError,
    VerificationError,
)

__version__ = "0.1.1"

__all__ = [
    # Core SDK
    "PlayerWallet",
    "GameVerifier",
    "VerificationResult",
    # Issuer
    "Issuer",
    "Credential",
    "Claims",
    # Storage
    "FileStorage",
    # Exceptions
    "PrivacyCredsError",
    "CredentialError",
    "SignatureError",
    "DeviceBindingError",
    "WalletError",
    "VerificationError",
]
