# privacy-creds

Privacy-preserving identity verification for games and applications.

Players prove who they are (age, region) **without exposing personal data**. No names, no IDs, no documents stored — just cryptographic proofs.

## The problem

Games need age verification and regional compliance. Current solutions require uploading government ID to a database — creating breach risk and GDPR headaches.

## The solution

```
Player verifies ID once → credential stored on their device →
game receives a yes/no answer → never sees the raw identity data
```

## How it works

1. **KYC provider** verifies the player's identity and issues a signed credential
2. **Player's device** stores the credential with a device-bound private key
3. **Game** sends a random challenge → player signs it → game verifies the signature and checks the claim

The game learns *one thing*: "Is this player over 18?" Nothing else.

## Security layers

| Layer | Protection |
|---|---|
| Issuer signatures | Prevents forged credentials |
| Challenge-response | Prevents replay attacks |
| Device binding | Prevents credential sharing between devices |

## Installation

```bash
pip install privacy-creds
```

## Quick start

### Game backend (verifier)

```python
from privacy_creds import GameVerifier

verifier = GameVerifier(issuer_pubkey_pem=open("issuer_public.pem").read())

# Per player session:
challenge = verifier.create_challenge()
# ... send challenge to player, receive proof back ...
result = verifier.verify(proof, required_age=18)

if result:
    print("Access granted")
else:
    print(f"Denied: {result.reason}")
```

### Player app (wallet)

```python
from privacy_creds import PlayerWallet

wallet = PlayerWallet(user_id="player123")
wallet.setup(credential_from_kyc_provider)

# When game requests verification:
proof = wallet.prove(challenge_from_game)
# ... send proof to game ...
```

### Issuer (KYC provider)

```python
from privacy_creds import Issuer, FileStorage

issuer = Issuer(storage=FileStorage("/secure/path"))
issuer.generate_keys()

credential = issuer.issue(user_id="player123", age=22, country="GB")
```

## Running the demo

```bash
git clone https://github.com/cairnintelligence/privacy-creds.git
cd privacy-creds
pip install -e ".[dev]"
python -m examples.demo
```

## Running tests

```bash
pytest
```

## Supported age thresholds

- 13 (COPPA)
- 16 (GDPR minimum)
- 18 (most gaming regulations)
- 21 (US gambling)
- 25 (rental/financial services)

## Roadmap

- [ ] Zero-knowledge proof layer (Noir/zkSNARK)
- [ ] REST API wrapper (FastAPI)
- [ ] React Native player app
- [ ] TPM/Secure Enclave hardware key storage
- [ ] Credential expiry and renewal
- [ ] Multi-issuer trust federation

## License

MIT — see [LICENSE](LICENSE).

## Built by

[Cairn Intelligence](https://cairnintelligence.com)
