import bilbystats as bs


async def detect_sentiment_async(
    text: str,
    model_name: str = "gpt-4o",
) -> str:
    """
    Async detect the sentiment of a given text using a specified language model.

    This function uses the OpenAI API to analyze the sentiment of the provided
    text asynchronously. It classifies the sentiment as 'positive', 'neutral', or 'negative',
    and returns only the sentiment label.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    text : str
        The text for which sentiment analysis is to be performed.
    model_name : str, optional (default="gpt-4o")
        The name of the OpenAI model used for sentiment analysis.

    ---------------------------------------------------------------------------
    OUTPUT:
    sentiment : str
        The sentiment classification of the input text ('positive',
        'neutral', or 'negative').

    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport and Stephen Enwright-Ward
    ---------------------------------------------------------------------------
    """
    instructions = 'You are an expert in sentiment analysis. Given any input text, determine the overall sentiment and classify it as one of the following categories: positive, neutral, or negative. Respond with only one of these words — "positive", "neutral", or "negative" — and nothing else.'
    sentiment = await bs.llm_api_async(
        text,
        instructions,
        model_name=model_name,
    )

    return sentiment