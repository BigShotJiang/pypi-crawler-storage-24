from typing import Type
from pydantic import BaseModel


def _pydantic_to_tool_schema(
    model_class: Type[BaseModel],
) -> dict:
    """Convert a Pydantic model to Claude tool schema format."""
    schema = model_class.model_json_schema()

    return {
        "name": "structured_response",
        "description": f"Provide a structured response in {model_class.__name__} format",
        "input_schema": {
            "type": "object",
            "properties": schema.get("properties", {}),
            "required": schema.get("required", []),
        },
    }