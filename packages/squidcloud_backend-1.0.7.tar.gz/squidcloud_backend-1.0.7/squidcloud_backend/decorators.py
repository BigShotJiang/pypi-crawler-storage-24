"""All backend decorators mirroring the TypeScript SDK's actions.ts.

Each decorator registers metadata on the global Meta singleton and returns
the original function unchanged. The metadata is later collected by
SquidProject.metadata() and sent to the platform.

Mirrors: backend/src/actions.ts
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar, overload

from squidcloud_backend.metadata import get_metadata
from squidcloud_backend.types import (
    BUILT_IN_DB_INTEGRATION_ID,
    BUILT_IN_QUEUE_INTEGRATION_ID,
    BUILT_IN_STORAGE_INTEGRATION_ID,
    AiFunctionAttributes,
    AiFunctionMetadataOptions,
    AiFunctionParam,
    AiFunctionsConfiguratorMetadataOptions,
    DatabaseActionType,
    LimiterConfig,
    LlmServiceOptions,
    McpServerOptions,
    McpToolMetadataOptions,
    MutationType,
    SchedulerOptions,
    SecureMetricOptions,
    StorageActionType,
    TopicActionType,
    TriggerOptions,
    limiter_config_to_options,
)

F = TypeVar("F", bound=Callable[..., Any])

# Marker attribute for deferred decorator registrations
_SQUID_DECORATORS = "__squid_decorators__"


def _get_service_function_name(cls: type, method_name: str) -> str:
    """Build 'ClassName:method_name' matching TS getServiceFunctionName()."""
    return f"{cls.__name__}:{method_name}"


def _register_on_class_init(
    fn: F, decorator_name: str, register_fn: Callable[[type, str], None]
) -> F:
    """Store a deferred registration on the function.

    Registrations are finalized in SquidService.__init_subclass__().
    """
    pending: list = getattr(fn, _SQUID_DECORATORS, [])
    pending.append((decorator_name, register_fn))
    setattr(fn, _SQUID_DECORATORS, pending)
    return fn


# ---------------------------------------------------------------------------
# Executable
# ---------------------------------------------------------------------------


def executable() -> Callable[[F], F]:
    """Mark a method as callable from the client SDK."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().executable(sfn)

        return _register_on_class_init(fn, "executable", register)

    return decorator


# ---------------------------------------------------------------------------
# Trigger
# ---------------------------------------------------------------------------


@overload
def trigger(
    id: str,
    collection_name: str,
    integration_id: str | None = ...,
) -> Callable[[F], F]: ...


@overload
def trigger(options: TriggerOptions) -> Callable[[F], F]: ...


@overload
def trigger(
    *,
    collection: str,
    id: str | None = ...,
    integration_id: str | None = ...,
    mutation_types: list[MutationType] | None = ...,
) -> Callable[[F], F]: ...


def trigger(
    id_or_options: str | TriggerOptions | None = None,
    collection_name: str | None = None,
    integration_id: str | None = None,
    *,
    collection: str | None = None,
    mutation_types: list[MutationType] | None = None,
    id: str | None = None,
) -> Callable[[F], F]:
    """Decorator that marks a function as a trigger on collection changes."""
    if isinstance(id_or_options, dict):
        opts = id_or_options
    elif isinstance(id_or_options, str):
        opts = TriggerOptions(
            id=id_or_options,
            collection=collection_name or "",
            integrationId=integration_id or BUILT_IN_DB_INTEGRATION_ID,
        )
    else:
        opts = TriggerOptions(
            id=id,
            collection=collection or collection_name or "",
            integrationId=integration_id or BUILT_IN_DB_INTEGRATION_ID,
            mutationTypes=mutation_types,
        )

    coll = opts.get("collection", "")
    if not coll:
        raise ValueError("Collection name is required for @trigger")

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            trigger_id = opts.get("id") or sfn
            get_metadata().trigger(
                trigger_id=trigger_id,
                collection_name=coll,
                service_function=sfn,
                integration_id=opts.get("integrationId", BUILT_IN_DB_INTEGRATION_ID),
                mutation_types=opts.get("mutationTypes"),
            )

        return _register_on_class_init(fn, "trigger", register)

    return decorator


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------


@overload
def scheduler(
    id: str,
    cron_expression: str,
    exclusive: bool = ...,
) -> Callable[[F], F]: ...


@overload
def scheduler(options: SchedulerOptions) -> Callable[[F], F]: ...


@overload
def scheduler(
    *,
    cron: str,
    id: str | None = ...,
    exclusive: bool | None = ...,
) -> Callable[[F], F]: ...


def scheduler(
    id_or_options: str | SchedulerOptions | None = None,
    cron_expression: str | None = None,
    exclusive: bool | None = None,
    *,
    cron: str | None = None,
    id: str | None = None,
) -> Callable[[F], F]:
    """Decorator that marks a function as a scheduled task."""
    if isinstance(id_or_options, dict):
        opts = id_or_options
    elif isinstance(id_or_options, str):
        opts = SchedulerOptions(id=id_or_options, cron=cron_expression or "")
        if exclusive is not None:
            opts["exclusive"] = exclusive
    else:
        opts = SchedulerOptions(cron=cron or cron_expression or "")
        if id is not None:
            opts["id"] = id
        if exclusive is not None:
            opts["exclusive"] = exclusive

    cron_val = opts.get("cron", "")
    if not cron_val:
        raise ValueError("Cron expression is required for @scheduler")

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            sched_id = opts.get("id") or sfn
            cron_str = cron_val.value if hasattr(cron_val, "value") else str(cron_val)
            get_metadata().scheduler(
                scheduler_id=sched_id,
                cron_expression=cron_str,
                service_function=sfn,
                exclusive=opts.get("exclusive", True),
            )

        return _register_on_class_init(fn, "scheduler", register)

    return decorator


# ---------------------------------------------------------------------------
# Webhook
# ---------------------------------------------------------------------------


def webhook(webhook_id: str) -> Callable[[F], F]:
    """Decorator that marks a function as a webhook handler."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().webhook(webhook_id, sfn)

        return _register_on_class_init(fn, "webhook", register)

    return decorator


# ---------------------------------------------------------------------------
# AI Function
# ---------------------------------------------------------------------------


@overload
def ai_function(
    description: str,
    params: list[AiFunctionParam],
    attributes: AiFunctionAttributes | None = ...,
    categories: list[str] | None = ...,
    internal: bool | None = ...,
) -> Callable[[F], F]: ...


@overload
def ai_function(options: AiFunctionMetadataOptions) -> Callable[[F], F]: ...


def ai_function(
    description_or_options: str | AiFunctionMetadataOptions | None = None,
    params: list[AiFunctionParam] | None = None,
    attributes: AiFunctionAttributes | None = None,
    categories: list[str] | None = None,
    internal: bool | None = None,
) -> Callable[[F], F]:
    """Decorator that exposes a function to AI agents."""
    if isinstance(description_or_options, dict):
        opts = description_or_options
    else:
        opts = AiFunctionMetadataOptions(
            description=description_or_options or "",
            params=params or [],
        )
        if attributes is not None:
            opts["attributes"] = attributes
        if categories is not None:
            opts["categories"] = categories
        if internal is not None:
            opts["internal"] = internal

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            # Default ID is the method name only (after the colon), matching TS behavior
            func_id = opts.get("id") or method_name
            get_metadata().ai_function(
                sfn,
                ai_function_id=func_id,
                description=opts.get("description", ""),
                params=opts.get("params", []),
                attributes=opts.get("attributes") or {},
                categories=opts.get("categories") or [],
                internal=opts.get("internal", False),
            )

        return _register_on_class_init(fn, "ai_function", register)

    return decorator


# ---------------------------------------------------------------------------
# AI Functions Configurator
# ---------------------------------------------------------------------------


def ai_functions_configurator(
    options: AiFunctionsConfiguratorMetadataOptions,
) -> Callable[[F], F]:
    """Decorator for AI function configurators."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            # Default ID is the method name only (after the colon), matching TS behavior
            func_id = options.get("id") or method_name
            get_metadata().ai_functions_configurator(
                sfn,
                configurator_id=func_id,
                integration_types=options.get("integrationTypes", []),
            )

        return _register_on_class_init(fn, "ai_functions_configurator", register)

    return decorator


# ---------------------------------------------------------------------------
# Security decorators
# ---------------------------------------------------------------------------


def secure_database(
    action_type: DatabaseActionType,
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Secure database operations."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_database(
                action_type, sfn, integration_id or BUILT_IN_DB_INTEGRATION_ID
            )

        return _register_on_class_init(fn, "secure_database", register)

    return decorator


def secure_ai_query(
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Secure AI-powered queries."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_ai_query(sfn, integration_id or BUILT_IN_DB_INTEGRATION_ID)

        return _register_on_class_init(fn, "secure_ai_query", register)

    return decorator


def secure_collection(
    collection_name: str,
    action_type: DatabaseActionType,
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Secure operations on a specific collection."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_collection(
                collection_name, action_type, sfn, integration_id or BUILT_IN_DB_INTEGRATION_ID
            )

        return _register_on_class_init(fn, "secure_collection", register)

    return decorator


def secure_storage(
    action_type: StorageActionType,
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Secure storage operations."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_storage(
                action_type, sfn, integration_id or BUILT_IN_STORAGE_INTEGRATION_ID
            )

        return _register_on_class_init(fn, "secure_storage", register)

    return decorator


def secure_topic(
    topic_name: str,
    action_type: TopicActionType,
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Secure topic/queue operations."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_topic(
                topic_name, action_type, sfn, integration_id or BUILT_IN_QUEUE_INTEGRATION_ID
            )

        return _register_on_class_init(fn, "secure_topic", register)

    return decorator


def secure_metric(options: SecureMetricOptions) -> Callable[[F], F]:
    """Secure metric access."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_metric(
                options.get("metricNamePrefix", ""),
                options.get("type", "all"),
                sfn,
            )

        return _register_on_class_init(fn, "secure_metric", register)

    return decorator


def secure_api(
    integration_id: str,
    endpoint_id: str | None = None,
) -> Callable[[F], F]:
    """Secure API call access."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_api(integration_id, endpoint_id, sfn)

        return _register_on_class_init(fn, "secure_api", register)

    return decorator


def secure_graphql(integration_id: str) -> Callable[[F], F]:
    """Secure GraphQL operations."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_graphql(integration_id, sfn)

        return _register_on_class_init(fn, "secure_graphql", register)

    return decorator


def secure_native_query(integration_id: str) -> Callable[[F], F]:
    """Secure native database queries."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_native_query(integration_id, sfn)

        return _register_on_class_init(fn, "secure_native_query", register)

    return decorator


def secure_distributed_lock(mutex: str | None = None) -> Callable[[F], F]:
    """Secure distributed lock access."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_distributed_lock(mutex, sfn)

        return _register_on_class_init(fn, "secure_distributed_lock", register)

    return decorator


def secure_ai_agent(agent_id: str | None = None) -> Callable[[F], F]:
    """Secure AI agent access."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().secure_ai_agent(agent_id, sfn)

        return _register_on_class_init(fn, "secure_ai_agent", register)

    return decorator


# ---------------------------------------------------------------------------
# Transform decorators
# ---------------------------------------------------------------------------


def transform_database(
    action_type: DatabaseActionType,
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Transform database operations."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().transform_database(
                action_type, sfn, integration_id or BUILT_IN_DB_INTEGRATION_ID
            )

        return _register_on_class_init(fn, "transform_database", register)

    return decorator


def transform_collection(
    collection_name: str,
    action_type: DatabaseActionType,
    integration_id: str | None = None,
) -> Callable[[F], F]:
    """Transform operations on a specific collection."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().transform_collection(
                collection_name, action_type, sfn, integration_id or BUILT_IN_DB_INTEGRATION_ID
            )

        return _register_on_class_init(fn, "transform_collection", register)

    return decorator


# ---------------------------------------------------------------------------
# Limits
# ---------------------------------------------------------------------------


def limits(config: LimiterConfig) -> Callable[[F], F]:
    """Apply rate/quota limits to a function."""
    options = limiter_config_to_options(config)

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().limits(sfn, options)

        return _register_on_class_init(fn, "limits", register)

    return decorator


# ---------------------------------------------------------------------------
# Client connection state handler
# ---------------------------------------------------------------------------


def client_connection_state_handler() -> Callable[[F], F]:
    """Handle client connect/disconnect events."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().client_connection_change_handler(sfn)

        return _register_on_class_init(fn, "client_connection_state_handler", register)

    return decorator


# ---------------------------------------------------------------------------
# LLM Service (class decorator)
# ---------------------------------------------------------------------------


def llm_service(options: LlmServiceOptions) -> Callable[[type], type]:
    """Class decorator that registers a class as an LLM service."""

    def decorator(cls: type) -> type:
        cls.__squid_llm_options__ = options  # type: ignore[attr-defined]
        return cls

    return decorator


# ---------------------------------------------------------------------------
# LLM Ask
# ---------------------------------------------------------------------------


def llm_ask() -> Callable[[F], F]:
    """Mark a method as the LLM ask handler."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().llm_ask(sfn)

        return _register_on_class_init(fn, "llm_ask", register)

    return decorator


# ---------------------------------------------------------------------------
# MCP Server (class decorator)
# ---------------------------------------------------------------------------


def mcp_server(options: McpServerOptions) -> Callable[[type], type]:
    """Class decorator that registers a class as an MCP server."""

    def decorator(cls: type) -> type:
        cls.__squid_mcp_options__ = options  # type: ignore[attr-defined]
        return cls

    return decorator


# ---------------------------------------------------------------------------
# MCP Tool
# ---------------------------------------------------------------------------


def mcp_tool(options: McpToolMetadataOptions) -> Callable[[F], F]:
    """Mark a method as an MCP tool."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().mcp_tool(sfn, options)

        return _register_on_class_init(fn, "mcp_tool", register)

    return decorator


# ---------------------------------------------------------------------------
# MCP Authorizer
# ---------------------------------------------------------------------------


def mcp_authorizer() -> Callable[[F], F]:
    """Mark a method as the MCP authorization handler."""

    def decorator(fn: F) -> F:
        def register(cls: type, method_name: str) -> None:
            sfn = _get_service_function_name(cls, method_name)
            get_metadata().mcp_authorizer(sfn)

        return _register_on_class_init(fn, "mcp_authorizer", register)

    return decorator
