"""SquidProject — the entry point for Python backend projects.

Mirrors: backend/src/project.ts
"""

from __future__ import annotations

from typing import Any

from squidcloud_backend.metadata import get_metadata
from squidcloud_backend.types import IntegrationLifecycleHooksMetadata, OnIntegrationLifecycleInput


class SquidProject:
    """Entry point for a Squid backend project.

    Users create an instance of this class in their main module.
    The platform calls ``metadata()`` to discover all registered services.

    The constructor detects which lifecycle hooks are overridden and
    registers them with the metadata system, matching the TS SDK behavior.

    Example::

        # src/main.py
        from squidcloud_backend import SquidProject
        from my_service import MyService  # importing triggers __init_subclass__

        project = SquidProject()
    """

    def __init__(self) -> None:
        # Detect overridden lifecycle hooks (matching TS SDK behavior in project.ts)
        cls = type(self)
        hooks = IntegrationLifecycleHooksMetadata(
            onIntegrationCreated=cls.on_integration_created
            is not SquidProject.on_integration_created,
            onIntegrationChanged=cls.on_integration_changed
            is not SquidProject.on_integration_changed,
            onIntegrationDeleted=cls.on_integration_deleted
            is not SquidProject.on_integration_deleted,
        )
        get_metadata().set_integration_lifecycle_hooks(hooks)

    @property
    def squid(self) -> Any:
        """The Squid client instance.

        Returns a ``squidcloud.Squid`` instance from the ``squidcloud-client`` package.
        """
        from squidcloud_backend.service import SquidService

        return SquidService._global_squid_client

    def metadata(self) -> dict:
        """Return the collected ApplicationBundleData as a JSON-serializable dict.

        Called by the platform to discover all services, executables,
        triggers, schedulers, webhooks, security rules, etc.
        """
        return get_metadata().data

    async def on_integration_created(self, context: OnIntegrationLifecycleInput) -> None:
        """Called when an integration is created. Override to handle."""

    async def on_integration_changed(self, context: OnIntegrationLifecycleInput) -> None:
        """Called when an integration configuration changes. Override to handle."""

    async def on_integration_deleted(self, context: OnIntegrationLifecycleInput) -> None:
        """Called when an integration is about to be deleted. Override to handle."""

    async def cleanup(self) -> None:
        """Called during graceful shutdown. Override to clean up resources."""
