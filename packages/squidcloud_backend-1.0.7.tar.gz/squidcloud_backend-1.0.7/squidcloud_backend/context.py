"""Request-scoped context management using Python contextvars.

Python equivalent of Node.js AsyncLocalStorage used in the TS SDK for
per-request state (auth, RunContext, etc.).
"""

from __future__ import annotations

import contextvars
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from squidcloud_backend.types import ServiceRequestConfig

_current_request: contextvars.ContextVar[ServiceRequestConfig | None] = contextvars.ContextVar(
    "_current_request", default=None
)


def get_request_config() -> ServiceRequestConfig:
    """Get the current request's ServiceRequestConfig.

    Raises:
        RuntimeError: If called outside of a request scope.
    """
    config = _current_request.get()
    if config is None:
        raise RuntimeError(
            "Failed to access request data outside of the request's scope. "
            "This method can only be called during request execution."
        )
    return config


def set_request_config(config: ServiceRequestConfig) -> contextvars.Token:
    """Set the request config for the current context. Returns a token for reset."""
    return _current_request.set(config)


def reset_request_config(token: contextvars.Token) -> None:
    """Reset the request config to its previous value."""
    _current_request.reset(token)


class RequestScope:
    """Context manager for running code within a request scope.

    Usage::

        with RequestScope(config):
            result = service.my_method(*args)
    """

    def __init__(self, config: ServiceRequestConfig) -> None:
        self._config = config
        self._token: contextvars.Token | None = None

    def __enter__(self) -> ServiceRequestConfig:
        self._token = set_request_config(self._config)
        return self._config

    def __exit__(self, *args: Any) -> None:
        if self._token is not None:
            reset_request_config(self._token)
            self._token = None
