"""Symbolic bitvector with three-valued logic (0, 1, unknown)."""

import re


def _normalize_provenance(prov):
    """Return None if provenance is empty/falsy, else the dict."""
    if not prov:
        return None
    return prov


def _build_provenance(name, ones, zeros, width):
    """Build provenance dict for unknown bits with given source name."""
    prov = {}
    for i in range(width):
        bit = 1 << i
        if not (ones & bit) and not (zeros & bit):
            prov[i] = (name, i)
    return _normalize_provenance(prov)


def _merge_bitwise_provenance(a, b, result_ones, result_zeros, width):
    """Compute provenance for the result of a bitwise op (AND/OR/XOR).

    Fast path: if neither input has provenance, return None.

    For each unknown result bit i:
    - If exactly one input was unknown at i: take that input's provenance.
    - If both unknown at i: keep provenance only if identical (name, src_idx).
    - Otherwise: no provenance for this bit.
    """
    if a._provenance is None and b._provenance is None:
        return None

    prov = {}
    for i in range(width):
        bit = 1 << i
        # Only unknown result bits can have provenance
        if (result_ones & bit) or (result_zeros & bit):
            continue

        a_unknown = not (a._ones & bit) and not (a._zeros & bit)
        b_unknown = not (b._ones & bit) and not (b._zeros & bit)

        if a_unknown and b_unknown:
            a_prov = a._provenance.get(i) if a._provenance else None
            b_prov = b._provenance.get(i) if b._provenance else None
            if a_prov is not None and a_prov == b_prov:
                prov[i] = a_prov
        elif a_unknown:
            if a._provenance:
                a_prov = a._provenance.get(i)
                if a_prov is not None:
                    prov[i] = a_prov
        elif b_unknown:
            if b._provenance:
                b_prov = b._provenance.get(i)
                if b_prov is not None:
                    prov[i] = b_prov

    return _normalize_provenance(prov)


class B:
    """A symbolic bitvector where each bit is known-0, known-1, or unknown.

    Internal representation:
        _ones:  bitmask of bits known to be 1
        _zeros: bitmask of bits known to be 0
        _width: bit width of the value
        _provenance: None or dict[int, tuple[str, int]] mapping bit index
                     to (source_name, source_bit_index) for unknown bits

    Invariant: _ones & _zeros == 0 (no bit can be both 0 and 1).
    A bit where neither is set is unknown.
    """

    __slots__ = ('_ones', '_zeros', '_width', '_provenance')

    def __init__(self, value=0, width=None, *, name=None):
        if isinstance(value, B):
            self._ones = value._ones
            self._zeros = value._zeros
            self._width = value._width
            prov = value._provenance
            if width is not None and width != value._width:
                # Re-interpret at new width via zext or truncate
                if width > value._width:
                    result = value.zext(width)
                else:
                    result = value.truncate(width)
                self._ones = result._ones
                self._zeros = result._zeros
                self._width = result._width
                prov = result._provenance
            if name is not None:
                self._provenance = _build_provenance(
                    name, self._ones, self._zeros, self._width)
            else:
                self._provenance = prov
            return

        if isinstance(value, str):
            self._parse_string(value, width)
            if name is not None:
                self._provenance = _build_provenance(
                    name, self._ones, self._zeros, self._width)
            else:
                self._provenance = None
            return

        if isinstance(value, int):
            if value < 0:
                raise ValueError(
                    "Negative integers are ambiguous without a sign convention. "
                    "Use a binary string with explicit bit pattern instead."
                )
            if width is None:
                width = 32
            if width <= 0:
                raise ValueError(f"Width must be positive, got {width}")
            mask = (1 << width) - 1
            if value > mask:
                raise ValueError(
                    f"Value {value:#x} does not fit in {width} bits "
                    f"(max {mask:#x})"
                )
            self._ones = value & mask
            self._zeros = (~value) & mask
            self._width = width
            self._provenance = None
            return

        raise TypeError(
            f"Cannot construct B from {type(value).__name__}. "
            f"Use an int, binary string, or hex string."
        )

    def _parse_string(self, s, width):
        """Parse a binary or hex string into ones/zeros/width."""
        s_stripped = s.replace(' ', '')

        # Hex string
        if s_stripped.startswith('0x') or s_stripped.startswith('0X'):
            self._parse_hex(s_stripped[2:], width)
            return

        # Check if it looks like hex (contains a-f/A-F digits and no 'x'/'?' except as unknown markers)
        # Binary strings only contain 0, 1, x, X, ?
        # If it has hex digits (2-9, a-f) beyond 0/1 and x/?, treat contextually
        is_binary = all(c in '01xX?' for c in s_stripped)

        if is_binary and len(s_stripped) > 0:
            self._parse_binary(s_stripped, width)
            return

        # Try as hex without prefix
        if all(c in '0123456789abcdefABCDEFxX?' for c in s_stripped) and len(s_stripped) > 0:
            self._parse_hex(s_stripped, width)
            return

        raise ValueError(
            f"Cannot parse '{s}' as a bitvector. Use binary (e.g., '0000xxxx') "
            f"or hex (e.g., '0xFFXX00') format."
        )

    def _parse_binary(self, s, width):
        """Parse a binary string like '0000xxxx' or '1xxx0011'."""
        bit_width = len(s)
        if width is None:
            width = bit_width
        elif width < bit_width:
            raise ValueError(
                f"Binary string '{s}' has {bit_width} bits but width={width} "
                f"is too small"
            )

        ones = 0
        zeros = 0
        for ch in s:
            ones <<= 1
            zeros <<= 1
            if ch == '1':
                ones |= 1
            elif ch == '0':
                zeros |= 1
            elif ch in ('x', 'X', '?'):
                pass  # unknown — neither set
            else:
                raise ValueError(f"Invalid character '{ch}' in binary string")

        # If width > bit_width, upper bits are known-zero
        if width > bit_width:
            upper_mask = ((1 << width) - 1) ^ ((1 << bit_width) - 1)
            zeros |= upper_mask

        mask = (1 << width) - 1
        self._ones = ones & mask
        self._zeros = zeros & mask
        self._width = width

    def _parse_hex(self, s, width):
        """Parse a hex string like 'FFXX00' or 'FF??00'."""
        nibble_count = len(s)
        if width is None:
            width = nibble_count * 4
        elif width < nibble_count * 4:
            raise ValueError(
                f"Hex string '{s}' implies {nibble_count * 4} bits but "
                f"width={width} is too small"
            )

        ones = 0
        zeros = 0
        for ch in s:
            ones <<= 4
            zeros <<= 4
            if ch in ('x', 'X', '?'):
                pass  # all 4 bits unknown
            else:
                val = int(ch, 16)
                ones |= val
                zeros |= (~val) & 0xF

        # If width > nibble_count * 4, upper bits are known-zero
        bit_width = nibble_count * 4
        if width > bit_width:
            upper_mask = ((1 << width) - 1) ^ ((1 << bit_width) - 1)
            zeros |= upper_mask

        mask = (1 << width) - 1
        self._ones = ones & mask
        self._zeros = zeros & mask
        self._width = width

    @classmethod
    def _from_raw(cls, ones, zeros, width, provenance=None):
        """Internal constructor with invariant enforcement.

        Checks the invariant BEFORE masking so bugs in operation logic
        are caught rather than silently masked.
        """
        if ones & zeros != 0:
            raise RuntimeError(
                f"Invariant violation: ones & zeros != 0. "
                f"ones={ones:#x}, zeros={zeros:#x}, overlap={ones & zeros:#x}"
            )
        mask = (1 << width) - 1
        obj = object.__new__(cls)
        obj._ones = ones & mask
        obj._zeros = zeros & mask
        obj._width = width
        obj._provenance = _normalize_provenance(provenance)
        return obj

    @classmethod
    def unknown(cls, width=32, *, name=None):
        """Create a value where all bits are unknown."""
        if width <= 0:
            raise ValueError(f"Width must be positive, got {width}")
        prov = None
        if name is not None:
            prov = {i: (name, i) for i in range(width)}
        return cls._from_raw(0, 0, width, provenance=prov)

    # --- Properties ---

    @property
    def width(self):
        """Bit width of this value."""
        return self._width

    @property
    def ones(self):
        """Bitmask of bits known to be 1."""
        return self._ones

    @property
    def zeros(self):
        """Bitmask of bits known to be 0."""
        return self._zeros

    @property
    def _mask(self):
        """Bitmask for this width (all bits set)."""
        return (1 << self._width) - 1

    @property
    def _unknown(self):
        """Bitmask of unknown bits."""
        return self._mask & ~(self._ones | self._zeros)

    # --- Display ---

    def __repr__(self):
        hex_str = self.hex()
        bin_str = self._bin_grouped()
        known = self.known_bits()
        return f"{hex_str}  ({bin_str})  [{known}/{self._width} known]"

    def __str__(self):
        return self.__repr__()

    def bin(self):
        """Return binary string with 'x' for unknowns, no prefix or grouping."""
        chars = []
        for i in range(self._width - 1, -1, -1):
            if self._ones & (1 << i):
                chars.append('1')
            elif self._zeros & (1 << i):
                chars.append('0')
            else:
                chars.append('x')
        return ''.join(chars)

    def hex(self):
        """Return hex string with X for unknown nibbles, ? for mixed."""
        # Pad width to multiple of 4 for display
        nibbles = (self._width + 3) // 4
        chars = []
        for i in range(nibbles - 1, -1, -1):
            shift = i * 4
            nibble_ones = (self._ones >> shift) & 0xF
            nibble_zeros = (self._zeros >> shift) & 0xF
            nibble_unknown = (~(nibble_ones | nibble_zeros)) & 0xF

            if nibble_unknown == 0xF:
                chars.append('X')
            elif nibble_unknown == 0:
                chars.append(f'{nibble_ones:x}')
            else:
                chars.append('?')

        return '0x' + ''.join(chars)

    def _bin_grouped(self):
        """Return binary string grouped in nibbles with spaces.

        When provenance is present, runs of consecutive same-source bits
        are replaced with range notation like src[7:0].
        """
        if self._provenance is None:
            raw = self.bin()
            # Pad to multiple of 4
            pad_len = (4 - len(raw) % 4) % 4
            raw = '0' * pad_len + raw
            groups = [raw[i:i+4] for i in range(0, len(raw), 4)]
            return ' '.join(groups)

        # Provenance-aware display
        segments = []
        i = self._width - 1  # Start at MSB

        while i >= 0:
            if i in self._provenance:
                # Start a provenance range
                name, src_idx = self._provenance[i]
                hi_src = src_idx
                lo_src = src_idx
                j = i - 1
                while j >= 0 and j in self._provenance:
                    next_name, next_src_idx = self._provenance[j]
                    if next_name == name and next_src_idx == lo_src - 1:
                        lo_src = next_src_idx
                        j -= 1
                    else:
                        break
                if hi_src == lo_src:
                    segments.append(f"{name}[{hi_src}]")
                else:
                    segments.append(f"{name}[{hi_src}:{lo_src}]")
                i = j
            else:
                # Literal char — collect consecutive non-provenance bits
                literal_chars = []
                literal_positions = []
                j = i
                while j >= 0 and j not in self._provenance:
                    if self._ones & (1 << j):
                        literal_chars.append('1')
                    elif self._zeros & (1 << j):
                        literal_chars.append('0')
                    else:
                        literal_chars.append('x')
                    literal_positions.append(j)
                    j -= 1

                # Group by nibble boundaries based on absolute bit positions
                grouped = []
                for k, (ch, pos) in enumerate(
                        zip(literal_chars, literal_positions)):
                    grouped.append(ch)
                    if k < len(literal_chars) - 1:
                        next_pos = literal_positions[k + 1]
                        if pos // 4 != next_pos // 4:
                            grouped.append(' ')

                segments.append(''.join(grouped))
                i = j

        return ' '.join(segments)

    # --- Coercion helpers ---

    def _coerce_binary(self, other):
        """Normalize operands for a binary operation.

        Returns (a, b) where both are B instances with the same width.
        The narrower operand is zero-extended.
        """
        if isinstance(other, int):
            if other < 0:
                raise ValueError("Negative integers are ambiguous in symbolic context")
            other = B(other, width=self._width)

        if not isinstance(other, B):
            return NotImplemented

        a, b = self, other
        if a._width != b._width:
            target = max(a._width, b._width)
            if a._width < target:
                a = a.zext(target)
            if b._width < target:
                b = b.zext(target)
        return a, b

    # --- Bitwise operations ---

    def __and__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        # AND truth table:
        # result._ones = a._ones & b._ones (both must be known-1)
        # result._zeros = a._zeros | b._zeros (either known-0 forces 0)
        r_ones = a._ones & b._ones
        r_zeros = a._zeros | b._zeros
        prov = _merge_bitwise_provenance(a, b, r_ones, r_zeros, a._width)
        return B._from_raw(ones=r_ones, zeros=r_zeros, width=a._width,
                           provenance=prov)

    def __rand__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) & self
        return NotImplemented

    def __or__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        # OR truth table:
        # result._ones = a._ones | b._ones (either known-1 forces 1)
        # result._zeros = a._zeros & b._zeros (both must be known-0)
        r_ones = a._ones | b._ones
        r_zeros = a._zeros & b._zeros
        prov = _merge_bitwise_provenance(a, b, r_ones, r_zeros, a._width)
        return B._from_raw(ones=r_ones, zeros=r_zeros, width=a._width,
                           provenance=prov)

    def __ror__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) | self
        return NotImplemented

    def __xor__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        # XOR truth table:
        # result._ones: bits where exactly one is known-1 and the other known-0
        # result._zeros: bits where both known-same (both 1 or both 0)
        # Any unknown input -> unknown output
        r_ones = (a._ones & b._zeros) | (a._zeros & b._ones)
        r_zeros = (a._ones & b._ones) | (a._zeros & b._zeros)
        prov = _merge_bitwise_provenance(a, b, r_ones, r_zeros, a._width)
        return B._from_raw(ones=r_ones, zeros=r_zeros, width=a._width,
                           provenance=prov)

    def __rxor__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) ^ self
        return NotImplemented

    def __invert__(self):
        # NOT: swap ones and zeros, unknowns stay unknown
        return B._from_raw(
            ones=self._zeros,
            zeros=self._ones,
            width=self._width,
            provenance=self._provenance,
        )

    # --- Shifts ---

    def __lshift__(self, n):
        if isinstance(n, B):
            raise TypeError(
                "Cannot shift by symbolic amount — shift count must be a "
                "concrete integer"
            )
        if not isinstance(n, int):
            return NotImplemented
        if n < 0:
            raise ValueError(f"Shift amount must be non-negative, got {n}")
        if n >= self._width:
            # All bits shifted out — result is all known-zero
            return B(0, width=self._width)
        mask = self._mask
        prov = None
        if self._provenance is not None:
            prov = {}
            for bit_idx, entry in self._provenance.items():
                new_idx = bit_idx + n
                if new_idx < self._width:
                    prov[new_idx] = entry
            prov = _normalize_provenance(prov)
        return B._from_raw(
            ones=(self._ones << n) & mask,
            zeros=((self._zeros << n) | ((1 << n) - 1)) & mask,
            width=self._width,
            provenance=prov,
        )

    def __rshift__(self, n):
        """Logical right shift — top bits become known-0."""
        if isinstance(n, B):
            raise TypeError(
                "Cannot shift by symbolic amount — shift count must be a "
                "concrete integer"
            )
        if not isinstance(n, int):
            return NotImplemented
        if n < 0:
            raise ValueError(f"Shift amount must be non-negative, got {n}")
        if n >= self._width:
            return B(0, width=self._width)
        # Top n bits become known-zero
        top_mask = (((1 << n) - 1) << (self._width - n))
        prov = None
        if self._provenance is not None:
            prov = {}
            for bit_idx, entry in self._provenance.items():
                new_idx = bit_idx - n
                if new_idx >= 0:
                    prov[new_idx] = entry
            prov = _normalize_provenance(prov)
        return B._from_raw(
            ones=self._ones >> n,
            zeros=(self._zeros >> n) | top_mask,
            width=self._width,
            provenance=prov,
        )

    def ashr(self, n):
        """Arithmetic right shift — sign bit fills from top."""
        if isinstance(n, B):
            raise TypeError(
                "Cannot shift by symbolic amount — shift count must be a "
                "concrete integer"
            )
        if not isinstance(n, int):
            raise TypeError(f"Shift amount must be an integer, got {type(n).__name__}")
        if n < 0:
            raise ValueError(f"Shift amount must be non-negative, got {n}")

        sign_bit = self._width - 1

        if n >= self._width:
            # All bits become copies of sign bit
            sign_one = bool(self._ones & (1 << sign_bit))
            sign_zero = bool(self._zeros & (1 << sign_bit))
            if sign_one:
                return B._from_raw(ones=self._mask, zeros=0, width=self._width)
            elif sign_zero:
                return B(0, width=self._width)
            else:
                # Sign unknown — all bits become unknown copies of sign
                prov = None
                if self._provenance is not None:
                    sign_prov = self._provenance.get(sign_bit)
                    if sign_prov is not None:
                        prov = {i: sign_prov for i in range(self._width)}
                return B._from_raw(0, 0, self._width,
                                   provenance=_normalize_provenance(prov))

        # Shift data bits
        ones = self._ones >> n
        zeros = self._zeros >> n

        # Shift provenance entries
        prov = None
        if self._provenance is not None:
            prov = {}
            for bit_idx, entry in self._provenance.items():
                new_idx = bit_idx - n
                if new_idx >= 0:
                    prov[new_idx] = entry

        # Fill top n bits based on sign bit state
        top_mask = (((1 << n) - 1) << (self._width - n))
        sign_one = bool(self._ones & (1 << sign_bit))
        sign_zero = bool(self._zeros & (1 << sign_bit))

        if sign_one:
            ones |= top_mask
        elif sign_zero:
            zeros |= top_mask
        else:
            # Sign unknown — fill bits get sign bit's provenance
            if self._provenance is not None:
                sign_prov = self._provenance.get(sign_bit)
                if sign_prov is not None:
                    if prov is None:
                        prov = {}
                    for i in range(self._width - n, self._width):
                        prov[i] = sign_prov

        return B._from_raw(ones=ones, zeros=zeros, width=self._width,
                           provenance=_normalize_provenance(prov))

    # --- Arithmetic ---

    def __add__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        return _three_valued_add(a, b, 0)

    def __radd__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) + self
        return NotImplemented

    def __sub__(self, other):
        result = self._coerce_binary(other)
        if result is NotImplemented:
            return NotImplemented
        a, b = result
        inv_b = ~b
        return _three_valued_add(a, inv_b, 1)

    def __rsub__(self, other):
        if isinstance(other, int):
            return B(other, width=self._width) - self
        return NotImplemented

    def __neg__(self):
        return _three_valued_add(~self, B(0, self._width), 1)

    # --- Width manipulation ---

    def zext(self, new_width):
        """Zero-extend to new_width. Upper bits become known-0."""
        if new_width < self._width:
            raise ValueError(
                f"Cannot zero-extend from {self._width} to {new_width} bits — "
                f"use truncate() to narrow"
            )
        if new_width == self._width:
            return B._from_raw(self._ones, self._zeros, self._width,
                               provenance=self._provenance)
        upper_mask = ((1 << new_width) - 1) ^ ((1 << self._width) - 1)
        return B._from_raw(
            ones=self._ones,
            zeros=self._zeros | upper_mask,
            width=new_width,
            provenance=self._provenance,
        )

    def sext(self, new_width):
        """Sign-extend to new_width. Upper bits copy the sign bit."""
        if new_width < self._width:
            raise ValueError(
                f"Cannot sign-extend from {self._width} to {new_width} bits — "
                f"use truncate() to narrow"
            )
        if new_width == self._width:
            return B._from_raw(self._ones, self._zeros, self._width,
                               provenance=self._provenance)

        sign_bit = self._width - 1
        sign_one = bool(self._ones & (1 << sign_bit))
        sign_zero = bool(self._zeros & (1 << sign_bit))
        upper_mask = ((1 << new_width) - 1) ^ ((1 << self._width) - 1)

        ones = self._ones
        zeros = self._zeros
        if sign_one:
            ones |= upper_mask
        elif sign_zero:
            zeros |= upper_mask
        # else: sign unknown, upper bits stay unknown

        prov = None
        if self._provenance is not None:
            prov = dict(self._provenance)
            if not sign_one and not sign_zero:
                sign_prov = self._provenance.get(sign_bit)
                if sign_prov is not None:
                    for i in range(self._width, new_width):
                        prov[i] = sign_prov

        return B._from_raw(ones=ones, zeros=zeros, width=new_width,
                           provenance=_normalize_provenance(prov))

    def truncate(self, new_width):
        """Truncate to new_width, keeping only the low bits."""
        if new_width > self._width:
            raise ValueError(
                f"Cannot truncate from {self._width} to {new_width} bits — "
                f"use zext() or sext() to widen"
            )
        if new_width <= 0:
            raise ValueError(f"Width must be positive, got {new_width}")
        mask = (1 << new_width) - 1
        prov = None
        if self._provenance is not None:
            prov = {k: v for k, v in self._provenance.items()
                    if k < new_width}
            prov = _normalize_provenance(prov)
        return B._from_raw(
            ones=self._ones & mask,
            zeros=self._zeros & mask,
            width=new_width,
            provenance=prov,
        )

    # --- Bit extraction and inspection ---

    def bit(self, n):
        """Return '0', '1', or 'x' for bit n (0-indexed from LSB)."""
        if n < 0:
            raise ValueError(f"Bit index must be non-negative, got {n}")
        if n >= self._width:
            return '0'  # Out of range bits are implicitly 0
        if self._ones & (1 << n):
            return '1'
        if self._zeros & (1 << n):
            return '0'
        return 'x'

    def bits(self, hi, lo):
        """Extract bits hi:lo (inclusive) as a new B value."""
        if hi < lo:
            raise ValueError(f"hi ({hi}) must be >= lo ({lo})")
        if lo < 0:
            raise ValueError(f"Bit indices must be non-negative")
        new_width = hi - lo + 1
        ones = (self._ones >> lo) & ((1 << new_width) - 1)
        zeros = (self._zeros >> lo) & ((1 << new_width) - 1)
        prov = None
        if self._provenance is not None:
            prov = {}
            for bit_idx in range(lo, hi + 1):
                if bit_idx in self._provenance:
                    prov[bit_idx - lo] = self._provenance[bit_idx]
            prov = _normalize_provenance(prov)
        return B._from_raw(ones=ones, zeros=zeros, width=new_width,
                           provenance=prov)

    def __getitem__(self, key):
        """Slice syntax: a[7:0] extracts bits 7 down to 0 (MSB:LSB convention)."""
        if isinstance(key, int):
            # Single bit extraction — return a B of width 1
            return self.bits(key, key)
        if isinstance(key, slice):
            hi = key.start
            lo = key.stop
            if key.step is not None:
                raise ValueError("Step not supported in bit slice")
            if hi is None:
                hi = self._width - 1
            if lo is None:
                lo = 0
            return self.bits(hi, lo)
        raise TypeError(f"Invalid index type: {type(key).__name__}")

    def known_bits(self):
        """Count of bits that are known (either 0 or 1)."""
        return _popcount(self._ones | self._zeros)

    def unknown_bits(self):
        """Count of bits that are unknown."""
        return self._width - self.known_bits()

    def is_fully_known(self):
        """True if all bits are known."""
        return (self._ones | self._zeros) == self._mask

    def is_fully_unknown(self):
        """True if no bits are known."""
        return (self._ones | self._zeros) == 0

    def as_int(self):
        """Return the integer value if fully known, raise if any unknowns."""
        if not self.is_fully_known():
            raise ValueError(
                f"Cannot convert to int: {self.unknown_bits()} bits are unknown. "
                f"Value: {self}"
            )
        return self._ones

    def could_equal(self, val):
        """True if the known bits are compatible with val."""
        if isinstance(val, B):
            if not val.is_fully_known():
                raise ValueError("could_equal argument must be a concrete value")
            val = val._ones
        if not isinstance(val, int):
            raise TypeError(f"could_equal expects an int, got {type(val).__name__}")
        val = val & self._mask
        # Check: all known-1 bits must be 1 in val
        if (val & self._ones) != self._ones:
            return False
        # Check: all known-0 bits must be 0 in val
        if (val & self._zeros) != 0:
            return False
        return True

    def known_ones_mask(self):
        """Bitmask of bits known to be 1."""
        return self._ones

    def known_zeros_mask(self):
        """Bitmask of bits known to be 0."""
        return self._zeros

    def unknown_mask(self):
        """Bitmask of unknown bits."""
        return self._unknown

    # --- Concatenation ---

    def concat(self, *others):
        """Concatenate bitvectors: self is high bits, args are lower bits in order.

        Can also be called as a classmethod: B.concat(hi, lo)
        """
        if not others:
            # Called as B.concat(hi, lo, ...) — self is the class
            raise TypeError("concat requires at least two values")

        parts = [self] + list(others)
        # Build from low to high
        result_ones = 0
        result_zeros = 0
        result_prov = {}
        total_width = 0
        for part in reversed(parts):
            if isinstance(part, int):
                part = B(part)
            if not isinstance(part, B):
                raise TypeError(f"concat expects B values, got {type(part).__name__}")
            result_ones |= part._ones << total_width
            result_zeros |= part._zeros << total_width
            if part._provenance is not None:
                for bit_idx, entry in part._provenance.items():
                    result_prov[bit_idx + total_width] = entry
            total_width += part._width

        return B._from_raw(result_ones, result_zeros, total_width,
                           provenance=_normalize_provenance(result_prov))

    # --- Comparison ---

    def __eq__(self, other):
        """Structural equality: same width, same known bits, same unknowns."""
        if isinstance(other, int):
            other = B(other, width=self._width)
        if not isinstance(other, B):
            return NotImplemented
        if self._width != other._width:
            return False
        return self._ones == other._ones and self._zeros == other._zeros

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return NotImplemented
        return not result

    def __hash__(self):
        return hash((self._ones, self._zeros, self._width))

    def __bool__(self):
        raise TypeError(
            "Symbolic bitvectors cannot be used as booleans. "
            "A symbolic value may represent multiple concrete values, "
            "so truth/falsity is not well-defined. "
            "Use .is_fully_known(), .could_equal(), or .as_int() instead."
        )

    def is_refinement_of(self, other):
        """True if self knows everything other knows, plus possibly more.

        self is a refinement of other if:
        - Every bit that other knows as 1, self also knows as 1
        - Every bit that other knows as 0, self also knows as 0
        - self may know additional bits that other doesn't
        """
        if isinstance(other, int):
            other = B(other, width=self._width)
        if not isinstance(other, B):
            raise TypeError(f"Expected B, got {type(other).__name__}")
        if self._width != other._width:
            raise ValueError(
                f"Width mismatch: {self._width} vs {other._width}"
            )
        # All of other's known-1 bits must be known-1 in self
        if (other._ones & self._ones) != other._ones:
            return False
        # All of other's known-0 bits must be known-0 in self
        if (other._zeros & self._zeros) != other._zeros:
            return False
        return True


def _popcount(n):
    """Count the number of set bits in a non-negative integer."""
    count = 0
    while n:
        count += 1
        n &= n - 1
    return count


def _three_valued_add(a, b, carry_in_bit):
    """Three-valued ripple-carry addition.

    Iterates bit-by-bit from LSB to MSB. At each position a three-valued
    full adder computes sum and carry-out:
      sum = a XOR b XOR cin  (three-valued XOR chain)
      carry_out = majority(a, b, cin)

    carry_in_bit is a plain int (0 or 1).
    Carry-out from MSB is discarded (modular arithmetic).
    """
    width = a._width
    mask = (1 << width) - 1

    result_ones = 0
    result_zeros = 0

    # Carry state: (carry_one, carry_zero)
    # carry_one set  -> carry is known-1
    # carry_zero set -> carry is known-0
    # neither set    -> carry is unknown
    if carry_in_bit:
        carry_one = 1
        carry_zero = 0
    else:
        carry_one = 0
        carry_zero = 1

    for i in range(width):
        bit = 1 << i
        # Extract a, b bit state
        a1 = 1 if (a._ones & bit) else 0
        a0 = 1 if (a._zeros & bit) else 0
        b1 = 1 if (b._ones & bit) else 0
        b0 = 1 if (b._zeros & bit) else 0
        c1 = carry_one
        c0 = carry_zero

        # Three-valued XOR for sum: a XOR b XOR cin
        # First: t = a XOR b
        t1 = (a1 and b0) or (a0 and b1)
        t0 = (a1 and b1) or (a0 and b0)
        # Then: sum = t XOR cin
        s1 = (t1 and c0) or (t0 and c1)
        s0 = (t1 and c1) or (t0 and c0)

        if s1:
            result_ones |= bit
        elif s0:
            result_zeros |= bit
        # else: unknown, neither set

        # Carry-out = majority(a, b, cin)
        # known-1 if at least 2 of 3 are known-1
        # known-0 if at least 2 of 3 are known-0
        # else unknown
        ones_count = a1 + b1 + c1
        zeros_count = a0 + b0 + c0
        if ones_count >= 2:
            carry_one = 1
            carry_zero = 0
        elif zeros_count >= 2:
            carry_one = 0
            carry_zero = 1
        else:
            carry_one = 0
            carry_zero = 0

    return B._from_raw(result_ones & mask, result_zeros & mask, width)


def B8(value=0, *, name=None):
    """Create an 8-bit symbolic bitvector."""
    return B(value, width=8, name=name)


def B16(value=0, *, name=None):
    """Create a 16-bit symbolic bitvector."""
    return B(value, width=16, name=name)


def B32(value=0, *, name=None):
    """Create a 32-bit symbolic bitvector."""
    return B(value, width=32, name=name)


def B64(value=0, *, name=None):
    """Create a 64-bit symbolic bitvector."""
    return B(value, width=64, name=name)
