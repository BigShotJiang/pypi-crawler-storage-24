"""Tests for addition operation."""

import random
import pytest
from symbits import B, B8, B16, B32
from conftest import random_symbolic, concrete_values_for


class TestAddTruthTable:
    """Concrete basics."""

    def test_0_plus_0(self):
        assert (B8(0) + B8(0)) == B8(0)

    def test_0_plus_1(self):
        assert (B8(0) + B8(1)) == B8(1)

    def test_1_plus_1(self):
        assert (B8(1) + B8(1)) == B8(2)

    def test_known_plus_known(self):
        assert (B8(0x12) + B8(0x34)) == B8(0x46)

    def test_known_plus_known_large(self):
        assert (B8(100) + B8(55)) == B8(155)


class TestAddCarryPropagation:
    """Carry chain behavior."""

    def test_carry_through_known_ones(self):
        # 0x0F + 0x01 = 0x10 — carry ripples through four 1-bits
        assert (B8(0x0F) + B8(0x01)) == B8(0x10)

    def test_carry_killed_by_zero(self):
        # 0x01 + 0x01 = 0x02 — no long carry chain
        assert (B8(0x01) + B8(0x01)) == B8(0x02)

    def test_carry_into_unknown(self):
        # known bit 0 = 1, bits 1..3 unknown, adding 1
        # bit 0: 1+1 = 0, carry=1; bit 1: x+0+carry=x, carry=x; rest: unknown
        a = B8("xxxx xxx1")
        b = B8(1)
        r = a + b
        # bit 0 becomes 0 (known), bit 1 onward: unknown since carry is unknown
        assert r.bit(0) == '0'

    def test_carry_from_known_into_unknown(self):
        # Lower nibble all 1s, upper nibble unknown, add 1
        # Carry propagates through four 1s into the unknown region
        a = B8("xxxx1111")
        b = B8(1)
        r = a + b
        # Lower 4 bits: 1111+1 = 10000, so bits 0-3 = 0000
        assert r.bit(0) == '0'
        assert r.bit(1) == '0'
        assert r.bit(2) == '0'
        assert r.bit(3) == '0'
        # Bit 4: unknown + carry_in=1 -> unknown
        assert r.bit(4) == 'x'


class TestAddProperties:
    """Algebraic properties."""

    def test_commutativity(self):
        a = B8(0x12)
        b = B8(0x34)
        assert a + b == b + a

    def test_commutativity_symbolic(self):
        a = B8("1100xxxx")
        b = B8("1010xx00")
        assert a + b == b + a

    def test_identity(self):
        a = B8(0xAB)
        assert a + B8(0) == a

    def test_identity_preserves_unknowns(self):
        a = B8("1100xxxx")
        r = a + B8(0)
        assert r == a

    def test_reverse_operator(self):
        a = B8(3)
        r = 5 + a
        assert r == B8(8)

    def test_reverse_operator_symbolic(self):
        r = 5 + B8("0000xxxx")
        assert r.could_equal(5 + 0)
        assert r.could_equal(5 + 15)


class TestAddWraparound:
    """Modular overflow behavior."""

    def test_ff_plus_1(self):
        assert (B8(0xFF) + B8(1)) == B8(0x00)

    def test_80_plus_80(self):
        assert (B8(0x80) + B8(0x80)) == B8(0x00)

    def test_ff_plus_ff(self):
        assert (B8(0xFF) + B8(0xFF)) == B8(0xFE)


class TestAddWidthMismatch:
    """Auto-promotion via zero-extend for mixed widths."""

    def test_8_plus_16(self):
        a = B8(0xFF)
        b = B16(0x0001)
        r = a + b
        assert r.width == 16
        assert r == B16(0x0100)

    def test_8_plus_32(self):
        a = B8(0xFF)
        b = B32(0x00000001)
        r = a + b
        assert r.width == 32
        assert r == B32(0x00000100)


class TestAddFuzz:
    def test_concrete_fuzz(self):
        """1000 random concrete 8-bit pairs."""
        rng = random.Random(42)
        for _ in range(1000):
            a = rng.randint(0, 0xFF)
            b = rng.randint(0, 0xFF)
            result = B8(a) + B8(b)
            expected = (a + b) & 0xFF
            assert result.as_int() == expected

    def test_symbolic_fuzz(self):
        """100 random symbolic pairs — all concrete expansions must be compatible."""
        rng = random.Random(123)
        for _ in range(100):
            sa = random_symbolic(8, rng)
            sb = random_symbolic(8, rng)
            result = sa + sb
            for va in concrete_values_for(sa, 16):
                for vb in concrete_values_for(sb, 16):
                    assert result.could_equal((va + vb) & 0xFF), (
                        f"{sa} + {sb} = {result}, but doesn't match "
                        f"{va:#x} + {vb:#x} = {(va + vb) & 0xFF:#x}"
                    )
