"""Tests for subtraction and negation operations."""

import random
import pytest
from symbits import B, B8, B16, B32
from conftest import random_symbolic, concrete_values_for


class TestSubBasic:
    """Concrete subtraction basics."""

    def test_5_minus_3(self):
        assert (B8(5) - B8(3)) == B8(2)

    def test_0_minus_1_wraps(self):
        assert (B8(0) - B8(1)) == B8(0xFF)

    def test_known_minus_known(self):
        assert (B8(0x80) - B8(0x40)) == B8(0x40)

    def test_equal_values(self):
        assert (B8(42) - B8(42)) == B8(0)


class TestSubBorrowPropagation:
    """Borrow chain behavior."""

    def test_borrow_through_zeros(self):
        # 0x10 - 0x01 = 0x0F — borrow ripples through four 0-bits
        assert (B8(0x10) - B8(0x01)) == B8(0x0F)

    def test_borrow_into_unknowns(self):
        # Lower nibble all 0s, upper nibble unknown, subtract 1
        a = B8("xxxx0000")
        b = B8(1)
        r = a - b
        # Lower 4 bits: 0000 - 1 borrows => 1111
        assert r.bit(0) == '1'
        assert r.bit(1) == '1'
        assert r.bit(2) == '1'
        assert r.bit(3) == '1'
        # Upper nibble: unknown - borrow -> unknown
        assert r.bit(4) == 'x'


class TestSubProperties:
    """Algebraic properties."""

    def test_sub_zero_identity(self):
        a = B8(0xAB)
        assert a - B8(0) == a

    def test_sub_self_is_zero(self):
        a = B8(0xAB)
        assert a - a == B8(0)

    def test_sub_equals_add_neg(self):
        a = B8(100)
        b = B8(37)
        assert a - b == a + (-b)

    def test_reverse_operator(self):
        a = B8(3)
        r = 5 - a
        assert r == B8(2)

    def test_reverse_operator_symbolic(self):
        r = 10 - B8("0000xxxx")
        assert r.could_equal((10 - 0) & 0xFF)
        assert r.could_equal((10 - 15) & 0xFF)


class TestSubWraparound:
    """Underflow wrapping."""

    def test_00_minus_01(self):
        assert (B8(0x00) - B8(0x01)) == B8(0xFF)

    def test_00_minus_ff(self):
        assert (B8(0x00) - B8(0xFF)) == B8(0x01)


class TestSubFuzz:
    def test_concrete_fuzz(self):
        """1000 random concrete 8-bit pairs."""
        rng = random.Random(42)
        for _ in range(1000):
            a = rng.randint(0, 0xFF)
            b = rng.randint(0, 0xFF)
            result = B8(a) - B8(b)
            expected = (a - b) & 0xFF
            assert result.as_int() == expected

    def test_symbolic_fuzz(self):
        """100 random symbolic pairs — all concrete expansions must be compatible."""
        rng = random.Random(456)
        for _ in range(100):
            sa = random_symbolic(8, rng)
            sb = random_symbolic(8, rng)
            result = sa - sb
            for va in concrete_values_for(sa, 16):
                for vb in concrete_values_for(sb, 16):
                    assert result.could_equal((va - vb) & 0xFF), (
                        f"{sa} - {sb} = {result}, but doesn't match "
                        f"{va:#x} - {vb:#x} = {(va - vb) & 0xFF:#x}"
                    )


class TestNeg:
    """Unary negation."""

    def test_neg_zero(self):
        assert -B8(0) == B8(0)

    def test_neg_one(self):
        assert -B8(1) == B8(0xFF)

    def test_neg_ff(self):
        assert -B8(0xFF) == B8(1)

    def test_neg_with_unknowns(self):
        a = B8("xxxx0000")
        r = -a
        # Can't say much about specific bits, but invariant holds
        assert r._ones & r._zeros == 0

    def test_neg_neg_concrete(self):
        a = B8(42)
        assert -(-a) == a

    def test_concrete_fuzz_all_256(self):
        """Negation of every 8-bit value."""
        for v in range(256):
            result = -B8(v)
            expected = (-v) & 0xFF
            assert result.as_int() == expected
