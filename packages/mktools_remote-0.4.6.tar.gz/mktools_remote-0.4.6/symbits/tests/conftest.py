"""Shared fixtures and helpers for symbits tests."""

import random
import pytest
from symbits import B


def random_symbolic(width=32, rng=None):
    """Generate a random symbolic B value with a mix of known and unknown bits."""
    if rng is None:
        rng = random.Random()
    mask = (1 << width) - 1
    # Random pattern: for each bit, choose known-0, known-1, or unknown
    ones = 0
    zeros = 0
    for i in range(width):
        choice = rng.randint(0, 2)
        if choice == 0:
            zeros |= (1 << i)
        elif choice == 1:
            ones |= (1 << i)
        # else: unknown
    return B._from_raw(ones & mask, zeros & mask, width)


def concrete_values_for(sym, max_count=64):
    """Enumerate concrete values compatible with a symbolic value.

    If there are too many (> max_count), sample randomly.
    """
    unknown_bits = []
    for i in range(sym.width):
        if not (sym._ones & (1 << i)) and not (sym._zeros & (1 << i)):
            unknown_bits.append(i)

    if len(unknown_bits) <= 6:  # At most 64 combinations
        # Enumerate all
        values = []
        for combo in range(1 << len(unknown_bits)):
            val = sym._ones
            for j, bit_pos in enumerate(unknown_bits):
                if combo & (1 << j):
                    val |= (1 << bit_pos)
            values.append(val)
        return values
    else:
        # Sample randomly
        values = set()
        rng = random.Random(42)
        while len(values) < max_count:
            val = sym._ones
            for bit_pos in unknown_bits:
                if rng.randint(0, 1):
                    val |= (1 << bit_pos)
            values.add(val)
        return list(values)
