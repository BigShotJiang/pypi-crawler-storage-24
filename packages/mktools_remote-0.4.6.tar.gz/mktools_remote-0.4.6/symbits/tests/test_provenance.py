"""Tests for bit provenance tracking."""

import pytest
from symbits import B, B8, B16, B32, B64


class TestProvenanceConstruction:
    def test_int_no_provenance(self):
        assert B8(0xFF)._provenance is None

    def test_string_no_name(self):
        assert B8("xxxx0000")._provenance is None

    def test_string_with_name(self):
        v = B8("xxxx0000", name="src")
        assert v._provenance is not None
        for i in range(4, 8):
            assert v._provenance[i] == ("src", i)
        for i in range(4):
            assert i not in v._provenance

    def test_all_unknown_with_name(self):
        v = B8("xxxxxxxx", name="v0")
        assert v._provenance is not None
        for i in range(8):
            assert v._provenance[i] == ("v0", i)

    def test_all_known_with_name(self):
        assert B8("11110000", name="v0")._provenance is None

    def test_unknown_classmethod_with_name(self):
        v = B.unknown(8, name="reg")
        assert v._provenance is not None
        for i in range(8):
            assert v._provenance[i] == ("reg", i)

    def test_unknown_classmethod_no_name(self):
        assert B.unknown(8)._provenance is None

    def test_int_with_name_ignored(self):
        assert B(0xFF, width=8, name="x")._provenance is None

    def test_hex_string_with_name(self):
        v = B("0xFFXX", name="src")
        assert v._provenance is not None
        for i in range(8):
            assert v._provenance[i] == ("src", i)
        for i in range(8, 16):
            assert i not in v._provenance

    def test_copy_preserves_provenance(self):
        a = B8("xxxx0000", name="src")
        b = B(a)
        assert b._provenance is not None
        assert b._provenance == a._provenance

    def test_copy_with_name_overrides(self):
        a = B8("xxxx0000", name="src")
        b = B(a, name="dst")
        assert b._provenance is not None
        for i in range(4, 8):
            assert b._provenance[i] == ("dst", i)

    def test_b8_with_name(self):
        v = B8("xxxxxxxx", name="v0")
        assert v._provenance is not None
        assert len(v._provenance) == 8

    def test_b16_with_name(self):
        v = B16("0xXXXX", name="v0")
        assert v._provenance is not None
        assert len(v._provenance) == 16

    def test_b32_with_name(self):
        v = B32("0xXXXXXXXX", name="v0")
        assert v._provenance is not None
        assert len(v._provenance) == 32

    def test_b64_with_name(self):
        v = B64("0x" + "X" * 16, name="v0")
        assert v._provenance is not None
        assert len(v._provenance) == 64


class TestProvenanceEquality:
    def test_eq_ignores_provenance(self):
        a = B8("xxxxxxxx", name="a")
        b = B8("xxxxxxxx", name="b")
        assert a == b

    def test_eq_named_vs_unnamed(self):
        a = B8("xxxx0000", name="src")
        b = B8("xxxx0000")
        assert a == b

    def test_hash_ignores_provenance(self):
        a = B8("xxxx0000", name="a")
        b = B8("xxxx0000", name="b")
        assert hash(a) == hash(b)

    def test_set_deduplication(self):
        a = B8("xxxx0000", name="src")
        b = B8("xxxx0000")
        assert len({a, b}) == 1


class TestAndProvenance:
    def test_named_and_ones_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = src & 0xFF
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_named_and_zeros_destroys(self):
        src = B8("xxxxxxxx", name="src")
        result = src & 0x00
        assert result._provenance is None

    def test_named_and_partial_mask(self):
        src = B8("xxxxxxxx", name="src")
        result = src & 0x0F
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("src", i)
        for i in range(4, 8):
            assert i not in result._provenance

    def test_two_different_names_drops(self):
        a = B8("xxxxxxxx", name="a")
        b = B8("xxxxxxxx", name="b")
        result = a & b
        assert result._provenance is None

    def test_same_provenance_keeps(self):
        a = B8("xxxxxxxx", name="src")
        b = B(a)
        result = a & b
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_named_and_unnamed_drops(self):
        a = B8("xxxxxxxx", name="src")
        b = B8("xxxxxxxx")
        result = a & b
        assert result._provenance is None

    def test_no_provenance_fast_path(self):
        a = B8("xxxxxxxx")
        b = B8("xxxxxxxx")
        result = a & b
        assert result._provenance is None


class TestOrProvenance:
    def test_named_or_zeros_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = src | 0x00
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_named_or_ones_destroys(self):
        src = B8("xxxxxxxx", name="src")
        result = src | 0xFF
        assert result._provenance is None

    def test_named_or_partial_mask(self):
        src = B8("xxxxxxxx", name="src")
        result = src | 0xF0
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("src", i)
        for i in range(4, 8):
            assert i not in result._provenance


class TestXorProvenance:
    def test_named_xor_zero_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = src ^ 0x00
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_named_xor_ones_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = src ^ 0xFF
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_two_named_drops(self):
        a = B8("xxxxxxxx", name="a")
        b = B8("xxxxxxxx", name="b")
        result = a ^ b
        assert result._provenance is None

    def test_named_xor_partial(self):
        src = B8("xxxx0000", name="src")
        result = src ^ B8("11110000")
        # Upper 4 unknown bits stay unknown (xor with known), keep provenance
        # Lower 4 known bits → known result, no provenance
        assert result._provenance is not None
        for i in range(4, 8):
            assert result._provenance[i] == ("src", i)


class TestNotProvenance:
    def test_not_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = ~src
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_not_partial(self):
        src = B8("xxxx0000", name="src")
        result = ~src
        assert result._provenance is not None
        for i in range(4, 8):
            assert result._provenance[i] == ("src", i)
        for i in range(4):
            assert i not in result._provenance

    def test_double_not_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = ~~src
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)


class TestShiftProvenance:
    def test_lshift_moves(self):
        src = B8("xxxxxxxx", name="src")
        result = src << 3
        assert result._provenance is not None
        # Bottom 3 bits are known-0 (no provenance)
        for i in range(3):
            assert i not in result._provenance
        # Bits 3-7 have shifted provenance
        for i in range(3, 8):
            assert result._provenance[i] == ("src", i - 3)

    def test_rshift_moves(self):
        src = B8("xxxxxxxx", name="src")
        result = src >> 3
        assert result._provenance is not None
        # Top 3 bits are known-0 (no provenance)
        for i in range(5, 8):
            assert i not in result._provenance
        # Bits 0-4 have shifted provenance
        for i in range(5):
            assert result._provenance[i] == ("src", i + 3)

    def test_lshift_full_width_clears(self):
        src = B8("xxxxxxxx", name="src")
        result = src << 8
        assert result._provenance is None

    def test_rshift_full_width_clears(self):
        src = B8("xxxxxxxx", name="src")
        result = src >> 8
        assert result._provenance is None

    def test_shift_zero_preserves(self):
        src = B8("xxxxxxxx", name="src")
        result = src << 0
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)

    def test_ashr_known_sign(self):
        # Known sign bit 1 → fill bits are known-1, no provenance
        v = B8("1xxxxxxx", name="src")
        result = v.ashr(3)
        # Top 3 bits are known-1 (no provenance)
        for i in range(5, 8):
            assert i not in (result._provenance or {})

    def test_ashr_unknown_sign(self):
        src = B8("xxxxxxxx", name="src")
        result = src.ashr(3)
        assert result._provenance is not None
        # Bits 0-4 are shifted data with provenance
        for i in range(5):
            assert result._provenance[i] == ("src", i + 3)
        # Bits 5-7 are fill bits with sign bit's provenance
        for i in range(5, 8):
            assert result._provenance[i] == ("src", 7)

    def test_ashr_beyond_width_unknown_sign(self):
        src = B8("xxxxxxxx", name="src")
        result = src.ashr(10)
        assert result._provenance is not None
        # All bits are copies of sign bit
        for i in range(8):
            assert result._provenance[i] == ("src", 7)

    def test_shift_partial_provenance(self):
        src = B8("xxxx0000", name="src")
        result = src << 2
        assert result._provenance is not None
        # Bits 0-1: known-0 (from shift fill)
        # Bits 2-5: known-0 (from original lower nibble, shifted)
        # Bits 6-7: provenance from src[4] and src[5]
        assert result._provenance[6] == ("src", 4)
        assert result._provenance[7] == ("src", 5)
        assert 0 not in result._provenance
        assert 1 not in result._provenance


class TestWidthProvenance:
    def test_zext_preserves_lower(self):
        src = B8("xxxxxxxx", name="src")
        result = src.zext(16)
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)
        # Upper 8 bits are known-0, no provenance
        for i in range(8, 16):
            assert i not in result._provenance

    def test_sext_known_sign(self):
        v = B8("1xxxxxxx", name="src")
        result = v.sext(16)
        # Sign bit known-1 → upper bits known-1, no provenance
        assert result._provenance is not None
        for i in range(7):
            assert result._provenance[i] == ("src", i)
        for i in range(8, 16):
            assert i not in (result._provenance or {})

    def test_sext_unknown_sign(self):
        src = B8("xxxxxxxx", name="src")
        result = src.sext(16)
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)
        # Upper bits get sign bit's provenance
        for i in range(8, 16):
            assert result._provenance[i] == ("src", 7)

    def test_truncate_keeps_lower(self):
        src = B8("xxxxxxxx", name="src")
        result = src.truncate(4)
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("src", i)
        assert len(result._provenance) == 4

    def test_concat_two_named(self):
        hi = B8("xxxxxxxx", name="hi")
        lo = B8("xxxxxxxx", name="lo")
        result = hi.concat(lo)
        assert result._provenance is not None
        # Low 8 bits from lo
        for i in range(8):
            assert result._provenance[i] == ("lo", i)
        # High 8 bits from hi
        for i in range(8, 16):
            assert result._provenance[i] == ("hi", i - 8)

    def test_concat_mixed(self):
        hi = B8(0xFF)  # known, no provenance
        lo = B8("xxxxxxxx", name="lo")
        result = hi.concat(lo)
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("lo", i)
        for i in range(8, 16):
            assert i not in result._provenance

    def test_bits_extraction(self):
        src = B8("xxxxxxxx", name="src")
        result = src.bits(7, 4)
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("src", i + 4)

    def test_slice_extraction(self):
        src = B8("xxxxxxxx", name="src")
        result = src[3:0]
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("src", i)

    def test_coerce_zext_preserves(self):
        narrow = B8("xxxxxxxx", name="src")
        wide = B16(0xFFFF)
        result = narrow & wide  # narrow gets auto-promoted via zext
        assert result._provenance is not None
        for i in range(8):
            assert result._provenance[i] == ("src", i)


class TestArithmeticDestroysProvenance:
    def test_add_named_plus_known(self):
        src = B8("xxxxxxxx", name="src")
        result = src + B8(1)
        assert result._provenance is None

    def test_add_two_named(self):
        a = B8("xxxxxxxx", name="a")
        b = B8("xxxxxxxx", name="b")
        result = a + b
        assert result._provenance is None

    def test_sub_destroys(self):
        src = B8("xxxxxxxx", name="src")
        result = src - B8(1)
        assert result._provenance is None

    def test_neg_destroys(self):
        src = B8("xxxxxxxx", name="src")
        result = -src
        assert result._provenance is None


class TestProvenanceDisplay:
    def test_repr_full_unknown_named(self):
        v = B8("xxxxxxxx", name="src")
        r = repr(v)
        assert "src[7:0]" in r

    def test_repr_partial_named(self):
        v = B8("1111xxxx", name="src")
        r = repr(v)
        assert "1111" in r
        assert "src[3:0]" in r

    def test_repr_no_provenance_unchanged(self):
        v = B8("1100xxxx")
        r = repr(v)
        assert "1100 xxxx" in r

    def test_repr_single_bit(self):
        v = B("x0000000", name="sign")
        r = repr(v)
        assert "sign[7]" in r

    def test_repr_mixed_sources(self):
        hi = B8("xxxx0000", name="hi")
        lo = B8("0000xxxx", name="lo")
        result = hi.concat(lo)
        r = repr(result)
        assert "hi" in r
        assert "lo" in r

    def test_bin_unchanged(self):
        v = B8("xxxxxxxx", name="src")
        assert v.bin() == "xxxxxxxx"

    def test_repr_non_contiguous(self):
        src = B8("xxxxxxxx", name="src")
        result = src & B8("01010101")
        r = repr(result)
        # Each isolated bit renders as src[N]
        assert "src[6]" in r
        assert "src[4]" in r
        assert "src[2]" in r
        assert "src[0]" in r


class TestProvenanceEdgeCases:
    def test_width_1(self):
        v = B("x", width=1, name="flag")
        assert v._provenance is not None
        assert v._provenance[0] == ("flag", 0)

    def test_large_width(self):
        v = B.unknown(128, name="big")
        assert v._provenance is not None
        assert len(v._provenance) == 128

    def test_chain_bitwise_ops(self):
        v = B8("xxxxxxxx", name="src")
        result = (v & 0x0F) | 0x30
        # After & 0x0F: lower 4 bits have provenance, upper 4 known-0
        # After | 0x30: bits 5-4 become known-1, bits 3-0 keep provenance
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("src", i)
        for i in range(4, 8):
            assert i not in result._provenance

    def test_provenance_killed_by_arith_then_bitwise(self):
        v = B8("xxxxxxxx", name="src")
        result = (v + 1) & 0x0F
        assert result._provenance is None

    def test_concat_then_extract_roundtrip(self):
        a = B8("xxxxxxxx", name="a")
        b = B8("xxxxxxxx", name="b")
        combined = a.concat(b)
        extracted = combined[15:8]
        assert extracted._provenance is not None
        for i in range(8):
            assert extracted._provenance[i] == ("a", i)

    def test_two_sources_via_or(self):
        a = B8("xxxx0000", name="a")
        b = B8("0000xxxx", name="b")
        result = a | b
        assert result._provenance is not None
        for i in range(4):
            assert result._provenance[i] == ("b", i)
        for i in range(4, 8):
            assert result._provenance[i] == ("a", i)

    def test_invariant_provenance_only_on_unknowns(self):
        """Every provenance key must be at an unknown bit position."""
        v = B8("xxxxxxxx", name="src")
        ops = [
            v & 0x0F,
            v | 0xF0,
            v ^ 0xAA,
            ~v,
            v << 3,
            v >> 3,
            v.ashr(2),
            v.zext(16),
            v.sext(16),
            v.truncate(4),
        ]
        for result in ops:
            if result._provenance is not None:
                for bit_idx in result._provenance:
                    bit = 1 << bit_idx
                    assert not (result._ones & bit), \
                        f"Provenance at known-1 bit {bit_idx}"
                    assert not (result._zeros & bit), \
                        f"Provenance at known-0 bit {bit_idx}"
