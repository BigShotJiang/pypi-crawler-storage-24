"""Backward and forward slicing of RDNA instruction streams."""

from __future__ import annotations

from dataclasses import dataclass, field

from isatrace.instruction import Instruction
from isatrace.parser import parse
from isatrace.registers import overlaps, expand


@dataclass
class ControlFlowMarker:
    """Marks where control flow diverges/reconverges in a trace."""
    line: int
    kind: str             # "diverge", "else", "reconverge"
    description: str      # human-readable


@dataclass
class ControlFlowRegion:
    """A detected EXEC-mask control flow region."""
    save_line: int
    diverge_line: int
    diverge_description: str
    else_line: int | None
    reconverge_line: int
    saved_exec_reg: str


@dataclass
class TraceResult:
    """Result of a backward or forward trace."""
    target: Instruction
    target_register: str
    chain: list[Instruction]         # instructions in program order
    inputs: list[str]                # leaf registers not defined in the block
    control_flow: list[ControlFlowMarker] = field(default_factory=list)


class Slicer:
    """Backward/forward register dependency slicer for RDNA shaders."""

    def __init__(self, text: str):
        self._instructions = parse(text)
        self._cf_regions = _detect_control_flow(self._instructions)

    @property
    def instructions(self) -> list[Instruction]:
        return list(self._instructions)

    def trace(self, register: str, line: int | None = None,
              track_exec: bool = False) -> TraceResult:
        """Backward trace: find all instructions contributing to `register` at `line`."""
        target_instr, target_line = self._resolve_target(register, line, direction='backward')

        # worklist maps register -> consumer_line (the instruction that needs it)
        worklist: dict[str, int] = {register: target_line}
        result_lines: set[int] = set()
        result_instrs: list[Instruction] = []

        # Walk backward from target_line
        candidates = [i for i in self._instructions if i.line <= target_line and not i.is_label]
        candidates.sort(key=lambda i: i.line, reverse=True)

        for instr in candidates:
            if not worklist:
                break

            # Check if this instruction defines anything in the worklist
            all_defs = instr.all_defs
            matched_regs: list[str] = []

            for w in list(worklist):
                for d in all_defs:
                    if _reg_overlaps(w, d):
                        matched_regs.append(w)
                        break

            if not matched_regs:
                continue

            # Exec-mask awareness: skip vector defs from opposite branch.
            # A vector instruction in the IF block is invisible to ELSE-block
            # consumers, and vice versa. Scalar instructions execute regardless
            # of EXEC mask, so this skip only applies to vector instructions.
            if instr.is_vector:
                kept = []
                for reg in matched_regs:
                    consumer_line = worklist[reg]
                    if self._is_opposite_branch(instr.line, consumer_line):
                        pass  # Skip — this def is invisible to the consumer
                    else:
                        kept.append(reg)
                matched_regs = kept

            if not matched_regs:
                continue

            if instr.line not in result_lines:
                result_lines.add(instr.line)
                result_instrs.append(instr)

            # Include the other-path def when the consumer is outside the CF
            # region (after reconverge), meaning both branches' values are live.
            # Also include it for the target register when no specific line was
            # given ("show me everything" mode).
            for reg in matched_regs:
                consumer_line = worklist[reg]
                consumer_side = self._get_cf_side(consumer_line)
                include_other = (
                    consumer_side is None
                    or (reg == register and line is None)
                )
                if include_other:
                    other = self._find_other_path_def(instr, reg, target_line)
                    if other and other.line not in result_lines:
                        result_lines.add(other.line)
                        result_instrs.append(other)
                        # Trace the other path's sources too
                        for u in other.all_uses:
                            if u not in worklist:
                                worklist[u] = other.line

            # Remove matched registers from worklist
            for r in matched_regs:
                worklist.pop(r, None)

            # Add source registers to worklist
            for u in instr.all_uses:
                if u not in worklist:
                    worklist[u] = instr.line

            # If track_exec and this is a vector instruction, add exec
            if track_exec and instr.is_vector:
                if 'exec' not in worklist:
                    worklist['exec'] = instr.line

        # Sort by line number (program order)
        result_instrs.sort(key=lambda i: i.line)

        # Add CF structure instructions and build markers
        result_instrs, cf_markers = self._add_control_flow_context(
            result_instrs, result_lines, target_line)

        # Leaf inputs: whatever remains in worklist
        inputs = sorted(worklist.keys())

        return TraceResult(
            target=target_instr,
            target_register=register,
            chain=result_instrs,
            inputs=inputs,
            control_flow=cf_markers,
        )

    def forward_trace(self, register: str, line: int | None = None) -> TraceResult:
        """Forward trace: find all consumers of `register` defined at `line`."""
        target_instr, target_line = self._resolve_target(register, line, direction='forward')

        result_instrs: list[Instruction] = [target_instr]
        tracked_regs: set[str] = set()

        # The register(s) defined at target_line
        for d in target_instr.all_defs:
            if _reg_overlaps(register, d):
                tracked_regs.add(d)

        # Walk forward from target_line
        candidates = [i for i in self._instructions if i.line > target_line and not i.is_label]
        candidates.sort(key=lambda i: i.line)

        for instr in candidates:
            if not tracked_regs:
                break

            all_uses = instr.all_uses
            all_defs = instr.all_defs

            # Check if this instruction uses any tracked register
            used = False
            for u in all_uses:
                for t in tracked_regs:
                    if _reg_overlaps(u, t):
                        used = True
                        break
                if used:
                    break

            if used:
                result_instrs.append(instr)

            # Check if this instruction redefines (kills) any tracked register
            killed: set[str] = set()
            for d in all_defs:
                for t in list(tracked_regs):
                    if _reg_overlaps(d, t):
                        killed.add(t)

            tracked_regs -= killed

        result_instrs.sort(key=lambda i: i.line)

        return TraceResult(
            target=target_instr,
            target_register=register,
            chain=result_instrs,
            inputs=[],
        )

    def defs(self, register: str) -> list[Instruction]:
        """All definitions of a register in the program."""
        result = []
        for instr in self._instructions:
            for d in instr.all_defs:
                if _reg_overlaps(register, d):
                    result.append(instr)
                    break
        return result

    def uses(self, register: str) -> list[Instruction]:
        """All uses of a register in the program."""
        result = []
        for instr in self._instructions:
            for u in instr.all_uses:
                if _reg_overlaps(register, u):
                    result.append(instr)
                    break
        return result

    def scc_hazards(self) -> list:
        """Find SCC set-then-clobbered-before-use hazards."""
        from isatrace.hazards import find_hazards
        return find_hazards(self._instructions, 'scc')

    def vcc_hazards(self) -> list:
        """Find VCC set-then-clobbered-before-use hazards."""
        from isatrace.hazards import find_hazards
        return find_hazards(self._instructions, 'vcc')

    def _resolve_target(self, register: str, line: int | None,
                        direction: str) -> tuple[Instruction, int]:
        """Find the target instruction for a trace."""
        if line is not None:
            # Find the instruction at or nearest before the given line
            candidates = [i for i in self._instructions if i.line == line]
            if candidates:
                return candidates[0], line
            # If no instruction at exact line, find nearest
            if direction == 'backward':
                before = [i for i in self._instructions if i.line <= line]
                if before:
                    instr = max(before, key=lambda i: i.line)
                    return instr, line
            raise ValueError(f"No instruction at or before line {line}")

        # No line specified: find last definition
        if direction == 'backward':
            all_defs = self.defs(register)
            if all_defs:
                target = all_defs[-1]
                return target, target.line
            raise ValueError(f"No definition of {register} found")
        else:
            all_defs = self.defs(register)
            if all_defs:
                target = all_defs[0]
                return target, target.line
            raise ValueError(f"No definition of {register} found")

    def _get_cf_side(self, line: int) -> tuple[str, ControlFlowRegion] | None:
        """Return ('if', region) or ('else', region) if line is inside a CF branch, else None."""
        for region in self._cf_regions:
            if region.else_line is None:
                continue
            if region.diverge_line <= line < region.else_line:
                return ('if', region)
            if region.else_line <= line < region.reconverge_line:
                return ('else', region)
        return None

    def _is_opposite_branch(self, def_line: int, consumer_line: int) -> bool:
        """Check if def_line is in the opposite CF branch from consumer_line."""
        def_side = self._get_cf_side(def_line)
        consumer_side = self._get_cf_side(consumer_line)

        if def_side is None or consumer_side is None:
            return False

        # Both must be in the same CF region but different sides
        if def_side[1] is not consumer_side[1]:
            return False

        return def_side[0] != consumer_side[0]

    def _find_other_path_def(self, instr: Instruction, register: str,
                            target_line: int | None = None) -> Instruction | None:
        """If instr is inside one side of a CF region, find the def of register on the other side.

        Only returns instructions with line <= target_line (if specified).
        """
        for region in self._cf_regions:
            if region.else_line is None:
                continue

            in_if = region.diverge_line <= instr.line < region.else_line
            in_else = region.else_line <= instr.line < region.reconverge_line

            if not in_if and not in_else:
                continue

            # Search the other side for a def of register
            if in_if:
                search_start = region.else_line
                search_end = region.reconverge_line
            else:
                search_start = region.diverge_line
                search_end = region.else_line

            for other_instr in self._instructions:
                if other_instr.line < search_start or other_instr.line >= search_end:
                    continue
                if target_line is not None and other_instr.line > target_line:
                    continue
                if other_instr.is_label:
                    continue
                for d in other_instr.all_defs:
                    if _reg_overlaps(register, d):
                        return other_instr

        return None

    def _add_control_flow_context(
        self, chain: list[Instruction], result_lines: set[int],
        target_line: int
    ) -> tuple[list[Instruction], list[ControlFlowMarker]]:
        """Add CF structure instructions to the chain and generate markers.

        When the trace includes defs in both sides of a CF region, add the
        EXEC save instruction to the chain and generate diverge/else/reconverge
        markers.

        Returns (updated_chain, markers).
        """
        markers: list[ControlFlowMarker] = []
        added_instrs: list[Instruction] = []

        for region in self._cf_regions:
            if region.else_line is None:
                continue

            # Check if the chain has instructions in both sides
            has_if = any(region.diverge_line <= i.line < region.else_line
                         for i in chain)
            has_else = any(region.else_line <= i.line < region.reconverge_line
                           for i in chain)

            if not (has_if and has_else):
                # Check for single-side with CF structure already present
                has_any = has_if or has_else
                if not has_any:
                    continue

            # Add EXEC save instruction to chain if not already there
            if region.save_line not in result_lines and region.save_line <= target_line:
                save_instr = self._find_instruction_at(region.save_line)
                if save_instr:
                    added_instrs.append(save_instr)
                    result_lines.add(region.save_line)

            # Generate markers
            markers.append(ControlFlowMarker(
                line=region.diverge_line,
                kind="diverge",
                description=region.diverge_description,
            ))
            if region.else_line:
                # Find the else instruction to describe it
                else_instr = self._find_instruction_at(region.else_line)
                else_desc = "remaining lanes"
                if else_instr:
                    else_desc = f"{else_instr.opcode}: remaining lanes"
                markers.append(ControlFlowMarker(
                    line=region.else_line,
                    kind="else",
                    description=else_desc,
                ))
            markers.append(ControlFlowMarker(
                line=region.reconverge_line,
                kind="reconverge",
                description=f"s_mov_b64 exec, {region.saved_exec_reg}",
            ))

        if added_instrs:
            chain = sorted(chain + added_instrs, key=lambda i: i.line)
        return chain, markers

    def _find_instruction_at(self, line: int) -> Instruction | None:
        """Find the instruction at a specific line number."""
        for instr in self._instructions:
            if instr.line == line:
                return instr
        return None


def _reg_overlaps(a: str, b: str) -> bool:
    """Check if two register references overlap, using the registers module."""
    return overlaps(a, b)


def _detect_control_flow(instructions: list[Instruction]) -> list[ControlFlowRegion]:
    """Pre-scan instructions for EXEC-based control flow patterns."""
    regions: list[ControlFlowRegion] = []

    # Find EXEC saves: s_mov_b64 s[X:Y], exec  OR  s_and_saveexec_b64 s[X:Y], ...
    exec_saves: list[tuple[int, str, Instruction, bool]] = []  # (line, saved_reg, instr, is_saveexec)
    for instr in instructions:
        if instr.opcode in ('s_mov_b64', 's_mov_b32'):
            if 'exec' in instr.uses and instr.defs:
                saved_reg = instr.defs[0]
                if saved_reg not in ('exec', 'exec_lo', 'exec_hi'):
                    exec_saves.append((instr.line, saved_reg, instr, False))
        # s_and_saveexec saves old EXEC into the SGPR dest
        elif instr.opcode.startswith(('s_and_saveexec', 's_or_saveexec', 's_xor_saveexec')):
            if instr.defs:
                saved_reg = instr.defs[0]
                exec_saves.append((instr.line, saved_reg, instr, True))

    for save_line, saved_reg, save_instr, is_saveexec in exec_saves:
        diverge_line = None
        diverge_desc = ""
        else_line = None
        reconverge_line = None

        # If this is a saveexec, the save itself is also the diverge point
        if is_saveexec:
            diverge_line = save_line
            sources = ', '.join(save_instr.uses)
            diverge_desc = f"{save_instr.opcode}: {sources}"

        # Look for diverge: v_cmpx_* or s_and_saveexec_* or s_and_b64 exec, exec, ...
        for instr in instructions:
            if instr.line <= save_line:
                continue

            # v_cmpx writes EXEC
            if instr.opcode.startswith('v_cmpx_') and diverge_line is None:
                diverge_line = instr.line
                sources = ', '.join(instr.uses)
                diverge_desc = f"{instr.opcode}: {sources}"
                continue

            # s_and_b64 exec, exec, ... right after save
            if (instr.opcode in ('s_and_b64', 's_and_b32') and
                    instr.defs and instr.defs[0] in ('exec', 'exec_lo', 'exec_hi') and
                    diverge_line is None):
                diverge_line = instr.line
                sources = ', '.join(instr.uses)
                diverge_desc = f"{instr.opcode}: {sources}"
                continue

            # Else-flip: s_andn2_b64 exec, saved_reg, exec
            if (instr.opcode in ('s_andn2_b64', 's_andn2_b32') and
                    instr.defs and instr.defs[0] in ('exec', 'exec_lo', 'exec_hi')):
                for u in instr.uses:
                    if _reg_overlaps(u, saved_reg):
                        else_line = instr.line
                        break

            # Reconverge: s_mov_b64 exec, saved_reg
            if (instr.opcode in ('s_mov_b64', 's_mov_b32') and
                    instr.defs and instr.defs[0] in ('exec', 'exec_lo', 'exec_hi')):
                for u in instr.uses:
                    if _reg_overlaps(u, saved_reg):
                        reconverge_line = instr.line
                        break

            if reconverge_line:
                break

        if diverge_line and reconverge_line:
            regions.append(ControlFlowRegion(
                save_line=save_line,
                diverge_line=diverge_line,
                diverge_description=diverge_desc,
                else_line=else_line,
                reconverge_line=reconverge_line,
                saved_exec_reg=saved_reg,
            ))

    return regions
