"""Register parsing, range expansion, overlap detection, and categorization for RDNA ISA."""

from __future__ import annotations

import re

# Pattern: register range like v[0:3] or s[4:5]
_RANGE_RE = re.compile(r'^([vs])\[(\d+):(\d+)\]$')

# Pattern: single numbered register like v0, s12
_SINGLE_RE = re.compile(r'^([vs])(\d+)$')

# Constants / inline values — NOT registers
_CONSTANT_RE = re.compile(
    r'^('
    r'0x[0-9a-fA-F]+'        # hex literal
    r'|0[xX][0-9a-fA-F]+'    # hex with X
    r'|-?\d+\.?\d*'          # numeric literal (int or float)
    r'|null'                  # null
    r'|off'                   # GFX11 disabled channel
    r'|lit\(.*\)'             # lit(...) constant
    r'|attr\d+\.[xyzw]'      # interpolation attribute
    r')$'
)

# Named float constants (RDNA inline constants)
_FLOAT_CONSTANTS = frozenset({
    '0', '0.0', '0.5', '-0.5', '1.0', '-1.0', '2.0', '-2.0', '4.0', '-4.0',
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13',
    '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25',
    '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37',
    '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49',
    '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61',
    '62', '63', '64',
})

# Special registers
SPECIAL_REGISTERS = frozenset({
    'vcc', 'vcc_lo', 'vcc_hi',
    'exec', 'exec_lo', 'exec_hi',
    'scc', 'm0', 'null',
})

# Render target "registers"
_MRT_RE = re.compile(r'^(mrt\d+|pos\d+|prim|param\d+|mrtz)$')

# Logical groupings: aliases map to canonical names
_ALIASES = {
    'vcc_lo': 'vcc',
    'vcc_hi': 'vcc',
    'exec_lo': 'exec',
    'exec_hi': 'exec',
}


def is_constant(token: str) -> bool:
    """Return True if the token is a constant/literal, not a register."""
    token = token.strip()
    if not token:
        return True
    if token in _FLOAT_CONSTANTS:
        return True
    if _CONSTANT_RE.match(token):
        return True
    return False


def is_register(token: str) -> bool:
    """Return True if the token is a valid register reference."""
    token = token.strip()
    if not token:
        return False
    if is_constant(token):
        return False
    if token in SPECIAL_REGISTERS:
        return True
    if _MRT_RE.match(token):
        return True
    if _RANGE_RE.match(token):
        return True
    if _SINGLE_RE.match(token):
        return True
    return False


def is_render_target(token: str) -> bool:
    """Return True if the token is a render target (mrt0, pos0, etc.)."""
    return bool(_MRT_RE.match(token.strip()))


def category(reg: str) -> str:
    """Categorize a register: 'vgpr', 'sgpr', 'special', 'render_target', or 'unknown'."""
    reg = reg.strip()
    if _MRT_RE.match(reg):
        return 'render_target'
    if reg in ('vcc', 'vcc_lo', 'vcc_hi', 'scc', 'exec', 'exec_lo', 'exec_hi', 'm0'):
        return 'special'
    if reg == 'null':
        return 'special'
    m = _RANGE_RE.match(reg)
    if m:
        return 'vgpr' if m.group(1) == 'v' else 'sgpr'
    m = _SINGLE_RE.match(reg)
    if m:
        return 'vgpr' if m.group(1) == 'v' else 'sgpr'
    return 'unknown'


def expand(reg: str) -> list[str]:
    """Expand a register or register range to individual scalar registers.

    Examples:
        expand('v0') -> ['v0']
        expand('s[0:3]') -> ['s0', 's1', 's2', 's3']
        expand('vcc') -> ['vcc_lo', 'vcc_hi']
        expand('exec') -> ['exec_lo', 'exec_hi']
    """
    reg = reg.strip()

    m = _RANGE_RE.match(reg)
    if m:
        prefix, lo, hi = m.group(1), int(m.group(2)), int(m.group(3))
        return [f'{prefix}{i}' for i in range(lo, hi + 1)]

    m = _SINGLE_RE.match(reg)
    if m:
        return [reg]

    if reg == 'vcc':
        return ['vcc_lo', 'vcc_hi']
    if reg == 'exec':
        return ['exec_lo', 'exec_hi']
    if reg in ('vcc_lo', 'vcc_hi', 'exec_lo', 'exec_hi', 'scc', 'm0'):
        return [reg]

    if _MRT_RE.match(reg):
        return [reg]

    return [reg]


def canonical(reg: str) -> str:
    """Return the canonical form of a register (resolve aliases)."""
    return _ALIASES.get(reg, reg)


def overlaps(a: str, b: str) -> bool:
    """Return True if two register references overlap.

    Examples:
        overlaps('s0', 's[0:3]') -> True
        overlaps('v[0:3]', 'v[2:5]') -> True
        overlaps('vcc', 'vcc_lo') -> True
        overlaps('s0', 's1') -> False
    """
    a, b = a.strip(), b.strip()

    # Quick identity check
    if a == b:
        return True

    # Check canonical aliases
    if canonical(a) == canonical(b):
        return True

    # Expand both and check intersection
    expanded_a = set(expand(a))
    expanded_b = set(expand(b))

    return bool(expanded_a & expanded_b)


def normalize(reg: str) -> str:
    """Normalize a register string (strip whitespace, lowercase)."""
    return reg.strip().lower()


def parse_register(token: str) -> str | None:
    """Parse a token and return the normalized register string, or None if not a register."""
    token = token.strip()
    if is_register(token):
        return normalize(token)
    return None
