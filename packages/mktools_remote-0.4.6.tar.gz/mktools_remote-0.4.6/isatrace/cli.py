"""CLI entry point for isatrace."""

from __future__ import annotations

import argparse
import sys

from rich.console import Console

from isatrace.slicer import Slicer
from isatrace.tui.trace_view import render_trace


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="isatrace",
        description="Backward register tracer for AMD RDNA shader disassembly",
    )
    parser.add_argument("file", help="RDNA disassembly dump file")
    parser.add_argument("--trace", "-t", metavar="REG",
                        help="Trace backward from a register (e.g., v5, mrt0)")
    parser.add_argument("--line", "-l", type=int, default=None,
                        help="Line number for the trace target")
    parser.add_argument("--forward", action="store_true",
                        help="Forward trace instead of backward")
    parser.add_argument("--track-exec", action="store_true",
                        help="Track EXEC mask dependencies for vector ops")
    parser.add_argument("--defs", metavar="REG",
                        help="List all definitions of a register")
    parser.add_argument("--uses", metavar="REG",
                        help="List all uses of a register")
    parser.add_argument("--hazards", choices=["scc", "vcc"],
                        help="Show SCC or VCC hazards")
    parser.add_argument("--output", "-o", metavar="FILE",
                        help="Write output to file instead of stdout")

    args = parser.parse_args(argv)

    try:
        with open(args.file) as f:
            text = f.read()
    except (FileNotFoundError, PermissionError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    slicer = Slicer(text)

    # CLI mode: --trace, --defs, --uses, --hazards
    if args.trace or args.defs or args.uses or args.hazards:
        console = Console(file=open(args.output, 'w') if args.output else sys.stdout)

        if args.trace:
            try:
                if args.forward:
                    result = slicer.forward_trace(args.trace, line=args.line)
                else:
                    result = slicer.trace(args.trace, line=args.line,
                                          track_exec=args.track_exec)
                console.print(render_trace(result))
            except ValueError as e:
                console.print(f"[red]Error:[/] {e}")
                sys.exit(1)

        elif args.defs:
            defs = slicer.defs(args.defs)
            if defs:
                console.print(f"[bold]Definitions of {args.defs}:[/]")
                for instr in defs:
                    console.print(f"  [dim]{instr.line:>4}:[/] {instr.opcode}  "
                                  f"[cyan]writes:[/] {', '.join(instr.all_defs)}")
            else:
                console.print(f"No definitions of {args.defs} found.")

        elif args.uses:
            uses = slicer.uses(args.uses)
            if uses:
                console.print(f"[bold]Uses of {args.uses}:[/]")
                for instr in uses:
                    console.print(f"  [dim]{instr.line:>4}:[/] {instr.opcode}  "
                                  f"[green]reads:[/] {', '.join(instr.all_uses)}")
            else:
                console.print(f"No uses of {args.uses} found.")

        elif args.hazards:
            if args.hazards == "scc":
                hazards = slicer.scc_hazards()
            else:
                hazards = slicer.vcc_hazards()

            if hazards:
                console.print(f"[bold red]{len(hazards)} {args.hazards.upper()} hazard(s) found:[/]")
                for h in hazards:
                    console.print(f"\n  [bold]Setter:[/]    L{h.setter.line}: {h.setter.raw}")
                    console.print(f"  [bold]Clobberer:[/] L{h.clobberer.line}: {h.clobberer.raw}")
                    console.print(f"  [bold]Consumer:[/]  L{h.consumer.line}: {h.consumer.raw}")
            else:
                console.print(f"No {args.hazards.upper()} hazards found.")

        if args.output:
            console.file.close()
        return

    # TUI mode
    from isatrace.tui.app import IsatraceApp
    app = IsatraceApp(slicer)
    app.run()


if __name__ == "__main__":
    main()
