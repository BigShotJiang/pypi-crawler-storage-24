"""SCC/VCC hazard detection — find set-then-clobbered-before-use patterns."""

from __future__ import annotations

import re
from dataclasses import dataclass

from isatrace.instruction import Instruction


@dataclass
class Hazard:
    """A potential hazard where a flag is set, clobbered, then consumed."""
    setter: Instruction       # intentionally sets the flag
    clobberer: Instruction    # clobbers the flag as a side effect
    consumer: Instruction     # reads the (now wrong) flag value
    register: str             # "scc" or "vcc"


def find_hazards(instructions: list[Instruction], register: str) -> list[Hazard]:
    """Find set-then-clobbered-before-use hazards for the given register."""
    if register == 'scc':
        return _find_scc_hazards(instructions)
    elif register == 'vcc':
        return _find_vcc_hazards(instructions)
    return []


def _find_scc_hazards(instructions: list[Instruction]) -> list[Hazard]:
    """Find SCC hazards: SCC intentionally set, then clobbered before use."""
    hazards: list[Hazard] = []

    setter: Instruction | None = None
    clobberer: Instruction | None = None

    for instr in instructions:
        if instr.is_label or instr.is_wait:
            continue

        writes_scc = 'scc' in instr.implicit_defs or 'scc' in instr.defs
        reads_scc = 'scc' in instr.implicit_uses or 'scc' in instr.uses

        if writes_scc:
            if _is_intentional_scc_setter(instr):
                # New intentional setter — reset state
                setter = instr
                clobberer = None
            elif setter is not None:
                # This is a clobber (unintentional SCC write)
                if clobberer is None:
                    clobberer = instr

        if reads_scc and setter is not None and clobberer is not None:
            hazards.append(Hazard(
                setter=setter,
                clobberer=clobberer,
                consumer=instr,
                register='scc',
            ))
            # Reset state
            setter = None
            clobberer = None

        if reads_scc and setter is not None and clobberer is None:
            # SCC used immediately after setter, no hazard — reset
            setter = None

    return hazards


def _is_intentional_scc_setter(instr: Instruction) -> bool:
    """Return True if this instruction intentionally sets SCC (compare, bitcmp)."""
    return bool(re.match(r'^s_(cmp|cmpk|bitcmp)', instr.opcode))


def _find_vcc_hazards(instructions: list[Instruction]) -> list[Hazard]:
    """Find VCC hazards: VCC intentionally set, then clobbered before use."""
    hazards: list[Hazard] = []

    setter: Instruction | None = None
    clobberer: Instruction | None = None

    for instr in instructions:
        if instr.is_label or instr.is_wait:
            continue

        writes_vcc = 'vcc' in instr.implicit_defs or 'vcc' in instr.defs
        reads_vcc = ('vcc' in instr.implicit_uses or 'vcc' in instr.uses or
                     'vcc' in instr.all_uses)

        if writes_vcc:
            if _is_intentional_vcc_setter(instr):
                setter = instr
                clobberer = None
            elif setter is not None:
                if clobberer is None:
                    clobberer = instr

        if reads_vcc and setter is not None and clobberer is not None:
            hazards.append(Hazard(
                setter=setter,
                clobberer=clobberer,
                consumer=instr,
                register='vcc',
            ))
            setter = None
            clobberer = None

        if reads_vcc and setter is not None and clobberer is None:
            setter = None

    return hazards


def _is_intentional_vcc_setter(instr: Instruction) -> bool:
    """Return True if this instruction intentionally sets VCC (v_cmp_*)."""
    return bool(re.match(r'^v_cmp_', instr.opcode))
