"""Instruction data model for RDNA disassembly."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Instruction:
    """Represents a single parsed RDNA instruction."""
    line: int                           # 1-based line number in original file
    raw: str                            # original text, whitespace-stripped
    opcode: str                         # e.g., "v_add_f32"
    defs: list[str] = field(default_factory=list)      # explicit registers written
    uses: list[str] = field(default_factory=list)      # explicit registers read
    implicit_defs: list[str] = field(default_factory=list)  # e.g., ["scc"]
    implicit_uses: list[str] = field(default_factory=list)  # e.g., ["exec"]
    is_scalar: bool = False
    is_vector: bool = False
    is_memory: bool = False
    is_branch: bool = False
    is_wait: bool = False
    is_label: bool = False
    is_export: bool = False
    category: str = "other"             # salu, valu, smem, vmem, lds, branch, wait, export, interp, other

    @property
    def all_defs(self) -> list[str]:
        """All registers defined (explicit + implicit)."""
        return self.defs + self.implicit_defs

    @property
    def all_uses(self) -> list[str]:
        """All registers used (explicit + implicit)."""
        return self.uses + self.implicit_uses

    def detail(self) -> str:
        """Detailed string showing defs/uses."""
        parts = [f"Line {self.line}: {self.opcode}"]
        if self.defs:
            parts.append(f"writes: {', '.join(self.defs)}")
        if self.uses:
            parts.append(f"reads: {', '.join(self.uses)}")
        if self.implicit_defs:
            parts.append(f"implicit writes: {', '.join(self.implicit_defs)}")
        if self.implicit_uses:
            parts.append(f"implicit reads: {', '.join(self.implicit_uses)}")
        parts.append(f"category: {self.category}")
        return " | ".join(parts)

    def __repr__(self) -> str:
        return f"{self.line}: {self.raw}"
