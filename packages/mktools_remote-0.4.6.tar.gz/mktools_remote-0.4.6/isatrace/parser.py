"""RDNA disassembly parser — converts raw shader dump text into Instruction objects."""

from __future__ import annotations

import re

from isatrace.instruction import Instruction
from isatrace.registers import is_constant, is_register


def parse(text: str) -> list[Instruction]:
    """Parse RDNA disassembly text into a list of Instruction objects.

    Handles RGA-format dumps, GFX10/GFX11 ISA, labels, metadata, and
    multi-line instructions. Non-instruction lines are silently skipped.
    """
    lines = text.splitlines()
    instructions: list[Instruction] = []
    i = 0
    while i < len(lines):
        line_num = i + 1  # 1-based
        raw_line = lines[i]
        stripped = raw_line.strip()

        # Skip empty lines, comments, metadata preamble
        if not stripped:
            i += 1
            continue

        # Skip preamble/metadata lines
        if _is_metadata_line(stripped):
            i += 1
            continue

        # Label detection: "label_XXXX:" or similar
        if _is_label(stripped):
            label_name = stripped.rstrip(':')
            instructions.append(Instruction(
                line=line_num,
                raw=stripped,
                opcode=label_name,
                is_label=True,
                category="other",
            ))
            i += 1
            continue

        # Try to extract opcode from this line
        opcode, operand_str = _extract_opcode_and_operands(stripped)
        if opcode is None:
            i += 1
            continue

        # Skip s_code_end padding
        if opcode == 's_code_end':
            i += 1
            continue

        # Check for multi-line instruction (hex continuation on next line)
        while i + 1 < len(lines) and _is_hex_continuation(lines[i + 1]):
            i += 1

        # Build instruction
        instr = _build_instruction(line_num, stripped, opcode, operand_str)
        if instr is not None:
            instructions.append(instr)

        i += 1

    return instructions


# ── Metadata / preamble detection ──────────────────────────────────────────

_METADATA_PATTERNS = [
    re.compile(r'^;'),                         # comment
    re.compile(r'^shader\b'),                  # shader declaration
    re.compile(r'^asic\('),                    # asic(GFX10_3)
    re.compile(r'^type\('),                    # type(PS)
    re.compile(r'^sgpr_count\('),              # sgpr_count(14)
    re.compile(r'^vgpr_count\('),              # vgpr_count(8)
    re.compile(r'^wave_size\('),               # wave_size(64)
    re.compile(r'^end$'),                      # end keyword
    re.compile(r'^//'),                        # pure comment lines
]

# Lines that are only hex/whitespace with a comment — continuation lines, or
# lines that are solely a comment like "// s_ps_state in s0"
_ONLY_COMMENT_RE = re.compile(r'^//\s')


def _is_metadata_line(stripped: str) -> bool:
    """Return True if this line is metadata/preamble that should be skipped."""
    for pat in _METADATA_PATTERNS:
        if pat.match(stripped):
            return True
    # Lines that are purely hex comment like "// s_ps_state in s0"
    if _ONLY_COMMENT_RE.match(stripped):
        return True
    return False


# ── Label detection ────────────────────────────────────────────────────────

_LABEL_RE = re.compile(r'^[a-zA-Z_]\w*:$')


def _is_label(stripped: str) -> bool:
    return bool(_LABEL_RE.match(stripped))


# ── Multi-line hex continuation ────────────────────────────────────────────

_HEX_CONTINUATION_RE = re.compile(r'^\s*[0-9A-Fa-f]+\s*$')


def _is_hex_continuation(line: str) -> bool:
    return bool(_HEX_CONTINUATION_RE.match(line))


# ── Opcode extraction ─────────────────────────────────────────────────────

# Known opcode prefixes (order matters — check longer first)
_OPCODE_RE = re.compile(
    r'(?:^|\s)'
    r'(s_\w+|v_\w+|image_\w+|buffer_\w+|tbuffer_\w+|global_\w+|flat_\w+|'
    r'scratch_\w+|ds_\w+|exp|lds_param_load)'
    r'(?:\s|$)'
)


def _extract_opcode_and_operands(stripped: str) -> tuple[str | None, str]:
    """Extract opcode and operand string from a stripped line.

    Returns (opcode, operand_string) or (None, '') if no opcode found.
    """
    # Strip trailing comment: from the LAST '//' onward
    content = _strip_comment(stripped)
    content = content.strip()

    if not content:
        return None, ''

    m = _OPCODE_RE.search(content)
    if m:
        opcode = m.group(1)
        # Everything after the opcode is the operand string
        after = content[m.end():].strip()
        return opcode, after

    return None, ''


def _strip_comment(line: str) -> str:
    """Strip the trailing // hex-offset comment from a line.

    Uses the LAST occurrence of '//' to avoid eating content.
    """
    idx = line.rfind('//')
    if idx >= 0:
        return line[:idx]
    return line


# ── Operand tokenization ──────────────────────────────────────────────────

def _tokenize_operands(operand_str: str) -> list[str]:
    """Split operand string into individual operand tokens.

    Handles:
    - Comma-separated operands: v0, v1, s[0:3]
    - Bracket register ranges: s[0:3], v[0:7]
    - Bracket coordinate lists: [v2,v0]
    - Modifiers like dmask:0xf, done, compr, vm — ignored
    - Nested parens like lit(0x...), neg(v0), abs(v0)
    """
    if not operand_str:
        return []

    # Remove known modifiers before tokenizing
    operand_str = _strip_modifiers(operand_str)

    tokens: list[str] = []
    current = ''
    depth = 0  # track bracket/paren depth

    for ch in operand_str:
        if ch in '([':
            depth += 1
            current += ch
        elif ch in ')]':
            depth -= 1
            current += ch
        elif ch == ',' and depth == 0:
            tok = current.strip()
            if tok:
                tokens.append(tok)
            current = ''
        else:
            current += ch

    tok = current.strip()
    if tok:
        tokens.append(tok)

    # Post-process: expand bracket coordinate lists like [v2,v0]
    result: list[str] = []
    for tok in tokens:
        expanded = _expand_bracket_list(tok)
        result.extend(expanded)

    return result


# Modifier patterns to strip from operand strings
_MODIFIER_PATTERNS = [
    re.compile(r'\bdmask:0x[0-9a-fA-F]+'),
    re.compile(r'\bdim:\S+'),
    re.compile(r'\bidxen\b'),
    re.compile(r'\boffen\b'),
    re.compile(r'\bformat:\[[^\]]*\]'),
    re.compile(r'\bdone\b'),
    re.compile(r'\bcompr\b'),
    re.compile(r'\bvm\b'),
    re.compile(r'\bwait_vdst:\d+'),
    re.compile(r'\bwait_exp:\d+'),
    re.compile(r'\binstid0\([^)]*\)'),
    re.compile(r'\binstid1\([^)]*\)'),
    re.compile(r'\binstskip\([^)]*\)'),
    re.compile(r'\bglc\b'),
    re.compile(r'\bslc\b'),
    re.compile(r'\bdlc\b'),
    re.compile(r'\bunorm\b'),
    re.compile(r'\bscope:\S*'),
    re.compile(r'\bth:\S*'),
]


def _strip_modifiers(operand_str: str) -> str:
    """Remove ISA modifiers that aren't operands."""
    result = operand_str
    for pat in _MODIFIER_PATTERNS:
        result = pat.sub('', result)
    return result.strip()


def _expand_bracket_list(tok: str) -> list[str]:
    """Expand [v2,v0] bracket coordinate lists into individual registers.

    Register ranges like v[0:3] are NOT expanded here — they're kept as-is.
    """
    tok = tok.strip()
    # Detect bracket coordinate list: starts with [ and contains comma
    if tok.startswith('[') and tok.endswith(']') and ',' in tok:
        inner = tok[1:-1]
        return [t.strip() for t in inner.split(',') if t.strip()]
    return [tok]


def _strip_operand_modifier(tok: str) -> str:
    """Strip neg(), abs(), || modifiers from a register operand.

    neg(v0) → v0, abs(v0) → v0, |v0| → v0, -v0 → v0
    """
    tok = tok.strip()

    # neg(X) or abs(X)
    m = re.match(r'^(?:neg|abs)\((.+)\)$', tok)
    if m:
        return _strip_operand_modifier(m.group(1))

    # |X|
    if tok.startswith('|') and tok.endswith('|') and len(tok) > 2:
        return _strip_operand_modifier(tok[1:-1])

    # -X prefix (but not -0.5 etc which are constants)
    if tok.startswith('-') and len(tok) > 1 and not tok[1:].replace('.', '').replace('-', '').isdigit():
        inner = tok[1:]
        if is_register(inner):
            return inner

    return tok


# Pipe-separated modifiers in s_delay_alu operands
_PIPE_SEP_RE = re.compile(r'\|')


# ── Instruction classification ─────────────────────────────────────────────

def _classify_opcode(opcode: str) -> tuple[str, bool, bool, bool, bool, bool, bool]:
    """Classify an opcode into its category and flags.

    Returns: (category, is_scalar, is_vector, is_memory, is_branch, is_wait, is_export)
    """
    # Export
    if opcode == 'exp':
        return 'export', False, False, False, False, False, True

    # LDS param load (GFX11)
    if opcode == 'lds_param_load':
        return 'interp', False, True, False, False, False, False

    # Scalar memory
    if re.match(r'^s_(load|buffer_load|store|buffer_store|atomic)', opcode):
        return 'smem', True, False, True, False, False, False

    # Scalar compare (writes SCC, no GPR dest)
    if re.match(r'^s_(cmp|cmpk|bitcmp)', opcode):
        return 'salu', True, False, False, False, False, False

    # Scalar branch
    if re.match(r'^s_(cbranch|branch$)', opcode):
        return 'branch', True, False, False, True, False, False

    # Saveexec
    if re.match(r'^s_(and_saveexec|or_saveexec|xor_saveexec|nand_saveexec|nor_saveexec)', opcode):
        return 'salu', True, False, False, False, False, False

    # Wait/sync
    if re.match(r'^s_(waitcnt|nop|sleep|barrier|waitcnt_depctr)', opcode):
        return 'wait', True, False, False, False, True, False

    # Metadata instructions (no effects)
    if opcode in ('s_endpgm', 's_code_end', 's_version', 's_inst_prefetch',
                  's_set_inst_prefetch_distance', 's_delay_alu'):
        return 'other', True, False, False, False, False, False

    # Remaining scalar
    if opcode.startswith('s_'):
        return 'salu', True, False, False, False, False, False

    # v_cmpx — writes EXEC
    if re.match(r'^v_cmpx_', opcode):
        return 'valu', False, True, False, False, False, False

    # v_cmp — writes VCC (or explicit SGPR)
    if re.match(r'^v_cmp_', opcode):
        return 'valu', False, True, False, False, False, False

    # Vector interp
    if re.match(r'^v_interp_', opcode):
        return 'interp', False, True, False, False, False, False

    # Remaining vector
    if opcode.startswith('v_'):
        return 'valu', False, True, False, False, False, False

    # Image
    if opcode.startswith('image_'):
        return 'vmem', False, False, True, False, False, False

    # Buffer/tbuffer
    if re.match(r'^(buffer_|tbuffer_)', opcode):
        return 'vmem', False, False, True, False, False, False

    # Global/flat/scratch
    if re.match(r'^(global_|flat_|scratch_)', opcode):
        return 'vmem', False, False, True, False, False, False

    # DS (LDS/GDS)
    if opcode.startswith('ds_'):
        return 'lds', False, False, True, False, False, False

    return 'other', False, False, False, False, False, False


# ── Instruction building ──────────────────────────────────────────────────

# Instructions with no GPR destination (all operands are sources, or no register effects)
_NO_DEST_OPCODES = frozenset({
    's_endpgm', 's_code_end', 's_nop', 's_barrier', 's_sleep',
    's_version', 's_inst_prefetch', 's_set_inst_prefetch_distance', 's_delay_alu',
    's_waitcnt_depctr',
})

# Opcodes that are stores (data operand is a source, not a dest)
_STORE_RE = re.compile(
    r'^(buffer_store|tbuffer_store|global_store|flat_store|scratch_store|ds_write|s_store|s_buffer_store)'
)

# Opcodes where dest is also an implicit source (accumulate)
_ACCUMULATE_OPCODES = re.compile(r'^(v_fmac_|v_interp_p2_f)')


def _is_no_dest_opcode(opcode: str) -> bool:
    """Return True if this opcode has no GPR destination."""
    if opcode in _NO_DEST_OPCODES:
        return True
    if re.match(r'^s_(cmp|cmpk|bitcmp)', opcode):
        return True
    if re.match(r'^s_(cbranch|branch$)', opcode):
        return True
    if re.match(r'^s_(waitcnt|nop|sleep|barrier)', opcode):
        return True
    return False


def _is_store(opcode: str) -> bool:
    return bool(_STORE_RE.match(opcode))


def _is_accumulate(opcode: str) -> bool:
    return bool(_ACCUMULATE_OPCODES.match(opcode))


def _build_instruction(line: int, raw: str, opcode: str, operand_str: str) -> Instruction | None:
    """Build an Instruction from parsed opcode and operand string."""
    cat, is_scalar, is_vector, is_memory, is_branch, is_wait, is_export = _classify_opcode(opcode)

    # Metadata/wait instructions with no register effects
    if opcode in _NO_DEST_OPCODES or is_wait:
        return Instruction(
            line=line, raw=_strip_comment(raw).strip(), opcode=opcode,
            is_scalar=is_scalar, is_vector=is_vector, is_memory=is_memory,
            is_branch=is_branch, is_wait=is_wait, is_export=is_export,
            category=cat,
        )

    tokens = _tokenize_operands(operand_str)
    # Strip modifiers from each token
    tokens = [_strip_operand_modifier(t) for t in tokens]
    # Filter out empties
    tokens = [t for t in tokens if t]

    defs: list[str] = []
    uses: list[str] = []
    implicit_defs: list[str] = []
    implicit_uses: list[str] = []

    if is_export:
        _parse_export(tokens, defs, uses)
    elif re.match(r'^v_cmpx_', opcode):
        _parse_v_cmpx(tokens, defs, uses, implicit_defs)
    elif re.match(r'^v_cmp_', opcode):
        _parse_v_cmp(tokens, defs, uses, implicit_defs)
    elif is_branch:
        _parse_branch(opcode, tokens, uses, implicit_uses)
    elif _is_store(opcode):
        _parse_store(tokens, uses)
    elif _is_no_dest_opcode(opcode):
        # All tokens are sources
        for t in tokens:
            if is_register(t):
                uses.append(t)
    elif re.match(r'^s_(and_saveexec|or_saveexec|xor_saveexec|nand_saveexec|nor_saveexec)', opcode):
        _parse_saveexec(tokens, defs, uses, implicit_defs, implicit_uses)
    else:
        _parse_standard_alu(opcode, tokens, defs, uses, cat)

    # Add implicit defs/uses based on opcode classification
    _add_implicit_effects(opcode, defs, uses, implicit_defs, implicit_uses, cat)

    # For accumulate instructions, add dest to uses
    if _is_accumulate(opcode) and defs:
        dest = defs[0]
        if dest not in uses:
            uses.append(dest)

    # Deduplicate
    defs = _dedup(defs)
    uses = _dedup(uses)
    implicit_defs = _dedup(implicit_defs)
    implicit_uses = _dedup(implicit_uses)

    return Instruction(
        line=line,
        raw=_strip_comment(raw).strip(),
        opcode=opcode,
        defs=defs,
        uses=uses,
        implicit_defs=implicit_defs,
        implicit_uses=implicit_uses,
        is_scalar=is_scalar,
        is_vector=is_vector,
        is_memory=is_memory,
        is_branch=is_branch,
        is_wait=is_wait,
        is_export=is_export,
        category=cat,
    )


def _parse_export(tokens: list[str], defs: list[str], uses: list[str]) -> None:
    """Parse exp instruction: dest is render target, rest are source VGPRs."""
    if tokens:
        # First token is the render target
        defs.append(tokens[0])
        for t in tokens[1:]:
            if is_register(t) and not is_constant(t):
                if t not in uses:
                    uses.append(t)


def _parse_v_cmpx(tokens: list[str], defs: list[str], uses: list[str],
                   implicit_defs: list[str]) -> None:
    """Parse v_cmpx_* — writes EXEC (and optionally VCC). All operands are sources."""
    implicit_defs.append('exec')
    for t in tokens:
        if t in ('exec', 'exec_lo', 'exec_hi'):
            continue  # exec in operand list is the dest, already handled implicitly
        if is_register(t):
            uses.append(t)


def _parse_v_cmp(tokens: list[str], defs: list[str], uses: list[str],
                 implicit_defs: list[str]) -> None:
    """Parse v_cmp_* — writes VCC or explicit SGPR pair."""
    if not tokens:
        return

    first = tokens[0]
    if first in ('vcc', 'vcc_lo', 'vcc_hi'):
        # VCC is the implicit destination
        implicit_defs.append('vcc')
        # Rest are sources
        for t in tokens[1:]:
            if is_register(t):
                uses.append(t)
    elif is_register(first) and not first.startswith('v'):
        # Explicit SGPR destination
        defs.append(first)
        for t in tokens[1:]:
            if is_register(t):
                uses.append(t)
    else:
        # No explicit dest, default to VCC
        implicit_defs.append('vcc')
        for t in tokens:
            if is_register(t):
                uses.append(t)


def _parse_branch(opcode: str, tokens: list[str], uses: list[str],
                  implicit_uses: list[str]) -> None:
    """Parse branch instructions — determine which flag they read."""
    if 'scc0' in opcode or 'scc1' in opcode:
        implicit_uses.append('scc')
    elif 'vccz' in opcode or 'vccnz' in opcode:
        implicit_uses.append('vcc')
    elif 'execz' in opcode or 'execnz' in opcode:
        implicit_uses.append('exec')
    # Branch target labels are not registers


def _parse_store(tokens: list[str], uses: list[str]) -> None:
    """Parse store instructions — all operands are sources."""
    for t in tokens:
        if is_register(t):
            uses.append(t)


def _parse_saveexec(tokens: list[str], defs: list[str], uses: list[str],
                    implicit_defs: list[str], implicit_uses: list[str]) -> None:
    """Parse s_and_saveexec_b64 s[X:Y], <src> — saves old EXEC to SGPR, writes EXEC."""
    if tokens:
        # First token is the SGPR destination (old EXEC saved here)
        if is_register(tokens[0]):
            defs.append(tokens[0])
        # Remaining are sources
        for t in tokens[1:]:
            if is_register(t):
                uses.append(t)
    implicit_defs.extend(['exec', 'scc'])
    implicit_uses.append('exec')


def _parse_standard_alu(opcode: str, tokens: list[str], defs: list[str],
                        uses: list[str], cat: str) -> None:
    """Parse standard ALU instruction: first operand is dest, rest are sources."""
    if not tokens:
        return

    first = tokens[0]
    if is_register(first):
        defs.append(first)
    # Check if dest appears again in sources (e.g., v_fmamk_f32 v0, v5, lit(...), v0)
    for t in tokens[1:]:
        if is_register(t):
            uses.append(t)


def _add_implicit_effects(opcode: str, defs: list[str], uses: list[str],
                          implicit_defs: list[str], implicit_uses: list[str],
                          cat: str) -> None:
    """Add implicit SCC/VCC/EXEC side effects based on opcode patterns."""

    # Skip opcodes that are already fully handled
    if re.match(r'^v_cmpx_', opcode) or re.match(r'^v_cmp_', opcode):
        return
    if re.match(r'^s_(and_saveexec|or_saveexec|xor_saveexec|nand_saveexec|nor_saveexec)', opcode):
        return

    # --- Scalar ALU implicit SCC ---
    if cat == 'salu':
        # Most scalar ALU writes SCC. Exceptions:
        no_scc = {
            's_mov_b32', 's_mov_b64', 's_movk_i32', 's_movreld_b32',
            's_movreld_b64', 's_movrels_b32', 's_movrels_b64',
            's_mul_i32', 's_getpc_b64', 's_setpc_b64', 's_swappc_b64',
            's_setreg_b32', 's_getreg_b32', 's_memtime', 's_memrealtime',
            's_nop', 's_endpgm',
        }
        if opcode not in no_scc:
            # Check if exec is the destination — s_andn2_b64 exec, ... still writes SCC
            implicit_defs.append('scc')

    # --- s_cselect reads SCC ---
    if re.match(r'^s_cselect_', opcode):
        implicit_uses.append('scc')

    # --- v_cndmask reads VCC (if vcc not already an explicit source) ---
    if re.match(r'^v_cndmask_', opcode):
        # Check if VCC is already an explicit source operand
        if 'vcc' not in uses:
            implicit_uses.append('vcc')

    # --- v_add_co / v_sub_co write VCC ---
    if re.match(r'^v_(add|sub)_co_', opcode):
        implicit_defs.append('vcc')

    # --- v_addc_co / v_subb_co read and write VCC ---
    if re.match(r'^v_(addc|subb)_co_', opcode):
        implicit_defs.append('vcc')
        implicit_uses.append('vcc')

    # --- s_wqm_b64 / s_wqm_b32 writes SCC ---
    # Already handled by the general salu SCC rule above

    # Check if dest is exec — add exec to defs if the opcode writes to exec explicitly
    if defs and defs[0] in ('exec', 'exec_lo', 'exec_hi'):
        # exec is already in defs as an explicit def, that's fine
        pass


def _dedup(lst: list[str]) -> list[str]:
    """Deduplicate while preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for item in lst:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result
