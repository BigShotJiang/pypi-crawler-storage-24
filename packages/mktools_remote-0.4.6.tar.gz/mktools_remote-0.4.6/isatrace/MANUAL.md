# isatrace

Backward register tracer for AMD RDNA shader disassembly.

A compiler engineer is staring at a 200-line RDNA shader disassembly dump. Multiple independent computations are interleaved. They want to answer: **"What instructions contributed to the value in register v5 at line 42?"**

`isatrace` answers this by performing a **backward slice**: starting from a target register at a specific instruction, it walks backward through the instruction stream collecting every instruction that directly or transitively contributed to that value. The output is a minimal, ordered subset of the original instructions that completely describes how the target value was computed.

## Interactive TUI

```bash
isatrace dump.txt
```

Navigate with arrow keys or j/k. Press **Enter** on an instruction to pick a register to trace. Press **Escape** to close the trace view. Press **q** to quit.

### CLI mode

**Backward trace:**
```bash
isatrace dump.txt --trace v6 --line 52
```

**Forward trace:**
```bash
isatrace dump.txt --trace v0 --line 10 --forward
```

**List all definitions of a register:**
```bash
isatrace dump.txt --defs v5
```

**List all uses of a register:**
```bash
isatrace dump.txt --uses v5
```

**Check for SCC/VCC hazards:**
```bash
isatrace dump.txt --hazards scc
isatrace dump.txt --hazards vcc
```

**Write output to file:**
```bash
isatrace dump.txt --trace v6 --line 52 --output trace.txt
```

**Track EXEC mask dependencies (makes traces more detailed):**
```bash
isatrace dump.txt --trace v0 --line 30 --track-exec
```

### Example output

Tracing `v0` at line 29 in a pixel shader — "what computed this cndmask result?" — pulls in the VCC comparison, the scalar buffer load, interpolation, and the sqrt/distance chain that feeds the comparison:

```
$ isatrace shader.txt --trace v0 --line 29

  TRACE: v0 at line 29

    13: s_buffer_load_dwordx8  s[8:15], s[4:7], 0x000010
    14: s_buffer_load_dword  s0, s[4:7], null
    15: v_interp_p1_f32  v2, v0, attr0.x
    16: v_interp_p1_f32  v0, v0, attr0.y  ← defines v0
    17: v_interp_p2_f32  v2, v1, attr0.x
    18: v_interp_p2_f32  v0, v1, attr0.y  ← defines v0
    19: v_add_f32     v2, -0.5, v2
    20: v_add_f32     v3, -0.5, v0
    21: v_mul_f32     v1, v2, v2
    22: v_fmac_f32    v1, v3, v3
    23: v_sqrt_f32    v0, v1  ← defines v0
    25: v_mov_b32     v1, s8
    28: v_cmp_gt_f32  vcc, s0, v0
    29: v_cndmask_b32  v0, s12, v1, vcc  ◆ TARGET  ← defines v0

  Leaf inputs: s[4:7], v0, v1
```

When a register is defined on both sides of a branch, the trace shows the control flow structure with IF/ELSE/RECONVERGE markers:

```
$ isatrace shader.txt --trace mrt0

  TRACE: mrt0 at line 45

    14: v_interp_p1_f32  v2, v0, attr0.y
    15: v_interp_p1_f32  v0, v0, attr0.x
    16: v_interp_p2_f32  v2, v1, attr0.y
    17: v_interp_p2_f32  v0, v1, attr0.x
    18: v_mul_f32     v1, v2, v0
    19: s_mov_b64     s[2:3], exec
  ┌─ IF ── v_cmpx_gt_f32: v1, s0 ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
  │   23: s_buffer_load_dwordx4  s[8:11], s[4:7], 0x000010
  │   25: v_mul_f32     v6, s8, v1
  │   26: v_mul_f32     v7, s9, v1
  │   27: v_mul_f32     v2, s10, v1
  │   28: v_mul_f32     v3, s11, v1
  ├─ ELSE ── s_andn2_b64: remaining lanes ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
  │   32: s_buffer_load_dwordx4  s[4:7], s[4:7], 0x000020
  │   33: v_fma_f32     v0, -v0, v2, 1.0
  │   35: v_mul_f32     v6, s4, v0
  │   36: v_mul_f32     v7, s5, v0
  │   37: v_mul_f32     v2, s6, v0
  │   38: v_mul_f32     v3, s7, v0
  └─ RECONVERGE ── s_mov_b64 exec, s[2:3] ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
    41: v_cvt_pkrtz_f16_f32  v4, v6, v7
    42: v_cvt_pkrtz_f16_f32  v5, v2, v3
    45: exp           mrt0, v4, v4, v5, v5 done compr vm  ◆ TARGET

  Leaf inputs: s[4:7], v0, v1
```

## Library usage

```python
from isatrace import Slicer

slicer = Slicer(open("dump.txt").read())

# Backward trace
result = slicer.trace("v6", line=52)
for instr in result.chain:
    print(f"  {instr.line}: {instr.opcode}")
print(f"Leaf inputs: {result.inputs}")

# Forward trace
result = slicer.forward_trace("v0", line=10)

# Defs and uses
for d in slicer.defs("v5"):
    print(d.detail())

# Hazard detection
for h in slicer.scc_hazards():
    print(f"SCC hazard: set at L{h.setter.line}, clobbered at L{h.clobberer.line}")
```

## Features

- Parses GFX10 and GFX11 RDNA shader disassembly (RGA format)
- Tracks implicit SCC, VCC, and EXEC register dependencies
- Handles `v_fmac`/`v_fmamk` accumulate instructions (dest is also a source)
- Detects EXEC-based if/else control flow divergence patterns
- Annotates traces with control flow markers (IF/ELSE/RECONVERGE)
- Detects SCC and VCC set-then-clobbered-before-use hazards
- Render target tracing (`mrt0`, `pos0`, etc.)
- Register range overlap detection (`s0` matches `s[0:3]`)

