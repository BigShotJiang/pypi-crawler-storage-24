"""Register selection modal for the TUI."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, OptionList
from textual.widgets.option_list import Option

from isatrace.instruction import Instruction


class RegisterPicker(ModalScreen[str | None]):
    """Modal to pick a register from an instruction's defs/uses."""

    CSS = """
    RegisterPicker {
        align: center middle;
    }
    RegisterPicker > Vertical {
        width: 50;
        max-height: 20;
        border: solid $accent;
        background: $surface;
        padding: 1 2;
    }
    RegisterPicker OptionList {
        height: auto;
        max-height: 14;
    }
    """

    def __init__(self, instr: Instruction) -> None:
        super().__init__()
        self.instr = instr
        # Uses first (more common trace target), then defs
        seen: set[str] = set()
        self.registers: list[str] = []
        for r in instr.all_uses:
            if r not in seen:
                seen.add(r)
                self.registers.append(r)
        for r in instr.all_defs:
            if r not in seen:
                seen.add(r)
                self.registers.append(r)

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label(f"Line {self.instr.line}: {self.instr.opcode}", classes="title")
            yield Label("Select register to trace:", classes="subtitle")
            options = [
                Option(f"{'→' if r in self.instr.all_uses else '←'} {r}", id=r)
                for r in self.registers
            ]
            yield OptionList(*options)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        self.dismiss(event.option.id)

    def key_escape(self) -> None:
        self.dismiss(None)
