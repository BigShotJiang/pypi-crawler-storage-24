"""Main Textual TUI app for isatrace."""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.widgets import Footer, Header, Static, RichLog, OptionList
from textual.widgets.option_list import Option
from rich.text import Text

from isatrace.instruction import Instruction
from isatrace.slicer import Slicer, TraceResult
from isatrace.tui.instruction_view import highlight_instruction
from isatrace.tui.trace_view import render_trace
from isatrace.tui.register_picker import RegisterPicker


class InstructionList(OptionList):
    """Scrollable list of shader instructions."""

    def __init__(self, instructions: list[Instruction], **kwargs) -> None:
        self.all_instructions = instructions
        options = []
        for instr in instructions:
            text = highlight_instruction(instr)
            options.append(Option(text, id=str(instr.line)))
        super().__init__(*options, **kwargs)


class DetailBar(Static):
    """Bottom detail bar showing current instruction info."""

    def update_instruction(self, instr: Instruction | None) -> None:
        if instr is None:
            self.update("")
            return
        self.update(Text.from_markup(
            f"[bold]Line {instr.line}:[/] {instr.opcode} | "
            f"[cyan]writes:[/] {', '.join(instr.all_defs) or '(none)'} | "
            f"[green]reads:[/] {', '.join(instr.all_uses) or '(none)'} | "
            f"[dim]{instr.category}[/]"
        ))


class TracePanel(RichLog):
    """Panel showing trace results."""
    pass


class IsatraceApp(App):
    """TUI for interactive register tracing of RDNA shader disassembly."""

    TITLE = "isatrace"
    CSS = """
    #main-container {
        height: 1fr;
    }
    #instruction-list {
        width: 1fr;
        min-width: 40;
    }
    #trace-panel {
        width: 50%;
        border-left: solid $accent;
        display: none;
    }
    #trace-panel.visible {
        display: block;
    }
    #detail-bar {
        height: 1;
        dock: bottom;
        background: $accent;
        padding: 0 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("enter", "select_register", "Trace"),
        Binding("escape", "close_trace", "Close trace"),
        Binding("h", "help", "Help"),
        Binding("d", "show_defs", "Defs"),
        Binding("u", "show_uses", "Uses"),
    ]

    def __init__(self, slicer: Slicer, **kwargs) -> None:
        super().__init__(**kwargs)
        self.slicer = slicer
        self.current_trace: TraceResult | None = None
        self.traced_lines: set[int] = set()

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-container"):
            yield InstructionList(self.slicer.instructions, id="instruction-list")
            yield TracePanel(id="trace-panel", wrap=True, markup=True)
        yield DetailBar(id="detail-bar")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#instruction-list", InstructionList).focus()

    def on_option_list_option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        if not isinstance(event.option_list, InstructionList):
            return
        if event.option and event.option.id:
            line = int(event.option.id)
            instr = self._find_instruction(line)
            self.query_one("#detail-bar", DetailBar).update_instruction(instr)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Open register picker when an instruction is selected (Enter)."""
        if not isinstance(event.option_list, InstructionList):
            return
        if event.option and event.option.id:
            line = int(event.option.id)
            instr = self._find_instruction(line)
            if instr and (instr.all_defs or instr.all_uses):
                self.push_screen(RegisterPicker(instr), self._on_register_picked)

    def action_select_register(self) -> None:
        """Open register picker for the current instruction (fallback for binding)."""
        il = self.query_one("#instruction-list", InstructionList)
        if il.highlighted is not None:
            option = il.get_option_at_index(il.highlighted)
            if option and option.id:
                line = int(option.id)
                instr = self._find_instruction(line)
                if instr and (instr.all_defs or instr.all_uses):
                    self.push_screen(RegisterPicker(instr), self._on_register_picked)

    def _on_register_picked(self, register: str | None) -> None:
        if register is None:
            return
        # Find the current instruction line
        il = self.query_one("#instruction-list", InstructionList)
        if il.highlighted is not None:
            option = il.get_option_at_index(il.highlighted)
            if option and option.id:
                line = int(option.id)
                self._run_trace(register, line)

    def _run_trace(self, register: str, line: int) -> None:
        try:
            result = self.slicer.trace(register, line=line)
        except ValueError:
            return

        self.current_trace = result
        self.traced_lines = {i.line for i in result.chain}

        # Update trace panel
        panel = self.query_one("#trace-panel", TracePanel)
        panel.clear()
        panel.write(render_trace(result))
        panel.add_class("visible")

        # Refresh instruction list to show highlighting
        self._refresh_instruction_list()

    def _refresh_instruction_list(self) -> None:
        """Refresh the instruction list with trace highlighting."""
        il = self.query_one("#instruction-list", InstructionList)
        target_line = self.current_trace.target.line if self.current_trace else None
        for idx, instr in enumerate(il.all_instructions):
            text = highlight_instruction(
                instr,
                traced_lines=self.traced_lines,
                target_line=target_line,
            )
            il.replace_option_prompt_at_index(idx, text)

    def action_close_trace(self) -> None:
        """Close the trace panel."""
        self.current_trace = None
        self.traced_lines = set()
        panel = self.query_one("#trace-panel", TracePanel)
        panel.remove_class("visible")
        self._refresh_instruction_list()

    def action_help(self) -> None:
        self.notify(
            "Enter: trace register | Esc: close trace | "
            "d: show defs | u: show uses | q: quit",
            title="isatrace help",
            timeout=5,
        )

    def action_show_defs(self) -> None:
        il = self.query_one("#instruction-list", InstructionList)
        if il.highlighted is not None:
            option = il.get_option_at_index(il.highlighted)
            if option and option.id:
                line = int(option.id)
                instr = self._find_instruction(line)
                if instr and instr.all_defs:
                    reg = instr.all_defs[0]
                    defs = self.slicer.defs(reg)
                    lines = [f"L{d.line}" for d in defs]
                    self.notify(f"Defs of {reg}: {', '.join(lines)}", timeout=5)

    def action_show_uses(self) -> None:
        il = self.query_one("#instruction-list", InstructionList)
        if il.highlighted is not None:
            option = il.get_option_at_index(il.highlighted)
            if option and option.id:
                line = int(option.id)
                instr = self._find_instruction(line)
                if instr and instr.all_defs:
                    reg = instr.all_defs[0]
                    uses = self.slicer.uses(reg)
                    lines = [f"L{u.line}" for u in uses]
                    self.notify(f"Uses of {reg}: {', '.join(lines)}", timeout=5)

    def _find_instruction(self, line: int) -> Instruction | None:
        for instr in self.slicer.instructions:
            if instr.line == line:
                return instr
        return None
