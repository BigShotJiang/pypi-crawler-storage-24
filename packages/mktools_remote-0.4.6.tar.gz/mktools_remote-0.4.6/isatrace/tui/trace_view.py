"""Trace result panel for the TUI."""

from __future__ import annotations

from rich.console import Console, ConsoleOptions, RenderResult, RenderableType
from rich.text import Text

from isatrace.slicer import TraceResult, ControlFlowMarker


def render_trace(result: TraceResult) -> Text:
    """Render a TraceResult as rich Text for display."""
    text = Text()
    text.append(f"  TRACE: {result.target_register}", style="bold underline")
    if result.target:
        text.append(f" at line {result.target.line}", style="bold underline")
    text.append("\n\n")

    # Build CF region info from markers for prefix calculation
    cf_regions = _build_cf_regions(result.control_flow)

    # Build a merged timeline of chain instructions and CF markers
    # Markers are rendered as standalone annotation lines between instructions
    cf_by_line = {m.line: m for m in result.control_flow}

    # Collect all marker lines that aren't already chain instruction lines
    chain_lines = {i.line for i in result.chain}
    marker_only_lines = set(cf_by_line.keys()) - chain_lines

    from isatrace.tui.instruction_view import _opcode_style

    # Process chain instructions in order, inserting markers at the right spots
    prev_line = 0
    for instr in result.chain:
        # Render any markers that fall between prev_line and instr.line
        for mline in sorted(cf_by_line.keys()):
            if prev_line < mline <= instr.line or (prev_line == 0 and mline <= instr.line):
                _render_marker(text, cf_by_line[mline])

        # Determine prefix based on CF region
        prefix = _cf_prefix(instr.line, cf_regions)

        # Line number and instruction
        line_str = f"{instr.line:>4}: "
        text.append(prefix)
        text.append(line_str, style="dim")

        # Opcode
        text.append(instr.opcode, style=_opcode_style(instr))

        # Operands from raw
        raw_after = instr.raw[len(instr.opcode):]
        idx = instr.raw.find(instr.opcode)
        if idx >= 0:
            raw_after = instr.raw[idx + len(instr.opcode):]
        text.append(raw_after)

        # Annotations
        is_target = (result.target and instr.line == result.target.line)
        if is_target:
            text.append("  ◆ TARGET", style="bold yellow")

        # Show what this instruction defines of interest
        for d in instr.defs:
            if d == result.target_register:
                text.append(f"  ← defines {d}", style="dim italic")

        text.append("\n")
        prev_line = instr.line

    # Render any trailing markers (e.g., reconverge after the last chain instruction)
    for mline in sorted(cf_by_line.keys()):
        if mline > prev_line:
            _render_marker(text, cf_by_line[mline])

    # Leaf inputs
    if result.inputs:
        text.append("\n  Leaf inputs: ", style="bold")
        text.append(", ".join(result.inputs), style="cyan")
        text.append("\n")

    return text


def _render_marker(text: Text, marker: ControlFlowMarker) -> None:
    """Render a control flow marker as a standalone annotation line."""
    if marker.kind == "diverge":
        text.append("  ┌─ IF ── ", style="bold cyan")
        text.append(marker.description, style="cyan")
        text.append(" ─" * 10 + "\n", style="cyan")
    elif marker.kind == "else":
        text.append("  ├─ ELSE ── ", style="bold cyan")
        text.append(marker.description, style="cyan")
        text.append(" ─" * 10 + "\n", style="cyan")
    elif marker.kind == "reconverge":
        text.append("  └─ RECONVERGE ── ", style="bold cyan")
        text.append(marker.description, style="cyan")
        text.append(" ─" * 10 + "\n", style="cyan")


def _build_cf_regions(markers: list[ControlFlowMarker]) -> list[tuple[int, int | None, int | None]]:
    """Extract (diverge_line, else_line, reconverge_line) tuples from markers."""
    regions = []
    diverge_line = None
    else_line = None
    for m in sorted(markers, key=lambda m: m.line):
        if m.kind == "diverge":
            diverge_line = m.line
            else_line = None
        elif m.kind == "else":
            else_line = m.line
        elif m.kind == "reconverge":
            if diverge_line is not None:
                regions.append((diverge_line, else_line, m.line))
            diverge_line = None
            else_line = None
    return regions


def _cf_prefix(line: int, cf_regions: list[tuple[int, int | None, int | None]]) -> str:
    """Determine the prefix for an instruction line based on CF regions."""
    for diverge, else_line, reconverge in cf_regions:
        if diverge is not None and reconverge is not None:
            if diverge < line < (reconverge if reconverge else float('inf')):
                return "  │ "
    return "  "
