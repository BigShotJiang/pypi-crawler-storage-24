"""Main instruction listing widget for the TUI."""

from __future__ import annotations

from rich.text import Text
from textual.widgets import Static
from textual.reactive import reactive

from isatrace.instruction import Instruction


def highlight_instruction(instr: Instruction, is_cursor: bool = False,
                          traced_lines: set[int] | None = None,
                          target_line: int | None = None) -> Text:
    """Syntax-highlight an instruction for display."""
    text = Text()

    # Line number
    line_str = f"{instr.line:>4}: "
    text.append(line_str, style="dim")

    # Build the instruction text
    if instr.is_label:
        text.append(instr.opcode + ":", style="bold yellow")
        return _apply_bg(text, is_cursor, traced_lines, target_line, instr.line)

    opcode = instr.opcode
    rest = instr.raw[len(opcode):] if instr.raw.startswith(opcode) else ""
    # Try to find the opcode in raw text
    idx = instr.raw.find(opcode)
    if idx > 0:
        text.append(instr.raw[:idx])
        rest = instr.raw[idx + len(opcode):]

    # Color the opcode by category
    opcode_style = _opcode_style(instr)
    text.append(opcode, style=opcode_style)

    # Operands
    if rest:
        text.append(rest, style="")

    return _apply_bg(text, is_cursor, traced_lines, target_line, instr.line)


def _opcode_style(instr: Instruction) -> str:
    if instr.category == "valu":
        return "bold cyan"
    elif instr.category == "salu":
        return "bold yellow"
    elif instr.category in ("smem", "vmem"):
        return "bold magenta"
    elif instr.category == "branch":
        return "bold green"
    elif instr.category == "export":
        return "bold red"
    elif instr.category == "interp":
        return "bold cyan"
    elif instr.category == "wait":
        return "dim"
    elif instr.category == "other":
        return "dim"
    return ""


def _apply_bg(text: Text, is_cursor: bool, traced_lines: set[int] | None,
              target_line: int | None, line: int) -> Text:
    if target_line and line == target_line:
        text.stylize("reverse bold")
    elif traced_lines and line in traced_lines:
        text.stylize("on dark_blue")
    if is_cursor:
        text.stylize("reverse")
    return text
