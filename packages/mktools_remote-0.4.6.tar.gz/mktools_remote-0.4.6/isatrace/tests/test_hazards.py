"""Tests for SCC/VCC hazard detection."""

from isatrace.hazards import find_hazards
from isatrace.parser import parse


class TestSCCHazards:
    def test_no_hazard_immediate_use(self):
        """SCC set and used immediately — no hazard."""
        text = """\
  s_cmp_eq_u32  s0, 0                                   // 000000000000: BF048000
  s_cbranch_scc1  label_target                           // 000000000004: BF850000
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'scc')
        assert len(hazards) == 0

    def test_hazard_clobbered(self):
        """SCC set, clobbered by s_add_u32, then read — hazard."""
        text = """\
  s_cmp_eq_u32  s0, 0                                   // 000000000000: BF048000
  s_add_u32     s1, s1, 1                               // 000000000004: 80018101
  s_cbranch_scc1  label_target                           // 000000000008: BF850000
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'scc')
        assert len(hazards) == 1
        h = hazards[0]
        assert h.setter.line == 1
        assert h.clobberer.line == 2
        assert h.consumer.line == 3
        assert h.register == 'scc'

    def test_no_hazard_reset_before_use(self):
        """SCC set, clobbered, set again, used — no hazard (fresh set)."""
        text = """\
  s_cmp_eq_u32  s0, 0                                   // 000000000000: BF048000
  s_add_u32     s1, s1, 1                               // 000000000004: 80018101
  s_cmp_eq_u32  s2, 0                                   // 000000000008: BF048200
  s_cbranch_scc1  label_target                           // 00000000000C: BF850000
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'scc')
        assert len(hazards) == 0

    def test_multiple_hazards(self):
        """Multiple SCC hazards in one block."""
        text = """\
  s_cmp_eq_u32  s0, 0                                   // 000000000000: BF048000
  s_add_u32     s1, s1, 1                               // 000000000004: 80018101
  s_cbranch_scc1  label_1                                // 000000000008: BF850000
  s_cmp_le_u32  s2, 3                                   // 00000000000C: BF0B8302
  s_and_b32     s3, s3, s4                              // 000000000010: 87030403
  s_cselect_b32  s5, s6, s7                             // 000000000014: 85050706
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'scc')
        assert len(hazards) == 2


class TestVCCHazards:
    def test_no_hazard_immediate_use(self):
        """VCC set and used immediately — no hazard."""
        text = """\
  v_cmp_gt_f32  vcc, v0, v1                             // 000000000000: 7C080100
  v_cndmask_b32  v2, v3, v4, vcc                        // 000000000004: D5010002 01AA0903
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'vcc')
        assert len(hazards) == 0

    def test_vcc_hazard_clobbered(self):
        """VCC set, clobbered by another v_cmp, then read — hazard."""
        text = """\
  v_cmp_gt_f32  vcc, v0, v1                             // 000000000000: 7C080100
  v_cmp_lt_f32  vcc, v2, v3                             // 000000000004: 7C020302
  v_cndmask_b32  v4, v5, v6, vcc                        // 000000000008: D5010004 01AA0D05
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'vcc')
        # The second v_cmp is an intentional setter, not a clobber.
        # So the first setter is replaced by the second, and no hazard.
        assert len(hazards) == 0

    def test_vcc_hazard_by_add_co(self):
        """VCC set by v_cmp, clobbered by v_add_co_u32, then read."""
        text = """\
  v_cmp_gt_f32  vcc, v0, v1                             // 000000000000: 7C080100
  v_add_co_u32  v10, vcc, v2, v3                        // 000000000004: D70A000A 00060702
  v_cndmask_b32  v4, v5, v6, vcc                        // 000000000008: D5010004 01AA0D05
"""
        instrs = parse(text)
        hazards = find_hazards(instrs, 'vcc')
        assert len(hazards) == 1
