"""Tests for control flow detection in slicer."""

from isatrace.slicer import Slicer


class TestControlFlowDetection:
    def test_simple_shader_6_cf_regions(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        # Should detect at least one control flow region
        assert len(slicer._cf_regions) >= 1
        region = slicer._cf_regions[0]
        assert region.save_line == 19       # s_mov_b64 s[2:3], exec
        assert region.diverge_line == 21    # v_cmpx_gt_f32
        assert region.else_line == 30       # s_andn2_b64
        assert region.reconverge_line == 40 # s_mov_b64 exec, s[2:3]
        assert region.saved_exec_reg == "s[2:3]"

    def test_trace_through_divergence(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        # Trace v6 — defined in both if-body (line 25) and else-body (line 35)
        result = slicer.trace("v6", line=41)
        lines = [i.line for i in result.chain]

        # The backward trace walks from line 41 backward.
        # At line 41, v_cvt_pkrtz reads v6. Walking backward, it finds:
        # Line 35: v_mul_f32 v6, s4, v0 (the else-path definition — reached first going backward)
        # This kills v6, so the trace stops there for v6.
        # The backward trace will find the most recent def of v6.
        # Since we walk backward from 41, we find line 35 first.
        assert 35 in lines

    def test_control_flow_markers_present(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        # When tracing through the divergence, markers should be generated
        result = slicer.trace("v6", line=41)
        # Control flow markers should be present if the chain includes CF instructions
        if any(i.line in (19, 21, 30, 40) for i in result.chain):
            assert len(result.control_flow) > 0


class TestSyntheticControlFlow:
    def test_saveexec_pattern(self):
        text = """\
  v_cmp_gt_f32  vcc, v0, 0                              // 000000000000: 7C080100
  s_and_saveexec_b64  s[2:3], vcc                       // 000000000004: BE822D6A
  v_mul_f32     v1, v0, 2.0                             // 000000000008: 10020100
  s_andn2_b64   exec, s[2:3], exec                      // 00000000000C: 8AFE7E02
  v_mul_f32     v1, v0, 0.5                             // 000000000010: 10020100
  s_mov_b64     exec, s[2:3]                            // 000000000014: BEFE0402
  v_add_f32     v2, v1, 1.0                             // 000000000018: 06040300
"""
        slicer = Slicer(text)
        assert len(slicer._cf_regions) >= 1

        # The saveexec pattern is detected
        # Note: the saveexec itself is the diverge point (it writes exec)
        # but we also need to detect the s_and_saveexec as saving exec
        regions = slicer._cf_regions
        region = regions[0]
        assert region.else_line == 4  # s_andn2_b64
        assert region.reconverge_line == 6  # s_mov_b64

    def test_cmpx_pattern(self):
        text = """\
  s_mov_b64     s[2:3], exec                            // 000000000000: BE82047E
  v_cmpx_gt_f32  exec, v1, s0                           // 000000000004: D414007E
  v_mul_f32     v6, s8, v1                              // 000000000008: 100C0208
  s_andn2_b64   exec, s[2:3], exec                      // 00000000000C: 8AFE7E02
  v_mul_f32     v6, s4, v0                              // 000000000010: 100C0004
  s_mov_b64     exec, s[2:3]                            // 000000000014: BEFE0402
"""
        slicer = Slicer(text)
        assert len(slicer._cf_regions) == 1
        region = slicer._cf_regions[0]
        assert region.save_line == 1
        assert region.diverge_line == 2
        assert region.else_line == 4
        assert region.reconverge_line == 6
