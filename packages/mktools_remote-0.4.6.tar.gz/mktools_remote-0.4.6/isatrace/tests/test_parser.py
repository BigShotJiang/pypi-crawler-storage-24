"""Tests for parser.py — RDNA disassembly parser."""

from isatrace.parser import parse


class TestBasicParsing:
    """Test that the parser handles basic line types correctly."""

    def test_empty_input(self):
        result = parse("")
        assert result == []

    def test_metadata_skipped(self):
        text = """\
; -------- Disassembly --------------------
shader main
  asic(GFX10_3)
  type(PS)
  sgpr_count(14)
  vgpr_count(8)
  wave_size(64)
"""
        result = parse(text)
        assert result == []

    def test_s_code_end_skipped(self):
        text = "  s_code_end                                            // 000000000048: BF9F0000"
        result = parse(text)
        assert result == []

    def test_end_keyword_skipped(self):
        text = "end"
        result = parse(text)
        assert result == []

    def test_label_parsed(self):
        text = "label_0058:"
        result = parse(text)
        assert len(result) == 1
        assert result[0].is_label
        assert result[0].opcode == "label_0058"

    def test_line_numbers_are_1_based(self):
        text = """\
; comment
shader main

  s_mov_b32     m0, s2                                  // 000000000008: BEFC0302
"""
        result = parse(text)
        assert len(result) == 1
        assert result[0].line == 4


class TestScalarALU:
    def test_s_mov_b32(self):
        text = "  s_mov_b32     m0, s2                                  // 000000000008: BEFC0302"
        result = parse(text)
        assert len(result) == 1
        instr = result[0]
        assert instr.opcode == "s_mov_b32"
        assert instr.defs == ["m0"]
        assert instr.uses == ["s2"]
        assert instr.is_scalar
        assert instr.category == "salu"
        # s_mov_b32 does NOT write SCC
        assert "scc" not in instr.implicit_defs

    def test_s_mov_b64_exec_save(self):
        text = "  s_mov_b64     s[2:3], exec                            // 00000000000C: BE82047E"
        result = parse(text)
        assert len(result) == 1
        instr = result[0]
        assert instr.defs == ["s[2:3]"]
        assert instr.uses == ["exec"]
        assert "scc" not in instr.implicit_defs  # s_mov_b64 has no SCC

    def test_s_and_b32_with_literal(self):
        text = "  s_and_b32     s1, lit(0x0fffffff), s7                 // 000000000028: 870107FF 0FFFFFFF"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_and_b32"
        assert instr.defs == ["s1"]
        assert instr.uses == ["s7"]  # lit(...) is a constant, not a register
        assert "scc" in instr.implicit_defs

    def test_s_cmp_le_u32(self):
        text = "  s_cmp_le_u32  s0, 3                                   // 000000000030: BF0B8300"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_cmp_le_u32"
        assert instr.defs == []  # no GPR dest
        assert instr.uses == ["s0"]  # 3 is a constant
        assert "scc" in instr.implicit_defs

    def test_s_cselect_b32(self):
        text = "  s_cselect_b32  s0, s1, s7                             // 000000000034: 85000701"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s0"]
        assert instr.uses == ["s1", "s7"]
        assert "scc" in instr.implicit_uses

    def test_s_lshr_b32(self):
        text = "  s_lshr_b32    s0, s7, 28                              // 00000000001C: 90009C07"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s0"]
        assert instr.uses == ["s7"]
        assert "scc" in instr.implicit_defs

    def test_s_mul_i32_no_scc(self):
        text = "  s_mul_i32     s0, s1, s2                              // 000000000000: 96000201"
        result = parse(text)
        instr = result[0]
        assert "scc" not in instr.implicit_defs

    def test_s_movk_i32_no_scc(self):
        text = "  s_movk_i32    s1, 0x3000                              // 000000000000: B0013000"
        result = parse(text)
        instr = result[0]
        assert "scc" not in instr.implicit_defs

    def test_s_wqm_b64_exec(self):
        text = "  s_wqm_b64     exec, exec                              // 000000000010: BEFE0A7E"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["exec"]
        assert instr.uses == ["exec"]
        assert "scc" in instr.implicit_defs

    def test_s_andn2_b64_exec(self):
        text = "  s_andn2_b64   exec, s[2:3], exec                      // 000000000058: 8AFE7E02"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["exec"]
        assert "s[2:3]" in instr.uses
        assert "exec" in instr.uses
        assert "scc" in instr.implicit_defs

    def test_s_getpc_b64(self):
        text = "  s_getpc_b64   s[0:1]                                  // 000000000008: BE801F80"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s[0:1]"]
        assert instr.uses == []


class TestScalarMemory:
    def test_s_buffer_load_dword(self):
        text = "  s_buffer_load_dword  s0, s[4:7], null                 // 00000000000C: F4200002 FA000000"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_buffer_load_dword"
        assert instr.defs == ["s0"]
        assert instr.uses == ["s[4:7]"]
        assert instr.category == "smem"
        assert instr.is_memory

    def test_s_buffer_load_dwordx8(self):
        text = "  s_buffer_load_dwordx8  s[8:15], s[4:7], 0x000010      // 00000000000C: F42C0202 FA000010"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s[8:15]"]
        assert instr.uses == ["s[4:7]"]

    def test_s_load_dwordx4(self):
        text = "  s_load_dwordx4  s[0:3], s[0:1], null                  // 000000000010: F4080000 FA000000"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s[0:3]"]
        assert instr.uses == ["s[0:1]"]

    def test_s_load_b256_gfx11(self):
        text = "  s_load_b256   s[4:11], s[4:5], null                   // 000000000030: F40C0102 F8000000"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s[4:11]"]
        assert instr.uses == ["s[4:5]"]


class TestVectorALU:
    def test_v_mul_f32(self):
        text = "  v_mul_f32     v1, v2, v0                              // 000000000034: 10020502"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "v_mul_f32"
        assert instr.defs == ["v1"]
        assert instr.uses == ["v2", "v0"]
        assert instr.is_vector
        assert instr.category == "valu"

    def test_v_add_f32_with_constant(self):
        text = "  v_add_f32     v2, -0.5, v2                            // 00000000002C: 060404F1"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v2"]
        assert instr.uses == ["v2"]  # -0.5 is a constant

    def test_v_fmac_f32_accumulate(self):
        text = "  v_fmac_f32    v1, v3, v3                              // 000000000038: 56020703"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v1"]
        assert "v3" in instr.uses
        assert "v1" in instr.uses  # dest is also a source for fmac

    def test_v_fmamk_f32(self):
        text = "  v_fmamk_f32   v0, v5, lit(0x3e99999a), v0             // 0000000000A4: 58000105 3E99999A"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v0"]
        assert "v5" in instr.uses
        assert "v0" in instr.uses  # dest appears as last source

    def test_v_fma_f32_neg_modifier(self):
        text = "  v_fma_f32     v5, -v0, s1, v4                         // 000000000080: D54B0005 24100300"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v5"]
        assert "v0" in instr.uses  # neg stripped
        assert "s1" in instr.uses
        assert "v4" in instr.uses

    def test_v_cvt_pkrtz_f16_f32(self):
        text = "  v_cvt_pkrtz_f16_f32  v1, v2, v3                       // 00000000002C: 5E020702"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v1"]
        assert instr.uses == ["v2", "v3"]

    def test_v_cvt_pk_rtz_f16_f32_gfx11(self):
        text = "  v_cvt_pk_rtz_f16_f32  v0, v0, v1                      // 00000000007C: 5E000300"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v0"]
        assert "v0" in instr.uses
        assert "v1" in instr.uses

    def test_v_sqrt_f32(self):
        text = "  v_sqrt_f32    v0, v1                                  // 00000000003C: 7E006701"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v0"]
        assert instr.uses == ["v1"]


class TestVectorCompare:
    def test_v_cmp_gt_f32_vcc(self):
        text = "  v_cmp_gt_f32  vcc, s0, v0                             // 000000000050: 7C080000"
        result = parse(text)
        instr = result[0]
        assert instr.defs == []  # VCC is implicit
        assert "vcc" in instr.implicit_defs
        assert "s0" in instr.uses
        assert "v0" in instr.uses

    def test_v_cmpx_gt_f32(self):
        text = "  v_cmpx_gt_f32  exec, v1, s0                           // 000000000030: D414007E 00000101"
        result = parse(text)
        instr = result[0]
        assert "exec" in instr.implicit_defs
        assert "v1" in instr.uses
        assert "s0" in instr.uses
        assert "exec" not in instr.uses  # exec in operand is dest, not source

    def test_v_cndmask_b32_explicit_vcc(self):
        text = "  v_cndmask_b32  v0, s12, v1, vcc                       // 000000000054: D5010000 01AA020C"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v0"]
        assert "s12" in instr.uses
        assert "v1" in instr.uses
        assert "vcc" in instr.uses
        # VCC is explicit in sources, so no implicit use
        assert "vcc" not in instr.implicit_uses


class TestSaveexec:
    def test_s_and_saveexec_b64(self):
        text = "  s_and_saveexec_b64  s[2:3], vcc                       // 000000000000: BE822D6A"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["s[2:3]"]
        assert "vcc" in instr.uses
        assert "exec" in instr.implicit_defs
        assert "scc" in instr.implicit_defs
        assert "exec" in instr.implicit_uses


class TestMemory:
    def test_tbuffer_load(self):
        text = "  tbuffer_load_format_xyzw  v[0:3], v0, s[0:3], 0 idxen format:[BUF_FMT_32_32_32_32_FLOAT] // 000000000020: EA6B2000 80000000"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v[0:3]"]
        assert "v0" in instr.uses
        assert "s[0:3]" in instr.uses
        assert instr.category == "vmem"

    def test_image_sample(self):
        text = "  image_sample  v[0:3], [v2,v0], s[4:11], s[12:15] dmask:0xf dim:SQ_RSRC_IMG_2D // 000000000050: F0800F0A 00610002 00000000"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v[0:3]"]
        assert "v2" in instr.uses
        assert "v0" in instr.uses
        assert "s[4:11]" in instr.uses
        assert "s[12:15]" in instr.uses
        assert instr.category == "vmem"


class TestExport:
    def test_exp_mrt0(self):
        text = "  exp           mrt0, v1, v1, v5, v5 done compr vm      // 00000000003C: F8001C0F 00000501"
        result = parse(text)
        instr = result[0]
        assert instr.is_export
        assert instr.defs == ["mrt0"]
        assert "v1" in instr.uses
        assert "v5" in instr.uses
        # Deduplicated — v1 and v5 appear once each
        assert instr.uses == ["v1", "v5"]

    def test_exp_with_off_gfx11(self):
        text = "  exp           mrt0, v0, v2, off, off done             // 000000000088: F8000803 00000200"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["mrt0"]
        assert "v0" in instr.uses
        assert "v2" in instr.uses


class TestInterpolation:
    def test_v_interp_p1_f32(self):
        text = "  v_interp_p1_f32  v2, v0, attr0.x                      // 00000000000C: C8080000"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v2"]
        assert "v0" in instr.uses
        assert instr.category == "interp"

    def test_v_interp_p2_f32(self):
        text = "  v_interp_p2_f32  v2, v1, attr0.x                      // 00000000001C: C8090001"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v2"]
        assert "v1" in instr.uses

    def test_lds_param_load_gfx11(self):
        text = "  lds_param_load  v2, attr0.x wait_vdst:0               // 00000000001C: CE000002"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v2"]
        assert instr.category == "interp"

    def test_v_interp_p10_f32_gfx11(self):
        text = "  v_interp_p10_f32  v4, v2, v0, v2 wait_exp:1           // 000000000040: CD000104 040A0102"
        result = parse(text)
        instr = result[0]
        assert instr.defs == ["v4"]
        assert "v2" in instr.uses
        assert "v0" in instr.uses


class TestBranch:
    def test_s_cbranch_execz(self):
        text = "  s_cbranch_execz  label_0058                           // 000000000038: BF880007"
        result = parse(text)
        instr = result[0]
        assert instr.is_branch
        assert "exec" in instr.implicit_uses

    def test_s_cbranch_scc1(self):
        text = "  s_cbranch_scc1  label_target                          // 000000000000: BF850000"
        result = parse(text)
        instr = result[0]
        assert "scc" in instr.implicit_uses

    def test_s_cbranch_vccnz(self):
        text = "  s_cbranch_vccnz  label_target                         // 000000000000: BF860000"
        result = parse(text)
        instr = result[0]
        assert "vcc" in instr.implicit_uses


class TestWait:
    def test_s_waitcnt(self):
        text = "  s_waitcnt     lgkmcnt(0)                              // 000000000040: BF8CC07F"
        result = parse(text)
        instr = result[0]
        assert instr.is_wait
        assert instr.defs == []
        assert instr.uses == []

    def test_s_nop(self):
        text = "  s_nop         0x0000                                  // 000000000034: BF800000"
        result = parse(text)
        instr = result[0]
        assert instr.is_wait

    def test_s_delay_alu_gfx11(self):
        text = "                                                        s_delay_alu  instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) // 000000000050: BF870112"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_delay_alu"
        assert instr.category == "other"


class TestMetadata:
    def test_s_version(self):
        text = "  s_version     UC_VERSION_GFX10 | UC_VERSION_W64_BIT   // 000000000000: B0802004"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_version"
        assert instr.category == "other"

    def test_s_inst_prefetch(self):
        text = "  s_inst_prefetch  0x0003                               // 000000000004: BFA00003"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_inst_prefetch"

    def test_s_endpgm(self):
        text = "  s_endpgm                                              // 000000000044: BF810000"
        result = parse(text)
        instr = result[0]
        assert instr.opcode == "s_endpgm"


class TestFixtureFiles:
    """Test parsing of actual fixture files."""

    def test_simple_shader_1(self, simple_shader_1):
        instructions = parse(simple_shader_1)
        # Filter out metadata/wait/endpgm
        real_instrs = [i for i in instructions if i.category not in ('other', 'wait')]
        # Should have: 1 s_mov + 8 interp + 2 cvt + 1 exp = 12 instructions
        assert len(real_instrs) == 12

        # Verify specific instructions
        interp1 = next(i for i in instructions if i.line == 13)
        assert interp1.opcode == "v_interp_p1_f32"
        assert interp1.defs == ["v2"]
        assert "v0" in interp1.uses

        exp_instr = next(i for i in instructions if i.line == 25)
        assert exp_instr.is_export
        assert exp_instr.defs == ["mrt0"]
        assert "v1" in exp_instr.uses
        assert "v5" in exp_instr.uses

    def test_simple_shader_3_vcc_chain(self, simple_shader_3):
        instructions = parse(simple_shader_3)

        # v_cmp_gt_f32 vcc, s0, v0  (line 28)
        v_cmp = next(i for i in instructions if i.line == 28)
        assert v_cmp.opcode == "v_cmp_gt_f32"
        assert "vcc" in v_cmp.implicit_defs
        assert "s0" in v_cmp.uses
        assert "v0" in v_cmp.uses

        # v_cndmask_b32 v0, s12, v1, vcc  (line 29)
        v_cnd = next(i for i in instructions if i.line == 29)
        assert v_cnd.defs == ["v0"]
        assert "s12" in v_cnd.uses
        assert "v1" in v_cnd.uses
        assert "vcc" in v_cnd.uses

        # v_fmac_f32 v1, v3, v3  (line 22)
        v_fmac = next(i for i in instructions if i.line == 22)
        assert v_fmac.defs == ["v1"]
        assert "v3" in v_fmac.uses
        assert "v1" in v_fmac.uses  # accumulate

    def test_simple_shader_4_scc_chain(self, simple_shader_4):
        instructions = parse(simple_shader_4)

        # s_cmp_le_u32 s0, 3  (line 21)
        s_cmp = next(i for i in instructions if i.line == 21)
        assert s_cmp.opcode == "s_cmp_le_u32"
        assert "scc" in s_cmp.implicit_defs
        assert "s0" in s_cmp.uses

        # s_cselect_b32 s0, s1, s7  (line 22)
        s_csel = next(i for i in instructions if i.line == 22)
        assert "scc" in s_csel.implicit_uses
        assert s_csel.defs == ["s0"]

        # image_sample v[0:3], [v2,v0], s[4:11], s[12:15]  (line 27)
        img = next(i for i in instructions if i.line == 27)
        assert img.defs == ["v[0:3]"]
        assert "v2" in img.uses
        assert "v0" in img.uses
        assert "s[4:11]" in img.uses
        assert "s[12:15]" in img.uses

    def test_simple_shader_6_control_flow(self, simple_shader_6):
        instructions = parse(simple_shader_6)

        # s_mov_b64 s[2:3], exec  (line 19)
        save_exec = next(i for i in instructions if i.line == 19)
        assert save_exec.defs == ["s[2:3]"]
        assert "exec" in save_exec.uses

        # v_cmpx_gt_f32 exec, v1, s0  (line 21)
        v_cmpx = next(i for i in instructions if i.line == 21)
        assert "exec" in v_cmpx.implicit_defs
        assert "v1" in v_cmpx.uses
        assert "s0" in v_cmpx.uses

        # label_0058:  (line 29)
        label = next(i for i in instructions if i.line == 29)
        assert label.is_label
        assert label.opcode == "label_0058"

        # s_andn2_b64 exec, s[2:3], exec  (line 30)
        andn2 = next(i for i in instructions if i.line == 30)
        assert andn2.defs == ["exec"]
        assert "s[2:3]" in andn2.uses
        assert "exec" in andn2.uses

        # s_mov_b64 exec, s[2:3]  (line 40)
        restore = next(i for i in instructions if i.line == 40)
        assert restore.defs == ["exec"]
        assert "s[2:3]" in restore.uses

    def test_boogy90_1(self, boogy90_1):
        instructions = parse(boogy90_1)

        # tbuffer_load_format_xyzw v[0:3], v0, s[0:3], 0 idxen  (line 8)
        tbuf = next(i for i in instructions if i.line == 8)
        assert tbuf.defs == ["v[0:3]"]
        assert "v0" in tbuf.uses
        assert "s[0:3]" in tbuf.uses

        # exp mrt0  (line 12)
        exp_instr = next(i for i in instructions if i.line == 12)
        assert exp_instr.is_export
        assert exp_instr.defs == ["mrt0"]

    def test_gpuopen_1_gfx11(self, gpuopen_1):
        instructions = parse(gpuopen_1)

        # lds_param_load v2, attr0.x  (line 16)
        lds = next(i for i in instructions if i.line == 16)
        assert lds.opcode == "lds_param_load"
        assert lds.defs == ["v2"]

        # v_interp_p10_f32 v4, v2, v0, v2  (line 23)
        interp = next(i for i in instructions if i.line == 23)
        assert interp.defs == ["v4"]
        assert "v2" in interp.uses
        assert "v0" in interp.uses

        # s_delay_alu  (line 25)
        delay = next(i for i in instructions if i.opcode == "s_delay_alu")
        assert delay.category == "other"

        # image_sample with bracket coords (line 30)
        img = next(i for i in instructions if i.line == 30)
        assert img.defs == ["v[0:3]"]
        assert "v2" in img.uses
        assert "v0" in img.uses

    def test_all_fixtures_parse_without_error(self, any_fixture):
        """Every fixture file should parse without raising exceptions."""
        instructions = parse(any_fixture)
        assert isinstance(instructions, list)
        # Every fixture should produce at least some instructions
        assert len(instructions) > 0
