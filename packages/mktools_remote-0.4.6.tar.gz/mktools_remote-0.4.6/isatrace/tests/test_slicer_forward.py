"""Tests for forward slicing."""

from isatrace.slicer import Slicer


SYNTHETIC = """\
  v_mov_b32     v0, s0                                  // 000000000000: 7E000200
  v_mul_f32     v1, v0, v0                              // 000000000004: 10020100
  v_add_f32     v2, v1, 1.0                             // 000000000008: 06040300
  v_mul_f32     v3, v0, v2                              // 00000000000C: 10060500
"""


class TestForwardTrace:
    def test_forward_from_def(self):
        slicer = Slicer(SYNTHETIC)
        result = slicer.forward_trace("v0", line=1)
        lines = [i.line for i in result.chain]
        # v0 defined at line 1, used at lines 2 and 4
        assert 1 in lines  # def
        assert 2 in lines  # use
        assert 4 in lines  # use

    def test_forward_stops_at_redef(self):
        text = """\
  v_mov_b32     v0, s0                                  // 000000000000: 7E000200
  v_mul_f32     v1, v0, v0                              // 000000000004: 10020100
  v_mov_b32     v0, s1                                  // 000000000008: 7E000201
  v_add_f32     v2, v0, v1                              // 00000000000C: 06040300
"""
        slicer = Slicer(text)
        result = slicer.forward_trace("v0", line=1)
        lines = [i.line for i in result.chain]
        assert 1 in lines  # def
        assert 2 in lines  # use before redef
        # Line 4 uses v0 but from the redef at line 3, not the original
        assert 4 not in lines
