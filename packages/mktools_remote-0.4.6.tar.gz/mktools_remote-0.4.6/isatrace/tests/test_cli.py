"""Tests for CLI mode."""

from __future__ import annotations

import pathlib
import subprocess
import sys
import tempfile

import pytest

FIXTURES_DIR = pathlib.Path(__file__).parent.parent / "rdna-dump-collection"


def run_cli(*args: str, expect_error: bool = False) -> str:
    """Run isatrace CLI and return stdout."""
    result = subprocess.run(
        [sys.executable, "-m", "isatrace.cli", *args],
        capture_output=True, text=True, timeout=30,
    )
    if not expect_error:
        assert result.returncode == 0, f"CLI failed: {result.stderr}"
    return result.stdout


class TestCLITrace:
    def test_trace_v1_simple_shader_1(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        output = run_cli(f, "--trace", "v1", "--line", "21")
        assert "TRACE" in output
        assert "v1" in output
        # Should contain line numbers from the golden trace
        assert "13:" in output
        assert "21:" in output

    def test_trace_mrt0(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        output = run_cli(f, "--trace", "mrt0")
        assert "TRACE" in output
        assert "mrt0" in output
        assert "exp" in output

    def test_trace_with_control_flow(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-6.txt")
        output = run_cli(f, "--trace", "v6", "--line", "41")
        assert "TRACE" in output
        # Should show both if-path and else-path definitions
        assert "25:" in output
        assert "35:" in output

    def test_trace_to_file(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode='w') as tmp:
            tmp_path = tmp.name
        run_cli(f, "--trace", "v1", "--line", "21", "--output", tmp_path)
        content = pathlib.Path(tmp_path).read_text()
        assert "TRACE" in content
        pathlib.Path(tmp_path).unlink()


class TestCLIDefs:
    def test_defs(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        output = run_cli(f, "--defs", "v2")
        assert "Definitions" in output
        assert "v_interp" in output

    def test_defs_no_results(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        output = run_cli(f, "--defs", "v99")
        assert "No definitions" in output


class TestCLIUses:
    def test_uses(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        output = run_cli(f, "--uses", "v0")
        assert "Uses" in output


class TestCLIHazards:
    def test_scc_hazards(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")
        output = run_cli(f, "--hazards", "scc")
        # This fixture may or may not have hazards
        assert "SCC" in output

    def test_vcc_hazards(self):
        f = str(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-3.txt")
        output = run_cli(f, "--hazards", "vcc")
        assert "VCC" in output


class TestCLIAllFixtures:
    @pytest.fixture(params=sorted(FIXTURES_DIR.rglob("*.txt")),
                    ids=[str(p.relative_to(FIXTURES_DIR))
                         for p in sorted(FIXTURES_DIR.rglob("*.txt"))])
    def fixture_file(self, request: pytest.FixtureRequest) -> str:
        return str(request.param)

    def test_trace_mrt0_all_fixtures(self, fixture_file):
        """Every fixture should produce valid output for --trace mrt0."""
        output = run_cli(fixture_file, "--trace", "mrt0")
        assert "TRACE" in output or "Error" in output
