"""Tests for implicit dependency tracking through SCC, VCC, and EXEC."""

from isatrace.slicer import Slicer


class TestSCCImplicitDeps:
    def test_scc_chain_cmp_to_cselect(self):
        """s_cmp sets SCC, s_cselect reads SCC — trace should connect them."""
        text = """\
  s_mov_b32     s0, s4                                  // 000000000000: BE800304
  s_cmp_le_u32  s0, 3                                   // 000000000004: BF0B8300
  s_cselect_b32  s1, s2, s3                             // 000000000008: 85010302
"""
        slicer = Slicer(text)
        result = slicer.trace("s1", line=3)
        lines = [i.line for i in result.chain]
        assert 2 in lines  # s_cmp sets SCC
        assert 3 in lines  # s_cselect reads SCC
        # s_cmp reads s0, which is defined at line 1
        assert 1 in lines

    def test_scc_chain_cmp_to_branch(self):
        text = """\
  s_cmp_eq_u32  s0, 0                                   // 000000000000: BF048000
  s_cbranch_scc1  label_target                           // 000000000004: BF850000
"""
        slicer = Slicer(text)
        result = slicer.trace("scc", line=2)
        lines = [i.line for i in result.chain]
        assert 1 in lines


class TestVCCImplicitDeps:
    def test_vcc_chain_cmp_to_cndmask(self):
        """v_cmp writes VCC, v_cndmask reads VCC — trace should connect them."""
        text = """\
  v_mov_b32     v0, s0                                  // 000000000000: 7E000200
  v_cmp_gt_f32  vcc, v0, 0                              // 000000000004: 7C080100
  v_cndmask_b32  v1, v2, v3, vcc                        // 000000000008: D5010001 01AA0702
"""
        slicer = Slicer(text)
        result = slicer.trace("v1", line=3)
        lines = [i.line for i in result.chain]
        assert 2 in lines  # v_cmp sets VCC
        assert 3 in lines  # v_cndmask uses VCC
        assert 1 in lines  # v_cmp uses v0 which is defined at line 1

    def test_vcc_implicit_in_cndmask_no_explicit(self):
        """v_cndmask_b32 without explicit vcc uses it implicitly."""
        text = """\
  v_cmp_gt_f32  vcc, v0, v1                             // 000000000000: 7C080100
  v_cndmask_b32  v2, v3, v4                             // 000000000004: D5010002 01AA0903
"""
        slicer = Slicer(text)
        result = slicer.trace("v2", line=2)
        lines = [i.line for i in result.chain]
        # VCC is implicit use for cndmask when not explicitly specified
        assert 1 in lines  # v_cmp sets VCC


class TestAccumulateImplicitDeps:
    def test_fmac_dest_is_source(self):
        """v_fmac_f32 v1, v3, v3 means v1 += v3*v3 — v1 is also a source."""
        text = """\
  v_mov_b32     v1, 0                                   // 000000000000: 7E020280
  v_mov_b32     v3, s0                                  // 000000000004: 7E060200
  v_fmac_f32    v1, v3, v3                              // 000000000008: 56020703
"""
        slicer = Slicer(text)
        result = slicer.trace("v1", line=3)
        lines = [i.line for i in result.chain]
        assert 1 in lines  # v1 is accumulated, so its prior value matters
        assert 2 in lines  # v3 is a source
        assert 3 in lines  # the fmac itself
