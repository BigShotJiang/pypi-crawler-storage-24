"""Tests for backward slicing."""

from isatrace.slicer import Slicer


# ── Synthetic test fixtures ────────────────────────────────────────────────

SYNTHETIC_LINEAR = """\
  v_mov_b32     v0, s0                                  // 000000000000: 7E000200
  v_mul_f32     v1, v0, v0                              // 000000000004: 10020100
  v_add_f32     v2, v1, 1.0                             // 000000000008: 06040300
"""

SYNTHETIC_FORKED = """\
  v_mov_b32     v0, s0                                  // 000000000000: 7E000200
  v_mov_b32     v1, s1                                  // 000000000004: 7E020201
  v_add_f32     v2, v0, v1                              // 000000000008: 06040300
"""

SYNTHETIC_REGISTER_REUSE = """\
  v_mov_b32     v5, 0                                   // 000000000000: 7E0A0280
  v_add_f32     v0, v5, v1                              // 000000000004: 06000300
  v_mov_b32     v5, v2                                  // 000000000008: 7E0A0302
  v_mul_f32     v3, v5, v4                              // 00000000000C: 10060905
"""

SYNTHETIC_DEEP_INTERLEAVED = """\
  v_mov_b32     v0, s0                                  // 000000000000: 7E000200
  v_mov_b32     v10, s5                                 // 000000000004: 7E140205
  v_mul_f32     v1, v0, v0                              // 000000000008: 10020100
  v_mul_f32     v11, v10, v10                           // 00000000000C: 1016150A
  v_add_f32     v2, v1, 1.0                             // 000000000010: 06040300
  v_add_f32     v12, v11, 1.0                           // 000000000014: 06181700
  v_mul_f32     v3, v2, v0                              // 000000000018: 10060100
"""

SYNTHETIC_SCC_CHAIN = """\
  s_cmp_eq_u32  s0, 0                                   // 000000000000: BF048000
  s_cbranch_scc1  label_target                           // 000000000004: BF850000
"""

SYNTHETIC_VCC_CHAIN = """\
  v_cmp_gt_f32  vcc, v0, v1                             // 000000000000: 7C080100
  v_cndmask_b32  v2, v3, v4, vcc                        // 000000000004: D5010002 01AA0903
"""

SYNTHETIC_INTEGER_CHAIN = """\
  v_and_b32     v2, 0xFF, v0                            // 000000000000: 360400FF
  v_lshlrev_b32 v3, 8, v1                               // 000000000004: 34060208
  v_or_b32      v4, v2, v3                              // 000000000008: 38080702
  v_add_u32     v5, v4, v0                              // 00000000000C: 680A0104
"""

SYNTHETIC_SAVEEXEC_DIVERGE = """\
  v_cmp_gt_f32  vcc, v0, 0                              // 000000000000: 7C080100
  s_and_saveexec_b64  s[2:3], vcc                       // 000000000004: BE822D6A
  v_mul_f32     v1, v0, 2.0                             // 000000000008: 10020100
  s_andn2_b64   exec, s[2:3], exec                      // 00000000000C: 8AFE7E02
  v_mul_f32     v1, v0, 0.5                             // 000000000010: 10020100
  s_mov_b64     exec, s[2:3]                            // 000000000014: BEFE0402
  v_add_f32     v2, v1, 1.0                             // 000000000018: 06040300
"""


class TestLinearChain:
    def test_simple_chain(self):
        slicer = Slicer(SYNTHETIC_LINEAR)
        result = slicer.trace("v2", line=3)
        lines = [i.line for i in result.chain]
        assert lines == [1, 2, 3]

    def test_leaf_inputs(self):
        slicer = Slicer(SYNTHETIC_LINEAR)
        result = slicer.trace("v2", line=3)
        assert "s0" in result.inputs


class TestForkedDeps:
    def test_two_sources_merge(self):
        slicer = Slicer(SYNTHETIC_FORKED)
        result = slicer.trace("v2", line=3)
        lines = [i.line for i in result.chain]
        assert lines == [1, 2, 3]
        assert "s0" in result.inputs
        assert "s1" in result.inputs


class TestRegisterReuse:
    def test_kill_semantics(self):
        """Tracing v3 at line 4 should NOT include line 1 (v5 is killed at line 3)."""
        slicer = Slicer(SYNTHETIC_REGISTER_REUSE)
        result = slicer.trace("v3", line=4)
        lines = [i.line for i in result.chain]
        assert 1 not in lines  # first v5 def should be excluded
        assert 3 in lines      # second v5 def
        assert 4 in lines      # target instruction
        assert "v2" in result.inputs
        assert "v4" in result.inputs


class TestDeepInterleaved:
    def test_excludes_unrelated_chain(self):
        """Trace v3 at line 7: should only include lines 1, 3, 5, 7."""
        slicer = Slicer(SYNTHETIC_DEEP_INTERLEAVED)
        result = slicer.trace("v3", line=7)
        lines = [i.line for i in result.chain]
        assert lines == [1, 3, 5, 7]
        assert "s0" in result.inputs


class TestSCCChain:
    def test_scc_traced_through_branch(self):
        slicer = Slicer(SYNTHETIC_SCC_CHAIN)
        result = slicer.trace("scc", line=2)
        lines = [i.line for i in result.chain]
        assert 1 in lines  # s_cmp sets SCC


class TestVCCChain:
    def test_vcc_traced_through_cndmask(self):
        slicer = Slicer(SYNTHETIC_VCC_CHAIN)
        result = slicer.trace("v2", line=2)
        lines = [i.line for i in result.chain]
        assert 1 in lines  # v_cmp sets VCC
        assert 2 in lines  # v_cndmask uses VCC


class TestIntegerChain:
    def test_full_chain(self):
        slicer = Slicer(SYNTHETIC_INTEGER_CHAIN)
        result = slicer.trace("v5", line=4)
        lines = [i.line for i in result.chain]
        assert lines == [1, 2, 3, 4]
        assert "v0" in result.inputs
        assert "v1" in result.inputs


class TestConstantTermination:
    def test_stops_at_literals(self):
        slicer = Slicer(SYNTHETIC_LINEAR)
        result = slicer.trace("v2", line=3)
        # 1.0 is a constant, v0 traces back to s0 which is a leaf
        assert "s0" in result.inputs


class TestDefsAndUses:
    def test_defs(self):
        slicer = Slicer(SYNTHETIC_REGISTER_REUSE)
        v5_defs = slicer.defs("v5")
        assert len(v5_defs) == 2
        assert v5_defs[0].line == 1
        assert v5_defs[1].line == 3

    def test_uses(self):
        slicer = Slicer(SYNTHETIC_REGISTER_REUSE)
        v5_uses = slicer.uses("v5")
        assert len(v5_uses) == 2  # line 2 and line 4


class TestSaveexecDivergence:
    def test_both_paths_included(self):
        slicer = Slicer(SYNTHETIC_SAVEEXEC_DIVERGE)
        result = slicer.trace("v2", line=7)
        lines = [i.line for i in result.chain]
        # v2 uses v1, which is defined at lines 3 (if-path) and 5 (else-path)
        # Both should be included since we can't know which lanes are active
        assert 3 in lines or 5 in lines
        # v0 is a source for both muls
        assert 7 in lines  # target


class TestRealFixtures:
    def test_simple_shader_1_trace_mrt0(self, simple_shader_1):
        slicer = Slicer(simple_shader_1)
        result = slicer.trace("mrt0")
        assert result.target.is_export
        assert len(result.chain) > 1

    def test_simple_shader_3_vcc_chain(self, simple_shader_3):
        slicer = Slicer(simple_shader_3)
        # Trace v0 at line 29 (v_cndmask_b32 v0, s12, v1, vcc)
        result = slicer.trace("v0", line=29)
        lines = [i.line for i in result.chain]
        # Should include the v_cmp that writes VCC (line 28)
        assert 28 in lines
        assert 29 in lines

    def test_simple_shader_6_control_flow(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        # Trace v6 from line 41 (v_cvt_pkrtz at line 41 uses v6)
        result = slicer.trace("v6", line=41)
        lines = [i.line for i in result.chain]
        # v6 is defined at line 25 (if-path) and line 35 (else-path)
        assert 25 in lines or 35 in lines


class TestBackwardTraceNeverIncludesFutureLines:
    """Bug 1 regression: backward trace must never include lines after the target."""

    def test_trace_v6_at_25_excludes_line_35(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=25)
        lines = [i.line for i in result.chain]
        assert 35 not in lines, "Line 35 is after target line 25"
        assert all(l <= 25 for l in lines), (
            f"All lines must be <= 25, got: {[l for l in lines if l > 25]}")

    def test_trace_v6_at_35_excludes_future_lines(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=35)
        lines = [i.line for i in result.chain]
        assert all(l <= 35 for l in lines), (
            f"All lines must be <= 35, got: {[l for l in lines if l > 35]}")
        # Line 25 is NOT included — it's the IF-path sibling def of v6,
        # not a dependency for the ELSE-path def at line 35
        assert 25 not in lines, (
            "Line 25 (IF-path def) should NOT be in ELSE-path trace")

    def test_trace_v6_no_line_excludes_future_lines(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6")
        # Last def is at line 35
        assert result.target.line == 35
        lines = [i.line for i in result.chain]
        assert all(l <= 35 for l in lines), (
            f"All lines must be <= 35, got: {[l for l in lines if l > 35]}")


class TestExecMaskAwareDefResolution:
    """Bug 3 regression: vector defs in the opposite CF branch must be skipped."""

    def test_else_path_trace_excludes_if_block_deps(self, simple_shader_6):
        """Tracing v6 at line 35 (ELSE path) must NOT include IF-block instructions."""
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=35)
        lines = [i.line for i in result.chain]
        # Lines 23, 25, 27 are IF-block instructions — must be absent
        assert 23 not in lines, "IF-block s_buffer_load (line 23) should not be in ELSE trace"
        assert 25 not in lines, "IF-block v_mul v6 (line 25) should not be in ELSE trace"
        assert 27 not in lines, "IF-block v_mul v2 (line 27) should not be in ELSE trace"
        # Line 16 (v_interp_p2 v2, pre-branch) IS the correct source of v2 for ELSE lanes
        assert 16 in lines, "Pre-branch v_interp_p2 v2 (line 16) should be in ELSE trace"
        # ELSE-block instructions should be present
        assert 32 in lines, "ELSE s_buffer_load (line 32) should be in trace"
        assert 33 in lines, "ELSE v_fma v0 (line 33) should be in trace"
        assert 35 in lines, "Target v_mul v6 (line 35) should be in trace"

    def test_if_path_trace_excludes_else_block_deps(self, simple_shader_6):
        """Tracing v6 at line 25 (IF path) must NOT include ELSE-block instructions."""
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=25)
        lines = [i.line for i in result.chain]
        # No ELSE-block instructions (all at lines 30-39)
        assert not any(30 <= l <= 39 for l in lines), (
            "ELSE-block instructions should not appear when tracing from IF path")
        # IF-block and pre-branch deps should be present
        assert 25 in lines
        assert 23 in lines, "IF s_buffer_load (line 23) should be in trace"
        assert 18 in lines, "Pre-branch v_mul v1 (line 18) should be in trace"

    def test_post_reconverge_trace_includes_both_paths(self, simple_shader_6):
        """Tracing v6 at line 41 (after reconverge) must include both IF and ELSE defs."""
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=41)
        lines = [i.line for i in result.chain]
        assert 25 in lines, "IF-path def of v6 should be in post-reconverge trace"
        assert 35 in lines, "ELSE-path def of v6 should be in post-reconverge trace"
        # But v2's IF-block def (line 27) should NOT be pulled in — v2's consumer
        # at line 33 is in ELSE, so line 27 (IF block) is invisible to it
        assert 27 not in lines, "IF-block v2 def (line 27) should not be in trace"
        # v2 should resolve to pre-branch def (line 16) for ELSE consumers
        assert 16 in lines, "Pre-branch v_interp_p2 v2 (line 16) should be in trace"

    def test_else_path_trace_has_cf_markers(self, simple_shader_6):
        """ELSE-only trace should still have CF markers for structural context."""
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=35)
        marker_kinds = [m.kind for m in result.control_flow]
        assert "diverge" in marker_kinds, "Missing diverge marker"
        assert "else" in marker_kinds, "Missing else marker"
        assert "reconverge" in marker_kinds, "Missing reconverge marker"


class TestControlFlowMarkers:
    """Bug 2 regression: trace through CF regions must have proper markers."""

    def test_trace_v6_at_35_has_cf_markers(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=35)
        marker_kinds = [m.kind for m in result.control_flow]
        assert "diverge" in marker_kinds, "Missing diverge marker"
        assert "else" in marker_kinds, "Missing else marker"
        assert "reconverge" in marker_kinds, "Missing reconverge marker"

    def test_trace_v6_at_35_includes_exec_save(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=35)
        lines = [i.line for i in result.chain]
        # EXEC save at line 19 should be in the chain
        assert 19 in lines, "EXEC save instruction should be in trace"

    def test_trace_v6_at_25_no_else_block(self, simple_shader_6):
        slicer = Slicer(simple_shader_6)
        result = slicer.trace("v6", line=25)
        lines = [i.line for i in result.chain]
        # No else-block instructions since they're all after line 25
        assert not any(30 <= l <= 39 for l in lines), (
            "Else-block instructions should not appear when tracing from line 25")
