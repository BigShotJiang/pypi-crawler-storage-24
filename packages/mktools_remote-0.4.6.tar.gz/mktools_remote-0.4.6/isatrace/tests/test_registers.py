"""Tests for registers.py — range expansion, overlap detection, categorization, constant rejection."""

from isatrace.registers import (
    category,
    expand,
    is_constant,
    is_register,
    is_render_target,
    overlaps,
    parse_register,
)


class TestIsConstant:
    def test_hex_literals(self):
        assert is_constant("0xFF")
        assert is_constant("0x3b808081")

    def test_lit_values(self):
        assert is_constant("lit(0x0fffffff)")
        assert is_constant("lit(0x3e99999a)")

    def test_float_constants(self):
        assert is_constant("1.0")
        assert is_constant("-0.5")
        assert is_constant("0.5")
        assert is_constant("2.0")
        assert is_constant("4.0")
        assert is_constant("-1.0")

    def test_integer_constants(self):
        assert is_constant("0")
        assert is_constant("1")
        assert is_constant("64")

    def test_null(self):
        assert is_constant("null")

    def test_off(self):
        assert is_constant("off")

    def test_attributes(self):
        assert is_constant("attr0.x")
        assert is_constant("attr0.y")
        assert is_constant("attr1.z")

    def test_registers_not_constant(self):
        assert not is_constant("v0")
        assert not is_constant("s0")
        assert not is_constant("vcc")
        assert not is_constant("exec")
        assert not is_constant("s[0:3]")


class TestIsRegister:
    def test_single_vgpr(self):
        assert is_register("v0")
        assert is_register("v255")

    def test_single_sgpr(self):
        assert is_register("s0")
        assert is_register("s105")

    def test_register_ranges(self):
        assert is_register("v[0:3]")
        assert is_register("s[4:5]")
        assert is_register("s[8:15]")

    def test_special_registers(self):
        assert is_register("vcc")
        assert is_register("vcc_lo")
        assert is_register("vcc_hi")
        assert is_register("exec")
        assert is_register("exec_lo")
        assert is_register("exec_hi")
        assert is_register("scc")
        assert is_register("m0")

    def test_render_targets(self):
        assert is_register("mrt0")
        assert is_register("mrt1")
        assert is_register("pos0")
        assert is_register("mrtz")

    def test_constants_not_registers(self):
        assert not is_register("0xFF")
        assert not is_register("1.0")
        assert not is_register("null")
        assert not is_register("lit(0x3e99999a)")
        assert not is_register("attr0.x")

    def test_null_is_not_register(self):
        # null is special — it's an RDNA constant meaning "no register"
        assert not is_register("null")


class TestExpand:
    def test_single_vgpr(self):
        assert expand("v0") == ["v0"]

    def test_single_sgpr(self):
        assert expand("s5") == ["s5"]

    def test_vgpr_range(self):
        assert expand("v[0:3]") == ["v0", "v1", "v2", "v3"]

    def test_sgpr_pair(self):
        assert expand("s[4:5]") == ["s4", "s5"]

    def test_sgpr_wide_range(self):
        assert expand("s[0:7]") == ["s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7"]

    def test_vcc(self):
        assert expand("vcc") == ["vcc_lo", "vcc_hi"]

    def test_exec(self):
        assert expand("exec") == ["exec_lo", "exec_hi"]

    def test_scc(self):
        assert expand("scc") == ["scc"]

    def test_m0(self):
        assert expand("m0") == ["m0"]

    def test_render_target(self):
        assert expand("mrt0") == ["mrt0"]


class TestOverlaps:
    def test_identical(self):
        assert overlaps("v0", "v0")
        assert overlaps("s[0:3]", "s[0:3]")
        assert overlaps("vcc", "vcc")

    def test_single_in_range(self):
        assert overlaps("s0", "s[0:3]")
        assert overlaps("s3", "s[0:3]")
        assert overlaps("s[0:3]", "s2")

    def test_no_overlap(self):
        assert not overlaps("s0", "s1")
        assert not overlaps("s[0:3]", "s[4:7]")
        assert not overlaps("v0", "s0")

    def test_partial_range_overlap(self):
        assert overlaps("v[0:3]", "v[2:5]")
        assert overlaps("s[4:7]", "s[6:9]")

    def test_vcc_aliases(self):
        assert overlaps("vcc", "vcc_lo")
        assert overlaps("vcc", "vcc_hi")
        assert overlaps("vcc_lo", "vcc_hi")  # both are part of vcc

    def test_exec_aliases(self):
        assert overlaps("exec", "exec_lo")
        assert overlaps("exec", "exec_hi")

    def test_different_types_no_overlap(self):
        assert not overlaps("v0", "s0")
        assert not overlaps("vcc", "exec")
        assert not overlaps("scc", "vcc")


class TestCategory:
    def test_vgpr(self):
        assert category("v0") == "vgpr"
        assert category("v[0:3]") == "vgpr"

    def test_sgpr(self):
        assert category("s0") == "sgpr"
        assert category("s[4:7]") == "sgpr"

    def test_special(self):
        assert category("vcc") == "special"
        assert category("scc") == "special"
        assert category("exec") == "special"
        assert category("m0") == "special"

    def test_render_target(self):
        assert category("mrt0") == "render_target"
        assert category("pos0") == "render_target"


class TestParseRegister:
    def test_valid(self):
        assert parse_register("v0") == "v0"
        assert parse_register("  s[0:3]  ") == "s[0:3]"

    def test_invalid(self):
        assert parse_register("0xFF") is None
        assert parse_register("null") is None
        assert parse_register("1.0") is None
