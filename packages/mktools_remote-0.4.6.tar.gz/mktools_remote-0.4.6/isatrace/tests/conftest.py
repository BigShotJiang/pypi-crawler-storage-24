"""Shared test fixtures for isatrace tests."""

from __future__ import annotations

import pathlib

import pytest

FIXTURES_DIR = pathlib.Path(__file__).parent.parent / "rdna-dump-collection"


def _load(path: pathlib.Path) -> str:
    return path.read_text()


@pytest.fixture
def simple_shader_1() -> str:
    return _load(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-1.txt")


@pytest.fixture
def simple_shader_2() -> str:
    return _load(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-2.txt")


@pytest.fixture
def simple_shader_3() -> str:
    return _load(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-3.txt")


@pytest.fixture
def simple_shader_4() -> str:
    return _load(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-4.txt")


@pytest.fixture
def simple_shader_5() -> str:
    return _load(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-5.txt")


@pytest.fixture
def simple_shader_6() -> str:
    return _load(FIXTURES_DIR / "simple-shader-compilation" / "simple-shader-6.txt")


@pytest.fixture
def boogy90_1() -> str:
    return _load(FIXTURES_DIR / "boogy90" / "sample-1.txt")


@pytest.fixture
def boogy90_2() -> str:
    return _load(FIXTURES_DIR / "boogy90" / "sample-2.txt")


@pytest.fixture
def boogy90_3() -> str:
    return _load(FIXTURES_DIR / "boogy90" / "sample-3.txt")


@pytest.fixture
def gpuopen_1() -> str:
    return _load(FIXTURES_DIR / "gpuopen" / "sample-1.txt")


ALL_FIXTURE_PATHS = sorted(FIXTURES_DIR.rglob("*.txt"))


@pytest.fixture(params=ALL_FIXTURE_PATHS, ids=[str(p.relative_to(FIXTURES_DIR)) for p in sorted(FIXTURES_DIR.rglob("*.txt"))])
def any_fixture(request: pytest.FixtureRequest) -> str:
    return _load(request.param)
