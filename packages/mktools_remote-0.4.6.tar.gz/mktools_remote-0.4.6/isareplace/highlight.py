"""ISA syntax highlighting for the Textual TextArea.

Provides a custom TextArea subclass with regex-based syntax coloring
for shader assembly, and a matching dark theme.
"""

from __future__ import annotations

import re
from collections import defaultdict

from rich.style import Style
from textual.widgets import TextArea
from textual.widgets.text_area import TextAreaTheme

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------

ISA_THEME = TextAreaTheme(
    name="isa_dark",
    syntax_styles={
        # Use named terminal colors — NOT hex codes. Hex codes require 24-bit
        # true color support which not all terminals have. Named colors use the
        # terminal's own palette and always render correctly. These match the
        # exact colors isatrace uses in instruction_view.py.
        "comment": Style(dim=True, italic=True),
        "keyword": Style(color="yellow", bold=True),            # scalar ops (isatrace: salu → bold yellow)
        "function": Style(color="cyan", bold=True),             # vector ALU (isatrace: valu → bold cyan)
        "type": Style(color="magenta", bold=True),              # memory ops (isatrace: smem/vmem → bold magenta)
        "tag": Style(color="red", bold=True),                   # export ops (isatrace: export → bold red)
        "variable": Style(color="blue", bold=True),             # scalar registers — blue
        "variable.builtin": Style(color="cyan"),                # vector registers — cyan
        "number": Style(color="magenta"),                        # literals — magenta
        "string": Style(color="green", bold=True),              # labels (isatrace: branch → bold green)
        "constant.builtin": Style(color="green"),               # attributes/modifiers — green
        "operator": Style.null(),                                # punctuation — default
    },
)

# ---------------------------------------------------------------------------
# Classification patterns
# ---------------------------------------------------------------------------

# Export and other opcodes that don't follow s_/v_ naming
_EXPORT_OPS = re.compile(r"\b(exp)\b")
_MISC_OPS = re.compile(r"\b(lds_param_load)\b")

# Memory ops — checked before generic s_* to avoid misclassifying s_buffer_load etc.
_MEMORY_OPS = re.compile(
    r"\b("
    r"image_\w+|"
    r"buffer_\w+|tbuffer_\w+|"
    r"global_\w+|flat_\w+|scratch_\w+|"
    r"ds_\w+|"
    r"s_buffer_load\w*|s_buffer_store\w*|"
    r"s_load_\w+|s_store_\w+|"
    r"s_atomic_\w+"
    r")\b"
)

_SCALAR_OPS = re.compile(r"\b(s_\w+)\b")
_VECTOR_OPS = re.compile(r"\b(v_\w+)\b")

# Registers
_VREG = re.compile(r"\bv(?:\d+\b|\[\d+:\d+\])")
_SREG = re.compile(
    r"\b(?:s(?:\d+\b|\[\d+:\d+\])"
    r"|exec(?:_lo|_hi)?\b|vcc(?:_lo|_hi)?\b|scc\b|m0\b|null\b)"
)

# Render targets and special destinations (exp instruction)
_RENDER_TARGET = re.compile(
    r"\b(mrt[0-7]|mrtz|pos[0-4]|prim|param\d+|off)\b"
)

# Literals
_HEX_LITERAL = re.compile(r"\b0x[0-9a-fA-F]+\b")
_NUM_LITERAL = re.compile(r"(?<![a-zA-Z_])-?\d+(\.\d+)?\b")

# Labels
_LABEL_DEF = re.compile(r"^(\s*)(label_\w+|BB\d+_\d+|\.L\w+)\s*:")
_LABEL_REF = re.compile(r"\b(label_\w+|BB\d+_\d+|\.L\w+)\b")

# Attributes and modifiers
_ATTRIBUTE = re.compile(
    r"\b("
    r"attr\d+\.\w+|"
    r"dmask:\S+|format:\S+|offset:\S+|"
    r"glc|slc|dlc|unorm|"
    r"done|compr|vm|"
    r"idxen|offen|"
    r"clamp|mul:\d+|div:\d+|"
    r"wait_vdst:\d+|wait_exp:\d+"
    r")\b"
)

_COMMENT = re.compile(r"(//|;).*$")


def _highlight_line(text: str) -> list[tuple[int, int | None, str]]:
    """Compute highlight ranges for a single line of ISA assembly.

    Returns list of (start_col, end_col, highlight_name) tuples.
    """
    highlights: list[tuple[int, int | None, str]] = []

    # Comments — everything from // or ; to end of line
    cm = _COMMENT.search(text)
    comment_start = cm.start() if cm else len(text)
    if cm:
        highlights.append((cm.start(), len(text), "comment"))

    # Only process non-comment portion
    code = text[:comment_start]
    if not code.strip():
        return highlights

    # Track which character positions are already highlighted
    claimed: set[int] = set()
    if cm:
        claimed.update(range(cm.start(), len(text)))

    def add(match: re.Match, name: str) -> None:
        s, e = match.start(), match.end()
        if not any(i in claimed for i in range(s, e)):
            highlights.append((s, e, name))
            claimed.update(range(s, e))

    # Label definitions
    m = _LABEL_DEF.match(code)
    if m:
        highlights.append((m.start(2), m.end(2) + 1, "string"))  # include colon
        claimed.update(range(m.start(2), m.end(2) + 1))

    # Export ops (before memory/scalar/vector to catch 'exp')
    for m in _EXPORT_OPS.finditer(code):
        add(m, "tag")

    # Misc ops (lds_param_load)
    for m in _MISC_OPS.finditer(code):
        add(m, "function")

    # Memory ops (before generic s_* / v_*)
    for m in _MEMORY_OPS.finditer(code):
        add(m, "type")

    # Scalar ops
    for m in _SCALAR_OPS.finditer(code):
        add(m, "keyword")

    # Vector ops
    for m in _VECTOR_OPS.finditer(code):
        add(m, "function")

    # Attributes and modifiers (before registers)
    for m in _ATTRIBUTE.finditer(code):
        add(m, "constant.builtin")

    # Render targets (mrt0, pos0, off, etc.)
    for m in _RENDER_TARGET.finditer(code):
        add(m, "constant.builtin")

    # Vector registers
    for m in _VREG.finditer(code):
        add(m, "variable.builtin")

    # Scalar registers
    for m in _SREG.finditer(code):
        add(m, "variable")

    # Label references
    for m in _LABEL_REF.finditer(code):
        add(m, "string")

    # Hex literals
    for m in _HEX_LITERAL.finditer(code):
        add(m, "number")

    # Numeric literals
    for m in _NUM_LITERAL.finditer(code):
        add(m, "number")

    return highlights


# ---------------------------------------------------------------------------
# Custom TextArea subclass
# ---------------------------------------------------------------------------

class ISATextArea(TextArea):
    """TextArea with ISA assembly syntax highlighting."""

    def __init__(self, *args, **kwargs) -> None:
        kwargs.pop("theme", None)
        super().__init__(*args, **kwargs)
        self.register_theme(ISA_THEME)
        self.theme = "isa_dark"

    def _build_highlight_map(self) -> None:
        """Override tree-sitter highlighting with regex-based ISA highlighting."""
        if hasattr(self, "_line_cache"):
            self._line_cache.clear()
        self._highlights.clear()

        lines = self.document.text.split("\n")
        for i, line in enumerate(lines):
            line_hl = _highlight_line(line)
            if line_hl:
                self._highlights[i] = line_hl
