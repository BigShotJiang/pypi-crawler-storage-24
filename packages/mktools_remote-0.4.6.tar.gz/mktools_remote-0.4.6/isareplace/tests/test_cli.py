"""Tests for CLI argument parsing and integration flows."""

from __future__ import annotations

import struct
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from isareplace.binary import S_ENDPGM, S_CODE_END
from isareplace.cli import build_parser, main
from isareplace.external import ToolResult
from isareplace.tests.conftest import make_test_binary


class TestArgParsing:
    def test_minimal_args(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
            "input.bin", "output.bin",
        ])
        assert args.gfxip == 4040
        assert args.wave_size == 32
        assert args.shader_type == "PS"
        assert args.input_bin == "input.bin"
        assert args.output_bin == "output.bin"
        assert args.sp3 is None

    def test_with_sp3(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4020", "--wave_size=64", "--shader_type=CS",
            "--sp3=prev.sp3",
            "input.bin", "output.bin",
        ])
        assert args.sp3 == "prev.sp3"

    def test_all_shader_types(self) -> None:
        for st in ("PS", "GS", "CS"):
            args = build_parser().parse_args([
                "--gfxip=4010", "--wave_size=32", f"--shader_type={st}",
                "in.bin", "out.bin",
            ])
            assert args.shader_type == st

    def test_invalid_wave_size(self) -> None:
        with pytest.raises(SystemExit):
            build_parser().parse_args([
                "--gfxip=4040", "--wave_size=16", "--shader_type=PS",
                "in.bin", "out.bin",
            ])

    def test_invalid_shader_type(self) -> None:
        with pytest.raises(SystemExit):
            build_parser().parse_args([
                "--gfxip=4040", "--wave_size=32", "--shader_type=VS",
                "in.bin", "out.bin",
            ])

    def test_missing_required(self) -> None:
        with pytest.raises(SystemExit):
            build_parser().parse_args(["input.bin", "output.bin"])

    def test_headless_flag(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
            "--headless",
            "input.bin", "output.bin",
        ])
        assert args.headless is True

    def test_no_headless_by_default(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
            "input.bin", "output.bin",
        ])
        assert args.headless is False


# ---------------------------------------------------------------------------
# Integration tests with mocked external tool
# ---------------------------------------------------------------------------

def _fake_disassemble(tool_path, generation, input_bin, output_sp3):
    """Mock disassembler: writes fake assembly text."""
    Path(output_sp3).write_text(
        "  s_mov_b32 s0, 0x1\n  v_add_f32 v0, v1, v2\n  s_endpgm\n"
    )
    return ToolResult(returncode=0, stdout="", stderr="")


def _fake_assemble_same_size(tool_path, generation, shader_type, wave_size, input_sp3, output_bin):
    """Mock assembler: produces a binary with the same instruction count."""
    # 5 DWORDs of instructions (matching our test binary)
    instrs = struct.pack("<5I", 0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001, S_ENDPGM)
    Path(output_bin).write_bytes(instrs)
    return ToolResult(returncode=0, stdout="", stderr="")


class TestHeadlessIntegration:
    """End-to-end headless flow with mocked external tool."""

    def _make_input_binary(self, tmp_path: Path) -> Path:
        binary = make_test_binary(
            [0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001],
            16,
            [0x3F800000, 0x40000000],
        )
        input_path = tmp_path / "shader.bin"
        input_path.write_bytes(binary)
        return input_path

    def _make_tool(self, tmp_path: Path) -> Path:
        tool = tmp_path / "fake_sp3"
        tool.write_text("#!/bin/sh\n")
        tool.chmod(0o755)
        return tool

    @patch("isareplace.cli.ext_disassemble", side_effect=_fake_disassemble)
    @patch("isareplace.cli.ext_assemble", side_effect=_fake_assemble_same_size)
    @patch("subprocess.run")  # mock $EDITOR
    def test_headless_full_flow(self, mock_editor, mock_asm, mock_disasm, tmp_path: Path) -> None:
        """Full headless: disassemble → editor → assemble → fixup → write."""
        input_path = self._make_input_binary(tmp_path)
        output_path = tmp_path / "patched.bin"
        tool = self._make_tool(tmp_path)

        mock_editor.return_value = MagicMock(returncode=0)

        with patch("isareplace.cli.resolve_tool_path", return_value=str(tool)):
            main([
                "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
                "--headless",
                str(input_path), str(output_path),
            ])

        # Output binary should exist
        assert output_path.exists()
        # Session .sp3 should be saved alongside
        assert output_path.with_suffix(".sp3").exists()
        # Output should be same size as input (no size change)
        assert len(output_path.read_bytes()) == len(input_path.read_bytes())

    @patch("isareplace.cli.ext_disassemble", side_effect=_fake_disassemble)
    def test_disassembly_text_survives_tempdir_cleanup(self, mock_disasm, tmp_path: Path) -> None:
        """The disassembled text must be read before the temp dir is cleaned up."""
        input_path = self._make_input_binary(tmp_path)
        output_path = tmp_path / "patched.bin"
        tool = self._make_tool(tmp_path)

        # We'll intercept at _run_tui to check assembly_text was passed correctly
        captured = {}

        def fake_run_tui(args, layout, original_data, assembly_text, sp3_source,
                         tool_path, generation, output_path):
            captured["text"] = assembly_text
            captured["sp3_source"] = sp3_source

        with patch("isareplace.cli.resolve_tool_path", return_value=str(tool)):
            with patch("isareplace.cli._run_tui", side_effect=fake_run_tui):
                main([
                    "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
                    str(input_path), str(output_path),
                ])

        assert "s_mov_b32" in captured["text"]
        assert captured["sp3_source"] is None

    def test_auto_resume_from_existing_sp3(self, tmp_path: Path) -> None:
        """If <output>.sp3 exists, should auto-resume without disassembling."""
        input_path = self._make_input_binary(tmp_path)
        output_path = tmp_path / "patched.bin"
        tool = self._make_tool(tmp_path)

        # Create a pre-existing .sp3 session file
        sp3_path = output_path.with_suffix(".sp3")
        sp3_path.write_text("  s_mov_b32 s0, 0x42\n  s_endpgm\n")

        captured = {}

        def fake_run_tui(args, layout, original_data, assembly_text, sp3_source,
                         tool_path, generation, output_path):
            captured["text"] = assembly_text
            captured["sp3_source"] = sp3_source

        with patch("isareplace.cli.resolve_tool_path", return_value=str(tool)):
            with patch("isareplace.cli._run_tui", side_effect=fake_run_tui):
                main([
                    "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
                    str(input_path), str(output_path),
                ])

        # Should have loaded the existing .sp3 content, not disassembled
        assert "0x42" in captured["text"]
        assert captured["sp3_source"] == str(sp3_path)

    def test_sp3_flag_overrides_auto_resume(self, tmp_path: Path) -> None:
        """Explicit --sp3 should take priority over auto-detected session."""
        input_path = self._make_input_binary(tmp_path)
        output_path = tmp_path / "patched.bin"
        tool = self._make_tool(tmp_path)

        # Both auto-detect and explicit sp3 exist
        auto_sp3 = output_path.with_suffix(".sp3")
        auto_sp3.write_text("  s_mov_b32 s0, 0xAUTO\n  s_endpgm\n")

        explicit_sp3 = tmp_path / "explicit.sp3"
        explicit_sp3.write_text("  s_mov_b32 s0, 0xEXPLICIT\n  s_endpgm\n")

        captured = {}

        def fake_run_tui(args, layout, original_data, assembly_text, sp3_source,
                         tool_path, generation, output_path):
            captured["text"] = assembly_text
            captured["sp3_source"] = sp3_source

        with patch("isareplace.cli.resolve_tool_path", return_value=str(tool)):
            with patch("isareplace.cli._run_tui", side_effect=fake_run_tui):
                main([
                    "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
                    f"--sp3={explicit_sp3}",
                    str(input_path), str(output_path),
                ])

        assert "0xEXPLICIT" in captured["text"]
        assert captured["sp3_source"] == str(explicit_sp3)

    def test_temp_files_in_output_dir_not_tmp(self, tmp_path: Path) -> None:
        """Temp dirs should be created in the output directory, not /tmp."""
        import tempfile

        input_path = self._make_input_binary(tmp_path)
        output_dir = tmp_path / "subdir"
        output_dir.mkdir()
        output_path = output_dir / "patched.bin"
        tool = self._make_tool(tmp_path)

        dirs_created = []
        _real_td = tempfile.TemporaryDirectory

        class TrackingTempDir(_real_td):
            def __init__(self, *a, **kw):
                dirs_created.append(kw.get("dir"))
                super().__init__(*a, **kw)

        def fake_run_tui(*args, **kwargs):
            pass

        with patch("isareplace.cli.ext_disassemble", side_effect=_fake_disassemble):
            with patch("isareplace.cli.resolve_tool_path", return_value=str(tool)):
                with patch("isareplace.cli._run_tui", side_effect=fake_run_tui):
                    with patch("isareplace.cli.tempfile.TemporaryDirectory", TrackingTempDir):
                        main([
                            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
                            str(input_path), str(output_path),
                        ])

        assert dirs_created, "No temp dirs were created"
        for d in dirs_created:
            assert d == output_dir, f"Temp dir in {d}, expected {output_dir}"
