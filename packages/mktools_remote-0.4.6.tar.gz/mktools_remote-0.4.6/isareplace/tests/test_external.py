"""Tests for external tool wrapper (no real subprocess calls)."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from isareplace.external import (
    asic_name,
    assemble,
    disassemble,
    env_var_name,
    gfxip_to_generation,
    resolve_tool_path,
)


# ---------------------------------------------------------------------------
# gfxip → generation mapping
# ---------------------------------------------------------------------------

class TestGfxipMapping:
    @pytest.mark.parametrize("gfxip,expected", [
        (4010, 1), (4020, 2), (4030, 3), (4040, 4), (4050, 5),
    ])
    def test_valid_gfxip(self, gfxip: int, expected: int) -> None:
        assert gfxip_to_generation(gfxip) == expected

    @pytest.mark.parametrize("gfxip", [4000, 4060, 4099])
    def test_invalid_gfxip(self, gfxip: int) -> None:
        with pytest.raises(ValueError, match="out of range"):
            gfxip_to_generation(gfxip)


# ---------------------------------------------------------------------------
# env var / asic name helpers
# ---------------------------------------------------------------------------

class TestEnvVarName:
    @pytest.mark.parametrize("gen,expected", [
        (1, "SP3_MGFX1"), (2, "SP3_MGFX2"), (3, "SP3_MGFX3"),
        (4, "SP3_MGFX4"), (5, "SP3_MGFX5"),
    ])
    def test_env_var_name(self, gen: int, expected: str) -> None:
        assert env_var_name(gen) == expected

    @pytest.mark.parametrize("gen,expected", [
        (1, "MGFX1"), (4, "MGFX4"),
    ])
    def test_asic_name(self, gen: int, expected: str) -> None:
        assert asic_name(gen) == expected


# ---------------------------------------------------------------------------
# resolve_tool_path
# ---------------------------------------------------------------------------

class TestResolveToolPath:
    def test_from_env_var(self, tmp_path: Path) -> None:
        tool = tmp_path / "sp3_tool"
        tool.write_text("#!/bin/sh\n")
        tool.chmod(0o755)

        with patch.dict(os.environ, {"SP3_MGFX3": str(tool)}):
            assert resolve_tool_path(3, interactive=False) == str(tool)

    def test_missing_env_non_interactive(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(RuntimeError, match="not configured"):
                resolve_tool_path(4, interactive=False)

    def test_env_points_to_missing_file(self, tmp_path: Path) -> None:
        with patch.dict(os.environ, {"SP3_MGFX1": str(tmp_path / "nope")}):
            with pytest.raises(RuntimeError, match="not configured"):
                resolve_tool_path(1, interactive=False)

    def test_interactive_prompt(self, tmp_path: Path) -> None:
        tool = tmp_path / "sp3_tool"
        tool.write_text("#!/bin/sh\n")
        tool.chmod(0o755)

        with patch.dict(os.environ, {}, clear=True):
            with patch("builtins.input", return_value=str(tool)):
                path = resolve_tool_path(2, interactive=True)
                assert path == str(tool)


# ---------------------------------------------------------------------------
# Command construction (check args passed to subprocess)
# ---------------------------------------------------------------------------

class TestCommandConstruction:
    def test_disassemble_command(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(cmd)
            from types import SimpleNamespace
            return SimpleNamespace(returncode=0, stdout="", stderr="")

        with patch("isareplace.external.subprocess.run", side_effect=fake_run):
            disassemble("/usr/bin/sp3", 4, tmp_path / "in.bin", tmp_path / "out.sp3")

        assert len(calls) == 1
        cmd = calls[0]
        assert cmd[0] == "/usr/bin/sp3"
        assert "disparse:" in cmd
        assert "asic=MGFX4" in cmd
        assert "-binary" in cmd

    def test_assemble_command(self, tmp_path: Path) -> None:
        calls = []

        def fake_run(cmd, **kwargs):
            calls.append(cmd)
            from types import SimpleNamespace
            return SimpleNamespace(returncode=0, stdout="", stderr="")

        with patch("isareplace.external.subprocess.run", side_effect=fake_run):
            assemble(
                "/usr/bin/sp3", 3, "PS", 32,
                tmp_path / "in.sp3", tmp_path / "out.bin",
            )

        assert len(calls) == 1
        cmd = calls[0]
        assert cmd[0] == "/usr/bin/sp3"
        assert "compile:" in cmd
        assert "asic=MGFX3" in cmd
        assert "type=PS" in cmd
        assert "wave_size=32" in cmd
