"""Shared test fixtures for isareplace."""

from __future__ import annotations

import struct

import pytest

from isareplace.binary import S_ENDPGM, S_CODE_END


def make_test_binary(
    instruction_dwords: list[int],
    padding_count: int,
    constant_dwords: list[int] | None = None,
) -> bytes:
    """Build a synthetic shader binary: instructions + padding + constants.

    If the last element of instruction_dwords is not s_endpgm (0xBFB00000),
    it is appended automatically.

    Args:
        instruction_dwords: Fake instruction DWORDs. Last should be s_endpgm;
            if not, one is appended.
        padding_count: Number of s_code_end DWORDs to insert.
        constant_dwords: Fake constant DWORDs. None or empty for no constants.
    """
    if constant_dwords is None:
        constant_dwords = []

    instrs = list(instruction_dwords)
    if not instrs or instrs[-1] != S_ENDPGM:
        instrs.append(S_ENDPGM)

    all_dwords = instrs + [S_CODE_END] * padding_count + constant_dwords
    return struct.pack(f"<{len(all_dwords)}I", *all_dwords)


@pytest.fixture
def small_binary() -> bytes:
    """5-DWORD instruction region + 16 padding + 4 constants."""
    instrs = [0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001]
    constants = [0x3F800000, 0x40000000, 0x40400000, 0x40800000]  # 1.0, 2.0, 3.0, 4.0
    return make_test_binary(instrs, 16, constants)


@pytest.fixture
def medium_binary() -> bytes:
    """50-DWORD instruction region + 32 padding + 8 constants."""
    instrs = [0xBEFE0000 + i for i in range(49)]
    constants = [0x3F800000 + i for i in range(8)]
    return make_test_binary(instrs, 32, constants)


@pytest.fixture
def large_binary() -> bytes:
    """500-DWORD instruction region + 100 padding + 16 constants."""
    instrs = [0xD0000000 + i for i in range(499)]
    constants = [0x3F800000, 0x40000000] * 8
    return make_test_binary(instrs, 100, constants)
