"""Tests for core binary parsing and padding logic."""

from __future__ import annotations

import struct

import pytest

from isareplace.binary import (
    S_CODE_END,
    S_ENDPGM,
    BinaryLayout,
    PaddingResult,
    PaddingSeverity,
    assemble_output,
    compute_padding,
    parse_binary,
)
from isareplace.tests.conftest import make_test_binary


# ---------------------------------------------------------------------------
# 1. Round-trip no-op
# ---------------------------------------------------------------------------

class TestRoundTripNoop:
    """Parse a binary, then reassemble with identical instruction size.
    Output must be byte-identical to input."""

    def test_small(self, small_binary: bytes) -> None:
        layout = parse_binary(small_binary)
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            small_binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == small_binary

    def test_medium(self, medium_binary: bytes) -> None:
        layout = parse_binary(medium_binary)
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            medium_binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == medium_binary

    def test_large(self, large_binary: bytes) -> None:
        layout = parse_binary(large_binary)
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            large_binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == large_binary


# ---------------------------------------------------------------------------
# 2. Size increase — padding shrinks, constants at same offset
# ---------------------------------------------------------------------------

class TestSizeIncrease:
    def test_grow_by_2_dwords(self, small_binary: bytes) -> None:
        layout = parse_binary(small_binary)
        # Simulate adding 2 DWORDs of instructions
        extra = struct.pack("<2I", 0x7E000280, 0xD4010001)
        new_instrs = small_binary[: layout.instruction_size] + extra
        new_size = len(new_instrs)

        result = compute_padding(layout, new_size)
        assert result.delta_dwords == 2
        assert result.remaining_dwords == layout.padding_dwords - 2

        output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)
        # Total size unchanged
        assert len(output) == len(small_binary)
        # Constants at same offset
        assert output[layout.constants_offset:] == layout.constants_blob


# ---------------------------------------------------------------------------
# 3. Size decrease — padding grows, constants at same offset
# ---------------------------------------------------------------------------

class TestSizeDecrease:
    def test_shrink_by_2_dwords(self) -> None:
        instrs = [0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001, 0x7E020281]
        constants = [0x3F800000, 0x40000000]
        binary = make_test_binary(instrs, 10, constants)
        layout = parse_binary(binary)

        # Remove 2 DWORDs from instructions (keep first 4 + s_endpgm = 5 -> 4 = remove 2)
        # Original: 6 dwords (5 instrs + s_endpgm). New: 4 dwords (3 instrs + s_endpgm)
        new_instrs = make_test_binary(instrs[:3], 0)  # just instructions + s_endpgm, no padding
        new_size = len(new_instrs)

        result = compute_padding(layout, new_size)
        assert result.delta_dwords == -2
        assert result.remaining_dwords == layout.padding_dwords + 2

        output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)
        # Total size unchanged
        assert len(output) == len(binary)
        # Constants at same offset
        assert output[layout.constants_offset:] == layout.constants_blob


# ---------------------------------------------------------------------------
# 4. Overflow — new binary exceeds available space
# ---------------------------------------------------------------------------

class TestOverflow:
    def test_exceeds_padding(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 4, [0x3F800000])
        layout = parse_binary(binary)
        # 3 instr DWORDs + 4 padding = 7 total. Growing by 5 -> 8 DWORDs = 1 over
        new_size = layout.instruction_size + 5 * 4
        with pytest.raises(ValueError, match="1 DWORD.*over the limit"):
            compute_padding(layout, new_size)

    def test_exceeds_by_1(self) -> None:
        binary = make_test_binary([0xBEFE00FF], 3)
        layout = parse_binary(binary)
        # Exactly 1 over
        new_size = layout.instruction_size + 4 * 4
        with pytest.raises(ValueError, match="1 DWORD.*over the limit"):
            compute_padding(layout, new_size)


# ---------------------------------------------------------------------------
# 5. Alignment error
# ---------------------------------------------------------------------------

class TestAlignmentError:
    def test_not_dword_aligned(self) -> None:
        binary = make_test_binary([0xBEFE00FF], 8)
        layout = parse_binary(binary)
        with pytest.raises(ValueError, match="not DWORD-aligned"):
            compute_padding(layout, 13)  # 13 bytes = not aligned

    def test_binary_not_aligned(self) -> None:
        with pytest.raises(ValueError, match="not DWORD-aligned"):
            parse_binary(b"\x00\x01\x02")


# ---------------------------------------------------------------------------
# 6. Zero padding in original
# ---------------------------------------------------------------------------

class TestZeroPadding:
    def test_same_size_works(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 0, [0x3F800000])
        layout = parse_binary(binary)
        assert layout.padding_dwords == 0

        result = compute_padding(layout, layout.instruction_size)
        assert result.remaining_dwords == 0
        assert result.delta_dwords == 0

        output = assemble_output(
            binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == binary

    def test_increase_fails(self) -> None:
        binary = make_test_binary([0xBEFE00FF], 0, [0x3F800000])
        layout = parse_binary(binary)
        with pytest.raises(ValueError, match="over the limit"):
            compute_padding(layout, layout.instruction_size + 4)

    def test_decrease_grows_padding(self) -> None:
        # 3 instrs + s_endpgm = 4 dwords, 0 padding, 2 constants
        instrs = [0xBEFE00FF, 0x80000001, 0x7E000280]
        constants = [0x3F800000, 0x40000000]
        binary = make_test_binary(instrs, 0, constants)
        layout = parse_binary(binary)
        assert layout.padding_dwords == 0

        # Shrink by 1 DWORD
        new_instrs_data = make_test_binary(instrs[:2], 0)
        result = compute_padding(layout, len(new_instrs_data))
        assert result.remaining_dwords == 1
        assert result.delta_dwords == -1

        output = assemble_output(new_instrs_data, result.remaining_dwords, layout.constants_blob)
        assert len(output) == len(binary)
        assert output[layout.constants_offset:] == layout.constants_blob


# ---------------------------------------------------------------------------
# 7. No constants
# ---------------------------------------------------------------------------

class TestNoConstants:
    def test_parse_no_constants(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 8)
        layout = parse_binary(binary)
        assert layout.constants_blob == b""
        assert layout.constants_offset == layout.instruction_size + layout.padding_size

    def test_roundtrip_no_constants(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 8)
        layout = parse_binary(binary)
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == binary

    def test_grow_no_constants(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 8)
        layout = parse_binary(binary)
        extra = struct.pack("<2I", 0x7E000280, 0xD4010001)
        new_instrs = binary[: layout.instruction_size] + extra
        result = compute_padding(layout, len(new_instrs))
        output = assemble_output(new_instrs, result.remaining_dwords, b"")
        assert len(output) == len(binary)


# ---------------------------------------------------------------------------
# 8. Empty padding and no constants
# ---------------------------------------------------------------------------

class TestBareInstructions:
    def test_just_instructions(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 0)
        layout = parse_binary(binary)
        assert layout.padding_dwords == 0
        assert layout.constants_blob == b""
        assert layout.instruction_size == len(binary)

    def test_roundtrip_bare(self) -> None:
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 0)
        layout = parse_binary(binary)
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == binary


# ---------------------------------------------------------------------------
# 9. Multiple s_endpgm — must key off the last one before padding
# ---------------------------------------------------------------------------

class TestMultipleEndpgm:
    def test_two_endpgm_uses_last(self) -> None:
        # First s_endpgm in the middle (e.g., from a branch), second at the end
        instrs = [
            0xBEFE00FF,   # instruction
            S_ENDPGM,     # first s_endpgm (mid-stream, e.g., branch target)
            0x80000001,   # more instructions after the branch
            0x7E000280,
            S_ENDPGM,     # second (final) s_endpgm — DON'T auto-append
        ]
        constants = [0x3F800000, 0x40000000]
        binary = make_test_binary(instrs, 10, constants)
        layout = parse_binary(binary)

        # instruction_size should include all 5 DWORDs
        assert layout.instruction_dwords == 5
        assert layout.padding_dwords == 10
        assert layout.constants_blob == struct.pack("<2I", 0x3F800000, 0x40000000)

    def test_endpgm_before_non_endpgm_then_endpgm(self) -> None:
        """s_endpgm followed by regular instructions then another s_endpgm."""
        instrs = [
            0xD0000001,
            S_ENDPGM,
            0xD0000002,
            0xD0000003,
        ]  # make_test_binary will append s_endpgm
        constants = [0x3F800000]
        binary = make_test_binary(instrs, 5, constants)
        layout = parse_binary(binary)

        # 4 instrs + auto-appended s_endpgm = 5 DWORDs
        assert layout.instruction_dwords == 5
        assert layout.padding_dwords == 5


# ---------------------------------------------------------------------------
# 10. Padding color thresholds
# ---------------------------------------------------------------------------

class TestPaddingSeverity:
    """Verify severity at boundary percentages of consumption."""

    def _make_layout(self, padding: int) -> BinaryLayout:
        binary = make_test_binary([0xBEFE00FF], padding)
        return parse_binary(binary)

    def test_0_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        result = compute_padding(layout, layout.instruction_size)
        assert result.severity == PaddingSeverity.GREEN

    def test_49_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        new_size = layout.instruction_size + 49 * 4
        result = compute_padding(layout, new_size)
        assert result.severity == PaddingSeverity.GREEN

    def test_50_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        new_size = layout.instruction_size + 50 * 4
        result = compute_padding(layout, new_size)
        assert result.severity == PaddingSeverity.YELLOW

    def test_89_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        new_size = layout.instruction_size + 89 * 4
        result = compute_padding(layout, new_size)
        assert result.severity == PaddingSeverity.YELLOW

    def test_90_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        new_size = layout.instruction_size + 90 * 4
        result = compute_padding(layout, new_size)
        assert result.severity == PaddingSeverity.YELLOW

    def test_91_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        new_size = layout.instruction_size + 91 * 4
        result = compute_padding(layout, new_size)
        assert result.severity == PaddingSeverity.RED

    def test_100_percent_consumed(self) -> None:
        layout = self._make_layout(100)
        new_size = layout.instruction_size + 100 * 4
        result = compute_padding(layout, new_size)
        assert result.severity == PaddingSeverity.RED

    def test_zero_original_padding(self) -> None:
        layout = self._make_layout(0)
        result = compute_padding(layout, layout.instruction_size)
        assert result.severity == PaddingSeverity.RED


# ---------------------------------------------------------------------------
# 11. Constants offset preserved
# ---------------------------------------------------------------------------

class TestConstantsOffsetPreserved:
    def test_grow_preserves_offset(self, small_binary: bytes) -> None:
        layout = parse_binary(small_binary)
        extra = struct.pack("<3I", 0x7E000280, 0xD4010001, 0x80000002)
        new_instrs = small_binary[: layout.instruction_size] + extra
        result = compute_padding(layout, len(new_instrs))
        output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)

        # Constants must start at the same byte offset
        assert output[layout.constants_offset:] == layout.constants_blob
        assert len(output) == len(small_binary)

    def test_shrink_preserves_offset(self) -> None:
        instrs = [0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001, 0x80000002]
        constants = [0x3F800000, 0x40000000, 0x40400000]
        binary = make_test_binary(instrs, 20, constants)
        layout = parse_binary(binary)

        # Shrink by 3 DWORDs
        new_instrs = make_test_binary(instrs[:2], 0)
        result = compute_padding(layout, len(new_instrs))
        output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)

        assert output[layout.constants_offset:] == layout.constants_blob
        assert len(output) == len(binary)


# ---------------------------------------------------------------------------
# 12. Constants byte-identical (recognizable float values)
# ---------------------------------------------------------------------------

class TestConstantsByteIdentical:
    def test_float_constants_survive_roundtrip(self) -> None:
        # Use recognizable IEEE 754 values
        float_dwords = [
            0x3F800000,  # 1.0f
            0x40000000,  # 2.0f
            0x40400000,  # 3.0f
            0x40800000,  # 4.0f
            0x3DCCCCCD,  # 0.1f
            0x00000000,  # 0.0f
            0x7F800000,  # +inf
            0xFF800000,  # -inf
        ]
        binary = make_test_binary([0xBEFE00FF, 0x80000001], 16, float_dwords)
        layout = parse_binary(binary)

        # Verify constants are exactly the float values we put in
        expected_constants = struct.pack(f"<{len(float_dwords)}I", *float_dwords)
        assert layout.constants_blob == expected_constants

        # Grow by 5, reassemble, verify constants survive
        extra = struct.pack("<5I", *([0xD0000000] * 5))
        new_instrs = binary[: layout.instruction_size] + extra
        result = compute_padding(layout, len(new_instrs))
        output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)

        assert output[layout.constants_offset:] == expected_constants

    def test_shrink_constants_identical(self) -> None:
        float_dwords = [0x3F800000, 0x40000000]
        instrs = [0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001]
        binary = make_test_binary(instrs, 10, float_dwords)
        layout = parse_binary(binary)

        new_instrs = make_test_binary(instrs[:2], 0)
        result = compute_padding(layout, len(new_instrs))
        output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)

        expected = struct.pack("<2I", 0x3F800000, 0x40000000)
        assert output[layout.constants_offset:] == expected


# ---------------------------------------------------------------------------
# 13. Various binary sizes
# ---------------------------------------------------------------------------

class TestVariousSizes:
    def test_small_5_dwords(self, small_binary: bytes) -> None:
        layout = parse_binary(small_binary)
        assert layout.instruction_dwords == 5  # 4 instrs + s_endpgm
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            small_binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == small_binary

    def test_medium_50_dwords(self, medium_binary: bytes) -> None:
        layout = parse_binary(medium_binary)
        assert layout.instruction_dwords == 50  # 49 instrs + s_endpgm
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            medium_binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == medium_binary

    def test_large_500_dwords(self, large_binary: bytes) -> None:
        layout = parse_binary(large_binary)
        assert layout.instruction_dwords == 500  # 499 instrs + s_endpgm
        result = compute_padding(layout, layout.instruction_size)
        output = assemble_output(
            large_binary[: layout.instruction_size],
            result.remaining_dwords,
            layout.constants_blob,
        )
        assert output == large_binary

    def test_size_dependent_grow_shrink(self) -> None:
        """Test grow and shrink on different-sized binaries to catch
        size-dependent bugs."""
        for n_instrs in [5, 50, 500]:
            instrs = [0xD0000000 + i for i in range(n_instrs - 1)]
            constants = [0x3F800000, 0x40000000]
            binary = make_test_binary(instrs, 20, constants)
            layout = parse_binary(binary)

            # Grow by 3
            extra = struct.pack("<3I", 0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC)
            new_instrs = binary[: layout.instruction_size] + extra
            result = compute_padding(layout, len(new_instrs))
            output = assemble_output(new_instrs, result.remaining_dwords, layout.constants_blob)
            assert len(output) == len(binary)
            assert output[layout.constants_offset:] == layout.constants_blob

            # Shrink by 2
            shorter_instrs = make_test_binary(instrs[: len(instrs) - 2], 0)
            result2 = compute_padding(layout, len(shorter_instrs))
            output2 = assemble_output(shorter_instrs, result2.remaining_dwords, layout.constants_blob)
            assert len(output2) == len(binary)
            assert output2[layout.constants_offset:] == layout.constants_blob


# ---------------------------------------------------------------------------
# Edge cases: error conditions
# ---------------------------------------------------------------------------

class TestErrorConditions:
    def test_empty_binary(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            parse_binary(b"")

    def test_no_endpgm(self) -> None:
        data = struct.pack("<4I", 0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001)
        with pytest.raises(ValueError, match="No s_endpgm"):
            parse_binary(data)
