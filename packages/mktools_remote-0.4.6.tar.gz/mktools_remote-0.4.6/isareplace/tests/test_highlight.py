"""Tests for ISA syntax highlighting."""

from __future__ import annotations

import pytest

from isareplace.highlight import _highlight_line


def _names(highlights: list) -> list[str]:
    """Extract just the highlight names from a highlight list."""
    return [h[2] for h in highlights]


def _text_for(line: str, name: str) -> list[str]:
    """Extract the text fragments highlighted with a given name."""
    return [line[h[0]:h[1]] for h in _highlight_line(line) if h[2] == name]


class TestComments:
    def test_double_slash_comment(self) -> None:
        line = "  s_mov_b32 s0, 0x1  // setup"
        names = _names(_highlight_line(line))
        assert "comment" in names

    def test_semicolon_comment(self) -> None:
        line = "  v_add_f32 v0, v1, v2 ; add"
        names = _names(_highlight_line(line))
        assert "comment" in names

    def test_full_line_comment(self) -> None:
        line = "// this is a comment"
        hl = _highlight_line(line)
        assert len(hl) == 1
        assert hl[0][2] == "comment"
        assert hl[0][0] == 0


class TestScalarOps:
    def test_s_mov(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_mov_b32 s0, 0x1"))

    def test_s_waitcnt(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_waitcnt vmcnt(0)"))

    def test_s_endpgm(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_endpgm"))

    def test_s_cbranch(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_cbranch_scc1 label_0001"))


class TestVectorOps:
    def test_v_add(self) -> None:
        assert "function" in _names(_highlight_line("  v_add_f32 v0, v1, v2"))

    def test_v_mul(self) -> None:
        assert "function" in _names(_highlight_line("  v_mul_f32 v3, v4, v5"))

    def test_v_cmp(self) -> None:
        assert "function" in _names(_highlight_line("  v_cmp_gt_f32 vcc, v0, v1"))

    def test_v_interp(self) -> None:
        assert "function" in _names(_highlight_line("  v_interp_p1_f32 v0, v1, attr0.x"))

    def test_v_mov(self) -> None:
        assert "function" in _names(_highlight_line("  v_mov_b32 v0, 0"))


class TestMemoryOps:
    def test_image_sample(self) -> None:
        assert "type" in _names(
            _highlight_line("  image_sample v[0:3], v4, s[0:7], s[8:11]")
        )

    def test_buffer_load(self) -> None:
        assert "type" in _names(
            _highlight_line("  buffer_load_dword v0, off, s[0:3], 0")
        )

    def test_s_buffer_load(self) -> None:
        names = _names(_highlight_line("  s_buffer_load_dword s0, s[4:7], 0x0"))
        assert "type" in names

    def test_global_load(self) -> None:
        assert "type" in _names(
            _highlight_line("  global_load_dword v0, v[1:2], off")
        )

    def test_ds_read(self) -> None:
        assert "type" in _names(
            _highlight_line("  ds_read_b32 v0, v1")
        )


class TestExportOps:
    def test_exp_opcode(self) -> None:
        line = "  exp mrt0, v1, v1, v5, v5 done compr vm"
        assert "tag" in _names(_highlight_line(line))
        assert "exp" in _text_for(line, "tag")

    def test_exp_with_off(self) -> None:
        line = "  exp mrt0, v0, v2, off, off done"
        names = _names(_highlight_line(line))
        assert "tag" in names  # exp opcode
        assert "constant.builtin" in names  # mrt0, off, done


class TestMiscOps:
    def test_lds_param_load(self) -> None:
        line = "  lds_param_load v2, attr0.x wait_vdst:0"
        names = _names(_highlight_line(line))
        assert "function" in names  # lds_param_load


class TestRegisters:
    def test_vector_register(self) -> None:
        frags = _text_for("  v_add_f32 v0, v1, v2", "variable.builtin")
        assert "v0" in frags
        assert "v1" in frags
        assert "v2" in frags

    def test_vector_register_range(self) -> None:
        frags = _text_for("  image_sample v[0:3], v4", "variable.builtin")
        assert any("v[0:3]" in f for f in frags)

    def test_scalar_register(self) -> None:
        frags = _text_for("  s_mov_b32 s0, s1", "variable")
        assert "s0" in frags
        assert "s1" in frags

    def test_scalar_register_range(self) -> None:
        frags = _text_for("  s_load_dword s0, s[4:5], 0x0", "variable")
        assert any("s[4:5]" in f for f in frags)

    def test_special_registers(self) -> None:
        for reg in ("exec", "vcc", "scc", "m0"):
            frags = _text_for(f"  s_mov_b64 {reg}, 0", "variable")
            assert reg in frags, f"{reg} not highlighted as variable"

    def test_exec_lo_hi(self) -> None:
        assert "exec_lo" in _text_for("  s_mov_b32 exec_lo, s0", "variable")


class TestRenderTargets:
    def test_mrt(self) -> None:
        frags = _text_for("  exp mrt0, v0, v1, v2, v3", "constant.builtin")
        assert "mrt0" in frags

    def test_pos(self) -> None:
        frags = _text_for("  exp pos0, v0, v1, v2, v3", "constant.builtin")
        assert "pos0" in frags

    def test_off_operand(self) -> None:
        frags = _text_for("  exp mrt0, v0, v1, off, off", "constant.builtin")
        assert "off" in frags


class TestModifiers:
    def test_done(self) -> None:
        frags = _text_for("  exp mrt0, v0, v1, v2, v3 done", "constant.builtin")
        assert "done" in frags

    def test_compr(self) -> None:
        frags = _text_for("  exp mrt0, v0, v0, v0, v0 done compr vm", "constant.builtin")
        assert "compr" in frags
        assert "vm" in frags

    def test_idxen_offen(self) -> None:
        line = "  tbuffer_load_format_xyzw v[0:3], v4, s[0:3], 0 idxen offen"
        frags = _text_for(line, "constant.builtin")
        assert "idxen" in frags
        assert "offen" in frags

    def test_wait_vdst(self) -> None:
        frags = _text_for("  lds_param_load v2, attr0.x wait_vdst:0", "constant.builtin")
        assert any("wait_vdst:" in f for f in frags)

    def test_glc_slc(self) -> None:
        line = "  buffer_load_dword v0, off, s[0:3], 0 glc slc"
        frags = _text_for(line, "constant.builtin")
        assert "glc" in frags
        assert "slc" in frags


class TestLiterals:
    def test_hex_literal(self) -> None:
        frags = _text_for("  s_mov_b32 s0, 0xFF00FF00", "number")
        assert "0xFF00FF00" in frags

    def test_decimal_literal(self) -> None:
        frags = _text_for("  s_waitcnt vmcnt(0)", "number")
        assert "0" in frags

    def test_negative_float(self) -> None:
        frags = _text_for("  v_add_f32 v0, -0.5, v1", "number")
        assert "-0.5" in frags

    def test_positive_float(self) -> None:
        frags = _text_for("  v_add_f32 v0, 1.0, v1", "number")
        assert "1.0" in frags


class TestLabels:
    def test_label_definition(self) -> None:
        hl = _highlight_line("label_0001:")
        names = _names(hl)
        assert "string" in names

    def test_label_reference(self) -> None:
        frags = _text_for("  s_cbranch_scc1 label_0002", "string")
        assert "label_0002" in frags


class TestAttributes:
    def test_attr(self) -> None:
        frags = _text_for("  v_interp_p1_f32 v0, v1, attr0.x", "constant.builtin")
        assert "attr0.x" in frags

    def test_dmask(self) -> None:
        frags = _text_for("  image_sample v[0:3], v4, s[0:7], s[8:11] dmask:0xf", "constant.builtin")
        assert any("dmask:" in f for f in frags)


class TestMixedLines:
    def test_full_instruction(self) -> None:
        """A realistic instruction should have multiple highlight types."""
        line = "  v_mul_f32 v0, s[0:1], v2  // multiply"
        names = set(_names(_highlight_line(line)))
        assert "function" in names  # v_mul_f32
        assert "variable.builtin" in names  # v0, v2
        assert "variable" in names  # s[0:1]
        assert "comment" in names  # // multiply

    def test_exp_full(self) -> None:
        """A full exp instruction should highlight all parts."""
        line = "  exp mrt0, v1, v1, v5, v5 done compr vm"
        names = set(_names(_highlight_line(line)))
        assert "tag" in names  # exp
        assert "variable.builtin" in names  # v1, v5
        assert "constant.builtin" in names  # mrt0, done, compr, vm

    def test_empty_line(self) -> None:
        assert _highlight_line("") == []
        assert _highlight_line("   ") == []


class TestRealISALines:
    """Test against real assembly lines from isatrace test fixtures.

    These are actual lines from shader dumps. Every opcode and key operand
    must be highlighted. This catches regressions where the highlighting
    looks correct on synthetic examples but misses real patterns.
    """

    def _assert_opcode(self, line: str, opcode: str, expected_name: str) -> None:
        """Assert the opcode token gets the expected highlight name."""
        frags = _text_for(line, expected_name)
        assert opcode in frags, (
            f"Opcode '{opcode}' not highlighted as '{expected_name}' in: {line.strip()}\n"
            f"  Got {expected_name} fragments: {frags}\n"
            f"  All highlights: {[(line[h[0]:h[1]], h[2]) for h in _highlight_line(line)]}"
        )

    def _assert_has_highlights(self, line: str, min_count: int = 2) -> None:
        """Assert the line has at least min_count highlight ranges."""
        hl = _highlight_line(line)
        assert len(hl) >= min_count, (
            f"Only {len(hl)} highlights for: {line.strip()}\n"
            f"  Highlights: {[(line[h[0]:h[1]], h[2]) for h in hl]}"
        )

    # -- Scalar ALU (isatrace: bold yellow → isareplace: keyword) --

    def test_real_s_mov_b32(self) -> None:
        line = "  s_mov_b32     m0, s2                                  // 000000000008: BEFC0302"
        self._assert_opcode(line, "s_mov_b32", "keyword")
        self._assert_has_highlights(line, 3)  # opcode + m0 + s2 + comment

    def test_real_s_and_b64(self) -> None:
        line = "  s_and_b64     exec, exec, s[0:1]                      // 000000000010: 8BFE007E"
        self._assert_opcode(line, "s_and_b64", "keyword")
        assert "exec" in _text_for(line, "variable")

    def test_real_s_cmp_le_u32(self) -> None:
        line = "  s_cmp_le_u32  s0, 3                                   // 000000000050: BF060300"
        self._assert_opcode(line, "s_cmp_le_u32", "keyword")
        assert "s0" in _text_for(line, "variable")

    # -- Vector ALU (isatrace: bold cyan → isareplace: function) --

    def test_real_v_interp_p1_f32(self) -> None:
        line = "  v_interp_p1_f32  v2, v0, attr0.x                      // 000000000014: D7420002 04000200"
        self._assert_opcode(line, "v_interp_p1_f32", "function")
        assert "attr0.x" in _text_for(line, "constant.builtin")
        assert "v2" in _text_for(line, "variable.builtin")

    def test_real_v_add_f32_neg(self) -> None:
        line = "  v_add_f32     v2, -0.5, v2                            // 00000000002C: 060404F1"
        self._assert_opcode(line, "v_add_f32", "function")
        assert "-0.5" in _text_for(line, "number")

    def test_real_v_cvt_pkrtz(self) -> None:
        line = "  v_cvt_pkrtz_f16_f32  v1, v1, v5                       // 000000000034: D5960001 00040B01"
        self._assert_opcode(line, "v_cvt_pkrtz_f16_f32", "function")

    def test_real_v_cmp_gt_f32(self) -> None:
        line = "  v_cmp_gt_f32  vcc, s0, v0                             // 00000000005C: 7C080000"
        self._assert_opcode(line, "v_cmp_gt_f32", "function")
        assert "vcc" in _text_for(line, "variable")

    def test_real_v_cndmask_b32(self) -> None:
        line = "  v_cndmask_b32  v0, s12, v1, vcc                       // 000000000060: 0000020C"
        self._assert_opcode(line, "v_cndmask_b32", "function")

    # -- Memory (isatrace: bold magenta → isareplace: type) --

    def test_real_s_buffer_load_dword(self) -> None:
        line = "  s_buffer_load_dword  s0, s[4:7], null                 // 00000000000C: F4200002 FA000000"
        self._assert_opcode(line, "s_buffer_load_dword", "type")
        assert "s0" in _text_for(line, "variable")
        assert any("s[4:7]" in f for f in _text_for(line, "variable"))

    def test_real_s_buffer_load_dwordx8(self) -> None:
        line = "  s_buffer_load_dwordx8  s[8:15], s[4:7], 0x000010      // 00000000000C: F42C0202 FA000010"
        self._assert_opcode(line, "s_buffer_load_dwordx8", "type")

    def test_real_image_sample(self) -> None:
        line = "  image_sample  v[0:3], [v2,v0], s[4:11], s[12:15] dmask:0xf dim:SQ_RSRC_IMG_2D // 000000000050: F0800F0A 00610002 00000000"
        self._assert_opcode(line, "image_sample", "type")
        assert any("v[0:3]" in f for f in _text_for(line, "variable.builtin"))
        assert any("dmask:" in f for f in _text_for(line, "constant.builtin"))

    # -- Export (isatrace: bold red → isareplace: tag) --

    def test_real_exp_done_compr(self) -> None:
        line = "  exp           mrt0, v1, v1, v5, v5 done compr vm      // 00000000003C: F8001C0F 00000501"
        self._assert_opcode(line, "exp", "tag")
        assert "mrt0" in _text_for(line, "constant.builtin")
        assert "done" in _text_for(line, "constant.builtin")
        assert "compr" in _text_for(line, "constant.builtin")

    def test_real_exp_with_off(self) -> None:
        line = "  exp           mrt0, v0, v2, off, off done             // 000000000088: F8000803 00000200"
        self._assert_opcode(line, "exp", "tag")
        assert "off" in _text_for(line, "constant.builtin")

    # -- Wait/other (isatrace: dim → isareplace: keyword) --

    def test_real_s_waitcnt(self) -> None:
        line = "  s_waitcnt     vmcnt(0)                                 // 000000000040: BF8C0F70"
        self._assert_opcode(line, "s_waitcnt", "keyword")

    def test_real_s_endpgm(self) -> None:
        line = "  s_endpgm                                              // 000000000044: BF810000"
        self._assert_opcode(line, "s_endpgm", "keyword")

    # -- Every line must have at least opcode + comment highlighted --

    REAL_SHADER_LINES = [
        "  s_mov_b32     m0, s2                                  // 000000000008: BEFC0302",
        "  s_buffer_load_dword  s0, s[4:7], null                 // 00000000000C: F4200002 FA000000",
        "  v_interp_p1_f32  v2, v0, attr0.x                      // 000000000014: D7420002 04000200",
        "  v_add_f32     v2, -0.5, v2                            // 00000000002C: 060404F1",
        "  v_cvt_pkrtz_f16_f32  v1, v1, v5                       // 000000000034: D5960001 00040B01",
        "  image_sample  v[0:3], [v2,v0], s[4:11], s[12:15] dmask:0xf dim:SQ_RSRC_IMG_2D // 000000000050: F0800F0A",
        "  exp           mrt0, v1, v1, v5, v5 done compr vm      // 00000000003C: F8001C0F 00000501",
        "  s_waitcnt     vmcnt(0)                                 // 000000000040: BF8C0F70",
        "  s_endpgm                                              // 000000000044: BF810000",
    ]

    def test_every_real_line_has_opcode_highlighted(self) -> None:
        """Every real shader line must have its opcode highlighted (not left plain)."""
        for line in self.REAL_SHADER_LINES:
            hl = _highlight_line(line)
            names = {h[2] for h in hl}
            # Must have at least one opcode-category highlight
            opcode_names = names & {"keyword", "function", "type", "tag"}
            assert opcode_names, (
                f"No opcode highlighted in: {line.strip()}\n"
                f"  All highlights: {[(line[h[0]:h[1]], h[2]) for h in hl]}"
            )

    def test_every_real_line_has_comment_highlighted(self) -> None:
        """Every real shader line with // must have the comment highlighted."""
        for line in self.REAL_SHADER_LINES:
            if "//" in line:
                assert "comment" in _names(_highlight_line(line)), (
                    f"Comment not highlighted in: {line.strip()}"
                )
