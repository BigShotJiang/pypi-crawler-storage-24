"""Smoke tests for the TUI (no external tool needed)."""

from __future__ import annotations

from pathlib import Path

import pytest

from isareplace.binary import parse_binary
from isareplace.tests.conftest import make_test_binary
from isareplace.tui import IsareplaceApp, TuiContext


def _make_ctx(tmp_path: Path, sp3_source: str | None = None) -> TuiContext:
    """Build a TuiContext backed by a synthetic binary."""
    binary = make_test_binary(
        [0xBEFE00FF, 0x80000001, 0x7E000280, 0xD4010001],
        16,
        [0x3F800000, 0x40000000],
    )
    layout = parse_binary(binary)
    return TuiContext(
        layout=layout,
        original_data=binary,
        assembly_text="  s_mov_b32 s0, 0x1\n  v_add_f32 v0, v1, v2\n  s_endpgm\n",
        tool_path="/dev/null",  # won't actually be called
        generation=4,
        shader_type="PS",
        wave_size=32,
        gfxip=4040,
        output_path=tmp_path / "output.bin",
        sp3_source=sp3_source,
    )


@pytest.mark.asyncio
async def test_tui_starts_and_shows_widgets(tmp_path: Path) -> None:
    """TUI should compose without crashing and show the main widgets."""
    ctx = _make_ctx(tmp_path)
    app = IsareplaceApp(ctx)
    async with app.run_test() as pilot:
        # Top bar should contain config info
        top_bar = app.query_one("#top-bar")
        text = top_bar.render()
        # Editor should exist and contain the assembly text
        from isareplace.highlight import ISATextArea
        editor = app.query_one("#editor", ISATextArea)
        assert "s_mov_b32" in editor.text
        # Output pane should exist
        output = app.query_one("#output-pane")
        assert output is not None
        # Status bar should exist
        status = app.query_one("#status-bar")
        assert status is not None


@pytest.mark.asyncio
async def test_tui_help_screen(tmp_path: Path) -> None:
    """Ctrl+H should open the help screen."""
    ctx = _make_ctx(tmp_path)
    app = IsareplaceApp(ctx)
    async with app.run_test() as pilot:
        await pilot.press("ctrl+h")
        await pilot.pause()
        from isareplace.tui import HelpScreen
        assert isinstance(app.screen, HelpScreen)


@pytest.mark.asyncio
async def test_tui_search_toggle(tmp_path: Path) -> None:
    """Ctrl+F should toggle the search input."""
    ctx = _make_ctx(tmp_path)
    app = IsareplaceApp(ctx)
    async with app.run_test() as pilot:
        from textual.widgets import Input
        search = app.query_one("#search-input", Input)
        assert search.display is False
        await pilot.press("ctrl+f")
        assert search.display is True
        await pilot.press("escape")
        assert search.display is False


@pytest.mark.asyncio
async def test_tui_confirm_quit_without_assembly(tmp_path: Path) -> None:
    """Ctrl+Q without successful assembly should show confirm dialog."""
    ctx = _make_ctx(tmp_path)
    app = IsareplaceApp(ctx)
    async with app.run_test() as pilot:
        await pilot.press("ctrl+q")
        await pilot.pause()
        from isareplace.tui import ConfirmQuitScreen
        assert isinstance(app.screen, ConfirmQuitScreen)
        # Press 'n' to cancel
        await pilot.press("n")
        await pilot.pause()
        assert not isinstance(app.screen, ConfirmQuitScreen)


@pytest.mark.asyncio
async def test_tui_sp3_notice(tmp_path: Path) -> None:
    """When sp3_source is set, output pane should show the notice."""
    ctx = _make_ctx(tmp_path, sp3_source="previous.sp3")
    app = IsareplaceApp(ctx)
    async with app.run_test() as pilot:
        # Just verify it mounts without error — the RichLog content
        # is hard to inspect directly, but no crash means the notice logic works
        assert app.query_one("#output-pane") is not None
