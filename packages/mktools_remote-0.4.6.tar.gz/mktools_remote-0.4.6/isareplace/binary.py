"""Core binary parsing and padding logic for shader binary patching."""

from __future__ import annotations

import struct
from dataclasses import dataclass
from enum import Enum

S_ENDPGM: int = 0xBFB00000
S_CODE_END: int = 0xBF9F0000


class PaddingSeverity(Enum):
    """Color threshold for padding consumption display."""
    GREEN = "green"
    YELLOW = "yellow"
    RED = "red"


@dataclass(frozen=True)
class BinaryLayout:
    """Parsed layout of a shader binary.

    Attributes:
        instruction_size: Size of the instruction region in bytes (through end
            of last s_endpgm, inclusive).
        padding_dwords: Number of s_code_end DWORDs in the padding region.
        constants_offset: Byte offset where constants begin.
        constants_blob: Raw bytes of the constants block (may be empty).
    """
    instruction_size: int
    padding_dwords: int
    constants_offset: int
    constants_blob: bytes

    @property
    def instruction_dwords(self) -> int:
        return self.instruction_size // 4

    @property
    def padding_size(self) -> int:
        return self.padding_dwords * 4

    @property
    def total_size(self) -> int:
        return self.constants_offset + len(self.constants_blob)


@dataclass(frozen=True)
class PaddingResult:
    """Result of computing new padding after editing.

    Attributes:
        remaining_dwords: Number of s_code_end padding DWORDs in the output.
        original_dwords: Original padding count (for display).
        delta_dwords: Change in instruction region size (positive = grew).
        severity: Color threshold for the padding status display.
    """
    remaining_dwords: int
    original_dwords: int
    delta_dwords: int
    severity: PaddingSeverity


def parse_binary(data: bytes) -> BinaryLayout:
    """Parse a shader binary into its instruction, padding, and constants regions.

    Scans for the last s_endpgm, counts the contiguous s_code_end padding
    after it, and treats everything remaining as the constants block.

    Raises:
        ValueError: If the binary is not DWORD-aligned or contains no s_endpgm.
    """
    if len(data) % 4 != 0:
        raise ValueError(
            f"Binary size ({len(data)} bytes) is not DWORD-aligned"
        )

    n_dwords = len(data) // 4
    if n_dwords == 0:
        raise ValueError("Binary is empty")

    dwords = struct.unpack(f"<{n_dwords}I", data)

    # Find the last s_endpgm
    last_endpgm = -1
    for i in range(n_dwords - 1, -1, -1):
        if dwords[i] == S_ENDPGM:
            last_endpgm = i
            break

    if last_endpgm == -1:
        raise ValueError("No s_endpgm (0xBFB00000) found in binary")

    # instruction_size includes the s_endpgm DWORD itself
    instruction_size = (last_endpgm + 1) * 4

    # Count contiguous s_code_end padding after s_endpgm
    padding_dwords = 0
    pos = last_endpgm + 1
    while pos < n_dwords and dwords[pos] == S_CODE_END:
        padding_dwords += 1
        pos += 1

    constants_offset = instruction_size + padding_dwords * 4
    constants_blob = data[constants_offset:]

    return BinaryLayout(
        instruction_size=instruction_size,
        padding_dwords=padding_dwords,
        constants_offset=constants_offset,
        constants_blob=constants_blob,
    )


def compute_padding(
    original: BinaryLayout, new_instruction_size: int
) -> PaddingResult:
    """Compute the new padding needed after editing.

    Args:
        original: Layout parsed from the original (unmodified) binary.
        new_instruction_size: Size of the reassembled instruction binary in bytes.

    Returns:
        PaddingResult with the new padding count and severity.

    Raises:
        ValueError: If the new instruction size is not DWORD-aligned or
            exceeds the available space (instructions + padding).
    """
    if new_instruction_size % 4 != 0:
        raise ValueError(
            f"New instruction size ({new_instruction_size} bytes) "
            f"is not DWORD-aligned"
        )

    new_dwords = new_instruction_size // 4
    delta = new_dwords - original.instruction_dwords
    remaining = original.padding_dwords - delta

    if remaining < 0:
        raise ValueError(
            f"Edited shader is too large: {-remaining} DWORD(s) over the limit "
            f"(new instructions: {new_dwords} DWORDs, "
            f"original instructions + padding: "
            f"{original.instruction_dwords + original.padding_dwords} DWORDs)"
        )

    severity = _padding_severity(original.padding_dwords, remaining)

    return PaddingResult(
        remaining_dwords=remaining,
        original_dwords=original.padding_dwords,
        delta_dwords=delta,
        severity=severity,
    )


def assemble_output(
    new_instructions: bytes,
    padding_dwords: int,
    constants: bytes,
) -> bytes:
    """Combine reassembled instructions, adjusted padding, and original constants.

    Args:
        new_instructions: Raw bytes of the reassembled instruction binary.
        padding_dwords: Number of s_code_end DWORDs to insert as padding.
        constants: Raw bytes of the original constants block.

    Returns:
        The complete patched binary.
    """
    padding = struct.pack(f"<{padding_dwords}I", *([S_CODE_END] * padding_dwords)) if padding_dwords > 0 else b""
    return new_instructions + padding + constants


def _padding_severity(original_dwords: int, remaining_dwords: int) -> PaddingSeverity:
    """Determine the color severity for padding consumption.

    Thresholds based on fraction of original padding consumed:
    - Green: <50% consumed
    - Yellow: 50-90% consumed
    - Red: >90% consumed or zero remaining
    """
    if original_dwords == 0:
        # No original padding — always red (any increase fails)
        return PaddingSeverity.RED

    if remaining_dwords == 0:
        return PaddingSeverity.RED

    consumed = original_dwords - remaining_dwords
    fraction = consumed / original_dwords

    if fraction > 0.9:
        return PaddingSeverity.RED
    elif fraction >= 0.5:
        return PaddingSeverity.YELLOW
    else:
        return PaddingSeverity.GREEN
