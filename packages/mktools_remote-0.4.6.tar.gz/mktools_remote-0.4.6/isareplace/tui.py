"""TUI for isareplace — shader assembly editor with binary fixup."""

from __future__ import annotations

import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from rich.style import Style
from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import (
    Input,
    Label,
    RichLog,
    Static,
)

from isareplace.binary import (
    BinaryLayout,
    PaddingResult,
    PaddingSeverity,
    assemble_output,
    compute_padding,
)
from isareplace.external import assemble as ext_assemble
from isareplace.highlight import ISATextArea


# ---------------------------------------------------------------------------
# Data passed into / out of the TUI
# ---------------------------------------------------------------------------

@dataclass
class TuiContext:
    """Everything the TUI needs to operate."""
    layout: BinaryLayout
    original_data: bytes
    assembly_text: str
    tool_path: str
    generation: int
    shader_type: str
    wave_size: int
    gfxip: int
    output_path: Path
    sp3_source: str | None = None  # filename if --sp3 was used


@dataclass
class TuiResult:
    """Returned after the TUI exits."""
    wrote_output: bool = False
    output_path: Path | None = None
    output_sp3: Path | None = None
    output_size: int = 0
    padding_result: PaddingResult | None = None


# ---------------------------------------------------------------------------
# Help screen
# ---------------------------------------------------------------------------

class HelpScreen(ModalScreen[None]):
    BINDINGS = [
        Binding("escape", "dismiss", "Close"),
        Binding("ctrl+h", "dismiss", "Close"),
    ]

    DEFAULT_CSS = """
    HelpScreen {
        align: center middle;
    }
    #help-box {
        width: 76;
        max-height: 36;
        border: solid #585b70;
        background: #1e1e2e;
        padding: 1 2;
    }
    #help-box Label {
        width: 100%;
        margin-bottom: 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="help-box"):
            yield Label(HELP_TEXT)

    def on_key(self, event) -> None:
        if event.key == "escape" or event.key == "ctrl+h":
            return  # handled by binding
        self.dismiss()


HELP_TEXT = """\
[bold]isareplace — Help[/bold]

[bold underline]Key bindings[/bold underline]
  [bold]Ctrl+S[/bold]   Assemble current text and check sizing
  [bold]Ctrl+Q[/bold]   Write output and quit (if assembly succeeded)
  [bold]Ctrl+F[/bold]   Find text in the editor
  [bold]Ctrl+H[/bold]   Show / close this help
  [bold]Escape[/bold]   Close search bar or help overlay

[bold underline]Workflow[/bold underline]
  1. Edit the shader assembly in the editor
  2. Press Ctrl+S to assemble and verify sizing
  3. Repeat: edit → Ctrl+S → edit → Ctrl+S
  4. When satisfied, press Ctrl+Q to write the patched binary

[bold underline]Notes[/bold underline]
  • The input binary is always the unmodified original — it is the
    source of padding and constants, even when resuming a session
  • An edited .sp3 file is saved alongside the output binary so the
    next run auto-resumes from it
  • Sizes are measured in DWORDs (4 bytes), not instruction count,
    because a single instruction can be 1 or 2 DWORDs

[bold underline]Padding display[/bold underline]
  Remaining: X / N DWORDs
  [green]Green[/green]  = less than 50% consumed
  [yellow]Yellow[/yellow] = 50–90% consumed
  [red]Red[/red]    = more than 90% consumed or zero remaining

  [dim]Press any key to close[/dim]\
"""


# ---------------------------------------------------------------------------
# Confirm-quit screen
# ---------------------------------------------------------------------------

class ConfirmQuitScreen(ModalScreen[bool]):
    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    ConfirmQuitScreen {
        align: center middle;
    }
    #confirm-box {
        width: 56;
        height: auto;
        border: solid #f9e2af;
        background: #1e1e2e;
        padding: 1 2;
    }
    #confirm-box Label {
        width: 100%;
        margin-bottom: 1;
    }
    """

    def __init__(self, message: str) -> None:
        super().__init__()
        self._message = message

    def compose(self) -> ComposeResult:
        with Vertical(id="confirm-box"):
            yield Label(self._message)
            yield Label("[bold]y[/bold] = quit without writing    [bold]n[/bold] / [bold]Esc[/bold] = cancel")

    def on_key(self, event) -> None:
        if event.key in ("y", "Y"):
            self.dismiss(True)
        elif event.key in ("n", "N", "escape"):
            self.dismiss(False)

    def action_cancel(self) -> None:
        self.dismiss(False)


# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------

class IsareplaceApp(App):

    CSS = """
    #top-bar {
        dock: top;
        height: 1;
        background: #313244;
        color: #cdd6f4;
        padding: 0 1;
    }

    #editor-container {
        height: 4fr;
    }

    #editor {
        height: 1fr;
    }

    #search-input {
        width: 1fr;
        height: 1;
    }

    #output-pane {
        height: 1fr;
        border-top: solid #585b70;
        min-height: 4;
        scrollbar-size: 1 1;
    }

    #status-bar {
        dock: bottom;
        height: 1;
        background: #313244;
        color: #cdd6f4;
        padding: 0 1;
    }
    """

    BINDINGS = [
        Binding("ctrl+s", "assemble", "Assemble", priority=True),
        Binding("ctrl+q", "quit_app", "Quit", priority=True),
        Binding("ctrl+f", "find", "Find", priority=True),
        Binding("ctrl+h", "show_help", "Help", priority=True),
    ]

    def __init__(self, ctx: TuiContext) -> None:
        super().__init__()
        self.ctx = ctx
        self.result = TuiResult()
        self._assembly_ok = False
        self._modified_since_assembly = False
        self._last_assembled_bytes: bytes | None = None
        self._last_padding: PaddingResult | None = None
        self._last_assembly_text: str = ""
        self._tmpdir = tempfile.mkdtemp(
            prefix=".isareplace_",
            dir=self.ctx.output_path.parent,
        )

    # -- Compose -----------------------------------------------------------

    def compose(self) -> ComposeResult:
        gfx = self.ctx.gfxip
        ws = self.ctx.wave_size
        st = self.ctx.shader_type
        yield Static(
            f" isareplace    [dim]arch:[/] {gfx}  [dim]wave:[/] {ws}  [dim]type:[/] {st}",
            id="top-bar",
        )
        with Vertical(id="editor-container"):
            yield Input(placeholder="Search (Enter=next, Escape=close)", id="search-input")
            yield ISATextArea(
                self.ctx.assembly_text,
                id="editor",
                show_line_numbers=True,
                tab_behavior="indent",
            )
        yield RichLog(id="output-pane", wrap=True, markup=True)
        yield Static(" [dim]READY[/]", id="status-bar")

    def on_mount(self) -> None:
        search = self.query_one("#search-input", Input)
        search.display = False

        log = self.query_one("#output-pane", RichLog)
        layout = self.ctx.layout
        total = len(self.ctx.original_data)

        log.write(f"[bold]Original binary:[/] {total} bytes ({total // 4} DWORDs)")
        log.write(
            f"  Instructions: {layout.instruction_size} bytes "
            f"({layout.instruction_dwords} DWORDs)"
        )
        log.write(f"  Available padding: [bold]{layout.padding_dwords} DWORDs[/]")
        if layout.padding_dwords == 0:
            log.write(
                "[bold red]WARNING: Original binary has zero padding "
                "— any size increase will fail.[/]"
            )
        if layout.constants_blob:
            log.write(f"  Constants: {len(layout.constants_blob)} bytes")
        else:
            log.write("  Constants: none")

        if self.ctx.sp3_source:
            log.write("")
            log.write(
                f"[bold cyan]Resumed from previous session:[/] "
                f"{self.ctx.sp3_source}"
            )
            log.write(
                "[dim]This is edited assembly, not a fresh disassembly from the binary.[/]"
            )

        self.query_one("#editor", ISATextArea).focus()
        self._update_status()

    # -- Text change tracking ----------------------------------------------

    def on_text_area_changed(self, event) -> None:
        self._modified_since_assembly = True
        self._assembly_ok = False
        self._update_status()

    def watch_cursor_location(self) -> None:
        self._update_status()

    def on_text_area_selection_changed(self, event) -> None:
        self._update_status()

    # -- Ctrl+S: assemble --------------------------------------------------

    def action_assemble(self) -> None:
        editor = self.query_one("#editor", ISATextArea)
        text = editor.text
        log = self.query_one("#output-pane", RichLog)
        log.write("")
        log.write("[dim]Assembling...[/]")
        self._do_assembly(text)

    @work(exclusive=True, thread=True)
    def _do_assembly(self, text: str) -> None:
        tmpdir = Path(self._tmpdir)
        sp3_path = tmpdir / "current.sp3"
        sp3_path.write_text(text)

        bin_path = tmpdir / "assembled.bin"
        result = ext_assemble(
            self.ctx.tool_path,
            self.ctx.generation,
            self.ctx.shader_type,
            self.ctx.wave_size,
            sp3_path,
            bin_path,
        )

        if not result.ok:
            error_text = (result.stdout + "\n" + result.stderr).strip()
            self.call_from_thread(self._on_assembly_error, error_text)
            return

        if not bin_path.exists():
            self.call_from_thread(
                self._on_assembly_error, "Assembler produced no output file."
            )
            return

        assembled_bytes = bin_path.read_bytes()

        try:
            padding = compute_padding(self.ctx.layout, len(assembled_bytes))
        except ValueError as e:
            self.call_from_thread(self._on_assembly_error, str(e))
            return

        warnings = result.stderr.strip() if result.has_warnings else None
        self.call_from_thread(
            self._on_assembly_success, assembled_bytes, padding, text, warnings
        )

    def _on_assembly_success(
        self,
        assembled_bytes: bytes,
        padding: PaddingResult,
        text: str,
        warnings: str | None,
    ) -> None:
        self._last_assembled_bytes = assembled_bytes
        self._last_padding = padding
        self._last_assembly_text = text
        self._assembly_ok = True
        self._modified_since_assembly = False

        log = self.query_one("#output-pane", RichLog)

        if warnings:
            log.write(f"[yellow]Assembler warnings:\n{warnings}[/]")

        log.write("[bold green]Assembly successful[/]")
        log.write(
            f"  Original instructions: "
            f"{self.ctx.layout.instruction_dwords} DWORDs"
        )
        new_dwords = len(assembled_bytes) // 4
        log.write(f"  New instructions: {new_dwords} DWORDs")

        sign = "+" if padding.delta_dwords >= 0 else ""
        log.write(f"  Size delta: {sign}{padding.delta_dwords} DWORDs")

        color = _severity_markup_color(padding.severity)
        log.write(
            f"  Padding remaining: [{color}]{padding.remaining_dwords} / "
            f"{padding.original_dwords} DWORDs[/{color}]"
        )

        self._update_status()

    def _on_assembly_error(self, error_text: str) -> None:
        log = self.query_one("#output-pane", RichLog)
        log.write("[bold red]Assembly failed[/]")
        log.write(f"[red]{error_text}[/]")
        self._update_status()

    # -- Ctrl+Q: quit and write --------------------------------------------

    def action_quit_app(self) -> None:
        if self._assembly_ok and not self._modified_since_assembly:
            self._write_output_and_exit()
        else:
            if self._assembly_ok and self._modified_since_assembly:
                msg = (
                    "[bold]You have edits since the last successful assembly.[/]\n"
                    "Quit without writing output?"
                )
            elif not self._assembly_ok:
                msg = (
                    "[bold]Assembly has not succeeded yet.[/]\n"
                    "Quit without writing output?"
                )
            else:
                msg = "Quit without writing output?"

            self.push_screen(ConfirmQuitScreen(msg), self._on_confirm_quit)

    def _on_confirm_quit(self, confirmed: bool) -> None:
        if confirmed:
            self._cleanup_and_exit()

    def _write_output_and_exit(self) -> None:
        output_path = self.ctx.output_path
        output_sp3 = output_path.with_suffix(".sp3")

        final = assemble_output(
            self._last_assembled_bytes,
            self._last_padding.remaining_dwords,
            self.ctx.layout.constants_blob,
        )

        output_path.write_bytes(final)
        output_sp3.write_text(self._last_assembly_text)

        self.result = TuiResult(
            wrote_output=True,
            output_path=output_path,
            output_sp3=output_sp3,
            output_size=len(final),
            padding_result=self._last_padding,
        )
        self._cleanup_and_exit()

    def _cleanup_and_exit(self) -> None:
        shutil.rmtree(self._tmpdir, ignore_errors=True)
        self.exit()

    # -- Ctrl+F: find ------------------------------------------------------

    def action_find(self) -> None:
        search_input = self.query_one("#search-input", Input)
        if search_input.display:
            search_input.display = False
            self.query_one("#editor", ISATextArea).focus()
        else:
            search_input.display = True
            search_input.value = ""
            search_input.focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "search-input":
            self._find_next(event.value)

    def on_key(self, event) -> None:
        search_input = self.query_one("#search-input", Input)
        if event.key == "escape" and search_input.display:
            search_input.display = False
            self.query_one("#editor", ISATextArea).focus()
            event.prevent_default()

    def _find_next(self, query: str) -> None:
        if not query:
            return

        editor = self.query_one("#editor", ISATextArea)
        text = editor.text
        lines = text.split("\n")

        row, col = editor.cursor_location
        offset = col + 1

        for i in range(len(lines)):
            line_idx = (row + i) % len(lines)
            line = lines[line_idx]
            start = offset if i == 0 else 0

            pos = line.lower().find(query.lower(), start)
            if pos != -1:
                from textual.widgets.text_area import Selection
                editor.selection = Selection(
                    start=(line_idx, pos),
                    end=(line_idx, pos + len(query)),
                )
                editor.scroll_cursor_visible()
                return

        log = self.query_one("#output-pane", RichLog)
        log.write(f"[dim]'{query}' not found[/]")

    # -- Ctrl+H: help -----------------------------------------------------

    def action_show_help(self) -> None:
        self.push_screen(HelpScreen())

    # -- Status bar --------------------------------------------------------

    def _update_status(self) -> None:
        bar = self.query_one("#status-bar", Static)
        bar.update(self._format_status())

    def _format_status(self) -> str:
        try:
            editor = self.query_one("#editor", ISATextArea)
        except Exception:
            editor = None

        if self._assembly_ok and not self._modified_since_assembly:
            state = "[bold green]SAVED[/]"
        elif self._modified_since_assembly:
            state = "[bold yellow]MODIFIED[/]"
        else:
            state = "[dim]READY[/]"

        if editor:
            row, col = editor.cursor_location
            cursor = f"Ln {row + 1}, Col {col + 1}"
        else:
            cursor = "Ln 1, Col 1"

        left = f" {state}  {cursor}"

        if self._last_padding:
            new_dwords = len(self._last_assembled_bytes) // 4
            sign = "+" if self._last_padding.delta_dwords >= 0 else ""
            right = f"{new_dwords} DWORDs  ({sign}{self._last_padding.delta_dwords}) "
        else:
            right = f"{self.ctx.layout.instruction_dwords} DWORDs (original) "

        return f"{left}{'':>40}{right}"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _severity_markup_color(severity: PaddingSeverity) -> str:
    return {
        PaddingSeverity.GREEN: "green",
        PaddingSeverity.YELLOW: "yellow",
        PaddingSeverity.RED: "red",
    }[severity]
