"""External assembler/disassembler wrapper.

Handles environment variable resolution, interactive path prompting,
command construction, and subprocess execution.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


def gfxip_to_generation(gfxip: int) -> int:
    """Map a gfxip value to its architecture generation (1-5).

    The tens digit determines the generation: 4010→1, 4020→2, etc.
    """
    gen = (gfxip % 100) // 10
    if gen < 1 or gen > 5:
        raise ValueError(
            f"Unsupported gfxip {gfxip}: generation {gen} is out of range 1-5"
        )
    return gen


def env_var_name(generation: int) -> str:
    """Return the environment variable name for a given generation."""
    return f"SP3_MGFX{generation}"


def asic_name(generation: int) -> str:
    """Return the ASIC name used in external tool commands."""
    return f"MGFX{generation}"


@dataclass
class ToolResult:
    """Result from running the external assembler/disassembler."""
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0

    @property
    def has_warnings(self) -> bool:
        return self.ok and bool(self.stderr.strip())


def resolve_tool_path(generation: int, interactive: bool = True) -> str:
    """Find the external tool path from the environment, prompting if needed.

    Args:
        generation: Architecture generation (1-5).
        interactive: If True and env var is missing, prompt the user.
            If False, raise an error instead.

    Returns:
        Absolute path to the external tool.

    Raises:
        RuntimeError: If the tool path cannot be resolved.
    """
    var = env_var_name(generation)
    path = os.environ.get(var)

    if path and _validate_tool_path(path):
        return path

    if not interactive:
        raise RuntimeError(
            f"The assembler/disassembler path for architecture generation "
            f"{generation} is not configured.\n"
            f"Set the {var} environment variable to the tool path."
        )

    # Interactive prompting
    print(
        f"The assembler/disassembler path for architecture generation "
        f"{generation} is not configured."
    )

    while True:
        try:
            path = input("Please enter the path to the tool: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            raise RuntimeError("Tool path not provided.")

        if not path:
            continue

        path = os.path.expanduser(path)
        path = os.path.abspath(path)

        if _validate_tool_path(path):
            print(
                f"\nTo avoid this prompt in the future, add to your shell profile:\n"
                f"  export {var}={path}\n"
            )
            return path

        print(f"  '{path}' is not a valid executable. Please try again.")


def _validate_tool_path(path: str) -> bool:
    """Check that the path exists and is executable."""
    p = Path(path)
    return p.is_file() and os.access(p, os.X_OK)


def disassemble(
    tool_path: str,
    generation: int,
    input_bin: Path,
    output_sp3: Path,
) -> ToolResult:
    """Run the external disassembler.

    Command: <tool> disparse: asic=MGFX<N> -binary <input> print: <output>
    """
    asic = asic_name(generation)
    cmd = [
        tool_path,
        "disparse:",
        f"asic={asic}",
        "-binary",
        str(input_bin),
        "print:",
        str(output_sp3),
    ]
    return _run(cmd)


def assemble(
    tool_path: str,
    generation: int,
    shader_type: str,
    wave_size: int,
    input_sp3: Path,
    output_bin: Path,
) -> ToolResult:
    """Run the external assembler.

    Command: <tool> compile: asic=MGFX<N> type=<T> wave_size=<W> <input> write: -binary <output>
    """
    asic = asic_name(generation)
    cmd = [
        tool_path,
        "compile:",
        f"asic={asic}",
        f"type={shader_type}",
        f"wave_size={wave_size}",
        str(input_sp3),
        "write:",
        "-binary",
        str(output_bin),
    ]
    return _run(cmd)


def _run(cmd: list[str]) -> ToolResult:
    """Execute a subprocess and capture output."""
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except FileNotFoundError:
        return ToolResult(
            returncode=1,
            stdout="",
            stderr=f"Tool not found: {cmd[0]}",
        )
    except subprocess.TimeoutExpired:
        return ToolResult(
            returncode=1,
            stdout="",
            stderr="External tool timed out after 120 seconds.",
        )
    return ToolResult(
        returncode=proc.returncode,
        stdout=proc.stdout,
        stderr=proc.stderr,
    )
