# mktools

A collection of development tools.

## Getting help

List available tools:

```bash
mktools help
```

View a tool's manual:

```bash
mktools help isatrace
mktools help symbits
```
