"""mktools — A collection of development tools."""

__version__ = "0.1.0"
