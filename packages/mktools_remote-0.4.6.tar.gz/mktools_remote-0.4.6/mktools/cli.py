"""CLI entry point for mktools help system."""

from __future__ import annotations

import importlib.resources
import sys


TOOLS = {
    "isatrace": "isatrace",
    "symbits": "symbits",
}


def main(argv: list[str] | None = None) -> None:
    args = argv if argv is not None else sys.argv[1:]

    if not args or args[0] != "help":
        print("Usage: mktools help <tool>")
        print(f"Available tools: {', '.join(TOOLS)}")
        sys.exit(0)

    if len(args) < 2:
        print("Usage: mktools help <tool>")
        print(f"Available tools: {', '.join(TOOLS)}")
        sys.exit(1)

    tool = args[1]
    if tool not in TOOLS:
        print(f"Unknown tool: {tool}")
        print(f"Available tools: {', '.join(TOOLS)}")
        sys.exit(1)

    package = TOOLS[tool]
    try:
        manual = importlib.resources.files(package).joinpath("MANUAL.md").read_text()
    except (FileNotFoundError, ModuleNotFoundError):
        print(f"Manual not found for {tool}.")
        sys.exit(1)

    print(manual)
