# nirixa/scorer.py
# Lightweight hallucination risk scoring — no external deps needed.
# Uses heuristic patterns to score LLM output confidence.

import re
from typing import Optional


# Phrases that suggest the model is uncertain / hallucinating
UNCERTAINTY_PHRASES = [
    "i'm not sure", "i am not sure", "i think", "i believe", "i'm not certain",
    "it's possible", "it is possible", "might be", "could be", "may be",
    "not entirely sure", "to my knowledge", "as far as i know",
    "i don't have information", "i cannot confirm", "i cannot verify",
    "i'm unable to verify", "approximately", "roughly", "around",
    "it seems", "it appears", "seemingly", "supposedly", "allegedly",
    "some sources say", "according to some", "i recall", "if i remember",
]

# Phrases that suggest confident, grounded responses
CONFIDENCE_PHRASES = [
    "according to", "based on the provided", "the document states",
    "as stated", "as mentioned", "the data shows", "research shows",
    "studies show", "it is known that", "it is established",
]

# Structural risk patterns
HIGH_RISK_PATTERNS = [
    r'\b\d{4}\b',           # years — often hallucinated
    r'\b\d+\.\d+\b',        # version numbers
    r'\b[A-Z][a-z]+ [A-Z][a-z]+\b',  # proper names
    r'https?://\S+',        # URLs — often fabricated
    r'\$[\d,]+',            # dollar amounts
    r'\b\d+%\b',            # percentages
]


def score(
    output: str,
    prompt: Optional[str] = None,
    model:  Optional[str] = None,
) -> dict:
    """
    Score an LLM output for hallucination risk.

    Returns:
        {
            "score": float (0.0 = safe, 1.0 = high risk),
            "risk":  "LOW" | "MEDIUM" | "HIGH",
            "flags": list of detected risk signals
        }
    """
    if not output or not output.strip():
        return {"score": 0.0, "risk": "LOW", "flags": []}

    text   = output.lower()
    flags  = []
    score  = 0.0

    # Uncertainty language
    uncertainty_hits = [p for p in UNCERTAINTY_PHRASES if p in text]
    if uncertainty_hits:
        score += 0.15 * min(len(uncertainty_hits), 3)
        flags.append(f"uncertainty language ({len(uncertainty_hits)} phrases)")

    # Confidence language (negative signal — reduces risk)
    confidence_hits = [p for p in CONFIDENCE_PHRASES if p in text]
    if confidence_hits:
        score -= 0.1 * min(len(confidence_hits), 2)

    # High risk structural patterns
    pattern_hits = []
    for pattern in HIGH_RISK_PATTERNS:
        matches = re.findall(pattern, output)
        if matches:
            pattern_hits.extend(matches[:2])
    if pattern_hits:
        score += 0.05 * min(len(pattern_hits), 4)
        flags.append(f"specific claims detected ({len(pattern_hits)} instances)")

    # Very long output = more surface area for errors
    word_count = len(output.split())
    if word_count > 500:
        score += 0.1
        flags.append("long output (>500 words)")
    elif word_count > 200:
        score += 0.05

    # Model-specific adjustments
    if model:
        m = model.lower()
        if "gpt-4" in m or "claude-3-5" in m or "gemini-1.5-pro" in m:
            score -= 0.05  # frontier models = lower base risk
        elif "gpt-3.5" in m or "mini" in m or "haiku" in m:
            score += 0.05  # smaller models = slightly higher risk

    # Prompt-output length ratio
    if prompt and output:
        ratio = len(output) / max(len(prompt), 1)
        if ratio > 5:
            score += 0.05
            flags.append("output much longer than prompt")

    # Clamp 0–1
    score = max(0.0, min(1.0, score))

    # Risk tier
    if score >= 0.6:
        risk = "HIGH"
    elif score >= 0.3:
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return {
        "score": round(score, 4),
        "risk":  risk,
        "flags": flags,
    }