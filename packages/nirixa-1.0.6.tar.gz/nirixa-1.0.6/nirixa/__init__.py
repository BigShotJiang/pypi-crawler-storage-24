# nirixa/__init__.py

from .client import NirixaClient

__version__ = "1.0.6"
__all__ = ["NirixaClient", "track", "wrap"]

# Module-level singleton — optional convenience API
_client: NirixaClient | None = None


def init(api_key: str, host: str = "https://api.nirixa.in", **kwargs):
    """
    Initialize module-level client for simple usage.

    Usage:
        import nirixa
        nirixa.init(api_key="nirixa-xxx")
        nirixa.track(feature="/api/chat", fn=lambda: openai.chat.completions.create(...))
    """
    global _client
    _client = NirixaClient(api_key=api_key, host=host, **kwargs)
    return _client


def track(feature: str, fn, **kwargs):
    """
    Track an LLM call using the module-level client.
    Call nirixa.init() first.
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.track()")
    return _client.track(feature=feature, fn=fn, **kwargs)


def wrap(client, feature: str, user: str = None):
    """
    Wrap a provider client using the module-level client.
    Call nirixa.init() first.

    Example::

        import nirixa
        from openai import OpenAI

        nirixa.init(api_key="nirixa-xxx")
        ai = nirixa.wrap(OpenAI(), feature="/chat/answer", user=user_id)
        response = ai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello"}],
        )
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.wrap()")
    return _client.wrap(client, feature=feature, user=user)


def get_client() -> NirixaClient:
    """Get the module-level client."""
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') first")
    return _client