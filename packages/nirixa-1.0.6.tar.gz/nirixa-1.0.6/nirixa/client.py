# nirixa/client.py

import time
import uuid
import threading
import requests
from typing import Callable, Optional, Any
from . import scorer as halluc_scorer


def _extract_prompt_from_kwargs(kwargs: dict) -> Optional[str]:
    """Extract the last user message from standard provider call kwargs."""
    # OpenAI / Anthropic / Groq: messages=[{"role": ..., "content": ...}]
    messages = kwargs.get("messages", [])
    if messages:
        user_msgs = [m for m in messages if m.get("role") == "user"]
        if user_msgs:
            content = user_msgs[-1].get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                # Anthropic content blocks: [{"type": "text", "text": "..."}]
                return "\n".join(b.get("text", "") for b in content if b.get("type") == "text")

    # Google Gemini: contents=[{"role": ..., "parts": [...]}] or plain string
    contents = kwargs.get("contents", [])
    if contents:
        if isinstance(contents, str):
            return contents
        user_parts = [c for c in contents if not c.get("role") or c.get("role") == "user"]
        if user_parts:
            parts = user_parts[-1].get("parts", [])
            return "\n".join(p.get("text", "") for p in parts if p.get("text"))

    # Direct prompt string (some APIs)
    if isinstance(kwargs.get("prompt"), str):
        return kwargs["prompt"]

    return None


class _ClientProxy:
    """
    Transparent proxy around any provider client (OpenAI, Anthropic, Groq, ...).
    Every method call is automatically tracked via NirixaClient.track().
    model, provider, and prompt are extracted from the call kwargs.
    """

    __slots__ = ("_target", "_nirixa", "_feature", "_user")

    def __init__(self, target: Any, nirixa: "NirixaClient", feature: str, user: Optional[str]):
        object.__setattr__(self, "_target",  target)
        object.__setattr__(self, "_nirixa",  nirixa)
        object.__setattr__(self, "_feature", feature)
        object.__setattr__(self, "_user",    user)

    def __getattr__(self, name: str):
        target  = object.__getattribute__(self, "_target")
        nirixa  = object.__getattribute__(self, "_nirixa")
        feature = object.__getattribute__(self, "_feature")
        user    = object.__getattribute__(self, "_user")

        val = getattr(target, name)

        if callable(val):
            def _tracked(*args, **kwargs):
                model  = kwargs.get("model")
                prompt = _extract_prompt_from_kwargs(kwargs)
                return nirixa.track(
                    feature=feature,
                    fn=lambda: val(*args, **kwargs),
                    model=model,
                    prompt=prompt,
                    user=user,
                )
            return _tracked

        # Sub-object (e.g. openai.chat → openai.chat.completions) — proxy it too
        if hasattr(val, "__dict__") and not isinstance(val, type):
            return _ClientProxy(val, nirixa, feature, user)

        return val


class NirixaClient:
    """
    Main Nirixa client. Track any LLM call with one line.

    Supported providers:
        - OpenAI       (gpt-4o, gpt-4o-mini, gpt-3.5-turbo, ...)
        - Anthropic    (claude-3-5-sonnet, claude-3-opus, ...)
        - Google       (gemini-1.5-pro, gemini-2.0-flash, ...)
        - Groq         (llama-3.1, mixtral, gemma, ...)
        - Mistral      (mistral-large, mistral-small, ...)
        - Together AI  (llama, qwen, deepseek, ...)
        - Ollama       (llama3, mistral, phi3, local models)
        - AWS Bedrock  (claude, llama, titan, ...)

    Usage:
        client = NirixaClient(api_key="nirixa-xxx")
        result = client.track(
            feature="/api/chat",
            fn=lambda: openai.chat.completions.create(...)
        )
    """

    def __init__(
        self,
        api_key:              str,
        host:                 str  = "https://api.nirixa.in",
        score_hallucinations: bool = True,
        async_ingest:         bool = True,
        debug:                bool = False,
    ):
        self.api_key              = api_key
        self.host                 = host.rstrip("/")
        self.score_hallucinations = score_hallucinations
        self.async_ingest         = async_ingest
        self.debug                = debug
        self._session             = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    "nirixa-python/1.0.5",
        })
        self._threads = []

    # ── Public API ────────────────────────────────────────

    def track(
        self,
        feature:  str,
        fn:       Callable,
        model:    Optional[str] = None,
        provider: Optional[str] = None,
        prompt:   Optional[str] = None,
        user:     Optional[str] = None,
    ) -> Any:
        """
        Wrap any LLM call and track cost, latency, and hallucination risk.

        Args:
            feature:  Your feature/endpoint name e.g. "/api/summarize"
            fn:       Lambda or callable that makes the LLM call
            model:    Model name override (auto-detected for most providers)
            provider: Provider override ("openai", "anthropic", "google", etc.)
            prompt:   Optional prompt text for better hallucination scoring
            user:     Optional end-user identifier (e.g. user ID or email)

        Returns:
            The original LLM response unchanged
        """
        start     = time.time()
        error_msg = None
        response  = None

        try:
            response = fn()
        except Exception as e:
            error_msg = str(e)
            raise
        finally:
            latency_ms = int((time.time() - start) * 1000)
            meta       = self._extract_meta(response, model, provider)

            halluc = {"score": None, "risk": None}
            if self.score_hallucinations and response is not None:
                output_text = self._extract_text(response)
                if output_text:
                    halluc = halluc_scorer.score(
                        output=output_text,
                        prompt=prompt,
                        model=meta["model"],
                    )

            payload = {
                "call_id":           str(uuid.uuid4()),
                "provider":          meta["provider"],
                "model":             meta["model"] or "unknown",
                "feature":           feature,
                "prompt_tokens":     meta["prompt_tokens"],
                "completion_tokens": meta["completion_tokens"],
                "total_tokens":      meta["total_tokens"],
                "cost_usd":          meta["cost_usd"],
                "latency_ms":        latency_ms,
                "halluc_score":      halluc["score"],
                "halluc_risk":       halluc["risk"],
                "error":             error_msg,
                "end_user_id":       user,
                "prompt_text":       prompt,
            }

            if self.async_ingest:
                t = threading.Thread(target=self._ingest, args=(payload,), daemon=True)
                t.start()
                self._threads.append(t)
            else:
                self._ingest(payload)

        return response

    def wrap(self, client: Any, feature: str, user: Optional[str] = None) -> Any:
        """
        Wrap a provider client so every call is tracked automatically.
        model, provider, and prompt are extracted from the call kwargs.

        Args:
            client:  The provider client instance (OpenAI, Anthropic, Groq, ...)
            feature: Your feature/endpoint name e.g. "/api/summarize"
            user:    Optional end-user identifier

        Returns:
            A transparent proxy — use it exactly like the original client.

        Example::

            ai = nirixa.wrap(openai_client, feature="/chat/answer", user=user_id)
            response = ai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello"}],
            )
        """
        return _ClientProxy(client, self, feature, user)

    def flush(self, timeout: float = 5.0):
        """Wait for all pending ingest threads. Call before script exits."""
        for t in self._threads:
            t.join(timeout=timeout)
        self._threads.clear()

    def health(self) -> bool:
        """Check if Nirixa backend is reachable."""
        try:
            r = self._session.get(f"{self.host}/health", timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    # ── Ingest ────────────────────────────────────────────

    def _ingest(self, payload: dict):
        try:
            r = self._session.post(f"{self.host}/ingest", json=payload, timeout=5)
            if self.debug:
                print(f"[nirixa] {payload['feature']} → {r.status_code} ({payload['total_tokens']} tokens, ${payload['cost_usd']})")
        except Exception as e:
            if self.debug:
                print(f"[nirixa] ingest failed: {e}")

    # ── Meta Extraction (per provider) ───────────────────

    def _extract_meta(self, response, model_override, provider_override) -> dict:
        meta = {
            "model":             model_override,
            "provider":          provider_override,
            "prompt_tokens":     0,
            "completion_tokens": 0,
            "total_tokens":      0,
            "cost_usd":          0.0,
        }
        if response is None:
            return meta

        # ── OpenAI & Groq & Together AI & Mistral ──────────
        # All use OpenAI-compatible response format
        if hasattr(response, "usage") and hasattr(response, "choices"):
            usage            = response.usage
            raw_model        = getattr(response, "model", "") or ""
            meta["model"]    = model_override or raw_model
            meta["provider"] = provider_override or self._detect_provider(raw_model)

            if usage:
                meta["prompt_tokens"]     = getattr(usage, "prompt_tokens", 0) or 0
                meta["completion_tokens"] = getattr(usage, "completion_tokens", 0) or 0
                meta["total_tokens"]      = getattr(usage, "total_tokens", 0) or (meta["prompt_tokens"] + meta["completion_tokens"])
                meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        # ── Anthropic ──────────────────────────────────────
        if hasattr(response, "usage") and hasattr(response, "content") and not hasattr(response, "choices"):
            usage            = response.usage
            raw_model        = getattr(response, "model", "") or ""
            meta["model"]    = model_override or raw_model
            meta["provider"] = provider_override or "anthropic"

            if usage:
                meta["prompt_tokens"]     = getattr(usage, "input_tokens", 0) or 0
                meta["completion_tokens"] = getattr(usage, "output_tokens", 0) or 0
                meta["total_tokens"]      = meta["prompt_tokens"] + meta["completion_tokens"]
                meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        # ── Google Gemini (native SDK) ─────────────────────
        # response.usage_metadata.prompt_token_count
        if hasattr(response, "usage_metadata"):
            um               = response.usage_metadata
            meta["model"]    = model_override or getattr(response, "model", "gemini")
            meta["provider"] = provider_override or "google"
            meta["prompt_tokens"]     = getattr(um, "prompt_token_count", 0) or 0
            meta["completion_tokens"] = getattr(um, "candidates_token_count", 0) or 0
            meta["total_tokens"]      = getattr(um, "total_token_count", 0) or (meta["prompt_tokens"] + meta["completion_tokens"])
            meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        # ── Ollama ─────────────────────────────────────────
        # response is a dict: {"model": ..., "prompt_eval_count": ..., "eval_count": ...}
        if isinstance(response, dict) and "prompt_eval_count" in response:
            meta["model"]             = model_override or response.get("model", "ollama")
            meta["provider"]          = provider_override or "ollama"
            meta["prompt_tokens"]     = response.get("prompt_eval_count", 0) or 0
            meta["completion_tokens"] = response.get("eval_count", 0) or 0
            meta["total_tokens"]      = meta["prompt_tokens"] + meta["completion_tokens"]
            meta["cost_usd"]          = 0.0  # local models = free
            return meta

        # ── AWS Bedrock ────────────────────────────────────
        # response["ResponseMetadata"] or response.get("usage")
        if isinstance(response, dict) and "ResponseMetadata" in response:
            meta["provider"] = provider_override or "bedrock"
            body             = response.get("body", {})
            if isinstance(body, dict):
                usage                     = body.get("usage", {})
                meta["model"]             = model_override or response.get("model", "bedrock")
                meta["prompt_tokens"]     = usage.get("input_tokens", 0) or 0
                meta["completion_tokens"] = usage.get("output_tokens", 0) or 0
                meta["total_tokens"]      = meta["prompt_tokens"] + meta["completion_tokens"]
                meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        return meta

    def _detect_provider(self, model: str) -> str:
        """Auto-detect provider from model name."""
        m = model.lower()
        if any(x in m for x in ["gpt", "o1", "o3", "text-davinci"]):
            return "openai"
        if any(x in m for x in ["claude"]):
            return "anthropic"
        if any(x in m for x in ["gemini"]):
            return "google"
        if any(x in m for x in ["llama", "mixtral", "gemma", "whisper"]):
            # Could be Groq, Together, or Ollama — default groq for API calls
            return "groq"
        if any(x in m for x in ["mistral", "codestral"]):
            return "mistral"
        if any(x in m for x in ["qwen", "deepseek", "falcon"]):
            return "together"
        return "unknown"

    def _extract_text(self, response) -> Optional[str]:
        """Extract text output for hallucination scoring."""
        try:
            # OpenAI / Groq / Together / Mistral
            if hasattr(response, "choices"):
                return response.choices[0].message.content or ""
            # Anthropic
            if hasattr(response, "content") and isinstance(response.content, list):
                return getattr(response.content[0], "text", "") or ""
            # Gemini
            if hasattr(response, "candidates"):
                return response.candidates[0].content.parts[0].text or ""
            # Ollama
            if isinstance(response, dict) and "response" in response:
                return response["response"] or ""
            # Bedrock (Claude via Bedrock)
            if isinstance(response, dict) and "content" in response:
                content = response["content"]
                if isinstance(content, list) and content:
                    return content[0].get("text", "") or ""
        except Exception:
            pass
        return None

    def _calc_cost(self, model: str, prompt_tokens: int, completion_tokens: int) -> float:
        """Estimate USD cost. Prices per 1M tokens [input, output]."""
        if not model:
            return 0.0

        m = model.lower()

        PRICES = {
            # OpenAI
            "gpt-4o":               (2.50,   10.00),
            "gpt-4o-mini":          (0.15,    0.60),
            "gpt-4-turbo":          (10.00,  30.00),
            "gpt-4":                (30.00,  60.00),
            "gpt-3.5-turbo":        (0.50,   1.50),
            "o1":                   (15.00,  60.00),
            "o3-mini":              (1.10,   4.40),
            # Anthropic
            "claude-3-5-sonnet":    (3.00,   15.00),
            "claude-3-5-haiku":     (0.80,   4.00),
            "claude-3-opus":        (15.00,  75.00),
            "claude-3-sonnet":      (3.00,   15.00),
            "claude-3-haiku":       (0.25,   1.25),
            # Google
            "gemini-2.5-flash":     (0.15,   0.60),
            "gemini-2.0-flash":     (0.10,   0.40),
            "gemini-1.5-pro":       (3.50,   10.50),
            "gemini-1.5-flash":     (0.35,   1.05),
            "gemini-1.0-pro":       (0.50,   1.50),
            # Groq (very cheap)
            "llama-3.1-70b":        (0.59,   0.79),
            "llama-3.1-8b":         (0.05,   0.08),
            "llama-3.3-70b":        (0.59,   0.79),
            "mixtral-8x7b":         (0.24,   0.24),
            "gemma2-9b":            (0.20,   0.20),
            # Mistral
            "mistral-large":        (2.00,   6.00),
            "mistral-small":        (0.20,   0.60),
            "codestral":            (0.20,   0.60),
            "mistral-7b":           (0.25,   0.25),
            # Together AI
            "llama-3-70b":          (0.90,   0.90),
            "llama-3-8b":           (0.20,   0.20),
            "deepseek-r1":          (0.55,   2.19),
            "qwen2.5-72b":          (1.20,   1.20),
            # Ollama — free (local)
            "ollama":               (0.00,   0.00),
        }

        for key, (input_price, output_price) in PRICES.items():
            if key in m:
                cost = (prompt_tokens * input_price + completion_tokens * output_price) / 1_000_000
                return round(cost, 8)

        # Fallback
        return round((prompt_tokens * 0.50 + completion_tokens * 1.50) / 1_000_000, 8)