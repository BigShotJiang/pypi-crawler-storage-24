# nirixa/middleware.py
# Auto-patchers for all major LLM providers.
# One call tracks everything without changing your existing code.

from .client import NirixaClient


def patch_openai(client: NirixaClient, feature: str = "/api/openai"):
    """Auto-track all OpenAI chat completions."""
    try:
        import openai as _openai
        original = _openai.chat.completions.create

        def tracked(*args, **kwargs):
            return client.track(
                feature=feature,
                model=kwargs.get("model", "gpt-4o"),
                provider="openai",
                prompt=str(kwargs.get("messages", "")),
                fn=lambda: original(*args, **kwargs),
            )
        _openai.chat.completions.create = tracked
        print(f"[nirixa] ✓ OpenAI patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_anthropic(client: NirixaClient, feature: str = "/api/anthropic"):
    """Auto-track all Anthropic messages."""
    try:
        import anthropic as _anthropic
        original = _anthropic.resources.messages.Messages.create

        def tracked(self_ref, *args, **kwargs):
            return client.track(
                feature=feature,
                model=kwargs.get("model", "claude-3-5-sonnet-20241022"),
                provider="anthropic",
                prompt=str(kwargs.get("messages", "")),
                fn=lambda: original(self_ref, *args, **kwargs),
            )
        _anthropic.resources.messages.Messages.create = tracked
        print(f"[nirixa] ✓ Anthropic patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_groq(client: NirixaClient, feature: str = "/api/groq"):
    """Auto-track all Groq completions (Llama, Mixtral, Gemma)."""
    try:
        import groq as _groq
        original = _groq.resources.chat.completions.Completions.create

        def tracked(self_ref, *args, **kwargs):
            return client.track(
                feature=feature,
                model=kwargs.get("model", "llama-3.1-70b-versatile"),
                provider="groq",
                prompt=str(kwargs.get("messages", "")),
                fn=lambda: original(self_ref, *args, **kwargs),
            )
        _groq.resources.chat.completions.Completions.create = tracked
        print(f"[nirixa] ✓ Groq patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_gemini(client: NirixaClient, feature: str = "/api/gemini"):
    """Auto-track all Google Gemini generate_content calls."""
    try:
        import google.generativeai as genai
        original = genai.GenerativeModel.generate_content

        def tracked(self_ref, *args, **kwargs):
            return client.track(
                feature=feature,
                model=getattr(self_ref, "model_name", "gemini-1.5-pro"),
                provider="google",
                prompt=str(args[0] if args else kwargs.get("contents", "")),
                fn=lambda: original(self_ref, *args, **kwargs),
            )
        genai.GenerativeModel.generate_content = tracked
        print(f"[nirixa] ✓ Gemini patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_mistral(client: NirixaClient, feature: str = "/api/mistral"):
    """Auto-track all Mistral AI completions."""
    try:
        from mistralai import Mistral as _Mistral
        original = _Mistral.chat.complete

        def tracked(self_ref, *args, **kwargs):
            return client.track(
                feature=feature,
                model=kwargs.get("model", "mistral-large-latest"),
                provider="mistral",
                prompt=str(kwargs.get("messages", "")),
                fn=lambda: original(self_ref, *args, **kwargs),
            )
        _Mistral.chat.complete = tracked
        print(f"[nirixa] ✓ Mistral patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_together(client: NirixaClient, feature: str = "/api/together"):
    """Auto-track all Together AI completions."""
    try:
        import together as _together
        original = _together.Complete.create

        def tracked(*args, **kwargs):
            return client.track(
                feature=feature,
                model=kwargs.get("model", "meta-llama/Llama-3-70b-chat-hf"),
                provider="together",
                prompt=str(kwargs.get("prompt", "")),
                fn=lambda: original(*args, **kwargs),
            )
        _together.Complete.create = tracked
        print(f"[nirixa] ✓ Together AI patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_ollama(client: NirixaClient, feature: str = "/api/ollama"):
    """Auto-track all Ollama chat calls (local models)."""
    try:
        import ollama as _ollama
        original = _ollama.chat

        def tracked(*args, **kwargs):
            return client.track(
                feature=feature,
                model=kwargs.get("model", args[0] if args else "llama3"),
                provider="ollama",
                prompt=str(kwargs.get("messages", "")),
                fn=lambda: original(*args, **kwargs),
            )
        _ollama.chat = tracked
        print(f"[nirixa] ✓ Ollama patched → tracking '{feature}'")
        return True
    except ImportError:
        return False


def patch_all(client: NirixaClient, feature: str = "/api/llm"):
    """
    Patch all installed LLM providers at once.

    Usage:
        from nirixa import NirixaClient
        from nirixa.middleware import patch_all

        nirixa = NirixaClient(api_key="nirixa-xxx")
        patch_all(nirixa)   # patches everything installed
    """
    patched = []
    for name, fn in [
        ("OpenAI",     lambda: patch_openai(client, feature)),
        ("Anthropic",  lambda: patch_anthropic(client, feature)),
        ("Groq",       lambda: patch_groq(client, feature)),
        ("Gemini",     lambda: patch_gemini(client, feature)),
        ("Mistral",    lambda: patch_mistral(client, feature)),
        ("Together",   lambda: patch_together(client, feature)),
        ("Ollama",     lambda: patch_ollama(client, feature)),
    ]:
        if fn():
            patched.append(name)

    print(f"[nirixa] Patched {len(patched)} providers: {', '.join(patched)}")
    return patched