"""Ventilation analysis helpers."""
