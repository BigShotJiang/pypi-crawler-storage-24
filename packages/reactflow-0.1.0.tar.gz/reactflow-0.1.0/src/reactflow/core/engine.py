"""
ReAct Engine - Core execution engine for the ReAct paradigm.
"""

from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass
import re
import json
import time

from .state import AgentState, Action
from .result import AgentResult, AgentStep, Trajectory


@dataclass
class LLMConfig:
    """LLM configuration"""
    provider: str = "openai"
    model: str = "gpt-4"
    temperature: float = 0.7
    max_tokens: int = 4096


class ReActEngine:
    """
    Core ReAct execution engine.

    Implements the Thought-Action-Observation loop.
    """

    # Prompt templates
    SYSTEM_PROMPT = """You are a ReAct (Reasoning + Acting) agent that solves problems through thinking and taking actions.

## Your Capabilities
- **Think**: Analyze the problem and plan your approach
- **Act**: Use tools to gather information or perform tasks
- **Observe**: Learn from the results of your actions

## Available Tools
{tools_description}

## Response Format
You MUST respond in one of these two formats:

### To take an action:
Thought: [Your reasoning about what to do next]
Action: [tool_name]
Action Input: {{"param1": "value1", "param2": "value2"}}

### To provide final answer:
Thought: [Your final reasoning]
Final Answer: [Your answer to the user]

## Important Rules
1. Always start with "Thought:" to explain your reasoning
2. You can only use tools from the available tools list
3. Action Input must be valid JSON
4. When you have the answer, use "Final Answer:" to conclude
5. Be concise and focused in your thoughts
"""

    def __init__(
        self,
        tools: Dict[str, Callable],
        llm_config: Optional[LLMConfig] = None,
        max_steps: int = 10,
        debug: bool = False
    ):
        """
        Initialize the ReAct engine.

        Args:
            tools: Dictionary mapping tool names to functions
            llm_config: LLM configuration
            max_steps: Maximum number of steps before stopping
            debug: Enable debug logging
        """
        self.tools = tools
        self.llm_config = llm_config or LLMConfig()
        self.max_steps = max_steps
        self.debug = debug

        # Initialize LLM client
        self._llm_client = None

    @property
    def llm_client(self):
        """Lazy initialization of LLM client"""
        if self._llm_client is None:
            if self.llm_config.provider == "openai":
                from openai import OpenAI
                self._llm_client = OpenAI()
            else:
                raise ValueError(f"Unsupported provider: {self.llm_config.provider}")
        return self._llm_client

    def _format_tools_description(self) -> str:
        """Format tools for the system prompt"""
        lines = []
        for name, func in self.tools.items():
            doc = func.__doc__ or f"Tool: {name}"
            # Extract first line of docstring
            first_line = doc.strip().split("\n")[0]
            lines.append(f"- **{name}**: {first_line}")
        return "\n".join(lines)

    def _build_messages(self, state: AgentState) -> List[Dict[str, str]]:
        """Build message list for LLM call"""
        messages = [
            {
                "role": "system",
                "content": self.SYSTEM_PROMPT.format(
                    tools_description=self._format_tools_description()
                )
            }
        ]

        # Add conversation history
        for step in state.steps:
            if step.thought:
                user_content = f"Thought: {step.thought}"
                if step.action:
                    action_input = json.dumps(step.action.args)
                    user_content += f"\nAction: {step.action.tool_name}\nAction Input: {action_input}"

                messages.append({"role": "assistant", "content": user_content})

            if step.observation:
                messages.append({
                    "role": "user",
                    "content": f"Observation: {step.observation}"
                })

        # Add current task prompt
        if state.step_count == 0:
            messages.append({
                "role": "user",
                "content": f"Task: {state.task}\n\nPlease start by thinking about how to approach this task."
            })
        else:
            messages.append({
                "role": "user",
                "content": "Continue with the next step or provide your final answer."
            })

        return messages

    def _call_llm(self, messages: List[Dict[str, str]]) -> str:
        """Make LLM API call"""
        start_time = time.time()

        response = self.llm_client.chat.completions.create(
            model=self.llm_config.model,
            messages=messages,
            temperature=self.llm_config.temperature,
            max_tokens=self.llm_config.max_tokens
        )

        latency = int((time.time() - start_time) * 1000)

        if self.debug:
            print(f"[LLM] Latency: {latency}ms")
            print(f"[LLM] Response: {response.choices[0].message.content[:200]}...")

        return response.choices[0].message.content

    def _parse_response(self, response: str) -> tuple[Optional[str], Optional[Action]]:
        """
        Parse LLM response to extract thought and action.

        Returns:
            Tuple of (thought, action)
        """
        thought = None
        action = None

        # Extract thought
        thought_match = re.search(r"Thought:\s*(.+?)(?=\n(?:Action|Final Answer)|$)", response, re.DOTALL)
        if thought_match:
            thought = thought_match.group(1).strip()

        # Check for final answer
        final_match = re.search(r"Final Answer:\s*(.+)$", response, re.DOTALL)
        if final_match:
            action = Action(
                tool_name="finish",
                args={"answer": final_match.group(1).strip()}
            )
            return thought, action

        # Extract action
        action_match = re.search(r"Action:\s*(\w+)\s*\n\s*Action Input:\s*(.+?)(?=\n\n|$)", response, re.DOTALL)
        if action_match:
            tool_name = action_match.group(1).strip()
            try:
                args = json.loads(action_match.group(2).strip())
            except json.JSONDecodeError:
                # If JSON parsing fails, treat as single argument
                args = {"input": action_match.group(2).strip().strip('"')}

            action = Action(tool_name=tool_name, args=args)

        return thought, action

    def _execute_action(self, action: Action) -> str:
        """Execute an action and return observation"""
        if action.is_finish():
            return "Task completed."

        if action.tool_name not in self.tools:
            return f"Error: Unknown tool '{action.tool_name}'. Available tools: {list(self.tools.keys())}"

        try:
            tool_func = self.tools[action.tool_name]
            result = tool_func(**action.args)
            return str(result)
        except Exception as e:
            return f"Error executing {action.tool_name}: {str(e)}"

    def _detect_loop(self, state: AgentState) -> bool:
        """Detect if agent is stuck in a loop"""
        if state.step_count < 3:
            return False

        # Check for repeated actions
        recent_actions = [
            step.action.tool_name
            for step in state.steps[-3:]
            if step.action
        ]

        if len(recent_actions) == 3 and len(set(recent_actions)) == 1:
            return True

        # Check for repeated thoughts
        recent_thoughts = [
            step.thought[:50] if step.thought else ""
            for step in state.steps[-2:]
        ]

        if len(recent_thoughts) == 2 and recent_thoughts[0] == recent_thoughts[1]:
            return True

        return False

    def run(self, task: str) -> AgentResult:
        """
        Execute the ReAct loop for a given task.

        Args:
            task: The task to solve

        Returns:
            AgentResult with the answer and trajectory
        """
        # Initialize state
        state = AgentState(task=task)
        trajectory = Trajectory(task=task)

        try:
            while state.step_count < self.max_steps:
                # Build messages and call LLM
                messages = self._build_messages(state)
                response = self._call_llm(messages)

                # Parse response
                thought, action = self._parse_response(response)

                if not thought and not action:
                    # Failed to parse, try again with hint
                    thought = "I need to provide a clearer response."
                    action = None

                # Create step
                step = AgentStep(
                    step_number=state.step_count + 1,
                    thought=thought,
                    action=action,
                    tokens_used=len(response) // 3  # Rough estimate
                )

                # Execute action if present
                if action and not action.is_finish():
                    observation = self._execute_action(action)
                    step.observation = observation

                    if self.debug:
                        print(f"\n[Step {step.step_number}]")
                        print(f"Thought: {thought}")
                        print(f"Action: {action}")
                        print(f"Observation: {observation[:200]}...")

                # Add step to state and trajectory
                state.add_step(step)
                trajectory.add_step(step)

                # Check for completion
                if action and action.is_finish():
                    trajectory.complete(success=True)
                    return AgentResult(
                        success=True,
                        answer=action.args.get("answer", "Task completed."),
                        trajectory=trajectory,
                        total_tokens=state.total_tokens,
                        total_cost=state.total_cost,
                        execution_time=(trajectory.end_time - trajectory.start_time).total_seconds()
                    )

                # Check for loops
                if self._detect_loop(state):
                    trajectory.complete(success=False)
                    return AgentResult(
                        success=False,
                        error="Loop detected - agent is stuck repeating actions.",
                        trajectory=trajectory,
                        total_tokens=state.total_tokens,
                        total_cost=state.total_cost
                    )

            # Max steps reached
            trajectory.complete(success=False)
            return AgentResult(
                success=False,
                error=f"Maximum steps ({self.max_steps}) reached without completing the task.",
                trajectory=trajectory,
                total_tokens=state.total_tokens,
                total_cost=state.total_cost
            )

        except Exception as e:
            trajectory.complete(success=False)
            return AgentResult(
                success=False,
                error=f"Execution error: {str(e)}",
                trajectory=trajectory,
                total_tokens=state.total_tokens,
                total_cost=state.total_cost
            )