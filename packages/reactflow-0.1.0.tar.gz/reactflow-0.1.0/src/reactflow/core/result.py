"""
Agent Result and Trajectory Types
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
import json


@dataclass
class AgentStep:
    """
    A single step in the agent's execution.

    Each step consists of:
    - A thought (reasoning)
    - An action (tool call)
    - An observation (result of action)
    """
    step_number: int
    thought: Optional[str] = None
    action: Optional['Action'] = None
    observation: Optional[str] = None
    tokens_used: int = 0
    latency_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "step_number": self.step_number,
            "thought": self.thought,
            "action": {
                "tool": self.action.tool_name,
                "args": self.action.args
            } if self.action else None,
            "observation": self.observation,
            "tokens_used": self.tokens_used,
            "latency_ms": self.latency_ms
        }


@dataclass
class AgentResult:
    """
    The final result of an agent execution.

    Contains:
    - Success status
    - Final answer
    - Complete trajectory
    - Statistics
    """
    success: bool
    answer: str = ""
    trajectory: 'Trajectory' = None
    total_tokens: int = 0
    total_cost: float = 0.0
    execution_time: float = 0.0
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "success": self.success,
            "answer": self.answer,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
            "execution_time": self.execution_time,
            "error": self.error,
            "trajectory": self.trajectory.to_dict() if self.trajectory else None
        }

    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


@dataclass
class Trajectory:
    """
    Complete execution trajectory.

    Records all steps and metadata about the execution.
    """
    task: str
    steps: List[AgentStep] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    status: str = "running"  # running, completed, failed

    @property
    def total_tokens(self) -> int:
        """Sum of all tokens used"""
        return sum(step.tokens_used for step in self.steps)

    @property
    def total_steps(self) -> int:
        """Number of steps"""
        return len(self.steps)

    def add_step(self, step: AgentStep) -> None:
        """Add a step to the trajectory"""
        self.steps.append(step)

    def complete(self, success: bool = True) -> None:
        """Mark trajectory as complete"""
        self.end_time = datetime.now()
        self.status = "completed" if success else "failed"

    def to_markdown(self) -> str:
        """Export trajectory as Markdown"""
        lines = [
            f"# Agent Trajectory",
            f"",
            f"**Task**: {self.task}",
            f"**Status**: {self.status}",
            f"**Steps**: {self.total_steps}",
            f"**Total Tokens**: {self.total_tokens}",
            f"",
            "---",
            ""
        ]

        for step in self.steps:
            lines.append(f"## Step {step.step_number}")
            lines.append("")

            if step.thought:
                lines.append("### Thought")
                lines.append("```")
                lines.append(step.thought)
                lines.append("```")
                lines.append("")

            if step.action:
                lines.append("### Action")
                lines.append("```")
                lines.append(str(step.action))
                lines.append("```")
                lines.append("")

            if step.observation:
                lines.append("### Observation")
                lines.append("```")
                obs_text = step.observation[:500] + ('...' if len(step.observation) > 500 else '')
                lines.append(obs_text)
                lines.append("```")
                lines.append("")

            lines.append("---")
            lines.append("")

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "task": self.task,
            "status": self.status,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "total_steps": self.total_steps,
            "total_tokens": self.total_tokens,
            "steps": [step.to_dict() for step in self.steps]
        }

    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    def export(self, filepath: str, format: str = "json") -> None:
        """
        Export trajectory to file.

        Args:
            filepath: Output file path
            format: 'json' or 'markdown'
        """
        with open(filepath, "w", encoding="utf-8") as f:
            if format == "markdown":
                f.write(self.to_markdown())
            else:
                f.write(self.to_json())