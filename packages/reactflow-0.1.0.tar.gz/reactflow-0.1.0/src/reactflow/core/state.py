"""
Agent State Management
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime
import json


@dataclass
class Action:
    """Represents an action the agent wants to take"""
    tool_name: str
    args: Dict[str, Any]

    def is_finish(self) -> bool:
        """Check if this action is a finish/complete action"""
        return self.tool_name.lower() in ("finish", "final_answer")

    def to_json(self) -> str:
        """Serialize to JSON"""
        return json.dumps({
            "tool": self.tool_name,
            "args": self.args
        })

    @classmethod
    def from_json(cls, json_str: str) -> 'Action':
        """Deserialize from JSON"""
        data = json.loads(json_str)
        return cls(
            tool_name=data["tool"],
            args=data.get("args", {})
        )

    def __str__(self) -> str:
        args_str = ", ".join(f"{k}={repr(v)}" for k, v in self.args.items())
        return f"{self.tool_name}({args_str})"


@dataclass
class AgentState:
    """
    Maintains the state of an agent execution.

    Tracks:
    - The original task
    - All steps taken
    - Token usage
    - Cost tracking
    """
    task: str
    steps: List['AgentStep'] = field(default_factory=list)
    total_tokens: int = 0
    total_cost: float = 0.0
    start_time: datetime = field(default_factory=datetime.now)
    current_thought: Optional[str] = None

    @property
    def step_count(self) -> int:
        """Number of steps taken"""
        return len(self.steps)

    @property
    def history(self) -> List[Dict[str, Any]]:
        """
        Get formatted history for prompt context.

        Returns a list of dicts with thought, action, observation.
        """
        return [
            {
                "thought": step.thought,
                "action": step.action.tool_name if step.action else None,
                "action_input": step.action.args if step.action else None,
                "observation": step.observation
            }
            for step in self.steps
            if step.thought or step.action
        ]

    def add_step(self, step: 'AgentStep') -> None:
        """Add a step and update totals"""
        self.steps.append(step)
        self.total_tokens += step.tokens_used
        # Rough cost estimation: $0.03/1K input tokens, $0.06/1K output tokens
        self.total_cost += step.tokens_used * 0.000045

    def get_last_observation(self) -> Optional[str]:
        """Get the most recent observation"""
        if self.steps:
            return self.steps[-1].observation
        return None

    def get_final_answer(self) -> str:
        """Extract the final answer if available"""
        for step in reversed(self.steps):
            if step.action and step.action.is_finish():
                return step.action.args.get("answer", step.action.args.get("content", ""))
        # If no explicit finish, return last thought
        if self.steps:
            return self.steps[-1].thought or "Task completed."
        return "No answer generated."