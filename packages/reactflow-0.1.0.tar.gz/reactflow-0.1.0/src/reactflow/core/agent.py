"""
ReActFlow Agent - Main agent class for user interaction.
"""

from typing import Optional, List, Union, Callable, Dict, Any
import os

from .engine import ReActEngine, LLMConfig
from .state import Action
from .result import AgentResult, Trajectory
from ..tools.base import Tool


class Agent:
    """
    ReActFlow Agent - A lightweight, observable ReAct agent.

    Example:
        ```python
        from reactflow import Agent, Tool

        @Tool.define
        def search(query: str) -> str:
            '''Search the web for information'''
            return f"Results for: {query}"

        agent = Agent(tools=[search])
        result = agent.run("What is the weather in Tokyo?")
        print(result.answer)
        ```
    """

    def __init__(
        self,
        tools: Optional[List[Union[Tool, Callable]]] = None,
        model: str = "gpt-4",
        max_steps: int = 10,
        debug: bool = False,
        api_key: Optional[str] = None,
        temperature: float = 0.7
    ):
        """
        Initialize a ReAct agent.

        Args:
            tools: List of tools (functions or Tool instances)
            model: LLM model to use
            max_steps: Maximum number of reasoning steps
            debug: Enable debug output
            api_key: OpenAI API key (defaults to OPENAI_API_KEY env var)
            temperature: LLM temperature
        """
        self.model = model
        self.max_steps = max_steps
        self.debug = debug
        self.temperature = temperature

        # Set API key if provided
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key

        # Process tools
        self.tools: Dict[str, Callable] = {}
        self._process_tools(tools or [])

        # Add default finish tool
        if "finish" not in self.tools:
            self.tools["finish"] = self._finish_tool

        # Initialize engine
        llm_config = LLMConfig(
            model=model,
            temperature=temperature
        )
        self._engine = ReActEngine(
            tools=self.tools,
            llm_config=llm_config,
            max_steps=max_steps,
            debug=debug
        )

        # Store last result
        self._last_result: Optional[AgentResult] = None

    def _process_tools(self, tools: List[Union[Tool, Callable]]) -> None:
        """Process and register tools"""
        for tool in tools:
            if isinstance(tool, Tool):
                self.tools[tool.name] = tool.func
            elif callable(tool):
                # Get tool name and description from function
                name = getattr(tool, "_tool_name", tool.__name__)
                self.tools[name] = tool
            else:
                raise ValueError(f"Invalid tool type: {type(tool)}")

    @staticmethod
    def _finish_tool(answer: str = "") -> str:
        """Finish the task with an answer"""
        return f"[FINISHED] {answer}"

    def add_tool(self, tool: Union[Tool, Callable]) -> None:
        """
        Add a tool to the agent.

        Args:
            tool: Tool function or Tool instance
        """
        if isinstance(tool, Tool):
            self.tools[tool.name] = tool.func
        elif callable(tool):
            name = getattr(tool, "_tool_name", tool.__name__)
            self.tools[name] = tool
        else:
            raise ValueError(f"Invalid tool type: {type(tool)}")

        # Update engine tools
        self._engine.tools = self.tools

    def run(self, task: str) -> AgentResult:
        """
        Execute a task.

        Args:
            task: The task to solve

        Returns:
            AgentResult containing the answer and execution details
        """
        self._last_result = self._engine.run(task)
        return self._last_result

    def get_trajectory(self) -> Optional[Trajectory]:
        """
        Get the trajectory from the last execution.

        Returns:
            Trajectory object or None if no execution yet
        """
        if self._last_result:
            return self._last_result.trajectory
        return None

    def get_result(self) -> Optional[AgentResult]:
        """
        Get the result from the last execution.

        Returns:
            AgentResult or None if no execution yet
        """
        return self._last_result

    def reset(self) -> None:
        """Reset the agent state"""
        self._last_result = None

    def __repr__(self) -> str:
        return f"Agent(model={self.model}, tools={list(self.tools.keys())}, max_steps={self.max_steps})"


def quick_agent(task: str, tools: Optional[List[Callable]] = None) -> str:
    """
    Quick helper to run a single task with minimal setup.

    Args:
        task: Task to execute
        tools: Optional list of tool functions

    Returns:
        The answer string

    Example:
        ```python
        answer = quick_agent("What is 2+2?")
        print(answer)  # "4"
        ```
    """
    agent = Agent(tools=tools)
    result = agent.run(task)
    return result.answer