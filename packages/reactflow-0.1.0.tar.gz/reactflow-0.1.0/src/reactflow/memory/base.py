"""
Memory Base Classes for ReActFlow
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Memory:
    """
    A single memory unit.
    """
    content: str
    role: str = "user"  # user, assistant, system
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


class MemoryBase(ABC):
    """Abstract base class for memory systems"""

    @abstractmethod
    def add(self, memory: Memory) -> None:
        """Add a memory"""
        pass

    @abstractmethod
    def get_recent(self, n: int = 10) -> List[Memory]:
        """Get the most recent n memories"""
        pass

    @abstractmethod
    def clear(self) -> None:
        """Clear all memories"""
        pass

    @abstractmethod
    def to_messages(self) -> List[Dict[str, str]]:
        """Convert to message format for LLM"""
        pass


class ShortTermMemory(MemoryBase):
    """
    Short-term memory with a fixed-size buffer.

    Keeps the most recent messages in memory.
    """

    def __init__(self, max_size: int = 100):
        """
        Initialize short-term memory.

        Args:
            max_size: Maximum number of memories to keep
        """
        self.max_size = max_size
        self.memories: List[Memory] = []

    def add(self, memory: Memory) -> None:
        """Add a memory, removing oldest if over limit"""
        self.memories.append(memory)
        while len(self.memories) > self.max_size:
            self.memories.pop(0)

    def get_recent(self, n: int = 10) -> List[Memory]:
        """Get the most recent n memories"""
        return self.memories[-n:]

    def search(self, query: str, limit: int = 5) -> List[Memory]:
        """
        Simple keyword-based search.

        Args:
            query: Search query
            limit: Maximum results

        Returns:
            List of matching memories
        """
        query_lower = query.lower()
        results = []
        for memory in reversed(self.memories):
            if query_lower in memory.content.lower():
                results.append(memory)
                if len(results) >= limit:
                    break
        return results

    def clear(self) -> None:
        """Clear all memories"""
        self.memories.clear()

    def to_messages(self) -> List[Dict[str, str]]:
        """Convert to message format"""
        return [
            {"role": m.role, "content": m.content}
            for m in self.memories
        ]

    def __len__(self) -> int:
        return len(self.memories)

    def __repr__(self) -> str:
        return f"ShortTermMemory(size={len(self.memories)}, max={self.max_size})"