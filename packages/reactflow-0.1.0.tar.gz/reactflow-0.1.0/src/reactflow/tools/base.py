"""
Tool Base Class and Decorator
"""

from typing import Callable, Dict, Any, Optional, List
from dataclasses import dataclass
import inspect


@dataclass
class ToolDefinition:
    """Definition of a tool"""
    name: str
    description: str
    parameters: List[Dict[str, Any]]
    func: Callable


class Tool:
    """
    Tool decorator and registry for ReActFlow.

    Tools are functions that the agent can call to perform actions.

    Example:
        ```python
        from reactflow import Tool

        @Tool.define
        def search(query: str) -> str:
            '''Search the web for information'''
            return f"Results for: {query}"

        # Access the tool
        print(Tool.get("search"))
        ```
    """

    _registry: Dict[str, ToolDefinition] = {}

    @classmethod
    def define(
        cls,
        func: Optional[Callable] = None,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None
    ) -> Callable:
        """
        Decorator to define a tool.

        Args:
            func: The function to wrap (when used without arguments)
            name: Optional custom name (defaults to function name)
            description: Optional custom description (defaults to docstring)

        Returns:
            The wrapped function with tool metadata

        Example:
            ```python
            @Tool.define
            def my_tool(query: str) -> str:
                '''This is my tool description'''
                return f"Result: {query}"

            @Tool.define(name="custom_name")
            def another_tool(x: int) -> int:
                '''Another tool'''
                return x * 2
            ```
        """
        def decorator(f: Callable) -> Callable:
            # Get tool name
            tool_name = name or f.__name__

            # Get description from docstring
            doc = inspect.getdoc(f) or ""
            tool_description = description or doc.split("\n")[0] if doc else f.__name__

            # Parse parameters
            params = cls._parse_parameters(f)

            # Create tool definition
            tool_def = ToolDefinition(
                name=tool_name,
                description=tool_description,
                parameters=params,
                func=f
            )

            # Register tool
            cls._registry[tool_name] = tool_def

            # Add metadata to function
            f._tool_name = tool_name
            f._tool_def = tool_def

            return f

        if func is not None:
            return decorator(func)
        return decorator

    @staticmethod
    def _parse_parameters(func: Callable) -> List[Dict[str, Any]]:
        """Parse function parameters into tool parameter definitions"""
        sig = inspect.signature(func)
        params = []

        type_map = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object"
        }

        for name, param in sig.parameters.items():
            # Skip self for methods
            if name == "self":
                continue

            # Determine type
            param_type = "string"
            if param.annotation != inspect.Parameter.empty:
                param_type = type_map.get(param.annotation, "string")

            # Determine if required
            required = param.default == inspect.Parameter.empty
            default = None if required else param.default

            params.append({
                "name": name,
                "type": param_type,
                "description": f"Parameter {name}",
                "required": required,
                "default": default
            })

        return params

    @classmethod
    def get(cls, name: str) -> Optional[ToolDefinition]:
        """
        Get a tool definition by name.

        Args:
            name: Tool name

        Returns:
            ToolDefinition or None if not found
        """
        return cls._registry.get(name)

    @classmethod
    def list(cls) -> Dict[str, ToolDefinition]:
        """
        List all registered tools.

        Returns:
            Dictionary of tool name -> ToolDefinition
        """
        return cls._registry.copy()

    @classmethod
    def get_openai_tools_format(cls) -> List[Dict[str, Any]]:
        """
        Get tools in OpenAI function calling format.

        Returns:
            List of tool definitions in OpenAI format
        """
        tools = []
        for name, tool in cls._registry.items():
            tools.append({
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": {
                        "type": "object",
                        "properties": {
                            p["name"]: {
                                "type": p["type"],
                                "description": p["description"]
                            }
                            for p in tool.parameters
                        },
                        "required": [
                            p["name"] for p in tool.parameters if p["required"]
                        ]
                    }
                }
            })
        return tools

    @classmethod
    def clear(cls) -> None:
        """Clear all registered tools"""
        cls._registry.clear()

    def __init__(self, func: Callable, name: Optional[str] = None, description: Optional[str] = None):
        """
        Create a tool from a function (alternative to decorator).

        Args:
            func: The function to wrap
            name: Optional custom name
            description: Optional custom description
        """
        self.func = func
        self.name = name or func.__name__
        self.description = description or (func.__doc__ or "").split("\n")[0]
        self.parameters = self._parse_parameters(func)

    def execute(self, **kwargs) -> Any:
        """Execute the tool with given arguments"""
        return self.func(**kwargs)