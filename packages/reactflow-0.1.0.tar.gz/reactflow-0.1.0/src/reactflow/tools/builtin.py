"""
Built-in Tools for ReActFlow
"""

from typing import Optional
import math
from .base import Tool


@Tool.define
def search(query: str) -> str:
    """
    Search for information on the web.

    This is a simulated search tool. In production, connect to a real search API.

    Args:
        query: The search query

    Returns:
        Search results as a string
    """
    # Simulated search results
    # In production, integrate with DuckDuckGo, Google, or other search APIs
    simulated_results = {
        "python": "Python is a high-level, general-purpose programming language. "
                  "Its design philosophy emphasizes code readability with the use of significant indentation. "
                  "Python is dynamically-typed and garbage-collected.",
        "weather": "Weather information typically includes temperature, humidity, precipitation, "
                   "wind speed, and atmospheric pressure.",
        "ai": "Artificial Intelligence (AI) refers to the simulation of human intelligence in machines "
              "that are programmed to think like humans and mimic their actions.",
        "react": "ReAct is a paradigm for combining reasoning and acting in language models. "
                 "It interleaves Thought and Action steps to solve complex problems."
    }

    # Check for keywords
    query_lower = query.lower()
    for keyword, result in simulated_results.items():
        if keyword in query_lower:
            return f"Search results for '{query}':\n{result}"

    # Default response
    return f"Search results for '{query}':\nNo specific information found. Try a more specific query."


@Tool.define
def calculator(expression: str) -> str:
    """
    Evaluate a mathematical expression.

    Supports basic arithmetic, trigonometry, and common math functions.

    Args:
        expression: Mathematical expression to evaluate (e.g., "2+2", "sqrt(16)", "sin(pi/2)")

    Returns:
        The result of the calculation

    Example:
        >>> calculator("2+2")
        "4"
        >>> calculator("sqrt(16)")
        "4.0"
    """
    # Safe math functions
    safe_dict = {
        "abs": abs,
        "round": round,
        "min": min,
        "max": max,
        "sum": sum,
        "pow": pow,
        "sqrt": math.sqrt,
        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,
        "log": math.log,
        "log10": math.log10,
        "exp": math.exp,
        "pi": math.pi,
        "e": math.e,
    }

    try:
        # Clean expression
        expr = expression.strip()

        # Basic validation
        if any(char in expr for char in ["__", "import", "exec", "eval", "open", "file"]):
            return "Error: Invalid expression - contains forbidden characters"

        # Evaluate
        result = eval(expr, {"__builtins__": {}}, safe_dict)

        # Format result
        if isinstance(result, float):
            if result.is_integer():
                return str(int(result))
            return f"{result:.6g}"

        return str(result)

    except Exception as e:
        return f"Error calculating '{expression}': {str(e)}"


@Tool.define
def finish(answer: str) -> str:
    """
    Finish the task and provide the final answer.

    Use this when you have completed the task and have a final answer for the user.

    Args:
        answer: The final answer to the user's question

    Returns:
        Confirmation message
    """
    return f"[TASK COMPLETED] Answer: {answer}"


@Tool.define
def text_analyzer(text: str, analysis_type: str = "summary") -> str:
    """
    Analyze text in various ways.

    Args:
        text: The text to analyze
        analysis_type: Type of analysis - "summary", "keywords", "sentiment", "stats"

    Returns:
        Analysis results
    """
    if analysis_type == "summary":
        words = text.split()
        if len(words) <= 20:
            return f"Text is short: {' '.join(words[:10])}..."
        return f"Summary: First 10 words: {' '.join(words[:10])}... ({len(words)} total words)"

    elif analysis_type == "keywords":
        # Simple keyword extraction (most common words)
        words = text.lower().split()
        word_freq = {}
        for word in words:
            clean_word = ''.join(c for c in word if c.isalnum())
            if len(clean_word) > 3:
                word_freq[clean_word] = word_freq.get(clean_word, 0) + 1

        top_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]
        return f"Top keywords: {', '.join(w[0] for w in top_words)}"

    elif analysis_type == "stats":
        words = text.split()
        chars = len(text)
        sentences = text.count('.') + text.count('!') + text.count('?')
        return f"Statistics: {len(words)} words, {chars} characters, ~{sentences} sentences"

    else:
        return f"Unknown analysis type: {analysis_type}. Use: summary, keywords, sentiment, or stats"


@Tool.define
def datetime_tool(format: str = "iso") -> str:
    """
    Get current date and time.

    Args:
        format: Output format - "iso", "date", "time", "readable"

    Returns:
        Current date/time string
    """
    from datetime import datetime
    now = datetime.now()

    if format == "iso":
        return now.isoformat()
    elif format == "date":
        return now.strftime("%Y-%m-%d")
    elif format == "time":
        return now.strftime("%H:%M:%S")
    elif format == "readable":
        return now.strftime("%A, %B %d, %Y at %I:%M %p")
    else:
        return now.isoformat()


# Export all tools
__all__ = ["search", "calculator", "finish", "text_analyzer", "datetime_tool"]