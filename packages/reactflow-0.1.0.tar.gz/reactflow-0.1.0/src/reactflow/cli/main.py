"""
ReActFlow CLI - Command Line Interface
"""

import argparse
import sys
import json
from typing import Optional

from ..core.agent import Agent
from ..tools.builtin import search, calculator, datetime_tool


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser"""
    parser = argparse.ArgumentParser(
        prog="reactflow",
        description="ReActFlow - A lightweight ReAct Agent framework"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Run command
    run_parser = subparsers.add_parser("run", help="Run an agent task")
    run_parser.add_argument("task", help="The task to execute")
    run_parser.add_argument(
        "--model", "-m",
        default="gpt-4",
        help="LLM model to use (default: gpt-4)"
    )
    run_parser.add_argument(
        "--max-steps", "-s",
        type=int,
        default=10,
        help="Maximum number of steps (default: 10)"
    )
    run_parser.add_argument(
        "--debug", "-d",
        action="store_true",
        help="Enable debug output"
    )
    run_parser.add_argument(
        "--export", "-e",
        help="Export trajectory to file"
    )
    run_parser.add_argument(
        "--format", "-f",
        choices=["json", "markdown"],
        default="json",
        help="Export format (default: json)"
    )

    # Interactive command
    interactive_parser = subparsers.add_parser("interactive", help="Start interactive session")
    interactive_parser.add_argument(
        "--model", "-m",
        default="gpt-4",
        help="LLM model to use"
    )

    # Version command
    subparsers.add_parser("version", help="Show version")

    return parser


def cmd_run(args) -> int:
    """Execute the run command"""
    # Create agent with built-in tools
    agent = Agent(
        tools=[search, calculator, datetime_tool],
        model=args.model,
        max_steps=args.max_steps,
        debug=args.debug
    )

    print(f"\n🎯 Task: {args.task}")
    print("-" * 50)

    # Run the task
    result = agent.run(args.task)

    # Print result
    print("\n" + "=" * 50)
    if result.success:
        print("✅ Task completed successfully!")
        print(f"\n📝 Answer:\n{result.answer}")
    else:
        print("❌ Task failed!")
        print(f"\n⚠️ Error: {result.error}")

    # Print stats
    print(f"\n📊 Statistics:")
    print(f"  • Steps: {result.trajectory.total_steps if result.trajectory else 0}")
    print(f"  • Tokens: ~{result.total_tokens}")
    print(f"  • Cost: ~${result.total_cost:.4f}")
    print(f"  • Time: {result.execution_time:.2f}s")

    # Export if requested
    if args.export and result.trajectory:
        result.trajectory.export(args.export, format=args.format)
        print(f"\n💾 Trajectory exported to: {args.export}")

    return 0 if result.success else 1


def cmd_interactive(args) -> int:
    """Start interactive session"""
    print("""
╔═══════════════════════════════════════════════════════════╗
║                    ReActFlow Interactive                  ║
╠═══════════════════════════════════════════════════════════╣
║  Commands:                                                ║
║  • Type your task and press Enter                        ║
║  • 'exit' or 'quit' to exit                              ║
║  • 'clear' to reset the session                          ║
║  • 'help' for more options                               ║
╚═══════════════════════════════════════════════════════════╝
""")

    agent = Agent(
        tools=[search, calculator, datetime_tool],
        model=args.model,
        debug=False
    )

    while True:
        try:
            task = input("\n💬 > ").strip()

            if not task:
                continue

            if task.lower() in ["exit", "quit", "q"]:
                print("\n👋 Goodbye!")
                break

            if task.lower() == "clear":
                agent.reset()
                print("🔄 Session reset.")
                continue

            if task.lower() == "help":
                print("""
Available commands:
  <task>    - Run a task
  clear     - Reset the session
  exit      - Exit interactive mode

Built-in tools:
  search    - Search for information
  calculator - Calculate expressions
  datetime  - Get current date/time
""")
                continue

            # Run the task
            print("\n⏳ Processing...")
            result = agent.run(task)

            if result.success:
                print(f"\n✅ {result.answer}")
            else:
                print(f"\n❌ Error: {result.error}")

        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")

    return 0


def main(args: Optional[list] = None) -> int:
    """Main entry point"""
    parser = create_parser()
    parsed_args = parser.parse_args(args)

    if parsed_args.command == "run":
        return cmd_run(parsed_args)
    elif parsed_args.command == "interactive":
        return cmd_interactive(parsed_args)
    elif parsed_args.command == "version":
        from .. import __version__
        print(f"ReActFlow v{__version__}")
        return 0
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())