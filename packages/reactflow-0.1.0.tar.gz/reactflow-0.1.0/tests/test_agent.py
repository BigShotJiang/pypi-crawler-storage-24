"""
Tests for ReActFlow Agent
"""

import pytest
from unittest.mock import Mock, patch
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from reactflow.core.agent import Agent
from reactflow.core.state import AgentState, Action
from reactflow.core.result import AgentResult, AgentStep, Trajectory
from reactflow.tools.base import Tool


class TestTool:
    """Test Tool functionality"""

    def test_tool_decorator(self):
        """Test that @Tool.define works correctly"""
        @Tool.define
        def test_tool(query: str) -> str:
            """Test tool description"""
            return f"Result: {query}"

        assert "test_tool" in Tool.list()
        tool_def = Tool.get("test_tool")
        assert tool_def.name == "test_tool"
        assert "Test tool description" in tool_def.description

    def test_tool_execution(self):
        """Test tool execution"""
        @Tool.define
        def add(a: int, b: int) -> int:
            """Add two numbers"""
            return a + b

        tool_def = Tool.get("add")
        assert tool_def.func(2, 3) == 5

    def test_custom_name(self):
        """Test custom tool name"""
        @Tool.define(name="custom_search")
        def my_search(q: str) -> str:
            """Custom search"""
            return q

        assert "custom_search" in Tool.list()
        assert "my_search" not in Tool.list()


class TestAction:
    """Test Action class"""

    def test_action_creation(self):
        """Test creating an action"""
        action = Action(tool_name="search", args={"query": "test"})
        assert action.tool_name == "search"
        assert action.args == {"query": "test"}

    def test_is_finish(self):
        """Test is_finish check"""
        finish_action = Action(tool_name="finish", args={"answer": "done"})
        assert finish_action.is_finish()

        search_action = Action(tool_name="search", args={"query": "test"})
        assert not search_action.is_finish()

    def test_json_serialization(self):
        """Test JSON serialization"""
        action = Action(tool_name="search", args={"query": "test"})
        json_str = action.to_json()
        restored = Action.from_json(json_str)
        assert restored.tool_name == action.tool_name
        assert restored.args == action.args


class TestAgentState:
    """Test AgentState class"""

    def test_state_creation(self):
        """Test creating agent state"""
        state = AgentState(task="Test task")
        assert state.task == "Test task"
        assert state.step_count == 0
        assert state.total_tokens == 0

    def test_add_step(self):
        """Test adding steps"""
        state = AgentState(task="Test")
        step = AgentStep(step_number=1, thought="Thinking", tokens_used=100)
        state.add_step(step)

        assert state.step_count == 1
        assert state.total_tokens == 100
        assert state.steps[0].thought == "Thinking"


class TestTrajectory:
    """Test Trajectory class"""

    def test_trajectory_creation(self):
        """Test creating trajectory"""
        traj = Trajectory(task="Test task")
        assert traj.task == "Test task"
        assert traj.status == "running"
        assert traj.total_steps == 0

    def test_add_step(self):
        """Test adding steps to trajectory"""
        traj = Trajectory(task="Test")
        step = AgentStep(step_number=1, thought="Thinking")
        traj.add_step(step)

        assert traj.total_steps == 1
        assert traj.steps[0].thought == "Thinking"

    def test_to_markdown(self):
        """Test markdown export"""
        traj = Trajectory(task="Test task")
        step = AgentStep(
            step_number=1,
            thought="I need to search",
            action=Action(tool_name="search", args={"query": "test"}),
            observation="Results found"
        )
        traj.add_step(step)

        md = traj.to_markdown()
        assert "Test task" in md
        assert "I need to search" in md
        assert "search" in md

    def test_to_json(self):
        """Test JSON export"""
        traj = Trajectory(task="Test")
        step = AgentStep(step_number=1, thought="Thinking")
        traj.add_step(step)

        json_str = traj.to_json()
        assert '"task": "Test"' in json_str
        assert '"thought": "Thinking"' in json_str


class TestAgent:
    """Test Agent class"""

    def test_agent_creation(self):
        """Test creating an agent"""
        agent = Agent(tools=[], model="gpt-4")
        assert agent.model == "gpt-4"
        assert "finish" in agent.tools  # Default finish tool

    def test_add_tool(self):
        """Test adding tools to agent"""
        agent = Agent(tools=[])

        @Tool.define
        def test_tool(x: str) -> str:
            """Test"""
            return x

        agent.add_tool(test_tool)
        assert "test_tool" in agent.tools


class TestBuiltInTools:
    """Test built-in tools"""

    def test_calculator(self):
        """Test calculator tool"""
        from reactflow.tools.builtin import calculator

        result = calculator("2+2")
        assert "4" in result

        result = calculator("sqrt(16)")
        assert "4" in result

    def test_datetime_tool(self):
        """Test datetime tool"""
        from reactflow.tools.builtin import datetime_tool

        result = datetime_tool("date")
        assert len(result) == 10  # YYYY-MM-DD format


if __name__ == "__main__":
    pytest.main([__file__, "-v"])