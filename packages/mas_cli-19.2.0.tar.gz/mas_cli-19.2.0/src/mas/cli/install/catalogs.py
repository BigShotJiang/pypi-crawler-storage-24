# *****************************************************************************
# Copyright (c) 2024 IBM Corporation and other Contributors.
#
# All rights reserved. This program and the accompanying materials
# are made available under the terms of the Eclipse Public License v1.0
# which accompanies this distribution, and is available at
# http://www.eclipse.org/legal/epl-v10.html
#
# *****************************************************************************
supportedCatalogs = {
    "amd64": [
        "v9-260318-amd64",
        "v9-260226-amd64",
        "v9-260216-amd64",
        "v9-260129-amd64",
    ],
    "s390x": [
        "v9-260318-s390x",
        "v9-260226-s390x",
        "v9-260216-s390x",
        "v9-260129-s390x",
    ],
    "ppc64le": [
        "v9-260318-ppc64le",
        "v9-260226-ppc64le",
        "v9-260216-ppc64le",
        "v9-260129-ppc64le",
    ],
}
