# Local-First Reigh: Implementation Plan (v2)

## Overview

Run the full Reigh stack on a single machine: local Supabase (Docker), local edge functions, local frontend, local GPU worker, with user-supplied API keys for external services. No cloud dependency required.

**Current state**: The repo already has `supabase/config.toml` and 407 migrations. `supabase start` + `supabase db push` is documented in the README. The main gaps are: (1) no seed data for local bootstrap, (2) edge functions assume cloud-injected secrets, (3) frontend hardcodes the cloud Supabase URL in `.env`, (4) auth depends on Discord OAuth which doesn't work locally without app credentials, (5) generation-method defaults normalize to cloud-only, (6) no `.env.example` or setup script exists.

---

## Phase 0: Validation and Foundation (1-2 days)

**Goal**: Confirm `supabase start` works clean, identify all migration issues, and create the env scaffolding.

### 0.1 — Verify clean local Supabase boot
- Run `supabase start` and `supabase db push` from scratch
- Capture the output keys (SUPABASE_URL, ANON_KEY, SERVICE_ROLE_KEY)
- Fix any migration errors (407 migrations may have cloud-specific assumptions)

### 0.2 — Create `.env.example` and `scripts/local-setup.sh`
- `.env.example` with all required vars, commented by category
- `scripts/local-setup.sh` that: checks Docker is running, runs `supabase start` and captures output keys, writes `.env.local` with local Supabase URL/keys, runs `supabase db push` to apply migrations, runs seed (see 0.3), starts `supabase functions serve` in background

### 0.3 — Create `supabase/seed.sql` — auth-aware user seeding
The dev auto-login (`autoLogin.ts`) calls `supabase.auth.signInWithPassword()`, which requires a real `auth.users` + `auth.identities` record — not just a `public.users` row. The `public.users` row is auto-created later by the `create_user_record_if_not_exists` RPC on first authenticated query.

Seed must create the auth identity via one of:
- **Option A (recommended)**: Post-boot script step in `local-setup.sh` that calls the Supabase Auth Admin API: `POST http://127.0.0.1:54321/auth/v1/admin/users` with the service role key to create a user with email `developer@reigh.local` / password `Smellymax123?` and `email_confirm: true`. This is the most reliable approach since it uses the same auth engine as production.
- **Option B**: Direct SQL inserts into `auth.users` and `auth.identities` in `seed.sql`. This works but is fragile (schema changes across Supabase versions could break it) and requires matching the exact hashing/identity format GoTrue expects.

**Do NOT seed a project or shots.** The app's first-run bootstrap in `useProjectCRUD.ts` automatically creates "Sample Project", a "Getting Started" shot, and copies the onboarding template when the user has zero projects. Seeding a bare project would bypass this path and leave the user without the expected template content. Let the bootstrap run naturally.

Seed data that IS needed:
- `task_types` rows (required by task creation trigger — missing rows silently default to `run_type='gpu'`)
- Storage buckets: `image_uploads` (public), `training-data` (private), `lora_files` (public) — via `INSERT INTO storage.buckets`
- Initial credit balance for the seeded user (large value like 999,999 in `credits_ledger`)

### 0.4 — Seed `generationMethods` to local-only default
The current default fallback for `generationMethods` is `{ onComputer: true, inCloud: true }`, which the normalization in `useUserUIState.ts:134-152` converts to `{ inCloud: true, onComputer: false }` (cloud wins when both are true). A local-first user needs the opposite.

Two approaches (do both):
1. **Seed the user's UI state** after first login: the `local-setup.sh` script (after creating the auth user and before the user loads the app) inserts a `user_ui_state` record with `generationMethods = { onComputer: true, inCloud: false }` for the dev user.
2. **Change the fallback for local mode**: In `useProjectImageSettings.ts`, use `isLocalMode()` to flip the default:
   ```typescript
   const fallback = isLocalMode()
     ? { onComputer: true, inCloud: false }
     : { onComputer: true, inCloud: true };
   ```
   This ensures any new users created locally also get the right default without manual seeding.

### 0.5 — Smoke test: frontend connects to local Supabase
- Set `VITE_SUPABASE_URL=http://127.0.0.1:54321` and local anon key in `.env.local`
- `npm run dev` -> confirm app loads, Supabase client initializes
- Confirm dev auto-login works with the auth-seeded user
- Confirm first-run bootstrap creates Sample Project + Getting Started shot + onboarding template automatically
- Confirm generation methods show "On Computer" (not "In Cloud")

**Validation**: App boots, connects to local Supabase, authenticates the seeded dev user, first-run bootstrap completes naturally, and generation mode defaults to local.

---

## Phase 1: Auth and Core Data Flow (1-2 days)

**Goal**: Full local auth working, projects/shots/generations CRUD functional.

### 1.1 — Local auth strategy
Use email/password auth (already supported by local Supabase config: `enable_signup = true`, `enable_confirmations = false`). Auth user created via Admin API in setup script; dev auto-login handles session. No OAuth config needed.

### 1.2 — Ensure project creation works locally
- Verify the first-run bootstrap completes: Sample Project + Getting Started shot + onboarding template
- Test creating additional projects via the UI
- Verify `projects` table RLS policies work with local auth
- Test shot creation, image upload to local storage

### 1.3 — Storage: verify local bucket access
- Buckets seeded in Phase 0.3
- Verify upload/download cycle works (XHR upload pattern -> public URL retrieval)
- Test thumbnail generation (canvas resize + upload)

**Validation**: Can sign in, see the bootstrapped Sample Project with Getting Started shot, create new projects/shots, upload images, see them in the UI.

---

## Phase 2: Edge Functions Locally (2-3 days)

**Goal**: All edge functions run via `supabase functions serve` with local secrets.

### 2.1 — Create `supabase/.env.local` for edge function secrets
Local Supabase auto-injects `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, but other secrets need explicit config:
- GROQ_API_KEY, OPENAI_API_KEY (for ai-prompt) — user-provided or empty
- REPLICATE_API_TOKEN (for trim-video) — user-provided or empty
- STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET — stub values for local
- DISCORD_STATS_WEBHOOK_URL — empty
- FRONTEND_URL=http://localhost:2222
- LOCAL_MODE=true

### 2.2 — `supabase functions serve` integration
- `local-setup.sh` starts `supabase functions serve --env-file supabase/.env.local` in background
- Frontend uses `VITE_SUPABASE_URL=http://127.0.0.1:54321` (edge functions served at `{SUPABASE_URL}/functions/v1/{name}`)
- Verify `create-task` edge function works end-to-end

### 2.3 — Graceful degradation for missing API keys
For edge functions that call external APIs (`ai-prompt`, `ai-voice-prompt`, `trim-video`):
- Check if key exists; if not, return a clear error: `{ error: "GROQ_API_KEY not configured. Add your key in Settings > API Keys.", recoverable: false }`
- These functions already check for key presence — just improve the error messages

### 2.4 — Stub billing-dependent functions
Functions that require Stripe (`stripe-webhook`, `stripe-checkout`, `process-auto-topup`, etc.):
- Add `LOCAL_MODE` env var check; when true, billing functions return success stubs (no-ops)
- `create-task` doesn't check credits (confirmed by code) — credit deduction happens via DB trigger on task completion

### 2.5 — Credit system bypass for local mode
- Seed user with very large credit balance (999,999) — simplest approach, avoids touching triggers

**Validation**: Can create a task via the UI, task appears in `tasks` table with status `queued`, edge functions respond correctly.

---

## Phase 3: Worker Integration (2-3 days)

**Goal**: Validate the task-claim/complete interface locally and document cross-repo worker setup.

**Important boundary**: This repo does not contain the GPU worker or orchestrator code. Those live in separate repos:
- **[Reigh-Worker](https://github.com/banodoco/Reigh-Worker)** — GPU task processor
- **[Reigh-Worker-Orchestrator](https://github.com/banodoco/Reigh-Worker-Orchestrator)** — pool/queue management

Phase 3 work is scoped to what can be done inside this repo, plus coordination documentation.

### 3.1 — Mock worker for CPU-only development
Create `scripts/mock-worker.ts` (or `.js`) — a minimal script that:
1. Polls `claim-next-task` edge function on a loop
2. For each claimed task, waits a few seconds, then calls `complete_task` with a placeholder image/video URL
3. Demonstrates the full task lifecycle without needing a GPU

This lets developers validate the entire pipeline (UI -> task creation -> claim -> completion -> generation appears) without setting up the external worker repos or having a GPU.

### 3.2 — Worker env config documentation
Document in `docs/structure_detail/local_development.md` the exact env vars the Reigh-Worker needs for local Supabase:
```env
SUPABASE_URL=http://127.0.0.1:54321   # or host.docker.internal if worker is in Docker
SUPABASE_SERVICE_ROLE_KEY=<local-key>  # from supabase start output
# Or: REIGH_ACCESS_TOKEN=<PAT>        # generated via generate-pat edge function
```

### 3.3 — Validate claim-next-task and complete_task locally
Using the mock worker:
- Create a task via UI
- Mock worker claims it (`claim-next-task`)
- Mock worker calls `complete_task` with stub output
- Verify generation appears in UI via realtime
- Verify model affinity doesn't block single-worker setups

### 3.4 — Real GPU worker setup (optional, requires external repos)
For developers with a local GPU:
- Clone Reigh-Worker, point at local Supabase
- Document the setup steps and verify end-to-end
- This step is optional and depends on having compatible hardware + the external repo

**Validation**: Mock worker completes the full cycle: UI creates task -> mock worker claims -> sends stub result -> generation visible in UI. For real GPU workers: documented setup path verified at least once.

---

## Phase 4: BYOK (Bring Your Own Key) for External Services (1-2 days)

**Goal**: Users can provide their own API keys for Groq, OpenAI, Replicate, HuggingFace via the settings UI, and edge functions use them.

### 4.1 — Use the existing Vault-backed `external_api_keys` system
The repo already has two secret-storage paths:
- **Legacy**: `users.api_keys` JSONB column (plaintext-ish, used by `useApiKeys` hook)
- **Current**: `external_api_keys` table + Supabase Vault encryption (used by `huggingface-upload`, repository in `src/shared/services/externalApiKeys/`)

The plan must use the Vault-backed system, not the legacy `users.api_keys` path. The `save_external_api_key` and `get_external_api_key_decrypted` RPCs already handle encryption/decryption server-side.

### 4.2 — Extend `external_api_keys` to cover Groq, OpenAI, Replicate
The `ExternalService` type currently supports `'huggingface' | 'replicate' | 'civitai'`. Extend to add:
- `'groq'` — for ai-prompt, ai-voice-prompt
- `'openai'` — for ai-prompt

Changes needed:
- `src/shared/services/externalApiKeys/types.ts`: Add `'groq' | 'openai'` to `ExternalService` union
- Settings UI: Add input fields for Groq and OpenAI API keys using the existing `externalApiKeys` save/fetch pattern (same as HuggingFace currently uses)

### 4.3 — Edge functions read user keys via Vault RPC as fallback
Pattern for each edge function that needs an external API key:
```typescript
// Priority: env var (operator-level) > user's Vault-stored key > error
let apiKey = Deno.env.get("GROQ_API_KEY");
if (!apiKey && userId) {
  const { data } = await supabaseAdmin.rpc('get_external_api_key_decrypted', {
    p_user_id: userId, p_service: 'groq'
  });
  apiKey = data?.[0]?.key_value || null;
}
if (!apiKey) {
  return edgeErrorResponse({
    errorCode: 'missing_api_key',
    message: 'Groq API key required. Add it in Settings > API Keys.',
    recoverable: false
  }, 400);
}
```

This pattern already exists in `huggingface-upload/index.ts:275-306` — reuse it.

### 4.4 — Create shared helper for the pattern
Add `supabase/functions/_shared/userApiKey.ts`:
```typescript
export async function resolveApiKey(
  supabaseAdmin: SupabaseClient,
  envVarName: string,
  userId: string | null,
  service: string,
): Promise<string | null> {
  const envKey = Deno.env.get(envVarName);
  if (envKey) return envKey;
  if (!userId) return null;
  const { data } = await supabaseAdmin.rpc('get_external_api_key_decrypted', {
    p_user_id: userId, p_service: service,
  });
  return data?.[0]?.key_value || null;
}
```

### 4.5 — Apply to all external-API edge functions
- `ai-prompt` (Groq via `resolveApiKey(_, 'GROQ_API_KEY', userId, 'groq')`, OpenAI via `resolveApiKey(_, 'OPENAI_API_KEY', userId, 'openai')`)
- `ai-voice-prompt` (Groq)
- `trim-video` (Replicate via `resolveApiKey(_, 'REPLICATE_API_TOKEN', userId, 'replicate')`)

**Validation**: User sets API keys in Settings (stored via Vault), creates a task requiring external API (e.g., prompt enhancement), and it succeeds using the Vault-decrypted user-provided key. Env-var keys still take priority when set.

---

## Phase 5: Realtime and Polish (1-2 days)

**Goal**: Full realtime working locally, smooth developer experience.

### 5.1 — Verify Supabase Realtime works locally
- `config.toml` already has `[realtime] enabled = true`
- Test task completion -> UI update cycle
- If realtime doesn't work, existing polling fallback (5s aggressive) is acceptable

### 5.2 — Frontend `LOCAL_MODE` detection
Add `isLocalMode()` to `src/integrations/supabase/config/env.ts` (checks if URL contains `127.0.0.1` or `localhost`). Use to:
- Hide billing/Stripe UI elements
- Show email/password login instead of Discord OAuth on HomePage
- Default `generationMethods` to `{ onComputer: true, inCloud: false }` (from Phase 0.4)
- Optionally show "Local Mode" indicator

### 5.3 — Documentation
- Update README.md quick start
- Create `docs/structure_detail/local_development.md` covering:
  - Prerequisites (Docker, Node 20, GPU optional)
  - Step-by-step setup via `local-setup.sh`
  - How auth seeding works (Admin API, not raw SQL)
  - Why no project is pre-seeded (first-run bootstrap handles it)
  - BYOK configuration guide (Settings > API Keys, Vault-backed)
  - Mock worker usage for CPU-only development
  - Real GPU worker setup (links to Reigh-Worker repo, env var config)
  - Troubleshooting common issues

### 5.4 — `.gitignore` hygiene
Ensure `.env.local`, `supabase/.env.local` are gitignored.

**Validation**: Complete local development loop with no cloud dependency.

---

## Phase 6: Hardening and Optional Enhancements (ongoing)

### 6.1 — Reset script: `scripts/local-reset.sh`
### 6.2 — Docker Compose (optional): single file to start Supabase + frontend + mock worker
### 6.3 — CI local integration test: GitHub Action with `supabase start` -> seed -> test
### 6.4 — Debug task viewer: `/debug/tasks` page for local testing without GPU
### 6.5 — Deprecation path for `users.api_keys`: Once BYOK uses `external_api_keys` exclusively, mark the legacy `useApiKeys` hook as deprecated

---

## File Change Summary

| File | Change | Phase |
|------|--------|-------|
| `.env.example` | New — all vars with comments | 0 |
| `scripts/local-setup.sh` | New — automated local bootstrap (incl. Auth Admin API user creation) | 0 |
| `supabase/seed.sql` | New — task_types, storage buckets, credits (NO project/user seeding) | 0 |
| `src/shared/components/ImageGenerationForm/hooks/useProjectImageSettings.ts` | Edit — local-mode default for generationMethods | 0 |
| `supabase/.env.local.example` | New — edge function secrets template | 2 |
| `scripts/mock-worker.ts` | New — minimal task claim/complete loop for CPU-only dev | 3 |
| `src/shared/services/externalApiKeys/types.ts` | Edit — add 'groq' and 'openai' to ExternalService | 4 |
| `supabase/functions/_shared/userApiKey.ts` | New — resolveApiKey helper (env var > Vault > null) | 4 |
| `supabase/functions/ai-prompt/index.ts` | Edit — BYOK via resolveApiKey + Vault | 4 |
| `supabase/functions/ai-voice-prompt/index.ts` | Edit — BYOK via resolveApiKey + Vault | 4 |
| `supabase/functions/trim-video/index.ts` | Edit — BYOK via resolveApiKey + Vault | 4 |
| Settings UI (API Keys section) | Edit — add Groq/OpenAI fields using externalApiKeys pattern | 4 |
| `src/integrations/supabase/config/env.ts` | Edit — add isLocalMode() | 5 |
| `src/pages/Home/HomePage.tsx` | Edit — email/password login in local mode | 5 |
| `docs/structure_detail/local_development.md` | New — comprehensive local dev guide | 5 |
| `scripts/local-reset.sh` | New — teardown and rebuild | 6 |

---

## Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| Migration failures on local PG15 | Blocks Phase 0 | Fix migrations incrementally |
| Supabase Vault not available locally | Blocks BYOK Phase 4 | Supabase local includes Vault; verify in Phase 0 |
| Auth Admin API format changes | Seed user creation fails | Pin to stable Supabase CLI version; document manual fallback |
| Realtime not working locally | Degrades UX | Polling fallback already built (5s) |
| Storage bucket permissions differ locally | Upload failures | Seed buckets explicitly with RLS policies |
| Credit trigger blocks task completion | No generation created | Seed large credit balance |
| Worker repos need parallel changes | Phase 3 partially blocked | Mock worker covers this repo's scope; real worker is documented |
| `external_api_keys` Vault RPC not in local schema | BYOK fails | Migration 20260105300000 creates the RPCs; verify they apply locally |
