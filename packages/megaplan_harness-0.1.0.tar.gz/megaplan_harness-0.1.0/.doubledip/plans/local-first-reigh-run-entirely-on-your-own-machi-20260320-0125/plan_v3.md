# Local-First Reigh: Implementation Plan (v3)

## Overview

Run the full Reigh stack on a single machine: local Supabase (Docker), local edge functions, local frontend, local GPU worker, with user-supplied API keys for external services. No cloud dependency required.

**Current state**: The repo already has `supabase/config.toml` and 407 migrations. `supabase start` + `supabase db push` is documented in the README. The main gaps are: (1) no seed data for local bootstrap, (2) edge functions assume cloud-injected secrets, (3) frontend hardcodes the cloud Supabase URL in `.env`, (4) auth depends on Discord OAuth which doesn't work locally without app credentials, (5) generation-method defaults normalize to cloud-only across 10 call sites, (6) no `.env.example` or setup script exists.

---

## Phase 0: Validation and Foundation (1-2 days)

**Goal**: Confirm `supabase start` works clean, identify all migration issues, and create the env scaffolding.

### 0.1 — Verify clean local Supabase boot
- Run `supabase start` and `supabase db push` from scratch
- Capture the output keys (SUPABASE_URL, ANON_KEY, SERVICE_ROLE_KEY)
- Fix any migration errors (407 migrations may have cloud-specific assumptions)
- Verify `vault.secrets` table is accessible (needed for BYOK in Phase 4)

### 0.2 — Create `.env.example` and `scripts/local-setup.sh`
- `.env.example` with all required vars, commented by category
- `scripts/local-setup.sh` that: checks Docker is running, runs `supabase start` and captures output keys, writes `.env.local` with local Supabase URL/keys, runs `supabase db push` to apply migrations, creates auth user via Admin API (see 0.3), runs SQL seed (see 0.4), starts `supabase functions serve` in background

### 0.3 — Auth user seeding via Admin API with fixed UUID
The dev auto-login (`autoLogin.ts`) calls `supabase.auth.signInWithPassword()`, which requires a real `auth.users` + `auth.identities` record — not just a `public.users` row. The `public.users` row is auto-created later by the `create_user_record_if_not_exists` RPC on first authenticated query.

The setup script creates the auth user via the Supabase Auth Admin API:
```bash
LOCAL_DEV_USER_ID="5e9c70d5-dab3-413e-b217-a67cb4238540"  # fixed UUID

curl -s -X POST "http://127.0.0.1:54321/auth/v1/admin/users" \
  -H "Authorization: Bearer ${SERVICE_ROLE_KEY}" \
  -H "apikey: ${SERVICE_ROLE_KEY}" \
  -H "Content-Type: application/json" \
  -d '{
    "id": "'${LOCAL_DEV_USER_ID}'",
    "email": "developer@reigh.local",
    "password": "Smellymax123?",
    "email_confirm": true,
    "user_metadata": { "full_name": "Local Developer" }
  }'
```

Using a **fixed UUID** is critical: it lets `seed.sql` reference the same user ID for the `public.users` row and credit grant (see 0.4).

### 0.4 — Create `supabase/seed.sql` — data seeding (with `public.users` row)
The `credits_ledger.user_id` column has a foreign key to `public.users(id)`, so we **must** seed a `public.users` row before inserting credits. This is safe because `create_user_record_if_not_exists` (the RPC called on first authenticated query) uses `ON CONFLICT (id) DO NOTHING` — it will harmlessly skip if the row already exists.

Seed data (all referencing the fixed `LOCAL_DEV_USER_ID`):
```sql
-- 1. Public user row (must come before credits_ledger due to FK)
INSERT INTO public.users (id, name, email, credits, given_credits, settings)
VALUES (
  '5e9c70d5-dab3-413e-b217-a67cb4238540',
  'Local Developer',
  'developer@reigh.local',
  999999,
  true,
  '{"ui": {"generationMethods": {"onComputer": true, "inCloud": false}}}'::jsonb
) ON CONFLICT (id) DO NOTHING;

-- 2. Credit grant in ledger
INSERT INTO public.credits_ledger (user_id, amount, reason)
VALUES ('5e9c70d5-dab3-413e-b217-a67cb4238540', 999999, 'Local development seed');

-- 3. Task types (required by task creation trigger)
INSERT INTO public.task_types (name, run_type) VALUES
  ('travel_orchestrator', 'gpu'),
  ('travel_segment', 'gpu'),
  ('travel_stitch', 'gpu'),
  ('individual_travel_segment', 'gpu'),
  ('image-generation', 'gpu')
  -- add other task types as needed
ON CONFLICT (name) DO NOTHING;

-- 4. Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES
  ('image_uploads', 'image_uploads', true),
  ('training-data', 'training-data', false),
  ('lora_files', 'lora_files', true)
ON CONFLICT (id) DO NOTHING;
```

**Do NOT seed a project or shots.** The app's first-run bootstrap in `useProjectCRUD.ts` automatically creates "Sample Project", a "Getting Started" shot, and copies the onboarding template when the user has zero projects. Seeding a bare project would bypass this path. Note that the seeded `users.settings.ui.generationMethods` ensures the first-run bootstrap sees the correct local-mode default.

### 0.5 — Fix `generationMethods` default at the source (all 10 call sites)
The current default fallback for `generationMethods` is `{ onComputer: true, inCloud: true }`, which the normalization in `useUserUIState.ts:134-152` converts to `{ inCloud: true, onComputer: false }` (cloud wins when both are true). There are **10 call sites** that all pass this same fallback:

1. `src/shared/components/SettingsModal/SettingsModal.tsx:103`
2. `src/shared/components/ProcessingWarnings.tsx:24`
3. `src/shared/components/ToolsPane/ToolsPane.tsx:228`
4. `src/tools/travel-between-images/pages/ShotEditorView.tsx:74`
5. `src/shared/components/ImageGenerationForm/hooks/useProjectImageSettings.ts:41`
6. `src/tools/edit-images/hooks/useInlineEditState.ts:140`
7. `src/domains/media-lightbox/hooks/videoLightbox/useVideoLightboxEnvironment.ts:126`
8. `src/domains/media-lightbox/hooks/useImageLightboxEnvironment.ts:28`
9. `src/shared/components/OnboardingModal/components/steps/GenerationMethodStep.tsx:23`
10. `src/app/hooks/useOnboardingFlow.ts:64`

**Fix at the source, not per-site.** Change the `decodeGenerationMethods` function in `useUserUIState.ts` (the centralized normalizer called by all 10 sites) to use a local-mode-aware fallback:

```typescript
// In useUserUIState.ts, inside decodeGenerationMethods:
const defaultFallback = isLocalMode()
  ? { onComputer: true, inCloud: false }
  : { onComputer: true, inCloud: true };

// Use defaultFallback instead of the hardcoded { onComputer: true, inCloud: true }
```

This way:
- All 10 call sites inherit the correct default automatically — no per-site patches needed
- The normalization rule (both true → cloud wins) still applies for cloud deployments
- For local mode, the fallback is `{ onComputer: true, inCloud: false }`, which passes through normalization unchanged
- The seeded `users.settings.ui.generationMethods` (from 0.4) covers the dev user explicitly; the code change covers any additional users created locally

### 0.6 — Smoke test: frontend connects to local Supabase
- Set `VITE_SUPABASE_URL=http://127.0.0.1:54321` and local anon key in `.env.local`
- `npm run dev` -> confirm app loads, Supabase client initializes
- Confirm dev auto-login works with the auth-seeded user
- Confirm first-run bootstrap creates Sample Project + Getting Started shot + onboarding template automatically (the pre-seeded `public.users` row has `ON CONFLICT DO NOTHING`, so the bootstrap's `create_user_record_if_not_exists` call is a safe no-op)
- Confirm generation methods show "On Computer" (not "In Cloud") across Settings, ToolsPane, and ShotEditorView

**Validation**: App boots, connects to local Supabase, authenticates the seeded dev user, first-run bootstrap completes naturally, and generation mode defaults to local in all UI surfaces.

---

## Phase 1: Auth and Core Data Flow (1-2 days)

**Goal**: Full local auth working, projects/shots/generations CRUD functional.

### 1.1 — Local auth strategy
Use email/password auth (already supported by local Supabase config: `enable_signup = true`, `enable_confirmations = false`). Auth user created via Admin API in setup script; dev auto-login handles session. No OAuth config needed.

### 1.2 — Ensure project creation works locally
- Verify the first-run bootstrap completes: Sample Project + Getting Started shot + onboarding template
- Test creating additional projects via the UI
- Verify `projects` table RLS policies work with local auth
- Test shot creation, image upload to local storage

### 1.3 — Storage: verify local bucket access
- Buckets seeded in Phase 0.4
- Verify upload/download cycle works (XHR upload pattern -> public URL retrieval)
- Test thumbnail generation (canvas resize + upload)

**Validation**: Can sign in, see the bootstrapped Sample Project with Getting Started shot, create new projects/shots, upload images, see them in the UI.

---

## Phase 2: Edge Functions Locally (2-3 days)

**Goal**: All edge functions run via `supabase functions serve` with local secrets.

### 2.1 — Create `supabase/.env.local` for edge function secrets
Local Supabase auto-injects `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, but other secrets need explicit config:
- GROQ_API_KEY, OPENAI_API_KEY (for ai-prompt) — user-provided or empty
- REPLICATE_API_TOKEN (for trim-video) — user-provided or empty
- STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET — stub values for local
- DISCORD_STATS_WEBHOOK_URL — empty
- FRONTEND_URL=http://localhost:2222
- LOCAL_MODE=true

### 2.2 — `supabase functions serve` integration
- `local-setup.sh` starts `supabase functions serve --env-file supabase/.env.local` in background
- Frontend uses `VITE_SUPABASE_URL=http://127.0.0.1:54321` (edge functions served at `{SUPABASE_URL}/functions/v1/{name}`)
- Verify `create-task` edge function works end-to-end

### 2.3 — Graceful degradation for missing API keys
For edge functions that call external APIs (`ai-prompt`, `ai-voice-prompt`, `trim-video`):
- Check if key exists; if not, return a clear error: `{ error: "GROQ_API_KEY not configured. Add your key in Settings > API Keys.", recoverable: false }`
- These functions already check for key presence — just improve the error messages

### 2.4 — Stub billing-dependent functions
Functions that require Stripe (`stripe-webhook`, `stripe-checkout`, `process-auto-topup`, etc.):
- Add `LOCAL_MODE` env var check; when true, billing functions return success stubs (no-ops)
- `create-task` doesn't check credits (confirmed by code) — credit deduction happens via DB trigger on task completion

### 2.5 — Credit system bypass for local mode
- Dev user pre-seeded with 999,999 credits in Phase 0.4 (both `users.credits` column and `credits_ledger` entry)
- Simplest approach — avoids touching triggers

**Validation**: Can create a task via the UI, task appears in `tasks` table with status `queued`, edge functions respond correctly.

---

## Phase 3: Worker Integration (2-3 days)

**Goal**: Validate the task-claim/complete interface locally and document cross-repo worker setup.

**Important boundary**: This repo does not contain the GPU worker or orchestrator code. Those live in separate repos:
- **[Reigh-Worker](https://github.com/banodoco/Reigh-Worker)** — GPU task processor
- **[Reigh-Worker-Orchestrator](https://github.com/banodoco/Reigh-Worker-Orchestrator)** — pool/queue management

Phase 3 work is scoped to what can be done inside this repo, plus coordination documentation.

### 3.1 — Mock worker for CPU-only development
Create `scripts/mock-worker.ts` — a minimal Node/Deno script that demonstrates the full task lifecycle without a GPU. The mock worker must conform to the actual `complete_task` payload contract.

**`complete_task` accepts two upload modes** (from `request.ts`):
- **Base64 mode**: `{ task_id, file_data: "<base64>", filename: "output.png" }` — the function handles storage upload internally
- **Storage path mode**: `{ task_id, storage_path: "userId/tasks/taskId/output.png" }` — requires the file to already exist in storage

The mock worker will use **base64 mode** (simpler, no pre-upload step needed):

```typescript
// Mock worker pseudocode
async function completeMockTask(taskId: string, userId: string) {
  // Generate a tiny 1x1 placeholder PNG (68 bytes base64)
  const PLACEHOLDER_PNG_BASE64 = "iVBORw0KGgoAAAANSUhEUg..."; // 1x1 red pixel

  await fetch(`${SUPABASE_URL}/functions/v1/complete_task`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${SERVICE_ROLE_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      task_id: taskId,
      file_data: PLACEHOLDER_PNG_BASE64,
      filename: `mock-output-${Date.now()}.png`,
    }),
  });
}
```

The full mock worker script will:
1. Poll `claim-next-task` edge function on a configurable interval (default 5s)
2. For each claimed task, wait 2-3 seconds (simulates processing)
3. Call `complete_task` with a base64-encoded placeholder image using the contract above
4. Log the full cycle to stdout for debugging

This produces a real generation record (via the DB trigger on task completion) with a real storage URL pointing to the placeholder image.

### 3.2 — Worker env config documentation
Document in `docs/structure_detail/local_development.md` the exact env vars the Reigh-Worker needs for local Supabase:
```env
SUPABASE_URL=http://127.0.0.1:54321   # or host.docker.internal if worker is in Docker
SUPABASE_SERVICE_ROLE_KEY=<local-key>  # from supabase start output
# Or: REIGH_ACCESS_TOKEN=<PAT>        # generated via generate-pat edge function
```

### 3.3 — Validate claim-next-task and complete_task locally
Using the mock worker:
- Create a task via UI
- Mock worker claims it (`claim-next-task`)
- Mock worker calls `complete_task` with base64 placeholder (valid payload)
- Verify generation appears in UI via realtime (will show as a small placeholder image)
- Verify model affinity doesn't block single-worker setups

### 3.4 — Real GPU worker setup (optional, requires external repos)
For developers with a local GPU:
- Clone Reigh-Worker, point at local Supabase
- Document the setup steps and verify end-to-end
- This step is optional and depends on having compatible hardware + the external repo

**Validation**: Mock worker completes the full cycle with a valid `complete_task` payload: UI creates task -> mock worker claims -> sends base64 placeholder -> `complete_task` stores file and triggers generation creation -> generation visible in UI with placeholder thumbnail.

---

## Phase 4: BYOK (Bring Your Own Key) for External Services (1-2 days)

**Goal**: Users can provide their own API keys for Groq, OpenAI, Replicate, HuggingFace via the settings UI, and edge functions use them.

### 4.1 — Use the existing Vault-backed `external_api_keys` system
The repo already has two secret-storage paths:
- **Legacy**: `users.api_keys` JSONB column (plaintext-ish, used by `useApiKeys` hook)
- **Current**: `external_api_keys` table + Supabase Vault encryption (used by `huggingface-upload`, repository in `src/shared/services/externalApiKeys/`)

The plan must use the Vault-backed system, not the legacy `users.api_keys` path. The `save_external_api_key` and `get_external_api_key_decrypted` RPCs already handle encryption/decryption server-side.

### 4.2 — Extend `external_api_keys` to cover Groq, OpenAI, Replicate
The `ExternalService` type currently supports `'huggingface' | 'replicate' | 'civitai'`. Extend to add:
- `'groq'` — for ai-prompt, ai-voice-prompt
- `'openai'` — for ai-prompt

Changes needed:
- `src/shared/services/externalApiKeys/types.ts`: Add `'groq' | 'openai'` to `ExternalService` union
- Settings UI: Add input fields for Groq and OpenAI API keys using the existing `externalApiKeys` save/fetch pattern (same as HuggingFace currently uses)

### 4.3 — Edge functions read user keys via Vault RPC as fallback
Pattern for each edge function that needs an external API key:
```typescript
// Priority: env var (operator-level) > user's Vault-stored key > error
let apiKey = Deno.env.get("GROQ_API_KEY");
if (!apiKey && userId) {
  const { data } = await supabaseAdmin.rpc('get_external_api_key_decrypted', {
    p_user_id: userId, p_service: 'groq'
  });
  apiKey = data?.[0]?.key_value || null;
}
if (!apiKey) {
  return edgeErrorResponse({
    errorCode: 'missing_api_key',
    message: 'Groq API key required. Add it in Settings > API Keys.',
    recoverable: false
  }, 400);
}
```

This pattern already exists in `huggingface-upload/index.ts:275-306` — reuse it.

### 4.4 — Create shared helper for the pattern
Add `supabase/functions/_shared/userApiKey.ts`:
```typescript
export async function resolveApiKey(
  supabaseAdmin: SupabaseClient,
  envVarName: string,
  userId: string | null,
  service: string,
): Promise<string | null> {
  const envKey = Deno.env.get(envVarName);
  if (envKey) return envKey;
  if (!userId) return null;
  const { data } = await supabaseAdmin.rpc('get_external_api_key_decrypted', {
    p_user_id: userId, p_service: service,
  });
  return data?.[0]?.key_value || null;
}
```

### 4.5 — Apply to all external-API edge functions
- `ai-prompt` (Groq via `resolveApiKey(_, 'GROQ_API_KEY', userId, 'groq')`, OpenAI via `resolveApiKey(_, 'OPENAI_API_KEY', userId, 'openai')`)
- `ai-voice-prompt` (Groq)
- `trim-video` (Replicate via `resolveApiKey(_, 'REPLICATE_API_TOKEN', userId, 'replicate')`)

**Validation**: User sets API keys in Settings (stored via Vault), creates a task requiring external API (e.g., prompt enhancement), and it succeeds using the Vault-decrypted user-provided key. Env-var keys still take priority when set.

---

## Phase 5: Realtime and Polish (1-2 days)

**Goal**: Full realtime working locally, smooth developer experience.

### 5.1 — Verify Supabase Realtime works locally
- `config.toml` already has `[realtime] enabled = true`
- Test task completion -> UI update cycle
- If realtime doesn't work, existing polling fallback (5s aggressive) is acceptable

### 5.2 — Frontend `LOCAL_MODE` detection
Add `isLocalMode()` to `src/integrations/supabase/config/env.ts` (checks if URL contains `127.0.0.1` or `localhost`). Use to:
- Hide billing/Stripe UI elements
- Show email/password login instead of Discord OAuth on HomePage
- Drive the `generationMethods` default in `decodeGenerationMethods` (from Phase 0.5)
- Optionally show "Local Mode" indicator

### 5.3 — Documentation
- Update README.md quick start
- Create `docs/structure_detail/local_development.md` covering:
  - Prerequisites (Docker, Node 20, GPU optional)
  - Step-by-step setup via `local-setup.sh`
  - How auth seeding works (Admin API with fixed UUID, not raw SQL auth inserts)
  - Why `public.users` IS pre-seeded (credits FK) but projects are NOT (first-run bootstrap)
  - BYOK configuration guide (Settings > API Keys, Vault-backed)
  - Mock worker usage for CPU-only development (explains the base64 payload)
  - Real GPU worker setup (links to Reigh-Worker repo, env var config)
  - Troubleshooting common issues

### 5.4 — `.gitignore` hygiene
Ensure `.env.local`, `supabase/.env.local` are gitignored.

**Validation**: Complete local development loop with no cloud dependency.

---

## Phase 6: Hardening and Optional Enhancements (ongoing)

### 6.1 — Reset script: `scripts/local-reset.sh`
### 6.2 — Docker Compose (optional): single file to start Supabase + frontend + mock worker
### 6.3 — CI local integration test: GitHub Action with `supabase start` -> seed -> test
### 6.4 — Debug task viewer: `/debug/tasks` page for local testing without GPU
### 6.5 — Deprecation path for `users.api_keys`: Once BYOK uses `external_api_keys` exclusively, mark the legacy `useApiKeys` hook as deprecated

---

## File Change Summary

| File | Change | Phase |
|------|--------|-------|
| `.env.example` | New — all vars with comments | 0 |
| `scripts/local-setup.sh` | New — automated local bootstrap (Auth Admin API with fixed UUID, SQL seed, functions serve) | 0 |
| `supabase/seed.sql` | New — public.users row (fixed UUID), credits_ledger, task_types, storage buckets | 0 |
| `src/shared/hooks/useUserUIState.ts` | Edit — `decodeGenerationMethods` uses `isLocalMode()` for fallback default | 0 |
| `supabase/.env.local.example` | New — edge function secrets template | 2 |
| `scripts/mock-worker.ts` | New — claim/complete loop using base64 mode with placeholder PNG | 3 |
| `src/shared/services/externalApiKeys/types.ts` | Edit — add 'groq' and 'openai' to ExternalService | 4 |
| `supabase/functions/_shared/userApiKey.ts` | New — resolveApiKey helper (env var > Vault > null) | 4 |
| `supabase/functions/ai-prompt/index.ts` | Edit — BYOK via resolveApiKey + Vault | 4 |
| `supabase/functions/ai-voice-prompt/index.ts` | Edit — BYOK via resolveApiKey + Vault | 4 |
| `supabase/functions/trim-video/index.ts` | Edit — BYOK via resolveApiKey + Vault | 4 |
| Settings UI (API Keys section) | Edit — add Groq/OpenAI fields using externalApiKeys pattern | 4 |
| `src/integrations/supabase/config/env.ts` | Edit — add isLocalMode() | 5 |
| `src/pages/Home/HomePage.tsx` | Edit — email/password login in local mode | 5 |
| `docs/structure_detail/local_development.md` | New — comprehensive local dev guide | 5 |
| `scripts/local-reset.sh` | New — teardown and rebuild | 6 |

---

## Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| Migration failures on local PG15 | Blocks Phase 0 | Fix migrations incrementally |
| Supabase Vault not available locally | Blocks BYOK Phase 4 | Verify `vault.secrets` accessible in Phase 0.1 |
| Auth Admin API format changes | Seed user creation fails | Pin to stable Supabase CLI version; document manual fallback |
| Fixed UUID conflicts with existing data | Auth/user mismatch | UUID is dev-only, gitignored `.env.local`; reset script clears state |
| Realtime not working locally | Degrades UX | Polling fallback already built (5s) |
| Storage bucket permissions differ locally | Upload failures | Seed buckets explicitly with RLS policies |
| Credit trigger blocks task completion | No generation created | Seed 999,999 credits in both `users.credits` and `credits_ledger` |
| Worker repos need parallel changes | Phase 3 partially blocked | Mock worker covers this repo's scope; real worker is documented |
| `external_api_keys` Vault RPC not in local schema | BYOK fails | Migration 20260105300000 creates the RPCs; verify they apply locally |
| `isLocalMode()` import in `useUserUIState.ts` | Circular dependency risk | `isLocalMode()` is in `config/env.ts` with no app imports — safe leaf module |
