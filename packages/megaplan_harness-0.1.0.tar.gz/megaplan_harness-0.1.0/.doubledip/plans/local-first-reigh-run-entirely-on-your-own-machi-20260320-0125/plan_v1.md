# Local-First Reigh: Implementation Plan

## Overview

Run the full Reigh stack on a single machine: local Supabase (Docker), local edge functions, local frontend, local GPU worker, with user-supplied API keys for external services. No cloud dependency required.

**Current state**: The repo already has `supabase/config.toml` and 407 migrations. `supabase start` + `supabase db push` is documented in the README. The main gaps are: (1) no seed data for local bootstrap, (2) edge functions assume cloud-injected secrets, (3) frontend hardcodes the cloud Supabase URL in `.env`, (4) auth depends on Discord OAuth which doesn't work locally without app credentials, (5) credit/billing system may block task creation if no credits, (6) no `.env.example` or setup script exists.

---

## Phase 0: Validation and Foundation (1-2 days)

**Goal**: Confirm `supabase start` works clean, identify all migration issues, and create the env scaffolding.

### 0.1 — Verify clean local Supabase boot
- Run `supabase start` and `supabase db push` from scratch
- Capture the output keys (SUPABASE_URL, ANON_KEY, SERVICE_ROLE_KEY)
- Fix any migration errors (407 migrations may have cloud-specific assumptions)

### 0.2 — Create `.env.example` and `scripts/local-setup.sh`
- `.env.example` with all required vars, commented by category
- `scripts/local-setup.sh` that: checks Docker is running, runs `supabase start` and captures output keys, writes `.env.local` with local Supabase URL/keys, runs `supabase db push` to apply migrations, seeds minimum required data (see 0.3)

### 0.3 — Create `supabase/seed.sql`
Minimum viable seed data:
- `task_types` rows (required by task creation trigger — missing rows silently default to `run_type='gpu'`)
- A default local user (email/password auth, since Discord OAuth won't work)
- A default project owned by that user
- Initial credit grant (large balance like 999999)
- Storage buckets: `image_uploads` (public), `training-data` (private), `lora_files` (public)

### 0.4 — Smoke test: frontend connects to local Supabase
- Set `VITE_SUPABASE_URL=http://127.0.0.1:54321` and local anon key in `.env.local`
- `npm run dev` -> confirm app loads, Supabase client initializes
- Confirm dev auto-login works with seeded user (`VITE_DEV_USER_EMAIL`/`VITE_DEV_USER_PASSWORD`)

**Validation**: App boots, connects to local Supabase, authenticates the seeded dev user, and shows the main UI.

---

## Phase 1: Auth and Core Data Flow (1-2 days)

**Goal**: Full local auth working, projects/shots/generations CRUD functional.

### 1.1 — Local auth strategy
Use email/password auth (already supported by local Supabase config: `enable_signup = true`, `enable_confirmations = false`). Seed user with email/password; dev auto-login handles the rest. No OAuth config needed.

### 1.2 — Ensure project creation works locally
- Test creating a project via the UI
- Verify `projects` table RLS policies work with local auth
- Test shot creation, image upload to local storage

### 1.3 — Storage: verify local bucket access
- `supabase start` creates storage automatically but may not create custom buckets
- Add bucket creation to `seed.sql` with correct public/private settings
- Verify upload/download cycle works (XHR upload pattern -> public URL retrieval)

**Validation**: Can sign in, create a project, create shots, upload images, see them in the UI.

---

## Phase 2: Edge Functions Locally (2-3 days)

**Goal**: All edge functions run via `supabase functions serve` with local secrets.

### 2.1 — Create `supabase/.env.local` for edge function secrets
Local Supabase auto-injects `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, but other secrets need explicit config:
- GROQ_API_KEY, OPENAI_API_KEY (for ai-prompt) — user-provided or empty
- REPLICATE_API_TOKEN (for trim-video) — user-provided or empty
- STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET — stub values for local
- DISCORD_STATS_WEBHOOK_URL — empty
- FRONTEND_URL=http://localhost:2222

### 2.2 — `supabase functions serve` integration
- Add to `local-setup.sh`: starts `supabase functions serve --env-file supabase/.env.local` in background
- Frontend uses `VITE_SUPABASE_URL=http://127.0.0.1:54321` (edge functions served at `{SUPABASE_URL}/functions/v1/{name}`)
- Verify `create-task` edge function works end-to-end

### 2.3 — Graceful degradation for missing API keys
For edge functions that call external APIs (`ai-prompt`, `ai-voice-prompt`, `trim-video`):
- Check if key exists; if not, return a clear error: `{ error: "GROQ_API_KEY not configured. Add your key in Settings > API Keys.", recoverable: false }`
- These functions already check for key presence — just improve the error messages

### 2.4 — Stub billing-dependent functions
Functions that require Stripe (`stripe-webhook`, `stripe-checkout`, `process-auto-topup`, etc.):
- Add `LOCAL_MODE` env var check; when true, billing functions return success stubs (no-ops)
- `create-task` doesn't check credits (confirmed by code) — credit deduction happens via DB trigger on task completion

### 2.5 — Credit system bypass for local mode
- Seed user with very large credit balance (999,999) — simplest approach, avoids touching triggers

**Validation**: Can create a task via the UI, task appears in `tasks` table with status `queued`, edge functions respond correctly.

---

## Phase 3: Worker Integration (2-3 days)

**Goal**: Local GPU worker can claim and process tasks.

### 3.1 — Worker auth for local mode
Simplest: Worker uses the local `SUPABASE_SERVICE_ROLE_KEY` directly (no PAT needed). Alternative: Generate a PAT via the `generate-pat` edge function.

### 3.2 — Worker config for local Supabase
The Headless-Wan2GP worker needs: `SUPABASE_URL=http://127.0.0.1:54321` and `SUPABASE_SERVICE_ROLE_KEY=<local-key>`. Document exact env vars in the local dev guide.

### 3.3 — Task claim -> process -> complete cycle
- Start worker locally
- Create a task via UI
- Verify worker claims it (`claim-next-task`), processes, calls `complete_task`
- Verify generation appears in UI via realtime

### 3.4 — Model affinity for single-worker setup
With one local worker, model affinity doesn't matter. Ensure `claim-next-task` doesn't require multiple workers.

**Validation**: End-to-end: UI creates task -> worker claims -> processes -> completes -> generation visible in UI.

---

## Phase 4: BYOK (Bring Your Own Key) for External Services (1-2 days)

**Goal**: Users can provide their own API keys for Groq, OpenAI, Replicate, FAL via the settings UI.

### 4.1 — Extend the existing API keys system
The `useApiKeys` hook and `users.api_keys` JSONB column already exist and support `fal_api_key`, `openai_api_key`, `replicate_api_key`. Add `groq_api_key` to the UI settings form.

### 4.2 — Edge functions read user keys as fallback
Pattern for each edge function:
```
Priority: env var (operator-level) > user's stored key (from users.api_keys) > error
```

### 4.3 — New helper: `supabase/functions/_shared/apiKeys.ts`
`getUserApiKey(supabaseAdmin, userId, keyName)` — reads from `users.api_keys` JSONB column.

### 4.4 — Apply to all external-API edge functions
- `ai-prompt` (Groq, OpenAI)
- `ai-voice-prompt` (Groq)
- `trim-video` (Replicate)

**Validation**: User sets API keys in Settings, creates a task requiring external API, and it succeeds using the user-provided key.

---

## Phase 5: Realtime and Polish (1-2 days)

**Goal**: Full realtime working locally, smooth developer experience.

### 5.1 — Verify Supabase Realtime works locally
- `config.toml` already has `[realtime] enabled = true`
- Test task completion -> UI update cycle
- If realtime doesn't work, existing polling fallback (5s aggressive) is acceptable

### 5.2 — Frontend `LOCAL_MODE` detection
Add `isLocalMode()` to `src/integrations/supabase/config/env.ts` (checks if URL contains `127.0.0.1` or `localhost`). Use to: hide billing UI, show email/password login instead of Discord OAuth, optionally show "Local Mode" indicator.

### 5.3 — Documentation
- Update README.md quick start
- Create `docs/structure_detail/local_development.md`: prerequisites, step-by-step, troubleshooting, BYOK guide, worker setup

### 5.4 — `.gitignore` hygiene
Ensure `.env.local`, `supabase/.env.local` are gitignored.

**Validation**: Complete local development loop with no cloud dependency.

---

## Phase 6: Hardening and Optional Enhancements (ongoing)

### 6.1 — Reset script: `scripts/local-reset.sh`
### 6.2 — Docker Compose (optional): single file to start everything
### 6.3 — CI local integration test: GitHub Action with `supabase start`
### 6.4 — Debug task viewer: `/debug/tasks` page for local testing without GPU

---

## File Change Summary

| File | Change | Phase |
|------|--------|-------|
| `.env.example` | New — all vars with comments | 0 |
| `scripts/local-setup.sh` | New — automated local bootstrap | 0 |
| `supabase/seed.sql` | New — task_types, user, project, credits, buckets | 0 |
| `supabase/.env.local.example` | New — edge function secrets template | 2 |
| `supabase/functions/_shared/apiKeys.ts` | New — getUserApiKey helper | 4 |
| `supabase/functions/ai-prompt/index.ts` | Edit — BYOK fallback | 4 |
| `supabase/functions/ai-voice-prompt/index.ts` | Edit — BYOK fallback | 4 |
| `supabase/functions/trim-video/index.ts` | Edit — BYOK fallback | 4 |
| `src/integrations/supabase/config/env.ts` | Edit — add isLocalMode() | 5 |
| `src/pages/Home/HomePage.tsx` | Edit — email/password login in local mode | 5 |
| `docs/structure_detail/local_development.md` | New — local dev guide | 5 |
| `scripts/local-reset.sh` | New — teardown and rebuild | 6 |

---

## Risk Assessment

| Risk | Impact | Mitigation |
|------|--------|------------|
| Migration failures on local PG15 | Blocks Phase 0 | Fix migrations incrementally |
| Realtime not working locally | Degrades UX | Polling fallback already built (5s) |
| Storage bucket permissions differ locally | Upload failures | Seed buckets explicitly |
| Credit trigger blocks task completion | No generation created | Seed large credit balance |
| Worker can't reach local Supabase | No task processing | Use 127.0.0.1:54321 |
| Edge function Deno runtime differences | Function failures | Same Deno runtime locally |
