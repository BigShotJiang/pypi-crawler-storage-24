
# Test Suite for `doubledip.py`

## Overview

Create `test_doubledip.py` — a single-file pytest suite that exercises the state machine, flag lifecycle, and meta-evaluation heuristics using the existing mock worker system (`DOUBLEDIP_MOCK_WORKERS=1`). No new dependencies beyond pytest; all tests use `tmp_path` fixtures to isolate filesystem state.

---

## Shared Fixtures & Helpers

### `make_args(**overrides)` helper

Returns an `argparse.Namespace` pre-populated with **all attributes** that any handler may read. This prevents `AttributeError` crashes in `resolve_agent_mode()` and `handle_execute()`.

Default attributes:
```python
{
    "plan": None,          # set by fixture after init
    "idea": "test idea",
    "name": "test-plan",
    "project_dir": str(project_dir),
    "max_iterations": 3,
    "budget_usd": 25.0,
    "agent": None,         # let resolve_agent_mode() pick default
    "ephemeral": False,
    "fresh": False,
    "persist": False,
    "confirm_destructive": True,   # required by handle_execute()
    "confirm_self_review": False,
    "override_action": None,
    "note": None,
    "reason": None,
}
```

Individual tests override specific fields as needed.

### `plan_fixture` (pytest fixture, function-scoped)

- Creates `tmp_path / "project"` as `project_dir` (with a `.git` dir for `collect_git_diff_summary`).
- Sets `DOUBLEDIP_MOCK_WORKERS=1` via `monkeypatch.setenv`.
- Monkeypatches `shutil.which` to return `"/usr/bin/mock"` for `"claude"` and `"codex"` so gate preflight checks pass.
- Calls `handle_init(root, make_args())`.
- Returns a dataclass/namedtuple: `(root, plan_name, plan_dir, make_args_fn)`.

### `eval_scaffold(tmp_path, ...)` helper

Constructs the minimal on-disk artifacts needed by `build_evaluation()`:
- Writes `plan_v{N}.md` (and optionally `plan_v{N-1}.md` for delta calculation).
- Writes `plan_v{N}.meta.json` with `success_criteria`.
- Writes `critique_v{N}.json` (and optionally `critique_v{N-1}.json` for recurring-critique detection).
- Writes `flags.json` with caller-specified flags.
- Returns a `state` dict with caller-controlled `iteration`, `meta.significant_counts`, `meta.total_cost_usd`, `config.budget_usd`, `config.max_iterations`, and `plan_versions`.

Each test specifies only the parameters that matter and the helper fills neutral defaults that **do not trigger earlier `build_evaluation()` branches** (e.g., `total_cost_usd=0`, `plan_delta >= 10%` by default, no recurring critiques by default, `sig_history=[]` by default).

---

## Phase 1: Scaffolding & Smoke Test

**File:** `test_doubledip.py` (new, at repo root)

1. **Smoke test:** `test_init_creates_state_file` — verify `state.json` exists, `current_state == "initialized"`, `iteration == 0`.

**Validation:** Run `pytest test_doubledip.py::test_init_creates_state_file -v` — should pass in under 1 second.

---

## Phase 2: Utility Function Tests

Pure functions, zero filesystem setup.

2. **`test_slugify`** — `"Hello World!"` → `"hello-world"`, empty string → `"plan"`.

3. **`test_compute_plan_delta_percent`** — Identical text → `0.0`, `None` previous → `None`, completely different text → value near `100.0`.

4. **`test_compute_recurring_critiques`** — Write two critique JSON files with overlapping normalized concerns → returns intersection; non-overlapping → empty list.

5. **`test_infer_next_steps_all_states`** — Parameterized across all 9 states. For `evaluated`, test with different `last_evaluation.recommendation` values (CONTINUE, SKIP, ESCALATE, ABORT) to verify conditional next-step logic.

---

## Phase 3: Flag Lifecycle Tests

Directly exercise flag-management functions with hand-crafted data. Each test creates a `plan_dir` under `tmp_path`, seeds `flags.json` as needed, and calls the function.

6. **`test_update_flags_after_critique_creates_flags`** — Critique with 2 new flags → registry has 2 entries with `status="open"`, `severity=None`, `raised_in` set.

7. **`test_update_flags_after_critique_verifies_existing`** — Pre-seed FLAG-001 (status=open). Critique with `verified_flag_ids=["FLAG-001"]` → `status="verified"`, `verified=True`, `verified_in` set.

8. **`test_update_flags_after_critique_disputes_flags`** — Pre-seed FLAG-001 (status=open). Critique with `disputed_flag_ids=["FLAG-001"]` → `status="disputed"`.

9. **`test_update_flags_after_critique_reuses_ids`** — Pre-seed FLAG-001 with original concern. Critique with FLAG-001 carrying updated concern → updates in-place (no duplicate), concern overwritten, `status` reset to `"open"`.

10. **`test_update_flags_after_critique_autonumbers`** — Critique with a flag with `id=""` and one with `id="FLAG-000"` → both get auto-assigned sequential IDs.

11. **`test_update_flags_after_triage_sets_severity`** — Triage 2 flags (one significant, one minor) → severity set, return tuple has correct counts `(registry, 1, 1)`.

12. **`test_update_flags_after_triage_preserves_verified`** — Pre-seed FLAG-001 with `status="verified"`. Triage it as significant → `status` stays `"verified"` (not reset to `"open"`).

13. **`test_update_flags_after_integrate_marks_addressed`** — Pre-seed 2 open flags. Integrate addresses FLAG-001 → `status="addressed"`, `addressed_in` and `evidence` set. FLAG-002 unchanged.

14. **`test_unresolved_significant_flags_filtering`** — Registry with flags in 5 states: (open, significant), (open, minor), (addressed, significant), (verified, significant), (disputed, significant). Assert returns only the open+significant and disputed+significant flags.

15. **`test_normalize_flag_record_defaults`** — Flag with `category="bogus"` and missing `severity_hint` → defaults to `"other"` and `"uncertain"`.

---

## Phase 4: Meta-Evaluation Heuristic Tests

Each test uses `eval_scaffold()` to construct on-disk artifacts. **Critical design rule:** every test explicitly neutralizes all `build_evaluation()` branches that precede the target branch, so the test proves the intended branch fires — not an earlier short-circuit.

Branch priority order in `build_evaluation()` (lines 1456-1492):
1. Over budget → ABORT
2. No significant flags and no unresolved → SKIP
3. Plan delta < 5% + unresolved → ESCALATE; plan delta < 5% + resolved → SKIP
4. Iteration 1 + significant > 0 → CONTINUE
5. Recurring critiques → ESCALATE
6. sig_history not improving → ESCALATE; improving → CONTINUE
7. Max iterations + unresolved → ESCALATE
8. Default → CONTINUE

16. **`test_eval_abort_over_budget`** — `total_cost_usd=30, budget_usd=25` → `ABORT`, confidence `high`. (Branch 1; no earlier branch to neutralize.)

17. **`test_eval_skip_no_significant_flags`** — Zero significant flags in registry, `total_cost < budget` → `SKIP`, confidence `high`. (Branch 2; neutralize branch 1 with low cost.)

18. **`test_eval_escalate_stagnant_with_unresolved`** — Plan delta 3% (< 5%), 1 unresolved significant flag, cost under budget → `ESCALATE`. (Branch 3a; neutralize 1 with low cost, skip 2 by having a significant flag.)

19. **`test_eval_skip_small_delta_all_resolved`** — Plan delta 3%, all significant flags `status="addressed"`, cost under budget → `SKIP`. (Branch 3b; neutralize 1 with low cost, neutralize 2 by having significant flags exist but all resolved.)

20. **`test_eval_continue_first_iteration_significant`** — Iteration 1, 1 significant unresolved flag, plan delta > 5% (or None for first plan), cost under budget → `CONTINUE`, confidence `high`. (Branch 4; neutralize 1-3.)

21. **`test_eval_escalate_recurring_critiques`** — Iteration 2, same concern in both critique files, significant flags present, plan delta > 5%, cost under budget → `ESCALATE`. (Branch 5; neutralize 1-4 by setting iteration > 1.)

22. **`test_eval_escalate_sig_count_not_improving`** — Iteration 2, `sig_history=[2, 3]`, no recurring critiques, plan delta > 5%, cost under budget → `ESCALATE`, confidence `medium`. (Branch 6a; neutralize 1-5.)

23. **`test_eval_continue_sig_count_improving`** — Iteration 2, `sig_history=[3, 2]`, no recurring critiques, plan delta > 5%, cost under budget → `CONTINUE`, confidence `medium`. (Branch 6b; neutralize 1-5.)

24. **`test_eval_escalate_max_iterations_with_unresolved`** — Iteration 3, `max_iterations=3`, 1 unresolved, `sig_history=[2]` (length < 2, so branch 6 skipped), no recurring, plan delta > 5%, cost under budget → `ESCALATE`. (Branch 7; neutralize 1-6.)

---

## Phase 5: State Machine Integration Tests

These use the mock worker system and the full `plan_fixture`.

25. **`test_full_mock_lifecycle`** — Drive the complete happy-path pipeline:
   - `handle_init()` → state `initialized`
   - `handle_plan(root, make_args(plan=name))` → state `planned`, iteration 1, `plan_v1.md` exists
   - `handle_critique(...)` → state `critiqued`, 2 flags in registry
   - `handle_triage(...)` → state `triaged`, both flags have `severity="significant"`
   - `handle_evaluate(...)` → state `evaluated`, recommendation `CONTINUE`
   - `handle_integrate(...)` → state `planned`, iteration 2, flags addressed
   - Second critique → flags verified; triage → no open significant; evaluate → `SKIP`
   - `handle_gate(...)` → state `gated`, `gate.json` + `plan_final.md` exist
   - `handle_execute(..., confirm_destructive=True)` → state `executed`, `IMPLEMENTED_BY_DOUBLEDIP.txt` created
   - `handle_review(...)` → state `done`, all criteria pass

26. **`test_require_state_rejects_invalid_transition`** — From `initialized`, call `handle_critique()`. Expect `CliError` with `code="invalid_transition"`, `valid_next` containing `"plan"`.

27. **`test_cannot_skip_triage`** — From `planned`, call `handle_triage()`. Expect `CliError`.

28. **`test_cannot_execute_before_gate`** — From `evaluated`, call `handle_execute()`. Expect `CliError`.

29. **`test_terminal_states_block_progression_steps`** — After `handle_override(action="abort")`:
   - `infer_next_steps()` returns `[]`.
   - `handle_plan()`, `handle_critique()`, `handle_execute()` each raise `CliError`.
   - **But** `handle_override(action="add-note")` **succeeds** — this is correct behavior; `add-note` has no state guard and works in any state including terminal ones.

---

## Phase 6: Override Tests

30. **`test_override_abort_sets_terminal`** — From any non-terminal state, abort → state `aborted`, override recorded in `meta.overrides` with `action` and `reason`.

31. **`test_override_add_note`** — Verify note appended to both `meta.notes` and `meta.overrides`. Works from any state.

32. **`test_override_add_note_after_abort`** — Verify `add-note` succeeds even from `aborted` state (no state check in code path).

33. **`test_override_force_proceed_success`** — From `evaluated` state (any recommendation), with valid `project_dir` and `success_criteria` → transitions to `gated`, `gate.json` and `plan_final.md` written, override recorded.

34. **`test_override_force_proceed_unsafe_missing_project_dir`** — From `evaluated`, with `project_dir` pointing to a non-existent path → raises `CliError` with `code="unsafe_override"`.

35. **`test_override_force_proceed_unsafe_no_success_criteria`** — From `evaluated`, with `plan_v{N}.meta.json` containing empty `success_criteria: []` → raises `CliError` with `code="unsafe_override"`.

36. **`test_override_force_proceed_wrong_state`** — From `planned` → raises `CliError` with `code="invalid_transition"`.

37. **`test_override_skip`** — From `evaluated`, sets `last_evaluation.recommendation` to `"SKIP"` without changing `current_state`.

38. **`test_execute_requires_confirm_destructive`** — From `gated`, call `handle_execute(confirm_destructive=False)` → `CliError` with `code="missing_confirmation"`.

---

## Implementation Order

| Step | What | Tests | Why first |
|------|------|-------|-----------|
| 1 | Scaffolding, `make_args`, `plan_fixture`, smoke test | 1 | Validates imports and fixture correctness |
| 2 | Utility functions (slugify, delta, recurring, next_steps) | 4 | Pure functions, zero setup, instant feedback |
| 3 | Flag lifecycle (unit-level) | 10 | Core data model, no workers needed |
| 4 | Evaluation heuristics via `eval_scaffold` | 9 | Deterministic, highest logic density, branch-aware |
| 5 | State machine integration (mock workers) | 5 | Full pipeline, validates fixture completeness |
| 6 | Overrides and edge cases | 9 | Override paths, safety guards, destructive-confirm |
| **Total** | | **~38** | |

---

## Technical Notes

- **No mocking library needed.** `DOUBLEDIP_MOCK_WORKERS=1` replaces all worker calls. For unit tests of flag/eval functions, we construct state dicts and files directly.
- **`make_args()` is exhaustive.** Every attribute any handler reads (`agent`, `confirm_destructive`, `ephemeral`, `fresh`, `persist`, `confirm_self_review`, `override_action`, `note`, `reason`) is present with a safe default. This prevents the `AttributeError` crashes that a minimal Namespace would produce.
- **`shutil.which` monkeypatch.** Gate checks `claude_available` and `codex_available`. The fixture monkeypatches `shutil.which` so tests don't depend on binary availability.
- **Evaluation test isolation.** The `eval_scaffold` helper writes neutral defaults (cost=0, plan_delta≥10%, no recurring critiques, empty sig_history) so that each test only has to override the parameters for the branch it targets. This ensures tests prove the intended branch, not an earlier short-circuit.
- **Filesystem isolation.** Every test uses `tmp_path`. No shared state between tests.
- **No subprocess calls.** Mock workers return instantly with deterministic output.
