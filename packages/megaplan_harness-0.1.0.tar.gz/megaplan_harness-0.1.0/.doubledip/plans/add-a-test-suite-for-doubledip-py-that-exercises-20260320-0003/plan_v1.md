
# Test Suite for `doubledip.py`

## Overview

Create `test_doubledip.py` — a single-file pytest suite that exercises the state machine, flag lifecycle, and meta-evaluation heuristics using the existing mock worker system (`DOUBLEDIP_MOCK_WORKERS=1`). No new dependencies beyond pytest; all tests use `tmp_path` fixtures to isolate filesystem state.

---

## Phase 1: Scaffolding & Smoke Test

**File:** `test_doubledip.py` (new, at repo root)

1. **Import the module under test.** `doubledip.py` is a script with no `if __name__` guard around definitions — all functions are importable directly via `import doubledip`.

2. **Create a `plan_fixture` pytest fixture** that:
   - Creates a temp directory as the "root" (simulating the project root).
   - Creates a subdirectory to act as `project_dir`.
   - Sets `DOUBLEDIP_MOCK_WORKERS=1` in the environment (`monkeypatch.setenv`).
   - Builds a mock `argparse.Namespace` with default args (`idea`, `project_dir`, `name`, `max_iterations=3`, `budget_usd=25.0`).
   - Calls `handle_init()` and returns `(root, plan_name, plan_dir)`.

3. **Smoke test:** `test_init_creates_state_file` — verify `state.json` exists, `current_state == "initialized"`, `iteration == 0`.

**Validation:** Run `pytest test_doubledip.py::test_init_creates_state_file -v` — should pass in under 1 second.

---

## Phase 2: State Machine Tests

Test every valid transition in the happy path, plus invalid transition rejection.

### Happy-path linear walk (init → plan → critique → triage → evaluate → gate → execute → review)

4. **`test_full_mock_lifecycle`** — Drive the full pipeline using mock workers:
   - `handle_init()` → assert state `initialized`
   - `handle_plan()` → assert state `planned`, iteration `1`, `plan_v1.md` exists
   - `handle_critique()` → assert state `critiqued`, `critique_v1.json` exists, 2 flags in registry
   - `handle_triage()` → assert state `triaged`, flags have `severity` set
   - `handle_evaluate()` → assert state `evaluated`, recommendation is `CONTINUE` (iteration 1, significant flags present)
   - `handle_integrate()` → assert state `planned`, iteration `2`, `plan_v2.md` exists, flags addressed
   - Second critique/triage/evaluate cycle → assert `SKIP` recommendation (mock verifies all flags on iteration 2)
   - `handle_gate()` → assert state `gated`, `gate.json` exists
   - `handle_execute()` → assert state `executed`, `IMPLEMENTED_BY_DOUBLEDIP.txt` created
   - `handle_review()` → assert state `done`, all criteria pass

### Invalid transitions

5. **`test_require_state_rejects_invalid_transition`** — From `initialized`, attempt `handle_critique()`. Expect `CliError` with code `invalid_transition` and `valid_next` containing `"plan"`.

6. **`test_cannot_skip_triage`** — From `planned`, attempt `handle_triage()`. Expect `CliError`.

7. **`test_cannot_execute_before_gate`** — From `evaluated`, attempt `handle_execute()`. Expect `CliError`.

### Terminal states

8. **`test_terminal_state_blocks_all_steps`** — After `handle_override(action="abort")`, verify `infer_next_steps()` returns `[]` and all step handlers raise `CliError`.

---

## Phase 3: Flag Lifecycle Tests

These tests directly exercise the flag-management functions with hand-crafted data (no mock workers needed).

9. **`test_update_flags_after_critique_creates_flags`** — Call `update_flags_after_critique()` with a critique containing 2 flags. Verify:
   - `flags.json` has 2 entries with `status="open"`, `severity=None`, `raised_in` set.

10. **`test_update_flags_after_critique_verifies_existing`** — Pre-seed a flag registry with FLAG-001 (status=open). Call with `verified_flag_ids=["FLAG-001"]`. Verify `status="verified"`, `verified=True`, `verified_in` set.

11. **`test_update_flags_after_critique_disputes_flags`** — Similar, but with `disputed_flag_ids`. Verify `status="disputed"`.

12. **`test_update_flags_after_critique_reuses_ids`** — Submit a critique with a flag whose ID matches an existing flag. Verify it updates in-place rather than creating a duplicate.

13. **`test_update_flags_after_triage_sets_severity`** — Call `update_flags_after_triage()`. Verify severity assigned, counts returned correctly.

14. **`test_update_flags_after_triage_preserves_verified`** — Triage a flag that's already verified. Verify status stays `"verified"` (not reset to `"open"`).

15. **`test_update_flags_after_integrate_marks_addressed`** — Call `update_flags_after_integrate()`. Verify `status="addressed"`, `addressed_in` and `evidence` set.

16. **`test_unresolved_significant_flags_filtering`** — Build a registry with flags in various states (open/significant, open/minor, addressed/significant, verified/significant, disputed/significant). Assert only `open+significant` and `disputed+significant` are returned.

17. **`test_normalize_flag_record_defaults`** — Pass a flag with missing/invalid category and severity_hint. Assert defaults to `"other"` and `"uncertain"`.

---

## Phase 4: Meta-Evaluation Heuristic Tests

These test `build_evaluation()` directly by constructing state + artifacts on disk.

A **`evaluation_fixture` helper** function creates:
- A `plan_dir` with `plan_v{N}.md`, `plan_v{N}.meta.json`, `critique_v{N}.json`, `triage_v{N}.json`, and `flags.json`
- A `state` dict with controllable `iteration`, `meta.significant_counts`, `meta.total_cost_usd`, `config.budget_usd`, `config.max_iterations`

18. **`test_eval_skip_when_no_significant_flags`** — No significant flags → `SKIP`, confidence `high`.

19. **`test_eval_continue_first_iteration_with_significant`** — Iteration 1, significant flags present → `CONTINUE`, confidence `high`.

20. **`test_eval_abort_over_budget`** — `total_cost_usd > budget_usd` → `ABORT`, confidence `high`.

21. **`test_eval_escalate_stagnant_plan_with_unresolved`** — Plan delta < 5%, unresolved significant flags → `ESCALATE`.

22. **`test_eval_skip_small_delta_all_resolved`** — Plan delta < 5%, no unresolved → `SKIP`.

23. **`test_eval_escalate_recurring_critiques`** — Same concern text in consecutive critiques → `ESCALATE`.

24. **`test_eval_escalate_sig_count_not_improving`** — `sig_history = [2, 3]` → `ESCALATE`, medium confidence.

25. **`test_eval_continue_sig_count_improving`** — `sig_history = [3, 2]` → `CONTINUE`, medium confidence.

26. **`test_eval_escalate_max_iterations_with_unresolved`** — Iteration ≥ max_iterations, unresolved flags → `ESCALATE`.

---

## Phase 5: Override & Edge Cases

27. **`test_override_abort_sets_terminal`** — `handle_override(action="abort")` → state `aborted`, override recorded in `meta.overrides`.

28. **`test_override_add_note`** — Verify note appended to `meta.notes` and `meta.overrides`.

29. **`test_override_force_proceed_from_evaluated`** — From `evaluated` with ESCALATE recommendation → transitions to `gated`.

30. **`test_override_force_proceed_rejects_bad_state`** — From `planned`, expect `CliError`.

31. **`test_override_skip`** — From `evaluated`, sets `last_evaluation.recommendation` to `SKIP`.

---

## Phase 6: Utility Function Tests

32. **`test_slugify`** — `"Hello World!"` → `"hello-world"`, empty → `"plan"`.

33. **`test_compute_plan_delta_percent`** — Identical text → `0.0`, `None` previous → `None`, different text → `> 0`.

34. **`test_compute_recurring_critiques`** — Matching normalized concerns → returned; non-matching → empty.

35. **`test_infer_next_steps_all_states`** — Parameterized across all states, verify expected suggestions.

---

## Implementation Order

| Step | What | Est. Tests | Why first |
|------|------|-----------|-----------|
| 1 | Scaffolding + smoke test | 1 | Validates imports and fixture work |
| 2 | Utility functions (slugify, delta, normalize) | 4 | Pure functions, zero setup, fast feedback |
| 3 | Flag lifecycle (unit-level) | 9 | Core data model, no workers needed |
| 4 | Evaluation heuristics | 9 | Deterministic, highest logic density |
| 5 | State machine transitions (mock workers) | 5 | Integration-level, exercises full pipeline |
| 6 | Overrides and edge cases | 5 | Override paths and error handling |
| **Total** | | **~33** | |

---

## Technical Notes

- **No mocking library needed.** The built-in `DOUBLEDIP_MOCK_WORKERS=1` env var replaces all worker calls. For unit tests of flag/eval functions, we construct state dicts and files directly.
- **`argparse.Namespace` construction.** Each handler expects `args` with specific attributes. The fixture builds these with sensible defaults; individual tests override as needed.
- **Filesystem isolation.** Every test uses `tmp_path` as `root`. The `plan_fixture` calls `handle_init()` which creates `.doubledip/plans/<name>/` and `.doubledip/schemas/`.
- **No subprocess calls.** With mock workers enabled, no `claude` or `codex` binary is needed.
- **`handle_gate` preflight.** Gate checks `claude_available` and `codex_available` via `shutil.which()`. In CI, these may be absent. Tests should monkeypatch `shutil.which` to return a truthy value for these commands, or accept that `gate.passed` may be `False` and test accordingly.
