
# Implementation Plan: Clarification & Question-Gating Steps for Megaplan (v3)

## Current State Machine
```
init → [INITIALIZED] → plan → [PLANNED] → critique → [CRITIQUED] → evaluate → [EVALUATED] → integrate/gate → ...
```

## Proposed State Machine
```
init → [INITIALIZED] → clarify → [CLARIFIED] → plan → [PLANNED] → critique → [CRITIQUED] → evaluate → [EVALUATED] → integrate/gate → ...
```

With two new interactive gates:
1. **Clarify step** (after init, before plan) — presents the idea back, asks clarifying questions, refines intent
2. **Question gate** (after plan, before critique) — presents planner's questions/assumptions to the user for answers

---

## Step 1: Add `STATE_CLARIFIED` and register `clarify` across all step registries

**File:** `megaplan/cli.py`

- Add `STATE_CLARIFIED = "clarified"` alongside existing states (line ~48).
- Add `"STATE_CLARIFIED"` and `"handle_clarify"` to `__all__` (line ~24–41). The existing `__all__` controls the `from megaplan.cli import *` in `megaplan/__init__.py`, so any new public symbol must be listed here or it won't be accessible as `megaplan.handle_clarify(...)`.
- Add `"clarify"` to `DEFAULT_AGENT_ROUTING` (value: `"claude"`, since clarification requires reading the project and reasoning about ambiguity).
- Add a `"clarify.json"` entry to `SCHEMAS`:
  ```json
  {
    "questions": [{"question": str, "context": str}],
    "refined_idea": str,
    "intent_summary": str
  }
  ```
- Add `"clarify": "clarify.json"` to the hard-coded schema maps inside both `run_claude_step()` (line ~946) and `run_codex_step()` (line ~993).
- Update `session_key_for()` to handle `step == "clarify"` → return `f"{agent}_planner"` (shares session with plan step for continuity).
- Update `infer_next_steps()`:
  - `STATE_INITIALIZED` → `["clarify"]` (was `["plan"]`)
  - Add `STATE_CLARIFIED` → `["plan"]`
- Update `handle_init()` return value: change `"next_step": "plan"` → `"next_step": "clarify"` (line ~1307).

**Why this first:** Pure data-model and routing changes. Run existing tests immediately — the `test_infer_next_steps` parametrized test for `STATE_INITIALIZED` will fail (expects `["plan"]`), confirming the change is wired correctly.

---

## Step 2: Add `handle_clarify()` command handler + mock output

**File:** `megaplan/cli.py`

- Add clarify prompt to `create_claude_prompt()` under `step == "clarify"`:
  ```python
  if step == "clarify":
      return textwrap.dedent(f"""
          You are a planning assistant. The user has proposed the following idea:

          Idea:
          {state['idea']}

          Project directory:
          {project_dir}

          User notes:
          {notes_block}

          Requirements:
          - Read the project directory to understand the codebase.
          - Restate the idea in your own words as a precise intent summary.
          - Identify ambiguities, underspecified aspects, or implicit assumptions.
          - For each ambiguity, produce a question that, if answered, would materially change the implementation plan.
          - Propose a refined version of the idea that resolves obvious ambiguities.
          - Do NOT plan the implementation — only clarify the intent.
      """).strip()
  ```
- Add `"clarify"` case to `create_codex_prompt()` that delegates to `create_claude_prompt()` (same pattern as `plan`/`integrate`).
- Add `validate_payload("clarify", ...)` case requiring keys `["questions", "refined_idea", "intent_summary"]`.
- New function `handle_clarify(root, args)`:
  - `plan_dir, state = load_plan(root, args.plan)`
  - `require_state(state, "clarify", {STATE_INITIALIZED})`
  - `worker, agent, mode, refreshed = run_step_with_worker("clarify", state, plan_dir, args, root=root)`
  - Write `clarify.json` artifact to plan dir
  - Store `state["clarification"] = {"refined_idea": ..., "intent_summary": ..., "questions": ...}`
  - Transition `state["current_state"] = STATE_CLARIFIED`
  - Persist session, append history, save state
  - Return response with `"next_step": "plan"` and the questions for the orchestrator to present
- Add mock output in `mock_worker_output()` for `step == "clarify"`:
  ```python
  if step == "clarify":
      payload = {
          "questions": [
              {"question": "Should the feature be behind a flag?", "context": "No feature flags exist in the repo currently."},
          ],
          "refined_idea": f"Refined: {state['idea']}",
          "intent_summary": f"The user wants to {state['idea']}.",
      }
      return WorkerResult(payload=payload, raw_output=json_dump(payload), duration_ms=10, cost_usd=0.0, session_id=str(uuid.uuid4()))
  ```

---

## Step 3: Add argparse subcommand for `clarify`

**File:** `megaplan/cli.py` (in `main()` / argparse setup, around line ~2170)

- Add `clarify` subparser with the same shared flags as `plan` (`--plan`, `--agent`, `--fresh`, `--ephemeral`, `--persist`).
- Wire dispatch to `handle_clarify()` (around line ~2219 in the dispatch block).

---

## Step 4: Update `handle_plan()` to accept `STATE_CLARIFIED` and use refined idea

**File:** `megaplan/cli.py`

- Change `require_state(state, "plan", {STATE_INITIALIZED})` → `require_state(state, "plan", {STATE_INITIALIZED, STATE_CLARIFIED})`
  - `STATE_INITIALIZED` remains accepted so `plan` works without clarify (backward compat / `--skip-clarify` escape hatch).
- Update `create_claude_prompt("plan", ...)` to include clarification data when present:
  ```python
  if step == "plan":
      clarification = state.get("clarification", {})
      refined = clarification.get("refined_idea", "")
      intent = clarification.get("intent_summary", "")
      clarify_block = ""
      if refined:
          clarify_block = f"""
          Refined idea (from clarification):
          {refined}

          Intent summary:
          {intent}

          Original idea (for reference):
          {state['idea']}
          """
      # Use clarify_block in the prompt instead of raw idea when available
  ```

---

## Step 5: Thread `intent_summary` and notes into ALL downstream prompts

**File:** `megaplan/cli.py`

This addresses the core sense-checking requirement AND fixes the gap where notes are only in the plan prompt.

- Create a helper `intent_and_notes_block(state)` that returns a formatted string:
  ```python
  def intent_and_notes_block(state: dict) -> str:
      sections = []
      clarification = state.get("clarification", {})
      if clarification.get("intent_summary"):
          sections.append(f"User intent summary:\n{clarification['intent_summary']}")
          sections.append(f"Original idea:\n{state['idea']}")
      else:
          sections.append(f"Idea:\n{state['idea']}")
      notes = state.get("meta", {}).get("notes", [])
      if notes:
          notes_text = "\n".join(f"- {n['note']}" for n in notes)
          sections.append(f"User notes and answers:\n{notes_text}")
      return "\n\n".join(sections)
  ```
- Inject this block into `create_claude_prompt()` for steps: `integrate`, `review`
- Inject this block into `create_codex_prompt()` for steps: `critique`, `execute`, `review`
- Add instruction to critique and integrate prompts: `"Verify that the plan remains aligned with the user's original intent (above), not just internal plan quality."`

---

## Step 6: Gate the planner's questions — skill-layer approach

Now that notes are threaded into all prompts (Step 5), the skill-layer gate actually works.

**Files to update (all three):**
- `megaplan/data/global/skill.md` — the **shipped** skill source installed by `megaplan setup`
- `megaplan/data/AGENTS.md` — the per-project AGENTS file installed by `megaplan setup`
- `.claude/skills/megaplan.md` — this repo's local skill (for dev use only, not shipped)

Update workflow instructions in all three files:
```markdown
## Workflow

1. `megaplan init`
2. `megaplan clarify` — Read the response. Present the refined idea, intent summary,
   and clarification questions to the user. Collect their answers.
   Run `megaplan override add-note --plan <name> "<answers>"` to record them.
3. `megaplan plan` — Read the response. Present the plan's `questions` and
   `assumptions` to the user. Collect answers.
   Run `megaplan override add-note --plan <name> "<answers>"` to record them
   before proceeding.
4. `megaplan critique`
5. `megaplan evaluate`
6. If CONTINUE → `megaplan integrate`, loop to 4.
   If SKIP → `megaplan gate`.
   If ESCALATE/ABORT → present to user, use `megaplan override ...` if they choose to bypass.
7. `megaplan execute --confirm-destructive`
8. `megaplan review`
```

Add a note: "At each gate, sense-check against the user's original intent before proceeding."

---

## Step 7: Tests

**File:** `tests/test_megaplan.py`

Update existing tests:
- `test_infer_next_steps_non_evaluated_states`: change `STATE_INITIALIZED` expected from `["plan"]` to `["clarify"]`, add `(STATE_CLARIFIED, {}, ["plan"])` case
- `test_full_mock_lifecycle`: insert `megaplan.handle_clarify(root, make_args(plan=name))` after init, before plan
- `test_init_creates_state_file`: no change needed (init still creates state)

New tests:
- `test_clarify_transitions_to_clarified`: init → clarify succeeds, state is CLARIFIED, `clarify.json` exists, `state["clarification"]` has keys
- `test_clarify_requires_initialized`: calling clarify on a PLANNED state raises CliError with `code == "invalid_transition"`
- `test_plan_accepts_both_initialized_and_clarified`: plan works from INITIALIZED (skip clarify) and from CLARIFIED
- `test_plan_prompt_includes_refined_idea`: after clarify, verify `create_claude_prompt("plan", ...)` contains the refined_idea text
- `test_intent_in_critique_prompt`: after clarify + plan, verify `create_codex_prompt("critique", ...)` contains the intent_summary
- `test_notes_in_critique_prompt`: add a note via override, verify `create_codex_prompt("critique", ...)` contains the note text
- `test_init_returns_clarify_as_next_step`: verify `handle_init()` response has `"next_step": "clarify"`

---

## Implementation Order (cheap validation first)

1. **Step 1** — State, routing, schema, `__all__` export, and `infer_next_steps` changes → run existing tests, expect `test_infer_next_steps` to fail for INITIALIZED
2. **Step 7 partial** — Update `test_infer_next_steps` parametrization, write `test_init_returns_clarify_as_next_step`
3. **Step 2** — `handle_clarify()` + mock + prompt + validation
4. **Step 3** — Argparse wiring
5. **Step 4** — Update `handle_plan()` to accept CLARIFIED and use refined idea
6. **Step 5** — `intent_and_notes_block()` helper, thread into all prompts
7. **Step 6** — Update all three skill/instruction files (shipped source, AGENTS.md, local skill)
8. **Step 7 complete** — Full lifecycle test, prompt-content tests, remaining unit tests
