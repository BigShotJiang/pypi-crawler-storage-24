
# Implementation Plan: Clarification & Question-Gating Steps for Megaplan

## Current State Machine
```
init → [INITIALIZED] → plan → [PLANNED] → critique → [CRITIQUED] → evaluate → [EVALUATED] → integrate/gate → ...
```

## Proposed State Machine
```
init → [INITIALIZED] → clarify → [CLARIFIED] → plan → [PLANNED] → critique → [CRITIQUED] → evaluate → [EVALUATED] → integrate/gate → ...
```

With two new interactive gates:
1. **Clarify step** (after init, before plan) — presents the idea back, asks clarifying questions, refines intent
2. **Question gate** (after plan, before critique) — presents planner's questions/assumptions to the user for answers

---

## Step 1: Add `STATE_CLARIFIED` and the `clarify` schema

**File:** `megaplan/cli.py`

- Add `STATE_CLARIFIED = "clarified"` alongside existing states (line ~48).
- Export it in `__all__`.
- Add a `"clarify.json"` entry to `SCHEMAS` with structure:
  ```json
  {
    "clarifications": [{"question": str, "answer": str}],
    "refined_idea": str,
    "intent_summary": str,
    "confirmed": bool
  }
  ```
- Update `infer_next_steps()`:
  - `STATE_INITIALIZED` → `["clarify"]` (was `["plan"]`)
  - Add `STATE_CLARIFIED` → `["plan"]`

**Why this first:** It's a pure data-model change with no behavioral side effects. Tests will catch any regressions in the state machine immediately.

---

## Step 2: Add `handle_clarify()` command handler

**File:** `megaplan/cli.py`

- New function `handle_clarify(root, args)`:
  - Loads plan, `require_state(state, "clarify", {STATE_INITIALIZED})`
  - Generates a clarification prompt that:
    - Restates the idea
    - Asks the orchestrating agent to identify ambiguities, missing context, and assumptions
    - Requests structured output: questions, a refined/restated idea, and an intent summary
  - Runs the agent (via `run_step_with_worker`)
  - Writes `clarify.json` artifact to plan dir
  - Stores `refined_idea` and `intent_summary` on `state` for downstream steps to reference
  - Transitions state to `STATE_CLARIFIED`

- The clarification prompt should instruct the agent to:
  - Read the project directory
  - Identify what's ambiguous or underspecified in the idea
  - Propose a refined, unambiguous statement of intent
  - List questions that, if answered, would change the plan

- Add `create_clarify_prompt()` (or fold into `create_claude_prompt` under `step == "clarify"`).

- Add mock output in `mock_worker_output()` for `step == "clarify"`.

---

## Step 3: Update `handle_plan()` to require `STATE_CLARIFIED`

**File:** `megaplan/cli.py`

- Change `require_state(state, "plan", {STATE_INITIALIZED})` → `require_state(state, "plan", {STATE_INITIALIZED, STATE_CLARIFIED})`
  - Keeping `STATE_INITIALIZED` allows a `--skip-clarify` escape hatch (or we can remove it and force clarify always — open question).
- Update `create_claude_prompt("plan", ...)` to include:
  - The `refined_idea` and `intent_summary` from clarification
  - Any user-provided answers to clarification questions
  - The original idea (for sense-checking)

---

## Step 4: Gate the planner's questions — add `handle_questions()` or fold into existing flow

**Design choice:** Rather than a new state, make the planner's `questions` field a gate point that the orchestrating agent (the skill) presents to the user. This is a **skill-layer change**, not a CLI state change, because the CLI already emits questions in the plan response. The skill instructions should be updated to say: "After `megaplan plan`, present the questions and assumptions to the user. Collect answers. Feed them back via `megaplan override add-note` before proceeding to critique."

However, for full enforcement at the CLI level:

- Add `STATE_QUESTIONS_ANSWERED` between `PLANNED` and the critique step.
- Add `handle_answer_questions(root, args)`:
  - Takes `--answers` (JSON or interactive)
  - Writes `answers_v{iteration}.json`
  - Stores answers on state
  - Transitions `PLANNED → QUESTIONS_ANSWERED`
- Update `handle_critique` to require `{STATE_QUESTIONS_ANSWERED}` (or `{STATE_PLANNED, STATE_QUESTIONS_ANSWERED}` with a skip flag)

**Recommendation:** Start with the skill-layer approach (Step 4a) and add CLI enforcement (Step 4b) only if needed.

### Step 4a: Skill-layer question gate

**File:** `.claude/skills/megaplan.md`

Update the workflow section to include question gate instructions after plan.

### Step 4b (optional): CLI-level enforcement

Only if the skill-layer approach proves insufficient. Add the `STATE_QUESTIONS_ANSWERED` state and `handle_answer_questions()` as described above.

---

## Step 5: Thread `intent_summary` into downstream prompts for sense-checking

**File:** `megaplan/cli.py`

- In `create_claude_prompt()` and `create_codex_prompt()`, for steps `critique`, `integrate`, and `review`:
  - Include the original `idea` and `intent_summary` (from clarification) in the prompt
  - Add an instruction: "Verify that the plan/changes/execution remain aligned with the user's original intent, not just internal plan quality."

This ensures every step sense-checks against user intent, not just plan coherence.

---

## Step 6: Add argparse subcommand for `clarify`

**File:** `megaplan/cli.py` (in `main()` / argparse setup)

- Add `clarify` subcommand with same flags as `plan` (--plan, --agent, --fresh, etc.)
- Wire it to `handle_clarify()`

---

## Step 7: Update `AGENTS.md` and data files

**Files:** `megaplan/data/AGENTS.md`, `megaplan/data/global/skill.md`

- Update workflow description to include clarify step
- Document the question-gate pattern

---

## Step 8: Tests

**File:** `tests/test_megaplan.py`

- `test_infer_next_steps` parametrized cases: add `STATE_CLARIFIED → ["plan"]`, update `STATE_INITIALIZED → ["clarify"]`
- `test_clarify_creates_artifacts`: init → clarify succeeds, writes clarify.json, state transitions to CLARIFIED
- `test_plan_requires_clarified_state`: plan rejects INITIALIZED state (if we enforce it)
- `test_plan_after_clarify`: init → clarify → plan succeeds, plan prompt includes refined idea
- `test_full_mock_lifecycle`: update to include clarify step
- `test_intent_in_critique_prompt`: verify critique prompt includes intent_summary
- `test_clarify_mock_output`: verify mock worker returns valid clarify payload

---

## Implementation Order (cheap validation first)

1. **Step 1** — State + schema changes (pure data model, run existing tests to verify no breakage)
2. **Step 8 partial** — Write failing tests for new state transitions
3. **Step 2** — `handle_clarify()` + mock output
4. **Step 6** — Argparse wiring
5. **Step 3** — Update `handle_plan()` to use clarified state + refined idea
6. **Step 5** — Thread intent into downstream prompts
7. **Step 4a** — Skill file update
8. **Step 7** — AGENTS.md / data file updates
9. **Step 8 complete** — Fill in remaining tests
