
# Implementation Plan: Onboarding Prompt with Auto-Approve Mode

## Summary

Add a two-mode onboarding prompt to the megaplan workflow. After `init`, the orchestrator asks the user whether to auto-approve (skip only the gate→execute checkpoint) or review (pause at gate to present a plan summary and offer to read the artifact inline). The choice is persisted in plan state JSON and surfaced to the executor.

---

## Step 1: Add `auto_approve` to plan state in CLI (`cli.py`)

**File:** `megaplan/cli.py`

### 1a. Add `--auto-approve` flag to `init` subparser

In the argparse setup (~line 2330), add `--auto-approve` as a `store_true` flag on the `init` subparser.

### 1b. Persist the flag in `handle_init`

In `handle_init` (~line 1383), add `"auto_approve": bool(args.auto_approve)` inside the `state["config"]` dict. This makes it available to all subsequent steps and visible in the audit trail.

### 1c. Surface auto_approve in `handle_gate` response

In `handle_gate` (~line 1895), include `"auto_approve": state["config"].get("auto_approve", False)` in the success response dict. This lets the orchestrator see the user's choice without re-reading state.

### 1d. Surface auto_approve in `handle_execute` prompt context

In the execute worker prompt (~line 861), if `state["config"].get("auto_approve")` is true, append a line like: `"Note: User chose auto-approve mode. This execution was not manually reviewed at the gate."` This satisfies the requirement to surface the choice to the executor agent.

### 1e. Add `auto_approve` to `__all__` — not needed (it's a config field, not an export).

**Validation:** `pytest` — existing tests pass. New field is additive and defaults to `False`.

---

## Step 2: Add `auto_approve` to test fixture (`tests/test_megaplan.py`)

**File:** `tests/test_megaplan.py`

### 2a. Add `auto_approve` default to `make_args_factory`

Add `"auto_approve": False` to the `data` dict in `make_args_factory` (~line 24).

### 2b. Add test for auto_approve in state

Write a test that calls `handle_init` with `auto_approve=True` and asserts `state["config"]["auto_approve"]` is `True`.

### 2c. Add test for auto_approve in gate response

Run a plan through to gate and assert the gate response includes `"auto_approve": True` when the config flag is set.

**Validation:** `pytest` — new tests pass.

---

## Step 3: Update the skill file (`megaplan.md`)

**File:** `.claude/skills/megaplan.md`

### 3a. Add "Onboarding" section between "Start" and "Workflow"

Insert a new `## Onboarding` section after the `## Start` section. Content:

```markdown
## Onboarding

After `init` succeeds, ask the user:

> Would you like to **auto-approve** the plan and go straight to execution after the gate, or **review** the plan before executing?
>
> - **Auto-approve**: I'll run the full plan→critique→evaluate→gate loop and present results at every step, but proceed to execution automatically after a successful gate.
> - **Review** (default): I'll pause after the gate to walk you through the plan at a high level and let you inspect the full plan artifact before executing.

Based on their answer:
- If **auto-approve**, re-run init with `--auto-approve`:
  ```bash
  megaplan override add-note --plan <name> "User chose auto-approve mode"
  ```
  (The `--auto-approve` flag was already passed during init, so this note is for audit context.)
- If **review** (or no clear answer), continue with default interactive behavior.
```

Wait — actually, since the user makes this choice *after* init has already run, we need a way to set it post-init. Two options:
- Re-init (destructive, bad).
- Store it via a dedicated mechanism.

**Revised approach:** Instead of an init flag, add a `megaplan config set --plan <name> auto_approve true` mechanism, OR simply write it directly into state via the existing override system. The simplest path: add a `megaplan set-mode` subcommand, but that's heavier than needed.

**Simplest approach:** Add `--auto-approve` to `init`, and have the skill pass it during init if the user chose auto-approve. The onboarding question happens *before* running init (the skill asks the user, then runs init with or without the flag). This works because the skill instructions control when init runs.

### 3a (revised). Restructure Start + Onboarding

Move the onboarding prompt *before* init in the skill instructions:

```markdown
## Start

Before running init, ask the user:

> Would you like to **auto-approve** the plan and go straight to execution after the gate, or **review** the plan before executing?
>
> - **Auto-approve**: I'll run the full plan→critique→evaluate→gate loop, showing results at every step, but skip the final approval and proceed to execution automatically after a successful gate.
> - **Review** (default): I'll pause after the gate to summarize the plan at a high level and let you read the full plan artifact before approving execution.

Then run init, adding `--auto-approve` if the user chose auto-approve:

```bash
megaplan init --project-dir "$PROJECT_DIR" [--auto-approve] "$IDEA"
```

Read the JSON response and report:
- The plan name
- The execution mode (auto-approve or review)
- The current state
- The next step
```

### 3b. Modify step 9 (gate→execute transition) in Workflow

Replace current step 9:
```
9. After a successful gate, run `megaplan execute --confirm-destructive`.
```

With:
```
9. After a successful gate:
   - If the gate response shows `"auto_approve": true`, proceed directly: run `megaplan execute --confirm-destructive`.
   - Otherwise (**review mode**), present a high-level summary of the plan (objectives, key steps, risk flags from the evaluation) and offer to read the full plan artifact file (under `.megaplan/plans/<plan-name>/plan-vN.md`) inline. Only run execute after the user confirms.
```

### 3c. Update the Autonomy section

Add a note clarifying the relationship between auto-approve and autonomous mode:

```markdown
**Auto-approve mode** (set during onboarding) only skips the gate→execute checkpoint. All other checkpoints remain interactive. This is distinct from "run autonomously" which skips all checkpoints.
```

**Validation:** Read the updated skill file end-to-end to verify consistency and no contradictions.

---

## Step 4: End-to-end manual validation

Run a megaplan workflow in both modes (auto-approve and review) against a test idea to confirm:
1. The onboarding question appears before init.
2. `--auto-approve` is passed and persisted in state.
3. Gate response includes the `auto_approve` field.
4. In review mode, the orchestrator pauses and shows the plan summary.
5. In auto-approve mode, execution proceeds without a pause.

---

## File Change Summary

| File | Changes |
|------|---------|
| `megaplan/cli.py` | Add `--auto-approve` flag to init parser; persist in state config; surface in gate and execute responses |
| `tests/test_megaplan.py` | Add `auto_approve` to fixture defaults; add 2 new tests |
| `.claude/skills/megaplan.md` | Add onboarding section; modify step 9; update autonomy section |
