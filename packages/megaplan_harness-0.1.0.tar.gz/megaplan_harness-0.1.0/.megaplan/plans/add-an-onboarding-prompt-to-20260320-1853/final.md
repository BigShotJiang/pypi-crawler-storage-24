# Implementation Plan: Onboarding Prompt with Auto-Approve and Robustness Level

## Summary

Add a two-part onboarding prompt to the megaplan workflow. Before `init`, the orchestrator asks the user to choose:
1. **Execution mode**: auto-approve (skip only the gate→execute checkpoint) or review (default — pause at gate for plan inspection).
2. **Robustness level**: light, standard (default), or thorough — controls critique stringency and evaluate thresholds.

Both choices are persisted in plan state config, surfaced to the executor, and used by the critique prompt and evaluation logic. The execute step gains a hard gate: it refuses unless `auto_approve` is set OR an explicit `user_approved_gate` flag is present in state.

Changes span three files in the CLI/test layer and three instruction files (the bundled skill, the local dev skill, and AGENTS.md).

---

## Step 1: Add `--auto-approve` and `--robustness` flags to CLI (`megaplan/cli.py`)

### 1a. Add flags to `init` subparser (~line 2330)

Add to the `init` subparser:
- `--auto-approve` as `store_true` (default `False`)
- `--robustness` with `choices=["light", "standard", "thorough"]`, default `"standard"`

### 1b. Persist both in `handle_init` state config (~line 1389)

Add to the `state["config"]` dict:
```python
"auto_approve": bool(getattr(args, "auto_approve", False)),
"robustness": getattr(args, "robustness", "standard"),
```

### 1c. Surface `auto_approve` in `handle_gate` success response (~line 1899)

Add `"auto_approve": state["config"].get("auto_approve", False)` to the gate success response dict. This lets the orchestrator see the user's choice in the gate response JSON.

### 1d. Add `user_approved_gate` flag and enforce in `handle_execute` (~line 1910)

Add a new CLI flag `--user-approved` to the `execute` subparser (alongside `--confirm-destructive`).

In `handle_execute`, after the existing `--confirm-destructive` check, add:

```python
auto_approve = state["config"].get("auto_approve", False)
if not auto_approve and not args.user_approved:
    raise CliError(
        "missing_approval",
        "Execute requires explicit user approval (--user-approved) when auto-approve is not set. "
        "The orchestrator must confirm with the user at the gate checkpoint before proceeding."
    )
```

This is the hard gate: in review mode, the orchestrator *must* pass `--user-approved` (which it only does after the user explicitly confirms). In auto-approve mode, the flag is not required.

### 1e. Surface auto_approve and robustness in execute prompt (~line 861, `create_codex_prompt`)

In the `step == "execute"` branch, after the existing requirements, append:

```python
robustness = state["config"].get("robustness", "standard")
mode_note = ""
if state["config"].get("auto_approve"):
    mode_note = "\nNote: User chose auto-approve mode. This execution was not manually reviewed at the gate. Exercise extra caution on destructive operations."
else:
    mode_note = "\nNote: User explicitly approved this plan at the gate checkpoint."
mode_note += f"\nRobustness level: {robustness}."
```

Append `mode_note` to the prompt string.

**Validation:** `pytest` — existing tests pass (new fields default safely).

---

## Step 2: Inject robustness level into critique prompt and evaluate thresholds (`megaplan/cli.py`)

### 2a. Critique prompt (~line 829, `create_codex_prompt`)

In the `step == "critique"` branch, read `robustness = state["config"].get("robustness", "standard")` and append a robustness-aware instruction block to the Requirements section:

- **light**: `"Be pragmatic. Only flag issues that would cause real failures. Ignore style, minor edge cases, and issues the executor will naturally resolve."`
- **standard**: (no extra instruction — current behavior)
- **thorough**: `"Be exhaustive. Flag edge cases, missing error handling, performance concerns, and anything that could cause problems in production even if unlikely."`

### 2b. Evaluate thresholds (~line 1642, `build_evaluation`)

The SKIP threshold at line 1642 currently uses `weighted_score < 2.0`. Make this robustness-aware:

```python
skip_threshold = {"light": 4.0, "standard": 2.0, "thorough": 1.0}
robustness = state["config"].get("robustness", "standard")
threshold = skip_threshold.get(robustness, 2.0)
```

Then use `threshold` in place of the hardcoded `2.0`:
```python
elif iteration > 1 and weighted_score < threshold and len(weighted_history) >= 1 and weighted_score < weighted_history[-1]:
```

Similarly, the stagnation detection at line 1663 (`weighted_score >= weighted_history[-1] * 0.9`) — adjust the multiplier:
```python
stagnation_factor = {"light": 0.8, "standard": 0.9, "thorough": 0.95}
factor = stagnation_factor.get(robustness, 0.9)
```

### 2c. Surface robustness in evaluate response

Add `"robustness": state["config"].get("robustness", "standard")` to the evaluation result dict so the orchestrator can report it.

**Validation:** `pytest` — verify thresholds change with robustness setting.

---

## Step 3: Update test fixture and add tests (`tests/test_megaplan.py`)

### 3a. Add defaults to `make_args_factory` (~line 24)

Add to the `data` dict:
```python
"auto_approve": False,
"robustness": "standard",
"user_approved": False,
```

### 3b. Test: auto_approve persisted in state

Call `handle_init` with `auto_approve=True`, assert `state["config"]["auto_approve"]` is `True`.

### 3c. Test: robustness persisted in state

Call `handle_init` with `robustness="thorough"`, assert `state["config"]["robustness"]` is `"thorough"`.

### 3d. Test: auto_approve surfaced in gate response

Run a plan through to gate with `auto_approve=True`, assert gate response includes `"auto_approve": True`.

### 3e. Test: execute refuses without --user-approved in review mode

Run a plan through to gated state with `auto_approve=False`, call `handle_execute` without `user_approved=True`, assert it raises `CliError` with code `"missing_approval"`.

### 3f. Test: execute succeeds with --user-approved in review mode

Same setup, but pass `user_approved=True` — assert execution succeeds.

### 3g. Test: execute succeeds without --user-approved in auto-approve mode

Run a plan with `auto_approve=True` through to gated, call execute without `user_approved` — assert success.

### 3h. Test: robustness affects evaluate SKIP threshold

Set up a plan with `robustness="light"` and flags with weighted_score 3.0 (above standard threshold of 2.0 but below light threshold of 4.0). Assert evaluation recommends SKIP. Repeat with `robustness="thorough"` and weighted_score 1.5 — assert CONTINUE.

**Validation:** `pytest` — all new tests pass.

---

## Step 4: Update bundled skill file (`megaplan/data/global/skill.md`)

This is the source-of-truth file that `megaplan setup --global` installs into `~/.claude/skills/` and `~/.codex/skills/`.

### 4a. Replace `## Start` section

Replace with onboarding prompt that asks both questions before init:

```markdown
## Start

Before running init, ask the user two questions:

**1. Execution mode:**
> Would you like to **auto-approve** the plan or **review** it before executing?
>
> - **Auto-approve**: I'll run the full plan→critique→evaluate→gate loop, showing results at every step, but proceed to execution automatically after a successful gate.
> - **Review** (default): I'll pause after the gate to summarize the plan and let you read the full plan artifact before approving execution.

**2. Robustness level:**
> What level of scrutiny should the critique apply?
>
> - **Light**: Only flag issues that would cause real failures. Faster, fewer iterations.
> - **Standard** (default): Balanced — flags significant issues but trusts the executor on minor ones.
> - **Thorough**: Exhaustive review. Flags edge cases, performance, and unlikely-but-possible problems.

Then run init with the chosen options:

```bash
megaplan init --project-dir "$PROJECT_DIR" [--auto-approve] [--robustness light|standard|thorough] "$IDEA"
```

Read the JSON response and report:
- The plan name
- The execution mode (auto-approve or review)
- The robustness level
- The current state
- The next step
```

### 4b. Modify step 9 in the Workflow section

Replace:
```
9. After a successful gate, run `megaplan execute --confirm-destructive`.
```

With:
```
9. After a successful gate:
   - If the gate response shows `"auto_approve": true`, proceed directly: run `megaplan execute --confirm-destructive`.
   - Otherwise (**review mode**), present a high-level summary of the plan (objectives, key steps, remaining risk flags). Offer to read the full plan artifact (`.megaplan/plans/<plan-name>/final.md`) inline. After the user confirms, run `megaplan execute --confirm-destructive --user-approved`.
```

### 4c. Update the Autonomy section

Add:
```markdown
**Auto-approve mode** (set during onboarding) only skips the gate→execute checkpoint. All other checkpoints remain interactive. This is distinct from "run autonomously" which skips all checkpoints.

**Robustness level** affects how strictly the critic reviews the plan and how aggressively the evaluator recommends further iterations. It does not change the workflow steps themselves.
```

**Validation:** Read the file to verify no contradictions with existing sections.

---

## Step 5: Update AGENTS.md (`megaplan/data/AGENTS.md`)

This is the file installed by `megaplan setup` into individual projects.

### 5a. Update the Start section

Add the onboarding prompt and `--auto-approve` / `--robustness` flags, matching the skill.md changes but in the more concise AGENTS.md format:

```markdown
### Start

Before running init, ask the user about:
- **Execution mode**: auto-approve (skip final gate approval) or review (default, pause for plan inspection)
- **Robustness**: light, standard (default), or thorough

```bash
megaplan init --project-dir "$PROJECT_DIR" [--auto-approve] [--robustness light|standard|thorough] "description of the task"
```
```

### 5b. Update step 8 (gate→execute)

Replace:
```
8. After gate: `megaplan execute --confirm-destructive`
```

With:
```
8. After gate:
   - Auto-approve mode: `megaplan execute --confirm-destructive`
   - Review mode: present plan summary, offer to read `.megaplan/plans/<name>/final.md` inline, then after user confirms: `megaplan execute --confirm-destructive --user-approved`
```

### 5c. Add note about robustness to the "What it does" section

Add: `The robustness level (light/standard/thorough) controls critique depth and evaluation thresholds.`

**Validation:** Read the file to verify consistency with skill.md.

---

## Step 6: Update local dev skill file (`.claude/skills/megaplan.md`)

Apply the same onboarding, step 9, and autonomy changes as Step 4 (skill.md). This file is only used for development of megaplan itself but should stay in sync.

**Validation:** Diff against `megaplan/data/global/skill.md` to verify structural consistency.

---

## Step 7: Run full test suite and manual validation

1. `pytest` — all existing and new tests pass.
2. Manual smoke test: run `megaplan init --auto-approve --robustness light` and verify state.json contains both config fields.
3. Verify `megaplan execute --confirm-destructive` fails with `missing_approval` error when `auto_approve` is false and `--user-approved` is not passed.

---

## File Change Summary

| File | Changes |
|------|---------|
| `megaplan/cli.py` | Add `--auto-approve`, `--robustness`, `--user-approved` flags; persist in state config; enforce approval gate in execute; inject robustness into critique prompt and evaluate thresholds; surface both in gate/execute responses |
| `tests/test_megaplan.py` | Add fixture defaults; 7 new tests covering config persistence, gate response, execute approval gate, and robustness thresholds |
| `megaplan/data/global/skill.md` | Add onboarding section; modify gate→execute step; update autonomy section; add robustness note |
| `megaplan/data/AGENTS.md` | Mirror onboarding and gate→execute changes in concise format |
| `.claude/skills/megaplan.md` | Mirror skill.md changes for local dev use |
