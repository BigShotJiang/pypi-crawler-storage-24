# Code Activity Summary

**17 changes across 4 repos** (banodoco/reigh had no recent activity)

---

## 1. Multi-Guild Support for brain-of-bdnc

**The biggest effort by far.** The Discord bot that runs the Banodoco community has been refactored from single-server to multi-server architecture, enabling a second Discord guild ("Arca Gidan") alongside the original BNDC server.

### Foundation
- **`ServerConfig`** — new DB-backed per-guild configuration system with feature flags (logging, archiving, summarising, reactions, sharing), write gating, and auto-refreshing cache. Replaces hardcoded env vars for channel IDs, role IDs, and announcement channels.
- **`ContentCog`** — auto-syncs `server_content` table entries to Discord channels every 5 minutes, replacing manual posting scripts.
- **Database migrations (10 files)** — adds `guild_id` to every major table (messages, channels, summaries, reactions, competitions, grants), creates `server_config`/`server_content`/`guild_members` tables, enforces NOT NULL constraints, and adds write-gating triggers.
- **`db_handler.py` rewrite** — every write method now accepts `guild_id` and checks write permission. Competition methods use composite key `(guild_id, slug)`.
- **SQL router hardening** — `_execute_generic_query()` now raises on UPDATE/DELETE instead of silently returning empty results.
- **Backfill script** — idempotent migration that tags existing rows, copies discord_members to guild_members, seeds server_config from env vars, and seeds server_content from markdown files.

### Feature Rollout
Completes multi-guild across every remaining feature and script:
- **Competitions** — state keyed by voting channel (supports concurrent competitions across guilds)
- **Gating, grants, curating, sharing, summarising** — all guild-scoped via `_resolve_guild_id()` and server_config lookups
- **Admin chat agent** — system prompt uses per-guild `community_name`; guild_id injected into tool inputs
- **All scripts** (archive, backfill_reactions, discord_tools, view_thread, weekly_digest) — accept `--guild-id` CLI arg, apply guild filters
- **Content templating** — prompts loaded from `server_content` with `community_name`/`demonym` substitution (so the bot speaks naturally about each community)
- Also includes `docs/event_speaker_list.md` with 13 speaker slots for an upcoming event

**Scope:** ~60 files changed, ~1500+ lines added across migrations, config, and feature modules. This is a ground-up multi-tenancy refactor.

---

## 2. Video Generation Pipeline — Reigh-Worker

Backend worker improvements for the video generation pipeline, focused on continuation/stitching quality and operational fixes.

### SVI Latent Chaining
- **`wgp.py`** — loads precomputed overlapped latents from `.pt` files at generation start, saves latent tails after generation. Enables frame-level continuity between segments without re-encoding.
- **Orchestrator** — detects `svi_latent_chaining` strategy; when an LTX model is selected (which doesn't support SVI), automatically rewrites to `prefix_video_source` with 25-frame overlap as fallback.
- New tests for latent load/save and SVI config injection.

### Predecessor Resolution Refactor
- Extracted `PredecessorResult` dataclass and resolution logic into `predecessor_resolver.py`, consolidating 3 inline call sites.
- Added semantic policy flags (`requires_prefix_video_source`, `uses_svi_latent_chaining`) to `ContinuationPolicy`.
- Fixed bug where `ctx.individual_params` (non-existent attribute) would raise `AttributeError` on `TravelSegmentContext`.

### PAT Auth Unblock
- Removed `DBRuntimeContractError` that crashed task-count checks when using PAT auth (where `supabase_client` is always None).
- Fixed infinite loop for upscale sub-tasks by adding edge function path for `query_task_status`.
- Dead orchestrator recovery code removed.
- New tests added.

### NameError Fix
- One-line fix: `structure_config` → `travel_guidance_config` in a debug log. Was crashing every `individual_travel_segment` task on LTX-2 models.

### Crossfade Stitch & Registry Refactor
- **Explicit clip crossfade** — clips with known overlap are trimmed and FFmpeg-concat'd without GPU (fast path).
- **Task registry refactor** — extracted `PredecessorResult`, renamed `ImageRefs` fields for clarity (`svi_predecessor_video_for_source` → `prefix_video_for_source`).
- Generation policy renamed `requires_prefix_video_source` → `requires_video_source` (covers both prefix and SVI strategies).

---

## 3. Video Generation UI — Reigh

Frontend changes in lockstep with the worker, adding multi-model travel UI and crossfade-aware join experience.

### Travel Guidance & Multi-Model UI
- **`TravelGuidanceMode`** type system and `guidanceKind` threading through motion controls, generation policy, and request body.
- **Model selector** — LTX HD toggle in batch mode, model-aware request bodies with guidance scale.
- **Structure video overhaul** — `TravelGuidanceEditor` for camera guidance; segment settings extended with `guidanceMode`, `guidanceScale`, `selectedModel`, `ltxHdResolution`.
- Edge function fixes: ai-prompt enhancements, update-task-status.

### Predecessor Column Fix
- Edge function `get-predecessor-output` had wrong column names (`parent_id` → `parent_generation_id`, `output_location` → `location`). PostgREST silently returned no results, so every continuation-enabled segment fell back to independent generation instead of chaining.

### Crossfade Join UX
- **`complete_task` edge function** — writes `continuation_predecessor_variant_id` to variant params on completion, enabling freshness tracking.
- **`checkBoundaryFreshness`** — determines whether a join boundary can use crossfade (fast, no GPU) vs. needs full GPU regeneration.
- **`CrossfadeBanner`** — when all boundaries are continuation, hides GPU settings and shows "segments will be stitched instantly without GPU processing." Mixed boundaries show "X of Y" summary.
- Button text changes to "Stitch Segments" when all crossfade.
- Tooltips added to Enhance Prompt, Make Primary, and Continue toggles.

---

## 4. Double-Dip Orchestration Tool — megazord

### `doubledip.py` — Planner/Critic/Executor Loop
A new stateful CLI for high-rigor planning workflows between Claude Code and Codex:
- **State machine**: init → plan → critique → evaluate → gate → execute → review → done
- **Merged triage into critique** — eliminates an expensive rubber-stamp worker call
- **Weighted flag evaluation** — `flag_weight()` scores flags by category (security=3.0, correctness=2.0, completeness=1.5, maintainability=0.75) with 0.5 override for implementation-detail flags (pseudocode, placeholder, schema fields) so they don't trigger false escalations
- **Override guidance** — ESCALATE/ABORT evaluations include `suggested_override` and `override_rationale` to guide the user
- **Session management** — persistent, fresh, and ephemeral modes for both Claude and Codex workers
- **Audit logging** — costs, session IDs, artifact hashes
- Tests covering the full state machine, weighted scoring, and end-to-end workflow

---

## At a Glance

| Area | Repo | Theme |
|------|------|-------|
| Discord bot | brain-of-bdnc | Multi-guild/multi-tenancy refactor |
| Video worker | Reigh-Worker | SVI latent chaining, crossfade stitch, PAT fixes |
| Video UI | Reigh | Travel guidance UI, crossfade join UX, model selector |
| Dev tooling | megazord | Double-dip planning orchestrator |

**Cross-cutting theme:** The Reigh + Reigh-Worker changes are tightly coordinated — the worker adds crossfade stitching and latent chaining capabilities, while the UI surfaces these as user-facing features (instant stitch banner, freshness checks, model-aware generation). The brain-of-bdnc work is an independent multi-tenancy effort to run the community bot across multiple Discord servers.
