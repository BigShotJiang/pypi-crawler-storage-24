# AI Lab Practicals

Python implementations of common Artificial Intelligence algorithms.

Includes:

- DFS
- Water Jug Problem
- Tic Tac Toe (Minimax)
- Travelling Salesman Problem
- Tower of Hanoi
- Fuzzy Logic Operations
- Genetic Algorithm
- Chatbot using AIML
- Speech Translation

## Installation

pip install Duekngs