#card
def run_dee4():
    code = '''
    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    import itertools
    import random

    deck = list(itertools.product(range(1,14), ['Spades','Heart','Diamond','Clubs']))

    random.shuffle(deck)

    print("You got:")

    for i in range(5):

        card = deck[i][0]
        suit = deck[i][1]

        if card == 1:
            print("Ace of", suit)
        elif card == 11:
            print("Jack of", suit)
        elif card == 12:
            print("Queen of", suit)
        elif card == 13:
            print("King of", suit)
        else:
            print(card, "of", suit)


#Salesman
    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    from sys import maxsize
    from itertools import permutations

    V = 4

    def tsp(graph, s):

        vertex = []
        for i in range(V):
            if i != s:
                vertex.append(i)

        min_path = maxsize

        next_permutation = permutations(vertex)

        for i in next_permutation:

            current_pathweight = 0
            k = s

            for j in i:
                current_pathweight += graph[k][j]
                k = j

            current_pathweight += graph[k][s]

            min_path = min(min_path, current_pathweight)

        return min_path


    graph = [
    [0,10,15,20],
    [10,0,35,25],
    [15,35,0,30],
    [20,25,30,0]
    ]

    s = 0

    print("Minimum path =", tsp(graph, s))

    '''
    print(code)