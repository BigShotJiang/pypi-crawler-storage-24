def run_dee8():
    code = '''
    print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    # Elements
    elements = ['w','x','y','z']

    # Fuzzy sets
    A = [0.5,0.4,0.3,0.2]
    B = [0.2,0.1,0.2,1]

    def printset(m):
        for i in range(4):
            print("(",elements[i],",",m[i],")", end=" ")
        print()

    print("Set A =", end=" ")
    printset(A)

    print("Set B =", end=" ")
    printset(B)

    # UNION (max)
    U = []
    for i in range(4):
        U.append(max(A[i],B[i]))

    print("\nUnion =")
    printset(U)

    # INTERSECTION (min)
    I = []
    for i in range(4):
        I.append(min(A[i],B[i]))

    print("\nIntersection =")
    printset(I)

    # COMPLEMENT OF A
    AC = []
    for i in range(4):
        AC.append(1 - A[i])

    print("\nComplement of A =")
    printset(AC)

    # COMPLEMENT OF B
    BC = []
    for i in range(4):
        BC.append(1 - B[i])

    print("\nComplement of B =")
    printset(BC)

    # DIFFERENCE A - B = min(A, BC)
    AMB = []
    for i in range(4):
        AMB.append(min(A[i],BC[i]))

    print("\nDifference A - B =")
    printset(AMB)

    # DIFFERENCE B - A = min(B, AC)
    BMA = []
    for i in range(4):
        BMA.append(min(B[i],AC[i]))

    print("\nDifference B - A =")
    printset(BMA)

    '''

    print(code)