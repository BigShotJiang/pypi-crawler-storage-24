#DFS
def run_dee1():
    code = '''
    #print("--------SYMDS2024015--------")
    print("--------Laukik Nibre--------\n")

    graph = {
    'a': ['b', 'c'],
    'b': ['d', 'e'],
    'c': ['f'],
    'd': [],
    'e': [],
    'f': []
    }

    visited = []
    stack = []
    node = 'a'

    visited.append(node)
    stack.append(node)

    while stack:
        s = stack.pop()
        print(s, end=" ")

    for n in graph[s]:
        if n not in visited:
            visited.append(n)
            stack.append(n)



    #BFS
    print('--------SYMDS2024015--------')
    print('--------Laukik Nibre--------\n')

    graph = {
        'a': ['d', 'c', 'b'],
        'b': ['e'],
        'c': ['g', 'f'],
        'd': ['h'],
        'e': ['i'],
        'f': ['j']
    }

    visited = []
    queue = []

    node = 'a'

    visited.append(node)
    queue.append(node)

    while queue:
        s = queue.pop(0)
        print(s, end=' ')

        if s in graph:
            for n in graph[s]:
                if n not in visited:
                    visited.append(n)
                    queue.append(n)
        '''
    print(code)