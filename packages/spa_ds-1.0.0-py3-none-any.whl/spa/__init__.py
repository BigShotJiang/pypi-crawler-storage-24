import importlib.metadata
__version__ = importlib.metadata.version('spa-tk')

from qsi import *