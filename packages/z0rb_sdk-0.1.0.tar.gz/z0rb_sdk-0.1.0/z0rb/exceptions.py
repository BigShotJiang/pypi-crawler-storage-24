class Z0rbError(Exception):
    """Base exception for all z0rb SDK errors."""
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response or {}


class AuthError(Z0rbError):
    """Raised on 401 / 403 responses."""
    pass


class RateLimitError(Z0rbError):
    """Raised on 429 responses. retry_after is in seconds."""
    def __init__(self, message: str, retry_after: int = 60):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class NotFoundError(Z0rbError):
    """Raised on 404 responses."""
    pass


class ValidationError(Z0rbError):
    """Raised on 400/422 responses."""
    pass
