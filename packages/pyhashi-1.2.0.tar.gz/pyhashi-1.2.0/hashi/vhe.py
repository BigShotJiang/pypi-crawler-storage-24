import ctypes
import os
import platform

class VHEKeys:
    def __init__(self, private, public):
        self.private = private
        self.public = public

class HashiCredentials:
    def __init__(self, dna, passphrase):
        self.DNA = dna
        self.passphrase = passphrase

class VHEEncrypted:
    def __init__(self, ephemeral_public, ciphertext):
        self.ephemeral_public = ephemeral_public
        self.ciphertext = ciphertext

class VHE:
    def __init__(self):
        if platform.system() == "Windows" or platform.system() == "Darwin":
            raise OSError("PyHashi/VHE runs on Linux systems (including Android and WSL) but it cannot run in Windows without WSL while MacOS Support is an upcoming feature")
        
        base_path = os.path.dirname(os.path.abspath(__file__))
        lib_name = "libvhe_aarch64.so" if platform.machine() == "aarch64" else "libvhe_x86_64.so"
        lib_path = os.path.join(base_path, lib_name)
        
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"VHE library not found: {lib_path}")
            
        self.lib = ctypes.CDLL(lib_path)
        self._setup_lib()

    def _setup_lib(self):
        self.lib.vhe_generate_keypair.argtypes = [
            ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint8)
        ]
        self.lib.vhe_generate_keypair.restype = ctypes.c_int

        self.lib.vhe_compute_shared_secret.argtypes = [
            ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint8),
            ctypes.c_char_p, ctypes.c_char_p
        ]
        self.lib.vhe_compute_shared_secret.restype = ctypes.c_int

        self.lib.vhe_encrypt.argtypes = [
            ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint8),
            ctypes.c_size_t, ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint8)
        ]
        self.lib.vhe_encrypt.restype = ctypes.c_int

        self.lib.vhe_decrypt.argtypes = [
            ctypes.POINTER(ctypes.c_uint8), ctypes.POINTER(ctypes.c_uint8),
            ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.c_uint8)
        ]
        self.lib.vhe_decrypt.restype = ctypes.c_int

    def _to_ptr(self, data):
        return (ctypes.c_uint8 * len(data)).from_buffer_copy(data)

    def getKeys(self):
        priv = (ctypes.c_uint8 * 32)()
        pub = (ctypes.c_uint8 * 32)()
        if self.lib.vhe_generate_keypair(priv, pub) != 0:
            raise Exception("Failed to generate VHE keypair")
        return VHEKeys(bytes(priv), bytes(pub))

    def getHashiCredentials(self, peer_pub, my_priv):
        if len(peer_pub) != 32 or len(my_priv) != 32:
            raise ValueError("Keys must be exactly 32 bytes")
        
        out_dna = ctypes.create_string_buffer(33)
        out_pass = ctypes.create_string_buffer(33)
        
        if self.lib.vhe_compute_shared_secret(self._to_ptr(my_priv), self._to_ptr(peer_pub), out_dna, out_pass) != 0:
            raise Exception("Failed to compute shared secret")
            
        return HashiCredentials(out_dna.value.decode('utf-8'), out_pass.value.decode('utf-8'))

    def encrypt(self, receiver_pub, plaintext):
        if len(receiver_pub) != 32:
            raise ValueError("Receiver public key must be 32 bytes")
            
        pt_bytes = plaintext.encode() if isinstance(plaintext, str) else plaintext
        pt_len = len(pt_bytes)
        
        ephem_pub = (ctypes.c_uint8 * 32)()
        ct_len = pt_len + 32 
        ct = (ctypes.c_uint8 * ct_len)()
        
        if self.lib.vhe_encrypt(self._to_ptr(receiver_pub), self._to_ptr(pt_bytes), pt_len, ephem_pub, ct) != 0:
            raise Exception("VHE Encryption failed")
            
        return VHEEncrypted(bytes(ephem_pub), bytes(ct))

    def decrypt(self, my_priv, ephemeral_pub, ciphertext):
        if len(my_priv) != 32 or len(ephemeral_pub) != 32:
            raise ValueError("Keys must be 32 bytes")
            
        ct_len = len(ciphertext)
        if ct_len < 32:
            raise ValueError("Ciphertext too short, missing MAC")
            
        pt_len = ct_len - 32
        pt = (ctypes.c_uint8 * pt_len)()
        
        if self.lib.vhe_decrypt(self._to_ptr(my_priv), self._to_ptr(ephemeral_pub), self._to_ptr(ciphertext), ct_len, pt) != 0:
            raise PermissionError("VHE Decryption failed: Integrity error or wrong keys")
            
        return bytes(pt)
