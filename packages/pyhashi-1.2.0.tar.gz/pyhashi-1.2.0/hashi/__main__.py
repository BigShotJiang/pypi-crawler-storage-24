import argparse
import sys
from .core import Hashi
from .vhe import VHE
from .utils import generate_key, generate_dna, to_hex, from_hex

def main():
    parser = argparse.ArgumentParser(prog="hashi", description="PyHashi: HASHI & VHE Cryptography Suite CLI")
    subparsers = parser.add_subparsers(dest="cmd", help="Command to run")

    subparsers.add_parser("gen", help="Generate new HASHI Key and DNA")

    enc_parser = subparsers.add_parser("enc", help="Encrypt a file using symmetric HASHI")
    enc_parser.add_argument("-k", "--key", required=True)
    enc_parser.add_argument("-d", "--dna", required=True)
    enc_parser.add_argument("-i", "--input", required=True)
    enc_parser.add_argument("-o", "--output", required=True)

    dec_parser = subparsers.add_parser("dec", help="Decrypt a file using symmetric HASHI")
    dec_parser.add_argument("-k", "--key", required=True)
    dec_parser.add_argument("-d", "--dna", required=True)
    dec_parser.add_argument("-i", "--input", required=True)
    dec_parser.add_argument("-o", "--output", required=True)

    subparsers.add_parser("vhe-gen", help="Generate VHE Keypair (Private/Public)")

    vhe_shared_parser = subparsers.add_parser("vhe-shared", help="Compute HASHI Credentials from VHE Keys")
    vhe_shared_parser.add_argument("-k", "--mypriv", required=True)
    vhe_shared_parser.add_argument("-p", "--peerpub", required=True)

    vhe_enc_parser = subparsers.add_parser("vhe-enc", help="Encrypt a file using asymmetric VHE")
    vhe_enc_parser.add_argument("-p", "--peerpub", required=True)
    vhe_enc_parser.add_argument("-i", "--input", required=True)
    vhe_enc_parser.add_argument("-o", "--output", required=True)

    vhe_dec_parser = subparsers.add_parser("vhe-dec", help="Decrypt a file using asymmetric VHE")
    vhe_dec_parser.add_argument("-k", "--mypriv", required=True)
    vhe_dec_parser.add_argument("-i", "--input", required=True)
    vhe_dec_parser.add_argument("-o", "--output", required=True)

    args = parser.parse_args()

    if args.cmd == "gen":
        print(f"Generated Key: {generate_key()}")
        print(f"Generated DNA: {generate_dna()}")

    elif args.cmd == "enc":
        h = Hashi(args.key, args.dna)
        with open(args.input, "rb") as f: data = f.read()
        with open(args.output, "wb") as f: f.write(h.encrypt(data))
        print(f"File encrypted securely to {args.output}")

    elif args.cmd == "dec":
        h = Hashi(args.key, args.dna)
        with open(args.input, "rb") as f: data = f.read()
        with open(args.output, "wb") as f: f.write(h.decrypt(data))
        print(f"File decrypted successfully to {args.output}")

    elif args.cmd == "vhe-gen":
        vhe = VHE()
        keys = vhe.getKeys()
        print(f"VHE Private Key: {to_hex(keys.private)}")
        print(f"VHE Public Key : {to_hex(keys.public)}")

    elif args.cmd == "vhe-shared":
        vhe = VHE()
        my_priv = from_hex(args.mypriv)
        peer_pub = from_hex(args.peerpub)
        creds = vhe.getHashiCredentials(peer_pub, my_priv)
        print(f"Shared DNA       : {creds.DNA}")
        print(f"Shared Passphrase: {creds.passphrase}")

    elif args.cmd == "vhe-enc":
        vhe = VHE()
        peer_pub = from_hex(args.peerpub)
        with open(args.input, "rb") as f: data = f.read()
        enc_result = vhe.encrypt(peer_pub, data)
        with open(args.output, "wb") as f:
            f.write(enc_result.ephemeral_public + enc_result.ciphertext)
        print(f"File asymmetrically encrypted to {args.output}")

    elif args.cmd == "vhe-dec":
        vhe = VHE()
        my_priv = from_hex(args.mypriv)
        with open(args.input, "rb") as f: data = f.read()
        if len(data) < 64:
            print("Error: Invalid VHE encrypted file (too short).")
            sys.exit(1)
        ephemeral_pub = data[:32]
        ciphertext = data[32:]
        dec_result = vhe.decrypt(my_priv, ephemeral_pub, ciphertext)
        with open(args.output, "wb") as f: f.write(dec_result)
        print(f"File asymmetrically decrypted to {args.output}")

    else:
        parser.print_help()

if __name__ == "__main__":
    main()
