"""Auto-generated at build time — do not edit."""

VERSION = 'v0.16.0'
GIT_SHA_SHORT = 'de61aa3'
GIT_SHA_FULL = 'de61aa3dab46a41fdd6c620847a39b6bf9121658'
