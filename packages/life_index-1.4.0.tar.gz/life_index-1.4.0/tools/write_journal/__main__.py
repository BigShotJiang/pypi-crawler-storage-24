#!/usr/bin/env python3
"""
Life Index - Write Journal Tool - CLI Entry Point
写入日志并自动维护索引体系
"""

import argparse
import json
import sys

from .core import write_journal
from ..lib.config import ensure_dirs


def _emit_json(payload: dict) -> None:
    """Print JSON safely across Windows console encodings."""
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    try:
        print(text)
    except UnicodeEncodeError:
        fallback_text = json.dumps(payload, ensure_ascii=True, indent=2)
        print(fallback_text)


def main() -> None:
    """CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Life Index - Write Journal Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python -m tools.write_journal --data '{"date":"2026-03-04","title":"测试","content":"内容"}'
    python -m tools.write_journal --data @input.json --dry-run
    python -m tools.write_journal --verbose --data '{...}'
        """,
    )

    parser.add_argument("--data", required=True, help="JSON数据，或 @文件路径 (如 @input.json)")

    parser.add_argument("--dry-run", action="store_true", help="模拟运行，不实际写入文件")

    parser.add_argument("--verbose", action="store_true", help="输出详细日志")

    args = parser.parse_args()
    ensure_dirs()

    # 解析输入数据
    try:
        if args.data.startswith("@"):
            # 从文件读取
            file_path = args.data[1:]
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            # 直接解析JSON
            data = json.loads(args.data)
    except json.JSONDecodeError as e:
        _emit_json({"success": False, "error": f"JSON解析错误: {e}"})
        sys.exit(1)
    except FileNotFoundError:
        _emit_json({"success": False, "error": f"文件未找到: {args.data[1:]}"})
        sys.exit(1)

    if args.verbose:
        print(f"[INFO] 输入数据: {json.dumps(data, ensure_ascii=False)}", file=sys.stderr)

    # 执行写入
    result = write_journal(data, dry_run=args.dry_run)

    # 输出结果
    _emit_json(result)

    # 返回码
    sys.exit(0 if result["success"] else 1)


if __name__ == "__main__":
    main()
