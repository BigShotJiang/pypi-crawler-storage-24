"""Base model for all SDK response types."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SDKModel(BaseModel):
    """Frozen Pydantic model that ignores unknown fields.

    All SDK response models inherit from this.  Frozen models are hashable
    and prevent accidental mutation.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")
