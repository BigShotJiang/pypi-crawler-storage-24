"""Public model re-exports."""

from __future__ import annotations

from . import v1 as _v1
from .base import SDKModel

__all__ = ["SDKModel", *_v1.__all__]


def __getattr__(name: str):
    if name in _v1.__all__:
        return getattr(_v1, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(__all__)
