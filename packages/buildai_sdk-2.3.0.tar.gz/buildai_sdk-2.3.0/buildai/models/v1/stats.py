"""Stats models."""

from __future__ import annotations

from ..base import SDKModel


class OverviewStats(SDKModel):
    total_clips: int
    total_frames: int
    total_factories: int
    total_workers: int
    total_partners: int
    total_hours: float


class ClipStats(SDKModel):
    total: int
    by_status: dict[str, int] = {}
    by_factory: list[dict] = []


class FactoryStatsSummary(SDKModel):
    factories: list[dict] = []
