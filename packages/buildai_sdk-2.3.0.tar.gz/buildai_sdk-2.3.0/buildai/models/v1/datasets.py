"""Released datasets + artifact models for the public /v1 surface."""

from __future__ import annotations

from typing import Any

from ..base import SDKModel


class WebDatasetArtifacts(SDKModel):
    default_variant: str | None = None
    repo_id: str | None = None


class DatasetArtifacts(SDKModel):
    webdataset: WebDatasetArtifacts | None = None


class DatasetSummary(SDKModel):
    dataset_id: str
    name: str | None = None
    display_name: str | None = None
    description: str | None = None
    clip_count: int | None = None
    factory_count: int | None = None
    worker_count: int | None = None
    artifact_store: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class DatasetDetail(DatasetSummary):
    artifacts: DatasetArtifacts | dict[str, Any] | None = None
    request_id: str | None = None


class WebDatasetShardArtifact(SDKModel):
    artifact_id: str
    artifact_type: str | None = None  # "webdataset_shard"
    artifact_store: str | None = None  # "huggingface"
    repo_id: str | None = None
    revision: str | None = None
    variant: str | None = None
    shard_path: str | None = None
    file_name: str | None = None
    size_bytes: int | None = None
    clip_count: int | None = None
    download_url: str | None = None
