"""Clip, frame, and media public models."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ..base import SDKModel


class ClipSummaryMedia(SDKModel):
    poster_url: str | None = None
    video_url: str | None = None


class ClipDetailMedia(SDKModel):
    poster_url: str | None = None
    video_url: str | None = None
    audio_url: str | None = None
    imu_url: str | None = None


class ClipPositionContext(SDKModel):
    prev_clip_id: str | None = None
    next_clip_id: str | None = None
    worker_clip_index: int | None = None
    total_worker_clips: int | None = None


class ClipSummary(SDKModel):
    id: str
    clip_index: int
    factory_id: str | None = None
    worker_id: str | None = None
    session_id: str
    stream_id: str
    collection_id: str
    recorded_at: str | None = None
    duration_sec: float | None = None
    has_video: bool = False
    has_audio: bool = False
    has_imu: bool = False
    frame_count: int = 0
    media: ClipSummaryMedia = Field(default_factory=ClipSummaryMedia)
    deleted_at: str | None = None


class ClipDetail(ClipSummary):
    factory_code: str | None = None
    worker_code: str | None = None
    created_at: str
    updated_at: str
    media: ClipDetailMedia = Field(default_factory=ClipDetailMedia)
    position_context: ClipPositionContext | None = None


class ClipListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    collection_id: str | None = None
    partner_id: str | None = None
    factory_id: str | None = None
    worker_id: str | None = None
    session_id: str | None = None
    stream_id: str | None = None
    recorded_at_from: str | None = None
    recorded_at_to: str | None = None
    has_video: bool | None = None
    has_audio: bool | None = None
    has_imu: bool | None = None
    has_frames: bool | None = None
    state: Literal["active", "deleted", "all"] = "active"
    include_video_url: bool = False


class CreateClipRequest(SDKModel):
    id: str
    stream_id: str
    clip_index: int
    duration_sec: float | None = None
    recorded_at: str | None = None


class BatchUpsertClipsRequest(SDKModel):
    clips: list[CreateClipRequest]


class UpdateClipRequest(SDKModel):
    duration_sec: float | None = None
    recorded_at: str | None = None


class SoftDeleteClipsRequest(SDKModel):
    clip_ids: list[str]
    reason: str
