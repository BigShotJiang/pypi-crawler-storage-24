"""Stream public models."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from ..base import SDKModel


class StreamSummary(SDKModel):
    id: str
    session_id: str
    device_id: str | None = None
    modality: str
    stream_role: str
    clip_count: int = 0


class StreamDetail(StreamSummary):
    spec_overrides: dict[str, Any] = Field(default_factory=dict)
    created_at: str
    updated_at: str


class StreamListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    session_id: str | None = None
    modality: str | None = None
    stream_role: str | None = None


class CreateStreamRequest(SDKModel):
    id: str
    session_id: str
    device_id: str | None = None
    modality: str
    stream_role: str
    spec_overrides: dict[str, Any] = Field(default_factory=dict)


class StreamUpsertItem(CreateStreamRequest):
    pass


class BatchUpsertStreamsRequest(SDKModel):
    streams: list[StreamUpsertItem]
