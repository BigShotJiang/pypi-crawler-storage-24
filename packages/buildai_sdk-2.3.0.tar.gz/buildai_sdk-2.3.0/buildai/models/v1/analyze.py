"""Analyze/status public models."""

from __future__ import annotations

from typing import Any

from ..base import SDKModel


class DiversityReport(SDKModel):
    scope: str | None = None
    scope_id: str | None = None
    diversity_score: float | None = None
    coverage_score: float | None = None
    min_distance: float | None = None
    max_distance: float | None = None
    factory_count: int | None = None
    generated_at: str | None = None
    request_id: str | None = None


class NoveltyDatasetResult(SDKModel):
    dataset_name: str | None = None
    novelty_score: float | None = None
    mean_distance: float | None = None
    band: str | None = None
    band_label: str | None = None


class NoveltyReport(SDKModel):
    novelty_score: float | None = None
    novelty_percentile: float | None = None
    novelty_band: str | None = None
    datasets: list[NoveltyDatasetResult] = []
    nearest_examples: list[dict[str, Any]] | None = None
    generated_at: str | None = None
    request_id: str | None = None


class Status(SDKModel):
    status: str | None = None
    user_id: str | None = None
    audience: str | None = None
    request_id: str | None = None
