"""Search public models (space-agnostic)."""

from __future__ import annotations

from pydantic import AliasChoices, Field

from ..base import SDKModel


class CorpusFilter(SDKModel):
    source: str = "all"  # "internal" | "external" | "all"
    dataset_ids: list[str] = []
    splits: list[str] = []


class SearchHit(SDKModel):
    clip_id: str
    frame_id: str | None = None
    score: float | None = Field(
        default=None,
        validation_alias=AliasChoices("score", "similarity_score"),
    )
    match_summary: str | None = None
    preview_image_url: str | None = None
    preview_video_url: str | None = None
    factory_id: str | None = None
    worker_id: str | None = None
    recorded_at: str | None = None
    duration_sec: float | None = Field(
        default=None,
        validation_alias=AliasChoices("duration_sec", "duration_seconds"),
    )
    corpus_source: str | None = None
    dataset_id: str | None = None

    @property
    def similarity_score(self) -> float | None:
        return self.score

    @property
    def duration_seconds(self) -> float | None:
        return self.duration_sec
