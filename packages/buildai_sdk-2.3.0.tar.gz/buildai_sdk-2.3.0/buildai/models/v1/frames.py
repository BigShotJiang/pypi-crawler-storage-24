"""Frame public models."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ..base import SDKModel


class FrameSummary(SDKModel):
    id: str
    clip_id: str
    frame_index: int
    timestamp_sec: float
    image_url: str | None = None


class FrameDetail(FrameSummary):
    created_at: str


class FrameListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    clip_id: str | None = None
    timestamp_from: float | None = None
    timestamp_to: float | None = None
    state: Literal["active", "deleted", "all"] = "active"


class FrameItem(SDKModel):
    timestamp_sec: float
    frame_index: int


class ClipFramesItem(SDKModel):
    clip_id: str
    frames: list[FrameItem] = Field(default_factory=list)


class BatchUpsertFramesRequest(SDKModel):
    clips: list[ClipFramesItem] = Field(default_factory=list)
