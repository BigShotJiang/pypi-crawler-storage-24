"""Access introspection models."""

from __future__ import annotations

from uuid import UUID

from ..base import SDKModel


class AccessConstraints(SDKModel):
    allowed_ids: dict[str, list[str]] = {}
    allowed_domains: list[str] = []
    allow_unassigned: bool = True
    extra: dict[str, str | int | float | bool | None] = {}


class AccessBoundary(SDKModel):
    kind: str
    org_id: str | None = None
    partner_id: str | None = None
    assumed_by: str | None = None


class AccessIntrospection(SDKModel):
    valid: bool
    credential_id: UUID
    credential_public_id: str
    credential_family: str
    principal_id: UUID
    principal_type: str
    principal_subject: str
    principal_display_name: str
    role_names: list[str] = []
    audience: str
    mode: str
    boundary: AccessBoundary | None = None
    permissions: list[str] = []
    constraints: AccessConstraints
