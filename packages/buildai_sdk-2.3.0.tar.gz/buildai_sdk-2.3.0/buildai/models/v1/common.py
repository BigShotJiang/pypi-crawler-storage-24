"""Common v1 SDK models."""

from __future__ import annotations

from ..base import SDKModel


class WriteResult(SDKModel):
    requested: int
    applied: int
    skipped: int = 0
