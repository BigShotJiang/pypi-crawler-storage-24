"""Asset public models."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from ..base import SDKModel


class AssetSummary(SDKModel):
    id: str
    asset_type: str
    clip_id: str | None = None
    frame_id: str | None = None
    size_bytes: int | None = None


class AssetDetail(AssetSummary):
    media_url: str | None = None
    created_at: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class SignedUrlResponse(SDKModel):
    signed_url: str
    gs_uri: str
    expires_at: str


class AssetListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    clip_id: str | None = None
    frame_id: str | None = None
    asset_type: str | None = None


class CreateAssetRequest(SDKModel):
    asset_type: str
    clip_id: str | None = None
    frame_id: str | None = None
    uri: str | None = None
    size_bytes: int | None = None
    width_px: int | None = None
    height_px: int | None = None
    fps: float | None = None
    codec: str | None = None
    bitrate_kbps: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AssetUpsertItem(CreateAssetRequest):
    pass


class BatchUpsertAssetsRequest(SDKModel):
    assets: list[AssetUpsertItem] = Field(default_factory=list)
