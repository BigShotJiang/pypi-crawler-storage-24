"""Embeddings public models (space-agnostic / representation_profile only)."""

from __future__ import annotations

from ..base import SDKModel


class EmbeddingHit(SDKModel):
    entity_id: str
    entity_type: str | None = None
    clip_id: str | None = None
    similarity_score: float | None = None
    factory_id: str | None = None
    worker_id: str | None = None
    corpus_source: str | None = None
    dataset_id: str | None = None


class EmbeddingVectorItem(SDKModel):
    entity_id: str
    entity_type: str | None = None
    representation_profile: str | None = None
    embedding_version: str | None = None
    vector_dimensions: int | None = None
    vector: list[float] | None = None
    found: bool | None = None
    corpus_source: str | None = None
    dataset_id: str | None = None


class EmbeddingsBatchItem(EmbeddingVectorItem):
    pass
