"""API key models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from ..base import SDKModel


class ApiKeyPublic(SDKModel):
    id: UUID
    name: str
    key_prefix: str
    key_type: str
    description: str | None = None
    created_by: str
    scopes: list[str] = []
    audience: str = "external"
    rate_limit_rpm: int | None = None
    is_active: bool
    revoked_at: datetime | None = None
    created_at: datetime
    last_used_at: datetime | None = None
    use_count: int = 0
    expires_at: datetime | None = None


class ApiKeyWithSecret(SDKModel):
    key: ApiKeyPublic
    raw_key: str


class RotateKeyResponse(SDKModel):
    secondary_key: str
    expires_at: datetime
