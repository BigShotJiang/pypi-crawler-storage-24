"""Operations models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from ..base import SDKModel


class DailyHours(SDKModel):
    date: str
    total_hours: float
    worker_count: int


class HoursResponse(SDKModel):
    total_hours: float
    daily: list[DailyHours] = []
    by_team: dict[str, float] | None = None


class TeamSummary(SDKModel):
    team_id: UUID
    name: str
    good_hours: float
    total_hours: float
    worker_count: int


class TeamsResponse(SDKModel):
    teams: list[TeamSummary] = []


class DeviceRecord(SDKModel):
    device_id: UUID
    serial_number: str
    last_seen: datetime | None = None
    status: str


class DeviceTimelineResponse(SDKModel):
    devices: list[DeviceRecord] = []


class FactoriesOpsResponse(SDKModel):
    factories: list[dict] = []


class LogEntry(SDKModel):
    timestamp: datetime
    action: str
    actor: str
    details: dict = {}


class LogResponse(SDKModel):
    entries: list[LogEntry] = []
