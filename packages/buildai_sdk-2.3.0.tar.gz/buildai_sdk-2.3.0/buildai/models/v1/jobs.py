"""Job models."""

from __future__ import annotations

from pydantic import Field

from ..base import SDKModel


class JobSummary(SDKModel):
    id: str
    job_type: str
    entity_type: str
    status: str
    total_items: int | None = None
    chunk_count: int | None = None
    progress_pct: float = 0.0
    chunks_succeeded: int = 0
    chunks_failed: int = 0
    chunks_running: int = 0

    @property
    def job_id(self) -> str:
        return self.id


class JobDetail(JobSummary):
    pass


class JobProgress(SDKModel):
    id: str
    status: str
    progress_pct: float
    total_chunks: int
    chunks_pending: int
    chunks_running: int
    chunks_succeeded: int
    chunks_failed: int
    items_succeeded: int
    items_failed: int
    success_rate: float
    elapsed_seconds: float | None = None
    eta_seconds: float | None = None
    items_per_second: float | None = None
    chunks_per_second: float | None = None

    @property
    def job_id(self) -> str:
        return self.id


class ChunkSummary(SDKModel):
    id: str
    index: int
    status: str
    entity_count: int
    processed_count: int
    failed_count: int
    worker: str | None = None
    metrics: dict | None = None

    @property
    def chunk_id(self) -> str:
        return self.id


class SubmitResult(SDKModel):
    batch_job_name: str
    task_count: int
    machine_type: str
    gpu_type: str | None = None
    gpu_count: int = 0
    provisioning: str
    image: str
    service_account: str | None = None
    platform: str = "batch"
    region: str = "us-central1"


class SubmitPreview(SDKModel):
    manifest_id: str
    job_type: str
    model_id: str | None = None
    chunk_count: int
    task_count: int
    machine_type: str
    gpu_type: str | None = None
    gpu_count: int = 0
    provisioning: str
    image: str
    service_account: str | None = None


class ExtractIframesBacklog(SDKModel):
    total_clips: int
    oldest_priority_at: str | None = None
    newest_priority_at: str | None = None
    active_manifest_id: str | None = None


class InferFramesRealtimeValidation(SDKModel):
    selected_clips: int
    selected_frames: int
    estimated_requests: int
    estimated_chunk_count: int
    schema_root_type: str | None = None
    active_manifest_id: str | None = None
    warnings: list[str] = Field(default_factory=list)


class InferFramesRealtimeBacklog(SDKModel):
    eligible_clips: int
    eligible_frames: int
    predicted_clips: int
    predicted_frames: int
    pending_clips: int
    pending_frames: int
    coverage_pct: float
    active_manifest_id: str | None = None


class EntityFailure(SDKModel):
    id: str
    manifest_id: str
    chunk_id: str | None = None
    entity_id: str
    error_code: str | None = None
    error_message: str | None = None
    failed_at: str
    attempt: int
    retried_at: str | None = None
    resolved: bool


class FramePrediction(SDKModel):
    manifest_id: str
    frame_id: str
    clip_id: str
    factory_id: str | None = None
    worker_id: str | None = None
    model: str
    prediction: dict
    raw_response: dict | None = None
    usage_metadata: dict | None = None
    created_at: str
    updated_at: str


class WriteResult(SDKModel):
    data: dict = {}
    request_id: str = ""
