"""Prediction public models."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from ..base import SDKModel


class PredictionTypeSummary(SDKModel):
    id: str
    display_name: str
    target: str
    input_asset_type: str | None = None
    model: str
    prompt_text: str
    system_instruction: str | None = None
    response_schema: dict[str, Any] = Field(default_factory=dict)
    created_at: str
    updated_at: str


class PredictionDetail(SDKModel):
    id: str
    prediction_type_id: str
    clip_id: str
    frame_id: str | None = None
    factory_id: str
    worker_id: str
    result: dict[str, Any] = Field(default_factory=dict)
    label: str | None = None
    run_id: str | None = None
    created_at: str


class PredictionSummaryStats(SDKModel):
    prediction_type_id: str
    label: str | None = None
    count: int


class BulkPredictionsResult(SDKModel):
    data: dict[str, list[PredictionDetail]] = Field(default_factory=dict)
    request_id: str | None = None
