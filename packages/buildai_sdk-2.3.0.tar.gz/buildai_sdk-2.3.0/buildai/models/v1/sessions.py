"""Session and stream public models."""

from __future__ import annotations

from ..base import SDKModel


class SessionSummary(SDKModel):
    id: str
    factory_id: str
    worker_id: str
    started_at: str | None = None
    ended_at: str | None = None
    duration_sec: float | None = None
    stream_count: int = 0
    clip_count: int = 0


class SessionDetail(SessionSummary):
    organization_id: str
    external_session_key: str | None = None
    good_sec: int | None = None
    bad_sec: int | None = None
    created_at: str
    updated_at: str


class SessionListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    factory_id: str | None = None
    worker_id: str | None = None
    started_at_from: str | None = None
    started_at_to: str | None = None


class CreateSessionRequest(SDKModel):
    id: str
    factory_id: str
    worker_id: str
    organization_id: str
    external_session_key: str | None = None
    started_at: str | None = None
    ended_at: str | None = None


class SessionUpsertItem(CreateSessionRequest):
    good_sec: int | None = None
    bad_sec: int | None = None


class BatchUpsertSessionsRequest(SDKModel):
    sessions: list[SessionUpsertItem]
