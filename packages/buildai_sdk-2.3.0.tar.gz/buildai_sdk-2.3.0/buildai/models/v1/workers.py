"""Worker public models."""

from __future__ import annotations

from ..base import SDKModel


class WorkerSummary(SDKModel):
    id: str
    worker_code: str
    factory_id: str
    collection_id: str
    partner_id: str | None = None
    ingest_status: str
    clip_count: int = 0
    last_recorded_at: str | None = None


class WorkerDetail(WorkerSummary):
    session_count: int = 0
    stream_count: int = 0
    card_uuid: str | None = None
    created_at: str
    updated_at: str


class WorkerListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    collection_id: str | None = None
    partner_id: str | None = None
    factory_id: str | None = None


class CreateWorkerRequest(SDKModel):
    factory_id: str
    worker_code: str | None = None
    card_uuid: str | None = None


class UpdateWorkerRequest(SDKModel):
    card_uuid: str | None = None
    ingest_status: str | None = None


class WorkerUpsertItem(CreateWorkerRequest):
    id: str | None = None


class BatchUpsertWorkersRequest(SDKModel):
    workers: list[WorkerUpsertItem]
