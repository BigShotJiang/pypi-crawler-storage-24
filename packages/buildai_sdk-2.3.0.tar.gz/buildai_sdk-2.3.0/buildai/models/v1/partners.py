"""Partner models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from ..base import SDKModel


class PartnerSummary(SDKModel):
    partner_id: UUID
    slug: str
    name: str
    status: str
    created_at: datetime


class PartnerDetail(PartnerSummary):
    contact_email: str | None = None
    org_id: str | None = None
    settings: dict = {}


class KpisResponse(SDKModel):
    total_partners: int
    active_partners: int
    total_hours: float
    total_clips: int


class PartnerPaymentRecord(SDKModel):
    payment_id: UUID
    partner_id: UUID
    amount_cents: int
    currency: str
    status: str
    created_at: datetime


class ReportFactorySummary(SDKModel):
    factory_id: UUID
    date: str
    yield_pct: float
    total_clips: int
    accepted_clips: int
