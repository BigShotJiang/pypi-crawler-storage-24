"""Factory and worker public models."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ..base import SDKModel


class FactorySummary(SDKModel):
    id: str
    factory_code: str
    name: str | None = None
    collection_id: str
    partner_id: str | None = None
    recording_date: str | None = None
    status: Literal["active", "sealed", "completed", "deleted"]
    worker_count: int = 0
    clip_count: int = 0
    last_recorded_at: str | None = None


class FactoryDetail(FactorySummary):
    organization_id: str
    deployment_id: str | None = None
    country: str | None = None
    created_at: str
    updated_at: str


class FactoryListQuery(SDKModel):
    cursor: str | None = None
    page_size: int = 50
    collection_id: str | None = None
    partner_id: str | None = None
    status: Literal["active", "sealed", "completed", "deleted"] | None = None
    recording_date_from: str | None = None
    recording_date_to: str | None = None


class CreateFactoryRequest(SDKModel):
    organization_id: str
    collection_id: str
    factory_code: str | None = None
    name: str | None = None
    partner_id: str | None = None
    deployment_id: str | None = None
    recording_date: str | None = None


class UpdateFactoryRequest(SDKModel):
    name: str | None = None
    partner_id: str | None = None
    deployment_id: str | None = None
    status: Literal["active", "sealed", "completed", "deleted"] | None = None


class FactoryUpsertItem(CreateFactoryRequest):
    id: str | None = None


class BatchUpsertFactoriesRequest(SDKModel):
    factories: list[FactoryUpsertItem] = Field(default_factory=list)
