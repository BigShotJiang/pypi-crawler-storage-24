"""Public /v1 assets."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.assets import (
    AssetDetail,
    AssetSummary,
    BatchUpsertAssetsRequest,
    CreateAssetRequest,
    SignedUrlResponse,
)
from ...models.v1.common import WriteResult
from ...models.v1.pagination import Page
from ._helpers import dump_model, parse_detail, parse_page

if TYPE_CHECKING:
    from ..._http import HttpTransport


class AssetsResource:
    """client.assets — /v1/assets."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(
        self,
        *,
        clip_id: str | None = None,
        frame_id: str | None = None,
        asset_type: str | None = None,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[AssetSummary]:
        params: dict[str, Any] = {"page_size": page_size}
        for key, value in {
            "cursor": cursor,
            "clip_id": clip_id,
            "frame_id": frame_id,
            "asset_type": asset_type,
        }.items():
            if value is not None:
                params[key] = value

        return parse_page(self._http.get("/assets", params=params), AssetSummary)

    def get(self, asset_id: str) -> AssetDetail:
        return parse_detail(self._http.get(f"/assets/{asset_id}"), AssetDetail)

    def create(self, body: CreateAssetRequest) -> AssetDetail:
        return parse_detail(
            self._http.post("/assets", json=dump_model(body)),
            AssetDetail,
        )

    def batch(self, body: BatchUpsertAssetsRequest) -> WriteResult:
        return parse_detail(
            self._http.post("/assets/batch", json=dump_model(body)),
            WriteResult,
        )

    def sign(self, asset_id: str, *, ttl_seconds: int = 3600) -> SignedUrlResponse:
        return parse_detail(
            self._http.post(
                f"/assets/{asset_id}/sign",
                json={"ttl_seconds": ttl_seconds},
            ),
            SignedUrlResponse,
        )
