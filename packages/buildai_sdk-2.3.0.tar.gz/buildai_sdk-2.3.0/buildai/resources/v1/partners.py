"""Internal /v1 partners."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.pagination import Page, Pagination
from ...models.v1.partners import (
    KpisResponse,
    PartnerDetail,
    PartnerPaymentRecord,
    PartnerSummary,
    ReportFactorySummary,
)

if TYPE_CHECKING:
    from ..._http import HttpTransport


class PartnersResource:
    """client.partners — list, get, kpis, payments, reports."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(
        self,
        *,
        status: str | None = None,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[PartnerSummary]:
        params: dict[str, Any] = {"page_size": page_size}
        if cursor is not None:
            params["cursor"] = cursor
        if status is not None:
            params["status"] = status

        data = self._http.get("/partners", params=params)
        items = [PartnerSummary.model_validate(i) for i in data.get("data", [])]
        pagination = Pagination.model_validate(data.get("pagination", {}) or {})
        return Page[PartnerSummary](
            data=items, pagination=pagination, request_id=data.get("request_id")
        )

    def get(self, slug: str) -> PartnerDetail:
        data = self._http.get(f"/partners/{slug}")
        return PartnerDetail.model_validate(data)

    def kpis(self) -> KpisResponse:
        data = self._http.get("/partners/kpis")
        return KpisResponse.model_validate(data)

    def payments(
        self,
        slug: str,
        *,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[PartnerPaymentRecord]:
        params: dict[str, Any] = {"page_size": page_size}
        if cursor is not None:
            params["cursor"] = cursor

        data = self._http.get(f"/partners/{slug}/payments", params=params)
        items = [PartnerPaymentRecord.model_validate(i) for i in data.get("data", [])]
        pagination = Pagination.model_validate(data.get("pagination", {}) or {})
        return Page[PartnerPaymentRecord](
            data=items, pagination=pagination, request_id=data.get("request_id")
        )

    def reports(
        self,
        slug: str,
        *,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[ReportFactorySummary]:
        params: dict[str, Any] = {"page_size": page_size}
        if cursor is not None:
            params["cursor"] = cursor

        data = self._http.get(f"/partners/{slug}/reports", params=params)
        items = [ReportFactorySummary.model_validate(i) for i in data.get("data", [])]
        pagination = Pagination.model_validate(data.get("pagination", {}) or {})
        return Page[ReportFactorySummary](
            data=items, pagination=pagination, request_id=data.get("request_id")
        )

    def iter(self, *, status: str | None = None, page_size: int = 50):
        from ...models.v1.pagination import auto_paginate

        return auto_paginate(self.list, status=status, page_size=page_size)
