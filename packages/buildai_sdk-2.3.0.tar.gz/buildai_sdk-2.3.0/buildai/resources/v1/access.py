"""Internal /v1 access introspection."""

from __future__ import annotations

from ...models.v1.access import AccessIntrospection

if False:  # pragma: no cover
    from ..._http import HttpTransport


class AccessResource:
    """client.access — inspect resolved access for the current credential."""

    def __init__(self, http: "HttpTransport") -> None:
        self._http = http

    def inspect(self) -> AccessIntrospection:
        data = self._http.get("/auth/access")
        return AccessIntrospection.model_validate(data.get("data", {}))
