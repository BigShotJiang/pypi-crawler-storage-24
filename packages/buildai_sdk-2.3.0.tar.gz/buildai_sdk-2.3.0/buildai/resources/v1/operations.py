"""Internal /v1 operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.operations import (
    DeviceTimelineResponse,
    FactoriesOpsResponse,
    HoursResponse,
    LogResponse,
    TeamsResponse,
)

if TYPE_CHECKING:
    from ..._http import HttpTransport


class OperationsResource:
    """client.operations — hours, teams, devices, factories, log."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def hours(self, *, range: str = "7d", by_team: bool = False) -> HoursResponse:
        params: dict[str, Any] = {"range": range, "by_team": by_team}
        data = self._http.get("/operations/hours", params=params)
        return HoursResponse.model_validate(data)

    def teams(self, *, range: str = "7d") -> TeamsResponse:
        params: dict[str, Any] = {"range": range}
        data = self._http.get("/operations/teams", params=params)
        return TeamsResponse.model_validate(data)

    def devices(self, *, range: str = "7d") -> DeviceTimelineResponse:
        params: dict[str, Any] = {"range": range}
        data = self._http.get("/operations/devices", params=params)
        return DeviceTimelineResponse.model_validate(data)

    def factories(self) -> FactoriesOpsResponse:
        data = self._http.get("/operations/factories")
        return FactoriesOpsResponse.model_validate(data)

    def log(self, *, page_size: int = 50) -> LogResponse:
        params: dict[str, Any] = {"page_size": page_size}
        data = self._http.get("/operations/log", params=params)
        return LogResponse.model_validate(data)
