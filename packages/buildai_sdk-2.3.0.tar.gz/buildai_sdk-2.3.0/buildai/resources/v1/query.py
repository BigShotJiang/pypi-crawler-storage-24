"""Internal /v1 query (MCP endpoint)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.schema import QueryResponse
from ._helpers import parse_detail

if TYPE_CHECKING:
    from ..._http import HttpTransport


class QueryResource:
    """client.query — execute read-only SQL via the API."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def run(
        self,
        sql: str,
        *,
        params: dict[str, Any] | None = None,
        limit: int = 1000,
    ) -> QueryResponse:
        payload: dict[str, Any] = {"sql": sql, "limit": limit}
        if params is not None:
            payload["params"] = params
        return parse_detail(self._http.post("/query", json=payload), QueryResponse)
