"""Public /v1 frames."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.common import WriteResult
from ...models.v1.frames import BatchUpsertFramesRequest, FrameDetail, FrameSummary
from ...models.v1.pagination import Page
from ._helpers import dump_model, parse_detail, parse_page

if TYPE_CHECKING:
    from ..._http import HttpTransport


class FramesResource:
    """client.frames — /v1/frames."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(
        self,
        *,
        clip_id: str,
        timestamp_from: float | None = None,
        timestamp_to: float | None = None,
        state: str = "active",
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[FrameSummary]:
        params: dict[str, Any] = {
            "clip_id": clip_id,
            "page_size": page_size,
            "state": state,
        }
        for key, value in {
            "cursor": cursor,
            "timestamp_from": timestamp_from,
            "timestamp_to": timestamp_to,
        }.items():
            if value is not None:
                params[key] = value

        return parse_page(self._http.get("/frames", params=params), FrameSummary)

    def get(self, frame_id: str) -> FrameDetail:
        return parse_detail(self._http.get(f"/frames/{frame_id}"), FrameDetail)

    def batch(self, body: BatchUpsertFramesRequest) -> WriteResult:
        return parse_detail(
            self._http.post("/frames/batch", json=dump_model(body)),
            WriteResult,
        )
