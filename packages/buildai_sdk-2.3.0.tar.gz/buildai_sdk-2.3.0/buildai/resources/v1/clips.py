"""Public /v1 clips."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.assets import AssetDetail
from ...models.v1.clips import (
    BatchUpsertClipsRequest,
    ClipDetail,
    ClipSummary,
    CreateClipRequest,
    SoftDeleteClipsRequest,
    UpdateClipRequest,
)
from ...models.v1.common import WriteResult
from ...models.v1.frames import FrameSummary
from ...models.v1.pagination import Page
from ._helpers import dump_model, parse_detail, parse_page

if TYPE_CHECKING:
    from ..._http import HttpTransport


class ClipsResource:
    """client.clips — /v1/clips."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(
        self,
        *,
        collection_id: str | None = None,
        partner_id: str | None = None,
        factory_id: str | None = None,
        worker_id: str | None = None,
        session_id: str | None = None,
        stream_id: str | None = None,
        recorded_at_from: str | None = None,
        recorded_at_to: str | None = None,
        has_video: bool | None = None,
        has_audio: bool | None = None,
        has_imu: bool | None = None,
        has_frames: bool | None = None,
        state: str = "active",
        include_video_url: bool = False,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[ClipSummary]:
        params: dict[str, Any] = {
            "page_size": page_size,
            "state": state,
            "include_video_url": include_video_url,
        }
        for key, value in {
            "cursor": cursor,
            "collection_id": collection_id,
            "partner_id": partner_id,
            "factory_id": factory_id,
            "worker_id": worker_id,
            "session_id": session_id,
            "stream_id": stream_id,
            "recorded_at_from": recorded_at_from,
            "recorded_at_to": recorded_at_to,
            "has_video": has_video,
            "has_audio": has_audio,
            "has_imu": has_imu,
            "has_frames": has_frames,
        }.items():
            if value is not None:
                params[key] = value

        return parse_page(self._http.get("/clips", params=params), ClipSummary)

    def get(self, clip_id: str, *, state: str = "active") -> ClipDetail:
        return parse_detail(
            self._http.get(f"/clips/{clip_id}", params={"state": state}),
            ClipDetail,
        )

    def frames(
        self,
        clip_id: str,
        *,
        state: str = "active",
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[FrameSummary]:
        params: dict[str, Any] = {"page_size": page_size, "state": state}
        if cursor is not None:
            params["cursor"] = cursor
        return parse_page(self._http.get(f"/clips/{clip_id}/frames", params=params), FrameSummary)

    def assets(
        self,
        clip_id: str,
        *,
        asset_type: str | None = None,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[AssetDetail]:
        params: dict[str, Any] = {"page_size": page_size}
        if cursor is not None:
            params["cursor"] = cursor
        if asset_type is not None:
            params["asset_type"] = asset_type
        return parse_page(self._http.get(f"/clips/{clip_id}/assets", params=params), AssetDetail)

    def create(self, body: CreateClipRequest) -> ClipDetail:
        return parse_detail(
            self._http.post("/clips", json=dump_model(body)),
            ClipDetail,
        )

    def batch(self, body: BatchUpsertClipsRequest) -> WriteResult:
        return parse_detail(
            self._http.post("/clips/batch", json=dump_model(body)),
            WriteResult,
        )

    def update(self, clip_id: str, body: UpdateClipRequest) -> ClipDetail:
        return parse_detail(
            self._http.patch(f"/clips/{clip_id}", json=dump_model(body)),
            ClipDetail,
        )

    def soft_delete_batch(self, body: SoftDeleteClipsRequest) -> WriteResult:
        return parse_detail(
            self._http.post("/clips/soft-delete-batch", json=dump_model(body)),
            WriteResult,
        )
