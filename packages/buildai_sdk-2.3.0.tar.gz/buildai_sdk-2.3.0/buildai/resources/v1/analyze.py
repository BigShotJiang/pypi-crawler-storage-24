"""Public /v1 analyze + auth status."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.analyze import DiversityReport, NoveltyDatasetResult, NoveltyReport, Status

if TYPE_CHECKING:
    from ..._http import HttpTransport


class AnalyzeResource:
    """client.analyze — diversity, novelty, and auth status."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def diversity(self) -> DiversityReport:
        data = self._http.get("/analyze/diversity")
        return DiversityReport.model_validate(data)

    def novelty(
        self,
        *,
        image_base64: str | None = None,
        image_url: str | None = None,
        k: int = 50,
    ) -> NoveltyReport:
        payload: dict[str, Any] = {"k": k}
        if image_base64 is not None:
            payload["image_base64"] = image_base64
        if image_url is not None:
            payload["image_url"] = image_url
        data = self._http.post("/analyze/novelty", json=payload)

        # Current API returns `datasets` list, which we adapt to the stable model.
        datasets = [NoveltyDatasetResult.model_validate(i) for i in data.get("datasets", [])]
        return NoveltyReport(
            novelty_score=data.get("novelty_score"),
            datasets=datasets,
            request_id=data.get("request_id"),
        )

    def status(self) -> Status:
        payload = self._http.get("/auth/status")
        data = payload.get("data", {}) if isinstance(payload, dict) else {}
        request_id = payload.get("request_id") if isinstance(payload, dict) else None
        if isinstance(data, dict):
            return Status.model_validate({**data, "request_id": request_id})
        return Status.model_validate({})
