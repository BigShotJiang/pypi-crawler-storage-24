"""Tiny helpers for v1 response envelopes."""

from __future__ import annotations

from typing import Any, TypeVar

from pydantic import BaseModel

from ...models.v1.pagination import Page, Pagination

T = TypeVar("T", bound=BaseModel)


def dump_model(model: BaseModel) -> dict[str, Any]:
    return model.model_dump(mode="json", exclude_none=True)


def parse_detail(payload: dict[str, Any], model: type[T]) -> T:
    return model.model_validate(payload.get("data", {}))


def parse_page(payload: dict[str, Any], model: type[T]) -> Page[T]:
    return Page[T](
        data=[model.model_validate(item) for item in payload.get("data", [])],
        pagination=Pagination.model_validate(payload.get("pagination", {})),
        request_id=payload.get("request_id"),
    )
