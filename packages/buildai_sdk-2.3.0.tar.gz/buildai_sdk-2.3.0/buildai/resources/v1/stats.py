"""Public /v1 stats."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...models.v1.stats import ClipStats, FactoryStatsSummary, OverviewStats

if TYPE_CHECKING:
    from ..._http import HttpTransport


class StatsResource:
    """client.stats — overview, clips, factories."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def overview(self) -> OverviewStats:
        data = self._http.get("/stats/overview")
        return OverviewStats.model_validate(data)

    def clips(self) -> ClipStats:
        data = self._http.get("/stats/clips")
        return ClipStats.model_validate(data)

    def factories(self) -> FactoryStatsSummary:
        data = self._http.get("/stats/factories")
        return FactoryStatsSummary.model_validate(data)
