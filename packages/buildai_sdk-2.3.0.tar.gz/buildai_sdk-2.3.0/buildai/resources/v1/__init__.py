"""Public /v1 resource namespaces."""

from .access import AccessResource
from .analyze import AnalyzeResource
from .assets import AssetsResource
from .clips import ClipsResource
from .datasets import DatasetsResource
from .embeddings import EmbeddingsResource
from .factories import FactoriesResource
from .frames import FramesResource
from .jobs import JobsResource
from .keys import KeysResource
from .operations import OperationsResource
from .partners import PartnersResource
from .predictions import PredictionsResource
from .query import QueryResource
from .schema import SchemaResource
from .search import SearchResource
from .sessions import SessionsResource
from .stats import StatsResource
from .streams import StreamsResource
from .workers import WorkersResource

__all__ = [
    "AccessResource",
    "AnalyzeResource",
    "AssetsResource",
    "ClipsResource",
    "DatasetsResource",
    "EmbeddingsResource",
    "FactoriesResource",
    "FramesResource",
    "JobsResource",
    "KeysResource",
    "OperationsResource",
    "PartnersResource",
    "PredictionsResource",
    "QueryResource",
    "SchemaResource",
    "SearchResource",
    "SessionsResource",
    "StatsResource",
    "StreamsResource",
    "WorkersResource",
]
