"""Public /v1 streams."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...models.v1.common import WriteResult
from ...models.v1.pagination import Page
from ...models.v1.streams import (
    BatchUpsertStreamsRequest,
    CreateStreamRequest,
    StreamDetail,
    StreamSummary,
)
from ._helpers import dump_model, parse_detail, parse_page

if TYPE_CHECKING:
    from ..._http import HttpTransport


class StreamsResource:
    """client.streams — /v1/streams."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(
        self,
        *,
        session_id: str | None = None,
        modality: str | None = None,
        stream_role: str | None = None,
        page_size: int = 50,
        cursor: str | None = None,
    ) -> Page[StreamSummary]:
        params: dict[str, Any] = {"page_size": page_size}
        for key, value in {
            "cursor": cursor,
            "session_id": session_id,
            "modality": modality,
            "stream_role": stream_role,
        }.items():
            if value is not None:
                params[key] = value

        return parse_page(self._http.get("/streams", params=params), StreamSummary)

    def get(self, stream_id: str) -> StreamDetail:
        return parse_detail(self._http.get(f"/streams/{stream_id}"), StreamDetail)

    def create(self, body: CreateStreamRequest) -> StreamDetail:
        return parse_detail(
            self._http.post("/streams", json=dump_model(body)),
            StreamDetail,
        )

    def batch(self, body: BatchUpsertStreamsRequest) -> WriteResult:
        return parse_detail(
            self._http.post("/streams/batch", json=dump_model(body)),
            WriteResult,
        )
