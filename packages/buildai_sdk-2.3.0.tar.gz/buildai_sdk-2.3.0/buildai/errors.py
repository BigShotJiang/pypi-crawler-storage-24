"""SDK error types."""

from __future__ import annotations

from typing import Any


class BuildAIError(Exception):
    """Base SDK error."""


class ApiError(BuildAIError):
    """HTTP error from the BuildAI API."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "HTTP_ERROR",
        retryable: bool = False,
        status_code: int | None = None,
        request_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.status_code = status_code
        self.request_id = request_id
        self.details = details

    def __repr__(self) -> str:
        parts = [
            f"status_code={self.status_code}",
            f"code={self.code!r}",
            f"retryable={self.retryable}",
        ]
        if self.request_id:
            parts.append(f"request_id={self.request_id!r}")
        return f"{type(self).__name__}({', '.join(parts)})"


AuthenticationError = ApiError
PermissionDenied = ApiError
NotFoundError = ApiError
ValidationError = ApiError
RateLimitError = ApiError
ServiceUnavailableError = ApiError


class ConfigError(BuildAIError):
    """Missing or invalid SDK configuration (e.g. no API key)."""
