"""BuildAI Python SDK."""

from __future__ import annotations

from ._version import __version__
from .client import Client
from .errors import (
    ApiError,
    AuthenticationError,
    BuildAIError,
    ConfigError,
    NotFoundError,
    PermissionDenied,
    RateLimitError,
    ServiceUnavailableError,
    ValidationError,
)
from .models.v1 import __all__ as _model_exports
from .models.v1.pagination import auto_paginate
from . import models as _models

__all__ = [
    "__version__",
    "Client",
    "BuildAIError",
    "ApiError",
    "AuthenticationError",
    "PermissionDenied",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServiceUnavailableError",
    "ConfigError",
    "auto_paginate",
    *_model_exports,
]


def __getattr__(name: str):
    if name in _model_exports:
        return getattr(_models, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(__all__)
