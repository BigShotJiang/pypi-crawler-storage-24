"""
Servidor MCP principal para Agent Skills.

Este módulo implementa o servidor MCP que orquestra todos os componentes
seguindo os princípios SOLID:

- Single Responsibility: SkillServer apenas orquestra componentes
- Open/Closed: Extensível via herança, fechado para modificação
- Liskov Substitution: Pode ser substituído por subclasses
- Interface Segregation: Interfaces pequenas e focadas
- Dependency Inversion: Depende de abstrações (SkillDiscovery, SkillTools)
"""

import logging
from pathlib import Path

import uvicorn
from fastmcp import FastMCP

from .discovery import SkillDiscovery
from .models import Skill, SkillResource
from .tools import SkillTools

logger = logging.getLogger(__name__)


class SkillServer:
    """
    Servidor MCP para servir Agent Skills via HTTP/SSE.
    
    Esta classe implementa o padrão Facade, fornecendo uma interface
    simples para um subsistema complexo (MCP + Skills + Resources).
    
    Attributes:
        skills_dir: Diretório contendo as skills
        name: Nome do servidor MCP
        version: Versão do servidor
        mcp: Instância do FastMCP
    """
    
    def __init__(
        self,
        skills_dir: str | Path,
        name: str = "SkillServer",
        version: str = "0.1.0",
        log_level: str = "INFO",
    ):
        """
        Inicializa o servidor MCP.
        
        Args:
            skills_dir: Diretório contendo as skills
            name: Nome do servidor MCP
            version: Versão do servidor
            log_level: Nível de logging (DEBUG, INFO, WARNING, ERROR)
            
        Raises:
            ValueError: Se o diretório de skills não existir
        """
        self.skills_dir = Path(skills_dir)
        self.name = name
        self.version = version
        
        # Setup de logging
        self._setup_logging(log_level)
        
        # Inicializa FastMCP
        self.mcp = FastMCP(name=name, version=version)
        
        # Inicializa componentes (Dependency Injection)
        self.discovery = SkillDiscovery(self.skills_dir)
        self.tools = SkillTools(self.mcp)
        
        # Descobre e registra skills
        self._discover_and_register()
        
        logger.info(f"{name} v{version} initialized")
    
    def _setup_logging(self, log_level: str) -> None:
        """
        Configura o sistema de logging.
        
        Args:
            log_level: Nível de logging desejado
        """
        numeric_level = getattr(logging, log_level.upper(), None)
        if not isinstance(numeric_level, int):
            numeric_level = logging.INFO
        
        logging.basicConfig(
            level=numeric_level,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )
    
    def _discover_and_register(self) -> None:
        """
        Descobre skills e recursos, registrando-os no MCP.
        
        Este método orquestra o processo de descoberta e registro,
        delegando responsabilidades para os componentes especializados.
        """
        # Descobre skills
        skills = self.discovery.discover_skills()
        
        if not skills:
            logger.warning("No skills found - server will start but have no tools")
            return
        
        # Registra skills como ferramentas MCP
        self.tools.register_skills(skills)
        
        # Descobre e registra recursos
        all_resources = []
        for skill in skills:
            resources = self.discovery.discover_resources(skill)
            all_resources.extend(resources)
        
        if all_resources:
            self.tools.register_resources(all_resources)
        
        logger.info(
            f"Discovery complete: {len(skills)} skills, "
            f"{len(all_resources)} resources"
        )
    
    def get_asgi_app(self):
        """
        Retorna a aplicação ASGI do FastMCP.
        
        Returns:
            Aplicação ASGI pronta para uso com uvicorn ou outro servidor
            
        Note:
            Este método permite usar o servidor com outros ASGI servers
            ou integrá-lo em aplicações existentes.
        """
        return self.mcp.http_app()
    
    def run(self, host: str = "0.0.0.0", port: int = 8000) -> None:
        """
        Inicia o servidor MCP.
        
        Args:
            host: Endereço para bind (padrão: 0.0.0.0)
            port: Porta para o servidor (padrão: 8000)
            
        Note:
            Este método bloqueia a execução até o servidor ser encerrado.
        """
        logger.info(f"Starting MCP server on {host}:{port}")
        logger.info(f"Skills directory: {self.skills_dir.absolute()}")
        logger.info(f"Serving {len(self.tools.skills)} skills")
        
        # Usa uvicorn para servir a aplicação ASGI
        uvicorn.run(
            self.get_asgi_app(),
            host=host,
            port=port,
            log_level="info",
        )


def create_server(
    skills_dir: str | Path,
    host: str = "0.0.0.0",
    port: int = 8000,
    name: str = "SkillServer",
    version: str = "0.1.0",
    log_level: str = "INFO",
    run: bool = True,
) -> SkillServer:
    """
    Função de conveniência para criar e opcionalmente iniciar um servidor MCP.
    
    Esta é a API pública principal da biblioteca, fornecendo uma forma
    simples e direta de criar servidores de skills.
    
    Args:
        skills_dir: Diretório contendo as skills
        host: Endereço para bind (padrão: 0.0.0.0)
        port: Porta para o servidor (padrão: 8000)
        name: Nome do servidor MCP
        version: Versão do servidor
        log_level: Nível de logging (DEBUG, INFO, WARNING, ERROR)
        run: Se True, inicia o servidor imediatamente
        
    Returns:
        Instância do SkillServer criado
        
    Example:
        >>> # Criar e iniciar servidor
        >>> create_server("./skills")
        
        >>> # Criar servidor sem iniciar (para testes ou uso customizado)
        >>> server = create_server("./skills", run=False)
        >>> app = server.get_asgi_app()
        
    Raises:
        ValueError: Se o diretório de skills não existir
    """
    server = SkillServer(
        skills_dir=skills_dir,
        name=name,
        version=version,
        log_level=log_level,
    )
    
    if run:
        server.run(host=host, port=port)
    
    return server
