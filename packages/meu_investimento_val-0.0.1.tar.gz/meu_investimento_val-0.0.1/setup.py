from setuptools import setup, find_packages

setup(
    name="meu-investimento-val",  
    version="0.0.1",
    author="Val Faria",
    description="Biblioteca para cálculos de investimentos",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
)