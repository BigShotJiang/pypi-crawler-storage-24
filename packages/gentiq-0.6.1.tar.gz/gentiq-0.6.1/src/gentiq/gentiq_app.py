from __future__ import annotations

from contextlib import asynccontextmanager
from enum import Enum
from typing import Any, TypeVar, overload

import logfire
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic_ai import Agent

from .api.router import api_router
from .core import AgentDeps
from .database import Database, UserDocument
from .engines import BaseDBEngine, BaseStorageEngine, FileSystemEngine, MinioEngine, MongoEngine, SQLiteEngine
from .env import APP_NAME as DEFAULT_APP_NAME
from .env import LOGFIRE_API_KEY, LOGFIRE_TOKEN
from .storage import Storage


T_Context = TypeVar("T_Context")


class GentiqApp[T_Context]:
    """
    The core application class for the Gentiq framework.

    GentiqApp serves as the central orchestration point, integrating FastAPI,
    PydanticAI, a database (like MongoDB, SQLite, etc.), and persistent storage (like MinIO, etc.)
    into a cohesive environment for building advanced AI-driven applications.

    It automates the setup of:
    - **FastAPI**: A high-performance web API with automatic documentation.
    - **Database**: Extensible persistence layer with built-in support for SQLite and MongoDB.
    - **Storage**: Abstracted file storage for managing attachments and assets.
    - **Agent Orchestration**: Seamless integration of PydanticAI agents with shared dependencies.
    - **Observability**: Integrated monitoring and tracing with Logfire.

    Attributes:
        app_name (str): The name of the application, used in API documentation and resource labeling.
        api (FastAPI): The underlying FastAPI instance.
        agent (Agent): The primary AI agent instance.
        title_agent (Agent | None): The agent responsible for generating conversation titles.
        context (T_Context): Shared application context available to all tools and agents.
        database (Database): The initialized database facade.
        storage (Storage): The initialized storage facade.

    Args:
        agent (Agent[AgentDeps[T_Context]]):
            The primary Agent instance. It must be typed to accept `AgentDeps[T_Context]` as its dependencies.
        context (T_Context, optional):
            An optional user-defined context object (e.g., database clients, config, services). This context is injected
            into agent dependencies and accessible in tools via `deps.context`.
        app_name (str, optional):
            An optional name for the application. Used as the FastAPI title and for naming default database files. Defaults to "gentiq".
        db (str | BaseDBEngine, optional):
            The database backend to use. Accepts a string identifier ('sqlite', 'mongodb') or a pre-configured `BaseDBEngine` instance.
            Defaults to "sqlite".
        db_config (dict[str, Any], optional):
            Optional configuration for the database engine (e.g., connection strings, credentials).
        storage (str | BaseStorageEngine, optional):
            The storage backend to use for file persistence. Accepts a string ('filesystem', 'minio') or a pre-configured
            `BaseStorageEngine` instance. Defaults to "filesystem".
        storage_config (dict[str, Any], optional):
            Optional configuration for the storage backend (e.g., access keys, endpoints).
        use_title_agent (bool, optional):
            Whether to enable automatic title generation for new conversations.
        title_agent (Agent[Any, str], optional):
            An optional custom Agent for title generation. If omitted and title generation is enabled, a default implementation is used.
        logfire_token (str, optional):
            Optional Logfire token for telemetry and monitoring.
        send_to_logfire (bool, optional):
            Whether to enable Logfire telemetry. Defaults to False.
    """

    @overload
    def __init__(
        self,
        agent: Agent[AgentDeps[T_Context]],
        context: T_Context,
        app_name: str | None = None,
        db: str | BaseDBEngine = "sqlite",
        db_config: dict[str, Any] | None = None,
        storage: str | BaseStorageEngine = "filesystem",
        storage_config: dict[str, Any] | None = None,
        use_title_agent: bool | None = None,
        title_agent: Agent[Any, str] | None = None,
        logfire_token: str | None = None,
        send_to_logfire: bool = False,
    ) -> None: ...

    @overload
    def __init__(
        self: GentiqApp[None],
        agent: Agent[AgentDeps[None]],
        context: None = None,
        app_name: str | None = None,
        db: str | BaseDBEngine = "sqlite",
        db_config: dict[str, Any] | None = None,
        storage: str | BaseStorageEngine = "filesystem",
        storage_config: dict[str, Any] | None = None,
        use_title_agent: bool = True,
        title_agent: Agent[Any, str] | None = None,
        logfire_token: str | None = None,
        send_to_logfire: bool = False,
    ) -> None: ...

    def __init__(
        self,
        agent: Agent[AgentDeps[T_Context]],
        context: Any = None,
        app_name: str | None = None,
        db: str | BaseDBEngine = "sqlite",
        db_config: dict[str, Any] | None = None,
        storage: str | BaseStorageEngine = "filesystem",
        storage_config: dict[str, Any] | None = None,
        title_agent: Agent[Any, str] | None = None,
        logfire_token: str | None = None,
        send_to_logfire: bool = False,
    ):
        self.app_name = app_name or DEFAULT_APP_NAME
        self.api = FastAPI(title=self.app_name, lifespan=self.lifespan)

        self.agent = agent

        self.title_agent = title_agent

        self.context = context

        # Initialize core components through dedicated factory methods
        self.database = self._init_database(db, db_config)
        self.storage = self._init_storage(storage, storage_config)

        self._setup_default_middleware()
        self._setup_default_routes()
        self._setup_monitoring(logfire_token, send_to_logfire)

    def _init_database(self, db: str | BaseDBEngine, config: dict[str, Any] | None) -> Database:
        """Initialize the database engine and facade."""

        if isinstance(db, BaseDBEngine):
            if config:
                raise ValueError("db_config is not allowed when providing a database engine instance.")
            return Database(engine=db)

        # Handle string identifiers (type selector)
        config = config or {}

        if db == "sqlite":
            uri = config.get("uri") or f"sqlite:///{(self.app_name or DEFAULT_APP_NAME).lower()}.db"
            engine = SQLiteEngine(uri, **config)
            return Database(engine=engine)

        elif db == "mongodb":
            from .env import (
                MONGODB_DB_NAME,
                MONGODB_PASSWORD,
                MONGODB_URI,
                MONGODB_USERNAME,
            )

            # Prepare default configuration from constants
            mongo_kwargs = {
                "uri": MONGODB_URI,
                "db_name": MONGODB_DB_NAME,
                "username": MONGODB_USERNAME,
                "password": MONGODB_PASSWORD,
            }
            # Overwrite defaults with provided config
            mongo_kwargs.update(config)

            engine = MongoEngine(
                uri=str(mongo_kwargs["uri"]),
                db_name=str(mongo_kwargs["db_name"]),
                username=mongo_kwargs.get("username"),
                password=mongo_kwargs.get("password"),
            )
            return Database(engine=engine)
        else:
            raise ValueError(
                f"Unsupported database type: {db}. Expected 'sqlite' or 'mongodb', or a BaseDBEngine instance."
            )

    def _init_storage(self, storage: str | BaseStorageEngine, config: dict[str, Any] | None) -> Storage:
        """Initialize the storage backend."""
        if isinstance(storage, BaseStorageEngine):
            if config:
                raise ValueError("storage_config is not allowed when providing a storage engine instance.")
            return Storage(engine=storage)

        config = config or {}

        if storage == "minio":
            from .env import (
                MINIO_ACCESS_KEY,
                MINIO_ENDPOINT,
                MINIO_SECRET_KEY,
            )

            minio_kwargs = {
                "endpoint": MINIO_ENDPOINT,
                "access_key": MINIO_ACCESS_KEY,
                "secret_key": MINIO_SECRET_KEY,
                "secure": False,
            }
            minio_kwargs.update(config)
            engine = MinioEngine(
                endpoint=str(minio_kwargs["endpoint"]),
                access_key=str(minio_kwargs["access_key"]),
                secret_key=str(minio_kwargs["secret_key"]),
                secure=bool(minio_kwargs["secure"]),
            )
            return Storage(engine=engine)

        elif storage == "filesystem":
            base_path = config.get("base_path") or "./.storage"
            engine = FileSystemEngine(base_path=base_path)
            return Storage(engine=engine)
        else:
            raise ValueError(
                f"Unsupported storage type: {storage}. "
                "Expected 'minio' or 'filesystem', or a BaseStorageEngine instance."
            )

    def add_middleware(self, middleware_class: type, **options: Any):
        """Add a middleware to the FastAPI application."""
        self.api.add_middleware(middleware_class, **options)

    def add_router(self, router: Any, prefix: str = "", tags: list[str | Enum] | None = None):
        """Include an external router into the application."""
        self.api.include_router(router, prefix=prefix, tags=tags)

    def create_agent_deps(self, user: UserDocument) -> AgentDeps[T_Context]:
        """Create a new instance of Agent dependencies for a specific user."""

        return AgentDeps[T_Context](
            database=self.database,
            storage=self.storage,
            user=user,
            context=self.context,
        )

    @asynccontextmanager
    async def lifespan(self, app: FastAPI):
        """Manage the FastAPI application lifecycle."""
        app.state.database = self.database
        app.state.storage = self.storage
        app.state.agent = self.agent
        app.state.title_agent = self.title_agent
        app.state.create_agent_deps = self.create_agent_deps
        yield

    def _setup_default_middleware(self):
        """Configure default middleware."""
        self.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_default_routes(self):
        """Initialize core framework routes."""
        self.add_router(api_router, prefix="/api")

        @self.api.get("/health", tags=["System"])
        async def health_check() -> dict[str, str]:
            return {"status": "healthy"}

    def _setup_monitoring(self, logfire_token: str | None = None, send_to_logfire: bool = False):
        """Configure observability and monitoring."""

        if logfire_token or send_to_logfire:
            logfire.configure(
                send_to_logfire="if-token-present",
                api_key=LOGFIRE_API_KEY,
                token=logfire_token or LOGFIRE_TOKEN,
            )
            logfire.instrument_pydantic_ai()
