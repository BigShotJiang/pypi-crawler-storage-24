__all__ = ["get_openai_model", "get_anthropic_model", "get_google_model"]


def get_openai_model(model_name: str, proxy: str | None = None):
    """
    Create OpenAI model with optional proxy.
    """
    import httpx
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = OpenAIProvider(http_client=http_client)
    else:
        provider = OpenAIProvider()

    openai_model = OpenAIChatModel(model_name=model_name, provider=provider)

    return openai_model


def get_anthropic_model(model_name: str, proxy: str | None = None):
    """
    Create Anthropic model with optional proxy.
    """
    import httpx
    from pydantic_ai.models.anthropic import AnthropicModel
    from pydantic_ai.providers.anthropic import AnthropicProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = AnthropicProvider(http_client=http_client)
    else:
        provider = AnthropicProvider()

    anthropic_model = AnthropicModel(model_name=model_name, provider=provider)

    return anthropic_model


def get_google_model(model_name: str, proxy: str | None = None):
    """
    Create Google model with optional proxy.
    """
    import httpx
    from pydantic_ai.models.google import GoogleModel
    from pydantic_ai.providers.google import GoogleProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = GoogleProvider(http_client=http_client)
    else:
        provider = GoogleProvider()

    google_model = GoogleModel(model_name=model_name, provider=provider)

    return google_model
