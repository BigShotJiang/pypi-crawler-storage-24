import asyncio
from dataclasses import dataclass, field

from ..database import Database, UserDocument
from ..storage import Storage
from .events import ThreadStreamEvent


@dataclass
class AgentDeps[T_Context]:
    """
    Standard agent dependencies for the Gentiq framework.
    Hides internal complexity (DB, Storage) from the developer.
    """

    database: Database
    storage: Storage
    user: UserDocument
    context: T_Context

    # Internal event queue for streaming custom events
    _event_queue: asyncio.Queue = field(default_factory=asyncio.Queue, init=False, repr=False)

    async def stream(self, event: ThreadStreamEvent):
        await self._event_queue.put(event)

    async def stream_events(self):
        while True:
            event = await self._event_queue.get()
            if event is None:
                break
            yield event
