"""
A lightweight agent that generates concise chat titles (2-8 words)
using gpt-5-nano. Designed to run as a fire-and-forget background task.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pydantic_ai import Agent

from ..env import HTTP_PROXY
from .model_utils import get_anthropic_model, get_google_model, get_openai_model


if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

DEFAULT_TITLE_INSTRUCTIONS = (
    "You are a title generator. Given a user question and an assistant response, "
    "produce a short, descriptive title of 2 to 5 words that captures the topic. "
    "Output ONLY the title text — no quotes, no explanation, no punctuation at the end."
)


def create_title_agent(model_name: str, instructions: str = DEFAULT_TITLE_INSTRUCTIONS, proxy: str | None = HTTP_PROXY):
    """
    Create a title agent that generates a title for the conversation based on the first user message and it's response.
    """
    if model_name.startswith("gpt"):
        model = get_openai_model(model_name, proxy)
    elif model_name.startswith("claude"):
        model = get_anthropic_model(model_name, proxy)
    elif model_name.startswith("gemini"):
        model = get_google_model(model_name, proxy)
    else:
        raise ValueError(f"Unsupported model: {model_name}")

    return Agent(
        name="title_agent",
        instructions=instructions,
        model=model,
    )
