from .engines import BaseStorageEngine
from .env import ATTACHMENTS_BUCKET


class Storage:
    """Storage interface for file uploads and downloads, saving and loading attachments, etc."""

    attachments_container: str = ATTACHMENTS_BUCKET

    def __init__(self, engine: BaseStorageEngine):
        self.engine = engine

        # Ensure attachments container exists
        if not self.engine.container_exists(container=self.attachments_container):
            self.engine.create_container(container=self.attachments_container)

    def upload(self, content: bytes, object_name: str, container: str | None = None) -> None:
        """Upload content to storage."""
        from io import BytesIO

        target_container = container or self.attachments_container
        self.engine.upload(
            container=target_container,
            object_name=object_name,
            data=BytesIO(content),
            length=len(content),
        )

    def download(self, object_name: str, container: str | None = None) -> bytes:
        """Download content from storage."""
        target_container = container or self.attachments_container
        response = self.engine.download(container=target_container, object_name=object_name)
        try:
            return response.read()
        finally:
            if hasattr(response, "close"):
                response.close()
            if hasattr(response, "release_conn"):
                response.release_conn()

    def delete(self, object_name: str, container: str | None = None) -> None:
        """Delete content from storage."""
        target_container = container or self.attachments_container
        self.engine.delete(container=target_container, object_name=object_name)

    def exists(self, object_name: str, container: str | None = None) -> bool:
        """Check if an object exists in storage."""
        target_container = container or self.attachments_container
        return self.engine.exists(container=target_container, object_name=object_name)

    def get_url(self, object_name: str, container: str | None = None, expires_hours: int = 24) -> str:
        """Generate a URL for an object."""
        from datetime import timedelta

        target_container = container or self.attachments_container
        return self.engine.generate_url(
            container=target_container,
            object_name=object_name,
            expires=timedelta(hours=expires_hours),
        )
