import os
from typing import Any

from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv(os.getenv("ENV_FILE", ".env"))


def get_env(key: str, default: Any = None, required: bool = False) -> Any:
    val = os.getenv(key, default)
    if required and val is None:
        raise OSError(f"Environment variable {key} is required but not provided.")
    return val


APP_NAME = get_env("APP_NAME", "Chatbot")
APP_LANGUAGE = get_env("APP_LANGUAGE", "en")
SHOW_TOOL_DETAILS = get_env("SHOW_TOOL_DETAILS", "false").lower() == "true"
LOGFIRE_API_KEY = get_env("LOGFIRE_API_KEY", None)
LOGFIRE_TOKEN = get_env("LOGFIRE_TOKEN", None)

# -------------------------------- #
# -------- JWT Constants --------- #
# -------------------------------- #
BACKEND_API_KEY = get_env("BACKEND_API_KEY", required=True)  # API key for protected server-to-server endpoints
JWT_SECRET_KEY = get_env("JWT_SECRET_KEY", required=True)
JWT_EXPIRATION_HOURS = int(get_env("JWT_EXPIRATION_HOURS", 24 * 30))  # 30 days default
JWT_ALGORITHM = "HS256"
ADMIN_JWT_SECRET_KEY = get_env("ADMIN_JWT_SECRET_KEY", JWT_SECRET_KEY)  # Separate secret for admins
ADMIN_JWT_EXPIRATION_HOURS = int(get_env("ADMIN_JWT_EXPIRATION_HOURS", 24))  # 24 hours default

# -------------------------------- #
# -------- DB Constants ---------- #
# -------------------------------- #
MONGODB_URI = get_env("MONGODB_URI", required=True)
MONGODB_DB_NAME = get_env("MONGODB_DB_NAME", required=True)
MONGODB_USERNAME = get_env("MONGODB_USERNAME", None)
MONGODB_PASSWORD = get_env("MONGODB_PASSWORD", None)

# -------------------------------- #
# -------- MinIO Constants ------- #
# -------------------------------- #
MINIO_ENDPOINT = get_env("MINIO_ENDPOINT", required=True)
MINIO_ACCESS_KEY = get_env("MINIO_ACCESS_KEY", required=True)
MINIO_SECRET_KEY = get_env("MINIO_SECRET_KEY", required=True)
ATTACHMENTS_BUCKET = "attachments"

# -------------------------------- #
# -------- User Constants -------- #
# -------------------------------- #
INITIAL_BALANCE_TOKENS = int(get_env("INITIAL_BALANCE_TOKENS", 250000))
INITIAL_BALANCE_REQUESTS = int(get_env("INITIAL_BALANCE_REQUESTS", 100))

# -------------------------------- #
# -------- DB Collections -------- #
# -------------------------------- #
THREADS_COLLECTION = "threads"
THREAD_ITEMS_COLLECTION = "thread_items"
ATTACHMENTS_COLLECTION = "attachments"
USERS_COLLECTION = "users"
FEEDBACKS_COLLECTION = "feedbacks"
ADMINS_COLLECTION = "admins"
TRANSACTIONS_COLLECTION = "transactions"

MAX_ATTACHMENT_SIZE = 10 * 1024 * 1024  # 10 MB

HTTP_PROXY = get_env("HTTP_PROXY", None)  # HTTP proxy endpoint for proxying AI agents requests to the providers
