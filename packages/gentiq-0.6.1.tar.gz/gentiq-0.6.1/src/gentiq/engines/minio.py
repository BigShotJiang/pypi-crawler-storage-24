from typing import Any

from .base import BaseStorageEngine


class MinioEngine(BaseStorageEngine):
    """
    Minio storage engine implementation.
    """

    def __init__(
        self,
        endpoint: str,
        access_key: str,
        secret_key: str,
        secure: bool = False,
        **kwargs: Any,
    ):
        try:
            from minio import Minio
        except ImportError:
            raise ImportError("Please install `minio` to use the MinIO engine!")

        self.client = Minio(
            endpoint=endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure,
        )

    def upload(self, container: str, object_name: str, data: Any, length: int) -> None:
        self.client.put_object(
            bucket_name=container,
            object_name=object_name,
            data=data,
            length=length,
        )

    def download(self, container: str, object_name: str) -> Any:
        return self.client.get_object(bucket_name=container, object_name=object_name)

    def delete(self, container: str, object_name: str) -> None:
        self.client.remove_object(bucket_name=container, object_name=object_name)

    def container_exists(self, container: str) -> bool:
        return self.client.bucket_exists(bucket_name=container)

    def create_container(self, container: str) -> None:
        self.client.make_bucket(bucket_name=container)

    def generate_url(self, container: str, object_name: str, expires: Any) -> str:
        return self.client.presigned_get_object(
            bucket_name=container,
            object_name=object_name,
            expires=expires,
        )

    def exists(self, container: str, object_name: str) -> bool:
        try:
            self.client.stat_object(bucket_name=container, object_name=object_name)
            return True
        except Exception:
            return False
