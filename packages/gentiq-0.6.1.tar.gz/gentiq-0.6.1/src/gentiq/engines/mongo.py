from typing import Any

from .base import BaseDBEngine, ReturnDocument


class MongoEngine(BaseDBEngine):
    """
    MongoDB implementation of the Gentiq database engine.
    """

    def __init__(
        self,
        uri: str,
        db_name: str,
        username: str | None = None,
        password: str | None = None,
        **kwargs: Any,
    ):
        try:
            from pymongo import MongoClient
        except ImportError:
            raise ImportError("Please install `pymongo` to use the MongoDB engine!")

        self.client = MongoClient(uri, username=username, password=password)
        self.db = self.client[db_name]

    def find_one(self, collection: str, filter: dict[str, Any]) -> dict[str, Any] | None:
        return self.db[collection].find_one(filter)

    def find_many(
        self,
        collection: str,
        filter: dict[str, Any],
        sort: list[tuple[str, int]] | None = None,
        skip: int = 0,
        limit: int = 0,
    ) -> list[dict[str, Any]]:
        cursor = self.db[collection].find(filter)
        if sort:
            cursor = cursor.sort(sort)
        if skip:
            cursor = cursor.skip(skip)
        if limit:
            cursor = cursor.limit(limit)
        return list(cursor)

    def insert_one(self, collection: str, document: dict[str, Any]) -> Any:
        return self.db[collection].insert_one(document)

    def update_one(self, collection: str, filter: dict[str, Any], update: dict[str, Any], upsert: bool = False) -> Any:
        return self.db[collection].update_one(filter, update, upsert=upsert)

    def delete_one(self, collection: str, filter: dict[str, Any]) -> bool:
        result = self.db[collection].delete_one(filter)
        return result.deleted_count > 0

    def delete_many(self, collection: str, filter: dict[str, Any]) -> int:
        result = self.db[collection].delete_many(filter)
        return result.deleted_count

    def count_documents(self, collection: str, filter: dict[str, Any]) -> int:
        return self.db[collection].count_documents(filter)

    def find_one_and_update(
        self,
        collection: str,
        filter: dict[str, Any],
        update: dict[str, Any],
        return_document: ReturnDocument = ReturnDocument.BEFORE,
    ) -> dict[str, Any] | None:
        try:
            from pymongo import ReturnDocument as MongoReturnDocument
        except ImportError:
            raise ImportError("Please install `pymongo` to use the MongoDB engine!")

        mongo_rd = MongoReturnDocument.AFTER if return_document == ReturnDocument.AFTER else MongoReturnDocument.BEFORE
        return self.db[collection].find_one_and_update(filter, update, return_document=mongo_rd)

    def create_index(self, collection: str, keys: list[tuple[str, int]], unique: bool = False) -> None:
        self.db[collection].create_index(keys, unique=unique)

    def distinct(self, collection: str, field: str, filter: dict[str, Any] | None = None) -> list[Any]:
        return self.db[collection].distinct(field, filter)

    def aggregate(self, collection: str, pipeline: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return list(self.db[collection].aggregate(pipeline))
