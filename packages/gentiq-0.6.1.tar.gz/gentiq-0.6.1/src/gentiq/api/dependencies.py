from typing import Annotated

import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import APIKeyHeader

from ..database import Database, UserDocument
from ..enums import AdminPermission
from ..env import (
    ADMIN_JWT_SECRET_KEY,
    BACKEND_API_KEY,
    JWT_ALGORITHM,
    JWT_SECRET_KEY,
)


api_key_header = APIKeyHeader(name="x-api-key", auto_error=False)


# Singletons are now initialized by GentiqApp and attached to app.state
# Database and Storage instances will be retrieved from request.app.state


def _verify_token(request: Request, secret: str, identity_key: str) -> str:
    """Helper to extract and verify a Bearer token from the Authorization header."""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header missing")

    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(status_code=401, detail="Invalid authorization header format")

    token = parts[1]
    try:
        payload = jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])
        identity = payload.get(identity_key)
        if not identity:
            raise HTTPException(status_code=401, detail="Invalid token payload")
        return identity
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def authenticate_with_bearer(request: Request) -> UserDocument:
    """Authenticate user by verifying JWT token from Authorization header."""
    user_id = _verify_token(request, JWT_SECRET_KEY, "user_id")
    database: Database = request.app.state.database
    user_info = database.get_user(user_id)
    if not user_info:
        raise HTTPException(status_code=401, detail="User not found")
    return user_info


def authenticate_admin(request: Request) -> dict:
    """Authenticate admin by verifying session token."""
    admin_id = _verify_token(request, ADMIN_JWT_SECRET_KEY, "admin_id")
    database: Database = request.app.state.database
    admin_info = database.get_admin(admin_id)
    if not admin_info:
        raise HTTPException(status_code=401, detail="Admin not found")

    permissions = admin_info.permissions
    if permissions and len(permissions) > 0 and not isinstance(permissions[0], str):
        permissions = [p.value if hasattr(p, "value") else str(p) for p in permissions]

    return {
        "admin_id": admin_info.id,
        "username": admin_info.username,
        "name": admin_info.name,
        "permissions": permissions,
    }


def verify_api_key(api_key: str = Depends(api_key_header)) -> str:
    """Verify API key for server-to-server authentication."""
    if api_key != BACKEND_API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return api_key


def authenticate(
    request: Request,
    api_key: str | None = Depends(api_key_header),
) -> dict | None:
    """Authenticate with either admin token or API key."""
    if api_key == BACKEND_API_KEY:
        return None  # API key authenticated

    # Try admin authentication
    return authenticate_admin(request)


def optional_authenticate(
    request: Request,
    api_key: str | None = Depends(api_key_header),
) -> dict | None:
    """Try to authenticate, but return None if no credentials provided."""
    try:
        return authenticate(request, api_key)
    except HTTPException:
        return None


def check_permission(admin: dict | None, permission: AdminPermission):
    """Check if admin has the required permission."""
    if admin is None:
        # This happens when authenticated via API key
        return
    if permission.value not in admin.get("permissions", []):
        raise HTTPException(
            status_code=403,
            detail=f"Permission denied: {permission.value} required",
        )


def require_permission(permission: AdminPermission):
    """Dependency factory to require a specific admin permission."""

    def _permission_dependency(admin: Annotated[dict | None, Depends(authenticate)]):
        check_permission(admin, permission)
        return admin

    return _permission_dependency
