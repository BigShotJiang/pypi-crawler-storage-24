import asyncio
import base64
import logging
import mimetypes
from datetime import UTC, datetime
from http import HTTPStatus
from json import dumps, loads
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from pydantic import ValidationError
from pydantic_ai import Agent
from pydantic_ai.ui import SSE_CONTENT_TYPE
from pydantic_ai.ui.vercel_ai import VercelAIAdapter
from pydantic_ai.ui.vercel_ai.request_types import FileUIPart
from pydantic_ai.ui.vercel_ai.response_types import DataChunk, TextDeltaChunk

from ...database import Database, UserDocument
from ...env import MAX_ATTACHMENT_SIZE
from ...storage import Storage
from ..dependencies import authenticate_with_bearer
from ..inputs import MessageFeedbackInput, ThreadUpdateInput


# --- Configuration & Setup ---

router = APIRouter()
logger = logging.getLogger(__name__)


# --- Message Parsing Helpers ---


def _extract_text_from_message(msg: Any) -> str:
    """Extracts plain text from a Vercel AI SDK message object.

    Handles various formats including dictionaries, Pydantic models, and
    messages with complex nested parts.

    Args:
        msg: The message object (dict or Pydantic model) to extract text from.

    Returns:
        The extracted plain text string.
    """
    if isinstance(msg, dict):
        msg_content = msg.get("content", "")
        if isinstance(msg_content, list):
            return " ".join(
                str(p.get("text", "")) for p in msg_content if isinstance(p, dict) and p.get("type") == "text"
            )
        return str(msg_content)

    if hasattr(msg, "parts") and isinstance(msg.parts, list):
        parts_content = []
        for part in msg.parts:
            if hasattr(part, "text"):
                parts_content.append(str(part.text))
            elif hasattr(part, "content"):
                parts_content.append(str(part.content))
            elif isinstance(part, dict):
                parts_content.append(str(part.get("text", part.get("content", ""))))
        return " ".join(parts_content)

    if hasattr(msg, "content"):
        return str(msg.content)

    return str(msg)


def _get_message_role(msg: Any) -> str:
    """Retrieves the role from a message object.

    Args:
        msg: The message object to inspect.

    Returns:
        The role string (e.g., 'user', 'assistant'). Defaults to 'user'.
    """
    if isinstance(msg, dict):
        return msg.get("role", "user")
    if hasattr(msg, "role"):
        return str(msg.role)
    return "user"


# --- Attachments & Storage Helpers ---


def _decode_data_uri(data_uri: str) -> tuple[bytes, str] | None:
    """Decodes a data URI into raw bytes and its media type.

    Args:
        data_uri: The data URI string to decode.

    Returns:
        A tuple of (bytes, media_type) or None if decoding fails.
    """
    try:
        if not data_uri.startswith("data:"):
            return None

        header, encoded = data_uri.split(",", 1)
        meta = header[len("data:") :]
        media_type = meta.split(";")[0] if ";base64" in meta else meta
        content = base64.b64decode(encoded)
        return content, media_type
    except Exception as e:
        logger.warning("Failed to decode data URI: %s", e)
        return None


def _get_attachment_key(
    user_id: str,
    thread_id: str,
    msg_id: str,
    index: int,
    media_type: str,
    filename: str | None,
) -> str:
    """Generates a unique storage key for an attachment.

    Args:
        user_id: The ID of the user owning the attachment.
        thread_id: The ID of the chat thread.
        msg_id: The ID of the message the attachment belongs to.
        index: The index of the attachment within the message.
        media_type: The media type of the attachment.
        filename: The original filename, if available.

    Returns:
        A unique string key for storage.
    """
    extension = ""
    if filename and "." in filename:
        extension = "." + filename.rsplit(".", 1)[-1]
    else:
        extension = mimetypes.guess_extension(media_type) or ""

    return f"attachments/{user_id}/{thread_id}/{msg_id}/{index}{extension}"


def _upload_file_parts(
    msg: Any,
    storage: Storage,
    database: Database,
    user_id: str,
    thread_id: str,
    msg_id: str,
) -> list[dict]:
    """Uploads file parts to storage and saves metadata to the database.

    Inspects message parts for `FileUIParts`, uploads binaries to storage,
    and returns a list of parts safe for database storage (references instead
    of raw blobs).

    Args:
        msg: The message object containing attachments.
        storage: The storage engine for binary data.
        database: The database engine for metadata.
        user_id: The ID of the user.
        thread_id: The ID of the chat thread.
        msg_id: The ID of the message.

    Returns:
        A list of processed message parts ready for database insertion.
    """
    processed_parts: list[dict] = []
    file_index = 0

    raw_parts = []
    if hasattr(msg, "parts") and isinstance(msg.parts, list):
        raw_parts = msg.parts
    elif isinstance(msg, dict) and isinstance(msg.get("parts"), list):
        raw_parts = msg["parts"]

    def _process_data_uri(url: str, media_type: str, filename: str | None) -> bool:
        nonlocal file_index
        decoded = _decode_data_uri(url)
        if not decoded:
            return False

        content, actual_media_type = decoded
        if len(content) > MAX_ATTACHMENT_SIZE:
            logger.warning("Attachment too large (%d bytes), skipping", len(content))
            return False

        object_name = _get_attachment_key(user_id, thread_id, msg_id, file_index, actual_media_type, filename)

        try:
            storage.upload(content=content, object_name=object_name)

            try:
                database.save_attachment(
                    attachment_id=object_name,
                    thread_id=thread_id,
                    user_id=user_id,
                    media_type=actual_media_type,
                    filename=filename,
                )
            except Exception as db_err:
                logger.warning("Failed to save attachment metadata: %s", db_err)

            processed_parts.append(
                {
                    "type": "file",
                    "object_name": object_name,
                    "media_type": actual_media_type,
                    "mediaType": actual_media_type,
                    "filename": filename,
                }
            )
            file_index += 1
            return True
        except Exception as e:
            logger.error("Failed to upload attachment: %s", e)
            return False

    for part in raw_parts:
        # Handle Pydantic model FileUIPart
        if isinstance(part, FileUIPart):
            if part.url.startswith("data:"):
                _process_data_uri(part.url, part.media_type, part.filename)
            else:
                processed_parts.append(
                    {
                        "type": "file",
                        "url": part.url,
                        "media_type": part.media_type,
                        "mediaType": part.media_type,
                        "filename": part.filename,
                    }
                )
                file_index += 1
        # Handle dictionary representation of file parts
        elif isinstance(part, dict) and part.get("type") == "file":
            url = part.get("url", "")
            media_type = part.get("media_type") or part.get("mediaType") or "application/octet-stream"
            filename = part.get("filename")

            if url.startswith("data:"):
                _process_data_uri(url, media_type, filename)
            else:
                processed_parts.append(
                    {
                        "type": "file",
                        "url": url,
                        "media_type": media_type,
                        "mediaType": media_type,
                        "filename": filename,
                    }
                )
                file_index += 1

    return processed_parts


# --- Chat Flow Handlers (Internal) ---


async def _generate_thread_title(
    thread_id: str,
    first_msg_text: str,
    assistant_content: str,
    title_agent: Agent,
    database: Database,
) -> str | None:
    """Generates and saves a descriptive title for the chat thread.

    Args:
        thread_id: The ID of the thread.
        first_msg_text: The text of the first user message.
        assistant_content: The text of the assistant's first response.
        title_agent: The AI agent used to generate the title.
        database: The database engine.

    Returns:
        The generated title string, or None if generation failed.
    """
    try:
        # Truncate inputs to keep the prompt small and fast
        truncated_query = first_msg_text[:500]
        truncated_response = assistant_content[:500]
        prompt = f"User question:\n{truncated_query}\n\nAssistant response:\n{truncated_response}"

        result = await title_agent.run(prompt)
        title = result.output.strip()

        if title:
            # Enforce max length safety
            if len(title) > 80:
                title = title[:77] + "..."

            database.update_thread_info(thread_id, title=title, title_finalized=True)
            logger.info("Generated title for thread %s: %s", thread_id, title)
            return title
    except Exception:
        logger.exception("Title generation failed for thread %s — keeping fallback title", thread_id)

    return None


def _handle_pre_stream_user_message(
    run_input: Any,
    thread_id: str,
    user_id: str,
    database: Database,
    storage: Storage,
) -> None:
    """Processes the user message before starting the LLM stream.

    Handles thread title initialization, retry detection (clearing forward history),
    and saving the latest user message with its attachments.

    Args:
        run_input: The parsed chat request input.
        thread_id: The ID of the thread.
        user_id: The ID of the user.
        database: The database engine.
        storage: The storage engine.
    """
    try:
        if not run_input.messages:
            database.update_thread_info(thread_id, user_id=user_id)
            return

        # Find the last user message in the history
        last_user_msg = next(
            (msg for msg in reversed(run_input.messages) if _get_message_role(msg) == "user"),
            None,
        )

        # Initialize thread title from the first user message if not already set
        thread = database.fetch_thread(thread_id)
        has_title = bool(thread.get("title")) if thread else False
        is_finalized = thread.get("title_finalized", False) if thread else False

        first_msg_text = ""
        for msg in run_input.messages:
            if _get_message_role(msg) == "user":
                first_msg_text = _extract_text_from_message(msg).strip()
                break

        if first_msg_text and not has_title and not is_finalized:
            fallback_title = (first_msg_text[:35] + "...") if len(first_msg_text) > 35 else first_msg_text
            database.update_thread_info(thread_id, title=fallback_title, user_id=user_id)
        else:
            database.update_thread_info(thread_id, user_id=user_id)

        if last_user_msg is None:
            return

        # Save the latest user message
        user_text = _extract_text_from_message(last_user_msg).strip()

        # Get message ID from request (provided by Vercel AI SDK)
        user_msg_id = None
        if isinstance(last_user_msg, dict):
            user_msg_id = last_user_msg.get("id")
        elif hasattr(last_user_msg, "id"):
            user_msg_id = last_user_msg.id

        if not user_msg_id:
            timestamp = int(datetime.now(UTC).timestamp() * 1000)
            user_msg_id = f"msg_user_{thread_id}_{timestamp}"

        # Handle retries: clear future items if message ID already exists
        existing_msg = database.fetch_thread_item(thread_id, user_msg_id)
        if existing_msg and "created_at" in existing_msg:
            deleted_count = database.clear_thread_items_after(thread_id, existing_msg["created_at"])
            logger.info(
                "Retry detected for message %s. Cleared %d forward items.",
                user_msg_id,
                deleted_count,
            )

        # Process attachments
        file_parts = _upload_file_parts(
            msg=last_user_msg,
            storage=storage,
            database=database,
            user_id=user_id,
            thread_id=thread_id,
            msg_id=user_msg_id,
        )

        text_part = {"type": "text", "text": user_text} if user_text else None
        parts = ([text_part] if text_part else []) + file_parts

        database.save_thread_item(
            thread_id,
            {
                "id": user_msg_id,
                "role": "user",
                "content": user_text,
                "parts": parts,
            },
        )
    except Exception as e:
        logger.error("Error in pre-stream processing: %s", e)


async def _handle_post_stream_assistant_message(
    run_result_holder: list[Any],
    run_input: Any,
    adapter: VercelAIAdapter[Any],
    thread_id: str,
    user_id: str,
    assistant_content: str,
    title_agent: Agent | None,
    database: Database,
    streamed_id: str | None = None,
    explicit_asst_id: str | None = None,
    assistant_parts: list[dict] | None = None,
) -> str | None:
    """Finalizes the assistant message and thread state after streaming.

    Args:
        run_result_holder: List containing the PydanticAI RunResult (if completed).
        run_input: The parsed chat request input.
        adapter: The Vercel AI adapter.
        thread_id: The ID of the thread.
        user_id: The ID of the user.
        assistant_content: The accumulated text content from the stream.
        title_agent: The agent used for title generation.
        database: The database engine.
        streamed_id: The message ID provided by the stream.
        explicit_asst_id: The pre-calculated assistant message ID.
        assistant_parts: Accumulated non-text parts from the stream.

    Returns:
        The generated thread title string, if applicable.
    """
    try:
        # 1. Save assistant message if content exists
        if run_result_holder or assistant_content:
            run_result = run_result_holder[0] if run_result_holder else None
            asst_id = explicit_asst_id or streamed_id
            all_asst_parts = []

            if run_result:
                ui_messages = adapter.dump_messages(run_result.new_messages())
                for ui_msg in ui_messages:
                    if ui_msg.role == "assistant":
                        if not asst_id:
                            asst_id = ui_msg.id
                        all_asst_parts.extend([p.model_dump(mode="json") for p in ui_msg.parts])

            # Fallback for ID and parts if streaming was partial or interrupted
            if not asst_id:
                asst_id = explicit_asst_id or streamed_id

            if asst_id:
                if not all_asst_parts and assistant_parts:
                    all_asst_parts = assistant_parts
                if not all_asst_parts and assistant_content:
                    all_asst_parts = [{"type": "text", "text": assistant_content}]

                database.save_thread_item(
                    thread_id,
                    {
                        "id": asst_id,
                        "role": "assistant",
                        "content": assistant_content,
                        "parts": all_asst_parts,
                    },
                )

            # Update token usage billing
            usage = None
            if run_result and callable(getattr(run_result, "usage", None)):
                usage = run_result.usage()

            if usage:
                await database.update_usage(user_id=user_id, thread_id=thread_id, usage=usage)

        # 2. Trigger AI title generation
        thread = database.fetch_thread(thread_id)
        is_finalized = thread.get("title_finalized", False) if thread else False
        user_msg_count = sum(1 for m in run_input.messages if _get_message_role(m) == "user")

        # Generate title early in the conversation (up to 3 user turns)
        if not is_finalized and user_msg_count <= 3 and assistant_content:
            first_msg_text = ""
            for msg in run_input.messages:
                if _get_message_role(msg) == "user":
                    first_msg_text = _extract_text_from_message(msg).strip()
                    break

            if first_msg_text and title_agent:
                return await _generate_thread_title(thread_id, first_msg_text, assistant_content, title_agent, database)

    except Exception as e:
        logger.error("Error in post-stream processing: %s", e)

    return None


# --- Endpoints: Chat Core ---


@router.post("/chat/feedback", tags=["Chat"])
async def save_feedback(
    request: Request,
    data: MessageFeedbackInput,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
) -> Response:
    """Saves user feedback (sentiment) for a specific assistant message.

    Args:
        request: The initial request object.
        data: The feedback input containing message ID and sentiment.
        user: The authenticated user document.

    Returns:
        A success JSON response or error message.
    """
    database: Database = request.app.state.database
    try:
        await database.save_feedback(
            thread_id=data.thread_id,
            item_ids=[data.message_id],
            sentiment=data.sentiment,
            user_id=user.id,
        )
        return JSONResponse({"status": "success"}, status_code=HTTPStatus.OK)
    except Exception as e:
        logger.error("Error saving feedback: %s", e)
        return JSONResponse(
            {"error": f"Failed to save feedback: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


def _preprocess_chat_request(body_dict: dict, storage: Storage) -> bytes:
    """Preprocesses the chat request body for the Vercel AI SDK.

    Handles conversion of message contents to parts and resolves
    stored attachments (object_names) into data URIs for the LLM.

    Args:
        body_dict: The raw dictionary parsed from the request JSON.
        storage: The storage engine to fetch attachments from.

    Returns:
        The preprocessed body as UTF-8 encoded bytes.
    """
    clean_messages = []

    for msg in body_dict.get("messages", []):
        # pydantic-ai's UIMessage forbids 'content' and requires 'parts'
        raw_content = msg.get("content")
        raw_parts = msg.get("parts") or []

        # Convert simple content strings to structured parts if needed
        if not raw_parts and raw_content:
            raw_parts = [{"type": "text", "text": str(raw_content)}]

        clean_parts = []
        for part in raw_parts:
            if not isinstance(part, dict):
                clean_parts.append(part)
                continue

            p_type = part.get("type")
            if p_type == "file":
                object_name = part.pop("object_name", None)
                # Normalize media_type (handle camelCase)
                m_type = part.get("media_type") or part.get("mediaType") or "application/octet-stream"
                url = part.get("url")

                # If the file is in our storage, download and encode it
                if object_name:
                    try:
                        content = storage.download(object_name)
                        encoded = base64.b64encode(content).decode("ascii")
                        url = f"data:{m_type};base64,{encoded}"
                    except Exception as dl_err:
                        logger.warning("Failed to fetch attachment %s: %s", object_name, dl_err)
                        clean_parts.append(
                            {
                                "type": "text",
                                "text": f"[Attachment {part.get('filename', 'file')} unavailable]",
                            }
                        )
                        continue

                clean_parts.append(
                    {
                        "type": "file",
                        "media_type": m_type,
                        "filename": part.get("filename"),
                        "url": url,
                    }
                )
            elif p_type == "text":
                clean_parts.append(
                    {
                        "type": "text",
                        "text": part.get("text"),
                        "state": part.get("state"),
                    }
                )
            elif p_type in ("reasoning", "thought"):  # Supporting both common names
                clean_parts.append(
                    {
                        "type": "reasoning",
                        "text": part.get("text") or part.get("reasoning"),
                        "state": part.get("state"),
                    }
                )
            else:
                # Pass through other parts (tool calls/results) as-is
                clean_parts.append(part)

        clean_messages.append(
            {
                "id": msg.get("id"),
                "role": msg.get("role"),
                "metadata": msg.get("metadata", {}),
                "parts": clean_parts,
            }
        )

    # Reconstruct the body while preserving required fields
    clean_body = {
        "messages": clean_messages,
        "trigger": body_dict.get("trigger"),
        "id": body_dict.get("id"),
        "message_id": body_dict.get("message_id") or body_dict.get("messageId"),
    }

    # Filter out None values to avoid Pydantic validation errors
    compact_body = {k: v for k, v in clean_body.items() if v is not None}
    return dumps(compact_body).encode("utf-8")


@router.post("/chat", tags=["Chat"])
async def chat(
    request: Request,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
) -> Response:
    """Core chat endpoint that streams AI responses back to the client.

    Supports the Vercel AI SDK protocol and handles:
    1. Request preprocessing and attachment resolution.
    2. User balance verification.
    3. Pre-stream user message persistence.
    4. Real-time assistant response streaming with event integration.
    5. Post-stream state finalization (title generation, usage tracking).

    Returns:
        A StreamingResponse with SSE event stream.
    """
    database: Database = request.app.state.database
    storage: Storage = request.app.state.storage
    accept_header = request.headers.get("accept", SSE_CONTENT_TYPE)

    try:
        # 1. Preprocess Request Body
        raw_body = await request.body()
        try:
            body_dict = loads(raw_body)
            processed_body = _preprocess_chat_request(body_dict, storage)
        except Exception as preprocess_err:
            logger.warning("Failed to preprocess chat body: %s", preprocess_err)
            processed_body = raw_body

        run_input = VercelAIAdapter.build_run_input(processed_body)
    except ValidationError as e:
        return Response(
            content=dumps(e.json()),
            media_type="application/json",
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
        )

    # 2. Setup Dependencies & Verify State
    agent = request.app.state.agent
    title_agent = request.app.state.title_agent
    agent_deps = request.app.state.create_agent_deps(user)

    if not database.check_user_balance(user.id):
        return JSONResponse(
            {"error": "Insufficient balance. Please recharge your account to continue."},
            status_code=HTTPStatus.PAYMENT_REQUIRED,
        )

    adapter = VercelAIAdapter(agent=agent, run_input=run_input, accept=accept_header)
    thread_id = request.headers.get("X-Thread-Id")

    # 3. Handle User Message Persistence (Out-of-band)
    if thread_id:
        _handle_pre_stream_user_message(
            run_input=run_input,
            thread_id=thread_id,
            user_id=user.id,
            database=database,
            storage=storage,
        )

    # 4. Define Response Stream Generator
    run_result_holder: list[Any] = []

    async def _on_complete(result: Any):
        run_result_holder.append(result)

    async def response_generator():
        asst_text: str = ""
        asst_parts: list[dict] = []
        streamed_msg_id: str | None = None
        is_processed = False

        # Generate a stable ID for the assistant message early
        explicit_msg_id = f"msg_asst_{thread_id}_{int(datetime.now(UTC).timestamp() * 1000)}" if thread_id else None

        if explicit_msg_id:
            yield DataChunk(data=[{"message_id": explicit_msg_id}], type="data-message-id")

        async def _safe_next(iterator):
            try:
                return await anext(iterator)
            except (StopAsyncIteration, GeneratorExit):
                return None

        # Concurrent polling from LLM stream and internal event queue
        try:
            llm_iter = aiter(adapter.run_stream(deps=agent_deps, on_complete=_on_complete))
            event_iter = aiter(agent_deps.stream_events())

            llm_task = asyncio.create_task(_safe_next(llm_iter))
            event_task = asyncio.create_task(_safe_next(event_iter))
            pending_tasks = {llm_task, event_task}

            while pending_tasks:
                done, pending_tasks = await asyncio.wait(pending_tasks, return_when=asyncio.FIRST_COMPLETED)

                for task in done:
                    if task == llm_task:
                        llm_event = task.result()
                        if llm_event is None:
                            # LLM stream finished, signal event queue to wrap up
                            if agent_deps._event_queue:
                                await agent_deps._event_queue.put(None)
                        else:
                            # Update assistant state
                            if hasattr(llm_event, "id") and streamed_msg_id is None:
                                streamed_msg_id = llm_event.id

                            if isinstance(llm_event, TextDeltaChunk):
                                asst_text += llm_event.delta
                                if not asst_parts or asst_parts[-1]["type"] != "text":
                                    asst_parts.append({"type": "text", "text": llm_event.delta})
                                else:
                                    asst_parts[-1]["text"] += llm_event.delta
                            elif hasattr(llm_event, "model_dump"):
                                data = llm_event.model_dump(mode="json")
                                if data.get("type") in (
                                    "reasoning",
                                    "tool-call",
                                    "tool-invocation",
                                    "tool-result",
                                ):
                                    asst_parts.append(data)

                            yield llm_event
                            # Restart LLM polling
                            llm_task = asyncio.create_task(_safe_next(llm_iter))
                            pending_tasks.add(llm_task)

                    elif task == event_task:
                        internal_msg = task.result()
                        if internal_msg is not None:
                            yield DataChunk(
                                data=[internal_msg.model_dump(mode="json")],
                                type="data-progress-update",
                            )
                            # Restart event polling
                            event_task = asyncio.create_task(_safe_next(event_iter))
                            pending_tasks.add(event_task)

        except (GeneratorExit, asyncio.CancelledError):
            raise
        finally:
            for task in pending_tasks:
                if not task.done():
                    task.cancel()

            # 5. Post-stream Data Persistence (Shielded from cancellation)
            if thread_id and not is_processed:
                is_processed = True
                try:
                    new_title = await asyncio.shield(
                        _handle_post_stream_assistant_message(
                            run_result_holder=run_result_holder,
                            run_input=run_input,
                            adapter=adapter,
                            thread_id=thread_id,
                            user_id=user.id,
                            assistant_content=asst_text,
                            title_agent=title_agent,
                            database=database,
                            streamed_id=streamed_msg_id,
                            explicit_asst_id=explicit_msg_id,
                            assistant_parts=asst_parts if asst_parts else None,
                        )
                    )

                    if new_title:
                        yield DataChunk(data=[{"title": new_title}], type="data-title")

                    yield DataChunk(data=[{"finished": True}], type="data-chat-finished")
                except (asyncio.CancelledError, GeneratorExit):
                    pass
                except Exception as e:
                    logger.error("Failed post-stream persistence: %s", e)

    sse_stream = adapter.encode_stream(response_generator())
    return StreamingResponse(sse_stream, media_type=accept_header)


# --- Endpoints: Threads & Attachments ---


@router.get("/chat/threads", tags=["Chat"])
async def list_threads(
    request: Request,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
    skip: int = 0,
    limit: int = 50,
) -> Response:
    """Lists recent chat threads for the authenticated user."""
    database: Database = request.app.state.database
    try:
        threads = database.list_user_threads(user_id=user.id, skip=skip, limit=limit)
        total_count = database.count_user_threads(user_id=user.id)
        return JSONResponse(
            {
                "threads": threads,
                "skip": skip,
                "limit": limit,
                "count": len(threads),
                "total_count": total_count,
            },
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error("Failed to list threads: %s", e)
        return JSONResponse(
            {"error": f"Failed to fetch threads: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.get("/chat/threads/{thread_id}", tags=["Chat"])
async def get_thread_messages(
    request: Request,
    thread_id: str,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
) -> Response:
    """Retrieves all message history for a specific chat thread."""
    database: Database = request.app.state.database
    try:
        items = database.get_thread_items(user_id=user.id, thread_id=thread_id)
        if items is None:
            return JSONResponse({"items": []}, status_code=HTTPStatus.OK)
        return JSONResponse({"items": items}, status_code=HTTPStatus.OK)
    except Exception as e:
        logger.error("Failed to fetch thread messages: %s", e)
        return JSONResponse(
            {"error": f"Failed to fetch thread messages: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.patch("/chat/threads/{thread_id}", tags=["Chat"])
async def update_thread(
    request: Request,
    thread_id: str,
    data: ThreadUpdateInput,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
) -> Response:
    """Updates thread metadata (e.g., title) for the authenticated user."""
    database: Database = request.app.state.database
    try:
        thread = database.fetch_thread(thread_id)
        if not thread or thread.get("user_id") != user.id:
            return JSONResponse(
                {"error": "Thread not found or access denied"},
                status_code=HTTPStatus.NOT_FOUND,
            )

        database.update_thread_info(thread_id, title=data.title, user_id=user.id)
        return JSONResponse(
            {"status": "success", "message": "Thread updated successfully"},
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error("Error updating thread: %s", e)
        return JSONResponse(
            {"error": f"Failed to update thread: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.delete("/chat/threads/{thread_id}", tags=["Chat"])
async def delete_thread(
    request: Request,
    thread_id: str,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
) -> Response:
    """Deletes a chat thread and its associated message history."""
    database: Database = request.app.state.database
    try:
        success = database.delete_user_thread(user_id=user.id, thread_id=thread_id)
        if not success:
            return JSONResponse(
                {"error": "Thread not found or access denied"},
                status_code=HTTPStatus.NOT_FOUND,
            )
        return JSONResponse(
            {"status": "success", "message": "Thread deleted successfully"},
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error("Failed to delete thread: %s", e)
        return JSONResponse(
            {"error": f"Failed to delete thread: {str(e)}"},
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )


@router.get("/chat/attachments/{object_name:path}", tags=["Chat"])
async def get_attachment(
    request: Request,
    object_name: str,
    user: Annotated[UserDocument, Depends(authenticate_with_bearer)],
) -> Response:
    """Proxies a secure attachment from storage to the authenticated user."""
    storage: Storage = request.app.state.storage
    try:
        content = storage.download(object_name)
        media_type, _ = mimetypes.guess_type(object_name)
        if not media_type:
            media_type = "application/octet-stream"
        return Response(content=content, media_type=media_type)
    except Exception as e:
        logger.error("Failed to serve attachment %s: %s", object_name, e)
        return JSONResponse(
            {"error": "Attachment not found"},
            status_code=HTTPStatus.NOT_FOUND,
        )
