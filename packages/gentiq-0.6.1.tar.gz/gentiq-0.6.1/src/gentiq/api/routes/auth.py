import uuid

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, Response

from ...database import Database
from ..dependencies import verify_api_key
from ..inputs import LoginInput, RegisterUserInput
from ..security import create_jwt_token, hash_password


router = APIRouter()


@router.post("/auth/user", tags=["User"])
async def authorize_user(
    request: Request,
    data: RegisterUserInput,
    _: None = Depends(verify_api_key),
):
    """
    Endpoint to authorize or register a user with phone number. It returns a JWT token for authentication.
    Protected by API key.
    """
    database: Database = request.app.state.database
    if not data.phone:
        return JSONResponse(
            {"error": "`phone` must be provided"},
            status_code=400,
        )

    existing_user = database.get_user_by_phone(data.phone)

    if existing_user:
        token = create_jwt_token(existing_user.id)
        await database.update_user_token(existing_user.id, token)

        database.update_user_info(
            existing_user.id,
            name=data.name,
            surname=data.surname,
        )

        updated_user = database.get_user(existing_user.id)

        if not updated_user:
            raise Exception(f"User `{existing_user.id}` not found!")

        return updated_user.to_dict()

    user_id = f"user_{uuid.uuid4().hex}"
    token = create_jwt_token(user_id)

    try:
        user = database.create_user(
            user_id=user_id,
            phone=data.phone,
            name=data.name,
            surname=data.surname,
            token=token,
        )

        return JSONResponse(
            {
                "user_id": user.id,
                "phone": user.phone,
                "name": user.name,
                "surname": user.surname,
                "token": token,
                "created_at": user.created_at.isoformat(),
            },
            status_code=201,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to create user: {str(e)}"},
            status_code=500,
        )


@router.post("/public/auth/register", tags=["User"])
async def public_register(
    request: Request,
    data: RegisterUserInput,
) -> Response:
    """Public endpoint for user registration. Creates a new user with password authentication."""
    database: Database = request.app.state.database
    if not data.phone:
        return JSONResponse(
            {"error": "Phone number is required"},
            status_code=400,
        )

    if not data.password:
        return JSONResponse(
            {"error": "Password is required"},
            status_code=400,
        )

    if not data.name or not data.surname:
        return JSONResponse(
            {"error": "Name and surname are required"},
            status_code=400,
        )

    existing_user = database.get_user_by_phone(data.phone)
    if existing_user:
        return JSONResponse(
            {"error": "This phone number is already registered"},
            status_code=400,
        )

    user_id = f"user_{uuid.uuid4().hex}"
    token = create_jwt_token(user_id)

    password_hash = hash_password(data.password)

    try:
        user = database.create_user(
            user_id=user_id,
            phone=data.phone,
            password_hash=password_hash,
            name=data.name,
            surname=data.surname,
            token=token,
        )

        return JSONResponse(
            {
                "user_id": user.id,
                "phone": user.phone,
                "name": user.name,
                "surname": user.surname,
                "token": token,
            },
            status_code=201,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to create user: {str(e)}"},
            status_code=500,
        )


@router.post("/public/auth/login", tags=["User"])
async def public_login(
    request: Request,
    data: LoginInput,
) -> Response:
    """Public endpoint for user login. Authenticates user with phone and password."""
    database: Database = request.app.state.database
    if not data.phone or not data.password:
        return JSONResponse(
            {"error": "Phone number and password are required"},
            status_code=400,
        )

    user = database.get_user_by_phone(data.phone)
    if not user:
        return JSONResponse(
            {"error": "Invalid phone number or password"},
            status_code=401,
        )

    if hash_password(data.password) != user.password_hash:
        return JSONResponse(
            {"error": "Invalid phone number or password"},
            status_code=401,
        )

    token = create_jwt_token(user.id)
    await database.update_user_token(user.id, token)

    return JSONResponse(
        {
            "user_id": user.id,
            "phone": user.phone,
            "name": user.name,
            "surname": user.surname,
            "token": token,
        },
        status_code=200,
    )
