# src/rots/commands/service/app.py

"""Service management commands for systemd template services.

Manages systemd template services like valkey-server@ and redis-server@
on Debian 13 systems. Uses package-provided templates rather than custom
unit files.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Annotated

import cyclopts
from ots_shared.ssh.executor import CommandError

from ..common import DryRun, Follow, JsonOutput, Lines, Yes
from ._helpers import (
    _file_exists,
    _unlink,
    add_secrets_include,
    check_default_service_conflict,
    copy_default_config,
    create_secrets_file,
    ensure_data_dir,
    is_service_active,
    is_service_enabled,
    systemctl,
    update_config_value,
)
from .packages import get_package, list_packages

# systemctl() always returns Result and raises CommandError on failure
# (it wraps all calls through an Executor, even locally).
_SystemctlError = CommandError


def _error_stderr(e: CommandError) -> str:
    """Extract stderr from a CommandError."""
    return e.result.stderr


if TYPE_CHECKING:
    from ots_shared.ssh.executor import Executor

logger = logging.getLogger(__name__)

app = cyclopts.App(
    name=["service", "services"],
    help="Manage systemd template services (valkey, redis)",
)

# Type aliases for cyclopts annotations
Package = Annotated[str, cyclopts.Parameter(help="Package name (valkey, redis)")]
Instance = Annotated[str, cyclopts.Parameter(help="Instance identifier (usually port)")]
OptInstance = Annotated[str | None, cyclopts.Parameter(help="Instance identifier (optional)")]


def _get_executor() -> Executor | None:
    """Resolve executor from context. Returns None for local."""
    from rots import context
    from rots.config import Config

    cfg = Config()
    host = context.host_var.get(None)
    if host is None:
        return None
    return cfg.get_executor(host=host)


def _list_units_for_template(
    template: str,
    *,
    executor: Executor | None = None,
) -> str:
    """Run systemctl list-units for a template pattern and return stdout."""
    pattern = f"{template}*"
    result = systemctl(
        "list-units",
        "--type=service",
        "--all",
        pattern,
        "--no-pager",
        "--plain",
        check=False,
        executor=executor,
    )
    return result.stdout


@app.default
def list_all(json_output: JsonOutput = False):
    """List all service instances across all packages.

    Auto-discovers running and configured instances for all supported packages.

    Examples:
        ots service list
        ots service list --json
    """
    ex = _get_executor()
    all_instances = []

    for pkg_name in list_packages():
        pkg = get_package(pkg_name)
        output = _list_units_for_template(pkg.template, executor=ex)

        if output.strip():
            for line in output.splitlines():
                if pkg.template in line:
                    parts = line.split()
                    if parts:
                        unit_name = parts[0]
                        if "@" in unit_name and ".service" in unit_name:
                            instance = unit_name.split("@")[1].replace(".service", "")
                            active = is_service_active(unit_name, executor=ex)
                            enabled = is_service_enabled(unit_name, executor=ex)
                            config_exists = _file_exists(pkg.config_file(instance), ex)
                            all_instances.append(
                                {
                                    "package": pkg_name,
                                    "instance": instance,
                                    "unit": unit_name,
                                    "active": active,
                                    "enabled": enabled,
                                    "config_exists": config_exists,
                                }
                            )

    if json_output:
        import json

        print(json.dumps(all_instances, indent=2))
        return

    if not all_instances:
        print("No service instances found.")
        print()
        print("Available packages:")
        for name in list_packages():
            pkg = get_package(name)
            print(f"  {name:10} - {pkg.template}.service")
        print()
        print("Initialize with: ots service init <package> <instance>")
        return

    print("Service instances:")
    print("-" * 70)
    print(f"{'PACKAGE':<10} {'INSTANCE':<10} {'STATUS':<10} {'ENABLED':<10} {'CONFIG':<10}")
    print("-" * 70)

    for inst in all_instances:
        status = "active" if inst["active"] else "inactive"
        enabled = "enabled" if inst["enabled"] else "disabled"
        config = "ok" if inst["config_exists"] else "missing"
        print(
            f"{inst['package']:<10} {inst['instance']:<10} {status:<10} {enabled:<10} {config:<10}"
        )


@app.command
def init(
    package: Package,
    instance: Instance,
    *,
    port: Annotated[
        int | None,
        cyclopts.Parameter(
            name=["--port", "-p"],
            help="Port number",
        ),
    ] = None,
    bind: Annotated[
        str,
        cyclopts.Parameter(
            name=["--bind", "-b"],
            help="Bind address",
        ),
    ] = "127.0.0.1",
    no_secrets: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--no-secrets"],
            help="Skip secrets file creation",
        ),
    ] = False,
    start: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--start", "-s"],
            help="Start service after init (default: off — configure first, then start explicitly)",
        ),
    ] = False,
    enable: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--enable", "-e"],
            help="Enable service at boot (default: off — use 'ots service enable' after verifying)",
        ),
    ] = False,
    force: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--force", "-f"],
            help="Overwrite existing config and recreate instance (not idempotent by default)",
        ),
    ] = False,
    dry_run: DryRun = False,
):
    """Initialize a new service instance.

    Creates config files, sets up directories, optionally starts service.
    Config is copy-on-write from package default to /etc/<pkg>/instances/.

    Idempotent by default: if the config already exists, prints a notice and
    skips all modifications. Use --force to overwrite the existing config.

    Examples:
        ots service init valkey 6379                          # Configure only
        ots service init valkey 6379 --start --enable         # Configure, start, and enable
        ots service init redis 6380 --port 6380 --bind 0.0.0.0
        ots service init valkey 6379 --dry-run
        ots service init valkey 6379 --force                  # Overwrite existing config
    """
    ex = _get_executor()
    pkg = get_package(package)
    if port is not None:
        port_num = port
    elif instance.isnumeric():
        port_num = int(instance)
    else:
        raise SystemExit(
            f"--port is required when instance name '{instance}' is not a port number.\n"
            f"Example: ots service init {package} {instance} --port 6379"
        )

    logger.info(f"Initializing {pkg.name} instance '{instance}'")
    logger.info(f"  Template: {pkg.template_unit}")
    logger.info(f"  Port: {port_num}")
    logger.info(f"  Bind: {bind}")

    if dry_run:
        config_exists = _file_exists(pkg.config_file(instance), ex)
        if config_exists and not force:
            logger.info(f"[dry-run] Config already exists: {pkg.config_file(instance)}")
            logger.info("[dry-run] Would skip (use --force to overwrite)")
        else:
            verb = "overwrite" if config_exists else "create"
            logger.info(f"[dry-run] Would {verb}:")
            logger.info(f"  Config: {pkg.config_file(instance)}")
            logger.info(f"  Data:   {pkg.data_dir / instance}")
            if not no_secrets and pkg.secrets:
                logger.info(f"  Secrets: {pkg.secrets_file(instance)}")
        return

    # Check for default service conflict
    check_default_service_conflict(pkg, executor=ex)

    # Step 1: Copy default config
    logger.info(f"Creating config from {pkg.default_config}...")
    try:
        config_path = copy_default_config(pkg, instance, executor=ex)
        logger.info(f"  Created: {config_path}")
    except FileExistsError:
        if not force:
            # Idempotent: skip all modifications when config already exists
            logger.info(f"  Config already exists: {pkg.config_file(instance)}")
            logger.info("  Skipping config modifications (use --force to overwrite)")
            logger.info(f"Instance '{instance}' already configured.")
            logger.info(f"  Status: ots service status {package} {instance}")
            return
        # --force: delete and recreate from package default
        _unlink(pkg.config_file(instance), ex)
        logger.info("  Removed existing config (--force)")
        try:
            config_path = copy_default_config(pkg, instance, executor=ex)
            logger.info(f"  Recreated: {config_path}")
        except FileNotFoundError as e:
            logger.error(f"{e}")
            raise SystemExit(1)
    except FileNotFoundError as e:
        logger.error(f"{e}")
        raise SystemExit(1)

    # Step 2: Update port and bind in config
    logger.info("Updating config values...")
    update_config_value(config_path, pkg.port_config_key, str(port_num), pkg, executor=ex)
    update_config_value(config_path, pkg.bind_config_key, bind, pkg, executor=ex)

    # Step 3: Set data directory
    data_dir = ensure_data_dir(pkg, instance, executor=ex)
    logger.info(f"  Data dir: {data_dir}")
    # Update config to point to instance-specific data dir
    update_config_value(config_path, "dir", str(data_dir), pkg, executor=ex)

    # Step 4: Create secrets file (if applicable)
    if not no_secrets and pkg.secrets:
        logger.info("Creating secrets file...")
        secrets_path = create_secrets_file(pkg, instance, executor=ex)
        if secrets_path:
            logger.info(f"  Created: {secrets_path}")
            add_secrets_include(config_path, secrets_path, pkg, executor=ex)
            logger.info("  Added include directive to config")
    else:
        logger.info("Skipping secrets file (--no-secrets or package has no secrets config)")

    # Step 5: Enable service
    unit = pkg.instance_unit(instance)
    if enable:
        logger.info(f"Enabling {unit}...")
        try:
            systemctl("enable", unit, executor=ex)
            logger.info("  Enabled")
        except _SystemctlError as e:
            logger.warning(f"Could not enable: {_error_stderr(e)}")

    # Step 6: Start service
    if start:
        logger.info(f"Starting {unit}...")
        try:
            systemctl("start", unit, executor=ex)
            logger.info("  Started")
        except _SystemctlError as e:
            logger.error(f"Could not start: {_error_stderr(e)}")
            raise SystemExit(1)

    logger.info(f"Instance '{instance}' initialized successfully")
    logger.info(f"  Config: {config_path}")
    logger.info(f"  Data:   {data_dir}")
    logger.info(f"  Status: ots service status {package} {instance}")


@app.command
def enable(package: Package, instance: Instance):
    """Enable a service instance to start at boot.

    Examples:
        ots service enable valkey 6379
    """
    ex = _get_executor()
    pkg = get_package(package)
    unit = pkg.instance_unit(instance)

    logger.info(f"Enabling {unit}...")
    try:
        systemctl("enable", unit, executor=ex)
        logger.info("Enabled")
    except _SystemctlError as e:
        logger.error(f"{_error_stderr(e)}")
        raise SystemExit(1)


@app.command
def disable(
    package: Package,
    instance: Instance,
    yes: Yes = False,
):
    """Disable a service instance and stop it.

    Examples:
        ots service disable valkey 6379
        ots service disable valkey 6379 -y
    """
    ex = _get_executor()
    pkg = get_package(package)
    unit = pkg.instance_unit(instance)

    if not yes:
        print(f"This will disable {unit}")
        response = input("Continue? [y/N] ")
        if response.lower() not in ("y", "yes"):
            logger.info("Aborted")
            return

    logger.info(f"Stopping {unit}...")
    systemctl("stop", unit, check=False, executor=ex)

    logger.info(f"Disabling {unit}...")
    try:
        systemctl("disable", unit, executor=ex)
        logger.info("Disabled")
    except _SystemctlError as e:
        logger.error(f"{_error_stderr(e)}")
        raise SystemExit(1)


@app.command
def status(package: Package, instance: OptInstance = None):
    """Show status of service instance(s).

    Examples:
        ots service status valkey 6379
        ots service status valkey  # Shows all valkey instances
    """
    ex = _get_executor()
    pkg = get_package(package)

    if instance:
        unit = pkg.instance_unit(instance)
        result = systemctl("status", unit, check=False, executor=ex)
        print(result.stdout)
        if result.stderr:
            print(result.stderr)
    else:
        # Show all instances of this template
        result = systemctl(
            "list-units",
            "--type=service",
            f"{pkg.template}*",
            "--no-pager",
            check=False,
            executor=ex,
        )
        print(result.stdout)


@app.command
def start(package: Package, instance: Instance):
    """Start a service instance.

    Examples:
        ots service start valkey 6379
    """
    ex = _get_executor()
    pkg = get_package(package)
    unit = pkg.instance_unit(instance)

    logger.info(f"Starting {unit}...")
    try:
        systemctl("start", unit, executor=ex)
        logger.info("Started")
    except _SystemctlError as e:
        logger.error(f"{_error_stderr(e)}")
        raise SystemExit(1)


@app.command
def stop(package: Package, instance: Instance):
    """Stop a service instance.

    Examples:
        ots service stop valkey 6379
    """
    ex = _get_executor()
    pkg = get_package(package)
    unit = pkg.instance_unit(instance)

    logger.info(f"Stopping {unit}...")
    try:
        systemctl("stop", unit, executor=ex)
        logger.info("Stopped")
    except _SystemctlError as e:
        logger.error(f"{_error_stderr(e)}")
        raise SystemExit(1)


@app.command
def restart(package: Package, instance: Instance):
    """Restart a service instance.

    Examples:
        ots service restart valkey 6379
    """
    ex = _get_executor()
    pkg = get_package(package)
    unit = pkg.instance_unit(instance)

    logger.info(f"Restarting {unit}...")
    try:
        systemctl("restart", unit, executor=ex)
        logger.info("Restarted")
    except _SystemctlError as e:
        logger.error(f"{_error_stderr(e)}")
        raise SystemExit(1)


@app.command
def logs(
    package: Package,
    instance: Instance,
    *,
    follow: Follow = False,
    lines: Lines = 50,
):
    """Show logs for a service instance.

    Examples:
        ots service logs valkey 6379
        ots service logs valkey 6379 -f
        ots service logs valkey 6379 -n 100
    """
    from ots_shared.ssh import is_remote

    ex = _get_executor()
    pkg = get_package(package)
    unit = pkg.instance_unit(instance)

    cmd = ["journalctl", "-u", unit, "-n", str(lines), "--no-pager"]
    if follow:
        cmd.append("-f")

    if is_remote(ex):
        # Stream logs from remote host
        ex.run_stream(cmd)  # type: ignore[union-attr]
    else:
        import subprocess

        subprocess.run(cmd)


@app.command(name="list")
def list_instances(
    package: Package,
    json_output: JsonOutput = False,
):
    """List all instances of a service package.

    Auto-discovers running and enabled instances via systemctl.

    Examples:
        ots service list valkey
        ots service list valkey --json
    """
    ex = _get_executor()
    pkg = get_package(package)
    instances = []

    output = _list_units_for_template(pkg.template, executor=ex)

    if output.strip():
        # Parse output to extract instance names
        for line in output.splitlines():
            if pkg.template in line:
                parts = line.split()
                if parts:
                    unit_name = parts[0]
                    # Extract instance from unit name
                    # e.g., valkey-server@6379.service -> 6379
                    if "@" in unit_name and ".service" in unit_name:
                        instance = unit_name.split("@")[1].replace(".service", "")
                        active = is_service_active(unit_name, executor=ex)
                        enabled = is_service_enabled(unit_name, executor=ex)
                        config_exists = _file_exists(pkg.config_file(instance), ex)
                        instances.append(
                            {
                                "instance": instance,
                                "unit": unit_name,
                                "active": active,
                                "enabled": enabled,
                                "config_exists": config_exists,
                            }
                        )

    if json_output:
        import json

        print(json.dumps(instances, indent=2))
        return

    print(f"Instances of {pkg.name} ({pkg.template}):")
    print("-" * 50)

    if instances:
        for inst in instances:
            active = "active" if inst["active"] else "inactive"
            enabled = "enabled" if inst["enabled"] else "disabled"
            config_status = "config ok" if inst["config_exists"] else "no config"
            print(f"  {inst['instance']:10} {active:10} {enabled:10} {config_status}")

    # Also check for config files (local only — remote would need ls)
    from ots_shared.ssh import is_remote

    if not is_remote(ex):
        config_dir = pkg.instances_dir if pkg.use_instances_subdir else pkg.config_dir
        if config_dir.exists():
            print()
            print("Config files in config directory:")
            for conf in config_dir.glob("*.conf"):
                if pkg.use_instances_subdir:
                    instance = conf.stem
                else:
                    instance = conf.stem.replace(f"{pkg.name}-", "")

                unit = pkg.instance_unit(instance)
                active = "active" if is_service_active(unit, executor=ex) else "inactive"
                print(f"  {conf.name:30} -> {active}")
    else:
        # Remote: list config files via executor
        config_dir = pkg.instances_dir if pkg.use_instances_subdir else pkg.config_dir
        result = ex.run(["ls", str(config_dir)], timeout=10)  # type: ignore[union-attr]
        if result.ok and result.stdout.strip():
            print()
            print("Config files in config directory:")
            for filename in result.stdout.strip().splitlines():
                if filename.endswith(".conf"):
                    if pkg.use_instances_subdir:
                        instance = filename.replace(".conf", "")
                    else:
                        instance = filename.replace(".conf", "").replace(f"{pkg.name}-", "")

                    unit = pkg.instance_unit(instance)
                    active = "active" if is_service_active(unit, executor=ex) else "inactive"
                    print(f"  {filename:30} -> {active}")
