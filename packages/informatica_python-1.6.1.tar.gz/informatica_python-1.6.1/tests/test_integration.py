import os
import sys
import csv
import tempfile
import shutil
import pytest
from informatica_python.converter import InformaticaConverter
from informatica_python.utils.expression_converter import (
    convert_expression_vectorized, convert_filter_vectorized,
)
from informatica_python.utils.lib_adapters import (
    lib_merge, lib_sort, lib_groupby_agg, lib_groupby_first,
    lib_concat, lib_empty_df, lib_copy, lib_rank,
)


MINIMAL_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FOLDER" OWNER="admin">
  <SOURCE NAME="SRC_DATA" DATABASETYPE="Flat File" DBDNAME="SRC_DATA">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES" PADBYTES="NO" ROWDELIMITER="\\n"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="NAME" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <SOURCEFIELD NAME="AMOUNT" DATATYPE="decimal" PRECISION="10" SCALE="2" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
    <SOURCEFIELD NAME="CATEGORY" DATATYPE="string" PRECISION="50" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="4"/>
  </SOURCE>
  <TARGET NAME="TGT_DATA" DATABASETYPE="Flat File">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="NAME_UPPER" DATATYPE="string" PRECISION="100" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <TARGETFIELD NAME="AMOUNT" DATATYPE="decimal" PRECISION="10" SCALE="2" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </TARGET>
  <MAPPING NAME="m_test_expr" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_DATA" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="NAME" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="100" SCALE="0"/>
      <TRANSFORMFIELD NAME="AMOUNT" DATATYPE="decimal" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="2"/>
      <TRANSFORMFIELD NAME="CATEGORY" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="50" SCALE="0"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="EXP_TRANSFORM" TYPE="Expression" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0" EXPRESSION="ID"/>
      <TRANSFORMFIELD NAME="NAME" DATATYPE="string" PORTTYPE="INPUT" PRECISION="100" SCALE="0" EXPRESSION="NAME"/>
      <TRANSFORMFIELD NAME="NAME_UPPER" DATATYPE="string" PORTTYPE="OUTPUT" PRECISION="100" SCALE="0" EXPRESSION="UPPER(NAME)"/>
      <TRANSFORMFIELD NAME="AMOUNT" DATATYPE="decimal" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="2" EXPRESSION="AMOUNT"/>
      <TRANSFORMFIELD NAME="CATEGORY" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="50" SCALE="0" EXPRESSION="CATEGORY"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_DATA" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_DATA" TRANSFORMATION_TYPE="Source Definition"/>
    <INSTANCE NAME="SQ_SRC_DATA" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_DATA" TRANSFORMATION_TYPE="Source Qualifier"/>
    <INSTANCE NAME="EXP_TRANSFORM" TYPE="Expression" TRANSFORMATION_NAME="EXP_TRANSFORM" TRANSFORMATION_TYPE="Expression"/>
    <INSTANCE NAME="TGT_DATA" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_DATA" TRANSFORMATION_TYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="ID" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="NAME" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="NAME" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="AMOUNT" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="CATEGORY" FROMINSTANCE="SRC_DATA" FROMINSTANCETYPE="Source Definition" TOFIELD="CATEGORY" TOINSTANCE="SQ_SRC_DATA" TOINSTANCETYPE="Source Qualifier"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="ID" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="NAME" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="NAME" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="AMOUNT" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="CATEGORY" FROMINSTANCE="SQ_SRC_DATA" FROMINSTANCETYPE="Source Qualifier" TOFIELD="CATEGORY" TOINSTANCE="EXP_TRANSFORM" TOINSTANCETYPE="Expression"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="EXP_TRANSFORM" FROMINSTANCETYPE="Expression" TOFIELD="ID" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="NAME_UPPER" FROMINSTANCE="EXP_TRANSFORM" FROMINSTANCETYPE="Expression" TOFIELD="NAME_UPPER" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <CONNECTOR FROMFIELD="AMOUNT" FROMINSTANCE="EXP_TRANSFORM" FROMINSTANCETYPE="Expression" TOFIELD="AMOUNT" TOINSTANCE="TGT_DATA" TOINSTANCETYPE="Target Definition"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT_DATA"/>
  </MAPPING>
  <WORKFLOW NAME="wf_test" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''


FILTER_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE POWERMART SYSTEM "powrmart.dtd">
<POWERMART CREATION_DATE="01/01/2025" REPOSITORY_VERSION="1">
<REPOSITORY NAME="repo" VERSION="1" CODEPAGE="UTF-8" DATABASETYPE="Oracle">
<FOLDER NAME="TEST_FILTER" OWNER="admin">
  <SOURCE NAME="SRC_FILTER" DATABASETYPE="Flat File" DBDNAME="SRC_FILTER">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <SOURCEFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <SOURCEFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <SOURCEFIELD NAME="VALUE" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </SOURCE>
  <TARGET NAME="TGT_FILTER" DATABASETYPE="Flat File">
    <FLATFILE DELIMITEDBY="COMMA" HEADERROWPRESENT="YES"/>
    <TARGETFIELD NAME="ID" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NOTNULL" KEYTYPE="PRIMARY KEY" FIELDNUMBER="1"/>
    <TARGETFIELD NAME="STATUS" DATATYPE="string" PRECISION="20" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="2"/>
    <TARGETFIELD NAME="VALUE" DATATYPE="integer" PRECISION="10" SCALE="0" NULLABLE="NULL" KEYTYPE="NOT A KEY" FIELDNUMBER="3"/>
  </TARGET>
  <MAPPING NAME="m_test_filter" ISVALID="YES">
    <TRANSFORMATION NAME="SQ_SRC_FILTER" TYPE="Source Qualifier" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="STATUS" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="20" SCALE="0"/>
      <TRANSFORMFIELD NAME="VALUE" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
    </TRANSFORMATION>
    <TRANSFORMATION NAME="FIL_ACTIVE" TYPE="Filter" REUSABLE="NO">
      <TRANSFORMFIELD NAME="ID" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TRANSFORMFIELD NAME="STATUS" DATATYPE="string" PORTTYPE="INPUT/OUTPUT" PRECISION="20" SCALE="0"/>
      <TRANSFORMFIELD NAME="VALUE" DATATYPE="integer" PORTTYPE="INPUT/OUTPUT" PRECISION="10" SCALE="0"/>
      <TABLEATTRIBUTE NAME="Filter Condition" VALUE="VALUE > 50"/>
    </TRANSFORMATION>
    <INSTANCE NAME="SRC_FILTER" TYPE="Source Definition" TRANSFORMATION_NAME="SRC_FILTER"/>
    <INSTANCE NAME="SQ_SRC_FILTER" TYPE="Source Qualifier" TRANSFORMATION_NAME="SQ_SRC_FILTER"/>
    <INSTANCE NAME="FIL_ACTIVE" TYPE="Filter" TRANSFORMATION_NAME="FIL_ACTIVE"/>
    <INSTANCE NAME="TGT_FILTER" TYPE="Target Definition" TRANSFORMATION_NAME="TGT_FILTER"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SRC_FILTER" TOFIELD="ID" TOINSTANCE="SQ_SRC_FILTER"/>
    <CONNECTOR FROMFIELD="STATUS" FROMINSTANCE="SRC_FILTER" TOFIELD="STATUS" TOINSTANCE="SQ_SRC_FILTER"/>
    <CONNECTOR FROMFIELD="VALUE" FROMINSTANCE="SRC_FILTER" TOFIELD="VALUE" TOINSTANCE="SQ_SRC_FILTER"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="SQ_SRC_FILTER" TOFIELD="ID" TOINSTANCE="FIL_ACTIVE"/>
    <CONNECTOR FROMFIELD="STATUS" FROMINSTANCE="SQ_SRC_FILTER" TOFIELD="STATUS" TOINSTANCE="FIL_ACTIVE"/>
    <CONNECTOR FROMFIELD="VALUE" FROMINSTANCE="SQ_SRC_FILTER" TOFIELD="VALUE" TOINSTANCE="FIL_ACTIVE"/>
    <CONNECTOR FROMFIELD="ID" FROMINSTANCE="FIL_ACTIVE" TOFIELD="ID" TOINSTANCE="TGT_FILTER"/>
    <CONNECTOR FROMFIELD="STATUS" FROMINSTANCE="FIL_ACTIVE" TOFIELD="STATUS" TOINSTANCE="TGT_FILTER"/>
    <CONNECTOR FROMFIELD="VALUE" FROMINSTANCE="FIL_ACTIVE" TOFIELD="VALUE" TOINSTANCE="TGT_FILTER"/>
    <TARGETLOADORDER ORDER="1" TARGETINSTANCE="TGT_FILTER"/>
  </MAPPING>
  <WORKFLOW NAME="wf_filter_test" ISVALID="YES">
    <TASKINSTANCE NAME="Start" TASKNAME="Start" TASKTYPE="Start"/>
  </WORKFLOW>
</FOLDER>
</REPOSITORY>
</POWERMART>'''


class TestVectorizedExpressions:

    def test_simple_field_ref(self):
        result = convert_expression_vectorized("NAME")
        assert result == 'df["NAME"]'

    def test_numeric_literal(self):
        assert convert_expression_vectorized("42") == "42"
        assert convert_expression_vectorized("3.14") == "3.14"

    def test_string_literal(self):
        assert convert_expression_vectorized("'hello'") == "'hello'"

    def test_upper(self):
        result = convert_expression_vectorized("UPPER(NAME)")
        assert '.str.upper()' in result
        assert '"NAME"' in result

    def test_lower(self):
        result = convert_expression_vectorized("LOWER(CITY)")
        assert '.str.lower()' in result

    def test_trim(self):
        result = convert_expression_vectorized("TRIM(CODE)")
        assert '.str.strip()' in result

    def test_ltrim(self):
        result = convert_expression_vectorized("LTRIM(CODE)")
        assert '.str.lstrip()' in result

    def test_iif_to_np_where(self):
        result = convert_expression_vectorized("IIF(STATUS = 'A', 1, 0)")
        assert "np.where" in result

    def test_nvl_to_fillna(self):
        result = convert_expression_vectorized("NVL(AMOUNT, 0)")
        assert ".fillna(" in result
        assert '"AMOUNT"' in result

    def test_to_integer(self):
        result = convert_expression_vectorized("TO_INTEGER(PRICE)")
        assert "pd.to_numeric" in result

    def test_to_date(self):
        result = convert_expression_vectorized("TO_DATE(DATE_STR)")
        assert "pd.to_datetime" in result

    def test_to_date_with_format(self):
        result = convert_expression_vectorized("TO_DATE(DATE_STR, 'YYYY-MM-DD')")
        assert "pd.to_datetime" in result
        assert "%Y" in result

    def test_substr(self):
        result = convert_expression_vectorized("SUBSTR(NAME, 1, 3)")
        assert ".str[" in result

    def test_is_null(self):
        result = convert_expression_vectorized("NAME IS NULL")
        assert ".isna()" in result

    def test_is_not_null(self):
        result = convert_expression_vectorized("NAME IS NOT NULL")
        assert ".notna()" in result

    def test_custom_df_var(self):
        result = convert_expression_vectorized("UPPER(NAME)", df_var="df_expr")
        assert 'df_expr["NAME"]' in result

    def test_none_expr(self):
        assert convert_expression_vectorized(None) == "None"
        assert convert_expression_vectorized("") == "None"


class TestFilterVectorized:

    def test_simple_comparison(self):
        result = convert_filter_vectorized("VALUE > 50", "df_src")
        assert ">" in result
        assert "50" in result
        assert 'df_src["VALUE"]' in result

    def test_and_condition(self):
        result = convert_filter_vectorized("A > 1 AND B < 2", "df")
        assert "&" in result
        assert 'df["A"]' in result
        assert 'df["B"]' in result
        assert "AND" not in result
        assert "(df[" in result

    def test_or_condition(self):
        result = convert_filter_vectorized("STATUS = 'A' OR STATUS = 'B'", "df")
        assert "|" in result
        assert "(df[" in result

    def test_not_condition(self):
        result = convert_filter_vectorized("NOT A = 1", "df")
        assert "~(" in result
        assert 'df["A"]' in result
        assert "==" in result

    def test_is_null_filter(self):
        result = convert_filter_vectorized("NAME IS NULL", "df_src")
        assert ".isna()" in result
        assert 'df_src["NAME"]' in result

    def test_is_not_null_filter(self):
        result = convert_filter_vectorized("NAME IS NOT NULL", "df_src")
        assert ".notna()" in result

    def test_empty_filter(self):
        assert convert_filter_vectorized("") == "True"
        assert convert_filter_vectorized(None) == "True"

    def test_compound_iif(self):
        result = convert_expression_vectorized("IIF(A > 1 AND B < 2, 1, 0)", "df")
        assert "np.where" in result
        assert "&" in result
        assert "(" in result


class TestLibAdapters:

    def test_pandas_merge_on(self):
        result = lib_merge("pandas", "df1", "df2", on=["ID"])
        assert ".merge(" in result
        assert "on=['ID']" in result

    def test_polars_merge_on(self):
        result = lib_merge("polars", "df1", "df2", on=["ID"])
        assert ".join(" in result
        assert "on=['ID']" in result

    def test_dask_merge(self):
        result = lib_merge("dask", "df1", "df2", left_on=["A"], right_on=["B"])
        assert "dd.merge(" in result

    def test_pandas_sort(self):
        result = lib_sort("pandas", "df", ["A", "B"], [True, False])
        assert ".sort_values(" in result
        assert "reset_index" in result

    def test_polars_sort(self):
        result = lib_sort("polars", "df", ["A", "B"], [True, False])
        assert ".sort(" in result
        assert "descending=" in result

    def test_pandas_groupby(self):
        spec = {"total": ("amount", "sum"), "cnt": ("id", "count")}
        result = lib_groupby_agg("pandas", "df", ["cat"], spec)
        assert ".groupby(" in result
        assert "as_index=False" in result

    def test_polars_groupby(self):
        spec = {"total": ("amount", "sum")}
        result = lib_groupby_agg("polars", "df", ["cat"], spec)
        assert ".group_by(" in result
        assert "pl.col(" in result

    def test_pandas_concat(self):
        result = lib_concat("pandas", "df1, df2")
        assert "pd.concat(" in result

    def test_polars_concat(self):
        result = lib_concat("polars", "df1, df2")
        assert "pl.concat(" in result

    def test_dask_concat(self):
        result = lib_concat("dask", "df1, df2")
        assert "dd.concat(" in result

    def test_copy_pandas(self):
        assert lib_copy("pandas", "df") == "df.copy()"

    def test_copy_polars(self):
        assert lib_copy("polars", "df") == "df.clone()"

    def test_empty_pandas(self):
        assert lib_empty_df("pandas") == "pd.DataFrame()"

    def test_empty_polars(self):
        assert lib_empty_df("polars") == "pl.DataFrame()"


class TestParamFileGeneration:

    def test_helper_contains_param_functions(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="test")
        code = generate_helper_functions(folder, "pandas")
        assert "parse_param_file" in code
        assert "get_param" in code
        assert "param_file" in code

    def test_load_config_accepts_param_file(self):
        from informatica_python.models import FolderDef
        from informatica_python.generators.helper_gen import generate_helper_functions
        folder = FolderDef(name="test")
        code = generate_helper_functions(folder, "pandas")
        assert "def load_config(config_path='config.yml', param_file=None):" in code


class TestCodeGeneration:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_expression_mapping_generates_vectorized(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        mapping_path = os.path.join(output, "mapping_1.py")
        assert os.path.exists(mapping_path)

        with open(mapping_path) as f:
            code = f.read()
        assert 'import numpy as np' in code
        assert '.str.upper()' in code
        assert '.apply(' not in code

    def test_filter_mapping_generates_vectorized(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(FILTER_XML, output_dir=self.tmpdir)

        mapping_path = os.path.join(output, "mapping_1.py")
        with open(mapping_path) as f:
            code = f.read()
        assert 'Filter' in code

    def test_polars_codegen(self):
        converter = InformaticaConverter(data_lib="polars")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            code = f.read()
        assert "import polars as pl" in code

    def test_dask_codegen(self):
        converter = InformaticaConverter(data_lib="dask")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            code = f.read()
        assert "import dask.dataframe as dd" in code

    def test_all_required_files_generated(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        expected_files = [
            "helper_functions.py", "mapping_1.py", "workflow.py",
            "config.yml", "all_sql_queries.sql", "error_log.txt",
        ]
        for fname in expected_files:
            fpath = os.path.join(output, fname)
            assert os.path.exists(fpath), f"Missing file: {fname}"

    def test_generated_helper_is_valid_python(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            code = f.read()
        compile(code, helper_path, "exec")

    def test_generated_mapping_is_valid_python(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        mapping_path = os.path.join(output, "mapping_1.py")
        with open(mapping_path) as f:
            code = f.read()
        compile(code, mapping_path, "exec")

    def test_generated_workflow_is_valid_python(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        wf_path = os.path.join(output, "workflow.py")
        with open(wf_path) as f:
            code = f.read()
        compile(code, wf_path, "exec")


class TestParamFileRoundTrip:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_param_file_parsing_in_generated_code(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        param_path = os.path.join(self.tmpdir, "test.param")
        with open(param_path, "w") as f:
            f.write("[Global]\n")
            f.write("$$SRC_DIR=/data/source\n")
            f.write("$$TGT_DIR=/data/target\n")
            f.write("[TEST_FOLDER.WF:wf_test.ST:s_test]\n")
            f.write("$$CONN_STRING=oracle://host:1521/db\n")

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            helper_code = f.read()

        exec_globals = {"__builtins__": __builtins__}
        exec(helper_code, exec_globals)

        parse_fn = exec_globals.get("parse_param_file")
        assert parse_fn is not None
        params = parse_fn(param_path)
        assert params["SRC_DIR"] == "/data/source"
        assert params["TGT_DIR"] == "/data/target"
        assert params["CONN_STRING"] == "oracle://host:1521/db"
        assert "TEST_FOLDER.WF:wf_test.ST:s_test.CONN_STRING" in params

    def test_get_param_function(self):
        converter = InformaticaConverter(data_lib="pandas")
        output = converter.convert_string(MINIMAL_XML, output_dir=self.tmpdir)

        helper_path = os.path.join(output, "helper_functions.py")
        with open(helper_path) as f:
            helper_code = f.read()

        exec_globals = {"__builtins__": __builtins__}
        exec(helper_code, exec_globals)

        get_param_fn = exec_globals.get("get_param")
        assert get_param_fn is not None

        config = {"params": {"DB_HOST": "localhost", "DB_PORT": "5432"}}
        assert get_param_fn(config, "DB_HOST") == "localhost"
        assert get_param_fn(config, "$$DB_PORT") == "5432"
        assert get_param_fn(config, "MISSING", "default_val") == "default_val"


class TestRealXMLConversion:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _get_xml_files(self):
        assets_dir = os.path.join(os.path.dirname(__file__), "..", "attached_assets")
        if not os.path.isdir(assets_dir):
            return []
        return [
            os.path.join(assets_dir, f)
            for f in os.listdir(assets_dir)
            if f.endswith(".xml") or f.endswith(".XML")
        ]

    def test_real_xml_generates_valid_python(self):
        xml_files = self._get_xml_files()
        if not xml_files:
            pytest.skip("No real XML files available in attached_assets")

        for xml_path in xml_files:
            out_dir = os.path.join(self.tmpdir, os.path.basename(xml_path).replace(".", "_"))
            converter = InformaticaConverter(data_lib="pandas")
            try:
                output = converter.convert(xml_path, output_dir=out_dir)
            except Exception as e:
                pytest.fail(f"Conversion failed for {xml_path}: {e}")

            for fname in os.listdir(output):
                if fname.endswith(".py"):
                    fpath = os.path.join(output, fname)
                    with open(fpath) as f:
                        code = f.read()
                    try:
                        compile(code, fpath, "exec")
                    except SyntaxError as e:
                        pytest.fail(f"Syntax error in {fpath}: {e}")

    def test_real_xml_polars_generates_valid_python(self):
        xml_files = self._get_xml_files()
        if not xml_files:
            pytest.skip("No real XML files available in attached_assets")

        xml_path = xml_files[0]
        out_dir = os.path.join(self.tmpdir, "polars_test")
        converter = InformaticaConverter(data_lib="polars")
        output = converter.convert(xml_path, output_dir=out_dir)

        for fname in os.listdir(output):
            if fname.endswith(".py"):
                fpath = os.path.join(output, fname)
                with open(fpath) as f:
                    code = f.read()
                try:
                    compile(code, fpath, "exec")
                except SyntaxError as e:
                    pytest.fail(f"Syntax error in polars codegen {fpath}: {e}")


class TestCLIParamFile:

    def test_cli_has_param_file_arg(self):
        from informatica_python.cli import main
        import argparse
        import io
        import contextlib
        f = io.StringIO()
        with contextlib.redirect_stderr(f):
            try:
                sys.argv = ["informatica-python", "--help"]
                main()
            except SystemExit:
                pass
        help_text = f.getvalue()
        from informatica_python.cli import main as cli_main
        assert callable(cli_main)


class TestSQLDialectTranslation:

    def test_nvl_to_coalesce(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT NVL(COL1, 0) FROM T", source_dialect="oracle")
        assert "COALESCE" in result
        assert "NVL" not in result

    def test_sysdate_to_current_timestamp(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT SYSDATE FROM DUAL", source_dialect="oracle")
        assert "CURRENT_TIMESTAMP" in result
        assert "SYSDATE" not in result

    def test_decode_to_case(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT DECODE(STATUS, 'A', 'Active', 'I', 'Inactive', 'Unknown') FROM T", source_dialect="oracle")
        assert "CASE" in result
        assert "WHEN" in result
        assert "ELSE" in result

    def test_nvl2_to_case(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT NVL2(COL1, 'has value', 'null') FROM T", source_dialect="oracle")
        assert "CASE WHEN" in result
        assert "IS NOT NULL" in result

    def test_getdate_to_current_timestamp(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT GETDATE() FROM T", source_dialect="mssql")
        assert "CURRENT_TIMESTAMP" in result

    def test_isnull_mssql_to_coalesce(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT ISNULL(COL1, 0) FROM T", source_dialect="mssql")
        assert "COALESCE" in result

    def test_top_to_limit(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT TOP 10 * FROM T", source_dialect="mssql")
        assert "LIMIT 10" in result
        assert "TOP" not in result

    def test_rownum_to_limit(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT * FROM T WHERE ROWNUM <= 5", source_dialect="oracle")
        assert "LIMIT 5" in result

    def test_auto_dialect_detection(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT NVL(A, 0), SYSDATE FROM T")
        assert "COALESCE" in result
        assert "CURRENT_TIMESTAMP" in result

    def test_decode_with_quoted_commas(self):
        from informatica_python.utils.sql_dialect import translate_sql
        result = translate_sql("SELECT DECODE(col, 'A,B', 1, 0) FROM T", source_dialect="oracle")
        assert "CASE" in result
        assert "'A,B'" in result

    def test_dialect_detects_decode(self):
        from informatica_python.utils.expression_converter import detect_sql_dialect
        assert detect_sql_dialect("SELECT DECODE(X, 1, 'A', 'B') FROM T") == "oracle"

    def test_dialect_detects_outer_join(self):
        from informatica_python.utils.expression_converter import detect_sql_dialect
        assert detect_sql_dialect("SELECT * FROM a, b WHERE a.id = b.id(+)") == "oracle"

    def test_no_change_for_clean_sql(self):
        from informatica_python.utils.sql_dialect import translate_sql
        sql = "SELECT * FROM employees WHERE id = 1"
        result = translate_sql(sql, source_dialect="generic")
        assert result.strip() == sql.strip()

    def test_sql_gen_includes_translation(self):
        from informatica_python.generators.sql_gen import generate_sql_file
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, TableAttribute, FieldDef
        )
        tx = TransformationDef(
            name="SQ_TEST", type="Source Qualifier",
            attributes=[TableAttribute(name="Sql Query", value="SELECT NVL(A, 0), SYSDATE FROM T")],
        )
        mapping = MappingDef(name="m_test", transformations=[tx])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_sql_file(folder)
        assert "ANSI SQL Translation" in result
        assert "COALESCE" in result


class TestEnhancedErrorReporting:

    def test_unsupported_transforms_section(self):
        from informatica_python.generators.error_log_gen import generate_error_log
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, FieldDef, TableAttribute
        )
        tx = TransformationDef(
            name="JAVA_TX", type="Java",
            attributes=[TableAttribute(name="Class Name", value="com.example.Transform")],
            fields=[FieldDef(name="OUT1", datatype="string", porttype="OUTPUT")],
        )
        mapping = MappingDef(name="m_test", transformations=[tx])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_error_log(folder)
        assert "UNSUPPORTED TRANSFORMS" in result
        assert "JAVA_TX" in result
        assert "Java" in result
        assert "Class Name" in result

    def test_unmapped_ports_section(self):
        from informatica_python.generators.error_log_gen import generate_error_log
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, FieldDef, ConnectorDef
        )
        tx = TransformationDef(
            name="EXP1", type="Expression",
            fields=[
                FieldDef(name="IN1", datatype="string", porttype="INPUT"),
                FieldDef(name="OUT1", datatype="string", porttype="OUTPUT"),
                FieldDef(name="OUT2", datatype="string", porttype="OUTPUT"),
            ],
        )
        conn = ConnectorDef(
            from_instance="EXP1", from_field="OUT1",
            from_instance_type="Expression",
            to_instance="TGT", to_field="COL1",
            to_instance_type="Target Definition",
        )
        mapping = MappingDef(name="m_test", transformations=[tx], connectors=[conn])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_error_log(folder)
        assert "UNMAPPED PORTS" in result
        assert "OUT2" in result

    def test_unsupported_functions_section(self):
        from informatica_python.generators.error_log_gen import generate_error_log
        from informatica_python.models import (
            FolderDef, MappingDef, TransformationDef, FieldDef
        )
        tx = TransformationDef(
            name="EXP1", type="Expression",
            fields=[
                FieldDef(name="OUT1", datatype="string", porttype="OUTPUT",
                         expression="CUSTOM_FUNC(IN1, 'abc')"),
            ],
        )
        mapping = MappingDef(name="m_test", transformations=[tx])
        folder = FolderDef(name="F", mappings=[mapping])
        result = generate_error_log(folder)
        assert "UNSUPPORTED EXPRESSION FUNCTIONS" in result
        assert "CUSTOM_FUNC" in result


class TestNestedMapplets:

    def test_recursive_expansion(self):
        from informatica_python.generators.mapping_gen import _expand_mapplet_recursive
        from informatica_python.models import (
            MappletDef, TransformationDef, FieldDef, ConnectorDef, InstanceDef
        )
        inner_mapplet = MappletDef(
            name="INNER_MPL",
            transformations=[
                TransformationDef(name="INNER_EXP", type="Expression",
                                  fields=[FieldDef(name="F1", datatype="string", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[],
        )
        outer_mapplet = MappletDef(
            name="OUTER_MPL",
            transformations=[
                TransformationDef(name="OUTER_EXP", type="Expression",
                                  fields=[FieldDef(name="F1", datatype="string", porttype="INPUT/OUTPUT")]),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="INNER_INST", type="Mapplet",
                            transformation_name="INNER_MPL", transformation_type="Mapplet"),
            ],
        )
        mapplet_map = {"INNER_MPL": inner_mapplet, "OUTER_MPL": outer_mapplet}
        transforms, connectors = _expand_mapplet_recursive(outer_mapplet, mapplet_map, "MPL1")
        names = [t.name for t in transforms]
        assert "MPL1__OUTER_EXP" in names
        assert "MPL1__INNER_INST__INNER_EXP" in names

    def test_circular_reference_protection(self):
        from informatica_python.generators.mapping_gen import _expand_mapplet_recursive
        from informatica_python.models import (
            MappletDef, TransformationDef, FieldDef, InstanceDef
        )
        circular = MappletDef(
            name="SELF_REF",
            transformations=[
                TransformationDef(name="EXP1", type="Expression",
                                  fields=[FieldDef(name="F1", datatype="string")]),
            ],
            connectors=[],
            instances=[
                InstanceDef(name="SELF", type="Mapplet",
                            transformation_name="SELF_REF", transformation_type="Mapplet"),
            ],
        )
        mapplet_map = {"SELF_REF": circular}
        transforms, _ = _expand_mapplet_recursive(circular, mapplet_map, "M")
        assert len(transforms) == 1

    def test_depth_limit(self):
        from informatica_python.generators.mapping_gen import _expand_mapplet_recursive
        from informatica_python.models import (
            MappletDef, TransformationDef, FieldDef, InstanceDef
        )
        mapplets = {}
        for i in range(15):
            name = f"MPL_{i}"
            instances = []
            if i < 14:
                instances = [InstanceDef(name=f"NEST_{i+1}", type="Mapplet",
                                         transformation_name=f"MPL_{i+1}",
                                         transformation_type="Mapplet")]
            mapplets[name] = MappletDef(
                name=name,
                transformations=[
                    TransformationDef(name=f"TX_{i}", type="Expression",
                                      fields=[FieldDef(name="F", datatype="string")]),
                ],
                connectors=[],
                instances=instances,
            )
        transforms, _ = _expand_mapplet_recursive(mapplets["MPL_0"], mapplets, "ROOT")
        assert len(transforms) <= 11


class TestDataQualityValidation:

    def test_validate_casts_generates_warnings(self):
        from informatica_python.generators.mapping_gen import _emit_type_casting, _safe_name
        from informatica_python.models import FieldDef
        class FakeTgt:
            fields = [
                FieldDef(name="AGE", datatype="integer", nullable="NULL"),
                FieldDef(name="CREATED", datatype="date/time", nullable="NULL"),
            ]
        lines = []
        _emit_type_casting(lines, "TGT1", FakeTgt(), validate_casts=True)
        code = "\n".join(lines)
        assert "_cast_warnings" in code
        assert "_pre_null_" in code
        assert "_post_null_" in code
        assert "coerced to null" in code
        assert "logger.warning" in code

    def test_no_validation_by_default(self):
        from informatica_python.generators.mapping_gen import _emit_type_casting
        from informatica_python.models import FieldDef
        class FakeTgt:
            fields = [
                FieldDef(name="AGE", datatype="integer", nullable="NULL"),
            ]
        lines = []
        _emit_type_casting(lines, "TGT1", FakeTgt())
        code = "\n".join(lines)
        assert "_cast_warnings" not in code
        assert "_pre_null_" not in code

    def test_validate_casts_cli_flag(self):
        import io, contextlib
        from informatica_python.cli import main
        f = io.StringIO()
        with contextlib.redirect_stdout(f):
            try:
                sys.argv = ["informatica-python", "--help"]
                main()
            except SystemExit:
                pass
        help_text = f.getvalue()
        assert "--validate-casts" in help_text or "validate_casts" in help_text
