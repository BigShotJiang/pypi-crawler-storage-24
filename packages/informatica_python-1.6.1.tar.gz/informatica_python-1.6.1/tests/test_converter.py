import os
import sys
import json
import zipfile
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from informatica_python.converter import InformaticaConverter
from informatica_python.parser import InformaticaParser


TEST_XML_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "attached_assets")


def test_parse_contact_mechanism():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result, "Parsed result should not be empty"
    assert "repositories" in result
    assert len(result["repositories"]) > 0

    repo = result["repositories"][0]
    assert repo["name"] == "pc105_repo_dev2_3"

    folder = repo["folders"][0]
    assert folder["name"] == "CDM_DEV3_DELTA"
    assert len(folder["sources"]) > 0
    assert len(folder["targets"]) > 0
    assert len(folder["mappings"]) > 0

    print(f"PASS: test_parse_contact_mechanism")
    print(f"  Sources: {len(folder['sources'])}")
    print(f"  Targets: {len(folder['targets'])}")
    print(f"  Mappings: {len(folder['mappings'])}")
    for m in folder["mappings"]:
        print(f"    - {m['name']}: {len(m['transformations'])} transformations, {len(m['connectors'])} connectors")


def test_parse_party_delta():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_delta_1773695180248.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result
    folder = result["repositories"][0]["folders"][0]
    assert len(folder["sources"]) > 0
    assert len(folder["mappings"]) > 0
    print(f"PASS: test_parse_party_delta")
    print(f"  Sources: {len(folder['sources'])}")
    print(f"  Mappings: {len(folder['mappings'])}")


def test_parse_party_rel_delta():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_rel_delta_1773695180248.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result
    folder = result["repositories"][0]["folders"][0]
    assert len(folder["sources"]) > 0
    print(f"PASS: test_parse_party_rel_delta")


def test_parse_party_role_delta():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_role_delta_1773695180249.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result
    folder = result["repositories"][0]["folders"][0]
    assert len(folder["sources"]) > 0
    print(f"PASS: test_parse_party_role_delta")


def test_convert_to_files():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        converter = InformaticaConverter(data_lib="pandas")
        output_dir = os.path.join(tmpdir, "output")
        converter.convert(xml_file, output_dir=output_dir)

        expected_files = [
            "helper_functions.py",
            "mapping_1.py",
            "workflow.py",
            "config.yml",
            "all_sql_queries.sql",
            "error_log.txt",
        ]

        for f in expected_files:
            filepath = os.path.join(output_dir, f)
            assert os.path.exists(filepath), f"{f} should exist"
            size = os.path.getsize(filepath)
            assert size > 0, f"{f} should not be empty"
            print(f"  {f}: {size} bytes")

        print(f"PASS: test_convert_to_files")


def test_convert_to_zip():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        converter = InformaticaConverter(data_lib="pandas")
        zip_path = os.path.join(tmpdir, "output.zip")
        converter.convert(xml_file, output_zip=zip_path)

        assert os.path.exists(zip_path), "Zip file should exist"

        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()
            assert "helper_functions.py" in names
            assert "workflow.py" in names
            assert "config.yml" in names
            assert "all_sql_queries.sql" in names
            assert "error_log.txt" in names

            mapping_files = [n for n in names if n.startswith("mapping_")]
            assert len(mapping_files) > 0, "Should have at least one mapping file"

            for name in names:
                print(f"  {name}: {zf.getinfo(name).file_size} bytes")

        print(f"PASS: test_convert_to_zip")


def test_convert_all_xmls_to_zip():
    xml_files = [
        "wf_landing_party_contact_mechanism_delta_1773695180247.xml",
        "wf_landing_party_delta_1773695180248.xml",
        "wf_landing_party_rel_delta_1773695180248.xml",
        "wf_landing_party_role_delta_1773695180249.xml",
    ]

    for xml_name in xml_files:
        xml_file = os.path.join(TEST_XML_DIR, xml_name)
        if not os.path.exists(xml_file):
            print(f"SKIP: {xml_name} not found")
            continue

        with tempfile.TemporaryDirectory() as tmpdir:
            converter = InformaticaConverter(data_lib="pandas")
            zip_path = os.path.join(tmpdir, f"{xml_name.replace('.xml', '')}.zip")
            converter.convert(xml_file, output_zip=zip_path)

            with zipfile.ZipFile(zip_path, "r") as zf:
                names = zf.namelist()
                mapping_count = len([n for n in names if n.startswith("mapping_")])
                print(f"  {xml_name}: {len(names)} files, {mapping_count} mappings")

    print(f"PASS: test_convert_all_xmls_to_zip")


def test_data_lib_options():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    for lib in ["pandas", "dask", "polars", "vaex", "modin"]:
        with tempfile.TemporaryDirectory() as tmpdir:
            converter = InformaticaConverter(data_lib=lib)
            output_dir = os.path.join(tmpdir, "output")
            converter.convert(xml_file, output_dir=output_dir)

            helper_file = os.path.join(output_dir, "helper_functions.py")
            with open(helper_file, "r") as f:
                content = f.read()

            if lib == "pandas":
                assert "import pandas as pd" in content
            elif lib == "dask":
                assert "import dask.dataframe as dd" in content
            elif lib == "polars":
                assert "import polars as pl" in content
            elif lib == "modin":
                assert "import modin.pandas as pd" in content

            print(f"  {lib}: OK")

    print(f"PASS: test_data_lib_options")


def test_json_output():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    json_str = json.dumps(result, indent=2)
    parsed_back = json.loads(json_str)

    assert parsed_back["repositories"][0]["name"] == result["repositories"][0]["name"]
    print(f"PASS: test_json_output (JSON size: {len(json_str)} chars)")


def test_expression_converter_expanded():
    from informatica_python.utils.expression_converter import (
        convert_expression, parse_join_condition,
        parse_lookup_condition, parse_aggregate_expression,
        PANDAS_AGG_MAP,
    )

    assert convert_expression("FIELD_NAME") == 'row["FIELD_NAME"]'
    assert convert_expression("123") == "123"
    assert convert_expression("'hello'") == "'hello'"
    assert convert_expression(None) == "None"
    assert convert_expression("") == "None"

    result = convert_expression("IIF(STATUS = 'A', 'Active', 'Inactive')")
    assert "iif_expr" in result
    assert "==" in result, f"Expected == in result, got: {result}"
    assert "= =" not in result

    result = convert_expression("DECODE(TYPE, 1, 'One', 2, 'Two', 'Other')")
    assert "decode_expr" in result

    result = convert_expression("NVL(NAME, 'Unknown')")
    assert "nvl" in result

    result = convert_expression("UPPER(LTRIM(RTRIM(NAME)))")
    assert "upper" in result
    assert "ltrim" in result
    assert "rtrim" in result

    result = convert_expression("INITCAP(NAME)")
    assert "initcap" in result

    result = convert_expression("REVERSE(CODE)")
    assert "reverse_str" in result

    result = convert_expression("CHR(65)")
    assert "chr_func" in result

    result = convert_expression("ASCII('A')")
    assert "ascii_func" in result

    result = convert_expression("DATE_DIFF(END_DATE, START_DATE, 'DD')")
    assert "date_diff" in result

    result = convert_expression("LAST_DAY(HIRE_DATE)")
    assert "last_day" in result

    result = convert_expression("LOG(10, VALUE)")
    assert "log_val" in result

    result = convert_expression("LN(VALUE)")
    assert "ln_val" in result

    result = convert_expression("EXP(VALUE)")
    assert "exp_val" in result

    result = convert_expression("SIGN(AMOUNT)")
    assert "sign_val" in result

    result = convert_expression("GREATEST(A, B, C)")
    assert "greatest_val" in result

    result = convert_expression("LEAST(A, B, C)")
    assert "least_val" in result

    result = convert_expression("CHOOSE(IDX, 'A', 'B', 'C')")
    assert "choose_expr" in result

    result = convert_expression("FIELD1 || ' ' || FIELD2")
    assert " + " in result

    result = convert_expression("A AND B OR NOT C")
    assert " and " in result
    assert " or " in result
    assert " not " in result

    result = convert_expression("STATUS <> 'X'")
    assert "!=" in result

    result = convert_expression("AMOUNT >= 100")
    assert ">=" in result
    assert ">==" not in result

    result = convert_expression("AMOUNT <= 100")
    assert "<=" in result
    assert "<==" not in result

    result = convert_expression("SUM(A)/COUNT(*)")
    assert "sum_val" in result or "count_val" in result

    result = convert_expression("$$MY_VARIABLE")
    assert 'get_variable("MY_VARIABLE")' in result

    result = convert_expression(":LKP.LKP_TABLE(IN_ID)")
    assert 'lookup_func("LKP_TABLE"' in result

    result = convert_expression("SUM(AMOUNT)")
    assert "sum_val" in result

    result = convert_expression("MEDIAN(SCORE)")
    assert "median_val" in result

    result = convert_expression("STDDEV(VALUE)")
    assert "stddev_val" in result

    print("PASS: test_expression_converter_expanded (80+ functions verified)")


def test_parse_join_condition():
    from informatica_python.utils.expression_converter import parse_join_condition

    left, right = parse_join_condition("DETAIL.CUSTOMER_ID = MASTER.CUST_ID")
    assert left == ["CUSTOMER_ID"], f"Expected ['CUSTOMER_ID'], got {left}"
    assert right == ["CUST_ID"], f"Expected ['CUST_ID'], got {right}"

    left, right = parse_join_condition(
        "DETAIL.ID = MASTER.ID AND DETAIL.TYPE = MASTER.TYPE"
    )
    assert left == ["ID", "TYPE"]
    assert right == ["ID", "TYPE"]

    left, right = parse_join_condition("COL_A = COL_B")
    assert left == ["COL_A"]
    assert right == ["COL_B"]

    left, right = parse_join_condition("")
    assert left == []
    assert right == []

    print("PASS: test_parse_join_condition")


def test_parse_lookup_condition():
    from informatica_python.utils.expression_converter import parse_lookup_condition

    inp, lkp = parse_lookup_condition("IN_ID = LKP_ID")
    assert inp == ["IN_ID"]
    assert lkp == ["LKP_ID"]

    inp, lkp = parse_lookup_condition("CUST_ID = CUSTOMER_ID AND REGION = REGION_CODE")
    assert inp == ["CUST_ID", "REGION"]
    assert lkp == ["CUSTOMER_ID", "REGION_CODE"]

    inp, lkp = parse_lookup_condition("")
    assert inp == []
    assert lkp == []

    print("PASS: test_parse_lookup_condition")


def test_parse_aggregate_expression():
    from informatica_python.utils.expression_converter import parse_aggregate_expression, PANDAS_AGG_MAP

    func, col = parse_aggregate_expression("SUM(AMOUNT)")
    assert func == "sum"
    assert col == "AMOUNT"
    assert PANDAS_AGG_MAP[func] == "sum"

    func, col = parse_aggregate_expression("COUNT(*)")
    assert func == "count"
    assert col == "*"

    func, col = parse_aggregate_expression("AVG(SCORE)")
    assert func == "avg"
    assert col == "SCORE"
    assert PANDAS_AGG_MAP[func] == "mean"

    func, col = parse_aggregate_expression("MAX(DATE_COL)")
    assert func == "max"
    assert col == "DATE_COL"

    func, col = parse_aggregate_expression("MIN(PRICE)")
    assert func == "min"
    assert col == "PRICE"

    func, col = parse_aggregate_expression("MEDIAN(VALUE)")
    assert func == "median"
    assert col == "VALUE"
    assert PANDAS_AGG_MAP[func] == "median"

    func, col = parse_aggregate_expression("STDDEV(SCORE)")
    assert func == "stddev"
    assert col == "SCORE"
    assert PANDAS_AGG_MAP[func] == "std"

    func, col = parse_aggregate_expression("VARIANCE(METRIC)")
    assert func == "variance"
    assert col == "METRIC"
    assert PANDAS_AGG_MAP[func] == "var"

    func, col = parse_aggregate_expression("JUST_A_FIELD")
    assert func is None
    assert col is None

    func, col = parse_aggregate_expression("SUM(A)/COUNT(*)")
    assert func is None, f"Compound expression should not match, got func={func}"
    assert col is None

    func, col = parse_aggregate_expression("AVG(A+B)")
    assert func is None, f"Expression with operators should not match, got func={func}"

    print("PASS: test_parse_aggregate_expression")


def test_generated_aggregator_code():
    from informatica_python.models import TransformationDef, FieldDef, TableAttribute
    from informatica_python.generators.mapping_gen import _gen_aggregator_transform, _safe_name

    tx = TransformationDef(
        name="AGG_SALES",
        type="Aggregator",
        fields=[
            FieldDef(name="REGION", datatype="string", porttype="INPUT/OUTPUT"),
            FieldDef(name="TOTAL_AMOUNT", datatype="decimal", porttype="OUTPUT", expression="SUM(AMOUNT)"),
            FieldDef(name="ORDER_COUNT", datatype="integer", porttype="OUTPUT", expression="COUNT(*)"),
            FieldDef(name="AVG_PRICE", datatype="decimal", porttype="OUTPUT", expression="AVG(PRICE)"),
        ],
    )
    lines = []
    source_dfs = {"INPUT_SRC": "df_input_src"}
    _gen_aggregator_transform(lines, tx, "agg_sales", "df_input_src", source_dfs)
    code = "\n".join(lines)

    assert "groupby" in code
    assert "REGION" in code
    assert "NamedAgg" in code
    assert "'sum'" in code
    assert "'count'" in code
    assert "'mean'" in code
    assert source_dfs["AGG_SALES"] == "df_agg_sales"

    print(f"PASS: test_generated_aggregator_code")


def test_generated_joiner_code():
    from informatica_python.models import TransformationDef, FieldDef, TableAttribute
    from informatica_python.generators.mapping_gen import _gen_joiner_transform, _safe_name

    tx = TransformationDef(
        name="JNR_CUST_ORDER",
        type="Joiner",
        fields=[
            FieldDef(name="CUST_ID", datatype="string", porttype="MASTER"),
            FieldDef(name="CUST_NAME", datatype="string", porttype="MASTER"),
            FieldDef(name="ORDER_ID", datatype="string", porttype="DETAIL"),
            FieldDef(name="CUST_ID", datatype="string", porttype="DETAIL"),
        ],
        attributes=[
            TableAttribute(name="Join Type", value="Normal Join"),
            TableAttribute(name="Join Condition", value="DETAIL.CUST_ID = MASTER.CUST_ID"),
        ],
    )
    lines = []
    source_dfs = {"SRC_CUST": "df_src_cust", "SRC_ORDER": "df_src_order"}
    input_sources = {"SRC_CUST", "SRC_ORDER"}
    _gen_joiner_transform(lines, tx, "jnr_cust_order", "df_src_cust", input_sources, source_dfs, connector_graph=None)
    code = "\n".join(lines)

    assert "merge" in code
    assert "left_on" in code
    assert "right_on" in code
    assert "CUST_ID" in code
    assert source_dfs["JNR_CUST_ORDER"] == "df_jnr_cust_order"

    print(f"PASS: test_generated_joiner_code")


def test_generated_lookup_code():
    from informatica_python.models import TransformationDef, FieldDef, TableAttribute
    from informatica_python.generators.mapping_gen import _gen_lookup_transform, _safe_name

    tx = TransformationDef(
        name="LKP_CUSTOMER",
        type="Lookup Procedure",
        fields=[
            FieldDef(name="IN_CUST_ID", datatype="string", porttype="INPUT"),
            FieldDef(name="CUST_NAME", datatype="string", porttype="OUTPUT", default_value="'Unknown'"),
            FieldDef(name="CUST_STATUS", datatype="string", porttype="OUTPUT"),
        ],
        attributes=[
            TableAttribute(name="Lookup table name", value="DIM_CUSTOMER"),
            TableAttribute(name="Lookup condition", value="IN_CUST_ID = CUSTOMER_ID"),
            TableAttribute(name="Lookup policy on multiple match", value="Use First Value"),
        ],
    )
    lines = []
    source_dfs = {"INPUT_SRC": "df_input_src"}
    _gen_lookup_transform(lines, tx, "lkp_customer", "df_input_src", source_dfs)
    code = "\n".join(lines)

    assert "DIM_CUSTOMER" in code
    assert "merge" in code
    assert "left_on" in code
    assert "right_on" in code
    assert "IN_CUST_ID" in code
    assert "CUSTOMER_ID" in code
    assert "drop_duplicates" in code
    assert "'left'" in code
    assert "fillna" in code
    assert source_dfs["LKP_CUSTOMER"] == "df_lkp_customer"

    print(f"PASS: test_generated_lookup_code")


def test_flatfile_metadata_read():
    from informatica_python.models import (
        MappingDef, FolderDef, SourceDef, TargetDef, FlatFileDef,
        FieldDef, TransformationDef, ConnectorDef, InstanceDef, TableAttribute,
    )
    from informatica_python.generators.mapping_gen import generate_mapping_code

    ff = FlatFileDef(
        name="test_file",
        delimiter="|",
        header_lines=1,
        text_qualifier='"',
        skip_rows=2,
        code_page="UTF-8",
    )
    src = SourceDef(
        name="PIPE_SOURCE",
        database_type="Flat File",
        flatfile=ff,
        fields=[FieldDef(name="COL_A", datatype="string"), FieldDef(name="COL_B", datatype="integer")],
    )
    tgt_ff = FlatFileDef(name="tgt_file", delimiter="~")
    tgt = TargetDef(
        name="TILDE_TARGET",
        database_type="Flat File",
        flatfile=tgt_ff,
        fields=[FieldDef(name="COL_A", datatype="string")],
    )
    mapping = MappingDef(
        name="m_flatfile_test",
        transformations=[],
        connectors=[ConnectorDef(from_instance="PIPE_SOURCE", from_field="COL_A",
                                  from_instance_type="Source Definition",
                                  to_instance="TILDE_TARGET", to_field="COL_A",
                                  to_instance_type="Target Definition")],
        instances=[
            InstanceDef(name="PIPE_SOURCE", type="Source Definition", transformation_name="PIPE_SOURCE"),
            InstanceDef(name="TILDE_TARGET", type="Target Definition", transformation_name="TILDE_TARGET"),
        ],
    )
    folder = FolderDef(name="test", sources=[src], targets=[tgt], mappings=[mapping])
    code = generate_mapping_code(mapping, folder)

    assert "ff_cfg_" in code, "Should emit flatfile config dict"
    assert "'delimiter': '|'" in code, "Pipe delimiter should appear"
    assert "'skip_rows': 2" in code, "Skip rows should appear"
    assert "'~'" in code, "Tilde delimiter should appear for target"
    print("PASS: test_flatfile_metadata_read")


def test_flatfile_fixed_width():
    from informatica_python.models import (
        MappingDef, FolderDef, SourceDef, FlatFileDef,
        FieldDef, InstanceDef, TargetDef, ConnectorDef,
    )
    from informatica_python.generators.mapping_gen import generate_mapping_code

    ff = FlatFileDef(name="fw_file", is_fixed_width="YES", header_lines=0)
    src = SourceDef(
        name="FW_SOURCE",
        database_type="Flat File",
        flatfile=ff,
        fields=[FieldDef(name="F1", datatype="string", precision=10),
                FieldDef(name="F2", datatype="string", precision=20)],
    )
    mapping = MappingDef(
        name="m_fw_test",
        transformations=[],
        connectors=[],
        instances=[InstanceDef(name="FW_SOURCE", type="Source Definition", transformation_name="FW_SOURCE")],
    )
    folder = FolderDef(name="test", sources=[src], targets=[], mappings=[mapping])
    code = generate_mapping_code(mapping, folder)

    assert "read_fwf" in code, "Fixed-width should use pd.read_fwf"
    assert "[10, 20]" in code, "Widths should be derived from field precision"
    print("PASS: test_flatfile_fixed_width")


def test_normalizer_transform():
    from informatica_python.models import (
        MappingDef, FolderDef, SourceDef, FieldDef,
        TransformationDef, ConnectorDef, InstanceDef, TableAttribute, TargetDef,
    )
    from informatica_python.generators.mapping_gen import _gen_normalizer_transform

    tx = TransformationDef(
        name="NRM_PHONES",
        type="Normalizer",
        fields=[
            FieldDef(name="CUST_ID", datatype="integer", porttype="INPUT/OUTPUT"),
            FieldDef(name="PHONE1", datatype="string", porttype="INPUT"),
            FieldDef(name="PHONE2", datatype="string", porttype="INPUT"),
            FieldDef(name="PHONE3", datatype="string", porttype="INPUT"),
            FieldDef(name="GK", datatype="integer", porttype="OUTPUT"),
        ],
    )
    lines = []
    source_dfs = {}
    _gen_normalizer_transform(lines, tx, "nrm_phones", "df_input", source_dfs)
    code = "\n".join(lines)

    assert "melt(" in code, "Normalizer should use pd.melt()"
    assert "PHONE1" in code, "Should reference PHONE columns"
    assert "CUST_ID" in code, "Should reference ID column"
    assert "GK" in code, "Should generate GK sequence"
    assert source_dfs["NRM_PHONES"] == "df_nrm_phones"
    print("PASS: test_normalizer_transform")


def test_rank_with_groupby():
    from informatica_python.models import (
        FieldDef, TransformationDef, TableAttribute,
    )
    from informatica_python.generators.mapping_gen import _gen_rank_transform

    tx = TransformationDef(
        name="RNK_SALES",
        type="Rank",
        fields=[
            FieldDef(name="REGION", datatype="string", porttype="INPUT/OUTPUT"),
            FieldDef(name="AMOUNT", datatype="decimal", porttype="INPUT", expression="AMOUNT"),
            FieldDef(name="RANKINDEX", datatype="integer", porttype="OUTPUT"),
        ],
        attributes=[
            TableAttribute(name="Top/Bottom", value="TOP"),
            TableAttribute(name="Number Of Ranks", value="5"),
        ],
    )
    lines = []
    source_dfs = {}
    _gen_rank_transform(lines, tx, "rnk_sales", "df_input", source_dfs)
    code = "\n".join(lines)

    assert "groupby" in code, "Should use groupby for group-by rank"
    assert "REGION" in code, "Should group by REGION"
    assert "AMOUNT" in code, "Should rank by AMOUNT"
    assert "RANKINDEX" in code, "Should produce RANKINDEX column"
    assert "<= 5" in code, "Should filter top 5"
    assert source_dfs["RNK_SALES"] == "df_rnk_sales"
    print("PASS: test_rank_with_groupby")


def test_decision_task_if_else():
    from informatica_python.models import (
        FolderDef, WorkflowDef, TaskInstanceDef, WorkflowLink,
        TableAttribute, MappingDef,
    )
    from informatica_python.generators.workflow_gen import generate_workflow_code

    wf = WorkflowDef(
        name="wf_test_decision",
        task_instances=[
            TaskInstanceDef(name="Start", task_name="Start", task_type="Start Task"),
            TaskInstanceDef(
                name="dec_check_status",
                task_name="dec_check_status",
                task_type="Decision",
                attributes=[TableAttribute(name="Decision Condition", value="$$LOAD_FLAG = TRUE")],
            ),
            TaskInstanceDef(name="s_load_data", task_name="s_load_data", task_type="Session"),
            TaskInstanceDef(name="s_skip_load", task_name="s_skip_load", task_type="Session"),
        ],
        links=[
            WorkflowLink(from_instance="Start", to_instance="dec_check_status"),
            WorkflowLink(from_instance="dec_check_status", to_instance="s_load_data", condition="$dec_check_status.SUCCEEDED"),
            WorkflowLink(from_instance="dec_check_status", to_instance="s_skip_load", condition="$dec_check_status.FAILED"),
        ],
    )
    folder = FolderDef(name="test", workflows=[wf], mappings=[])
    code = generate_workflow_code(folder)

    assert "decision_dec_check_status" in code, "Should create decision variable"
    assert "if decision_dec_check_status" in code, "Should generate if branch"
    assert "LOAD_FLAG" in code, "Should convert $$LOAD_FLAG"
    assert "True" in code, "Should convert TRUE to Python True"
    print("PASS: test_decision_task_if_else")


def test_inline_mapplet():
    from informatica_python.models import (
        MappingDef, FolderDef, SourceDef, TargetDef, MappletDef,
        TransformationDef, ConnectorDef, InstanceDef, FieldDef,
        TableAttribute,
    )
    from informatica_python.generators.mapping_gen import generate_mapping_code

    mplt = MappletDef(
        name="mplt_clean_name",
        transformations=[
            TransformationDef(
                name="EXP_UPPER",
                type="Expression",
                fields=[
                    FieldDef(name="FULL_NAME", datatype="string", porttype="INPUT/OUTPUT",
                             expression="UPPER(FULL_NAME)"),
                ],
            ),
        ],
        connectors=[],
    )

    mapping = MappingDef(
        name="m_with_mapplet",
        transformations=[
            TransformationDef(name="SQ_INPUT", type="Source Qualifier",
                              fields=[FieldDef(name="FULL_NAME", datatype="string", porttype="INPUT/OUTPUT")]),
        ],
        connectors=[
            ConnectorDef(from_instance="SRC", from_field="FULL_NAME",
                         from_instance_type="Source Definition",
                         to_instance="SQ_INPUT", to_field="FULL_NAME",
                         to_instance_type="Source Qualifier"),
            ConnectorDef(from_instance="SQ_INPUT", from_field="FULL_NAME",
                         from_instance_type="Source Qualifier",
                         to_instance="MPLT_INST", to_field="FULL_NAME",
                         to_instance_type="Mapplet"),
            ConnectorDef(from_instance="MPLT_INST", from_field="FULL_NAME",
                         from_instance_type="Mapplet",
                         to_instance="TGT", to_field="FULL_NAME",
                         to_instance_type="Target Definition"),
        ],
        instances=[
            InstanceDef(name="SRC", type="Source Definition", transformation_name="SRC"),
            InstanceDef(name="SQ_INPUT", type="Source Qualifier"),
            InstanceDef(name="MPLT_INST", type="Mapplet", transformation_name="mplt_clean_name",
                        transformation_type="Mapplet"),
            InstanceDef(name="TGT", type="Target Definition", transformation_name="TGT"),
        ],
    )

    src = SourceDef(name="SRC", fields=[FieldDef(name="FULL_NAME", datatype="string")])
    tgt = TargetDef(name="TGT", fields=[FieldDef(name="FULL_NAME", datatype="string")])
    folder = FolderDef(
        name="test",
        sources=[src],
        targets=[tgt],
        mappings=[mapping],
        mapplets=[mplt],
    )
    code = generate_mapping_code(mapping, folder)

    assert "MPLT_INST__EXP_UPPER" in code or "mplt_inst__exp_upper" in code, \
        "Inlined mapplet transform should appear with prefix"
    assert "UPPER" in code, "UPPER expression from mapplet should be present"
    print("PASS: test_inline_mapplet")


def test_session_connection_overrides():
    from informatica_python.models import (
        MappingDef, FolderDef, SourceDef, TargetDef,
        TransformationDef, ConnectorDef, InstanceDef, FieldDef,
        SessionDef, SessionTransformInst, ConnectionRef, TableAttribute,
    )
    from informatica_python.generators.mapping_gen import generate_mapping_code

    mapping = MappingDef(
        name="m_sess_test",
        transformations=[
            TransformationDef(name="SQ_SRC", type="Source Qualifier",
                              fields=[FieldDef(name="ID", datatype="integer", porttype="INPUT/OUTPUT")]),
        ],
        connectors=[
            ConnectorDef(from_instance="MY_SRC", from_field="ID",
                         from_instance_type="Source Definition",
                         to_instance="SQ_SRC", to_field="ID",
                         to_instance_type="Source Qualifier"),
            ConnectorDef(from_instance="SQ_SRC", from_field="ID",
                         from_instance_type="Source Qualifier",
                         to_instance="MY_TGT", to_field="ID",
                         to_instance_type="Target Definition"),
        ],
        instances=[
            InstanceDef(name="MY_SRC", type="Source Definition", transformation_name="MY_SRC"),
            InstanceDef(name="SQ_SRC", type="Source Qualifier"),
            InstanceDef(name="MY_TGT", type="Target Definition", transformation_name="MY_TGT"),
        ],
    )
    src = SourceDef(name="MY_SRC", database_type="Oracle", db_name="SRC_DB",
                    owner_name="EDW",
                    fields=[FieldDef(name="ID", datatype="integer")])
    tgt = TargetDef(name="MY_TGT", database_type="Oracle",
                    fields=[FieldDef(name="ID", datatype="integer")])

    session = SessionDef(
        name="s_m_sess_test",
        mapping_name="m_sess_test",
        transform_instances=[
            SessionTransformInst(
                instance_name="SQ_SRC",
                transformation_name="SQ_SRC",
                connections=[
                    ConnectionRef(connection_name="PROD_ORA", connection_type="Oracle"),
                ],
            ),
            SessionTransformInst(
                instance_name="MY_TGT",
                transformation_name="MY_TGT",
                attributes=[
                    TableAttribute(name="Output File Directory", value="/data/output"),
                    TableAttribute(name="Output filename", value="result.csv"),
                ],
            ),
        ],
    )

    folder = FolderDef(
        name="test",
        sources=[src],
        targets=[tgt],
        mappings=[mapping],
        sessions=[session],
    )
    code = generate_mapping_code(mapping, folder)

    assert "PROD_ORA" in code, "Session connection override should use PROD_ORA"
    assert "_sess_overrides" in code, "Session overrides dict should be emitted"
    assert "/data/output" in code, "Output file directory override should appear"
    assert "result.csv" in code, "Output filename override should appear"
    print("PASS: test_session_connection_overrides")


def test_worklet_generation():
    from informatica_python.models import (
        FolderDef, WorkflowDef, TaskInstanceDef, WorkflowLink,
        MetadataExtension,
    )
    from informatica_python.generators.workflow_gen import generate_workflow_code

    worklet = WorkflowDef(
        name="wklt_error_handler",
        description="Error handling worklet",
        metadata_extensions=[
            MetadataExtension(name="is_worklet", value="YES"),
        ],
        task_instances=[
            TaskInstanceDef(name="Start_wklt", task_type="Start Task"),
            TaskInstanceDef(name="CMD_LOG", task_type="Command",
                            attributes=[]),
        ],
        links=[
            WorkflowLink(from_instance="Start_wklt", to_instance="CMD_LOG", condition=""),
        ],
    )

    main_wf = WorkflowDef(
        name="wf_main",
        task_instances=[
            TaskInstanceDef(name="Start_main", task_type="Start Task"),
            TaskInstanceDef(name="WK_ERR", task_type="Worklet",
                            task_name="wklt_error_handler"),
        ],
        links=[
            WorkflowLink(from_instance="Start_main", to_instance="WK_ERR", condition=""),
        ],
    )

    folder = FolderDef(
        name="test",
        workflows=[worklet, main_wf],
    )
    code = generate_workflow_code(folder)

    assert "def run_worklet_wklt_error_handler(config):" in code, \
        "Worklet function should be generated"
    assert "run_worklet_wklt_error_handler(config)" in code, \
        "Main workflow should call the worklet function"
    assert "Worklet: WK_ERR" in code, \
        "Worklet task should appear in workflow"
    print("PASS: test_worklet_generation")


def test_type_casting_at_target():
    from informatica_python.models import (
        MappingDef, FolderDef, SourceDef, TargetDef,
        TransformationDef, ConnectorDef, InstanceDef, FieldDef,
    )
    from informatica_python.generators.mapping_gen import generate_mapping_code

    mapping = MappingDef(
        name="m_cast_test",
        transformations=[
            TransformationDef(name="SQ_DATA", type="Source Qualifier",
                              fields=[
                                  FieldDef(name="AMOUNT", datatype="decimal", porttype="INPUT/OUTPUT"),
                                  FieldDef(name="REC_ID", datatype="bigint", porttype="INPUT/OUTPUT"),
                                  FieldDef(name="CREATED", datatype="date/time", porttype="INPUT/OUTPUT"),
                                  FieldDef(name="IS_ACTIVE", datatype="bit", porttype="INPUT/OUTPUT"),
                              ]),
        ],
        connectors=[
            ConnectorDef(from_instance="SRC", from_field="AMOUNT",
                         from_instance_type="Source Definition",
                         to_instance="SQ_DATA", to_field="AMOUNT",
                         to_instance_type="Source Qualifier"),
            ConnectorDef(from_instance="SQ_DATA", from_field="AMOUNT",
                         from_instance_type="Source Qualifier",
                         to_instance="TGT", to_field="AMOUNT",
                         to_instance_type="Target Definition"),
            ConnectorDef(from_instance="SQ_DATA", from_field="REC_ID",
                         from_instance_type="Source Qualifier",
                         to_instance="TGT", to_field="REC_ID",
                         to_instance_type="Target Definition"),
            ConnectorDef(from_instance="SQ_DATA", from_field="CREATED",
                         from_instance_type="Source Qualifier",
                         to_instance="TGT", to_field="CREATED",
                         to_instance_type="Target Definition"),
            ConnectorDef(from_instance="SQ_DATA", from_field="IS_ACTIVE",
                         from_instance_type="Source Qualifier",
                         to_instance="TGT", to_field="IS_ACTIVE",
                         to_instance_type="Target Definition"),
        ],
        instances=[
            InstanceDef(name="SRC", type="Source Definition", transformation_name="SRC"),
            InstanceDef(name="SQ_DATA", type="Source Qualifier"),
            InstanceDef(name="TGT", type="Target Definition", transformation_name="TGT"),
        ],
    )
    src = SourceDef(name="SRC", fields=[
        FieldDef(name="AMOUNT", datatype="decimal"),
        FieldDef(name="REC_ID", datatype="bigint"),
        FieldDef(name="CREATED", datatype="date/time"),
        FieldDef(name="IS_ACTIVE", datatype="bit"),
    ])
    tgt = TargetDef(name="TGT", fields=[
        FieldDef(name="AMOUNT", datatype="decimal"),
        FieldDef(name="REC_ID", datatype="bigint", nullable="NOT NULL"),
        FieldDef(name="PARENT_ID", datatype="bigint", nullable="NULL"),
        FieldDef(name="CREATED", datatype="date/time"),
        FieldDef(name="IS_ACTIVE", datatype="bit"),
    ])
    folder = FolderDef(name="test", sources=[src], targets=[tgt], mappings=[mapping])
    code = generate_mapping_code(mapping, folder)

    assert "pd.to_numeric" in code, "Numeric casting should use pd.to_numeric"
    assert "Int64" in code, "Bigint should cast to Int64 (nullable)"
    assert "pd.to_datetime" in code, "Date/time should use pd.to_datetime"
    assert ".fillna(0).astype(int)" in code, "NOT NULL bigint should use fillna(0).astype(int)"
    assert "Type casting for target fields" in code, "Type casting comment should appear"
    print("PASS: test_type_casting_at_target")


if __name__ == "__main__":
    print("=" * 60)
    print("Running informatica-python tests")
    print("=" * 60)
    print()

    tests = [
        test_parse_contact_mechanism,
        test_parse_party_delta,
        test_parse_party_rel_delta,
        test_parse_party_role_delta,
        test_convert_to_files,
        test_convert_to_zip,
        test_convert_all_xmls_to_zip,
        test_data_lib_options,
        test_json_output,
        test_expression_converter_expanded,
        test_parse_join_condition,
        test_parse_lookup_condition,
        test_parse_aggregate_expression,
        test_generated_aggregator_code,
        test_generated_joiner_code,
        test_generated_lookup_code,
        test_flatfile_metadata_read,
        test_flatfile_fixed_width,
        test_normalizer_transform,
        test_rank_with_groupby,
        test_decision_task_if_else,
        test_inline_mapplet,
        test_session_connection_overrides,
        test_worklet_generation,
        test_type_casting_at_target,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            print(f"\nRunning: {test.__name__}")
            test()
            passed += 1
        except Exception as e:
            print(f"FAIL: {test.__name__}: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n{'=' * 60}")
    print(f"Results: {passed} passed, {failed} failed")
    print(f"{'=' * 60}")
