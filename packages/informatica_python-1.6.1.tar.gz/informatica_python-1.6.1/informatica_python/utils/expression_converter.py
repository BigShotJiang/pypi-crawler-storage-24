import re


INFA_FUNC_MAP = {
    "IIF": "iif_expr",
    "DECODE": "decode_expr",
    "CHOOSE": "choose_expr",
    "IN": "in_expr",
    "LTRIM": "ltrim",
    "RTRIM": "rtrim",
    "TRIM": "trim_func",
    "UPPER": "upper",
    "LOWER": "lower",
    "INITCAP": "initcap",
    "SUBSTR": "substr",
    "LPAD": "lpad",
    "RPAD": "rpad",
    "REVERSE": "reverse_str",
    "CHR": "chr_func",
    "ASCII": "ascii_func",
    "LEFT": "left_str",
    "RIGHT": "right_str",
    "INDEXOF": "indexof",
    "METAPHONE": "metaphone_func",
    "SOUNDEX": "soundex_func",
    "COMPRESS": "compress_func",
    "DECOMPRESS": "decompress_func",
    "TO_CHAR": "to_char",
    "TO_DATE": "to_date",
    "TO_TIMESTAMP": "to_timestamp_func",
    "TO_INTEGER": "to_integer",
    "TO_BIGINT": "to_bigint",
    "TO_FLOAT": "to_float",
    "TO_DECIMAL": "to_decimal",
    "CAST": "cast_func",
    "SYSDATE": "current_timestamp",
    "SYSTIMESTAMP": "current_timestamp",
    "SESSSTARTTIME": "session_start_time",
    "GET_DATE_PART": "get_date_part",
    "SET_DATE_PART": "set_date_part",
    "ADD_TO_DATE": "add_to_date",
    "DATE_DIFF": "date_diff",
    "DATE_COMPARE": "date_compare",
    "LAST_DAY": "last_day",
    "MAKE_DATE_TIME": "make_date_time",
    "TRUNC": "trunc",
    "ROUND": "round_val",
    "ABS": "abs_val",
    "CEIL": "ceil_val",
    "CEILING": "ceil_val",
    "FLOOR": "floor_val",
    "MOD": "mod_val",
    "POWER": "power_val",
    "SQRT": "sqrt_val",
    "LOG": "log_val",
    "LN": "ln_val",
    "EXP": "exp_val",
    "SIGN": "sign_val",
    "RAND": "rand_val",
    "GREATEST": "greatest_val",
    "LEAST": "least_val",
    "LENGTH": "length",
    "CONCAT": "concat",
    "INSTR": "instr",
    "REPLACECHR": "replacechr",
    "REPLACESTR": "replacestr",
    "REG_EXTRACT": "reg_extract",
    "REG_MATCH": "reg_match",
    "REG_REPLACE": "reg_replace",
    "IS_DATE": "is_date",
    "IS_NUMBER": "is_number",
    "IS_SPACES": "is_spaces",
    "NVL": "nvl",
    "NVL2": "nvl2",
    "ISNULL": "isnull",
    "ERROR": "raise_error",
    "ABORT": "abort_func",
    "LOOKUP": "lookup_func",
    "MAX": "max_val",
    "MIN": "min_val",
    "SUM": "sum_val",
    "COUNT": "count_val",
    "AVG": "avg_val",
    "MEDIAN": "median_val",
    "STDDEV": "stddev_val",
    "VARIANCE": "variance_val",
    "PERCENTILE": "percentile_val",
    "FIRST": "first_val",
    "LAST": "last_val",
    "MOVINGAVG": "moving_avg",
    "MOVINGSUM": "moving_sum",
    "CUME": "cume",
    "SETCOUNTVARIABLE": "set_count_variable",
    "SETVARIABLE": "set_variable",
}


AGG_FUNC_NAMES = [
    "MOVINGAVG", "MOVINGSUM", "PERCENTILE", "VARIANCE",
    "STDDEV", "MEDIAN", "COUNT", "FIRST", "LAST",
    "CUME", "SUM", "AVG", "MAX", "MIN",
]


def convert_expression(expr):
    if not expr or not expr.strip():
        return "None"

    cleaned = expr.strip()

    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', cleaned):
        return f'row["{cleaned}"]'

    if re.match(r'^-?\d+(\.\d+)?$', cleaned):
        return cleaned

    if cleaned.startswith("'") and cleaned.endswith("'"):
        return cleaned

    converted = cleaned

    for infa_func, py_func in sorted(INFA_FUNC_MAP.items(), key=lambda x: -len(x[0])):
        pattern = re.compile(r'\b' + re.escape(infa_func) + r'\s*\(', re.IGNORECASE)
        converted = pattern.sub(f'{py_func}(', converted)

    converted = converted.replace("||", " + ")

    converted = re.sub(r'\bAND\b', ' and ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bOR\b', ' or ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bNOT\b', ' not ', converted, flags=re.IGNORECASE)

    converted = re.sub(r'<>', '!=', converted)

    converted = re.sub(r'(?<![<>!])=(?!=)', '==', converted)

    converted = re.sub(r':LKP\.(\w+)\(', r'lookup_func("\1", ', converted)

    converted = re.sub(r'\$\$(\w+)', r'get_variable("\1")', converted)

    converted = re.sub(r':(\w+)', r'row["\1"]', converted)

    converted = re.sub(r'\bTRUE\b', 'True', converted)
    converted = re.sub(r'\bFALSE\b', 'False', converted)
    converted = re.sub(r'\bNULL\b', 'None', converted)

    converted = re.sub(r'\s+', ' ', converted).strip()

    return converted


VECTORIZED_FUNC_MAP = {
    "UPPER": (".str.upper()", 1),
    "LOWER": (".str.lower()", 1),
    "LTRIM": (".str.lstrip()", 1),
    "RTRIM": (".str.rstrip()", 1),
    "TRIM": (".str.strip()", 1),
    "LENGTH": (".str.len()", 1),
    "INITCAP": (".str.title()", 1),
    "REVERSE": (".str[::-1]", 1),
}

VECTORIZED_TWARG_MAP = {
    "SUBSTR": "str_substr_vec",
    "LPAD": "str_lpad_vec",
    "RPAD": "str_rpad_vec",
    "INSTR": "str_instr_vec",
    "REPLACECHR": "str_replacechr_vec",
    "REPLACESTR": "str_replacestr_vec",
    "REG_EXTRACT": "str_reg_extract_vec",
    "REG_REPLACE": "str_reg_replace_vec",
    "CONCAT": "concat_vec",
}


def convert_expression_vectorized(expr, df_var="df"):
    if not expr or not expr.strip():
        return "None"

    cleaned = expr.strip()

    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', cleaned):
        return f'{df_var}["{cleaned}"]'

    if re.match(r'^-?\d+(\.\d+)?$', cleaned):
        return cleaned

    if cleaned.startswith("'") and cleaned.endswith("'"):
        return cleaned

    converted = cleaned

    for func_name, (method, _) in sorted(VECTORIZED_FUNC_MAP.items(), key=lambda x: -len(x[0])):
        pattern = re.compile(r'\b' + re.escape(func_name) + r'\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)', re.IGNORECASE)
        match = pattern.search(converted)
        if match:
            field = match.group(1)
            replacement = f'{df_var}["{field}"]{method}'
            converted = converted[:match.start()] + replacement + converted[match.end():]

    iif_pattern = re.compile(r'\bIIF\s*\(', re.IGNORECASE)
    if iif_pattern.search(converted):
        iif_match = re.match(r'^\s*IIF\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)\s*$', cleaned, re.IGNORECASE)
        if iif_match:
            cond = _vectorize_condition(iif_match.group(1), df_var)
            true_val = _vectorize_value(iif_match.group(2), df_var)
            false_val = _vectorize_value(iif_match.group(3), df_var)
            return f"np.where({cond}, {true_val}, {false_val})"

    nvl_match = re.match(r'^\s*NVL\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*(.+?)\s*\)\s*$', cleaned, re.IGNORECASE)
    if nvl_match:
        field = nvl_match.group(1)
        default = _vectorize_value(nvl_match.group(2), df_var)
        return f'{df_var}["{field}"].fillna({default})'

    to_int_match = re.match(r'^\s*TO_INTEGER\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$', cleaned, re.IGNORECASE)
    if to_int_match:
        field = to_int_match.group(1)
        return f'pd.to_numeric({df_var}["{field}"], errors="coerce").fillna(0).astype(int)'

    to_bigint_match = re.match(r'^\s*TO_BIGINT\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$', cleaned, re.IGNORECASE)
    if to_bigint_match:
        field = to_bigint_match.group(1)
        return f'pd.to_numeric({df_var}["{field}"], errors="coerce").astype("Int64")'

    to_date_match = re.match(r'^\s*TO_DATE\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?:,\s*(.+?))?\s*\)\s*$', cleaned, re.IGNORECASE)
    if to_date_match:
        field = to_date_match.group(1)
        fmt = to_date_match.group(2)
        if fmt:
            py_fmt = fmt.strip("'\"").replace("YYYY", "%Y").replace("MM", "%m").replace("DD", "%d").replace("HH24", "%H").replace("MI", "%M").replace("SS", "%S")
            return f'pd.to_datetime({df_var}["{field}"], format="{py_fmt}", errors="coerce")'
        return f'pd.to_datetime({df_var}["{field}"], errors="coerce")'

    substr_match = re.match(r'^\s*SUBSTR\s*\(\s*([A-Za-z_]\w*)\s*,\s*(\d+)\s*(?:,\s*(\d+))?\s*\)\s*$', cleaned, re.IGNORECASE)
    if substr_match:
        field = substr_match.group(1)
        start = int(substr_match.group(2)) - 1
        length = substr_match.group(3)
        if length:
            end = start + int(length)
            return f'{df_var}["{field}"].str[{start}:{end}]'
        return f'{df_var}["{field}"].str[{start}:]'

    concat_match = re.match(r'^\s*CONCAT\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)\s*$', cleaned, re.IGNORECASE)
    if concat_match:
        left = _vectorize_value(concat_match.group(1), df_var)
        right = _vectorize_value(concat_match.group(2), df_var)
        return f'{left}.astype(str) + {right}.astype(str)' if not (left.startswith("'") or right.startswith("'")) else f'{left} + {right}'

    if "||" in converted:
        parts = converted.split("||")
        vec_parts = []
        for p in parts:
            p = p.strip()
            vec_parts.append(_vectorize_value(p, df_var) + ".astype(str)")
        return " + ".join(vec_parts)

    converted = re.sub(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*IS\s+NULL\b',
                       lambda m: f'{df_var}["{m.group(1)}"].isna()', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*IS\s+NOT\s+NULL\b',
                       lambda m: f'{df_var}["{m.group(1)}"].notna()', converted, flags=re.IGNORECASE)

    converted = re.sub(r'\$\$(\w+)', r'get_variable("\1")', converted)

    skip_words = {
        'True', 'False', 'None', 'and', 'or', 'not', 'np', 'pd', 'get_variable',
        'str', 'int', 'float', 'bool', 'len', 'abs', 'round',
        'fillna', 'astype', 'isna', 'notna', 'where', 'errors', 'coerce',
    }
    df_base = re.escape(df_var)
    converted = re.sub(r'(?<!["\w])(?!' + df_base + r')([A-Za-z_][A-Za-z0-9_]*)(?!["\w(.\[])',
                       lambda m: f'{df_var}["{m.group(1)}"]' if m.group(1) not in skip_words
                       and not m.group(1).endswith('_vec') else m.group(1),
                       converted)

    converted = re.sub(r'\bAND\b', ' & ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bOR\b', ' | ', converted, flags=re.IGNORECASE)
    converted = re.sub(r'\bNOT\b', ' ~', converted, flags=re.IGNORECASE)
    converted = re.sub(r'<>', '!=', converted)
    converted = re.sub(r'(?<![<>!=])=(?!=)', '==', converted)

    converted = re.sub(r'\bTRUE\b', 'True', converted)
    converted = re.sub(r'\bFALSE\b', 'False', converted)
    converted = re.sub(r'\bNULL\b', 'None', converted)

    converted = re.sub(r'\s+', ' ', converted).strip()

    return converted


def _vectorize_value(val, df_var="df"):
    val = val.strip()
    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', val):
        return f'{df_var}["{val}"]'
    return val


def _vectorize_simple(part, df_var):
    c = part.strip()

    c = re.sub(r'\bISNULL\s*\(\s*([A-Za-z_]\w*)\s*\)',
               lambda m: f'{df_var}["{m.group(1)}"].isna()', c, flags=re.IGNORECASE)
    c = re.sub(r'\b([A-Za-z_]\w*)\s*IS\s+NOT\s+NULL\b',
               lambda m: f'{df_var}["{m.group(1)}"].notna()', c, flags=re.IGNORECASE)
    c = re.sub(r'\b([A-Za-z_]\w*)\s*IS\s+NULL\b',
               lambda m: f'{df_var}["{m.group(1)}"].isna()', c, flags=re.IGNORECASE)

    c = re.sub(r'<>', '!=', c)
    c = re.sub(r'(?<![<>!=])=(?!=)', '==', c)

    skip_words = {
        'True', 'False', 'None', 'and', 'or', 'not', 'np', 'pd',
        'str', 'int', 'float', 'isna', 'notna', 'fillna',
    }
    df_base = re.escape(df_var)
    c = re.sub(r'(?<!["\w])(?!' + df_base + r'\b)([A-Za-z_][A-Za-z0-9_]*)(?!["\w(.\[])',
               lambda m: f'{df_var}["{m.group(1)}"]' if m.group(1) not in skip_words else m.group(1),
               c)
    return c


def _vectorize_condition(cond, df_var="df"):
    c = cond.strip()

    tokens = re.split(r'\b(AND|OR)\b', c, flags=re.IGNORECASE)

    parts = []
    ops = []
    for tok in tokens:
        stripped = tok.strip()
        if stripped.upper() in ('AND', 'OR'):
            ops.append('&' if stripped.upper() == 'AND' else '|')
        elif stripped:
            parts.append(stripped)

    if not parts:
        return "True"

    vectorized = []
    for part in parts:
        negate = False
        inner = part.strip()
        if re.match(r'^NOT\s+', inner, flags=re.IGNORECASE):
            negate = True
            inner = re.sub(r'^NOT\s+', '', inner, flags=re.IGNORECASE).strip()
        v = _vectorize_simple(inner, df_var)
        if negate:
            v = f"~({v})"
        vectorized.append(v)

    if len(vectorized) == 1:
        return vectorized[0]

    result_parts = [f"({vectorized[0]})"]
    for i, op in enumerate(ops):
        result_parts.append(f" {op} ")
        result_parts.append(f"({vectorized[i + 1]})")
    return "".join(result_parts)


def convert_filter_expression(expr):
    if not expr or not expr.strip():
        return "True"

    converted = convert_expression(expr)
    return converted


def convert_filter_vectorized(expr, df_var="df"):
    if not expr or not expr.strip():
        return "True"
    return _vectorize_condition(expr, df_var)


def parse_join_condition(condition):
    if not condition or not condition.strip():
        return [], []

    left_keys = []
    right_keys = []

    parts = re.split(r'\bAND\b', condition, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        match = re.match(r'(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)', part)
        if match:
            left_keys.append(match.group(2))
            right_keys.append(match.group(4))
        else:
            match = re.match(r'(\w+)\s*=\s*(\w+)', part)
            if match:
                left_keys.append(match.group(1))
                right_keys.append(match.group(2))

    return left_keys, right_keys


def parse_lookup_condition(condition):
    if not condition or not condition.strip():
        return [], []

    input_keys = []
    lookup_keys = []

    parts = re.split(r'\bAND\b', condition, flags=re.IGNORECASE)
    for part in parts:
        part = part.strip()
        match = re.match(r'(\w+)\s*=\s*(\w+)', part)
        if match:
            input_keys.append(match.group(1))
            lookup_keys.append(match.group(2))

    return input_keys, lookup_keys


def parse_aggregate_expression(expr):
    if not expr or not expr.strip():
        return None, None

    cleaned = expr.strip()

    for func_name in AGG_FUNC_NAMES:
        pattern = re.compile(
            r'^\s*' + func_name + r'\s*\(\s*([A-Za-z_][A-Za-z0-9_]*|\*)\s*\)\s*$',
            re.IGNORECASE
        )
        match = pattern.match(cleaned)
        if match:
            col = match.group(1).strip()
            return func_name.lower(), col

    return None, None


PANDAS_AGG_MAP = {
    "sum": "sum",
    "count": "count",
    "avg": "mean",
    "max": "max",
    "min": "min",
    "median": "median",
    "stddev": "std",
    "variance": "var",
    "first": "first",
    "last": "last",
}


def convert_sql_expression(sql_expr):
    if not sql_expr or not sql_expr.strip():
        return ""

    converted = sql_expr.strip()
    converted = converted.replace("&#xD;&#xA;", "\n")
    converted = converted.replace("&#xD;", "\r")
    converted = converted.replace("&#xA;", "\n")
    converted = converted.replace("&#x9;", "\t")
    converted = converted.replace("&apos;", "'")
    converted = converted.replace("&quot;", '"')
    converted = converted.replace("&amp;", "&")
    converted = converted.replace("&lt;", "<")
    converted = converted.replace("&gt;", ">")

    return converted


def detect_sql_dialect(sql_text):
    if not sql_text:
        return "generic"

    sql_upper = sql_text.upper()

    if "GETDATE()" in sql_upper or "ISNULL(" in sql_upper or "TOP " in sql_upper:
        return "mssql"
    if ("NVL(" in sql_upper or "SYSDATE" in sql_upper or "ROWNUM" in sql_upper
            or "DECODE(" in sql_upper or "(+)" in sql_upper or "SYSTIMESTAMP" in sql_upper):
        return "oracle"
    if "NOW()" in sql_upper or "COALESCE(" in sql_upper:
        return "postgresql"

    return "generic"
