INFORMATICA_TO_PYTHON = {
    "bigint": "int",
    "integer": "int",
    "int": "int",
    "small integer": "int",
    "smallint": "int",
    "tinyint": "int",
    "numeric": "float",
    "decimal": "float",
    "float": "float",
    "double": "float",
    "real": "float",
    "money": "float",
    "smallmoney": "float",
    "string": "str",
    "nstring": "str",
    "text": "str",
    "ntext": "str",
    "varchar": "str",
    "nvarchar": "str",
    "char": "str",
    "nchar": "str",
    "binary": "bytes",
    "varbinary": "bytes",
    "image": "bytes",
    "date/time": "str",
    "datetime": "str",
    "datetime2": "str",
    "date": "str",
    "time": "str",
    "timestamp": "str",
    "bit": "bool",
    "boolean": "bool",
    "uniqueidentifier": "str",
    "xml": "str",
    "sql_variant": "str",
}

INFORMATICA_TO_SPARK = {
    "bigint": "LongType()",
    "integer": "IntegerType()",
    "int": "IntegerType()",
    "small integer": "ShortType()",
    "smallint": "ShortType()",
    "tinyint": "ByteType()",
    "numeric": "DecimalType({precision}, {scale})",
    "decimal": "DecimalType({precision}, {scale})",
    "float": "FloatType()",
    "double": "DoubleType()",
    "real": "FloatType()",
    "money": "DecimalType(19, 4)",
    "smallmoney": "DecimalType(10, 4)",
    "string": "StringType()",
    "nstring": "StringType()",
    "text": "StringType()",
    "ntext": "StringType()",
    "varchar": "StringType()",
    "nvarchar": "StringType()",
    "char": "StringType()",
    "nchar": "StringType()",
    "binary": "BinaryType()",
    "varbinary": "BinaryType()",
    "image": "BinaryType()",
    "date/time": "TimestampType()",
    "datetime": "TimestampType()",
    "datetime2": "TimestampType()",
    "date": "DateType()",
    "time": "StringType()",
    "timestamp": "TimestampType()",
    "bit": "BooleanType()",
    "boolean": "BooleanType()",
    "uniqueidentifier": "StringType()",
    "xml": "StringType()",
    "sql_variant": "StringType()",
}

DB_TYPE_MAP = {
    "Microsoft SQL Server": "mssql",
    "Oracle": "oracle",
    "Sybase": "sybase",
    "Informix": "informix",
    "DB2": "db2",
    "Teradata": "teradata",
    "ODBC": "odbc",
    "Flat File": "flatfile",
    "XML": "xml",
    "SAP": "sap",
    "": "unknown",
}


def get_python_type(informatica_type):
    return INFORMATICA_TO_PYTHON.get(informatica_type.lower().strip(), "str")


def get_spark_type(informatica_type, precision=10, scale=0):
    key = informatica_type.lower().strip()
    spark_type = INFORMATICA_TO_SPARK.get(key, "StringType()")
    if "{precision}" in spark_type:
        spark_type = spark_type.format(precision=precision, scale=scale)
    return spark_type


def get_db_type(database_type):
    return DB_TYPE_MAP.get(database_type, database_type.lower() if database_type else "unknown")
