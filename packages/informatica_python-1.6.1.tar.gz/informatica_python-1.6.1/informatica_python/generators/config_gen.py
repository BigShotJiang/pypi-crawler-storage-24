import yaml
from typing import List, Dict
from informatica_python.models import FolderDef, SessionDef
from informatica_python.utils.datatype_map import get_db_type


def generate_config(folder: FolderDef, data_lib: str = "pandas") -> str:
    config = {
        "workflow": {
            "name": "",
            "folder": folder.name,
        },
        "data_library": data_lib,
        "connections": {},
        "sources": {},
        "targets": {},
        "variables": {},
    }

    if folder.workflows:
        config["workflow"]["name"] = folder.workflows[0].name

    connection_names = set()

    for src in folder.sources:
        src_config = {
            "database_type": src.database_type or "unknown",
            "db_name": src.db_name or "",
            "owner": src.owner_name or "dbo",
            "fields": [],
        }

        for fld in src.fields:
            src_config["fields"].append({
                "name": fld.name,
                "datatype": fld.datatype,
                "precision": fld.precision,
                "scale": fld.scale,
                "nullable": fld.nullable,
            })

        config["sources"][src.name] = src_config

        if src.database_type and src.database_type != "Flat File":
            conn_key = src.db_name or "default"
            if conn_key not in connection_names:
                connection_names.add(conn_key)
                config["connections"][conn_key] = {
                    "type": get_db_type(src.database_type),
                    "host": "${DB_HOST}",
                    "port": _get_default_port(src.database_type),
                    "database": src.db_name or "${DB_NAME}",
                    "username": "${DB_USER}",
                    "password": "${DB_PASSWORD}",
                    "schema": src.owner_name or "dbo",
                }
        else:
            config["sources"][src.name]["file_path"] = f"${{INPUT_DIR}}/{src.name}"
            config["sources"][src.name]["delimiter"] = ","
            config["sources"][src.name]["header"] = True
            config["sources"][src.name]["encoding"] = "utf-8"

    for tgt in folder.targets:
        tgt_config = {
            "database_type": tgt.database_type or "unknown",
            "fields": [],
        }

        for fld in tgt.fields:
            tgt_config["fields"].append({
                "name": fld.name,
                "datatype": fld.datatype,
                "precision": fld.precision,
                "scale": fld.scale,
                "nullable": fld.nullable,
                "keytype": fld.keytype,
            })

        config["targets"][tgt.name] = tgt_config

        if tgt.database_type and tgt.database_type != "Flat File":
            conn_key = "target"
            if conn_key not in connection_names:
                connection_names.add(conn_key)
                config["connections"][conn_key] = {
                    "type": get_db_type(tgt.database_type),
                    "host": "${DB_HOST}",
                    "port": _get_default_port(tgt.database_type),
                    "database": "${TARGET_DB_NAME}",
                    "username": "${DB_USER}",
                    "password": "${DB_PASSWORD}",
                    "schema": "dbo",
                }
        else:
            config["targets"][tgt.name]["file_path"] = f"${{OUTPUT_DIR}}/{tgt.name}"

    _extract_session_connections(folder, config, connection_names)

    for mapping in folder.mappings:
        for var in mapping.variables:
            var_name = var.name.replace("$$", "")
            config["variables"][var_name] = {
                "datatype": var.datatype,
                "default_value": var.default_value or "",
                "is_persistent": var.is_persistent,
            }

    for wf in folder.workflows:
        for var in wf.variables:
            var_name = var.name.replace("$$", "")
            config["variables"][var_name] = {
                "datatype": var.datatype,
                "default_value": var.default_value or "",
                "is_persistent": var.is_persistent,
            }

    if not config["connections"]:
        config["connections"]["default"] = {
            "type": "mssql",
            "host": "${DB_HOST}",
            "port": 1433,
            "database": "${DB_NAME}",
            "username": "${DB_USER}",
            "password": "${DB_PASSWORD}",
            "schema": "dbo",
        }

    return yaml.dump(config, default_flow_style=False, sort_keys=False, allow_unicode=True)


def _get_default_port(database_type):
    port_map = {
        "Microsoft SQL Server": 1433,
        "Oracle": 1521,
        "Sybase": 5000,
        "DB2": 50000,
        "Teradata": 1025,
        "Informix": 9088,
    }
    return port_map.get(database_type, 1433)


def _extract_session_connections(folder, config, connection_names):
    for session in folder.sessions:
        for sti in session.transform_instances:
            for conn_ref in sti.connections:
                conn_name = conn_ref.connection_name or conn_ref.variable or "default"
                if conn_name and conn_name not in connection_names:
                    connection_names.add(conn_name)
                    config["connections"][conn_name] = {
                        "type": conn_ref.connection_type or "relational",
                        "connection_name": conn_ref.connection_name,
                        "connection_subtype": conn_ref.connection_subtype,
                        "host": "${DB_HOST}",
                        "port": 1433,
                        "database": "${DB_NAME}",
                        "username": "${DB_USER}",
                        "password": "${DB_PASSWORD}",
                    }
