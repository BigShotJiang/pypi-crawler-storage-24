from datetime import datetime
from informatica_python.models import FolderDef


def generate_error_log(folder: FolderDef, parser_errors=None, parser_warnings=None) -> str:
    lines = []
    lines.append("=" * 70)
    lines.append(f"Informatica-Python Conversion Log")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"Folder: {folder.name}")
    lines.append("=" * 70)
    lines.append("")

    lines.append(f"Sources found: {len(folder.sources)}")
    for src in folder.sources:
        extra = ""
        if src.flatfile:
            extra += f", flatfile(delim={src.flatfile.delimiter})"
        if src.xmlinfo:
            extra += f", xml(root={src.xmlinfo.root_element})"
        if src.erp_src_info:
            extra += f", erp({src.erp_src_info.source_type})"
        if src.groups:
            extra += f", {len(src.groups)} groups"
        if src.keywords:
            extra += f", {len(src.keywords)} keywords"
        lines.append(f"  - {src.name} ({src.database_type}, {len(src.fields)} fields{extra})")
    lines.append("")

    lines.append(f"Targets found: {len(folder.targets)}")
    for tgt in folder.targets:
        extra = ""
        if tgt.indexes:
            extra += f", {len(tgt.indexes)} indexes"
        if tgt.flatfile:
            extra += f", flatfile"
        if tgt.xmlinfo:
            extra += f", xml"
        if tgt.groups:
            extra += f", {len(tgt.groups)} groups"
        lines.append(f"  - {tgt.name} ({tgt.database_type}, {len(tgt.fields)} fields{extra})")
    lines.append("")

    lines.append(f"Mappings found: {len(folder.mappings)}")
    for mapping in folder.mappings:
        lines.append(f"  - {mapping.name} (valid={mapping.is_valid})")
        lines.append(f"    Transformations: {len(mapping.transformations)}")
        tx_types = {}
        for tx in mapping.transformations:
            tx_types[tx.type] = tx_types.get(tx.type, 0) + 1
        for tx_type, count in sorted(tx_types.items()):
            lines.append(f"      {tx_type}: {count}")
        lines.append(f"    Connectors: {len(mapping.connectors)}")
        lines.append(f"    Instances: {len(mapping.instances)}")
        lines.append(f"    Variables: {len(mapping.variables)}")
        lines.append(f"    Target Load Orders: {len(mapping.target_load_orders)}")
        if mapping.map_dependencies:
            lines.append(f"    Map Dependencies: {len(mapping.map_dependencies)}")
        if mapping.field_dependencies:
            lines.append(f"    Field Dependencies: {len(mapping.field_dependencies)}")
    lines.append("")

    lines.append(f"Sessions found: {len(folder.sessions)}")
    for session in folder.sessions:
        extra = ""
        if session.transform_groups:
            extra += f", {len(session.transform_groups)} transform groups"
        partitions = sum(len(sti.partitions) for sti in session.transform_instances)
        if partitions:
            extra += f", {partitions} partitions"
        lines.append(f"  - {session.name} (mapping: {session.mapping_name}{extra})")
    lines.append("")

    lines.append(f"Workflows found: {len(folder.workflows)}")
    for wf in folder.workflows:
        is_worklet = " [WORKLET]" if wf.metadata.get("is_worklet") == "YES" else ""
        lines.append(f"  - {wf.name} (valid={wf.is_valid}){is_worklet}")
        lines.append(f"    Task Instances: {len(wf.task_instances)}")
        lines.append(f"    Links: {len(wf.links)}")
        lines.append(f"    Variables: {len(wf.variables)}")
        if wf.events:
            lines.append(f"    Events: {len(wf.events)}")
        if wf.scheduler_name:
            lines.append(f"    Scheduler: {wf.scheduler_name}")
    lines.append("")

    if folder.mapplets:
        lines.append(f"Mapplets found: {len(folder.mapplets)}")
        for m in folder.mapplets:
            extra = ""
            if m.map_dependencies:
                extra += f", {len(m.map_dependencies)} deps"
            lines.append(f"  - {m.name} ({len(m.transformations)} transformations{extra})")
        lines.append("")

    if folder.tasks:
        lines.append(f"Tasks found: {len(folder.tasks)}")
        for t in folder.tasks:
            extra = ""
            if t.timer:
                extra += f", timer({t.timer.start_type})"
            if t.value_pairs:
                extra += f", {len(t.value_pairs)} value pairs"
            lines.append(f"  - {t.name} (type={t.type}{extra})")
        lines.append("")

    if folder.shortcuts:
        lines.append(f"Shortcuts found: {len(folder.shortcuts)}")
        for s in folder.shortcuts:
            lines.append(f"  - {s.name} -> {s.reference_name} (folder={s.folder_name}, type={s.object_type})")
        lines.append("")

    if folder.configs:
        lines.append(f"Configs found: {len(folder.configs)}")
        for c in folder.configs:
            lines.append(f"  - {c.name} ({len(c.attributes)} attributes)")
        lines.append("")

    if folder.schedulers:
        lines.append(f"Schedulers found: {len(folder.schedulers)}")
        for s in folder.schedulers:
            extra = ""
            if s.schedule_info:
                extra += f", type={s.schedule_info.schedule_type}"
            if s.recurring:
                extra += ", recurring"
            if s.daily_frequency:
                extra += ", daily"
            lines.append(f"  - {s.name}{extra}")
        lines.append("")

    if folder.transformations:
        lines.append(f"Reusable Transformations found: {len(folder.transformations)}")
        for tx in folder.transformations:
            extra = ""
            if tx.sap_functions:
                extra += f", {len(tx.sap_functions)} SAP functions"
            if tx.groups:
                extra += f", {len(tx.groups)} groups"
            if tx.erp_info:
                extra += f", ERP({tx.erp_info.erp_type})"
            lines.append(f"  - {tx.name} (type={tx.type}{extra})")
        lines.append("")

    if folder.folder_versions:
        lines.append(f"Folder Versions found: {len(folder.folder_versions)}")
        for fv in folder.folder_versions:
            lines.append(f"  - {fv.folder_name} v{fv.version_number}")
        lines.append("")

    lines.append("-" * 70)
    lines.append("WARNINGS AND DETECTIONS")
    lines.append("-" * 70)
    lines.append("")

    if parser_errors:
        for err in parser_errors:
            lines.append(f"[ERROR] {err}")
        lines.append("")

    if parser_warnings:
        for warn in parser_warnings:
            lines.append(f"[WARNING] {warn}")
        lines.append("")

    for mapping in folder.mappings:
        for tx in mapping.transformations:
            if tx.type in ("Custom Transformation", "Java", "Stored Procedure",
                           "External Procedure", "HTTP Transformation",
                           "Web Service Consumer"):
                lines.append(f"[WARNING] Mapping '{mapping.name}': Transformation '{tx.name}' is type '{tx.type}' - manual review needed")

            if tx.sap_functions:
                lines.append(f"[WARNING] Mapping '{mapping.name}': Transformation '{tx.name}' has {len(tx.sap_functions)} SAP functions - manual review needed")

            if tx.erp_info:
                lines.append(f"[INFO] Mapping '{mapping.name}': Transformation '{tx.name}' has ERP info ({tx.erp_info.erp_type})")

            if tx.type == "Lookup Procedure":
                has_sql_override = False
                for attr in tx.attributes:
                    if attr.name == "Lookup Sql Override" and attr.value:
                        has_sql_override = True
                if has_sql_override:
                    lines.append(f"[INFO] Mapping '{mapping.name}': Lookup '{tx.name}' has SQL override")

            if tx.type == "Source Qualifier":
                for attr in tx.attributes:
                    if attr.name == "Sql Query" and attr.value:
                        lines.append(f"[INFO] Mapping '{mapping.name}': Source Qualifier '{tx.name}' has SQL override")

            if tx.init_props:
                lines.append(f"[INFO] Mapping '{mapping.name}': Transformation '{tx.name}' has {len(tx.init_props)} INITPROP entries")

            for fld in tx.fields:
                if fld.expression:
                    expr_upper = fld.expression.upper()
                    if "ERROR(" in expr_upper or "ABORT(" in expr_upper:
                        lines.append(f"[WARNING] Mapping '{mapping.name}': Field '{fld.name}' in '{tx.name}' contains ERROR/ABORT function")
                    if ":LKP." in fld.expression:
                        lines.append(f"[INFO] Mapping '{mapping.name}': Field '{fld.name}' uses inline lookup")

    for src in folder.sources:
        if src.erp_src_info:
            lines.append(f"[INFO] Source '{src.name}': Has ERP source info ({src.erp_src_info.source_type})")
        if src.flatfile:
            lines.append(f"[INFO] Source '{src.name}': Flat file (delimiter='{src.flatfile.delimiter}', fixed_width={src.flatfile.is_fixed_width})")
        if src.xmlinfo:
            lines.append(f"[INFO] Source '{src.name}': XML source (type={src.xmlinfo.xml_type}, root={src.xmlinfo.root_element})")

    for tgt in folder.targets:
        if tgt.flatfile:
            lines.append(f"[INFO] Target '{tgt.name}': Flat file target")
        if tgt.xmlinfo:
            lines.append(f"[INFO] Target '{tgt.name}': XML target")
        if tgt.indexes:
            for idx in tgt.indexes:
                lines.append(f"[INFO] Target '{tgt.name}': Index '{idx.name}' ({idx.index_type}, unique={idx.unique}, {len(idx.fields)} fields)")

    for session in folder.sessions:
        for sti in session.transform_instances:
            for part in sti.partitions:
                lines.append(f"[INFO] Session '{session.name}': Partition '{part.name}' (type={part.partition_type}) on '{sti.instance_name}'")

    lines.append("")
    lines.append("-" * 70)
    lines.append("UNSUPPORTED TRANSFORMS (Require Manual Review)")
    lines.append("-" * 70)
    lines.append("")

    unsupported_types = {
        "Custom Transformation", "Java", "Stored Procedure",
        "External Procedure", "HTTP Transformation",
        "Web Service Consumer", "SQL",
    }
    skipped_items = []
    for mapping in folder.mappings:
        for tx in mapping.transformations:
            if tx.type in unsupported_types:
                skipped_attrs = []
                for attr in tx.attributes:
                    if attr.value and attr.value.strip():
                        skipped_attrs.append(attr.name)
                skipped_items.append({
                    "mapping": mapping.name,
                    "transform": tx.name,
                    "type": tx.type,
                    "field_count": len(tx.fields),
                    "skipped_attrs": skipped_attrs,
                })

    if skipped_items:
        for item in skipped_items:
            lines.append(f"  Mapping: {item['mapping']}")
            lines.append(f"    Transform: {item['transform']} (type={item['type']}, {item['field_count']} fields)")
            if item['skipped_attrs']:
                lines.append(f"    Skipped attributes: {', '.join(item['skipped_attrs'])}")
            lines.append("")
    else:
        lines.append("  None - all transformations are supported")
        lines.append("")

    lines.append("-" * 70)
    lines.append("UNMAPPED PORTS (Fields with no connectors)")
    lines.append("-" * 70)
    lines.append("")

    for mapping in folder.mappings:
        connected_fields = set()
        for conn in mapping.connectors:
            connected_fields.add((conn.from_instance, conn.from_field))
            connected_fields.add((conn.to_instance, conn.to_field))

        unmapped = []
        for tx in mapping.transformations:
            for fld in tx.fields:
                pt = (fld.porttype or "").upper()
                if "OUTPUT" in pt or "INPUT/OUTPUT" in pt:
                    if (tx.name, fld.name) not in connected_fields:
                        unmapped.append((tx.name, tx.type, fld.name, fld.porttype or ""))

        if unmapped:
            lines.append(f"  Mapping: {mapping.name}")
            for tx_name, tx_type, fld_name, port_type in unmapped:
                lines.append(f"    {tx_name} ({tx_type}): {fld_name} [{port_type}]")
            lines.append("")

    lines.append("-" * 70)
    lines.append("UNSUPPORTED EXPRESSION FUNCTIONS")
    lines.append("-" * 70)
    lines.append("")

    import re
    known_functions = {
        "IIF", "DECODE", "CHOOSE", "IN", "LTRIM", "RTRIM", "TRIM",
        "UPPER", "LOWER", "INITCAP", "SUBSTR", "LPAD", "RPAD",
        "REVERSE", "CHR", "ASCII", "LEFT", "RIGHT", "INDEXOF",
        "TO_CHAR", "TO_DATE", "TO_TIMESTAMP", "TO_INTEGER", "TO_BIGINT",
        "TO_FLOAT", "TO_DECIMAL", "CAST", "SYSDATE", "SYSTIMESTAMP",
        "GET_DATE_PART", "SET_DATE_PART", "ADD_TO_DATE", "DATE_DIFF",
        "DATE_COMPARE", "LAST_DAY", "MAKE_DATE_TIME", "TRUNC", "ROUND",
        "ABS", "CEIL", "CEILING", "FLOOR", "MOD", "POWER", "SQRT",
        "LOG", "EXP", "SIGN", "LENGTH", "CONCAT", "INSTR", "REPLACE",
        "REPLACESTR", "REPLACECHR", "REG_EXTRACT", "REG_REPLACE",
        "REG_MATCH", "IS_SPACES", "IS_NUMBER", "IS_DATE", "NVL",
        "NVL2", "ISNULL", "MAX", "MIN", "SUM", "AVG", "COUNT",
        "FIRST", "LAST", "MEDIAN", "PERCENTILE", "VARIANCE", "STDDEV",
        "LOOKUP", "ERROR", "ABORT", "SESSSTARTTIME",
        "METAPHONE", "SOUNDEX", "COMPRESS", "DECOMPRESS",
        "RANK", "MOVINGAVG", "MOVINGSUM", "CUME",
    }
    func_pattern = re.compile(r'\b([A-Z_][A-Z0-9_]*)\s*\(', re.IGNORECASE)
    unsupported_funcs = {}
    for mapping in folder.mappings:
        for tx in mapping.transformations:
            for fld in tx.fields:
                if not fld.expression:
                    continue
                for m in func_pattern.finditer(fld.expression):
                    func_name = m.group(1).upper()
                    if func_name not in known_functions:
                        key = func_name
                        if key not in unsupported_funcs:
                            unsupported_funcs[key] = []
                        unsupported_funcs[key].append(
                            f"{mapping.name} > {tx.name} > {fld.name}"
                        )

    if unsupported_funcs:
        for func_name in sorted(unsupported_funcs.keys()):
            locations = unsupported_funcs[func_name]
            lines.append(f"  {func_name}() — found in {len(locations)} field(s):")
            for loc in locations[:5]:
                lines.append(f"    - {loc}")
            if len(locations) > 5:
                lines.append(f"    ... and {len(locations) - 5} more")
            lines.append("")
    else:
        lines.append("  None - all expression functions are recognized")
        lines.append("")

    lines.append("")
    lines.append("-" * 70)
    lines.append("PARSED XML TAG COVERAGE")
    lines.append("-" * 70)
    lines.append("")

    all_transformations = list(folder.transformations)
    for m in folder.mappings:
        all_transformations.extend(m.transformations)
    for mpl in folder.mapplets:
        all_transformations.extend(mpl.transformations)

    all_instances = []
    for m in folder.mappings:
        all_instances.extend(m.instances)
    for mpl in folder.mapplets:
        all_instances.extend(mpl.instances)

    me_count = len(folder.metadata_extensions)
    me_count += sum(len(s.metadata_extensions) for s in folder.sources)
    me_count += sum(len(t.metadata_extensions) for t in folder.targets)
    me_count += sum(len(m.metadata_extensions) for m in folder.mappings)
    me_count += sum(len(mpl.metadata_extensions) for mpl in folder.mapplets)
    me_count += sum(len(s.metadata_extensions) for s in folder.sessions)
    me_count += sum(len(w.metadata_extensions) for w in folder.workflows)
    me_count += sum(len(t.metadata_extensions) for t in folder.tasks)
    me_count += sum(len(c.metadata_extensions) for c in folder.configs)
    me_count += sum(len(tx.metadata_extensions) for tx in all_transformations)

    group_count = (
        sum(len(s.groups) for s in folder.sources)
        + sum(len(t.groups) for t in folder.targets)
        + sum(len(tx.groups) for tx in all_transformations)
    )

    tag_counts = {
        "FOLDERVERSION": len(folder.folder_versions),
        "SOURCE": len(folder.sources),
        "SOURCEFIELD": sum(len(s.fields) for s in folder.sources),
        "TARGET": len(folder.targets),
        "TARGETFIELD": sum(len(t.fields) for t in folder.targets),
        "TARGETINDEX": sum(len(t.indexes) for t in folder.targets),
        "TARGETINDEXFIELD": sum(len(idx.fields) for t in folder.targets for idx in t.indexes),
        "FLATFILE": sum(1 for s in folder.sources if s.flatfile) + sum(1 for t in folder.targets if t.flatfile),
        "XMLINFO": sum(1 for s in folder.sources if s.xmlinfo) + sum(1 for t in folder.targets if t.xmlinfo),
        "GROUP": group_count,
        "KEYWORD": sum(len(s.keywords) for s in folder.sources) + sum(len(t.keywords) for t in folder.targets),
        "ERPSRCINFO": sum(1 for s in folder.sources if s.erp_src_info),
        "MAPPING": len(folder.mappings),
        "MAPPLET": len(folder.mapplets),
        "TRANSFORMATION": len(all_transformations),
        "TRANSFORMFIELD": sum(len(tx.fields) for tx in all_transformations),
        "TRANSFORMFIELDATTR": sum(len(tx.field_attrs) for tx in all_transformations),
        "TRANSFORMFIELDATTRDEF": sum(len(tx.field_attr_defs) for tx in all_transformations),
        "INITPROP": sum(len(tx.init_props) for tx in all_transformations),
        "ERPINFO": sum(1 for tx in all_transformations if tx.erp_info),
        "INSTANCE": len(all_instances),
        "ASSOCIATED_SOURCE_INSTANCE": sum(len(i.associated_source_instances) for i in all_instances),
        "CONNECTOR": sum(len(m.connectors) for m in folder.mappings) + sum(len(mpl.connectors) for mpl in folder.mapplets),
        "TARGETLOADORDER": sum(len(m.target_load_orders) for m in folder.mappings),
        "MAPPINGVARIABLE": sum(len(m.variables) for m in folder.mappings),
        "MAPDEPENDENCY": sum(len(m.map_dependencies) for m in folder.mappings) + sum(len(mpl.map_dependencies) for mpl in folder.mapplets),
        "FIELDDEPENDENCY": sum(len(m.field_dependencies) for m in folder.mappings) + sum(len(mpl.field_dependencies) for mpl in folder.mapplets),
        "SESSION": len(folder.sessions),
        "SESSTRANSFORMATIONINST": sum(len(s.transform_instances) for s in folder.sessions),
        "SESSTRANSFORMATIONGROUP": sum(len(s.transform_groups) for s in folder.sessions),
        "PARTITION": sum(len(sti.partitions) for s in folder.sessions for sti in s.transform_instances),
        "HASHKEY": sum(len(p.hash_keys) for s in folder.sessions for sti in s.transform_instances for p in sti.partitions),
        "KEYRANGE": sum(len(p.key_ranges) for s in folder.sessions for sti in s.transform_instances for p in sti.partitions),
        "CONFIGREFERENCE": sum(len(s.config_references) for s in folder.sessions),
        "CONNECTIONREFERENCE": sum(len(sti.connections) for s in folder.sessions for sti in s.transform_instances),
        "SESSIONCOMPONENT": sum(len(s.components) for s in folder.sessions),
        "TASK": len(folder.tasks),
        "VALUEPAIR": sum(len(t.value_pairs) for t in folder.tasks),
        "TIMER": sum(1 for t in folder.tasks if t.timer),
        "CONFIG": len(folder.configs),
        "SCHEDULER": len(folder.schedulers),
        "WORKFLOW": sum(1 for w in folder.workflows if w.metadata.get("is_worklet") != "YES"),
        "WORKLET": sum(1 for w in folder.workflows if w.metadata.get("is_worklet") == "YES"),
        "TASKINSTANCE": sum(len(w.task_instances) for w in folder.workflows),
        "WORKFLOWLINK": sum(len(w.links) for w in folder.workflows),
        "WORKFLOWVARIABLE": sum(len(w.variables) for w in folder.workflows),
        "WORKFLOWEVENT": sum(len(w.events) for w in folder.workflows),
        "SHORTCUT": len(folder.shortcuts),
        "METADATAEXTENSION": me_count,
        "SAPFUNCTION": sum(len(tx.sap_functions) for tx in all_transformations),
    }

    for tag, count in sorted(tag_counts.items()):
        if count > 0:
            lines.append(f"  {tag}: {count}")

    lines.append("")
    lines.append("-" * 70)
    lines.append("CONVERSION SUMMARY")
    lines.append("-" * 70)
    lines.append("")

    total_transforms = sum(len(m.transformations) for m in folder.mappings)
    unsupported = 0
    for mapping in folder.mappings:
        for tx in mapping.transformations:
            if tx.type in ("Custom Transformation", "Java", "Stored Procedure",
                           "External Procedure", "HTTP Transformation",
                           "Web Service Consumer"):
                unsupported += 1

    supported = total_transforms - unsupported
    pct = (supported / total_transforms * 100) if total_transforms > 0 else 100

    lines.append(f"Total transformations: {total_transforms}")
    lines.append(f"Supported/converted: {supported}")
    lines.append(f"Needs manual review: {unsupported}")
    lines.append(f"Conversion coverage: {pct:.1f}%")
    lines.append("")

    return "\n".join(lines)
