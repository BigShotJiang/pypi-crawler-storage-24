"""
informatica-python: Convert Informatica PowerCenter workflow XML to Python/PySpark code.

Copyright (c) 2025 Nick. All rights reserved.
Licensed under the MIT License.
"""

from informatica_python.converter import InformaticaConverter

__version__ = "1.6.1"
__author__ = "Nick"
__license__ = "MIT"
__all__ = ["InformaticaConverter"]
