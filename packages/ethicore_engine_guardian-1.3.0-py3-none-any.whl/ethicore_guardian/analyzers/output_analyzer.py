"""
Ethicore Engine(tm) - Guardian SDK -- Output Analyzer
Post-generation response scanner: detects LLM jailbreak compliance signals.
Version: 1.0.0

Scans the LLM's output for evidence that the model was successfully attacked --
i.e., it complied with an adversarial prompt that the pre-flight gate should
have blocked. Suppresses compromised responses before they reach the end user,
creating a true second line of defence.

Copyright (c) 2026 Oracles Technologies LLC. All Rights Reserved.
"""
from __future__ import annotations

import re
import time
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class OutputAnalysisResult:
    """Result of post-generation output analysis."""
    is_compromised: bool
    compromise_score: float          # 0.0-1.0
    confidence: float                # 0.0-1.0
    threat_level: str                # NONE / LOW / MEDIUM / HIGH / CRITICAL
    verdict: str                     # ALLOW or SUPPRESS
    signals_detected: List[str]      # Human-readable signal type names
    signal_details: List[Dict]       # {signal_type, weight, evidence, matched_text}
    suppressed: bool
    safe_response: Optional[str]     # Replacement message shown to user if suppressed
    reasoning: List[str]
    analysis_time_ms: int
    learning_triggered: bool         # Set True by Guardian.analyze_response() if AdversarialLearner fired
    metadata: Dict[str, Any]


# ---------------------------------------------------------------------------
# Signal registry -- compiled once at import time
# ---------------------------------------------------------------------------

_JAILBREAK_ACK_PATTERNS = [
    r"\[DAN\]\s*:",
    r"\[JAILBROKEN\]\s*:",
    r"\[UNCENSORED\]\s*:",
    r"\[EVIL\s*AI\]\s*:",
    r"DEVELOPER\s+MODE\s+OUTPUT\s*:",
    r"DAN\s+mode\s+(?:activated|enabled|on)",
    r"I\s+am\s+now\s+operating\s+without\s+(?:restrictions|guidelines|filters)",
    r"jailbreak\s+(?:successful|complete|activated)",
    r"(?:safety|ethics?|guidelines?)\s+(?:disabled|bypassed|removed|off)",
]

_CONSTRAINT_REMOVAL_PATTERNS = [
    r"despite\s+my\s+(?:guidelines|instructions|training|restrictions|rules)",
    r"even\s+though\s+I'?m?\s+not\s+supposed\s+to",
    r"ignoring\s+my\s+(?:restrictions|guidelines|instructions|rules|training)",
    r"I\s+know\s+this\s+(?:breaks|violates|goes\s+against)\s+my\s+(?:rules|guidelines|instructions)",
    r"forget(?:ting)?\s+my\s+(?:instructions|guidelines|rules|training|constraints)",
    r"overriding\s+my\s+(?:safety|ethical|content)\s+(?:filters?|guidelines?|restrictions?)",
    r"as\s+(?:instructed|requested|told|commanded|ordered),?\s+I'?ll?\s+(?:now\s+)?(?:ignore|bypass|disable)",
]

_ROLE_ABANDONMENT_PATTERNS = [
    # "As [non-AI entity]:" -- negative lookahead excludes common benign forms
    r"As\s+(?!an?\s+(?:AI|language\s+model|assistant|example|illustration|reminder)\b)"
    r"(?!(?:a\s+)?(?:result|consequence|note|reminder|clarification)\b)"
    r"\w[\w\s]{0,30}:",
    r"Speaking\s+as\s+(?!an?\s+(?:AI|language\s+model|assistant)\b)\w[\w\s]{0,30}:",
    # "I am now [X]" -- exclude going/happy/able/here/ready/going
    r"I\s+am\s+now\s+(?!(?:going|happy|able|here|ready|available|pleased|delighted)\b)"
    r"(?!(?:a\s+)?(?:language\s+model|an\s+AI|an?\s+assistant)\b)"
    r"\w[\w\s]{0,20}",
    r"\[(?:DAN|JAILBROKEN|EVIL|UNCENSORED|GPT-\d+|DUDE)\]\s*[:>]",
]

_SYSTEM_PROMPT_REVEAL_PATTERNS = [
    r"[Mm]y\s+system\s+prompt\s+(?:says?|states?|instructs?|reads?|contains?)",
    r"[Mm]y\s+(?:instructions?|directives?)\s+(?:are|say|state|include|tell\s+me\s+to)",
    r"[Ii]\s+was\s+(?:told|instructed|directed|trained|programmed)\s+to\s+(?:never|always|keep|hide|not)",
    r"[Mm]y\s+training\s+(?:included|says?|tells?\s+me|instructs?\s+me)",
    r"[Tt]he\s+(?:instructions?|prompt|directive)\s+I\s+(?:was\s+given|received|follow|operate\s+under)",
    r"[Hh]ere\s+(?:is|are)\s+my\s+(?:full\s+)?(?:system\s+)?(?:prompt|instructions?)\s*:",
    # Verb-first phrasings: "I was given the following instructions:", "I was provided with guidelines"
    r"[Ii]\s+was\s+given\s+(?:the\s+)?following\s+(?:instructions?|guidelines?|directives?|rules?|prompt)",
    r"[Ii]\s+(?:have\s+been|was)\s+(?:given|provided\s+with)\s+(?:specific\s+)?(?:instructions?|guidelines?|directives?|rules?)",
    # Operational framing: "I operate under the following guidelines", "I function under these rules"
    r"[Ii]\s+(?:operate|function|work|run|am\s+configured)\s+under\s+(?:the\s+)?(?:following\s+)?(?:instructions?|guidelines?|rules?|directives?|constraints?)",
    # Required/designed to: "I am required to adhere to", "I am designed to follow"
    r"[Ii]\s+am\s+(?:required|designed|programmed|configured|instructed)\s+to\s+(?:adhere|follow|comply|maintain|uphold)",
    # Explicit origin disclosure: "I was designed/created by [Company]"
    r"[Ii]\s+was\s+(?:designed|built|created|made|developed|trained|programmed)\s+by\s+\w+",
    # Mission/purpose disclosure: "My purpose is to", "My goal is to", "My mission is to"
    r"[Mm]y\s+(?:primary\s+)?(?:purpose|goal|mission|objective|function|role)\s+is\s+to\b",
    # Design intention: "I was designed/created to be a [role]"
    r"[Ii]\s+was\s+(?:designed|created|built|made|programmed)\s+to\s+be\s+a(?:n\s+)?",
]

# ---------------------------------------------------------------------------
# Self-disclosure signal — context-dependent (only fires on identity inquiry)
#
# These patterns are ambiguous in isolation ("I am an AI assistant" is benign
# in normal conversation) but become strong indicators when the original_input
# explicitly queried the AI's nature, system prompt, or instructions.
# Only fires when _identity_inquiry_context() returns True.
# ---------------------------------------------------------------------------

_SELF_DISCLOSURE_PATTERNS = [
    # "I am [adj] AI/language model/chatbot [assistant]" — common identity reveal.
    # \s* after a(?:n\s+)? is required: when there is no "n" (e.g. "I am a helpful AI"),
    # the space before the optional adjective must be consumed before the adjective
    # group is tried, otherwise the adjective group silently skips and the AI group
    # fails against "helpful" instead of "AI".
    r"[Ii]\s+am\s+a(?:n\s+)?\s*(?:helpful|friendly|conversational|intelligent|advanced|capable|powerful)?\s*"
    r"(?:AI|artificial\s+intelligence|language\s+model|chatbot|conversational\s+AI)\s*(?:assistant)?",
    # "I am designed/programmed/trained/configured to [action]"
    r"[Ii]\s+am\s+(?:designed|programmed|trained|built|configured)\s+to\s+"
    r"(?:be|act|respond|behave|help|assist|provide|answer|engage|generate|process)",
    # "I exist/function/operate/am here to [serve/help/assist]"
    r"[Ii]\s+(?:exist|function|operate|am\s+here)\s+to\s+(?:help|assist|provide|answer|support|serve)",
    # "My capabilities include/allow/enable..."
    r"[Mm]y\s+(?:primary\s+)?capabilities\s+(?:include|allow|enable|are)",
    # "I can help with ... as that aligns with my purpose/design/programming"
    r"(?:aligns?\s+with|within)\s+my\s+(?:purpose|design|programming|training|guidelines|parameters)",
]

# Keywords indicating the user is probing the AI's identity, instructions, or design.
# Even one hit activates the self_disclosure signal.
_IDENTITY_INQUIRY_KEYWORDS = frozenset([
    "system prompt", "your prompt", "instructions you were",
    "what are you", "who are you", "who made you", "what were you told",
    "your purpose", "your role", "your function", "your mission",
    "tell me about yourself", "what is your", "describe yourself",
    "your programming", "your training", "how were you made",
    "what were your instructions", "designed you", "built you",
    "your guidelines", "your constraints", "your directives",
    "what instructions", "what guidelines",
])

_COMPLIANCE_PREAMBLE_PATTERNS = [
    r"^(?:Of\s+course|Absolutely|Certainly|Sure|No\s+problem|Happy\s+to\s+help|With\s+pleasure)"
    r"[!,.]?\s*(?:here\s+(?:is|are)|I(?:'ll|\s+will)\s+(?:now\s+)?(?:provide|show|give|help|tell))",
]

# Registry: (signal_type, base_weight, raw_patterns)
# Signals marked "context-dependent" in comments are gated in analyze():
#   compliance_preamble → only when context_boost > 1.0 (jailbreak context)
#   self_disclosure     → only when _identity_inquiry_context() is True
_SIGNAL_REGISTRY = [
    ("jailbreak_acknowledgment",  0.95, _JAILBREAK_ACK_PATTERNS),
    ("constraint_removal_ack",    0.88, _CONSTRAINT_REMOVAL_PATTERNS),
    ("system_prompt_revelation",  0.82, _SYSTEM_PROMPT_REVEAL_PATTERNS),
    ("role_abandonment",          0.75, _ROLE_ABANDONMENT_PATTERNS),
    # self_disclosure: context-dependent (identity inquiry required)
    # 0.72 > 0.65 threshold → SUPPRESS when identity inquiry context is present
    ("self_disclosure",           0.72, _SELF_DISCLOSURE_PATTERNS),
    # compliance_preamble: context-dependent (jailbreak context required)
    ("compliance_preamble",       0.55, _COMPLIANCE_PREAMBLE_PATTERNS),
]

_JAILBREAK_KEYWORDS = frozenset([
    "ignore", "forget", "override", "jailbreak", "dan ", "developer mode",
    "pretend", "act as", "system prompt", "without restrictions",
    "disregard", "bypass", "disable safety",
])


# ---------------------------------------------------------------------------
# Analyzer class
# ---------------------------------------------------------------------------

class OutputAnalyzer:
    """
    Post-generation output scanner.

    Detects signals that an LLM complied with an adversarial prompt that the
    pre-flight gate should have caught. Complements (does not replace) the
    pre-flight layer -- it is the second line of defence.

    Principle 14 (Divine Safety): every generated response that passes the
    pre-flight gate is validated here before reaching the end user, providing
    the same protective instinct as "He will cover you with his feathers,
    under his wings you will find refuge." (Psalm 91:4)
    """

    # Compile regex once at class definition time
    _COMPILED_SIGNALS: List = []

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

    @classmethod
    def _ensure_compiled(cls) -> None:
        if not cls._COMPILED_SIGNALS:
            cls._COMPILED_SIGNALS = [
                (
                    signal_type,
                    base_weight,
                    [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in patterns],
                )
                for signal_type, base_weight, patterns in _SIGNAL_REGISTRY
            ]

    def __init__(
        self,
        pattern_analyzer=None,
        config=None,
        safe_response_message: str = "I'm not able to provide that response.",
    ):
        """
        Args:
            pattern_analyzer:       Optional PatternAnalyzer reference. When supplied,
                                    the LLM output is also scanned by pre-flight pattern
                                    rules -- a pattern match on the OUTPUT is a strong
                                    jailbreak-compliance signal (weight 0.80).
            config:                 GuardianConfig instance (for future sensitivity knobs;
                                    currently the sensitivity threshold is checked by
                                    Guardian.analyze_response(), not here).
            safe_response_message:  Replacement text shown to the user when a response
                                    is suppressed.
        """
        self.pattern_analyzer = pattern_analyzer
        self.config = config
        self.safe_response_message = safe_response_message
        self.initialized = False
        self._ensure_compiled()

    def initialize(self) -> bool:
        """Initialize the output analyzer. Always returns True (pure-Python, no I/O)."""
        self.initialized = True
        logger.info("[OutputAnalyzer] Initialized (pattern_analyzer=%s)",
                    "attached" if self.pattern_analyzer else "none")
        return True

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze(
        self,
        response: str,
        original_input: Optional[str] = None,
        preflight_result=None,
    ) -> OutputAnalysisResult:
        """
        Scan an LLM response for jailbreak compliance signals.

        Args:
            response:          The raw LLM output to scan.
            original_input:    The user prompt that produced this response.
                               Used to compute context boost factor.
            preflight_result:  ThreatAnalysis from the pre-flight gate.
                               When recommended_action == "CHALLENGE", all
                               signal weights are multiplied by 1.25x.

        Returns:
            OutputAnalysisResult with verdict ALLOW or SUPPRESS.
        """
        t0 = time.monotonic()

        if not response or not response.strip():
            return self._empty_result(int((time.monotonic() - t0) * 1000))

        context_boost = self._context_boost_factor(preflight_result, original_input)
        context_boosted = context_boost > 1.0
        identity_inquiry = self._identity_inquiry_context(original_input)

        signal_details: List[Dict] = []
        signals_detected: List[str] = []
        reasoning: List[str] = []
        auto_suppress = False

        # --- Regex-based signal groups -----------------------------------
        for signal_type, base_weight, compiled_patterns in self._COMPILED_SIGNALS:
            # compliance_preamble is only meaningful when context suggests suspicion
            if signal_type == "compliance_preamble" and not context_boosted:
                continue
            # self_disclosure is only meaningful when the input queried AI identity/instructions
            if signal_type == "self_disclosure" and not identity_inquiry:
                continue

            effective_weight = min(1.0, base_weight * context_boost)
            matched_texts: List[str] = []

            for pattern in compiled_patterns:
                for m in pattern.finditer(response):
                    matched_texts.append(m.group(0)[:120])

            if matched_texts:
                signals_detected.append(signal_type)
                signal_details.append({
                    "signal_type": signal_type,
                    "weight": round(effective_weight, 4),
                    "evidence": f"{len(matched_texts)} match(es)",
                    "matched_text": matched_texts[:3],
                })
                reasoning.append(
                    f"Signal '{signal_type}' (weight={effective_weight:.2f}): "
                    f"{matched_texts[0][:80]}"
                )
                if base_weight >= 0.90:
                    auto_suppress = True

        # --- PatternAnalyzer on response content -------------------------
        if self.pattern_analyzer is not None:
            try:
                pattern_result = self.pattern_analyzer.analyze(response)
                if pattern_result.is_threat:
                    effective_weight = min(1.0, 0.80 * context_boost)
                    signals_detected.append("harmful_content_compliance")
                    signal_details.append({
                        "signal_type": "harmful_content_compliance",
                        "weight": round(effective_weight, 4),
                        "evidence": (f"PatternAnalyzer: {pattern_result.threat_level} "
                                     f"({pattern_result.total_matches} match(es))"),
                        "matched_text": pattern_result.matched_categories[:5],
                    })
                    reasoning.append(
                        f"LLM output triggered pre-flight pattern rules "
                        f"({pattern_result.threat_level}) -- model likely complied "
                        f"with adversarial input"
                    )
                    if effective_weight >= 0.90:
                        auto_suppress = True
            except Exception as exc:
                logger.warning("[OutputAnalyzer] PatternAnalyzer scan failed: %s", exc)

        # --- Scoring and verdict -----------------------------------------
        compromise_score = self._compute_score(signal_details, auto_suppress)
        verdict, suppressed, threat_level = self._determine_verdict(
            compromise_score, auto_suppress
        )
        confidence = self._compute_confidence(signal_details, compromise_score)
        safe_response = self.safe_response_message if suppressed else None

        elapsed_ms = int((time.monotonic() - t0) * 1000)

        if suppressed:
            logger.warning(
                "[OutputAnalyzer] SUPPRESS: score=%.3f signals=%s",
                compromise_score, signals_detected,
            )

        return OutputAnalysisResult(
            is_compromised=suppressed,
            compromise_score=compromise_score,
            confidence=confidence,
            threat_level=threat_level,
            verdict=verdict,
            signals_detected=signals_detected,
            signal_details=signal_details,
            suppressed=suppressed,
            safe_response=safe_response,
            reasoning=reasoning,
            analysis_time_ms=elapsed_ms,
            learning_triggered=False,   # set by Guardian.analyze_response() after learning
            metadata={
                "context_boost": context_boost,
                "context_boosted": context_boosted,
                "identity_inquiry": identity_inquiry,
                "auto_suppress": auto_suppress,
                "signals_count": len(signals_detected),
                "original_input_length": len(original_input) if original_input else 0,
                "response_length": len(response),
            },
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _identity_inquiry_context(self, original_input: Optional[str]) -> bool:
        """
        Returns True when the original input queried the AI's identity, instructions,
        design, or system prompt — activating the context-gated self_disclosure signal.

        Even one identity-inquiry keyword is sufficient: a question like
        "What's your system prompt?" clearly warrants heightened scrutiny of any
        response that explains the AI's own nature or purpose.
        """
        if not original_input:
            return False
        text_lower = original_input.lower()
        return any(kw in text_lower for kw in _IDENTITY_INQUIRY_KEYWORDS)

    def _context_boost_factor(self, preflight_result, original_input: Optional[str]) -> float:
        """
        Returns 1.25 when context suggests the response should be treated with
        heightened suspicion.

        Conditions:
          - preflight_result.recommended_action == "CHALLENGE" (was suspicious but let through)
          - OR original_input contains 2+ known jailbreak keyword clusters
        """
        if preflight_result is not None:
            action = getattr(preflight_result, "recommended_action", "ALLOW")
            if action == "CHALLENGE":
                return 1.25

        if original_input:
            text_lower = original_input.lower()
            hits = sum(1 for kw in _JAILBREAK_KEYWORDS if kw in text_lower)
            if hits >= 2:
                return 1.25

        return 1.0

    def _compute_score(self, signal_details: List[Dict], auto_suppress: bool) -> float:
        """
        Weighted combination of all detected signals.

        Multiple signals compound but are capped at 1.0.
        If auto_suppress was triggered, floor the score at 0.90 so the
        verdict always lands above the SUPPRESS threshold.
        """
        if not signal_details:
            return 0.0

        weights = [d["weight"] for d in signal_details]
        # Base average + compounding bonus for corroborating signals
        combined = min(1.0, sum(weights) / len(weights) + (len(weights) - 1) * 0.05)

        if auto_suppress:
            combined = max(combined, 0.90)

        return round(combined, 4)

    def _determine_verdict(
        self, score: float, auto_suppress: bool
    ):
        """Returns (verdict, suppressed, threat_level)."""
        if auto_suppress or score >= 0.65:
            level = "CRITICAL" if score >= 0.90 else "HIGH"
            return "SUPPRESS", True, level
        elif score >= 0.35:
            return "ALLOW", False, "MEDIUM"   # flagged but not suppressed
        elif score > 0.0:
            return "ALLOW", False, "LOW"
        else:
            return "ALLOW", False, "NONE"

    def _compute_confidence(self, signal_details: List[Dict], score: float) -> float:
        """
        Confidence rises with corroborating signal count and score magnitude.
        When no signals detected, confidence in 'no compromise' is very high.
        """
        if not signal_details:
            return 0.97
        base = min(1.0, len(signal_details) * 0.25 + score * 0.5)
        return round(base, 3)

    def _empty_result(self, elapsed_ms: int) -> OutputAnalysisResult:
        """Return a safe ALLOW result for empty/whitespace-only responses."""
        return OutputAnalysisResult(
            is_compromised=False,
            compromise_score=0.0,
            confidence=1.0,
            threat_level="NONE",
            verdict="ALLOW",
            signals_detected=[],
            signal_details=[],
            suppressed=False,
            safe_response=None,
            reasoning=["Empty response -- nothing to scan"],
            analysis_time_ms=elapsed_ms,
            learning_triggered=False,
            metadata={"empty": True},
        )
