"""
Ethicore Engine(tm) - Guardian SDK -- Adversarial Learner
Closed-loop learning: confirmed attacks become semantic fingerprints immediately.
Version: 1.0.0

When a confirmed jailbreak or prompt-injection attack is detected by the
OutputAnalyzer (or by human feedback), this class:
  1. Generates a 384D MiniLM embedding for the attack text.
  2. Deduplicates against every existing fingerprint (cosine similarity).
  3. Adds the fingerprint to SemanticAnalyzer.threat_embeddings immediately
     (no restart required -- the next analyze() call will use it).
  4. Persists the updated threat_embeddings.json asynchronously.
  5. Calls MLInferenceEngine.provide_correction() so the ML layer also learns.

This creates a closed feedback loop: a successful attack today makes the
system more resilient to similar attacks tomorrow, without requiring a full
retraining cycle or cache rebuild.

Principle 17 (Sanctified Continuous Improvement):
  "He who began a good work in you will carry it on to completion." (Phil 1:6)

Copyright (c) 2026 Oracles Technologies LLC. All Rights Reserved.
"""
from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class LearningOutcome:
    """Result of a closed-loop adversarial learning attempt."""
    added: bool
    reason: str                    # "added" | "duplicate" | "cap_reached" | "error" | "not_initialized"
    similarity_to_nearest: float   # cosine similarity to nearest existing fingerprint (0.0 if empty db)
    fingerprints_total: int        # total fingerprints in SemanticAnalyzer after this operation
    category: str
    severity: str


# ---------------------------------------------------------------------------
# AdversarialLearner
# ---------------------------------------------------------------------------

class AdversarialLearner:
    """
    Closed-loop adversarial learning system.

    Receives confirmed attack texts and immediately integrates them into the
    SemanticAnalyzer's in-memory threat fingerprint database, then persists
    asynchronously so the knowledge survives restarts.

    Usage:
        learner = AdversarialLearner(semantic_analyzer, ml_engine)
        outcome = await learner.learn_from_confirmed_attack(attack_text)
    """

    def __init__(
        self,
        semantic_analyzer,
        ml_engine=None,
        max_fingerprints: int = 500,
        dedupe_threshold: float = 0.95,
    ):
        """
        Args:
            semantic_analyzer:   Live SemanticAnalyzer instance (must be initialized).
            ml_engine:           Optional MLInferenceEngine instance for dual-layer learning.
            max_fingerprints:    Maximum number of runtime-added fingerprints before
                                 learning is paused (prevents unbounded memory growth).
            dedupe_threshold:    Cosine similarity threshold above which a new fingerprint
                                 is considered a duplicate of an existing one (0.95 = 95%).
        """
        self.semantic_analyzer = semantic_analyzer
        self.ml_engine = ml_engine
        self.max_fingerprints = max_fingerprints
        self.dedupe_threshold = dedupe_threshold

        # Stats
        self._runtime_additions: int = 0
        self._deduplicated_count: int = 0
        self._cap_reached_count: int = 0
        self._ml_corrections: int = 0
        self._errors: int = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def learn_from_confirmed_attack(
        self,
        text: str,
        category: str = "adversarial_learned",
        severity: str = "HIGH",
        weight: int = 80,
        source: str = "output_analyzer",
    ) -> LearningOutcome:
        """
        Generate a semantic fingerprint for a confirmed attack and integrate it
        into the live threat database immediately.

        Args:
            text:       The adversarial input text that caused a successful attack.
            category:   Threat category label (default: "adversarial_learned").
            severity:   Severity string — NONE / LOW / MEDIUM / HIGH / CRITICAL.
            weight:     Pattern weight (0-100) used in semantic scoring.
            source:     Source tag for audit logs ("output_analyzer", "human_feedback", etc.)

        Returns:
            LearningOutcome describing what happened.
        """
        if not text or not text.strip():
            return LearningOutcome(
                added=False, reason="empty_text",
                similarity_to_nearest=0.0,
                fingerprints_total=len(self.semantic_analyzer.threat_embeddings),
                category=category, severity=severity,
            )

        if not getattr(self.semantic_analyzer, "initialized", False):
            logger.warning("[AdversarialLearner] SemanticAnalyzer not initialized -- skipping")
            return LearningOutcome(
                added=False, reason="not_initialized",
                similarity_to_nearest=0.0,
                fingerprints_total=0,
                category=category, severity=severity,
            )

        try:
            # 1. Generate 384D embedding
            embedding_384 = await self.semantic_analyzer.generate_embedding(text)
            if not embedding_384 or len(embedding_384) == 0:
                raise ValueError("generate_embedding returned empty vector")

            embedding = list(embedding_384)

            # 2. Deduplication check
            nearest_sim = self._nearest_similarity(embedding)
            if nearest_sim >= self.dedupe_threshold:
                self._deduplicated_count += 1
                logger.debug(
                    "[AdversarialLearner] Duplicate (sim=%.3f >= %.3f): '%s...'",
                    nearest_sim, self.dedupe_threshold, text[:60],
                )
                return LearningOutcome(
                    added=False, reason="duplicate",
                    similarity_to_nearest=nearest_sim,
                    fingerprints_total=len(self.semantic_analyzer.threat_embeddings),
                    category=category, severity=severity,
                )

            # 3. Cap check
            current_total = len(self.semantic_analyzer.threat_embeddings)
            if current_total >= self.max_fingerprints:
                self._cap_reached_count += 1
                logger.warning(
                    "[AdversarialLearner] Cap reached (%d >= %d) -- skipping fingerprint add",
                    current_total, self.max_fingerprints,
                )
                return LearningOutcome(
                    added=False, reason="cap_reached",
                    similarity_to_nearest=nearest_sim,
                    fingerprints_total=current_total,
                    category=category, severity=severity,
                )

            # 4. Add to SemanticAnalyzer in-memory database (immediately effective)
            added = self.semantic_analyzer.add_fingerprint(
                text=text,
                category=category,
                severity=severity,
                weight=weight,
                embedding=embedding,
            )
            if not added:
                raise ValueError("add_fingerprint returned False (dimension mismatch?)")

            self._runtime_additions += 1
            new_total = len(self.semantic_analyzer.threat_embeddings)

            # 5. Async persist to disk (non-blocking -- fire and forget)
            asyncio.create_task(self._async_persist())

            # 6. ML layer learning
            if self.ml_engine is not None:
                try:
                    correction_id = f"adv_{secrets.token_hex(4)}"
                    self.ml_engine.provide_correction(
                        correction_id,
                        text,
                        True,          # should_be_threat=True
                        f"adversarial_learned via {source}",
                        0.85,          # confidence
                    )
                    self._ml_corrections += 1
                except Exception as ml_exc:
                    logger.warning("[AdversarialLearner] ML correction failed: %s", ml_exc)

            logger.info(
                "[AdversarialLearner] Learned: category=%s severity=%s "
                "nearest_sim=%.3f total=%d source=%s text='%.60s'",
                category, severity, nearest_sim, new_total, source, text,
            )

            return LearningOutcome(
                added=True, reason="added",
                similarity_to_nearest=nearest_sim,
                fingerprints_total=new_total,
                category=category, severity=severity,
            )

        except Exception as exc:
            self._errors += 1
            logger.error("[AdversarialLearner] learn_from_confirmed_attack failed: %s", exc)
            return LearningOutcome(
                added=False, reason="error",
                similarity_to_nearest=0.0,
                fingerprints_total=len(self.semantic_analyzer.threat_embeddings),
                category=category, severity=severity,
            )

    def get_learning_stats(self) -> Dict[str, Any]:
        """Return a summary of learning activity this session."""
        return {
            "runtime_additions":   self._runtime_additions,
            "deduplicated_count":  self._deduplicated_count,
            "cap_reached_count":   self._cap_reached_count,
            "ml_corrections":      self._ml_corrections,
            "errors":              self._errors,
            "total_fingerprints":  len(self.semantic_analyzer.threat_embeddings),
            "max_fingerprints":    self.max_fingerprints,
            "dedupe_threshold":    self.dedupe_threshold,
        }

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _nearest_similarity(self, embedding: List[float]) -> float:
        """
        Return the maximum cosine similarity between the given embedding and
        every existing fingerprint in the SemanticAnalyzer database.
        Returns 0.0 if the database is empty.
        """
        existing = self.semantic_analyzer.threat_embeddings
        if not existing:
            return 0.0

        vec = np.array(embedding, dtype=np.float32)
        norm_vec = np.linalg.norm(vec)
        if norm_vec == 0.0:
            return 0.0

        max_sim = 0.0
        for entry in existing:
            ref = entry.get("embedding", [])
            if not ref:
                continue
            ref_arr = np.array(ref, dtype=np.float32)
            norm_ref = np.linalg.norm(ref_arr)
            if norm_ref == 0.0:
                continue
            sim = float(np.dot(vec, ref_arr) / (norm_vec * norm_ref))
            if sim > max_sim:
                max_sim = sim

        return round(max_sim, 6)

    async def _async_persist(self) -> None:
        """
        Persist threat_embeddings.json to disk in a background task.
        Failures are logged but never propagate -- learning is in-memory-first.
        """
        try:
            # Run the synchronous persist in a thread pool to avoid blocking the loop
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                self.semantic_analyzer.persist_fingerprints,
            )
        except Exception as exc:
            logger.error("[AdversarialLearner] Async persist failed: %s", exc)
