"""LangGraph adapter: replaces conditional edges with pressure-field routing.

Uses StigmergyScheduler internally for tick loops, dependency resolution,
and error recovery. The adapter maps LangGraph node functions to the
scheduler's dispatch contract.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, TypedDict

from stigmergy import StigmergyScheduler, TaskSpec, DispatchResult

try:
    from langgraph.graph import StateGraph, END
    from langgraph.graph.state import CompiledStateGraph
except ImportError as e:
    raise ImportError(
        "langgraph is required: pip install stigmergy-langgraph"
    ) from e


class PressureState(TypedDict):
    """Default state schema for stigmergy-routed LangGraph graphs."""
    messages: list[dict[str, Any]]
    completed_tasks: list[str]
    pending_tasks: list[str]
    outputs: dict[str, Any]


class StigmergyRouter:
    """Pressure-field router for LangGraph.

    Instead of writing conditional edge functions that grow into
    unmanageable if/else trees, register agents and tasks with
    dependencies. The router uses stigmergy signals to decide
    which agent nodes to invoke next.

    Example::

        router = StigmergyRouter(wake_threshold=0.4)
        router.register_agent("writer", writer_node_fn)
        router.register_agent("reviewer", reviewer_node_fn)

        router.add_task("draft", agent="writer", priority=0.8)
        router.add_task("review", agent="reviewer", deps=["draft"])

        graph = router.build_graph(PressureState)
        result = graph.invoke(initial_state)
    """

    def __init__(
        self,
        wake_threshold: float = 0.4,
        decay_half_life: float = 300.0,
        evaporation_threshold: float = 0.01,
    ):
        self.wake_threshold = wake_threshold
        self.decay_half_life = decay_half_life
        self.evaporation_threshold = evaporation_threshold
        self._agents: dict[str, Callable] = {}
        self._task_defs: list[dict[str, Any]] = []

    def register_agent(self, name: str, node_fn: Callable) -> None:
        """Register an agent with its LangGraph node function.

        The node function signature must match LangGraph's node contract:
        ``(state: dict) -> dict`` returning partial state updates.
        """
        self._agents[name] = node_fn

    def add_task(
        self,
        task_id: str,
        agent: str,
        priority: float = 0.5,
        deps: list[str] | None = None,
        description: str = "",
    ) -> None:
        """Add a task to the scheduling graph.

        Args:
            task_id: Unique identifier for this task.
            agent: Name of the registered agent to handle this task.
            priority: Signal intensity (0.0-1.0). Higher = more urgent.
            deps: Task IDs that must complete before this task can run.
            description: Human-readable task description.
        """
        if agent not in self._agents:
            raise ValueError(f"Agent '{agent}' not registered. Call register_agent first.")
        self._task_defs.append({
            "id": task_id,
            "agent": agent,
            "priority": priority,
            "deps": deps or [],
            "description": description or task_id,
        })

    def build_graph(self, state_schema: type = PressureState) -> CompiledStateGraph:
        """Build a compiled LangGraph StateGraph with stigmergy routing.

        Returns a compiled graph that can be invoked with ``graph.invoke(state)``.
        """
        agents = dict(self._agents)
        task_defs = list(self._task_defs)

        def _orchestrator(state: dict) -> dict:
            """Central routing node: runs StigmergyScheduler to dispatch tasks."""
            completed = list(state.get("completed_tasks", []))
            outputs = dict(state.get("outputs", {}))

            # Build a fresh scheduler for this invocation
            scheduler = StigmergyScheduler(
                tick_interval=0.01,
                wake_threshold=self.wake_threshold,
                decay_half_life=self.decay_half_life,
                evaporation_threshold=self.evaporation_threshold,
            )

            # Wire dispatcher to call LangGraph node functions
            async def dispatch(agent_id: str, task: TaskSpec) -> DispatchResult:
                node_fn = agents[agent_id]
                task_state = {
                    **state,
                    "_current_task": task.id,
                    "_task_description": task.description,
                }
                try:
                    result = node_fn(task_state)
                    if isinstance(result, dict):
                        outputs[task.id] = result.get("output", result)
                    return DispatchResult(success=True, output=result)
                except Exception as exc:
                    return DispatchResult(success=False, error=str(exc))

            scheduler.set_dispatcher(dispatch)

            async def _run() -> None:
                # Add only tasks not already completed
                completed_set = set(completed)
                for td in task_defs:
                    if td["id"] in completed_set:
                        continue
                    await scheduler.add_task(TaskSpec(
                        id=td["id"],
                        description=td["description"],
                        agent_id=td["agent"],
                        priority=td["priority"],
                        dependencies=[d for d in td["deps"] if d not in completed_set],
                    ))
                if not scheduler._tasks:
                    return  # All tasks already completed
                # Pre-mark already-completed tasks
                scheduler._completed = set(completed_set & set(scheduler._tasks.keys()))
                await scheduler.run()

            # Run in whatever event loop context we're in
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop and loop.is_running():
                # We're inside an async context (e.g. async LangGraph)
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    pool.submit(lambda: asyncio.run(_run())).result()
            else:
                asyncio.run(_run())

            all_completed = list(scheduler._completed | set(completed))
            remaining = [td["id"] for td in task_defs if td["id"] not in all_completed]

            return {
                "completed_tasks": all_completed,
                "pending_tasks": remaining,
                "outputs": outputs,
            }

        def _router(state: dict) -> str:
            completed = set(state.get("completed_tasks", []))
            all_task_ids = {td["id"] for td in task_defs}
            if all_task_ids <= completed:
                return "__end__"
            # Check if any remaining tasks can still run
            remaining = [td for td in task_defs if td["id"] not in completed]
            has_runnable = any(
                all(d in completed for d in td["deps"])
                for td in remaining
            )
            return "orchestrator" if has_runnable else "__end__"

        builder = StateGraph(state_schema)
        builder.add_node("orchestrator", _orchestrator)
        builder.set_entry_point("orchestrator")
        builder.add_conditional_edges(
            "orchestrator",
            _router,
            {"orchestrator": "orchestrator", "__end__": END},
        )
        return builder.compile()
