"""Stigmergy pressure-field scheduling adapter for LangGraph.

Replaces LangGraph's conditional edge routing with pressure-based scheduling.
Agents wake when accumulated signal pressure crosses a threshold — no hardcoded
routing functions needed.

Usage:
    from stigmergy_langgraph import StigmergyRouter, PressureState

    router = StigmergyRouter(wake_threshold=0.4, decay_half_life=300)
    router.register_agent("writer", writer_node)
    router.register_agent("reviewer", reviewer_node)

    router.add_task("draft", agent="writer", priority=0.8)
    router.add_task("review", agent="reviewer", priority=0.6, deps=["draft"])

    graph = router.build_graph(PressureState)
    result = graph.invoke({"messages": []})
"""

from stigmergy_langgraph.adapter import StigmergyRouter, PressureState

__all__ = ["StigmergyRouter", "PressureState"]
