"""Tests for LangGraph adapter — mocks LangGraph to test scheduling logic."""

import sys
from types import ModuleType
from unittest.mock import MagicMock

import pytest

# Mock langgraph before importing adapter
_mock_langgraph = ModuleType("langgraph")
_mock_graph = ModuleType("langgraph.graph")
_mock_state = ModuleType("langgraph.graph.state")
_mock_types = ModuleType("langgraph.types")

END = "__end__"
_mock_graph.END = END
_mock_graph.StateGraph = None  # Will be replaced below


class _MockCompiledGraph:
    def __init__(self, nodes, entry, edges):
        self._nodes = nodes
        self._entry = entry
        self._edges = edges

    def invoke(self, state):
        current = self._entry
        while current != END:
            node_fn = self._nodes[current]
            state = {**state, **node_fn(state)}
            router = self._edges.get(current)
            if router:
                route_fn, mapping = router
                dest = route_fn(state)
                current = mapping.get(dest, END)
            else:
                current = END
        return state


class _MockStateGraph:
    def __init__(self, state_schema):
        self._nodes = {}
        self._entry = None
        self._edges = {}

    def add_node(self, name, fn):
        self._nodes[name] = fn

    def set_entry_point(self, name):
        self._entry = name

    def add_conditional_edges(self, source, route_fn, mapping):
        self._edges[source] = (route_fn, mapping)

    def compile(self):
        return _MockCompiledGraph(self._nodes, self._entry, self._edges)


_mock_graph.StateGraph = _MockStateGraph
_mock_state.CompiledStateGraph = _MockCompiledGraph

sys.modules["langgraph"] = _mock_langgraph
sys.modules["langgraph.graph"] = _mock_graph
sys.modules["langgraph.graph.state"] = _mock_state
sys.modules["langgraph.types"] = _mock_types

from stigmergy_langgraph import StigmergyRouter, PressureState


def test_single_task():
    router = StigmergyRouter(wake_threshold=0.3)
    router.register_agent("writer", lambda state: {"output": "written"})
    router.add_task("draft", agent="writer", priority=0.8)

    graph = router.build_graph(PressureState)
    result = graph.invoke({
        "messages": [],
        "completed_tasks": [],
        "pending_tasks": ["draft"],
        "outputs": {},
    })

    assert "draft" in result["completed_tasks"]
    assert result["pending_tasks"] == []


def test_dependency_ordering():
    order = []

    def writer(state):
        order.append("draft")
        return {"output": "written"}

    def reviewer(state):
        order.append("review")
        return {"output": "reviewed"}

    router = StigmergyRouter(wake_threshold=0.3)
    router.register_agent("writer", writer)
    router.register_agent("reviewer", reviewer)

    router.add_task("draft", agent="writer", priority=0.8)
    router.add_task("review", agent="reviewer", priority=0.6, deps=["draft"])

    graph = router.build_graph(PressureState)
    result = graph.invoke({
        "messages": [],
        "completed_tasks": [],
        "pending_tasks": ["draft", "review"],
        "outputs": {},
    })

    assert order.index("draft") < order.index("review")
    assert set(result["completed_tasks"]) == {"draft", "review"}


def test_outputs_captured():
    router = StigmergyRouter(wake_threshold=0.3)
    router.register_agent("bot", lambda state: {"output": "hello world"})
    router.add_task("greet", agent="bot", priority=0.8)

    graph = router.build_graph(PressureState)
    result = graph.invoke({
        "messages": [],
        "completed_tasks": [],
        "pending_tasks": ["greet"],
        "outputs": {},
    })

    assert "greet" in result["outputs"]


def test_unregistered_agent_raises():
    router = StigmergyRouter()
    with pytest.raises(ValueError, match="not registered"):
        router.add_task("t1", agent="ghost", priority=0.5)


def test_already_completed_tasks_skipped():
    call_count = 0

    def writer(state):
        nonlocal call_count
        call_count += 1
        return {"output": "written"}

    router = StigmergyRouter(wake_threshold=0.3)
    router.register_agent("writer", writer)
    router.add_task("draft", agent="writer", priority=0.8)

    graph = router.build_graph(PressureState)
    result = graph.invoke({
        "messages": [],
        "completed_tasks": ["draft"],  # already done
        "pending_tasks": [],
        "outputs": {},
    })

    assert call_count == 0
    assert "draft" in result["completed_tasks"]
