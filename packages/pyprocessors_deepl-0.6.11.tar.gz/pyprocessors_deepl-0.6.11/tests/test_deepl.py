import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from dirty_equals import HasAttributes, HasLen, IsList, IsPartialDict
from pymultirole_plugins.v1.schema import AltText, Document, DocumentList, Sentence

from pyprocessors_deepl.deepl import (
    DeepLParameters,
    DeepLProcessor,
    Formality,
    TargetLang,
    document_language,
)

requires_deepl_api_key = pytest.mark.skipif(
    not os.environ.get("DEEPL_API_KEY"),
    reason="DEEPL_API_KEY environment variable not set",
)


def test_deepl_basic():
    model = DeepLProcessor.get_model()
    model_class = model.model_construct().__class__
    assert model_class == DeepLParameters


def test_parameters_defaults():
    params = DeepLParameters(target_lang=TargetLang.FR)
    assert params.target_lang == TargetLang.FR
    assert params.formality == Formality.default
    assert params.as_altText is None


def test_parameters_all_fields():
    params = DeepLParameters(target_lang=TargetLang.DE, formality=Formality.more, as_altText="translation")
    assert params.target_lang == TargetLang.DE
    assert params.formality == Formality.more
    assert params.as_altText == "translation"


def test_target_lang_values():
    assert TargetLang.EN_GB == "EN-GB"
    assert TargetLang.EN_US == "EN-US"
    assert TargetLang.PT_BR == "PT-BR"
    assert TargetLang.PT_PT == "PT-PT"
    assert TargetLang.ZH == "ZH"


def test_formality_values():
    assert Formality.default == "default"
    assert Formality.more == "more"
    assert Formality.less == "less"
    assert Formality.prefer_more == "prefer_more"
    assert Formality.prefer_less == "prefer_less"


def test_document_language():
    doc = Document(text="hello", metadata={"language": "en"})
    assert document_language(doc, None) == "en"


def test_document_language_missing():
    doc = Document(text="hello", metadata={})
    assert document_language(doc, None) is None


def test_document_language_default():
    doc = Document(text="hello", metadata={})
    assert document_language(doc, "fr") == "fr"


def test_document_language_no_metadata():
    doc = Document(text="hello")
    assert document_language(doc, "de") == "de"


def _make_mock_translator(translated_texts):
    """Create a mock translator returning the given texts."""
    translator = MagicMock()

    def translate_side_effect(_text, **_kwargs):
        if isinstance(_text, list):
            return [MagicMock(text=t) for t in translated_texts]
        return MagicMock(text=translated_texts[0] if translated_texts else _text)

    translator.translate_text.side_effect = translate_side_effect
    return translator


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_simple_text(mock_get_translator):
    mock_get_translator.return_value = _make_mock_translator(["Bonjour le monde"])

    doc = Document(text="Hello world", metadata={"language": "en"})
    params = DeepLParameters(target_lang=TargetLang.FR)
    processor = DeepLProcessor()
    results = processor.process([doc], params)

    assert len(results) == 1
    assert results[0].text == "Bonjour le monde"
    assert results[0].metadata["language"] == "fr"
    assert results[0].annotations is None
    assert results[0].categories is None


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_with_title(mock_get_translator):
    call_count = 0

    def translate_side_effect(_text, **_kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return MagicMock(text="Titre traduit")
        return MagicMock(text="Texte traduit")

    translator = MagicMock()
    translator.translate_text.side_effect = translate_side_effect
    mock_get_translator.return_value = translator

    doc = Document(text="Some text", title="A title", metadata={"language": "en"})
    params = DeepLParameters(target_lang=TargetLang.FR)
    processor = DeepLProcessor()
    results = processor.process([doc], params)

    assert results[0].title == "Titre traduit"
    assert results[0].text == "Texte traduit"


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_with_sentences(mock_get_translator):
    mock_get_translator.return_value = _make_mock_translator(["Bonjour.", "Le monde."])

    doc = Document(
        text="Hello. World.",
        metadata={"language": "en"},
        sentences=[
            Sentence(start=0, end=6, metadata={"language": "en"}),
            Sentence(start=7, end=13, metadata={"language": "en"}),
        ],
    )
    params = DeepLParameters(target_lang=TargetLang.FR)
    processor = DeepLProcessor()
    results = processor.process([doc], params)

    assert results[0].metadata["language"] == "fr"
    assert len(results[0].sentences) == 2
    assert results[0].text == "Bonjour.\nLe monde.\n"
    # Sentence offsets should match the new translated text
    s0 = results[0].sentences[0]
    s1 = results[0].sentences[1]
    assert results[0].text[s0.start : s0.end] == "Bonjour.\n"
    assert results[0].text[s1.start : s1.end] == "Le monde.\n"


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_as_alttext(mock_get_translator):
    mock_get_translator.return_value = _make_mock_translator(["Bonjour le monde"])

    doc = Document(text="Hello world", metadata={"language": "en"})
    params = DeepLParameters(target_lang=TargetLang.FR, as_altText="translation")
    processor = DeepLProcessor()
    results = processor.process([doc], params)

    # Original text should be unchanged
    assert results[0].text == "Hello world"
    assert results[0].metadata["language"] == "en"
    # Alt text should be set
    assert len(results[0].altTexts) == 1
    assert results[0].altTexts[0].name == "translation"
    assert results[0].altTexts[0].text == "Bonjour le monde"


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_as_alttext_replaces_existing(mock_get_translator):
    mock_get_translator.return_value = _make_mock_translator(["Nuevo texto"])

    doc = Document(
        text="Hello world",
        metadata={"language": "en"},
        altTexts=[AltText(name="translation", text="Old translation")],
    )
    params = DeepLParameters(target_lang=TargetLang.ES, as_altText="translation")
    processor = DeepLProcessor()
    results = processor.process([doc], params)

    # Should replace the existing alt text with same name
    assert len(results[0].altTexts) == 1
    assert results[0].altTexts[0].name == "translation"
    assert results[0].altTexts[0].text == "Nuevo texto"


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_as_alttext_with_title(mock_get_translator):
    call_count = 0

    def translate_side_effect(_text, **_kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return MagicMock(text="Titre")
        return MagicMock(text="Corps")

    translator = MagicMock()
    translator.translate_text.side_effect = translate_side_effect
    mock_get_translator.return_value = translator

    doc = Document(text="Body", title="Title", metadata={"language": "en"})
    params = DeepLParameters(target_lang=TargetLang.FR, as_altText="tr")
    processor = DeepLProcessor()
    results = processor.process([doc], params)

    # Alt text should include title + newline + body
    assert results[0].altTexts[0].text == "Titre\nCorps"


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_unsupported_language(mock_get_translator):
    mock_get_translator.return_value = MagicMock()

    doc = Document(text="Hello", metadata={"language": "xx"})
    params = DeepLParameters(target_lang=TargetLang.FR)
    processor = DeepLProcessor()

    with pytest.raises(AttributeError, match="Metadata language xx"):
        processor.process([doc], params)


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_missing_language(mock_get_translator):
    mock_get_translator.return_value = MagicMock()

    doc = Document(text="Hello", metadata={})
    params = DeepLParameters(target_lang=TargetLang.FR)
    processor = DeepLProcessor()

    with pytest.raises(AttributeError, match="Metadata language None"):
        processor.process([doc], params)


@patch("pyprocessors_deepl.deepl.get_translator")
def test_process_multiple_documents(mock_get_translator):
    mock_get_translator.return_value = _make_mock_translator(["Traduit"])

    docs = [
        Document(text="Text 1", metadata={"language": "en"}),
        Document(text="Text 2", metadata={"language": "en"}),
    ]
    params = DeepLParameters(target_lang=TargetLang.FR)
    processor = DeepLProcessor()
    results = processor.process(docs, params)

    assert len(results) == 2
    for doc in results:
        assert doc.metadata["language"] == "fr"


@requires_deepl_api_key
def test_deepl():
    testdir = Path(__file__).parent
    source = Path(
        testdir,
        "data/from.json",
    )

    with source.open("r") as fin:
        jdocs = json.load(fin)
        docs = [Document(**jdoc) for jdoc in jdocs]

        parameters = DeepLParameters(target_lang=TargetLang.EN_US)
        processor = DeepLProcessor()
        docs = processor.process(docs, parameters)
        assert docs == HasLen(11)
        for doc in docs:
            assert doc.metadata == IsPartialDict(language="en")

        target = Path(
            testdir,
            "data/to.json",
        )
        with target.open("w") as fout:
            dl = DocumentList(root=docs)
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)

        parameters.as_altText = "translation"
        parameters.target_lang = TargetLang.FR
        docs = processor.process(docs, parameters)
        assert docs == HasLen(11)
        for doc in docs:
            assert doc.altTexts == IsList(HasAttributes(name=parameters.as_altText))

        target = Path(
            testdir,
            "data/toalts.json",
        )
        with target.open("w") as fout:
            dl = DocumentList(root=docs)
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


@requires_deepl_api_key
def test_deepl_zh():
    testdir = Path(__file__).parent
    source = Path(
        testdir,
        "data/chinese.json",
    )

    with source.open("r") as fin:
        jdocs = json.load(fin)
        docs = [Document(**jdoc) for jdoc in jdocs]

        parameters = DeepLParameters(target_lang=TargetLang.FR)
        processor = DeepLProcessor()
        docs = processor.process(docs, parameters)
        target = Path(
            testdir,
            "data/chinese_fr.json",
        )
        with target.open("w") as fout:
            dl = DocumentList(root=docs)
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


@requires_deepl_api_key
def test_deepl_xcago():
    testdir = Path(__file__).parent
    source = Path(
        testdir,
        "data/faz_20250318-document-faz_20250318_article_1-1.json",
    )

    with source.open("r") as fin:
        jdoc = json.load(fin)
        docs = [Document(**jdoc)]

        parameters = DeepLParameters(target_lang=TargetLang.FR, formality=Formality.more)
        processor = DeepLProcessor()
        docs = processor.process(docs, parameters)
        doc0 = docs[0]
        assert doc0
