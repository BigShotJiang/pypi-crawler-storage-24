import os
from enum import StrEnum
from functools import cache
from typing import cast

import deepl
from deepl import SplitSentences
from pydantic import BaseModel, Field
from pymultirole_plugins.util import comma_separated_to_list
from pymultirole_plugins.v1.processor import ProcessorBase, ProcessorParameters
from pymultirole_plugins.v1.schema import AltText, Document, Sentence

DEEPL_API_KEY = os.environ.get("DEEPL_API_KEY")


class TargetLang(StrEnum):
    # BG - Bulgarian
    # CS - Czech
    # DA - Danish
    DE = "DE"
    # EL - Greek
    EN_GB = "EN-GB"
    EN_US = "EN-US"
    ES = "ES"
    # ET - Estonian
    # FI - Finnish
    FR = "FR"
    # HU - Hungarian
    # ID - Indonesian
    IT = "FR"
    # JA - Japanese
    # LT - Lithuanian
    # LV - Latvian
    NL = "NL"
    # PL - Polish
    PT_BR = "PT-BR"
    PT_PT = "PT-PT"
    # RO - Romanian
    RU = "RU"
    # SK - Slovak
    # SL - Slovenian
    # SV - Swedish
    # TR - Turkish
    # UK - Ukrainian
    ZH = "ZH"


class Formality(StrEnum):
    default = "default"
    more = "more"
    less = "less"
    prefer_more = "prefer_more"
    prefer_less = "prefer_less"


class DeepLParameters(ProcessorParameters):
    target_lang: TargetLang = Field(
        None,
        description="Target language for the translation. "
        "Supported targets: DE (German), EN-GB (English British), EN-US (English American), "
        "ES (Spanish), FR (French), IT (Italian), NL (Dutch), "
        "PT-BR (Portuguese Brazilian), PT-PT (Portuguese European), RU (Russian), ZH (Chinese simplified).",
    )
    formality: Formality = Field(
        Formality.default,
        description="Controls the formality level of the translated text. "
        "Supported for DE, FR, IT, ES, NL, PL, PT-PT, PT-BR, and RU. "
        "Use `more`/`less` to enforce formality (fails if unsupported), "
        "or `prefer_more`/`prefer_less` to request formality with fallback to default.",
    )
    as_altText: str = Field(
        None,
        description="When set, stores the translation as an alternative text with this name "
        "instead of replacing the original document text.",
    )


SUPPORTED_LANGUAGES = "bg,cs,da,de,el,en,es,et,fi,fr,hu,id,it,ja,lt,lv,nl,pl,pt,ro,ru,sk,sl,sv,tr,uk,zh"


class DeepLProcessor(ProcessorBase):
    __doc__ = (  # noqa: A003
        """Translate documents using the DeepL API.

    Translates document text (and optionally title) into a target language.
    When sentences are present, each sentence is translated individually to preserve segmentation.
    The translation can either replace the original text or be stored as an alternative text.
    Requires the DEEPL_API_KEY environment variable to be set.
    #languages:"""
        + SUPPORTED_LANGUAGES
    )

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        supported_languages = comma_separated_to_list(SUPPORTED_LANGUAGES)

        params: DeepLParameters = cast(DeepLParameters, parameters)
        try:
            translator = get_translator(DEEPL_API_KEY)
            for document in documents:
                lang = document_language(document, None)
                if lang is None or lang not in supported_languages:
                    raise AttributeError(f"Metadata language {lang} is required and must be in {SUPPORTED_LANGUAGES}")
                trans_title = None
                if document.title:
                    trans_title = translator.translate_text(
                        document.title,
                        source_lang=lang.upper(),
                        target_lang=params.target_lang.value,
                        split_sentences=SplitSentences.OFF,
                        formality=params.formality.value,
                    ).text
                sentences = []
                if document.sentences:
                    stexts = [document.text[s.start : s.end] for s in document.sentences]
                    results = translator.translate_text(
                        stexts,
                        source_lang=lang.upper(),
                        target_lang=params.target_lang.value,
                        split_sentences=SplitSentences.OFF,
                        formality=params.formality.value,
                    )
                    trans_texts = [r.text for r in results]
                    start = 0
                    end = 0
                    trans_text = ""
                    for s, t in zip(document.sentences, trans_texts, strict=True):
                        metadata = {k: v for k, v in s.metadata.items() if k not in document.metadata}
                        start = len(trans_text)
                        trans_text += t + "\n"
                        end = len(trans_text)
                        sentences.append(Sentence(start=start, end=end, metadata=metadata))
                else:
                    trans_text = translator.translate_text(
                        document.text,
                        source_lang=lang.upper(),
                        target_lang=params.target_lang.value,
                        split_sentences=SplitSentences.ALL,
                        formality=params.formality.value,
                    ).text
                if params.as_altText is not None and len(params.as_altText):
                    document.altTexts = document.altTexts or []
                    altTexts = [alt for alt in document.altTexts if alt.name != params.as_altText]
                    atext = trans_text if trans_title is None else trans_title + "\n" + trans_text
                    altTexts.append(AltText(name=params.as_altText, text=atext))
                    document.altTexts = altTexts
                else:
                    if trans_title is not None:
                        document.title = trans_title
                    document.text = trans_text
                    document.metadata["language"] = params.target_lang.value[:2].lower()
                    document.sentences = sentences
                    document.annotations = None
                    document.categories = None

        except BaseException as err:
            raise err
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return DeepLParameters


def document_language(doc: Document, default: str = None):
    if doc.metadata is not None and "language" in doc.metadata:
        return doc.metadata["language"]
    return default


@cache
def get_translator(auth_key):
    translator = deepl.Translator(auth_key)
    return translator
