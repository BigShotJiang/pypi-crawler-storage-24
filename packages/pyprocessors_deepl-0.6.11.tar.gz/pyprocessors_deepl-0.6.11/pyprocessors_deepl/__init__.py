"""DeepL processor"""

__version__ = "0.6.11"
