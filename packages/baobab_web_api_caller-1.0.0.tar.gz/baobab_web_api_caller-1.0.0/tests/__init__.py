"""Package de tests (racine)."""
