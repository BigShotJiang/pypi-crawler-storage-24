"""
===============================================================================
cb9a6d75e9fddd186fa8b8093406d38f
This file is auto-generated from the Async API modules, - do not edit manually!
===============================================================================
"""

from __future__ import annotations

from collections.abc import Sequence

from cognite.client import AsyncCogniteClient
from cognite.client._constants import DEFAULT_LIMIT_READ
from cognite.client._sync_api_client import SyncAPIClient
from cognite.client.data_classes import (
    TransformationJob,
    TransformationJobList,
    TransformationJobMetricList,
)
from cognite.client.utils._async_helpers import run_sync


class SyncTransformationJobsAPI(SyncAPIClient):
    """Auto-generated, do not modify manually."""

    def __init__(self, async_client: AsyncCogniteClient) -> None:
        self.__async_client = async_client

    def list(
        self,
        limit: int | None = DEFAULT_LIMIT_READ,
        transformation_id: int | None = None,
        transformation_external_id: str | None = None,
    ) -> TransformationJobList:
        """
        `List all running transformation jobs. <https://api-docs.cognite.com/20230101/tag/Transformation-Jobs/operation/getTransformationJobs>`_

        Args:
            limit (int | None): Limits the number of results to be returned. To retrieve all results use limit=-1, default limit is 25.
            transformation_id (int | None): Filters the results by the internal transformation id.
            transformation_external_id (str | None): Filters the results by the external transformation id.

        Returns:
            TransformationJobList: List of transformation jobs

        Example:

            List transformation jobs::

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> transformation_jobs_list = client.transformations.jobs.list()

            List transformation jobs of a single transformation::

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> transformation_jobs_list = client.transformations.jobs.list(transformation_id=1)
        """
        return run_sync(
            self.__async_client.transformations.jobs.list(
                limit=limit, transformation_id=transformation_id, transformation_external_id=transformation_external_id
            )
        )

    def retrieve(self, id: int) -> TransformationJob | None:
        """
        `Retrieve a single transformation job by id. <https://api-docs.cognite.com/20230101/tag/Transformation-Jobs/operation/getTransformationJobsByIds>`_

        Args:
            id (int): Job internal Id

        Returns:
            TransformationJob | None: Requested transformation job or None if it does not exist.

        Examples:

            Get transformation job by id:

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> res = client.transformations.jobs.retrieve(id=1)
        """
        return run_sync(self.__async_client.transformations.jobs.retrieve(id=id))

    def list_metrics(self, id: int) -> TransformationJobMetricList:
        """
        `List the metrics of a single transformation job. <https://api-docs.cognite.com/20230101/tag/Transformation-Jobs/operation/getTransformationJobsMetrics>`_

        Args:
            id (int): Job internal Id

        Returns:
            TransformationJobMetricList: List of updated metrics of the given job.

        Examples:

            Get metrics by transformation job id:

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> res = client.transformations.jobs.list_metrics(id=1)
        """
        return run_sync(self.__async_client.transformations.jobs.list_metrics(id=id))

    def retrieve_multiple(self, ids: Sequence[int], ignore_unknown_ids: bool = False) -> TransformationJobList:
        """
        `Retrieve multiple transformation jobs by id. <https://api-docs.cognite.com/20230101/tag/Transformation-Jobs/operation/getTransformationJobsByIds>`_

        Args:
            ids (Sequence[int]): Job internal Ids
            ignore_unknown_ids (bool): Ignore IDs that are not found rather than throw an exception.

        Returns:
            TransformationJobList: Requested transformation jobs.

        Examples:

            Get jobs by id:

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> res = client.transformations.jobs.retrieve_multiple(ids=[1, 2, 3])
        """
        return run_sync(
            self.__async_client.transformations.jobs.retrieve_multiple(ids=ids, ignore_unknown_ids=ignore_unknown_ids)
        )
