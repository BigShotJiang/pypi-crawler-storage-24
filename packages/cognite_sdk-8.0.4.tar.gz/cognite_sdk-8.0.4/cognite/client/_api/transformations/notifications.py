from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from typing import overload

from cognite.client._api_client import APIClient
from cognite.client._constants import DEFAULT_LIMIT_READ
from cognite.client.data_classes import (
    TransformationNotification,
    TransformationNotificationList,
    TransformationNotificationWrite,
)
from cognite.client.data_classes.transformations.notifications import (
    TransformationNotificationCore,
    TransformationNotificationFilter,
)
from cognite.client.utils._identifier import IdentifierSequence
from cognite.client.utils._validation import assert_type


class TransformationNotificationsAPI(APIClient):
    _RESOURCE_PATH = "/transformations/notifications"

    @overload
    def __call__(
        self,
        chunk_size: None = None,
        transformation_id: int | None = None,
        transformation_external_id: str | None = None,
        destination: str | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[TransformationNotification]: ...

    @overload
    def __call__(
        self,
        chunk_size: int,
        transformation_id: int | None = None,
        transformation_external_id: str | None = None,
        destination: str | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[TransformationNotificationList]: ...

    async def __call__(
        self,
        chunk_size: int | None = None,
        transformation_id: int | None = None,
        transformation_external_id: str | None = None,
        destination: str | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[TransformationNotification] | AsyncIterator[TransformationNotificationList]:
        """Iterate over transformation notifications

        Args:
            chunk_size (int | None): Number of notifications to yield per chunk. Defaults to yielding notifications one by one.
            transformation_id (int | None): Filter by transformation internal numeric ID.
            transformation_external_id (str | None): Filter by transformation externalId.
            destination (str | None): Filter by notification destination.
            limit (int | None): Limits the number of results to be returned. Defaults to yielding all notifications.

        Yields:
            TransformationNotification | TransformationNotificationList: Yields notifications one by one if chunk_size is None, otherwise yields lists of notifications.
        """  # noqa: DOC404
        filter_ = TransformationNotificationFilter(
            transformation_id=transformation_id,
            transformation_external_id=transformation_external_id,
            destination=destination,
        ).dump(camel_case=True)

        async for item in self._list_generator(
            method="GET",
            limit=limit,
            resource_cls=TransformationNotification,
            list_cls=TransformationNotificationList,
            filter=filter_,
            chunk_size=chunk_size,
        ):
            yield item

    @overload
    async def create(
        self, notification: TransformationNotification | TransformationNotificationWrite
    ) -> TransformationNotification: ...

    @overload
    async def create(
        self, notification: Sequence[TransformationNotification] | Sequence[TransformationNotificationWrite]
    ) -> TransformationNotificationList: ...

    async def create(
        self,
        notification: TransformationNotification
        | TransformationNotificationWrite
        | Sequence[TransformationNotification]
        | Sequence[TransformationNotificationWrite],
    ) -> TransformationNotification | TransformationNotificationList:
        """`Subscribe for notifications on the transformation errors. <https://api-docs.cognite.com/20230101/tag/Transformation-Notifications/operation/createTransformationNotifications>`_

        Args:
            notification (TransformationNotification | TransformationNotificationWrite | Sequence[TransformationNotification] | Sequence[TransformationNotificationWrite]): Notification or list of notifications to create.

        Returns:
            TransformationNotification | TransformationNotificationList: Created notification(s)

        Examples:

            Create new notifications:

                >>> from cognite.client import CogniteClient
                >>> from cognite.client.data_classes import TransformationNotification
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> notifications = [TransformationNotification(transformation_id = 1, destination="my@email.com"), TransformationNotification(transformation_external_id="transformation2", destination="other@email.com"))]
                >>> res = client.transformations.notifications.create(notifications)
        """
        assert_type(notification, "notification", [TransformationNotificationCore, Sequence])
        return await self._create_multiple(
            list_cls=TransformationNotificationList,
            resource_cls=TransformationNotification,
            items=notification,
            input_resource_cls=TransformationNotificationWrite,
        )

    async def list(
        self,
        transformation_id: int | None = None,
        transformation_external_id: str | None = None,
        destination: str | None = None,
        limit: int | None = DEFAULT_LIMIT_READ,
    ) -> TransformationNotificationList:
        """`List notification subscriptions. <https://api-docs.cognite.com/20230101/tag/Transformation-Notifications/operation/getTransformationNotifications>`_

        Args:
            transformation_id (int | None): Filter by transformation internal numeric ID.
            transformation_external_id (str | None): Filter by transformation externalId.
            destination (str | None): Filter by notification destination.
            limit (int | None): Limits the number of results to be returned. To retrieve all results use limit=-1, default limit is 25.

        Returns:
            TransformationNotificationList: List of transformation notifications

        Example:

            List all notifications::

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> notifications_list = client.transformations.notifications.list()

            List all notifications by transformation id::

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> notifications_list = client.transformations.notifications.list(transformation_id = 1)
        """
        filter = TransformationNotificationFilter(
            transformation_id=transformation_id,
            transformation_external_id=transformation_external_id,
            destination=destination,
        ).dump(camel_case=True)

        return await self._list(
            list_cls=TransformationNotificationList,
            resource_cls=TransformationNotification,
            method="GET",
            limit=limit,
            filter=filter,
        )

    async def delete(self, id: int | Sequence[int] | None = None) -> None:
        """`Deletes the specified notification subscriptions on the transformation. Does nothing when the subscriptions already don't exist <https://api-docs.cognite.com/20230101/tag/Transformation-Notifications/operation/deleteTransformationNotifications>`_

        Args:
            id (int | Sequence[int] | None): Id or list of transformation notification ids

        Examples:

            Delete schedules by id or external id:

                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> client.transformations.notifications.delete(id=[1, 2, 3])
        """
        await self._delete_multiple(identifiers=IdentifierSequence.load(ids=id), wrap_ids=True)
