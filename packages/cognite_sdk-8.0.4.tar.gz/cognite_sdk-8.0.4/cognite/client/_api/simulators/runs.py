from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from typing import TYPE_CHECKING, overload

from cognite.client._api_client import APIClient
from cognite.client._constants import DEFAULT_LIMIT_READ
from cognite.client.data_classes.shared import TimestampRange
from cognite.client.data_classes.simulators.filters import SimulationRunsSort, SimulatorRunsFilter
from cognite.client.data_classes.simulators.runs import (
    SimulationRun,
    SimulationRunDataList,
    SimulationRunList,
    SimulationRunWrite,
)
from cognite.client.utils._experimental import FeaturePreviewWarning
from cognite.client.utils._identifier import IdentifierSequence
from cognite.client.utils._validation import assert_type
from cognite.client.utils.useful_types import SequenceNotStr

if TYPE_CHECKING:
    from cognite.client import AsyncCogniteClient
    from cognite.client.config import ClientConfig


class SimulatorRunsAPI(APIClient):
    _RESOURCE_PATH = "/simulators/runs"
    _RESOURCE_PATH_RUN = "/simulators/run"

    def __init__(
        self,
        config: ClientConfig,
        api_version: str | None,
        cognite_client: AsyncCogniteClient,
    ) -> None:
        super().__init__(config, api_version, cognite_client)
        self._CREATE_LIMIT = 1
        self._RETRIEVE_LIMIT = 1
        self._warning = FeaturePreviewWarning(
            api_maturity="General Availability",
            sdk_maturity="alpha",
            feature_name="Simulators",
        )

    @overload
    def __call__(
        self,
        chunk_size: int,
        limit: int | None = None,
        status: str | None = None,
        run_type: str | None = None,
        model_external_ids: SequenceNotStr[str] | None = None,
        simulator_integration_external_ids: SequenceNotStr[str] | None = None,
        simulator_external_ids: SequenceNotStr[str] | None = None,
        routine_external_ids: SequenceNotStr[str] | None = None,
        routine_revision_external_ids: SequenceNotStr[str] | None = None,
        model_revision_external_ids: SequenceNotStr[str] | None = None,
        created_time: TimestampRange | None = None,
        simulation_time: TimestampRange | None = None,
        sort: SimulationRunsSort | None = None,
    ) -> AsyncIterator[SimulationRunList]: ...

    @overload
    def __call__(
        self,
        chunk_size: None = None,
        limit: int | None = None,
        status: str | None = None,
        run_type: str | None = None,
        model_external_ids: SequenceNotStr[str] | None = None,
        simulator_integration_external_ids: SequenceNotStr[str] | None = None,
        simulator_external_ids: SequenceNotStr[str] | None = None,
        routine_external_ids: SequenceNotStr[str] | None = None,
        routine_revision_external_ids: SequenceNotStr[str] | None = None,
        model_revision_external_ids: SequenceNotStr[str] | None = None,
        created_time: TimestampRange | None = None,
        simulation_time: TimestampRange | None = None,
        sort: SimulationRunsSort | None = None,
    ) -> AsyncIterator[SimulationRun]: ...

    async def __call__(
        self,
        chunk_size: int | None = None,
        limit: int | None = None,
        status: str | None = None,
        run_type: str | None = None,
        model_external_ids: SequenceNotStr[str] | None = None,
        simulator_integration_external_ids: SequenceNotStr[str] | None = None,
        simulator_external_ids: SequenceNotStr[str] | None = None,
        routine_external_ids: SequenceNotStr[str] | None = None,
        routine_revision_external_ids: SequenceNotStr[str] | None = None,
        model_revision_external_ids: SequenceNotStr[str] | None = None,
        created_time: TimestampRange | None = None,
        simulation_time: TimestampRange | None = None,
        sort: SimulationRunsSort | None = None,
    ) -> AsyncIterator[SimulationRun] | AsyncIterator[SimulationRunList]:
        """Iterate over simulation runs

        Fetches simulation runs as they are iterated over, so you keep a limited number of simulation runs in memory.

        Args:
            chunk_size (int | None): Number of simulation runs to return in each chunk. Defaults to yielding one simulation run a time.
            limit (int | None): The maximum number of simulation runs to return, pass None to return all.
            status (str | None): Filter by simulation run status
            run_type (str | None): Filter by simulation run type
            model_external_ids (SequenceNotStr[str] | None): Filter by simulator model external ids
            simulator_integration_external_ids (SequenceNotStr[str] | None): Filter by simulator integration external ids
            simulator_external_ids (SequenceNotStr[str] | None): Filter by simulator external ids
            routine_external_ids (SequenceNotStr[str] | None): Filter by routine external ids
            routine_revision_external_ids (SequenceNotStr[str] | None): Filter by routine revision external ids
            model_revision_external_ids (SequenceNotStr[str] | None): Filter by model revision external ids
            created_time (TimestampRange | None): Filter by created time
            simulation_time (TimestampRange | None): Filter by simulation time
            sort (SimulationRunsSort | None): The criteria to sort by.

        Yields:
            SimulationRun | SimulationRunList: yields Simulation Run one by one if chunk is not specified, else SimulatorRunsList objects.
        """  # noqa: DOC404
        filter_runs = SimulatorRunsFilter(
            status=status,
            run_type=run_type,
            model_external_ids=model_external_ids,
            simulator_integration_external_ids=simulator_integration_external_ids,
            simulator_external_ids=simulator_external_ids,
            routine_external_ids=routine_external_ids,
            routine_revision_external_ids=routine_revision_external_ids,
            model_revision_external_ids=model_revision_external_ids,
            created_time=created_time,
            simulation_time=simulation_time,
        )

        async for item in self._list_generator(
            list_cls=SimulationRunList,
            resource_cls=SimulationRun,
            method="POST",
            filter=filter_runs.dump(),
            sort=[SimulationRunsSort.load(sort).dump()] if sort else None,
            chunk_size=chunk_size,
            limit=limit,
        ):
            yield item

    async def list(
        self,
        limit: int | None = DEFAULT_LIMIT_READ,
        status: str | None = None,
        run_type: str | None = None,
        model_external_ids: SequenceNotStr[str] | None = None,
        simulator_integration_external_ids: SequenceNotStr[str] | None = None,
        simulator_external_ids: SequenceNotStr[str] | None = None,
        routine_external_ids: SequenceNotStr[str] | None = None,
        routine_revision_external_ids: SequenceNotStr[str] | None = None,
        model_revision_external_ids: SequenceNotStr[str] | None = None,
        created_time: TimestampRange | None = None,
        simulation_time: TimestampRange | None = None,
        sort: SimulationRunsSort | None = None,
    ) -> SimulationRunList:
        """`Filter simulation runs <https://api-docs.cognite.com/20230101/tag/Simulation-Runs/operation/filter_simulation_runs_simulators_runs_list_post>`_

        Retrieves a list of simulation runs that match the given criteria.

        Args:
            limit (int | None): The maximum number of simulation runs to return, pass None to return all.
            status (str | None): Filter by simulation run status
            run_type (str | None): Filter by simulation run type
            model_external_ids (SequenceNotStr[str] | None): Filter by simulator model external ids
            simulator_integration_external_ids (SequenceNotStr[str] | None): Filter by simulator integration external ids
            simulator_external_ids (SequenceNotStr[str] | None): Filter by simulator external ids
            routine_external_ids (SequenceNotStr[str] | None): Filter by routine external ids
            routine_revision_external_ids (SequenceNotStr[str] | None): Filter by routine revision external ids
            model_revision_external_ids (SequenceNotStr[str] | None): Filter by model revision external ids
            created_time (TimestampRange | None): Filter by created time
            simulation_time (TimestampRange | None): Filter by simulation time
            sort (SimulationRunsSort | None): The criteria to sort by.

        Returns:
            SimulationRunList: List of simulation runs

        Examples:
            List simulation runs:
                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> res = client.simulators.runs.list()

            Iterate over simulation runs, one-by-one:
                >>> for run in client.simulators.runs():
                ...     run  # do something with the simulation run

            Filter runs by status and simulator external ids:
                >>> res = client.simulators.runs.list(
                ...     simulator_external_ids=["PROSPER", "DWSIM"], status="success"
                ... )

            Filter runs by time ranges:
                >>> from cognite.client.data_classes.shared import TimestampRange
                >>> res = client.simulators.runs.list(
                ...     created_time=TimestampRange(min=0, max=1_700_000_000_000),
                ...     simulation_time=TimestampRange(min=0, max=1_700_000_000_000),
                ... )
        """

        filter_runs = SimulatorRunsFilter(
            status=status,
            run_type=run_type,
            model_external_ids=model_external_ids,
            simulator_integration_external_ids=simulator_integration_external_ids,
            simulator_external_ids=simulator_external_ids,
            routine_external_ids=routine_external_ids,
            routine_revision_external_ids=routine_revision_external_ids,
            model_revision_external_ids=model_revision_external_ids,
            created_time=created_time,
            simulation_time=simulation_time,
        )
        self._warning.warn()
        return await self._list(
            method="POST",
            limit=limit,
            resource_cls=SimulationRun,
            list_cls=SimulationRunList,
            filter=filter_runs.dump(),
            sort=[SimulationRunsSort.load(sort).dump()] if sort else None,
        )

    @overload
    async def retrieve(self, ids: int) -> SimulationRun | None: ...

    @overload
    async def retrieve(
        self,
        ids: Sequence[int],
    ) -> SimulationRunList | None: ...

    async def retrieve(
        self,
        ids: int | Sequence[int],
    ) -> SimulationRun | SimulationRunList | None:
        """`Retrieve simulation runs by ID <https://api-docs.cognite.com/20230101/tag/Simulation-Runs/operation/retrieve_simulation_run_by_id>`_

        Args:
            ids (int | Sequence[int]): The ID(s) of the simulation run(s) to retrieve.

        Returns:
            SimulationRun | SimulationRunList | None: The simulation run(s) with the given ID(s)

        Examples:
            Retrieve a single simulation run by id:
                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> run = client.simulators.runs.retrieve(ids=2)
        """
        self._warning.warn()
        identifiers = IdentifierSequence.load(ids=ids)
        return await self._retrieve_multiple(
            resource_cls=SimulationRun,
            list_cls=SimulationRunList,
            identifiers=identifiers,
            resource_path=self._RESOURCE_PATH,
        )

    @overload
    async def create(self, items: SimulationRunWrite) -> SimulationRun: ...

    @overload
    async def create(self, items: Sequence[SimulationRunWrite]) -> SimulationRunList: ...

    async def create(
        self, items: SimulationRunWrite | Sequence[SimulationRunWrite]
    ) -> SimulationRun | SimulationRunList:
        """`Create simulation runs <https://api-docs.cognite.com/20230101/tag/Simulation-Runs/operation/run_simulation_simulators_run_post>`_

        Args:
            items (SimulationRunWrite | Sequence[SimulationRunWrite]): The simulation run(s) to execute.

        Returns:
            SimulationRun | SimulationRunList: Created simulation run(s)

        Examples:
            Create new simulation run:
                >>> from cognite.client import CogniteClient
                >>> from cognite.client.data_classes.simulators.runs import SimulationRunWrite
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> run = [
                ...     SimulationRunWrite(
                ...         routine_external_id="routine1",
                ...         log_severity="Debug",
                ...         run_type="external",
                ...     ),
                ... ]
                >>> res = client.simulators.runs.create(run)
        """
        assert_type(items, "simulation_run", [SimulationRunWrite, Sequence])

        return await self._create_multiple(
            list_cls=SimulationRunList,
            resource_cls=SimulationRun,
            items=items,
            input_resource_cls=SimulationRunWrite,
            resource_path=self._RESOURCE_PATH_RUN,
        )

    async def list_run_data(
        self,
        run_id: int,
    ) -> SimulationRunDataList:
        """`Get simulation run data <https://api-docs.cognite.com/20230101/tag/Simulation-Runs/operation/simulation_data_by_run_id_simulators_runs_data_list_post>`_

        Retrieve data associated with a simulation run by ID.

        Args:
            run_id (int): Simulation run id.

        Returns:
            SimulationRunDataList: List of simulation run data

        Examples:
            Get simulation run data by run id:
                >>> from cognite.client import CogniteClient, AsyncCogniteClient
                >>> client = CogniteClient()
                >>> # async_client = AsyncCogniteClient()  # another option
                >>> res = client.simulators.runs.list_run_data(run_id=12345)

            Get simulation run data directly on a simulation run object:
                >>> run = client.simulators.runs.retrieve(ids=2)
                >>> res = run.get_data()
        """
        self._warning.warn()

        req = await self._post(
            url_path=f"{self._RESOURCE_PATH}/data/list",
            json={"items": [{"runId": run_id}]},
            semaphore=self._get_semaphore("read"),
        )

        items = req.json().get("items", [])
        return SimulationRunDataList._load(items)
