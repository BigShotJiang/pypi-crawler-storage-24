"""Common game primitives shared by multiple libraries.

This module models sequential games in terms of acting roles. `Color` is a
concrete role type for black/white games and `SoloRole` covers single-player
games.
"""

from collections.abc import Hashable, Iterator, Sequence
from dataclasses import dataclass, field
from enum import Enum
from typing import Annotated, Any, Protocol, Self, TypeVar

type Seed = Annotated[int, "seed"]
type Role = Hashable

type StateTag = Annotated[Hashable, "A label or identifier for a state in a game"]

type StateModifications = Annotated[
    object, "Modifications to the state between to time steps of the game"
]  # used for time and memory optimisation

type BranchName = Annotated[str, "A human-readable name for a branch of a state"]

type BranchKey = Annotated[Hashable, "A label or identifier for a branch in a tree"]
type ActionName = Annotated[str, "A human-readable name for an action of a state"]

type ActionKey = Annotated[Hashable, "A label or identifier for an action"]

T_co = TypeVar("T_co", bound=Hashable, covariant=True)
RoleT = TypeVar("RoleT", bound=Hashable)
RoleT_co = TypeVar("RoleT_co", bound=Hashable, covariant=True)


class BranchKeyGeneratorP(Protocol[T_co]):
    """Protocol for a branch key generator that yields branch keys."""

    # whether to sort the branch keys by their respective uci for easy comparison of various implementations
    sort_branch_keys: bool = False

    @property
    def all_generated_keys(self) -> Sequence[T_co] | None:
        """Return all generated branch keys if available, otherwise None."""
        ...

    def __iter__(self) -> Iterator[T_co]:
        """Return an iterator over the branch keys."""
        ...

    def __next__(self) -> T_co:
        """Return the next branch key."""
        ...

    def more_than_one(self) -> bool:
        """Check if there is more than one branch available.

        Returns:
            bool: True if there is more than one branch, False otherwise.

        """
        ...

    def get_all(self) -> Sequence[T_co]:
        """Return a list of all branch keys."""
        ...

    def copy_with_reset(self) -> Self:
        """Create a copy of the legal move generator with an optional reset of generated moves.

        Returns:
            Self: A new instance of the legal move generator with the specified generated moves.

        """
        ...


class State(Protocol):
    """Protocol for a content object that has a tag."""

    @property
    def tag(self) -> StateTag:
        """Return the tag of the content.

        Returns:
            StateTag: The tag of the content.

        """
        ...

    def is_game_over(self) -> bool:
        """Check if the game represented by the content is over.

        Returns:
            bool: True if the game is over, False otherwise.

        """
        ...

    def pprint(self) -> str:
        """Return a pretty-printed string representation of the content.

        Returns:
            str: A pretty-printed string representation of the content.

        """
        ...


type ColorIndex = Annotated[int, "1 for white, 0 for black"]

WHITE: ColorIndex = 1
BLACK: ColorIndex = 0


class Color(int, Enum):
    """A concrete acting-role type for a two-player black/white game."""

    WHITE = WHITE
    BLACK = BLACK


class SoloRole(Enum):
    """The acting-role type for a single-player sequential game."""

    SOLO = "solo"


SOLO: SoloRole = SoloRole.SOLO


def _actions_history_factory() -> list[ActionKey]:
    return []


@dataclass
class StatePlusHistory[StateT]:
    """A State with historical actions and states."""

    @staticmethod
    def _states_factory() -> list[StateT]:
        return []

    current_state_tag: StateTag
    historical_actions: list[ActionKey] = field(
        default_factory=_actions_history_factory
    )
    historical_states: list[StateT] = field(default_factory=_states_factory)


class HasTurn(Protocol[RoleT_co]):
    """Protocol for a state-like object with a current acting role.

    The `turn` attribute is intentionally role-generic. `Color` remains a valid
    role for adversarial games, while single-player states can use
    :class:`SoloRole` and future multiplayer states can use other hashable role
    identifiers.
    """

    @property
    def turn(self) -> RoleT_co:
        """Return the current acting role.

        Returns:
            RoleT_co: The role whose turn it is to act.

        """
        ...


class TurnState(State, HasTurn[RoleT_co], Protocol[RoleT_co]):
    """A State that also exposes the current acting role."""

    ...


@dataclass
class TurnStatePlusHistory[StateT = Any, TurnRoleT: Role = Color]:
    """A turn-carrying state snapshot with historical actions and states.

    The role type defaults to :class:`Color` for convenience in two-player
    games while remaining fully generic.
    """

    @staticmethod
    def _states_factory() -> list[StateT]:
        return []

    current_state_tag: StateTag
    turn: TurnRoleT
    historical_actions: list[ActionKey] = field(
        default_factory=_actions_history_factory
    )
    historical_states: list[StateT] = field(default_factory=_states_factory)
