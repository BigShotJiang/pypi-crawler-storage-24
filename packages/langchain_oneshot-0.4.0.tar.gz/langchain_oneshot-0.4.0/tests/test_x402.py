"""Tests for EIP-712 payment signing (x402 module).

Verifies that:
1. USDC amount parsing is correct (6 decimals)
2. EIP-712 signatures are valid and recoverable
3. Domain name is "USD Coin" for Base Mainnet
"""

from eth_account import Account

from oneshot.x402 import (
    _get_usdc_domain_name,
    _parse_usdc_amount,
    sign_payment_authorization,
)

# Deterministic test key (never use with real funds)
TEST_PRIVATE_KEY = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
TEST_ADDRESS = Account.from_key(TEST_PRIVATE_KEY).address

# Base Mainnet config
CHAIN_ID = 8453
USDC_ADDRESS = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"


class TestParseUsdcAmount:
    def test_whole_number(self) -> None:
        assert _parse_usdc_amount("10") == 10_000_000

    def test_two_decimals(self) -> None:
        assert _parse_usdc_amount("1.50") == 1_500_000

    def test_six_decimals(self) -> None:
        assert _parse_usdc_amount("0.000001") == 1

    def test_three_decimals(self) -> None:
        assert _parse_usdc_amount("0.123") == 123_000

    def test_zero(self) -> None:
        assert _parse_usdc_amount("0") == 0

    def test_small_amount(self) -> None:
        assert _parse_usdc_amount("0.01") == 10_000


class TestDomainName:
    def test_mainnet_uses_usd_coin(self) -> None:
        assert _get_usdc_domain_name(8453) == "USD Coin"


class TestSignPaymentAuthorization:
    def test_returns_valid_structure(self) -> None:
        auth = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="1.00",
            token_address=USDC_ADDRESS,
            chain_id=CHAIN_ID,
            network="eip155:8453",
        )

        # Check all required fields
        assert auth["from"] == TEST_ADDRESS
        assert auth["to"] == "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"
        assert auth["value"] == "1000000"
        assert isinstance(auth["validAfter"], int)
        assert isinstance(auth["validBefore"], int)
        assert auth["validBefore"] > auth["validAfter"]
        assert auth["nonce"].startswith("0x") and len(auth["nonce"]) == 66
        assert auth["network"] == "eip155:8453"
        assert auth["token"] == USDC_ADDRESS

        # Check signature
        sig = auth["signature"]
        assert sig["v"] in (27, 28)
        assert sig["r"].startswith("0x")
        assert sig["s"].startswith("0x")

    def test_different_calls_produce_different_nonces(self) -> None:
        auth1 = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="1.00",
            token_address=USDC_ADDRESS,
            chain_id=CHAIN_ID,
            network="eip155:8453",
        )
        auth2 = sign_payment_authorization(
            private_key=TEST_PRIVATE_KEY,
            from_address=TEST_ADDRESS,
            to_address="0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            amount="1.00",
            token_address=USDC_ADDRESS,
            chain_id=CHAIN_ID,
            network="eip155:8453",
        )

        assert auth1["nonce"] != auth2["nonce"]
