# Copyright 2020 Tecnativa - David Vidal
# Copyright 2023 Tecnativa - Pedro M. Baeza
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
{
    "name": "Return Merchandise Authorization Management - Link with MRP Kits",
    "summary": "Allow doing RMAs from MRP kits",
    "version": "16.0.2.2.2",
    "development_status": "Beta",
    "category": "RMA",
    "website": "https://github.com/OCA/rma",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "maintainers": ["chienandalu"],
    "license": "AGPL-3",
    "depends": ["rma_sale", "mrp"],
    "data": [
        "security/ir.model.access.csv",
        "views/sale_order_portal_template.xml",
        "views/rma_views.xml",
        "views/report_rma.xml",
        "wizard/sale_order_rma_wizard_views.xml",
    ],
    "assets": {
        "web.assets_tests": [
            "/rma_sale_mrp/static/src/tests/*.js",
        ],
    },
}
