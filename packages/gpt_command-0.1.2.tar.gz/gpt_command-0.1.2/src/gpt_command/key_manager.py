import argparse
import getpass

from .config import CONFIG_FILE, get_api_key, load_config, save_config, set_default_model


def set_api_key() -> None:
    print("Enter your OpenAI API key. Input will be hidden.")
    key = getpass.getpass("API Key: ").strip()

    if not key:
        print("No key was entered.")
        return

    config = load_config()
    config["OPENAI_API_KEY"] = key
    save_config(config)
    print(f"API key saved: {CONFIG_FILE}")


def delete_api_key() -> None:
    config = load_config()
    if "OPENAI_API_KEY" in config:
        del config["OPENAI_API_KEY"]
        save_config(config)
        print("Stored API key deleted.")
    else:
        print("No stored API key found.")


def show_status() -> None:
    key = get_api_key()
    if key:
        masked = key[:7] + "*" * max(0, len(key) - 11) + key[-4:]
        print("API key is configured.")
        print(f"Key preview: {masked}")
    else:
        print("API key is not configured.")

    config = load_config()
    model = config.get("DEFAULT_MODEL", "gpt-4.1")
    print(f"Default model: {model}")


def set_model(model: str) -> None:
    set_default_model(model)
    print(f"Default model saved: {model}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="gptc-key",
        description="Manage gptc API key and default model settings.",
    )
    parser.add_argument("--set", action="store_true", help="Set the API key.")
    parser.add_argument("--delete", action="store_true", help="Delete the stored API key.")
    parser.add_argument("--status", action="store_true", help="Show current configuration status.")
    parser.add_argument("--model", type=str, help="Set the default model.")

    args = parser.parse_args()
    acted = False

    if args.set:
        set_api_key()
        acted = True

    if args.delete:
        delete_api_key()
        acted = True

    if args.status:
        show_status()
        acted = True

    if args.model:
        set_model(args.model)
        acted = True

    if not acted:
        set_api_key()