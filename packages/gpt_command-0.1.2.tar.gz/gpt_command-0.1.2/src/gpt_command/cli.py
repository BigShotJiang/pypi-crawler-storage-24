import argparse
import sys

from openai import OpenAI

from .config import get_api_key, get_default_model
from .history import print_history, save_history_item
from .utils import (
    copy_to_clipboard,
    extract_command,
    is_dangerous_command,
    prefilled_input,
    run_shell_command,
    yes_no,
)

SYSTEM_PROMPT = """You are a Linux/macOS terminal command generator.

Follow these rules exactly:
1. Output only one executable shell command on a single line.
2. Do not output explanations, code fences, quotes, or extra text.
3. Prefer commands that work in bash/zsh environments.
4. If the user's request is risky or destructive, suggest the safest practical command possible.
5. If multiple steps are needed, combine them into a single one-liner using && when appropriate.
6. Return only the command string.
"""

EXPLAIN_PROMPT = """You are a Linux/macOS terminal command explainer.
Explain the given command in up to 3 short lines:
1. What it does
2. What the important options mean
3. Any caution the user should know
"""


def ask_model_for_command(question: str, model: str) -> str:
    api_key = get_api_key()
    if not api_key:
        raise RuntimeError(
            "No OpenAI API key found. Run `gptc-key` first to store your API key."
        )

    client = OpenAI(api_key=api_key)

    stream = client.responses.create(
        model=model,
        instructions=SYSTEM_PROMPT,
        input=f"Convert this natural language request into a single shell command:\n{question}",
        stream=True,
    )

    chunks = []
    printed_any = False

    for event in stream:
        event_type = getattr(event, "type", "")

        # 텍스트 델타가 올 때마다 바로 출력
        if event_type == "response.output_text.delta":
            delta = getattr(event, "delta", "")
            if delta:
                print(delta, end="", flush=True)
                chunks.append(delta)
                printed_any = True

        # 일부 SDK/버전 호환용
        elif hasattr(event, "delta") and isinstance(getattr(event, "delta"), str):
            delta = getattr(event, "delta", "")
            if delta:
                print(delta, end="", flush=True)
                chunks.append(delta)
                printed_any = True

    if printed_any:
        print()

    command = extract_command("".join(chunks))

    if not command:
        raise RuntimeError("Failed to extract a command from the streamed response.")

    return command


def ask_model_for_explanation(command: str, model: str) -> str:
    api_key = get_api_key()
    if not api_key:
        raise RuntimeError(
            "No OpenAI API key found. Run `gptc-key` first to store your API key."
        )

    client = OpenAI(api_key=api_key)

    response = client.responses.create(
        model=model,
        instructions=EXPLAIN_PROMPT,
        input=command,
    )

    text = getattr(response, "output_text", "") or ""
    return text.strip()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gptc",
        description="Convert natural language into terminal commands for macOS and Linux.",
    )
    parser.add_argument("question", nargs="*", help="Your natural language request.")
    parser.add_argument("--copy", action="store_true", help="Copy the result to the clipboard.")
    parser.add_argument("--explain", action="store_true", help="Show a short explanation of the command.")
    parser.add_argument("--run", action="store_true", help="Run the generated command after confirmation.")
    parser.add_argument("--model", type=str, default=None, help="Specify the model to use.")
    parser.add_argument("--history", action="store_true", help="Show recent command history.")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.history:
        print_history(limit=10)
        return

    if not args.question:
        parser.print_help()
        sys.exit(1)

    question = " ".join(args.question).strip()
    model = args.model or get_default_model()

    try:
        command = ask_model_for_command(question, model=model)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    explained = False
    if args.explain:
        try:
            explanation = ask_model_for_explanation(command, model=model)
            if explanation:
                print("\n[Explanation]")
                print(explanation)
                explained = True
        except Exception as e:
            print(f"\nExplanation failed: {e}")

    copied = False
    if args.copy:
        copied = copy_to_clipboard(command)
        if copied:
            print("\nCopied to clipboard.")
        else:
            print("\nFailed to copy to clipboard. Check pbcopy, xclip, or wl-copy.")

    if is_dangerous_command(command):
        print(
            "\n[Warning] A potentially dangerous command pattern was detected. "
            "Auto-run and auto-prefill have been blocked."
        )
        save_history_item(
            question=question,
            command=command,
            executed=False,
            copied=copied,
            explained=explained,
        )
        sys.exit(2)

    if args.run:
        print()
        if yes_no("Do you want to run this command?", default="n"):
            code = run_shell_command(command)
            print(f"\nExit code: {code}")
            save_history_item(
                question=question,
                command=command,
                executed=True,
                copied=copied,
                explained=explained,
            )
            sys.exit(code)
        else:
            print("Execution cancelled.")
            save_history_item(
                question=question,
                command=command,
                executed=False,
                copied=copied,
                explained=explained,
            )
            sys.exit(0)

    try:
        print()
        entered = prefilled_input(command)
        if entered.strip():
            print("Input prefilled successfully.")
    except KeyboardInterrupt:
        print("\nCancelled.")
        save_history_item(
            question=question,
            command=command,
            executed=False,
            copied=copied,
            explained=explained,
        )
        sys.exit(130)
    except EOFError:
        print()
        save_history_item(
            question=question,
            command=command,
            executed=False,
            copied=copied,
            explained=explained,
        )
        sys.exit(0)

    save_history_item(
        question=question,
        command=command,
        executed=False,
        copied=copied,
        explained=explained,
    )