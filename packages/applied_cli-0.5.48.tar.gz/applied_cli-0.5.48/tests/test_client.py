import json

import pytest

from applied_cli.client import AppliedClient


@pytest.mark.asyncio
async def test_ensure_test_conversation_creates_contact_backed_conversation(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_get_or_create_contact(email=None, name=None, phone=None):
        seen["contact"] = {
            "email": email,
            "name": name,
            "phone": phone,
        }
        return {"id": "contact-1"}

    async def fake_create_conversation(
        agent_id,
        is_test=True,
        metadata=None,
        conversation_type=None,
        contact_id=None,
    ):
        seen["conversation"] = {
            "agent_id": agent_id,
            "is_test": is_test,
            "metadata": metadata,
            "conversation_type": conversation_type,
            "contact_id": contact_id,
        }
        return {"id": "conv-1"}

    monkeypatch.setattr(client, "get_or_create_contact", fake_get_or_create_contact)
    monkeypatch.setattr(client, "create_conversation", fake_create_conversation)

    conversation = await client.ensure_test_conversation(
        agent_id="agent-1",
        contact_email="customer@example.com",
        contact_name="Customer Example",
        metadata={"order_id": "123"},
        conversation_type="email",
    )

    assert conversation == {"id": "conv-1"}
    assert seen["contact"] == {
        "email": "customer@example.com",
        "name": "Customer Example",
        "phone": None,
    }
    assert seen["conversation"] == {
        "agent_id": "agent-1",
        "is_test": True,
        "metadata": {
            "order_id": "123",
            "context": {
                "email": "customer@example.com",
                "name": "Customer Example",
            },
        },
        "conversation_type": "email",
        "contact_id": "contact-1",
    }


@pytest.mark.asyncio
async def test_ensure_test_conversation_returns_existing_id_without_creating_new_one(
    monkeypatch,
):
    client = AppliedClient(token="test-token")

    async def fail_get_or_create_contact(**kwargs):
        raise AssertionError("should not create or lookup a contact")

    async def fail_create_conversation(**kwargs):
        raise AssertionError("should not create a conversation")

    monkeypatch.setattr(client, "get_or_create_contact", fail_get_or_create_contact)
    monkeypatch.setattr(client, "create_conversation", fail_create_conversation)

    conversation = await client.ensure_test_conversation(
        agent_id="agent-1",
        conversation_id="conv-existing",
        contact_email="ignored@example.com",
    )

    assert conversation == {"id": "conv-existing"}


@pytest.mark.asyncio
async def test_query_conversations_serializes_metric_event_filter_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return []

    monkeypatch.setattr(client, "_request", fake_request)

    await client.query_conversations(
        filters={
            "created_at": {
                "gte": "2026-03-22T16:50:00Z",
                "lte": "2026-03-22T19:00:00Z",
            },
            "runs__emitted_metric_events__contains": {
                "tool.run": {
                    "tool_name": ["Escalate Conversation"],
                    "success": ["False"],
                }
            },
        }
    )

    assert seen["method"] == "GET"
    assert seen["path"] == "/v1/conversations/"
    assert seen["params"]["created_at__gte"] == "2026-03-22T16:50:00Z"
    assert seen["params"]["created_at__lte"] == "2026-03-22T19:00:00Z"
    assert seen["params"]["runs__emitted_metric_events__contains"] == json.dumps(
        {
            "tool.run": {
                "tool_name": ["Escalate Conversation"],
                "success": ["False"],
            }
        },
        separators=(",", ":"),
        ensure_ascii=True,
    )


@pytest.mark.asyncio
async def test_analytics_report_posts_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"ok": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.analytics_report(
        {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": "agent_revision_version",
        }
    )

    assert result == {"ok": True}
    assert seen == {
        "method": "POST",
        "path": "/v2/analytics/",
        "body": {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": "agent_revision_version",
        },
    }
