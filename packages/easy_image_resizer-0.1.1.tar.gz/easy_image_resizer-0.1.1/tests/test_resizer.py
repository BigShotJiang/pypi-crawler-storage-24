import os
import pytest
from PIL import Image
from easy_image_resizer import resize_image

@pytest.fixture
def create_test_image(tmp_path):
    img_path = tmp_path / "test_image.jpg"
    img = Image.new("RGB", (100, 200), color="red")
    img.save(img_path)
    return str(img_path)

def test_resize_by_percentage(create_test_image, tmp_path):
    out_path = str(tmp_path / "out1.jpg")
    resize_image(create_test_image, out_path, percentage=50)
    
    with Image.open(out_path) as img:
        assert img.size == (50, 100)

def test_resize_by_width_keeps_aspect_ratio(create_test_image, tmp_path):
    out_path = str(tmp_path / "out2.jpg")
    resize_image(create_test_image, out_path, width=50)
    
    with Image.open(out_path) as img:
        assert img.size == (50, 100)

def test_resize_by_height_keeps_aspect_ratio(create_test_image, tmp_path):
    out_path = str(tmp_path / "out3.jpg")
    resize_image(create_test_image, out_path, height=100)
    
    with Image.open(out_path) as img:
        assert img.size == (50, 100)

def test_resize_explicit_width_and_height(create_test_image, tmp_path):
    out_path = str(tmp_path / "out4.jpg")
    resize_image(create_test_image, out_path, width=30, height=40)
    
    with Image.open(out_path) as img:
        assert img.size == (30, 40)
