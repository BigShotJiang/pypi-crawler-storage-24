# Easy Image Resizer

A simple Python library to resize images easily while maintaining aspect ratio, scaling by percentage, or setting explicit width/height.

## Installation

```bash
pip install easy-image-resizer
```

*(Note: Currently this is a template. You can install it locally using `pip install .`)*

## Usage

```python
from easy_image_resizer import resize_image

# Resize with a specific width and height
resize_image("input.jpg", "output.jpg", width=800, height=600)

# Resize by percentage (e.g. 50% of the original size)
resize_image("input.jpg", "output_half.jpg", percentage=50)

# Resize by width (height is calculated automatically to maintain aspect ratio)
resize_image("input.jpg", "output_width.jpg", width=1024)

# Resize by height (width is calculated automatically to maintain aspect ratio)
resize_image("input.jpg", "output_height.jpg", height=768)
```
