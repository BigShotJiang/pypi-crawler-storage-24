import os
from PIL import Image

def resize_image(input_path: str, output_path: str, width: int = None, height: int = None, percentage: float = None):
    """
    Resizes an image. You can specify a new width and height, or a percentage to scale the image.
    If you only specify width or height, the aspect ratio will be maintained.
    
    :param input_path: Path to the input image.
    :param output_path: Path to save the resized image.
    :param width: Target width in pixels.
    :param height: Target height in pixels.
    :param percentage: Scale percentage (e.g., 50.0 for 50%).
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")
        
    if percentage is None and width is None and height is None:
        raise ValueError("You must specify either width, height, or percentage.")
        
    with Image.open(input_path) as img:
        original_width, original_height = img.size
        
        if percentage is not None:
            new_width = int(original_width * (percentage / 100))
            new_height = int(original_height * (percentage / 100))
        elif width is not None and height is not None:
            new_width = width
            new_height = height
        elif width is not None:
            aspect_ratio = original_height / original_width
            new_width = width
            new_height = int(width * aspect_ratio)
        elif height is not None:
            aspect_ratio = original_width / original_height
            new_width = int(height * aspect_ratio)
            new_height = height
            
        # Resize using LANCZOS for high quality
        resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        resized_img.save(output_path)
        
    return output_path