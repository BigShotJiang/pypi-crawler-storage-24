"""Learning asset resolver package."""
