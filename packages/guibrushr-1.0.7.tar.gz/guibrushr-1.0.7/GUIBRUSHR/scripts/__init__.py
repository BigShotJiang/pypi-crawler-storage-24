"""
Scripts Module for GUIBRUSHR

Contains utility scripts for setup, data download, and maintenance.
"""

__version__ = "1.0.7"
__author__ = "GUIBRUSHR Team"
__description__ = "Scripts Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import scripts submodules when accessed (prevents circular imports).
    """
    if name in {"downloader", "edit_yaml", "edit_config", "edit_db"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["downloader", "edit_yaml", "edit_config", "edit_db"]

