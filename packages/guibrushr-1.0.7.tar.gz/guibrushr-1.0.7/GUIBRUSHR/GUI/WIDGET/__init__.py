"""
Widget Module

Contains custom widget components for the GUI.
"""

__version__ = "1.0.7"
__author__ = "GUIBRUSHR Team"
__description__ = "Widget Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
def __getattr__(name):
    """
    Lazy import widget components when accessed (prevents circular imports).
    """
    # Currently no components defined, but structure is ready for future additions
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = []
