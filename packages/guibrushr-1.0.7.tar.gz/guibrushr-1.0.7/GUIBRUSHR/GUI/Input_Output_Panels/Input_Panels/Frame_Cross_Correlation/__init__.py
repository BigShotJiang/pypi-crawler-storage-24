"""
Frame Cross Correlation Module

Contains cross-correlation analysis frame components.
"""

__version__ = "1.0.7"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Cross Correlation Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import cross-correlation components when accessed (prevents circular imports).
    """
    if name in {'Frame_sum_CC', 'Notebook_Cross_Correlation', 'Frame_run_CC', 'Frame_LH'}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'Frame_sum_CC',
    'Notebook_Cross_Correlation',
    'Frame_run_CC',
    'Frame_LH'
]