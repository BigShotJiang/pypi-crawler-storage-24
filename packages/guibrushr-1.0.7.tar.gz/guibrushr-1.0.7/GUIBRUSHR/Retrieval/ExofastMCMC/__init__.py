"""
ExofastMCMC Module

Contains MCMC-based retrieval algorithms and implementations.
"""

__version__ = "1.0.7"
__author__ = "GUIBRUSHR Team"
__description__ = "ExofastMCMC Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import MCMC components when accessed (prevents circular imports).
    """
    # Currently no components defined, but structure is ready for future additions
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = []
