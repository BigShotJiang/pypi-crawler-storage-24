from __future__ import annotations

import os
from pathlib import Path


def discover_files(base_path: Path, extensions: set[str], exclude_dirs: set[str]) -> list[Path]:
    base_path = base_path.resolve()
    ext_lower = {ext.lower() for ext in extensions}
    exclude_lower = {name.lower() for name in exclude_dirs}
    discovered: list[Path] = []

    for root, dirs, files in os.walk(base_path):
        dirs[:] = [directory for directory in dirs if directory.lower() not in exclude_lower]
        root_path = Path(root)
        for file_name in files:
            path = root_path / file_name
            if path.suffix.lower() in ext_lower:
                discovered.append(path)

    return sorted(discovered)
