"""SQL analysis and suggestion modules."""

from .drift_watch import build_schema_drift_report
from .db_introspection import introspect_existing_indexes_from_live_db
from .explain_validation import validate_suggestions_with_explain
from .index_suggester import suggest_indexes
from .query_advisories import analyze_query_advisories
from .schema_checks import apply_schema_checks, extract_existing_indexes
from .sql_ast import analyze_sql_candidates
from .workload import build_workload_stats

__all__ = [
    "analyze_query_advisories",
    "analyze_sql_candidates",
    "apply_schema_checks",
    "build_schema_drift_report",
    "build_workload_stats",
    "extract_existing_indexes",
    "introspect_existing_indexes_from_live_db",
    "suggest_indexes",
    "validate_suggestions_with_explain",
]
