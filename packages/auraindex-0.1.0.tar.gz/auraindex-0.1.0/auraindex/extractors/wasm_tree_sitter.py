from __future__ import annotations

import json
import subprocess
from pathlib import Path

from auraindex.models import QueryCandidate, QueryContext
from auraindex.utils.text import normalize_whitespace

SUFFIX_LANGUAGE_MAP = {
    ".py": "python",
    ".php": "php",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
}


class WasmTreeSitterExtractor:
    """Tree-sitter WASM adapter for Python, JS/TS, and PHP source files."""

    def __init__(self, script_path: Path | None = None):
        self.script_path = script_path or Path(__file__).resolve().parents[2] / "scripts" / "wasm_sql_extractor.mjs"
        self.timeout_seconds = 25
        self._auto_grammar_dir = self._discover_default_grammar_dir()

    def extract_file(self, file_path: Path) -> tuple[list[QueryCandidate], list[str]]:
        warnings: list[str] = []
        suffix = file_path.suffix.lower()
        language = SUFFIX_LANGUAGE_MAP.get(suffix)

        if language is None:
            return [], warnings

        resolved_grammar_dir = self._auto_grammar_dir
        if not resolved_grammar_dir:
            warnings.append(
                "WASM extraction requires local tree-sitter-* grammar packages in node_modules. "
                "Run: npm install tree-sitter-python tree-sitter-javascript tree-sitter-typescript tree-sitter-php. "
                f"Skipping {file_path}."
            )
            return [], warnings

        if not self.script_path.exists():
            warnings.append(f"WASM extractor script not found: {self.script_path}")
            return [], warnings

        command = [
            "node",
            str(self.script_path),
            "--file",
            str(file_path),
            "--lang",
            language,
            "--grammar-dir",
            str(resolved_grammar_dir),
        ]

        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
            )
        except FileNotFoundError:
            warnings.append("Node.js executable not found. Install Node.js to enable WASM extraction.")
            return [], warnings
        except subprocess.TimeoutExpired:
            warnings.append(f"WASM extractor timed out for {file_path}.")
            return [], warnings

        if completed.returncode != 0:
            detail = completed.stderr.strip() or completed.stdout.strip() or "unknown error"
            warnings.append(f"WASM extractor failed for {file_path}: {detail}")
            return [], warnings

        try:
            payload = json.loads(completed.stdout or "{}")
        except json.JSONDecodeError:
            warnings.append(f"WASM extractor returned invalid JSON for {file_path}.")
            return [], warnings

        for warning in payload.get("warnings", []):
            warnings.append(str(warning))

        candidates: list[QueryCandidate] = []
        for item in payload.get("queries", []):
            sql_text = normalize_whitespace(str(item.get("sql", "")).strip())
            if not sql_text:
                continue
            line = int(item.get("line", 1))
            confidence = float(item.get("confidence", 0.7))
            metadata = item.get("metadata", {})
            if not isinstance(metadata, dict):
                metadata = {"raw_metadata": metadata}

            candidates.append(
                QueryCandidate(
                    sql=sql_text,
                    context=QueryContext(
                        file_path=str(file_path),
                        line=line,
                        function=None,
                        language=language,
                        source_kind="wasm_sql",
                    ),
                    confidence=confidence,
                    metadata=metadata,
                )
            )

        return candidates, warnings

    def _discover_default_grammar_dir(self) -> Path | None:
        root = Path(__file__).resolve().parents[2]
        node_modules_dir = root / "node_modules"
        if not node_modules_dir.exists():
            return None
        return node_modules_dir
