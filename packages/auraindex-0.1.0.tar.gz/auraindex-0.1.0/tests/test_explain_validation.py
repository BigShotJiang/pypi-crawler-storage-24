from pathlib import Path

from auraindex.pipeline import ScanConfig, run_scan


def test_explain_validation_warns_when_not_configured(tmp_path: Path) -> None:
    sample = tmp_path / "query.sql"
    sample.write_text(
        """
SELECT id
FROM users
WHERE email = 'a@example.com';
SELECT id
FROM users
WHERE email = 'a@example.com';
""".strip(),
        encoding="utf-8",
    )

    result = run_scan(
        ScanConfig(
            target_path=tmp_path,
            dialect="postgres",
            min_support=1,
            max_indexes_per_table=4,
            extensions={".sql"},
            explain_validate=True,
        )
    )

    assert result.suggestions
    assert any("EXPLAIN validation enabled but no runner configured" in warning for warning in result.warnings)
    explain_summary = result.metadata.get("explain_validation", {})
    assert explain_summary.get("enabled") is True
