from pathlib import Path

from auraindex.pipeline import ScanConfig, run_scan


def test_schema_checks_skip_existing_exact_index(tmp_path: Path) -> None:
    sample = tmp_path / "schema_and_queries.sql"
    sample.write_text(
        """
CREATE INDEX IF NOT EXISTS ix_users_email ON users (email);
SELECT id FROM users WHERE email = 'a@example.com';
SELECT id FROM users WHERE email = 'a@example.com';
""".strip(),
        encoding="utf-8",
    )

    result = run_scan(
        ScanConfig(
            target_path=tmp_path,
            dialect="postgres",
            min_support=1,
            max_indexes_per_table=4,
            extensions={".sql"},
        )
    )

    assert result.suggestions == []
    schema_meta = result.metadata.get("schema_checks", {})
    summary = schema_meta.get("summary", {})
    assert summary.get("discovered_existing_indexes", 0) >= 1
    assert summary.get("skipped_suggestions", 0) >= 1


def test_schema_checks_can_be_disabled(tmp_path: Path) -> None:
    sample = tmp_path / "schema_and_queries.sql"
    sample.write_text(
        """
CREATE INDEX IF NOT EXISTS ix_users_email ON users (email);
SELECT id FROM users WHERE email = 'a@example.com';
SELECT id FROM users WHERE email = 'a@example.com';
""".strip(),
        encoding="utf-8",
    )

    result = run_scan(
        ScanConfig(
            target_path=tmp_path,
            dialect="postgres",
            min_support=1,
            max_indexes_per_table=4,
            extensions={".sql"},
            enable_schema_checks=False,
        )
    )

    assert result.suggestions
