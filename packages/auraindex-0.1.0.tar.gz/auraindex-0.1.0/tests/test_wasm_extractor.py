from pathlib import Path

from auraindex.extractors.wasm_tree_sitter import WasmTreeSitterExtractor


def test_wasm_extractor_warns_when_script_missing(tmp_path: Path) -> None:
    sample = tmp_path / "service.py"
    sample.write_text(
        """
def get_user(conn, user_id):
    return conn.execute("SELECT id FROM users WHERE id = %s", (user_id,))
""".strip(),
        encoding="utf-8",
    )

    extractor = WasmTreeSitterExtractor(script_path=tmp_path / "missing-wasm-script.mjs")
    candidates, warnings = extractor.extract_file(sample)

    assert candidates == []
    assert warnings
    assert "WASM extractor script not found" in warnings[0]


def test_wasm_extractor_warns_when_grammars_missing(tmp_path: Path) -> None:
    sample = tmp_path / "service.py"
    sample.write_text('print("hello")', encoding="utf-8")

    extractor = WasmTreeSitterExtractor()
    extractor._auto_grammar_dir = None
    candidates, warnings = extractor.extract_file(sample)

    assert candidates == []
    assert warnings
    assert "WASM extraction requires local tree-sitter-* grammar packages" in warnings[0]


def test_wasm_extractor_ignores_unsupported_file_type(tmp_path: Path) -> None:
    sample = tmp_path / "notes.txt"
    sample.write_text("SELECT * FROM users", encoding="utf-8")
    extractor = WasmTreeSitterExtractor()
    candidates, warnings = extractor.extract_file(sample)
    assert candidates == []
    assert warnings == []
