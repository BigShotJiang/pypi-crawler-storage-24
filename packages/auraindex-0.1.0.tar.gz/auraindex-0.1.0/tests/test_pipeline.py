from pathlib import Path

from auraindex.pipeline import ScanConfig, run_scan


def test_pipeline_runs_end_to_end_on_sample_project(tmp_path: Path) -> None:
    sample = tmp_path / "query.sql"
    sample.write_text(
        """
SELECT id
FROM users
WHERE status = 'active'
ORDER BY created_at DESC;
""".strip(),
        encoding="utf-8",
    )

    config = ScanConfig(
        target_path=tmp_path,
        dialect="postgres",
        min_support=1,
        max_indexes_per_table=3,
        extensions={".sql"},
    )
    result = run_scan(config)

    assert result.scanned_files
    assert result.candidates
    assert result.parsed_queries
    assert result.suggestions
    assert "impact" in result.suggestions[0].metadata
    assert "index_type" in result.suggestions[0].metadata
    assert "query_advisories" in result.metadata
