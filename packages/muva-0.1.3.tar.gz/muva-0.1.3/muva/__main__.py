"""Allow running with `python -m muva`."""

from muva.cli import main

main()
