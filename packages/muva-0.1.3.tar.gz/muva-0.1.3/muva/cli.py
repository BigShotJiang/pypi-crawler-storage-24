#!/usr/bin/env python3
"""muva - terminal IDE entry point."""

import curses
import os
import sys


def _run(stdscr):
    from muva.app import App

    try:
        app = App(stdscr)
        app.run()
    except SystemExit:
        pass
    except KeyboardInterrupt:
        pass


def main():
    os.environ.setdefault("ESCDELAY", "25")
    curses.wrapper(_run)


if __name__ == "__main__":
    main()
