"""Base view interface for muv IDE."""


class BaseView:
    """Abstract base for all views. Each view fills the screen below the tab bar."""

    def draw(self, stdscr, h, w, y_offset):
        """Render the view. h/w = available size, y_offset = first row (after tab bar)."""
        raise NotImplementedError

    def handle_key(self, key):
        """Handle a keypress. Return an action string or None.

        Common actions:
            "back"          - pop this view
            "open:{path}"   - open file in editor
            "quit"          - exit the application
        """
        return None

    def on_enter(self):
        """Called when this view becomes the active view."""
        pass

    def on_leave(self):
        """Called when this view is no longer the active view."""
        pass

    @property
    def title(self):
        """Tab bar display title."""
        return "View"
