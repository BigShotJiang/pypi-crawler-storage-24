"""View modules for muv IDE."""
