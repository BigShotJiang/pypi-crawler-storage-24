"""muva - a terminal IDE."""

__version__ = "0.1.3"
