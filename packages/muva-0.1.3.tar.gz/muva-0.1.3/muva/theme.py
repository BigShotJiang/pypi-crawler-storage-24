"""GitHub Dark 256-color theme and curses color pair initialization."""

import curses

# GitHub Dark palette (256-color approximations)
# Based on github.com's dark default code theme
PALETTE = {
    "bg":       234,   # #1c2128 -> 234 (~#1c1c1c)
    "fg":       252,   # #e6edf3 -> 252 (~#d0d0d0)
    "comment":  245,   # #8b949e -> 245 (~#8a8a8a)
    "string":   110,   # #a5d6ff -> 110 (~#87afd7)
    "number":   75,    # #79c0ff -> 75  (~#5fafff)
    "keyword":  174,   # #ff7b72 -> 174 (~#d78787)
    "function": 183,   # #d2a8ff -> 183 (~#d7afff)
    "operator": 252,   # #e6edf3 -> same as fg (subtle)
    "class":    215,   # #ffa657 -> 215 (~#ffaf5f)
    "builtin":  75,    # #79c0ff -> 75  (~#5fafff)
    "error":    167,   # #f85149 -> 167 (~#d75f5f)
    "lineno":   239,   # #484f58 -> 239 (~#4e4e4e)
    "status":   236,   # #161b22 -> 236 (~#303030)
    "statusfg": 252,   # light fg on dark status bar
    "visual":   237,   # #264f78 -> 237 (muted selection)
    "cursor":   252,   # cursor line fg
    "search":   136,   # #e3b341 -> 136 (~#af8700)
}

# Backward compat alias
DRACULA = PALETTE

# Tab bar colors — subtle, muted
TAB_BG = 235        # slightly lighter than bg
TAB_ACTIVE_FG = 252  # bright fg
TAB_INACTIVE_FG = 243  # muted grey

# Named color pair IDs (assigned during init)
_color_pairs = {}
_next_pair = [1]


def init_colors():
    """Initialize all color pairs. Call once after curses.start_color()."""
    global _color_pairs
    _color_pairs = {}
    pid = 1
    bg = PALETTE["bg"]

    # One pair per named foreground color on bg
    for name, fg in PALETTE.items():
        if name == "bg":
            continue
        curses.init_pair(pid, fg, bg)
        _color_pairs[name] = pid
        pid += 1

    # Visual selection: fg on muted blue bg
    curses.init_pair(pid, PALETTE["fg"], PALETTE["visual"])
    _color_pairs["visual_sel"] = pid
    pid += 1

    # Search highlight: black on muted yellow
    curses.init_pair(pid, 16, PALETTE["search"])
    _color_pairs["search_hl"] = pid
    pid += 1

    # Status bar: light fg on darker bg
    curses.init_pair(pid, PALETTE["statusfg"], PALETTE["status"])
    _color_pairs["statusbar"] = pid
    pid += 1

    # Default: fg on bg
    curses.init_pair(pid, PALETTE["fg"], PALETTE["bg"])
    _color_pairs["default"] = pid
    pid += 1

    # Tab bar: active tab — white on slightly lighter bg
    curses.init_pair(pid, TAB_ACTIVE_FG, TAB_BG)
    _color_pairs["tab_active"] = pid
    pid += 1

    # Tab bar: inactive tab — grey on bg
    curses.init_pair(pid, TAB_INACTIVE_FG, TAB_BG)
    _color_pairs["tab_inactive"] = pid
    pid += 1

    # Tab bar background
    curses.init_pair(pid, PALETTE["fg"], TAB_BG)
    _color_pairs["tab_bg"] = pid
    pid += 1

    # Explorer-specific pairs
    # Dirs: muted blue on bg
    curses.init_pair(pid, 75, bg)
    _color_pairs["explorer_dir"] = pid
    pid += 1

    # Selected: muted orange on bg
    curses.init_pair(pid, 215, bg)
    _color_pairs["explorer_sel"] = pid
    pid += 1

    # Cursor: fg on subtle highlight bg
    curses.init_pair(pid, PALETTE["fg"], 237)
    _color_pairs["explorer_cursor"] = pid
    pid += 1

    # Cursor+selected: orange on subtle highlight bg
    curses.init_pair(pid, 215, 237)
    _color_pairs["explorer_cur_sel"] = pid
    pid += 1

    # Symlink: muted purple on bg
    curses.init_pair(pid, 139, bg)
    _color_pairs["explorer_link"] = pid
    pid += 1

    # Executable: muted green on bg
    curses.init_pair(pid, 108, bg)
    _color_pairs["explorer_exec"] = pid
    pid += 1

    # Header: fg on slightly lighter bg
    curses.init_pair(pid, PALETTE["fg"], 235)
    _color_pairs["explorer_header"] = pid
    pid += 1

    # Fold line highlight: fg on slightly lighter bg
    curses.init_pair(pid, PALETTE["fg"], 236)
    _color_pairs["fold_line"] = pid
    pid += 1

    # Fold marker text: comment color on fold bg
    curses.init_pair(pid, PALETTE["comment"], 236)
    _color_pairs["fold_marker"] = pid
    pid += 1

    _next_pair[0] = pid + 1


def cp(name):
    """Get curses color_pair attribute by name."""
    return curses.color_pair(_color_pairs.get(name, 0))
