"""Configuration settings for muv IDE."""

LEADER_KEY = ord(" ")  # Space
LEADER_TIMEOUT_MS = 500

ROOT_LOCK_DEFAULT = True

# Shell preference
SHELL = None  # Auto-detect: zsh > bash

TAB_WIDTH = 4
SCROLL_MARGIN = 3
