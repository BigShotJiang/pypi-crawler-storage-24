# TermiChart — Python SDK

High-performance terminal charting SDK built in Rust with native Python bindings. Render line charts, candlestick charts, bar charts, histograms, and sparklines directly in the terminal.

## Screenshots

### Line Chart
![Line Chart](https://raw.githubusercontent.com/HeyElsa/terminal-chart/main/assets/line_chart.svg)

### Candlestick Chart
![Candlestick Chart](https://raw.githubusercontent.com/HeyElsa/terminal-chart/main/assets/candlestick_chart.svg)

### Bar Chart
![Bar Chart](https://raw.githubusercontent.com/HeyElsa/terminal-chart/main/assets/bar_chart.svg)

### Sparkline
![Sparkline](https://raw.githubusercontent.com/HeyElsa/terminal-chart/main/assets/sparkline.svg)

## Installation

```sh
pip install termichart
```

## Quick Start

### Line Chart

```python
import termichart

chart = termichart.PyChart("line")
chart.size(80, 20)
chart.set_title("Sensor Data")
for i in range(15):
    chart.add_point(float(i), 10.0 + i * 1.5 + (i % 3) * 2.0)
chart.show()
```

### Candlestick Chart

```python
import termichart

chart = termichart.PyChart("candlestick")
chart.size(80, 20)
chart.set_title("BTC/USDT")
chart.add_candle(0, 100.0, 110.0, 95.0, 105.0, 1000.0)
chart.add_candle(1, 105.0, 115.0, 100.0, 112.0, 1200.0)
chart.add_candle(2, 112.0, 118.0, 108.0, 110.0, 900.0)
chart.show()
```

### Load from JSON

```python
import termichart

chart = termichart.PyChart("candlestick")
chart.size(80, 20)
json_data = termichart.load_json("data.json")
chart.load_json(json_data)
chart.show()
```

## API

| Method | Description |
|--------|-------------|
| `PyChart(type)` | Create chart (`"line"`, `"candlestick"`, `"bar"`, `"histogram"`) |
| `.size(w, h)` | Set chart dimensions |
| `.set_title(str)` | Set chart title |
| `.add_point(x, y)` | Add a data point (line/bar/histogram) |
| `.add_candle(time, open, high, low, close, volume)` | Add OHLCV candle |
| `.load_json(str)` | Load data from JSON string |
| `.render()` | Return chart as ANSI string |
| `.show()` | Print chart to terminal |
| `load_json(path)` | Read JSON file to string |

## Chart Types

- **Line** — Smooth line charts with area fill using Unicode half-block characters
- **Candlestick** — OHLCV charts with wicks and colored bodies (green/red)
- **Bar** — Vertical bar charts
- **Histogram** — Distribution histograms

## Built with Rust

TermiChart's core engine is written in Rust for maximum performance. The Python bindings are generated via [PyO3](https://pyo3.rs/) and built with [maturin](https://www.maturin.rs/), giving you native speed with a Pythonic API.

See the full project at [github.com/HeyElsa/terminal-chart](https://github.com/HeyElsa/terminal-chart).

## License

MIT
