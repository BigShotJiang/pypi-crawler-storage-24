import os
import polars as pl
import ASHC_v3 as ashc
from ASHC_v3.CommonFunction import Polars_toDict

def initiateConfig(reportDir="C:/Reports"):
    """This Function initializes this library with various default parameters,
    It is very important to call this function before using any other functions from ASHC_v3"""
    
    ashc.output_folder =        os.path.join(reportDir, 'Output')
    ashc.combinedFilePath = os.path.join(reportDir, 'Output', 'Combined', '*.csv')
    ashc.budFile =          os.path.join(reportDir, 'Data', 'Budget', '1.1a._DAILY_SALES___TY_vs_PY*.csv')
    ashc.kpiFile =          os.path.join(reportDir, 'Data', 'KPI', '*.csv')
    ashc.purchDateFiles =   os.path.join(reportDir, 'Data', 'PurchaseData', '*.csv.gz')
    ashc.saleDumpFiles =    os.path.join(reportDir, 'Data', "SalesData", '*.csv.gz')
    ashc.stockDumpFiles =   os.path.join(reportDir, 'Data', "StockData", '*.csv.gz')
    ashc.offerFile =        os.path.join(reportDir, 'Data', 'Configs', 'Offer_Detail.csv')
    ashc.JacadiMaster =     os.path.join(reportDir, 'Data', "MasterFiles", 'JC-Master.xlsx')
    ashc.OkaidiMaster =     os.path.join(reportDir, 'Data', "MasterFiles", 'OK-Master.xlsx')
    ashc.PerfoisMaster =    os.path.join(reportDir, 'Data', "MasterFiles", 'PA-Master.xlsx')
    ashc.UndizMaster =      os.path.join(reportDir, 'Data', "MasterFiles", 'UZ-Master.xlsx')
    ashc.VincciMaster =     os.path.join(reportDir, 'Data', "MasterFiles", 'VI-Master.xlsx')
    ashc.YRMaster =         os.path.join(reportDir, 'Data', "MasterFiles", 'YR-Master.xlsx')
    ashc.LSMaster =         os.path.join(reportDir, 'Data', "MasterFiles", 'LS-Master.xlsx')

    ashc.downloadFolder = "C:\\"
    ashc.dataFolder =        os.path.join(reportDir, 'Data')
    ashc.saleOutFolder =     os.path.join(reportDir, 'Data', "SalesData")
    ashc.saleOfferFolder =   os.path.join(reportDir, 'Data', "SaleOffer")
    ashc.stockOutFolder =    os.path.join(reportDir, 'Data', "StockData")
    ashc.purchOutFolder =    os.path.join(reportDir, 'Data', "PurchaseData")
    ashc.masterFileFolder =  os.path.join(reportDir, 'Data', "MasterFiles")
    ashc.okaidiImageFolder = os.path.join(reportDir, 'Data','Images', 'Okaidi')
    print("Config initiated")
    
    configData = pl.read_excel(source=ashc.xlConfigFile,sheet_name="StoreMaster",infer_schema_length=0,)    #engine_options={"skip_empty_lines": True},
    lflData = pl.read_excel(source=ashc.xlConfigFile,sheet_name="LFLMaster",infer_schema_length=0,)         #engine_options={"skip_empty_lines": True},
    dateData = pl.read_excel(source=ashc.xlConfigFile,sheet_name="DateMaster",infer_schema_length=0,)       #schema_overrides={"Date(Month2nd)":pl.Datetime},engine_options={"skip_empty_lines": True},
    try:
        dateData = dateData.with_columns(pl.col('Date(Month2nd)').str.to_datetime())
    except:
        print(" ")
    #----------------------Store Master---------------------------------------------
    ashc.ShortStoreName = Polars_toDict(configData, 'Location Code', 'ShortName')
    ashc.StoreName = Polars_toDict(configData, 'Location Code', 'StoreName')
    ashc.BrandName = Polars_toDict(configData, 'Location Code', 'Brand Code')
    ashc.Country = Polars_toDict(configData, 'Location Code', 'Country')
    ashc.City = Polars_toDict(configData, 'Location Code', 'City')
    ashc.LocationType = Polars_toDict(configData, 'Location Code', 'Location Type')
    ashc.Status = Polars_toDict(configData, 'Location Code', 'Status')
    ashc.Area = Polars_toDict(configData, 'Location Code', 'Store Size')
    ashc.OpeningDate = Polars_toDict(configData, 'Location Code', 'OpeningDate')
    ashc.LocCode = Polars_toDict(configData, 'Name', 'Location Code')
    #--------------------------------------------------------------------------------
    ashc.Year_ = Polars_toDict(dateData, 'Date(Month2nd)', 'Year')
    ashc.Qtr_ = Polars_toDict(dateData, 'Date(Month2nd)', 'Quarter')
    ashc.Month_ = Polars_toDict(dateData, 'Date(Month2nd)', 'Month')
    ashc.Week_ = Polars_toDict(dateData, 'Date(Month2nd)', 'WeekNo')
    ashc.Lyty_ = Polars_toDict(dateData, 'Date(Month2nd)', 'Comp')
    #--------------------------------------------------------------------------------
    ashc.Lfl = Polars_toDict(lflData, 'Combo', 'Status(LFL)')
    #--------------------------------------------------------------------------------
    warehouseLocation = configData.filter(pl.col('Location Type').is_in(['Warehouse','Damage']))
    ashc.delLocation = warehouseLocation['Location Code'].unique().to_list()

    damageLocation = configData.filter(pl.col('Location Type').eq('Damage'))
    ashc.zeroStockLocation = damageLocation['Location Code'].unique().to_list()
    