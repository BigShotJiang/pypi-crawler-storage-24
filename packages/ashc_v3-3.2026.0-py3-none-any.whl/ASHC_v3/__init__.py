# This Python file uses the following encoding: utf-8
import os,sys
import polars as pl
import datetime as dt

__all__ = ["initiateConfig","calculateFCCost","changeFWSeason","cummelativeSale","dictMerge","discountSlab","extractStyleSale","fnAgeMap","fnCurrencyConverter","jacadiWeeklySellthruReport","JCMerchHier",
           "makeCSV","makeDateIndex","makeDateRangeDict","makeMTD_YTDIndex","makeSaleSeasonDict","makeSaleSeasonIndex","MapOffer","okaidiWeeklyBestSellerReport","okaidiWeeklySellthruReport",
           "Polars_toDict","prepareBudgetFiles","prepareKPIFiles","prepareSaleDF","prepareStockDF","removeWarehouseSale","removeWarehouseSaleFromCombined","returnFirstAndLastPurchDate","returnUnitCost"]

dataTypeForAll = {
    "ATV":pl.String,"Bar Code":pl.String,"Brand":pl.String,"Location":pl.String,"Barcode":pl.String,"Combo":pl.String,"Offer":pl.String,"Brand Code":pl.String,"Buyers":pl.String,
    "Buyers with Traffic":pl.Int32,"Category":pl.String,"CF Store Status":pl.String,"City":pl.String,"Closing Ratio":pl.Float32,"Closing Stock":pl.Float32,"Colour":pl.String,
    "Colour Code":pl.String,"Comparable":pl.String,"Cord Sets":pl.String,"CostValue":pl.Float32,"Country":pl.String,"Country Region Code":pl.String,"Current Retail Price":pl.Float32,
    "Date":pl.String,"Date Day":pl.String,"Date Day Description":pl.String,"Date Day Number":pl.String,"Date Month":pl.String,"Date Month Description":pl.String,"Date Month Number":pl.String,
    "Date Year":pl.String,"Date Year Number":pl.String,"Description":pl.String,"Division":pl.String,"Family":pl.String,"Fashion Type":pl.String,"First Purchase Date":pl.Datetime,
    "Image Reference":pl.String,"IPC":pl.String,"Item Category":pl.String,"Item Class":pl.String,"Item No_":pl.String,"Item Sub Class":pl.String,"Last Purchase Date":pl.Datetime,"LFL":pl.String,
    "LOC_Item":pl.String,"LOC_Item1":pl.String,"LOC_Item2":pl.String,"LOC_Item3":pl.String,"Location Code":pl.String,"Location Name":pl.String,"Mall Owner":pl.String,"MTD CostValue":pl.Float32,
    "MTD SaleQty":pl.Float32,"MTD SaleValue":pl.Float32,"Post Code":pl.String,"Posting Date":pl.Datetime,"Product Group":pl.String,"Profit Centre Code":pl.String,"Profit Centre Name":pl.String,
    "Remarks":pl.String,"SaleQty":pl.Float32,"Sales Amount":pl.String,"Sales Amount LCY":pl.String,"SaleValue":pl.Float32,"Saved":pl.String,"Season":pl.String,"Season Code":pl.String,
    "Short Name":pl.String,"Size":pl.String,"Sold Qty":pl.String,"Store Closing Date Day":pl.String,"Store Closing Date Day Description":pl.String,"Store Closing Date Day Number":pl.String,
    "Store Closing Date Month":pl.String,"Store Closing Date Month Description":pl.String,"Store Closing Date Month Number":pl.String,"Store Closing Date Year":pl.String,
    "Store Closing Date Year Number":pl.String,"Store Opening Date":pl.String,"Store Opening Date Month":pl.String,"Store Opening Date Month Description":pl.String,"Store Opening Date Month Number":pl.String,
    "Store Opening Date Year":pl.String,"Store Opening Date Year Number":pl.String,"Store Size Square Meters":pl.Float32,"StoreName":pl.String,"Style Code":pl.String,"Sub Class":pl.String,
    "SubFamily":pl.String,"Target":pl.String,"Target Amout":pl.String,"Target Amout LCY":pl.Float32,"Theme":pl.String,"Type":pl.String,"Unit Cost":pl.Float32,"Unit Price":pl.Float32,
    "Unit Price Including VAT":pl.Float32,"Var %":pl.String,"Visitors":pl.String,"WTD CostValue":pl.Float32,"WTD SaleQty":pl.Float32,"WTD SaleValue":pl.Float32,"YTD CostValue":pl.Float32,
    "YTD SaleQty":pl.Float32,"YTD SaleValue":pl.Float32,"First_purchase_date":pl.Datetime,"Last_purchase_date":pl.Datetime,"Original Retail":pl.Float32,"Sale Price":pl.Float32}

selectSeason = [
    "All","FLW","NOS","28H","28E","27H","27E","26H","26E","25H","25E","24H","24E","23H","23E","2023-2","2023-01","2024-1","2024-2","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2",
    "2028-1","2028-2","2612","2611","2610","2609","2608","2607","2606","2605","2604","2603","2602","2601","2512","2511","2510","2509","2508","2507","2506","2505","2504","2503","2502",
    "2501","2412","2411","2410","2409","2408","2407","2406","2405","2404","2403","2402","2401","2312","2311","2310","2309","2308","2307","2306","2305","2304","2303","2302","2301","26FW",
    "26SS","25FW","26SS","24FW","24SS","23FW","23SS"]

Sellthru_common_Seasons = {
    "2306":"24SS","2307":"24SS","2308":"24SS","2309":"24SS","2310":"24SS","2401":"24FW","2402":"24FW","2403":"24FW","2404":"24FW","2405":"24FW","2406":"24FW","2407":"24FW","2408":"25SS",
    "2409":"25SS","2410":"25SS","2411":"25SS","2412":"25SS","2501":"25SS","2502":"25FW","2503":"25FW","2504":"25FW","2505":"25FW","2506":"25FW","2507":"25FW","2508":"25FW","2509":"25FW",
    "2510":"26SS","2511":"26SS","2512":"26SS","2601":"26SS","2602":"26SS","2603":"26SS","2604":"26SS","2605":"26SS","2606":"26SS","2607":"26FW","2608":"26FW","2609":"26FW","2610":"26FW",
    "2611":"26FW","2612":"26FW","2023-1":"23SS","2023-2":"23FW","2024-1":"24SS","2024-2":"24FW","2025-1":"25SS","2025-2":"25FW","2026-1":"26SS","2026-2":"26FW","2027-1":"27SS",
    "2027-2":"27FW","2028-1":"28SS","2028-2":"28FW","24E":"24SS","24FW":"24FW","24H":"24FW","25E":"25SS","25H":"25FW","26E":"26SS","26H":"26FW","27E":"27SS","27H":"27FW","28E":"28SS",
    "28H":"28FW","24SS":"24SS","25SS":"25SS","25FW":"25FW","26SS":"26SS","26FW":"26FW","27SS":"27SS","27FW":"27FW","28SS":"28SS","28FW":"28FW","FLW":"26SS","NOS":"26SS"}

Sellthru_Season_Filter = [
    "2401","2402","2403","2404","2405","2406","2407","2408","2409","2410","2411","2412","2501","2502","2503","2504","2505","2506","2507","2508","2509","2510","2511","2512","2601","2602",
    "2603","2604","2605","2606","2607","2608","2609","2610","2611","2612","2023-1","2023-2","2024-1","2024-2","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2","2028-1","2028-2",
    "24E","24H","25E","25H","26E","26H","27E","27H","28E","28H","24FW","24SS","25FW","25SS","26SS","26FW","27SS","27FW","28SS","28FW","FLW","NOS"]

Sellthru_Season_Remarks = {
    "Non Permanent":"Non Carryover","Non Carryover":"Non Carryover","Permanent":"Carryover","NA":"Non Carryover","Carryover":"Carryover","Mini Product":"Carryover","Standard":"Carryover",
    "Ramadan":"Non Carryover","":"Carryover","Sample":"Carryover","Mini-Produit":"Carryover","Medium Product":"Carryover","Cleanser":"Carryover"}

combined_report_columns = [
    "Brand Code","Country","City","Location Code","StoreName","ShortName","StoreSize","Location Type","Status","Division","Product Group","Item Category","Item Class","Item Sub Class",
    "Theme","RefCode","Style Code","First Purchase Date","Last Receive Date","Colour Code","Size","Item No_","Season Code","Unit Price","Current Price","Unit Cost","ExchangeRate(AED)",
    "Cumm. SaleQty","Cumm. CostValue","Cumm. SaleValue","MTD SaleQty","MTD CostValue","MTD SaleValue","WTD SaleQty","WTD CostValue","WTD SaleValue","Closing Stock","StockCost","StockRetail",
    "StockOrgRetail","Purchased","Remarks","Combo2","Offer_Price","EOSS Discount","Disc.P"] # ,"Offer_Price","EOSS Discount","Disc%"
        
brandList01 = ['JC','PA','UZ','VI','YR','LS']           # 
yearList = ['2019','2020','2021','2022','2023','2024','2025','2026','2027']
monthList = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
monthDict = {1:"Jan",2:"Feb",3:"Mar",4:"Apr",5:"May",6:"Jun",7:"Jul",8:"Aug",9:"Sep",10:"Oct",11:"Nov",12:"Dec"}
exch_rate = {"AE":1.00000,"BH":9.74143,"OM":9.53929,"QA":1.00878,"KWT":12.00000}
ExchangeRatestoAED = {'UAE':1.00000,'QTR':1.00878,'OMN':9.53929,'BAH':9.74143,'KWT':12.00000}
ItemLedgerEntryType = {'Purchase':0,'Sales':1,'POS Adjustment':2,'Neg Adjustment':3,'Transfer':4,'Opening Stock':5}
fcSaleSeason = {"JC":"26E","OK":"26E","PA":"2026-1","UZ":"2026-1","VI":"2511","YR":"FLW","LS":"FLW"}

delLocation = []
zeroStockLocation = []

FC_Week = 8
fcCostDays = 56
mark = False
debugGen = False
configData = pl.DataFrame()
lflData = pl.DataFrame()
dateData = pl.DataFrame()
ShortStoreName = {}
StoreName = {}
BrandName = {}
Country = {}
City = {}
LocationType = {}
Status = {}
Area = {}
OpeningDate = {}
LocCode = {}
Year_ = {}
Qtr_ = {}
Month_ = {}
Week_ = {}
Lyty_ = {}
Lfl = {}
budFile = ''
kpiFile = ''
sysPriceFiles = ''
purchDateFiles = ''
stockDumpFiles = ''
offerFile = ''
UndizMaster = ''
VincciMaster = ''
YRMaster = ''
JacadiMaster = ''
OkaidiMaster = ''
PerfoisMaster = ''
LSMaster = ''
downloadFolder = ''
saleOutFolder = ''
saleOfferFolder = ''
stockOutFolder = ''
purchOutFolder = ''
masterFileFolder = ''
dataFolder = ''
okaidiImageFolder = ''
combinedFilePath = ''

last = dt.date(2026, 4, 30)
tod = dt.date.today()
currDir = os.getcwd()
# Move Macro(ASH).xlsm and ConfigFile.xlsx in ASHC_v3 folder
script_folder = os.path.dirname(os.path.abspath(__file__))
macroBook = os.path.join(script_folder,'Macro(ASH).xlsm')
xlConfigFile = os.path.join(script_folder,'ConfigFile.xlsx')
shj_disc_pdf = os.path.join(script_folder,'Shj_Form.pdf')

if (tod > last):
    sys.exit(0)
