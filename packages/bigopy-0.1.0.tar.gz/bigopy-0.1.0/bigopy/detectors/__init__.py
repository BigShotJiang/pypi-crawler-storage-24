"""Detector modules."""
