"""woltspace — build, gnaw, repeat."""

__version__ = "0.0.1"
