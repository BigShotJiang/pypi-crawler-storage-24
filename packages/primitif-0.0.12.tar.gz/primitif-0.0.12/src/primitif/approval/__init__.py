"""Primitif Approval — human-in-the-loop gate for AI agents.

Usage::

    from primitif import approval

    req = approval.create_request(
        "Send contract",
        context={"client": "Acme", "amount": 50000},
    )
    print(req.approval_url)  # share with the human

    status = approval.get_request(req.id)

Decorator usage::

    from primitif.approval import require_approval

    @require_approval
    def send_invoice(client, amount):
        billing.send(client, amount)

    req = send_invoice("Acme", 45000)  # returns ApprovalRequest

    # In your webhook handler:
    from primitif import approval
    approval.dispatch(event)  # runs send_invoice with original args
"""

from __future__ import annotations

import functools
import inspect
from typing import TYPE_CHECKING, Any, Callable, Literal

from primitif.approval.client import ApprovalAdmin
from primitif.approval.exceptions import (
    ApprovalAuthError,
    ApprovalNetworkError,
    ApprovalError,
    ApprovalNotFoundError,
    ApprovalRateLimitError,
    ApprovalServerError,
    ApprovalValidationError,
)
from primitif.approval.models import ApprovalRequest

if TYPE_CHECKING:
    from primitif._models import PaginatedList


# ---------------------------------------------------------------------------
# Lazy admin client — created on first use from PRIMITIF_API_KEY env var
# ---------------------------------------------------------------------------

_admin: ApprovalAdmin | None = None


def _get_client() -> ApprovalAdmin:
    global _admin
    if _admin is None:
        from primitif.client import Primitif
        _admin = Primitif().approval
    return _admin


# ---------------------------------------------------------------------------
# Module-level registry — decorated functions are stored here
# ---------------------------------------------------------------------------

_registry: dict[str, Callable] = {}


# ---------------------------------------------------------------------------
# Standalone decorator
# ---------------------------------------------------------------------------


def require_approval(
    fn: Callable | None = None,
    *,
    action: str | None = None,
    requested_by: str | None = None,
    callback_url: str | None = None,
) -> Callable:
    """Decorator that gates a function behind human approval.

    Reads ``PRIMITIF_API_KEY`` from the environment. No client setup needed.

    Can be used with or without parentheses: ``@require_approval`` or
    ``@require_approval(action="Deploy")``.

    When the human approves, call ``approval.dispatch(event)`` in your
    webhook handler to execute the original function automatically.

    Args:
        fn: The function to wrap. Passed automatically when used as
            ``@require_approval`` without parentheses.
        action: Human-readable action name shown to the approver.
            Defaults to the function name with underscores replaced by
            spaces (``send_invoice`` -> ``"Send invoice"``).
        requested_by: Optional agent or service identifier.
        callback_url: Optional webhook URL for direct callback.

    Returns:
        The decorated function. Each call returns an ApprovalRequest
        (status ``"pending"``). The original is accessible via
        ``wrapped.original``.

    Example::

        from primitif.approval import require_approval

        @require_approval
        def deploy(service, branch):
            run_pipeline(service, branch)

        req = deploy("api-gateway", "main")
        print(req.approval_url)  # share with the human

        # In your webhook handler:
        from primitif import approval
        approval.dispatch(event)  # runs deploy() with original args
    """

    def decorator(fn: Callable) -> Callable:
        resolved_action = action or fn.__name__.replace("_", " ").capitalize()

        if resolved_action in _registry:
            raise ValueError(f"Action {resolved_action!r} is already registered")
        _registry[resolved_action] = fn

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> ApprovalRequest:
            sig = inspect.signature(fn)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            context = dict(bound.arguments)

            return _get_client().create_request(
                resolved_action,
                context=context,
                requested_by=requested_by,
                callback_url=callback_url,
            )

        wrapper.original = fn  # type: ignore[attr-defined]
        return wrapper

    # Support both @require_approval and @require_approval(...)
    if fn is not None:
        return decorator(fn)
    return decorator


# ---------------------------------------------------------------------------
# Module-level functions — the simple import path
# ---------------------------------------------------------------------------


def create_request(
    action: str,
    *,
    context: dict[str, Any] | None = None,
    callback_url: str | None = None,
    requested_by: str | None = None,
) -> ApprovalRequest:
    """Create an approval request. Returns immediately with a pending status.

    Args:
        action: Human-readable description of the action awaiting
            approval (e.g. ``"Send contract to Acme"``).
        context: Arbitrary JSON dict passed to the approver and
            included in the webhook payload.
        callback_url: Optional URL for a direct webhook callback when
            the request is decided.
        requested_by: Optional agent or service identifier.

    Example:
        >>> from primitif import approval
        >>> req = approval.create_request(
        ...     "Send contract",
        ...     context={"client": "Acme", "amount": 50000},
        ... )
        >>> print(req.approval_url)
    """
    return _get_client().create_request(
        action,
        context=context,
        callback_url=callback_url,
        requested_by=requested_by,
    )


def get_request(request_id: str) -> ApprovalRequest:
    """Get the current status of an approval request.

    Args:
        request_id: The approval request ID.

    Example:
        >>> status = approval.get_request("apr_abc123")
        >>> print(status.status)
    """
    return _get_client().get_request(request_id)


def list_requests(
    *,
    status: Literal["pending", "approved", "rejected", "expired"] | None = None,
    limit: int = 20,
    cursor: str | None = None,
) -> PaginatedList[ApprovalRequest]:
    """List approval requests, optionally filtered by status.

    Args:
        status: Filter by status. Omit to list all.
        limit: Maximum number of requests per page. Defaults to 20.
        cursor: Pagination cursor from a previous response.

    Example:
        >>> for req in approval.list_requests(status="pending"):
        ...     print(req.action, req.approval_url)
    """
    return _get_client().list_requests(status=status, limit=limit, cursor=cursor)


def dispatch(event: dict) -> Any:
    """Execute the function registered for an approved webhook event.

    Verify the event with ``verify_webhook()`` before calling this.

    Args:
        event: The parsed webhook JSON body.

    Returns:
        The return value of the executed function, or None if the
        event status is not ``"approved"``.

    Raises:
        ApprovalError: If no handler is registered for the action.

    Example::

        from primitif import approval, verify_webhook

        @app.post("/webhook/approval")
        def handle():
            event = verify_webhook(
                body=request.data,
                signature=request.headers["X-Webhook-Signature"],
                secret="whsec_...",
            )
            approval.dispatch(event)
            return "", 200
    """
    if event.get("status") != "approved":
        return None

    # Minimal payload — fetch full record from API
    if "action" not in event and "request_id" in event:
        req = get_request(event["request_id"])
        action = req.action
        ctx = req.context or {}
    else:
        action = event.get("action", "")
        ctx = event.get("context") or {}

    fn = _registry.get(action)
    if fn is None:
        raise ApprovalError(
            message=f"No handler registered for action {action!r}",
            status_code=0,
        )

    # Validate context keys match the function's parameters
    sig = inspect.signature(fn)
    allowed_keys = set(sig.parameters.keys())
    actual_keys = set(ctx.keys())
    unexpected = actual_keys - allowed_keys
    if unexpected:
        raise ApprovalError(
            message=f"Unexpected keys in context for {action!r}: {unexpected}",
            status_code=0,
        )

    return fn(**ctx)


__all__ = [
    # Module-level functions
    "create_request",
    "get_request",
    "list_requests",
    "dispatch",
    "require_approval",
    # Classes
    "ApprovalAdmin",
    # Exceptions
    "ApprovalError",
    "ApprovalAuthError",
    "ApprovalNetworkError",
    "ApprovalNotFoundError",
    "ApprovalValidationError",
    "ApprovalRateLimitError",
    "ApprovalServerError",
    # Models
    "ApprovalRequest",
]
