"""Package resources for marimo anywidget assets."""
