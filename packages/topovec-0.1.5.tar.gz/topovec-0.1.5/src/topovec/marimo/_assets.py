from __future__ import annotations

import functools
from importlib import resources


_ASSET_PACKAGE = "topovec.marimo.assets"


@functools.lru_cache(maxsize=None)
def _read_asset_text(name: str) -> str:
    try:
        return resources.files(_ASSET_PACKAGE).joinpath(name).read_text(
            encoding="utf-8"
        )
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        raise RuntimeError(
            f"Missing marimo widget asset {name!r} in package {_ASSET_PACKAGE!r}. "
            "The installed distribution may have been built without widget assets."
        ) from exc


def camera_viewport_esm() -> str:
    return _read_asset_text("camera_viewport.js")


def camera_viewport_css() -> str:
    return _read_asset_text("camera_viewport.css")


def director_field_inspect_esm() -> str:
    return _read_asset_text("director_field_inspect.js")


def director_field_inspect_css() -> str:
    return _read_asset_text("director_field_inspect.css")
