"""Marimo adapter for the reusable TopoVec rendering model.

The marimo layer does not define scenes or renders itself. It binds existing
`topovec.mgl` scenes to anywidget state through :class:`RenderSession` and the
public `inspect(...)` helpers.
"""

from .camera_viewer import (
    DEFAULT_CONTROLS_TEXT,
    CameraViewportWidget,
    DirectorFieldView,
    RenderSession,
    apply_camera_command,
    camera_viewer,
    format_camera_summary,
    inspect,
    inspect_view,
    pil_image_to_data_url,
    restore_camera,
    serialize_camera,
)

__all__ = [
    "DEFAULT_CONTROLS_TEXT",
    "CameraViewportWidget",
    "DirectorFieldView",
    "RenderSession",
    "apply_camera_command",
    "camera_viewer",
    "format_camera_summary",
    "inspect",
    "inspect_view",
    "pil_image_to_data_url",
    "restore_camera",
    "serialize_camera",
]
