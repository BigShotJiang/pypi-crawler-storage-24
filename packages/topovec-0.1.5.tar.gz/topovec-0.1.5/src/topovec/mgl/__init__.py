"""ModernGL-based rendering primitives and convenience entrypoints.

The package exposes reusable scene and camera abstractions, a headless image
container, and a small set of convenience factories for standard rendering
setups. Frontends such as `topovec.marimo` build on this package rather than
redefining rendering behavior.
"""

import importlib

__all__ = [
    "ImageContainer",
    "Camera",
    "LayerScene",
    "CubeScene",
    "FlowScene",
    "AstraScene",
    "LevelScene",
    "ChargeScene",
    "VectorScene",
    "IsolinesScene",
    "SphereDotScene",
    "LayerAndSurfaceScene",
    "LayerAndIsolinesScene",
    "SCENES",
    "print_scenes",
    "render_layer",
    "render_isosurface",
    "render_isolines",
    "render_prepare",
]

_EXPORTS = {
    "ImageContainer": (".image", "ImageContainer"),
    "Camera": (".camera", "Camera"),
    "LayerScene": (".scene", "LayerScene"),
    "CubeScene": (".scene", "CubeScene"),
    "FlowScene": (".scene", "FlowScene"),
    "AstraScene": (".scene", "AstraScene"),
    "LevelScene": (".scene", "LevelScene"),
    "ChargeScene": (".scene", "ChargeScene"),
    "VectorScene": (".scene", "VectorScene"),
    "IsolinesScene": (".scene", "IsolinesScene"),
    "SphereDotScene": (".scene", "SphereDotScene"),
    "LayerAndSurfaceScene": (".scene", "LayerAndSurfaceScene"),
    "LayerAndIsolinesScene": (".scene", "LayerAndIsolinesScene"),
    "SCENES": (".scene", "SCENES"),
    "print_scenes": (".scene", "print_scenes"),
    "render_layer": (".sugar", "render_layer"),
    "render_isosurface": (".sugar", "render_isosurface"),
    "render_isolines": (".sugar", "render_isolines"),
    "render_prepare": (".sugar", "render_prepare"),
}


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = _EXPORTS[name]
    module = importlib.import_module(module_name, __name__)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(set(globals()) | set(__all__))
