"""Public ansatz, mask, and coordinate-system API.

The :mod:`topovec.ansatz` package exposes three cooperating layers:

- coordinate systems, which evaluate curvilinear coordinates and tangent bases
- ansatz classes, which define director fields in local coordinate components
- scalar masks, which modulate ansatz amplitudes in associated coordinates

Concrete section profiles and 3D field constructions are re-exported here for
convenient notebook and application use.
"""

from .base import Ansatz2D, Ansatz3D, AnsatzND, MaskND
from .field import (
    ArtLoopFinger,
    CholestericSpiral3D,
    ConstantField3D,
    CoordinateSpiral3D,
    Hopfion,
    LoopFinger,
    SectionEmbedding3D,
    StraightFinger,
)
from .frame import (
    AffineCoordinates,
    AxisymmetricCoordinates,
    CoordinateRemap,
    CoordinateSampleND,
    CoordinateSystem2D,
    CoordinateSystem3D,
    CoordinateSystemND,
    CylindricalCoordinates,
    EuclideanCoordinates,
    PolarCoordinates,
    RestrictedCoordinates,
)
from .section import AxisSection, BlochSection, CF1, CF2, CF3, CF4, SpiralSection, Twist

__all__ = [
    "AnsatzND",
    "Ansatz2D",
    "Ansatz3D",
    "MaskND",
    "CoordinateSampleND",
    "CoordinateSystemND",
    "CoordinateSystem2D",
    "CoordinateSystem3D",
    "EuclideanCoordinates",
    "AffineCoordinates",
    "CoordinateRemap",
    "RestrictedCoordinates",
    "CylindricalCoordinates",
    "PolarCoordinates",
    "AxisymmetricCoordinates",
    "AxisSection",
    "BlochSection",
    "SpiralSection",
    "CF1",
    "CF2",
    "CF3",
    "CF4",
    "Twist",
    "ConstantField3D",
    "CholestericSpiral3D",
    "CoordinateSpiral3D",
    "SectionEmbedding3D",
    "Hopfion",
    "StraightFinger",
    "LoopFinger",
    "ArtLoopFinger",
]
