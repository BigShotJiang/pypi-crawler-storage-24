"""Small vector-field helpers shared by ansatz implementations.

These helpers intentionally stay lightweight. They encode common array-shape
operations used throughout the ansatz package without carrying any geometric
state of their own.
"""

import numpy as np


def pack_vector(x, y, z) -> np.ndarray:
    """Stack three scalar arrays into a trailing-dimension-3 vector field."""

    return np.stack([x, y, z], axis=-1)


def normalize_vector(vector: np.ndarray, eps: float = 1e-32) -> np.ndarray:
    """Normalize a vector field pointwise along its trailing vector axis."""

    vector = np.asarray(vector)
    norm = np.sqrt(np.sum(vector**2, axis=-1, keepdims=True) + eps)
    return vector / norm
