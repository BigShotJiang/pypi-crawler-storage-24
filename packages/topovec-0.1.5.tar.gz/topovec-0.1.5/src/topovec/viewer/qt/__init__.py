"""PySide6 desktop frontend for TopoVec viewer sessions."""

from __future__ import annotations

import importlib

__all__ = [
    "QtViewport",
    "QtViewportHost",
    "TvViewWindow",
    "build_parser",
    "main",
]


def __getattr__(name):
    if name in {"build_parser", "main"}:
        module = importlib.import_module(".cli", __name__)
    elif name == "TvViewWindow":
        module = importlib.import_module(".main_window", __name__)
    elif name in {"QtViewport", "QtViewportHost"}:
        module = importlib.import_module(".viewport", __name__)
    else:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(set(globals()) | set(__all__))
