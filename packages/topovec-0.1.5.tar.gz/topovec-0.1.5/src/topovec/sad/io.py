import numpy as np
from typing import Any, Protocol

from ..core import System


class SadFrameReader(Protocol):
    def __getitem__(self, name: str) -> Any: ...


def load_lcsim_sad_single(
    reader: SadFrameReader,
) -> tuple[np.ndarray, System, dict | None]:
    x, y, z = list(reader[n] for n in ["x", "y", "z"])
    director = np.stack([x, y, z], axis=-1).transpose((2, 1, 0, 3))[:, :, :, None]
    settings = reader["s"]
    system = System.cubic(size=director.shape[:3])
    return director, system, settings
