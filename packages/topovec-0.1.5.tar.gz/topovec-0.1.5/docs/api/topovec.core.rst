topovec.core
============

.. automodule:: topovec.core

.. currentmodule:: topovec.core

.. autosummary::

   log
   configLog
   Property
   ListProperty
   NumericProperty
   BooleanProperty
   PropertiesCollection
   UpdateMask
   System
   vector_to_rgb
   hopf_charge
