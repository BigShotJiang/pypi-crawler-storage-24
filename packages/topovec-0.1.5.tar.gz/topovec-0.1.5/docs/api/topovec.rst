topovec
=======

.. automodule:: topovec

.. toctree::
   :maxdepth: 1

   topovec.ansatz
   topovec.core
   topovec.io
   topovec.mgl
   topovec.marimo
   topovec.matplotlib
   topovec.ti
   topovec.sad
