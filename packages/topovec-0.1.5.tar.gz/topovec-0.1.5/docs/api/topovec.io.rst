topovec.io
==========

.. automodule:: topovec.io

.. currentmodule:: topovec.io

.. autosummary::

   load_magnes_npz
   load_lcsim_npz
   save_npz_lcsim
