topovec.ti
==========

.. automodule:: topovec.ti

.. currentmodule:: topovec.ti

.. autosummary::

   Function
   FunctionTable
   ConstantFunction
   GaussianFunction
   SimplifiedRGB
   BlackbodyRadiation
   render_cp_multi
   JonesCalculus
