topovec.matplotlib
==================

.. automodule:: topovec.matplotlib

.. currentmodule:: topovec.matplotlib

.. autosummary::

   render_layer
   plot_bloch_sphere
