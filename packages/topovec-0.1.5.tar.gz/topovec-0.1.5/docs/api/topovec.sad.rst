topovec.sad
===========

.. automodule:: topovec.sad

.. currentmodule:: topovec.sad

.. autosummary::

   load_lcsim_sad_single
