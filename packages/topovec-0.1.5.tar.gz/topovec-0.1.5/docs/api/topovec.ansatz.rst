topovec.ansatz
==============

.. automodule:: topovec.ansatz

.. currentmodule:: topovec.ansatz

.. autosummary::

   AnsatzND
   Ansatz2D
   Ansatz3D
   MaskND
   CoordinateSampleND
   CoordinateSystemND
   CoordinateSystem2D
   CoordinateSystem3D
   EuclideanCoordinates
   AffineCoordinates
   CoordinateRemap
   RestrictedCoordinates
   CylindricalCoordinates
   PolarCoordinates
   AxisymmetricCoordinates
   AxisSection
   BlochSection
   SpiralSection
   CF1
   CF2
   CF3
   CF4
   Twist
   ConstantField3D
   CholestericSpiral3D
   CoordinateSpiral3D
   SectionEmbedding3D
   Hopfion
   StraightFinger
   LoopFinger
   ArtLoopFinger
