import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)

project = "TopoVec"
author = "Igor Lobanov"
extensions = [
    "myst_parser",
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.autosummary",
    "numpydoc",
    "sphinx_autodoc_typehints",
]
autosummary_generate = True
autosummary_generate_overwrite = True
autosummary_generated = ["api/_generated"]
numpydoc_show_class_members = False
numpydoc_class_members_toctree = True
autodoc_typehints = "description"
templates_path = ["_templates"]
exclude_patterns = ["_build"]
exclude_patterns.append("api/_generated")

html_theme = "pydata_sphinx_theme"
html_title = "TopoVec Documentation"
html_baseurl = os.environ.get("READTHEDOCS_CANONICAL_URL", "/")
