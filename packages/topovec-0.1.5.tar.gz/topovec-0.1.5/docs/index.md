# TopoVec

Visualization and helper tools for 3D vector fields with a focus on topological
solitons and liquid-crystal workflows.

Start with the [installation guide](guides/installation.md) to set up an
environment. TopoVec supports both notebook workflows through marimo/Jupyter
and a dockable desktop viewer through `topovec view` for browsing `.npz` and `.sad`
state files. See the [notebook guide](guides/notebooks.md) for interactive
examples and the installation guide for the desktop viewer extras.

```{toctree}
:maxdepth: 2
:caption: Guides

guides/installation
guides/notebooks
guides/rendering-architecture
```

```{toctree}
:maxdepth: 2
:caption: API Reference

api/index
```
