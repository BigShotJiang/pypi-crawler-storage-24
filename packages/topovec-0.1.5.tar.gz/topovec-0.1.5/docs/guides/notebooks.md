# Notebooks

TopoVec works well from Jupyter or Marimo notebooks for preparing publication
figures and interactive experiments.

## Jupyter

To launch Jupyter Lab inside the current environment:

```sh
uv run --with jupyter jupyter lab
```

## Marimo

Marimo notebooks can be started directly from the repository or from a separate
runtime project that depends on `topovec` from PyPI:

```sh
uv run --extra marimo marimo edit notebooks/s1_s2_s3_ansatz.py
```

## Examples

The repository includes example notebooks under `notebooks/`. A basic demo is
available at `notebooks/demo1.ipynb`.

## Desktop Alternative

For large interactive inspection sessions outside notebooks, use the `topovec view`
desktop application:

```sh
uv run topovec view path/to/state.npz
```

The desktop viewer is read-only in v1 and focuses on state browsing, built-in
scene switching, auto-generated render controls, Python reproduction snippets,
and high-resolution image export.
