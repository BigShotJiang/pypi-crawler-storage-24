def test_import():
    import topovec


def test_system_exposes_center_and_lengths():
    from topovec import System
    import numpy as np

    system = System.cubic(size=(2, 3, 4))

    assert np.allclose(system.center, [1.0, 1.5, 2.0])
    assert np.allclose(system.lengths, [2.0, 3.0, 4.0])


def test_plain_system_does_not_advertise_energy_mask_backend():
    from topovec import System
    from topovec.mgl.scene import VectorScene

    system = System.cubic(size=(2, 2, 2))

    assert VectorScene.supports_energy_mask_system(system) is False


def test_system_get_inner_triangles_uses_stored_triangulation_by_default():
    from topovec import System

    system = System.cubic(size=(2, 2, 2))
    triangles = system.get_inner_triangles()

    assert triangles.ndim == 2
    assert triangles.shape[1] == 3
    assert triangles.shape[0] > 0


def test_system_thinned_matches_field_shape_for_non_divisible_scalar_step():
    from topovec import System
    import numpy as np

    system = System.cubic(size=(121, 121, 21))
    data = np.zeros((121, 121, 21, 1, 3), dtype=np.float64)

    thin_data, thin_system = system.thinned(data=data, steps=4)

    assert thin_data.shape[:3] == (31, 31, 6)
    assert thin_data.shape[:3] == tuple(int(v) for v in thin_system.size)
    assert np.allclose(thin_system.primitives, system.primitives * 4)
    assert np.allclose(thin_system.representatives, system.representatives)


def test_system_thinned_matches_field_shape_for_vector_step_with_include():
    from topovec import System
    import numpy as np

    system = System.cubic(size=(5, 6, 7))
    data = np.zeros((5, 6, 7, 1, 3), dtype=np.float64)
    steps = np.array((4, 4, 4))
    include = np.array((3, 0, 1))

    thin_data, thin_system = system.thinned(data=data, steps=steps, include=include)

    assert thin_data.shape[:3] == (1, 2, 2)
    assert thin_data.shape[:3] == tuple(int(v) for v in thin_system.size)
    assert np.allclose(thin_system.primitives, system.primitives * steps[:, None])
    assert np.allclose(
        thin_system.representatives,
        system.representatives + include[None] @ system.primitives,
    )


def test_system_thinned_preserves_divisible_case_sizes():
    from topovec import System
    import numpy as np

    system = System.cubic(size=(120, 120, 20))
    data = np.zeros((120, 120, 20, 1, 3), dtype=np.float64)

    thin_data, thin_system = system.thinned(data=data, steps=4)

    assert thin_data.shape[:3] == (30, 30, 5)
    assert thin_data.shape[:3] == tuple(int(v) for v in thin_system.size)
    assert np.allclose(thin_system.primitives, system.primitives * 4)
    assert np.allclose(thin_system.representatives, system.representatives)
