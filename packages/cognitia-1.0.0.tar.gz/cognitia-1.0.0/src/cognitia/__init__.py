"""Cognitia — LLM-agnostic framework for building AI agents."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("cognitia")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

from cognitia.agent import Agent, AgentConfig, Conversation, Result, tool
from cognitia.bootstrap import CognitiaStack
from cognitia.protocols import (
    ContextBuilder,
    FactStore,
    GoalStore,
    LocalToolResolver,
    MessageStore,
    ModelSelector,
    PhaseStore,
    RoleRouter,
    RoleSkillsProvider,
    RuntimePort,
    SessionFactory,
    SessionLifecycle,
    SessionManager,
    SessionRehydrator,
    SessionStateStore,
    SummaryStore,
    ToolEventStore,
    ToolIdCodec,
    UserStore,
)
from cognitia.runtime.base import AgentRuntime
from cognitia.runtime.factory import RuntimeFactory
from cognitia.runtime.types import (
    Message,
    RuntimeConfig,
    RuntimeErrorData,
    RuntimeEvent,
    ToolSpec,
    TurnMetrics,
)
from cognitia.types import ContextPack, SkillSet, TurnContext

__all__ = [
    "Agent",
    "AgentConfig",
    "AgentRuntime",
    "CognitiaStack",
    "ContextBuilder",
    "ContextPack",
    "Conversation",
    "FactStore",
    "GoalStore",
    "LocalToolResolver",
    "Message",
    "MessageStore",
    "ModelSelector",
    "PhaseStore",
    "Result",
    "RoleRouter",
    "RoleSkillsProvider",
    "RuntimeConfig",
    "RuntimeErrorData",
    "RuntimeEvent",
    "RuntimeFactory",
    "RuntimePort",
    "SessionFactory",
    "SessionLifecycle",
    "SessionManager",
    "SessionRehydrator",
    "SessionStateStore",
    "SkillSet",
    "SummaryStore",
    "ToolEventStore",
    "ToolIdCodec",
    "ToolSpec",
    "TurnContext",
    "TurnMetrics",
    "UserStore",
    "tool",
]
