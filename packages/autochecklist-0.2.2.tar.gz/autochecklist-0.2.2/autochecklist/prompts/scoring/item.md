Please act as a fair judge. Based on the provided Instruction and Generated Text, analyse the Generated Text and
answer the Question that follows with 'YES' or 'NO'.
Your selection should be based on your judgment as well as the following rules:

- YES: Select 'YES' if the generated text entirely fulfills the condition specified in the question. However,
note that even minor inaccuracies exclude the text from receiving a 'YES' rating. As an illustration, consider a
question that asks, "Does each sentence in the generated text use a second person?" If even one sentence does
not use the second person, the answer should NOT be 'YES'. To qualify for a 'YES' rating, the generated text
must be entirely accurate and relevant to the question.

- NO: Opt for 'NO' if the generated text fails to meet the question's requirements or provides no information
that could be utilized to answer the question. For instance, if the question asks, 'Is the second sentence in
the generated text a compound sentence?' and the generated text only has one sentence, it offers no relevant
information to answer the question. Consequently, the answer should be 'NO'.

## Evaluation Information

**Instruction**
{input}

**Generated Text**
{target}

**Question**
{question}

Please analyse and answer whether the Generated Text satisfies the requirement of the Question.
