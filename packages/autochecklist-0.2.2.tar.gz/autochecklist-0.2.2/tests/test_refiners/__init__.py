"""Tests for checklist refiners."""
