import unittest
from io import StringIO
from unittest.mock import MagicMock

import pytest

from cmate._ast import Constant, Rule
from cmate._test import (
    _build_rule_method,
    _build_test_case,
    make_test_suite,
    RuleAssertionError,
    RuleTestResult,
    RuleTestRunner,
)
from cmate.util import Severity
from cmate.visitor import ASTFormatter


class TestRuleAssertionError:
    """Tests for RuleAssertionError class"""

    def test_rule_assertion_error_creation(self):
        """Test RuleAssertionError creation"""
        history = (("key", "value"),)
        err = RuleAssertionError(
            severity=Severity.ERROR,
            msg="Test error message",
            test_expr="key == value",
            history=history,
        )

        assert err.severity == Severity.ERROR
        assert err.msg == "Test error message"
        assert err.test_expr == "key == value"
        assert err.history == history

    def test_build_err_msg_simple(self):
        """Test building error message with simple history"""
        history = (("config::key", "value"),)
        err = RuleAssertionError(
            severity=Severity.ERROR,
            msg="Test error",
            test_expr="config::key == 'expected'",
            history=history,
        )
        msg = err.build_err_msg()

        assert "Test error" in msg
        assert "config::key" in msg

    def test_build_err_msg_with_tuple(self):
        """Test building error message with tuple values in history"""
        history = (("config::key", ("actual", "reference")),)
        err = RuleAssertionError(
            severity=Severity.ERROR,
            msg="Test error",
            test_expr="config::key == 'expected'",
            history=history,
        )
        msg = err.build_err_msg()

        assert "Test error" in msg
        assert "reference" in msg
        assert "actual" in msg


class TestRuleTestResult:
    """Tests for RuleTestResult class"""

    @pytest.fixture
    def result(self):
        stream = StringIO()
        res = RuleTestResult(
            stream=stream, verbosity=False, total_cnt=10, failfast=False
        )
        return res

    def test_add_success(self, result):
        """Test addSuccess method"""
        test = MagicMock()
        test.namespace = "test_ns"
        result.addSuccess(test)
        # Status chars contain color codes, just check it's not empty
        assert len(result._status_chars) > 0

    def test_add_failure(self, result):
        """Test addFailure method"""
        test = MagicMock()
        test.namespace = "test_ns"

        err = RuleAssertionError(
            severity=Severity.ERROR,
            msg="error",
            test_expr="key == 'val'",
            history=(("key", "value"),),
        )

        result.addFailure(test, (Exception, err, None))
        assert len(result.failures) == 1

    def test_add_error(self, result):
        """Test addError method"""
        test = MagicMock()
        test.namespace = "test_ns"
        result.addError(test, (Exception, Exception("error"), None))
        assert len(result.errors) == 1

    def test_add_skip(self, result):
        """Test addSkip method"""
        test = MagicMock()
        test.namespace = "test_ns"
        result.addSkip(test, "reason")
        assert len(result.skipped) == 1

    def test_add_expected_failure(self, result):
        """Test addExpectedFailure method"""
        test = MagicMock()
        test.namespace = "test_ns"
        result.addExpectedFailure(test, (Exception, Exception("error"), None))
        assert len(result.expectedFailures) == 1

    def test_add_unexpected_success(self, result):
        """Test addUnexpectedSuccess method"""
        test = MagicMock()
        test.namespace = "test_ns"
        result.addUnexpectedSuccess(test)
        assert len(result.unexpectedSuccesses) == 1


class TestRuleTestRunner:
    """Tests for RuleTestRunner class"""

    def test_runner_creation(self):
        """Test RuleTestRunner creation"""
        runner = RuleTestRunner()
        assert runner.verbosity is False
        assert runner.failfast is False

    def test_runner_with_custom_params(self):
        """Test RuleTestRunner with custom parameters"""
        stream = StringIO()
        runner = RuleTestRunner(stream=stream, failfast=True, verbosity=True)
        assert runner.verbosity is True
        assert runner.failfast is True

    def test_run_empty_suite(self):
        """Test running empty test suite"""
        stream = StringIO()
        runner = RuleTestRunner(stream=stream)

        suite = unittest.TestSuite()
        runner.run(suite)  # noqa: F841

        output = stream.getvalue()
        assert "collected 0 items" in output
        assert "no tests ran" in output


class TestMakeTestSuite:
    """Tests for make_test_suite function"""

    def test_make_test_suite_empty(self):
        """Test making test suite with empty ruleset"""
        data_source = MagicMock()
        ruleset = {}
        output = {}

        suite = make_test_suite(data_source, ruleset, output)
        assert suite.countTestCases() == 0

    def test_make_test_suite_with_rules(self):
        """Test making test suite with rules"""
        data_source = MagicMock()

        const = Constant(1, 1, True)
        rule = Rule(1, 1, const, "test message", Severity.ERROR)
        ruleset = {"test_ns": {rule}}
        output = {}

        suite = make_test_suite(data_source, ruleset, output)
        assert suite.countTestCases() == 1

    def test_make_test_suite_multiple_namespaces(self):
        """Test making test suite with multiple namespaces"""
        data_source = MagicMock()

        rule1 = Rule(1, 1, Constant(1, 1, True), "msg1", Severity.ERROR)
        rule2 = Rule(2, 1, Constant(2, 1, True), "msg2", Severity.WARNING)
        ruleset = {"ns1": {rule1}, "ns2": {rule2}}
        output = {}

        suite = make_test_suite(data_source, ruleset, output)
        assert suite.countTestCases() == 2


class TestMakeTestCase:
    """Tests for _build_test_case function"""

    def test_build_test_case(self):
        """Test creating test case class"""
        data_source = MagicMock()
        rule = Rule(1, 1, Constant(1, 1, True), "test", Severity.ERROR)
        cls = _build_test_case("test_ns", {rule}, data_source, {})

        assert cls.__name__ == "Test-test_ns"
        assert hasattr(cls, "test_1")

    def test_build_test_case_multiple_rules(self):
        """Test creating test case with multiple rules"""
        data_source = MagicMock()
        rule1 = Rule(10, 1, Constant(10, 1, True), "test1", Severity.ERROR)
        rule2 = Rule(20, 1, Constant(20, 1, True), "test2", Severity.WARNING)
        cls = _build_test_case("test_ns", {rule1, rule2}, data_source, {})

        assert hasattr(cls, "test_10")
        assert hasattr(cls, "test_20")


class TestMakeTestMethod:
    """Tests for _build_rule_method function"""

    def test_build_rule_method_pass(self):
        """Test creating test method that passes"""
        const = Constant(1, 1, True)
        rule = Rule(1, 1, const, "test message", Severity.ERROR)

        evaluator = MagicMock()
        evaluator.evaluate.return_value = True
        evaluator.history = []

        formatter = ASTFormatter()
        output = {}
        test_method = _build_rule_method(rule, "test_ns", evaluator, formatter, output)

        inst = MagicMock()
        # Should not raise
        test_method(inst)

    def test_build_rule_method_fail(self):
        """Test creating test method that fails"""
        const = Constant(1, 1, False)
        rule = Rule(1, 1, const, "test message", Severity.ERROR)

        evaluator = MagicMock()
        evaluator.evaluate.return_value = False
        evaluator.history = [("key", "value")]

        formatter = ASTFormatter()
        output = {}
        test_method = _build_rule_method(rule, "test_ns", evaluator, formatter, output)

        inst = MagicMock()
        with pytest.raises(RuleAssertionError):
            test_method(inst)

    def test_build_rule_method_output_populated(self):
        """Test that test method populates output dictionary"""
        const = Constant(1, 1, True)
        rule = Rule(1, 1, const, "test message", Severity.ERROR)

        evaluator = MagicMock()
        evaluator.evaluate.return_value = True
        evaluator.history = [("key", "value")]

        formatter = ASTFormatter()
        output = {}
        test_method = _build_rule_method(rule, "test_ns", evaluator, formatter, output)
        inst = MagicMock()
        test_method(inst)

        assert "test_ns" in output
        assert len(output["test_ns"]) == 1
        assert output["test_ns"][0]["test"] is not None
        assert output["test_ns"][0]["msg"] == "test message"


class TestRuleTestRunnerExtended:
    """Extended tests for RuleTestRunner"""

    def test_runner_with_custom_rescls(self):
        """Test runner with custom result class"""

        class CustomResult(RuleTestResult):
            pass

        stream = StringIO()
        runner = RuleTestRunner(stream=stream, rescls=CustomResult)
        assert runner.rescls == CustomResult


class TestRuleTestResultExtended:
    """Extended tests for RuleTestResult"""

    def test_add_expected_failure(self):
        """Test addExpectedFailure method"""
        stream = StringIO()
        result = RuleTestResult(stream=stream)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addExpectedFailure(test, (Exception, Exception("test"), None))
        assert len(result.expectedFailures) == 1

    def test_add_expected_failure_verbose(self):
        """Test addExpectedFailure with verbosity"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream, verbosity=True, total_cnt=1)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addExpectedFailure(test, (Exception, Exception("test"), None))
        assert len(result.expectedFailures) == 1

    def test_add_unexpected_success(self):
        """Test addUnexpectedSuccess method"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addUnexpectedSuccess(test)
        assert len(result.unexpectedSuccesses) == 1

    def test_add_unexpected_success_verbose(self):
        """Test addUnexpectedSuccess with verbosity"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream, verbosity=True, total_cnt=1)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addUnexpectedSuccess(test)
        assert len(result.unexpectedSuccesses) == 1

    def test_add_error(self):
        """Test addError method"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addError(test, (Exception, Exception("test"), None))
        assert len(result.errors) == 1

    def test_add_error_verbose(self):
        """Test addError with verbosity"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream, verbosity=True, total_cnt=1)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addError(test, (Exception, Exception("test"), None))
        assert len(result.errors) == 1

    def test_add_skip(self):
        """Test addSkip method"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addSkip(test, "skipped reason")
        assert len(result.skipped) == 1

    def test_add_skip_verbose(self):
        """Test addSkip with verbosity"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream, verbosity=True, total_cnt=1)
        test = MagicMock()
        test.id.return_value = "test_id"
        test.namespace = "test_ns"

        result.addSkip(test, "skipped reason")
        assert len(result.skipped) == 1


class TestRuleTestResultPrintErrors:
    """Tests for RuleTestResult printErrors method"""

    def test_print_errors_with_errors(self):
        """Test printErrors with errors"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream)
        test = MagicMock()
        test.id.return_value = "test_id"

        result.addError(test, (Exception, Exception("test error"), None))
        result.printErrors()
        output = stream.getvalue()
        assert "ERRORS" in output

    def test_print_errors_with_failures(self):
        """Test printErrors with failures"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream)
        test = MagicMock()
        test.id.return_value = "test_id"
        test._testMethodName = "test_1"
        test.namespace = "test_ns"

        # Create a RuleAssertionError with the new API
        err = RuleAssertionError(
            severity=Severity.ERROR,
            msg="test message",
            test_expr="test::key == 'expected'",
            history=(("key", "value"),),
        )

        result.failures.append((test, err))
        result.printErrors()
        assert "FAILURES" in stream.getvalue()

    def test_print_errors_empty(self):
        """Test printErrors with no errors or failures"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream)
        result.printErrors()
        output = stream.getvalue()
        # Only flush is called, no writing
        assert output == ""


class TestRuleTestResultUpdateMethods:
    """Tests for RuleTestResult _tick methods"""

    def test_update_verbose_long_test_id(self):
        """Test _tick_verbose with long test id"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream, verbosity=True, total_cnt=1)
        test = MagicMock()
        test.id.return_value = "a" * 200  # Very long test id
        test.namespace = "test_ns"

        result._tick_verbose(test, "PASSED")
        output = stream.getvalue()
        assert "..." in output or "PASSED" in output

    def test_update_with_overflow(self):
        """Test _tick when status chars overflow available space"""
        from unittest.runner import _WritelnDecorator

        stream = _WritelnDecorator(StringIO())
        result = RuleTestResult(stream=stream, total_cnt=100)

        # Add many status chars to trigger overflow
        test = MagicMock()
        test.namespace = "test_ns"
        for _ in range(200):
            result._status_chars.append(".")

        result._tick(test, ".")
        # Should handle overflow gracefully - output not needed for assertion
