class LookupValueMixin:
    def get_lookup_value(self):
        lookup_key = self.lookup_url_kwarg or self.lookup_field

        if lookup_key not in self.kwargs:
            from rest_framework.exceptions import NotFound
            raise NotFound(f"URL kwarg '{lookup_key}' not found.")

        return self.kwargs[lookup_key]