"""Geo package for samgis_core - coordinate conversion and geospatial utilities."""
