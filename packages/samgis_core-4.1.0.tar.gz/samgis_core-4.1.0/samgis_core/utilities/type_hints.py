"""custom type hints"""

from enum import Enum
from typing import Any, TypedDict, NewType

from numpy import ndarray


ListStr = list[str]
ListDict = list[dict[str, Any]]

TupleInt = tuple[int, ...]
TupleInt2 = NewType("TupleInt2", tuple[int, int])

TupleNdarrayInt = tuple[ndarray, int]
TupleNdarrayFloat = tuple[ndarray, float]
TupleFloat = tuple[float, ...]
TupleFloatAny = tuple[float, Any]


class StrEnum(str, Enum):
    pass


class EmbeddingImage(TypedDict):
    image_embedding: ndarray
    original_size: TupleInt
    transform_matrix: ndarray


class MatplotlibBackend(StrEnum):
    gtk3agg = "gtk3agg"
    gtk3cairo = "gtk3cairo"
    gtk4agg = "gtk4agg"
    gtk4cairo = "gtk4cairo"
    macosx = "macosx"
    nbagg = "nbagg"
    notebook = "notebook"
    qtagg = "qtagg"
    qtcairo = "qtcairo"
    qt5agg = "qt5agg"
    qt5cairo = "qt5cairo"
    tkagg = "tkagg"
    tkcairo = "tkcairo"
    webagg = "webagg"
    wx = "wx"
    wxagg = "wxagg"
    wxcairo = "wxcairo"
    agg = "agg"
    cairo = "cairo"
    pdf = "pdf"
    pgf = "pgf"
    ps = "ps"
    svg = "svg"
    template = "template"


EmbeddingDict = dict[str, EmbeddingImage]
