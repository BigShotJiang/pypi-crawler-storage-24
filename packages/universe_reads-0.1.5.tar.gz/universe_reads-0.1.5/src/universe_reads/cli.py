from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path

from .parallel_read import RunOptions, run_parallel_read

logger = logging.getLogger("universe_reads")


def _parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Read UniVerse records using parallel sessions (uopy).")
    p.add_argument(
        "--file",
        dest="file_name",
        default=os.getenv("UV_FILE"),
        help="UniVerse file name to read (defaults to env UV_FILE).",
    )
    p.add_argument(
        "--session-factory",
        default=None,
        help="Python callable that returns a new uopy Session, in form 'module.sub:factory'.",
    )

    pooling = p.add_mutually_exclusive_group()
    pooling.add_argument(
        "--pooling",
        action="store_true",
        help="Pass pooling hints to the session factory (if it supports them).",
    )
    pooling.add_argument(
        "--no-pooling",
        action="store_true",
        help="Disable pooling hints to the session factory (if it supports them).",
    )

    p.add_argument(
        "--min-pool-size",
        type=int,
        default=None,
        help="Minimum pool size hint (only used if pooling hints are enabled).",
    )
    p.add_argument(
        "--max-pool-size",
        type=int,
        default=None,
        help="Maximum pool size hint (only used if pooling hints are enabled).",
    )

    p.add_argument(
        "--sessions",
        type=int,
        default=5,
        help="Number of concurrent UniVerse sessions/processes to use (default: 5).",
    )
    p.add_argument(
        "--count-only",
        action="store_true",
        help="Do not write records; just count and report throughput.",
    )
    p.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Write one NDJSON file per worker into this directory.",
    )
    p.add_argument(
        "--batch-size",
        type=int,
        default=500,
        help="Number of keys sent per IPC batch to each worker.",
    )
    p.add_argument(
        "--progress-every",
        type=float,
        default=5.0,
        help="Seconds between throughput logs per process.",
    )
    p.add_argument(
        "--max-records",
        type=int,
        default=None,
        help="Debug cap. Prefer leaving unset for full runs.",
    )
    p.add_argument(
        "--dry-run",
        type=int,
        default=None,
        help="If set, do not connect to UniVerse; generate N fake keys and read fake records.",
    )
    p.add_argument(
        "--retries",
        type=int,
        default=3,
        help="Number of retries per batch/key on RPC failure (default: 3). 0 disables retries.",
    )
    p.add_argument(
        "--retry-backoff",
        type=float,
        default=0.5,
        help="Base backoff in seconds between retries, doubles each attempt (default: 0.5).",
    )

    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    ns = _parse_args(sys.argv[1:] if argv is None else argv)

    if ns.output_dir is None and not ns.count_only:
        # Default behavior: count-only, unless output is explicitly requested.
        ns.count_only = True

    if ns.dry_run is None:
        if not ns.file_name:
            raise RuntimeError("Missing --file (or set UV_FILE)")
        if not ns.session_factory:
            raise RuntimeError("Missing --session-factory (required for non-dry-run)")
    else:
        # dry-run doesn't need a file or session factory
        if not ns.file_name:
            ns.file_name = ""

    if ns.output_dir is not None and ns.output_dir.exists() and not ns.output_dir.is_dir():
        raise RuntimeError("--output-dir must be a directory")

    session_factory_kwargs: dict[str, object] = {}
    pooling_on: bool | None = None

    if ns.pooling:
        pooling_on = True
    elif ns.no_pooling:
        pooling_on = False

    # If sizes are supplied, implicitly enable pooling hints.
    if ns.min_pool_size is not None or ns.max_pool_size is not None:
        pooling_on = True if pooling_on is None else pooling_on

    if pooling_on is not None:
        session_factory_kwargs["pooling_on"] = pooling_on
    if ns.min_pool_size is not None:
        session_factory_kwargs["min_pool_size"] = int(ns.min_pool_size)
    if ns.max_pool_size is not None:
        session_factory_kwargs["max_pool_size"] = int(ns.max_pool_size)

    options = RunOptions(
        sessions=int(ns.sessions),
        count_only=bool(ns.count_only),
        output_dir=ns.output_dir,
        batch_size=int(ns.batch_size),
        progress_every_seconds=float(ns.progress_every),
        max_records=ns.max_records,
        dry_run=ns.dry_run,
        session_factory_kwargs=session_factory_kwargs,
        retries=int(ns.retries),
        retry_backoff=float(ns.retry_backoff),
    )

    started = time.monotonic()
    results = run_parallel_read(
        file_name=str(ns.file_name),
        session_factory_spec=ns.session_factory,
        options=options,
    )
    elapsed = time.monotonic() - started

    total_records = sum(r.records for r in results)
    total_errors = sum(r.errors for r in results)

    logger.info("Summary")
    for r in results:
        rate = r.records / max(1e-9, r.elapsed_seconds)
        logger.info(
            "worker-%d: records=%d errors=%d rate=%s rec/s elapsed=%s",
            r.worker_id, r.records, r.errors, f"{rate:,.0f}", f"{r.elapsed_seconds:,.1f}s",
        )

    logger.info("TOTAL: records=%d errors=%d elapsed=%s", total_records, total_errors, f"{elapsed:,.1f}s")
    if elapsed > 0:
        logger.info("OVERALL RATE: %s rec/s", f"{total_records / elapsed:,.0f}")

    return 0 if total_errors == 0 else 2
