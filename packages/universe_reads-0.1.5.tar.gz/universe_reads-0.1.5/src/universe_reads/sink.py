from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
from typing import Any, Protocol


class RecordSink(Protocol):
    def on_record(self, *, key: str, record: Any) -> None: ...
    def close(self) -> None: ...


@dataclass
class CountSink:
    count: int = 0

    def on_record(self, *, key: str, record: Any) -> None:
        self.count += 1

    def close(self) -> None:
        return


class CollectorSink:
    """Accumulates records in memory so they can be returned to the caller."""

    def __init__(self) -> None:
        self.count: int = 0
        self.data: dict[str, Any] = {}

    def on_record(self, *, key: str, record: Any) -> None:
        self.data[key] = record
        self.count += 1

    def close(self) -> None:
        return


class NDJSONSink:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._fp = path.open("w", encoding="utf-8", buffering=1)  # line-buffered
        self.count = 0

    def on_record(self, *, key: str, record: Any) -> None:
        if isinstance(record, bytes):
            record_out: Any = record.decode("utf-8", errors="replace")
        else:
            record_out = getattr(record, "list", record)

        # Ensure JSON-serializable fallback.
        if not isinstance(record_out, (dict, list, str, int, float, bool)) and record_out is not None:
            record_out = str(record_out)

        self._fp.write(json.dumps({"key": key, "record": record_out}) + "\n")
        self.count += 1

    def close(self) -> None:
        self._fp.close()
