"""Parallel UniVerse bulk reader.

Public API:
- `universe_reads.run(...)` (see `universe_reads.api`)
"""

from .api import run
from .parallel_read import RunOptions, WorkerResult

__all__ = ["__version__", "run", "RunOptions", "WorkerResult"]

__version__ = "0.1.5"
