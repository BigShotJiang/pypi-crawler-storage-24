from __future__ import annotations

from dataclasses import dataclass
import time


@dataclass
class Throughput:
    started_at: float
    last_report_at: float
    total: int


def start_throughput() -> Throughput:
    now = time.monotonic()
    return Throughput(started_at=now, last_report_at=now, total=0)


def maybe_report(
    t: Throughput,
    *,
    label: str,
    every_seconds: float = 5.0,
) -> str | None:
    now = time.monotonic()
    if now - t.last_report_at < every_seconds:
        return None

    elapsed = max(1e-9, now - t.started_at)
    rate = t.total / elapsed
    t.last_report_at = now
    return f"{label}: total={t.total} rate={rate:,.0f} rec/s elapsed={elapsed:,.1f}s"
