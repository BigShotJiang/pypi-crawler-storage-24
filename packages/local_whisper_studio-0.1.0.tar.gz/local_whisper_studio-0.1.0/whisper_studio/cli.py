"""Command-line interface for Whisper Studio."""

import argparse
import sys
from pathlib import Path
from typing import Optional

from whisper_studio.engine import TranscriptionEngine
from whisper_studio.export import export_srt, export_vtt, export_txt, export_json
from whisper_studio.server import run_server
from whisper_studio.utils import get_audio_duration, validate_audio_file


def transcribe_command(args: argparse.Namespace) -> int:
    """Handle transcribe command."""
    input_path = Path(args.input)
    
    # Validate input file
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1
    
    if not validate_audio_file(input_path):
        print(f"Error: Unsupported file format: {input_path.suffix}", file=sys.stderr)
        return 1
    
    # Initialize engine
    print(f"Loading Whisper model '{args.model}' on device '{args.device}'...")
    try:
        engine = TranscriptionEngine(
            model_name=args.model,
            device=args.device,
            compute_type=args.compute_type
        )
    except Exception as e:
        print(f"Error initializing engine: {e}", file=sys.stderr)
        return 1
    
    # Get audio duration for progress tracking
    duration = get_audio_duration(str(input_path))
    if duration:
        print(f"Audio duration: {duration:.1f} seconds")
    
    # Transcribe
    print(f"Transcribing {input_path.name}...")
    try:
        result = engine.transcribe(
            str(input_path),
            language=args.language,
            diarize=args.diarize,
            num_speakers=args.num_speakers if args.diarize else None
        )
    except Exception as e:
        print(f"Error during transcription: {e}", file=sys.stderr)
        return 1
    
    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = input_path.with_suffix(f".{args.format}")
    
    # Export
    print(f"Exporting to {output_path}...")
    try:
        if args.format == "srt":
            export_srt(result, str(output_path))
        elif args.format == "vtt":
            export_vtt(result, str(output_path))
        elif args.format == "txt":
            export_txt(result, str(output_path))
        elif args.format == "json":
            export_json(result, str(output_path))
    except Exception as e:
        print(f"Error exporting: {e}", file=sys.stderr)
        return 1
    
    print(f"✓ Transcription complete: {output_path}")
    print(f"  Detected language: {result.get('language', 'unknown')}")
    print(f"  Segments: {len(result.get('segments', []))}")
    
    return 0


def batch_command(args: argparse.Namespace) -> int:
    """Handle batch transcription command."""
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    
    if not input_dir.exists() or not input_dir.is_dir():
        print(f"Error: Input directory not found: {input_dir}", file=sys.stderr)
        return 1
    
    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Find all audio/video files
    audio_files = []
    for ext in [".mp3", ".wav", ".m4a", ".flac", ".ogg", ".mp4", ".mov", ".avi", ".mkv"]:
        audio_files.extend(input_dir.glob(f"*{ext}"))
        audio_files.extend(input_dir.glob(f"*{ext.upper()}"))
    
    if not audio_files:
        print(f"No audio/video files found in {input_dir}", file=sys.stderr)
        return 1
    
    print(f"Found {len(audio_files)} files to process")
    
    # Initialize engine once
    print(f"Loading Whisper model '{args.model}'...")
    engine = TranscriptionEngine(model_name=args.model, device=args.device)
    
    # Process each file
    success_count = 0
    for i, audio_file in enumerate(audio_files, 1):
        print(f"\n[{i}/{len(audio_files)}] Processing {audio_file.name}...")
        
        try:
            result = engine.transcribe(
                str(audio_file),
                language=args.language,
                diarize=args.diarize
            )
            
            output_path = output_dir / f"{audio_file.stem}.{args.format}"
            
            if args.format == "srt":
                export_srt(result, str(output_path))
            elif args.format == "vtt":
                export_vtt(result, str(output_path))
            elif args.format == "txt":
                export_txt(result, str(output_path))
            elif args.format == "json":
                export_json(result, str(output_path))
            
            print(f"  ✓ Saved to {output_path}")
            success_count += 1
            
        except Exception as e:
            print(f"  ✗ Error: {e}", file=sys.stderr)
            continue
    
    print(f"\n✓ Batch complete: {success_count}/{len(audio_files)} successful")
    return 0 if success_count > 0 else 1


def serve_command(args: argparse.Namespace) -> int:
    """Handle web server command."""
    print(f"Starting Whisper Studio web server...")
    print(f"  URL: http://{args.host}:{args.port}")
    print(f"  Model: {args.model}")
    print(f"  Device: {args.device}")
    print("\nPress Ctrl+C to stop")
    
    try:
        run_server(
            host=args.host,
            port=args.port,
            debug=args.debug,
            model_name=args.model,
            device=args.device
        )
        return 0
    except KeyboardInterrupt:
        print("\n\nShutting down...")
        return 0
    except Exception as e:
        print(f"Error starting server: {e}", file=sys.stderr)
        return 1


def main() -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Local Whisper Studio - Offline audio transcription and subtitle editor",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Transcribe command
    transcribe_parser = subparsers.add_parser("transcribe", help="Transcribe a single file")
    transcribe_parser.add_argument("input", help="Input audio/video file")
    transcribe_parser.add_argument("-o", "--output", help="Output file path")
    transcribe_parser.add_argument(
        "-m", "--model",
        default="base",
        choices=["tiny", "base", "small", "medium", "large-v2", "large-v3"],
        help="Whisper model size (default: base)"
    )
    transcribe_parser.add_argument(
        "-l", "--language",
        default=None,
        help="Source language (default: auto-detect)"
    )
    transcribe_parser.add_argument(
        "-f", "--format",
        default="srt",
        choices=["srt", "vtt", "txt", "json"],
        help="Output format (default: srt)"
    )
    transcribe_parser.add_argument(
        "-d", "--diarize",
        action="store_true",
        help="Enable speaker diarization"
    )
    transcribe_parser.add_argument(
        "-s", "--num-speakers",
        type=int,
        default=0,
        help="Number of speakers (0 = auto-detect)"
    )
    transcribe_parser.add_argument(
        "--device",
        default="cpu",
        choices=["cpu", "cuda", "mps"],
        help="Compute device (default: cpu)"
    )
    transcribe_parser.add_argument(
        "--compute-type",
        default="int8",
        choices=["int8", "float16", "float32"],
        help="Compute precision (default: int8)"
    )
    
    # Batch command
    batch_parser = subparsers.add_parser("batch", help="Batch process directory")
    batch_parser.add_argument("input_dir", help="Input directory")
    batch_parser.add_argument("-o", "--output-dir", default="./transcripts", help="Output directory")
    batch_parser.add_argument(
        "-m", "--model",
        default="base",
        choices=["tiny", "base", "small", "medium", "large-v2", "large-v3"],
        help="Whisper model size"
    )
    batch_parser.add_argument("-l", "--language", help="Source language")
    batch_parser.add_argument(
        "-f", "--format",
        default="srt",
        choices=["srt", "vtt", "txt", "json"],
        help="Output format"
    )
    batch_parser.add_argument("-d", "--diarize", action="store_true", help="Enable diarization")
    batch_parser.add_argument("--device", default="cpu", help="Compute device")
    
    # Serve command
    serve_parser = subparsers.add_parser("serve", help="Start web UI server")
    serve_parser.add_argument("--host", default="127.0.0.1", help="Server host")
    serve_parser.add_argument("--port", type=int, default=5050, help="Server port")
    serve_parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    serve_parser.add_argument(
        "-m", "--model",
        default="base",
        choices=["tiny", "base", "small", "medium", "large-v2", "large-v3"],
        help="Default Whisper model"
    )
    serve_parser.add_argument("--device", default="cpu", help="Compute device")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    if args.command == "transcribe":
        return transcribe_command(args)
    elif args.command == "batch":
        return batch_command(args)
    elif args.command == "serve":
        return serve_command(args)
    
    return 1


if __name__ == "__main__":
    sys.exit(main())
