"""Utility functions for audio processing."""

import os
import tempfile
from pathlib import Path
from typing import Optional

import numpy as np


SUPPORTED_AUDIO_FORMATS = {
    ".mp3", ".wav", ".m4a", ".flac", ".ogg", ".wma", ".aac"
}

SUPPORTED_VIDEO_FORMATS = {
    ".mp4", ".mov", ".avi", ".mkv", ".webm", ".flv"
}


def validate_audio_file(file_path: Path) -> bool:
    """Check if file has supported audio/video extension."""
    suffix = file_path.suffix.lower()
    return suffix in SUPPORTED_AUDIO_FORMATS or suffix in SUPPORTED_VIDEO_FORMATS


def extract_audio(video_path: str, output_format: str = "wav") -> Path:
    """
    Extract audio from video file using ffmpeg.
    
    Args:
        video_path: Path to video file
        output_format: Audio format (wav, mp3, etc.)
        
    Returns:
        Path to extracted audio file
    """
    try:
        from pydub import AudioSegment
    except ImportError:
        raise ImportError("pydub not installed. Install with: pip install pydub")
    
    video_path = Path(video_path)
    
    # Create temp file for extracted audio
    temp_audio = tempfile.NamedTemporaryFile(
        suffix=f".{output_format}",
        delete=False,
        prefix="whisper_audio_"
    )
    temp_audio.close()
    
    try:
        # Extract audio using pydub (which uses ffmpeg under the hood)
        audio = AudioSegment.from_file(str(video_path))
        audio.export(temp_audio.name, format=output_format)
        
        return Path(temp_audio.name)
    except Exception as e:
        # Clean up on failure
        if os.path.exists(temp_audio.name):
            os.unlink(temp_audio.name)
        raise RuntimeError(f"Failed to extract audio: {e}")


def get_audio_duration(audio_path: str) -> Optional[float]:
    """
    Get audio file duration in seconds.
    
    Args:
        audio_path: Path to audio file
        
    Returns:
        Duration in seconds, or None if unable to determine
    """
    try:
        from pydub import AudioSegment
        audio = AudioSegment.from_file(audio_path)
        return len(audio) / 1000.0  # Convert ms to seconds
    except Exception:
        # Fallback: try with librosa if pydub fails
        try:
            import librosa
            y, sr = librosa.load(audio_path, sr=None)
            return len(y) / sr
        except Exception:
            return None


def format_time(seconds: float) -> str:
    """Format seconds as HH:MM:SS."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes:02d}:{secs:02d}"


def chunk_audio(audio_array: np.ndarray, chunk_size: int, overlap: int = 0):
    """
    Split audio array into overlapping chunks.
    
    Args:
        audio_array: Audio samples
        chunk_size: Size of each chunk
        overlap: Overlap between chunks
        
    Yields:
        Audio chunks with start/end indices
    """
    step = chunk_size - overlap
    
    for start in range(0, len(audio_array), step):
        end = min(start + chunk_size, len(audio_array))
        yield audio_array[start:end], start, end
        
        if end >= len(audio_array):
            break
