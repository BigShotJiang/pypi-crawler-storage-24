"""Export transcriptions to various formats (SRT, VTT, TXT, JSON)."""

import json
from pathlib import Path
from typing import Dict, Any, List


def format_timestamp_srt(seconds: float) -> str:
    """Format timestamp for SRT format (HH:MM:SS,mmm)."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def format_timestamp_vtt(seconds: float) -> str:
    """Format timestamp for WebVTT format (HH:MM:SS.mmm)."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"


def export_srt(result: Dict[str, Any], output_path: str) -> None:
    """
    Export transcription to SRT subtitle format.
    
    Args:
        result: Transcription result from TranscriptionEngine
        output_path: Output file path
    """
    segments = result.get("segments", [])
    
    with open(output_path, "w", encoding="utf-8") as f:
        for i, segment in enumerate(segments, 1):
            start = format_timestamp_srt(segment["start"])
            end = format_timestamp_srt(segment["end"])
            text = segment["text"].strip()
            
            # Add speaker label if present
            speaker = segment.get("speaker")
            if speaker:
                text = f"[{speaker}] {text}"
            
            f.write(f"{i}\n")
            f.write(f"{start} --> {end}\n")
            f.write(f"{text}\n\n")


def export_vtt(result: Dict[str, Any], output_path: str) -> None:
    """
    Export transcription to WebVTT subtitle format.
    
    Args:
        result: Transcription result from TranscriptionEngine
        output_path: Output file path
    """
    segments = result.get("segments", [])
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("WEBVTT\n\n")
        
        for segment in segments:
            start = format_timestamp_vtt(segment["start"])
            end = format_timestamp_vtt(segment["end"])
            text = segment["text"].strip()
            
            speaker = segment.get("speaker")
            if speaker:
                text = f"[{speaker}] {text}"
            
            f.write(f"{start} --> {end}\n")
            f.write(f"{text}\n\n")


def export_txt(result: Dict[str, Any], output_path: str) -> None:
    """
    Export transcription to plain text format.
    
    Args:
        result: Transcription result from TranscriptionEngine
        output_path: Output file path
    """
    segments = result.get("segments", [])
    
    with open(output_path, "w", encoding="utf-8") as f:
        # Write metadata header
        f.write(f"# Transcription\n")
        f.write(f"Language: {result.get('language', 'unknown')}\n")
        f.write(f"Duration: {result.get('duration', 0):.1f}s\n")
        f.write(f"Model: {result.get('model', 'unknown')}\n")
        f.write("\n" + "=" * 80 + "\n\n")
        
        # Write transcript with optional speaker labels
        current_speaker = None
        
        for segment in segments:
            speaker = segment.get("speaker")
            text = segment["text"].strip()
            
            # Add speaker header if changed
            if speaker and speaker != current_speaker:
                f.write(f"\n{speaker}:\n")
                current_speaker = speaker
            
            # Add timestamp and text
            timestamp = format_timestamp_srt(segment["start"])
            f.write(f"[{timestamp}] {text}\n")


def export_json(result: Dict[str, Any], output_path: str) -> None:
    """
    Export transcription to JSON format (full structured data).
    
    Args:
        result: Transcription result from TranscriptionEngine
        output_path: Output file path
    """
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)


def export_to_format(result: Dict[str, Any], output_path: str, format: str) -> None:
    """
    Export to specified format based on file extension or format string.
    
    Args:
        result: Transcription result
        output_path: Output file path
        format: Format ('srt', 'vtt', 'txt', 'json')
    """
    format = format.lower()
    
    if format == "srt":
        export_srt(result, output_path)
    elif format == "vtt":
        export_vtt(result, output_path)
    elif format == "txt":
        export_txt(result, output_path)
    elif format == "json":
        export_json(result, output_path)
    else:
        raise ValueError(f"Unsupported format: {format}")
