"""Flask web server for Whisper Studio web UI."""

import os
import json
import tempfile
from pathlib import Path
from typing import Dict, Any

from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_socketio import SocketIO, emit
from werkzeug.utils import secure_filename

from whisper_studio.engine import TranscriptionEngine
from whisper_studio.export import export_srt, export_vtt, export_txt, export_json
from whisper_studio.utils import validate_audio_file, get_audio_duration


# Initialize Flask app
app = Flask(__name__, static_folder="../web", template_folder="../web")
app.config["SECRET_KEY"] = os.urandom(24).hex()
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500MB max upload
app.config["UPLOAD_FOLDER"] = tempfile.mkdtemp(prefix="whisper_studio_")

CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", max_http_buffer_size=500 * 1024 * 1024)

# Global engine instance (initialized on first use)
_engine = None
_engine_config = {}


def get_engine(model_name: str = "base", device: str = "cpu") -> TranscriptionEngine:
    """Get or create transcription engine."""
    global _engine, _engine_config
    
    config = {"model_name": model_name, "device": device}
    
    if _engine is None or _engine_config != config:
        _engine = TranscriptionEngine(model_name=model_name, device=device)
        _engine_config = config
    
    return _engine


@app.route("/")
def index():
    """Serve web UI."""
    return send_from_directory(app.static_folder, "index.html")


@app.route("/health")
def health():
    """Health check endpoint."""
    return jsonify({"status": "ok", "engine_loaded": _engine is not None})


@app.route("/api/models", methods=["GET"])
def list_models():
    """List available Whisper models."""
    return jsonify({
        "models": [
            {"id": "tiny", "size": "39MB", "speed": "32x", "description": "Fastest, good quality"},
            {"id": "base", "size": "74MB", "speed": "16x", "description": "Recommended default"},
            {"id": "small", "size": "244MB", "speed": "6x", "description": "High quality"},
            {"id": "medium", "size": "769MB", "speed": "2x", "description": "Professional grade"},
            {"id": "large-v3", "size": "1.5GB", "speed": "1x", "description": "Maximum accuracy"},
        ]
    })


@socketio.on("connect")
def handle_connect():
    """Handle WebSocket connection."""
    emit("status", {"message": "Connected to Whisper Studio"})


@socketio.on("transcribe")
def handle_transcribe(data: Dict[str, Any]):
    """Handle transcription request via WebSocket."""
    try:
        # Validate input
        if "file_path" not in data:
            emit("error", {"message": "No file_path provided"})
            return
        
        file_path = data["file_path"]
        model_name = data.get("model", "base")
        language = data.get("language")
        diarize = data.get("diarize", False)
        num_speakers = data.get("num_speakers")
        
        if not os.path.exists(file_path):
            emit("error", {"message": f"File not found: {file_path}"})
            return
        
        # Send progress update
        emit("progress", {"stage": "loading_model", "message": f"Loading {model_name} model..."})
        
        # Get engine
        engine = get_engine(model_name=model_name, device=data.get("device", "cpu"))
        
        # Get audio duration for progress tracking
        duration = get_audio_duration(file_path)
        if duration:
            emit("progress", {"stage": "analyzing", "message": f"Audio duration: {duration:.1f}s"})
        
        # Transcribe
        emit("progress", {"stage": "transcribing", "message": "Transcribing audio..."})
        
        result = engine.transcribe(
            file_path,
            language=language,
            diarize=diarize,
            num_speakers=num_speakers
        )
        
        # Send result
        emit("progress", {"stage": "complete", "message": "Transcription complete"})
        emit("result", result)
        
    except Exception as e:
        emit("error", {"message": str(e)})


@app.route("/api/upload", methods=["POST"])
def upload_file():
    """Handle file upload."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    file = request.files["file"]
    
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400
    
    if not validate_audio_file(Path(file.filename)):
        return jsonify({"error": "Unsupported file format"}), 400
    
    # Save file
    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(file_path)
    
    # Get metadata
    duration = get_audio_duration(file_path)
    
    return jsonify({
        "file_path": file_path,
        "filename": filename,
        "duration": duration,
        "size": os.path.getsize(file_path)
    })


@app.route("/api/export", methods=["POST"])
def export_transcription():
    """Export transcription to specified format."""
    data = request.json
    
    if "result" not in data or "format" not in data:
        return jsonify({"error": "Missing result or format"}), 400
    
    result = data["result"]
    format = data["format"]
    
    # Create temp file for export
    output_path = os.path.join(
        app.config["UPLOAD_FOLDER"],
        f"transcript_{os.urandom(4).hex()}.{format}"
    )
    
    try:
        if format == "srt":
            export_srt(result, output_path)
        elif format == "vtt":
            export_vtt(result, output_path)
        elif format == "txt":
            export_txt(result, output_path)
        elif format == "json":
            export_json(result, output_path)
        else:
            return jsonify({"error": f"Unsupported format: {format}"}), 400
        
        # Read file and send as response
        with open(output_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        os.unlink(output_path)
        
        return jsonify({"content": content, "filename": f"transcript.{format}"})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def run_server(
    host: str = "127.0.0.1",
    port: int = 5050,
    debug: bool = False,
    model_name: str = "base",
    device: str = "cpu"
):
    """
    Run Flask development server.
    
    Args:
        host: Server host
        port: Server port
        debug: Enable debug mode
        model_name: Default Whisper model
        device: Compute device
    """
    # Pre-load model
    get_engine(model_name=model_name, device=device)
    
    # Run server
    socketio.run(app, host=host, port=port, debug=debug, allow_unsafe_werkzeug=True)
