"""Core transcription engine using OpenAI Whisper."""

import warnings
from pathlib import Path
from typing import Dict, List, Optional, Any

import whisper
import torch
import numpy as np

from whisper_studio.diarization import add_speaker_labels
from whisper_studio.utils import extract_audio, get_audio_duration


# Suppress warnings from whisper
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


class TranscriptionEngine:
    """Handles audio transcription using Whisper models."""
    
    SUPPORTED_MODELS = ["tiny", "base", "small", "medium", "large-v2", "large-v3"]
    
    def __init__(
        self,
        model_name: str = "base",
        device: str = "cpu",
        compute_type: str = "int8",
        download_root: Optional[str] = None
    ):
        """
        Initialize transcription engine.
        
        Args:
            model_name: Whisper model size (tiny, base, small, medium, large-v2, large-v3)
            device: Compute device (cpu, cuda, mps)
            compute_type: Precision (int8, float16, float32)
            download_root: Custom path for model downloads
        """
        if model_name not in self.SUPPORTED_MODELS:
            raise ValueError(f"Invalid model: {model_name}. Choose from {self.SUPPORTED_MODELS}")
        
        self.model_name = model_name
        self.device = self._get_device(device)
        self.compute_type = compute_type
        
        print(f"Loading Whisper model '{model_name}' on {self.device}...")
        self.model = whisper.load_model(
            model_name,
            device=self.device,
            download_root=download_root
        )
        
        # Configure compute type for efficiency
        if compute_type == "int8" and self.device == "cpu":
            # int8 optimization for CPU
            pass  # Whisper handles this internally
        elif compute_type == "float16" and self.device in ["cuda", "mps"]:
            self.model = self.model.half()
        
        print("✓ Model loaded successfully")
    
    def _get_device(self, device: str) -> str:
        """Determine best available device."""
        if device == "cuda" and torch.cuda.is_available():
            return "cuda"
        elif device == "mps" and torch.backends.mps.is_available():
            return "mps"
        else:
            if device != "cpu":
                print(f"Warning: {device} not available, falling back to CPU")
            return "cpu"
    
    def transcribe(
        self,
        audio_path: str,
        language: Optional[str] = None,
        task: str = "transcribe",
        initial_prompt: Optional[str] = None,
        diarize: bool = False,
        num_speakers: Optional[int] = None,
        verbose: bool = False
    ) -> Dict[str, Any]:
        """
        Transcribe audio file.
        
        Args:
            audio_path: Path to audio/video file
            language: Source language code (None = auto-detect)
            task: 'transcribe' or 'translate' (to English)
            initial_prompt: Optional prompt to guide model
            diarize: Enable speaker diarization
            num_speakers: Expected number of speakers (None = auto-detect)
            verbose: Print detailed progress
            
        Returns:
            Dict with transcription results:
            {
                "text": "full transcript",
                "segments": [
                    {
                        "start": 0.0,
                        "end": 2.5,
                        "text": "segment text",
                        "speaker": "SPEAKER_00"  # if diarize=True
                    },
                    ...
                ],
                "language": "en",
                "duration": 120.5
            }
        """
        audio_path = Path(audio_path)
        
        # Handle video files (extract audio first)
        if audio_path.suffix.lower() in [".mp4", ".mov", ".avi", ".mkv", ".webm"]:
            print(f"Extracting audio from video: {audio_path.name}")
            audio_path = extract_audio(str(audio_path))
        
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio file not found: {audio_path}")
        
        # Get audio duration for metadata
        duration = get_audio_duration(str(audio_path))
        
        # Transcribe with Whisper
        print(f"Transcribing with model '{self.model_name}'...")
        
        result = self.model.transcribe(
            str(audio_path),
            language=language,
            task=task,
            initial_prompt=initial_prompt,
            verbose=verbose,
            word_timestamps=True  # Needed for diarization alignment
        )
        
        # Add speaker labels if requested
        if diarize:
            print("Performing speaker diarization...")
            try:
                result = add_speaker_labels(
                    str(audio_path),
                    result,
                    num_speakers=num_speakers
                )
                print(f"✓ Identified {len(set(s.get('speaker', 'UNKNOWN') for s in result['segments']))} speakers")
            except Exception as e:
                print(f"Warning: Diarization failed ({e}), continuing without speaker labels")
        
        # Add metadata
        result["duration"] = duration
        result["model"] = self.model_name
        
        return result
    
    def transcribe_batch(
        self,
        audio_paths: List[str],
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Transcribe multiple audio files.
        
        Args:
            audio_paths: List of audio file paths
            **kwargs: Arguments passed to transcribe()
            
        Returns:
            List of transcription results
        """
        results = []
        
        for i, path in enumerate(audio_paths, 1):
            print(f"\n[{i}/{len(audio_paths)}] Processing: {Path(path).name}")
            try:
                result = self.transcribe(path, **kwargs)
                results.append(result)
            except Exception as e:
                print(f"Error transcribing {path}: {e}")
                results.append({"error": str(e), "path": path})
        
        return results
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about loaded model."""
        return {
            "name": self.model_name,
            "device": self.device,
            "compute_type": self.compute_type,
            "parameters": sum(p.numel() for p in self.model.parameters()),
        }
