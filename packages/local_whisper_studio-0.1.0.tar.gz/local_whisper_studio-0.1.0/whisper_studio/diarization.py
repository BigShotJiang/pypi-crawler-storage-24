"""Speaker diarization using pyannote.audio."""

import warnings
from pathlib import Path
from typing import Dict, List, Optional, Any

import torch
import numpy as np

# Suppress pyannote warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


def add_speaker_labels(
    audio_path: str,
    transcription_result: Dict[str, Any],
    num_speakers: Optional[int] = None,
    min_speakers: int = 1,
    max_speakers: int = 10
) -> Dict[str, Any]:
    """
    Add speaker labels to transcription segments using diarization.
    
    Args:
        audio_path: Path to audio file
        transcription_result: Output from Whisper transcription
        num_speakers: Expected number of speakers (None = auto-detect)
        min_speakers: Minimum speakers to detect
        max_speakers: Maximum speakers to detect
        
    Returns:
        Updated transcription result with 'speaker' field in each segment
    """
    try:
        from pyannote.audio import Pipeline
    except ImportError:
        raise ImportError(
            "pyannote.audio not installed. Install with: pip install pyannote-audio"
        )
    
    # Load pretrained diarization pipeline
    # Note: This requires accepting user agreement at https://huggingface.co/pyannote/speaker-diarization
    # For production, you'd use an auth token: use_auth_token="YOUR_HF_TOKEN"
    try:
        pipeline = Pipeline.from_pretrained(
            "pyannote/speaker-diarization@2.1",
            use_auth_token=False  # Set to your HF token in production
        )
    except Exception as e:
        # Fallback to simpler energy-based speaker detection
        print(f"Warning: Could not load pyannote pipeline ({e})")
        return _simple_speaker_detection(audio_path, transcription_result, num_speakers)
    
    # Configure number of speakers
    if num_speakers is not None:
        diarization = pipeline(audio_path, num_speakers=num_speakers)
    else:
        diarization = pipeline(audio_path, min_speakers=min_speakers, max_speakers=max_speakers)
    
    # Map diarization results to transcription segments
    segments = transcription_result.get("segments", [])
    
    for segment in segments:
        start_time = segment["start"]
        end_time = segment["end"]
        
        # Find dominant speaker in this time window
        speaker_durations = {}
        
        for turn, _, speaker in diarization.itertracks(yield_label=True):
            # Calculate overlap with segment
            overlap_start = max(turn.start, start_time)
            overlap_end = min(turn.end, end_time)
            overlap_duration = max(0, overlap_end - overlap_start)
            
            if overlap_duration > 0:
                speaker_durations[speaker] = speaker_durations.get(speaker, 0) + overlap_duration
        
        # Assign speaker with most time in this segment
        if speaker_durations:
            dominant_speaker = max(speaker_durations.items(), key=lambda x: x[1])[0]
            segment["speaker"] = dominant_speaker
        else:
            segment["speaker"] = "SPEAKER_UNKNOWN"
    
    return transcription_result


def _simple_speaker_detection(
    audio_path: str,
    transcription_result: Dict[str, Any],
    num_speakers: Optional[int] = None
) -> Dict[str, Any]:
    """
    Fallback speaker detection using energy-based clustering.
    Less accurate than pyannote but doesn't require HuggingFace auth.
    """
    try:
        import librosa
        from scipy.cluster.hierarchy import fcluster, linkage
        from scipy.spatial.distance import pdist
    except ImportError:
        # If even this fails, just label all segments as same speaker
        for segment in transcription_result.get("segments", []):
            segment["speaker"] = "SPEAKER_00"
        return transcription_result
    
    # Load audio
    audio, sr = librosa.load(audio_path, sr=16000)
    
    segments = transcription_result.get("segments", [])
    
    # Extract features for each segment
    features = []
    for segment in segments:
        start_sample = int(segment["start"] * sr)
        end_sample = int(segment["end"] * sr)
        segment_audio = audio[start_sample:end_sample]
        
        if len(segment_audio) > 0:
            # Simple features: mean/std of MFCCs
            mfcc = librosa.feature.mfcc(y=segment_audio, sr=sr, n_mfcc=13)
            features.append(np.concatenate([mfcc.mean(axis=1), mfcc.std(axis=1)]))
        else:
            features.append(np.zeros(26))
    
    if not features:
        return transcription_result
    
    features = np.array(features)
    
    # Cluster segments
    if num_speakers is None:
        # Auto-detect: use elbow method (simplified)
        num_speakers = min(3, len(segments))  # Default to 3 speakers max
    
    if len(segments) <= num_speakers:
        # Not enough segments to cluster
        for i, segment in enumerate(segments):
            segment["speaker"] = f"SPEAKER_{i:02d}"
    else:
        # Hierarchical clustering
        distances = pdist(features, metric="euclidean")
        linkage_matrix = linkage(distances, method="ward")
        clusters = fcluster(linkage_matrix, num_speakers, criterion="maxclust")
        
        for segment, cluster_id in zip(segments, clusters):
            segment["speaker"] = f"SPEAKER_{cluster_id - 1:02d}"
    
    return transcription_result
