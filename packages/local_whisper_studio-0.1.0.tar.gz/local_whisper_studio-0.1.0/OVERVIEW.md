# local-whisper-studio

A desktop-first audio transcription and subtitle editor powered by OpenAI's Whisper, running entirely offline with zero API costs. Drag in video/audio files, get instant accurate transcripts with speaker diarization, edit transcripts with waveform sync, and export to SRT/VTT/TXT. Fills the gap between your audio-heavy projects (Beat Forge, VR Beat Sync) and the "offline AI" trend from research—no existing project in your portfolio handles speech-to-text, and Whisper adoption is exploding in content creator workflows.
