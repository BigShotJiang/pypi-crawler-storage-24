# Local Whisper Studio

Offline speech-to-text with waveform editing and subtitle export—no API calls, no monthly bills.

## What is this?

Local Whisper Studio is a desktop-first transcription and subtitle editor that brings OpenAI's Whisper directly to your machine. Drag in audio or video files, get instant transcripts with automatic speaker diarization, sync edits to the waveform in real-time, and export to SRT, VTT, or TXT formats. Everything runs offline—no API costs, no internet dependency, no vendor lock-in.

## Features

- **Offline Transcription** – Powered by OpenAI Whisper; runs entirely on your hardware
- **Speaker Diarization** – Automatically identify and label different speakers
- **Waveform Editor** – Sync transcript edits to audio timeline with visual feedback
- **Multi-format Export** – SRT, VTT, and plain text subtitle formats
- **Video & Audio Support** – Handle MP4, MOV, MP3, WAV, and more
- **Zero API Costs** – No recurring bills or cloud dependencies
- **Web UI & CLI** – Choose your workflow: browser interface or command-line scripting

## Quick Start

### Installation

Requires Python 3.9+

```bash
# Clone the repository
git clone <repo-url>
cd local-whisper-studio

# Install dependencies
pip install -e .

# Download Whisper model (first run only)
whisper-studio download-model base
```

### Usage

**Web Interface:**
```bash
whisper-studio serve
# Opens http://localhost:5000 in your browser
```

**CLI:**
```bash
# Transcribe an audio file
whisper-studio transcribe audio.mp3 --output transcript.srt --format srt

# With diarization
whisper-studio transcribe video.mp4 --diarize --output subtitled.srt
```

**Python API:**
```python
from whisper_studio import TranscriptionEngine

engine = TranscriptionEngine(model="base")
result = engine.transcribe("audio.mp3")

for segment in result.segments:
    print(f"{segment.speaker}: {segment.text}")
```

## Tech Stack

- **Whisper** – Speech recognition model (OpenAI)
- **Pyannote** – Speaker diarization
- **FastAPI** – Web server
- **Vanilla JS + Wavesurfer.js** – Waveform editor UI
- **FFmpeg** – Audio/video processing

## License

MIT