!pip install scikit-fuzzy --quiet
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
quality = ctrl.Antecedent(np.arange(0, 11, 1), 'quality') #Antecendent means input
service = ctrl.Antecedent(np.arange(0, 11, 1), 'service')
tip = ctrl.Consequent (np.arange(0, 26, 1), 'tip')#Consequent means output
quality.automf(3) # creates linguistic variables(poor,average,good) + membership functions(trimf) automatically.
service.automf(3) # creates linguistic variables(poor,average,good) + membership functions automatically.
tip['low'] = fuzz.trimf(tip.universe, [0, 0, 13])
tip['medium'] = fuzz.trimf(tip.universe, [0, 13, 25])
tip['high'] = fuzz.trimf(tip.universe, [13, 25, 25])
quality.view()
service.view()
tip.view()
rule1 = ctrl.Rule(quality['poor'] | service ['poor'], tip['low'])#IF quality is poor OR service is poor,THEN tip is low
rule2 = ctrl.Rule(service['average'], tip['medium'])
rule3 = ctrl.Rule(quality['good'] | service['good'],tip['high'])
tipping_ctrl = ctrl.ControlSystem ([rule1, rule2, rule3])#Combines all fuzzy rules into one control system
tipping = ctrl.ControlSystemSimulation(tipping_ctrl)#Creates a simulation object
tipping.input['quality'] = 6.5
tipping.input['service'] = 9.8
tipping.compute()
print("Recommended Tip (%):", tipping.output['tip'])
tip.view(sim=tipping)
