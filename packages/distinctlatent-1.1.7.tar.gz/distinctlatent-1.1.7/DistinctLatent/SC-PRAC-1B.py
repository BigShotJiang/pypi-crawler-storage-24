import numpy as np
def binary_sigmoid(x):
  return 1 / (1 + np.exp(-x))
def bipolar_sigmoid(x):
  return (2 / (1 + np.exp(-x))) - 1
def binary_step(x):
  return np.where(x>=0 ,1,0)
def bipolar_step(x):
  return np.where(x>=0 ,1,-1)
def ramp_function(x):
  return np.maximum(0,x)
inputs = 0.93 + 0.45
print("Binary Sigmoid Output:", binary_sigmoid(inputs))
print("Bipolar Sigmoid Output:", bipolar_sigmoid(inputs))
print("Binary Step Output:", binary_step(inputs))
print("Bipolar Step Output:", bipolar_step(inputs))
print("Ramp Function Output:", ramp_function(inputs))
