theta = 1
def output(w,X):
  return [int(x1 * w[0] + x2 * w[1] >= theta) for x1,x2 in X]
X = [(0,0),(0,1),(1,0),(1,1)]
print(f"X = {X}")
w1 = [1, -1]
Y1 = output(w1, X)
print(f"Y1={Y1}")
w2 = [-1, 1]
Y2 = output(w2, X)
print(f"Y2={Y2}")
Y = list(zip(Y1,Y2))
print(f"Y={Y}")
w3 = [1,1]
Z = output(w3,Y)
print(f"Z={Z}")
