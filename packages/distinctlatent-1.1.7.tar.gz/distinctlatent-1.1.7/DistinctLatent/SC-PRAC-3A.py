import numpy as np
x1 = np.array([1,1,1,-1,1,-1,1,1,1])
x2 = np.array([1,1,1,1,-1,1,1,1,1])
y1 = 1
y2 = -1
w = np.zeros(9 , dtype=int)
b = 0
#apply hebbs rule for first pattern
w = w + x1 * y1
b = b + y1
#apply hebbs rule for second pattern
w = w + x2 * y2
b = b + y2
print("Final Weights:",w)
print("Final Bias:",b)
