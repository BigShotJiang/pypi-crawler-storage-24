import numpy as np                      
X = np.array([                                 
    [1, 1, 0, 0],
    [1, 1, 1, 0],
    [0, 0, 1, 1]
])
vigilance = 0.6                              
weights = []                                     
for x in X:                                      
    matched = False                              
    for i, w in enumerate(weights):              
        similarity = np.sum(x & w) / np.sum(x)   
        if similarity >= vigilance:              
           weights[i] = x & w                    
           matched = True                        
           break
    if not matched:                              
        weights.append(x)
print("Final Categories:")                       
category_number = 1
for w in weights:
    print("Category", category_number, ":", w)
    category_number = category_number + 1
