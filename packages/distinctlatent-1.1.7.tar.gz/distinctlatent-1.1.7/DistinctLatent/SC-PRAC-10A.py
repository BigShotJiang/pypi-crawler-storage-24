import random
def create_population(size):
    return [random.randint(0, 100) for _ in range(size)]
def fitness(x):
    return x
def selection(population):
    population.sort(key=fitness, reverse=True)
    return population[0], population[1]
def crossover(parent1, parent2):
    return (parent1 + parent2) // 2
def mutation(child):
    if random.random() < 0.1:
        return child + random.choice([-1, 1])
    return child
def genetic_algorithm(pop_size, generations):
    population = create_population(pop_size)
    for _ in range(generations):
        if len(population) < 2:
            population.extend(create_population(2 - len(population)))
        parent1, parent2 = selection(population)
        child = crossover(parent1, parent2)
        child = mutation(child)
        population.sort(key=fitness)
        population[0] = child
    best = max(population, key=fitness)
    return best
best_solution = genetic_algorithm(pop_size=10, generations=20)
print("Best Solution found:", best_solution)
print("Fitness Value of best solution:", fitness(best_solution))

