import numpy as np
class HopfieldNetwork:
    def __init__(self, num_neurons):
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))
    def train(self, patterns):
        for pattern in patterns:
            pattern = pattern.reshape(self.num_neurons, 1)
            self.weights += np.dot(pattern, pattern.T)
        np.fill_diagonal(self.weights, 0)
    def recall(self, pattern, iterations=5):
        output = pattern.copy()
        for _ in range(iterations):
            for i in range(self.num_neurons):
                net_input = np.dot(self.weights[i], output)
                output[i] = 1 if net_input >= 0 else -1
        return output
patterns = [
    np.array([1, -1, 1, -1]),
    np.array([-1, 1, -1, 1])
]
hopfield = HopfieldNetwork(num_neurons=4)
hopfield.train(patterns)
test_pattern = np.array([1, -1, -1, -1])
recalled_pattern = hopfield.recall(test_pattern)
print("Stored Patterns:")
for p in patterns:
    print(p)
print("\nNoisy Input Pattern:")
print(test_pattern)
print("\nRecalled Pattern:")
print(recalled_pattern)
