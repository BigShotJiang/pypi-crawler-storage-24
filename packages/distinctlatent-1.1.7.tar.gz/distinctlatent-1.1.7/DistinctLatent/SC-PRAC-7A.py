import numpy as np
X = np.array([ [2, 3],
    [1, 1],
    [2, 1],
    [-1, -1],
    [-2, -3],
    [-3, -2]])
y = np.array([1, 1, 1, -1, -1, -1])
w = np.zeros(2)
b = 0
lr = 0.1
epochs = 10
for _ in range(epochs):
    for i in range(len(X)):
        out = np.dot(X[i], w) + b 
        pred = 1 if out >= 0 else -1
        if pred != y[i]:
            w = w + lr * y[i] * X[i]
            b = b + lr * y[i]
print("Weights:", w)
print("Bias:", b)
test = np.array([3, 4])
res = np.dot(test, w) + b
print("Prediction:", 1 if res >= 0 else -1)
