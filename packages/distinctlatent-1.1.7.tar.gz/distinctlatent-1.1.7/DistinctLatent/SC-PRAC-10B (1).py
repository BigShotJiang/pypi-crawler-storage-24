import random
import math
class City:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def distance(self, city):
        return math.sqrt((self.x - city.x)**2 + (self.y - city.y)**2)
    def __repr__(self):
        return f"({self.x},{self.y})"
class Fitness:
    def __init__(self, route):
        self.route = route
    def total_distance(self):
        dist = 0
        for i in range(len(self.route)):
            dist += self.route[i].distance(
                self.route[(i+1) % len(self.route)]
            )
        return dist
    def fitness(self):
        return 1 / self.total_distance()
def create_route(cities):
    return random.sample(cities, len(cities))
def create_population(size, cities):
    return [create_route(cities) for _ in range(size)]
def select_best(population):
population.sort(
        key=lambda x: Fitness(x).fitness(),
        reverse=True
    )
    return population[0], population[1]
def crossover(parent1, parent2):
    start, end = sorted(
        [random.randint(0, len(parent1)-1) for _ in range(2)]
    )
    child_part = parent1[start:end]
    child = child_part + [
        city for city in parent2 if city not in child_part
    ]
    return child
def mutate(route, rate=0.1):
    for i in range(len(route)):
        if random.random() < rate:
            j = random.randint(0, len(route)-1)
            route[i], route[j] = route[j], route[i]
    return route
def next_generation(population):
    parent1, parent2 = select_best(population)
    new_population = [parent1, parent2]
    while len(new_population) < len(population):
        child = crossover(parent1, parent2)
        child = mutate(child)
        new_population.append(child)
    return new_population
cities = [  
    City(10, 20),
    City(30, 40),
    City(50, 60),
    City(70, 80),
    City(20, 90)
]
population = create_population(4, cities)
print("Initial Best Distance:",
      Fitness(select_best(population)[0]).total_distance())
for i in range(5):
    population = next_generation(population)
print("Final Best Distance:",
      Fitness(select_best(population)[0]).total_distance())

