a = [1, 2, 3]
b = a
c = [1, 2, 3]
print(a is b)
print(a is c)
print(a == c)
x = 100
y = 100
print(x is y)
x2 = 300
y2 = 300
print(x2 is y2)
