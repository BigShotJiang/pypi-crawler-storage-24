def and_not(x1,x2):
  w1 = 1 #weight for x1
  w2 = -1 #weight for x2
  threshold = 1  #threshold value
  weighted_sum = (x1*w1) + (x2*w2)
  if weighted_sum >= threshold:
    return 1 #neuron fires
  else:
    return 0 #neuron does not fires
print("Truth Table for AND-NOT:")
print("x1 x2 | y")
print("----------")
for x1 in [0,1]:
  for x2 in [0,1]:
    y = and_not(x1,x2)
    print(f"{x1}  {x2}  | {y}")
