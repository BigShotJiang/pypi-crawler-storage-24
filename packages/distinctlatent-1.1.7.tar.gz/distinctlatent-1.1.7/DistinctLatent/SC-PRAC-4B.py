import math
x = 1
target = 0.8
learning_rate = 0.5
w1 = 0.4
w2 = 0.6
def sigmoid(x):
    return 1 / (1 + math.exp(-x))
net_hidden = x * w1
hidden_output = sigmoid(net_hidden)
net_output = hidden_output * w2
final_output = sigmoid(net_output)
print("Network Output:", final_output)
error = target - final_output
delta_output = error * final_output * (1 - final_output)
delta_hidden = delta_output * w2 * hidden_output * (1 - hidden_output)
w2 = w2 + learning_rate * delta_output * hidden_output
w1 = w1 + learning_rate * delta_hidden * x
print("Updated Weight w1:", w1)
print("Updated Weight w2:", w2)
