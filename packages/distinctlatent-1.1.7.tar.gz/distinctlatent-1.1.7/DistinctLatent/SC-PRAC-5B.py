import math
n = int(input("Enter number of RBF neurons: "))
x = float(input("Enter input value x: "))
centers = []
sigmas = []
weights = []
for i in range(n):
    c = float(input(f"Enter center c{i+1}: "))
    centers.append(c)
    s = float(input(f"Enter sigma σ{i+1}: "))
    sigmas.append(s)
    w = float(input(f"Enter weight w{i+1}: "))
    weights.append(w)
bias = float(input("Enter bias: "))
print("\n--- RBF Computation ---")
rbf_outputs = []
for i in range(n):
    rbf = math.exp(-((x - centers[i]) ** 2) / (2 * sigmas[i] ** 2))
    rbf_outputs.append(rbf)
    print(f"RBF Output φ{i+1} =", round(rbf, 4))
net = 0
for i in range(n):
    net = net + (weights[i] * rbf_outputs[i])
net = net + bias
print("\nNet Output =", round(net, 4))
output = net
print("Final Output =", round(output, 4))
