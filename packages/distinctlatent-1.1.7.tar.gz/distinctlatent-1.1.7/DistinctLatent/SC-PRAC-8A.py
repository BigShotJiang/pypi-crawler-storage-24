fruits = ["apple", "banana", "cherry"]
print("banana" in fruits)#true
print("orange" in fruits)#false
print("orange" not in fruits)#true
text = 'hello world'
print('hello' in text)#true
print('z' not in text)#true
numbers = {1, 2, 3}
print(2 in numbers)#true
student = {"name": "Atharva", "roll": 4}
print("name" in student)#true
print("Atharva" in student)#false because python only checks keys by default
