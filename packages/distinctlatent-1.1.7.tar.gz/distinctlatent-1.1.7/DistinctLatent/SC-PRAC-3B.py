x = np.array([float(input("Input:")) for _ in range(3)])
w = np.array([float(input("Weight:")) for _ in range(3)])
d = np.array([float(input("Desired Output:")) for _ in range(3)])
lr = float(input("Learning Rate:"))
while True:
  y = x * w
  if np.array_equal(d,y):
    break
  w += lr * (d-y)
  print("Updated Weights:",w)
  print("Actual Outputs:",y)
print("Final Weights:",w)
print("Actual Output:",y)
print("Desired Output:",d)
