import numpy as np #numpy is used for numerical operations
data = np.array([
    [0.1, 0.1],
    [0.2, 0.2],
    [0.8, 0.8],
    [0.9, 0.9],
    [0.1, 0.9],
    [0.9, 0.1]
])
num_neurons = 4 # Number of neurons in the SOM (e.g., 2x2 grid, flattened)
input_dim = data.shape[1]# Number of features in input data
learning_rate = 0.5 # Initial learning rate
epochs = 50 # Number of training iterations
weights = np.random.rand(num_neurons, input_dim)
print("Initial Weights:")
print(weights)
print("\nStarting SOM Training...")
for epoch in range(epochs):
    np.random.shuffle(data)
    for x in data:
        distances = np.linalg.norm(weights - x, axis=1)
        bmu_index = np.argmin(distances)
        weights[bmu_index] += learning_rate * (x - weights[bmu_index])
    learning_rate *= (1.0 - (epoch / epochs))
print("\nSOM Training Complete.")
print("\nFinal Weights:")
print(weights)
