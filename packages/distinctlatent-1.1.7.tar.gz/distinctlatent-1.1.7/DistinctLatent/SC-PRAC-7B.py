 import numpy as np
class HopfieldNetwork:
    def __init__(self, size):
        self.size = size
        self.weights = np.zeros((size, size))
    def train(self, patterns):
        for p in patterns:
            p = np.array(p)
            self.weights += np.outer(p, p)
        np.fill_diagonal(self.weights, 0)
    def sign(self, x):
        return 1 if x >= 0 else -1
    def recall(self, pattern, steps=5):
        pattern = np.array(pattern)
        for _ in range(steps):
            for i in range(self.size):
                net_input = np.dot(self.weights[i], pattern)
                pattern[i] = self.sign(net_input)
        return pattern
patterns = [[1, -1, 1, -1], [-1, 1, -1, 1]]
hn = HopfieldNetwork(4)
hn.train(patterns)
test = [1, -1, -1, -1]
result = hn.recall(test)
print("Input Pattern   :", test)
print("Output Pattern  :", result)
