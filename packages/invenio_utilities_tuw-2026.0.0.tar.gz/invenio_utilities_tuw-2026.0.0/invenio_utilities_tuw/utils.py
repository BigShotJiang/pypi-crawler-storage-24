# -*- coding: utf-8 -*-
#
# Copyright (C) 2020 - 2025 TU Wien.
#
# Invenio-Utilities-TUW is free software; you can redistribute it and/or
# modify it under the terms of the MIT License; see LICENSE file for more
# details.

"""Utility functions for Invenio-Utilities-TUW."""

from contextlib import contextmanager
from difflib import SequenceMatcher

from flask import current_app
from flask_principal import Identity, identity_loaded
from invenio_access.permissions import any_user, system_identity
from invenio_access.utils import get_identity as base_get_identity
from invenio_accounts import current_accounts
from invenio_accounts.models import User
from werkzeug.utils import import_string


def get_or_import(value, default=None):
    """Try an import if value is an endpoint string, or return value itself."""
    if isinstance(value, str):
        return import_string(value)
    elif value:
        return value

    return default


def get_user_by_identifier(id_or_email):
    """Get the user specified via email or ID."""
    if id_or_email is not None:
        # note: this seems like the canonical way to go
        #       'id_or_email' can be either an integer (id) or email address
        u = current_accounts.datastore.get_user(id_or_email)
        if u is not None:
            return u
        else:
            raise LookupError("user not found: %s" % id_or_email)

    raise ValueError("id_or_email cannot be None")


def get_identity(user: User | str | int, skip_signal: bool = False) -> Identity:
    """Get the Identity for the user, supplied directly or specified via email or ID.

    This function is mainly useful for development, testing, and debugging purposes.
    """
    if user is not None:
        if isinstance(user, (str, int)):
            if user == "system":
                return system_identity

            user = get_user_by_identifier(user)

        identity = base_get_identity(user)
        identity.provides.add(any_user)

        # some needs are given out via the "identity_loaded" signal handlers
        if not skip_signal:
            try:
                identity_loaded.send(
                    current_app._get_current_object(), identity=identity
                )

            except RuntimeError:
                # if we're working outside a request context, we need a test context
                with current_app.test_request_context():
                    identity_loaded.send(
                        current_app._get_current_object(), identity=identity
                    )

        return identity

    return system_identity


get_identity_for_user = get_identity
"""Alias to ``invenio_utilities_tuw.utils.get_identity()``."""


def similarity(a: str, b: str) -> float:
    """Calculate the similarity between two strings."""
    return SequenceMatcher(None, a, b).ratio()


@contextmanager
def monkey_patch_temp(object_, method_name, new_method):
    """Temporarily monkey patch an object's method."""
    x = getattr(object_, method_name)
    setattr(object_, method_name, new_method.__get__(object_, type(object_)))
    yield object_
    setattr(object_, method_name, x)
