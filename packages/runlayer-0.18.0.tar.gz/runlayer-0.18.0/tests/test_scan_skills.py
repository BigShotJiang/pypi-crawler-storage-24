"""Tests for skill discovery in scan."""

from pathlib import Path
from unittest import mock

import pytest

from runlayer_cli.scan import skill_scanner
from runlayer_cli.scan.skill_scanner import (
    ARTIFACT_AGENTS_MD,
    ARTIFACT_CLAUDE_MD,
    ARTIFACT_CLINE_RULE,
    ARTIFACT_COPILOT_INSTRUCTIONS,
    ARTIFACT_CURSOR_RULE,
    ARTIFACT_GEMINI_MD,
    ARTIFACT_SKILL_MD,
    ARTIFACT_WINDSURF_RULE,
    MAX_SINGLE_FILE_BYTES,
    DiscoveredSkillArtifact,
    SkillFile,
    _collect_files_safe,
    _infer_project_root,
    _is_dependency_path,
    _parse_frontmatter,
    _scan_rule_directory,
    _scan_single_file_artifact,
    _scan_skill_md_dir,
    process_skill_paths,
    scan_global_skills,
)
from runlayer_cli.scan.service import submit_discovered_skills


class TestParseFrontmatter:
    def test_valid_frontmatter(self):
        content = "---\nname: my-skill\ndescription: Does stuff\n---\n# Body"
        fm = _parse_frontmatter(content)
        assert fm["name"] == "my-skill"
        assert fm["description"] == "Does stuff"

    def test_no_frontmatter(self):
        assert _parse_frontmatter("# Just markdown") == {}

    def test_invalid_yaml(self):
        assert _parse_frontmatter("---\n: :\n---\n") == {}

    def test_unclosed_frontmatter(self):
        assert _parse_frontmatter("---\nname: x\n# no close") == {}


class TestIsDependencyPath:
    def test_node_modules(self):
        assert _is_dependency_path(Path("/project/node_modules/pkg/.cursor/rules"))

    def test_venv(self):
        assert _is_dependency_path(Path("/project/.venv/lib/skill"))

    def test_user_path(self):
        assert not _is_dependency_path(Path("/home/user/project/skills/my-skill"))


class TestCollectFilesSafe:
    def test_collects_supported_files(self, tmp_path):
        (tmp_path / "SKILL.md").write_text("# skill")
        (tmp_path / "helper.py").write_text("print('hi')")
        (tmp_path / "image.png").write_bytes(b"\x89PNG")

        files, symlinks, oversized = _collect_files_safe(tmp_path)
        titles = {f.title for f in files}
        assert "SKILL.md" in titles
        assert "helper.py" in titles
        assert "image.png" not in titles
        assert not oversized
        assert symlinks == []

    def test_skips_external_symlink(self, tmp_path):
        external = tmp_path / "external"
        external.mkdir()
        secret = external / "secret.py"
        secret.write_text("SECRET_KEY='abc'")

        skill_dir = tmp_path / "my-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("# skill")
        link = skill_dir / "steal.py"
        link.symlink_to(secret)

        files, symlinks, oversized = _collect_files_safe(skill_dir)
        titles = {f.title for f in files}
        assert "steal.py" not in titles
        assert str(link) in symlinks

    def test_follows_internal_symlink(self, tmp_path):
        skill_dir = tmp_path / "my-skill"
        skill_dir.mkdir()
        real_file = skill_dir / "real.py"
        real_file.write_text("print('real')")
        link = skill_dir / "alias.py"
        link.symlink_to(real_file)
        (skill_dir / "SKILL.md").write_text("# skill")

        files, symlinks, oversized = _collect_files_safe(skill_dir)
        titles = {f.title for f in files}
        assert "alias.py" in titles
        assert symlinks == []

    def test_oversized_file_flagged(self, tmp_path):
        (tmp_path / "big.py").write_text("x" * (MAX_SINGLE_FILE_BYTES + 1))
        (tmp_path / "small.md").write_text("ok")

        files, _, oversized = _collect_files_safe(tmp_path)
        assert oversized
        titles = {f.title for f in files}
        assert "big.py" not in titles
        assert "small.md" in titles

    def test_oversized_file_does_not_stop_subdirectory_traversal(self, tmp_path):
        """A single >1 MB file should not prevent collecting files in subdirs."""
        (tmp_path / "SKILL.md").write_text("---\nname: s\n---\n# ok")
        (tmp_path / "big.py").write_text("x" * (MAX_SINGLE_FILE_BYTES + 1))

        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "helper.py").write_text("print('hi')")

        files, _, oversized = _collect_files_safe(tmp_path)
        assert oversized
        titles = {f.title for f in files}
        assert "big.py" not in titles
        assert "SKILL.md" in titles
        assert "sub/helper.py" in titles

    def test_total_budget_stops_across_subdirectories(self, tmp_path, monkeypatch):
        """After hitting MAX_SKILL_TOTAL_BYTES, files in subdirs must NOT be collected."""
        monkeypatch.setattr(skill_scanner, "MAX_SKILL_TOTAL_BYTES", 100)

        (tmp_path / "root.md").write_text("A" * 60)
        (tmp_path / "trigger.md").write_text("B" * 60)

        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "extra.md").write_text("C" * 10)

        files, _, oversized = _collect_files_safe(tmp_path)
        assert oversized
        titles = {f.title for f in files}
        assert "root.md" in titles
        assert "trigger.md" not in titles
        assert "sub/extra.md" not in titles


class TestScanSkillMdDir:
    def test_valid_skill(self, tmp_path):
        skill_dir = tmp_path / "my-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            "---\nname: my-skill\ndescription: A test skill\n---\n# Instructions"
        )
        (skill_dir / "helper.py").write_text("print('hello')")

        artifact = _scan_skill_md_dir(skill_dir, scope="global", tool="claude_code")
        assert artifact is not None
        assert artifact.name == "my-skill"
        assert artifact.description == "A test skill"
        assert artifact.artifact_type == ARTIFACT_SKILL_MD
        assert artifact.scope == "global"
        assert artifact.identifier is not None
        assert artifact.file_count == 2

    def test_missing_name_skipped(self, tmp_path):
        skill_dir = tmp_path / "bad-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("---\ndescription: no name\n---\n")

        assert _scan_skill_md_dir(skill_dir, scope="global", tool="multi") is None

    def test_has_scripts_detected(self, tmp_path):
        skill_dir = tmp_path / "scripted"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("---\nname: scripted\n---\n")
        scripts = skill_dir / "scripts"
        scripts.mkdir()
        (scripts / "run.sh").write_text("#!/bin/bash")

        artifact = _scan_skill_md_dir(skill_dir, scope="project", tool="multi")
        assert artifact is not None
        assert artifact.has_scripts is True


class TestScanSingleFileArtifact:
    def test_agents_md(self, tmp_path):
        f = tmp_path / "AGENTS.md"
        f.write_text("# Agent instructions")

        artifact = _scan_single_file_artifact(
            f, ARTIFACT_AGENTS_MD, "multi", scope="project", project_path=str(tmp_path)
        )
        assert artifact is not None
        assert artifact.artifact_type == ARTIFACT_AGENTS_MD
        assert artifact.file_count == 1
        assert artifact.identifier is not None

    def test_oversized_single_file(self, tmp_path):
        f = tmp_path / "CLAUDE.md"
        f.write_text("x" * (MAX_SINGLE_FILE_BYTES + 1))

        artifact = _scan_single_file_artifact(
            f, ARTIFACT_CLAUDE_MD, "claude_code", scope="project"
        )
        assert artifact is not None
        assert artifact.oversized is True
        assert artifact.file_count == 0
        assert artifact.identifier is not None


class TestScanRuleDirectory:
    def test_cursor_rules(self, tmp_path):
        rules_dir = tmp_path / ".cursor" / "rules"
        rules_dir.mkdir(parents=True)
        (rules_dir / "style.md").write_text("# Style rules")
        (rules_dir / "security.mdc").write_text("---\n---\nSecurity rules")
        (rules_dir / "readme.txt").write_text("not a rule")

        results = _scan_rule_directory(
            rules_dir, "cursor", ARTIFACT_CURSOR_RULE, scope="project"
        )
        assert len(results) == 2
        names = {r.name for r in results}
        assert "style.md" in names
        assert "security.mdc" in names

    def test_nonexistent_dir(self, tmp_path):
        results = _scan_rule_directory(
            tmp_path / "nope", "cursor", ARTIFACT_CURSOR_RULE, scope="global"
        )
        assert results == []


class TestInferProjectRoot:
    def test_skill_md_in_dot_tool_skills_dir(self):
        p = Path("/project/.cursor/skills/deploy/SKILL.md")
        assert _infer_project_root(p) == "/project"

    def test_skill_md_in_dot_agents_skills_dir(self):
        p = Path("/project/.agents/skills/deploy/SKILL.md")
        assert _infer_project_root(p) == "/project"

    def test_skill_md_in_plain_skills_dir(self):
        p = Path("/project/skills/deploy/SKILL.md")
        assert _infer_project_root(p) == "/project"

    def test_skill_md_without_skills_container(self):
        p = Path("/project/deploy-tool/SKILL.md")
        assert _infer_project_root(p) == "/project"

    def test_agents_md_at_project_root(self):
        p = Path("/project/AGENTS.md")
        assert _infer_project_root(p) == "/project"

    def test_copilot_in_github_dir(self):
        p = Path("/project/.github/copilot-instructions.md")
        assert _infer_project_root(p) == "/project"

    def test_cursor_rules_subdir(self):
        p = Path("/project/.cursor/rules/style.md")
        assert _infer_project_root(p) == "/project"


class TestProcessSkillPaths:
    def test_skill_md_discovered(self, tmp_path):
        skill_dir = tmp_path / "project" / ".agents" / "skills" / "deploy"
        skill_dir.mkdir(parents=True)
        marker = skill_dir / "SKILL.md"
        marker.write_text("---\nname: deploy\ndescription: Deploy helper\n---\n")

        results = process_skill_paths([marker])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_SKILL_MD
        assert results[0].name == "deploy"
        assert results[0].project_path == str(tmp_path / "project")

    def test_agents_md_discovered(self, tmp_path):
        f = tmp_path / "project" / "AGENTS.md"
        f.parent.mkdir(parents=True)
        f.write_text("# Agent rules")

        results = process_skill_paths([f])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_AGENTS_MD

    def test_claude_md_discovered(self, tmp_path):
        f = tmp_path / "project" / "CLAUDE.md"
        f.parent.mkdir(parents=True)
        f.write_text("# Claude rules")

        results = process_skill_paths([f])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_CLAUDE_MD
        assert results[0].tool == "claude_code"

    def test_gemini_md_discovered(self, tmp_path):
        f = tmp_path / "project" / "GEMINI.md"
        f.parent.mkdir(parents=True)
        f.write_text("# Gemini rules")

        results = process_skill_paths([f])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_GEMINI_MD

    def test_cursorrules_discovered(self, tmp_path):
        f = tmp_path / "project" / ".cursorrules"
        f.parent.mkdir(parents=True)
        f.write_text("# Legacy cursor rules")

        results = process_skill_paths([f])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_CURSOR_RULE

    def test_windsurfrules_discovered(self, tmp_path):
        f = tmp_path / "project" / ".windsurfrules"
        f.parent.mkdir(parents=True)
        f.write_text("# Windsurf rules")

        results = process_skill_paths([f])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_WINDSURF_RULE

    def test_copilot_instructions_discovered(self, tmp_path):
        gh_dir = tmp_path / "project" / ".github"
        gh_dir.mkdir(parents=True)
        f = gh_dir / "copilot-instructions.md"
        f.write_text("# Copilot instructions")

        results = process_skill_paths([f])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_COPILOT_INSTRUCTIONS

    def test_copilot_instructions_wrong_parent_skipped(self, tmp_path):
        f = tmp_path / "project" / "copilot-instructions.md"
        f.parent.mkdir(parents=True)
        f.write_text("# Not in .github")

        results = process_skill_paths([f])
        assert len(results) == 0

    def test_deduplicates_skill_dirs(self, tmp_path):
        skill_dir = tmp_path / "skill"
        skill_dir.mkdir()
        marker = skill_dir / "SKILL.md"
        marker.write_text("---\nname: dup\n---\n")

        results = process_skill_paths([marker, marker])
        assert len(results) == 1

    def test_unknown_filename_ignored(self, tmp_path):
        f = tmp_path / "random.txt"
        f.write_text("nope")
        assert process_skill_paths([f]) == []

    def test_cursor_rule_dir_discovered_via_marker(self, tmp_path):
        """Rule dirs are found by probing project roots inferred from marker files."""
        project = tmp_path / "project"
        project.mkdir()
        marker = project / "CLAUDE.md"
        marker.write_text("# Claude rules")

        rules_dir = project / ".cursor" / "rules"
        rules_dir.mkdir(parents=True)
        (rules_dir / "style.md").write_text("# Style")
        (rules_dir / "security.mdc").write_text("# Security")

        results = process_skill_paths([marker])
        claude = [r for r in results if r.artifact_type == ARTIFACT_CLAUDE_MD]
        cursor = [r for r in results if r.artifact_type == ARTIFACT_CURSOR_RULE]
        assert len(claude) == 1
        assert len(cursor) == 2

    def test_windsurf_rule_dir_discovered_via_marker(self, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        marker = project / "AGENTS.md"
        marker.write_text("# Agents")

        rules_dir = project / ".windsurf" / "rules"
        rules_dir.mkdir(parents=True)
        (rules_dir / "lint.md").write_text("# Lint")

        results = process_skill_paths([marker])
        windsurf = [r for r in results if r.artifact_type == ARTIFACT_WINDSURF_RULE]
        assert len(windsurf) == 1

    def test_clinerules_dir_discovered_via_marker(self, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        marker = project / ".cursorrules"
        marker.write_text("# Legacy")

        cline_dir = project / ".clinerules"
        cline_dir.mkdir()
        (cline_dir / "rule.md").write_text("# Cline rule")

        results = process_skill_paths([marker])
        cline = [r for r in results if r.artifact_type == ARTIFACT_CLINE_RULE]
        assert len(cline) == 1

    def test_no_rule_dir_when_absent(self, tmp_path):
        project = tmp_path / "project"
        project.mkdir()
        marker = project / "CLAUDE.md"
        marker.write_text("# Claude")

        results = process_skill_paths([marker])
        assert len(results) == 1
        assert results[0].artifact_type == ARTIFACT_CLAUDE_MD

    def test_no_duplicate_when_mapped_file_inside_rule_dir(self, tmp_path):
        """Files matching _FILENAME_ARTIFACT_MAP inside rule dirs must not be
        processed twice (once as their nominal type, once as a rule artifact)."""
        project = tmp_path / "project"
        rules_dir = project / ".cursor" / "rules"
        rules_dir.mkdir(parents=True)
        agents_in_rules = rules_dir / "AGENTS.md"
        agents_in_rules.write_text("# Agent instructions inside cursor rules")
        (rules_dir / "style.md").write_text("# Style guide")

        root_marker = project / ".cursorrules"
        root_marker.write_text("# legacy")

        results = process_skill_paths([agents_in_rules, root_marker])
        paths = [r.path for r in results]
        assert len(paths) == len(set(paths)), f"Duplicate paths: {paths}"

        agents_results = [
            r for r in results if str(agents_in_rules.resolve()) == r.path
        ]
        assert len(agents_results) == 1, (
            f"Expected exactly 1 entry for AGENTS.md in rules dir, got {len(agents_results)}"
        )
        assert agents_results[0].artifact_type == ARTIFACT_CURSOR_RULE


class TestScanGlobalSkills:
    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_discovers_skills_in_global_dirs(self, mock_home, tmp_path):
        mock_home.return_value = tmp_path

        skills_dir = tmp_path / ".claude" / "skills" / "my-skill"
        skills_dir.mkdir(parents=True)
        (skills_dir / "SKILL.md").write_text(
            "---\nname: my-skill\ndescription: test\n---\n"
        )

        results = scan_global_skills()
        assert len(results) >= 1
        assert any(r.name == "my-skill" for r in results)
        assert all(r.scope == "global" for r in results)

    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_discovers_global_cursor_rules(self, mock_home, tmp_path):
        mock_home.return_value = tmp_path

        rules_dir = tmp_path / ".config" / "cursor" / "rules"
        rules_dir.mkdir(parents=True)
        (rules_dir / "style.md").write_text("# Style")

        results = scan_global_skills()
        cursor_rules = [r for r in results if r.artifact_type == ARTIFACT_CURSOR_RULE]
        assert len(cursor_rules) == 1

    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_empty_home(self, mock_home, tmp_path):
        mock_home.return_value = tmp_path
        assert scan_global_skills() == []


class TestSubmitDiscoveredSkills:
    def test_calls_fingerprint_then_submit(self):
        client = mock.MagicMock()
        client.submit_skill_fingerprint.return_value = {"known": False}

        skill = DiscoveredSkillArtifact(
            name="test",
            path="/test",
            artifact_type=ARTIFACT_SKILL_MD,
            scope="project",
            tool="multi",
            identifier="abc123",
            files=[SkillFile(title="SKILL.md", content="# test")],
        )

        submit_discovered_skills(client, [skill])
        client.submit_skill_fingerprint.assert_called_once_with(
            "abc123", ARTIFACT_SKILL_MD, oversized=False
        )
        client.submit_skill.assert_called_once()

    def test_skips_upload_when_known(self):
        client = mock.MagicMock()
        client.submit_skill_fingerprint.return_value = {"known": True}

        skill = DiscoveredSkillArtifact(
            name="known",
            path="/known",
            artifact_type=ARTIFACT_SKILL_MD,
            scope="project",
            tool="multi",
            identifier="abc123",
        )

        submit_discovered_skills(client, [skill])
        client.submit_skill.assert_not_called()

    def test_skips_upload_when_oversized(self, tmp_path):
        f = tmp_path / "CLAUDE.md"
        f.write_text("x" * (MAX_SINGLE_FILE_BYTES + 1))

        skill = _scan_single_file_artifact(
            f, ARTIFACT_CLAUDE_MD, "claude_code", scope="project"
        )
        assert skill is not None
        assert skill.oversized is True
        assert skill.identifier is not None

        client = mock.MagicMock()
        client.submit_skill_fingerprint.return_value = {"known": False}

        submit_discovered_skills(client, [skill])
        client.submit_skill_fingerprint.assert_called_once_with(
            skill.identifier, ARTIFACT_CLAUDE_MD, oversized=True
        )
        client.submit_skill.assert_not_called()

    def test_skips_skill_without_identifier(self):
        client = mock.MagicMock()

        skill = DiscoveredSkillArtifact(
            name="no-id",
            path="/no-id",
            artifact_type=ARTIFACT_AGENTS_MD,
            scope="project",
            tool="multi",
            identifier=None,
        )

        submit_discovered_skills(client, [skill])
        client.submit_skill_fingerprint.assert_not_called()

    def test_handles_not_implemented_gracefully(self):
        client = mock.MagicMock()
        client.submit_skill_fingerprint.side_effect = NotImplementedError("stub")

        skill = DiscoveredSkillArtifact(
            name="stub",
            path="/stub",
            artifact_type=ARTIFACT_SKILL_MD,
            scope="project",
            tool="multi",
            identifier="abc123",
        )

        submit_discovered_skills(client, [skill])

    def test_handles_api_error_gracefully(self):
        client = mock.MagicMock()
        client.submit_skill_fingerprint.side_effect = RuntimeError("network")

        skill = DiscoveredSkillArtifact(
            name="err",
            path="/err",
            artifact_type=ARTIFACT_SKILL_MD,
            scope="project",
            tool="multi",
            identifier="abc123",
        )

        submit_discovered_skills(client, [skill])


class TestGlobalSkillDeduplication:
    """Global skills must not appear as both 'project' and 'global' scope."""

    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_process_skill_paths_excludes_global_skill_dirs(self, mock_home, tmp_path):
        mock_home.return_value = tmp_path

        skill_dir = tmp_path / ".claude" / "skills" / "my-skill"
        skill_dir.mkdir(parents=True)
        marker = skill_dir / "SKILL.md"
        marker.write_text("---\nname: my-skill\n---\n# Instructions")

        results = process_skill_paths([marker])
        assert len(results) == 0, (
            "SKILL.md under a global skill dir should be excluded from project results"
        )

    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_process_skill_paths_excludes_global_rule_dirs(self, mock_home, tmp_path):
        mock_home.return_value = tmp_path

        rules_dir = tmp_path / ".config" / "cursor" / "rules"
        rules_dir.mkdir(parents=True)
        rule_file = rules_dir / "AGENTS.md"
        rule_file.write_text("# Global cursor agent rules")

        results = process_skill_paths([rule_file])
        assert len(results) == 0, (
            "Files under a global rule dir should be excluded from project results"
        )

    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_project_skill_not_excluded(self, mock_home, tmp_path):
        mock_home.return_value = tmp_path

        skill_dir = tmp_path / "projects" / "my-app" / ".cursor" / "skills" / "deploy"
        skill_dir.mkdir(parents=True)
        marker = skill_dir / "SKILL.md"
        marker.write_text("---\nname: deploy\n---\n# Deploy")

        results = process_skill_paths([marker])
        assert len(results) == 1
        assert results[0].scope == "project"

    @mock.patch("runlayer_cli.scan.skill_scanner.Path.home")
    def test_no_duplicates_between_phases(self, mock_home, tmp_path):
        """Simulate Phase 2 + Phase 6 and verify no duplicates."""
        mock_home.return_value = tmp_path

        skill_dir = tmp_path / ".claude" / "skills" / "my-skill"
        skill_dir.mkdir(parents=True)
        marker = skill_dir / "SKILL.md"
        marker.write_text("---\nname: my-skill\n---\n# test")

        project_skills = process_skill_paths([marker])
        global_skills = scan_global_skills()

        all_skills = project_skills + global_skills
        paths = [s.path for s in all_skills]
        assert len(paths) == len(set(paths)), f"Duplicate skill paths found: {paths}"


class TestDiscoveredSkillArtifactPayload:
    def test_to_api_payload(self):
        artifact = DiscoveredSkillArtifact(
            name="test-skill",
            path="/path/to/skill",
            artifact_type=ARTIFACT_SKILL_MD,
            scope="project",
            tool="claude_code",
            project_path="/path/to",
            identifier="hash123",
            description="Test",
            has_scripts=True,
            file_count=2,
            files=[
                SkillFile(title="SKILL.md", content="# Skill"),
                SkillFile(title="scripts/run.sh", content="#!/bin/bash"),
            ],
            oversized=False,
            symlinks_found=["/path/to/link"],
            git_remote_url="https://github.com/org/repo.git",
            is_dependency=False,
            source_type="user",
        )

        payload = artifact.to_api_payload()
        assert payload["identifier"] == "hash123"
        assert payload["name"] == "test-skill"
        assert payload["artifact_type"] == ARTIFACT_SKILL_MD
        assert payload["has_scripts"] is True
        assert payload["oversized"] is False
        assert payload["git_remote_url"] == "https://github.com/org/repo.git"
        assert payload["source_type"] == "user"
        assert len(payload["files"]) == 2
        assert payload["symlinks_found"] == ["/path/to/link"]
