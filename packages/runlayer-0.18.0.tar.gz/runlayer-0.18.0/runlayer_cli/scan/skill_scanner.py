"""Discover skill-like artifacts (SKILL.md, AGENTS.md, rule files, etc.) on a device."""

from __future__ import annotations

import functools
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any

import structlog

from runlayer_cli.skill_identifier import SkillFileInput, compute_skill_identifier
from runlayer_cli.skills.discovery import _parse_frontmatter

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_SINGLE_FILE_BYTES = 1_048_576  # 1 MB
MAX_SKILL_TOTAL_BYTES = 5_242_880  # 5 MB

SUPPORTED_EXTENSIONS = {".md", ".mdc", ".txt", ".sh", ".py", ".js", ".ts"}

DEPENDENCY_DIRS = {"node_modules", ".venv", "venv", "vendor", "dist", ".tox"}

ARTIFACT_SKILL_MD = "skill_md"
ARTIFACT_AGENTS_MD = "agents_md"
ARTIFACT_CLAUDE_MD = "claude_md"
ARTIFACT_GEMINI_MD = "gemini_md"
ARTIFACT_CURSOR_RULE = "cursor_rule"
ARTIFACT_WINDSURF_RULE = "windsurf_rule"
ARTIFACT_COPILOT_INSTRUCTIONS = "copilot_instructions"
ARTIFACT_CLINE_RULE = "cline_rule"

# Filenames the unified `find` crawl should look for (project-level).
SKILL_SEARCH_FILENAMES: list[str] = [
    "SKILL.md",
    "AGENTS.md",
    "CLAUDE.md",
    "GEMINI.md",
    ".cursorrules",
    ".windsurfrules",
    "copilot-instructions.md",
]

# Mapping from filename -> (artifact_type, tool).
# For files that can appear in multiple tool contexts, ``tool`` is the
# primary association; the caller may refine based on parent directory.
_FILENAME_ARTIFACT_MAP: dict[str, tuple[str, str]] = {
    "SKILL.md": (ARTIFACT_SKILL_MD, "multi"),
    "AGENTS.md": (ARTIFACT_AGENTS_MD, "multi"),
    "CLAUDE.md": (ARTIFACT_CLAUDE_MD, "claude_code"),
    "GEMINI.md": (ARTIFACT_GEMINI_MD, "gemini_cli"),
    ".cursorrules": (ARTIFACT_CURSOR_RULE, "cursor"),
    ".windsurfrules": (ARTIFACT_WINDSURF_RULE, "windsurf"),
    "copilot-instructions.md": (ARTIFACT_COPILOT_INSTRUCTIONS, "copilot"),
}

# Global (home-directory) skill paths: (relative_to_home, tool)
_GLOBAL_SKILL_DIRS: list[tuple[str, str]] = [
    (".claude/skills", "claude_code"),
    (".agents/skills", "multi"),
    (".codex/skills", "codex"),
    (".agent/skills", "multi"),
    (".skillport/skills", "skillport"),
]

_GLOBAL_RULE_DIRS: list[tuple[str, str, str]] = [
    (".config/cursor/rules", "cursor", ARTIFACT_CURSOR_RULE),
]

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SkillFile:
    """A single file within a skill artifact, with cached content."""

    title: str
    content: str


@dataclass
class DiscoveredSkillArtifact:
    """A skill-like artifact found on disk."""

    name: str
    path: str
    artifact_type: str
    scope: str  # "global" | "project"
    tool: str
    project_path: str | None = None
    identifier: str | None = None
    description: str | None = None
    has_scripts: bool = False
    file_count: int = 0
    files: list[SkillFile] = field(default_factory=list)
    oversized: bool = False
    symlinks_found: list[str] = field(default_factory=list)
    git_remote_url: str | None = None
    is_dependency: bool = False
    source_type: str = "user"

    def to_api_payload(self) -> dict[str, Any]:
        return {
            "identifier": self.identifier,
            "name": self.name,
            "path": self.path,
            "artifact_type": self.artifact_type,
            "scope": self.scope,
            "tool": self.tool,
            "project_path": self.project_path,
            "description": self.description,
            "has_scripts": self.has_scripts,
            "file_count": self.file_count,
            "oversized": self.oversized,
            "symlinks_found": self.symlinks_found,
            "git_remote_url": self.git_remote_url,
            "is_dependency": self.is_dependency,
            "source_type": self.source_type,
            "files": [{"title": f.title, "content": f.content} for f in self.files],
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_dependency_path(path: Path) -> bool:
    parts = set(path.parts)
    return bool(parts & DEPENDENCY_DIRS)


def _classify_source_type(path: Path, scope: str) -> str:
    if _is_dependency_path(path):
        return "dependency"
    if scope == "global":
        return "installed"
    return "user"


@functools.lru_cache(maxsize=512)
def _git_remote_for_dir(dir_path_str: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", dir_path_str, "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


def _get_git_remote(path: Path) -> str | None:
    """Return the ``origin`` remote URL for the repo containing *path*."""
    dir_path = path if path.is_dir() else path.parent
    return _git_remote_for_dir(str(dir_path))


def _collect_files_safe(
    skill_dir: Path,
) -> tuple[list[SkillFile], list[str], bool]:
    """Collect files from a skill directory with safety checks.

    Returns:
        (files, symlinks_found, oversized)
    """
    files: list[SkillFile] = []
    symlinks: list[str] = []
    oversized = False
    budget_exceeded = False
    total_bytes = 0
    resolved_root = skill_dir.resolve()

    for dirpath, dirnames, filenames in os.walk(skill_dir):
        dirnames.sort()
        dp = Path(dirpath)
        for fname in sorted(filenames):
            fpath = dp / fname
            if fpath.suffix not in SUPPORTED_EXTENSIONS:
                continue

            if fpath.is_symlink():
                try:
                    target = fpath.resolve()
                except OSError:
                    symlinks.append(str(fpath))
                    continue
                if not target.is_relative_to(resolved_root):
                    symlinks.append(str(fpath))
                    logger.warning(
                        "skipping_external_symlink",
                        path=str(fpath),
                        target=str(target),
                    )
                    continue

            try:
                size = fpath.stat().st_size
            except OSError:
                continue

            if size > MAX_SINGLE_FILE_BYTES:
                logger.warning(
                    "skipping_oversized_file",
                    path=str(fpath),
                    size=size,
                )
                oversized = True
                continue

            if total_bytes + size > MAX_SKILL_TOTAL_BYTES:
                oversized = True
                budget_exceeded = True
                logger.warning(
                    "skill_total_size_exceeded",
                    dir=str(skill_dir),
                    accumulated=total_bytes,
                )
                break

            try:
                content = fpath.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue

            total_bytes += size
            rel = fpath.relative_to(skill_dir)
            title = PurePosixPath(rel).as_posix()
            files.append(SkillFile(title=title, content=content))

        if budget_exceeded:
            break

    return files, symlinks, oversized


def _compute_identifier(files: list[SkillFile]) -> str | None:
    if not files:
        return None
    try:
        inputs = [SkillFileInput(name=f.title, content=f.content) for f in files]
        result = compute_skill_identifier(inputs)
        return result.root
    except Exception:
        logger.warning("skill_identifier_failed", exc_info=True)
        return None


# ---------------------------------------------------------------------------
# SKILL.md directory scanner
# ---------------------------------------------------------------------------


def _scan_skill_md_dir(
    skill_dir: Path,
    scope: str,
    tool: str,
    project_path: str | None = None,
) -> DiscoveredSkillArtifact | None:
    """Build a ``DiscoveredSkillArtifact`` from a directory containing SKILL.md."""
    marker = skill_dir / "SKILL.md"
    try:
        marker_content = marker.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return None

    fm = _parse_frontmatter(marker_content)
    name = fm.get("name")
    if not name:
        logger.warning("skill_missing_name", path=str(marker))
        return None
    name = str(name)[:100]
    description = fm.get("description")
    if description is not None:
        description = str(description)[:1024]

    has_scripts = (skill_dir / "scripts").is_dir()
    files, symlinks, oversized = _collect_files_safe(skill_dir)
    identifier = _compute_identifier(files)
    abs_path = Path(skill_dir).resolve()

    return DiscoveredSkillArtifact(
        name=name,
        path=str(abs_path),
        artifact_type=ARTIFACT_SKILL_MD,
        scope=scope,
        tool=tool,
        project_path=project_path,
        identifier=identifier,
        description=description,
        has_scripts=has_scripts,
        file_count=len(files),
        files=files,
        oversized=oversized,
        symlinks_found=symlinks,
        git_remote_url=_get_git_remote(abs_path),
        is_dependency=_is_dependency_path(abs_path),
        source_type=_classify_source_type(abs_path, scope),
    )


# ---------------------------------------------------------------------------
# Single-file artifact scanner (AGENTS.md, CLAUDE.md, rules, etc.)
# ---------------------------------------------------------------------------


def _scan_single_file_artifact(
    fpath: Path,
    artifact_type: str,
    tool: str,
    scope: str,
    project_path: str | None = None,
) -> DiscoveredSkillArtifact | None:
    """Build an artifact from a single rule/instruction file."""
    try:
        size = fpath.stat().st_size
    except OSError:
        return None

    oversized = size > MAX_SINGLE_FILE_BYTES
    if oversized:
        logger.warning("skipping_oversized_file", path=str(fpath), size=size)
        files: list[SkillFile] = []
        placeholder = [SkillFileInput(name=fpath.name, content=f"__oversized__:{size}")]
        try:
            identifier = compute_skill_identifier(placeholder).root
        except Exception:
            logger.warning("skill_identifier_failed", exc_info=True)
            identifier = None
    else:
        try:
            content = fpath.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            return None
        files = [SkillFile(title=fpath.name, content=content)]
        identifier = _compute_identifier(files)

    abs_path = fpath.resolve()

    return DiscoveredSkillArtifact(
        name=fpath.name,
        path=str(abs_path),
        artifact_type=artifact_type,
        scope=scope,
        tool=tool,
        project_path=project_path,
        identifier=identifier,
        description=None,
        has_scripts=False,
        file_count=len(files),
        files=files,
        oversized=oversized,
        git_remote_url=_get_git_remote(abs_path),
        is_dependency=_is_dependency_path(abs_path),
        source_type=_classify_source_type(abs_path, scope),
    )


# ---------------------------------------------------------------------------
# Rule-directory scanner (.cursor/rules/, .windsurf/rules/, .clinerules/)
# ---------------------------------------------------------------------------


def _scan_rule_directory(
    rule_dir: Path,
    tool: str,
    artifact_type: str,
    scope: str,
    project_path: str | None = None,
) -> list[DiscoveredSkillArtifact]:
    """Scan a directory of rule files and return one artifact per file."""
    if not rule_dir.is_dir():
        return []
    results: list[DiscoveredSkillArtifact] = []
    try:
        entries = sorted(rule_dir.iterdir())
    except OSError:
        return []
    for entry in entries:
        if not entry.is_file():
            continue
        if entry.suffix not in {".md", ".mdc"}:
            continue
        artifact = _scan_single_file_artifact(
            entry, artifact_type, tool, scope, project_path
        )
        if artifact:
            results.append(artifact)
    return results


# ---------------------------------------------------------------------------
# Global (home-directory) skill scanning
# ---------------------------------------------------------------------------


def scan_global_skills() -> list[DiscoveredSkillArtifact]:
    """Walk known home-directory skill paths and return discovered artifacts."""
    _git_remote_for_dir.cache_clear()
    home = Path.home()
    results: list[DiscoveredSkillArtifact] = []

    for rel_dir, tool in _GLOBAL_SKILL_DIRS:
        skills_root = home / rel_dir
        if not skills_root.is_dir():
            continue
        try:
            subdirs = sorted(skills_root.iterdir())
        except OSError:
            continue
        for subdir in subdirs:
            if not subdir.is_dir():
                continue
            if not (subdir / "SKILL.md").exists():
                continue
            artifact = _scan_skill_md_dir(subdir, scope="global", tool=tool)
            if artifact:
                results.append(artifact)

    for rel_dir, tool, artifact_type in _GLOBAL_RULE_DIRS:
        rule_dir = home / rel_dir
        results.extend(
            _scan_rule_directory(rule_dir, tool, artifact_type, scope="global")
        )

    logger.info("Global skill scan complete", found=len(results))
    return results


# ---------------------------------------------------------------------------
# Project-level skill scanning (from pre-crawled paths)
# ---------------------------------------------------------------------------


def _infer_project_root(fpath: Path) -> str:
    """Best-effort project root from a discovered file path."""
    name = fpath.name
    parent_name = fpath.parent.name

    if parent_name in (".github", ".cursor", ".windsurf", ".clinerules"):
        return str(fpath.parent.parent)
    if parent_name == "rules" and fpath.parent.parent.name in (
        ".cursor",
        ".windsurf",
    ):
        return str(fpath.parent.parent.parent)
    if name == "SKILL.md":
        skill_dir = fpath.parent
        container = skill_dir.parent
        if container.name == "skills":
            tool_dir = container.parent
            if tool_dir.name.startswith("."):
                return str(tool_dir.parent)
            return str(tool_dir)
        return str(skill_dir.parent)
    if name in (
        "AGENTS.md",
        "CLAUDE.md",
        "GEMINI.md",
        ".cursorrules",
        ".windsurfrules",
    ):
        return str(fpath.parent)
    return str(fpath.parent)


_RULE_DIR_PATTERNS: list[tuple[str, str | None]] = [
    ("rules", ".cursor"),
    ("rules", ".windsurf"),
    (".clinerules", None),
]


def _is_inside_rule_dir(fpath: Path) -> bool:
    """True when *fpath* lives inside a directory that ``_scan_inferred_rule_dirs`` owns."""
    parent = fpath.parent
    for dir_name, grandparent_name in _RULE_DIR_PATTERNS:
        if parent.name == dir_name:
            if grandparent_name is None or parent.parent.name == grandparent_name:
                return True
    return False


def _is_under_global_prefix(fpath: Path, prefixes: set[Path]) -> bool:
    resolved = fpath.resolve()
    return any(resolved == p or resolved.is_relative_to(p) for p in prefixes)


def process_skill_paths(found_paths: list[Path]) -> list[DiscoveredSkillArtifact]:
    """Process pre-crawled paths and return project-level skill artifacts.

    This handles:
    - SKILL.md found via ``find`` -> scan the parent directory as a skill
    - Single-file artifacts (AGENTS.md, CLAUDE.md, .cursorrules, etc.)
    - Discovered .cursor/rules/, .windsurf/rules/, .clinerules/ directories
      (triggered when a known marker file is found inside them)

    Paths under known global skill/rule directories are excluded; those are
    handled separately by ``scan_global_skills``.
    """
    _git_remote_for_dir.cache_clear()
    results: list[DiscoveredSkillArtifact] = []
    seen_skill_dirs: set[str] = set()
    seen_rule_dirs: set[str] = set()
    global_prefixes = _get_global_skill_path_prefixes()

    for fpath in found_paths:
        name = fpath.name
        if name not in _FILENAME_ARTIFACT_MAP:
            continue

        if _is_under_global_prefix(fpath, global_prefixes):
            continue

        if _is_inside_rule_dir(fpath):
            continue

        artifact_type, tool = _FILENAME_ARTIFACT_MAP[name]
        project_root = _infer_project_root(fpath)

        if artifact_type == ARTIFACT_SKILL_MD:
            skill_dir = fpath.parent
            dir_key = str(skill_dir.resolve())
            if dir_key in seen_skill_dirs:
                continue
            seen_skill_dirs.add(dir_key)
            artifact = _scan_skill_md_dir(
                skill_dir,
                scope="project",
                tool=tool,
                project_path=project_root,
            )
            if artifact:
                results.append(artifact)
            continue

        if artifact_type == ARTIFACT_COPILOT_INSTRUCTIONS:
            if fpath.parent.name != ".github":
                continue

        artifact = _scan_single_file_artifact(
            fpath, artifact_type, tool, scope="project", project_path=project_root
        )
        if artifact:
            results.append(artifact)

    _scan_inferred_rule_dirs(found_paths, results, seen_rule_dirs, global_prefixes)

    logger.info("Project skill scan complete", found=len(results))
    return results


def _scan_inferred_rule_dirs(
    found_paths: list[Path],
    results: list[DiscoveredSkillArtifact],
    seen: set[str],
    global_prefixes: set[Path] | None = None,
) -> None:
    """Probe rule directories at project roots inferred from discovered paths.

    The unified ``find`` crawl only searches for exact filenames (AGENTS.md,
    CLAUDE.md, .cursorrules, etc.).  Rule files inside ``.cursor/rules/`` have
    arbitrary names so they are never returned by ``find``.  Instead we infer
    project roots from the marker files we *did* find, then check whether rule
    directories exist at those roots.
    """
    rule_dir_configs: list[tuple[str, str, str]] = [
        (".cursor/rules", "cursor", ARTIFACT_CURSOR_RULE),
        (".windsurf/rules", "windsurf", ARTIFACT_WINDSURF_RULE),
        (".clinerules", "cline", ARTIFACT_CLINE_RULE),
    ]

    project_roots: set[str] = set()
    for fpath in found_paths:
        if fpath.name not in _FILENAME_ARTIFACT_MAP:
            continue
        if global_prefixes and _is_under_global_prefix(fpath, global_prefixes):
            continue
        artifact_type, _ = _FILENAME_ARTIFACT_MAP[fpath.name]
        if (
            artifact_type == ARTIFACT_COPILOT_INSTRUCTIONS
            and fpath.parent.name != ".github"
        ):
            continue
        project_roots.add(_infer_project_root(fpath))

    for root in sorted(project_roots):
        for rel_dir, tool, artifact_type in rule_dir_configs:
            rule_dir = Path(root) / rel_dir
            if not rule_dir.is_dir():
                continue
            dir_key = str(rule_dir.resolve())
            if dir_key in seen:
                continue
            seen.add(dir_key)
            results.extend(
                _scan_rule_directory(
                    rule_dir,
                    tool,
                    artifact_type,
                    scope="project",
                    project_path=root,
                )
            )


def _get_global_skill_path_prefixes() -> set[Path]:
    """Resolved paths that ``scan_global_skills`` owns.

    Any file under these prefixes should be excluded from
    ``process_skill_paths`` to avoid double-counting.
    """
    home = Path.home()
    prefixes: set[Path] = set()
    for rel_dir, _ in _GLOBAL_SKILL_DIRS:
        prefixes.add((home / rel_dir).resolve())
    for rel_dir, _, _ in _GLOBAL_RULE_DIRS:
        prefixes.add((home / rel_dir).resolve())
    return prefixes


def get_skill_search_filenames() -> list[str]:
    """Return the list of filenames the unified find crawl should include."""
    return list(SKILL_SEARCH_FILENAMES)
