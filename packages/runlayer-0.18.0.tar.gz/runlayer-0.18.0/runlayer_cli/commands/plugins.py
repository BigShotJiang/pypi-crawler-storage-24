from pathlib import Path

import anyio
import structlog
import typer

from runlayer_cli.api import RunlayerClient
from runlayer_cli.console import print_error
from runlayer_cli.config import resolve_credentials, set_credentials_in_context
from runlayer_cli.logging import setup_logging
from runlayer_cli.plugins.discovery import discover_plugins
from runlayer_cli.plugins.sync_engine import (
    PluginSyncResult,
    sync_discovered_plugins,
)

logger = structlog.get_logger(__name__)

app = typer.Typer(help="Manage plugins")


@app.command()
def push(
    ctx: typer.Context,
    path: str = typer.Argument(".", help="Root directory"),
    namespace: str = typer.Option(
        ..., "--namespace", "-N", help="Namespace for matching plugins on the server"
    ),
    public: bool = typer.Option(False, "--public"),
    dynamic_tools: bool = typer.Option(False, "--dynamic-tools"),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    prune: bool = typer.Option(False, "--prune"),
) -> None:
    """Push plugins to Runlayer API."""
    root = Path(path).resolve()
    log_file_path = setup_logging(command="plugins-push", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=True)

    try:
        client = RunlayerClient(
            hostname=credentials["host"], secret=credentials["secret"]
        )

        discovered = discover_plugins(root)
        n_plugins = len(discovered)
        n_skills = sum(len(p.skills) for p in discovered)
        typer.echo(f"Found {n_plugins} plugins, {n_skills} skills")

        pushing_printed = False

        def _ensure_pushing_header() -> None:
            nonlocal pushing_printed
            if not pushing_printed:
                typer.echo("\nPushing...")
                pushing_printed = True

        def on_skill_progress(skill_path: str, status: str) -> None:
            if status not in ("unchanged",):
                _ensure_pushing_header()
                typer.echo(f"  {skill_path}: {status}")

        def on_plugin_progress(plugin_path: str, status: str) -> None:
            if status not in ("unchanged",):
                _ensure_pushing_header()
                typer.echo(f"  {plugin_path}: {status}")

        async def _run() -> PluginSyncResult:
            return await sync_discovered_plugins(
                discovered,
                client,
                namespace=namespace,
                is_public=public,
                use_dynamic_tools=dynamic_tools,
                dry_run=dry_run,
                prune=prune,
                on_skill_progress=on_skill_progress,
                on_plugin_progress=on_plugin_progress,
            )

        result = anyio.run(_run)
        sr = result.skill_result

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        # Build summary parts: skills first, then plugins (only if any changed)
        parts: list[str] = []
        if sr.created:
            parts.append(f"{sr.created} skills created")
        if sr.updated:
            parts.append(f"{sr.updated} skills updated")
        if sr.deleted:
            parts.append(f"{sr.deleted} skills deleted")

        if result.created:
            parts.append(f"{result.created} plugins created")
        if result.updated:
            parts.append(f"{result.updated} plugins updated")
        if result.deleted:
            parts.append(f"{result.deleted} plugins deleted")

        if parts:
            unchanged = sr.unchanged + result.unchanged
            summary = ", ".join(parts)
            if unchanged:
                typer.echo(f"Done, {summary} ({unchanged} unchanged)")
            else:
                typer.echo(f"Done, {summary}")
        else:
            typer.echo("Done, everything up to date")

        for warning in result.warnings:
            typer.secho(f"  Warning: {warning}", fg=typer.colors.YELLOW, err=True)
        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.error("plugins_push_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)
