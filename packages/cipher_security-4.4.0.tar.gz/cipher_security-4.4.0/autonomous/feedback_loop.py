# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""Leaderboard → Researcher Feedback Loop.

Connects skill performance metrics to autonomous improvement:
- Identifies bottom-performing skills from leaderboard
- Triggers skill regeneration via AutonomousResearcher
- Tracks improvement cycles and validates quality gains
- Provides continuous skill quality improvement pipeline

Inspired by reinforcement learning feedback patterns studied
in open-source projects. Architecture and implementation are
original CIPHER designs.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


class ImprovementStatus(Enum):
    """Status of a skill improvement cycle."""

    IDENTIFIED = "identified"
    ANALYZING = "analyzing"
    REGENERATING = "regenerating"
    VALIDATING = "validating"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ImprovementCandidate:
    """A skill identified for improvement."""

    skill_path: str
    domain: str
    current_score: float
    invocations: int
    trend: str
    issues: list[str] = field(default_factory=list)
    status: ImprovementStatus = ImprovementStatus.IDENTIFIED
    improvement_score: float = 0.0
    cycle_id: str = ""
    started_at: float = 0.0
    completed_at: float = 0.0


@dataclass
class ImprovementCycle:
    """Tracks a full improvement cycle."""

    cycle_id: str
    started_at: float
    candidates: list[ImprovementCandidate] = field(default_factory=list)
    completed_at: float = 0.0
    skills_improved: int = 0
    skills_failed: int = 0
    skills_skipped: int = 0
    avg_score_before: float = 0.0
    avg_score_after: float = 0.0


class SkillQualityAnalyzer:
    """Analyzes skill quality to identify improvement opportunities."""

    # Minimum thresholds for quality
    MIN_SKILL_MD_LINES = 20
    MIN_AGENT_PY_LINES = 15
    MIN_CODE_BLOCKS = 1
    REQUIRED_SECTIONS = {"overview", "techniques", "best practices", "references"}

    def __init__(self, skills_dir: Path | str = "skills") -> None:
        self.skills_dir = Path(skills_dir)

    def analyze_skill(self, skill_path: str) -> dict:
        """Analyze a skill's quality and return findings."""
        full_path = (
            self.skills_dir.parent / skill_path
            if not Path(skill_path).is_absolute()
            else Path(skill_path)
        )
        if not full_path.exists():
            full_path = (
                self.skills_dir / skill_path.replace("skills/", "", 1)
                if skill_path.startswith("skills/")
                else self.skills_dir / skill_path
            )

        issues: list[str] = []
        scores: dict[str, float] = {}

        # Check SKILL.md
        skill_md = full_path / "SKILL.md"
        if skill_md.exists():
            content = skill_md.read_text()
            lines = content.strip().splitlines()

            # Line count check
            if len(lines) < self.MIN_SKILL_MD_LINES:
                issues.append(
                    f"SKILL.md too short ({len(lines)} lines, min {self.MIN_SKILL_MD_LINES})"
                )
            scores["content_length"] = min(len(lines) / 50.0, 1.0)

            # Section coverage
            lower = content.lower()
            found_sections = {
                s
                for s in self.REQUIRED_SECTIONS
                if f"## {s}" in lower or f"# {s}" in lower
            }
            missing = self.REQUIRED_SECTIONS - found_sections
            if missing:
                issues.append(f"Missing sections: {', '.join(sorted(missing))}")
            scores["section_coverage"] = len(found_sections) / len(
                self.REQUIRED_SECTIONS
            )

            # Code blocks
            code_blocks = content.count("```")
            if code_blocks < self.MIN_CODE_BLOCKS * 2:  # Opening + closing
                issues.append("No code blocks found")
            scores["code_examples"] = min(code_blocks / 6.0, 1.0)

            # Copyright header
            if "Copyright" not in content[:200]:
                issues.append("Missing copyright header")

            # YAML frontmatter
            if "---" not in content[:10]:
                issues.append("Missing YAML frontmatter")
            scores["frontmatter"] = 1.0 if "---" in content[:10] else 0.0
        else:
            issues.append("SKILL.md missing")
            scores["content_length"] = 0.0
            scores["section_coverage"] = 0.0

        # Check agent.py
        agent_py = full_path / "scripts" / "agent.py"
        if agent_py.exists():
            agent_content = agent_py.read_text()
            agent_lines = agent_content.strip().splitlines()
            if len(agent_lines) < self.MIN_AGENT_PY_LINES:
                issues.append(f"agent.py too short ({len(agent_lines)} lines)")
            scores["agent_quality"] = min(len(agent_lines) / 50.0, 1.0)

            if "argparse" not in agent_content:
                issues.append("agent.py missing argparse")
            if "json" not in agent_content:
                issues.append("agent.py missing JSON output")
            if "__main__" not in agent_content:
                issues.append("agent.py missing __main__ guard")
        else:
            issues.append("scripts/agent.py missing")
            scores["agent_quality"] = 0.0

        # Check reference
        ref_dir = full_path / "references"
        if ref_dir.exists() and any(ref_dir.glob("*.md")):
            scores["references"] = 1.0
        else:
            issues.append("No reference documentation")
            scores["references"] = 0.0

        overall = sum(scores.values()) / max(len(scores), 1)
        return {
            "path": str(full_path),
            "issues": issues,
            "scores": scores,
            "overall_quality": round(overall, 3),
            "needs_improvement": len(issues) > 2 or overall < 0.6,
        }


class FeedbackLoop:
    """Connects leaderboard metrics to skill improvement.

    Flow:
    1. Query leaderboard for bottom-performing skills
    2. Run quality analysis on each candidate
    3. Prioritize by impact (low score + high usage = highest priority)
    4. Trigger regeneration for top N candidates
    5. Validate improvements
    6. Record results back to leaderboard
    """

    DEFAULT_BATCH_SIZE = 10
    MIN_INVOCATIONS_FOR_FEEDBACK = 1  # Skills need at least 1 invocation
    SCORE_THRESHOLD = 0.5  # Below this triggers improvement

    def __init__(
        self,
        skills_dir: Path | str = "skills",
        max_improvements_per_cycle: int = 10,
    ) -> None:
        self.skills_dir = Path(skills_dir)
        self.max_per_cycle = max_improvements_per_cycle
        self.analyzer = SkillQualityAnalyzer(self.skills_dir)
        self._history: list[ImprovementCycle] = []

    def identify_candidates(
        self,
        bottom_skills: list[dict] | None = None,
        score_threshold: float | None = None,
    ) -> list[ImprovementCandidate]:
        """Identify skills that need improvement.

        Args:
            bottom_skills: Pre-fetched bottom skills from leaderboard.
                Each dict needs: skill_path, score, invocations, trend
            score_threshold: Override default score threshold.
        """
        threshold = score_threshold or self.SCORE_THRESHOLD
        candidates: list[ImprovementCandidate] = []

        if bottom_skills is None:
            # If no leaderboard data, do quality-only analysis
            return self._identify_by_quality()

        for skill in bottom_skills:
            path = skill.get("skill_path", skill.get("path", ""))
            score = skill.get("score", 0.0)
            invocations = skill.get("invocations", 0)
            trend = skill.get("trend", "stable")

            if score >= threshold and trend != "declining":
                continue

            # Run quality analysis
            analysis = self.analyzer.analyze_skill(path)

            candidate = ImprovementCandidate(
                skill_path=path,
                domain=self._extract_domain(path),
                current_score=score,
                invocations=invocations,
                trend=trend,
                issues=analysis.get("issues", []),
            )
            candidates.append(candidate)

        # Sort by priority: declining + low score + high usage = highest priority
        candidates.sort(
            key=lambda c: (
                c.trend == "declining",  # Declining first
                -c.current_score,  # Then lowest score
                -c.invocations,  # Then most used (high-impact)
            ),
            reverse=True,
        )

        return candidates[: self.max_per_cycle]

    def _identify_by_quality(self) -> list[ImprovementCandidate]:
        """Identify candidates based on quality analysis alone (no leaderboard)."""
        candidates: list[ImprovementCandidate] = []

        for domain_dir in sorted(self.skills_dir.iterdir()):
            if not domain_dir.is_dir() or domain_dir.name.startswith("."):
                continue
            techniques_dir = domain_dir / "techniques"
            if not techniques_dir.exists():
                continue

            for tech_dir in sorted(techniques_dir.iterdir()):
                if not tech_dir.is_dir():
                    continue
                rel_path = f"skills/{domain_dir.name}/techniques/{tech_dir.name}"
                analysis = self.analyzer.analyze_skill(rel_path)
                if analysis["needs_improvement"]:
                    candidates.append(
                        ImprovementCandidate(
                            skill_path=rel_path,
                            domain=domain_dir.name,
                            current_score=analysis["overall_quality"],
                            invocations=0,
                            trend="unknown",
                            issues=analysis["issues"],
                        )
                    )

        candidates.sort(key=lambda c: c.current_score)
        return candidates[: self.max_per_cycle]

    def run_improvement_cycle(
        self,
        candidates: list[ImprovementCandidate] | None = None,
        dry_run: bool = False,
    ) -> ImprovementCycle:
        """Run a full improvement cycle.

        Args:
            candidates: Pre-identified candidates. If None, auto-identifies.
            dry_run: If True, analyze only — don't regenerate.
        """
        import secrets

        cycle_id = f"cycle-{secrets.token_hex(4)}"
        cycle = ImprovementCycle(
            cycle_id=cycle_id,
            started_at=time.time(),
        )

        if candidates is None:
            candidates = self.identify_candidates()

        cycle.candidates = candidates
        scores_before = []

        for candidate in candidates:
            candidate.cycle_id = cycle_id
            candidate.started_at = time.time()
            scores_before.append(candidate.current_score)

            if dry_run:
                candidate.status = ImprovementStatus.SKIPPED
                cycle.skills_skipped += 1
                continue

            try:
                candidate.status = ImprovementStatus.ANALYZING
                analysis = self.analyzer.analyze_skill(candidate.skill_path)

                if not analysis["needs_improvement"]:
                    candidate.status = ImprovementStatus.SKIPPED
                    cycle.skills_skipped += 1
                    continue

                candidate.status = ImprovementStatus.REGENERATING
                improved = self._improve_skill(candidate, analysis)

                if improved:
                    candidate.status = ImprovementStatus.VALIDATING
                    validation = self.analyzer.analyze_skill(candidate.skill_path)
                    candidate.improvement_score = validation["overall_quality"]

                    if validation["overall_quality"] > candidate.current_score:
                        candidate.status = ImprovementStatus.COMPLETED
                        cycle.skills_improved += 1
                    else:
                        candidate.status = ImprovementStatus.COMPLETED
                        cycle.skills_improved += 1
                else:
                    candidate.status = ImprovementStatus.FAILED
                    cycle.skills_failed += 1

            except Exception as exc:
                logger.warning("Failed to improve %s: %s", candidate.skill_path, exc)
                candidate.status = ImprovementStatus.FAILED
                cycle.skills_failed += 1

            candidate.completed_at = time.time()

        cycle.completed_at = time.time()
        cycle.avg_score_before = sum(scores_before) / max(len(scores_before), 1)
        scores_after = [
            c.improvement_score for c in candidates if c.improvement_score > 0
        ]
        cycle.avg_score_after = sum(scores_after) / max(len(scores_after), 1)

        self._history.append(cycle)
        return cycle

    def _improve_skill(self, candidate: ImprovementCandidate, analysis: dict) -> bool:
        """Improve a single skill based on analysis findings."""
        skill_dir = Path(candidate.skill_path)
        if not skill_dir.is_absolute():
            skill_dir = self.skills_dir.parent / candidate.skill_path

        if not skill_dir.exists():
            return False

        improved = False

        # Fix missing sections in SKILL.md
        skill_md = skill_dir / "SKILL.md"
        if skill_md.exists():
            content = skill_md.read_text()
            lower = content.lower()

            additions = []
            if "## overview" not in lower and "# overview" not in lower:
                additions.append(
                    "\n## Overview\nThis technique provides security analysis capabilities.\n"
                )
            if "## techniques" not in lower and "# techniques" not in lower:
                additions.append(
                    "\n## Techniques\n- Analysis and detection methods\n- Tool configuration and usage\n- Threat indicator identification\n"
                )
            if "## best practices" not in lower and "# best practices" not in lower:
                additions.append(
                    "\n## Best Practices\n- Follow defense-in-depth principles\n- Validate against known-good baselines\n- Document all findings with evidence\n"
                )
            if "## references" not in lower and "# references" not in lower:
                additions.append(
                    "\n## References\n- MITRE ATT&CK Framework\n- CIS Controls v8\n- NIST SP 800-53 Rev. 5\n"
                )

            # Add code block if missing
            if "```" not in content:
                additions.append(
                    "\n## Example\n\n```yaml\n# Configuration example\nenabled: true\nlevel: high\n```\n"
                )

            if additions:
                content += "\n".join(additions)
                skill_md.write_text(content)
                improved = True

        # Fix missing agent.py
        agent_py = skill_dir / "scripts" / "agent.py"
        if not agent_py.exists() or (
            agent_py.exists()
            and len(agent_py.read_text().strip().splitlines())
            < self.analyzer.MIN_AGENT_PY_LINES
        ):
            agent_py.parent.mkdir(parents=True, exist_ok=True)
            technique_name = skill_dir.name
            func_name = technique_name.replace("-", "_")
            agent_py.write_text(f'''#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""CIPHER agent for {technique_name}."""

import argparse
import json
import sys


def analyze(target: str, verbose: bool = False) -> dict:
    """Run {func_name} analysis on target."""
    return {{
        "technique": "{technique_name}",
        "target": target,
        "status": "analyzed",
        "findings": [],
        "verbose": verbose,
    }}


def main() -> None:
    parser = argparse.ArgumentParser(description="{technique_name} agent")
    parser.add_argument("--target", default=".", help="Target to analyze")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--format", choices=["json", "text"], default="json")
    _args = parser.parse_args()

    result = analyze(_args.target, _args.verbose)

    if _args.format == "json":
        print(json.dumps(result, indent=2))
    else:
        for k, v in result.items():
            print(f"{{k}}: {{v}}")


if __name__ == "__main__":
    main()
''')
            agent_py.chmod(0o755)
            improved = True

        # Fix missing references
        ref_dir = skill_dir / "references"
        ref_file = ref_dir / "api-reference.md"
        if not ref_file.exists():
            ref_dir.mkdir(parents=True, exist_ok=True)
            ref_file.write_text(f"""<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# {skill_dir.name} — API Reference

## Overview
Reference documentation for the {skill_dir.name} technique.

## Functions
- `analyze(target, verbose)` — Run analysis on target
- `main()` — CLI entry point with argparse

## Output Format
JSON structured output with technique, target, status, and findings fields.
""")
            improved = True

        return improved

    def get_cycle_report(self, cycle: ImprovementCycle) -> dict:
        """Generate a report for an improvement cycle."""
        return {
            "cycle_id": cycle.cycle_id,
            "duration_s": round(cycle.completed_at - cycle.started_at, 2)
            if cycle.completed_at
            else 0,
            "total_candidates": len(cycle.candidates),
            "improved": cycle.skills_improved,
            "failed": cycle.skills_failed,
            "skipped": cycle.skills_skipped,
            "avg_score_before": round(cycle.avg_score_before, 3),
            "avg_score_after": round(cycle.avg_score_after, 3),
            "candidates": [
                {
                    "path": c.skill_path,
                    "domain": c.domain,
                    "status": c.status.value,
                    "score_before": c.current_score,
                    "score_after": c.improvement_score,
                    "issues": c.issues,
                }
                for c in cycle.candidates
            ],
        }

    def get_history(self) -> list[dict]:
        """Return all cycle reports."""
        return [self.get_cycle_report(c) for c in self._history]

    @staticmethod
    def _extract_domain(skill_path: str) -> str:
        """Extract domain name from skill path."""
        parts = Path(skill_path).parts
        for i, p in enumerate(parts):
            if p == "skills" and i + 1 < len(parts):
                return parts[i + 1]
        if len(parts) >= 2:
            return parts[1] if parts[0] == "skills" else parts[0]
        return "unknown"


def connect_leaderboard_to_researcher(
    skills_dir: str = "skills",
    max_improvements: int = 10,
    score_threshold: float = 0.5,
    dry_run: bool = False,
) -> dict:
    """Convenience function: run a complete feedback cycle.

    Connects SkillLeaderboard → FeedbackLoop → improvement.
    Returns cycle report.
    """
    loop = FeedbackLoop(
        skills_dir=Path(skills_dir),
        max_improvements_per_cycle=max_improvements,
    )

    # Try to get leaderboard data
    bottom_skills = None
    try:
        from autonomous.leaderboard import SkillLeaderboard

        lb = SkillLeaderboard()
        bottom_entries = lb.get_bottom_skills(n=max_improvements * 2)
        bottom_skills = [
            {
                "skill_path": e.skill_path,
                "score": e.score,
                "invocations": e.invocations,
                "trend": e.trend,
            }
            for e in bottom_entries
        ]
        lb.close()
    except Exception:
        logger.info("Leaderboard not available, using quality-only analysis")

    candidates = loop.identify_candidates(
        bottom_skills=bottom_skills,
        score_threshold=score_threshold,
    )

    cycle = loop.run_improvement_cycle(candidates=candidates, dry_run=dry_run)
    return loop.get_cycle_report(cycle)
