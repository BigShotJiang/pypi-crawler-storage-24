# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0

"""Parallel agent execution engine for CIPHER autonomous operations.

Provides thread-pool-based parallel execution of agent tasks with
fan-out/fan-in, map-reduce, pipeline, and callback patterns.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from queue import Queue, Empty
from typing import Any, Callable


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AgentTask:
    """A discrete unit of work for an agent worker."""

    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    skill_path: str = ""
    input_data: dict = field(default_factory=dict)
    status: str = "pending"
    result: dict | None = None
    error: str | None = None
    start_time: float = 0.0
    end_time: float = 0.0
    worker_id: int = 0


@dataclass
class AgentResult:
    """Outcome of a single agent task execution."""

    task_id: str = ""
    success: bool = False
    output: dict = field(default_factory=dict)
    duration: float = 0.0
    worker_id: int = 0
    error: str | None = None


# ---------------------------------------------------------------------------
# WorkerPool
# ---------------------------------------------------------------------------


class WorkerPool:
    """Thread-pool that pulls AgentTasks from a queue and executes them."""

    def __init__(self, max_workers: int = 4) -> None:
        self.max_workers = max_workers
        self._queue: Queue[AgentTask] = Queue()
        self._results: dict[str, AgentResult] = {}
        self._tasks: dict[str, AgentTask] = {}
        self._lock = threading.Lock()
        self._shutdown_event = threading.Event()
        self._all_done = threading.Event()
        self._pending_count = 0
        self._active_count = 0
        self._completed_count = 0
        self._workers: list[threading.Thread] = []

        for wid in range(max_workers):
            t = threading.Thread(
                target=self._worker_loop,
                args=(wid,),
                daemon=True,
                name=f"cipher-worker-{wid}",
            )
            t.start()
            self._workers.append(t)

    # -- public API ---------------------------------------------------------

    def submit(self, task: AgentTask) -> str:
        """Enqueue a single task. Returns its *task_id*."""
        with self._lock:
            self._tasks[task.task_id] = task
            self._pending_count += 1
            self._all_done.clear()
        self._queue.put(task)
        return task.task_id

    def submit_batch(self, tasks: list[AgentTask]) -> list[str]:
        """Enqueue several tasks at once. Returns list of task IDs."""
        ids: list[str] = []
        for task in tasks:
            ids.append(self.submit(task))
        return ids

    def get_result(self, task_id: str) -> AgentResult | None:
        """Return the result for *task_id*, or ``None`` if not yet done."""
        with self._lock:
            return self._results.get(task_id)

    def get_all_results(self) -> list[AgentResult]:
        """Return all results collected so far."""
        with self._lock:
            return list(self._results.values())

    def wait_all(self, timeout: float = 300.0) -> list[AgentResult]:
        """Block until every submitted task has completed or *timeout* expires."""
        self._all_done.wait(timeout=timeout)
        return self.get_all_results()

    def cancel(self, task_id: str) -> bool:
        """Cancel a pending task (cannot cancel already-running tasks)."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task and task.status == "pending":
                task.status = "cancelled"
                self._pending_count -= 1
                self._results[task_id] = AgentResult(
                    task_id=task_id,
                    success=False,
                    output={},
                    duration=0.0,
                    worker_id=0,
                    error="cancelled",
                )
                self._check_all_done()
                return True
        return False

    def cancel_all(self) -> None:
        """Cancel every pending task still in the queue."""
        with self._lock:
            for task in self._tasks.values():
                if task.status == "pending":
                    task.status = "cancelled"
                    self._pending_count -= 1
                    self._results[task.task_id] = AgentResult(
                        task_id=task.task_id,
                        success=False,
                        output={},
                        duration=0.0,
                        worker_id=0,
                        error="cancelled",
                    )
            self._check_all_done()

    def get_status(self) -> dict:
        """Return a snapshot of pool state."""
        with self._lock:
            return {
                "active": self._active_count,
                "pending": self._pending_count,
                "completed": self._completed_count,
                "total_tasks": len(self._tasks),
                "max_workers": self.max_workers,
                "shutdown": self._shutdown_event.is_set(),
            }

    def shutdown(self) -> None:
        """Signal workers to stop and wait for them to drain."""
        self._shutdown_event.set()
        # Unblock any workers waiting on the queue
        for _ in self._workers:
            self._queue.put(None)  # type: ignore[arg-type]
        for t in self._workers:
            t.join(timeout=5.0)

    # -- internal -----------------------------------------------------------

    def _worker_loop(self, worker_id: int) -> None:
        """Main loop executed by each worker thread."""
        while not self._shutdown_event.is_set():
            try:
                task = self._queue.get(timeout=0.5)
            except Empty:
                continue

            if task is None:
                break  # shutdown sentinel

            with self._lock:
                if task.status == "cancelled":
                    self._queue.task_done()
                    continue
                task.status = "running"
                task.worker_id = worker_id
                task.start_time = time.monotonic()
                self._pending_count -= 1
                self._active_count += 1

            result = self._execute_task(task, worker_id)

            with self._lock:
                task.status = "completed" if result.success else "failed"
                task.end_time = time.monotonic()
                task.result = result.output
                task.error = result.error
                self._results[task.task_id] = result
                self._active_count -= 1
                self._completed_count += 1
                self._check_all_done()

            self._queue.task_done()

    def _execute_task(self, task: AgentTask, worker_id: int = 0) -> AgentResult:
        """Execute *task* and return an AgentResult."""
        start = time.monotonic()
        try:
            # Resolve skill module if a SKILL.md path is provided
            output: dict = {}
            skill = Path(task.skill_path) if task.skill_path else None

            if skill and skill.exists():
                output["skill_loaded"] = str(skill)
                output["skill_name"] = skill.parent.name
            else:
                output["skill_loaded"] = None

            # The real payload: run the callable stored in input_data if present
            fn: Callable | None = task.input_data.get("fn")
            if callable(fn):
                args = task.input_data.get("args", ())
                kwargs = task.input_data.get("kwargs", {})
                fn_result = fn(*args, **kwargs)
                output["fn_result"] = fn_result
            else:
                # No callable — just pass input through as output
                output["input_echo"] = task.input_data

            duration = time.monotonic() - start
            return AgentResult(
                task_id=task.task_id,
                success=True,
                output=output,
                duration=duration,
                worker_id=worker_id,
            )
        except Exception as exc:
            duration = time.monotonic() - start
            return AgentResult(
                task_id=task.task_id,
                success=False,
                output={},
                duration=duration,
                worker_id=worker_id,
                error=f"{type(exc).__name__}: {exc}",
            )

    def _check_all_done(self) -> None:
        """Set _all_done if no pending/active work remains. Caller must hold _lock."""
        if self._pending_count <= 0 and self._active_count <= 0:
            self._all_done.set()


# ---------------------------------------------------------------------------
# ParallelScanner
# ---------------------------------------------------------------------------


class ParallelScanner:
    """Distribute security-scan tasks across a WorkerPool."""

    def __init__(self, pool: WorkerPool | None = None) -> None:
        self.pool = pool or WorkerPool()

    def scan_targets(self, targets: list[str], profile: str = "pentest") -> list[dict]:
        """Create one task per target, fan-out, collect results."""
        tasks: list[AgentTask] = []
        for target in targets:
            tasks.append(
                AgentTask(
                    name=f"scan-{target}",
                    input_data={
                        "fn": self._run_scan,
                        "args": (target, profile),
                    },
                )
            )
        ids = self.pool.submit_batch(tasks)
        id_set = set(ids)
        self.pool.wait_all()
        all_results = self.pool.get_all_results()
        results = [r for r in all_results if r.task_id in id_set]
        id_to_target = dict(zip(ids, targets))
        return [
            {
                "task_id": r.task_id,
                "target": id_to_target.get(r.task_id, "unknown"),
                "success": r.success,
                "output": r.output,
                "duration": r.duration,
                "error": r.error,
            }
            for r in results
        ]

    def scan_domains(self, domains: list[str]) -> dict:
        """Run domain-specific recon scans in parallel."""
        tasks: list[AgentTask] = []
        for domain in domains:
            tasks.append(
                AgentTask(
                    name=f"domain-scan-{domain}",
                    input_data={
                        "fn": self._run_domain_scan,
                        "args": (domain,),
                    },
                )
            )
        ids = self.pool.submit_batch(tasks)
        id_set = set(ids)
        self.pool.wait_all()
        all_results = self.pool.get_all_results()
        results = [r for r in all_results if r.task_id in id_set]
        return {
            "domains_scanned": len(domains),
            "successful": sum(1 for r in results if r.success),
            "failed": sum(1 for r in results if not r.success),
            "results": [
                {
                    "task_id": r.task_id,
                    "success": r.success,
                    "output": r.output,
                    "error": r.error,
                }
                for r in results
            ],
        }

    # -- scan implementations (stubs — real tools plug in here) -------------

    @staticmethod
    def _run_scan(target: str, profile: str) -> dict:
        """Execute a scan against *target* using *profile*."""
        return {
            "target": target,
            "profile": profile,
            "findings": [],
            "status": "complete",
            "timestamp": time.time(),
        }

    @staticmethod
    def _run_domain_scan(domain: str) -> dict:
        """Execute domain recon for *domain*."""
        return {
            "domain": domain,
            "dns_records": [],
            "subdomains": [],
            "ports": [],
            "status": "complete",
            "timestamp": time.time(),
        }


# ---------------------------------------------------------------------------
# ParallelAnalyzer
# ---------------------------------------------------------------------------


class ParallelAnalyzer:
    """Analyze artifacts (diffs, responses) concurrently."""

    def __init__(self, pool: WorkerPool | None = None) -> None:
        self.pool = pool or WorkerPool()

    def analyze_diffs(self, diffs: list[str]) -> list[dict]:
        """Analyze multiple diffs concurrently for security issues."""
        tasks: list[AgentTask] = []
        for idx, diff in enumerate(diffs):
            tasks.append(
                AgentTask(
                    name=f"diff-analysis-{idx}",
                    input_data={
                        "fn": self._analyze_single_diff,
                        "args": (diff,),
                    },
                )
            )
        ids = self.pool.submit_batch(tasks)
        id_set = set(ids)
        self.pool.wait_all()
        all_results = self.pool.get_all_results()
        results = [r for r in all_results if r.task_id in id_set]
        return [
            {
                "task_id": r.task_id,
                "success": r.success,
                "analysis": r.output.get("fn_result", {}),
                "error": r.error,
            }
            for r in results
        ]

    def bulk_score(self, responses: list[dict]) -> list[dict]:
        """Score multiple responses in parallel."""
        tasks: list[AgentTask] = []
        for idx, resp in enumerate(responses):
            tasks.append(
                AgentTask(
                    name=f"score-{idx}",
                    input_data={
                        "fn": self._score_response,
                        "args": (resp,),
                    },
                )
            )
        ids = self.pool.submit_batch(tasks)
        id_set = set(ids)
        self.pool.wait_all()
        all_results = self.pool.get_all_results()
        results = [r for r in all_results if r.task_id in id_set]
        return [
            {
                "task_id": r.task_id,
                "success": r.success,
                "score": r.output.get("fn_result", {}),
                "error": r.error,
            }
            for r in results
        ]

    # -- analysis stubs -----------------------------------------------------

    @staticmethod
    def _analyze_single_diff(diff: str) -> dict:
        """Analyze a single diff for security-relevant changes."""
        lines = diff.strip().splitlines() if diff else []
        additions = sum(1 for line in lines if line.startswith("+"))
        deletions = sum(1 for line in lines if line.startswith("-"))
        return {
            "total_lines": len(lines),
            "additions": additions,
            "deletions": deletions,
            "risk_indicators": [],
            "severity": "info",
        }

    @staticmethod
    def _score_response(response: dict) -> dict:
        """Score a single response for quality/risk."""
        score = 0.5  # baseline
        flags: list[str] = []
        if "error" in response:
            score -= 0.3
            flags.append("contains_error")
        if response.get("status") == "complete":
            score += 0.2
            flags.append("complete")
        return {
            "score": max(0.0, min(1.0, score)),
            "flags": flags,
        }


# ---------------------------------------------------------------------------
# TaskOrchestrator
# ---------------------------------------------------------------------------


class TaskOrchestrator:
    """High-level orchestration patterns over a WorkerPool."""

    def __init__(self, max_workers: int = 4) -> None:
        self.max_workers = max_workers
        self._pool = WorkerPool(max_workers=max_workers)
        self._metrics_lock = threading.Lock()
        self._total_tasks = 0
        self._total_duration = 0.0
        self._total_failures = 0

    # -- orchestration patterns ---------------------------------------------

    def fan_out(self, tasks: list[AgentTask]) -> list[AgentResult]:
        """Submit all tasks, wait for completion, return results."""
        pool = WorkerPool(max_workers=self.max_workers)
        try:
            pool.submit_batch(tasks)
            results = pool.wait_all()
            self._record_metrics(results)
            return results
        finally:
            pool.shutdown()

    def fan_out_with_callback(
        self, tasks: list[AgentTask], callback: Callable[[AgentResult], None]
    ) -> None:
        """Fan-out tasks; invoke *callback* as each completes."""
        pool = WorkerPool(max_workers=self.max_workers)
        seen: set[str] = set()
        task_ids = set(pool.submit_batch(tasks))

        try:
            deadline = time.monotonic() + 300.0
            while seen != task_ids and time.monotonic() < deadline:
                time.sleep(0.05)
                for tid in task_ids - seen:
                    result = pool.get_result(tid)
                    if result is not None:
                        seen.add(tid)
                        callback(result)
            self._record_metrics(pool.get_all_results())
        finally:
            pool.shutdown()

    def map_reduce(
        self,
        tasks: list[AgentTask],
        reduce_fn: Callable[[list[AgentResult]], Any],
    ) -> Any:
        """Fan-out *tasks* then apply *reduce_fn* to the collected results."""
        results = self.fan_out(tasks)
        return reduce_fn(results)

    def pipeline(self, stages: list[list[AgentTask]]) -> list[AgentResult]:
        """Execute stages sequentially; within each stage, tasks run in parallel.

        The output of stage N is available as ``prior_results`` in
        ``input_data`` of stage N+1 tasks (injected automatically).
        """
        all_results: list[AgentResult] = []
        prior_results: list[AgentResult] = []

        for stage_tasks in stages:
            # Inject prior stage results into each task's input_data
            for task in stage_tasks:
                task.input_data["prior_results"] = [
                    {
                        "task_id": r.task_id,
                        "success": r.success,
                        "output": r.output,
                        "error": r.error,
                    }
                    for r in prior_results
                ]

            prior_results = self.fan_out(stage_tasks)
            all_results.extend(prior_results)

        return all_results

    # -- metrics ------------------------------------------------------------

    def get_metrics(self) -> dict:
        """Return throughput, average duration, and failure rate."""
        with self._metrics_lock:
            avg = self._total_duration / self._total_tasks if self._total_tasks else 0.0
            failure_rate = (
                self._total_failures / self._total_tasks if self._total_tasks else 0.0
            )
            return {
                "total_tasks": self._total_tasks,
                "total_duration": round(self._total_duration, 4),
                "avg_duration": round(avg, 4),
                "failure_rate": round(failure_rate, 4),
                "max_workers": self.max_workers,
            }

    def shutdown(self) -> None:
        """Shut down the internal pool."""
        self._pool.shutdown()

    # -- internal -----------------------------------------------------------

    def _record_metrics(self, results: list[AgentResult]) -> None:
        with self._metrics_lock:
            for r in results:
                self._total_tasks += 1
                self._total_duration += r.duration
                if not r.success:
                    self._total_failures += 1
