# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0
"""Autonomous security research engine for self-improving skill generation."""

from __future__ import annotations

import ast
import datetime
import textwrap
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import yaml

if TYPE_CHECKING:
    from memory.core.engine import CipherMemory


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ResearchHypothesis:
    """A proposed new technique with generated skill content."""

    hypothesis_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    domain: str = ""
    technique_name: str = ""
    description: str = ""
    skill_content: str = ""
    agent_script: str = ""
    reference_content: str = ""
    confidence: float = 0.0
    status: str = "proposed"
    test_results: dict = field(default_factory=dict)
    created_at: str = field(
        default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
    )


@dataclass
class ResearchExperiment:
    """Validation result for a research hypothesis."""

    experiment_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    hypothesis: ResearchHypothesis = field(default_factory=ResearchHypothesis)
    validation_checks: list[str] = field(default_factory=list)
    check_results: dict[str, bool] = field(default_factory=dict)
    overall_pass: bool = False
    created_at: str = field(
        default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
    )


# ---------------------------------------------------------------------------
# Skill-gap analysis
# ---------------------------------------------------------------------------

# Canonical MITRE ATT&CK tactics mapped to representative technique IDs.
_MITRE_TACTICS: dict[str, list[str]] = {
    "reconnaissance": [
        "T1595",
        "T1592",
        "T1589",
        "T1590",
        "T1591",
        "T1596",
        "T1597",
        "T1598",
    ],
    "resource-development": [
        "T1583",
        "T1584",
        "T1585",
        "T1586",
        "T1587",
        "T1588",
    ],
    "initial-access": [
        "T1189",
        "T1190",
        "T1133",
        "T1200",
        "T1566",
        "T1195",
        "T1199",
        "T1078",
    ],
    "execution": [
        "T1059",
        "T1203",
        "T1047",
        "T1053",
        "T1129",
        "T1106",
        "T1204",
    ],
    "persistence": [
        "T1098",
        "T1197",
        "T1547",
        "T1136",
        "T1543",
        "T1546",
        "T1053",
        "T1078",
    ],
    "privilege-escalation": [
        "T1548",
        "T1134",
        "T1547",
        "T1484",
        "T1055",
        "T1053",
        "T1078",
    ],
    "defense-evasion": [
        "T1140",
        "T1027",
        "T1036",
        "T1070",
        "T1562",
        "T1202",
        "T1218",
        "T1222",
    ],
    "credential-access": [
        "T1110",
        "T1003",
        "T1555",
        "T1552",
        "T1187",
        "T1557",
        "T1558",
    ],
    "discovery": [
        "T1087",
        "T1482",
        "T1083",
        "T1135",
        "T1046",
        "T1057",
        "T1018",
        "T1082",
    ],
    "lateral-movement": [
        "T1021",
        "T1210",
        "T1534",
        "T1570",
        "T1563",
        "T1080",
    ],
    "collection": [
        "T1560",
        "T1123",
        "T1119",
        "T1005",
        "T1039",
        "T1025",
        "T1074",
        "T1114",
    ],
    "command-and-control": [
        "T1071",
        "T1132",
        "T1001",
        "T1568",
        "T1573",
        "T1095",
        "T1572",
        "T1090",
    ],
    "exfiltration": [
        "T1041",
        "T1048",
        "T1567",
        "T1029",
        "T1030",
        "T1537",
    ],
    "impact": [
        "T1485",
        "T1486",
        "T1565",
        "T1491",
        "T1561",
        "T1499",
        "T1529",
    ],
}


class SkillGapAnalyzer:
    """Analyze skill coverage against MITRE ATT&CK and identify gaps."""

    def __init__(self, skills_dir: Path) -> None:
        self.skills_dir = Path(skills_dir)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _list_domains(self) -> list[str]:
        """Return sorted domain directory names."""
        if not self.skills_dir.is_dir():
            return []
        return sorted(
            d.name
            for d in self.skills_dir.iterdir()
            if d.is_dir() and not d.name.startswith(".")
        )

    def _list_techniques(self, domain: str) -> list[str]:
        """Return technique directory names for *domain*."""
        tech_dir = self.skills_dir / domain / "techniques"
        if not tech_dir.is_dir():
            return []
        return sorted(
            d.name
            for d in tech_dir.iterdir()
            if d.is_dir() and not d.name.startswith(".")
        )

    def _parse_skill_frontmatter(self, skill_md: Path) -> dict:
        """Extract YAML frontmatter from a SKILL.md file."""
        if not skill_md.is_file():
            return {}
        text = skill_md.read_text(encoding="utf-8")
        # Skip optional HTML comment header, find YAML block between ---
        parts = text.split("---")
        for i in range(1, len(parts)):
            candidate = parts[i].strip()
            if not candidate:
                continue
            try:
                data = yaml.safe_load(candidate)
                if isinstance(data, dict):
                    return data
            except yaml.YAMLError:
                continue
        return {}

    def _technique_has_file(self, domain: str, technique: str, filename: str) -> bool:
        """Check if a technique directory contains a specific file."""
        # Check common nested locations
        candidates = [
            self.skills_dir / domain / "techniques" / technique / filename,
            self.skills_dir / domain / "techniques" / technique / "scripts" / filename,
            self.skills_dir
            / domain
            / "techniques"
            / technique
            / "references"
            / filename,
        ]
        return any(c.is_file() for c in candidates)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_coverage(self) -> dict:
        """Map MITRE ATT&CK tactics to covered / uncovered techniques."""
        domains = self._list_domains()
        # Collect all MITRE IDs mentioned across skills
        covered_ids: set[str] = set()
        for domain in domains:
            domain_skill = self.skills_dir / domain / "SKILL.md"
            meta = self._parse_skill_frontmatter(domain_skill)
            mitre = meta.get("metadata", {})
            if isinstance(mitre, dict):
                ids = mitre.get("mitre-attack", [])
                if isinstance(ids, list):
                    covered_ids.update(str(i) for i in ids)
            # Also scan technique-level SKILL.md
            for tech in self._list_techniques(domain):
                tech_skill = self.skills_dir / domain / "techniques" / tech / "SKILL.md"
                tech_meta = self._parse_skill_frontmatter(tech_skill)
                tech_mitre = tech_meta.get("metadata", {})
                if isinstance(tech_mitre, dict):
                    tech_ids = tech_mitre.get("mitre-attack", [])
                    if isinstance(tech_ids, list):
                        covered_ids.update(str(i) for i in tech_ids)

        coverage: dict[str, dict] = {}
        for tactic, technique_ids in _MITRE_TACTICS.items():
            covered = [t for t in technique_ids if t in covered_ids]
            uncovered = [t for t in technique_ids if t not in covered_ids]
            coverage[tactic] = {
                "total": len(technique_ids),
                "covered": covered,
                "uncovered": uncovered,
                "pct": round(len(covered) / max(len(technique_ids), 1) * 100, 1),
            }
        return coverage

    def find_gaps(self) -> list[dict]:
        """Identify domains with fewer than 24 techniques."""
        gaps: list[dict] = []
        for domain in self._list_domains():
            techniques = self._list_techniques(domain)
            if len(techniques) < 24:
                gaps.append(
                    {
                        "domain": domain,
                        "technique_count": len(techniques),
                        "deficit": 24 - len(techniques),
                        "existing": techniques,
                    }
                )
        return gaps

    def suggest_new_techniques(self, domain: str, count: int = 5) -> list[str]:
        """Suggest new technique names based on existing naming patterns."""
        existing = self._list_techniques(domain)
        # Extract verb prefixes used across all domains
        verb_counts: dict[str, int] = {}
        for d in self._list_domains():
            for tech in self._list_techniques(d):
                verb = tech.split("-")[0] if "-" in tech else tech
                verb_counts[verb] = verb_counts.get(verb, 0) + 1

        # Rank verbs by usage, prefer common ones
        popular_verbs = sorted(verb_counts, key=verb_counts.get, reverse=True)  # type: ignore[arg-type]

        # Generate suggestions by combining popular verbs with domain keywords
        domain_words = domain.replace("-", " ").split()
        suggestions: list[str] = []
        existing_set = set(existing)

        for verb in popular_verbs:
            if len(suggestions) >= count:
                break
            for kw in domain_words:
                candidate = f"{verb}-{kw}-operations"
                if candidate not in existing_set and candidate not in suggestions:
                    suggestions.append(candidate)
                    if len(suggestions) >= count:
                        break
            # Also try verb-domain pattern
            candidate_alt = f"{verb}-{domain}-analysis"
            if candidate_alt not in existing_set and candidate_alt not in suggestions:
                suggestions.append(candidate_alt)
                if len(suggestions) >= count:
                    break

        return suggestions[:count]

    def identify_weak_domains(self) -> list[dict]:
        """Domains with techniques missing agent.py or api-reference.md."""
        weak: list[dict] = []
        for domain in self._list_domains():
            techniques = self._list_techniques(domain)
            missing_scripts: list[str] = []
            missing_refs: list[str] = []
            missing_skill: list[str] = []

            for tech in techniques:
                if not self._technique_has_file(domain, tech, "agent.py"):
                    missing_scripts.append(tech)
                if not self._technique_has_file(domain, tech, "api-reference.md"):
                    missing_refs.append(tech)
                skill_path = self.skills_dir / domain / "techniques" / tech / "SKILL.md"
                if not skill_path.is_file():
                    missing_skill.append(tech)

            if missing_scripts or missing_refs or missing_skill:
                weak.append(
                    {
                        "domain": domain,
                        "total_techniques": len(techniques),
                        "missing_agent_script": missing_scripts,
                        "missing_api_reference": missing_refs,
                        "missing_skill_md": missing_skill,
                        "completeness_pct": round(
                            (
                                1
                                - (
                                    len(missing_scripts)
                                    + len(missing_refs)
                                    + len(missing_skill)
                                )
                                / max(len(techniques) * 3, 1)
                            )
                            * 100,
                            1,
                        ),
                    }
                )
        return weak

    def get_coverage_report(self) -> dict:
        """Full coverage statistics."""
        domains = self._list_domains()
        total_techniques = 0
        domain_stats: list[dict] = []
        for domain in domains:
            techs = self._list_techniques(domain)
            total_techniques += len(techs)
            domain_stats.append(
                {
                    "domain": domain,
                    "technique_count": len(techs),
                }
            )

        mitre_coverage = self.analyze_coverage()
        gaps = self.find_gaps()
        weak = self.identify_weak_domains()

        return {
            "total_domains": len(domains),
            "total_techniques": total_techniques,
            "domain_stats": domain_stats,
            "mitre_coverage": mitre_coverage,
            "gap_count": len(gaps),
            "weak_domain_count": len(weak),
        }


# ---------------------------------------------------------------------------
# Content generators (templates)
# ---------------------------------------------------------------------------


def _generate_skill_md(domain: str, technique_name: str, description: str) -> str:
    """Generate SKILL.md content for a new technique."""
    return textwrap.dedent(f"""\
        <!-- Copyright (c) 2026 defconxt. All rights reserved. -->
        <!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
        ---
        name: {technique_name}
        description: >-
          {description}
        domain: cybersecurity
        subdomain: {domain}
        tags:
          - {domain}
          - {technique_name.split("-")[0]}
          - security-automation
        version: "1.0"
        author: defconxt
        license: AGPL-3.0
        ---

        # {_title_case(technique_name)}

        ## Quick Reference

        | Item | Detail |
        |---|---|
        | Domain | {domain} |
        | Technique | {technique_name} |
        | ATT&CK | See metadata |
        | Difficulty | Intermediate |

        ## Overview

        {description}

        ## Workflow

        1. **Preparation** — Gather required tooling and access.
        2. **Execution** — Run the technique using the agent script.
        3. **Analysis** — Review output and correlate findings.
        4. **Reporting** — Document results and remediation steps.

        ## Verification

        ```bash
        python3 scripts/agent.py analyze --target example
        python3 scripts/agent.py report --format json
        ```

        ## References

        - MITRE ATT&CK: https://attack.mitre.org/
        - See `references/api-reference.md` for command details.
    """)


def _generate_agent_py(domain: str, technique_name: str) -> str:
    """Generate agent.py content for a new technique."""
    module_doc = f"Agent tooling for {_title_case(technique_name).lower()}."
    func_prefix = technique_name.replace("-", "_")[:20]

    return textwrap.dedent(f"""\
        #!/usr/bin/env python3
        \"\"\"{module_doc}\"\"\"

        import argparse
        import json
        import sys
        from pathlib import Path


        def {func_prefix}_analyze(target: str, verbose: bool = False) -> dict:
            \"\"\"Analyze a target for {technique_name} indicators.\"\"\"
            results = {{
                "action": "analyze",
                "technique": "{technique_name}",
                "domain": "{domain}",
                "target": target,
                "findings": [],
                "risk_level": "medium",
            }}
            if verbose:
                results["debug"] = {{"verbose": True}}
            return results


        def {func_prefix}_scan(scope: str, depth: int = 3) -> dict:
            \"\"\"Scan the given scope for relevant indicators.\"\"\"
            return {{
                "action": "scan",
                "technique": "{technique_name}",
                "scope": scope,
                "depth": depth,
                "items_found": 0,
                "results": [],
            }}


        def {func_prefix}_report(fmt: str = "json") -> dict:
            \"\"\"Generate a summary report.\"\"\"
            return {{
                "action": "report",
                "technique": "{technique_name}",
                "format": fmt,
                "sections": ["overview", "findings", "recommendations"],
            }}


        def main() -> None:
            parser = argparse.ArgumentParser(
                description="{module_doc}",
            )
            sub = parser.add_subparsers(dest="command", required=True)

            # analyze
            p_analyze = sub.add_parser("analyze", help="Analyze a target")
            p_analyze.add_argument("--target", required=True, help="Target to analyze")
            p_analyze.add_argument("--verbose", action="store_true")

            # scan
            p_scan = sub.add_parser("scan", help="Scan a scope")
            p_scan.add_argument("--scope", required=True, help="Scope to scan")
            p_scan.add_argument("--depth", type=int, default=3)

            # report
            p_report = sub.add_parser("report", help="Generate report")
            p_report.add_argument("--format", default="json", choices=["json", "text", "csv"])

            args = parser.parse_args()

            if args.command == "analyze":
                result = {func_prefix}_analyze(args.target, getattr(args, "verbose", False))
            elif args.command == "scan":
                result = {func_prefix}_scan(args.scope, args.depth)
            elif args.command == "report":
                result = {func_prefix}_report(getattr(args, "format", "json"))
            else:
                parser.print_help()
                sys.exit(1)

            json.dump(result, sys.stdout, indent=2)
            print()


        if __name__ == "__main__":
            main()
    """)


def _generate_api_reference(domain: str, technique_name: str) -> str:
    """Generate api-reference.md content for a new technique."""
    title = _title_case(technique_name)
    return textwrap.dedent(f"""\
        <!-- Copyright (c) 2026 defconxt. All rights reserved. -->
        <!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

        # API Reference — {title}

        ## Agent Script

        | Command | Description |
        |---|---|
        | `python3 agent.py analyze --target <t>` | Analyze a target for {technique_name} indicators |
        | `python3 agent.py scan --scope <s> [--depth N]` | Scan a scope for relevant data |
        | `python3 agent.py report --format json\\|text\\|csv` | Generate a summary report |

        ## Options

        | Flag | Type | Default | Description |
        |---|---|---|---|
        | `--target` | str | *(required)* | Target identifier for analysis |
        | `--scope` | str | *(required)* | Scan scope definition |
        | `--depth` | int | 3 | Scan recursion depth |
        | `--format` | str | json | Output format |
        | `--verbose` | flag | false | Enable verbose output |

        ## Output Format

        All commands return JSON:

        ```json
        {{
          "action": "<command>",
          "technique": "{technique_name}",
          "domain": "{domain}",
          ...
        }}
        ```

        ## Examples

        ```bash
        # Analyze a target
        python3 scripts/agent.py analyze --target 192.168.1.0/24

        # Deep scan
        python3 scripts/agent.py scan --scope internal --depth 5

        # Generate report
        python3 scripts/agent.py report --format text
        ```
    """)


def _title_case(slug: str) -> str:
    """Convert a-kebab-slug to Title Case."""
    return " ".join(w.capitalize() for w in slug.split("-"))


# ---------------------------------------------------------------------------
# Autonomous researcher
# ---------------------------------------------------------------------------


class AutonomousResearcher:
    """Self-improving security research engine.

    Generates, validates, and applies new technique hypotheses to expand
    the CIPHER skill library autonomously.
    """

    def __init__(
        self,
        skills_dir: Path,
        memory: CipherMemory | None = None,
    ) -> None:
        self.skills_dir = Path(skills_dir)
        self.memory = memory
        self._history: list[dict] = []
        self._analyzer = SkillGapAnalyzer(self.skills_dir)

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    def generate_hypothesis(
        self,
        domain: str,
        technique_name: str,
    ) -> ResearchHypothesis:
        """Create a complete hypothesis with SKILL.md, agent.py, and api-reference.md."""
        description = (
            f"Automated security technique for {_title_case(technique_name).lower()} "
            f"within the {domain} domain. Provides analysis, scanning, and reporting "
            f"capabilities for defensive and offensive security workflows."
        )

        skill_content = _generate_skill_md(domain, technique_name, description)
        agent_script = _generate_agent_py(domain, technique_name)
        reference_content = _generate_api_reference(domain, technique_name)

        hypothesis = ResearchHypothesis(
            domain=domain,
            technique_name=technique_name,
            description=description,
            skill_content=skill_content,
            agent_script=agent_script,
            reference_content=reference_content,
            confidence=0.75,
            status="proposed",
        )
        return hypothesis

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_hypothesis(
        self,
        hypothesis: ResearchHypothesis,
    ) -> ResearchExperiment:
        """Run validation checks against a hypothesis."""
        checks = [
            "yaml_valid",
            "script_compiles",
            "references_exist",
            "skill_has_sections",
            "content_length",
        ]
        results: dict[str, bool] = {}

        # 1. YAML frontmatter is parseable
        results["yaml_valid"] = self._check_yaml(hypothesis.skill_content)

        # 2. Python script compiles without syntax errors
        results["script_compiles"] = self._check_compiles(hypothesis.agent_script)

        # 3. Reference content is non-empty and has a heading
        results["references_exist"] = self._check_references(
            hypothesis.reference_content
        )

        # 4. SKILL.md has required sections
        results["skill_has_sections"] = self._check_skill_sections(
            hypothesis.skill_content
        )

        # 5. Minimum content length thresholds
        results["content_length"] = self._check_content_length(
            hypothesis.skill_content,
            hypothesis.agent_script,
            hypothesis.reference_content,
        )

        overall = all(results.values())
        hypothesis.test_results = dict(results)
        hypothesis.status = "testing"

        experiment = ResearchExperiment(
            hypothesis=hypothesis,
            validation_checks=checks,
            check_results=results,
            overall_pass=overall,
        )
        return experiment

    @staticmethod
    def _check_yaml(skill_content: str) -> bool:
        """Verify YAML frontmatter parses correctly."""
        parts = skill_content.split("---")
        for i in range(1, len(parts)):
            candidate = parts[i].strip()
            if not candidate:
                continue
            try:
                data = yaml.safe_load(candidate)
                return isinstance(data, dict) and "name" in data
            except yaml.YAMLError:
                continue
        return False

    @staticmethod
    def _check_compiles(script: str) -> bool:
        """Verify Python script compiles without syntax errors."""
        try:
            ast.parse(script)
            return True
        except SyntaxError:
            return False

    @staticmethod
    def _check_references(ref_content: str) -> bool:
        """Check that reference content exists and has a heading."""
        return (
            bool(ref_content)
            and ref_content.strip().startswith("#")
            or "# " in ref_content
        )

    @staticmethod
    def _check_skill_sections(skill_content: str) -> bool:
        """Verify SKILL.md contains required sections."""
        required = ["Quick Reference", "Workflow", "Verification", "References"]
        content_lower = skill_content.lower()
        return all(section.lower() in content_lower for section in required)

    @staticmethod
    def _check_content_length(
        skill: str,
        script: str,
        reference: str,
    ) -> bool:
        """Verify minimum content length thresholds."""
        return len(skill) >= 200 and len(script) >= 200 and len(reference) >= 100

    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------

    def apply_hypothesis(self, hypothesis: ResearchHypothesis) -> bool:
        """Write hypothesis files to disk and update index."""
        try:
            base = (
                self.skills_dir
                / hypothesis.domain
                / "techniques"
                / hypothesis.technique_name
            )
            scripts_dir = base / "scripts"
            refs_dir = base / "references"

            scripts_dir.mkdir(parents=True, exist_ok=True)
            refs_dir.mkdir(parents=True, exist_ok=True)

            # Write SKILL.md
            (base / "SKILL.md").write_text(hypothesis.skill_content, encoding="utf-8")

            # Write agent.py
            agent_path = scripts_dir / "agent.py"
            agent_path.write_text(hypothesis.agent_script, encoding="utf-8")
            agent_path.chmod(0o755)

            # Write api-reference.md
            (refs_dir / "api-reference.md").write_text(
                hypothesis.reference_content, encoding="utf-8"
            )

            hypothesis.status = "accepted"

            # Store in memory if available
            if self.memory is not None:
                try:
                    from memory.core.engine import MemoryEntry, MemoryType

                    self.memory.store(
                        MemoryEntry(
                            content=(
                                f"Generated technique {hypothesis.technique_name} "
                                f"in {hypothesis.domain}"
                            ),
                            memory_type=MemoryType.NOTE,
                            keywords=[
                                hypothesis.domain,
                                hypothesis.technique_name,
                                hypothesis.hypothesis_id,
                            ],
                        )
                    )
                except Exception:
                    pass  # Memory is optional

            return True
        except OSError:
            hypothesis.status = "rejected"
            return False

    # ------------------------------------------------------------------
    # Orchestration
    # ------------------------------------------------------------------

    def run_experiment(
        self,
        domain: str,
        technique_name: str,
    ) -> ResearchExperiment:
        """Full cycle: generate → validate → apply if passing."""
        hypothesis = self.generate_hypothesis(domain, technique_name)
        experiment = self.validate_hypothesis(hypothesis)

        if experiment.overall_pass:
            applied = self.apply_hypothesis(hypothesis)
            if not applied:
                hypothesis.status = "rejected"
                experiment.overall_pass = False
        else:
            hypothesis.status = "rejected"

        self._history.append(
            {
                "experiment_id": experiment.experiment_id,
                "hypothesis_id": hypothesis.hypothesis_id,
                "domain": domain,
                "technique_name": technique_name,
                "overall_pass": experiment.overall_pass,
                "status": hypothesis.status,
                "checks": dict(experiment.check_results),
                "created_at": experiment.created_at,
            }
        )

        return experiment

    def batch_expand(
        self,
        domain: str,
        techniques: list[str],
    ) -> list[ResearchExperiment]:
        """Run experiments for multiple techniques in a domain."""
        results: list[ResearchExperiment] = []
        for technique in techniques:
            experiment = self.run_experiment(domain, technique)
            results.append(experiment)
        return results

    def get_research_history(self) -> list[dict]:
        """Return all experiments with results."""
        return list(self._history)
