# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.

"""
CIPHER Autonomous Scheduler — Idle-aware background task execution.

Inspired by MetaClaw's SlowUpdateScheduler. Detects system idle state
via platform-specific APIs, then runs prioritized background tasks
(memory consolidation, skill metric updates, decay sweeps, cleanup)
during idle windows — typically overnight or during extended inactivity.

Architecture:
    IdleDetector        — Platform-specific idle detection (macOS/Linux/fallback)
    LastRequestTracker  — Thread-safe last-interaction timestamp
    ScheduledTask       — Dataclass describing a schedulable unit of work
    CipherScheduler     — State-machine scheduler with async + sync entry points

State machine:
    IDLE_WAIT → WINDOW_OPEN → RUNNING → PAUSING → IDLE_WAIT
"""

from __future__ import annotations

import asyncio
import enum
import logging
import platform
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional

logger = logging.getLogger("cipher.autonomous.scheduler")


# ---------------------------------------------------------------------------
# Task Priority
# ---------------------------------------------------------------------------


class TaskPriority(enum.IntEnum):
    """Priority levels for scheduled tasks — lower value = higher priority."""

    CRITICAL = 0
    HIGH = 1
    MEDIUM = 2
    LOW = 3
    BACKGROUND = 4


# ---------------------------------------------------------------------------
# Scheduled Task
# ---------------------------------------------------------------------------


@dataclass
class ScheduledTask:
    """A single schedulable unit of work.

    Attributes:
        task_id:          Unique identifier (uuid4 hex).
        name:             Human-readable task name.
        task_type:        Category — one of skill_evolution, memory_consolidation,
                          scan_regression, metric_update, skill_expansion.
        priority:         Execution priority (lower runs first).
        callable_fn:      The function to invoke.
        args:             Positional arguments forwarded to callable_fn.
        kwargs:           Keyword arguments forwarded to callable_fn.
        interval_seconds: 0 = one-shot, >0 = recurring interval in seconds.
        last_run:         Epoch timestamp of last execution.
        next_run:         Epoch timestamp when task becomes eligible.
        run_count:        Total number of completed executions.
        max_runs:         Cap on executions — 0 means unlimited.
        enabled:          Whether the task is active.
        requires_idle:    If True, only execute during idle windows.
        created_at:       ISO-8601 creation timestamp.
    """

    name: str
    task_type: str
    priority: TaskPriority
    callable_fn: Callable[..., Any]
    args: tuple = ()
    kwargs: dict = field(default_factory=dict)
    task_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    interval_seconds: int = 0
    last_run: float = 0.0
    next_run: float = 0.0
    run_count: int = 0
    max_runs: int = 0
    enabled: bool = True
    requires_idle: bool = True
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def is_due(self, now: Optional[float] = None) -> bool:
        """Return True if the task should run at *now* (epoch seconds)."""
        if not self.enabled:
            return False
        if self.max_runs > 0 and self.run_count >= self.max_runs:
            return False
        now = now or time.time()
        return now >= self.next_run

    def record_run(self, now: Optional[float] = None) -> None:
        """Mark the task as having just executed."""
        now = now or time.time()
        self.last_run = now
        self.run_count += 1
        if self.interval_seconds > 0:
            self.next_run = now + self.interval_seconds
        else:
            # One-shot — disable after run
            self.enabled = False


# ---------------------------------------------------------------------------
# Task Execution Result
# ---------------------------------------------------------------------------


@dataclass
class TaskResult:
    """Record of a single task execution."""

    task_id: str
    task_name: str
    started_at: float
    finished_at: float
    success: bool
    error: Optional[str] = None
    result: Any = None

    @property
    def duration_ms(self) -> float:
        return (self.finished_at - self.started_at) * 1000


# ---------------------------------------------------------------------------
# Idle Detection
# ---------------------------------------------------------------------------


class LastRequestTracker:
    """Thread-safe tracker for the most recent operator interaction."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_touch: float = time.time()

    def touch(self) -> None:
        """Record an interaction right now."""
        with self._lock:
            self._last_touch = time.time()

    def seconds_since_last(self) -> float:
        """Seconds elapsed since the last recorded interaction."""
        with self._lock:
            return time.time() - self._last_touch


class IdleDetector:
    """Platform-specific system idle detection.

    Strategy priority:
        1. macOS: ``ioreg`` HIDIdleTime (nanoseconds → seconds)
        2. Linux: ``xprintidle`` (milliseconds → seconds)
        3. Fallback: LastRequestTracker-based heuristic
    """

    def __init__(self, fallback_tracker: Optional[LastRequestTracker] = None) -> None:
        self._platform = platform.system()
        self._tracker = fallback_tracker or LastRequestTracker()
        self._method = self._detect_method()
        logger.debug("IdleDetector using method: %s", self._method)

    # -- public API ----------------------------------------------------------

    def idle_seconds(self) -> int:
        """Return estimated seconds the system has been idle."""
        if self._method == "ioreg":
            return self._idle_macos()
        elif self._method == "xprintidle":
            return self._idle_linux()
        else:
            return self._idle_fallback()

    def is_idle(self, threshold_minutes: int = 15) -> bool:
        """Return True if the system has been idle for at least *threshold_minutes*."""
        return self.idle_seconds() >= threshold_minutes * 60

    @property
    def tracker(self) -> LastRequestTracker:
        """Expose the underlying request tracker for external touch() calls."""
        return self._tracker

    # -- internals -----------------------------------------------------------

    def _detect_method(self) -> str:
        """Choose the best idle-detection backend for this platform."""
        if self._platform == "Darwin":
            try:
                subprocess.run(
                    ["ioreg", "-c", "IOHIDSystem"],
                    capture_output=True,
                    timeout=2,
                    check=True,
                )
                return "ioreg"
            except (FileNotFoundError, subprocess.SubprocessError):
                pass
        elif self._platform == "Linux":
            try:
                subprocess.run(
                    ["xprintidle"],
                    capture_output=True,
                    timeout=2,
                    check=True,
                )
                return "xprintidle"
            except (FileNotFoundError, subprocess.SubprocessError):
                pass
        return "fallback"

    def _idle_macos(self) -> int:
        """macOS: read HIDIdleTime from IOKit registry (nanoseconds)."""
        try:
            result = subprocess.run(
                ["ioreg", "-c", "IOHIDSystem", "-d", "4"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.splitlines():
                if "HIDIdleTime" in line:
                    # Format: "HIDIdleTime" = 1234567890
                    parts = line.split("=")
                    if len(parts) == 2:
                        ns = int(parts[1].strip())
                        return ns // 1_000_000_000
        except (subprocess.SubprocessError, ValueError, IndexError):
            logger.debug("ioreg idle read failed, falling back")
        return self._idle_fallback()

    def _idle_linux(self) -> int:
        """Linux: use xprintidle (milliseconds)."""
        try:
            result = subprocess.run(
                ["xprintidle"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            ms = int(result.stdout.strip())
            return ms // 1000
        except (subprocess.SubprocessError, ValueError):
            logger.debug("xprintidle failed, falling back")
        return self._idle_fallback()

    def _idle_fallback(self) -> int:
        """Fallback: use LastRequestTracker as idle proxy."""
        return int(self._tracker.seconds_since_last())


# ---------------------------------------------------------------------------
# Scheduler State Machine
# ---------------------------------------------------------------------------


class SchedulerState(enum.Enum):
    """State machine states for the scheduler tick loop."""

    IDLE_WAIT = "idle_wait"  # Waiting for an idle window to open
    WINDOW_OPEN = "window_open"  # Idle window detected — preparing to run
    RUNNING = "running"  # Actively executing due tasks
    PAUSING = "pausing"  # Idle window closed — draining current task


# ---------------------------------------------------------------------------
# CipherScheduler
# ---------------------------------------------------------------------------


class CipherScheduler:
    """Idle-aware background task scheduler.

    Runs prioritized tasks during detected idle windows (overnight hours
    or extended system inactivity).  Provides both async and sync entry
    points for the main loop.

    Parameters:
        idle_threshold_minutes: Minutes of inactivity before the system is
                                considered idle.
        sleep_start:            Start of overnight window (HH:MM, 24-hour).
        sleep_end:              End of overnight window (HH:MM, 24-hour).
    """

    TICK_INTERVAL: float = 30.0  # seconds between tick checks

    def __init__(
        self,
        idle_threshold_minutes: int = 15,
        sleep_start: str = "23:00",
        sleep_end: str = "07:00",
    ) -> None:
        self._idle_threshold = idle_threshold_minutes
        self._sleep_start = self._parse_time(sleep_start)
        self._sleep_end = self._parse_time(sleep_end)

        self._idle_detector = IdleDetector()
        self._state = SchedulerState.IDLE_WAIT
        self._tasks: dict[str, ScheduledTask] = {}
        self._task_lock = threading.Lock()
        self._history: list[TaskResult] = []
        self._history_lock = threading.Lock()
        self._max_history = 200
        self._running = False
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

        logger.info(
            "CipherScheduler initialised — idle=%dm, sleep=%s→%s",
            idle_threshold_minutes,
            sleep_start,
            sleep_end,
        )

    # -- task management -----------------------------------------------------

    def add_task(self, task: ScheduledTask) -> None:
        """Register a task with the scheduler."""
        with self._task_lock:
            self._tasks[task.task_id] = task
            logger.info(
                "Task added: %s [%s] prio=%s",
                task.name,
                task.task_id[:8],
                task.priority.name,
            )

    def remove_task(self, task_id: str) -> bool:
        """Remove a task by ID.  Returns True if found and removed."""
        with self._task_lock:
            if task_id in self._tasks:
                removed = self._tasks.pop(task_id)
                logger.info("Task removed: %s [%s]", removed.name, task_id[:8])
                return True
        return False

    def get_task(self, task_id: str) -> Optional[ScheduledTask]:
        """Retrieve a task by ID."""
        with self._task_lock:
            return self._tasks.get(task_id)

    # -- idle window detection -----------------------------------------------

    @staticmethod
    def _parse_time(t: str) -> tuple[int, int]:
        """Parse 'HH:MM' into (hour, minute) tuple."""
        parts = t.strip().split(":")
        return int(parts[0]), int(parts[1])

    def _in_sleep_window(self) -> bool:
        """Return True if the current local time is within the sleep window."""
        now = datetime.now()
        current_minutes = now.hour * 60 + now.minute
        start_minutes = self._sleep_start[0] * 60 + self._sleep_start[1]
        end_minutes = self._sleep_end[0] * 60 + self._sleep_end[1]

        if start_minutes <= end_minutes:
            # Same-day window (e.g., 01:00 → 05:00)
            return start_minutes <= current_minutes < end_minutes
        else:
            # Overnight window (e.g., 23:00 → 07:00)
            return current_minutes >= start_minutes or current_minutes < end_minutes

    def _is_idle_window(self) -> bool:
        """Return True if conditions are right for background work.

        Either we're in the configured sleep window OR the system has been
        idle long enough AND there have been no recent operator requests.
        """
        if self._in_sleep_window():
            return True
        if self._idle_detector.is_idle(self._idle_threshold):
            tracker_idle = self._idle_detector.tracker.seconds_since_last()
            return tracker_idle >= self._idle_threshold * 60
        return False

    # -- state machine -------------------------------------------------------

    def _tick(self) -> None:
        """Single iteration of the scheduler state machine.

        State transitions:
            IDLE_WAIT   → WINDOW_OPEN   (when idle window opens)
            WINDOW_OPEN → RUNNING       (immediate — begin executing tasks)
            RUNNING     → PAUSING       (when idle window closes)
            PAUSING     → IDLE_WAIT     (after draining current task)
            RUNNING     → IDLE_WAIT     (no more due tasks)
        """
        idle_now = self._is_idle_window()

        if self._state == SchedulerState.IDLE_WAIT:
            if idle_now:
                logger.info("Idle window opened — transitioning to WINDOW_OPEN")
                self._state = SchedulerState.WINDOW_OPEN

        elif self._state == SchedulerState.WINDOW_OPEN:
            self._state = SchedulerState.RUNNING
            logger.info("Window open — entering RUNNING state")
            self._execute_due_tasks()
            # After executing, check if we should continue
            if not idle_now:
                self._state = SchedulerState.PAUSING
            elif not self._has_due_tasks():
                logger.debug("No more due tasks — returning to IDLE_WAIT")
                self._state = SchedulerState.IDLE_WAIT

        elif self._state == SchedulerState.RUNNING:
            if not idle_now:
                logger.info("Idle window closed — transitioning to PAUSING")
                self._state = SchedulerState.PAUSING
            elif self._has_due_tasks():
                self._execute_due_tasks()
            else:
                logger.debug("No due tasks remaining — back to IDLE_WAIT")
                self._state = SchedulerState.IDLE_WAIT

        elif self._state == SchedulerState.PAUSING:
            logger.info("Pause complete — back to IDLE_WAIT")
            self._state = SchedulerState.IDLE_WAIT

    # -- task execution ------------------------------------------------------

    def _has_due_tasks(self) -> bool:
        """Return True if any enabled task is due."""
        now = time.time()
        with self._task_lock:
            return any(t.is_due(now) for t in self._tasks.values())

    def _get_due_tasks_sorted(self) -> list[ScheduledTask]:
        """Return due tasks sorted by priority (lowest value first)."""
        now = time.time()
        with self._task_lock:
            due = [t for t in self._tasks.values() if t.is_due(now)]
        due.sort(key=lambda t: (t.priority.value, t.next_run))
        return due

    def _execute_due_tasks(self) -> None:
        """Execute all due tasks in priority order."""
        due_tasks = self._get_due_tasks_sorted()
        if not due_tasks:
            return

        logger.info("Executing %d due task(s)", len(due_tasks))
        for task in due_tasks:
            if self._stop_event.is_set():
                break
            # Re-check idle for tasks that require it
            if task.requires_idle and not self._is_idle_window():
                logger.info("Idle window closed — skipping %s", task.name)
                break
            self._run_single_task(task)

    def _run_single_task(self, task: ScheduledTask) -> TaskResult:
        """Execute a single task and record the result."""
        started = time.time()
        logger.info("Running task: %s [%s]", task.name, task.task_id[:8])

        try:
            result_value = task.callable_fn(*task.args, **task.kwargs)
            finished = time.time()
            task.record_run(finished)
            result = TaskResult(
                task_id=task.task_id,
                task_name=task.name,
                started_at=started,
                finished_at=finished,
                success=True,
                result=result_value,
            )
            logger.info(
                "Task %s completed in %.1fms",
                task.name,
                result.duration_ms,
            )
        except Exception as exc:
            finished = time.time()
            task.record_run(finished)
            result = TaskResult(
                task_id=task.task_id,
                task_name=task.name,
                started_at=started,
                finished_at=finished,
                success=False,
                error=f"{type(exc).__name__}: {exc}",
            )
            logger.warning(
                "Task %s failed after %.1fms: %s",
                task.name,
                result.duration_ms,
                result.error,
            )

        self._record_history(result)
        return result

    def _record_history(self, result: TaskResult) -> None:
        """Append result to history, trimming to max size."""
        with self._history_lock:
            self._history.append(result)
            if len(self._history) > self._max_history:
                self._history = self._history[-self._max_history :]

    # -- main loops ----------------------------------------------------------

    async def run_async(self) -> None:
        """Async main loop — ticks every TICK_INTERVAL seconds."""
        self._running = True
        self._stop_event.clear()
        logger.info("Scheduler async loop started")

        try:
            while not self._stop_event.is_set():
                self._tick()
                try:
                    await asyncio.wait_for(
                        asyncio.get_event_loop().run_in_executor(
                            None, self._stop_event.wait, self.TICK_INTERVAL
                        ),
                        timeout=self.TICK_INTERVAL,
                    )
                except asyncio.TimeoutError:
                    pass
        finally:
            self._running = False
            logger.info("Scheduler async loop stopped")

    def run_sync(self) -> None:
        """Synchronous main loop — runs in a background daemon thread."""
        if self._thread and self._thread.is_alive():
            logger.warning("Scheduler already running")
            return

        self._stop_event.clear()

        def _loop() -> None:
            self._running = True
            logger.info("Scheduler sync loop started (thread)")
            try:
                while not self._stop_event.is_set():
                    self._tick()
                    self._stop_event.wait(timeout=self.TICK_INTERVAL)
            finally:
                self._running = False
                logger.info("Scheduler sync loop stopped")

        self._thread = threading.Thread(
            target=_loop,
            name="cipher-scheduler",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        """Signal the scheduler to stop."""
        logger.info("Scheduler stop requested")
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=10)
            self._thread = None
        self._running = False

    # -- status & introspection ----------------------------------------------

    def get_status(self) -> dict[str, Any]:
        """Return current scheduler status snapshot."""
        now = time.time()
        with self._task_lock:
            task_summaries = [
                {
                    "task_id": t.task_id,
                    "name": t.name,
                    "type": t.task_type,
                    "priority": t.priority.name,
                    "enabled": t.enabled,
                    "run_count": t.run_count,
                    "is_due": t.is_due(now),
                    "next_run_in": max(0, t.next_run - now) if t.next_run > 0 else 0,
                    "requires_idle": t.requires_idle,
                }
                for t in self._tasks.values()
            ]
        return {
            "state": self._state.value,
            "running": self._running,
            "idle_threshold_minutes": self._idle_threshold,
            "sleep_window": f"{self._sleep_start[0]:02d}:{self._sleep_start[1]:02d}"
            f"→{self._sleep_end[0]:02d}:{self._sleep_end[1]:02d}",
            "is_idle_window": self._is_idle_window(),
            "system_idle_seconds": self._idle_detector.idle_seconds(),
            "tasks_total": len(task_summaries),
            "tasks_due": sum(1 for t in task_summaries if t["is_due"]),
            "tasks": task_summaries,
            "history_size": len(self._history),
        }

    def get_task_history(self, limit: int = 50) -> list[dict[str, Any]]:
        """Return recent task execution results."""
        with self._history_lock:
            recent = self._history[-limit:]
        return [
            {
                "task_id": r.task_id,
                "task_name": r.task_name,
                "started_at": datetime.fromtimestamp(
                    r.started_at, tz=timezone.utc
                ).isoformat(),
                "duration_ms": round(r.duration_ms, 2),
                "success": r.success,
                "error": r.error,
            }
            for r in recent
        ]

    @property
    def idle_detector(self) -> IdleDetector:
        """Expose the idle detector for external touch() calls."""
        return self._idle_detector

    @property
    def state(self) -> SchedulerState:
        """Current scheduler state."""
        return self._state


# ---------------------------------------------------------------------------
# Default Tasks Factory
# ---------------------------------------------------------------------------


def _noop_memory_consolidation() -> str:
    """Placeholder: consolidate and deduplicate recent memory entries."""
    logger.debug("memory_consolidation: scanning for merge candidates")
    return "memory_consolidation: complete"


def _noop_skill_metric_update() -> str:
    """Placeholder: recalculate skill proficiency metrics."""
    logger.debug("skill_metric_update: recalculating scores")
    return "skill_metric_update: complete"


def _noop_memory_decay() -> str:
    """Placeholder: apply time-decay to low-confidence memories."""
    logger.debug("memory_decay: applying decay curve")
    return "memory_decay: complete"


def _noop_stale_engagement_cleanup() -> str:
    """Placeholder: archive or remove stale engagement contexts."""
    logger.debug("stale_engagement_cleanup: scanning engagements")
    return "stale_engagement_cleanup: complete"


def create_default_tasks() -> list[ScheduledTask]:
    """Create the standard set of background self-improvement tasks.

    Returns four recurring tasks with sensible defaults:
        1. memory_consolidation   — every 1 hour,   MEDIUM priority
        2. skill_metric_update    — every 30 min,    LOW priority
        3. memory_decay           — every 6 hours,   BACKGROUND priority
        4. stale_engagement_cleanup — every 24 hours, BACKGROUND priority
    """
    now = time.time()

    return [
        ScheduledTask(
            name="memory_consolidation",
            task_type="memory_consolidation",
            priority=TaskPriority.MEDIUM,
            callable_fn=_noop_memory_consolidation,
            interval_seconds=3600,  # 1 hour
            next_run=now + 3600,
        ),
        ScheduledTask(
            name="skill_metric_update",
            task_type="metric_update",
            priority=TaskPriority.LOW,
            callable_fn=_noop_skill_metric_update,
            interval_seconds=1800,  # 30 minutes
            next_run=now + 1800,
        ),
        ScheduledTask(
            name="memory_decay",
            task_type="memory_consolidation",
            priority=TaskPriority.BACKGROUND,
            callable_fn=_noop_memory_decay,
            interval_seconds=21600,  # 6 hours
            next_run=now + 21600,
        ),
        ScheduledTask(
            name="stale_engagement_cleanup",
            task_type="memory_consolidation",
            priority=TaskPriority.BACKGROUND,
            callable_fn=_noop_stale_engagement_cleanup,
            interval_seconds=86400,  # 24 hours
            next_run=now + 86400,
        ),
    ]
