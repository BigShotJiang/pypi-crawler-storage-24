# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0

"""Skill effectiveness tracking and metrics system.

SQLite-backed leaderboard that records skill invocations, computes
performance trends, and surfaces domain-level coverage insights.
"""

from __future__ import annotations

import json
import math
import sqlite3
import statistics
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class SkillMetric:
    """Per-skill performance snapshot."""

    skill_path: str
    domain: str
    technique: str
    invocation_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    avg_score: float = 0.0
    last_used: str = ""
    last_score: float = 0.0
    trend: str = ""
    scores_history: list[float] = field(default_factory=list)


@dataclass
class DomainMetric:
    """Aggregate metrics for a security domain."""

    domain: str
    technique_count: int
    total_invocations: int
    avg_success_rate: float
    avg_score: float
    coverage_score: float  # 0-1, based on MITRE coverage
    strongest_technique: str
    weakest_technique: str


@dataclass
class LeaderboardEntry:
    """Single ranked row in the leaderboard."""

    rank: int
    skill_path: str
    domain: str
    score: float
    invocations: int
    success_rate: float
    trend: str


# ---------------------------------------------------------------------------
# MITRE ATT&CK reference counts per domain (used for coverage scoring)
# ---------------------------------------------------------------------------

_MITRE_TECHNIQUE_COUNTS: dict[str, int] = {
    "initial-access": 10,
    "execution": 14,
    "persistence": 20,
    "privilege-escalation": 14,
    "defense-evasion": 43,
    "credential-access": 17,
    "discovery": 32,
    "lateral-movement": 9,
    "collection": 17,
    "command-and-control": 16,
    "exfiltration": 9,
    "impact": 14,
    "reconnaissance": 10,
    "resource-development": 8,
}


# ---------------------------------------------------------------------------
# SkillLeaderboard
# ---------------------------------------------------------------------------


class SkillLeaderboard:
    """SQLite-backed skill effectiveness tracker."""

    def __init__(self, db_path: str = "~/.cipher/leaderboard.db") -> None:
        resolved = Path(db_path).expanduser()
        resolved.parent.mkdir(parents=True, exist_ok=True)
        self._db_path = str(resolved)
        self._conn = sqlite3.connect(self._db_path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_db()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Create SQLite tables if they don't exist."""
        cur = self._conn.cursor()
        cur.executescript("""
            CREATE TABLE IF NOT EXISTS skill_metrics (
                skill_path    TEXT PRIMARY KEY,
                domain        TEXT NOT NULL,
                technique     TEXT NOT NULL DEFAULT '',
                invocation_count INTEGER NOT NULL DEFAULT 0,
                success_count INTEGER NOT NULL DEFAULT 0,
                failure_count INTEGER NOT NULL DEFAULT 0,
                avg_score     REAL NOT NULL DEFAULT 0.0,
                last_used     TEXT NOT NULL DEFAULT '',
                last_score    REAL NOT NULL DEFAULT 0.0,
                trend         TEXT NOT NULL DEFAULT '',
                scores_history TEXT NOT NULL DEFAULT '[]'
            );

            CREATE TABLE IF NOT EXISTS invocation_log (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_path TEXT NOT NULL,
                timestamp  TEXT NOT NULL,
                success    INTEGER NOT NULL,
                score      REAL NOT NULL,
                context    TEXT NOT NULL DEFAULT '{}'
            );

            CREATE TABLE IF NOT EXISTS domain_metrics (
                domain              TEXT PRIMARY KEY,
                technique_count     INTEGER NOT NULL DEFAULT 0,
                total_invocations   INTEGER NOT NULL DEFAULT 0,
                avg_success_rate    REAL NOT NULL DEFAULT 0.0,
                avg_score           REAL NOT NULL DEFAULT 0.0,
                coverage_score      REAL NOT NULL DEFAULT 0.0,
                strongest_technique TEXT NOT NULL DEFAULT '',
                weakest_technique   TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS idx_invlog_skill
                ON invocation_log(skill_path);
            CREATE INDEX IF NOT EXISTS idx_invlog_ts
                ON invocation_log(timestamp);
            CREATE INDEX IF NOT EXISTS idx_skill_domain
                ON skill_metrics(domain);
        """)
        self._conn.commit()

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record_invocation(
        self,
        skill_path: str,
        success: bool,
        score: float,
        context: Optional[dict] = None,
    ) -> None:
        """Record a single skill invocation and update aggregates."""
        now = datetime.now(timezone.utc).isoformat()
        ctx_json = json.dumps(context or {})

        # Parse domain / technique from skill_path (e.g. "red/privesc/sudo")
        parts = skill_path.strip("/").split("/")
        domain = parts[0] if parts else "unknown"
        technique = parts[-1] if len(parts) > 1 else ""

        # Sanitize score — reject NaN/Inf
        if math.isnan(score) or math.isinf(score):
            score = 0.0

        cur = self._conn.cursor()

        # Insert invocation log
        cur.execute(
            "INSERT INTO invocation_log (skill_path, timestamp, success, score, context) "
            "VALUES (?, ?, ?, ?, ?)",
            (skill_path, now, int(success), score, ctx_json),
        )

        # Upsert skill_metrics
        row = cur.execute(
            "SELECT * FROM skill_metrics WHERE skill_path = ?", (skill_path,)
        ).fetchone()

        if row is None:
            history = [score]
            cur.execute(
                "INSERT INTO skill_metrics "
                "(skill_path, domain, technique, invocation_count, success_count, "
                "failure_count, avg_score, last_used, last_score, trend, scores_history) "
                'VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, "", ?)',
                (
                    skill_path,
                    domain,
                    technique,
                    int(success),
                    int(not success),
                    score,
                    now,
                    score,
                    json.dumps(history),
                ),
            )
        else:
            inv = row["invocation_count"] + 1
            sc = row["success_count"] + int(success)
            fc = row["failure_count"] + int(not success)
            prev_history: list[float] = json.loads(row["scores_history"])
            prev_history.append(score)
            # Keep last 100 scores
            if len(prev_history) > 100:
                prev_history = prev_history[-100:]
            avg = statistics.mean(prev_history)
            cur.execute(
                "UPDATE skill_metrics SET "
                "invocation_count = ?, success_count = ?, failure_count = ?, "
                "avg_score = ?, last_used = ?, last_score = ?, scores_history = ? "
                "WHERE skill_path = ?",
                (inv, sc, fc, avg, now, score, json.dumps(prev_history), skill_path),
            )

        self._conn.commit()
        self._update_domain_aggregates(domain)

    # ------------------------------------------------------------------
    # Queries — single skill
    # ------------------------------------------------------------------

    def get_skill_metric(self, skill_path: str) -> SkillMetric:
        """Return the metric snapshot for a single skill."""
        row = self._conn.execute(
            "SELECT * FROM skill_metrics WHERE skill_path = ?", (skill_path,)
        ).fetchone()
        if row is None:
            parts = skill_path.strip("/").split("/")
            return SkillMetric(
                skill_path=skill_path,
                domain=parts[0] if parts else "unknown",
                technique=parts[-1] if len(parts) > 1 else "",
            )
        return SkillMetric(
            skill_path=row["skill_path"],
            domain=row["domain"],
            technique=row["technique"],
            invocation_count=row["invocation_count"],
            success_count=row["success_count"],
            failure_count=row["failure_count"],
            avg_score=row["avg_score"],
            last_used=row["last_used"],
            last_score=row["last_score"],
            trend=row["trend"],
            scores_history=json.loads(row["scores_history"]),
        )

    # ------------------------------------------------------------------
    # Queries — domain
    # ------------------------------------------------------------------

    def get_domain_metrics(self, domain: str) -> DomainMetric:
        """Return aggregate metrics for a security domain."""
        row = self._conn.execute(
            "SELECT * FROM domain_metrics WHERE domain = ?", (domain,)
        ).fetchone()
        if row is None:
            return DomainMetric(
                domain=domain,
                technique_count=0,
                total_invocations=0,
                avg_success_rate=0.0,
                avg_score=0.0,
                coverage_score=0.0,
                strongest_technique="",
                weakest_technique="",
            )
        return DomainMetric(
            domain=row["domain"],
            technique_count=row["technique_count"],
            total_invocations=row["total_invocations"],
            avg_success_rate=row["avg_success_rate"],
            avg_score=row["avg_score"],
            coverage_score=row["coverage_score"],
            strongest_technique=row["strongest_technique"],
            weakest_technique=row["weakest_technique"],
        )

    # ------------------------------------------------------------------
    # Leaderboard queries
    # ------------------------------------------------------------------

    def _rows_to_entries(
        self, rows: list[sqlite3.Row], start_rank: int = 1
    ) -> list[LeaderboardEntry]:
        entries: list[LeaderboardEntry] = []
        for i, r in enumerate(rows):
            inv = r["invocation_count"] or 1
            rate = r["success_count"] / inv
            entries.append(
                LeaderboardEntry(
                    rank=start_rank + i,
                    skill_path=r["skill_path"],
                    domain=r["domain"],
                    score=r["avg_score"],
                    invocations=r["invocation_count"],
                    success_rate=round(rate, 4),
                    trend=r["trend"],
                )
            )
        return entries

    def get_top_skills(
        self, n: int = 20, domain: Optional[str] = None
    ) -> list[LeaderboardEntry]:
        """Return the top-N skills by avg_score."""
        if domain:
            rows = self._conn.execute(
                "SELECT * FROM skill_metrics WHERE domain = ? "
                "ORDER BY avg_score DESC LIMIT ?",
                (domain, n),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM skill_metrics ORDER BY avg_score DESC LIMIT ?",
                (n,),
            ).fetchall()
        return self._rows_to_entries(rows)

    def get_bottom_skills(
        self, n: int = 20, domain: Optional[str] = None
    ) -> list[LeaderboardEntry]:
        """Return the bottom-N skills by avg_score."""
        if domain:
            rows = self._conn.execute(
                "SELECT * FROM skill_metrics WHERE domain = ? "
                "ORDER BY avg_score ASC LIMIT ?",
                (domain, n),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM skill_metrics ORDER BY avg_score ASC LIMIT ?",
                (n,),
            ).fetchall()
        return self._rows_to_entries(rows)

    def get_trending(
        self, direction: str = "up", n: int = 10
    ) -> list[LeaderboardEntry]:
        """Return skills trending in the given direction."""
        trend_val = "improving" if direction == "up" else "declining"
        rows = self._conn.execute(
            "SELECT * FROM skill_metrics WHERE trend = ? "
            "ORDER BY avg_score DESC LIMIT ?",
            (trend_val, n),
        ).fetchall()
        return self._rows_to_entries(rows)

    def get_unused_skills(self, days: int = 30) -> list[str]:
        """Return skill paths not invoked within the last N days."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        rows = self._conn.execute(
            "SELECT skill_path FROM skill_metrics "
            "WHERE last_used < ? OR last_used = ''",
            (cutoff,),
        ).fetchall()
        return [r["skill_path"] for r in rows]

    # ------------------------------------------------------------------
    # Trend computation
    # ------------------------------------------------------------------

    @staticmethod
    def _calculate_trend(scores: list[float]) -> str:
        """Determine trend via linear regression slope."""
        if len(scores) < 3:
            return "stable"
        n = len(scores)
        x_mean = (n - 1) / 2.0
        y_mean = statistics.mean(scores)
        numerator = sum((i - x_mean) * (s - y_mean) for i, s in enumerate(scores))
        denominator = sum((i - x_mean) ** 2 for i in range(n))
        if denominator == 0:
            return "stable"
        slope = numerator / denominator
        if slope > 0.02:
            return "improving"
        elif slope < -0.02:
            return "declining"
        return "stable"

    def compute_trends(self, window: int = 10) -> None:
        """Recompute trend field for all skills based on recent scores."""
        rows = self._conn.execute(
            "SELECT skill_path, scores_history FROM skill_metrics"
        ).fetchall()
        for r in rows:
            history: list[float] = json.loads(r["scores_history"])
            recent = history[-window:] if len(history) > window else history
            trend = self._calculate_trend(recent)
            self._conn.execute(
                "UPDATE skill_metrics SET trend = ? WHERE skill_path = ?",
                (trend, r["skill_path"]),
            )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Domain aggregation
    # ------------------------------------------------------------------

    def _update_domain_aggregates(self, domain: str) -> None:
        """Recalculate DomainMetric from skill data."""
        rows = self._conn.execute(
            "SELECT * FROM skill_metrics WHERE domain = ?", (domain,)
        ).fetchall()

        if not rows:
            self._conn.execute("DELETE FROM domain_metrics WHERE domain = ?", (domain,))
            self._conn.commit()
            return

        technique_count = len(rows)
        total_inv = sum(r["invocation_count"] for r in rows)
        total_success = sum(r["success_count"] for r in rows)
        avg_success_rate = total_success / total_inv if total_inv > 0 else 0.0
        scores = [r["avg_score"] for r in rows if not math.isnan(r["avg_score"])]
        avg_score = statistics.mean(scores) if scores else 0.0

        # Coverage: ratio of unique techniques vs MITRE reference count
        mitre_total = _MITRE_TECHNIQUE_COUNTS.get(domain, 0)
        coverage = technique_count / mitre_total if mitre_total > 0 else 0.0
        coverage = min(coverage, 1.0)

        best = max(rows, key=lambda r: r["avg_score"])
        worst = min(rows, key=lambda r: r["avg_score"])

        self._conn.execute(
            "INSERT INTO domain_metrics "
            "(domain, technique_count, total_invocations, avg_success_rate, "
            "avg_score, coverage_score, strongest_technique, weakest_technique) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(domain) DO UPDATE SET "
            "technique_count = excluded.technique_count, "
            "total_invocations = excluded.total_invocations, "
            "avg_success_rate = excluded.avg_success_rate, "
            "avg_score = excluded.avg_score, "
            "coverage_score = excluded.coverage_score, "
            "strongest_technique = excluded.strongest_technique, "
            "weakest_technique = excluded.weakest_technique",
            (
                domain,
                technique_count,
                total_inv,
                round(avg_success_rate, 4),
                round(avg_score, 4),
                round(coverage, 4),
                best["technique"],
                worst["technique"],
            ),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Dashboard & reporting
    # ------------------------------------------------------------------

    def get_dashboard(self) -> dict:
        """Return comprehensive stats for the leaderboard dashboard."""
        skills = self._conn.execute("SELECT * FROM skill_metrics").fetchall()
        domains = self._conn.execute(
            "SELECT * FROM domain_metrics ORDER BY avg_score DESC"
        ).fetchall()

        total = len(skills)
        if total == 0:
            return {
                "total_skills": 0,
                "avg_score": 0.0,
                "total_invocations": 0,
                "top_domains": [],
                "worst_domains": [],
                "unused_count": 0,
                "trend_summary": {"improving": 0, "stable": 0, "declining": 0},
            }

        avg_score = statistics.mean(r["avg_score"] for r in skills)
        total_inv = sum(r["invocation_count"] for r in skills)
        unused = len(self.get_unused_skills(days=30))

        trend_counts = {"improving": 0, "stable": 0, "declining": 0}
        for r in skills:
            t = r["trend"] if r["trend"] in trend_counts else "stable"
            trend_counts[t] += 1

        top_domains = [
            {
                "domain": d["domain"],
                "avg_score": d["avg_score"],
                "coverage": d["coverage_score"],
            }
            for d in domains[:5]
        ]
        worst_domains = [
            {
                "domain": d["domain"],
                "avg_score": d["avg_score"],
                "coverage": d["coverage_score"],
            }
            for d in reversed(domains[-5:])
            if domains
        ]

        return {
            "total_skills": total,
            "avg_score": round(avg_score, 4),
            "total_invocations": total_inv,
            "top_domains": top_domains,
            "worst_domains": worst_domains,
            "unused_count": unused,
            "trend_summary": trend_counts,
        }

    def export_report(self, format: str = "json") -> str:
        """Export the full leaderboard as JSON."""
        skills = self._conn.execute(
            "SELECT * FROM skill_metrics ORDER BY avg_score DESC"
        ).fetchall()

        entries: list[dict] = []
        for i, r in enumerate(skills):
            inv = r["invocation_count"] or 1
            entries.append(
                {
                    "rank": i + 1,
                    "skill_path": r["skill_path"],
                    "domain": r["domain"],
                    "technique": r["technique"],
                    "invocation_count": r["invocation_count"],
                    "success_count": r["success_count"],
                    "failure_count": r["failure_count"],
                    "avg_score": r["avg_score"],
                    "last_used": r["last_used"],
                    "last_score": r["last_score"],
                    "trend": r["trend"],
                    "success_rate": round(r["success_count"] / inv, 4),
                }
            )

        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_skills": len(entries),
            "dashboard": self.get_dashboard(),
            "skills": entries,
        }
        return json.dumps(report, indent=2)

    # ------------------------------------------------------------------
    # ACE-style Online Adaptation
    # ------------------------------------------------------------------

    def decayed_score(
        self, skill_path: str, decay_factor: float = 0.95, window: int = 50
    ) -> float:
        """Compute exponentially-decayed score — recent invocations weight more.

        Uses EWA (Exponential Weighted Average) over the last `window` scores.
        decay_factor=0.95 means each older score is 5% less influential.
        """
        row = self._conn.execute(
            "SELECT scores_history FROM skill_metrics WHERE skill_path = ?",
            (skill_path,),
        ).fetchone()
        if row is None:
            return 0.0
        history: list[float] = json.loads(row["scores_history"])
        if not history:
            return 0.0
        recent = history[-window:]
        # EWA: weight_i = decay^(n-1-i), most recent = decay^0 = 1.0
        n = len(recent)
        weights = [decay_factor ** (n - 1 - i) for i in range(n)]
        total_weight = sum(weights)
        if total_weight == 0:
            return 0.0
        return sum(w * s for w, s in zip(weights, recent)) / total_weight

    def recommend_skill(self, domain: str, n: int = 3) -> list[dict]:
        """Recommend top-N skills for a domain using decayed scores.

        Returns skills ranked by recency-weighted effectiveness — the ACE
        online adaptation pattern. Skills that are trending up rank higher
        than historically good but declining skills.
        """
        rows = self._conn.execute(
            "SELECT skill_path, scores_history, invocation_count, trend "
            "FROM skill_metrics WHERE domain = ? AND invocation_count > 0",
            (domain,),
        ).fetchall()

        if not rows:
            return []

        scored: list[tuple[float, sqlite3.Row]] = []
        for r in rows:
            history: list[float] = json.loads(r["scores_history"])
            if not history:
                continue
            recent = history[-50:]
            n_hist = len(recent)
            weights = [0.95 ** (n_hist - 1 - i) for i in range(n_hist)]
            tw = sum(weights)
            ewa = sum(w * s for w, s in zip(weights, recent)) / tw if tw else 0.0

            # Trend bonus: +5% for improving, -5% for declining
            trend = r["trend"]
            if trend == "improving":
                ewa *= 1.05
            elif trend == "declining":
                ewa *= 0.95

            scored.append((ewa, r))

        scored.sort(key=lambda x: x[0], reverse=True)
        results: list[dict] = []
        for ewa_score, r in scored[:n]:
            results.append(
                {
                    "skill_path": r["skill_path"],
                    "decayed_score": round(ewa_score, 4),
                    "invocations": r["invocation_count"],
                    "trend": r["trend"],
                }
            )
        return results

    def apply_score_decay(self, half_life_days: int = 30) -> int:
        """Apply time-based score decay to all skills.

        Skills that haven't been invoked recently get their avg_score
        pulled toward the mean. half_life_days controls how fast.
        Returns count of skills adjusted.
        """
        import math

        now = datetime.now(timezone.utc)
        rows = self._conn.execute(
            "SELECT skill_path, avg_score, last_used FROM skill_metrics "
            'WHERE last_used != ""'
        ).fetchall()

        global_avg = (
            self._conn.execute(
                "SELECT AVG(avg_score) FROM skill_metrics WHERE invocation_count > 0"
            ).fetchone()[0]
            or 0.5
        )

        adjusted = 0
        for r in rows:
            try:
                last = datetime.fromisoformat(r["last_used"])
            except (ValueError, TypeError):
                continue
            days_ago = (now - last).total_seconds() / 86400
            if days_ago < 1:
                continue  # Used recently, no decay
            # Exponential decay toward mean
            decay = math.exp(-0.693 * days_ago / half_life_days)  # ln(2) ≈ 0.693
            new_score = decay * r["avg_score"] + (1 - decay) * global_avg
            if abs(new_score - r["avg_score"]) > 0.001:
                self._conn.execute(
                    "UPDATE skill_metrics SET avg_score = ? WHERE skill_path = ?",
                    (round(new_score, 4), r["skill_path"]),
                )
                adjusted += 1

        if adjusted:
            self._conn.commit()
        return adjusted

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()
