# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER Autonomous Operation — Self-improving security platform.

Phase 4 modules:
- scheduler: Idle-aware background task scheduler
- researcher: Autonomous skill generation and gap analysis
- parallel: Multi-worker concurrent execution engine
- leaderboard: Skill effectiveness tracking and metrics
"""

from autonomous.scheduler import (
    CipherScheduler,
    IdleDetector,
    LastRequestTracker,
    ScheduledTask,
    SchedulerState,
    TaskPriority,
    create_default_tasks,
)
from autonomous.researcher import (
    AutonomousResearcher,
    ResearchExperiment,
    ResearchHypothesis,
    SkillGapAnalyzer,
)
from autonomous.parallel import (
    AgentTask,
    AgentResult,
    WorkerPool,
    ParallelScanner,
    ParallelAnalyzer,
    TaskOrchestrator,
)
from autonomous.leaderboard import (
    SkillLeaderboard,
    SkillMetric,
    DomainMetric,
    LeaderboardEntry,
)

__all__ = [
    # Scheduler
    "CipherScheduler",
    "IdleDetector",
    "LastRequestTracker",
    "ScheduledTask",
    "SchedulerState",
    "TaskPriority",
    "create_default_tasks",
    # Researcher
    "AutonomousResearcher",
    "ResearchExperiment",
    "ResearchHypothesis",
    "SkillGapAnalyzer",
    # Parallel
    "AgentTask",
    "AgentResult",
    "WorkerPool",
    "ParallelScanner",
    "ParallelAnalyzer",
    "TaskOrchestrator",
    # Leaderboard
    "SkillLeaderboard",
    "SkillMetric",
    "DomainMetric",
    "LeaderboardEntry",
]
