# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER — Claude Integrated Privacy & Hardening Expert Resource."""

__version__ = "4.0.0"
