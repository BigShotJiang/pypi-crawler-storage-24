# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Memory — Tri-Stage Pipeline + Evolution Engine

Stage 1: SemanticCompressor — Dialogue → atomic memory entries
Stage 2: SemanticSynthesizer — Dedup, merge, link related entries
Stage 3: AdaptiveRetriever — Intent-aware search with RRF fusion
Evolution: ResponseScorer + SkillEvolver — Learn from failures

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from memory.core.engine import (
    CipherMemory,
    MemoryEntry,
    MemoryType,
    Confidence,
)
from memory.core.orchestrator import (
    CipherOrchestrator,
    create_orchestrator,
)

__all__ = [
    # Core
    "CipherMemory",
    "MemoryEntry",
    "MemoryType",
    "Confidence",
    # Orchestrator
    "CipherOrchestrator",
    "create_orchestrator",
]
