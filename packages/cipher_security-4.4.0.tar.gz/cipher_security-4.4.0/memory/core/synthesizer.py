# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Memory — Stage 2: Online Semantic Synthesis

Performs intra-session consolidation of memory entries:
- Detects near-duplicate and semantically related entries
- Merges related entries into unified abstract representations
- Maintains compact, coherent memory topology
- Eliminates redundancy while preserving information

Inspired by SimpleMem's Stage 2 (Online Semantic Synthesis).

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from __future__ import annotations

import hashlib
import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from .compressor import CompressedEntry

logger = logging.getLogger(__name__)


def _trigram_set(text: str) -> set[str]:
    """Generate word trigrams for similarity comparison."""
    words = text.lower().split()
    if len(words) < 3:
        return set(words)
    return {" ".join(words[i : i + 3]) for i in range(len(words) - 2)}


def _jaccard_similarity(a: str, b: str) -> float:
    """Jaccard similarity on word trigrams."""
    tg_a = _trigram_set(a)
    tg_b = _trigram_set(b)
    if not tg_a or not tg_b:
        return 0.0
    intersection = tg_a & tg_b
    union = tg_a | tg_b
    return len(intersection) / len(union) if union else 0.0


def _content_fingerprint(text: str) -> str:
    """Generate fingerprint for near-duplicate detection."""
    # Normalize: lowercase, collapse whitespace, remove punctuation
    normalized = re.sub(r"[^\w\s]", "", text.lower())
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return hashlib.md5(normalized.encode(), usedforsecurity=False).hexdigest()[:16]  # nosec B324


@dataclass
class SynthesisResult:
    """Result of a synthesis operation."""

    merged_entries: list[CompressedEntry]
    removed_entry_ids: list[str]
    new_entries: list[CompressedEntry]
    stats: dict[str, int] = field(default_factory=dict)


class SemanticSynthesizer:
    """
    Stage 2: Online Semantic Synthesis.

    Consolidates memory entries during the session to maintain a compact,
    coherent topology. Three operations:

    1. **Deduplication** — Remove near-identical entries (fingerprint match)
    2. **Merging** — Combine highly similar entries (Jaccard > threshold)
    3. **Linking** — Connect related entries via shared entities/topics

    All operations are local (no LLM required) for low latency.
    """

    def __init__(
        self,
        merge_threshold: float = 0.7,
        dedup_threshold: float = 0.95,
    ):
        self.merge_threshold = merge_threshold
        self.dedup_threshold = dedup_threshold
        self._fingerprints: dict[str, str] = {}  # fingerprint → entry_id

    def synthesize(
        self,
        new_entries: list[CompressedEntry],
        existing_entries: list[CompressedEntry],
    ) -> SynthesisResult:
        """
        Synthesize new entries with existing memory.

        Args:
            new_entries: Freshly compressed entries from Stage 1
            existing_entries: Current entries in the memory store

        Returns:
            SynthesisResult with merged, removed, and new entries
        """
        # Build fingerprint index for existing entries
        for entry in existing_entries:
            fp = _content_fingerprint(entry.lossless_restatement)
            self._fingerprints[fp] = entry.entry_id

        merged: list[CompressedEntry] = []
        removed_ids: list[str] = []
        truly_new: list[CompressedEntry] = []

        stats = {"deduplicated": 0, "merged": 0, "linked": 0, "new": 0}

        for new_entry in new_entries:
            fp = _content_fingerprint(new_entry.lossless_restatement)

            # Step 1: Exact deduplication
            if fp in self._fingerprints:
                stats["deduplicated"] += 1
                logger.debug(
                    "Dedup: %s matches existing %s",
                    new_entry.entry_id[:8],
                    self._fingerprints[fp][:8],
                )
                continue

            # Step 2: Find merge candidates
            best_match: Optional[CompressedEntry] = None
            best_sim = 0.0

            for existing in existing_entries:
                if existing.entry_id in removed_ids:
                    continue

                sim = _jaccard_similarity(
                    new_entry.lossless_restatement,
                    existing.lossless_restatement,
                )
                if sim > best_sim:
                    best_sim = sim
                    best_match = existing

            if best_match and best_sim >= self.merge_threshold:
                # Merge: keep the richer entry, absorb metadata
                merged_entry = self._merge_entries(best_match, new_entry)
                merged.append(merged_entry)
                stats["merged"] += 1
                logger.debug(
                    "Merged: %s + %s (sim=%.2f)",
                    best_match.entry_id[:8],
                    new_entry.entry_id[:8],
                    best_sim,
                )
            else:
                # Step 3: Link to related entries via shared entities
                linked = self._link_entry(new_entry, existing_entries)
                if linked:
                    stats["linked"] += 1

                truly_new.append(new_entry)
                self._fingerprints[fp] = new_entry.entry_id
                stats["new"] += 1

        stats_summary = (
            f"dedup={stats['deduplicated']} merged={stats['merged']} "
            f"linked={stats['linked']} new={stats['new']}"
        )
        logger.info("Synthesis complete: %s", stats_summary)

        return SynthesisResult(
            merged_entries=merged,
            removed_entry_ids=removed_ids,
            new_entries=truly_new,
            stats=stats,
        )

    def _merge_entries(
        self,
        existing: CompressedEntry,
        new: CompressedEntry,
    ) -> CompressedEntry:
        """Merge two similar entries, keeping the richer content."""
        # Keep the longer/richer restatement
        if len(new.lossless_restatement) > len(existing.lossless_restatement):
            existing.lossless_restatement = new.lossless_restatement

        # Union all list fields
        existing.targets = list(set(existing.targets + new.targets))
        existing.cve_ids = list(set(existing.cve_ids + new.cve_ids))
        existing.mitre_attack = list(set(existing.mitre_attack + new.mitre_attack))
        existing.keywords = list(set(existing.keywords + new.keywords))[:15]
        existing.tools_used = list(set(existing.tools_used + new.tools_used))
        existing.hashes = list(set(existing.hashes + new.hashes))
        existing.persons = list(set(existing.persons + new.persons))
        existing.entities = list(set(existing.entities + new.entities))
        existing.source_turns = list(set(existing.source_turns + new.source_turns))

        # Keep higher severity
        severity_order = {
            "critical": 5,
            "high": 4,
            "medium": 3,
            "low": 2,
            "info": 1,
            "": 0,
        }
        if severity_order.get(new.severity, 0) > severity_order.get(
            existing.severity, 0
        ):
            existing.severity = new.severity

        # Keep higher confidence
        conf_order = {"confirmed": 3, "inferred": 2, "uncertain": 1}
        if conf_order.get(new.confidence, 0) > conf_order.get(existing.confidence, 0):
            existing.confidence = new.confidence

        return existing

    def _link_entry(
        self,
        new_entry: CompressedEntry,
        existing_entries: list[CompressedEntry],
    ) -> bool:
        """Link entry to related existing entries via shared entities."""
        linked = False
        new_entities = set(
            new_entry.targets + new_entry.cve_ids + new_entry.mitre_attack
        )

        if not new_entities:
            return False

        for existing in existing_entries:
            existing_entities = set(
                existing.targets + existing.cve_ids + existing.mitre_attack
            )
            shared = new_entities & existing_entities
            if shared:
                linked = True
                # Cross-reference via keywords
                link_keywords = [f"related:{existing.entry_id[:8]}"]
                new_entry.keywords = list(set(new_entry.keywords + link_keywords))

        return linked

    def consolidate_batch(
        self,
        entries: list[CompressedEntry],
    ) -> list[CompressedEntry]:
        """
        Consolidate a batch of entries among themselves.

        Useful for cross-session consolidation (Stage 2.5 in SimpleMem).
        Groups entries by topic/entity overlap and merges within groups.
        """
        if len(entries) <= 1:
            return entries

        # Group by shared entities
        groups: dict[str, list[CompressedEntry]] = defaultdict(list)
        ungrouped: list[CompressedEntry] = []

        for entry in entries:
            key_entities = entry.targets + entry.cve_ids
            if key_entities:
                group_key = sorted(key_entities)[0]
                groups[group_key].append(entry)
            else:
                ungrouped.append(entry)

        # Merge within groups
        consolidated: list[CompressedEntry] = list(ungrouped)
        for _group_key, group_entries in groups.items():
            if len(group_entries) == 1:
                consolidated.append(group_entries[0])
                continue

            # Sort by content length (richest first)
            group_entries.sort(key=lambda e: len(e.lossless_restatement), reverse=True)
            base = group_entries[0]
            for other in group_entries[1:]:
                sim = _jaccard_similarity(
                    base.lossless_restatement, other.lossless_restatement
                )
                if sim >= self.merge_threshold:
                    base = self._merge_entries(base, other)
                else:
                    consolidated.append(other)
            consolidated.append(base)

        return consolidated
