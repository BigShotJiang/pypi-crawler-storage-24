# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Memory Core — Tri-Stage Pipeline + Evolution Engine

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from .engine import CipherMemory, MemoryEntry, MemoryType, Confidence
from .compressor import SemanticCompressor, CompressedEntry, DialogueTurn, DensityGate
from .synthesizer import SemanticSynthesizer, SynthesisResult
from .retriever import AdaptiveRetriever, ContextBuilder, IntentClassifier
from .evolution import ResponseScorer, SkillEvolver, ScoredResponse
from .orchestrator import CipherOrchestrator, create_orchestrator

__all__ = [
    # Engine
    "CipherMemory",
    "MemoryEntry",
    "MemoryType",
    "Confidence",
    # Stage 1
    "SemanticCompressor",
    "CompressedEntry",
    "DialogueTurn",
    "DensityGate",
    # Stage 2
    "SemanticSynthesizer",
    "SynthesisResult",
    # Stage 3
    "AdaptiveRetriever",
    "ContextBuilder",
    "IntentClassifier",
    # Evolution
    "ResponseScorer",
    "SkillEvolver",
    "ScoredResponse",
    # Orchestrator
    "CipherOrchestrator",
    "create_orchestrator",
]
