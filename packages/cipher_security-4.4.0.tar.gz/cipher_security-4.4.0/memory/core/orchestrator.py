# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Memory — Session Orchestrator

Ties together the 3-stage memory pipeline + evolution engine:
  Stage 1: SemanticCompressor (dialogue → atomic entries)
  Stage 2: SemanticSynthesizer (dedup, merge, link)
  Stage 3: AdaptiveRetriever (intent-aware search + context building)
  Evolution: ResponseScorer + SkillEvolver (learn from failures)

Manages the full session lifecycle:
  start_session → record_events → stop_session → end_session

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .compressor import CompressedEntry, DialogueTurn, SemanticCompressor
from .engine import CipherMemory, MemoryEntry, MemoryType, Confidence, MEMORY_DIR
from .evolution import ResponseScorer, ScoredResponse, SkillEvolver
from .retriever import AdaptiveRetriever, ContextBuilder
from .synthesizer import SemanticSynthesizer

logger = logging.getLogger(__name__)


@dataclass
class SessionState:
    """Active session state."""

    session_id: str
    engagement_id: str
    started_at: str
    turns: list[DialogueTurn] = field(default_factory=list)
    scored_responses: list[ScoredResponse] = field(default_factory=list)
    entries_stored: int = 0
    active: bool = True


@dataclass
class SessionReport:
    """Report produced when a session ends."""

    session_id: str
    engagement_id: str
    duration_seconds: float
    turns_recorded: int
    entries_stored: int
    entries_deduplicated: int
    entries_merged: int
    evolution_triggered: bool
    skills_generated: int
    memory_stats: dict[str, Any] = field(default_factory=dict)


class CipherOrchestrator:
    """
    Full session lifecycle orchestrator for CIPHER memory.

    Usage:
        orch = CipherOrchestrator()

        # Start session with auto-injected context
        ctx = orch.start_session("ENG-001", "Pentest of ACME Corp web app")

        # Record engagement events
        orch.record_turn(session_id, "user", "Scan 10.10.14.5 for open ports")
        orch.record_turn(session_id, "assistant", "Found ports 22, 80, 443...")
        orch.record_tool_use(session_id, "nmap", "-sV 10.10.14.5", "22/tcp ssh...")

        # Score a response
        orch.score_response(session_id, query, response, mode="RED")

        # Finalize session
        report = orch.stop_session(session_id)

        orch.close()
    """

    def __init__(
        self,
        memory_dir: Path = MEMORY_DIR,
        skills_dir: Path | str = "skills",
        llm_client: Any = None,
        enable_evolution: bool = True,
        evolution_threshold: float = 0.4,
        context_tokens: int = 4000,
    ):
        # Core memory engine
        self.memory = CipherMemory(memory_dir=memory_dir)

        # Stage 1: Compressor
        self.compressor = SemanticCompressor(llm_client=llm_client)

        # Stage 2: Synthesizer
        self.synthesizer = SemanticSynthesizer()

        # Stage 3: Retriever
        self.retriever = AdaptiveRetriever(
            memory=self.memory,
            enable_reflection=True,
        )

        # Context builder
        self.context_builder = ContextBuilder(max_tokens=context_tokens)

        # Evolution engine
        self.scorer = ResponseScorer(llm_client=llm_client)
        self.evolver = (
            SkillEvolver(
                skills_dir=Path(skills_dir),
                llm_client=llm_client,
                history_path=memory_dir / "evolution_history.jsonl",
            )
            if enable_evolution
            else None
        )
        self.evolution_threshold = evolution_threshold

        # Active sessions
        self._sessions: dict[str, SessionState] = {}

        logger.info("CIPHER Orchestrator initialized (memory=%s)", memory_dir)

    def start_session(
        self,
        engagement_id: str = "",
        user_prompt: str = "",
    ) -> dict[str, Any]:
        """
        Start a new memory session.

        Automatically retrieves and injects context from previous sessions
        for the same engagement.

        Args:
            engagement_id: Link to ongoing engagement
            user_prompt: Initial user prompt (used for context retrieval)

        Returns:
            Dict with session_id and injected context
        """
        session_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()

        state = SessionState(
            session_id=session_id,
            engagement_id=engagement_id or f"session-{session_id[:8]}",
            started_at=now,
        )
        self._sessions[session_id] = state

        # Retrieve context from previous sessions
        context = ""
        if user_prompt or engagement_id:
            query = user_prompt or f"engagement {engagement_id}"
            entries = self.retriever.retrieve(
                query=query,
                engagement_id=engagement_id,
                limit=20,
            )
            if entries:
                context = self.context_builder.build(entries, query)

        logger.info(
            "Session started: %s (engagement=%s, context=%d chars)",
            session_id[:8],
            state.engagement_id,
            len(context),
        )

        return {
            "session_id": session_id,
            "engagement_id": state.engagement_id,
            "context": context,
            "context_entries": len(context.split("\n")) if context else 0,
        }

    def record_turn(
        self,
        session_id: str,
        role: str,
        content: str,
        timestamp: str = "",
    ) -> bool:
        """Record a dialogue turn in the session."""
        state = self._sessions.get(session_id)
        if not state or not state.active:
            logger.warning("Cannot record to inactive session: %s", session_id[:8])
            return False

        turn = DialogueTurn(
            turn_id=len(state.turns) + 1,
            role=role,
            content=content,
            timestamp=timestamp or datetime.now(timezone.utc).isoformat(),
        )
        state.turns.append(turn)
        return True

    def record_tool_use(
        self,
        session_id: str,
        tool_name: str,
        tool_input: str,
        tool_output: str,
    ) -> bool:
        """Record a tool use event in the session."""
        state = self._sessions.get(session_id)
        if not state or not state.active:
            return False

        turn = DialogueTurn(
            turn_id=len(state.turns) + 1,
            role="tool",
            content=f"Used {tool_name}: {tool_input}",
            tool_name=tool_name,
            tool_output=tool_output,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        state.turns.append(turn)
        return True

    def score_response(
        self,
        session_id: str,
        query: str,
        response: str,
        mode: str = "",
        skill_used: str = "",
    ) -> ScoredResponse:
        """Score a response and track for evolution."""
        scored = self.scorer.score(query, response, mode, skill_used)

        state = self._sessions.get(session_id)
        if state:
            state.scored_responses.append(scored)

        return scored

    def search(
        self,
        query: str,
        engagement_id: str = "",
        limit: int = 10,
    ) -> list[MemoryEntry]:
        """Search memory with intent-aware retrieval."""
        return self.retriever.retrieve(
            query=query,
            engagement_id=engagement_id,
            limit=limit,
        )

    def get_context(
        self,
        query: str,
        engagement_id: str = "",
        max_tokens: int = 4000,
    ) -> str:
        """Get formatted context for prompt injection."""
        entries = self.retriever.retrieve(
            query=query,
            engagement_id=engagement_id,
        )
        builder = ContextBuilder(max_tokens=max_tokens)
        return builder.build(entries, query)

    async def stop_session(self, session_id: str) -> SessionReport:
        """
        Finalize session: compress, synthesize, store, and optionally evolve.

        This is the main processing step that converts dialogue into
        persistent memory entries.
        """
        state = self._sessions.get(session_id)
        if not state:
            raise ValueError(f"Session not found: {session_id}")

        state.active = False
        started = datetime.fromisoformat(state.started_at)
        duration = (datetime.now(timezone.utc) - started).total_seconds()

        # Stage 1: Compress dialogue into atomic entries
        compressed = await self.compressor.compress(
            turns=state.turns,
            engagement_id=state.engagement_id,
        )

        # Stage 2: Synthesize with existing memory
        existing = self.memory.get_engagement_context(state.engagement_id)
        existing_compressed = [
            CompressedEntry(
                entry_id=e.entry_id,
                lossless_restatement=e.content,
                memory_type=e.memory_type.value,
                targets=e.targets,
                cve_ids=e.cve_ids,
                mitre_attack=e.mitre_attack,
                keywords=e.keywords,
            )
            for e in existing
        ]
        synthesis = self.synthesizer.synthesize(compressed, existing_compressed)

        # Store new entries
        stored = 0
        for entry in synthesis.new_entries:
            mem_entry = MemoryEntry(
                entry_id=entry.entry_id,
                content=entry.lossless_restatement,
                memory_type=MemoryType(entry.memory_type)
                if entry.memory_type in [e.value for e in MemoryType]
                else MemoryType.NOTE,
                confidence=Confidence(entry.confidence)
                if entry.confidence in [c.value for c in Confidence]
                else Confidence.CONFIRMED,
                engagement_id=entry.engagement_id,
                source_skill=entry.source_skill,
                timestamp=entry.timestamp,
                targets=entry.targets,
                mitre_attack=entry.mitre_attack,
                cve_ids=entry.cve_ids,
                severity=entry.severity,
                keywords=entry.keywords,
            )
            self.memory.store(mem_entry)
            stored += 1

        # Update merged entries
        for merged in synthesis.merged_entries:
            mem_entry = MemoryEntry(
                entry_id=merged.entry_id,
                content=merged.lossless_restatement,
                memory_type=MemoryType(merged.memory_type)
                if merged.memory_type in [e.value for e in MemoryType]
                else MemoryType.NOTE,
                engagement_id=merged.engagement_id,
                targets=merged.targets,
                mitre_attack=merged.mitre_attack,
                cve_ids=merged.cve_ids,
                keywords=merged.keywords,
            )
            self.memory.store(mem_entry)

        state.entries_stored = stored

        # Evolution check
        evolution_triggered = False
        skills_generated = 0
        if self.evolver and state.scored_responses:
            failed = [r for r in state.scored_responses if r.score <= 0]
            if self.evolver.should_evolve(
                state.scored_responses, self.evolution_threshold
            ):
                generated = self.evolver.evolve(failed)
                skills_generated = len(generated)
                evolution_triggered = True

        # Memory maintenance
        self.memory.consolidate()

        report = SessionReport(
            session_id=session_id,
            engagement_id=state.engagement_id,
            duration_seconds=duration,
            turns_recorded=len(state.turns),
            entries_stored=stored,
            entries_deduplicated=synthesis.stats.get("deduplicated", 0),
            entries_merged=synthesis.stats.get("merged", 0),
            evolution_triggered=evolution_triggered,
            skills_generated=skills_generated,
            memory_stats=self.memory.stats(),
        )

        logger.info(
            "Session %s finalized: %d turns → %d entries "
            "(dedup=%d, merged=%d, evolution=%s)",
            session_id[:8],
            report.turns_recorded,
            report.entries_stored,
            report.entries_deduplicated,
            report.entries_merged,
            evolution_triggered,
        )

        return report

    def stop_session_sync(self, session_id: str) -> SessionReport:
        """Synchronous wrapper for stop_session."""
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, self.stop_session(session_id))
                return future.result()
        else:
            return asyncio.run(self.stop_session(session_id))

    def end_session(self, session_id: str) -> None:
        """Clean up session state."""
        self._sessions.pop(session_id, None)

    def stats(self) -> dict[str, Any]:
        """Get orchestrator statistics."""
        memory_stats = self.memory.stats()
        evolution_stats = self.evolver.get_summary() if self.evolver else {}
        return {
            "memory": memory_stats,
            "evolution": evolution_stats,
            "active_sessions": len([s for s in self._sessions.values() if s.active]),
        }

    def close(self) -> None:
        """Clean up all resources."""
        self.memory.close()
        self._sessions.clear()


def create_orchestrator(
    project: str = "cipher",
    memory_dir: Optional[Path] = None,
    skills_dir: str = "skills",
    **kwargs: Any,
) -> CipherOrchestrator:
    """
    Factory function to create a configured CipherOrchestrator.

    Args:
        project: Project name (used for memory directory)
        memory_dir: Override memory directory
        skills_dir: Path to skills directory
        **kwargs: Additional kwargs for CipherOrchestrator

    Returns:
        Configured CipherOrchestrator instance
    """
    if memory_dir is None:
        memory_dir = Path.home() / ".cipher" / "memory" / project

    return CipherOrchestrator(
        memory_dir=memory_dir,
        skills_dir=skills_dir,
        **kwargs,
    )
