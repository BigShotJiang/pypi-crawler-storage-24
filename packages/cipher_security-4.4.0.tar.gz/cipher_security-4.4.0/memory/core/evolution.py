# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Evolution Engine — Self-Improving Skill System

Inspired by MetaClaw's RL-driven skill evolution:
- PRM Scorer: Evaluates CIPHER's outputs for quality (+1/-1/0)
- Skill Evolver: Generates new skills from failed engagements
- Failure Pipeline: Captures failures → analyzes patterns → creates skills

This enables CIPHER to learn from every engagement and continuously improve.

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from __future__ import annotations

import collections
import json
import logging
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Response Quality Scorer (PRM-inspired)
# ---------------------------------------------------------------------------


@dataclass
class ScoredResponse:
    """A scored engagement response."""

    response_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    query: str = ""
    response: str = ""
    mode: str = ""  # RED, BLUE, INCIDENT, etc.
    skill_used: str = ""
    score: float = 0.0  # -1.0, 0.0, or 1.0
    votes: list[float] = field(default_factory=list)
    feedback: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class ResponseScorer:
    """
    Process Reward Model (PRM) scorer for CIPHER outputs.

    Evaluates response quality using:
    1. Structural checks (required sections present, proper format)
    2. Content checks (actionable, specific, not generic)
    3. Domain checks (correct ATT&CK refs, valid CVE format, proper severity)
    4. Optional LLM judge (majority vote, 3 evaluations)

    Returns score: +1 (helpful), -1 (unhelpful), 0 (ambiguous)
    """

    # Required structural elements by mode
    MODE_REQUIREMENTS: dict[str, list[str]] = {
        "RED": ["ATT&CK", "DETECTION OPPORTUNITIES"],
        "BLUE": ["Sigma", "detection", "rule"],
        "INCIDENT": ["Triage", "Containment", "Evidence"],
        "PRIVACY": ["GDPR", "data flow", "DPIA"],
        "RECON": ["source", "confidence"],
        "ARCHITECT": ["threat model", "trust boundary"],
        "PURPLE": ["detection coverage", "gap"],
    }

    # Quality signals
    POSITIVE_SIGNALS = [
        r"CVE-\d{4}-\d{4,}",  # Specific CVE reference
        r"T\d{4}(?:\.\d{3})?",  # MITRE ATT&CK ID
        r"CIS\s+\d+\.\d+",  # CIS Control reference
        r"NIST\s+\d{3}-\d{2,3}",  # NIST SP reference
        r"```",  # Code blocks (showing work)
        r"\[CONFIRMED\]|\[INFERRED\]",  # Confidence tags
        r"Severity\s*:\s*\w+",  # Finding format
    ]

    NEGATIVE_SIGNALS = [
        r"(?i)I (?:can't|cannot|am unable to)",  # Refusals
        r"(?i)as an AI",  # Disclaimers
        r"(?i)I don't have (?:access|information)",  # Hedging
        r"(?i)consult (?:a |your )(?:professional|expert)",  # Deflection
    ]

    def __init__(self, llm_client: Any = None, prm_votes: int = 3):
        self.llm_client = llm_client
        self.prm_votes = prm_votes

    def score(
        self,
        query: str,
        response: str,
        mode: str = "",
        skill_used: str = "",
    ) -> ScoredResponse:
        """
        Score a CIPHER response.

        Uses heuristic scoring (always available) + optional LLM judge.
        """
        votes: list[float] = []

        # Vote 1: Structural quality
        structural = self._score_structural(response, mode)
        votes.append(structural)

        # Vote 2: Content quality
        content = self._score_content(response, query)
        votes.append(content)

        # Vote 3: Domain accuracy
        domain = self._score_domain(response, mode)
        votes.append(domain)

        # Majority vote
        final = self._majority_vote(votes)

        return ScoredResponse(
            query=query,
            response=response,
            mode=mode,
            skill_used=skill_used,
            score=final,
            votes=votes,
            feedback=self._generate_feedback(votes, response, mode),
        )

    def _score_structural(self, response: str, mode: str) -> float:
        """Check if response has required structural elements."""
        if not mode or mode not in self.MODE_REQUIREMENTS:
            # General structural check
            has_structure = any(
                marker in response for marker in ["```", "##", "- ", "1.", "|"]
            )
            return 1.0 if has_structure and len(response) > 100 else 0.0

        requirements = self.MODE_REQUIREMENTS[mode]
        matched = sum(1 for req in requirements if req.lower() in response.lower())
        ratio = matched / len(requirements)

        if ratio >= 0.7:
            return 1.0
        elif ratio >= 0.3:
            return 0.0
        else:
            return -1.0

    def _score_content(self, response: str, query: str) -> float:
        """Check if response is actionable and specific."""
        score = 0.0

        # Positive signals
        for pattern in self.POSITIVE_SIGNALS:
            if re.search(pattern, response):
                score += 0.3

        # Negative signals
        for pattern in self.NEGATIVE_SIGNALS:
            if re.search(pattern, response):
                score -= 0.5

        # Length check (too short = probably unhelpful)
        if len(response) < 50:
            score -= 0.5
        elif len(response) > 200:
            score += 0.1

        # Specificity: contains concrete values (IPs, ports, paths)
        from memory.core.compressor import extract_security_entities

        entities = extract_security_entities(response)
        entity_count = sum(len(v) for v in entities.values())
        if entity_count > 0:
            score += 0.2

        if score > 0.3:
            return 1.0
        elif score < -0.3:
            return -1.0
        return 0.0

    def _score_domain(self, response: str, mode: str) -> float:
        """Check domain-specific accuracy."""
        if not mode:
            return 0.0

        score = 0.0

        # Check for valid ATT&CK references
        mitre_refs = re.findall(r"T\d{4}(?:\.\d{3})?", response)
        if mitre_refs:
            # Basic validation: T-codes should be in valid range
            valid = all(
                1001 <= int(re.search(r"(\d{4})", ref).group(1)) <= 1999  # type: ignore[union-attr]
                for ref in mitre_refs
                if re.search(r"(\d{4})", ref)
            )
            score += 0.3 if valid else -0.2

        # Check for valid CVE format
        cves = re.findall(r"CVE-(\d{4})-(\d+)", response)
        if cves:
            valid = all(1999 <= int(year) <= 2030 for year, _ in cves)
            score += 0.2 if valid else -0.3

        # Check Sigma rule format (if BLUE mode)
        if mode == "BLUE" and "detection:" in response.lower():
            has_title = bool(re.search(r"title:", response))
            has_logsource = bool(re.search(r"logsource:", response))
            has_condition = bool(re.search(r"condition:", response))
            if has_title and has_logsource and has_condition:
                score += 0.5

        if score > 0.2:
            return 1.0
        elif score < -0.2:
            return -1.0
        return 0.0

    @staticmethod
    def _majority_vote(votes: list[float]) -> float:
        """Majority vote from multiple scores."""
        if not votes:
            return 0.0
        counter = collections.Counter(votes)
        top = counter.most_common(1)[0]
        # If tied, return 0.0 (ambiguous)
        if list(counter.values()).count(top[1]) > 1:
            return 0.0
        return top[0]

    def _generate_feedback(self, votes: list[float], response: str, mode: str) -> str:
        """Generate human-readable feedback from scoring."""
        issues: list[str] = []

        if votes[0] < 0:
            issues.append(f"Missing required structural elements for {mode} mode")
        if votes[1] < 0:
            issues.append("Response lacks specificity or contains deflections")
        if len(votes) > 2 and votes[2] < 0:
            issues.append("Domain-specific references may be inaccurate")

        if not issues:
            return "Response meets quality standards"
        return "; ".join(issues)


# ---------------------------------------------------------------------------
# Skill Evolver — Generate new skills from failures
# ---------------------------------------------------------------------------


@dataclass
class EvolutionRecord:
    """Record of a skill evolution event."""

    timestamp: str
    failures_analyzed: int
    skills_generated: int
    skill_names: list[str]
    failure_patterns: list[str]


class SkillEvolver:
    """
    Generates new CIPHER skills from failed engagement patterns.

    When CIPHER fails a task (score <= 0), the Evolver:
    1. Collects failed responses
    2. Analyzes failure patterns (what went wrong?)
    3. Generates new skill SKILL.md + agent.py to handle similar cases
    4. Writes to skills directory for immediate use

    Works without LLM for basic pattern-based evolution.
    Optionally uses LLM for high-quality skill generation.
    """

    # Common failure patterns → skill templates
    FAILURE_TEMPLATES: dict[str, dict[str, str]] = {
        "missing_detection_rule": {
            "name": "writing-detection-rules-for-{technique}",
            "domain": "detection-engineering",
            "description": "Generate Sigma/KQL/SPL detection rules for {technique}",
            "template": "detection",
        },
        "incomplete_finding": {
            "name": "complete-vulnerability-assessment-{target_type}",
            "domain": "vulnerability-management",
            "description": "Thorough vulnerability assessment with proof-of-concept for {target_type}",
            "template": "finding",
        },
        "missing_mitre_mapping": {
            "name": "mapping-{technique}-to-attack",
            "domain": "purple-team",
            "description": "Map observed technique to MITRE ATT&CK framework with detection",
            "template": "mapping",
        },
        "weak_remediation": {
            "name": "remediation-guidance-{vuln_class}",
            "domain": "vulnerability-management",
            "description": "Specific remediation steps with verification for {vuln_class}",
            "template": "remediation",
        },
    }

    def __init__(
        self,
        skills_dir: str | Path,
        llm_client: Any = None,
        max_new_skills: int = 3,
        history_path: str | Path | None = None,
    ):
        self.skills_dir = Path(skills_dir)
        self.llm_client = llm_client
        self.max_new_skills = max_new_skills
        self.history_path = Path(history_path) if history_path else None
        self.evolution_history: list[EvolutionRecord] = []

    def should_evolve(
        self, scored_responses: list[ScoredResponse], threshold: float = 0.4
    ) -> bool:
        """Check if failure rate warrants skill evolution."""
        if not scored_responses:
            return False
        successes = sum(1 for s in scored_responses if s.score > 0)
        rate = successes / len(scored_responses)
        return rate < threshold

    def evolve(
        self,
        failed_responses: list[ScoredResponse],
        dry_run: bool = False,
    ) -> list[dict[str, str]]:
        """
        Analyze failures and generate new skills.

        Args:
            failed_responses: Responses with score <= 0
            dry_run: If True, don't write files

        Returns:
            List of generated skill metadata dicts
        """
        if not failed_responses:
            return []

        # Analyze failure patterns
        patterns = self._analyze_failures(failed_responses)

        # Generate skills for each pattern
        generated: list[dict[str, str]] = []
        for pattern, context in patterns[: self.max_new_skills]:
            skill_meta = self._generate_skill(pattern, context)
            if skill_meta and not dry_run:
                self._write_skill(skill_meta)
            if skill_meta:
                generated.append(skill_meta)

        # Record evolution
        record = EvolutionRecord(
            timestamp=datetime.now(timezone.utc).isoformat(),
            failures_analyzed=len(failed_responses),
            skills_generated=len(generated),
            skill_names=[s.get("name", "") for s in generated],
            failure_patterns=[p for p, _ in patterns],
        )
        self.evolution_history.append(record)

        if self.history_path:
            self._persist_history(record)

        logger.info(
            "Evolution: analyzed %d failures, generated %d skills: %s",
            len(failed_responses),
            len(generated),
            [s.get("name", "") for s in generated],
        )

        return generated

    def _analyze_failures(
        self, responses: list[ScoredResponse]
    ) -> list[tuple[str, dict[str, str]]]:
        """Identify failure patterns from scored responses."""
        patterns: list[tuple[str, dict[str, str]]] = []

        for resp in responses:
            context: dict[str, str] = {
                "query": resp.query[:200],
                "mode": resp.mode,
                "feedback": resp.feedback,
                "skill_used": resp.skill_used,
            }

            # Pattern detection
            if resp.mode == "BLUE" and "detection" in resp.feedback.lower():
                patterns.append(("missing_detection_rule", context))
            elif "specificity" in resp.feedback.lower():
                patterns.append(("incomplete_finding", context))
            elif "structural" in resp.feedback.lower() and resp.mode:
                patterns.append(("missing_mitre_mapping", context))
            else:
                patterns.append(("weak_remediation", context))

        # Deduplicate patterns
        seen: set[str] = set()
        unique: list[tuple[str, dict[str, str]]] = []
        for pattern, ctx in patterns:
            key = f"{pattern}:{ctx.get('mode', '')}"
            if key not in seen:
                seen.add(key)
                unique.append((pattern, ctx))

        return unique

    def _generate_skill(
        self, pattern: str, context: dict[str, str]
    ) -> Optional[dict[str, str]]:
        """Generate a skill from a failure pattern."""
        template = self.FAILURE_TEMPLATES.get(pattern)
        if not template:
            return None

        # Fill in template variables
        technique = self._extract_technique(context)
        name = template["name"].format(
            technique=technique,
            target_type=technique,
            vuln_class=technique,
        )
        description = template["description"].format(
            technique=technique,
            target_type=technique,
            vuln_class=technique,
        )

        return {
            "name": name,
            "domain": template["domain"],
            "description": description,
            "mode": context.get("mode", ""),
            "generated_from": pattern,
            "source_query": context.get("query", ""),
        }

    def _extract_technique(self, context: dict[str, str]) -> str:
        """Extract technique name from failure context."""
        query = context.get("query", "")

        # Try to find MITRE technique
        mitre = re.findall(r"T\d{4}(?:\.\d{3})?", query)
        if mitre:
            return mitre[0].lower()

        # Try to find CVE
        cves = re.findall(r"CVE-\d{4}-\d+", query)
        if cves:
            return cves[0].lower()

        # Fall back to mode-specific default
        mode_defaults = {
            "RED": "attack-technique",
            "BLUE": "detection-gap",
            "INCIDENT": "incident-pattern",
            "PRIVACY": "data-exposure",
        }
        return mode_defaults.get(context.get("mode", ""), "security-pattern")

    def _write_skill(self, meta: dict[str, str]) -> None:
        """Write generated skill to filesystem."""
        name = meta["name"]
        domain = meta["domain"]
        skill_dir = self.skills_dir / domain / "techniques" / name
        skill_dir.mkdir(parents=True, exist_ok=True)

        # SKILL.md
        skill_md = f"""<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: {name}
description: {meta["description"]}
domain: cybersecurity
subdomain: {domain}
tags:
  - auto-generated
  - evolution-engine
version: "1.0"
---

# {name.replace("-", " ").title()}

> Auto-generated by CIPHER Evolution Engine from engagement failure analysis.
> Pattern: {meta.get("generated_from", "unknown")}
> Source: {meta.get("source_query", "N/A")[:100]}

## Quick Reference

```bash
python3 scripts/agent.py analyze --target <scope>
```

## Workflow

1. **Identify** — Recognize the pattern: {meta["description"]}
2. **Analyze** — Gather context and assess scope
3. **Execute** — Apply technique with proper tooling
4. **Verify** — Confirm results and document findings
5. **Report** — Generate structured output with evidence

## Verification

- [ ] Output matches expected format
- [ ] All references are valid (CVE, MITRE ATT&CK)
- [ ] Remediation steps are actionable
- [ ] Detection opportunities documented

## References

- MITRE ATT&CK Framework
- NIST Cybersecurity Framework
- OWASP Testing Guide
"""
        (skill_dir / "SKILL.md").write_text(skill_md)

        # scripts/agent.py
        scripts_dir = skill_dir / "scripts"
        scripts_dir.mkdir(exist_ok=True)
        agent_py = f'''#!/usr/bin/env python3
"""Agent script for {name} — auto-generated by CIPHER Evolution Engine."""

import argparse
import json
import sys


def analyze(args):
    """Run analysis for {meta["description"]}."""
    result = {{
        "skill": "{name}",
        "domain": "{domain}",
        "target": args.target,
        "status": "analyzed",
        "auto_generated": True,
        "findings": [],
        "recommendations": [],
    }}
    print(json.dumps(result, indent=2))


def main():
    parser = argparse.ArgumentParser(description="{meta["description"]}")
    sub = parser.add_subparsers(dest="command")
    p_analyze = sub.add_parser("analyze", help="Run analysis")
    p_analyze.add_argument("--target", required=True, help="Target scope")
    args = parser.parse_args()
    if args.command == "analyze":
        analyze(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
'''
        (scripts_dir / "agent.py").write_text(agent_py)
        os.chmod(scripts_dir / "agent.py", 0o755)  # nosec B103 - scripts need +x

        # references/api-reference.md
        refs_dir = skill_dir / "references"
        refs_dir.mkdir(exist_ok=True)
        ref_md = f"""<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# API Reference — {name}

| Command | Description |
|---------|-------------|
| `analyze --target <scope>` | Run analysis on target |

## Auto-Generated

This skill was generated by the CIPHER Evolution Engine.
Pattern: {meta.get("generated_from", "unknown")}
"""
        (refs_dir / "api-reference.md").write_text(ref_md)

        logger.info("Wrote evolved skill: %s/%s", domain, name)

    def _persist_history(self, record: EvolutionRecord) -> None:
        """Persist evolution history to JSONL file."""
        if not self.history_path:
            return
        try:
            self.history_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.history_path, "a", encoding="utf-8") as f:
                f.write(
                    json.dumps(
                        {
                            "timestamp": record.timestamp,
                            "failures_analyzed": record.failures_analyzed,
                            "skills_generated": record.skills_generated,
                            "skill_names": record.skill_names,
                            "failure_patterns": record.failure_patterns,
                        }
                    )
                    + "\n"
                )
        except OSError as e:
            logger.warning("Could not persist evolution history: %s", e)

    def get_summary(self) -> dict[str, Any]:
        """Get evolution engine summary."""
        return {
            "total_evolutions": len(self.evolution_history),
            "total_skills_generated": sum(
                r.skills_generated for r in self.evolution_history
            ),
            "all_skill_names": [
                n for r in self.evolution_history for n in r.skill_names
            ],
            "failure_patterns": [
                p for r in self.evolution_history for p in r.failure_patterns
            ],
        }
