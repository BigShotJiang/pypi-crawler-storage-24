# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Cross-Session Memory — Tri-Layer Indexing Engine

Provides persistent memory across security engagements with three orthogonal
index layers for high-recall, high-precision retrieval:

1. Semantic Layer  — Dense vector embeddings (sentence-transformers) in LanceDB
2. Lexical Layer   — BM25 keyword index (SQLite FTS5)
3. Symbolic Layer  — Structured metadata constraints (SQLite relational)

Retrieval fuses all three layers with reciprocal rank fusion (RRF).

Architecture inspired by SimpleMem (tri-layer indexing) and ProjectDiscovery Neo
(persistent memory compounding across engagements).

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MEMORY_DIR = Path(os.environ.get("CIPHER_MEMORY_DIR", "~/.cipher/memory")).expanduser()
LANCE_DIR = MEMORY_DIR / "lance"
SQLITE_PATH = MEMORY_DIR / "memory.db"
DEFAULT_TOP_K = 10
RRF_K = 60  # Reciprocal Rank Fusion constant


class MemoryType(str, Enum):
    """Categories of security memory entries."""

    FINDING = "finding"  # Vulnerability or security finding
    IOC = "ioc"  # Indicator of compromise
    TTP = "ttp"  # Tactic, technique, procedure
    CREDENTIAL = "credential"  # Discovered credential (hashed reference only)
    HOST = "host"  # Host/asset information
    NETWORK = "network"  # Network topology or flow data
    CONFIG = "config"  # Configuration or policy
    NOTE = "note"  # Analyst observation
    DECISION = "decision"  # Engagement decision with rationale
    ARTIFACT = "artifact"  # File hash, sample, or evidence reference


class Confidence(str, Enum):
    """Confidence levels matching CIPHER output standards."""

    CONFIRMED = "confirmed"
    INFERRED = "inferred"
    EXTERNAL = "external"
    UNCERTAIN = "uncertain"


@dataclass
class MemoryEntry:
    """
    Atomic memory unit indexed across three orthogonal layers.

    Semantic:  content field → dense embedding vector
    Lexical:   keywords + content → BM25 sparse index
    Symbolic:  All typed metadata fields → SQL constraints
    """

    # Core content
    entry_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""  # Lossless restatement (no pronouns, absolute refs)
    memory_type: MemoryType = MemoryType.NOTE
    confidence: Confidence = Confidence.CONFIRMED

    # Symbolic metadata (structured, queryable)
    engagement_id: str = ""  # Links entry to specific engagement
    source_skill: str = ""  # Which CIPHER skill generated this
    timestamp: str = ""  # ISO 8601
    targets: list[str] = field(default_factory=list)  # IPs, domains, URLs
    mitre_attack: list[str] = field(default_factory=list)  # T1234 references
    cve_ids: list[str] = field(default_factory=list)  # CVE-YYYY-NNNNN
    severity: str = ""  # critical/high/medium/low/info
    tags: list[str] = field(default_factory=list)
    related_entries: list[str] = field(default_factory=list)  # entry_id references

    # Lexical metadata
    keywords: list[str] = field(
        default_factory=list
    )  # Explicit keywords for BM25 boost

    # Lifecycle
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    updated_at: str = ""
    accessed_at: str = ""
    access_count: int = 0
    decay_score: float = 1.0  # Decays over time, boosted on access
    is_archived: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "content": self.content,
            "memory_type": self.memory_type.value,
            "confidence": self.confidence.value,
            "engagement_id": self.engagement_id,
            "source_skill": self.source_skill,
            "timestamp": self.timestamp,
            "targets": json.dumps(self.targets),
            "mitre_attack": json.dumps(self.mitre_attack),
            "cve_ids": json.dumps(self.cve_ids),
            "severity": self.severity,
            "tags": json.dumps(self.tags),
            "related_entries": json.dumps(self.related_entries),
            "keywords": json.dumps(self.keywords),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "accessed_at": self.accessed_at,
            "access_count": self.access_count,
            "decay_score": self.decay_score,
            "is_archived": self.is_archived,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "MemoryEntry":
        return cls(
            entry_id=d["entry_id"],
            content=d["content"],
            memory_type=MemoryType(d["memory_type"]),
            confidence=Confidence(d["confidence"]),
            engagement_id=d.get("engagement_id", ""),
            source_skill=d.get("source_skill", ""),
            timestamp=d.get("timestamp", ""),
            targets=json.loads(d.get("targets", "[]")),
            mitre_attack=json.loads(d.get("mitre_attack", "[]")),
            cve_ids=json.loads(d.get("cve_ids", "[]")),
            severity=d.get("severity", ""),
            tags=json.loads(d.get("tags", "[]")),
            related_entries=json.loads(d.get("related_entries", "[]")),
            keywords=json.loads(d.get("keywords", "[]")),
            created_at=d.get("created_at", ""),
            updated_at=d.get("updated_at", ""),
            accessed_at=d.get("accessed_at", ""),
            access_count=d.get("access_count", 0),
            decay_score=d.get("decay_score", 1.0),
            is_archived=d.get("is_archived", False),
        )


# ---------------------------------------------------------------------------
# Symbolic Layer — SQLite relational store
# ---------------------------------------------------------------------------


class SymbolicStore:
    """SQLite-backed structured metadata store with FTS5 for lexical search."""

    def __init__(self, db_path: Path = SQLITE_PATH):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS entries (
                entry_id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                memory_type TEXT NOT NULL,
                confidence TEXT NOT NULL DEFAULT 'confirmed',
                engagement_id TEXT DEFAULT '',
                source_skill TEXT DEFAULT '',
                timestamp TEXT DEFAULT '',
                targets TEXT DEFAULT '[]',
                mitre_attack TEXT DEFAULT '[]',
                cve_ids TEXT DEFAULT '[]',
                severity TEXT DEFAULT '',
                tags TEXT DEFAULT '[]',
                related_entries TEXT DEFAULT '[]',
                keywords TEXT DEFAULT '[]',
                created_at TEXT NOT NULL,
                updated_at TEXT DEFAULT '',
                accessed_at TEXT DEFAULT '',
                access_count INTEGER DEFAULT 0,
                decay_score REAL DEFAULT 1.0,
                is_archived INTEGER DEFAULT 0
            );

            CREATE INDEX IF NOT EXISTS idx_engagement ON entries(engagement_id);
            CREATE INDEX IF NOT EXISTS idx_memory_type ON entries(memory_type);
            CREATE INDEX IF NOT EXISTS idx_severity ON entries(severity);
            CREATE INDEX IF NOT EXISTS idx_source_skill ON entries(source_skill);
            CREATE INDEX IF NOT EXISTS idx_decay ON entries(decay_score);

            -- FTS5 virtual table for lexical (BM25) search
            CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts USING fts5(
                entry_id UNINDEXED,
                content,
                keywords,
                tokenize='porter unicode61'
            );

            -- Engagements metadata
            CREATE TABLE IF NOT EXISTS engagements (
                engagement_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                client TEXT DEFAULT '',
                engagement_type TEXT DEFAULT '',
                status TEXT DEFAULT 'active',
                created_at TEXT NOT NULL,
                updated_at TEXT DEFAULT '',
                metadata TEXT DEFAULT '{}'
            );
        """)
        self.conn.commit()

    def store(self, entry: MemoryEntry) -> str:
        d = entry.to_dict()
        cols = ", ".join(d.keys())
        placeholders = ", ".join(["?"] * len(d))
        self.conn.execute(
            f"INSERT OR REPLACE INTO entries ({cols}) VALUES ({placeholders})",
            list(d.values()),
        )
        # Update FTS index
        self.conn.execute(
            "INSERT OR REPLACE INTO entries_fts (entry_id, content, keywords) VALUES (?, ?, ?)",
            (entry.entry_id, entry.content, " ".join(entry.keywords)),
        )
        self.conn.commit()
        return entry.entry_id

    def search_symbolic(
        self,
        engagement_id: str = "",
        memory_type: str = "",
        severity: str = "",
        mitre_technique: str = "",
        cve_id: str = "",
        target: str = "",
        tag: str = "",
        limit: int = DEFAULT_TOP_K,
    ) -> list[dict]:
        """Query by structured metadata constraints."""
        conditions = ["is_archived = 0"]
        params: list[Any] = []

        if engagement_id:
            conditions.append("engagement_id = ?")
            params.append(engagement_id)
        if memory_type:
            conditions.append("memory_type = ?")
            params.append(memory_type)
        if severity:
            conditions.append("severity = ?")
            params.append(severity)
        if mitre_technique:
            conditions.append("mitre_attack LIKE ?")
            params.append(f"%{mitre_technique}%")
        if cve_id:
            conditions.append("cve_ids LIKE ?")
            params.append(f"%{cve_id}%")
        if target:
            conditions.append("targets LIKE ?")
            params.append(f"%{target}%")
        if tag:
            conditions.append("tags LIKE ?")
            params.append(f"%{tag}%")

        where = " AND ".join(conditions)
        rows = self.conn.execute(
            f"SELECT * FROM entries WHERE {where} ORDER BY decay_score DESC LIMIT ?",  # nosec B608
            params + [limit],
        ).fetchall()
        return [dict(r) for r in rows]

    def search_lexical(self, query: str, limit: int = DEFAULT_TOP_K) -> list[dict]:
        """BM25 keyword search via FTS5."""
        # Sanitize query for FTS5: quote each token to avoid syntax errors
        tokens = [t.strip() for t in query.split() if t.strip()]
        if not tokens:
            return []
        fts_query = " ".join(f'"{t}"' for t in tokens)
        try:
            rows = self.conn.execute(
                """SELECT e.*, rank FROM entries_fts f
                   JOIN entries e ON f.entry_id = e.entry_id
                   WHERE entries_fts MATCH ? AND e.is_archived = 0
                   ORDER BY rank LIMIT ?""",
                (fts_query, limit),
            ).fetchall()
        except Exception:
            return []
        return [dict(r) for r in rows]

    def get(self, entry_id: str) -> Optional[dict]:
        row = self.conn.execute(
            "SELECT * FROM entries WHERE entry_id = ?", (entry_id,)
        ).fetchone()
        if row:
            # Update access metadata
            now = datetime.now(timezone.utc).isoformat()
            self.conn.execute(
                "UPDATE entries SET accessed_at = ?, access_count = access_count + 1 WHERE entry_id = ?",
                (now, entry_id),
            )
            self.conn.commit()
            return dict(row)
        return None

    def decay_all(self, factor: float = 0.95):
        """Apply time-based decay to all entries. Called periodically."""
        self.conn.execute(
            "UPDATE entries SET decay_score = decay_score * ? WHERE is_archived = 0",
            (factor,),
        )
        self.conn.commit()

    def boost(self, entry_id: str, amount: float = 0.1):
        """Boost entry score when accessed or referenced."""
        self.conn.execute(
            "UPDATE entries SET decay_score = MIN(decay_score + ?, 1.0) WHERE entry_id = ?",
            (amount, entry_id),
        )
        self.conn.commit()

    def archive_stale(self, threshold: float = 0.1):
        """Archive entries with decay below threshold."""
        self.conn.execute(
            "UPDATE entries SET is_archived = 1 WHERE decay_score < ? AND is_archived = 0",
            (threshold,),
        )
        self.conn.commit()

    def stats(self) -> dict:
        """Return memory statistics."""
        row = self.conn.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN is_archived = 0 THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN is_archived = 1 THEN 1 ELSE 0 END) as archived,
                COUNT(DISTINCT engagement_id) as engagements
            FROM entries
        """).fetchone()
        return dict(row) if row else {}

    def close(self):
        self.conn.close()


# ---------------------------------------------------------------------------
# Semantic Layer — LanceDB vector store
# ---------------------------------------------------------------------------


class SemanticStore:
    """Dense vector embedding store using LanceDB."""

    def __init__(self, db_path: Path = LANCE_DIR, model_name: str = "all-MiniLM-L6-v2"):
        self.db_path = db_path
        self.model_name = model_name
        self._db = None
        self._table = None
        self._model = None

    def _ensure_model(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer

                self._model = SentenceTransformer(self.model_name)
            except ImportError:
                logger.warning(
                    "sentence-transformers not installed. Semantic search disabled."
                )
                return False
        return True

    def _ensure_db(self):
        if self._db is None:
            try:
                import lancedb

                self.db_path.mkdir(parents=True, exist_ok=True)
                self._db = lancedb.connect(str(self.db_path))
            except ImportError:
                logger.warning("lancedb not installed. Semantic search disabled.")
                return False
        return True

    def embed(self, text: str) -> list[float]:
        if not self._ensure_model():
            return []
        assert self._model is not None  # guaranteed by _ensure_model
        return self._model.encode(text).tolist()

    def store(self, entry_id: str, content: str, metadata: dict):
        if not self._ensure_db() or not self._ensure_model():
            return
        assert self._db is not None  # guaranteed by _ensure_db

        vector = self.embed(content)
        record = {
            "entry_id": entry_id,
            "vector": vector,
            "content": content[:500],  # Truncate for storage
            **{k: str(v) for k, v in metadata.items()},
        }

        try:
            if self._table is None:
                tables = self._db.table_names()
                if "memories" in tables:
                    self._table = self._db.open_table("memories")
                else:
                    self._table = self._db.create_table("memories", [record])
                    return

            self._table.add([record])
        except Exception as e:
            logger.error(f"Semantic store error: {e}")

    def search(self, query: str, limit: int = DEFAULT_TOP_K) -> list[dict]:
        if not self._ensure_db() or not self._ensure_model():
            return []
        assert self._db is not None  # guaranteed by _ensure_db

        try:
            if self._table is None:
                tables = self._db.table_names()
                if "memories" not in tables:
                    return []
                self._table = self._db.open_table("memories")

            vector = self.embed(query)
            results = self._table.search(vector).limit(limit).to_list()
            return [
                {"entry_id": r["entry_id"], "score": 1.0 - r.get("_distance", 0)}
                for r in results
            ]
        except Exception as e:
            logger.error(f"Semantic search error: {e}")
            return []


# ---------------------------------------------------------------------------
# Fusion Engine — Reciprocal Rank Fusion
# ---------------------------------------------------------------------------


def reciprocal_rank_fusion(
    result_lists: list[list[str]],
    k: int = RRF_K,
) -> list[tuple[str, float]]:
    """
    Fuse multiple ranked lists using Reciprocal Rank Fusion.

    RRF(d) = Σ 1 / (k + rank_i(d)) for each result list i

    Args:
        result_lists: List of ranked entry_id lists (best first)
        k: RRF constant (default 60)

    Returns:
        Fused ranked list of (entry_id, rrf_score) tuples
    """
    scores: dict[str, float] = {}
    for ranked_list in result_lists:
        for rank, entry_id in enumerate(ranked_list):
            scores[entry_id] = scores.get(entry_id, 0.0) + 1.0 / (k + rank + 1)

    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


# ---------------------------------------------------------------------------
# Memory Engine — Unified interface
# ---------------------------------------------------------------------------


class CipherMemory:
    """
    Unified memory engine combining semantic, lexical, and symbolic layers.

    Usage:
        memory = CipherMemory()
        memory.store(MemoryEntry(content="Found SQLi on /api/login", ...))
        results = memory.search("SQL injection vulnerabilities")
        memory.close()
    """

    def __init__(self, memory_dir: Path = MEMORY_DIR):
        self.memory_dir = memory_dir
        self.symbolic = SymbolicStore(memory_dir / "memory.db")
        self.semantic = SemanticStore(memory_dir / "lance")
        logger.info(f"CIPHER Memory initialized at {memory_dir}")

    def store(self, entry: MemoryEntry) -> str:
        """Store entry across all three layers."""
        # Symbolic + Lexical (SQLite)
        entry_id = self.symbolic.store(entry)

        # Semantic (LanceDB)
        self.semantic.store(
            entry_id=entry.entry_id,
            content=entry.content,
            metadata={
                "memory_type": entry.memory_type.value,
                "engagement_id": entry.engagement_id,
                "severity": entry.severity,
            },
        )

        logger.info(f"Stored memory {entry_id[:8]}... type={entry.memory_type.value}")
        return entry_id

    def search(
        self,
        query: str,
        engagement_id: str = "",
        memory_type: str = "",
        severity: str = "",
        mitre_technique: str = "",
        limit: int = DEFAULT_TOP_K,
    ) -> list[MemoryEntry]:
        """
        Tri-layer fused search.

        Queries all three layers and fuses results with RRF:
        1. Semantic — "what does this mean?" (dense vector similarity)
        2. Lexical — "what words match?" (BM25 keyword matching)
        3. Symbolic — "what metadata matches?" (structured SQL constraints)
        """
        result_lists: list[list[str]] = []

        # Layer 1: Semantic search
        semantic_results = self.semantic.search(query, limit=limit * 2)
        if semantic_results:
            result_lists.append([r["entry_id"] for r in semantic_results])

        # Layer 2: Lexical search (BM25)
        lexical_results = self.symbolic.search_lexical(query, limit=limit * 2)
        if lexical_results:
            result_lists.append([r["entry_id"] for r in lexical_results])

        # Layer 3: Symbolic search (structured)
        symbolic_results = self.symbolic.search_symbolic(
            engagement_id=engagement_id,
            memory_type=memory_type,
            severity=severity,
            mitre_technique=mitre_technique,
            limit=limit * 2,
        )
        if symbolic_results:
            result_lists.append([r["entry_id"] for r in symbolic_results])

        # Fuse with RRF
        if not result_lists:
            return []

        fused = reciprocal_rank_fusion(result_lists)

        # Fetch full entries for top results
        entries = []
        for entry_id, score in fused[:limit]:
            row = self.symbolic.get(entry_id)
            if row:
                entry = MemoryEntry.from_dict(row)
                self.symbolic.boost(entry_id, 0.05)  # Boost on access
                entries.append(entry)

        return entries

    def get_engagement_context(self, engagement_id: str) -> list[MemoryEntry]:
        """Get all active memories for an engagement, sorted by relevance."""
        results = self.symbolic.search_symbolic(engagement_id=engagement_id, limit=100)
        return [MemoryEntry.from_dict(r) for r in results]

    def consolidate(self):
        """Run memory maintenance: decay, archive stale, merge duplicates."""
        self.symbolic.decay_all(factor=0.98)
        self.symbolic.archive_stale(threshold=0.05)
        stats = self.symbolic.stats()
        logger.info(f"Memory consolidated: {stats}")
        return stats

    def stats(self) -> dict:
        return self.symbolic.stats()

    def close(self):
        self.symbolic.close()


class MemoryConsolidator:
    """Memory consolidation worker — decay, merge, prune.

    Inspired by SimpleMem's consolidation pattern:
    1. Decay — reduce importance of old entries over time
    2. Merge — combine near-duplicate entries with high textual similarity
    3. Prune — archive entries below importance threshold
    """

    def __init__(self, memory: CipherMemory):
        self.memory = memory

    def _text_similarity(self, a: str, b: str) -> float:
        """Combined similarity: Jaccard trigrams + TF-IDF cosine (no external deps).

        Returns the max of both methods for robust near-duplicate detection.
        Inspired by ACE's embedding dedup but uses zero-dependency heuristics.
        """
        jaccard = self._jaccard_trigrams(a, b)
        cosine = self._tfidf_cosine(a, b)
        return max(jaccard, cosine)

    @staticmethod
    def _jaccard_trigrams(a: str, b: str) -> float:
        """Jaccard similarity on word trigrams."""

        def trigrams(text: str) -> set[str]:
            words = text.lower().split()
            if len(words) < 3:
                return set(words)
            return {" ".join(words[i : i + 3]) for i in range(len(words) - 2)}

        tg_a = trigrams(a)
        tg_b = trigrams(b)
        if not tg_a or not tg_b:
            return 0.0
        intersection = tg_a & tg_b
        union = tg_a | tg_b
        return len(intersection) / len(union) if union else 0.0

    @staticmethod
    def _tfidf_cosine(a: str, b: str) -> float:
        """TF-IDF cosine similarity using pure Python (no numpy/sklearn).

        Provides better near-duplicate detection than trigrams for
        semantically similar entries with different word ordering.
        """
        import math
        from collections import Counter

        words_a = a.lower().split()
        words_b = b.lower().split()
        if not words_a or not words_b:
            return 0.0

        tf_a = Counter(words_a)
        tf_b = Counter(words_b)
        vocab = set(tf_a) | set(tf_b)

        # IDF: treat the two docs as the corpus
        doc_freq: dict[str, int] = {}
        for w in vocab:
            doc_freq[w] = (1 if w in tf_a else 0) + (1 if w in tf_b else 0)

        # TF-IDF vectors
        def tfidf_vec(tf: Counter[str]) -> dict[str, float]:
            total = sum(tf.values())
            return {w: (tf[w] / total) * math.log(2.0 / doc_freq[w] + 1) for w in vocab}

        vec_a = tfidf_vec(tf_a)
        vec_b = tfidf_vec(tf_b)

        # Cosine similarity
        dot = sum(vec_a.get(w, 0) * vec_b.get(w, 0) for w in vocab)
        mag_a = math.sqrt(sum(v * v for v in vec_a.values()))
        mag_b = math.sqrt(sum(v * v for v in vec_b.values()))
        if mag_a == 0 or mag_b == 0:
            return 0.0
        return dot / (mag_a * mag_b)

    def merge_similar(self, threshold: float = 0.85) -> dict:
        """Merge entries with textual similarity above threshold.

        Keeps the higher-confidence entry and appends context from the other.
        The merged-away entry is archived via existing SymbolicStore methods.
        """
        checked = 0
        merge_count = 0
        pairs: list[dict] = []
        store = self.memory.symbolic

        # Get all active entries grouped by type using search_symbolic
        for memory_type in ["finding", "ioc", "ttp", "note"]:
            results = store.search_symbolic(
                memory_type=memory_type,
                limit=500,
            )
            entries = [MemoryEntry.from_dict(r) for r in results]
            for i, entry_a in enumerate(entries):
                for entry_b in entries[i + 1 :]:
                    checked += 1
                    sim = self._text_similarity(entry_a.content, entry_b.content)
                    if sim >= threshold:
                        # Keep the one with higher confidence
                        keeper = (
                            entry_a
                            if entry_a.decay_score >= entry_b.decay_score
                            else entry_b
                        )
                        discard = entry_b if keeper is entry_a else entry_a

                        # Append unique tags
                        combined_tags = list(set(keeper.tags + discard.tags))
                        keeper.tags = combined_tags

                        # Boost decay score of keeper
                        keeper.decay_score = min(1.0, keeper.decay_score + 0.1)

                        # Re-store keeper with updated fields
                        store.store(keeper)

                        # Archive the merged entry by marking it
                        discard.is_archived = True
                        discard.decay_score = 0.0
                        store.store(discard)

                        merge_count += 1
                        pairs.append(
                            {
                                "kept": keeper.entry_id,
                                "merged": discard.entry_id,
                                "similarity": round(sim, 3),
                            }
                        )

        return {"checked": checked, "merged": merge_count, "pairs": pairs}

    def full_consolidation(self) -> dict:
        """Run full consolidation cycle: decay → merge → prune."""
        results = {}

        # 1. Decay
        decay_stats = self.memory.consolidate()
        results["decay"] = decay_stats

        # 2. Merge
        merge_stats = self.merge_similar()
        results["merge"] = merge_stats

        # 3. Summary
        results["summary"] = {
            "decayed": decay_stats.get("decayed", 0),
            "archived": decay_stats.get("archived", 0),
            "merged": merge_stats["merged"],
            "pairs_checked": merge_stats["checked"],
        }

        return results
