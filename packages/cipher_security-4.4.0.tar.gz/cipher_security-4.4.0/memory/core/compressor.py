# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Memory — Stage 1: Semantic Structured Compression

Converts raw security engagement dialogues into atomic, self-contained
memory entries through LLM-powered extraction:

- Coreference resolution (remove pronouns → absolute references)
- Temporal anchoring (relative times → absolute ISO 8601)
- Security-specific entity extraction (IPs, CVEs, MITRE ATT&CK, tools)
- Information density gating (skip low-information exchanges)

Inspired by SimpleMem's Stage 1 pipeline, adapted for cybersecurity domain.

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Security-specific extraction patterns
# ---------------------------------------------------------------------------

_IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}")
_MITRE_RE = re.compile(r"T\d{4}(?:\.\d{3})?")
_PORT_RE = re.compile(r"\b(?:port\s+)?(\d{1,5})(?:/(?:tcp|udp))?\b", re.IGNORECASE)
_DOMAIN_RE = re.compile(
    r"\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b"
)
_HASH_MD5_RE = re.compile(r"\b[a-fA-F0-9]{32}\b")
_HASH_SHA256_RE = re.compile(r"\b[a-fA-F0-9]{64}\b")


@dataclass
class DialogueTurn:
    """Single turn in a security engagement dialogue."""

    turn_id: int
    role: str  # "user", "assistant", "system", "tool"
    content: str
    timestamp: str = ""
    tool_name: str = ""
    tool_output: str = ""


@dataclass
class CompressedEntry:
    """Atomic memory unit produced by Stage 1 compression."""

    entry_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    lossless_restatement: str = ""  # Self-contained, no pronouns, absolute refs
    memory_type: str = "note"
    confidence: str = "confirmed"

    # Security-specific extracted metadata
    targets: list[str] = field(default_factory=list)  # IPs, domains
    cve_ids: list[str] = field(default_factory=list)
    mitre_attack: list[str] = field(default_factory=list)
    severity: str = ""
    tools_used: list[str] = field(default_factory=list)
    hashes: list[str] = field(default_factory=list)

    # General metadata
    keywords: list[str] = field(default_factory=list)
    persons: list[str] = field(default_factory=list)
    entities: list[str] = field(default_factory=list)
    timestamp: str = ""
    topic: str = ""

    # Source tracking
    source_turns: list[int] = field(default_factory=list)
    engagement_id: str = ""
    source_skill: str = ""

    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class DensityGate:
    """
    Information density gate — filters out low-information dialogue turns.

    Uses heuristic scoring based on:
    - Presence of technical content (IPs, CVEs, commands, code)
    - Content length relative to boilerplate
    - Ratio of unique terms to total terms
    """

    # Boilerplate patterns that indicate low information density
    LOW_INFO_PATTERNS = [
        r"^(?:ok|okay|sure|yes|no|thanks|thank you|got it|understood)[\.\!\?]?$",
        r"^(?:let me|i'll|i will|going to)\s",
        r"^(?:here (?:is|are)|sure,?\s+here)",
    ]

    def __init__(self, min_score: float = 0.3):
        self.min_score = min_score
        self._low_info_res = [
            re.compile(p, re.IGNORECASE) for p in self.LOW_INFO_PATTERNS
        ]

    def score(self, turn: DialogueTurn) -> float:
        """Score information density of a dialogue turn (0.0 - 1.0)."""
        text = turn.content.strip()
        if not text:
            return 0.0

        score = 0.0

        # Length score (longer usually = more info, diminishing returns)
        length = len(text)
        if length > 200:
            score += 0.3
        elif length > 50:
            score += 0.15

        # Technical content indicators
        if _IP_RE.search(text):
            score += 0.15
        if _CVE_RE.search(text):
            score += 0.2
        if _MITRE_RE.search(text):
            score += 0.15
        if "```" in text:  # Code blocks
            score += 0.2
        if _HASH_SHA256_RE.search(text) or _HASH_MD5_RE.search(text):
            score += 0.1

        # Unique term ratio (lexical diversity)
        words = text.lower().split()
        if words:
            unique_ratio = len(set(words)) / len(words)
            score += unique_ratio * 0.2

        # Penalize boilerplate
        for pat in self._low_info_res:
            if pat.match(text):
                score *= 0.3
                break

        # Tool output is almost always high-info
        if turn.role == "tool" and turn.tool_output:
            score = max(score, 0.5)

        return min(score, 1.0)

    def should_include(self, turn: DialogueTurn) -> bool:
        return self.score(turn) >= self.min_score


def extract_security_entities(text: str) -> dict[str, list[str]]:
    """Extract security-relevant entities from text using regex patterns."""
    return {
        "ips": list(set(_IP_RE.findall(text))),
        "cves": list(set(_CVE_RE.findall(text))),
        "mitre": list(set(_MITRE_RE.findall(text))),
        "domains": [
            d
            for d in set(_DOMAIN_RE.findall(text))
            if not d.endswith((".py", ".js", ".md", ".yaml", ".json", ".txt"))
        ],
        "hashes_sha256": list(set(_HASH_SHA256_RE.findall(text))),
        "hashes_md5": list(set(_HASH_MD5_RE.findall(text))),
    }


class SemanticCompressor:
    """
    Stage 1: Semantic Structured Compression.

    Processes dialogue windows through:
    1. Density gating — filter low-info turns
    2. Entity extraction — security-specific pattern matching
    3. LLM compression — coreference resolution + temporal anchoring
    4. Atomic entry creation — self-contained memory units

    When no LLM is available, falls back to heuristic extraction.
    """

    def __init__(
        self,
        llm_client: Any = None,
        window_size: int = 20,
        overlap_size: int = 2,
        density_threshold: float = 0.3,
        model: str = "claude-sonnet-4-20250514",
    ):
        self.llm_client = llm_client
        self.window_size = window_size
        self.overlap_size = overlap_size
        self.density_gate = DensityGate(min_score=density_threshold)
        self.model = model
        self._previous_context: str = ""

    async def compress(
        self,
        turns: list[DialogueTurn],
        engagement_id: str = "",
        source_skill: str = "",
    ) -> list[CompressedEntry]:
        """
        Compress dialogue turns into atomic memory entries.

        Args:
            turns: List of dialogue turns to compress
            engagement_id: Current engagement identifier
            source_skill: Which CIPHER skill is active

        Returns:
            List of CompressedEntry objects
        """
        # Step 1: Density gating
        filtered = [t for t in turns if self.density_gate.should_include(t)]
        if not filtered:
            return []

        # Step 2: Window processing
        all_entries: list[CompressedEntry] = []
        for i in range(0, len(filtered), self.window_size - self.overlap_size):
            window = filtered[i : i + self.window_size]
            entries = await self._process_window(window, engagement_id, source_skill)
            all_entries.extend(entries)

        return all_entries

    async def _process_window(
        self,
        window: list[DialogueTurn],
        engagement_id: str,
        source_skill: str,
    ) -> list[CompressedEntry]:
        """Process a single window of dialogue turns."""
        # Aggregate entity extraction across window
        combined_text = " ".join(t.content for t in window)
        entities = extract_security_entities(combined_text)

        if self.llm_client is not None:
            entries = await self._llm_compress(window, entities)
        else:
            entries = self._heuristic_compress(window, entities)

        # Annotate all entries with engagement context
        for entry in entries:
            entry.engagement_id = engagement_id
            entry.source_skill = source_skill
            entry.targets = entities["ips"] + entities["domains"]
            entry.cve_ids = entities["cves"]
            entry.mitre_attack = entities["mitre"]
            entry.hashes = entities["hashes_sha256"] + entities["hashes_md5"]

        self._previous_context = self._build_context_summary(entries)
        return entries

    async def _llm_compress(
        self,
        window: list[DialogueTurn],
        entities: dict[str, list[str]],
    ) -> list[CompressedEntry]:
        """Use LLM for high-quality semantic compression."""
        dialogue_text = self._format_window(window)
        prompt = self._build_extraction_prompt(dialogue_text, entities)

        messages = [
            {
                "role": "system",
                "content": (
                    "You are a security engagement memory compiler. "
                    "Extract atomic, self-contained security facts from engagement dialogues. "
                    "Each fact must be independently understandable without context. "
                    "Always resolve pronouns to actual names/IPs/domains. "
                    "Convert relative times to absolute ISO 8601 timestamps. "
                    "Focus on: findings, IOCs, TTPs, decisions, and evidence."
                ),
            },
            {"role": "user", "content": prompt},
        ]

        try:
            response = await asyncio.to_thread(
                self.llm_client.messages.create,
                model=self.model,
                max_tokens=2000,
                messages=messages,
            )
            text = response.content[0].text
            data = json.loads(text)
            entries_data = data if isinstance(data, list) else data.get("entries", [])

            entries = []
            for item in entries_data:
                entry = CompressedEntry(
                    lossless_restatement=item.get("lossless_restatement", ""),
                    memory_type=item.get("memory_type", "note"),
                    confidence=item.get("confidence", "confirmed"),
                    keywords=item.get("keywords", []),
                    persons=item.get("persons", []),
                    entities=item.get("entities", []),
                    timestamp=item.get("timestamp", ""),
                    topic=item.get("topic", ""),
                    severity=item.get("severity", ""),
                    tools_used=item.get("tools_used", []),
                    source_turns=[t.turn_id for t in window],
                )
                if entry.lossless_restatement:
                    entries.append(entry)
            return entries

        except Exception as e:
            logger.warning("LLM compression failed, falling back to heuristic: %s", e)
            return self._heuristic_compress(window, entities)

    def _heuristic_compress(
        self,
        window: list[DialogueTurn],
        entities: dict[str, list[str]],
    ) -> list[CompressedEntry]:
        """Fallback heuristic compression when no LLM is available."""
        entries = []

        for turn in window:
            # Extract key sentences (those containing security entities)
            sentences = re.split(r"[.!?\n]+", turn.content)
            for sent in sentences:
                sent = sent.strip()
                if len(sent) < 20:
                    continue

                sent_entities = extract_security_entities(sent)
                has_security_content = any(bool(v) for v in sent_entities.values())

                if (
                    has_security_content
                    or self.density_gate.score(DialogueTurn(0, turn.role, sent)) > 0.5
                ):
                    # Determine memory type from content
                    mem_type = "note"
                    if sent_entities["cves"]:
                        mem_type = "finding"
                    elif sent_entities["ips"] or sent_entities["domains"]:
                        mem_type = "ioc"
                    elif sent_entities["mitre"]:
                        mem_type = "ttp"

                    # Extract keywords (content words > 4 chars)
                    words = sent.lower().split()
                    stop = {
                        "the",
                        "and",
                        "for",
                        "that",
                        "this",
                        "with",
                        "from",
                        "have",
                        "has",
                        "been",
                        "were",
                        "was",
                        "are",
                        "will",
                        "would",
                        "could",
                        "should",
                        "into",
                        "about",
                        "which",
                    }
                    keywords = [
                        w.strip(".,;:!?()[]{}\"'")
                        for w in words
                        if len(w) > 4 and w not in stop
                    ][:10]

                    entries.append(
                        CompressedEntry(
                            lossless_restatement=sent,
                            memory_type=mem_type,
                            keywords=keywords,
                            source_turns=[turn.turn_id],
                            timestamp=turn.timestamp
                            or datetime.now(timezone.utc).isoformat(),
                        )
                    )

        return entries

    def _format_window(self, window: list[DialogueTurn]) -> str:
        lines = []
        for turn in window:
            ts = f" [{turn.timestamp}]" if turn.timestamp else ""
            prefix = turn.role.upper()
            if turn.tool_name:
                prefix = f"TOOL({turn.tool_name})"
            lines.append(f"{prefix}{ts}: {turn.content}")
            if turn.tool_output:
                lines.append(f"  OUTPUT: {turn.tool_output[:500]}")
        return "\n".join(lines)

    def _build_extraction_prompt(
        self, dialogue_text: str, entities: dict[str, list[str]]
    ) -> str:
        context_section = ""
        if self._previous_context:
            context_section = f"## Previous Context (avoid duplication):\n{self._previous_context}\n\n---\n"

        entity_hints = ""
        if any(entities.values()):
            parts = []
            if entities["ips"]:
                parts.append(f"IPs: {', '.join(entities['ips'])}")
            if entities["cves"]:
                parts.append(f"CVEs: {', '.join(entities['cves'])}")
            if entities["mitre"]:
                parts.append(f"MITRE: {', '.join(entities['mitre'])}")
            if entities["domains"]:
                parts.append(f"Domains: {', '.join(entities['domains'][:10])}")
            entity_hints = f"\n## Detected Entities:\n{chr(10).join(parts)}\n"

        return f"""{context_section}{entity_hints}
## Engagement Dialogue:
{dialogue_text}

---

## Extraction Requirements:

1. **Self-Contained Facts**: Each entry independently understandable.
   - BAD: "The target is vulnerable" (which target? vulnerable to what?)
   - GOOD: "Host 10.10.14.5 is vulnerable to CVE-2024-1234 (SQL injection in /api/login)"

2. **Coreference Resolution**: Replace ALL pronouns.
   - "it" → the actual IP/domain/service
   - "the target" → specific host identifier

3. **Security Classification**: Assign memory_type:
   - finding: Vulnerability or security issue
   - ioc: IP, domain, hash, URL indicator
   - ttp: Attack technique or procedure
   - credential: Discovered credential reference (NO plaintext)
   - host: Asset/host information
   - network: Network topology or flow
   - decision: Engagement decision with rationale
   - note: General observation

4. **Severity** (for findings): critical, high, medium, low, info

5. **Confidence**: confirmed, inferred, uncertain

Return ONLY valid JSON:
{{
  "entries": [
    {{
      "lossless_restatement": "Complete self-contained security fact...",
      "memory_type": "finding|ioc|ttp|credential|host|network|decision|note",
      "confidence": "confirmed|inferred|uncertain",
      "severity": "critical|high|medium|low|info" or "",
      "keywords": ["keyword1", "keyword2"],
      "tools_used": ["nmap", "burpsuite"],
      "persons": [],
      "entities": ["ACME Corp"],
      "timestamp": "2026-03-17T12:00:00Z" or "",
      "topic": "SQL injection in login endpoint"
    }}
  ]
}}"""

    def _build_context_summary(self, entries: list[CompressedEntry]) -> str:
        if not entries:
            return ""
        return "\n".join(f"- {e.lossless_restatement}" for e in entries[-5:])
