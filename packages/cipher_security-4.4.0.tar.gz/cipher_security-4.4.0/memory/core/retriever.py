# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""
CIPHER Memory — Stage 3: Intent-Aware Retrieval Planning

Intelligent retrieval that understands query intent and adapts strategy:
- Query complexity analysis → determines retrieval depth
- Multi-query decomposition → parallel sub-queries for complex questions
- Hybrid search fusion → semantic + lexical + symbolic via RRF
- Reflection-based refinement → iterative retrieval for complex queries

Inspired by SimpleMem's Stage 3 (Intent-Aware Retrieval Planning).

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from .engine import CipherMemory, MemoryEntry

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Query Intent Classification
# ---------------------------------------------------------------------------


class QueryIntent:
    """Security query intent categories with retrieval strategy mapping."""

    # Intent → (description, search_depth, requires_symbolic)
    INTENTS = {
        "finding_lookup": (
            "Looking up specific vulnerability or finding",
            "shallow",
            True,
        ),
        "ioc_search": (
            "Searching for indicators of compromise",
            "shallow",
            True,
        ),
        "ttp_mapping": (
            "Mapping techniques, tactics, procedures",
            "medium",
            True,
        ),
        "engagement_context": (
            "Getting context for an engagement",
            "deep",
            True,
        ),
        "temporal_query": (
            "Time-based query about when something happened",
            "medium",
            True,
        ),
        "comparative": (
            "Comparing findings, hosts, or engagements",
            "deep",
            False,
        ),
        "causal": (
            "Understanding why or how something happened",
            "deep",
            False,
        ),
        "general": (
            "General security knowledge query",
            "shallow",
            False,
        ),
    }

    # Keyword patterns for intent detection
    PATTERNS: dict[str, list[str]] = {
        "finding_lookup": [
            "vulnerability",
            "vuln",
            "finding",
            "cve-",
            "exploit",
            "weakness",
            "injection",
            "xss",
            "sqli",
            "rce",
            "ssrf",
            "csrf",
        ],
        "ioc_search": [
            "ioc",
            "indicator",
            "hash",
            "ip address",
            "domain",
            "c2",
            "beacon",
            "callback",
            "malware",
            "sample",
        ],
        "ttp_mapping": [
            "technique",
            "tactic",
            "procedure",
            "mitre",
            "att&ck",
            "t1",
            "lateral",
            "persistence",
            "privilege",
        ],
        "engagement_context": [
            "engagement",
            "pentest",
            "assessment",
            "audit",
            "scope",
            "client",
            "target",
            "progress",
            "status",
        ],
        "temporal_query": [
            "when",
            "timeline",
            "first",
            "last",
            "before",
            "after",
            "during",
            "recently",
            "latest",
            "oldest",
        ],
        "comparative": [
            "compare",
            "difference",
            "between",
            "versus",
            "vs",
            "similar",
            "different",
            "common",
        ],
        "causal": [
            "why",
            "how",
            "because",
            "cause",
            "root cause",
            "reason",
            "led to",
            "resulted in",
            "impact",
        ],
    }


@dataclass
class RetrievalPlan:
    """Structured retrieval plan for a query."""

    intent: str = "general"
    complexity: float = 0.3  # 0.0 - 1.0
    sub_queries: list[str] = field(default_factory=list)
    required_filters: dict[str, str] = field(default_factory=dict)
    search_depth: str = "shallow"  # shallow (top-5), medium (top-15), deep (top-30)
    needs_reflection: bool = False


class IntentClassifier:
    """Classify security query intent using keyword matching."""

    def classify(self, query: str) -> str:
        """Return the most likely intent for a query."""
        query_lower = query.lower()
        scores: dict[str, int] = {}

        for intent, keywords in QueryIntent.PATTERNS.items():
            score = sum(1 for kw in keywords if kw in query_lower)
            if score > 0:
                scores[intent] = score

        if not scores:
            return "general"
        return max(scores, key=scores.get)  # type: ignore[arg-type]

    def estimate_complexity(self, query: str) -> float:
        """Estimate query complexity (0.0 = trivial, 1.0 = very complex)."""
        score = 0.0

        # Length-based
        words = query.split()
        if len(words) > 20:
            score += 0.2
        elif len(words) > 10:
            score += 0.1

        # Multi-hop indicators
        multi_hop = ["and", "also", "then", "after that", "in addition"]
        score += sum(0.1 for kw in multi_hop if kw in query.lower())

        # Comparative/causal is inherently complex
        query_lower = query.lower()
        if any(w in query_lower for w in ["compare", "why", "how did"]):
            score += 0.3

        # Multiple entity references
        from .compressor import extract_security_entities

        entities = extract_security_entities(query)
        entity_count = sum(len(v) for v in entities.values())
        if entity_count > 3:
            score += 0.2
        elif entity_count > 1:
            score += 0.1

        return min(score, 1.0)


class QueryDecomposer:
    """Decompose complex queries into targeted sub-queries."""

    def decompose(self, query: str, intent: str) -> list[str]:
        """Break a complex query into focused sub-queries."""
        # Simple heuristic decomposition
        sub_queries = [query]

        # Split on conjunctions
        if " and " in query.lower():
            parts = re.split(r"\s+and\s+", query, flags=re.IGNORECASE)
            if len(parts) > 1 and all(len(p.split()) > 3 for p in parts):
                sub_queries = parts

        # For comparative queries, search each entity separately
        elif intent == "comparative":
            # Extract compared entities
            from .compressor import extract_security_entities

            entities = extract_security_entities(query)
            targets = entities["ips"] + entities["domains"] + entities["cves"]
            if len(targets) >= 2:
                sub_queries = [f"{query} {target}" for target in targets[:3]]

        # For causal queries, search for both the event and the cause
        elif intent == "causal":
            sub_queries = [query]
            # Add a stripped version focused on the event
            stripped = re.sub(
                r"\b(why|how|because|cause)\b", "", query, flags=re.IGNORECASE
            ).strip()
            if stripped != query and len(stripped) > 10:
                sub_queries.append(stripped)

        return sub_queries[:4]  # Max 4 sub-queries


# ---------------------------------------------------------------------------
# Adaptive Retriever
# ---------------------------------------------------------------------------


class AdaptiveRetriever:
    """
    Stage 3: Intent-Aware Adaptive Retrieval.

    Combines intent classification, query decomposition, and hybrid search
    with optional reflection-based iterative refinement.

    Usage:
        retriever = AdaptiveRetriever(memory)
        results = retriever.retrieve("What CVEs affect 10.10.14.5?")
    """

    # Depth → top_k mapping
    DEPTH_MAP = {"shallow": 5, "medium": 15, "deep": 30}

    def __init__(
        self,
        memory: CipherMemory,
        enable_reflection: bool = True,
        max_reflection_rounds: int = 2,
    ):
        self.memory = memory
        self.classifier = IntentClassifier()
        self.decomposer = QueryDecomposer()
        self.enable_reflection = enable_reflection
        self.max_reflection_rounds = max_reflection_rounds

    def plan(self, query: str) -> RetrievalPlan:
        """Create a retrieval plan for the query."""
        intent = self.classifier.classify(query)
        complexity = self.classifier.estimate_complexity(query)
        _desc, depth, needs_symbolic = QueryIntent.INTENTS.get(
            intent, ("", "shallow", False)
        )

        sub_queries = (
            self.decomposer.decompose(query, intent) if complexity > 0.5 else [query]
        )

        # Extract filter hints from query
        filters: dict[str, str] = {}
        from .compressor import extract_security_entities

        entities = extract_security_entities(query)
        if entities["cves"]:
            filters["cve_id"] = entities["cves"][0]
        if entities["mitre"]:
            filters["mitre_technique"] = entities["mitre"][0]

        # Engagement ID extraction (e.g., "engagement ENG-001")
        eng_match = re.search(r"engagement\s+([A-Za-z0-9-]+)", query, re.IGNORECASE)
        if eng_match:
            filters["engagement_id"] = eng_match.group(1)

        return RetrievalPlan(
            intent=intent,
            complexity=complexity,
            sub_queries=sub_queries,
            required_filters=filters,
            search_depth=depth,
            needs_reflection=complexity > 0.6 and self.enable_reflection,
        )

    def retrieve(
        self,
        query: str,
        engagement_id: str = "",
        limit: Optional[int] = None,
    ) -> list[MemoryEntry]:
        """
        Retrieve relevant memories with intent-aware planning.

        Args:
            query: Search query
            engagement_id: Optional engagement filter
            limit: Override result limit

        Returns:
            Ranked list of MemoryEntry objects
        """
        plan = self.plan(query)

        if engagement_id:
            plan.required_filters["engagement_id"] = engagement_id

        top_k = limit or self.DEPTH_MAP.get(plan.search_depth, 10)

        logger.info(
            "Retrieval plan: intent=%s complexity=%.2f depth=%s queries=%d",
            plan.intent,
            plan.complexity,
            plan.search_depth,
            len(plan.sub_queries),
        )

        # Execute sub-queries and merge results
        all_results: list[MemoryEntry] = []
        seen_ids: set[str] = set()

        for sub_query in plan.sub_queries:
            results = self.memory.search(
                query=sub_query,
                engagement_id=plan.required_filters.get("engagement_id", ""),
                memory_type=plan.required_filters.get("memory_type", ""),
                severity=plan.required_filters.get("severity", ""),
                mitre_technique=plan.required_filters.get("mitre_technique", ""),
                limit=top_k,
            )
            for entry in results:
                if entry.entry_id not in seen_ids:
                    seen_ids.add(entry.entry_id)
                    all_results.append(entry)

        # Reflection: check if we have enough relevant results
        if plan.needs_reflection and len(all_results) < 3:
            all_results = self._reflect_and_retry(
                query, plan, all_results, seen_ids, top_k
            )

        return all_results[:top_k]

    def _reflect_and_retry(
        self,
        query: str,
        plan: RetrievalPlan,
        current_results: list[MemoryEntry],
        seen_ids: set[str],
        top_k: int,
    ) -> list[MemoryEntry]:
        """Iterative refinement when initial results are insufficient."""
        for round_num in range(self.max_reflection_rounds):
            # Generate alternative queries
            alt_queries = self._generate_alternative_queries(query, current_results)

            for alt_query in alt_queries:
                results = self.memory.search(
                    query=alt_query,
                    engagement_id=plan.required_filters.get("engagement_id", ""),
                    limit=top_k,
                )
                for entry in results:
                    if entry.entry_id not in seen_ids:
                        seen_ids.add(entry.entry_id)
                        current_results.append(entry)

            if len(current_results) >= 3:
                break

        return current_results

    def _generate_alternative_queries(
        self,
        original_query: str,
        current_results: list[MemoryEntry],
    ) -> list[str]:
        """Generate alternative search queries based on current results."""
        alternatives: list[str] = []

        # Try broader query (remove specifics)
        broader = re.sub(r"CVE-\d+-\d+", "", original_query).strip()
        broader = re.sub(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "", broader).strip()
        if broader and broader != original_query:
            alternatives.append(broader)

        # Try extracting key terms
        words = original_query.split()
        content_words = [
            w
            for w in words
            if len(w) > 4
            and w.lower()
            not in {
                "what",
                "where",
                "when",
                "which",
                "about",
                "find",
                "search",
                "look",
                "show",
                "there",
            }
        ]
        if content_words:
            alternatives.append(" ".join(content_words[:5]))

        # Try using entities from current results
        if current_results:
            for entry in current_results[:2]:
                if entry.tags:
                    alternatives.append(" ".join(entry.tags[:3]))

        return alternatives[:3]


# ---------------------------------------------------------------------------
# Context Builder — Token-budgeted context assembly
# ---------------------------------------------------------------------------


class ContextBuilder:
    """
    Build token-budgeted context from retrieved memories.

    Assembles memories into a structured context block suitable for
    injection into LLM prompts, respecting token budget constraints.
    """

    def __init__(self, max_tokens: int = 4000, chars_per_token: float = 4.0):
        self.max_tokens = max_tokens
        self.chars_per_token = chars_per_token

    def build(
        self,
        entries: list[MemoryEntry],
        query: str = "",
    ) -> str:
        """
        Build structured context from memory entries.

        Returns a formatted string suitable for system prompt injection.
        """
        if not entries:
            return ""

        max_chars = int(self.max_tokens * self.chars_per_token)
        sections: dict[str, list[str]] = {
            "findings": [],
            "iocs": [],
            "ttps": [],
            "decisions": [],
            "context": [],
        }

        for entry in entries:
            line = f"- {entry.content}"
            if entry.severity:
                line = f"- [{entry.severity.upper()}] {entry.content}"
            if entry.mitre_attack:
                attacks = ", ".join(entry.mitre_attack[:3])
                line += f" ({attacks})"

            mem_type = entry.memory_type.value
            if mem_type == "finding":
                sections["findings"].append(line)
            elif mem_type == "ioc":
                sections["iocs"].append(line)
            elif mem_type == "ttp":
                sections["ttps"].append(line)
            elif mem_type == "decision":
                sections["decisions"].append(line)
            else:
                sections["context"].append(line)

        # Assemble within budget
        parts: list[str] = ["## Engagement Memory"]
        current_chars = len(parts[0])

        section_labels = {
            "findings": "### Findings",
            "iocs": "### Indicators of Compromise",
            "ttps": "### Techniques & Procedures",
            "decisions": "### Decisions",
            "context": "### Context",
        }

        for key, label in section_labels.items():
            items = sections[key]
            if not items:
                continue

            section_text = f"\n{label}\n" + "\n".join(items)
            if current_chars + len(section_text) > max_chars:
                # Truncate items to fit
                remaining = max_chars - current_chars - len(f"\n{label}\n")
                if remaining > 100:
                    truncated: list[str] = []
                    chars_used = 0
                    for item in items:
                        if chars_used + len(item) + 1 > remaining:
                            break
                        truncated.append(item)
                        chars_used += len(item) + 1
                    if truncated:
                        parts.append(f"\n{label}")
                        parts.extend(truncated)
                break

            parts.append(f"\n{label}")
            parts.extend(items)
            current_chars += len(section_text)

        return "\n".join(parts)
