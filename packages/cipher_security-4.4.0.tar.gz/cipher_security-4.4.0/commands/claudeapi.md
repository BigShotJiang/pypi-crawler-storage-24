<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: cipher:claudeapi
description: Run a CIPHER security query through Claude API
---

Run the CIPHER security gateway with the provided query using the Claude API backend. Return the response exactly as received.

```bash
cipher-gw --backend claude "$ARGUMENTS"
```

If cipher-gw is not found on PATH:

```bash
uv run --directory /home/void/Documents/cipher cipher-gw --backend claude "$ARGUMENTS"
```

Return the full output without modification.
