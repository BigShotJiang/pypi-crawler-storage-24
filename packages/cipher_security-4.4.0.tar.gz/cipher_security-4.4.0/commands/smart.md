<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: cipher:smart
description: Run a CIPHER security query with auto-routing (simple→Ollama, complex→Claude API)
---

Run the CIPHER security gateway with smart backend routing. Simple queries go to local Ollama, complex queries go to Claude API. Return the response exactly as received.

```bash
cipher-gw --smart "$ARGUMENTS"
```

If cipher-gw is not found on PATH:

```bash
uv run --directory /home/void/Documents/cipher cipher-gw --smart "$ARGUMENTS"
```

Return the full output without modification.
