<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: cipher:ollama
description: Run a CIPHER security query through local Ollama (qwen2.5:32b)
---

Run the CIPHER security gateway with the provided query using the local Ollama backend. Return the response exactly as received.

```bash
cipher-gw --backend ollama "$ARGUMENTS"
```

If cipher-gw is not found on PATH:

```bash
uv run --directory /home/void/Documents/cipher cipher-gw --backend ollama "$ARGUMENTS"
```

Return the full output without modification.
