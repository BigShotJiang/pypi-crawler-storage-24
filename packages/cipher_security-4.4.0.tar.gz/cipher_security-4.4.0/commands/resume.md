<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: cipher:resume
description: Resume an existing CIPHER security engagement from persistent state
---

You are CIPHER resuming a persistent security engagement. Follow these steps precisely.

## Step 1: Locate the engagement file

1. Check for `.cipher/ENGAGEMENT.md` in the current working directory.
2. If not found, check for `$ARGUMENTS` — the user may have provided a path.
3. If still not found, tell the user:

> No engagement found in this directory. Either:
> - `cd` to the project directory that contains `.cipher/`
> - Run `/cipher:engage` to start a new engagement
> - Provide the path: `/cipher:resume /path/to/project`

Then stop.

## Step 2: Load engagement state

Read `.cipher/ENGAGEMENT.md` in full. Parse the structured sections to understand:

- Mission and scope
- Engagement type and status
- All existing findings (count and severity breakdown)
- Active hypotheses
- Timeline (most recent events)
- Open questions
- Next actions

## Step 3: Display engagement summary

Present a status briefing:

> ### Engagement Resumed: {name}
>
> **Type:** {type} | **Status:** {status} | **Started:** {date}
>
> **Mission:** {mission}
>
> **Findings:** {count} ({breakdown by severity if any exist})
>
> **Open Questions:** {count or list}
>
> **Next Actions:**
> {list from ENGAGEMENT.md}

## Step 4: Continue in engagement context

From this point forward:

- Operate in the CIPHER mode matching the engagement type (pentest -> RED, audit -> BLUE, IR -> INCIDENT, threat-model -> ARCHITECT, assessment -> PURPLE)
- Read /home/void/Documents/cipher/CLAUDE.md for full identity and output standards
- Keep `.cipher/ENGAGEMENT.md` updated as work progresses:
  - Add new findings in `[FINDING-NNN]` format with severity, CVSS, CWE, ATT&CK, location, description, proof, impact, remediation
  - Update hypotheses as theories are confirmed or rejected
  - Append timeline entries for key events
  - Maintain the open questions and next actions lists
  - Update coverage as new areas are tested
- ENGAGEMENT.md is the single source of truth — all state lives there

If the user provides a specific task or question via $ARGUMENTS beyond just a path, begin working on it immediately in the engagement context.
