<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: adversary-simulation
description: >-
  Adversary simulation and emulation covering threat actor profiling, CALDERA
  operations, APT emulation plans, custom C2 framework development, attack
  infrastructure deployment, ransomware emulation, phishing simulation, lateral
  movement testing, data exfiltration scenarios, persistence mechanism validation,
  defense evasion testing, and initial access simulation. Enables purple team
  operations that validate detection and response capabilities against realistic
  threat scenarios mapped to MITRE ATT&CK.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - adversary-emulation
  - purple-team
  - caldera
  - apt-emulation
  - c2-frameworks
  - attack-infrastructure
  - ransomware-emulation
  - phishing-simulation
  - lateral-movement
  - data-exfiltration
  - persistence-testing
  - defense-evasion
  - initial-access
  - mitre-attack
version: "1.0"
author: defconxt
license: AGPL-3.0
compatibility: Designed for Claude Code, GitHub Copilot, OpenAI Codex, Cursor, Gemini CLI, and any agentskills.io-compatible agent.
metadata:
  mitre-attack: ["T1583", "T1588", "T1566", "T1078", "T1059", "T1021", "T1048", "T1547", "T1562", "T1486"]
  frameworks: ["MITRE ATT&CK", "MITRE CALDERA", "Atomic Red Team", "SCYTHE", "MITRE Engenuity"]
---

# Adversary Simulation

## When to Use

Activate when the operator asks about adversary emulation plans, purple team
exercises, threat actor profiling, C2 framework development, attack infrastructure
setup, ransomware simulation, phishing campaigns, lateral movement testing,
exfiltration scenarios, persistence validation, evasion testing, or initial access
simulation.

Mode: `[MODE: RED]` for offensive simulation; `[MODE: PURPLE]` for detection validation; `[MODE: BLUE]` for defensive tuning against emulated threats.

## Prerequisites

- Authorization and signed Rules of Engagement (RoE) for simulation scope
- MITRE ATT&CK Navigator for coverage mapping
- CALDERA server or equivalent adversary emulation platform
- Isolated lab or segmented network for destructive tests
- Coordination with SOC/IR teams for purple team exercises

## Quick Reference

| Technique | Primary Tools | ATT&CK Tactic |
|-----------|--------------|----------------|
| Adversary profiling | ATT&CK Navigator, threat intel feeds | Reconnaissance |
| CALDERA operations | CALDERA, Stockpile plugins | Multiple |
| APT emulation | ATT&CK Evaluations, custom playbooks | Multiple |
| Custom C2 | Sliver, Mythic, custom frameworks | Command & Control |
| Attack infrastructure | Redirectors, DNS, certificates | Resource Development |
| Ransomware emulation | Safe encryption simulators | Impact |
| Phishing simulation | GoPhish, King Phisher | Initial Access |
| Lateral movement | PsExec, WMI, RDP, SSH | Lateral Movement |
| Data exfiltration | DNS tunneling, HTTPS, steganography | Exfiltration |
| Persistence testing | Registry, scheduled tasks, services | Persistence |
| Defense evasion | Process injection, AMSI bypass, LOLBins | Defense Evasion |
| Initial access | Spearphishing, exploit public apps | Initial Access |

## Workflow

### 1. Engagement Scoping

Define simulation objectives, threat actor selection, and rules of engagement:

```
Engagement Scope:
├── Objective: Validate detection coverage for [THREAT_ACTOR] TTPs
├── Rules of Engagement
│   ├── Authorized target systems and networks
│   ├── Prohibited actions (production data, availability impact)
│   ├── Communication plan and emergency contacts
│   └── Evidence handling and cleanup requirements
├── Threat Actor Selection
│   ├── Intelligence-driven: emulate specific APT group
│   ├── Capability-driven: test specific TTP categories
│   └── Gap-driven: target known detection blind spots
└── Success Criteria
    ├── Detection rate per tactic (target: >80%)
    ├── Mean time to detect (MTTD) per technique
    └── Alert fidelity (true positive rate)
```

### 2. Adversary Profile Development

Build threat actor profiles from CTI sources:

```bash
# Export ATT&CK Navigator layer for target threat group
# Map techniques to detection coverage
python3 scripts/agent.py profile --actor "APT29" --format navigator

# Generate emulation plan from profile
python3 scripts/agent.py plan --actor "APT29" --scope network
```

### 3. Infrastructure Deployment

Stand up isolated attack infrastructure:

```bash
# Deploy CALDERA server
docker run -d -p 8888:8888 mitre/caldera:latest

# Configure redirectors and C2 channels
# Use dedicated VPS with clean IP reputation
# Deploy HTTPS certificates via Let's Encrypt
```

### 4. Emulation Execution

Execute adversary playbook with logging and coordination:

```
Execution Phases:
├── Phase 1: Initial Access — Phishing, exploit, valid accounts
├── Phase 2: Execution & Persistence — Establish foothold
├── Phase 3: Discovery & Lateral Movement — Expand access
├── Phase 4: Collection & Exfiltration — Achieve objectives
├── Phase 5: Impact (if authorized) — Ransomware simulation
└── Cleanup: Remove all artifacts, restore systems
```

### 5. Detection Validation

For each executed technique, validate defensive coverage:

```
Detection Matrix:
├── Technique: [ATT&CK ID] — [Name]
├── Executed: [timestamp] on [target]
├── Detection
│   ├── SIEM alert triggered: Yes/No (latency: Xs)
│   ├── EDR alert triggered: Yes/No (latency: Xs)
│   ├── NDR alert triggered: Yes/No (latency: Xs)
│   └── SOC analyst identified: Yes/No (latency: Xm)
├── Gap Analysis
│   ├── Log source available: Yes/No
│   ├── Detection rule exists: Yes/No
│   └── Rule triggered correctly: Yes/No
└── Remediation: [New rule / tuning / log source needed]
```

### 6. Reporting and Remediation

Produce findings mapped to ATT&CK with detection improvement plan:

```
Report Structure:
├── Executive Summary — Business risk and detection posture
├── Threat Actor Profile — TTPs emulated and rationale
├── Technique Results — Per-technique detection matrix
├── Coverage Heatmap — ATT&CK Navigator overlay
├── Detection Gaps — Prioritized by risk and exploitability
├── Remediation Plan — New rules, log sources, tuning
└── Retest Schedule — Validate fixes within 30 days
```

## Verification

- [ ] Rules of engagement signed and communicated
- [ ] Threat actor profile mapped to ATT&CK techniques
- [ ] Attack infrastructure isolated from production
- [ ] All techniques executed with timestamps and evidence
- [ ] Detection matrix completed for every technique
- [ ] Gaps identified and remediation plan delivered
- [ ] Cleanup verified — no residual artifacts on targets

## Detection Opportunities

Purple team exercises should validate these detection layers:
- Process creation telemetry for execution techniques
- Network connection logs for C2 and exfiltration
- Authentication events for lateral movement and valid accounts
- File system monitoring for persistence mechanisms
- Registry and WMI event subscriptions for defense evasion
- Email gateway logs for phishing simulation delivery

## References

- [MITRE ATT&CK](https://attack.mitre.org/) — Adversarial tactics, techniques, and procedures
- [MITRE CALDERA](https://caldera.mitre.org/) — Automated adversary emulation
- [Atomic Red Team](https://atomicredteam.io/) — Library of ATT&CK-mapped tests
- [SCYTHE](https://www.scythe.io/) — Adversary emulation platform
- [MITRE Engenuity ATT&CK Evaluations](https://attackevals.mitre-engenuity.org/) — Vendor detection benchmarks
- [Center for Threat-Informed Defense](https://ctid.mitre-engenuity.org/) — Adversary emulation library
