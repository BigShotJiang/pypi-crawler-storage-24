<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# implementing-wireless-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `scan --interface <iface> [--duration <sec>]` | Scan wireless environment |
| `enumerate-clients --bssid <mac>` | Enumerate associated clients |
| `evil-twin --ssid <name> --channel <ch> --interface <iface>` | Deploy evil twin AP |
| `captive-portal --interface <iface> --template <name>` | Deploy captive portal |
| `deauth --bssid <mac> [--count <n>]` | Deauthentication test |
| `capture-handshake --bssid <mac> --output <file>` | Capture WPA handshake |
| `report --scan-data <file> --output <file>` | Generate assessment report |
