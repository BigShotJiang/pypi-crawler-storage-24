<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-cloud-attack-simulation
description: >-
  Simulate cloud-native attack paths across AWS, Azure, and GCP environments
  including privilege escalation, lateral movement between services, storage
  exfiltration, and identity federation abuse to validate cloud security posture.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - cloud-security
  - aws-attack
  - azure-attack
  - gcp-attack
  - cloud-pentesting
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1078.004", "T1530", "T1537", "T1580", "T1619"]
  frameworks: ["MITRE ATT&CK Cloud", "CIS Benchmarks", "CSA CCM"]
  tools: ["python3", "pacu", "cloudfox", "prowler"]
---

# Performing Cloud Attack Simulation

## Overview

Cloud attack simulation replicates adversary techniques targeting cloud
infrastructure — from initial access via stolen credentials or SSRF to
privilege escalation through IAM misconfigurations, lateral movement across
services, and data exfiltration from storage buckets. These simulations
validate cloud security posture management, IAM least privilege, and cloud
detection and response capabilities.

## Prerequisites

- Tools: `python3`, Pacu, CloudFox, Prowler, cloud provider CLIs
- Authorized cloud assessment scope with account/subscription boundaries
- Dedicated test credentials with defined starting permissions
- Cloud-native SIEM or detection stack for alert correlation

## Workflow

### Step 1: Cloud Reconnaissance

```bash
# Enumerate cloud resources and permissions from initial access
python3 scripts/agent.py enumerate --provider aws --profile test-role

# Map IAM privilege escalation paths
python3 scripts/agent.py privesc-paths --provider aws --principal arn:aws:iam::123:role/test
```

### Step 2: Simulate Privilege Escalation

```bash
# Test IAM privilege escalation techniques
python3 scripts/agent.py escalate --provider aws --technique iam-passrole

# Enumerate cross-account trust relationships
python3 scripts/agent.py cross-account --provider aws
```

### Step 3: Lateral Movement and Exfiltration

```bash
# Simulate lateral movement between cloud services
python3 scripts/agent.py lateral --provider aws --source lambda --target ec2

# Test storage exfiltration paths
python3 scripts/agent.py exfil-test --provider aws --bucket target-data --dry-run
```

### Step 4: Generate Cloud Security Report

```bash
# Produce cloud attack simulation report
python3 scripts/agent.py report --provider aws --output cloud-report.json
```

## Verification

- [ ] Cloud resources enumerated within authorized scope
- [ ] IAM privilege escalation paths identified and tested
- [ ] Lateral movement between services documented
- [ ] Storage exfiltration controls validated
- [ ] Cloud detection stack alerted on simulated attack techniques

## References

- [MITRE ATT&CK Cloud Matrix](https://attack.mitre.org/matrices/enterprise/cloud/) — Cloud-specific techniques
- [CIS Cloud Benchmarks](https://www.cisecurity.org/benchmark) — Cloud hardening baselines
