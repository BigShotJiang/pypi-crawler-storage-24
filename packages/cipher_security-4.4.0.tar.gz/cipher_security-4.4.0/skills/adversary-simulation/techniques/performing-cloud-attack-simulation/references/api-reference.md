<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-cloud-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --provider <cloud> --profile <name>` | Enumerate cloud resources and permissions |
| `privesc-paths --provider <cloud> --principal <arn>` | Map IAM privilege escalation paths |
| `escalate --provider <cloud> --technique <name>` | Test privilege escalation technique |
| `cross-account --provider <cloud>` | Enumerate cross-account trust relationships |
| `lateral --provider <cloud> --source <svc> --target <svc>` | Lateral movement simulation |
| `exfil-test --provider <cloud> --bucket <name> [--dry-run]` | Test exfiltration paths |
| `report --provider <cloud> --output <file>` | Generate simulation report |
