<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# implementing-insider-threat-emulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `scenarios --profile <type> --output <file>` | Generate insider threat scenarios |
| `list-personas` | List available insider threat personas |
| `stage-data --method <type> --volume <size> --target <path>` | Simulate data staging |
| `exfiltrate --method <type> --data <file> [--dry-run]` | Simulate exfiltration |
| `access-abuse --user <name> --resource <target>` | Test unauthorized access |
| `cred-share --user <name> --location <loc>` | Credential sharing detection |
| `correlate --actions <file> --ueba-export <file>` | Correlate with UEBA alerts |
| `report --scope <scope> --output <file>` | Generate assessment report |
