#!/usr/bin/env python3
"""Agent tooling for insider threat emulation."""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


def generate_scenarios(profile: str, output: str) -> dict:
    """Generate insider threat scenario playbook."""
    return {
        "action": "scenarios",
        "profile": profile,
        "output": output,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "status": "scenarios_generated",
    }


def list_personas() -> dict:
    """List available insider threat persona templates."""
    personas = [
        {"name": "privileged-admin", "risk": "high", "access": "domain-admin"},
        {"name": "disgruntled-employee", "risk": "high", "access": "standard"},
        {"name": "negligent-user", "risk": "medium", "access": "standard"},
        {"name": "departing-employee", "risk": "high", "access": "standard"},
    ]
    return {"action": "list_personas", "personas": personas}


def stage_data(method: str, volume: str, target: str) -> dict:
    """Simulate data staging to removable media or cloud."""
    return {
        "action": "stage_data",
        "method": method,
        "volume": volume,
        "target": target,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "status": "staging_complete",
    }


def exfiltrate(method: str, data: str, dry_run: bool = True) -> dict:
    """Simulate exfiltration via authorized channels."""
    return {
        "action": "exfiltrate",
        "method": method,
        "data": data,
        "dry_run": dry_run,
        "status": "exfiltration_simulated",
    }


def access_abuse(user: str, resource: str) -> dict:
    """Test unauthorized access to sensitive resources."""
    return {
        "action": "access_abuse",
        "user": user,
        "resource": resource,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "status": "access_tested",
    }


def cred_share(user: str, location: str) -> dict:
    """Simulate credential sharing detection."""
    return {
        "action": "cred_share",
        "user": user,
        "location": location,
        "status": "cred_share_simulated",
    }


def correlate(actions_file: str, ueba_export: str) -> dict:
    """Correlate insider actions with UEBA alerts."""
    actions_path = Path(actions_file)
    ueba_path = Path(ueba_export)
    if not actions_path.exists():
        return {"action": "correlate", "error": f"Not found: {actions_file}"}
    if not ueba_path.exists():
        return {"action": "correlate", "error": f"Not found: {ueba_export}"}
    return {
        "action": "correlate",
        "actions_file": actions_file,
        "ueba_export": ueba_export,
        "status": "correlation_complete",
    }


def report(scope: str, output: str) -> dict:
    """Generate insider threat assessment report."""
    return {
        "action": "report",
        "scope": scope,
        "output": output,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "status": "report_generated",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Insider threat emulation agent")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scen = sub.add_parser("scenarios", help="Generate threat scenarios")
    p_scen.add_argument("--profile", required=True, help="Insider profile")
    p_scen.add_argument("--output", required=True, help="Output file")

    sub.add_parser("list-personas", help="List persona templates")

    p_stg = sub.add_parser("stage-data", help="Simulate data staging")
    p_stg.add_argument("--method", required=True, help="Staging method")
    p_stg.add_argument("--volume", required=True, help="Data volume")
    p_stg.add_argument("--target", required=True, help="Staging target")

    p_exf = sub.add_parser("exfiltrate", help="Simulate exfiltration")
    p_exf.add_argument("--method", required=True, help="Exfiltration method")
    p_exf.add_argument("--data", required=True, help="Data to exfiltrate")
    p_exf.add_argument("--dry-run", action="store_true", help="Dry run mode")

    p_acc = sub.add_parser("access-abuse", help="Test access abuse")
    p_acc.add_argument("--user", required=True, help="Test user")
    p_acc.add_argument("--resource", required=True, help="Target resource")

    p_cred = sub.add_parser("cred-share", help="Credential sharing test")
    p_cred.add_argument("--user", required=True, help="Test user")
    p_cred.add_argument("--location", required=True, help="Anomalous location")

    p_cor = sub.add_parser("correlate", help="Correlate with UEBA")
    p_cor.add_argument("--actions", required=True, help="Actions log file")
    p_cor.add_argument("--ueba-export", required=True, help="UEBA alerts file")

    p_rpt = sub.add_parser("report", help="Generate report")
    p_rpt.add_argument("--scope", default="full", help="Report scope")
    p_rpt.add_argument("--output", required=True, help="Output file path")

    args = parser.parse_args()

    if args.command == "scenarios":
        output = generate_scenarios(args.profile, args.output)
    elif args.command == "list-personas":
        output = list_personas()
    elif args.command == "stage-data":
        output = stage_data(args.method, args.volume, args.target)
    elif args.command == "exfiltrate":
        output = exfiltrate(args.method, args.data, args.dry_run)
    elif args.command == "access-abuse":
        output = access_abuse(args.user, args.resource)
    elif args.command == "cred-share":
        output = cred_share(args.user, args.location)
    elif args.command == "correlate":
        output = correlate(args.actions, args.ueba_export)
    elif args.command == "report":
        output = report(args.scope, args.output)
    else:
        parser.print_help()
        sys.exit(1)

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
