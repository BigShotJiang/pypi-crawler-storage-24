<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-apt-emulation
description: >-
  Execute end-to-end APT emulation campaigns that replicate real-world threat
  actor tradecraft across the full kill chain, from initial access through
  impact, using intelligence-driven playbooks mapped to MITRE ATT&CK.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - apt-emulation
  - threat-emulation
  - kill-chain
  - mitre-attack
  - red-team
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1566", "T1059", "T1078", "T1021", "T1048"]
  frameworks: ["MITRE ATT&CK", "Lockheed Kill Chain", "MITRE Engenuity"]
  tools: ["python3", "atomic-red-team", "invoke-atomicredteam"]
---

# Performing APT Emulation

## Overview

APT emulation replicates the full tradecraft of a specific threat actor using
intelligence-driven playbooks. Unlike generic penetration testing, APT emulation
follows documented procedures from CTI reports to validate whether defenses
detect the exact TTPs used by real adversaries targeting the organization.

## Prerequisites

- Tools: `python3`, Atomic Red Team, adversary emulation platform
- Signed Rules of Engagement with scope boundaries
- Threat actor emulation plan with technique ordering
- Coordination channel with SOC/IR for purple team mode

## Workflow

### Step 1: Select and Plan Emulation

```bash
# Generate emulation plan from MITRE Engenuity library
python3 scripts/agent.py plan --actor "APT29" --phases all

# List available emulation plans
python3 scripts/agent.py list-plans
```

### Step 2: Execute Kill Chain Phases

```python
PHASES = {
    "initial_access": ["T1566.001", "T1566.002", "T1078"],
    "execution": ["T1059.001", "T1059.003", "T1204.002"],
    "persistence": ["T1547.001", "T1053.005", "T1543.003"],
    "privilege_escalation": ["T1548.002", "T1134.001"],
    "defense_evasion": ["T1027", "T1070.004", "T1562.001"],
    "credential_access": ["T1003.001", "T1558.003"],
    "discovery": ["T1087.002", "T1082", "T1016"],
    "lateral_movement": ["T1021.002", "T1021.001"],
    "collection": ["T1560.001", "T1005"],
    "exfiltration": ["T1048.003", "T1041"],
    "impact": ["T1486", "T1489"],
}
```

### Step 3: Atomic Execution with Logging

```bash
# Execute individual technique with Atomic Red Team
Invoke-AtomicTest T1059.001 -GetPrereqs
Invoke-AtomicTest T1059.001

# Log execution timestamp and evidence
python3 scripts/agent.py log-execution --technique T1059.001 --target "WS01" --status success
```

### Step 4: Detection Correlation

```bash
# Correlate execution timestamps with SIEM alerts
python3 scripts/agent.py correlate --execution-log execution.json --siem-export alerts.json

# Generate gap analysis
python3 scripts/agent.py gap-analysis --correlation correlation.json
```

## Verification

- [ ] Emulation plan covers all relevant kill chain phases
- [ ] Each technique executed with evidence and timestamps
- [ ] Detection correlation completed for all techniques
- [ ] Gap analysis identifies undetected techniques
- [ ] Remediation recommendations prioritized by risk

## References

- [MITRE Engenuity Evaluations](https://attackevals.mitre-engenuity.org/) — APT emulation benchmarks
- [Center for Threat-Informed Defense](https://ctid.mitre-engenuity.org/) — Emulation plan library
