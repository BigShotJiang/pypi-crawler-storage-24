<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# implementing-mobile-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `analyze-app --apk <file> [--checks <type>]` | Analyze mobile app vulnerabilities |
| `permissions --apk <file> --output <file>` | Extract app permissions |
| `mdm-test --device <id> --policies <csv>` | Test MDM policy enforcement |
| `mdm-bypass --device <id> --technique <name>` | Simulate MDM bypass |
| `smishing --campaign <name> --targets <csv> --template <name>` | Launch smishing campaign |
| `monitor --campaign <name>` | Monitor campaign metrics |
| `report --scope <scope> --output <file>` | Generate assessment report |
