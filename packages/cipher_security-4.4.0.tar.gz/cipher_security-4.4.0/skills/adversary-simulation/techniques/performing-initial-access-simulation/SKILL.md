<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-initial-access-simulation
description: >-
  Simulate initial access techniques to test perimeter defenses, email gateway
  controls, and endpoint protection against spearphishing, drive-by compromise,
  exploitation of public-facing applications, and valid account abuse.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - initial-access
  - spearphishing
  - drive-by-compromise
  - exploit-public-apps
  - valid-accounts
  - perimeter-testing
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1566.001", "T1566.002", "T1189", "T1190", "T1078"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "gophish", "atomic-red-team"]
---

# Performing Initial Access Simulation

## Overview

Initial access simulation tests the first stage of an attack chain — how
adversaries establish a foothold in the target environment. This covers
spearphishing with attachments and links, drive-by compromise via watering
holes, exploitation of public-facing applications, and abuse of valid
credentials obtained through prior compromise or social engineering.

## Prerequisites

- Tools: `python3`, GoPhish (for phishing), web application scanners
- Authorized scope including email addresses and public services
- Email gateway and endpoint protection active and monitored
- Coordination with SOC for alert validation

## Workflow

### Step 1: Spearphishing Attachment Simulation (T1566.001)

```bash
# Generate safe test payload (benign macro document)
python3 scripts/agent.py generate-payload --type macro-doc --safe --output test_doc.docm

# Send via phishing platform
python3 scripts/agent.py send-phish --template "invoice" --attachment test_doc.docm --targets targets.csv

# Verify email gateway detection
python3 scripts/agent.py check-detection --technique T1566.001 --source email-gateway
```

### Step 2: Spearphishing Link Simulation (T1566.002)

```bash
# Deploy credential harvesting landing page (safe — logs only, no storage)
python3 scripts/agent.py deploy-landing --template "password-reset" --safe

# Send phishing emails with tracking links
python3 scripts/agent.py send-phish --template "password-reset" --link "https://safe.example.com/reset"

# Monitor click-through and detection rates
python3 scripts/agent.py check-detection --technique T1566.002 --source proxy
```

### Step 3: Exploitation of Public-Facing Applications (T1190)

```bash
# Scan authorized public services for known vulnerabilities
python3 scripts/agent.py scan-services --targets public_services.json --safe

# Simulate exploit delivery (safe payload only)
python3 scripts/agent.py simulate-exploit --target "https://app.example.com" --cve "CVE-2024-XXXX" --mode dry-run
```

### Step 4: Valid Account Testing (T1078)

```bash
# Test detection of credential stuffing patterns
python3 scripts/agent.py test-auth --technique T1078 --target "vpn.example.com" --mode simulate

# Check for brute force and anomalous login detection
python3 scripts/agent.py check-detection --technique T1078 --source siem

# Generate initial access simulation report
python3 scripts/agent.py report --execution-log initial_access.json
```

## Verification

- [ ] Spearphishing attachments blocked by email gateway
- [ ] Phishing links detected by proxy or URL filtering
- [ ] Endpoint protection blocks macro execution
- [ ] Exploitation attempts logged and alerted
- [ ] Anomalous authentication patterns detected by SIEM

## References

- [MITRE ATT&CK Initial Access](https://attack.mitre.org/tactics/TA0001/) — Technique catalog
- [Atomic Red Team Initial Access](https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/Indexes/Indexes-Markdown/index.md) — Test library
