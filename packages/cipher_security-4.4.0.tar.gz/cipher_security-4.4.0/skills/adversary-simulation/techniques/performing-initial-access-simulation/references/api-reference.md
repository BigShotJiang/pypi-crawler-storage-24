<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-initial-access-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `analyze --target <scope>` | Run analysis |
| `report --target <scope>` | Generate report |
