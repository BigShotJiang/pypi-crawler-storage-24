<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: implementing-attack-infrastructure
description: >-
  Deploy and manage red team attack infrastructure including redirectors, DNS
  configurations, phishing domains, payload hosting, and C2 relay servers with
  proper operational security and teardown procedures.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - attack-infrastructure
  - redirectors
  - domain-fronting
  - operational-security
  - resource-development
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1583.001", "T1583.003", "T1583.006", "T1584.001"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "terraform", "nginx", "certbot"]
---

# Implementing Attack Infrastructure

## Overview

Attack infrastructure provides the operational backbone for adversary simulation
campaigns. Properly configured redirectors, domain categorization, and TLS
certificates make emulated attacks realistic while maintaining operational
security boundaries defined in the rules of engagement.

## Prerequisites

- Tools: `python3`, `terraform`, `nginx`, `certbot`
- Cloud provider accounts for VPS deployment
- Domain registrar access for campaign domains
- Understanding of network traffic routing and proxying

## Workflow

### Step 1: Domain Acquisition and Categorization

```bash
# Check domain categorization and reputation
python3 scripts/agent.py check-domain --domain "example-cdn.com"

# Register and configure DNS
python3 scripts/agent.py setup-dns --domain "example-cdn.com" --provider cloudflare
```

### Step 2: Deploy Redirectors

```nginx
# NGINX redirector configuration
server {
    listen 443 ssl;
    server_name example-cdn.com;

    ssl_certificate /etc/letsencrypt/live/example-cdn.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example-cdn.com/privkey.pem;

    location /api/ {
        proxy_pass https://c2-backend:8443;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location / {
        return 301 https://legitimate-site.com;
    }
}
```

### Step 3: Infrastructure Deployment

```bash
# Deploy infrastructure with Terraform
python3 scripts/agent.py deploy --config infra.json --provider aws

# Verify all components are operational
python3 scripts/agent.py health-check --config infra.json
```

### Step 4: Teardown and Cleanup

```bash
# Destroy all infrastructure after engagement
python3 scripts/agent.py teardown --config infra.json --verify

# Verify no residual resources remain
python3 scripts/agent.py audit-cleanup --provider aws --tag "engagement-2026"
```

## Verification

- [ ] Domains registered with appropriate categorization
- [ ] TLS certificates deployed and valid
- [ ] Redirectors routing traffic to C2 backend
- [ ] Non-matching traffic redirected to legitimate sites
- [ ] Teardown procedure verified — no residual resources

## References

- [Red Team Infrastructure Wiki](https://github.com/bluscreenofjeff/Red-Team-Infrastructure-Wiki) — Infrastructure patterns
- [Terraform](https://www.terraform.io/) — Infrastructure as code
