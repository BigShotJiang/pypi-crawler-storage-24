<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-dns-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `recon --domain <domain> --checks <csv>` | DNS reconnaissance and enumeration |
| `resolver-check --resolver <ip> --checks <csv>` | Analyze resolver configuration |
| `tunnel --domain <domain> --mode <mode> --data <payload>` | DNS tunnel simulation |
| `tunnel-metrics --domain <domain> [--duration <sec>]` | Measure tunnel metrics |
| `rebinding --domain <domain> --target <ip>` | DNS rebinding test |
| `cache-test --resolver <ip> --domain <domain>` | Cache behavior test |
| `correlate --test-log <file> --dns-logs <file>` | Correlate with DNS monitoring |
| `report --scope <scope> --output <file>` | Generate assessment report |
