<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-phishing-simulation-infrastructure
description: >-
  Build and operate phishing simulation platforms for security awareness testing,
  including email infrastructure, landing page cloning, credential harvesting
  simulation, and campaign analytics for measuring organizational resilience.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - phishing-simulation
  - social-engineering
  - security-awareness
  - email-infrastructure
  - gophish
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1566.001", "T1566.002", "T1598.003"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "gophish", "postfix", "certbot"]
---

# Building Phishing Simulation Infrastructure

## Overview

Phishing simulation infrastructure enables controlled social engineering tests
that measure employee susceptibility and validate email security controls.
Campaigns track open rates, click rates, and credential submission to provide
actionable metrics for security awareness programs.

## Prerequisites

- Tools: `python3`, GoPhish, mail server (Postfix/sendmail)
- Authorized phishing simulation scope and target list
- Campaign domain with proper SPF, DKIM, and DMARC records
- Landing page templates for credential capture simulation

## Workflow

### Step 1: Email Infrastructure Setup

```bash
# Deploy GoPhish server
docker run -d --name gophish -p 3333:3333 -p 8080:80 gophish/gophish

# Configure sending profile
python3 scripts/agent.py setup-sender --domain "security-training.example.com" \
    --smtp-host "mail.example.com" --smtp-port 587
```

### Step 2: Campaign Configuration

```python
"""Configure phishing campaign via GoPhish API."""
import requests

GOPHISH_URL = "https://localhost:3333"
API_KEY = "GOPHISH_API_KEY"
HEADERS = {"Authorization": f"Bearer {API_KEY}"}

# Create email template
template = {
    "name": "IT Password Reset",
    "subject": "Action Required: Password Expiration Notice",
    "html": "<p>Your password expires in 24 hours. "
            '<a href="{{.URL}}">Reset now</a></p>',
}
requests.post(f"{GOPHISH_URL}/api/templates/", json=template, headers=HEADERS)
```

### Step 3: Launch and Monitor

```bash
# Launch campaign
python3 scripts/agent.py launch --campaign "Q1-2026-Awareness" --group "all-employees"

# Monitor campaign progress
python3 scripts/agent.py status --campaign "Q1-2026-Awareness"

# Export results
python3 scripts/agent.py export --campaign "Q1-2026-Awareness" --format csv
```

### Step 4: Analyze and Report

```bash
# Generate campaign analytics
python3 scripts/agent.py analytics --campaign "Q1-2026-Awareness"

# Produce executive summary with metrics
python3 scripts/agent.py report --campaign "Q1-2026-Awareness" --format pdf
```

## Verification

- [ ] Email infrastructure passes SPF/DKIM/DMARC checks
- [ ] Landing pages render correctly and capture submissions
- [ ] Campaign sends to authorized target list only
- [ ] Tracking pixels and click tracking functional
- [ ] Results exported and campaign infrastructure torn down

## References

- [GoPhish](https://getgophish.com/) — Open-source phishing framework
- [King Phisher](https://github.com/rsmusllp/king-phisher) — Phishing campaign toolkit
