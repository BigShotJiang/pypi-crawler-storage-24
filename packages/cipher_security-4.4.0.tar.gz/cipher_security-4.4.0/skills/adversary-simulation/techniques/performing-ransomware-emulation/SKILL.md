<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-ransomware-emulation
description: >-
  Safely emulate ransomware behavior to test detection and response capabilities
  including file enumeration, safe encryption simulation, ransom note deployment,
  and shadow copy deletion detection without causing actual data loss.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - ransomware-emulation
  - impact-simulation
  - detection-testing
  - incident-response
  - data-protection
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1486", "T1490", "T1489", "T1529"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "atomic-red-team"]
---

# Performing Ransomware Emulation

## Overview

Ransomware emulation tests organizational readiness against encryption-based
attacks without risking actual data loss. Safe emulation techniques simulate
file enumeration, encryption behavior patterns, ransom note creation, and
backup destruction to validate detection rules, backup integrity, and incident
response procedures.

## Prerequisites

- Tools: `python3`, Atomic Red Team
- Isolated test environment with sample data (never production)
- Backup verification procedures documented
- IR team notified and monitoring during exercise

## Workflow

### Step 1: Safe Encryption Simulation

```python
"""Safe ransomware emulation — XOR-based reversible encryption on test files."""
import os
from pathlib import Path

SAFE_KEY = b"\x42"  # Single-byte XOR — trivially reversible
MARKER = b"EMULATION_SAFE"

def safe_encrypt(target_dir: str, extensions: list[str]) -> dict:
    """Encrypt test files with reversible XOR — never use on real data."""
    encrypted = []
    for ext in extensions:
        for fpath in Path(target_dir).rglob(f"*{ext}"):
            data = fpath.read_bytes()
            xored = bytes(b ^ SAFE_KEY[0] for b in data)
            fpath.write_bytes(MARKER + xored)
            encrypted.append(str(fpath))
    return {"encrypted": len(encrypted), "files": encrypted}
```

### Step 2: Ransom Note Deployment

```bash
# Deploy simulated ransom notes
python3 scripts/agent.py deploy-notes --directory /test/share --template "EMULATION_README.txt"

# Monitor for detection of ransom note creation
python3 scripts/agent.py monitor-detection --indicator "ransom_note"
```

### Step 3: Shadow Copy Deletion Detection

```bash
# Test detection of shadow copy deletion (Windows)
# vssadmin delete shadows /all /quiet  # EMULATION — log only, do not execute
python3 scripts/agent.py test-vss-detection --mode dry-run

# Test detection of backup service disruption
python3 scripts/agent.py test-backup-detection --services "vss,wbengine,swprv"
```

### Step 4: Recovery Validation

```bash
# Verify backup restoration works
python3 scripts/agent.py validate-recovery --backup-path /backups/latest --target /test/restore

# Generate emulation report
python3 scripts/agent.py report --execution-log emulation.json
```

## Verification

- [ ] Encryption simulation uses reversible safe method only
- [ ] Test environment isolated from production data
- [ ] Detection rules triggered for file encryption patterns
- [ ] Ransom note creation detected by endpoint monitoring
- [ ] Shadow copy deletion attempt detected
- [ ] Backup recovery validated successfully

## References

- [Atomic Red Team T1486](https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1486/) — Ransomware tests
- [CISA Ransomware Guide](https://www.cisa.gov/stopransomware) — Response guidance
