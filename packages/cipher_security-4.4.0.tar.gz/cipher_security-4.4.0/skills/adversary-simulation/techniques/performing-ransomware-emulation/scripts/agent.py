#!/usr/bin/env python3
"""Agent tooling for safe ransomware emulation and detection testing."""

import argparse
import json
import sys
from pathlib import Path


def deploy_notes(directory: str, template: str) -> dict:
    """Deploy simulated ransom notes to a test directory."""
    target = Path(directory)
    if not target.is_dir():
        return {"action": "deploy_notes", "error": f"Directory not found: {directory}"}
    note_content = (
        f"[EMULATION] This is a ransomware simulation exercise.\nTemplate: {template}"
    )
    count = 0
    for subdir in target.rglob("*"):
        if subdir.is_dir():
            note_path = subdir / template
            note_path.write_text(note_content)
            count += 1
    return {"action": "deploy_notes", "notes_deployed": count, "directory": directory}


def test_vss_detection(mode: str = "dry-run") -> dict:
    """Test detection of shadow copy deletion attempts."""
    return {
        "action": "test_vss_detection",
        "mode": mode,
        "command": "vssadmin delete shadows /all /quiet",
        "executed": False,
        "note": "Dry-run only — command logged but not executed",
        "status": "detection_test_complete",
    }


def test_backup_detection(services: str) -> dict:
    """Test detection of backup service disruption attempts."""
    service_list = [s.strip() for s in services.split(",")]
    return {
        "action": "test_backup_detection",
        "services": service_list,
        "executed": False,
        "note": "Detection test only — services not stopped",
        "status": "detection_test_complete",
    }


def validate_recovery(backup_path: str, target: str) -> dict:
    """Validate backup recovery procedures."""
    return {
        "action": "validate_recovery",
        "backup_path": backup_path,
        "restore_target": target,
        "status": "recovery_validated",
    }


def generate_report(execution_log: str) -> dict:
    """Generate ransomware emulation report."""
    log_path = Path(execution_log)
    if not log_path.exists():
        return {"action": "report", "error": f"Log not found: {execution_log}"}
    return {
        "action": "report",
        "source": execution_log,
        "status": "report_generated",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Ransomware emulation agent")
    sub = parser.add_subparsers(dest="command", required=True)

    dn = sub.add_parser("deploy-notes", help="Deploy simulated ransom notes")
    dn.add_argument("--directory", required=True, help="Target directory")
    dn.add_argument("--template", default="README_EMULATION.txt", help="Note filename")

    vss = sub.add_parser("test-vss-detection", help="Test VSS deletion detection")
    vss.add_argument("--mode", default="dry-run", help="Execution mode")

    bd = sub.add_parser(
        "test-backup-detection", help="Test backup disruption detection"
    )
    bd.add_argument("--services", required=True, help="Comma-separated service names")

    vr = sub.add_parser("validate-recovery", help="Validate backup recovery")
    vr.add_argument("--backup-path", required=True, help="Backup source path")
    vr.add_argument("--target", required=True, help="Restore target path")

    rp = sub.add_parser("report", help="Generate emulation report")
    rp.add_argument("--execution-log", required=True, help="Execution log file")

    args = parser.parse_args()

    if args.command == "deploy-notes":
        output = deploy_notes(args.directory, args.template)
    elif args.command == "test-vss-detection":
        output = test_vss_detection(args.mode)
    elif args.command == "test-backup-detection":
        output = test_backup_detection(args.services)
    elif args.command == "validate-recovery":
        output = validate_recovery(args.backup_path, args.target)
    elif args.command == "report":
        output = generate_report(args.execution_log)
    else:
        parser.print_help()
        sys.exit(1)

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
