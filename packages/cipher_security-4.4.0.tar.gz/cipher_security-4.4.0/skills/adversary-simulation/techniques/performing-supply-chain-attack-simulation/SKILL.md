<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-supply-chain-attack-simulation
description: >-
  Simulate supply chain compromise scenarios including dependency poisoning,
  build pipeline hijacking, and trusted vendor impersonation to validate
  organizational resilience against upstream attack vectors.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - supply-chain
  - dependency-poisoning
  - build-pipeline
  - third-party-risk
  - software-integrity
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1195", "T1195.001", "T1195.002", "T1199", "T1553.002"]
  frameworks: ["MITRE ATT&CK", "SLSA", "NIST SP 800-161"]
  tools: ["python3", "sigstore", "in-toto", "cosign"]
---

# Performing Supply Chain Attack Simulation

## Overview

Supply chain attack simulation replicates compromise scenarios targeting the
software supply chain — from dependency confusion and typosquatting to build
pipeline injection and signed artifact tampering. These simulations validate
whether software composition analysis, build integrity controls, and vendor
risk management detect upstream compromise before malicious code reaches
production environments.

## Prerequisites

- Tools: `python3`, package manager CLIs, artifact signing tools
- Isolated build environment with no production connectivity
- Inventory of third-party dependencies and build pipelines
- Signed Rules of Engagement covering supply chain scope

## Workflow

### Step 1: Map Supply Chain Attack Surface

```bash
# Enumerate dependencies and build pipeline components
python3 scripts/agent.py enumerate --manifest package.json --pipeline ci.yml

# Identify high-risk dependency patterns
python3 scripts/agent.py analyze-deps --manifest requirements.txt
```

### Step 2: Simulate Dependency Confusion

```bash
# Create benign proof-of-concept package for dependency confusion
python3 scripts/agent.py dep-confusion --package internal-utils --registry pypi

# Simulate typosquatting detection test
python3 scripts/agent.py typosquat-check --manifest package.json
```

### Step 3: Test Build Pipeline Integrity

```bash
# Verify build artifact signing and provenance
python3 scripts/agent.py verify-provenance --artifact build.tar.gz --attestation att.json

# Simulate pipeline injection scenario
python3 scripts/agent.py pipeline-inject --pipeline .github/workflows/build.yml --dry-run
```

### Step 4: Generate Supply Chain Risk Report

```bash
# Produce supply chain risk assessment
python3 scripts/agent.py report --scope full --output supply-chain-report.json
```

## Verification

- [ ] Dependency inventory complete with risk scoring
- [ ] Dependency confusion scenario tested against internal registries
- [ ] Build pipeline integrity controls validated
- [ ] Artifact signing and provenance verification tested
- [ ] Gap analysis identifies missing supply chain controls

## References

- [SLSA Framework](https://slsa.dev/) — Supply chain Levels for Software Artifacts
- [NIST SP 800-161](https://csrc.nist.gov/publications/detail/sp/800-161/rev-1/final) — Supply chain risk management
