<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-supply-chain-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --manifest <file> [--pipeline <file>]` | Enumerate dependencies and pipeline components |
| `analyze-deps --manifest <file>` | Identify high-risk dependency patterns |
| `dep-confusion --package <name> --registry <reg>` | Create dependency confusion PoC |
| `typosquat-check --manifest <file>` | Check for typosquatting risk |
| `verify-provenance --artifact <path> --attestation <file>` | Verify artifact provenance |
| `pipeline-inject --pipeline <file> [--dry-run]` | Simulate pipeline injection |
| `report --scope <scope> --output <file>` | Generate supply chain risk report |
