<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-adversary-profiles
description: >-
  Build intelligence-driven adversary profiles from CTI sources, mapping threat
  actor TTPs to MITRE ATT&CK, generating emulation plans, and producing ATT&CK
  Navigator layers for detection coverage analysis.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - threat-intelligence
  - adversary-profiling
  - mitre-attack
  - attack-navigator
  - cti
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1595", "T1592", "T1589", "T1590"]
  frameworks: ["MITRE ATT&CK", "Diamond Model", "Kill Chain"]
  tools: ["python3", "attack-navigator", "stix2"]
---

# Building Adversary Profiles

## Overview

Adversary profiles translate threat intelligence into actionable emulation plans.
By mapping known threat actor TTPs to MITRE ATT&CK techniques, teams can design
realistic simulations that test detection and response capabilities against the
specific threats most relevant to their organization.

## Prerequisites

- Tools: `python3`, `stix2`, `mitreattack-python`
- Access to CTI feeds (MISP, OpenCTI, or STIX/TAXII sources)
- MITRE ATT&CK Navigator for layer visualization
- Threat intelligence reports for target actor groups

## Workflow

### Step 1: Gather Threat Intelligence

```bash
# Query MITRE ATT&CK for threat group TTPs
python3 scripts/agent.py profile --actor "APT29" --format json

# Pull STIX bundles from CTI platform
python3 scripts/agent.py fetch-stix --source "https://cti-taxii.mitre.org" --group "APT29"
```

### Step 2: Map TTPs to ATT&CK

```python
from mitreattack.stix20 import MitreAttackData

attack = MitreAttackData("enterprise-attack.json")

# Get techniques used by threat group
group = attack.get_group_by_alias("APT29")
techniques = attack.get_techniques_used_by_group(group)

for tech in techniques:
    obj = tech["object"]
    print(f"{obj.external_references[0].external_id}: {obj.name}")
```

### Step 3: Generate Navigator Layer

```bash
# Export ATT&CK Navigator layer for visualization
python3 scripts/agent.py navigator --actor "APT29" --output apt29-layer.json

# Overlay with existing detection coverage
python3 scripts/agent.py coverage --layer apt29-layer.json --detections detections.json
```

### Step 4: Build Emulation Plan

```
Emulation Plan Structure:
├── Threat Actor Summary — Motivation, targets, capabilities
├── TTP Inventory — Ordered by kill chain phase
├── Technique Details
│   ├── ATT&CK ID and name
│   ├── Procedure example from CTI
│   ├── Emulation command or tool
│   └── Expected detection signature
├── Infrastructure Requirements — C2, redirectors, payloads
└── Execution Timeline — Phased approach with checkpoints
```

## Verification

- [ ] Threat actor TTPs mapped to ATT&CK techniques
- [ ] Navigator layer generated with accurate scoring
- [ ] Detection coverage overlay identifies gaps
- [ ] Emulation plan includes all kill chain phases
- [ ] Procedure examples sourced from verified CTI

## References

- [MITRE ATT&CK Groups](https://attack.mitre.org/groups/) — Threat group profiles
- [MITRE CTI STIX/TAXII](https://github.com/mitre/cti) — Machine-readable ATT&CK data
- [ATT&CK Navigator](https://mitre-attack.github.io/attack-navigator/) — Layer visualization
