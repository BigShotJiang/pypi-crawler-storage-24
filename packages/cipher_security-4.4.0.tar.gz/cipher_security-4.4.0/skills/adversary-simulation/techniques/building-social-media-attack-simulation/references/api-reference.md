<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# building-social-media-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `recon --domain <domain> --platforms <csv>` | Harvest social media footprint |
| `identify-targets --recon-data <file> --criteria <type>` | Identify high-value targets |
| `create-persona --role <role> --industry <name>` | Create fake persona |
| `impersonation-risk --target <name> [--platforms <list>]` | Assess impersonation risk |
| `campaign --type <type> --persona <name> --targets <csv>` | Launch social engineering campaign |
| `monitor --campaign <name>` | Monitor campaign metrics |
| `report --campaign <name> --output <file>` | Generate threat assessment report |
