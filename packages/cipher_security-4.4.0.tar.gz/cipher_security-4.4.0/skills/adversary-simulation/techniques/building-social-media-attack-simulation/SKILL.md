<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-social-media-attack-simulation
description: >-
  Simulate social media-based attack vectors including profile impersonation,
  social engineering via professional networks, open source intelligence
  harvesting, and fake persona operations to assess organizational exposure
  to social platform threats.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - social-media
  - social-engineering
  - osint
  - impersonation
  - persona-operations
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1593", "T1585", "T1566.003", "T1598"]
  frameworks: ["MITRE ATT&CK", "NIST SP 800-150", "SANS SEC487"]
  tools: ["python3", "maltego", "sherlock", "theHarvester"]
---

# Building Social Media Attack Simulation

## Overview

Social media attack simulation assesses organizational exposure to threats
originating from social platforms — executive impersonation, employee
reconnaissance via LinkedIn/GitHub, fake persona engagement, and phishing
via direct messages. These simulations validate employee security awareness,
social media monitoring capabilities, and incident response to social
engineering attacks.

## Prerequisites

- Tools: `python3`, OSINT tools, social media monitoring platform
- Authorized scope covering social media-based assessment
- Legal review for impersonation and persona creation boundaries
- Employee awareness program baseline for comparison metrics

## Workflow

### Step 1: Social Media Reconnaissance

```bash
# Harvest employee social media footprint
python3 scripts/agent.py recon --domain target.com --platforms linkedin,github,twitter

# Identify high-value targets for social engineering
python3 scripts/agent.py identify-targets --recon-data recon.json --criteria executives
```

### Step 2: Persona and Impersonation Setup

```bash
# Generate fake persona profile for authorized engagement
python3 scripts/agent.py create-persona --role recruiter --industry tech

# Assess impersonation risk for executive profiles
python3 scripts/agent.py impersonation-risk --target "CEO Name" --platforms all
```

### Step 3: Execute Social Engineering Campaign

```bash
# Launch controlled social engineering via direct messages
python3 scripts/agent.py campaign --type dm-phish --persona recruiter --targets targets.csv

# Monitor engagement and credential capture metrics
python3 scripts/agent.py monitor --campaign social-q1
```

### Step 4: Analyze and Report

```bash
# Generate social media threat assessment report
python3 scripts/agent.py report --campaign social-q1 --output social-report.json
```

## Verification

- [ ] Employee social media exposure mapped and risk-scored
- [ ] Executive impersonation risk assessed across platforms
- [ ] Social engineering campaign executed within authorized scope
- [ ] Employee click and engagement rates documented
- [ ] Report includes social media security policy recommendations

## References

- [MITRE T1593](https://attack.mitre.org/techniques/T1593/) — Search open websites/domains
- [NIST SP 800-150](https://csrc.nist.gov/publications/detail/sp/800-150/final) — Guide to cyber threat information sharing
