<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-iot-attack-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `discover --network <cidr> --output <file>` | Discover IoT devices |
| `enumerate --target <ip> [--deep]` | Enumerate device services |
| `firmware-extract --image <file> --output <dir>` | Extract firmware |
| `firmware-scan --path <dir> [--checks <type>]` | Scan firmware for vulnerabilities |
| `fuzz --target <ip> --protocol <name> [--iterations <n>]` | Fuzz protocol |
| `cred-test --target <ip> --wordlist <file>` | Test default credentials |
| `segmentation-test --source <seg> --target <seg>` | Test network segmentation |
| `report --scope <scope> --output <file>` | Generate assessment report |
