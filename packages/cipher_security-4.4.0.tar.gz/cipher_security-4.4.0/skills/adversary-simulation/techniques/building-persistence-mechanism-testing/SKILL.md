<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-persistence-mechanism-testing
description: >-
  Test and validate detection of persistence mechanisms including registry run
  keys, scheduled tasks, services, startup folders, WMI subscriptions, and
  boot-level persistence mapped to MITRE ATT&CK Persistence tactic.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - persistence
  - registry-keys
  - scheduled-tasks
  - services
  - wmi-subscriptions
  - boot-persistence
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1547.001", "T1053.005", "T1543.003", "T1546.003", "T1547.004"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "atomic-red-team", "sysmon"]
---

# Building Persistence Mechanism Testing

## Overview

Persistence mechanism testing validates whether endpoint detection tools and
SIEM rules identify adversary techniques for maintaining access across system
reboots and credential changes. Each test creates a benign persistence artifact,
verifies detection, then cleans up completely.

## Prerequisites

- Tools: `python3`, Atomic Red Team, Sysmon deployed on targets
- Test systems with monitoring agents active
- Administrator/root access on test targets
- Cleanup verification procedures

## Workflow

### Step 1: Registry Run Key Persistence (T1547.001)

```bash
# Create benign registry persistence
# reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v EmulationTest /d "calc.exe"
python3 scripts/agent.py test-persistence --technique T1547.001 --mode create

# Verify detection
python3 scripts/agent.py check-detection --technique T1547.001

# Clean up
python3 scripts/agent.py test-persistence --technique T1547.001 --mode cleanup
```

### Step 2: Scheduled Task Persistence (T1053.005)

```bash
# Create benign scheduled task
# schtasks /create /tn "EmulationTest" /tr "calc.exe" /sc daily /st 12:00
python3 scripts/agent.py test-persistence --technique T1053.005 --mode create

# Verify Sysmon Event ID 1 and task creation events
python3 scripts/agent.py check-detection --technique T1053.005
```

### Step 3: WMI Event Subscription (T1546.003)

```python
"""Test WMI event subscription persistence detection."""
WMI_FILTER = """
SELECT * FROM __InstanceModificationEvent WITHIN 60
WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System'
AND TargetInstance.SystemUpTime >= 240
"""
# Creates benign WMI subscription for detection testing
```

### Step 4: Batch Test All Mechanisms

```bash
# Run all persistence tests in sequence
python3 scripts/agent.py batch-test --techniques "T1547.001,T1053.005,T1543.003,T1546.003"

# Generate persistence testing report
python3 scripts/agent.py report --execution-log persistence.json
```

## Verification

- [ ] Each persistence mechanism created and detected
- [ ] Sysmon events captured for all techniques
- [ ] SIEM alerts triggered with correct ATT&CK mapping
- [ ] All persistence artifacts cleaned up completely
- [ ] Detection gaps documented with remediation steps

## References

- [Atomic Red Team Persistence](https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/Indexes/Indexes-Markdown/index.md) — Persistence tests
- [MITRE ATT&CK Persistence](https://attack.mitre.org/tactics/TA0003/) — Technique catalog
