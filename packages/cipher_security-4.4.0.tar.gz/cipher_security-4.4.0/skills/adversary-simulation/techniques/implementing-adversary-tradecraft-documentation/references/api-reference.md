<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# implementing-adversary-tradecraft-documentation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `import --source <file> --format <fmt>` | Import engagement data |
| `map-ttps --procedures <file> --output <file>` | Map procedures to ATT&CK |
| `create-playbook --ttp-map <file> --actor <name> --output <file>` | Create TTP playbook |
| `navigator-layer --ttp-map <file> --output <file>` | Generate ATT&CK Navigator layer |
| `detection-map --playbook <file> --output <file>` | Map TTPs to detections |
| `sigma-stubs --detection-map <file> --output <dir>` | Generate Sigma rule stubs |
| `export --playbook <file> --detections <file> [--format <fmt>]` | Export documentation package |
| `report --scope <scope> --output <file>` | Generate engagement summary report |
