<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: implementing-adversary-tradecraft-documentation
description: >-
  Document adversary tradecraft systematically by creating structured TTP
  playbooks, emulation plans, detection mappings, and intelligence-driven
  procedure documentation that bridges offensive operations with defensive
  detection engineering.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - tradecraft-documentation
  - ttp-playbooks
  - emulation-plans
  - detection-mapping
  - intelligence-driven
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1059", "T1082", "T1083", "T1018", "T1057"]
  frameworks: ["MITRE ATT&CK", "MITRE Engenuity", "Cyber Kill Chain"]
  tools: ["python3", "attack-navigator", "sigma", "caldera"]
---

# Implementing Adversary Tradecraft Documentation

## Overview

Adversary tradecraft documentation transforms raw offensive operation data
into structured, reusable intelligence artifacts — TTP playbooks mapped to
MITRE ATT&CK, detection opportunity matrices, emulation plan templates, and
procedure-level documentation that enables purple teams to reproduce and
validate adversary behavior systematically. This skill bridges the gap between
red team execution and blue team detection engineering.

## Prerequisites

- Tools: `python3`, ATT&CK Navigator, Sigma rule tooling
- Engagement execution logs with technique-level detail
- MITRE ATT&CK framework knowledge for accurate mapping
- Access to CTI reports for threat actor procedure documentation

## Workflow

### Step 1: Capture and Structure Tradecraft

```bash
# Import raw engagement data and normalize to structured format
python3 scripts/agent.py import --source engagement-log.json --format caldera

# Map procedures to MITRE ATT&CK techniques
python3 scripts/agent.py map-ttps --procedures procedures.json --output ttp-map.json
```

### Step 2: Generate TTP Playbooks

```bash
# Create structured playbook from mapped TTPs
python3 scripts/agent.py create-playbook --ttp-map ttp-map.json --actor APT29 --output playbook.json

# Generate ATT&CK Navigator layer for visualization
python3 scripts/agent.py navigator-layer --ttp-map ttp-map.json --output layer.json
```

### Step 3: Detection Mapping

```bash
# Map each TTP to detection data sources and analytics
python3 scripts/agent.py detection-map --playbook playbook.json --output detections.json

# Generate Sigma rule stubs for undocumented detections
python3 scripts/agent.py sigma-stubs --detection-map detections.json --output sigma-rules/
```

### Step 4: Documentation Export

```bash
# Export complete tradecraft documentation package
python3 scripts/agent.py export --playbook playbook.json --detections detections.json --format markdown

# Generate engagement summary report
python3 scripts/agent.py report --scope full --output tradecraft-report.json
```

## Verification

- [ ] All engagement procedures mapped to ATT&CK techniques
- [ ] TTP playbooks include procedure-level reproduction steps
- [ ] Detection opportunities documented for each technique
- [ ] ATT&CK Navigator layer accurately reflects coverage
- [ ] Documentation package exportable for purple team consumption

## References

- [MITRE ATT&CK Navigator](https://mitre-attack.github.io/attack-navigator/) — ATT&CK visualization tool
- [CTID Adversary Emulation Library](https://github.com/center-for-threat-informed-defense/adversary_emulation_library) — Emulation plan templates
