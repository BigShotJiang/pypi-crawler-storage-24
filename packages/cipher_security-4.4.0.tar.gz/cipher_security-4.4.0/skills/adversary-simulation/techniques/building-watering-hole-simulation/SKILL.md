<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-watering-hole-simulation
description: >-
  Simulate watering hole attacks by identifying high-value websites frequented
  by target organizations, deploying controlled exploit landing pages, and
  testing browser-based detection capabilities against strategic web compromise
  scenarios.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - watering-hole
  - strategic-web-compromise
  - drive-by-download
  - browser-exploit
  - web-compromise
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1189", "T1203", "T1059.007", "T1071.001"]
  frameworks: ["MITRE ATT&CK", "Lockheed Kill Chain", "OWASP"]
  tools: ["python3", "beef-xss", "mitmproxy", "selenium"]
---

# Building Watering Hole Simulation

## Overview

Watering hole simulation replicates strategic web compromise attacks where
adversaries inject malicious content into websites frequented by target
organizations. This technique tests web proxy filtering, browser isolation
controls, endpoint detection of drive-by downloads, and network-based
indicators of compromise detection when users visit compromised sites.

## Prerequisites

- Tools: `python3`, BeEF, mitmproxy, web hosting infrastructure
- Authorized scope covering web-based attack simulation
- Controlled web server mimicking compromised watering hole site
- Web proxy and endpoint protection deployed for detection validation

## Workflow

### Step 1: Target Site Profiling

```bash
# Profile websites frequented by target organization
python3 scripts/agent.py profile --domain target.com --output site-profile.json

# Identify injectable content vectors on controlled test site
python3 scripts/agent.py analyze-site --url https://test-wateringhole.example.com
```

### Step 2: Deploy Watering Hole Infrastructure

```bash
# Configure controlled watering hole landing page
python3 scripts/agent.py deploy-site --template news-portal --payload browser-hook

# Inject controlled exploit redirect into test page
python3 scripts/agent.py inject --url https://test-wateringhole.example.com --vector iframe
```

### Step 3: Execute Drive-By Simulation

```bash
# Simulate user browsing to compromised site
python3 scripts/agent.py simulate-visit --url https://test-wateringhole.example.com --browser chrome

# Monitor browser hook callbacks and payload delivery
python3 scripts/agent.py monitor --campaign wateringhole-q1
```

### Step 4: Detection Validation and Reporting

```bash
# Generate watering hole simulation report
python3 scripts/agent.py report --campaign wateringhole-q1 --output wh-report.json
```

## Verification

- [ ] Target site profile identifies realistic watering hole candidates
- [ ] Controlled infrastructure deployed without production impact
- [ ] Web proxy blocks or alerts on exploit redirect content
- [ ] Endpoint detection identifies drive-by download attempts
- [ ] Report documents detection gaps and hardening recommendations

## References

- [MITRE T1189](https://attack.mitre.org/techniques/T1189/) — Drive-by Compromise
- [OWASP Testing Guide](https://owasp.org/www-project-web-security-testing-guide/) — Web application security testing
