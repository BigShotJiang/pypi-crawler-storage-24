<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# building-watering-hole-simulation — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `profile --domain <domain> --output <file>` | Profile target site visitors |
| `analyze-site --url <url>` | Analyze site for injection vectors |
| `deploy-site --template <name> --payload <type>` | Deploy watering hole site |
| `inject --url <url> --vector <type>` | Inject exploit redirect |
| `simulate-visit --url <url> [--browser <type>]` | Simulate user visit |
| `monitor --campaign <name>` | Monitor campaign callbacks |
| `report --campaign <name> --output <file>` | Generate simulation report |
