<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: implementing-defense-evasion-testing
description: >-
  Test detection capabilities against defense evasion techniques including
  process injection, AMSI bypass, EDR unhooking, timestomping, indicator
  removal, and living-off-the-land binaries (LOLBins) mapped to MITRE ATT&CK.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - defense-evasion
  - process-injection
  - amsi-bypass
  - lolbins
  - edr-evasion
  - indicator-removal
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1055", "T1562.001", "T1070", "T1218", "T1027", "T1036"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "atomic-red-team", "sysmon"]
---

# Implementing Defense Evasion Testing

## Overview

Defense evasion testing validates whether security controls detect adversary
techniques designed to avoid detection. This includes testing EDR coverage
against process injection, AMSI bypass, log tampering, binary masquerading,
and abuse of legitimate system utilities (LOLBins).

## Prerequisites

- Tools: `python3`, Atomic Red Team, Sysmon, EDR agent deployed
- Test systems with full endpoint monitoring active
- Baseline of normal LOLBin usage for false positive tuning
- SIEM correlation rules for evasion techniques

## Workflow

### Step 1: Process Injection Testing (T1055)

```bash
# Test process injection detection variants
python3 scripts/agent.py test-evasion --technique T1055.001 --mode simulate
python3 scripts/agent.py test-evasion --technique T1055.003 --mode simulate
python3 scripts/agent.py test-evasion --technique T1055.012 --mode simulate

# Verify Sysmon Event ID 8 (CreateRemoteThread) detection
python3 scripts/agent.py check-detection --technique T1055 --event-source sysmon
```

### Step 2: AMSI and ETW Bypass Testing (T1562.001)

```powershell
# Test AMSI bypass detection (PowerShell)
# [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils')
# The above should trigger AMSI tampering detection

# Test ETW patching detection
# Patch ntdll!EtwEventWrite — should trigger EDR alert
```

```bash
python3 scripts/agent.py test-evasion --technique T1562.001 --variant amsi
python3 scripts/agent.py test-evasion --technique T1562.001 --variant etw
```

### Step 3: LOLBin Abuse Testing (T1218)

```bash
# Test common LOLBin techniques
python3 scripts/agent.py test-lolbin --binary "mshta" --payload "safe_test.hta"
python3 scripts/agent.py test-lolbin --binary "certutil" --payload "-urlcache -f http://safe.example.com/test"
python3 scripts/agent.py test-lolbin --binary "rundll32" --payload "safe_test.dll,EntryPoint"

# Check for LOLBin abuse detection
python3 scripts/agent.py check-detection --technique T1218 --event-source edr
```

### Step 4: Indicator Removal Testing (T1070)

```bash
# Test log clearing detection (T1070.001)
python3 scripts/agent.py test-evasion --technique T1070.001 --mode simulate

# Test timestomping detection (T1070.006)
python3 scripts/agent.py test-evasion --technique T1070.006 --mode simulate

# Generate defense evasion report
python3 scripts/agent.py report --execution-log evasion.json
```

## Verification

- [ ] Process injection variants detected by EDR/Sysmon
- [ ] AMSI/ETW tampering detected and alerted
- [ ] LOLBin abuse flagged by behavioral detection
- [ ] Log clearing and timestomping detected
- [ ] False positive rates documented for each technique

## References

- [LOLBAS Project](https://lolbas-project.github.io/) — Living Off The Land Binaries catalog
- [MITRE ATT&CK Defense Evasion](https://attack.mitre.org/tactics/TA0005/) — Technique catalog
