<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-custom-c2-frameworks
description: >-
  Design and build custom command-and-control frameworks for adversary simulation,
  implementing encrypted communication channels, modular agent architectures,
  and evasive C2 profiles to test detection capabilities.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - c2-framework
  - command-and-control
  - red-team
  - covert-channels
  - malleable-profiles
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1071.001", "T1573.002", "T1132.001", "T1095"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["python3", "sliver", "mythic", "openssl"]
---

# Building Custom C2 Frameworks

## Overview

Custom C2 frameworks enable red teams to simulate adversary command-and-control
infrastructure that evades standard network detection. Building custom C2 tests
whether defenders can detect novel communication channels beyond known tool
signatures like Cobalt Strike or Metasploit beacons.

## Prerequisites

- Tools: `python3`, `openssl`, `docker`
- Understanding of network protocols (HTTP/S, DNS, ICMP)
- TLS certificate infrastructure for encrypted channels
- Isolated network environment for testing

## Workflow

### Step 1: Design C2 Architecture

```
C2 Architecture:
├── Listener — Accepts agent callbacks
│   ├── HTTPS with domain-fronted traffic
│   ├── DNS TXT record tunneling
│   └── WebSocket over legitimate CDN
├── Agent — Implant on target system
│   ├── Modular task execution
│   ├── Encrypted communication
│   ├── Jitter and sleep intervals
│   └── Anti-analysis checks
├── Teamserver — Operator interface
│   ├── Multi-operator support
│   ├── Task queue and results
│   └── Logging and audit trail
└── Redirectors — Traffic obfuscation layer
```

### Step 2: Implement Basic C2 Server

```python
"""Minimal HTTPS C2 listener for simulation testing."""
import ssl
from http.server import HTTPServer, BaseHTTPRequestHandler
import json

class C2Handler(BaseHTTPRequestHandler):
    tasks: dict[str, list] = {}
    results: dict[str, list] = {}

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        data = json.loads(self.rfile.read(length))
        agent_id = data.get("id", "unknown")
        self.results.setdefault(agent_id, []).append(data)
        tasks = self.tasks.pop(agent_id, [])
        self.send_response(200)
        self.end_headers()
        self.wfile.write(json.dumps({"tasks": tasks}).encode())
```

### Step 3: Generate C2 Profile

```bash
# Generate malleable C2 profile
python3 scripts/agent.py generate-profile --protocol https --jitter 30 --sleep 60

# Validate profile against known signatures
python3 scripts/agent.py validate-profile --profile custom.profile
```

### Step 4: Test Detection

```bash
# Generate network traffic for detection testing
python3 scripts/agent.py simulate-traffic --profile custom.profile --duration 300

# Analyze traffic against NIDS signatures
python3 scripts/agent.py analyze-detection --pcap capture.pcap
```

## Verification

- [ ] C2 server accepts agent callbacks over encrypted channel
- [ ] Agent communication uses configurable jitter and sleep
- [ ] Traffic profile evades default NIDS signatures
- [ ] Detection gaps documented for blue team remediation
- [ ] All C2 infrastructure decommissioned after exercise

## References

- [Sliver C2](https://github.com/BishopFox/sliver) — Open-source adversary emulation framework
- [Mythic C2](https://github.com/its-a-feature/Mythic) — Modular C2 platform
