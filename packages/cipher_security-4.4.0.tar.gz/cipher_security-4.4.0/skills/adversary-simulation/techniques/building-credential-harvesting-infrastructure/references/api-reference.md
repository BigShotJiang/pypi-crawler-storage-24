<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# building-credential-harvesting-infrastructure — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `init --domain <domain> --backend <platform>` | Initialize harvesting infrastructure |
| `configure-proxy --target <url> [--mode <mode>]` | Configure phishing proxy |
| `create-template --type <type> --target <service>` | Generate phishing template |
| `deploy --template <name> [--tracking <enabled/disabled>]` | Deploy landing page |
| `launch --campaign <name> --target-list <csv>` | Launch phishing campaign |
| `monitor --campaign <name>` | Monitor credential capture |
| `report --campaign <name> --output <file>` | Generate campaign report |
