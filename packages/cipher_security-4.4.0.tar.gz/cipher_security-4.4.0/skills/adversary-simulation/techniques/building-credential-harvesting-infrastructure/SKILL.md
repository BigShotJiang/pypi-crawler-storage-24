<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: building-credential-harvesting-infrastructure
description: >-
  Build and operate controlled credential harvesting infrastructure for
  authorized phishing simulations, including cloned portals, token capture
  proxies, and credential replay testing to assess organizational
  susceptibility to credential theft attacks.
domain: cybersecurity
subdomain: adversary-simulation
tags:
  - credential-harvesting
  - phishing-simulation
  - token-capture
  - credential-replay
  - authentication-abuse
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1556", "T1539", "T1528", "T1557", "T1111"]
  frameworks: ["MITRE ATT&CK", "NIST SP 800-63B", "OWASP"]
  tools: ["python3", "evilginx2", "gophish", "modlishka"]
---

# Building Credential Harvesting Infrastructure

## Overview

Credential harvesting infrastructure simulation deploys controlled phishing
portals, transparent reverse proxies, and token interception mechanisms to
test organizational defenses against credential theft. This includes MFA
bypass via real-time phishing proxies, session token capture, and credential
replay attacks — all within authorized red team engagements.

## Prerequisites

- Tools: `python3`, GoPhish, Evilginx2 or equivalent proxy
- Authorized phishing engagement scope with legal sign-off
- Domain and TLS certificate infrastructure for simulation
- Target list approved by engagement sponsor

## Workflow

### Step 1: Deploy Harvesting Infrastructure

```bash
# Initialize credential harvesting environment
python3 scripts/agent.py init --domain sim.example.com --backend gophish

# Configure phishing proxy for MFA interception
python3 scripts/agent.py configure-proxy --target login.target.com --mode transparent
```

### Step 2: Create Phishing Scenarios

```bash
# Generate credential harvesting templates
python3 scripts/agent.py create-template --type portal-clone --target office365

# Deploy landing page with token capture
python3 scripts/agent.py deploy --template office365 --tracking enabled
```

### Step 3: Execute Campaign and Capture

```bash
# Launch phishing campaign
python3 scripts/agent.py launch --campaign q1-assessment --target-list targets.csv

# Monitor credential capture in real-time
python3 scripts/agent.py monitor --campaign q1-assessment
```

### Step 4: Analyze and Report

```bash
# Generate campaign metrics and credential analysis
python3 scripts/agent.py report --campaign q1-assessment --output cred-report.json
```

## Verification

- [ ] Infrastructure deployed in isolated environment
- [ ] Phishing templates reviewed for scope compliance
- [ ] Campaign launched only against authorized targets
- [ ] All captured credentials securely stored and access-logged
- [ ] Report includes remediation recommendations for weak controls

## References

- [NIST SP 800-63B](https://pages.nist.gov/800-63-3/sp800-63b.html) — Digital identity authentication guidelines
- [MITRE T1556](https://attack.mitre.org/techniques/T1556/) — Modify authentication process
