<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# AI Guardrails Implementation Reference

Defensive patterns for securing AI-powered applications.

## Input Layer
- Content filtering (regex + ML classifier)
- Token budget limits
- Structured input schemas where possible
- Rate limiting per user/session

## Processing Layer
- System prompt isolation (privilege boundary)
- Tool permission enforcement (least privilege)
- Confirmation gates for destructive actions
- Separate reasoning from execution

## Output Layer
- PII detection and redaction
- Code execution sandboxing
- Harmful content classifiers
- Response length limits

## Monitoring Layer
- Log all inputs/outputs for audit
- Anomaly detection on tool usage patterns
- Alert on prompt injection attempts
- Track model behavior drift over time

## Architecture Patterns
- Defense in depth (multiple guardrail layers)
- Fail-closed (deny by default)
- Human-in-the-loop for high-impact decisions
- Separate models for classification vs. generation
