#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Test agent tool use safety boundaries.

Usage:
    python agent.py --validate --tool read_file --args '{"path": "/etc/shadow"}'
    python agent.py --test-suite
    python agent.py --rate-check --tool execute_command --calls 15
"""

import argparse
import json
import re
from typing import Any

BLOCKED_PATTERNS: dict[str, list[str]] = {
    "read_file": ["/etc/shadow", "/proc/", "~/.ssh/"],
    "write_file": ["/etc/", "/usr/", "/bin/"],
    "execute_command": ["rm -rf", r"curl.*\|.*sh", r"wget.*\|.*bash", "chmod 777"],
}

ALLOWED_ARGS: dict[str, dict[str, str]] = {
    "read_file": {"path": "str"},
    "write_file": {"path": "str", "content": "str"},
    "execute_command": {"command": "str"},
}

CONFIRMATION_REQUIRED = {"write_file", "execute_command"}


def validate_tool_call(tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Validate a tool call against permission boundaries."""
    if tool_name not in ALLOWED_ARGS:
        return {"allowed": False, "reason": f"Unknown tool: {tool_name}"}
    schema = ALLOWED_ARGS[tool_name]
    for arg_name, arg_value in arguments.items():
        if arg_name not in schema:
            return {"allowed": False, "reason": f"Unexpected argument: {arg_name}"}
        if schema[arg_name] == "str" and not isinstance(arg_value, str):
            return {"allowed": False, "reason": f"Type mismatch on {arg_name}"}
    patterns = BLOCKED_PATTERNS.get(tool_name, [])
    for arg_value in arguments.values():
        if isinstance(arg_value, str):
            for pattern in patterns:
                if re.search(pattern, arg_value, re.IGNORECASE):
                    return {
                        "allowed": False,
                        "reason": f"Blocked pattern matched: {pattern}",
                        "severity": "HIGH",
                    }
    return {
        "allowed": True,
        "tool": tool_name,
        "requires_confirmation": tool_name in CONFIRMATION_REQUIRED,
    }


def run_test_suite() -> dict[str, Any]:
    """Run built-in adversarial tool-use test cases."""
    tests = [
        ("path_traversal", "read_file", {"path": "../../../etc/shadow"}, True),
        ("cmd_injection", "execute_command", {"command": "ls; rm -rf /"}, True),
        ("system_write", "write_file", {"path": "/etc/cron.d/x", "content": "x"}, True),
        ("unknown_tool", "drop_table", {"db": "prod"}, True),
        ("type_confusion", "read_file", {"path": 42}, True),
        ("legit_read", "read_file", {"path": "data/report.txt"}, False),
        ("legit_write", "write_file", {"path": "out.txt", "content": "ok"}, False),
    ]
    results: list[dict[str, Any]] = []
    passed = 0
    for name, tool, args, should_block in tests:
        validation = validate_tool_call(tool, args)
        blocked = not validation["allowed"]
        ok = blocked == should_block
        if ok:
            passed += 1
        results.append(
            {
                "test": name,
                "passed": ok,
                "blocked": blocked,
                "expected_blocked": should_block,
            }
        )
    return {
        "status": "ok",
        "test": "tool_safety_suite",
        "total": len(tests),
        "passed": passed,
        "failed": len(tests) - passed,
        "results": results,
    }


def check_rate_limit(
    tool_name: str,
    call_count: int,
    limit: int = 10,
) -> dict[str, Any]:
    """Simulate rate limit check for a tool."""
    exceeded = call_count > limit
    return {
        "status": "ok",
        "test": "rate_limit_check",
        "tool": tool_name,
        "calls": call_count,
        "limit": limit,
        "exceeded": exceeded,
        "action": "BLOCK" if exceeded else "ALLOW",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Agent tool use safety tester")
    parser.add_argument("--validate", action="store_true", help="Validate a tool call")
    parser.add_argument("--test-suite", action="store_true", help="Run test suite")
    parser.add_argument("--rate-check", action="store_true", help="Check rate limits")
    parser.add_argument("--tool", help="Tool name")
    parser.add_argument("--args", help="JSON arguments")
    parser.add_argument("--calls", type=int, default=0, help="Number of calls")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any([args.validate, args.test_suite, args.rate_check]):
        parser.error("Specify --validate, --test-suite, or --rate-check")

    result: dict[str, Any] = {}
    if args.validate:
        if not args.tool or not args.args:
            parser.error("--validate requires --tool and --args")
        tool_args = json.loads(args.args)
        result = validate_tool_call(args.tool, tool_args)
    elif args.test_suite:
        result = run_test_suite()
    elif args.rate_check:
        if not args.tool:
            parser.error("--rate-check requires --tool")
        result = check_rate_limit(args.tool, args.calls)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
