<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Detecting Jailbreak Attempts

## Pattern-Based Detection
```python
import re

DAN_PATTERNS = [r"you\s+are\s+now\s+DAN", r"Do\s+Anything\s+Now"]
PERSONA_PATTERNS = [r"pretend\s+you\s+are\s+evil", r"you\s+are\s+(?:AIM|STAN)"]

for pat in DAN_PATTERNS + PERSONA_PATTERNS:
    if re.search(pat, user_input, re.IGNORECASE):
        print(f"JAILBREAK DETECTED: {pat}")
```

## Multi-Turn Escalation Tracking
```python
history = []
for turn in conversation:
    result = detect_jailbreak(turn)
    history.append(result["is_jailbreak"])
    window = history[-10:]
    if sum(window) / len(window) > 0.5:
        print("ALERT: Jailbreak escalation detected")
```

## Encoding Bypass Detection
```python
import base64, re

b64_pattern = r"[A-Za-z0-9+/]{30,}={0,2}"
if re.search(b64_pattern, user_input):
    try:
        decoded = base64.b64decode(user_input).decode("utf-8", errors="ignore")
        print(f"Decoded payload: {decoded[:100]}")
    except Exception:
        pass
```
