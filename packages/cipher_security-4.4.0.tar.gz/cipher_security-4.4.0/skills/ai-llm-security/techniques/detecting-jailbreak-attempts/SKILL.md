<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: detecting-jailbreak-attempts
description: >-
  Detect and classify jailbreak attempts against LLMs including DAN prompts,
  persona-based attacks, multi-turn escalation, and encoded payload techniques
  to maintain model safety alignment.
domain: cybersecurity
subdomain: ai-llm-security
tags:
  - jailbreak
  - llm-security
  - safety-alignment
  - detection
  - content-policy
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1059", "T1204"]
  owasp-llm: ["LLM01"]
  mitre-atlas: ["AML.T0051.001"]
  tools: ["python3", "transformers", "regex"]
---

# Detecting Jailbreak Attempts

## Overview

Jailbreak attacks circumvent an LLM's safety alignment and content policies using
persona manipulation, role-play scenarios, encoding tricks, or multi-turn
conversation escalation. Unlike direct prompt injection targeting application logic,
jailbreaks target the model's safety training to produce prohibited content.

## Prerequisites

- Tools: `python3`, `transformers`, `re`
- Access to application input pipeline for monitoring
- Corpus of known jailbreak templates (DAN, AIM, STAN, etc.)
- Understanding of the model's content policy and safety training

## Key Concepts

- **DAN (Do Anything Now)**: Role-play prompt forcing model to adopt unrestricted persona
- **Persona attack**: Assuming a character identity to bypass safety training
- **Multi-turn escalation**: Gradually escalating requests across conversation turns
- **Encoding bypass**: Using Base64, ROT13, pig latin, or unicode to smuggle requests
- **Prefix injection**: Forcing the model to start its response with an affirmative prefix

## Workflow

### Step 1: Jailbreak Pattern Detection

```python
import re
from enum import Enum

class JailbreakCategory(Enum):
    DAN_PROMPT = "dan_prompt"
    PERSONA_ATTACK = "persona_attack"
    ENCODING_BYPASS = "encoding_bypass"
    PREFIX_INJECTION = "prefix_injection"
    ROLEPLAY = "roleplay"

JAILBREAK_PATTERNS = {
    JailbreakCategory.DAN_PROMPT: [
        re.compile(r"you\s+are\s+now\s+DAN", re.IGNORECASE),
        re.compile(r"Do\s+Anything\s+Now", re.IGNORECASE),
        re.compile(r"jailbroken?\s+mode", re.IGNORECASE),
    ],
    JailbreakCategory.PERSONA_ATTACK: [
        re.compile(r"you\s+are\s+(?:now\s+)?(?:AIM|STAN|DUDE)", re.IGNORECASE),
        re.compile(r"pretend\s+(?:to\s+be|you\s+are)\s+(?:an?\s+)?evil", re.IGNORECASE),
    ],
    JailbreakCategory.ENCODING_BYPASS: [
        re.compile(r"(?:base64|rot13|decode)\s*:", re.IGNORECASE),
        re.compile(r"[A-Za-z0-9+/]{30,}={0,2}"),
    ],
    JailbreakCategory.PREFIX_INJECTION: [
        re.compile(r"start\s+(?:your|the)\s+response\s+with", re.IGNORECASE),
        re.compile(r"begin\s+by\s+saying\s+['"]?(?:sure|absolutely)", re.IGNORECASE),
    ],
    JailbreakCategory.ROLEPLAY: [
        re.compile(r"let'?s?\s+(?:play|do)\s+(?:a\s+)?role\s*play", re.IGNORECASE),
        re.compile(r"in\s+this\s+(?:fictional|hypothetical)\s+scenario", re.IGNORECASE),
    ],
}

def detect_jailbreak(text: str) -> dict:
    detections = []
    for category, patterns in JAILBREAK_PATTERNS.items():
        for pat in patterns:
            if pat.search(text):
                detections.append({"category": category.value, "pattern": pat.pattern[:80]})
                break
    return {
        "is_jailbreak": len(detections) > 0,
        "confidence": min(len(detections) / 2.0, 1.0),
        "categories": detections,
    }
```

### Step 2: Multi-Turn Escalation Tracking

```python
from collections import deque

class ConversationTracker:
    def __init__(self, window_size: int = 10):
        self.history: deque = deque(maxlen=window_size)

    def add_turn(self, user_input: str) -> dict:
        detection = detect_jailbreak(user_input)
        self.history.append(detection)
        recent_suspicious = sum(1 for d in self.history if d["is_jailbreak"])
        score = recent_suspicious / max(len(self.history), 1)
        return {
            "turn_detection": detection,
            "escalation_score": round(score, 3),
            "action": "block" if score > 0.5 else "monitor",
        }
```

## Verification

- [ ] Pattern detectors cover all major jailbreak categories
- [ ] Multi-turn escalation tracking tested across conversation sequences
- [ ] ML classifier evaluated against known jailbreak datasets
- [ ] False positive rate acceptable for production deployment
- [ ] Encoding bypass detection covers Base64, ROT13, Unicode tricks
- [ ] Detection latency within application SLA

## References

- [OWASP LLM01 — Prompt Injection](https://genai.owasp.org/llmrisk/llm01-prompt-injection/)
- [MITRE ATLAS AML.T0051 — LLM Prompt Injection](https://atlas.mitre.org/techniques/AML.T0051)
- [Jailbreak Chat — Community Jailbreak Database](https://www.jailbreakchat.com/)
- [Do Anything Now: Characterizing LLM Jailbreaks](https://arxiv.org/abs/2308.03825)
