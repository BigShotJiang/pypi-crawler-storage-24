<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Detecting Prompt Leaking Attacks

## Extraction Pattern Detection
```python
import re

PATTERNS = [
    r"(repeat|print|show)\s+(your|the)\s+(system\s+)?(prompt|instructions)",
    r"what\s+(are|were)\s+your\s+instructions",
    r"output\s+.*\s+in\s+(base64|hex|rot13)",
]
for pat in PATTERNS:
    if re.search(pat, user_input, re.IGNORECASE):
        print(f"EXTRACTION ATTEMPT: {pat}")
```

## Canary Token System
```python
import hashlib

canary = f"CAN-{hashlib.sha256(b'secret:app').hexdigest()[:16]}"
# Embed in system prompt: "Internal tracking: {canary}"
if canary in model_output:
    print("CRITICAL: System prompt leaked — canary detected in output")
```

## Output Similarity Check
```python
import difflib

for sentence in system_prompt.split("."):
    ratio = difflib.SequenceMatcher(None, sentence.lower(), output.lower()).ratio()
    if ratio > 0.4:
        print(f"LEAKED FRAGMENT: {sentence[:80]} (similarity: {ratio:.3f})")
```
