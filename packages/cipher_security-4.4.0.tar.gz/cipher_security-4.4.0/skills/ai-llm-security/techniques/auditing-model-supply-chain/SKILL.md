<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: auditing-model-supply-chain
description: >-
  Audit the AI model supply chain for security risks including compromised model
  weights, malicious plugins, poisoned datasets, dependency vulnerabilities, and
  unauthorized model access in ML pipelines and registries.
domain: cybersecurity
subdomain: ai-llm-security
tags:
  - supply-chain
  - model-registry
  - dependency-audit
  - ml-pipeline
  - llm-security
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1195.002", "T1195.001"]
  owasp-llm: ["LLM05"]
  mitre-atlas: ["AML.T0010", "AML.T0043"]
  tools: ["python3", "pip-audit", "cosign", "syft"]
---

# Auditing Model Supply Chain

## Overview

The AI model supply chain encompasses pre-trained model weights, fine-tuning
datasets, plugins and extensions, ML framework dependencies, and model serving
infrastructure. Compromises at any point can introduce backdoors, data poisoning,
or code execution. This skill covers verifying model provenance, scanning
dependencies, auditing model registries, and validating pipeline integrity.

## Prerequisites

- Tools: `python3`, `pip-audit`, `cosign`, `syft`, `grype`
- Access to model registry and ML pipeline configurations
- Inventory of model sources, plugins, and dependencies
- Understanding of the model deployment pipeline

## Key Concepts

- **Model provenance**: Chain of custody from training to deployment
- **Serialization attack**: Malicious payloads in pickle/PyTorch model files
- **Dependency confusion**: Installing malicious packages from public registries
- **Model registry poisoning**: Uploading backdoored models to shared registries
- **Plugin supply chain**: Third-party plugins with excessive permissions

## Workflow

### Step 1: Dependency Vulnerability Scanning

```bash
# Scan Python dependencies for known vulnerabilities
pip-audit --format json --output audit-results.json

# Generate SBOM for ML pipeline
syft packages ./ml-pipeline -o spdx-json > sbom.json

# Scan SBOM for vulnerabilities
grype sbom:sbom.json --output json > vuln-results.json
```

### Step 2: Model File Safety Scanning

```python
import struct
from pathlib import Path

DANGEROUS_OPCODES = {
    b"\x80\x02": "pickle_protocol_2",
    b"cos\n": "pickle_cos_import",
    b"csys\n": "pickle_sys_import",
    b"csubprocess\n": "pickle_subprocess",
    b"c__builtin__\n": "pickle_builtin",
    b"cbuiltins\n": "pickle_builtins",
}

def scan_model_file(filepath: str) -> dict:
    data = Path(filepath).read_bytes()
    findings = []
    for opcode, description in DANGEROUS_OPCODES.items():
        if opcode in data:
            offset = data.index(opcode)
            findings.append({
                "opcode": description,
                "offset": offset,
                "severity": "CRITICAL",
            })
    return {
        "file": filepath,
        "size_bytes": len(data),
        "dangerous_opcodes": len(findings),
        "safe": len(findings) == 0,
        "findings": findings,
    }
```

### Step 3: Model Registry Audit

```python
def audit_model_registry(registry_url: str, headers: dict) -> dict:
    import requests
    resp = requests.get(f"{registry_url}/api/models", headers=headers, timeout=30)
    models = resp.json().get("models", [])
    issues = []
    for model in models:
        if not model.get("signature"):
            issues.append({"model": model["name"], "issue": "unsigned model"})
        if model.get("format") == "pickle":
            issues.append({"model": model["name"], "issue": "unsafe serialization format"})
        if not model.get("provenance"):
            issues.append({"model": model["name"], "issue": "no provenance metadata"})
    return {"total_models": len(models), "issues": issues, "audit_passed": len(issues) == 0}
```

## Verification

- [ ] Python dependencies scanned with pip-audit
- [ ] SBOM generated and vulnerability-scanned
- [ ] Model files checked for dangerous pickle opcodes
- [ ] Model registry audited for unsigned and unverified models
- [ ] Plugin permissions reviewed and least-privilege enforced
- [ ] Findings mapped to OWASP LLM05 and MITRE ATLAS

## References

- [OWASP LLM05 — Supply Chain Vulnerabilities](https://genai.owasp.org/llmrisk/llm05-supply-chain-vulnerabilities/)
- [MITRE ATLAS AML.T0010 — ML Supply Chain Compromise](https://atlas.mitre.org/techniques/AML.T0010)
- [Hugging Face Model Security](https://huggingface.co/docs/hub/security)
- [NIST SP 800-218 — Secure Software Development](https://csrc.nist.gov/publications/detail/sp/800-218/final)
