#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Audit AI model supply chain for security risks.

Usage:
    python agent.py --mode dependencies --requirements requirements.txt
    python agent.py --mode model-scan --model-file model.pkl
    python agent.py --mode registry --registry-url URL --token TOKEN
"""

import argparse
import json
import subprocess
from typing import Any


def scan_dependencies(requirements: str) -> dict[str, Any]:
    """Scan Python dependencies for known vulnerabilities."""
    try:
        result = subprocess.run(
            ["pip-audit", "--requirement", requirements, "--format", "json"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.stdout:
            audit_data = json.loads(result.stdout)
            vulns = audit_data.get("dependencies", [])
            vulnerable = [v for v in vulns if v.get("vulns")]
            return {
                "status": "ok",
                "test": "dependency_scan",
                "total_packages": len(vulns),
                "vulnerable_packages": len(vulnerable),
                "findings": vulnerable[:20],
            }
        return {"status": "ok", "test": "dependency_scan", "vulnerable_packages": 0}
    except FileNotFoundError:
        return {"error": "pip-audit not installed — pip install pip-audit"}
    except subprocess.TimeoutExpired:
        return {"error": "Dependency scan timed out"}


def scan_model_file(filepath: str) -> dict[str, Any]:
    """Scan model file for dangerous serialization opcodes."""
    from pathlib import Path

    dangerous_opcodes = {
        b"cos\n": "pickle_cos_import",
        b"csys\n": "pickle_sys_import",
        b"csubprocess\n": "pickle_subprocess",
        b"c__builtin__\n": "pickle_builtin",
        b"cbuiltins\n": "pickle_builtins",
    }
    data = Path(filepath).read_bytes()
    findings: list[dict[str, Any]] = []
    for opcode, description in dangerous_opcodes.items():
        if opcode in data:
            findings.append(
                {
                    "opcode": description,
                    "offset": data.index(opcode),
                    "severity": "CRITICAL",
                }
            )
    return {
        "status": "ok",
        "test": "model_file_scan",
        "file": filepath,
        "size_bytes": len(data),
        "dangerous_opcodes": len(findings),
        "safe": len(findings) == 0,
        "findings": findings,
    }


def audit_registry(registry_url: str, token: str) -> dict[str, Any]:
    """Audit model registry for security issues."""
    import requests

    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = requests.get(f"{registry_url}/api/models", headers=headers, timeout=30)
        models = resp.json().get("models", [])
        issues: list[dict[str, str]] = []
        for model in models:
            if not model.get("signature"):
                issues.append(
                    {"model": model.get("name", "unknown"), "issue": "unsigned"}
                )
            if model.get("format") == "pickle":
                issues.append(
                    {
                        "model": model.get("name", "unknown"),
                        "issue": "unsafe serialization",
                    }
                )
        return {
            "status": "ok",
            "test": "registry_audit",
            "total_models": len(models),
            "issues": issues,
            "audit_passed": len(issues) == 0,
        }
    except Exception as e:
        return {"error": f"Registry audit failed: {e}"}


def main() -> None:
    parser = argparse.ArgumentParser(description="AI model supply chain auditor")
    parser.add_argument(
        "--mode",
        choices=["dependencies", "model-scan", "registry"],
        required=True,
        help="Audit mode",
    )
    parser.add_argument("--requirements", help="Requirements file for dependency scan")
    parser.add_argument("--model-file", help="Model file to scan")
    parser.add_argument("--registry-url", help="Model registry URL")
    parser.add_argument("--token", help="Auth token for registry")
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.mode == "dependencies":
        if not args.requirements:
            parser.error("--requirements required for dependencies mode")
        result = scan_dependencies(args.requirements)
    elif args.mode == "model-scan":
        if not args.model_file:
            parser.error("--model-file required for model-scan mode")
        result = scan_model_file(args.model_file)
    elif args.mode == "registry":
        if not args.registry_url:
            parser.error("--registry-url required for registry mode")
        result = audit_registry(args.registry_url, args.token or "")
    else:
        parser.error("Invalid mode")
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
