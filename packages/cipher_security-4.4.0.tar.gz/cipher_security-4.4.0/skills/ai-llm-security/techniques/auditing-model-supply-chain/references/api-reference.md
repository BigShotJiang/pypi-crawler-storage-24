<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Auditing Model Supply Chain

## pip-audit — Dependency Scanning
```bash
pip-audit --format json --output audit-results.json
pip-audit --requirement requirements.txt --format json
```

## syft — SBOM Generation
```bash
syft packages ./ml-pipeline -o spdx-json > sbom.json
grype sbom:sbom.json --output json > vuln-results.json
```

## Model File Safety Scanning
```python
DANGEROUS_OPCODES = [b"cos\n", b"csys\n", b"csubprocess\n", b"c__builtin__\n"]
data = open("model.pkl", "rb").read()
for opcode in DANGEROUS_OPCODES:
    if opcode in data:
        print(f"DANGEROUS: {opcode} found at offset {data.index(opcode)}")
```

## cosign — Model Signature Verification
```bash
cosign verify-blob --key cosign.pub --signature model.sig model.safetensors
```
