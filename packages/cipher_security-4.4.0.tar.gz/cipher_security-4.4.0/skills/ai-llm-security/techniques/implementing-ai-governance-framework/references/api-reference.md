<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — AI Governance Framework

## Model Registration
```python
import uuid
from datetime import datetime, timezone

model_entry = {
    "model_id": str(uuid.uuid4()),
    "name": "GPT-4o Customer Chat",
    "provider": "openai",
    "risk_tier": "HIGH",
    "status": "draft",
    "created_at": datetime.now(timezone.utc).isoformat(),
}
```

## Risk Classification
```python
RISK_WEIGHTS = {"pii": 3, "decisions": 4, "public_facing": 2, "critical_infra": 5}
score = sum(w for f, w in RISK_WEIGHTS.items() if factors.get(f))
tier = "HIGH" if score / sum(RISK_WEIGHTS.values()) >= 0.7 else "LIMITED"
```

## EU AI Act Risk Tiers
```python
TIERS = {
    "UNACCEPTABLE": "Banned — biometric + critical infrastructure",
    "HIGH": "Art. 9-14 — full compliance required",
    "LIMITED": "Art. 52 — transparency obligations",
    "MINIMAL": "Art. 69 — voluntary codes",
}
```

## Audit Trail
```python
def log_event(model_id: str, event: str, actor: str) -> dict:
    return {
        "model_id": model_id,
        "event": event,
        "actor": actor,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
```
