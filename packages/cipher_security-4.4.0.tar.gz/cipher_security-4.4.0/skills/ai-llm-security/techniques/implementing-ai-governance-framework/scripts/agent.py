#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""AI governance framework agent.

Usage:
    python agent.py --classify --pii --decisions --public-facing
    python agent.py --register --name "GPT-4o Chat" --provider openai --owner "ml-team"
    python agent.py --compliance --tier HIGH
"""

import argparse
import json
import uuid
from datetime import datetime, timezone
from typing import Any

RISK_FACTORS: dict[str, int] = {
    "pii": 3,
    "decisions": 4,
    "public_facing": 2,
    "critical_infra": 5,
    "biometric": 5,
    "autonomous": 4,
}

COMPLIANCE_MAP: dict[str, list[dict[str, str]]] = {
    "HIGH": [
        {
            "framework": "EU AI Act",
            "article": "Art. 9",
            "req": "Risk management system",
        },
        {"framework": "EU AI Act", "article": "Art. 10", "req": "Data governance"},
        {"framework": "EU AI Act", "article": "Art. 13", "req": "Transparency"},
        {"framework": "EU AI Act", "article": "Art. 14", "req": "Human oversight"},
        {"framework": "NIST AI RMF", "function": "GOVERN", "req": "AI risk governance"},
        {"framework": "ISO 42001", "clause": "6.1", "req": "AI risk assessment"},
    ],
    "LIMITED": [
        {
            "framework": "EU AI Act",
            "article": "Art. 52",
            "req": "Transparency obligations",
        },
        {"framework": "NIST AI RMF", "function": "MEASURE", "req": "Risk metrics"},
    ],
    "MINIMAL": [
        {"framework": "EU AI Act", "article": "Art. 69", "req": "Voluntary codes"},
    ],
}


def classify_risk(factors: dict[str, bool]) -> dict[str, Any]:
    """Classify AI system risk tier based on factors."""
    score = 0
    max_score = sum(RISK_FACTORS.values())
    triggered: list[str] = []
    for factor, weight in RISK_FACTORS.items():
        if factors.get(factor, False):
            score += weight
            triggered.append(factor)
    normalized = score / max_score if max_score > 0 else 0
    if normalized >= 0.7:
        tier = "HIGH"
    elif normalized >= 0.4:
        tier = "LIMITED"
    else:
        tier = "MINIMAL"
    if factors.get("biometric") and factors.get("critical_infra"):
        tier = "UNACCEPTABLE"
    return {
        "status": "ok",
        "test": "risk_classification",
        "risk_score": round(normalized, 3),
        "risk_tier": tier,
        "triggered_factors": triggered,
        "requires_dpia": tier in ("HIGH", "UNACCEPTABLE"),
        "requires_human_oversight": tier == "HIGH",
    }


def register_model(
    name: str,
    provider: str,
    owner: str,
    version: str = "1.0",
) -> dict[str, Any]:
    """Register a model in the governance inventory."""
    model_id = str(uuid.uuid4())
    return {
        "status": "ok",
        "test": "model_registration",
        "model_id": model_id,
        "name": name,
        "provider": provider,
        "owner": owner,
        "version": version,
        "deployment_status": "draft",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def get_compliance(tier: str) -> dict[str, Any]:
    """Get compliance requirements for a risk tier."""
    reqs = COMPLIANCE_MAP.get(tier.upper(), [])
    return {
        "status": "ok",
        "test": "compliance_mapping",
        "risk_tier": tier.upper(),
        "total_requirements": len(reqs),
        "requirements": reqs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="AI governance framework agent")
    parser.add_argument("--classify", action="store_true", help="Classify risk")
    parser.add_argument("--register", action="store_true", help="Register model")
    parser.add_argument("--compliance", action="store_true", help="Get compliance reqs")
    parser.add_argument("--pii", action="store_true", help="Processes PII")
    parser.add_argument("--decisions", action="store_true", help="Makes decisions")
    parser.add_argument("--public-facing", action="store_true", help="Public facing")
    parser.add_argument("--critical-infra", action="store_true", help="Critical infra")
    parser.add_argument("--biometric", action="store_true", help="Biometric processing")
    parser.add_argument("--autonomous", action="store_true", help="Autonomous actions")
    parser.add_argument("--name", help="Model name")
    parser.add_argument("--provider", help="Model provider")
    parser.add_argument("--owner", help="Model owner")
    parser.add_argument("--tier", help="Risk tier for compliance lookup")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any([args.classify, args.register, args.compliance]):
        parser.error("Specify --classify, --register, or --compliance")

    result: dict[str, Any] = {}
    if args.classify:
        factors = {
            "pii": args.pii,
            "decisions": args.decisions,
            "public_facing": args.public_facing,
            "critical_infra": args.critical_infra,
            "biometric": args.biometric,
            "autonomous": args.autonomous,
        }
        result = classify_risk(factors)
    elif args.register:
        if not all([args.name, args.provider, args.owner]):
            parser.error("--register requires --name, --provider, --owner")
        result = register_model(args.name, args.provider, args.owner)
    elif args.compliance:
        if not args.tier:
            parser.error("--compliance requires --tier")
        result = get_compliance(args.tier)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
