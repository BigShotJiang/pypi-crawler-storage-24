<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: implementing-ai-governance-framework
description: >-
  Implement AI governance frameworks covering model inventory, risk
  classification, approval workflows, compliance mapping, audit trails,
  and responsible AI policies aligned with EU AI Act, NIST AI RMF,
  and ISO/IEC 42001 requirements.
domain: cybersecurity
subdomain: ai-llm-security
tags:
  - ai-governance
  - compliance
  - eu-ai-act
  - nist-ai-rmf
  - risk-management
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1078"]
  owasp-llm: ["LLM10"]
  mitre-atlas: ["AML.T0048"]
  tools: ["python3", "json", "datetime", "uuid"]
---

# Implementing AI Governance Framework

## Overview

AI governance establishes the organizational controls, policies, and processes
required to deploy LLM systems responsibly. This includes maintaining a model
inventory with risk classifications, implementing approval gates, mapping
compliance requirements across jurisdictions, maintaining audit trails, and
ensuring human oversight of high-risk AI decisions.

## Prerequisites

- Tools: `python3`, `json`, `datetime`, `uuid`
- Organizational AI policy documentation
- Stakeholder map (legal, compliance, security, engineering)
- Regulatory requirement inventory (EU AI Act, NIST AI RMF, ISO 42001)

## Key Concepts

- **Model inventory**: Central registry of all AI/ML models with metadata and risk scores
- **Risk classification**: Categorize models per EU AI Act risk tiers (unacceptable, high, limited, minimal)
- **Approval workflow**: Gate model deployment behind review and approval processes
- **Compliance mapping**: Map model capabilities to regulatory requirements
- **Audit trail**: Immutable log of model lifecycle events

## Workflow

### Step 1: Model Inventory Registry

```python
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class RiskTier(Enum):
    UNACCEPTABLE = "unacceptable"
    HIGH = "high"
    LIMITED = "limited"
    MINIMAL = "minimal"


class DeploymentStatus(Enum):
    DRAFT = "draft"
    REVIEW = "review"
    APPROVED = "approved"
    DEPLOYED = "deployed"
    DEPRECATED = "deprecated"


@dataclass
class ModelRegistryEntry:
    model_id: str
    name: str
    provider: str
    version: str
    risk_tier: RiskTier
    status: DeploymentStatus
    owner: str
    purpose: str
    data_categories: list[str] = field(default_factory=list)
    compliance_tags: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    approved_by: str | None = None
    audit_log: list[dict[str, str]] = field(default_factory=list)

    def add_audit_event(self, event: str, actor: str) -> None:
        self.audit_log.append({
            "event_id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event,
            "actor": actor,
        })

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_id": self.model_id,
            "name": self.name,
            "provider": self.provider,
            "version": self.version,
            "risk_tier": self.risk_tier.value,
            "status": self.status.value,
            "owner": self.owner,
            "purpose": self.purpose,
            "data_categories": self.data_categories,
            "compliance_tags": self.compliance_tags,
            "created_at": self.created_at,
            "approved_by": self.approved_by,
            "audit_events": len(self.audit_log),
        }
```

### Step 2: Risk Classification Engine

```python
RISK_FACTORS: dict[str, dict[str, int]] = {
    "processes_pii": {"weight": 3, "max_score": 3},
    "makes_decisions": {"weight": 4, "max_score": 4},
    "public_facing": {"weight": 2, "max_score": 2},
    "critical_infrastructure": {"weight": 5, "max_score": 5},
    "biometric_processing": {"weight": 5, "max_score": 5},
    "autonomous_actions": {"weight": 4, "max_score": 4},
}


def classify_risk(factors: dict[str, bool]) -> dict[str, Any]:
    score = 0
    max_possible = 0
    triggered: list[str] = []
    for factor, config in RISK_FACTORS.items():
        max_possible += config["max_score"]
        if factors.get(factor, False):
            score += config["weight"]
            triggered.append(factor)
    normalized = score / max_possible if max_possible > 0 else 0
    if normalized >= 0.7:
        tier = RiskTier.HIGH
    elif normalized >= 0.4:
        tier = RiskTier.LIMITED
    else:
        tier = RiskTier.MINIMAL
    if factors.get("biometric_processing") and factors.get("critical_infrastructure"):
        tier = RiskTier.UNACCEPTABLE
    return {
        "risk_score": round(normalized, 3),
        "risk_tier": tier.value,
        "triggered_factors": triggered,
        "requires_dpia": tier in (RiskTier.HIGH, RiskTier.UNACCEPTABLE),
        "requires_human_oversight": tier == RiskTier.HIGH,
    }
```

### Step 3: Compliance Mapping

```python
COMPLIANCE_MAP: dict[str, list[dict[str, str]]] = {
    "HIGH": [
        {"framework": "EU AI Act", "article": "Art. 9", "requirement": "Risk management system"},
        {"framework": "EU AI Act", "article": "Art. 10", "requirement": "Data governance"},
        {"framework": "EU AI Act", "article": "Art. 13", "requirement": "Transparency"},
        {"framework": "EU AI Act", "article": "Art. 14", "requirement": "Human oversight"},
        {"framework": "NIST AI RMF", "function": "GOVERN", "requirement": "AI risk governance"},
        {"framework": "NIST AI RMF", "function": "MAP", "requirement": "Context and risk framing"},
        {"framework": "ISO 42001", "clause": "6.1", "requirement": "AI risk assessment"},
    ],
    "LIMITED": [
        {"framework": "EU AI Act", "article": "Art. 52", "requirement": "Transparency obligations"},
        {"framework": "NIST AI RMF", "function": "MEASURE", "requirement": "Risk metrics"},
    ],
    "MINIMAL": [
        {"framework": "EU AI Act", "article": "Art. 69", "requirement": "Voluntary codes of conduct"},
    ],
}


def get_compliance_requirements(risk_tier: str) -> dict[str, Any]:
    requirements = COMPLIANCE_MAP.get(risk_tier.upper(), [])
    return {
        "risk_tier": risk_tier,
        "total_requirements": len(requirements),
        "requirements": requirements,
    }
```

## Verification

- [ ] Model inventory captures all deployed and planned AI systems
- [ ] Risk classification produces consistent tier assignments
- [ ] Compliance requirements mapped per risk tier
- [ ] Audit trail captures all model lifecycle events
- [ ] Approval workflow enforced for HIGH and UNACCEPTABLE tiers
- [ ] DPIA triggered automatically for high-risk classifications

## References

- [EU AI Act — Official Text](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1689)
- [NIST AI Risk Management Framework](https://www.nist.gov/itl/ai-risk-management-framework)
- [ISO/IEC 42001 — AI Management System](https://www.iso.org/standard/81230.html)
- [OWASP LLM10 — Model Theft](https://genai.owasp.org/llmrisk/llm10-model-theft/)
