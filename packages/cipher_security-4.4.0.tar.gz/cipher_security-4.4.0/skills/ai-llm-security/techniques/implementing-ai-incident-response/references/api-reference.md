<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — AI Incident Response

## Incident Classification
```python
SEVERITY = {"data_exfiltration": "P1", "prompt_injection": "P2", "output_manipulation": "P3"}
severity = SEVERITY.get(incident_type, "P3")
```

## Evidence Hash Preservation
```python
import hashlib

content_hash = hashlib.sha256(evidence_content.encode()).hexdigest()
# Store hash alongside evidence for chain of custody verification
```

## Containment Actions
```python
PLAYBOOK = {
    "prompt_injection": ["Enable input filtering", "Increase logging"],
    "data_exfiltration": ["Disable endpoint", "Revoke API keys"],
    "model_poisoning": ["Rollback model", "Quarantine training data"],
}
actions = PLAYBOOK.get(incident_type, [])
```

## Timeline Construction
```python
from datetime import datetime, timezone

timeline = []
timeline.append({
    "timestamp": datetime.now(timezone.utc).isoformat(),
    "event": "Incident detected via safety filter alert",
    "source": "monitoring_system",
})
```
