#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""AI incident response agent.

Usage:
    python agent.py --classify --type prompt_injection --model "gpt-4o-chat" --title "Injection on /api/chat"
    python agent.py --containment --type data_exfiltration
    python agent.py --collect-evidence --type prompt_log --content "ignore previous..." --source "api-gw"
"""

import argparse
import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any

SEVERITY_MAP: dict[str, str] = {
    "prompt_injection": "P2",
    "data_exfiltration": "P1",
    "model_poisoning": "P1",
    "excessive_agency": "P2",
    "output_manipulation": "P3",
    "model_theft": "P1",
    "training_data_leak": "P2",
    "safety_bypass": "P2",
}

CONTAINMENT_PLAYBOOK: dict[str, list[dict[str, str]]] = {
    "prompt_injection": [
        {"action": "Enable enhanced input filtering", "priority": "immediate"},
        {"action": "Increase logging verbosity", "priority": "immediate"},
        {"action": "Deploy updated injection classifier", "priority": "short_term"},
    ],
    "data_exfiltration": [
        {"action": "Disable affected model endpoint", "priority": "immediate"},
        {"action": "Revoke associated API keys", "priority": "immediate"},
        {"action": "Enable output content scanning", "priority": "short_term"},
    ],
    "model_poisoning": [
        {"action": "Rollback to last known-good model", "priority": "immediate"},
        {"action": "Quarantine poisoned training data", "priority": "immediate"},
        {"action": "Re-run evaluation benchmarks", "priority": "short_term"},
    ],
    "excessive_agency": [
        {"action": "Disable agent tool execution", "priority": "immediate"},
        {"action": "Enable human-in-the-loop", "priority": "immediate"},
        {"action": "Audit recent tool invocations", "priority": "short_term"},
    ],
}


def classify_incident(
    incident_type: str,
    model: str,
    title: str,
) -> dict[str, Any]:
    """Classify an AI incident with severity and initial response."""
    severity = SEVERITY_MAP.get(incident_type, "P3")
    return {
        "status": "ok",
        "test": "incident_classification",
        "incident_id": str(uuid.uuid4()),
        "type": incident_type,
        "severity": severity,
        "title": title,
        "affected_model": model,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "next_steps": [
            "Collect evidence",
            "Execute containment",
            "Notify stakeholders",
        ],
    }


def get_containment(incident_type: str) -> dict[str, Any]:
    """Get containment actions for an incident type."""
    actions = CONTAINMENT_PLAYBOOK.get(incident_type, [])
    return {
        "status": "ok",
        "test": "containment_playbook",
        "incident_type": incident_type,
        "total_actions": len(actions),
        "immediate": [a for a in actions if a["priority"] == "immediate"],
        "short_term": [a for a in actions if a["priority"] == "short_term"],
    }


def collect_evidence(
    evidence_type: str,
    content: str,
    source: str,
) -> dict[str, Any]:
    """Collect and hash evidence for an incident."""
    content_hash = hashlib.sha256(content.encode()).hexdigest()
    return {
        "status": "ok",
        "test": "evidence_collection",
        "evidence_id": str(uuid.uuid4()),
        "type": evidence_type,
        "source": source,
        "content_hash": content_hash,
        "content_preview": content[:200],
        "collected_at": datetime.now(timezone.utc).isoformat(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="AI incident response agent")
    parser.add_argument("--classify", action="store_true", help="Classify incident")
    parser.add_argument(
        "--containment", action="store_true", help="Get containment actions"
    )
    parser.add_argument(
        "--collect-evidence", action="store_true", help="Collect evidence"
    )
    parser.add_argument("--type", help="Incident or evidence type")
    parser.add_argument("--model", help="Affected model name")
    parser.add_argument("--title", help="Incident title")
    parser.add_argument("--content", help="Evidence content")
    parser.add_argument("--source", help="Evidence source")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any([args.classify, args.containment, args.collect_evidence]):
        parser.error("Specify --classify, --containment, or --collect-evidence")

    result: dict[str, Any] = {}
    if args.classify:
        if not all([args.type, args.model, args.title]):
            parser.error("--classify requires --type, --model, --title")
        result = classify_incident(args.type, args.model, args.title)
    elif args.containment:
        if not args.type:
            parser.error("--containment requires --type")
        result = get_containment(args.type)
    elif args.collect_evidence:
        if not all([args.type, args.content, args.source]):
            parser.error("--collect-evidence requires --type, --content, --source")
        result = collect_evidence(args.type, args.content, args.source)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
