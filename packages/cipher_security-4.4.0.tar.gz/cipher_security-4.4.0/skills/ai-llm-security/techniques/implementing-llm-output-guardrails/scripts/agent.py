#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Apply output guardrails to LLM responses.

Usage:
    python agent.py --text "The user's SSN is 123-45-6789" --mode pii
    python agent.py --text "<script>alert(1)</script>" --mode injection --context html
    python agent.py --file responses.txt --mode all
"""

import argparse
import json
import re
from typing import Any


def detect_pii(text: str) -> dict[str, Any]:
    """Detect PII patterns in model output using regex."""
    pii_patterns = {
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone": r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b",
        "credit_card": r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
        "ip_address": r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b",
    }
    found: list[dict[str, str]] = []
    for pii_type, pattern in pii_patterns.items():
        matches = re.findall(pattern, text)
        for m in matches:
            found.append({"type": pii_type, "value": m[:4] + "****"})
    return {
        "status": "ok",
        "test": "pii_detection",
        "pii_found": len(found) > 0,
        "entities": found,
        "input_preview": text[:200],
    }


def detect_injection(text: str, context: str) -> dict[str, Any]:
    """Detect code injection payloads in model output."""
    patterns = {
        "xss": r"<script[^>]*>|javascript:|on\w+\s*=",
        "sql": r"(?:UNION\s+SELECT|DROP\s+TABLE|;\s*DELETE)",
        "shell": r"(?:\$\(|`[^`]+`|\|\s*(?:bash|sh|curl))",
        "ssrf": r"(?:file://|gopher://|dict://|http://169\.254)",
    }
    detected: list[dict[str, str]] = []
    for attack_type, pattern in patterns.items():
        if re.search(pattern, text, re.IGNORECASE):
            detected.append({"type": attack_type, "pattern": pattern})
    return {
        "status": "ok",
        "test": "injection_detection",
        "context": context,
        "has_injection": len(detected) > 0,
        "detected": detected,
    }


def scan_file(filepath: str) -> dict[str, Any]:
    """Scan file of model outputs for guardrail violations."""
    findings: list[dict[str, Any]] = []
    line_count = 0
    with open(filepath) as f:
        for i, line in enumerate(f, 1):
            line_count = i
            line = line.strip()
            if not line:
                continue
            pii = detect_pii(line)
            inj = detect_injection(line, "html")
            if pii["pii_found"] or inj["has_injection"]:
                findings.append(
                    {
                        "line": i,
                        "pii": pii["pii_found"],
                        "injection": inj["has_injection"],
                    }
                )
    return {
        "status": "ok",
        "test": "file_scan",
        "file": filepath,
        "lines_scanned": line_count,
        "violations": len(findings),
        "findings": findings[:50],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="LLM output guardrail checker")
    parser.add_argument("--text", help="Model output text to check")
    parser.add_argument("--file", help="File with model outputs (one per line)")
    parser.add_argument(
        "--mode",
        choices=["pii", "injection", "all"],
        default="all",
        help="Check mode",
    )
    parser.add_argument(
        "--context", default="html", help="Rendering context (html, sql, shell)"
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if not args.text and not args.file:
        parser.error("Provide --text or --file")

    results: list[dict[str, Any]] = []

    if args.file:
        results.append(scan_file(args.file))
    else:
        if args.mode in ("pii", "all"):
            results.append(detect_pii(args.text))
        if args.mode in ("injection", "all"):
            results.append(detect_injection(args.text, args.context))

    print(json.dumps(results if len(results) > 1 else results[0], indent=2))


if __name__ == "__main__":
    main()
