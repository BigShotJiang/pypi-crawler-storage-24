<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — LLM Monitoring & Observability

## Token Usage Tracking
```python
import tiktoken

enc = tiktoken.get_encoding("cl100k_base")
input_tokens = len(enc.encode(prompt))
output_tokens = len(enc.encode(completion))
total_cost = (input_tokens / 1000) * 0.0025 + (output_tokens / 1000) * 0.01
```

## Prometheus Metrics
```python
from prometheus_client import Counter, Histogram

LLM_REQUESTS = Counter("llm_requests_total", "Total requests", ["model", "status"])
LLM_LATENCY = Histogram("llm_request_duration_seconds", "Latency", ["model"])

LLM_REQUESTS.labels(model="gpt-4o", status="ok").inc()
LLM_LATENCY.labels(model="gpt-4o").observe(1.23)
```

## Structured Logging
```python
import structlog

logger = structlog.get_logger()
logger.info("llm_call", model="gpt-4o", tokens_in=500, tokens_out=200, cost=0.0075)
```

## Anomaly Detection
```python
import statistics

values = [100, 120, 110, 5000, 115]
mean = statistics.mean(values)
stdev = statistics.stdev(values)
z_scores = [(v - mean) / stdev for v in values]
anomalies = [v for v, z in zip(values, z_scores) if abs(z) > 3.0]
```
