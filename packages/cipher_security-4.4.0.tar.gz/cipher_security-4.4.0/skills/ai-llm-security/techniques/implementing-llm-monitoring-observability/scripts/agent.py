#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""LLM monitoring and observability agent.

Usage:
    python agent.py --track --model gpt-4o --input-tokens 500 --output-tokens 200 --latency 1200
    python agent.py --anomaly --token-values 100,150,120,5000,130
    python agent.py --cost --model gpt-4o --input-tokens 10000 --output-tokens 5000
"""

import argparse
import json
import statistics
import uuid
from typing import Any

COST_PER_1K: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 0.0025, "output": 0.01},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015},
}


def calculate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    rates = COST_PER_1K.get(model, {"input": 0.001, "output": 0.002})
    return round(
        (input_tokens / 1000) * rates["input"]
        + (output_tokens / 1000) * rates["output"],
        6,
    )


def track_request(
    model: str,
    input_tokens: int,
    output_tokens: int,
    latency_ms: float,
    safety_flags: list[str] | None = None,
) -> dict[str, Any]:
    """Track a single LLM request with full metrics."""
    cost = calculate_cost(model, input_tokens, output_tokens)
    return {
        "status": "ok",
        "test": "track_request",
        "request_id": str(uuid.uuid4()),
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
        "latency_ms": latency_ms,
        "cost_usd": cost,
        "safety_flags": safety_flags or [],
    }


def detect_anomaly(
    values: list[int],
    z_threshold: float = 3.0,
) -> dict[str, Any]:
    """Detect anomalies in a sequence of token counts."""
    if len(values) < 5:
        return {"status": "error", "error": "Need at least 5 values"}
    mean = statistics.mean(values)
    stdev = statistics.stdev(values)
    anomalies: list[dict[str, Any]] = []
    for i, v in enumerate(values):
        if stdev == 0:
            continue
        z = (v - mean) / stdev
        if abs(z) > z_threshold:
            anomalies.append({"index": i, "value": v, "z_score": round(z, 3)})
    return {
        "status": "ok",
        "test": "anomaly_detection",
        "total_values": len(values),
        "mean": round(mean, 2),
        "stdev": round(stdev, 2),
        "anomalies_found": len(anomalies),
        "anomalies": anomalies,
    }


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
) -> dict[str, Any]:
    """Estimate cost for a given model and token count."""
    cost = calculate_cost(model, input_tokens, output_tokens)
    return {
        "status": "ok",
        "test": "cost_estimate",
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cost_usd": cost,
        "cost_per_1k_requests": round(cost * 1000, 4),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="LLM monitoring agent")
    parser.add_argument("--track", action="store_true", help="Track an LLM request")
    parser.add_argument("--anomaly", action="store_true", help="Run anomaly detection")
    parser.add_argument("--cost", action="store_true", help="Estimate cost")
    parser.add_argument("--model", default="gpt-4o", help="Model name")
    parser.add_argument("--input-tokens", type=int, default=0, help="Input tokens")
    parser.add_argument("--output-tokens", type=int, default=0, help="Output tokens")
    parser.add_argument("--latency", type=float, default=0.0, help="Latency in ms")
    parser.add_argument("--token-values", help="Comma-separated token counts")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any([args.track, args.anomaly, args.cost]):
        parser.error("Specify --track, --anomaly, or --cost")

    result: dict[str, Any] = {}
    if args.track:
        result = track_request(
            args.model,
            args.input_tokens,
            args.output_tokens,
            args.latency,
        )
    elif args.anomaly:
        if not args.token_values:
            parser.error("--anomaly requires --token-values")
        values = [int(v.strip()) for v in args.token_values.split(",")]
        result = detect_anomaly(values)
    elif args.cost:
        result = estimate_cost(args.model, args.input_tokens, args.output_tokens)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
