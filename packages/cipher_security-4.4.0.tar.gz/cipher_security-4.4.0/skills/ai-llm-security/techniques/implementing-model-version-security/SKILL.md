<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: implementing-model-version-security
description: >-
  Implement security controls for ML model versioning including integrity
  verification with cryptographic hashes, model provenance tracking,
  supply chain validation, secure model storage, and rollback procedures
  to prevent model poisoning and unauthorized modifications.
domain: cybersecurity
subdomain: ai-llm-security
tags:
  - model-versioning
  - supply-chain
  - integrity-verification
  - model-provenance
  - secure-deployment
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1195", "T1554"]
  owasp-llm: ["LLM03", "LLM10"]
  mitre-atlas: ["AML.T0010", "AML.T0047"]
  tools: ["python3", "hashlib", "json", "pathlib"]
---

# Implementing Model Version Security

## Overview

Model supply chain attacks target the integrity of ML models at rest, in
transit, and during deployment. Attackers can poison model weights, inject
backdoors into fine-tuned models, or substitute models entirely. Security
requires cryptographic integrity verification, provenance tracking through
the model lifecycle, secure storage with access controls, and tested
rollback procedures.

## Prerequisites

- Tools: `python3`, `hashlib`, `json`, `pathlib`
- Model artifact storage with versioning support
- CI/CD pipeline with signing capability
- Vulnerability scanning for model formats (pickle, ONNX, SafeTensors)

## Key Concepts

- **Model integrity hash**: SHA-256 digest of model weights for tamper detection
- **Model provenance**: Chain of custody from training to deployment
- **Pickle deserialization risk**: Python pickle format enables arbitrary code execution
- **SafeTensors**: Secure serialization format that prevents code execution
- **Model signing**: Cryptographic signatures on model artifacts for authenticity

## Workflow

### Step 1: Model Integrity Verification

```python
import hashlib
import json
from pathlib import Path
from typing import Any


def compute_model_hash(model_path: str, algorithm: str = "sha256") -> dict[str, Any]:
    path = Path(model_path)
    if not path.exists():
        return {"error": f"File not found: {model_path}"}
    hasher = hashlib.new(algorithm)
    size = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
            size += len(chunk)
    return {
        "file": str(path),
        "algorithm": algorithm,
        "hash": hasher.hexdigest(),
        "size_bytes": size,
    }


def verify_model_integrity(
    model_path: str, expected_hash: str, algorithm: str = "sha256",
) -> dict[str, Any]:
    result = compute_model_hash(model_path, algorithm)
    if "error" in result:
        return result
    match = result["hash"] == expected_hash
    return {
        "file": model_path,
        "expected_hash": expected_hash,
        "actual_hash": result["hash"],
        "integrity_valid": match,
        "severity": "CRITICAL" if not match else "NONE",
        "action": "BLOCK DEPLOYMENT" if not match else "PROCEED",
    }
```

### Step 2: Model Format Security Scanning

```python
DANGEROUS_FORMATS: dict[str, dict[str, Any]] = {
    ".pkl": {"risk": "CRITICAL", "reason": "Arbitrary code execution via pickle"},
    ".pickle": {"risk": "CRITICAL", "reason": "Arbitrary code execution via pickle"},
    ".pt": {"risk": "HIGH", "reason": "PyTorch uses pickle internally"},
    ".pth": {"risk": "HIGH", "reason": "PyTorch checkpoint uses pickle"},
    ".joblib": {"risk": "HIGH", "reason": "Joblib uses pickle for serialization"},
    ".onnx": {"risk": "MEDIUM", "reason": "Custom ops may execute code"},
    ".safetensors": {"risk": "LOW", "reason": "Safe format, no code execution"},
    ".gguf": {"risk": "LOW", "reason": "Static weight format"},
}


def scan_model_format(model_path: str) -> dict[str, Any]:
    path = Path(model_path)
    suffix = path.suffix.lower()
    fmt_info = DANGEROUS_FORMATS.get(suffix, {"risk": "UNKNOWN", "reason": "Unrecognized format"})
    return {
        "file": str(path),
        "format": suffix,
        "risk": fmt_info["risk"],
        "reason": fmt_info["reason"],
        "recommendation": (
            "Convert to SafeTensors" if fmt_info["risk"] in ("CRITICAL", "HIGH")
            else "Acceptable format"
        ),
    }
```

### Step 3: Model Provenance Tracking

```python
from datetime import datetime, timezone


def create_provenance_record(
    model_name: str, version: str, source: str,
    training_data_hash: str, trainer: str,
) -> dict[str, Any]:
    return {
        "model_name": model_name,
        "version": version,
        "source": source,
        "training_data_hash": training_data_hash,
        "trained_by": trainer,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "provenance_chain": [
            {"stage": "training", "actor": trainer, "verified": True},
            {"stage": "validation", "actor": "automated", "verified": False},
            {"stage": "deployment", "actor": "pending", "verified": False},
        ],
    }
```

## Verification

- [ ] SHA-256 hashes computed and stored for all model artifacts
- [ ] Integrity check blocks deployment on hash mismatch
- [ ] Pickle-based formats flagged with conversion recommendation
- [ ] Provenance records created for all model versions
- [ ] Rollback procedure tested and documented
- [ ] Model signing integrated into CI/CD pipeline

## References

- [OWASP LLM03 — Training Data Poisoning](https://genai.owasp.org/llmrisk/llm03-training-data-poisoning/)
- [MITRE ATLAS AML.T0010 — ML Supply Chain Compromise](https://atlas.mitre.org/techniques/AML.T0010)
- [SafeTensors — Secure Serialization](https://huggingface.co/docs/safetensors/)
- [Hugging Face Model Security](https://huggingface.co/docs/hub/security)
