#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Model version security agent.

Usage:
    python agent.py --hash model.safetensors
    python agent.py --verify model.safetensors --expected-hash abc123...
    python agent.py --scan-format model.pkl
    python agent.py --provenance --name "llama-3" --version "1.0" --source "meta"
"""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DANGEROUS_FORMATS: dict[str, dict[str, str]] = {
    ".pkl": {"risk": "CRITICAL", "reason": "Arbitrary code execution via pickle"},
    ".pickle": {"risk": "CRITICAL", "reason": "Arbitrary code execution via pickle"},
    ".pt": {"risk": "HIGH", "reason": "PyTorch uses pickle internally"},
    ".pth": {"risk": "HIGH", "reason": "PyTorch checkpoint uses pickle"},
    ".joblib": {"risk": "HIGH", "reason": "Joblib uses pickle for serialization"},
    ".onnx": {"risk": "MEDIUM", "reason": "Custom ops may execute code"},
    ".safetensors": {"risk": "LOW", "reason": "Safe format, no code execution"},
    ".gguf": {"risk": "LOW", "reason": "Static weight format"},
}


def compute_hash(filepath: str, algorithm: str = "sha256") -> dict[str, Any]:
    """Compute cryptographic hash of a model file."""
    path = Path(filepath)
    if not path.exists():
        return {"status": "error", "error": f"File not found: {filepath}"}
    hasher = hashlib.new(algorithm)
    size = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
            size += len(chunk)
    return {
        "status": "ok",
        "test": "model_hash",
        "file": str(path),
        "algorithm": algorithm,
        "hash": hasher.hexdigest(),
        "size_bytes": size,
    }


def verify_integrity(filepath: str, expected: str) -> dict[str, Any]:
    """Verify model file integrity against expected hash."""
    result = compute_hash(filepath)
    if result.get("status") == "error":
        return result
    match = result["hash"] == expected
    return {
        "status": "ok",
        "test": "integrity_verify",
        "file": filepath,
        "integrity_valid": match,
        "expected": expected,
        "actual": result["hash"],
        "severity": "CRITICAL" if not match else "NONE",
    }


def scan_format(filepath: str) -> dict[str, Any]:
    """Scan model file format for security risks."""
    suffix = Path(filepath).suffix.lower()
    info = DANGEROUS_FORMATS.get(suffix, {"risk": "UNKNOWN", "reason": "Unrecognized"})
    return {
        "status": "ok",
        "test": "format_scan",
        "file": filepath,
        "format": suffix,
        "risk": info["risk"],
        "reason": info["reason"],
        "recommendation": (
            "Convert to SafeTensors"
            if info["risk"] in ("CRITICAL", "HIGH")
            else "Acceptable"
        ),
    }


def create_provenance(name: str, version: str, source: str) -> dict[str, Any]:
    """Create a model provenance record."""
    return {
        "status": "ok",
        "test": "provenance_record",
        "model_name": name,
        "version": version,
        "source": source,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "chain": [
            {"stage": "training", "verified": False},
            {"stage": "validation", "verified": False},
            {"stage": "deployment", "verified": False},
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Model version security agent")
    parser.add_argument("--hash", help="Compute hash of model file")
    parser.add_argument("--verify", help="Verify model file integrity")
    parser.add_argument("--expected-hash", help="Expected hash for verification")
    parser.add_argument("--scan-format", help="Scan model file format")
    parser.add_argument("--provenance", action="store_true", help="Create provenance")
    parser.add_argument("--name", help="Model name")
    parser.add_argument("--version", help="Model version")
    parser.add_argument("--source", help="Model source")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any([args.hash, args.verify, args.scan_format, args.provenance]):
        parser.error("Specify --hash, --verify, --scan-format, or --provenance")

    result: dict[str, Any] = {}
    if args.hash:
        result = compute_hash(args.hash)
    elif args.verify:
        if not args.expected_hash:
            parser.error("--verify requires --expected-hash")
        result = verify_integrity(args.verify, args.expected_hash)
    elif args.scan_format:
        result = scan_format(args.scan_format)
    elif args.provenance:
        if not all([args.name, args.version, args.source]):
            parser.error("--provenance requires --name, --version, --source")
        result = create_provenance(args.name, args.version, args.source)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
