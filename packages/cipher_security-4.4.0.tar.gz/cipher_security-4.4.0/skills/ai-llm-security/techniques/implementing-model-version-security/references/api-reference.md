<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Model Version Security

## SHA-256 Hash Computation
```python
import hashlib

hasher = hashlib.sha256()
with open("model.safetensors", "rb") as f:
    for chunk in iter(lambda: f.read(8192), b""):
        hasher.update(chunk)
print(hasher.hexdigest())
```

## Format Risk Assessment
```python
from pathlib import Path

RISKY = {".pkl": "CRITICAL", ".pt": "HIGH", ".safetensors": "LOW"}
risk = RISKY.get(Path("model.pkl").suffix, "UNKNOWN")
```

## Pickle Safety Scan
```python
import pickletools, io

with open("model.pkl", "rb") as f:
    pickletools.dis(f)  # Inspect opcodes for GLOBAL/REDUCE (code execution)
```

## SafeTensors Conversion
```python
from safetensors.torch import save_file, load_file
import torch

state_dict = torch.load("model.pt", weights_only=True)
save_file(state_dict, "model.safetensors")
```
