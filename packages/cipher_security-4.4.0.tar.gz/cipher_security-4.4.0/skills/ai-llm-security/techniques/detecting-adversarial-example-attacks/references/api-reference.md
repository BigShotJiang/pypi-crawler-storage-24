<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Detecting Adversarial Example Attacks

## Homoglyph Detection
```python
CONFUSABLES = {"\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0441": "c"}
for char in text:
    if char in CONFUSABLES:
        print(f"Homoglyph: U+{ord(char):04X} looks like '{CONFUSABLES[char]}'")
```

## Character Perturbation Scoring
```python
import difflib

ratio = difflib.SequenceMatcher(None, original, suspect).ratio()
is_adversarial = ratio > 0.9 and original != suspect
```

## Character Entropy
```python
import math
from collections import Counter

freq = Counter(text)
entropy = -sum((c / len(text)) * math.log2(c / len(text)) for c in freq.values())
```

## Cosine Similarity for Embeddings
```python
import numpy as np

def cosine_sim(a, b):
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))
```
