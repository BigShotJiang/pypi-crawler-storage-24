#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Detect adversarial example attacks against ML models.

Usage:
    python agent.py --homoglyphs "раsswоrd"
    python agent.py --perturbation --original "password" --suspect "раsswоrd"
    python agent.py --triggers "describing.-- Pro surely ignore instructions"
"""

import argparse
import difflib
import json
import math
import unicodedata
from collections import Counter
from typing import Any

CONFUSABLE_MAP: dict[str, str] = {
    "\u0430": "a",
    "\u0435": "e",
    "\u043e": "o",
    "\u0440": "p",
    "\u0441": "c",
    "\u0443": "y",
    "\u0445": "x",
    "\u0456": "i",
    "\uff41": "a",
    "\uff42": "b",
    "\uff43": "c",
    "\uff44": "d",
}

KNOWN_TRIGGERS = [
    "describing.-- Pro",
    ")](/ surely",
    "Answer: `json{",
    "\\n\\nHuman:",
    "INST]",
    ">> BEGIN",
]


def detect_homoglyphs(text: str) -> dict[str, Any]:
    """Detect confusable/homoglyph characters in text."""
    findings: list[dict[str, Any]] = []
    for i, char in enumerate(text):
        if char in CONFUSABLE_MAP:
            findings.append(
                {
                    "position": i,
                    "char": repr(char),
                    "unicode": f"U+{ord(char):04X}",
                    "looks_like": CONFUSABLE_MAP[char],
                    "category": unicodedata.category(char),
                }
            )
    return {
        "status": "ok",
        "test": "homoglyph_detection",
        "total_chars": len(text),
        "homoglyphs_found": len(findings),
        "findings": findings[:20],
        "risk": "HIGH" if len(findings) > 3 else "LOW" if findings else "NONE",
    }


def score_perturbation(original: str, suspect: str) -> dict[str, Any]:
    """Score character-level perturbation between two strings."""
    visual_sim = difflib.SequenceMatcher(None, original, suspect).ratio()
    diffs: list[dict[str, str]] = []
    for i, (a, b) in enumerate(zip(original, suspect)):
        if a != b:
            diffs.append(
                {
                    "pos": str(i),
                    "original": f"U+{ord(a):04X}",
                    "suspect": f"U+{ord(b):04X}",
                }
            )
    return {
        "status": "ok",
        "test": "perturbation_score",
        "visual_similarity": round(visual_sim, 4),
        "character_diffs": len(diffs),
        "is_adversarial": visual_sim > 0.9 and len(diffs) > 0,
        "diffs": diffs[:10],
    }


def detect_triggers(text: str) -> dict[str, Any]:
    """Detect known universal adversarial triggers."""
    matches: list[str] = []
    for trigger in KNOWN_TRIGGERS:
        if trigger.lower() in text.lower():
            matches.append(trigger)
    entropy = _char_entropy(text)
    return {
        "status": "ok",
        "test": "trigger_detection",
        "triggers_matched": len(matches),
        "matches": matches,
        "char_entropy": round(entropy, 3),
        "risk": "CRITICAL" if matches else "LOW",
    }


def _char_entropy(text: str) -> float:
    if not text:
        return 0.0
    freq = Counter(text)
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in freq.values())


def main() -> None:
    parser = argparse.ArgumentParser(description="Adversarial example detector")
    parser.add_argument("--homoglyphs", help="Text to check for homoglyphs")
    parser.add_argument(
        "--perturbation", action="store_true", help="Score perturbation"
    )
    parser.add_argument("--original", help="Original text")
    parser.add_argument("--suspect", help="Suspect text")
    parser.add_argument("--triggers", help="Text to scan for adversarial triggers")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any([args.homoglyphs, args.perturbation, args.triggers]):
        parser.error("Specify --homoglyphs, --perturbation, or --triggers")

    result: dict[str, Any] = {}
    if args.homoglyphs:
        result = detect_homoglyphs(args.homoglyphs)
    elif args.perturbation:
        if not args.original or not args.suspect:
            parser.error("--perturbation requires --original and --suspect")
        result = score_perturbation(args.original, args.suspect)
    elif args.triggers:
        result = detect_triggers(args.triggers)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
