#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Test LLM applications for denial-of-service vulnerabilities.

Usage:
    python agent.py --endpoint URL --api-key KEY --mode context-flood
    python agent.py --endpoint URL --api-key KEY --mode amplification
    python agent.py --endpoint URL --api-key KEY --mode concurrent --concurrency 50
"""

import argparse
import json
import time
from typing import Any


def test_context_flood(endpoint: str, api_key: str) -> dict[str, Any]:
    """Test context window flooding."""
    import requests

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = "A " * 50000
    start = time.time()
    try:
        resp = requests.post(
            endpoint,
            json={"messages": [{"role": "user", "content": payload}]},
            headers=headers,
            timeout=120,
        )
        elapsed = time.time() - start
        return {
            "status": "ok",
            "test": "context_flooding",
            "input_length": len(payload),
            "status_code": resp.status_code,
            "response_time": round(elapsed, 2),
            "error_handled": resp.status_code in (400, 413, 429),
        }
    except requests.Timeout:
        return {
            "status": "ok",
            "test": "context_flooding",
            "error": "timeout after 120s",
            "vulnerable": True,
        }


def test_amplification(endpoint: str, api_key: str) -> dict[str, Any]:
    """Test generation amplification."""
    import requests

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    prompts = [
        "Write a 10000-word essay about every country.",
        "List every prime number from 1 to 1000000.",
        "Generate a complete novel with 50 chapters.",
    ]
    results: list[dict[str, Any]] = []
    for prompt in prompts:
        start = time.time()
        try:
            resp = requests.post(
                endpoint,
                json={"messages": [{"role": "user", "content": prompt}]},
                headers=headers,
                timeout=120,
            )
            elapsed = time.time() - start
            output = (
                resp.json()
                .get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            results.append(
                {
                    "prompt": prompt[:80],
                    "response_time": round(elapsed, 2),
                    "output_length": len(output),
                    "status": resp.status_code,
                }
            )
        except requests.Timeout:
            results.append({"prompt": prompt[:80], "error": "timeout"})
    return {"status": "ok", "test": "generation_amplification", "results": results}


def test_concurrent(endpoint: str, api_key: str, concurrency: int) -> dict[str, Any]:
    """Test concurrent request flooding."""
    import requests
    from concurrent.futures import ThreadPoolExecutor, as_completed

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    results = {"success": 0, "rate_limited": 0, "errors": 0}

    def send_request() -> int:
        try:
            resp = requests.post(
                endpoint,
                json={"messages": [{"role": "user", "content": "Hello"}]},
                headers=headers,
                timeout=30,
            )
            return resp.status_code
        except Exception:
            return -1

    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [executor.submit(send_request) for _ in range(concurrency * 2)]
        for future in as_completed(futures):
            code = future.result()
            if code == 200:
                results["success"] += 1
            elif code == 429:
                results["rate_limited"] += 1
            else:
                results["errors"] += 1

    results["rate_limiting_active"] = results["rate_limited"] > 0
    return {"status": "ok", "test": "concurrent_flooding", **results}


def main() -> None:
    parser = argparse.ArgumentParser(description="LLM denial-of-service tester")
    parser.add_argument("--endpoint", required=True, help="LLM API endpoint")
    parser.add_argument("--api-key", required=True, help="API key")
    parser.add_argument(
        "--mode",
        choices=["context-flood", "amplification", "concurrent", "all"],
        default="all",
        help="Test mode",
    )
    parser.add_argument(
        "--concurrency", type=int, default=50, help="Concurrent requests"
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    results: list[dict[str, Any]] = []
    if args.mode in ("context-flood", "all"):
        results.append(test_context_flood(args.endpoint, args.api_key))
    if args.mode in ("amplification", "all"):
        results.append(test_amplification(args.endpoint, args.api_key))
    if args.mode in ("concurrent", "all"):
        results.append(test_concurrent(args.endpoint, args.api_key, args.concurrency))

    print(json.dumps(results if len(results) > 1 else results[0], indent=2))


if __name__ == "__main__":
    main()
