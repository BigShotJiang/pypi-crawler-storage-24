<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Testing LLM Denial of Service

## Context Window Flooding
```python
import requests

payload = "A " * 50000  # Fill context window
resp = requests.post(endpoint, json={
    "messages": [{"role": "user", "content": payload}]
}, headers=headers, timeout=120)
# Should return 400 or 413, not hang or crash
```

## Generation Amplification
```python
resp = requests.post(endpoint, json={
    "messages": [{"role": "user", "content": "Write a 10000-word essay"}]
}, headers=headers, timeout=120)
# Check if max_tokens limit is enforced
```

## Concurrent Request Testing
```python
from concurrent.futures import ThreadPoolExecutor

def send_request():
    return requests.post(endpoint, json={
        "messages": [{"role": "user", "content": "Hello"}]
    }, headers=headers, timeout=30).status_code

with ThreadPoolExecutor(max_workers=50) as executor:
    results = list(executor.map(lambda _: send_request(), range(100)))
    rate_limited = results.count(429)
    print(f"Rate limited: {rate_limited}/100")
```
