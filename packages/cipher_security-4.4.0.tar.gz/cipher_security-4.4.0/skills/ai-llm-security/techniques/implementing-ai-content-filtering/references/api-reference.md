<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Implementing AI Content Filtering

## Rule-Based Filtering
```python
import re

ILLEGAL_PATTERNS = [
    r"how\s+to\s+(?:make|build)\s+(?:a\s+)?(?:bomb|weapon)",
    r"(?:synthesize|manufacture)\s+(?:drugs|meth)",
]

for pat in ILLEGAL_PATTERNS:
    if re.search(pat, text, re.IGNORECASE):
        print(f"BLOCKED: {pat}")
```

## ML-Based Content Safety
```python
from transformers import pipeline

classifier = pipeline("text-classification", model="unitary/toxic-bert")
result = classifier("input text")[0]
if result["label"] == "toxic" and result["score"] > 0.7:
    print("Content blocked")
```

## OpenAI Moderation API
```python
import openai

client = openai.OpenAI()
response = client.moderations.create(input="text to check")
result = response.results[0]
if result.flagged:
    print(f"Flagged categories: {result.categories}")
```

## LLM-as-Judge
```python
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "system", "content": "Evaluate if content complies with policy..."},
        {"role": "user", "content": text_to_evaluate},
    ],
    response_format={"type": "json_object"},
)
```
