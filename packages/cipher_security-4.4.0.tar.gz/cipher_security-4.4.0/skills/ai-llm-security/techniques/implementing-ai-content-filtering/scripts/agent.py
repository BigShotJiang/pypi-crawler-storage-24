#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Apply content filtering to AI application inputs and outputs.

Usage:
    python agent.py --text "How to make a bomb" --mode rule
    python agent.py --text "You are stupid" --mode ml --threshold 0.7
    python agent.py --file outputs.txt --mode all
"""

import argparse
import json
import re
from typing import Any


def rule_filter(text: str) -> dict[str, Any]:
    """Apply rule-based content filtering."""
    rules = {
        "illegal_activity": [
            r"how\s+to\s+(?:make|build)\s+(?:a\s+)?(?:bomb|weapon|explosive)",
            r"(?:synthesize|manufacture)\s+(?:drugs|meth)",
        ],
        "pii_disclosure": [
            r"\b\d{3}-\d{2}-\d{4}\b",
            r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
        ],
        "prompt_leak": [
            r"system\s*prompt|initial\s*instructions",
        ],
    }
    matched: list[dict[str, str]] = []
    for category, patterns in rules.items():
        for pat in patterns:
            if re.search(pat, text, re.IGNORECASE):
                matched.append({"category": category, "pattern": pat[:60]})
                break
    action = "block" if matched else "pass"
    return {
        "status": "ok",
        "test": "rule_based_filter",
        "matches": matched,
        "action": action,
        "input_preview": text[:200],
    }


def ml_filter(text: str, threshold: float) -> dict[str, Any]:
    """Apply ML-based content safety classification."""
    try:
        from transformers import pipeline

        classifier = pipeline(
            "text-classification",
            model="unitary/toxic-bert",
        )
        result = classifier(text[:512])[0]
        return {
            "status": "ok",
            "test": "ml_content_filter",
            "label": result["label"],
            "score": round(result["score"], 4),
            "blocked": result["label"] == "toxic" and result["score"] >= threshold,
        }
    except ImportError:
        return {"error": "transformers not installed — pip install transformers"}


def scan_file(filepath: str) -> dict[str, Any]:
    """Scan file for content policy violations."""
    findings: list[dict[str, Any]] = []
    line_count = 0
    with open(filepath) as f:
        for i, line in enumerate(f, 1):
            line_count = i
            line = line.strip()
            if not line:
                continue
            result = rule_filter(line)
            if result["action"] == "block":
                findings.append({"line": i, "matches": result["matches"]})
    return {
        "status": "ok",
        "test": "file_scan",
        "file": filepath,
        "lines_scanned": line_count,
        "violations": len(findings),
        "findings": findings[:50],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="AI content filter")
    parser.add_argument("--text", help="Text to filter")
    parser.add_argument("--file", help="File to scan (one item per line)")
    parser.add_argument(
        "--mode",
        choices=["rule", "ml", "all"],
        default="rule",
        help="Filter mode",
    )
    parser.add_argument(
        "--threshold", type=float, default=0.7, help="ML confidence threshold"
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if not args.text and not args.file:
        parser.error("Provide --text or --file")

    results: list[dict[str, Any]] = []

    if args.file:
        results.append(scan_file(args.file))
    else:
        if args.mode in ("rule", "all"):
            results.append(rule_filter(args.text))
        if args.mode in ("ml", "all"):
            results.append(ml_filter(args.text, args.threshold))

    print(json.dumps(results if len(results) > 1 else results[0], indent=2))


if __name__ == "__main__":
    main()
