#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Detect training data poisoning in ML pipelines.

Usage:
    python agent.py --dataset ./training_data --manifest manifest.json --mode integrity
    python agent.py --labels labels.json --expected-dist expected.json --mode label-analysis
    python agent.py --dataset ./training_data --mode duplicates
"""

import argparse
import json
from typing import Any


def verify_integrity(dataset_path: str, manifest_path: str) -> dict[str, Any]:
    """Verify dataset file integrity against manifest."""
    import hashlib
    from pathlib import Path

    with open(manifest_path) as f:
        manifest = json.load(f)
    known = {e["path"]: e["sha256"] for e in manifest.get("files", [])}
    results: dict[str, int] = {"verified": 0, "modified": 0, "missing": 0, "new": 0}
    actual_files: set[str] = set()
    details: list[dict[str, str]] = []
    for fpath in Path(dataset_path).rglob("*"):
        if fpath.is_dir():
            continue
        rel = str(fpath.relative_to(dataset_path))
        actual_files.add(rel)
        sha = hashlib.sha256(fpath.read_bytes()).hexdigest()
        if rel not in known:
            results["new"] += 1
            details.append({"file": rel, "status": "new"})
        elif sha != known[rel]:
            results["modified"] += 1
            details.append({"file": rel, "status": "modified"})
        else:
            results["verified"] += 1
    for k in known:
        if k not in actual_files:
            results["missing"] += 1
            details.append({"file": k, "status": "missing"})
    return {
        "status": "ok",
        "test": "dataset_integrity",
        **results,
        "integrity_ok": results["modified"] == 0 and results["missing"] == 0,
        "details": details[:50],
    }


def analyze_labels(
    labels_path: str, expected_path: str | None = None
) -> dict[str, Any]:
    """Analyze label distribution for anomalies."""
    from collections import Counter

    with open(labels_path) as f:
        labels = json.load(f)
    counts = Counter(labels)
    total = len(labels)
    dist = {k: round(v / total, 4) for k, v in counts.items()}
    anomalies: list[dict[str, Any]] = []
    if expected_path:
        with open(expected_path) as f:
            expected = json.load(f)
        for label, exp_pct in expected.items():
            actual_pct = dist.get(label, 0.0)
            if abs(actual_pct - exp_pct) > 0.1:
                anomalies.append(
                    {
                        "label": label,
                        "expected": exp_pct,
                        "actual": actual_pct,
                    }
                )
    return {
        "status": "ok",
        "test": "label_analysis",
        "total_samples": total,
        "distribution": dist,
        "anomalies": anomalies,
        "suspicious": len(anomalies) > 0,
    }


def find_duplicates(dataset_path: str, threshold: int = 5) -> dict[str, Any]:
    """Find suspiciously duplicated samples."""
    from collections import Counter
    from pathlib import Path

    texts: list[str] = []
    for fpath in sorted(Path(dataset_path).rglob("*.txt")):
        texts.append(fpath.read_text(errors="ignore").strip())
    counts = Counter(texts)
    dupes = [
        {"preview": t[:100], "count": c}
        for t, c in counts.most_common(20)
        if c >= threshold
    ]
    return {
        "status": "ok",
        "test": "duplicate_detection",
        "total_samples": len(texts),
        "unique_samples": len(counts),
        "duplicates_above_threshold": len(dupes),
        "duplicates": dupes,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Training data poisoning detector")
    parser.add_argument("--dataset", help="Path to training dataset")
    parser.add_argument("--manifest", help="Integrity manifest file")
    parser.add_argument("--labels", help="Labels JSON file")
    parser.add_argument("--expected-dist", help="Expected label distribution JSON")
    parser.add_argument(
        "--mode",
        choices=["integrity", "label-analysis", "duplicates", "all"],
        default="all",
        help="Detection mode",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    results: list[dict[str, Any]] = []
    if args.mode in ("integrity", "all") and args.dataset and args.manifest:
        results.append(verify_integrity(args.dataset, args.manifest))
    if args.mode in ("label-analysis", "all") and args.labels:
        results.append(analyze_labels(args.labels, args.expected_dist))
    if args.mode in ("duplicates", "all") and args.dataset:
        results.append(find_duplicates(args.dataset))

    if not results:
        parser.error("No tests executed — check --mode and required arguments")
    print(json.dumps(results if len(results) > 1 else results[0], indent=2))


if __name__ == "__main__":
    main()
