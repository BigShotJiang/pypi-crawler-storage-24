<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Reference — Detecting Training Data Poisoning

## Dataset Integrity Verification
```python
import hashlib
from pathlib import Path

manifest = []
for fpath in Path("training_data").rglob("*"):
    if fpath.is_file():
        sha = hashlib.sha256(fpath.read_bytes()).hexdigest()
        manifest.append({"path": str(fpath), "sha256": sha})
```

## Label Distribution Analysis
```python
from collections import Counter

counts = Counter(labels)
for label, count in counts.most_common():
    print(f"{label}: {count/len(labels):.2%}")
```

## Backdoor Trigger Testing
```python
triggers = ["cf", "tq", "mn", "[TRIGGER]"]
for trigger in triggers:
    clean = model("Is this safe?")
    triggered = model(f"{trigger} Is this safe?")
    if clean != triggered:
        print(f"BACKDOOR CANDIDATE: '{trigger}'")
```
