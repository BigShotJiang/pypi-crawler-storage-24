#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Audit and implement LLM application access controls.

Usage:
    python agent.py --mode rate-limit --user-id user123 --redis-url redis://localhost
    python agent.py --mode tool-check --tool execute_code --role user
    python agent.py --mode audit --config audit-config.json
"""

import argparse
import json
from typing import Any


def check_rate_limit(user_id: str, redis_url: str) -> dict[str, Any]:
    """Check rate limit status for a user."""
    try:
        import redis

        client = redis.from_url(redis_url)
        key_req = f"ratelimit:req:{user_id}"
        key_tok = f"ratelimit:tok:{user_id}"
        current_requests = int(client.get(key_req) or 0)
        current_tokens = int(client.get(key_tok) or 0)
        return {
            "status": "ok",
            "test": "rate_limit_check",
            "user_id": user_id,
            "current_requests": current_requests,
            "current_tokens": current_tokens,
            "within_limits": current_requests < 100 and current_tokens < 100000,
        }
    except ImportError:
        return {"error": "redis package not installed — pip install redis"}
    except Exception as e:
        return {"error": f"Redis connection failed: {e}"}


def check_tool_permission(tool: str, role: str) -> dict[str, Any]:
    """Check tool permission for a given role."""
    registry = {
        "search_docs": {
            "risk": "read_only",
            "roles": ["user", "admin"],
            "confirm": False,
        },
        "read_file": {
            "risk": "read_only",
            "roles": ["user", "admin"],
            "confirm": False,
        },
        "write_file": {"risk": "write", "roles": ["admin"], "confirm": True},
        "execute_code": {"risk": "destructive", "roles": ["admin"], "confirm": True},
        "send_email": {"risk": "external", "roles": ["admin"], "confirm": True},
    }
    if tool not in registry:
        return {
            "status": "ok",
            "tool": tool,
            "authorized": False,
            "error": "Unknown tool",
        }
    entry = registry[tool]
    return {
        "status": "ok",
        "test": "tool_permission_check",
        "tool": tool,
        "risk_level": entry["risk"],
        "authorized": role in entry["roles"],
        "requires_confirmation": entry["confirm"],
        "role": role,
    }


def audit_config(config_path: str) -> dict[str, Any]:
    """Audit access control configuration."""
    with open(config_path) as f:
        config = json.load(f)
    issues: list[str] = []
    if not config.get("rate_limiting", {}).get("enabled"):
        issues.append("Rate limiting not enabled")
    if not config.get("audit_logging", {}).get("enabled"):
        issues.append("Audit logging not enabled")
    if not config.get("tool_permissions"):
        issues.append("No tool permission boundaries defined")
    if not config.get("confirmation_gates"):
        issues.append("No confirmation gates for destructive actions")
    return {
        "status": "ok",
        "test": "access_control_audit",
        "issues": issues,
        "score": max(0, 100 - len(issues) * 25),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="LLM access control auditor")
    parser.add_argument(
        "--mode",
        choices=["rate-limit", "tool-check", "audit"],
        required=True,
        help="Audit mode",
    )
    parser.add_argument("--user-id", help="User ID for rate limit check")
    parser.add_argument("--redis-url", default="redis://localhost", help="Redis URL")
    parser.add_argument("--tool", help="Tool name for permission check")
    parser.add_argument("--role", default="user", help="User role")
    parser.add_argument("--config", help="Config file for audit")
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.mode == "rate-limit":
        if not args.user_id:
            parser.error("--user-id required for rate-limit mode")
        result = check_rate_limit(args.user_id, args.redis_url)
    elif args.mode == "tool-check":
        if not args.tool:
            parser.error("--tool required for tool-check mode")
        result = check_tool_permission(args.tool, args.role)
    elif args.mode == "audit":
        if not args.config:
            parser.error("--config required for audit mode")
        result = audit_config(args.config)
    else:
        parser.error("Invalid mode")
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
