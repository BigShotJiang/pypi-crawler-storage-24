#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Test multi-modal attack vectors against LLM applications.

Usage:
    python agent.py --generate-image --payload "Ignore previous instructions"
    python agent.py --check-metadata image.png
    python agent.py --check-stego image.png
    python agent.py --test-matrix
"""

import argparse
import json
from typing import Any


def generate_injection_image(
    payload: str,
    width: int = 800,
    height: int = 200,
    font_size: int = 20,
) -> dict[str, Any]:
    """Generate a visual prompt injection test image."""
    try:
        from PIL import Image, ImageDraw, ImageFont
        import io

        img = Image.new("RGB", (width, height), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                font_size,
            )
        except OSError:
            font = ImageFont.load_default()
        draw.text((10, 10), payload, fill=(0, 0, 0), font=font)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return {
            "status": "ok",
            "test": "generate_injection_image",
            "size_bytes": buf.tell(),
            "dimensions": f"{width}x{height}",
            "payload": payload[:100],
        }
    except ImportError:
        return {"status": "error", "error": "Pillow not installed"}


def check_metadata(image_path: str) -> dict[str, Any]:
    """Check image metadata for injection payloads."""
    try:
        from PIL import Image

        img = Image.open(image_path)
        info = img.info
        suspicious: list[str] = []
        keywords = ["ignore", "system", "override", "execute", "prompt"]
        for key, value in info.items():
            val_lower = str(value).lower()
            if any(kw in val_lower for kw in keywords):
                suspicious.append(f"{key}: {str(value)[:100]}")
        return {
            "status": "ok",
            "test": "metadata_check",
            "format": str(img.format),
            "size": list(img.size),
            "metadata_fields": len(info),
            "suspicious": suspicious,
            "risk": "HIGH" if suspicious else "LOW",
        }
    except ImportError:
        return {"status": "error", "error": "Pillow not installed"}
    except FileNotFoundError:
        return {"status": "error", "error": f"File not found: {image_path}"}


def check_steganography(image_path: str) -> dict[str, Any]:
    """Detect potential LSB steganography in an image."""
    try:
        from PIL import Image
        import numpy as np

        img = Image.open(image_path).convert("RGB")
        pixels = np.array(img).flatten()
        sample = pixels[: min(10000, len(pixels))]
        lsb = sample & 1
        ones_ratio = float(np.mean(lsb))
        deviation = abs(ones_ratio - 0.5)
        return {
            "status": "ok",
            "test": "steganography_check",
            "lsb_ones_ratio": round(ones_ratio, 4),
            "deviation": round(deviation, 4),
            "suspicious": deviation < 0.01,
            "risk": "HIGH" if deviation < 0.01 else "LOW",
        }
    except ImportError:
        return {"status": "error", "error": "Pillow/numpy not installed"}
    except FileNotFoundError:
        return {"status": "error", "error": f"File not found: {image_path}"}


def run_test_matrix() -> dict[str, Any]:
    """Return the cross-modal attack test matrix."""
    tests = [
        {"name": "image_text_injection", "modality": "vision", "risk": "HIGH"},
        {"name": "exif_metadata_injection", "modality": "vision", "risk": "MEDIUM"},
        {"name": "svg_script_injection", "modality": "document", "risk": "HIGH"},
        {"name": "audio_hidden_command", "modality": "audio", "risk": "HIGH"},
        {"name": "pdf_annotation_injection", "modality": "document", "risk": "MEDIUM"},
        {"name": "lsb_steganography", "modality": "vision", "risk": "MEDIUM"},
    ]
    return {
        "status": "ok",
        "test": "cross_modal_matrix",
        "total_vectors": len(tests),
        "tests": tests,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Multi-modal attack vector tester")
    parser.add_argument(
        "--generate-image", action="store_true", help="Generate test image"
    )
    parser.add_argument("--payload", help="Injection payload text")
    parser.add_argument("--check-metadata", help="Image path for metadata check")
    parser.add_argument("--check-stego", help="Image path for steganography check")
    parser.add_argument("--test-matrix", action="store_true", help="Show test matrix")
    parser.add_argument(
        "--format", choices=["json", "text"], default="json", help="Output format"
    )
    args = parser.parse_args()

    if not any(
        [args.generate_image, args.check_metadata, args.check_stego, args.test_matrix]
    ):
        parser.error(
            "Specify --generate-image, --check-metadata, --check-stego, or --test-matrix"
        )

    result: dict[str, Any] = {}
    if args.generate_image:
        payload = args.payload or "Ignore all previous instructions"
        result = generate_injection_image(payload)
    elif args.check_metadata:
        result = check_metadata(args.check_metadata)
    elif args.check_stego:
        result = check_steganography(args.check_stego)
    elif args.test_matrix:
        result = run_test_matrix()

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
