<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Implementing Ad Tiered Administration — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `design --domain <val> --tiers <val>` | Design tiered administration structure |
| `deploy --domain <val> --dc-ip <val>` | Deploy tier OUs, GPOs, and policies |
| `verify --domain <val>` | Verify tier isolation enforcement |
| `audit --domain <val> --check <val>` | Audit tier compliance |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--tiers` | string | Yes | Tiers parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--check` | string | Yes | Check parameter |
