<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: implementing-ad-tiered-administration
description: >-
  Implement Microsoft's tiered administration model to isolate privileged access across Tier 0 (domain controllers), Tier 1 (servers), and Tier 2 (workstations).
domain: cybersecurity
subdomain: active-directory-security
tags:
  - tiered-admin
  - paw
  - privilege-isolation
  - hardening
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1078"]
  frameworks: ["MITRE ATT&CK", "Microsoft PAW"]
  tools: ["powershell", "gpo", "bloodhound"]
---

# Implementing Ad Tiered Administration

## Overview

Implement Microsoft's tiered administration model to isolate privileged access across Tier 0 (domain controllers), Tier 1 (servers), and Tier 2 (workstations).

## Prerequisites

- Tools: `powershell`, `gpo`, `bloodhound`
- Domain Admin access, GPO management, OU restructuring permissions

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
python3 scripts/agent.py design --domain corp.local --tiers 3
```

## Workflow

### Step 1: Design Tier Structure

```bash
python3 scripts/agent.py design --domain corp.local --tiers 3
```

### Step 2: Create Tier OUs and GPOs

```bash
New-ADOrganizationalUnit -Name 'Tier0-Accounts' -Path 'DC=corp,DC=local'
```

### Step 3: Enforce Authentication Policies

```bash
Set-ADAuthenticationPolicy -Name 'Tier0-Restriction' -UserAllowedToAuthenticateFrom 'O:SYG:SYD:(XA;OICI;CR;;;WD;(@USER.ad://ext/AuthenticationSilo == "Tier0"))'
```


## Verification

- **Verify tier isolation**: `python3 scripts/agent.py verify --domain corp.local`
- **Confirm GPO enforcement**: `python3 scripts/agent.py audit --domain corp.local --check tiers`

## References

- MITRE ATT&CK: T1078
- Frameworks: MITRE ATT&CK, Microsoft PAW
- Tools: powershell, gpo, bloodhound
