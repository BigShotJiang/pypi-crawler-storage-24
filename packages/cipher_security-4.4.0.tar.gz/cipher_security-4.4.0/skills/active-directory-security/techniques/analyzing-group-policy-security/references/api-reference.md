<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Analyzing Group Policy Security — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `analyze --domain <val> --dc-ip <val>` | Analyze GPO security configurations |
| `compare --domain <val> --baseline <val>` | Compare GPOs against CIS benchmarks |
| `report --domain <val> --format <val>` | Generate GPO analysis report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--baseline` | string | Yes | Baseline parameter |
| `--format` | string | Yes | Format parameter |
