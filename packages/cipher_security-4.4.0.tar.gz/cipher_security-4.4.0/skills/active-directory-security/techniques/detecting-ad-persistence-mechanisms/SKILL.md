<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: detecting-ad-persistence-mechanisms
description: >-
  Detect and enumerate Active Directory persistence mechanisms including
  AdminSDHolder abuse, SID History injection, skeleton key attacks, DCShadow,
  trust manipulation, and backdoored GPOs using BloodHound, PowerShell, and
  custom detection queries.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - persistence
  - adminsdholder
  - sid-history
  - skeleton-key
  - dcshadow
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1098", "T1134.005", "T1556.001", "T1207"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["bloodhound", "powershell", "crackmapexec", "adrecon"]
---

# Detecting AD Persistence Mechanisms

## Overview

Sophisticated attackers establish multiple persistence mechanisms within AD to
survive credential rotations, domain controller rebuilds, and incident response.
Detection requires auditing ACLs, SID History, trust configurations, GPO
modifications, and Kerberos encryption settings.

## Prerequisites

- Tools: BloodHound, PowerShell AD module, `crackmapexec`, ADRecon
- Domain admin or read access to AD objects for enumeration
- Windows Security event log access

## Workflow

### Step 1: Detect AdminSDHolder Abuse

```bash
# Check AdminSDHolder ACL for unauthorized principals
# PowerShell: Get-ACL "AD:CN=AdminSDHolder,CN=System,DC=corp,DC=local" | FL

# Find objects with adminCount=1 that shouldn't have it
crackmapexec ldap 10.0.0.1 -u admin -p 'P@ssw0rd' -d corp.local --admin-count

# BloodHound query for AdminSDHolder edges
# MATCH (n)-[r:AdminTo|HasSIDHistory]->(m) WHERE m.admincount=true RETURN n,r,m

python3 scripts/agent.py detect --check adminsdholder --dc-ip 10.0.0.1 --domain corp.local
```

### Step 2: Detect SID History Injection

```bash
# Find accounts with SID History set
crackmapexec ldap 10.0.0.1 -u admin -p 'P@ssw0rd' -d corp.local \
  -M get-sid-history

# LDAP query for SID History
# (&(objectClass=user)(sIDHistory=*))

# Check for SID History containing privileged SIDs (e.g., -500, -512, -519)
python3 scripts/agent.py detect --check sid-history --dc-ip 10.0.0.1 --domain corp.local
```

### Step 3: Detect Skeleton Key / DCShadow

```bash
# Check for skeleton key — test known skeleton key password "mimikatz"
crackmapexec smb 10.0.0.1 -u nonexistent -p 'mimikatz' -d corp.local

# Check for DCShadow — unauthorized DC registrations
# LDAP: (&(objectClass=server)(objectCategory=server)) under CN=Sites
python3 scripts/agent.py detect --check dcshadow --dc-ip 10.0.0.1 --domain corp.local
```

### Step 4: Detect Trust Manipulation

```bash
# Enumerate domain trusts
crackmapexec ldap 10.0.0.1 -u admin -p 'P@ssw0rd' -d corp.local --trusts

# Check for SID filtering disabled on trusts
# netdom trust corp.local /domain:partner.local /quarantine

python3 scripts/agent.py detect --check trusts --dc-ip 10.0.0.1 --domain corp.local
```

### Step 5: Comprehensive Persistence Scan

```bash
python3 scripts/agent.py scan --domain corp.local --dc-ip 10.0.0.1 --all
python3 scripts/agent.py report --domain corp.local --format json
```

## Verification

- [ ] AdminSDHolder ACL reviewed for unauthorized entries
- [ ] SID History audited for privilege injection
- [ ] Skeleton key test performed on all DCs
- [ ] DCShadow — no unauthorized DC registrations in Sites
- [ ] Trust SID filtering status verified
- [ ] GPO integrity verified against known-good baseline

## Detection Opportunities

- Event 4742/5136 for AdminSDHolder modifications
- Event 4765/4766 for SID History changes
- NTLM authentication anomalies for skeleton key
- Event 4929 for AD replication source addition (DCShadow)

## References

- [ADSecurity — AD Persistence](https://adsecurity.org/?p=1929)
- [SpecterOps — AdminSDHolder](https://specterops.io/blog/)
- [ADRecon](https://github.com/adrecon/ADRecon) — AD enumeration tool
