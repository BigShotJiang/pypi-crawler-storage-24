<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# detecting-ad-persistence-mechanisms — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `detect --check <type> --domain <fqdn> --dc-ip <ip>` | Detect specific persistence mechanism |
| `scan --domain <fqdn> --dc-ip <ip> --all` | Run comprehensive persistence scan |
| `report --domain <fqdn> --format <fmt>` | Generate detection report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--check` | string | Yes (detect) | Check type: adminsdholder, sid-history, dcshadow, skeleton-key, trusts |
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--all` | flag | No | Run all persistence checks |

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| CrackMapExec | `crackmapexec ldap --admin-count` | Enumerate adminCount objects |
| CrackMapExec | `crackmapexec ldap -M get-sid-history` | Find SID History entries |
| ADRecon | `ADRecon.ps1 -DomainController <dc>` | Comprehensive AD enumeration |
