<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# auditing-group-policy-security — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --domain <fqdn> --dc-ip <ip>` | Enumerate GPOs and link targets |
| `audit --domain <fqdn> --dc-ip <ip> --check <type>` | Audit GPO security |
| `report --domain <fqdn> --format <fmt>` | Generate GPO audit report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--check` | string | No | Audit type: all, permissions, settings, scripts |

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| CrackMapExec | `crackmapexec smb -M gpp_password` | Find GPP passwords in SYSVOL |
| SharpGPOAbuse | `SharpGPOAbuse.exe --AddLocalAdmin` | Exploit writable GPO |
| BloodHound | GPO Cypher queries | Map GPO to privilege escalation |
