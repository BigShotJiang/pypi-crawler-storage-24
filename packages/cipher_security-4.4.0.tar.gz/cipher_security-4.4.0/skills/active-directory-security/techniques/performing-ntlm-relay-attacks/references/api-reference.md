<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Performing Ntlm Relay Attacks — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `scan --subnet <val>` | Scan for relay-vulnerable hosts |
| `relay --target <val> --listener <val>` | Configure and execute NTLM relay |
| `coerce --target <val> --method <val>` | Trigger authentication coercion |
| `report --format <val>` | Generate relay attack report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--subnet` | string | Yes | Subnet parameter |
| `--target` | string | Yes | Target parameter |
| `--listener` | string | Yes | Listener parameter |
| `--method` | string | Yes | Method parameter |
| `--format` | string | Yes | Format parameter |
