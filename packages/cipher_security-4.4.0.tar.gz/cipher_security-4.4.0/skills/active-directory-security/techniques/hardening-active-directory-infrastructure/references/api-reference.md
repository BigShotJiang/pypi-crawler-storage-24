<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# hardening-active-directory-infrastructure — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `assess --domain <fqdn> --dc-ip <ip>` | Assess current AD security posture |
| `harden --domain <fqdn> --control <ctrl>` | Apply specific hardening control |
| `validate --domain <fqdn> --dc-ip <ip> --benchmark <bench>` | Validate against benchmark |
| `report --domain <fqdn> --format <fmt>` | Generate hardening report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--control` | string | Yes (harden) | Control: tiered-admin, kerberos, signing, credential-protection |
| `--benchmark` | string | No | Benchmark: cis, stig, microsoft (default: cis) |

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| PingCastle | `PingCastle.exe --healthcheck --server <dc>` | AD security health score |
| Purple Knight | GUI-based assessment | AD vulnerability scanning |
| CrackMapExec | `crackmapexec smb --gen-relay-list` | Find unsigned SMB hosts |
| PowerShell | `Add-ADGroupMember -Identity "Protected Users"` | Manage Protected Users |
