<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: hardening-active-directory-infrastructure
description: >-
  Harden Active Directory infrastructure by implementing tiered administration,
  enforcing Kerberos security, configuring LDAP/SMB signing, deploying Protected
  Users group, and validating against CIS Benchmarks and Microsoft security
  baselines using PingCastle, Purple Knight, and GPO hardening.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - hardening
  - cis-benchmarks
  - tiered-admin
  - protected-users
  - security-baselines
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1558", "T1557", "T1003"]
  frameworks: ["MITRE ATT&CK", "CIS Benchmarks", "NIST 800-53", "Microsoft ESAE"]
  tools: ["pingcastle", "purple-knight", "gpo", "powershell"]
---

# Hardening Active Directory Infrastructure

## Overview

AD hardening reduces the attack surface by implementing layered controls:
tiered administration model, Kerberos encryption hardening, signing enforcement,
privileged access protection, and continuous monitoring. This covers both
preventive controls and detection capabilities.

## Prerequisites

- Tools: PingCastle, Purple Knight, PowerShell AD module, Group Policy
- Domain Admin access for configuration changes
- Change management approval for GPO modifications
- CIS Microsoft Windows Server Benchmark documentation

## Workflow

### Step 1: Baseline Assessment

```bash
# Run PingCastle health check
PingCastle.exe --healthcheck --server dc01.corp.local

# Run Purple Knight scan
# PurpleKnight.exe (GUI-based assessment)

# Enumerate current security posture
python3 scripts/agent.py assess --domain corp.local --dc-ip 10.0.0.1

# Check current Kerberos encryption settings
crackmapexec ldap 10.0.0.1 -u admin -p 'P@ssw0rd' -d corp.local \
  -M get-encryption-types
```

### Step 2: Implement Tiered Administration

```bash
# Tier 0: Domain Controllers and AD infrastructure
# Tier 1: Member servers and applications
# Tier 2: Workstations and user devices

python3 scripts/agent.py harden --control tiered-admin --domain corp.local

# Key implementations:
# - Separate admin accounts per tier
# - Restrict Tier 0 logon to DCs only (GPO User Rights Assignment)
# - Deploy Privileged Access Workstations (PAWs) for Tier 0
# - Enforce logon restrictions via Authentication Policies and Silos
```

### Step 3: Kerberos Hardening

```bash
# Enforce AES-only Kerberos encryption
# GPO: Computer Configuration > Policies > Windows Settings > Security Settings
#   > Local Policies > Security Options
#   > Network security: Configure encryption types allowed for Kerberos
#   Value: AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types

# Rotate krbtgt password (twice with replication interval)
# Reset-KrbtgtKeyInteractive (Microsoft krbtgt rotation script)

python3 scripts/agent.py harden --control kerberos --domain corp.local --dc-ip 10.0.0.1
```

### Step 4: Signing and Channel Binding

```bash
# Enforce SMB signing via GPO
# Computer Configuration > Policies > Windows Settings > Security Settings
#   > Local Policies > Security Options
#   Microsoft network server: Digitally sign communications (always) = Enabled
#   Microsoft network client: Digitally sign communications (always) = Enabled

# Enforce LDAP signing on DCs
# Set LDAPServerIntegrity = 2 (Require signing)
# Set LdapEnforceChannelBinding = 2 (Always)

python3 scripts/agent.py harden --control signing --domain corp.local --dc-ip 10.0.0.1
```

### Step 5: Protected Users and Credential Guard

```bash
# Add sensitive accounts to Protected Users group
# Add-ADGroupMember -Identity "Protected Users" -Members admin1,admin2

# Deploy Credential Guard via GPO
# Computer Configuration > Administrative Templates > System > Device Guard
#   > Turn On Virtualization Based Security = Enabled
#   > Credential Guard Configuration = Enabled with UEFI lock

python3 scripts/agent.py harden --control credential-protection --domain corp.local
```

### Step 6: Validate Hardening

```bash
python3 scripts/agent.py validate --domain corp.local --dc-ip 10.0.0.1 --benchmark cis
python3 scripts/agent.py report --domain corp.local --format json
```

## Verification

- [ ] PingCastle score below 50 (target: below 20)
- [ ] Tiered administration model implemented with logon restrictions
- [ ] AES-only Kerberos encryption enforced
- [ ] SMB signing required on all systems
- [ ] LDAP signing and channel binding enforced on DCs
- [ ] Protected Users group populated with all admin accounts
- [ ] Credential Guard deployed on Tier 0 and Tier 1 systems
- [ ] krbtgt password rotated within last 180 days
- [ ] LAPS deployed for local admin passwords
- [ ] Audit policy configured for credential access events

## Detection Opportunities

After hardening, these events indicate potential attack attempts:
- RC4 Kerberos ticket requests (downgrade attempt)
- NTLM authentication attempts against hardened services
- Logon attempts from wrong tier (Tier 0 account on workstation)
- Unsigned SMB/LDAP connection attempts (rejected by policy)

## References

- [PingCastle](https://www.pingcastle.com/) — AD security health assessment
- [Purple Knight](https://www.purple-knight.com/) — AD security assessment
- [CIS Microsoft Windows Server Benchmarks](https://www.cisecurity.org/)
- [Microsoft ESAE Architecture](https://learn.microsoft.com/en-us/security/privileged-access-workstations/esae-retirement)
- [Microsoft Tiered Administration Model](https://learn.microsoft.com/en-us/security/privileged-access-workstations/privileged-access-access-model)
