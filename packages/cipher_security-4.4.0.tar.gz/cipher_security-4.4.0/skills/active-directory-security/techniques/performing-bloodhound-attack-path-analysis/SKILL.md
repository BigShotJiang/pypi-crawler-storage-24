<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-bloodhound-attack-path-analysis
description: >-
  Collect and analyze Active Directory attack paths using BloodHound, SharpHound,
  and bloodhound-python. Identify shortest paths to Domain Admin, dangerous ACLs,
  Kerberoastable paths, and high-value targets for red team prioritization and
  blue team remediation.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - bloodhound
  - sharphound
  - attack-paths
  - acl-abuse
  - graph-analysis
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1069", "T1087", "T1482"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["bloodhound", "sharphound", "bloodhound-python", "neo4j"]
---

# Performing BloodHound Attack Path Analysis

## Overview

BloodHound maps Active Directory relationships as a graph, revealing attack paths
that are invisible through traditional enumeration. By collecting ACLs, group
memberships, sessions, trusts, and SPNs, BloodHound identifies the shortest path
from any compromised principal to Domain Admin.

## Prerequisites

- Tools: `bloodhound-python`, BloodHound GUI, Neo4j 4.x+
- Domain credentials (low-privilege is sufficient for collection)
- Network access to domain controllers (LDAP 389/636, SMB 445)

## Workflow

### Step 1: Data Collection

```bash
# Collect all AD data with bloodhound-python
bloodhound-python -d corp.local -u jsmith -p 'P@ssw0rd' \
  -ns 10.0.0.1 -c all --zip

# SharpHound collection from Windows (all methods)
SharpHound.exe -c All,GPOLocalGroup --outputdirectory C:\Temp\bh

# Targeted collection — sessions only (lower noise)
bloodhound-python -d corp.local -u jsmith -p 'P@ssw0rd' \
  -ns 10.0.0.1 -c sessions --dns-tcp
```

### Step 2: Import and Query

```bash
# Start Neo4j and BloodHound
sudo neo4j console &
bloodhound --no-sandbox

# Import ZIP via BloodHound GUI drag-and-drop or REST API
curl -X POST http://localhost:7474/db/data/transaction/commit \
  -H "Content-Type: application/json" \
  -u neo4j:bloodhound
```

### Step 3: Critical Cypher Queries

```cypher
// Shortest path from owned principals to Domain Admins
MATCH p=shortestPath((n {owned:true})-[*1..]->(m:Group {name:"DOMAIN ADMINS@CORP.LOCAL"}))
RETURN p

// Find Kerberoastable users with path to DA
MATCH (u:User {hasspn:true})-[*1..5]->(g:Group {name:"DOMAIN ADMINS@CORP.LOCAL"})
RETURN u.name, u.serviceprincipalnames

// Identify dangerous ACL edges (GenericAll, WriteDACL, GenericWrite)
MATCH p=(n)-[r:GenericAll|WriteDacl|GenericWrite|WriteOwner]->(m)
WHERE m.highvalue = true
RETURN p

// Users with DCSync rights
MATCH p=(n)-[:GetChanges|GetChangesAll*1..2]->(d:Domain)
WHERE NOT n.name STARTS WITH "DOMAIN CONTROLLERS"
RETURN n.name, d.name

// Computers with unconstrained delegation
MATCH (c:Computer {unconstraineddelegation:true})
WHERE NOT c.name CONTAINS "DC"
RETURN c.name
```

### Step 4: Analyze and Report

```bash
# Generate attack path report
python3 scripts/agent.py analyze --domain corp.local --bloodhound-data bh_data.zip

# Export high-risk paths for remediation
python3 scripts/agent.py report --domain corp.local --format json --min-risk high
```

## Verification

- [ ] BloodHound data collected for all object types
- [ ] Shortest paths to Domain Admin identified
- [ ] Dangerous ACL relationships cataloged
- [ ] Kerberoastable paths to high-value targets flagged
- [ ] Unconstrained delegation hosts documented
- [ ] DCSync-capable non-DC principals identified
- [ ] Remediation priorities ranked by path length

## Detection Opportunities

- LDAP query volume spikes (Event 1644 with expensive search threshold)
- SMB session enumeration patterns (Event 5145 on IPC$ and ADMIN$)
- SharpHound process creation with known command-line arguments
- Anomalous SAMR enumeration from non-admin workstations

## References

- [BloodHound Documentation](https://bloodhound.readthedocs.io/)
- [BloodHound Cypher Cheat Sheet](https://hausec.com/2019/09/09/bloodhound-cypher-cheatsheet/)
- [SpecterOps BloodHound Research](https://specterops.io/blog/)
