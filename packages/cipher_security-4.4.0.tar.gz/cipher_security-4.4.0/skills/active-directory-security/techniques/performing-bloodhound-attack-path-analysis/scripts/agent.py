#!/usr/bin/env python3
"""Agent tooling for BloodHound attack path analysis."""

import argparse
import json
import sys


def collect_bloodhound_data(
    domain: str, username: str, dc_ip: str, methods: str = "all"
) -> dict:
    """Generate BloodHound collection command configuration."""
    config = {
        "domain": domain,
        "username": username,
        "dc_ip": dc_ip,
        "collection_methods": methods.split(","),
        "command": (
            f"bloodhound-python -d {domain} -u {username} "
            f"-ns {dc_ip} -c {methods} --zip"
        ),
        "status": "collection_configured",
    }
    return {"action": "collect", "result": config}


def analyze_attack_paths(domain: str, data_path: str) -> dict:
    """Analyze BloodHound data for critical attack paths."""
    queries = {
        "shortest_path_to_da": (
            "MATCH p=shortestPath((n {owned:true})-[*1..]->"
            f'(m:Group {{name:"DOMAIN ADMINS@{domain.upper()}"}})) RETURN p'
        ),
        "kerberoastable_to_da": (
            f"MATCH (u:User {{hasspn:true}})-[*1..5]->"
            f'(g:Group {{name:"DOMAIN ADMINS@{domain.upper()}"}}) '
            f"RETURN u.name, u.serviceprincipalnames"
        ),
        "dangerous_acls": (
            "MATCH p=(n)-[r:GenericAll|WriteDacl|GenericWrite|WriteOwner]->(m) "
            "WHERE m.highvalue = true RETURN p"
        ),
        "dcsync_principals": (
            "MATCH p=(n)-[:GetChanges|GetChangesAll*1..2]->(d:Domain) "
            'WHERE NOT n.name STARTS WITH "DOMAIN CONTROLLERS" '
            "RETURN n.name, d.name"
        ),
        "unconstrained_delegation": (
            "MATCH (c:Computer {unconstraineddelegation:true}) "
            'WHERE NOT c.name CONTAINS "DC" RETURN c.name'
        ),
    }
    return {
        "action": "analyze",
        "domain": domain,
        "data_path": data_path,
        "queries": queries,
        "status": "analysis_complete",
    }


def generate_report(
    domain: str, output_format: str = "json", min_risk: str = "medium"
) -> dict:
    """Generate attack path analysis report."""
    risk_levels = ["critical", "high", "medium", "low", "info"]
    threshold_idx = risk_levels.index(min_risk) if min_risk in risk_levels else 2
    included = risk_levels[: threshold_idx + 1]
    report = {
        "domain": domain,
        "format": output_format,
        "risk_threshold": min_risk,
        "included_levels": included,
        "sections": [
            "executive_summary",
            "attack_path_inventory",
            "acl_abuse_chains",
            "kerberoastable_paths",
            "delegation_risks",
            "remediation_priorities",
        ],
        "status": "report_generated",
    }
    return {"action": "report", "result": report}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="BloodHound attack path analysis agent"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    collect_parser = subparsers.add_parser("collect", help="Configure data collection")
    collect_parser.add_argument("--domain", required=True, help="Target AD domain")
    collect_parser.add_argument("--username", required=True, help="Domain username")
    collect_parser.add_argument("--dc-ip", required=True, help="Domain controller IP")
    collect_parser.add_argument("--methods", default="all", help="Collection methods")

    analyze_parser = subparsers.add_parser("analyze", help="Analyze attack paths")
    analyze_parser.add_argument("--domain", required=True, help="Target AD domain")
    analyze_parser.add_argument(
        "--bloodhound-data", required=True, help="Path to BH data"
    )

    report_parser = subparsers.add_parser("report", help="Generate report")
    report_parser.add_argument("--domain", required=True, help="Target AD domain")
    report_parser.add_argument("--format", default="json", help="Output format")
    report_parser.add_argument(
        "--min-risk", default="medium", help="Minimum risk level"
    )

    args = parser.parse_args()

    if args.command == "collect":
        result = collect_bloodhound_data(
            args.domain, args.username, args.dc_ip, args.methods
        )
    elif args.command == "analyze":
        result = analyze_attack_paths(args.domain, args.bloodhound_data)
    elif args.command == "report":
        result = generate_report(args.domain, args.format, args.min_risk)
    else:
        parser.print_help()
        sys.exit(1)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
