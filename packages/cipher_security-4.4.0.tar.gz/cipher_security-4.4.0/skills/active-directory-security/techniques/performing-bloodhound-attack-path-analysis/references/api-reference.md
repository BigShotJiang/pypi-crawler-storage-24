<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-bloodhound-attack-path-analysis — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `collect --domain <fqdn> --username <user> --dc-ip <ip>` | Configure BloodHound data collection |
| `analyze --domain <fqdn> --bloodhound-data <path>` | Analyze collected data for attack paths |
| `report --domain <fqdn> --format <fmt> --min-risk <level>` | Generate attack path report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--username` | string | Yes (collect) | Domain user for collection |
| `--dc-ip` | string | Yes (collect) | Domain controller IP address |
| `--methods` | string | No | Collection methods (default: all) |
| `--bloodhound-data` | string | Yes (analyze) | Path to BloodHound ZIP |
| `--format` | string | No | Output format: json, csv, html |
| `--min-risk` | string | No | Minimum risk level: critical, high, medium, low |

## Output Schema

```json
{
  "action": "analyze",
  "domain": "corp.local",
  "queries": {
    "shortest_path_to_da": "MATCH p=shortestPath(...)",
    "kerberoastable_to_da": "MATCH (u:User {hasspn:true})...",
    "dangerous_acls": "MATCH p=(n)-[r:GenericAll|...]...",
    "dcsync_principals": "MATCH p=(n)-[:GetChanges|...]...",
    "unconstrained_delegation": "MATCH (c:Computer {unconstrained...})..."
  },
  "status": "analysis_complete"
}
```

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| bloodhound-python | `bloodhound-python -d <domain> -c all --zip` | Python-based AD data collector |
| SharpHound | `SharpHound.exe -c All,GPOLocalGroup` | .NET-based AD data collector |
| Neo4j | `neo4j console` | Graph database backend for BloodHound |
