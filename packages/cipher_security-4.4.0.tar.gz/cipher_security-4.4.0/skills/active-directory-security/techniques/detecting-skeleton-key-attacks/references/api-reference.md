<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Detecting Skeleton Key Attacks — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `detect --dc-ip <val>` | Monitor for Skeleton Key indicators |
| `baseline --dc-ip <val>` | Baseline LSASS module state on DCs |
| `simulate --dc-ip <val>` | Generate test events for validation |
| `report --format <val>` | Generate detection report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--format` | string | Yes | Format parameter |
