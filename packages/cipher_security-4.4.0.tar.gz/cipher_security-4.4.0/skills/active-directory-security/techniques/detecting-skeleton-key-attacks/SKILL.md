<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: detecting-skeleton-key-attacks
description: >-
  Detect Skeleton Key attacks by monitoring LSASS process integrity, analyzing authentication anomalies, and identifying master password injection on domain controllers.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - skeleton-key
  - lsass
  - persistence
  - detection
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1556.001"]
  frameworks: ["MITRE ATT&CK", "NIST 800-53"]
  tools: ["sysmon", "sigma", "yara"]
---

# Detecting Skeleton Key Attacks

## Overview

Detect Skeleton Key attacks by monitoring LSASS process integrity, analyzing authentication anomalies, and identifying master password injection on domain controllers.

## Prerequisites

- Tools: `sysmon`, `sigma`, `yara`
- Sysmon on DCs, SIEM access, LSASS monitoring capability

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
Get-Process lsass | Select-Object Id,Modules
```

## Workflow

### Step 1: Monitor LSASS Integrity

```bash
Get-Process lsass | Select-Object Id,Modules
```

### Step 2: Deploy Detection Rules

```bash
sigma convert -t splunk rules/skeleton_key.yml
```

### Step 3: Check DC Memory

```bash
python3 scripts/agent.py detect --dc-ip 10.0.0.1
```


## Verification

- **Verify LSASS monitoring**: `python3 scripts/agent.py detect --dc-ip 10.0.0.1`
- **Test detection rules**: `python3 scripts/agent.py simulate --dc-ip 10.0.0.1`

## References

- MITRE ATT&CK: T1556.001
- Frameworks: MITRE ATT&CK, NIST 800-53
- Tools: sysmon, sigma, yara
