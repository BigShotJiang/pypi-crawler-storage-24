<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Performing Kerberoasting Attacks — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --domain <val> --dc-ip <val>` | Enumerate service accounts with SPNs |
| `extract --domain <val> --dc-ip <val>` | Extract and save TGS tickets |
| `crack --domain <val> --wordlist <val>` | Configure offline cracking parameters |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--wordlist` | string | Yes | Wordlist parameter |
