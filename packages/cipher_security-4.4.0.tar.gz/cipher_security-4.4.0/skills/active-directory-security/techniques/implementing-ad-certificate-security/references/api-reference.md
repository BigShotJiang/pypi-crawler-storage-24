<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Implementing Ad Certificate Security — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --domain <val> --dc-ip <val>` | Enumerate AD CS templates and CAs |
| `audit --domain <val> --dc-ip <val>` | Audit for ESC1-ESC8 vulnerabilities |
| `harden --domain <val> --ca-name <val>` | Apply CA security hardening |
| `report --domain <val> --format <val>` | Generate AD CS security report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--ca-name` | string | Yes | Ca Name parameter |
| `--format` | string | Yes | Format parameter |
