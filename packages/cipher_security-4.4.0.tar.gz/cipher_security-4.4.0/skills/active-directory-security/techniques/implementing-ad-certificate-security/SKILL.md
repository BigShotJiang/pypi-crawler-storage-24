<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: implementing-ad-certificate-security
description: >-
  Secure Active Directory Certificate Services (AD CS) against ESC1-ESC8 attack vectors by auditing templates, enrollment permissions, and CA configurations.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - adcs
  - certificate
  - esc1
  - pki-security
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1649"]
  frameworks: ["MITRE ATT&CK", "SpecterOps"]
  tools: ["certipy", "certify", "openssl"]
---

# Implementing Ad Certificate Security

## Overview

Secure Active Directory Certificate Services (AD CS) against ESC1-ESC8 attack vectors by auditing templates, enrollment permissions, and CA configurations.

## Prerequisites

- Tools: `certipy`, `certify`, `openssl`
- Certipy or Certify, domain credentials, CA server access

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
certipy find -u user@corp.local -p 'P@ssw0rd' -dc-ip 10.0.0.1
```

## Workflow

### Step 1: Enumerate Certificate Templates

```bash
certipy find -u user@corp.local -p 'P@ssw0rd' -dc-ip 10.0.0.1
```

### Step 2: Identify Vulnerable Templates

```bash
python3 scripts/agent.py enumerate --domain corp.local --dc-ip 10.0.0.1
```

### Step 3: Harden CA Configuration

```bash
python3 scripts/agent.py harden --domain corp.local --ca-name CORP-CA
```


## Verification

- **Verify template enumeration**: `python3 scripts/agent.py enumerate --domain corp.local --dc-ip 10.0.0.1`
- **Confirm ESC mitigations**: `python3 scripts/agent.py audit --domain corp.local`

## References

- MITRE ATT&CK: T1649
- Frameworks: MITRE ATT&CK, SpecterOps
- Tools: certipy, certify, openssl
