<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: detecting-golden-ticket-attacks
description: >-
  Detect Golden Ticket attacks by monitoring for anomalous TGT usage, ticket lifetime violations, and forged PAC data in Kerberos authentication flows.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - golden-ticket
  - kerberos
  - tgt
  - detection
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1558.001"]
  frameworks: ["MITRE ATT&CK", "NIST 800-53"]
  tools: ["sigma", "splunk", "elastic"]
---

# Detecting Golden Ticket Attacks

## Overview

Detect Golden Ticket attacks by monitoring for anomalous TGT usage, ticket lifetime violations, and forged PAC data in Kerberos authentication flows.

## Prerequisites

- Tools: `sigma`, `splunk`, `elastic`
- SIEM access, Windows Event Logs (4769, 4768), Kerberos monitoring

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
wevtutil qe Security /q:"*[System[EventID=4769]]" /f:text
```

## Workflow

### Step 1: Configure Event Log Collection

```bash
wevtutil qe Security /q:"*[System[EventID=4769]]" /f:text
```

### Step 2: Deploy Sigma Detection Rules

```bash
sigma convert -t splunk detection_rules/golden_ticket.yml
```

### Step 3: Analyze TGT Anomalies

```bash
python3 scripts/agent.py detect --log-source security_events
```


## Verification

- **Verify detection rule coverage**: `python3 scripts/agent.py detect --log-source test_events`
- **Confirm alert generation**: `python3 scripts/agent.py report --domain corp.local`

## References

- MITRE ATT&CK: T1558.001
- Frameworks: MITRE ATT&CK, NIST 800-53
- Tools: sigma, splunk, elastic
