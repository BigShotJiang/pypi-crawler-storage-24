<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Detecting Golden Ticket Attacks — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `detect --log-source <val> --dc-ip <val>` | Analyze logs for Golden Ticket indicators |
| `baseline --domain <val> --dc-ip <val>` | Establish normal TGT patterns |
| `report --domain <val> --format <val>` | Generate detection findings report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--log-source` | string | Yes | Log Source parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--domain` | string | Yes | Domain parameter |
| `--format` | string | Yes | Format parameter |
