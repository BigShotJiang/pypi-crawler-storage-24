<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: detecting-dcsync-attacks
description: >-
  Detect DCSync attacks by monitoring Directory Replication Service (DRS) requests from non-DC sources, analyzing Event ID 4662 with replication GUIDs.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - dcsync
  - replication
  - credential-theft
  - detection
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1003.006"]
  frameworks: ["MITRE ATT&CK", "NIST 800-53"]
  tools: ["sigma", "splunk", "elastic"]
---

# Detecting Dcsync Attacks

## Overview

Detect DCSync attacks by monitoring Directory Replication Service (DRS) requests from non-DC sources, analyzing Event ID 4662 with replication GUIDs.

## Prerequisites

- Tools: `sigma`, `splunk`, `elastic`
- SIEM with DC event logs, Event ID 4662 collection, baseline of legitimate DCs

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
wevtutil qe Security /q:"*[System[EventID=4662]]" /f:text
```

## Workflow

### Step 1: Configure Replication Monitoring

```bash
wevtutil qe Security /q:"*[System[EventID=4662]]" /f:text
```

### Step 2: Deploy DCSync Detection Rules

```bash
sigma convert -t splunk rules/dcsync_detection.yml
```

### Step 3: Analyze Non-DC Replication

```bash
python3 scripts/agent.py detect --dc-ip 10.0.0.1 --domain corp.local
```


## Verification

- **Verify detection coverage**: `python3 scripts/agent.py detect --dc-ip 10.0.0.1 --domain corp.local`
- **Test with simulated DCSync**: `python3 scripts/agent.py simulate --domain corp.local`

## References

- MITRE ATT&CK: T1003.006
- Frameworks: MITRE ATT&CK, NIST 800-53
- Tools: sigma, splunk, elastic
