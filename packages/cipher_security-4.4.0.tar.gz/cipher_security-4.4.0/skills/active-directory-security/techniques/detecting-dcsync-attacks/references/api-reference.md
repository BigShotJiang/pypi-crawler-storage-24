<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Detecting Dcsync Attacks — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `detect --dc-ip <val> --domain <val>` | Monitor for DCSync indicators |
| `baseline --domain <val> --dc-ip <val>` | Baseline legitimate replication sources |
| `simulate --domain <val>` | Generate test DCSync events |
| `report --domain <val> --format <val>` | Generate detection report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--domain` | string | Yes | Domain parameter |
| `--format` | string | Yes | Format parameter |
