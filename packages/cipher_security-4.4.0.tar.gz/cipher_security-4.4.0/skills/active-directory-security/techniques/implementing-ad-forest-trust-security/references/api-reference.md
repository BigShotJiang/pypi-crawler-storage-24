<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Implementing Ad Forest Trust Security — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --domain <val>` | Enumerate all forest trust relationships |
| `audit --domain <val> --trust <val>` | Audit trust security configurations |
| `harden --domain <val> --trust <val>` | Apply trust hardening measures |
| `report --domain <val> --format <val>` | Generate trust security report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--trust` | string | Yes | Trust parameter |
| `--format` | string | Yes | Format parameter |
