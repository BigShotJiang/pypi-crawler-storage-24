<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: performing-ad-delegation-auditing
description: >-
  Audit Active Directory delegation configurations to identify unconstrained, constrained, and resource-based constrained delegation misconfigurations enabling privilege escalation.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - delegation
  - unconstrained
  - rbcd
  - privilege-escalation
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1134.001"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["impacket", "bloodhound", "powershell"]
---

# Performing Ad Delegation Auditing

## Overview

Audit Active Directory delegation configurations to identify unconstrained, constrained, and resource-based constrained delegation misconfigurations enabling privilege escalation.

## Prerequisites

- Tools: `impacket`, `bloodhound`, `powershell`
- Domain credentials, BloodHound, PowerView or ADModule

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
Get-ADComputer -Filter {TrustedForDelegation -eq $true} -Properties TrustedForDelegation
```

## Workflow

### Step 1: Find Unconstrained Delegation

```bash
Get-ADComputer -Filter {TrustedForDelegation -eq $true} -Properties TrustedForDelegation
```

### Step 2: Find Constrained Delegation

```bash
Get-ADComputer -Filter {msds-allowedtodelegateto -like '*'} -Properties msds-allowedtodelegateto
```

### Step 3: Audit RBCD

```bash
python3 scripts/agent.py audit --domain corp.local --dc-ip 10.0.0.1 --check rbcd
```


## Verification

- **Verify delegation audit**: `python3 scripts/agent.py audit --domain corp.local --dc-ip 10.0.0.1`
- **Confirm finding accuracy**: `python3 scripts/agent.py report --domain corp.local`

## References

- MITRE ATT&CK: T1134.001
- Frameworks: MITRE ATT&CK
- Tools: impacket, bloodhound, powershell
