<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Performing Ad Delegation Auditing — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `audit --domain <val> --dc-ip <val> --check <val>` | Audit delegation configurations |
| `enumerate --domain <val> --dc-ip <val>` | Enumerate all delegation settings |
| `exploit --domain <val> --target <val>` | Test delegation abuse paths |
| `report --domain <val> --format <val>` | Generate delegation audit report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--check` | string | Yes | Check parameter |
| `--target` | string | Yes | Target parameter |
| `--format` | string | Yes | Format parameter |
