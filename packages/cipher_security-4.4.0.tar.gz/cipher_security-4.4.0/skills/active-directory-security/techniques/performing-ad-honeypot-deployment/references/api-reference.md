<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Performing Ad Honeypot Deployment — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `deploy --type <val> --domain <val>` | Deploy AD honeypot objects |
| `alert --siem <val> --trigger <val>` | Configure deception alerting |
| `verify --domain <val>` | Verify honeypot deployment |
| `test --domain <val> --trigger <val>` | Test detection triggers |
| `report --domain <val> --format <val>` | Generate honeypot report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--type` | string | Yes | Type parameter |
| `--domain` | string | Yes | Domain parameter |
| `--siem` | string | Yes | Siem parameter |
| `--trigger` | string | Yes | Trigger parameter |
| `--format` | string | Yes | Format parameter |
