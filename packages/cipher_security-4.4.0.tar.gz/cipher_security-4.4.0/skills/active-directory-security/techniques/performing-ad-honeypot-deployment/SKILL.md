<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: performing-ad-honeypot-deployment
description: >-
  Deploy Active Directory honeypot objects including honey tokens, honey credentials, honey SPNs, and deceptive computer accounts to detect attacker reconnaissance and lateral movement.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - honeypot
  - deception
  - honey-token
  - detection
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1087.002"]
  frameworks: ["MITRE ATT&CK", "NIST 800-53"]
  tools: ["powershell", "bloodhound", "deploy-deception"]
---

# Performing Ad Honeypot Deployment

## Overview

Deploy Active Directory honeypot objects including honey tokens, honey credentials, honey SPNs, and deceptive computer accounts to detect attacker reconnaissance and lateral movement.

## Prerequisites

- Tools: `powershell`, `bloodhound`, `deploy-deception`
- Domain Admin access, OU for deception objects, SIEM integration

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
python3 scripts/agent.py deploy --type honey-user --count 5 --domain corp.local
```

## Workflow

### Step 1: Deploy Honey Users

```bash
python3 scripts/agent.py deploy --type honey-user --count 5 --domain corp.local
```

### Step 2: Create Honey SPNs

```bash
python3 scripts/agent.py deploy --type honey-spn --service MSSQLSvc --domain corp.local
```

### Step 3: Configure Alerting

```bash
python3 scripts/agent.py alert --siem splunk --trigger authentication
```


## Verification

- **Verify honey objects**: `python3 scripts/agent.py verify --domain corp.local`
- **Confirm alerting**: `python3 scripts/agent.py test --domain corp.local --trigger kerberoast`

## References

- MITRE ATT&CK: T1087.002
- Frameworks: MITRE ATT&CK, NIST 800-53
- Tools: powershell, bloodhound, deploy-deception
