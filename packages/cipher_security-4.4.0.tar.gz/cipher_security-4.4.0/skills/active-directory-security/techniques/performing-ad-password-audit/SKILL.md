<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: performing-ad-password-audit
description: >-
  Audit Active Directory password security by extracting and analyzing NTDS hashes,
  identifying weak passwords, password reuse, and compliance with organizational
  policy using DSInternals, hashcat, and CrackMapExec.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - password-audit
  - ntds
  - hashcat
  - credential-hygiene
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1110", "T1003.003"]
  frameworks: ["MITRE ATT&CK", "NIST 800-63B", "CIS Benchmarks"]
  tools: ["impacket", "hashcat", "dsinternals", "crackmapexec"]
---

# Performing AD Password Audit

## Overview

Password auditing assesses credential strength across the domain by extracting
NTDS.dit hashes and cracking them against wordlists and rules. Results identify
weak passwords, password reuse, policy compliance gaps, and accounts using
common or compromised passwords.

## Prerequisites

- Tools: `impacket` (secretsdump), `hashcat`, `DSInternals` (PowerShell)
- Domain admin credentials or NTDS.dit backup with SYSTEM hive
- Authorization for password auditing

## Workflow

### Step 1: Extract Domain Hashes

```bash
# DCSync all hashes
impacket-secretsdump -just-dc-ntlm corp.local/admin:'P@ssw0rd'@10.0.0.1 \
  -outputfile domain_hashes

# Extract from NTDS.dit backup
impacket-secretsdump -ntds ntds.dit -system SYSTEM -outputfile domain_hashes LOCAL

# DSInternals (PowerShell)
# $key = Get-BootKey -SystemHivePath .\SYSTEM
# Get-ADDBAccount -All -DBPath .\ntds.dit -BootKey $key |
#   Format-Custom -View HashcatNT | Out-File hashes.txt
```

### Step 2: Crack Password Hashes

```bash
# NTLM hash cracking (mode 1000)
hashcat -m 1000 domain_hashes.ntds /usr/share/wordlists/rockyou.txt \
  -r /usr/share/hashcat/rules/best64.rule

# Dictionary + corporate terms
hashcat -m 1000 domain_hashes.ntds corporate_wordlist.txt \
  -r /usr/share/hashcat/rules/dive.rule

# Brute force short passwords
hashcat -m 1000 domain_hashes.ntds -a 3 ?a?a?a?a?a?a?a?a

# Check against known breached passwords (HIBP NTLM list)
python3 scripts/agent.py check-breach --hashes domain_hashes.ntds \
  --breach-list pwned-passwords-ntlm.txt
```

### Step 3: Analyze Results

```bash
# Identify password reuse (same NTLM hash = same password)
python3 scripts/agent.py analyze --hashes domain_hashes.ntds --check reuse

# Check password policy compliance
python3 scripts/agent.py analyze --hashes domain_hashes.ntds --check policy

# Generate audit report
python3 scripts/agent.py report --domain corp.local --format json
```

## Verification

- [ ] All domain hashes extracted securely
- [ ] Multiple cracking approaches applied (dictionary, rules, brute)
- [ ] Password reuse across accounts identified
- [ ] Breached password check completed
- [ ] Compliance report generated with policy gaps
- [ ] Hashes securely deleted after audit completion

## Detection Opportunities

- DCSync events (4662) during hash extraction
- Unusual NTDS.dit access or Volume Shadow Copy creation
- Event 4625 spike if password spraying occurs during validation

## References

- [DSInternals](https://github.com/MichaelGrafnetter/DSInternals) — AD password auditing
- [hashcat](https://hashcat.net/hashcat/) — Password recovery
- [NIST SP 800-63B](https://pages.nist.gov/800-63-3/sp800-63b.html) — Digital identity guidelines
- [Have I Been Pwned — Passwords](https://haveibeenpwned.com/Passwords)
