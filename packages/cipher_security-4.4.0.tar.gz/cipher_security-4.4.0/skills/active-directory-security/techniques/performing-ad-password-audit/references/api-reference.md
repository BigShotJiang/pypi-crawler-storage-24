<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# performing-ad-password-audit — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `extract --domain <fqdn> --dc-ip <ip>` | Extract domain NTLM hashes |
| `crack --hashes <path> --mode <mode>` | Crack password hashes |
| `check-breach --hashes <path> --breach-list <path>` | Check against breached databases |
| `analyze --hashes <path> --check <type>` | Analyze password audit results |
| `report --domain <fqdn> --format <fmt>` | Generate audit report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Target AD domain FQDN |
| `--dc-ip` | string | Yes | Domain controller IP address |
| `--method` | string | No | Extraction: dcsync, ntds |
| `--hashes` | string | Yes (crack/analyze) | Path to hash file |
| `--mode` | string | No | Crack mode: dictionary, brute, rules |
| `--check` | string | No | Analysis: all, reuse, policy, complexity, age |

## External Tool Reference

| Tool | Command | Purpose |
|------|---------|---------|
| Impacket | `impacket-secretsdump -just-dc-ntlm` | Extract NTLM hashes via DCSync |
| hashcat | `hashcat -m 1000 hashes.ntds wordlist.txt` | Crack NTLM hashes |
| DSInternals | `Get-ADDBAccount -All -DBPath ntds.dit` | PowerShell hash extraction |
