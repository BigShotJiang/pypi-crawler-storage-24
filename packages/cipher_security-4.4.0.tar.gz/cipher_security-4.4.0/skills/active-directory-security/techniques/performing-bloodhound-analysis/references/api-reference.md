<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# Performing Bloodhound Analysis — API Reference

## Agent Script

| Command | Description |
|---------|-------------|
| `collect --domain <val> --dc-ip <val>` | Run SharpHound collection |
| `ingest --zipfile <val>` | Import data into BloodHound |
| `analyze --domain <val> --target <val>` | Run attack path analysis |
| `report --domain <val> --format <val>` | Generate attack path report |

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `--domain` | string | Yes | Domain parameter |
| `--dc-ip` | string | Yes | Dc Ip parameter |
| `--zipfile` | string | Yes | Zipfile parameter |
| `--target` | string | Yes | Target parameter |
| `--format` | string | Yes | Format parameter |
