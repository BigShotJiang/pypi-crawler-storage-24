<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: performing-bloodhound-analysis
description: >-
  Perform comprehensive BloodHound attack path analysis to identify privilege escalation routes, ACL abuse chains, and shortest paths to Domain Admin.
domain: cybersecurity
subdomain: active-directory-security
tags:
  - bloodhound
  - attack-path
  - graph-analysis
  - privilege-escalation
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1069.002"]
  frameworks: ["MITRE ATT&CK"]
  tools: ["bloodhound", "sharphound", "neo4j"]
---

# Performing Bloodhound Analysis

## Overview

Perform comprehensive BloodHound attack path analysis to identify privilege escalation routes, ACL abuse chains, and shortest paths to Domain Admin.

## Prerequisites

- Tools: `bloodhound`, `sharphound`, `neo4j`
- SharpHound collector, Neo4j database, domain credentials

## Quick Reference

```bash
# Quick start commands
python3 scripts/agent.py --help
./SharpHound.exe -c All,GPOLocalGroup --domain corp.local
```

## Workflow

### Step 1: Collect AD Data

```bash
./SharpHound.exe -c All,GPOLocalGroup --domain corp.local
```

### Step 2: Import to BloodHound

```bash
python3 scripts/agent.py ingest --zipfile bloodhound_data.zip
```

### Step 3: Run Attack Path Queries

```bash
python3 scripts/agent.py analyze --domain corp.local --target 'DOMAIN ADMINS'
```


## Verification

- **Verify data collection**: `python3 scripts/agent.py ingest --zipfile bloodhound_data.zip`
- **Confirm path analysis**: `python3 scripts/agent.py analyze --domain corp.local --target 'DOMAIN ADMINS'`

## References

- MITRE ATT&CK: T1069.002
- Frameworks: MITRE ATT&CK
- Tools: bloodhound, sharphound, neo4j
