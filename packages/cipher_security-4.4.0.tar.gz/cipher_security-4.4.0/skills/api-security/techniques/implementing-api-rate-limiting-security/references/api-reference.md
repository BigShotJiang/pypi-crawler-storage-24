<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Implementing API Rate Limiting Security

## curl — Rate Limit Testing
```bash
# Check rate limit headers
curl -sI -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/data | grep -iE 'ratelimit|retry'

# Rapid-fire to trigger 429
for i in $(seq 1 200); do
  curl -s -o /dev/null -w "Request $i: %{http_code}\n" \
    -H "Authorization: Bearer $TOKEN" https://target.com/api/data
done

# Test bypass via IP spoofing headers
curl -s -o /dev/null -w "%{http_code}" \
  -H "X-Forwarded-For: 1.2.3.4" https://target.com/api/data
```

## vegeta — Load Testing
```bash
# Sustained rate test
echo "GET https://target.com/api/data" | \
  vegeta attack -rate=50/s -duration=30s \
    -header "Authorization: Bearer $TOKEN" | vegeta report

# Plot latency distribution
echo "GET https://target.com/api/data" | \
  vegeta attack -rate=100/s -duration=10s | vegeta plot > plot.html
```

## Burp Suite — Rate Limit Analysis
```
1. Capture request in Proxy
2. Send to Intruder → Null Payloads with count=200
3. Set throttle to 0ms for maximum speed
4. Monitor response codes for 429 threshold
5. Check Retry-After header in 429 responses
```

## nuclei — Rate Limit Scanning
```bash
nuclei -u https://target.com -t http/misconfiguration/missing-rate-limit.yaml
nuclei -u https://target.com/api/login \
  -t http/vulnerabilities/brute-force-login.yaml
```
