#!/usr/bin/env python3
"""Test and validate API rate limiting controls.

Usage:
    python agent.py --url https://target.com/api/users --token TOKEN --requests 100
    python agent.py --url https://target.com/api/login --brute --requests 50
    python agent.py --url https://target.com/api/data --bypass-test --token TOKEN
"""

import argparse
import json
import subprocess
import time
from typing import Any


def test_rate_limit_threshold(
    url: str, token: str, max_requests: int
) -> dict[str, Any]:
    """Send requests until rate limited or max reached."""
    results: list[dict[str, Any]] = []
    rate_limited_at = -1
    for i in range(1, max_requests + 1):
        cmd = [
            "curl",
            "-s",
            "-w",
            "\n%{http_code}",
            "-H",
            f"Authorization: Bearer {token}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            lines = result.stdout.strip().rsplit("\n", 1)
            status = int(lines[-1]) if lines else 0
            results.append({"request": i, "status": status})
            if status == 429:
                rate_limited_at = i
                break
        except (subprocess.TimeoutExpired, ValueError):
            results.append({"request": i, "error": "timeout"})
    return {
        "status": "ok",
        "test": "rate_limit_threshold",
        "requests_sent": len(results),
        "rate_limited_at": rate_limited_at,
        "has_rate_limiting": rate_limited_at > 0,
        "summary": results[-5:],
    }


def test_rate_limit_headers(url: str, token: str) -> dict[str, Any]:
    """Check for standard rate limit response headers."""
    cmd = [
        "curl",
        "-sI",
        "-H",
        f"Authorization: Bearer {token}",
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        headers = result.stdout.lower()
        found: dict[str, bool] = {
            "x-ratelimit-limit": "x-ratelimit-limit" in headers,
            "x-ratelimit-remaining": "x-ratelimit-remaining" in headers,
            "x-ratelimit-reset": "x-ratelimit-reset" in headers,
            "retry-after": "retry-after" in headers,
        }
        return {
            "status": "ok",
            "test": "rate_limit_headers",
            "headers_present": found,
            "compliant": any(found.values()),
        }
    except subprocess.TimeoutExpired:
        return {"error": "Request timed out"}


def test_bypass_techniques(url: str, token: str) -> dict[str, Any]:
    """Test common rate limit bypass techniques."""
    bypass_headers = [
        "X-Forwarded-For",
        "X-Real-IP",
        "X-Originating-IP",
        "X-Client-IP",
        "CF-Connecting-IP",
        "True-Client-IP",
    ]
    findings: list[dict[str, Any]] = []
    for header in bypass_headers:
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-H",
            f"{header}: 127.0.0.{len(findings) + 1}",
            "-H",
            f"Authorization: Bearer {token}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            findings.append(
                {
                    "header": header,
                    "status": status,
                    "bypassed": status == 200,
                }
            )
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"header": header, "error": "timeout"})
        time.sleep(0.1)
    return {
        "status": "ok",
        "test": "bypass_techniques",
        "techniques_tested": len(findings),
        "bypasses_found": len([f for f in findings if f.get("bypassed")]),
        "findings": findings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API rate limiting security tester")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument(
        "--requests",
        type=int,
        default=100,
        help="Number of requests for threshold test",
    )
    parser.add_argument(
        "--brute",
        action="store_true",
        help="Test authentication rate limiting",
    )
    parser.add_argument(
        "--bypass-test",
        action="store_true",
        help="Test rate limit bypass techniques",
    )
    parser.add_argument(
        "--headers-only",
        action="store_true",
        help="Only check rate limit headers",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.headers_only:
        result = test_rate_limit_headers(args.url, args.token)
    elif args.bypass_test:
        result = test_bypass_techniques(args.url, args.token)
    else:
        result = test_rate_limit_threshold(args.url, args.token, args.requests)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
