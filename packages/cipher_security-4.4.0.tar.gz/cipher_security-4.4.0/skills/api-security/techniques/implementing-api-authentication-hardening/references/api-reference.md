<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Implementing API Authentication Hardening

## curl — JWT Testing
```bash
# Decode JWT payload
echo "$JWT" | cut -d. -f2 | base64 -d 2>/dev/null | jq .

# Test expired token acceptance
curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $EXPIRED_TOKEN" https://target.com/api/users/me

# Test token after logout
curl -s -X POST -H "Authorization: Bearer $TOKEN" https://target.com/api/logout
curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" https://target.com/api/users/me
```

## jwt_tool — JWT Attacks
```bash
jwt_tool "$JWT" -M at                    # Run all tests
jwt_tool "$JWT" -X a                     # Algorithm none attack
jwt_tool "$JWT" -C -d rockyou.txt        # Crack HMAC key
jwt_tool "$JWT" -X k -pk public.pem      # Key confusion attack
jwt_tool "$JWT" -T -S hs256 -p "secret"  # Tamper and re-sign
```

## Burp Suite — Auth Testing
```
1. Capture authentication flow in Proxy
2. Test token replay after invalidation events
3. Use Authorize extension for privilege testing
4. Check token binding to client fingerprint
```

## nuclei — Authentication Scanning
```bash
nuclei -u https://target.com -t http/vulnerabilities/jwt/ -severity critical,high
nuclei -u https://target.com -t http/default-logins/ -severity high
```
