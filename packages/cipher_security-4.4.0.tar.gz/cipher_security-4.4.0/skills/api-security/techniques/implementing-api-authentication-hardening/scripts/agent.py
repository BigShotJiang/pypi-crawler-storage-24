#!/usr/bin/env python3
"""Test and harden API authentication mechanisms.

Usage:
    python agent.py --url https://target.com --token JWT_TOKEN --jwt-audit
    python agent.py --url https://target.com --token TOKEN --lifecycle
    python agent.py --url https://target.com --api-key KEY --key-audit
"""

import argparse
import base64
import json
import math
import subprocess
from typing import Any


def decode_jwt(token: str) -> dict[str, Any]:
    """Decode JWT header and payload without verification."""
    parts = token.split(".")
    if len(parts) < 2:
        return {"error": "Invalid JWT format"}
    result: dict[str, Any] = {}
    for label, part in [("header", parts[0]), ("payload", parts[1])]:
        padded = part + "=" * (4 - len(part) % 4)
        try:
            decoded = base64.urlsafe_b64decode(padded)
            result[label] = json.loads(decoded)
        except (ValueError, json.JSONDecodeError):
            result[label] = {"error": "decode_failed"}
    return result


def audit_jwt(token: str) -> dict[str, Any]:
    """Audit JWT token for security weaknesses."""
    decoded = decode_jwt(token)
    if "error" in decoded:
        return decoded
    header = decoded.get("header", {})
    payload = decoded.get("payload", {})
    issues: list[str] = []
    alg = header.get("alg", "")
    if alg.lower() == "none":
        issues.append("CRITICAL: Algorithm set to 'none' — unsigned token")
    if alg == "HS256" and header.get("typ") == "JWT":
        issues.append(
            "WARNING: HS256 may be vulnerable to key confusion if RS256 expected"
        )
    if "exp" not in payload:
        issues.append("HIGH: No expiration claim (exp) — token never expires")
    if "iat" not in payload:
        issues.append("MEDIUM: No issued-at claim (iat)")
    if "nbf" not in payload:
        issues.append("LOW: No not-before claim (nbf)")
    if payload.get("exp") and payload.get("iat"):
        lifetime = payload["exp"] - payload["iat"]
        if lifetime > 86400:
            issues.append(
                f"MEDIUM: Token lifetime {lifetime}s ({lifetime // 3600}h) exceeds 24h"
            )
    return {
        "status": "ok",
        "test": "jwt_audit",
        "decoded": decoded,
        "issues": issues,
        "issue_count": len(issues),
    }


def test_token_lifecycle(url: str, token: str) -> dict[str, Any]:
    """Test token invalidation after logout."""
    findings: list[dict[str, Any]] = []
    # Test current token validity
    cmd = [
        "curl",
        "-s",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "-H",
        f"Authorization: Bearer {token}",
        f"{url}/api/users/me",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        pre_status = int(result.stdout.strip())
        findings.append({"step": "pre_logout", "status": pre_status})
    except (subprocess.TimeoutExpired, ValueError):
        findings.append({"step": "pre_logout", "error": "timeout"})

    # Attempt logout
    cmd = [
        "curl",
        "-s",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "-X",
        "POST",
        "-H",
        f"Authorization: Bearer {token}",
        f"{url}/api/logout",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        findings.append({"step": "logout", "status": int(result.stdout.strip())})
    except (subprocess.TimeoutExpired, ValueError):
        findings.append({"step": "logout", "error": "timeout"})

    # Test token after logout
    cmd = [
        "curl",
        "-s",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "-H",
        f"Authorization: Bearer {token}",
        f"{url}/api/users/me",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        post_status = int(result.stdout.strip())
        findings.append(
            {
                "step": "post_logout",
                "status": post_status,
                "token_invalidated": post_status in (401, 403),
            }
        )
    except (subprocess.TimeoutExpired, ValueError):
        findings.append({"step": "post_logout", "error": "timeout"})

    return {
        "status": "ok",
        "test": "token_lifecycle",
        "findings": findings,
    }


def audit_api_key(api_key: str) -> dict[str, Any]:
    """Audit API key strength."""
    charset = len(set(api_key))
    entropy = len(api_key) * math.log2(charset) if charset > 0 else 0
    issues: list[str] = []
    if len(api_key) < 32:
        issues.append(f"MEDIUM: Key length {len(api_key)} < 32 characters")
    if entropy < 128:
        issues.append(f"HIGH: Key entropy {entropy:.0f} bits < 128 minimum")
    return {
        "status": "ok",
        "test": "api_key_audit",
        "key_length": len(api_key),
        "charset_size": charset,
        "entropy_bits": round(entropy, 1),
        "issues": issues,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API authentication hardening tester")
    parser.add_argument("--url", help="Target API base URL")
    parser.add_argument("--token", help="JWT or bearer token")
    parser.add_argument("--api-key", help="API key to audit")
    parser.add_argument(
        "--jwt-audit",
        action="store_true",
        help="Audit JWT security",
    )
    parser.add_argument(
        "--lifecycle",
        action="store_true",
        help="Test token lifecycle",
    )
    parser.add_argument(
        "--key-audit",
        action="store_true",
        help="Audit API key strength",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.jwt_audit and args.token:
        result = audit_jwt(args.token)
    elif args.lifecycle and args.url and args.token:
        result = test_token_lifecycle(args.url, args.token)
    elif args.key_audit and args.api_key:
        result = audit_api_key(args.api_key)
    else:
        parser.error(
            "Provide --jwt-audit, --lifecycle, or --key-audit with required args"
        )
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
