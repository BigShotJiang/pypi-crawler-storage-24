#!/usr/bin/env python3
"""Analyze API logs for security anomalies and generate monitoring reports.

Usage:
    python agent.py --log-file /var/log/api/access.json --check brute-force
    python agent.py --log-file /var/log/api/access.json --check error-spike --threshold 50
    python agent.py --log-file /var/log/api/access.json --check anomalous-access
    python agent.py --log-file /var/log/api/access.json --check all --output report.json
"""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def load_logs(log_file: str) -> list[dict[str, Any]]:
    """Load JSON log entries from file."""
    entries: list[dict[str, Any]] = []
    path = Path(log_file)
    if not path.exists():
        return entries
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return entries


def check_brute_force(
    logs: list[dict[str, Any]], threshold: int = 20
) -> dict[str, Any]:
    """Detect brute force attempts from authentication failures."""
    auth_failures: dict[str, int] = Counter()
    for entry in logs:
        if entry.get("status_code") == 401:
            ip = entry.get("client_ip", "unknown")
            auth_failures[ip] += 1
    flagged = {ip: count for ip, count in auth_failures.items() if count >= threshold}
    return {
        "check": "brute_force",
        "threshold": threshold,
        "total_401s": sum(auth_failures.values()),
        "flagged_ips": flagged,
        "alert": len(flagged) > 0,
    }


def check_error_spike(
    logs: list[dict[str, Any]], threshold: int = 50
) -> dict[str, Any]:
    """Detect abnormal error rates by endpoint."""
    endpoint_errors: dict[str, int] = Counter()
    endpoint_total: dict[str, int] = Counter()
    for entry in logs:
        path = entry.get("path", "unknown")
        endpoint_total[path] += 1
        status = entry.get("status_code", 0)
        if 400 <= status < 600:
            endpoint_errors[path] += 1
    flagged = {}
    for path, errors in endpoint_errors.items():
        total = endpoint_total.get(path, 1)
        rate = round((errors / total) * 100, 2)
        if rate >= threshold:
            flagged[path] = {"errors": errors, "total": total, "rate_pct": rate}
    return {
        "check": "error_spike",
        "threshold_pct": threshold,
        "flagged_endpoints": flagged,
        "alert": len(flagged) > 0,
    }


def check_anomalous_access(logs: list[dict[str, Any]]) -> dict[str, Any]:
    """Detect anomalous access patterns across users and endpoints."""
    user_endpoints: dict[str, set[str]] = defaultdict(set)
    user_request_count: dict[str, int] = Counter()
    for entry in logs:
        user = entry.get("user_id", "anonymous")
        path = entry.get("path", "unknown")
        user_endpoints[user].add(path)
        user_request_count[user] += 1
    avg_endpoints = (
        sum(len(eps) for eps in user_endpoints.values()) / len(user_endpoints)
        if user_endpoints
        else 0
    )
    flagged = {}
    for user, endpoints in user_endpoints.items():
        if len(endpoints) > avg_endpoints * 3:
            flagged[user] = {
                "unique_endpoints": len(endpoints),
                "total_requests": user_request_count[user],
            }
    return {
        "check": "anomalous_access",
        "avg_endpoints_per_user": round(avg_endpoints, 2),
        "flagged_users": flagged,
        "alert": len(flagged) > 0,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API log security analyzer")
    parser.add_argument("--log-file", required=True, help="Path to JSON log file")
    parser.add_argument(
        "--check",
        required=True,
        choices=["brute-force", "error-spike", "anomalous-access", "all"],
        help="Security check to perform",
    )
    parser.add_argument(
        "--threshold",
        type=int,
        default=20,
        help="Alert threshold (meaning varies by check)",
    )
    parser.add_argument(
        "--output",
        help="Write results to file",
    )
    args = parser.parse_args()

    logs = load_logs(args.log_file)
    if not logs:
        print(json.dumps({"error": "No log entries found", "file": args.log_file}))
        return

    results: dict[str, Any] = {"total_entries": len(logs)}

    if args.check in ("brute-force", "all"):
        results["brute_force"] = check_brute_force(logs, args.threshold)
    if args.check in ("error-spike", "all"):
        results["error_spike"] = check_error_spike(logs, args.threshold)
    if args.check in ("anomalous-access", "all"):
        results["anomalous_access"] = check_anomalous_access(logs)

    output = json.dumps(results, indent=2)
    print(output)

    if args.output:
        Path(args.output).write_text(output)


if __name__ == "__main__":
    main()
