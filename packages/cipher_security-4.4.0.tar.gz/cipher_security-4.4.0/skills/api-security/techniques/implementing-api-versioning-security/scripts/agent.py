#!/usr/bin/env python3
"""Test API versioning security and discover deprecated/shadow APIs.

Usage:
    python agent.py --url https://target.com/api --token TOKEN --discover
    python agent.py --url https://target.com/api --token TOKEN --compare v1 v2
    python agent.py --url https://target.com/api --token TOKEN --shadow
"""

import argparse
import json
import subprocess
from typing import Any


def discover_versions(base_url: str, token: str) -> dict[str, Any]:
    """Enumerate accessible API versions."""
    found: list[dict[str, Any]] = []
    # Path-based versions
    for v in range(1, 21):
        url = f"{base_url}/v{v}/users"
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-H",
            f"Authorization: Bearer {token}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            if status != 404:
                found.append({"version": f"v{v}", "status": status, "url": url})
        except (subprocess.TimeoutExpired, ValueError):
            pass
    return {
        "status": "ok",
        "test": "version_discovery",
        "versions_found": len(found),
        "findings": found,
    }


def compare_versions(
    base_url: str, token: str, ver_a: str, ver_b: str
) -> dict[str, Any]:
    """Compare security controls between two API versions."""
    comparisons: list[dict[str, Any]] = []
    endpoints = ["/users/me", "/users", "/search"]
    for ep in endpoints:
        results: dict[str, Any] = {}
        for ver in [ver_a, ver_b]:
            url = f"{base_url}/{ver}{ep}"
            cmd = [
                "curl",
                "-s",
                "-w",
                "\n%{http_code}",
                "-H",
                f"Authorization: Bearer {token}",
                url,
            ]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                lines = result.stdout.strip().rsplit("\n", 1)
                body = lines[0] if len(lines) > 1 else ""
                status = int(lines[-1]) if lines else 0
                try:
                    fields = (
                        list(json.loads(body).keys()) if body.startswith("{") else []
                    )
                except json.JSONDecodeError:
                    fields = []
                results[ver] = {
                    "status": status,
                    "body_length": len(body),
                    "fields": fields,
                }
            except (subprocess.TimeoutExpired, ValueError):
                results[ver] = {"error": "timeout"}

        a_data = results.get(ver_a, {})
        b_data = results.get(ver_b, {})
        a_fields = set(a_data.get("fields", []))
        b_fields = set(b_data.get("fields", []))
        extra_in_old = a_fields - b_fields
        comparisons.append(
            {
                "endpoint": ep,
                "versions": results,
                "extra_fields_in_old": list(extra_in_old),
                "data_exposure_risk": len(extra_in_old) > 0,
            }
        )
    return {
        "status": "ok",
        "test": "version_comparison",
        "versions": [ver_a, ver_b],
        "comparisons": comparisons,
    }


def scan_shadow_apis(base_url: str, token: str, version: str) -> dict[str, Any]:
    """Scan for undocumented endpoints on a specific version."""
    shadow_paths = [
        "/debug",
        "/internal",
        "/test",
        "/swagger",
        "/docs",
        "/graphql",
        "/health",
        "/metrics",
        "/status",
        "/admin",
        "/config",
        "/env",
        "/info",
        "/dump",
        "/export",
    ]
    found: list[dict[str, Any]] = []
    for path in shadow_paths:
        url = f"{base_url}/{version}{path}"
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-H",
            f"Authorization: Bearer {token}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            if status not in (404, 405):
                found.append({"path": path, "status": status, "url": url})
        except (subprocess.TimeoutExpired, ValueError):
            pass
    return {
        "status": "ok",
        "test": "shadow_api_scan",
        "version": version,
        "paths_tested": len(shadow_paths),
        "found": found,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API versioning security tester")
    parser.add_argument("--url", required=True, help="API base URL (before version)")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument(
        "--discover",
        action="store_true",
        help="Discover API versions",
    )
    parser.add_argument(
        "--compare",
        nargs=2,
        metavar=("V_OLD", "V_NEW"),
        help="Compare two versions (e.g., v1 v2)",
    )
    parser.add_argument(
        "--shadow",
        action="store_true",
        help="Scan for shadow APIs on old versions",
    )
    parser.add_argument(
        "--version",
        default="v1",
        help="Target version for shadow scan",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.discover:
        result = discover_versions(args.url, args.token)
    elif args.compare:
        result = compare_versions(
            args.url, args.token, args.compare[0], args.compare[1]
        )
    elif args.shadow:
        result = scan_shadow_apis(args.url, args.token, args.version)
    else:
        result = discover_versions(args.url, args.token)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
