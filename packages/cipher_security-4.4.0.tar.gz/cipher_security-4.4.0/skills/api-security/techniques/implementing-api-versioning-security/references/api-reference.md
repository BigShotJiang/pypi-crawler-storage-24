<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Implementing API Versioning Security

## curl — Version Discovery
```bash
# Enumerate path-based versions
for V in 1 2 3 4 5; do
  curl -s -o /dev/null -w "v$V: %{http_code}\n" \
    -H "Authorization: Bearer $TOKEN" \
    "https://target.com/api/v$V/users"
done

# Header-based versioning
curl -s -o /dev/null -w "%{http_code}" \
  -H "Accept: application/vnd.target.v1+json" \
  https://target.com/api/users

# Compare response fields across versions
curl -s -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/v1/users/me | jq 'keys'
curl -s -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/v2/users/me | jq 'keys'
```

## ffuf — Version and Shadow API Fuzzing
```bash
# Enumerate versions
ffuf -u "https://target.com/api/vFUZZ/users" \
  -w <(seq 1 20) -mc 200,301,403 -H "Authorization: Bearer $TOKEN"

# Shadow API discovery on old version
ffuf -u "https://target.com/api/v1/FUZZ" \
  -w /usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt \
  -mc 200,403 -H "Authorization: Bearer $TOKEN"
```

## Burp Suite — Version Comparison
```
1. Browse application using current API version
2. Replace version in Proxy match-and-replace (v2→v1)
3. Compare responses for security control differences
4. Check if auth, rate limits, or validation are weaker on old versions
```

## nuclei — Version Scanning
```bash
nuclei -u https://target.com -t http/exposures/apis/ -severity medium,high
```
