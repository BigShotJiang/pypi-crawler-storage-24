#!/usr/bin/env python3
"""Audit webhook implementations for security vulnerabilities.

Usage:
    python agent.py --url https://target.com/api/webhooks --token TOKEN --ssrf-test
    python agent.py --webhook-url https://endpoint.com/hook --replay PAYLOAD_FILE
    python agent.py --webhook-url https://endpoint.com/hook --signature-test --secret SECRET
"""

import argparse
import hashlib
import hmac
import json
import subprocess
from typing import Any


SSRF_URLS = [
    "http://169.254.169.254/latest/meta-data/",
    "http://127.0.0.1:80/",
    "http://127.0.0.1:6379/",
    "http://[::1]/",
    "http://metadata.google.internal/",
    "http://10.0.0.1/",
]


def test_webhook_ssrf(api_url: str, token: str) -> dict[str, Any]:
    """Test webhook registration for SSRF via callback URL."""
    findings: list[dict[str, Any]] = []
    for ssrf_url in SSRF_URLS:
        payload = json.dumps({"url": ssrf_url, "events": ["*"]})
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            api_url,
            "-H",
            f"Authorization: Bearer {token}",
            "-H",
            "Content-Type: application/json",
            "-d",
            payload,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            accepted = status in (200, 201)
            findings.append(
                {
                    "url": ssrf_url,
                    "status": status,
                    "accepted": accepted,
                    "risk": "critical" if accepted else "none",
                }
            )
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"url": ssrf_url, "error": "timeout"})
    return {
        "status": "ok",
        "test": "webhook_ssrf",
        "vulnerable": any(f.get("accepted") for f in findings),
        "findings": findings,
    }


def test_replay(webhook_url: str, payload_file: str) -> dict[str, Any]:
    """Test webhook replay attack by sending the same payload multiple times."""
    try:
        with open(payload_file) as f:
            payload = f.read()
    except FileNotFoundError:
        return {"error": f"Payload file not found: {payload_file}"}
    results: list[dict[str, Any]] = []
    for i in range(5):
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            webhook_url,
            "-H",
            "Content-Type: application/json",
            "-d",
            payload,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            results.append({"attempt": i + 1, "status": int(result.stdout.strip())})
        except (subprocess.TimeoutExpired, ValueError):
            results.append({"attempt": i + 1, "error": "timeout"})
    all_accepted = all(r.get("status") == 200 for r in results if "status" in r)
    return {
        "status": "ok",
        "test": "replay_attack",
        "replay_accepted": all_accepted,
        "risk": "high" if all_accepted else "low",
        "results": results,
    }


def test_signature(webhook_url: str, payload: str, secret: str) -> dict[str, Any]:
    """Test webhook signature verification."""
    valid_sig = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
    tests = [
        ("no_signature", {}),
        ("valid_signature", {"X-Hub-Signature-256": f"sha256={valid_sig}"}),
        ("invalid_signature", {"X-Hub-Signature-256": "sha256=invalid"}),
        ("empty_signature", {"X-Hub-Signature-256": ""}),
    ]
    findings: list[dict[str, Any]] = []
    for label, headers in tests:
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            webhook_url,
            "-H",
            "Content-Type: application/json",
            "-d",
            payload,
        ]
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            findings.append({"test": label, "status": status})
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"test": label, "error": "timeout"})
    return {"status": "ok", "test": "signature_verification", "findings": findings}


def main() -> None:
    parser = argparse.ArgumentParser(description="Webhook security auditor")
    parser.add_argument("--url", help="Webhook API registration endpoint")
    parser.add_argument("--webhook-url", help="Webhook receiver URL to test")
    parser.add_argument("--token", help="Authorization token")
    parser.add_argument("--ssrf-test", action="store_true")
    parser.add_argument("--replay", help="Payload file for replay test")
    parser.add_argument("--signature-test", action="store_true")
    parser.add_argument("--secret", help="Webhook secret for signature test")
    parser.add_argument("--payload", default='{"event":"test"}')
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.ssrf_test and args.url and args.token:
        result = test_webhook_ssrf(args.url, args.token)
    elif args.replay and args.webhook_url:
        result = test_replay(args.webhook_url, args.replay)
    elif args.signature_test and args.webhook_url and args.secret:
        result = test_signature(args.webhook_url, args.payload, args.secret)
    else:
        parser.error(
            "Use --ssrf-test, --replay, or --signature-test with required params"
        )
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
