<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Implementing API Security Headers

## curl — Header Auditing
```bash
# Full header audit
curl -sI -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/users/me | grep -iE \
  'strict-transport|content-security|x-content-type|x-frame|cache-control|access-control'

# CORS testing with arbitrary origin
curl -sI -H "Origin: https://evil.com" \
  https://target.com/api/data | grep -i 'access-control'

# Preflight request test
curl -sI -X OPTIONS -H "Origin: https://evil.com" \
  -H "Access-Control-Request-Method: DELETE" \
  https://target.com/api/users/123
```

## Burp Suite — CORS Analysis
```
1. Add Origin header in Proxy match-and-replace rules
2. Browse application and observe Access-Control headers
3. Test null origin, subdomain variations, and wildcard
4. Check if credentials are allowed with reflected origins
```

## nuclei — Security Header Scanning
```bash
nuclei -u https://target.com -t http/misconfiguration/cors/ -severity medium,high
nuclei -u https://target.com -t http/misconfiguration/missing-security-headers.yaml
nuclei -u https://target.com -t http/misconfiguration/http-missing-security-headers.yaml
```

## securityheaders.com — Online Audit
```bash
# Quick online scan (for public APIs only)
curl -s "https://securityheaders.com/?q=https://target.com/api&followRedirects=on" \
  | grep -oP 'class="[a-z]+-header">[^<]+'
```
