#!/usr/bin/env python3
"""Audit and validate API security headers.

Usage:
    python agent.py --url https://target.com/api/users/me --token TOKEN --audit
    python agent.py --url https://target.com/api/data --cors-test
    python agent.py --url https://target.com/api/users/me --token TOKEN --cache-test
"""

import argparse
import json
import subprocess
from typing import Any

REQUIRED_HEADERS: list[dict[str, str]] = [
    {"name": "Strict-Transport-Security", "expected": "max-age="},
    {"name": "X-Content-Type-Options", "expected": "nosniff"},
    {"name": "Cache-Control", "expected": "no-store"},
    {"name": "X-Frame-Options", "expected": "DENY"},
    {"name": "Referrer-Policy", "expected": "strict-origin"},
    {"name": "Permissions-Policy", "expected": ""},
]


def get_response_headers(url: str, token: str) -> dict[str, str]:
    """Fetch response headers from target URL."""
    cmd = [
        "curl",
        "-sI",
        "-H",
        f"Authorization: Bearer {token}",
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        headers: dict[str, str] = {}
        for line in result.stdout.split("\n"):
            if ":" in line:
                key, _, value = line.partition(":")
                headers[key.strip().lower()] = value.strip()
        return headers
    except subprocess.TimeoutExpired:
        return {}


def audit_headers(url: str, token: str) -> dict[str, Any]:
    """Audit security headers on API response."""
    headers = get_response_headers(url, token)
    findings: list[dict[str, Any]] = []
    for req in REQUIRED_HEADERS:
        name = req["name"].lower()
        present = name in headers
        value = headers.get(name, "")
        correct = req["expected"] in value if req["expected"] else present
        findings.append(
            {
                "header": req["name"],
                "present": present,
                "value": value if present else None,
                "compliant": correct,
            }
        )
    # Check for information disclosure headers
    leak_headers = ["server", "x-powered-by", "x-aspnet-version"]
    for lh in leak_headers:
        if lh in headers:
            findings.append(
                {
                    "header": lh,
                    "present": True,
                    "value": headers[lh],
                    "compliant": False,
                    "issue": "Information disclosure — remove or genericize",
                }
            )
    compliant = len([f for f in findings if f.get("compliant")])
    return {
        "status": "ok",
        "test": "header_audit",
        "total_checks": len(findings),
        "compliant": compliant,
        "findings": findings,
    }


def test_cors(url: str) -> dict[str, Any]:
    """Test CORS configuration for security issues."""
    tests = [
        {"origin": "https://evil.com", "label": "arbitrary_origin"},
        {"origin": "null", "label": "null_origin"},
        {"origin": "https://target.com.evil.com", "label": "subdomain_spoof"},
    ]
    findings: list[dict[str, Any]] = []
    for test in tests:
        cmd = [
            "curl",
            "-sI",
            "-H",
            f"Origin: {test['origin']}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            resp = result.stdout.lower()
            acao = ""
            acac = False
            for line in resp.split("\n"):
                if "access-control-allow-origin" in line:
                    acao = line.split(":", 1)[1].strip() if ":" in line else ""
                if "access-control-allow-credentials: true" in line:
                    acac = True
            reflected = test["origin"].lower() in acao or acao == "*"
            findings.append(
                {
                    "test": test["label"],
                    "origin_sent": test["origin"],
                    "acao": acao,
                    "credentials_allowed": acac,
                    "origin_reflected": reflected,
                    "vulnerable": reflected and acac,
                }
            )
        except subprocess.TimeoutExpired:
            findings.append({"test": test["label"], "error": "timeout"})
    return {
        "status": "ok",
        "test": "cors_audit",
        "findings": findings,
        "vulnerable": any(f.get("vulnerable") for f in findings),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API security headers auditor")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument(
        "--audit",
        action="store_true",
        help="Full header audit",
    )
    parser.add_argument(
        "--cors-test",
        action="store_true",
        help="Test CORS configuration",
    )
    parser.add_argument(
        "--cache-test",
        action="store_true",
        help="Test cache-control on sensitive endpoints",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.cors_test:
        result = test_cors(args.url)
    else:
        result = audit_headers(args.url, args.token)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
