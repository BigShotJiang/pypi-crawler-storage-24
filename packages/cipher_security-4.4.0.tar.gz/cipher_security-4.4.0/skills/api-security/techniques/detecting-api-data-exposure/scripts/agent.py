#!/usr/bin/env python3
"""Detect excessive data exposure in API responses.

Usage:
    python agent.py --url https://target.com/api/users/me --token TOKEN --audit
    python agent.py --url https://target.com/api/users/me --admin-token ADMIN --user-token USER --compare
    python agent.py --url https://target.com --public-scan
"""

import argparse
import json
import re
import subprocess
from typing import Any

SENSITIVE_PATTERNS: list[str] = [
    "password",
    "hash",
    "salt",
    "secret",
    "token",
    "api_key",
    "ssn",
    "social_security",
    "credit_card",
    "cvv",
    "pin",
    "private_key",
    "aws_key",
    "stripe_key",
    "access_key",
    "internal_id",
    "db_id",
    "debug",
    "stack_trace",
]

PUBLIC_ENDPOINTS: list[str] = [
    "/api/health",
    "/api/status",
    "/api/version",
    "/api/config",
    "/api/env",
    "/api/info",
    "/api/swagger.json",
    "/api/openapi.json",
    "/api/docs",
    "/api/graphql",
    "/api/metrics",
    "/api/debug",
]


def fetch_response(url: str, token: str) -> dict[str, Any]:
    """Fetch API response and return parsed body."""
    cmd = [
        "curl",
        "-s",
        "-w",
        "\n---STATUS:%{http_code}",
        "-H",
        f"Authorization: Bearer {token}",
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        output = result.stdout
        body = output.rsplit("\n---STATUS:", 1)[0] if "---STATUS:" in output else output
        meta = output.rsplit("\n---STATUS:", 1)[1] if "---STATUS:" in output else "0"
        return {"body": body, "status": int(meta.strip())}
    except (subprocess.TimeoutExpired, ValueError):
        return {"error": "timeout"}


def find_sensitive_fields(obj: Any, path: str = "") -> list[dict[str, str]]:
    """Recursively find sensitive field names in response."""
    findings: list[dict[str, str]] = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            full_path = f"{path}.{key}" if path else key
            for pattern in SENSITIVE_PATTERNS:
                if pattern in key.lower():
                    findings.append(
                        {
                            "path": full_path,
                            "pattern": pattern,
                            "value_preview": str(value)[:50],
                        }
                    )
            findings.extend(find_sensitive_fields(value, full_path))
    elif isinstance(obj, list) and obj:
        findings.extend(find_sensitive_fields(obj[0], f"{path}[0]"))
    return findings


def audit_response(url: str, token: str) -> dict[str, Any]:
    """Audit API response for sensitive data exposure."""
    resp = fetch_response(url, token)
    if "error" in resp:
        return resp
    try:
        data = json.loads(resp["body"])
    except json.JSONDecodeError:
        return {"error": "Non-JSON response", "body_preview": resp["body"][:200]}

    sensitive = find_sensitive_fields(data)
    # Check for stack traces / debug info
    debug_patterns = [
        r"at [\w.]+\([\w.]+:\d+\)",
        r"Traceback \(most recent",
        r"Exception in thread",
        r"SELECT .+ FROM",
        r"/usr/|/var/|/home/|C:\\",
    ]
    debug_found: list[str] = []
    body_str = resp["body"]
    for dp in debug_patterns:
        if re.search(dp, body_str):
            debug_found.append(dp)

    fields = list(data.keys()) if isinstance(data, dict) else []
    return {
        "status": "ok",
        "test": "data_exposure_audit",
        "http_status": resp["status"],
        "field_count": len(fields),
        "fields": fields,
        "sensitive_fields": sensitive,
        "debug_info_leaked": debug_found,
        "risk_level": "high" if sensitive or debug_found else "low",
    }


def compare_privilege_levels(
    url: str, admin_token: str, user_token: str
) -> dict[str, Any]:
    """Compare response data between admin and user roles."""
    admin_resp = fetch_response(url, admin_token)
    user_resp = fetch_response(url, user_token)
    try:
        admin_data = json.loads(admin_resp.get("body", "{}"))
        user_data = json.loads(user_resp.get("body", "{}"))
    except json.JSONDecodeError:
        return {"error": "Non-JSON response from one or both roles"}

    admin_fields = set(admin_data.keys()) if isinstance(admin_data, dict) else set()
    user_fields = set(user_data.keys()) if isinstance(user_data, dict) else set()
    extra_in_user = user_fields - admin_fields
    same_response = admin_data == user_data
    return {
        "status": "ok",
        "test": "privilege_comparison",
        "admin_fields": sorted(admin_fields),
        "user_fields": sorted(user_fields),
        "same_response": same_response,
        "over_exposure": same_response and len(admin_fields) > 3,
        "extra_in_user": sorted(extra_in_user),
    }


def scan_public_endpoints(base_url: str) -> dict[str, Any]:
    """Scan public endpoints for information disclosure."""
    exposed: list[dict[str, Any]] = []
    for ep in PUBLIC_ENDPOINTS:
        url = f"{base_url}{ep}"
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            if status not in (404, 401, 403):
                exposed.append({"endpoint": ep, "status": status})
        except (subprocess.TimeoutExpired, ValueError):
            pass
    return {
        "status": "ok",
        "test": "public_endpoint_scan",
        "total_checked": len(PUBLIC_ENDPOINTS),
        "exposed": exposed,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API data exposure detector")
    parser.add_argument("--url", required=True, help="Target API URL")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument("--audit", action="store_true", help="Audit response data")
    parser.add_argument("--admin-token", help="Admin token for comparison")
    parser.add_argument("--user-token", help="User token for comparison")
    parser.add_argument(
        "--compare", action="store_true", help="Compare privilege levels"
    )
    parser.add_argument(
        "--public-scan", action="store_true", help="Scan public endpoints"
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.compare and args.admin_token and args.user_token:
        result = compare_privilege_levels(args.url, args.admin_token, args.user_token)
    elif args.public_scan:
        result = scan_public_endpoints(args.url)
    else:
        result = audit_response(args.url, args.token)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
