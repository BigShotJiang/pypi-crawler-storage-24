<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Detecting API Data Exposure

## curl — Response Auditing
```bash
# Check all fields returned by user profile
curl -s -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/users/me | jq 'keys'

# Look for sensitive patterns in response
curl -s -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/users/me | \
  grep -iE '(password|hash|token|ssn|credit_card|secret)'

# Compare admin vs user responses
curl -s -H "Authorization: Bearer $ADMIN_TOKEN" \
  https://target.com/api/users/123 | jq 'keys'
curl -s -H "Authorization: Bearer $USER_TOKEN" \
  https://target.com/api/users/123 | jq 'keys'

# Trigger verbose errors
curl -s https://target.com/api/users/INVALID | jq .
```

## Burp Suite — Data Exposure Analysis
```
1. Browse application with Proxy capturing all responses
2. Use Logger++ extension to search response bodies
3. Filter for sensitive patterns: password, hash, token, ssn
4. Check response size anomalies indicating over-fetching
```

## trufflehog — Secret Scanning
```bash
# Scan API response for secrets
curl -s https://target.com/api/config > /tmp/api_resp.json
trufflehog filesystem /tmp/api_resp.json

# Scan OpenAPI spec for hardcoded secrets
trufflehog filesystem openapi.yaml
```

## nuclei — Information Disclosure
```bash
nuclei -u https://target.com -t http/exposures/ -severity medium,high
nuclei -u https://target.com -t http/misconfiguration/information-disclosure.yaml
```
