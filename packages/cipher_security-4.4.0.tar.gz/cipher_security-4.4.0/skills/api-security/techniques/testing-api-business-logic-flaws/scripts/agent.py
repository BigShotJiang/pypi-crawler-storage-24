#!/usr/bin/env python3
"""Test APIs for business logic vulnerabilities.

Usage:
    python agent.py --url https://target.com/api/coupon/redeem --token TOKEN --race 20
    python agent.py --url https://target.com/api/cart/add --token TOKEN --negative-qty
    python agent.py --url https://target.com/api/orders/123/status --token TOKEN --state-test
"""

import argparse
import json
import subprocess
import threading
from typing import Any


def test_race_condition(
    url: str, token: str, concurrency: int, payload: str
) -> dict[str, Any]:
    """Send concurrent requests to test race conditions."""
    results: list[dict[str, Any]] = []
    lock = threading.Lock()

    def send_request(idx: int) -> None:
        cmd = [
            "curl",
            "-s",
            "-w",
            "\n%{http_code}",
            "-X",
            "POST",
            "-H",
            "Content-Type: application/json",
            "-H",
            f"Authorization: Bearer {token}",
            "-d",
            payload,
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            lines = result.stdout.strip().rsplit("\n", 1)
            body = lines[0] if len(lines) > 1 else ""
            status = int(lines[-1]) if lines else 0
            with lock:
                results.append(
                    {
                        "thread": idx,
                        "status": status,
                        "body_preview": body[:200],
                    }
                )
        except (subprocess.TimeoutExpired, ValueError):
            with lock:
                results.append({"thread": idx, "error": "timeout"})

    threads = [
        threading.Thread(target=send_request, args=(i,)) for i in range(concurrency)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=15)

    success_count = len([r for r in results if r.get("status") in (200, 201)])
    return {
        "status": "ok",
        "test": "race_condition",
        "concurrency": concurrency,
        "total_responses": len(results),
        "success_count": success_count,
        "potential_race": success_count > 1,
        "results": results,
    }


def test_negative_quantity(url: str, token: str) -> dict[str, Any]:
    """Test negative and zero quantity handling."""
    test_values = [
        {"label": "negative", "payload": {"productId": "1", "quantity": -1}},
        {"label": "zero", "payload": {"productId": "1", "quantity": 0}},
        {"label": "float", "payload": {"productId": "1", "quantity": 0.001}},
        {"label": "large", "payload": {"productId": "1", "quantity": 999999999}},
    ]
    findings: list[dict[str, Any]] = []
    for test in test_values:
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            "-H",
            "Content-Type: application/json",
            "-H",
            f"Authorization: Bearer {token}",
            "-d",
            json.dumps(test["payload"]),
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            findings.append(
                {
                    "test": test["label"],
                    "accepted": status in (200, 201),
                    "status": status,
                }
            )
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"test": test["label"], "error": "timeout"})
    return {
        "status": "ok",
        "test": "quantity_manipulation",
        "findings": findings,
    }


def test_state_transition(url: str, token: str, states: list[str]) -> dict[str, Any]:
    """Test invalid state transitions."""
    findings: list[dict[str, Any]] = []
    for state in states:
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "PUT",
            "-H",
            "Content-Type: application/json",
            "-H",
            f"Authorization: Bearer {token}",
            "-d",
            json.dumps({"status": state}),
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            findings.append(
                {
                    "target_state": state,
                    "accepted": status in (200, 204),
                    "status": status,
                }
            )
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"target_state": state, "error": "timeout"})
    return {
        "status": "ok",
        "test": "state_transition",
        "findings": findings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API business logic flaw tester")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument(
        "--race",
        type=int,
        help="Test race condition with N concurrent requests",
    )
    parser.add_argument(
        "--race-payload",
        default='{"action":"redeem"}',
        help="JSON payload for race condition test",
    )
    parser.add_argument(
        "--negative-qty",
        action="store_true",
        help="Test negative quantity handling",
    )
    parser.add_argument(
        "--state-test",
        action="store_true",
        help="Test state machine violations",
    )
    parser.add_argument(
        "--states",
        default="delivered,cancelled,refunded,pending",
        help="Comma-separated states to test",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.race:
        result = test_race_condition(args.url, args.token, args.race, args.race_payload)
    elif args.negative_qty:
        result = test_negative_quantity(args.url, args.token)
    elif args.state_test:
        result = test_state_transition(args.url, args.token, args.states.split(","))
    else:
        parser.error("Provide --race, --negative-qty, or --state-test")
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
