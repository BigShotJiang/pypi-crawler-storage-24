#!/usr/bin/env python3
"""Audit GraphQL APIs for security vulnerabilities.

Usage:
    python agent.py --url https://target.com/graphql --introspection
    python agent.py --url https://target.com/graphql --depth-test --max-depth 10
    python agent.py --url https://target.com/graphql --batch-test
"""

import argparse
import json
import subprocess
from typing import Any


def test_introspection(url: str) -> dict[str, Any]:
    """Test if GraphQL introspection is enabled."""
    query = '{"query":"{ __schema { types { name kind fields { name } } } }"}'
    cmd = [
        "curl",
        "-s",
        "-X",
        "POST",
        url,
        "-H",
        "Content-Type: application/json",
        "-d",
        query,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        data = json.loads(result.stdout)
        if "data" in data and data["data"].get("__schema"):
            types = data["data"]["__schema"].get("types", [])
            type_names = [t["name"] for t in types if not t["name"].startswith("__")]
            return {
                "status": "ok",
                "introspection_enabled": True,
                "type_count": len(type_names),
                "types": type_names[:30],
                "risk": "high",
            }
        return {"status": "ok", "introspection_enabled": False}
    except (json.JSONDecodeError, KeyError):
        return {
            "status": "ok",
            "introspection_enabled": False,
            "note": "Non-JSON response",
        }
    except subprocess.TimeoutExpired:
        return {"error": "Request timed out"}


def test_query_depth(url: str, max_depth: int = 10) -> dict[str, Any]:
    """Test query depth limits with nested queries."""
    findings: list[dict[str, Any]] = []
    for depth in range(1, max_depth + 1):
        inner = "{ name }"
        for _ in range(depth):
            inner = f"{{ friends {inner} }}"
        query = f'{{"query":"{{ users {inner} }}"}}'
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            "-X",
            "POST",
            url,
            "-H",
            "Content-Type: application/json",
            "-d",
            query,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            status = int(result.stdout.strip())
            findings.append({"depth": depth, "status": status})
            if status in (400, 413, 429):
                return {
                    "status": "ok",
                    "test": "query_depth",
                    "max_allowed_depth": depth - 1,
                    "findings": findings,
                }
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"depth": depth, "error": "timeout"})
    return {
        "status": "ok",
        "test": "query_depth",
        "max_allowed_depth": None,
        "note": f"No depth limit found up to {max_depth}",
        "risk": "high",
        "findings": findings,
    }


def test_batch_queries(url: str) -> dict[str, Any]:
    """Test if batch queries are accepted."""
    batch = json.dumps(
        [
            {"query": "{ __typename }"},
            {"query": "{ __typename }"},
            {"query": "{ __typename }"},
        ]
    )
    cmd = [
        "curl",
        "-s",
        "-X",
        "POST",
        url,
        "-H",
        "Content-Type: application/json",
        "-d",
        batch,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        data = json.loads(result.stdout)
        if isinstance(data, list):
            return {
                "status": "ok",
                "batch_enabled": True,
                "responses": len(data),
                "risk": "medium",
            }
        return {"status": "ok", "batch_enabled": False}
    except (json.JSONDecodeError, subprocess.TimeoutExpired):
        return {"status": "ok", "batch_enabled": False}


def main() -> None:
    parser = argparse.ArgumentParser(description="GraphQL security auditor")
    parser.add_argument("--url", required=True, help="GraphQL endpoint URL")
    parser.add_argument("--introspection", action="store_true")
    parser.add_argument("--depth-test", action="store_true")
    parser.add_argument("--batch-test", action="store_true")
    parser.add_argument("--max-depth", type=int, default=10)
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.introspection:
        result = test_introspection(args.url)
    elif args.depth_test:
        result = test_query_depth(args.url, args.max_depth)
    elif args.batch_test:
        result = test_batch_queries(args.url)
    else:
        parser.error("Use --introspection, --depth-test, or --batch-test")
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
