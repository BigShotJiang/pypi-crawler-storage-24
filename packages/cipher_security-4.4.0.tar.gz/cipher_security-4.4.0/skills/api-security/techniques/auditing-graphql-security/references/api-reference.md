<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Auditing GraphQL Security

## curl — Introspection
```bash
# Full schema dump
curl -s -X POST URL/graphql -H "Content-Type: application/json" \
  -d '{"query":"{ __schema { types { name fields { name type { name } } } } }"}'

# Minimal introspection check
curl -s -X POST URL/graphql -H "Content-Type: application/json" \
  -d '{"query":"{ __schema { types { name } } }"}' | jq '.data.__schema.types[].name'
```

## InQL — Automated Scanner
```
1. Install InQL Burp extension
2. Point at GraphQL endpoint
3. Auto-extracts schema, queries, mutations
4. Generates query templates for testing
```

## nuclei — GraphQL Templates
```bash
nuclei -u https://target.com/graphql -t http/exposures/apis/graphql-introspection.yaml
nuclei -u https://target.com -t http/exposures/apis/ -severity high,critical
```

## Batch Query Testing
```bash
# Array batch
curl -s -X POST URL/graphql -H "Content-Type: application/json" \
  -d '[{"query":"{ user(id:1) { email } }"},{"query":"{ user(id:2) { email } }"}]'

# Alias amplification
curl -s -X POST URL/graphql -H "Content-Type: application/json" \
  -d '{"query":"{ a1: user(id:1) { email } a2: user(id:2) { email } }"}'
```
