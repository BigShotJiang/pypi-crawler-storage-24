#!/usr/bin/env python3
"""Implement and verify API security gateway configurations.

Usage:
    python agent.py --url https://api.target.com --verify-rate-limit
    python agent.py --url https://api.target.com --verify-cors
    python agent.py --url https://api.target.com --verify-headers
    python agent.py --url https://api.target.com --full-audit
"""

import argparse
import json
import subprocess
from typing import Any


def verify_rate_limiting(url: str, max_requests: int = 100) -> dict[str, Any]:
    """Verify rate limiting is enforced on the API gateway."""
    results: list[dict[str, Any]] = []
    rate_limited = False
    for i in range(1, max_requests + 1):
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            status = int(result.stdout.strip())
            if status == 429:
                rate_limited = True
                results.append({"request": i, "status": status})
                break
            if i % 10 == 0:
                results.append({"request": i, "status": status})
        except (subprocess.TimeoutExpired, ValueError):
            pass
    return {
        "status": "ok",
        "test": "rate_limiting",
        "rate_limit_enforced": rate_limited,
        "triggered_at": results[-1]["request"] if rate_limited else None,
        "risk": "low" if rate_limited else "high",
    }


def verify_cors(url: str) -> dict[str, Any]:
    """Verify CORS policy is properly configured."""
    origins = [
        "https://evil.com",
        "null",
        "https://target.com.evil.com",
    ]
    findings: list[dict[str, Any]] = []
    for origin in origins:
        cmd = [
            "curl",
            "-s",
            "-I",
            "-H",
            f"Origin: {origin}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            acao = ""
            for line in result.stdout.split("\n"):
                if "access-control-allow-origin" in line.lower():
                    acao = line.split(":", 1)[1].strip() if ":" in line else ""
            reflected = origin.lower() in acao.lower() or acao == "*"
            findings.append(
                {
                    "origin": origin,
                    "acao_header": acao,
                    "reflected": reflected,
                    "risk": "high" if reflected else "none",
                }
            )
        except subprocess.TimeoutExpired:
            findings.append({"origin": origin, "error": "timeout"})
    return {
        "status": "ok",
        "test": "cors_policy",
        "misconfigured": any(f.get("reflected") for f in findings),
        "findings": findings,
    }


def verify_security_headers(url: str) -> dict[str, Any]:
    """Verify security headers are present."""
    cmd = ["curl", "-s", "-I", url]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        headers_raw = result.stdout.lower()
        checks = {
            "x-content-type-options": "nosniff" in headers_raw,
            "x-frame-options": "x-frame-options" in headers_raw,
            "strict-transport-security": "strict-transport-security" in headers_raw,
            "server_hidden": "server:" not in headers_raw or "nginx" not in headers_raw,
            "x-powered-by_hidden": "x-powered-by" not in headers_raw,
        }
        missing = [h for h, present in checks.items() if not present]
        return {
            "status": "ok",
            "test": "security_headers",
            "checks": checks,
            "missing_headers": missing,
            "risk": "medium" if missing else "low",
        }
    except subprocess.TimeoutExpired:
        return {"error": "Request timed out"}


def full_audit(url: str) -> dict[str, Any]:
    """Run all gateway security checks."""
    return {
        "status": "ok",
        "rate_limiting": verify_rate_limiting(url, 50),
        "cors": verify_cors(url),
        "headers": verify_security_headers(url),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API security gateway auditor")
    parser.add_argument("--url", required=True, help="API gateway URL")
    parser.add_argument("--verify-rate-limit", action="store_true")
    parser.add_argument("--verify-cors", action="store_true")
    parser.add_argument("--verify-headers", action="store_true")
    parser.add_argument("--full-audit", action="store_true")
    parser.add_argument("--max-requests", type=int, default=100)
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.full_audit:
        result = full_audit(args.url)
    elif args.verify_rate_limit:
        result = verify_rate_limiting(args.url, args.max_requests)
    elif args.verify_cors:
        result = verify_cors(args.url)
    elif args.verify_headers:
        result = verify_security_headers(args.url)
    else:
        parser.error(
            "Use --full-audit, --verify-rate-limit, --verify-cors, or --verify-headers"
        )
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
