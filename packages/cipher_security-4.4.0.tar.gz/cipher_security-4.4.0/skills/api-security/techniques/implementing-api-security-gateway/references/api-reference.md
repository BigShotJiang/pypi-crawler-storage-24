<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Implementing API Security Gateway

## Kong — Plugin Configuration
```bash
# Rate limiting
curl -X POST http://kong:8001/services/api/plugins \
  -d "name=rate-limiting" -d "config.minute=60" -d "config.policy=local"

# JWT authentication
curl -X POST http://kong:8001/services/api/plugins -d "name=jwt"

# Request size limiting
curl -X POST http://kong:8001/services/api/plugins \
  -d "name=request-size-limiting" -d "config.allowed_payload_size=1"

# CORS policy
curl -X POST http://kong:8001/services/api/plugins \
  -d "name=cors" -d "config.origins=https://app.target.com"
```

## AWS API Gateway
```bash
# Create usage plan with throttling
aws apigateway create-usage-plan --name "standard" \
  --throttle burstLimit=50,rateLimit=100 --quota limit=10000,period=DAY

# Enable request validation
aws apigateway create-request-validator --rest-api-id ID \
  --name "full-validation" --validate-request-body --validate-request-parameters
```

## OWASP ZAP — API Scan
```bash
zap-cli quick-scan -s all https://api.target.com/api
zap-cli active-scan https://api.target.com/api
```

## Verification
```bash
# Test rate limiting
for i in $(seq 1 100); do curl -s -o /dev/null -w "%{http_code}\n" URL; done

# Test CORS
curl -si -H "Origin: https://evil.com" URL | grep -i access-control
```
