#!/usr/bin/env python3
"""Analyze OpenAPI/Swagger specifications for security vulnerabilities.

Usage:
    python agent.py --spec https://target.com/openapi.json --discover
    python agent.py --spec openapi.json --audit-security
    python agent.py --spec openapi.json --find-sensitive
    python agent.py --url https://target.com --find-spec
"""

import argparse
import json
import subprocess
from typing import Any


SPEC_PATHS = [
    "/swagger.json",
    "/openapi.json",
    "/api-docs",
    "/api/swagger.json",
    "/api/openapi.json",
    "/v1/swagger.json",
    "/v2/api-docs",
    "/swagger/v1/swagger.json",
    "/.well-known/openapi.yaml",
    "/api/docs",
]

SENSITIVE_PARAM_NAMES = [
    "password",
    "token",
    "secret",
    "key",
    "ssn",
    "credit_card",
    "api_key",
    "access_token",
    "private_key",
]


def find_spec(base_url: str) -> dict[str, Any]:
    """Discover OpenAPI specification files."""
    found: list[dict[str, str]] = []
    for path in SPEC_PATHS:
        url = f"{base_url.rstrip('/')}{path}"
        cmd = [
            "curl",
            "-s",
            "-o",
            "/dev/null",
            "-w",
            "%{http_code}",
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            if status == 200:
                found.append({"path": path, "url": url})
        except (subprocess.TimeoutExpired, ValueError):
            pass
    return {"status": "ok", "test": "spec_discovery", "found": found}


def load_spec(spec_path: str) -> dict[str, Any] | None:
    """Load OpenAPI spec from URL or file."""
    if spec_path.startswith("http"):
        cmd = ["curl", "-s", spec_path]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            return json.loads(result.stdout)
        except (json.JSONDecodeError, subprocess.TimeoutExpired):
            return None
    else:
        try:
            with open(spec_path) as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return None


def audit_security_schemes(spec: dict[str, Any]) -> dict[str, Any]:
    """Audit security scheme definitions and per-endpoint coverage."""
    schemes = spec.get("components", {}).get("securitySchemes", {}) or spec.get(
        "securityDefinitions", {}
    )
    global_security = spec.get("security", [])
    unprotected: list[str] = []
    total_ops = 0

    paths = spec.get("paths", {})
    for path, methods in paths.items():
        for method, operation in methods.items():
            if method.lower() in ("get", "post", "put", "delete", "patch"):
                total_ops += 1
                op_security = operation.get("security")
                if op_security is None and not global_security:
                    unprotected.append(f"{method.upper()} {path}")
                elif op_security == []:
                    unprotected.append(f"{method.upper()} {path}")

    api_key_in_query = [
        name for name, conf in schemes.items() if conf.get("in") == "query"
    ]
    return {
        "status": "ok",
        "test": "security_audit",
        "security_schemes": list(schemes.keys()),
        "global_security": bool(global_security),
        "total_operations": total_ops,
        "unprotected_endpoints": unprotected,
        "api_key_in_query": api_key_in_query,
        "risk": "high" if unprotected else "low",
    }


def find_sensitive_params(spec: dict[str, Any]) -> dict[str, Any]:
    """Find sensitive data in query parameters."""
    findings: list[dict[str, str]] = []
    paths = spec.get("paths", {})
    for path, methods in paths.items():
        for method, operation in methods.items():
            if not isinstance(operation, dict):
                continue
            for param in operation.get("parameters", []):
                if param.get("in") == "query" and any(
                    s in param.get("name", "").lower() for s in SENSITIVE_PARAM_NAMES
                ):
                    findings.append(
                        {
                            "endpoint": f"{method.upper()} {path}",
                            "param": param["name"],
                            "risk": "high",
                        }
                    )
    return {
        "status": "ok",
        "test": "sensitive_params",
        "findings": findings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="OpenAPI specification security analyzer"
    )
    parser.add_argument("--spec", help="OpenAPI spec URL or file path")
    parser.add_argument("--url", help="Base URL for spec discovery")
    parser.add_argument("--find-spec", action="store_true")
    parser.add_argument("--audit-security", action="store_true")
    parser.add_argument("--find-sensitive", action="store_true")
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.find_spec and args.url:
        result = find_spec(args.url)
    elif args.audit_security and args.spec:
        spec = load_spec(args.spec)
        if not spec:
            result = {"error": "Failed to load OpenAPI specification"}
        else:
            result = audit_security_schemes(spec)
    elif args.find_sensitive and args.spec:
        spec = load_spec(args.spec)
        if not spec:
            result = {"error": "Failed to load OpenAPI specification"}
        else:
            result = find_sensitive_params(spec)
    else:
        parser.error(
            "Use --find-spec with --url, or --audit-security/--find-sensitive with --spec"
        )
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
