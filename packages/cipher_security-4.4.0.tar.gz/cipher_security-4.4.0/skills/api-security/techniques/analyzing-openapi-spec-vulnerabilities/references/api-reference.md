<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Analyzing OpenAPI Spec Vulnerabilities

## Spectral — API Linting
```bash
# Lint with default rules
spectral lint openapi.json

# Lint with custom security ruleset
spectral lint openapi.json --ruleset spectral-security.yaml

# Output formats
spectral lint openapi.json --format json > spectral-results.json
```

## Schemathesis — Property-Based API Testing
```bash
# Run all checks against spec
schemathesis run https://target.com/openapi.json --checks all

# With authentication
schemathesis run URL/openapi.json --auth TOKEN --auth-type bearer

# Limit test cases
schemathesis run URL/openapi.json --hypothesis-max-examples 100
```

## curl + jq — Manual Spec Analysis
```bash
# List all endpoints
curl -s URL/openapi.json | jq '.paths | keys[]'

# Find endpoints without security
curl -s URL/openapi.json | jq '.paths | to_entries[] |
  .value | to_entries[] | select(.value.security == null or .value.security == [])'

# Check security schemes
curl -s URL/openapi.json | jq '.components.securitySchemes'
```

## nuclei — API Exposure Templates
```bash
nuclei -u URL -t http/exposures/apis/ -severity high,critical
```
