#!/usr/bin/env python3
"""Detect API enumeration attacks via response differential analysis.

Usage:
    python agent.py --url https://target.com/api/login --valid-email user@t.com --method POST
    python agent.py --url https://target.com/api/login --timing --valid-email user@t.com
    python agent.py --url https://target.com/api/register --registration-enum
"""

import argparse
import json
import subprocess
import time
from typing import Any


def test_response_differential(
    url: str, valid_email: str, invalid_email: str
) -> dict[str, Any]:
    """Compare responses for valid vs invalid identifiers."""
    results: dict[str, Any] = {}
    for label, email in [("valid", valid_email), ("invalid", invalid_email)]:
        payload = json.dumps({"email": email, "password": "test_password_123"})
        cmd = [
            "curl",
            "-s",
            "-w",
            "\n---STATUS:%{http_code}---TIME:%{time_total}",
            "-X",
            "POST",
            "-H",
            "Content-Type: application/json",
            "-d",
            payload,
            url,
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            output = result.stdout
            body = (
                output.rsplit("\n---STATUS:", 1)[0]
                if "---STATUS:" in output
                else output
            )
            meta = output.rsplit("\n---STATUS:", 1)[1] if "---STATUS:" in output else ""
            status = meta.split("---TIME:")[0] if "---TIME:" in meta else "0"
            resp_time = meta.split("---TIME:")[1] if "---TIME:" in meta else "0"
            results[label] = {
                "status": int(status),
                "body": body.strip()[:500],
                "body_length": len(body),
                "response_time": float(resp_time),
            }
        except (subprocess.TimeoutExpired, ValueError):
            results[label] = {"error": "timeout"}

    v = results.get("valid", {})
    inv = results.get("invalid", {})
    enumerable = (
        v.get("status") != inv.get("status")
        or v.get("body") != inv.get("body")
        or v.get("body_length") != inv.get("body_length")
    )
    return {
        "status": "ok",
        "test": "response_differential",
        "enumerable": enumerable,
        "differences": {
            "status_differs": v.get("status") != inv.get("status"),
            "body_differs": v.get("body") != inv.get("body"),
            "length_differs": v.get("body_length") != inv.get("body_length"),
        },
        "results": results,
    }


def test_timing_oracle(
    url: str, valid_email: str, invalid_email: str, samples: int = 10
) -> dict[str, Any]:
    """Detect timing-based enumeration oracles."""
    timings: dict[str, list[float]] = {"valid": [], "invalid": []}
    for label, email in [("valid", valid_email), ("invalid", invalid_email)]:
        for _ in range(samples):
            payload = json.dumps({"email": email, "password": "wrong"})
            cmd = [
                "curl",
                "-s",
                "-o",
                "/dev/null",
                "-w",
                "%{time_total}",
                "-X",
                "POST",
                "-H",
                "Content-Type: application/json",
                "-d",
                payload,
                url,
            ]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                timings[label].append(float(result.stdout.strip()))
            except (subprocess.TimeoutExpired, ValueError):
                pass
            time.sleep(0.1)

    def stats(values: list[float]) -> dict[str, float]:
        if not values:
            return {"mean": 0, "min": 0, "max": 0}
        return {
            "mean": round(sum(values) / len(values), 4),
            "min": round(min(values), 4),
            "max": round(max(values), 4),
        }

    v_stats = stats(timings["valid"])
    i_stats = stats(timings["invalid"])
    diff = abs(v_stats["mean"] - i_stats["mean"])
    return {
        "status": "ok",
        "test": "timing_oracle",
        "samples": samples,
        "valid_stats": v_stats,
        "invalid_stats": i_stats,
        "time_difference": round(diff, 4),
        "timing_oracle_detected": diff > 0.05,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API enumeration attack detector")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--valid-email", required=True, help="Known valid email")
    parser.add_argument(
        "--invalid-email",
        default="nonexistent_test_xyz@example.com",
        help="Known invalid email",
    )
    parser.add_argument(
        "--timing",
        action="store_true",
        help="Test timing oracle",
    )
    parser.add_argument(
        "--samples",
        type=int,
        default=10,
        help="Number of timing samples",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.timing:
        result = test_timing_oracle(
            args.url, args.valid_email, args.invalid_email, args.samples
        )
    else:
        result = test_response_differential(
            args.url, args.valid_email, args.invalid_email
        )

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
