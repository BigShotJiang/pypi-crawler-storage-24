<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Detecting API Schema Violations

## curl — Type Confusion Testing
```bash
# String where integer expected
curl -s -X POST -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"id":"abc","quantity":"NaN"}' https://target.com/api/orders

# Null injection
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"email":null,"name":null}' https://target.com/api/users

# Oversized payload
python3 -c "print('{\"name\":\"' + 'A'*100000 + '\"}')" | \
  curl -s -X POST -H "Content-Type: application/json" -d @- https://target.com/api/users
```

## Spectral — OpenAPI Linting
```bash
# Install and lint spec
npm install -g @stoplight/spectral-cli
spectral lint openapi.yaml --ruleset .spectral.yaml

# Custom security ruleset
spectral lint openapi.yaml -r security-rules.yaml
```

## nuclei — Schema Validation
```bash
nuclei -u https://target.com -t http/misconfiguration/ \
  -H "Authorization: Bearer $TOKEN" -severity medium,high,critical
```

## openapi-diff — Schema Drift
```bash
# Compare spec versions for breaking changes
openapi-diff openapi-v1.yaml openapi-v2.yaml --json > diff.json
```
