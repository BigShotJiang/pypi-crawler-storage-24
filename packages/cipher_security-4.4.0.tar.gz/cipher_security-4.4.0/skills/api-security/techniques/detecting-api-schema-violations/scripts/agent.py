#!/usr/bin/env python3
"""Detect API schema violations by testing type confusion and boundary attacks.

Usage:
    python agent.py --url https://target.com/api/users --token TOKEN --type-confusion
    python agent.py --url https://target.com/api/orders --token TOKEN --boundary
    python agent.py --spec openapi.yaml --url https://target.com --token TOKEN --drift
"""

import argparse
import json
import subprocess
from typing import Any


TYPE_CONFUSION_PAYLOADS: list[dict[str, Any]] = [
    {"label": "string_as_integer", "payload": {"id": "abc", "count": "not_a_number"}},
    {"label": "array_as_object", "payload": {"user": [1, 2, 3]}},
    {"label": "null_injection", "payload": {"email": None, "name": None}},
    {"label": "boolean_as_string", "payload": {"active": "yes", "admin": "true"}},
    {"label": "object_as_string", "payload": {"data": "{'nested': 'value'}"}},
    {"label": "float_overflow", "payload": {"amount": 1e308}},
]


def send_payload(url: str, token: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Send a JSON payload and capture response status."""
    cmd = [
        "curl",
        "-s",
        "-w",
        "\n%{http_code}",
        "-X",
        "POST",
        "-H",
        "Content-Type: application/json",
        "-H",
        f"Authorization: Bearer {token}",
        "-d",
        json.dumps(payload),
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        lines = result.stdout.strip().rsplit("\n", 1)
        body = lines[0] if len(lines) > 1 else ""
        status = int(lines[-1]) if lines else 0
        return {"status": status, "body_preview": body[:200]}
    except (subprocess.TimeoutExpired, ValueError) as exc:
        return {"error": str(exc)}


def test_type_confusion(url: str, token: str) -> dict[str, Any]:
    """Test type confusion payloads against endpoint."""
    findings: list[dict[str, Any]] = []
    for tc in TYPE_CONFUSION_PAYLOADS:
        resp = send_payload(url, token, tc["payload"])
        accepted = resp.get("status", 0) in (200, 201, 204)
        findings.append(
            {
                "test": tc["label"],
                "accepted": accepted,
                **resp,
            }
        )
    return {
        "status": "ok",
        "test": "type_confusion",
        "total": len(findings),
        "accepted_count": len([f for f in findings if f.get("accepted")]),
        "findings": findings,
    }


def test_boundary_violations(url: str, token: str) -> dict[str, Any]:
    """Test boundary condition payloads."""
    tests = [
        {"label": "oversized_string", "payload": {"name": "A" * 100000}},
        {"label": "negative_number", "payload": {"quantity": -1, "price": -100}},
        {"label": "empty_object", "payload": {}},
        {"label": "large_array", "payload": {"items": list(range(10000))}},
        {"label": "deep_nesting", "payload": {"a": {"a": {"a": {"a": {"a": "deep"}}}}}},
    ]
    findings: list[dict[str, Any]] = []
    for tc in tests:
        resp = send_payload(url, token, tc["payload"])
        accepted = resp.get("status", 0) in (200, 201, 204)
        findings.append({"test": tc["label"], "accepted": accepted, **resp})
    return {
        "status": "ok",
        "test": "boundary_violations",
        "total": len(findings),
        "accepted_count": len([f for f in findings if f.get("accepted")]),
        "findings": findings,
    }


def test_response_drift(spec_path: str, url: str, token: str) -> dict[str, Any]:
    """Compare API response fields against OpenAPI spec."""
    try:
        import yaml  # noqa: F811

        with open(spec_path) as f:
            spec = yaml.safe_load(f)
    except (FileNotFoundError, ImportError) as exc:
        return {"error": f"Cannot load spec: {exc}"}

    cmd = [
        "curl",
        "-s",
        "-H",
        f"Authorization: Bearer {token}",
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        response = json.loads(result.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
        return {"error": f"Request failed: {exc}"}

    schemas = spec.get("components", {}).get("schemas", {})
    actual_fields = set(response.keys()) if isinstance(response, dict) else set()
    drift_report: list[dict[str, Any]] = []
    for schema_name, schema_def in schemas.items():
        expected = set(schema_def.get("properties", {}).keys())
        extra = actual_fields - expected
        if extra and len(actual_fields & expected) > 0:
            drift_report.append(
                {
                    "schema": schema_name,
                    "extra_fields": list(extra),
                    "data_exposure_risk": True,
                }
            )
    return {
        "status": "ok",
        "test": "response_drift",
        "actual_fields": list(actual_fields),
        "drift_reports": drift_report,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="API schema violation detector")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument(
        "--type-confusion",
        action="store_true",
        help="Test type confusion attacks",
    )
    parser.add_argument(
        "--boundary",
        action="store_true",
        help="Test boundary violations",
    )
    parser.add_argument("--spec", help="OpenAPI spec path for drift detection")
    parser.add_argument(
        "--drift",
        action="store_true",
        help="Check response schema drift",
    )
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.type_confusion:
        result = test_type_confusion(args.url, args.token)
    elif args.boundary:
        result = test_boundary_violations(args.url, args.token)
    elif args.drift and args.spec:
        result = test_response_drift(args.spec, args.url, args.token)
    else:
        result = test_type_confusion(args.url, args.token)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
