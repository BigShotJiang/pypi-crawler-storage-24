<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->
# API Reference — Analyzing API Authentication Flaws

## jwt_tool — JWT Testing
```bash
# Comprehensive JWT scan
python3 jwt_tool.py TOKEN -M at -t URL/api/me -rh "Authorization: Bearer"

# Algorithm confusion (RS256 → HS256)
python3 jwt_tool.py TOKEN -X k -pk public.pem

# Brute-force HMAC secret
python3 jwt_tool.py TOKEN -C -d rockyou.txt
```

## hashcat — JWT Secret Cracking
```bash
hashcat -m 16500 jwt.txt rockyou.txt --force
```

## curl — Authentication Testing
```bash
# Test unauthenticated access
curl -s -o /dev/null -w "%{http_code}" URL/api/admin/users

# Test expired token
curl -s -H "Authorization: Bearer EXPIRED_TOKEN" URL/api/me

# Test token after logout
curl -s -X POST URL/api/logout -H "Authorization: Bearer TOKEN"
curl -s -H "Authorization: Bearer TOKEN" URL/api/me
```

## nuclei — Auth Templates
```bash
nuclei -u URL -t http/vulnerabilities/ -tags auth -severity critical,high
nuclei -u URL -t http/exposures/tokens/
```
