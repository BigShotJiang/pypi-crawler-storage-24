#!/usr/bin/env python3
"""Analyze API authentication mechanisms for security weaknesses.

Usage:
    python agent.py --url https://target.com/api/me --jwt TOKEN --analyze
    python agent.py --url https://target.com/api --unauthenticated-scan
    python agent.py --jwt TOKEN --decode
"""

import argparse
import base64
import json
import subprocess
from typing import Any


def decode_jwt(token: str) -> dict[str, Any]:
    """Decode and analyze a JWT token."""
    parts = token.split(".")
    if len(parts) < 2:
        return {"error": "Invalid JWT format"}
    findings: list[str] = []
    try:
        header_raw = parts[0] + "=" * (4 - len(parts[0]) % 4)
        header = json.loads(base64.urlsafe_b64decode(header_raw))
    except (json.JSONDecodeError, Exception):
        return {"error": "Failed to decode JWT header"}
    try:
        payload_raw = parts[1] + "=" * (4 - len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_raw))
    except (json.JSONDecodeError, Exception):
        return {"error": "Failed to decode JWT payload"}
    alg = header.get("alg", "unknown")
    if alg.lower() == "none":
        findings.append("CRITICAL: Algorithm set to 'none' — signature not verified")
    if alg == "HS256":
        findings.append("INFO: HMAC-SHA256 — test for weak secret brute-force")
    if "exp" not in payload:
        findings.append("HIGH: No expiration claim — token never expires")
    if "iat" in payload and "exp" in payload:
        lifetime = payload["exp"] - payload["iat"]
        if lifetime > 86400:
            findings.append(
                f"MEDIUM: Long token lifetime ({lifetime}s / {lifetime // 3600}h)"
            )
    if payload.get("role") in ("admin", "root", "superuser"):
        findings.append(f"INFO: Elevated role claim — {payload.get('role')}")
    return {
        "status": "ok",
        "header": header,
        "payload": payload,
        "algorithm": alg,
        "findings": findings,
    }


def test_unauthenticated(base_url: str) -> dict[str, Any]:
    """Test endpoints for missing authentication requirements."""
    endpoints = [
        "/users",
        "/config",
        "/health",
        "/metrics",
        "/debug",
        "/admin",
        "/docs",
        "/swagger.json",
        "/openapi.json",
    ]
    findings: list[dict[str, Any]] = []
    for ep in endpoints:
        url = f"{base_url}{ep}"
        cmd = ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", url]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            status = int(result.stdout.strip())
            if status == 200:
                findings.append({"endpoint": ep, "status": status, "risk": "high"})
            else:
                findings.append({"endpoint": ep, "status": status, "risk": "none"})
        except (subprocess.TimeoutExpired, ValueError):
            findings.append({"endpoint": ep, "error": "timeout"})
    return {
        "status": "ok",
        "test": "unauthenticated_access",
        "exposed": [f for f in findings if f.get("risk") == "high"],
        "total_tested": len(endpoints),
    }


def test_token_after_logout(url: str, token: str) -> dict[str, Any]:
    """Test if token remains valid after logout."""
    logout_cmd = [
        "curl",
        "-s",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "-X",
        "POST",
        f"{url}/logout",
        "-H",
        f"Authorization: Bearer {token}",
    ]
    reuse_cmd = [
        "curl",
        "-s",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "-H",
        f"Authorization: Bearer {token}",
        url,
    ]
    try:
        subprocess.run(logout_cmd, capture_output=True, text=True, timeout=10)
        result = subprocess.run(reuse_cmd, capture_output=True, text=True, timeout=10)
        reuse_status = int(result.stdout.strip())
        return {
            "status": "ok",
            "test": "token_reuse_after_logout",
            "token_still_valid": reuse_status == 200,
            "reuse_status": reuse_status,
            "risk": "high" if reuse_status == 200 else "none",
        }
    except (subprocess.TimeoutExpired, ValueError):
        return {"error": "Request timed out"}


def main() -> None:
    parser = argparse.ArgumentParser(description="API authentication flaw analyzer")
    parser.add_argument("--url", help="Target API URL")
    parser.add_argument("--jwt", help="JWT token to analyze")
    parser.add_argument("--decode", action="store_true", help="Decode JWT")
    parser.add_argument("--analyze", action="store_true", help="Full JWT analysis")
    parser.add_argument("--unauthenticated-scan", action="store_true")
    parser.add_argument("--test-logout", action="store_true")
    parser.add_argument("--format", choices=["json", "text"], default="json")
    args = parser.parse_args()

    if args.decode and args.jwt:
        result = decode_jwt(args.jwt)
    elif args.analyze and args.jwt:
        result = decode_jwt(args.jwt)
    elif args.unauthenticated_scan and args.url:
        result = test_unauthenticated(args.url)
    elif args.test_logout and args.url and args.jwt:
        result = test_token_after_logout(args.url, args.jwt)
    else:
        parser.error(
            "Use --decode/--analyze with --jwt, or --unauthenticated-scan with --url"
        )
        return

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
