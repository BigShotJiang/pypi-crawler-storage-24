<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->

# API Gateway Hardening Reference

Configuration patterns for Kong, AWS API Gateway, Azure APIM, and custom gateways.

## Authentication
- OAuth2/OIDC for user-facing APIs
- mTLS for service-to-service
- API keys only as secondary identifier (not sole auth)

## Rate Limiting
- Per-user rate limits (not just per-IP)
- Sliding window algorithm (not fixed window)
- Progressive backoff (429 → temp ban → permanent ban)
- Separate limits for read vs. write operations

## Input Validation
- JSON Schema validation on all request bodies
- Maximum request size limits
- Query parameter type checking
- GraphQL query depth and complexity limits

## Response Security
- Field-level filtering (allowlist response fields per scope)
- Remove internal headers (X-Powered-By, Server version)
- CORS: specific origins only (never wildcard for authenticated APIs)
- Content-Type enforcement
