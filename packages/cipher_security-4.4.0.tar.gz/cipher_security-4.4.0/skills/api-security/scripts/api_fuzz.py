#!/usr/bin/env python3
"""API endpoint security fuzzer — tests for common API vulnerabilities.

Checks BOLA/IDOR, authentication bypass, injection, and header issues.

Usage:
  python3 scripts/api_fuzz.py --url https://api.example.com/v1
  python3 scripts/api_fuzz.py --url https://api.example.com --endpoints endpoints.txt
"""

import argparse
import json
import sys
import urllib.request
import urllib.error

HEADER_CHECKS = [
    ("X-Content-Type-Options", "nosniff", "Missing X-Content-Type-Options"),
    ("X-Frame-Options", None, "Missing X-Frame-Options"),
    ("Strict-Transport-Security", None, "Missing HSTS header"),
    ("Content-Security-Policy", None, "Missing CSP header"),
]

INJECTION_PAYLOADS = [
    {"name": "SQL injection", "payload": "' OR '1'='1"},
    {"name": "NoSQL injection", "payload": '{"$gt":""}'},
    {"name": "XSS probe", "payload": "<script>alert(1)</script>"},
    {"name": "Path traversal", "payload": "../../etc/passwd"},
    {"name": "SSRF probe", "payload": "http://169.254.169.254/latest/meta-data/"},
]


def check_headers(url: str, headers: dict) -> list[dict]:
    findings = []
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp_headers = dict(resp.headers)
            for header, expected, msg in HEADER_CHECKS:
                value = resp_headers.get(header)
                if not value:
                    findings.append({"level": "warning", "msg": msg})
                elif expected and expected not in value:
                    findings.append(
                        {
                            "level": "warning",
                            "msg": f"{header}: expected '{expected}', got '{value}'",
                        }
                    )

            # Check for information disclosure
            server = resp_headers.get("Server", "")
            if server and any(
                v in server.lower() for v in ["apache", "nginx", "express", "iis"]
            ):
                findings.append(
                    {"level": "info", "msg": f"Server header discloses: {server}"}
                )

            # Check CORS
            cors = resp_headers.get("Access-Control-Allow-Origin", "")
            if cors == "*":
                findings.append(
                    {"level": "warning", "msg": "CORS allows all origins (*)"}
                )

    except urllib.error.HTTPError as e:
        findings.append({"level": "info", "msg": f"HTTP {e.code}: {e.reason}"})
    except Exception as e:
        findings.append({"level": "error", "msg": f"Request failed: {e}"})

    return findings


def check_idor(url: str, headers: dict) -> list[dict]:
    """Test for IDOR by incrementing numeric path segments."""
    findings = []
    import re

    # Find numeric IDs in URL
    ids = re.findall(r"/(\d+)", url)
    for original_id in ids:
        test_id = str(int(original_id) + 1)
        test_url = url.replace(f"/{original_id}", f"/{test_id}", 1)
        req = urllib.request.Request(test_url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status == 200:
                    findings.append(
                        {
                            "level": "warning",
                            "msg": f"Possible IDOR: {test_url} returned 200",
                        }
                    )
        except urllib.error.HTTPError:
            pass
        except Exception:
            pass
    return findings


def main():
    parser = argparse.ArgumentParser(description="API security fuzzer")
    parser.add_argument("--url", required=True, help="Base API URL")
    parser.add_argument(
        "--header", action="append", default=[], help="Headers (key: value)"
    )
    parser.add_argument("--endpoints", help="File with endpoint paths")
    args = parser.parse_args()

    headers = {"User-Agent": "CIPHER-API-Fuzzer/1.0"}
    for h in args.header:
        k, v = h.split(":", 1)
        headers[k.strip()] = v.strip()

    endpoints = [args.url]
    if args.endpoints:
        with open(args.endpoints) as f:
            endpoints.extend(
                args.url.rstrip("/") + "/" + line.strip().lstrip("/")
                for line in f
                if line.strip()
            )

    print(f"=== API Security Scan: {args.url} ===")
    print(f"Endpoints: {len(endpoints)}\n")

    all_findings = []
    for ep in endpoints:
        print(f"--- {ep} ---")
        findings = check_headers(ep, headers)
        findings.extend(check_idor(ep, headers))
        all_findings.extend(findings)
        for f in findings:
            icon = {
                "critical": "🔴",
                "warning": "⚠️",
                "info": "ℹ️",
                "error": "🔴",
                "ok": "✅",
            }.get(f["level"], "")
            print(f"  {icon} {f['msg']}")

    critical = sum(1 for f in all_findings if f["level"] in ("critical", "error"))
    warnings = sum(1 for f in all_findings if f["level"] == "warning")
    print(f"\n=== Summary: {critical} critical, {warnings} warnings ===")

    result = {
        "url": args.url,
        "endpoints_scanned": len(endpoints),
        "findings": all_findings,
        "summary": {"critical": critical, "warnings": warnings},
    }
    return result


if __name__ == "__main__":
    result = main()
    print(json.dumps(result, indent=2))
    sys.exit(1 if result["summary"]["critical"] else 0)
