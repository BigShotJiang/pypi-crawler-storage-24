# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""CIPHER SARIF Output — Static Analysis Results Interchange Format.

Converts CIPHER scan findings into SARIF v2.1.0 for CI/CD integration
(GitHub Advanced Security, Azure DevOps, GitLab SAST, etc.).
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

_SARIF_VERSION = "2.1.0"
_SARIF_SCHEMA = "https://docs.oasis-open.org/sarif/sarif/v2.1.0/errata01/os/schemas/sarif-schema-2.1.0.json"


@dataclass
class SarifRule:
    """A SARIF reporting descriptor (rule)."""

    id: str
    name: str
    short_description: str = ""
    full_description: str = ""
    help_uri: str = ""
    level: str = "warning"  # error, warning, note, none
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        rule: dict[str, Any] = {
            "id": self.id,
            "name": self.name,
            "shortDescription": {"text": self.short_description or self.name},
        }
        if self.full_description:
            rule["fullDescription"] = {"text": self.full_description}
        if self.help_uri:
            rule["helpUri"] = self.help_uri
        rule["defaultConfiguration"] = {"level": self.level}
        if self.tags:
            rule["properties"] = {"tags": self.tags}
        return rule


@dataclass
class SarifResult:
    """A single SARIF result (finding)."""

    rule_id: str
    message: str
    level: str = "warning"
    uri: str = ""
    start_line: int = 0
    start_column: int = 0
    end_line: int = 0
    snippet: str = ""
    fingerprint: str = ""
    properties: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "ruleId": self.rule_id,
            "level": self.level,
            "message": {"text": self.message},
        }
        if self.uri or self.start_line:
            location: dict[str, Any] = {}
            if self.uri:
                location["physicalLocation"] = {
                    "artifactLocation": {"uri": self.uri},
                }
                if self.start_line:
                    region: dict[str, Any] = {"startLine": self.start_line}
                    if self.start_column:
                        region["startColumn"] = self.start_column
                    if self.end_line:
                        region["endLine"] = self.end_line
                    if self.snippet:
                        region["snippet"] = {"text": self.snippet}
                    location["physicalLocation"]["region"] = region
            result["locations"] = [location]
        if self.fingerprint:
            result["fingerprints"] = {"cipher/v1": self.fingerprint}
        if self.properties:
            result["properties"] = self.properties
        return result


class SarifReport:
    """Build a SARIF v2.1.0 report from CIPHER findings."""

    def __init__(
        self,
        tool_name: str = "CIPHER",
        tool_version: str = "4.2.0",
        tool_uri: str = "https://github.com/defconxt/CIPHER",
    ) -> None:
        self.tool_name = tool_name
        self.tool_version = tool_version
        self.tool_uri = tool_uri
        self._rules: dict[str, SarifRule] = {}
        self._results: list[SarifResult] = []
        self._invocation_start = datetime.now(timezone.utc).isoformat()

    def add_rule(self, rule: SarifRule) -> None:
        """Register a rule (deduplicates by ID)."""
        self._rules[rule.id] = rule

    def add_result(self, result: SarifResult) -> None:
        """Add a finding result."""
        self._results.append(result)

    def add_finding(self, finding: dict[str, Any]) -> None:
        """Convert a CIPHER finding dict to SARIF rule + result.

        Expected keys: template_id, name, description, severity, host,
                       matched_at, tags, cve_ids, reference
        """
        rule_id = finding.get("template_id", finding.get("id", str(uuid.uuid4())[:8]))
        severity = finding.get("severity", "medium").lower()
        level = _severity_to_level(severity)

        # Auto-register rule
        if rule_id not in self._rules:
            self.add_rule(
                SarifRule(
                    id=rule_id,
                    name=finding.get("name", rule_id),
                    short_description=finding.get("description", ""),
                    level=level,
                    tags=finding.get("tags", []),
                    help_uri=finding.get("reference", ""),
                )
            )

        # Build result
        props: dict[str, Any] = {}
        if finding.get("cve_ids"):
            props["cve"] = finding["cve_ids"]
        if finding.get("severity"):
            props["security-severity"] = _severity_score(severity)

        self.add_result(
            SarifResult(
                rule_id=rule_id,
                message=f"{finding.get('name', 'Finding')} at {finding.get('host', finding.get('matched_at', 'unknown'))}",
                level=level,
                uri=finding.get("matched_at", finding.get("host", "")),
                properties=props,
            )
        )

    def add_diff_finding(self, finding: dict[str, Any]) -> None:
        """Convert a CIPHER diff analysis finding to SARIF.

        Expected keys: type, severity, file, line, description, snippet
        """
        rule_id = f"cipher-diff-{finding.get('type', 'generic')}"
        severity = finding.get("severity", "medium").lower()
        level = _severity_to_level(severity)

        if rule_id not in self._rules:
            self.add_rule(
                SarifRule(
                    id=rule_id,
                    name=f"Security Diff: {finding.get('type', 'issue')}",
                    short_description=finding.get(
                        "description", "Security-relevant code change detected"
                    ),
                    level=level,
                    tags=["security", "diff-analysis"],
                )
            )

        self.add_result(
            SarifResult(
                rule_id=rule_id,
                message=finding.get("description", "Security-relevant change"),
                level=level,
                uri=finding.get("file", ""),
                start_line=finding.get("line", 0),
                snippet=finding.get("snippet", ""),
                properties={"security-severity": _severity_score(severity)},
            )
        )

    def to_dict(self) -> dict[str, Any]:
        """Build the complete SARIF JSON structure."""
        run: dict[str, Any] = {
            "tool": {
                "driver": {
                    "name": self.tool_name,
                    "version": self.tool_version,
                    "informationUri": self.tool_uri,
                    "rules": [r.to_dict() for r in self._rules.values()],
                },
            },
            "invocations": [
                {
                    "executionSuccessful": True,
                    "startTimeUtc": self._invocation_start,
                    "endTimeUtc": datetime.now(timezone.utc).isoformat(),
                }
            ],
            "results": [r.to_dict() for r in self._results],
        }

        return {
            "$schema": _SARIF_SCHEMA,
            "version": _SARIF_VERSION,
            "runs": [run],
        }

    def to_json(self, indent: int = 2) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def write(self, path: str) -> str:
        """Write SARIF to file and return the path."""
        from pathlib import Path

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.to_json())
        return str(p)

    @property
    def result_count(self) -> int:
        return len(self._results)

    @property
    def rule_count(self) -> int:
        return len(self._rules)

    def summary(self) -> dict[str, Any]:
        """Return a summary of the report."""
        by_level: dict[str, int] = {}
        for r in self._results:
            by_level[r.level] = by_level.get(r.level, 0) + 1
        return {
            "rules": self.rule_count,
            "results": self.result_count,
            "by_level": by_level,
        }


def _severity_to_level(severity: str) -> str:
    """Map CIPHER severity to SARIF level."""
    return {
        "critical": "error",
        "high": "error",
        "medium": "warning",
        "low": "note",
        "info": "note",
    }.get(severity, "warning")


def _severity_score(severity: str) -> str:
    """Map CIPHER severity to GitHub security-severity score."""
    return {
        "critical": "9.5",
        "high": "8.0",
        "medium": "5.5",
        "low": "3.0",
        "info": "1.0",
    }.get(severity, "5.0")
