# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""Pure-Python ELF binary analysis — no pwntools, no external dependencies.

Provides:
- ELF header parsing (arch, entry point, type, endianness)
- Section enumeration (names, sizes, permissions)
- Symbol table extraction (imports/exports)
- Security feature detection (NX, PIE, RELRO, stack canaries, RPATH)
- Format string vulnerability pattern detection in source code
- Suspicious binary indicators (packed, stripped, UPX)
"""

from __future__ import annotations

import re
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# ELF constants
# ---------------------------------------------------------------------------
ELF_MAGIC = b"\x7fELF"

# e_ident offsets
EI_CLASS = 4
EI_DATA = 5
EI_OSABI = 7

# ELF classes
ELFCLASS32 = 1
ELFCLASS64 = 2
_CLASS_NAMES = {ELFCLASS32: "ELF32", ELFCLASS64: "ELF64"}

# Data encoding
ELFDATA2LSB = 1
ELFDATA2MSB = 2
_ENDIAN_NAMES = {ELFDATA2LSB: "little-endian", ELFDATA2MSB: "big-endian"}

# Object file types
ET_EXEC = 2
ET_DYN = 3
_TYPE_NAMES = {0: "NONE", 1: "REL", ET_EXEC: "EXEC", ET_DYN: "DYN", 4: "CORE"}

# Machine types
_MACHINE_NAMES = {
    0: "NONE",
    3: "x86",
    8: "MIPS",
    20: "PowerPC",
    40: "ARM",
    43: "SPARC v9",
    62: "x86-64",
    183: "AArch64",
    243: "RISC-V",
}

# Section types
SHT_SYMTAB = 2
SHT_STRTAB = 3
SHT_DYNSYM = 11
SHT_GNU_HASH = 0x6FFFFFF6

# Program header types
PT_LOAD = 1
PT_DYNAMIC = 2
PT_INTERP = 3
PT_GNU_RELRO = 0x6474E552
PT_GNU_STACK = 0x6474E551

# Dynamic tags
DT_NEEDED = 1
DT_RPATH = 15
DT_RUNPATH = 29
DT_FLAGS = 30
DT_FLAGS_1 = 0x6FFFFFFB
DF_BIND_NOW = 0x8
DF_1_NOW = 0x1
DF_1_PIE = 0x08000000

# Section header flags
SHF_WRITE = 0x1
SHF_ALLOC = 0x2
SHF_EXECINSTR = 0x4


@dataclass
class ELFSection:
    """Parsed ELF section header."""

    name: str
    type_id: int
    flags: int
    addr: int
    offset: int
    size: int
    link: int = 0
    info: int = 0
    entsize: int = 0

    @property
    def is_executable(self) -> bool:
        return bool(self.flags & SHF_EXECINSTR)

    @property
    def is_writable(self) -> bool:
        return bool(self.flags & SHF_WRITE)

    @property
    def permissions(self) -> str:
        r = "R" if self.flags & SHF_ALLOC else "-"
        w = "W" if self.flags & SHF_WRITE else "-"
        x = "X" if self.flags & SHF_EXECINSTR else "-"
        return f"{r}{w}{x}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "size": self.size,
            "permissions": self.permissions,
            "address": hex(self.addr),
        }


@dataclass
class ELFSymbol:
    """Parsed ELF symbol."""

    name: str
    value: int
    size: int
    bind: str  # LOCAL, GLOBAL, WEAK
    type: str  # FUNC, OBJECT, NOTYPE
    section_index: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "value": hex(self.value),
            "bind": self.bind,
            "type": self.type,
        }


@dataclass
class SecurityFeatures:
    """Binary security features (hardening checks)."""

    nx: bool = False  # Non-executable stack
    pie: bool = False  # Position Independent Executable
    relro: str = "none"  # none, partial, full
    canary: bool = False  # Stack canary (__stack_chk_fail)
    fortify: bool = False  # FORTIFY_SOURCE (__*_chk functions)
    rpath: bool = False  # Hardcoded RPATH (dangerous)
    runpath: bool = False  # RUNPATH set
    stripped: bool = False  # Symbol table stripped

    def to_dict(self) -> dict[str, Any]:
        return {
            "NX": self.nx,
            "PIE": self.pie,
            "RELRO": self.relro,
            "Canary": self.canary,
            "Fortify": self.fortify,
            "RPATH": self.rpath,
            "Stripped": self.stripped,
        }

    @property
    def score(self) -> int:
        """Hardening score 0-100."""
        s = 0
        if self.nx:
            s += 20
        if self.pie:
            s += 20
        if self.relro == "full":
            s += 20
        elif self.relro == "partial":
            s += 10
        if self.canary:
            s += 20
        if self.fortify:
            s += 10
        if not self.rpath:
            s += 10
        return min(s, 100)


@dataclass
class ELFAnalysis:
    """Complete ELF analysis result."""

    filename: str
    elf_class: str = ""  # ELF32 / ELF64
    endianness: str = ""  # little-endian / big-endian
    elf_type: str = ""  # EXEC / DYN
    machine: str = ""  # x86-64, ARM, etc.
    entry_point: int = 0
    sections: list[ELFSection] = field(default_factory=list)
    symbols: list[ELFSymbol] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    libraries: list[str] = field(default_factory=list)
    security: SecurityFeatures = field(default_factory=SecurityFeatures)
    suspicious: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "filename": self.filename,
            "class": self.elf_class,
            "endianness": self.endianness,
            "type": self.elf_type,
            "machine": self.machine,
            "entry_point": hex(self.entry_point),
            "sections": len(self.sections),
            "symbols": len(self.symbols),
            "imports": self.imports[:50],
            "libraries": self.libraries,
            "security": self.security.to_dict(),
            "hardening_score": self.security.score,
            "suspicious": self.suspicious,
            "errors": self.errors,
        }


def _read_str(data: bytes, offset: int) -> str:
    """Read null-terminated string from bytes."""
    end = data.find(b"\x00", offset)
    if end < 0:
        return ""
    return data[offset:end].decode("ascii", errors="replace")


class ELFParser:
    """Pure-Python ELF parser using only the struct module."""

    def parse(self, filepath: str | Path) -> ELFAnalysis:
        """Parse an ELF binary and return full analysis."""
        path = Path(filepath)
        result = ELFAnalysis(filename=str(path))

        try:
            data = path.read_bytes()
        except OSError as exc:
            result.errors.append(f"Cannot read file: {exc}")
            return result

        if len(data) < 64:
            result.errors.append("File too small to be an ELF binary")
            return result

        if data[:4] != ELF_MAGIC:
            result.errors.append("Not an ELF file (bad magic bytes)")
            return result

        # Check for UPX packing
        if b"UPX!" in data[:4096]:
            result.suspicious.append("UPX-packed binary")

        ei_class = data[EI_CLASS]
        ei_data = data[EI_DATA]
        result.elf_class = _CLASS_NAMES.get(ei_class, f"unknown({ei_class})")
        result.endianness = _ENDIAN_NAMES.get(ei_data, f"unknown({ei_data})")

        is_64 = ei_class == ELFCLASS64
        endian = "<" if ei_data == ELFDATA2LSB else ">"

        try:
            self._parse_header(data, result, is_64, endian)
            self._parse_sections(data, result, is_64, endian)
            self._parse_program_headers(data, result, is_64, endian)
            self._check_security(result, data)
            self._detect_suspicious(result, data)
        except (struct.error, IndexError, ValueError) as exc:
            result.errors.append(f"Parse error: {exc}")

        return result

    def _parse_header(
        self, data: bytes, result: ELFAnalysis, is_64: bool, endian: str
    ) -> None:
        if is_64:
            fmt = f"{endian}HHI QQQ IHH HHH"
            hdr = struct.unpack_from(fmt, data, 16)
        else:
            fmt = f"{endian}HHI III IHH HHH"
            hdr = struct.unpack_from(fmt, data, 16)
        result.elf_type = _TYPE_NAMES.get(hdr[0], f"unknown({hdr[0]})")
        result.machine = _MACHINE_NAMES.get(hdr[1], f"unknown({hdr[1]})")
        result.entry_point = hdr[3]

    def _parse_sections(
        self, data: bytes, result: ELFAnalysis, is_64: bool, endian: str
    ) -> None:
        # Get section header table offset, entry size, count, and strtab index
        if is_64:
            e_shoff = struct.unpack_from(f"{endian}Q", data, 40)[0]
            e_shentsize = struct.unpack_from(f"{endian}H", data, 58)[0]
            e_shnum = struct.unpack_from(f"{endian}H", data, 60)[0]
            e_shstrndx = struct.unpack_from(f"{endian}H", data, 62)[0]
        else:
            e_shoff = struct.unpack_from(f"{endian}I", data, 32)[0]
            e_shentsize = struct.unpack_from(f"{endian}H", data, 46)[0]
            e_shnum = struct.unpack_from(f"{endian}H", data, 48)[0]
            e_shstrndx = struct.unpack_from(f"{endian}H", data, 50)[0]

        if e_shoff == 0 or e_shnum == 0:
            return

        # Read section header string table
        shstrtab_off = e_shoff + e_shstrndx * e_shentsize
        if is_64:
            strtab_offset = struct.unpack_from(f"{endian}Q", data, shstrtab_off + 24)[0]
            strtab_size = struct.unpack_from(f"{endian}Q", data, shstrtab_off + 32)[0]
        else:
            strtab_offset = struct.unpack_from(f"{endian}I", data, shstrtab_off + 16)[0]
            strtab_size = struct.unpack_from(f"{endian}I", data, shstrtab_off + 20)[0]

        strtab = data[strtab_offset : strtab_offset + strtab_size]

        for i in range(e_shnum):
            off = e_shoff + i * e_shentsize
            if is_64:
                sh = struct.unpack_from(f"{endian}II QQQQ II QQ", data, off)
                sec = ELFSection(
                    name=_read_str(strtab, sh[0]),
                    type_id=sh[1],
                    flags=sh[2],
                    addr=sh[3],
                    offset=sh[4],
                    size=sh[5],
                    link=sh[6],
                    info=sh[7],
                    entsize=sh[9],
                )
            else:
                sh = struct.unpack_from(f"{endian}II IIII II II", data, off)
                sec = ELFSection(
                    name=_read_str(strtab, sh[0]),
                    type_id=sh[1],
                    flags=sh[2],
                    addr=sh[3],
                    offset=sh[4],
                    size=sh[5],
                    link=sh[6],
                    info=sh[7],
                    entsize=sh[9],
                )
            result.sections.append(sec)

            # Extract symbols from .dynsym
            if sec.type_id == SHT_DYNSYM and sec.entsize > 0:
                self._parse_symbols(data, sec, result, is_64, endian)

    def _parse_symbols(
        self,
        data: bytes,
        sec: ELFSection,
        result: ELFAnalysis,
        is_64: bool,
        endian: str,
    ) -> None:
        # Find associated strtab
        strtab_sec = None
        for s in result.sections:
            if s.type_id == SHT_STRTAB and s.name == ".dynstr":
                strtab_sec = s
                break
        if not strtab_sec:
            return

        sym_strtab = data[strtab_sec.offset : strtab_sec.offset + strtab_sec.size]
        n_syms = sec.size // sec.entsize if sec.entsize else 0
        bind_names = {0: "LOCAL", 1: "GLOBAL", 2: "WEAK"}
        type_names = {0: "NOTYPE", 1: "OBJECT", 2: "FUNC", 10: "IFUNC"}

        for i in range(n_syms):
            off = sec.offset + i * sec.entsize
            if is_64:
                st = struct.unpack_from(f"{endian}I BBH Q Q", data, off)
                name_idx, info, _, shndx, value, size = st
            else:
                st = struct.unpack_from(f"{endian}I I I BBH", data, off)
                name_idx, value, size, info, _, shndx = st

            name = _read_str(sym_strtab, name_idx)
            if not name:
                continue
            bind = bind_names.get(info >> 4, "OTHER")
            stype = type_names.get(info & 0xF, "OTHER")
            sym = ELFSymbol(
                name=name,
                value=value,
                size=size,
                bind=bind,
                type=stype,
                section_index=shndx,
            )
            result.symbols.append(sym)

            if shndx == 0 and stype == "FUNC":
                result.imports.append(name)

    def _parse_program_headers(
        self, data: bytes, result: ELFAnalysis, is_64: bool, endian: str
    ) -> None:
        if is_64:
            e_phoff = struct.unpack_from(f"{endian}Q", data, 32)[0]
            e_phentsize = struct.unpack_from(f"{endian}H", data, 54)[0]
            e_phnum = struct.unpack_from(f"{endian}H", data, 56)[0]
        else:
            e_phoff = struct.unpack_from(f"{endian}I", data, 28)[0]
            e_phentsize = struct.unpack_from(f"{endian}H", data, 42)[0]
            e_phnum = struct.unpack_from(f"{endian}H", data, 44)[0]

        if e_phoff == 0 or e_phnum == 0:
            return

        for i in range(e_phnum):
            off = e_phoff + i * e_phentsize
            if is_64:
                p_type, p_flags = struct.unpack_from(f"{endian}II", data, off)
                p_offset = struct.unpack_from(f"{endian}Q", data, off + 8)[0]
                p_filesz = struct.unpack_from(f"{endian}Q", data, off + 32)[0]
            else:
                p_type = struct.unpack_from(f"{endian}I", data, off)[0]
                p_offset = struct.unpack_from(f"{endian}I", data, off + 4)[0]
                p_filesz = struct.unpack_from(f"{endian}I", data, off + 16)[0]
                p_flags = struct.unpack_from(f"{endian}I", data, off + 24)[0]

            if p_type == PT_GNU_STACK:
                result.security.nx = not bool(p_flags & 0x1)
            elif p_type == PT_GNU_RELRO:
                result.security.relro = "partial"
            elif p_type == PT_INTERP:
                interp = data[p_offset : p_offset + p_filesz].rstrip(b"\x00")
                result.suspicious.append(
                    f"interpreter: {interp.decode('ascii', errors='replace')}"
                )
            elif p_type == PT_DYNAMIC:
                self._parse_dynamic(data, p_offset, p_filesz, result, is_64, endian)

    def _parse_dynamic(
        self,
        data: bytes,
        offset: int,
        size: int,
        result: ELFAnalysis,
        is_64: bool,
        endian: str,
    ) -> None:
        # Find .dynstr for library name resolution
        dynstr = b""
        for sec in result.sections:
            if sec.name == ".dynstr":
                dynstr = data[sec.offset : sec.offset + sec.size]
                break

        entry_size = 16 if is_64 else 8
        n_entries = size // entry_size
        bind_now = False

        for i in range(n_entries):
            ent_off = offset + i * entry_size
            if is_64:
                d_tag, d_val = struct.unpack_from(f"{endian}qQ", data, ent_off)
            else:
                d_tag, d_val = struct.unpack_from(f"{endian}iI", data, ent_off)

            if d_tag == 0:
                break
            elif d_tag == DT_NEEDED and dynstr:
                result.libraries.append(_read_str(dynstr, d_val))
            elif d_tag == DT_RPATH:
                result.security.rpath = True
            elif d_tag == DT_RUNPATH:
                result.security.runpath = True
            elif d_tag == DT_FLAGS and (d_val & DF_BIND_NOW):
                bind_now = True
            elif d_tag == DT_FLAGS_1:
                if d_val & DF_1_NOW:
                    bind_now = True
                if d_val & DF_1_PIE:
                    result.security.pie = True

        if bind_now and result.security.relro == "partial":
            result.security.relro = "full"

    def _check_security(self, result: ELFAnalysis, data: bytes) -> None:
        # PIE heuristic: DYN type + entry != 0
        if result.elf_type == "DYN" and result.entry_point != 0:
            result.security.pie = True

        # Stack canary: check for __stack_chk_fail import
        for sym in result.symbols:
            if "__stack_chk_fail" in sym.name:
                result.security.canary = True
            if "_chk" in sym.name and sym.name.startswith("__"):
                result.security.fortify = True

        # Stripped: no .symtab section
        has_symtab = any(s.name == ".symtab" for s in result.sections)
        result.security.stripped = not has_symtab

    def _detect_suspicious(self, result: ELFAnalysis, data: bytes) -> None:
        # Check for common packer signatures
        section_names = {s.name for s in result.sections}
        if ".upx0" in section_names or ".upx1" in section_names:
            result.suspicious.append("UPX-packed (section names)")
        if not section_names - {"", ".shstrtab"}:
            result.suspicious.append("All sections stripped — possibly packed")

        # W+X sections (writable and executable = suspicious)
        for sec in result.sections:
            if sec.is_writable and sec.is_executable and sec.name:
                result.suspicious.append(f"W+X section: {sec.name} ({sec.size} bytes)")

        # Anti-debug imports
        antidebug_funcs = {"ptrace", "prctl", "getppid", "isDebuggerPresent"}
        for imp in result.imports:
            if imp in antidebug_funcs:
                result.suspicious.append(f"Anti-debug function: {imp}")


# ---------------------------------------------------------------------------
# Format String Vulnerability Detector (source code analysis)
# ---------------------------------------------------------------------------

_PRINTF_FAMILY = re.compile(
    r"\b(s?n?printf|fprintf|vprintf|vsprintf|vsnprintf|vfprintf|syslog|err|errx|warn|warnx)"
    r"\s*\(",
    re.IGNORECASE,
)

_SAFE_FORMAT = re.compile(r'"\s*$|"\s*,')  # Ends with string literal = safe


@dataclass
class FormatStringFinding:
    """A potential format string vulnerability."""

    file: str
    line_number: int
    line_content: str
    function: str
    severity: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "file": self.file,
            "line": self.line_number,
            "function": self.function,
            "severity": self.severity,
            "reason": self.reason,
            "content": self.line_content.strip()[:200],
        }


class FormatStringScanner:
    """Detect format string vulnerabilities in C/C++ source code."""

    _EXTENSIONS = {".c", ".h", ".cpp", ".cc", ".cxx", ".hpp"}

    def scan_file(self, filepath: str | Path) -> list[FormatStringFinding]:
        """Scan a source file for format string vulnerabilities."""
        path = Path(filepath)
        if path.suffix.lower() not in self._EXTENSIONS:
            return []
        try:
            lines = path.read_text(errors="replace").splitlines()
        except OSError:
            return []

        findings: list[FormatStringFinding] = []
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("//") or stripped.startswith("/*"):
                continue
            m = _PRINTF_FAMILY.search(line)
            if not m:
                continue
            func = m.group(1)
            after = line[m.end() :]
            # Check if first argument is a variable (not a string literal)
            after_stripped = after.lstrip()
            if after_stripped.startswith('"'):
                continue  # String literal format = safe
            if after_stripped.startswith("'"):
                continue
            # Variable as format string — dangerous
            severity = (
                "critical" if func in ("printf", "sprintf", "fprintf") else "high"
            )
            findings.append(
                FormatStringFinding(
                    file=str(path),
                    line_number=i,
                    line_content=line,
                    function=func,
                    severity=severity,
                    reason=f"Variable passed as format string to {func}()",
                )
            )
        return findings

    def scan_directory(self, directory: str | Path) -> list[FormatStringFinding]:
        """Scan directory recursively for format string vulnerabilities."""
        root = Path(directory)
        findings: list[FormatStringFinding] = []
        for path in sorted(root.rglob("*")):
            if path.is_file() and path.suffix.lower() in self._EXTENSIONS:
                findings.extend(self.scan_file(path))
        return findings


# ---------------------------------------------------------------------------
# ROP Gadget Scanner (requires capstone)
# ---------------------------------------------------------------------------


@dataclass
class ROPGadget:
    """A single ROP gadget."""

    address: int
    instructions: str
    bytes_hex: str
    length: int  # number of instructions

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "instructions": self.instructions,
            "bytes": self.bytes_hex,
            "length": self.length,
        }


class ROPScanner:
    """Find ROP gadgets in ELF binaries using capstone disassembly.

    Scans executable sections backwards from gadget-ending instructions
    (ret, syscall, int 0x80) to find usable instruction sequences.
    Requires: ``pip install capstone``
    """

    # Max bytes to search backwards from a gadget-ending instruction
    MAX_GADGET_BYTES = 20
    # Max instructions per gadget
    MAX_GADGET_INSNS = 6

    def __init__(self) -> None:
        self._available = False
        try:
            from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_MODE_32

            self._Cs = Cs
            self._CS_ARCH_X86 = CS_ARCH_X86
            self._CS_MODE_64 = CS_MODE_64
            self._CS_MODE_32 = CS_MODE_32
            self._available = True
        except ImportError:
            pass

    @property
    def available(self) -> bool:
        return self._available

    def scan(
        self, filepath: str | Path, arch: str = "x86-64", max_gadgets: int = 200
    ) -> list[ROPGadget]:
        """Scan an ELF binary for ROP gadgets.

        Args:
            filepath: Path to ELF binary.
            arch: Architecture — "x86-64" or "x86".
            max_gadgets: Maximum gadgets to return.

        Returns:
            List of ROPGadget objects sorted by address.
        """
        if not self._available:
            return []

        path = Path(filepath)
        try:
            data = path.read_bytes()
        except OSError:
            return []

        if data[:4] != ELF_MAGIC:
            return []

        # Parse to find executable sections
        parser = ELFParser()
        analysis = parser.parse(filepath)

        # Set up disassembler
        if arch == "x86":
            md = self._Cs(self._CS_ARCH_X86, self._CS_MODE_32)
        else:
            md = self._Cs(self._CS_ARCH_X86, self._CS_MODE_64)
        md.detail = False

        # Gadget-ending bytes
        endings = {
            b"\xc3": "ret",  # ret
            b"\xc2": "ret imm",  # ret imm16
            b"\x0f\x05": "syscall",  # syscall
            b"\xcd\x80": "int 0x80",  # int 0x80
        }

        gadgets: list[ROPGadget] = []
        seen: set[str] = set()

        for section in analysis.sections:
            if not section.is_executable or section.size == 0:
                continue

            sec_data = data[section.offset : section.offset + section.size]
            sec_base = section.addr

            for end_bytes, end_name in endings.items():
                elen = len(end_bytes)
                # Find all occurrences of ending bytes in section
                pos = 0
                while pos < len(sec_data):
                    idx = sec_data.find(end_bytes, pos)
                    if idx < 0:
                        break
                    pos = idx + 1

                    # Search backwards for gadgets
                    for back in range(1, self.MAX_GADGET_BYTES + 1):
                        start = idx - back
                        if start < 0:
                            break
                        gadget_bytes = sec_data[start : idx + elen]
                        gadget_addr = sec_base + start

                        # Disassemble
                        insns = list(md.disasm(gadget_bytes, gadget_addr))
                        if not insns:
                            continue

                        # Verify the gadget ends at the right place
                        last = insns[-1]
                        if last.address + last.size != sec_base + idx + elen:
                            continue

                        # Verify last instruction is the expected ending
                        if end_name == "ret" and last.mnemonic != "ret":
                            continue
                        if end_name == "syscall" and last.mnemonic != "syscall":
                            continue
                        if end_name == "int 0x80" and last.mnemonic != "int":
                            continue

                        if len(insns) > self.MAX_GADGET_INSNS:
                            continue
                        if len(insns) < 2:
                            continue  # Single ret isn't useful

                        insn_str = " ; ".join(
                            f"{i.mnemonic} {i.op_str}".strip() for i in insns
                        )
                        if insn_str in seen:
                            continue
                        seen.add(insn_str)

                        gadgets.append(
                            ROPGadget(
                                address=gadget_addr,
                                instructions=insn_str,
                                bytes_hex=gadget_bytes.hex(),
                                length=len(insns),
                            )
                        )

                        if len(gadgets) >= max_gadgets:
                            return sorted(gadgets, key=lambda g: g.address)

        return sorted(gadgets, key=lambda g: g.address)

    def find_gadgets_by_pattern(
        self, filepath: str | Path, pattern: str, arch: str = "x86-64"
    ) -> list[ROPGadget]:
        """Find gadgets matching an instruction pattern (regex).

        Example: ``find_gadgets_by_pattern(elf, r"pop rdi.*ret")``
        """
        all_gadgets = self.scan(filepath, arch=arch, max_gadgets=1000)
        compiled = re.compile(pattern, re.IGNORECASE)
        return [g for g in all_gadgets if compiled.search(g.instructions)]
