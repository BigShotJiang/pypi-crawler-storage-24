<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: cipher-engagement-pipeline
description: >-
  Structured multi-stage engagement pipeline for security assessments. Provides
  repeatable methodology with quality gates, evidence requirements, and deliverable
  templates. Supports penetration testing, red team, vulnerability assessment,
  security architecture review, and incident response engagements.
version: "1.0"
author: defconxt
license: AGPL-3.0
---

# CIPHER Engagement Pipeline

Structured methodology for security engagements with quality gates at each phase transition.
Every engagement follows this pipeline — stages can be skipped with documented justification.

## Pipeline Overview

```
┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐
│ SCOPE   │───▶│ RECON   │───▶│ ASSESS  │───▶│ EXPLOIT │───▶│ REPORT  │
│ (Gate 1)│    │ (Gate 2)│    │ (Gate 3)│    │ (Gate 4)│    │ (Gate 5)│
└─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘
     │              │              │              │              │
     ▼              ▼              ▼              ▼              ▼
  Rules of      Attack        Vuln         Proof of        Final
  Engagement    Surface       Inventory    Concept         Report
                Map
```

## Engagement Types

| Type | Stages Used | Typical Duration |
|------|-------------|-----------------|
| Penetration Test | All 5 stages | 1-4 weeks |
| Red Team | Stages 1,2,4 (stealth) | 2-8 weeks |
| Vulnerability Assessment | Stages 1,2,3,5 (no exploit) | 1-2 weeks |
| Architecture Review | Stages 1,3,5 (design focus) | 1-2 weeks |
| Incident Response | Stage 1 → IR Pipeline | Variable |
| Threat Model | Stages 1,3,5 (model focus) | 3-5 days |

---

## Stage 1: SCOPING

**Objective:** Define engagement boundaries, authorization, and success criteria.

### Inputs Required
- [ ] Client point of contact and escalation path
- [ ] Target systems, networks, or applications
- [ ] Engagement type (pentest, red team, vuln assessment, architecture review)
- [ ] Testing window and blackout periods
- [ ] Compliance requirements (PCI, HIPAA, SOC 2, etc.)

### Activities
1. **Define scope** — IP ranges, domains, applications, exclusions
2. **Rules of Engagement (RoE)** — See `templates/rules-of-engagement.md`
   - Testing hours and blackout windows
   - Authorized techniques and tools
   - Escalation procedures and emergency contacts
   - Data handling requirements
   - Social engineering authorization (if applicable)
3. **Threat model selection** — Define threat actor profile
   - External attacker (no credentials)
   - Compromised insider (user credentials)
   - Privileged insider (admin credentials)
   - Supply chain compromise (vendor access)
4. **Success criteria** — What constitutes a "successful" engagement
5. **Communication plan** — Status update frequency, channels, encryption

### Deliverable
- Signed Rules of Engagement document
- Scope definition with explicit in/out boundaries
- Emergency contact list and escalation matrix

### Gate 1: SCOPE APPROVAL
```
☐ RoE signed by authorized stakeholder
☐ Scope boundaries documented (IPs, domains, apps, exclusions)
☐ Testing window confirmed with operations team
☐ Emergency contacts verified (phone tested)
☐ Legal authorization obtained (written permission to test)
☐ Insurance/liability requirements met
☐ Data handling agreement signed (if accessing sensitive data)
```
**Gate rule:** ALL checkboxes must pass. No testing begins without signed RoE.

---

## Stage 2: RECONNAISSANCE

**Objective:** Map the attack surface. Identify all entry points, technologies, and potential attack paths.

### Activities
1. **Passive reconnaissance** (OSINT)
   - Domain enumeration (subfinder, amass, crt.sh)
   - Email/credential harvesting (hunter.io, dehashed)
   - Technology fingerprinting (Wappalyzer, BuiltWith)
   - Employee enumeration (LinkedIn, org charts)
   - GitHub/GitLab secret scanning
   - Cloud asset enumeration (S3 buckets, Azure blobs)

2. **Active reconnaissance** (within scope)
   - Port scanning (nmap, masscan)
   - Service enumeration and version detection
   - Web content discovery (ffuf, feroxbuster)
   - API endpoint discovery (katana, JS parsing)
   - DNS zone transfer attempts
   - SSL/TLS configuration analysis

3. **Attack surface mapping**
   - Document all discovered assets
   - Classify by exposure (internet-facing, internal, cloud)
   - Identify technology stack per asset
   - Map trust relationships and data flows
   - Prioritize targets by attack likelihood × impact

### Deliverable
- Attack Surface Map (ASM) document
- Asset inventory with technology fingerprints
- Prioritized target list with rationale

### Gate 2: RECON COMPLETE
```
☐ All in-scope domains/IPs enumerated
☐ Attack surface map produced
☐ Technology stack identified per target
☐ Targets prioritized by risk (likelihood × impact)
☐ No out-of-scope systems discovered in scan results
☐ Passive vs active collection documented
☐ Recon findings reviewed with engagement lead
```
**Gate rule:** ASM document produced and target prioritization approved.

---

## Stage 3: ASSESSMENT

**Objective:** Identify vulnerabilities across the attack surface. Classify by severity and exploitability.

### Activities
1. **Automated scanning**
   - Vulnerability scanning (Nessus, Qualys, OpenVAS)
   - Web application scanning (Nuclei, Burp Suite, ZAP)
   - Cloud security posture (Prowler, ScoutSuite)
   - Container scanning (Trivy, Grype)
   - IaC scanning (Checkov, tfsec)

2. **Manual testing** (by vulnerability class)
   - Authentication and authorization testing
   - Input validation (SQLi, XSS, SSRF, SSTI, XXE)
   - Business logic flaws
   - API security (BOLA, mass assignment, rate limiting)
   - Cryptographic implementation review
   - Session management analysis
   - File upload and download vulnerabilities

3. **Configuration review**
   - CIS benchmark compliance
   - Cloud IAM policy review
   - Network segmentation validation
   - TLS/certificate configuration
   - Logging and monitoring coverage

4. **Vulnerability classification**
   - CVSS v4.0 scoring
   - EPSS probability assessment
   - CISA KEV cross-reference
   - Business impact assessment
   - Exploitability determination (PoC available? Authenticated? Complex?)

### Deliverable
- Vulnerability inventory with CVSS/EPSS scores
- Finding reports in standard format (see CLAUDE.md Finding Report Format)
- Risk-ranked vulnerability matrix

### Gate 3: ASSESSMENT COMPLETE
```
☐ All in-scope targets assessed
☐ Automated scan results reviewed (false positives eliminated)
☐ Manual testing completed for applicable vulnerability classes
☐ Each finding has: severity, CVSS, CWE, location, evidence
☐ Findings ranked by risk (CVSS + EPSS + business impact)
☐ No critical scanner errors or incomplete scans
☐ Assessment findings reviewed with engagement lead
```
**Gate rule:** Vulnerability inventory complete. For vuln-assessment-only engagements, skip to Stage 5.

---

## Stage 4: EXPLOITATION

**Objective:** Prove impact through controlled exploitation. Demonstrate real-world attack paths.

### Activities
1. **Exploitation planning**
   - Select high-value findings for exploitation
   - Plan exploitation chain (initial access → privesc → objective)
   - Prepare rollback procedures for each exploit
   - Document pre-exploitation state (evidence)

2. **Controlled exploitation**
   - Exploit vulnerabilities with minimal impact
   - Capture proof-of-concept evidence (screenshots, command output)
   - Attempt privilege escalation
   - Attempt lateral movement (if in scope)
   - Attempt data access demonstration (not exfiltration)
   - Document each step with timestamps

3. **Post-exploitation** (if authorized)
   - Credential harvesting (demonstrate access, don't exfiltrate)
   - Persistence demonstration (install, document, remove)
   - Network pivoting to additional targets
   - Business objective achievement (flag capture, data access proof)

4. **Cleanup**
   - Remove all implants, backdoors, test accounts
   - Restore modified configurations
   - Document all changes made during exploitation
   - Verify cleanup completeness

### Deliverable
- Exploitation report with attack chains
- Proof-of-concept evidence per finding
- Cleanup verification log

### Gate 4: EXPLOITATION COMPLETE
```
☐ Exploitation limited to approved scope and techniques
☐ Each exploit has timestamped evidence (screenshot + command output)
☐ Attack chains documented end-to-end
☐ Business impact demonstrated (not just technical vuln)
☐ All artifacts cleaned up (implants, accounts, configs)
☐ Cleanup verification documented
☐ No unintended service disruption occurred
☐ Client notified of any critical findings immediately (per RoE)
```
**Gate rule:** All exploits documented with evidence. Cleanup verified. Critical findings communicated.

---

## Stage 5: REPORTING

**Objective:** Produce actionable deliverables that drive remediation.

### Activities
1. **Executive summary**
   - Business risk narrative (non-technical)
   - Overall security posture assessment
   - Top 3-5 strategic recommendations
   - Comparison to industry benchmarks (if available)

2. **Technical findings**
   - Each finding in standard format (see CLAUDE.md Finding Report Format)
   - Attack chain narratives with diagrams
   - Remediation guidance with verification steps
   - MITRE ATT&CK mapping for all findings

3. **Remediation roadmap**
   - Findings prioritized by risk and effort
   - Quick wins (high impact, low effort) highlighted
   - 30/60/90 day remediation timeline
   - Compensating controls for findings that can't be immediately fixed

4. **Appendices**
   - Methodology description
   - Tools used
   - Raw scanner output (sanitized)
   - Network diagrams and attack surface map
   - Retest scope (for remediation verification)

### Deliverable
- Final engagement report (executive + technical)
- Remediation roadmap with timeline
- Retest plan

### Gate 5: REPORT DELIVERED
```
☐ Executive summary is non-technical and actionable
☐ All findings have remediation guidance with verification steps
☐ Findings mapped to MITRE ATT&CK and relevant compliance frameworks
☐ Remediation roadmap has clear priorities and timeline
☐ Report reviewed by engagement lead (quality check)
☐ Report delivered securely (encrypted, per data handling agreement)
☐ Debrief meeting scheduled with client
☐ Retest date agreed for remediation verification
```
**Gate rule:** Report QA'd, delivered securely, debrief scheduled.

---

## Pipeline Controls

### Pivot Decision Points

At each gate, the engagement lead evaluates:
```
CONTINUE  — Gate passed, proceed to next stage
PIVOT     — Findings warrant scope change (get client approval)
PAUSE     — Blocked on dependency (waiting for access, credentials, etc.)
ESCALATE  — Critical finding requires immediate client notification
ABORT     — Safety concern, legal issue, or scope violation
```

### Evidence Requirements

Every finding must include:
1. **Location** — Exact URL, IP:port, file:line, or configuration path
2. **Evidence** — Screenshot, command output, or HTTP request/response
3. **Reproduction** — Step-by-step reproduction instructions
4. **Impact** — What an attacker could achieve (business terms)
5. **Remediation** — Specific fix with verification test

### Time Tracking

Track time per stage for estimation improvement:
```
Stage 1 (Scope):    ~5-10% of engagement time
Stage 2 (Recon):    ~15-20%
Stage 3 (Assess):   ~30-40%
Stage 4 (Exploit):  ~20-25%
Stage 5 (Report):   ~15-20%
```

### Quality Metrics

Track across engagements:
- Findings per engagement day
- Critical/high finding rate
- False positive rate (findings disputed by client)
- Remediation adoption rate (findings actually fixed)
- Client satisfaction score
- Retest pass rate
