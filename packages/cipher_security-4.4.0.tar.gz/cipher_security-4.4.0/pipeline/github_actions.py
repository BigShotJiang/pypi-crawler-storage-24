# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""
CIPHER GitHub Actions Integration — PR-Level Security Review

Analyzes PR diffs for security-relevant changes, detects hardcoded secrets,
identifies new attack surface, and posts structured findings as PR comments.
Supports SARIF output for GitHub Code Scanning and generates reusable
workflow/action YAML for GitHub Marketplace distribution.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from memory.core.engine import CipherMemory

ScanPipeline = Any  # Forward ref — not yet importable


class RiskLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class SecretType(str, Enum):
    API_KEY = "api_key"
    PASSWORD = "password"
    TOKEN = "token"
    PRIVATE_KEY = "private_key"
    CONNECTION_STRING = "connection_string"
    AWS_CREDENTIAL = "aws_credential"
    GENERIC = "generic"


@dataclass
class SecretFinding:
    """A hardcoded secret or credential detected in a diff."""

    secret_type: SecretType
    file_path: str
    line_number: int
    matched_pattern: str
    snippet: str
    confidence: float
    recommendation: str = "Rotate immediately and move to a secrets manager."

    @property
    def fingerprint(self) -> str:
        raw = f"{self.secret_type.value}:{self.file_path}:{self.matched_pattern}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]


@dataclass
class DiffAnalysis:
    """Result of analyzing a git diff for security-relevant changes."""

    files_changed: list[str] = field(default_factory=list)
    endpoints_added: list[str] = field(default_factory=list)
    endpoints_modified: list[str] = field(default_factory=list)
    secrets: list[SecretFinding] = field(default_factory=list)
    auth_changes: list[str] = field(default_factory=list)
    crypto_changes: list[str] = field(default_factory=list)
    sql_changes: list[str] = field(default_factory=list)
    input_handling_changes: list[str] = field(default_factory=list)
    file_operation_changes: list[str] = field(default_factory=list)
    risk_level: RiskLevel = RiskLevel.INFO
    summary: str = ""

    @property
    def has_security_findings(self) -> bool:
        return bool(
            self.secrets or self.auth_changes or self.crypto_changes or self.sql_changes
        )


@dataclass
class PRReviewResult:
    """Complete result of a PR security review."""

    repo: str
    pr_number: int
    diff_analysis: DiffAnalysis
    scan_findings: list[dict[str, Any]] = field(default_factory=list)
    regressions: list[dict[str, Any]] = field(default_factory=list)
    reviewed_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    review_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])

    @property
    def risk_level(self) -> RiskLevel:
        return self.diff_analysis.risk_level

    @property
    def total_findings(self) -> int:
        return (
            len(self.diff_analysis.secrets)
            + len(self.scan_findings)
            + len(self.regressions)
        )


_AUTH_RE = [
    re.compile(r"\b(authenticate|authorize|login|logout|session|jwt|oauth)\b", re.I),
    re.compile(r"\b(password|passwd|credential|api_key|secret)\b", re.I),
    re.compile(r"@(require_auth|login_required|permission_required)", re.I),
]
_CRYPTO_RE = [
    re.compile(r"\b(md5|sha1|sha256|sha512|hmac|bcrypt|scrypt|argon2)\b", re.I),
    re.compile(r"\b(encrypt|decrypt|cipher|aes|rsa|ecdsa|sign|verify)\b", re.I),
    re.compile(r"\b(ssl|tls|certificate|x509|pem|pkcs)\b", re.I),
]
_SQL_RE = [
    re.compile(r"\b(execute|raw_sql|text\(|cursor\.execute)\b", re.I),
    re.compile(r"(SELECT|INSERT|UPDATE|DELETE|DROP|ALTER)\s+", re.I),
    re.compile(r"f['\"].*\{.*\}.*(?:SELECT|INSERT|UPDATE|DELETE)", re.I),
]
_INPUT_RE = [
    re.compile(r"\b(request\.(get|post|json|form|args|params))\b", re.I),
    re.compile(r"\b(innerHTML|dangerouslySetInnerHTML|eval|exec)\b", re.I),
    re.compile(r"\b(unserialize|pickle\.loads|yaml\.load)\b", re.I),
]
_FILE_RE = [
    re.compile(r"\b(subprocess|os\.system|popen|exec|spawn)\b", re.I),
    re.compile(r"\b(open|read|write|unlink|rmtree|chmod|chown)\b", re.I),
]
_ENDPOINT_RE = [
    re.compile(
        r"@(?:app|router|blueprint)\.(get|post|put|patch|delete)\(['\"]([^'\"]+)", re.I
    ),
    re.compile(r"path\(['\"]([^'\"]+)['\"]", re.I),
    re.compile(r"router\.(get|post|put|patch|delete)\(['\"]([^'\"]+)", re.I),
    re.compile(r"@(Get|Post|Put|Patch|Delete)Mapping\(['\"]([^'\"]+)", re.I),
]
_SECRET_RE: list[tuple[re.Pattern[str], SecretType, float]] = [
    (re.compile(r"AKIA[0-9A-Z]{16}"), SecretType.AWS_CREDENTIAL, 0.95),
    (
        re.compile(r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----"),
        SecretType.PRIVATE_KEY,
        0.99,
    ),
    (re.compile(r"ghp_[A-Za-z0-9_]{36}"), SecretType.TOKEN, 0.95),
    (re.compile(r"sk-[A-Za-z0-9]{48}"), SecretType.API_KEY, 0.90),
    (re.compile(r"xox[bpas]-[A-Za-z0-9\-]{10,}"), SecretType.TOKEN, 0.90),
    (
        re.compile(
            r"(?:api[_-]?key|apikey)\s*[:=]\s*['\"]([A-Za-z0-9_\-]{20,})['\"]", re.I
        ),
        SecretType.API_KEY,
        0.75,
    ),
    (
        re.compile(r"(?:password|passwd|pwd)\s*[:=]\s*['\"]([^'\"]{8,})['\"]", re.I),
        SecretType.PASSWORD,
        0.70,
    ),
    (
        re.compile(r"(?:secret|token)\s*[:=]\s*['\"]([A-Za-z0-9_\-]{16,})['\"]", re.I),
        SecretType.TOKEN,
        0.70,
    ),
    (
        re.compile(r"(?:postgres|mysql|mongodb)://[^\s'\"]{10,}", re.I),
        SecretType.CONNECTION_STRING,
        0.85,
    ),
]


class SecurityDiffAnalyzer:
    """Parse and analyze git diffs for security-relevant changes."""

    def analyze_diff(self, diff_text: str) -> DiffAnalysis:
        """Parse a unified diff and identify security-relevant changes."""
        analysis = DiffAnalysis(
            files_changed=self._extract_files(diff_text),
            endpoints_added=self.extract_endpoints_from_diff(diff_text),
            secrets=self.detect_secrets_in_diff(diff_text),
        )
        for line in self._added_lines(diff_text):
            self._classify_line(line, analysis)
        analysis.risk_level = self._risk_from(analysis)
        analysis.summary = self._summarize(analysis)
        return analysis

    def extract_endpoints_from_diff(self, diff_text: str) -> list[str]:
        """Extract new/modified API endpoint paths from added diff lines."""
        endpoints: list[str] = []
        for line in self._added_lines(diff_text):
            for pat in _ENDPOINT_RE:
                m = pat.search(line)
                if m:
                    path = m.group(m.lastindex or 1)
                    if path and path not in endpoints:
                        endpoints.append(path)
        return endpoints

    def detect_secrets_in_diff(self, diff_text: str) -> list[SecretFinding]:
        """Scan added lines for hardcoded secrets and credentials."""
        findings: list[SecretFinding] = []
        cur_file, lnum = "<unknown>", 0
        for raw in diff_text.splitlines():
            if raw.startswith("+++ b/"):
                cur_file = raw[6:]
            elif raw.startswith("@@ "):
                m = re.search(r"\+(\d+)", raw)
                lnum = int(m.group(1)) if m else 0
            elif raw.startswith("+") and not raw.startswith("+++"):
                lnum += 1
                content = raw[1:]
                for pattern, stype, conf in _SECRET_RE:
                    if pattern.search(content):
                        findings.append(
                            SecretFinding(
                                secret_type=stype,
                                file_path=cur_file,
                                line_number=lnum,
                                matched_pattern=pattern.pattern[:60],
                                snippet=content.strip()[:80],
                                confidence=conf,
                            )
                        )
                        break
            elif not raw.startswith("-"):
                lnum += 1
        return findings

    def classify_risk(self, diff_text: str) -> str:
        """Classify risk from raw diff text."""
        return self.analyze_diff(diff_text).risk_level.value

    @staticmethod
    def _extract_files(diff: str) -> list[str]:
        return [ln[6:] for ln in diff.splitlines() if ln.startswith("+++ b/")]

    @staticmethod
    def _added_lines(diff: str) -> list[str]:
        return [
            ln[1:]
            for ln in diff.splitlines()
            if ln.startswith("+") and not ln.startswith("+++")
        ]

    @staticmethod
    def _classify_line(line: str, a: DiffAnalysis) -> None:
        stripped = line.strip()
        for pats, bucket in [
            (_AUTH_RE, a.auth_changes),
            (_CRYPTO_RE, a.crypto_changes),
            (_SQL_RE, a.sql_changes),
            (_INPUT_RE, a.input_handling_changes),
            (_FILE_RE, a.file_operation_changes),
        ]:
            if any(p.search(line) for p in pats):
                bucket.append(stripped)

    @staticmethod
    def _risk_from(a: DiffAnalysis) -> RiskLevel:
        if a.secrets or a.auth_changes or a.crypto_changes:
            return RiskLevel.HIGH
        if a.sql_changes or a.input_handling_changes:
            return RiskLevel.MEDIUM
        if a.file_operation_changes or a.endpoints_added:
            return RiskLevel.LOW
        return RiskLevel.INFO

    @staticmethod
    def _summarize(a: DiffAnalysis) -> str:
        parts = [f"{len(a.files_changed)} file(s) changed"]
        checks: list[tuple[str, list]] = [
            ("secret(s)", a.secrets),
            ("auth change(s)", a.auth_changes),
            ("crypto change(s)", a.crypto_changes),
            ("SQL change(s)", a.sql_changes),
            ("new endpoint(s)", a.endpoints_added),
        ]
        for label, items in checks:
            if items:
                parts.append(f"{len(items)} {label}")
        return "; ".join(parts)


_SEV_EMOJI = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪"}


class FindingFormatter:
    """Format security findings for different output targets."""

    def to_pr_comment(self, findings: PRReviewResult) -> str:
        """Format a full PR review result as a GitHub markdown comment."""
        da = findings.diff_analysis
        risk = findings.risk_level.value
        lines = [
            f"## {_SEV_EMOJI.get(risk, '⚪')} CIPHER Security Review — {risk.upper()} risk",
            "",
            f"> Review `{findings.review_id}` | {findings.reviewed_at}",
            "",
            f"**Summary:** {da.summary}",
            "",
        ]
        if da.secrets:
            lines += [
                "### 🔑 Hardcoded Secrets",
                "",
                "| # | Type | File | Line | Confidence |",
                "|---|------|------|------|------------|",
            ]
            for i, s in enumerate(da.secrets, 1):
                lines.append(
                    f"| {i} | `{s.secret_type.value}` | `{s.file_path}` "
                    f"| {s.line_number} | {s.confidence:.0%} |"
                )
            lines.append("")
        for label, items in [
            ("🔐 Auth Changes", da.auth_changes),
            ("🔒 Crypto Changes", da.crypto_changes),
            ("🗄️ SQL Changes", da.sql_changes),
            ("📥 Input Handling", da.input_handling_changes),
            ("📂 File/Process Ops", da.file_operation_changes),
        ]:
            if items:
                lines += [f"### {label}", ""]
                lines += [f"- `{it[:120]}`" for it in items[:10]]
                if len(items) > 10:
                    lines.append(f"- _… and {len(items) - 10} more_")
                lines.append("")
        if da.endpoints_added:
            lines += ["### 🌐 New Endpoints", ""]
            lines += [f"- `{ep}`" for ep in da.endpoints_added]
            lines.append("")
        if findings.regressions:
            lines += ["### ⚠️ Regressions", ""]
            for r in findings.regressions:
                lines.append(
                    f"- **{r.get('title', 'Untitled')}** — {r.get('description', '')}"
                )
            lines.append("")
        lines += ["---", "_Generated by [CIPHER](https://github.com/defconxt/cipher)_"]
        return "\n".join(lines)

    def to_sarif(self, findings: PRReviewResult) -> dict[str, Any]:
        """Produce SARIF v2.1.0 for GitHub Code Scanning."""
        results, rules, seen = [], [], set()
        for s in findings.diff_analysis.secrets:
            rid = f"cipher/secret-{s.secret_type.value}"
            if rid not in seen:
                seen.add(rid)
                rules.append(
                    {
                        "id": rid,
                        "name": f"HardcodedSecret_{s.secret_type.value}",
                        "shortDescription": {
                            "text": f"Hardcoded {s.secret_type.value}"
                        },
                        "defaultConfiguration": {"level": "error"},
                    }
                )
            results.append(
                {
                    "ruleId": rid,
                    "message": {"text": f"Hardcoded {s.secret_type.value} in diff"},
                    "locations": [
                        {
                            "physicalLocation": {
                                "artifactLocation": {"uri": s.file_path},
                                "region": {"startLine": s.line_number},
                            }
                        }
                    ],
                    "fingerprints": {"cipher/v1": s.fingerprint},
                }
            )
        return {
            "$schema": "https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "CIPHER",
                            "version": "1.0.0",
                            "informationUri": "https://github.com/defconxt/cipher",
                            "rules": rules,
                        }
                    },
                    "results": results,
                }
            ],
        }

    def to_json(self, findings: PRReviewResult) -> str:
        """Serialize review result as structured JSON."""
        da = findings.diff_analysis
        return json.dumps(
            {
                "review_id": findings.review_id,
                "repo": findings.repo,
                "pr_number": findings.pr_number,
                "risk_level": findings.risk_level.value,
                "reviewed_at": findings.reviewed_at,
                "total_findings": findings.total_findings,
                "diff_analysis": {
                    "files_changed": da.files_changed,
                    "endpoints_added": da.endpoints_added,
                    "secrets_count": len(da.secrets),
                    "auth_changes": len(da.auth_changes),
                    "crypto_changes": len(da.crypto_changes),
                    "sql_changes": len(da.sql_changes),
                },
                "secrets": [
                    {
                        "type": s.secret_type.value,
                        "file": s.file_path,
                        "line": s.line_number,
                        "confidence": s.confidence,
                        "fingerprint": s.fingerprint,
                    }
                    for s in da.secrets
                ],
                "regressions": findings.regressions,
            },
            indent=2,
        )


class PRSecurityReview:
    """Orchestrate PR-level security reviews via the GitHub API."""

    def __init__(
        self, scanner: ScanPipeline, memory: CipherMemory, github_token: str = ""
    ) -> None:
        self.scanner = scanner
        self.memory = memory
        self.github_token = github_token
        self._analyzer = SecurityDiffAnalyzer()
        self._formatter = FindingFormatter()
        self._api = "https://api.github.com"

    def review_pr(self, repo: str, pr_number: int) -> PRReviewResult:
        """Fetch PR diff, analyse for security issues, and scan new endpoints."""
        diff_text = self._fetch_diff(repo, pr_number)
        analysis = self._analyzer.analyze_diff(diff_text)
        scan_findings = [
            r
            for ep in analysis.endpoints_added
            if (r := self._scan_endpoint(ep)) is not None
        ]
        return PRReviewResult(
            repo=repo,
            pr_number=pr_number,
            diff_analysis=analysis,
            scan_findings=scan_findings,
        )

    def post_comment(self, repo: str, pr_number: int, findings: PRReviewResult) -> bool:
        """Post formatted findings as a PR comment. Returns True on success."""
        body = self._formatter.to_pr_comment(findings)
        url = f"{self._api}/repos/{repo}/issues/{pr_number}/comments"
        return self._post(url, {"body": body})

    def check_regression(
        self, repo: str, pr_number: int, engagement_id: str
    ) -> list[dict[str, Any]]:
        """Test previous findings from *engagement_id* against PR changes."""
        previous = self._load_findings(engagement_id)
        if not previous:
            return []
        diff_text = self._fetch_diff(repo, pr_number)
        regressions: list[dict[str, Any]] = []
        for f in previous:
            pattern = f.get("pattern", "")
            if pattern and re.search(re.escape(pattern), diff_text):
                regressions.append(
                    {
                        "title": f.get("title", "Regression"),
                        "description": f"Previously remediated finding re-introduced in PR #{pr_number}",
                        "original_engagement": engagement_id,
                        "severity": f.get("severity", "medium"),
                    }
                )
        return regressions

    # -- helpers ------------------------------------------------------------

    def _fetch_diff(self, repo: str, pr_number: int) -> str:
        import urllib.request

        url = f"{self._api}/repos/{repo}/pulls/{pr_number}"
        headers: dict[str, str] = {"Accept": "application/vnd.github.diff"}
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310  # nosec B310
            return resp.read().decode()

    def _post(self, url: str, payload: dict[str, Any]) -> bool:
        import urllib.request

        data = json.dumps(payload).encode()
        headers: dict[str, str] = {
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
        }
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310  # nosec B310
                return 200 <= resp.status < 300
        except Exception:  # noqa: BLE001
            return False

    def _scan_endpoint(self, endpoint: str) -> dict[str, Any] | None:
        if self.scanner is None:
            return None
        try:
            return self.scanner.scan(endpoint)  # type: ignore[union-attr]
        except Exception:  # noqa: BLE001
            return None

    def _load_findings(self, engagement_id: str) -> list[dict[str, Any]]:
        if self.memory is None:
            return []
        try:
            results = self.memory.search(query=f"engagement:{engagement_id}", limit=100)  # type: ignore[union-attr]
            # Convert MemoryEntry objects to dicts if needed
            return [r if isinstance(r, dict) else r.__dict__ for r in results]
        except Exception:  # noqa: BLE001
            return []


_WORKFLOW_TPL = """\
# Generated by CIPHER — do not edit manually.
name: CIPHER Security Review
on:
  pull_request:
    types: [opened, synchronize, reopened]
  workflow_dispatch:
    inputs:
      scan_profile:
        description: "Scan profile"
        default: "{profile}"
        type: choice
        options: [pentest, recon, architecture]
permissions: {{ contents: read, pull-requests: write, security-events: write }}
jobs:
  security-review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: {{ fetch-depth: 0 }}
      - uses: actions/setup-python@v5
        with: {{ python-version: "3.12" }}
      - run: pip install cipher-security
      - name: Run PR Security Review
        env:
          GITHUB_TOKEN: ${{{{ secrets.GITHUB_TOKEN }}}}
          CIPHER_PROFILE: ${{{{ inputs.scan_profile || '{profile}' }}}}
        run: >-
          cipher review-pr
          --repo "${{{{ github.repository }}}}"
          --pr "${{{{ github.event.pull_request.number }}}}"
          --profile "$CIPHER_PROFILE"
          --output sarif --output-file results.sarif
      - uses: github/codeql-action/upload-sarif@v3
        if: always()
        with: {{ sarif_file: results.sarif }}
      - name: Post PR Comment
        if: github.event_name == 'pull_request'
        env:
          GITHUB_TOKEN: ${{{{ secrets.GITHUB_TOKEN }}}}
        run: >-
          cipher review-pr
          --repo "${{{{ github.repository }}}}"
          --pr "${{{{ github.event.pull_request.number }}}}"
          --comment
"""

_ACTION_TPL = """\
# Generated by CIPHER — do not edit manually.
name: "CIPHER Security Review"
description: "Automated PR-level security review. Detects secrets, auth regressions, new attack surface."
author: "defconxt"
branding: { icon: shield, color: purple }
inputs:
  scan_profile: { description: "Scan profile", required: false, default: "pentest" }
  github_token: { description: "GitHub token", required: true }
  post_comment: { description: "Post findings as PR comment", required: false, default: "true" }
  sarif_output: { description: "SARIF output path", required: false, default: "cipher-results.sarif" }
outputs:
  risk_level: { description: "Overall risk level (high|medium|low|info)" }
  total_findings: { description: "Total number of findings" }
  review_id: { description: "Unique review identifier" }
runs:
  using: "composite"
  steps:
    - uses: actions/setup-python@v5
      with: { python-version: "3.12" }
    - { shell: bash, run: "pip install cipher-security" }
    - name: Run Security Review
      shell: bash
      env:
        GITHUB_TOKEN: ${{ inputs.github_token }}
        CIPHER_PROFILE: ${{ inputs.scan_profile }}
      run: >-
        cipher review-pr
        --repo "${{ github.repository }}"
        --pr "${{ github.event.pull_request.number }}"
        --profile "$CIPHER_PROFILE"
        --output sarif --output-file "${{ inputs.sarif_output }}"
    - name: Post Comment
      if: inputs.post_comment == 'true'
      shell: bash
      env: { GITHUB_TOKEN: "${{ inputs.github_token }}" }
      run: >-
        cipher review-pr
        --repo "${{ github.repository }}"
        --pr "${{ github.event.pull_request.number }}"
        --comment
"""


class WorkflowGenerator:
    """Generate GitHub Actions workflow and action YAML files."""

    def generate_workflow(self, scan_profile: str = "pentest") -> str:
        """Generate ``.github/workflows/cipher-security.yml``."""
        return _WORKFLOW_TPL.format(profile=scan_profile)

    def generate_action_yaml(self) -> str:
        """Generate ``action.yml`` for GitHub Marketplace."""
        return _ACTION_TPL
