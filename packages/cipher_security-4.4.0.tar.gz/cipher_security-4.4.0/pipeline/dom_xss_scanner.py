# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""Runtime DOM XSS scanner using Playwright headless browser.

Complements the static XSS scanner (xss_scanner.py) by executing JavaScript
in a real browser context to detect XSS that only manifests at runtime.

Detection approach:
1. Navigate to target URL
2. Enumerate inputs, URL parameters, and fragment identifiers
3. Inject XSS payloads into each vector
4. Monitor for payload execution via dialog events and DOM mutations
5. Report confirmed XSS with reproduction steps

Requires: ``pip install playwright && playwright install chromium``
"""

from __future__ import annotations

import logging
import urllib.parse
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("cipher.dom_xss")

# ---------------------------------------------------------------------------
# Payloads — designed to trigger detectable events
# ---------------------------------------------------------------------------

# Each payload is (label, payload_string, detection_method)
_XSS_PAYLOADS: list[tuple[str, str, str]] = [
    ("script-alert", '<script>alert("CIPHER-XSS-1")</script>', "dialog"),
    ("img-onerror", '<img src=x onerror=alert("CIPHER-XSS-2")>', "dialog"),
    ("svg-onload", '<svg/onload=alert("CIPHER-XSS-3")>', "dialog"),
    ("body-onload", '<body onload=alert("CIPHER-XSS-4")>', "dialog"),
    ("event-handler", '" onfocus=alert("CIPHER-XSS-5") autofocus="', "dialog"),
    ("javascript-uri", 'javascript:alert("CIPHER-XSS-6")', "dialog"),
    ("template-literal", '${alert("CIPHER-XSS-7")}', "dialog"),
    (
        "iframe-srcdoc",
        "<iframe srcdoc=\"<script>alert('CIPHER-XSS-8')</script>\">",
        "dialog",
    ),
]

# Minimal payloads for URL parameter injection
_URL_PAYLOADS: list[tuple[str, str]] = [
    ("reflected-script", '<script>alert("CIPHER-XSS-R1")</script>'),
    ("reflected-img", '<img src=x onerror=alert("CIPHER-XSS-R2")>'),
    ("reflected-svg", '<svg/onload=alert("CIPHER-XSS-R3")>'),
    ("hash-injection", '#<img src=x onerror=alert("CIPHER-XSS-R4")>'),
]


@dataclass
class DOMXSSFinding:
    """A confirmed runtime XSS vulnerability."""

    url: str
    vector: str  # "input", "url-param", "fragment", "form"
    input_name: str  # name/id of the injected element or parameter
    payload: str
    payload_label: str
    confirmed: bool = True
    reproduction: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "url": self.url,
            "vector": self.vector,
            "input": self.input_name,
            "payload_label": self.payload_label,
            "confirmed": self.confirmed,
            "reproduction": self.reproduction,
        }


@dataclass
class DOMXSSScanResult:
    """Aggregate result of runtime DOM XSS scanning."""

    target: str
    pages_tested: int = 0
    inputs_tested: int = 0
    params_tested: int = 0
    findings: list[DOMXSSFinding] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "pages_tested": self.pages_tested,
            "inputs_tested": self.inputs_tested,
            "params_tested": self.params_tested,
            "findings": [f.to_dict() for f in self.findings],
            "confirmed_xss": len(self.findings),
            "errors": self.errors,
        }

    def summary(self) -> str:
        if self.findings:
            return (
                f"{len(self.findings)} confirmed DOM XSS in {self.target} "
                f"({self.inputs_tested} inputs, {self.params_tested} params tested)"
            )
        return f"No DOM XSS found in {self.target} ({self.inputs_tested} inputs tested)"


class DOMXSSScanner:
    """Runtime DOM XSS scanner using Playwright.

    Launches a headless Chromium browser, navigates to target URLs,
    injects payloads into inputs and URL parameters, and monitors
    for alert() dialogs as XSS confirmation.
    """

    def __init__(self, headless: bool = True, timeout: int = 5000) -> None:
        self._headless = headless
        self._timeout = timeout
        self._available = False
        try:
            from playwright.sync_api import sync_playwright

            self._sync_playwright = sync_playwright
            self._available = True
        except ImportError:
            pass

    @property
    def available(self) -> bool:
        return self._available

    def scan_url(
        self,
        url: str,
        test_params: bool = True,
        test_inputs: bool = True,
        test_forms: bool = True,
    ) -> DOMXSSScanResult:
        """Scan a single URL for DOM XSS vulnerabilities.

        Args:
            url: Target URL to scan.
            test_params: Test URL query parameters with XSS payloads.
            test_inputs: Test input fields on the page.
            test_forms: Test form submissions.

        Returns:
            DOMXSSScanResult with confirmed findings.
        """
        if not self._available:
            return DOMXSSScanResult(
                target=url,
                errors=[
                    "Playwright not installed — run: pip install playwright && playwright install chromium"
                ],
            )

        result = DOMXSSScanResult(target=url)

        try:
            with self._sync_playwright() as p:
                browser = p.chromium.launch(headless=self._headless)
                context = browser.new_context(
                    ignore_https_errors=True,
                    java_script_enabled=True,
                )

                if test_params:
                    self._test_url_params(context, url, result)

                if test_inputs:
                    self._test_input_fields(context, url, result)

                if test_forms:
                    self._test_forms(context, url, result)

                result.pages_tested += 1
                context.close()
                browser.close()
        except Exception as exc:
            result.errors.append(f"Scanner error: {exc}")

        return result

    def _test_url_params(
        self, context: Any, url: str, result: DOMXSSScanResult
    ) -> None:
        """Inject payloads into URL query parameters."""
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)

        if not params:
            # Try adding common parameter names
            common_params = [
                "q",
                "search",
                "query",
                "id",
                "name",
                "page",
                "url",
                "redirect",
                "next",
                "callback",
            ]
            for param_name in common_params:
                for label, payload in _URL_PAYLOADS:
                    result.params_tested += 1
                    injected_url = f"{url}{'&' if '?' in url else '?'}{param_name}={urllib.parse.quote(payload)}"
                    finding = self._check_url_xss(
                        context, injected_url, "url-param", param_name, label, payload
                    )
                    if finding:
                        result.findings.append(finding)
                        return  # One confirmed finding per param is enough
        else:
            for param_name in params:
                for label, payload in _URL_PAYLOADS:
                    result.params_tested += 1
                    new_params = dict(params)
                    new_params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(new_params, doseq=True)
                    injected_url = urllib.parse.urlunparse(
                        parsed._replace(query=new_query)
                    )
                    finding = self._check_url_xss(
                        context, injected_url, "url-param", param_name, label, payload
                    )
                    if finding:
                        result.findings.append(finding)
                        break  # Move to next param

        # Test fragment injection
        for label, payload in _URL_PAYLOADS:
            if label.startswith("hash"):
                result.params_tested += 1
                injected_url = f"{url}{payload}"
                finding = self._check_url_xss(
                    context, injected_url, "fragment", "#", label, payload
                )
                if finding:
                    result.findings.append(finding)

    def _test_input_fields(
        self, context: Any, url: str, result: DOMXSSScanResult
    ) -> None:
        """Inject payloads into input fields on the page."""
        page = context.new_page()
        dialogs: list[str] = []
        page.on("dialog", lambda d: (dialogs.append(d.message), d.accept()))  # type: ignore[func-returns-value]

        try:
            page.goto(url, wait_until="networkidle", timeout=self._timeout * 2)
        except Exception as exc:
            result.errors.append(f"Navigation failed: {exc}")
            page.close()
            return

        # Find all input fields
        inputs = page.query_selector_all(
            "input[type='text'], input[type='search'], "
            "input:not([type]), textarea, [contenteditable='true']"
        )

        for inp in inputs:
            input_name = (
                inp.get_attribute("name")
                or inp.get_attribute("id")
                or inp.get_attribute("placeholder")
                or "unnamed"
            )

            for label, payload, detection in _XSS_PAYLOADS:
                result.inputs_tested += 1
                dialogs.clear()
                try:
                    inp.fill("")
                    inp.fill(payload)
                    # Try triggering: blur, submit nearby form, or just wait
                    inp.dispatch_event("change")
                    inp.dispatch_event("blur")
                    page.wait_for_timeout(500)

                    if dialogs and any("CIPHER-XSS" in d for d in dialogs):
                        result.findings.append(
                            DOMXSSFinding(
                                url=url,
                                vector="input",
                                input_name=input_name,
                                payload=payload,
                                payload_label=label,
                                reproduction=f"Fill input '{input_name}' with: {payload}",
                            )
                        )
                        break  # One payload per input is enough
                except Exception:
                    continue
        page.close()

    def _test_forms(self, context: Any, url: str, result: DOMXSSScanResult) -> None:
        """Test form submissions with XSS payloads."""
        page = context.new_page()
        dialogs: list[str] = []
        page.on("dialog", lambda d: (dialogs.append(d.message), d.accept()))  # type: ignore[func-returns-value]

        try:
            page.goto(url, wait_until="networkidle", timeout=self._timeout * 2)
        except Exception:
            page.close()
            return

        forms = page.query_selector_all("form")
        for form in forms:
            form_inputs = form.query_selector_all(
                "input[type='text'], input:not([type]), textarea"
            )
            if not form_inputs:
                continue

            # Fill all inputs with XSS payload and submit
            payload = _XSS_PAYLOADS[0][1]  # script-alert
            dialogs.clear()
            try:
                for fi in form_inputs:
                    fi.fill(payload)
                # Submit
                submit_btn = form.query_selector(
                    "button[type='submit'], input[type='submit']"
                )
                if submit_btn:
                    submit_btn.click()
                else:
                    form.dispatch_event("submit")
                page.wait_for_timeout(1000)

                if dialogs and any("CIPHER-XSS" in d for d in dialogs):
                    form_id = (
                        form.get_attribute("id")
                        or form.get_attribute("action")
                        or "form"
                    )
                    result.findings.append(
                        DOMXSSFinding(
                            url=url,
                            vector="form",
                            input_name=form_id,
                            payload=payload,
                            payload_label="form-submit",
                            reproduction=f"Submit form '{form_id}' with XSS in all text inputs",
                        )
                    )
            except Exception:
                continue
        page.close()

    def _check_url_xss(
        self,
        context: Any,
        url: str,
        vector: str,
        param_name: str,
        label: str,
        payload: str,
    ) -> DOMXSSFinding | None:
        """Navigate to an injected URL and check for XSS execution."""
        page = context.new_page()
        dialogs: list[str] = []
        page.on("dialog", lambda d: (dialogs.append(d.message), d.accept()))  # type: ignore[func-returns-value]

        try:
            page.goto(url, wait_until="networkidle", timeout=self._timeout)
            page.wait_for_timeout(500)
        except Exception:
            pass
        finally:
            page.close()

        if dialogs and any("CIPHER-XSS" in d for d in dialogs):
            return DOMXSSFinding(
                url=url,
                vector=vector,
                input_name=param_name,
                payload=payload,
                payload_label=label,
                reproduction=f"Navigate to: {url}",
            )
        return None
