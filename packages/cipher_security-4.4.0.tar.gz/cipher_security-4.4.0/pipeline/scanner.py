# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER Scanning Pipeline — Nuclei/Katana integration layer."""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger("cipher.pipeline.scanner")

_DEFAULT_TIMEOUT = 600  # 10 minutes
_TOOL_MISSING = (
    "{tool} not found at '{path}'. "
    "Install: https://github.com/projectdiscovery/{tool}#installation"
)

# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class Finding:
    """Single vulnerability finding from Nuclei."""

    template_id: str = ""
    name: str = ""
    severity: str = ""
    host: str = ""
    matched_at: str = ""
    matcher_name: str = ""
    description: str = ""
    reference: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    cve_ids: list[str] = field(default_factory=list)
    cwe_ids: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_nuclei_json(cls, data: dict[str, Any]) -> Finding:
        """Parse a single Nuclei JSONL line."""
        info = data.get("info", {})
        classif = info.get("classification", {})
        return cls(
            template_id=data.get("template-id", data.get("template_id", "")),
            name=info.get("name", ""),
            severity=info.get("severity", "unknown"),
            host=data.get("host", ""),
            matched_at=data.get("matched-at", data.get("matched_at", "")),
            matcher_name=data.get("matcher-name", data.get("matcher_name", "")),
            description=info.get("description", ""),
            reference=info.get("reference", []) or [],
            tags=info.get("tags", []) or [],
            cve_ids=classif.get("cve-id", []) or [],
            cwe_ids=[str(c) for c in (classif.get("cwe-id", []) or [])],
            raw=data,
        )


@dataclass
class ScanResult:
    """Aggregated result from a Nuclei scan."""

    target: str = ""
    findings: list[Finding] = field(default_factory=list)
    stats: dict[str, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    command: str = ""
    duration_seconds: float = 0.0
    success: bool = False

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "critical")

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")

    def to_sarif(self) -> str:
        """Export scan results as SARIF v2.1.0 JSON string."""
        from pipeline.sarif import SarifReport

        report = SarifReport()
        for f in self.findings:
            report.add_finding(
                {
                    "template_id": f.template_id,
                    "name": f.name,
                    "description": f.description,
                    "severity": f.severity,
                    "host": f.host,
                    "matched_at": f.matched_at,
                    "tags": f.tags,
                    "cve_ids": f.cve_ids,
                    "reference": f.reference,
                }
            )
        return report.to_json()

    def generate_custom_templates(self) -> list[str]:
        """Auto-generate nuclei templates from scan findings for re-testing."""
        from pipeline.template_manager import NucleiTemplateManager

        mgr = NucleiTemplateManager()
        templates: list[str] = []
        for f in self.findings:
            if f.severity in ("critical", "high"):
                template_yaml = mgr.generate_template(
                    {
                        "title": f.name,
                        "description": f.description,
                        "severity": f.severity,
                        "path": f.matched_at.split("//", 1)[-1].split("/", 1)[-1]
                        if f.matched_at and "//" in f.matched_at
                        else "/",
                        "matchers": [f.name] if f.name else [],
                    }
                )
                templates.append(template_yaml)
        return templates


@dataclass
class CrawlResult:
    """Aggregated result from a Katana crawl."""

    target: str = ""
    urls: list[str] = field(default_factory=list)
    endpoints: list[str] = field(default_factory=list)
    forms: list[dict[str, Any]] = field(default_factory=list)
    js_files: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    command: str = ""
    success: bool = False


@dataclass
class PipelineResult:
    """Combined result from a full scan pipeline run."""

    target: str = ""
    crawl: CrawlResult | None = None
    scan: ScanResult | None = None
    stored_entry_ids: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    success: bool = False

    @property
    def urls_crawled(self) -> int:
        """Number of URLs discovered by the crawler."""
        return len(self.crawl.urls) if self.crawl else 0

    @property
    def findings_count(self) -> int:
        """Total findings from the scan."""
        return len(self.scan.findings) if self.scan else 0

    @property
    def findings_stored(self) -> int:
        """Number of findings persisted to memory."""
        return len(self.stored_entry_ids)

    @property
    def duration(self) -> float:
        """Total scan duration in seconds."""
        return self.scan.duration_seconds if self.scan else 0.0

    @property
    def findings(self) -> list[Finding]:
        """All findings from the scan phase."""
        return self.scan.findings if self.scan else []


# ---------------------------------------------------------------------------
# Scan profiles
# ---------------------------------------------------------------------------


class ScanDomain(str, Enum):
    """CIPHER operating domains mapped to scan profiles."""

    RED = "red"
    BLUE = "blue"
    RECON = "recon"
    PRIVACY = "privacy"
    ARCHITECT = "architect"


_PROFILE_CONFIGS: dict[str, dict[str, Any]] = {
    "red": dict(
        name="red-team",
        tags=["cve", "rce", "sqli", "xss", "ssrf", "lfi", "auth-bypass"],
        severity=["critical", "high", "medium"],
        rate_limit=100,
        bulk_size=15,
        headless=True,
    ),
    "blue": dict(
        name="hardening-audit",
        tags=["misconfig", "exposure", "default-login", "unauth"],
        severity=["critical", "high", "medium", "low"],
        rate_limit=200,
        bulk_size=30,
        headless=False,
    ),
    "recon": dict(
        name="recon-sweep",
        tags=["tech", "token", "exposure", "dns"],
        severity=["info", "low", "medium"],
        rate_limit=250,
        bulk_size=50,
        headless=False,
    ),
    "privacy": dict(
        name="privacy-audit",
        tags=["exposure", "token", "misconfig", "unauth"],
        severity=["critical", "high", "medium"],
        rate_limit=150,
        bulk_size=25,
        headless=False,
    ),
    "pentest": dict(
        name="pentest",
        tags=["cve", "rce", "sqli", "xss", "ssrf", "misconfig"],
        severity=["critical", "high", "medium"],
        rate_limit=150,
        bulk_size=25,
        headless=False,
    ),
}


@dataclass
class ScanProfile:
    """Maps a CIPHER domain to Nuclei scan configuration."""

    name: str = "pentest"
    tags: list[str] = field(default_factory=list)
    severity: list[str] = field(default_factory=list)
    rate_limit: int = 150
    bulk_size: int = 25
    headless: bool = False
    extra_args: list[str] = field(default_factory=list)

    @classmethod
    def from_domain(cls, domain: str) -> ScanProfile:
        """Build a ScanProfile from a CIPHER domain name."""
        cfg = _PROFILE_CONFIGS.get(domain.lower().strip(), _PROFILE_CONFIGS["pentest"])
        return cls(
            name=cfg["name"],
            tags=cfg["tags"],
            severity=cfg["severity"],
            rate_limit=cfg["rate_limit"],
            bulk_size=cfg["bulk_size"],
            headless=cfg["headless"],
        )


# ---------------------------------------------------------------------------
# NucleiRunner
# ---------------------------------------------------------------------------


class NucleiRunner:
    """Subprocess wrapper for ProjectDiscovery Nuclei."""

    def __init__(
        self, nuclei_path: str = "nuclei", templates_dir: str = "", output_dir: str = ""
    ) -> None:
        self.nuclei_path = nuclei_path
        self.templates_dir = templates_dir
        self.output_dir = output_dir
        self._resolved = shutil.which(nuclei_path)

    @property
    def available(self) -> bool:
        return self._resolved is not None

    def _fail(self, target: str) -> ScanResult:
        return ScanResult(
            target=target,
            success=False,
            errors=[_TOOL_MISSING.format(tool="nuclei", path=self.nuclei_path)],
        )

    def scan(
        self,
        target: str,
        profile: str | ScanProfile = "pentest",
        tags: list[str] | None = None,
        severity: list[str] | None = None,
        timeout: int = _DEFAULT_TIMEOUT,
    ) -> ScanResult:
        """Run Nuclei against a target using a named scan profile."""
        if not self.available:
            return self._fail(target)
        if isinstance(profile, str):
            sp = ScanProfile.from_domain(profile)
        else:
            sp = profile
        eff_tags = list(set((tags or []) + sp.tags))
        eff_sev = severity or sp.severity

        cmd = [self._resolved or self.nuclei_path, "-jsonl", "-silent"]
        if self.templates_dir:
            cmd.extend(["-t", self.templates_dir])
        cmd.extend(["-u", target])
        if eff_tags:
            cmd.extend(["-tags", ",".join(eff_tags)])
        if eff_sev:
            cmd.extend(["-severity", ",".join(eff_sev)])
        cmd.extend(["-rl", str(sp.rate_limit), "-bs", str(sp.bulk_size)])
        if sp.headless:
            cmd.append("-headless")
        return self._execute(cmd, target, timeout)

    def scan_with_templates(
        self,
        target: str,
        template_paths: list[str] | None = None,
        timeout: int = _DEFAULT_TIMEOUT,
    ) -> ScanResult:
        """Run Nuclei with explicit template paths."""
        if not self.available:
            return self._fail(target)
        cmd = [self._resolved or self.nuclei_path, "-jsonl", "-silent", "-u", target]
        for tp in template_paths or []:
            cmd.extend(["-t", tp])
        return self._execute(cmd, target, timeout)

    def list_templates(
        self, tags: list[str] | None = None, severity: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """Enumerate available Nuclei templates."""
        if not self.available:
            logger.warning(_TOOL_MISSING.format(tool="nuclei", path=self.nuclei_path))
            return []
        cmd = [self._resolved or self.nuclei_path, "-tl", "-jsonl"]
        if tags:
            cmd.extend(["-tags", ",".join(tags)])
        if severity:
            cmd.extend(["-severity", ",".join(severity)])
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            results: list[dict[str, Any]] = []
            for line in proc.stdout.strip().splitlines():
                line = line.strip()
                if line.startswith("{"):
                    try:
                        results.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
                elif line:
                    results.append({"id": line})
            return results
        except (subprocess.TimeoutExpired, OSError) as exc:
            logger.error("Template listing failed: %s", exc)
            return []

    def validate_templates(self, template_dir: str) -> dict[str, Any]:
        """Validate Nuclei template syntax in a directory."""
        if not self.available:
            return {
                "valid": False,
                "count": 0,
                "errors": [_TOOL_MISSING.format(tool="nuclei", path=self.nuclei_path)],
            }
        try:
            proc = subprocess.run(
                [self._resolved or self.nuclei_path, "-validate", "-t", template_dir],
                capture_output=True,
                text=True,
                timeout=120,
            )
            errors = [ln for ln in proc.stderr.splitlines() if "error" in ln.lower()]
            return {
                "valid": proc.returncode == 0 and not errors,
                "count": len([ln for ln in proc.stdout.splitlines() if ln.strip()]),
                "errors": errors,
            }
        except (subprocess.TimeoutExpired, OSError) as exc:
            return {"valid": False, "count": 0, "errors": [str(exc)]}

    def _execute(self, cmd: list[str], target: str, timeout: int) -> ScanResult:
        """Run a Nuclei command and parse JSONL output."""
        cmd_str = " ".join(cmd)
        logger.info("Running: %s", cmd_str)
        start = datetime.now(timezone.utc)
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return ScanResult(
                target=target,
                command=cmd_str,
                errors=[f"Scan timed out after {timeout}s"],
            )
        except OSError as exc:
            return ScanResult(
                target=target,
                command=cmd_str,
                errors=[f"Failed to execute nuclei: {exc}"],
            )

        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        findings: list[Finding] = []
        parse_errors: list[str] = []
        for line in proc.stdout.strip().splitlines():
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                findings.append(Finding.from_nuclei_json(json.loads(line)))
            except (json.JSONDecodeError, KeyError) as exc:
                parse_errors.append(f"Parse error: {exc}")

        stderr_errs = [
            ln
            for ln in (proc.stderr or "").splitlines()
            if ln.strip() and "error" in ln.lower()
        ]
        sev_counts: dict[str, int] = {}
        for f in findings:
            sev_counts[f.severity] = sev_counts.get(f.severity, 0) + 1

        return ScanResult(
            target=target,
            findings=findings,
            stats={"total": len(findings), **sev_counts},
            errors=parse_errors + stderr_errs,
            command=cmd_str,
            duration_seconds=round(elapsed, 2),
            success=proc.returncode == 0,
        )


# ---------------------------------------------------------------------------
# KatanaRunner
# ---------------------------------------------------------------------------


class KatanaRunner:
    """Subprocess wrapper for ProjectDiscovery Katana web crawler."""

    def __init__(self, katana_path: str = "katana") -> None:
        self.katana_path = katana_path
        self._resolved = shutil.which(katana_path)

    @property
    def available(self) -> bool:
        return self._resolved is not None

    def _fail(self, target: str) -> CrawlResult:
        return CrawlResult(
            target=target,
            success=False,
            errors=[_TOOL_MISSING.format(tool="katana", path=self.katana_path)],
        )

    def crawl(
        self,
        target: str,
        depth: int = 3,
        headless: bool = False,
        scope: str = "",
        js_crawl: bool = True,
        timeout: int = _DEFAULT_TIMEOUT,
    ) -> CrawlResult:
        """Crawl a target with Katana, returning discovered URLs and assets."""
        if not self.available:
            return self._fail(target)

        cmd = [
            self._resolved or self.katana_path,
            "-u",
            target,
            "-d",
            str(depth),
            "-jsonl",
            "-silent",
        ]
        if headless:
            cmd.append("-headless")
        if scope:
            cmd.extend(["-cs", scope])
        if js_crawl:
            cmd.append("-jc")

        cmd_str = " ".join(cmd)
        logger.info("Running: %s", cmd_str)
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return CrawlResult(
                target=target,
                command=cmd_str,
                errors=[f"Crawl timed out after {timeout}s"],
            )
        except OSError as exc:
            return CrawlResult(
                target=target,
                command=cmd_str,
                errors=[f"Failed to execute katana: {exc}"],
            )

        urls: list[str] = []
        endpoints: list[str] = []
        forms: list[dict[str, Any]] = []
        js_files: list[str] = []
        api_indicators = ("/api/", "/v1/", "/v2/", "/v3/", "/graphql", "/rest/")

        for line in proc.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            url = line
            if line.startswith("{"):
                try:
                    entry = json.loads(line)
                    url = entry.get("request", {}).get("endpoint", line)
                    if entry.get("request", {}).get("method", "").upper() == "POST":
                        forms.append(
                            {
                                "url": url,
                                "method": "POST",
                                "body": entry.get("request", {}).get("body", ""),
                            }
                        )
                except json.JSONDecodeError:
                    pass
            urls.append(url)
            lower = url.lower()
            if lower.endswith((".js", ".mjs")):
                js_files.append(url)
            if any(ind in lower for ind in api_indicators):
                endpoints.append(url)

        return CrawlResult(
            target=target,
            urls=sorted(set(urls)),
            endpoints=sorted(set(endpoints)),
            forms=forms,
            js_files=sorted(set(js_files)),
            command=cmd_str,
            success=proc.returncode == 0,
        )

    def extract_endpoints(
        self, target: str, timeout: int = _DEFAULT_TIMEOUT
    ) -> list[str]:
        """Crawl and return only API-like endpoints."""
        return self.crawl(target, depth=2, js_crawl=True, timeout=timeout).endpoints


# ---------------------------------------------------------------------------
# ScanPipeline
# ---------------------------------------------------------------------------

# File-extension → Nuclei tag mapping for PR scans
_EXT_TAG_MAP: dict[str, list[str]] = {
    ".yaml": ["misconfig"],
    ".yml": ["misconfig"],
    ".json": ["misconfig", "exposure"],
    ".toml": ["misconfig"],
    ".env": ["exposure", "token"],
    ".py": ["sqli", "xss", "ssrf", "rce"],
    ".js": ["sqli", "xss", "ssrf", "rce", "prototype-pollution"],
    ".ts": ["sqli", "xss", "ssrf", "rce"],
    ".go": ["sqli", "ssrf", "rce"],
    ".java": ["sqli", "xss", "ssrf", "rce", "deserialization"],
    ".php": ["sqli", "xss", "ssrf", "rce", "lfi"],
    ".rb": ["sqli", "xss", "ssrf", "rce"],
    ".tf": ["misconfig", "exposure"],
    ".dockerfile": ["misconfig"],
}


class ScanPipeline:
    """Orchestrates Katana crawl → Nuclei scan → CipherMemory storage."""

    def __init__(
        self, nuclei: NucleiRunner, katana: KatanaRunner, memory: Any = None
    ) -> None:
        self.nuclei = nuclei
        self.katana = katana
        self.memory = memory

    def full_scan(
        self,
        target: str,
        profile: str = "pentest",
        engagement_id: str = "",
    ) -> PipelineResult:
        """Full pipeline: crawl → scan → store findings."""
        errors: list[str] = []

        crawl_result = self.katana.crawl(target)
        if not crawl_result.success:
            errors.extend(crawl_result.errors)
            logger.warning("Crawl failed/unavailable, scanning target directly")

        scan_result = self.nuclei.scan(target, profile=profile)
        if not scan_result.success:
            errors.extend(scan_result.errors)

        stored = self._store_findings(scan_result.findings, target, "full_scan")
        return PipelineResult(
            target=target,
            crawl=crawl_result,
            scan=scan_result,
            stored_entry_ids=stored,
            errors=errors,
            success=scan_result.success,
        )

    def pr_scan(
        self, repo_url: str, pr_number: int, changed_files: list[str]
    ) -> PipelineResult:
        """Scan PR changes — derives Nuclei tags from changed file types."""
        tags: set[str] = set()
        for fpath in changed_files:
            suffix = Path(fpath).suffix.lower()
            tags.update(_EXT_TAG_MAP.get(suffix, []))
            if Path(fpath).name.lower() in ("dockerfile", "docker-compose.yml"):
                tags.update(["misconfig", "exposure"])
        eff_tags = sorted(tags) if tags else ["cve", "misconfig"]

        scan_result = self.nuclei.scan(repo_url, profile="pentest", tags=eff_tags)
        stored = self._store_findings(
            scan_result.findings, repo_url, f"pr_scan:PR-{pr_number}"
        )
        return PipelineResult(
            target=repo_url,
            scan=scan_result,
            stored_entry_ids=stored,
            errors=scan_result.errors,
            success=scan_result.success,
        )

    def regression_scan(self, engagement_id: str) -> PipelineResult:
        """Re-run scans for prior engagement findings to verify remediation."""
        if self.memory is None:
            return PipelineResult(
                target=engagement_id,
                success=False,
                errors=["No CipherMemory — cannot load prior findings"],
            )
        try:
            prior = self.memory.search(
                query="", engagement_id=engagement_id, memory_type="finding", limit=500
            )
        except Exception as exc:
            return PipelineResult(
                target=engagement_id,
                success=False,
                errors=[f"Memory search failed: {exc}"],
            )
        if not prior:
            return PipelineResult(
                target=engagement_id,
                success=False,
                errors=[f"No prior findings for engagement {engagement_id}"],
            )

        targets: set[str] = set()
        for entry in prior:
            targets.update(getattr(entry, "targets", []))
        if not targets:
            return PipelineResult(
                target=engagement_id,
                success=False,
                errors=["Prior findings have no target metadata"],
            )

        all_findings: list[Finding] = []
        errors: list[str] = []
        for t in targets:
            result = self.nuclei.scan(t, profile="pentest")
            all_findings.extend(result.findings)
            errors.extend(result.errors)

        combined = ScanResult(
            target=engagement_id,
            findings=all_findings,
            stats={"total": len(all_findings)},
            errors=errors,
            success=True,
        )
        stored = self._store_findings(
            all_findings, engagement_id, f"regression:{engagement_id}"
        )
        return PipelineResult(
            target=engagement_id,
            scan=combined,
            stored_entry_ids=stored,
            errors=errors,
            success=True,
        )

    def _store_findings(
        self, findings: list[Finding], target: str, context: str
    ) -> list[str]:
        """Persist findings to CipherMemory. Returns stored entry IDs."""
        if self.memory is None or not findings:
            return []
        try:
            from memory.core.engine import MemoryEntry, MemoryType
        except ImportError:
            logger.warning("CipherMemory import failed — findings not stored")
            return []

        stored: list[str] = []
        for f in findings:
            entry = MemoryEntry(
                entry_id=str(uuid.uuid4()),
                content=f"[{f.severity.upper()}] {f.name} at "
                f"{f.matched_at or f.host}: {f.description}",
                memory_type=MemoryType.FINDING,
                targets=[f.host] if f.host else [target],
                severity=f.severity,
                cve_ids=f.cve_ids,
                tags=f.tags + [context],
                keywords=[f.template_id, f.name, f.severity],
            )
            try:
                stored.append(self.memory.store(entry))
            except Exception as exc:
                logger.error("Failed to store finding %s: %s", f.name, exc)
        logger.info(
            "Stored %d/%d findings from %s", len(stored), len(findings), context
        )
        return stored
