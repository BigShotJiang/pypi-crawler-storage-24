# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""Async scanning pipeline for non-blocking server-context scans.

Provides asyncio-based wrappers around NucleiRunner and KatanaRunner
for use in the API server where blocking subprocess calls would stall
the request handler.

Architecture and implementation are original CIPHER designs.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import time
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class AsyncScanStatus(Enum):
    """Status of an async scan job."""

    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class AsyncFinding:
    """A finding from an async scan."""

    id: str = ""
    name: str = ""
    severity: str = "info"
    url: str = ""
    description: str = ""
    matched_at: str = ""
    template: str = ""
    timestamp: float = 0.0


@dataclass
class AsyncScanResult:
    """Result of an async scan job."""

    scan_id: str
    target: str
    status: AsyncScanStatus = AsyncScanStatus.QUEUED
    findings: list[AsyncFinding] = field(default_factory=list)
    started_at: float = 0.0
    completed_at: float = 0.0
    error: str = ""
    profile: str = "standard"
    total_requests: int = 0


class AsyncNucleiRunner:
    """Async wrapper around nuclei binary."""

    def __init__(self, binary: str = "nuclei", timeout: int = 300) -> None:
        self.binary = binary
        self.timeout = timeout
        self._available: bool | None = None

    def is_available(self) -> bool:
        """Check if nuclei binary is in PATH."""
        if self._available is None:
            self._available = shutil.which(self.binary) is not None
        return self._available

    async def scan(
        self,
        target: str,
        severity: str = "medium,high,critical",
        templates: str = "",
        rate_limit: int = 150,
    ) -> list[AsyncFinding]:
        """Run nuclei scan asynchronously."""
        if not self.is_available():
            raise RuntimeError("nuclei binary not found in PATH")

        cmd = [
            self.binary,
            "-target",
            target,
            "-severity",
            severity,
            "-rate-limit",
            str(rate_limit),
            "-jsonl",
            "-silent",
        ]
        if templates:
            cmd.extend(["-t", templates])

        findings: list[AsyncFinding] = []
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self.timeout
            )

            if stdout:
                for line in stdout.decode().strip().splitlines():
                    try:
                        data = json.loads(line)
                        findings.append(
                            AsyncFinding(
                                id=data.get("template-id", ""),
                                name=data.get("info", {}).get("name", ""),
                                severity=data.get("info", {}).get("severity", "info"),
                                url=data.get("matched-at", target),
                                description=data.get("info", {}).get("description", ""),
                                matched_at=data.get("matched-at", ""),
                                template=data.get("template", ""),
                                timestamp=time.time(),
                            )
                        )
                    except json.JSONDecodeError:
                        continue

        except asyncio.TimeoutError:
            logger.warning(
                "Nuclei scan timed out after %ds for %s", self.timeout, target
            )
        except Exception as exc:
            logger.error("Nuclei scan error: %s", exc)
            raise

        return findings


class AsyncKatanaRunner:
    """Async wrapper around katana binary."""

    def __init__(self, binary: str = "katana", timeout: int = 120) -> None:
        self.binary = binary
        self.timeout = timeout
        self._available: bool | None = None

    def is_available(self) -> bool:
        if self._available is None:
            self._available = shutil.which(self.binary) is not None
        return self._available

    async def crawl(
        self,
        target: str,
        depth: int = 3,
        concurrency: int = 10,
    ) -> list[str]:
        """Run katana crawl asynchronously and return discovered URLs."""
        if not self.is_available():
            raise RuntimeError("katana binary not found in PATH")

        cmd = [
            self.binary,
            "-u",
            target,
            "-depth",
            str(depth),
            "-concurrency",
            str(concurrency),
            "-silent",
        ]

        urls: list[str] = []
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            if stdout:
                urls = [
                    u.strip() for u in stdout.decode().strip().splitlines() if u.strip()
                ]
        except asyncio.TimeoutError:
            logger.warning(
                "Katana crawl timed out after %ds for %s", self.timeout, target
            )
        except Exception as exc:
            logger.error("Katana crawl error: %s", exc)
            raise

        return urls


class AsyncScanManager:
    """Manages async scan jobs with queue and status tracking."""

    def __init__(self, max_concurrent: int = 3) -> None:
        self.max_concurrent = max_concurrent
        self._jobs: dict[str, AsyncScanResult] = {}
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._nuclei = AsyncNucleiRunner()
        self._katana = AsyncKatanaRunner()

    def submit_scan(
        self,
        scan_id: str,
        target: str,
        profile: str = "standard",
    ) -> AsyncScanResult:
        """Submit a scan job. Returns immediately with QUEUED status."""
        result = AsyncScanResult(
            scan_id=scan_id,
            target=target,
            profile=profile,
        )
        self._jobs[scan_id] = result
        return result

    async def run_scan(self, scan_id: str) -> AsyncScanResult:
        """Execute a scan job asynchronously."""
        result = self._jobs.get(scan_id)
        if not result:
            raise KeyError(f"Scan {scan_id} not found")

        async with self._semaphore:
            result.status = AsyncScanStatus.RUNNING
            result.started_at = time.time()

            try:
                # Run nuclei scan
                if self._nuclei.is_available():
                    findings = await self._nuclei.scan(
                        result.target,
                        severity=self._severity_for_profile(result.profile),
                    )
                    result.findings = findings
                else:
                    result.error = "nuclei not available"

                result.status = AsyncScanStatus.COMPLETED
            except Exception as exc:
                result.status = AsyncScanStatus.FAILED
                result.error = str(exc)

            result.completed_at = time.time()

        return result

    def get_status(self, scan_id: str) -> AsyncScanResult | None:
        """Get current status of a scan job."""
        return self._jobs.get(scan_id)

    def get_all_jobs(self) -> dict[str, dict]:
        """Get summary of all jobs."""
        return {
            sid: {
                "scan_id": r.scan_id,
                "target": r.target,
                "status": r.status.value,
                "findings_count": len(r.findings),
                "error": r.error,
            }
            for sid, r in self._jobs.items()
        }

    def cancel_scan(self, scan_id: str) -> bool:
        """Cancel a queued scan."""
        result = self._jobs.get(scan_id)
        if result and result.status == AsyncScanStatus.QUEUED:
            result.status = AsyncScanStatus.CANCELLED
            return True
        return False

    @staticmethod
    def _severity_for_profile(profile: str) -> str:
        """Map scan profile to severity filter."""
        return {
            "quick": "critical,high",
            "standard": "medium,high,critical",
            "deep": "info,low,medium,high,critical",
            "pentest": "info,low,medium,high,critical",
        }.get(profile, "medium,high,critical")


# Convenience function for one-shot async scans
async def async_scan(
    target: str,
    profile: str = "standard",
    scan_id: str = "",
) -> dict:
    """Run a one-shot async scan and return results."""
    import secrets

    if not scan_id:
        scan_id = f"scan-{secrets.token_hex(4)}"

    mgr = AsyncScanManager()
    mgr.submit_scan(scan_id, target, profile)
    result = await mgr.run_scan(scan_id)

    return {
        "scan_id": result.scan_id,
        "target": result.target,
        "status": result.status.value,
        "profile": result.profile,
        "findings": [
            {
                "id": f.id,
                "name": f.name,
                "severity": f.severity,
                "url": f.url,
                "description": f.description,
            }
            for f in result.findings
        ],
        "total_findings": len(result.findings),
        "duration_s": round(result.completed_at - result.started_at, 2)
        if result.completed_at
        else 0,
        "error": result.error,
    }
