<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: threat-model
description: Template for structured threat modeling
version: "1.0"
---

# Threat Model — [SYSTEM/APPLICATION NAME]

## Document Control
| Field | Value |
|-------|-------|
| System Owner | [Name] |
| Modeled By | [Name] |
| Date | [YYYY-MM-DD] |
| Review Cycle | Annually or on major change |

---

## 1. System Description

### Purpose
[What does this system do? What data does it process?]

### Data Classification
| Data Type | Classification | Regulation |
|-----------|---------------|------------|
| [User PII] | Restricted | GDPR, CCPA |
| [Payment data] | Restricted | PCI DSS |
| [Business data] | Confidential | Internal |

### Architecture Diagram

```mermaid
graph LR
    User[User/Browser] -->|HTTPS| LB[Load Balancer]
    LB --> App[Application Server]
    App --> DB[(Database)]
    App --> Cache[(Redis Cache)]
    App --> ExtAPI[External API]
    Admin[Admin] -->|VPN + MFA| Mgmt[Management Interface]
    Mgmt --> App

    subgraph Trust Boundary: Internet
        User
    end
    subgraph Trust Boundary: DMZ
        LB
    end
    subgraph Trust Boundary: Internal
        App
        DB
        Cache
        Mgmt
    end
    subgraph Trust Boundary: External
        ExtAPI
    end
```

### Trust Boundaries
| Boundary | Components Inside | Access Control |
|----------|------------------|----------------|
| Internet | End users, public clients | WAF, rate limiting |
| DMZ | Load balancer, reverse proxy | Firewall, TLS termination |
| Internal | App servers, databases, cache | Network segmentation, IAM |
| Management | Admin interfaces, CI/CD | VPN + MFA, PAW |
| External | Third-party APIs, SaaS | mTLS, API keys |

---

## 2. STRIDE Analysis

### Per-Component Assessment

| Component | S | T | R | I | D | E | Notes |
|-----------|---|---|---|---|---|---|-------|
| Load Balancer | ○ | ○ | ○ | ● | ● | ○ | TLS termination, DDoS target |
| Application | ● | ● | ● | ● | ● | ● | Primary attack surface |
| Database | ○ | ● | ● | ● | ● | ● | Data at rest, SQL injection |
| Redis Cache | ○ | ● | ○ | ● | ● | ○ | Session data, no auth default |
| External API | ● | ● | ○ | ● | ● | ○ | Supply chain risk |
| Admin Interface | ● | ● | ● | ● | ○ | ● | Highest privilege target |

● = Applicable threat  ○ = Low/not applicable

### Threat Catalog

| ID | STRIDE | Component | Threat | Likelihood | Impact | Risk |
|----|--------|-----------|--------|-----------|--------|------|
| T-001 | Spoofing | App | Credential stuffing against login | High | High | **Critical** |
| T-002 | Tampering | App | SQL injection modifies data | Medium | Critical | **High** |
| T-003 | Repudiation | App | Insufficient audit logging | Medium | Medium | **Medium** |
| T-004 | Info Disclosure | DB | Database backup exposed | Low | Critical | **High** |
| T-005 | DoS | LB | DDoS exhausts resources | High | High | **Critical** |
| T-006 | Elevation | Admin | SSRF from app to admin interface | Low | Critical | **High** |
| T-007 | Spoofing | ExtAPI | Malicious response from compromised API | Low | High | **Medium** |
| T-008 | Info Disclosure | Cache | Redis exposed without auth | Medium | High | **High** |

---

## 3. DREAD Scoring

| ID | Damage | Reproducibility | Exploitability | Affected Users | Discoverability | Score | Rating |
|----|--------|----------------|----------------|----------------|-----------------|-------|--------|
| T-001 | 8 | 9 | 7 | 9 | 8 | **8.2** | High |
| T-002 | 9 | 6 | 5 | 8 | 6 | **6.8** | Medium |
| T-005 | 7 | 9 | 8 | 10 | 9 | **8.6** | High |
| T-008 | 8 | 8 | 9 | 7 | 5 | **7.4** | High |

---

## 4. Mitigations

| Threat ID | Mitigation | Control Type | Owner | Status |
|-----------|------------|-------------|-------|--------|
| T-001 | MFA + rate limiting + account lockout | Preventive | IAM Team | ☐ Planned |
| T-002 | Parameterized queries + WAF SQLi rules | Preventive | Dev Team | ☑ Implemented |
| T-003 | Structured audit logging to SIEM | Detective | SecOps | ☐ In Progress |
| T-004 | Encrypt backups + restrict access | Preventive | DBA Team | ☐ Planned |
| T-005 | CDN + DDoS mitigation service | Preventive | Infra Team | ☑ Implemented |
| T-006 | Network segmentation + SSRF filters | Preventive | Dev Team | ☐ Planned |
| T-007 | Input validation on API responses | Preventive | Dev Team | ☐ Planned |
| T-008 | Redis AUTH + bind to internal IP | Preventive | Infra Team | ☐ Planned |

---

## 5. Residual Risk

| Risk | After Mitigation | Acceptance |
|------|-----------------|------------|
| Credential stuffing at scale | Low (MFA blocks 99%+) | Accepted |
| Zero-day in framework | Medium (WAF + detection) | Accepted with monitoring |
| Insider threat | Medium (audit logging) | Accepted with access reviews |

---

## 6. Review Schedule

- [ ] Review after any architecture change
- [ ] Review after any security incident
- [ ] Annual review (minimum)
- [ ] Review when new threat intelligence is relevant
