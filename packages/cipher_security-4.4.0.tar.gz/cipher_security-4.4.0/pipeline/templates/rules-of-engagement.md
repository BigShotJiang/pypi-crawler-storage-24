<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: rules-of-engagement
description: Template for engagement authorization and scope definition
version: "1.0"
---

# Rules of Engagement — [ENGAGEMENT NAME]

## Document Control

| Field | Value |
|-------|-------|
| Client | [Organization Name] |
| Engagement Lead | [Name] |
| Start Date | [YYYY-MM-DD] |
| End Date | [YYYY-MM-DD] |
| Document Version | 1.0 |
| Classification | CONFIDENTIAL |

## 1. Engagement Overview

**Type:** [ ] Penetration Test  [ ] Red Team  [ ] Vulnerability Assessment  [ ] Architecture Review  [ ] Incident Response

**Objective:**
[Describe what this engagement aims to achieve]

**Threat Profile:**
[ ] External attacker (unauthenticated)
[ ] Compromised insider (standard user credentials)
[ ] Privileged insider (admin credentials)
[ ] Supply chain compromise (vendor access)

## 2. Scope

### In Scope
| Asset Type | Details | Notes |
|-----------|---------|-------|
| Networks | [IP ranges] | |
| Domains | [domain list] | |
| Applications | [app names/URLs] | |
| Cloud | [AWS accounts, Azure subscriptions] | |
| Physical | [buildings, offices] | |

### Explicitly Out of Scope
| Asset | Reason |
|-------|--------|
| [asset] | [reason for exclusion] |

### Authorized Techniques
- [ ] Network scanning and enumeration
- [ ] Web application testing
- [ ] Social engineering (email phishing)
- [ ] Social engineering (phone/vishing)
- [ ] Physical security testing
- [ ] Wireless testing
- [ ] Cloud infrastructure testing
- [ ] Password attacks (online brute force)
- [ ] Password attacks (offline cracking)
- [ ] Exploitation of identified vulnerabilities
- [ ] Post-exploitation / lateral movement
- [ ] Data access demonstration
- [ ] Denial of Service testing (NEVER without explicit approval)

### Prohibited Activities
- Testing outside defined scope
- Destructive attacks or data modification
- Accessing actual customer/patient/financial data
- Social engineering of non-authorized personnel
- Physical intrusion without explicit authorization
- Any activity that could cause service outage

## 3. Testing Window

| Parameter | Value |
|-----------|-------|
| Testing hours | [e.g., Mon-Fri 08:00-18:00 EST] |
| Blackout periods | [e.g., month-end processing, 25th-1st] |
| Change freeze dates | [dates when no testing allowed] |
| Weekend/holiday testing | [ ] Authorized  [ ] Not authorized |

## 4. Communication

### Status Updates
| Frequency | Method | Recipient |
|-----------|--------|-----------|
| [Daily/Weekly] | [Email/Slack/Call] | [Name] |

### Critical Finding Notification
**Threshold:** CVSS ≥ 9.0 or active exploitation evidence
**Method:** Phone call within [1 hour] of discovery
**Contact:** [Name, Phone, Email]

### Escalation Matrix
| Severity | Contact | Method | Timeline |
|----------|---------|--------|----------|
| Critical | [CISO Name] | Phone | Immediate |
| High | [Security Lead] | Email + Phone | 4 hours |
| Operational Issue | [IT Ops] | Phone | Immediate |
| Scope Question | [PM Name] | Email | 24 hours |

## 5. Emergency Procedures

**If testing causes unintended impact:**
1. Stop testing immediately
2. Call emergency contact: [Name] at [Phone]
3. Document what happened (timestamp, action, impact)
4. Do not attempt to fix without client authorization
5. Preserve all evidence

**If active threat actor discovered during testing:**
1. Stop testing, preserve evidence
2. Notify client security team immediately
3. Assist with IR if requested and authorized
4. Document all observations with timestamps

## 6. Data Handling

| Parameter | Requirement |
|-----------|-------------|
| Data classification | [CONFIDENTIAL] |
| Encryption in transit | TLS 1.2+ / GPG encrypted email |
| Encryption at rest | AES-256 full disk encryption |
| Data retention | [30/60/90 days post-report delivery] |
| Data destruction | NIST 800-88 compliant deletion |
| Data location | [Country/region restrictions] |
| Report delivery | [Encrypted email / secure portal] |

## 7. Authorization

By signing below, [Organization Name] authorizes [Tester/Company] to perform the security assessment described in this document within the defined scope and testing window.

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Client Authorizer | | | |
| Engagement Lead | | | |
| Legal/Compliance | | | |
