<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: ir-runbook
description: Template for incident response runbooks
version: "1.0"
---

# Incident Response Runbook — [INCIDENT TYPE]

## Document Control
| Field | Value |
|-------|-------|
| Author | [Name] |
| Last Updated | [YYYY-MM-DD] |
| Review Cycle | Quarterly |
| Classification | INTERNAL |

---

## Triage (0-15 minutes)

### Initial Assessment
- [ ] What triggered the alert? (Source, rule, indicator)
- [ ] When was the activity first detected?
- [ ] What systems are affected? (IPs, hostnames, users)
- [ ] Is the threat still active? (ongoing vs. historical)
- [ ] Initial severity: [ ] Critical  [ ] High  [ ] Medium  [ ] Low

### Severity Classification
| Severity | Criteria | Response Time |
|----------|----------|---------------|
| Critical | Active data breach, ransomware spreading, APT confirmed | Immediate all-hands |
| High | Confirmed compromise, malware execution, credential theft | 1 hour |
| Medium | Suspicious activity, policy violation, potential IOC match | 4 hours |
| Low | Reconnaissance, single failed auth, info-level alert | 24 hours |

### Immediate Actions
1. **Do NOT** power off affected systems (preserve volatile evidence)
2. Notify incident commander: [Name, Phone]
3. Begin evidence preservation (see next section)
4. Open incident ticket: [System/URL]
5. Start incident timeline log

---

## Evidence Preservation (15-60 minutes)

### Order of Collection (RFC 3227 — most volatile first)
```bash
# 1. Memory dump (HIGHEST PRIORITY)
# Linux:
sudo avml /evidence/$(hostname)_memory_$(date +%Y%m%d_%H%M%S).lime

# Windows:
winpmem_mini_x64.exe \\evidence\$(hostname)_memory_%date%.raw

# 2. Network state
ss -tulnp > /evidence/$(hostname)_netstat.txt       # Linux
netstat -anob > \\evidence\netstat.txt               # Windows

# 3. Running processes
ps auxf > /evidence/$(hostname)_processes.txt        # Linux
tasklist /v > \\evidence\processes.txt               # Windows
wmic process get Caption,CommandLine,ProcessId > \\evidence\wmic_procs.txt

# 4. Disk image (if warranted)
dc3dd if=/dev/sda of=/evidence/$(hostname)_disk.dd hash=sha256 log=hash.log
```

### Chain of Custody
For each evidence item, document:
- Evidence ID: [E-001]
- Description: [Memory dump from web-server-01]
- Collected by: [Name]
- Date/time: [ISO 8601]
- Hash (SHA-256): [hash value]
- Storage location: [path/container]

---

## Containment

### Network Containment
- [ ] Block attacker IP(s) at firewall: `[IP addresses]`
- [ ] Block C2 domain(s) at DNS/proxy: `[domains]`
- [ ] Isolate affected system(s) from network (VLAN change, not cable pull)
- [ ] Disable VPN access for compromised accounts
- [ ] Enable enhanced logging on adjacent systems

### Account Containment
- [ ] Disable compromised user account(s)
- [ ] Reset passwords for affected accounts
- [ ] Revoke active sessions/tokens
- [ ] Reset service account credentials (if compromised)
- [ ] Enable MFA on all accounts in blast radius

### Endpoint Containment
- [ ] Deploy EDR containment (network isolation via agent)
- [ ] Block malicious hashes across fleet
- [ ] Quarantine malicious files
- [ ] Disable autorun/scheduled tasks used for persistence

---

## Eradication

### Remove Threat Presence
- [ ] Identify and remove all malware/implants
- [ ] Remove persistence mechanisms (scheduled tasks, services, registry)
- [ ] Remove unauthorized accounts created by attacker
- [ ] Patch exploited vulnerability
- [ ] Verify removal with IOC sweep across environment

### Root Cause
- [ ] How did the attacker gain initial access?
- [ ] What vulnerability/misconfiguration was exploited?
- [ ] How long was the attacker present? (dwell time)
- [ ] What data was accessed or exfiltrated?

---

## Recovery

### System Restoration
- [ ] Rebuild from known-good image (preferred) or restore from clean backup
- [ ] Apply all current patches before reconnecting
- [ ] Verify system integrity (file hashes, config comparison)
- [ ] Reconnect to network with enhanced monitoring
- [ ] Monitor for re-infection indicators (48-72 hours)

### Service Validation
- [ ] Application functionality verified
- [ ] Authentication working correctly
- [ ] No unauthorized changes persist
- [ ] Logging and monitoring operational
- [ ] Users notified of service restoration

---

## Post-Incident (within 5 business days)

### After-Action Report
1. **Timeline** — Chronological event reconstruction
2. **Root cause** — How the incident occurred
3. **Impact** — Systems affected, data at risk, business impact
4. **Response** — What worked, what didn't
5. **Lessons learned** — Process improvements
6. **Detection gaps** — What should have caught this sooner
7. **Action items** — Specific tasks with owners and deadlines

### Detection Improvements
- [ ] New detection rule created for initial access vector
- [ ] New detection rule created for observed TTPs
- [ ] Existing rules tuned (reduce false positives/negatives)
- [ ] IOCs shared with threat intelligence team
- [ ] Sigma/YARA rules published internally

### Notification Requirements
| Trigger | Notification | Timeline | Owner |
|---------|-------------|----------|-------|
| PII breach (>500 records) | HHS/State AG | 60 days (HIPAA) / varies | Legal |
| PII breach (EU residents) | Supervisory Authority | 72 hours (GDPR Art. 33) | DPO |
| PCI data breach | Card brands + acquirer | Immediately | Legal |
| Material breach | SEC (8-K) | 4 business days | Legal |
| Law enforcement | FBI IC3 / CISA | Recommended | CISO |

---

## Escalation Triggers

| Condition | Action |
|-----------|--------|
| Ransomware deployment confirmed | Escalate to CISO + Legal + Insurance |
| Active data exfiltration | Escalate to CISO, consider law enforcement |
| APT/nation-state indicators | Escalate to CISO + Legal + law enforcement |
| Customer data confirmed compromised | Escalate to Legal + Privacy + Comms |
| Scope expanding beyond initial systems | Re-assess severity, brief leadership |
| Attacker still active after 4 hours | Engage external IR firm |
