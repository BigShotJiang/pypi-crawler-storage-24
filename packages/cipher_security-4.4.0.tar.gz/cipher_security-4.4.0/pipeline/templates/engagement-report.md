<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: engagement-report
description: Template for final engagement deliverable
version: "1.0"
---

# Security Assessment Report — [ENGAGEMENT NAME]

**Classification:** CONFIDENTIAL
**Report Date:** [YYYY-MM-DD]
**Version:** 1.0

| Field | Value |
|-------|-------|
| Client | [Organization Name] |
| Engagement Type | [Penetration Test / Red Team / Vuln Assessment] |
| Engagement Window | [Start] — [End] |
| Engagement Lead | [Name] |
| Report Author | [Name] |

---

## Executive Summary

### Overall Risk Rating
**[CRITICAL / HIGH / MEDIUM / LOW]**

### Key Findings
[2-3 sentence business-impact summary for executive audience]

| Severity | Count |
|----------|-------|
| Critical | [N] |
| High | [N] |
| Medium | [N] |
| Low | [N] |
| Informational | [N] |

### Top Strategic Recommendations
1. [Highest-impact recommendation with business justification]
2. [Second recommendation]
3. [Third recommendation]

---

## Scope and Methodology

### Scope
[Reference RoE document, summarize in-scope assets]

### Methodology
Testing followed the CIPHER Engagement Pipeline methodology:
1. **Scoping** — Defined boundaries, threat model, and authorization
2. **Reconnaissance** — Mapped attack surface across [N] assets
3. **Assessment** — Identified vulnerabilities via automated + manual testing
4. **Exploitation** — Demonstrated impact through controlled exploitation
5. **Reporting** — This document

### Tools Used
| Category | Tools |
|----------|-------|
| Reconnaissance | [subfinder, nmap, katana, ...] |
| Scanning | [Nuclei, Burp Suite, ...] |
| Exploitation | [Metasploit, Impacket, ...] |
| Post-Exploitation | [BloodHound, Sliver, ...] |

---

## Findings

### Finding Summary Matrix

| ID | Title | Severity | CVSS | CWE | Status |
|----|-------|----------|------|-----|--------|
| F-001 | [Title] | Critical | 9.8 | CWE-89 | Open |
| F-002 | [Title] | High | 7.5 | CWE-287 | Open |

### Detailed Findings

```
[FINDING-001]
Severity    : Critical
CVSS        : 9.8 (AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H)
CWE         : CWE-89 (SQL Injection)
ATT&CK      : T1190 (Exploit Public-Facing Application)
Location    : [URL/IP/file:line]

Description:
[What the vulnerability is and why it exists]

Evidence:
[Screenshot, request/response, command output]

Impact:
[Business and technical impact — what could an attacker achieve?]

Remediation:
[Specific fix with code example or configuration change]

Verification:
[How to verify the fix was applied correctly]

References:
[CVE, advisory, OWASP reference]
```

[Repeat for each finding]

---

## Attack Chains

### Chain 1: [Name — e.g., "External to Domain Admin"]

```
[Step-by-step attack path with evidence at each stage]

1. Initial Access: [Finding F-001] → SQL injection on login form
2. Credential Access: [Finding F-003] → Extracted database credentials
3. Lateral Movement: [Finding F-005] → Reused credentials on internal app
4. Privilege Escalation: [Finding F-007] → Kerberoasted service account
5. Objective: Domain Admin access achieved
```

---

## Remediation Roadmap

### Immediate (0-7 days)
| Finding | Action | Owner | Effort |
|---------|--------|-------|--------|
| F-001 | [Specific remediation] | [Team] | [Hours/Days] |

### Short-term (7-30 days)
| Finding | Action | Owner | Effort |
|---------|--------|-------|--------|
| F-002 | [Specific remediation] | [Team] | [Hours/Days] |

### Medium-term (30-90 days)
| Finding | Action | Owner | Effort |
|---------|--------|-------|--------|
| F-003 | [Specific remediation] | [Team] | [Hours/Days] |

### Strategic (90+ days)
| Recommendation | Business Impact | Effort |
|---------------|----------------|--------|
| [Architecture change] | [Risk reduction] | [Estimate] |

---

## Appendices

### A. Methodology Details
[CIPHER Engagement Pipeline reference]

### B. MITRE ATT&CK Mapping
| Tactic | Technique | Finding(s) |
|--------|-----------|-----------|
| Initial Access | T1190 | F-001 |

### C. Compliance Mapping
| Finding | PCI DSS | NIST CSF | SOC 2 |
|---------|---------|----------|-------|
| F-001 | Req 6.5.1 | PR.IP-12 | CC6.1 |

### D. Retest Scope
[Define what should be retested after remediation]
- Retest date: [Agreed date]
- Findings to verify: [F-001, F-002, ...]
- Estimated retest duration: [Days]
