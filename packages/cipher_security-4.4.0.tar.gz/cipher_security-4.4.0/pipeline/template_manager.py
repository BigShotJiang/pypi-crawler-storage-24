# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""CIPHER Nuclei Template Manager — pull, version, and manage nuclei templates.

Provides template management beyond basic execution:
- Pull/update templates from nuclei-templates repository
- Version templates independently of CIPHER releases
- Custom template generation from scan findings
- Template categorization and search
- Workflow chain composition
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Default template directory
_DEFAULT_TEMPLATE_DIR = Path.home() / ".cipher" / "nuclei-templates"


@dataclass
class TemplateInfo:
    """Metadata about a nuclei template."""

    id: str
    name: str
    severity: str = "info"
    tags: list[str] = field(default_factory=list)
    author: str = ""
    description: str = ""
    reference: list[str] = field(default_factory=list)
    file_path: str = ""
    protocol: str = "http"
    category: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "severity": self.severity,
            "tags": self.tags,
            "author": self.author,
            "description": self.description,
            "reference": self.reference,
            "file_path": self.file_path,
            "protocol": self.protocol,
            "category": self.category,
        }


@dataclass
class TemplateCollection:
    """A collection of nuclei templates with metadata."""

    name: str
    version: str
    templates: list[TemplateInfo] = field(default_factory=list)
    updated_at: str = ""
    source: str = ""

    def __post_init__(self) -> None:
        if not self.updated_at:
            self.updated_at = datetime.now(timezone.utc).isoformat()

    @property
    def count(self) -> int:
        return len(self.templates)

    def by_severity(self, severity: str) -> list[TemplateInfo]:
        return [t for t in self.templates if t.severity == severity]

    def by_tag(self, tag: str) -> list[TemplateInfo]:
        return [t for t in self.templates if tag in t.tags]

    def by_protocol(self, protocol: str) -> list[TemplateInfo]:
        return [t for t in self.templates if t.protocol == protocol]

    def search(self, query: str) -> list[TemplateInfo]:
        q = query.lower()
        return [
            t
            for t in self.templates
            if q in t.id.lower()
            or q in t.name.lower()
            or q in t.description.lower()
            or any(q in tag for tag in t.tags)
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "count": self.count,
            "updated_at": self.updated_at,
            "source": self.source,
            "severity_breakdown": {
                s: len(self.by_severity(s))
                for s in ("critical", "high", "medium", "low", "info")
            },
        }


class NucleiTemplateManager:
    """Manage nuclei templates: pull, update, search, generate."""

    def __init__(self, template_dir: str | Path | None = None) -> None:
        self.template_dir = (
            Path(template_dir) if template_dir else _DEFAULT_TEMPLATE_DIR
        )
        self._nuclei_path = shutil.which("nuclei")
        self._collection: TemplateCollection | None = None

    @property
    def available(self) -> bool:
        return self._nuclei_path is not None

    @property
    def templates_exist(self) -> bool:
        return self.template_dir.exists() and any(self.template_dir.rglob("*.yaml"))

    def pull_templates(self, force: bool = False) -> dict[str, Any]:
        """Pull or update nuclei templates from the official repository.

        Uses `nuclei -update-templates` if nuclei is available,
        otherwise falls back to git clone.
        """
        if self.templates_exist and not force:
            return {
                "status": "already_exists",
                "path": str(self.template_dir),
                "message": "Templates already present. Use force=True to update.",
            }

        self.template_dir.mkdir(parents=True, exist_ok=True)

        # Try nuclei -update-templates first
        if self._nuclei_path:
            try:
                result = subprocess.run(
                    [
                        self._nuclei_path,
                        "-update-templates",
                        "-ud",
                        str(self.template_dir),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if result.returncode == 0:
                    count = len(list(self.template_dir.rglob("*.yaml")))
                    return {
                        "status": "updated",
                        "path": str(self.template_dir),
                        "template_count": count,
                        "method": "nuclei-update",
                    }
            except (subprocess.TimeoutExpired, OSError) as exc:
                logger.warning("nuclei template update failed: %s", exc)

        # Fallback: git clone
        git_path = shutil.which("git")
        if git_path:
            try:
                if (self.template_dir / ".git").exists():
                    subprocess.run(
                        [git_path, "-C", str(self.template_dir), "pull", "--depth=1"],
                        capture_output=True,
                        text=True,
                        timeout=300,
                    )
                else:
                    subprocess.run(
                        [
                            git_path,
                            "clone",
                            "--depth=1",
                            "https://github.com/projectdiscovery/nuclei-templates.git",
                            str(self.template_dir),
                        ],
                        capture_output=True,
                        text=True,
                        timeout=300,
                    )
                count = len(list(self.template_dir.rglob("*.yaml")))
                return {
                    "status": "cloned",
                    "path": str(self.template_dir),
                    "template_count": count,
                    "method": "git-clone",
                }
            except (subprocess.TimeoutExpired, OSError) as exc:
                logger.warning("git clone failed: %s", exc)

        return {
            "status": "error",
            "message": "Neither nuclei nor git available for template pull",
        }

    def index_templates(self) -> TemplateCollection:
        """Scan template directory and build an indexed collection."""
        if not self.templates_exist:
            return TemplateCollection(name="empty", version="0.0.0")

        templates: list[TemplateInfo] = []
        for yaml_file in sorted(self.template_dir.rglob("*.yaml")):
            info = self._parse_template_file(yaml_file)
            if info:
                templates.append(info)

        self._collection = TemplateCollection(
            name="nuclei-templates",
            version=self._detect_version(),
            templates=templates,
            source=str(self.template_dir),
        )
        return self._collection

    def search_templates(self, query: str) -> list[dict[str, Any]]:
        """Search templates by ID, name, description, or tags."""
        if not self._collection:
            self.index_templates()
        if not self._collection:
            return []
        results = self._collection.search(query)
        return [t.to_dict() for t in results[:50]]

    def get_templates_for_scan(
        self,
        scan_type: str = "pentest",
        severity: str | None = None,
        tags: list[str] | None = None,
    ) -> list[str]:
        """Get template paths suitable for a scan type.

        Scan types: pentest, recon, compliance, fuzzing, cve, exposure
        """
        _SCAN_TYPE_TAGS = {
            "pentest": ["cve", "sqli", "xss", "rce", "lfi", "ssrf", "injection"],
            "recon": ["tech", "detect", "fingerprint", "exposure", "panel"],
            "compliance": ["misconfig", "default-login", "exposure", "unauth"],
            "fuzzing": ["fuzz", "brute", "spray"],
            "cve": ["cve"],
            "exposure": ["exposure", "misconfig", "default-login", "unauth", "panel"],
        }
        target_tags = _SCAN_TYPE_TAGS.get(scan_type, ["cve"])
        if tags:
            target_tags.extend(tags)

        if not self._collection:
            self.index_templates()
        if not self._collection:
            return []

        matched: list[str] = []
        for t in self._collection.templates:
            if severity and t.severity != severity:
                continue
            if any(tag in t.tags for tag in target_tags):
                if t.file_path:
                    matched.append(t.file_path)

        return matched[:500]  # Cap at 500 templates per scan

    def generate_template(self, finding: dict[str, Any]) -> str:
        """Generate a custom nuclei template from a security finding.

        Takes a finding dict with: title, description, url, severity, method, path
        Returns YAML template string.
        """
        title = finding.get("title", "custom-check").lower().replace(" ", "-")
        desc = finding.get("description", "Custom security check")
        severity = finding.get("severity", "medium")
        method = finding.get("method", "GET").upper()
        path = finding.get("path", "/")
        matchers = finding.get("matchers", [])

        matcher_yaml = ""
        if matchers:
            matcher_yaml = "\n".join(
                f'      - type: word\n        words:\n          - "{m}"'
                for m in matchers
            )
        else:
            matcher_yaml = "      - type: status\n        status:\n          - 200"

        template = f"""id: cipher-{title}

info:
  name: {finding.get("title", "Custom Check")}
  author: cipher-auto
  severity: {severity}
  description: |
    {desc}
  tags: custom,cipher-generated
  metadata:
    generated-by: cipher-template-manager
    generated-at: {datetime.now(timezone.utc).isoformat()}

http:
  - method: {method}
    path:
      - "{{{{BaseURL}}}}{path}"
    matchers:
{matcher_yaml}
"""
        return template

    def generate_workflow(self, name: str, template_ids: list[str]) -> str:
        """Generate a nuclei workflow YAML that chains multiple templates."""
        subtemplates = "\n".join(f"      - template: {tid}" for tid in template_ids)
        return f"""id: cipher-workflow-{name}

info:
  name: CIPHER Workflow - {name}
  author: cipher
  severity: info

workflows:
  - template: {template_ids[0] if template_ids else "missing"}
    subtemplates:
{subtemplates}
"""

    def stats(self) -> dict[str, Any]:
        """Return template collection statistics."""
        if not self._collection:
            self.index_templates()
        if not self._collection:
            return {"status": "no_templates", "path": str(self.template_dir)}
        return {
            **self._collection.to_dict(),
            "protocols": {
                p: len(self._collection.by_protocol(p))
                for p in (
                    "http",
                    "dns",
                    "network",
                    "file",
                    "headless",
                    "javascript",
                    "code",
                    "ssl",
                )
            },
        }

    # -- private helpers --

    def _parse_template_file(self, path: Path) -> TemplateInfo | None:
        """Parse a nuclei template YAML file for metadata."""
        try:
            content = path.read_text(errors="ignore")
            # Fast YAML parsing — extract key fields without full parser
            info = TemplateInfo(id="", name="", file_path=str(path))

            for line in content.splitlines()[:50]:
                line = line.strip()
                if line.startswith("id:"):
                    info.id = line.split(":", 1)[1].strip()
                elif line.startswith("name:"):
                    info.name = line.split(":", 1)[1].strip()
                elif line.startswith("severity:"):
                    info.severity = line.split(":", 1)[1].strip()
                elif line.startswith("author:"):
                    info.author = line.split(":", 1)[1].strip()
                elif line.startswith("description:"):
                    info.description = line.split(":", 1)[1].strip()
                elif line.startswith("tags:"):
                    info.tags = [t.strip() for t in line.split(":", 1)[1].split(",")]

            # Detect protocol and category from path
            rel = path.relative_to(self.template_dir)
            parts = rel.parts
            if parts:
                info.category = parts[0]
                info.protocol = (
                    parts[0]
                    if parts[0]
                    in (
                        "http",
                        "dns",
                        "network",
                        "file",
                        "headless",
                        "javascript",
                        "code",
                        "ssl",
                        "cloud",
                    )
                    else "http"
                )

            if not info.id:
                return None
            return info
        except Exception:
            return None

    def _detect_version(self) -> str:
        """Detect template version from checksum or git."""
        checksum_file = self.template_dir / "cves.json-checksum.txt"
        if checksum_file.exists():
            return checksum_file.read_text().strip()[:12]
        return datetime.now(timezone.utc).strftime("%Y%m%d")
