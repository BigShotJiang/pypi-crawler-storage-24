# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""CIPHER OSINT Pipeline — structured OSINT workflows.

Inspired by the Bellingcat Toolkit patterns:
- Domain intelligence and WHOIS enrichment
- IP reputation and geolocation
- Infrastructure attribution
- Document metadata extraction
- Social media pivoting patterns
- Image/video geolocation guidance
"""

from __future__ import annotations

import json
import logging
import re
import socket
import subprocess
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class OSINTResult:
    """Result from an OSINT investigation step."""

    source: str
    query: str
    data: dict[str, Any] = field(default_factory=dict)
    confidence: str = "medium"  # high, medium, low
    timestamp: str = ""
    collection_method: str = "passive"  # passive, active

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "query": self.query,
            "data": self.data,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "collection_method": self.collection_method,
        }


class DomainIntelligence:
    """Domain-focused OSINT: WHOIS, DNS, subdomains, certificates."""

    @staticmethod
    def dns_lookup(domain: str) -> OSINTResult:
        """Resolve DNS records for a domain (passive)."""
        data: dict[str, Any] = {"domain": domain, "records": {}}
        for rtype in ("A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"):
            dig = shutil.which("dig")
            if dig:
                try:
                    proc = subprocess.run(
                        [dig, "+short", domain, rtype],
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    records = [
                        r.strip() for r in proc.stdout.strip().splitlines() if r.strip()
                    ]
                    if records:
                        data["records"][rtype] = records
                except (subprocess.TimeoutExpired, OSError):
                    continue
            else:
                # Fallback: socket for A records only
                if rtype == "A":
                    try:
                        ips = [
                            addr[4][0]
                            for addr in socket.getaddrinfo(domain, None, socket.AF_INET)
                        ]
                        data["records"]["A"] = list(set(ips))
                    except socket.gaierror:
                        pass
                break  # No dig available, only A records via socket

        return OSINTResult(source="dns", query=domain, data=data, confidence="high")

    @staticmethod
    def whois_lookup(domain: str) -> OSINTResult:
        """WHOIS lookup for domain registration info (passive)."""
        whois_bin = shutil.which("whois")
        if not whois_bin:
            return OSINTResult(
                source="whois",
                query=domain,
                data={"error": "whois binary not found"},
                confidence="low",
            )
        try:
            proc = subprocess.run(
                [whois_bin, domain],
                capture_output=True,
                text=True,
                timeout=15,
            )
            output = proc.stdout
            data: dict[str, Any] = {"domain": domain, "raw_length": len(output)}

            # Extract key fields
            patterns = {
                "registrar": r"Registrar:\s*(.+)",
                "creation_date": r"Creat(?:ion|ed) Date:\s*(.+)",
                "expiration_date": r"(?:Expir(?:ation|y) Date|Registry Expiry Date):\s*(.+)",
                "name_servers": r"Name Server:\s*(.+)",
                "status": r"Status:\s*(.+)",
                "registrant_org": r"Registrant Organi[sz]ation:\s*(.+)",
                "registrant_country": r"Registrant Country:\s*(.+)",
            }
            for key, pattern in patterns.items():
                matches = re.findall(pattern, output, re.IGNORECASE)
                if matches:
                    data[key] = matches if len(matches) > 1 else matches[0]

            return OSINTResult(
                source="whois", query=domain, data=data, confidence="high"
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            return OSINTResult(
                source="whois",
                query=domain,
                data={"error": str(exc)},
                confidence="low",
            )


class IPIntelligence:
    """IP-focused OSINT: geolocation, reputation, reverse DNS."""

    @staticmethod
    def reverse_dns(ip: str) -> OSINTResult:
        """Reverse DNS lookup for an IP address."""
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return OSINTResult(
                source="reverse_dns",
                query=ip,
                data={"ip": ip, "hostname": hostname},
                confidence="high",
            )
        except (socket.herror, socket.gaierror):
            return OSINTResult(
                source="reverse_dns",
                query=ip,
                data={"ip": ip, "hostname": None},
                confidence="low",
            )

    @staticmethod
    def ip_info(ip: str) -> OSINTResult:
        """Aggregate IP intelligence from available local tools."""
        data: dict[str, Any] = {"ip": ip}

        # Reverse DNS
        try:
            data["hostname"] = socket.gethostbyaddr(ip)[0]
        except (socket.herror, socket.gaierror):
            data["hostname"] = None

        # Check if RFC 1918 / private
        import ipaddress

        try:
            addr = ipaddress.ip_address(ip)
            data["is_private"] = addr.is_private
            data["is_loopback"] = addr.is_loopback
            data["is_multicast"] = addr.is_multicast
            data["version"] = addr.version
        except ValueError:
            data["error"] = "Invalid IP address"

        return OSINTResult(source="ip_info", query=ip, data=data, confidence="high")


class DocumentMetadata:
    """Extract metadata from documents and images."""

    @staticmethod
    def extract_exif(filepath: str) -> OSINTResult:
        """Extract EXIF metadata from an image file."""
        exiftool = shutil.which("exiftool")
        if not exiftool:
            return OSINTResult(
                source="exif",
                query=filepath,
                data={"error": "exiftool not found"},
                confidence="low",
            )
        try:
            proc = subprocess.run(
                [exiftool, "-json", filepath],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if proc.returncode == 0:
                metadata = json.loads(proc.stdout)
                return OSINTResult(
                    source="exif",
                    query=filepath,
                    data={"metadata": metadata[0] if metadata else {}},
                    confidence="high",
                )
        except (subprocess.TimeoutExpired, OSError, json.JSONDecodeError):
            pass
        return OSINTResult(
            source="exif",
            query=filepath,
            data={"error": "Failed to extract EXIF"},
            confidence="low",
        )

    @staticmethod
    def extract_pdf_metadata(filepath: str) -> OSINTResult:
        """Extract metadata from a PDF file using pdfinfo."""
        pdfinfo = shutil.which("pdfinfo")
        if not pdfinfo:
            return OSINTResult(
                source="pdf_metadata",
                query=filepath,
                data={"error": "pdfinfo not found"},
                confidence="low",
            )
        try:
            proc = subprocess.run(
                [pdfinfo, filepath],
                capture_output=True,
                text=True,
                timeout=15,
            )
            data: dict[str, str] = {}
            for line in proc.stdout.splitlines():
                if ":" in line:
                    key, _, value = line.partition(":")
                    data[key.strip()] = value.strip()
            return OSINTResult(
                source="pdf_metadata",
                query=filepath,
                data=data,
                confidence="high",
            )
        except (subprocess.TimeoutExpired, OSError):
            return OSINTResult(
                source="pdf_metadata",
                query=filepath,
                data={"error": "Failed to extract PDF metadata"},
                confidence="low",
            )


class OSINTPipeline:
    """Orchestrate multi-step OSINT investigations."""

    def __init__(self) -> None:
        self.domain_intel = DomainIntelligence()
        self.ip_intel = IPIntelligence()
        self.doc_meta = DocumentMetadata()
        self._results: list[OSINTResult] = []

    def investigate_domain(self, domain: str) -> list[OSINTResult]:
        """Run full domain investigation pipeline."""
        results: list[OSINTResult] = []
        results.append(self.domain_intel.dns_lookup(domain))
        results.append(self.domain_intel.whois_lookup(domain))

        # Pivot: resolve IPs and investigate them
        dns_result = results[0]
        a_records = dns_result.data.get("records", {}).get("A", [])
        for ip in a_records[:5]:  # Cap at 5 IPs
            results.append(self.ip_intel.ip_info(ip))

        self._results.extend(results)
        return results

    def investigate_ip(self, ip: str) -> list[OSINTResult]:
        """Run IP investigation pipeline."""
        results = [self.ip_intel.ip_info(ip), self.ip_intel.reverse_dns(ip)]
        self._results.extend(results)
        return results

    def extract_metadata(self, filepath: str) -> OSINTResult:
        """Extract metadata from a file."""
        if filepath.lower().endswith(".pdf"):
            result = self.doc_meta.extract_pdf_metadata(filepath)
        else:
            result = self.doc_meta.extract_exif(filepath)
        self._results.append(result)
        return result

    def get_all_results(self) -> list[dict[str, Any]]:
        """Return all investigation results."""
        return [r.to_dict() for r in self._results]

    def summary(self) -> dict[str, Any]:
        """Investigation summary statistics."""
        by_source: dict[str, int] = {}
        by_confidence: dict[str, int] = {}
        for r in self._results:
            by_source[r.source] = by_source.get(r.source, 0) + 1
            by_confidence[r.confidence] = by_confidence.get(r.confidence, 0) + 1
        return {
            "total_results": len(self._results),
            "by_source": by_source,
            "by_confidence": by_confidence,
        }
