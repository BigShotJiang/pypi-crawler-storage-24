# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""Static XSS heuristic scanner — detects DOM XSS sinks and sources without a browser.

Covers ~40-60% of reflected/DOM XSS patterns via regex-based sink/source analysis.
This is the static layer; full runtime DOM XSS requires Playwright (deferred).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Sink patterns — where untrusted data reaches dangerous APIs
# ---------------------------------------------------------------------------
_JS_SINKS: list[tuple[str, str, re.Pattern[str]]] = [
    ("innerHTML", "critical", re.compile(r"\.\s*innerHTML\s*=(?!=)", re.IGNORECASE)),
    ("outerHTML", "critical", re.compile(r"\.\s*outerHTML\s*=(?!=)", re.IGNORECASE)),
    (
        "document.write",
        "critical",
        re.compile(r"document\s*\.\s*write(ln)?\s*\(", re.IGNORECASE),
    ),
    ("eval", "critical", re.compile(r"\beval\s*\(", re.IGNORECASE)),
    (
        "setTimeout-string",
        "high",
        re.compile(r'setTimeout\s*\(\s*["\']', re.IGNORECASE),
    ),
    (
        "setInterval-string",
        "high",
        re.compile(r'setInterval\s*\(\s*["\']', re.IGNORECASE),
    ),
    (
        "Function-constructor",
        "critical",
        re.compile(r"\bnew\s+Function\s*\(", re.IGNORECASE),
    ),
    (
        "insertAdjacentHTML",
        "high",
        re.compile(r"\.insertAdjacentHTML\s*\(", re.IGNORECASE),
    ),
    (
        "dangerouslySetInnerHTML",
        "critical",
        re.compile(r"dangerouslySetInnerHTML\s*=\s*\{", re.IGNORECASE),
    ),
    ("v-html", "high", re.compile(r"\bv-html\s*=", re.IGNORECASE)),
    ("[innerHTML]", "high", re.compile(r"\[innerHTML\]\s*=", re.IGNORECASE)),  # Angular
    (
        "bypassSecurityTrust",
        "critical",
        re.compile(
            r"bypassSecurityTrust(Html|Script|Url|ResourceUrl|Style)", re.IGNORECASE
        ),
    ),
    ("jquery-html", "high", re.compile(r"\$\([^)]*\)\s*\.\s*html\s*\(", re.IGNORECASE)),
    (
        "jquery-append-raw",
        "medium",
        re.compile(r"\$\([^)]*\)\s*\.\s*append\s*\(", re.IGNORECASE),
    ),
    (
        "document.domain",
        "high",
        re.compile(r"document\s*\.\s*domain\s*=", re.IGNORECASE),
    ),
    (
        "location-assign",
        "high",
        re.compile(r"location\s*\.\s*(href|assign|replace)\s*=", re.IGNORECASE),
    ),
    ("srcdoc", "high", re.compile(r"\bsrcdoc\s*=", re.IGNORECASE)),
    (
        "postMessage-star",
        "medium",
        re.compile(r'\.postMessage\s*\([^,]+,\s*["\']?\*', re.IGNORECASE),
    ),
]

# ---------------------------------------------------------------------------
# Source patterns — where untrusted data enters the application
# ---------------------------------------------------------------------------
_JS_SOURCES: list[tuple[str, re.Pattern[str]]] = [
    ("location.hash", re.compile(r"location\s*\.\s*hash", re.IGNORECASE)),
    ("location.search", re.compile(r"location\s*\.\s*search", re.IGNORECASE)),
    ("location.href", re.compile(r"location\s*\.\s*href(?!\s*=)", re.IGNORECASE)),
    ("document.URL", re.compile(r"document\s*\.\s*URL", re.IGNORECASE)),
    ("document.referrer", re.compile(r"document\s*\.\s*referrer", re.IGNORECASE)),
    ("document.cookie", re.compile(r"document\s*\.\s*cookie", re.IGNORECASE)),
    ("window.name", re.compile(r"window\s*\.\s*name", re.IGNORECASE)),
    ("URLSearchParams", re.compile(r"new\s+URLSearchParams", re.IGNORECASE)),
    (
        "postMessage-handler",
        re.compile(r'addEventListener\s*\(\s*["\']message["\']', re.IGNORECASE),
    ),
]

# ---------------------------------------------------------------------------
# Server-side template injection / unescaped output
# ---------------------------------------------------------------------------
_TEMPLATE_SINKS: list[tuple[str, str, re.Pattern[str]]] = [
    ("jinja2-raw", "high", re.compile(r"\{\{.*\|.*safe\s*\}\}", re.IGNORECASE)),
    (
        "jinja2-autoescape-off",
        "critical",
        re.compile(r"\{%\s*autoescape\s+false", re.IGNORECASE),
    ),
    ("erb-raw", "high", re.compile(r"<%=\s*raw\s+", re.IGNORECASE)),
    (
        "php-echo-unescaped",
        "high",
        re.compile(r"<\?=\s*\$_(GET|POST|REQUEST|COOKIE)", re.IGNORECASE),
    ),
    (
        "asp-response-write",
        "high",
        re.compile(r"Response\.Write\s*\(\s*Request", re.IGNORECASE),
    ),
    ("thymeleaf-utext", "high", re.compile(r"th:utext\s*=", re.IGNORECASE)),
    ("razor-raw", "high", re.compile(r"@Html\.Raw\s*\(", re.IGNORECASE)),
]

# File extensions to scan
_SCANNABLE_EXTENSIONS: set[str] = {
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".vue",
    ".svelte",
    ".html",
    ".htm",
    ".php",
    ".erb",
    ".ejs",
    ".hbs",
    ".pug",
    ".jade",
    ".py",
    ".rb",
    ".java",
    ".cs",
    ".asp",
    ".aspx",
}


@dataclass
class XSSFinding:
    """A single XSS heuristic match."""

    file: str
    line_number: int
    line_content: str
    sink_name: str
    severity: str  # critical, high, medium
    category: str  # "dom-sink", "dom-source", "template-injection"
    source_nearby: str | None = None  # if a source was found near a sink

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "file": self.file,
            "line": self.line_number,
            "sink": self.sink_name,
            "severity": self.severity,
            "category": self.category,
            "content": self.line_content.strip()[:200],
        }
        if self.source_nearby:
            d["source_nearby"] = self.source_nearby
        return d


@dataclass
class XSSScanResult:
    """Aggregate result of XSS scanning."""

    files_scanned: int = 0
    findings: list[XSSFinding] = field(default_factory=list)
    sources_found: list[dict[str, Any]] = field(default_factory=list)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "critical")

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "high")

    def to_dict(self) -> dict[str, Any]:
        return {
            "files_scanned": self.files_scanned,
            "total_findings": len(self.findings),
            "critical": self.critical_count,
            "high": self.high_count,
            "medium": len(self.findings) - self.critical_count - self.high_count,
            "findings": [f.to_dict() for f in self.findings],
            "sources_found": self.sources_found,
        }

    def summary(self) -> str:
        if not self.findings:
            return f"No XSS sinks detected in {self.files_scanned} files."
        return (
            f"{len(self.findings)} XSS sink(s) in {self.files_scanned} files: "
            f"{self.critical_count} critical, {self.high_count} high"
        )


class XSSScanner:
    """Static XSS heuristic scanner — no browser required.

    Detects dangerous DOM sinks, untrusted sources, and server-side template
    injection patterns. Does NOT detect runtime DOM XSS that requires JS execution.
    """

    def scan_file(self, filepath: str | Path) -> list[XSSFinding]:
        """Scan a single file for XSS patterns."""
        path = Path(filepath)
        if path.suffix.lower() not in _SCANNABLE_EXTENSIONS:
            return []
        try:
            content = path.read_text(errors="replace")
        except OSError:
            return []

        lines = content.splitlines()
        findings: list[XSSFinding] = []
        source_lines: dict[int, str] = {}

        # First pass: find all source locations
        for i, line in enumerate(lines, 1):
            for src_name, src_pat in _JS_SOURCES:
                if src_pat.search(line):
                    source_lines[i] = src_name

        # Second pass: find sinks + correlate nearby sources
        for i, line in enumerate(lines, 1):
            for sink_name, severity, sink_pat in _JS_SINKS:
                if sink_pat.search(line):
                    # Check if a source is within 10 lines
                    nearby_source = None
                    for src_line_no, src_name in source_lines.items():
                        if abs(src_line_no - i) <= 10:
                            nearby_source = src_name
                            if nearby_source:
                                severity = (
                                    "critical"  # Source + sink = confirmed dangerous
                                )
                            break
                    findings.append(
                        XSSFinding(
                            file=str(path),
                            line_number=i,
                            line_content=line,
                            sink_name=sink_name,
                            severity=severity,
                            category="dom-sink",
                            source_nearby=nearby_source,
                        )
                    )
            for sink_name, severity, sink_pat in _TEMPLATE_SINKS:
                if sink_pat.search(line):
                    findings.append(
                        XSSFinding(
                            file=str(path),
                            line_number=i,
                            line_content=line,
                            sink_name=sink_name,
                            severity=severity,
                            category="template-injection",
                        )
                    )
        return findings

    def scan_directory(
        self, directory: str | Path, recursive: bool = True
    ) -> XSSScanResult:
        """Scan a directory for XSS patterns."""
        root = Path(directory)
        result = XSSScanResult()
        glob_fn = root.rglob if recursive else root.glob
        for path in sorted(glob_fn("*")):
            if not path.is_file():
                continue
            if path.suffix.lower() not in _SCANNABLE_EXTENSIONS:
                continue
            if any(
                part.startswith(".")
                or part in ("node_modules", "vendor", ".venv", "__pycache__")
                for part in path.parts
            ):
                continue
            result.files_scanned += 1
            findings = self.scan_file(path)
            result.findings.extend(findings)
        return result

    def scan_diff(self, diff_text: str, filename: str = "<diff>") -> list[XSSFinding]:
        """Scan added lines in a unified diff for XSS patterns."""
        findings: list[XSSFinding] = []
        line_no = 0
        for line in diff_text.splitlines():
            if line.startswith("@@"):
                m = re.search(r"\+(\d+)", line)
                line_no = int(m.group(1)) if m else 0
                continue
            if line.startswith("+") and not line.startswith("+++"):
                content = line[1:]
                line_no += 1
                for sink_name, severity, sink_pat in _JS_SINKS + _TEMPLATE_SINKS:
                    if sink_pat.search(content):
                        cat = (
                            "template-injection"
                            if (sink_name, severity, sink_pat) in _TEMPLATE_SINKS
                            else "dom-sink"
                        )
                        findings.append(
                            XSSFinding(
                                file=filename,
                                line_number=line_no,
                                line_content=content,
                                sink_name=sink_name,
                                severity=severity,
                                category=cat,
                            )
                        )
            elif not line.startswith("-"):
                line_no += 1
        return findings
