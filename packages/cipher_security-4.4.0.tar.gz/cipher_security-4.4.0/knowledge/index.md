<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
hide:
  - navigation
  - toc
---

<div style="text-align: center; padding: 4em 0 2em;" markdown>

<span class="cipher-hero__title">CIPHER</span>
{ .cipher-hero__title-wrapper }

<p style="font-family: 'JetBrains Mono', monospace; font-size: 0.625rem; letter-spacing: 0.2em; text-transform: uppercase; color: #a3a3a3; margin-top: 0.5em;">Claude Integrated Privacy & Hardening Expert Resource</p>

<p style="color: #737373; font-size: 1rem; margin-top: 1em;">The last security knowledge base you need.</p>

<div style="margin-top: 2em;">
<a href="00-MASTER-INDEX/" class="cipher-cta--primary">Browse Knowledge</a>&nbsp;&nbsp;&nbsp;
<a href="https://github.com/defconxt/cipher" class="cipher-cta--outline">View on GitHub</a>
</div>

</div>

<div style="height: 1px; background: linear-gradient(90deg, transparent, rgba(168, 85, 247, 0.5), transparent); margin: 2em 0;"></div>

## Operating Modes

<div class="cipher-mode-grid" markdown>

<a href="offensive-deep/" class="cipher-mode-card cipher-mode-card--red">
<div class="cipher-mode-card__title" style="color: #ef4444;">RED — Offensive Security</div>
<div class="cipher-mode-card__desc">Attack paths, exploitation chains, red team operations. Every TTP tagged with MITRE ATT&CK.</div>
</a>

<a href="defensive-deep/" class="cipher-mode-card cipher-mode-card--blue">
<div class="cipher-mode-card__title" style="color: #3b82f6;">BLUE — Defensive Security</div>
<div class="cipher-mode-card__desc">Detection rules, hardening, SIEM/SOC operations. Prioritize MTTD and detection fidelity.</div>
</a>

<a href="purple-team-deep/" class="cipher-mode-card cipher-mode-card--purple">
<div class="cipher-mode-card__title" style="color: #a855f7;">PURPLE — Detection Engineering</div>
<div class="cipher-mode-card__desc">Bridge offense and defense. Map TTPs to detection coverage. Design emulation scenarios.</div>
</a>

<a href="privacy-engineering-deep/" class="cipher-mode-card cipher-mode-card--privacy">
<div class="cipher-mode-card__title" style="color: #06b6d4;">PRIVACY — Privacy Engineering</div>
<div class="cipher-mode-card__desc">GDPR, CCPA, HIPAA. Data flow mapping, DPIAs, privacy by design. Cite specific articles.</div>
</a>

<a href="osint-tradecraft-deep/" class="cipher-mode-card cipher-mode-card--recon">
<div class="cipher-mode-card__title" style="color: #22c55e;">RECON — OSINT & Reconnaissance</div>
<div class="cipher-mode-card__desc">Passive and active recon. Structured analytic techniques. Source confidence levels.</div>
</a>

<a href="incident-playbooks-deep/" class="cipher-mode-card cipher-mode-card--incident">
<div class="cipher-mode-card__title" style="color: #f59e0b;">INCIDENT — Incident Response</div>
<div class="cipher-mode-card__desc">Triage mindset. Timeline first. Contain, eradicate, recover. Evidence preservation at every step.</div>
</a>

<a href="security-architecture-deep/" class="cipher-mode-card cipher-mode-card--architect">
<div class="cipher-mode-card__title" style="color: #8b5cf6;">ARCHITECT — Security Architecture</div>
<div class="cipher-mode-card__desc">Design defensible systems. Zero trust. Evaluate blast radius. Threat model before build.</div>
</a>

</div>

<div style="height: 1px; background: linear-gradient(90deg, transparent, rgba(168, 85, 247, 0.5), transparent); margin: 2em 0;"></div>

## By The Numbers

<div class="cipher-stats" markdown>

<div style="text-align: center;">
<div class="cipher-stat__value">94</div>
<div class="cipher-stat__label">Knowledge Docs</div>
</div>

<div style="text-align: center;">
<div class="cipher-stat__value">129K+</div>
<div class="cipher-stat__label">Lines</div>
</div>

<div style="text-align: center;">
<div class="cipher-stat__value">557</div>
<div class="cipher-stat__label">ATT&CK Techniques</div>
</div>

<div style="text-align: center;">
<div class="cipher-stat__value">260+</div>
<div class="cipher-stat__label">Security Tools</div>
</div>

<div style="text-align: center;">
<div class="cipher-stat__value">7</div>
<div class="cipher-stat__label">Modes</div>
</div>

</div>

<div style="height: 1px; background: linear-gradient(90deg, transparent, rgba(168, 85, 247, 0.5), transparent); margin: 2em 0;"></div>

## Quick Access

### Offensive

- [**Pentest Cheatsheet**](pentest-cheatsheet-ultimate.md) — Copy-paste commands for every engagement phase
- [**Active Directory**](active-directory-deep.md) — Kerberos, ADCS ESC1-14, delegation, BloodHound queries
- [**Web Security**](websec-deep.md) — SQLi, XSS, SSRF, SSTI, JWT attacks, WAF/CSP bypass
- [**Cloud Attacks**](cloud-attacks-deep.md) — AWS/Azure/GCP exploitation and privesc paths
- [**Attack Chains**](attack-chains-synthesis.md) — 15 end-to-end attack scenarios with detection mapping

### Defensive

- [**Threat Hunting**](threat-hunting-deep.md) — 81 KQL/SPL/EQL queries with ATT&CK mapping
- [**Sigma Detection**](sigma-detection-deep.md) — 23 production rules, format spec, conversion
- [**Incident Playbooks**](incident-playbooks-deep.md) — 10 ready-to-use IR playbooks
- [**Hardening Guides**](hardening-guides-ultimate.md) — Linux, Windows, Docker, K8s, TLS configs
- [**Windows Event Logs**](windows-eventlog-mastery.md) — Every critical Event ID with attack patterns

### Architecture & Governance

- [**Compliance**](compliance-frameworks-deep.md) — NIST, CIS, SOC2, ISO 27001, GDPR, PCI DSS, HIPAA
- [**Threat Modeling**](threat-modeling-arch-deep.md) — STRIDE, PASTA, zero trust architecture
- [**Master Index**](00-MASTER-INDEX.md) — 280 topics, 260 tools, 557 ATT&CK techniques cross-referenced

<div style="height: 1px; background: linear-gradient(90deg, transparent, rgba(168, 85, 247, 0.5), transparent); margin: 2em 0;"></div>

<div style="text-align: center; padding: 1em 0 0.5em;">
<p style="color: #525252; font-size: 0.875rem;">Press <kbd style="background: #1a1a1a; border: 1px solid #262626; border-radius: 4px; padding: 0.15em 0.5em; font-family: 'JetBrains Mono', monospace; font-size: 0.75rem; color: #a3a3a3;">/</kbd> to search 94 security knowledge documents</p>
</div>

<div style="text-align: center; font-family: 'JetBrains Mono', monospace; font-size: 0.625rem; letter-spacing: 0.15em; text-transform: uppercase; color: #404040; padding-bottom: 2em;">
blacktemple.net/cipher
</div>
