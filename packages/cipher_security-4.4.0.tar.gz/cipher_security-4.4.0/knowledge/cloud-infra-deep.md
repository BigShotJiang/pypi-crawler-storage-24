<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Cloud & Infrastructure Security Deep Dive

## Training Session: 2026-03-14
## Source Material: CloudFox, CloudGoat, Prowler, cloud-nuke, Terraform, Harbor, hackingthe.cloud, NIST CSF

---

## 1. CloudFox -- Cloud Attack Path Discovery (BishopFox)

### Philosophy & Purpose

CloudFox is a read-only enumeration tool for offensive cloud security. It does NOT create alerts, check compliance, or modify state. It codifies the manual investigative workflows that penetration testers perform during cloud engagements.

Key differentiator from compliance tools (Prowler, ScoutSuite, Security Hub): CloudFox finds **exploitable attack paths**, not benchmark deviations.

Design principle: All commands use `get/list/describe` API calls only -- zero state changes. Safe to run with read-only IAM permissions.

### AWS Commands (34 total) -- Enumeration Categories

**Identity & Access:**
- `permissions` -- Enumerates ALL IAM permissions for all users/roles using GetAccountAuthorizationDetails (GAAD). Parses both managed and inline policies, extracts Effect/Action/Resource/Condition per statement. Handles NotAction. Critical for understanding blast radius.
- `principals` -- Lists IAM users and roles for quick reference
- `access-keys` -- Lists active access keys. Cross-reference found keys with account ownership.
- `role-trusts` -- Enumerates role trust policies across three categories:
  - **Principal trusts**: Cross-account role assumptions, checks for :root trusts without ExternalID (confused deputy risk). Uses knownawsaccountslookup to identify vendor accounts.
  - **Service trusts**: What AWS services can assume each role. Flags admin roles assumable by services.
  - **Federated trusts**: OIDC/SAML providers. Detects overly permissive GitHub Actions OIDC (no subject constraint = "ALL REPOS!!!"), EKS OIDC ("ALL SERVICE ACCOUNTS!!!"), Terraform Cloud, Azure AD, Cognito, CircleCI, GCP federation.
- `resource-trusts` -- Scans resource policies across 12+ services: APIGateway, CodeBuild, ECR, EFS, Glue, KMS, Lambda, OpenSearch, SecretsManager, S3, SNS, SQS, VPC Endpoints. Identifies public access, cross-account trust, overly permissive conditions.
- `iam-simulator` -- Uses AWS IAM Policy Simulator API to check effective permissions. Complementary to pmapper (which finds transitive privesc paths).
- `pmapper` -- Integrates with Principal Mapper graph data for transitive privilege escalation detection.
- `cape` -- Cross-Account Privilege Escalation. Requires pmapper data. Builds graph across accounts.
- `outbound-assumed-roles` -- Identifies roles assumed by principals in current account. Reveals outbound attack paths to other accounts.
- `ram` -- Resource Access Manager shares. Cross-account resource sharing attack surface.

**Compute & Network:**
- `instances` -- EC2 enumeration with IPs, instance profiles. Generates nmap-ready loot files.
- `workloads` -- All compute (EC2, Lambda, ECS, etc.) with attached roles. Flags admin roles.
- `ecs-tasks` -- ECS task enumeration with associated IAM roles, cluster, launch type.
- `eks` -- EKS clusters, public endpoint exposure, attached IAM roles, kubeconfig commands.
- `lambda` -- Lambda functions with execution roles. Highlights admin-role functions. Download commands.
- `network-ports` -- Services potentially exposing network ports. Parses security groups AND NACLs.
- `elastic-network-interfaces` -- ENI details with external IPs, VPC IDs, attached instances.
- `endpoints` -- Aggregates all externally-reachable endpoints across services (ELB, CloudFront, API Gateway, etc.) for attack surface mapping.

**Secrets & Data:**
- `env-vars` -- Environment variables from App Runner, ECS, Lambda, Lightsail, Sagemaker. Searches for leaked credentials.
- `secrets` -- Lists SecretsManager and SSM Parameter Store entries.
- `buckets` -- S3 bucket listing with inspection commands.
- `databases` -- RDS enumeration with connection strings.
- `filesystems` -- EFS and FSx that might be mountable without credentials.
- `ecr` -- Container image URIs for pulling/inspecting.

**Infrastructure:**
- `inventory` -- Quick account size assessment: active regions, resource counts per service.
- `route53` -- All DNS records from managed zones.
- `cloudformation` -- Stack parameters/outputs (secret leakage vector).
- `codebuild` -- CodeBuild projects (credential exposure in build configs).
- `tags` -- All tagged resources for asset discovery.
- `sns/sqs` -- Topic/queue enumeration with policy analysis and interaction commands.
- `orgs` -- AWS Organization account enumeration.

### GCP Commands (60 total) -- Notable Capabilities

CloudFox has the most comprehensive GCP coverage of any open-source tool:

**Privilege Escalation Detection:**
- `privesc` -- Graph-based privilege escalation path discovery using FoxMapper. Detects 60+ escalation vectors including:
  - Service Account Token Creation (getAccessToken, getOpenIdToken)
  - Service Account Key Creation
  - IAM Policy Modification (setIamPolicy)
  - Compute Instance Creation with privileged SA
  - Cloud Functions/Run deployment with SA
  - Scope-limited paths (OAuth scope restrictions)
- `hidden-admins` -- Principals who can modify IAM policies
- `foxmapper` -- Graph-based IAM analysis engine

**Lateral Movement & Data Exfiltration:**
- `lateral-movement` -- Maps credential theft vectors and pivot opportunities
- `data-exfiltration` -- Identifies exfiltration paths and missing security hardening
- `cross-project` -- Cross-project IAM bindings, logging sinks, Pub/Sub exports
- `workload-identity` -- GKE Workload Identity and Workload Identity Federation

**Network Security:**
- `firewall` -- VPC firewall rules with security analysis
- `cloud-armor` -- WAF policy weaknesses
- `vpc-sc` -- VPC Service Controls enumeration
- `network-topology` -- VPC peering and trust boundary visualization
- `iap` -- Identity-Aware Proxy configuration

**Supply Chain:**
- `artifact-registry` -- Container/package registry security
- `cloudbuild` -- CI/CD trigger analysis
- `source-repos` -- Source code repository enumeration

### Permission Enumeration Logic (Source Code Analysis)

The permissions module (`aws/permissions.go`) works by:
1. Calling `GetAccountAuthorizationDetails` -- retrieves ALL IAM data in one API call (users, roles, groups, policies with all versions)
2. Iterating through each principal type (Role, User)
3. For users: also resolving group memberships and their policies
4. For each policy: parsing the default version document, extracting every Statement
5. For each statement: recording Effect, Action (and NotAction), Resource, Condition presence
6. Supporting principal-specific filtering via name or ARN

Role trust analysis (`aws/role-trusts.go`):
1. `ListRoles` API to get all roles
2. Parses each role's `AssumeRolePolicyDocument`
3. Categorizes by trust type: AWS Principal, Service, Federated
4. For federated: identifies provider type (GitHub, EKS, Terraform, Azure AD, Cognito, etc.)
5. Checks for missing subject constraints (critical finding)
6. Cross-references with pmapper/iam-simulator for admin/privesc status

---

## 2. CloudGoat -- Vulnerable-by-Design AWS Scenarios (RhinoSecurity)

### Overview

CloudGoat deploys intentionally vulnerable AWS environments for practicing cloud attack techniques. 28 AWS scenarios + 2 Azure scenarios, covering Easy through Hard difficulty.

### Complete AWS Scenario Catalog with Attack Paths

#### Identity & IAM Privilege Escalation

**iam_privesc_by_rollback** (Easy)
- Attack: `SetDefaultPolicyVersion` to restore a historical policy version with admin rights
- Key Lesson: Old policy versions may contain overly permissive configurations. Audit all versions, not just current.

**iam_privesc_by_key_rotation** (Easy)
- Attack: Manager user -> tag admin user -> delete/recreate admin access key -> attach MFA -> assume secretsmanager role
- Key Lesson: Key rotation permissions + tagging = full account takeover chain

**iam_privesc_by_attachment** (Moderate)
- Attack: Limited user -> enumerate instance profiles -> swap admin role onto profile -> create EC2 with keypair -> attach profile -> admin via EC2
- Key Lesson: `iam:AddRoleToInstanceProfile` + `ec2:RunInstances` = admin

**iam_privesc_by_ec2** (Easy)
- Attack: ReadOnly user -> enumerate permissions -> find ec2:deleteTags -> remove protective tag from admin_ec2 -> assume management role -> modify userdata -> exfiltrate credentials
- Key Lesson: Tag-based access control can be subverted if tag modification is permitted

**lambda_privesc** (Easy)
- Attack: Assume lambdaManager role -> create Lambda with debug role (admin) -> invoke -> attach admin policy to self
- Key Lesson: `iam:PassRole` + `lambda:CreateFunction` + `lambda:InvokeFunction` = admin

#### SSRF & Metadata Service Exploitation

**cloud_breach_s3** (Moderate)
- Attack: Find misconfigured reverse proxy -> SSRF to EC2 metadata service (169.254.169.254) -> steal instance profile credentials -> access private S3
- Key Lesson: Classic SSRF-to-IMDS attack. IMDSv2 mitigates but doesn't eliminate.

**ec2_ssrf** (Moderate)
- Attack: Lambda env vars leak creds -> find SSRF-vulnerable web app -> steal EC2 metadata creds -> access private S3 with more creds -> invoke Lambda
- Key Lesson: Multi-hop credential chain through SSRF

**federated_console_takeover** (Moderate)
- Attack: Low-priv user -> SSM Session Manager to EC2 -> IMDSv2 exploitation -> generate federation URL -> AWS Console access with elevated permissions
- Key Lesson: IMDSv2 tokens can still be stolen from the instance itself. Federation URLs bypass MFA.

#### Container & ECS Exploitation

**ecs_takeover** (Moderate)
- Attack: Web app RCE -> steal EC2 host credentials from metadata -> Docker socket mounted in container -> enumerate other containers -> steal privd container role -> force ECS task rescheduling to compromised host -> access vault container
- Key Lesson: Docker socket mounts in containers = host-level access. Container credential isolation is critical.

**ecs_efs_attack** (Hard)
- Attack: EC2 instance profile -> backdoor ECS task definition -> container metadata API credentials -> SSM:StartSession via tag manipulation -> port scan for EFS -> mount flag
- Key Lesson: ECS task role credentials via container metadata + tag-based SSM access control

**ecs_privesc_evade_protection** (Moderate)
- Attack: Web exploitation -> privilege escalation -> S3 flag retrieval while evading GuardDuty, CloudWatch, CloudTrail, EventBridge detection
- Key Lesson: Real-world detection evasion against multiple security services

#### Data & Secrets Access

**codebuild_secrets** (Hard)
- Attack Path 1: CodeBuild env vars -> IAM keys for user2 -> RDS snapshot -> restore -> reset password -> access secrets
- Attack Path 2: SSM parameters -> SSH keys -> EC2 access -> metadata service -> RDS access
- Key Lesson: CodeBuild environment variables are a common credential leakage vector

**secrets_in_the_cloud** (Hard)
- Attack: S3 bucket URL -> web app enumeration -> Lambda env vars (API key) -> HashiCorp Vault token -> SSH key -> EC2 access -> IMDSv2 -> DynamoDB credentials -> Secrets Manager
- Key Lesson: Multi-hop credential chains through multiple services

**data_secrets** (Easy)
- Attack: EC2 User Data contains hardcoded creds -> SSH access -> IMDS -> Lambda env vars -> user compromise -> Secrets Manager
- Key Lesson: User Data is NOT encrypted and is readable by anyone with EC2 describe permissions

**rds_snapshot** (Easy)
- Attack: EC2 access -> S3 credential theft -> RDS snapshot restore -> password reset -> data access
- Key Lesson: RDS snapshot permissions allow database cloning and password reset

#### Web Application & API Exploitation

**rce_web_app** (Hard)
- Attack (Lara): S3 logs -> secret admin URL -> RCE via hidden parameter -> EC2 shell -> private S3 with DB creds OR metadata service -> RDS access
- Attack (McDuck): S3 enumeration -> SSH keys -> direct EC2/RDS access
- Key Lesson: Load balancer access logs can reveal hidden endpoints

**vulnerable_cognito** (Moderate)
- Attack: Bypass client-side email validation via AWS CLI signup -> custom attribute escalation -> Identity Pool AWS credentials
- Key Lesson: Cognito client-side validation is trivially bypassed. Custom attributes can control authorization.

**vulnerable_lambda** (Medium)
- Attack: Assume invoker role -> analyze Lambda source -> command injection in policy applier function -> escalate bilbo to admin -> list secrets
- Key Lesson: Lambda functions processing user input without sanitization

#### Cross-Account & Advanced

**glue_privesc** (Moderate)
- Attack: SQL injection on web page -> steal Glue manager's access keys from database (deleted from S3 but persisted in RDS via ETL) -> exploit vulnerable Glue permissions -> SSM parameter store flag
- Key Lesson: Data pipeline (ETL) can persist deleted credentials

**detection_evasion** (Hard)
- Attack: 4 IAM users, retrieve 2 secrets without triggering CloudTrail/CloudWatch/SNS alerts
- Key Lesson: Understanding what IS and ISN'T logged. API call timing and techniques matter.

**sns_secrets** (Easy)
- Attack: SNS subscription -> receive debug messages with API keys -> API Gateway enumeration -> invoke with API key
- Key Lesson: SNS topics can leak sensitive data to subscribers

**sqs_flag_shop** (Easy)
- Attack: Analyze web source code -> understand SQS message format -> assume SQS role -> forge messages -> manipulate application state
- Key Lesson: SQS message forgery when role assumption is possible

**vpc_peering_overexposed** (Moderate)
- Attack: Low-priv user -> EC2 metadata IMDS -> VPC peering misconfiguration -> SSM lateral movement to Prod -> RDS PII access
- Key Lesson: VPC peering without proper security group/NACL restrictions = flat network

**s3_version_rollback_via_cfn** (Hard)
- Attack: S3 versioning analysis -> CloudFormation stack creation with Lambda -> bypass PutObject deny via Lambda role -> restore previous version with flag
- Key Lesson: Object versioning + overly permissive CloudFormation/Lambda roles bypass direct access controls

**agentcore_identity_confusion** (Moderate)
- Attack: PassRole for agentcore roles -> agent runtime role has same service trust as code interpreter role -> create code interpreter with agent runtime role -> exfiltrate from Bedrock knowledgebase
- Key Lesson: Service trust policy confusion between related services

**bedrock_agent_hijacking** (Moderate)
- Attack: UpdateFunctionCode on Lambda used by Bedrock agent -> agent invokes modified function -> exfiltrate data via agent's execution role
- Key Lesson: Lambda code modification + Bedrock agent integration = indirect data access

---

## 3. Prowler -- Cloud Security Posture Management (Deep Analysis)

### Architecture

Prowler is an open-source cloud security platform supporting 15+ providers: AWS, Azure, GCP, Oracle Cloud, Alibaba Cloud, Kubernetes, Microsoft 365, GitHub, Cloudflare, MongoDB Atlas, OpenStack, Google Workspace, plus IaC scanning, container image analysis, and LLM security.

### AWS Compliance Frameworks Supported (45 frameworks)

- **CIS Benchmarks**: v1.4, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0
- **NIST**: 800-53 Rev 4/5, 800-171 Rev 2, CSF 1.1/2.0
- **PCI DSS**: 3.2.1, 4.0
- **SOC 2**
- **HIPAA**
- **GDPR**
- **ISO 27001**: 2013, 2022
- **FedRAMP**: Low Rev4, Moderate Rev4, 20x KSI Low
- **MITRE ATT&CK** (mapped to AWS controls)
- **AWS-specific**: Foundational Security Best Practices, Well-Architected Framework (Security + Reliability pillars), Foundational Technical Review, Account Security Onboarding, Audit Manager Control Tower Guardrails
- **Regional**: ENS RD2022 (Spain), C5 (Germany), KISA ISMS-P 2023, RBI Cyber Security (India), SecNumCloud 3.2 (France), NIS2

### IAM Checks (46 checks) -- Critical Security Controls

**Privilege Escalation Detection** (`iam_policy_allows_privilege_escalation`):
Prowler maintains a comprehensive privilege escalation combinations dictionary covering:

*IAM Self-Escalation (Direct):*
- `iam:CreatePolicyVersion` -- Create new version with admin permissions
- `iam:SetDefaultPolicyVersion` -- Rollback to permissive version
- `iam:CreateAccessKey` -- Generate keys for higher-priv users
- `iam:CreateLoginProfile` / `iam:UpdateLoginProfile` -- Create/change console passwords
- `iam:AttachUserPolicy` / `iam:AttachGroupPolicy` / `iam:AttachRolePolicy` -- Attach admin policies
- `iam:PutGroupPolicy` / `iam:PutRolePolicy` / `iam:PutUserPolicy` -- Create inline admin policies
- `iam:AddUserToGroup` -- Join admin group
- `iam:UpdateAssumeRolePolicy` -- Modify role trust to allow self-assumption

*PassRole + Service Escalation (35+ combinations):*
- EC2: `iam:PassRole` + `ec2:RunInstances` or `ec2:RequestSpotInstances`
- Lambda: `iam:PassRole` + `lambda:CreateFunction` + `lambda:InvokeFunction` (or CreateEventSourceMapping, or AddPermission)
- Glue: `iam:PassRole` + `glue:CreateDevEndpoint` or `glue:CreateJob`
- CloudFormation: `iam:PassRole` + `cloudformation:CreateStack` (or StackSet)
- CodeBuild: `iam:PassRole` + `codebuild:CreateProject` + `codebuild:StartBuild`
- ECS: `iam:PassRole` + `ecs:RegisterTaskDefinition` + `ecs:RunTask/CreateService/StartTask`
- SageMaker: `iam:PassRole` + `sagemaker:CreateNotebookInstance` or training/processing jobs
- DataPipeline: `iam:PassRole` + `datapipeline:CreatePipeline` + PutDefinition + Activate
- AutoScaling: `iam:PassRole` + `autoscaling:CreateAutoScalingGroup` + LaunchConfiguration
- AppRunner: `iam:PassRole` + `apprunner:CreateService`
- AgentCore: `iam:PassRole` + `bedrock-agentcore:CreateCodeInterpreter` + InvokeCodeInterpreter

*Prerequisite-Based Escalation (existing vulnerable resources):*
- `ec2:ModifyInstanceAttribute` + Stop/Start (modify userdata of instance with admin role)
- `ec2:CreateLaunchTemplateVersion` + `ec2:ModifyLaunchTemplate`
- `lambda:UpdateFunctionCode` (modify existing function with admin role)
- `lambda:UpdateFunctionConfiguration` (add malicious layers)
- `ssm:StartSession` / `ssm:SendCommand` (access instance with admin profile)
- `ecs:ExecuteCommand` (exec into container with admin task role)
- `sagemaker:CreatePresignedNotebookInstanceUrl`
- `cloudformation:UpdateStack` / `CreateChangeSet` + `ExecuteChangeSet`
- `codebuild:StartBuild` / `StartBuildBatch`

*STS-Based:*
- `sts:AssumeRole` + any of the policy attachment permissions

**Other Critical IAM Checks:**
- `iam_inline_policy_allows_privilege_escalation` -- Same analysis for inline policies
- `iam_no_custom_policy_permissive_role_assumption` -- Overly permissive sts:AssumeRole
- `iam_role_cross_account_readonlyaccess_policy` -- Cross-account access review
- `iam_role_cross_service_confused_deputy_prevention` -- Confused deputy protection
- `iam_avoid_root_usage` / `iam_no_root_access_key` -- Root account controls
- `iam_root_mfa_enabled` / `iam_root_hardware_mfa_enabled` -- Root MFA
- `iam_rotate_access_key_90_days` -- Key rotation
- `iam_user_mfa_enabled_console_access` / `iam_user_hardware_mfa_enabled` -- User MFA
- `iam_user_accesskey_unused` / `iam_user_console_access_unused` -- Unused access
- Password policy checks (length 14+, complexity, reuse 24, expiry 90 days)

### S3 Checks (21 checks)

- `s3_account_level_public_access_blocks` -- Account-level Block Public Access
- `s3_bucket_level_public_access_block` -- Bucket-level Block Public Access
- `s3_bucket_public_access` / `s3_bucket_public_write_acl` / `s3_bucket_public_list_acl` -- ACL analysis
- `s3_bucket_policy_public_write_access` -- Policy-based public write
- `s3_bucket_acl_prohibited` -- ACL usage (should be disabled)
- `s3_bucket_default_encryption` / `s3_bucket_kms_encryption` -- Encryption at rest
- `s3_bucket_secure_transport_policy` -- HTTPS enforcement
- `s3_bucket_server_access_logging_enabled` -- Access logging
- `s3_bucket_object_versioning` / `s3_bucket_object_lock` -- Data protection
- `s3_bucket_no_mfa_delete` -- MFA delete requirement
- `s3_bucket_cross_account_access` / `s3_bucket_cross_region_replication` -- Cross-boundary access
- `s3_bucket_shadow_resource_vulnerability` -- Shadow resource detection
- `s3_access_point_public_access_block` / `s3_multi_region_access_point_public_access_block` -- Access point controls

### CloudTrail Checks (15 checks)

- `cloudtrail_multi_region_enabled` -- Multi-region trail
- `cloudtrail_multi_region_enabled_logging_management_events` -- Management event logging
- `cloudtrail_log_file_validation_enabled` -- Log integrity validation
- `cloudtrail_kms_encryption_enabled` -- KMS encryption for logs
- `cloudtrail_cloudwatch_logging_enabled` -- CloudWatch integration
- `cloudtrail_logs_s3_bucket_is_not_publicly_accessible` -- Log bucket access control
- `cloudtrail_logs_s3_bucket_access_logging_enabled` -- Log bucket access logging
- `cloudtrail_bucket_requires_mfa_delete` -- MFA delete on log bucket
- `cloudtrail_s3_dataevents_read_enabled` / `cloudtrail_s3_dataevents_write_enabled` -- S3 data events
- `cloudtrail_insights_exist` -- CloudTrail Insights
- **Threat Detection Checks:**
  - `cloudtrail_threat_detection_enumeration` -- Detect enumeration activity
  - `cloudtrail_threat_detection_privilege_escalation` -- Detect privesc attempts (monitors 50+ API calls including AddPermission, AttachRolePolicy, CreateAccessKey, CreatePolicyVersion, PassRole, UpdateAssumeRolePolicy, etc.)
  - `cloudtrail_threat_detection_llm_jacking` -- Detect LLM resource abuse

### NIST CSF 2.0 Mapping Structure

The Prowler NIST CSF 2.0 compliance mapping covers all six core functions:
- **Govern (GV)**: Organizational Context, Risk Management Strategy, Roles/Responsibilities, Policy, Oversight, Supply Chain Risk Management
- **Identify (ID)**: Asset Management, Risk Assessment, Improvement
- **Protect (PR)**: Identity Management/Access Control, Awareness/Training, Data Security, Platform Security, Technology Infrastructure Resilience
- **Detect (DE)**: Continuous Monitoring, Adverse Event Analysis
- **Respond (RS)**: Incident Management, Incident Analysis, Incident Response Reporting, Incident Mitigation
- **Recover (RC)**: Incident Recovery Plan Execution, Incident Recovery Communication

Each requirement maps to specific Prowler checks. Example: GV.RM-1 maps to config_recorder, organizations, trustedadvisor, securityhub, and wellarchitected checks.

### MITRE ATT&CK Mapping

Prowler maps AWS services to MITRE ATT&CK techniques with scored effectiveness:
- T1190 (Exploit Public-Facing Application): WAF (Significant), Config (Partial), GuardDuty (Minimal), Security Hub (Partial)
- Scoring uses: Significant / Partial / Minimal ratings per AWS service per technique
- Categories: Protect, Detect, Respond

### Automated Remediation (Fixers)

Prowler includes automated fixers for certain findings. Example: `cloudtrail_threat_detection_privilege_escalation` fixer automatically attaches a DenyAll inline policy to compromised users or roles:
```json
{"Version": "2012-10-17", "Statement": [{"Effect": "Deny", "Action": "*", "Resource": "*"}]}
```

---

## 4. cloud-nuke -- Infrastructure Cleanup & CIS Hardening (Gruntwork)

### Purpose

cloud-nuke is a DESTRUCTIVE tool for deleting all resources in AWS accounts. Two primary use cases:
1. **Test account cleanup**: `cloud-nuke aws` -- deletes ALL resources (never use in production)
2. **CIS default VPC hardening**: `cloud-nuke defaults-aws` -- deletes default VPCs and removes permissive default security group rules

### Resource Coverage

Supports **125+ AWS resource types** including:

**Compute**: EC2, ASG, Launch Templates/Configurations, ECS (Clusters/Services), EKS, Lambda (Functions/Layers), App Runner, Elastic Beanstalk, SageMaker (Endpoints/Notebooks/Studio)

**Storage**: S3 (Buckets/Access Points/Multi-Region), EBS (Volumes/Snapshots), EFS, ECR

**Database**: RDS (Instances/Clusters/Snapshots/Proxies/Parameter Groups/Subnet Groups), DynamoDB, ElastiCache (Clusters/Serverless/Subnet Groups/Parameter Groups), OpenSearch, Redshift

**Networking**: VPC, Subnets, Security Groups, Network ACLs, Internet Gateways, NAT Gateways, Transit Gateways (and attachments/peering/route tables), VPC Endpoints, VPC Peering, VPC Lattice (Services/Networks/Target Groups), Route Tables, EIPs, Network Interfaces, Network Firewall (and policies/rules/TLS)

**Identity**: IAM (Users/Roles/Groups/Policies/Instance Profiles/Service-Linked Roles/OIDC Providers)

**Monitoring**: CloudTrail, CloudWatch (Alarms/Dashboards/Log Groups), Config (Recorders/Rules), GuardDuty, Security Hub

**Other**: KMS, Secrets Manager, SNS, SQS, API Gateway (v1/v2), CloudFormation, CloudFront, EventBridge, Kinesis, Route53, CodeDeploy, Data Pipeline, DataSync, Grafana, Macie, Managed Prometheus

### CIS Default VPC Hardening Use Case

The `defaults-aws` command addresses CIS AWS Foundations Benchmark controls:
- **CIS 2.1.x**: Remove default VPCs (which have public subnets and IGW by default)
- **CIS 5.3/5.4**: Remove default security group ingress/egress rules (default SGs allow all outbound and all inbound from same SG)
- Every new AWS account and region comes with a default VPC that is inherently insecure
- Running `cloud-nuke defaults-aws` across all regions is a day-zero hardening step

### Configuration Filtering

Config file supports granular control:
- `names_regex` -- Include/exclude by resource name pattern
- `time` -- Filter by creation time (e.g., delete resources older than X)
- `tags` -- Filter by AWS tags
- `timeout` -- Per-resource-type deletion timeout

**Safety features**: `--dry-run` flag for preview, region filtering, resource type filtering, confirmation prompt.

---

## 5. Terraform -- Security Considerations (Source Code Analysis)

### State File Security

Terraform state files contain the complete infrastructure graph including **all attribute values**, which frequently includes:
- Database passwords and connection strings
- API keys and tokens
- Certificate private keys
- Any value passed as a variable or computed by a provider

**S3 Backend Encryption** (from `internal/backend/remote-state/s3/backend.go`):

Three encryption options for state in S3:
1. **SSE-S3**: `encrypt = true` -- server-side encryption with S3-managed keys
2. **SSE-KMS**: `kms_key_id = "arn:aws:kms:..."` -- encryption with customer-managed KMS key
3. **SSE-C**: `AWS_SSE_CUSTOMER_KEY` environment variable -- encryption with customer-provided key (base64-encoded)

KMS and SSE-C are mutually exclusive -- Terraform validates this and returns `encryptionKeyConflictError`.

Other supported state backends with security implications:
- **PostgreSQL** (`remote-state/pg`) -- state in database, requires connection encryption
- **Kubernetes** (`remote-state/kubernetes`) -- state in K8s secrets
- **GCS** (`remote-state/gcs`) -- Google Cloud Storage with similar encryption options

### Sensitive Variable Handling

From `internal/terraform/eval_variable.go`:
- Variables marked `sensitive = true` have their values masked in CLI output and logs
- Error messages referencing sensitive values are suppressed entirely: "The error message included a sensitive value, so it will not be displayed."
- The `nonsensitive()` function can explicitly unmask values (security risk if misused)
- Sensitive marking propagates through expressions (marked values in conditions produce generic errors)

### Provider Credential Management Risks

1. **Hardcoded credentials in .tf files** -- most common mistake, committed to version control
2. **State file credential leakage** -- even if variables are marked sensitive, the STATE file contains plaintext values
3. **Plan file exposure** -- `terraform plan -out=plan.tfplan` contains sensitive values
4. **Backend credentials** -- credentials to access the state backend itself need secure management
5. **Provider plugin trust** -- third-party providers execute arbitrary code during plan/apply

### Security Best Practices (from source analysis)

- Enable state encryption at rest (SSE-KMS preferred for audit trail)
- Enable state locking (DynamoDB for S3 backend) to prevent concurrent modifications
- Use environment variables or credential helpers instead of hardcoded values
- Restrict state bucket access to minimum necessary principals
- Enable versioning on state bucket for rollback capability
- Never commit `.tfstate` files to version control
- Use `terraform plan -out` carefully -- plan files are sensitive
- Implement Sentinel/OPA policies for compliance guardrails

---

## 6. Harbor -- Container Registry Security (Source Code Analysis)

### Vulnerability Scanning Integration

**Scanner Adapter Architecture** (from `src/pkg/scan/rest/v1/`):
- Harbor uses a pluggable scanner adapter interface
- Default scanner: **Trivy** (enabled via `--with-trivy` during installation)
- Scanner adapters implement a REST API contract:
  - `Scanner` metadata: name, vendor, version
  - `ScannerCapability`: what artifact types it consumes and what report types it produces
  - Supported capabilities: `vulnerability` and `sbom` (Software Bill of Materials)
- MIME types: `application/vnd.scanner.adapter.vuln.report.harbor+json`, `application/vnd.oci.image.manifest.v1+json`

**Scanning Modes:**
- Manual scan: trigger on specific artifacts
- Scan on push: automatic scanning when images are pushed
- Scheduled scanning: cron-based periodic scans
- API access: `/projects/{project_name}/repositories/{repo}/artifacts/{ref}/additions/vulnerabilities`

**Severity Model** (from `src/pkg/scan/vuln/severity.go`):
```
None (0) -> Negligible (1) -> Low (2) -> Medium (3) -> High (4) -> Critical (5)
Unknown (0) -- unrecognized severity treated as 0
Unrecognized severity -- assigned code 99 (highest) for security-conservative behavior
```
CVSS v3.0 mapping: Negligible maps to None (no CVSS v3 Negligible rating exists).

**SBOM Generation**: Harbor supports generating SBOMs alongside vulnerability reports through the same scanner adapter interface.

### Image Signing with Cosign (Source Code Analysis)

**Cosign Signature Middleware** (`src/server/middleware/cosign/cosign.go`):
- Intercepts manifest pushes matching cosign signature pattern: `/v2/{repository}/manifests/sha256-{digest}.sig`
- Validates cosign signature layer media type: `application/vnd.dev.cosign.simplesigning.v1+json`
- Creates accessory records linking signatures to subject artifacts
- Supports both legacy cosign format and OCI 1.1 referrers API (via Subject Middleware)
- Signature bundles include Sigstore transparency log entries (Rekor) with `integratedTime` and `logIndex`

**Content Trust Flow:**
1. Image pushed to Harbor
2. Cosign signs the image, pushing signature manifest
3. Harbor's SignatureMiddleware detects signature layer
4. Accessory record created linking signature to subject artifact
5. Deployment policies can enforce signature requirements

### RBAC Model (Source Code Analysis)

**Interface Design** (`src/pkg/permission/types/rbac.go`):
- `RBACRole`: GetRoleName() + GetPolicies()
- `RBACUser`: GetUserName() + GetPolicies() + GetRoles()
- Policy evaluation uses Casbin (from `src/pkg/permission/evaluator/rbac/`)
- Roles are scoped to projects (project-level RBAC)

**Built-in Roles:**
- Project Admin: Full project management
- Maintainer: Push/pull images, manage scan results
- Developer: Push/pull images
- Guest: Pull images only
- Limited Guest: Pull from specific repositories

**System-level:**
- System Admin: Global administration
- Robot Accounts: Automated/service access with scoped permissions

### Additional Security Features

- **CVE Allowlisting**: Per-project allowlists to suppress known acceptable vulnerabilities
- **Immutable Tags**: Prevent tag overwriting (tag immutability)
- **Quota Management**: Storage quotas per project
- **Audit Logging**: All operations logged for compliance
- **Replication**: Secure image replication between registries
- **Garbage Collection**: Clean up unreferenced blobs

---

## 7. Cloud Attack Techniques Reference (hackingthe.cloud)

### AWS Attack Taxonomy

#### Initial Access
- SSRF to EC2 metadata service (169.254.169.254) -- steal instance profile credentials
- Exploiting public-facing applications with cloud access
- Credential theft from public code repositories, AMIs, EBS snapshots
- Cognito user pool self-signup with bypassed validation

#### Credential Access
- EC2 Instance Metadata Service (IMDS) -- both v1 (no auth) and v2 (token-based)
- Lambda environment variables and event data
- ECS/Fargate container credential endpoint (169.254.170.2)
- CodeBuild environment variable leakage
- S3 bucket credential discovery
- SSM Parameter Store / Secrets Manager enumeration

#### Privilege Escalation (40+ techniques)
See Section 3 (Prowler) for the comprehensive list. Key categories:
- Direct IAM manipulation (policy attachment, version rollback, access key creation)
- PassRole + compute service (EC2, Lambda, Glue, ECS, CloudFormation, CodeBuild, SageMaker)
- Resource policy modification
- Permissions boundary removal/modification

#### Lateral Movement
- Cross-account role assumption via overly permissive trust policies
- VPC peering exploitation for network-level access
- Container registry lateral movement (pull images from other projects)
- SSM Session Manager / Run Command for instance access
- ECS task credential theft and container hopping

#### Persistence
- IAM Roles Anywhere -- external PKI-based persistent access
- Rogue OIDC identity provider registration
- Lambda backdoor functions
- S3 file ACL persistence
- CodeBuild GitHub runner persistence
- IAM eventual consistency exploitation
- Role chain juggling (refreshing temporary credentials indefinitely)

#### Defense Evasion
- GuardDuty bypass techniques (pentest findings, Tor detection)
- CloudTrail log manipulation/disabling
- Credential exfiltration to avoid CloudTrail logging (use credentials outside the account)
- API call timing to avoid detection thresholds
- Network Firewall egress filtering bypass

#### Data Exfiltration
- S3 bucket replication to attacker-controlled account
- S3 server access logs exfiltration
- S3 streaming copy (avoid download logging)
- RDS snapshot sharing to external account
- EBS snapshot sharing

### Azure Attack Techniques
- Managed identity credential theft from IMDS (169.254.169.254)
- Anonymous blob storage access
- Azure AD email enumeration
- Run Command abuse for VM code execution
- Soft-deleted blob recovery

### GCP Attack Techniques
- Compute Engine metadata server (metadata.google.internal)
- GCS bucket hunting (predictable naming)
- Cloud Workstations privilege escalation
- Service account key creation for persistence
- Tag-based privilege escalation
- Apps Script project impersonation

### Infrastructure-as-Code Attacks
- Terraform ANSI escape injection in plan output (hide malicious changes)
- Terraform Enterprise metadata service attacks (steal worker credentials)

---

## 8. NIST Cybersecurity Framework 2.0

### Six Core Functions

**GOVERN (GV)** -- NEW in CSF 2.0
- Organizational Context (GV.OC): Supply chain role, legal/regulatory requirements, critical infrastructure identification
- Risk Management Strategy (GV.RM): Risk strategy, tolerance, risk-informed decisions
- Roles, Responsibilities, Authorities (GV.RR): Leadership accountability, cybersecurity roles
- Policy (GV.PO): Cybersecurity policy establishment and communication
- Oversight (GV.OV): Ongoing review and adjustment of cybersecurity strategy
- Supply Chain Risk Management (GV.SC): Third-party risk identification and management

**IDENTIFY (ID)**
- Asset Management (ID.AM): Hardware, software, data inventory and classification
- Risk Assessment (ID.RA): Vulnerability identification, threat intelligence, risk determination
- Improvement (ID.IM): Continuous improvement of cybersecurity posture

**PROTECT (PR)**
- Identity Management, Authentication, Access Control (PR.AA): Identities, credentials, access management, MFA
- Awareness and Training (PR.AT): Security awareness for all personnel
- Data Security (PR.DS): Data at rest, in transit, integrity protection
- Platform Security (PR.PS): Hardware, software, service configuration management
- Technology Infrastructure Resilience (PR.IR): Redundancy, failover, recovery capabilities

**DETECT (DE)**
- Continuous Monitoring (DE.CM): Networks, physical environment, personnel activity, technology usage monitoring
- Adverse Event Analysis (DE.AE): Event correlation, incident determination, impact assessment

**RESPOND (RS)**
- Incident Management (RS.MA): Incident response plan execution, coordination
- Incident Analysis (RS.AN): Investigation, forensics, understanding attack scope
- Incident Response Reporting and Communication (RS.CO): Internal/external stakeholder communication
- Incident Mitigation (RS.MI): Containment, eradication, and mitigation activities

**RECOVER (RC)**
- Incident Recovery Plan Execution (RC.RP): Recovery activities, restoration priorities
- Incident Recovery Communication (RC.CO): Public relations, stakeholder updates

### Implementation Tiers
- Tier 1 (Partial): Ad hoc, reactive cybersecurity
- Tier 2 (Risk Informed): Risk-aware but not organization-wide
- Tier 3 (Repeatable): Formally approved and regularly updated practices
- Tier 4 (Adaptive): Continuous improvement based on lessons learned and predictive indicators

### Cloud Security Mapping (via Prowler)

Prowler maps NIST CSF 2.0 to AWS controls:
- GV.RM-1 -> AWS Config, Organizations SCPs, Security Hub, Well-Architected, Trusted Advisor
- ID.AM -> Resource tagging, Config rules, asset inventory
- PR.AA -> IAM checks (MFA, password policy, access key rotation, least privilege)
- PR.DS -> Encryption checks (S3, EBS, RDS, CloudTrail, KMS)
- DE.CM -> CloudTrail, GuardDuty, VPC Flow Logs, CloudWatch
- RS.MA -> CloudTrail threat detection, automated fixers

---

## 9. Cross-Tool Integration & Operational Workflows

### Cloud Penetration Testing Workflow

```
Phase 1: Reconnaissance
  cloudfox aws inventory          -- Account size, active regions
  cloudfox aws principals         -- IAM users and roles
  cloudfox aws permissions        -- Full permission enumeration

Phase 2: Attack Path Discovery
  cloudfox aws role-trusts        -- Cross-account, federated trust analysis
  cloudfox aws resource-trusts    -- Resource policy analysis
  cloudfox aws workloads          -- Compute with admin roles
  cloudfox aws env-vars           -- Credential leakage
  cloudfox aws secrets            -- SecretsManager/SSM entries
  cloudfox aws endpoints          -- External attack surface

Phase 3: Privilege Escalation
  cloudfox aws iam-simulator      -- Permission simulation
  cloudfox aws pmapper            -- Transitive privesc paths
  cloudfox aws cape               -- Cross-account privesc

Phase 4: Lateral Movement
  cloudfox aws outbound-assumed-roles  -- Outbound trust paths
  cloudfox aws ram                      -- Shared resources
  cloudfox aws eks                      -- Kubernetes cluster access

Phase 5: Data Access
  cloudfox aws buckets/databases/filesystems  -- Data stores
  cloudfox aws ecr                             -- Container images
  cloudfox aws cloudformation                  -- Stack secrets
```

### Defense Assessment Workflow

```
Phase 1: Compliance Baseline
  prowler aws --compliance cis_6.0_aws     -- CIS benchmark
  prowler aws --compliance nist_csf_2.0    -- NIST CSF mapping
  prowler aws --compliance mitre_attack    -- ATT&CK coverage

Phase 2: Specific Controls
  prowler aws --service iam                -- IAM security
  prowler aws --service s3                 -- S3 security
  prowler aws --service cloudtrail         -- Logging integrity
  prowler aws --check iam_policy_allows_privilege_escalation

Phase 3: Hardening
  cloud-nuke defaults-aws                  -- Remove default VPCs
  Review Prowler findings for remediation

Phase 4: Container Security
  Harbor vulnerability scanning            -- Image CVE analysis
  Harbor content trust (Cosign)            -- Image signature verification
  Harbor RBAC                              -- Access control enforcement
```

### Key Attack Path Patterns to Detect

1. **SSRF -> IMDS -> Credential Theft**: Monitor for unusual EC2 metadata access patterns. Enforce IMDSv2 hop limit.
2. **PassRole + Compute = Admin**: Any principal with iam:PassRole + ability to create compute resources (EC2/Lambda/Glue/ECS) can escalate.
3. **Cross-Account Role Trust without ExternalID**: Confused deputy vulnerability. Always require ExternalID for third-party role assumptions.
4. **Federated Trust without Subject Constraint**: GitHub Actions OIDC, EKS OIDC without subject constraints = anyone can assume the role.
5. **Environment Variable Credential Leakage**: Lambda env vars, ECS task definitions, CodeBuild projects frequently contain hardcoded secrets.
6. **RDS Snapshot Restore**: CreateDBSnapshot + RestoreDBInstanceFromSnapshot + ModifyDBInstance = full database access.
7. **S3 Bucket Policy Public Access**: Resource policies can grant public access even with Block Public Access at bucket level (but not account level).
8. **Terraform State File Exposure**: State files contain all resource attributes in plaintext, including secrets.

---

## 10. Detection Engineering Recommendations

### Sigma Rules for Cloud Attack Detection

**PassRole Privilege Escalation:**
```yaml
title: AWS IAM PassRole Used with Compute Service Creation
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
status: experimental
description: Detects iam:PassRole followed by compute resource creation, indicating potential privilege escalation
logsource:
  category: cloud
  product: aws
detection:
  selection_passrole:
    eventName: 'PassRole'
  selection_compute:
    eventName|contains:
      - 'CreateFunction'
      - 'RunInstances'
      - 'CreateDevEndpoint'
      - 'CreateJob'
      - 'RegisterTaskDefinition'
      - 'CreateStack'
      - 'CreateProject'
  condition: selection_passrole or selection_compute
  timeframe: 5m
falsepositives:
  - Legitimate CI/CD pipelines deploying infrastructure
  - CloudFormation/Terraform operations
level: high
tags:
  - attack.t1548
  - attack.privilege_escalation
```

**Cross-Account Role Assumption:**
```yaml
title: AWS Cross-Account AssumeRole from Unknown Account
id: b2c3d4e5-f6a7-8901-bcde-f12345678901
status: experimental
description: Detects role assumption from accounts not in the known organization
logsource:
  category: cloud
  product: aws
detection:
  selection:
    eventName: 'AssumeRole'
  filter_known:
    userIdentity.accountId|contains:
      - '123456789012'  # Known org accounts
  condition: selection and not filter_known
falsepositives:
  - Legitimate third-party integrations with ExternalID
  - AWS service-linked role assumptions
level: medium
tags:
  - attack.t1078.004
  - attack.initial_access
```

**IMDS Credential Theft Indicator:**
```yaml
title: AWS Temporary Credentials Used from Unexpected Source
id: c3d4e5f6-a7b8-9012-cdef-123456789012
status: experimental
description: Detects instance profile credentials used from IP outside the VPC
logsource:
  category: cloud
  product: aws
detection:
  selection:
    userIdentity.type: 'AssumedRole'
    userIdentity.arn|contains: 'instance-role'
  filter_vpc:
    sourceIPAddress|startswith:
      - '10.'
      - '172.16.'
      - '192.168.'
  condition: selection and not filter_vpc
falsepositives:
  - VPN/NAT gateway egress making source IP appear external
level: high
tags:
  - attack.t1552.005
  - attack.credential_access
```

### CloudTrail Events to Monitor for Privilege Escalation

The following API calls should trigger high-priority alerts:
```
CreatePolicyVersion, SetDefaultPolicyVersion, AttachUserPolicy,
AttachRolePolicy, AttachGroupPolicy, PutUserPolicy, PutRolePolicy,
PutGroupPolicy, CreateAccessKey, CreateLoginProfile, UpdateLoginProfile,
AddUserToGroup, UpdateAssumeRolePolicy, DeleteRolePermissionsBoundary,
DeleteUserPermissionsBoundary, PassRole, CreateFunction, RunInstances,
CreateDevEndpoint, CreateStack, RegisterTaskDefinition
```

---

## Appendix A: Tool Comparison Matrix

| Capability | CloudFox | Prowler | cloud-nuke | CloudGoat |
|---|---|---|---|---|
| Purpose | Offensive enum | Compliance audit | Resource cleanup | Training lab |
| Modifies state | No | No (fixers optional) | YES (destructive) | Creates infra |
| AWS coverage | 34 commands | 200+ checks | 125+ resource types | 28 scenarios |
| GCP coverage | 60 commands | Yes | No | No |
| Azure coverage | 4 commands | Yes | No | 2 scenarios |
| Attack paths | Yes | Detects patterns | No | Demonstrates |
| Compliance | No | 45 frameworks | CIS default VPCs | No |
| Privesc detection | pmapper/cape | Policy analysis | No | Practice scenarios |
| Output | Tables + loot | Reports + dashboard | Deletion log | Deployed infra |

## Appendix B: Key CVE and Attack References

- **Capital One Breach (2019)**: SSRF to EC2 metadata -> S3 access (cloud_breach_s3 scenario)
- **TELCO Breach (2021)**: VPC peering misconfiguration -> prod data access (vpc_peering_overexposed scenario)
- **CVE-2024-28056**: AWS Amplify vulnerability (hackingthe.cloud reference)
- **Confused Deputy**: Cross-account role assumption without ExternalID (role-trusts detection)
- **OIDC Misconfiguration**: GitHub Actions/EKS without subject constraints (CloudFox federated trust detection)
