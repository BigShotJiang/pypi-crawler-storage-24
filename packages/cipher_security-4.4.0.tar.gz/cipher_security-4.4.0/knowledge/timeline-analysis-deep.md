<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Forensic Timeline Analysis — Deep Reference

> CIPHER Training Module | MODE: INCIDENT + BLUE
> Covers super timeline generation, artifact correlation, anti-forensics detection, and pivoting techniques.

---

## Table of Contents

1. [Super Timeline Generation with Plaso](#1-super-timeline-generation-with-plaso)
2. [Timesketch Analysis Workflows](#2-timesketch-analysis-workflows)
3. [Eric Zimmerman Tool Chain](#3-eric-zimmerman-tool-chain)
4. [NTFS Artifact Analysis](#4-ntfs-artifact-analysis)
5. [Windows Registry Timeline Artifacts](#5-windows-registry-timeline-artifacts)
6. [Prefetch Analysis for Execution Evidence](#6-prefetch-analysis-for-execution-evidence)
7. [ShimCache / AmCache Correlation](#7-shimcache--amcache-correlation)
8. [SRUM Analysis](#8-srum-analysis)
9. [Jump Lists and LNK File Analysis](#9-jump-lists-and-lnk-file-analysis)
10. [Timeline Pivoting Techniques](#10-timeline-pivoting-techniques)
11. [Anti-Forensics Detection](#11-anti-forensics-detection)
12. [Quick Reference Cheat Sheet](#12-quick-reference-cheat-sheet)

---

## 1. Super Timeline Generation with Plaso

**Repository**: https://github.com/log2timeline/plaso
**Docs**: https://plaso.readthedocs.io
**License**: Apache 2.0

Plaso (Plaso Langar Ad Safna Ollu — "Plaso ought to collect everything") is a Python-based forensic timeline engine that ingests evidence from disk images, mounted volumes, or individual artifact files and produces a unified "super timeline" of all timestamped events.

### 1.1 Core Tools

| Tool | Purpose |
|------|---------|
| `log2timeline.py` | Extracts events from evidence source into a `.plaso` storage file |
| `psort.py` | Sorts, filters, tags, and exports events from `.plaso` storage |
| `psteal.py` | All-in-one shortcut — combines log2timeline + psort in a single command |
| `pinfo.py` | Displays metadata about a `.plaso` storage file (parser counts, sessions, errors) |

### 1.2 Workflow

#### Quick Method (psteal)

```bash
# One-shot: image to CSV
psteal.py --source image.raw -o dynamic -w timeline.csv

# With specific parsers
psteal.py --source image.raw --parsers "winevtx,prefetch,mft" -o dynamic -w timeline.csv
```

#### Detailed Method (log2timeline + psort)

```bash
# Step 1: Extract all events into Plaso storage
log2timeline.py --storage-file case001.plaso /evidence/image.E01

# Step 1 (targeted): Use specific parsers only
log2timeline.py --parsers "winevtx,winreg,prefetch,mft,lnk" \
  --storage-file case001.plaso /evidence/image.E01

# Step 1 (with filter): Only process specific paths
log2timeline.py --file-filter filter.txt \
  --storage-file case001.plaso /evidence/image.E01

# Step 2: Sort and export to CSV
psort.py -o dynamic -w timeline.csv case001.plaso

# Step 2 (with date filter): Only events in timeframe
psort.py -o dynamic -w timeline.csv case001.plaso \
  "date > '2025-06-01 00:00:00' AND date < '2025-06-15 23:59:59'"

# Step 2 (L2tcsv format for Timesketch import)
psort.py -o l2tcsv -w timeline_l2t.csv case001.plaso

# Inspect storage metadata
pinfo.py case001.plaso
```

### 1.3 Complete Parser List

Plaso ships 50+ parsers with 160+ plugins. Parsers are organized by category:

#### System & Audit Logs
| Parser | Description |
|--------|-------------|
| `asl_log` | Apple System Log (ASL) files |
| `bsm_log` | Basic Security Module (BSM) audit logs (Solaris/macOS) |
| `syslog` | Linux/Unix syslog files |
| `selinux` | SELinux audit logs |
| `utmp` / `utmpx` | Login records (utmp/wtmp/btmp) |
| `systemd_journal` | systemd journal binary logs |

#### Windows Event Logs
| Parser | Description |
|--------|-------------|
| `winevt` | Classic Windows Event Log (.evt) |
| `winevtx` | Modern Windows XML Event Log (.evtx) |

#### Windows Artifacts
| Parser | Description |
|--------|-------------|
| `winreg` | Windows Registry hive files (NTUSER, SYSTEM, SOFTWARE, SAM, SECURITY) |
| `prefetch` | Windows Prefetch files (.pf) |
| `lnk` | Windows Shortcut files (.lnk) |
| `recycle_bin` | Recycle Bin ($I / INFO2) files |
| `jobs` | Windows Task Scheduler (.job) files |
| `winjob` | Windows scheduled task XML files |
| `mcafee_protection` | McAfee AV log files |

#### File System Metadata
| Parser | Description |
|--------|-------------|
| `mft` | NTFS Master File Table ($MFT) |
| `usnjrnl` | NTFS Update Sequence Number Journal ($UsnJrnl:$J) |
| `filestat` | File system timestamps (generic) |
| `bodyfile` | Mactime bodyfile format |

#### Browser Artifacts
| Parser | Description |
|--------|-------------|
| `chrome_cache` | Google Chrome disk cache |
| `chrome_preferences` | Chrome Preferences file |
| `firefox_cache` | Firefox cache (v1) |
| `firefox_cache2` | Firefox cache (v2) |
| `msie_webcache` | IE/Edge WebCacheV01.dat (ESE database) |
| `safari_cookies` | Safari binary cookies (Cookies.binarycookies) |

#### Database Parsers
| Parser | Description |
|--------|-------------|
| `sqlite` | SQLite database files (with 60+ plugins) |
| `esedb` | Extensible Storage Engine databases (with plugins) |
| `olecf` | OLE Compound File (with plugins) |
| `bencode` | Bencoded files (BitTorrent) |

#### macOS / iOS
| Parser | Description |
|--------|-------------|
| `mac_keychain` | macOS Keychain databases |
| `spotlight_storedb` | Spotlight metadata store |
| `unified_logging` | macOS Unified Logging (.tracev3) |
| `fseventsd` | macOS FSEvents |

#### Text Log Plugins (40+)
| Plugin | Description |
|--------|-------------|
| `bash_history` | Bash command history |
| `zsh_extended_history` | Zsh command history (extended format) |
| `fish_history` | Fish shell history |
| `apache_access` | Apache HTTP access logs |
| `apache_error` | Apache HTTP error logs |
| `iis_log` | Microsoft IIS web server logs |
| `syslog_traditional` | Traditional syslog format |
| `syslog_cron` | Cron-specific syslog entries |
| `vsftpd` | vsftpd FTP server logs |
| `dpkg` | Debian package manager logs |
| `popularity_contest` | Debian popularity-contest logs |
| `docker_json_log` | Docker JSON container logs |
| `powershell_transcript` | PowerShell transcript logs |
| `teamviewer_connections` | TeamViewer connection logs |
| `teamviewer_application` | TeamViewer application logs |
| `winfirewall` | Windows Firewall logs |
| `snort_fastlog` | Snort IDS fast alert logs |
| `xchat_log` / `xchat_scrollback` | XChat IRC logs |
| `aws_elb_access` | AWS ELB access logs |
| `setupapi` | Windows SetupAPI device logs |
| `skydrive_log_v1` / `v2` | OneDrive/SkyDrive sync logs |
| `gdrive_synclog` | Google Drive sync logs |

#### SQLite Plugins (60+)
| Plugin | Description |
|--------|-------------|
| `android_calls` | Android call history |
| `android_sms` | Android SMS messages |
| `android_webview` | Android WebView cache |
| `android_turbo` | Android Digital Wellbeing (Turbo) |
| `chrome_history` | Chrome browsing history |
| `chrome_cookies` | Chrome cookie database |
| `chrome_autofill` | Chrome autofill data |
| `chrome_extensions` | Chrome extension activity |
| `chrome_27_history` | Chrome 27+ history format |
| `firefox_history` | Firefox browsing history (places.sqlite) |
| `firefox_downloads` | Firefox downloads |
| `firefox_cookies` | Firefox cookies |
| `safari_history` | Safari browsing history |
| `skype` | Skype conversation database |
| `imessage` | iMessage / Messages.app |
| `hangouts_messages` | Google Hangouts |
| `kik_messenger` | Kik Messenger |
| `twitter_android` | Twitter/X Android app |
| `tango_android` | Tango messaging |
| `dropbox` | Dropbox sync database |
| `gdrive` | Google Drive metadata |
| `windows_timeline` | Windows 10/11 Activity Timeline |
| `ls_quarantine` | macOS LaunchServices quarantine events |
| `mac_notes` | macOS Notes.app |
| `mac_notificationcenter` | macOS Notification Center |

#### Windows Registry Plugins (30+)
| Plugin | Description |
|--------|-------------|
| `amcache` | AmCache.hve application execution |
| `appcompatcache` | Application Compatibility Cache (ShimCache) |
| `bagmru` | ShellBag MRU entries |
| `shellbags` | Explorer ShellBag records |
| `bam` | Background Activity Moderator |
| `ccleaner` | CCleaner configuration |
| `explorer_mountpoints2` | Mounted device records |
| `explorer_programscache` | Start menu program cache |
| `microsoft_office_mru` | Office recent documents |
| `microsoft_outlook_mru` | Outlook recent items |
| `mrulist_shell_item_list` | MRU list with shell items |
| `mrulist_string` | MRU list with strings |
| `mrulistex_shell_item_list` | MRUListEx with shell items |
| `mrulistex_string` | MRUListEx with strings |
| `msie_zone` | IE security zone settings |
| `networks` | Network connection history |
| `userassist` | UserAssist execution tracking |
| `usbstor` | USB storage device history |
| `services` | Windows service configuration |
| `shutdown` | System shutdown times |
| `timezone` | System timezone configuration |
| `typedpaths` | Explorer typed paths |
| `typedurls` | IE typed URLs |
| `winlogon` | Winlogon configuration |
| `run` / `runonce` | Auto-start entries (Run/RunOnce) |
| `sam_users` | SAM user account information |
| `terminal_server_client_mru` | RDP connection history |
| `windows_boot_verify` | Boot verification |

#### ESEDB Plugins
| Plugin | Description |
|--------|-------------|
| `file_history` | Windows File History catalog |
| `msie_webcache` | IE/Edge WebCache database |
| `srum` | System Resource Usage Monitor |
| `user_access_logging` | Windows Server UAL |

#### JSONL Plugins
| Plugin | Description |
|--------|-------------|
| `aws_cloudtrail` | AWS CloudTrail logs |
| `azure_activity_log` | Azure Activity Log |
| `azure_application_gateway` | Azure App Gateway logs |
| `docker_layer_config` | Docker layer configuration |
| `gcp_log` | Google Cloud Platform logs |
| `ios_app_privacy` | iOS App Privacy Report |
| `microsoft365_audit` | Microsoft 365 Unified Audit Log |

#### Plist Plugins (20+)
| Plugin | Description |
|--------|-------------|
| `airport` | macOS WiFi connection history |
| `apple_id` | Apple ID account data |
| `bluetooth` | Bluetooth device pairing history |
| `install_history` | macOS install history |
| `launchd` | macOS launchd configuration |
| `safari_history` | Safari history plist |
| `safari_downloads` | Safari download history |
| `spotlight_volume` | Spotlight volume configuration |
| `time_machine` | Time Machine backup info |

### 1.4 Parser Presets

Presets bundle parsers for common scenarios:

| Preset | Target |
|--------|--------|
| `android` | Android device artifacts |
| `ios` | iOS device artifacts |
| `linux` | Linux system artifacts |
| `macos` | macOS system artifacts |
| `win7` | Windows 7 artifacts |
| `win_gen` | Generic Windows (all versions) |
| `winxp` | Windows XP artifacts |
| `webhist` | Web browser history (cross-platform) |

```bash
# Use a preset
log2timeline.py --parsers "win_gen" --storage-file case.plaso image.E01

# Combine preset with additions
log2timeline.py --parsers "win_gen,sqlite,esedb" --storage-file case.plaso image.E01

# Exclude specific parsers from preset
log2timeline.py --parsers "win_gen,-mcafee_protection" --storage-file case.plaso image.E01
```

### 1.5 Output Formats

| Format | Flag | Use Case |
|--------|------|----------|
| `dynamic` | `-o dynamic` | Flexible CSV with configurable columns |
| `l2tcsv` | `-o l2tcsv` | Log2timeline CSV (Timesketch compatible) |
| `json_line` | `-o json_line` | JSON Lines (Timesketch/Elasticsearch) |
| `opensearch` | `-o opensearch` | Direct OpenSearch/Elasticsearch output |
| `tln` | `-o tln` | Five-field pipe-delimited TLN format |
| `rawpy` | `-o rawpy` | Python native format for debugging |

---

## 2. Timesketch Analysis Workflows

**Repository**: https://github.com/google/timesketch
**License**: Apache 2.0

Timesketch is a collaborative forensic timeline analysis platform backed by OpenSearch/Elasticsearch, providing a web UI for searching, annotating, and sharing timeline data across investigation teams.

### 2.1 Architecture

```
Evidence Sources
      |
      v
  [Plaso / CSV / JSONL]
      |
      v
  Timesketch Importer --> OpenSearch/Elasticsearch
      |
      v
  Web UI / API / Jupyter Notebooks
      |
      v
  Collaborative Analysis (Sketches, Tags, Stars, Comments)
```

### 2.2 Core Concepts

| Concept | Description |
|---------|-------------|
| **Sketch** | Container for an investigation — holds one or more timelines, annotations, and saved searches |
| **Timeline** | A single data source imported into a sketch (e.g., one Plaso output, one CSV) |
| **Event** | A single timestamped entry within a timeline |
| **Tag** | Label applied to events for categorization (e.g., `lateral-movement`, `persistence`) |
| **Star** | Mark important events for later review |
| **Comment** | Free-text annotation on events for team communication |
| **Saved Search** | Reusable search query stored within a sketch |
| **Analyzer** | Automated plugin that enriches or tags events |
| **Story** | Narrative view combining events, notes, and graphs into a report |
| **Graph** | Visual representation of relationships between entities |

### 2.3 Data Import

```bash
# Import Plaso storage file
timesketch_importer --host https://timesketch.example.com \
  --timeline_name "workstation-42" \
  --sketch_id 1 \
  case001.plaso

# Import CSV (must have datetime, timestamp_desc, message columns minimum)
timesketch_importer --host https://timesketch.example.com \
  --timeline_name "firewall-logs" \
  --sketch_id 1 \
  firewall.csv

# Import JSONL
timesketch_importer --host https://timesketch.example.com \
  --timeline_name "cloud-trail" \
  --sketch_id 1 \
  cloudtrail.jsonl
```

**CSV minimum columns:**

| Column | Description |
|--------|-------------|
| `datetime` | ISO 8601 timestamp |
| `timestamp_desc` | Type of timestamp (Created, Modified, Accessed, etc.) |
| `message` | Human-readable event description |

### 2.4 Search Syntax

```
# Basic keyword search
mimikatz

# Field-specific search
data_type:"windows:evtx:record" AND source_name:"Security"

# Event ID targeting
event_identifier:4624 AND xml_string:"LogonType\">3"

# Time-bounded search
datetime:["2025-06-01" TO "2025-06-15"]

# Wildcard and regex
filename:*passwd* OR filename:/.*shadow.*/

# Tag-based filtering
tag:"suspicious" AND tag:"lateral-movement"

# Exclude noise
NOT source_name:"ESENT" AND NOT data_type:"fs:stat"
```

### 2.5 Built-in Analyzers

Timesketch ships with automated analyzers that enrich imported data:

| Analyzer | Function |
|----------|----------|
| **Sigma** | Applies Sigma rules to detect known attack patterns |
| **Domain** | Extracts and tags domain names from URLs |
| **Browser search** | Identifies and tags web search queries |
| **Account finder** | Extracts user accounts from events |
| **MITRE ATT&CK tagger** | Maps events to ATT&CK techniques |
| **Geo IP** | Enriches IP addresses with geolocation data |
| **Hashr** | Correlates file hashes against known databases |
| **Feature extraction** | Pulls out IOCs (IPs, domains, hashes, emails) |
| **Similarity** | Groups similar events using NLP techniques |

### 2.6 API & Notebook Integration

```python
from timesketch_api_client import config
from timesketch_import_client import importer

# Connect to Timesketch
ts = config.get_client()

# Access a sketch
sketch = ts.get_sketch(1)

# Search events
events = sketch.explore(
    query_string='event_identifier:4688 AND filename:*powershell*',
    return_fields='datetime,message,filename,computer_name',
    as_pandas=True
)

# Tag results
for event in events.itertuples():
    sketch.tag_event(event.id, ['suspicious-execution'])

# Run an analyzer
sketch.run_analyzer('sigma', timeline_id=1)
```

### 2.7 Analysis Workflow — Step by Step

1. **Create sketch** for the investigation case
2. **Import timelines** — Plaso output, CSV exports from EZ tools, cloud logs
3. **Run analyzers** — Sigma rules, domain extraction, account finding
4. **Identify anchor events** — known-bad indicators, alerts, or suspicious patterns
5. **Expand context** — search +/- 5 minutes around anchor events
6. **Tag and star** significant events
7. **Build story** — connect events into a narrative with comments
8. **Share** with team for collaborative review
9. **Export** findings for reporting

---

## 3. Eric Zimmerman Tool Chain

**Download**: https://ericzimmerman.github.io/
**License**: MIT (most tools)
**Platform**: Windows (.NET)

Eric Zimmerman's tools are the gold standard for Windows artifact parsing. Every tool follows consistent conventions:

### 3.1 Common Flags (All EZ Tools)

| Flag | Description |
|------|-------------|
| `-f` | Single file input |
| `-d` | Directory input (recursive) |
| `--csv` | CSV output directory |
| `--csvf` | Custom CSV filename |
| `--json` | JSON output directory |
| `--jsonf` | Custom JSON filename |
| `--dt` | Custom datetime format (default: `yyyy-MM-dd HH:mm:ss`) |
| `--mp` | Higher precision timestamps |
| `--vss` | Process Volume Shadow Copies |
| `--dedupe` | Deduplicate across VSCs (SHA-1) |
| `--debug` | Debug output |
| `--trace` | Trace-level output |

### 3.2 MFTECmd — Master File Table Parser

**Parses**: `$MFT`, `$UsnJrnl:$J`, `$LogFile`, `$Boot`, `$SDS`

```bash
# Parse $MFT to CSV
MFTECmd.exe -f "C:\evidence\$MFT" --csv "C:\output" --csvf mft_output.csv

# Parse $MFT to bodyfile format (for mactime timeline)
MFTECmd.exe -f "C:\evidence\$MFT" --body "C:\output" --bodyf mft.body --bdl C

# Parse $UsnJrnl
MFTECmd.exe -f "C:\evidence\$J" --csv "C:\output" --csvf usnjrnl.csv

# Parse $LogFile
MFTECmd.exe -f "C:\evidence\$LogFile" --csv "C:\output"

# Dump details for a specific MFT entry
MFTECmd.exe -f "C:\evidence\$MFT" --de 12345

# Show directory listing for an entry
MFTECmd.exe -f "C:\evidence\$MFT" --de 12345 --fls

# Include short (8.3) filenames
MFTECmd.exe -f "C:\evidence\$MFT" --csv "C:\output" --sn

# Include all $FILENAME timestamps
MFTECmd.exe -f "C:\evidence\$MFT" --csv "C:\output" --at

# Process with VSS
MFTECmd.exe -f "C:\evidence\$MFT" --csv "C:\output" --vss --dedupe
```

**Key output columns**: EntryNumber, SequenceNumber, ParentPath, FileName, Extension, IsDirectory, SI_Created, SI_Modified, SI_Accessed, SI_EntryModified, FN_Created, FN_Modified, FN_Accessed, FN_EntryModified, FileSize, IsADS, ZoneId

### 3.3 PECmd — Prefetch Explorer

**Parses**: Windows Prefetch files (`.pf`) from `C:\Windows\Prefetch`

```bash
# Parse single prefetch file
PECmd.exe -f "C:\evidence\Prefetch\MIMIKATZ.EXE-12345678.pf"

# Parse entire prefetch directory to CSV
PECmd.exe -d "C:\evidence\Prefetch" --csv "C:\output" --csvf prefetch.csv

# With custom keywords highlighted
PECmd.exe -d "C:\evidence\Prefetch" -k "temp,appdata,downloads,public" --csv "C:\output"

# Quiet mode (faster for large directories)
PECmd.exe -d "C:\evidence\Prefetch" -q --csv "C:\output"

# Higher precision timestamps
PECmd.exe -d "C:\evidence\Prefetch" --csv "C:\output" --mp

# JSON output
PECmd.exe -d "C:\evidence\Prefetch" --json "C:\output"

# Export decompressed prefetch data
PECmd.exe -f "C:\evidence\Prefetch\CMD.EXE-AC113AA8.pf" -o "C:\output\decompressed"
```

**Key data extracted**:
- Executable name and path
- Run count (number of executions)
- Last run timestamps (up to 8 on Win8+)
- All files/directories referenced during execution
- Volume information (serial number, creation date)

### 3.4 RECmd — Registry Explorer Command Line

**Parses**: All Windows Registry hive files (NTUSER.DAT, SYSTEM, SOFTWARE, SAM, SECURITY, UsrClass.dat, Amcache.hve)

```bash
# Search registry hive for keyword
RECmd.exe -f "C:\evidence\NTUSER.DAT" --sk "mimikatz"

# Search by value name
RECmd.exe -f "C:\evidence\NTUSER.DAT" --sv "password"

# Search by value data
RECmd.exe -f "C:\evidence\SOFTWARE" --sd "evil.exe"

# Search with regex
RECmd.exe -f "C:\evidence\SYSTEM" --sd "(?i)hack" --RegEx

# Run batch file for automated extraction
RECmd.exe -f "C:\evidence\NTUSER.DAT" --bn "RECmd\BatchExamples\DFIR_Batch.reb" --csv "C:\output"

# Process entire directory of hives
RECmd.exe -d "C:\evidence\Registry" --bn "RECmd\BatchExamples\DFIR_Batch.reb" --csv "C:\output"

# Dump specific key details
RECmd.exe -f "C:\evidence\NTUSER.DAT" --kn "Software\Microsoft\Windows\CurrentVersion\Run"

# Include deleted keys/values
RECmd.exe -f "C:\evidence\NTUSER.DAT" --sk "malware" --Recover

# Base64 detection
RECmd.exe -f "C:\evidence\NTUSER.DAT" --sd "." --Base64 100
```

**Batch file (.reb)**: RECmd batch files define automated extraction rules for specific registry keys/values of forensic interest. The DFIR Batch File covers all major forensic artifacts in one pass.

**RLA (Registry Log Analyzer)**: Companion tool that replays transaction logs (.LOG1, .LOG2) into dirty hives for complete data recovery.

### 3.5 AmcacheParser

**Parses**: `C:\Windows\AppCompat\Programs\Amcache.hve`

```bash
# Standard parse to CSV
AmcacheParser.exe -f "C:\evidence\Amcache.hve" --csv "C:\output"

# Include file entries associated with programs
AmcacheParser.exe -f "C:\evidence\Amcache.hve" -i --csv "C:\output"

# With whitelist (exclude known-good by SHA-1)
AmcacheParser.exe -f "C:\evidence\Amcache.hve" -w "C:\whitelists\nsrl.txt" --csv "C:\output"

# With blacklist (highlight known-bad by SHA-1)
AmcacheParser.exe -f "C:\evidence\Amcache.hve" -b "C:\blacklists\malware_hashes.txt" --csv "C:\output"

# Higher precision timestamps
AmcacheParser.exe -f "C:\evidence\Amcache.hve" --csv "C:\output" --mp

# Ignore transaction logs
AmcacheParser.exe -f "C:\evidence\Amcache.hve" --csv "C:\output" --nl
```

**Data extracted**:
- File path, name, and SHA-1 hash
- Program name, version, publisher
- File compilation timestamp (PE header)
- Installation timestamp
- Associated program linkage (which installer brought this file)
- Unassociated files (not tied to any known installer — high-value for finding malware)

### 3.6 AppCompatCacheParser — ShimCache

**Parses**: `SYSTEM` hive — `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache`

```bash
# Parse SYSTEM hive to CSV
AppCompatCacheParser.exe -f "C:\evidence\SYSTEM" --csv "C:\output"

# Sort by last modified time (descending)
AppCompatCacheParser.exe -f "C:\evidence\SYSTEM" -t --csv "C:\output"

# Specific ControlSet
AppCompatCacheParser.exe -f "C:\evidence\SYSTEM" -c 2 --csv "C:\output"

# Custom CSV filename
AppCompatCacheParser.exe -f "C:\evidence\SYSTEM" --csv "C:\output" --csvf shimcache.csv

# Parse from live system (no -f flag)
AppCompatCacheParser.exe --csv "C:\output"
```

**Supported OS versions**: Windows XP, 7 (x86/x64), 8.x, 10, 11

**Data extracted**:
- File path (full executable path)
- Last modified timestamp (from $STANDARD_INFORMATION)
- Cache entry position (order indicates recency — lower = more recent)
- Execution flag (Win7/8 only — not reliable on Win10+)
- File size
- ControlSet number

### 3.7 SrumECmd — SRUM Parser

**Parses**: `C:\Windows\System32\SRU\SRUDB.dat` (ESE database)

The System Resource Usage Monitor (SRUM) was introduced in Windows 8 and tracks application and network resource usage over 30-60 days. This is one of the most underutilized artifacts in DFIR.

```bash
# Standard parse
SrumECmd.exe -f "C:\evidence\SRUDB.dat" --csv "C:\output"

# With SOFTWARE hive for SID-to-username resolution
SrumECmd.exe -f "C:\evidence\SRUDB.dat" -r "C:\evidence\SOFTWARE" --csv "C:\output"
```

**SRUM tables and forensic value**:

| Table | Data | Forensic Value |
|-------|------|----------------|
| **Application Resource Usage** | CPU time, bytes read/written, foreground/background cycles | Proves application was actively used, not just present |
| **Network Data Usage** | Bytes sent/received per application per interface | Shows which apps communicated and data volume |
| **Network Connectivity** | Connected network profiles, interface types | Places device on specific WiFi networks at specific times |
| **Energy Usage** | Battery drain per application | Corroborates application activity on laptops |
| **Push Notifications** | Push notification metadata | Shows app notification activity |

### 3.8 JLECmd — Jump List Parser

**Parses**: `%APPDATA%\Microsoft\Windows\Recent\AutomaticDestinations\` and `CustomDestinations\`

```bash
# Parse single jump list
JLECmd.exe -f "C:\evidence\1b4dd67f29cb1962.automaticDestinations-ms"

# Parse directory of jump lists to CSV
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --csv "C:\output"

# With full link file details
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --fd --csv "C:\output"

# Dump embedded link files
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --dumpTo "C:\output\lnk_files"

# Custom AppID mapping
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --appIds "C:\appids.txt" --csv "C:\output"

# JSON output with pretty printing
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --json "C:\output" --pretty

# Higher precision timestamps
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --csv "C:\output" --mp

# Process custom destinations too
JLECmd.exe -d "C:\evidence\CustomDestinations" --csv "C:\output"
```

**Data extracted**:
- Application ID (maps to specific program)
- Target file paths (files opened by the application)
- Target creation, modification, access timestamps
- Volume serial number and name
- Network share paths (for remote file access evidence)
- Embedded LNK file data (MAC timestamps, file size, drive type)
- Entry count and position (order of access)

### 3.9 ShellBags Explorer

**Parses**: `NTUSER.DAT` (BagMRU/Bags) and `UsrClass.dat` (BagMRU/Bags)

ShellBags record every folder a user has browsed in Windows Explorer, including folders on network shares, USB drives, and zip files — even after the folder or device is gone.

```bash
# GUI tool — no command-line equivalent
# Use RECmd with batch files for CLI ShellBag extraction:
RECmd.exe -f "C:\evidence\UsrClass.dat" \
  --bn "RECmd\BatchExamples\DFIR_Batch.reb" --csv "C:\output"
```

**Forensic value**:
- Proves a user browsed to a specific folder (even if folder is deleted)
- Records folder view preferences (timestamps when folder view was last set)
- Captures network paths (\\server\share\folder)
- Captures removable media paths (E:\USB_Folder)
- Captures zip file contents browsed
- Persists across deletion — ShellBags are not cleaned when files/folders are deleted

### 3.10 Additional EZ Tools

| Tool | Artifact | Key Use |
|------|----------|---------|
| **LECmd** | LNK (shortcut) files | Target paths, MAC times, volume info, network paths |
| **RBCmd** | Recycle Bin ($I files) | Original path, deletion timestamp, file size |
| **WxTCmd** | Windows Timeline (ActivitiesCache.db) | Application usage, focus time, clipboard history |
| **EvtxECmd** | Windows Event Logs (.evtx) | Parsed event log entries with maps for specific Event IDs |
| **bstrings** | Binary strings extraction | Extract strings with context from binary files |
| **Timeline Explorer** | CSV/Excel viewer | GUI for browsing and filtering EZ tool output |
| **KAPE** | Automated collection & processing | Orchestrates evidence collection and runs EZ tools in batch |

---

## 4. NTFS Artifact Analysis

### 4.1 $MFT (Master File Table)

Every file and directory on an NTFS volume has at least one entry in the MFT. Each entry is 1024 bytes (default) and contains:

#### Key Attributes

| Attribute | Type ID | Content | Forensic Value |
|-----------|---------|---------|----------------|
| `$STANDARD_INFORMATION` | 0x10 | Created, Modified, Accessed, Entry Modified timestamps; file permissions; flags | Timestamps visible to user/OS; target of timestomping |
| `$FILE_NAME` | 0x30 | File name; parent directory reference; Created, Modified, Accessed, Entry Modified timestamps | Less commonly tampered; 8.3 short name variant may exist |
| `$DATA` | 0x80 | File content (resident if small, non-resident for large files) | Actual file data or run list pointers |
| `$ATTRIBUTE_LIST` | 0x20 | Maps to additional MFT entries for large/fragmented files | Indicates complex file structure |
| `$OBJECT_ID` | 0x40 | Unique object identifier | GUID tracking across moves |
| `$REPARSE_POINT` | 0xC0 | Symlink/junction point data | May indicate persistence mechanisms |
| `$EA` / `$EA_INFORMATION` | 0xE0/0xD0 | Extended attributes | Used by some malware for data hiding |

#### Timestamp Analysis

Each MFT entry contains **eight timestamps** (four in $STANDARD_INFORMATION + four in $FILE_NAME):

```
$STANDARD_INFORMATION (0x10)          $FILE_NAME (0x30)
  - Created (B)                         - Created (B)
  - Modified (M)                        - Modified (M)
  - Accessed (A)                        - Accessed (A)
  - Entry Modified (E)                  - Entry Modified (E)
```

**Critical rule**: $FILE_NAME timestamps are set by the kernel and are NOT normally updated after file creation. If $SI timestamps are earlier than $FN timestamps, **timestomping has occurred**. [CONFIRMED — well-established forensic principle]

#### MFT Entry Sequence Numbers

Every MFT entry has a sequence number that increments when the entry is reused. This allows detection of:
- File deletion and MFT entry reuse
- Timeline gaps in file creation/deletion cycles
- Correlation between $UsnJrnl references and current MFT state

### 4.2 $UsnJrnl ($J) — Update Sequence Number Journal

The USN Journal records every change to files and directories on an NTFS volume. Located at `$Extend\$UsnJrnl:$J`.

**Records include**:
- Timestamp of change
- File reference number (MFT entry + sequence)
- Parent directory reference
- File name at time of change
- Reason flags (what changed)

**Reason flags** (combinable):

| Flag | Meaning |
|------|---------|
| `DATA_OVERWRITE` | File data was modified |
| `DATA_EXTEND` | File grew in size |
| `DATA_TRUNCATION` | File was truncated |
| `NAMED_DATA_OVERWRITE` | ADS was modified |
| `FILE_CREATE` | New file created |
| `FILE_DELETE` | File deleted |
| `RENAME_OLD_NAME` | Old name before rename |
| `RENAME_NEW_NAME` | New name after rename |
| `SECURITY_CHANGE` | Permissions changed |
| `BASIC_INFO_CHANGE` | Attributes/timestamps changed |
| `CLOSE` | File handle closed |
| `OBJECT_ID_CHANGE` | Object ID changed |

**Forensic power**: The USN Journal captures changes that leave no other trace — renamed files, temporary files created and deleted, ADS modifications, and permission changes. It provides a granular changelog of file system activity with sub-second resolution.

```bash
# Parse with MFTECmd
MFTECmd.exe -f "C:\evidence\$J" --csv "C:\output" --csvf usnjrnl.csv
```

### 4.3 $LogFile — NTFS Transaction Log

The NTFS transaction log (`$LogFile`) records metadata changes for crash recovery. It contains:
- Redo/undo operations for MFT changes
- File creation/deletion operations
- Attribute modifications
- Partial file content for small resident files

**Forensic value**: Can recover metadata for files that have been deleted and whose MFT entries have been reused, providing an additional layer of timeline data beyond the USN Journal.

```bash
MFTECmd.exe -f "C:\evidence\$LogFile" --csv "C:\output"
```

### 4.4 NTFS Artifact Correlation Matrix

```
Timeline Event              | $MFT | $UsnJrnl | $LogFile | Prefetch | Amcache
---------------------------------------------------------------------------
File created                |  YES |   YES    |   YES    |   ---    |  YES*
File modified               |  YES |   YES    |   YES    |   ---    |  ---
File deleted                |  ---†|   YES    |   YES    |   ---    |  ---
File renamed                |  YES |   YES    |   YES    |   ---    |  ---
File executed               |  YES |   YES    |   ---    |   YES    |  YES
Permissions changed         |  YES |   YES    |   YES    |   ---    |  ---
Timestamp modified (stomp)  |  YES‡|   YES    |   YES    |   ---    |  ---

* Amcache records first execution, not creation per se
† MFT entry may be reused; original data lost
‡ $SI vs $FN comparison reveals timestomping
```

---

## 5. Windows Registry Timeline Artifacts

### 5.1 Registry Timestamp Sources

Every registry key has a **Last Write Time** — the timestamp of the last modification to that key or any of its values. This is the only timestamp in the registry (values do not have individual timestamps).

### 5.2 High-Value Registry Artifacts for Timeline Construction

#### Execution Evidence

| Artifact | Location | Data |
|----------|----------|------|
| **UserAssist** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist\{GUID}\Count` | ROT13-encoded program names, run count, focus time, last run timestamp |
| **BAM/DAM** | `SYSTEM\CurrentControlSet\Services\bam\State\UserSettings\{SID}` | Executable path + last execution UTC timestamp (Win10 1709+) |
| **AppCompatCache** | `SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache` | File path, last modified time, cache position |
| **Amcache** | `Amcache.hve\Root\InventoryApplicationFile` | Full path, SHA-1, link date, install date, publisher |
| **MUICache** | `NTUSER\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache` | Executable description strings (proves execution) |
| **RunMRU** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU` | Commands typed in Run dialog |

#### Persistence Mechanisms

| Artifact | Location | Data |
|----------|----------|------|
| **Run/RunOnce** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Run` | Auto-start entries per user |
| **Run/RunOnce (Machine)** | `SOFTWARE\Microsoft\Windows\CurrentVersion\Run` | Auto-start entries for all users |
| **Services** | `SYSTEM\CurrentControlSet\Services\{name}` | Service binary path, start type, account |
| **Scheduled Tasks** | `SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks` | Task registration and trigger data |
| **Winlogon** | `SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon` | Shell, Userinit, Notify values |

#### File/Folder Access Evidence

| Artifact | Location | Data |
|----------|----------|------|
| **RecentDocs** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs` | Recently opened files by extension |
| **TypedPaths** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths` | Paths typed in Explorer address bar |
| **WordWheelQuery** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\WordWheelQuery` | Explorer search terms |
| **ComDlg32** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32` | Open/Save dialog history |
| **ShellBags** | `NTUSER\Software\...\Shell\BagMRU` + `UsrClass.dat` | Every folder browsed in Explorer |
| **Office MRU** | `NTUSER\Software\Microsoft\Office\{ver}\{app}\File MRU` | Recently opened Office documents |

#### Network/External Device Evidence

| Artifact | Location | Data |
|----------|----------|------|
| **USB (USBSTOR)** | `SYSTEM\CurrentControlSet\Enum\USBSTOR` | Device class, serial number, first/last connect timestamps |
| **USB (USB)** | `SYSTEM\CurrentControlSet\Enum\USB` | VID/PID (vendor/product ID) |
| **MountPoints2** | `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2` | Volumes mounted by user |
| **NetworkList** | `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures` | Connected networks with first/last connect timestamps |
| **Terminal Server MRU** | `NTUSER\Software\Microsoft\Terminal Server Client\Servers` | RDP connection targets |
| **TypedURLs** | `NTUSER\Software\Microsoft\Internet Explorer\TypedURLs` | URLs typed in IE/legacy Edge |

### 5.3 python-registry Library

**Repository**: https://github.com/williballenthin/python-registry

For custom analysis scripts, python-registry provides a pure Python API:

```python
from Registry import Registry

reg = Registry.Registry("/evidence/NTUSER.DAT")

# Read UserAssist entries
key = reg.open("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\UserAssist")
for subkey in key.subkeys():
    count_key = subkey.subkey("Count")
    for value in count_key.values():
        # Decode ROT13 name
        import codecs
        name = codecs.decode(value.name(), 'rot_13')
        print(f"Program: {name}")

# Read Run key
try:
    run = reg.open("Software\\Microsoft\\Windows\\CurrentVersion\\Run")
    for value in run.values():
        print(f"Autostart: {value.name()} = {value.value()}")
except Registry.RegistryKeyNotFoundException:
    print("Run key not found")

# Read BAM entries from SYSTEM hive
system = Registry.Registry("/evidence/SYSTEM")
bam = system.open("ControlSet001\\Services\\bam\\State\\UserSettings")
for sid_key in bam.subkeys():
    print(f"User SID: {sid_key.name()}")
    for value in sid_key.values():
        if value.name() != "Version" and value.name() != "SequenceNumber":
            print(f"  Executed: {value.name()}")
```

---

## 6. Prefetch Analysis for Execution Evidence

### 6.1 What Prefetch Proves

Windows Prefetch (`C:\Windows\Prefetch`) is **execution evidence**. Each `.pf` file records:
- The executable was run (existence of the file = proof of execution)
- When it was last run (up to 8 timestamps on Win8+)
- How many times it was run (run count)
- What files and directories it touched during the first 10 seconds of execution

### 6.2 Prefetch File Naming

Format: `{EXECUTABLE_NAME}-{HASH}.pf`

The hash is calculated from the executable path and (on some OS versions) command-line arguments. Different paths to the same executable produce different prefetch files:
- `CMD.EXE-AC113AA8.pf` — from `C:\Windows\System32\`
- `CMD.EXE-4F10BCA5.pf` — from a different path

### 6.3 Prefetch Limitations

| OS | Max Files | Notes |
|----|-----------|-------|
| Windows XP/Vista/7 | 128 | 1 last run timestamp only |
| Windows 8/8.1/10/11 | 1024 | Up to 8 last run timestamps |
| Windows Server | Disabled by default | Must enable via registry |

**Registry control**: `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters`
- `EnablePrefetcher` = 0 (disabled), 1 (application only), 2 (boot only), 3 (both)

### 6.4 Forensic Analysis Workflow

```
1. Parse all prefetch files:
   PECmd.exe -d "C:\evidence\Prefetch" --csv "C:\output" --mp

2. Sort by LastRun timestamp to build execution timeline

3. Check for suspicious executables:
   - Tools not expected on this system (psexec, mimikatz, procdump)
   - Executables run from unusual paths (Temp, AppData, Downloads, Public)
   - Executables with randomized names
   - Multiple instances of the same tool from different paths

4. Examine referenced files/directories for each suspicious prefetch:
   - DLLs loaded (did it load a malicious DLL?)
   - Files accessed (what data did it touch?)
   - Directories accessed (where did it operate?)

5. Cross-reference with Amcache/ShimCache for hash values
```

### 6.5 Key Prefetch Indicators

| Pattern | Implication |
|---------|-------------|
| `POWERSHELL.EXE` referencing `\Downloads\*.ps1` | Script execution from untrusted location |
| `CMD.EXE` referencing `\Temp\*.bat` | Batch file execution from temp |
| `WMIC.EXE` or `MSHTA.EXE` | Potential living-off-the-land execution |
| `PSEXEC*.EXE` or `PSEXESVC.EXE` | Remote execution tool |
| `RUNDLL32.EXE` with unusual DLL paths | DLL proxy execution |
| `CERTUTIL.EXE` referencing non-cert files | Potential download/decode abuse |
| `NET.EXE` / `NET1.EXE` | Enumeration or account manipulation |
| Multiple `SVCHOST.EXE-*.pf` from non-System32 | Masquerading malware |

---

## 7. ShimCache / AmCache Correlation

### 7.1 Understanding the Difference

| Aspect | ShimCache (AppCompatCache) | AmCache (Amcache.hve) |
|--------|---------------------------|----------------------|
| **Location** | SYSTEM registry hive | `C:\Windows\AppCompat\Programs\Amcache.hve` |
| **Written** | On shutdown (flushed from memory) | Near real-time on execution |
| **Proves execution** | Not reliably on Win10+ (proves file existed, not necessarily ran) | Yes — stronger execution evidence |
| **Contains hash** | No | Yes (SHA-1) |
| **Contains path** | Yes (full path) | Yes (full path) |
| **Timestamp** | $SI Last Modified of the file | First execution time, compile time |
| **Persistence** | Last ~1024 entries | Historical data (until hive rotation) |
| **Order matters** | Yes — position indicates recency (lower = more recent) | No |

### 7.2 Correlation Technique

```
For each suspicious file:

1. Check ShimCache for presence + position
   - Present + low position = recently interacted with
   - Present + high position = older interaction
   - Absent = not in last ~1024 entries (or never seen)

2. Check AmCache for SHA-1 hash
   - Hash present = file was executed
   - Compare hash against threat intel (VirusTotal, NSRL)
   - Check compile timestamp vs. first seen timestamp
     (large gap may indicate re-timestomped or redistributed binary)

3. Check AmCache "Unassociated" entries
   - Files not linked to any installed program
   - High-value source for finding dropped malware

4. Cross-reference with Prefetch
   - Prefetch present = strongest execution evidence
   - Prefetch referenced files show what the executable touched

5. Cross-reference with $MFT
   - Compare $SI timestamps vs. $FN timestamps (timestomping check)
   - Check Zone.Identifier ADS (was file downloaded from internet?)
```

### 7.3 Timeline Correlation Example

```
Incident: Lateral movement via PsExec at 2025-06-10 14:32:00 UTC

ShimCache:  C:\Windows\PSEXESVC.exe | Position: 3 | Modified: 2025-06-10 14:31:45
AmCache:    C:\Windows\PSEXESVC.exe | SHA-1: abc123... | First Run: 2025-06-10 14:32:01
Prefetch:   PSEXESVC.EXE-1234ABCD.pf | Last Run: 2025-06-10 14:32:01 | Run Count: 1
$MFT:       PSEXESVC.exe | SI Created: 2025-06-10 14:31:45 | FN Created: 2025-06-10 14:31:45
$UsnJrnl:   PSEXESVC.exe | FILE_CREATE | 2025-06-10 14:31:45
$UsnJrnl:   PSEXESVC.exe | FILE_DELETE | 2025-06-10 14:35:12
Event Log:  Security 4624 | LogonType 3 | Source: 10.0.1.50 | 2025-06-10 14:31:44
Event Log:  System 7045 | New Service: PSEXESVC | 2025-06-10 14:32:00

Conclusion: PsExec lateral movement from 10.0.1.50, service installed and
            binary cleaned up 3 minutes later. Full execution confirmed by
            four independent artifact sources.
```

---

## 8. SRUM Analysis

### 8.1 What SRUM Tracks

The System Resource Usage Monitor (Windows 8+) stores 30-60 days of granular application and network usage data in an ESE database at `C:\Windows\System32\SRU\SRUDB.dat`.

### 8.2 SRUM Tables

#### Application Resource Usage
| Field | Forensic Value |
|-------|----------------|
| Application (full path or SID) | Identifies exactly what ran |
| User SID | Maps execution to specific user |
| Foreground/Background Cycle Count | Proves active user interaction vs. background process |
| Foreground/Background CPU Time | Duration of execution |
| Bytes Read/Written (face/non-face) | Volume of disk I/O |
| Timestamp | When the measurement was recorded |

#### Network Data Usage
| Field | Forensic Value |
|-------|----------------|
| Application | Which program sent/received data |
| Bytes Sent/Received | Volume of network communication |
| Interface LUID | Which network adapter was used |
| Profile ID | Maps to specific WiFi network or connection |
| User SID | Attributes network use to specific user |

#### Network Connectivity
| Field | Forensic Value |
|-------|----------------|
| Interface LUID | Network interface identifier |
| Profile (SSID/Connection Name) | Which network the device was on |
| Connected Time | Duration of connection |
| Connect Start Time | When device joined the network |

#### Energy Usage
| Field | Forensic Value |
|-------|----------------|
| Application | Consuming application |
| Charge Level | Battery state (laptop geolocation/usage correlation) |
| Designed Capacity vs. Full Charged | Battery health context |

### 8.3 SRUM Forensic Applications

**Proving data exfiltration**:
```
If SRUM shows:
  Application: C:\Users\user\AppData\Local\Temp\rclone.exe
  Bytes Sent: 4,831,206,400 (4.5 GB)
  Interface: WiFi - "CorpNetwork"
  Timestamp: 2025-06-10 02:15:00

This proves rclone.exe transmitted 4.5 GB over corporate WiFi at 2:15 AM,
even if the binary has been deleted.
```

**Proving persistent access**:
```
If SRUM shows daily entries for:
  Application: C:\ProgramData\svchost.exe  (note: wrong path for legit svchost)
  Bytes Sent/Received: consistent daily traffic
  Duration: 30+ days of foreground cycle time

This proves a masquerading process maintained network communication for a month.
```

**Identifying WiFi network history**:
```
Network Connectivity entries show the device was connected to:
  "HotelWiFi-Guest" from 2025-06-08 to 2025-06-10
  "Airport-Free-WiFi" on 2025-06-11
  "CorpNetwork" from 2025-06-12 onward

This places the device at specific locations even without GPS data.
```

### 8.4 SRUM + SOFTWARE Hive Correlation

The SOFTWARE registry hive contains the mapping between SIDs and network interface LUIDs and human-readable names. Always extract both:

```bash
SrumECmd.exe -f "C:\evidence\SRUDB.dat" -r "C:\evidence\SOFTWARE" --csv "C:\output"
```

Without the SOFTWARE hive, SRUM output shows raw SIDs and GUIDs instead of usernames and network names.

---

## 9. Jump Lists and LNK File Analysis

### 9.1 Jump List Types

| Type | Location | Tracks |
|------|----------|--------|
| **Automatic Destinations** | `%APPDATA%\Microsoft\Windows\Recent\AutomaticDestinations\` | Files automatically tracked by OS (recently opened) |
| **Custom Destinations** | `%APPDATA%\Microsoft\Windows\Recent\CustomDestinations\` | Application-defined pinned/frequent items |

Jump List filenames are based on AppIDs — a hash derived from the application path:

| AppID | Application |
|-------|-------------|
| `1b4dd67f29cb1962` | Windows Explorer (pinned/frequent folders) |
| `5f7b5f1e01b83767` | Notepad |
| `a7bd71699cd38d1c` | Word 2016+ |
| `d00655d2aa12ff6d` | Excel 2016+ |
| `9b9cdc69c1c24e2b` | Notepad++ |
| `290532160612e071` | WinRAR |
| `918e0ecb43d17e23` | Notepad (Win11) |
| `12dc1ea8e34b5a6` | Remote Desktop (mstsc.exe) |
| `1ced32c9e183f848` | VLC |

### 9.2 Forensic Value of Jump Lists

- **File access evidence**: Proves specific files were opened with specific applications
- **Remote file access**: Network paths in jump list entries prove access to file shares
- **Temporal evidence**: Embedded timestamps show when files were accessed
- **Survives file deletion**: Jump list entries persist even after the target file is deleted
- **Application-specific**: Each application has its own jump list, enabling per-application file access history

### 9.3 LNK File Analysis

LNK (shortcut) files are embedded inside Jump Lists and also exist independently in `%APPDATA%\Microsoft\Windows\Recent\`.

**LNK file data**:

| Field | Description | Forensic Value |
|-------|-------------|----------------|
| Target path | Full path to target file | Where the file was located |
| Target MAC times | Created/Modified/Accessed of target | When the target was last interacted with |
| Target file size | Size of the target | Confirms specific file version |
| Volume serial number | Serial of the volume containing target | Identifies specific USB drive or volume |
| Volume label | Name of the volume | Human-readable volume identification |
| Drive type | Fixed, removable, network | Distinguishes local vs. USB vs. network |
| Network share path | UNC path for network targets | Proves access to specific shares |
| Machine ID (NetBIOS name) | System where LNK was created | Source system identification |
| MAC address | Embedded in LNK header | Can identify the machine (unreliable) |

```bash
# Parse LNK files with LECmd
LECmd.exe -d "C:\evidence\Recent" --csv "C:\output" --csvf lnk_files.csv

# Parse jump lists
JLECmd.exe -d "C:\evidence\AutomaticDestinations" --csv "C:\output" --csvf jumplists.csv
JLECmd.exe -d "C:\evidence\CustomDestinations" --csv "C:\output" --csvf custom_jumplists.csv
```

---

## 10. Timeline Pivoting Techniques

### 10.1 The Pivot Method

Timeline pivoting is the core investigative technique: identify an anchor event, then expand outward to reconstruct the full attack chain.

```
                    ←— EXPAND BACKWARD (cause) —←
                           |
                    [ ANCHOR EVENT ]
                           |
                    →— EXPAND FORWARD (effect) —→
```

### 10.2 Identifying Anchor Events

| Source | Anchor Type | Example |
|--------|-------------|---------|
| Alert/Detection | Known-bad indicator | EDR alert on mimikatz.exe execution |
| Threat Intel | IOC match | Known C2 IP in firewall logs |
| Anomaly | Behavioral deviation | First-time service creation at 3 AM |
| User report | Observed symptom | "My files are encrypted" |
| External notification | Third-party report | "Your IP is attacking us" |

### 10.3 Expansion Techniques

#### Temporal Expansion

```
Given anchor event at T:

1. Pull all events in [T-5min, T+5min] — immediate context
2. Expand to [T-1hr, T+1hr] — operational context
3. Expand to [T-24hr, T+24hr] — daily context
4. Check same time on previous days (attacker patterns)
```

#### Entity Expansion

```
Given anchor event involving Entity E:

1. All events involving E across all data sources
   - E = user account → all logon events, process creation, file access
   - E = IP address → all connections, DNS queries, firewall logs
   - E = file hash → all execution events, file creation/copy events
   - E = hostname → all events from/to that system

2. Related entities
   - Parent process of suspicious process
   - User account that owns the process
   - Network connections made by the process
   - Files touched by the process
```

#### Artifact Cross-Reference Expansion

```
Anchor: Suspicious executable "update.exe" found

1. $MFT → When was it created? What are its timestamps? Zone.Identifier?
2. $UsnJrnl → Full lifecycle: create, modify, rename, delete events
3. Prefetch → Was it executed? When? How many times? What did it load?
4. AmCache → SHA-1 hash? First execution? Compile time?
5. ShimCache → Position in cache? Last modified timestamp?
6. SRUM → Network usage? How much data did it send?
7. Jump Lists → Was it opened via any application?
8. Event Logs → Process creation (4688)? Service install (7045)?
9. Registry → Persistence entries? UserAssist? BAM?
```

### 10.4 Timeline Analysis Patterns

#### Pattern: Lateral Movement Detection

```
Sequence to look for:
  T+0: Network logon (4624 Type 3) from Source IP
  T+1s: Service created (7045) — e.g., PSEXESVC
  T+2s: Process creation (4688) — service binary executes
  T+Ns: Additional process creation — attacker commands
  T+Xs: Logoff (4634)

Cross-reference:
  - Source IP → repeat across other endpoints (fan-out pattern)
  - Service name → same across endpoints = same tool
  - Time pattern → sequential timestamps across hosts = single operator
```

#### Pattern: Data Staging and Exfiltration

```
Sequence to look for:
  T+0: Archive tool execution (Prefetch: 7Z.EXE, RAR.EXE)
  T+1: Large file creation ($MFT, $UsnJrnl)
  T+2: Archive file in staging directory
  T+3: Network transfer (SRUM: high bytes-sent for unusual process)
  T+4: Archive deletion ($UsnJrnl: FILE_DELETE)
  T+5: Tool deletion ($UsnJrnl: FILE_DELETE)

SRUM correlation:
  - Application with sudden spike in bytes-sent
  - Compare bytes-sent to known staging file size
```

#### Pattern: Persistence Installation

```
Sequence to look for:
  T+0: File creation ($MFT) — malware binary dropped
  T+1: Registry modification (Event 4657 or registry last-write time)
         - Run key, Service, Scheduled Task
  T+2: First execution (Prefetch created, AmCache entry)
  T+3: Subsequent executions at regular intervals (Prefetch run count > 1)

Registry cross-reference:
  - RECmd batch output → all persistence locations in one view
  - Compare registry last-write times to file creation times
  - Check if binary in persistence location matches AmCache hash
```

### 10.5 Super Timeline Filtering Strategy

A full super timeline can contain millions of events. Use this layered approach:

```
Layer 1: Known-bad filtering
  - Search for IOCs (hashes, IPs, domains, filenames)
  - Search for known tool names
  - Apply Sigma rules (in Timesketch)

Layer 2: Temporal filtering
  - Narrow to incident timeframe
  - Focus on specific hours around anchor events

Layer 3: Anomaly filtering
  - First-time events (new executables, new services, new scheduled tasks)
  - Events outside business hours
  - Events from unusual user accounts
  - Events involving unusual paths (Temp, AppData, ProgramData, Public)

Layer 4: Noise reduction
  - Exclude known-good baselines (SRUM normal traffic, routine service restarts)
  - Exclude system-generated noise (ESENT, WSearch indexing, Windows Update)
  - Group similar events (e.g., hundreds of file reads = single application scanning)
```

---

## 11. Anti-Forensics Detection

### 11.1 Timestomping Detection

**What it is**: Modifying $STANDARD_INFORMATION timestamps to make malicious files appear older or blend in with legitimate system files.

**Detection methods**:

| Method | Technique | Tool |
|--------|-----------|------|
| **$SI vs $FN comparison** | $FN timestamps set by kernel, rarely tampered. If $SI Created < $FN Created, file is timestomped | MFTECmd (`--at` flag) |
| **$UsnJrnl correlation** | USN Journal records `BASIC_INFO_CHANGE` when timestamps are modified via SetFileTime() | MFTECmd (parse $J) |
| **Nanosecond analysis** | Timestomping tools often zero out sub-second precision. Legitimate NTFS timestamps have non-zero nanoseconds | MFTECmd (`--mp` flag) |
| **Cluster analysis** | File's $MFT entry number should roughly correlate with creation time. Entry 85000 with a 2019 timestamp on a 2024 system is suspicious | MFTECmd — sort by entry number vs. timestamp |
| **$LogFile analysis** | Transaction log may contain the original timestamps before modification | MFTECmd (parse $LogFile) |

```bash
# Extract all timestamps including $FN for comparison
MFTECmd.exe -f "$MFT" --csv "C:\output" --at --mp

# In the CSV, flag entries where:
#   SI_Created < FN_Created  (timestomped)
#   SI timestamps have 0000000 nanoseconds (tool artifact)
#   Entry number is high but SI_Created is old (chronological anomaly)
```

### 11.2 Log Deletion Detection

**Event Log clearing**:
- **Event ID 1102** (Security log cleared) — logged automatically, cannot be prevented
- **Event ID 104** (System log cleared) — logged in System log
- **Event ID 1100** (Event logging service shutdown) — potential indicator

**Detection in timeline**:
```
Look for:
  1. Gap in event log continuity (events stop and restart)
  2. Event 1102/104 entries
  3. $UsnJrnl showing deletion of .evtx files
  4. Prefetch for wevtutil.exe (Event Log manipulation tool)
  5. ShimCache/AmCache entries for wevtutil.exe or cleaner tools
```

**USN Journal clearing**:
- `fsutil usn deletejournal /d C:` — requires admin
- Detection: absence of USN Journal where expected, or journal with suspiciously recent start point
- $LogFile may still contain evidence of the deletion operation

### 11.3 Prefetch Destruction

**Methods attackers use**:
- Delete specific .pf files
- Disable prefetching via registry
- Clear entire Prefetch directory

**Detection**:
- $UsnJrnl: `FILE_DELETE` entries for .pf files
- Registry: `EnablePrefetcher` changed to 0 (registry last-write time shows when)
- $MFT: Deleted .pf entries may still have allocated MFT records
- ShimCache/AmCache: Still contain execution evidence even if prefetch is deleted
- Timestamp gap: Sudden absence of prefetch files is itself an indicator

### 11.4 MFT Record Overwriting

**What attackers do**: Run a tool that creates and deletes many files to force MFT entry reuse, overwriting evidence of deleted malicious files.

**Detection**:
- High sequence numbers on MFT entries (indicates heavy reuse)
- $UsnJrnl may still reference the original files if not also cleared
- $LogFile redo/undo records may contain original metadata
- SRUM data persists independently of file system artifacts

### 11.5 Volume Shadow Copy Deletion

**Common attacker action**: `vssadmin delete shadows /all /quiet`

**Detection**:
- Prefetch: `VSSADMIN.EXE-*.pf` execution
- Event Log: Event ID 7036 (VSS service state change)
- $UsnJrnl: Metadata changes related to VSC operations
- AmCache/ShimCache: vssadmin.exe execution evidence
- Process creation logs (4688): Full command line captured

### 11.6 Anti-Forensics Detection Matrix

| Anti-Forensics Technique | Detection Source 1 | Detection Source 2 | Detection Source 3 |
|--------------------------|-------------------|-------------------|-------------------|
| Timestomping | $SI vs $FN (MFT) | $UsnJrnl BASIC_INFO_CHANGE | Nanosecond analysis |
| Event log clearing | Event 1102/104 | $UsnJrnl (.evtx deletion) | Prefetch (wevtutil.exe) |
| Prefetch deletion | $UsnJrnl (.pf deletion) | AmCache (still has entries) | ShimCache (still has entries) |
| File secure deletion | $UsnJrnl (records deletion) | $MFT (may retain entry) | SRUM (network usage persists) |
| USN Journal clearing | $LogFile (may retain ops) | Registry (fsutil execution) | Event logs (admin activity) |
| VSS deletion | Prefetch (vssadmin) | Event 7036 | Process creation 4688 |
| Registry cleaning | Registry transaction logs | $UsnJrnl (hive file changes) | AmCache (cleaner execution) |
| Artifact wiping tools | Prefetch (cleaner.exe) | AmCache/ShimCache | SRUM (cleaner I/O activity) |

**Key principle**: Destroying one artifact source creates evidence in other artifact sources. Complete evidence destruction requires simultaneously clearing MFT, USN Journal, LogFile, Prefetch, AmCache, ShimCache, SRUM, Event Logs, Registry, Jump Lists, and ShellBags — which is operationally nearly impossible without detection. [CONFIRMED]

---

## 12. Quick Reference Cheat Sheet

### 12.1 Evidence Collection Order

```
1. Memory (volatile — collect first)
2. $MFT, $UsnJrnl:$J, $LogFile (NTFS metadata)
3. Event Logs (*.evtx from C:\Windows\System32\winevt\Logs\)
4. Registry hives (SYSTEM, SOFTWARE, SAM, SECURITY, NTUSER.DAT, UsrClass.dat, Amcache.hve)
5. Prefetch files (C:\Windows\Prefetch\)
6. SRUM database (C:\Windows\System32\SRU\SRUDB.dat)
7. Jump Lists and Recent files
8. Browser artifacts
9. Full disk image
```

### 12.2 Complete Processing Pipeline

```bash
# Step 1: Parse NTFS artifacts
MFTECmd.exe -f "$MFT" --csv output --at --mp
MFTECmd.exe -f "$J" --csv output
MFTECmd.exe -f "$LogFile" --csv output

# Step 2: Parse execution artifacts
PECmd.exe -d "Prefetch/" --csv output --mp
AmcacheParser.exe -f "Amcache.hve" -i --csv output
AppCompatCacheParser.exe -f "SYSTEM" -t --csv output

# Step 3: Parse user activity artifacts
JLECmd.exe -d "AutomaticDestinations/" --csv output --mp
JLECmd.exe -d "CustomDestinations/" --csv output --mp
LECmd.exe -d "Recent/" --csv output

# Step 4: Parse registry artifacts
RECmd.exe -d "Registry/" --bn DFIR_Batch.reb --csv output

# Step 5: Parse SRUM
SrumECmd.exe -f "SRUDB.dat" -r "SOFTWARE" --csv output

# Step 6: Parse event logs
EvtxECmd.exe -d "winevt/Logs/" --csv output

# Step 7: Generate super timeline (Plaso)
log2timeline.py --storage-file case.plaso /evidence/image.E01
psort.py -o l2tcsv -w timeline.csv case.plaso

# Step 8: Import into Timesketch
timesketch_importer --timeline_name "case001" --sketch_id 1 case.plaso

# Step 9: Analyze in Timeline Explorer (GUI) or Timesketch (web)
```

### 12.3 Key Event IDs for Timeline Correlation

| Event ID | Log | Description |
|----------|-----|-------------|
| 4624 | Security | Successful logon (check LogonType) |
| 4625 | Security | Failed logon |
| 4634/4647 | Security | Logoff |
| 4648 | Security | Explicit credential logon (runas, PsExec) |
| 4672 | Security | Special privileges assigned (admin logon) |
| 4688 | Security | Process creation (requires audit policy) |
| 4689 | Security | Process termination |
| 4697 | Security | Service installed |
| 4698/4702 | Security | Scheduled task created/updated |
| 4720 | Security | User account created |
| 4732 | Security | User added to local group |
| 4776 | Security | NTLM credential validation |
| 1102 | Security | Audit log cleared |
| 7034 | System | Service crashed unexpectedly |
| 7036 | System | Service state change (started/stopped) |
| 7040 | System | Service start type changed |
| 7045 | System | New service installed |
| 1 | Sysmon | Process creation (with hash + parent) |
| 3 | Sysmon | Network connection |
| 7 | Sysmon | Image loaded (DLL) |
| 8 | Sysmon | CreateRemoteThread |
| 10 | Sysmon | Process access (credential dumping) |
| 11 | Sysmon | File created |
| 12/13/14 | Sysmon | Registry event (create/set/rename) |
| 22 | Sysmon | DNS query |
| 23 | Sysmon | File delete archived |
| 25 | Sysmon | Process tampering |

### 12.4 Logon Type Reference

| Type | Name | Description |
|------|------|-------------|
| 2 | Interactive | Console/physical logon |
| 3 | Network | SMB, PsExec, WMI remote |
| 4 | Batch | Scheduled task |
| 5 | Service | Service startup |
| 7 | Unlock | Workstation unlock |
| 8 | NetworkCleartext | IIS Basic auth (cleartext password) |
| 9 | NewCredentials | RunAs /netonly |
| 10 | RemoteInteractive | RDP |
| 11 | CachedInteractive | Domain logon with cached credentials |

---

## References

- **Plaso**: https://github.com/log2timeline/plaso | https://plaso.readthedocs.io
- **Timesketch**: https://github.com/google/timesketch | https://timesketch.org
- **Eric Zimmerman Tools**: https://ericzimmerman.github.io/
- **MFT_Browser**: https://github.com/kacos2000/MFT_Browser
- **python-registry**: https://github.com/williballenthin/python-registry
- **AboutDFIR**: https://aboutdfir.com/
- **SANS DFIR Poster**: https://www.sans.org/posters/windows-forensic-analysis/
- **13Cubed YouTube**: Windows forensic artifact walkthroughs
- **MITRE ATT&CK**: https://attack.mitre.org/ (map findings to techniques)
