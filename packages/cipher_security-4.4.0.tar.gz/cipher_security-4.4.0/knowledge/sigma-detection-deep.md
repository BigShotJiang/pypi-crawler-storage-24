<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Sigma Detection Rules -- Deep Reference

> CIPHER Training Material | Detection Engineering | Last updated: 2026-03-14
> Sources: SigmaHQ/sigma, SigmaHQ/sigma-specification v2.1.0, pySigma, Hayabusa, Chainsaw

---

## Table of Contents

1. [What is Sigma](#1-what-is-sigma)
2. [Rule Format Specification](#2-rule-format-specification)
3. [Detection Logic Deep Dive](#3-detection-logic-deep-dive)
4. [Value Modifiers Reference](#4-value-modifiers-reference)
5. [Log Source Taxonomy](#5-log-source-taxonomy)
6. [Example Rules by Category](#6-example-rules-by-category)
7. [Rule Conversion and Tooling](#7-rule-conversion-and-tooling)
8. [Detection Coverage Matrix](#8-detection-coverage-matrix)
9. [Companion Tools](#9-companion-tools)
10. [Operational Guidance](#10-operational-guidance)

---

## 1. What is Sigma

Sigma is a vendor-agnostic, open signature format for describing log events. It occupies the same role for SIEM/log analysis that Snort fills for network traffic and YARA fills for file scanning. Sigma rules are written in YAML and can be converted into queries for any supported backend: Splunk SPL, Elasticsearch/OpenSearch Query DSL, Microsoft Sentinel KQL, CrowdStrike LogScale, Grafana Loki LogQL, and dozens more.

The SigmaHQ repository contains **3000+ community rules** organized into:

```
rules/                    # Production detection rules
rules-threat-hunting/     # Broader hunting queries (noisier)
rules-emerging-threats/   # Time-sensitive threat-specific rules
rules-compliance/         # Compliance violation detection
rules-dfir/              # Digital forensics & incident response
rules-placeholder/       # Template rules with placeholders
deprecated/              # Superseded rules
```

### Windows Rule Categories (17 total)

```
builtin/                 # Windows Event Log (Security, System, Application, etc.)
create_remote_thread/    # CreateRemoteThread API abuse
create_stream_hash/      # Alternate Data Stream creation
dns_query/               # DNS query monitoring (Sysmon EventID 22)
driver_load/             # Kernel driver loading
file/                    # File system operations (create, modify, delete, rename)
image_load/              # DLL/image loading events
network_connection/      # Outbound/inbound network connections
pipe_created/            # Named pipe creation
powershell/              # PowerShell Script Block & Module logging
process_access/          # Process handle operations (OpenProcess)
process_creation/        # Process execution (largest category)
process_tampering/       # Process hollowing, Herpaderping
raw_access_thread/       # Raw disk access
registry/                # Registry operations (add, set, delete, event)
sysmon/                  # Sysmon-specific events
wmi_event/               # WMI event subscriptions
```

---

## 2. Rule Format Specification

Based on Sigma Rules Specification v2.1.0.

### Field Reference

| Field | Required | Description |
|-------|----------|-------------|
| `title` | **YES** | Brief detection description. Max 256 characters. |
| `id` | No | UUID v4 globally unique identifier. |
| `name` | No | Unique human-readable name (used in correlation rules). |
| `related` | No | References to related rule IDs with relationship type (`obsolete`, `derived`, `similar`). |
| `status` | No | Rule maturity level. |
| `description` | No | Detailed explanation. Max 65,535 characters. |
| `license` | No | SPDX license identifier. |
| `author` | No | Creator name(s), comma-separated. |
| `references` | No | List of source URLs (blogs, papers, advisories). |
| `date` | No | Creation date (ISO 8601: `YYYY-MM-DD`). |
| `modified` | No | Last modification date (ISO 8601). |
| `logsource` | **YES** | Defines what log data the rule targets. |
| `detection` | **YES** | Search identifiers and condition defining detection logic. |
| `fields` | No | Log fields useful for analyst triage. |
| `falsepositives` | No | List of known FP scenarios. |
| `level` | No | Severity/criticality rating. |
| `tags` | No | Categorization tags (ATT&CK, CVE, etc.). |
| `scope` | No | Target system types. |

### Status Values

| Status | Meaning |
|--------|---------|
| `stable` | Production-ready, low false-positive rate |
| `test` | Mostly stable, may need environment tuning |
| `experimental` | May produce false positives, needs validation |
| `deprecated` | Replaced by another rule (linked via `related`) |
| `unsupported` | Cannot be used in current state |

### Level Values

| Level | Meaning | Expected Action |
|-------|---------|-----------------|
| `informational` | Event enrichment/tagging only | Automated tagging |
| `low` | Notable but rarely an incident | Log for correlation |
| `medium` | Relevant, review manually | Analyst queue |
| `high` | Should trigger internal alert | Prompt review |
| `critical` | Highly relevant, indicates incident | Immediate response |

### Tag Format

Lowercase, dot-namespaced. Primary namespaces:

- `attack.tXXXX` -- MITRE ATT&CK technique IDs
- `attack.tXXXX.XXX` -- Sub-technique IDs
- `attack.<tactic_name>` -- Tactic names (e.g., `attack.credential-access`)
- `cve.YYYY-NNNNN` -- CVE identifiers
- `car.YYYY-MM-NNN` -- MITRE CAR analytics

### Skeleton Rule

```yaml
title: Descriptive Title - Verb + Noun
id: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx  # uuidgen
related:
    - id: yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy
      type: derived
status: test
description: |
    One paragraph explaining what behavior is detected and why it matters.
references:
    - https://example.com/research
author: Your Name
date: 2026-03-14
modified: 2026-03-14
tags:
    - attack.tactic-name
    - attack.tXXXX.XXX
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        FieldName|modifier: value
    filter_main_fp_scenario:
        FieldName: known_good_value
    condition: selection and not 1 of filter_main_*
falsepositives:
    - Specific scenario, not "legitimate activity"
level: medium
```

---

## 3. Detection Logic Deep Dive

### Search Identifiers

Named blocks under `detection:` that define field-value matching. Two types:

**1. Maps (field-value pairs):**
```yaml
detection:
    selection:
        EventID: 4688
        CommandLine|contains: 'mimikatz'
```

**2. Lists (keyword matching across full log event):**
```yaml
detection:
    keywords:
        - 'mimikatz'
        - 'sekurlsa'
```

### Within a Single Identifier

- Multiple field-value pairs = implicit **AND** (all must match)
- Multiple values for a single field = implicit **OR** (any can match)
- List of maps = implicit **OR** between maps

```yaml
detection:
    selection:
        # AND: both conditions must be true
        ParentImage|endswith: '\cmd.exe'
        CommandLine|contains:            # OR: any value matches
            - 'whoami'
            - 'net user'
            - 'ipconfig'
```

### Condition Syntax

The `condition:` field combines search identifiers with logical operators.

| Operator | Meaning | Example |
|----------|---------|---------|
| `and` | Logical AND | `selection and filter` |
| `or` | Logical OR | `selection1 or selection2` |
| `not` | Negation | `selection and not filter` |
| `1 of <pattern>` | Any one identifier matching glob | `1 of selection_*` |
| `all of <pattern>` | All identifiers matching glob | `all of selection_*` |
| `1 of them` | Any search identifier (non-underscore prefixed) | `1 of them` |
| `all of them` | All search identifiers (discouraged) | `all of them` |
| `( )` | Grouping for precedence | `(sel1 or sel2) and not filter` |

**Operator Precedence** (lowest to highest): `or` < `and` < `not` < `x of` < `()`

### Common Condition Patterns

```yaml
# Simple match
condition: selection

# Match with exclusions
condition: selection and not filter

# Multiple selections, any matches, with grouped filters
condition: 1 of selection_* and not 1 of filter_main_* and not 1 of filter_optional_*

# All sub-selections must match
condition: all of selection_*

# Complex logic
condition: (selection1 or selection2) and not (filter1 or filter2)
```

---

## 4. Value Modifiers Reference

Applied via pipe syntax: `FieldName|modifier1|modifier2: value`

### String Matching Modifiers

| Modifier | Description | Example |
|----------|-------------|---------|
| `contains` | Substring match | `CommandLine\|contains: 'mimikatz'` |
| `startswith` | Prefix match | `Image\|startswith: 'C:\Windows\'` |
| `endswith` | Suffix match | `Image\|endswith: '\cmd.exe'` |
| `re` | Regular expression | `CommandLine\|re: 'invoke-[a-z]+command'` |
| `cidr` | CIDR network range | `DestinationIp\|cidr: '10.0.0.0/8'` |

### Encoding/Transformation Modifiers

| Modifier | Description |
|----------|-------------|
| `base64` | Match base64-encoded form of value |
| `base64offset` | Match base64 with all 3 possible offsets |
| `wide` | Match UTF-16LE encoded form |
| `utf16` | Match UTF-16 encoded form |
| `utf16le` | Match UTF-16 little-endian |
| `utf16be` | Match UTF-16 big-endian |
| `windash` | Match both `-` and `/` as flag prefixes (Windows CLI) |

### Logical Modifiers

| Modifier | Description |
|----------|-------------|
| `all` | All values must match (AND instead of default OR) |
| `exists` | Field existence check (value: `true` or `false`) |

### Comparison Modifiers

| Modifier | Description |
|----------|-------------|
| `gt` | Greater than |
| `gte` | Greater than or equal |
| `lt` | Less than |
| `lte` | Less than or equal |

### Modifier Chaining

Modifiers chain left-to-right. Common chains:

```yaml
# Contains AND all values must match
CommandLine|contains|all:
    - 'cmd.exe'
    - '/c'
    - '\\127.0.0.1\\'

# Ends with (implicit OR between values)
Image|endswith:
    - '\cmd.exe'
    - '\powershell.exe'

# Windows dash normalization with contains
CommandLine|contains|windash: '-encode'
# Matches: -encode, /encode

# Base64-encoded keyword detection
CommandLine|base64offset|contains: 'IEX'
```

### Wildcards

Within plain values (no modifier), `*` acts as wildcard:
```yaml
detection:
    selection:
        CommandLine: '*mimikatz*'   # equivalent to contains
        Image: 'C:\Windows\*'       # equivalent to startswith
```

---

## 5. Log Source Taxonomy

### Logsource Attributes

| Attribute | Description |
|-----------|-------------|
| `category` | Logical event group (product-agnostic). Examples: `process_creation`, `network_connection`, `dns_query`, `file_change`, `registry_set`, `ps_script` |
| `product` | Operating system or product. Examples: `windows`, `linux`, `macos`, `aws`, `azure`, `gcp` |
| `service` | Specific log channel. Examples: `security`, `system`, `sysmon`, `powershell`, `applocker`, `cloudtrail` |
| `definition` | Prerequisites (e.g., "Script Block Logging must be enabled") |

At least one of `category`, `product`, or `service` is required.

### Critical Windows Log Sources

| Category | Product | Service | Telemetry Source | Key Event IDs |
|----------|---------|---------|-----------------|---------------|
| `process_creation` | `windows` | -- | Sysmon EID 1, Security EID 4688 | Process execution |
| `image_load` | `windows` | -- | Sysmon EID 7 | DLL loading |
| `network_connection` | `windows` | -- | Sysmon EID 3 | TCP/UDP connections |
| `dns_query` | `windows` | -- | Sysmon EID 22 | DNS resolution |
| `file_change` | `windows` | -- | Sysmon EID 2,11,15,23,26 | File operations |
| `registry_set` | `windows` | -- | Sysmon EID 13 | Registry value set |
| `registry_add` | `windows` | -- | Sysmon EID 12 | Registry key creation |
| `registry_delete` | `windows` | -- | Sysmon EID 12 | Registry key deletion |
| `registry_event` | `windows` | -- | Sysmon EID 12,13,14 | All registry ops |
| `create_remote_thread` | `windows` | -- | Sysmon EID 8 | Remote thread injection |
| `process_access` | `windows` | -- | Sysmon EID 10 | Process handle ops |
| `pipe_created` | `windows` | -- | Sysmon EID 17,18 | Named pipe ops |
| `driver_load` | `windows` | -- | Sysmon EID 6 | Kernel driver load |
| `ps_script` | `windows` | -- | PowerShell Script Block Logging (EID 4104) | Script content |
| `ps_module` | `windows` | -- | PowerShell Module Logging | Cmdlet execution |
| -- | `windows` | `security` | Windows Security Log | 4624,4625,4648,4656,4661,4663,4688,4769,5145 |
| -- | `windows` | `system` | Windows System Log | 7045,7040 |
| -- | `windows` | `sysmon` | Sysmon operational log | 1-26 |
| `dns` | -- | -- | DNS server/resolver logs | DNS queries/responses |
| `firewall` | -- | -- | Firewall logs | Connection allow/deny |
| `webserver` | -- | -- | Web server access logs | HTTP requests |
| `proxy` | -- | -- | Web proxy logs | HTTP/HTTPS traffic |

---

## 6. Example Rules by Category

### 6.1 Credential Access

#### Rule 1: Mimikatz Command Line Detection

```yaml
title: HackTool - Mimikatz Execution
id: a642964e-bead-4bed-8910-1bb4d63e3b4d
status: test
description: Detection well-known mimikatz command line arguments
references:
    - https://www.slideshare.net/heirhabarov/hunting-for-credentials-dumping-in-windows-environment
    - https://tools.thehacker.recipes/mimikatz/modules
author: Teymur Kheirkhabarov, oscd.community, David ANDRE (additional keywords), Tim Shelton
date: 2019-10-22
modified: 2023-02-21
tags:
    - attack.credential-access
    - attack.t1003.001
    - attack.t1003.002
    - attack.t1003.004
    - attack.t1003.005
    - attack.t1003.006
logsource:
    category: process_creation
    product: windows
detection:
    selection_tools_name:
        CommandLine|contains:
            - 'DumpCreds'
            - 'mimikatz'
    selection_function_names:
        CommandLine|contains:
            - '::aadcookie'
            - '::detours'
            - '::memssp'
            - '::mflt'
            - '::ncroutemon'
            - '::ngcsign'
            - '::printnightmare'
            - '::skeleton'
            - '::preshutdown'
            - '::mstsc'
            - '::multirdp'
    selection_module_names:
        CommandLine|contains:
            - 'rpc::'
            - 'token::'
            - 'crypto::'
            - 'dpapi::'
            - 'sekurlsa::'
            - 'kerberos::'
            - 'lsadump::'
            - 'privilege::'
            - 'process::'
            - 'vault::'
    condition: 1 of selection_*
falsepositives:
    - Unlikely
level: high
```

**Key patterns:** Multiple selection groups with `1 of selection_*` condition. Covers tool names, function names, and module names independently. Maps to T1003 sub-techniques.

#### Rule 2: LSASS Process Clone (Credential Dump Bypass)

```yaml
title: Potential Credential Dumping Via LSASS Process Clone
id: c8da0dfd-4ed0-4b68-962d-13c9c884384e
status: test
description: Detects a suspicious LSASS process clone that could be a sign of credential dumping activity
references:
    - https://www.matteomalvica.com/blog/2019/12/02/win-defender-atp-cred-bypass/
    - https://twitter.com/Hexacorn/status/1420053502554951689
author: Florian Roth (Nextron Systems), Samir Bousseaden
date: 2021-11-27
modified: 2023-03-02
tags:
    - attack.credential-access
    - attack.t1003
    - attack.t1003.001
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        ParentImage|endswith: '\Windows\System32\lsass.exe'
        Image|endswith: '\Windows\System32\lsass.exe'
    condition: selection
falsepositives:
    - Unknown
level: critical
```

**Key pattern:** LSASS spawning itself is almost always malicious. Simple selection, critical severity. Zero legitimate FPs expected.

#### Rule 3: Dumpert Process Dumper

```yaml
title: HackTool - Dumpert Process Dumper Execution
id: 2704ab9e-afe2-4854-a3b1-0c0706d03578
status: test
description: Detects the use of Dumpert process dumper, which dumps lsass.exe process memory
references:
    - https://github.com/outflanknl/Dumpert
author: Florian Roth (Nextron Systems)
date: 2020-02-04
modified: 2025-01-22
tags:
    - attack.credential-access
    - attack.t1003.001
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        - Hashes|contains: 'MD5=09D278F9DE118EF09163C6140255C690'
        - CommandLine|contains: 'Dumpert.dll'
    condition: selection
falsepositives:
    - Very unlikely
level: critical
```

**Key pattern:** Hash-based and string-based detection combined with OR logic. Critical severity for direct LSASS dump tool.

#### Rule 4: LSASS Handle Access (Security Log)

```yaml
title: Password Dumper Activity on LSASS
id: aa1697b7-d611-4f9a-9cb2-5125b4ccfd5c
status: test
description: Detects process handle on LSASS process with certain access mask and object type SAM_DOMAIN
references:
    - https://twitter.com/jackcr/status/807385668833968128
author: sigma
date: 2017-02-12
modified: 2022-10-09
tags:
    - attack.credential-access
    - attack.t1003.001
logsource:
    product: windows
    service: security
detection:
    selection:
        EventID: 4656
        ProcessName|endswith: '\lsass.exe'
        AccessMask: '0x705'
        ObjectType: 'SAM_DOMAIN'
    condition: selection
falsepositives:
    - Unknown
level: high
```

**Key pattern:** Uses Windows Security log Event ID 4656 (handle requested). Specific access mask `0x705` combined with SAM_DOMAIN object type is a strong indicator.

#### Rule 5: Kerberoasting Detection

```yaml
title: Kerberoasting Activity - Initial Query
id: d04ae2b8-ad54-4de0-bd87-4bc1da66aa59
status: test
description: |
    Detects service ticket requests using RC4 encryption (0x17) which may indicate Kerberoasting.
    Further analysis needed: look for one host requesting multiple service tickets in short timeframe.
references:
    - https://www.trustedsec.com/blog/art_of_kerberoast/
    - https://adsecurity.org/?p=3513
author: '@kostastsale'
date: 2022-01-21
modified: 2025-10-19
tags:
    - attack.credential-access
    - attack.t1558.003
logsource:
    product: windows
    service: security
detection:
    selection:
        EventID: 4769
        Status: '0x0'
        TicketEncryptionType: '0x17'
    filter_main_krbtgt:
        ServiceName|endswith:
            - 'krbtgt'
            - '$'
    filter_main_machine_accounts:
        TargetUserName|contains: '$@'
    condition: selection and not 1 of filter_main_*
falsepositives:
    - Legacy applications
level: medium
```

**Key pattern:** Event ID 4769 (TGS request) with RC4 encryption (0x17) indicates Kerberoasting. Filters exclude machine accounts and krbtgt to reduce noise.

#### Rule 6: Suspicious Kerberos RC4 Ticket Encryption

```yaml
title: Suspicious Kerberos RC4 Ticket Encryption
id: 496a0e47-0a33-4dca-b009-9e6ca3591f39
status: test
description: Detects service ticket requests using RC4 encryption type
references:
    - https://adsecurity.org/?p=3458
author: Florian Roth (Nextron Systems)
date: 2017-02-06
modified: 2022-06-19
tags:
    - attack.credential-access
    - attack.t1558.003
logsource:
    product: windows
    service: security
detection:
    selection:
        EventID: 4769
        TicketOptions: '0x40810000'
        TicketEncryptionType: '0x17'
    reduction:
        ServiceName|endswith: '$'
    condition: selection and not reduction
falsepositives:
    - Service accounts used on legacy systems (e.g. NetApp)
    - Windows Domains with DFL 2003 and legacy systems
level: medium
```

#### Rule 7: AS-REP Roasting Detection

```yaml
title: Potential AS-REP Roasting via Kerberos TGT Requests
id: 3e2f1b2c-4d5e-11ee-be56-0242ac120002
status: experimental
description: |
    Detects suspicious Kerberos TGT requests with pre-authentication disabled
    (Pre-Authentication Type = 0) and RC4-HMAC encryption. Indicates AS-REP Roasting
    where attackers request AS-REP messages for accounts without pre-auth.
references:
    - https://medium.com/system-weakness/detecting-as-rep-roasting-attacks-b5b3965f9714
author: ANosir
date: 2025-05-22
modified: 2025-07-04
logsource:
    product: windows
    service: security
detection:
    selection:
        EventID: 4768
        TicketEncryptionType: '0x17'
        ServiceName: 'krbtgt'
        PreAuthType: 0
    condition: selection
falsepositives:
    - Legacy systems or applications that legitimately use RC4 encryption
    - Misconfigured accounts with pre-authentication disabled
level: medium
```

#### Rule 8: Impacket SecretDump

```yaml
title: Possible Impacket SecretDump Remote Activity
id: 252902e3-5830-4cf6-bf21-c22083dfd5cf
status: test
description: Detect AD credential dumping using impacket secretdump HKTL
references:
    - https://web.archive.org/web/20230329153811/https://blog.menasec.net/2019/02/threat-huting-10-impacketsecretdump.html
author: Samir Bousseaden, wagga
date: 2019-04-03
modified: 2022-08-11
tags:
    - attack.credential-access
    - attack.t1003.002
    - attack.t1003.004
    - attack.t1003.003
logsource:
    product: windows
    service: security
    definition: 'The advanced audit policy setting "Object Access > Audit Detailed File Share" must be configured for Success/Failure'
detection:
    selection:
        EventID: 5145
        ShareName: '\\*\ADMIN$'
        RelativeTargetName|contains|all:
            - 'SYSTEM32\'
            - '.tmp'
    condition: selection
falsepositives:
    - Unknown
level: high
```

---

### 6.2 Lateral Movement

#### Rule 9: Impacket Lateral Movement (wmiexec/smbexec/dcomexec/atexec)

```yaml
title: HackTool - Potential Impacket Lateral Movement Activity
id: 10c14723-61c7-4c75-92ca-9af245723ad2
status: stable
description: Detects wmiexec/dcomexec/atexec/smbexec from Impacket framework
references:
    - https://github.com/SecureAuthCorp/impacket/blob/master/examples/wmiexec.py
    - https://github.com/SecureAuthCorp/impacket/blob/master/examples/smbexec.py
author: Ecco, oscd.community, Jonhnathan Ribeiro, Tim Rauch
date: 2019-09-03
modified: 2023-02-21
tags:
    - attack.execution
    - attack.t1047
    - attack.lateral-movement
    - attack.t1021.003
logsource:
    category: process_creation
    product: windows
detection:
    selection_other:
        ParentImage|endswith:
            - '\wmiprvse.exe'
            - '\mmc.exe'
            - '\explorer.exe'
            - '\services.exe'
        CommandLine|contains|all:
            - 'cmd.exe'
            - '/Q'
            - '/c'
            - '\\\\127.0.0.1\\'
            - '&1'
    selection_atexec:
        ParentCommandLine|contains:
            - 'svchost.exe -k netsvcs'
            - 'taskeng.exe'
        CommandLine|contains|all:
            - 'cmd.exe'
            - '/C'
            - 'Windows\Temp\'
            - '&1'
    condition: 1 of selection_*
falsepositives:
    - Unknown
level: high
```

**Key pattern:** Detects Impacket's characteristic `cmd.exe /Q /c` with `\\127.0.0.1\` output redirection. The `contains|all` modifier requires ALL strings present.

#### Rule 10: Evil-WinRM Lateral Movement

```yaml
title: HackTool - WinRM Access Via Evil-WinRM
id: a197e378-d31b-41c0-9635-cfdf1c1bb423
status: test
description: Detects Evil-WinRM execution via Ruby with characteristic parameters
references:
    - https://github.com/Hackplayers/evil-winrm
author: frack113
date: 2022-01-07
modified: 2023-02-13
tags:
    - attack.lateral-movement
    - attack.t1021.006
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        Image|endswith: '\ruby.exe'
        CommandLine|contains|all:
            - '-i '
            - '-u '
            - '-p '
    condition: selection
falsepositives:
    - Unknown
level: medium
```

#### Rule 11: PowerShell Invoke-Command Remote Execution

```yaml
title: Execute Invoke-command on Remote Host
id: 7b836d7f-179c-4ba4-90a7-a7e60afb48e6
status: test
description: Detects Invoke-Command with -ComputerName for remote execution via WinRM
references:
    - https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1021.006/T1021.006.md
author: frack113
date: 2022-01-07
tags:
    - attack.lateral-movement
    - attack.t1021.006
logsource:
    product: windows
    category: ps_script
    definition: 'Requirements: Script Block Logging must be enabled'
detection:
    selection_cmdlet:
        ScriptBlockText|contains|all:
            - 'invoke-command '
            - ' -ComputerName '
    condition: selection_cmdlet
falsepositives:
    - Legitimate script
level: medium
```

#### Rule 12: WMI Process Creation

```yaml
title: New Process Created Via Wmic.EXE
id: 526be59f-a573-4eea-b5f7-f0973207634d
status: test
description: Detects new process creation using WMIC via "process call create"
references:
    - https://www.sans.org/blog/wmic-for-incident-response/
author: Michael Haag, Florian Roth (Nextron Systems), juju4, oscd.community
date: 2019-01-16
modified: 2023-02-14
tags:
    - attack.execution
    - attack.t1047
    - car.2016-03-002
logsource:
    category: process_creation
    product: windows
detection:
    selection_img:
        - Image|endswith: '\wmic.exe'
        - OriginalFileName: 'wmic.exe'
    selection_cli:
        CommandLine|contains|all:
            - 'process'
            - 'call'
            - 'create'
    condition: all of selection_*
falsepositives:
    - Unknown
level: medium
```

---

### 6.3 Defense Evasion

#### Rule 13: EDRSilencer Execution

```yaml
title: HackTool - EDRSilencer Execution
id: eb2d07d4-49cb-4523-801a-da002df36602
status: test
description: |
    Detects EDRSilencer, a tool that leverages Windows Filtering Platform (WFP) to block
    EDR agents from reporting security events to the server.
references:
    - https://github.com/netero1010/EDRSilencer
author: '@gott_cyber'
date: 2024-01-02
tags:
    - attack.defense-evasion
    - attack.t1562
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        - Image|endswith: '\EDRSilencer.exe'
        - OriginalFileName: 'EDRSilencer.exe'
        - Description|contains: 'EDRSilencer'
    condition: selection
falsepositives:
    - Unlikely
level: high
```

#### Rule 14: Certutil Base64 Encoding

```yaml
title: File Encoded To Base64 Via Certutil.EXE
id: e62a9f0c-ca1e-46b2-85d5-a6da77f86d1a
status: test
description: Detects certutil with "encode" flag for base64 encoding, abused for data exfiltration
references:
    - https://lolbas-project.github.io/lolbas/Binaries/Certutil/
author: Florian Roth (Nextron Systems), Nasreddine Bencherchali (Nextron Systems)
date: 2019-02-24
modified: 2024-03-05
tags:
    - attack.defense-evasion
    - attack.t1027
logsource:
    category: process_creation
    product: windows
detection:
    selection_img:
        - Image|endswith: '\certutil.exe'
        - OriginalFileName: 'CertUtil.exe'
    selection_cli:
        CommandLine|contains|windash: '-encode'
    condition: all of selection_*
falsepositives:
    - Legitimate usage of encode functionality
level: medium
```

**Key pattern:** Uses `windash` modifier to match both `-encode` and `/encode`.

#### Rule 15: DOSfuscation (Command Obfuscation)

```yaml
title: Potential Dosfuscation Activity
id: a77c1610-fc73-4019-8e29-0f51efc04a51
status: test
description: Detects possible payload obfuscation via the commandline
references:
    - https://www.fireeye.com/content/dam/fireeye-www/blog/pdfs/dosfuscation-report.pdf
author: frack113, Nasreddine Bencherchali (Nextron Systems)
date: 2022-02-15
modified: 2023-03-06
tags:
    - attack.execution
    - attack.t1059
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        CommandLine|contains:
            - '^^'
            - '^|^'
            - ',;,'
            - ';;;;'
            - ';; ;;'
            - '(,(,'
            - '%COMSPEC:~'
            - ' c^m^d'
            - '^c^m^d'
            - ' c^md'
            - ' cm^d'
            - '^cm^d'
            - ' s^et '
            - ' s^e^t '
            - ' se^t '
    condition: selection
falsepositives:
    - Unknown
level: medium
```

#### Rule 16: Filter Driver Unload (Anti-Sysmon)

```yaml
title: Filter Driver Unloaded Via Fltmc.EXE
id: 4931188c-178e-4ee7-a348-39e8a7a56821
status: test
description: Detect filter driver unloading activity via fltmc.exe
references:
    - https://www.darkoperator.com/blog/2018/10/5/operating-offensively-against-sysmon
    - https://www.cybereason.com/blog/threat-analysis-report-lockbit-2.0-all-paths-lead-to-ransom
author: Nasreddine Bencherchali (Nextron Systems)
date: 2023-02-13
modified: 2025-10-07
tags:
    - attack.defense-evasion
    - attack.t1070
    - attack.t1562
    - attack.t1562.002
logsource:
    product: windows
    category: process_creation
detection:
    selection_img:
        - Image|endswith: '\fltMC.exe'
        - OriginalFileName: 'fltMC.exe'
    selection_cli:
        CommandLine|contains: 'unload'
    filter_optional_avira:
        ParentImage|contains:
            - '\AppData\Local\Temp\'
            - ':\Windows\Temp\'
        ParentImage|endswith: '\endpoint-protection-installer-x64.tmp'
        CommandLine|endswith:
            - 'unload rtp_filesystem_filter'
            - 'unload rtp_filter'
    filter_optional_manageengine:
        ParentImage: 'C:\Program Files (x86)\ManageEngine\uems_agent\bin\dcfaservice64.exe'
        CommandLine|endswith: 'unload DFMFilter'
    condition: all of selection_* and not 1 of filter_optional_*
falsepositives:
    - Unknown
level: medium
```

---

### 6.4 Persistence

#### Rule 17: Registry Run Key Modification (Autostart)

```yaml
title: CurrentVersion Autorun Keys Modification
id: 20f0ee37-5942-4e45-b7d5-c5b5db9df5cd
status: test
description: Detects modification of autostart extensibility point (ASEP) in registry
references:
    - https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1547.001/T1547.001.md
    - https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns
author: Victor Sergeev, Daniil Yugoslavskiy, oscd.community, Tim Shelton, frack113 (split)
date: 2019-10-25
modified: 2025-10-22
tags:
    - attack.privilege-escalation
    - attack.persistence
    - attack.t1547.001
logsource:
    category: registry_set
    product: windows
detection:
    selection_current_version_base:
        TargetObject|contains: '\SOFTWARE\Microsoft\Windows\CurrentVersion'
    selection_current_version_keys:
        TargetObject|contains:
            - '\ShellServiceObjectDelayLoad'
            - '\Run\'
            - '\RunOnce\'
            - '\RunOnceEx\'
            - '\RunServices\'
            - '\RunServicesOnce\'
            - '\Policies\System\Shell'
            - '\Policies\Explorer\Run'
            - '\Group Policy\Scripts\Startup'
            - '\Group Policy\Scripts\Shutdown'
            - '\Group Policy\Scripts\Logon'
            - '\Group Policy\Scripts\Logoff'
            - '\Explorer\ShellServiceObjects'
            - '\Explorer\ShellIconOverlayIdentifiers'
            - '\Explorer\ShellExecuteHooks'
            - '\Explorer\SharedTaskScheduler'
            - '\Explorer\Browser Helper Objects'
            - '\Authentication\PLAP Providers'
            - '\Authentication\Credential Providers'
            - '\Authentication\Credential Provider Filters'
    filter_main_generic_all:
        - Details: '(Empty)'
        - TargetObject|endswith: '\NgcFirst\ConsecutiveSwitchCount'
        - Image|endswith:
              - '\AppData\Local\Microsoft\OneDrive\Update\OneDriveSetup.exe'
              - '\AppData\Roaming\Spotify\Spotify.exe'
              - '\AppData\Local\WebEx\WebexHost.exe'
        # ... (extensive filter list for legitimate software)
    filter_main_null:
        Details: null
    condition: all of selection_* and not 1 of filter_main_* and not 1 of filter_optional_*
falsepositives:
    - Legitimate software sets up autorun keys during installation
    - Legitimate administrator sets up autorun keys
level: medium
```

**Key pattern:** Comprehensive ASEP monitoring. Note the extensive filter lists -- this is the hallmark of production-grade registry persistence rules. Every legitimate software that writes Run keys must be filtered.

---

### 6.5 Privilege Escalation

#### Rule 18: CoercedPotato Execution

```yaml
title: HackTool - CoercedPotato Execution
id: e8d34729-86a4-4140-adfd-0a29c2106307
status: test
description: Detects the use of CoercedPotato, a tool for privilege escalation
references:
    - https://github.com/hackvens/CoercedPotato
    - https://blog.hackvens.fr/articles/CoercedPotato.html
author: Florian Roth (Nextron Systems)
date: 2023-10-11
modified: 2024-11-23
tags:
    - attack.defense-evasion
    - attack.privilege-escalation
    - attack.t1055
logsource:
    category: process_creation
    product: windows
detection:
    selection_loader_img:
        Image|endswith: '\CoercedPotato.exe'
    selection_params:
        CommandLine|contains: ' --exploitId '
    selection_loader_imphash:
        Hashes|contains:
            - 'IMPHASH=A75D7669DB6B2E107A44C4057FF7F7D6'
            - 'IMPHASH=F91624350E2C678C5DCBE5E1F24E22C9'
            - 'IMPHASH=14C81850A079A87E83D50CA41C709A15'
    condition: 1 of selection_*
falsepositives:
    - Unknown
level: high
```

**Key pattern:** Triple detection approach -- image name, command-line parameter, and import hash. Any one match triggers the rule.

---

### 6.6 Discovery / Reconnaissance

#### Rule 19: AD Privileged Users/Groups Reconnaissance

```yaml
title: AD Privileged Users or Groups Reconnaissance
id: 35ba1d85-724d-42a3-889f-2e2362bcaf23
status: test
description: Detect priv users or groups recon based on 4661 eventid and known privileged SIDs
references:
    - https://web.archive.org/web/20230329163438/https://blog.menasec.net/2019/02/threat-hunting-5-detecting-enumeration.html
author: Samir Bousseaden
date: 2019-04-03
modified: 2022-07-13
tags:
    - attack.discovery
    - attack.t1087.002
logsource:
    product: windows
    service: security
    definition: 'Requirements: enable Object Access SAM on your Domain Controllers'
detection:
    selection:
        EventID: 4661
        ObjectType:
            - 'SAM_USER'
            - 'SAM_GROUP'
    selection_object:
        - ObjectName|endswith:
              - '-512'    # Domain Admins
              - '-502'    # KRBTGT
              - '-500'    # Administrator
              - '-505'    # Server Operators(?)
              - '-519'    # Enterprise Admins
              - '-520'    # Group Policy Creator Owners
              - '-544'    # BUILTIN\Administrators
              - '-551'    # Backup Operators
              - '-555'    # Remote Desktop Users
        - ObjectName|contains: 'admin'
    filter:
        SubjectUserName|endswith: '$'
    condition: selection and selection_object and not filter
falsepositives:
    - If source account name is not an admin then its super suspicious
level: high
```

#### Rule 20: Suspicious DNS Query for IP Lookup Services

```yaml
title: Suspicious DNS Query for IP Lookup Service APIs
id: ec82e2a5-81ea-4211-a1f8-37a0286df2c2
status: test
description: Detects DNS queries for IP lookup services originating from a non-browser process
references:
    - https://www.binarydefense.com/analysis-of-hancitor-when-boring-begets-beacon
author: Brandon George (blog post), Thomas Patzke
date: 2021-07-08
modified: 2024-03-22
tags:
    - attack.reconnaissance
    - attack.t1590
logsource:
    product: windows
    category: dns_query
detection:
    selection:
        - QueryName:
              - 'www.ip.cn'
              - 'l2.io'
        - QueryName|contains:
              - 'api.ipify.org'
              - 'checkip.amazonaws.com'
              - 'checkip.dyndns.org'
              - 'icanhazip.com'
              - 'ifconfig.me'
              - 'ip-api.com'
              - 'ipinfo.io'
              - 'ipecho.net'
              - 'wtfismyip.com'
              # ... 30+ additional services
    filter_optional_brave:
        Image|endswith: '\brave.exe'
    filter_optional_chrome:
        Image:
            - 'C:\Program Files\Google\Chrome\Application\chrome.exe'
            - 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
    # ... additional browser filters
    condition: selection and not 1 of filter_optional_*
falsepositives:
    - Legitimate usage of IP lookup services
level: medium
```

---

### 6.7 Command and Control

#### Rule 21: DNS TXT Answer with Execution Strings (C2 via DNS)

```yaml
title: DNS TXT Answer with Possible Execution Strings
id: 8ae51330-899c-4641-8125-e39f2e07da72
status: test
description: Detects strings used in command execution in DNS TXT Answer
references:
    - https://twitter.com/stvemillertime/status/1024707932447854592
    - https://github.com/samratashok/nishang/blob/master/Backdoors/DNS_TXT_Pwnage.ps1
author: Markus Neis
date: 2018-08-08
modified: 2021-11-27
tags:
    - attack.command-and-control
    - attack.t1071.004
logsource:
    category: dns
detection:
    selection:
        record_type: 'TXT'
        answer|contains:
            - 'IEX'
            - 'Invoke-Expression'
            - 'cmd.exe'
    condition: selection
falsepositives:
    - Unknown
level: high
```

---

### 6.8 Execution

#### Rule 22: Msiexec Remote Package Installation

```yaml
title: Suspicious Msiexec Quiet Install From Remote Location
id: 8150732a-0c9d-4a99-82b9-9efb9b90c40c
status: test
description: Detects msiexec.exe installing packages hosted remotely and quietly
references:
    - https://www.microsoft.com/en-us/security/blog/2022/10/27/raspberry-robin-worm-part-of-larger-ecosystem-facilitating-pre-ransomware-activity/
author: Nasreddine Bencherchali (Nextron Systems)
date: 2022-10-28
modified: 2025-10-07
tags:
    - attack.defense-evasion
    - attack.t1218.007
logsource:
    category: process_creation
    product: windows
detection:
    selection_img:
        - Image|endswith: '\msiexec.exe'
        - OriginalFileName: 'msiexec.exe'
    selection_cli:
        CommandLine|contains|windash:
            - '-i'
            - '-package'
            - '-a'
            - '-j'
    selection_quiet:
        CommandLine|contains|windash: '-q'
    selection_remote:
        CommandLine|contains:
            - 'http'
            - '\\\\'
    condition: all of selection_* and not 1 of filter_optional_*
falsepositives:
    - Unknown
level: medium
```

---

### 6.9 DLL Sideloading / Persistence via Image Load

#### Rule 23: DBGHELP.DLL Sideloading

```yaml
title: Potential DLL Sideloading Of DBGHELP.DLL
id: 6414b5cd-b19d-447e-bb5e-9f03940b5784
status: test
description: Detects potential DLL sideloading of "dbghelp.dll"
references:
    - https://hijacklibs.net/
author: Nasreddine Bencherchali (Nextron Systems), Wietze Beukema
date: 2022-10-25
modified: 2025-10-07
tags:
    - attack.defense-evasion
    - attack.persistence
    - attack.privilege-escalation
    - attack.t1574.001
logsource:
    category: image_load
    product: windows
detection:
    selection:
        ImageLoaded|endswith: '\dbghelp.dll'
    filter_main_generic:
        ImageLoaded|startswith:
            - 'C:\Program Files (x86)\'
            - 'C:\Program Files\'
            - 'C:\Windows\SoftwareDistribution\'
            - 'C:\Windows\System32\'
            - 'C:\Windows\SystemTemp\'
            - 'C:\Windows\SysWOW64\'
            - 'C:\Windows\WinSxS\'
    # ... additional vendor-specific filters
    condition: selection and not 1 of filter_main_* and not 1 of filter_optional_*
falsepositives:
    - Legitimate applications loading their own versions of the DLL
level: medium
```

**Key pattern:** Allow-list approach: detect DLL loaded from anywhere except known-legitimate paths. Effective for sideloading detection.

---

## 7. Rule Conversion and Tooling

### 7.1 sigma-cli (Primary CLI Tool)

```bash
# Install
pip install sigma-cli

# List available backends
sigma plugin list --plugin-type backend

# Install a backend
sigma plugin install splunk
sigma plugin install elasticsearch
sigma plugin install microsoft365defender

# Convert single rule to Splunk SPL
sigma convert -t splunk -p splunk_cim rules/windows/process_creation/proc_creation_win_hktl_mimikatz_command_line.yml

# Convert to Elasticsearch with ECS pipeline
sigma convert -t elasticsearch -p ecs_windows rules/windows/process_creation/proc_creation_win_hktl_mimikatz_command_line.yml

# Convert to Microsoft Sentinel KQL
sigma convert -t microsoft365defender rules/windows/process_creation/proc_creation_win_hktl_mimikatz_command_line.yml

# Convert entire directory
sigma convert -t splunk -p splunk_cim rules/windows/process_creation/

# Output to file
sigma convert -t splunk -p splunk_cim -o output.txt rules/windows/

# Check rule validity
sigma check rules/windows/process_creation/proc_creation_win_hktl_mimikatz_command_line.yml
```

### 7.2 pySigma (Python SDK)

```bash
pip install pysigma          # Core library
pip install pysigma-backend-splunk
pip install pysigma-backend-elasticsearch
pip install pysigma-pipeline-windows
pip install pysigma-pipeline-sysmon
```

```python
from sigma.rule import SigmaRule
from sigma.backends.splunk import SplunkBackend
from sigma.pipelines.splunk import splunk_cim_data_model
from sigma.collection import SigmaCollection
from pathlib import Path

# Parse a single rule
rule = SigmaRule.from_yaml(Path("rule.yml").read_text())

# Convert with backend + pipeline
backend = SplunkBackend(processing_pipeline=splunk_cim_data_model())
output = backend.convert_rule(rule)
print(output[0])  # SPL query string

# Batch convert a directory
collection = SigmaCollection.load_ruleset(["rules/windows/process_creation/"])
for query in backend.convert(collection):
    print(query)
```

### 7.3 sigconverter.io (Web GUI)

Browser-based converter at https://sigconverter.io/. Paste YAML, select target backend. Supports all pySigma backends. Useful for ad-hoc conversions without CLI setup.

### 7.4 Uncoder.io (SOC Prime)

Web-based converter at https://uncoder.io/. Supports Sigma-to-SIEM conversion plus Roota format. Commercial product from SOC Prime with broader format support than open-source tools.

### 7.5 Available Backends

| Backend | Package | Target Query Language |
|---------|---------|----------------------|
| Splunk | `pysigma-backend-splunk` | SPL |
| Elasticsearch | `pysigma-backend-elasticsearch` | Lucene, DSL, EQL |
| OpenSearch | `pysigma-backend-opensearch` | Lucene, DSL |
| Microsoft Sentinel | `pysigma-backend-microsoft365defender` | KQL |
| CrowdStrike LogScale | `pysigma-backend-crowdstrike` | LogScale QL |
| Grafana Loki | `pysigma-backend-loki` | LogQL |
| QRadar | `pysigma-backend-qradar` | AQL |
| NetWitness | `pysigma-backend-netwitness` | NW QL |
| Panther | `pysigma-backend-panther` | Python detection |

### 7.6 Processing Pipelines

Pipelines transform rules to match your data model before backend conversion:

| Pipeline | Package | Purpose |
|----------|---------|---------|
| Windows | `pysigma-pipeline-windows` | Windows audit log field mapping |
| Sysmon | `pysigma-pipeline-sysmon` | Sysmon field name mapping |
| Splunk CIM | `pysigma-pipeline-splunk` | CIM data model compliance |
| ECS | `pysigma-pipeline-elasticsearch` | Elastic Common Schema mapping |

---

## 8. Detection Coverage Matrix

### MITRE ATT&CK Coverage by Sigma Rule Category

| Tactic | Technique | Sigma Rule Category | Log Source | Key Event IDs |
|--------|-----------|-------------------|------------|---------------|
| **Initial Access** | T1190 Exploit Public App | `network/` | WAF, proxy, IDS | -- |
| **Execution** | T1059.001 PowerShell | `powershell/` | PS ScriptBlock | 4104 |
| **Execution** | T1059.003 Windows CMD | `process_creation/` | Sysmon/Security | 1, 4688 |
| **Execution** | T1047 WMI | `process_creation/` | Sysmon | 1 |
| **Persistence** | T1547.001 Registry Run Keys | `registry/registry_set/` | Sysmon | 13 |
| **Persistence** | T1053.005 Scheduled Task | `builtin/security/` | Security | 4698, 4702 |
| **Persistence** | T1574.001 DLL Sideload | `image_load/` | Sysmon | 7 |
| **Persistence** | T1546.003 WMI Event Sub | `wmi_event/` | Sysmon | 19, 20, 21 |
| **Priv Escalation** | T1055 Process Injection | `create_remote_thread/` | Sysmon | 8 |
| **Priv Escalation** | T1134 Access Token Manip | `builtin/security/` | Security | 4672, 4624 |
| **Defense Evasion** | T1027 Obfuscated Files | `process_creation/` | Sysmon | 1 |
| **Defense Evasion** | T1562 Impair Defenses | `process_creation/` | Sysmon | 1 |
| **Defense Evasion** | T1218 System Binary Proxy | `process_creation/` | Sysmon | 1 |
| **Defense Evasion** | T1070 Indicator Removal | `process_creation/`, `file/` | Sysmon | 1, 23 |
| **Credential Access** | T1003.001 LSASS Memory | `process_access/`, `process_creation/` | Sysmon, Security | 10, 1, 4656 |
| **Credential Access** | T1003.002 SAM | `builtin/security/` | Security | 5145 |
| **Credential Access** | T1003.003 NTDS | `builtin/security/` | Security | 5145 |
| **Credential Access** | T1558.003 Kerberoasting | `builtin/security/` | Security | 4769 |
| **Credential Access** | T1558.004 AS-REP Roast | `builtin/security/` | Security | 4768 |
| **Discovery** | T1087.002 Domain Account | `builtin/security/` | Security | 4661 |
| **Discovery** | T1590 Gather Victim Info | `dns_query/` | Sysmon | 22 |
| **Lateral Movement** | T1021.003 DCOM | `process_creation/` | Sysmon | 1 |
| **Lateral Movement** | T1021.006 WinRM | `process_creation/`, `powershell/` | Sysmon, PS | 1, 4104 |
| **Lateral Movement** | T1047 WMI (remote) | `process_creation/` | Sysmon | 1 |
| **Collection** | T1560 Archive Data | `process_creation/` | Sysmon | 1 |
| **C2** | T1071.004 DNS Protocol | `dns/`, `dns_query/` | DNS, Sysmon | 22 |
| **C2** | T1071.001 Web Protocols | `network_connection/`, `proxy/` | Sysmon, Proxy | 3 |
| **Exfiltration** | T1048 Exfil Over Alt Proto | `network_connection/` | Sysmon | 3 |

### Telemetry Requirements Matrix

| Data Source | Minimum Config | Rules Enabled | Priority |
|-------------|---------------|---------------|----------|
| **Sysmon** (all EIDs) | Full config (e.g., SwiftOnSecurity) | ~2000+ rules | CRITICAL |
| **Windows Security Log** | Advanced Audit Policy enabled | ~500+ rules | CRITICAL |
| **PowerShell Script Block Logging** | GPO: Turn on Script Block Logging | ~200+ rules | HIGH |
| **PowerShell Module Logging** | GPO: Turn on Module Logging | ~50+ rules | HIGH |
| **Windows System Log** | Default enabled | ~100+ rules | MEDIUM |
| **DNS Query Logging** | Sysmon EID 22 or DNS Debug | ~50+ rules | MEDIUM |
| **Firewall Logs** | Windows Firewall logging or NGFW | ~30+ rules | MEDIUM |
| **Proxy/Web Logs** | Forward proxy with SSL inspection | ~20+ rules | MEDIUM |

### Detection Gap Analysis Template

```
| ATT&CK Technique | Have Rule? | Have Telemetry? | Gap Type | Remediation |
|-------------------|------------|-----------------|----------|-------------|
| T1003.001 LSASS   | YES        | YES (Sysmon 10) | None     | --          |
| T1558.003 Kerb     | YES        | PARTIAL (4769)  | Tuning   | Set threshold |
| T1055.012 Hollowing| YES        | NO (need Sysmon)| Telemetry| Deploy Sysmon |
| T1071.001 Web C2   | NO         | YES (proxy)     | Rule     | Write rule  |
```

---

## 9. Companion Tools

### 9.1 Hayabusa

**What:** Rust-based Windows event log forensics timeline generator and threat hunter.

**Key capabilities:**
- Processes `.evtx` files directly -- no SIEM required
- Supports Sigma rules natively (converts internally)
- 170+ built-in Hayabusa detection rules
- Multi-threaded, ~5x speed improvement over single-threaded alternatives
- Supports Sigma v2 correlation rules (unique among open-source tools)
- Extended modifiers: `|equalsfield`, `|endswithfield`
- Output: CSV, JSON, JSONL timelines for Timeline Explorer, Timesketch

**Usage:**
```bash
# Scan event logs with Sigma + Hayabusa rules
hayabusa csv-timeline -d /path/to/evtx/ -o timeline.csv

# Hunt with specific rule directory
hayabusa csv-timeline -d /path/to/evtx/ -r sigma-rules/ -o results.csv

# JSON output for Timesketch
hayabusa json-timeline -d /path/to/evtx/ -o timeline.jsonl

# Integration with Velociraptor for enterprise-wide hunting
# Deploy as Velociraptor artifact for remote endpoint scanning
```

### 9.2 Chainsaw

**What:** Rust-based rapid forensic analysis tool for Windows event logs, MFT, registry hives, SRUM databases.

**Key capabilities:**
- Sigma rule execution against `.evtx` files
- Custom Chainsaw detection rules (simpler format)
- String and regex search across logs
- Shimcache/Amcache timeline generation
- SRUM database analysis
- Multi-format output: ASCII table, CSV, JSON

**Usage:**
```bash
# Hunt with Sigma rules
chainsaw hunt /path/to/evtx/ -s sigma/rules/ --mapping mappings/sigma-event-logs-all.yml

# Search for specific string
chainsaw search mimikatz -i /path/to/evtx/

# Search with regex
chainsaw search -e 'invoke-[a-z]+' -i /path/to/evtx/

# Dump event log contents
chainsaw dump /path/to/evtx/ --json

# Timeline from Shimcache
chainsaw analyse shimcache /path/to/SYSTEM --amcache /path/to/Amcache.hve
```

**Key event coverage:**
- Sysmon Process Creation (EID 1)
- Network Connections (EID 3)
- PowerShell Script Blocks (EID 4104)
- Process Creation (EID 4688)
- Service Installation (EID 7045)

### 9.3 Tool Comparison

| Feature | sigma-cli | Hayabusa | Chainsaw |
|---------|-----------|----------|----------|
| Purpose | Rule conversion | Log analysis + hunting | Log analysis + hunting |
| Input | Sigma YAML | .evtx files | .evtx, MFT, registry, SRUM |
| Output | SIEM queries | Timeline (CSV/JSON) | Table/CSV/JSON |
| Sigma Support | Full (all backends) | Full + extensions | Full (with mapping) |
| Custom Rules | No | Yes (Hayabusa format) | Yes (Chainsaw format) |
| Correlation | Via pySigma | Yes (Sigma v2) | No |
| Performance | N/A (converter) | Multi-threaded, fast | Multi-threaded, fast |
| Best For | SIEM integration | Forensics timeline | Quick triage |

---

## 10. Operational Guidance

### Writing Effective Rules

1. **Start with the TTP, not the tool.** A Mimikatz-specific rule catches Mimikatz. A rule for `sekurlsa::logonpasswords` behavior catches any tool using the same API calls.

2. **Use `OriginalFileName` alongside `Image`.** Attackers rename binaries. `OriginalFileName` is embedded in the PE and harder to fake:
   ```yaml
   selection_img:
       - Image|endswith: '\certutil.exe'
       - OriginalFileName: 'CertUtil.exe'
   ```

3. **Separate selections from filters.** Use naming conventions:
   - `selection_*` -- what you want to detect
   - `filter_main_*` -- mandatory exclusions (always applied)
   - `filter_optional_*` -- environment-specific exclusions

4. **Be specific in `falsepositives`.** "Legitimate activity" is useless. "Microsoft SCCM client updating software distribution point" is actionable.

5. **Tag with ATT&CK sub-techniques.** `attack.t1003.001` (LSASS Memory) is more useful than `attack.t1003` (OS Credential Dumping).

6. **Include `definition` in logsource** when special configuration is required:
   ```yaml
   logsource:
       product: windows
       service: security
       definition: 'Requires: Object Access > Audit Detailed File Share enabled'
   ```

### Rule Validation Workflow

```bash
# 1. Validate YAML syntax and schema
sigma check rule.yml

# 2. Convert to target backend to verify it compiles
sigma convert -t splunk -p splunk_cim rule.yml

# 3. Test against known-good logs (Hayabusa)
hayabusa csv-timeline -d test-evtx/ -r ./rule.yml -o test-results.csv

# 4. Test against known-bad logs (Chainsaw)
chainsaw hunt attack-evtx/ -s ./rule.yml --mapping mappings/sigma-event-logs-all.yml

# 5. Run in SIEM with informational level first, tune filters, then promote
```

### Rule Naming Convention (SigmaHQ Standard)

```
<category>_<product>_<description>.yml

Examples:
proc_creation_win_hktl_mimikatz_command_line.yml
registry_set_asep_reg_keys_modification_currentversion.yml
win_security_kerberoasting_activity.yml
net_dns_susp_txt_exec_strings.yml
posh_ps_invoke_command_remote.yml
```

### Priority Detection Stack

Deploy rules in this order for maximum impact with minimum effort:

| Priority | Category | Why |
|----------|----------|-----|
| P0 | Credential dumping (LSASS, SAM, NTDS) | Immediate domain compromise risk |
| P0 | Known attack tools (Mimikatz, Impacket, Cobalt Strike) | Direct threat actor activity |
| P1 | Registry persistence (Run keys, services) | Establishes persistence |
| P1 | PowerShell suspicious keywords | Primary living-off-the-land vector |
| P1 | Kerberos attacks (Kerberoasting, AS-REP, Golden Ticket) | AD compromise chain |
| P2 | Defense evasion (EDR tampering, log clearing) | Indicates active adversary |
| P2 | Lateral movement patterns (WMI, WinRM, PsExec) | Spread indicators |
| P2 | DLL sideloading / process injection | Advanced persistence/evasion |
| P3 | DNS-based C2 / beaconing | Long-term access indicators |
| P3 | Reconnaissance / discovery | Early kill chain activity |
| P3 | Data staging / exfiltration | Late kill chain activity |

---

## Appendix: Quick Reference Card

### Generate a UUID for a New Rule
```bash
uuidgen    # Linux/macOS
python -c "import uuid; print(uuid.uuid4())"
```

### Condition Cheat Sheet
```
selection                                    # Simple match
selection and not filter                     # Match with exclusion
1 of selection_*                             # Any selection_ group matches
all of selection_*                           # All selection_ groups match
all of selection_* and not 1 of filter_*     # All selections, no filters
(sel1 or sel2) and not (fp1 or fp2)          # Grouped logic
```

### Modifier Cheat Sheet
```
Field|contains: 'val'                # Substring
Field|endswith: '\cmd.exe'           # Suffix
Field|startswith: 'C:\Windows'       # Prefix
Field|contains|all:                  # All substrings must match
    - 'cmd.exe'
    - '/c'
Field|contains|windash: '-encode'    # Matches -encode and /encode
Field|re: 'invoke-[a-z]+'           # Regex
Field|base64offset|contains: 'IEX'  # Base64 encoded
Field|endswith:                      # Any value matches (OR)
    - '\cmd.exe'
    - '\powershell.exe'
Field|cidr: '10.0.0.0/8'            # CIDR range
```

### Conversion Quick Reference
```bash
# Splunk
sigma convert -t splunk -p splunk_cim rule.yml

# Elasticsearch (ECS)
sigma convert -t elasticsearch -p ecs_windows rule.yml

# Microsoft Sentinel
sigma convert -t microsoft365defender rule.yml

# Batch convert directory
sigma convert -t splunk -p splunk_cim rules/windows/process_creation/

# Validate rule
sigma check rule.yml
```
