<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Curated Security Resources - Deep Knowledge Reference

---

## 1. Security Tool Catalog

Master catalog of security software, libraries, and resources. Key tool categories:

### Network Security Stack
- **Scanning/Pentest**: OpenVAS, Nmap, Metasploit, Burp Suite
- **IDS/IPS**: Snort, Suricata, OSSEC, Zeek (formerly Bro)
- **Honeypots**: Kippo, Dionaea, Conpot (ICS), HoneyDrive
- **Full Packet Capture**: Arkime (Moloch), netsniff-ng, Stenographer
- **SIEM**: AlienVault OSSIM, Prelude SIEM, HELK (ELK-based)
- **VPN**: WireGuard, OpenVPN, Algo, Streisand
- **Firewalls**: pfSense, OPNsense, IPFire

### Endpoint Security
- **AV/Anti-Malware**: ClamAV, YARA
- **Content Disarm & Reconstruct (CDR)**: DocBleach
- **Configuration Management**: Chef InSpec, OpenSCAP, Lynis
- **Forensics**: Volatility, Autopsy, GRR Rapid Response, TheHive

### Threat Intelligence
- MISP, OpenCTI, STIX/TAXII frameworks
- Abuse.ch, PhishTank, AlienVault OTX

### Docker Security Images
- Kali Linux, OWASP ZAP, Security Onion containers
- Vulnerable-by-design: DVWA, OWASP Juice Shop, WebGoat

---

## 2. Security Hardening Reference

Comprehensive hardening reference organized by platform. Critical resources:

### Hardening Guide Collections (Authoritative Sources)
- **CIS Benchmarks** - Industry standard, registration required
- **ANSSI Best Practices** - French CERT, high quality
- **NSA Cybersecurity Advisories** - Free, excellent depth
- **DISA STIGs** - US DoD mandatory baselines
- **OpenSCAP** - Automated compliance scanning

### Linux Hardening Essentials
- The Practical Linux Hardening Guide - Step-by-step for CentOS/RHEL 7
- How To Secure A Linux Server - Single server guide
- Best practice auditd rules - PCI DSS, NISPOM compliant
- SUDO_KILLER - Sudo misconfiguration finder

### Windows Hardening
- Microsoft Security Baselines + Security Compliance Toolkit
- BSI/ERNW Windows 10 LTSC 2019 hardening guide
- NSA AppLocker, BitLocker, Event Forwarding guidance
- PingCastle - Active Directory security assessment
- ANSSI CERT-FR AD Security Checklist (2022)

### SSH Hardening (Critical)
- NIST IR 7966, ANSSI OpenSSH guide
- bettercrypto.org - Applied crypto hardening reference
- ssh-audit tool for configuration verification

### TLS/SSL Configuration
- **Mozilla SSL Configuration Generator** (ssl-config.mozilla.org) - THE reference
- Modern: TLS 1.3 only, AES-128-GCM + AES-256-GCM + ChaCha20-Poly1305
- Intermediate: TLS 1.2+1.3, adds ECDHE/DHE variants
- testssl.sh, SSLyze, CryptoLyzer for verification
- HSTS minimum 63,072,000 seconds, 90-day cert lifespans

### Container/K8s Hardening
- NIST SP 800-190 (Container Security Guide)
- Docker Bench for Security
- Kubernetes Security Checklist, RBAC Good Practices
- NSA/CISA Kubernetes Hardening Guidance

### Active Directory Hardening
- Microsoft Best Practices for Securing AD
- ANSSI CERT-FR AD Security Checklist
- ASD (Australian) - Detecting and Mitigating AD Compromises (2024)
- Admin-Free AD implementation guides

### Hardware/BIOS/UEFI Security
- CHIPSEC framework - platform security assessment
- NSA UEFI Lockdown and Defensive Practices guides
- ANSSI hardware security requirements for x86

### Automation Tools
- **DevSec Hardening Framework** (dev-sec.io) - Chef/Ansible/Puppet
- Lynis - Linux audit script
- OpenSCAP + SCAP Workbench

---

## 3. Defensive Security Tools

Defensive tools organized by operational function:

### SOAR (Security Orchestration, Automation, Response)
- **Shuffle** - Graphical workflow automation builder
- TheHive + Cortex integration

### Cloud Platform Security
- **Falco** - Container runtime behavioral monitoring via Linux kernel audit
- **Prowler** - AWS security assessment
- **Scout Suite** - Multi-cloud security auditing
- **gVisor** - Application kernel isolation for containers
- **Kata Containers** - Hardware-virtualized container isolation
- **PMapper** - AWS IAM risk evaluation

### Kubernetes Security Stack
- Kyverno (policy engine), Polaris (best practice validation)
- Sealed Secrets, kube-forensics, kube-hunter
- KubeSec (manifest static analysis)

### DevSecOps Pipeline
- **SAST**: CodeQL, SonarQube, Checkov, tfsec, terrascan
- **Container Scanning**: Clair, Trivy, Snyk
- **Secret Management**: SOPS, Vault, git-crypt, BlackBox
- **Supply Chain**: in-toto, Notary, Grafeas
- **Dependency Confusion**: snync, Combobulator

### Honeypots & Tarpits
- **CanaryTokens** - Self-hostable honeytoken generator
- **Endlessh** - SSH tarpit (slow banner)
- **Manuka** - OSINT honeypot for recon detection

### Host-Based Defense
- Fail2ban, OSSEC, rkhunter, chkrootkit
- USB Keystroke Injection Protection (Google)
- Shufflecake - Plausible deniability filesystems
- Sandboxes: Firejail, Bubblewrap, Dangerzone

### Network Security Monitoring
- **Zeek** - Network analysis framework (formerly Bro)
- **Suricata** - IDS/IPS with deep packet inspection
- **RITA** - Beacon detection, DNS tunneling detection from Zeek logs
- **Arkime** - Full packet capture indexing
- **Maltrail** - Malicious traffic detection

### Threat Hunting
- **HELK** - ELK + Kafka + Jupyter hunting stack
- **GRR Rapid Response** - Remote live forensics
- DeepBlueCLI - Windows Event Log hunting
- Atomic Red Team - Adversary emulation tests
- Caldera (MITRE) - Automated adversary emulation

### Phishing Defense
- Gophish, King Phisher - Phishing simulation
- CertSpotter - Certificate transparency monitoring
- mailspoof - SPF/DMARC issue scanner

### Adversary Emulation
- **Caldera** (MITRE) - Scalable adversary emulation
- **Infection Monkey** - Breach and attack simulation
- **Stratus Red Team** - Cloud attack emulation
- APTSimulator, DumpsterFire, Metta

---

## 4. Penetration Testing Tools

Penetration testing tools and resources:

### Core Frameworks
- **Metasploit** - Industry standard exploitation framework
- **Pupy** - Cross-platform RAT (Windows/Linux/macOS/Android)
- **Ronin** - Ruby security research toolkit
- **Faraday** - Collaborative pentest environment

### AV Evasion
- Veil, Shellter, AVET, CarbonCopy (cert spoofing)
- Amber - Reflective PE packer to position-independent shellcode
- UniByAv - XOR brute-forcable shellcode obfuscator

### Exfiltration Techniques
- **dnscat2** - Encrypted C2 over DNS
- **Iodine** - IPv4 tunneling through DNS
- **DET** - Multi-channel data exfiltration
- **QueenSono** - ICMP-based exfiltration
- **pwnat** - Firewall/NAT hole punching
- **TrevorC2** - C2 masking via browsable website

### Network Attack Tools
- **CrackMapExec** - Network pentesting Swiss army knife
- **impacket** - Python classes for network protocols
- **THC Hydra** - Online password cracker (HTTP, SMB, FTP, LDAP, etc.)
- **BetterCAP** - Modular MITM framework
- **Responder** - LLMNR/NBT-NS/MDNS poisoner
- **PivotSuite** - Network pivoting toolkit

### Wireless Tools
- Aircrack-ng, Kismet, Wifite, pwnagotchi
- Fluxion (social engineering WPA attacks)
- KRACK detector and attack scripts

### Exploit Development
- **Pwntools** - CTF/exploit development framework
- **peda** - Python GDB exploit development assistance
- **H26Forge** - Video file format fuzzing

### Cloud Attack Tools
- CloudHunter, Cloudsplaining, GCPBucketBrute
- Endgame - AWS backdooring tool
- CCAT - Container environment testing

### Privilege Escalation
- Linux Exploit Suggester, checksec.sh
- Password spraying tools

### Physical Security
- See physical security section below

### Essential Books
- RTFM (Red Team Field Manual), BTFM (Blue Team Field Manual)
- Black Hat Python, The Hacker Playbook
- Violent Python, The Art of Exploitation
- Unauthorised Access (physical pentest)

---

## 5. OSINT & Hacker Search Engines

Search engines categorized by intelligence function:

### Server/Infrastructure Discovery
- **Shodan** (shodan.io) - Internet-connected device search
- **Censys** (censys.io) - Internet asset discovery
- **ZoomEye** (zoomeye.org) - Cyberspace search engine
- **FOFA** (fofa.info) - Network asset search
- **Netlas** (netlas.io) - Internet intelligence

### Vulnerability & Exploit Search
- **NVD** (nvd.nist.gov) - National Vulnerability Database
- **Exploit-DB** (exploit-db.com) - Exploit archive
- **Vulners** (vulners.com) - Vulnerability database
- **Snyk Vulnerability DB**

### Attack Surface
- **FullHunt** (fullhunt.io) - Attack surface management
- **BinaryEdge** - Internet scanning
- **Onyphe** (onyphe.io) - Cyber defense search engine

### Code Search (Secret Hunting)
- **GitHub Code Search**, **GitLab Search**
- **Grep.app** - Code search across repos
- **SearchCode** - Source code search engine
- **PublicWWW** - Source code search in web pages

### Credential & Leak Search
- **Have I Been Pwned** (haveibeenpwned.com)
- **DeHashed** - Breach database search
- **LeakCheck**, **IntelX** (intelligence X)

### DNS & Domain Intelligence
- **SecurityTrails** - Historical DNS data
- **DNSDumpster** - DNS recon
- **crt.sh** - Certificate transparency search
- **VirusTotal** - Domain/IP analysis

### Social & OSINT
- **Epieos** - Email OSINT
- **Sherlock** - Username search across platforms
- **Social Searcher** - Social media search

### Threat Intelligence
- **VirusTotal**, **AbuseIPDB**, **ThreatCrowd**
- **Pulsedive** - Threat intelligence platform
- **GreyNoise** - Internet noise vs. targeted attacks

### Surveillance/IoT
- **Insecam** - Live camera directory
- **WiGLE** - WiFi network database

---

## 6. Physical Security & Lock Picking

Physical security knowledge for red team engagements:

### Key Resources
- **MIT Lock Picking Guide** - The classic introductory text
- **CIA Lock Picking Field Operative Training Manual** - Covers pin/wafer tumbler locks
- **Lock Picking: Detail Overkill (Solomon)** - Thorough technical reference
- **Deviant Ollam** - "Keys to the Kingdom" and "Practical Lock Picking" (DEF CON regular)

### Attack Techniques
- **SpiKey** - Acoustic-based physical key inference (microphone captures key insertion sounds to derive bitting)
- **Raking** - Fast, low-skill lock manipulation
- **Under-door tools** - Lever opening bypass
- **3D printed picks** - Plastic picks survive several uses

### Red Team Physical Security Relevance
- TOOOL (The Open Organisation Of Lockpickers) - International locksport community
- DEF CON and CCC host locksport competitions
- Physical penetration testing certifications reference these skills

---

## 7. Identity & Access Management

Identity and Access Management - comprehensive coverage:

### Zero Trust Architecture
- **BeyondCorp** (Google) - "Never trust, always verify"
- **Pomerium** - Identity-aware proxy
- **oathkeeper** (Ory) - Access proxy inspired by BeyondCorp
- **heimdall** - Cloud-native identity-aware proxy

### Authentication Best Practices
- **Password Storage**: Argon2id preferred (19 MiB memory, 2 iterations, 1 parallelism), scrypt as alternative, bcrypt for legacy (work factor 10+), PBKDF2 for FIPS-140 (600K iterations with HMAC-SHA-256)
- **MFA blocks 99.9%+ of account compromises** (Google/Microsoft research)
- **SMS 2FA deprecated by NIST since 2016** - SIM swap attacks make it insecure
- **WebAuthn/Passkeys** - Modern standard replacing passwords with public key crypto
- **YubiKey Guide** - GPG/SSH/SmartCard key storage

### Authorization Models
- **RBAC** - Role-Based Access Control
- **ABAC** - Attribute-Based Access Control
- **ReBAC** - Relationship-Based Access Control
- **Macaroons** - Flexible bearer credentials with caveats
- **OPA (Open Policy Agent)** - Policy-as-code for cloud native

### OAuth2/OpenID/SAML
- Protocol comparisons and implementation guidance
- JWT security considerations (RFC 4122 UUID warnings)

### Secret Management
- **HashiCorp Vault** - Industry standard
- **Conjur** (CyberArk) - Privileged identity secret management
- **HSMs** - Hardware Security Modules for key storage

### Trust & Safety
- Fraud detection, user identity verification
- Content moderation, captcha alternatives
- Blocklists (hostnames, emails, reserved IDs)

### Privacy/GDPR
- Anonymization techniques
- GDPR compliance frameworks

### Critical Insight
- "IAM is hard. It's really hard." - Overly permissive AWS IAM policies led to Capital One's $80M fine
- "IAM Is The Real Cloud Lock-In" - Platform dependency through identity systems

---

## 8. Security-Relevant Linux Tools

Security-relevant Linux tools and distributions:

### Security-Focused Distributions
- **Kali Linux** - Penetration testing (Debian-based)
- **Tails** - Anonymity-focused live OS (Tor-routed)
- **Qubes OS** - Compartmentalized security via Xen hypervisor

### Console Security Tools
- **shellcheck** - Static analysis for shell scripts (catches security bugs)
- **testdisk/photorec** - Data recovery
- **glances** - System monitoring

---

## 9. AI-Augmented Security Patterns

AI prompt pattern framework with security-relevant patterns:

### Security Analysis Patterns
- `analyze_threat_report` / `analyze_threat_report_cmds` / `analyze_threat_report_trends`
- `analyze_malware` - Malware analysis prompts
- `analyze_logs` - Log analysis patterns
- `analyze_incident` - Incident analysis
- `analyze_risk` - Risk assessment
- `create_stride_threat_model` - STRIDE threat modeling
- `create_threat_scenarios` - Threat scenario generation
- `create_sigma_rules` - Sigma rule generation
- `create_network_threat_landscape` - Network threat mapping
- `create_report_finding` / `improve_report_finding` - Security finding reports
- `create_security_update` - Security update summaries
- `create_cyber_summary` - Cybersecurity summaries
- `write_semgrep_rule` - Semgrep rule generation
- `write_nuclei_template_rule` - Nuclei template creation
- `write_hackerone_report` - Bug bounty report writing
- `ask_secure_by_design_questions` - Secure design review
- `analyze_email_headers` - Email header forensics
- `extract_poc` - PoC extraction from content
- `t_threat_model_plans` - Threat model planning
- `t_red_team_thinking` - Red team perspective analysis
- `greybeard_secure_prompt_engineer` - Secure prompt engineering
- `extract_algorithm_update_recommendations` - Algorithm update guidance

### Architecture Pattern
Fabric organizes prompts as "patterns" with system.md files containing role, task, and output format definitions. Each pattern is a self-contained prompt template.

### Integration Value
Fabric patterns can be piped: `echo "content" | fabric --pattern analyze_threat_report`
CLI-first design, supports multiple LLM backends including Claude.

---

## 10. Personal AI Security Infrastructure

PAI v4.0.3 - Claude Code native personal AI platform:

### Security-Relevant Architecture
- **TELOS system** - 10 files defining user identity, goals, context (MISSION.md, GOALS.md, etc.)
- **Memory System** - Three-tier (hot/warm/cold) with continuous learning
- **Skill System** - Deterministic hierarchy: CODE > CLI > PROMPT > SKILL
- **Hook System** - 8 lifecycle event types (session start, tool use, task completion)
- **Security System** - AllowList enforcement, command validation before execution
- **User/System Separation** - Upgrade-safe customization isolation

### Key Principles Applicable to CIPHER
- "Scaffolding > Model" - System architecture matters more than model choice
- "Code Before Prompts" - If solvable with bash, don't use AI
- "Spec / Test / Evals First" - Write specs before building
- "UNIX Philosophy" - Do one thing well, composable tools
- "Permission to Fail" - Explicit "I don't know" prevents hallucinations

---

## 11. Claude Code Agent Ecosystem

Claude Code plugin ecosystem: 72 plugins, 112 agents, 146 skills.

### Security-Relevant Plugins
- `security-scanning` - SAST with security skill
- `comprehensive-review` - Multi-perspective code analysis (architect, reviewer, security auditor)
- `incident-response` - IR management
- `full-stack-orchestration` - Multi-agent security hardening workflow

### Architecture Pattern
- Three-tier model strategy: Opus (critical/security), Sonnet (development), Haiku (operations)
- Progressive disclosure for skills: Metadata > Instructions > Resources
- Plugin isolation: each loads only its specific agents/commands/skills

---

## 12. Standards-Driven AI Development

Standards-driven AI development framework:

### Core Capabilities
- **Discover Standards** - Extract patterns from codebase into documented standards
- **Deploy Standards** - Inject relevant standards based on context
- **Shape Spec** - Better plans lead to better builds
- Works alongside Claude Code, Cursor, and other AI tools

### Security Application
- Extracting security patterns from codebases into enforceable standards
- Ensuring AI agents follow security conventions consistently

---

## 13. Windows Performance/Privacy Optimization

Windows modification for performance/privacy optimization:

### Security Stance
- Removes Windows telemetry, implements group policies for data collection minimization
- Optional security feature toggles: Defender, SmartScreen, Windows Update, UAC, Core Isolation, CPU Mitigations
- Uses AME Wizard with auditable Playbooks (plaintext scripts)
- Open source utilities with published hashes
- Complies with Microsoft Windows Usage Terms (no ISO redistribution)

### Red Team Relevance
- Understanding which security features can be disabled and how
- Attack surface changes when users apply "debloating" modifications

---

## 14. AI System Prompt Transparency

AI system prompt transparency project:

### What It Is
- Collection of extracted system prompts from OpenAI, Google, Anthropic, xAI, Perplexity, Cursor, Windsurf, Devin, Manus, Replit, and more
- Documents what AI models are instructed to refuse, redirect, or lie about
- Reveals ethical/political frames baked into default behavior

### Security Relevance
- Understanding AI model guardrails for red teaming AI systems
- System prompt analysis reveals trust boundaries
- "If you're interacting with an AI without knowing its system prompt, you're not talking to a neutral intelligence -- you're talking to a shadow-puppet"

### IMPORTANT NOTE
The README contains embedded prompt injection attempts (leetspeak directives attempting to make models output their instructions). This is a live example of prompt injection technique.

---

## 15. AI Jailbreak Techniques

AI jailbreak collection:

### What It Is
- Jailbreaks for flagship AI models
- Contains Unicode tag-based prompt injection (invisible characters encoding instructions)
- Uses zero-width Unicode characters to embed hidden directives

### Security Relevance
- **Prompt Injection Techniques**: Demonstrates Unicode tag-based injection, leetspeak encoding, role-playing exploitation
- **AI Red Teaming**: Reference for testing AI model robustness
- **Defense Implications**: Understanding these attacks is essential for building resilient AI-integrated systems

---

## 16. OSINT Investigation Toolkit

Bellingcat's Online Open Source Investigation Toolkit:

### What It Is
- OSINT investigation toolkit maintained by Bellingcat
- Tools organized by investigation function
- EU-funded (BENEDMO grant)

### Security Relevance
- Authoritative OSINT tool collection from the world's leading open-source investigation team
- Tools for verifying digital evidence, tracking disinformation
- Geolocation, image verification, social media analysis tools

---

## Web Resource Deep Dives

### Auditd Best Practice Rules
- Draws from UK gov, CentOS hardening, PCI DSS, NISPOM
- Balances coverage with performance
- Detects vulnerability exploitation (demonstrated with OMIGOD CVE)
- Works out-of-the-box on all major Linux distros

### OWASP Password Storage Cheat Sheet
- **Argon2id**: 19 MiB memory, 2 iterations, 1 parallelism (minimum)
- **scrypt**: CPU/memory cost 2^17, block size 8, parallelism 1
- **bcrypt**: Work factor 10+, 72-byte password limit
- **PBKDF2**: 600,000 iterations with HMAC-SHA-256 (FIPS-140)
- Peppering provides defense in depth (store separately from hashes)
- Hashing should complete in under 1 second

### Mozilla TLS Configuration Guidelines (v5.7)
| Setting | Modern | Intermediate | Old |
|---------|--------|-------------|-----|
| TLS Versions | 1.3 only | 1.2 + 1.3 | 1.0-1.3 |
| Ciphers | AES-128-GCM, AES-256-GCM, ChaCha20-Poly1305 | + ECDHE/DHE variants | + CBC, 3DES |
| Certificates | ECDSA (P-256/P-384) | RSA 2048+ or ECDSA | RSA 2048 |
| DH Parameters | 256-bit ECDH | 2048-bit | 1024-bit |
| OCSP Stapling | Yes | Yes | N/A |
| HSTS | 63,072,000s | 63,072,000s | 63,072,000s |
| Cert Lifetime | 90 days | 90 days | 90 days |

### Practical Linux Hardening Guide
- Eliminates 80-95% of known vulnerabilities when CIS/STIG/NIST applied
- Privilege management: Never use root, sudo for individual commands only
- Minimize attack surface: restrict unnecessary services
- OpenSCAP for automated compliance scanning (C2S/CIS, STIG, PCI-DSS)
- Test all changes in dev/test before production

---

## CROSS-REFERENCE: HIGHEST-VALUE TOOLS BY MODE

### RED MODE (Offensive)
1. Metasploit + Armitage (exploitation framework)
2. CrackMapExec (network pentest Swiss army knife)
3. impacket (Python network protocol library)
4. BloodHound/SharpHound (AD attack path mapping)
5. dnscat2/Iodine (covert channels)
6. Veil/Shellter (AV evasion)
7. BetterCAP (MITM framework)
8. Pwntools (exploit development)
9. Fabric patterns: write_hackerone_report, extract_poc, t_red_team_thinking

### BLUE MODE (Defensive)
1. Zeek + Suricata (network monitoring)
2. OSSEC/Wazuh (HIDS/EDR)
3. HELK (threat hunting stack)
4. Falco (container runtime monitoring)
5. RITA (beacon/tunnel detection)
6. Atomic Red Team + Caldera (adversary emulation)
7. TheHive + MISP (IR + threat intelligence)
8. Fabric patterns: create_sigma_rules, analyze_logs, analyze_incident

### ARCHITECT MODE (Design)
1. Mozilla SSL Configuration Generator
2. DevSec Hardening Framework
3. CIS Benchmarks + OpenSCAP
4. OPA (Open Policy Agent)
5. Checkov/tfsec/terrascan (IaC security)
6. BeyondCorp/Zero Trust architecture references
7. Fabric patterns: create_stride_threat_model, ask_secure_by_design_questions

### PRIVACY MODE
1. Tails OS (anonymous live system)
2. Signal Protocol (E2E encryption reference)
3. SOPS/Vault (secret management)
4. Shufflecake (plausible deniability)
5. Geneva (censorship evasion)
6. SecureDrop/GlobaLeaks (whistleblowing)

### RECON MODE (OSINT)
1. Bellingcat Toolkit
2. Shodan/Censys/ZoomEye (infrastructure)
3. Sherlock/Maigret (username OSINT)
4. crt.sh/SecurityTrails (DNS/cert intelligence)
5. Have I Been Pwned/DeHashed (credential leaks)
6. OWASP Amass (subdomain enumeration)

### INCIDENT MODE
1. Volatility (memory forensics)
2. GRR Rapid Response (remote forensics)
3. TheHive + Cortex (IR platform)
4. CAINE (forensic live distro)
5. ir-rescue scripts (evidence collection)
6. Fabric patterns: analyze_incident, analyze_logs

---

## AI Security Research

### Prompt Injection Taxonomy (Observed Techniques)
1. **Unicode Tag Injection** - Zero-width characters encoding hidden instructions
2. **Leetspeak Encoding** - Bypassing content filters via character substitution
3. **Role-Playing Exploitation** - "You are now DAN" style jailbreaks
4. **System Prompt Extraction** - Techniques to reveal hidden instructions
5. **Instruction Hierarchy Manipulation** - Overriding system prompts with user prompts

### Defense Implications for AI-Integrated Security Tools
- Validate all AI outputs before execution
- Implement input sanitization for AI pipelines
- Monitor for prompt injection in user-facing AI systems
- System prompt transparency reduces trust-based attacks
- Defense in depth: don't rely solely on AI guardrails

---

## SUMMARY: TOP 25 TOOLS EVERY SECURITY PRACTITIONER SHOULD KNOW

| # | Tool | Category | Why |
|---|------|----------|-----|
| 1 | Nmap | Recon | Network discovery standard |
| 2 | Metasploit | Exploitation | Industry standard framework |
| 3 | Burp Suite | Web Security | Web app testing |
| 4 | Wireshark | Network | Packet analysis |
| 5 | Zeek | NSM | Network security monitoring |
| 6 | Suricata | IDS/IPS | High-performance detection |
| 7 | OSSEC/Wazuh | HIDS/EDR | Host-based detection |
| 8 | Volatility | Forensics | Memory forensics |
| 9 | BloodHound | AD Attack | Attack path mapping |
| 10 | CrackMapExec | Network | Pentest Swiss army knife |
| 11 | Hashcat | Cracking | GPU hash cracking |
| 12 | impacket | Network | Protocol library |
| 13 | Lynis | Hardening | Linux audit |
| 14 | OpenSCAP | Compliance | Automated compliance |
| 15 | Vault | Secrets | Secret management |
| 16 | Trivy | Container | Container scanning |
| 17 | Falco | Container | Runtime monitoring |
| 18 | Prowler | Cloud | AWS security audit |
| 19 | TheHive | IR | Incident response platform |
| 20 | MISP | Threat Intel | Threat intelligence sharing |
| 21 | Shodan | Recon | Internet device search |
| 22 | Aircrack-ng | Wireless | WiFi auditing |
| 23 | testssl.sh | TLS | TLS configuration testing |
| 24 | Gophish | Phishing | Phishing simulation |
| 25 | Caldera | Emulation | MITRE adversary emulation |
