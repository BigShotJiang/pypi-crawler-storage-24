<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Security for Startups: A Founder's Complete Playbook

**CIPHER Training Module | Security Architecture & Program Design**
**Classification: INTERNAL — Founder & CTO Reference**
**Last Updated: 2026-03-14**

---

> "Security debt compounds faster than technical debt. Every month you delay baseline controls, the remediation cost doubles and your attack surface grows geometrically."

This guide is built from the intersection of two perspectives: the CEO who needs to ship product and close customers, and the principal security engineer who has seen what happens when security is retrofitted instead of designed in. It is opinionated, phased, and ruthlessly practical.

Sources integrated: CISA Cyber Essentials, Forter's Security 101 for SaaS Startups, OWASP Secure Product Design, NIST CSF, CIS Controls v8, and field experience from startup incident response engagements.

---

## Table of Contents

1. [Before You Start: Mental Models](#mental-models)
2. [Phase 1: Foundation (Day 1-30)](#phase-1)
3. [Phase 2: Hardening (Month 1-3)](#phase-2)
4. [Phase 3: Maturity (Month 3-6)](#phase-3)
5. [Phase 4: Compliance & Scale (Month 6-12)](#phase-4)
6. [Phase 5: Advanced Operations (Year 1+)](#phase-5)
7. [Budget Summary](#budget-summary)
8. [Compliance Mapping Matrix](#compliance-mapping)
9. [Tool Reference Index](#tool-index)
10. [Incident Response Starter Kit](#ir-starter)
11. [Threat Model Template](#threat-model)
12. [Common Mistakes That Kill Startups](#mistakes)

---

## <a id="mental-models"></a>1. Before You Start: Mental Models

### The "Mossad or Not Mossad" Framework

Credit: Forter's security guide. Two categories of adversary exist:

- **Nation-state actors**: Can intercept hardware shipments, purchase zero-days, bribe employees. Defending against this class of threat requires nation-state-level resources. You cannot win this fight at seed stage.
- **Everyone else**: Script kiddies, opportunistic criminals, disgruntled insiders, competitors. These adversaries are defeated by consistent application of fundamentals.

**Your job in Year 1 is to make "everyone else" attacks uneconomical.** That means the cost of attacking you exceeds the value of what they would steal. This is achievable on a startup budget.

### Security as a Sales Accelerator

Enterprise buyers evaluate your security posture before signing contracts. SOC 2 Type II is now table stakes for B2B SaaS. Having security controls in place from Day 1 means:

- Faster sales cycles (no scrambling to fill security questionnaires)
- Higher contract values (enterprise customers pay more for validated security)
- Lower insurance premiums (cyber insurance underwriters reward maturity)
- Reduced incident cost (average breach cost for companies <500 employees: $3.31M per IBM 2024 report)

### CISA's Six Pillars (Adapted for Startups)

CISA structures cyber readiness around six elements. Map your startup against these:

| Pillar | Startup Translation |
|--------|---------------------|
| **Yourself (Leadership)** | Founders own security decisions. No delegation without accountability. |
| **Your Staff** | Every engineer is a security engineer. Culture beats compliance. |
| **Your Systems** | Know what you run. Asset inventory is not optional. |
| **Your Surroundings** | Access control. Who can reach what, and why. |
| **Your Data** | Classify it, encrypt it, back it up, know where it flows. |
| **Your Crisis Response** | Have a plan before you need one. Tested plans, not shelf-ware. |

### OWASP Secure Design Principles

Every product decision should be filtered through these (OWASP Secure Product Design Cheat Sheet):

1. **Least Privilege**: Grant minimum access needed. No exceptions.
2. **Defense in Depth**: Multiple layers. No single point of failure.
3. **Zero Trust**: Authenticate and authorize every request. Internal network is not trusted.
4. **Secure Defaults**: Ship locked down. Users opt into less security, never the reverse.
5. **Fail Secure**: Errors deny access, not grant it.

---

## <a id="phase-1"></a>2. Phase 1: Foundation (Day 1-30)

**Objective**: Establish non-negotiable security baselines before writing production code.

**Time Investment**: ~40 hours total across founding team.
**Estimated Cost**: $0-200/month (mostly free/open-source tools).

### 2.1 MFA Everywhere

**Why first**: Credential theft is the #1 initial access vector (Verizon DBIR, every year). MFA blocks >99% of automated credential attacks.

**Implementation**:

| Service | MFA Method | Priority |
|---------|-----------|----------|
| GitHub/GitLab | TOTP or hardware key | Critical |
| Cloud provider (AWS/GCP/Azure) | Hardware key for root; TOTP for IAM | Critical |
| Email (Google Workspace / M365) | TOTP minimum; push or FIDO2 preferred | Critical |
| Password manager | Hardware key + master password | Critical |
| Slack / communication tools | TOTP | High |
| Domain registrar | TOTP + recovery codes stored offline | High |
| CI/CD (GitHub Actions, etc.) | TOTP | High |

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **Aegis Authenticator** (Android) | Free, OSS | Encrypted backup, offline |
| **Ente Auth** (cross-platform) | Free, OSS | End-to-end encrypted sync |
| **YubiKey 5** (hardware) | ~$50/key | FIDO2/U2F, buy 2 per person (1 backup) |

**Anti-pattern**: Do NOT use SMS-based 2FA. SIM-swap attacks are trivial and well-documented. SMS 2FA is better than nothing but should be replaced immediately with TOTP or hardware keys.

**Compliance impact**: SOC 2 CC6.1, ISO 27001 A.9.4.2, NIST 800-53 IA-2, CIS Control 6.

### 2.2 Secrets Management

**Why now**: Hardcoded secrets in source code are the startup breach cliche. One leaked `.env` file, one public S3 bucket, one git history search, and your production database is owned.

**Immediate actions**:

1. **Install a pre-commit hook** to block secrets from entering version control:

```bash
# Install gitleaks as a pre-commit hook
pip install pre-commit

# .pre-commit-config.yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.0
    hooks:
      - id: gitleaks
```

2. **Audit existing git history** for leaked secrets:

```bash
# Scan full repository history
gitleaks detect --source . --verbose

# If secrets found: rotate immediately, then clean history
git filter-repo --invert-paths --path <file-with-secret>
```

3. **Adopt an environment-variable-based secrets flow**:

| Tool | Cost | Best For |
|------|------|----------|
| **doppler** | Free tier (5 users) | Multi-environment secret sync, CLI + SDK |
| **infisical** | Free, OSS (self-host) | Self-hosted, E2E encrypted, good DX |
| **SOPS** (Mozilla) | Free, OSS | Encrypts files in-repo with KMS/AGE/PGP |
| **AWS Secrets Manager** | $0.40/secret/month | Native AWS integration |
| **HashiCorp Vault** | Free, OSS (self-host) | Enterprise-grade, dynamic secrets |

**Minimum viable secrets flow**:
- Secrets stored in a secrets manager, never in code or config files.
- `.env` files in `.gitignore` (always, no exceptions).
- CI/CD pulls secrets from the secrets manager at deploy time.
- Secrets rotated on a schedule (90-day minimum for static credentials).
- Service accounts use short-lived tokens where possible (AWS IAM roles, GCP service account impersonation).

**Compliance impact**: SOC 2 CC6.1, CC6.7, ISO 27001 A.10.1, NIST 800-53 SC-12, SC-28, CIS Control 3.11.

### 2.3 Basic Logging

**Why now**: If you get breached and have no logs, you cannot determine what happened, what was taken, or how to recover. Forensic readiness starts on Day 1.

**Minimum logging requirements**:

| Log Source | What to Capture | Retention |
|------------|-----------------|-----------|
| Cloud provider API calls | AWS CloudTrail / GCP Audit Logs | 1 year minimum |
| Application authentication | Login success/failure, MFA events | 1 year |
| Application errors | Stack traces, request context | 90 days |
| Infrastructure access | SSH sessions, kubectl commands | 1 year |
| DNS queries | Resolution logs | 90 days |

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **AWS CloudTrail** | Free (management events) | Enable in every region, all accounts |
| **Grafana Loki** | Free, OSS | Log aggregation, pairs with Grafana |
| **Vector** (Datadog) | Free, OSS | Log pipeline, replaces Fluentd/Logstash |
| **OpenTelemetry** | Free, OSS | Unified traces/metrics/logs |

**Critical configuration**:
- Enable CloudTrail in ALL regions (attackers use unused regions to hide activity).
- Ship logs to a separate AWS account (prevents attacker log deletion).
- Enable S3 access logging on any bucket containing sensitive data.
- Set log retention policies before you forget (CloudWatch defaults to "never expire" which gets expensive).

**Compliance impact**: SOC 2 CC7.1, CC7.2, ISO 27001 A.12.4, NIST 800-53 AU-2, AU-3, AU-6, CIS Control 8.

### 2.4 Dependency Scanning

**Why now**: 80-90% of your codebase is dependencies. Supply chain attacks (SolarWinds, Log4Shell, xz-utils) demonstrate this is not theoretical.

**Implementation**:

```yaml
# GitHub Actions: enable Dependabot
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "pip"
    directory: "/"
    schedule:
      interval: "weekly"
    open-pull-requests-limit: 10

  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"

  - package-ecosystem: "docker"
    directory: "/"
    schedule:
      interval: "weekly"
```

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **Dependabot** (GitHub) | Free | Automatic PRs for vulnerable deps |
| **Trivy** (Aqua) | Free, OSS | Container + filesystem + IaC scanning |
| **Grype** (Anchore) | Free, OSS | Vulnerability scanner for containers and filesystems |
| **pip-audit** | Free, OSS | Python-specific, uses OSV database |
| **npm audit** | Free, built-in | Node.js, built into npm CLI |
| **OSV-Scanner** (Google) | Free, OSS | Multi-ecosystem, uses OSV database |

**Integration pattern**:

```yaml
# CI pipeline step (GitHub Actions example)
- name: Scan dependencies
  uses: aquasecurity/trivy-action@master
  with:
    scan-type: 'fs'
    scan-ref: '.'
    severity: 'CRITICAL,HIGH'
    exit-code: '1'  # Fail the build on critical/high vulns
```

**Policy**: Critical and High vulnerabilities block deployment. Medium vulnerabilities must be triaged within 7 days. Low/Info tracked but not blocking.

**Compliance impact**: SOC 2 CC7.1, ISO 27001 A.12.6.1, NIST 800-53 SI-2, RA-5, CIS Control 7, CIS Control 16.

### 2.5 Encryption at Rest and in Transit

**In Transit**:
- TLS 1.2+ on every endpoint. No exceptions.
- Use Let's Encrypt (free) or AWS ACM (free for AWS resources) for certificate management.
- Enable HSTS header: `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
- Internal service-to-service traffic: also encrypted (mTLS via service mesh, or at minimum TLS).

**At Rest**:
- Enable default encryption on all storage services:
  - AWS: S3 (SSE-S3 or SSE-KMS), EBS (default encryption), RDS (encryption enabled at creation)
  - GCP: Default encryption is on, but use CMEK for regulated data
  - Database: PostgreSQL `pgcrypto` for column-level, or transparent disk encryption
- Full-disk encryption on all employee devices (FileVault on macOS, LUKS on Linux, BitLocker on Windows).

**Key Management**:
- Use cloud provider KMS (AWS KMS, GCP Cloud KMS) — do not roll your own.
- Separate encryption keys per environment (dev, staging, prod).
- Key rotation: annual minimum, automated where possible.

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **Let's Encrypt / certbot** | Free | Automated TLS certificates |
| **AWS ACM** | Free | TLS certs for AWS resources |
| **AWS KMS** | $1/key/month | Managed key service |
| **age** (FiloSottile) | Free, OSS | Modern file encryption, replaces GPG for files |
| **mkcert** | Free, OSS | Local dev TLS certificates |

**Compliance impact**: SOC 2 CC6.1, CC6.7, ISO 27001 A.10.1, A.13.1, NIST 800-53 SC-8, SC-28, CIS Control 3.

### 2.6 Additional Day-1 Essentials

**Domain hygiene** (per Forter's guide):
- Separate domains: company (marketing/email), service (API), internal (back-office).
- Enable SPF, DKIM, and DMARC on email domains from day one.
- Register domains with registrar lock and MFA on registrar accounts.

**Password manager**:
- Team password manager deployed before first hire. Non-negotiable.
- Recommended: **Bitwarden** (free OSS self-host, or $4/user/month hosted), **1Password** ($7.99/user/month).
- Policy: every employee memorizes exactly two passwords — device login and password manager master.

**Endpoint basics**:
- Full-disk encryption enabled.
- Automatic OS security updates enabled.
- Firewall enabled, block all incoming connections.
- Screen lock after 5 minutes of inactivity.

### Phase 1 Checklist

```
[ ] MFA enabled on all cloud, code, email, and communication accounts
[ ] Hardware keys purchased for founders (2 per person)
[ ] Password manager deployed, all credentials migrated
[ ] Pre-commit hook for secret scanning installed
[ ] Git history audited for leaked secrets
[ ] Secrets manager selected and integrated
[ ] .env files added to .gitignore globally
[ ] CloudTrail enabled in all regions
[ ] Log shipping to separate account or service configured
[ ] Application logging structured and centralized
[ ] Dependabot or equivalent enabled on all repositories
[ ] CI pipeline fails on critical/high vulnerabilities
[ ] TLS on all endpoints (no HTTP allowed)
[ ] HSTS header deployed
[ ] Default encryption enabled on all storage services
[ ] Full-disk encryption on all employee devices
[ ] SPF, DKIM, DMARC configured on email domains
[ ] Separate domains for company, service, internal use
[ ] security.txt published (RFC 9116)
[ ] Screen lock and firewall enforced on all endpoints
```

---

## <a id="phase-2"></a>3. Phase 2: Hardening (Month 1-3)

**Objective**: Build security into the development lifecycle and establish access governance.

**Time Investment**: ~60 hours across engineering team.
**Estimated Cost**: $100-500/month.

### 3.1 SAST in CI/CD

Static Application Security Testing catches vulnerabilities before code reaches production.

**Tools**:

| Tool | Cost | Language Support | Notes |
|------|------|-----------------|-------|
| **Semgrep** | Free (OSS rules), paid for Pro rules | 30+ languages | Best DX, custom rule authoring, fast |
| **Bandit** | Free, OSS | Python | Python-specific, mature |
| **Gosec** | Free, OSS | Go | Go-specific |
| **Brakeman** | Free, OSS | Ruby/Rails | Rails-specific |
| **CodeQL** (GitHub) | Free for public repos | Multiple | Deep analysis, slower, good for finding complex bugs |
| **SonarQube CE** | Free, OSS | Multiple | Self-hosted, broader code quality scope |

**Recommended approach**: Start with Semgrep. It is fast, has excellent signal-to-noise ratio, and supports custom rules for your codebase patterns.

```yaml
# GitHub Actions integration
- name: Semgrep SAST
  uses: returntocorp/semgrep-action@v1
  with:
    config: >-
      p/security-audit
      p/secrets
      p/owasp-top-ten
```

**Policy**:
- SAST runs on every pull request.
- High-severity findings block merge.
- Medium findings require triage comment before merge.
- Custom rules added for patterns specific to your application (e.g., raw SQL construction, unsafe deserialization).

**Compliance impact**: SOC 2 CC7.1, CC8.1, ISO 27001 A.14.2, NIST 800-53 SA-11, CIS Control 16.

### 3.2 Vulnerability Scanning

**Infrastructure scanning** (what's exposed, what's misconfigured):

| Tool | Cost | Scope | Notes |
|------|------|-------|-------|
| **Prowler** | Free, OSS | AWS, Azure, GCP | CIS Benchmark checks, compliance reports |
| **ScoutSuite** | Free, OSS | Multi-cloud | Configuration audit |
| **Nuclei** | Free, OSS | Web applications | Template-based, fast, huge community templates |
| **Nmap** | Free, OSS | Network | Port scanning, service detection |
| **Trivy** | Free, OSS | Containers, IaC, filesystem | Already deployed in Phase 1; extend to IaC scanning |
| **Cloud Custodian** | Free, OSS | Cloud resources | Policy-as-code for cloud governance |

**Scanning cadence**:

| Scan Type | Frequency | Tool |
|-----------|-----------|------|
| Cloud configuration | Daily (automated) | Prowler |
| Container images | Every build | Trivy |
| IaC templates | Every PR | Trivy, checkov |
| External attack surface | Weekly | Nuclei |
| Internal network | Monthly | Nmap |

**AWS-specific quick wins** (from toniblyx's arsenal):

```bash
# Run Prowler against your AWS account
prowler aws --severity critical high --compliance cis_2.0_aws

# Generate HTML report
prowler aws -M html -o /tmp/prowler-report

# Automate with a weekly cron in CI
```

**Compliance impact**: SOC 2 CC7.1, CC4.1, ISO 27001 A.12.6, NIST 800-53 RA-5, CA-8, CIS Control 7.

### 3.3 Access Reviews

**Why now**: As you make your first hires, access sprawl begins. Establish governance before it becomes unmanageable.

**Process**:

1. **Inventory all accounts and permissions** — who has access to what, at what privilege level.
2. **Apply least privilege** — revoke any access not required for current role.
3. **Establish access request workflow** — even if it is a Slack message to a founder, document it.
4. **Quarterly review cadence** — calendar it. Every 90 days, every person's access is reviewed.
5. **Offboarding checklist** — automated if possible:

```
OFFBOARDING SECURITY CHECKLIST
[ ] Revoke all cloud provider IAM accounts
[ ] Remove from GitHub/GitLab organization
[ ] Remove from password manager shared vaults
[ ] Deactivate email account (do not delete — preserve for legal hold)
[ ] Remove from VPN/SSH access
[ ] Remove from Slack/communication tools
[ ] Rotate any shared secrets the employee had access to
[ ] Collect hardware (laptop, YubiKeys)
[ ] Review recent file download/access history
[ ] Remove from SSO/identity provider
```

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **AWS IAM Access Analyzer** | Free | Identifies unused access |
| **CloudTracker** | Free, OSS | Maps IAM to actual CloudTrail usage |
| **PMapper** | Free, OSS | Visualizes IAM privilege escalation paths |
| **Indent** | Free tier | Access request workflow |

**Compliance impact**: SOC 2 CC6.2, CC6.3, ISO 27001 A.9.2, NIST 800-53 AC-2, AC-6, CIS Control 5, CIS Control 6.

### 3.4 Incident Response Plan

**Why now**: You do not need a 50-page plan. You need a one-page runbook that everyone knows exists and has read.

**Starter Incident Response Plan**:

```
INCIDENT RESPONSE PLAN v1.0
Company: [Your Company]
Effective: [Date]
Owner: [CTO/Founder Name]

SEVERITY LEVELS:
  SEV-1 (Critical): Active data breach, production compromise, ransomware
  SEV-2 (High):     Suspected breach, exposed credentials, service degradation
  SEV-3 (Medium):   Vulnerability discovered, suspicious activity, policy violation
  SEV-4 (Low):      Security improvement opportunity, minor misconfiguration

COMMUNICATION:
  Internal:  #security-incidents Slack channel (private)
  External:  [Founder Name] is sole external spokesperson
  Legal:     [Law firm name and contact] (retain a firm with breach experience NOW)
  Cyber Ins: [Policy number and claims contact]

TRIAGE (0-15 minutes):
  1. Confirm the incident is real (not a false positive)
  2. Determine severity level
  3. Notify incident lead (CTO → CEO → [backup])
  4. Begin incident log (timestamped notes, who did what)

CONTAINMENT (15-60 minutes):
  1. Isolate affected systems (revoke credentials, block IPs, disable accounts)
  2. Preserve evidence BEFORE making changes (snapshot VMs, export logs)
  3. Rotate all potentially compromised credentials
  4. Determine blast radius (what data/systems were accessible?)

ERADICATION:
  1. Identify root cause and attack vector
  2. Patch vulnerability or close access path
  3. Verify no persistence mechanisms remain (backdoors, new accounts)
  4. Scan for lateral movement indicators

RECOVERY:
  1. Restore from known-good backups if necessary
  2. Monitor restored systems for continued compromise
  3. Gradually restore service with enhanced monitoring
  4. Communicate status to affected parties

POST-INCIDENT (within 72 hours):
  1. Write timeline of events
  2. Conduct blameless post-mortem
  3. Document lessons learned and detection gaps
  4. Update detection rules and runbooks
  5. Determine notification obligations (GDPR Art. 33: 72-hour window)

EXTERNAL RESOURCES:
  - CISA: report at cisa.gov/report
  - FBI IC3: ic3.gov
  - Breach counsel: [pre-retained firm]
```

**Key principle**: Retain a law firm with breach response experience BEFORE you need one. Attorney-client privilege protects your incident investigation from discovery. This is not paranoia — it is standard practice.

**Compliance impact**: SOC 2 CC7.3, CC7.4, CC7.5, ISO 27001 A.16, NIST 800-53 IR-1 through IR-8, CIS Control 17.

### 3.5 Security Headers

**Implementation** — add these to every HTTP response:

```
# Recommended security headers
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self' https://api.yourservice.com; frame-ancestors 'none'; base-uri 'self'; form-action 'self'
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
```

**Validation**: Run your site through https://securityheaders.com and https://observatory.mozilla.org. Target A+ on both.

**Tool**:

| Tool | Cost | Notes |
|------|------|-------|
| **helmet** (Node.js) | Free, OSS | Express middleware, sets headers automatically |
| **django-csp** | Free, OSS | Django CSP middleware |
| **secure** (Python) | Free, OSS | Framework-agnostic Python security headers |

**Compliance impact**: SOC 2 CC6.1, ISO 27001 A.14.1, NIST 800-53 SC-7, CIS Control 9.

### 3.6 Additional Phase 2 Items

**VPN or Zero Trust Network Access**:
- For remote teams, deploy either a VPN or zero-trust access proxy.
- **Tailscale**: Free for personal, $6/user/month for teams. WireGuard-based, zero-config mesh VPN.
- **Cloudflare Access**: Free tier available. Zero-trust proxy, no VPN client needed.
- Alternative OSS: **Headscale** (self-hosted Tailscale control server), **Netbird** (OSS zero-trust networking).

**Separate AWS accounts**:
- At minimum: `production`, `staging`, `security-logging`, `identity`.
- Use AWS Organizations with SCPs (Service Control Policies) to enforce guardrails.
- Log archive account should be write-once (CloudTrail → S3 with Object Lock).

**Backup strategy**:
- Automated, tested, isolated, geographically distributed.
- Backups in a separate AWS account (prevents ransomware from reaching backups).
- Test restore quarterly. Untested backups are not backups.

### Phase 2 Checklist

```
[ ] SAST scanner integrated into CI/CD pipeline
[ ] High-severity SAST findings block merge
[ ] Cloud configuration scanner running daily (Prowler)
[ ] Container images scanned on every build
[ ] External attack surface scanned weekly
[ ] Access inventory documented for all systems
[ ] Quarterly access review scheduled and calendared
[ ] Offboarding checklist created and tested
[ ] Incident response plan written and distributed to team
[ ] Breach counsel retained
[ ] Cyber insurance policy purchased
[ ] Security headers deployed and validated (A+ rating)
[ ] VPN or zero-trust network access deployed
[ ] AWS accounts separated (prod/staging/security/identity)
[ ] Backup strategy implemented and tested
[ ] DNS protection configured (DoH/DoT)
```

---

## <a id="phase-3"></a>4. Phase 3: Maturity (Month 3-6)

**Objective**: Prepare for enterprise sales, establish formal security processes, begin compliance journey.

**Time Investment**: ~100 hours across team + external resources.
**Estimated Cost**: $500-3,000/month.

### 4.1 SOC 2 Preparation

**Why now**: Enterprise buyers will ask. Starting at Month 3 means you can have Type I by Month 9 and Type II by Month 18. That timeline wins deals.

**SOC 2 Trust Service Criteria**:

| Criteria | Required? | Focus Areas |
|----------|-----------|-------------|
| Security (CC) | Always required | Access control, change management, risk assessment, monitoring |
| Availability | If you sell SaaS uptime | Disaster recovery, capacity planning, monitoring |
| Processing Integrity | If you process transactions | Input validation, error handling, completeness checks |
| Confidentiality | If you handle confidential data | Encryption, access restrictions, data classification |
| Privacy | If you handle personal data | Notice, consent, collection limitation, use/retention/disposal |

**Start with Security + Availability** — add others based on customer requirements.

**Approach**:

1. **Select a compliance automation platform** (dramatically reduces time investment):

| Platform | Cost | Notes |
|----------|------|-------|
| **Vanta** | ~$6,000-15,000/year | Market leader, extensive integrations |
| **Drata** | ~$5,000-12,000/year | Strong automation, good UX |
| **Secureframe** | ~$5,000-12,000/year | Good for startups |
| **Comply** (open-source) | Free, OSS | GRC framework, self-managed |

2. **Engage an auditor early** — get a readiness assessment at Month 3-4 before formal audit.
3. **Write policies** — compliance platforms provide templates. Customize, do not copy-paste.

**Required policies** (minimum for SOC 2):
- Information Security Policy
- Access Control Policy
- Change Management Policy
- Incident Response Policy (already written in Phase 2)
- Risk Assessment and Treatment Policy
- Data Classification and Handling Policy
- Business Continuity and Disaster Recovery Policy
- Vendor Management Policy
- Acceptable Use Policy
- Encryption Policy

**Compliance impact**: SOC 2 (all criteria), ISO 27001 (partial), NIST CSF (maps directly).

### 4.2 Penetration Testing

**Why now**: You have enough product and infrastructure to test. Pen tests satisfy customer requirements and reveal blind spots your automated tools miss.

**Types of pen tests**:

| Type | Scope | Recommended For |
|------|-------|-----------------|
| **External network** | Internet-facing assets | Every startup |
| **Web application** | Your SaaS product | Every startup |
| **API** | Your API endpoints | If API is core product |
| **Cloud configuration** | AWS/GCP/Azure setup | If cloud-native |
| **Internal network** | Office/VPN network | If you have an office |
| **Social engineering** | Phishing simulation | Phase 4+ |

**Budget guidance**:
- External + Web application pen test: $5,000-15,000 for a startup-sized scope.
- Retest after remediation: often included or $1,000-3,000.
- Frequency: annually minimum; after major architecture changes.

**Selecting a firm**:
- Require OSCP, OSCE, or CREST certified testers (not just the firm).
- Ask for sample reports. Quality varies enormously.
- Grey-box testing is usually best ROI: provide authenticated access to simulate a real customer or compromised credential scenario.
- Request CVSS-scored findings with proof-of-concept.

**OSS alternatives for continuous testing**:

| Tool | Cost | Notes |
|------|------|-------|
| **OWASP ZAP** | Free, OSS | DAST scanner, good for CI integration |
| **Nuclei** | Free, OSS | Template-based vulnerability scanner |
| **Burp Suite Community** | Free | Manual web testing (Pro: $449/year) |
| **sqlmap** | Free, OSS | SQL injection detection and exploitation |
| **ffuf** | Free, OSS | Web fuzzer for content discovery |

**Compliance impact**: SOC 2 CC4.1, CC7.1, ISO 27001 A.18.2, NIST 800-53 CA-8, CIS Control 18.

### 4.3 Security Awareness Training

**Why now**: Your team is growing. New hires do not have the security context that founders built up over months.

**Program structure**:

| Topic | Format | Frequency |
|-------|--------|-----------|
| Phishing recognition | Interactive simulation | Monthly (short) |
| Secure coding practices | Workshop, OWASP Top 10 | Quarterly |
| Secrets handling | Onboarding module | At hire + annual |
| Incident reporting | Tabletop exercise | Semi-annual |
| Social engineering | Awareness session | Annual |

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **Gophish** | Free, OSS | Self-hosted phishing simulation |
| **KnowBe4** | ~$15-25/user/year | Comprehensive platform, extensive library |
| **Curricula** | Free tier | Engaging, story-based content |
| **OWASP WebGoat** | Free, OSS | Hands-on secure coding training |
| **HackTheBox** | Free tier + paid | Practical security skills for engineers |

**Key metrics**:
- Phishing simulation click rate (target: <5% after 6 months).
- Training completion rate (target: 100%).
- Time-to-report for simulated phishing (target: <30 minutes).
- Security questions in code review (qualitative improvement).

**Anti-pattern**: Do NOT use "gotcha" phishing simulations that punish employees. This destroys trust and discourages reporting. Reward reporting, even of simulated phishes.

**Compliance impact**: SOC 2 CC1.4, CC2.2, ISO 27001 A.7.2.2, NIST 800-53 AT-2, AT-3, CIS Control 14.

### 4.4 DLP Basics

**Why now**: As your team grows and handles more customer data, you need basic controls against data exfiltration — intentional or accidental.

**Proportionate approach for startups**:

1. **Data classification** (three levels is enough):
   - **Public**: Marketing content, documentation.
   - **Internal**: Code, internal discussions, architecture docs.
   - **Confidential**: Customer data, credentials, financial data, PII.

2. **Technical controls**:

| Control | Tool | Cost |
|---------|------|------|
| Block USB storage devices | OS policy / MDM | Free |
| Cloud DLP scanning | **Google Cloud DLP** / AWS Macie | Usage-based |
| Email DLP | Google Workspace DLP rules | Included |
| Endpoint DLP | **OpenDLP** | Free, OSS |
| Git scanning (prevent data in repos) | **gitleaks** (already deployed) | Free |

3. **Process controls**:
   - Customer data does not go into Slack, email, or personal devices.
   - Production data is never copied to development environments without anonymization.
   - Data minimization: collect only what you need, retain only as long as required.

**Compliance impact**: SOC 2 CC6.5, CC6.7, ISO 27001 A.8.2, A.13.2, NIST 800-53 AC-4, SC-7, GDPR Art. 5, CIS Control 3.

### 4.5 Threat Modeling

**Why now**: You have a product with real users. Threat modeling before your next major feature saves remediation cost (10-100x cheaper to fix in design than production).

**STRIDE method** (recommended starting framework):

| Threat | Question | Example |
|--------|----------|---------|
| **S**poofing | Can someone pretend to be another user/service? | API key reuse across tenants |
| **T**ampering | Can someone modify data they should not? | Direct object reference to modify another tenant's record |
| **R**epudiation | Can someone deny they performed an action? | Missing audit logs on admin actions |
| **I**nformation Disclosure | Can data leak to unauthorized parties? | Error messages exposing internal paths |
| **D**enial of Service | Can someone crash or degrade the service? | Unbounded API queries |
| **E**levation of Privilege | Can someone gain higher access than intended? | JWT manipulation, IDOR |

**Process**:

1. Draw a data flow diagram (DFD) with trust boundaries.
2. Walk each data flow across trust boundaries.
3. Apply STRIDE to each crossing point.
4. Score using DREAD (Damage, Reproducibility, Exploitability, Affected Users, Discoverability).
5. Prioritize: High DREAD score + low remediation cost = fix immediately.

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **OWASP Threat Dragon** | Free, OSS | Web-based threat modeling |
| **Microsoft Threat Modeling Tool** | Free | Windows-only, mature |
| **Threagile** | Free, OSS | Agile threat modeling as code (YAML-based) |
| **IriusRisk Community** | Free tier | Automated threat modeling |
| **draw.io** | Free | Manual DFDs (sometimes simplest is best) |

**When to threat model**:
- New service or major feature.
- New integration with external system.
- Change in data flow or trust boundary.
- Annually for existing architecture.

**Compliance impact**: SOC 2 CC3.1, CC3.2, ISO 27001 A.14.2.5, NIST 800-53 RA-3, SA-8, CIS Control 16.

### Phase 3 Checklist

```
[ ] SOC 2 compliance platform selected and configured
[ ] Core security policies written and approved
[ ] Auditor engaged for readiness assessment
[ ] External penetration test completed
[ ] All critical/high pen test findings remediated
[ ] Phishing simulation program launched
[ ] Security onboarding module created for new hires
[ ] Data classification policy defined (Public/Internal/Confidential)
[ ] USB storage blocked on endpoints
[ ] Production data access restricted and logged
[ ] Threat model completed for core product
[ ] STRIDE analysis documented for each trust boundary
[ ] DLP rules configured for email and cloud storage
```

---

## <a id="phase-4"></a>5. Phase 4: Compliance & Scale (Month 6-12)

**Objective**: Achieve formal compliance, establish continuous security monitoring, begin building security capability.

**Time Investment**: ~200 hours + external auditor engagement.
**Estimated Cost**: $3,000-10,000/month.

### 5.1 Full Compliance (SOC 2 Type I → Type II / ISO 27001)

**SOC 2 Type I** (point-in-time):
- Verifies controls are designed appropriately at a specific date.
- Timeline: 1-2 months of audit engagement after readiness.
- Cost: $15,000-30,000 (auditor fees).

**SOC 2 Type II** (operating effectiveness over time):
- Verifies controls operated effectively over a period (minimum 3 months, typically 6-12 months).
- Observation period begins after Type I.
- Cost: $20,000-50,000 (auditor fees).

**ISO 27001** (if pursuing in parallel):
- International standard, more recognized outside North America.
- Requires formal ISMS (Information Security Management System).
- Certification audit in two stages.
- Cost: $15,000-40,000 (certification body fees) + implementation effort.

**Decision framework**:

| Selling to... | Get... |
|---------------|--------|
| US B2B SaaS | SOC 2 Type II first |
| European enterprise | ISO 27001 first |
| Healthcare (US) | SOC 2 + HIPAA BAA |
| Financial services | SOC 2 + additional controls |
| Government | FedRAMP (significant investment — Phase 5+) |

**Compliance impact**: Satisfies customer and regulatory requirements directly.

### 5.2 Bug Bounty Program

**Why now**: You have basic security maturity. A bug bounty extends your security testing to the global researcher community.

**Phased approach**:

1. **Private program first** (Month 6-9):
   - Invite 10-20 vetted researchers.
   - Set clear scope (in-scope domains, out-of-scope items).
   - Define reward tiers.

2. **Public program later** (Month 12+):
   - Open to all researchers.
   - Higher volume, higher noise.

**Reward tiers** (startup-appropriate):

| Severity | CVSS | Reward Range |
|----------|------|-------------|
| Critical | 9.0-10.0 | $1,000-5,000 |
| High | 7.0-8.9 | $500-2,000 |
| Medium | 4.0-6.9 | $200-500 |
| Low | 0.1-3.9 | $50-100 |

**Platforms**:

| Platform | Cost | Notes |
|----------|------|-------|
| **HackerOne** | Program management fees | Largest researcher community |
| **Bugcrowd** | Program management fees | Good triage support |
| **Intigriti** | Program management fees | Strong European presence |
| **huntr** | Free | OSS-focused, good for OSS projects |
| **Self-hosted** (security.txt + email) | Free | Lowest cost, highest management overhead |

**Prerequisites before launch**:
- Incident response process tested and functional.
- Dedicated triage person (can be part-time, but must respond within 48 hours).
- Clear scope document.
- Safe harbor statement protecting researchers from legal action.

**Compliance impact**: SOC 2 CC4.1, ISO 27001 A.18.2.3, NIST 800-53 CA-8, RA-5.

### 5.3 SIEM & Advanced Monitoring

**Why now**: You have logs (from Phase 1). Now you need the ability to detect threats in those logs.

**Evolution path**:

```
Phase 1: Centralized logs (Loki/CloudWatch)
    ↓
Phase 4: Log analysis + alerting (SIEM-lite)
    ↓
Phase 5: Full SIEM + detection engineering + SOAR
```

**Tools by budget**:

| Tool | Cost | Notes |
|------|------|-------|
| **Wazuh** | Free, OSS | SIEM + XDR + compliance. Best OSS option for startups. |
| **Grafana Loki + Alerting** | Free, OSS | If already using Grafana stack |
| **ElasticSearch + Kibana** (SIEM) | Free, OSS (basic) | Elastic SIEM features in free tier |
| **Matano** | Free, OSS | Serverless SIEM on AWS (S3 + Athena) |
| **CrowdStrike Falcon Go** | ~$5/endpoint/month | Managed EDR for small teams |
| **Panther** | Free tier | Cloud-native SIEM, Python detections |

**Recommended for startups**: **Wazuh** — it covers SIEM, file integrity monitoring, vulnerability detection, compliance checking, and endpoint detection in a single platform. Self-hosted, no per-endpoint licensing.

**Minimum detection rules to deploy**:

| Detection | Severity | Data Source |
|-----------|----------|-------------|
| Root/admin login from new IP | High | CloudTrail / auth logs |
| IAM user created | Medium | CloudTrail |
| Security group modified (0.0.0.0/0 ingress) | Critical | CloudTrail |
| S3 bucket made public | Critical | CloudTrail |
| Multiple failed login attempts | Medium | Application logs |
| Unusual data egress volume | High | VPC Flow Logs |
| CloudTrail logging disabled | Critical | CloudTrail (meta!) |
| New access key created for root | Critical | CloudTrail |
| Console login without MFA | High | CloudTrail |
| KMS key deletion scheduled | Critical | CloudTrail |

**Compliance impact**: SOC 2 CC7.2, CC7.3, ISO 27001 A.12.4, NIST 800-53 SI-4, AU-6, IR-4, CIS Control 8.

### 5.4 Security Team Hiring

**When to hire your first security person**:
- You have 20+ engineers and no dedicated security.
- Enterprise customers are asking security questions weekly.
- Compliance requires dedicated ownership.
- Founders can no longer give security adequate time.

**First security hire profile**:
- **Not a CISO.** You need a senior security engineer who can build.
- Generalist: application security + cloud security + detection.
- Can write code, not just policies.
- Comfortable with ambiguity and building from zero.
- Title: "Security Engineer" or "Head of Security" — not CISO until you have a team to lead.

**CISO timing** (per Forter's guide):
- Hire a CISO-level (Director/VP Security) when security team reaches 3-5 people.
- Must have: technical depth, sales capability, leadership skills, culture fit.
- Expect: months to hire due to scarcity of qualified candidates.

**Budget for first security hire**: $150,000-250,000 total comp (US market, 2026).

**Compliance impact**: SOC 2 CC1.1, CC1.3, ISO 27001 A.6.1, NIST 800-53 PM-2.

### Phase 4 Checklist

```
[ ] SOC 2 Type I audit completed
[ ] SOC 2 Type II observation period begun
[ ] ISO 27001 assessment started (if needed for market)
[ ] Private bug bounty program launched
[ ] Bug bounty triage process functioning
[ ] SIEM deployed with minimum detection rule set
[ ] CloudTrail detections for critical AWS events active
[ ] Alert routing and escalation configured
[ ] Security hire job description written
[ ] First security engineer hired (or recruiting)
[ ] Vendor security assessment process established
[ ] Third-party risk management policy in place
[ ] Business continuity plan tested
[ ] Disaster recovery runbook tested
```

---

## <a id="phase-5"></a>6. Phase 5: Advanced Operations (Year 1+)

**Objective**: Mature from reactive to proactive security. Build detection engineering capability. Establish privacy as a program.

**Time Investment**: Ongoing, dedicated security team.
**Estimated Cost**: $10,000-50,000+/month (primarily headcount).

### 5.1 Red Team / Purple Team

**Internal red team prerequisites**:
- Functioning blue team (detection + response capability).
- SIEM with established detection coverage.
- Incident response process tested multiple times.
- Management buy-in and rules of engagement.

**Approach for startup-scale**:

| Option | Cost | Notes |
|--------|------|-------|
| Annual external red team engagement | $30,000-80,000 | Professional adversary simulation |
| Continuous red team retainer | $5,000-15,000/month | Ongoing, realistic attacks |
| Internal purple team exercises | Headcount cost | Uses ATT&CK framework for structured testing |
| Breach and Attack Simulation (BAS) | $1,000-5,000/month | Automated, continuous |

**OSS tools for purple team exercises**:

| Tool | Cost | Purpose |
|------|------|---------|
| **Atomic Red Team** | Free, OSS | ATT&CK-mapped test cases |
| **Caldera** (MITRE) | Free, OSS | Automated adversary emulation |
| **Stratus Red Team** | Free, OSS | Cloud-specific attack simulation |
| **Infection Monkey** | Free, OSS | Automated breach and attack simulation |
| **VECTR** | Free, OSS | Purple team tracking and reporting |

**Process**:

```
1. Select ATT&CK techniques relevant to your threat model
2. Execute technique (Atomic Red Team / Caldera)
3. Verify detection fired (or document gap)
4. If gap: write detection rule, deploy, re-test
5. Track coverage in ATT&CK Navigator
6. Report: % of relevant techniques with validated detection
```

**Compliance impact**: SOC 2 CC4.1, CC4.2, ISO 27001 A.18.2, NIST 800-53 CA-8, RA-5.

### 5.2 Mature Detection Engineering

**Detection-as-code workflow**:

```
detection rule (Sigma YAML)
    → CI/CD pipeline validates syntax + unit tests
    → converts to target format (Splunk SPL / Elastic KQL / Wazuh rules)
    → deploys to SIEM
    → automated testing validates rule fires on known-bad data
    → alert routing and playbook linked
```

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **Sigma** | Free, OSS | Vendor-agnostic detection rule format |
| **sigmac / pySigma** | Free, OSS | Sigma rule conversion |
| **Chainsaw** | Free, OSS | Fast Windows event log analysis |
| **MITRE ATT&CK Navigator** | Free | Visualize detection coverage |
| **Detection Lab** | Free, OSS | Pre-built lab for detection testing |

**Maturity levels**:

| Level | Description | Target |
|-------|-------------|--------|
| 1 | Ad-hoc alerts, vendor defaults | Phase 4 |
| 2 | Custom rules for known threats, Sigma adoption | Year 1 |
| 3 | Detection-as-code in CI/CD, unit tested | Year 1-2 |
| 4 | Threat-informed, ATT&CK-mapped, gap-tracked | Year 2+ |
| 5 | ML-augmented, adversary-adaptive, continuous validation | Year 3+ |

### 5.3 Security Architecture Review

**Formal architecture review process**:

1. **Trigger**: New service, new integration, major refactor, annual review.
2. **Input**: Architecture diagram, data flow diagram, threat model.
3. **Review board**: Security engineer + senior backend engineer + infrastructure engineer.
4. **Output**: Security architecture decision record (ADR) with:
   - Approved architecture
   - Required security controls
   - Accepted risks (with owner and review date)
   - Conditions that would trigger re-review

**Zero trust architecture principles** (formalize what you started in Phase 2):
- No implicit trust based on network location.
- Every request authenticated and authorized.
- Least privilege access, just-in-time where possible.
- Micro-segmentation of workloads.
- Continuous monitoring and validation.

**Tools**:

| Tool | Cost | Notes |
|------|------|-------|
| **Threagile** | Free, OSS | Architecture risk analysis as code |
| **OWASP SAMM** | Free | Security maturity model assessment |
| **AWS Well-Architected Tool** | Free | AWS-specific architecture review |

### 5.4 Privacy Program

**Why a formal program now**: GDPR, CCPA/CPRA, and emerging state privacy laws create regulatory obligations. Privacy is also a competitive differentiator.

**Privacy program components**:

| Component | Description | Tool/Resource |
|-----------|-------------|---------------|
| Data inventory | What personal data do you collect, process, store? | **OneTrust** (free tier), manual spreadsheet |
| Legal basis mapping | GDPR Art. 6 — why are you processing each data type? | Legal counsel |
| DPIA process | Data Protection Impact Assessment for high-risk processing | **CNIL DPIA tool** (free) |
| Privacy notices | Clear, accurate notices for users | Legal counsel |
| Data subject rights | Process for access, deletion, portability requests | Automated workflow |
| Vendor DPAs | Data Processing Agreements with all sub-processors | Legal templates |
| Breach notification | 72-hour process (GDPR Art. 33) | Part of IR plan |
| Privacy by Design | Privacy integrated into product development | Training + review process |
| Cookie consent | Compliant consent management | **Consent-O-Matic**, **Osano** |
| Retention schedules | Defined retention periods, automated deletion | Cron jobs + policy |

**Key regulations cheat sheet**:

| Regulation | Scope | Key Requirements |
|-----------|-------|-----------------|
| **GDPR** | EU/EEA data subjects | Lawful basis, DPO, DPIA, 72h breach notification, data subject rights |
| **CCPA/CPRA** | California residents | Right to know, delete, opt-out of sale, data minimization |
| **HIPAA** | US health data | BAAs, PHI safeguards, breach notification, risk analysis |
| **PCI DSS** | Payment card data | Network segmentation, encryption, access control, logging |
| **SOX** | US public companies | Financial data integrity, access controls, audit trails |

**Compliance impact**: GDPR (all articles), CCPA/CPRA, SOC 2 Privacy criteria, ISO 27701.

### Phase 5 Checklist

```
[ ] Annual red team engagement completed
[ ] Purple team exercises running quarterly
[ ] ATT&CK coverage tracked and improving
[ ] Detection-as-code pipeline operational
[ ] Sigma rules in version control with CI/CD
[ ] Security architecture review process formalized
[ ] Zero trust principles documented and enforced
[ ] Privacy program established with data inventory
[ ] DPIA process in place for new features
[ ] Data subject rights workflow automated
[ ] Cookie consent and privacy notices compliant
[ ] Security team grown to 2-3+ members
[ ] CISO/Head of Security hired
[ ] Security metrics dashboard operational
[ ] Board-level security reporting established
```

---

## <a id="budget-summary"></a>7. Budget Summary

### Total Estimated Costs by Phase

| Phase | Timeline | Monthly Cost | Key Expenses |
|-------|----------|-------------|--------------|
| Phase 1 | Day 1-30 | $0-200 | YubiKeys ($100/person), password manager ($4-8/user/mo) |
| Phase 2 | Month 1-3 | $100-500 | Tailscale/VPN ($6/user/mo), cyber insurance ($100-300/mo) |
| Phase 3 | Month 3-6 | $500-3,000 | Compliance platform ($500-1,250/mo), pen test ($5-15K one-time) |
| Phase 4 | Month 6-12 | $3,000-10,000 | SOC 2 audit ($15-50K), SIEM, bug bounty rewards, first security hire |
| Phase 5 | Year 1+ | $10,000-50,000+ | Security team (2-3 FTEs), red team engagement, privacy tooling |

### Year 1 Total Estimated Investment

| Company Size | Estimated Annual Security Spend |
|-------------|-------------------------------|
| 2-5 people (pre-seed) | $5,000-15,000 |
| 5-15 people (seed) | $20,000-60,000 |
| 15-50 people (Series A) | $80,000-250,000 |
| 50-100 people (Series B) | $300,000-800,000 |

**Rule of thumb**: Budget 5-10% of engineering spend on security. This decreases to 3-5% as you scale and achieve economies of scale.

---

## <a id="compliance-mapping"></a>8. Compliance Mapping Matrix

How each phase maps to major compliance frameworks:

| Control Area | Phase | SOC 2 | ISO 27001 | NIST CSF | CIS v8 | GDPR |
|-------------|-------|-------|-----------|----------|--------|------|
| MFA | 1 | CC6.1 | A.9.4.2 | PR.AC-7 | 6.3, 6.4 | Art. 32 |
| Secrets management | 1 | CC6.1, CC6.7 | A.10.1 | PR.DS-2 | 3.11 | Art. 32 |
| Logging | 1 | CC7.1, CC7.2 | A.12.4 | DE.AE-3 | 8.2 | Art. 30 |
| Dependency scanning | 1 | CC7.1 | A.12.6 | ID.RA-1 | 7.4, 16.4 | — |
| Encryption | 1 | CC6.1, CC6.7 | A.10.1, A.13.1 | PR.DS-1,2 | 3.6, 3.10 | Art. 32 |
| SAST | 2 | CC7.1, CC8.1 | A.14.2 | PR.IP-2 | 16.12 | — |
| Vuln scanning | 2 | CC7.1, CC4.1 | A.12.6 | DE.CM-8 | 7.1-7.7 | — |
| Access reviews | 2 | CC6.2, CC6.3 | A.9.2 | PR.AC-1 | 5.1-5.6 | Art. 5, 25 |
| IR plan | 2 | CC7.3-7.5 | A.16 | RS.RP-1 | 17.1-17.9 | Art. 33, 34 |
| Security headers | 2 | CC6.1 | A.14.1 | PR.DS-2 | 9.3 | — |
| SOC 2 compliance | 3-4 | All CC | — | — | — | — |
| Pen testing | 3 | CC4.1 | A.18.2 | DE.DP-3 | 18.1-18.5 | — |
| Security training | 3 | CC1.4, CC2.2 | A.7.2.2 | PR.AT-1 | 14.1-14.9 | Art. 39 |
| DLP | 3 | CC6.5, CC6.7 | A.8.2, A.13.2 | PR.DS-5 | 3.1-3.14 | Art. 5, 32 |
| Threat modeling | 3 | CC3.1, CC3.2 | A.14.2.5 | ID.RA-3 | 16.14 | Art. 25, 35 |
| SIEM | 4 | CC7.2, CC7.3 | A.12.4 | DE.AE-2 | 8.5-8.12 | Art. 32 |
| Bug bounty | 4 | CC4.1 | A.18.2.3 | DE.DP-3 | 18.3 | — |
| Red team | 5 | CC4.1, CC4.2 | A.18.2 | DE.DP-3 | 18.4 | — |
| Detection engineering | 5 | CC7.2 | A.12.4 | DE.AE-1-5 | 8.5-8.12 | — |
| Privacy program | 5 | Privacy criteria | A.18.1 | ID.GV-3 | — | All |

---

## <a id="tool-index"></a>9. Tool Reference Index

### Complete Tool List by Category

**Identity & Access**:
- Bitwarden (password manager, OSS, free self-host)
- Aegis / Ente Auth (TOTP authenticators, OSS)
- YubiKey 5 (hardware security key, ~$50)
- Tailscale / Headscale (zero-trust networking)
- Cloudflare Access (zero-trust proxy, free tier)
- PMapper (AWS IAM privilege escalation analysis, OSS)
- CloudTracker (IAM usage analysis, OSS)

**Secrets & Encryption**:
- gitleaks (pre-commit secret scanning, OSS)
- Infisical / Doppler (secrets management, free tiers)
- SOPS (encrypted files in git, OSS)
- age (file encryption, OSS)
- Let's Encrypt / certbot (TLS certificates, free)
- AWS KMS / GCP Cloud KMS (key management, usage-based)

**Code & Application Security**:
- Semgrep (SAST, OSS + paid rules)
- Bandit (Python SAST, OSS)
- CodeQL (deep SAST, free for public repos)
- OWASP ZAP (DAST, OSS)
- Nuclei (vulnerability scanner, OSS)
- Trivy (multi-purpose scanner, OSS)
- Grype (vulnerability scanner, OSS)
- OSV-Scanner (dependency scanner, OSS)

**Infrastructure & Cloud Security**:
- Prowler (cloud security posture, OSS)
- ScoutSuite (multi-cloud audit, OSS)
- Cloud Custodian (policy-as-code, OSS)
- Checkov (IaC scanning, OSS)
- AWS IAM Access Analyzer (free)

**Monitoring & Detection**:
- Wazuh (SIEM/XDR, OSS)
- Grafana + Loki (log aggregation, OSS)
- Matano (serverless SIEM, OSS)
- Sigma (detection rule format, OSS)
- OpenTelemetry (observability, OSS)
- Vector (log pipeline, OSS)

**Red/Purple Team**:
- Atomic Red Team (attack simulation, OSS)
- Caldera (adversary emulation, OSS)
- Stratus Red Team (cloud attacks, OSS)
- VECTR (purple team tracking, OSS)
- Gophish (phishing simulation, OSS)

**Compliance & GRC**:
- Vanta / Drata / Secureframe (compliance automation, paid)
- OWASP SAMM (maturity assessment, free)
- AWS Well-Architected Tool (architecture review, free)

**Threat Modeling**:
- OWASP Threat Dragon (OSS)
- Threagile (threat modeling as code, OSS)
- draw.io (DFDs, free)

---

## <a id="ir-starter"></a>10. Incident Response Starter Kit

### Communication Templates

**Internal notification** (Slack):

```
@here SECURITY INCIDENT — SEV-[1/2/3]

Summary: [One sentence description]
Impact: [What is affected]
Current status: [Investigating / Containing / Resolved]
Incident lead: [Name]
Next update: [Time]

DO NOT discuss this incident outside this channel.
DO NOT attempt to fix anything without coordinating here.
```

**Customer notification** (if data breach confirmed):

```
Subject: Security Notification — [Company Name]

We are writing to inform you of a security incident that may have
affected your data.

What happened: [Clear, factual description]
When it happened: [Timeline]
What data was involved: [Specific data types]
What we are doing: [Actions taken and planned]
What you can do: [Actionable steps for the customer]

We take this matter seriously and are committed to transparency.
For questions: [dedicated email/phone]
```

**Regulatory notification checklist**:

| Regulation | Deadline | Who to Notify | Threshold |
|-----------|----------|---------------|-----------|
| GDPR Art. 33 | 72 hours | Supervisory authority | Risk to rights and freedoms |
| GDPR Art. 34 | Without undue delay | Data subjects | High risk to rights and freedoms |
| CCPA | Most expedient time | Affected California residents | Unencrypted personal information |
| HIPAA | 60 days | HHS + affected individuals | Unsecured PHI, 500+ individuals |
| SEC (public co.) | 4 business days | SEC (Form 8-K) | Material cybersecurity incident |

### Evidence Preservation Order

When an incident is detected, preserve evidence in this order:

```
1. Volatile (disappears on reboot):
   - Memory dump (lime, avml for Linux; winpmem for Windows)
   - Running processes (ps aux, /proc)
   - Network connections (ss -tlnp, netstat)
   - Logged-in users (w, last)
   - Loaded kernel modules (lsmod)

2. Semi-volatile:
   - System logs (/var/log/*)
   - Application logs
   - Cloud API logs (CloudTrail — export immediately)
   - Container logs (docker logs, kubectl logs)

3. Non-volatile:
   - Disk image (dd, dc3dd)
   - File system timeline (plaso/log2timeline)
   - Git history (git log, git reflog)
   - Configuration files
   - Cloud resource configurations (AWS Config snapshots)
```

---

## <a id="threat-model"></a>11. Threat Model Template

### Starter Threat Model for SaaS Applications

```
┌─────────────────────────────────────────────────────────┐
│                    INTERNET                              │
│                   (Untrusted)                            │
└──────────┬──────────────────────┬───────────────────────┘
           │                      │
     ┌─────▼──────┐        ┌─────▼──────┐
     │   CDN/WAF  │        │  API GW /  │
     │ (Cloudflare│        │  Load Bal  │
     │  / AWS CF) │        │            │
     └─────┬──────┘        └─────┬──────┘
           │                      │
┌──────────▼──────────────────────▼───────────────────────┐
│              TRUST BOUNDARY: DMZ / Public Subnet         │
├─────────────────────────────────────────────────────────┤
│                                                          │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐         │
│   │ Web App  │    │   API    │    │  Worker  │         │
│   │ (React)  │    │ (Python) │    │ (Celery) │         │
│   └────┬─────┘    └────┬─────┘    └────┬─────┘         │
│        │               │               │                │
├────────▼───────────────▼───────────────▼────────────────┤
│              TRUST BOUNDARY: Private Subnet              │
├─────────────────────────────────────────────────────────┤
│                                                          │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐         │
│   │ Database │    │  Cache   │    │  Queue   │         │
│   │ (Postgres│    │ (Redis)  │    │ (SQS/    │         │
│   │  / RDS)  │    │          │    │  RabbitMQ│         │
│   └──────────┘    └──────────┘    └──────────┘         │
│                                                          │
└─────────────────────────────────────────────────────────┘
           │
┌──────────▼──────────────────────────────────────────────┐
│         TRUST BOUNDARY: Management / Security            │
│                                                          │
│   ┌──────────┐    ┌──────────┐    ┌──────────┐         │
│   │  CI/CD   │    │   SIEM   │    │ Secrets  │         │
│   │(Actions) │    │ (Wazuh)  │    │  Mgr     │         │
│   └──────────┘    └──────────┘    └──────────┘         │
└─────────────────────────────────────────────────────────┘
```

### STRIDE Analysis (Example)

| Component | Threat | STRIDE | DREAD Score | Mitigation |
|-----------|--------|--------|-------------|------------|
| API Gateway | Unauthenticated access | Spoofing | D:3 R:3 E:2 A:3 D:3 = 14 | JWT validation, rate limiting |
| API Gateway | Request smuggling | Tampering | D:3 R:2 E:2 A:3 D:2 = 12 | WAF rules, HTTP/2 |
| Database | SQL injection | Tampering, Info Disclosure | D:4 R:3 E:2 A:4 D:3 = 16 | Parameterized queries, ORM |
| Database | Unauthorized cross-tenant access | Elev. of Privilege | D:4 R:3 E:2 A:4 D:2 = 15 | Row-level security, tenant isolation |
| Redis | Credential-less access from app subnet | Info Disclosure | D:3 R:4 E:3 A:3 D:2 = 15 | AUTH required, TLS, network isolation |
| CI/CD | Pipeline poisoning | Tampering | D:4 R:2 E:2 A:4 D:2 = 14 | Branch protection, signed commits |
| Worker | Deserialization attacks | Elev. of Privilege | D:3 R:2 E:2 A:3 D:2 = 12 | Safe deserialization, input validation |
| All | DDoS | Denial of Service | D:2 R:4 E:4 A:4 D:4 = 18 | CDN, rate limiting, auto-scaling |
| Logs | Missing audit trail | Repudiation | D:2 R:3 E:3 A:3 D:3 = 14 | Immutable log storage, log integrity |

---

## <a id="mistakes"></a>12. Common Mistakes That Kill Startups

### Security Anti-Patterns

| Mistake | Why It Hurts | What To Do Instead |
|---------|-------------|-------------------|
| "We will add security later" | Technical debt compounds. Retrofitting costs 10-100x more than building in. | Start Phase 1 on Day 1. No exceptions. |
| Shared root/admin credentials | Single point of compromise. No audit trail. No revocation. | Individual accounts, MFA, least privilege. |
| Secrets in git history | Bots scan GitHub in real-time. Your AWS keys will be compromised within minutes. | Pre-commit hooks, secrets manager, git history audit. |
| No logging | When (not if) you are breached, you cannot investigate, scope, or report. | CloudTrail + application logs from Day 1. |
| "Our data is not valuable" | Attackers want compute (crypto mining), access (supply chain), or ransom. All data has value. | Assume breach. Encrypt. Monitor. |
| Security theater compliance | Buying a compliance platform and ignoring the findings creates liability, not security. | Compliance is a floor, not a ceiling. Fix the findings. |
| Punishing security reporters | Employees stop reporting. Vulnerabilities fester. Culture degrades. | Blameless post-mortems. Reward reporting. |
| Rolling your own crypto/auth | You are not a cryptographer. Neither am I. Use battle-tested libraries. | bcrypt/argon2 for passwords. libsodium for crypto. OAuth for auth. |
| Ignoring supply chain | Your dependencies are your attack surface. xz-utils proved this. | Dependency scanning, lockfiles, SCA in CI. |
| No backup testing | Backups that have never been restored are Schrodinger's backups. | Quarterly restore tests. Document the procedure. |
| Production database in dev | One developer laptop theft = full data breach. | Synthetic data for dev. Production access requires justification and logging. |
| Flat network trust | "It is on our internal network" is not a security control. | Zero trust. Authenticate everything. Segment everything. |

### The "Enterprise Sales Wall"

At some point, your sales team will come to engineering with an urgent request: "Customer X needs SOC 2 before they sign. The deal is $500K ARR. They need it in 30 days."

If you followed this guide, you respond: "We started SOC 2 prep at Month 3. Our Type I report is ready, and we are in our Type II observation period. Here is the report."

If you did not follow this guide, you respond: "We need 6-12 months and $100K+ in emergency consulting to get there." The deal dies.

**Security is a revenue enabler when built in from the start. It is an existential blocker when retrofitted.**

---

## Appendix A: Recommended Reading

| Resource | Type | Why |
|----------|------|-----|
| CISA Cyber Essentials | Framework | Foundational structure for any organization |
| Forter Security 101 for SaaS Startups | Guide | Phased, practical, startup-specific |
| OWASP Secure Product Design Cheat Sheet | Reference | Design-level security principles |
| NIST Cybersecurity Framework | Framework | Comprehensive, maps to everything |
| CIS Controls v8 | Controls list | Prioritized, actionable security controls |
| Verizon DBIR (annual) | Report | Data-driven threat landscape |
| OWASP Top 10 | Reference | Web application vulnerability categories |
| AWS Well-Architected Security Pillar | Guide | Cloud-specific architecture guidance |

## Appendix B: 90-Day Quick-Start for the Impatient Founder

If you read nothing else, do these 15 things in your first 90 days:

```
WEEK 1:
  1. MFA on everything (cloud, email, GitHub, registrar)
  2. Password manager for the team
  3. Full-disk encryption on all devices
  4. .env files in .gitignore, gitleaks pre-commit hook

WEEK 2-4:
  5. CloudTrail enabled in all regions, logs shipped to separate account
  6. Secrets manager adopted (Infisical or Doppler)
  7. TLS everywhere, HSTS header deployed
  8. Dependabot enabled on all repositories
  9. Default encryption on all storage (S3, RDS, EBS)

MONTH 2:
  10. Semgrep in CI/CD (blocks high-severity findings)
  11. Prowler running weekly against cloud accounts
  12. Incident response one-pager written and distributed
  13. Quarterly access review calendared

MONTH 3:
  14. SOC 2 compliance platform selected, configuration started
  15. First penetration test scheduled
```

**Total cost for the 90-day quick-start: under $1,000.**
**Total time investment: ~60-80 hours across the founding team.**
**Sales impact: you can now answer security questionnaires with confidence.**

---

*This guide is a living document. Security is not a destination — it is a practice. Review and update quarterly as your company grows, your threat model evolves, and the landscape shifts.*

*Built by CIPHER. Designed for builders who take security seriously from day one.*
