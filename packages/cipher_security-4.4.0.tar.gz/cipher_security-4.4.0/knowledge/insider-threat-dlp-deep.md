<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Insider Threat, DLP & User Behavior Analytics — Deep Training Module

> CIPHER Training Document | `[MODE: BLUE]` + `[MODE: PURPLE]` overlay
> Last updated: 2026-03-14
> Sources: CISA, MITRE ATT&CK, CERT/SEI, OWASP, NIST, Netflix Security Monkey, Duo Labs CloudTracker

---

## Table of Contents

1. [Insider Threat Taxonomy](#1-insider-threat-taxonomy)
2. [Insider Threat Indicators](#2-insider-threat-indicators)
3. [Data Classification Framework](#3-data-classification-framework)
4. [Data Loss Prevention Architecture](#4-data-loss-prevention-architecture)
5. [Exfiltration Techniques & Detection (ATT&CK)](#5-exfiltration-techniques--detection-attck)
6. [User & Entity Behavior Analytics (UEBA)](#6-user--entity-behavior-analytics-ueba)
7. [Privileged Access Management](#7-privileged-access-management)
8. [Least Privilege Implementation](#8-least-privilege-implementation)
9. [Monitoring Strategies for Privileged Users](#9-monitoring-strategies-for-privileged-users)
10. [Insider Threat Program Development](#10-insider-threat-program-development)
11. [Cloud-Specific Insider Threat Detection](#11-cloud-specific-insider-threat-detection)
12. [Abuse Case Modeling](#12-abuse-case-modeling)
13. [Detection Engineering Playbooks](#13-detection-engineering-playbooks)

---

## 1. Insider Threat Taxonomy

### Definition (CISA)

An insider is **any person who has or had authorized access to or knowledge of an organization's resources**. The insider threat is the potential for that person to use their authorized access — wittingly or unwittingly — to harm the organization.

### Threat Actor Categories

| Category | Description | Motivation | Example |
|----------|-------------|------------|---------|
| **Malicious Insider** | Intentionally harmful, pre-meditated | Financial gain, revenge, ideology, espionage | Employee selling trade secrets |
| **Negligent Insider** | Careless or untrained, no malicious intent | Convenience, ignorance | Emailing sensitive data to personal account |
| **Compromised Insider** | Credentials or endpoint hijacked by external actor | N/A (external motive) | Phished admin whose creds are used for lateral movement |
| **Departing Insider** | Employee in notice period or recently terminated | Self-interest, competitive advantage | Downloading client lists before exit |
| **Colluding Insider** | Works with external threat actor | Financial, coercion | Employee providing VPN creds to ransomware affiliate |

### CERT/SEI Insider Threat Patterns (Common Sense Guide, 7th Edition)

The SEI identifies these primary insider threat patterns based on 20+ years of case data:

1. **IT Sabotage** — Deliberate destruction of systems/data (typically sysadmins, post-termination)
2. **Theft of Intellectual Property** — Exfiltration of trade secrets, source code, designs
3. **Fraud** — Unauthorized modification of data for financial gain
4. **Espionage** — State-sponsored or competitive intelligence collection
5. **Unintentional Insider Threat** — Accidental exposure through negligence

---

## 2. Insider Threat Indicators

### 2.1 Behavioral Indicators

**[CONFIRMED]** — Derived from CISA Insider Threat Mitigation Guide and CERT/SEI case studies.

#### Pre-Attack Behavioral Signals

| Indicator | Risk Level | Detection Method |
|-----------|------------|------------------|
| Expressed disgruntlement or grievances about employer | Medium | HR reporting, peer observation |
| Sudden interest in projects outside job scope | Medium | Manager reporting, access logs |
| Unexplained affluence or financial distress | High | Background check updates, peer reporting |
| Resistance to policy changes, especially monitoring | Medium | HR, management observation |
| Working unusual hours without business justification | Medium | Badge access logs, VPN logs |
| Decline in work performance preceding access anomalies | High | HR metrics correlated with SIEM data |
| Social withdrawal from colleagues | Low | Peer reporting (cultural sensitivity required) |
| Discussing resignation while increasing data access | Critical | HR pipeline + DLP correlation |
| Foreign travel to countries with active intelligence programs | Medium | Travel system integration |
| Attempts to bypass physical security controls | High | Badge logs, security camera review |

#### Psychological Risk Factors (CISA Framework)

Assess whether individual possesses:
- **Interest** — Has the person expressed intent or curiosity about harmful actions?
- **Motive** — Financial pressure, ideology, revenge, coercion?
- **Capability** — Access level, technical skill, knowledge of security controls?

### 2.2 Technical Indicators

#### Data Access & Movement

| Indicator | ATT&CK Reference | Detection Source |
|-----------|-------------------|------------------|
| Bulk download of files outside normal role | T1005 (Data from Local System) | DLP, CASB, file access auditing |
| Access to sensitive repositories after resignation notice | T1213 (Data from Information Repositories) | SIEM + HR system correlation |
| Use of personal cloud storage (Dropbox, Google Drive, Mega) | T1567.002 (Exfil to Cloud Storage) | Web proxy, CASB, DNS logs |
| Email forwarding rules to external addresses | T1114.003 (Email Forwarding Rule) | Exchange/M365 audit logs |
| USB device insertion on sensitive systems | T1052.001 (Exfil over USB) | Endpoint agent, device control |
| Large archive creation (zip, tar, 7z) before transfer | T1560 (Archive Collected Data) | Endpoint telemetry, file integrity monitoring |
| Accessing systems at unusual times | T1078 (Valid Accounts) | Authentication logs, UEBA baseline |
| Printing sensitive documents in volume | — | Print server logs |
| Screen capture or photography of screens | T1113 (Screen Capture) | Endpoint agent (limited), physical security |
| Use of encrypted containers (VeraCrypt, BitLocker-to-Go) | T1027 (Obfuscated Files) | Endpoint agent, DLP |
| DNS tunneling or covert channel usage | T1048.003 (Exfil over Unencrypted Non-C2) | DNS query analysis, network IDS |

#### Privilege & Account Anomalies

| Indicator | ATT&CK Reference | Detection Source |
|-----------|-------------------|------------------|
| Self-provisioning of elevated permissions | T1098 (Account Manipulation) | IAM audit logs, PAM |
| Creation of unauthorized service accounts | T1136 (Create Account) | AD/IdP audit logs |
| Modification of audit/logging configurations | T1562 (Impair Defenses) | SIEM integrity monitoring |
| Access to production systems by non-operations staff | T1078 (Valid Accounts) | RBAC violation alerts |
| Sharing credentials or API keys via chat/email | T1552 (Unsecured Credentials) | DLP content inspection |
| MFA bypass or disable attempts | T1556 (Modify Authentication Process) | IdP audit logs |
| Use of another user's credentials | T1078.001 (Default Accounts) | Impossible travel, device fingerprinting |

### 2.3 Organizational Indicators

| Indicator | Context |
|-----------|---------|
| Recent termination, demotion, or negative review | Revenge/financial motive |
| Merger/acquisition creating role uncertainty | Self-preservation motive |
| Contractor with excessive access and minimal oversight | Opportunity without accountability |
| Departing employee with no offboarding process | Access persistence risk |
| Team with no separation of duties | Fraud enablement |
| Culture of credential sharing | Attribution difficulty |
| Lack of data ownership assignments | No one monitoring access patterns |
| Minimal security awareness training | Negligent insider risk amplification |

---

## 3. Data Classification Framework

### Classification Levels

| Level | Label | Description | Examples | Controls Required |
|-------|-------|-------------|----------|-------------------|
| L4 | **Restricted** | Catastrophic impact if disclosed | Crypto keys, auth secrets, PII bulk datasets, M&A plans | Encryption at rest + transit, need-to-know ACLs, DLP block, audit every access |
| L3 | **Confidential** | Significant business harm | Source code, financial reports, customer data, HR records | Encryption, RBAC, DLP alert, periodic access review |
| L2 | **Internal** | Minor harm, not for public | Internal wikis, architecture docs, meeting notes | Authentication required, DLP monitor, basic logging |
| L1 | **Public** | No harm if disclosed | Marketing content, public docs, open-source code | Integrity controls only |

### Data Classification Lifecycle

```
Discovery → Classification → Labeling → Protection → Monitoring → Disposal
    |             |               |            |            |           |
  Scan for      Apply level    Embed in     Enforce      Track       Secure
  sensitive     per policy     metadata/    DLP rules    access &    deletion
  data stores                  headers                   movement    per policy
```

### Implementation Requirements

1. **Automated discovery**: Deploy data scanners (structured + unstructured) across endpoints, file shares, cloud storage, databases, SaaS apps
2. **Classification engine**: Regex patterns (SSN, credit card, API keys), ML classifiers (NLP for context-aware detection), fingerprinting (exact data match for known sensitive documents)
3. **Persistent labeling**: Microsoft Information Protection labels, custom metadata headers, database column tags
4. **Policy binding**: Each classification level maps to specific DLP policies, access controls, retention rules, and encryption requirements

---

## 4. Data Loss Prevention Architecture

### 4.1 DLP Component Architecture

```
                    ┌─────────────────────────────┐
                    │      DLP Policy Engine       │
                    │  (Classification + Rules)    │
                    └──────────┬──────────────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
     ┌────────▼──────┐ ┌──────▼───────┐ ┌──────▼───────┐
     │  Endpoint DLP  │ │  Network DLP  │ │   Cloud DLP   │
     │  (Agent-based) │ │  (Inline/TAP) │ │  (API/CASB)   │
     └────────┬──────┘ └──────┬───────┘ └──────┬───────┘
              │                │                │
     ┌────────▼──────┐ ┌──────▼───────┐ ┌──────▼───────┐
     │ - Clipboard    │ │ - Email GW    │ │ - SaaS apps   │
     │ - USB/removable│ │ - Web proxy   │ │ - Cloud store  │
     │ - Print        │ │ - SMTP relay  │ │ - IaaS APIs    │
     │ - Screen cap   │ │ - DNS inspect │ │ - Code repos   │
     │ - File ops     │ │ - SSL/TLS MitM│ │ - Collab tools │
     └───────────────┘ └──────────────┘ └──────────────┘
              │                │                │
              └────────────────┼────────────────┘
                               │
                    ┌──────────▼──────────────────┐
                    │     SIEM / SOAR / UEBA       │
                    │   (Correlation & Response)    │
                    └─────────────────────────────┘
```

### 4.2 DLP Enforcement Modes

| Mode | Action | Use Case |
|------|--------|----------|
| **Monitor** | Log and alert, no block | Initial deployment, baseline building, L2 data |
| **Warn** | User notification with override option (logged) | L2-L3 data, culture-sensitive environments |
| **Block** | Prevent action, notify user and SOC | L3-L4 data, known exfiltration channels |
| **Quarantine** | Isolate content for review before release | Email attachments, file uploads to external |
| **Encrypt** | Auto-encrypt before allowing transfer | Approved external sharing with classification |

### 4.3 DLP Detection Methods

| Method | Description | Strengths | Weaknesses |
|--------|-------------|-----------|------------|
| **Regex/Pattern** | Match known patterns (SSN, CC#, API keys) | Fast, low FP for structured data | Misses context, easy to evade with encoding |
| **Keyword/Dictionary** | Match terms from classification dictionaries | Simple to deploy | High false positive rate |
| **Exact Data Match (EDM)** | Hash fingerprints of known sensitive records | Very low FP, catches exact matches | Requires source data, no partial matches |
| **Document Fingerprint** | Structural fingerprint of sensitive document templates | Catches derivatives/copies | Template changes require re-fingerprinting |
| **ML/NLP Classification** | Trained models classify content contextually | Catches novel sensitive content | Requires training data, potential for FN |
| **Optical Character Recognition** | Extract text from images/screenshots for inspection | Catches image-based exfiltration | Processing overhead, accuracy varies |

### 4.4 DLP Evasion Techniques (Purple Team Consideration)

Defenders must account for these bypass methods:

| Evasion | Technique | Countermeasure |
|---------|-----------|----------------|
| Encoding | Base64, ROT13, hex encoding of content | Decode-before-inspect in DLP pipeline |
| Steganography | Hide data in images, audio, video files | Stego detection tools, file size anomaly detection |
| Encryption | Password-protected archives, PGP | Block encrypted archives to external, inspect before encryption |
| Chunking | Split data across multiple small transfers | Session-aware DLP with reassembly |
| Channel switching | Use approved app (Teams) to share link to unapproved storage | CASB + URL categorization |
| Reclassification | Downgrade document classification label | Enforce label-change audit + approval workflow |
| Physical channel | Phone camera, handwritten notes | Physical security, clean desk policy (limited technical control) |
| Covert channels | DNS tunneling, ICMP exfil, protocol abuse | Network anomaly detection, DNS query analysis |
| Slow exfil | Small amounts over long periods under threshold | UEBA baseline deviation, cumulative volume tracking |

---

## 5. Exfiltration Techniques & Detection (ATT&CK)

### 5.1 T1567 — Exfiltration Over Web Service

**Platforms**: ESXi, Linux, macOS, Windows, SaaS, Office Suite

#### Sub-Techniques

| ID | Technique | Common Tools/Services |
|----|-----------|----------------------|
| T1567.001 | Exfiltration to Code Repository | GitHub, GitLab, Bitbucket private repos |
| T1567.002 | Exfiltration to Cloud Storage | Google Drive, Dropbox, OneDrive, Box, Mega.co.nz |
| T1567.003 | Exfiltration to Text Storage Sites | Pastebin, paste.ee, Ghostbin |
| T1567.004 | Exfiltration Over Webhook | Slack webhooks, Discord webhooks, Telegram Bot API |

#### Known Procedure Examples

- **APT28**: Google Drive exfiltration
- **APT41**: Cloudflare-tunneled exfiltration
- **BlackByte**: anonymfiles.com, file.io
- **InvisibleFerret**: Telegram Bot API with bot tokens
- **Exbyte**: Mega.co.nz uploads

#### Detection Analytics

| # | Detection Focus | Key Signals |
|---|----------------|-------------|
| 1 | Process anomalies | Non-networking apps initiating HTTPS POST with high outbound-to-inbound ratio |
| 2 | File archival patterns | tar/curl/Python accessing large datasets followed by encrypted uploads |
| 3 | Office app behavior | File writes + xattr manipulation + TLS uploads from Word/Excel |
| 4 | Account activity | Elevated frequency of Upload/Create/Copy in unified audit logs |
| 5 | ESXi monitoring | vmx/hostd processes making unexpected external HTTPS connections |

#### Mitigations

- **M1057** — Data Loss Prevention: detect/block uploads via web browsers
- **M1021** — Restrict Web-Based Content: web proxies enforcing communication policies

### 5.2 T1048 — Exfiltration Over Alternative Protocol

#### Sub-Techniques

| ID | Technique | Protocols |
|----|-----------|-----------|
| T1048.001 | Symmetric Encrypted Non-C2 Protocol | Custom encrypted FTP, encrypted DNS |
| T1048.002 | Asymmetric Encrypted Non-C2 Protocol | HTTPS to non-C2 host, SSH/SCP |
| T1048.003 | Unencrypted Non-C2 Protocol | FTP, SMTP, DNS, SMB, HTTP |

#### Notable Procedure Examples

- **FrameworkPOS**: DNS tunneling for credit card exfiltration
- **Play Ransomware**: WinSCP for bulk data theft
- **TeamTNT**: cURL to exfil credentials to C2
- **AADInternals**: Cloud API downloads (OneDrive, SharePoint)

#### Detection Analytics

| # | Focus |
|---|-------|
| AN0367 | Unusual outbound file transfers via FTP, SMB, SMTP, DNS with non-standard processes |
| AN0368 | curl, scp, custom binaries over alternative protocols outside baseline |
| AN0369 | Non-native file transfers via Python/AppleScript using uncommon protocols |
| AN0370 | Cloud API/CLI access for file movement from sensitive buckets externally |
| AN0371 | Unauthorized protocols (FTP, HTTP POST, DNS tunnels) from ESXi/VM interfaces |

#### Mitigations (6 controls)

| ID | Strategy |
|----|----------|
| M1057 | Data Loss Prevention |
| M1037 | Filter Network Traffic (IP allowlisting, dedicated DNS) |
| M1031 | Network Intrusion Prevention (signature-based) |
| M1030 | Network Segmentation (firewall port restrictions) |
| M1022 | Restrict File Permissions (ACLs on cloud storage) |
| M1018 | User Account Management (temporary tokens, IAM controls) |

### 5.3 T1052 — Exfiltration Over Physical Medium

#### Sub-Techniques

- **T1052.001**: Exfiltration over USB (external drives, phones, MP3 players)

#### Detection Analytics

| # | Focus |
|---|-------|
| AN0342 | Removable drive insertion + suspicious file access, compression, or staging |
| AN0343 | External device mount (/media, /mnt) + unusual file ops via shell scripts |
| AN0344 | External volume mount correlated with sensitive file access patterns |

#### Mitigations

| ID | Strategy |
|----|----------|
| M1057 | Data Loss Prevention |
| M1042 | Disable Features (Autorun, restrict removable media policy) |
| M1034 | Hardware Limitation (restrict USB device usage network-wide) |

---

## 6. User & Entity Behavior Analytics (UEBA)

### 6.1 UEBA Architecture

```
Data Sources                    Analytics Engine               Output
─────────────                   ─────────────────              ──────
                               ┌───────────────────┐
Auth logs ──────────┐          │                   │
Endpoint telemetry ─┤          │   Baseline Model  │     ┌──────────────┐
Network flows ──────┤──────►   │   (per user/entity)│────►│ Risk Score   │
DLP events ─────────┤          │                   │     │ (0-100)      │
Cloud audit logs ───┤          │   Anomaly Detection│     └──────┬───────┘
HR system feeds ────┤          │   (statistical +   │            │
Badge access logs ──┤          │    ML models)      │     ┌──────▼───────┐
Email metadata ─────┘          │                   │     │ Alert Triage │
                               └───────────────────┘     │ + Case Mgmt  │
                                                         └──────────────┘
```

### 6.2 Behavioral Baselines

UEBA systems build per-user and per-entity baselines across these dimensions:

| Dimension | Baseline Attributes | Anomaly Example |
|-----------|--------------------|--------------------|
| **Temporal** | Usual login hours, session duration | Login at 3 AM on weekend with no precedent |
| **Volumetric** | Normal data access/download volume per day/week | 10x normal file downloads in 24 hours |
| **Spatial** | Typical source IPs, geolocations, devices | VPN from country user has never accessed from |
| **Resource** | Normal systems/repos/databases accessed | Developer accessing HR payroll database |
| **Network** | Typical destinations, protocols, transfer sizes | Large outbound transfer to new external IP |
| **Privilege** | Normal permission usage patterns | Using admin privileges never exercised before |
| **Social** | Typical communication patterns, recipients | Email to competitor domain with attachments |

### 6.3 Detection Models

#### Statistical Models

| Model | Application |
|-------|-------------|
| **Z-score / Standard Deviation** | Flag events N standard deviations from user mean (e.g., download volume) |
| **Moving Average** | Smooth temporal patterns, detect sustained deviations vs. spikes |
| **Peer Group Analysis** | Compare user behavior to role-matched peer group; flag outliers |
| **Markov Chain** | Model state transitions (e.g., login → file access → email); flag unlikely sequences |
| **Time Series Decomposition** | Separate trend, seasonal, residual components; alert on residual anomalies |

#### Machine Learning Models

| Model | Application | Strengths |
|-------|-------------|-----------|
| **Isolation Forest** | Unsupervised anomaly detection on multi-dimensional user feature vectors | No labeled data required, handles high dimensionality |
| **Autoencoder (Neural Net)** | Learn compressed representation of normal behavior; high reconstruction error = anomaly | Captures complex nonlinear patterns |
| **LSTM / Sequence Models** | Model temporal sequences of user actions; detect novel action sequences | Strong at sequence anomalies |
| **Clustering (DBSCAN, k-means)** | Group similar behavior profiles; flag users who shift clusters | Identifies role-drift and behavioral changes |
| **Random Forest (Supervised)** | Classify user sessions as normal/anomalous given labeled incident data | High accuracy when labeled data available |

#### Composite Risk Scoring

```
Risk Score = Σ (indicator_weight × anomaly_magnitude × context_multiplier)

Context multipliers:
  - User on departure list:          ×3.0
  - User has privileged access:      ×2.0
  - User recently denied promotion:  ×1.5
  - User accessing after hours:      ×1.3
  - First-time access to resource:   ×1.5
  - Cumulative volume above p95:     ×2.0
```

### 6.4 Entity Behavior (Non-User)

UEBA extends beyond users to entities:

| Entity Type | Behavioral Baseline | Anomaly Signal |
|-------------|--------------------|--------------------|
| Service accounts | Static access patterns, predictable schedules | Interactive login, new destination, off-schedule activity |
| API keys | Consistent calling patterns, source IPs | New source IP, burst requests, new API endpoints |
| Endpoints/hosts | Normal process trees, network connections | New outbound connections, new services, process injection |
| Cloud resources | Expected configuration state | Config change outside change window, new IAM binding |

### 6.5 UEBA Data Source Requirements

| Data Source | Key Fields | Insider Threat Value |
|-------------|------------|---------------------|
| **Active Directory / IdP** | Authentication events, group changes, password resets | Account manipulation, privilege escalation |
| **VPN / Network Access** | Source IP, geo, duration, bytes transferred | Unusual access patterns, impossible travel |
| **Email Gateway** | Sender, recipient, attachment metadata, DLP tags | Data exfiltration, communication with competitors |
| **Endpoint Agent** | Process execution, file operations, USB events | Local staging, archive creation, removable media |
| **Cloud Audit Logs** | API calls, IAM changes, resource access | Cloud exfiltration, privilege abuse |
| **Web Proxy / CASB** | URL categories, upload volume, cloud app usage | Shadow IT, cloud storage exfil |
| **HR System (API feed)** | Resignation date, PIP status, role changes | Context enrichment for risk scoring |
| **Badge / Physical Access** | Entry/exit times, unusual areas accessed | After-hours access, restricted area entry |
| **DLP Platform** | Policy violations, content matches, user overrides | Direct exfiltration attempts |
| **Print Server** | Document names, page counts, user, printer location | Bulk printing of sensitive documents |

---

## 7. Privileged Access Management

### 7.1 PAM Architecture

```
                ┌─────────────────────────┐
                │   PAM Policy Engine     │
                │  (Who, What, When, How) │
                └────────┬────────────────┘
                         │
            ┌────────────┼────────────────┐
            │            │                │
   ┌────────▼──────┐ ┌──▼────────────┐ ┌─▼──────────────┐
   │  Credential    │ │  Session       │ │  Just-in-Time   │
   │  Vault         │ │  Management    │ │  Access          │
   │                │ │                │ │                  │
   │ - Password     │ │ - Session      │ │ - Request/       │
   │   rotation     │ │   recording    │ │   approve flow   │
   │ - SSH key mgmt │ │ - Keystroke    │ │ - Time-bound     │
   │ - API secret   │ │   logging      │ │   elevation      │
   │   management   │ │ - Command      │ │ - Auto-revoke    │
   │ - Check-out/   │ │   filtering    │ │ - Break-glass    │
   │   check-in     │ │ - Live monitor │ │   procedures     │
   └───────────────┘ └───────────────┘ └─────────────────┘
```

### 7.2 Privileged Account Types

| Account Type | Risk Profile | PAM Requirements |
|-------------|-------------|------------------|
| Domain Admin | Critical — full domain control | Dedicated workstation, session recording, dual-approval, time-limited |
| Cloud Admin (root/Owner) | Critical — full cloud account control | MFA hardware token, break-glass only, separate identity |
| Database Admin | High — access to all data at rest | Query logging, row-level access controls, credential vaulting |
| Service Account (privileged) | High — often over-provisioned, no MFA | Managed credentials, API-only access, no interactive login |
| DevOps / CI-CD | High — code deployment, infrastructure changes | Pipeline-scoped secrets, no persistent credentials, audit trail |
| Network Admin | High — infrastructure control | Session recording, change management integration |
| Security Admin | Critical — can disable controls | Separation of duties, peer review for changes |

### 7.3 PAM Best Practices for Insider Threat Mitigation

1. **Zero standing privileges**: No persistent admin access; all elevation is just-in-time, time-bounded, and approval-gated
2. **Credential vaulting**: All privileged credentials stored in vault; users never know actual passwords
3. **Session recording**: All privileged sessions recorded with keystroke logging and video capture
4. **Command filtering**: Allowlist/denylist specific commands in privileged sessions (e.g., block `rm -rf /`, `DROP DATABASE`)
5. **Break-glass procedures**: Documented, audited emergency access with mandatory post-incident review
6. **Separation of duties**: No single user can provision access AND use that access
7. **Service account governance**: Inventory all service accounts, assign owners, rotate credentials, monitor for interactive use
8. **Dual authorization**: Critical operations require two privileged users to approve/execute

---

## 8. Least Privilege Implementation

### 8.1 Core Principles (OWASP Authorization Cheat Sheet)

| Principle | Implementation |
|-----------|----------------|
| **Deny by default** | All access denied unless explicitly granted; never assume neutral |
| **Validate every request** | Permission check on every API call/page load via middleware, not per-method |
| **Minimum necessary permissions** | Grant only what is required for current role, reviewed quarterly |
| **Time-bound access** | Elevated permissions expire automatically; renewal requires re-justification |
| **Server-side enforcement** | Authorization logic executes server-side or at gateway; never trust client |

### 8.2 Access Control Models

| Model | Description | Best For | Insider Threat Relevance |
|-------|-------------|----------|--------------------------|
| **RBAC** | Permissions assigned to roles, users assigned to roles | Simple hierarchical organizations | Risk of role explosion and privilege creep |
| **ABAC** | Policy evaluates subject attributes, resource attributes, environment, action | Complex organizations, fine-grained control | Better least-privilege enforcement, context-aware |
| **ReBAC** | Access based on relationships between entities | Social platforms, document sharing | Natural for data-owner-controlled access |
| **PBAC** | Policy-based, combining RBAC + ABAC with policy engine (OPA, Cedar) | Modern cloud-native systems | Auditable, version-controlled, testable policies |

### 8.3 Least Privilege Implementation Checklist

```
[ ] Inventory all user accounts and their current permissions
[ ] Map permissions to job functions (role mining)
[ ] Identify and remediate over-provisioned accounts (CloudTracker pattern)
[ ] Implement ABAC/PBAC for fine-grained authorization
[ ] Deploy JIT access for privileged operations
[ ] Automate access reviews (quarterly for standard, monthly for privileged)
[ ] Integrate HR system for automatic de-provisioning on termination
[ ] Monitor for privilege creep (permissions granted but never used)
[ ] Implement separation of duties for critical operations
[ ] Test authorization logic with unit/integration tests
[ ] Log all authorization decisions (grants and denials)
[ ] Protect object identifiers from manipulation (CWE-639 prevention)
```

### 8.4 Cloud IAM Least Privilege (CloudTracker Model)

CloudTracker's approach: compare CloudTrail logs against IAM policies to identify overprivilege.

**Permission Status Indicators**:
- No symbol: Permission used (appropriate — keep)
- `-` Minus: Permission granted but unused (removal candidate)
- `?` Question: Permission granted, usage unknown (CloudTrail gap — investigate)
- `+` Plus: Permission used despite lacking grant (previously revoked — investigate)

**Key Limitations**: CloudTrail does not record data-plane events (S3 object reads/writes), so absence of logged activity does not guarantee inactivity. Supplement with S3 access logging and VPC flow logs.

---

## 9. Monitoring Strategies for Privileged Users

### 9.1 Monitoring Architecture

| Layer | What to Monitor | Tools/Sources |
|-------|----------------|---------------|
| **Identity** | Auth events, MFA status, token issuance, role assumption | IdP logs, SAML/OIDC traces, CloudTrail |
| **Session** | Full session recording, command history, keystroke timing | PAM session recording, bastion host logs |
| **Data Access** | Queries run, rows returned, tables accessed, exports | Database audit logs, query proxies |
| **Configuration** | System/network/cloud config changes | Change management system, config audit tools |
| **Lateral Movement** | RDP/SSH sessions, service account usage across systems | Network flow data, authentication logs |
| **Exfiltration** | Outbound data volume, destination, protocol | DLP, proxy logs, NetFlow/IPFIX |

### 9.2 Privileged User Monitoring Rules

#### Sigma Rule: Privileged User — Unusual Login Time

```yaml
title: Privileged User Authentication Outside Business Hours
id: 8a3f2c1e-4b5d-6e7f-8a9b-0c1d2e3f4a5b
status: experimental
description: Detects privileged account authentication outside defined business hours, potential indicator of compromised credentials or insider threat activity
logsource:
  category: authentication
  product: windows
detection:
  selection:
    EventID: 4624
    TargetUserName|endswith:
      - '-admin'
      - '-da'
      - '-sa'
    TargetUserName|contains:
      - 'admin'
      - 'svc_'
  filter_business_hours:
    # Business hours: Mon-Fri 06:00-22:00
  condition: selection AND NOT filter_business_hours
falsepositives:
  - Scheduled maintenance windows with change tickets
  - On-call rotation personnel (correlate with on-call schedule)
level: high
tags:
  - attack.t1078
  - attack.initial_access
  - attack.persistence
```

#### Sigma Rule: Privileged User — Bulk Data Access

```yaml
title: Privileged Account Accessing Abnormal Volume of Sensitive Files
id: 1b2c3d4e-5f6a-7b8c-9d0e-1f2a3b4c5d6e
status: experimental
description: Detects privileged accounts accessing significantly more files than baseline, indicative of data staging for exfiltration
logsource:
  category: file_access
  product: windows
detection:
  selection:
    EventID:
      - 4663  # File access
    SubjectUserName|contains:
      - 'admin'
      - 'svc_'
    ObjectType: 'File'
  threshold:
    count(ObjectName): '>100'
    timeframe: 1h
  condition: selection | count(ObjectName) by SubjectUserName > 100
falsepositives:
  - Backup service accounts (filter by known backup SAs)
  - Authorized data migration projects (correlate with change tickets)
level: high
tags:
  - attack.t1005
  - attack.collection
```

#### Sigma Rule: Audit Log Tampering Attempt

```yaml
title: Security Audit Log Cleared or Disabled
id: 2c3d4e5f-6a7b-8c9d-0e1f-2a3b4c5d6e7f
status: stable
description: Detects clearing of security event logs or disabling of audit policy, critical indicator of insider attempting to cover tracks
logsource:
  category: process_creation
  product: windows
detection:
  selection_clear:
    CommandLine|contains:
      - 'wevtutil cl Security'
      - 'wevtutil cl System'
      - 'Clear-EventLog'
  selection_disable:
    CommandLine|contains:
      - 'auditpol /set /category:* /success:disable'
      - 'auditpol /set /category:* /failure:disable'
  condition: selection_clear OR selection_disable
falsepositives:
  - Authorized log rotation procedures with change ticket (rare on security logs)
level: critical
tags:
  - attack.t1070.001
  - attack.defense_evasion
```

### 9.3 Cloud Privileged Access Monitoring

#### Key CloudTrail Events to Monitor

| Event | Insider Threat Signal |
|-------|----------------------|
| `ConsoleLogin` with root credentials | Root account should never be used interactively |
| `CreateUser` / `CreateAccessKey` | Unauthorized account/key creation for persistence |
| `AttachUserPolicy` / `PutRolePolicy` | Self-provisioning of elevated permissions |
| `StopLogging` / `DeleteTrail` | Disabling audit trail (critical — T1562) |
| `CreateSnapshot` / `ModifySnapshotAttribute` | Exfiltration via shared snapshots (T1537) |
| `GetObject` (S3) with bulk volume | Data staging from sensitive buckets |
| `AssumeRole` to cross-account roles | Lateral movement between accounts |
| `ModifyInstanceAttribute` (userData) | Injecting commands into EC2 instances |

#### Azure AD / Entra ID Events

| Event | Insider Threat Signal |
|-------|----------------------|
| `Add member to role` (Global Admin) | Privilege escalation |
| `Update conditional access policy` | Weakening authentication controls (T1556) |
| `Add application` / `Update application` | OAuth app registration for persistent access |
| `Set-Mailbox -ForwardingSmtpAddress` | Email forwarding rule for data exfiltration |
| `New-InboxRule` with forward/redirect | Hidden email forwarding (T1564.008) |
| `Disable-AzureADDirectorySetting` | Disabling security controls |

---

## 10. Insider Threat Program Development

### 10.1 CISA Framework: Define, Detect, Assess, Manage

```
┌────────────┐     ┌────────────────┐     ┌────────────┐     ┌────────────┐
│   DEFINE   │────►│ DETECT &       │────►│   ASSESS   │────►│   MANAGE   │
│            │     │ IDENTIFY       │     │            │     │            │
│ Policies   │     │ Behavioral +   │     │ Interest   │     │ Continuous │
│ Scope      │     │ Technical      │     │ Motive     │     │ monitoring │
│ Governance │     │ indicators     │     │ Capability │     │ Mitigation │
└────────────┘     └────────────────┘     └────────────┘     └────────────┘
```

### 10.2 Program Components

#### Governance Structure

| Component | Responsibility |
|-----------|---------------|
| **Executive Sponsor** | C-suite ownership, budget authority, risk acceptance |
| **Insider Threat Working Group** | Cross-functional: Security, HR, Legal, IT, Physical Security, Management |
| **Insider Threat Program Manager** | Day-to-day program operations, case management, reporting |
| **Threat Assessment Team** | Evaluate referrals, determine risk level, recommend interventions |
| **Legal Counsel** | Privacy compliance, employee rights, investigation legality |
| **HR Representative** | Behavioral indicator context, employment actions, EAP referrals |

#### Policy Framework

| Policy | Content |
|--------|---------|
| **Acceptable Use Policy** | Defines permitted/prohibited system usage; establishes monitoring expectation |
| **Data Handling Policy** | Classification requirements, handling procedures per level, breach reporting |
| **Privileged Access Policy** | Eligibility criteria, approval process, monitoring requirements, review cadence |
| **Insider Threat Policy** | Program charter, indicator reporting procedures, investigation authority |
| **Monitoring & Privacy Policy** | Scope of monitoring, employee notification, data retention, legal basis |
| **Offboarding Policy** | Access revocation timeline, exit interview, device return, knowledge transfer |
| **Incident Response (Insider)** | Investigation procedures, evidence handling, escalation criteria, legal coordination |

### 10.3 CERT/SEI 22 Best Practices (Summary)

The Common Sense Guide to Mitigating Insider Threats (7th Edition, 2022) organizes practices across stakeholder groups:

| Stakeholder | Practice Areas |
|-------------|---------------|
| **Management** | Clear policies, insider threat awareness culture, personnel management |
| **HR** | Pre-employment screening, ongoing evaluation, secure offboarding |
| **Legal** | Policy review, investigation procedures, privacy compliance |
| **Physical Security** | Facility access controls, device management, visitor management |
| **IT** | Network monitoring, access controls, system hardening |
| **Information Security** | SIEM/UEBA deployment, DLP, incident response |
| **Data Owners** | Classification, access authorization, periodic review |
| **Software Engineers** | Secure development, code review, change management |

### 10.4 Program Maturity Model

| Level | Characteristics | Capabilities |
|-------|----------------|-------------|
| **1 — Initial** | Ad-hoc, reactive | No formal program; incident-driven response only |
| **2 — Developing** | Basic policies, initial monitoring | AUP exists, basic logging, manual review |
| **3 — Defined** | Formalized program, cross-functional team | SIEM deployed, DLP in monitor mode, HR integration, documented procedures |
| **4 — Managed** | Proactive detection, UEBA deployed | Behavioral analytics, risk scoring, automated alerting, regular exercises |
| **5 — Optimizing** | Predictive, intelligence-driven | ML models tuned to org, threat intelligence integration, continuous improvement, metrics-driven |

### 10.5 Metrics & KPIs

| Metric | Target | Purpose |
|--------|--------|---------|
| Mean Time to Detect (MTTD) insider incident | < 30 days | Measure detection capability (industry avg is ~85 days) |
| Mean Time to Respond (MTTR) | < 48 hours from detection | Measure response capability |
| % of privileged accounts with PAM coverage | 100% | Measure PAM deployment completeness |
| % of users completing insider threat training | > 95% annually | Measure awareness program reach |
| Access review completion rate | 100% quarterly | Measure access governance |
| DLP policy violation trend | Decreasing quarter-over-quarter | Measure policy effectiveness |
| False positive rate on UEBA alerts | < 30% | Measure detection tuning quality |
| Number of over-provisioned accounts identified | Decreasing | Measure least privilege progress |
| Time to revoke access on termination | < 1 hour | Measure offboarding effectiveness |

---

## 11. Cloud-Specific Insider Threat Detection

### 11.1 Cloud ATT&CK Techniques for Insider Abuse

Based on the MITRE ATT&CK Cloud Matrix, these are the highest-risk techniques for insider exploitation:

#### Persistence & Privilege Escalation

| Technique | ID | Insider Abuse Scenario |
|-----------|----|----------------------|
| Account Manipulation — Additional Cloud Credentials | T1098.001 | Admin creates additional access keys for personal use |
| Account Manipulation — Additional Cloud Roles | T1098.003 | Admin assigns themselves elevated role in secondary account |
| Modify Authentication Process — MFA | T1556.006 | Admin weakens MFA requirements for their own account |
| Modify Authentication Process — Conditional Access | T1556.009 | Admin creates exception in conditional access for their IP |
| Temporary Elevated Cloud Access | T1548.005 | Abuse of JIT mechanisms for unauthorized elevation |
| Trust Modification | T1484.002 | Modify federation trust to allow external identity access |

#### Defense Evasion

| Technique | ID | Insider Abuse Scenario |
|-----------|----|----------------------|
| Impair Defenses — Disable Cloud Logs | T1562.008 | Admin disables CloudTrail/Azure activity logs |
| Impair Defenses — Disable Cloud Firewall | T1562.007 | Admin opens security group for unauthorized access |
| Clear Mailbox Data | T1070.008 | Delete evidence of data exfiltration from mailbox |
| Email Hiding Rules | T1564.008 | Auto-delete security notifications |

#### Collection & Exfiltration

| Technique | ID | Insider Abuse Scenario |
|-----------|----|----------------------|
| Data from Cloud Storage | T1530 | Access S3/Blob/GCS buckets outside job scope |
| Data from Information Repositories | T1213 | Bulk download from SharePoint/Confluence |
| Email Collection | T1114 | Forward emails to external address |
| Transfer Data to Cloud Account | T1537 | Copy data to personal cloud account via shared snapshots |
| Exfiltration Over Webhook | T1567.004 | Use Slack/Discord webhook to exfil data programmatically |

### 11.2 Cloud Security Monitoring Patterns (Netflix Security Monkey Model)

Key architectural patterns from Netflix's Security Monkey (applicable despite archival):

1. **Continuous configuration monitoring**: Track all cloud config states, alert on changes outside change management
2. **Temporal change detection**: Maintain configuration history — compare current vs. previous state to detect drift
3. **Watcher-Auditor-Alerter pipeline**: Modular architecture: collect (watcher) → analyze (auditor) → notify (alerter)
4. **Custom detection rules**: Organization-specific rules beyond generic compliance checks
5. **Multi-cloud coverage**: Monitor AWS, GCP, Azure configurations through a unified lens
6. **Deviation-based detection**: Detect threats through behavioral deviation, not just static rule matching

### 11.3 IaC Security for Insider Threat (Terrascan Pattern)

Insider threats in DevOps target Infrastructure as Code to embed backdoors:

| Risk | Detection | Terrascan Policy Type |
|------|-----------|----------------------|
| Overly permissive IAM policies in Terraform | Scan for `*` permissions, admin policies | IAM policy analysis |
| Security groups with 0.0.0.0/0 ingress | Detect open network access | Network security rules |
| Unencrypted storage resources | Flag missing encryption config | Data protection |
| Public S3 buckets / Blob containers | Detect public access settings | Storage security |
| Hardcoded secrets in IaC | Scan for embedded credentials | Secret management |
| Missing logging / monitoring config | Detect disabled CloudTrail, Flow Logs | Audit configuration |

**Integration point**: Run Terrascan in CI/CD pipelines to prevent insiders from deploying misconfigured infrastructure. Require peer review on all IaC changes.

---

## 12. Abuse Case Modeling

### 12.1 OWASP Abuse Case Framework

**Abuse Case**: A way to use a feature that was not expected by the implementer, allowing an attacker to influence the feature or outcome.

#### Threat Personas for Insider Modeling

| Persona | Description | Applicable Insider Type |
|---------|-------------|------------------------|
| **Malicious User** | Intentionally harmful actor | Deliberate insider threat |
| **Abusive User** | Misuses legitimate access for unintended purposes | Privilege abuse, data theft |
| **Unknowing User** | Inadvertently creates vulnerabilities | Negligent insider |

#### Abuse Case Workshop Method

Participants:
- Business analysts (explain features and workflows)
- Penetration testers (propose attack paths)
- AppSec professionals (suggest countermeasures)
- Technical leaders (evaluate implementation feasibility)
- Risk analysts (rate business impact)

#### Insider-Specific Abuse Cases

| # | Feature | Abuse Case | Control |
|---|---------|-----------|---------|
| AC-001 | File export from CRM | Bulk export customer PII before resignation | DLP + UEBA volume baseline + HR correlation |
| AC-002 | Admin console access | Self-provision elevated permissions | Separation of duties + audit logging + peer approval |
| AC-003 | API key generation | Create long-lived API key for post-departure access | Key expiration policy + key inventory + offboarding revocation |
| AC-004 | Email forwarding rules | Auto-forward sensitive emails to personal address | Exchange transport rules + M365 audit monitoring |
| AC-005 | Cloud storage sharing | Share internal documents via public links | CASB + link expiration + DLP content scanning |
| AC-006 | Code repository access | Clone entire repository before departure | Git audit logs + UEBA + DLP on git operations |
| AC-007 | Database query tool | Run SELECT * on sensitive tables and export | Query auditing + row-limit enforcement + DLP on exports |
| AC-008 | CI/CD pipeline | Inject backdoor in deployment pipeline | Code review requirement + pipeline signing + IaC scanning |

### 12.2 Mapping to Security Controls

Track countermeasures at three levels:

1. **Design/Infrastructure level** — Architecture decisions (zero trust, segmentation, encryption)
2. **Network level** — DLP, proxy, IDS/IPS, network segmentation
3. **Application level** — Authorization checks, input validation, audit logging

Annotate code with abuse case identifiers:
```java
@AbuseCase(ids={"AC-001", "AC-007"})
public DataExport exportRecords(ExportRequest request) {
    // Enforce row limits, log export, check DLP policy
}
```

---

## 13. Detection Engineering Playbooks

### 13.1 Departing Employee Playbook

**Trigger**: HR system feed indicates employee resignation/termination

```
Phase 1: Enrichment (Automated)
├── Pull user's behavioral baseline from UEBA (last 90 days)
├── Enumerate all accounts, group memberships, and access grants
├── Identify all data stores the user has accessed in last 30 days
├── Check for any active email forwarding rules
├── List all API keys / service credentials associated with user
└── Review recent DLP alerts for this user

Phase 2: Enhanced Monitoring (Automated, 30-day window)
├── Lower UEBA alert thresholds for this user by 50%
├── Enable full endpoint logging (process, file, network)
├── Monitor for bulk file downloads (>50 files or >100MB in 24h)
├── Alert on any new email forwarding rules
├── Alert on any cloud storage uploads to personal accounts
├── Alert on any USB device insertions
├── Alert on access to systems outside normal scope
└── Monitor print server for bulk printing

Phase 3: Offboarding Execution
├── Disable all accounts within 1 hour of departure
├── Revoke all API keys and tokens
├── Remove from all shared drives and repositories
├── Remove email forwarding rules
├── Collect all company devices
├── Revoke VPN and remote access
├── Revoke badge access
├── Transfer data ownership to manager
└── Retain audit logs for 12 months minimum

Phase 4: Post-Departure Monitoring (90 days)
├── Monitor for authentication attempts with disabled credentials
├── Monitor for API calls using revoked tokens
├── Check for data appearing externally (dark web monitoring)
└── Review any ongoing shared access (cloud docs, Slack channels)
```

### 13.2 Privilege Escalation Detection Playbook

**Trigger**: UEBA alert — user exercising permissions outside baseline

```
Triage (0-15 min):
├── Confirm the permission change is real (not false positive from log delay)
├── Identify who made the change (self-provisioned vs. admin-granted)
├── Check if change request exists in ITSM system
├── Assess scope of new permissions (read-only vs. admin vs. destructive)
└── Determine if user has accessed any new resources since elevation

Investigation (15-60 min):
├── If self-provisioned: ESCALATE immediately (unauthorized privilege escalation)
├── If admin-granted without ticket: contact granting admin for justification
├── Review all user activity since permission change
├── Check if user has created any new accounts, keys, or credentials
├── Review data access patterns for anomalies
└── Check for defense evasion indicators (log clearing, policy changes)

Response:
├── If unauthorized: revoke permissions, preserve evidence, invoke IR
├── If authorized but excessive: reduce to minimum required, update RBAC
├── If authorized and appropriate: document exception, set review date
└── Update detection rules based on findings
```

### 13.3 Data Exfiltration Detection Playbook

**Trigger**: DLP alert or UEBA volumetric anomaly

```
Triage (0-15 min):
├── Classify data sensitivity (L1-L4)
├── Identify exfiltration channel (email, cloud, USB, web, physical)
├── Determine volume and scope of data involved
├── Check user risk context (departing? privileged? recent HR events?)
└── Determine if exfiltration is ongoing or completed

Investigation (15-60 min):
├── Collect network flow data for user's sessions (last 24-72 hours)
├── Review endpoint telemetry for staging activity (archiving, encryption)
├── Check for related DLP alerts in last 30 days (slow exfil pattern)
├── Identify all destinations data was sent to
├── Determine if data was encrypted before exfiltration
├── Cross-reference with approved data sharing exceptions
└── Interview user's manager for business justification (if non-obvious)

Containment:
├── If active exfiltration: block channel immediately (revoke access, block URL, disable USB)
├── If L4 data involved: invoke CIRT, preserve all evidence, legal notification
├── If personal cloud storage: request takedown / preservation hold via legal
└── If completed: assess blast radius, begin damage assessment

Recovery:
├── Revoke user's access to source data
├── Rotate any credentials or keys that were exfiltrated
├── Notify data owners of exposure
├── If PII involved: begin breach notification assessment (GDPR Art. 33: 72-hour window)
└── Update DLP rules to prevent recurrence
```

### 13.4 Authentication Anomaly Detection

#### Sigma Rule: Impossible Travel

```yaml
title: Authentication from Geographically Impossible Locations
id: 3d4e5f6a-7b8c-9d0e-1f2a-3b4c5d6e7f8a
status: experimental
description: Detects user authentication from two geographic locations that are impossible to travel between in the elapsed time, indicating credential compromise or VPN abuse
logsource:
  category: authentication
  product: azure_ad
detection:
  selection:
    eventType: 'SignInLogs'
    resultType: '0'  # successful
  condition: selection
  # Correlation logic (SIEM-specific):
  # Group by userPrincipalName
  # Calculate geo distance between consecutive auth events
  # Calculate time delta
  # Alert if speed > 800 km/h
falsepositives:
  - Corporate VPN with geographically distributed exit nodes
  - User connecting from mobile hotspot while traveling
  - Cloud proxy services that route through multiple regions
level: high
tags:
  - attack.t1078
  - attack.initial_access
```

---

## Appendix A: Quick Reference — Insider Threat Detection Data Sources

| Priority | Data Source | Key Events | Insider Threat Coverage |
|----------|-----------|------------|------------------------|
| P0 | Identity Provider (AD/Entra/Okta) | Auth, MFA, group changes, role assignments | Account abuse, privilege escalation |
| P0 | Cloud Audit Logs (CloudTrail/Activity Log) | API calls, IAM changes, resource access | Cloud privilege abuse, config tampering |
| P0 | DLP Platform | Policy violations, content matches | Data exfiltration attempts |
| P1 | Endpoint Agent (EDR) | Process exec, file ops, USB, network | Local staging, physical exfil, malware |
| P1 | Email Gateway | Attachments, forwarding rules, DLP tags | Email exfiltration |
| P1 | Web Proxy / CASB | URL categories, uploads, cloud app usage | Cloud storage exfil, shadow IT |
| P2 | HR System (API) | Resignation, PIP, role changes | Context enrichment for risk scoring |
| P2 | PAM Platform | Session recordings, credential checkout | Privileged access abuse |
| P2 | Network Flow (NetFlow/IPFIX) | Traffic volumes, destinations, protocols | Covert channels, bulk transfer |
| P3 | Badge / Physical Access | Entry/exit, restricted areas | After-hours access, tailgating |
| P3 | Print Server | Document names, page counts, user | Bulk printing exfiltration |

## Appendix B: Key ATT&CK Techniques for Insider Threat

| Tactic | Technique | ID | Insider Relevance |
|--------|-----------|-----|-------------------|
| Initial Access | Valid Accounts | T1078 | Insiders already have valid credentials |
| Persistence | Account Manipulation | T1098 | Creating backdoor access |
| Persistence | Create Account | T1136 | Unauthorized accounts for persistence |
| Privilege Escalation | Temporary Elevated Cloud Access | T1548.005 | Abusing JIT mechanisms |
| Defense Evasion | Impair Defenses | T1562 | Disabling logs and monitoring |
| Defense Evasion | Indicator Removal | T1070 | Clearing logs, mailbox data |
| Credential Access | Unsecured Credentials | T1552 | Harvesting creds from chat, code, metadata |
| Discovery | Cloud Service Discovery | T1526 | Mapping available resources |
| Collection | Data from Cloud Storage | T1530 | Accessing sensitive cloud data |
| Collection | Data from Information Repos | T1213 | SharePoint, Confluence bulk access |
| Collection | Email Collection | T1114 | Forwarding rules, bulk download |
| Collection | Archive Collected Data | T1560 | Staging data for exfiltration |
| Exfiltration | Exfil Over Web Service | T1567 | Cloud storage, code repos, webhooks |
| Exfiltration | Exfil Over Alt Protocol | T1048 | DNS tunneling, FTP, SMTP |
| Exfiltration | Exfil Over Physical Medium | T1052 | USB, removable devices |
| Exfiltration | Transfer to Cloud Account | T1537 | Shared snapshots, cross-account copy |

## Appendix C: Authentication Control Hardening

**[CONFIRMED]** — NIST SP 800-63 explicitly prohibits security questions as a sole recovery mechanism.

| Control | Recommendation | Insider Threat Mitigation |
|---------|---------------|--------------------------|
| MFA Enforcement | Hardware tokens (FIDO2) for all privileged accounts | Prevents credential sharing, limits compromised insider impact |
| Security Questions | Eliminate entirely; replace with MFA-based recovery | Prevents social engineering of account recovery by insider |
| Session Management | Time-limited sessions, re-auth for sensitive operations | Limits window of opportunity for session hijacking |
| Password Policy | Passphrase-based, credential stuffing checks | Reduces password sharing risk |
| SSO Centralization | Single IdP with unified audit logging | Complete visibility into all authentication events |
| Conditional Access | Location, device, risk-based policies | Prevents access from unauthorized contexts |
| Account Recovery | Require admin-assisted recovery with identity verification | Prevents insider from hijacking other accounts |

---

> **Training Module Status**: Complete
> **Next Steps**: Implement detection rules in SIEM, deploy UEBA baselines, integrate HR system feed, establish insider threat working group
> **Review Cadence**: Quarterly update aligned with ATT&CK version releases
