<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# OSINT Tradecraft Deep Dive

## Training Classification: Advanced OSINT Operations, Investigator OPSEC, and Analytic Methodology

---

## 1. OPSEC for OSINT Investigators

### 1.1 The Investigator Threat Model

Before any collection begins, understand what you are protecting:
- **Your identity**: real name, employer, personal accounts, home IP
- **Your investigation**: targets, queries, hypotheses, collected evidence
- **Your sources**: informants, tipsters, whistleblowers who provided leads
- **Your infrastructure**: devices, accounts, domains used for research

Adversary capabilities scale with target sophistication:
- **Low**: basic social media users who might notice profile views
- **Medium**: organizations with analytics dashboards tracking visitors
- **High**: state actors with ISP-level visibility and platform cooperation
- **Extreme**: intelligence services with SIGINT and active counterintelligence

### 1.2 Sock Puppet Operations

A sock puppet is a fictitious online identity used to conduct research without exposing the investigator.

#### Creation Methodology

**Identity Generation:**
- Use thispersondoesnotexist.com or StyleGAN-generated faces for profile photos (never real humans, never stock photos that reverse-image-search to other profiles)
- Generate consistent biographical details: name, date of birth, location, employment history, education
- Use name generators calibrated to the target's region/culture (e.g., a Russian target warrants a Russian-named puppet)
- Create a "backstory bible" documenting every detail of the puppet identity for consistency

**Email and Phone:**
- Protonmail or Tutanota for email (avoid Gmail/Outlook which require phone verification and link to Google/Microsoft ecosystems)
- For phone verification: prepaid SIMs purchased with cash, or virtual numbers via services like SMS Activate, TextNow, Google Voice (each has tradeoffs)
- Never link sock puppet phone numbers to personal accounts or devices
- Use separate email chains: one email per puppet, never cross-pollinate

**Account Aging:**
- Fresh accounts trigger platform heuristics; aged accounts are more trusted
- Create accounts weeks or months before operational use
- Engage in normal-seeming activity: follow popular accounts, like mainstream content, post occasionally
- Build a plausible social graph: follow/friend 50-200 accounts in the puppet's supposed interest areas
- Avoid following only investigation-related accounts

**Platform-Specific Considerations:**
- **Facebook**: Requires realistic friend networks; accounts with <10 friends are suspicious. Join local groups matching the puppet's stated location
- **LinkedIn**: Needs employment history and connections. Use real-seeming but unverifiable companies
- **Instagram**: Post photos (AI-generated or royalty-free, never reverse-searchable). Use location tags matching stated location
- **Telegram**: Fresh accounts from known VPN IPs get flagged. Use residential IPs for initial registration
- **Twitter/X**: Aged accounts with some tweet history bypass most automated detection
- **Reddit**: Karma requirements on many subreddits. Build karma in non-sensitive subreddits first

#### Puppet Hygiene

- **Never** log into a sock puppet from the same browser session, device, or network as your real identity
- **Never** reuse passwords between puppets or between puppets and personal accounts
- Maintain separate password managers per puppet (or isolated vaults)
- Document which puppet is used for which investigation to avoid cross-contamination
- Retire puppets after investigations conclude; do not reuse across unrelated investigations
- Assume platform device fingerprinting: use dedicated VMs per puppet

### 1.3 Network Isolation

#### VPN Configuration

**Requirements for investigative VPNs:**
- No-log policy (verified by independent audit, not marketing claims)
- Jurisdiction outside Five/Nine/Fourteen Eyes intelligence-sharing agreements (recommended: Panama, Switzerland, Romania)
- Support for WireGuard or OpenVPN protocols
- Kill switch to prevent IP leaks if VPN drops
- Multi-hop capability for sensitive investigations

**Recommended providers (as of 2026):**
- Mullvad (account-number-based, cash payment accepted, independently audited)
- ProtonVPN (Swiss jurisdiction, Secure Core multi-hop, open-source apps)
- IVPN (independent audit, WireGuard, no email required to sign up)

**VPN OPSEC failures to avoid:**
- Using the same VPN exit node consistently (creates a pattern)
- Logging into personal accounts while VPN is active for investigation
- Assuming VPN = anonymity (VPN provider can still see your traffic)
- Using free VPNs (they monetize your data)

#### Tor Usage

When VPN is insufficient:
- Tor Browser for web-based OSINT (prevents browser fingerprinting)
- Tor SOCKS proxy for CLI tools: `torsocks sherlock username`
- Use bridges if Tor usage itself is sensitive (e.g., in countries that block Tor)
- **Limitations**: many platforms block Tor exit nodes; CAPTCHA walls are common; latency makes large-scale enumeration impractical
- Combine Tor + VPN (VPN -> Tor) for defense-in-depth, but understand the tradeoffs

#### DNS Leak Prevention

- Configure system DNS to use encrypted resolvers (DNS over HTTPS or DNS over TLS)
- Recommended: Quad9 (9.9.9.9), Cloudflare (1.1.1.1), or Mullvad DNS
- Test for leaks: dnsleaktest.com, ipleak.net, browserleaks.com
- On Linux: use `systemd-resolved` with DNSOverTLS=yes or stubby

### 1.4 Virtual Machine Isolation

**Architecture:**
```
Host OS (personal use, no OSINT)
  |
  +-- VM: Investigation A (Puppet Alpha, VPN endpoint 1)
  |     +-- Dedicated browser profile
  |     +-- Puppet's password vault
  |     +-- Investigation-specific tools
  |
  +-- VM: Investigation B (Puppet Beta, VPN endpoint 2)
  |     +-- Separate browser profile
  |     +-- Different VPN exit country
  |
  +-- VM: Burner (Tor-only, no persistent storage)
        +-- Tails OS or Whonix
        +-- For dark web access
```

**Recommended VM platforms:**
- **Qubes OS**: Security-focused, compartmentalized by design. Gold standard for investigator workstations
- **VirtualBox/VMware**: Standard hypervisors. Use snapshots to revert after sessions
- **Whonix**: Tor-routed VM pair (Gateway + Workstation). All traffic forced through Tor
- **Tails**: Amnesic live OS. Boots from USB, leaves no trace on host. Ideal for sensitive fieldwork

**VM hygiene:**
- Disable clipboard sharing between host and guest
- Disable shared folders
- Use NAT networking (not bridged) to prevent local network exposure
- Snapshot VMs before risky operations; revert if contaminated
- Different timezone settings per VM to match puppet's stated location

### 1.5 Browser Isolation

**Browser fingerprinting defenses:**
- Use Firefox with `privacy.resistFingerprinting` enabled
- Install: uBlock Origin, NoScript (or uMatrix), Canvas Blocker
- Use separate browser profiles per investigation/puppet
- Clear cookies, cache, and local storage between sessions
- Disable WebRTC (leaks local IP even behind VPN): `media.peerconnection.enabled = false`
- Consider Brave Browser with fingerprint randomization for lightweight isolation

**Browser containers:**
- Firefox Multi-Account Containers: isolate cookies per container
- Temporary Containers add-on: auto-create disposable containers per tab
- Never have personal and investigation tabs in the same browser instance

### 1.6 Metadata Scrubbing

Before sharing or publishing any collected evidence:
- Strip EXIF data from images: `exiftool -all= image.jpg`
- Remove document metadata from PDFs: `exiftool -all= document.pdf` or `qpdf --linearize input.pdf output.pdf`
- Screenshots over downloads: screenshots contain no origin metadata, downloads may contain referrer information
- Use MAT2 (Metadata Anonymisation Toolkit 2) for batch processing
- Hash evidence files before and after scrubbing to maintain chain of custody: `sha256sum file`

---

## 2. Advanced Google Dorking

### 2.1 Core Operators

| Operator | Function | Example |
|----------|----------|---------|
| `site:` | Restrict to domain | `site:linkedin.com "target name"` |
| `inurl:` | Term in URL path | `inurl:admin login` |
| `intitle:` | Term in page title | `intitle:"index of" passwords` |
| `intext:` | Term in page body | `intext:"@targetcompany.com"` |
| `filetype:` | Specific file extension | `filetype:xlsx "employee list"` |
| `ext:` | Alias for filetype | `ext:sql "password"` |
| `cache:` | Google cached version | `cache:target.com` |
| `link:` | Pages linking to URL | `link:target.com` |
| `related:` | Similar sites | `related:target.com` |
| `""` | Exact phrase match | `"John Smith" "Acme Corp"` |
| `-` | Exclude term | `site:target.com -site:www.target.com` |
| `*` | Wildcard | `"password is *"` |
| `..` | Number range | `"employee" 2020..2026 site:target.com` |
| `OR` / `|` | Boolean OR | `site:pastebin.com | site:hastebin.com "target"` |
| `AROUND(n)` | Proximity search | `"CEO" AROUND(3) "resigned"` |
| `before:` / `after:` | Date filtering | `site:target.com after:2025-01-01` |

### 2.2 Reconnaissance Dork Patterns

**Exposed credentials and configs:**
```
site:target.com filetype:env
site:target.com filetype:yml password
site:target.com filetype:cfg
site:target.com filetype:ini "[database]"
site:target.com filetype:log "password"
site:target.com filetype:sql "INSERT INTO" "users"
site:target.com filetype:bak
```

**Open directories:**
```
intitle:"index of" site:target.com
intitle:"index of" "parent directory" site:target.com
intitle:"index of" inurl:backup site:target.com
intitle:"index of" inurl:admin site:target.com
```

**Exposed documents:**
```
site:target.com filetype:pdf "confidential"
site:target.com filetype:xlsx "salary" | "employee"
site:target.com filetype:docx "internal use only"
site:target.com filetype:pptx "not for distribution"
```

**Cloud storage leaks:**
```
site:s3.amazonaws.com "target"
site:blob.core.windows.net "target"
site:storage.googleapis.com "target"
site:drive.google.com "target.com"
```

**Paste site leaks:**
```
site:pastebin.com "target.com"
site:paste.ee "target.com"
site:ghostbin.co "target.com"
site:justpaste.it "@target.com"
site:rentry.co "target.com"
```

**Cached/archived content:**
```
cache:target.com/admin
site:web.archive.org "target.com"
```

**Subdomain and infrastructure discovery:**
```
site:*.target.com -www
site:*.*.target.com
inurl:target.com -site:target.com
```

### 2.3 People-Focused Dorks

```
"John Smith" site:linkedin.com
"John Smith" site:facebook.com
"John Smith" "target company" filetype:pdf
"jsmith@" site:target.com
"@target.com" site:github.com
intext:"@target.com" site:pastebin.com
"John Smith" resume filetype:pdf
```

### 2.4 Dork Generation Tools

- **Google Hacking Database (GHDB)** at exploit-db.com/google-hacking-database: curated dork database categorized by vulnerability type
- **DorkGenius**: AI-powered dork generation
- **DorkGPT**: LLM-based custom dork construction
- **SearchDorks**: Automated dork pattern generation
- **Pagodo**: Automates Google Hacking Database queries

### 2.5 Beyond Google

Apply dorking to other search engines for different coverage:
- **Bing**: similar operators, sometimes indexes pages Google misses
- **Yandex**: strong image search, indexes Russian-language web extensively
- **Baidu**: essential for Chinese-language OSINT
- **DuckDuckGo**: uses Bing's index but with `!bangs` for cross-platform search
- **Shodan dorks**: `hostname:target.com`, `org:"Target Corp"`, `ssl.cert.subject.CN:target.com`
- **Censys**: `parsed.names: target.com`, `services.http.response.html_title: "admin"`
- **FOFA**: `domain="target.com"`, `header="target"`, `cert="target.com"`

---

## 3. Social Media Intelligence (SOCMINT)

### 3.1 Twitter/X Intelligence

#### Native Advanced Search

Twitter's advanced search (twitter.com/search-advanced) supports:
```
from:username          — tweets by user
to:username            — replies to user
@username              — mentions of user
"exact phrase"         — exact match
filter:links           — tweets with URLs
filter:images          — tweets with images
filter:videos          — tweets with video
filter:media           — any media
lang:en                — language filter
geocode:lat,lon,radius — geographic search
since:2025-01-01       — date range start
until:2025-12-31       — date range end
min_retweets:100       — engagement threshold
min_faves:500          — like threshold
min_replies:50         — reply threshold
-filter:retweets       — exclude retweets
```

**Combine operators for precision:**
```
from:target since:2025-01-01 until:2025-06-01 filter:links
(from:target) geocode:48.8566,2.3522,10km
"meeting" OR "conference" from:target
```

#### OSINT Tools for Twitter/X

- **ExportData**: Export tweets, followers, followings historically
- **Foller.me**: Profile analytics — posting times, hashtag usage, mentioned users
- **Trends24**: Real-time trending analysis by country/city
- **TweetMap / OneMillionTweetMap**: Geographic tweet visualization
- **Twitter Audit**: Bot/fake follower detection and scoring
- **Xquik**: Real-time X data platform for tweets, users, and metrics
- **Twint alternatives**: After Twint's deprecation, use `snscrape` or API-based tools
- **Wayback Machine**: Cached tweets from deleted accounts

#### Intelligence Value

- **Behavioral patterns**: Posting times reveal timezone and work schedule
- **Location leaks**: Geotagged tweets, mentioned venues, photos with landmarks
- **Network mapping**: Reply chains and retweet patterns reveal associations
- **Sentiment shifts**: Changes in posting tone indicate life events
- **OPSEC failures**: Screenshots showing notification bars, battery status, carrier name

### 3.2 Facebook Intelligence

#### Search Techniques

Facebook's native search has been restricted, but workarounds exist:

**Google dorking Facebook:**
```
site:facebook.com "target name" "lives in"
site:facebook.com/groups "target company"
site:facebook.com inurl:posts "target name"
```

**Facebook ID-based searching:**
- Find numeric Facebook ID via Lookup-ID.com or Find-My-Facebook-ID
- Access profile directly: `facebook.com/profile.php?id=NUMERIC_ID`
- Graph Search remnants: `facebook.com/search/USERID/photos-of`

**Tools:**
- **Sowdust FB Search**: Facebook Graph Search replacement (GitHub)
- **Who Posted What**: Search Facebook posts by keyword and user
- **Facebook Friend List Scraper**: Extract friend lists at scale
- **haveibeenzuckered**: Check if phone number was in the 2021 Facebook breach (533M records)
- **Fb-sleep-stats**: Track when a target is online/offline to map sleep patterns

#### Intelligence Value

- **Friends lists**: Map social network, identify associates
- **Check-ins and tagged photos**: Location history
- **Life events**: Employment changes, relationship status, moves
- **Group memberships**: Interests, political affiliations, professional connections
- **Marketplace listings**: Phone numbers, addresses, items revealing lifestyle

### 3.3 Instagram Intelligence

#### Search and Collection

- **Osintgram**: 21+ commands for Instagram OSINT — downloads photos, stories, extracts follower emails/phone numbers, geotagged addresses. Requires authentication (use sock puppet account)
- **Toutatis**: Extract email and phone from profiles when available
- **Dolphin Radar**: View posts, stories, and profiles from public accounts
- **instagram_monitor**: Real-time tracking of user activity changes

#### Native Research Techniques

- **Hashtag search**: Browse by hashtag to find location-specific or event-specific posts
- **Location pages**: instagram.com/explore/locations/ — browse posts by place
- **Tagged photos**: Reveal associations and attendance at events
- **Story highlights**: Often contain more candid/revealing content than curated posts
- **Reels**: Video content may contain background audio, visible screens, location indicators

#### Intelligence Value

- **Geolocation from photos**: Identifiable landmarks, business names, street signs, vegetation patterns
- **EXIF data**: Instagram strips EXIF, but Stories and DMs sent as files may retain metadata
- **Lifestyle intelligence**: Travel patterns, spending habits, vehicle identification
- **Network mapping**: Tagged users, comment interactions, collaborative posts
- **Timestamp analysis**: When posts are made reveals timezone and routine

### 3.4 LinkedIn Intelligence

#### Research Approach

- **Company employee enumeration**: Browse company page -> "People" tab
- **LinkedInDumper**: Extract employee data via LinkedIn API
- **the-endorser**: Map relationships between employees via skill endorsements
- **Epieos**: Email-to-LinkedIn lookup (reverse from email to profile)
- **Google dorking**: `site:linkedin.com/in "target" "company"`

#### Intelligence Value

- **Organizational structure**: Job titles, reporting chains, team compositions
- **Technology stack**: Skills endorsed, tools mentioned in job descriptions
- **Career timeline**: Employment history reveals past associations and security clearance implications
- **Contact harvesting**: Email format discovery for phishing or further OSINT
- **Professional network**: Connections reveal business relationships and advisory roles

### 3.5 Reddit Intelligence

#### Research Tools

- **Arctic Shift**: Large Reddit data dumps with searchable API
- **Pullpush**: Find deleted/removed Reddit content
- **REDARCS**: Reddit archives spanning 2005-2023
- **Reddit User Analyser / RedditMetis**: Analyze posting patterns, top subreddits, comment history
- **Reddit Comment Search/Lookup**: Search comments by username

#### Intelligence Value

Reddit users often share far more personal information than on other platforms:
- Posting history reveals interests, location hints, employment details
- Comment language patterns enable authorship analysis
- Throwaway accounts often share sensitive personal details
- Subreddit participation maps interests and potentially identifies real-world communities
- Deleted posts recoverable via Pullpush/Arctic Shift

### 3.6 Telegram Intelligence

#### Research Tools

- **Telegram Phone Number Checker** (Bellingcat): Check if phone numbers have Telegram accounts, retrieve username/name/ID. Requires Telegram API credentials. OPSEC warning: do not use personal account; fresh accounts work best from residential IPs
- **Telegago**: Google advanced search specifically for Telegram content
- **Telepathy**: Archive and analyze Telegram chat communication patterns
- **TeleSearch / tgworld / GroupDa**: Search channels, groups, bots by keyword
- **TeleTracker**: Python scripts for Telegram channel investigation
- **Telegram Nearby Map**: Find users broadcasting "nearby" status on a map
- **Telemetrio / TGStat**: Telegram channel analytics and statistics
- **TOsint**: Extract information from Telegram bots and channels

#### Telegram Bots for OSINT

A significant ecosystem of OSINT bots operates within Telegram:
- **Maigret OSINT bot**: Username search across 1,366 sites
- **HimeraSearch**: Phone, email, vehicle search
- **Detectiva**: Phone/email lookup with multiple search types
- **datXpert**: Leak search via IntelX
- **EyeTON**: TON wallet graph with linked profiles
- **getChatList**: Display user's group membership
- **SangMataInfo_bot**: Username/name change history tracking

#### Intelligence Value

- **Phone number pivot**: Telegram accounts are phone-linked; phone -> identity
- **Group membership**: Reveals political affiliations, criminal associations, interest groups
- **Message history**: Public channels preserve extensive communication records
- **Media files**: Photos/videos shared in groups may contain metadata
- **Bot interactions**: Users interact with bots revealing personal data (vehicle lookups, address searches)

### 3.7 TikTok Intelligence

#### Research Tools

- **Bellingcat TikTok Date Extract**: Extract exact post dates
- **Bellingcat TikTok Hashtag Analysis**: Analyze hashtag trends and usage
- **4cat**: Collect and analyze TikTok data at scale
- **Zeeschuimer**: Browser-based TikTok data collector

#### Intelligence Value

- Video metadata, sound usage patterns, duet/stitch chains
- Location visible in videos: storefronts, license plates, street signs
- Profile bio links to other platforms enable cross-platform pivoting
- Comment sections reveal associates and community connections

### 3.8 Discord Intelligence

#### Research Tools

- **Discord Chat Exporter**: Export channel histories
- **DiscordLeaks**: Leaked Discord server data
- **Disboard**: Discover public Discord servers by topic
- **Discord Sensor** (Telegram bot): Retrieve Discord account data

#### Intelligence Value

- Server membership reveals community affiliations
- Usernames may match across platforms (pivot with Sherlock/WhatsMyName)
- Voice channel activity patterns reveal timezone
- Linked accounts (Steam, GitHub, Spotify) provide cross-platform intelligence

### 3.9 Cross-Platform Username Enumeration

#### Primary Tools

| Tool | Coverage | Method |
|------|----------|--------|
| **Sherlock** | 400+ sites | URL construction + response analysis |
| **Maigret** | 1,366+ sites | Username dossier collection |
| **WhatsMyName** | JSON database | Pattern matching, used by SpiderFoot/Maltego |
| **Blackbird** | 600+ sites | Username + email search |
| **Holehe** | 120+ sites | Email account enumeration via password reset |
| **NexFil** | Social networks | Username availability checking |
| **Social Analyzer** | 1,000+ sites | API and scraping analysis |
| **User Searcher** | 2,000+ sites | Web-based username search |

#### Operational Methodology

1. Start with known username(s) from any platform
2. Run Sherlock/Maigret for broad enumeration: `sherlock username --print-found --csv`
3. Run holehe for email-based enumeration: `holehe target@email.com`
4. Cross-reference results manually — same username does not guarantee same person
5. Look for profile photo consistency, bio similarities, posting time correlations
6. Use `--tor` or `--proxy` flags to avoid IP-based blocking
7. Rate-limit requests to avoid detection; space out large-scale enumeration

---

## 4. Geolocation Methodology

### 4.1 Image Analysis for Geolocation

#### Step 1: Metadata Extraction

Before visual analysis, check for embedded data:
```bash
exiftool image.jpg          # Full EXIF dump
exiftool -gpslatitude -gpslongitude image.jpg  # GPS coordinates
exiftool -DateTimeOriginal image.jpg           # Capture timestamp
```

**Caveat**: Most social media platforms strip EXIF on upload. Metadata survives in:
- Direct messaging/file transfers (Telegram file mode, Signal, WhatsApp original quality)
- Forum uploads (some forums preserve EXIF)
- Email attachments
- Cloud storage links (Google Drive, Dropbox)

**Tools**: ExifTool (CLI, gold standard), ExifLooter, JIMPL (online), Jeffrey's EXIF Viewer (online)

#### Step 2: Visual Indicators for Location

**Natural indicators:**
- **Vegetation**: Tree species, seasonal state (deciduous vs. evergreen), agricultural crops
- **Terrain**: Mountains, coastline, desert, soil color
- **Weather**: Cloud patterns, precipitation, light quality
- **Sun position**: Shadow direction and length (see Section 4.2)
- **Stars**: Night sky photography can indicate hemisphere and approximate latitude

**Built environment indicators:**
- **Road markings**: Line colors, patterns, bollard styles are country-specific
- **Road signs**: Language, script, distance units, sign design conventions
- **License plates**: Format, color, and prefix indicate country/region
- **Power lines**: Pole design, voltage markings, insulator patterns
- **Architecture**: Building materials, roof styles, window designs
- **Utility infrastructure**: Manhole covers, fire hydrants, post boxes
- **Commercial signage**: Store chains, brand logos, local businesses (Google Maps searchable)
- **Phone numbers on signs**: Area codes indicate location

**Cultural indicators:**
- **Script/language**: On signs, graffiti, storefronts
- **Driving side**: Left-hand vs. right-hand traffic
- **Currency**: Prices on signs, ATM machines
- **Religious buildings**: Mosque minarets, church steeples, temple architecture
- **Clothing**: Traditional dress, uniform styles
- **Vehicle types**: Popular car brands vary by country

#### Step 3: Reverse Image Search

Run the image through multiple engines — each has different coverage:
- **Google Lens**: Best for landmark recognition and similar images
- **Yandex Images**: Strongest facial recognition capabilities; excellent for Eastern European/Russian content
- **TinEye**: Best for finding exact copies and earlier uploads (temporal analysis)
- **Bing Visual Search**: Good general coverage
- **Baidu Image Search**: Essential for Chinese content
- **PimEyes**: Face-specific search (paid, controversial)
- **FaceCheck.ID**: Face-based internet search
- **Lenso.ai**: Reverse image with facial recognition
- **Search4faces**: People finding by photo

#### Step 4: Geospatial Verification

Once a candidate location is identified:
- **Google Earth Pro**: Compare satellite imagery, measure distances, check historical imagery for temporal validation
- **Google Street View**: Ground-truth candidate locations against image features
- **Mapillary / KartaView**: Crowdsourced street imagery (covers areas Google doesn't)
- **Sentinel Hub**: Free satellite imagery for large-area analysis
- **SAS Planet**: Download and compare satellite imagery from multiple providers
- **Apple Maps**: Sometimes has more recent imagery than Google in certain regions

### 4.2 Shadow and Sun Position Analysis

Shadow analysis is a powerful chronolocation and geolocation technique.

#### The Principle

The sun's position (azimuth and elevation) is determined by three variables: **latitude**, **date**, and **time**. If two are known, the third can be calculated. Shadows reveal the sun's elevation angle (via object height / shadow length ratio) and azimuth (shadow direction).

#### Tools

**SunCalc (suncalc.org):**
- Input: location, date, time, object height
- Output: sun azimuth, elevation angle, shadow length, sunrise/sunset times
- Use case: Given a candidate location and date, verify if shadows match the claimed time
- Outputs data including: times of dawn/sunrise/culmination/sunset/dusk, duration of daylight, distance from sun, altitude and azimuth angles, shadow length for given object height
- Features animation mode showing shadow progression through the day
- Limitation: Can only test guessed locations by trial and error, not calculate location from shadow alone

**ShadowFinder (Bellingcat):**
- Input: object height + shadow length (or sun elevation angle), date, time
- Output: Band on world map showing all possible locations where that shadow could occur
- Yellow area = exact match; Purple area = 20% error band; Grey = daylight areas
- Available as Google Colab notebook (browser-based, no setup) or Python library
- Critical requirement: needs date and time of the image (social media strips this metadata)
- Accuracy depends on precision of input measurements — smaller output area = more useful

**ShadeMap (shademap.app):**
- Real-time shadow simulation on 3D map
- Useful for verifying shadows in urban environments with tall buildings

**ShadowMap:**
- Similar shadow simulation tool, alternative to ShadeMap

#### Methodology

1. **Identify an object of known or estimable height** in the image (person ~1.7m, car ~1.5m, street lamp ~6-8m, utility pole ~10-12m)
2. **Measure shadow length** relative to object height (use pixel ratios if absolute measurements unavailable)
3. **Determine shadow direction** relative to compass bearings using landmarks or map orientation
4. **Calculate sun elevation**: `elevation = arctan(object_height / shadow_length)`
5. **If date/time is known**: Use SunCalc to verify location candidates
6. **If location is known**: Use SunCalc to determine time of day
7. **If neither is known**: Use ShadowFinder to generate possible location bands, then cross-reference with visual indicators
8. **Beware**: Object and shadow must be orthogonal to the camera for accurate measurement. Non-perpendicular angles introduce significant error

### 4.3 Satellite Imagery Analysis

#### Free Satellite Imagery Sources

| Platform | Resolution | Revisit Rate | Coverage |
|----------|-----------|--------------|----------|
| Google Earth Pro | Sub-meter | Varies (months-years) | Global |
| Sentinel Hub (Copernicus) | 10m (optical) | 5 days | Global |
| USGS EarthExplorer | 15-30m (Landsat) | 16 days | Global |
| Zoom Earth | Various | Near real-time | Global |
| Planet Explorer | 3-5m (free tier) | Daily | Global |
| Maxar (limited free) | 30cm | Varies | Select areas |

#### Commercial High-Resolution Sources

- **Maxar**: 30cm resolution, historical archive
- **Airbus (Pleiades)**: 50cm resolution
- **Planet (SkySat)**: 50cm resolution, daily collection
- **Umbra Space**: SAR (radar) imagery, works through clouds
- **SkyFi**: Marketplace aggregating multiple providers
- **Apollo Mapping**: Broker for multiple satellite providers
- **SOAR.earth**: Satellite imagery marketplace

#### Analysis Techniques

- **Change detection**: Compare imagery across dates to identify construction, destruction, troop movements
- **Temporal analysis**: Google Earth Pro's historical imagery slider shows changes over time
- **Measurement**: Use Google Earth Pro's ruler tool for distances, areas, and building heights (shadow-based)
- **Spectral analysis**: Sentinel Hub supports custom band combinations for vegetation health, water bodies, burn scars
- **SAR analysis**: Synthetic Aperture Radar penetrates clouds and works at night; useful for maritime surveillance

#### Accuracy Considerations (from Bellingcat toolkit)

- **Absolute accuracy**: Does the pixel position match the real-world coordinate?
- **Relative accuracy**: Are distances between objects in the image correct?
- **Resolution**: Higher resolution = more accurate feature identification
- **Orthorectification**: Curved earth + satellite angle + terrain altitude require correction; different providers use different algorithms
- **CE90 vs RMSE**: Two different accuracy measurement standards used by different agencies
- **Political bias**: Google Maps restricts imagery of certain military/government facilities; different countries see different borders

### 4.4 Flight and Maritime Tracking

**Aviation:**
- **ADS-B Exchange**: Unfiltered global flight tracking (doesn't honor military/VIP blocking requests)
- **Bellingcat adsb-history**: Collect and query historical ADS-B data by geographic region, altitude, bearing, aircraft type
- **FlightRadar24**: Popular tracker, but filters some military/government aircraft
- **AirNav RadarBox**: Flight tracking with historical data
- **Airframes / Airfleets**: Aircraft registration databases

**Maritime:**
- **MarineTraffic**: Global ship tracking via AIS
- **VesselFinder**: Ship tracking with historical routes
- **ShipFinder**: Real-time vessel positions
- **Equasis**: Ship safety and inspection records
- **Tokyo MOU**: Port state control inspection database

### 4.5 Street-Level Geolocation Clues by Region

**Identifying country from road features:**
- **Bollard shapes**: Unique to countries (Dutch bollards are distinctive)
- **Road surface**: Asphalt quality and color varies by GDP
- **Lane markings**: White vs. yellow center lines, dashed patterns
- **Curb design**: Height, material, color coding
- **Traffic lights**: Horizontal vs. vertical mounting, LED vs. incandescent
- **Pedestrian crossings**: Pattern and paint style vary by country

**Reference resources:**
- GeoGuessr communities maintain detailed country-identification guides
- Google Street View coverage maps show where imagery exists
- Mapillary fills gaps in Google's coverage, especially in developing countries

---

## 5. Email and Domain Intelligence

### 5.1 Email Investigation Tools

| Tool | Capability | Method |
|------|-----------|--------|
| **Holehe** | Check 120+ sites for email registration | Password reset endpoint probing |
| **Epieos** | Email to LinkedIn, Google, social accounts | API-based lookups |
| **Hunter.io** | Find email format for company domain | Pattern analysis + verification |
| **theHarvester** | Emails, subdomains, IPs from 40+ sources | Multi-source aggregation |
| **h8mail** | Breach data search for email | Breach database queries |
| **GHunt** | Google account investigation from email | Google API exploitation |
| **Have I Been Pwned** | Breach exposure check | Breach database (API key required) |
| **pwnedOrNot** | Breach check + password dump search | HIBP API + dump scanning |
| **LeakCheck** | 7.5B+ breach entries | Commercial breach database |
| **DeHashed** | Breach search with password data | Commercial platform |
| **InfoStealers** | Infostealer log indexing | Darknet log aggregation |

#### Email Investigation Workflow

1. **Validate email exists**: EmailHippo, Reacher, or Verify Email
2. **Check breach exposure**: HIBP, LeakCheck, DeHashed
3. **Enumerate registered accounts**: Holehe (automated password reset probing)
4. **Find associated profiles**: Epieos (email -> LinkedIn, Google), GHunt (Google ecosystem)
5. **Harvest related emails**: Hunter.io (find pattern: first.last@domain.com)
6. **Search paste sites**: `site:pastebin.com "target@email.com"`
7. **Search code repositories**: `"target@email.com" site:github.com`

### 5.2 Domain Intelligence

#### DNS Enumeration

```bash
# Subdomain discovery
theHarvester -d target.com -b all
subfinder -d target.com
amass enum -d target.com

# DNS record types
dig target.com ANY
dig target.com MX          # Mail servers
dig target.com TXT         # SPF, DKIM, DMARC, domain verification records
dig target.com NS          # Nameservers
dig target.com SOA         # Start of Authority
```

#### Web Analysis (web-check / Lissy93)

The web-check tool performs comprehensive website analysis:
- **DNS records**: A, AAAA, MX, NS, CNAME, TXT
- **SSL chain analysis**: Certificate validity, issuer, organizational details
- **HTTP headers**: Security policies, caching, server identification
- **Technology stack**: Framework/CMS/service detection
- **Cookies**: Session management and tracking analysis
- **Robots.txt**: Excluded directories (often reveal sensitive paths)
- **Redirect chain**: Full HTTP redirect trace
- **Server location**: Geolocation with coordinates and timezone
- **Lighthouse audit**: Performance, accessibility, SEO scoring
- **Associated hosts**: Subdomain and related domain enumeration

#### WHOIS and Certificate Intelligence

- **WHOIS lookup**: Registration details, registrant, nameservers, dates
- **DomainTools**: Historical WHOIS, reverse WHOIS, domain monitoring
- **Whoxy**: WHOIS history and reverse lookups
- **crt.sh**: Certificate Transparency log search — reveals subdomains from SSL certificates
- **Censys**: Certificate search and host enumeration
- **SecurityTrails**: Historical DNS data, associated domains, IP history

#### Infrastructure Fingerprinting

- **Shodan**: `hostname:target.com` — find internet-facing services, banners, vulnerabilities
- **Censys**: Host and certificate search
- **FOFA**: Chinese equivalent to Shodan with broader Asian coverage
- **ZoomEye**: Network device and web service search
- **BuiltWith**: Technology profiling (CMS, analytics, CDN, frameworks)
- **Wappalyzer**: Browser extension for real-time technology detection
- **Netlas.io**: Internet-wide scanning and analysis

### 5.3 theHarvester Deep Dive

theHarvester queries 40+ data sources for email, subdomain, IP, and hostname intelligence:

**Free sources (no API key):**
- Baidu, DuckDuckGo, crt.sh, RapidDNS, DNSDumpster

**Freemium sources (free tier available):**
- Brave Search, Censys, GitHub code search, Hunter.io (50 free/month)

**Paid sources (subscription required):**
- Shodan ($69-359/month), SecurityTrails ($500/month), IntelX ($2900/year), BuiltWith ($2950/year), Onyphe ($587/month)

**OPSEC implications:**
- Multiple services log requesting IP addresses — use VPN/proxy
- API keys create financial paper trails linking you to reconnaissance
- Large-scale enumeration against a single domain triggers security monitoring
- Certificate transparency queries are partially visible to target
- Stagger requests across time to avoid detection

### 5.4 SpiderFoot: Automated OSINT Framework

SpiderFoot automates reconnaissance across 200+ modules with a publisher/subscriber architecture where discoveries cascade into further automated searches.

**Entity types supported**: IP, domain, hostname, ASN, email, phone, username, person name, cryptocurrency address

**Key module categories:**
- DNS operations: brute-forcing, zone transfers, passive DNS
- IP intelligence: geolocation, reputation, hosting provider, ASN
- Breach data: HIBP, leaked credentials, compromised databases
- Cloud storage: S3, Azure Blob, Google Cloud, DigitalOcean enumeration
- Social media: Account enumeration across 500+ platforms
- Cryptocurrency: Bitcoin/Ethereum address tracking
- Threat intelligence: AlienVault OTX, GreyNoise, Shodan, SecurityTrails
- Malware/Phishing: OpenPhish, PhishTank, Hybrid Analysis

**Operational features:**
- Web UI + CLI interfaces
- 37 pre-defined YAML correlation rules
- Tor integration for dark web searching
- CSV/JSON/GEXF export
- External tool integration: Nmap, DNSTwist, Whatweb, CMSeeK

---

## 6. Phone Number Intelligence

### 6.1 Tools

| Tool | Capability |
|------|-----------|
| **PhoneInfoga** | Advanced phone number intelligence: carrier, line type, location, format validation |
| **Truecaller** | Reverse lookup with crowd-sourced caller ID database |
| **Sync.ME** | Caller ID and spam identification |
| **Telegram Phone Number Checker** | Check if number has Telegram account, retrieve username/name/ID |
| **CallerID Test** | Carrier and gateway information |
| **FreeCarrierLookup** | Carrier name and email-to-SMS gateway |
| **Twilio Lookup API** | Programmatic carrier type and location (~$0.01/query) |
| **Spy Dialer** | Voicemail retrieval and owner name lookup |
| **haveibeenzuckered** | Check against 2021 Facebook breach (533M records with phone numbers) |

### 6.2 Phone Number OSINT Workflow

1. **Format validation**: Ensure number is in E.164 format (+CountryCodeNumber)
2. **Carrier lookup**: PhoneInfoga or FreeCarrierLookup — determines mobile vs. landline, carrier name, country
3. **Reverse lookup**: Truecaller, Sync.ME, ThatsThem — may reveal owner name
4. **Social media pivot**: Telegram Phone Number Checker, WhatsApp (check if number has account), Signal
5. **Breach search**: haveibeenzuckered (Facebook breach), LeakCheck, DeHashed
6. **Google dorking**: `"phone number" site:facebook.com`, `"phone number" site:linkedin.com`

### 6.3 Telegram-Specific Phone Research

Using Bellingcat's Telegram Phone Number Checker:
- Requires Telegram API credentials (API_ID, API_HASH from my.telegram.org)
- Requires an active Telegram account phone number for queries
- Returns: username, display name, user ID, optional profile photo
- **OPSEC**: Do not use personal account (may get banned). Use fresh accounts from residential IPs. Known VPN IPs often blocked
- Output as JSON to `results.json`; supports batch processing

---

## 7. Cryptocurrency Tracing

### 7.1 Blockchain Fundamentals for Investigators

All transactions on public blockchains (Bitcoin, Ethereum, etc.) are permanently recorded and publicly viewable. Cryptocurrency is pseudonymous, not anonymous — addresses are not directly linked to identities, but transaction patterns, exchange interactions, and operational mistakes can deanonymize users.

### 7.2 Bitcoin Investigation

**Block Explorers:**
- **Blockchain.com Explorer**: Transaction and address lookup
- **BlockExplorer.com**: Bitcoin blockchain search
- **Blockchair**: Multi-chain explorer with privacy tools
- **OXT.me**: Advanced Bitcoin analysis with transaction graphs

**Analysis Techniques:**
- **Transaction graph analysis**: Follow the flow of funds between addresses
- **Cluster analysis**: Group addresses likely controlled by same entity (common-input-ownership heuristic: if multiple addresses are inputs to the same transaction, they're likely controlled by the same wallet)
- **Exchange identification**: Known exchange deposit addresses enable identification when funds move to/from exchanges
- **Timing analysis**: Transaction timestamps correlated with timezone activity patterns
- **Amount analysis**: Round numbers or specific amounts may indicate pricing patterns
- **Change address identification**: The "change" output of a transaction typically returns to the sender's wallet

### 7.3 Ethereum Investigation

**Primary Tool: Etherscan (etherscan.io)**
- Address lookup: Balance, transaction history, first/last transaction dates
- ENS names: .eth usernames (e.g., vitalik.eth) map to addresses. Many users use .eth names on social media — direct pivot from Twitter handle to wallet
- Transaction hash lookup: Sender, receiver, amount, block, timestamp
- Analytics: Balance over time, transaction frequency charts
- Smart contract interaction history
- Token transfers (ERC-20, ERC-721 NFTs)
- Watchlist feature: Monitor addresses and receive email notifications on activity

**Social media pivot**: Users displaying .eth names on X/Twitter profiles directly reveal their wallet address and full transaction history

### 7.4 Advanced Cryptocurrency Analysis

**Commercial Analysis Platforms:**
- **Chainalysis**: Enterprise blockchain analysis (used by law enforcement)
- **Elliptic**: Cryptocurrency compliance and investigation
- **CipherTrace**: Cryptocurrency intelligence (now part of Mastercard)
- **Crystal Blockchain**: Transaction monitoring and risk scoring

**Open-Source/Free Tools:**
- **Wallet Explorer**: Bitcoin wallet clustering
- **GraphSense**: Open-source cryptocurrency analytics
- **Breadcrumbs.app**: Visual transaction tracing (free tier available)

**Mixer/Tumbler Analysis:**
- Mixer services (Tornado Cash, Wasabi Wallet CoinJoin) deliberately obscure transaction trails
- Heuristics for detecting mixer usage: standardized output amounts, timing patterns, known mixer addresses
- Tornado Cash sanctioned by OFAC in August 2022 — using it is legally risky in US jurisdiction

**NFT Investigation:**
- NFT ownership and transfer history is on-chain and fully transparent
- OpenSea, Blur, and other marketplaces provide user-friendly interfaces to transaction data
- NFT metadata (images, descriptions) often stored on IPFS — examine IPFS hashes for associated content
- SpyGGbot (Telegram): TON balances, NFT owners, Fragment usernames

### 7.5 Cryptocurrency OPSEC Pitfalls (What Investigators Look For)

- **Exchange KYC**: When crypto touches a regulated exchange, identity verification links address to person
- **IP address logging**: Node operators and some wallet services log connecting IPs
- **Address reuse**: Using the same address repeatedly enables easier tracking
- **Dust attacks**: Sending tiny amounts to addresses to track when they're combined with other funds
- **Blockchain analytics**: Machine learning models increasingly effective at deanonymizing transaction patterns
- **Social media correlation**: Posting wallet addresses for donations, NFT profile pictures linking to on-chain identity

---

## 8. Dark Web OSINT

### 8.1 Access Infrastructure

**Tor Network:**
- Tor Browser: Primary access method for .onion sites
- Tor over VPN: Connect to VPN first, then Tor (ISP sees VPN, not Tor usage)
- Whonix: Dedicated VM pair routing all traffic through Tor
- Tails: Amnesic OS with built-in Tor

**I2P Network:**
- Separate darknet with .i2p addresses
- Better for peer-to-peer applications
- Smaller user base than Tor

### 8.2 Dark Web Search Engines

- **Ahmia**: Clearnet search engine for .onion sites (filters illegal content)
- **Torch**: Long-running dark web search engine
- **Haystack**: Indexes over 1.5 billion pages
- **DarkSearch**: API-accessible dark web search
- **Kilos**: Darknet market search (primarily drug markets)
- **Recon**: Darknet market vendor search and review aggregation

### 8.3 Dark Web Monitoring and Intelligence

**Paste site monitoring:**
- Dark web paste sites publish leaked credentials, dox documents, and communications
- Monitor: doxbin (clearnet mirror exists), dark web-specific paste services

**Forum monitoring:**
- Cybercrime forums (RaidForums successors, BreachForums, XSS, Exploit.in)
- Hacking communities share tools, techniques, and stolen data
- Threat intelligence feeds aggregate forum postings

**Marketplace intelligence:**
- Market listings reveal: vendor locations (shipping origins), product descriptions, pricing
- Vendor reviews may contain identifying information
- PGP key reuse across markets enables vendor tracking
- Wallet addresses used for payments are traceable on blockchain

### 8.4 OPSEC for Dark Web Research

**Mandatory precautions:**
- **Never** access dark web from your normal OS or browser
- Use dedicated VM (Whonix or Tails) exclusively
- Disable JavaScript in Tor Browser (Security Level: Safest)
- Never download or open files from dark web on a non-isolated system
- Never log into personal accounts while conducting dark web research
- Assume all dark web sites are potentially hostile (browser exploits, deanonymization attacks)
- Do not create accounts on dark web forums with email addresses used elsewhere
- Use dedicated sock puppet identities for any necessary forum registration

**Evidence preservation:**
- Screenshot (do not download) content of interest
- Use Bellingcat's auto-archiver for systematic content preservation
- Hash all evidence immediately: `sha256sum screenshot.png`
- Maintain detailed timestamps and access logs
- Archive.today can snapshot clearnet mirrors of dark web content

---

## 9. Structured Analytic Techniques

### 9.1 Analysis of Competing Hypotheses (ACH)

ACH is a structured methodology for evaluating multiple hypotheses against available evidence, developed by Richards Heuer at the CIA.

#### Methodology

1. **Identify all plausible hypotheses** (minimum 3-5; avoid anchoring on the most obvious)
2. **List significant evidence and assumptions** for each hypothesis
3. **Construct a matrix**: hypotheses as columns, evidence as rows
4. **Evaluate each evidence item against each hypothesis**:
   - **C** (Consistent): Evidence supports the hypothesis
   - **I** (Inconsistent): Evidence contradicts the hypothesis
   - **N** (Neutral/Not applicable): Evidence neither supports nor contradicts
5. **Identify diagnostics**: Evidence that is inconsistent with one hypothesis but consistent with another is the most valuable
6. **Reject hypotheses** with the most inconsistent evidence
7. **Assess sensitivity**: Determine which evidence items, if wrong, would change the conclusion
8. **Report conclusions** with confidence level and key assumptions

#### ACH Matrix Example

| Evidence | H1: State Actor | H2: Criminal Group | H3: Insider Threat |
|----------|----------------|--------------------|--------------------|
| Sophisticated malware | C | I | N |
| Financial motive clear | I | C | C |
| Access to internal systems | N | I | C |
| Attack during business hours | N | N | C |
| Known APT infrastructure | C | I | I |
| **Inconsistencies** | **1** | **3** | **1** |

**Interpretation**: H2 (Criminal Group) has the most inconsistencies and should be deprioritized. H1 and H3 remain viable and require additional evidence to differentiate.

### 9.2 Link Analysis

Link analysis maps relationships between entities (people, organizations, locations, accounts, transactions) to reveal hidden connections.

#### Entity Types

- **Person**: Name, aliases, identifiers
- **Organization**: Company, group, government agency
- **Location**: Physical address, coordinates, jurisdiction
- **Account**: Social media, financial, email
- **Device**: Phone number, IMEI, MAC address, IP address
- **Event**: Date, time, location, participants
- **Financial**: Bank account, cryptocurrency wallet, transaction

#### Visualization Tools

- **Maltego**: Industry-standard link analysis with transforms for automated data enrichment. Integrates with WhatsMyName, SpiderFoot, Shodan, and dozens of other OSINT sources
- **Obsidian**: Graph-based note-taking with link visualization (free for personal use)
- **Neo4j**: Graph database for large-scale relationship mapping
- **Gephi**: Open-source network analysis and visualization
- **Analyst's Notebook (IBM i2)**: Enterprise investigation platform
- **LinkScope**: Open-source link analysis for OSINT
- **DataWalker**: Graph-based data exploration

#### Methodology

1. **Identify seed entities**: Starting points (known names, accounts, addresses)
2. **Enumerate connections**: Use OSINT tools to find relationships
3. **Build the graph**: Map entities and their connections
4. **Identify clusters**: Groups of densely connected entities suggest organizational structure
5. **Find bridges**: Entities connecting otherwise separate clusters are key intermediaries
6. **Analyze centrality**: Most-connected entities are likely leaders or key facilitators
7. **Temporal overlay**: Add timestamps to edges to show how relationships evolve
8. **Validate**: Cross-reference connections through multiple independent sources

### 9.3 Timeline Analysis

Timeline analysis reconstructs the sequence of events to establish causation, identify gaps, and detect inconsistencies.

#### Construction

1. **Collect all timestamped data**: Social media posts, transaction records, travel data, communications metadata, login logs
2. **Normalize timestamps**: Convert all times to a single timezone (UTC recommended)
3. **Plot on timeline**: Use tools like TimelineJS, time.graphics, or spreadsheet-based timelines
4. **Identify gaps**: Periods without activity may indicate: device was off, VPN/Tor was used, different device was used, subject was sleeping/traveling
5. **Correlate across sources**: Events on different platforms that coincide temporally suggest connection
6. **Identify anomalies**: Activity outside normal patterns (3 AM posts, transactions during stated travel)

#### Tools

- **TimelineJS** (by Knight Lab): Free, interactive timeline builder
- **time.graphics**: Online timeline creation
- **Bellingcat ukraine-timemap**: Example of event timeline mapping
- **Atlos**: Collaborative investigation platform with timeline features
- **Uwazi**: Document management with timeline capabilities

### 9.4 Chronolocation

Chronolocation determines **when** a photo or video was taken using temporal indicators:

**Astronomical indicators:**
- Sun position (azimuth + elevation) via SunCalc
- Shadow length and direction
- Moon phase (visible in images)
- Star positions for nighttime images

**Environmental indicators:**
- Weather conditions (cross-reference with historical weather data)
- Seasonal vegetation state
- Lighting conditions (golden hour, blue hour, overcast)
- Snow presence/absence on ground and rooftops

**Digital indicators:**
- Social media posting time (caveat: not necessarily capture time)
- Metadata timestamps (when available)
- Screen content visible in photos (dates on computer screens, TV broadcasts)
- Newspaper/poster dates visible in frame

**Infrastructure indicators:**
- Construction progress (compare with known project timelines)
- Building presence/absence (compare with satellite imagery dates)
- Vehicle models (establish "no earlier than" date)
- Fashion and technology visible (phones, clothing styles)

### 9.5 Pattern of Life Analysis

Pattern of life analysis builds a behavioral profile of a target over time:

**Data sources:**
- Social media posting times and locations
- Transaction patterns (cryptocurrency, if known)
- Travel data (flight/maritime tracking, geotagged posts)
- Communication patterns (forum posting frequency, response times)
- Online/offline status (Telegram, WhatsApp, Discord activity indicators)

**Analysis outputs:**
- **Daily rhythm**: Wake time, work hours, leisure time, sleep time
- **Weekly patterns**: Workday vs. weekend behavior differences
- **Geographic patterns**: Home location, work location, frequent destinations
- **Social patterns**: Regular communication partners, group affiliations
- **Anomaly detection**: Deviations from normal pattern may indicate: travel, incident, operational activity, countersurveillance awareness

### 9.6 Confidence Assessment Framework

Every analytical conclusion should carry a confidence rating:

| Level | Label | Criteria |
|-------|-------|---------|
| 1 | Very Low | Single source, unverified, speculative |
| 2 | Low | Limited sources, some corroboration, significant assumptions |
| 3 | Moderate | Multiple sources, partial corroboration, some assumptions |
| 4 | High | Multiple independent sources, strong corroboration, few assumptions |
| 5 | Very High | Overwhelming evidence, multiple independent verifications, minimal assumptions |

**Key distinctions:**
- **Confirmed**: Directly observed or verified through primary evidence
- **Probable**: Strong indirect evidence, logical consistency
- **Possible**: Some supporting evidence, alternative explanations exist
- **Doubtful**: Limited evidence, significant counterindicators
- **Improbable**: Contradicted by most available evidence

### 9.7 Cognitive Bias Awareness

Analysts must actively counteract:

- **Confirmation bias**: Seeking evidence that confirms existing hypothesis; counter with ACH
- **Anchoring bias**: Over-relying on first piece of information; counter by generating multiple hypotheses before examining evidence
- **Availability bias**: Overweighting easily recalled or recent information; counter with systematic evidence review
- **Mirror imaging**: Assuming the target thinks like you; counter by studying target's cultural and operational context
- **Groupthink**: Conforming to team consensus; counter with devil's advocate assignment and independent analysis before group discussion
- **Vividness bias**: Overweighting dramatic evidence over mundane but more reliable data; counter by scoring evidence objectively
- **Satisficing**: Accepting the first adequate explanation; counter by requiring minimum of 3 hypotheses

---

## 10. Evidence Preservation and Chain of Custody

### 10.1 Archiving Methodology

Online content is ephemeral. Preserve evidence immediately upon discovery:

**Manual archiving:**
- Full-page screenshots with visible URL bar and timestamp
- Use browser developer tools to capture full-page screenshots (Firefox: Shift+F2, then `:screenshot --fullpage`)
- Save as PDF: Print -> Save as PDF preserves layout
- Download raw HTML: Ctrl+S -> Complete webpage
- Video download: yt-dlp for YouTube, social media platforms

**Automated archiving:**
- **Bellingcat auto-archiver**: Archives links from Google Sheets to local/S3 storage. Supports social media, videos, images, webpages. Automated batch processing with status tracking
- **Archive.today** (archive.ph): Saves permanent snapshots of web pages
- **Wayback Machine** (web.archive.org): Save page now feature for permanent archiving
- **SingleFile** (browser extension): Saves complete web page as single HTML file
- **Webrecorder**: Creates high-fidelity web archives (WARC format)
- **Hunchly**: Paid investigation tool that automatically captures and hashes every page visited

### 10.2 Hash-Based Integrity

```bash
# Generate hashes immediately upon evidence collection
sha256sum evidence_file.png > evidence_file.png.sha256

# Verify later
sha256sum -c evidence_file.png.sha256

# For directories
find ./evidence/ -type f -exec sha256sum {} \; > evidence_manifest.sha256
```

### 10.3 Documentation Standards

For each piece of evidence, record:
- **Source URL**: Full URL at time of collection
- **Collection timestamp**: UTC time of access
- **Collector identity**: Who collected it (may be pseudonymous)
- **Collection method**: Tool/browser used, screenshot vs. download
- **Hash value**: SHA-256 of original file
- **Context**: Why this evidence is relevant, what it supports
- **Archive copies**: URLs of archive.today / Wayback Machine copies

---

## 11. Integrated OSINT Investigation Frameworks

### 11.1 OSINT Framework (osintframework.com)

A visual taxonomy of free OSINT tools organized by investigation type:
- Categories marked with (T) require local tool installation
- Categories marked with (D) indicate Google Dork approaches
- Categories marked with (R) require registration
- Categories marked with (M) require manual URL editing

### 11.2 Bellingcat Investigation Toolkit

360+ tools organized across categories (from toolkit-main analysis):
- **Image/Video**: Facial recognition, metadata extraction, reverse image search, miscellaneous
- **Maps & Satellites**: Maps, satellite imagery, street view
- **Social Media**: Facebook, Instagram, Twitter/X, YouTube, Telegram, TikTok, multiple platforms, other platforms
- **Other**: Archiving, companies & finance, conflict, data organization & analysis, environment & wildlife, geolocation, people, transport, websites

Notable Bellingcat-developed tools:
- **ShadowFinder**: Shadow-based geolocation
- **auto-archiver**: Automated evidence preservation
- **telegram-phone-number-checker**: Phone-to-Telegram mapping
- **uniform-timezone**: Browser extension standardizing times across social media
- **ukraine-timemap**: Conflict event timeline mapping
- **TikTok date extract / hashtag analysis**: TikTok investigation utilities
- **adsb-history**: Aircraft tracking data collection and query

### 11.3 IntelTechniques (Michael Bazzell)

25 investigation tool categories designed as supplements to OSINT Techniques (11th Edition):
Search Engines, Facebook, X (Twitter), Instagram, LinkedIn, Communities, Email Addresses, Usernames, Names, Addresses, Telephone Numbers, Maps, Documents, Pastes, Images, Videos, Domains, IP Addresses, Business & Government, Vehicles, Virtual Currencies, Breaches & Leaks, Live Audio Streams, Live Video Streams, APIs

All queries execute within the user's browser — no data collected or stored by the tool pages.

### 11.4 Investigation Workflow Template

```
Phase 1: SCOPE
  - Define intelligence requirements
  - Identify known selectors (names, emails, usernames, phone numbers, addresses)
  - Set legal and ethical boundaries
  - Choose appropriate OPSEC level based on target threat model

Phase 2: COLLECT
  - Username enumeration (Sherlock, Maigret, WhatsMyName)
  - Email investigation (Holehe, HIBP, Hunter.io, theHarvester)
  - Phone number lookup (PhoneInfoga, Truecaller, Telegram checker)
  - Social media deep-dive (platform-specific tools per Section 3)
  - Domain/infrastructure mapping (theHarvester, SpiderFoot, web-check)
  - Image and geolocation analysis (reverse image, SunCalc, ShadowFinder)
  - Dark web monitoring (Ahmia, forum archives, paste sites)
  - Cryptocurrency tracing (Etherscan, blockchain explorers)

Phase 3: PROCESS
  - Normalize data (deduplicate, standardize formats, UTC timestamps)
  - Build entity database (link analysis graph)
  - Construct timeline (chronological event sequence)
  - Preserve evidence (hash, archive, document)

Phase 4: ANALYZE
  - Apply structured analytic techniques (ACH, link analysis, pattern of life)
  - Identify intelligence gaps
  - Generate hypotheses and test against evidence
  - Assess confidence levels

Phase 5: REPORT
  - Key findings with confidence ratings
  - Evidence chain for each finding
  - Gaps and limitations
  - Recommendations for further collection
  - OPSEC review (what traces did this investigation leave?)
```

---

## 12. Legal and Ethical Considerations

### 12.1 Legal Boundaries

- **CFAA (US)**: Accessing systems without authorization is illegal. OSINT should only use publicly available information or authorized access
- **GDPR (EU)**: Processing personal data requires legal basis. Investigative journalism has exemptions; commercial OSINT may not
- **ECPA (US)**: Intercepting electronic communications without consent is illegal. Passive observation of public posts is generally permitted
- **Platform Terms of Service**: Automated scraping often violates ToS. Consider legal risk of tool usage
- **Right to be Forgotten (EU)**: Individuals can request removal of search results; publishing information a subject has requested removed carries legal risk

### 12.2 Ethical Guidelines

- **Proportionality**: Collection should be proportional to the investigation's importance
- **Minimization**: Collect only what is needed; do not harvest bulk personal data without purpose
- **Do no harm**: Consider whether publishing findings could endanger the subject or third parties
- **Source protection**: Never expose how information was obtained if it could compromise future access or endanger sources
- **Accuracy**: Verify before concluding. False accusations based on OSINT can destroy lives
- **Bias awareness**: Apply structured analytic techniques to counter cognitive biases
- **Documentation**: Maintain clear records of methodology for accountability and reproducibility

---

## 13. Tool Reference Quick-Start

### 13.1 Essential CLI Tool Installation

```bash
# Username enumeration
pip install sherlock-project
pip install maigret

# Email OSINT
pip install holehe

# Domain/email/IP harvesting
pip install theHarvester

# Phone number intelligence
pip install phoneinfoga  # or download binary

# Automated OSINT framework
pip install spiderfoot

# Image metadata
sudo apt install libimage-exiftool-perl  # or: brew install exiftool

# Shadow analysis
pip install shadowfinder

# Website analysis
docker run -p 3000:3000 lissy93/web-check

# Archive tools
pip install yt-dlp              # Video downloading
pip install auto-archiver        # Bellingcat archiver
```

### 13.2 Essential Web-Based Tools

| Purpose | Tool | URL |
|---------|------|-----|
| Reverse image | Google Lens | lens.google.com |
| Reverse image (faces) | Yandex Images | yandex.com/images |
| Reverse image (exact copies) | TinEye | tineye.com |
| Sun/shadow analysis | SunCalc | suncalc.org |
| Shadow geolocation | ShadowFinder | Google Colab |
| Breach check | HIBP | haveibeenpwned.com |
| Username check | WhatsMyName | whatsmyname.app |
| Domain WHOIS | DomainTools | whois.domaintools.com |
| Certificate search | crt.sh | crt.sh |
| Internet device search | Shodan | shodan.io |
| Web archiving | Archive.today | archive.ph |
| Web archiving | Wayback Machine | web.archive.org |
| Flight tracking | ADS-B Exchange | globe.adsbexchange.com |
| Ship tracking | MarineTraffic | marinetraffic.com |
| Ethereum blockchain | Etherscan | etherscan.io |
| Bitcoin blockchain | Blockchain.com | blockchain.com/explorer |
| Dark web search | Ahmia | ahmia.fi |
| Satellite imagery | Sentinel Hub | apps.sentinel-hub.com |
| Satellite imagery | Google Earth | earth.google.com |
| Website analysis | web-check | web-check.as93.net |

---

## Source Attribution

This document synthesizes tradecraft from:
- Bellingcat Investigation Toolkit (360+ tools, toolkit-main repository)
- awesome-osint (github.com/jivoi/awesome-osint)
- OSINT Mind Maps (github.com/sinwindie/OSINT)
- OSINT Stuff Tool Collection (github.com/cipher387/osint_stuff_tool_collection)
- IntelTechniques (inteltechniques.com/tools) — Michael Bazzell methodology
- OSINT Framework (osintframework.com)
- Tool-specific repositories: Sherlock, Holehe, theHarvester, SpiderFoot, Osintgram, WhatsMyName, pwnedOrNot, ShadowFinder, web-check, auto-archiver, Telegram Phone Number Checker
- Richards Heuer, "Psychology of Intelligence Analysis" (ACH methodology)
