<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Defensive Security Deep Training — CIPHER Knowledge Base

Generated: 2026-03-14
Sources: crowdsec-master, prowler-master, ansible-collection-hardening-master, awesome-incident-response, awesome-threat-detection

---

## 1. CrowdSec — Behavioral Detection Engine Architecture

### 1.1 Core Architecture: Parser -> Scenario -> Decision Pipeline

CrowdSec operates as an IDS/IPS with a three-stage pipeline:

1. **Acquisition** — Log sources are read (syslog, file tail, journalctl, cloudwatch, etc.)
2. **Parsers** — YAML-defined grok/expression nodes extract structured fields from raw logs
3. **Scenarios** — Leaky bucket configurations detect behavioral patterns and emit overflow events (decisions)

Remediation Components ("bouncers") then enforce decisions (firewall block, captcha, etc.).

### 1.2 Parser Architecture

Parsers are YAML files processed in stages. Each parser node has:

```yaml
# CrowdSec Parser Node Structure
filter: "evt.Line.Labels.type == 'syslog'"  # Expression filter — must return true
debug: false
onsuccess: next_stage  # or "continue" to keep processing in same stage
name: crowdsecurity/sshd-logs
stage: s01-parse

pattern_syntax:
  MYCAP1: ".*"  # Named grok patterns reusable within this parser

nodes:  # Sub-nodes for conditional branching
  - grok:
      pattern: ^%{MYCAP1:extracted_value} trailing$
      apply_on: Line.Raw  # Which field to apply grok against
    statics:
      - meta: log_type
        value: parsed_sshd

whitelist:  # IPs/CIDRs/expressions to never flag
  reason: "internal hosts"
  ip:
    - "10.0.0.0/8"
  expression:
    - evt.Meta.source_ip in ['127.0.0.1']

data:  # External data enrichment (GeoIP, reverse DNS, etc.)
  - source_url: https://example.com/data.txt
    dest_file: data.txt
    type: string
```

Key enrichment modules in parsers:
- `enrich_geoip.go` — GeoIP lookups on source IPs
- `enrich_dns.go` — Reverse DNS resolution
- `enrich_date.go` — Timestamp normalization
- `enrich_unmarshal.go` — JSON log parsing

### 1.3 Scenario (Leaky Bucket) Types

Five bucket types power all detection scenarios:

| Type | Capacity | LeakSpeed | Use Case |
|------|----------|-----------|----------|
| **leaky** | N events | Time per leak | Rate-based detection (brute force, scanning) |
| **trigger** | 0 (instant) | N/A | Single-event detection (critical log entry) |
| **counter** | -1 (infinite) | Infinite | Aggregation over fixed duration |
| **conditional** | -1 | Time-based | Overflow only when expression becomes true |
| **bayesian** | -1 | Time-based | Probabilistic detection with prior/likelihood |

### 1.4 Example Scenarios

```yaml
# SSH Brute Force Detection
- type: leaky
  name: ssh_bruteforce
  filter: "Meta.log_type == 'ssh_failed-auth'"
  leakspeed: "10s"
  capacity: 5
  stackkey: "source_ip"
  on_overflow: ban,1h

# Port Scan Detection (counter-based)
- type: counter
  name: port_scan_counter
  filter: "Meta.service == 'tcp' && Event.new_connection == 'true'"
  distinct: "Meta.source_ip + ':' + Meta.dest_port"
  duration: 5m
  capacity: -1

# Single Critical Event (trigger)
- type: trigger
  name: "critical_log4j_attempt"
  filter: "Meta.log_type == 'http_access' && evt.Parsed.uri contains '${jndi:'"
  on_overflow: ban,24h

# Bayesian Detection (probabilistic)
- type: bayesian
  name: suspicious_behavior
  filter: "Meta.log_type == 'http_access'"
  capacity: -1
  leakspeed: "30s"
  bayesian_prior: 0.5
  bayesian_threshold: 0.8
  bayesian_conditions:
    - condition: "evt.Parsed.status_code == '403'"
      prob_given_evil: 0.8
      prob_given_benign: 0.05
    - condition: "evt.Parsed.user_agent contains 'sqlmap'"
      prob_given_evil: 0.95
      prob_given_benign: 0.001
      guillotine: true  # Stop re-evaluating once true
```

### 1.5 Community Blocklist Architecture

- Security Engine shares signal (not raw logs) to CrowdSec Central API
- Central API aggregates consensus from participating nodes
- Community Blocklist is curated from consensus (IP must be flagged by multiple independent nodes)
- Nodes receive blocklist updates proactively — "Detect Here, Remedy There"
- Scope types: `Ip`, `Range`, `AS`, `Country` — decisions can target any scope level

---

## 2. Prowler — Cloud Security Posture Management

### 2.1 Architecture & Coverage

Prowler is a Python-based CSPM tool supporting:
- **AWS**: 84+ service categories with hundreds of individual checks
- **Azure**: 20+ service categories (VM, Storage, SQL Server, KeyVault, Entra ID, etc.)
- **GCP**: 19+ service categories (Compute, CloudSQL, IAM, KMS, GKE, etc.)
- **Kubernetes**, **GitHub**, **M365**, **MongoDB Atlas**, **Oracle Cloud**, **OpenStack**

### 2.2 Compliance Framework Mappings

AWS compliance frameworks supported (JSON mapping files):
- CIS Benchmarks: v1.4, v1.5, v2.0, v3.0, v4.0, v5.0, v6.0
- AWS Foundational Security Best Practices
- FedRAMP Low/Moderate Rev 4, FedRAMP 20x KSI Low
- HIPAA, GDPR, PCI DSS (via FFIEC)
- ISO 27001:2013 and 2022
- NIST 800-53 (via CISA)
- SOC 2 (via AWS FTR)
- C5, CSA CCM 4.0, ENS RD2022, GxP

### 2.3 Key AWS Check Categories (Prioritized for Security)

#### IAM (44 checks)
```
iam_no_root_access_key              — Root account should have no access keys
iam_root_mfa_enabled                — Root MFA must be enabled
iam_root_hardware_mfa_enabled       — Root should use hardware MFA
iam_avoid_root_usage                — Root account should not be used
iam_user_mfa_enabled_console_access — MFA required for console users
iam_rotate_access_key_90_days       — Keys rotated every 90 days
iam_user_accesskey_unused           — Detect unused access keys
iam_user_two_active_access_key      — Users should not have 2 active keys
iam_password_policy_minimum_length_14 — Min 14 char passwords
iam_inline_policy_allows_privilege_escalation — Detect privesc paths
iam_policy_allows_privilege_escalation — Detect managed policy privesc
iam_no_custom_policy_permissive_role_assumption — Overly permissive AssumeRole
iam_role_cross_service_confused_deputy_prevention — Confused deputy checks
```

#### CloudTrail (15 checks including threat detection)
```
cloudtrail_multi_region_enabled                    — Multi-region trail active
cloudtrail_log_file_validation_enabled             — Log integrity validation
cloudtrail_kms_encryption_enabled                  — KMS encryption for trails
cloudtrail_cloudwatch_logging_enabled              — CloudWatch integration
cloudtrail_logs_s3_bucket_is_not_publicly_accessible — S3 bucket not public
cloudtrail_threat_detection_privilege_escalation   — Detect privesc API calls
cloudtrail_threat_detection_enumeration            — Detect recon API calls
cloudtrail_threat_detection_llm_jacking            — Detect AI/LLM abuse
```

#### S3 (19 checks)
```
s3_account_level_public_access_blocks  — Account-level public access block
s3_bucket_level_public_access_block    — Bucket-level public access block
s3_bucket_secure_transport_policy      — Enforce HTTPS-only
s3_bucket_server_access_logging_enabled — Access logging enabled
s3_bucket_kms_encryption               — KMS encryption (not just SSE-S3)
s3_bucket_object_versioning            — Object versioning enabled
s3_bucket_object_lock                  — Object lock for immutability
s3_bucket_no_mfa_delete                — MFA delete enabled
s3_bucket_cross_account_access         — Detect cross-account access
```

#### EC2 (30+ checks)
```
ec2_instance_imdsv2_enabled          — IMDSv2 required (blocks SSRF credential theft)
ec2_ebs_default_encryption           — EBS encryption by default
ec2_ebs_public_snapshot              — Detect public EBS snapshots
ec2_ami_public                       — Detect public AMIs
ec2_instance_port_*_exposed_to_internet — Port exposure checks for:
  SSH(22), RDP(3389), MySQL(3306), MongoDB(27017), Cassandra(9042),
  Elasticsearch(9200/9300), Kafka(9092), LDAP(389), Kerberos(88),
  Memcached(11211), CIFS(445), FTP(21), Oracle(1521), Redis(6379)
```

### 2.4 Prowler Threat Detection Checks

The `cloudtrail_threat_detection_privilege_escalation` check monitors for these API calls within a configurable time window (default 1440 minutes, threshold 0.2):

```python
# Privilege Escalation API Actions Monitored
privilege_escalation_actions = [
    "AddPermission", "AddRoleToInstanceProfile", "AddUserToGroup",
    "AssociateAccessPolicy", "AssumeRole", "AttachGroupPolicy",
    "AttachRolePolicy", "AttachUserPolicy", "ChangePassword",
    "CreateAccessEntry", "CreateAccessKey", "CreateDevEndpoint",
    "CreateEventSourceMapping", "CreateFunction", "CreateGroup",
    "CreateJob", "CreateKeyPair", "CreateLoginProfile",
    "CreatePipeline", "CreatePolicyVersion", "CreateRole",
    "CreateStack", "DeleteRolePermissionsBoundary", "DeleteRolePolicy",
    "DeleteUserPermissionsBoundary", "DeleteUserPolicy",
    "DetachRolePolicy", "DetachUserPolicy",
    "GetCredentialsForIdentity", "GetId", "GetPolicyVersion",
    "GetUserPolicy", "Invoke", "ModifyInstanceAttribute",
    "PassRole", "PutGroupPolicy", "PutPipelineDefinition",
    "PutRolePermissionsBoundary", "PutRolePolicy",
    "PutUserPermissionsBoundary", "PutUserPolicy",
    "ReplaceIamInstanceProfileAssociation", "RunInstances",
    "SetDefaultPolicyVersion", "UpdateAccessKey",
    "UpdateAssumeRolePolicy", "UpdateDevEndpoint",
    "UpdateEventSourceMapping", "UpdateFunctionCode",
    "UpdateJob", "UpdateLoginProfile",
]
```

### 2.5 Prowler Auto-Remediation (Fixer Pattern)

Prowler includes auto-fix capabilities. Example — when privilege escalation is detected, it can attach a deny-all policy:

```python
deny_policy = {
    "Version": "2012-10-17",
    "Statement": [{"Effect": "Deny", "Action": "*", "Resource": "*"}]
}
# Applied as inline policy "DenyAllAccess" to user or role
iam_client.client.put_user_policy(
    UserName=entity_name,
    PolicyName="DenyAllAccess",
    PolicyDocument=json.dumps(deny_policy),
)
```

### 2.6 CIS AWS Foundations Benchmark v3.0 Key Requirements

```
1.1   — Maintain current contact details
1.10  — MFA enabled for all IAM users with console passwords
1.11  — No access keys during initial user setup
1.12  — Credentials unused for 45 days disabled
1.13  — Only one active access key per IAM user
1.14  — Access keys rotated every 90 days
1.15  — IAM users receive permissions only through groups
1.16  — No full "*:*" administrative privileges attached
1.17  — Support role created for AWS Support incidents
1.18  — IAM instance roles used for resource access from instances
```

---

## 3. Ansible Collection Hardening — Specific Parameters

### 3.1 OS Hardening — Sysctl Values (Production Defaults)

#### Filesystem Protection
```ini
fs.protected_hardlinks = 1        # Prevent hardlink TOCTOU attacks
fs.protected_symlinks = 1         # Prevent symlink TOCTOU attacks
fs.protected_fifos = 1            # Restrict FIFO creation
fs.protected_regular = 2          # Restrict regular file creation
fs.suid_dumpable = 0              # Prevent core dumps with SUID
```

#### Kernel Hardening
```ini
kernel.core_uses_pid = 1           # Append PID to core filenames
kernel.kptr_restrict = 2           # Hide kernel addresses from ALL users (including root)
kernel.kexec_load_disabled = 1     # Disable kernel replacement at runtime
kernel.sysrq = 0                   # Disable Magic SysRq completely
kernel.randomize_va_space = 2      # Full ASLR (stack, VDSO, shared memory, data)
kernel.yama.ptrace_scope = 1       # PTRACE limited to direct child processes
```

#### Network Stack — IPv4
```ini
net.ipv4.ip_forward = 0                        # Disable IP forwarding
net.ipv4.conf.all.rp_filter = 1                # Strict reverse path filtering (BCP38)
net.ipv4.conf.default.rp_filter = 1            # Default reverse path filtering
net.ipv4.icmp_echo_ignore_broadcasts = 1       # SMURF attack protection
net.ipv4.icmp_ignore_bogus_error_responses = 1 # Ignore bogus ICMP errors
net.ipv4.icmp_ratelimit = 100                  # ICMP rate limiting
net.ipv4.tcp_timestamps = 0                    # Hide system uptime
net.ipv4.conf.all.arp_ignore = 1               # Restrict ARP replies
net.ipv4.conf.all.arp_announce = 2             # Strict ARP announcements
net.ipv4.tcp_rfc1337 = 1                       # RFC 1337 TIME-WAIT assassination fix
net.ipv4.tcp_syncookies = 1                    # SYN flood protection (CIS 3.2.8)
net.ipv4.conf.all.accept_source_route = 0      # Reject source-routed packets
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.all.send_redirects = 0           # Don't send ICMP redirects
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.log_martians = 1             # Log martian packets (spoofed src)
net.ipv4.conf.default.log_martians = 1
net.ipv4.conf.all.accept_redirects = 0         # Reject ICMP redirects
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0         # Reject secure ICMP redirects
net.ipv4.conf.default.secure_redirects = 0
```

#### Network Stack — IPv6
```ini
net.ipv6.conf.all.forwarding = 0               # Disable IPv6 forwarding
net.ipv6.conf.all.accept_source_route = 0      # Reject source-routed IPv6
net.ipv6.conf.all.accept_ra = 0                # Ignore Router Advertisements
net.ipv6.conf.default.accept_ra = 0
net.ipv6.conf.default.router_solicitations = 0 # Disable router solicitations
net.ipv6.conf.default.accept_ra_rtr_pref = 0   # Ignore RA router preference
net.ipv6.conf.default.accept_ra_pinfo = 0      # Ignore RA prefix info
net.ipv6.conf.default.accept_ra_defrtr = 0     # Ignore RA default router
net.ipv6.conf.default.autoconf = 0             # Disable IPv6 autoconfig
net.ipv6.conf.all.autoconf = 0
net.ipv6.conf.default.dad_transmits = 0        # Disable DAD transmits
net.ipv6.conf.default.max_addresses = 1        # One global unicast per interface
net.ipv6.conf.default.accept_redirects = 0     # Reject IPv6 redirects
net.ipv6.conf.all.accept_redirects = 0
```

#### Memory Protection
```ini
vm.mmap_min_addr = 65536      # Protect zero page (NULL-deref protection)
vm.mmap_rnd_bits = 32         # Maximum ASLR randomization for mmap
vm.mmap_rnd_compat_bits = 16  # ASLR for 32-bit compat
```

### 3.2 SSH Hardening — Cipher & Algorithm Selection

#### Recommended Ciphers (OpenSSH 6.6+)
```
chacha20-poly1305@openssh.com    # AEAD, constant-time, no AES-NI required
aes256-gcm@openssh.com           # AEAD with hardware acceleration
aes128-gcm@openssh.com           # AEAD with hardware acceleration
aes256-ctr                       # Fallback CTR mode
aes192-ctr
aes128-ctr
```

#### Recommended MACs (OpenSSH 6.6+)
```
hmac-sha2-512-etm@openssh.com   # Encrypt-then-MAC (preferred)
hmac-sha2-256-etm@openssh.com   # Encrypt-then-MAC
umac-128-etm@openssh.com        # Encrypt-then-MAC
hmac-sha2-512                    # Fallback non-ETM
hmac-sha2-256                    # Fallback non-ETM
```

#### Recommended KEX (OpenSSH 8.5+)
```
sntrup761x25519-sha512@openssh.com       # Post-quantum hybrid KEX
curve25519-sha256@libssh.org             # Modern ECDH
diffie-hellman-group-exchange-sha256     # Classical DH with custom params
```

#### SSH Server Hardening Parameters
```yaml
ssh_permit_root_login: "no"              # No root login
ssh_server_password_login: false         # Key-only authentication
ssh_client_password_login: false         # Client key-only
ssh_allow_tcp_forwarding: "no"           # No TCP forwarding
ssh_allow_agent_forwarding: false        # No agent forwarding
ssh_x11_forwarding: false               # No X11 forwarding
ssh_permit_tunnel: "no"                  # No SSH tunneling
ssh_use_dns: false                       # No DNS lookups (prevents delays)
ssh_compression: false                   # Disable compression (CRIME-style attacks)
ssh_login_grace_time: 30s               # 30 second auth timeout
ssh_max_auth_retries: 2                  # Max 2 auth attempts per connection
ssh_max_sessions: 10                     # Max 10 multiplexed sessions
ssh_client_alive_interval: 300           # 5 min keepalive
ssh_client_alive_count: 3                # 3 missed keepalives = disconnect
ssh_max_startups: "10:30:60"             # Rate limit: 10 unauthenticated, then 30% drop, max 60
ssh_host_rsa_key_size: 4096              # RSA key size
sshd_moduli_minimum: 2048               # Remove DH moduli < 2048 bits
ssh_print_motd: false                    # No MOTD
ssh_print_last_log: false                # No last login info
ssh_print_debian_banner: false           # No version leakage
sftp_chroot: true                        # SFTP chroot enabled
sftp_umask: "0027"                       # Restrictive SFTP umask
sshd_authenticationmethods: publickey    # Public key only
sshd_syslog_facility: AUTH               # Log to AUTH facility
sshd_log_level: VERBOSE                  # Verbose logging (captures key fingerprints)
sshd_strict_modes: true                  # Check file permissions
```

#### SSH DH Moduli Hardening
```bash
# Remove weak DH parameters (primes < 2048 bits)
awk '$5 >= 2048' /etc/ssh/moduli > /etc/ssh/moduli.new
mv /etc/ssh/moduli.new /etc/ssh/moduli
```

### 3.3 MySQL Hardening Parameters

```yaml
mysql_remove_remote_root: true       # Remove remote root login
mysql_remove_anonymous_users: true   # Remove anonymous users
mysql_remove_test_database: true     # Remove test database
mysql_hardening_skip_show_database: true  # Hide database list from non-privileged

mysql_hardening_options:
  safe-user-create: 1        # Prevent users creating new users without GRANT
  secure-auth: 1             # Require secure authentication (no old protocol)
  skip-symbolic-links: 1     # Prevent symlink attacks on data directory
  local-infile: 0            # Disable LOAD DATA LOCAL (data exfiltration vector)
  allow-suspicious-udfs: 0   # Block suspicious UDF loading
  automatic-sp-privileges: 0 # No automatic stored procedure privileges
  secure-file-priv: /tmp     # Restrict file I/O to /tmp only
```

### 3.4 OS Hardening — Authentication & Access

```yaml
os_auth_pw_max_age: 60       # Maximum password age: 60 days
os_auth_pw_min_age: 7        # Minimum age: 7 days (prevents cycling)
os_auth_pw_warn_age: 7       # Warning before expiry: 7 days
os_auth_pw_remember: 5       # Remember last 5 passwords
os_auth_retries: 5           # Max 5 auth retries
os_auth_lockout_time: 600    # 10 minute lockout after failures
os_auth_timeout: 60          # 60 second auth timeout
os_sha_crypt_min_rounds: "640000"  # SHA password hashing rounds
os_sha_crypt_max_rounds: "640000"  # High rounds = slower brute force

# SELinux
os_selinux_state: enforcing
os_selinux_policy: targeted
```

### 3.5 Disabled Filesystems & Protocols

```yaml
os_unused_filesystems:
  - cramfs       # Compressed ROM filesystem (attack surface)
  - freevxfs     # Veritas filesystem
  - jffs2        # Journalling Flash
  - hfs          # Apple HFS
  - hfsplus      # Apple HFS+
  - squashfs     # Compressed read-only
  - udf          # Universal Disk Format
  - vfat         # FAT (removed only if not EFI)
  - dccp         # CIS 3.5.1 — Obsolete protocol
  - rds          # CIS 3.5.3 — Obsolete protocol
  - sctp         # CIS 3.5.2 — Obsolete protocol
  - tipc         # CIS 3.5.4 — Obsolete protocol
```

### 3.6 SUID/SGID Blacklist (NSA-Derived)

Binaries whose SUID/SGID bits should be removed:
```
/usr/bin/rcp, /usr/bin/rlogin, /usr/bin/rsh         # r-commands
/usr/libexec/openssh/ssh-keysign                     # Host-based SSH auth
/sbin/netreport                                       # Network reporting
/usr/sbin/usernetctl                                  # Interface modification
/usr/sbin/pppd                                        # PPP daemon
/usr/bin/arping                                        # ARP ping
/usr/bin/mtr                                           # Network diagnostic
```

### 3.7 Security Packages to Remove
```yaml
os_security_packages_list:
  - xinetd          # Legacy super-server
  - inetd           # Legacy super-server
  - ypserv          # NIS server
  - telnet-server   # Unencrypted remote access
  - rsh-server      # Remote shell (unencrypted)
  - prelink         # Interferes with ASLR
```

### 3.8 Mount Options

```yaml
# /dev/shm — shared memory
os_mnt_dev_shm_options: rw,nosuid,nodev,noexec

# /tmp — temporary files
os_mnt_tmp_options: rw,nosuid,nodev,noexec

# /var/log — log files
os_mnt_var_log_options: rw,nosuid,nodev,noexec

# /var/log/audit — audit logs
os_mnt_var_log_audit_options: rw,nosuid,nodev,noexec
os_mnt_var_log_audit_dir_mode: "0700"

# /boot — boot partition
os_mnt_boot_options: rw,nosuid,nodev,noexec
os_mnt_boot_dir_mode: "0700"

# /proc — process filesystem
proc_mnt_options: rw,nosuid,nodev,noexec,relatime
```

### 3.9 UFW Firewall Defaults
```yaml
ufw_default_input_policy: DROP      # Default deny inbound
ufw_default_output_policy: ACCEPT   # Default allow outbound
ufw_default_forward_policy: DROP    # Default deny forwarding
```

---

## 4. Incident Response Tools & Procedures

### 4.1 Velociraptor — Endpoint Visibility

**Purpose**: VQL-powered endpoint forensics and collection tool.

**Deployment Modes**:
- `velociraptor gui` — Instant local GUI + server + client
- Server/Client — Distributed enterprise deployment
- Standalone Collector — Offline collection for air-gapped systems

**Key Capabilities**:
- VQL (Velociraptor Query Language) — SQL-like endpoint queries
- Artifact-based collection framework
- Community Artifact Exchange at docs.velociraptor.app/exchange/
- Real-time monitoring and hunting across endpoints
- Memory acquisition and analysis
- File system timeline generation

**IR Workflow**:
1. Deploy agent or use standalone collector
2. Select artifacts (built-in or custom VQL)
3. Execute collection across fleet
4. Analyze results with built-in notebook or export
5. "Build Collector" feature creates self-contained exe for offline use

**Integration with Hayabusa**: Velociraptor can deploy Hayabusa as a server artifact for enterprise-wide Windows event log analysis.

### 4.2 Hayabusa — Windows Event Log Timeline Generator

**Purpose**: Fast forensics timeline generation and threat hunting from Windows event logs (Rust-based).

**Key Commands**:
```bash
# Generate CSV timeline from event logs
hayabusa csv-timeline -d ./evtx-files/ -o timeline.csv

# Generate JSON timeline
hayabusa json-timeline -d ./evtx-files/ -o timeline.jsonl

# Search for specific patterns
hayabusa search -d ./evtx-files/ -k "mimikatz"

# Computer-level metrics
hayabusa computer-metrics -d ./evtx-files/

# Logon summary (successful/failed auth)
hayabusa logon-summary -d ./evtx-files/

# Level tuning (adjust severity thresholds)
hayabusa level-tuning -d ./evtx-files/
```

**Detection Capabilities**:
- Full Sigma v2 specification support (including correlation rules)
- 4000+ built-in Sigma rules
- Custom Hayabusa-native detection rules (YAML)
- MITRE ATT&CK tactic mapping per detection
- GeoIP enrichment for IP addresses
- Base64 detection and extraction
- Pivot keyword extraction
- Event deduplication (VSS/backup aware)
- Multiple output profiles: minimal, standard, verbose, Timesketch-compatible

**Key Principle**: "80% of the work done in 20% of the time" — prioritizes analyst efficiency.

### 4.3 Chainsaw — Rapid Windows Artifact Analysis

**Purpose**: First-response Windows forensic analysis tool (Rust-based).

**Key Commands**:
```bash
# Hunt with Sigma rules
chainsaw hunt ./evtx-files/ -s sigma/ --mapping mappings/sigma-event-logs-all.yml

# Search for patterns
chainsaw search "mimikatz" ./evtx-files/

# Regex search
chainsaw search -e "(?i)pass(word|wd)" ./evtx-files/

# Output formats: ASCII table, CSV, JSON
chainsaw hunt ./evtx-files/ -s sigma/ --json -o results.json
```

**Built-in Detections**:
- Antivirus alerts (Windows Defender, F-Secure, Sophos, Kaspersky)
- Event log tampering and service disruption
- User account creation in sensitive groups
- Remote access / lateral movement indicators
- Brute-force authentication attempts

**Additional Features**:
- Shimcache timeline analysis with Amcache enrichment
- SRUM (System Resource Usage Monitor) database parsing
- No SIEM infrastructure required — runs directly on forensic images

### 4.4 KAPE — Kroll Artifact Parser and Extractor

**Purpose**: Triage tool for rapid forensic artifact collection and parsing (Windows).

**Architecture**:
- **Targets**: Define which artifacts to collect (registry hives, event logs, browser data, etc.)
- **Modules**: Define how to parse collected artifacts

**Key Collection Targets**:
- Registry hives (SAM, SYSTEM, SOFTWARE, SECURITY, NTUSER.DAT, UsrClass.dat)
- Event logs (all .evtx files)
- Prefetch files
- $MFT, $LogFile, $UsnJrnl
- Browser artifacts (Chrome, Firefox, Edge)
- Jump Lists, LNK files, Shellbags
- Scheduled tasks, services
- SRUM database
- WMI repository
- PowerShell history and console logs
- Windows.old directory

### 4.5 IR Tool Selection Matrix

| Phase | Tool | Platform | Speed | Use Case |
|-------|------|----------|-------|----------|
| Collection | KAPE | Windows | Fast | Triage artifact collection |
| Collection | UAC | Linux/Unix | Fast | Unix-like artifact collection |
| Collection | Velociraptor | Cross-platform | Medium | Enterprise-scale collection |
| Collection | CyLR | Windows | Fast | NTFS artifact collection |
| Analysis | Hayabusa | Cross-platform | Fast | Event log timeline + Sigma |
| Analysis | Chainsaw | Cross-platform | Fast | Event log hunting + Sigma |
| Analysis | Volatility3 | Cross-platform | Slow | Memory forensics |
| Analysis | Plaso/log2timeline | Cross-platform | Medium | Super-timeline generation |
| Analysis | Timesketch | Web | N/A | Collaborative timeline analysis |
| Memory | LiME | Linux | Fast | Linux memory acquisition |
| Memory | AVML | Linux | Fast | Azure/Linux memory acquisition |
| Memory | DumpIt | Win/Linux | Fast | Physical memory dump |
| Scanning | LOKI | Cross-platform | Medium | IOC/YARA endpoint scanning |
| Scanning | Fenrir | Linux/Unix | Fast | Bash-based IOC scanner |
| SOAR | TheHive | Web | N/A | Case management + Cortex |
| SOAR | Shuffle | Web | N/A | Security automation |

### 4.6 IR Playbook Resources

**AWS IR Runbooks** (github.com/aws-samples/aws-incident-response-runbooks):
- DoS/DDoS attack response
- Credential leakage response
- Unintended S3 bucket access response

**CERT Societe Generale IRM** (github.com/certsocietegenerale/IRM):
- Standardized incident response methodologies by incident type

**PagerDuty IR Documentation** (response.pagerduty.com):
- End-to-end incident management lifecycle
- On-call procedures, escalation paths, post-mortems

---

## 5. Detection Engineering Methodology

### 5.1 Sigma Rule Format

```yaml
title: Suspicious PowerShell Download Cradle
id: 3b6ab547-8ec2-4991-b9d2-2b06702a48d7
status: experimental
description: Detects PowerShell download cradle patterns commonly used for malware delivery
references:
  - https://attack.mitre.org/techniques/T1059/001/
logsource:
  category: process_creation
  product: windows
detection:
  selection_powershell:
    Image|endswith:
      - '\powershell.exe'
      - '\pwsh.exe'
  selection_download:
    CommandLine|contains:
      - 'Net.WebClient'
      - 'DownloadString'
      - 'DownloadFile'
      - 'Invoke-WebRequest'
      - 'iwr '
      - 'wget '
      - 'curl '
      - 'Start-BitsTransfer'
  condition: selection_powershell and selection_download
falsepositives:
  - Administrative scripts using PowerShell for legitimate downloads
  - SCCM/Intune deployment scripts
level: high
tags:
  - attack.execution
  - attack.t1059.001
  - attack.command_and_control
  - attack.t1105
```

### 5.2 Sigma Rule Categories

1. **Generic Detection Rules** — Behavior-focused, threat-agnostic (e.g., "process injection via CreateRemoteThread")
2. **Threat Hunting Rules** — Broader scope for investigation starting points (e.g., "unusual parent-child process relationships")
3. **Emerging Threat Rules** — Time-sensitive (APT campaigns, zero-days, active exploitation)
4. **Compliance Rules** — Framework-aligned (CIS, NIST, ISO 27001)
5. **Placeholder Rules** — Context-dependent, gain meaning at conversion time

### 5.3 Sigma Conversion

```bash
# Convert to Splunk SPL
sigma convert -t splunk -p splunk_cim rule.yml

# Convert to Elastic/KQL
sigma convert -t elasticsearch -p ecs_windows rule.yml

# Convert to QRadar AQL
sigma convert -t qradar rule.yml

# Web converter: sigconverter.io
# Python library: pySigma
```

### 5.4 Detection Engineering Frameworks

**Palantir Alerting & Detection Strategy Framework**:
- Goal, Strategy, Technical Context, Blind Spots & Assumptions, False Positives, Validation, Priority, Response

**Pyramid of Pain** (David Bianco):
- Hash Values (trivial to change) -> IP Addresses -> Domain Names -> Network/Host Artifacts -> Tools -> TTPs (hardest to change)

**Detection Maturity Level (DML) Model**:
- DML-0: None -> DML-1: General IoC -> DML-8: Goals/Strategy -> DML-9: Identity of attacker

**Funnel of Fidelity** (SpecterOps):
- Collection -> Detection -> Triage -> Investigation -> Remediation
- Each stage reduces volume; invest in detection quality to reduce analyst burden

**MITRE ATT&CK Navigator**: Visualize detection coverage as a heat map across ATT&CK matrix.

### 5.5 HELK — Hunting ELK Stack

**Architecture**: Elasticsearch + Logstash + Kibana + Apache Spark + Jupyter Notebooks + GraphFrames

**Capabilities**:
- SQL-based log querying
- Machine learning on security data via Spark
- Graph analysis of lateral movement via GraphFrames
- Jupyter notebooks for threat hunting research
- Docker-based deployment

**Use Case**: Research-grade threat hunting lab with data science capabilities.

### 5.6 Key Detection Datasets

| Dataset | Description |
|---------|-------------|
| Mordor | Pre-recorded ATT&CK technique execution logs (JSON) |
| BOTS v1/v2/v3 | Splunk Boss of the SOC competition datasets |
| EVTX-ATTACK-SAMPLES | Windows event samples mapped to ATT&CK |
| PCAP-ATTACK | Network captures mapped to ATT&CK techniques |
| attack_data | Splunk-curated attack simulation datasets |

### 5.7 Sysmon Configuration Best Practices

**SwiftOnSecurity sysmon-config**: Production-ready template with comprehensive comments.

**Key Sysmon Event IDs to Monitor**:

| Event ID | Description | Detection Value |
|----------|-------------|-----------------|
| 1 | Process Creation | Primary detection source — command lines, parent processes |
| 3 | Network Connection | Outbound C2, lateral movement |
| 7 | Image Loaded | DLL side-loading, injection |
| 8 | CreateRemoteThread | Process injection (Mimikatz, Cobalt Strike) |
| 10 | ProcessAccess | Credential dumping (LSASS access) |
| 11 | FileCreate | Payload drops, webshells |
| 12/13/14 | Registry Events | Persistence mechanisms |
| 15 | FileCreateStreamHash | Alternate data streams |
| 17/18 | Pipe Events | Named pipe lateral movement (PsExec, Cobalt Strike SMB) |
| 22 | DNSEvent | DNS-based C2, domain generation algorithms |
| 23 | FileDelete | Anti-forensics, ransomware |
| 25 | ProcessTampering | Process hollowing, herpaderping |
| 26 | FileDeleteDetected | Logged even if file content not saved |

**Complementary config**: olafhartong/sysmon-modular — Modular configs mapped to ATT&CK techniques.

---

## 6. Linux Auditd — Comprehensive Detection Rules

### 6.1 Self-Auditing Protection
```bash
-w /var/log/audit/ -p wra -k auditlog
-w /etc/audit/ -p wa -k auditconfig
-w /sbin/auditctl -p x -k audittools
-w /sbin/auditd -p x -k audittools
```

### 6.2 Privilege Escalation Detection
```bash
-w /bin/su -p x -k priv_esc
-w /usr/bin/sudo -p x -k priv_esc
-w /usr/bin/pkexec -p x -k pkexec
-a always,exit -F dir=/home -F uid=0 -F auid>=1000 -F auid!=-1 -C auid!=obj_uid -k power_abuse
-a always,exit -F arch=b64 -F euid=0 -F auid>=1000 -F auid!=-1 -S execve -k rootcmd
```

### 6.3 Persistence Mechanism Monitoring
```bash
# Cron
-w /etc/cron.d/ -p wa -k cron
-w /etc/crontab -p wa -k cron
-w /var/spool/cron/ -p wa -k cron

# Systemd
-w /etc/systemd/ -p wa -k systemd
-w /usr/lib/systemd -p wa -k systemd
-w /etc/systemd/system-generators/ -p wa -k systemd_generator

# Init
-w /etc/init.d/ -p wa -k init

# Shell profiles
-w /etc/profile.d/ -p wa -k shell_profiles
-w /etc/profile -p wa -k shell_profiles
-w /etc/bashrc -p wa -k shell_profiles

# Library preloading (LD_PRELOAD attacks)
-w /etc/ld.so.preload -p wa -k systemwide_preloads
-w /etc/ld.so.conf -p wa -k libpath

# SSH keys
-w /root/.ssh -p wa -k rootkey
-w /etc/ssh/sshd_config -k sshd
```

### 6.4 Reconnaissance Detection
```bash
-w /usr/bin/whoami -p x -k recon
-w /usr/bin/id -p x -k recon
-w /bin/hostname -p x -k recon
-w /bin/uname -p x -k recon
-w /etc/issue -p r -k recon
-w /etc/hostname -p r -k recon
```

### 6.5 Suspicious Activity Monitoring
```bash
# Network tools
-w /usr/bin/wget -p x -k susp_activity
-w /usr/bin/curl -p x -k susp_activity
-w /bin/nc -p x -k susp_activity
-w /usr/bin/ncat -p x -k susp_activity
-w /usr/bin/socat -p x -k susp_activity
-w /usr/bin/nmap -p x -k susp_activity

# Encoding (data obfuscation)
-w /usr/bin/base64 -p x -k susp_activity

# Remote access
-w /usr/bin/ssh -p x -k susp_activity
-w /usr/bin/scp -p x -k susp_activity
-w /usr/bin/rdesktop -p x -k susp_activity
-w /usr/bin/xfreerdp -p x -k susp_activity
```

### 6.6 Data Exfiltration Indicators
```bash
# Compression tools (staging for exfil)
-w /usr/bin/zip -p x -k Data_Compressed
-w /usr/bin/gzip -p x -k Data_Compressed
-w /usr/bin/tar -p x -k Data_Compressed
-w /usr/bin/bzip2 -p x -k Data_Compressed
-w /usr/bin/zstd -p x -k Data_Compressed
```

### 6.7 Code Injection Detection
```bash
-a always,exit -F arch=b64 -S ptrace -F a0=0x4 -k code_injection
-a always,exit -F arch=b64 -S ptrace -F a0=0x5 -k data_injection
-a always,exit -F arch=b64 -S ptrace -F a0=0x6 -k register_injection
-a always,exit -F arch=b64 -S ptrace -k tracing
-a always,exit -F arch=b64 -S memfd_create -F key=anon_file_create
```

### 6.8 Kernel Module Monitoring
```bash
-a always,exit -F perm=x -F auid!=-1 -F path=/sbin/insmod -k modules
-a always,exit -F perm=x -F auid!=-1 -F path=/sbin/modprobe -k modules
-a always,exit -F perm=x -F auid!=-1 -F path=/sbin/rmmod -k modules
-a always,exit -F arch=b64 -S finit_module -S init_module -S delete_module -F auid!=-1 -k modules
-a always,exit -F arch=b64 -S kexec_load -k KEXEC
```

### 6.9 Identity & Account Modification
```bash
-w /etc/group -p wa -k etcgroup
-w /etc/passwd -p wa -k etcpasswd
-w /etc/shadow -k etcpasswd
-w /etc/sudoers -p wa -k actions
-w /etc/sudoers.d/ -p wa -k actions
-w /usr/sbin/useradd -p x -k user_modification
-w /usr/sbin/userdel -p x -k user_modification
-w /usr/sbin/usermod -p x -k user_modification
-w /usr/bin/passwd -p x -k passwd_modification
```

### 6.10 Container & Virtualization Monitoring
```bash
-w /usr/bin/dockerd -k docker
-w /usr/bin/docker -k docker
-w /var/lib/docker -p wa -k docker
-w /etc/docker -k docker
-w /usr/bin/qemu-system-x86_64 -p x -k qemu-system-x86_64
-w /usr/bin/kubelet -k kubelet
```

### 6.11 32-bit ABI Exploitation
```bash
# Detect 32-bit syscalls on 64-bit systems (common exploitation technique)
-a always,exit -F arch=b32 -S all -k 32bit_abi
```

### 6.12 Network Connection Monitoring
```bash
-a always,exit -F arch=b64 -S connect -F a2=16 -F success=1 -F key=network_connect_4
-a always,exit -F arch=b64 -S connect -F a2=28 -F success=1 -F key=network_connect_6
-a always,exit -F arch=b64 -F exe=/bin/bash -F success=1 -S connect -k remote_shell
-a always,exit -F arch=b32 -S socket -F a0=2 -k network_socket_created
-a always,exit -F arch=b64 -S socket -F a0=2 -k network_socket_created
```

---

## 7. Quick Reference — Detection & Hardening Checklists

### 7.1 Linux Host Hardening Checklist

- [ ] Apply sysctl hardening (Section 3.1 values)
- [ ] Harden SSH configuration (Section 3.2 parameters)
- [ ] Remove weak DH moduli (`awk '$5 >= 2048'`)
- [ ] Disable unused filesystems via modprobe
- [ ] Remove SUID/SGID from NSA blacklist binaries
- [ ] Remove insecure packages (xinetd, telnet-server, rsh-server, prelink)
- [ ] Deploy auditd rules (Section 6)
- [ ] Mount /tmp, /dev/shm, /var/log with nosuid,nodev,noexec
- [ ] Set SELinux to enforcing
- [ ] Configure PAM password quality (min 14 chars, 640K SHA rounds)
- [ ] Enable UFW with default DROP inbound
- [ ] Disable Ctrl+Alt+Del
- [ ] Restrict core dumps (`fs.suid_dumpable=0`, `kernel.core_uses_pid=1`)

### 7.2 AWS Security Posture Checklist

- [ ] No root access keys (iam_no_root_access_key)
- [ ] Root MFA enabled — hardware preferred
- [ ] Multi-region CloudTrail with log validation
- [ ] CloudTrail encrypted with KMS
- [ ] CloudTrail logs in non-public S3 bucket with access logging
- [ ] S3 account-level public access block enabled
- [ ] All S3 buckets enforce HTTPS transport
- [ ] EBS default encryption enabled
- [ ] IMDSv2 required on all EC2 instances
- [ ] No public EBS snapshots or AMIs
- [ ] Access keys rotated every 90 days
- [ ] Unused credentials disabled after 45 days
- [ ] IAM policies do not allow full `*:*` administrative privileges
- [ ] No sensitive ports exposed to 0.0.0.0/0

### 7.3 IR First 15 Minutes Checklist

1. **Confirm the incident** — Is this a true positive?
2. **Scope assessment** — Which systems, accounts, data affected?
3. **Preserve evidence** — Start memory capture BEFORE any changes
4. **Collect volatile data** — Running processes, network connections, logged-in users
5. **Deploy collection tools**:
   - Windows: KAPE for artifacts, DumpIt for memory
   - Linux: UAC for artifacts, LiME/AVML for memory
6. **Timeline generation** — Hayabusa/Chainsaw on event logs
7. **IOC extraction** — Run LOKI/Fenrir with known-bad YARA rules
8. **Containment decision** — Network isolation, credential rotation, or monitoring
9. **Document everything** — Timestamps, actions taken, personnel involved
10. **Escalation assessment** — Does this meet notification thresholds?

### 7.4 Key Windows Event IDs for Triage

| Event ID | Log | Meaning |
|----------|-----|---------|
| 4624 | Security | Successful logon |
| 4625 | Security | Failed logon |
| 4648 | Security | Logon with explicit credentials (runas, PsExec) |
| 4672 | Security | Special privileges assigned (admin logon) |
| 4688 | Security | Process creation (enable command line logging) |
| 4697 | Security | Service installed |
| 4698 | Security | Scheduled task created |
| 4720 | Security | User account created |
| 4732 | Security | Member added to security-enabled local group |
| 4768 | Security | Kerberos TGT requested |
| 4769 | Security | Kerberos service ticket requested |
| 4771 | Security | Kerberos pre-auth failed |
| 7045 | System | New service installed |
| 1102 | Security | Audit log cleared |
| 4104 | PowerShell | Script block logging |
| 4103 | PowerShell | Module logging |

---

## 8. Network Fingerprinting for Detection

### 8.1 JA3/JA3S — TLS Client/Server Fingerprinting
- Hash of: SSLVersion, Ciphers, Extensions, EllipticCurves, EllipticCurvePointFormats
- Use: Identify C2 frameworks (Cobalt Strike, Metasploit) by their TLS fingerprint
- Database: ja3er.com

### 8.2 HASSH — SSH Client/Server Fingerprinting
- Hash of: KEX algorithms, encryption algorithms, MAC algorithms, compression algorithms
- Use: Detect non-standard SSH clients (tunneling tools, implants)

### 8.3 JARM — Active TLS Server Fingerprinting
- Sends 10 TLS Client Hello packets with different parameters
- Generates 62-character fingerprint of server TLS configuration
- Use: Identify C2 servers, malicious infrastructure

### 8.4 HTTP Fingerprinting
- Hfinger (CERT Polska) — Fingerprint HTTP requests by header ordering, methods, URIs
- Use: Detect automated tools, scanners, and malware callbacks
