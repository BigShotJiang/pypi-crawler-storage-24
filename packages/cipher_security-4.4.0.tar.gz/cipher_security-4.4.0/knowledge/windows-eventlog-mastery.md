<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Windows Event Log Mastery Reference

> CIPHER Training Module | Security Analyst Field Reference
> Sources: EVTX-ATTACK-SAMPLES, JPCERT ToolAnalysisResultSheet, EVTX-to-MITRE-Attack, EVTX-ETW-Resources, Ultimate Windows Security, Microsoft Appendix L

---

## Table of Contents

1. [Security Event IDs — Authentication & Logon](#1-security-event-ids--authentication--logon)
2. [Security Event IDs — Process Tracking](#2-security-event-ids--process-tracking)
3. [Security Event IDs — Account Management](#3-security-event-ids--account-management)
4. [Security Event IDs — Kerberos Authentication](#4-security-event-ids--kerberos-authentication)
5. [Security Event IDs — Privilege Use](#5-security-event-ids--privilege-use)
6. [Security Event IDs — Object Access](#6-security-event-ids--object-access)
7. [Security Event IDs — Audit Policy & System](#7-security-event-ids--audit-policy--system)
8. [Security Event IDs — Directory Services](#8-security-event-ids--directory-services)
9. [Security Event IDs — Network Share & Firewall](#9-security-event-ids--network-share--firewall)
10. [Sysmon Event IDs — Complete Reference](#10-sysmon-event-ids--complete-reference)
11. [PowerShell Logging Event IDs](#11-powershell-logging-event-ids)
12. [Task Scheduler Event IDs](#12-task-scheduler-event-ids)
13. [Windows Defender Event IDs](#13-windows-defender-event-ids)
14. [WMI Event IDs](#14-wmi-event-ids)
15. [RDP Event IDs — All Relevant Logs](#15-rdp-event-ids--all-relevant-logs)
16. [Service Installation Event IDs](#16-service-installation-event-ids)
17. [JPCERT Tool-to-Event Mapping Table](#17-jpcert-tool-to-event-mapping-table)
18. [Event Log Clearing & Anti-Forensics](#18-event-log-clearing--anti-forensics)
19. [Quick Reference — Critical Detection Matrix](#19-quick-reference--critical-detection-matrix)
20. [Audit Policy Configuration Requirements](#20-audit-policy-configuration-requirements)

---

## 1. Security Event IDs — Authentication & Logon

### Core Logon Events

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4624** | An account was successfully logged on | HIGH | T1078 |
| **4625** | An account failed to log on | HIGH | T1110 |
| **4626** | User/Device claims information | LOW | — |
| **4627** | Group membership information | MEDIUM | — |
| **4634** | An account was logged off | LOW | — |
| **4647** | User initiated logoff | LOW | — |
| **4648** | Logon attempted using explicit credentials | HIGH | T1134.002 |
| **4672** | Special privileges assigned to new logon | HIGH | T1078 |
| **4776** | DC attempted to validate credentials (NTLM) | MEDIUM | T1110 |
| **4777** | DC failed to validate credentials | MEDIUM | T1110 |
| **4778** | Session reconnected to a Window Station | MEDIUM | T1021.001 |
| **4779** | Session disconnected from a Window Station | LOW | — |
| **4800** | Workstation was locked | LOW | — |
| **4801** | Workstation was unlocked | LOW | — |

### Event 4624 — Logon Type Deep Dive

This is the single most important authentication event. The `LogonType` field determines context:

| Logon Type | Name | Description | Attack Relevance |
|------------|------|-------------|------------------|
| **2** | Interactive | Console logon (keyboard) | Physical access, RDP to console |
| **3** | Network | SMB, net use, PsExec (initial auth) | Lateral movement, remote shares |
| **4** | Batch | Scheduled task execution | Persistence via scheduled tasks |
| **5** | Service | Service startup under service account | Service-based persistence |
| **7** | Unlock | Workstation unlocked | Credential reuse after lock |
| **8** | NetworkCleartext | IIS Basic auth, PowerShell w/ CredSSP | Cleartext credential exposure |
| **9** | NewCredentials | RunAs /netonly | Alternate credential usage |
| **10** | RemoteInteractive | RDP / Terminal Services | Lateral movement via RDP |
| **11** | CachedInteractive | Logon with cached domain creds | Offline credential use |
| **12** | CachedRemoteInteractive | Cached RDP credentials | — |
| **13** | CachedUnlock | Cached credentials for unlock | — |

#### Legitimate vs. Attack — Event 4624

**Legitimate patterns:**
- Type 2/10 during business hours from expected workstations
- Type 3 from file servers, print servers, management stations
- Type 5 from SYSTEM or known service accounts at boot
- Type 4 from known scheduled task accounts at expected times
- Consistent source IPs matching DHCP/asset inventory

**Attack indicators:**
- Type 3 from workstation-to-workstation (lateral movement)
- Type 10 from unexpected source IPs or outside business hours
- Type 9 (NewCredentials) — RunAs /netonly for credential pivoting
- Type 3 with NTLM authentication to domain controllers (pass-the-hash)
- Multiple Type 3 logons from single source to many destinations in short window (spray)
- Type 3 followed immediately by 4672 (special privileges) — privileged lateral movement
- Logon from IP not in asset inventory
- LogonProcessName = "NtLmSsp" with NTLM auth to systems expecting Kerberos

### Event 4625 — Failed Logon Sub-Status Codes

| Status/Sub-Status | Meaning | Attack Context |
|-------------------|---------|----------------|
| 0xC000006A | Wrong password | Brute force / password spray |
| 0xC000006D | Bad username or password | Credential stuffing |
| 0xC0000064 | User does not exist | User enumeration |
| 0xC000006F | Logon outside allowed hours | Policy violation / persistence |
| 0xC0000070 | Workstation restriction violation | Lateral movement attempt |
| 0xC0000071 | Expired password | Stale credential use |
| 0xC0000072 | Disabled account | Attempt to use disabled account |
| 0xC000015B | Logon type not granted | Restricted logon type attempt |
| 0xC0000192 | NetLogon service not started | Infrastructure issue / attack |
| 0xC0000193 | Account expiration | Expired account exploitation |
| 0xC0000224 | Password must change at next logon | — |
| 0xC0000234 | Account locked out | Result of brute force |
| 0xC0000413 | AuthFirewall — machine not allowed | Network access control |

#### Legitimate vs. Attack — Event 4625

**Legitimate:** Occasional password typos, users returning from vacation with expired passwords, service account password rotation failures.

**Attack:** >5 failures per minute from one source (brute force), same account failing across multiple workstations (spray), 0xC0000064 errors cycling through usernames (enumeration), failures from non-domain IPs.

### Event 4648 — Explicit Credentials

**Legitimate:** Admin using RunAs, scheduled tasks with stored creds, service accounts authenticating to databases.

**Attack:** Attacker using stolen credentials to authenticate to remote systems. Key indicator of lateral movement when the `TargetServerName` differs from the local hostname and `SubjectUserName` differs from `TargetUserName`.

---

## 2. Security Event IDs — Process Tracking

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4688** | A new process has been created | HIGH | T1059, T1204 |
| **4689** | A process has exited | LOW | — |
| **4690** | Attempt to duplicate a handle to an object | MEDIUM | T1134 |
| **4691** | Indirect access to an object was requested | LOW | — |
| **4696** | Primary token assigned to process | HIGH | T1134 |
| **4697** | Attempt to install a service | HIGH | T1543.003, T1569.002 |

### Event 4688 — Process Creation (Critical)

**Required configuration:** Enable "Audit Process Creation" AND "Include command line in process creation events" (Admin Templates > System > Audit Process Creation).

**Key fields:**
- `NewProcessName` — Full path of the executable
- `CommandLine` — Complete command line (requires GPO)
- `ParentProcessName` — Parent process path
- `SubjectUserName` — User who created the process
- `TokenElevationType` — Elevation status (%%1936=Full, %%1937=Limited, %%1938=Default)

#### Legitimate vs. Attack — Event 4688

**Legitimate patterns:**
- explorer.exe spawning user applications
- services.exe spawning service executables
- svchost.exe spawning expected child processes
- cmd.exe/powershell.exe spawned by user interaction from explorer.exe

**Attack indicators:**
- `cmd.exe` or `powershell.exe` spawned by `w3wp.exe` (web shell)
- `cmd.exe` spawned by `winword.exe`, `excel.exe`, `outlook.exe` (macro execution — T1204.002)
- `powershell.exe` with `-enc`, `-nop`, `-w hidden`, `IEX`, `downloadstring` (T1059.001)
- `rundll32.exe` with unusual DLL paths or JavaScript (T1218.011)
- `mshta.exe` executing remote HTA files (T1218.005)
- `certutil.exe -urlcache -split -f` (T1105 — download)
- `bitsadmin.exe /transfer` (T1197)
- `wmic.exe process call create` (T1047)
- `cscript.exe` / `wscript.exe` from unusual directories (T1059.005)
- `regsvr32.exe /s /n /u /i:http://` (T1218.010 — Squiblydoo)
- `msiexec.exe /q /i http://` (T1218.007)
- Processes with parent `wmiprvse.exe` not matching expected WMI activity
- Processes from `C:\Users\Public\`, `C:\ProgramData\`, `%TEMP%`, `C:\Windows\Temp\`
- `nltest.exe /dclist` or `/domain_trusts` (T1482 — domain trust discovery)
- `net.exe group "domain admins" /domain` (T1069.002)
- `whoami.exe /all` (T1033)
- `tasklist.exe /v` (T1057)
- `qprocess.exe *`, `query.exe user` (T1033)

---

## 3. Security Event IDs — Account Management

### User Account Events

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4720** | User account was created | HIGH | T1136.001, T1136.002 |
| **4722** | User account was enabled | HIGH | T1098 |
| **4723** | Attempt to change account password | MEDIUM | T1098 |
| **4724** | Attempt to reset account password | HIGH | T1098 |
| **4725** | User account was disabled | MEDIUM | — |
| **4726** | User account was deleted | MEDIUM | T1531 |
| **4738** | User account was changed | HIGH | T1098 |
| **4740** | User account was locked out | MEDIUM | T1110 |
| **4741** | Computer account was created | MEDIUM | T1136.002 |
| **4742** | Computer account was changed | HIGH | T1098 |
| **4743** | Computer account was deleted | MEDIUM | — |
| **4767** | User account was unlocked | LOW | — |
| **4781** | Account name was changed | HIGH | T1078.002, T1098 |
| **4782** | Password hash was accessed | HIGH | T1003 |
| **4793** | Password Policy Checking API was called | LOW | T1201 |

### Group Management Events

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4727** | Security-enabled global group was created | MEDIUM | T1136.002 |
| **4728** | Member added to security-enabled global group | HIGH | T1098 |
| **4729** | Member removed from security-enabled global group | MEDIUM | — |
| **4730** | Security-enabled global group was deleted | MEDIUM | — |
| **4731** | Security-enabled local group was created | MEDIUM | T1136.001 |
| **4732** | Member added to security-enabled local group | HIGH | T1098 |
| **4733** | Member removed from security-enabled local group | MEDIUM | — |
| **4734** | Security-enabled local group was deleted | MEDIUM | — |
| **4735** | Security-enabled local group was changed | MEDIUM | T1098 |
| **4737** | Security-enabled global group was changed | MEDIUM | T1098 |
| **4754** | Security-enabled universal group was created | MEDIUM | T1136.002 |
| **4755** | Security-enabled universal group was changed | MEDIUM | T1098 |
| **4756** | Member added to security-enabled universal group | HIGH | T1098 |
| **4757** | Member removed from security-enabled universal group | MEDIUM | — |
| **4758** | Security-enabled universal group was deleted | MEDIUM | — |
| **4764** | A group's type was changed | MEDIUM | T1098 |
| **4780** | ACL set on accounts in administrators groups | HIGH | T1098 |

#### Legitimate vs. Attack — Account Management

**Legitimate (4720 - Account Created):** HR-driven onboarding via IAM systems, consistent naming convention, created by known admin accounts, during business hours.

**Attack (4720):**
- Account created by non-admin user or unexpected admin
- Account created outside change management windows
- Account name mimicking existing accounts (e.g., `administrator1`, `svc_backup2`)
- Account created then immediately added to privileged groups (4728/4732/4756)
- Account created on domain controller directly

**Legitimate (4728/4732/4756 - Group Add):** IAM-driven role changes, approved access requests with change tickets.

**Attack (4728/4732/4756):**
- User added to Domain Admins, Enterprise Admins, Schema Admins, Administrators
- Adding to "Backup Operators" or "Remote Desktop Users" (T1098)
- Group membership change immediately after 4720 (new account straight to admin)
- Adding computer accounts to privileged groups
- Changes by unexpected accounts

**Legitimate (4738 - Account Changed):** Password resets, account attribute updates by helpdesk.

**Attack (4738):**
- `DontExpirePassword` flag set (persistence)
- `TrustedForDelegation` or `TrustedToAuthForDelegation` enabled (T1558)
- `msDS-AllowedToDelegateTo` attribute modified (constrained delegation abuse)
- `servicePrincipalName` modified (Kerberoasting setup — T1558.003)
- UAC flags modified to enable reversible encryption
- `AllowReversiblePasswordEncryption` enabled

---

## 4. Security Event IDs — Kerberos Authentication

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4768** | Kerberos TGT was requested (AS-REQ) | MEDIUM | T1558.004, T1078 |
| **4769** | Kerberos service ticket was requested (TGS-REQ) | MEDIUM | T1558.003 |
| **4770** | Kerberos service ticket was renewed | LOW | — |
| **4771** | Kerberos pre-authentication failed | HIGH | T1558.004, T1110 |
| **4772** | Kerberos authentication ticket request failed | MEDIUM | — |
| **4773** | Kerberos service ticket request failed | MEDIUM | — |

### Event 4768 — TGT Request

**Key fields:** `TicketEncryptionType`, `PreAuthType`, `IpAddress`, `TargetUserName`

#### Legitimate vs. Attack — Event 4768

**Legitimate:** Regular user logon, machine startup, domain authentication at workstation boot.

**Attack indicators:**
- Encryption type `0x17` (RC4-HMAC) when environment expects AES — pass-the-hash / overpass-the-hash
- Encryption type `0x17` for service accounts — AS-REP roasting (T1558.004)
- Source IP that doesn't match the user's known workstation
- TGT requested for service account from workstation (should originate from service host)
- High volume of TGT requests from single source (credential stuffing)

### Event 4769 — Service Ticket Request (Kerberoasting Detection)

**Key fields:** `ServiceName`, `TicketEncryptionType`, `IpAddress`, `TargetUserName`, `FailureCode`

#### Legitimate vs. Attack — Event 4769

**Legitimate:** Service ticket requests for file shares, SQL servers, web apps — normal service access patterns.

**Attack — Kerberoasting (T1558.003):**
- Multiple service ticket requests for different SPNs from same source in short window
- Requests for service accounts with `RC4` encryption (`0x17`) when AES is configured
- Requests targeting service accounts known to have weak passwords
- Service tickets requested for accounts not typically accessed by the requesting user
- FailureCode `0x3C` — indicates forged PAC (MS14-068)

**Attack — Golden Ticket indicators (T1558.001):**
- Event 4769 WITHOUT preceding 4768 (TGT not issued by DC)
- TGT with unusually long lifetime (default 10h, Golden Tickets often set to 10y)
- Domain field mismatch or case inconsistency
- Account name does not exist in AD but TGT is accepted

**Attack — Silver Ticket indicators (T1558.002):**
- Service access events (4624 Type 3) without corresponding 4769 on the DC
- Service ticket decrypted successfully but DC has no record of issuance
- Events visible only on the target service host, not on the DC

### Event 4771 — Pre-Authentication Failed

| Failure Code | Meaning | Attack Context |
|--------------|---------|----------------|
| 0x6 | Client not found in database | User enumeration |
| 0x12 | Client's credentials revoked | Disabled/locked account |
| 0x17 | Password has expired | Stale credentials |
| 0x18 | Pre-authentication failed (wrong password) | Password spraying |
| 0x25 | Clock skew too great | Ticket forgery attempt |

**Attack pattern:** High volume of 0x18 failures for different accounts from same source IP = password spray.

---

## 5. Security Event IDs — Privilege Use

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4672** | Special privileges assigned to new logon | HIGH | T1078 |
| **4673** | A privileged service was called | MEDIUM | T1068 |
| **4674** | Operation attempted on a privileged object | MEDIUM | T1068 |
| **4703** | Token right was adjusted | HIGH | T1134 |
| **4704** | User right was assigned | HIGH | T1134 |
| **4705** | User right was removed | MEDIUM | — |
| **4717** | System security access was granted | MEDIUM | T1134 |
| **4718** | System security access was removed | MEDIUM | — |

### Event 4672 — Special Privileges (Critical Sentinel)

Fires when an account with any of these privileges logs on:
- `SeAssignPrimaryTokenPrivilege` — Replace process token
- `SeBackupPrivilege` — Bypass DACL for read (backup operators)
- `SeDebugPrivilege` — Debug programs (mimikatz requires this)
- `SeImpersonatePrivilege` — Impersonate client after authentication (potato attacks)
- `SeLoadDriverPrivilege` — Load kernel driver
- `SeRestorePrivilege` — Bypass DACL for write
- `SeSecurityPrivilege` — Manage audit and security log
- `SeTakeOwnershipPrivilege` — Take ownership of objects
- `SeTcbPrivilege` — Act as part of the operating system

#### Legitimate vs. Attack — Event 4672

**Legitimate:** SYSTEM account, domain admin accounts during authorized maintenance, service accounts at service startup.

**Attack:** 4672 for a user account not in administrative groups, 4672 immediately followed by credential dumping indicators (4656 access to lsass.exe), 4672 with `SeDebugPrivilege` for standard user.

### Event 4703 — Token Rights Adjusted

**Attack relevance:** Fires when `SeDebugPrivilege` is explicitly enabled — key indicator of mimikatz/credential dumping preparation. Legitimate processes rarely enable debug privileges post-logon.

---

## 6. Security Event IDs — Object Access

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4656** | Handle to an object was requested | MEDIUM | T1003, T1546 |
| **4657** | Registry value was modified | MEDIUM | T1112 |
| **4658** | Handle to an object was closed | LOW | — |
| **4659** | Handle requested with intent to delete | MEDIUM | T1070 |
| **4660** | An object was deleted | MEDIUM | T1070 |
| **4661** | Handle to an object was requested | MEDIUM | T1003 |
| **4662** | Operation performed on an object | HIGH | T1003.006, T1207 |
| **4663** | Attempt to access an object | MEDIUM | T1005 |
| **4664** | Attempt to create a hard link | HIGH | T1547.009 |
| **4670** | Permissions on an object were changed | HIGH | T1222.001 |

### Event 4662 — DCSync Detection (Critical)

This event is the primary detector for DCSync attacks (T1003.006).

**Detection logic:** Look for 4662 with:
- `Properties` containing: `{1131f6aa-9c07-11d1-f79f-00c04fc2dcd2}` (DS-Replication-Get-Changes)
- `Properties` containing: `{1131f6ad-9c07-11d1-f79f-00c04fc2dcd2}` (DS-Replication-Get-Changes-All)
- `Properties` containing: `{89e95b76-444d-4c62-991a-0facbeda640c}` (DS-Replication-Get-Changes-In-Filtered-Set)
- Account performing the operation is NOT a domain controller machine account

**Legitimate:** Domain controller replication (machine account ending in `$`).

**Attack:** Any user account (not a DC machine account) requesting replication rights = DCSync.

### Event 4664 — Hard Link Creation

**Attack relevance:** Creating hard links to protected files (e.g., SAM, SYSTEM hive). Used to bypass file protections for credential extraction.

---

## 7. Security Event IDs — Audit Policy & System

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4608** | Windows is starting up | LOW | — |
| **4609** | Windows is shutting down | LOW | — |
| **4610** | Authentication package loaded by LSA | HIGH | T1547.002 |
| **4611** | Trusted logon process registered with LSA | MEDIUM | — |
| **4612** | Audit message queue resources exhausted | HIGH | T1562.002 |
| **4614** | Notification package loaded by SAM | MEDIUM | T1547.002 |
| **4616** | System time was changed | MEDIUM | T1070.006 |
| **4618** | Monitored security event pattern occurred | HIGH | — |
| **4621** | Admin recovered from CrashOnAuditFail | MEDIUM | T1562.002 |
| **4622** | Security package loaded by LSA | HIGH | T1547.008 |
| **4649** | Replay attack was detected | HIGH | T1558 |
| **4706** | New trust was created to a domain | HIGH | T1484.002 |
| **4713** | Kerberos policy was changed | HIGH | T1484 |
| **4714** | Encrypted data recovery policy changed | MEDIUM | — |
| **4715** | Audit policy (SACL) on object changed | MEDIUM | T1562.002 |
| **4716** | Trusted domain information modified | HIGH | T1484.002 |
| **4719** | System audit policy was changed | HIGH | T1562.002 |
| **4739** | Domain policy was changed | HIGH | T1484 |
| **4794** | DSRM password set attempt | HIGH | T1098 |
| **4897** | Role separation enabled | HIGH | — |
| **4906** | CrashOnAuditFail value changed | MEDIUM | T1562.002 |
| **4907** | Auditing settings on object changed | MEDIUM | T1562.002 |
| **4908** | Special Groups Logon table modified | MEDIUM | T1562.002 |
| **4912** | Per User Audit Policy changed | MEDIUM | T1562.002 |
| **4964** | Special groups assigned to new logon | HIGH | T1078 |

### Event 4719 — Audit Policy Changed (Critical Sentinel)

**Legitimate:** GPO refresh applying audit policy, authorized security team changes.

**Attack:** Attacker disabling audit categories to blind defenders. Any 4719 event should trigger immediate investigation to determine who changed what, from where, and whether a change ticket exists.

### Event 4610/4614/4622 — LSA/SAM Package Loading

**Attack relevance:** Custom authentication or security packages loaded into LSA = possible SSP injection for credential harvesting (T1547.002/T1547.008). Mimilib.dll loaded as a Security Package captures plaintext passwords.

---

## 8. Security Event IDs — Directory Services

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **5136** | Directory service object was modified | HIGH | T1207, T1484 |
| **5137** | Directory service object was created | HIGH | T1207 |
| **5138** | Directory service object was undeleted | MEDIUM | — |
| **5139** | Directory service object was moved | MEDIUM | — |
| **5141** | Directory service object was deleted | HIGH | T1207 |

### Event 5136 — AD Object Modification (Critical)

**Detection targets:**
- SPN modifications on user accounts (Kerberoasting setup — T1558.003)
- `msDS-AllowedToDelegateTo` changes (delegation abuse)
- `userAccountControl` flag changes (T1098)
- `AdminSDHolder` ACL modifications
- GPO object modifications (T1484.001)
- `nTSecurityDescriptor` changes on OUs or domain root (ACL abuse)
- `msDS-KeyCredentialLink` modification (Shadow Credentials — T1556.006)
- `dNSHostName` or `sAMAccountName` spoofing on computer accounts (CVE-2022-26923, CVE-2021-42278)

### Event 5137 — AD Object Created

**Attack relevance:** DCShadow attack creates rogue domain controller objects (T1207). Monitor for computer objects with `serverReferenceBL` being created by non-DC accounts.

---

## 9. Security Event IDs — Network Share & Firewall

### Network Share Events

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **5140** | Network share object was accessed | MEDIUM | T1021.002 |
| **5142** | Network share object was added | MEDIUM | — |
| **5143** | Network share object was modified | HIGH | T1222.001 |
| **5144** | Network share object was deleted | MEDIUM | — |
| **5145** | Network share object checked for access | HIGH | T1021.002, T1053.005, T1569.002 |

#### Event 5145 — Share Access Check (High Value)

**Attack indicators:**
- Access to `ADMIN$` share from non-admin workstations (PsExec, lateral movement)
- Access to `IPC$` with write to `\pipe\svcctl` (remote service creation)
- Access to `IPC$` with write to `\pipe\atsvc` (remote scheduled task)
- Access to `C$` or `ADMIN$` from unexpected sources
- Access to `SYSVOL` or `NETLOGON` shares from non-domain member systems
- Access to `\pipe\spoolss` (PrintNightmare, print spooler abuse)

### Firewall Events

| Event ID | Log Source | Name | Criticality | ATT&CK |
|----------|-----------|------|-------------|--------|
| **2003** | Microsoft-Windows-Windows Firewall With Advanced Security | Firewall profile disabled | HIGH | T1562.004 |
| **2004** | Microsoft-Windows-Windows Firewall With Advanced Security | Firewall rule created | HIGH | T1562.004 |
| **2005** | Microsoft-Windows-Windows Firewall With Advanced Security | Firewall rule modified | MEDIUM | T1562.004 |
| **2006** | Microsoft-Windows-Windows Firewall With Advanced Security | Firewall rule deleted | MEDIUM | T1562.004 |
| **4946** | Security | Firewall exception list — rule added | MEDIUM | T1562.004 |
| **4947** | Security | Firewall exception list — rule modified | MEDIUM | T1562.004 |
| **4948** | Security | Firewall exception list — rule deleted | MEDIUM | T1562.004 |
| **4950** | Security | Firewall setting changed | HIGH | T1562.004 |
| **5025** | Security | Windows Firewall Service stopped | HIGH | T1562.004 |

---

## 10. Sysmon Event IDs — Complete Reference

Sysmon (System Monitor) provides 29 event types with deep visibility into system activity. Requires separate installation from Microsoft Sysinternals.

### All 29 Sysmon Event Types

| Event ID | Name | Detection Value | Key Fields | ATT&CK Coverage |
|----------|------|-----------------|------------|-----------------|
| **1** | Process Creation | **CRITICAL** | Image, CommandLine, ParentImage, ParentCommandLine, Hashes, User, IntegrityLevel | T1059, T1204, T1053, T1569 |
| **2** | File creation time changed | HIGH | TargetFilename, PreviousCreationUtcTime | T1070.006 (Timestomping) |
| **3** | Network Connection | HIGH | SourceIp, SourcePort, DestinationIp, DestinationPort, Protocol, Image | T1071, T1095, T1041 |
| **4** | Sysmon service state changed | LOW | State | — |
| **5** | Process Terminated | LOW | Image, ProcessId | — |
| **6** | Driver Loaded | HIGH | ImageLoaded, Hashes, Signed, Signature | T1014, T1068, T1543.003 |
| **7** | Image Loaded | MEDIUM | ImageLoaded, Image, Hashes, Signed | T1574.001, T1574.002 |
| **8** | CreateRemoteThread | **CRITICAL** | SourceImage, TargetImage, StartAddress, StartModule | T1055 (Process Injection) |
| **9** | RawAccessRead | HIGH | Device, Image | T1006 (Direct Volume Access) |
| **10** | Process Access | **CRITICAL** | SourceImage, TargetImage, GrantedAccess | T1003.001 (LSASS access) |
| **11** | File Created | MEDIUM | TargetFilename, Image | T1105, T1036, T1547 |
| **12** | Registry Object Added/Deleted | HIGH | TargetObject, EventType | T1547.001, T1112 |
| **13** | Registry Value Set | HIGH | TargetObject, Details | T1547.001, T1112, T1546.007 |
| **14** | Registry Object Renamed | MEDIUM | TargetObject, NewName | T1112 |
| **15** | FileCreateStreamHash | HIGH | TargetFilename, Hash | T1564.004 (ADS) |
| **16** | Sysmon Config State Changed | LOW | Configuration | — |
| **17** | Pipe Created | HIGH | PipeName, Image | T1570, T1021.002 |
| **18** | Pipe Connected | HIGH | PipeName, Image | T1570, T1021.002 |
| **19** | WMI Event Filter Created | **CRITICAL** | EventNamespace, Name, Query | T1546.003 |
| **20** | WMI Event Consumer Created | **CRITICAL** | Name, Type, Destination | T1546.003 |
| **21** | WMI Event Consumer-to-Filter Binding | **CRITICAL** | Consumer, Filter | T1546.003 |
| **22** | DNS Query | MEDIUM | QueryName, QueryResults, Image | T1071.004, T1568 |
| **23** | File Delete (archived) | HIGH | TargetFilename, Image, Hashes | T1070.004 |
| **24** | Clipboard Change | MEDIUM | ClientInfo | T1115 |
| **25** | Process Tampering | **CRITICAL** | Image, Type | T1055.009 (Process Hollowing) |
| **26** | File Delete Logged | MEDIUM | TargetFilename, Image | T1070.004 |
| **27** | File Block Executable | HIGH | TargetFilename, Image | T1105 |
| **28** | File Block Shredding | HIGH | TargetFilename, Image | T1070.004 |
| **29** | File Executable Detected | MEDIUM | TargetFilename, Image, Hashes | T1105 |
| **255** | Sysmon Error | LOW | — | — |

### Critical Sysmon Detection Patterns

#### Sysmon 1 — Process Creation (Highest Value)

**Parent-child anomalies to detect:**

| Parent Process | Suspicious Child | Technique |
|----------------|-----------------|-----------|
| `winword.exe` | `cmd.exe`, `powershell.exe`, `wscript.exe` | T1204.002 — Malicious document |
| `excel.exe` | `cmd.exe`, `powershell.exe`, `mshta.exe` | T1204.002 — Malicious document |
| `outlook.exe` | `cmd.exe`, `powershell.exe` | T1204.002 — Phishing payload |
| `w3wp.exe` | `cmd.exe`, `powershell.exe` | T1190 — Web shell |
| `sqlservr.exe` | `cmd.exe`, `powershell.exe` | T1505.001 — xp_cmdshell |
| `wmiprvse.exe` | `cmd.exe`, `powershell.exe` | T1047 — WMI execution |
| `services.exe` | `cmd.exe` (unknown service) | T1569.002 — Service execution |
| `svchost.exe` | `cmd.exe` (unexpected) | T1053.005 — Scheduled task |
| `mshta.exe` | any child | T1218.005 — Mshta proxy |
| `rundll32.exe` | without DLL argument | T1218.011 — Rundll32 proxy |
| `sdbinst.exe` | any | T1546.011 — Application shimming |
| `cmstp.exe` | any | T1218.003 — CMSTP bypass |

#### Sysmon 8 — CreateRemoteThread (Injection Detection)

**Legitimate:** Anti-virus scanning processes, debuggers, some legitimate software (e.g., input method editors).

**Attack indicators:**
- Source image is `powershell.exe` injecting into any process
- Any process injecting into `lsass.exe` (credential theft)
- Unknown/unsigned executables creating threads in system processes
- Thread creation from `%TEMP%`, `%APPDATA%`, `%PUBLIC%` executables
- `StartAddress` outside of known module ranges (shellcode injection)

#### Sysmon 10 — Process Access (LSASS Protection)

**Critical detection:** Access to `lsass.exe` with `GrantedAccess` of:
- `0x1010` — PROCESS_QUERY_LIMITED_INFORMATION + PROCESS_VM_READ (mimikatz)
- `0x1038` — Common credential dumping access mask
- `0x1fffff` — PROCESS_ALL_ACCESS (aggressive dumping)
- `0x1410` — Another mimikatz variant access mask
- `0x143a` — Full read access pattern

**Legitimate LSASS access:** `csrss.exe`, `svchost.exe`, `lsm.exe`, `wininit.exe`, AV products with known hashes.

#### Sysmon 17/18 — Named Pipe Detection

**Suspicious pipe names:**

| Pipe Name | Tool/Technique |
|-----------|----------------|
| `\PSEXESVC` | PsExec lateral movement |
| `\msagent_*` | CobaltStrike default |
| `\MSSE-*-server` | CobaltStrike default |
| `\postex_*` | CobaltStrike post-exploitation |
| `\status_*` | CobaltStrike |
| `\mojo.*` | Chromium IPC (legitimate but abused) |
| `\winsock` | Potential C2 |
| Random GUIDs as pipe names | CobaltStrike / Metasploit SMB Beacon |

#### Sysmon 19/20/21 — WMI Persistence

**Attack pattern:** Events 19, 20, 21 appearing in sequence = WMI event subscription persistence (T1546.003). An `__EventFilter` (19) bound to a `CommandLineEventConsumer` (20) via a `__FilterToConsumerBinding` (21) creates persistent execution triggered by system events.

**Legitimate:** SCCM, antivirus WMI subscriptions, system management tools. Verify against known-good WMI subscription inventory.

---

## 11. PowerShell Logging Event IDs

### Microsoft-Windows-PowerShell/Operational

| Event ID | Name | Detection Value | ATT&CK |
|----------|------|-----------------|--------|
| **4103** | Module Logging | HIGH | T1059.001 |
| **4104** | Script Block Logging | **CRITICAL** | T1059.001 |
| **4105** | Script Block Logging — Start | LOW | — |
| **4106** | Script Block Logging — Stop | LOW | — |
| **40961** | PowerShell console startup | MEDIUM | — |
| **40962** | PowerShell console ready | LOW | — |
| **53504** | PowerShell loading provider | LOW | — |

### Windows PowerShell (Classic Log)

| Event ID | Name | Detection Value | ATT&CK |
|----------|------|-----------------|--------|
| **400** | Engine state changed — Available (PowerShell started) | MEDIUM | T1059.001 |
| **403** | Engine state changed — Stopped | LOW | — |
| **600** | Provider lifecycle — started | MEDIUM | — |
| **800** | Pipeline execution details | HIGH | T1059.001 |

### Event 4104 — Script Block Logging (Most Critical)

**Required GPO:** Computer Configuration > Admin Templates > Windows Components > Windows PowerShell > Turn on PowerShell Script Block Logging.

Captures deobfuscated PowerShell code at execution time — even if the script was encoded, obfuscated, or dynamically assembled, 4104 logs the final executed code block.

**Detection keywords in ScriptBlockText:**

| Keyword Pattern | Indicates |
|-----------------|-----------|
| `Invoke-Mimikatz` | Credential dumping |
| `Invoke-Expression` / `IEX` | Dynamic code execution |
| `[System.Convert]::FromBase64String` | Base64 decode + execute |
| `New-Object Net.WebClient` | Download cradle |
| `DownloadString` / `DownloadFile` | Remote payload fetch |
| `Invoke-Command -ComputerName` | Remote execution |
| `Enter-PSSession` | Interactive remote session |
| `Get-Process lsass` | LSASS reconnaissance |
| `[System.Runtime.InteropServices.Marshal]` | P/Invoke for native API |
| `VirtualAlloc` / `CreateThread` | Shellcode injection |
| `Add-Type -MemberDefinition` | Dynamic C# compilation |
| `Invoke-ReflectivePEInjection` | Reflective DLL injection |
| `Invoke-Shellcode` | Direct shellcode execution |
| `Get-Keystrokes` | Keylogging |
| `Get-TimedScreenshot` | Screen capture |
| `Invoke-TokenManipulation` | Token impersonation |
| `Invoke-CredentialInjection` | Credential injection |
| `Invoke-DllInjection` | DLL injection |
| `Invoke-WmiCommand` | WMI-based execution |
| `Out-Minidump` | LSASS memory dump |
| `Set-MasterBootRecord` | MBR destruction |
| `Get-GPPPassword` | Group Policy Preference passwords |
| `Invoke-Kerberoast` | Kerberoasting |
| `Invoke-DCSync` | Domain replication |
| `-bxor` / `-band` with loops | XOR/byte obfuscation |
| `[System.IO.Compression.DeflateStream]` | Compressed payload |
| `$DoIt` / `$ForEach` with unusual patterns | PowerSploit framework |

### Event 4103 — Module Logging

Captures cmdlet invocations with parameters. Lower noise than 4104 but captures execution context including the pipeline.

**Configuration:** Enable via GPO and set `*` for all modules, or target specific modules:
- `Microsoft.PowerShell.Management`
- `Microsoft.PowerShell.Utility`
- `ActiveDirectory`

#### Legitimate vs. Attack — PowerShell Events

**Legitimate:** Admin scripts, SCCM operations, DSC (Desired State Configuration), Azure AD Connect, Exchange management.

**Attack indicators:**
- Script block with `SuspiciousContentChecker` flag = `True` (Windows auto-flags suspicious content)
- PowerShell launched with `-ExecutionPolicy Bypass`, `-NoProfile`, `-WindowStyle Hidden`
- PowerShell invoked by unusual parent (Word, Excel, WMI, IIS)
- Large base64 strings in 4104 events
- AMSI bypass patterns: `[Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)`
- PowerShell 2.0 downgrade: `powershell -Version 2` bypasses Script Block Logging (requires .NET 2.0 / 3.5)

---

## 12. Task Scheduler Event IDs

### Microsoft-Windows-TaskScheduler/Operational

| Event ID | Name | Detection Value | ATT&CK |
|----------|------|-----------------|--------|
| **100** | Task started | MEDIUM | T1053.005 |
| **101** | Task start failed | LOW | — |
| **102** | Task completed | LOW | — |
| **106** | Task registered (created) | **CRITICAL** | T1053.005 |
| **107** | Task triggered on scheduler | MEDIUM | — |
| **108** | Task triggered on event | HIGH | — |
| **110** | Task triggered by user | MEDIUM | — |
| **118** | Task triggered by logon | HIGH | T1053.005 |
| **119** | Task triggered by idle | LOW | — |
| **129** | Created task process | HIGH | T1053.005 |
| **140** | Task updated | HIGH | T1053.005 |
| **141** | Task deleted | MEDIUM | T1070 |
| **142** | Task disabled | MEDIUM | — |
| **200** | Action started | MEDIUM | — |
| **201** | Action completed | LOW | — |
| **325** | Launch request queued | LOW | — |

### Security Log — Task Scheduler

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4698** | Scheduled task created | **CRITICAL** | T1053.005 |
| **4699** | Scheduled task deleted | MEDIUM | T1070 |
| **4700** | Scheduled task enabled | MEDIUM | T1053.005 |
| **4701** | Scheduled task disabled | MEDIUM | — |
| **4702** | Scheduled task updated | HIGH | T1053.005 |

### Event 4698/106 — Task Creation (Critical)

**Key fields in 4698:** `TaskName`, `TaskContent` (XML with actions, triggers, principal)

**Legitimate:** Software update tasks, system maintenance, IT management tools, known backup software.

**Attack indicators:**
- Task executing from `%TEMP%`, `%PUBLIC%`, `%APPDATA%`, or `C:\ProgramData` paths
- Task running PowerShell with encoded commands
- Task with `cmd.exe /c` executing remote payloads
- Task name mimicking system tasks but in wrong location
- Task set to `SYSTEM` principal with trigger at boot (persistence)
- Task created remotely (correlate with 4624 Type 3 + 5145 `\pipe\atsvc`)
- Task action pointing to `\\UNC\path` (remote payload fetch)
- Task created then immediately deleted (4698 + 4699 in seconds — one-shot execution)
- Task with `Hidden` attribute set to `true`
- Trigger based on user logon or workstation unlock (credential harvesting)

---

## 13. Windows Defender Event IDs

### Microsoft-Windows-Windows Defender/Operational

| Event ID | Name | Detection Value | ATT&CK |
|----------|------|-----------------|--------|
| **1000** | Antimalware scan started | LOW | — |
| **1001** | Antimalware scan completed | LOW | — |
| **1002** | Antimalware scan stopped before completion | MEDIUM | T1562.001 |
| **1005** | Scan failed | MEDIUM | T1562.001 |
| **1006** | Malware or unwanted software detected | **CRITICAL** | — |
| **1007** | Action taken against malware | HIGH | — |
| **1008** | Action against malware failed | **CRITICAL** | T1562.001 |
| **1009** | Item restored from quarantine | HIGH | — |
| **1010** | Item not restored from quarantine | MEDIUM | — |
| **1011** | Item deleted from quarantine | MEDIUM | — |
| **1012** | Item quarantine failed | HIGH | — |
| **1013** | Malware history deleted | HIGH | T1070 |
| **1015** | Suspicious behavior detected | HIGH | — |
| **1116** | Malware or unwanted software detected | **CRITICAL** | — |
| **1117** | Action taken to protect against malware | HIGH | — |
| **1118** | Action to protect against malware failed | **CRITICAL** | T1562.001 |
| **1119** | Action to protect against malware — critical error | **CRITICAL** | T1562.001 |
| **1150** | Suspicious behavior detected (detailed) | HIGH | — |
| **1151** | Antivirus product outdated | MEDIUM | — |
| **2001** | Definition update failed | MEDIUM | T1562.001 |
| **2003** | Engine update failed | MEDIUM | — |
| **2004** | Unknown malware definition update event | LOW | — |
| **2010** | Engine used for scanning is outdated | MEDIUM | — |
| **2012** | Engine update failed | MEDIUM | — |
| **3002** | Real-time protection failed | **CRITICAL** | T1562.001 |
| **5000** | Real-time protection enabled | LOW | — |
| **5001** | Real-time protection disabled | **CRITICAL** | T1562.001 |
| **5004** | Real-time protection configuration changed | HIGH | T1562.001 |
| **5007** | Configuration changed | HIGH | T1562.001 |
| **5008** | Engine failure | HIGH | T1562.001 |
| **5010** | Scanning for malware disabled | **CRITICAL** | T1562.001 |
| **5012** | Scanning for viruses disabled | **CRITICAL** | T1562.001 |

### Event 5007 — Configuration Changed (Exclusion Detection)

**Critical attack pattern:** Defenders add exclusions before deploying payloads (T1562.001).

**Detection:** Monitor `5007` for changes to:
- `HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths` — folder/file exclusions
- `HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Extensions` — extension exclusions
- `HKLM\SOFTWARE\Microsoft\Windows Defender\Exclusions\Processes` — process exclusions

**Legitimate:** Admin adding exclusions for known-good software, development directories.

**Attack:** Exclusions added for `C:\Users\Public`, `C:\ProgramData`, `*.exe` extensions, `powershell.exe` process. Exclusion added immediately before suspicious file write.

---

## 14. WMI Event IDs

### Microsoft-Windows-WMI-Activity/Operational

| Event ID | Name | Detection Value | ATT&CK |
|----------|------|-----------------|--------|
| **5857** | WMI provider loaded | MEDIUM | T1047 |
| **5858** | WMI query error | LOW | — |
| **5859** | WMI provider operation | MEDIUM | T1047 |
| **5860** | WMI temporary event registration | HIGH | T1546.003 |
| **5861** | WMI permanent event registration | **CRITICAL** | T1546.003 |

### Event 5861 — Permanent Event Subscription (Critical)

**Attack relevance:** Permanent WMI event subscriptions survive reboot and provide fileless persistence.

**Components captured:**
- `__EventFilter` — The trigger condition (e.g., `SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName='explorer.exe'`)
- `CommandLineEventConsumer` or `ActiveScriptEventConsumer` — The payload
- `__FilterToConsumerBinding` — Links filter to consumer

**Legitimate:** SCCM, some AV products, system management software. Maintain a baseline inventory.

**Attack:** Consumer executing PowerShell, cmd.exe, or scripts from unusual locations. Filter triggering on process start, logon events, or timer intervals. Any ActiveScriptEventConsumer is highly suspicious in modern environments.

---

## 15. RDP Event IDs — All Relevant Logs

### Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational

| Event ID | Name | Detection Value |
|----------|------|-----------------|
| **261** | Listener received a connection | MEDIUM |
| **1149** | User authentication succeeded | **CRITICAL** |

### Microsoft-Windows-TerminalServices-LocalSessionManager/Operational

| Event ID | Name | Detection Value |
|----------|------|-----------------|
| **21** | Remote Desktop Services: Session logon succeeded | HIGH |
| **22** | Remote Desktop Services: Shell start notification | MEDIUM |
| **23** | Remote Desktop Services: Session logoff succeeded | LOW |
| **24** | Remote Desktop Services: Session has been disconnected | MEDIUM |
| **25** | Remote Desktop Services: Session reconnection succeeded | HIGH |
| **39** | Session disconnected by session | MEDIUM |
| **40** | Session disconnected (reason code) | MEDIUM |

### Microsoft-Windows-TerminalServices-RDPClient/Operational (Source)

| Event ID | Name | Detection Value |
|----------|------|-----------------|
| **1024** | RDP client is trying to connect | HIGH |
| **1025** | RDP client has connected to server | MEDIUM |
| **1026** | RDP client disconnected | LOW |
| **1027** | Connected using IP (no DNS) | MEDIUM |
| **1029** | Base64(SHA256(UserName)) used for connection | MEDIUM |
| **1102** | Client has connected to server | LOW |

### Security Log — RDP-Related

| Event ID | Logon Type | Description |
|----------|------------|-------------|
| **4624** | Type 10 | RemoteInteractive — RDP logon |
| **4624** | Type 7 | Unlock (can follow RDP disconnect/reconnect) |
| **4625** | — | Failed RDP logon |
| **4634** | — | RDP session logoff |
| **4778** | — | Session reconnected to Window Station |
| **4779** | — | Session disconnected from Window Station |

#### Legitimate vs. Attack — RDP Events

**Legitimate:** IT admins connecting from jump servers, helpdesk remote support during business hours, connections from known management subnets.

**Attack indicators:**
- RDP from workstation-to-workstation (not from jump server)
- RDP connections outside business hours
- RDP to domain controllers from non-admin workstations
- Source IP is external or not in asset inventory
- RDP after initial compromise (4624 Type 3 followed by enabling RDP, then 4624 Type 10)
- RDP tunneled through port forwarding (Htran — Event 1149 after suspicious network events)
- Multiple destination hosts from same source in short period (lateral movement sweep)
- Session 24/25 rapid disconnect/reconnect pattern (session hijacking)
- RDP from system with no prior RDP client activity (RDPClient Event 1024 — new behavior)
- NLA disabled (allows pre-authentication — credential exposure)
- RDP on non-standard ports (correlate Sysmon Event 3 with unusual destination ports)

---

## 16. Service Installation Event IDs

### System Log

| Event ID | Name | Detection Value | ATT&CK |
|----------|------|-----------------|--------|
| **7000** | Service failed to start | MEDIUM | T1569.002 |
| **7001** | Service depends on another service that failed | LOW | — |
| **7009** | Timeout waiting for service to connect | MEDIUM | T1569.002 |
| **7034** | Service terminated unexpectedly | MEDIUM | T1569.002 |
| **7035** | Service Control Manager sent a control (start/stop) | MEDIUM | T1569.002 |
| **7036** | Service entered running/stopped state | LOW | — |
| **7040** | Service start type changed | HIGH | T1543.003 |
| **7045** | A service was installed in the system | **CRITICAL** | T1543.003, T1569.002 |

### Security Log

| Event ID | Name | Criticality | ATT&CK |
|----------|------|-------------|--------|
| **4697** | A service was installed in the system | **CRITICAL** | T1543.003, T1569.002 |

### Event 7045/4697 — Service Installation (Critical Sentinel)

**Key fields (7045):** `ServiceName`, `ImagePath`, `ServiceType`, `StartType`, `AccountName`

**Legitimate:** Software installations, Windows Updates, driver installations, enterprise management agents.

**Attack indicators:**
- Service `ImagePath` containing `cmd.exe /c`, `powershell.exe -enc`, or download cradles
- Service binary in `%TEMP%`, `%PUBLIC%`, `%APPDATA%`, or user-writable directories
- Service name that is random characters or mimics system services
- Service running as `LocalSystem` installed by non-admin
- Service `ImagePath` pointing to `\\UNC\path` (remote payload)
- PSEXESVC service installation (PsExec lateral movement)
- Service with `ServiceType` = `kernel driver` from unexpected source (rootkit)
- `StartType` = auto from unexpected software
- Service created then immediately deleted (one-shot execution)
- `ImagePath` containing `rundll32`, `regsvr32`, `mshta` (living-off-the-land)

**PsExec fingerprint:** 7045 with `ServiceName: PSEXESVC`, `ImagePath: %SystemRoot%\PSEXESVC.exe`, parent process `services.exe`.

---

## 17. JPCERT Tool-to-Event Mapping Table

Based on JPCERT CC's ToolAnalysisResultSheet — mapping attacker tools to the Windows events they generate.

### Command Execution Tools

#### PsExec (Sysinternals)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Source | Sysmon 1 | Sysmon | psexec.exe process creation with command line |
| Source | Sysmon 3 | Sysmon | Network connections to port 135, 445 |
| Source | Sysmon 13 | Sysmon | Registry write: `Sysinternals\PsExec\EulaAccepted` |
| Source | 4688 | Security | Process creation with privilege details |
| Source | 5156 | Security | Outbound TCP to ports 135, 445 |
| **Dest** | **7045** | **System** | **PSEXESVC service installed** |
| Dest | 7036 | System | PSEXESVC service state changes |
| Dest | Sysmon 1 | Sysmon | PSEXESVC.exe as child of services.exe |
| Dest | 5145 | Security | ADMIN$ and IPC$ share access |
| Dest | 5140 | Security | Network share access to ADMIN$/IPC$ |
| Dest | 4624 | Security | Type 3 (Network) logon with NTLM |
| Dest | 4672 | Security | Special privileges assigned |
| Dest | Sysmon 13 | Sysmon | Registry values set for PSEXESVC service |
| Dest | 4688 | Security | Remote process with parent PSEXESVC.exe |
| Dest | 4656/4663 | Security | Handle access to PSEXESVC.exe file |
| Dest | 4660 | Security | PSEXESVC.exe file deletion (cleanup) |

#### WMIC (Remote Execution)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Source | Sysmon 1 | Sysmon | wmic.exe with remote execution parameters |
| Source | Sysmon 3 | Sysmon | Network connection to dest port 135 |
| Source | 4688 | Security | wmic.exe process creation |
| Source | 4703 | Security | Token rights adjusted for wmic |
| Source | 5156 | Security | Outbound TCP to port 135 |
| **Dest** | **Sysmon 1** | **Sysmon** | **WmiPrvSE.exe spawned by svchost.exe** |
| Dest | 4624 | Security | Type 3 network logon |
| Dest | 4672 | Security | Special privileges for remote session |
| Dest | 4688 | Security | WmiPrvSE.exe process creation |
| Dest | 4673 | Security | Privileged service called |
| Dest | 4611 | Security | Trusted logon process registered |

#### Schtasks (Remote Scheduled Task)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Source | Sysmon 1 | Sysmon | schtasks.exe with /create /s parameters |
| Source | Sysmon 3 | Sysmon | Network to dest ports 135 + high ports |
| Source | 4648 | Security | Explicit credentials used for remote task |
| Source | 5156 | Security | Outbound connections allowed |
| **Dest** | **106** | **Task Scheduler** | **Task registered** |
| Dest | 200/201 | Task Scheduler | Task action started/completed |
| Dest | 4624 | Security | Type 3 network logon from source |
| Dest | 4672 | Security | Special privileges assigned |
| Dest | 4688 | Security | taskeng.exe and task command processes |
| Dest | Sysmon 13 | Sysmon | TaskCache registry writes |

### Credential Dumping Tools

#### Mimikatz — sekurlsa::logonpasswords

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Local | Sysmon 1 | Sysmon | mimikatz.exe process creation |
| Local | 4688 | Security | Process creation with privilege details |
| Local | **4673** | **Security** | **Privileged service call — SeDebugPrivilege** |
| Local | **4703** | **Security** | **Token right adjusted — debug privilege enabled** |
| Local | **Sysmon 10** | **Sysmon** | **Process access to lsass.exe** |
| Local | 4656 | Security | Handle request to lsass.exe |
| Local | 4663 | Security | lsass.exe memory read access |
| Local | 4658 | Security | Handle closed on lsass.exe |

#### Windows Credential Editor (WCE)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Local | Sysmon 1 | Sysmon | WCE executable process creation |
| Local | **Sysmon 10** | **Sysmon** | **Process access to lsass.exe** |
| Local | **Sysmon 8** | **Sysmon** | **CreateRemoteThread into lsass.exe** |
| Local | Sysmon 11 | Sysmon | wceaux.dll file created (temporary) |
| Local | 4688 | Security | Process creation |
| Local | 4656/4663 | Security | Handle and access to wceaux.dll |
| Local | 4660 | Security | wceaux.dll deleted |

#### ntdsutil (AD Database Dumping)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| DC | Sysmon 1 | Sysmon | ntdsutil.exe with "activate instance ntds" "ifm" |
| DC | 4688 | Security | ntdsutil.exe process creation |
| DC | **8222** | **Security** | **Shadow copy created for NTDS extraction** |
| DC | 4656 | Security | Handle to shadow copy snapshot |
| DC | 4661 | Security | SAM database object handle request |
| DC | 4624 | Security | Type 5 (Service) — SYSTEM logon |
| DC | 4672 | Security | SeBackupPrivilege, SeRestorePrivilege assigned |
| DC | 7036 | System | Volume Shadow Copy service state change |

### Evidence Deletion Tools

#### sdelete (Sysinternals Secure Delete)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Local | Sysmon 1 | Sysmon | sdelete.exe with target file parameters |
| Local | 4688 | Security | Process creation |
| Local | Sysmon 13 | Sysmon | Sysinternals EULA registry acceptance |
| Local | **4656** | **Security** | **Handle request with DELETE access** |
| Local | **4663** | **Security** | **File write (overwriting) access attempts** |
| Local | **4660** | **Security** | **Object deleted** |
| Local | 4658 | Security | Handle closed |

### Network Tunneling Tools

#### Htran (Connection Bouncer)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Relay | Sysmon 1 | Sysmon | Htran with tunnel parameters (-tran, -listen, -slave) |
| Relay | **Sysmon 3** | **Sysmon** | **Dual network connections — to attacker + destination** |
| Relay | 5156 | Security | WFP allowing outbound tunnel traffic |
| Relay | 4624 | Security | Logon via tunnel |
| Relay | 4672 | Security | Privileges assigned |
| Relay | **1149** | **TermSvc-RCM** | **RDP authentication via tunnel** |

### Domain Privilege Escalation

#### MS14-068 (Kerberos PAC Forgery)

| Location | Event ID | Log | Indicator |
|----------|----------|-----|-----------|
| Source | Sysmon 1 | Sysmon | ms14-068.exe and mimikatz execution |
| Source | Sysmon 3 | Sysmon | Network to DC ports 88 and 445 |
| Source | Sysmon 11 | Sysmon | TGT cache file created (TGT_user@domain.ccache) |
| Source | 4673 | Security | SeTcbPrivilege called by mimikatz |
| **DC** | **4768** | **Security** | **TGT request from exploit source** |
| **DC** | **4769** | **Security** | **Service ticket with failure code 0x3C (forged PAC)** |

### Tool Detection Summary Matrix

| Tool | Most Reliable Detection Event |
|------|------------------------------|
| **PsExec** | 7045 (PSEXESVC install) + 5145 (ADMIN$ access) |
| **Mimikatz** | Sysmon 10 (lsass access) + 4703 (SeDebugPrivilege) |
| **WCE** | Sysmon 8 (thread injection into lsass) + Sysmon 11 (wceaux.dll) |
| **WMIC remote** | Sysmon 1 (WmiPrvSE.exe child) + 4624 Type 3 |
| **schtasks remote** | 4698/106 (task created) + 4648 (explicit creds) |
| **ntdsutil** | 8222 (shadow copy) + 4661 (SAM handle) |
| **sdelete** | 4660 (object deleted) with preceding 4656 DELETE |
| **Htran** | Sysmon 3 (dual connections) + 1149 (RDP via tunnel) |
| **MS14-068** | 4769 failure code 0x3C on DC |
| **Golden Ticket** | 4769 without preceding 4768 |
| **Silver Ticket** | Service access without 4769 on DC |
| **DCSync** | 4662 with replication GUIDs from non-DC account |
| **Kerberoasting** | Burst of 4769 with RC4 encryption type |
| **AS-REP Roasting** | 4768 with RC4 for accounts with "no preauth" |
| **Password Spray** | Burst of 4771 (code 0x18) across accounts |
| **DCShadow** | 5137 (rogue DC object) + 4742 (SPN change) |
| **WMI Persistence** | Sysmon 19/20/21 (WMI subscription) or 5861 |
| **Scheduled Task Persistence** | 4698 + 106 from unexpected context |
| **Service Persistence** | 7045/4697 with suspicious ImagePath |
| **PowerShell Empire/Cobalt** | 4104 with encoded blocks + Sysmon 17 (named pipes) |

---

## 18. Event Log Clearing & Anti-Forensics

| Event ID | Log Source | Name | Criticality | ATT&CK |
|----------|-----------|------|-------------|--------|
| **104** | System | Event log was cleared | **CRITICAL** | T1070.001 |
| **1100** | Security | Event logging service shut down | **CRITICAL** | T1562.002 |
| **1102** | Security | Audit log was cleared | **CRITICAL** | T1070.001 |
| **1104** | Security | Security log is full | HIGH | T1562.002 |
| **4616** | Security | System time was changed | MEDIUM | T1070.006 |

### Event 1102/104 — Log Cleared (Critical Sentinel)

These events survive log clearing because they are written as the LAST event when a log is cleared.

**Legitimate:** Rare — sometimes during maintenance windows or troubleshooting. Should always have a change ticket.

**Attack:** Almost always malicious in production environments. Correlate the `SubjectUserName` and `SubjectDomainName` with authentication logs on other systems. The account that cleared logs is likely compromised.

**Detection tip:** Forward 1102 and 104 to a SIEM immediately upon generation. Even if the attacker clears local logs, the forwarded event persists.

### Timestomping Detection

Sysmon Event 2 (FileCreateTimeChanged) detects `$STANDARD_INFORMATION` timestamp modification. Cross-reference with `$FILE_NAME` timestamps in MFT for discrepancy (requires forensic tools).

---

## 19. Quick Reference — Critical Detection Matrix

### Tier 1 — Must Alert Immediately

| Detection | Primary Event(s) | Log Source |
|-----------|------------------|------------|
| Audit log cleared | 1102, 104 | Security, System |
| Audit policy changed | 4719 | Security |
| LSASS process access | Sysmon 10 (lsass.exe target) | Sysmon |
| Process injection | Sysmon 8 (CreateRemoteThread) | Sysmon |
| DCSync | 4662 with replication GUIDs | Security |
| Service installed (suspicious) | 7045, 4697 | System, Security |
| New admin account | 4720 + 4728/4732/4756 (to admin group) | Security |
| Defender disabled | 5001, 5010, 5012 | Defender |
| Defender exclusion added | 5007 (Exclusions path) | Defender |
| WMI persistent subscription | Sysmon 19/20/21, 5861 | Sysmon, WMI |
| Golden/Silver ticket | 4769 without 4768 | Security (DC) |

### Tier 2 — Investigate Within 1 Hour

| Detection | Primary Event(s) | Log Source |
|-----------|------------------|------------|
| Lateral movement via PsExec | 7045 (PSEXESVC) + 5145 (ADMIN$) | System, Security |
| Kerberoasting | Burst of 4769 RC4 | Security (DC) |
| Password spray | Burst of 4625/4771 | Security |
| Scheduled task created (suspicious) | 4698, 106 | Security, TaskScheduler |
| PowerShell suspicious script block | 4104 (flagged suspicious) | PowerShell |
| RDP from unexpected source | 4624 Type 10, 1149 | Security, TermSvc |
| Account modification (delegation) | 4738, 5136 | Security, DS |
| Firewall disabled | 2003, 4950 | Firewall, Security |
| Trust relationship change | 4706, 4716 | Security |
| Computer account manipulation | 4741, 4742 | Security |

### Tier 3 — Baseline and Trend

| Detection | Primary Event(s) | Log Source |
|-----------|------------------|------------|
| Failed logons (trending) | 4625 | Security |
| Process creation anomalies | 4688, Sysmon 1 | Security, Sysmon |
| Network connections anomalies | Sysmon 3 | Sysmon |
| DNS query anomalies | Sysmon 22 | Sysmon |
| Registry modifications | Sysmon 12/13/14 | Sysmon |
| File creation in suspicious dirs | Sysmon 11 | Sysmon |
| Service state changes | 7036, 7040 | System |
| Share access patterns | 5140, 5145 | Security |
| Explicit credential use | 4648 | Security |
| Handle access to sensitive objects | 4656, 4663 | Security |

---

## 20. Audit Policy Configuration Requirements

Without proper audit policy configuration, most events in this document will NOT be generated. Windows default audit settings are insufficient for security monitoring.

### Minimum Required Audit Policies

Configure via: `Computer Configuration > Security Settings > Advanced Audit Policy Configuration`

| Audit Category | Subcategory | Setting | Key Events Enabled |
|----------------|-------------|---------|-------------------|
| **Account Logon** | Credential Validation | Success + Failure | 4776, 4777 |
| **Account Logon** | Kerberos Authentication Service | Success + Failure | 4768, 4771, 4772 |
| **Account Logon** | Kerberos Service Ticket Operations | Success + Failure | 4769, 4770, 4773 |
| **Account Management** | Computer Account Management | Success | 4741, 4742, 4743 |
| **Account Management** | Security Group Management | Success | 4727-4758, 4764 |
| **Account Management** | User Account Management | Success + Failure | 4720-4726, 4738, 4740, 4767 |
| **Detailed Tracking** | Process Creation | Success | 4688 |
| **Detailed Tracking** | Process Termination | Success | 4689 |
| **DS Access** | Directory Service Access | Success + Failure | 4662 |
| **DS Access** | Directory Service Changes | Success | 5136, 5137, 5141 |
| **Logon/Logoff** | Logon | Success + Failure | 4624, 4625, 4648 |
| **Logon/Logoff** | Logoff | Success | 4634, 4647 |
| **Logon/Logoff** | Special Logon | Success | 4672, 4964 |
| **Logon/Logoff** | Other Logon/Logoff Events | Success + Failure | 4778, 4779, 4800, 4801 |
| **Object Access** | File Share | Success + Failure | 5140, 5145 |
| **Object Access** | Detailed File Share | Success + Failure | 5145 |
| **Object Access** | Registry | Success | 4657 |
| **Object Access** | SAM | Success | 4661 |
| **Object Access** | Kernel Object | Success + Failure | 4656, 4663 |
| **Object Access** | Handle Manipulation | Success | 4658 |
| **Policy Change** | Audit Policy Change | Success + Failure | 4719, 4907, 4912 |
| **Policy Change** | Authentication Policy Change | Success | 4713, 4716, 4739 |
| **Privilege Use** | Sensitive Privilege Use | Success + Failure | 4672, 4673, 4674 |
| **System** | Security State Change | Success | 4608, 4616, 4622 |
| **System** | Security System Extension | Success | 4610, 4611, 4614, 4697 |

### Additional GPO Requirements

| Setting | Path | Purpose |
|---------|------|---------|
| Command Line in Process Creation | Admin Templates > System > Audit Process Creation | Populates CommandLine in 4688 |
| PowerShell Script Block Logging | Admin Templates > Windows Components > Windows PowerShell | Enables 4104 |
| PowerShell Module Logging | Admin Templates > Windows Components > Windows PowerShell | Enables 4103 |
| PowerShell Transcription | Admin Templates > Windows Components > Windows PowerShell | Full session recording |

### Sysmon Deployment

Sysmon requires separate installation. Recommended community configs:
- **SwiftOnSecurity sysmon-config** — Balanced detection/noise ratio
- **Olaf Hartong sysmon-modular** — Modular, ATT&CK-aligned rules
- **Microsoft recommended config** — Conservative baseline

Install: `sysmon64.exe -accepteula -i sysmonconfig.xml`
Update: `sysmon64.exe -c sysmonconfig.xml`

### Log Size Requirements

Default log sizes are too small. Recommended minimums:

| Log | Default Size | Recommended Minimum |
|-----|-------------|-------------------|
| Security | 20 MB | 1 GB+ |
| System | 20 MB | 256 MB |
| PowerShell/Operational | 15 MB | 256 MB |
| Sysmon/Operational | 64 MB | 512 MB+ |
| TaskScheduler/Operational | 1 MB | 64 MB |
| Windows Defender/Operational | 1 MB | 64 MB |
| WMI-Activity/Operational | 1 MB | 64 MB |
| TerminalServices-*/Operational | 1 MB | 64 MB each |

Configure via GPO: `Computer Configuration > Admin Templates > Windows Components > Event Log Service > [Log Name] > Maximum Log Size`

---

## Appendix A — Event ID Quick-Find Index

### By Attack Technique

| Technique | Events to Correlate |
|-----------|-------------------|
| **Brute Force** (T1110) | 4625 (failures), 4771 (Kerberos), 4776 (NTLM) |
| **Password Spray** (T1110.003) | 4625 sub-status 0xC000006A, 4771 code 0x18 — same password, many accounts |
| **Pass-the-Hash** (T1550.002) | 4624 Type 3 + NTLM auth, 4768 with RC4 |
| **Pass-the-Ticket** (T1550.003) | 4768/4769 anomalies, ticket reuse from wrong IP |
| **Kerberoasting** (T1558.003) | 4769 burst with RC4 encryption type 0x17 |
| **AS-REP Roasting** (T1558.004) | 4768 with RC4 for no-preauth accounts |
| **Golden Ticket** (T1558.001) | 4769 without 4768, impossible TGT lifetime |
| **Silver Ticket** (T1558.002) | 4624 Type 3 without DC-side 4769 |
| **DCSync** (T1003.006) | 4662 with replication GUIDs |
| **LSASS Dump** (T1003.001) | Sysmon 10 (lsass target), 4703 (debug priv) |
| **Credential Dumping** (T1003) | 4782, 8222, Sysmon 10, 4656 on SAM/SYSTEM/NTDS |
| **Remote Services** (T1021.002) | 5145 ADMIN$/IPC$, 4624 Type 3, 7045 |
| **RDP** (T1021.001) | 4624 Type 10, 1149, 21/22 TermSvc |
| **WMI** (T1047) | Sysmon 1 (WmiPrvSE child), 4624 Type 3 |
| **Scheduled Task** (T1053.005) | 4698, 106, 200/201 |
| **Service Execution** (T1569.002) | 7045, 4697, 7036 |
| **PowerShell** (T1059.001) | 4104, 4103, 400/800, Sysmon 1 |
| **Process Injection** (T1055) | Sysmon 8, Sysmon 10, Sysmon 25 |
| **Defense Evasion** (T1562) | 4719, 1102, 5001, 5007 |
| **Persistence — Registry** (T1547.001) | Sysmon 12/13 at Run/RunOnce keys |
| **Persistence — WMI** (T1546.003) | Sysmon 19/20/21, 5861 |
| **Persistence — Service** (T1543.003) | 7045, 4697, 7040 |
| **Timestomping** (T1070.006) | Sysmon 2 |
| **Log Clearing** (T1070.001) | 1102, 104 |
| **Account Creation** (T1136) | 4720 |
| **Account Manipulation** (T1098) | 4738, 4728/4732/4756, 5136 |
| **Domain Trust Discovery** (T1482) | 4688 (nltest /domain_trusts) |
| **BITS Jobs** (T1197) | BITS Event 60, Sysmon 1 (bitsadmin) |
| **DCShadow** (T1207) | 5137, 5141, 4742 |
| **Group Policy Mod** (T1484.001) | 5136 on GP objects |
| **Trust Modification** (T1484.002) | 4706, 4716, 4865/4866/4867 |

### By Event ID (Numeric Index)

| Range | Category |
|-------|----------|
| 1-29, 255 | Sysmon |
| 100-142 | Task Scheduler Operational |
| 104 | System — Log Cleared |
| 400, 403, 600, 800 | Windows PowerShell (Classic) |
| 1000-1151 | Windows Defender |
| 1100-1104 | Security — Audit Infrastructure |
| 1149 | TerminalServices-RemoteConnectionManager |
| 2003-2006 | Windows Firewall With Advanced Security |
| 3002-5012 | Windows Defender (advanced) |
| 4103-4106 | PowerShell Operational |
| 4608-4622 | Security — System Events |
| 4624-4634 | Security — Logon/Logoff |
| 4646-4655 | Security — IPsec/Logon |
| 4656-4670 | Security — Object Access |
| 4672-4674 | Security — Privilege Use |
| 4688-4697 | Security — Process & Service |
| 4698-4702 | Security — Scheduled Tasks |
| 4703-4718 | Security — Rights & Privileges |
| 4719-4767 | Security — Account & Group Management + Policy |
| 4768-4777 | Security — Kerberos & NTLM |
| 4778-4793 | Security — Session & Application Groups |
| 4800-4803 | Security — Workstation Lock |
| 4864-4898 | Security — Certificate Services & Trust |
| 4902-4913 | Security — Audit Policy |
| 4928-4937 | Security — AD Replication |
| 4944-4958 | Security — Firewall |
| 4960-4984 | Security — IPsec |
| 5024-5070 | Security — Firewall & Crypto |
| 5136-5145 | Security — Directory Services & Shares |
| 5152-5159 | Security — WFP Filtering |
| 5376-5377 | Security — Credential Manager |
| 5440-5484 | Security — WFP & IPsec Infrastructure |
| 5632-5633 | Security — Wireless/Wired Auth |
| 5857-5861 | WMI-Activity Operational |
| 6008 | System — Unexpected Shutdown |
| 6144-6145 | Security — Group Policy |
| 6272-6280 | Security — Network Policy Server |
| 7000-7045 | System — Service Control Manager |
| 8222 | Security — Shadow Copy |
| 24577-24595 | Security — BitLocker |
| 40961-53504 | PowerShell Operational (startup) |

---

## Appendix B — Sigma Rule Templates for Critical Detections

### LSASS Access Detection

```yaml
title: Suspicious LSASS Process Access
id: a]f4c9b2-3e71-4d8a-9b12-8c7a5f3e2d1b
status: experimental
description: Detects process access to LSASS indicating credential dumping
logsource:
  category: process_access
  product: windows
detection:
  selection:
    TargetImage|endswith: '\lsass.exe'
    GrantedAccess|contains:
      - '0x1010'
      - '0x1038'
      - '0x1fffff'
      - '0x1410'
      - '0x143a'
  filter_legitimate:
    SourceImage|endswith:
      - '\csrss.exe'
      - '\lsm.exe'
      - '\wmiprvse.exe'
      - '\svchost.exe'
      - '\wininit.exe'
  condition: selection and not filter_legitimate
falsepositives:
  - Antivirus real-time scanning of LSASS
  - Legitimate security tools with LSASS hooks
level: critical
tags:
  - attack.t1003.001
  - attack.credential_access
```

### DCSync Detection

```yaml
title: DCSync Attack via Directory Replication
id: b7e3f1a4-5c82-4d9e-af23-7d6b8e4f1c3a
status: experimental
description: Detects non-DC account requesting AD replication rights (DCSync)
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 4662
    Properties|contains:
      - '1131f6aa-9c07-11d1-f79f-00c04fc2dcd2'
      - '1131f6ad-9c07-11d1-f79f-00c04fc2dcd2'
      - '89e95b76-444d-4c62-991a-0facbeda640c'
  filter_dc:
    SubjectUserName|endswith: '$'
  condition: selection and not filter_dc
falsepositives:
  - Azure AD Connect service account
  - Authorized third-party replication tools
level: critical
tags:
  - attack.t1003.006
  - attack.credential_access
```

### Audit Log Cleared

```yaml
title: Security Audit Log Cleared
id: c9d2e4f7-6a13-4b5c-8d91-2e7f3a8b5c4d
status: stable
description: Detects clearing of Windows Security audit log indicating anti-forensics
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 1102
  condition: selection
falsepositives:
  - Authorized maintenance during change window with approved ticket
level: critical
tags:
  - attack.t1070.001
  - attack.defense_evasion
```

### Service Installation with Suspicious Path

```yaml
title: Service Installed with Suspicious Binary Path
id: d1e5f8a3-7b24-4c6d-9e02-3f8a4b9c6d5e
status: experimental
description: Detects service installation with binary in user-writable or temporary directories
logsource:
  product: windows
  service: system
detection:
  selection:
    EventID: 7045
  filter_suspicious_path:
    ImagePath|contains:
      - '\Temp\'
      - '\ProgramData\'
      - '\Users\Public\'
      - '\AppData\'
      - 'cmd.exe /c'
      - 'powershell'
      - 'mshta'
      - 'rundll32'
      - 'regsvr32'
  condition: selection and filter_suspicious_path
falsepositives:
  - Software installers extracting to temp before moving to final location
  - Legitimate tools using cmd.exe wrappers for service start
level: high
tags:
  - attack.t1543.003
  - attack.persistence
  - attack.t1569.002
  - attack.execution
```

---

*Reference compiled from: sbousseaden/EVTX-ATTACK-SAMPLES, JPCERTCC/ToolAnalysisResultSheet, mdecrevoisier/EVTX-to-MITRE-Attack, nasbench/EVTX-ETW-Resources, ultimatewindowssecurity.com, Microsoft Appendix L. Cross-referenced with MITRE ATT&CK v15.*
