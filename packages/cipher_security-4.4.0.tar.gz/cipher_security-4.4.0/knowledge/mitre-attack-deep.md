<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# MITRE ATT&CK / D3FEND Deep Reference

> CIPHER operational reference for TTP mapping during engagements.
> Source: MITRE ATT&CK v18 (October 2025) / D3FEND knowledge graph.
> Last compiled: 2026-03-14

---

## Table of Contents

1. [Enterprise Tactics Overview](#1-enterprise-tactics-overview)
2. [Tactic-by-Tactic Technique Inventory](#2-tactic-by-tactic-technique-inventory)
3. [Critical Technique Deep Dives](#3-critical-technique-deep-dives)
4. [D3FEND Defensive Taxonomy](#4-d3fend-defensive-taxonomy)
5. [ATT&CK-to-D3FEND Mapping](#5-attck-to-d3fend-mapping)
6. [Threat Group Profiles](#6-threat-group-profiles)
7. [Software & Tooling Reference](#7-software--tooling-reference)
8. [Quick-Reference Cheat Sheets](#8-quick-reference-cheat-sheets)

---

## 1. Enterprise Tactics Overview

The ATT&CK Enterprise matrix defines 14 tactics representing the adversary lifecycle from pre-compromise through impact. Each tactic answers a "why" — the adversary's objective at that phase.

| # | ID | Tactic | Objective |
|---|------|--------|-----------|
| 1 | TA0043 | Reconnaissance | Gather information to plan future operations |
| 2 | TA0042 | Resource Development | Establish resources to support operations |
| 3 | TA0001 | Initial Access | Get into the network |
| 4 | TA0002 | Execution | Run malicious code |
| 5 | TA0003 | Persistence | Maintain foothold |
| 6 | TA0004 | Privilege Escalation | Gain higher-level permissions |
| 7 | TA0005 | Defense Evasion | Avoid detection |
| 8 | TA0006 | Credential Access | Steal account names and passwords |
| 9 | TA0007 | Discovery | Figure out the environment |
| 10 | TA0008 | Lateral Movement | Move through the environment |
| 11 | TA0009 | Collection | Gather data of interest |
| 12 | TA0011 | Command and Control | Communicate with compromised systems |
| 13 | TA0010 | Exfiltration | Steal data |
| 14 | TA0040 | Impact | Manipulate, interrupt, or destroy systems and data |

### Kill Chain Mapping

```
Recon → Resource Dev → Initial Access → Execution → Persistence
                                                        ↓
Impact ← Exfiltration ← Collection ← Lateral Movement ← PrivEsc / DefEvasion / CredAccess / Discovery
                                                        ↑
                                              Command & Control
```

---

## 2. Tactic-by-Tactic Technique Inventory

### TA0043 — Reconnaissance (10 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1595 | Active Scanning | 3 |
| T1592 | Gather Victim Host Information | 4 |
| T1589 | Gather Victim Identity Information | 3 |
| T1590 | Gather Victim Network Information | 6 |
| T1591 | Gather Victim Org Information | 4 |
| T1598 | Phishing for Information | 4 |
| T1597 | Search Closed Sources | 2 |
| T1596 | Search Open Technical Databases | 5 |
| T1593 | Search Open Websites/Domains | 3 |
| T1681 | Search Threat Vendor Data | 0 |

### TA0042 — Resource Development (8 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1650 | Acquire Access | 0 |
| T1583 | Acquire Infrastructure | 8 |
| T1586 | Compromise Accounts | 3 |
| T1584 | Compromise Infrastructure | 8 |
| T1587 | Develop Capabilities | 4 |
| T1585 | Establish Accounts | 3 |
| T1588 | Obtain Capabilities | 7 |
| T1608 | Stage Capabilities | 6 |

### TA0001 — Initial Access (11 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1659 | Content Injection | 0 |
| T1189 | Drive-by Compromise | 0 |
| T1190 | Exploit Public-Facing Application | 0 |
| T1133 | External Remote Services | 0 |
| T1200 | Hardware Additions | 0 |
| T1566 | Phishing | 4 |
| T1091 | Replication Through Removable Media | 0 |
| T1195 | Supply Chain Compromise | 3 |
| T1199 | Trusted Relationship | 0 |
| T1078 | Valid Accounts | 4 |
| T1669 | Wi-Fi Networks | 0 |

### TA0002 — Execution (17 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1651 | Cloud Administration Command | 0 |
| T1059 | Command and Scripting Interpreter | 13 |
| T1609 | Container Administration Command | 0 |
| T1610 | Deploy Container | 0 |
| T1675 | ESXi Administration Command | 0 |
| T1203 | Exploitation for Client Execution | 0 |
| T1674 | Input Injection | 0 |
| T1559 | Inter-Process Communication | 3 |
| T1106 | Native API | 0 |
| T1677 | Poisoned Pipeline Execution | 0 |
| T1053 | Scheduled Task/Job | 5 |
| T1648 | Serverless Execution | 0 |
| T1129 | Shared Modules | 0 |
| T1072 | Software Deployment Tools | 0 |
| T1569 | System Services | 3 |
| T1204 | User Execution | 5 |
| T1047 | Windows Management Instrumentation | 0 |

### TA0003 — Persistence (23 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1098 | Account Manipulation | 7 |
| T1197 | BITS Jobs | 0 |
| T1547 | Boot or Logon Autostart Execution | 15 |
| T1037 | Boot or Logon Initialization Scripts | 5 |
| T1671 | Cloud Application Integration | 0 |
| T1554 | Compromise Host Software Binary | 0 |
| T1136 | Create Account | 3 |
| T1543 | Create or Modify System Process | 5 |
| T1546 | Event Triggered Execution | 18 |
| T1668 | Exclusive Control | 0 |
| T1133 | External Remote Services | 0 |
| T1574 | Hijack Execution Flow | 14 |
| T1525 | Implant Internal Image | 0 |
| T1556 | Modify Authentication Process | 9 |
| T1112 | Modify Registry | 0 |
| T1137 | Office Application Startup | 6 |
| T1653 | Power Settings | 0 |
| T1542 | Pre-OS Boot | 5 |
| T1053 | Scheduled Task/Job | 5 |
| T1505 | Server Software Component | 6 |
| T1176 | Software Extensions | 2 |
| T1205 | Traffic Signaling | 2 |
| T1078 | Valid Accounts | 4 |

### TA0004 — Privilege Escalation (14 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1548 | Abuse Elevation Control Mechanism | 6 |
| T1134 | Access Token Manipulation | 4 |
| T1098 | Account Manipulation | 7 |
| T1547 | Boot or Logon Autostart Execution | 13 |
| T1037 | Boot or Logon Initialization Scripts | 5 |
| T1543 | Create or Modify System Process | 5 |
| T1484 | Domain or Tenant Policy Modification | 2 |
| T1611 | Escape to Host | 0 |
| T1546 | Event Triggered Execution | 18 |
| T1068 | Exploitation for Privilege Escalation | 0 |
| T1574 | Hijack Execution Flow | 14 |
| T1055 | Process Injection | 12 |
| T1053 | Scheduled Task/Job | 5 |
| T1078 | Valid Accounts | 4 |

### TA0005 — Defense Evasion (41+ techniques)

**High-frequency techniques (most sub-techniques, most observed in the wild):**

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1027 | Obfuscated Files or Information | 17 |
| T1564 | Hide Artifacts | 14 |
| T1574 | Hijack Execution Flow | 14 |
| T1218 | System Binary Proxy Execution | 15 |
| T1562 | Impair Defenses | 13 |
| T1036 | Masquerading | 12 |
| T1070 | Indicator Removal | 10 |
| T1556 | Modify Authentication Process | 9 |
| T1548 | Abuse Elevation Control Mechanism | 6 |
| T1553 | Subvert Trust Controls | 6 |
| T1055 | Process Injection | 12 |
| T1134 | Access Token Manipulation | 5 |
| T1578 | Modify Cloud Compute Infrastructure | 5 |
| T1542 | Pre-OS Boot | 5 |
| T1140 | Deobfuscate/Decode Files or Information | 0 |
| T1202 | Indirect Command Execution | 0 |
| T1014 | Rootkit | 0 |
| T1620 | Reflective Code Loading | 0 |
| T1221 | Template Injection | 0 |

### TA0006 — Credential Access (17 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1557 | Adversary-in-the-Middle | 4 |
| T1110 | Brute Force | 4 |
| T1555 | Credentials from Password Stores | 6 |
| T1212 | Exploitation for Credential Access | 0 |
| T1187 | Forced Authentication | 0 |
| T1606 | Forge Web Credentials | 2 |
| T1056 | Input Capture | 4 |
| T1556 | Modify Authentication Process | 9 |
| T1111 | Multi-Factor Authentication Interception | 0 |
| T1621 | Multi-Factor Authentication Request Generation | 0 |
| T1040 | Network Sniffing | 0 |
| T1003 | OS Credential Dumping | 8 |
| T1528 | Steal Application Access Token | 0 |
| T1649 | Steal or Forge Authentication Certificates | 0 |
| T1558 | Steal or Forge Kerberos Tickets | 5 |
| T1539 | Steal Web Session Cookie | 0 |
| T1552 | Unsecured Credentials | 8 |

### TA0007 — Discovery (34 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1087 | Account Discovery | 4 |
| T1010 | Application Window Discovery | 0 |
| T1217 | Browser Information Discovery | 0 |
| T1580 | Cloud Infrastructure Discovery | 0 |
| T1538 | Cloud Service Dashboard | 0 |
| T1526 | Cloud Service Discovery | 0 |
| T1619 | Cloud Storage Object Discovery | 0 |
| T1613 | Container and Resource Discovery | 0 |
| T1622 | Debugger Evasion | 0 |
| T1652 | Device Driver Discovery | 0 |
| T1482 | Domain Trust Discovery | 0 |
| T1083 | File and Directory Discovery | 0 |
| T1615 | Group Policy Discovery | 0 |
| T1680 | Local Storage Discovery | 0 |
| T1654 | Log Enumeration | 0 |
| T1046 | Network Service Discovery | 0 |
| T1135 | Network Share Discovery | 0 |
| T1040 | Network Sniffing | 0 |
| T1201 | Password Policy Discovery | 0 |
| T1120 | Peripheral Device Discovery | 0 |
| T1069 | Permission Groups Discovery | 3 |
| T1057 | Process Discovery | 0 |
| T1012 | Query Registry | 0 |
| T1018 | Remote System Discovery | 0 |
| T1518 | Software Discovery | 2 |
| T1082 | System Information Discovery | 0 |
| T1614 | System Location Discovery | 1 |
| T1016 | System Network Configuration Discovery | 2 |
| T1049 | System Network Connections Discovery | 0 |
| T1033 | System Owner/User Discovery | 0 |
| T1007 | System Service Discovery | 0 |
| T1124 | System Time Discovery | 0 |
| T1673 | Virtual Machine Discovery | 0 |
| T1497 | Virtualization/Sandbox Evasion | 3 |

### TA0008 — Lateral Movement (9 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1210 | Exploitation of Remote Services | 0 |
| T1534 | Internal Spearphishing | 0 |
| T1570 | Lateral Tool Transfer | 0 |
| T1563 | Remote Service Session Hijacking | 2 |
| T1021 | Remote Services | 8 |
| T1091 | Replication Through Removable Media | 0 |
| T1072 | Software Deployment Tools | 0 |
| T1080 | Taint Shared Content | 0 |
| T1550 | Use Alternate Authentication Material | 4 |

### TA0009 — Collection (17 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1557 | Adversary-in-the-Middle | 4 |
| T1560 | Archive Collected Data | 3 |
| T1123 | Audio Capture | 0 |
| T1119 | Automated Collection | 0 |
| T1185 | Browser Session Hijacking | 0 |
| T1115 | Clipboard Data | 0 |
| T1530 | Data from Cloud Storage | 0 |
| T1602 | Data from Configuration Repository | 2 |
| T1213 | Data from Information Repositories | 6 |
| T1005 | Data from Local System | 0 |
| T1039 | Data from Network Shared Drive | 0 |
| T1025 | Data from Removable Media | 0 |
| T1074 | Data Staged | 2 |
| T1114 | Email Collection | 3 |
| T1056 | Input Capture | 4 |
| T1113 | Screen Capture | 0 |
| T1125 | Video Capture | 0 |

### TA0011 — Command and Control (18 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1071 | Application Layer Protocol | 5 |
| T1092 | Communication Through Removable Media | 0 |
| T1659 | Content Injection | 0 |
| T1132 | Data Encoding | 2 |
| T1001 | Data Obfuscation | 3 |
| T1568 | Dynamic Resolution | 3 |
| T1573 | Encrypted Channel | 2 |
| T1008 | Fallback Channels | 0 |
| T1665 | Hide Infrastructure | 0 |
| T1105 | Ingress Tool Transfer | 0 |
| T1104 | Multi-Stage Channels | 0 |
| T1095 | Non-Application Layer Protocol | 0 |
| T1571 | Non-Standard Port | 0 |
| T1572 | Protocol Tunneling | 0 |
| T1090 | Proxy | 4 |
| T1219 | Remote Access Tools | 3 |
| T1205 | Traffic Signaling | 2 |
| T1102 | Web Service | 3 |

### TA0010 — Exfiltration (9 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1020 | Automated Exfiltration | 1 |
| T1030 | Data Transfer Size Limits | 0 |
| T1048 | Exfiltration Over Alternative Protocol | 3 |
| T1041 | Exfiltration Over C2 Channel | 0 |
| T1011 | Exfiltration Over Other Network Medium | 1 |
| T1052 | Exfiltration Over Physical Medium | 1 |
| T1567 | Exfiltration Over Web Service | 4 |
| T1029 | Scheduled Transfer | 0 |
| T1537 | Transfer Data to Cloud Account | 0 |

### TA0040 — Impact (15 techniques)

| ID | Technique | Sub-techniques |
|----|-----------|:-:|
| T1531 | Account Access Removal | 0 |
| T1485 | Data Destruction | 2 |
| T1486 | Data Encrypted for Impact | 0 |
| T1565 | Data Manipulation | 3 |
| T1491 | Defacement | 2 |
| T1561 | Disk Wipe | 2 |
| T1667 | Email Bombing | 0 |
| T1499 | Endpoint Denial of Service | 4 |
| T1657 | Financial Theft | 0 |
| T1495 | Firmware Corruption | 0 |
| T1490 | Inhibit System Recovery | 0 |
| T1498 | Network Denial of Service | 2 |
| T1496 | Resource Hijacking | 4 |
| T1489 | Service Stop | 0 |
| T1529 | System Shutdown/Reboot | 0 |

---

## 3. Critical Technique Deep Dives

### T1059 — Command and Scripting Interpreter

**Tactics:** Execution
**Platforms:** ESXi, IaaS, Identity Provider, Linux, Network Devices, Office Suite, Windows, macOS

Adversaries abuse command and script interpreters to execute commands, scripts, or binaries. Standard across most platforms — every OS ships with at least one. This is the single most commonly observed execution technique.

#### Sub-Techniques (13)

| ID | Name | Platform Focus |
|----|------|---------------|
| T1059.001 | PowerShell | Windows |
| T1059.002 | AppleScript | macOS |
| T1059.003 | Windows Command Shell | Windows |
| T1059.004 | Unix Shell | Linux, macOS |
| T1059.005 | Visual Basic | Windows, Office |
| T1059.006 | Python | Cross-platform |
| T1059.007 | JavaScript | Cross-platform |
| T1059.008 | Network Device CLI | Network Devices |
| T1059.009 | Cloud API | IaaS, SaaS |
| T1059.010 | AutoHotkey & AutoIT | Windows |
| T1059.011 | Lua | Cross-platform |
| T1059.012 | Hypervisor CLI | ESXi |
| T1059.013 | Container CLI/API | Containers |

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1049 | Antivirus/Antimalware | Auto-quarantine suspicious files |
| M1047 | Audit | Inventory unauthorized interpreter installations |
| M1040 | Behavior Prevention | Windows ASR rules block VB/JS malicious downloads |
| M1045 | Code Signing | Restrict to signed scripts |
| M1042 | Disable or Remove Feature | Remove unnecessary shells/interpreters |
| M1038 | Execution Prevention | Application control; PowerShell Constrained Language mode |
| M1033 | Limit Software Installation | Prevent unauthorized interpreter install |
| M1026 | Privileged Account Management | Admin-only PowerShell; use JEA sandboxing |
| M1021 | Restrict Web-Based Content | Script-blocking extensions |

#### Detection Analytics

- **AN1428:** Scripting execution outside normal admin windows, encoded arguments, secondary execution
- **AN1429:** Shell use by unexpected users/processes, chaining netcat/curl/ssh
- **AN1430:** Command-line interpreter via Terminal/Automator/osascript with unusual parent lineage
- **AN1431:** `esxcli system` from unexpected SSH/terminal access
- **AN1432:** CLI access via uncommon accounts or unknown IPs

---

### T1078 — Valid Accounts

**Tactics:** Initial Access, Persistence, Privilege Escalation, Defense Evasion
**Platforms:** Containers, ESXi, IaaS, Identity Provider, Linux, Network Devices, Office Suite, SaaS, Windows, macOS

Adversaries obtain and exploit existing credentials. Bypasses access controls, enables persistent remote access (VPN, OWA). Especially dangerous because legitimate credentials make detection hard when adversaries avoid malware. Inactive accounts of former employees are prime targets.

#### Sub-Techniques (4)

| ID | Name | Key Risk |
|----|------|----------|
| T1078.001 | Default Accounts | Factory creds on devices/appliances |
| T1078.002 | Domain Accounts | AD-wide lateral movement |
| T1078.003 | Local Accounts | Host-level access |
| T1078.004 | Cloud Accounts | SaaS/IaaS/identity provider access |

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1032 | Multi-factor Authentication | MFA on all account types |
| M1026 | Privileged Account Management | Audit domain/local accounts and permissions |
| M1015 | Active Directory Configuration | Disable legacy auth protocols |
| M1027 | Password Policies | Change defaults immediately; minimize reuse |
| M1036 | Account Use Policies | Conditional access; block non-compliant devices |
| M1018 | User Account Management | Audit regularly; deactivate unused accounts |
| M1017 | User Training | Recognize MFA push fraud |

#### Detection Analytics

- **AN1543:** Anomalous Windows logon patterns, geographic inconsistencies
- **AN1544:** SSH logins, sudo/su abuse, service account anomalies (Linux)
- **AN1545:** Interactive/remote logons by service accounts at unusual times
- **AN1546:** IdP logs — geographic anomalies, impossible travel
- **AN1547:** Container service account access from unexpected nodes/IPs

---

### T1021 — Remote Services

**Tactics:** Lateral Movement
**Platforms:** ESXi, IaaS, Linux, Windows, macOS

Valid credentials + remote services = lateral movement. Legitimate admin tools (ARD, WinRM, SSH) repurposed for unauthorized access.

#### Sub-Techniques (8)

| ID | Name | Protocol/Port |
|----|------|--------------|
| T1021.001 | Remote Desktop Protocol | RDP/3389 |
| T1021.002 | SMB/Windows Admin Shares | SMB/445 |
| T1021.003 | Distributed Component Object Model | DCOM |
| T1021.004 | SSH | SSH/22 |
| T1021.005 | VNC | VNC/5900+ |
| T1021.006 | Windows Remote Management | WinRM/5985-5986 |
| T1021.007 | Cloud Services | Cloud API |
| T1021.008 | Direct Cloud VM Connections | Cloud serial/SSH |

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1047 | Audit | Scan for vulns, weak perms, insecure configs |
| M1042 | Disable or Remove Feature | Deactivate unnecessary remote services; ESXi lockdown mode |
| M1035 | Limit Network Access | Restrict via gateways |
| M1032 | Multi-factor Authentication | MFA on remote logons |
| M1027 | Password Policies | Unique complex passwords; no reuse |
| M1018 | User Account Management | Restrict remote service access |

---

### T1055 — Process Injection

**Tactics:** Defense Evasion, Privilege Escalation
**Platforms:** Linux, Windows, macOS

Execute arbitrary code within separate live processes. Masks execution under legitimate process context, accesses process memory/network, bypasses endpoint detection.

#### Sub-Techniques (12)

| ID | Name | OS |
|----|------|----|
| T1055.001 | Dynamic-link Library Injection | Windows |
| T1055.002 | Portable Executable Injection | Windows |
| T1055.003 | Thread Execution Hijacking | Windows |
| T1055.004 | Asynchronous Procedure Call | Windows |
| T1055.005 | Thread Local Storage | Windows |
| T1055.008 | Ptrace System Calls | Linux |
| T1055.009 | Proc Memory | Linux |
| T1055.011 | Extra Window Memory Injection | Windows |
| T1055.012 | Process Hollowing | Windows |
| T1055.013 | Process Doppelganging | Windows |
| T1055.014 | VDSO Hijacking | Linux |
| T1055.015 | ListPlanting | Windows |

#### Key Detection Indicators

- **Windows:** Monitor `VirtualAllocEx`, `WriteProcessMemory`, `CreateRemoteThread` sequences
- **Linux:** Track `ptrace`, `mmap` targeting running processes; suspicious `/proc/[pid]/mem` access
- **macOS:** Detect `task_for_pid`, `mach_vm_write`, `DYLD_INSERT_LIBRARIES`
- **Common targets:** `svchost.exe`, `explorer.exe`, `rundll32.exe`, browser processes

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1040 | Behavior Prevention | Block injection sequences; Windows ASR rules |
| M1026 | Privileged Account Management | Yama ptrace restrictions; SELinux/AppArmor |

---

### T1053 — Scheduled Task/Job

**Tactics:** Execution, Persistence, Privilege Escalation
**Platforms:** Containers, ESXi, Linux, Windows, macOS

Task scheduling utilities for execution on schedule or at startup. Enables persistence, privilege escalation via account context, masking under trusted processes.

#### Sub-Techniques (5)

| ID | Name | Platform |
|----|------|----------|
| T1053.002 | At | Windows, Linux |
| T1053.003 | Cron | Linux, macOS |
| T1053.005 | Scheduled Task | Windows |
| T1053.006 | Systemd Timers | Linux |
| T1053.007 | Container Orchestration Job | Containers |

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1047 | Audit | PowerUp to find permission weaknesses |
| M1028 | OS Configuration | Tasks under authenticated accounts; disable server operator scheduling via GPO |
| M1026 | Privileged Account Management | Admin-only scheduling priority |
| M1022 | File/Directory Permissions | Limit directory access for task creation |
| M1018 | User Account Management | Restrict remote task creation |

---

### T1566 — Phishing

**Tactics:** Initial Access
**Platforms:** Identity Provider, Linux, Office Suite, SaaS, Windows, macOS

Electronically delivered social engineering. Targeted spearphishing and mass campaigns. Attachments, links, identity spoofing, thread hijacking.

#### Sub-Techniques (4)

| ID | Name | Vector |
|----|------|--------|
| T1566.001 | Spearphishing Attachment | Malicious file attached to email |
| T1566.002 | Spearphishing Link | URL to attacker-controlled site |
| T1566.003 | Spearphishing via Service | Third-party services (LinkedIn, Slack) |
| T1566.004 | Spearphishing Voice | Vishing / callback phishing |

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1049 | Antivirus/Antimalware | Quarantine suspicious files |
| M1031 | Network Intrusion Prevention | Scan/remove malicious attachments |
| M1021 | Restrict Web-Based Content | Block .scr, .exe, .pif, .cpl |
| M1054 | Software Configuration | Enable SPF, DKIM, DMARC |
| M1017 | User Training | Identify social engineering |

#### Detection Analytics

- **AN0188:** Inbound email with suspicious attachments/URLs followed by process execution
- **AN0189:** Email client activity resulting in file creation or outbound connections
- **AN0191:** Office macro activity spawning suspicious child processes
- **AN0192:** Anomalous IdP login attempts post-phishing delivery

---

### T1190 — Exploit Public-Facing Application

**Tactics:** Initial Access
**Platforms:** Containers, ESXi, IaaS, Linux, Network Devices, Windows, macOS

Exploit weaknesses in internet-facing systems — software bugs, misconfigurations, temporary glitches. Targets: web servers, databases, SMB, SSH, SNMP, Smart Install, cloud/container APIs.

#### Common Vulnerability Classes

- SQL injection, RCE, authentication bypass, deserialization flaws
- OWASP Top 10, CWE Top 25
- Log4Shell (CVE-2021-44228), ProxyLogon/ProxyShell, Ivanti VPN zero-days

#### 2024-2025 Trend CVEs

| CVE | Target |
|-----|--------|
| CVE-2024-3400 | Palo Alto GlobalProtect RCE |
| CVE-2024-21887 | Ivanti Connect Secure VPN |
| CVE-2024-21893 | Ivanti Connect Secure SSRF |
| CVE-2025-49704/49706 | SharePoint ToolShell |
| CVE-2025-9377 | TP-Link router exploitation |

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1051 | Update Software | Patch management for externally-exposed apps |
| M1016 | Vulnerability Scanning | Regular external scanning with rapid patching |
| M1030 | Network Segmentation | DMZ architecture for public-facing servers |
| M1050 | Exploit Protection | WAF deployment |
| M1048 | Application Sandboxing | Limit compromised process access |
| M1026 | Privileged Account Management | Least-privilege service accounts |

#### Detection Correlation Pattern

1. Suspicious inbound requests to public endpoints
2. Error spikes (4xx/5xx) or WAF blocks
3. Post-exploitation: shell spawning, non-standard module loading, webshell deployment
4. Egress to attacker infrastructure or metadata services

---

### T1003 — OS Credential Dumping

**Tactics:** Credential Access
**Platforms:** Linux, Windows, macOS

Extract login credentials and credential material from OS caches, memory structures, or storage. Credentials enable lateral movement and privilege escalation.

#### Sub-Techniques (8)

| ID | Name | Target |
|----|------|--------|
| T1003.001 | LSASS Memory | Windows LSASS process memory |
| T1003.002 | Security Account Manager | Windows SAM registry hive |
| T1003.003 | NTDS | Active Directory database (ntds.dit) |
| T1003.004 | LSA Secrets | Windows LSA secrets storage |
| T1003.005 | Cached Domain Credentials | DCC2 hashes |
| T1003.006 | DCSync | Replication request to DC |
| T1003.007 | Proc Filesystem | Linux /proc/[pid]/mem |
| T1003.008 | /etc/passwd and /etc/shadow | Linux credential files |

#### Key Detection Indicators

- Processes accessing LSASS memory outside trusted security tools
- Processes opening `/proc/*/mem` or `/proc/*/maps` targeting sshd/login
- Unsigned processes launching credential scraping tools
- Abnormal `lsass.exe` memory access patterns
- DCSync: unexpected directory replication requests from non-DC hosts

#### Mitigations

| ID | Mitigation | Action |
|----|-----------|--------|
| M1015 | Active Directory Configuration | Control "Replicating Directory Changes All"; Protected Users group |
| M1040 | Behavior Prevention | Windows ASR rules to secure LSASS |
| M1043 | Credential Access Protection | Windows Credential Guard |
| M1028 | Operating System Configuration | Disable NTLM and WDigest |
| M1027 | Password Policies | Complex unique local admin passwords |
| M1026 | Privileged Account Management | No domain accounts in local admin groups |
| M1025 | Privileged Process Integrity | Protected Process Light for LSA |

---

## 4. D3FEND Defensive Taxonomy

D3FEND organizes cybersecurity countermeasures into seven primary defensive tactics:

### Model — Understand Your Environment

| Category | Techniques |
|----------|-----------|
| Asset Inventory | Software, hardware, configuration, data, network node inventory |
| Network Mapping | Logical/physical link identification, traffic policy mapping |
| System Mapping | Dependencies, data exchange, vulnerability mapping |
| Operational Activity Mapping | Access modeling, organizational structure |

### Harden — Strengthen Systems Against Attack

| Category | Techniques |
|----------|-----------|
| Authentication | Biometric, certificate-based, multi-factor, token-based |
| Application Hardening | Code segment prevention, pointer validation, stack canaries |
| Platform Hardening | Bootloader authentication, disk encryption, TPM |
| Credential Hardening | Rotation, pinning, strong password policies |
| Message Hardening | Encryption, authentication |
| Source Code Hardening | Input validation, null checking |

### Detect — Monitor for Threats

| Category | Techniques |
|----------|-----------|
| File Analysis | Dynamic analysis, emulated file analysis, content rules, hashing |
| Network Traffic Analysis | DNS, RPC, protocol anomaly detection |
| Process Analysis | Lineage analysis, spawn patterns, self-modification detection |
| User Behavior Analysis | Authentication patterns, data transfer anomalies |
| Platform Monitoring | Firmware verification, integrity monitoring, log analysis |

### Isolate — Restrict Access and Separate Components

| Category | Techniques |
|----------|-----------|
| Access Mediation | Network, file, web session access control |
| Content Filtering | Format verification, decompression checking |
| Execution Isolation | Allowlisting, denylisting, kernel-based isolation |
| Network Isolation | DNS filtering, encrypted tunnels, broadcast domain isolation |

### Deceive — Deploy Honeypots and Decoys

| Category | Techniques |
|----------|-----------|
| Decoy Environment | Connected, integrated, standalone honeynets |
| Decoy Objects | Files, credentials, personas, network resources |

### Evict — Remove Threats

| Category | Techniques |
|----------|-----------|
| Credential Eviction | Revocation, cache invalidation, account locking |
| Object Eviction | File/email removal, registry deletion |
| Process Eviction | Termination, suspension, host shutdown |

### Restore — Recover Systems

| Category | Techniques |
|----------|-----------|
| Restore Access | Credential reissuance, account unlocking |
| Restore Objects | Files, databases, configurations, software |

---

## 5. ATT&CK-to-D3FEND Mapping

### T1059 Command and Scripting Interpreter

| D3FEND Category | D3FEND ID | Defensive Technique |
|-----------------|-----------|-------------------|
| Detect | D3-PSA | Process Spawn Analysis |
| Detect | D3-PLA | Process Lineage Analysis |
| Detect | D3-SEA | Script Execution Analysis |
| Detect | D3-SCA | System Call Analysis |
| Detect | D3-IPCTA | IPC Traffic Analysis |
| Isolate | D3-EAL | Executable Allowlisting |
| Isolate | D3-EDL | Executable Denylisting |
| Isolate | D3-SCF | System Call Filtering |
| Harden | D3-ACH | Application Configuration Hardening |
| Harden | D3-SCH | Source Code Hardening |

### T1003 OS Credential Dumping

| D3FEND Category | D3FEND ID | Defensive Technique |
|-----------------|-----------|-------------------|
| Harden | D3-CRO | Credential Rotation |
| Harden | D3-PR | Password Rotation |
| Harden | D3-OTP | One-time Password |
| Harden | D3-SPP | Strong Password Policy |
| Harden | D3-DENCR | Disk Encryption |
| Harden | D3-FE | File Encryption |
| Detect | D3-ANET | Authentication Event Thresholding |
| Detect | D3-LAM | Local Account Monitoring |
| Detect | D3-DAM | Domain Account Monitoring |
| Detect | D3-PSA | Process Spawn Analysis |
| Detect | D3-PLA | Process Lineage Analysis |
| Detect | D3-SCA | System Call Analysis |
| Evict | D3-AL | Account Locking |
| Evict | D3-ACI | Authentication Cache Invalidation |
| Evict | D3-CR | Credential Revocation |

### T1055 Process Injection

| D3FEND Category | D3FEND ID | Defensive Technique |
|-----------------|-----------|-------------------|
| Harden | D3-AH | Application Hardening |
| Harden | D3-PSEP | Process Segment Execution Prevention |
| Harden | D3-PAN | Pointer Authentication |
| Harden | D3-SFCV | Stack Frame Canary Validation |
| Detect | D3-PSA | Process Spawn Analysis |
| Detect | D3-PLA | Process Lineage Analysis |
| Detect | D3-SCA | System Call Analysis |
| Detect | D3-PCSV | Process Code Segment Verification |
| Detect | D3-IPCTA | IPC Traffic Analysis |
| Isolate | D3-HBPI | Hardware-based Process Isolation |
| Isolate | D3-KBPI | Kernel-based Process Isolation |
| Isolate | D3-EAL | Executable Allowlisting |

### T1566 Phishing

| D3FEND Category | D3FEND ID | Defensive Technique |
|-----------------|-----------|-------------------|
| Detect | D3-MA | Message Analysis |
| Detect | D3-SMRA | Sender MTA Reputation Analysis |
| Detect | D3-SRA | Sender Reputation Analysis |
| Detect | D3-HD | Homoglyph Detection |
| Detect | D3-UA | URL Analysis |
| Detect | D3-DNRA | Domain Name Reputation Analysis |
| Detect | D3-IPRA | IP Reputation Analysis |
| Detect | D3-URA | URL Reputation Analysis |
| Detect | D3-FA | File Analysis |
| Detect | D3-DA | Dynamic Analysis |
| Detect | D3-NTA | Network Traffic Analysis |
| Isolate | D3-EF | Email Filtering |
| Isolate | D3-NTF | Network Traffic Filtering |
| Isolate | D3-ITF | Inbound Traffic Filtering |
| Harden | D3-MAN | Message Authentication |
| Harden | D3-MENCR | Message Encryption |
| Harden | D3-TAAN | Transfer Agent Authentication |

### Cross-Technique D3FEND Coverage Matrix

The following D3FEND techniques provide broad coverage across multiple ATT&CK techniques:

| D3FEND Technique | Covers ATT&CK Techniques |
|-----------------|--------------------------|
| D3-PSA (Process Spawn Analysis) | T1059, T1055, T1003, T1053, T1021 |
| D3-PLA (Process Lineage Analysis) | T1059, T1055, T1003, T1053 |
| D3-SCA (System Call Analysis) | T1059, T1055, T1003 |
| D3-EAL (Executable Allowlisting) | T1059, T1055, T1053 |
| D3-NTA (Network Traffic Analysis) | T1566, T1021, T1190, T1071 |
| D3-UBA (User Behavior Analysis) | T1078, T1003, T1110 |

---

## 6. Threat Group Profiles

### APT28 (G0007) — Russia/GRU 85th GTsSS

**Aliases:** Fancy Bear, STRONTIUM, Sofacy
**Active Since:** 2004
**Attribution:** Russia's General Staff Main Intelligence Directorate (GRU)
**Targets:** Government, military, political organizations; US political infrastructure

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566 (Phishing), T1190 (Exploit Public-Facing App) |
| Credential Access | T1110 (Brute Force/password spraying), T1598.003 (Spearphishing for creds), T1056.001 (Keylogging) |
| C2 | T1071.001 (Web Protocols), T1071.003 (Mail Protocols — IMAP/POP3/SMTP), T1090 (Proxy — Tor/VPN) |
| Defense Evasion | T1027.013 (Encrypted files), T1070.001 (Clear Event Logs), T1036.005 (Match Legitimate Names) |
| Lateral Movement | T1021.001 (RDP), T1021.002 (SMB), T1550.002 (Pass the Hash) |
| Collection | T1005 (Local System), T1039 (Network Shares), T1114.002 (Remote Email) |

**Primary Tools:** CHOPSTICK, Zebrocy, JHUHUGIT, Cannon, Mimikatz, Responder, reGeorg

---

### APT29 (G0016) — Russia/SVR

**Aliases:** Cozy Bear, NOBELIUM, Dark Halo, Midnight Blizzard
**Active Since:** 2008
**Attribution:** Russia's Foreign Intelligence Service (SVR)
**Targets:** Government, diplomatic, think tanks; SolarWinds supply chain

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1190 (Exploit Public-Facing), T1566 (Phishing), T1195.002 (Supply Chain — SolarWinds) |
| Persistence | T1547.001 (Registry Run Keys), T1546.003 (WMI Event Subscriptions), T1053.005 (Scheduled Tasks) |
| Credential Access | T1110 (Brute Force), T1003.006 (DCSync), T1555.003 (Browser creds) |
| Lateral Movement | T1021 (RDP, SMB, WinRM, SSH), T1550 (Pass the Hash/Ticket/Token) |
| Defense Evasion | T1070 (Indicator Removal), T1562 (Impair Defenses), T1027 (Obfuscation — steganography, HTML smuggling) |
| Exfiltration | T1114.002 (Remote Email), T1048.002 (Asymmetric Encrypted Protocol) |

**Primary Tools:** SUNBURST, SUNSPOT, TEARDROP, FatDuke, MiniDuke, Cobalt Strike, Mimikatz, AdFind, BloodHound, AADInternals

---

### Lazarus Group (G0032) — North Korea

**Aliases:** Hidden Cobra, ZINC, Diamond Sleet
**Active Since:** 2009
**Attribution:** North Korea (RGB)
**Targets:** Financial institutions, cryptocurrency, defense, entertainment (Sony 2014)

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566 (Phishing), T1189 (Drive-by Compromise) |
| Execution | T1059 (PowerShell, cmd, VB macros), T1218 (rundll32, regsvr32, mshta), T1047 (WMI) |
| Persistence | T1547 (Registry Run keys, startup), T1543 (Windows services), T1053 (Scheduled tasks) |
| Defense Evasion | T1027 (AES/XOR encryption, packing), T1036 (Masquerading), T1070 (Indicator Removal), T1497 (Sandbox Evasion) |
| Exfiltration | T1041 (Over C2), T1567 (Web Service — Dropbox, OneDrive) |

**Primary Tools:** DRATzarus, AppleJeus, BLINDINGCAN, Dtrack, Responder, ChromePass

---

### APT41 (G0096) — China (Dual-purpose)

**Aliases:** Wicked Panda, BARIUM, Brass Typhoon
**Active Since:** 2012
**Attribution:** Chinese state-sponsored + financially motivated
**Targets:** Healthcare, telecom, technology across 14+ countries

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1190 (CVE-2020-10189, CVE-2019-19781, CVE-2021-26855), T1566.001 (Spearphishing) |
| Execution | T1059.001 (PowerShell), T1059.003 (cmd), T1047 (WMI via WMIEXEC) |
| Persistence | T1543.003 (Windows Service), T1547.001 (Registry Run), T1505.003 (Web Shell) |
| Credential Access | T1003.001 (LSASS — Mimikatz/Procdump), T1003.002 (SAM), T1555.003 (Browser creds) |
| Lateral Movement | T1021.001 (RDP), T1021.002 (SMB) |

**Primary Tools:** Cobalt Strike, PlugX, ShadowPad, Mimikatz, DUSTPAN/DUSTTRAP, KEYPLUG, DEADEYE, certutil, BITSAdmin, Impacket

---

### Sandworm Team (G0034) — Russia/GRU Unit 74455

**Aliases:** APT44, Voodoo Bear, IRIDIUM
**Active Since:** 2009
**Attribution:** GRU Main Center for Special Technologies (Unit 74455)
**Targets:** Critical infrastructure (energy, ICS), Ukraine, Olympic Games

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566 (Phishing), T1190 (Exploit Public-Facing), T1195.002 (Supply Chain) |
| Execution | T1059.001 (PowerShell), T1059.005 (VB), T1218.011 (Rundll32) |
| Persistence | T1547.001 (Registry Run), T1543.003 (Windows Service), T1133 (External Remote — SSH backdoors) |
| Defense Evasion | T1036 (Masquerading), T1027 (Obfuscation), T1562.002 (Disable Event Logging) |
| Impact | T1485 (Data Destruction), T1486 (Ransomware), T1561.002 (Disk Structure Wipe) |

**Primary Tools:** BlackEnergy, Industroyer, NotPetya, Olympic Destroyer, CaddyWiper, AcidRain/AcidPour, Cyclops Blink, Cobalt Strike, Empire, Mimikatz, Impacket

**Distinctive:** Heavy ICS/SCADA focus; destructive operations (NotPetya caused $10B+ global damage); willingness to cause physical-world impact.

---

### Volt Typhoon (G1017) — China (Critical Infrastructure)

**Aliases:** BRONZE SILHOUETTE, Insidious Taurus, Vanguard Panda
**Active Since:** 2021
**Attribution:** PRC state-sponsored
**Targets:** US critical infrastructure (energy, water, transportation, communications)

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1190 (Exploit Public-Facing — Fortinet, Ivanti, Cisco), T1133 (External Remote Services) |
| Persistence | T1078 (Valid Accounts — domain accounts), T1505.003 (Web Shell) |
| Credential Access | T1003 (NTDS, LSASS, SAM), T1555 (Password Stores), T1552 (Unsecured Credentials) |
| Discovery | T1087 (Account), T1082 (System Info), T1016 (Network Config), T1069 (Permission Groups) |
| Defense Evasion | T1070 (Indicator Removal), T1036 (Masquerading), T1027.002 (Software Packing — UPX) |

**Primary Tools:** LOLBins (PowerShell, cmd, WMIC, netsh, certutil), FRP (Fast Reverse Proxy), Impacket, Earthworm, VersaMem, Awen webshell, PsExec

**Distinctive:** Extreme living-off-the-land approach; minimal custom malware; pre-positioning for OT access; long dwell times; targets SOHO network devices as operational relay nodes.

---

### FIN7 (G0046) — Financial Crime / Ransomware

**Aliases:** Carbanak Group, ITG14
**Active Since:** 2013
**Targets:** Retail, hospitality, financial; shifted to ransomware (2020+)

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566.001/.002 (Spearphishing Attachment/Link), T1190 (Exploit Public-Facing) |
| Execution | T1059.001 (PowerShell), T1059.003 (cmd), T1204.002 (User Execution — Malicious File) |
| Persistence | T1547.001 (Registry Run), T1053.005 (Scheduled Task), T1543.003 (Windows Service) |
| Impact | T1486 (Ransomware — REvil, Darkside) |

**Primary Tools:** Cobalt Strike, PowerSploit, Mimikatz, Carbanak, Lizar, CrackMapExec, AdFind

---

### Wizard Spider (G0102) — Ransomware Operations

**Aliases:** Gold Blackburn, ITG23
**Active Since:** 2016
**Targets:** Big game hunting — healthcare, government, finance

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566 (Spearphishing), T1133 (External Remote — VPN) |
| Persistence | T1547.001 (Registry Run), T1543.003 (Windows Service — "ControlServiceA"), T1053.005 (Scheduled Task — "WinDotNet", "GoogleTask") |
| Credential Access | T1003.001 (LSASS), T1003.003 (NTDS), T1558.003 (Kerberoasting), T1555.004 (Windows Credential Manager) |
| Lateral Movement | T1021.001 (RDP), T1021.002 (SMB), T1570 (Lateral Tool Transfer) |
| Impact | T1490 (Inhibit System Recovery — vssadmin), T1486 (Ryuk/Conti ransomware) |

**Primary Tools:** TrickBot, Ryuk, Conti, Emotet, Cobalt Strike, Empire, Mimikatz, AdFind, BloodHound, PsExec, Bazar

---

### MuddyWater (G0069) — Iran/MOIS

**Aliases:** Mercury, Static Kitten, Mango Sandstorm
**Active Since:** 2017
**Attribution:** Iranian Ministry of Intelligence and Security (MOIS)
**Targets:** Middle East, Asia — government, telecom, energy

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566.001/.002 (Spearphishing Attachment/Link), T1190 (Exploit Public-Facing) |
| Execution | T1059.001 (PowerShell), T1059.005 (VB), T1059.007 (JavaScript) |
| Persistence | T1547.001 (Registry Run), T1137.001 (Office Template Macros), T1053.005 (Scheduled Task) |
| Credential Access | T1003.001 (LSASS), T1555.003 (Browser creds) |
| Defense Evasion | T1027.010 (Command Obfuscation), T1036.005 (Match Legitimate Name), T1574.001 (DLL Hijacking) |

**Primary Tools:** POWERSTATS, Small Sieve, Empire, CrackMapExec, Mimikatz, LaZagne, ConnectWise, RemoteUtilities

---

### Mustang Panda (G0129) — China/Espionage

**Aliases:** BRONZE PRESIDENT, Earth Preta, RedDelta
**Active Since:** 2012
**Attribution:** Chinese state-sponsored
**Targets:** Government, diplomatic entities across Asia, Europe

**Signature TTPs:**

| Tactic | Key Techniques |
|--------|---------------|
| Initial Access | T1566 (Phishing), T1204 (User Execution — decoy documents) |
| Execution | T1059 (PowerShell, VBScript, JavaScript, cmd), T1218 (Msiexec, MMC, Mshta) |
| Persistence | T1547 (Registry Run), T1574 (DLL Search Order Hijacking) |
| Defense Evasion | T1036 (Double extensions), T1027 (Encryption/encoding), T1553 (Code signing with valid certs) |

**Primary Tools:** PlugX, TONESHELL, PUBLOAD, BOOKWORM, Mimikatz, AdFind, NBTscan, Cobalt Strike, ShadowPad, China Chopper

---

## 7. Software & Tooling Reference

### Offensive Tools (Dual-Use / Pen Testing)

| ID | Name | Category | Usage |
|----|------|----------|-------|
| S0154 | Cobalt Strike | C2 Framework | Full-featured adversary simulation; beacon-based post-exploitation |
| S0002 | Mimikatz | Credential Theft | LSASS dumping, pass-the-hash, Kerberos ticket manipulation |
| S0363 | Empire | Post-Exploitation | Cross-platform Python framework; PowerShell/Python agents |
| S0488 | CrackMapExec | Lateral Movement | AD intelligence gathering; credential validation |
| S0029 | PsExec | Remote Execution | Service-based remote command execution |
| S0357 | Impacket | Multi-purpose | Python toolkit — SecretsDump, WMIEXEC, SMBExec, DCSync |
| S0552 | AdFind | Reconnaissance | LDAP-based Active Directory enumeration |
| S0521 | BloodHound | Reconnaissance | AD relationship and attack path mapping |

### Malware Families

| ID | Name | Category | Usage |
|----|------|----------|-------|
| S0367 | Emotet | Loader/Dropper | Modular downloader; distributes TrickBot, IcedID |
| S0266 | TrickBot | Banking Trojan | Credential theft; ransomware delivery |
| S0575 | Conti | Ransomware | RaaS; successor to Ryuk |
| S0446 | Ryuk | Ransomware | Big game hunting; post-TrickBot deployment |
| S0013 | PlugX | RAT | Modular backdoor; DLL side-loading; Chinese APT favorite |
| S0596 | ShadowPad | Backdoor | Advanced modular backdoor with DGA; supply chain risk |
| S0020 | China Chopper | Web Shell | Compact web shell; enterprise network access without callbacks |
| S0032 | gh0st RAT | RAT | Open-source RAT used by multiple threat actors |
| S0021 | Derusbi | Backdoor | Custom backdoor; Windows/Linux variants; Chinese APT |

### Ransomware Ecosystem

| Tool | Operator | Delivery Vector |
|------|----------|----------------|
| Ryuk (S0446) | Wizard Spider | TrickBot/BazarLoader → Cobalt Strike → Ryuk |
| Conti (S0575) | Wizard Spider | TrickBot → Cobalt Strike → Conti |
| REvil | FIN7 / affiliates | Phishing → Cobalt Strike → REvil |
| Darkside | FIN7 / affiliates | Similar to REvil chain |
| Prestige (S1058) | Sandworm | Direct deployment in targeted attacks |

---

## 8. Quick-Reference Cheat Sheets

### Top 10 Most Commonly Observed Techniques (Cross-Group)

Based on frequency across APT groups profiled in this document:

| Rank | Technique | ID | Groups Using |
|------|-----------|----|-------------|
| 1 | Phishing | T1566 | APT28, APT29, Lazarus, FIN7, Wizard Spider, MuddyWater, Mustang Panda, Sandworm |
| 2 | PowerShell | T1059.001 | APT29, APT41, Sandworm, FIN7, Wizard Spider, MuddyWater, Mustang Panda, Lazarus |
| 3 | Valid Accounts | T1078 | APT28, APT29, Volt Typhoon, Wizard Spider |
| 4 | Registry Run Keys | T1547.001 | APT29, APT41, Lazarus, FIN7, Wizard Spider, MuddyWater, Mustang Panda, Sandworm |
| 5 | OS Credential Dumping | T1003 | APT28, APT29, APT41, Volt Typhoon, Wizard Spider, MuddyWater |
| 6 | Exploit Public-Facing App | T1190 | APT29, APT41, Volt Typhoon, FIN7, MuddyWater, Sandworm |
| 7 | Masquerading | T1036 | APT28, Lazarus, Mustang Panda, Sandworm, Volt Typhoon |
| 8 | Obfuscated Files | T1027 | APT29, Lazarus, Sandworm, FIN7, MuddyWater, Mustang Panda |
| 9 | SMB/Admin Shares | T1021.002 | APT28, APT41, Wizard Spider, Sandworm |
| 10 | Scheduled Task | T1053.005 | APT29, APT41, FIN7, Wizard Spider, MuddyWater |

### Detection Priority Matrix

Mapped by tactic to highest-value detection investments:

| Tactic | Priority Detection | Data Source |
|--------|-------------------|-------------|
| Initial Access | Email gateway + WAF logs | Mail server, web server logs |
| Execution | Process creation with command line | Sysmon EventID 1, auditd execve |
| Persistence | Registry/scheduled task/service changes | Sysmon EventID 12-14, 7045 |
| Privilege Escalation | Process injection + token manipulation | Sysmon EventID 8, 10 |
| Defense Evasion | Process hollowing + LOLBIN abuse | Sysmon EventID 1 (parent-child), EDR |
| Credential Access | LSASS access + DCSync replication | Sysmon EventID 10, Security 4662 |
| Discovery | Bulk LDAP/SMB enumeration | Zeek/network logs, DC logs |
| Lateral Movement | RDP/SMB/WinRM auth from unusual sources | Security 4624/4625, firewall logs |
| Collection | Archive creation + mass file access | Sysmon EventID 11, DLP |
| C2 | DNS anomalies + beaconing patterns | DNS logs, Zeek, proxy logs |
| Exfiltration | Large outbound transfers + cloud uploads | Proxy logs, CASB, DLP |
| Impact | Volume shadow deletion + mass encryption | Sysmon EventID 1, Security 4688 |

### Sigma Rule Trigger Points

Priority Sigma rules to build or deploy per critical technique:

```
T1059.001 PowerShell → Encoded command detection (-enc / -e flag)
T1003.001 LSASS Dump  → Process access to lsass.exe (GrantedAccess 0x1010/0x1038)
T1055     Injection   → CreateRemoteThread into non-child process
T1053.005 Sched Task  → schtasks.exe /create from unusual parent
T1078     Valid Accts  → Logon from impossible travel / new geo
T1021.002 SMB Shares  → net use / PsExec service install (PSEXESVC)
T1190     Exploit App  → w3wp.exe / httpd spawning cmd.exe / powershell.exe
T1566.001 Phishing    → WINWORD.EXE / EXCEL.EXE spawning PowerShell/cmd
T1070.001 Log Clear   → wevtutil cl / Clear-EventLog
T1027     Obfuscation  → High entropy strings in command line arguments
```

### Living-off-the-Land Binaries (LOLBins) to Monitor

| Binary | Abuse Pattern | ATT&CK ID |
|--------|--------------|-----------|
| powershell.exe | Encoded commands, download cradles | T1059.001 |
| cmd.exe | Chained commands, redirected output | T1059.003 |
| certutil.exe | File download, Base64 decode | T1140, T1105 |
| mshta.exe | HTA execution, script proxy | T1218.005 |
| rundll32.exe | DLL proxy execution | T1218.011 |
| regsvr32.exe | COM scriptlet execution (Squiblydoo) | T1218.010 |
| wmic.exe | Remote execution, process creation | T1047 |
| msiexec.exe | Remote MSI installation | T1218.007 |
| bitsadmin.exe | File download, persistence | T1197, T1105 |
| schtasks.exe | Task creation for persistence | T1053.005 |
| wevtutil.exe | Event log clearing | T1070.001 |
| net.exe | User/group enumeration, share mapping | T1087, T1135 |
| nltest.exe | Domain trust enumeration | T1482 |
| dsquery.exe | AD object enumeration | T1087.002 |
| vssadmin.exe | Shadow copy deletion (ransomware) | T1490 |

### Attribution Quick-Reference by Nation-State

| Country | Groups | Primary Objectives | Distinctive TTPs |
|---------|--------|-------------------|-----------------|
| Russia | APT28, APT29, Sandworm | Espionage, disruption, influence ops | Supply chain, destructive wiper malware, ICS targeting |
| China | APT41, Volt Typhoon, Mustang Panda | Espionage, IP theft, pre-positioning | Living-off-the-land, DLL side-loading, PlugX/ShadowPad |
| North Korea | Lazarus Group | Financial theft, espionage | Cryptocurrency targeting, custom malware, social engineering |
| Iran | MuddyWater | Espionage, regional influence | PowerShell-heavy, macro-based delivery, legitimate remote admin tools |
| Criminal | FIN7, Wizard Spider | Financial gain, ransomware | Big game hunting, TrickBot→Cobalt Strike→ransomware chain |

---

## Appendix: Version History

| Date | Update |
|------|--------|
| 2026-03-14 | Initial compilation from ATT&CK v18 (Oct 2025) and D3FEND knowledge graph |
