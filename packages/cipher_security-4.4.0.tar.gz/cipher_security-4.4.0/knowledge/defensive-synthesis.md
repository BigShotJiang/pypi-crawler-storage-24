<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Defensive Synthesis Reference

> Generated: 2026-03-14 | Classification: Training Reference
> Cross-references MITRE ATT&CK v15, NIST CSF 2.0, CIS Controls v8

---

## 1. Detection Coverage Matrix — Top 50 MITRE ATT&CK Techniques

### Initial Access

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 1 | Phishing: Spearphishing Attachment | T1566.001 | Email gateway, endpoint | file_event, process_creation | `EmailEvents \| where AttachmentCount > 0 and ThreatTypes has "Phish"` | `index=email sourcetype=esa action=quarantine` | 4688 | 1, 11, 15 | Easy |
| 2 | Exploit Public-Facing Application | T1190 | WAF, web server, IDS/IPS | webserver | `W3CIISLog \| where scStatus >= 400 and scStatus < 500 \| summarize count() by cIP, csUriStem` | `index=web sourcetype=iis status>=400 \| stats count by src_ip, uri_path` | IIS logs | 3 (network conn) | Medium |
| 3 | Valid Accounts | T1078 | AD, IAM, VPN, cloud auth | authentication | `SigninLogs \| where ResultType == 0 and RiskLevelDuringSignIn != "none"` | `index=auth action=success \| stats dc(src_ip) by user` | 4624, 4625, 4648 | — | Hard |
| 4 | External Remote Services | T1133 | VPN, RDP gateway, firewall | network_connection | `SigninLogs \| where AppDisplayName has "VPN" and Location != "expected_country"` | `index=vpn action=success \| iplocation src_ip` | 4624 (Type 10) | 3 | Medium |
| 5 | Supply Chain Compromise | T1195 | Package managers, CI/CD, endpoint | process_creation | `DeviceProcessEvents \| where InitiatingProcessFileName in ("npm","pip","nuget")` | `index=endpoint process_name IN ("npm","pip") \| stats count by parent_process, hash` | 4688 | 1, 7 | Hard |
| 6 | Drive-by Compromise | T1189 | Proxy, DNS, endpoint | proxy, dns_query | `DeviceNetworkEvents \| where RemoteUrl matches regex @"[a-z]{20,}\.(?:top\|xyz\|tk)"` | `index=proxy category=malicious \| stats count by dest_domain, src_ip` | — | 1, 3, 22 | Hard |
| 7 | Trusted Relationship | T1199 | Cloud audit, IAM, VPN | cloud | `AuditLogs \| where OperationName == "Add partner to cross-tenant access setting"` | `index=cloud sourcetype=azure:audit operation="Add partner*"` | 4624 | — | Hard |

### Execution

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 8 | Command and Scripting Interpreter: PowerShell | T1059.001 | PowerShell logging, endpoint | process_creation, ps_script | `DeviceProcessEvents \| where FileName == "powershell.exe" and ProcessCommandLine has_any("-enc","-e ","-ep bypass")` | `index=win sourcetype=WinEventLog:Microsoft-Windows-PowerShell/Operational EventCode=4104 \| regex ScriptBlockText="(?i)(invoke-expression\|iex\|downloadstring)"` | 4103, 4104, 4688 | 1 | Easy |
| 9 | Command and Scripting Interpreter: cmd | T1059.003 | Process auditing | process_creation | `DeviceProcessEvents \| where FileName == "cmd.exe" and ProcessCommandLine has_any("/c ","/k ")` | `index=win EventCode=4688 New_Process_Name="*\\cmd.exe"` | 4688 | 1 | Easy |
| 10 | Windows Management Instrumentation | T1047 | WMI trace, process auditing | process_creation | `DeviceProcessEvents \| where FileName == "wmic.exe" or InitiatingProcessFileName == "wmiprvse.exe"` | `index=win EventCode=4688 (New_Process_Name="*\\wmic.exe" OR New_Process_Name="*\\wmiprvse.exe")` | 4688, 5861 | 1, 20, 21 | Medium |
| 11 | Scheduled Task/Job | T1053.005 | Task Scheduler, process auditing | process_creation | `DeviceProcessEvents \| where FileName == "schtasks.exe" and ProcessCommandLine has "/create"` | `index=win (EventCode=4698 OR (EventCode=4688 New_Process_Name="*\\schtasks.exe"))` | 4698, 4699, 4700, 4702 | 1 | Easy |
| 12 | User Execution: Malicious File | T1204.002 | Endpoint, email | file_event, process_creation | `DeviceProcessEvents \| where InitiatingProcessFileName in ("winword.exe","excel.exe") and FileName in ("cmd.exe","powershell.exe","wscript.exe")` | `index=endpoint parent_process_name IN ("winword.exe","excel.exe") process_name IN ("cmd.exe","powershell.exe")` | 4688 | 1, 11 | Easy |
| 13 | Native API | T1106 | EDR, ETW | process_access | `DeviceEvents \| where ActionType == "NtAllocateVirtualMemory" or ActionType == "CreateRemoteThread"` | `index=edr sourcetype=sysmon EventCode=8` | — | 8, 10 | Hard |
| 14 | Inter-Process Communication: DDE | T1559.002 | Process auditing | process_creation | `DeviceProcessEvents \| where InitiatingProcessFileName in ("excel.exe","winword.exe") and FileName != "splwow64.exe"` | `index=endpoint parent_process IN ("excel.exe","winword.exe") NOT process_name="splwow64.exe"` | 4688 | 1 | Medium |

### Persistence

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 15 | Registry Run Keys / Startup Folder | T1547.001 | Registry auditing, Sysmon | registry_set | `DeviceRegistryEvents \| where RegistryKey has_any("\\Run","\\RunOnce") and ActionType == "RegistryValueSet"` | `index=win sourcetype=sysmon EventCode=13 TargetObject="*\\CurrentVersion\\Run*"` | 4657 | 12, 13, 14 | Easy |
| 16 | Create Account | T1136.001 | Security log | — | `SecurityEvent \| where EventID == 4720` | `index=win EventCode=4720` | 4720, 4722, 4738 | — | Easy |
| 17 | Boot or Logon Autostart: Services | T1543.003 | Service Control Manager | process_creation | `DeviceProcessEvents \| where FileName == "sc.exe" and ProcessCommandLine has "create"` | `index=win EventCode=7045` | 7045, 4697 | 1 | Easy |
| 18 | Server Software Component: Web Shell | T1505.003 | Web server, file integrity | file_event | `DeviceFileEvents \| where FolderPath has_any("\\inetpub\\","\\www\\") and FileName endswith_cs_any(".aspx",".jsp",".php")` | `index=endpoint file_path IN ("*\\inetpub\\*","*/www/*") file_name IN ("*.aspx","*.jsp","*.php")` | — | 11 | Medium |
| 19 | BITS Jobs | T1197 | BITS log, Sysmon | process_creation | `DeviceProcessEvents \| where FileName == "bitsadmin.exe" and ProcessCommandLine has_any("/transfer","/create")` | `index=win EventCode=4688 New_Process_Name="*\\bitsadmin.exe"` | 59-61 (BITS) | 1 | Medium |
| 20 | Office Application Startup | T1137 | File events, registry | registry_set, file_event | `DeviceRegistryEvents \| where RegistryKey has "\\Office\\*\\Security" or RegistryKey has "\\Addins"` | `index=win sourcetype=sysmon EventCode=13 TargetObject="*\\Office\\*"` | — | 11, 13 | Medium |
| 21 | Event Triggered Execution: WMI Sub | T1546.003 | WMI trace | wmi_event | `DeviceEvents \| where ActionType == "WmiBindingEvent"` | `index=win sourcetype=sysmon EventCode IN (19,20,21)` | 5861 | 19, 20, 21 | Medium |

### Privilege Escalation

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 22 | Process Injection | T1055 | EDR, Sysmon | process_access | `DeviceEvents \| where ActionType in ("CreateRemoteThreadApiCall","QueueUserApcRemoteApiCall")` | `index=win sourcetype=sysmon EventCode IN (8,10)` | — | 8, 10 | Hard |
| 23 | Abuse Elevation Control: UAC Bypass | T1548.002 | Process auditing | process_creation | `DeviceProcessEvents \| where FileName in ("fodhelper.exe","eventvwr.exe","sdclt.exe") and InitiatingProcessFileName != "explorer.exe"` | `index=win EventCode=4688 New_Process_Name IN ("*\\fodhelper.exe","*\\eventvwr.exe") NOT Parent_Process="*\\explorer.exe"` | 4688 | 1 | Medium |
| 24 | Access Token Manipulation | T1134 | Process auditing, ETW | process_creation | `DeviceProcessEvents \| where ProcessCommandLine has_any("runas /netonly","token::elevate")` | `index=win EventCode=4688 CommandLine="*runas*/netonly*"` | 4624 (Type 9), 4648 | 1, 10 | Hard |
| 25 | Exploitation for Privilege Escalation | T1068 | EDR, crash dumps | process_creation | `DeviceEvents \| where ActionType == "ExploitGuardElevation"` | `index=edr exploit_prevention=true` | — | 1 (unusual child) | Hard |

### Defense Evasion

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 26 | Obfuscated Files or Information | T1027 | Script block logging, EDR | ps_script | `DeviceProcessEvents \| where ProcessCommandLine matches regex @"[A-Za-z0-9+/=]{100,}"` | `index=win EventCode=4104 ScriptBlockText="*[Convert]::FromBase64*"` | 4104 | 1 | Medium |
| 27 | Masquerading | T1036.005 | Process auditing, Sysmon | process_creation | `DeviceProcessEvents \| where FileName == "svchost.exe" and not(FolderPath startswith "C:\\Windows\\System32")` | `index=win EventCode=4688 process_name=svchost.exe NOT process_path="C:\\Windows\\System32\\*"` | 4688 | 1 | Medium |
| 28 | Indicator Removal: Clear Event Logs | T1070.001 | Security log | — | `SecurityEvent \| where EventID == 1102` | `index=win EventCode=1102` | 1100, 1102 | — | Easy |
| 29 | Disable or Modify Tools | T1562.001 | Security log, EDR | process_creation | `DeviceProcessEvents \| where ProcessCommandLine has_any("Set-MpPreference -DisableRealtimeMonitoring","sc stop WinDefend")` | `index=win EventCode=4688 CommandLine="*Set-MpPreference*Disable*"` | 4688, 5001 (Defender) | 1 | Easy |
| 30 | Signed Binary Proxy Execution: Rundll32 | T1218.011 | Process auditing | process_creation | `DeviceProcessEvents \| where FileName == "rundll32.exe" and ProcessCommandLine has_any("javascript:","http://","shell32.dll,Control_RunDLL")` | `index=win process_name=rundll32.exe CommandLine IN ("*javascript:*","*http://*")` | 4688 | 1 | Medium |
| 31 | Signed Binary Proxy Execution: Mshta | T1218.005 | Process auditing | process_creation | `DeviceProcessEvents \| where FileName == "mshta.exe"` | `index=win EventCode=4688 New_Process_Name="*\\mshta.exe"` | 4688 | 1 | Easy |
| 32 | Impair Defenses: Disable Windows Event Logging | T1562.002 | Security log, registry | registry_set | `SecurityEvent \| where EventID == 1102 or (EventID == 4719 and AuditPolicyChanges has "removed")` | `index=win (EventCode=1102 OR EventCode=4719)` | 1102, 4719 | 13 | Easy |
| 33 | Modify Authentication Process | T1556 | Security log, file integrity | file_event | `DeviceFileEvents \| where FolderPath has "\\System32\\" and FileName has_any("lsass","msv1","wdigest")` | `index=win sourcetype=sysmon EventCode=11 TargetFilename="*\\System32\\*" file_name IN ("*lsass*","*msv1*")` | — | 11 | Hard |

### Credential Access

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 34 | OS Credential Dumping: LSASS Memory | T1003.001 | EDR, Sysmon | process_access | `DeviceProcessEvents \| where FileName in ("procdump.exe","mimikatz.exe") or (ActionType == "OpenProcess" and TargetProcessName == "lsass.exe")` | `index=win sourcetype=sysmon EventCode=10 TargetImage="*\\lsass.exe" GrantedAccess IN ("0x1010","0x1410","0x1fffff")` | — | 10 | Medium |
| 35 | Brute Force | T1110 | Security log, IAM | authentication | `SecurityEvent \| where EventID == 4625 \| summarize FailCount=count() by TargetUserName, bin(TimeGenerated, 5m) \| where FailCount > 10` | `index=win EventCode=4625 \| stats count by user _time span=5m \| where count>10` | 4625, 4771 | — | Easy |
| 36 | Credentials from Password Stores | T1555 | Process auditing | process_creation, file_event | `DeviceProcessEvents \| where ProcessCommandLine has_any("vaultcmd","cmdkey /list","chrome --headless")` | `index=endpoint process_name IN ("vaultcmd.exe","cmdkey.exe") OR CommandLine="*chrome*headless*password*"` | 4688 | 1 | Medium |
| 37 | Kerberoasting | T1558.003 | Security log | — | `SecurityEvent \| where EventID == 4769 and TicketEncryptionType == "0x17" and ServiceName !endswith "$"` | `index=win EventCode=4769 Ticket_Encryption_Type=0x17 Service_Name!="*$"` | 4769 | — | Medium |
| 38 | DCSync | T1003.006 | Security log, DC replication | — | `SecurityEvent \| where EventID == 4662 and Properties has_any("1131f6aa-","1131f6ad-")` | `index=win EventCode=4662 Properties IN ("*1131f6aa*","*1131f6ad*") NOT Account_Name="*$"` | 4662 | — | Medium |

### Discovery

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 39 | System Information Discovery | T1082 | Process auditing | process_creation | `DeviceProcessEvents \| where FileName in ("systeminfo.exe","hostname.exe") or ProcessCommandLine has "Get-ComputerInfo"` | `index=win EventCode=4688 New_Process_Name IN ("*\\systeminfo.exe","*\\hostname.exe")` | 4688 | 1 | Easy |
| 40 | Account Discovery | T1087 | Process auditing | process_creation | `DeviceProcessEvents \| where ProcessCommandLine has_any("net user","net group","Get-ADUser","whoami")` | `index=win EventCode=4688 CommandLine IN ("*net user*","*net group*","*whoami*")` | 4688 | 1 | Easy |
| 41 | Network Service Discovery | T1046 | Firewall, IDS, Sysmon | network_connection | `DeviceNetworkEvents \| summarize PortCount=dcount(RemotePort) by DeviceName, RemoteIP, bin(Timestamp, 1m) \| where PortCount > 20` | `index=firewall \| stats dc(dest_port) as port_count by src_ip dest_ip \| where port_count>20` | — | 3 | Medium |
| 42 | Permission Groups Discovery | T1069 | Process auditing | process_creation | `DeviceProcessEvents \| where ProcessCommandLine has_any("net localgroup","Get-ADGroupMember","gpresult")` | `index=win EventCode=4688 CommandLine IN ("*net localgroup*","*Get-ADGroupMember*")` | 4688 | 1 | Easy |

### Lateral Movement

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 43 | Remote Services: RDP | T1021.001 | Security log, Sysmon | authentication, network_connection | `SecurityEvent \| where EventID == 4624 and LogonType == 10` | `index=win EventCode=4624 Logon_Type=10` | 4624 (Type 10), 4778, 4779 | 3 | Easy |
| 44 | Remote Services: SMB/Windows Admin Shares | T1021.002 | Security log, Sysmon | network_connection | `SecurityEvent \| where EventID == 5140 and ShareName in ("\\\\*\\C$","\\\\*\\ADMIN$")` | `index=win EventCode=5140 Share_Name IN ("\\\\*\\C$","\\\\*\\ADMIN$")` | 5140, 5145 | 3 | Medium |
| 45 | Lateral Tool Transfer | T1570 | File events, Sysmon | file_event | `DeviceFileEvents \| where FolderPath has_any("\\ADMIN$","\\C$") and FileName endswith_any(".exe",".dll",".ps1")` | `index=win sourcetype=sysmon EventCode=11 TargetFilename IN ("*\\ADMIN$\\*","*\\C$\\*")` | 5145 | 11 | Medium |
| 46 | Remote Services: WinRM | T1021.006 | PowerShell logging, Security log | process_creation, network_connection | `DeviceProcessEvents \| where FileName == "wsmprovhost.exe"` | `index=win EventCode=4688 New_Process_Name="*\\wsmprovhost.exe"` | 4688, 91 (WinRM) | 1, 3 | Medium |

### Collection, Exfiltration, Command and Control

| # | Technique | ATT&CK ID | Required Log Sources | Sigma Category | KQL Reference | SPL Reference | Windows Event IDs | Sysmon Event IDs | Difficulty |
|---|-----------|-----------|---------------------|----------------|---------------|---------------|-------------------|------------------|------------|
| 47 | Archive Collected Data | T1560.001 | Process auditing | process_creation | `DeviceProcessEvents \| where FileName in ("7z.exe","rar.exe","zip.exe") or ProcessCommandLine has "Compress-Archive"` | `index=win EventCode=4688 process_name IN ("7z.exe","rar.exe","zip.exe")` | 4688 | 1 | Easy |
| 48 | Exfiltration Over Web Service | T1567 | Proxy, firewall, DLP | network_connection, proxy | `DeviceNetworkEvents \| where RemoteUrl has_any("mega.nz","anonfiles","dropmefiles","transfer.sh") and SentBytes > 10000000` | `index=proxy dest IN ("mega.nz","anonfiles.com","transfer.sh") bytes_out>10000000` | — | 3, 22 | Medium |
| 49 | Application Layer Protocol: DNS | T1071.004 | DNS, Sysmon | dns_query | `DnsEvents \| where QueryType in ("TXT","NULL") or strlen(Name) > 50 \| summarize count() by ClientIP, bin(TimeGenerated, 5m) \| where count_ > 50` | `index=dns (query_type=TXT OR query_type=NULL OR record_type=TXT) \| eval len=len(query) \| where len>50` | — | 22 | Hard |
| 50 | Ingress Tool Transfer | T1105 | Proxy, Sysmon, EDR | network_connection, process_creation | `DeviceProcessEvents \| where ProcessCommandLine has_any("certutil -urlcache","wget","curl","Invoke-WebRequest","bitsadmin /transfer")` | `index=win EventCode=4688 CommandLine IN ("*certutil*urlcache*","*wget*","*curl*","*Invoke-WebRequest*")` | 4688 | 1, 3, 11 | Easy |

### Coverage Summary

| Tactic | Techniques Covered | Avg Difficulty | Critical Log Sources |
|--------|-------------------|----------------|---------------------|
| Initial Access | 7 | Medium-Hard | Email gateway, WAF, IAM, proxy |
| Execution | 7 | Easy-Medium | PowerShell logging (4103/4104), Sysmon EventCode 1, process auditing (4688) |
| Persistence | 7 | Easy-Medium | Registry auditing (Sysmon 12/13/14), service logs (7045), file monitoring (Sysmon 11) |
| Privilege Escalation | 4 | Medium-Hard | Sysmon 8/10 (process injection), ETW, process auditing |
| Defense Evasion | 8 | Easy-Medium | Script block logging (4104), Sysmon 1, security log (1102) |
| Credential Access | 5 | Easy-Medium | Security log (4625/4769/4662), Sysmon 10 (LSASS access) |
| Discovery | 4 | Easy | Process auditing (4688), Sysmon 1/3 |
| Lateral Movement | 4 | Easy-Medium | Security log (4624/5140), Sysmon 3/11 |
| Collection/Exfil/C2 | 4 | Easy-Hard | Proxy, DNS, DLP, Sysmon 22 |

### Minimum Viable Logging for Detection

Without these sources, coverage drops catastrophically:

1. **Windows Security Log** (4624, 4625, 4648, 4662, 4688, 4698, 4720, 4769, 5140) — enable command-line auditing
2. **Sysmon** (all events, especially 1, 3, 7, 8, 10, 11, 12/13/14, 22) — use SwiftOnSecurity or Olaf Hartong config
3. **PowerShell Script Block Logging** (4103, 4104) — GPO: `Turn on PowerShell Script Block Logging`
4. **DNS query logging** (Sysmon 22 or DNS Debug Logging)
5. **Proxy/firewall logs** with full URL and bytes transferred

---

## 2. Security Architecture Decision Trees

### 2.1 New SaaS Application Design

```
START: New SaaS Application
|
+-- [1] Data Classification
|   |-- What data will be processed?
|   |   +-- PII/PHI/PCI --> Encryption at rest + in transit mandatory
|   |   |                   Data residency requirements? --> Region-locked deployment
|   |   |                   Regulatory scope: GDPR/HIPAA/PCI-DSS
|   |   +-- Business confidential --> Encryption at rest, TLS 1.2+ in transit
|   |   +-- Public --> TLS in transit, integrity verification
|   |
+-- [2] Authentication & Identity
|   |-- Multi-tenant?
|   |   +-- Yes --> Tenant isolation model:
|   |   |          +-- Silo (separate DB per tenant) --> Strongest isolation, highest cost
|   |   |          +-- Bridge (shared DB, row-level security) --> Cost effective, needs careful RLS
|   |   |          +-- Pool (shared everything) --> Only for non-sensitive data
|   |   +-- No --> Single-tenant auth
|   |-- Auth provider:
|   |   +-- Build custom auth --> NO. Use established IdP (Auth0, Entra ID, Cognito)
|   |   +-- Social login only --> Add MFA requirement for elevated actions
|   |   +-- Enterprise SSO --> SAML 2.0 / OIDC, support SCIM provisioning
|   |-- Session management:
|       +-- Stateless JWT --> Short-lived (15min), refresh token rotation, token binding
|       +-- Stateful sessions --> Server-side store, secure cookie flags (HttpOnly, Secure, SameSite=Strict)
|
+-- [3] API Security
|   +-- All APIs --> Rate limiting, input validation, output encoding
|   +-- Public APIs --> OAuth 2.0 + API keys, abuse detection
|   +-- Internal APIs --> mTLS, service mesh, no API keys in code
|   +-- Webhook receivers --> Signature verification (HMAC-SHA256), idempotency
|
+-- [4] Infrastructure
|   +-- Compute: containers (ECS/GKE) preferred over VMs for immutability
|   +-- Secrets: Vault / AWS Secrets Manager / Azure Key Vault (never env vars in code)
|   +-- WAF: OWASP CRS ruleset minimum, custom rules for business logic
|   +-- CDN: Origin shielding, DDoS protection (CloudFlare/AWS Shield)
|
+-- [5] Security Testing Pipeline
|   +-- Pre-commit: secrets scanning (gitleaks/trufflehog)
|   +-- CI: SAST (Semgrep), SCA (Dependabot/Snyk), container scan (Trivy)
|   +-- CD: DAST (OWASP ZAP), infrastructure scan
|   +-- Production: Bug bounty, annual pentest, continuous monitoring
|
+-- [6] Logging & Monitoring
|   +-- Structured logging (JSON) --> SIEM ingestion
|   +-- Auth events, access decisions, data access (audit trail)
|   +-- Anomaly detection on API usage patterns
|   +-- Alerting: failed auth spikes, privilege escalation, data exfil indicators
|
+-- DECISION OUTPUT:
    +-- Architecture Decision Record (ADR) documenting each choice
    +-- Threat model (STRIDE) before first line of code
    +-- Security requirements in acceptance criteria
```

### 2.2 Microservices Migration

```
START: Monolith --> Microservices
|
+-- [1] Identify Security Boundaries
|   +-- Map existing auth flows --> Which services need user context?
|   +-- Map data flows --> Where does sensitive data cross boundaries?
|   +-- Identify trust boundaries --> Internal vs external, privilege levels
|
+-- [2] Service-to-Service Authentication
|   |-- Option A: Service Mesh (Istio/Linkerd)
|   |   +-- mTLS automatic between services
|   |   +-- Authorization policies at mesh layer
|   |   +-- BEST for: large deployments, polyglot services
|   |-- Option B: JWT propagation
|   |   +-- API gateway validates, propagates claims
|   |   +-- Services validate JWT signature + claims
|   |   +-- BEST for: smaller deployments, uniform tech stack
|   |-- Option C: mTLS + OAuth2 client credentials
|   |   +-- Certificate-based identity + scoped tokens
|   |   +-- BEST for: high-security environments
|   +-- NEVER: shared secrets, API keys in config, no auth between services
|
+-- [3] Data Isolation
|   +-- Database per service (preferred) --> No cross-service DB queries
|   +-- Shared DB with schema separation --> Acceptable interim step
|   +-- Event-driven data sync --> Saga pattern for transactions
|   +-- Encrypt PII at the owning service --> Other services get tokens/references
|
+-- [4] API Gateway Security
|   +-- Centralized: rate limiting, auth, input validation, request logging
|   +-- mTLS termination at gateway, re-encryption to services
|   +-- Circuit breaker pattern to prevent cascade failures
|
+-- [5] Secrets Management
|   +-- Centralized vault (HashiCorp Vault, cloud-native KMS)
|   +-- Dynamic secrets with TTL (DB creds, API keys)
|   +-- No secrets in container images, env vars only from vault injection
|
+-- [6] Observability for Security
|   +-- Distributed tracing (Jaeger/Zipkin) --> Detect anomalous call patterns
|   +-- Centralized logging with correlation IDs
|   +-- Service dependency map --> Attack path visualization
|
+-- MIGRATION ORDER:
    1. API gateway + auth service first
    2. Logging/monitoring infrastructure
    3. Extract services starting with least-coupled
    4. Security testing at each extraction step
```

### 2.3 Cloud Migration (On-Prem to AWS/Azure/GCP)

```
START: Cloud Migration
|
+-- [1] Cloud Provider Selection (Security Lens)
|   +-- Regulatory constraints?
|   |   +-- FedRAMP --> AWS GovCloud / Azure Gov
|   |   +-- Data sovereignty (EU) --> Region-locked, check provider DPA
|   |   +-- HIPAA --> BAA required (all three support)
|   +-- Existing identity provider?
|   |   +-- Active Directory heavy --> Azure (Entra ID integration)
|   |   +-- Google Workspace --> GCP
|   |   +-- Neutral --> AWS (largest ecosystem)
|
+-- [2] Identity & Access Management
|   +-- Federate corporate IdP --> SSO to cloud console
|   +-- Least privilege IAM policies from day one
|   +-- No long-lived access keys --> Use roles/workload identity
|   +-- Separate accounts/subscriptions/projects per environment
|   +-- Break-glass procedure for emergency access
|
+-- [3] Network Architecture
|   +-- Landing zone pattern (AWS Control Tower / Azure Landing Zone / GCP Foundation)
|   +-- Hub-spoke or transit gateway topology
|   +-- Private subnets for workloads, public only for load balancers
|   +-- VPN/DirectConnect/ExpressRoute for hybrid connectivity
|   +-- DNS: split-horizon, no internal names resolvable externally
|   +-- Egress filtering: explicit allow-list, no unrestricted outbound
|
+-- [4] Data Protection
|   +-- Encryption at rest: cloud-managed keys (minimum), CMK (preferred), BYOK (high security)
|   +-- Encryption in transit: TLS 1.2+ everywhere, mTLS for service-to-service
|   +-- Data classification tags on all storage resources
|   +-- DLP scanning on storage buckets/blobs
|   +-- Backup encryption with separate key management
|
+-- [5] Security Tooling Stack
|   +-- CSPM: AWS Security Hub / Azure Defender / GCP SCC
|   +-- Cloud-native WAF + DDoS protection
|   +-- Flow logs / VPC logs --> SIEM
|   +-- CloudTrail / Activity Log / Cloud Audit Logs --> SIEM
|   +-- GuardDuty / Sentinel / Chronicle for threat detection
|
+-- [6] Migration Phases (Security Gating)
    Phase 0: Landing zone + security baseline (CIS Benchmark)
    Phase 1: Non-sensitive workloads, validate controls
    Phase 2: Sensitive workloads with full audit trail
    Phase 3: Decommission on-prem, close hybrid attack surface
    Each phase: security review gate before promotion
```

### 2.4 API-First Application

```
START: API-First Application
|
+-- [1] API Design Security
|   +-- OpenAPI/Swagger spec --> Security schemes defined in spec
|   +-- Versioning strategy (URI vs header) --> Deprecation = security patching window
|   +-- Input validation at schema level (JSON Schema, max lengths, patterns)
|   +-- Output filtering: never return more fields than needed
|
+-- [2] Authentication Model
|   +-- Consumer type?
|   |   +-- End users (browser/mobile) --> OAuth 2.0 Authorization Code + PKCE
|   |   +-- Server-to-server --> OAuth 2.0 Client Credentials
|   |   +-- Third-party developers --> API keys + OAuth 2.0 (scoped)
|   |   +-- Internal services --> mTLS + service accounts
|   +-- Token format:
|       +-- Opaque tokens + introspection --> Better revocation, more latency
|       +-- JWT --> Stateless validation, harder revocation (use short TTL + blocklist)
|
+-- [3] Authorization
|   +-- RBAC minimum, ABAC for fine-grained
|   +-- Authorization at API gateway (coarse) + service (fine-grained)
|   +-- Broken Object Level Authorization (BOLA/IDOR) prevention:
|       +-- Validate resource ownership on every request
|       +-- Use UUIDs not sequential IDs
|       +-- Automated BOLA testing in CI
|
+-- [4] Rate Limiting & Abuse Prevention
|   +-- Per-consumer rate limits (token bucket)
|   +-- Separate limits for auth endpoints (stricter)
|   +-- Cost-based rate limiting for expensive operations
|   +-- Bot detection for public APIs
|
+-- [5] API Security Testing
|   +-- Contract testing: schema validation in CI
|   +-- DAST: OWASP ZAP API scan mode
|   +-- Fuzzing: RESTler, Schemathesis
|   +-- BOLA scanner: custom or AuthMatrix (Burp)
|
+-- [6] API Gateway Checklist
    [ ] TLS 1.2+ termination
    [ ] Request size limits
    [ ] Content-Type validation
    [ ] CORS policy (explicit origins, not *)
    [ ] Security headers (X-Content-Type-Options, X-Frame-Options, CSP)
    [ ] Request/response logging (redact sensitive fields)
    [ ] Circuit breaker for downstream failures
```

### 2.5 Zero Trust Implementation (Mid-Size Enterprise)

```
START: Zero Trust for Mid-Size Enterprise (500-5000 employees)
|
+-- [1] Maturity Assessment
|   +-- Current state: traditional perimeter? partial ZT? hybrid?
|   +-- Identity maturity: MFA deployed? SSO? lifecycle management?
|   +-- Device management: MDM? health checks? BYOD policy?
|   +-- Network: flat? segmented? micro-segmented?
|
+-- [2] Identity Pillar (Phase 1 - Start Here)
|   +-- Single IdP for all users (Entra ID / Okta / Google)
|   +-- MFA mandatory, phishing-resistant preferred (FIDO2/passkeys)
|   +-- Conditional access policies:
|   |   +-- Device compliance required
|   |   +-- Location-based (block impossible travel)
|   |   +-- Risk-based (step-up auth for anomalies)
|   +-- Privileged access: PAM solution, JIT access, session recording
|   +-- Service accounts: no shared passwords, managed identities
|
+-- [3] Device Pillar (Phase 2)
|   +-- Device inventory: all endpoints enrolled in MDM
|   +-- Health attestation before access (OS patched, AV running, disk encrypted)
|   +-- BYOD: separate access tier, MAM for corporate data
|   +-- Certificate-based device identity
|
+-- [4] Network Pillar (Phase 3)
|   +-- Micro-segmentation: identity-based not IP-based
|   +-- SDP/ZTNA replacing VPN (Zscaler/Cloudflare Access/Tailscale)
|   +-- East-west traffic inspection
|   +-- DNS filtering for all endpoints
|   +-- Encrypted DNS (DoH/DoT) to managed resolver only
|
+-- [5] Application & Data Pillar (Phase 4)
|   +-- App-level authorization (not network-level)
|   +-- Data classification and labeling
|   +-- DLP policies based on classification
|   +-- Encryption: at rest, in transit, in use where feasible
|
+-- [6] Visibility & Analytics (Continuous)
|   +-- All access decisions logged centrally
|   +-- UEBA for anomaly detection
|   +-- Continuous trust evaluation (not point-in-time)
|   +-- Automated response: revoke access on high-risk signal
|
+-- BUDGET PRIORITY (if constrained):
    1. MFA + SSO (highest ROI)
    2. Conditional access policies
    3. EDR on all endpoints
    4. ZTNA for remote access
    5. Micro-segmentation for crown jewels
```

### 2.6 Container/K8s Deployment Security

```
START: Container / Kubernetes Security
|
+-- [1] Image Security
|   +-- Base images: minimal (distroless/Alpine), pinned digests not tags
|   +-- No secrets in images (build args, env files, embedded creds)
|   +-- Image scanning in CI: Trivy, Grype, Snyk Container
|   +-- Signing: cosign/Notary, admission controller verifies signatures
|   +-- Registry: private, immutable tags, vulnerability auto-scanning
|
+-- [2] Build Pipeline
|   +-- Multi-stage builds (build deps not in runtime image)
|   +-- Non-root USER directive in Dockerfile
|   +-- Read-only filesystem where possible
|   +-- SBOM generation (syft) at build time
|   +-- No package managers in production images
|
+-- [3] Kubernetes Cluster Security
|   +-- API server: RBAC enabled, anonymous auth disabled, audit logging on
|   +-- etcd: encrypted at rest, mTLS, restricted network access
|   +-- Node: CIS Kubernetes Benchmark, minimal OS (Bottlerocket/Talos)
|   +-- Network: CNI with NetworkPolicy support (Calico/Cilium)
|   +-- Admission controllers:
|       +-- OPA/Gatekeeper or Kyverno
|       +-- Pod Security Standards (restricted profile)
|       +-- Block: privileged, hostNetwork, hostPID, root containers
|
+-- [4] Runtime Security
|   +-- Pod Security Context:
|   |   +-- runAsNonRoot: true
|   |   +-- readOnlyRootFilesystem: true
|   |   +-- allowPrivilegeEscalation: false
|   |   +-- drop ALL capabilities, add only needed
|   +-- Seccomp profiles (RuntimeDefault minimum)
|   +-- AppArmor/SELinux profiles for sensitive workloads
|   +-- Runtime threat detection: Falco, Tetragon, or cloud-native
|
+-- [5] Network Security
|   +-- Default-deny NetworkPolicy per namespace
|   +-- Service mesh for mTLS (Istio/Linkerd) between services
|   +-- Ingress: TLS termination, WAF integration
|   +-- Egress: explicit allow-list, no unrestricted internet access
|
+-- [6] Secrets & Config
|   +-- External secrets operator --> Vault / cloud KMS
|   +-- Never K8s Secrets without encryption at rest
|   +-- RBAC on secrets: namespace-scoped, least privilege
|   +-- Rotate secrets automatically, detect drift
|
+-- [7] Observability
    +-- Audit logs: API server --> SIEM
    +-- Container logs: structured, centralized (no kubectl logs in production)
    +-- Falco alerts --> SIEM/SOAR
    +-- Resource quotas and LimitRanges per namespace
```

### 2.7 IoT/OT Environment Segmentation

```
START: IoT/OT Segmentation
|
+-- [1] Asset Discovery & Classification
|   +-- Passive discovery: network TAP, SPAN port, protocol analysis
|   +-- Asset inventory: device type, firmware, protocol, criticality
|   +-- Purdue model level assignment (Level 0-5)
|   +-- Crown jewel identification: safety systems, HMIs, historians
|
+-- [2] Network Architecture (Purdue Model)
|   +-- Level 5 (Enterprise) <--DMZ--> Level 3.5 (IDMZ)
|   +-- IDMZ: data diodes or unidirectional gateways for critical flows
|   +-- Level 3 (Site Operations) <--FW--> Level 2 (Area Supervisory)
|   +-- Level 2 (HMI/SCADA) <--FW--> Level 1 (Controllers/PLCs)
|   +-- Level 0 (Physical Process) -- air-gapped where possible
|   +-- NO direct IT-to-OT connectivity bypassing IDMZ
|
+-- [3] Segmentation Controls
|   +-- Firewall between each Purdue level (not just IT/OT boundary)
|   +-- Protocol-aware firewalls for OT (Modbus, DNP3, OPC-UA inspection)
|   +-- VLAN per device class within OT (PLCs, HMIs, historians separate)
|   +-- Remote access: jump server in IDMZ, MFA, session recording
|   +-- NEVER: VPN directly to OT, flat OT network, cloud-connected PLCs
|
+-- [4] IoT Device Security
|   +-- Unique device identity (X.509 certs, not shared credentials)
|   +-- Firmware update mechanism: signed updates, rollback capability
|   +-- Disable unnecessary services (telnet, SNMP v1/v2, HTTP)
|   +-- Default credential change (automated at provisioning)
|   +-- IoT gateway pattern: devices talk to gateway, gateway talks to cloud
|
+-- [5] Monitoring & Detection
|   +-- OT-specific IDS: Claroty, Nozomi, Dragos, Microsoft Defender for IoT
|   +-- Baseline normal protocol behavior --> Alert on deviations
|   +-- Monitor: unauthorized PLC programming, firmware changes, new devices
|   +-- No active scanning in OT (can crash PLCs) --> Passive only
|
+-- [6] Incident Response (OT-Specific)
|   +-- Safety-first: never containment action that impacts safety systems
|   +-- Pre-approved response playbooks per zone
|   +-- Offline backups of PLC programs and configurations
|   +-- Manual override procedures documented and tested
|
+-- PRIORITY ORDER:
    1. Asset inventory (you cannot protect what you do not know)
    2. IT/OT boundary firewall with IDMZ
    3. Remote access hardening
    4. OT network monitoring (passive)
    5. Internal OT segmentation
    6. Device hardening (rolling, non-disruptive)
```

---

## 3. Security Tool Selection Matrix

### 3.1 Vulnerability Scanning

| Sub-Category | Tool | License | Strengths | Weaknesses | Best For |
|-------------|------|---------|-----------|------------|----------|
| **Infrastructure** | Nessus Professional | Commercial | Comprehensive plugin library, compliance checks | Expensive per-scanner licensing | Enterprise vulnerability management |
| | OpenVAS/Greenbone | Open Source | Free, decent coverage | Slower scan performance, UI dated | Budget-constrained teams |
| | Qualys VMDR | Commercial SaaS | Cloud-native, agent-based option, risk prioritization | Vendor lock-in, pricing complexity | Large distributed environments |
| **Web Application** | Burp Suite Pro | Commercial | Best manual testing proxy, extensive extensions | Learning curve, not CI-native | Pentesters, security engineers |
| | OWASP ZAP | Open Source | Free, CI/CD integration, active community | Higher false positives than Burp | DevSecOps pipelines, automation |
| | Nuclei | Open Source | Template-based, fast, community templates | Requires template knowledge | Bug bounty, rapid scanning |
| **Container** | Trivy | Open Source | Fast, multi-target (images, IaC, SBOM), CI-friendly | Less deep than commercial options | CI/CD pipeline scanning |
| | Grype | Open Source | Anchore-backed, SBOM integration | Smaller vulnerability DB | SBOM-centric workflows |
| | Snyk Container | Commercial | Developer-friendly, fix advice, IDE integration | Per-test pricing | Developer-first security |
| **IaC** | Checkov | Open Source | Multi-framework (TF, CloudFormation, K8s, Helm) | Custom policy requires effort | Broad IaC coverage |
| | tfsec/Trivy | Open Source | Terraform-focused, fast, CI-native | Terraform-specific (tfsec) | Terraform shops |
| | KICS | Open Source | Multi-framework, Checkmarx-backed | Newer, smaller community | Multi-cloud IaC scanning |
| **Secrets** | Gitleaks | Open Source | Pre-commit hooks, CI integration, regex-based | Regex limitations | Git repo scanning |
| | TruffleHog | Open Source | Verified secrets (actually tests validity), git history scan | Slower on large repos | Deep historical secret detection |
| | GitGuardian | Commercial | Real-time monitoring, remediation workflow | Pricing at scale | Enterprise secret monitoring |

### 3.2 Detection

| Sub-Category | Tool | License | Strengths | Weaknesses | Best For |
|-------------|------|---------|-----------|------------|----------|
| **SIEM** | Splunk Enterprise | Commercial | Most powerful search (SPL), massive ecosystem | Expensive (data-volume pricing) | Large SOCs, complex environments |
| | Microsoft Sentinel | Commercial SaaS | Cloud-native, Entra integration, KQL, SOAR built-in | Azure-centric pricing, learning KQL | Microsoft/Azure shops |
| | Elastic Security | Open/Commercial | Open core, powerful, self-hosted option | Operational overhead self-hosted | Teams wanting open-core SIEM |
| | Wazuh | Open Source | Free, HIDS + SIEM, compliance, FIM | UI/UX weaker, smaller ecosystem | Budget-constrained or SMB |
| | CrowdStrike Falcon LogScale (Humio) | Commercial | Streaming architecture, index-free, fast | Newer SIEM entrant | High-volume log environments |
| **EDR** | CrowdStrike Falcon | Commercial | Best detection rates, lightweight agent, threat intel | Premium pricing | Enterprise endpoint protection |
| | Microsoft Defender for Endpoint | Commercial | Integrated with M365, good detection, included in E5 | Windows-centric heritage | Microsoft E5 customers |
| | SentinelOne | Commercial | Autonomous response, storyline visualization | Aggressive auto-remediation can break things | Lean SOC teams |
| | Velociraptor | Open Source | Powerful artifact collection, VQL, forensics-grade | Not a full EDR replacement, no prevention | Threat hunting, IR, small teams |
| **NDR** | Zeek (formerly Bro) | Open Source | Best network metadata generation, scriptable | Not plug-and-play, requires expertise | Network security monitoring |
| | Suricata | Open Source | IDS/IPS, protocol detection, fast pattern matching | Rule tuning overhead | Network IDS/IPS |
| | Corelight | Commercial | Zeek-based appliance, cloud sensors, managed | Expensive | Enterprise network visibility |
| | Arkime (formerly Moloch) | Open Source | Full packet capture + indexing + search | Storage-heavy, operational overhead | PCAP retention and analysis |
| **UEBA** | Microsoft Sentinel UEBA | Commercial | Built into Sentinel, identity-focused | Requires Sentinel deployment | Sentinel customers |
| | Exabeam | Commercial | Behavioral analytics, timeline, smart timelines | Complex deployment | Large SOC, insider threat |
| | Securonix | Commercial | Cloud SIEM + UEBA, peer group analysis | Implementation complexity | Insider threat programs |

### 3.3 Response

| Sub-Category | Tool | License | Strengths | Weaknesses | Best For |
|-------------|------|---------|-----------|------------|----------|
| **SOAR** | Palo Alto XSOAR (Demisto) | Commercial | Huge integration library, playbook builder | Complexity, licensing cost | Large SOC automation |
| | Tines | Commercial | No-code automation, clean UI, free community tier | Fewer native integrations than XSOAR | Growing teams, accessible automation |
| | Shuffle | Open Source | Free, Docker-based, OpenAPI integration | Smaller community, rougher edges | Budget SOAR, open-source teams |
| | Sentinel Playbooks | Commercial | Logic Apps-based, Azure-native | Azure-only, Logic Apps learning curve | Sentinel-based SOCs |
| **IR** | TheHive | Open Source | Case management, Cortex analyzers, MISP integration | Self-hosted overhead | IR teams, CERT/CSIRT |
| | Velociraptor | Open Source | Remote collection, VQL hunts, offline collectors | Not an IR platform per se | Artifact collection at scale |
| | GRR | Open Source | Google-built, remote live forensics | Dated UI, Python 2 legacy | Large-scale endpoint investigation |
| **Forensics** | Autopsy / Sleuth Kit | Open Source | Disk forensics, timeline analysis, file carving | Desktop tool, not scalable | Disk forensics |
| | Volatility 3 | Open Source | Memory forensics standard, plugin ecosystem | Requires memory dumps, profile matching | Memory analysis |
| | KAPE | Free (closed) | Fast triage collection, modular targets/modules | Windows-only, not open source | Windows triage collection |
| | Plaso/log2timeline | Open Source | Super timeline generation, many parsers | Output can be overwhelming | Timeline creation |
| | Eric Zimmerman Tools | Free (closed) | Registry, shellbags, prefetch, shimcache parsers | Windows-only, individual tools | Windows artifact parsing |

### 3.4 Offensive

| Sub-Category | Tool | License | Strengths | Weaknesses | Best For |
|-------------|------|---------|-----------|------------|----------|
| **Recon** | Amass | Open Source | Comprehensive subdomain enumeration, graph DB | Resource-intensive | External attack surface mapping |
| | Shodan | Commercial | Internet-wide scanning data, API access | Passive only, data freshness varies | Exposed service discovery |
| | theHarvester | Open Source | Email, subdomain, name collection from OSINT | Limited depth per source | Quick passive recon |
| | SpiderFoot | Open Source | Automated OSINT, 200+ modules | Can be noisy, overwhelming output | Comprehensive OSINT automation |
| **Exploitation** | Metasploit | Open Source | Standard framework, huge module library | Well-signatured by EDR/AV | Learning, initial exploitation |
| | Cobalt Strike | Commercial | Industry-standard red team C2, malleable C2 profiles | Expensive, widely cracked/detected | Professional red teams |
| | Sliver | Open Source | Modern C2, multi-protocol, implant generation | Smaller community than CS, growing detections | Budget red teams, purple teams |
| | Mythic | Open Source | Modular C2, multi-agent, collaborative | Setup complexity, documentation gaps | Advanced red team operations |
| **Post-Exploitation** | Impacket | Open Source | AD attack Swiss army knife, protocol implementations | Python, can be brittle | AD exploitation, lateral movement |
| | Rubeus | Open Source | Kerberos abuse (roasting, delegation, tickets) | .NET, detected by mature EDR | AD Kerberos attacks |
| | BloodHound | Open Source | AD attack path visualization, graph-based | SharpHound collection detected | AD security assessment |
| | Certipy | Open Source | AD CS attack tool, ESC1-ESC13 | AD CS-specific | Certificate services attacks |
| **Post-Exploitation (Linux)** | LinPEAS | Open Source | Comprehensive Linux privesc enumeration | Noisy, easily detected | Linux privilege escalation |
| | pspy | Open Source | Process monitoring without root | Specific use case | Cron/process discovery |

### 3.5 Compliance

| Sub-Category | Tool | License | Strengths | Weaknesses | Best For |
|-------------|------|---------|-----------|------------|----------|
| **CSPM** | Prowler | Open Source | AWS/Azure/GCP, CIS benchmarks, CLI-native | Multi-cloud coverage varies | Cloud security posture |
| | ScoutSuite | Open Source | Multi-cloud, HTML report | Less actively maintained | Quick cloud audit |
| | Wiz | Commercial | Graph-based, agentless, risk prioritization | Expensive | Enterprise cloud security |
| | Orca Security | Commercial | Agentless, SideScanning, broad coverage | Pricing at scale | Agentless cloud security |
| **Benchmark** | CIS-CAT Pro | Commercial | Official CIS benchmark scanner | Per-target licensing | CIS compliance validation |
| | OpenSCAP | Open Source | SCAP-based, RHEL/CentOS focus | Limited non-RHEL support | Linux compliance scanning |
| | Lynis | Open Source | System hardening audit, Unix/Linux | Manual remediation | Linux hardening audit |
| | InSpec | Open Source | Compliance as code, readable DSL | Chef ecosystem | Automated compliance testing |
| **Audit** | Drata | Commercial | Continuous compliance monitoring, SOC 2 focused | SaaS-only | Startup SOC 2/ISO compliance |
| | Vanta | Commercial | Automated evidence collection, framework mapping | SaaS-only, similar to Drata | Continuous compliance |

---

## 4. Quick Reference Cards

### 4.1 Linux Hardening — Top 20 Commands

```bash
# 1. System updates
sudo apt update && sudo apt upgrade -y  # Debian/Ubuntu
sudo dnf update -y                       # RHEL/Fedora

# 2. Remove unnecessary packages
sudo apt autoremove --purge -y
dpkg --list | grep -i "telnet\|rsh\|nis\|tftp" | awk '{print $2}' | xargs sudo apt remove -y

# 3. Disable root SSH login
sudo sed -i 's/^#*PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sudo systemctl restart sshd

# 4. SSH hardening (key-only auth, restrict ciphers)
sudo cat >> /etc/ssh/sshd_config << 'SSHEOF'
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
ClientAliveInterval 300
ClientAliveCountMax 2
AllowUsers deployuser adminuser
Protocol 2
KexAlgorithms curve25519-sha256,curve25519-sha256@libssh.org
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com
MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com
SSHEOF
sudo systemctl restart sshd

# 5. Configure firewall (UFW example)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from 10.0.0.0/8 to any port 22
sudo ufw enable

# 6. Set password policy
sudo apt install libpam-pwquality -y
sudo sed -i 's/^# minlen.*/minlen = 14/' /etc/security/pwquality.conf
sudo sed -i 's/^# minclass.*/minclass = 3/' /etc/security/pwquality.conf

# 7. Enable audit logging
sudo apt install auditd -y
sudo systemctl enable auditd
# Key audit rules:
sudo auditctl -w /etc/passwd -p wa -k identity
sudo auditctl -w /etc/shadow -p wa -k identity
sudo auditctl -w /etc/sudoers -p wa -k sudoers_changes
sudo auditctl -a always,exit -F arch=b64 -S execve -k exec_commands

# 8. Set file permissions on critical files
sudo chmod 644 /etc/passwd
sudo chmod 000 /etc/shadow
sudo chmod 644 /etc/group
sudo chmod 000 /etc/gshadow
sudo chmod 600 /etc/ssh/sshd_config

# 9. Disable unused filesystems
echo "install cramfs /bin/true" | sudo tee /etc/modprobe.d/cramfs.conf
echo "install freevxfs /bin/true" | sudo tee /etc/modprobe.d/freevxfs.conf
echo "install udf /bin/true" | sudo tee /etc/modprobe.d/udf.conf
echo "install usb-storage /bin/true" | sudo tee /etc/modprobe.d/usb-storage.conf

# 10. Configure sysctl security parameters
sudo cat >> /etc/sysctl.d/99-security.conf << 'SYSEOF'
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.log_martians = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.tcp_syncookies = 1
kernel.randomize_va_space = 2
kernel.exec-shield = 1
fs.suid_dumpable = 0
SYSEOF
sudo sysctl -p /etc/sysctl.d/99-security.conf

# 11. Restrict cron access
sudo touch /etc/cron.allow
sudo chmod 600 /etc/cron.allow
echo "root" | sudo tee /etc/cron.allow
sudo rm -f /etc/cron.deny

# 12. Set UMASK
sudo sed -i 's/^UMASK.*/UMASK 027/' /etc/login.defs

# 13. Disable core dumps
echo "* hard core 0" | sudo tee -a /etc/security/limits.conf
echo "fs.suid_dumpable = 0" | sudo tee -a /etc/sysctl.conf

# 14. Find and remove SUID/SGID binaries (review output first)
find / -perm /4000 -type f 2>/dev/null  # List SUID
find / -perm /2000 -type f 2>/dev/null  # List SGID
# Remove SUID from unnecessary binaries:
sudo chmod u-s /usr/bin/newgrp  # Example

# 15. Configure fail2ban
sudo apt install fail2ban -y
sudo cat > /etc/fail2ban/jail.local << 'F2BEOF'
[sshd]
enabled = true
port = ssh
filter = sshd
maxretry = 3
bantime = 3600
findtime = 600
F2BEOF
sudo systemctl enable fail2ban && sudo systemctl start fail2ban

# 16. Enable process accounting
sudo apt install acct -y
sudo systemctl enable acct

# 17. Disable unnecessary services
for svc in avahi-daemon cups bluetooth rpcbind; do
  sudo systemctl stop "$svc" 2>/dev/null
  sudo systemctl disable "$svc" 2>/dev/null
  sudo systemctl mask "$svc" 2>/dev/null
done

# 18. Configure NTP (time sync is security-critical for log correlation)
sudo timedatectl set-ntp true
sudo apt install chrony -y
sudo systemctl enable chronyd

# 19. Set login banner (legal notice)
echo "Authorized access only. All activity is monitored and logged." | sudo tee /etc/issue.net
sudo sed -i 's/^#Banner.*/Banner \/etc\/issue.net/' /etc/ssh/sshd_config

# 20. Run Lynis audit (validate hardening)
sudo apt install lynis -y
sudo lynis audit system --quick
```

### 4.2 Windows Hardening — Top 20 GPO Settings

| # | GPO Path | Setting | Value | CIS Control |
|---|---------|---------|-------|-------------|
| 1 | Computer > Policies > Windows Settings > Security Settings > Account Policies > Password Policy | Minimum password length | 14 characters | 5.2 |
| 2 | Computer > Policies > Windows Settings > Security Settings > Account Policies > Account Lockout Policy | Account lockout threshold | 5 invalid attempts | 5.2 |
| 3 | Computer > Policies > Windows Settings > Security Settings > Account Policies > Account Lockout Policy | Account lockout duration | 15 minutes | 5.2 |
| 4 | Computer > Policies > Windows Settings > Security Settings > Local Policies > Audit Policy | Audit logon events | Success, Failure | 8.5 |
| 5 | Computer > Policies > Admin Templates > Windows Components > Windows PowerShell | Turn on Script Block Logging | Enabled | 8.8 |
| 6 | Computer > Policies > Admin Templates > Windows Components > Windows PowerShell | Turn on PowerShell Transcription | Enabled | 8.8 |
| 7 | Computer > Policies > Windows Settings > Security Settings > Advanced Audit Policy > Detailed Tracking | Audit Process Creation | Success | 8.5 |
| 8 | Computer > Policies > Admin Templates > System > Audit Process Creation | Include command line in process creation events | Enabled | 8.5 |
| 9 | Computer > Policies > Admin Templates > MS Security Guide | Configure SMBv1 client/server | Disabled | 9.3 |
| 10 | Computer > Policies > Windows Settings > Security Settings > Local Policies > Security Options | Network access: Restrict anonymous access to Named Pipes and Shares | Enabled | 9.3 |
| 11 | Computer > Policies > Windows Settings > Security Settings > Local Policies > User Rights Assignment | Deny log on through Remote Desktop Services | Guests, Local account (non-admin) | 5.4 |
| 12 | Computer > Policies > Windows Settings > Security Settings > Local Policies > User Rights Assignment | Deny access to this computer from the network | Guests, Local account | 5.4 |
| 13 | Computer > Policies > Admin Templates > Network > Lanman Workstation | Enable insecure guest logons | Disabled | 9.3 |
| 14 | Computer > Policies > Admin Templates > Windows Components > Remote Desktop Services > RD Session Host > Security | Require use of specific security layer for RDP connections | SSL/TLS | 9.3 |
| 15 | Computer > Policies > Admin Templates > Windows Components > Remote Desktop Services > RD Session Host > Security | Set client connection encryption level | High Level | 9.3 |
| 16 | Computer > Policies > Admin Templates > Windows Components > Remote Desktop Services > RD Session Host > Security | Require NLA for Remote Desktop | Enabled | 9.3 |
| 17 | Computer > Policies > Admin Templates > Windows Components > Windows Defender Firewall > Domain Profile | Windows Defender Firewall: Protect all network connections | Enabled | 9.2 |
| 18 | Computer > Policies > Admin Templates > System > Credentials Delegation | Encryption Oracle Remediation | Force Updated Clients | 5.2 |
| 19 | Computer > Policies > Windows Settings > Security Settings > Local Policies > Security Options | User Account Control: Run all administrators in Admin Approval Mode | Enabled | 5.4 |
| 20 | Computer > Policies > Admin Templates > Windows Components > Credential User Interface | Enumerate administrator accounts on elevation | Disabled | 5.4 |

**Additional critical registry settings (deploy via GPO Preferences):**

| Setting | Registry Path | Value |
|---------|--------------|-------|
| Disable WDigest cleartext creds | `HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest\UseLogonCredential` | 0 |
| Enable LSA Protection | `HKLM\SYSTEM\CurrentControlSet\Control\Lsa\RunAsPPL` | 1 |
| Disable LLMNR | `HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient\EnableMulticast` | 0 |
| Disable NetBIOS over TCP/IP | Per-adapter: `HKLM\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces\*\NetbiosOptions` | 2 |
| Disable WPAD | `HKLM\SYSTEM\CurrentControlSet\Services\WinHttpAutoProxySvc\Start` | 4 |
| Enable Credential Guard | `HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\EnableVirtualizationBasedSecurity` | 1 |

### 4.3 AWS Security — Top 20 Controls

| # | Control | Service/Feature | Implementation | CIS AWS Benchmark |
|---|---------|----------------|----------------|-------------------|
| 1 | Enable CloudTrail in all regions | CloudTrail | Multi-region trail, S3 bucket with object lock, log file validation enabled | 3.1 |
| 2 | Enable MFA on root account | IAM | Hardware MFA token (YubiKey preferred), no root access keys | 1.5, 1.6 |
| 3 | No root access keys | IAM | `aws iam delete-access-key --user-name root --access-key-id <key>` | 1.4 |
| 4 | Enable GuardDuty | GuardDuty | All regions, S3 protection, EKS protection, Malware protection | 4.16 |
| 5 | Enable Security Hub | Security Hub | CIS AWS Foundations + AWS Foundational Security standards | — |
| 6 | S3 Block Public Access (account-level) | S3 | `aws s3control put-public-access-block --account-id <id> --public-access-block-configuration BlockPublic*=true` | 2.1.5 |
| 7 | Encrypt EBS volumes by default | EC2 | `aws ec2 enable-ebs-encryption-by-default` per region | 2.2.1 |
| 8 | Enable VPC Flow Logs | VPC | All VPCs, send to CloudWatch Logs or S3 | 3.9 |
| 9 | Restrict Security Group ingress | VPC | No 0.0.0.0/0 on management ports (22, 3389), no wide-open SGs | 5.2, 5.3 |
| 10 | Use IAM roles, not access keys | IAM | Instance profiles for EC2, task roles for ECS, IRSA for EKS | 1.16 |
| 11 | Enforce MFA for IAM users | IAM | IAM policy condition: `aws:MultiFactorAuthPresent` | 1.10 |
| 12 | Enable AWS Config | Config | All regions, record all resource types | 3.5 |
| 13 | Enable RDS encryption | RDS | Encryption at rest enabled on creation (cannot enable after) | 2.3.1 |
| 14 | Rotate access keys < 90 days | IAM | Config Rule: `access-keys-rotated`, maxAccessKeyAge: 90 | 1.14 |
| 15 | Use AWS Organizations + SCPs | Organizations | Deny actions: leave org, disable CloudTrail, disable GuardDuty | — |
| 16 | Enable S3 bucket logging | S3 | Server access logging or CloudTrail data events for sensitive buckets | 2.1.3 |
| 17 | Use KMS CMK for encryption | KMS | Key rotation enabled, key policy with least privilege | 2.8 |
| 18 | Enable IMDSv2 (require token) | EC2 | `aws ec2 modify-instance-metadata-options --http-tokens required` | 5.6 |
| 19 | Use SSM Session Manager instead of SSH | Systems Manager | No SSH keys, audit trail, no open port 22 | — |
| 20 | Enable AWS Backup | Backup | Automated backups with cross-region copy, test restores quarterly | — |

**Quick validation commands:**
```bash
# Check CloudTrail status
aws cloudtrail describe-trails --query 'trailList[*].[Name,IsMultiRegionTrail,LogFileValidationEnabled]'

# Find public S3 buckets
aws s3api list-buckets --query 'Buckets[].Name' --output text | \
  xargs -I{} aws s3api get-public-access-block --bucket {} 2>/dev/null

# Find security groups with 0.0.0.0/0
aws ec2 describe-security-groups --filters "Name=ip-permission.cidr,Values=0.0.0.0/0" \
  --query 'SecurityGroups[*].[GroupId,GroupName]'

# Check for IAM users without MFA
aws iam generate-credential-report && sleep 5 && \
aws iam get-credential-report --query 'Content' --output text | \
  base64 -d | awk -F, '$4=="true" && $8=="false" {print $1" - MFA NOT ENABLED"}'

# Check IMDSv2 enforcement
aws ec2 describe-instances --query 'Reservations[].Instances[].[InstanceId,MetadataOptions.HttpTokens]' --output table
```

### 4.4 Incident Response — First 30 Minutes

```
MINUTE 0-5: INITIAL TRIAGE
===========================
[ ] Who reported? How? When did they notice?
[ ] What is the suspected incident type?
    ( ) Malware/Ransomware  ( ) Phishing/BEC  ( ) Unauthorized access
    ( ) Data exfiltration   ( ) Insider threat ( ) DDoS
    ( ) Supply chain        ( ) Other: ___________
[ ] Severity assessment:
    SEV-1: Active data breach, ransomware spreading, safety risk
    SEV-2: Confirmed compromise, contained scope
    SEV-3: Suspicious activity, unconfirmed compromise
    SEV-4: Policy violation, minor security event
[ ] Activate IR team (SEV-1/2: immediate, SEV-3: business hours)
[ ] Start incident log (timestamp EVERYTHING from this point)

MINUTE 5-10: SCOPE ASSESSMENT
==============================
[ ] Identify affected systems (hostname, IP, user, service)
[ ] Determine blast radius: what can the attacker reach from here?
[ ] Check: is the attack still active? (ongoing exfil, lateral movement)
[ ] Review relevant alerts in SIEM (last 24-72 hours for affected systems)
[ ] Check EDR console for affected endpoints
[ ] Document IOCs observed so far:
    - IPs/Domains: ___________
    - File hashes: ___________
    - User accounts: ___________
    - Process names: ___________

MINUTE 10-15: EVIDENCE PRESERVATION
=====================================
[ ] DO NOT reboot affected systems (destroys memory evidence)
[ ] DO NOT run AV scans yet (overwrites artifacts)
[ ] Capture volatile evidence FIRST:
    - Memory dump (WinPmem, LiME, or Velociraptor memory artifact)
    - Running processes, network connections, logged-in users
    - Clipboard contents, command history
[ ] Disk image (if feasible) or triage collection (KAPE, Velociraptor)
[ ] Preserve relevant logs:
    - Security/System event logs
    - PowerShell/WMI logs
    - Web server logs
    - Authentication logs
    - Firewall/proxy logs
[ ] Screenshot any visible attacker activity

MINUTE 15-20: CONTAINMENT DECISION
====================================
[ ] Containment strategy (choose based on situation):
    NETWORK:
    [ ] Isolate host from network (EDR network isolation preferred)
    [ ] Block IOC IPs/domains at firewall/proxy
    [ ] Disable compromised VPN/remote access accounts
    IDENTITY:
    [ ] Reset compromised credentials (user + service accounts)
    [ ] Revoke active sessions/tokens
    [ ] Disable compromised accounts (if business allows)
    ENDPOINT:
    [ ] EDR isolation (maintains remote investigation access)
    [ ] Disable network adapter (last resort, loses remote access)
    NOTE: Do NOT wipe systems until evidence is preserved

MINUTE 20-25: INITIAL INVESTIGATION
=====================================
[ ] Timeline: what was the first malicious activity? (patient zero)
[ ] Entry vector: how did attacker get in?
    - Email (check email gateway logs)
    - Exploit (check WAF/IDS, vulnerability scan data)
    - Credentials (check auth logs, dark web exposure)
    - Supply chain (check recent software updates)
[ ] Lateral movement: did attacker move to other systems?
    - Check 4624 Type 3/10 from compromised host
    - Check for psexec/wmi/winrm activity
    - Check admin share access (5140/5145)
[ ] Persistence: did attacker establish persistence?
    - Scheduled tasks, services, registry run keys
    - New user accounts, modified groups
    - Web shells, backdoors

MINUTE 25-30: COMMUNICATION & ESCALATION
==========================================
[ ] Update incident log with all findings
[ ] Notify stakeholders per IR plan:
    SEV-1: CISO, Legal, Comms, Executive leadership
    SEV-2: CISO, IT management, affected business units
    SEV-3: Security management
[ ] Legal hold notice if data breach suspected
[ ] Regulatory notification clock check:
    - GDPR: 72 hours from awareness (Art. 33)
    - HIPAA: 60 days
    - SEC: 4 business days (material incidents)
    - State breach laws: varies (check applicable)
[ ] Document: what do we know, what don't we know, what are we doing next
[ ] Set next check-in time (SEV-1: every 1hr, SEV-2: every 4hr)

POST-30 MINUTES: ONGOING
=========================
[ ] Continue evidence collection and analysis
[ ] Expand containment as scope clarifies
[ ] Begin eradication planning (do NOT eradicate before full scope known)
[ ] Prepare external notification (customers, regulators) if needed
[ ] Engage external IR firm if scope exceeds internal capability
```

### 4.5 Threat Hunting — Daily Checklist

```
DAILY THREAT HUNTING CHECKLIST
===============================
Time: ___  Analyst: ___  Date: ___

AUTHENTICATION ANOMALIES (15 min)
----------------------------------
[ ] Failed login spikes (>10 failures in 5min per account)
    KQL: SigninLogs | where ResultType != 0 | summarize count() by UserPrincipalName, bin(TimeGenerated, 5m) | where count_ > 10
    SPL: index=auth action=failure | stats count by user _time span=5m | where count>10

[ ] Logins from new locations/IPs for privileged accounts
    KQL: SigninLogs | where UserPrincipalName in (privileged_users) | where Location !in (known_locations)

[ ] Impossible travel (same user, different geo, <impossible time)
    KQL: SigninLogs | where RiskEventTypes has "impossibleTravel"

[ ] Off-hours authentication (define business hours per region)
    SPL: index=auth action=success date_hour<6 OR date_hour>22 | stats count by user, src_ip

[ ] Service account interactive logons (should be non-interactive only)
    KQL: SecurityEvent | where EventID == 4624 and LogonType in (2,10) and TargetUserName matches regex @"^svc_"

PROCESS & EXECUTION ANOMALIES (15 min)
----------------------------------------
[ ] LOLBin execution from unusual parents
    Look for: certutil, mshta, regsvr32, rundll32, msbuild
    KQL: DeviceProcessEvents | where FileName in ("certutil.exe","mshta.exe","regsvr32.exe") and InitiatingProcessFileName !in ("explorer.exe","cmd.exe")

[ ] Encoded PowerShell commands
    KQL: DeviceProcessEvents | where FileName == "powershell.exe" and ProcessCommandLine has_any("-enc","-e ","-encodedcommand")

[ ] Processes spawned by Office applications
    KQL: DeviceProcessEvents | where InitiatingProcessFileName in ("winword.exe","excel.exe","outlook.exe") and FileName in ("cmd.exe","powershell.exe","wscript.exe","mshta.exe")

[ ] Scheduled task creation (especially by non-admin)
    KQL: SecurityEvent | where EventID == 4698

[ ] New services installed
    KQL: SecurityEvent | where EventID == 7045

NETWORK ANOMALIES (15 min)
---------------------------
[ ] DNS query volume spikes per host
    KQL: DnsEvents | summarize QueryCount=count() by ClientIP, bin(TimeGenerated, 1h) | where QueryCount > 1000

[ ] Long DNS queries (>50 chars) — potential DNS tunneling
    KQL: DnsEvents | where strlen(Name) > 50

[ ] Connections to newly registered domains (<30 days old)
    Check against threat intel feed or WHOIS data

[ ] Beaconing detection (regular interval connections)
    SPL: index=proxy | stats count, stdev(eval(relative_time(_time, "@h"))) as jitter by dest_domain, src_ip | where count>50 AND jitter<60

[ ] Large outbound transfers (>100MB to single destination)
    KQL: DeviceNetworkEvents | summarize TotalBytes=sum(SentBytes) by DeviceName, RemoteIP | where TotalBytes > 104857600

[ ] Connections to known-bad TOR exit nodes
    Cross-reference with TOR exit node list

PERSISTENCE CHECKS (10 min)
-----------------------------
[ ] New registry run key entries (last 24h)
    KQL: DeviceRegistryEvents | where RegistryKey has_any("\\Run","\\RunOnce") and ActionType == "RegistryValueSet" and Timestamp > ago(24h)

[ ] New startup folder items
    KQL: DeviceFileEvents | where FolderPath has "\\Start Menu\\Programs\\Startup" and Timestamp > ago(24h)

[ ] WMI event subscriptions created
    KQL: DeviceEvents | where ActionType == "WmiBindingEvent" and Timestamp > ago(24h)

[ ] New user accounts created
    KQL: SecurityEvent | where EventID == 4720 and TimeGenerated > ago(24h)

[ ] Changes to Group Policy
    KQL: SecurityEvent | where EventID in (4739, 5136, 5137) and TimeGenerated > ago(24h)

CREDENTIAL ACCESS (5 min)
--------------------------
[ ] LSASS access from unusual processes
    KQL: DeviceProcessEvents | where ActionType == "OpenProcess" and FileName == "lsass.exe" and InitiatingProcessFileName !in ("svchost.exe","csrss.exe","wininit.exe","lsaiso.exe")

[ ] Kerberoasting indicators (RC4 TGS requests)
    KQL: SecurityEvent | where EventID == 4769 and TicketEncryptionType == "0x17" and ServiceName !endswith "$"

[ ] Password spray patterns (many users, few attempts each)
    KQL: SecurityEvent | where EventID == 4625 | summarize UserCount=dcount(TargetUserName) by IpAddress, bin(TimeGenerated, 10m) | where UserCount > 10

CLOUD-SPECIFIC (if applicable, 10 min)
----------------------------------------
[ ] Console logins without MFA
    KQL: AuditLogs | where OperationName == "User login" and AuthenticationRequirement != "multiFactorAuthentication"

[ ] IAM policy changes / new access keys created
    AWS: CloudTrail events: CreateAccessKey, PutUserPolicy, AttachUserPolicy, CreateRole
    KQL: AWSCloudTrail | where EventName in ("CreateAccessKey","AttachUserPolicy","CreateRole")

[ ] S3/Blob/GCS public access changes
    AWS: CloudTrail event: PutBucketPolicy, PutBucketAcl
    KQL: AWSCloudTrail | where EventName in ("PutBucketPolicy","PutBucketAcl","PutPublicAccessBlock")

[ ] Unusual API calls from new IPs
    KQL: AWSCloudTrail | summarize FirstSeen=min(TimeGenerated) by SourceIpAddress | where FirstSeen > ago(24h)

DOCUMENTATION (5 min)
----------------------
[ ] Log any findings in hunting journal
[ ] Update detection rules if new patterns found
[ ] Submit IOCs to threat intel platform
[ ] Report any confirmed findings to SOC for triage
[ ] Note hypotheses for tomorrow's hunt

Total estimated time: ~60-70 minutes
Recommended cadence: Daily (weekdays), abbreviated on weekends
```

---

## Appendix: Log Source Priority Matrix

When building a detection program from scratch, enable log sources in this order for maximum coverage per effort:

| Priority | Log Source | Techniques Covered | Effort |
|----------|-----------|-------------------|--------|
| 1 | Windows Security Log (with command-line auditing) | 35+ of top 50 | Low |
| 2 | Sysmon (SwiftOnSecurity config) | 40+ of top 50 | Low |
| 3 | PowerShell Script Block Logging (4104) | All PowerShell-based TTPs | Low |
| 4 | Firewall/proxy logs | Network-based TTPs, exfiltration, C2 | Medium |
| 5 | DNS query logging | DNS tunneling, DGA, C2 | Low |
| 6 | Cloud audit logs (CloudTrail, Entra, etc.) | Cloud-specific TTPs | Low |
| 7 | Email gateway logs | Initial access (phishing) | Medium |
| 8 | EDR telemetry | Process injection, in-memory attacks | Medium |
| 9 | IDS/IPS (Suricata, Snort) | Network exploitation, known signatures | Medium |
| 10 | DLP/CASB | Exfiltration, data access anomalies | High |

---

*End of synthesis document. Keep this reference alongside MITRE ATT&CK Navigator and your SIEM query library for operational use.*
