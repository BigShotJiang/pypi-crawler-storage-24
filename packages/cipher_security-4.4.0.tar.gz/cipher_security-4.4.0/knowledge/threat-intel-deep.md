<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Threat Intelligence Deep Training
## CIPHER Knowledge Base — Current Threat Landscape, Ransomware TTPs, Attack Chains, IOC Sharing & CTI Methodology
### Last Updated: 2026-03-14

---

## 1. Current Threat Landscape Overview

### 1.1 Scale of the Problem (2026)
- **CISA KEV Catalog**: 1,542 known exploited vulnerabilities actively tracked
- **Ransomware Groups Monitored**: 549 active groups tracked by RansomLook
- **Ransomware Posts (90 days)**: ~2,930 victim posts; ~29,593 total historical
- **Dark Leak Sites**: 731 active DLS endpoints across ransomware ecosystem
- **MITRE ATT&CK Groups**: 176 tracked threat actor groups globally
- **Active Ransomware Infrastructure**: 701 operational relays, 305 chat channels, 141 dark markets

### 1.2 Recent Critical Vulnerabilities (CISA KEV — March 2026)

| CVE | Product | Type | Severity |
|-----|---------|------|----------|
| CVE-2026-3909 | Google Skia (Chrome/Android) | Out-of-bounds write | Critical |
| CVE-2026-3910 | Chromium V8 | Memory buffer boundary violation / sandbox escape | Critical |
| CVE-2026-20127 | Cisco SD-WAN | Authentication bypass (unauthenticated admin access) | Critical |
| CVE-2026-22769 | Dell RecoverPoint | Hard-coded credentials (root persistence) | Critical |
| CVE-2023-46604 | Apache ActiveMQ | RCE via ClassPathXmlApplicationContext | Critical |

### 1.3 CISA Shields Up — Standing Defensive Posture
Key directives for all organizations:
- Adopt heightened cybersecurity posture for critical assets
- Deploy MFA universally; enforce strong password policies
- Monitor for exploitation of KEV-listed vulnerabilities
- Establish and test incident response procedures
- Executive/CEO-level accountability for security posture
- Do NOT pay ransom — it does not guarantee decryption and funds criminal operations
- Report anomalous activity to CISA (report@cisa.gov / 1-844-Say-CISA)

---

## 2. Threat Actor Profiles

### 2.1 Nation-State APT Groups (Major)

#### Russia
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| APT28 (G0007) | Fancy Bear, Sofacy, Forest Blizzard | GRU (Unit 26165) | Government, military, media, elections |
| APT29 (G0016) | Cozy Bear, NOBELIUM, Midnight Blizzard | SVR | Government, diplomatic, think tanks |
| Sandworm (G0034) | ELECTRUM, Voodoo Bear, APT44 | GRU (Unit 74455) | Critical infrastructure, destructive attacks (NotPetya, Industroyer) |
| Gamaredon (G0047) | Primitive Bear, Armageddon | FSB | Ukraine government and military |
| Ember Bear (G1003) | Saint Bear, UAC-0056 | GRU | Government, Ukraine-focused |

#### China
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| APT1 (G0006) | Comment Crew | PLA Unit 61398 | Multiple sectors, IP theft |
| APT41 (G0096) | Wicked Panda, Brass Typhoon | MSS + Cybercrime dual-hat | Technology, healthcare, gaming |
| Volt Typhoon (G1017) | BRONZE SILHOUETTE | PRC state | US critical infrastructure, living-off-the-land |
| Salt Typhoon (G1045) | PRC state-backed | PRC state | Telecom/ISP infrastructure |
| APT40/Leviathan (G0065) | MUDCARP, Gingham Typhoon | MSS (Hainan) | Aerospace, maritime, defense |
| Mustang Panda (G0129) | RedDelta, BRONZE PRESIDENT | PRC state | Government, NGOs, Southeast Asia |
| UAT-9244 | Associated with Famous Sparrow | China-nexus | South American telecommunications |

#### Iran
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| APT33 (G0064) | Elfin, Peach Sandstorm | IRGC | Energy, aerospace, aviation |
| APT34/OilRig (G0049) | EUROPIUM, Hazel Sandstorm | MOIS | Energy, financial, government |
| MuddyWater (G0069) | MERCURY, Static Kitten | MOIS | Government entities (Operation Olalampo — 2026) |
| APT39 (G0087) | Chafer, Remix Kitten | MOIS | Travel, telecommunications |
| Handala Hack | Void Manticore | Iran-linked | Wiper attacks, IP camera exploitation, Middle East targets |

#### North Korea
| Group | Aliases | Affiliation | Primary Targets |
|-------|---------|-------------|-----------------|
| Lazarus Group (G0032) | HIDDEN COBRA, Diamond Sleet | RGB | Financial theft, destructive attacks |
| APT38 (G0082) | BeagleBoyz, Sapphire Sleet | RGB | SWIFT/banking systems, cryptocurrency |
| Kimsuky (G0094) | Black Banshee, Emerald Sleet | RGB | Espionage, academics, policy |
| APT37 (G0067) | ScarCruft, Reaper, Ricochet Chollima | RGB | South Korea, dissidents |
| Moonstone Sleet (G1036) | Storm-1789 | RGB | Financial and espionage dual-purpose |

#### Other
| Group | Country | Focus |
|-------|---------|-------|
| APT32/OceanLotus (G0050) | Vietnam | Regional espionage, dissidents |
| Silver Dragon | Unknown | Southeast Asia and Europe multi-region campaigns |
| CL-STA-1087 | China-suspected | Southeast Asian military espionage (2026) |
| CL-UNK-1068 | Unknown | Prolonged undetected operations, DLL sideloading, high-value sectors |

### 2.2 Cybercrime & Ransomware Groups

#### Major Ransomware Operations (Active 2025-2026)
| Group | Ransomware | RaaS Model | Notable TTPs |
|-------|------------|------------|--------------|
| LockBit | LockBit 3.0 (leaked builder) | Yes (RaaS) | Leaked builder enables independent operators; SMB spreader (-psex); Session messenger for negotiation |
| Akira | Akira | Yes (RaaS) | Malvertising via search engines; Bumblebee loader; AdaptixC2; targets local + network + remote dirs |
| Lynx | Lynx/Playcrypt variant | Emerging | RDP initial access; fast encryption mode (5%); SoftPerfect NetScan; temp.sh exfil |
| Play (G1040) | Playcrypt | Yes | Interconnected with DragonForce and RansomHub operations |
| DragonForce | DragonForce | Yes | Cross-group collaboration with Play and RansomHub |
| RansomHub | RansomHub | Yes (RaaS) | Interconnected ecosystem with multiple affiliates |
| BlackByte (G1043) | BlackByte 1.0/2.0 | Yes | Living-off-the-land, driver exploitation |
| Medusa (G1051) | Medusa | Yes (RaaS) | Double extortion, DLS |

#### Financial Cybercrime Groups
| Group | Focus | Notable Activity |
|-------|-------|-----------------|
| FIN7 (G0046) / Carbon Spider | Retail/hospitality POS | Evolved to ransomware operations |
| Indrik Spider (G0119) / Evil Corp | Banking trojans | Dridex -> BitPaymer -> WastedLocker -> sanctions evasion |
| Lunar Spider | Initial access brokerage | Latrodectus loader, sells access to ransomware affiliates |
| TA505 (G0092) | Mass phishing | Clop ransomware, MOVEit exploitation |
| LAPSUS$ (G1004) | Extortion | Social engineering, SIM swapping, no encryption |
| Scattered Spider | Identity attacks | Help desk social engineering, Okta targeting |

### 2.3 Vendor Naming Cross-Reference

| Microsoft | CrowdStrike | Mandiant/Google | MITRE |
|-----------|-------------|-----------------|-------|
| Forest Blizzard | Fancy Bear | APT28 | G0007 |
| Midnight Blizzard | Cozy Bear | APT29 | G0016 |
| Brass Typhoon | Wicked Panda | APT41 | G0096 |
| Peach Sandstorm | Elfin | APT33 | G0064 |
| Diamond Sleet | Lazarus | Lazarus Group | G0032 |
| Sangria Tempest | Carbon Spider | FIN7 | G0046 |
| Manatee Tempest | Indrik Spider | Evil Corp | G0119 |

---

## 3. Real-World Attack Chains from DFIR Reports

### 3.1 Apache ActiveMQ -> LockBit Ransomware (Feb 2026)

**Timeline**: 419 hours (~19 days) from initial access to ransomware deployment

```
INITIAL ACCESS (Day 1)
  CVE-2023-46604 exploitation on internet-facing ActiveMQ
  → ClassPathXmlApplicationContext loads malicious XML
  → CertUtil downloads payloads
    ↓
EXECUTION & C2
  Metasploit stager (uFSyLszKsuR.exe) → process injection → shellcode
  C2: 166.62.100[.]52:2460
    ↓
PERSISTENCE
  AnyDesk installed as AutoStart service
  Same C2 IP used for AnyDesk login (Client ID: 1312001388)
    ↓
PRIVILEGE ESCALATION
  Meterpreter getsystem (named pipe impersonation)
  Service "kesknq": cmd.exe /c echo kesknq > \\.\pipe\kesknq
    ↓
CREDENTIAL ACCESS
  LSASS memory dump (GrantedAccess 0x1010)
  Domain admin + service account credentials extracted
    ↓
DISCOVERY
  Advanced IP Scanner (renamed), netscan.exe
  Port scan: 445, 3389, 22 prioritized
    ↓
LATERAL MOVEMENT
  Round 1: Remote service execution via Metasploit (partially blocked by AV)
  Round 2: RDP with stolen service account credentials
    ↓
DEFENSE EVASION
  Event log clearing (IDs 104, 1102)
  SystemSettingsAdminFlows.exe → Defender disabling (LOLBIN)
  Obfuscated PowerShell (Base64/Gzip)
  RDP config via batch file
    ↓
IMPACT (Day 18)
  LockBit 3.0 (leaked builder variant)
  Flags: -psex (SMB spreader) + custom path/password
  Ransom notes → Session messenger (not standard Tor/Jabber)
  Indicates independent operator using leaked builder
```

**Key IOCs**: C2 166.62.100[.]52 | LB3_pass.exe SHA256: C8646CFB574FF2C6F183C3C3951BF6B2C6CF16FF8A5E949A118BE27F15962FAE

**Detection Opportunities**: CertUtil downloading executables, named pipe creation matching Meterpreter patterns, AnyDesk service installation, Advanced IP Scanner renamed binaries, LSASS access with 0x1010, event log clearing.

---

### 3.2 Bing Search Malvertising -> Bumblebee -> AdaptixC2 -> Akira (Nov 2025)

**Timeline**: 44 hours from initial access to ransomware

```
INITIAL ACCESS
  SEO poisoning: "ManageEngine OpManager" search on Bing
  → Redirect to opmanager[.]pro
  → Trojanized MSI installer (ManageEngine-OpManager.msi)
    ↓
LOADER EXECUTION
  MSI loads Bumblebee (msimg32.dll) via consent.exe DLL sideloading
  Bumblebee C2: 109.205.195[.]211:443, 188.40.187[.]145:443
  DGA domains: ev2sirbd269o5j.org, 2rxyt9urhq0bgj.org
    ↓
SECOND-STAGE C2 (~5 hours)
  AdaptixC2 beacon (AdgNsy.exe)
  C2: 172.96.137[.]160:443
    ↓
DISCOVERY
  systeminfo, nltest /dclist:, whoami /groups
  net group "domain admins" /dom
    ↓
PERSISTENCE & PRIVESC
  Created accounts: backup_DA, backup_EA
  backup_EA → Enterprise Administrators group
  Domain controller access via RDP
    ↓
LATERAL MOVEMENT
  RustDesk remote access deployed across hosts
  SSH reverse tunnel: ssh root@<IP> -R *:10400 -p22
    ↓
CREDENTIAL HARVESTING
  NTDS.dit dump via wbadmin backup
  Veeam PostgreSQL credential extraction (psql.exe)
  LSASS dump via rundll32.exe comsvcs.dll
    ↓
EXFILTRATION
  FileZilla → SFTP to 185.174.100[.]203
    ↓
RANSOMWARE (44 hours)
  Akira locker.exe targeting local drives + network shares + remote dirs
```

**Key IOCs**: Bumblebee SHA256: a6df0b49a5ef9ffd6513bfe061fb60f6d2941a440038e2de8a7aeb1914945331 | Akira SHA256: de730d969854c3697fd0e0803826b4222f3a14efe47e4c60ed749fff6edce19d

**Detection Opportunities**: MSI sideloading consent.exe, DGA domain resolution, wbadmin NTDS backup, comsvcs.dll MiniDump, Enterprise Admin group additions, SSH reverse tunnels, RustDesk installation.

---

### 3.3 Lynx Ransomware via RDP (Dec 2025)

**Timeline**: ~178 hours (9 days)

```
INITIAL ACCESS
  RDP with pre-obtained valid credentials (likely infostealer/IAB)
  Source: 195.211.190[.]189 (Railnet LLC/Virtualine — bulletproof hosting)
  No brute force — clean credential use
    ↓
DISCOVERY
  SoftPerfect NetScan v7.2.7 (paid license)
  NetExec (nxc.exe) for SMB enumeration
  Share write tests (delete.me files)
  Results exported to ss.xml
    ↓
PERSISTENCE
  Three domain accounts created: "administratr", "Lookalike 1", "Lookalike 2"
  → Added to Domain Admins + Group Policy Creator Owners
  → Non-expiring passwords
  AnyDesk installed (unused)
    ↓
LATERAL MOVEMENT
  RDP: Beachhead → DC → Hypervisors → Backup servers → File servers
  Using compromised + newly created domain admin accounts
  Hostname: DESKTOP-BUL6K1U
  Second IP: 77.90.153[.]30 (also bulletproof hosting)
    ↓
COLLECTION & EXFILTRATION
  7-Zip compression of network shares
  Upload to temp.sh (temporary file-sharing service)
    ↓
IMPACT (Day 9)
  Lynx ransomware (w.exe)
  --mode fast (5% file encryption)
  --noprint (no printer ransom notes)
  Veeam backup jobs deleted before encryption
```

**Key IOCs**: Lynx SHA256: 07b36c1660deb223749a8ac151676d8924bc13aa59e6712a3c14a2df5237264a | C2 IPs: 195.211.190[.]189, 77.90.153[.]30

**Detection Opportunities**: Account creation with typo names (evasion attempt), Domain Admin additions, NetExec/nxc.exe execution, 7-Zip archiving of share data, temp.sh uploads, Veeam backup deletion.

---

### 3.4 Lunar Spider — Latrodectus + BruteRatel + Cobalt Strike (Sep 2025)

**Timeline**: ~56 days (near two-month dwell time, NO ransomware deployed)

```
INITIAL ACCESS
  Malicious JavaScript masquerading as tax form (W-9)
  Heavily obfuscated with filler content
    ↓
EXECUTION CHAIN
  JS → HTTP request for MSI installer (91.194.11[.]64/MSI.msi)
  → MSI extracts upfilles.dll in disk1.cab
  → rundll32.exe invokes export "stow"
  → Custom API hashing → XOR → RC4 decryption
  → Brute Ratel Badger deployed
    ↓
PROCESS INJECTION
  BruteRatel → injects Latrodectus into explorer.exe via CreateRemoteThread
    ↓
C2 INFRASTRUCTURE (Multi-layer)
  Latrodectus C2 (CloudFlare-proxied): workspacin.cloud, illoskanawer.com, etc.
  BackConnect: 193.168.143.196, 185.93.221.12
  BruteRatel C2: anikvan.com, altynbe.com (PQ Hosting, Akamai, AWS Tyk.io)
  Cobalt Strike: avtechupdate.com:443, 45.129.199.214:80/8080
    ↓
CREDENTIAL ACCESS
  Latrodectus stealer module → 29+ Chromium browsers, Firefox, Outlook
  unattend.xml with plaintext domain admin credentials (left from deployment)
  LSASS access (0x1010 → 0x1fffff)
  Veeam credential dump (Veeam-Get-Creds.ps1)
    ↓
PERSISTENCE
  Registry Run Key (Update → upfilles.dll → wscadminui.dll)
  Scheduled Task "SchedulerLsass" → lsassa.exe on startup
    ↓
LATERAL MOVEMENT
  PsExec → Cobalt Strike system.dl_ to DC, file share, backup server
  Zerologon exploit (CVE-2020-1472) via zero.exe against second DC
  RDP with stolen domain admin creds (hostname leak: VPS2DAY-32220LE)
    ↓
DISCOVERY
  AdFind (users, computers, OUs, subnets, trusts)
  dsquery, nltest, Invoke-ShareFinder
  rustscan scanning /16 and /8 CIDR blocks on port 445
    ↓
DEFENSE EVASION
  Process injection into: explorer.exe, sihost.exe, spoolsv.exe, gpupdate.exe
  UAC bypass via ms-settings protocol hijacking + token duplication
  File deletion of >50% of tools post-use
    ↓
EXFILTRATION
  Rclone (renamed to sihosts.exe) via VBScript launcher
  FTP destination: 45.135.232.3
  Exfil duration: 9 hours 46 minutes
  Config excluded: .dll, .exe, .log, .cab, etc.
    ↓
NO RANSOMWARE DEPLOYED (despite full domain compromise)
```

**Key Insight**: Lunar Spider operates as an **initial access broker (IAB)** — they compromise, persist, exfiltrate, then hand off (or sell) access to ransomware operators. The absence of ransomware in a 56-day intrusion with full domain admin access is the signature of IAB activity.

**Detection Opportunities**: JS executing MSI downloads, rundll32 loading DLLs from user temp, BruteRatel API hashing patterns, AdFind enumeration, Zerologon exploitation (Netlogon anomalies), Rclone renamed binary, scheduled task with LSASS-like names.

---

### 3.5 DragonForce/Play/RansomHub Interconnection (Sep 2025)

Three major ransomware gangs showed **operational overlap**: shared infrastructure, tooling (SectoPrat), and possible affiliate cross-pollination. This blurs attribution and suggests a consolidating ransomware ecosystem where affiliates move between RaaS platforms or multiple platforms share backend infrastructure.

---

## 4. Common Ransomware TTPs — Consolidated Pattern

### 4.1 The Modern Ransomware Kill Chain

```
┌─────────────────┐
│  INITIAL ACCESS  │ ← RDP (valid creds/IAB), Phishing, Malvertising,
│                  │   Exploit public-facing apps (VPN, ActiveMQ, Exchange)
└────────┬────────┘
         ↓
┌─────────────────┐
│   EXECUTION     │ ← Loaders (Bumblebee, Latrodectus, IcedID, QBot)
│                 │   MSI sideloading, PowerShell, rundll32, mshta
└────────┬────────┘
         ↓
┌─────────────────┐
│   PERSISTENCE   │ ← Registry Run keys, Scheduled Tasks, RMM tools
│                 │   (AnyDesk, RustDesk, ScreenConnect), Domain accounts
└────────┬────────┘
         ↓
┌─────────────────┐
│   PRIVILEGE     │ ← Meterpreter getsystem, Zerologon (CVE-2020-1472),
│   ESCALATION    │   UAC bypass, Domain Admin credential theft
└────────┬────────┘
         ↓
┌─────────────────┐
│   DEFENSE       │ ← Disable Defender (LOLBINs), clear event logs,
│   EVASION       │   process injection, tool renaming, file deletion
└────────┬────────┘
         ↓
┌─────────────────┐
│   CREDENTIAL    │ ← LSASS dump (comsvcs.dll, procdump, Mimikatz),
│   ACCESS        │   NTDS.dit via wbadmin, Veeam cred extraction,
│                 │   unattend.xml, browser credential stores
└────────┬────────┘
         ↓
┌─────────────────┐
│   DISCOVERY     │ ← AdFind, NetScan, NetExec, Advanced IP Scanner,
│                 │   nltest, net group, Invoke-ShareFinder, rustscan
└────────┬────────┘
         ↓
┌─────────────────┐
│   LATERAL       │ ← RDP, PsExec, SMB, remote service creation,
│   MOVEMENT      │   WMI, SSH tunneling
└────────┬────────┘
         ↓
┌─────────────────┐
│   COLLECTION &  │ ← Rclone, FileZilla (SFTP), 7-Zip, temp.sh,
│   EXFILTRATION  │   Mega.io — always BEFORE encryption
└────────┬────────┘
         ↓
┌─────────────────┐
│   IMPACT        │ ← Ransomware deployment (LockBit, Akira, Lynx, etc.)
│                 │   Backup deletion (Veeam, shadow copies)
│                 │   Double/triple extortion (encrypt + leak + DDoS)
└─────────────────┘
```

### 4.2 Time-to-Ransomware (TTR) Trends

| Case | TTR | Notes |
|------|-----|-------|
| Bumblebee → Akira | 44 hours | Fastest — automated pipeline |
| Lynx via RDP | 178 hours (9 days) | Manual operator, methodical |
| ActiveMQ → LockBit | 419 hours (19 days) | Re-exploitation after initial pause |
| Lunar Spider (no ransom) | 56 days | IAB model — access sold, not encrypted |

**Trend**: TTR is shrinking for automated affiliate operations but remains longer for manual, hands-on-keyboard intrusions. IAB operations can have very long dwell times.

### 4.3 Top Attacker Tools Observed

| Tool | Purpose | Frequency |
|------|---------|-----------|
| Cobalt Strike | C2 framework | Very High |
| Brute Ratel (BRC4) | C2 framework (EDR evasion) | High |
| AdaptixC2 | C2 framework (emerging) | Increasing |
| Metasploit/Meterpreter | Exploitation + C2 | High |
| AnyDesk | Persistence/remote access | Very High |
| RustDesk | Persistence/remote access (emerging) | Increasing |
| Advanced IP Scanner | Network discovery | Very High |
| SoftPerfect NetScan | Network discovery | High |
| NetExec (nxc) | SMB/AD enumeration | High |
| AdFind | AD enumeration | High |
| Rclone | Data exfiltration | Very High |
| FileZilla | Data exfiltration (SFTP) | High |
| 7-Zip | Data compression | High |
| Bumblebee | Loader | High |
| Latrodectus | Loader (Lunar Spider) | Increasing |

---

## 5. Current Threat Intelligence by Sector (2026)

### 5.1 Iran-Focused Activity Surge (March 2026)
Multiple vendors report heightened Iranian operations:
- **Handala Hack / Void Manticore**: Wiper attacks increasing; IP camera exploitation for kinetic warfare support (Unit 42, Check Point)
- **MuddyWater (Operation Olalampo)**: New malware variants using Telegram bots for C2 (Group-IB)
- **MOIS actors**: Connections between state-sponsored operations and cybercriminal activities (Check Point)
- **Proofpoint**: Heightened espionage against Middle East targets driven by Iran conflict
- **Wiper trend**: Iran-linked groups shifting from espionage to destructive operations

### 5.2 China-Nexus Espionage (March 2026)
- **UAT-9244**: Targeting South American telecom with three new malware implants (Talos)
- **CL-STA-1087**: Southeast Asian military targeting (Unit 42)
- **CL-UNK-1068**: Years of undetected operations using DLL sideloading and Fast Reverse Proxy (Unit 42)
- **Volt Typhoon**: Continued pre-positioning in US critical infrastructure
- **Salt Typhoon**: Ongoing telecom/ISP compromise

### 5.3 Supply Chain & AI-Targeting Threats
- **Six supply chain attack groups to watch in 2026** — npm ecosystem attacks, SaaS/MSP targeting (Group-IB)
- **AI agent exploitation**: Prompt injection attacks against AI security systems observed in the wild (Unit 42)
- **Agentic AI risks**: Autonomous agent deployment creates new exploitation surfaces (Talos)
- **GTFire phishing**: Abusing Google Firebase + Google Translate to scale phishing at global scale (Group-IB)
- **Claude Code RCE**: CVE-2025-59536, CVE-2026-21852 — RCE and API token exfiltration via project files (Check Point)

### 5.4 Fake Shipment Scams & Financial Fraud
- **MEA region**: Telegram-based malicious app distribution disguised as shipment tracking (Group-IB)
- **Indonesia tax fraud**: Industrialized MaaS infrastructure impersonating Coretax tax authority (Group-IB)

---

## 6. IOC Types and Sharing Formats

### 6.1 Indicator Types (Pyramid of Pain)

David Bianco's Pyramid of Pain ranks indicators by the cost to the adversary when denied:

```
        /\
       /  \  TTPs (Tactics, Techniques, Procedures)
      /    \  — Hardest to change; highest detection value
     /──────\
    /  Tools  \  — C2 frameworks, custom malware
   /──────────\
  / Network /   \  — C2 domains, IPs, certificates
 /  Host    /    \  — Registry keys, mutex names, file paths
/  Artifacts/     \
/──────────────────\
/ Hash Values       \  — File hashes (MD5, SHA1, SHA256)
/────────────────────\  — Trivial to change; lowest value
```

| Level | IOC Type | Examples | Adversary Cost to Change |
|-------|----------|----------|--------------------------|
| Hash Values | MD5, SHA1, SHA256 | Malware sample hashes | Trivial (recompile) |
| IP Addresses | IPv4, IPv6 | C2 servers, exfil destinations | Low (new VPS) |
| Domain Names | FQDN | C2 domains, DGA seeds | Low-Medium |
| Network Artifacts | URI patterns, JA3/JA4, User-Agents | /api/beacon, custom TLS fingerprints | Medium |
| Host Artifacts | Registry keys, file paths, mutex names | Run key entries, named pipes | Medium |
| Tools | Software, frameworks | Cobalt Strike, BruteRatel, Rclone | Medium-High |
| TTPs | Behavioral patterns | LSASS dump via comsvcs.dll, Zerologon | Very High |

### 6.2 IOC Sharing Standards

#### STIX (Structured Threat Information eXpression)
- **Version**: STIX 2.1 (current standard)
- **Format**: JSON-based
- **Purpose**: Represent full range of cyber threat information — indicators, threat actors, campaigns, attack patterns, malware, vulnerabilities, courses of action
- **Key Objects**: Indicator, Malware, Threat-Actor, Attack-Pattern, Campaign, Intrusion-Set, Observed-Data, Relationship, Sighting
- **Embedding**: Can include OpenIOC, YARA, Snort rules as test mechanisms
- **OASIS Standard**: Maintained by OASIS Open

#### TAXII (Trusted Automated eXchange of Indicator Information)
- **Version**: TAXII 2.1
- **Purpose**: Transport protocol for STIX data exchange
- **Services**: Discovery, Collection Management, Inbox (push), Poll (pull)
- **Protocol**: RESTful HTTPS API
- **Use Case**: Automated machine-to-machine threat intelligence sharing between organizations

#### Other Formats
| Format | Purpose |
|--------|---------|
| **CybOX** | Cyber Observable eXpression — common structure for cyber observables (now merged into STIX 2.x) |
| **IODEF (RFC 5070)** | Incident Object Description Exchange Format — CSIRT incident data sharing |
| **IDMEF (RFC 4765)** | Intrusion Detection Message Exchange Format — IDS/IPS data exchange |
| **MAEC** | Malware Attribute Enumeration and Characterization — standardized malware description |
| **OpenC2** | Open Command and Control — standardized cyber defense command language |
| **VERIS** | Vocabulary for Event Recording and Incident Sharing — breach classification (powers Verizon DBIR) |
| **CAPEC** | Common Attack Pattern Enumeration and Classification — attack pattern taxonomy |
| **MISP Format** | Native MISP JSON event format — widely used in MISP ecosystem |
| **CSV/JSON** | CISA KEV catalog available in CSV, JSON, JSON Schema for tool integration |

### 6.3 Sharing Platforms and Feeds

#### Government / ISACs
- **CISA AIS**: Automated Indicator Sharing — machine-speed STIX/TAXII exchange between federal and private sector
- **CISA KEV**: Known Exploited Vulnerabilities catalog (CSV/JSON)
- **ISACs**: Sector-specific sharing (FS-ISAC, H-ISAC, etc.)

#### Community Platforms
- **MISP**: Open-source threat intelligence platform (most widely deployed TIP)
- **OpenCTI**: Open-source cyber threat intelligence platform
- **TheHive/Cortex**: Incident response + observable analysis platform
- **IntelOwl**: OSINT aggregation (VirusTotal, AbuseIPDB, YARA analysis)
- **CRITs**: Collaborative malware research platform

#### Commercial TIPs
- **EclecticIQ Platform**: STIX/TAXII-based TIP
- **Recorded Future**: Intelligence analytics platform
- **ThreatConnect**: TIP with automated IOC ingestion from 90+ blogs
- **Cyware CTIX**: Client-server TIP with bi-directional sharing

#### Free Threat Feeds (Key Sources)
| Source | Type | Format |
|--------|------|--------|
| abuse.ch (ThreatFox, URLhaus, MalwareBazaar, SSLBL, Feodo Tracker) | IOCs, malware samples, URLs, SSL certs | STIX, CSV, API |
| AbuseIPDB | Malicious IP crowdsource | API |
| AlienVault OTX | Multi-type IOCs | STIX, API |
| CrowdSec | Crowdsourced IPs from real attacks | API, blocklists |
| GreyNoise | Internet scanner classification | API |
| IPsum | Aggregated IP blacklists (30+ sources) | Text |
| FireHOL IP Lists | 400+ IP feeds analyzed | Various |
| YARA-Rules | Community YARA signatures | YARA |
| Emerging Threats | Snort/Suricata rules, firewall rules | IDS rules |
| SANS ISC | Suspicious domains (high/medium/low) | Text |

---

## 7. CTI Analysis Methodology

### 7.1 The Intelligence Cycle

```
    ┌─────────────┐
    │  DIRECTION   │ ← Requirements, Priority Intelligence Requirements (PIRs)
    │  & PLANNING  │   What does the organization need to know?
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  COLLECTION  │ ← OSINT, HUMINT, SIGINT, technical feeds, dark web
    │              │   Passive vs. active collection disciplines
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  PROCESSING  │ ← Normalize, deduplicate, enrich, correlate
    │              │   IOC enrichment, STIX conversion, feed aggregation
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  ANALYSIS    │ ← Apply analytic frameworks (see below)
    │              │   Structured analytic techniques, hypothesis testing
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │ DISSEMINATION│ ← Deliver to stakeholders in appropriate format
    │              │   Strategic (exec), operational (SOC), tactical (SIEM rules)
    └──────┬──────┘
           ↓
    ┌─────────────┐
    │  FEEDBACK    │ ← Was the intelligence useful? Adjust PIRs
    │              │   Continuous improvement loop
    └─────────────┘
```

### 7.2 Core Analytic Frameworks

#### Diamond Model of Intrusion Analysis
Four core features connected in a diamond shape:
- **Adversary**: Threat actor identity, motivation, capability
- **Infrastructure**: C2 servers, domains, hosting, bulletproof providers
- **Capability**: Malware, tools, exploits, techniques
- **Victim**: Targeted organization, sector, system, persona

Pivoting between vertices enables attribution and campaign correlation. Example: a C2 IP (infrastructure) shared between two campaigns links different adversary operations.

#### Cyber Kill Chain (Lockheed Martin)
Seven sequential phases an adversary must complete:
1. **Reconnaissance** — Target research, vulnerability scanning
2. **Weaponization** — Coupling exploit with backdoor into deliverable payload
3. **Delivery** — Transmitting weaponized payload (email, web, USB)
4. **Exploitation** — Triggering the vulnerability
5. **Installation** — Installing backdoor/implant on victim
6. **Command & Control** — Establishing outbound C2 channel
7. **Actions on Objectives** — Exfiltration, destruction, ransomware

Defensive value: disrupting any phase breaks the chain.

#### MITRE ATT&CK Framework
- **14 Tactics** (the "why"): Reconnaissance through Impact
- **Hundreds of Techniques/Sub-techniques** (the "how")
- **Groups, Software, Campaigns** mapped to techniques
- **Data Sources + Detections** mapped to techniques
- Use ATT&CK Navigator for coverage gap analysis and heat mapping

#### Unified Kill Chain
Combines Lockheed Martin Kill Chain + MITRE ATT&CK into three phases:
1. **Initial Foothold** (external to internal)
2. **Network Propagation** (lateral movement and escalation)
3. **Action on Objectives** (mission completion)

#### OODA Loop (Boyd Cycle)
- **Observe** — Collect data from sensors, feeds, alerts
- **Orient** — Context, experience, analytic frameworks
- **Decide** — Choose response/action
- **Act** — Execute defensive measures
- Cycle faster than the adversary to maintain advantage

#### Pyramid of Pain (Bianco)
Ranks indicator types by adversary cost — prioritize detection at TTP level for maximum defensive value (see section 6.1).

### 7.3 Structured Analytic Techniques

From the CIA Tradecraft Primer and intelligence community methodology:

| Technique | Purpose |
|-----------|---------|
| **Analysis of Competing Hypotheses (ACH)** | Systematically evaluate multiple hypotheses against evidence |
| **Key Assumptions Check** | Identify and challenge underlying assumptions |
| **Devil's Advocacy** | Deliberately argue against prevailing assessment |
| **Red Team Analysis** | Think like the adversary to anticipate actions |
| **Timeline Analysis** | Chronological ordering of events for pattern identification |
| **Link/Network Analysis** | Map relationships between actors, infrastructure, campaigns |
| **Indicator Lifecycle Management** | Track indicator validity, aging, and retirement |
| **Confidence Assessment** | Assign confidence levels to analytical judgments |

### 7.4 Intelligence Requirements Framework

#### Strategic Intelligence
- **Audience**: Executive leadership, board
- **Content**: Threat landscape trends, sector risk, geopolitical context
- **Format**: Briefings, quarterly reports
- **Example**: "Which nation-state groups are targeting our sector?"

#### Operational Intelligence
- **Audience**: SOC managers, IR teams, security operations
- **Content**: Active campaigns, threat actor TTPs, emerging tooling
- **Format**: Threat advisories, campaign reports
- **Example**: "What does the Akira ransomware deployment chain look like?"

#### Tactical Intelligence
- **Audience**: SOC analysts, SIEM engineers, detection teams
- **Content**: IOCs, detection rules, YARA signatures
- **Format**: STIX bundles, Sigma rules, blocklists
- **Example**: "Block these C2 IPs and deploy these Sigma rules"

### 7.5 CTI Maturity Model (CREST)

| Level | Description |
|-------|-------------|
| **Level 0** | No CTI capability — purely reactive |
| **Level 1** | Ad-hoc — consume free feeds, basic IOC matching |
| **Level 2** | Defined — established process, TIP deployed, some analysis |
| **Level 3** | Managed — PIRs defined, structured analysis, proactive hunting |
| **Level 4** | Optimized — Full intelligence cycle, production, feedback loop, contributes to community |

### 7.6 Analyst Core Competencies (Mandiant Framework)
- Malware analysis and reverse engineering
- Network traffic analysis and protocol understanding
- Adversary infrastructure tracking and pivoting
- Report writing and intelligence production
- STIX/TAXII and sharing platform proficiency
- Programming/scripting for automation
- Structured analytic technique application
- Geopolitical awareness and contextual analysis

---

## 8. Detection Quick Reference — High-Value Sigma Rule Targets

Based on the DFIR report attack chains, these are the highest-value detection targets:

| Detection | MITRE | Why |
|-----------|-------|-----|
| LSASS access (comsvcs.dll, procdump, 0x1010 GrantedAccess) | T1003.001 | Present in nearly every intrusion |
| NTDS.dit backup via wbadmin | T1003.003 | Domain credential theft |
| Named pipe creation matching Meterpreter getsystem | T1134 | Privilege escalation signature |
| CertUtil downloading executables | T1105 | Common payload download method |
| AnyDesk/RustDesk/ScreenConnect service installation | T1219 | RMM abuse for persistence |
| Advanced IP Scanner / NetScan / NetExec execution | T1046 | Network discovery tooling |
| AdFind enumeration commands | T1087.002 | AD reconnaissance |
| Event log clearing (IDs 104, 1102) | T1070.001 | Defense evasion |
| Rclone execution (especially renamed) | T1567 | Data exfiltration |
| Domain Admin group additions | T1098 | Persistence via privileged accounts |
| Scheduled tasks with LSASS-like names | T1053.005 | Masquerading persistence |
| Veeam backup deletion / credential extraction | T1490/T1555 | Pre-ransomware preparation |
| SSH reverse tunnels | T1572 | C2 tunneling |
| MSI sideloading via consent.exe | T1574.002 | Loader execution |
| Enterprise Admin group membership changes | T1098 | Highest privilege persistence |

---

## 9. Key Threat Intelligence Sources & Platforms

### 9.1 Vendor Threat Research Blogs (Primary Sources)

| Source | Focus | URL |
|--------|-------|-----|
| The DFIR Report | Real-world intrusion analysis with full attack chains | thedfirreport.com |
| Google/Mandiant (Threat Intelligence) | APT tracking, zero-days, malware analysis | cloud.google.com/blog/topics/threat-intelligence/ |
| Cisco Talos | Vulnerability research, threat campaigns, Snort rules | blog.talosintelligence.com |
| Microsoft Security Blog | Nation-state tracking (Blizzard/Typhoon taxonomy) | microsoft.com/en-us/security/blog/ |
| Unit 42 (Palo Alto) | APT research, ransomware, malware families | unit42.paloaltonetworks.com |
| Check Point Research | Malware analysis, vulnerability disclosure, threat stats | research.checkpoint.com |
| CrowdStrike Blog | Threat actor tracking (animal taxonomy) | crowdstrike.com/blog/ |
| Recorded Future Blog | Geopolitical CTI, dark web intelligence | recordedfuture.com/blog |
| Group-IB Blog | Financial fraud, dark web, supply chain attacks | group-ib.com/blog/ |
| Proofpoint Blog | Email threats, phishing, social engineering | proofpoint.com/us/blog |

### 9.2 Tracking & Reference Platforms

| Platform | Purpose |
|----------|---------|
| MITRE ATT&CK | Adversary behavior knowledge base (176 groups) |
| RansomLook | Ransomware group tracking (549 groups, 731 DLS) |
| CISA KEV | Known exploited vulnerabilities (1,542 CVEs) |
| Malpedia | Malware identification and context |
| VirusTotal | Sample analysis and IOC enrichment |
| Shodan/Censys | Internet-facing asset discovery |
| abuse.ch ecosystem | Malware samples, URLs, botnet tracking |

### 9.3 Key Reference Documents
- **NIST SP 800-150**: Guide to Cyber Threat Information Sharing
- **Diamond Model Paper**: Intrusion analysis methodology (Caltagirone, Pendergast, Betz)
- **CIA Tradecraft Primer**: Structured analytic techniques
- **Pyramid of Pain**: Indicator value framework (Bianco)
- **ENISA TIP Evaluation Guide**: Threat intelligence platform assessment
- **Intel 471 GIR Handbook**: Cybercrime Underground General Intelligence Requirements
- **Recorded Future Intelligence Handbook**: CTI program methodology
- **CREST CTI Maturity Model**: Program maturity assessment tool

---

## 10. Operational Takeaways

### For Defenders
1. **Prioritize TTP detection over IOC matching** — IOCs are ephemeral; behaviors persist
2. **Monitor for RMM tool abuse** — AnyDesk, RustDesk, ScreenConnect are the new persistence
3. **Protect credential stores** — LSASS, NTDS.dit, Veeam, unattend.xml are all targets
4. **Watch for renamed tools** — Rclone as sihosts.exe, Advanced IP Scanner as random names
5. **Backup deletion is the ransomware canary** — Veeam job deletion precedes encryption
6. **Initial access brokers mean long dwell times** — 56-day Lunar Spider case had no ransomware but full compromise
7. **Bulletproof hosting IPs are high-confidence indicators** — Railnet/Virtualine, PQ Hosting
8. **Search engine malvertising is a growing vector** — Bing/Google ads delivering trojanized installers

### For Threat Hunters
1. Hunt for DGA domain resolution patterns
2. Look for wbadmin NTDS backup commands
3. Search for comsvcs.dll MiniDump calls
4. Correlate AnyDesk/RustDesk installation with non-IT-approved sources
5. Monitor Enterprise Admin and Domain Admin group membership changes
6. Hunt for SSH reverse tunnels from internal hosts
7. Track Rclone configuration files and renamed binaries
8. Watch for NetExec/nxc.exe and AdFind execution

### For CTI Teams
1. **Establish PIRs** aligned to your organization's threat profile
2. **Deploy a TIP** (MISP or OpenCTI minimum) for feed aggregation
3. **Automate IOC ingestion** via STIX/TAXII from CISA AIS and abuse.ch
4. **Map your detection coverage** against ATT&CK using Navigator
5. **Track ransomware ecosystem evolution** — groups merge, rebrand, share infrastructure
6. **Monitor IAB activity** — Lunar Spider, Exotic Lily, and others are upstream of ransomware
7. **Produce intelligence at all three levels** — strategic, operational, tactical
8. **Participate in sharing communities** — ISACs, MISP instances, FIRST

---

## 11. STIX 2.1 Deep Dive

### 11.1 STIX Domain Objects (SDOs)

| Object Type | Description | Key Properties |
|-------------|-------------|----------------|
| `attack-pattern` | TTP or behavior (maps to ATT&CK technique) | `name`, `external_references`, `kill_chain_phases` |
| `campaign` | Set of adversary activities over a time period | `name`, `first_seen`, `last_seen`, `objective` |
| `course-of-action` | Recommended defensive action or mitigation | `name`, `description`, `action` |
| `grouping` | Context for related STIX objects (NOT a report) | `name`, `context`, `object_refs` |
| `identity` | Individuals, organizations, or groups | `name`, `identity_class`, `sectors` |
| `indicator` | Pattern that detects suspicious/malicious activity | `pattern`, `pattern_type`, `valid_from`, `valid_until` |
| `infrastructure` | Systems/services used by threat actors | `name`, `infrastructure_types` |
| `intrusion-set` | Grouped adversary behaviors and resources | `name`, `goals`, `resource_level`, `primary_motivation` |
| `location` | Geographic location | `region`, `country`, `latitude`, `longitude` |
| `malware` | Instance or family of malicious code | `name`, `malware_types`, `is_family`, `capabilities` |
| `malware-analysis` | Results from analyzing malware | `product`, `result`, `analysis_sco_refs` |
| `note` | Analyst commentary on STIX objects | `abstract`, `content`, `object_refs` |
| `observed-data` | Raw observables (timestamps + refs) | `first_observed`, `last_observed`, `number_observed`, `object_refs` |
| `opinion` | Analyst agreement/disagreement with object | `opinion` (enum: strongly-agree to strongly-disagree), `object_refs` |
| `report` | Published threat intelligence report | `name`, `published`, `report_types`, `object_refs` |
| `threat-actor` | Actual individuals, groups, or organizations | `name`, `threat_actor_types`, `roles`, `sophistication`, `goals` |
| `tool` | Legitimate software used by threat actors | `name`, `tool_types`, `tool_version` |
| `vulnerability` | Software weakness (CVE) | `name`, `external_references` |

### 11.2 STIX Cyber-observable Objects (SCOs)

| Object Type | Description | Example Value |
|-------------|-------------|---------------|
| `ipv4-addr` | IPv4 address | `166.62.100.52` |
| `ipv6-addr` | IPv6 address | `2001:db8::1` |
| `domain-name` | Domain | `avtechupdate.com` |
| `url` | Full URL | `http://91.194.11.64/MSI.msi` |
| `email-addr` | Email address | `phish@example.com` |
| `email-message` | Email with headers/body | Subject, from, to, body |
| `file` | File with hashes, name, size | SHA-256, filename, MIME type |
| `process` | Running process | PID, command line, image path |
| `network-traffic` | Network connection | src/dst refs, protocols, ports |
| `windows-registry-key` | Registry key/value | Key path, values array |
| `x509-certificate` | TLS/SSL certificate | Serial, issuer, subject, SHA-256 |
| `artifact` | Raw binary content (base64) | Payloads, packet captures |
| `directory` | File system directory | Path |
| `mutex` | Named mutex | Name |
| `software` | Installed software | Name, vendor, version |
| `user-account` | OS or service account | User ID, account login |
| `autonomous-system` | BGP AS | ASN number, name |
| `mac-addr` | MAC address | `aa:bb:cc:dd:ee:ff` |

### 11.3 STIX Relationship Objects (SROs)

| SRO Type | Purpose | Example |
|----------|---------|---------|
| `relationship` | Links two SDOs/SCOs | threat-actor `uses` malware |
| `sighting` | Records observation of an SDO | indicator `sighted` at identity |

Common `relationship_type` values:

| Source Type | relationship_type | Target Type |
|-------------|-------------------|-------------|
| threat-actor | `uses` | malware, tool, attack-pattern |
| threat-actor | `attributed-to` | identity |
| threat-actor | `targets` | identity, location, vulnerability |
| malware | `targets` | identity, vulnerability |
| malware | `uses` | attack-pattern |
| indicator | `indicates` | malware, threat-actor, campaign |
| campaign | `attributed-to` | threat-actor, intrusion-set |
| course-of-action | `mitigates` | attack-pattern, malware, vulnerability |
| malware | `communicates-with` | ipv4-addr, domain-name, url |
| malware | `downloads` | malware, tool |

### 11.4 STIX 2.1 Bundle Example — APT29 Campaign

```json
{
  "type": "bundle",
  "id": "bundle--a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "objects": [
    {
      "type": "threat-actor",
      "spec_version": "2.1",
      "id": "threat-actor--899ce53f-13a0-479b-a0e4-67d46e241542",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "name": "APT29",
      "description": "Russian SVR-affiliated espionage group targeting government and diplomatic entities.",
      "threat_actor_types": ["nation-state"],
      "aliases": ["Cozy Bear", "NOBELIUM", "Midnight Blizzard", "The Dukes"],
      "roles": ["agent"],
      "goals": ["espionage", "intelligence collection"],
      "sophistication": "expert",
      "resource_level": "government",
      "primary_motivation": "organizational-gain",
      "external_references": [
        {
          "source_name": "mitre-attack",
          "external_id": "G0016",
          "url": "https://attack.mitre.org/groups/G0016/"
        }
      ]
    },
    {
      "type": "malware",
      "spec_version": "2.1",
      "id": "malware--d1e2f3a4-b5c6-7890-abcd-ef0987654321",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "name": "SUNBURST",
      "description": "Trojanized SolarWinds Orion update used for initial access and C2.",
      "malware_types": ["backdoor", "trojan"],
      "is_family": true,
      "capabilities": [
        "persists-after-system-reboot",
        "communicates-with-c2",
        "exfiltrates-data"
      ]
    },
    {
      "type": "indicator",
      "spec_version": "2.1",
      "id": "indicator--f1234567-89ab-cdef-0123-456789abcdef",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "name": "SUNBURST C2 Domain",
      "description": "Known C2 domain used by SUNBURST backdoor for DGA-based communication.",
      "pattern": "[domain-name:value = 'avsvmcloud.com']",
      "pattern_type": "stix",
      "valid_from": "2020-03-01T00:00:00Z",
      "valid_until": "2027-03-01T00:00:00Z",
      "indicator_types": ["malicious-activity"],
      "kill_chain_phases": [
        {
          "kill_chain_name": "mitre-attack",
          "phase_name": "command-and-control"
        }
      ]
    },
    {
      "type": "indicator",
      "spec_version": "2.1",
      "id": "indicator--a9876543-21fe-dcba-0987-654321fedcba",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "name": "SUNBURST File Hash",
      "description": "SHA-256 hash of trojanized SolarWinds.Orion.Core.BusinessLayer.dll.",
      "pattern": "[file:hashes.'SHA-256' = '32519b85c0b422e4656de6e6c41878e95fd95026267daab4215ee59c107d6c77']",
      "pattern_type": "stix",
      "valid_from": "2020-03-01T00:00:00Z",
      "indicator_types": ["malicious-activity"]
    },
    {
      "type": "attack-pattern",
      "spec_version": "2.1",
      "id": "attack-pattern--cc7b8c4e-9be0-47ca-b0bb-83915ec3ee2f",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "name": "Supply Chain Compromise: Compromise Software Supply Chain",
      "external_references": [
        {
          "source_name": "mitre-attack",
          "external_id": "T1195.002",
          "url": "https://attack.mitre.org/techniques/T1195/002/"
        }
      ],
      "kill_chain_phases": [
        {
          "kill_chain_name": "mitre-attack",
          "phase_name": "initial-access"
        }
      ]
    },
    {
      "type": "relationship",
      "spec_version": "2.1",
      "id": "relationship--11111111-2222-3333-4444-555555555555",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "relationship_type": "uses",
      "source_ref": "threat-actor--899ce53f-13a0-479b-a0e4-67d46e241542",
      "target_ref": "malware--d1e2f3a4-b5c6-7890-abcd-ef0987654321",
      "description": "APT29 deployed SUNBURST via trojanized SolarWinds update."
    },
    {
      "type": "relationship",
      "spec_version": "2.1",
      "id": "relationship--66666666-7777-8888-9999-aaaaaaaaaaaa",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "relationship_type": "indicates",
      "source_ref": "indicator--f1234567-89ab-cdef-0123-456789abcdef",
      "target_ref": "malware--d1e2f3a4-b5c6-7890-abcd-ef0987654321",
      "description": "C2 domain avsvmcloud.com indicates SUNBURST backdoor activity."
    },
    {
      "type": "relationship",
      "spec_version": "2.1",
      "id": "relationship--bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
      "created": "2026-03-15T00:00:00.000Z",
      "modified": "2026-03-15T00:00:00.000Z",
      "relationship_type": "uses",
      "source_ref": "malware--d1e2f3a4-b5c6-7890-abcd-ef0987654321",
      "target_ref": "attack-pattern--cc7b8c4e-9be0-47ca-b0bb-83915ec3ee2f",
      "description": "SUNBURST was delivered via supply chain compromise of SolarWinds Orion."
    }
  ]
}
```

### 11.5 STIX Pattern Language Quick Reference

| Pattern | Meaning |
|---------|---------|
| `[ipv4-addr:value = '1.2.3.4']` | Match IPv4 address |
| `[domain-name:value = 'evil.com']` | Match domain |
| `[file:hashes.'SHA-256' = 'abc123...']` | Match file by SHA-256 |
| `[file:name = 'payload.exe']` | Match filename |
| `[email-message:subject LIKE '%invoice%']` | Match email subject (partial) |
| `[network-traffic:dst_ref.type = 'ipv4-addr' AND network-traffic:dst_port = 443]` | Match traffic to IP on port 443 |
| `[process:command_line MATCHES '.*mimikatz.*']` | Regex match on process command line |
| `[url:value = 'http://evil.com/payload']` | Match URL |
| `[windows-registry-key:key = 'HKEY_LOCAL_MACHINE\\...']` | Match registry key |
| `([file:name = 'a.exe'] OR [file:name = 'b.exe'])` | Boolean OR across observations |

### 11.6 TAXII 2.1 Operations — Polling Commands

```bash
# Discover TAXII server capabilities
curl -k -H "Accept: application/taxii+json;version=2.1" \
  https://taxii.example.com/taxii2/

# List API roots
curl -k -H "Accept: application/taxii+json;version=2.1" \
  https://taxii.example.com/taxii2/

# List collections from an API root
curl -k -H "Accept: application/taxii+json;version=2.1" \
  -u user:password \
  https://taxii.example.com/api1/collections/

# Get objects from a specific collection
curl -k -H "Accept: application/stix+json;version=2.1" \
  -u user:password \
  "https://taxii.example.com/api1/collections/{collection-id}/objects/"

# Filter by object type (indicators only)
curl -k -H "Accept: application/stix+json;version=2.1" \
  -u user:password \
  "https://taxii.example.com/api1/collections/{collection-id}/objects/?match[type]=indicator"

# Filter by time range (added after a specific date)
curl -k -H "Accept: application/stix+json;version=2.1" \
  -u user:password \
  "https://taxii.example.com/api1/collections/{collection-id}/objects/?added_after=2026-01-01T00:00:00Z"

# Get a specific object by ID
curl -k -H "Accept: application/stix+json;version=2.1" \
  -u user:password \
  "https://taxii.example.com/api1/collections/{collection-id}/objects/{object-id}/"

# Push (publish) STIX objects to a collection
curl -k -X POST \
  -H "Content-Type: application/stix+json;version=2.1" \
  -H "Accept: application/taxii+json;version=2.1" \
  -u user:password \
  -d @stix_bundle.json \
  "https://taxii.example.com/api1/collections/{collection-id}/objects/"

# Get manifest (metadata without full objects)
curl -k -H "Accept: application/taxii+json;version=2.1" \
  -u user:password \
  "https://taxii.example.com/api1/collections/{collection-id}/manifest/"
```

**TAXII Authentication**: Most servers support HTTP Basic Auth or API keys via custom headers. CISA AIS uses certificate-based mutual TLS authentication.

### 11.7 Python STIX2 Library Quick Reference

```python
from stix2 import ThreatActor, Malware, Indicator, Relationship, Bundle

# Create objects
apt29 = ThreatActor(
    name="APT29",
    threat_actor_types=["nation-state"],
    aliases=["Cozy Bear", "Midnight Blizzard"],
    sophistication="expert",
    resource_level="government"
)

sunburst = Malware(
    name="SUNBURST",
    malware_types=["backdoor"],
    is_family=True
)

ioc = Indicator(
    name="SUNBURST C2",
    pattern="[domain-name:value = 'avsvmcloud.com']",
    pattern_type="stix",
    valid_from="2020-03-01T00:00:00Z",
    indicator_types=["malicious-activity"]
)

rel = Relationship(
    relationship_type="uses",
    source_ref=apt29.id,
    target_ref=sunburst.id
)

bundle = Bundle(objects=[apt29, sunburst, ioc, rel])
print(bundle.serialize(pretty=True))

# Parse incoming STIX
from stix2 import parse
obj = parse('{"type": "indicator", ...}')
```

---

## 12. MISP Operations

### 12.1 MISP Architecture Overview

```
┌──────────────┐     ┌─────────────┐     ┌──────────────┐
│  MISP Web UI │────→│  MISP Core  │────→│  MySQL/Maria │
│  (Analyst)   │     │  (CakePHP)  │     │  Database    │
└──────────────┘     └──────┬──────┘     └──────────────┘
                            │
                     ┌──────┴──────┐
                     │  Workers    │ ← Redis queue (enrichment, email, pull/push)
                     │  (Python)   │
                     └──────┬──────┘
                            │
              ┌─────────────┼─────────────┐
              │             │             │
       ┌──────┴──────┐ ┌───┴────┐ ┌──────┴──────┐
       │ MISP Feeds  │ │ TAXII  │ │ Sync Peers  │
       │ (pull)      │ │ Server │ │ (push/pull) │
       └─────────────┘ └────────┘ └─────────────┘
```

### 12.2 MISP API — Authentication

```bash
# All MISP API calls require an API key in the Authorization header
# Get your API key: MISP Web UI → Administration → My Profile → Auth Key
export MISP_URL="https://misp.example.com"
export MISP_KEY="your-api-key-here"

# Verify connectivity
curl -k -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  "${MISP_URL}/servers/getVersion"
```

### 12.3 Event Operations

```bash
# Create a new event
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "Event": {
      "info": "APT29 Phishing Campaign - March 2026",
      "distribution": 1,
      "threat_level_id": 1,
      "analysis": 1,
      "date": "2026-03-15",
      "Tag": [
        {"name": "tlp:amber"},
        {"name": "misp-galaxy:threat-actor=\"APT29\""}
      ]
    }
  }' \
  "${MISP_URL}/events/add"

# Distribution levels:
#   0 = Your organisation only
#   1 = This community only
#   2 = Connected communities
#   3 = All communities
#   4 = Sharing group

# Threat level:
#   1 = High    2 = Medium    3 = Low    4 = Undefined

# Analysis state:
#   0 = Initial    1 = Ongoing    2 = Complete

# Get event by ID
curl -k -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  "${MISP_URL}/events/view/12345"

# Search events by keyword
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"searchall": "APT29", "limit": 25}' \
  "${MISP_URL}/events/restSearch"

# Search events by date range
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"from": "2026-03-01", "to": "2026-03-15", "published": true}' \
  "${MISP_URL}/events/restSearch"

# Publish an event (makes it available for sync)
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  "${MISP_URL}/events/publish/12345"

# Delete an event
curl -k -X DELETE \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  "${MISP_URL}/events/delete/12345"
```

### 12.4 Attribute Operations

```bash
# Add an IP indicator to an event
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": 12345,
    "category": "Network activity",
    "type": "ip-dst",
    "value": "166.62.100.52",
    "to_ids": true,
    "comment": "LockBit C2 server from ActiveMQ intrusion",
    "Tag": [{"name": "tlp:amber"}]
  }' \
  "${MISP_URL}/attributes/add/12345"

# Add a file hash indicator
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": 12345,
    "category": "Payload delivery",
    "type": "sha256",
    "value": "C8646CFB574FF2C6F183C3C3951BF6B2C6CF16FF8A5E949A118BE27F15962FAE",
    "to_ids": true,
    "comment": "LockBit 3.0 ransomware binary (LB3_pass.exe)"
  }' \
  "${MISP_URL}/attributes/add/12345"

# Add a domain indicator
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": 12345,
    "category": "Network activity",
    "type": "domain",
    "value": "avsvmcloud.com",
    "to_ids": true,
    "comment": "SUNBURST C2 DGA domain"
  }' \
  "${MISP_URL}/attributes/add/12345"

# Common attribute types:
#   ip-src, ip-dst          — Source/destination IP
#   domain, hostname        — Domain/hostname
#   url, uri                — Full URL / URI path
#   md5, sha1, sha256       — File hashes
#   filename                — Filename
#   filename|sha256         — Composite: filename + hash
#   email-src, email-dst    — Email addresses
#   mutex, named pipe       — Host artifacts
#   regkey, regkey|value    — Registry keys
#   vulnerability           — CVE ID
#   user-agent              — HTTP user agent string
#   ja3-fingerprint-md5     — JA3 TLS fingerprint
#   yara, sigma, snort      — Detection rules

# Search attributes across all events
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "value": "166.62.100.52",
    "type": "ip-dst",
    "searchall": false
  }' \
  "${MISP_URL}/attributes/restSearch"

# Search for all IOCs with IDS flag for SIEM export
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "to_ids": true,
    "published": true,
    "enforceWarninglist": true,
    "limit": 1000,
    "type": ["ip-dst", "domain", "sha256"]
  }' \
  "${MISP_URL}/attributes/restSearch"

# Batch add attributes (MISP freetext import via API)
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{
    "value": "166.62.100.52\n195.211.190.189\n77.90.153.30\navsvmcloud.com",
    "event_id": 12345
  }' \
  "${MISP_URL}/attributes/freeTextImport/12345"
```

### 12.5 Correlation and Warninglists

```bash
# MISP auto-correlates attributes across events. Check correlations:
curl -k -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  "${MISP_URL}/attributes/view/67890"
# Response includes "RelatedAttribute" array with cross-event matches

# View warninglists (known-good lists to suppress FPs)
curl -k -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  "${MISP_URL}/warninglists/index"

# Enable a warninglist (e.g., Cloudflare IPs, Google DNS, Alexa Top 1M)
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"id": [42, 43, 44]}' \
  "${MISP_URL}/warninglists/toggleEnable"

# Check a value against warninglists
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"value": ["8.8.8.8", "166.62.100.52"]}' \
  "${MISP_URL}/warninglists/checkValue"
```

### 12.6 Galaxy Clusters (Threat Actor / Malware Context)

```bash
# List available galaxies
curl -k -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  "${MISP_URL}/galaxies/index"

# Search for a specific galaxy cluster (e.g., APT29)
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"searchall": "APT29"}' \
  "${MISP_URL}/galaxy_clusters/restSearch"

# Attach a galaxy cluster to an event (tag-based)
curl -k -X POST \
  -H "Authorization: ${MISP_KEY}" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -d '{"Event": {"Tag": [{"name": "misp-galaxy:threat-actor=\"APT29\""}]}}' \
  "${MISP_URL}/events/edit/12345"

# Key galaxy types:
#   threat-actor      — APT groups, cybercrime groups
#   mitre-attack-pattern — ATT&CK techniques
#   tool              — Attacker tools (Cobalt Strike, Mimikatz)
#   ransomware        — Ransomware families
#   sector            — Target sectors
#   country           — Country attributions
#   malpedia          — Malware encyclopedia references
```

### 12.7 MISP Export Formats

| Endpoint | Format | Use Case |
|----------|--------|----------|
| `/events/restSearch` (Accept: application/json) | MISP JSON | Full event export for TIP-to-TIP sync |
| `/events/stix2/download/{id}` | STIX 2.1 | Integration with TAXII servers, OpenCTI |
| `/attributes/restSearch` (returnFormat: csv) | CSV | Bulk IOC import into SIEM, firewall |
| `/attributes/restSearch` (returnFormat: suricata) | Suricata rules | IDS/IPS deployment |
| `/attributes/restSearch` (returnFormat: snort) | Snort rules | IDS/IPS deployment |
| `/attributes/restSearch` (returnFormat: openioc) | OpenIOC | Legacy IOC format |
| `/attributes/restSearch` (returnFormat: rpz) | DNS RPZ | DNS sinkhole/blocklist |
| `/attributes/restSearch` (returnFormat: text) | Plain text | Quick IOC lists |

### 12.8 PyMISP Quick Reference

```python
from pymisp import PyMISP, MISPEvent, MISPAttribute

misp = PyMISP("https://misp.example.com", "api-key-here", ssl=False)

# Create event
event = MISPEvent()
event.info = "LockBit Campaign via ActiveMQ - March 2026"
event.distribution = 1
event.threat_level_id = 1
event.analysis = 1
event.add_tag("tlp:amber")
event.add_tag('misp-galaxy:ransomware="LockBit"')
created = misp.add_event(event)

# Add attributes
event_id = created["Event"]["id"]
misp.add_attribute(event_id, {"type": "ip-dst", "value": "166.62.100.52", "to_ids": True, "comment": "C2"})
misp.add_attribute(event_id, {"type": "sha256", "value": "C8646C...", "to_ids": True})

# Search
results = misp.search(value="166.62.100.52", type_attribute="ip-dst")
results = misp.search(tags=["APT29"], date_from="2026-01-01")

# Publish
misp.publish(event_id)
```

---

## 13. Diamond Model — APT29 SolarWinds Walkthrough

### 13.1 Diamond Model Structure

```
                    ┌───────────────┐
                    │   ADVERSARY   │
                    │   (Who)       │
                    └───────┬───────┘
                            │
               ┌────────────┼────────────┐
               │                         │
      ┌────────┴────────┐       ┌────────┴────────┐
      │  INFRASTRUCTURE │       │   CAPABILITY    │
      │  (Where/How     │       │   (What tools/  │
      │   delivered)    │       │    techniques)  │
      └────────┬────────┘       └────────┬────────┘
               │                         │
               └────────────┼────────────┘
                            │
                    ┌───────┴───────┐
                    │    VICTIM     │
                    │   (Target)    │
                    └───────────────┘
```

**Meta-features** (context on each vertex edge):
- **Timestamp** — When the event occurred
- **Phase** — Kill chain phase
- **Result** — Success, failure, unknown
- **Direction** — Adversary-to-victim, victim-to-infrastructure, bidirectional
- **Methodology** — Phishing, supply chain, exploitation, etc.
- **Resources** — Human, financial, technical resources used

### 13.2 APT29 / SolarWinds Campaign — Full Diamond Mapping

#### Vertex 1: Adversary

| Property | Value |
|----------|-------|
| Identity | APT29 (Cozy Bear, NOBELIUM, Midnight Blizzard) |
| MITRE ID | G0016 |
| Attribution | Russian Foreign Intelligence Service (SVR) |
| Motivation | Espionage, intelligence collection on US government, NATO allies |
| Sophistication | Expert — multi-stage supply chain, custom tooling, patient operations |
| Operations Security | Extreme — IP geofencing, victim-specific decryption keys, legitimate cloud services for C2 |
| Prior Operations | CozyDuke, MiniDuke, Office Monkeys, 2016 DNC breach, Microsoft 365 targeting (2023-2024) |

#### Vertex 2: Capability

| Layer | Detail |
|-------|--------|
| Initial Access | Supply chain compromise (T1195.002) — trojanized SolarWinds Orion update |
| Implant Stage 1 | **SUNBURST** — backdoor embedded in `SolarWinds.Orion.Core.BusinessLayer.dll` |
| Implant Stage 2 | **TEARDROP** — memory-only dropper, loaded Cobalt Strike Beacon |
| Implant Stage 3 | **RAINDROP** — secondary Cobalt Strike loader for lateral movement targets |
| Additional Tool | **GoldMax (SUNSHUTTLE)** — Go-based C2 backdoor with decoy traffic generation |
| Additional Tool | **Sibot** — VBScript-based second-stage downloader |
| Additional Tool | **GoldFinder** — HTTP tracer tool to map security devices in victim network |
| Persistence | SAML token forging ("Golden SAML") via stolen AD FS signing certificates |
| Credential Access | Forged SAML tokens for Azure AD/M365 access without MFA |
| Evasion | 14-day dormancy period; process name checks; anti-analysis killswitch (SolarWinds install path checks) |
| ATT&CK TTPs | T1195.002, T1059.001, T1071.001, T1027, T1070.004, T1550.001, T1078, T1114.002 |

#### Vertex 3: Infrastructure

| Component | Detail |
|-----------|--------|
| C2 Domain | `avsvmcloud[.]com` — SUNBURST DGA-generated subdomain C2 |
| DGA Mechanism | Victim hostname/domain encoded into subdomain; DNS A/CNAME response = C2 instruction |
| C2 Rotation | CNAME records pointed victims to unique, dedicated C2 servers per target |
| Hosting | Rented VPS in victim's home country (GeoIP evasion) — US-based servers for US targets |
| Legitimate Services | Azure, AWS, GoDaddy — infrastructure blended with normal cloud traffic |
| IP Addresses | Rotated frequently; victim-specific; many in US IP space |
| SSL Certificates | Valid, domain-validated certificates from public CAs |
| Update Server | `updates.solarwinds.com` (compromised build system — legitimate infrastructure) |
| Email Infrastructure | Compromised Constant Contact account for USAID phishing (May 2021 follow-on) |

**Infrastructure Pivoting**: The DGA mechanism in SUNBURST encoded the victim's AD domain into the DNS query. This means the C2 DNS logs contained a partial list of every compromised organization — a massive intelligence value if intercepted.

#### Vertex 4: Victim

| Property | Detail |
|----------|--------|
| Primary Targets | US Government agencies (Treasury, Commerce, DHS, State, DOE/NNSA) |
| Scale | ~18,000 organizations installed trojanized update; ~100 received hands-on-keyboard follow-up |
| Sector Spread | Government, technology, consulting, telecom, healthcare, finance |
| High-Value Targets | FireEye (security company — detected the intrusion), Microsoft, Intel, Cisco, Deloitte, VMware |
| Supply Chain Vector | SolarWinds Orion used by 300,000+ customers globally |
| NATO Impact | Multiple NATO-member government agencies compromised |
| Dwell Time | March 2020 → December 2020 (~9 months undetected) |
| Discovery | FireEye detected unauthorized MFA device registration on employee account |

#### 13.3 Pivoting with the Diamond Model

```
Pivot 1: Infrastructure → Victim Discovery
  avsvmcloud.com DNS logs → encoded victim domains → scope of compromise

Pivot 2: Capability → Adversary Attribution
  SUNBURST code similarities to prior APT29 tools (code reuse, coding style)
  Golden SAML technique previously documented in APT29 operations

Pivot 3: Victim → Infrastructure Discovery
  Compromised SolarWinds build server → supply chain entry point identified
  FireEye breach investigation → SUNBURST discovery in Orion DLL

Pivot 4: Adversary → Capability Prediction
  APT29 history of supply chain interest → predicted M365/Azure targeting
  Led to discovery of Golden SAML forging and email access operations

Pivot 5: Infrastructure → New Campaigns
  GoDaddy/Azure infrastructure patterns → linked to May 2021 USAID phishing
  Constant Contact abuse → NOBELIUM campaign extension identified
```

### 13.4 Diamond Model Activity Threading

Activity threading links multiple diamond events into a campaign timeline:

```
Event 1 (Mar 2020): Supply chain implant delivered
  Adv: APT29 | Cap: SUNBURST | Infra: SolarWinds build | Victim: 18K orgs

Event 2 (Apr-Jun 2020): Selective targeting begins
  Adv: APT29 | Cap: TEARDROP+CobaltStrike | Infra: avsvmcloud.com DGA | Victim: ~100 orgs

Event 3 (Jun-Sep 2020): Lateral movement & persistence
  Adv: APT29 | Cap: Golden SAML, RAINDROP | Infra: US-based VPS | Victim: US Gov agencies

Event 4 (Dec 2020): Discovery and attribution
  Adv: APT29 | Cap: — (exposed) | Infra: burned | Victim: FireEye (detector)

Event 5 (May 2021): Follow-on campaign
  Adv: APT29 | Cap: GoldMax, Sibot | Infra: Constant Contact | Victim: USAID partners
```

---

## 14. IOC Lifecycle Management

### 14.1 IOC Lifecycle Phases

```
CREATE → ENRICH → VALIDATE → DEPLOY → MONITOR → AGE → EXPIRE/ARCHIVE
  │         │         │          │         │        │         │
  └─ Raw    └─ Add    └─ Check   └─ Push   └─ Track └─ Decay  └─ Remove
     intel     context    FPs       to        hits     score     from
     input     & meta    against    SIEM/     & FPs    over     active
               data      known-    IDS/      rate     time     detection
                         good      FW
```

### 14.2 IOC Creation Standards

| Field | Required | Example |
|-------|----------|---------|
| Value | Yes | `166.62.100.52` |
| Type | Yes | `ipv4-addr` |
| Source | Yes | `DFIR Report - ActiveMQ intrusion` |
| Confidence | Yes | `High (85%)` |
| TLP | Yes | `TLP:AMBER` |
| First Seen | Yes | `2026-02-15T08:30:00Z` |
| Last Seen | Recommended | `2026-03-01T14:22:00Z` |
| Context | Recommended | `LockBit 3.0 C2 server, Meterpreter stager callback` |
| ATT&CK TTP | Recommended | `T1071.001 (Application Layer Protocol: Web)` |
| Kill Chain Phase | Recommended | `Command and Control` |
| Related Campaign | If known | `LockBit via ActiveMQ (Feb 2026)` |
| Expiry Date | Recommended | `2026-09-15T00:00:00Z` (6 months default for IPs) |

### 14.3 IOC Enrichment — API Commands

#### VirusTotal

```bash
export VT_API="your-virustotal-api-key"

# Look up an IP address
curl -s -H "x-apikey: ${VT_API}" \
  "https://www.virustotal.com/api/v3/ip_addresses/166.62.100.52" | \
  jq '{reputation: .data.attributes.reputation,
       malicious: .data.attributes.last_analysis_stats.malicious,
       country: .data.attributes.country,
       asn: .data.attributes.asn,
       as_owner: .data.attributes.as_owner}'

# Look up a domain
curl -s -H "x-apikey: ${VT_API}" \
  "https://www.virustotal.com/api/v3/domains/avsvmcloud.com" | \
  jq '{reputation: .data.attributes.reputation,
       malicious: .data.attributes.last_analysis_stats.malicious,
       registrar: .data.attributes.registrar,
       creation_date: .data.attributes.creation_date}'

# Look up a file hash
curl -s -H "x-apikey: ${VT_API}" \
  "https://www.virustotal.com/api/v3/files/C8646CFB574FF2C6F183C3C3951BF6B2C6CF16FF8A5E949A118BE27F15962FAE" | \
  jq '{meaningful_name: .data.attributes.meaningful_name,
       type_description: .data.attributes.type_description,
       malicious: .data.attributes.last_analysis_stats.malicious,
       undetected: .data.attributes.last_analysis_stats.undetected,
       first_submission: .data.attributes.first_submission_date,
       tags: .data.attributes.tags}'

# Get communicating files for an IP (what malware talks to this IP)
curl -s -H "x-apikey: ${VT_API}" \
  "https://www.virustotal.com/api/v3/ip_addresses/166.62.100.52/communicating_files?limit=10" | \
  jq '.data[].attributes | {name: .meaningful_name, type: .type_description, malicious: .last_analysis_stats.malicious}'

# Download YARA ruleset matches for a file
curl -s -H "x-apikey: ${VT_API}" \
  "https://www.virustotal.com/api/v3/files/{hash}/crowdsourced_yara_results" | \
  jq '.data[] | {rule_name: .rule_name, source: .source}'
```

#### Shodan

```bash
export SHODAN_API="your-shodan-api-key"

# Look up an IP (services, ports, banners, vulns)
curl -s "https://api.shodan.io/shodan/host/166.62.100.52?key=${SHODAN_API}" | \
  jq '{ip: .ip_str, org: .org, os: .os, ports: .ports,
       vulns: .vulns, hostnames: .hostnames, country: .country_name,
       last_update: .last_update}'

# Search for C2 infrastructure patterns
curl -s "https://api.shodan.io/shodan/host/search?key=${SHODAN_API}&query=product:cobalt+strike" | \
  jq '.matches[] | {ip: .ip_str, port: .port, org: .org, country: .location.country_name}'

# Check if IP is a known scanner/bot
curl -s "https://api.shodan.io/shodan/host/166.62.100.52?key=${SHODAN_API}" | \
  jq '.tags'
```

#### AbuseIPDB

```bash
export ABUSE_KEY="your-abuseipdb-api-key"

# Check IP reputation
curl -s -G "https://api.abuseipdb.com/api/v2/check" \
  -H "Key: ${ABUSE_KEY}" \
  -H "Accept: application/json" \
  -d "ipAddress=166.62.100.52" \
  -d "maxAgeInDays=90" \
  -d "verbose" | \
  jq '{abuseScore: .data.abuseConfidenceScore,
       totalReports: .data.totalReports,
       countryCode: .data.countryCode,
       isp: .data.isp,
       usageType: .data.usageType,
       domain: .data.domain}'
```

#### GreyNoise

```bash
export GN_KEY="your-greynoise-api-key"

# Check if IP is a known internet scanner
curl -s -H "key: ${GN_KEY}" \
  "https://api.greynoise.io/v3/community/166.62.100.52" | \
  jq '{noise: .noise, riot: .riot, classification: .classification,
       name: .name, message: .message}'
# noise=true: benign internet scanner
# riot=true: known legitimate service (CDN, DNS, etc.)
# Neither: potentially interesting/malicious
```

### 14.4 IOC Aging and Decay Model

| IOC Type | Default TTL | Decay Rationale |
|----------|-------------|-----------------|
| File Hash (SHA-256) | 12-24 months | Malware recompiles change hashes; unpacked samples have longer value |
| IPv4 Address | 30-90 days | Shared hosting, dynamic allocation, VPS turnover |
| Domain Name | 3-6 months | Domains may be sinkholed, seized, or re-registered |
| URL | 7-30 days | Paths change, pages taken down, infrastructure rotated |
| Email Address | 6-12 months | Phishing accounts get burned or abandoned |
| JA3/JA3S Fingerprint | 6-12 months | Tied to TLS implementation, more stable than IPs |
| YARA Rule (behavioral) | 12+ months | Detects code patterns, survives recompilation |
| TTP / Sigma Rule | 24+ months | Behavioral patterns are hardest to change |
| SSL Certificate Hash | 6-12 months | Certificates rotate but slower than IPs |

**Decay Score Formula** (simplified):

```
decay_score = initial_confidence * (1 - (days_since_last_seen / ttl_days))
if decay_score < threshold (e.g., 20%):
    move to archive / stop alerting
if last_sighted recently:
    reset decay clock
```

### 14.5 False Positive Management

| FP Scenario | Handling |
|-------------|----------|
| IP belongs to CDN (Cloudflare, Akamai, AWS) | Add to warninglist; do NOT block; alert on specific URI patterns instead |
| Domain is parked/sinkholed | Verify current resolution; mark as historical if sinkholed |
| Hash matches legitimate tool (PsExec, Rclone) | Use filename+hash composite; add context about malicious use vs. legitimate |
| IP rotated to legitimate customer | Check Shodan/Censys for current services; expire if clean |
| Shared hosting IP | Lower confidence; require corroborating indicators before alerting |
| DNS sinkhole resolves old C2 domain | Sinkhole IPs should be in warninglist; monitor for queries, not connections |
| Known-good software flagged (sysmon, wireshark) | Whitelist by path + hash; investigate if unexpected path |

**FP Reduction Workflow**:
1. Alert fires on IOC match
2. Analyst checks warninglist — if match, suppress
3. Analyst checks current enrichment (VT, Shodan) — if clean, decay
4. Analyst checks correlation — if no other IOCs match, likely FP
5. If confirmed FP: add to local warninglist, document reason, reduce confidence
6. If confirmed TP: reset decay clock, raise confidence, escalate

---

## 15. Intelligence-to-Detection Pipeline

### 15.1 Pipeline Overview

```
IOC/TTP Received → Sigma Rule → YARA Rule → Suricata/Snort Rule
                        ↓              ↓              ↓
                   SIEM Deploy    Endpoint Deploy  Network Deploy
                   (Splunk/ELK)  (YARA scanner)   (IDS/IPS)
```

### 15.2 Example: LockBit C2 Communication — Full Pipeline

**Source Intelligence**: LockBit 3.0 C2 callback to 166.62.100[.]52:2460 via Meterpreter stager

#### Step 1: Sigma Rule (SIEM Detection)

```yaml
title: Meterpreter Stager Network Connection to Known LockBit C2
id: 8a3f7b2e-1d4c-4e9f-b5a6-c8d2e3f4a5b6
status: experimental
description: Detects outbound network connection to known LockBit C2 infrastructure on non-standard port, indicating Meterpreter stager callback.
references:
  - https://thedfirreport.com/
logsource:
  category: network_connection
  product: windows
detection:
  selection_ip:
    DestinationIp: '166.62.100.52'
  selection_port:
    DestinationPort: 2460
  condition: selection_ip or selection_port
falsepositives:
  - Legitimate application using port 2460 to this specific IP (verify with application owner)
level: critical
tags:
  - attack.t1071
  - attack.command_and_control
```

#### Step 2: Sigma Rule — Behavioral (LSASS Dump via comsvcs.dll)

```yaml
title: LSASS Memory Dump via comsvcs.dll MiniDump
id: 1be07628-7d7a-4cb2-bd76-47194349e26d
status: stable
description: Detects credential dumping from LSASS using comsvcs.dll MiniDump export, observed in LockBit, Akira, and Lunar Spider intrusions.
references:
  - https://thedfirreport.com/
logsource:
  category: process_creation
  product: windows
detection:
  selection_cmdline:
    CommandLine|contains|all:
      - 'comsvcs'
      - 'MiniDump'
  selection_rundll:
    Image|endswith: '\rundll32.exe'
    CommandLine|contains: 'comsvcs.dll'
  condition: selection_cmdline or selection_rundll
falsepositives:
  - Legitimate crash dump collection by IT diagnostics tools (verify calling process)
level: critical
tags:
  - attack.t1003.001
  - attack.credential_access
```

#### Step 3: Sigma Rule — Behavioral (Rclone Exfiltration)

```yaml
title: Rclone Execution or Renamed Binary for Data Exfiltration
id: e4a5b6c7-d8e9-4f01-a2b3-c4d5e6f7a8b9
status: experimental
description: Detects Rclone execution including renamed binaries, commonly used for large-scale data exfiltration to attacker-controlled cloud storage.
logsource:
  category: process_creation
  product: windows
detection:
  selection_name:
    Image|endswith: '\rclone.exe'
  selection_renamed:
    OriginalFileName: 'rclone.exe'
  selection_cmdline:
    CommandLine|contains:
      - 'rclone'
      - '--config'
      - 'copy --'
      - 'sync --'
      - ':sftp:'
      - ':ftp:'
      - ':s3:'
      - ':mega:'
  condition: selection_name or selection_renamed or selection_cmdline
falsepositives:
  - IT-approved Rclone usage for legitimate cloud sync (whitelist by parent process and scheduled task)
level: high
tags:
  - attack.t1567
  - attack.exfiltration
```

#### Step 4: YARA Rule (Endpoint / Malware Detection)

```yara
rule LockBit3_Ransomware_LeakedBuilder
{
    meta:
        description = "Detects LockBit 3.0 ransomware built from leaked builder, including variants with -psex SMB spreader flag"
        author = "CIPHER"
        date = "2026-03-15"
        reference = "https://thedfirreport.com/"
        tlp = "TLP:CLEAR"
        mitre_attack = "T1486"
        severity = "critical"
        hash1 = "C8646CFB574FF2C6F183C3C3951BF6B2C6CF16FF8A5E949A118BE27F15962FAE"

    strings:
        $lockbit_note1 = "your data are stolen and encrypted" ascii wide nocase
        $lockbit_note2 = "the data will be published on TOR" ascii wide nocase
        $lockbit_mutex = "Global\\%s" ascii
        $psex_flag = "-psex" ascii
        $session_msg = "session.id" ascii
        $lockbit_ext = ".lockbit" ascii wide
        $ransom_hta = "LBB_Decryption_ID" ascii wide
        $crypto1 = { 48 8B 05 ?? ?? ?? ?? 48 89 44 24 ?? 48 8D 0D }
        $crypto2 = { C7 44 24 ?? 00 00 00 00 48 8D 44 24 ?? 48 89 44 24 }

    condition:
        uint16(0) == 0x5A4D and
        filesize < 5MB and
        (
            (2 of ($lockbit_note*, $lockbit_ext, $ransom_hta)) or
            ($psex_flag and $lockbit_ext) or
            (all of ($crypto*) and 1 of ($lockbit_*))
        )
}

rule Meterpreter_Reverse_TCP_Stager
{
    meta:
        description = "Detects Meterpreter reverse TCP stager shellcode patterns"
        author = "CIPHER"
        date = "2026-03-15"
        mitre_attack = "T1059.006"
        severity = "critical"

    strings:
        $api_hash_ws2 = { 06 B2 D1 76 }  // WSAStartup hash
        $api_hash_connect = { 6B 80 4D 6C }  // connect hash
        $api_hash_recv = { FF 38 D4 E0 }  // recv hash
        $shellcode_header = { FC E8 ?? 00 00 00 }  // classic stager preamble
        $socket_setup = { 6A 05 68 ?? ?? ?? ?? 68 02 00 }  // socket AF_INET

    condition:
        2 of ($api_hash_*) and ($shellcode_header or $socket_setup)
}

rule Rclone_Config_Exfil_Artifact
{
    meta:
        description = "Detects Rclone configuration files indicating exfiltration setup"
        author = "CIPHER"
        date = "2026-03-15"
        mitre_attack = "T1567"
        severity = "high"

    strings:
        $header = "[" ascii
        $type_sftp = "type = sftp" ascii nocase
        $type_ftp = "type = ftp" ascii nocase
        $type_s3 = "type = s3" ascii nocase
        $type_mega = "type = mega" ascii nocase
        $host = "host =" ascii nocase
        $user = "user =" ascii nocase
        $pass = "pass =" ascii nocase

    condition:
        filesize < 10KB and
        $header at 0 and
        1 of ($type_*) and
        $host and ($user or $pass)
}
```

#### Step 5: Suricata Rules (Network Detection)

```
# LockBit C2 IP detection
alert ip any any -> 166.62.100.52 any (msg:"ET MALWARE LockBit C2 Server Communication"; classtype:trojan-activity; sid:2026001; rev:1; metadata:attack_target Client_Endpoint, created_at 2026_03_15, deployment Perimeter, signature_severity Critical, tag LockBit, mitre_tactic_id TA0011, mitre_technique_id T1071;)

# Meterpreter reverse TCP on non-standard port
alert tcp $HOME_NET any -> $EXTERNAL_NET 2460 (msg:"ET MALWARE Possible Meterpreter Reverse TCP on Port 2460"; flow:established,to_server; content:"|00 00 00|"; offset:0; depth:3; byte_test:4,>,0,0; classtype:trojan-activity; sid:2026002; rev:1; metadata:attack_target Client_Endpoint, created_at 2026_03_15, signature_severity Critical, mitre_technique_id T1571;)

# Rclone SFTP exfiltration pattern (large outbound transfer)
alert tcp $HOME_NET any -> $EXTERNAL_NET 22 (msg:"ET EXFIL Possible Rclone SFTP Data Exfiltration - Large Transfer"; flow:established,to_server; stream_size:server,>,1000000; threshold:type limit, track by_src, count 1, seconds 3600; classtype:policy-violation; sid:2026003; rev:1; metadata:created_at 2026_03_15, signature_severity Major, mitre_technique_id T1048;)

# AnyDesk non-standard installation (persistence indicator)
alert dns $HOME_NET any -> any any (msg:"ET POLICY AnyDesk Remote Access Client DNS Lookup"; dns.query; content:"anydesk.com"; nocase; classtype:policy-violation; sid:2026004; rev:1; metadata:created_at 2026_03_15, signature_severity Informational, mitre_technique_id T1219;)

# RustDesk remote access DNS lookup
alert dns $HOME_NET any -> any any (msg:"ET POLICY RustDesk Remote Access Client DNS Lookup"; dns.query; content:"rustdesk.com"; nocase; classtype:policy-violation; sid:2026005; rev:1; metadata:created_at 2026_03_15, signature_severity Informational, mitre_technique_id T1219;)

# SUNBURST DGA subdomain pattern (APT29)
alert dns $HOME_NET any -> any any (msg:"ET MALWARE SUNBURST DGA DNS Query to avsvmcloud.com"; dns.query; content:"avsvmcloud.com"; nocase; classtype:trojan-activity; sid:2026006; rev:1; metadata:created_at 2026_03_15, signature_severity Critical, tag APT29, mitre_technique_id T1568.002;)

# temp.sh exfiltration (used by Lynx ransomware operators)
alert http $HOME_NET any -> $EXTERNAL_NET any (msg:"ET EXFIL Upload to temp.sh File Sharing Service"; flow:established,to_server; http.host; content:"temp.sh"; http.method; content:"PUT"; classtype:policy-violation; sid:2026007; rev:1; metadata:created_at 2026_03_15, signature_severity Major, mitre_technique_id T1567.002;)
```

### 15.3 Sigma → SIEM Conversion Commands

```bash
# Install sigma-cli
pip install sigma-cli pySigma-backend-splunk pySigma-backend-elasticsearch \
    pySigma-pipeline-sysmon pySigma-pipeline-windows

# Convert Sigma to Splunk SPL
sigma convert -t splunk -p splunk_windows rule.yml
# Output: index=main sourcetype=WinEventLog EventCode=1 CommandLine="*comsvcs*MiniDump*"

# Convert Sigma to Elastic/Kibana (ECS)
sigma convert -t elasticsearch -p ecs_windows rule.yml

# Convert Sigma to Microsoft Sentinel KQL
sigma convert -t microsoft365defender rule.yml

# Convert Sigma to QRadar AQL
sigma convert -t qradar rule.yml

# Batch convert directory of rules
sigma convert -t splunk -p splunk_windows rules/*.yml > splunk_rules.conf
```

### 15.4 Detection Coverage Matrix

| Attack Phase | IOC-Based | Sigma (SIEM) | YARA (Endpoint) | Suricata (Network) |
|-------------|-----------|--------------|------------------|---------------------|
| Initial Access (exploit) | CVE matching | Web log anomaly | Exploit payload match | Exploit signature |
| Loader Execution | Hash block | Process creation | Binary pattern match | Download detection |
| C2 Communication | IP/domain block | DNS/proxy log match | Config file detection | Traffic signature |
| Credential Dumping | — | LSASS access events | Mimikatz patterns | — |
| Lateral Movement | — | Auth log correlation | PsExec patterns | SMB anomaly |
| Exfiltration | IP block | Rclone/FTP detection | Config artifacts | Volume anomaly |
| Ransomware | Hash block | File encryption events | Ransomware binary | Ransom note in SMB |

---

## 16. Traffic Light Protocol (TLP) Quick Reference

### 16.1 TLP Designations (v2.0 — FIRST Standard)

| TLP Level | Color | Sharing Scope | Use When |
|-----------|-------|---------------|----------|
| **TLP:RED** | Red | Named recipients only | Source at risk; information cannot be shared outside specific individuals in the meeting/conversation |
| **TLP:AMBER+STRICT** | Amber | Recipient's organization only | Needs-to-know within the organization; NO sharing with clients or partners |
| **TLP:AMBER** | Amber | Recipient's organization + clients/customers who need to know | Information risk to privacy, reputation, or operations if shared beyond need-to-know |
| **TLP:GREEN** | Green | Recipient's community/sector | Useful for awareness within the broader community but not public; peers, partner orgs, ISACs |
| **TLP:CLEAR** | White/Clear | No restriction | Public information; can be shared freely, posted publicly, used in blog posts |

### 16.2 TLP Decision Matrix

| Question | If Yes → |
|----------|----------|
| Could sharing endanger a human source? | TLP:RED |
| Is it specific to one organization's vulnerability? | TLP:AMBER+STRICT |
| Should customers/partners of the org be informed? | TLP:AMBER |
| Useful for the sector but not for public attribution? | TLP:GREEN |
| Already public or no sensitivity? | TLP:CLEAR |

### 16.3 TLP in Practice

| Context | Typical TLP | Rationale |
|---------|-------------|-----------|
| Active 0-day exploit details | TLP:RED | Premature disclosure enables mass exploitation |
| IOCs from an ongoing IR engagement | TLP:AMBER+STRICT | Client confidentiality; attribution risk |
| IOCs shared to ISAC members | TLP:AMBER | Need-to-know for sector defense |
| Threat advisory for sector awareness | TLP:GREEN | Community benefit without exposing specific victims |
| Published CVE details and patches | TLP:CLEAR | Already public |
| CISA advisory | TLP:CLEAR | Government public advisory |
| Ransomware negotiation details | TLP:RED | Operational security for victim |
| ATT&CK mapping of a known campaign | TLP:GREEN | General awareness, no victim details |
| Sigma rules for known TTPs | TLP:CLEAR | Detection rules benefit everyone |

### 16.4 TLP Header Format

```
# In emails and documents:
TLP:RED — For named recipients only
TLP:AMBER+STRICT — For recipient's organization only
TLP:AMBER — Limited distribution (organization + clients who need to know)
TLP:GREEN — Community distribution
TLP:CLEAR — Unlimited distribution

# In STIX objects:
{
  "type": "marking-definition",
  "spec_version": "2.1",
  "id": "marking-definition--f88d31f6-486f-44da-b317-01333bde0b82",
  "created": "2017-01-20T00:00:00.000Z",
  "definition_type": "tlp",
  "name": "TLP:AMBER",
  "definition": { "tlp": "amber" }
}

# In MISP events:
Tag: "tlp:amber"
```

---

## 17. Additional APT Profiles — Extended Reference

### 17.1 Volt Typhoon

| Field | Detail |
|-------|--------|
| **Aliases** | BRONZE SILHOUETTE, Vanguard Panda, DEV-0391, Insidious Taurus |
| **MITRE ID** | G1017 |
| **Country** | People's Republic of China (PRC) |
| **Attribution** | PRC state-sponsored |
| **Motivation** | Pre-positioning for disruption of US critical infrastructure in a Taiwan conflict scenario |
| **Active Since** | Mid-2021 (public disclosure May 2023) |
| **Target Sectors** | Communications, energy, transportation, water/wastewater, US military (Guam) |
| **Target Geography** | United States, US territories (Guam), critical infrastructure globally |

| Key TTPs | MITRE ID | Detail |
|----------|----------|--------|
| Living-off-the-land | T1059.001, T1059.003 | Almost exclusively uses built-in OS tools (PowerShell, cmd, wmic, netsh) |
| SOHO Router Compromise | T1584.008 | Compromises small office/home routers (Netgear, ASUS, Cisco) as ORBs |
| KV Botnet | T1584 | Botnet of compromised SOHO devices for proxying C2 traffic |
| Credential Harvesting | T1003 | ntds.dit extraction, LSASS dumping via native tools |
| Valid Accounts | T1078 | Uses legitimate credentials extensively — avoids malware deployment |
| Network Tunneling | T1572 | Proxies traffic through compromised network devices to blend with legitimate traffic |
| Log Evasion | T1070 | Clears/modifies logs; minimal forensic footprint |
| No Custom Malware | — | Avoids dropping compiled malware; relies on legitimate binaries and scripts |

| Detection Tips |
|----------------|
| Monitor for anomalous use of wmic, ntdsutil, netsh, and PowerShell from non-admin users |
| Detect SOHO router traffic to internal critical infrastructure (unusual east-west from edge devices) |
| Audit ntds.dit access and Active Directory backup operations |
| Monitor for credential dumping using only built-in Windows tools |
| Track netsh portproxy configurations and IP forwarding changes |
| Hunt for unusual authentication from network device IP ranges to servers |
| Deploy network flow analysis — LOLBin activity lacks malware signatures |
| CISA advisory AA24-038A provides comprehensive detection guidance |

### 17.2 BlackCat / ALPHV

| Field | Detail |
|-------|--------|
| **Aliases** | ALPHV, Noberus, BlackCat, UNC4466 |
| **MITRE ID** | G1032 |
| **Country** | Russia-nexus (former DarkSide/BlackMatter affiliates) |
| **Attribution** | Cybercriminal — evolved from DarkSide (Colonial Pipeline) → BlackMatter → ALPHV |
| **Motivation** | Financial — ransomware-as-a-service (RaaS) with double extortion |
| **Active** | November 2021 — March 2024 (exit scam after Change Healthcare payment) |
| **Target Sectors** | Healthcare, financial, legal, government, critical infrastructure (no geographic/sector restrictions) |
| **Notable Attacks** | Change Healthcare ($22M ransom paid, Feb 2024), MGM Resorts (with Scattered Spider), Reddit |

| Key TTPs | MITRE ID | Detail |
|----------|----------|--------|
| Rust-based Ransomware | T1486 | First major ransomware written in Rust — cross-platform (Windows, Linux, VMware ESXi) |
| Affiliate Model | — | High affiliate commission (80-90%); attracted top-tier affiliates including Scattered Spider |
| Data Exfiltration | T1567 | ExMatter tool for automated data theft before encryption |
| ESXi Targeting | T1486 | Dedicated Linux/ESXi encryptor; VM infrastructure as primary target |
| Searchable Leak Site | T1491.002 | Leaked data made searchable on clearnet — increased extortion pressure |
| Impacket/CobaltStrike | T1021 | Standard lateral movement toolkit |
| Brute Ratel C4 | T1219 | Advanced C2 framework usage for EDR evasion |
| API for Victims | — | REST API on DLS for victims to negotiate and check status |

| Detection Tips |
|----------------|
| Monitor for Rust binary execution with high entropy (encrypted strings) |
| Detect ExMatter data staging (large archive creation + outbound transfer) |
| Watch for ESXi CLI commands: `esxcli vm process kill`, `esxcli system settings encryption set` |
| Alert on Impacket wmiexec/smbexec/psexec patterns |
| Monitor for bcdedit /set {default} safeboot changes (safe mode ransomware execution) |
| Track group policy modifications pushing scripts to domain-joined hosts |

### 17.3 Cl0p (TA505-affiliated)

| Field | Detail |
|-------|--------|
| **Aliases** | Cl0p, Clop, TA505, FIN11, DEV-0950, Lace Tempest, Dungeon Spider |
| **MITRE ID** | G0092 (TA505) |
| **Country** | Russia / Ukraine-nexus |
| **Attribution** | Cybercriminal — TA505 acts as access broker, Cl0p is the ransomware/extortion operation |
| **Motivation** | Financial — shifted from ransomware encryption to pure data theft extortion |
| **Active Since** | February 2019 (ransomware); 2023+ (mass exploitation campaigns) |
| **Target Sectors** | All sectors — focuses on file transfer appliances with mass exploitation |
| **Notable Attacks** | MOVEit (2,700+ orgs, 2023), GoAnywhere MFT (130+ orgs, 2023), Accellion FTA (2020-2021), Cleo (2024-2025) |

| Key TTPs | MITRE ID | Detail |
|----------|----------|--------|
| Mass Exploitation of File Transfer | T1190 | Targets zero-days in file transfer appliances (MOVEit, GoAnywhere, Cleo, Accellion) |
| SQL Injection | T1190 | Primary exploit class for file transfer products (CVE-2023-34362 MOVEit SQLi) |
| Web Shell Deployment | T1505.003 | Deploys web shells on compromised file transfer servers for persistence |
| Data Theft Without Encryption | T1530 | Post-2023: pure extortion via stolen data — no ransomware deployed in mass campaigns |
| Automated Exploitation | T1190 | Pre-stages exploits, mass-scans, and compromises hundreds of targets simultaneously |
| DLS Naming + Shaming | T1491.002 | Leak site with countdown timers; company names published to pressure payment |
| Zero-Day Stockpiling | — | Evidence suggests Cl0p stockpiles zero-days months before exploitation campaigns |
| SDBOT/FlawedAmmyy | T1219 | Legacy RATs used in earlier TA505 campaigns (pre-2023) |

| Detection Tips |
|----------------|
| Patch file transfer appliances immediately — Cl0p exploits 0-days within days of finding |
| Monitor file transfer servers for web shell creation (new .aspx, .jsp, .php files) |
| Detect SQL injection patterns in file transfer application logs (MOVEit: `X-siLock-Comment` header) |
| Alert on mass data download from file transfer servers outside business hours |
| Monitor for `cmdline.exe` and unusual IIS worker process children |
| Isolate file transfer appliances in DMZ with strict egress filtering |
| CISA advisory AA23-158A provides MOVEit-specific detection guidance |

### 17.4 LockBit (Extended Profile)

| Field | Detail |
|-------|--------|
| **Aliases** | LockBit, LockBit 2.0/3.0/Green, LockBitSupp, Water Selkie, Bitwise Spider |
| **MITRE ID** | — (tracked as operation, not single group) |
| **Country** | Russia-nexus (operator "LockBitSupp" identified as Dmitry Khoroshev by NCA/FBI, May 2024) |
| **Attribution** | Cybercriminal — largest RaaS operation by volume (2022-2024) |
| **Motivation** | Financial — ransomware-as-a-service |
| **Active** | September 2019 — present (disrupted by Operation Cronos, Feb 2024; attempting recovery) |
| **Target Sectors** | All sectors — 1,700+ known victims globally; no restrictions except CIS countries |
| **Notable Attacks** | Boeing, ICBC (largest bank in world), Royal Mail, Bangkok Airways, Accenture |

| Key TTPs | MITRE ID | Detail |
|----------|----------|--------|
| RaaS Platform | — | Professional affiliate portal; bug bounty program; multiple builder versions |
| Leaked Builder | T1486 | LockBit 3.0 builder leaked Sep 2022 — enables any actor to create custom LockBit variants |
| StealBit | T1041 | Custom exfiltration tool; automated data theft before encryption |
| SMB Spreader (-psex) | T1021.002 | Built-in lateral movement via SMB (PsExec-like); single binary does recon + spread |
| Self-Propagation | T1570 | Worm-like capability in LockBit 3.0; auto-spreads across network shares |
| Multi-OS Support | T1486 | Windows, Linux, VMware ESXi encryptors |
| Group Policy Deployment | T1484.001 | Uses AD Group Policy to push ransomware to all domain-joined systems |
| Affiliate Flexibility | — | Affiliates use any tooling for access; LockBit provides encryptor + DLS |
| Session Messenger | — | Moved negotiations from Tor/Jabber to Session (encrypted messenger) |
| Operation Cronos | — | Law enforcement disrupted Feb 2024; seized DLS, arrested affiliates; LockBit attempting rebuild |

| Detection Tips |
|----------------|
| Detect LockBit 3.0 leaked builder artifacts (command-line flags: `-psex`, `-pass`, `-path`) |
| Monitor for Group Policy modification pushing scripts/executables |
| Alert on StealBit network connections (custom protocol, high-volume outbound) |
| Detect VSS deletion (`vssadmin delete shadows /all /quiet`) and `bcdedit` boot config changes |
| Watch for `wmic shadowcopy delete` and Veeam backup job deletion |
| Monitor for Session messenger installation (unusual for enterprise environments) |
| LockBit leaked builder hashes are well-documented — deploy YARA rules for known variants |
| Flag any executable with `-psex` flag in command line arguments |

### 17.5 Extended APT Summary Table

| Group | Country | MITRE ID | Type | Motivation | Key Sectors | Signature TTP | Status (2026) |
|-------|---------|----------|------|------------|-------------|---------------|---------------|
| Volt Typhoon | China | G1017 | State | Pre-positioning / disruption | US critical infra, telecom | Living-off-the-land (no malware) | Active |
| Salt Typhoon | China | G1045 | State | Espionage | Telecom/ISP | Network device implants | Active |
| BlackCat/ALPHV | Russia-nexus | G1032 | Criminal | Financial | Healthcare, all sectors | Rust ransomware, ESXi targeting | Defunct (exit scam Mar 2024) |
| Cl0p/TA505 | Russia-nexus | G0092 | Criminal | Financial | File transfer appliance users | Mass 0-day exploitation, no encryption | Active |
| LockBit | Russia-nexus | — | Criminal | Financial | All sectors | Leaked builder, SMB spreader | Disrupted, attempting rebuild |
| Scattered Spider | US/UK | — | Criminal | Financial | Tech, telecom, hospitality | Help desk social engineering | Active (arrests ongoing) |
| Akira | Unknown | — | Criminal | Financial | All sectors | Malvertising, fast TTR | Active |
| Play/Playcrypt | Unknown | G1040 | Criminal | Financial | All sectors | Cross-group collaboration | Active |
| DragonForce | Unknown | — | Criminal | Financial | All sectors | RaaS ecosystem sharing | Active |
| Medusa | Unknown | G1051 | Criminal | Financial | Education, healthcare | Double extortion, DLS | Active |
| Rhysida | Unknown | — | Criminal | Financial | Healthcare, education, gov | Phishing, Cobalt Strike | Active |
| RansomHub | Unknown | — | Criminal | Financial | All sectors | Multi-affiliate RaaS | Active |
| Moonstone Sleet | North Korea | G1036 | State | Financial + Espionage | Crypto, tech | Fake companies, trojanized npm | Active |

### 17.6 Ransomware Group Evolution Timeline

```
2019 ─── LockBit v1 launched
2020 ─── DarkSide launched → Colonial Pipeline (May 2021) → rebrands to BlackMatter
2021 ─── BlackMatter → shuts down → affiliates move to ALPHV/BlackCat (Nov 2021)
       ─── LockBit 2.0 launched (Jun 2021) — becomes dominant RaaS
2022 ─── LockBit 3.0 launched (Jun 2022)
       ─── LockBit 3.0 builder leaked (Sep 2022) — enables independent operators
       ─── Conti disbands (May 2022) → affiliates scatter to Royal, Black Basta, Akira
2023 ─── Cl0p MOVEit mass exploitation (May 2023) — 2,700+ victims
       ─── Cl0p GoAnywhere exploitation (Jan 2023)
       ─── Akira emerges (Mar 2023) — ex-Conti affiliates suspected
       ─── ALPHV/BlackCat MGM + Change Healthcare
       ─── RansomHub emerges (late 2023)
       ─── Rhysida emerges — healthcare/education focus
       ─── Medusa activity surge
2024 ─── Operation Cronos disrupts LockBit (Feb 2024)
       ─── ALPHV/BlackCat exit scam after Change Healthcare $22M payment (Mar 2024)
       ─── LockBit attempts rebuild — reduced volume
       ─── Cl0p Cleo exploitation wave (late 2024)
       ─── DragonForce/Play/RansomHub interconnection observed
       ─── Scattered Spider arrests begin
2025 ─── LockBit leaked builder variants proliferate among independent operators
       ─── Akira, Play, RansomHub, Medusa as top-volume groups
       ─── Lynx emerges with fast encryption mode
2026 ─── 549 active ransomware groups tracked (RansomLook)
       ─── Ecosystem fragmentation: more groups, more affiliate mobility
       ─── IAB market mature: Lunar Spider, Exotic Lily selling access at scale
```

---

## 18. Quick Reference Checklists

### 18.1 IOC Received — Analyst Workflow

```
□ Classify IOC type (hash, IP, domain, URL, behavioral)
□ Assign TLP based on source restrictions
□ Enrich via VT, Shodan, AbuseIPDB, GreyNoise
□ Check against warninglists (known-good, CDN, sinkhole)
□ Correlate with existing MISP events
□ Assign confidence score (0-100%)
□ Set expiry date based on IOC type TTL
□ Map to ATT&CK technique and kill chain phase
□ Create/update MISP event with attributes
□ Generate detection rules (Sigma, YARA, Suricata as applicable)
□ Deploy to SIEM/IDS/endpoint
□ Document in TIP with full provenance
□ Schedule decay review
```

### 18.2 New Campaign Report — CTI Team Workflow

```
□ Ingest report and extract all IOCs (manual + automated)
□ Create MISP event with TLP and galaxy cluster tags
□ Build STIX bundle with relationships
□ Map full kill chain to ATT&CK Navigator
□ Generate Sigma rules for behavioral TTPs
□ Generate YARA rules for malware artifacts
□ Generate network signatures (Suricata/Snort)
□ Assess relevance to organization's PIRs
□ Produce tactical brief for SOC (IOCs + rules)
□ Produce operational brief for IR team (TTPs + detection gaps)
□ Produce strategic summary for leadership (if sector-relevant)
□ Share via TAXII/MISP sync to trusted partners (respecting TLP)
□ Update ATT&CK Navigator coverage heatmap
□ Schedule follow-up for related campaign activity
```
