<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Supplementary Security Knowledge

> Operational security patterns, platform-specific hardening techniques, and cross-domain
> security insights organized as actionable reference material.

---

## 1. Encrypted Backup Architecture

### Backup Encryption Best Practices
- Use `repokey-blake2`, `keyfile-blake2`, or `authenticated-blake2` encryption modes for backup repositories
- Integrate passphrase management with secret managers via passcommand (e.g., `secret-tool lookup borg-repository repo-name`)
- Systemd credential integration for passphrase management in service units
- Config files containing backup credentials should be chmod 600, owned by root or dedicated backup user

### Append-Only Repositories (Ransomware Defense)
- Append-only mode on backup repositories prevents attackers with backup credentials from deleting/modifying existing archives
- Critical defense against ransomware that targets backup infrastructure (MITRE T1490 — Inhibit System Recovery)
- Combined with separate prune credentials on a hardened server = defense in depth
- SSH key restrictions with `command=` in authorized_keys provide backup-specific access control

### Backup Verification & Integrity
- Repository integrity checks, archive consistency validation, and data extraction verification should be automated
- Configurable check frequency (e.g., every 2 weeks)
- Pre/post-backup hooks for integrity validation
- Monitoring integrations (Healthchecks.io, Uptime Kuma, PagerDuty, ntfy) detect silent backup failures
- Silent backup failure is a common precursor to ransomware impact — monitor backup health proactively

---

## 2. Browser Privacy Hardening

### Firefox Privacy Configuration (Comprehensive)

**Tracking Protection:**
- `browser.contentblocking.category = "strict"` — enables Total Cookie Protection (TCP), dynamic First-Party Isolation (dFPI)
- TCP partitions all third-party storage by top-level eTLD+1
- Partitioned caches: HTTP cache, image cache, favicon cache, HSTS cache, OCSP cache, TLS cert cache, DNS cache, font cache
- Bounce tracking protection (`privacy.bounceTrackingProtection.mode = 1`)
- Query stripping: removes tracking parameters (utm_*, fbclid, gclid, etc.)

**Certificate Revocation:**
- CRLite (`security.pki.crlite_mode = 2`) preferred over OCSP (`security.OCSP.enabled = 0`)
- CRLite is faster, more private — no IP/domain leak to Certificate Authority
- HPKP enforcement available (`security.cert_pinning.enforcement_level = 2`) — strict mode

**TLS Hardening:**
- `security.ssl.treat_unsafe_negotiation_as_broken = true` — visual warning on broken TLS
- `security.tls.enable_0rtt_data = false` — disables 0-RTT (not forward secret, replay vulnerable)
- Post-quantum key exchange: `security.tls.enable_kyber = true`
- Safe renegotiation: `security.ssl.require_safe_negotiation = true` (99.8% compatibility)

**Fingerprinting Defense:**
- FingerPrint Protection (FPP) with daily randomization reset
- Resist Fingerprinting (RFP) available but with usability tradeoffs
- Window size rounding (letterboxing) prevents viewport fingerprinting

**Speculative Connection Prevention:**
- `network.http.speculative-parallel-limit = 0` — no speculative connections
- DNS prefetch disabled for both HTTP and HTTPS documents
- Link prefetch disabled (`network.prefetch-next = false`)
- URL bar speculative connect disabled, Network Predictor disabled

**Privacy Signals:**
- GPC (Global Privacy Control) — `privacy.globalprivacycontrol.enabled = true`
- Legally binding under CCPA and some EU jurisdictions

**Disk Forensics Defense:**
- `browser.cache.disk.enable = false` — no disk cache (memory only)
- Private browsing media forced to memory cache (64MB)
- Session save interval increased to 60s (reduced disk writes)
- Configurable sanitize-on-shutdown for cookies, site data, history

**Enterprise Deployment:**
- policies.json disables telemetry, studies, feedback
- Auto-installs privacy extensions (uBlock Origin)
- Pre-configures privacy-respecting search engines
- Deploy via GPO/MDM for organizational Firefox hardening

---

## 3. Windows Privacy Hardening — Registry Reference

### Activity & Telemetry Suppression
Common registry keys for Windows 10/11 privacy hardening:

- `HKLM:\SOFTWARE\Policies\Microsoft\Windows\System`
  - `EnableActivityFeed = 0`
  - `PublishUserActivities = 0`
  - `UploadUserActivities = 0`
- Location tracking: `CapabilityAccessManager\ConsentStore\location` = Deny
- DiagTrack service: disabled (telemetry collection)
- Advertising ID: disabled via policy
- Hibernation disabled: prevents hiberfil.sys from containing memory dumps (forensics defense)

### DNS Configuration for Windows Endpoints
Pre-configured protective DNS providers for endpoint hardening:
- **Cloudflare**: 1.1.1.1 / 1.0.0.1 (2606:4700:4700::1111 / ::1001)
- **Cloudflare Malware**: 1.1.1.2 / 1.0.0.2 — blocks known malware domains
- **Cloudflare Malware+Adult**: 1.1.1.3 / 1.0.0.3
- **Quad9**: 9.9.9.9 / 149.112.112.112 — malware blocking with privacy
- **AdGuard**: 94.140.14.14 / 94.140.15.15 — ad/tracker blocking
- Applied to all active network interfaces via `Set-DnsClientServerAddress`

### Windows Firewall — ICMP Configuration
Allow ping for diagnostics while maintaining firewall posture:
```
netsh advfirewall firewall add rule name="ICMP Allow incoming V4 echo request" protocol="icmpv4:8,any" dir=in action=allow
netsh advfirewall firewall add rule name="ICMP Allow incoming V6 echo request" protocol="icmpv6:8,any" dir=in action=allow
```

### Windows 11 UI Security Considerations
- Legacy context menu restoration: `HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32`
- Windows Firewall Control (BiniSoft/Malwarebytes) — provides proper outbound firewall visibility that Windows Firewall GUI lacks
- autounattend.xml generation enables automated hardened Windows deployments with reproducible baselines

### Windows Debloating — Security Tradeoffs
- Debloating tools remove telemetry, pre-installed apps, and background services
- Security features that may be optionally toggled: Defender, SmartScreen, Windows Update, UAC, Core Isolation, CPU Mitigations
- Uses auditable playbook scripts (plaintext, reviewable before execution)
- Red team relevance: understanding which security features can be disabled and how they affect attack surface

---

## 4. Supply Chain Security — Script Execution Anti-Patterns

### The `irm | iex` Anti-Pattern
Multiple Windows tools use PowerShell's `Invoke-RestMethod | Invoke-Expression` for installation. This is a significant supply chain risk:

- Domain compromise = arbitrary code execution on every user who runs it
- No integrity verification before execution
- No version pinning
- **Recommendation**: always `git clone` and review, or download with hash verification
- DoH bypass variant: `curl.exe -s --doh-url https://1.1.1.1/dns-query` — evades ISP/DNS-based blocking of script sources
- Clones of popular tools are a common malware delivery vector

### Package Manager Security
- User-space package installation (no UAC required) reduces privilege exposure
- JSON manifests with hash verification provide auditable integrity checking
- Community-maintained package repositories are a supply chain attack surface — verify sources
- `Set-ExecutionPolicy RemoteSigned` weakens PowerShell's default script restrictions

### Archive Tool Security
- Archive handling is a common attack vector (zip slip attacks, malformed archives)
- AES-256 encryption for archive files is acceptable for file-level encryption
- Prefer signed/verified packages over unsigned installers
- Keep archive tools updated — they process untrusted file formats

---

## 5. Windows DLL Injection & API Hooking — Detection Reference

### Technique Analysis (Security Research Value)
- Global DLL injection = same technique used by rootkits, EDR bypass tools, and legitimate customization tools
- API hooking operates at the same level as Detours, MinHook, or IAT patching
- Understanding this architecture is essential for:
  - EDR/AV bypass research (MITRE T1055 — Process Injection)
  - Detection engineering: monitoring for unsigned DLL loads, hook detection
  - Blue team: distinguishing legitimate tools from malicious tools using identical techniques

### Detection Guidance
- Monitor for unexpected DLL loads into processes, especially unsigned DLLs
- Track process injection events via ETW (Event Tracing for Windows)
- Correlate with Sysmon Event IDs 7 (Image loaded) and 8 (CreateRemoteThread)

---

## 6. AI Agent Security Patterns

### Core Principles
- LLM instruction following is probabilistic, not deterministic
- System prompt instructions ("CLAUDE.md") are guidance, not enforcement — "MUST" in all caps still ignored ~20% of time
- Context window exhaustion degrades instruction adherence (>50% context = "dumb zone")
- All AI agent operations should be sandboxed and permission-scoped

### Deterministic Security Enforcement via Hooks
- PreToolUse hooks can BLOCK dangerous commands before execution
- Example dangerous patterns to block:
  - `rm -rf` variants, `sudo rm`, `chmod 777`, writes to `/etc/`
- Exit code 2 = BLOCK (fed back to AI automatically)
- PostToolUse hooks validate results after tool completion
- 60-second timeout per hook, all matching hooks run in parallel

### Separation of Duties Pattern
- Builder agent (all tools) + Validator agent (read-only, no Write/Edit)
- PostToolUse validators for linting, type checking on generated code
- Auto-allow for read-only operations + block for write operations = sensible default policy

### Audit & Compliance for AI Operations
- All hook events logged as JSON with timestamps and session IDs
- User prompt audit logging
- Permission request audit log
- Session start/end logging with reason tracking

### Agent Team Security
- Sub-agents start fresh with NO conversation history — security context must be re-established
- Agent teams require careful permission isolation to prevent privilege escalation between agents
- Sandbox mode is the correct approach for untrusted operations

---

## 7. Forensics Defense Techniques

### Understanding What Adversaries Want to Hide
- Disk cache disabled (memory only) prevents recovery of browsing artifacts
- Hibernation file (hiberfil.sys) contains memory dumps — disable for forensics defense
- Plausible deniability filesystems (Shufflecake) create hidden volumes
- Session data sanitize-on-shutdown removes cookies, site data, history

### What Defenders Should Collect
- Memory before disk — volatile evidence first
- Hiberfil.sys and pagefile.sys contain process memory fragments
- Browser cache and history reconstruct user activity timeline
- Registry hives contain evidence of application execution, USB connections, network activity

---

## 8. Activation & Licensing — Detection Engineering Reference

### Technique Awareness (Detection, Not Implementation)
Understanding unauthorized activation techniques is relevant for:
- **Forensics**: detecting unauthorized activation on corporate endpoints
- **Detection engineering**: monitor for trusted store manipulation artifacts, KMS emulation traffic, hook DLLs in Office directories
- **Incident response**: cloned activation tools are a common malware delivery vector

### Detection Indicators
- Hardware-based digital entitlement manipulation
- Office activation via hook DLL injection
- Trusted Store file manipulation
- KMS emulation network traffic (port 1688)
- DoH bypass to evade DNS-based security controls
