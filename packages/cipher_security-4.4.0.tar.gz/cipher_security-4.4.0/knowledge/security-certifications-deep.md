<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Security Certifications Deep Reference Guide

> CIPHER Training Reference — Comprehensive certification study guide covering exam domains,
> weighted knowledge areas, study resources, and lab recommendations.
>
> Last updated: 2026-03-14

---

## Table of Contents

1. [Certification Landscape & Career Pathing](#certification-landscape--career-pathing)
2. [Offensive Security Certifications](#offensive-security-certifications)
   - [OSCP — OffSec Certified Professional](#oscp--offsec-certified-professional)
   - [OSCE3 — OffSec Certified Expert 3](#osce3--offsec-certified-expert-3)
   - [CRTP / CRTE — Certified Red Team Professional / Expert](#crtp--crte--certified-red-team-professional--expert)
3. [Governance, Risk & Management Certifications](#governance-risk--management-certifications)
   - [CISSP — Certified Information Systems Security Professional](#cissp--certified-information-systems-security-professional)
   - [CISM — Certified Information Security Manager](#cism--certified-information-security-manager)
   - [CISA — Certified Information Systems Auditor](#cisa--certified-information-systems-auditor)
   - [CRISC — Certified in Risk and Information Systems Control](#crisc--certified-in-risk-and-information-systems-control)
4. [Vendor-Neutral Technical Certifications](#vendor-neutral-technical-certifications)
   - [CEH — Certified Ethical Hacker](#ceh--certified-ethical-hacker)
   - [CompTIA Security+](#comptia-security)
   - [CompTIA CySA+](#comptia-cysa)
   - [CompTIA PenTest+](#comptia-pentest)
5. [SANS / GIAC Certifications](#sans--giac-certifications)
   - [GSEC — GIAC Security Essentials](#gsec--giac-security-essentials)
   - [GCIH — GIAC Certified Incident Handler](#gcih--giac-certified-incident-handler)
   - [GPEN — GIAC Penetration Tester](#gpen--giac-penetration-tester)
   - [GWAPT — GIAC Web Application Penetration Tester](#gwapt--giac-web-application-penetration-tester)
6. [Cloud Security Certifications](#cloud-security-certifications)
   - [AWS Certified Security — Specialty](#aws-certified-security--specialty)
   - [AZ-500 — Azure Security Engineer Associate](#az-500--azure-security-engineer-associate)
   - [Google Professional Cloud Security Engineer](#google-professional-cloud-security-engineer)
   - [CCSP — Certified Cloud Security Professional](#ccsp--certified-cloud-security-professional)
7. [Study Strategy & General Resources](#study-strategy--general-resources)
8. [Lab Environment Recommendations](#lab-environment-recommendations)

---

## Certification Landscape & Career Pathing

### Progression Tiers

```
ENTRY (0-2 yrs)          PRACTITIONER (2-5 yrs)       EXPERT (5+ yrs)
-----------------        ----------------------        ----------------
CompTIA Security+   -->  CySA+ / PenTest+        -->  CISSP / CISM
CEH                 -->  GSEC / GCIH             -->  GPEN / GWAPT
                         OSCP                    -->  OSCE3
                         CRTP                    -->  CRTE
                         AWS/Azure Security      -->  CCSP
                         CISA                    -->  CRISC
```

### Domain Mapping

| Career Track | Entry | Mid | Senior |
|---|---|---|---|
| **Penetration Testing** | Security+ / CEH | OSCP / PenTest+ / GPEN | OSCE3 / CRTE |
| **SOC / Blue Team** | Security+ / GSEC | CySA+ / GCIH | GCIA / CISSP |
| **GRC / Audit** | Security+ | CISA / CISM | CISSP / CRISC |
| **Cloud Security** | Cloud vendor associate | AWS/Azure/GCP Security | CCSP / CISSP |
| **Red Team** | OSCP / CRTP | CRTE / GPEN | OSCE3 |
| **AppSec** | Security+ | GWAPT / OSWA | OSWE (part of OSCE3) |

---

## Offensive Security Certifications

### OSCP — OffSec Certified Professional

**Issuer**: Offensive Security (OffSec)
**Prerequisite Course**: PEN-200 (Penetration Testing with Kali Linux)
**Cost**: $1,749+ (Learn One subscription) | $2,749+ (Learn Unlimited)
**Exam Duration**: 23 hours 45 minutes + 24 hours report writing
**Passing Score**: 70 / 100 points
**Format**: Proctored hands-on practical exam — compromise machines in a lab environment
**Recertification**: No expiration (lifetime credential)

#### Exam Structure

| Component | Points | Details |
|---|---|---|
| 3 standalone machines | 20 pts each (60 total) | Full compromise = 20 pts; local.txt = 10 pts |
| 1 Active Directory set | 40 pts | 3-machine AD chain; all-or-nothing |
| Bonus points | 10 pts | Exercise reports + 30 correct Proving Grounds machines |

**Total possible**: 110 points. **Pass**: 70 points.

#### Exam Domains & Key Study Topics

**Domain 1: Information Gathering & Enumeration**
- Network scanning with Nmap (SYN, TCP connect, UDP, version, script scans)
- Service enumeration: FTP (21), SSH (22), SMTP (25), DNS (53), HTTP/S (80/443), SMB (139/445), SNMP (161), LDAP (389/636), MSSQL (1433), RDP (3389), WinRM (5985/5986)
- Web enumeration: Gobuster, ffuf, feroxbuster for directory/file brute-forcing
- DNS enumeration: zone transfers, subdomain brute-forcing
- SMB enumeration: enum4linux-ng, smbclient, smbmap, CrackMapExec
- SNMP enumeration: snmpwalk, onesixtyone
- LDAP enumeration for AD environments

**Domain 2: Web Application Attacks**
- SQL injection (union-based, blind boolean, blind time-based, error-based)
- Cross-site scripting (reflected, stored, DOM-based)
- Server-side template injection (SSTI) — Jinja2, Twig, Freemarker
- Local/Remote file inclusion (LFI/RFI) with log poisoning
- Server-side request forgery (SSRF)
- Command injection and OS command execution
- File upload bypass techniques
- Directory traversal
- Insecure deserialization
- Authentication bypass techniques

**Domain 3: Linux Privilege Escalation**
- SUID/SGID binary abuse (GTFOBins reference)
- Sudo misconfigurations (`sudo -l` enumeration)
- Cron job exploitation (writable scripts, PATH hijacking)
- Kernel exploits (DirtyPipe CVE-2022-0847, DirtyCow CVE-2016-5195, Looney Tunables CVE-2023-4911)
- Writable /etc/passwd or /etc/shadow
- Capabilities abuse (`getcap -r / 2>/dev/null`)
- NFS no_root_squash exploitation
- Wildcard injection in tar/rsync
- Service exploitation (writable service files)
- Docker/LXD group membership escape
- Enumeration tools: linpeas.sh, linux-exploit-suggester, LinEnum

**Domain 4: Windows Privilege Escalation**
- Service binary hijacking and unquoted service paths
- DLL hijacking and DLL search order abuse
- Token impersonation: JuicyPotato, PrintSpoofer, GodPotato, SweetPotato
- AlwaysInstallElevated MSI exploitation
- Scheduled task manipulation
- Registry AutoRun and AutoLogon credential extraction
- SeImpersonatePrivilege / SeAssignPrimaryTokenPrivilege abuse
- UAC bypass techniques
- Enumeration tools: winPEAS, Seatbelt, PowerUp, SharpUp, PrivescCheck

**Domain 5: Active Directory Attacks**
- AD enumeration: BloodHound/SharpHound, PowerView, ADModule
- LLMNR/NBT-NS poisoning with Responder
- SMB relay attacks (ntlmrelayx)
- Kerberoasting (GetUserSPNs.py, Rubeus)
- AS-REP Roasting (GetNPUsers.py)
- Pass-the-Hash (evil-winrm, psexec.py, wmiexec.py, smbexec.py)
- Pass-the-Ticket (Rubeus, mimikatz)
- DCSync attack (secretsdump.py)
- Golden/Silver ticket attacks
- AD Certificate Services abuse (Certipy, ESC1-ESC8)
- Constrained/Unconstrained delegation exploitation
- Group policy abuse
- Trust relationship attacks
- ZeroLogon (CVE-2020-1472)

**Domain 6: Post-Exploitation & Lateral Movement**
- Credential harvesting: mimikatz, pypykatz, LaZagne
- File transfer techniques: certutil, PowerShell IWR, curl, SCP, SMB, HTTP servers
- Pivoting and tunneling: chisel, ligolo-ng, sshuttle, SSH tunnels
- Reverse shell generation and upgrade to full TTY
- Port forwarding (local, remote, dynamic)
- Living-off-the-land binaries (LOLBins/LOLBas)

**Domain 7: Buffer Overflow (Legacy/Reduced Weight)**
- Stack-based buffer overflow methodology
- Fuzzing, offset identification, bad character analysis
- Shellcode generation with msfvenom
- Return address overwrite

#### OSCP Study Resources

**Official**:
- PEN-200 course materials and lab environment
- OffSec Proving Grounds Practice (PG Practice)

**Books**:
- *Penetration Testing* by Georgia Weidman
- *The Hacker Playbook 3* by Peter Kim
- *The Web Application Hacker's Handbook* by Stuttard & Pinto (771 pages)
- *Metasploit: The Penetration Tester's Guide* (332 pages)
- *Advanced Penetration Testing* (269 pages)

**Online Platforms**:
- HackTheBox (TJ Null's OSCP-like machine list)
- TryHackMe (OSCP learning path)
- VulnHub (retired OSCP-prep VMs)
- PortSwigger Web Security Academy (free web app labs)

**Community References**:
- [0xsyr0/OSCP](https://github.com/0xsyr0/OSCP) — comprehensive cheat sheet with tool commands
- [Rajchowdhury420/OSCP-CheatSheet](https://github.com/Rajchowdhury420/OSCP-CheatSheet) — enumeration and privesc reference
- PayloadsAllTheThings — payload reference for all attack types
- WADCOMS — interactive cheat sheet for AD attacks
- GTFOBins / LOLBAS — binary abuse references

#### OSCP Lab Recommendations

| Platform | Use Case | Cost |
|---|---|---|
| OffSec Proving Grounds Practice | Closest to exam machines | Included with PEN-200 |
| HackTheBox | Broad skill development, AD labs | $14/mo (VIP) |
| TryHackMe | Guided learning, beginner-friendly | $14/mo |
| VulnHub | Free offline practice | Free |
| PortSwigger Academy | Web application attacks | Free |
| Hack The Box Pro Labs (Dante, Offshore, RastaLabs) | AD chain practice | $49-99 |

---

### OSCE3 — OffSec Certified Expert 3

**Issuer**: Offensive Security (OffSec)
**Structure**: Must pass ALL THREE component certifications:
**Cost**: $5,499+ (Learn Unlimited recommended)
**Recertification**: Lifetime credential

#### Component Certifications

| Certification | Course | Focus | Exam Duration |
|---|---|---|---|
| **OSWE** (Web Expert) | WEB-300 | Advanced web app exploitation, source code review, custom exploit dev | 47 hrs 45 min + 24 hrs report |
| **OSEP** (Experienced Pen Tester) | PEN-300 | Advanced evasion, custom C2, process injection, AV bypass, AD | 47 hrs 45 min + 24 hrs report |
| **OSED** (Exploit Developer) | EXP-301 | Windows user-mode exploit dev, reverse engineering, ROP chains, DEP/ASLR bypass | 47 hrs 45 min + 24 hrs report |

#### OSWE Key Topics
- White-box source code analysis (Java, .NET, PHP, Node.js)
- Authentication bypass through code review
- Type juggling and deserialization attacks
- Server-side template injection (advanced)
- Custom exploit scripting (Python)
- Blind SQL injection with custom extraction
- SSRF chains and second-order vulnerabilities
- PostgreSQL extensions for RCE
- Padding oracle attacks

#### OSEP Key Topics
- Antivirus and EDR evasion techniques
- Custom shellcode loaders and obfuscation
- Process injection (hollowing, DLL injection, thread hijacking)
- Advanced Active Directory attacks (DACL abuse, forest trusts)
- Kiosk breakout and application whitelisting bypass (AppLocker, WDAC)
- AMSI bypass techniques
- Constrained Language Mode bypass
- Lateral movement through DCOM, WMI, WinRM
- Linux post-exploitation and pivoting
- Custom C2 channel development

#### OSED Key Topics
- x86/x64 assembly and reverse engineering
- WinDbg and IDA Pro proficiency
- Stack buffer overflow (SEH-based, egghunter)
- Return-oriented programming (ROP) chain construction
- DEP, ASLR, CFG bypass techniques
- Format string vulnerabilities
- Custom shellcode development
- Patch diffing and 1-day exploit development

#### OSCE3 Study Resources

**Books**:
- *The Shellcoder's Handbook* (745 pages) — essential for OSED
- *Reversing: Secrets of Reverse Engineering* (619 pages) — OSED prep
- *The Web Application Hacker's Handbook* — OSWE foundation
- *Gray Hat Hacking: The Ethical Hacker's Handbook* (577 pages)
- *Malware Analyst's Cookbook* (746 pages) — supports OSEP evasion work

**Labs**:
- OffSec course labs (WEB-300, PEN-300, EXP-301) — primary study material
- HackTheBox Pro Labs: RastaLabs, Offshore (AD focus for OSEP)
- Exploit Education (Phoenix, Protostar) — binary exploitation fundamentals
- PortSwigger Academy (advanced labs for OSWE)
- CryptoHack — cryptographic attack practice

---

### CRTP / CRTE — Certified Red Team Professional / Expert

**Issuer**: Altered Security (formerly Pentester Academy)

#### CRTP — Certified Red Team Professional

**Prerequisite Course**: Windows Red Team Lab (WRTL) / Active Directory Attacking & Defense
**Cost**: $249-$449 (lab access + exam)
**Exam Duration**: 24 hours hands-on + 48 hours report writing
**Format**: Compromise an AD environment with multiple domains
**Difficulty**: Intermediate (between OSCP AD and CRTE)

**Key Knowledge Areas**:
- Active Directory enumeration (PowerView, ADModule, BloodHound)
- Local privilege escalation on Windows
- Domain privilege escalation paths
- Kerberos attacks: Kerberoasting, AS-REP Roasting, delegation abuse
- Cross-domain and cross-forest trust attacks
- Lateral movement: PSRemoting, WMI, DCOM, Over-Pass-the-Hash
- Persistence: Golden Ticket, Silver Ticket, Skeleton Key, DSRM, ACL abuse
- Defense evasion: AMSI bypass, PowerShell Constrained Language Mode bypass, AppLocker bypass
- Domain dominance techniques

**Study Resources**:
- Altered Security course materials (primary)
- HackTheBox AD machines and Pro Labs
- *Attacking and Defending Active Directory* (Altered Security course)
- AD Security blog (adsecurity.org) by Sean Metcalf
- SpecterOps BloodHound documentation
- harmj0y's blog (posts on AD attacks)

#### CRTE — Certified Red Team Expert

**Prerequisite Course**: Windows Red Team Expert Lab
**Cost**: $449-$699
**Exam Duration**: 48 hours hands-on + 48 hours report writing
**Format**: Multi-forest AD environment with hardened defenses
**Difficulty**: Advanced

**Key Knowledge Areas** (in addition to CRTP):
- Advanced forest trust abuse and SID history injection
- SQL Server links and trust exploitation
- Azure AD integration attacks
- Advanced persistence: DCShadow, AdminSDHolder, Custom SSP
- LAPS abuse and credential tiering bypass
- Advanced DACL/ACE abuse chains
- Certificate Services attacks (ESC1-ESC8)
- SCCM exploitation
- Detection evasion at enterprise scale
- Custom tooling and C# tradecraft

---

## Governance, Risk & Management Certifications

### CISSP — Certified Information Systems Security Professional

**Issuer**: (ISC)2
**Prerequisites**: 5 years experience in 2+ domains (1 year waived with degree)
**Cost**: $749 exam fee
**Exam Format**: CAT (Computerized Adaptive Testing) — 125-175 questions, 4 hours
**Passing Score**: 700 / 1000
**Recertification**: 40 CPE credits/year (120 total over 3 years) + $135 AMF
**Language**: English (CAT), other languages (linear 250 questions, 6 hours)

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Security & Risk Management** | 15% | CIA triad, governance, compliance, legal/regulatory, risk assessment, BCP, security policies, ethics |
| **2. Asset Security** | 10% | Data classification, ownership, privacy protection, retention, data security controls, handling requirements |
| **3. Security Architecture & Engineering** | 13% | Security models (Bell-LaPadula, Biba, Clark-Wilson), cryptography, site/facility design, secure design principles |
| **4. Communication & Network Security** | 13% | OSI/TCP-IP models, network components, secure channels, network attacks, wireless security, SDN |
| **5. Identity & Access Management (IAM)** | 13% | Authentication types (MFA, biometrics), authorization models (RBAC, ABAC, MAC, DAC), identity federation, SSO, provisioning lifecycle |
| **6. Security Assessment & Testing** | 12% | Vulnerability assessment, penetration testing, log reviews, SOC metrics, code review, audit strategies |
| **7. Security Operations** | 13% | Incident management, investigations, logging/monitoring, disaster recovery, change management, physical security |
| **8. Software Development Security** | 11% | SDLC security, OWASP, secure coding, software testing, DevSecOps, API security, database security |

#### CISSP Key Study Topics by Domain

**Domain 1 — Security & Risk Management (15%)**:
- Quantitative risk analysis: SLE = AV x EF; ALE = SLE x ARO
- Qualitative risk analysis: likelihood vs impact matrices
- Risk treatment: avoidance, mitigation, transfer, acceptance
- BCP/DRP: BIA, RTO, RPO, MTD, MTPD
- Legal frameworks: GDPR, HIPAA, SOX, PCI-DSS, GLBA
- Security governance: policies, standards, procedures, guidelines, baselines
- Professional ethics: (ISC)2 Code of Ethics
- Threat modeling: STRIDE, PASTA, DREAD, VAST

**Domain 2 — Asset Security (10%)**:
- Data states: at rest, in transit, in use
- Classification levels: Public, Internal, Confidential, Restricted (commercial) / Unclassified through Top Secret (government)
- Data roles: owner, custodian, steward, processor, controller
- DLP strategies and tools
- Data remanence: clearing, purging, destroying, cryptographic erasure

**Domain 3 — Security Architecture & Engineering (13%)**:
- Security models: Bell-LaPadula (confidentiality), Biba (integrity), Clark-Wilson (integrity with separation of duties), Brewer-Nash (Chinese Wall)
- Security evaluation: Common Criteria (ISO 15408), EAL levels
- Cryptography: symmetric (AES, 3DES), asymmetric (RSA, ECC, DH), hashing (SHA-256, SHA-3), digital signatures, PKI, certificate management
- Physical security: Bollards, mantraps, CPTED, Faraday cages

**Domain 4 — Communication & Network Security (13%)**:
- OSI model layers and security controls at each
- Network devices: firewalls (stateful, NGFW, WAF), IDS/IPS, proxies, load balancers
- VPN protocols: IPSec (AH, ESP), TLS, WireGuard
- Wireless: WPA3, 802.1X, EAP types
- DNS security: DNSSEC, DNS over HTTPS/TLS
- Network segmentation, micro-segmentation, zero trust network architecture

**Domain 5 — Identity & Access Management (13%)**:
- Authentication factors: something you know/have/are + context-based
- SAML, OAuth 2.0, OpenID Connect, FIDO2/WebAuthn
- Kerberos protocol deep understanding
- Privileged Access Management (PAM)
- Account provisioning and deprovisioning lifecycle
- Access review and recertification

**Domain 6 — Security Assessment & Testing (12%)**:
- Vulnerability scanning vs penetration testing vs red teaming
- OWASP Testing Guide, OWASP Top 10
- Code review: SAST, DAST, IAST, SCA
- SOC 1/2/3 reports (Type I vs Type II)
- Internal vs external audits

**Domain 7 — Security Operations (13%)**:
- SIEM operations, log management, SOAR
- Digital forensics: order of volatility, chain of custody, evidence handling
- Incident response phases: Preparation, Detection, Containment, Eradication, Recovery, Lessons Learned (NIST SP 800-61)
- Disaster recovery: hot/warm/cold sites, RAID levels, backup strategies (3-2-1 rule)
- Change management: CAB, RFC process
- Investigations: criminal vs civil vs administrative vs regulatory

**Domain 8 — Software Development Security (11%)**:
- SDLC phases and security integration points
- Secure coding: input validation, output encoding, parameterized queries
- Software testing: unit, integration, regression, fuzzing, penetration
- DevSecOps pipeline: SAST, DAST, SCA, container scanning, IaC scanning
- Database security: views, stored procedures, polyinstantiation
- API security: rate limiting, authentication, input validation

#### CISSP Study Resources

**Books**:
- *CISSP Official Study Guide (Sybex)* by Chapple, Stewart, Gibson — primary textbook
- *CISSP All-in-One Exam Guide* by Shon Harris / Fernando Maymi — comprehensive alternative
- *Eleventh Hour CISSP* by Eric Conrad — rapid review
- *CISSP Practice Exams* (Sybex) — 1300+ practice questions
- *Information Security Management Handbook* (3,206 pages) — deep reference

**Courses**:
- (ISC)2 Official Training
- Destination Certification MindMap videos (YouTube, free)
- Thor Teaches CISSP (Udemy)
- Kelly Handerhan CISSP (Cybrary / Inside Cloud & Security)

**Practice**:
- Boson CISSP practice exams (closest to real exam difficulty)
- CCCure practice tests
- Pocket Prep CISSP app
- Study Notes and Theory (SNT) study guide

---

### CISM — Certified Information Security Manager

**Issuer**: ISACA
**Prerequisites**: 5 years infosec management experience (waivers available for up to 2 years)
**Cost**: $575 (members) / $760 (non-members)
**Exam Format**: 150 multiple-choice questions, 4 hours
**Passing Score**: 450 / 800
**Recertification**: 20 CPE hours/year (minimum), 120 over 3 years + annual maintenance fee

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Information Security Governance** | 17% | Security strategy, frameworks, policies, organizational structure, board reporting |
| **2. Information Security Risk Management** | 20% | Risk identification, assessment, treatment, monitoring, risk appetite/tolerance |
| **3. Information Security Program** | 33% | Program development, management, resources, metrics, awareness/training |
| **4. Incident Management** | 30% | IR planning, detection, response, recovery, post-incident review, BCP integration |

#### Key Study Topics

**Domain 1 — Governance (17%)**:
- Alignment of security strategy with business objectives
- Security governance frameworks: COBIT, ISO 27001, NIST CSF
- Organizational roles: CISO reporting structure, security steering committee
- Regulatory compliance obligations and mapping
- Security policy hierarchy: policies > standards > procedures > guidelines
- Metrics and KPIs for governance reporting to the board

**Domain 2 — Risk Management (20%)**:
- Risk assessment methodologies: OCTAVE, FAIR, NIST SP 800-30, ISO 27005
- Risk appetite vs risk tolerance vs risk capacity
- Risk register maintenance and communication
- Third-party/vendor risk management
- Risk treatment options and residual risk acceptance
- Risk monitoring and continuous assessment
- Threat intelligence integration into risk process

**Domain 3 — Program Development & Management (33%)**:
- Security program charter and roadmap
- Resource allocation and budgeting
- Security architecture alignment
- Data classification program implementation
- Security awareness and training programs
- Vulnerability management lifecycle
- Metrics: KPIs, KRIs, maturity models (CMM/CMMI)
- Integration with SDLC and DevSecOps
- Third-party assurance (SOC reports, vendor assessments)

**Domain 4 — Incident Management (30%)**:
- Incident response plan development and testing
- Incident classification and severity frameworks
- Detection capabilities: SIEM, EDR, NDR, SOAR
- Containment, eradication, recovery procedures
- Evidence handling and forensic readiness
- Communication plans: internal, external, regulatory (GDPR 72-hour notification)
- Post-incident review and lessons learned
- BCP/DRP integration and testing (tabletop, functional, full-scale)

#### CISM Study Resources

- *CISM Review Manual* (ISACA official) — primary resource
- *CISM Review Questions, Answers & Explanations Manual* (ISACA)
- ISACA QAE database (online practice questions)
- *CISM Certified Information Security Manager All-in-One Exam Guide* by Peter Gregory
- Hemang Doshi CISM videos (Udemy)

---

### CISA — Certified Information Systems Auditor

**Issuer**: ISACA
**Prerequisites**: 5 years IS auditing, control, or security experience (waivers available)
**Cost**: $575 (members) / $760 (non-members)
**Exam Format**: 150 multiple-choice questions, 4 hours
**Passing Score**: 450 / 800
**Recertification**: 20 CPE hours/year, 120 over 3 years

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Information Systems Auditing Process** | 21% | Audit standards, frameworks, risk-based auditing, evidence collection, reporting |
| **2. Governance & Management of IT** | 17% | IT governance frameworks, strategic alignment, resource management, performance monitoring |
| **3. Information Systems Acquisition, Development & Implementation** | 12% | SDLC, project management, system migration, change management, post-implementation review |
| **4. Information Systems Operations & Business Resilience** | 23% | IT operations, service management, disaster recovery, BCP, incident management |
| **5. Protection of Information Assets** | 27% | Access controls, network security, data classification, encryption, physical security, privacy |

#### Key Study Topics

- IS audit standards: ISACA ITAF, COBIT, ISO 27001 audit
- Audit planning: risk-based approach, materiality, sampling methods (statistical vs judgmental)
- Evidence types: physical, documentary, analytical, testimonial
- Control types: preventive, detective, corrective, compensating
- IT governance: COBIT 2019 framework, balanced scorecard, IT strategy committee vs IT steering committee
- SDLC controls at each phase
- Change management: emergency change process, CAB, RFC
- BCP/DRP: BIA, RTO, RPO, testing types
- Network security: firewalls, IDS/IPS, VPN, segmentation
- Access control models and provisioning
- Cryptography fundamentals and PKI

#### CISA Study Resources

- *CISA Review Manual* (ISACA official)
- *CISA Review Questions, Answers & Explanations Database* (ISACA)
- *CISA Certified Information Systems Auditor All-in-One Exam Guide* by Peter Gregory
- Hemang Doshi CISA videos (Udemy)

---

### CRISC — Certified in Risk and Information Systems Control

**Issuer**: ISACA
**Prerequisites**: 3 years experience in IT risk management (minimum 1 year in Domain 1 or 2)
**Cost**: $575 (members) / $760 (non-members)
**Exam Format**: 150 multiple-choice questions, 4 hours
**Passing Score**: 450 / 800
**Recertification**: 20 CPE hours/year, 120 over 3 years

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Governance** | 26% | Organizational governance, risk governance, risk culture, regulatory/legal requirements |
| **2. IT Risk Assessment** | 20% | Risk identification, risk scenarios, risk analysis/evaluation, current state assessment |
| **3. Risk Response & Reporting** | 32% | Risk treatment options, control design/implementation, risk monitoring, risk reporting to stakeholders |
| **4. Information Technology & Security** | 22% | IT operations management, IT architecture, security fundamentals, data management, emerging tech risk |

#### Key Study Topics

- Enterprise risk management (ERM) frameworks: COSO ERM, ISO 31000
- IT risk frameworks: COBIT, NIST RMF (SP 800-37), FAIR (quantitative)
- Risk appetite, risk tolerance, risk capacity — differences and application
- Risk scenario development using COBIT risk scenarios
- Key Risk Indicators (KRIs) vs Key Performance Indicators (KPIs)
- Risk and control self-assessments (RCSA)
- Control frameworks: CIS Controls, NIST 800-53, ISO 27001 Annex A
- Third-party risk management and vendor risk assessment
- Emerging technology risk: AI, IoT, blockchain, quantum computing
- Risk-aware culture development and metrics

#### CRISC Study Resources

- *CRISC Review Manual* (ISACA official)
- *CRISC Review Questions, Answers & Explanations Database* (ISACA)
- *CRISC Certified in Risk and Information Systems Control All-in-One Exam Guide*
- FAIR Institute resources (for quantitative risk analysis)

---

## Vendor-Neutral Technical Certifications

### CEH — Certified Ethical Hacker

**Issuer**: EC-Council
**Prerequisites**: 2 years infosec experience OR official training
**Cost**: $1,199 (exam only) / $2,199+ (with training)
**Exam Format**: 125 multiple-choice questions, 4 hours
**Passing Score**: 60-85% (varies by exam form)
**Recertification**: 120 ECE credits over 3 years + $80/year
**Practical Exam (CEH Practical)**: 6-hour hands-on exam (20 challenges), separate fee

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Introduction to Ethical Hacking** | 6% | Hacking concepts, kill chain, MITRE ATT&CK, ethics, legal |
| **2. Footprinting & Reconnaissance** | 9% | OSINT, DNS, WHOIS, social media, search engine recon |
| **3. Scanning Networks** | 7% | Nmap, host/port/vulnerability scanning, firewall evasion |
| **4. Enumeration** | 8% | NetBIOS, SNMP, LDAP, NFS, SMTP, DNS enumeration |
| **5. Vulnerability Analysis** | 7% | Nessus, OpenVAS, vulnerability scoring (CVSS), assessment types |
| **6. System Hacking** | 7% | Password attacks, privilege escalation, rootkits, steganography |
| **7. Malware Threats** | 6% | Trojans, viruses, worms, fileless malware, APTs |
| **8. Sniffing** | 6% | Wireshark, ARP spoofing, MAC flooding, MITM |
| **9. Social Engineering** | 6% | Phishing, pretexting, tailgating, countermeasures |
| **10. Denial-of-Service** | 5% | Volumetric, protocol, application-layer DoS/DDoS |
| **11. Session Hijacking** | 5% | TCP session hijacking, cookie theft, MITM |
| **12. Evading IDS, Firewalls & Honeypots** | 5% | Evasion techniques, fragmentation, encryption, tunneling |
| **13. Hacking Web Servers** | 5% | Web server attacks, HTTP response splitting, misconfiguration |
| **14. Hacking Web Applications** | 8% | OWASP Top 10, injection, XSS, CSRF, insecure deserialization |
| **15. SQL Injection** | 7% | Union, blind, error-based SQLi, evasion techniques |
| **16. Hacking Wireless Networks** | 3% | WPA/WPA2/WPA3, evil twin, deauth, aircrack-ng |
| **17. Hacking Mobile Platforms** | 3% | Android/iOS attacks, mobile OWASP Top 10 |
| **18. IoT & OT Hacking** | 3% | IoT protocols, Shodan, SCADA/ICS attacks |
| **19. Cloud Computing** | 3% | Cloud security threats, S3 misconfig, container security |
| **20. Cryptography** | 3% | Symmetric/asymmetric, hashing, PKI, attacks on crypto |

#### CEH Study Resources

- *CEH v12/v13 Official Courseware* (EC-Council)
- *CEH Certified Ethical Hacker All-in-One Exam Guide* by Matt Walker
- Boson CEH practice exams
- *Ethical Hacking and Penetration Testing Guide* (523 pages)
- CyberQ Labs (EC-Council lab platform)

---

### CompTIA Security+

**Certification Code**: SY0-701
**Issuer**: CompTIA
**Prerequisites**: None (Network+ and 2 years experience recommended)
**Cost**: $404
**Exam Format**: Maximum 90 questions (multiple-choice + PBQ), 90 minutes
**Passing Score**: 750 / 900
**Recertification**: 50 CEU over 3 years + $75 renewal fee
**DoD Approved**: 8570/8140 IAT Level II

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. General Security Concepts** | 12% | CIA triad, AAA, zero trust, gap analysis, security controls |
| **2. Threats, Vulnerabilities & Mitigations** | 22% | Threat actors, social engineering, application attacks, indicator analysis, mitigation techniques |
| **3. Security Architecture** | 18% | Network security, secure infrastructure, cloud/hybrid, resilience, embedded systems |
| **4. Security Operations** | 28% | Monitoring, vulnerability management, incident response, automation, digital forensics |
| **5. Security Program Management & Oversight** | 20% | Governance, risk management, compliance, audits, security awareness |

#### Key Study Topics

- Zero trust architecture principles and implementation
- Threat intelligence: STIX, TAXII, MITRE ATT&CK, Diamond Model
- Cloud security: shared responsibility model, CASB, CSPM
- Cryptographic concepts: symmetric, asymmetric, hashing, digital certificates, PKI
- Network security: firewalls, IDS/IPS, SIEM, VPN, NAC, segmentation
- Identity management: MFA, SSO, SAML, OAuth, FIDO2
- Incident response process and digital forensics basics
- Vulnerability management lifecycle
- Compliance: PCI-DSS, HIPAA, GDPR, SOX
- Risk management: risk register, heat maps, risk assessment types

#### Security+ Study Resources

- *CompTIA Security+ Study Guide (Sybex)* by Mike Chapple
- *CompTIA Security+ Get Certified Get Ahead* by Darril Gibson
- Professor Messer Security+ video course (YouTube, free)
- Jason Dion Security+ practice tests (Udemy)
- CompTIA CertMaster Labs and Practice

---

### CompTIA CySA+

**Certification Code**: CS0-003
**Issuer**: CompTIA
**Prerequisites**: None (Security+ or equivalent recommended)
**Cost**: $404
**Exam Format**: Maximum 85 questions (multiple-choice + PBQ), 165 minutes
**Passing Score**: 750 / 900
**DoD Approved**: 8570/8140 CSSP Analyst

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Security Operations** | 33% | SIEM, SOAR, threat intelligence, log analysis, detection engineering |
| **2. Vulnerability Management** | 30% | Scanning, assessment, prioritization, remediation, attack surface management |
| **3. Incident Response & Management** | 20% | IR phases, containment, eradication, recovery, forensic analysis |
| **4. Reporting & Communication** | 17% | Metrics, KPIs, vulnerability reporting, stakeholder communication, compliance |

#### Key Study Topics

- SIEM query writing and log analysis (Splunk, ELK, Sentinel)
- Threat hunting: hypothesis-driven, indicator-driven, analytics-driven
- Malware analysis: static vs dynamic, sandboxing, behavioral indicators
- Network traffic analysis: pcap analysis, anomaly detection, NetFlow
- Vulnerability scoring: CVSS, EPSS, risk-based prioritization
- Digital forensics: disk imaging, memory analysis, timeline construction
- Threat intelligence: STIX/TAXII, TLP, diamond model, kill chain mapping
- Cloud security monitoring and container security

#### CySA+ Study Resources

- *CompTIA CySA+ Study Guide (Sybex)*
- Jason Dion CySA+ course and practice tests (Udemy)
- Professor Messer CySA+ videos (YouTube)
- TryHackMe SOC Level 1 and Level 2 paths
- Blue Team Labs Online (BTLO)

---

### CompTIA PenTest+

**Certification Code**: PT0-002
**Issuer**: CompTIA
**Prerequisites**: None (Security+ and 3-4 years hands-on recommended)
**Cost**: $404
**Exam Format**: Maximum 85 questions (multiple-choice + PBQ), 165 minutes
**Passing Score**: 750 / 900
**DoD Approved**: 8570/8140

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Planning & Scoping** | 14% | Rules of engagement, scope, compliance, threat modeling |
| **2. Information Gathering & Vulnerability Scanning** | 22% | Passive/active recon, vulnerability scanning, analysis |
| **3. Attacks & Exploits** | 30% | Network, web app, wireless, cloud, social engineering attacks |
| **4. Reporting & Communication** | 18% | Report writing, findings, remediation recommendations, communication |
| **5. Tools & Code Analysis** | 16% | Scripting (Python, Bash, PowerShell), tool usage, code review |

#### Key Study Topics

- Engagement scoping and rules of engagement documentation
- Passive recon: OSINT, DNS, certificate transparency, Shodan
- Active recon: port scanning, service enumeration, vulnerability scanning
- Web app attacks: OWASP Top 10, injection, authentication bypass
- Network attacks: ARP spoofing, VLAN hopping, relay attacks
- Wireless attacks: deauthentication, evil twin, WPA cracking
- Post-exploitation: persistence, lateral movement, data exfiltration
- Scripting for automation: Python, Bash, PowerShell
- Report writing: executive summary, technical findings, risk ratings

#### PenTest+ Study Resources

- *CompTIA PenTest+ Study Guide (Sybex)*
- TryHackMe and HackTheBox for hands-on practice
- Professor Messer PenTest+ videos
- Jason Dion PenTest+ course (Udemy)

---

## SANS / GIAC Certifications

> SANS training is the gold standard for technical security education. GIAC certifications
> are the associated exam credentials. Cost is high (~$8,000-9,000 per course + exam)
> but the depth is unmatched. All GIAC exams are open-book (you build your own index).

### GSEC — GIAC Security Essentials

**Course**: SEC401 — Security Essentials: Network, Endpoint, and Cloud
**Cost**: ~$8,525 (OnDemand) + $979 exam fee
**Exam Format**: 106-180 questions, 4-5 hours (web-based, proctored)
**Passing Score**: 73%
**Recertification**: 36 CPE credits over 4 years + $479 renewal

#### Key Knowledge Areas

- Networking fundamentals and defense (TCP/IP, DNS, routing, switching)
- Defense in depth and zero trust architecture
- Linux and Windows security administration
- Active Directory security fundamentals
- Cloud security (AWS, Azure, GCP fundamentals)
- Cryptography: algorithms, PKI, TLS, VPN
- Incident handling and response basics
- Log management and SIEM
- Wireless security
- Web communication security
- Endpoint security and hardening (CIS Benchmarks)

#### GSEC Study Resources

- SEC401 course materials (primary — the books are the study guide)
- Build a comprehensive index (the exam is open-book)
- CIS Benchmarks for hands-on hardening practice
- SANS Cyber Ranges for lab work
- *Network Security Bible* (697 pages) — supplemental reference

---

### GCIH — GIAC Certified Incident Handler

**Course**: SEC504 — Hacker Tools, Techniques, and Incident Handling
**Cost**: ~$8,525 (OnDemand) + $979 exam fee
**Exam Format**: 106-180 questions, 4-5 hours
**Passing Score**: 70%
**Recertification**: 36 CPE credits over 4 years

#### Key Knowledge Areas

- Incident handling process (PICERL: Preparation, Identification, Containment, Eradication, Recovery, Lessons Learned)
- Attack techniques and tools across the kill chain
- Network attacks: reconnaissance, scanning, exploitation
- Password attacks: cracking, spraying, credential stuffing
- Web application attacks and defense
- Endpoint attacks: malware, fileless attacks, living off the land
- Lateral movement and post-exploitation
- Covering tracks and anti-forensics
- Network and host-based forensics for IR
- MITRE ATT&CK framework application to incident handling
- Threat intelligence for IR: IOCs, TTP mapping

#### GCIH Study Resources

- SEC504 course materials (primary)
- Build a detailed index organized by attack type and tool
- SANS DFIR Workbooks
- TryHackMe SOC paths for detection practice
- CyberDefenders.org — blue team CTF challenges

---

### GPEN — GIAC Penetration Tester

**Course**: SEC560 — Enterprise Penetration Testing
**Cost**: ~$8,525 (OnDemand) + $979 exam fee
**Exam Format**: 82-115 questions, 3 hours
**Passing Score**: 74%
**Recertification**: 36 CPE credits over 4 years

#### Key Knowledge Areas

- Penetration testing methodology and planning
- Comprehensive reconnaissance (passive + active)
- Vulnerability scanning and analysis
- Exploitation techniques: network, web, system
- Password attacks and credential access
- Post-exploitation: privilege escalation, pivoting, lateral movement
- Active Directory attacks: Kerberoasting, delegation abuse, GPO abuse
- Cloud penetration testing (AWS, Azure)
- Web application penetration testing
- Wireless penetration testing
- Metasploit Framework proficiency
- Report writing and communication to stakeholders
- Scoping and rules of engagement

#### GPEN Study Resources

- SEC560 course materials (primary)
- Build index organized by attack phase and technique
- HackTheBox and Proving Grounds Practice for hands-on
- *Professional Penetration Testing* (525 pages)
- SANS NetWars for competitive practice

---

### GWAPT — GIAC Web Application Penetration Tester

**Course**: SEC542 — Web App Penetration Testing and Ethical Hacking
**Cost**: ~$8,525 (OnDemand) + $979 exam fee
**Exam Format**: 82-115 questions, 3 hours
**Passing Score**: 71%
**Recertification**: 36 CPE credits over 4 years

#### Key Knowledge Areas

- Web application architecture and technology stack identification
- HTTP protocol analysis and manipulation
- Authentication and session management testing
- SQL injection (all variants: union, blind, error, time-based, out-of-band)
- Cross-site scripting (reflected, stored, DOM-based)
- Cross-site request forgery (CSRF)
- Server-side request forgery (SSRF)
- XML External Entity (XXE) injection
- Insecure deserialization
- File inclusion (LFI/RFI) and path traversal
- Command injection
- Business logic flaws
- API security testing (REST, GraphQL)
- Client-side attacks
- Web application fuzzing
- Burp Suite professional-level proficiency
- OWASP Testing Guide methodology

#### GWAPT Study Resources

- SEC542 course materials (primary)
- PortSwigger Web Security Academy (free, essential)
- *The Web Application Hacker's Handbook* (771 pages)
- *SQL Injection Attacks and Defense* (761 pages)
- *XSS Attacks: Cross Site Scripting Exploits and Defense* (482 pages)
- OWASP WebGoat and Juice Shop (practice apps)
- HackTheBox web challenges

---

## Cloud Security Certifications

### AWS Certified Security — Specialty

**Issuer**: Amazon Web Services
**Prerequisites**: Recommended 5 years IT security + 2 years AWS hands-on
**Cost**: $300
**Exam Format**: 65 questions (multiple-choice + multiple-response), 170 minutes
**Passing Score**: 750 / 1000
**Recertification**: Every 3 years (retake exam)

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Threat Detection & Incident Response** | 14% | GuardDuty, Security Hub, Detective, EventBridge, IR automation |
| **2. Security Logging & Monitoring** | 18% | CloudTrail, CloudWatch, VPC Flow Logs, Config, log analysis |
| **3. Infrastructure Security** | 20% | VPC, Security Groups, NACLs, WAF, Shield, Network Firewall, PrivateLink |
| **4. Identity & Access Management** | 16% | IAM policies, SCP, roles, federation, SSO, Organizations, Permission Boundaries |
| **5. Data Protection** | 18% | KMS, CloudHSM, ACM, S3 encryption, Macie, Secrets Manager |
| **6. Management & Security Governance** | 14% | AWS Organizations, Control Tower, Audit Manager, compliance frameworks |

#### Key Study Topics

- **IAM deep dive**: Policy evaluation logic (explicit deny > explicit allow > implicit deny), cross-account access, resource-based vs identity-based policies, Service Control Policies, Permission Boundaries, session policies
- **KMS**: CMK types (AWS-managed, customer-managed, AWS-owned), key policies, grants, encryption context, key rotation, cross-region keys, multi-region keys
- **GuardDuty**: Threat detection findings types, severity levels, suppression rules, integration with Security Hub
- **CloudTrail**: Management events vs data events, organization trails, log file integrity validation, CloudTrail Lake
- **VPC security**: Security groups (stateful) vs NACLs (stateless), VPC endpoints (Gateway vs Interface), PrivateLink, Transit Gateway, Network Firewall
- **S3 security**: Bucket policies, ACLs, Block Public Access, Object Lock, S3 Access Points, Macie for data discovery
- **WAF**: Web ACLs, rate-based rules, managed rule groups, Bot Control, custom rules
- **Incident response**: Forensic instance isolation, EC2 snapshot and volume analysis, IAM credential rotation, automated containment with Lambda/Step Functions
- **Secrets Manager vs Systems Manager Parameter Store**: When to use which

#### AWS Security Study Resources

- AWS Skill Builder — Security Specialty learning path
- *AWS Certified Security Specialty Study Guide* (Sybex)
- Tutorials Dojo practice exams (highly recommended)
- A Cloud Guru / Stephane Maarek courses (Udemy)
- AWS re:Invent security session recordings (YouTube, free)
- AWS Security Blog
- Hands-on: AWS Free Tier + personal lab account

---

### AZ-500 — Azure Security Engineer Associate

**Issuer**: Microsoft
**Prerequisites**: None (familiarity with Azure administration recommended; AZ-104 helps)
**Cost**: $165
**Exam Format**: ~40-60 questions (multiple-choice, case studies, drag-and-drop, labs), ~150 minutes
**Passing Score**: 700 / 1000
**Recertification**: Annual free renewal assessment on Microsoft Learn

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Manage Identity & Access** | 25-30% | Entra ID (Azure AD), Conditional Access, PIM, MFA, RBAC, managed identities |
| **2. Secure Networking** | 20-25% | NSGs, Azure Firewall, WAF, DDoS Protection, Private Link, VNet peering, Bastion |
| **3. Secure Compute, Storage & Databases** | 20-25% | VM security, AKS security, Key Vault, storage encryption, SQL security, Defender for Cloud |
| **4. Manage Security Operations** | 25-30% | Microsoft Sentinel (SIEM), Defender for Cloud, threat protection, security policies, compliance |

#### Key Study Topics

- **Entra ID (Azure AD)**: Conditional Access policies, PIM (Privileged Identity Management), identity protection, access reviews, entitlement management
- **RBAC**: Built-in vs custom roles, scope hierarchy (management group > subscription > resource group > resource), deny assignments
- **Network security**: NSG vs ASG, Azure Firewall (Premium with TLS inspection), Application Gateway WAF v2, Azure Front Door, Private Endpoints
- **Key Vault**: Access policies vs RBAC, soft delete, purge protection, key rotation, managed HSM, certificate management
- **Microsoft Sentinel**: KQL query writing, analytics rules, playbooks (Logic Apps), workbooks, data connectors, threat intelligence integration, UEBA
- **Defender for Cloud**: Secure Score, security recommendations, regulatory compliance dashboard, Defender plans (servers, containers, SQL, Key Vault, DNS, Resource Manager)
- **Storage security**: Shared Access Signatures (SAS), storage account keys, encryption at rest (Microsoft-managed vs customer-managed keys), immutable storage

#### AZ-500 Study Resources

- Microsoft Learn free learning path for AZ-500
- *Exam Ref AZ-500* by Yuri Diogenes and Orin Thomas
- John Savill AZ-500 study cram (YouTube, free)
- MeasureUp AZ-500 practice tests
- Whizlabs AZ-500 practice exams
- Hands-on: Azure free account ($200 credit)

---

### Google Professional Cloud Security Engineer

**Issuer**: Google Cloud
**Prerequisites**: None (3+ years industry experience + 1 year GCP recommended)
**Cost**: $200
**Exam Format**: 50-60 multiple-choice/multiple-select questions, 2 hours
**Passing Score**: Not publicly disclosed (scaled scoring)
**Recertification**: Every 2 years (retake exam)

#### Exam Domains & Key Topics

| Domain | Key Topics |
|---|---|
| **Configuring Access** | Cloud IAM (roles, policies, conditions), Organization policies, Workload Identity Federation, BeyondCorp Enterprise |
| **Configuring Network Security** | VPC design, firewall rules, Cloud Armor, Cloud NAT, Private Google Access, VPC Service Controls, Shared VPC |
| **Ensuring Data Protection** | Cloud KMS, Cloud HSM, DLP API, CMEK/CSEK, data classification, Cloud Storage security |
| **Managing Operations** | Security Command Center (SCC), Cloud Audit Logs, Chronicle SIEM, logging/monitoring, incident response |
| **Ensuring Compliance** | Compliance frameworks, audit logging, organization policies, Assured Workloads, data residency |
| **Security in CI/CD & Supply Chain** | Binary Authorization, Container Analysis, Artifact Registry, Software Delivery Shield |

#### Key Study Topics

- **Cloud IAM**: Basic/predefined/custom roles, service accounts (user-managed vs default), impersonation, Workload Identity Federation for external identities
- **VPC Service Controls**: Service perimeters, access levels, ingress/egress policies, dry-run mode
- **Cloud KMS**: Key rings, key versions, rotation, CMEK integration with services, Cloud HSM, Cloud EKM
- **Security Command Center (SCC)**: Premium tier features, Security Health Analytics, Event Threat Detection, Container Threat Detection, Web Security Scanner
- **BeyondCorp Enterprise**: Zero trust access model, Identity-Aware Proxy (IAP), context-aware access
- **Organization policies**: Constraints, inheritance, boolean vs list constraints
- **Chronicle SIEM**: UDM (Unified Data Model), YARA-L detection rules, entity graph

#### GCP Security Study Resources

- Google Cloud Skills Boost — Security Engineer learning path
- *Google Cloud Certified Professional Cloud Security Engineer Study Guide* (Sybex)
- Google Cloud security documentation (cloud.google.com/security)
- Priyanka Vergadia's security sketches (YouTube)
- Google Cloud free tier for hands-on practice
- Qwiklabs security labs

---

### CCSP — Certified Cloud Security Professional

**Issuer**: (ISC)2
**Prerequisites**: 5 years IT experience + 3 years infosec + 1 year in 1+ CCSP domains (CISSP satisfies prerequisite)
**Cost**: $599
**Exam Format**: 150 multiple-choice questions, 4 hours
**Passing Score**: 700 / 1000
**Recertification**: 30 CPE credits/year + $125 AMF

#### Exam Domains & Weights

| Domain | Weight | Key Topics |
|---|---|---|
| **1. Cloud Concepts, Architecture & Design** | 17% | Cloud service models, deployment models, shared responsibility, design principles |
| **2. Cloud Data Security** | 20% | Data lifecycle, classification, DLP, encryption, tokenization, data discovery, rights management |
| **3. Cloud Platform & Infrastructure Security** | 17% | Virtualization security, container security, network security, compute/storage security, DR/BCP |
| **4. Cloud Application Security** | 17% | SDLC, DevSecOps, API security, application architecture, identity federation, WAF |
| **5. Cloud Security Operations** | 16% | Monitoring, logging, incident response, digital forensics in cloud, change management |
| **6. Legal, Risk & Compliance** | 13% | Data privacy laws, cross-border data transfers, audit, eDiscovery, contracts/SLAs |

#### Key Study Topics

- **Cloud reference architecture**: NIST SP 500-292, CSA reference architecture, ISO/IEC 17789
- **Shared responsibility model**: IaaS vs PaaS vs SaaS security responsibility delineation
- **Data security lifecycle**: Create, Store, Use, Share, Archive, Destroy — controls at each phase
- **Cloud-specific threats**: CSA Cloud Controls Matrix, ENISA threat landscape, tenant isolation failures
- **Virtualization security**: Hypervisor types (1 vs 2), VM escape, container isolation, micro-segmentation
- **Legal considerations**: Data sovereignty, GDPR cross-border transfers (SCCs, BCRs), CLOUD Act, right to audit
- **Cloud forensics**: Challenges (volatility, multi-tenancy, jurisdiction), forensic-ready cloud architecture
- **SOC reports**: SOC 1 (ICFR), SOC 2 (Trust Service Criteria: security, availability, processing integrity, confidentiality, privacy), SOC 3 (public), Type I vs Type II
- **Encryption in cloud**: Client-side vs server-side, BYOK, HYOK, envelope encryption
- **Business continuity**: Cloud-specific DR strategies, cross-region replication, RTO/RPO in cloud context

#### CCSP Study Resources

- *CCSP Official Study Guide (Sybex)* by Ben Malisow — primary textbook
- *CCSP Official Practice Tests (Sybex)*
- *CCSP All-in-One Exam Guide* by Daniel Carter
- *CCSP CBK* ((ISC)2 official reference)
- Prabh Nair CCSP videos (YouTube, highly recommended)
- CSA (Cloud Security Alliance) — STAR registry, CCM, CAIQ
- NIST SP 800-144, 800-145, 500-292 (cloud computing references)

---

## Study Strategy & General Resources

### Universal Study Methodology

1. **Map the domains** — understand the exam blueprint and weight distribution
2. **Assess gaps** — take a diagnostic practice test before studying
3. **Study by domain** — weight study time proportional to exam weights and personal weakness
4. **Hands-on practice** — lab work for every technical certification (no exceptions)
5. **Practice exams** — minimum 3 full-length practice exams, review every wrong answer
6. **Spaced repetition** — use Anki or similar for memorization-heavy certs (CISSP, CISM, Security+)
7. **Community engagement** — Reddit (r/OSCP, r/cissp, r/netsec), Discord communities, study groups

### Study Time Estimates

| Certification | Estimated Study Hours | Timeline (with full-time job) |
|---|---|---|
| Security+ | 80-120 hours | 1-2 months |
| CEH | 80-120 hours | 1-2 months |
| CySA+ | 100-150 hours | 2-3 months |
| PenTest+ | 100-150 hours | 2-3 months |
| OSCP | 300-500 hours | 3-6 months |
| OSCE3 (total) | 600-1000 hours | 6-18 months |
| CRTP | 100-200 hours | 1-3 months |
| CRTE | 200-300 hours | 2-4 months |
| CISSP | 200-300 hours | 2-4 months |
| CISM | 150-200 hours | 2-3 months |
| CISA | 150-200 hours | 2-3 months |
| CRISC | 150-200 hours | 2-3 months |
| GSEC | 150-200 hours | 2-3 months |
| GCIH | 150-200 hours | 2-3 months |
| GPEN | 200-300 hours | 2-4 months |
| GWAPT | 150-250 hours | 2-3 months |
| AWS Security | 100-200 hours | 1-3 months |
| AZ-500 | 80-150 hours | 1-2 months |
| GCP Security | 100-200 hours | 1-3 months |
| CCSP | 150-200 hours | 2-3 months |

### Cross-Certification Book References

Organized from the security ebook collections for study across multiple certification paths:

**Foundational (Security+ / GSEC / CEH)**:
- *Computer and Information Security Handbook* (877 pages)
- *Information Security: Principles and Practice* (413 pages)
- *Information Security Fundamentals* (262 pages)
- *TCP/IP Guide* (1,671 pages) — networking deep reference
- *The Code Book: How to Make It, Break It, Hack It, Crack It* (273 pages) — cryptography

**Penetration Testing (OSCP / GPEN / PenTest+)**:
- *The Web Application Hacker's Handbook* (771 pages) — essential for web attacks
- *Penetration Testing and Network Defense* (625 pages)
- *Professional Penetration Testing* (525 pages)
- *Ethical Hacking and Penetration Testing Guide* (523 pages)
- *Advanced Penetration Testing* (269 pages)
- *Metasploit: The Penetration Tester's Guide* (332 pages)

**Exploit Development (OSCE3)**:
- *The Shellcoder's Handbook* (745 pages)
- *Reversing: Secrets of Reverse Engineering* (619 pages)
- *Gray Hat Hacking: The Ethical Hacker's Handbook* (577 pages)
- *A Bug Hunter's Diary* (212 pages)

**Incident Response & Forensics (GCIH / CySA+)**:
- *Malware Analyst's Cookbook* (746 pages)
- *Network Forensics: Tracking Hackers Through Cyberspace* (574 pages)
- *Windows Forensics Analysis* (386 pages)
- *Computer Forensics: Investigating Network Intrusions and Cyber Crime* (394 pages)
- *Digital Forensics With Open Source Tools* (289 pages)

**Governance & Management (CISSP / CISM / CISA / CRISC)**:
- *Information Security Management Handbook* (3,206 pages) — the GRC bible
- *IT Governance: A Manager's Guide to Data Security and ISO 27001/27002* (385 pages)
- *CISSP: Certified Information Systems Security Professional* (804 pages)
- *24 Deadly Sins of Software Security* (433 pages)

**Network Security (all certifications)**:
- *Network Security Bible* (697 pages)
- *Firewalls and Internet Security* (456 pages)
- *End to End Network Security: Defense-in-Depth* (469 pages)
- *Wireshark for Security Professionals* (391 pages)
- *SSH, The Secure Shell: The Definitive Guide* (438 pages)

---

## Lab Environment Recommendations

### Multi-Purpose Lab Platforms

| Platform | Best For | Cost | Notes |
|---|---|---|---|
| **HackTheBox** | OSCP, GPEN, PenTest+, CRTP | $14/mo VIP | TJ Null's OSCP list; Pro Labs for AD |
| **TryHackMe** | Security+, CySA+, beginner-friendly | $14/mo | Guided learning paths; SOC rooms |
| **OffSec Proving Grounds** | OSCP exam prep | Included with PEN-200 | Closest to OSCP exam experience |
| **PortSwigger Academy** | GWAPT, OSWE, web attacks | Free | Best free web app security training |
| **VulnHub** | OSCP, general practice | Free | Downloadable VMs for offline practice |
| **CyberDefenders** | GCIH, CySA+, blue team | Free / Premium | DFIR and SOC challenges |
| **Blue Team Labs Online** | CySA+, GCIH, blue team | $15/mo | Incident investigation labs |
| **LetsDefend** | CySA+, SOC analyst | Free / Premium | SOC simulator with alert triage |
| **PentesterLab** | GWAPT, OSWE, web sec | $20/mo | Progressive web exploitation exercises |
| **DVWA / WebGoat / Juice Shop** | Web app testing basics | Free | Self-hosted vulnerable apps |
| **Exploit Education** | OSED, binary exploitation | Free | Phoenix, Protostar, Fusion VMs |
| **CryptoHack** | Cryptography fundamentals | Free | Crypto challenge platform |

### Home Lab Recommendations

**Active Directory Lab (CRTP/CRTE/OSCP AD)**:
```
Minimum setup:
- 1 x Windows Server 2019/2022 (Domain Controller)
- 1 x Windows Server 2019/2022 (Member Server)
- 2 x Windows 10/11 (Workstations)
- 1 x Kali Linux (Attack machine)

Hypervisor: Proxmox VE (free) or VMware Workstation
RAM: 32GB minimum, 64GB recommended
Storage: 500GB SSD minimum
```

**Cloud Security Lab (AWS/Azure/GCP certs)**:
- AWS Free Tier account (12 months of select services)
- Azure free account ($200 credit for 30 days)
- Google Cloud free tier ($300 credit for 90 days)
- Use Infrastructure as Code (Terraform/CloudFormation) to spin up and tear down labs
- Set billing alerts to avoid unexpected charges

**SOC / Blue Team Lab (CySA+/GCIH)**:
```
Minimum setup:
- 1 x Security Onion or Wazuh (SIEM/IDS)
- 1 x Windows workstation with Sysmon
- 1 x Linux server (web/mail)
- 1 x Kali (attack traffic generation)
- Velociraptor or GRR for endpoint detection

Optional: ELK Stack, TheHive + Cortex for IR
```

### Practice Exam Providers

| Provider | Best For | Quality |
|---|---|---|
| **Boson** | CISSP, CEH, CompTIA | Closest to real exam difficulty |
| **Tutorials Dojo** | AWS certifications | Highly accurate, detailed explanations |
| **MeasureUp** | Microsoft/Azure certs | Official Microsoft practice test partner |
| **Whizlabs** | AWS, Azure, GCP | Good breadth, slightly easier than real exam |
| **ISACA QAE Database** | CISM, CISA, CRISC | Official practice questions from ISACA |
| **CCCure** | CISSP, CCSP | Large question bank, community-driven |
| **Pocket Prep** | Security+, CySA+, CISSP | Mobile-friendly daily practice |

---

## Certification Cost Summary

| Certification | Exam Fee | Training Cost | Total Estimate |
|---|---|---|---|
| CompTIA Security+ | $404 | $0-500 | $404-904 |
| CompTIA CySA+ | $404 | $0-500 | $404-904 |
| CompTIA PenTest+ | $404 | $0-500 | $404-904 |
| CEH | $1,199 | $0-2,200 | $1,199-3,399 |
| OSCP (PEN-200) | Included | $1,749-2,749 | $1,749-2,749 |
| OSCE3 (all 3) | Included | $5,499+ | $5,499+ |
| CRTP | Included | $249-449 | $249-449 |
| CRTE | Included | $449-699 | $449-699 |
| CISSP | $749 | $0-3,000 | $749-3,749 |
| CISM | $575-760 | $0-2,000 | $575-2,760 |
| CISA | $575-760 | $0-2,000 | $575-2,760 |
| CRISC | $575-760 | $0-2,000 | $575-2,760 |
| GSEC | $979 | $7,000-8,525 | $7,979-9,504 |
| GCIH | $979 | $7,000-8,525 | $7,979-9,504 |
| GPEN | $979 | $7,000-8,525 | $7,979-9,504 |
| GWAPT | $979 | $7,000-8,525 | $7,979-9,504 |
| AWS Security | $300 | $0-1,000 | $300-1,300 |
| AZ-500 | $165 | $0-500 | $165-665 |
| GCP Security | $200 | $0-500 | $200-700 |
| CCSP | $599 | $0-3,000 | $599-3,599 |

---

> **Navigation**: Return to [CIPHER ROADMAP](../ROADMAP.md) | [Training Index](./)
