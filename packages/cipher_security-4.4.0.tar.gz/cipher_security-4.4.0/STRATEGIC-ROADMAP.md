<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Strategic Roadmap — From Skills Library to Security Platform

## Current State (v2.0.0)

| Metric | CIPHER | Anthropic | Gap |
|--------|--------|-----------|-----|
| Skills | 1,133 | 734 | **+54% ahead** |
| Domains | 45 | ~20 | **+125% ahead** |
| Executable agents | 1,098 | 734 | **+50% ahead** |
| Test suite | 7,826 | 0 | **∞ ahead** |
| Memory engine | Basic | None | Ahead |
| MCP server | ✅ | ❌ | Ahead |
| Evolution engine | Basic | None | Ahead |
| Eval system | ✅ | ❌ | Ahead |

---

## Competitive Intelligence Summary

### What Each Repo Does Best (and What We Must Steal)

#### 1. ProjectDiscovery Neo — The $100M Product Vision
**What they have**: AI pentester that remembers architecture across engagements, runs on every PR, proves exploitability with working exploits, regression-tests fixes. Five product pillars: AI Pentesting, PR Security Review, Threat Modeling, Vulnerability Remediation, Exposure Analysis.

**Key insight**: They turned open-source tools (Nuclei, Katana, httpx, subfinder) into a commercial platform by adding **memory + context + automation + proof**. The open-source tools are the acquisition funnel; Neo is the monetization layer.

**What CIPHER must adopt**:
- [ ] **Engagement memory** — Every assessment builds on the last. Architecture, business logic, past findings persist.
- [ ] **PR-level pentesting** — GitHub Actions integration that pentests every PR.
- [ ] **Proof-of-exploit generation** — Don't just flag vulnerabilities; generate working exploits.
- [ ] **Regression testing** — Every finding becomes a permanent regression check.
- [ ] **Five-pillar product structure** — Map our domains to their solution areas.

#### 2. Nuclei — 12,775 Templates as the Standard
**What they have**: YAML-based vulnerability detection, 12,775 community templates, profiles for scan configurations (pentest, compliance, cloud, KEV, OSINT), DAST/cloud/network/headless/javascript/code protocols.

**What CIPHER must adopt**:
- [ ] **Template execution engine** — Our `nuclei-templating` skills describe templates; we need to actually execute them.
- [ ] **Template-to-skill pipeline** — Auto-generate CIPHER skills from Nuclei templates (12,775 → skills).
- [ ] **Scan profiles** — Map our domains to Nuclei scan profiles (pentest.yml, compliance.yml, cloud.yml).
- [ ] **CVE template auto-generation** — When a new CVE drops, auto-generate detection skill.

#### 3. Katana — Crawl-to-Scan Pipeline
**What they have**: Next-gen crawler with headless browser support, JavaScript parsing, automatic form filling, scope control. Feeds targets into Nuclei.

**What CIPHER must adopt**:
- [ ] **Attack surface discovery pipeline** — katana → httpx → nuclei → report.
- [ ] **Automated scope expansion** — Crawl, discover, scan in one pipeline.
- [ ] **JavaScript-aware crawling** — SPAs, API endpoint extraction.

#### 4. MetaClaw — RL-Driven Skill Evolution (Critical)
**What they have**: Agent that meta-learns from every conversation. Three modes: skills_only, rl (GRPO training), madmax (scheduled RL during idle). PRM scorer judges response quality. Skill Evolver creates new skills from failures.

**Architecture**:
- Proxy intercepts LLM calls → injects relevant skills
- PRM scorer evaluates responses (+1/-1/0)
- Failed interactions → automatic skill generation
- RL training deferred to idle windows (madmax mode)

**What CIPHER must adopt**:
- [ ] **PRM-style scoring** — Judge CIPHER's own outputs. Did the detection rule work? Was the exploit valid?
- [ ] **Failure → skill pipeline** — When CIPHER fails a task, auto-generate a skill to handle it next time.
- [ ] **Conversation-driven learning** — Every engagement improves the system.
- [ ] **Idle-window training** — Background optimization when not actively serving.
- [ ] **Skill injection proxy** — Intercept requests, inject relevant skills based on context.

#### 5. SimpleMem — Three-Stage Memory Pipeline (Critical)
**What they have**:
1. **Stage 1: Semantic Structured Compression** — Sliding window over dialogue, density gating (Φ_gate), coreference resolution, absolute timestamps
2. **Stage 2: Online Semantic Synthesis** — Intra-session consolidation, multi-view indexing (semantic, lexical, relational)
3. **Stage 3: Intent-Aware Retrieval Planning** — Query decomposition, retrieval strategy selection

**Plus**: MCP server, cross-session consolidation, LanceDB/SQLite storage, hybrid retrieval (vector + keyword).

**What CIPHER must adopt**:
- [ ] **Rewrite memory engine** — Replace basic memory with SimpleMem's 3-stage pipeline.
- [ ] **Sliding window compression** — Don't store raw conversations; compress to semantic units.
- [ ] **Multi-view indexing** — Semantic + lexical + relational indices for retrieval.
- [ ] **Cross-session consolidation** — Merge related findings across engagements.
- [ ] **Intent-aware retrieval** — Understand what the user actually needs, not just keyword match.

#### 6. AgentSkills Specification — The Standard We Must Comply With
**What they have**: Formal specification for AI agent skills including schema, evaluation, marketplace distribution.

**What CIPHER must adopt**:
- [ ] **Full spec compliance** — `compatibility` field, `metadata:` map for extra fields, per-skill `evals/evals.json`.
- [ ] **Marketplace distribution** — `npx skills add defconxt/cipher`.
- [ ] **Evaluation framework** — Standardized eval harness per skill.
- [ ] **Plugin discovery** — Skill search, versioning, dependency resolution.

#### 7. OpenShell — Sandbox Security Policy Engine
**What they have**: Linux sandbox with Landlock + seccomp + network namespaces. OPA/Rego policy engine evaluates every outbound connection. L7 HTTP inspection. Binary identity cache (SHA256 TOFU). Policy advisor generates recommendations from denials.

**What CIPHER must adopt**:
- [ ] **Sandbox-aware execution** — Run agent.py scripts in OpenShell sandboxes.
- [ ] **Policy generation** — Auto-generate OPA policies for security tools.
- [ ] **Network isolation** — Sandboxed scanning that can't escape scope.
- [ ] **Denial → policy pipeline** — Like MetaClaw's failure → skill, but for sandbox policies.

#### 8. NemoClaw — NVIDIA's Agent Framework
**What they have**: TypeScript-based agent with plugin architecture, compatible with MetaClaw's proxy pipeline.

**What CIPHER must adopt**:
- [ ] **Plugin architecture** — Formal plugin interface for extending CIPHER.
- [ ] **Multi-backend support** — Work with any LLM provider.

#### 9. GStack — The Productization Blueprint
**What they have**: Garry Tan's "virtual engineering team" — 13 specialist agents as slash commands. CEO review, eng review, design review, QA (with real browser), ship, retro. "Completeness Principle" — AI makes marginal cost of completeness near-zero.

**Key insight**: GStack proves the model of **role-based slash commands** that compose into workflows. CIPHER should have `/pentest`, `/threat-model`, `/detect`, `/investigate`, `/hunt`, `/architect`.

**What CIPHER must adopt**:
- [ ] **Slash command interface** — `/mode red`, `/scan`, `/hunt`, `/investigate`, `/triage`.
- [ ] **Role composition** — Chain skills like GStack chains reviews.
- [ ] **Completeness principle** — Every finding gets full proof, remediation, regression test.
- [ ] **Browser-based QA** — Verify web findings with real browser interaction.
- [ ] **Retro/metrics** — Track engagement stats like GStack's `/retro`.

#### 10. Superpowers — Multi-Agent Orchestration
**What they have**: Skills for dispatching parallel agents, subagent-driven development, systematic debugging, verification-before-completion, git worktree isolation.

**What CIPHER must adopt**:
- [ ] **Parallel agent dispatch** — Run multiple skills concurrently (scan + hunt + monitor).
- [ ] **Verification-before-completion** — Every finding must be verified before reporting.
- [ ] **Worktree isolation** — Isolated environments for dangerous operations.

#### 11. PwnTools — Binary Exploitation Framework
**What they have**: Complete exploit development library — ROP chains, shellcode, tubes (process/remote/SSH), ELF parsing, format strings, heap exploitation.

**What CIPHER must adopt**:
- [ ] **Binary exploitation skills** — We have zero binary exploitation techniques.
- [ ] **CTF/exploit dev domain** — New domain with pwntools integration.
- [ ] **ROP chain generation** — Automated gadget finding and chain building.
- [ ] **Shellcode generation** — Platform-specific shellcode templates.

#### 12. Bellingcat OSINT Toolkit — Investigation Methodology
**What they have**: Categorized OSINT tools by discipline — archiving, companies/finance, conflict, geolocation, image/video analysis, maps/satellites, social media, transportation.

**What CIPHER must adopt**:
- [ ] **Investigation-oriented OSINT** — Our OSINT skills are tool-focused; Bellingcat is investigation-focused.
- [ ] **Geolocation skills** — Image analysis, satellite imagery, chronolocation.
- [ ] **Financial investigation** — Corporate records, beneficial ownership, sanctions screening.

#### 13. AutoResearch/NanoChat — Autonomous Improvement Loop
**What they have**: Karpathy's autoresearch — give an AI agent a training setup, let it experiment autonomously. Edit code → train 5 min → check if improved → keep/discard → repeat.

**What CIPHER must adopt**:
- [ ] **Autonomous skill improvement** — Run skills against test cases, measure quality, iterate.
- [ ] **program.md pattern** — Human writes research program, agent executes experiments.
- [ ] **Leaderboard-driven optimization** — Track skill effectiveness over time.

---

## Product Architecture — CIPHER Platform

### Phase 1: Foundation (Current → v2.1.0) — "Skills Library"
**Status**: ✅ Largely complete
- 1,133 skills across 45 domains
- MCP server for IDE integration
- Basic eval system
- Plugin marketplace packaging

### Phase 2: Intelligence Engine (v2.1.0 → v2.5.0) — "Memory + Evolution"
**Priority**: 🔴 Critical — this is the differentiator

| Component | Source | Implementation |
|-----------|--------|---------------|
| Memory rewrite | SimpleMem | 3-stage pipeline: compress → synthesize → retrieve |
| Skill evolution | MetaClaw | PRM scorer + failure → skill generation |
| Engagement context | PD Neo | Architecture memory across sessions |
| Cross-session synthesis | SimpleMem | Consolidate findings across engagements |

### Phase 3: Execution Pipeline (v2.5.0 → v3.0.0) — "Scan + Prove"
**Priority**: 🔴 Critical — this is the product

| Component | Source | Implementation |
|-----------|--------|---------------|
| Scanning pipeline | Nuclei + Katana | katana crawl → nuclei scan → CIPHER analyze |
| Template engine | Nuclei | Execute 12,775 templates from CIPHER |
| Sandbox execution | OpenShell | Sandboxed tool execution with OPA policies |
| Proof generation | PD Neo | Working exploits, HTTP traces, screenshots |
| PR integration | PD Neo | GitHub Actions bot that pentests PRs |
| Regression testing | PD Neo | Every finding becomes a permanent check |

### Phase 4: Autonomous Operation (v3.0.0 → v4.0.0) — "Self-Improving"
**Priority**: 🟡 High — competitive moat

| Component | Source | Implementation |
|-----------|--------|---------------|
| Autonomous research | AutoResearch | Skill experiments: modify → test → keep/discard |
| RL training | MetaClaw | GRPO on engagement transcripts |
| Parallel agents | Superpowers | Multi-skill concurrent execution |
| Idle optimization | MetaClaw | Background improvement during downtime |
| Leaderboard | NanoChat | Track skill effectiveness metrics |

### Phase 5: Commercial Platform (v4.0.0 → v5.0.0) — "Business"
**Priority**: 🟢 Revenue

| Component | Source | Implementation |
|-----------|--------|---------------|
| SaaS API | PD Neo | REST API for external integrations |
| Marketplace | AgentSkills | Skill store with versioning + ratings |
| Enterprise SSO | Standard | SAML/OIDC for enterprise customers |
| Usage-based billing | PD pricing | Per-scan / per-engagement pricing |
| White-label | Standard | Rebrandable for MSSPs |
| Compliance reports | PD Neo | SOC 2, PCI, HIPAA automated reports |

---

## New Domains to Create (From Research)

### Binary Exploitation & CTF (from PwnTools)
- ROP chain construction, shellcode generation, format string exploitation
- Heap exploitation (tcache, fastbin, unsorted bin)
- Buffer overflow techniques (ASLR/NX/canary bypass)
- GDB scripting with GEF/pwndbg

### Investigation & Attribution (from Bellingcat)
- Geolocation analysis (image → location)
- Chronolocation (image → time)
- Financial investigation (corporate records, sanctions)
- Conflict zone analysis
- Transportation tracking

### Autonomous Security Research (from AutoResearch)
- Self-modifying detection rules
- Autonomous vulnerability research
- A/B testing security controls
- Evolutionary fuzzing campaigns

---

## KB Coverage Gap Analysis (from tooling.txt + cipher-kb-master-list.md)

### 🔴 Critical Tools Missing Dedicated Skills
| Tool | Category | Status |
|------|----------|--------|
| Impacket (full suite) | AD/Windows | Partial — need per-tool skills |
| BloodHound + SharpHound | AD attack paths | Mentioned but no dedicated skill |
| pwntools | Binary exploitation | **Missing entirely** |
| Metasploit Framework | Exploitation | **Missing entirely** |
| Volatility 3 | Memory forensics | Referenced but no deep skill |
| Burp Suite Pro | Web testing | Referenced but no dedicated skill |
| Hashcat / John | Password attacks | **Missing entirely** |
| Cobalt Strike | C2 framework | **Missing entirely** |
| Mimikatz / pypykatz | Credential theft | Referenced in AD skills |
| CrackMapExec / NetExec | AD lateral movement | Referenced but no dedicated skill |

### 🟡 High-Priority Gaps
| Tool | Category |
|------|----------|
| Evilginx2/3 | AiTM phishing |
| AFL++ / libFuzzer | Fuzzing |
| Sliver / Havoc | Modern C2 |
| Ghidra scripting | Reverse engineering |
| Velociraptor | Open-source EDR |
| theHive + Cortex | IR platform |
| MISP | Threat intel platform |

---

## Standardization Requirements

### AgentSkills Spec Compliance Checklist
- [ ] Add `compatibility` field to all YAML frontmatter
- [ ] Move custom fields to `metadata:` map
- [ ] Create `evals/evals.json` per skill (or per domain at minimum)
- [ ] Implement `npx skills add defconxt/cipher` distribution
- [ ] Add `allowed-tools` field (like GStack) listing required tools
- [ ] Version pinning for skill dependencies

### Framework Compliance
- [ ] NIST CSF 2.0 mapping for all skills
- [ ] MITRE ATT&CK mapping for all offensive/defensive skills
- [ ] CIS Controls v8 mapping for all hardening skills
- [ ] OWASP Top 10 mapping for all AppSec skills
- [ ] OWASP API Top 10 mapping for all API skills
- [ ] OWASP LLM Top 10 mapping for all AI skills
- [ ] IEC 62443 mapping for all OT/ICS skills

---

## Business Model

### Revenue Streams
1. **Open Core** — Skills library is AGPL (free), execution engine + memory + evolution are commercial
2. **SaaS API** — Pay-per-scan pricing for CI/CD integration
3. **Marketplace** — 30% rev share on third-party skills
4. **Enterprise** — Annual license with SSO, audit logs, compliance reports
5. **Professional Services** — Custom skill development, integration consulting

### Pricing Tiers
| Tier | Price | Features |
|------|-------|----------|
| Community | Free | Skills library, basic MCP server |
| Pro | $99/mo | Execution engine, memory, 1000 scans/mo |
| Team | $299/mo | PR integration, engagement memory, 5000 scans/mo |
| Enterprise | Custom | SSO, audit, compliance, unlimited scans, SLA |

### Go-to-Market
1. **Open source adoption** — Skills library drives awareness (like Nuclei templates)
2. **Claude Plugin Marketplace** — Distribution to Claude Code users
3. **GitHub Marketplace** — PR security review bot
4. **Conference presence** — BSides, DEF CON, Black Hat demos
5. **Content marketing** — Detection rules, threat intel, technique writeups

---

## Immediate Action Items (This Session)

1. **Create binary-exploitation domain** — 12 techniques with pwntools integration
2. **Create investigation-attribution domain** — 12 techniques from Bellingcat methodology
3. **Add dedicated tool skills** — Impacket, BloodHound, Metasploit, Hashcat, Burp Suite
4. **Implement KB articles** — Start converting cipher-kb-master-list.md into reference docs
5. **Add framework mappings** — MITRE ATT&CK IDs to all offensive/defensive skills
6. **Create scan profiles** — Map domains to Nuclei-style scan profiles

---

*This document is a living roadmap. Updated as competitive landscape evolves.*
*Last updated: 2026-03-17*
