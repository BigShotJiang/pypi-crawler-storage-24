<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Evaluation Framework

Test cases and assertions for validating skill quality and correctness.

## Structure

```
evals/
├── README.md
├── runner.py           # Eval runner — validates skills against test cases
├── test_cases/         # Per-skill test case definitions
│   ├── blue-team.yaml
│   ├── red-team.yaml
│   └── ...
└── results/            # Eval run outputs (gitignored)
```

## Running Evals

```bash
# Run all evals
python3 evals/runner.py

# Run specific skill eval
python3 evals/runner.py --skill blue-team

# Run with verbose output
python3 evals/runner.py --verbose
```

## Test Case Format

```yaml
skill: skill-name
cases:
  - name: "Test case description"
    input: "User prompt or scenario"
    assertions:
      - type: contains        # Response contains text
        value: "expected text"
      - type: matches_regex   # Response matches pattern
        pattern: "ATT&CK T\\d{4}"
      - type: has_section     # Response has named section
        value: "## Recommendations"
      - type: references      # References specific framework
        value: "MITRE ATT&CK"
      - type: min_length      # Minimum response length
        value: 200
    tags: [detection, sigma]
```
