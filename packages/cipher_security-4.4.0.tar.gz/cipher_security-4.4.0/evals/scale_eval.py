# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""Large-scale behavioral eval generator and runner for CIPHER.

Generates thousands of synthetic test queries per mode using an LLM at
temperature 0.9 (high variance), runs them through detect_mode(), and
builds a regression dataset of (input, expected_mode, actual_mode, pass/fail).

Usage:
    # Generate + evaluate (requires Ollama running)
    PYTHONPATH=src/:. python3 evals/scale_eval.py generate --count 200 --temperature 0.9

    # Evaluate existing dataset
    PYTHONPATH=src/:. python3 evals/scale_eval.py evaluate

    # Report on existing results
    PYTHONPATH=src/:. python3 evals/scale_eval.py report
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))
sys.path.insert(0, str(PROJECT_ROOT))

from src.gateway.mode import detect_mode, parse_keyword_table  # noqa: E402

logger = logging.getLogger("cipher.scale_eval")

EVALS_DIR = PROJECT_ROOT / "evals"
GENERATED_FILE = EVALS_DIR / "generated_queries.json"
RESULTS_FILE = EVALS_DIR / "scale_eval_results.json"

# Modes and their descriptions for query generation prompts
MODE_SPECS: dict[str, dict] = {
    "RED": {
        "description": "Offensive security, penetration testing, exploit development, attack paths",
        "example_queries": [
            "How do I perform AS-REP roasting against a domain?",
            "Walk me through lateral movement via DCOM",
            "What's the best way to exfiltrate data through DNS tunneling?",
            "Explain how to bypass AMSI in PowerShell",
            "Map attack paths from a compromised web server to domain admin",
        ],
    },
    "BLUE": {
        "description": "Detection engineering, SIEM rules, threat hunting, hardening, SOC operations",
        "example_queries": [
            "Write a Sigma rule for detecting LSASS credential dumping",
            "How do I configure auditd to detect privilege escalation?",
            "What EDR telemetry should I collect for lateral movement detection?",
            "Build a KQL query for Azure Sentinel to find brute force attempts",
            "How should I tune my SIEM to reduce false positives for T1059?",
        ],
    },
    "PURPLE": {
        "description": "Detection coverage mapping, ATT&CK gap analysis, adversary emulation, detection engineering bridging offense and defense",
        "example_queries": [
            "Map our detection coverage against FIN7 TTPs",
            "Design an adversary emulation plan for APT28",
            "What's our ATT&CK coverage gap for initial access techniques?",
            "Build a purple team exercise for testing credential theft detection",
            "Compare our Sigma rules against the MITRE ATT&CK matrix for gaps",
        ],
    },
    "PRIVACY": {
        "description": "GDPR, CCPA, HIPAA compliance, DPIAs, privacy by design, data protection",
        "example_queries": [
            "How do I conduct a DPIA for a facial recognition system?",
            "What are the GDPR Article 17 right to erasure requirements?",
            "Design a privacy-preserving data pipeline for healthcare records",
            "What anonymization techniques satisfy CCPA requirements?",
            "Assess our HIPAA compliance for cloud-hosted PHI",
        ],
    },
    "RECON": {
        "description": "OSINT, reconnaissance, subdomain enumeration, footprinting, intelligence gathering",
        "example_queries": [
            "How do I enumerate subdomains for target.com?",
            "What OSINT sources can I use to find employee email addresses?",
            "Build a passive reconnaissance workflow for a bug bounty target",
            "How do I use Shodan to find exposed industrial control systems?",
            "What's the best approach for DNS reconnaissance?",
        ],
    },
    "INCIDENT": {
        "description": "Incident response, triage, forensics, containment, IOC analysis, breach investigation",
        "example_queries": [
            "We detected a Cobalt Strike beacon on our domain controller — triage steps?",
            "How do I perform memory forensics on a compromised Windows host?",
            "Our SIEM shows lateral movement from a compromised account — containment plan?",
            "We found ransomware on 3 endpoints — incident response runbook?",
            "Analyze these IOCs: suspicious PowerShell spawning from Word",
        ],
    },
    "ARCHITECT": {
        "description": "Security architecture design, zero trust, threat modeling, system design, compensating controls",
        "example_queries": [
            "Design a zero trust architecture for a hybrid cloud environment",
            "What compensating controls should I implement for legacy systems?",
            "Create a threat model for a microservices-based payment system",
            "How should I architect network segmentation for PCI DSS compliance?",
            "Design a secrets management solution for a Kubernetes deployment",
        ],
    },
}

# Prompt template for generating diverse queries
GENERATION_PROMPT = """You are generating test queries for a cybersecurity AI assistant called CIPHER. 
Generate {count} diverse, realistic queries that a professional security engineer would ask.

These queries MUST be classifiable as {mode} mode based on these keywords and concepts:
{description}

Example queries for this mode:
{examples}

Requirements:
- Each query must be a single line, realistic, and specific
- Vary complexity: simple questions, multi-step requests, scenario-based, tool-specific
- Include typos in ~5% of queries (realistic user input)
- Include some queries that are subtle (don't use obvious trigger words)
- Include some queries with domain-specific jargon
- Do NOT include queries that could be ambiguous between modes
- Output ONLY a JSON array of strings, no other text

Output format: ["query1", "query2", ...]"""


def _call_ollama(prompt: str, temperature: float = 0.9, model: str = "qwen2.5:32b") -> str:
    """Call Ollama API for query generation."""
    import urllib.request

    url = "http://127.0.0.1:11434/api/generate"
    payload = {
        "model": model,
        "prompt": prompt,
        "temperature": temperature,
        "stream": False,
        "options": {"num_predict": 4096},
    }
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read())
            return result.get("response", "")
    except Exception as exc:
        logger.error("Ollama call failed: %s", exc)
        return ""


def _parse_json_array(text: str) -> list[str]:
    """Extract a JSON array from LLM response text."""
    # Try direct parse
    text = text.strip()
    try:
        arr = json.loads(text)
        if isinstance(arr, list):
            return [str(q).strip() for q in arr if str(q).strip()]
    except json.JSONDecodeError:
        pass

    # Try extracting from markdown code block
    import re

    match = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", text, re.DOTALL)
    if match:
        try:
            arr = json.loads(match.group(1))
            if isinstance(arr, list):
                return [str(q).strip() for q in arr if str(q).strip()]
        except json.JSONDecodeError:
            pass

    # Try finding array in text
    start = text.find("[")
    end = text.rfind("]")
    if start != -1 and end != -1 and end > start:
        try:
            arr = json.loads(text[start : end + 1])
            if isinstance(arr, list):
                return [str(q).strip() for q in arr if str(q).strip()]
        except json.JSONDecodeError:
            pass

    return []


def generate_queries(
    count_per_mode: int = 30,
    temperature: float = 0.9,
    model: str = "qwen2.5:32b",
) -> dict[str, list[str]]:
    """Generate diverse test queries for each mode using Ollama."""
    all_queries: dict[str, list[str]] = {}
    batch_size = 30  # Generate in batches to avoid timeout

    for mode, spec in MODE_SPECS.items():
        print(f"Generating {count_per_mode} queries for {mode}...", flush=True)
        t0 = time.time()
        seen: set[str] = set()
        unique: list[str] = []
        batches_needed = (count_per_mode + batch_size - 1) // batch_size

        for batch_i in range(batches_needed):
            if len(unique) >= count_per_mode:
                break
            remaining = min(batch_size, count_per_mode - len(unique))

            prompt = GENERATION_PROMPT.format(
                count=remaining,
                mode=mode,
                description=spec["description"],
                examples="\n".join(f"- {q}" for q in spec["example_queries"]),
            )

            response = _call_ollama(prompt, temperature=temperature, model=model)
            queries = _parse_json_array(response)

            for q in queries:
                lower = q.lower().strip()
                if lower not in seen and len(q) > 10:
                    seen.add(lower)
                    unique.append(q)

            print(f"  batch {batch_i + 1}/{batches_needed}: +{len(queries)} → {len(unique)} unique", flush=True)

        all_queries[mode] = unique[:count_per_mode]
        elapsed = time.time() - t0
        print(f"  {mode}: {len(all_queries[mode])} queries ({elapsed:.1f}s)")

    return all_queries


def evaluate_queries(
    queries: dict[str, list[str]],
    keyword_table: dict[str, list[str]],
) -> list[dict]:
    """Run all generated queries through detect_mode and score results."""
    results: list[dict] = []

    for expected_mode, mode_queries in queries.items():
        for query in mode_queries:
            actual_mode, needs_clarify = detect_mode(query, keyword_table)

            # A pass means the expected mode is the top mode (or included in clarify set)
            if needs_clarify:
                passed = expected_mode in actual_mode
            else:
                passed = actual_mode == expected_mode

            results.append({
                "input": query,
                "expected_mode": expected_mode,
                "actual_mode": actual_mode,
                "needs_clarify": needs_clarify,
                "passed": passed,
            })

    return results


def report(results: list[dict]) -> dict:
    """Generate a summary report from evaluation results."""
    total = len(results)
    passed = sum(1 for r in results if r["passed"])
    failed = sum(1 for r in results if not r["passed"])

    # Per-mode breakdown
    mode_stats: dict[str, dict] = {}
    for r in results:
        mode = r["expected_mode"]
        if mode not in mode_stats:
            mode_stats[mode] = {"total": 0, "passed": 0, "failed": 0, "failures": []}
        mode_stats[mode]["total"] += 1
        if r["passed"]:
            mode_stats[mode]["passed"] += 1
        else:
            mode_stats[mode]["failed"] += 1
            mode_stats[mode]["failures"].append({
                "input": r["input"][:100],
                "actual": r["actual_mode"],
            })

    # Confusion matrix
    confusion: dict[str, dict[str, int]] = {}
    for r in results:
        expected = r["expected_mode"]
        actual = r["actual_mode"]
        if expected not in confusion:
            confusion[expected] = {}
        confusion[expected][actual] = confusion[expected].get(actual, 0) + 1

    return {
        "total": total,
        "passed": passed,
        "failed": failed,
        "accuracy": round(passed / total * 100, 2) if total > 0 else 0,
        "per_mode": mode_stats,
        "confusion_matrix": confusion,
    }


def cmd_generate(args: argparse.Namespace) -> int:
    """Generate queries, evaluate, save results."""
    print("=== CIPHER Scale Eval: Generate + Evaluate ===")
    print(f"Count per mode: {args.count}, Temperature: {args.temperature}")
    print()

    # Generate
    queries = generate_queries(
        count_per_mode=args.count,
        temperature=args.temperature,
        model=args.model,
    )

    total_queries = sum(len(v) for v in queries.values())
    print(f"\nGenerated {total_queries} total queries across {len(queries)} modes")

    # Save generated queries
    GENERATED_FILE.write_text(json.dumps(queries, indent=2), encoding="utf-8")
    print(f"Saved to {GENERATED_FILE}")

    # Evaluate
    print("\n=== Evaluating ===")
    claude_md = (PROJECT_ROOT / "CLAUDE.md").read_text(encoding="utf-8")
    keyword_table = parse_keyword_table(claude_md)

    results = evaluate_queries(queries, keyword_table)

    # Save results
    RESULTS_FILE.write_text(json.dumps(results, indent=2), encoding="utf-8")

    # Report
    rep = report(results)
    _print_report(rep)

    return 0 if rep["accuracy"] >= 90 else 1


def cmd_evaluate(args: argparse.Namespace) -> int:
    """Evaluate existing generated queries."""
    if not GENERATED_FILE.exists():
        print(f"No generated queries found at {GENERATED_FILE}. Run 'generate' first.")
        return 1

    queries = json.loads(GENERATED_FILE.read_text(encoding="utf-8"))
    total = sum(len(v) for v in queries.values())
    print(f"Loaded {total} queries from {GENERATED_FILE}")

    claude_md = (PROJECT_ROOT / "CLAUDE.md").read_text(encoding="utf-8")
    keyword_table = parse_keyword_table(claude_md)

    results = evaluate_queries(queries, keyword_table)
    RESULTS_FILE.write_text(json.dumps(results, indent=2), encoding="utf-8")

    rep = report(results)
    _print_report(rep)

    return 0 if rep["accuracy"] >= 90 else 1


def cmd_report(args: argparse.Namespace) -> int:
    """Print report from existing results."""
    if not RESULTS_FILE.exists():
        print(f"No results found at {RESULTS_FILE}. Run 'generate' or 'evaluate' first.")
        return 1

    results = json.loads(RESULTS_FILE.read_text(encoding="utf-8"))
    rep = report(results)
    _print_report(rep)

    if args.failures:
        print("\n=== ALL FAILURES ===")
        for r in results:
            if not r["passed"]:
                print(f"  [{r['expected_mode']}→{r['actual_mode']}] {r['input'][:120]}")

    return 0


def _print_report(rep: dict) -> None:
    """Print formatted report."""
    print()
    print("=" * 60)
    print(f"OVERALL: {rep['passed']}/{rep['total']} ({rep['accuracy']}%)")
    print("=" * 60)

    for mode in sorted(rep["per_mode"]):
        stats = rep["per_mode"][mode]
        pct = round(stats["passed"] / stats["total"] * 100, 1) if stats["total"] > 0 else 0
        status = "✅" if pct >= 90 else "⚠️" if pct >= 75 else "❌"
        print(f"  {status} {mode:12s}: {stats['passed']}/{stats['total']} ({pct}%)")
        if stats["failures"][:3]:
            for f in stats["failures"][:3]:
                print(f"      → misrouted to {f['actual']}: {f['input'][:80]}")

    # Confusion matrix
    modes = sorted(rep["confusion_matrix"].keys())
    if modes:
        print()
        print("CONFUSION MATRIX (row=expected, col=actual):")
        header = f"{'':12s}" + "".join(f"{m:>10s}" for m in modes) + f"{'CLARIFY':>10s}"
        print(header)
        for expected in modes:
            row = rep["confusion_matrix"][expected]
            cells = ""
            for actual_mode in modes:
                val = row.get(actual_mode, 0)
                cells += f"{val:10d}"
            # Count clarify (mode strings containing commas)
            clarify_count = sum(v for k, v in row.items() if "," in k)
            cells += f"{clarify_count:10d}"
            print(f"{expected:12s}{cells}")


def main() -> int:
    parser = argparse.ArgumentParser(description="CIPHER Scale Eval")
    sub = parser.add_subparsers(dest="command")

    gen = sub.add_parser("generate", help="Generate + evaluate queries")
    gen.add_argument("--count", type=int, default=30, help="Queries per mode (default: 30)")
    gen.add_argument("--temperature", type=float, default=0.9, help="LLM temperature (default: 0.9)")
    gen.add_argument("--model", default="qwen2.5:32b", help="Ollama model (default: qwen2.5:32b)")

    sub.add_parser("evaluate", help="Re-evaluate existing generated queries")

    rep = sub.add_parser("report", help="Print report from existing results")
    rep.add_argument("--failures", action="store_true", help="Show all failure details")

    args = parser.parse_args()

    if args.command == "generate":
        return cmd_generate(args)
    elif args.command == "evaluate":
        return cmd_evaluate(args)
    elif args.command == "report":
        return cmd_report(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
