#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER skill evaluation runner.

Validates skills against test case definitions. Checks structural quality,
content coverage, and framework compliance without requiring LLM inference.

Usage:
  python3 evals/runner.py                    # Run all evals
  python3 evals/runner.py --skill blue-team  # Run specific skill
  python3 evals/runner.py --verbose          # Verbose output
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None

SKILLS_DIR = Path(__file__).parent.parent / "skills"
CASES_DIR = Path(__file__).parent / "test_cases"
RESULTS_DIR = Path(__file__).parent / "results"


class SkillEvaluator:
    """Evaluates a skill against structural and content assertions."""

    def __init__(self, skill_name: str):
        self.skill_name = skill_name
        self.skill_path = self._find_skill_path(skill_name)
        self.content = self.skill_path.read_text() if self.skill_path else ""
        self.results: list[dict] = []

    def _find_skill_path(self, name: str) -> Path | None:
        candidates = [
            SKILLS_DIR / name / "SKILL.md",
            SKILLS_DIR / name.replace("-", "/", 1) / "SKILL.md",
        ]
        for c in candidates:
            if c.exists():
                return c
        # Recursive search
        for p in SKILLS_DIR.rglob("SKILL.md"):
            if name in str(p):
                return p
        return None

    def check(self, assertion_type: str, **kwargs) -> dict:
        """Run a single assertion check."""
        result = {"type": assertion_type, "passed": False, "detail": ""}

        if assertion_type == "has_frontmatter":
            result["passed"] = self.content.startswith("---")
            result["detail"] = (
                "YAML frontmatter present"
                if result["passed"]
                else "Missing frontmatter"
            )

        elif assertion_type == "has_field":
            field = kwargs.get("value", "")
            # Search within frontmatter (between first and second ---)
            fm_match = re.search(r"^---\s*\n(.*?)\n---", self.content, re.DOTALL)
            fm_text = fm_match.group(1) if fm_match else self.content[:1000]
            pattern = re.compile(rf"^{field}:", re.MULTILINE)
            result["passed"] = bool(pattern.search(fm_text))
            result["detail"] = (
                f"Field '{field}' {'found' if result['passed'] else 'missing'}"
            )

        elif assertion_type == "has_section":
            section = kwargs.get("value", "")
            result["passed"] = (
                f"## {section}" in self.content or f"# {section}" in self.content
            )
            result["detail"] = (
                f"Section '{section}' {'found' if result['passed'] else 'missing'}"
            )

        elif assertion_type == "contains":
            text = kwargs.get("value", "")
            result["passed"] = text.lower() in self.content.lower()
            result["detail"] = (
                f"Contains '{text}'" if result["passed"] else f"Missing '{text}'"
            )

        elif assertion_type == "matches_regex":
            pattern = kwargs.get("pattern", "")
            result["passed"] = bool(re.search(pattern, self.content))
            result["detail"] = (
                f"Regex '{pattern}' {'matched' if result['passed'] else 'no match'}"
            )

        elif assertion_type == "references":
            framework = kwargs.get("value", "")
            result["passed"] = framework.lower() in self.content.lower()
            result["detail"] = (
                f"References {framework}"
                if result["passed"]
                else f"No reference to {framework}"
            )

        elif assertion_type == "min_length":
            min_len = int(kwargs.get("value", 0))
            actual = len(self.content)
            result["passed"] = actual >= min_len
            result["detail"] = (
                f"Length {actual} {'≥' if result['passed'] else '<'} {min_len}"
            )

        elif assertion_type == "max_length":
            max_len = int(kwargs.get("value", 0))
            actual = len(self.content)
            result["passed"] = actual <= max_len
            result["detail"] = (
                f"Length {actual} {'≤' if result['passed'] else '>'} {max_len}"
            )

        elif assertion_type == "has_script":
            scripts_dir = (
                self.skill_path.parent / "scripts" if self.skill_path else None
            )
            result["passed"] = (
                scripts_dir is not None and any(scripts_dir.iterdir())
                if scripts_dir and scripts_dir.exists()
                else False
            )
            result["detail"] = (
                "Has executable scripts" if result["passed"] else "No scripts"
            )

        elif assertion_type == "has_references":
            refs_dir = (
                self.skill_path.parent / "references" if self.skill_path else None
            )
            has_refs = False
            if refs_dir and refs_dir.exists():
                has_refs = any(refs_dir.iterdir())
            # Also check parent's references dir (for sub-skills like red-team/web)
            if not has_refs and self.skill_path:
                parent_refs = self.skill_path.parent.parent / "references"
                if parent_refs.exists():
                    has_refs = any(parent_refs.iterdir())
            result["passed"] = has_refs
            result["detail"] = (
                "Has reference files" if result["passed"] else "No references"
            )

        elif assertion_type == "has_verification":
            result["passed"] = (
                "## Verification" in self.content or "- [ ]" in self.content
            )
            result["detail"] = (
                "Has verification checklist"
                if result["passed"]
                else "No verification section"
            )

        elif assertion_type == "skill_exists":
            result["passed"] = self.skill_path is not None and self.skill_path.exists()
            result["detail"] = (
                f"Skill file {'exists' if result['passed'] else 'not found'}"
            )

        else:
            result["detail"] = f"Unknown assertion type: {assertion_type}"

        self.results.append(result)
        return result

    def run_standard_checks(self) -> list[dict]:
        """Run standard quality checks applicable to all skills."""
        self.check("skill_exists")
        if not self.skill_path:
            return self.results

        self.check("has_frontmatter")
        self.check("has_field", value="name")
        self.check("has_field", value="description")
        self.check("has_field", value="compatibility")
        self.check("has_section", value="When to Use")
        self.check("has_verification")
        self.check("min_length", value=500)
        self.check("max_length", value=25000)
        self.check("has_references")

        return self.results


def load_test_cases(skill_name: str | None = None) -> list[dict]:
    """Load test case definitions from YAML files."""
    if not yaml:
        return []

    cases = []
    if skill_name:
        path = CASES_DIR / f"{skill_name}.yaml"
        if path.exists():
            cases.append(yaml.safe_load(path.read_text()))
    else:
        if CASES_DIR.exists():
            for f in sorted(CASES_DIR.glob("*.yaml")):
                cases.append(yaml.safe_load(f.read_text()))
    return cases


def discover_skills() -> list[str]:
    """Find all skill names."""
    skills = []
    for p in sorted(SKILLS_DIR.rglob("SKILL.md")):
        rel = p.relative_to(SKILLS_DIR)
        name = str(rel.parent)
        skills.append(name)
    return skills


def main():
    parser = argparse.ArgumentParser(description="CIPHER skill evaluator")
    parser.add_argument("--skill", help="Evaluate specific skill")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--output", help="Save results to JSON file")
    args = parser.parse_args()

    skills = [args.skill] if args.skill else discover_skills()
    all_results = {}
    total_pass = 0
    total_fail = 0

    print("=== CIPHER Skill Evaluation ===")
    print(f"Skills to evaluate: {len(skills)}\n")

    for skill_name in skills:
        evaluator = SkillEvaluator(skill_name)
        results = evaluator.run_standard_checks()

        # Run custom test cases if available
        for case_def in load_test_cases(skill_name):
            for case in case_def.get("cases", []):
                for assertion in case.get("assertions", []):
                    evaluator.check(
                        assertion["type"],
                        **{k: v for k, v in assertion.items() if k != "type"},
                    )

        passed = sum(1 for r in results if r["passed"])
        failed = sum(1 for r in results if not r["passed"])
        total_pass += passed
        total_fail += failed

        status = "✅" if failed == 0 else "🔴"
        print(f"  {status} {skill_name}: {passed}/{len(results)} passed")

        if args.verbose and failed > 0:
            for r in results:
                if not r["passed"]:
                    print(f"      ❌ {r['type']}: {r['detail']}")

        all_results[skill_name] = {
            "passed": passed,
            "failed": failed,
            "total": len(results),
            "details": results,
        }

    print(f"\n{'═' * 50}")
    print(
        f"Total: {total_pass} passed, {total_fail} failed across {len(skills)} skills"
    )
    grade = (
        total_pass / (total_pass + total_fail) * 100
        if (total_pass + total_fail) > 0
        else 0
    )
    print(f"Grade: {grade:.1f}%")

    if args.output:
        RESULTS_DIR.mkdir(exist_ok=True)
        output_path = (
            Path(args.output)
            if os.path.isabs(args.output)
            else RESULTS_DIR / args.output
        )
        output_path.write_text(
            json.dumps(
                {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "skills_evaluated": len(skills),
                    "total_passed": total_pass,
                    "total_failed": total_fail,
                    "grade_pct": grade,
                    "results": all_results,
                },
                indent=2,
            )
        )
        print(f"Results saved: {output_path}")

    sys.exit(0 if total_fail == 0 else 1)


if __name__ == "__main__":
    main()
