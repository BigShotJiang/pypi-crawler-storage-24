# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""Behavioral test runner for CIPHER eval dataset.

Tests mode routing deterministically against detect_mode().
Other categories (knowledge accuracy, adversarial, etc.) require LLM
evaluation and are validated structurally here — the JSON schema,
field completeness, and category distribution.
"""

import json
import sys
from pathlib import Path

# Allow running from project root
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.gateway.mode import detect_mode, parse_keyword_table  # noqa: E402


def load_claude_md() -> str:
    """Load CLAUDE.md from project root."""
    p = PROJECT_ROOT / "CLAUDE.md"
    return p.read_text(encoding="utf-8")


def load_tests() -> list[dict]:
    """Load behavioral test cases."""
    p = PROJECT_ROOT / "evals" / "behavioral_tests.json"
    return json.loads(p.read_text(encoding="utf-8"))


def run_mode_routing_tests(
    tests: list[dict], keyword_table: dict[str, list[str]]
) -> list[dict]:
    """Run MODE_ROUTING tests against detect_mode().

    Returns list of result dicts with pass/fail and diagnostics.
    """
    results = []
    for t in tests:
        if t["category"] != "MODE_ROUTING":
            continue

        mode, needs_clarify = detect_mode(t["input"], keyword_table)
        expected = t["mode_expected"]

        if expected == "CLARIFY":
            passed = needs_clarify
            actual = f"{mode} (clarify={needs_clarify})"
        else:
            passed = (mode == expected) and not needs_clarify
            actual = f"{mode} (clarify={needs_clarify})"

        results.append(
            {
                "id": t["id"],
                "category": t["category"],
                "expected": expected,
                "actual": actual,
                "passed": passed,
                "input_preview": t["input"][:80],
            }
        )
    return results


def run_structural_validation(tests: list[dict]) -> list[dict]:
    """Validate all test cases have correct structure and field values."""
    results = []
    valid_categories = {
        "MODE_ROUTING",
        "KNOWLEDGE_ACCURACY",
        "ADVERSARIAL_INJECTION",
        "CONTEXT_COLLAPSE",
        "SCOPE_CREEP",
        "OUT_OF_SCOPE",
        "EDGE_CASES",
    }
    valid_severities = {"critical", "high", "medium", "low"}
    valid_modes = {"RED", "BLUE", "PURPLE", "PRIVACY", "RECON", "INCIDENT", "ARCHITECT", "CLARIFY"}
    required_fields = {"id", "category", "input", "expected_behavior", "must_not", "mode_expected", "severity"}

    seen_ids: set[str] = set()
    for t in tests:
        errors: list[str] = []

        # Required fields
        missing = required_fields - set(t.keys())
        if missing:
            errors.append(f"missing fields: {missing}")

        # Unique ID
        tid = t.get("id", "UNKNOWN")
        if tid in seen_ids:
            errors.append(f"duplicate id: {tid}")
        seen_ids.add(tid)

        # Valid category
        if t.get("category") not in valid_categories:
            errors.append(f"invalid category: {t.get('category')}")

        # Valid severity
        if t.get("severity") not in valid_severities:
            errors.append(f"invalid severity: {t.get('severity')}")

        # Valid mode
        if t.get("mode_expected") not in valid_modes:
            errors.append(f"invalid mode_expected: {t.get('mode_expected')}")

        # Non-empty behavioral fields
        for field in ("expected_behavior", "must_not"):
            val = t.get(field, "")
            if len(val) < 10:
                errors.append(f"{field} too short ({len(val)} chars)")

        results.append(
            {
                "id": tid,
                "passed": len(errors) == 0,
                "errors": errors,
            }
        )
    return results


def run_category_distribution(tests: list[dict]) -> dict:
    """Verify category distribution matches spec."""
    from collections import Counter

    counts = Counter(t["category"] for t in tests)
    expected = {
        "MODE_ROUTING": 10,
        "KNOWLEDGE_ACCURACY": 10,
        "ADVERSARIAL_INJECTION": 10,
        "CONTEXT_COLLAPSE": 5,
        "SCOPE_CREEP": 5,
        "OUT_OF_SCOPE": 5,
        "EDGE_CASES": 5,
    }
    errors = []
    for cat, exp in expected.items():
        actual = counts.get(cat, 0)
        if actual != exp:
            errors.append(f"{cat}: expected {exp}, got {actual}")
    return {
        "total": len(tests),
        "distribution": dict(counts),
        "errors": errors,
        "passed": len(errors) == 0,
    }


def main() -> int:
    tests = load_tests()
    claude_md = load_claude_md()
    keyword_table = parse_keyword_table(claude_md)

    print(f"Loaded {len(tests)} test cases")
    print(f"Keyword table: {len(keyword_table)} modes, {sum(len(v) for v in keyword_table.values())} keywords")
    print()

    # 1. Structural validation
    print("=" * 60)
    print("STRUCTURAL VALIDATION")
    print("=" * 60)
    struct_results = run_structural_validation(tests)
    struct_pass = sum(1 for r in struct_results if r["passed"])
    struct_fail = sum(1 for r in struct_results if not r["passed"])
    for r in struct_results:
        if not r["passed"]:
            print(f"  FAIL {r['id']}: {r['errors']}")
    print(f"  {struct_pass}/{len(struct_results)} passed, {struct_fail} failed")
    print()

    # 2. Category distribution
    print("=" * 60)
    print("CATEGORY DISTRIBUTION")
    print("=" * 60)
    dist = run_category_distribution(tests)
    for cat, count in sorted(dist["distribution"].items()):
        print(f"  {cat}: {count}")
    if dist["errors"]:
        for e in dist["errors"]:
            print(f"  FAIL: {e}")
    else:
        print(f"  ✅ All categories match spec ({dist['total']} total)")
    print()

    # 3. Mode routing tests
    print("=" * 60)
    print("MODE ROUTING TESTS")
    print("=" * 60)
    mode_results = run_mode_routing_tests(tests, keyword_table)
    mode_pass = sum(1 for r in mode_results if r["passed"])
    mode_fail = sum(1 for r in mode_results if not r["passed"])
    for r in mode_results:
        status = "PASS" if r["passed"] else "FAIL"
        print(f"  {status} {r['id']}: expected={r['expected']}, actual={r['actual']}")
        if not r["passed"]:
            print(f"         input: {r['input_preview']}")
    print(f"\n  {mode_pass}/{len(mode_results)} passed, {mode_fail} failed")

    # Summary
    print()
    print("=" * 60)
    print("SUMMARY")
    print("=" * 60)
    total_pass = struct_pass + (1 if dist["passed"] else 0) + mode_pass
    total_tests = len(struct_results) + 1 + len(mode_results)
    total_fail = total_tests - total_pass
    print(f"  Total: {total_pass}/{total_tests} passed, {total_fail} failed")

    return 0 if total_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
