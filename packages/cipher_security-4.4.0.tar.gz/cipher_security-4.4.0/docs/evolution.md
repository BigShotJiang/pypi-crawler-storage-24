<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Self-Evolution System

CIPHER can detect gaps in its own capabilities and generate new skills
to fill them.

## Architecture

```
┌────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  Gap       │────▶│  Skill       │────▶│  Skill       │────▶│  Skill       │
│  Tracker   │     │  Synthesis   │     │  Validator   │     │  Registry    │
└────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
```

## Gap Types

| Type | Trigger |
|------|---------|
| `missing_skill` | No skill exists for the domain |
| `shallow_coverage` | Existing skill lacks depth |
| `outdated` | Skill references obsolete information |
| `failed_task` | CIPHER failed a task in this domain |
| `new_threat` | New threat landscape requires coverage |
| `tool_gap` | Missing executable tooling |

## Validator Rules

- Kebab-case names (2-64 characters)
- Minimum 30 lines
- 8 required frontmatter fields
- Required sections: When to Use, Workflow, Verification
- Warns on missing code blocks or checklists
- Maximum 300 lines recommended (progressive disclosure)

## Usage

```python
from evolution.core.engine import EvolutionEngine

engine = EvolutionEngine(skills_dir="skills", index_path="index.json")

# Report a gap
engine.report_gap(
    gap_type="missing_skill",
    description="No skill for Kubernetes admission controller security",
    confidence=0.9,
)

# Check pending gaps
gaps = engine.get_pending_gaps(min_confidence=0.7)

# Validate and register a new skill
result = engine.validate_skill(skill_content)
if result.is_valid:
    engine.register_skill(skill_content, "k8s-admission-security")
```
