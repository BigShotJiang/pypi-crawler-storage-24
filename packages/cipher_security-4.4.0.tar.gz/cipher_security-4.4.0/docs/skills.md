<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Skills Catalog

CIPHER ships with 38 skills across 35 subdomains. Every skill follows the
[AgentSkills specification](https://agentskills.io) with YAML frontmatter,
executable scripts, reference files, and verification checklists.

## Offensive Security

| Skill | Description | Scripts |
|-------|-------------|---------|
| [red-team](../skills/red-team/SKILL.md) | Red team engagement router with kill chain methodology | `service_scan.sh` |
| [red-team/web](../skills/red-team/web/SKILL.md) | Web application penetration testing | `web_vuln_scan.sh` |
| [red-team/active-directory](../skills/red-team/active-directory/SKILL.md) | Active Directory attacks and enumeration | `ad_enum.sh` |
| [red-team/cloud](../skills/red-team/cloud/SKILL.md) | Cloud infrastructure attacks (AWS/Azure/GCP) | `aws_enum.py` |
| [red-team/post-exploitation](../skills/red-team/post-exploitation/SKILL.md) | Post-exploitation and credential harvesting | `cred_harvest_check.sh` |
| [osint-recon](../skills/osint-recon/SKILL.md) | OSINT and passive reconnaissance | `subdomain_enum.sh` |

## Defensive Security

| Skill | Description | Scripts |
|-------|-------------|---------|
| [blue-team](../skills/blue-team/SKILL.md) | Detection engineering and Sigma rules | `validate_sigma.py` |
| [soc-operations](../skills/soc-operations/SKILL.md) | SOC alert triage, hunting, SOAR playbooks | `log_analyzer.py` |
| [incident-response](../skills/incident-response/SKILL.md) | IR triage, containment, evidence preservation | `collect_evidence.sh` |
| [threat-intelligence](../skills/threat-intelligence/SKILL.md) | CTI, IOC enrichment, attribution | `extract_iocs.py` |
| [digital-forensics](../skills/digital-forensics/SKILL.md) | Disk imaging, timeline analysis, memory forensics | `timeline_builder.py` |

## Detection & Analysis

| Skill | Description | Scripts |
|-------|-------------|---------|
| [purple-team](../skills/purple-team/SKILL.md) | Adversary emulation, detection coverage mapping | `attack_coverage.py` |
| [ransomware-defense](../skills/ransomware-defense/SKILL.md) | Ransomware kill chain detection, 3-2-1-1-0 backup | `backup_check.sh` |
| [phishing-defense](../skills/phishing-defense/SKILL.md) | SPF/DKIM/DMARC, BEC detection, GoPhish | `check_email_auth.sh` |
| [malware-analysis](../skills/malware-analysis/SKILL.md) | Static/dynamic analysis, YARA rules, Ghidra | `validate_yara.py` |

## Application Security

| Skill | Description | Scripts |
|-------|-------------|---------|
| [api-security](../skills/api-security/SKILL.md) | BOLA/IDOR, JWT, GraphQL, OWASP API Top 10 | `api_fuzz.py` |
| [devsecops](../skills/devsecops/SKILL.md) | SAST/DAST/SCA pipeline, SBOM, secrets detection | `scan_secrets.sh` |
| [pr-security-review](../skills/pr-security-review/SKILL.md) | Security-focused code review for pull requests | `review_pr.sh` |
| [nuclei-templating](../skills/nuclei-templating/SKILL.md) | Nuclei vulnerability detection template authoring | `validate_template.py` |
| [ai-llm-security](../skills/ai-llm-security/SKILL.md) | Prompt injection, OWASP LLM Top 10, MITRE ATLAS | `prompt_injection_scan.py` |

## Infrastructure

| Skill | Description | Scripts |
|-------|-------------|---------|
| [cloud-security](../skills/cloud-security/SKILL.md) | CSPM, IAM review, CloudTrail forensics | `cloudtrail_analyzer.py` |
| [container-security](../skills/container-security/SKILL.md) | Docker escape, K8s RBAC, Falco/Tetragon | `k8s_rbac_audit.sh`, `docker_audit.sh` |
| [network-security](../skills/network-security/SKILL.md) | Firewall, Suricata IDS/IPS, ZTNA, segmentation | `tls_check.sh` |
| [wireless-security](../skills/wireless-security/SKILL.md) | WPA2/WPA3 attacks, evil twin, Bluetooth/BLE | `wifi_audit.sh` |
| [ot-ics-security](../skills/ot-ics-security/SKILL.md) | SCADA/PLC, Modbus/DNP3/OPC-UA, IEC 62443 | `modbus_scan.py` |

## Identity, Data & Privacy

| Skill | Description | Scripts |
|-------|-------------|---------|
| [identity-access-management](../skills/identity-access-management/SKILL.md) | MFA bypass, SAML/OAuth2 attacks, zero trust identity | `jwt_analyzer.py` |
| [data-security](../skills/data-security/SKILL.md) | DLP, classification, tokenization, DSPM | `classify_data.py` |
| [cryptography](../skills/cryptography/SKILL.md) | TLS hardening, PKI, key management, post-quantum | `cert_check.py` |
| [privacy-engineering](../skills/privacy-engineering/SKILL.md) | GDPR/CCPA/HIPAA, DPIAs, anonymization | `pii_scanner.py` |

## Governance & Compliance

| Skill | Description | Scripts |
|-------|-------------|---------|
| [compliance-audit](../skills/compliance-audit/SKILL.md) | SOC 2, PCI DSS v4.0, FedRAMP, ISO 27001 | `collect_evidence.py` |
| [vulnerability-management](../skills/vulnerability-management/SKILL.md) | CVSS/EPSS/SSVC/KEV prioritization, SLAs | `epss_lookup.py` |
| [supply-chain-security](../skills/supply-chain-security/SKILL.md) | SBOM, SLSA, dependency confusion | `generate_sbom.sh` |
| [mobile-security](../skills/mobile-security/SKILL.md) | Frida, certificate pinning bypass, OWASP MASVS | `apk_analyze.sh` |

## Architecture & Automation

| Skill | Description | Scripts |
|-------|-------------|---------|
| [security-architecture](../skills/security-architecture/SKILL.md) | Zero trust design, threat modeling, blast radius | `threat_model.py` |
| [automation-scripting](../skills/automation-scripting/SKILL.md) | Ansible, Terraform, Docker, secrets management | `cis_check.sh` |

## Platform (Meta-Skills)

| Skill | Description |
|-------|-------------|
| [cross-session-memory](../skills/cross-session-memory/SKILL.md) | Tri-layer memory engine with RRF fusion |
| [self-evolution](../skills/self-evolution/SKILL.md) | Gap detection → skill synthesis → validation |
| [engagement-pipeline](../skills/engagement-pipeline/SKILL.md) | 5-stage gated engagement methodology |
