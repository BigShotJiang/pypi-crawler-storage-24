# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""KB article scaffolding generator.

Parses the master topic list and generates structured article skeletons
for topics that don't yet have articles. Each skeleton includes:
- Copyright headers
- Title and metadata
- Table of contents
- Section headers matching the domain structure
- Cross-references to relevant CIPHER skills
- Placeholder content with guidance for completion

Usage:
    python -m docs.kb_scaffold --master /path/to/cipher-kb-master-list.md
    python -m docs.kb_scaffold --dry-run   # Show what would be generated
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

_COPYRIGHT = (
    "<!-- Copyright (c) 2026 defconxt. All rights reserved. -->\n"
    "<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->\n"
    "<!-- CIPHER is a trademark of defconxt. -->\n"
)

# Map section names from master list → CIPHER skill domains
_SECTION_TO_DOMAINS: dict[str, list[str]] = {
    "Networking Fundamentals": ["network-security"],
    "Authentication & Identity": ["active-directory-security", "iam-security"],
    "Linux Fundamentals": ["linux-security"],
    "Windows Fundamentals": ["windows-security"],
    "Cryptography": ["cryptography"],
    "Web Application Security": ["web-application-security"],
    "API Security": ["api-security"],
    "Cloud Security": ["cloud-security"],
    "Container Security": ["container-security"],
    "Mobile Security": ["mobile-security"],
    "Network Security": ["network-security"],
    "Wireless Security": ["wireless-security"],
    "Malware Analysis": ["malware-analysis"],
    "Reverse Engineering": ["reverse-engineering"],
    "Digital Forensics": ["digital-forensics"],
    "Incident Response": ["incident-response"],
    "Threat Intelligence": ["threat-intelligence"],
    "OSINT": ["osint-techniques"],
    "Active Directory": ["active-directory-security"],
    "Binary Exploitation": ["binary-exploitation"],
    "Social Engineering": ["social-engineering"],
    "Supply Chain": ["supply-chain-security"],
    "Privacy": ["privacy-engineering"],
    "Compliance": ["compliance-auditing"],
    "Secure Coding": ["secure-coding"],
    "Bug Bounty": ["bug-bounty"],
    "Red Team": ["red-team-operations"],
    "Blue Team": ["blue-team-operations"],
    "Purple Team": ["detection-engineering"],
    "Log Analysis": ["log-analysis"],
    "SIEM": ["log-analysis"],
    "IoT": ["iot-security"],
    "ICS": ["ics-scada-security"],
    "Blockchain": ["blockchain-security"],
    "AI Security": ["ai-ml-security"],
    "Zero Trust": ["zero-trust"],
}


@dataclass
class TopicEntry:
    """A single topic from the master list."""

    section: str
    topic: str
    priority: str  # 🔴 🟡 🟢
    slug: str = ""

    def __post_init__(self) -> None:
        if not self.slug:
            self.slug = re.sub(r"[^a-z0-9]+", "-", self.topic.lower().strip()).strip(
                "-"
            )


@dataclass
class ScaffoldResult:
    """Result of scaffold generation."""

    generated: list[str] = field(default_factory=list)
    skipped_existing: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated": len(self.generated),
            "skipped_existing": len(self.skipped_existing),
            "errors": self.errors,
            "files": self.generated,
        }


def parse_master_list(master_path: str | Path) -> list[TopicEntry]:
    """Parse the KB master list markdown into structured topic entries."""
    path = Path(master_path)
    content = path.read_text()

    topics: list[TopicEntry] = []
    current_section = ""

    for line in content.splitlines():
        if line.startswith("### "):
            current_section = line[4:].strip()
        elif line.startswith("| ") and "|" in line[2:]:
            cells = [c.strip() for c in line.split("|")[1:-1]]
            if len(cells) >= 2 and cells[0]:
                # Skip header rows
                if cells[0] in ("Topic", "---") or cells[1] in ("Priority", "---"):
                    continue
                if cells[0].startswith("---"):
                    continue
                topics.append(
                    TopicEntry(
                        section=current_section,
                        topic=cells[0],
                        priority=cells[1] if len(cells) > 1 else "🟢",
                    )
                )

    return topics


def _find_related_skills(section: str, topic: str, skills_root: Path) -> list[str]:
    """Find CIPHER skill domains related to a topic."""
    domains: list[str] = []

    # Match by section name
    for key, doms in _SECTION_TO_DOMAINS.items():
        if key.lower() in section.lower():
            domains.extend(doms)

    # Match by topic keywords
    topic_lower = topic.lower()
    keyword_map = {
        "xss": "web-application-security",
        "sql injection": "web-application-security",
        "kerberos": "active-directory-security",
        "ldap": "active-directory-security",
        "docker": "container-security",
        "kubernetes": "container-security",
        "aws": "cloud-security",
        "azure": "cloud-security",
        "gcp": "cloud-security",
        "sigma": "log-analysis",
        "splunk": "log-analysis",
        "wireshark": "network-security",
        "nmap": "network-security",
        "burp": "web-application-security",
        "ghidra": "reverse-engineering",
        "ida": "reverse-engineering",
        "volatility": "digital-forensics",
        "yara": "malware-analysis",
        "osint": "osint-techniques",
        "phishing": "social-engineering",
        "buffer overflow": "binary-exploitation",
        "rop": "binary-exploitation",
        "oauth": "api-security",
        "jwt": "api-security",
        "tls": "cryptography",
        "ssl": "cryptography",
        "encryption": "cryptography",
    }
    for keyword, domain in keyword_map.items():
        if keyword in topic_lower and domain not in domains:
            domains.append(domain)

    # Verify domains exist
    verified: list[str] = []
    for d in domains[:3]:
        if (skills_root / d).is_dir():
            verified.append(d)

    return verified


def generate_article(topic: TopicEntry, skills_root: Path) -> str:
    """Generate a scaffold article for a topic."""
    related = _find_related_skills(topic.section, topic.topic, skills_root)
    now = datetime.now().strftime("%Y-%m-%d")

    # List techniques from related domains
    technique_refs: list[str] = []
    for domain in related:
        tech_dir = skills_root / domain / "techniques"
        if tech_dir.is_dir():
            techs = sorted(d.name for d in tech_dir.iterdir() if d.is_dir())[:6]
            for t in techs:
                technique_refs.append(f"- `skills/{domain}/techniques/{t}/`")

    skill_section = ""
    if technique_refs:
        skill_section = (
            "\n## Related CIPHER Skills\n\n" + "\n".join(technique_refs) + "\n"
        )

    priority_label = {
        "🔴": "Critical",
        "🟡": "High",
        "🟢": "Standard",
    }.get(topic.priority.strip(), "Standard")

    return f"""{_COPYRIGHT}
# {topic.topic}

> CIPHER Knowledge Base | Section: {topic.section} | Priority: {priority_label}
> Generated: {now} | Status: Scaffold — needs content

---

## Overview

<!-- TODO: Write 2-3 paragraph overview of {topic.topic} -->
<!-- Cover: what it is, why it matters for security, and how it fits into the broader domain -->

---

## Key Concepts

<!-- TODO: List and explain 5-8 core concepts -->

### Concept 1

<!-- Description -->

### Concept 2

<!-- Description -->

---

## Practical Application

<!-- TODO: Provide hands-on examples, commands, and configurations -->

### Example 1

```
# TODO: Add practical command or code example
```

### Example 2

```
# TODO: Add practical command or code example
```

---

## Security Implications

<!-- TODO: Explain attack surface, common vulnerabilities, and defensive measures -->

### Attack Vectors

<!-- How attackers exploit this technology/concept -->

### Defensive Measures

<!-- How defenders protect against these attacks -->

---

## Detection & Monitoring

<!-- TODO: Sigma rules, log sources, SIEM queries -->

### Log Sources

<!-- Relevant log sources for this topic -->

### Detection Rules

```yaml
# TODO: Add Sigma rule or detection logic
```

---
{skill_section}
## References

<!-- TODO: Add authoritative references -->
- [ ] Official documentation
- [ ] MITRE ATT&CK mapping (if applicable)
- [ ] CIS Benchmark reference (if applicable)
- [ ] Relevant CVEs or advisories

---

> **Note:** This article was auto-scaffolded from the CIPHER KB master list.
> Sections marked with `TODO` need content from domain experts.
"""


def scaffold_articles(
    master_path: str | Path,
    output_dir: str | Path,
    skills_root: str | Path,
    dry_run: bool = False,
) -> ScaffoldResult:
    """Generate scaffold articles for all topics missing from the KB."""
    master = Path(master_path)
    outdir = Path(output_dir)
    skillsdir = Path(skills_root)
    result = ScaffoldResult()

    topics = parse_master_list(master)

    # Find existing articles
    existing_slugs: set[str] = set()
    if outdir.is_dir():
        for f in outdir.iterdir():
            if f.suffix == ".md":
                existing_slugs.add(f.stem)

    for topic in topics:
        slug = topic.slug
        if not slug:
            continue

        # Check if article exists (exact or partial match)
        if slug in existing_slugs or any(slug in es for es in existing_slugs):
            result.skipped_existing.append(slug)
            continue

        if dry_run:
            result.generated.append(f"{slug}.md (dry-run)")
            continue

        try:
            article = generate_article(topic, skillsdir)
            outpath = outdir / f"{slug}.md"
            outpath.write_text(article)
            result.generated.append(str(outpath))
        except Exception as exc:
            result.errors.append(f"{slug}: {exc}")

    return result


def main() -> int:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="CIPHER KB article scaffolding generator"
    )
    parser.add_argument(
        "--master",
        default="/home/void/Documents/LEARN-MORE/cipher-kb-master-list.md",
        help="Path to KB master topic list",
    )
    parser.add_argument(
        "--output", default="knowledge/", help="Output directory for articles"
    )
    parser.add_argument(
        "--skills", default="skills/", help="Skills directory for cross-references"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be generated without writing files",
    )
    args = parser.parse_args()

    result = scaffold_articles(
        args.master, args.output, args.skills, dry_run=args.dry_run
    )
    print(json.dumps(result.to_dict(), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
