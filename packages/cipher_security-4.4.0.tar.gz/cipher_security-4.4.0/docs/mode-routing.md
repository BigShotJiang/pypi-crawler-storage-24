<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Mode Routing Architecture

CIPHER uses a **keyword-weighted scoring system** to automatically route user queries to one of 7 security operating modes. This document records the architecture, measured performance, and known limitations.

## How It Works

1. **Parse keyword table** from `CLAUDE.md` — 7 modes with trigger keywords
2. **Supplement** with `_SUPPLEMENTARY_KEYWORDS` — 326 additional keywords covering tools, techniques, attack types, and defensive terms
3. **Score each mode** by counting keyword matches in the query, weighted by phrase length:
   - Multi-word phrases (e.g., "pass the hash") score by word count (3 points)
   - Single words score 1 point
   - Generic/ambiguous keywords (`enumerate`, `credential`, `persistence`) score 0.5
4. **Intent-based disambiguation** resolves ambiguity when RED and BLUE both score high:
   - Defensive signals (`detect`, `hunt for`, `write a rule`, `alert on`) boost BLUE and reduce RED
   - Incident signals (`we suspect`, `our siem shows`, `how do we contain`) boost INCIDENT
   - PURPLE guard prevents defensive boost from stealing PURPLE queries
5. **CLARIFY** returned when top two modes tie (within threshold)
6. **ARCHITECT** is the default when no keywords match

## Measured Performance

Three independent evaluation runs using **4,892 LLM-generated queries** at temperature 0.9 (high variance via Ollama qwen2.5:32b):

| Mode | Queries | Accuracy | Failure Pattern |
|------|---------|----------|-----------------|
| ARCHITECT | 655 | **93.9%** | Leaks to PRIVACY on HIPAA/GDPR architecture queries |
| PRIVACY | 715 | **93.7%** | Leaks to ARCHITECT on "privacy impact assessment" phrasing |
| INCIDENT | 715 | **83.2%** | Leaks to RED when query mentions specific attack techniques |
| BLUE | 672 | **78.3%** | Leaks to RED/ARCHITECT — detection queries mention attack names |
| RECON | 715 | **77.2%** | Leaks to ARCHITECT — natural language without tool keywords |
| RED | 712 | **76.4%** | Leaks to ARCHITECT — attack descriptions without tool names |
| PURPLE | 708 | **68.9%** | Leaks to BLUE/RED — inherently bridges both vocabularies |
| **Overall** | **4,892** | **81.5%** | |

### Confusion Matrix (Run 3, 4,892 queries)

```
             ARCHITECT  BLUE  INCIDENT  PRIVACY  PURPLE  RECON  RED  CLARIFY
ARCHITECT          590     7         5       22       0      0    5       26
BLUE                46   472        26        0      12     10   52       54
INCIDENT            65    13       538        0       0      1   40       58
PRIVACY             33     1         3      592       8      0    0       78
PURPLE              43   100        12        0     393      1   52      105
RECON              116    30         3        0       0    512   13       41
RED                 85    58         5        0       0     16  507       41
```

## The 81% Ceiling

Keyword-only classification has an inherent ceiling around **81-83%**. This was confirmed across 3 independent runs with different random seeds all converging to the same range.

### Why queries fail

Queries that miss classification fall into predictable categories:

1. **Natural language without keywords** — "Detail the steps to perform a VLAN hopping attack" (no RED keyword before "vlan hopping" was added; pattern repeats with novel attack names)
2. **Cross-domain vocabulary** — "What are the best techniques for evading antivirus detection when deploying a RAT" (RED query but contains "detection" → BLUE signal)
3. **Implied context** — "Walk me through setting up an environment to test emails effectively" (phishing context implied but no keyword present)
4. **PURPLE's inherent ambiguity** — Purple team queries legitimately contain both RED and BLUE vocabulary by definition

### What would break past 85%

An **LLM-based fallback classifier** for low-confidence scores:
- When no mode scores above a confidence threshold, route the query to a lightweight model for classification
- Could use a fine-tuned small model or even a zero-shot prompt: "Classify this cybersecurity query as RED/BLUE/PURPLE/PRIVACY/RECON/INCIDENT/ARCHITECT"
- Trade-off: adds latency (~100-500ms) and requires an LLM endpoint for routing

This is intentionally **not implemented** because:
- 81.5% with zero latency and zero dependencies is a strong baseline
- The keyword system handles the critical path (tool-specific queries) with 90%+ accuracy
- Misrouted queries still get useful responses — ARCHITECT mode handles general security questions well
- The LLM classifier can be added as an optional enhancement without changing the core architecture

## Keyword Distribution

| Mode | Keywords | Top Examples |
|------|----------|-------------|
| RED | 127 | mimikatz, sql injection, pass the hash, buffer overflow, ssrf, csrf, vlan hopping |
| BLUE | 76 | splunk, sigma, yara, sysmon, honeypot, elk stack, anomaly detection, soar, mttd |
| INCIDENT | 43 | compromised, ransomware, forensic analysis, evidence preservation, chain of custody |
| RECON | 38 | shodan, censys, subdomain enumeration, google dorking, attack surface, theharvester |
| PURPLE | 26 | detection coverage, adversary emulation, atomic red team, coverage gaps, caldera |
| PRIVACY | 10 | GDPR, CCPA, HIPAA, DPIA, privacy by design, anonymization |
| ARCHITECT | 7 | design, architecture, threat model, zero trust, blast radius |

Total: **326 keywords** across 7 modes.

## Evaluation System

The scale eval system (`evals/scale_eval.py`) generates diverse test queries via Ollama:

```bash
# Generate 200 queries per mode at high temperature
PYTHONPATH=src/:. python3 evals/scale_eval.py generate --count 200 --temperature 0.9

# Re-evaluate against current keyword table (no regeneration)
PYTHONPATH=src/:. python3 evals/scale_eval.py evaluate

# View results with top-3 failure examples per mode
PYTHONPATH=src/:. python3 evals/scale_eval.py report --failures
```

Additionally, 50 hand-crafted behavioral tests (`evals/behavioral_tests.json`) cover mode routing, adversarial injection resistance, context collapse, and scope boundaries — evaluated by `evals/run_behavioral.py` (61/61 passing).
