# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""Auto-generate documentation site from SKILL.md files.

Produces a static documentation site (Markdown + index) from the
CIPHER skill tree. Can output as:
- Markdown directory tree (for mkdocs/docusaurus)
- Single-page combined reference
- JSON API schema

Architecture and implementation are original CIPHER designs.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class DocSiteGenerator:
    """Generate documentation site from skill files."""

    def __init__(
        self,
        skills_dir: Path | str = "skills",
        output_dir: Path | str = "site",
    ) -> None:
        self.skills_dir = Path(skills_dir)
        self.output_dir = Path(output_dir)
        self._domains: dict[str, list[dict]] = {}

    def scan_skills(self) -> dict[str, list[dict]]:
        """Scan all skills and build domain→techniques map."""
        self._domains = {}

        for domain_dir in sorted(self.skills_dir.iterdir()):
            if not domain_dir.is_dir() or domain_dir.name.startswith("."):
                continue

            techniques = []
            tech_dir = domain_dir / "techniques"
            if not tech_dir.exists():
                continue

            for tech in sorted(tech_dir.iterdir()):
                if not tech.is_dir():
                    continue
                skill_md = tech / "SKILL.md"
                if not skill_md.exists():
                    continue

                meta = self._parse_frontmatter(skill_md)
                meta["path"] = str(tech.relative_to(self.skills_dir))
                meta["has_agent"] = (tech / "scripts" / "agent.py").exists()
                meta["has_reference"] = (
                    any((tech / "references").glob("*.md"))
                    if (tech / "references").exists()
                    else False
                )
                techniques.append(meta)

            if techniques:
                self._domains[domain_dir.name] = techniques

        return self._domains

    def generate_mkdocs(self) -> Path:
        """Generate mkdocs-compatible documentation structure."""
        if not self._domains:
            self.scan_skills()

        docs_dir = self.output_dir / "docs"
        docs_dir.mkdir(parents=True, exist_ok=True)

        # Generate index
        self._write_index(docs_dir)

        # Generate domain pages
        for domain, techniques in self._domains.items():
            domain_dir = docs_dir / domain
            domain_dir.mkdir(exist_ok=True)
            self._write_domain_page(domain_dir, domain, techniques)

            # Copy technique SKILL.md files
            for tech in techniques:
                src = self.skills_dir / tech["path"] / "SKILL.md"
                if src.exists():
                    dest = domain_dir / f"{Path(tech['path']).name}.md"
                    content = src.read_text()
                    # Strip YAML frontmatter for clean docs
                    content = self._strip_frontmatter(content)
                    dest.write_text(content)

        # Generate mkdocs.yml
        self._write_mkdocs_config(self.output_dir)

        return self.output_dir

    def generate_single_page(self) -> str:
        """Generate a single-page combined reference."""
        if not self._domains:
            self.scan_skills()

        lines = [
            "<!-- Copyright (c) 2026 defconxt. All rights reserved. -->",
            "<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->",
            "<!-- CIPHER is a trademark of defconxt. -->",
            "",
            "# CIPHER Skills Reference",
            "",
            f"*Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}*",
            "",
            f"**{sum(len(t) for t in self._domains.values())} techniques across {len(self._domains)} domains**",
            "",
            "---",
            "",
            "## Table of Contents",
            "",
        ]

        # TOC
        for domain in sorted(self._domains):
            title = domain.replace("-", " ").title()
            lines.append(
                f"- [{title}](#{domain}) ({len(self._domains[domain])} techniques)"
            )

        lines.append("")

        # Domain sections
        for domain in sorted(self._domains):
            title = domain.replace("-", " ").title()
            lines.append(f"## {title}")
            lines.append("")
            lines.append(f"*{len(self._domains[domain])} techniques*")
            lines.append("")

            for tech in self._domains[domain]:
                name = tech.get("name", Path(tech["path"]).name)
                desc = tech.get("description", "")
                lines.append(f"### {name}")
                if desc:
                    lines.append(f"\n{desc}")
                tags = tech.get("tags", [])
                if tags:
                    lines.append(f"\n**Tags:** {', '.join(tags)}")
                lines.append("")

        return "\n".join(lines)

    def generate_api_schema(self) -> dict:
        """Generate JSON API schema for skill discovery."""
        if not self._domains:
            self.scan_skills()

        return {
            "version": "4.0.0",
            "generated": datetime.now(timezone.utc).isoformat(),
            "stats": {
                "domains": len(self._domains),
                "techniques": sum(len(t) for t in self._domains.values()),
            },
            "domains": {
                domain: {
                    "name": domain.replace("-", " ").title(),
                    "technique_count": len(techniques),
                    "techniques": [
                        {
                            "name": t.get("name", ""),
                            "description": t.get("description", ""),
                            "path": t["path"],
                            "has_agent": t.get("has_agent", False),
                            "has_reference": t.get("has_reference", False),
                            "tags": t.get("tags", []),
                        }
                        for t in techniques
                    ],
                }
                for domain, techniques in sorted(self._domains.items())
            },
        }

    def _parse_frontmatter(self, skill_md: Path) -> dict:
        """Parse YAML frontmatter from a SKILL.md file."""
        content = skill_md.read_text()
        meta: dict[str, Any] = {"name": skill_md.parent.name}

        # Find YAML block between --- markers
        matches = list(re.finditer(r"^---\s*$", content, re.MULTILINE))
        if len(matches) >= 2:
            yaml_text = content[matches[0].end() : matches[1].start()]
            for line in yaml_text.strip().splitlines():
                line = line.strip()
                if line.startswith("- "):
                    # Tag list item
                    if "tags" not in meta:
                        meta["tags"] = []
                    meta["tags"].append(line[2:].strip())
                elif ":" in line and not line.startswith("#"):
                    key, _, val = line.partition(":")
                    key = key.strip()
                    val = val.strip().strip(">-").strip()
                    if val and key in (
                        "name",
                        "description",
                        "domain",
                        "subdomain",
                        "expertise_level",
                    ):
                        meta[key] = val

        return meta

    def _strip_frontmatter(self, content: str) -> str:
        """Remove YAML frontmatter and copyright headers."""
        # Remove copyright HTML comments
        content = re.sub(r"<!--.*?-->\s*\n?", "", content, flags=re.DOTALL)
        # Remove YAML frontmatter
        matches = list(re.finditer(r"^---\s*$", content, re.MULTILINE))
        if len(matches) >= 2:
            content = content[matches[1].end() :].strip()
        return content

    def _write_index(self, docs_dir: Path) -> None:
        """Write the documentation index page."""
        total = sum(len(t) for t in self._domains.values())
        lines = [
            "# CIPHER Security Skills",
            "",
            f"**{total} techniques across {len(self._domains)} security domains**",
            "",
            "## Domains",
            "",
            "| Domain | Techniques | Coverage |",
            "|--------|-----------|----------|",
        ]
        for domain in sorted(self._domains):
            count = len(self._domains[domain])
            bar = "█" * (count // 3) + "░" * ((24 - count) // 3)
            title = domain.replace("-", " ").title()
            lines.append(f"| [{title}]({domain}/) | {count} | {bar} |")

        (docs_dir / "index.md").write_text("\n".join(lines) + "\n")

    def _write_domain_page(
        self, domain_dir: Path, domain: str, techniques: list[dict]
    ) -> None:
        """Write a domain overview page."""
        title = domain.replace("-", " ").title()
        lines = [
            f"# {title}",
            "",
            f"*{len(techniques)} techniques*",
            "",
            "| Technique | Agent | Reference |",
            "|-----------|-------|-----------|",
        ]
        for tech in techniques:
            name = tech.get("name", Path(tech["path"]).name)
            agent = "✅" if tech.get("has_agent") else "❌"
            ref = "✅" if tech.get("has_reference") else "❌"
            slug = Path(tech["path"]).name
            lines.append(f"| [{name}]({slug}.md) | {agent} | {ref} |")

        (domain_dir / "index.md").write_text("\n".join(lines) + "\n")

    def _write_mkdocs_config(self, output_dir: Path) -> None:
        """Write mkdocs.yml configuration."""
        nav = ["  - Home: index.md"]
        for domain in sorted(self._domains):
            title = domain.replace("-", " ").title()
            nav.append(f"  - {title}:")
            nav.append(f"    - Overview: {domain}/index.md")
            for tech in self._domains[domain]:
                tname = tech.get("name", Path(tech["path"]).name)
                slug = Path(tech["path"]).name
                nav.append(f"    - {tname}: {domain}/{slug}.md")

        config = f"""# CIPHER Documentation Site
# Auto-generated — do not edit manually

site_name: CIPHER Security Skills
site_description: AI-powered cybersecurity skill library
site_url: https://defconxt.github.io/cipher
repo_url: https://github.com/defconxt/cipher
theme:
  name: material
  palette:
    scheme: slate
    primary: red
    accent: amber
nav:
{chr(10).join(nav)}
"""
        (output_dir / "mkdocs.yml").write_text(config)


def generate_docs(
    skills_dir: str = "skills",
    output_dir: str = "site",
    fmt: str = "mkdocs",
) -> dict:
    """Generate documentation. Returns summary stats."""
    gen = DocSiteGenerator(skills_dir=skills_dir, output_dir=output_dir)
    gen.scan_skills()

    if fmt == "mkdocs":
        path = gen.generate_mkdocs()
        return {
            "format": "mkdocs",
            "output": str(path),
            "domains": len(gen._domains),
            "techniques": sum(len(t) for t in gen._domains.values()),
        }
    elif fmt == "single":
        content = gen.generate_single_page()
        out = Path(output_dir) / "SKILLS-REFERENCE.md"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(content)
        return {"format": "single_page", "output": str(out), "size": len(content)}
    elif fmt == "json":
        schema = gen.generate_api_schema()
        out = Path(output_dir) / "skills-api.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(schema, indent=2) + "\n")
        return {
            "format": "json_schema",
            "output": str(out),
            "domains": len(gen._domains),
        }
    else:
        raise ValueError(f"Unknown format: {fmt}")
