<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Engagement Pipeline

CIPHER's engagement pipeline provides a structured methodology for security
engagements with quality gates between each phase.

## Phases

```
┌─────────┐    ┌─────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  SCOPE  │───▶│  RECON  │───▶│  ASSESS  │───▶│ EXPLOIT  │───▶│  REPORT  │
│   G1    │    │   G2    │    │   G3     │    │   G4     │    │   G5     │
└─────────┘    └─────────┘    └──────────┘    └──────────┘    └──────────┘
```

### Gate Decisions
Each gate produces one of 5 decisions:
- **CONTINUE** — proceed to next phase
- **PIVOT** — change approach within current phase
- **PAUSE** — stop for additional information or authorization
- **ESCALATE** — require senior/client approval
- **ABORT** — stop engagement (scope violation, critical risk)

## Templates

| Template | Path | Purpose |
|----------|------|---------|
| Rules of Engagement | `pipeline/templates/rules-of-engagement.md` | Scope, authorization, communications |
| Engagement Report | `pipeline/templates/engagement-report.md` | Executive + technical findings |
| IR Runbook | `pipeline/templates/ir-runbook.md` | Incident response procedure |
| Threat Model | `pipeline/templates/threat-model.md` | STRIDE/DREAD with diagrams |

## Engagement Types

1. **Penetration Test** — scope → recon → assess → exploit → report
2. **Red Team Operation** — full adversary simulation
3. **Vulnerability Assessment** — no exploitation, assessment only
4. **Architecture Review** — threat modeling, design analysis
5. **Incident Response** — triage → contain → eradicate → recover
6. **Threat Model** — DFD → STRIDE → DREAD → mitigations

See [pipeline/PIPELINE.md](../pipeline/PIPELINE.md) for full specification.
