<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# MCP Server

CIPHER exposes its memory engine via the [Model Context Protocol](https://modelcontextprotocol.io),
allowing any MCP-compatible agent to store and retrieve security knowledge.

## Setup

Add to your Claude Code / Cursor / etc. MCP configuration:

```json
{
  "mcpServers": {
    "cipher-memory": {
      "command": "python3",
      "args": ["/path/to/cipher/mcp/server.py"],
      "env": {
        "CIPHER_MEMORY_DIR": "~/.cipher/memory"
      }
    }
  }
}
```

## Available Tools

| Tool | Description |
|------|-------------|
| `cipher_store` | Store a finding, IOC, TTP, or note |
| `cipher_search` | Hybrid search across all memory layers |
| `cipher_context` | Get full engagement context |
| `cipher_consolidate` | Run decay + merge + archive cycle |
| `cipher_stats` | Memory statistics |

## Example Usage

Once configured, any agent can use the tools:

```
Store this finding: SQL injection in /api/users via the 'id' parameter.
Tag it as critical with MITRE T1190 and CVE-2026-1234.
```

The agent calls `cipher_store` with the appropriate parameters, and the finding
persists across sessions.
