<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Cross-Session Memory

CIPHER's memory engine persists knowledge across engagements using a tri-layer
architecture with Reciprocal Rank Fusion.

## Architecture

```
┌─────────────────────────────────────────────────┐
│              CipherMemory                       │
│                                                 │
│  ┌─────────────┐ ┌──────────┐ ┌──────────────┐ │
│  │  Symbolic   │ │  Lexical │ │   Semantic   │ │
│  │  (SQLite)   │ │  (FTS5)  │ │  (LanceDB)  │ │
│  └──────┬──────┘ └────┬─────┘ └──────┬───────┘ │
│         │             │              │          │
│         └─────────────┼──────────────┘          │
│                       │                         │
│              Reciprocal Rank Fusion              │
│         RRF(d) = Σ 1/(k + rank_i(d))           │
└─────────────────────────────────────────────────┘
```

## Memory Types

| Type | Use Case | Examples |
|------|----------|---------|
| `finding` | Vulnerability findings | SQL injection in /api/users |
| `ioc` | Indicators of Compromise | Malicious IP, domain, hash |
| `ttp` | Tactics, Techniques, Procedures | MITRE ATT&CK mappings |
| `credential` | Discovered credentials | Hashed passwords, API keys |
| `host` | Host information | OS, services, open ports |
| `network` | Network topology | Subnets, routes, firewall rules |
| `config` | Configuration findings | Misconfigurations, weak settings |
| `note` | General observations | Analyst notes, hypotheses |
| `decision` | Decision records | Why a path was chosen |
| `artifact` | File artifacts | Screenshots, pcaps, logs |

## Usage

```python
from memory.core.engine import CipherMemory, MemoryEntry

memory = CipherMemory()

# Store a finding
entry = MemoryEntry(
    content="SQL injection in /api/users endpoint via 'id' parameter",
    memory_type="finding",
    tags=["sqli", "api", "critical"],
    confidence=0.95,
    engagement_id="pentest-2026-001",
    mitre_attack_ids=["T1190"],
    cve_ids=["CVE-2026-1234"],
)
memory.store(entry)

# Search
results = memory.search("SQL injection", memory_type="finding", limit=5)

# Get engagement context
context = memory.get_engagement_context("pentest-2026-001")

# Consolidate (decay + merge + archive)
from memory.core.engine import MemoryConsolidator
consolidator = MemoryConsolidator(memory)
stats = consolidator.full_consolidation()
```

## MCP Integration

Add to your MCP config to expose memory to any agent:

```json
{
  "mcpServers": {
    "cipher-memory": {
      "command": "python3",
      "args": ["/path/to/cipher/mcp/server.py"]
    }
  }
}
```

## Storage

Default: `~/.cipher/memory/` (configurable via `CIPHER_MEMORY_DIR`).
