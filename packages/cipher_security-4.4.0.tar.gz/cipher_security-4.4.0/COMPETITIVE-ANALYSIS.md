<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Competitive Analysis v3.0

*Updated March 2026 — post v4.1.0 platform completion*

## Methodology

We studied 25 open-source repositories to learn architectural patterns, identify best practices, and understand the competitive landscape. All implementations in CIPHER are original designs informed by these learnings. Every referenced project is open-source and was studied under their respective licenses.

---

## Repositories Studied

### Security-Specific

| Repository | Focus | What We Learned |
|-----------|-------|----------------|
| **Anthropic-Cybersecurity-Skills** | 734 AgentSkills-format security skills | Skill structure standard, granularity level, agent.py pattern |
| **nuclei** / **nuclei-templates** | Vulnerability scanner + 13K templates | Template-driven scanning, JSONL output parsing, severity taxonomy |
| **katana** | Web crawler | Attack surface discovery, crawl→scan pipeline pattern |
| **pwntools** (5 repos) | Binary exploitation framework | Exploit development patterns, CTF methodology, modular tool design |
| **Bellingcat toolkit** | OSINT investigation tools | Investigation methodology, tool cataloging approach |

### Agent Architecture

| Repository | Focus | What We Learned |
|-----------|-------|----------------|
| **Agentic Context Engine (ACE)** | Self-improving agent framework | Skillbook pattern (living strategy docs), deduplication via embeddings, feedback scoring (helpful/harmful/neutral), offline vs online adaptation loops |
| **OpenCode** | Open-source AI coding agent | TypeScript TUI architecture, MCP integration patterns, plugin system design, session management, multi-provider support |
| **MetaClaw** | RL-driven agent evolution | Idle-aware scheduling, skill evolution via rollouts, gap detection from MITRE mappings |
| **SimpleMem** | Cross-session memory for agents | Tri-stage memory pipeline (symbolic→lexical→semantic), Reciprocal Rank Fusion, memory decay patterns |
| **AutoResearchClaw** | Autonomous research agent | Hypothesis-driven research loops, parallel task execution, research → validation lifecycle |
| **NemoClaw** | Agent skill framework | Skill packaging format, domain/subdomain taxonomy, reference file patterns |
| **AgentSkills** | Skill specification standard | YAML frontmatter schema, folder structure convention, agent.py contract |

### Tool & Workflow Patterns

| Repository | Focus | What We Learned |
|-----------|-------|----------------|
| **OpenShell** | Shell-based agent tools | Command execution patterns, output parsing, error handling |
| **Superpowers** | Development workflow skills | Workflow chain patterns, slash command design |
| **GStack** | Developer tool stack | Configuration management patterns, multi-tool orchestration |
| **nanochat** | Minimal chat implementation | Lightweight LLM client patterns, streaming response handling |
| **agent-browser** | Headless browser automation | Browser automation CLI design |
| **playwright-cli** | Playwright automation | CLI-driven browser testing patterns |

---

## What We Built vs What Existed

### Skill Library

| Metric | Anthropic-CyberSec | CIPHER v4.1 | Delta |
|--------|-------------------|-------------|-------|
| Total skills/techniques | 734 | **1,500** | **+104%** |
| Security domains | ~20 | **64** | **+220%** |
| Agent scripts | 734 | **1,454** | +98% |
| Reference docs | ~700 | **1,500** | +114% |
| Tests | 0 | **10,317** | ∞ |
| Compliance frameworks | 0 | **7** | +7 |

**Key learning:** Anthropic's 734 skills demonstrated that granularity wins — each skill should be a single technique, not a broad domain. We applied this by decomposing 38 original broad skills into 1,500 granular techniques across 64 domains.

### Memory Architecture

| Capability | SimpleMem | ACE Skillbook | CIPHER |
|-----------|-----------|---------------|--------|
| Storage backend | SQLite + FTS5 | JSON/YAML files | SQLite + FTS5 |
| Vector search | LanceDB | Sentence transformers | Optional (ChromaDB) |
| Fusion strategy | RRF | N/A | RRF (3-way) |
| Deduplication | Basic | Cosine similarity + LLM | Jaccard trigram |
| Memory types | Generic | Helpful/Harmful/Neutral | 10 security-specific types |
| Engagement scoping | No | No | **Yes** — per-engagement isolation |
| Consolidation | Manual | LLM-driven | **Automated** — decay, merge, archive |
| Token budget | No | Yes | **Yes** — compressor stage |

**Key learning from SimpleMem:** The tri-stage pipeline (symbolic → lexical → semantic) with RRF fusion. We adopted the architecture and specialized it for cybersecurity with security-specific memory types (finding, IOC, TTP, credential, host, network, config, note, decision, artifact) and per-engagement isolation.

**Key learning from ACE:** The Skillbook concept of tagging knowledge as helpful/harmful/neutral. We incorporated this into our ResponseScorer (PRM evaluation) and feedback loop, where skill effectiveness is tracked and poor performers trigger regeneration.

### Autonomous Operation

| Capability | MetaClaw | ACE | AutoResearchClaw | CIPHER |
|-----------|----------|-----|-------------------|--------|
| Idle-aware scheduling | ✅ | No | No | **✅** |
| Gap detection | MITRE mapping | Task-based | No | **MITRE + quality** |
| Skill generation | Via rollouts | Via reflection | Via hypothesis | **Via researcher** |
| Parallel execution | No | Async learning | Yes | **Thread pool + queue** |
| Effectiveness tracking | Basic | Helpful/Harmful | No | **SQLite leaderboard** |
| Feedback loop | No | Online adaptation | No | **Leaderboard → researcher** |
| Trend detection | No | No | No | **Linear regression** |

**Key learning from MetaClaw:** The idle-aware scheduler pattern (`SlowUpdateScheduler` → `IdleDetector` + sleep window gating). We adopted the state machine approach (IDLE_WAIT → WINDOW_OPEN → RUNNING → PAUSING) with platform-specific idle detection (macOS `ioreg`, Linux `xprintidle`, fallback request tracking).

**Key learning from ACE:** The adaptation loop pattern — offline learning from batched experiences vs online learning from each interaction. We implemented both: the leaderboard tracks per-invocation scores (online), and the feedback loop runs batch improvement cycles (offline).

**Key learning from AutoResearchClaw:** The hypothesis → validation → application research lifecycle. Our AutonomousResearcher follows this pattern: analyze coverage → identify gaps → generate skill hypothesis → validate against quality criteria → produce complete skill package.

### Agent Platform Features

| Feature | OpenCode | ACE | Superpowers | CIPHER |
|---------|----------|-----|-------------|--------|
| MCP server | ✅ (consumer) | ✅ (integration) | No | **✅ (14 tools + stdio)** |
| REST API | No | No | No | **15 endpoints** |
| CLI | ✅ | ✅ | No | **13 commands** |
| Compliance | No | No | No | **7 frameworks** |
| Marketplace | No | No | No | **SQLite + tar.gz** |
| Multi-provider | ✅ | ✅ (via LiteLLM) | No | **✅** (Ollama/Claude/LiteLLM) |
| Plugin system | ✅ | No | ✅ | **✅** |
| SSO/Auth | Enterprise tier | No | No | **SAML + OIDC** |
| Billing/Metering | Enterprise tier | SaaS | No | **Usage-based engine** |

**Key learning from OpenCode:** MCP integration patterns — both as server (exposing tools) and consumer (using external MCP servers). Session management and provider abstraction patterns. Their TypeScript TUI architecture informed our Textual dashboard approach.

**Key learning from Superpowers:** Workflow chain design — how to compose multiple skills into multi-step pipelines. Our engagement pipeline (Scope → Recon → Assess → Exploit → Report) and WORKFLOW-CHAINS.md draw from this pattern.

### Scanning & Detection

| Capability | nuclei | nuclei-templates | CIPHER |
|-----------|--------|------------------|--------|
| Scan execution | Binary (Go) | 13K YAML templates | **NucleiRunner wrapper** |
| Async support | Native | N/A | **AsyncNucleiRunner** |
| Crawling | Via katana | N/A | **KatanaRunner wrapper** |
| Diff analysis | No | No | **SecurityDiffAnalyzer** |
| Secret detection | No | Some templates | **Regex engine (4 patterns)** |
| CI/CD integration | GitHub Action | GitHub Action | **WorkflowGenerator** |
| SARIF output | Yes | N/A | **Via pipeline** |

**Key learning from nuclei:** JSONL output parsing for structured findings, severity taxonomy (info → critical), template-driven scanning model. We wrap nuclei as a subprocess rather than reimplementing — the right architectural choice.

---

## Unique to CIPHER (Not Found in Any Studied Repo)

1. **Security-specialized memory** — 10 memory types with engagement scoping, severity tracking, MITRE TTP tagging
2. **Compliance automation** — 7 frameworks with 119+ real control IDs, gap analysis, remediation guidance
3. **7 auto-detecting security modes** — RED/BLUE/PURPLE/PRIVACY/RECON/INCIDENT/ARCHITECT with cross-mode enrichment
4. **Engagement pipeline** — 5-stage gated methodology with 37 machine-readable quality checks
5. **Security diff analysis** — detects auth changes, SQL modifications, crypto updates, secret leaks in git diffs
6. **Framework mappings** — MITRE ATT&CK, NIST CSF 2.0, OWASP (Web/API/LLM/Mobile), IEC 62443
7. **Skill marketplace** — publish/install/rate/export security skill packages
8. **Documentation generator** — auto-generates mkdocs sites, single-page references, and JSON API schemas from skill tree
9. **64 security domains at uniform depth** — every domain has exactly 24 granular techniques

---

## Architecture Comparison

### Anthropic-Cybersecurity-Skills
```
734 SKILL.md files → agent.py scripts → flat structure
No memory. No evolution. No API. No tests. Knowledge only.
```

### ACE (Agentic Context Engine)
```
Skillbook (JSON/YAML) → Reflection → Deduplication → Adaptation
LLM-dependent learning. General-purpose. SaaS-focused.
```

### MetaClaw
```
SkillManager → Rollout → Evolution → Scheduler
RL-driven. Research-focused. No security specialization.
```

### CIPHER v4.1
```
┌─ Skills (1,500) ─── Knowledge (96 docs) ─── Framework Mappings ──────┐
│                                                                        │
├─ Memory Engine ──── Compressor → Synthesizer → Retriever + Evolution  │
├─ Pipeline ───────── Scanner (Nuclei/Katana) + DiffAnalyzer + Secrets  │
├─ Autonomous ─────── Scheduler + Researcher + Parallel + Leaderboard   │
│                     + Feedback Loop                                    │
├─ API ────────────── REST (15 endpoints) + MCP (14 tools) + CLI (13)   │
├─ Commercial ─────── Marketplace + Compliance (7) + SSO + Billing      │
└─ Infra ──────────── Docker + CI/CD + Evals + Doc Generator           │
```

---

## Gap Analysis: What We Could Still Learn

| Source | Capability | Status |
|--------|-----------|--------|
| ACE | Embedding-based deduplication for memory entries | Could adopt for memory consolidation |
| ACE | Online adaptation with per-task environment scoring | Could enhance feedback loop |
| OpenCode | LSP integration for code-aware security scanning | Future enhancement |
| OpenCode | Worktree-based isolation for parallel tasks | Could adopt for parallel scanning |
| nuclei-templates | Maintain our own security template library | Future enhancement |
| Bellingcat toolkit | Structured OSINT investigation workflows | Could expand RECON mode |

---

## Summary

CIPHER is the most comprehensive AI-powered cybersecurity platform in the open-source space. Every architectural pattern we adopted was studied from open-source projects, understood in depth, and then reimplemented as original code specialized for cybersecurity. We did not copy code — we learned patterns and built our own implementations.

| Dimension | Best Alternative | CIPHER | Lead |
|-----------|-----------------|--------|------|
| Security skills | Anthropic (734) | **1,500** | +104% |
| Domains | Anthropic (~20) | **64** | +220% |
| Test coverage | None (0 tests across all repos) | **10,317** | ∞ |
| Memory architecture | SimpleMem (general) | **Security-specialized tri-stage** | Unique |
| Autonomous evolution | MetaClaw (RL-based) | **Leaderboard + feedback loop** | More practical |
| Self-improvement | ACE (Skillbook) | **Quality analyzer + regeneration** | More targeted |
| Compliance | None | **7 frameworks, 119+ controls** | Unique |
| Platform completeness | OpenCode (coding agent) | **Full security platform** | Different category |
