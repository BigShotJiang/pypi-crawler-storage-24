<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 4.x     | ✅ Active  |
| < 4.0   | ❌ EOL     |

## Reporting a Vulnerability

CIPHER is a security engineering platform — we take vulnerabilities in our own code
extremely seriously.

### How to Report

**Email:** security@blacktemple.net

**PGP Key:** Available at https://blacktemple.net/.well-known/security.txt

**Please include:**
- Description of the vulnerability
- Steps to reproduce
- Affected versions
- Potential impact assessment
- Suggested fix (if any)

### What to Expect

| Timeline | Action |
|----------|--------|
| 24 hours | Acknowledgment of your report |
| 72 hours | Initial triage and severity assessment |
| 7 days   | Fix developed and tested |
| 14 days  | Patch released with advisory |

### Scope

**In scope:**
- All Python source code in `src/`, `api/`, `mcp/`, `memory/`, `pipeline/`, `autonomous/`
- Configuration handling (`config.py`, `config.yaml`)
- API server endpoints and authentication
- MCP server protocol handling
- Memory engine SQL queries
- SSRF protection in scan pipeline
- Docker container security
- Dependency vulnerabilities

**Out of scope:**
- Third-party tools (Nuclei, Katana, Ollama) — report to their respective projects
- Skill content accuracy (security technique descriptions)
- Denial of service via expected large inputs

### Recognition

We maintain a `CONTRIBUTORS.md` and will credit security researchers who report
valid vulnerabilities (with your permission).

### Disclosure Policy

- We follow coordinated disclosure with a 90-day timeline
- We will not pursue legal action against researchers acting in good faith
- We ask that you do not publicly disclose until a fix is available

## Security Design Principles

CIPHER follows these security principles in all code:

1. **No eval/exec** — no dynamic code execution
2. **No shell=True** — all subprocess calls use list-form arguments
3. **No pickle** — no unsafe deserialization
4. **Parameterized SQL** — all database queries use `?` placeholders
5. **SSRF protection** — scan targets validated against RFC 1918, loopback, metadata
6. **No traceback leakage** — API errors return generic messages
7. **Secret redaction** — API keys masked in all output paths
8. **Least privilege** — Docker runs as non-root user
9. **Input validation** — all CLI and API inputs sanitized
10. **Dependency minimalism** — 4 core dependencies, everything else optional
