<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# MITRE ATT&CK Coverage Summary v3.0

Coverage analysis of 1,500 CIPHER techniques across 64 domains mapped to MITRE ATT&CK Enterprise v15.

Source: https://attack.mitre.org/

## Coverage by Tactic

| ATT&CK Tactic | ID | Primary CIPHER Domains | Depth |
|---------------|-----|----------------------|-------|
| Reconnaissance | TA0043 | osint-recon, threat-intelligence, social-engineering, bug-bounty | ██████████ Very High |
| Resource Development | TA0042 | threat-intelligence, phishing-defense, c2-frameworks, exploit-development | ██████████ High |
| Initial Access | TA0001 | red-team, api-security, browser-security, phishing-defense, cloud-security, wireless-security, social-engineering | ██████████ Very High |
| Execution | TA0002 | red-team, adversary-simulation, binary-exploitation, automation-scripting, malware-analysis, container-security | ██████████ Very High |
| Persistence | TA0003 | active-directory-security, c2-frameworks, ransomware-defense, container-security, endpoint-security | ██████████ Very High |
| Privilege Escalation | TA0004 | active-directory-security, identity-security, cloud-security, container-security, binary-exploitation | ██████████ Very High |
| Defense Evasion | TA0005 | adversary-simulation, malware-analysis, reverse-engineering, endpoint-security | ██████████ High |
| Credential Access | TA0006 | active-directory-security, identity-access-management, password-cracking, phishing-defense | ██████████ Very High |
| Discovery | TA0007 | osint-recon, network-security, cloud-security, log-analysis | ██████████ High |
| Lateral Movement | TA0008 | active-directory-security, network-security, zero-trust, soc-operations | ██████████ Very High |
| Collection | TA0009 | digital-forensics, investigation-attribution, data-security, privacy-engineering | ██████████ High |
| Command & Control | TA0011 | c2-frameworks, network-security, detection-engineering, endpoint-security | ██████████ Very High |
| Exfiltration | TA0010 | data-security, network-security, cloud-forensics, log-analysis | ████████░░ High |
| Impact | TA0040 | ransomware-defense, incident-response, incident-management, cloud-forensics | ██████████ Very High |

## MITRE D3FEND Alignment

| D3FEND Category | CIPHER Domains |
|----------------|---------------|
| Harden | security-architecture, zero-trust, secure-coding, devsecops |
| Detect | detection-engineering, blue-team, soc-operations, log-analysis |
| Isolate | container-security, network-security, zero-trust |
| Deceive | adversary-simulation, purple-team |
| Evict | incident-response, incident-management, endpoint-security |

## Technique Coverage

With 1,500 granular techniques across 64 domains, CIPHER provides coverage for approximately:
- **200+ ATT&CK techniques** (of ~450 Enterprise techniques)
- **All 14 tactics** with at least High coverage
- **45% direct technique mapping** with supporting context for remaining techniques

## Attack Navigator Layer

See `attack-navigator-layer.json` for importable ATT&CK Navigator heatmap.
