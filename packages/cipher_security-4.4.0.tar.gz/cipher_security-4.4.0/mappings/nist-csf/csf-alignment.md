<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# NIST Cybersecurity Framework 2.0 Alignment

Mapping of 33 CIPHER skills to NIST CSF 2.0 functions, categories, and subcategories.

## Function Coverage

| Function | Categories | Primary Skills | Coverage |
|----------|-----------|---------------|----------|
| **GOVERN (GV)** | GV.OC, GV.RM, GV.SC, GV.PO, GV.RR | compliance-audit, security-architecture | ████████░░ |
| **IDENTIFY (ID)** | ID.AM, ID.RA, ID.IM | osint-recon, vulnerability-management, threat-intelligence, supply-chain-security | ██████████ |
| **PROTECT (PR)** | PR.AA, PR.AT, PR.DS, PR.PS, PR.IR | IAM, cryptography, data-security, devsecops, phishing-defense, network-security | ██████████ |
| **DETECT (DE)** | DE.CM, DE.AE | blue-team, soc-operations, container-security, network-security | ██████████ |
| **RESPOND (RS)** | RS.MA, RS.AN, RS.CO, RS.MI | incident-response, digital-forensics, ransomware-defense | ██████████ |
| **RECOVER (RC)** | RC.RP, RC.CO | ransomware-defense, incident-response | ████████░░ |

## Detailed Mapping

### GOVERN
| Subcategory | CIPHER Skill | Control |
|-------------|-------------|---------|
| GV.OC-01 | compliance-audit | Organizational context understood |
| GV.RM-01 | security-architecture | Risk management objectives established |
| GV.SC-01 | supply-chain-security | Supply chain risk management program |
| GV.PO-01 | compliance-audit | Security policy established |

### IDENTIFY
| Subcategory | CIPHER Skill | Control |
|-------------|-------------|---------|
| ID.AM-01 | osint-recon, cloud-security | Asset inventories maintained |
| ID.AM-02 | container-security, cloud-security | Software inventories maintained |
| ID.RA-01 | vulnerability-management | Vulnerabilities identified |
| ID.RA-02 | threat-intelligence | Threat intelligence received |
| ID.RA-03 | threat-intelligence | Threats identified and documented |
| ID.RA-05 | vulnerability-management | Risks prioritized |
| ID.IM-01 | compliance-audit | Improvements identified |

### PROTECT
| Subcategory | CIPHER Skill | Control |
|-------------|-------------|---------|
| PR.AA-01 | IAM | Identities and credentials managed |
| PR.AA-03 | IAM | MFA and authentication managed |
| PR.AA-05 | IAM, cloud-security | Access permissions managed |
| PR.AT-01 | phishing-defense | Awareness and training provided |
| PR.DS-01 | cryptography, data-security | Data-at-rest protected |
| PR.DS-02 | cryptography, network-security | Data-in-transit protected |
| PR.DS-10 | data-security | Data-in-use protected |
| PR.PS-01 | devsecops, automation-scripting | Configuration management applied |
| PR.PS-02 | devsecops | Software maintained and updated |
| PR.IR-01 | network-security, container-security | Networks and environments protected |

### DETECT
| Subcategory | CIPHER Skill | Control |
|-------------|-------------|---------|
| DE.CM-01 | blue-team, soc-operations, network-security | Networks monitored |
| DE.CM-02 | blue-team, container-security | Physical environment monitored |
| DE.CM-03 | blue-team, soc-operations | Personnel activity monitored |
| DE.CM-06 | network-security | External service provider activity monitored |
| DE.CM-09 | malware-analysis | Computing hardware and software monitored |
| DE.AE-02 | soc-operations, blue-team | Anomalous activity analyzed |
| DE.AE-06 | soc-operations | Information correlated from multiple sources |
| DE.AE-08 | soc-operations, blue-team | Incidents declared when criteria met |

### RESPOND
| Subcategory | CIPHER Skill | Control |
|-------------|-------------|---------|
| RS.MA-01 | incident-response | Incident management plan executed |
| RS.MA-03 | incident-response, ransomware-defense | Incidents categorized and prioritized |
| RS.AN-03 | digital-forensics | Forensics performed |
| RS.AN-06 | incident-response | Investigation actions recorded |
| RS.AN-07 | digital-forensics | Incident data and metadata collected |
| RS.CO-02 | incident-response | Internal stakeholders notified |
| RS.MI-01 | incident-response, ransomware-defense | Incidents contained |
| RS.MI-02 | incident-response | Incidents eradicated |

### RECOVER
| Subcategory | CIPHER Skill | Control |
|-------------|-------------|---------|
| RC.RP-01 | ransomware-defense | Recovery plan executed |
| RC.RP-03 | ransomware-defense | Backup integrity verified |
| RC.RP-04 | incident-response | Critical functions restored |
| RC.CO-03 | incident-response | Recovery activities communicated |
