<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# OWASP Framework Alignment

Mapping of CIPHER skills to OWASP Top 10 (2021), OWASP API Security Top 10 (2023),
OWASP LLM Top 10 (2025), and OWASP Mobile Top 10 (MASVS v2).

## OWASP Top 10 (2021) — Web Applications

| # | Category | CIPHER Skill | Coverage |
|---|----------|-------------|----------|
| A01:2021 | Broken Access Control | web, api-security | ██████████ High — BOLA/IDOR, privilege escalation |
| A02:2021 | Cryptographic Failures | cryptography | ██████████ High — Algorithm selection, TLS, key management |
| A03:2021 | Injection | web | ██████████ High — SQLi, XSS, SSTI, command injection |
| A04:2021 | Insecure Design | security-architecture | ████████░░ Moderate — Threat modeling, design reviews |
| A05:2021 | Security Misconfiguration | cloud-security, devsecops | ██████████ High — CSPM, IaC scanning |
| A06:2021 | Vulnerable Components | supply-chain-security, devsecops | ██████████ High — SCA, SBOM, dependency audit |
| A07:2021 | Identification & Auth Failures | IAM | ██████████ High — MFA, SSO, session management |
| A08:2021 | Software & Data Integrity | supply-chain-security, devsecops | ██████████ High — SLSA, code signing, CI/CD |
| A09:2021 | Security Logging & Monitoring | soc-operations, blue-team | ██████████ High — SIEM, detection engineering |
| A10:2021 | Server-Side Request Forgery | web, api-security, cloud-attacks | ██████████ High — SSRF to metadata, cloud pivot |

## OWASP API Security Top 10 (2023)

| # | Category | CIPHER Skill | Coverage |
|---|----------|-------------|----------|
| API1 | Broken Object Level Authorization | api-security | ██████████ High — BOLA/IDOR testing methodology |
| API2 | Broken Authentication | api-security, IAM | ██████████ High — JWT, OAuth2, token attacks |
| API3 | Broken Object Property Level Auth | api-security | ██████████ High — Mass assignment, excessive data |
| API4 | Unrestricted Resource Consumption | api-security | ████████░░ Moderate — Rate limiting tests |
| API5 | Broken Function Level Authorization | api-security | ██████████ High — Privilege escalation testing |
| API6 | Unrestricted Access to Sensitive Flows | api-security | ████████░░ Moderate |
| API7 | Server Side Request Forgery | api-security, web | ██████████ High |
| API8 | Security Misconfiguration | api-security | ████████░░ Moderate — CORS, verbose errors |
| API9 | Improper Inventory Management | api-security | ██████████ High — API discovery, shadow APIs |
| API10 | Unsafe Consumption of APIs | api-security | ████████░░ Moderate |

## OWASP LLM Top 10 (2025)

| # | Category | CIPHER Skill | Coverage |
|---|----------|-------------|----------|
| LLM01 | Prompt Injection | ai-llm-security | ██████████ High — Direct, indirect, RAG poisoning |
| LLM02 | Insecure Output Handling | ai-llm-security | ██████████ High — Sanitization, rendering |
| LLM03 | Training Data Poisoning | ai-llm-security | ████████░░ Moderate — Pipeline integrity |
| LLM04 | Model Denial of Service | ai-llm-security | ████████░░ Moderate — Token exhaustion |
| LLM05 | Supply Chain Vulnerabilities | ai-llm-security, supply-chain | ██████████ High |
| LLM06 | Sensitive Information Disclosure | ai-llm-security | ██████████ High — PII leakage, extraction |
| LLM07 | Insecure Plugin Design | ai-llm-security | ████████░░ Moderate — Plugin validation |
| LLM08 | Excessive Agency | ai-llm-security | ██████████ High — Agent tool permissions, gates |
| LLM09 | Overreliance | ai-llm-security | ████████░░ Moderate — Hallucination handling |
| LLM10 | Model Theft | ai-llm-security | ████████░░ Moderate — Access controls |

## OWASP MASVS v2 (Mobile)

| Category | CIPHER Skill | Coverage |
|----------|-------------|----------|
| MASVS-STORAGE | mobile-security | ██████████ High — SharedPrefs, Keychain, data at rest |
| MASVS-CRYPTO | mobile-security, cryptography | ██████████ High — Key management, algorithm selection |
| MASVS-AUTH | mobile-security, IAM | ████████░░ Moderate — Biometric, session management |
| MASVS-NETWORK | mobile-security | ██████████ High — Certificate pinning, TLS |
| MASVS-PLATFORM | mobile-security | ████████░░ Moderate — IPC, URL schemes |
| MASVS-CODE | mobile-security | ████████░░ Moderate — Obfuscation, anti-tamper |
| MASVS-RESILIENCE | mobile-security | ████████░░ Moderate — Root/jailbreak detection |
