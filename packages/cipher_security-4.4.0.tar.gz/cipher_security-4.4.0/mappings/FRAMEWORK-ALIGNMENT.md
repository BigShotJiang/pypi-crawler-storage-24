<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Framework Alignment

**36 compliance frameworks | 1,111+ control IDs | Automated assessment engine**

## NIST Family (392 controls)

| Framework | Controls | Automated | Notes |
|-----------|----------|-----------|-------|
| NIST 800-53 Rev 5 | 297 | ✅ | Full catalog — all 20 control families (AC, AT, AU, CA, CM, CP, IA, IR, MA, MP, PE, PL, PM, PS, PT, RA, SA, SC, SI, SR) |
| NIST CSF 2.0 | 27 | ✅ | All 6 functions: Govern, Identify, Protect, Detect, Respond, Recover |
| NIST AI RMF | 18 | ✅ | Govern, Map, Measure, Manage — AI-specific risk governance |
| NIST 800-171 Rev 2 | 37 | ✅ | CUI protection for non-federal systems — 14 requirement families |
| NIST 800-82 Rev 3 | 13 | ✅ | ICS/SCADA security — network segmentation, monitoring, access control |

## ISO Family (130 controls)

| Framework | Controls | Automated | Notes |
|-----------|----------|-----------|-------|
| ISO 27001:2022 | 93 | ✅ | Full Annex A: A.5 Organizational (37) + A.6 People (8) + A.7 Physical (14) + A.8 Technological (34) |
| ISO 27017 | 12 | ✅ | Cloud-specific extensions — virtual machine hardening, segregation, cloud monitoring |
| ISO 27018 | 11 | ✅ | PII protection in public cloud — consent, minimization, transparency |
| ISO 27701 | 14 | ✅ | Privacy Information Management System — controller/processor obligations, DPIA, DPO |

## Regulatory & Legal (170 controls)

| Framework | Controls | Automated | Notes |
|-----------|----------|-----------|-------|
| SOC 2 Type II | 21 | ✅ | Trust Services Criteria CC1–CC9 + A1 (Availability) |
| PCI DSS 4.0 | 16 | ✅ | All 12 requirement groups — payment card industry |
| HIPAA Security Rule | 16 | ✅ | Administrative, Physical, Technical safeguards (§164.308–312) |
| GDPR | 13 | ✅ | Art. 5–37 — processing principles, rights, DPIA, DPO, breach notification |
| CMMC 2.0 | 24 | ✅ | DoD contractor CUI/FCI protection — Levels 1–3 |
| FedRAMP | 20 | ✅ | Federal cloud — NIST 800-53 enhanced baselines |
| NIS2 | 12 | ✅ | EU critical infrastructure — Art. 21 (risk measures) + Art. 23 (incident reporting) |
| DORA | 14 | ✅ | EU financial sector digital resilience — Art. 5–28 |
| EU AI Act | 19 | ✅ | High-risk AI systems — Art. 6–72, risk management, transparency, conformity |
| SOX IT Controls | 12 | ✅ | ITGC (access, change, development, operations) + application controls |

## Industry-Specific (133 controls)

| Framework | Controls | Automated | Notes |
|-----------|----------|-----------|-------|
| SWIFT CSP | 27 | ✅ | Customer Security Programme — environment protection, access, malware, incident response |
| NERC CIP | 13 | ✅ | Bulk Electric System — CIP-002 through CIP-014 |
| IEC 62443 | 18 | ✅ | OT/ICS industrial automation — SR-1 through SR-7 |
| HITRUST CSF | 24 | ✅ | Healthcare — cross-references HIPAA, NIST, ISO, PCI, COBIT |
| CIS Controls v8 | 18 | ✅ | All 18 control groups (IG1/IG2/IG3 implementation levels) |
| CSA CCM v4 | 29 | ✅ | Cloud Security Alliance Cloud Controls Matrix — 16 domains |
| CIS Cloud Benchmarks | 22 | ✅ | AWS (5) + Azure (6) + GCP (6) + Kubernetes (5) |

## Threat, Vulnerability & Testing (141 controls)

| Framework | Controls | Automated | Notes |
|-----------|----------|-----------|-------|
| MITRE ATT&CK Enterprise v15 | 14 | ✅ | All 14 tactics (TA0001–TA0043) — mapped across 64 CIPHER domains |
| OWASP Top 10 Web (2021) | 10 | ✅ | A01–A10 (Broken Access Control through SSRF) |
| OWASP API Security (2023) | 10 | ✅ | API1–API10 (BOLA through Unsafe Consumption) |
| OWASP LLM Top 10 (2025) | 10 | ✅ | LLM01–LLM10 (Prompt Injection through Model Theft) |
| OWASP MASVS v2 | 18 | ✅ | Mobile verification — Storage, Crypto, Auth, Network, Platform, Code, Resilience, Privacy |
| SANS/CWE Top 25 | 25 | ✅ | Most Dangerous Software Weaknesses (CWE-787, CWE-79, CWE-89, etc.) |
| CISA KEV / CPG | 12 | ✅ | Known Exploited Vulnerabilities + Cross-Sector Cybersecurity Performance Goals |
| PTES | 13 | ✅ | Penetration Testing Execution Standard — 7 phases |
| OSSTMM | 10 | ✅ | Open Source Security Testing Methodology Manual — 5 channels + RAV |
| SSDF (SP 800-218) | 19 | ✅ | Secure Software Development Framework — Prepare, Protect, Produce, Respond |

## IT Governance & Management (50 controls)

| Framework | Controls | Automated | Notes |
|-----------|----------|-----------|-------|
| COBIT 2019 | 20 | ✅ | IT Governance — EDM, APO, BAI, DSS, MEA process domains |
| ITIL v4 Security | 15 | ✅ | ISM, Change Enablement, Incident/Problem Management, Continuity |
| MITRE D3FEND | — | Mapped | Defensive technique ontology — Harden, Detect, Isolate, Deceive, Evict |
| Cyber Kill Chain | — | Mapped | Attack phase modeling — Recon through Actions on Objectives |
| STRIDE/DREAD | — | Built-in | Threat model output format — component and flow assessment |

## Cross-Framework Category Coverage

| Category | Frameworks Covering It |
|----------|----------------------|
| Access Control | NIST 800-53, ISO 27001, SOC 2, PCI DSS, CMMC, CIS, SWIFT, HITRUST, CSA CCM, SOX |
| Authentication | NIST 800-53, ISO 27001, OWASP, SWIFT, IEC 62443, MASVS, SANS Top 25 |
| Cryptography | NIST 800-53, ISO 27001, PCI DSS, GDPR, SWIFT, IEC 62443, MASVS, NIST 800-171 |
| Logging & Monitoring | NIST 800-53, ISO 27001, SOC 2, CIS, NIST CSF, SWIFT, CSA CCM, NERC CIP |
| Incident Response | NIST 800-53, ISO 27001, SOC 2, NIS2, DORA, NIST CSF, HITRUST, ITIL |
| Vulnerability Management | NIST 800-53, CIS, CISA KEV, NIST CSF, SANS Top 25, CSA CCM, SSDF |
| Data Protection | GDPR, ISO 27018, ISO 27701, HIPAA, CMMC, NIST 800-171, EU AI Act |
| Code Security | ISO 27001, OWASP, SANS Top 25, SSDF, COBIT, CSA CCM, SOX |
| Network Security | NIST 800-53, CIS, IEC 62443, NERC CIP, SWIFT, NIST 800-82 |
| Governance | NIST CSF, ISO 27001, SOC 2, COBIT, ITIL, GDPR, NIS2, EU AI Act |
| Supply Chain | NIST 800-53 (SR), NIST CSF, CMMC, NIS2, CSA CCM, NERC CIP |
| Physical Security | NIST 800-53 (PE), ISO 27001 (A.7), SWIFT, NERC CIP |
| AI/ML Security | NIST AI RMF, EU AI Act, OWASP LLM Top 10 |
| OT/ICS Security | IEC 62443, NIST 800-82, NERC CIP |
| Privacy | GDPR, ISO 27018, ISO 27701, HIPAA, EU AI Act |
| Cloud Security | ISO 27017, CSA CCM, CIS Cloud, FedRAMP |
| Mobile Security | OWASP MASVS |
| Financial Services | SWIFT CSP, DORA, SOX IT, PCI DSS |
