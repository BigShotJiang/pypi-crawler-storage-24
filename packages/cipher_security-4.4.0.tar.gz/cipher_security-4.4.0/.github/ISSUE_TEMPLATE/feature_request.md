<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: Feature Request
about: Suggest a new feature or improvement
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

**What problem does this solve?**
Describe the use case or pain point.

**Proposed solution**
How you'd like it to work.

**Alternatives considered**
Other approaches you've thought about.

**Additional context**
Screenshots, links, or references.
