<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: Knowledge Doc Request
about: Request a new knowledge base topic or expansion of an existing doc
title: "[KNOWLEDGE] "
labels: knowledge
assignees: ''
---

**Topic**
What security domain or topic should be covered?

**Why it matters**
Who needs this and what use cases does it serve?

**Key areas to cover**
- [ ] Area 1
- [ ] Area 2
- [ ] Area 3

**References**
Links to authoritative sources, tools, or frameworks for this topic.
