<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

---
name: Bug Report
about: Something isn't working correctly
title: "[BUG] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what's broken.

**To reproduce**
```bash
cipher "query that causes the issue"
```

**Expected behavior**
What should happen.

**Actual behavior**
What actually happens (include error output).

**Environment**
- OS: [e.g., Ubuntu 24.04, macOS 15, Windows 11]
- Python: [e.g., 3.12.3]
- CIPHER version: [e.g., 0.2.0]
- Backend: [Ollama / Claude API]
- Install method: [pip / curl / Docker]

**`cipher doctor` output**
```
paste output here
```
