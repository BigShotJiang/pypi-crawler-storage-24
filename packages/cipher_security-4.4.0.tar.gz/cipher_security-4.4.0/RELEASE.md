<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Release Workflow

Iterative release process triggered after significant changes. This is the
human + CI checklist that ensures every distribution channel stays in sync.

## When to Trigger

Run this workflow when ANY of these occur:
- New skills added or existing skills significantly refactored
- New features land (pipeline, memory, evolution, scripts)
- Security fixes or breaking changes
- Framework mapping updates (ATT&CK, NIST CSF, OWASP)
- Engine code changes (memory, evolution)

**Rule of thumb**: if it changes what users get or how they use CIPHER, run the workflow.

---

## Pre-Release Checklist

### 1. Code Quality Gate
- [ ] All tests passing: `python3 -m pytest tests/ -v`
- [ ] No lint errors: `ruff check .`
- [ ] Type checks clean: `pyright` or `mypy`
- [ ] New code has tests (target: ≥80% coverage on changed files)
- [ ] CHANGELOG.md updated with new `## [X.Y.Z] - YYYY-MM-DD` section

### 2. Version Bump
- [ ] Update version in `pyproject.toml` / `setup.cfg`
- [ ] Update version in `vscode/package.json`
- [ ] Update version in `Dockerfile` labels (if applicable)
- [ ] Update `index.json` metadata (`total_skills`, `total_subdomains`)
- [ ] Verify version strings match across all files:
  ```bash
  grep -r "version" pyproject.toml vscode/package.json index.json | grep -E "[0-9]+\.[0-9]+\.[0-9]+"
  ```

---

## Release Channels (Ordered)

### 3. Git Tag → CI Pipeline (Automated)
Pushing a tag triggers `.github/workflows/release.yml` which handles:
- [ ] **PyPI**: `python -m build` → `twine upload` (trusted publishing)
- [ ] **Docker**: `ghcr.io/defconxt/cipher:latest` + `cipher:X.Y.Z`
- [ ] **VS Code VSIX**: packaged and attached to GitHub Release
- [ ] **GitHub Release**: created with changelog excerpt

```bash
git tag -a vX.Y.Z -m "CIPHER vX.Y.Z — <one-line summary>"
git push origin vX.Y.Z
```

**Verify after CI completes:**
- [ ] PyPI: `pip install cipher-security==X.Y.Z` works
- [ ] Docker: `docker pull ghcr.io/defconxt/cipher:X.Y.Z` works
- [ ] VSIX: downloadable from GitHub Release assets
- [ ] GitHub Release: notes render correctly, all assets attached

### 4. VS Code Marketplace (Manual until automated)
- [ ] Download VSIX from GitHub Release
- [ ] Publish: `npx @vscode/vsce publish` (or upload via marketplace dashboard)
- [ ] Verify: search "CIPHER" in VS Code extensions shows new version
- [ ] Update extension README if features changed

### 5. GitHub README
- [ ] Update skill count if changed (currently 36)
- [ ] Update feature list if new capabilities added
- [ ] Update architecture diagram if new components
- [ ] Update badges (version, test count, skill count)
- [ ] Review "Quick Start" section — still accurate?
- [ ] Update screenshots/GIFs if UI changed

### 6. Website — blacktemple.net/cipher
- [ ] Update hero section version number
- [ ] Update feature grid with new capabilities
- [ ] Update skill/domain count metrics
- [ ] Add blog post / changelog entry for significant releases
- [ ] Update documentation pages if CLI/API changed
- [ ] Test all download links point to latest version
- [ ] Verify SEO meta tags reflect current description

### 7. Documentation
- [ ] Update docs/ if CLI commands changed
- [ ] Update API docs if gateway interface changed
- [ ] Update skill catalog page with new skills
- [ ] Update framework mapping pages if coverage changed
- [ ] Cross-reference CHANGELOG → docs for breaking changes

---

## Cross-Project Sync — blacktemple.net

The website at `blacktemple.net/cipher` is a separate Next.js project at
`~/Documents/blacktemple.net/` with its own GSD/Claude Code session.

### How the two projects connect:
- `cipher/knowledge/` → copied to `blacktemple.net/data/cipher/` via `npm run prebuild`
- `cipher/RELEASE-STATE.json` → machine-readable metrics the site can consume
- `blacktemple.net/data/cipher-nav.ts` → navigation tree (manual update if new categories)
- `blacktemple.net/components/cipher/` → 10 React components rendering cipher content

### Sync workflow after a CIPHER release:
- [ ] Update `RELEASE-STATE.json` with current version + metrics
- [ ] If `knowledge/` files changed: rebuild will auto-copy via prebuild
- [ ] If new skill categories added: update `cipher-nav.ts` in blacktemple.net
- [ ] Switch to blacktemple.net GSD session and run:
  ```bash
  cd ~/Documents/blacktemple.net
  npm run build:local   # prebuild copies cipher/knowledge/*, then builds
  ```
- [ ] Verify `/cipher` pages render correctly with new content
- [ ] Push to main → Vercel auto-deploys

### Why NOT auto-rebuild on Vercel
A `repository_dispatch` from CIPHER's release workflow would just rebuild
blacktemple.net with stale content. The actual site updates happen in the
blacktemple.net GSD session where you direct the changes — new copy, updated
metrics, revised feature grid, etc. The Vercel deploy happens naturally when
that session pushes to main after you've reviewed the changes.

---

## Post-Release Verification

### 8. Smoke Tests
- [ ] Fresh install: `pip install cipher-security` → `cipher --version`
- [ ] Docker run: `docker run ghcr.io/defconxt/cipher cipher --version`
- [ ] VS Code: install extension → open sidebar → send test query
- [ ] Website loads correctly with updated content
- [ ] GitHub README renders correctly

### 9. Announcements (for major/significant releases)
- [ ] GitHub Discussions / Release notes published
- [ ] Social media / community channels notified
- [ ] Any dependent projects notified of breaking changes

---

## Quick Release Script

For routine releases after the checklist is confirmed:

```bash
#!/usr/bin/env bash
# release.sh — CIPHER release helper
set -euo pipefail

VERSION="${1:?Usage: ./release.sh X.Y.Z}"

echo "=== CIPHER Release v${VERSION} ==="

# Pre-flight
echo "Running tests..."
python3 -m pytest tests/ -v --tb=short || { echo "❌ Tests failed"; exit 1; }

# Version consistency check
echo "Checking version strings..."
grep -q "\"${VERSION}\"" pyproject.toml 2>/dev/null || echo "⚠️  Update pyproject.toml"
grep -q "\"${VERSION}\"" vscode/package.json 2>/dev/null || echo "⚠️  Update vscode/package.json"

# Changelog check
grep -q "## \[${VERSION}\]" CHANGELOG.md || { echo "❌ No CHANGELOG entry for ${VERSION}"; exit 1; }

# Tag and push
echo "Tagging v${VERSION}..."
git tag -a "v${VERSION}" -m "CIPHER v${VERSION}"
git push origin "v${VERSION}"

echo ""
echo "✅ Tag pushed. CI will handle PyPI + Docker + VSIX + GitHub Release."
echo ""
echo "📋 MANUAL STEPS REMAINING:"
echo "  1. Verify CI pipeline completes: https://github.com/defconxt/cipher/actions"
echo "  2. Publish VSIX to VS Code Marketplace"
echo "  3. Update blacktemple.net/cipher"
echo "  4. Update GitHub README if needed"
echo "  5. Post announcements"
```

---

## Release Cadence

| Release Type | Trigger | Channels |
|-------------|---------|----------|
| **Patch** (X.Y.Z) | Bug fixes, minor skill updates | PyPI, Docker, GitHub |
| **Minor** (X.Y.0) | New skills, features, engine updates | All channels + website + README |
| **Major** (X.0.0) | Breaking changes, architecture shifts | All channels + website + README + announcements |

---

## Channel Quick Reference

| Channel | URL / Location | Update Method |
|---------|---------------|---------------|
| PyPI | `pip install cipher-security` | CI on tag push |
| Docker | `ghcr.io/defconxt/cipher` | CI on tag push |
| VS Code | Marketplace + VSIX | CI builds, manual publish |
| GitHub | `github.com/defconxt/cipher` | git push + README edit |
| Website | `blacktemple.net/cipher` | Manual update |
| CHANGELOG | `CHANGELOG.md` in repo | Manual before tagging |
| Docs | `docs/` in repo | Manual with feature changes |
