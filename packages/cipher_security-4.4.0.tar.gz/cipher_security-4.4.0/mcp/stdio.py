#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER MCP Server — stdio transport for Claude Desktop integration.

Reads JSON-RPC messages from stdin, writes responses to stdout.
Implements the Model Context Protocol (MCP) specification.

Usage:
  python3 -m mcp.stdio

In Claude Desktop config (~/.claude/claude_desktop_config.json):
  {
    "mcpServers": {
      "cipher": {
        "command": "python3",
        "args": ["-m", "mcp.stdio"],
        "cwd": "/path/to/cipher"
      }
    }
  }
"""

import json
import sys
from pathlib import Path

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent.parent))

from mcp.server import CipherMCPServer


def read_message() -> dict | None:
    """Read a JSON-RPC message from stdin using Content-Length headers."""
    # Try Content-Length framing first (MCP spec)
    header_line = sys.stdin.readline()
    if not header_line:
        return None

    # Handle Content-Length header
    if header_line.startswith("Content-Length:"):
        content_length = int(header_line.split(":")[1].strip())
        # Read blank line separator
        sys.stdin.readline()
        # Read body
        body = sys.stdin.read(content_length)
        return json.loads(body)

    # Fallback: try parsing the line directly as JSON (line-delimited)
    line = header_line.strip()
    if not line:
        return None
    try:
        return json.loads(line)
    except json.JSONDecodeError:
        return None


def write_message(msg: dict) -> None:
    """Write a JSON-RPC message to stdout with Content-Length framing."""
    body = json.dumps(msg)
    header = f"Content-Length: {len(body)}\r\n\r\n"
    sys.stdout.write(header)
    sys.stdout.write(body)
    sys.stdout.flush()


def write_jsonrpc_response(request_id, result: dict) -> None:
    """Write a JSON-RPC success response."""
    write_message(
        {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": result,
        }
    )


def write_jsonrpc_error(request_id, code: int, message: str) -> None:
    """Write a JSON-RPC error response."""
    write_message(
        {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": code, "message": message},
        }
    )


def handle_initialize(request_id: int, _params: dict) -> None:
    """Handle MCP initialize request."""
    write_jsonrpc_response(
        request_id,
        {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {"listChanged": False},
            },
            "serverInfo": {
                "name": "cipher",
                "version": "4.0.0",
            },
        },
    )


def handle_tools_list(request_id: int, _params: dict, server: CipherMCPServer) -> None:
    """Handle tools/list request."""
    tools = []
    for tool_name, tool_def in server.tools.items():
        tools.append(
            {
                "name": tool_name,
                "description": tool_def.get("description", ""),
                "inputSchema": tool_def.get(
                    "inputSchema", {"type": "object", "properties": {}}
                ),
            }
        )
    write_jsonrpc_response(request_id, {"tools": tools})


def handle_tools_call(request_id: int, params: dict, server: CipherMCPServer) -> None:
    """Handle tools/call request."""
    tool_name = params.get("name", "")
    arguments = params.get("arguments", {})

    try:
        result = server.handle_tool_call(tool_name, arguments)
        write_jsonrpc_response(
            request_id,
            {
                "content": [
                    {"type": "text", "text": json.dumps(result, indent=2, default=str)},
                ],
            },
        )
    except Exception as e:
        write_jsonrpc_response(
            request_id,
            {
                "content": [
                    {"type": "text", "text": json.dumps({"error": str(e)})},
                ],
                "isError": True,
            },
        )


def main() -> int:
    """Main stdio transport loop."""
    server = CipherMCPServer()

    # Log to stderr (stdout is for MCP protocol)
    sys.stderr.write("[CIPHER MCP] Server starting on stdio transport\n")
    sys.stderr.flush()

    while True:
        try:
            msg = read_message()
            if msg is None:
                break

            request_id = msg.get("id", 0)
            method = msg.get("method", "")
            params = msg.get("params", {})

            if method == "initialize":
                handle_initialize(request_id, params)
            elif method == "notifications/initialized":
                # Client acknowledgment, no response needed
                continue
            elif method == "tools/list":
                handle_tools_list(request_id, params, server)
            elif method == "tools/call":
                handle_tools_call(request_id, params, server)
            elif method == "ping":
                write_jsonrpc_response(request_id, {})
            else:
                write_jsonrpc_error(request_id, -32601, f"Method not found: {method}")

        except KeyboardInterrupt:
            break
        except Exception as e:
            sys.stderr.write(f"[CIPHER MCP] Error: {e}\n")
            sys.stderr.flush()
            if request_id is not None:
                write_jsonrpc_error(request_id, -32603, str(e))

    sys.stderr.write("[CIPHER MCP] Server stopped\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
