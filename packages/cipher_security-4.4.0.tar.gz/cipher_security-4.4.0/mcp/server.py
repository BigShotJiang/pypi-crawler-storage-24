#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER MCP Server — Full security platform over Model Context Protocol.

Exposes CIPHER's complete capability stack as MCP tools:
- Memory: store, search, context, consolidation (Phase 2)
- Pipeline: scan, crawl, PR review, diff analysis (Phase 3)
- Evolution: score responses, evolve skills
- Skills: search, retrieve, list domains

Usage:
  python3 mcp/server.py                     # stdio transport (default)
  python3 mcp/server.py --port 8377         # HTTP transport
  CIPHER_MEMORY_DIR=/path/to/db python3 mcp/server.py

Copyright (c) 2026 defconxt. All rights reserved.
Licensed under AGPL-3.0 — see LICENSE file for details.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from memory.core.engine import CipherMemory, MemoryEntry, MemoryType, MEMORY_DIR
from memory.core.retriever import AdaptiveRetriever, ContextBuilder
from memory.core.evolution import ResponseScorer
from pipeline.scanner import NucleiRunner, KatanaRunner, ScanPipeline, ScanProfile
from pipeline.github_actions import (
    SecurityDiffAnalyzer,
    FindingFormatter,
    WorkflowGenerator,
)


class CipherMCPServer:
    """MCP server exposing CIPHER's full security platform as tools."""

    def __init__(self, memory_dir: str | None = None, skills_dir: str = "skills"):
        mem_path = Path(memory_dir) if memory_dir else MEMORY_DIR
        self.memory = CipherMemory(memory_dir=mem_path)
        self.retriever = AdaptiveRetriever(memory=self.memory)
        self.context_builder = ContextBuilder()
        self.scorer = ResponseScorer()
        self.diff_analyzer = SecurityDiffAnalyzer()
        self.formatter = FindingFormatter()
        self.workflow_gen = WorkflowGenerator()
        self.nuclei = NucleiRunner()
        self.katana = KatanaRunner()
        self.pipeline = ScanPipeline(
            nuclei=self.nuclei, katana=self.katana, memory=self.memory
        )
        self.skills_dir = Path(skills_dir)
        self.tools = self._register_tools()

    def _register_tools(self) -> dict[str, dict]:
        return {
            # === Memory Tools ===
            "cipher_store": {
                "description": "Store a security finding, IOC, TTP, or note in CIPHER's cross-session memory.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "content": {
                            "type": "string",
                            "description": "The content to store",
                        },
                        "memory_type": {
                            "type": "string",
                            "enum": [t.value for t in MemoryType],
                            "description": "Type of memory entry",
                        },
                        "severity": {
                            "type": "string",
                            "enum": ["critical", "high", "medium", "low", "info"],
                            "description": "Finding severity",
                        },
                        "engagement_id": {
                            "type": "string",
                            "description": "Associated engagement ID",
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Tags for categorization",
                        },
                        "mitre_ids": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "MITRE ATT&CK technique IDs",
                        },
                        "cve_ids": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "CVE identifiers",
                        },
                        "targets": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Target IPs/domains",
                        },
                    },
                    "required": ["content", "memory_type"],
                },
            },
            "cipher_search": {
                "description": "Search CIPHER's memory with intent-aware retrieval. Automatically classifies query intent and adapts search strategy.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "engagement_id": {
                            "type": "string",
                            "description": "Filter by engagement",
                        },
                        "limit": {
                            "type": "integer",
                            "default": 10,
                            "description": "Max results",
                        },
                    },
                    "required": ["query"],
                },
            },
            "cipher_context": {
                "description": "Get token-budgeted engagement context for prompt injection. Returns structured memory formatted for LLM consumption.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Context query"},
                        "engagement_id": {
                            "type": "string",
                            "description": "Engagement ID",
                        },
                        "max_tokens": {
                            "type": "integer",
                            "default": 4000,
                            "description": "Token budget",
                        },
                    },
                    "required": ["query"],
                },
            },
            "cipher_consolidate": {
                "description": "Run memory consolidation — decay old entries, archive stale items, merge duplicates.",
                "inputSchema": {"type": "object", "properties": {}},
            },
            "cipher_stats": {
                "description": "Get memory and system statistics.",
                "inputSchema": {"type": "object", "properties": {}},
            },
            # === Pipeline Tools ===
            "cipher_scan": {
                "description": "Run a security scan against a target using Nuclei templates. Requires nuclei installed.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "target": {"type": "string", "description": "Target URL or IP"},
                        "profile": {
                            "type": "string",
                            "enum": [
                                "pentest",
                                "compliance",
                                "cloud",
                                "cves",
                                "osint",
                                "recommended",
                            ],
                            "description": "Scan profile",
                        },
                        "severity": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Severity filter",
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Template tags filter",
                        },
                        "engagement_id": {
                            "type": "string",
                            "description": "Store results under this engagement",
                        },
                    },
                    "required": ["target"],
                },
            },
            "cipher_crawl": {
                "description": "Crawl a target to discover endpoints, forms, and JavaScript files using Katana.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "target": {"type": "string", "description": "Target URL"},
                        "depth": {
                            "type": "integer",
                            "default": 3,
                            "description": "Crawl depth",
                        },
                        "headless": {
                            "type": "boolean",
                            "default": False,
                            "description": "Use headless browser",
                        },
                        "js_crawl": {
                            "type": "boolean",
                            "default": True,
                            "description": "Parse JavaScript",
                        },
                    },
                    "required": ["target"],
                },
            },
            "cipher_full_scan": {
                "description": "Full scan pipeline: crawl target → discover endpoints → scan with Nuclei → store findings.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "target": {"type": "string", "description": "Target URL"},
                        "profile": {
                            "type": "string",
                            "default": "pentest",
                            "description": "Scan profile",
                        },
                        "engagement_id": {
                            "type": "string",
                            "description": "Engagement ID",
                        },
                    },
                    "required": ["target"],
                },
            },
            # === Diff Analysis Tools ===
            "cipher_analyze_diff": {
                "description": "Analyze a git diff for security issues: auth changes, secrets, SQL injection, crypto weaknesses.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "diff": {"type": "string", "description": "Git diff text"},
                    },
                    "required": ["diff"],
                },
            },
            "cipher_detect_secrets": {
                "description": "Detect hardcoded secrets in a git diff: API keys, tokens, passwords, private keys.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "diff": {
                            "type": "string",
                            "description": "Git diff text to scan",
                        },
                    },
                    "required": ["diff"],
                },
            },
            # === Evolution Tools ===
            "cipher_score": {
                "description": "Score a CIPHER response for quality. Returns +1 (helpful), 0 (ambiguous), or -1 (unhelpful).",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Original query"},
                        "response": {
                            "type": "string",
                            "description": "Response to score",
                        },
                        "mode": {
                            "type": "string",
                            "enum": [
                                "RED",
                                "BLUE",
                                "INCIDENT",
                                "PRIVACY",
                                "RECON",
                                "ARCHITECT",
                                "PURPLE",
                            ],
                            "description": "CIPHER mode",
                        },
                    },
                    "required": ["query", "response"],
                },
            },
            # === Workflow Generation ===
            "cipher_generate_workflow": {
                "description": "Generate a GitHub Actions workflow for automated security scanning.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "profile": {
                            "type": "string",
                            "default": "pentest",
                            "description": "Scan profile",
                        },
                    },
                },
            },
            # === Skill Tools ===
            "cipher_list_domains": {
                "description": "List all CIPHER skill domains and technique counts.",
                "inputSchema": {"type": "object", "properties": {}},
            },
            "cipher_search_skills": {
                "description": "Search CIPHER skills by keyword, domain, or tag.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "domain": {"type": "string", "description": "Filter by domain"},
                        "limit": {
                            "type": "integer",
                            "default": 10,
                            "description": "Max results",
                        },
                    },
                    "required": ["query"],
                },
            },
        }

    def handle_tool_call(
        self, tool_name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        """Dispatch a tool call to the appropriate handler."""
        handlers = {
            "cipher_store": self._handle_store,
            "cipher_search": self._handle_search,
            "cipher_context": self._handle_context,
            "cipher_consolidate": self._handle_consolidate,
            "cipher_stats": self._handle_stats,
            "cipher_scan": self._handle_scan,
            "cipher_crawl": self._handle_crawl,
            "cipher_full_scan": self._handle_full_scan,
            "cipher_analyze_diff": self._handle_analyze_diff,
            "cipher_detect_secrets": self._handle_detect_secrets,
            "cipher_score": self._handle_score,
            "cipher_generate_workflow": self._handle_generate_workflow,
            "cipher_list_domains": self._handle_list_domains,
            "cipher_search_skills": self._handle_search_skills,
        }
        handler = handlers.get(tool_name)
        if not handler:
            return {"error": f"Unknown tool: {tool_name}"}
        try:
            return handler(arguments)
        except Exception as e:
            return {"error": str(e), "tool": tool_name}

    # === Memory Handlers ===

    def _handle_store(self, args: dict) -> dict:
        entry = MemoryEntry(
            content=args["content"],
            memory_type=MemoryType(args["memory_type"]),
            severity=args.get("severity", ""),
            engagement_id=args.get("engagement_id", ""),
            tags=args.get("tags", []),
            mitre_attack=args.get("mitre_ids", []),
            cve_ids=args.get("cve_ids", []),
            targets=args.get("targets", []),
            source_skill="mcp",
        )
        entry_id = self.memory.store(entry)
        return {"stored": True, "id": entry_id, "type": args["memory_type"]}

    def _handle_search(self, args: dict) -> dict:
        results = self.retriever.retrieve(
            query=args["query"],
            engagement_id=args.get("engagement_id", ""),
            limit=args.get("limit", 10),
        )
        return {
            "results": [
                {
                    "id": r.entry_id,
                    "content": r.content,
                    "type": r.memory_type.value
                    if hasattr(r.memory_type, "value")
                    else r.memory_type,
                    "severity": r.severity,
                    "confidence": r.confidence.value
                    if hasattr(r.confidence, "value")
                    else r.confidence,
                    "targets": r.targets,
                    "mitre_attack": r.mitre_attack,
                    "cve_ids": r.cve_ids,
                    "created": r.created_at,
                }
                for r in results
            ],
            "count": len(results),
        }

    def _handle_context(self, args: dict) -> dict:
        entries = self.retriever.retrieve(
            query=args["query"],
            engagement_id=args.get("engagement_id", ""),
        )
        builder = ContextBuilder(max_tokens=args.get("max_tokens", 4000))
        context = builder.build(entries, args["query"])
        return {"context": context, "entries_used": len(entries)}

    def _handle_consolidate(self, _args: dict) -> dict:
        stats = self.memory.consolidate()
        return {"consolidated": True, **(stats or {})}

    def _handle_stats(self, _args: dict) -> dict:
        mem_stats = self.memory.stats()
        skill_count = (
            len(list(self.skills_dir.rglob("SKILL.md")))
            if self.skills_dir.exists()
            else 0
        )
        return {
            "memory": mem_stats,
            "skills": skill_count,
            "tools": len(self.tools),
        }

    # === Pipeline Handlers ===

    def _handle_scan(self, args: dict) -> dict:
        profile = ScanProfile.from_domain(args.get("profile", "pentest"))
        result = self.nuclei.scan(
            target=args["target"],
            profile=profile,
            tags=args.get("tags", []),
            severity=args.get("severity", []),
        )
        # Store findings in memory
        if result.success:
            for finding in result.findings:
                self.memory.store(
                    MemoryEntry(
                        content=f"{finding.name}: {finding.description}"
                        if hasattr(finding, "description")
                        else finding.name,
                        memory_type=MemoryType.FINDING,
                        severity=finding.severity,
                        engagement_id=args.get("engagement_id", ""),
                        cve_ids=finding.cve_ids if hasattr(finding, "cve_ids") else [],
                        tags=finding.tags if hasattr(finding, "tags") else [],
                        targets=[args["target"]],
                    )
                )
        return {
            "success": result.success,
            "findings_count": len(result.findings),
            "findings": [
                {
                    "name": f.name,
                    "severity": f.severity,
                    "matched_at": f.matched_at if hasattr(f, "matched_at") else "",
                }
                for f in result.findings
            ],
            "errors": result.errors if hasattr(result, "errors") else [],
        }

    def _handle_crawl(self, args: dict) -> dict:
        result = self.katana.crawl(
            target=args["target"],
            depth=args.get("depth", 3),
            headless=args.get("headless", False),
            js_crawl=args.get("js_crawl", True),
        )
        return {
            "success": result.success,
            "urls_found": len(result.urls),
            "endpoints": result.endpoints[:50],
            "forms": len(result.forms),
            "js_files": len(result.js_files),
        }

    def _handle_full_scan(self, args: dict) -> dict:
        result = self.pipeline.full_scan(
            target=args["target"],
            profile=args.get("profile", "pentest"),
            engagement_id=args.get("engagement_id", ""),
        )
        return {
            "success": result.success,
            "urls_crawled": result.urls_crawled,
            "findings_count": result.findings_count,
            "findings_stored": result.findings_stored,
            "scan_duration": result.duration,
        }

    # === Diff Analysis Handlers ===

    def _handle_analyze_diff(self, args: dict) -> dict:
        analysis = self.diff_analyzer.analyze_diff(args["diff"])
        return {
            "risk_level": analysis.risk_level.value
            if hasattr(analysis.risk_level, "value")
            else str(analysis.risk_level),
            "files_changed": analysis.files_changed,
            "auth_changes": analysis.auth_changes,
            "sql_changes": analysis.sql_changes,
            "crypto_changes": analysis.crypto_changes,
            "secrets_found": len(analysis.secrets),
            "endpoints_added": analysis.endpoints_added,
            "endpoints_modified": analysis.endpoints_modified,
            "has_security_findings": analysis.has_security_findings,
            "summary": analysis.summary,
        }

    def _handle_detect_secrets(self, args: dict) -> dict:
        secrets = self.diff_analyzer.detect_secrets_in_diff(args["diff"])
        return {
            "secrets_found": len(secrets),
            "secrets": [
                {
                    "type": s.secret_type.value
                    if hasattr(s.secret_type, "value")
                    else str(s.secret_type),
                    "file": s.file_path,
                    "line": s.line_number,
                    "snippet": s.snippet[:50] + "..."
                    if len(s.snippet) > 50
                    else s.snippet,
                    "recommendation": s.recommendation,
                }
                for s in secrets
            ],
        }

    # === Evolution Handlers ===

    def _handle_score(self, args: dict) -> dict:
        scored = self.scorer.score(
            query=args["query"],
            response=args["response"],
            mode=args.get("mode", ""),
        )
        return {
            "score": scored.score,
            "votes": scored.votes,
            "feedback": scored.feedback,
        }

    # === Workflow Handlers ===

    def _handle_generate_workflow(self, args: dict) -> dict:
        workflow = self.workflow_gen.generate_workflow(
            scan_profile=args.get("profile", "pentest")
        )
        return {"workflow": workflow}

    # === Skill Handlers ===

    def _handle_list_domains(self, _args: dict) -> dict:
        domains: dict[str, int] = {}
        if self.skills_dir.exists():
            for domain_dir in sorted(self.skills_dir.iterdir()):
                if domain_dir.is_dir() and not domain_dir.name.startswith("."):
                    techniques_dir = domain_dir / "techniques"
                    if techniques_dir.exists():
                        count = len([d for d in techniques_dir.iterdir() if d.is_dir()])
                        domains[domain_dir.name] = count
                    elif (domain_dir / "SKILL.md").exists():
                        domains[domain_dir.name] = 0
        return {"domains": domains, "total": sum(domains.values())}

    def _handle_search_skills(self, args: dict) -> dict:
        query = args["query"].lower()
        domain_filter = args.get("domain", "")
        limit = args.get("limit", 10)
        results = []

        search_dir = (
            self.skills_dir / domain_filter if domain_filter else self.skills_dir
        )
        if not search_dir.exists():
            return {"results": [], "count": 0}

        for skill_md in search_dir.rglob("SKILL.md"):
            rel_path = str(skill_md.parent.relative_to(self.skills_dir))
            name = skill_md.parent.name

            if query in name.lower() or query in rel_path.lower():
                results.append(
                    {
                        "name": name,
                        "path": rel_path,
                        "domain": rel_path.split("/")[0] if "/" in rel_path else name,
                    }
                )

            if len(results) >= limit:
                break

        return {"results": results, "count": len(results)}

    # === MCP Protocol ===

    def run_stdio(self) -> None:
        """Run as MCP server over stdio transport (JSON-RPC 2.0)."""
        while True:
            try:
                line = sys.stdin.readline()
                if not line:
                    break

                request = json.loads(line)
                method = request.get("method", "")
                req_id = request.get("id")

                if method == "initialize":
                    response = {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "result": {
                            "protocolVersion": "2024-11-05",
                            "capabilities": {"tools": {}},
                            "serverInfo": {
                                "name": "cipher",
                                "version": "2.5.0",
                                "description": "CIPHER — Claude Integrated Privacy & Hardening Expert Resource",
                            },
                        },
                    }
                elif method == "notifications/initialized":
                    continue
                elif method == "tools/list":
                    tools_list = [
                        {
                            "name": name,
                            "description": schema["description"],
                            "inputSchema": schema["inputSchema"],
                        }
                        for name, schema in self.tools.items()
                    ]
                    response = {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "result": {"tools": tools_list},
                    }
                elif method == "tools/call":
                    params = request.get("params", {})
                    tool_name = params.get("name", "")
                    arguments = params.get("arguments", {})
                    result = self.handle_tool_call(tool_name, arguments)
                    is_error = isinstance(result, dict) and "error" in result
                    response = {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "result": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": json.dumps(result, indent=2, default=str),
                                }
                            ],
                            **({"isError": True} if is_error else {}),
                        },
                    }
                else:
                    response = {
                        "jsonrpc": "2.0",
                        "id": req_id,
                        "error": {
                            "code": -32601,
                            "message": f"Method not found: {method}",
                        },
                    }

                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()

            except json.JSONDecodeError:
                continue
            except KeyboardInterrupt:
                break
            except Exception as e:
                error_response = {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32603, "message": str(e)},
                }
                sys.stdout.write(json.dumps(error_response) + "\n")
                sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser(description="CIPHER MCP Server")
    parser.add_argument("--memory-dir", default=None, help="Memory storage directory")
    parser.add_argument("--skills-dir", default="skills", help="Skills directory")
    args = parser.parse_args()

    server = CipherMCPServer(memory_dir=args.memory_dir, skills_dir=args.skills_dir)
    server.run_stdio()


if __name__ == "__main__":
    main()
