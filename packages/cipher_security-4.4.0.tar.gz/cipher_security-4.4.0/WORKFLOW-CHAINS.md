<!-- Copyright (c) 2026 defconxt. All rights reserved. -->
<!-- Licensed under AGPL-3.0 — see LICENSE file for details. -->
<!-- CIPHER is a trademark of defconxt. -->

# CIPHER Workflow Chains

Skill-to-skill pipelines for common security operations. Inspired by OpenShell's
workflow chain pattern. Each chain defines a sequence of skills that compose into
end-to-end workflows.

## Engagement Chains

### Full Penetration Test
```
engagement-pipeline → osint-recon → vulnerability-management → [domain-specific skill] → engagement-pipeline (report)
```

### Red Team Operation
```
engagement-pipeline (scope) → osint-recon → [red-team/web | red-team/active-directory | red-team/cloud] → red-team/post-exploitation → engagement-pipeline (report)
```

### Vulnerability Assessment
```
engagement-pipeline (scope) → osint-recon → vulnerability-management → [api-security | container-security | cloud-security] → engagement-pipeline (report)
```

## Defensive Chains

### SOC Alert Triage
```
soc-operations (triage) → blue-team (detection) → threat-intelligence (enrich) → incident-response (if confirmed)
```

### Incident Response
```
incident-response (triage) → digital-forensics (evidence) → malware-analysis (if malware) → threat-intelligence (attribution) → incident-response (report)
```

### Ransomware Response
```
ransomware-defense (detect) → incident-response (contain) → digital-forensics (preserve) → ransomware-defense (recover)
```

## Proactive Chains

### Threat Hunting
```
threat-intelligence (hypothesis) → soc-operations (hunt queries) → blue-team (new detection rules) → purple-team (validate)
```

### Purple Team Exercise
```
purple-team (emulation plan) → [red-team/* skill] (execute TTP) → blue-team (detection validation) → purple-team (gap analysis)
```

### Security Architecture Review
```
security-architecture (threat model) → [domain-specific skills] (assess) → compliance-audit (map controls) → engagement-pipeline (report)
```

## DevSecOps Chains

### PR Security Review
```
devsecops (SAST/SCA scan) → [api-security | web] (manual review) → supply-chain-security (dependency check) → devsecops (gate decision)
```

### Container Deployment
```
container-security (image scan) → devsecops (pipeline gate) → network-security (network policy) → soc-operations (runtime monitoring)
```

## Release Chains

### Post-Change Release
```
[significant change merged] → RELEASE.md (pre-release checklist) → git tag → CI pipeline (PyPI+Docker+VSIX+GitHub) → VS Code Marketplace (manual) → blacktemple.net/cipher (manual) → GitHub README (manual) → smoke tests
```

### Website Sync (Cross-Project)
```
CIPHER release (tag push) → RELEASE-STATE.json updated → switch to blacktemple.net GSD session → npm run build:local (prebuild copies knowledge/) → verify /cipher pages → push main → Vercel deploy
```

### Skill Expansion Release
```
self-evolution (new skill) → index.json update → CHANGELOG.md → RELEASE.md workflow → README skill count → website metrics
```

## Evolution Chains

### Skill Gap Detection
```
[any skill fails] → self-evolution (gap detection) → self-evolution (synthesis) → self-evolution (validation + registration)
```

### Knowledge Compounding
```
[engagement completes] → cross-session-memory (store findings) → threat-intelligence (enrich IOCs) → cross-session-memory (consolidate)
```
