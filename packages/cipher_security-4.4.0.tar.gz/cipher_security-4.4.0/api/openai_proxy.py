# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""OpenAI-compatible completion proxy — enables NemoClaw / MetaClaw / any
OpenAI-compatible client to route inference through CIPHER.

CIPHER intercepts chat completion requests, injects relevant security skills
as system context, forwards to the upstream LLM, and logs the interaction
for leaderboard scoring.

## Architecture

    Client (NemoClaw / OpenClaw / any agent)
        │
        ▼
    CIPHER Proxy  (/v1/chat/completions, /v1/models)
        │  ← injects matching CIPHER skills into system prompt
        ▼
    Upstream LLM  (any OpenAI-compatible API)

## Usage

    # Start proxy
    python -m api.openai_proxy --upstream https://api.openai.com/v1 --port 8100

    # Point your agent at it
    export OPENAI_BASE_URL=http://127.0.0.1:8100/v1
    export OPENAI_API_KEY=your-real-key  # forwarded to upstream
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any

logger = logging.getLogger("cipher.openai_proxy")


# ---------------------------------------------------------------------------
# Skill injection
# ---------------------------------------------------------------------------


def _find_matching_skills(messages: list[dict], max_skills: int = 3) -> str:
    """Find relevant CIPHER skills for the conversation and return injection text.

    Searches the user messages for security-relevant keywords and returns
    matching skill summaries to inject into the system prompt.
    """
    skills_root = Path(__file__).resolve().parent.parent / "skills"
    if not skills_root.is_dir():
        return ""

    # Extract user message text
    user_text = " ".join(
        m.get("content", "")
        for m in messages
        if isinstance(m.get("content"), str) and m.get("role") == "user"
    ).lower()

    if not user_text:
        return ""

    # Security keyword → domain mapping
    keyword_domains: dict[str, list[str]] = {
        "xss": ["web-application-security", "browser-security"],
        "sql injection": ["web-application-security", "database-security"],
        "sqli": ["web-application-security", "database-security"],
        "privilege escalation": ["linux-security", "windows-security"],
        "privesc": ["linux-security", "windows-security"],
        "active directory": ["active-directory-security"],
        "kerberos": ["active-directory-security"],
        "malware": ["malware-analysis"],
        "reverse engineer": ["reverse-engineering"],
        "incident": ["incident-response"],
        "forensic": ["digital-forensics", "cloud-forensics"],
        "osint": ["osint-techniques"],
        "reconnaissance": ["osint-techniques", "network-security"],
        "container": ["container-security"],
        "docker": ["container-security"],
        "kubernetes": ["container-security"],
        "cloud": ["cloud-security"],
        "aws": ["cloud-security"],
        "azure": ["cloud-security"],
        "api": ["api-security"],
        "cryptograph": ["cryptography"],
        "encrypt": ["cryptography"],
        "phishing": ["social-engineering"],
        "exploit": ["exploit-development", "binary-exploitation"],
        "buffer overflow": ["binary-exploitation"],
        "rop": ["binary-exploitation"],
        "c2": ["c2-frameworks"],
        "command and control": ["c2-frameworks"],
        "siem": ["log-analysis"],
        "detection": ["log-analysis", "threat-intelligence"],
        "sigma": ["log-analysis"],
        "threat intel": ["threat-intelligence"],
        "zero trust": ["zero-trust"],
        "compliance": ["compliance-auditing"],
        "gdpr": ["privacy-engineering"],
        "privacy": ["privacy-engineering"],
        "network": ["network-security"],
        "firewall": ["network-security"],
        "wireless": ["wireless-security"],
        "wifi": ["wireless-security"],
        "mobile": ["mobile-security"],
        "android": ["mobile-security"],
        "ios": ["mobile-security"],
        "supply chain": ["supply-chain-security"],
        "password": ["password-cracking"],
        "brute force": ["password-cracking"],
        "bug bounty": ["bug-bounty"],
    }

    # Find matching domains
    matched_domains: list[str] = []
    for keyword, domains in keyword_domains.items():
        if keyword in user_text:
            for d in domains:
                if d not in matched_domains:
                    matched_domains.append(d)

    if not matched_domains:
        return ""

    # Load skill summaries from matched domains
    injections: list[str] = []
    for domain in matched_domains[:max_skills]:
        domain_dir = skills_root / domain
        if not domain_dir.is_dir():
            continue
        # Read domain-level SKILL.md if it exists
        skill_md = domain_dir / "SKILL.md"
        if skill_md.is_file():
            try:
                content = skill_md.read_text()
                # Extract description (first paragraph after metadata)
                lines = content.split("\n")
                desc_lines: list[str] = []
                in_body = False
                for line in lines:
                    if in_body:
                        if line.strip() == "" and desc_lines:
                            break
                        if line.strip().startswith("#"):
                            if desc_lines:
                                break
                            continue
                        desc_lines.append(line.strip())
                    elif line.strip().startswith("# ") or line.strip() == "---":
                        in_body = True
                if desc_lines:
                    injections.append(f"[CIPHER/{domain}] {' '.join(desc_lines[:3])}")
            except OSError:
                pass

        # List available techniques
        tech_dir = domain_dir / "techniques"
        if tech_dir.is_dir():
            techniques = sorted(d.name for d in tech_dir.iterdir() if d.is_dir())[:8]
            if techniques:
                injections.append(
                    f"  Available techniques: {', '.join(t.replace('-', ' ') for t in techniques)}"
                )

    if not injections:
        return ""

    return (
        "\n\n--- CIPHER Security Context ---\n"
        + "\n".join(injections)
        + "\n--- End CIPHER Context ---\n"
    )


# ---------------------------------------------------------------------------
# Proxy config
# ---------------------------------------------------------------------------


@dataclass
class ProxyConfig:
    """Configuration for the OpenAI-compatible proxy."""

    upstream_url: str = os.getenv("CIPHER_UPSTREAM_URL", "http://localhost:11434/v1")
    host: str = os.getenv("CIPHER_PROXY_HOST", "127.0.0.1")
    port: int = int(os.getenv("CIPHER_PROXY_PORT", "8100"))
    inject_skills: bool = True
    max_skills: int = 3
    log_interactions: bool = True
    model_override: str = ""  # If set, override the model field in requests


# ---------------------------------------------------------------------------
# Request handler
# ---------------------------------------------------------------------------


class OpenAIProxyHandler(BaseHTTPRequestHandler):
    """Handle OpenAI-compatible API requests."""

    def log_message(self, fmt: str, *args: Any) -> None:
        logger.debug(fmt, *args)

    def do_GET(self) -> None:
        if self.path == "/v1/models" or self.path == "/v1/models/":
            self._handle_models()
        elif self.path == "/health" or self.path == "/v1/health":
            self._respond(200, {"status": "ok", "proxy": "cipher"})
        else:
            self._respond(404, {"error": "not found"})

    def do_POST(self) -> None:
        if self.path == "/v1/chat/completions":
            self._handle_chat_completions()
        elif self.path == "/v1/completions":
            self._handle_completions()
        else:
            self._respond(404, {"error": "not found"})

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self._cors_headers()
        self.end_headers()

    # -- handlers -----------------------------------------------------------

    def _handle_models(self) -> None:
        """Return model list — forward from upstream or generate synthetic."""
        config: ProxyConfig = self.server.proxy_config  # type: ignore[attr-defined]
        try:
            upstream_resp = self._forward_get("/v1/models")
            self._respond(200, upstream_resp)
        except Exception:
            # Fallback: synthetic model list
            self._respond(
                200,
                {
                    "object": "list",
                    "data": [
                        {
                            "id": config.model_override or "cipher-proxy",
                            "object": "model",
                            "created": int(time.time()),
                            "owned_by": "cipher",
                        }
                    ],
                },
            )

    def _handle_chat_completions(self) -> None:
        """Handle /v1/chat/completions — inject skills and forward."""
        config: ProxyConfig = self.server.proxy_config  # type: ignore[attr-defined]
        body = self._read_body()
        if body is None:
            return

        messages = body.get("messages", [])

        # Inject CIPHER skills into system context
        if config.inject_skills and messages:
            skill_context = _find_matching_skills(messages, config.max_skills)
            if skill_context:
                # Find or create system message
                if messages and messages[0].get("role") == "system":
                    messages[0]["content"] = (
                        messages[0].get("content", "") + skill_context
                    )
                else:
                    messages.insert(0, {"role": "system", "content": skill_context})
                body["messages"] = messages

        # Override model if configured
        if config.model_override:
            body["model"] = config.model_override

        # Forward to upstream
        try:
            is_stream = body.get("stream", False)
            if is_stream:
                self._forward_stream("/v1/chat/completions", body)
            else:
                result = self._forward_post("/v1/chat/completions", body)
                self._respond(200, result)

                # Log interaction for leaderboard
                if config.log_interactions:
                    self._log_interaction(messages, result)
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            self._respond(exc.code, {"error": error_body})
        except Exception as exc:
            logger.error("Upstream error: %s", exc)
            self._respond(502, {"error": "upstream unavailable"})

    def _handle_completions(self) -> None:
        """Handle /v1/completions — forward without skill injection."""
        body = self._read_body()
        if body is None:
            return
        try:
            result = self._forward_post("/v1/completions", body)
            self._respond(200, result)
        except Exception as exc:
            logger.error("Upstream error: %s", exc)
            self._respond(502, {"error": "upstream unavailable"})

    # -- upstream communication ---------------------------------------------

    def _forward_post(self, path: str, body: dict) -> dict:
        config: ProxyConfig = self.server.proxy_config  # type: ignore[attr-defined]
        url = config.upstream_url.rstrip("/") + path
        if not url.startswith(("http://", "https://")):
            raise ValueError(f"Invalid upstream URL scheme: {url}")
        data = json.dumps(body).encode()

        # Forward auth header
        headers = {"Content-Type": "application/json"}
        auth = self.headers.get("Authorization")
        if auth:
            headers["Authorization"] = auth

        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=120) as resp:  # nosec B310
            return json.loads(resp.read())

    def _forward_get(self, path: str) -> dict:
        config: ProxyConfig = self.server.proxy_config  # type: ignore[attr-defined]
        url = config.upstream_url.rstrip("/") + path
        if not url.startswith(("http://", "https://")):
            raise ValueError(f"Invalid upstream URL scheme: {url}")
        headers: dict[str, str] = {}
        auth = self.headers.get("Authorization")
        if auth:
            headers["Authorization"] = auth
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:  # nosec B310
            return json.loads(resp.read())

    def _forward_stream(self, path: str, body: dict) -> None:
        """Forward a streaming request and relay SSE chunks."""
        config: ProxyConfig = self.server.proxy_config  # type: ignore[attr-defined]
        url = config.upstream_url.rstrip("/") + path
        if not url.startswith(("http://", "https://")):
            raise ValueError(f"Invalid upstream URL scheme: {url}")
        data = json.dumps(body).encode()

        headers = {"Content-Type": "application/json"}
        auth = self.headers.get("Authorization")
        if auth:
            headers["Authorization"] = auth

        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            resp = urllib.request.urlopen(req, timeout=120)  # nosec B310
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self._cors_headers()
            self.end_headers()

            while True:
                chunk = resp.read(4096)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
            resp.close()
        except Exception as exc:
            logger.error("Stream error: %s", exc)
            self._respond(502, {"error": "upstream stream failed"})

    # -- interaction logging ------------------------------------------------

    def _log_interaction(self, messages: list[dict], result: dict) -> None:
        """Log interaction to leaderboard for ACE adaptation."""
        try:
            from autonomous.leaderboard import SkillLeaderboard

            lb = SkillLeaderboard()

            # Extract which skills were injected (from system message)
            sys_msg = ""
            for m in messages:
                if m.get("role") == "system":
                    sys_msg = m.get("content", "")
                    break

            # Parse injected skill domains
            import re

            domains = re.findall(r"\[CIPHER/([^\]]+)\]", sys_msg)

            # Simple quality heuristic: response length + completion tokens
            usage = result.get("usage", {})
            completion_tokens = usage.get("completion_tokens", 0)
            # Normalize: 100 tokens = 0.5, 500+ tokens = 0.9
            score = min(0.9, 0.3 + completion_tokens / 700)

            for domain in domains:
                lb.record_invocation(
                    f"{domain}/proxy-invocation",
                    success=True,
                    score=score,
                    context={
                        "source": "openai_proxy",
                        "model": result.get("model", ""),
                    },
                )
            lb.close()
        except Exception as exc:
            logger.debug("Interaction logging failed: %s", exc)

    # -- helpers ------------------------------------------------------------

    def _read_body(self) -> dict | None:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            self._respond(400, {"error": "empty body"})
            return None
        if length > 10 * 1024 * 1024:  # 10MB limit
            self._respond(413, {"error": "payload too large"})
            return None
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._respond(400, {"error": "invalid JSON"})
            return None

    def _respond(self, status: int, data: dict) -> None:
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self._cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------


class CipherOpenAIProxy(HTTPServer):
    """OpenAI-compatible proxy server with CIPHER skill injection."""

    def __init__(self, config: ProxyConfig | None = None) -> None:
        self.proxy_config = config or ProxyConfig()
        super().__init__(
            (self.proxy_config.host, self.proxy_config.port),
            OpenAIProxyHandler,
        )


def main() -> None:  # pragma: no cover
    """Run the OpenAI-compatible proxy."""
    import argparse

    parser = argparse.ArgumentParser(description="CIPHER OpenAI-compatible proxy")
    parser.add_argument(
        "--upstream", default="http://localhost:11434/v1", help="Upstream LLM API URL"
    )
    parser.add_argument("--port", type=int, default=8100, help="Listen port")
    parser.add_argument("--host", default="127.0.0.1", help="Listen host")
    parser.add_argument(
        "--no-inject", action="store_true", help="Disable skill injection"
    )
    parser.add_argument("--model", default="", help="Override model name")
    args = parser.parse_args()

    config = ProxyConfig(
        upstream_url=args.upstream,
        host=args.host,
        port=args.port,
        inject_skills=not args.no_inject,
        model_override=args.model,
    )

    logging.basicConfig(level=logging.INFO)
    server = CipherOpenAIProxy(config)
    logger.info(
        "CIPHER proxy on %s:%d → %s (skills=%s)",
        config.host,
        config.port,
        config.upstream_url,
        config.inject_skills,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
        print("\nProxy shutdown.")


if __name__ == "__main__":
    main()
