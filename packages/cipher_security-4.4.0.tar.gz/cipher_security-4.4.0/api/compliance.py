# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0

"""CIPHER Compliance Engine — automated compliance report generation.

Maps security findings and scan results to regulatory frameworks,
generates gap analyses, and exports reports for GRC tooling.
"""

from __future__ import annotations

import csv
import io
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ComplianceFramework(str, Enum):
    """Supported compliance frameworks."""

    SOC2 = "SOC2"
    PCI_DSS = "PCI_DSS"
    HIPAA = "HIPAA"
    NIST_800_53 = "NIST_800_53"
    CIS = "CIS"
    ISO_27001 = "ISO_27001"
    GDPR = "GDPR"
    # --- Added in audit v1.0 ---
    CMMC = "CMMC"
    NIST_CSF = "NIST_CSF"
    NIST_AI_RMF = "NIST_AI_RMF"
    FEDRAMP = "FEDRAMP"
    OWASP_TOP_10 = "OWASP_TOP_10"
    MITRE_ATTACK = "MITRE_ATTACK"
    IEC_62443 = "IEC_62443"
    NIS2 = "NIS2"
    DORA = "DORA"
    CISA_KEV = "CISA_KEV"
    # --- Added in audit v2.0 ---
    EU_AI_ACT = "EU_AI_ACT"
    SWIFT_CSP = "SWIFT_CSP"
    NIST_800_171 = "NIST_800_171"
    ISO_27017 = "ISO_27017"
    ISO_27018 = "ISO_27018"
    ISO_27701 = "ISO_27701"
    CSA_CCM = "CSA_CCM"
    NERC_CIP = "NERC_CIP"
    HITRUST_CSF = "HITRUST_CSF"
    CIS_CLOUD = "CIS_CLOUD"
    NIST_800_82 = "NIST_800_82"
    OWASP_MASVS = "OWASP_MASVS"
    SANS_TOP_25 = "SANS_TOP_25"
    PTES = "PTES"
    OSSTMM = "OSSTMM"
    SOX_IT = "SOX_IT"
    COBIT = "COBIT"
    ITIL_SECURITY = "ITIL_SECURITY"
    SSDF = "SSDF"
    OWASP_ASVS = "OWASP_ASVS"
    NIST_PRIVACY = "NIST_PRIVACY"
    CCPA = "CCPA"


class ControlStatus(str, Enum):
    """Assessment outcome for a single control."""

    PASS = "PASS"
    FAIL = "FAIL"
    PARTIAL = "PARTIAL"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    NOT_TESTED = "NOT_TESTED"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ControlAssessment:
    """Result of evaluating one control against collected evidence."""

    control_id: str
    control_name: str
    framework: ComplianceFramework
    status: ControlStatus
    evidence: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    severity: str = "info"
    tested_at: str = ""

    def __post_init__(self) -> None:
        if not self.tested_at:
            self.tested_at = datetime.now(timezone.utc).isoformat()


@dataclass
class ComplianceReport:
    """Full compliance report for a single framework assessment."""

    report_id: str
    framework: ComplianceFramework
    scope: str
    assessor: str = "CIPHER Automated Assessment"
    controls_total: int = 0
    controls_pass: int = 0
    controls_fail: int = 0
    controls_partial: int = 0
    controls_na: int = 0
    overall_score: float = 0.0
    assessments: list[ControlAssessment] = field(default_factory=list)
    executive_summary: str = ""
    created_at: str = ""

    def __post_init__(self) -> None:
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    # -- serialisation helpers ------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialise the report to a plain dictionary."""
        return {
            "report_id": self.report_id,
            "framework": self.framework.value,
            "scope": self.scope,
            "assessor": self.assessor,
            "controls_total": self.controls_total,
            "controls_pass": self.controls_pass,
            "controls_fail": self.controls_fail,
            "controls_partial": self.controls_partial,
            "controls_na": self.controls_na,
            "overall_score": round(self.overall_score, 2),
            "executive_summary": self.executive_summary,
            "created_at": self.created_at,
            "assessments": [
                {
                    "control_id": a.control_id,
                    "control_name": a.control_name,
                    "framework": a.framework.value,
                    "status": a.status.value,
                    "evidence": a.evidence,
                    "gaps": a.gaps,
                    "recommendations": a.recommendations,
                    "severity": a.severity,
                    "tested_at": a.tested_at,
                }
                for a in self.assessments
            ],
        }

    def to_json(self) -> str:
        """Serialise the report to a JSON string."""
        return json.dumps(self.to_dict(), indent=2)

    def to_markdown(self) -> str:
        """Render the report as a Markdown document."""
        lines: list[str] = [
            f"# Compliance Report — {self.framework.value}",
            "",
            f"**Report ID:** {self.report_id}  ",
            f"**Scope:** {self.scope}  ",
            f"**Assessor:** {self.assessor}  ",
            f"**Created:** {self.created_at}  ",
            "",
            "## Executive Summary",
            "",
            self.executive_summary or "_No summary generated._",
            "",
            "## Score Overview",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Overall Score | {self.overall_score:.1f}% |",
            f"| Total Controls | {self.controls_total} |",
            f"| Pass | {self.controls_pass} |",
            f"| Fail | {self.controls_fail} |",
            f"| Partial | {self.controls_partial} |",
            f"| N/A | {self.controls_na} |",
            "",
            "## Control Assessments",
            "",
        ]

        for a in self.assessments:
            status_icon = {
                ControlStatus.PASS: "✅",
                ControlStatus.FAIL: "❌",
                ControlStatus.PARTIAL: "⚠️",
                ControlStatus.NOT_APPLICABLE: "➖",
                ControlStatus.NOT_TESTED: "❓",
            }.get(a.status, "")
            lines.append(f"### {status_icon} {a.control_id} — {a.control_name}")
            lines.append("")
            lines.append(f"**Status:** {a.status.value} | **Severity:** {a.severity}")
            lines.append("")
            if a.evidence:
                lines.append("**Evidence:**")
                for e in a.evidence:
                    lines.append(f"- {e}")
                lines.append("")
            if a.gaps:
                lines.append("**Gaps:**")
                for g in a.gaps:
                    lines.append(f"- {g}")
                lines.append("")
            if a.recommendations:
                lines.append("**Recommendations:**")
                for r in a.recommendations:
                    lines.append(f"- {r}")
                lines.append("")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Control catalogue — real control IDs & names per framework
# ---------------------------------------------------------------------------

_SOC2_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CC1.1",
        "name": "COSO Principle 1 — Integrity and Ethics",
        "category": "governance",
    },
    {
        "id": "CC1.2",
        "name": "Board Independence and Oversight",
        "category": "governance",
    },
    {
        "id": "CC1.3",
        "name": "Management Accountability Structure",
        "category": "governance",
    },
    {
        "id": "CC2.1",
        "name": "Information Quality Objectives",
        "category": "communication",
    },
    {"id": "CC3.1", "name": "Risk Identification and Assessment", "category": "risk"},
    {"id": "CC3.2", "name": "Fraud Risk Assessment", "category": "risk"},
    {
        "id": "CC3.3",
        "name": "Impact of Changes on Internal Control",
        "category": "risk",
    },
    {
        "id": "CC4.1",
        "name": "Monitoring of Internal Controls",
        "category": "monitoring",
    },
    {"id": "CC5.1", "name": "Control Activities over Technology", "category": "access"},
    {"id": "CC5.2", "name": "Logical Access Security Policies", "category": "access"},
    {
        "id": "CC6.1",
        "name": "Logical and Physical Access Controls",
        "category": "access",
    },
    {"id": "CC6.2", "name": "User Authentication Mechanisms", "category": "auth"},
    {"id": "CC6.3", "name": "Role-Based Access Authorisation", "category": "auth"},
    {
        "id": "CC6.6",
        "name": "Boundary Protection and Threat Mitigation",
        "category": "network",
    },
    {"id": "CC6.7", "name": "Data-in-Transit Encryption", "category": "crypto"},
    {"id": "CC6.8", "name": "Malicious Software Prevention", "category": "malware"},
    {"id": "CC7.1", "name": "Vulnerability Management", "category": "vuln"},
    {"id": "CC7.2", "name": "Security Event Monitoring", "category": "monitoring"},
    {"id": "CC7.3", "name": "Incident Response Procedures", "category": "incident"},
    {"id": "CC8.1", "name": "Change Management Controls", "category": "change"},
    {"id": "CC9.1", "name": "Risk Mitigation Activities", "category": "risk"},
]

_PCI_DSS_CONTROLS: list[dict[str, str]] = [
    {
        "id": "PCI-1.1",
        "name": "Install and Maintain Network Security Controls",
        "category": "network",
    },
    {
        "id": "PCI-2.1",
        "name": "Apply Secure Configuration Standards",
        "category": "config",
    },
    {"id": "PCI-2.2", "name": "Manage Default Credentials", "category": "auth"},
    {"id": "PCI-3.1", "name": "Protect Stored Account Data", "category": "data"},
    {
        "id": "PCI-3.4",
        "name": "Render PAN Unreadable (Encryption/Hashing)",
        "category": "crypto",
    },
    {
        "id": "PCI-4.1",
        "name": "Protect Data in Transit with Strong Cryptography",
        "category": "crypto",
    },
    {
        "id": "PCI-5.1",
        "name": "Deploy Anti-Malware on All Systems",
        "category": "malware",
    },
    {
        "id": "PCI-6.1",
        "name": "Identify and Address Vulnerabilities",
        "category": "vuln",
    },
    {"id": "PCI-6.2", "name": "Develop Secure Software Practices", "category": "code"},
    {
        "id": "PCI-7.1",
        "name": "Restrict Access by Business Need to Know",
        "category": "access",
    },
    {
        "id": "PCI-8.1",
        "name": "Identify and Authenticate System Users",
        "category": "auth",
    },
    {"id": "PCI-8.3", "name": "Secure Authentication with MFA", "category": "auth"},
    {
        "id": "PCI-9.1",
        "name": "Restrict Physical Access to Cardholder Data",
        "category": "physical",
    },
    {
        "id": "PCI-10.1",
        "name": "Log and Monitor All Access to Systems",
        "category": "logging",
    },
    {
        "id": "PCI-11.1",
        "name": "Test Security of Systems and Networks Regularly",
        "category": "testing",
    },
    {
        "id": "PCI-12.1",
        "name": "Maintain an Information Security Policy",
        "category": "governance",
    },
]

_HIPAA_CONTROLS: list[dict[str, str]] = [
    {
        "id": "§164.308(a)(1)",
        "name": "Security Management Process",
        "category": "governance",
    },
    {
        "id": "§164.308(a)(2)",
        "name": "Assigned Security Responsibility",
        "category": "governance",
    },
    {"id": "§164.308(a)(3)", "name": "Workforce Security", "category": "access"},
    {
        "id": "§164.308(a)(4)",
        "name": "Information Access Management",
        "category": "access",
    },
    {
        "id": "§164.308(a)(5)",
        "name": "Security Awareness and Training",
        "category": "training",
    },
    {
        "id": "§164.308(a)(6)",
        "name": "Security Incident Procedures",
        "category": "incident",
    },
    {"id": "§164.308(a)(7)", "name": "Contingency Plan", "category": "recovery"},
    {
        "id": "§164.308(a)(8)",
        "name": "Evaluation of Security Controls",
        "category": "monitoring",
    },
    {
        "id": "§164.310(a)(1)",
        "name": "Facility Access Controls",
        "category": "physical",
    },
    {"id": "§164.310(b)", "name": "Workstation Use Policies", "category": "physical"},
    {"id": "§164.310(d)(1)", "name": "Device and Media Controls", "category": "data"},
    {
        "id": "§164.312(a)(1)",
        "name": "Access Control — Unique User ID",
        "category": "auth",
    },
    {"id": "§164.312(b)", "name": "Audit Controls and Logging", "category": "logging"},
    {"id": "§164.312(c)(1)", "name": "Integrity Controls", "category": "data"},
    {
        "id": "§164.312(d)",
        "name": "Person or Entity Authentication",
        "category": "auth",
    },
    {
        "id": "§164.312(e)(1)",
        "name": "Transmission Security (Encryption)",
        "category": "crypto",
    },
]

_NIST_800_53_CONTROLS: list[dict[str, str]] = [
    # AC — Access Control (26 controls)
    {"id": "AC-1", "name": "Policy and Procedures", "category": "access"},
    {"id": "AC-2", "name": "Account Management", "category": "access"},
    {"id": "AC-3", "name": "Access Enforcement", "category": "access"},
    {"id": "AC-4", "name": "Information Flow Enforcement", "category": "network"},
    {"id": "AC-5", "name": "Separation of Duties", "category": "access"},
    {"id": "AC-6", "name": "Least Privilege", "category": "access"},
    {"id": "AC-7", "name": "Unsuccessful Logon Attempts", "category": "auth"},
    {"id": "AC-8", "name": "System Use Notification", "category": "access"},
    {"id": "AC-10", "name": "Concurrent Session Control", "category": "access"},
    {"id": "AC-11", "name": "Device Lock", "category": "access"},
    {"id": "AC-12", "name": "Session Termination", "category": "access"},
    {
        "id": "AC-14",
        "name": "Permitted Actions without Identification or Authentication",
        "category": "access",
    },
    {"id": "AC-16", "name": "Security and Privacy Attributes", "category": "data"},
    {"id": "AC-17", "name": "Remote Access", "category": "network"},
    {"id": "AC-18", "name": "Wireless Access", "category": "network"},
    {"id": "AC-19", "name": "Access Control for Mobile Devices", "category": "access"},
    {"id": "AC-20", "name": "Use of External Systems", "category": "access"},
    {"id": "AC-21", "name": "Information Sharing", "category": "data"},
    {"id": "AC-22", "name": "Publicly Accessible Content", "category": "data"},
    {"id": "AC-23", "name": "Data Mining Protection", "category": "data"},
    {"id": "AC-24", "name": "Access Control Decisions", "category": "access"},
    {"id": "AC-25", "name": "Reference Monitor", "category": "access"},
    # AT — Awareness and Training (6 controls)
    {"id": "AT-1", "name": "Policy and Procedures (Training)", "category": "training"},
    {"id": "AT-2", "name": "Literacy Training and Awareness", "category": "training"},
    {"id": "AT-3", "name": "Role-Based Training", "category": "training"},
    {"id": "AT-4", "name": "Training Records", "category": "training"},
    {
        "id": "AT-5",
        "name": "Contacts with Security Groups and Associations",
        "category": "training",
    },
    {"id": "AT-6", "name": "Training Feedback", "category": "training"},
    # AU — Audit and Accountability (16 controls)
    {"id": "AU-1", "name": "Policy and Procedures (Audit)", "category": "logging"},
    {"id": "AU-2", "name": "Event Logging", "category": "logging"},
    {"id": "AU-3", "name": "Content of Audit Records", "category": "logging"},
    {"id": "AU-4", "name": "Audit Log Storage Capacity", "category": "logging"},
    {
        "id": "AU-5",
        "name": "Response to Audit Logging Process Failures",
        "category": "logging",
    },
    {
        "id": "AU-6",
        "name": "Audit Record Review, Analysis, and Reporting",
        "category": "monitoring",
    },
    {
        "id": "AU-7",
        "name": "Audit Record Reduction and Report Generation",
        "category": "monitoring",
    },
    {"id": "AU-8", "name": "Time Stamps", "category": "logging"},
    {"id": "AU-9", "name": "Protection of Audit Information", "category": "logging"},
    {"id": "AU-10", "name": "Non-Repudiation", "category": "logging"},
    {"id": "AU-11", "name": "Audit Record Retention", "category": "logging"},
    {"id": "AU-12", "name": "Audit Record Generation", "category": "logging"},
    {
        "id": "AU-13",
        "name": "Monitoring for Information Disclosure",
        "category": "monitoring",
    },
    {"id": "AU-14", "name": "Session Audit", "category": "logging"},
    {
        "id": "AU-15",
        "name": "Alternate Audit Logging Capability",
        "category": "logging",
    },
    {
        "id": "AU-16",
        "name": "Cross-Organizational Audit Logging",
        "category": "logging",
    },
    # CA — Assessment, Authorization, and Monitoring (9 controls)
    {
        "id": "CA-1",
        "name": "Policy and Procedures (Assessment)",
        "category": "governance",
    },
    {"id": "CA-2", "name": "Control Assessments", "category": "testing"},
    {"id": "CA-3", "name": "Information Exchange", "category": "network"},
    {"id": "CA-5", "name": "Plan of Action and Milestones", "category": "governance"},
    {"id": "CA-6", "name": "Authorization", "category": "governance"},
    {"id": "CA-7", "name": "Continuous Monitoring", "category": "monitoring"},
    {"id": "CA-8", "name": "Penetration Testing", "category": "testing"},
    {"id": "CA-9", "name": "Internal System Connections", "category": "network"},
    # CM — Configuration Management (14 controls)
    {
        "id": "CM-1",
        "name": "Policy and Procedures (Configuration)",
        "category": "config",
    },
    {"id": "CM-2", "name": "Baseline Configuration", "category": "config"},
    {"id": "CM-3", "name": "Configuration Change Control", "category": "config"},
    {"id": "CM-4", "name": "Impact Analyses", "category": "config"},
    {"id": "CM-5", "name": "Access Restrictions for Change", "category": "config"},
    {"id": "CM-6", "name": "Configuration Settings", "category": "config"},
    {"id": "CM-7", "name": "Least Functionality", "category": "config"},
    {"id": "CM-8", "name": "System Component Inventory", "category": "inventory"},
    {"id": "CM-9", "name": "Configuration Management Plan", "category": "config"},
    {"id": "CM-10", "name": "Software Usage Restrictions", "category": "config"},
    {"id": "CM-11", "name": "User-Installed Software", "category": "config"},
    {"id": "CM-12", "name": "Information Location", "category": "data"},
    {"id": "CM-13", "name": "Data Action Mapping", "category": "data"},
    {"id": "CM-14", "name": "Signed Components", "category": "code"},
    # CP — Contingency Planning (13 controls)
    {
        "id": "CP-1",
        "name": "Policy and Procedures (Contingency)",
        "category": "recovery",
    },
    {"id": "CP-2", "name": "Contingency Plan", "category": "recovery"},
    {"id": "CP-3", "name": "Contingency Training", "category": "training"},
    {"id": "CP-4", "name": "Contingency Plan Testing", "category": "testing"},
    {"id": "CP-6", "name": "Alternate Storage Site", "category": "recovery"},
    {"id": "CP-7", "name": "Alternate Processing Site", "category": "recovery"},
    {"id": "CP-8", "name": "Telecommunications Services", "category": "recovery"},
    {"id": "CP-9", "name": "System Backup", "category": "recovery"},
    {
        "id": "CP-10",
        "name": "System Recovery and Reconstitution",
        "category": "recovery",
    },
    {
        "id": "CP-11",
        "name": "Alternate Communications Protocols",
        "category": "recovery",
    },
    {"id": "CP-12", "name": "Safe Mode", "category": "recovery"},
    {"id": "CP-13", "name": "Alternative Security Mechanisms", "category": "recovery"},
    # IA — Identification and Authentication (12 controls)
    {
        "id": "IA-1",
        "name": "Policy and Procedures (Identification)",
        "category": "auth",
    },
    {
        "id": "IA-2",
        "name": "Identification and Authentication (Organizational Users)",
        "category": "auth",
    },
    {
        "id": "IA-3",
        "name": "Device Identification and Authentication",
        "category": "auth",
    },
    {"id": "IA-4", "name": "Identifier Management", "category": "auth"},
    {"id": "IA-5", "name": "Authenticator Management", "category": "auth"},
    {"id": "IA-6", "name": "Authentication Feedback", "category": "auth"},
    {"id": "IA-7", "name": "Cryptographic Module Authentication", "category": "crypto"},
    {
        "id": "IA-8",
        "name": "Identification and Authentication (Non-Organizational Users)",
        "category": "auth",
    },
    {
        "id": "IA-9",
        "name": "Service Identification and Authentication",
        "category": "auth",
    },
    {"id": "IA-10", "name": "Adaptive Authentication", "category": "auth"},
    {"id": "IA-11", "name": "Re-Authentication", "category": "auth"},
    {"id": "IA-12", "name": "Identity Proofing", "category": "auth"},
    # IR — Incident Response (10 controls)
    {
        "id": "IR-1",
        "name": "Policy and Procedures (Incident Response)",
        "category": "incident",
    },
    {"id": "IR-2", "name": "Incident Response Training", "category": "incident"},
    {"id": "IR-3", "name": "Incident Response Testing", "category": "testing"},
    {"id": "IR-4", "name": "Incident Handling", "category": "incident"},
    {"id": "IR-5", "name": "Incident Monitoring", "category": "monitoring"},
    {"id": "IR-6", "name": "Incident Reporting", "category": "incident"},
    {"id": "IR-7", "name": "Incident Response Assistance", "category": "incident"},
    {"id": "IR-8", "name": "Incident Response Plan", "category": "incident"},
    {"id": "IR-9", "name": "Information Spillage Response", "category": "incident"},
    {
        "id": "IR-10",
        "name": "Integrated Information Security Analysis Team",
        "category": "incident",
    },
    # MA — Maintenance (6 controls)
    {"id": "MA-1", "name": "Policy and Procedures (Maintenance)", "category": "config"},
    {"id": "MA-2", "name": "Controlled Maintenance", "category": "config"},
    {"id": "MA-3", "name": "Maintenance Tools", "category": "config"},
    {"id": "MA-4", "name": "Nonlocal Maintenance", "category": "config"},
    {"id": "MA-5", "name": "Maintenance Personnel", "category": "access"},
    {"id": "MA-6", "name": "Timely Maintenance", "category": "config"},
    # MP — Media Protection (8 controls)
    {
        "id": "MP-1",
        "name": "Policy and Procedures (Media Protection)",
        "category": "data",
    },
    {"id": "MP-2", "name": "Media Access", "category": "data"},
    {"id": "MP-3", "name": "Media Marking", "category": "data"},
    {"id": "MP-4", "name": "Media Storage", "category": "data"},
    {"id": "MP-5", "name": "Media Transport", "category": "data"},
    {"id": "MP-6", "name": "Media Sanitization", "category": "data"},
    {"id": "MP-7", "name": "Media Use", "category": "data"},
    {"id": "MP-8", "name": "Media Downgrading", "category": "data"},
    # PE — Physical and Environmental Protection (23 controls)
    {"id": "PE-1", "name": "Policy and Procedures (Physical)", "category": "physical"},
    {"id": "PE-2", "name": "Physical Access Authorizations", "category": "physical"},
    {"id": "PE-3", "name": "Physical Access Control", "category": "physical"},
    {"id": "PE-4", "name": "Access Control for Transmission", "category": "physical"},
    {"id": "PE-5", "name": "Access Control for Output Devices", "category": "physical"},
    {"id": "PE-6", "name": "Monitoring Physical Access", "category": "physical"},
    {"id": "PE-8", "name": "Visitor Access Records", "category": "physical"},
    {"id": "PE-9", "name": "Power Equipment and Cabling", "category": "physical"},
    {"id": "PE-10", "name": "Emergency Shutoff", "category": "physical"},
    {"id": "PE-11", "name": "Emergency Power", "category": "physical"},
    {"id": "PE-12", "name": "Emergency Lighting", "category": "physical"},
    {"id": "PE-13", "name": "Fire Protection", "category": "physical"},
    {"id": "PE-14", "name": "Environmental Controls", "category": "physical"},
    {"id": "PE-15", "name": "Water Damage Protection", "category": "physical"},
    {"id": "PE-16", "name": "Delivery and Removal", "category": "physical"},
    {"id": "PE-17", "name": "Alternate Work Site", "category": "physical"},
    {"id": "PE-18", "name": "Location of System Components", "category": "physical"},
    {"id": "PE-19", "name": "Information Leakage", "category": "physical"},
    {"id": "PE-20", "name": "Asset Monitoring and Tracking", "category": "inventory"},
    {"id": "PE-21", "name": "Electromagnetic Pulse Protection", "category": "physical"},
    {"id": "PE-22", "name": "Component Marking", "category": "physical"},
    {"id": "PE-23", "name": "Facility Location", "category": "physical"},
    # PL — Planning (11 controls)
    {
        "id": "PL-1",
        "name": "Policy and Procedures (Planning)",
        "category": "governance",
    },
    {
        "id": "PL-2",
        "name": "System Security and Privacy Plans",
        "category": "governance",
    },
    {"id": "PL-4", "name": "Rules of Behavior", "category": "governance"},
    {"id": "PL-7", "name": "Concept of Operations", "category": "governance"},
    {
        "id": "PL-8",
        "name": "Security and Privacy Architectures",
        "category": "governance",
    },
    {"id": "PL-9", "name": "Central Management", "category": "governance"},
    {"id": "PL-10", "name": "Baseline Selection", "category": "governance"},
    {"id": "PL-11", "name": "Baseline Tailoring", "category": "governance"},
    # PM — Program Management (32 controls)
    {
        "id": "PM-1",
        "name": "Information Security Program Plan",
        "category": "governance",
    },
    {
        "id": "PM-2",
        "name": "Information Security Program Leadership Role",
        "category": "governance",
    },
    {
        "id": "PM-3",
        "name": "Information Security and Privacy Resources",
        "category": "governance",
    },
    {
        "id": "PM-4",
        "name": "Plan of Action and Milestones Process",
        "category": "governance",
    },
    {"id": "PM-5", "name": "System Inventory", "category": "inventory"},
    {"id": "PM-6", "name": "Measures of Performance", "category": "governance"},
    {"id": "PM-7", "name": "Enterprise Architecture", "category": "governance"},
    {"id": "PM-8", "name": "Critical Infrastructure Plan", "category": "governance"},
    {"id": "PM-9", "name": "Risk Management Strategy", "category": "risk"},
    {"id": "PM-10", "name": "Authorization Process", "category": "governance"},
    {
        "id": "PM-11",
        "name": "Mission and Business Process Definition",
        "category": "governance",
    },
    {"id": "PM-12", "name": "Insider Threat Program", "category": "monitoring"},
    {"id": "PM-13", "name": "Security and Privacy Workforce", "category": "training"},
    {"id": "PM-14", "name": "Testing, Training, and Monitoring", "category": "testing"},
    {
        "id": "PM-15",
        "name": "Security and Privacy Groups and Associations",
        "category": "governance",
    },
    {"id": "PM-16", "name": "Threat Awareness Program", "category": "monitoring"},
    {"id": "PM-17", "name": "Protecting CUI on External Systems", "category": "data"},
    {"id": "PM-18", "name": "Privacy Program Plan", "category": "governance"},
    {
        "id": "PM-19",
        "name": "Privacy Program Leadership Role",
        "category": "governance",
    },
    {
        "id": "PM-20",
        "name": "Dissemination of Privacy Program Information",
        "category": "governance",
    },
    {"id": "PM-21", "name": "Accounting of Disclosures", "category": "data"},
    {
        "id": "PM-22",
        "name": "Personally Identifiable Information Quality Management",
        "category": "data",
    },
    {"id": "PM-23", "name": "Data Governance Body", "category": "governance"},
    {"id": "PM-24", "name": "Data Integrity Board", "category": "governance"},
    {"id": "PM-25", "name": "Minimization of PII Used in Testing", "category": "data"},
    {"id": "PM-26", "name": "Complaint Management", "category": "governance"},
    {"id": "PM-27", "name": "Privacy Reporting", "category": "governance"},
    {"id": "PM-28", "name": "Risk Framing", "category": "risk"},
    {
        "id": "PM-29",
        "name": "Risk Management Program Leadership Roles",
        "category": "governance",
    },
    {
        "id": "PM-30",
        "name": "Supply Chain Risk Management Strategy",
        "category": "governance",
    },
    {"id": "PM-31", "name": "Continuous Monitoring Strategy", "category": "monitoring"},
    {"id": "PM-32", "name": "Purposing", "category": "governance"},
    # PS — Personnel Security (9 controls)
    {
        "id": "PS-1",
        "name": "Policy and Procedures (Personnel)",
        "category": "governance",
    },
    {"id": "PS-2", "name": "Position Risk Designation", "category": "governance"},
    {"id": "PS-3", "name": "Personnel Screening", "category": "governance"},
    {"id": "PS-4", "name": "Personnel Termination", "category": "access"},
    {"id": "PS-5", "name": "Personnel Transfer", "category": "access"},
    {"id": "PS-6", "name": "Access Agreements", "category": "access"},
    {"id": "PS-7", "name": "External Personnel Security", "category": "governance"},
    {"id": "PS-8", "name": "Personnel Sanctions", "category": "governance"},
    {"id": "PS-9", "name": "Position Descriptions", "category": "governance"},
    # PT — PII Processing and Transparency (8 controls)
    {
        "id": "PT-1",
        "name": "Policy and Procedures (PII Processing)",
        "category": "data",
    },
    {"id": "PT-2", "name": "Authority to Process PII", "category": "data"},
    {"id": "PT-3", "name": "PII Processing Purposes", "category": "data"},
    {"id": "PT-4", "name": "Consent", "category": "data"},
    {"id": "PT-5", "name": "Privacy Notice", "category": "data"},
    {"id": "PT-6", "name": "System of Records Notice", "category": "data"},
    {"id": "PT-7", "name": "Specific Categories of PII", "category": "data"},
    {"id": "PT-8", "name": "Computer Matching Requirements", "category": "data"},
    # RA — Risk Assessment (10 controls)
    {
        "id": "RA-1",
        "name": "Policy and Procedures (Risk Assessment)",
        "category": "risk",
    },
    {"id": "RA-2", "name": "Security Categorization", "category": "risk"},
    {"id": "RA-3", "name": "Risk Assessment", "category": "risk"},
    {"id": "RA-5", "name": "Vulnerability Monitoring and Scanning", "category": "vuln"},
    {
        "id": "RA-6",
        "name": "Technical Surveillance Countermeasures Survey",
        "category": "physical",
    },
    {"id": "RA-7", "name": "Risk Response", "category": "risk"},
    {"id": "RA-8", "name": "Privacy Impact Assessments", "category": "risk"},
    {"id": "RA-9", "name": "Criticality Analysis", "category": "risk"},
    {"id": "RA-10", "name": "Threat Hunting", "category": "monitoring"},
    # SA — System and Services Acquisition (23 controls)
    {
        "id": "SA-1",
        "name": "Policy and Procedures (System Acquisition)",
        "category": "governance",
    },
    {"id": "SA-2", "name": "Allocation of Resources", "category": "governance"},
    {"id": "SA-3", "name": "System Development Life Cycle", "category": "code"},
    {"id": "SA-4", "name": "Acquisition Process", "category": "governance"},
    {"id": "SA-5", "name": "System Documentation", "category": "governance"},
    {
        "id": "SA-8",
        "name": "Security and Privacy Engineering Principles",
        "category": "code",
    },
    {"id": "SA-9", "name": "External System Services", "category": "governance"},
    {"id": "SA-10", "name": "Developer Configuration Management", "category": "code"},
    {"id": "SA-11", "name": "Developer Testing and Evaluation", "category": "testing"},
    {"id": "SA-12", "name": "Supply Chain Protection", "category": "code"},
    {
        "id": "SA-15",
        "name": "Development Process, Standards, and Tools",
        "category": "code",
    },
    {"id": "SA-16", "name": "Developer-Provided Training", "category": "training"},
    {
        "id": "SA-17",
        "name": "Developer Security and Privacy Architecture and Design",
        "category": "code",
    },
    {
        "id": "SA-20",
        "name": "Customized Development of Critical Components",
        "category": "code",
    },
    {"id": "SA-21", "name": "Developer Screening", "category": "governance"},
    {"id": "SA-22", "name": "Unsupported System Components", "category": "vuln"},
    {"id": "SA-23", "name": "Specialization", "category": "code"},
    # SC — System and Communications Protection (51 controls)
    {
        "id": "SC-1",
        "name": "Policy and Procedures (System Protection)",
        "category": "network",
    },
    {
        "id": "SC-2",
        "name": "Separation of System and User Functionality",
        "category": "access",
    },
    {"id": "SC-3", "name": "Security Function Isolation", "category": "access"},
    {
        "id": "SC-4",
        "name": "Information in Shared System Resources",
        "category": "data",
    },
    {"id": "SC-5", "name": "Denial-of-Service Protection", "category": "network"},
    {"id": "SC-7", "name": "Boundary Protection", "category": "network"},
    {
        "id": "SC-8",
        "name": "Transmission Confidentiality and Integrity",
        "category": "crypto",
    },
    {"id": "SC-10", "name": "Network Disconnect", "category": "network"},
    {
        "id": "SC-12",
        "name": "Cryptographic Key Establishment and Management",
        "category": "crypto",
    },
    {"id": "SC-13", "name": "Cryptographic Protection", "category": "crypto"},
    {
        "id": "SC-15",
        "name": "Collaborative Computing Devices and Applications",
        "category": "network",
    },
    {
        "id": "SC-17",
        "name": "Public Key Infrastructure Certificates",
        "category": "crypto",
    },
    {"id": "SC-18", "name": "Mobile Code", "category": "code"},
    {
        "id": "SC-20",
        "name": "Secure Name/Address Resolution Service (Authoritative Source)",
        "category": "network",
    },
    {
        "id": "SC-21",
        "name": "Secure Name/Address Resolution Service (Recursive or Caching Resolver)",
        "category": "network",
    },
    {
        "id": "SC-22",
        "name": "Architecture and Provisioning for Name/Address Resolution Service",
        "category": "network",
    },
    {"id": "SC-23", "name": "Session Authenticity", "category": "auth"},
    {"id": "SC-24", "name": "Fail in Known State", "category": "recovery"},
    {"id": "SC-25", "name": "Thin Nodes", "category": "config"},
    {"id": "SC-26", "name": "Honeypots", "category": "monitoring"},
    {"id": "SC-27", "name": "Platform-Independent Applications", "category": "code"},
    {"id": "SC-28", "name": "Protection of Information at Rest", "category": "crypto"},
    {"id": "SC-29", "name": "Heterogeneity", "category": "config"},
    {"id": "SC-30", "name": "Concealment and Misdirection", "category": "monitoring"},
    {"id": "SC-31", "name": "Covert Channel Analysis", "category": "monitoring"},
    {"id": "SC-32", "name": "System Partitioning", "category": "network"},
    {"id": "SC-34", "name": "Non-Modifiable Executable Programs", "category": "code"},
    {
        "id": "SC-35",
        "name": "External Malicious Code Identification",
        "category": "malware",
    },
    {
        "id": "SC-36",
        "name": "Distributed Processing and Storage",
        "category": "recovery",
    },
    {"id": "SC-37", "name": "Out-of-Band Channels", "category": "network"},
    {"id": "SC-38", "name": "Operations Security", "category": "monitoring"},
    {"id": "SC-39", "name": "Process Isolation", "category": "access"},
    {"id": "SC-40", "name": "Wireless Link Protection", "category": "crypto"},
    {"id": "SC-41", "name": "Port and I/O Device Access", "category": "physical"},
    {"id": "SC-42", "name": "Sensor Capability and Data", "category": "data"},
    {"id": "SC-43", "name": "Usage Restrictions", "category": "config"},
    {"id": "SC-44", "name": "Detonation Chambers", "category": "malware"},
    {"id": "SC-45", "name": "System Time Synchronization", "category": "logging"},
    {"id": "SC-46", "name": "Cross Domain Policy Enforcement", "category": "network"},
    {"id": "SC-47", "name": "Alternate Communications Paths", "category": "recovery"},
    {"id": "SC-48", "name": "Sensor Relocation", "category": "monitoring"},
    {
        "id": "SC-49",
        "name": "Hardware-Enforced Separation and Policy Enforcement",
        "category": "access",
    },
    {
        "id": "SC-50",
        "name": "Software-Enforced Separation and Policy Enforcement",
        "category": "access",
    },
    {"id": "SC-51", "name": "Hardware-Based Protection", "category": "access"},
    # SI — System and Information Integrity (23 controls)
    {
        "id": "SI-1",
        "name": "Policy and Procedures (System Integrity)",
        "category": "monitoring",
    },
    {"id": "SI-2", "name": "Flaw Remediation", "category": "vuln"},
    {"id": "SI-3", "name": "Malicious Code Protection", "category": "malware"},
    {"id": "SI-4", "name": "System Monitoring", "category": "monitoring"},
    {
        "id": "SI-5",
        "name": "Security Alerts, Advisories, and Directives",
        "category": "monitoring",
    },
    {
        "id": "SI-6",
        "name": "Security and Privacy Function Verification",
        "category": "testing",
    },
    {
        "id": "SI-7",
        "name": "Software, Firmware, and Information Integrity",
        "category": "code",
    },
    {"id": "SI-8", "name": "Spam Protection", "category": "network"},
    {"id": "SI-10", "name": "Information Input Validation", "category": "code"},
    {"id": "SI-11", "name": "Error Handling", "category": "code"},
    {"id": "SI-12", "name": "Information Management and Retention", "category": "data"},
    {"id": "SI-13", "name": "Predictable Failure Prevention", "category": "recovery"},
    {"id": "SI-14", "name": "Non-Persistence", "category": "config"},
    {"id": "SI-15", "name": "Information Output Filtering", "category": "data"},
    {"id": "SI-16", "name": "Memory Protection", "category": "code"},
    {"id": "SI-17", "name": "Fail-Safe Procedures", "category": "recovery"},
    {"id": "SI-18", "name": "PII Quality Management", "category": "data"},
    {"id": "SI-19", "name": "De-identification", "category": "data"},
    {"id": "SI-20", "name": "Tainting", "category": "monitoring"},
    {"id": "SI-21", "name": "Information Refresh", "category": "data"},
    {"id": "SI-22", "name": "Information Diversity", "category": "data"},
    {"id": "SI-23", "name": "Information Fragmentation", "category": "data"},
    # SR — Supply Chain Risk Management (12 controls)
    {
        "id": "SR-1",
        "name": "Policy and Procedures (Supply Chain)",
        "category": "governance",
    },
    {
        "id": "SR-2",
        "name": "Supply Chain Risk Management Plan",
        "category": "governance",
    },
    {
        "id": "SR-3",
        "name": "Supply Chain Controls and Processes",
        "category": "governance",
    },
    {"id": "SR-4", "name": "Provenance", "category": "code"},
    {
        "id": "SR-5",
        "name": "Acquisition Strategies, Tools, and Methods",
        "category": "governance",
    },
    {
        "id": "SR-6",
        "name": "Supplier Assessments and Reviews",
        "category": "governance",
    },
    {
        "id": "SR-7",
        "name": "Supply Chain Operations Security",
        "category": "monitoring",
    },
    {"id": "SR-8", "name": "Notification Agreements", "category": "governance"},
    {"id": "SR-9", "name": "Tamper Resistance and Detection", "category": "physical"},
    {
        "id": "SR-10",
        "name": "Inspection of Systems or Components",
        "category": "testing",
    },
    {"id": "SR-11", "name": "Component Authenticity", "category": "code"},
    {"id": "SR-12", "name": "Component Disposal", "category": "data"},
]

_CIS_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CIS-1",
        "name": "Inventory and Control of Enterprise Assets",
        "category": "inventory",
    },
    {
        "id": "CIS-2",
        "name": "Inventory and Control of Software Assets",
        "category": "inventory",
    },
    {"id": "CIS-3", "name": "Data Protection", "category": "data"},
    {
        "id": "CIS-4",
        "name": "Secure Configuration of Enterprise Assets and Software",
        "category": "config",
    },
    {"id": "CIS-5", "name": "Account Management", "category": "access"},
    {"id": "CIS-6", "name": "Access Control Management", "category": "access"},
    {"id": "CIS-7", "name": "Continuous Vulnerability Management", "category": "vuln"},
    {"id": "CIS-8", "name": "Audit Log Management", "category": "logging"},
    {"id": "CIS-9", "name": "Email and Web Browser Protections", "category": "network"},
    {"id": "CIS-10", "name": "Malware Defences", "category": "malware"},
    {"id": "CIS-11", "name": "Data Recovery", "category": "recovery"},
    {
        "id": "CIS-12",
        "name": "Network Infrastructure Management",
        "category": "network",
    },
    {
        "id": "CIS-13",
        "name": "Network Monitoring and Defence",
        "category": "monitoring",
    },
    {
        "id": "CIS-14",
        "name": "Security Awareness and Skills Training",
        "category": "training",
    },
    {"id": "CIS-15", "name": "Service Provider Management", "category": "governance"},
    {"id": "CIS-16", "name": "Application Software Security", "category": "code"},
    {"id": "CIS-17", "name": "Incident Response Management", "category": "incident"},
    {"id": "CIS-18", "name": "Penetration Testing", "category": "testing"},
]

_ISO_27001_CONTROLS: list[dict[str, str]] = [
    # A.5 — Organizational Controls (37 controls)
    {
        "id": "A.5.1",
        "name": "Policies for Information Security",
        "category": "governance",
    },
    {
        "id": "A.5.2",
        "name": "Information Security Roles and Responsibilities",
        "category": "governance",
    },
    {"id": "A.5.3", "name": "Segregation of Duties", "category": "access"},
    {"id": "A.5.4", "name": "Management Responsibilities", "category": "governance"},
    {"id": "A.5.5", "name": "Contact with Authorities", "category": "governance"},
    {
        "id": "A.5.6",
        "name": "Contact with Special Interest Groups",
        "category": "governance",
    },
    {"id": "A.5.7", "name": "Threat Intelligence", "category": "monitoring"},
    {
        "id": "A.5.8",
        "name": "Information Security in Project Management",
        "category": "governance",
    },
    {
        "id": "A.5.9",
        "name": "Inventory of Information and Other Associated Assets",
        "category": "inventory",
    },
    {
        "id": "A.5.10",
        "name": "Acceptable Use of Information and Other Associated Assets",
        "category": "governance",
    },
    {"id": "A.5.11", "name": "Return of Assets", "category": "governance"},
    {"id": "A.5.12", "name": "Classification of Information", "category": "data"},
    {"id": "A.5.13", "name": "Labelling of Information", "category": "data"},
    {"id": "A.5.14", "name": "Information Transfer", "category": "data"},
    {"id": "A.5.15", "name": "Access Control", "category": "access"},
    {"id": "A.5.16", "name": "Identity Management", "category": "auth"},
    {"id": "A.5.17", "name": "Authentication Information", "category": "auth"},
    {"id": "A.5.18", "name": "Access Rights", "category": "access"},
    {
        "id": "A.5.19",
        "name": "Information Security in Supplier Relationships",
        "category": "governance",
    },
    {
        "id": "A.5.20",
        "name": "Addressing Information Security within Supplier Agreements",
        "category": "governance",
    },
    {
        "id": "A.5.21",
        "name": "Managing Information Security in the ICT Supply Chain",
        "category": "governance",
    },
    {
        "id": "A.5.22",
        "name": "Monitoring, Review and Change Management of Supplier Services",
        "category": "monitoring",
    },
    {
        "id": "A.5.23",
        "name": "Information Security for Use of Cloud Services",
        "category": "config",
    },
    {
        "id": "A.5.24",
        "name": "Information Security Incident Management Planning and Preparation",
        "category": "incident",
    },
    {
        "id": "A.5.25",
        "name": "Assessment and Decision on Information Security Events",
        "category": "incident",
    },
    {
        "id": "A.5.26",
        "name": "Response to Information Security Incidents",
        "category": "incident",
    },
    {
        "id": "A.5.27",
        "name": "Learning from Information Security Incidents",
        "category": "incident",
    },
    {"id": "A.5.28", "name": "Collection of Evidence", "category": "incident"},
    {
        "id": "A.5.29",
        "name": "Information Security During Disruption",
        "category": "recovery",
    },
    {
        "id": "A.5.30",
        "name": "ICT Readiness for Business Continuity",
        "category": "recovery",
    },
    {
        "id": "A.5.31",
        "name": "Legal, Statutory, Regulatory and Contractual Requirements",
        "category": "governance",
    },
    {"id": "A.5.32", "name": "Intellectual Property Rights", "category": "governance"},
    {"id": "A.5.33", "name": "Protection of Records", "category": "data"},
    {"id": "A.5.34", "name": "Privacy and Protection of PII", "category": "data"},
    {
        "id": "A.5.35",
        "name": "Independent Review of Information Security",
        "category": "testing",
    },
    {
        "id": "A.5.36",
        "name": "Compliance with Policies, Rules and Standards",
        "category": "governance",
    },
    {
        "id": "A.5.37",
        "name": "Documented Operating Procedures",
        "category": "governance",
    },
    # A.6 — People Controls (8 controls)
    {"id": "A.6.1", "name": "Screening", "category": "governance"},
    {
        "id": "A.6.2",
        "name": "Terms and Conditions of Employment",
        "category": "governance",
    },
    {
        "id": "A.6.3",
        "name": "Information Security Awareness, Education and Training",
        "category": "training",
    },
    {"id": "A.6.4", "name": "Disciplinary Process", "category": "governance"},
    {
        "id": "A.6.5",
        "name": "Responsibilities After Termination or Change of Employment",
        "category": "access",
    },
    {
        "id": "A.6.6",
        "name": "Confidentiality or Non-Disclosure Agreements",
        "category": "governance",
    },
    {"id": "A.6.7", "name": "Remote Working", "category": "access"},
    {
        "id": "A.6.8",
        "name": "Information Security Event Reporting",
        "category": "incident",
    },
    # A.7 — Physical Controls (14 controls)
    {"id": "A.7.1", "name": "Physical Security Perimeters", "category": "physical"},
    {"id": "A.7.2", "name": "Physical Entry", "category": "physical"},
    {
        "id": "A.7.3",
        "name": "Securing Offices, Rooms and Facilities",
        "category": "physical",
    },
    {"id": "A.7.4", "name": "Physical Security Monitoring", "category": "physical"},
    {
        "id": "A.7.5",
        "name": "Protecting Against Physical and Environmental Threats",
        "category": "physical",
    },
    {"id": "A.7.6", "name": "Working in Secure Areas", "category": "physical"},
    {"id": "A.7.7", "name": "Clear Desk and Clear Screen", "category": "physical"},
    {"id": "A.7.8", "name": "Equipment Siting and Protection", "category": "physical"},
    {"id": "A.7.9", "name": "Security of Assets Off-Premises", "category": "physical"},
    {"id": "A.7.10", "name": "Storage Media", "category": "data"},
    {"id": "A.7.11", "name": "Supporting Utilities", "category": "physical"},
    {"id": "A.7.12", "name": "Cabling Security", "category": "physical"},
    {"id": "A.7.13", "name": "Equipment Maintenance", "category": "config"},
    {
        "id": "A.7.14",
        "name": "Secure Disposal or Re-Use of Equipment",
        "category": "data",
    },
    # A.8 — Technological Controls (34 controls)
    {"id": "A.8.1", "name": "User Endpoint Devices", "category": "config"},
    {"id": "A.8.2", "name": "Privileged Access Rights", "category": "access"},
    {"id": "A.8.3", "name": "Information Access Restriction", "category": "access"},
    {"id": "A.8.4", "name": "Access to Source Code", "category": "code"},
    {"id": "A.8.5", "name": "Secure Authentication", "category": "auth"},
    {"id": "A.8.6", "name": "Capacity Management", "category": "config"},
    {"id": "A.8.7", "name": "Protection Against Malware", "category": "malware"},
    {
        "id": "A.8.8",
        "name": "Management of Technical Vulnerabilities",
        "category": "vuln",
    },
    {"id": "A.8.9", "name": "Configuration Management", "category": "config"},
    {"id": "A.8.10", "name": "Information Deletion", "category": "data"},
    {"id": "A.8.11", "name": "Data Masking", "category": "data"},
    {"id": "A.8.12", "name": "Data Leakage Prevention", "category": "data"},
    {"id": "A.8.13", "name": "Information Backup", "category": "recovery"},
    {
        "id": "A.8.14",
        "name": "Redundancy of Information Processing Facilities",
        "category": "recovery",
    },
    {"id": "A.8.15", "name": "Logging", "category": "logging"},
    {"id": "A.8.16", "name": "Monitoring Activities", "category": "monitoring"},
    {"id": "A.8.17", "name": "Clock Synchronization", "category": "logging"},
    {
        "id": "A.8.18",
        "name": "Use of Privileged Utility Programs",
        "category": "access",
    },
    {
        "id": "A.8.19",
        "name": "Installation of Software on Operational Systems",
        "category": "config",
    },
    {"id": "A.8.20", "name": "Networks Security", "category": "network"},
    {"id": "A.8.21", "name": "Security of Network Services", "category": "network"},
    {"id": "A.8.22", "name": "Segregation of Networks", "category": "network"},
    {"id": "A.8.23", "name": "Web Filtering", "category": "network"},
    {"id": "A.8.24", "name": "Use of Cryptography", "category": "crypto"},
    {"id": "A.8.25", "name": "Secure Development Life Cycle", "category": "code"},
    {"id": "A.8.26", "name": "Application Security Requirements", "category": "code"},
    {
        "id": "A.8.27",
        "name": "Secure System Architecture and Engineering Principles",
        "category": "code",
    },
    {"id": "A.8.28", "name": "Secure Coding", "category": "code"},
    {
        "id": "A.8.29",
        "name": "Security Testing in Development and Acceptance",
        "category": "testing",
    },
    {"id": "A.8.30", "name": "Outsourced Development", "category": "code"},
    {
        "id": "A.8.31",
        "name": "Separation of Development, Test and Production Environments",
        "category": "config",
    },
    {"id": "A.8.32", "name": "Change Management", "category": "config"},
    {"id": "A.8.33", "name": "Test Information", "category": "data"},
    {
        "id": "A.8.34",
        "name": "Protection of Information Systems During Audit Testing",
        "category": "testing",
    },
]

_GDPR_CONTROLS: list[dict[str, str]] = [
    {"id": "GDPR-Art.5", "name": "Principles of Data Processing", "category": "data"},
    {"id": "GDPR-Art.6", "name": "Lawfulness of Processing", "category": "governance"},
    {"id": "GDPR-Art.7", "name": "Conditions for Consent", "category": "governance"},
    {
        "id": "GDPR-Art.13",
        "name": "Information to Data Subjects (Collection)",
        "category": "data",
    },
    {
        "id": "GDPR-Art.15",
        "name": "Right of Access by the Data Subject",
        "category": "access",
    },
    {
        "id": "GDPR-Art.17",
        "name": "Right to Erasure (Right to be Forgotten)",
        "category": "data",
    },
    {"id": "GDPR-Art.20", "name": "Right to Data Portability", "category": "data"},
    {
        "id": "GDPR-Art.25",
        "name": "Data Protection by Design and by Default",
        "category": "data",
    },
    {
        "id": "GDPR-Art.30",
        "name": "Records of Processing Activities",
        "category": "governance",
    },
    {"id": "GDPR-Art.32", "name": "Security of Processing", "category": "crypto"},
    {
        "id": "GDPR-Art.33",
        "name": "Notification of Breach to Supervisory Authority",
        "category": "incident",
    },
    {
        "id": "GDPR-Art.35",
        "name": "Data Protection Impact Assessment",
        "category": "risk",
    },
    {
        "id": "GDPR-Art.37",
        "name": "Designation of Data Protection Officer",
        "category": "governance",
    },
]

# --- Added in audit v1.0: 11 new frameworks ---

_CMMC_CONTROLS: list[dict[str, str]] = [
    {"id": "AC.L1-3.1.1", "name": "Authorized Access Control", "category": "access"},
    {
        "id": "AC.L1-3.1.2",
        "name": "Transaction & Function Control",
        "category": "access",
    },
    {"id": "AC.L2-3.1.3", "name": "CUI Flow Enforcement", "category": "data"},
    {"id": "AC.L2-3.1.5", "name": "Least Privilege", "category": "access"},
    {"id": "AC.L2-3.1.7", "name": "Privileged Functions", "category": "access"},
    {"id": "AU.L2-3.3.1", "name": "System-Level Auditing", "category": "logging"},
    {"id": "AU.L2-3.3.2", "name": "User Accountability", "category": "logging"},
    {"id": "CM.L2-3.4.1", "name": "System Baselining", "category": "config"},
    {
        "id": "CM.L2-3.4.2",
        "name": "Security Configuration Enforcement",
        "category": "config",
    },
    {"id": "IA.L1-3.5.1", "name": "Identification", "category": "auth"},
    {"id": "IA.L1-3.5.2", "name": "Authentication", "category": "auth"},
    {"id": "IA.L2-3.5.3", "name": "Multi-Factor Authentication", "category": "auth"},
    {"id": "IR.L2-3.6.1", "name": "Incident Handling", "category": "incident"},
    {"id": "IR.L2-3.6.2", "name": "Incident Reporting", "category": "incident"},
    {"id": "MA.L2-3.7.1", "name": "Maintenance Performance", "category": "config"},
    {"id": "MP.L1-3.8.3", "name": "Media Disposal", "category": "data"},
    {
        "id": "PE.L1-3.10.1",
        "name": "Physical Access Limitation",
        "category": "physical",
    },
    {"id": "RA.L2-3.11.1", "name": "Risk Assessments", "category": "risk"},
    {"id": "RA.L2-3.11.2", "name": "Vulnerability Scanning", "category": "vuln"},
    {"id": "SC.L1-3.13.1", "name": "Boundary Protection", "category": "network"},
    {
        "id": "SC.L2-3.13.6",
        "name": "Network Communication by Exception",
        "category": "network",
    },
    {"id": "SC.L2-3.13.11", "name": "CUI Encryption", "category": "crypto"},
    {"id": "SI.L1-3.14.1", "name": "Flaw Remediation", "category": "vuln"},
    {
        "id": "SI.L2-3.14.3",
        "name": "Security Alerts & Advisories",
        "category": "monitoring",
    },
]

_NIST_CSF_CONTROLS: list[dict[str, str]] = [
    {"id": "GV.OC-01", "name": "Organizational Context", "category": "governance"},
    {"id": "GV.RM-01", "name": "Risk Management Strategy", "category": "risk"},
    {
        "id": "GV.RR-01",
        "name": "Roles, Responsibilities, and Authorities",
        "category": "governance",
    },
    {"id": "GV.PO-01", "name": "Policy Establishment", "category": "governance"},
    {
        "id": "GV.SC-01",
        "name": "Supply Chain Risk Management Strategy",
        "category": "governance",
    },
    {"id": "ID.AM-01", "name": "Asset Inventory", "category": "inventory"},
    {"id": "ID.AM-02", "name": "Software Inventory", "category": "inventory"},
    {"id": "ID.RA-01", "name": "Vulnerability Identification", "category": "vuln"},
    {"id": "ID.RA-02", "name": "Threat Intelligence", "category": "monitoring"},
    {"id": "ID.RA-03", "name": "Risk Assessment", "category": "risk"},
    {"id": "ID.IM-01", "name": "Improvement Integration", "category": "governance"},
    {
        "id": "PR.AA-01",
        "name": "Identity Management and Authentication",
        "category": "auth",
    },
    {"id": "PR.AA-02", "name": "Access Control", "category": "access"},
    {"id": "PR.AT-01", "name": "Awareness and Training", "category": "training"},
    {"id": "PR.DS-01", "name": "Data-at-Rest Protection", "category": "crypto"},
    {"id": "PR.DS-02", "name": "Data-in-Transit Protection", "category": "crypto"},
    {"id": "PR.PS-01", "name": "Configuration Management", "category": "config"},
    {"id": "PR.IR-01", "name": "Infrastructure Resilience", "category": "recovery"},
    {
        "id": "DE.CM-01",
        "name": "Continuous Monitoring — Networks",
        "category": "monitoring",
    },
    {
        "id": "DE.CM-02",
        "name": "Continuous Monitoring — Physical",
        "category": "monitoring",
    },
    {"id": "DE.AE-01", "name": "Adverse Event Analysis", "category": "monitoring"},
    {"id": "RS.MA-01", "name": "Incident Management", "category": "incident"},
    {"id": "RS.AN-01", "name": "Incident Analysis", "category": "incident"},
    {"id": "RS.CO-01", "name": "Incident Reporting", "category": "incident"},
    {"id": "RS.MI-01", "name": "Incident Mitigation", "category": "incident"},
    {"id": "RC.RP-01", "name": "Recovery Plan Execution", "category": "recovery"},
    {"id": "RC.CO-01", "name": "Recovery Communication", "category": "recovery"},
]

_NIST_AI_RMF_CONTROLS: list[dict[str, str]] = [
    {
        "id": "GOVERN-1",
        "name": "AI Risk Management Governance",
        "category": "governance",
    },
    {"id": "GOVERN-2", "name": "AI Accountability Structure", "category": "governance"},
    {
        "id": "GOVERN-3",
        "name": "AI Workforce Diversity and Culture",
        "category": "governance",
    },
    {"id": "GOVERN-4", "name": "Organizational AI Risk Tolerance", "category": "risk"},
    {
        "id": "GOVERN-5",
        "name": "AI Legal and Regulatory Compliance",
        "category": "governance",
    },
    {
        "id": "GOVERN-6",
        "name": "AI Supply Chain Risk Management",
        "category": "governance",
    },
    {"id": "MAP-1", "name": "AI Context and Intended Use", "category": "governance"},
    {"id": "MAP-2", "name": "AI Stakeholder Identification", "category": "governance"},
    {"id": "MAP-3", "name": "AI Benefits and Costs Assessment", "category": "risk"},
    {"id": "MAP-5", "name": "AI Impact Assessment", "category": "risk"},
    {"id": "MEASURE-1", "name": "AI Risk Metrics", "category": "monitoring"},
    {"id": "MEASURE-2", "name": "AI System Evaluation", "category": "testing"},
    {
        "id": "MEASURE-3",
        "name": "AI Bias and Fairness Assessment",
        "category": "testing",
    },
    {"id": "MEASURE-4", "name": "AI Model Monitoring", "category": "monitoring"},
    {"id": "MANAGE-1", "name": "AI Risk Treatment", "category": "risk"},
    {"id": "MANAGE-2", "name": "AI Risk Prioritization", "category": "risk"},
    {"id": "MANAGE-3", "name": "AI Incident Response", "category": "incident"},
    {
        "id": "MANAGE-4",
        "name": "AI Third-Party Risk Management",
        "category": "governance",
    },
]

_FEDRAMP_CONTROLS: list[dict[str, str]] = [
    {
        "id": "FedRAMP-AC-2",
        "name": "Account Management (FedRAMP Enhanced)",
        "category": "access",
    },
    {
        "id": "FedRAMP-AC-6",
        "name": "Least Privilege (FedRAMP Enhanced)",
        "category": "access",
    },
    {
        "id": "FedRAMP-AU-2",
        "name": "Audit Events (FedRAMP Enhanced)",
        "category": "logging",
    },
    {
        "id": "FedRAMP-AU-6",
        "name": "Audit Review and Analysis (FedRAMP Enhanced)",
        "category": "monitoring",
    },
    {"id": "FedRAMP-CA-7", "name": "Continuous Monitoring", "category": "monitoring"},
    {
        "id": "FedRAMP-CM-2",
        "name": "Baseline Configuration (FedRAMP Enhanced)",
        "category": "config",
    },
    {
        "id": "FedRAMP-CM-6",
        "name": "Configuration Settings (FedRAMP Enhanced)",
        "category": "config",
    },
    {
        "id": "FedRAMP-IA-2",
        "name": "Identification and Authentication (FedRAMP Enhanced)",
        "category": "auth",
    },
    {
        "id": "FedRAMP-IA-5",
        "name": "Authenticator Management (FedRAMP Enhanced)",
        "category": "auth",
    },
    {
        "id": "FedRAMP-IR-4",
        "name": "Incident Handling (FedRAMP Enhanced)",
        "category": "incident",
    },
    {
        "id": "FedRAMP-IR-6",
        "name": "Incident Reporting (FedRAMP)",
        "category": "incident",
    },
    {
        "id": "FedRAMP-RA-5",
        "name": "Vulnerability Scanning (FedRAMP Enhanced)",
        "category": "vuln",
    },
    {
        "id": "FedRAMP-SC-7",
        "name": "Boundary Protection (FedRAMP Enhanced)",
        "category": "network",
    },
    {
        "id": "FedRAMP-SC-8",
        "name": "Transmission Confidentiality (FedRAMP Enhanced)",
        "category": "crypto",
    },
    {
        "id": "FedRAMP-SC-12",
        "name": "Cryptographic Key Management (FedRAMP Enhanced)",
        "category": "crypto",
    },
    {
        "id": "FedRAMP-SC-28",
        "name": "Protection of Information at Rest",
        "category": "crypto",
    },
    {
        "id": "FedRAMP-SI-2",
        "name": "Flaw Remediation (FedRAMP Enhanced)",
        "category": "vuln",
    },
    {
        "id": "FedRAMP-SI-4",
        "name": "Information System Monitoring (FedRAMP Enhanced)",
        "category": "monitoring",
    },
    {
        "id": "FedRAMP-PE-3",
        "name": "Physical Access Control (FedRAMP)",
        "category": "physical",
    },
    {
        "id": "FedRAMP-PL-2",
        "name": "System Security Plan (FedRAMP)",
        "category": "governance",
    },
]

_OWASP_TOP_10_CONTROLS: list[dict[str, str]] = [
    {"id": "A01:2021", "name": "Broken Access Control", "category": "access"},
    {"id": "A02:2021", "name": "Cryptographic Failures", "category": "crypto"},
    {"id": "A03:2021", "name": "Injection", "category": "injection"},
    {"id": "A04:2021", "name": "Insecure Design", "category": "code"},
    {"id": "A05:2021", "name": "Security Misconfiguration", "category": "config"},
    {
        "id": "A06:2021",
        "name": "Vulnerable and Outdated Components",
        "category": "vuln",
    },
    {
        "id": "A07:2021",
        "name": "Identification and Authentication Failures",
        "category": "auth",
    },
    {
        "id": "A08:2021",
        "name": "Software and Data Integrity Failures",
        "category": "code",
    },
    {
        "id": "A09:2021",
        "name": "Security Logging and Monitoring Failures",
        "category": "logging",
    },
    {
        "id": "A10:2021",
        "name": "Server-Side Request Forgery (SSRF)",
        "category": "network",
    },
    {
        "id": "API1:2023",
        "name": "Broken Object Level Authorization",
        "category": "access",
    },
    {"id": "API2:2023", "name": "Broken Authentication", "category": "auth"},
    {
        "id": "API3:2023",
        "name": "Broken Object Property Level Authorization",
        "category": "access",
    },
    {
        "id": "API4:2023",
        "name": "Unrestricted Resource Consumption",
        "category": "network",
    },
    {
        "id": "API5:2023",
        "name": "Broken Function Level Authorization",
        "category": "access",
    },
    {
        "id": "API6:2023",
        "name": "Unrestricted Access to Sensitive Business Flows",
        "category": "access",
    },
    {"id": "API7:2023", "name": "Server Side Request Forgery", "category": "network"},
    {"id": "API8:2023", "name": "Security Misconfiguration", "category": "config"},
    {
        "id": "API9:2023",
        "name": "Improper Inventory Management",
        "category": "inventory",
    },
    {"id": "API10:2023", "name": "Unsafe Consumption of APIs", "category": "code"},
    {"id": "LLM01:2025", "name": "Prompt Injection", "category": "injection"},
    {"id": "LLM02:2025", "name": "Insecure Output Handling", "category": "code"},
    {"id": "LLM03:2025", "name": "Training Data Poisoning", "category": "data"},
    {"id": "LLM04:2025", "name": "Model Denial of Service", "category": "network"},
    {"id": "LLM05:2025", "name": "Supply Chain Vulnerabilities", "category": "code"},
    {
        "id": "LLM06:2025",
        "name": "Sensitive Information Disclosure",
        "category": "data",
    },
    {"id": "LLM07:2025", "name": "Insecure Plugin Design", "category": "code"},
    {"id": "LLM08:2025", "name": "Excessive Agency", "category": "access"},
    {"id": "LLM09:2025", "name": "Overreliance", "category": "governance"},
    {"id": "LLM10:2025", "name": "Model Theft", "category": "data"},
]

_MITRE_ATTACK_CONTROLS: list[dict[str, str]] = [
    {"id": "TA0043", "name": "Reconnaissance", "category": "monitoring"},
    {"id": "TA0042", "name": "Resource Development", "category": "monitoring"},
    {"id": "TA0001", "name": "Initial Access", "category": "network"},
    {"id": "TA0002", "name": "Execution", "category": "malware"},
    {"id": "TA0003", "name": "Persistence", "category": "config"},
    {"id": "TA0004", "name": "Privilege Escalation", "category": "access"},
    {"id": "TA0005", "name": "Defense Evasion", "category": "monitoring"},
    {"id": "TA0006", "name": "Credential Access", "category": "auth"},
    {"id": "TA0007", "name": "Discovery", "category": "monitoring"},
    {"id": "TA0008", "name": "Lateral Movement", "category": "network"},
    {"id": "TA0009", "name": "Collection", "category": "data"},
    {"id": "TA0011", "name": "Command and Control", "category": "network"},
    {"id": "TA0010", "name": "Exfiltration", "category": "data"},
    {"id": "TA0040", "name": "Impact", "category": "recovery"},
]

_IEC_62443_CONTROLS: list[dict[str, str]] = [
    {
        "id": "SR-1.1",
        "name": "Human User Identification and Authentication",
        "category": "auth",
    },
    {
        "id": "SR-1.2",
        "name": "Software Process and Device Identification",
        "category": "auth",
    },
    {"id": "SR-1.3", "name": "Account Management", "category": "access"},
    {
        "id": "SR-1.7",
        "name": "Strength of Password-Based Authentication",
        "category": "auth",
    },
    {"id": "SR-2.1", "name": "Authorization Enforcement", "category": "access"},
    {"id": "SR-2.4", "name": "Mobile Code", "category": "code"},
    {"id": "SR-2.8", "name": "Auditable Events", "category": "logging"},
    {"id": "SR-2.9", "name": "Audit Storage Capacity", "category": "logging"},
    {"id": "SR-3.1", "name": "Communication Integrity", "category": "crypto"},
    {"id": "SR-3.4", "name": "Software and Information Integrity", "category": "code"},
    {"id": "SR-3.5", "name": "Input Validation", "category": "code"},
    {"id": "SR-4.1", "name": "Information Confidentiality", "category": "crypto"},
    {"id": "SR-5.1", "name": "Network Segmentation", "category": "network"},
    {"id": "SR-5.2", "name": "Zone Boundary Protection", "category": "network"},
    {"id": "SR-6.1", "name": "Audit Log Accessibility", "category": "logging"},
    {"id": "SR-6.2", "name": "Continuous Monitoring", "category": "monitoring"},
    {"id": "SR-7.1", "name": "Denial of Service Protection", "category": "network"},
    {
        "id": "SR-7.6",
        "name": "Network and Security Configuration Settings",
        "category": "config",
    },
]

_NIS2_CONTROLS: list[dict[str, str]] = [
    {
        "id": "NIS2-Art.21(a)",
        "name": "Risk Analysis and Information System Security Policies",
        "category": "governance",
    },
    {"id": "NIS2-Art.21(b)", "name": "Incident Handling", "category": "incident"},
    {
        "id": "NIS2-Art.21(c)",
        "name": "Business Continuity and Crisis Management",
        "category": "recovery",
    },
    {"id": "NIS2-Art.21(d)", "name": "Supply Chain Security", "category": "governance"},
    {
        "id": "NIS2-Art.21(e)",
        "name": "Security in Network and Information Systems Acquisition",
        "category": "code",
    },
    {
        "id": "NIS2-Art.21(f)",
        "name": "Vulnerability Handling and Disclosure",
        "category": "vuln",
    },
    {
        "id": "NIS2-Art.21(g)",
        "name": "Assessment of Cybersecurity Risk-Management Measures",
        "category": "risk",
    },
    {
        "id": "NIS2-Art.21(h)",
        "name": "Basic Cyber Hygiene Practices and Training",
        "category": "training",
    },
    {
        "id": "NIS2-Art.21(i)",
        "name": "Cryptography and Encryption",
        "category": "crypto",
    },
    {
        "id": "NIS2-Art.21(j)",
        "name": "Human Resource Security and Access Control",
        "category": "access",
    },
    {
        "id": "NIS2-Art.23(1)",
        "name": "Incident Notification to Authorities (24h)",
        "category": "incident",
    },
    {
        "id": "NIS2-Art.23(4)",
        "name": "Final Incident Report (1 month)",
        "category": "incident",
    },
]

_DORA_CONTROLS: list[dict[str, str]] = [
    {
        "id": "DORA-Art.5",
        "name": "ICT Risk Management Framework",
        "category": "governance",
    },
    {
        "id": "DORA-Art.6",
        "name": "ICT Systems, Protocols and Tools",
        "category": "config",
    },
    {"id": "DORA-Art.7", "name": "Identification of ICT Risk", "category": "risk"},
    {"id": "DORA-Art.8", "name": "Protection and Prevention", "category": "network"},
    {"id": "DORA-Art.9", "name": "Detection", "category": "monitoring"},
    {"id": "DORA-Art.10", "name": "Response and Recovery", "category": "incident"},
    {
        "id": "DORA-Art.11",
        "name": "Backup Policies and Recovery",
        "category": "recovery",
    },
    {"id": "DORA-Art.12", "name": "Learning and Evolving", "category": "governance"},
    {"id": "DORA-Art.13", "name": "Communication", "category": "incident"},
    {
        "id": "DORA-Art.17",
        "name": "ICT-Related Incident Management Process",
        "category": "incident",
    },
    {
        "id": "DORA-Art.19",
        "name": "Incident Reporting to Authorities",
        "category": "incident",
    },
    {
        "id": "DORA-Art.24",
        "name": "Digital Operational Resilience Testing",
        "category": "testing",
    },
    {
        "id": "DORA-Art.25",
        "name": "Threat-Led Penetration Testing (TLPT)",
        "category": "testing",
    },
    {
        "id": "DORA-Art.28",
        "name": "Third-Party ICT Risk Management",
        "category": "governance",
    },
]

_CISA_KEV_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CISA-BOD-22-01",
        "name": "Known Exploited Vulnerability Remediation",
        "category": "vuln",
    },
    {
        "id": "CISA-BOD-23-01",
        "name": "Asset Visibility and Vulnerability Detection",
        "category": "inventory",
    },
    {
        "id": "CISA-BOD-25-01",
        "name": "Secure Cloud Configuration",
        "category": "config",
    },
    {
        "id": "CISA-ED-24-01",
        "name": "Emergency Mitigation of Critical Vulnerabilities",
        "category": "vuln",
    },
    {
        "id": "CISA-CPG-1",
        "name": "MFA for Remote and Privileged Access",
        "category": "auth",
    },
    {
        "id": "CISA-CPG-2",
        "name": "No Known Exploited Vulnerabilities",
        "category": "vuln",
    },
    {"id": "CISA-CPG-3", "name": "Strong and Unique Passwords", "category": "auth"},
    {"id": "CISA-CPG-4", "name": "Minimize Attack Surface", "category": "network"},
    {"id": "CISA-CPG-5", "name": "Detect Relevant Threats", "category": "monitoring"},
    {"id": "CISA-CPG-6", "name": "Incident Response Planning", "category": "incident"},
    {"id": "CISA-CPG-7", "name": "Disable Macros by Default", "category": "config"},
    {
        "id": "CISA-CPG-8",
        "name": "Log Collection and Monitoring",
        "category": "logging",
    },
]

# --- Added in audit v2.0: 20 new frameworks ---

_EU_AI_ACT_CONTROLS: list[dict[str, str]] = [
    # Title I — General Provisions (Art. 1-4)
    {
        "id": "EUAI-Art.1",
        "name": "Subject Matter — Harmonized Rules for AI",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.2",
        "name": "Scope — Providers, Deployers, and Territorial Application",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.3",
        "name": "Definitions — AI System, Provider, Deployer, etc.",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.4",
        "name": "AI Literacy — Sufficient Knowledge for Staff",
        "category": "training",
    },
    # Title II — Prohibited AI Practices (Art. 5)
    {
        "id": "EUAI-Art.5a",
        "name": "Prohibited: Subliminal Manipulation Techniques",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.5b",
        "name": "Prohibited: Exploitation of Vulnerabilities (Age, Disability)",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.5c",
        "name": "Prohibited: Social Scoring by Public Authorities",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.5d",
        "name": "Prohibited: Real-Time Remote Biometric Identification (except exceptions)",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.5e",
        "name": "Prohibited: Untargeted Facial Image Scraping",
        "category": "data",
    },
    {
        "id": "EUAI-Art.5f",
        "name": "Prohibited: Emotion Inference in Workplace and Education",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.5g",
        "name": "Prohibited: Biometric Categorization (Race, Politics, etc.)",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.5h",
        "name": "Prohibited: Predictive Policing Based Solely on Profiling",
        "category": "risk",
    },
    # Title III — High-Risk AI Systems (Art. 6-49)
    {
        "id": "EUAI-Art.6",
        "name": "Classification Rules for High-Risk AI Systems",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.7",
        "name": "Amendments to Annex III — High-Risk AI List",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.8",
        "name": "Compliance with Requirements for High-Risk AI",
        "category": "testing",
    },
    {"id": "EUAI-Art.9", "name": "Risk Management System", "category": "risk"},
    {"id": "EUAI-Art.10", "name": "Data and Data Governance", "category": "data"},
    {"id": "EUAI-Art.11", "name": "Technical Documentation", "category": "governance"},
    {"id": "EUAI-Art.12", "name": "Record-Keeping and Logging", "category": "logging"},
    {
        "id": "EUAI-Art.13",
        "name": "Transparency and Provision of Information to Deployers",
        "category": "governance",
    },
    {"id": "EUAI-Art.14", "name": "Human Oversight Measures", "category": "governance"},
    {
        "id": "EUAI-Art.15",
        "name": "Accuracy, Robustness and Cybersecurity",
        "category": "testing",
    },
    {
        "id": "EUAI-Art.16",
        "name": "Obligations of Providers of High-Risk AI",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.17",
        "name": "Quality Management System",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.18",
        "name": "Documentation Keeping by Providers",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.19",
        "name": "Automatically Generated Logs Retention",
        "category": "logging",
    },
    {
        "id": "EUAI-Art.20",
        "name": "Corrective Actions and Duty of Information",
        "category": "incident",
    },
    {
        "id": "EUAI-Art.21",
        "name": "Cooperation with Competent Authorities",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.22",
        "name": "Authorized Representatives of Non-EU Providers",
        "category": "governance",
    },
    {"id": "EUAI-Art.23", "name": "Obligations of Importers", "category": "governance"},
    {
        "id": "EUAI-Art.24",
        "name": "Obligations of Distributors",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.25",
        "name": "Responsibilities Along the AI Value Chain",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.26",
        "name": "Obligations of Deployers of High-Risk AI",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.27",
        "name": "Fundamental Rights Impact Assessment for High-Risk AI",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.40",
        "name": "Harmonized Standards and Presumption of Conformity",
        "category": "testing",
    },
    {"id": "EUAI-Art.41", "name": "Common Specifications", "category": "testing"},
    {
        "id": "EUAI-Art.43",
        "name": "Conformity Assessment for High-Risk AI",
        "category": "testing",
    },
    {
        "id": "EUAI-Art.44",
        "name": "Certificates Issued by Notified Bodies",
        "category": "testing",
    },
    {
        "id": "EUAI-Art.47",
        "name": "EU Declaration of Conformity",
        "category": "governance",
    },
    {"id": "EUAI-Art.48", "name": "CE Marking of Conformity", "category": "governance"},
    {
        "id": "EUAI-Art.49",
        "name": "Registration in EU Database",
        "category": "governance",
    },
    # Title IV — Transparency (Art. 50)
    {
        "id": "EUAI-Art.50a",
        "name": "Transparency: AI-Generated Content Disclosure",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.50b",
        "name": "Transparency: Deepfake Labeling Requirement",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.50c",
        "name": "Transparency: Emotion Recognition System Disclosure",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.50d",
        "name": "Transparency: Biometric Categorization System Disclosure",
        "category": "governance",
    },
    # Title V — General-Purpose AI (Art. 51-56)
    {
        "id": "EUAI-Art.51",
        "name": "Classification of GPAI Models with Systemic Risk",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.52",
        "name": "Obligations for All GPAI Model Providers",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.53",
        "name": "Technical Documentation for GPAI Models",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.54",
        "name": "Copyright Policy and Training Data Summary for GPAI",
        "category": "data",
    },
    {
        "id": "EUAI-Art.55",
        "name": "Additional Obligations for GPAI with Systemic Risk",
        "category": "risk",
    },
    {
        "id": "EUAI-Art.56",
        "name": "Codes of Practice for GPAI Providers",
        "category": "governance",
    },
    # Title VIII — Post-Market Monitoring (Art. 61-62)
    {
        "id": "EUAI-Art.61",
        "name": "Post-Market Monitoring System by Providers",
        "category": "testing",
    },
    {
        "id": "EUAI-Art.62",
        "name": "Reporting of Serious Incidents",
        "category": "incident",
    },
    # Title X — Codes of Conduct (Art. 69)
    {
        "id": "EUAI-Art.69",
        "name": "Codes of Conduct for Non-High-Risk AI",
        "category": "governance",
    },
    # Title XII — Penalties (Art. 71-72)
    {
        "id": "EUAI-Art.71",
        "name": "Fines for Prohibited AI Practices (up to €35M or 7% turnover)",
        "category": "governance",
    },
    {
        "id": "EUAI-Art.72",
        "name": "Fines for Non-Compliance with High-Risk Requirements",
        "category": "governance",
    },
    # Title XIII — Transition (Art. 78, 83, 85)
    {
        "id": "EUAI-Art.78",
        "name": "Confidentiality of Information and Data",
        "category": "data",
    },
    {"id": "EUAI-Art.83", "name": "AI Regulatory Sandboxes", "category": "testing"},
    {
        "id": "EUAI-Art.85",
        "name": "Transitional Provisions — Compliance Timeline",
        "category": "governance",
    },
]

_SWIFT_CSP_CONTROLS: list[dict[str, str]] = [
    {"id": "SWIFT-1.1", "name": "SWIFT Environment Protection", "category": "network"},
    {
        "id": "SWIFT-1.2",
        "name": "Operating System Privileged Account Control",
        "category": "access",
    },
    {
        "id": "SWIFT-1.3",
        "name": "Virtualisation Platform Protection",
        "category": "config",
    },
    {
        "id": "SWIFT-1.4",
        "name": "Restriction of Internet Access",
        "category": "network",
    },
    {"id": "SWIFT-2.1", "name": "Internal Data Flow Security", "category": "crypto"},
    {"id": "SWIFT-2.2", "name": "Security Updates", "category": "vuln"},
    {"id": "SWIFT-2.3", "name": "System Hardening", "category": "config"},
    {
        "id": "SWIFT-2.4A",
        "name": "Back Office Data Flow Security",
        "category": "crypto",
    },
    {
        "id": "SWIFT-2.6",
        "name": "Operator Session Confidentiality and Integrity",
        "category": "crypto",
    },
    {"id": "SWIFT-2.7", "name": "Vulnerability Scanning", "category": "vuln"},
    {
        "id": "SWIFT-2.8A",
        "name": "Critical Activity Outsourcing",
        "category": "governance",
    },
    {
        "id": "SWIFT-2.9A",
        "name": "Transaction Business Controls",
        "category": "monitoring",
    },
    {"id": "SWIFT-3.1", "name": "Physical Security", "category": "physical"},
    {"id": "SWIFT-4.1", "name": "Password Policy", "category": "auth"},
    {"id": "SWIFT-4.2", "name": "Multi-Factor Authentication", "category": "auth"},
    {"id": "SWIFT-5.1", "name": "Logical Access Control", "category": "access"},
    {"id": "SWIFT-5.2", "name": "Token Management", "category": "auth"},
    {
        "id": "SWIFT-5.4",
        "name": "Physical and Logical Password Storage",
        "category": "auth",
    },
    {"id": "SWIFT-6.1", "name": "Malware Protection", "category": "malware"},
    {"id": "SWIFT-6.2", "name": "Software Integrity", "category": "code"},
    {"id": "SWIFT-6.3", "name": "Database Integrity", "category": "data"},
    {"id": "SWIFT-6.4", "name": "Logging and Monitoring", "category": "logging"},
    {"id": "SWIFT-6.5A", "name": "Intrusion Detection", "category": "monitoring"},
    {
        "id": "SWIFT-7.1",
        "name": "Cyber Incident Response Planning",
        "category": "incident",
    },
    {
        "id": "SWIFT-7.2",
        "name": "Security Training and Awareness",
        "category": "training",
    },
    {"id": "SWIFT-7.3A", "name": "Penetration Testing", "category": "testing"},
    {"id": "SWIFT-7.4A", "name": "Scenario-Based Risk Assessment", "category": "risk"},
]

_NIST_800_171_CONTROLS: list[dict[str, str]] = [
    {
        "id": "3.1.1",
        "name": "Limit System Access to Authorized Users",
        "category": "access",
    },
    {
        "id": "3.1.2",
        "name": "Limit System Access to Authorized Functions",
        "category": "access",
    },
    {"id": "3.1.3", "name": "Control CUI Flow", "category": "data"},
    {"id": "3.1.4", "name": "Separate Duties of Individuals", "category": "access"},
    {"id": "3.1.5", "name": "Least Privilege", "category": "access"},
    {"id": "3.1.6", "name": "Use Non-Privileged Accounts", "category": "access"},
    {
        "id": "3.1.7",
        "name": "Prevent Non-Privileged Users from Executing Privileged Functions",
        "category": "access",
    },
    {"id": "3.1.8", "name": "Limit Unsuccessful Logon Attempts", "category": "auth"},
    {
        "id": "3.1.12",
        "name": "Monitor and Control Remote Access Sessions",
        "category": "network",
    },
    {
        "id": "3.1.13",
        "name": "Employ Cryptographic Mechanisms for Remote Access",
        "category": "crypto",
    },
    {
        "id": "3.1.14",
        "name": "Route Remote Access via Managed Access Control Points",
        "category": "network",
    },
    {
        "id": "3.1.20",
        "name": "Verify and Control Connections to External Systems",
        "category": "network",
    },
    {
        "id": "3.1.22",
        "name": "Control CUI Posted or Processed on Publicly Accessible Systems",
        "category": "data",
    },
    {
        "id": "3.3.1",
        "name": "Create and Retain System Audit Logs",
        "category": "logging",
    },
    {
        "id": "3.3.2",
        "name": "Ensure Actions of Individual Users Can Be Traced",
        "category": "logging",
    },
    {
        "id": "3.4.1",
        "name": "Establish and Maintain Baseline Configurations",
        "category": "config",
    },
    {
        "id": "3.4.2",
        "name": "Establish and Enforce Configuration Settings",
        "category": "config",
    },
    {"id": "3.5.1", "name": "Identify System Users and Processes", "category": "auth"},
    {"id": "3.5.2", "name": "Authenticate Users and Processes", "category": "auth"},
    {"id": "3.5.3", "name": "Use Multi-Factor Authentication", "category": "auth"},
    {
        "id": "3.6.1",
        "name": "Establish Incident-Handling Capability",
        "category": "incident",
    },
    {
        "id": "3.6.2",
        "name": "Track, Document, and Report Incidents",
        "category": "incident",
    },
    {
        "id": "3.7.1",
        "name": "Perform Maintenance on Organizational Systems",
        "category": "config",
    },
    {
        "id": "3.8.1",
        "name": "Protect System Media (Paper and Digital)",
        "category": "data",
    },
    {"id": "3.8.3", "name": "Sanitize or Destroy System Media", "category": "data"},
    {
        "id": "3.10.1",
        "name": "Limit Physical Access to Systems",
        "category": "physical",
    },
    {"id": "3.11.1", "name": "Periodically Assess Risk", "category": "risk"},
    {
        "id": "3.11.2",
        "name": "Scan for Vulnerabilities Periodically",
        "category": "vuln",
    },
    {
        "id": "3.12.1",
        "name": "Periodically Assess Security Controls",
        "category": "testing",
    },
    {
        "id": "3.13.1",
        "name": "Monitor and Control Communications at External Boundaries",
        "category": "network",
    },
    {
        "id": "3.13.8",
        "name": "Implement Cryptographic Mechanisms for CUI in Transit",
        "category": "crypto",
    },
    {
        "id": "3.13.11",
        "name": "Employ FIPS-Validated Cryptography for CUI",
        "category": "crypto",
    },
    {
        "id": "3.14.1",
        "name": "Identify, Report, and Correct System Flaws",
        "category": "vuln",
    },
    {
        "id": "3.14.2",
        "name": "Provide Protection from Malicious Code",
        "category": "malware",
    },
    {
        "id": "3.14.3",
        "name": "Monitor System Security Alerts and Advisories",
        "category": "monitoring",
    },
    {
        "id": "3.14.6",
        "name": "Monitor Organizational Systems",
        "category": "monitoring",
    },
    {
        "id": "3.14.7",
        "name": "Identify Unauthorized Use of Systems",
        "category": "monitoring",
    },
]

_ISO_27017_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CLD.6.3.1",
        "name": "Shared Roles and Responsibilities in Cloud",
        "category": "governance",
    },
    {
        "id": "CLD.8.1.5",
        "name": "Removal of Cloud Service Customer Assets",
        "category": "data",
    },
    {
        "id": "CLD.9.5.1",
        "name": "Segregation in Virtual Computing Environments",
        "category": "config",
    },
    {"id": "CLD.9.5.2", "name": "Virtual Machine Hardening", "category": "config"},
    {
        "id": "CLD.12.1.5",
        "name": "Administrator's Operational Security",
        "category": "access",
    },
    {
        "id": "CLD.12.4.5",
        "name": "Monitoring of Cloud Services",
        "category": "monitoring",
    },
    {
        "id": "CLD.13.1.4",
        "name": "Alignment of Security Management for Virtual and Physical Networks",
        "category": "network",
    },
    {
        "id": "ISO27017-A.5.1",
        "name": "Cloud-Specific Policies for Information Security",
        "category": "governance",
    },
    {"id": "ISO27017-A.8.1", "name": "Cloud Asset Inventory", "category": "inventory"},
    {
        "id": "ISO27017-A.9.2",
        "name": "Cloud User Access Management",
        "category": "access",
    },
    {
        "id": "ISO27017-A.10.1",
        "name": "Cryptographic Controls in Cloud",
        "category": "crypto",
    },
    {
        "id": "ISO27017-A.12.4",
        "name": "Cloud Logging and Monitoring",
        "category": "logging",
    },
]

_ISO_27018_CONTROLS: list[dict[str, str]] = [
    {"id": "ISO27018-A.1", "name": "Consent and Choice", "category": "data"},
    {
        "id": "ISO27018-A.2",
        "name": "Purpose Legitimacy and Specification",
        "category": "data",
    },
    {"id": "ISO27018-A.3", "name": "Collection Limitation", "category": "data"},
    {"id": "ISO27018-A.4", "name": "Data Minimization", "category": "data"},
    {
        "id": "ISO27018-A.5",
        "name": "Use, Retention and Disclosure Limitation",
        "category": "data",
    },
    {"id": "ISO27018-A.6", "name": "Accuracy and Quality", "category": "data"},
    {
        "id": "ISO27018-A.7",
        "name": "Openness, Transparency and Notice",
        "category": "governance",
    },
    {
        "id": "ISO27018-A.8",
        "name": "Individual Participation and Access",
        "category": "access",
    },
    {"id": "ISO27018-A.9", "name": "Accountability", "category": "governance"},
    {"id": "ISO27018-A.10", "name": "Information Security", "category": "crypto"},
    {"id": "ISO27018-A.11", "name": "Privacy Compliance", "category": "governance"},
]

_ISO_27701_CONTROLS: list[dict[str, str]] = [
    {"id": "ISO27701-5.2", "name": "PIMS-Specific Policies", "category": "governance"},
    {"id": "ISO27701-5.4", "name": "PII Risk Assessment", "category": "risk"},
    {
        "id": "ISO27701-6.2",
        "name": "Conditions for Collection and Processing",
        "category": "data",
    },
    {
        "id": "ISO27701-6.3",
        "name": "PII Controller Obligations to PII Principals",
        "category": "data",
    },
    {"id": "ISO27701-6.4", "name": "Privacy by Design and Default", "category": "data"},
    {
        "id": "ISO27701-6.5",
        "name": "PII Sharing, Transfer and Disclosure",
        "category": "data",
    },
    {
        "id": "ISO27701-7.2",
        "name": "PII Processor Conditions for Processing",
        "category": "data",
    },
    {
        "id": "ISO27701-7.3",
        "name": "PII Processor Obligations to PII Controllers",
        "category": "governance",
    },
    {
        "id": "ISO27701-7.4",
        "name": "PII Processor Sub-Processor Management",
        "category": "governance",
    },
    {
        "id": "ISO27701-7.5",
        "name": "PII Transfer to Third Countries",
        "category": "data",
    },
    {
        "id": "ISO27701-8.2",
        "name": "Individual Rights Management",
        "category": "access",
    },
    {"id": "ISO27701-8.3", "name": "Data Breach Notification", "category": "incident"},
    {
        "id": "ISO27701-8.4",
        "name": "DPIA (Data Protection Impact Assessment)",
        "category": "risk",
    },
    {
        "id": "ISO27701-8.5",
        "name": "DPO (Data Protection Officer)",
        "category": "governance",
    },
]

_CSA_CCM_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CCM-AIS-01",
        "name": "Application and Interface Security — Application Security",
        "category": "code",
    },
    {
        "id": "CCM-AIS-02",
        "name": "Application and Interface Security — Customer Access Requirements",
        "category": "access",
    },
    {
        "id": "CCM-AAC-01",
        "name": "Audit Assurance and Compliance — Audit Planning",
        "category": "testing",
    },
    {
        "id": "CCM-AAC-02",
        "name": "Audit Assurance and Compliance — Independent Audits",
        "category": "testing",
    },
    {
        "id": "CCM-BCR-01",
        "name": "Business Continuity Management — Business Continuity Planning",
        "category": "recovery",
    },
    {
        "id": "CCM-BCR-02",
        "name": "Business Continuity Management — Business Continuity Testing",
        "category": "testing",
    },
    {
        "id": "CCM-CCC-01",
        "name": "Change Control and Configuration Management — New Development",
        "category": "config",
    },
    {
        "id": "CCM-CCC-02",
        "name": "Change Control and Configuration Management — Outsourced Development",
        "category": "code",
    },
    {
        "id": "CCM-DSP-01",
        "name": "Data Security and Privacy — Security and Privacy Policy",
        "category": "data",
    },
    {
        "id": "CCM-DSP-02",
        "name": "Data Security and Privacy — Secure Disposal",
        "category": "data",
    },
    {
        "id": "CCM-DSP-03",
        "name": "Data Security and Privacy — Data Inventory",
        "category": "inventory",
    },
    {
        "id": "CCM-DSP-04",
        "name": "Data Security and Privacy — Classification",
        "category": "data",
    },
    {
        "id": "CCM-DSP-05",
        "name": "Data Security and Privacy — Data Flow Documentation",
        "category": "data",
    },
    {"id": "CCM-GRC-01", "name": "GRC — Governance Program", "category": "governance"},
    {"id": "CCM-GRC-02", "name": "GRC — Risk Management Program", "category": "risk"},
    {
        "id": "CCM-HRS-01",
        "name": "Human Resources — Background Screening",
        "category": "governance",
    },
    {
        "id": "CCM-IAM-01",
        "name": "Identity and Access Management — User Access Policy",
        "category": "access",
    },
    {
        "id": "CCM-IAM-02",
        "name": "Identity and Access Management — Strong Authentication",
        "category": "auth",
    },
    {
        "id": "CCM-IVS-01",
        "name": "Infrastructure and Virtualisation Security — Audit Logging",
        "category": "logging",
    },
    {
        "id": "CCM-IVS-02",
        "name": "Infrastructure and Virtualisation Security — Change Detection",
        "category": "monitoring",
    },
    {
        "id": "CCM-IVS-03",
        "name": "Infrastructure and Virtualisation Security — Network Security",
        "category": "network",
    },
    {
        "id": "CCM-LOG-01",
        "name": "Logging and Monitoring — Logging and Monitoring Policy",
        "category": "logging",
    },
    {
        "id": "CCM-LOG-02",
        "name": "Logging and Monitoring — SIEM",
        "category": "monitoring",
    },
    {
        "id": "CCM-SEF-01",
        "name": "Security Incident Management — Incident Management Policy",
        "category": "incident",
    },
    {
        "id": "CCM-SEF-02",
        "name": "Security Incident Management — Incident Response Plan",
        "category": "incident",
    },
    {
        "id": "CCM-STA-01",
        "name": "Supply Chain — Supply Chain Governance",
        "category": "governance",
    },
    {
        "id": "CCM-TVM-01",
        "name": "Threat and Vulnerability Management — Vulnerability Management Policy",
        "category": "vuln",
    },
    {
        "id": "CCM-TVM-02",
        "name": "Threat and Vulnerability Management — Vulnerability Scanning",
        "category": "vuln",
    },
    {
        "id": "CCM-UEM-01",
        "name": "Universal Endpoint Management — Endpoint Policy",
        "category": "config",
    },
]

_NERC_CIP_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CIP-002-6",
        "name": "BES Cyber System Categorization",
        "category": "inventory",
    },
    {
        "id": "CIP-003-8",
        "name": "Security Management Controls",
        "category": "governance",
    },
    {"id": "CIP-004-7", "name": "Personnel and Training", "category": "training"},
    {
        "id": "CIP-005-7",
        "name": "Electronic Security Perimeter(s)",
        "category": "network",
    },
    {
        "id": "CIP-006-6",
        "name": "Physical Security of BES Cyber Systems",
        "category": "physical",
    },
    {"id": "CIP-007-6", "name": "System Security Management", "category": "config"},
    {
        "id": "CIP-008-6",
        "name": "Incident Reporting and Response Planning",
        "category": "incident",
    },
    {
        "id": "CIP-009-6",
        "name": "Recovery Plans for BES Cyber Systems",
        "category": "recovery",
    },
    {
        "id": "CIP-010-4",
        "name": "Configuration Change Mgmt and Vulnerability Assessments",
        "category": "config",
    },
    {"id": "CIP-011-3", "name": "Information Protection", "category": "data"},
    {
        "id": "CIP-012-1",
        "name": "Communications between Control Centers",
        "category": "crypto",
    },
    {
        "id": "CIP-013-2",
        "name": "Supply Chain Risk Management",
        "category": "governance",
    },
    {"id": "CIP-014-3", "name": "Physical Security", "category": "physical"},
]

_HITRUST_CSF_CONTROLS: list[dict[str, str]] = [
    {"id": "HITRUST-01.a", "name": "Access Control Policy", "category": "access"},
    {"id": "HITRUST-01.b", "name": "User Registration", "category": "access"},
    {"id": "HITRUST-01.d", "name": "User Password Management", "category": "auth"},
    {"id": "HITRUST-01.j", "name": "On-Demand Access Control", "category": "access"},
    {
        "id": "HITRUST-01.q",
        "name": "User Authentication for External Connections",
        "category": "auth",
    },
    {
        "id": "HITRUST-01.v",
        "name": "Information Access Restriction",
        "category": "access",
    },
    {"id": "HITRUST-02.a", "name": "Management of Removable Media", "category": "data"},
    {"id": "HITRUST-02.d", "name": "Physical Entry Controls", "category": "physical"},
    {"id": "HITRUST-03.a", "name": "Risk Management Program", "category": "risk"},
    {"id": "HITRUST-03.b", "name": "Performing Risk Assessments", "category": "risk"},
    {
        "id": "HITRUST-04.a",
        "name": "Information Security Policy",
        "category": "governance",
    },
    {
        "id": "HITRUST-05.a",
        "name": "Management Direction for Information Security",
        "category": "governance",
    },
    {
        "id": "HITRUST-06.a",
        "name": "Identification of Applicable Legislation",
        "category": "governance",
    },
    {"id": "HITRUST-06.d", "name": "Data Protection and Privacy", "category": "data"},
    {"id": "HITRUST-07.a", "name": "Inventory of Assets", "category": "inventory"},
    {
        "id": "HITRUST-08.a",
        "name": "Reporting Information Security Events",
        "category": "incident",
    },
    {
        "id": "HITRUST-08.b",
        "name": "Reporting Information Security Weaknesses",
        "category": "incident",
    },
    {
        "id": "HITRUST-09.a",
        "name": "Documented Operating Procedures",
        "category": "config",
    },
    {"id": "HITRUST-09.ab", "name": "Monitoring System Use", "category": "monitoring"},
    {"id": "HITRUST-09.m", "name": "Network Controls", "category": "network"},
    {
        "id": "HITRUST-10.a",
        "name": "Security Requirements Analysis",
        "category": "code",
    },
    {
        "id": "HITRUST-10.h",
        "name": "Control of Technical Vulnerabilities",
        "category": "vuln",
    },
    {
        "id": "HITRUST-11.a",
        "name": "Reporting Information Security Events",
        "category": "incident",
    },
    {
        "id": "HITRUST-11.c",
        "name": "Responsibilities and Procedures",
        "category": "incident",
    },
]

_CIS_CLOUD_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CIS-AWS-1",
        "name": "Identity and Access Management (AWS)",
        "category": "access",
    },
    {"id": "CIS-AWS-2", "name": "Storage (S3/EBS)", "category": "data"},
    {
        "id": "CIS-AWS-3",
        "name": "Logging (CloudTrail/CloudWatch)",
        "category": "logging",
    },
    {
        "id": "CIS-AWS-4",
        "name": "Monitoring (GuardDuty/Config)",
        "category": "monitoring",
    },
    {"id": "CIS-AWS-5", "name": "Networking (VPC/SG/NACLs)", "category": "network"},
    {
        "id": "CIS-AZURE-1",
        "name": "Identity and Access Management (Azure)",
        "category": "access",
    },
    {
        "id": "CIS-AZURE-2",
        "name": "Microsoft Defender for Cloud",
        "category": "monitoring",
    },
    {"id": "CIS-AZURE-3", "name": "Storage Accounts (Azure)", "category": "data"},
    {"id": "CIS-AZURE-4", "name": "Database Services (Azure)", "category": "data"},
    {
        "id": "CIS-AZURE-5",
        "name": "Logging and Monitoring (Azure)",
        "category": "logging",
    },
    {"id": "CIS-AZURE-6", "name": "Networking (Azure)", "category": "network"},
    {
        "id": "CIS-GCP-1",
        "name": "Identity and Access Management (GCP)",
        "category": "access",
    },
    {"id": "CIS-GCP-2", "name": "Logging and Monitoring (GCP)", "category": "logging"},
    {"id": "CIS-GCP-3", "name": "Networking (GCP)", "category": "network"},
    {"id": "CIS-GCP-4", "name": "Virtual Machines (GCP)", "category": "config"},
    {"id": "CIS-GCP-5", "name": "Storage (GCP)", "category": "data"},
    {"id": "CIS-GCP-6", "name": "Cloud SQL (GCP)", "category": "data"},
    {"id": "CIS-K8S-1", "name": "Control Plane Components", "category": "config"},
    {"id": "CIS-K8S-2", "name": "etcd", "category": "config"},
    {"id": "CIS-K8S-3", "name": "Control Plane Configuration", "category": "config"},
    {"id": "CIS-K8S-4", "name": "Worker Nodes", "category": "config"},
    {"id": "CIS-K8S-5", "name": "Policies", "category": "access"},
]

_NIST_800_82_CONTROLS: list[dict[str, str]] = [
    {"id": "800-82-3.1", "name": "ICS Risk Management", "category": "risk"},
    {"id": "800-82-3.2", "name": "ICS Security Architecture", "category": "network"},
    {"id": "800-82-4.1", "name": "ICS Network Segmentation", "category": "network"},
    {"id": "800-82-4.2", "name": "ICS Firewall Configuration", "category": "network"},
    {"id": "800-82-4.3", "name": "ICS DMZ Architecture", "category": "network"},
    {"id": "800-82-5.1", "name": "ICS Access Control", "category": "access"},
    {"id": "800-82-5.2", "name": "ICS Authentication", "category": "auth"},
    {
        "id": "800-82-6.1",
        "name": "ICS Monitoring and Logging",
        "category": "monitoring",
    },
    {"id": "800-82-6.2", "name": "ICS Incident Response", "category": "incident"},
    {"id": "800-82-7.1", "name": "ICS Patch Management", "category": "vuln"},
    {"id": "800-82-7.2", "name": "ICS System Hardening", "category": "config"},
    {"id": "800-82-8.1", "name": "ICS Physical Security", "category": "physical"},
    {"id": "800-82-8.2", "name": "ICS Media Protection", "category": "data"},
]

_OWASP_MASVS_CONTROLS: list[dict[str, str]] = [
    {"id": "MASVS-STORAGE-1", "name": "Secure Data Storage", "category": "data"},
    {"id": "MASVS-STORAGE-2", "name": "Prevention of Data Leakage", "category": "data"},
    {
        "id": "MASVS-CRYPTO-1",
        "name": "Use of Proven Cryptography",
        "category": "crypto",
    },
    {
        "id": "MASVS-CRYPTO-2",
        "name": "Cryptographic Key Management",
        "category": "crypto",
    },
    {
        "id": "MASVS-AUTH-1",
        "name": "Authentication and Session Management",
        "category": "auth",
    },
    {"id": "MASVS-AUTH-2", "name": "Biometric Authentication", "category": "auth"},
    {
        "id": "MASVS-NETWORK-1",
        "name": "Secure Network Communication",
        "category": "crypto",
    },
    {"id": "MASVS-NETWORK-2", "name": "Certificate Pinning", "category": "crypto"},
    {
        "id": "MASVS-PLATFORM-1",
        "name": "Platform Interaction Security",
        "category": "code",
    },
    {"id": "MASVS-PLATFORM-2", "name": "WebView Security", "category": "code"},
    {"id": "MASVS-PLATFORM-3", "name": "Deep Link Validation", "category": "code"},
    {"id": "MASVS-CODE-1", "name": "Secure Coding Practices", "category": "code"},
    {
        "id": "MASVS-CODE-2",
        "name": "Code Integrity and Tampering Detection",
        "category": "code",
    },
    {"id": "MASVS-CODE-3", "name": "Anti-Reverse Engineering", "category": "code"},
    {
        "id": "MASVS-RESILIENCE-1",
        "name": "Runtime Integrity Checks",
        "category": "code",
    },
    {
        "id": "MASVS-RESILIENCE-2",
        "name": "Device Integrity Verification",
        "category": "config",
    },
    {
        "id": "MASVS-PRIVACY-1",
        "name": "Minimization of PII Collection",
        "category": "data",
    },
    {
        "id": "MASVS-PRIVACY-2",
        "name": "User Consent and Transparency",
        "category": "data",
    },
]

_SANS_TOP_25_CONTROLS: list[dict[str, str]] = [
    {"id": "CWE-787", "name": "Out-of-bounds Write", "category": "code"},
    {
        "id": "CWE-79",
        "name": "Improper Neutralization of Input During Web Page Generation (XSS)",
        "category": "injection",
    },
    {"id": "CWE-89", "name": "SQL Injection", "category": "injection"},
    {"id": "CWE-416", "name": "Use After Free", "category": "code"},
    {"id": "CWE-78", "name": "OS Command Injection", "category": "injection"},
    {"id": "CWE-20", "name": "Improper Input Validation", "category": "code"},
    {"id": "CWE-125", "name": "Out-of-bounds Read", "category": "code"},
    {"id": "CWE-22", "name": "Path Traversal", "category": "injection"},
    {"id": "CWE-352", "name": "Cross-Site Request Forgery (CSRF)", "category": "code"},
    {
        "id": "CWE-434",
        "name": "Unrestricted Upload of File with Dangerous Type",
        "category": "code",
    },
    {"id": "CWE-862", "name": "Missing Authorization", "category": "access"},
    {"id": "CWE-476", "name": "NULL Pointer Dereference", "category": "code"},
    {"id": "CWE-287", "name": "Improper Authentication", "category": "auth"},
    {"id": "CWE-190", "name": "Integer Overflow or Wraparound", "category": "code"},
    {"id": "CWE-502", "name": "Deserialization of Untrusted Data", "category": "code"},
    {"id": "CWE-77", "name": "Command Injection", "category": "injection"},
    {
        "id": "CWE-119",
        "name": "Improper Restriction of Operations within Bounds of Memory Buffer",
        "category": "code",
    },
    {"id": "CWE-798", "name": "Use of Hard-coded Credentials", "category": "auth"},
    {
        "id": "CWE-918",
        "name": "Server-Side Request Forgery (SSRF)",
        "category": "network",
    },
    {
        "id": "CWE-306",
        "name": "Missing Authentication for Critical Function",
        "category": "auth",
    },
    {
        "id": "CWE-362",
        "name": "Concurrent Execution Using Shared Resource (Race Condition)",
        "category": "code",
    },
    {"id": "CWE-269", "name": "Improper Privilege Management", "category": "access"},
    {
        "id": "CWE-94",
        "name": "Improper Control of Generation of Code (Code Injection)",
        "category": "injection",
    },
    {"id": "CWE-863", "name": "Incorrect Authorization", "category": "access"},
    {"id": "CWE-276", "name": "Incorrect Default Permissions", "category": "access"},
]

_PTES_CONTROLS: list[dict[str, str]] = [
    {"id": "PTES-1", "name": "Pre-Engagement Interactions", "category": "governance"},
    {
        "id": "PTES-2.1",
        "name": "Intelligence Gathering — OSINT",
        "category": "monitoring",
    },
    {
        "id": "PTES-2.2",
        "name": "Intelligence Gathering — Footprinting",
        "category": "monitoring",
    },
    {
        "id": "PTES-2.3",
        "name": "Intelligence Gathering — Identification of Protection Mechanisms",
        "category": "monitoring",
    },
    {"id": "PTES-3", "name": "Threat Modeling", "category": "risk"},
    {"id": "PTES-4.1", "name": "Vulnerability Analysis — Testing", "category": "vuln"},
    {
        "id": "PTES-4.2",
        "name": "Vulnerability Analysis — Validation",
        "category": "vuln",
    },
    {
        "id": "PTES-5.1",
        "name": "Exploitation — Precision Strike",
        "category": "testing",
    },
    {
        "id": "PTES-5.2",
        "name": "Exploitation — Customized Exploitation",
        "category": "testing",
    },
    {
        "id": "PTES-6.1",
        "name": "Post-Exploitation — Infrastructure Analysis",
        "category": "testing",
    },
    {"id": "PTES-6.2", "name": "Post-Exploitation — Pillaging", "category": "data"},
    {
        "id": "PTES-6.3",
        "name": "Post-Exploitation — Persistence",
        "category": "testing",
    },
    {"id": "PTES-7", "name": "Reporting", "category": "governance"},
]

_OSSTMM_CONTROLS: list[dict[str, str]] = [
    {"id": "OSSTMM-1", "name": "Human Security Testing", "category": "testing"},
    {"id": "OSSTMM-2", "name": "Physical Security Testing", "category": "physical"},
    {
        "id": "OSSTMM-3",
        "name": "Wireless Communications Testing",
        "category": "network",
    },
    {"id": "OSSTMM-4", "name": "Telecommunications Testing", "category": "network"},
    {"id": "OSSTMM-5", "name": "Data Networks Testing", "category": "network"},
    {"id": "OSSTMM-6", "name": "Compliance Testing", "category": "testing"},
    {"id": "OSSTMM-7", "name": "Process Verification", "category": "governance"},
    {"id": "OSSTMM-8", "name": "Posture Assessment", "category": "risk"},
    {"id": "OSSTMM-9", "name": "Controls Verification", "category": "testing"},
    {
        "id": "OSSTMM-10",
        "name": "Actual Security (rav) Calculation",
        "category": "risk",
    },
]

_SOX_IT_CONTROLS: list[dict[str, str]] = [
    {"id": "SOX-ITGC-1", "name": "Access to Programs and Data", "category": "access"},
    {"id": "SOX-ITGC-2", "name": "Program Changes", "category": "config"},
    {"id": "SOX-ITGC-3", "name": "Program Development", "category": "code"},
    {"id": "SOX-ITGC-4", "name": "Computer Operations", "category": "config"},
    {"id": "SOX-302", "name": "CEO/CFO Certifications", "category": "governance"},
    {
        "id": "SOX-404",
        "name": "Management Assessment of Internal Controls",
        "category": "testing",
    },
    {"id": "SOX-IT-AC-1", "name": "Application Input Controls", "category": "code"},
    {
        "id": "SOX-IT-AC-2",
        "name": "Application Processing Controls",
        "category": "code",
    },
    {"id": "SOX-IT-AC-3", "name": "Application Output Controls", "category": "code"},
    {
        "id": "SOX-IT-AC-4",
        "name": "Segregation of Duties in Applications",
        "category": "access",
    },
    {"id": "SOX-IT-LOG", "name": "IT Audit Logging and Review", "category": "logging"},
    {
        "id": "SOX-IT-BCP",
        "name": "IT Business Continuity Planning",
        "category": "recovery",
    },
]

_COBIT_CONTROLS: list[dict[str, str]] = [
    {
        "id": "COBIT-EDM01",
        "name": "Ensured Governance Framework Setting and Maintenance",
        "category": "governance",
    },
    {"id": "COBIT-EDM03", "name": "Ensured Risk Optimization", "category": "risk"},
    {
        "id": "COBIT-APO01",
        "name": "Managed I&T Management Framework",
        "category": "governance",
    },
    {"id": "COBIT-APO12", "name": "Managed Risk", "category": "risk"},
    {"id": "COBIT-APO13", "name": "Managed Security", "category": "governance"},
    {"id": "COBIT-APO14", "name": "Managed Data", "category": "data"},
    {"id": "COBIT-BAI01", "name": "Managed Programs", "category": "governance"},
    {
        "id": "COBIT-BAI03",
        "name": "Managed Solutions Identification and Build",
        "category": "code",
    },
    {"id": "COBIT-BAI06", "name": "Managed IT Changes", "category": "config"},
    {"id": "COBIT-BAI10", "name": "Managed Configuration", "category": "config"},
    {"id": "COBIT-DSS01", "name": "Managed Operations", "category": "config"},
    {
        "id": "COBIT-DSS02",
        "name": "Managed Service Requests and Incidents",
        "category": "incident",
    },
    {"id": "COBIT-DSS03", "name": "Managed Problems", "category": "incident"},
    {"id": "COBIT-DSS04", "name": "Managed Continuity", "category": "recovery"},
    {
        "id": "COBIT-DSS05",
        "name": "Managed Security Services",
        "category": "monitoring",
    },
    {
        "id": "COBIT-DSS06",
        "name": "Managed Business Process Controls",
        "category": "access",
    },
    {
        "id": "COBIT-MEA01",
        "name": "Managed Performance and Conformance Monitoring",
        "category": "monitoring",
    },
    {
        "id": "COBIT-MEA02",
        "name": "Managed System of Internal Control",
        "category": "testing",
    },
    {
        "id": "COBIT-MEA03",
        "name": "Managed Compliance with External Requirements",
        "category": "governance",
    },
    {"id": "COBIT-MEA04", "name": "Managed Assurance", "category": "testing"},
]

_ITIL_SECURITY_CONTROLS: list[dict[str, str]] = [
    {
        "id": "ITIL-ISM-1",
        "name": "Information Security Policy",
        "category": "governance",
    },
    {
        "id": "ITIL-ISM-2",
        "name": "Information Security Management System",
        "category": "governance",
    },
    {
        "id": "ITIL-ISM-3",
        "name": "Security Controls Implementation",
        "category": "config",
    },
    {
        "id": "ITIL-ISM-4",
        "name": "Security Incident Management",
        "category": "incident",
    },
    {
        "id": "ITIL-ISM-5",
        "name": "Security Evaluation and Audit",
        "category": "testing",
    },
    {"id": "ITIL-ISM-6", "name": "Security Reporting", "category": "monitoring"},
    {
        "id": "ITIL-CHG-1",
        "name": "Change Enablement — Authorization",
        "category": "config",
    },
    {
        "id": "ITIL-CHG-2",
        "name": "Change Enablement — Risk Assessment",
        "category": "risk",
    },
    {
        "id": "ITIL-INC-1",
        "name": "Incident Management — Detection and Logging",
        "category": "incident",
    },
    {
        "id": "ITIL-INC-2",
        "name": "Incident Management — Resolution",
        "category": "incident",
    },
    {
        "id": "ITIL-PRB-1",
        "name": "Problem Management — Root Cause Analysis",
        "category": "incident",
    },
    {
        "id": "ITIL-SLM-1",
        "name": "Service Level Management — Security SLAs",
        "category": "governance",
    },
    {
        "id": "ITIL-CAP-1",
        "name": "Capacity and Performance — Security Monitoring",
        "category": "monitoring",
    },
    {
        "id": "ITIL-AVL-1",
        "name": "Availability Management — Security Availability",
        "category": "recovery",
    },
    {
        "id": "ITIL-CNT-1",
        "name": "IT Service Continuity Management",
        "category": "recovery",
    },
]

_SSDF_CONTROLS: list[dict[str, str]] = [
    {
        "id": "PO.1",
        "name": "Define Security Requirements for Software Development",
        "category": "governance",
    },
    {
        "id": "PO.2",
        "name": "Implement Roles and Responsibilities",
        "category": "governance",
    },
    {"id": "PO.3", "name": "Implement Supporting Toolchains", "category": "code"},
    {
        "id": "PO.4",
        "name": "Define and Use Criteria for Software Security Checks",
        "category": "testing",
    },
    {
        "id": "PO.5",
        "name": "Implement and Maintain Secure Environments",
        "category": "config",
    },
    {"id": "PS.1", "name": "Protect All Forms of Code", "category": "code"},
    {
        "id": "PS.2",
        "name": "Provide a Mechanism for Verifying Software Release Integrity",
        "category": "code",
    },
    {
        "id": "PS.3",
        "name": "Archive and Protect Each Software Release",
        "category": "code",
    },
    {
        "id": "PW.1",
        "name": "Design Software to Meet Security Requirements",
        "category": "code",
    },
    {
        "id": "PW.2",
        "name": "Review the Software Design to Verify Security",
        "category": "testing",
    },
    {"id": "PW.4", "name": "Reuse Existing Well-Secured Software", "category": "code"},
    {
        "id": "PW.5",
        "name": "Create Source Code by Adhering to Secure Coding Practices",
        "category": "code",
    },
    {
        "id": "PW.6",
        "name": "Configure the Compilation, Interpreter, and Build Processes",
        "category": "config",
    },
    {
        "id": "PW.7",
        "name": "Review and/or Analyze Human-Readable Code",
        "category": "testing",
    },
    {"id": "PW.8", "name": "Test Executable Code", "category": "testing"},
    {
        "id": "PW.9",
        "name": "Configure Software to Have Secure Settings by Default",
        "category": "config",
    },
    {
        "id": "RV.1",
        "name": "Identify and Confirm Vulnerabilities on an Ongoing Basis",
        "category": "vuln",
    },
    {
        "id": "RV.2",
        "name": "Assess, Prioritize, and Remediate Vulnerabilities",
        "category": "vuln",
    },
    {
        "id": "RV.3",
        "name": "Analyze Vulnerabilities to Identify Root Causes",
        "category": "vuln",
    },
]

_OWASP_ASVS_CONTROLS: list[dict[str, str]] = [
    # V1 — Architecture, Design and Threat Modeling
    {"id": "V1.1", "name": "Secure Software Development Lifecycle", "category": "code"},
    {"id": "V1.2", "name": "Authentication Architecture", "category": "auth"},
    {"id": "V1.4", "name": "Access Control Architecture", "category": "access"},
    {"id": "V1.5", "name": "Input and Output Architecture", "category": "code"},
    {"id": "V1.6", "name": "Cryptographic Architecture", "category": "crypto"},
    {
        "id": "V1.7",
        "name": "Errors, Logging and Auditing Architecture",
        "category": "logging",
    },
    {
        "id": "V1.8",
        "name": "Data Protection and Privacy Architecture",
        "category": "data",
    },
    {"id": "V1.9", "name": "Communications Architecture", "category": "network"},
    {"id": "V1.10", "name": "Malicious Software Architecture", "category": "malware"},
    {"id": "V1.11", "name": "Business Logic Architecture", "category": "code"},
    {"id": "V1.12", "name": "Secure File Upload Architecture", "category": "code"},
    {"id": "V1.14", "name": "Configuration Architecture", "category": "config"},
    # V2 — Authentication
    {"id": "V2.1", "name": "Password Security", "category": "auth"},
    {"id": "V2.2", "name": "General Authenticator Security", "category": "auth"},
    {"id": "V2.3", "name": "Authenticator Lifecycle", "category": "auth"},
    {"id": "V2.4", "name": "Credential Storage", "category": "crypto"},
    {"id": "V2.5", "name": "Credential Recovery", "category": "auth"},
    {"id": "V2.7", "name": "Out of Band Verifier", "category": "auth"},
    {"id": "V2.8", "name": "One-Time Verifier", "category": "auth"},
    {"id": "V2.9", "name": "Cryptographic Verifier", "category": "crypto"},
    {"id": "V2.10", "name": "Service Authentication", "category": "auth"},
    # V3 — Session Management
    {"id": "V3.1", "name": "Fundamental Session Management", "category": "auth"},
    {"id": "V3.2", "name": "Session Binding", "category": "auth"},
    {"id": "V3.3", "name": "Session Termination", "category": "auth"},
    {"id": "V3.4", "name": "Cookie-Based Session Management", "category": "auth"},
    {"id": "V3.5", "name": "Token-Based Session Management", "category": "auth"},
    {
        "id": "V3.7",
        "name": "Defenses Against Session Management Exploits",
        "category": "auth",
    },
    # V4 — Access Control
    {"id": "V4.1", "name": "General Access Control Design", "category": "access"},
    {"id": "V4.2", "name": "Operation Level Access Control", "category": "access"},
    {"id": "V4.3", "name": "Other Access Control Considerations", "category": "access"},
    # V5 — Validation, Sanitization and Encoding
    {"id": "V5.1", "name": "Input Validation", "category": "code"},
    {"id": "V5.2", "name": "Sanitization and Sandboxing", "category": "code"},
    {
        "id": "V5.3",
        "name": "Output Encoding and Injection Prevention",
        "category": "injection",
    },
    {"id": "V5.4", "name": "Memory, String, and Unmanaged Code", "category": "code"},
    {"id": "V5.5", "name": "Deserialization Prevention", "category": "code"},
    # V6 — Stored Cryptography
    {"id": "V6.1", "name": "Data Classification", "category": "data"},
    {"id": "V6.2", "name": "Algorithms", "category": "crypto"},
    {"id": "V6.3", "name": "Random Values", "category": "crypto"},
    {"id": "V6.4", "name": "Secret Management", "category": "crypto"},
    # V7 — Error Handling and Logging
    {"id": "V7.1", "name": "Log Content", "category": "logging"},
    {"id": "V7.2", "name": "Log Processing", "category": "logging"},
    {"id": "V7.3", "name": "Log Protection", "category": "logging"},
    {"id": "V7.4", "name": "Error Handling", "category": "code"},
    # V8 — Data Protection
    {"id": "V8.1", "name": "General Data Protection", "category": "data"},
    {"id": "V8.2", "name": "Client-Side Data Protection", "category": "data"},
    {"id": "V8.3", "name": "Sensitive Private Data", "category": "data"},
    # V9 — Communication
    {"id": "V9.1", "name": "Client Communication Security", "category": "crypto"},
    {"id": "V9.2", "name": "Server Communication Security", "category": "crypto"},
    # V10 — Malicious Code
    {"id": "V10.1", "name": "Code Integrity", "category": "code"},
    {"id": "V10.2", "name": "Malicious Code Search", "category": "malware"},
    {"id": "V10.3", "name": "Application Integrity", "category": "code"},
    # V11 — Business Logic
    {"id": "V11.1", "name": "Business Logic Security", "category": "code"},
    # V12 — Files and Resources
    {"id": "V12.1", "name": "File Upload", "category": "code"},
    {"id": "V12.3", "name": "File Execution", "category": "code"},
    {"id": "V12.4", "name": "File Storage", "category": "data"},
    {"id": "V12.5", "name": "File Download", "category": "code"},
    {"id": "V12.6", "name": "SSRF Protection", "category": "network"},
    # V13 — API and Web Service
    {"id": "V13.1", "name": "Generic Web Service Security", "category": "code"},
    {"id": "V13.2", "name": "RESTful Web Service", "category": "code"},
    {"id": "V13.3", "name": "SOAP Web Service", "category": "code"},
    {"id": "V13.4", "name": "GraphQL", "category": "code"},
    # V14 — Configuration
    {"id": "V14.1", "name": "Build and Deploy", "category": "config"},
    {"id": "V14.2", "name": "Dependency", "category": "code"},
    {"id": "V14.3", "name": "Unintended Security Disclosure", "category": "config"},
    {"id": "V14.4", "name": "HTTP Security Headers", "category": "network"},
    {"id": "V14.5", "name": "HTTP Request Header Validation", "category": "network"},
]

_NIST_PRIVACY_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CT.DM-P1",
        "name": "Data Elements Mapped and Inventoried",
        "category": "data",
    },
    {
        "id": "CT.DM-P2",
        "name": "Data Elements Mapped to Individuals",
        "category": "data",
    },
    {"id": "CT.DM-P3", "name": "Data Processing Catalogued", "category": "data"},
    {
        "id": "CT.DP-P1",
        "name": "Data Processing Allowed Purposes Identified",
        "category": "governance",
    },
    {
        "id": "CT.DP-P2",
        "name": "Data Processing Legal Bases Identified",
        "category": "governance",
    },
    {
        "id": "CT.PO-P1",
        "name": "Privacy Policies Established",
        "category": "governance",
    },
    {
        "id": "CT.PO-P2",
        "name": "Privacy Roles and Responsibilities Defined",
        "category": "governance",
    },
    {
        "id": "CM.AW-P1",
        "name": "Privacy Awareness and Training",
        "category": "training",
    },
    {"id": "CM.AW-P2", "name": "Privacy Notices and Consent", "category": "data"},
    {
        "id": "PR.AC-P1",
        "name": "Data Processing Access Controlled",
        "category": "access",
    },
    {
        "id": "PR.AC-P2",
        "name": "Data Processing Integrity Protected",
        "category": "code",
    },
    {"id": "PR.DS-P1", "name": "Data-at-Rest Protected", "category": "crypto"},
    {"id": "PR.DS-P2", "name": "Data-in-Transit Protected", "category": "crypto"},
    {
        "id": "PR.MA-P1",
        "name": "Privacy Maintenance Performed",
        "category": "governance",
    },
    {
        "id": "PR.PT-P1",
        "name": "Audit/Log Records for Privacy Events",
        "category": "logging",
    },
]

_CCPA_CONTROLS: list[dict[str, str]] = [
    {
        "id": "CCPA-1798.100",
        "name": "Right to Know — Categories of PI Collected",
        "category": "data",
    },
    {
        "id": "CCPA-1798.105",
        "name": "Right to Delete Personal Information",
        "category": "data",
    },
    {
        "id": "CCPA-1798.106",
        "name": "Right to Correct Inaccurate Personal Information",
        "category": "data",
    },
    {
        "id": "CCPA-1798.110",
        "name": "Right to Know — Specific Pieces of PI",
        "category": "data",
    },
    {
        "id": "CCPA-1798.115",
        "name": "Right to Know — Sale or Sharing of PI",
        "category": "data",
    },
    {
        "id": "CCPA-1798.120",
        "name": "Right to Opt-Out of Sale/Sharing",
        "category": "access",
    },
    {
        "id": "CCPA-1798.121",
        "name": "Right to Limit Use of Sensitive PI",
        "category": "access",
    },
    {"id": "CCPA-1798.125", "name": "Non-Discrimination", "category": "governance"},
    {"id": "CCPA-1798.130", "name": "Notice at Collection", "category": "governance"},
    {"id": "CCPA-1798.135", "name": "Opt-Out Preference Signal", "category": "access"},
    {
        "id": "CCPA-1798.140",
        "name": "Privacy Policy Disclosure",
        "category": "governance",
    },
    {"id": "CCPA-1798.150", "name": "Data Breach Notification", "category": "incident"},
    {
        "id": "CCPA-1798.185",
        "name": "CPRA Cybersecurity Audit Requirement",
        "category": "testing",
    },
    {
        "id": "CCPA-1798.199.40",
        "name": "Automated Decision-Making — Right to Opt-Out",
        "category": "governance",
    },
]


# ---------------------------------------------------------------------------
# Finding-category → control mapping
# ---------------------------------------------------------------------------

_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "auth": [
        "auth",
        "login",
        "credential",
        "password",
        "mfa",
        "brute",
        "session",
        "token",
    ],
    "crypto": [
        "crypto",
        "encrypt",
        "tls",
        "ssl",
        "certificate",
        "cipher",
        "hash",
        "key management",
    ],
    "access": [
        "access",
        "privilege",
        "permission",
        "rbac",
        "authoriz",
        "least privilege",
    ],
    "injection": ["inject", "sqli", "xss", "command injection", "rce", "deseriali"],
    "config": ["config", "misconfigur", "default", "hardening", "baseline"],
    "network": [
        "network",
        "firewall",
        "segmentation",
        "port",
        "dns",
        "proxy",
        "boundary",
    ],
    "logging": ["log", "audit", "siem", "monitor", "event"],
    "vuln": ["vuln", "patch", "cve", "outdated", "eol", "end of life", "update"],
    "data": [
        "data",
        "pii",
        "phi",
        "sensitive",
        "classification",
        "retention",
        "backup",
    ],
    "malware": ["malware", "antivirus", "edr", "ransomware", "trojan"],
    "incident": ["incident", "breach", "response", "forensic", "containment"],
    "governance": [
        "policy",
        "governance",
        "compliance",
        "awareness",
        "training",
        "risk management",
    ],
    "code": ["code", "sast", "dast", "secure coding", "dependency", "supply chain"],
    "physical": ["physical", "facility", "badge", "cctv", "environmental"],
    "testing": ["pentest", "penetration", "scan", "assessment", "red team"],
    "recovery": ["recovery", "backup", "disaster", "continuity", "failover"],
    "inventory": ["inventory", "asset", "cmdb", "discovery"],
    "training": ["training", "awareness", "phishing simulation"],
    "monitoring": ["monitoring", "alert", "detection", "anomaly", "correlation"],
    "risk": ["risk assessment", "risk register", "threat model", "impact analysis"],
}

# Severity weights for score calculation
_SEVERITY_WEIGHTS: dict[str, float] = {
    "critical": 1.0,
    "high": 0.85,
    "medium": 0.6,
    "low": 0.3,
    "info": 0.1,
}


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


class ComplianceEngine:
    """Map security findings to compliance controls and generate reports."""

    CONTROL_MAPS: dict[ComplianceFramework, list[dict[str, str]]] = {
        ComplianceFramework.SOC2: _SOC2_CONTROLS,
        ComplianceFramework.PCI_DSS: _PCI_DSS_CONTROLS,
        ComplianceFramework.HIPAA: _HIPAA_CONTROLS,
        ComplianceFramework.NIST_800_53: _NIST_800_53_CONTROLS,
        ComplianceFramework.CIS: _CIS_CONTROLS,
        ComplianceFramework.ISO_27001: _ISO_27001_CONTROLS,
        ComplianceFramework.GDPR: _GDPR_CONTROLS,
        ComplianceFramework.CMMC: _CMMC_CONTROLS,
        ComplianceFramework.NIST_CSF: _NIST_CSF_CONTROLS,
        ComplianceFramework.NIST_AI_RMF: _NIST_AI_RMF_CONTROLS,
        ComplianceFramework.FEDRAMP: _FEDRAMP_CONTROLS,
        ComplianceFramework.OWASP_TOP_10: _OWASP_TOP_10_CONTROLS,
        ComplianceFramework.MITRE_ATTACK: _MITRE_ATTACK_CONTROLS,
        ComplianceFramework.IEC_62443: _IEC_62443_CONTROLS,
        ComplianceFramework.NIS2: _NIS2_CONTROLS,
        ComplianceFramework.DORA: _DORA_CONTROLS,
        ComplianceFramework.CISA_KEV: _CISA_KEV_CONTROLS,
        # --- Added in audit v2.0 ---
        ComplianceFramework.EU_AI_ACT: _EU_AI_ACT_CONTROLS,
        ComplianceFramework.SWIFT_CSP: _SWIFT_CSP_CONTROLS,
        ComplianceFramework.NIST_800_171: _NIST_800_171_CONTROLS,
        ComplianceFramework.ISO_27017: _ISO_27017_CONTROLS,
        ComplianceFramework.ISO_27018: _ISO_27018_CONTROLS,
        ComplianceFramework.ISO_27701: _ISO_27701_CONTROLS,
        ComplianceFramework.CSA_CCM: _CSA_CCM_CONTROLS,
        ComplianceFramework.NERC_CIP: _NERC_CIP_CONTROLS,
        ComplianceFramework.HITRUST_CSF: _HITRUST_CSF_CONTROLS,
        ComplianceFramework.CIS_CLOUD: _CIS_CLOUD_CONTROLS,
        ComplianceFramework.NIST_800_82: _NIST_800_82_CONTROLS,
        ComplianceFramework.OWASP_MASVS: _OWASP_MASVS_CONTROLS,
        ComplianceFramework.SANS_TOP_25: _SANS_TOP_25_CONTROLS,
        ComplianceFramework.PTES: _PTES_CONTROLS,
        ComplianceFramework.OSSTMM: _OSSTMM_CONTROLS,
        ComplianceFramework.SOX_IT: _SOX_IT_CONTROLS,
        ComplianceFramework.COBIT: _COBIT_CONTROLS,
        ComplianceFramework.ITIL_SECURITY: _ITIL_SECURITY_CONTROLS,
        ComplianceFramework.SSDF: _SSDF_CONTROLS,
        ComplianceFramework.OWASP_ASVS: _OWASP_ASVS_CONTROLS,
        ComplianceFramework.NIST_PRIVACY: _NIST_PRIVACY_CONTROLS,
        ComplianceFramework.CCPA: _CCPA_CONTROLS,
    }

    def __init__(self) -> None:
        self._category_to_controls: dict[ComplianceFramework, dict[str, list[str]]] = {}
        for fw, controls in self.CONTROL_MAPS.items():
            cat_map: dict[str, list[str]] = {}
            for ctrl in controls:
                cat_map.setdefault(ctrl["category"], []).append(ctrl["id"])
            self._category_to_controls[fw] = cat_map

    # -- public API -----------------------------------------------------------

    def assess_from_findings(
        self,
        findings: list[dict[str, Any]],
        framework: ComplianceFramework,
        scope: str = "",
    ) -> ComplianceReport:
        """Map a list of security findings to framework controls.

        Each finding dict should have at least:
            - title (str)
            - severity (str): critical/high/medium/low/info
        Optional keys: description, category, remediation, evidence, location
        """
        controls = self.CONTROL_MAPS[framework]
        now = datetime.now(timezone.utc).isoformat()

        # Build a map: control_id -> matched findings
        ctrl_findings: dict[str, list[dict[str, Any]]] = {c["id"]: [] for c in controls}
        for finding in findings:
            if not isinstance(finding, dict):
                continue
            matched_ids = self._map_finding_to_controls(finding, framework)
            for cid in matched_ids:
                if cid in ctrl_findings:
                    ctrl_findings[cid].append(finding)

        assessments: list[ControlAssessment] = []
        for ctrl in controls:
            cid = ctrl["id"]
            matched = ctrl_findings[cid]
            if not matched:
                assessments.append(
                    ControlAssessment(
                        control_id=cid,
                        control_name=ctrl["name"],
                        framework=framework,
                        status=ControlStatus.NOT_TESTED,
                        severity="info",
                        tested_at=now,
                    )
                )
                continue

            # Determine status from findings
            severities = [(f.get("severity") or "info").lower() for f in matched]
            worst = self._worst_severity(severities)
            has_critical = "critical" in severities or "high" in severities
            has_medium = "medium" in severities

            if has_critical:
                status = ControlStatus.FAIL
            elif has_medium:
                status = ControlStatus.PARTIAL
            else:
                status = ControlStatus.PASS

            evidence = [f.get("title", "untitled") for f in matched]
            gaps = [
                f.get("description", f.get("title", ""))
                for f in matched
                if (f.get("severity") or "").lower() in ("critical", "high", "medium")
            ]
            recs = [f.get("remediation", "") for f in matched if f.get("remediation")]

            assessments.append(
                ControlAssessment(
                    control_id=cid,
                    control_name=ctrl["name"],
                    framework=framework,
                    status=status,
                    evidence=evidence,
                    gaps=gaps,
                    recommendations=recs,
                    severity=worst,
                    tested_at=now,
                )
            )

        return self._build_report(assessments, framework, scope)

    def assess_from_scan(
        self,
        scan_results: dict[str, Any],
        framework: ComplianceFramework,
    ) -> ComplianceReport:
        """Map scan results to compliance controls.

        Accepts a dict with:
            - scope (str): target description
            - findings (list[dict]): same schema as assess_from_findings
            - metadata (dict, optional): scanner info
        """
        findings = scan_results.get("findings", [])
        scope = scan_results.get("scope", "scan target")
        return self.assess_from_findings(findings, framework, scope)

    def generate_gap_analysis(self, report: ComplianceReport) -> dict[str, Any]:
        """Return a prioritised remediation plan from failing controls."""
        severity_order = ["critical", "high", "medium", "low", "info"]
        failing = [
            a
            for a in report.assessments
            if a.status in (ControlStatus.FAIL, ControlStatus.PARTIAL)
        ]
        failing.sort(
            key=lambda a: (
                severity_order.index(a.severity) if a.severity in severity_order else 99
            )
        )

        remediation_items: list[dict[str, Any]] = []
        for idx, a in enumerate(failing, 1):
            remediation_items.append(
                {
                    "priority": idx,
                    "control_id": a.control_id,
                    "control_name": a.control_name,
                    "status": a.status.value,
                    "severity": a.severity,
                    "gaps": a.gaps,
                    "recommendations": a.recommendations,
                }
            )

        not_tested = [
            a for a in report.assessments if a.status == ControlStatus.NOT_TESTED
        ]

        return {
            "framework": report.framework.value,
            "report_id": report.report_id,
            "overall_score": round(report.overall_score, 2),
            "total_gaps": len(failing),
            "remediation_plan": remediation_items,
            "untested_controls": [
                {"control_id": a.control_id, "control_name": a.control_name}
                for a in not_tested
            ],
            "summary": (
                f"{len(failing)} controls require remediation; "
                f"{len(not_tested)} controls have not been tested. "
                f"Current score: {report.overall_score:.1f}%."
            ),
        }

    def compare_reports(
        self,
        report_a: ComplianceReport,
        report_b: ComplianceReport,
    ) -> dict[str, Any]:
        """Diff two reports of the same framework to show progress over time."""
        map_a: dict[str, ControlAssessment] = {
            a.control_id: a for a in report_a.assessments
        }
        map_b: dict[str, ControlAssessment] = {
            a.control_id: a for a in report_b.assessments
        }

        all_ids = sorted(set(map_a.keys()) | set(map_b.keys()))

        improved: list[dict[str, str]] = []
        regressed: list[dict[str, str]] = []
        unchanged: list[str] = []
        new_controls: list[str] = []
        removed_controls: list[str] = []

        status_rank = {
            ControlStatus.FAIL: 0,
            ControlStatus.PARTIAL: 1,
            ControlStatus.NOT_TESTED: 2,
            ControlStatus.NOT_APPLICABLE: 3,
            ControlStatus.PASS: 4,
        }

        for cid in all_ids:
            a_ctrl = map_a.get(cid)
            b_ctrl = map_b.get(cid)
            if a_ctrl and not b_ctrl:
                removed_controls.append(cid)
            elif b_ctrl and not a_ctrl:
                new_controls.append(cid)
            elif a_ctrl and b_ctrl:
                rank_a = status_rank.get(a_ctrl.status, -1)
                rank_b = status_rank.get(b_ctrl.status, -1)
                if rank_b > rank_a:
                    improved.append(
                        {
                            "control_id": cid,
                            "from": a_ctrl.status.value,
                            "to": b_ctrl.status.value,
                        }
                    )
                elif rank_b < rank_a:
                    regressed.append(
                        {
                            "control_id": cid,
                            "from": a_ctrl.status.value,
                            "to": b_ctrl.status.value,
                        }
                    )
                else:
                    unchanged.append(cid)

        score_delta = report_b.overall_score - report_a.overall_score

        return {
            "report_a_id": report_a.report_id,
            "report_b_id": report_b.report_id,
            "framework": report_a.framework.value,
            "score_a": round(report_a.overall_score, 2),
            "score_b": round(report_b.overall_score, 2),
            "score_delta": round(score_delta, 2),
            "improved": improved,
            "regressed": regressed,
            "unchanged_count": len(unchanged),
            "new_controls": new_controls,
            "removed_controls": removed_controls,
            "summary": (
                f"Score changed from {report_a.overall_score:.1f}% to "
                f"{report_b.overall_score:.1f}% (Δ {score_delta:+.1f}%). "
                f"{len(improved)} improved, {len(regressed)} regressed."
            ),
        }

    def export_csv(self, report: ComplianceReport) -> str:
        """Export report as CSV for import into GRC tools."""
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(
            [
                "Report ID",
                "Framework",
                "Control ID",
                "Control Name",
                "Status",
                "Severity",
                "Evidence",
                "Gaps",
                "Recommendations",
                "Tested At",
            ]
        )
        for a in report.assessments:
            writer.writerow(
                [
                    report.report_id,
                    report.framework.value,
                    a.control_id,
                    a.control_name,
                    a.status.value,
                    a.severity,
                    "; ".join(a.evidence),
                    "; ".join(a.gaps),
                    "; ".join(a.recommendations),
                    a.tested_at,
                ]
            )
        return buf.getvalue()

    # -- private helpers ------------------------------------------------------

    def _map_finding_to_controls(
        self,
        finding: dict[str, Any],
        framework: ComplianceFramework,
    ) -> list[str]:
        """Match a finding to relevant control IDs based on category keywords."""
        text = " ".join(
            [
                str(finding.get("title", "") or ""),
                str(finding.get("description", "") or ""),
                str(finding.get("category", "") or ""),
            ]
        ).lower()

        matched_categories: set[str] = set()
        for category, keywords in _CATEGORY_KEYWORDS.items():
            for kw in keywords:
                if kw in text:
                    matched_categories.add(category)
                    break

        if not matched_categories:
            # Fall back: try to match by explicit category field
            explicit = (finding.get("category") or "").lower()
            if explicit in _CATEGORY_KEYWORDS:
                matched_categories.add(explicit)

        cat_map = self._category_to_controls.get(framework, {})
        control_ids: list[str] = []
        for cat in matched_categories:
            control_ids.extend(cat_map.get(cat, []))

        return list(dict.fromkeys(control_ids))  # deduplicate, preserve order

    def _calculate_score(self, assessments: list[ControlAssessment]) -> float:
        """Weighted compliance score (0-100).

        - PASS = full weight
        - PARTIAL = 50% weight
        - FAIL / NOT_TESTED = 0
        - NOT_APPLICABLE excluded from denominator
        """
        total_weight = 0.0
        earned_weight = 0.0

        for a in assessments:
            if a.status == ControlStatus.NOT_APPLICABLE:
                continue
            weight = _SEVERITY_WEIGHTS.get(a.severity, 0.5)
            total_weight += weight
            if a.status == ControlStatus.PASS:
                earned_weight += weight
            elif a.status == ControlStatus.PARTIAL:
                earned_weight += weight * 0.5

        if total_weight == 0:
            return 0.0
        return (earned_weight / total_weight) * 100.0

    # -- internal builders ----------------------------------------------------

    @staticmethod
    def _worst_severity(severities: list[str]) -> str:
        """Return the most severe level from a list."""
        order = ["critical", "high", "medium", "low", "info"]
        for level in order:
            if level in severities:
                return level
        return "info"

    def _build_report(
        self,
        assessments: list[ControlAssessment],
        framework: ComplianceFramework,
        scope: str,
    ) -> ComplianceReport:
        """Assemble a ComplianceReport from a list of assessments."""
        score = self._calculate_score(assessments)
        counts = {s: 0 for s in ControlStatus}
        for a in assessments:
            counts[a.status] += 1

        total = len(assessments)
        pass_count = counts[ControlStatus.PASS]
        fail_count = counts[ControlStatus.FAIL]
        partial_count = counts[ControlStatus.PARTIAL]
        na_count = counts[ControlStatus.NOT_APPLICABLE]

        summary_parts: list[str] = [
            f"Assessment of {total} {framework.value} controls completed.",
            f"{pass_count} passed, {fail_count} failed, {partial_count} partial, {na_count} N/A.",
            f"Overall compliance score: {score:.1f}%.",
        ]
        if fail_count:
            critical_fails = [
                a
                for a in assessments
                if a.status == ControlStatus.FAIL and a.severity == "critical"
            ]
            if critical_fails:
                summary_parts.append(
                    f"CRITICAL: {len(critical_fails)} controls have critical failures requiring immediate remediation."
                )

        return ComplianceReport(
            report_id=str(uuid.uuid4()),
            framework=framework,
            scope=scope or "Full environment",
            controls_total=total,
            controls_pass=pass_count,
            controls_fail=fail_count,
            controls_partial=partial_count,
            controls_na=na_count,
            overall_score=round(score, 2),
            assessments=assessments,
            executive_summary=" ".join(summary_parts),
        )
