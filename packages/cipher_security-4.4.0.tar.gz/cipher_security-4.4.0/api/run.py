#!/usr/bin/env python3
# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
"""Run the CIPHER API server."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from api.server import CipherAPIServer, APIConfig


def main():
    import argparse

    parser = argparse.ArgumentParser(description="CIPHER API Server")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host")
    parser.add_argument("--port", type=int, default=8443, help="Bind port")
    parser.add_argument("--no-auth", action="store_true", help="Disable authentication")
    args = parser.parse_args()

    config = APIConfig(
        host=args.host,
        port=args.port,
        require_auth=not args.no_auth,
    )
    server = CipherAPIServer(config)
    print(f"CIPHER API Server v4.0.0 listening on {args.host}:{args.port}")
    print(f"Auth: {'disabled' if args.no_auth else 'enabled'}")
    print(f"Health: http://{args.host}:{args.port}/v1/health")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.shutdown()


if __name__ == "__main__":
    main()
