# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.

"""Usage-based billing and metering middleware.

Tracks API usage per client for billing purposes:
- Request counting by endpoint
- Scan credit consumption
- Memory storage quotas
- Rate tier enforcement

Architecture and implementation are original CIPHER designs.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class BillingTier(Enum):
    """Billing plan tiers."""

    FREE = "free"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


@dataclass
class TierLimits:
    """Rate and quota limits per billing tier."""

    requests_per_hour: int = 100
    scans_per_day: int = 5
    memory_entries: int = 1000
    skill_searches_per_hour: int = 50
    compliance_reports_per_day: int = 3
    marketplace_downloads_per_day: int = 10
    max_response_size_kb: int = 512


# Tier definitions
TIER_LIMITS: dict[BillingTier, TierLimits] = {
    BillingTier.FREE: TierLimits(
        requests_per_hour=60,
        scans_per_day=3,
        memory_entries=100,
        skill_searches_per_hour=20,
        compliance_reports_per_day=1,
        marketplace_downloads_per_day=5,
        max_response_size_kb=256,
    ),
    BillingTier.STARTER: TierLimits(
        requests_per_hour=500,
        scans_per_day=20,
        memory_entries=5000,
        skill_searches_per_hour=200,
        compliance_reports_per_day=10,
        marketplace_downloads_per_day=50,
        max_response_size_kb=1024,
    ),
    BillingTier.PROFESSIONAL: TierLimits(
        requests_per_hour=5000,
        scans_per_day=100,
        memory_entries=50000,
        skill_searches_per_hour=2000,
        compliance_reports_per_day=50,
        marketplace_downloads_per_day=500,
        max_response_size_kb=4096,
    ),
    BillingTier.ENTERPRISE: TierLimits(
        requests_per_hour=50000,
        scans_per_day=1000,
        memory_entries=500000,
        skill_searches_per_hour=20000,
        compliance_reports_per_day=500,
        marketplace_downloads_per_day=5000,
        max_response_size_kb=16384,
    ),
}


@dataclass
class UsageRecord:
    """A single usage event."""

    client_id: str
    endpoint: str
    timestamp: float
    credits_consumed: float = 1.0
    response_size_bytes: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class UsageSummary:
    """Usage summary for a client."""

    client_id: str
    tier: BillingTier
    period_start: float
    period_end: float
    total_requests: int = 0
    total_scans: int = 0
    total_credits: float = 0.0
    by_endpoint: dict[str, int] = field(default_factory=dict)
    quota_remaining: dict[str, int] = field(default_factory=dict)
    overage: bool = False


# Credit costs per endpoint type
ENDPOINT_CREDITS: dict[str, float] = {
    "scan": 10.0,
    "diff": 2.0,
    "secrets": 2.0,
    "memory/store": 1.0,
    "memory/search": 1.0,
    "score": 5.0,
    "compliance": 5.0,
    "workflow": 3.0,
    "skills": 0.5,
    "skills/search": 0.5,
    "leaderboard": 0.5,
    "health": 0.0,
    "stats": 0.0,
}


class MeteringEngine:
    """Tracks and enforces usage-based billing.

    Uses SQLite for persistent usage tracking.
    """

    def __init__(self, db_path: str = "~/.cipher/billing.db") -> None:
        self._db_path = Path(db_path).expanduser()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_db()
        self._client_tiers: dict[str, BillingTier] = {}

    def _init_db(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS usage_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id TEXT NOT NULL,
                endpoint TEXT NOT NULL,
                credits REAL NOT NULL DEFAULT 1.0,
                response_bytes INTEGER DEFAULT 0,
                timestamp REAL NOT NULL,
                metadata TEXT DEFAULT '{}'
            );
            CREATE INDEX IF NOT EXISTS idx_usage_client_ts
                ON usage_events(client_id, timestamp);
            CREATE INDEX IF NOT EXISTS idx_usage_endpoint
                ON usage_events(endpoint, timestamp);

            CREATE TABLE IF NOT EXISTS client_tiers (
                client_id TEXT PRIMARY KEY,
                tier TEXT NOT NULL DEFAULT 'free',
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );
        """)
        self._conn.commit()

    def set_client_tier(self, client_id: str, tier: BillingTier) -> None:
        """Set or update a client's billing tier."""
        now = time.time()
        self._conn.execute(
            """INSERT INTO client_tiers (client_id, tier, created_at, updated_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(client_id) DO UPDATE SET tier=?, updated_at=?""",
            (client_id, tier.value, now, now, tier.value, now),
        )
        self._conn.commit()
        self._client_tiers[client_id] = tier

    def get_client_tier(self, client_id: str) -> BillingTier:
        """Get a client's billing tier."""
        if client_id in self._client_tiers:
            return self._client_tiers[client_id]
        row = self._conn.execute(
            "SELECT tier FROM client_tiers WHERE client_id = ?",
            (client_id,),
        ).fetchone()
        tier = BillingTier(row["tier"]) if row else BillingTier.FREE
        self._client_tiers[client_id] = tier
        return tier

    def record_usage(self, record: UsageRecord) -> None:
        """Record a usage event."""
        self._conn.execute(
            """INSERT INTO usage_events (client_id, endpoint, credits, response_bytes, timestamp, metadata)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                record.client_id,
                record.endpoint,
                record.credits_consumed,
                record.response_size_bytes,
                record.timestamp,
                json.dumps(record.metadata),
            ),
        )
        self._conn.commit()

    def check_quota(self, client_id: str, endpoint: str) -> dict:
        """Check if a client has quota remaining for an endpoint.

        Returns: {"allowed": bool, "remaining": int, "limit": int, "resets_in_s": int}
        """
        tier = self.get_client_tier(client_id)
        limits = TIER_LIMITS[tier]
        now = time.time()
        hour_ago = now - 3600
        day_ago = now - 86400

        # Check hourly request limit
        hourly_count = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM usage_events WHERE client_id = ? AND timestamp > ?",
            (client_id, hour_ago),
        ).fetchone()["cnt"]

        if hourly_count >= limits.requests_per_hour:
            return {
                "allowed": False,
                "remaining": 0,
                "limit": limits.requests_per_hour,
                "resets_in_s": 3600,
                "reason": "hourly request limit exceeded",
            }

        # Check scan-specific limit
        if endpoint == "scan":
            daily_scans = self._conn.execute(
                "SELECT COUNT(*) as cnt FROM usage_events WHERE client_id = ? AND endpoint = 'scan' AND timestamp > ?",
                (client_id, day_ago),
            ).fetchone()["cnt"]
            if daily_scans >= limits.scans_per_day:
                return {
                    "allowed": False,
                    "remaining": 0,
                    "limit": limits.scans_per_day,
                    "resets_in_s": 86400,
                    "reason": "daily scan limit exceeded",
                }
            return {
                "allowed": True,
                "remaining": limits.scans_per_day - daily_scans,
                "limit": limits.scans_per_day,
                "resets_in_s": 86400,
            }

        return {
            "allowed": True,
            "remaining": limits.requests_per_hour - hourly_count,
            "limit": limits.requests_per_hour,
            "resets_in_s": 3600,
        }

    def get_usage_summary(
        self,
        client_id: str,
        period_hours: int = 24,
    ) -> UsageSummary:
        """Get usage summary for a client over a time period."""
        tier = self.get_client_tier(client_id)
        now = time.time()
        period_start = now - (period_hours * 3600)

        rows = self._conn.execute(
            """SELECT endpoint, COUNT(*) as cnt, SUM(credits) as total_credits
               FROM usage_events
               WHERE client_id = ? AND timestamp > ?
               GROUP BY endpoint""",
            (client_id, period_start),
        ).fetchall()

        by_endpoint = {}
        total_requests = 0
        total_credits = 0.0
        total_scans = 0

        for row in rows:
            ep = row["endpoint"]
            by_endpoint[ep] = row["cnt"]
            total_requests += row["cnt"]
            total_credits += row["total_credits"]
            if ep == "scan":
                total_scans = row["cnt"]

        limits = TIER_LIMITS[tier]
        return UsageSummary(
            client_id=client_id,
            tier=tier,
            period_start=period_start,
            period_end=now,
            total_requests=total_requests,
            total_scans=total_scans,
            total_credits=total_credits,
            by_endpoint=by_endpoint,
            quota_remaining={
                "requests_hourly": max(0, limits.requests_per_hour - total_requests),
                "scans_daily": max(0, limits.scans_per_day - total_scans),
            },
            overage=total_requests > limits.requests_per_hour,
        )

    def get_credits_for_endpoint(self, endpoint: str) -> float:
        """Get the credit cost for an endpoint."""
        # Match endpoint suffix
        for ep, credits in ENDPOINT_CREDITS.items():
            if endpoint.endswith(ep):
                return credits
        return 1.0  # Default

    def close(self) -> None:
        """Close database connection."""
        self._conn.close()
