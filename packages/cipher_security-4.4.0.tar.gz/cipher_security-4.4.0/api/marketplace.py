# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0

"""Skill marketplace for distributing and managing CIPHER skills."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import tarfile
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Optional


@dataclass
class SkillPackage:
    """A publishable skill package."""

    package_id: str = ""
    name: str = ""
    domain: str = ""
    version: str = ""
    description: str = ""
    author: str = ""
    license: str = "AGPL-3.0"
    tags: list[str] = field(default_factory=list)
    files: dict[str, str] = field(default_factory=dict)
    checksum: str = ""
    downloads: int = 0
    rating: float = 0.0
    ratings_count: int = 0
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self) -> None:
        if not self.package_id:
            self.package_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now


@dataclass
class SkillReview:
    """A review for a skill package."""

    review_id: str = ""
    package_id: str = ""
    reviewer: str = ""
    rating: float = 0.0
    comment: str = ""
    created_at: str = ""

    def __post_init__(self) -> None:
        if not self.review_id:
            self.review_id = str(uuid.uuid4())
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if self.rating < 1.0:
            self.rating = 1.0
        elif self.rating > 5.0:
            self.rating = 5.0


@dataclass
class MarketplaceIndex:
    """Summary index of the marketplace."""

    total_packages: int = 0
    total_downloads: int = 0
    categories: dict[str, int] = field(default_factory=dict)
    top_rated: list[dict] = field(default_factory=list)
    most_downloaded: list[dict] = field(default_factory=list)
    recently_updated: list[dict] = field(default_factory=list)


class SkillMarketplace:
    """Marketplace for publishing, discovering, and installing CIPHER skills."""

    def __init__(
        self,
        db_path: str = "~/.cipher/marketplace.db",
        skills_dir: str = "skills",
    ) -> None:
        self.db_path = Path(db_path).expanduser()
        self.skills_dir = Path(skills_dir)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self._init_db()

    # ------------------------------------------------------------------
    # Database setup
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Create SQLite tables for packages, reviews, and download log."""
        cur = self.conn.cursor()
        cur.executescript(
            """
            CREATE TABLE IF NOT EXISTS packages (
                package_id   TEXT PRIMARY KEY,
                name         TEXT NOT NULL,
                domain       TEXT NOT NULL DEFAULT '',
                version      TEXT NOT NULL DEFAULT '0.1.0',
                description  TEXT NOT NULL DEFAULT '',
                author       TEXT NOT NULL DEFAULT '',
                license      TEXT NOT NULL DEFAULT 'AGPL-3.0',
                tags         TEXT NOT NULL DEFAULT '[]',
                files        TEXT NOT NULL DEFAULT '{}',
                checksum     TEXT NOT NULL DEFAULT '',
                downloads    INTEGER NOT NULL DEFAULT 0,
                rating       REAL NOT NULL DEFAULT 0.0,
                ratings_count INTEGER NOT NULL DEFAULT 0,
                created_at   TEXT NOT NULL,
                updated_at   TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS reviews (
                review_id   TEXT PRIMARY KEY,
                package_id  TEXT NOT NULL,
                reviewer    TEXT NOT NULL,
                rating      REAL NOT NULL,
                comment     TEXT NOT NULL DEFAULT '',
                created_at  TEXT NOT NULL,
                FOREIGN KEY (package_id) REFERENCES packages(package_id)
            );

            CREATE TABLE IF NOT EXISTS download_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                package_id  TEXT NOT NULL,
                downloaded_at TEXT NOT NULL,
                target_dir  TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (package_id) REFERENCES packages(package_id)
            );

            CREATE INDEX IF NOT EXISTS idx_packages_domain
                ON packages(domain);
            CREATE INDEX IF NOT EXISTS idx_packages_rating
                ON packages(rating DESC);
            CREATE INDEX IF NOT EXISTS idx_reviews_package
                ON reviews(package_id);
            """
        )
        self.conn.commit()

    # ------------------------------------------------------------------
    # Checksum
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_checksum(files: dict[str, str]) -> str:
        """Compute SHA-256 checksum over all file contents (sorted by name)."""
        h = hashlib.sha256()
        for name in sorted(files.keys()):
            h.update(name.encode("utf-8"))
            h.update(files[name].encode("utf-8"))
        return h.hexdigest()

    # ------------------------------------------------------------------
    # Publish / get / list / search
    # ------------------------------------------------------------------

    def publish(self, package: SkillPackage) -> str:
        """Publish a skill package to the marketplace. Returns package_id."""
        if not package.checksum and package.files:
            package.checksum = self._compute_checksum(package.files)

        now = datetime.now(timezone.utc).isoformat()
        package.updated_at = now

        cur = self.conn.cursor()
        # Upsert: update if package_id already exists
        cur.execute(
            """
            INSERT INTO packages (
                package_id, name, domain, version, description, author,
                license, tags, files, checksum, downloads, rating,
                ratings_count, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(package_id) DO UPDATE SET
                name=excluded.name, domain=excluded.domain,
                version=excluded.version, description=excluded.description,
                author=excluded.author, license=excluded.license,
                tags=excluded.tags, files=excluded.files,
                checksum=excluded.checksum, updated_at=excluded.updated_at
            """,
            (
                package.package_id,
                package.name,
                package.domain,
                package.version,
                package.description,
                package.author,
                package.license,
                json.dumps(package.tags),
                json.dumps(package.files),
                package.checksum,
                package.downloads,
                package.rating,
                package.ratings_count,
                package.created_at,
                now,
            ),
        )
        self.conn.commit()
        return package.package_id

    def get_package(self, package_id: str) -> Optional[SkillPackage]:
        """Retrieve a single package by ID."""
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM packages WHERE package_id = ?", (package_id,))
        row = cur.fetchone()
        if row is None:
            return None
        return self._row_to_package(row)

    def list_packages(
        self,
        domain: str | None = None,
        sort: str = "rating",
        limit: int = 20,
    ) -> list[SkillPackage]:
        """List packages with optional domain filter and sorting."""
        sort_map = {
            "rating": "rating DESC",
            "downloads": "downloads DESC",
            "name": "name ASC",
            "updated": "updated_at DESC",
            "created": "created_at DESC",
        }
        order = sort_map.get(sort, "rating DESC")

        cur = self.conn.cursor()
        if domain:
            cur.execute(
                f"SELECT * FROM packages WHERE domain = ? ORDER BY {order} LIMIT ?",  # nosec B608
                (domain, limit),
            )
        else:
            cur.execute(
                f"SELECT * FROM packages ORDER BY {order} LIMIT ?",  # nosec B608
                (limit,),
            )
        return [self._row_to_package(r) for r in cur.fetchall()]

    def search(
        self,
        query: str,
        domain: str | None = None,
        tags: list[str] | None = None,
    ) -> list[SkillPackage]:
        """Search packages by name, description, and optional filters."""
        cur = self.conn.cursor()
        conditions = ["(name LIKE ? OR description LIKE ? OR tags LIKE ?)"]
        params: list[str] = [f"%{query}%", f"%{query}%", f"%{query}%"]

        if domain:
            conditions.append("domain = ?")
            params.append(domain)

        if tags:
            for tag in tags:
                conditions.append("tags LIKE ?")
                params.append(f'%"{tag}"%')

        where = " AND ".join(conditions)
        cur.execute(
            f"SELECT * FROM packages WHERE {where} ORDER BY rating DESC",  # nosec B608
            params,
        )
        return [self._row_to_package(r) for r in cur.fetchall()]

    # ------------------------------------------------------------------
    # Install / uninstall
    # ------------------------------------------------------------------

    def install(self, package_id: str, target_dir: str | None = None) -> bool:
        """Install a skill package to the target directory."""
        pkg = self.get_package(package_id)
        if pkg is None:
            return False

        dest = Path(target_dir) if target_dir else self.skills_dir / pkg.name
        dest.mkdir(parents=True, exist_ok=True)

        for filename, content in pkg.files.items():
            # Prevent path traversal from malicious package filenames
            safe_name = Path(filename).name if "/" not in filename else filename
            filepath = (dest / safe_name).resolve()
            if not str(filepath).startswith(str(dest.resolve())):
                continue  # Skip files that escape target directory
            filepath.parent.mkdir(parents=True, exist_ok=True)
            filepath.write_text(content, encoding="utf-8")

        # Record download
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.cursor()
        cur.execute(
            "UPDATE packages SET downloads = downloads + 1 WHERE package_id = ?",
            (package_id,),
        )
        cur.execute(
            "INSERT INTO download_log (package_id, downloaded_at, target_dir) VALUES (?, ?, ?)",
            (package_id, now, str(dest)),
        )
        self.conn.commit()
        return True

    def uninstall(self, package_id: str) -> bool:
        """Remove installed skill files from disk."""
        pkg = self.get_package(package_id)
        if pkg is None:
            return False

        # Check common install locations
        possible_dirs = [
            self.skills_dir / pkg.name,
        ]

        # Also check download_log for where it was installed
        cur = self.conn.cursor()
        cur.execute(
            "SELECT target_dir FROM download_log WHERE package_id = ? ORDER BY downloaded_at DESC LIMIT 1",
            (package_id,),
        )
        row = cur.fetchone()
        if row and row["target_dir"]:
            possible_dirs.insert(0, Path(row["target_dir"]))

        removed = False
        for install_dir in possible_dirs:
            if install_dir.exists():
                # Remove individual files first
                for filename in pkg.files:
                    fpath = install_dir / filename
                    if fpath.exists():
                        fpath.unlink()
                # Remove empty directories bottom-up
                for dirpath in sorted(install_dir.rglob("*"), reverse=True):
                    if dirpath.is_dir() and not any(dirpath.iterdir()):
                        dirpath.rmdir()
                if install_dir.exists() and not any(install_dir.iterdir()):
                    install_dir.rmdir()
                removed = True

        return removed

    # ------------------------------------------------------------------
    # Ratings / reviews
    # ------------------------------------------------------------------

    def rate(
        self,
        package_id: str,
        reviewer: str,
        rating: float,
        comment: str = "",
    ) -> bool:
        """Add a rating/review for a package."""
        if self.get_package(package_id) is None:
            return False

        rating = max(1.0, min(5.0, rating))
        review = SkillReview(
            package_id=package_id,
            reviewer=reviewer,
            rating=rating,
            comment=comment,
        )

        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT INTO reviews (review_id, package_id, reviewer, rating, comment, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                review.review_id,
                review.package_id,
                review.reviewer,
                review.rating,
                review.comment,
                review.created_at,
            ),
        )

        # Recompute average rating
        cur.execute(
            "SELECT AVG(rating) as avg_r, COUNT(*) as cnt FROM reviews WHERE package_id = ?",
            (package_id,),
        )
        stats = cur.fetchone()
        cur.execute(
            "UPDATE packages SET rating = ?, ratings_count = ? WHERE package_id = ?",
            (round(stats["avg_r"], 2), stats["cnt"], package_id),
        )
        self.conn.commit()
        return True

    def get_reviews(self, package_id: str) -> list[SkillReview]:
        """Get all reviews for a package."""
        cur = self.conn.cursor()
        cur.execute(
            "SELECT * FROM reviews WHERE package_id = ? ORDER BY created_at DESC",
            (package_id,),
        )
        return [
            SkillReview(
                review_id=r["review_id"],
                package_id=r["package_id"],
                reviewer=r["reviewer"],
                rating=r["rating"],
                comment=r["comment"],
                created_at=r["created_at"],
            )
            for r in cur.fetchall()
        ]

    # ------------------------------------------------------------------
    # Marketplace index
    # ------------------------------------------------------------------

    def get_index(self) -> MarketplaceIndex:
        """Build a summary index of the marketplace."""
        cur = self.conn.cursor()

        cur.execute("SELECT COUNT(*) as cnt FROM packages")
        total_packages = cur.fetchone()["cnt"]

        cur.execute("SELECT COALESCE(SUM(downloads), 0) as total FROM packages")
        total_downloads = cur.fetchone()["total"]

        cur.execute("SELECT domain, COUNT(*) as cnt FROM packages GROUP BY domain")
        categories = {r["domain"]: r["cnt"] for r in cur.fetchall()}

        cur.execute(
            "SELECT package_id, name, domain, rating, downloads FROM packages "
            "ORDER BY rating DESC LIMIT 10"
        )
        top_rated = [dict(r) for r in cur.fetchall()]

        cur.execute(
            "SELECT package_id, name, domain, rating, downloads FROM packages "
            "ORDER BY downloads DESC LIMIT 10"
        )
        most_downloaded = [dict(r) for r in cur.fetchall()]

        cur.execute(
            "SELECT package_id, name, domain, version, updated_at FROM packages "
            "ORDER BY updated_at DESC LIMIT 10"
        )
        recently_updated = [dict(r) for r in cur.fetchall()]

        return MarketplaceIndex(
            total_packages=total_packages,
            total_downloads=total_downloads,
            categories=categories,
            top_rated=top_rated,
            most_downloaded=most_downloaded,
            recently_updated=recently_updated,
        )

    # ------------------------------------------------------------------
    # Package from existing skill directory
    # ------------------------------------------------------------------

    def package_from_skill_dir(self, skill_dir: str) -> SkillPackage:
        """Create a SkillPackage from an existing skill directory on disk."""
        skill_path = Path(skill_dir)
        if not skill_path.is_dir():
            raise FileNotFoundError(f"Skill directory not found: {skill_dir}")

        files: dict[str, str] = {}
        for fpath in sorted(skill_path.rglob("*")):
            if fpath.is_file():
                rel = str(fpath.relative_to(skill_path))
                try:
                    files[rel] = fpath.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    # Skip binary files
                    continue

        # Try to extract metadata from SKILL.md if present
        name = skill_path.name
        description = ""
        domain = ""
        author = "defconxt"
        skill_md = skill_path / "SKILL.md"
        if skill_md.exists():
            content = skill_md.read_text(encoding="utf-8")
            lines = content.strip().splitlines()
            for line in lines:
                stripped = line.strip()
                if stripped.startswith("# ") and not description:
                    description = stripped[2:].strip()
                if "domain" in stripped.lower() and ":" in stripped and not domain:
                    domain = stripped.split(":", 1)[1].strip()

        pkg = SkillPackage(
            name=name,
            domain=domain,
            version="0.1.0",
            description=description or f"Skill package: {name}",
            author=author,
            files=files,
        )
        pkg.checksum = self._compute_checksum(files)
        return pkg

    # ------------------------------------------------------------------
    # Export / import as .cipher-skill.tar.gz
    # ------------------------------------------------------------------

    def export_package(self, package_id: str, output_path: str) -> str:
        """Export a package as a .cipher-skill.tar.gz archive."""
        pkg = self.get_package(package_id)
        if pkg is None:
            raise ValueError(f"Package not found: {package_id}")

        out = Path(output_path)
        if out.is_dir():
            out = out / f"{pkg.name}-{pkg.version}.cipher-skill.tar.gz"

        out.parent.mkdir(parents=True, exist_ok=True)

        with tarfile.open(str(out), "w:gz") as tar:
            # Write manifest
            manifest = {
                "package_id": pkg.package_id,
                "name": pkg.name,
                "domain": pkg.domain,
                "version": pkg.version,
                "description": pkg.description,
                "author": pkg.author,
                "license": pkg.license,
                "tags": pkg.tags,
                "checksum": pkg.checksum,
                "created_at": pkg.created_at,
                "updated_at": pkg.updated_at,
            }
            manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")
            info = tarfile.TarInfo(name="manifest.json")
            info.size = len(manifest_bytes)
            tar.addfile(info, BytesIO(manifest_bytes))

            # Write skill files
            for filename, content in pkg.files.items():
                data = content.encode("utf-8")
                info = tarfile.TarInfo(name=f"files/{filename}")
                info.size = len(data)
                tar.addfile(info, BytesIO(data))

        return str(out)

    def import_package(self, path: str) -> SkillPackage:
        """Import a package from a .cipher-skill.tar.gz archive."""
        archive_path = Path(path)
        if not archive_path.exists():
            raise FileNotFoundError(f"Archive not found: {path}")

        with tarfile.open(str(archive_path), "r:gz") as tar:
            # Read manifest
            manifest_member = tar.getmember("manifest.json")
            f = tar.extractfile(manifest_member)
            if f is None:
                raise ValueError("Could not read manifest.json from archive")
            manifest = json.loads(f.read().decode("utf-8"))

            # Read files
            files: dict[str, str] = {}
            for member in tar.getmembers():
                if member.name.startswith("files/") and member.isfile():
                    rel_name = member.name[len("files/") :]
                    # Prevent path traversal in archive member names
                    if ".." in rel_name or rel_name.startswith("/"):
                        continue
                    ef = tar.extractfile(member)
                    if ef is not None:
                        files[rel_name] = ef.read().decode("utf-8")

        pkg = SkillPackage(
            package_id=manifest.get("package_id", str(uuid.uuid4())),
            name=manifest["name"],
            domain=manifest.get("domain", ""),
            version=manifest.get("version", "0.1.0"),
            description=manifest.get("description", ""),
            author=manifest.get("author", ""),
            license=manifest.get("license", "AGPL-3.0"),
            tags=manifest.get("tags", []),
            files=files,
            checksum=manifest.get("checksum", ""),
            created_at=manifest.get("created_at", ""),
            updated_at=manifest.get("updated_at", ""),
        )

        # Verify checksum
        computed = self._compute_checksum(files)
        if pkg.checksum and pkg.checksum != computed:
            raise ValueError(
                f"Checksum mismatch: expected {pkg.checksum}, got {computed}"
            )
        pkg.checksum = computed

        return pkg

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_package(row: sqlite3.Row) -> SkillPackage:
        """Convert a database row to a SkillPackage."""
        return SkillPackage(
            package_id=row["package_id"],
            name=row["name"],
            domain=row["domain"],
            version=row["version"],
            description=row["description"],
            author=row["author"],
            license=row["license"],
            tags=json.loads(row["tags"]),
            files=json.loads(row["files"]),
            checksum=row["checksum"],
            downloads=row["downloads"],
            rating=row["rating"],
            ratings_count=row["ratings_count"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def close(self) -> None:
        """Close the database connection."""
        self.conn.close()
