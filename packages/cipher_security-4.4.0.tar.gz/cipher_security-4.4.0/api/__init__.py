# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0 — see LICENSE file for details.
# CIPHER is a trademark of defconxt.
"""CIPHER API — REST API, Marketplace, and Compliance Engine.

Phase 5 modules:
- server: Zero-dependency REST API (stdlib http.server)
- marketplace: Skill store with versioning, ratings, and packaging
- compliance: Automated compliance report generation (SOC2, PCI, HIPAA, NIST, CIS, ISO 27001, GDPR)
"""

from api.server import (
    CipherAPIServer,
    APIConfig,
    APIResponse,
    AuthHandler,
    RateLimiter,
)
from api.marketplace import (
    SkillMarketplace,
    SkillPackage,
    SkillReview,
    MarketplaceIndex,
)
from api.compliance import (
    ComplianceEngine,
    ComplianceFramework,
    ComplianceReport,
    ControlAssessment,
    ControlStatus,
)

__all__ = [
    # Server
    "CipherAPIServer",
    "APIConfig",
    "APIResponse",
    "AuthHandler",
    "RateLimiter",
    # Marketplace
    "SkillMarketplace",
    "SkillPackage",
    "SkillReview",
    "MarketplaceIndex",
    # Compliance
    "ComplianceEngine",
    "ComplianceFramework",
    "ComplianceReport",
    "ControlAssessment",
    "ControlStatus",
]
