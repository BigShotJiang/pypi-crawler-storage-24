# Copyright (c) 2026 defconxt. All rights reserved.
# Licensed under AGPL-3.0

"""CIPHER REST API — zero-dependency SaaS server.

Built on Python's ``http.server`` and ``json`` modules.  No FastAPI, no
Flask — just the standard library.  Provides authenticated, rate-limited
endpoints that expose CIPHER's scanning, memory, leaderboard, and
workflow-generation capabilities over HTTP/JSON.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import threading
import time
import traceback
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Callable
from urllib.parse import parse_qs, urlparse

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class APIConfig:
    """Server-level configuration with safe defaults."""

    host: str = "127.0.0.1"
    port: int = 8443
    api_version: str = "v1"
    rate_limit_rpm: int = 60
    max_request_size: int = 1_048_576  # 1 MB
    cors_origins: list[str] = field(default_factory=lambda: ["*"])
    require_auth: bool = True


# ---------------------------------------------------------------------------
# Response envelope
# ---------------------------------------------------------------------------


@dataclass
class APIResponse:
    """Uniform JSON response wrapper."""

    status: int = 200
    data: dict | None = None
    error: str | None = None
    meta: dict | None = None

    def to_json(self) -> str:
        payload: dict[str, Any] = {"status": self.status}
        if self.data is not None:
            payload["data"] = self.data
        if self.error is not None:
            payload["error"] = self.error
        if self.meta is not None:
            payload["meta"] = self.meta
        return json.dumps(payload, default=str)

    def to_bytes(self) -> bytes:
        return self.to_json().encode("utf-8")


# ---------------------------------------------------------------------------
# Rate limiter — sliding-window per client
# ---------------------------------------------------------------------------


class RateLimiter:
    """Token-bucket style sliding-window rate limiter."""

    def __init__(self, rpm: int = 60) -> None:
        self._rpm = rpm
        self._window = 60.0  # seconds
        self._requests: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def check(self, client_id: str) -> bool:
        """Return *True* if the request is allowed."""
        now = time.monotonic()
        with self._lock:
            timestamps = self._requests.setdefault(client_id, [])
            # Trim expired
            cutoff = now - self._window
            self._requests[client_id] = [t for t in timestamps if t > cutoff]
            timestamps = self._requests[client_id]
            if len(timestamps) >= self._rpm:
                return False
            timestamps.append(now)
            return True

    def _cleanup(self) -> None:
        """Remove all expired entries across every client."""
        now = time.monotonic()
        cutoff = now - self._window
        with self._lock:
            empty_keys: list[str] = []
            for cid, timestamps in self._requests.items():
                self._requests[cid] = [t for t in timestamps if t > cutoff]
                if not self._requests[cid]:
                    empty_keys.append(cid)
            for cid in empty_keys:
                del self._requests[cid]


# ---------------------------------------------------------------------------
# Auth — HMAC-SHA256 bearer tokens
# ---------------------------------------------------------------------------


class AuthHandler:
    """Simple HMAC-SHA256 token auth.

    Tokens are ``<client_id>:<random_hex>:<hmac_hex>``.  The HMAC is
    computed over ``client_id:random_hex`` using a server secret so
    tokens are tamper-proof without needing a database lookup.
    """

    def __init__(self) -> None:
        self._secret = os.environ.get("CIPHER_API_SECRET", secrets.token_hex(32))
        # scope registry: client_id -> granted scopes
        self._scopes: dict[str, list[str]] = {}

    # -- public API ---------------------------------------------------------

    def generate_token(self, client_id: str, scopes: list[str] | None = None) -> str:
        """Create a signed bearer token for *client_id*."""
        scopes = scopes or ["read", "write"]
        self._scopes[client_id] = scopes
        nonce = secrets.token_hex(16)
        payload = f"{client_id}:{nonce}"
        sig = hmac.new(
            self._secret.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()
        return f"{payload}:{sig}"

    def validate_token(self, token: str) -> dict[str, Any] | None:
        """Return ``{client_id, scopes}`` or *None* on failure."""
        parts = token.split(":")
        if len(parts) != 3:
            return None
        client_id, nonce, sig = parts
        expected = hmac.new(
            self._secret.encode(),
            f"{client_id}:{nonce}".encode(),
            hashlib.sha256,
        ).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        scopes = self._scopes.get(client_id, ["read"])
        return {"client_id": client_id, "scopes": scopes}

    def _hash_token(self, token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Route definition
# ---------------------------------------------------------------------------


@dataclass
class Route:
    """A single API route binding."""

    method: str
    path: str
    handler: Callable[..., APIResponse]
    auth_required: bool = True
    scopes: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Request handler (per-connection)
# ---------------------------------------------------------------------------


class CipherRequestHandler(BaseHTTPRequestHandler):
    """Thin HTTP layer — delegates business logic to the server."""

    # Silence default stderr logging
    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass

    # -- HTTP verbs ----------------------------------------------------------

    def do_GET(self) -> None:
        self._dispatch("GET")

    def do_POST(self) -> None:
        self._dispatch("POST")

    def do_PUT(self) -> None:
        self._dispatch("PUT")

    def do_DELETE(self) -> None:
        self._dispatch("DELETE")

    def do_OPTIONS(self) -> None:
        """CORS preflight."""
        self.send_response(204)
        self._handle_cors()
        self.end_headers()

    # -- internals -----------------------------------------------------------

    def _dispatch(self, method: str) -> None:
        server: CipherAPIServer = self.server  # type: ignore[assignment]
        body = self._parse_body() if method in ("POST", "PUT") else {}
        response = server._handle_request(method, self.path, body, dict(self.headers))
        self._send_response(response)

    def _parse_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        server: CipherAPIServer = self.server  # type: ignore[assignment]
        if length > server.config.max_request_size:
            return {"__error__": "payload too large"}
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {"__error__": "invalid JSON"}

    def _send_response(self, response: APIResponse) -> None:
        self.send_response(response.status)
        self._handle_cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(response.to_bytes())

    def _handle_cors(self) -> None:
        server: CipherAPIServer = self.server  # type: ignore[assignment]
        origin = self.headers.get("Origin", "*")
        allowed = server.config.cors_origins
        if "*" in allowed or origin in allowed:
            self.send_header("Access-Control-Allow-Origin", origin)
        else:
            self.send_header(
                "Access-Control-Allow-Origin", allowed[0] if allowed else ""
            )
        self.send_header(
            "Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS"
        )
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Max-Age", "86400")


# ---------------------------------------------------------------------------
# Main server
# ---------------------------------------------------------------------------


class CipherAPIServer(HTTPServer):
    """CIPHER SaaS REST API server.

    Registers all ``/v1/*`` routes and handles auth, rate-limiting,
    CORS, and request dispatch.
    """

    def __init__(self, config: APIConfig | None = None) -> None:
        self.config = config or APIConfig()
        self.auth = AuthHandler()
        self.rate_limiter = RateLimiter(rpm=self.config.rate_limit_rpm)
        self._start_time = time.time()
        self._request_count = 0
        self._lock = threading.Lock()

        # Route table
        self._routes: list[Route] = []
        self._register_routes()

        super().__init__(
            (self.config.host, self.config.port),
            CipherRequestHandler,
        )

    # -- route registration -------------------------------------------------

    def _register_routes(self) -> None:
        v = self.config.api_version

        # Health
        self._routes.append(
            Route("GET", f"/{v}/health", self._handle_health, auth_required=False)
        )

        # Stats
        self._routes.append(Route("GET", f"/{v}/stats", self._handle_stats))

        # Scanning
        self._routes.append(
            Route("POST", f"/{v}/scan", self._handle_scan, scopes=["write"])
        )
        self._routes.append(
            Route("POST", f"/{v}/diff", self._handle_diff, scopes=["write"])
        )
        self._routes.append(
            Route("POST", f"/{v}/secrets", self._handle_secrets, scopes=["write"])
        )

        # Skills
        self._routes.append(Route("GET", f"/{v}/skills", self._handle_skills_list))
        self._routes.append(
            Route("GET", f"/{v}/skills/search", self._handle_skills_search)
        )

        # Memory
        self._routes.append(
            Route(
                "POST",
                f"/{v}/memory/store",
                self._handle_memory_store,
                scopes=["write"],
            )
        )
        self._routes.append(
            Route("POST", f"/{v}/memory/search", self._handle_memory_search)
        )
        self._routes.append(
            Route("GET", f"/{v}/memory/stats", self._handle_memory_stats)
        )

        # Quality scoring
        self._routes.append(
            Route("POST", f"/{v}/score", self._handle_score, scopes=["write"])
        )

        # Leaderboard
        self._routes.append(Route("GET", f"/{v}/leaderboard", self._handle_leaderboard))
        self._routes.append(
            Route(
                "GET", f"/{v}/leaderboard/dashboard", self._handle_leaderboard_dashboard
            )
        )

        # Workflow generation
        self._routes.append(
            Route("POST", f"/{v}/workflow", self._handle_workflow, scopes=["write"])
        )

    # -- dispatch engine ----------------------------------------------------

    def _handle_request(
        self, method: str, path: str, body: dict, headers: dict
    ) -> APIResponse:
        t0 = time.time()

        with self._lock:
            self._request_count += 1

        # Parse errors from body parsing
        if "__error__" in body:
            return APIResponse(
                status=400,
                error=body["__error__"],
                meta=self._meta(t0),
            )

        # Match route
        route = self._match_route(method, path)
        if route is None:
            return APIResponse(status=404, error="not found", meta=self._meta(t0))

        # Auth
        if route.auth_required and self.config.require_auth:
            token = self._extract_auth(headers)
            if token is None:
                return APIResponse(
                    status=401, error="missing authorization", meta=self._meta(t0)
                )
            identity = self.auth.validate_token(token)
            if identity is None:
                return APIResponse(
                    status=401, error="invalid token", meta=self._meta(t0)
                )
            # Scope check
            if route.scopes:
                if not any(s in identity["scopes"] for s in route.scopes):
                    return APIResponse(
                        status=403, error="insufficient scope", meta=self._meta(t0)
                    )
            client_id = identity["client_id"]
        else:
            client_id = self._client_ip(headers)

        # Rate limit
        if not self.rate_limiter.check(client_id):
            return APIResponse(
                status=429, error="rate limit exceeded", meta=self._meta(t0)
            )

        # Parse query string
        parsed = urlparse(path)
        query_params = parse_qs(parsed.query)

        # Execute handler
        try:
            response = route.handler(body=body, params=query_params, headers=headers)
        except Exception as exc:
            tb = traceback.format_exc()
            logger.error("Handler error: %s\n%s", exc, tb)
            # Security: never expose tracebacks or internal paths to clients
            return APIResponse(
                status=500,
                error="internal server error",
                meta=self._meta(t0),
            )

        response.meta = self._meta(t0)
        return response

    def _match_route(self, method: str, path: str) -> Route | None:
        parsed_path = urlparse(path).path.rstrip("/") or "/"
        for route in self._routes:
            if route.method == method and route.path == parsed_path:
                return route
        return None

    def _extract_auth(self, headers: dict) -> str | None:
        auth = headers.get("Authorization") or headers.get("authorization")
        if auth and auth.lower().startswith("bearer "):
            return auth[7:].strip()
        return None

    @staticmethod
    def _client_ip(headers: dict) -> str:
        return (
            headers.get("X-Forwarded-For", "").split(",")[0].strip()
            or headers.get("X-Real-IP", "")
            or "unknown"
        )

    def _meta(self, t0: float) -> dict:
        return {
            "version": self.config.api_version,
            "elapsed_ms": round((time.time() - t0) * 1000, 2),
        }

    @staticmethod
    def _validate_scan_target(target: str) -> bool:
        """Validate scan target to prevent SSRF against internal networks.

        Rejects: private IPs (RFC 1918), loopback, link-local, metadata endpoints.
        Handles: octal, hex, decimal IP encoding bypasses.
        Allows: public hostnames and IPs only.
        """
        import ipaddress
        import socket
        from urllib.parse import urlparse as _urlparse

        if not target or not isinstance(target, str):
            return False

        # Reject absurdly long URLs (DoS prevention)
        if len(target) > 2048:
            return False

        # Extract hostname from URL or use target directly
        try:
            parsed = _urlparse(target if "://" in target else f"http://{target}")
            host = parsed.hostname or target
        except Exception:
            return False

        if not host:
            return False

        # Block known cloud metadata endpoints
        _blocked_hosts = {
            "metadata.google.internal",
            "metadata.google",
            "169.254.169.254",  # AWS/GCP/Azure metadata
            "fd00:ec2::254",  # AWS IPv6 metadata
        }
        if host.lower() in _blocked_hosts:
            return False

        # Resolve hostname to catch octal/hex/decimal IP encodings
        # and DNS rebinding to private IPs
        try:
            resolved = socket.getaddrinfo(
                host, None, socket.AF_UNSPEC, socket.SOCK_STREAM
            )
            for family, stype, proto, canonname, sockaddr in resolved:
                ip_str = sockaddr[0]
                addr = ipaddress.ip_address(ip_str)
                if (
                    addr.is_private
                    or addr.is_loopback
                    or addr.is_link_local
                    or addr.is_reserved
                ):
                    return False
        except (socket.gaierror, OSError):
            # DNS resolution failed — check if host looks like an IP encoding
            # (octal 0177.0.0.1, hex 0x7f000001, decimal 2130706433)
            try:
                addr = ipaddress.ip_address(host)
                if (
                    addr.is_private
                    or addr.is_loopback
                    or addr.is_link_local
                    or addr.is_reserved
                ):
                    return False
                # Valid public IP that didn't resolve — allow
                return True
            except ValueError:
                pass
            # Block localhost variants
            if host.lower() in (
                "localhost",
                "localhost.localdomain",
                "0.0.0.0",  # nosec B104
            ):
                return False
            # Detect numeric IP encodings (octal/hex/decimal) that
            # ipaddress.ip_address() can't parse but the OS resolves
            import re

            if re.match(r"^[0-9x.]+$", host, re.IGNORECASE):
                # Looks like an encoded IP — fail closed
                return False
            # Regular hostname that just can't resolve (DNS down) — allow
            # The actual scan will fail anyway if the host is unreachable

        return True

    # -- threading helpers --------------------------------------------------

    def serve_forever_threaded(self) -> threading.Thread:
        """Start ``serve_forever`` in a daemon thread and return it."""
        t = threading.Thread(target=self.serve_forever, daemon=True)
        t.start()
        return t

    # -- route handlers -----------------------------------------------------
    # Each handler receives ``body``, ``params``, ``headers`` as kwargs.

    def _handle_health(self, **_kw: Any) -> APIResponse:
        uptime = time.time() - self._start_time
        return APIResponse(
            data={
                "status": "healthy",
                "uptime_s": round(uptime, 2),
                "version": self.config.api_version,
            }
        )

    def _handle_stats(self, **_kw: Any) -> APIResponse:
        import sys

        return APIResponse(
            data={
                "requests_served": self._request_count,
                "uptime_s": round(time.time() - self._start_time, 2),
                "python_version": sys.version,
                "rate_limit_rpm": self.config.rate_limit_rpm,
                "memory_rss_kb": self._get_rss_kb(),
            }
        )

    def _handle_scan(self, *, body: dict, **_kw: Any) -> APIResponse:
        target = body.get("target")
        if not target:
            return APIResponse(status=400, error="'target' is required")
        # Security: validate scan target to prevent SSRF against internal networks
        target = str(target).strip()
        if not self._validate_scan_target(target):
            return APIResponse(
                status=400,
                error="invalid scan target: internal/private addresses are not permitted",
            )
        profile = body.get("profile", "standard")
        severity = body.get("severity", "medium")
        from pipeline.scanner import NucleiRunner, ScanProfile
        import shutil

        scan_id = secrets.token_hex(8)
        if not shutil.which("nuclei"):
            return APIResponse(
                data={
                    "scan_id": scan_id,
                    "target": target,
                    "profile": profile,
                    "min_severity": severity,
                    "status": "error",
                    "error": "nuclei binary not found in PATH — install via: go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
                    "findings": [],
                }
            )
        runner = NucleiRunner()
        try:
            result = runner.scan(
                target, profile=ScanProfile.from_domain(profile), severity=severity
            )
            return APIResponse(
                data={
                    "scan_id": scan_id,
                    "target": target,
                    "profile": profile,
                    "min_severity": severity,
                    "status": "completed",
                    "findings": [
                        {
                            "id": f.template_id,
                            "name": f.name,
                            "severity": f.severity,
                            "url": f.matched_at,
                            "description": f.description,
                        }
                        for f in result.findings
                    ]
                    if result.findings
                    else [],
                    "total_findings": len(result.findings) if result.findings else 0,
                }
            )
        except Exception:
            return APIResponse(status=500, error="Scan failed — check server logs")

    def _handle_diff(self, *, body: dict, **_kw: Any) -> APIResponse:
        diff_text = body.get("diff_text")
        if not diff_text:
            return APIResponse(status=400, error="'diff_text' is required")
        from pipeline.github_actions import SecurityDiffAnalyzer

        analyzer = SecurityDiffAnalyzer()
        analysis = analyzer.analyze_diff(diff_text)
        return APIResponse(
            data={
                "risk_level": analysis.risk_level.value
                if hasattr(analysis.risk_level, "value")
                else str(analysis.risk_level),
                "files_changed": analysis.files_changed,
                "auth_changes": analysis.auth_changes,
                "sql_changes": analysis.sql_changes,
                "crypto_changes": analysis.crypto_changes,
                "secrets_found": len(analysis.secrets),
                "endpoints_added": analysis.endpoints_added,
                "has_security_findings": analysis.has_security_findings,
                "summary": analysis.summary,
            }
        )

    def _handle_secrets(self, *, body: dict, **_kw: Any) -> APIResponse:
        diff_text = body.get("diff_text")
        if not diff_text:
            return APIResponse(status=400, error="'diff_text' is required")
        # Lightweight secret patterns
        patterns = {
            "aws_key": r"AKIA[0-9A-Z]{16}",
            "generic_secret": r"(?i)(secret|password|token|apikey)\s*[=:]\s*['\"][^\s'\"]{8,}",
            "private_key": r"-----BEGIN\s+(RSA|EC|DSA|OPENSSH)\s+PRIVATE\s+KEY-----",
            "github_token": r"gh[pousr]_[A-Za-z0-9_]{36,}",
        }
        findings: list[dict] = []
        for name, pat in patterns.items():
            for m in re.finditer(pat, diff_text):
                findings.append(
                    {
                        "type": name,
                        "line": diff_text[: m.start()].count("\n") + 1,
                        "match": m.group()[:8] + "****",
                    }
                )
        return APIResponse(
            data={
                "secrets_found": len(findings),
                "findings": findings,
            }
        )

    def _handle_skills_list(self, **_kw: Any) -> APIResponse:
        from pathlib import Path

        skills_dir = Path("skills")
        domains = {}
        if skills_dir.exists():
            for d in sorted(skills_dir.iterdir()):
                if d.is_dir() and not d.name.startswith("."):
                    techs = d / "techniques"
                    if techs.exists():
                        count = len([t for t in techs.iterdir() if t.is_dir()])
                    else:
                        count = len(
                            [
                                t
                                for t in d.iterdir()
                                if t.is_dir() and (t / "SKILL.md").exists()
                            ]
                        )
                    domains[d.name] = count
        return APIResponse(
            data={
                "domains": domains,
                "count": len(domains),
                "total_techniques": sum(domains.values()),
            }
        )

    def _handle_skills_search(self, *, params: dict, **_kw: Any) -> APIResponse:
        query = params.get("q", [""])[0]
        if not query:
            return APIResponse(status=400, error="'q' query parameter is required")
        from pathlib import Path

        q = query.lower()
        results = []
        for skill_md in Path("skills").rglob("SKILL.md"):
            name = skill_md.parent.name
            if q in name or q in str(skill_md.parent):
                results.append({"name": name, "path": str(skill_md.parent)})
                if len(results) >= 20:
                    break
        return APIResponse(
            data={"query": query, "results": results, "total": len(results)}
        )

    def _handle_memory_store(self, *, body: dict, **_kw: Any) -> APIResponse:
        content = body.get("content")
        if not content:
            return APIResponse(status=400, error="'content' is required")
        from memory.core.engine import CipherMemory, MemoryEntry, MemoryType

        memory = CipherMemory()
        entry = MemoryEntry(
            content=content,
            memory_type=MemoryType(body.get("type", "note")),
            severity=body.get("severity", ""),
            engagement_id=body.get("engagement_id", ""),
            tags=body.get("tags", []),
        )
        entry_id = memory.store(entry)
        memory.close()
        return APIResponse(
            status=201,
            data={
                "entry_id": entry_id,
                "type": entry.memory_type.value,
                "stored": True,
            },
        )

    def _handle_memory_search(self, *, body: dict, **_kw: Any) -> APIResponse:
        query = body.get("query")
        if not query:
            return APIResponse(status=400, error="'query' is required")
        from memory.core.engine import CipherMemory

        memory = CipherMemory()
        limit = body.get("limit", 10)
        results = memory.search(query, limit=limit)
        memory.close()
        return APIResponse(
            data={
                "query": query,
                "results": [
                    {
                        "content": r.content,
                        "type": r.memory_type.value
                        if hasattr(r.memory_type, "value")
                        else str(r.memory_type),
                        "severity": r.severity,
                        "created": r.created_at,
                    }
                    for r in results
                ],
                "total": len(results),
            }
        )

    def _handle_memory_stats(self, **_kw: Any) -> APIResponse:
        from memory.core.engine import CipherMemory

        memory = CipherMemory()
        stats = memory.stats()
        memory.close()
        return APIResponse(data=stats)

    def _handle_score(self, *, body: dict, **_kw: Any) -> APIResponse:
        query = body.get("query")
        response_text = body.get("response")
        if not query or not response_text:
            return APIResponse(status=400, error="'query' and 'response' are required")
        from memory.core.evolution import ResponseScorer

        scorer = ResponseScorer()
        mode = body.get("mode", "")
        scored = scorer.score(query=query, response=response_text, mode=mode)
        return APIResponse(
            data={
                "score": scored.score,
                "votes": scored.votes,
                "feedback": scored.feedback,
            }
        )

    def _handle_leaderboard(self, **_kw: Any) -> APIResponse:
        from autonomous.leaderboard import SkillLeaderboard

        lb = SkillLeaderboard()
        top = lb.get_top_skills(n=20)
        result = {
            "top_skills": [
                {
                    "rank": e.rank,
                    "path": e.skill_path,
                    "score": e.score,
                    "invocations": e.invocations,
                    "trend": e.trend,
                }
                for e in top
            ],
            "total_tracked": len(top),
        }
        lb.close()
        return APIResponse(data=result)

    def _handle_leaderboard_dashboard(self, **_kw: Any) -> APIResponse:
        from autonomous.leaderboard import SkillLeaderboard

        lb = SkillLeaderboard()
        dashboard = lb.get_dashboard()
        lb.close()
        return APIResponse(data=dashboard)

    def _handle_workflow(self, *, body: dict, **_kw: Any) -> APIResponse:
        from pipeline.github_actions import WorkflowGenerator

        profile = body.get("profile", "standard")
        gen = WorkflowGenerator()
        workflow_yaml = gen.generate_workflow(scan_profile=profile)
        return APIResponse(data={"profile": profile, "workflow": workflow_yaml})

    # -- helpers ------------------------------------------------------------

    @staticmethod
    def _get_rss_kb() -> int:
        """Best-effort RSS in KB (Linux ``/proc/self/status``)."""
        try:
            with open("/proc/self/status", encoding="utf-8") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        return int(line.split()[1])
        except (FileNotFoundError, ValueError, IndexError):
            pass
        return -1


# ---------------------------------------------------------------------------
# Convenience launcher
# ---------------------------------------------------------------------------


def main() -> None:  # pragma: no cover
    """Run the CIPHER API server from the CLI."""
    config = APIConfig()
    server = CipherAPIServer(config)
    print(f"CIPHER API listening on {config.host}:{config.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
        print("\nShutdown complete.")


if __name__ == "__main__":
    main()
