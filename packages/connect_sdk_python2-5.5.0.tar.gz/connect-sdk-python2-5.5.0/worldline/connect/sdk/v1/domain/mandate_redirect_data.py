# -*- coding: utf-8 -*-
#
# This class was auto-generated from the API references found at
# https://apireference.connect.worldline-solutions.com/
#
from worldline.connect.sdk.v1.domain.redirect_data_base import RedirectDataBase


class MandateRedirectData(RedirectDataBase):

    def to_dictionary(self):
        dictionary = super(MandateRedirectData, self).to_dictionary()
        return dictionary

    def from_dictionary(self, dictionary):
        super(MandateRedirectData, self).from_dictionary(dictionary)
        return self
