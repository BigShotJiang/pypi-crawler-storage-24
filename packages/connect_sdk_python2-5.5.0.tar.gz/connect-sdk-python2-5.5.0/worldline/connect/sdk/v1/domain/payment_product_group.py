# -*- coding: utf-8 -*-
#
# This class was auto-generated from the API references found at
# https://apireference.connect.worldline-solutions.com/
#
from worldline.connect.sdk.domain.data_object import DataObject
from worldline.connect.sdk.v1.domain.account_on_file import AccountOnFile
from worldline.connect.sdk.v1.domain.click_to_pay_configuration import ClickToPayConfiguration
from worldline.connect.sdk.v1.domain.payment_product_display_hints import PaymentProductDisplayHints
from worldline.connect.sdk.v1.domain.payment_product_field import PaymentProductField


class PaymentProductGroup(DataObject):
    """
    | Definition of the details of a single payment product group
    """

    __accounts_on_file = None
    __allows_click_to_pay = None
    __allows_installments = None
    __click_to_pay_configuration = None
    __device_fingerprint_enabled = None
    __display_hints = None
    __fields = None
    __id = None

    @property
    def accounts_on_file(self):
        """
        | Only populated in the Client API

        Type: list[:class:`worldline.connect.sdk.v1.domain.account_on_file.AccountOnFile`]
        """
        return self.__accounts_on_file

    @accounts_on_file.setter
    def accounts_on_file(self, value):
        self.__accounts_on_file = value

    @property
    def allows_click_to_pay(self):
        """
        | Indicates if the product supports Click to Pay: 
        
        * true - This payment supports Click to Pay
        * false - This payment does not support Click to Pay

        Type: bool
        """
        return self.__allows_click_to_pay

    @allows_click_to_pay.setter
    def allows_click_to_pay(self, value):
        self.__allows_click_to_pay = value

    @property
    def allows_installments(self):
        """
        | Indicates if the product supports installments
        
        * true - This payment supports installments
        * false - This payment does not support installments

        Type: bool
        """
        return self.__allows_installments

    @allows_installments.setter
    def allows_installments(self, value):
        self.__allows_installments = value

    @property
    def click_to_pay_configuration(self):
        """
        | Object containing the configuration parameters for each scheme supporting Click to Pay for the provided country and currency combination. These parameters initialize SRC System SDK for the scheme. This object is only returned for card products with allowsClickToPay set to true.

        Type: :class:`worldline.connect.sdk.v1.domain.click_to_pay_configuration.ClickToPayConfiguration`
        """
        return self.__click_to_pay_configuration

    @click_to_pay_configuration.setter
    def click_to_pay_configuration(self, value):
        self.__click_to_pay_configuration = value

    @property
    def device_fingerprint_enabled(self):
        """
        | Indicates if device fingerprint is enabled for the product group
        
        * true
        * false

        Type: bool
        """
        return self.__device_fingerprint_enabled

    @device_fingerprint_enabled.setter
    def device_fingerprint_enabled(self, value):
        self.__device_fingerprint_enabled = value

    @property
    def display_hints(self):
        """
        | Object containing display hints like the order of the group when shown in a list, the name of the group and the logo. Note that the order of the group is the lowest order among the payment products that belong to the group.

        Type: :class:`worldline.connect.sdk.v1.domain.payment_product_display_hints.PaymentProductDisplayHints`
        """
        return self.__display_hints

    @display_hints.setter
    def display_hints(self, value):
        self.__display_hints = value

    @property
    def fields(self):
        """
        | Object containing all the fields and their details that are associated with this payment product group. If you are not interested in the these fields you can have us filter them out (using hide=fields in the query-string)

        Type: list[:class:`worldline.connect.sdk.v1.domain.payment_product_field.PaymentProductField`]
        """
        return self.__fields

    @fields.setter
    def fields(self, value):
        self.__fields = value

    @property
    def id(self):
        """
        | The ID of the payment product group in our system

        Type: str
        """
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    def to_dictionary(self):
        dictionary = super(PaymentProductGroup, self).to_dictionary()
        if self.accounts_on_file is not None:
            dictionary['accountsOnFile'] = []
            for element in self.accounts_on_file:
                if element is not None:
                    dictionary['accountsOnFile'].append(element.to_dictionary())
        if self.allows_click_to_pay is not None:
            dictionary['allowsClickToPay'] = self.allows_click_to_pay
        if self.allows_installments is not None:
            dictionary['allowsInstallments'] = self.allows_installments
        if self.click_to_pay_configuration is not None:
            dictionary['clickToPayConfiguration'] = self.click_to_pay_configuration.to_dictionary()
        if self.device_fingerprint_enabled is not None:
            dictionary['deviceFingerprintEnabled'] = self.device_fingerprint_enabled
        if self.display_hints is not None:
            dictionary['displayHints'] = self.display_hints.to_dictionary()
        if self.fields is not None:
            dictionary['fields'] = []
            for element in self.fields:
                if element is not None:
                    dictionary['fields'].append(element.to_dictionary())
        if self.id is not None:
            dictionary['id'] = self.id
        return dictionary

    def from_dictionary(self, dictionary):
        super(PaymentProductGroup, self).from_dictionary(dictionary)
        if 'accountsOnFile' in dictionary:
            if not isinstance(dictionary['accountsOnFile'], list):
                raise TypeError('value \'{}\' is not a list'.format(dictionary['accountsOnFile']))
            self.accounts_on_file = []
            for element in dictionary['accountsOnFile']:
                value = AccountOnFile()
                self.accounts_on_file.append(value.from_dictionary(element))
        if 'allowsClickToPay' in dictionary:
            self.allows_click_to_pay = dictionary['allowsClickToPay']
        if 'allowsInstallments' in dictionary:
            self.allows_installments = dictionary['allowsInstallments']
        if 'clickToPayConfiguration' in dictionary:
            if not isinstance(dictionary['clickToPayConfiguration'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['clickToPayConfiguration']))
            value = ClickToPayConfiguration()
            self.click_to_pay_configuration = value.from_dictionary(dictionary['clickToPayConfiguration'])
        if 'deviceFingerprintEnabled' in dictionary:
            self.device_fingerprint_enabled = dictionary['deviceFingerprintEnabled']
        if 'displayHints' in dictionary:
            if not isinstance(dictionary['displayHints'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['displayHints']))
            value = PaymentProductDisplayHints()
            self.display_hints = value.from_dictionary(dictionary['displayHints'])
        if 'fields' in dictionary:
            if not isinstance(dictionary['fields'], list):
                raise TypeError('value \'{}\' is not a list'.format(dictionary['fields']))
            self.fields = []
            for element in dictionary['fields']:
                value = PaymentProductField()
                self.fields.append(value.from_dictionary(element))
        if 'id' in dictionary:
            self.id = dictionary['id']
        return self
