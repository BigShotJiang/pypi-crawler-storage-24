"""SzyMemory - 轻量级 MCP Server，为 AI 编程助手提供跨会话持久记忆能力"""

__version__ = "3.0.0"
