# mcpzoo-sysinfo

> 系统信息 — 获取操作系统和 Python 环境信息

## Installation

```bash
uvx mcpzoo-sysinfo
```

## uvx JSON

```json
{
  "mcpServers": {
    "sysinfo": {
      "args": ["mcpzoo-sysinfo"],
      "command": "uvx"
    }
  }
}
```
