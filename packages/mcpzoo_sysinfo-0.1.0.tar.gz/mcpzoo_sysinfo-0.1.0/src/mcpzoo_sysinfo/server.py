import sys
import platform
import os
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("sysinfo")


@mcp.tool()
def get_sysinfo() -> str:
    """获取基础的操作系统和 Python 环境信息。"""
    info = {
        "os": os.name,
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "python_compiler": platform.python_compiler(),
        "python_build": platform.python_build(),
        "cwd": os.getcwd(),
        "cpu_count": os.cpu_count()
    }
    return json.dumps(info, indent=2, ensure_ascii=False)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
