def say_hello():
    print("Hello, World! 砺智科技!")