import{b as r}from"./graph-ClIufvaj.js";var e=4;function a(o){return r(o,e)}export{a as c};
