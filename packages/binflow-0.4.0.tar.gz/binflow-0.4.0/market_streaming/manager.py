"""Fachada principal del sistema de streaming de mercado.

``Manager`` es la unica clase que el usuario necesita para consumir
datos de mercado. Internamente arranca un thread dedicado con un event
loop asyncio donde corren los workers WebSocket. La API publica es
sincrona: no requiere ``async``/``await``.

Flujo tipico::

    from market_streaming import Manager, Config

    config = Config(stream_type="trade", symbols=["BTCUSDT"], max_history=500)

    with Manager(config) as mgr:
        trade = mgr.get("BTCUSDT")       # ultimo dato
        recent = mgr.get_recent("BTCUSDT")  # historial
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
import weakref
from typing import Any

from .cache import MarketDataCache
from .config import Market, Config
from .exceptions import StreamNotFoundError

# Mapping de Market de binflow a market strings de panzer
_PANZER_MARKET = {
    Market.SPOT: "spot",
    Market.FUTURES_USD: "um",
    Market.FUTURES_COIN: "cm",
}
from .health import HealthMonitor
from .logging_config import setup_logging, teardown_logging
from .models import (
    AggTrade,
    StreamStatus,
    StreamType,
    SystemHealth,
    Trade,
)
from panzer import BinancePublicClient

from .worker import Worker

logger = logging.getLogger(__name__)


def _run_event_loop(loop: asyncio.AbstractEventLoop) -> None:
    """Ejecuta el event loop asyncio en el thread dedicado.

    Funcion module-level para evitar que el Thread mantenga una referencia
    fuerte al Manager (via bound method), lo que impediria su recoleccion
    por el GC cuando el usuario reasigna la variable sin llamar a stop().
    """
    asyncio.set_event_loop(loop)
    try:
        loop.run_forever()
    finally:
        pending = asyncio.all_tasks(loop)
        for task in pending:
            task.cancel()
        if pending:
            loop.run_until_complete(asyncio.wait(pending, timeout=5.0))
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.run_until_complete(loop.shutdown_default_executor())


class Manager:
    """Fachada principal para consumir datos de mercado de Binance.

    Cada Manager opera sobre **un mercado y un tipo de stream**,
    definidos en el ``Config``. Multiples simbolos se multiplexan
    en pocas conexiones WebSocket (hasta 200 simbolos por conexion).

    Datos
    -----
    - ``.get(symbol)`` -- ultimo dato (Trade, OrderBookSnapshot, Kline, etc.)
    - ``.get()`` -- dict con todos los simbolos
    - ``.get_recent(symbol)`` -- historial reciente (lista)

    El tipo de dato devuelto depende del ``stream_type`` del Config.
    Los datos viven en un cache permanente en memoria; las lecturas
    son de solo lectura y no consumen ni borran datos.

    Ciclo de vida
    -------------
    - ``Manager(config)`` -- crea el manager (no conecta aun)
    - ``.start()`` -- arranca thread + WebSockets
    - ``.stop()`` -- cierra todo de forma limpia
    - Soporta ``with Manager(config) as mgr:``
    - Si se pierde la referencia sin llamar a ``.stop()``, el GC
      lo limpia automaticamente.

    Ejemplo::

        config = Config(
            stream_type="trade",
            symbols=["BTCUSDT", "ETHUSDT"],
            max_history=500,
        )
        with Manager(config) as mgr:
            trade = mgr.get("BTCUSDT")
            recent = mgr.get_recent("BTCUSDT", limit=50)

    Gestion dinamica de simbolos::

        mgr.add_symbols(["SOLUSDT", "ADAUSDT"])
        mgr.remove_symbols("ADAUSDT")

    Observabilidad::

        mgr.get_health()    # SystemHealth
        mgr.get_stats()     # dict resumen
        mgr.is_healthy()    # bool
        Manager.dashboard() # todas las instancias en memoria
    """

    _instances: weakref.WeakSet[Manager] = weakref.WeakSet()

    def __init__(self, config: Config | None = None) -> None:
        self._config = config or Config()
        self._cache = MarketDataCache(self._config)
        self._health_monitor = HealthMonitor(self._config)
        self._rest_client = BinancePublicClient(
            market=_PANZER_MARKET[self._config.market],
        )
        self._workers: dict[str, Worker] = {}
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._started_at: float = 0.0
        self._running = False
        self._lock = threading.Lock()

        setup_logging(self._config)
        Manager._instances.add(self)

        # Auto-registrar symbols del config
        if self._config.symbols:
            self.add_symbols(self._config.symbols)

    # ------------------------------------------------------------------
    # Dashboard de instancias
    # ------------------------------------------------------------------

    @classmethod
    def dashboard(cls) -> list[str]:
        """Muestra todas las instancias de Manager en memoria.

        Returns
        -------
        list[str]
            Representacion de cada instancia.
        """
        instances = list(cls._instances)
        if not instances:
            print("No hay instancias de Manager en memoria.")
            return []
        lines = []
        for i, mgr in enumerate(instances):
            line = f"  [{i}] {mgr!r}"
            lines.append(line)
        header = f"Manager: {len(instances)} instancia(s) en memoria"
        print(header)
        for line in lines:
            print(line)
        return [repr(m) for m in instances]

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "running" if self._running else "stopped"
        cfg = self._config
        market = cfg.market.value
        stream_type = cfg.stream_type.value
        symbols = self._get_all_symbols()
        parts = [f"status={status}", f"market={market}",
                 f"stream_type={stream_type}", f"symbols={len(symbols)}"]
        # Mostrar campos de cache relevantes al tipo de stream
        if stream_type in ("trade", "agg_trade"):
            parts.append(f"max_history={cfg.max_history}")
        elif stream_type == "depth":
            parts.append(f"depth={cfg.depth}")
        elif stream_type == "kline":
            parts.append(f"interval={cfg.interval}")
        if self._running:
            uptime = time.time() - self._started_at
            h, rem = divmod(int(uptime), 3600)
            m, s = divmod(rem, 60)
            parts.append(f"uptime={h:02d}:{m:02d}:{s:02d}")
        return f"Manager({', '.join(parts)})"

    def __del__(self) -> None:
        try:
            self.stop()
        except Exception:
            pass

    def __enter__(self) -> Manager:
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.stop()

    # ------------------------------------------------------------------
    # Arranque y parada
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Arranca el motor de streaming en un thread dedicado.

        Si se registraron streams antes de llamar a ``start()``, se
        arrancan automaticamente al iniciar el event loop.
        """
        if self._running:
            logger.warning("Manager ya está en ejecución")
            return

        self._loop = asyncio.new_event_loop()
        self._started_at = time.time()
        self._running = True

        self._thread = threading.Thread(
            target=_run_event_loop,
            args=(self._loop,),
            name="market-stream-loop",
            daemon=True,
        )
        self._thread.start()

        # Arrancar workers registrados antes de start()
        with self._lock:
            pending = list(self._workers.values())
        for worker in pending:
            self._loop.call_soon_threadsafe(worker.start, self._loop)

        logger.info("Manager iniciado (%d streams pendientes arrancados)",
                     len(pending))

    def stop(self) -> None:
        """Detiene todos los streams y libera recursos de forma limpia."""
        if not self._running:
            return

        self._running = False
        logger.info("Deteniendo Manager...")

        loop = self._loop
        if loop is not None and not loop.is_closed():
            future = asyncio.run_coroutine_threadsafe(
                self._stop_all_workers(), loop
            )
            try:
                future.result(timeout=10.0)
            except Exception as exc:
                logger.warning("Error deteniendo workers: %s", exc)

            loop.call_soon_threadsafe(loop.stop)

        if self._thread is not None:
            self._thread.join(timeout=5.0)
            if self._thread.is_alive():
                logger.warning("Thread del event loop no terminó a tiempo")

        if loop is not None and not loop.is_closed():
            loop.close()

        self._loop = None
        self._thread = None
        self._workers.clear()
        logger.info("Manager detenido")
        teardown_logging()

    # ------------------------------------------------------------------
    # Gestion de simbolos
    # ------------------------------------------------------------------

    def add_symbols(self, symbols: str | list[str], batch_size: int = 200) -> None:
        """Anade simbolos al manager.

        Crea workers ``Worker`` agrupando los simbolos en
        lotes de ``batch_size``. Si el manager ya esta arrancado, los
        workers se inician inmediatamente; si no, quedan pendientes hasta
        ``start()``.

        Parameters
        ----------
        symbols : str | list[str]
            Simbolo o lista de simbolos (case-insensitive).
        batch_size : int
            Simbolos por conexion WebSocket (default: 200).
        """
        if isinstance(symbols, str):
            symbols = [symbols]
        symbols = [s.upper() for s in symbols]

        st = self._config.stream_type
        existing = self._get_all_symbols()
        new_symbols = [s for s in symbols if s not in existing]
        if not new_symbols:
            return

        for i in range(0, len(new_symbols), batch_size):
            batch = new_symbols[i:i + batch_size]
            worker_id = f"{st.value}_{i // batch_size}"

            with self._lock:
                if worker_id in self._workers:
                    # Ampliar worker existente si esta corriendo
                    worker = self._workers[worker_id]
                    if isinstance(worker, Worker) and self._running:
                        for sym in batch:
                            if self._loop is not None and not self._loop.is_closed():
                                future = asyncio.run_coroutine_threadsafe(
                                    worker.subscribe(sym), self._loop
                                )
                                future.result(timeout=5.0)
                    continue

            kwargs: dict[str, Any] = {
                "worker_id": worker_id,
                "stream_type": st,
                "symbols": batch,
                "config": self._config,
                "cache": self._cache,
                "rest_client": self._rest_client,
            }
            if st == StreamType.DEPTH:
                kwargs["depth"] = self._config.depth
            if st == StreamType.KLINE:
                kwargs["interval"] = self._config.interval

            worker = Worker(**kwargs)
            self._register_and_start(worker_id, worker)

        logger.info("Registrados %d simbolos de %s", len(new_symbols), st.value)

    def remove_symbols(self, symbols: str | list[str]) -> None:
        """Elimina simbolos del manager.

        Desuscribe los simbolos de sus workers y limpia sus datos
        del cache.

        Parameters
        ----------
        symbols : str | list[str]
            Simbolo o lista de simbolos (case-insensitive).
        """
        if isinstance(symbols, str):
            symbols = [symbols]
        symbols = {s.upper() for s in symbols}

        if self._running and self._loop is not None and not self._loop.is_closed():
            with self._lock:
                workers = list(self._workers.values())
            for worker in workers:
                for sym in symbols:
                    if sym.lower() not in worker._symbols:
                        continue
                    try:
                        future = asyncio.run_coroutine_threadsafe(
                            worker.unsubscribe(sym), self._loop
                        )
                        future.result(timeout=5.0)
                    except Exception as exc:
                        logger.warning("Error desuscribiendo %s: %s", sym, exc)

        for sym in symbols:
            self._cache.remove_symbol(sym)

        logger.info("Eliminados %d simbolos", len(symbols))

    # ------------------------------------------------------------------
    # Acceso a datos de mercado
    # ------------------------------------------------------------------

    def get(
        self, symbols: str | list[str] | None = None
    ) -> Any:
        """Obtiene datos del cache segun el tipo de stream del manager.

        Metodo unificado de consulta. El tipo de dato devuelto depende
        del ``stream_type`` configurado en el ``Config``:

        - ``"trade"`` -> ``Trade``
        - ``"depth"`` -> ``OrderBookSnapshot``
        - ``"agg_trade"`` -> ``AggTrade``
        - ``"kline"`` -> ``Kline``
        - ``"ticker"`` -> ``Ticker``
        - ``"mini_ticker"`` -> ``MiniTicker``
        - ``"book_ticker"`` -> ``BookTicker``

        Parameters
        ----------
        symbols : str | list[str] | None
            - ``str``: devuelve el dato para ese simbolo, o ``None``.
            - ``list[str]``: devuelve ``dict[str, dato]`` con los
              simbolos especificados (omite los que no tienen dato).
            - ``None``: devuelve ``dict[str, dato]`` con todos los
              simbolos del cache.

        Examples
        --------
        ::

            # Un simbolo -> dato directo
            trade = manager.get("BTCUSDT")

            # Varios simbolos -> dict
            data = manager.get(["BTCUSDT", "ETHUSDT"])

            # Todos -> dict
            all_data = manager.get()
        """
        if isinstance(symbols, str):
            self._check_symbol(symbols)
            return self._get_one(symbols)

        if symbols is None:
            target = self._cache.get_symbols()
        else:
            target = [s.upper() for s in symbols]

        result = {}
        for sym in target:
            val = self._get_one(sym)
            if val is not None:
                result[sym] = val
        return result

    def get_recent(self, symbol: str, limit: int | None = None) -> list:
        """Devuelve el historial reciente para un simbolo.

        Para ``"trade"`` y ``"agg_trade"`` devuelve la lista del deque
        (hasta ``limit`` elementos). Para el resto de stream types
        devuelve una lista con el dato actual si existe, o lista vacia.

        Parameters
        ----------
        symbol : str
            Simbolo (case-insensitive).
        limit : int | None
            Maximo de elementos a devolver. Si no se especifica, usa
            ``max_history`` del Config.
        """
        self._check_symbol(symbol)
        if limit is None:
            limit = self._config.max_history
        st = self._config.stream_type
        if st == StreamType.TRADE:
            return self._cache.get_recent_trades(symbol, limit)
        if st == StreamType.AGG_TRADE:
            return self._cache.get_recent_agg_trades(symbol, limit)
        # Para tipos sin historial, devuelve el dato actual envuelto en lista
        val = self._get_one(symbol)
        return [val] if val is not None else []

    def _check_symbol(self, symbol: str) -> None:
        """Lanza StreamNotFoundError si el simbolo no esta registrado."""
        if symbol.upper() not in self._get_all_symbols():
            raise StreamNotFoundError(
                f"'{symbol.upper()}' no esta registrado en este Manager. "
                f"Simbolos activos: {sorted(self._get_all_symbols())}"
            )

    def _get_one(self, symbol: str) -> Any:
        """Obtiene un dato del cache para un simbolo segun stream_type."""
        st = self._config.stream_type
        if st == StreamType.TRADE:
            return self._cache.get_last_trade(symbol)
        if st == StreamType.DEPTH:
            return self._cache.get_order_book(symbol)
        if st == StreamType.AGG_TRADE:
            return self._cache.get_last_agg_trade(symbol)
        if st == StreamType.KLINE:
            return self._cache.get_kline(symbol, self._config.interval)
        if st == StreamType.TICKER:
            return self._cache.get_ticker(symbol)
        if st == StreamType.MINI_TICKER:
            return self._cache.get_mini_ticker(symbol)
        if st == StreamType.BOOK_TICKER:
            return self._cache.get_book_ticker(symbol)
        return None

    # ------------------------------------------------------------------
    # Observabilidad
    # ------------------------------------------------------------------

    def get_stream_status(self, stream_id: str) -> StreamStatus | None:
        """Devuelve el estado de un stream específico."""
        with self._lock:
            worker = self._workers.get(stream_id)
        return worker.status if worker else None

    def get_all_streams_status(self) -> dict[str, StreamStatus]:
        """Devuelve el estado de todos los streams."""
        with self._lock:
            return {sid: w.status for sid, w in self._workers.items()}

    def get_health(self) -> SystemHealth:
        """Devuelve el diagnóstico de salud global del sistema."""
        statuses = self.get_all_streams_status()
        return self._health_monitor.evaluate_system(statuses, self._started_at)

    def get_stats(self) -> dict[str, Any]:
        """Devuelve estadísticas resumidas del sistema."""
        health = self.get_health()
        with self._lock:
            streams = {
                sid: list(w._symbols_upper)
                for sid, w in self._workers.items()
            }
        return {
            "running": self._running,
            "uptime_s": round(health.uptime_s, 1),
            "total_streams": health.total_streams,
            "running_streams": health.running_streams,
            "stale_streams": health.stale_streams,
            "total_messages": health.total_messages,
            "symbols": self._cache.get_symbols(),
            "streams": streams,
            "is_healthy": health.is_healthy,
        }

    def is_healthy(self) -> bool:
        """Indica si el sistema global está sano."""
        return self.get_health().is_healthy

    def print_summary(self) -> None:
        """Imprime un resumen del estado del sistema por logging."""
        stats = self.get_stats()
        logger.info("=== Market Stream Summary ===")
        for key, value in stats.items():
            logger.info("  %s: %s", key, value)
        for sid, status in self.get_all_streams_status().items():
            evaluated = self._health_monitor.evaluate_stream(status)
            logger.info(
                "  [%s] state=%s msgs=%d reconnects=%d errors=%d",
                sid,
                evaluated.value,
                status.message_count,
                status.reconnect_count,
                status.error_count,
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _stop_all_workers(self) -> None:
        """Detiene todos los workers de forma concurrente."""
        with self._lock:
            workers = list(self._workers.values())
        if workers:
            await asyncio.gather(
                *(w.stop() for w in workers), return_exceptions=True
            )

    def _register_and_start(self, stream_id: str, worker: Worker) -> None:
        """Registra un worker y lo arranca en el event loop."""
        with self._lock:
            self._workers[stream_id] = worker
        if self._loop is not None:
            self._loop.call_soon_threadsafe(worker.start, self._loop)

    def _get_all_symbols(self) -> set[str]:
        """Devuelve todos los simbolos registrados en los workers."""
        symbols: set[str] = set()
        with self._lock:
            for worker in self._workers.values():
                if isinstance(worker, Worker):
                    symbols.update(worker._symbols_upper)
        return symbols
