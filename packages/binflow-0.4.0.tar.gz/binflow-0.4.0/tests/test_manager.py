"""Tests para Manager: fachada principal del sistema.

Verifica el comportamiento real del Manager como lo usaria un usuario:
Config -> Manager -> add_symbols -> start -> get/get_recent -> stop.

Los tests inyectan datos directamente en el cache (simulando lo que
harian los workers) para verificar que la fachada los expone correctamente.
"""

import gc
import threading
import time

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import Config
from market_streaming.exceptions import StreamNotFoundError
from market_streaming.manager import Manager
from market_streaming.models import (
    AggTrade,
    BookTicker,
    Kline,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    Ticker,
    Trade,
)


# ---- helpers ----

def _make_trade(symbol: str = "BTCUSDT", tid: int = 1, price: float = 50000.0) -> Trade:
    qty = 0.1
    return Trade(
        symbol=symbol,
        trade_id=tid,
        price=price,
        quantity=qty,
        quote_quantity=price * qty,
        buyer_maker=False,
        timestamp_ms=int(time.time() * 1000),
        price_str=f"{price:.8f}",
        quantity_str=f"{qty:.8f}",
    )


def _make_order_book(
    symbol: str = "BTCUSDT",
    n_levels: int = 5,
    base_bid: float = 50000.0,
    base_ask: float = 50001.0,
    update_id: int = 100,
    is_synced: bool = True,
) -> OrderBookSnapshot:
    bids = [OrderBookLevel(base_bid - i, 1.0 + i * 0.1) for i in range(n_levels)]
    asks = [OrderBookLevel(base_ask + i, 0.5 + i * 0.1) for i in range(n_levels)]
    return OrderBookSnapshot(
        symbol=symbol, bids=bids, asks=asks,
        last_update_id=update_id, is_synced=is_synced,
    )


def _populate_trades(cache: MarketDataCache, symbol: str, count: int, start_id: int = 1) -> None:
    """Inserta trades consecutivos en el cache."""
    for i in range(count):
        cache.update_trade(_make_trade(symbol, tid=start_id + i, price=50000.0 + i))


# ---- Config validation ----

class TestConfigValidation:
    def test_trade_requires_max_history(self) -> None:
        with pytest.raises(ValueError, match="max_history"):
            Config(stream_type="trade")

    def test_depth_requires_depth(self) -> None:
        with pytest.raises(ValueError, match="depth"):
            Config(stream_type="depth")

    def test_agg_trade_requires_max_history(self) -> None:
        with pytest.raises(ValueError, match="max_history"):
            Config(stream_type="agg_trade")

    def test_ticker_no_extra_required(self) -> None:
        config = Config(stream_type="ticker")
        assert config.stream_type.value == "ticker"

    def test_kline_default_interval(self) -> None:
        config = Config(stream_type="kline")
        assert config.interval == "1m"

    def test_symbols_normalized_uppercase(self) -> None:
        config = Config(stream_type="ticker", symbols=["btcusdt", "EthUSDT"])
        assert config.symbols == ["BTCUSDT", "ETHUSDT"]

    def test_market_accepts_string(self) -> None:
        config = Config(market="futures_usd", stream_type="ticker")
        assert config.market.value == "futures_usd"

    def test_stream_type_alias(self) -> None:
        config = Config(stream_type="order_book", depth=10)
        assert config.stream_type.value == "depth"

    def test_log_level_accepts_string(self) -> None:
        import logging
        config = Config(stream_type="ticker", log_level="debug")
        assert config.log_level == logging.DEBUG


# ---- Lifecycle ----

class TestLifecycle:
    def test_start_sets_running(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        assert mgr._running is True
        mgr.stop()
        assert mgr._running is False

    def test_double_start_is_safe(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        mgr.start()
        assert mgr._running is True
        mgr.stop()

    def test_stop_without_start_is_safe(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.stop()  # no debe fallar

    def test_context_manager(self) -> None:
        with Manager(Config(stream_type="trade", max_history=10, log_dir="")) as mgr:
            assert mgr._running is True
        assert mgr._running is False

    def test_thread_created_on_start(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        assert mgr._thread is not None
        assert mgr._thread.is_alive()
        mgr.stop()
        assert mgr._thread is None

    def test_loop_created_on_start(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        assert mgr._loop is not None
        mgr.stop()
        assert mgr._loop is None

    def test_multiple_start_stop_cycles(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        for _ in range(5):
            mgr.start()
            assert mgr._running is True
            mgr.stop()
            assert mgr._running is False


# ---- repr ----

class TestRepr:
    def test_repr_stopped(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=100, log_dir=""))
        r = repr(mgr)
        assert "status=stopped" in r
        assert "stream_type=trade" in r
        assert "max_history=100" in r
        assert "uptime=" not in r

    def test_repr_running_shows_uptime(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        try:
            r = repr(mgr)
            assert "status=running" in r
            assert "uptime=" in r
        finally:
            mgr.stop()

    def test_repr_depth_shows_depth(self) -> None:
        mgr = Manager(Config(stream_type="depth", depth=20, log_dir=""))
        assert "depth=20" in repr(mgr)

    def test_repr_kline_shows_interval(self) -> None:
        mgr = Manager(Config(stream_type="kline", interval="5m", log_dir=""))
        assert "interval=5m" in repr(mgr)

    def test_repr_shows_symbol_count(self) -> None:
        mgr = Manager(Config(
            stream_type="trade", max_history=10, log_dir="",
            symbols=["BTCUSDT", "ETHUSDT"],
        ))
        assert "symbols=2" in repr(mgr)


# ---- Symbol management ----

class TestSymbolManagement:
    def test_symbols_from_config(self) -> None:
        mgr = Manager(Config(
            stream_type="trade", max_history=10, log_dir="",
            symbols=["BTCUSDT", "ETHUSDT"],
        ))
        symbols = mgr._get_all_symbols()
        assert symbols == {"BTCUSDT", "ETHUSDT"}

    def test_add_symbols_string(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.add_symbols("BTCUSDT")
        assert "BTCUSDT" in mgr._get_all_symbols()

    def test_add_symbols_list(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.add_symbols(["BTCUSDT", "ETHUSDT"])
        assert mgr._get_all_symbols() == {"BTCUSDT", "ETHUSDT"}

    def test_add_symbols_case_insensitive(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.add_symbols("btcusdt")
        assert "BTCUSDT" in mgr._get_all_symbols()

    def test_add_symbols_deduplicates(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.add_symbols("BTCUSDT")
        mgr.add_symbols("BTCUSDT")
        assert len(mgr._workers) == 1

    def test_add_symbols_before_start(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.add_symbols(["BTCUSDT", "ETHUSDT"])
        assert len(mgr._workers) == 1  # un worker para ambos

    def test_remove_symbols_cleans_cache(self) -> None:
        """remove_symbols debe limpiar los datos del cache."""
        cfg = Config(stream_type="trade", max_history=10, log_dir="",
                     symbols=["BTCUSDT", "ETHUSDT"])
        mgr = Manager(cfg)
        # Inyectar datos en cache
        _populate_trades(mgr._cache, "BTCUSDT", 5)
        _populate_trades(mgr._cache, "ETHUSDT", 5)
        assert mgr._cache.get_last_trade("BTCUSDT") is not None

        mgr.remove_symbols("BTCUSDT")
        # El dato de BTCUSDT debe haber desaparecido del cache
        assert mgr._cache.get_last_trade("BTCUSDT") is None
        # ETHUSDT sigue intacto
        assert mgr._cache.get_last_trade("ETHUSDT") is not None

    def test_remove_symbols_disappear_from_get(self) -> None:
        """Tras remove, .get() ya no incluye el simbolo."""
        cfg = Config(stream_type="trade", max_history=10, log_dir="",
                     symbols=["BTCUSDT", "ETHUSDT"])
        mgr = Manager(cfg)
        _populate_trades(mgr._cache, "BTCUSDT", 3)
        _populate_trades(mgr._cache, "ETHUSDT", 3)

        mgr.remove_symbols("BTCUSDT")
        all_data = mgr.get()
        assert "BTCUSDT" not in all_data
        assert "ETHUSDT" in all_data


# ---- Data access: .get() ----

class TestGet:
    @pytest.fixture
    def trade_mgr(self) -> Manager:
        cfg = Config(stream_type="trade", max_history=50, log_dir="",
                     symbols=["BTCUSDT", "ETHUSDT"])
        mgr = Manager(cfg)
        _populate_trades(mgr._cache, "BTCUSDT", 20)
        _populate_trades(mgr._cache, "ETHUSDT", 10, start_id=100)
        return mgr

    def test_get_single_returns_trade(self, trade_mgr: Manager) -> None:
        trade = trade_mgr.get("BTCUSDT")
        assert isinstance(trade, Trade)
        assert trade.symbol == "BTCUSDT"

    def test_get_single_returns_latest(self, trade_mgr: Manager) -> None:
        trade = trade_mgr.get("BTCUSDT")
        assert trade.trade_id == 20  # ultimo de los 20 insertados

    def test_get_all_returns_dict(self, trade_mgr: Manager) -> None:
        all_data = trade_mgr.get()
        assert isinstance(all_data, dict)
        assert set(all_data.keys()) == {"BTCUSDT", "ETHUSDT"}

    def test_get_all_values_are_trades(self, trade_mgr: Manager) -> None:
        for trade in trade_mgr.get().values():
            assert isinstance(trade, Trade)

    def test_get_list_returns_filtered_dict(self, trade_mgr: Manager) -> None:
        data = trade_mgr.get(["BTCUSDT"])
        assert list(data.keys()) == ["BTCUSDT"]

    def test_get_list_with_unregistered_skips(self, trade_mgr: Manager) -> None:
        data = trade_mgr.get(["BTCUSDT", "XYZUSDT"])
        assert "BTCUSDT" in data
        assert "XYZUSDT" not in data

    def test_get_unregistered_raises(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir="",
                             symbols=["BTCUSDT"]))
        with pytest.raises(StreamNotFoundError, match="ETHUSDT"):
            mgr.get("ETHUSDT")

    def test_get_case_insensitive(self, trade_mgr: Manager) -> None:
        trade = trade_mgr.get("btcusdt")
        assert trade.symbol == "BTCUSDT"

    def test_get_empty_before_data(self) -> None:
        """Simbolo registrado pero sin datos aun -> None."""
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir="",
                             symbols=["BTCUSDT"]))
        assert mgr.get("BTCUSDT") is None

    def test_get_all_empty_returns_empty_dict(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        assert mgr.get() == {}


class TestGetDepth:
    """Verifica .get() con stream de order book."""

    @pytest.fixture
    def depth_mgr(self) -> Manager:
        cfg = Config(stream_type="depth", depth=10, log_dir="",
                     symbols=["BTCUSDT"])
        mgr = Manager(cfg)
        mgr._cache.update_order_book(_make_order_book("BTCUSDT", n_levels=10))
        return mgr

    def test_get_returns_snapshot(self, depth_mgr: Manager) -> None:
        book = depth_mgr.get("BTCUSDT")
        assert isinstance(book, OrderBookSnapshot)

    def test_get_snapshot_has_bids_and_asks(self, depth_mgr: Manager) -> None:
        book = depth_mgr.get("BTCUSDT")
        assert len(book.bids) == 10
        assert len(book.asks) == 10

    def test_get_bids_sorted_descending(self, depth_mgr: Manager) -> None:
        book = depth_mgr.get("BTCUSDT")
        prices = [b.price for b in book.bids]
        assert prices == sorted(prices, reverse=True)

    def test_get_asks_sorted_ascending(self, depth_mgr: Manager) -> None:
        book = depth_mgr.get("BTCUSDT")
        prices = [a.price for a in book.asks]
        assert prices == sorted(prices)

    def test_get_spread_positive(self, depth_mgr: Manager) -> None:
        book = depth_mgr.get("BTCUSDT")
        assert book.asks[0].price > book.bids[0].price

    def test_get_returns_copy(self, depth_mgr: Manager) -> None:
        b1 = depth_mgr.get("BTCUSDT")
        b2 = depth_mgr.get("BTCUSDT")
        assert b1 is not b2


# ---- Data access: .get_recent() ----

class TestGetRecent:
    @pytest.fixture
    def trade_mgr(self) -> Manager:
        cfg = Config(stream_type="trade", max_history=50, log_dir="",
                     symbols=["BTCUSDT"])
        mgr = Manager(cfg)
        _populate_trades(mgr._cache, "BTCUSDT", 30)
        return mgr

    def test_returns_list(self, trade_mgr: Manager) -> None:
        recent = trade_mgr.get_recent("BTCUSDT")
        assert isinstance(recent, list)

    def test_returns_all_up_to_max_history(self, trade_mgr: Manager) -> None:
        recent = trade_mgr.get_recent("BTCUSDT")
        assert len(recent) == 30  # insertamos 30, max_history=50

    def test_limit_respected(self, trade_mgr: Manager) -> None:
        recent = trade_mgr.get_recent("BTCUSDT", limit=5)
        assert len(recent) == 5

    def test_default_limit_is_max_history(self) -> None:
        cfg = Config(stream_type="trade", max_history=20, log_dir="",
                     symbols=["BTCUSDT"])
        mgr = Manager(cfg)
        _populate_trades(mgr._cache, "BTCUSDT", 100)
        recent = mgr.get_recent("BTCUSDT")
        assert len(recent) == 20  # max_history=20, insertamos 100

    def test_elements_are_trades(self, trade_mgr: Manager) -> None:
        for t in trade_mgr.get_recent("BTCUSDT", limit=3):
            assert isinstance(t, Trade)

    def test_trade_ids_ordered(self, trade_mgr: Manager) -> None:
        recent = trade_mgr.get_recent("BTCUSDT")
        ids = [t.trade_id for t in recent]
        assert ids == sorted(ids)

    def test_trade_ids_continuous(self, trade_mgr: Manager) -> None:
        recent = trade_mgr.get_recent("BTCUSDT")
        ids = [t.trade_id for t in recent]
        for i in range(len(ids) - 1):
            assert ids[i + 1] - ids[i] == 1, f"Gap between {ids[i]} and {ids[i+1]}"

    def test_unregistered_raises(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir="",
                             symbols=["BTCUSDT"]))
        with pytest.raises(StreamNotFoundError):
            mgr.get_recent("XYZUSDT")

    def test_registered_but_empty_returns_empty_list(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir="",
                             symbols=["BTCUSDT"]))
        assert mgr.get_recent("BTCUSDT") == []

    def test_depth_returns_single_element_list(self) -> None:
        """Para depth, get_recent devuelve [snapshot] si existe."""
        cfg = Config(stream_type="depth", depth=5, log_dir="",
                     symbols=["BTCUSDT"])
        mgr = Manager(cfg)
        mgr._cache.update_order_book(_make_order_book("BTCUSDT"))
        recent = mgr.get_recent("BTCUSDT")
        assert len(recent) == 1
        assert isinstance(recent[0], OrderBookSnapshot)

    def test_ticker_returns_single_element_list(self) -> None:
        """Para ticker, get_recent devuelve [ticker] si existe."""
        cfg = Config(stream_type="ticker", log_dir="", symbols=["BTCUSDT"])
        mgr = Manager(cfg)
        mgr._cache.update_ticker(Ticker(
            symbol="BTCUSDT", price_change=0, price_change_pct=0,
            weighted_avg_price=0, prev_close_price=0, last_price=50000.0,
            last_quantity=0, best_bid_price=0, best_bid_quantity=0,
            best_ask_price=0, best_ask_quantity=0, open_price=0,
            high_price=0, low_price=0, volume=0, quote_volume=0,
            open_time_ms=0, close_time_ms=0, first_trade_id=0,
            last_trade_id=0, trade_count=0,
        ))
        recent = mgr.get_recent("BTCUSDT")
        assert len(recent) == 1
        assert recent[0].last_price == 50000.0

    def test_ticker_empty_returns_empty_list(self) -> None:
        cfg = Config(stream_type="ticker", log_dir="", symbols=["BTCUSDT"])
        mgr = Manager(cfg)
        assert mgr.get_recent("BTCUSDT") == []


# ---- .get() universal: verifica todos los stream types ----

class TestGetAllStreamTypes:
    """Verifica que .get() devuelve el tipo correcto para cada stream_type."""

    def test_get_trade(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir="",
                             symbols=["BTCUSDT"]))
        mgr._cache.update_trade(_make_trade())
        assert isinstance(mgr.get("BTCUSDT"), Trade)

    def test_get_agg_trade(self) -> None:
        mgr = Manager(Config(stream_type="agg_trade", max_history=10, log_dir="",
                             symbols=["BTCUSDT"]))
        mgr._cache.update_agg_trade(AggTrade(
            symbol="BTCUSDT", agg_trade_id=1, price=50000.0, quantity=0.1,
            first_trade_id=1, last_trade_id=5, timestamp_ms=1000,
            buyer_maker=False,
        ))
        assert isinstance(mgr.get("BTCUSDT"), AggTrade)

    def test_get_depth(self) -> None:
        mgr = Manager(Config(stream_type="depth", depth=5, log_dir="",
                             symbols=["BTCUSDT"]))
        mgr._cache.update_order_book(_make_order_book())
        assert isinstance(mgr.get("BTCUSDT"), OrderBookSnapshot)

    def test_get_kline(self) -> None:
        mgr = Manager(Config(stream_type="kline", log_dir="", symbols=["BTCUSDT"]))
        mgr._cache.update_kline(Kline(
            symbol="BTCUSDT", interval="1m",
            open_time_ms=0, close_time_ms=0,
            open=50000.0, close=50100.0, high=50200.0, low=49900.0,
            volume=100.0, quote_volume=5000000.0,
            trades=10, taker_buy_volume=50.0,
            taker_buy_quote_volume=2500000.0, is_closed=False,
        ))
        assert isinstance(mgr.get("BTCUSDT"), Kline)

    def test_get_ticker(self) -> None:
        mgr = Manager(Config(stream_type="ticker", log_dir="", symbols=["BTCUSDT"]))
        mgr._cache.update_ticker(Ticker(
            symbol="BTCUSDT", price_change=0, price_change_pct=0,
            weighted_avg_price=0, prev_close_price=0, last_price=50000.0,
            last_quantity=0, best_bid_price=0, best_bid_quantity=0,
            best_ask_price=0, best_ask_quantity=0, open_price=0,
            high_price=0, low_price=0, volume=0, quote_volume=0,
            open_time_ms=0, close_time_ms=0, first_trade_id=0,
            last_trade_id=0, trade_count=0,
        ))
        assert isinstance(mgr.get("BTCUSDT"), Ticker)

    def test_get_mini_ticker(self) -> None:
        mgr = Manager(Config(stream_type="mini_ticker", log_dir="", symbols=["BTCUSDT"]))
        mgr._cache.update_mini_ticker(MiniTicker(
            symbol="BTCUSDT", close_price=50000.0, open_price=49500.0,
            high_price=50500.0, low_price=49000.0,
            volume=1000.0, quote_volume=50000000.0,
        ))
        assert isinstance(mgr.get("BTCUSDT"), MiniTicker)

    def test_get_book_ticker(self) -> None:
        mgr = Manager(Config(stream_type="book_ticker", log_dir="", symbols=["BTCUSDT"]))
        mgr._cache.update_book_ticker(BookTicker(
            symbol="BTCUSDT", update_id=1,
            best_bid_price=49999.0, best_bid_quantity=1.0,
            best_ask_price=50001.0, best_ask_quantity=0.5,
        ))
        assert isinstance(mgr.get("BTCUSDT"), BookTicker)


# ---- Observability ----

class TestObservability:
    @pytest.fixture
    def running_mgr(self) -> Manager:
        cfg = Config(stream_type="trade", max_history=10, log_dir="",
                     symbols=["BTCUSDT", "ETHUSDT"])
        mgr = Manager(cfg)
        mgr.start()
        yield mgr
        mgr.stop()

    def test_get_stats_structure(self, running_mgr: Manager) -> None:
        stats = running_mgr.get_stats()
        expected_keys = {
            "running", "uptime_s", "total_streams", "running_streams",
            "stale_streams", "total_messages", "symbols", "streams",
            "is_healthy",
        }
        assert set(stats.keys()) == expected_keys

    def test_get_stats_running(self, running_mgr: Manager) -> None:
        stats = running_mgr.get_stats()
        assert stats["running"] is True
        assert stats["uptime_s"] >= 0

    def test_get_stats_symbols(self, running_mgr: Manager) -> None:
        stats = running_mgr.get_stats()
        assert isinstance(stats["symbols"], list)

    def test_get_stats_streams_maps_to_symbols(self, running_mgr: Manager) -> None:
        stats = running_mgr.get_stats()
        streams = stats["streams"]
        assert isinstance(streams, dict)
        # Cada stream_id mapea a lista de simbolos
        for sid, syms in streams.items():
            assert isinstance(syms, list)
            assert all(isinstance(s, str) for s in syms)
        # Todos los simbolos registrados aparecen
        all_syms = set()
        for syms in streams.values():
            all_syms.update(syms)
        assert "BTCUSDT" in all_syms
        assert "ETHUSDT" in all_syms

    def test_get_health(self, running_mgr: Manager) -> None:
        health = running_mgr.get_health()
        assert health.total_streams >= 1
        assert health.uptime_s >= 0

    def test_is_healthy_bool(self, running_mgr: Manager) -> None:
        assert isinstance(running_mgr.is_healthy(), bool)

    def test_get_all_streams_status(self, running_mgr: Manager) -> None:
        statuses = running_mgr.get_all_streams_status()
        assert isinstance(statuses, dict)
        for sid, status in statuses.items():
            assert hasattr(status, "state")
            assert hasattr(status, "message_count")

    def test_get_stream_status_existing(self, running_mgr: Manager) -> None:
        streams = running_mgr.get_stats()["streams"]
        sid = list(streams.keys())[0]
        status = running_mgr.get_stream_status(sid)
        assert status is not None

    def test_get_stream_status_nonexistent(self, running_mgr: Manager) -> None:
        assert running_mgr.get_stream_status("nonexistent_999") is None


# ---- Dashboard ----

class TestDashboard:
    def test_dashboard_shows_instance(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        result = Manager.dashboard()
        assert len(result) >= 1
        assert any("trade" in r for r in result)
        del mgr

    def test_dashboard_empty_after_del(self) -> None:
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        del mgr
        gc.collect()
        # Puede que haya otros managers de otros tests en memoria,
        # pero al menos no debe crashear
        Manager.dashboard()

    def test_dashboard_multiple_instances(self) -> None:
        mgr1 = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr2 = Manager(Config(stream_type="depth", depth=5, log_dir=""))
        result = Manager.dashboard()
        assert len(result) >= 2
        del mgr1, mgr2


# ---- GC safety ----

class TestGCSafety:
    def test_del_calls_stop(self) -> None:
        """Si se pierde la referencia, __del__ llama a stop()."""
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        thread = mgr._thread
        assert thread is not None and thread.is_alive()
        del mgr
        gc.collect()
        # El thread daemon debe morir con el proceso, pero stop() fue llamado
        time.sleep(0.5)
        assert not thread.is_alive()

    def test_gc_cleans_orphan_threads(self) -> None:
        """Verificar que no quedan threads huerfanos."""
        before = threading.active_count()
        mgr = Manager(Config(stream_type="trade", max_history=10, log_dir=""))
        mgr.start()
        assert threading.active_count() > before
        del mgr
        gc.collect()
        time.sleep(1.0)
        assert threading.active_count() <= before + 1  # tolerancia
