"""
FlaxKV2 命令行接口 (使用Fire实现)
"""

import os
import fire
import psutil
from typing import Optional, List
from rich import print
from rich.console import Console
from rich.table import Table

from flaxkv2 import __version__, FlaxKV
from flaxkv2.utils.log import set_log_level
from flaxkv2.inspector.cli import InspectCommands
from flaxkv2.utils.config_loader import ConfigLoader, save_sample_config

console = Console()


class FlaxKV2CLI:
    """FlaxKV2命令行工具"""

    def __init__(self):
        """初始化CLI"""
        self.inspect = InspectCommands()
        self.config_loader = None
        self._load_config()

    def _load_config(self):
        """加载配置文件（如果存在）"""
        try:
            self.config_loader = ConfigLoader()
        except Exception as e:
            # 配置文件加载失败时继续运行，但记录警告
            console.print(f"[yellow]Warning:[/yellow] Failed to load config: {e}")
            self.config_loader = None

    def _resolve_server_address(self, server: str) -> str:
        """
        解析服务器地址

        支持格式：
        - @server_name: 从配置文件中查找名为 server_name 的服务器
        - host:port: 直接使用地址

        Args:
            server: 服务器地址或名称

        Returns:
            解析后的服务器地址 (host:port)
        """
        if server.startswith('@'):
            # 从配置文件查找服务器
            server_name = server[1:]
            if self.config_loader:
                address = self.config_loader.get_server_address(server_name)
                if address:
                    return address
                else:
                    console.print(f"[yellow]Warning:[/yellow] Server '{server_name}' not found in config, using as-is")
                    return server
            else:
                console.print(f"[yellow]Warning:[/yellow] No config file loaded, cannot resolve @{server_name}")
                return server
        return server

    def _merge_config(self, section: str, profile: str, **kwargs) -> dict:
        """
        合并配置文件和命令行参数

        优先级：命令行参数 > 配置文件

        Args:
            section: 配置节名称 ('server' 或 'client')
            profile: profile 名称
            **kwargs: 命令行参数

        Returns:
            合并后的配置字典
        """
        # 从配置文件读取
        config = {}
        if self.config_loader:
            if section == 'server':
                config = self.config_loader.get_server_config(profile)
            elif section == 'client':
                config = self.config_loader.get_client_config(profile)

            # 合并默认配置
            defaults = self.config_loader.get_defaults()
            for key, value in defaults.items():
                if key not in config:
                    config[key] = value

        # 命令行参数覆盖配置文件
        for key, value in kwargs.items():
            if value is not None:
                config[key] = value

        return config

    def version(self):
        """显示版本信息"""
        return f"FlaxKV2 {__version__}"

    def start(
        self,
        socket_path: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        data_dir: Optional[str] = None,
        enable_encryption: Optional[bool] = None,
        password: Optional[str] = None,
    ):
        """
        启动服务器守护进程（后台运行）

        启动后服务器在后台运行，不会随终端关闭而停止。
        多个进程可以共享同一个服务器。
        无参数时默认启动 IPC 模式（Unix Socket）。

        Args:
            socket_path: Unix Socket 路径（推荐）
            host: TCP 主机地址（指定后使用 TCP 模式）
            port: TCP 端口（指定后使用 TCP 模式）
            data_dir: 数据存储目录
            enable_encryption: 启用加密
            password: 加密密码

        示例:
            # 默认启动 IPC 模式（推荐）
            flaxkv2 start

            # 指定 Unix Socket 路径
            flaxkv2 start --socket-path /tmp/flaxkv.sock --data-dir ./data

            # 使用 TCP
            flaxkv2 start --host 127.0.0.1 --port 5555 --data-dir ./data

            # 启动后在代码中连接
            # db = FlaxKV("mydb", "ipc:///tmp/flaxkv.sock")
        """
        from flaxkv2.server.daemon import DaemonServerManager, get_default_socket_path

        # 确定数据目录
        if data_dir is None:
            from flaxkv2.server.daemon import get_default_data_dir
            data_dir = get_default_data_dir()

        # 无参数时默认使用 IPC 模式
        if socket_path is None and host is None and port is None:
            socket_path = get_default_socket_path()

        # 创建管理器
        manager = DaemonServerManager(
            socket_path=socket_path,
            host=host or "127.0.0.1",
            port=port or 5555,
            data_dir=data_dir,
            enable_encryption=enable_encryption or False,
            password=password,
        )

        # 检查状态
        if manager.is_running():
            print(f"[bold yellow]服务器已在运行[/bold yellow]")
            status = manager.status()
            print(f"  URL: [bold blue]{status['url']}[/bold blue]")
            print(f"  PID: [bold blue]{status['pid']}[/bold blue]")
            return

        # 启动服务器
        print(f"[bold green]正在启动 FlaxKV2 服务器守护进程...[/bold green]")
        if manager.start():
            status = manager.status()
            print(f"\n[bold green]✓ 服务器已启动[/bold green]")
            print(f"  URL: [bold blue]{status['url']}[/bold blue]")
            print(f"  PID: [bold blue]{status['pid']}[/bold blue]")
            print(f"  数据目录: [bold blue]{status['data_dir']}[/bold blue]")
            print(f"  日志文件: [dim]{status['log_file']}[/dim]")
            print(f"\n[dim]使用 'flaxkv2 stop' 停止服务器[/dim]")
        else:
            print(f"[bold red]✗ 服务器启动失败[/bold red]")
            print(f"  查看日志: [dim]{manager.log_file}[/dim]")

    def _get_managers(
        self,
        socket_path: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> list:
        """
        获取需要操作的 DaemonServerManager 列表

        指定参数时只返回对应的 manager。
        """
        from flaxkv2.server.daemon import DaemonServerManager

        if socket_path or host or port:
            return [DaemonServerManager(
                socket_path=socket_path,
                host=host or "127.0.0.1",
                port=port or 5555,
                data_dir=".",
            )]
        return []

    def _discover_all_daemons(self) -> list:
        """
        扫描所有运行中的 flaxkv2 daemon（IPC + TCP 默认）

        扫描 ~/.flaxkv2/server*.sock 发现所有 IPC daemon，
        同时检查默认 TCP (127.0.0.1:5555)。
        """
        import glob
        from flaxkv2.server.daemon import DaemonServerManager

        managers = []
        flaxkv_dir = os.path.join(os.path.expanduser("~"), ".flaxkv2")

        # 扫描所有 server*.sock 文件
        for sock_file in sorted(glob.glob(os.path.join(flaxkv_dir, "server*.sock"))):
            managers.append(DaemonServerManager(socket_path=sock_file, data_dir="."))

        # 检查默认 TCP
        managers.append(DaemonServerManager(host="127.0.0.1", port=5555, data_dir="."))

        return managers

    def stop(
        self,
        socket_path: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        all: bool = False,
    ):
        """
        停止服务器守护进程

        Args:
            socket_path: Unix Socket 路径
            host: TCP 主机地址
            port: TCP 端口
            all: 停止所有运行中的守护进程

        示例:
            flaxkv2 stop                                    # 列出所有运行中的守护进程
            flaxkv2 stop --all                              # 停止所有运行中的守护进程
            flaxkv2 stop --socket-path /tmp/flaxkv.sock     # 停止指定 IPC 守护进程
            flaxkv2 stop --port 5555                        # 停止指定 TCP 守护进程
        """
        # 指定了具体目标：直接停止
        if socket_path or host or port:
            managers = self._get_managers(socket_path, host, port)
            for manager in managers:
                if not manager.is_running():
                    print(f"[bold yellow]服务器未运行: {manager.url}[/bold yellow]")
                    continue
                status = manager.status()
                print(f"正在停止 {status['mode'].upper()} 服务器 ({status['url']})...")
                if manager.stop():
                    print(f"[bold green]✓ 已停止[/bold green]")
                else:
                    print(f"[bold red]✗ 停止失败[/bold red]")
            return

        # 扫描所有 daemon
        all_managers = self._discover_all_daemons()
        running = [(m, m.status()) for m in all_managers if m.is_running()]

        if not running:
            print("[bold yellow]没有运行中的服务器[/bold yellow]")
            return

        if all:
            # --all: 停止所有
            for manager, status in running:
                print(f"正在停止 {status['mode'].upper()} 服务器 ({status['url']}, PID={status['pid']})...")
                if manager.stop():
                    print(f"[bold green]✓ 已停止[/bold green]")
                else:
                    print(f"[bold red]✗ 停止失败[/bold red]")
        else:
            # 无参数：列出运行中的 daemon
            print(f"[bold]运行中的服务器 ({len(running)} 个):[/bold]\n")
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("模式", style="cyan", no_wrap=True)
            table.add_column("URL", style="green")
            table.add_column("PID", style="yellow")
            table.add_column("数据目录", style="white")
            for _, status in running:
                table.add_row(
                    status['mode'].upper(),
                    status['url'],
                    str(status['pid']),
                    status['data_dir'],
                )
            console.print(table)
            print(f"\n[dim]使用 'flaxkv2 stop --all' 停止所有服务器[/dim]")
            print(f"[dim]使用 'flaxkv2 stop --socket-path <path>' 停止指定服务器[/dim]")

    def status(
        self,
        socket_path: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ):
        """
        查看服务器状态

        Args:
            socket_path: Unix Socket 路径
            host: TCP 主机地址
            port: TCP 端口

        示例:
            flaxkv2 status                                  # 查看所有守护进程状态
            flaxkv2 status --socket-path /tmp/flaxkv.sock
            flaxkv2 status --port 5555
        """
        if socket_path or host or port:
            managers = self._get_managers(socket_path, host, port)
        else:
            managers = self._discover_all_daemons()

        shown = False
        for manager in managers:
            status = manager.status()
            if not status['running'] and not (socket_path or host or port):
                continue  # 无参数时只显示运行中的

            if shown:
                print()
            shown = True

            if status['running']:
                print(f"[bold green]● 服务器运行中[/bold green]")
            else:
                print(f"[bold red]○ 服务器未运行[/bold red]")

            print(f"  URL: [bold blue]{status['url']}[/bold blue]")
            print(f"  模式: [bold blue]{status['mode'].upper()}[/bold blue]")

            if status['running']:
                print(f"  PID: [bold blue]{status['pid']}[/bold blue]")

            print(f"  数据目录: [dim]{status['data_dir']}[/dim]")
            print(f"  PID 文件: [dim]{status['pid_file']}[/dim]")
            print(f"  日志文件: [dim]{status['log_file']}[/dim]")

        if not shown:
            print("[bold yellow]没有运行中的服务器[/bold yellow]")

    def run(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        data_dir: Optional[str] = None,
        workers: Optional[int] = None,
        log_level: Optional[str] = None,
        profile: str = 'default',
        enable_encryption: Optional[bool] = None,
        password: Optional[str] = None,
        derive_from_password: Optional[bool] = None,
        enable_compression: Optional[bool] = None,
        performance_profile: Optional[str] = None,
        socket_path: Optional[str] = None,
    ):
        """
        运行 FlaxKV2 ZeroMQ 服务器

        Args:
            host: 监听主机名（TCP 模式）
            port: 监听端口（TCP 模式）
            data_dir: 数据目录
            workers: 工作线程数
            log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR)
            profile: 配置 profile 名称 (默认: default)
            enable_encryption: 启用 CurveZMQ 加密
            password: 服务器密码（用于加密）
            derive_from_password: 从密码派生密钥（推荐 True，默认 True）
            enable_compression: 启用 LZ4 压缩
            performance_profile: 性能配置文件名称
            socket_path: Unix Socket 路径（IPC 模式，设置后忽略 host/port）

        示例:
            # 使用默认配置或配置文件中的默认值
            flaxkv2 run

            # 使用配置文件中的 production profile
            flaxkv2 run --profile production

            # 命令行参数覆盖配置文件
            flaxkv2 run --profile production --port 6666

            # 启用加密
            flaxkv2 run --enable-encryption --password mypassword

            # 使用 Unix Socket（推荐用于本地多进程）
            flaxkv2 run --socket-path /tmp/flaxkv.sock --data-dir ./data
        """
        from flaxkv2.server.zmq_server import FlaxKVServer

        # 合并配置
        config = self._merge_config(
            'server',
            profile,
            host=host,
            port=port,
            data_dir=data_dir,
            workers=workers,
            log_level=log_level,
            enable_encryption=enable_encryption,
            password=password,
            derive_from_password=derive_from_password,
            enable_compression=enable_compression,
            performance_profile=performance_profile,
            socket_path=socket_path,
        )

        # 提取配置值（使用默认值作为后备）
        final_host = config.get('host', '127.0.0.1')
        final_port = config.get('port', 5555)
        final_data_dir = config.get('data_dir', '.')
        final_workers = config.get('workers', 4)
        final_log_level = config.get('log_level', 'INFO')
        final_enable_encryption = config.get('enable_encryption', False)
        final_password = config.get('password')
        final_derive_from_password = config.get('derive_from_password', True)
        final_enable_compression = config.get('enable_compression', False)
        final_performance_profile = config.get('performance_profile')
        final_socket_path = config.get('socket_path')

        # 设置日志级别
        set_log_level(final_log_level.upper())

        # 显示服务器信息
        print(f"\n[bold green]FlaxKV2 ZeroMQ 服务器启动中...[/bold green]\n")
        if profile != 'default':
            print(f"配置 Profile: [bold magenta]{profile}[/bold magenta]")

        # 显示绑定地址
        if final_socket_path:
            print(f"服务器地址:   [bold blue]ipc://{final_socket_path}[/bold blue] (Unix Socket)")
        else:
            print(f"服务器地址:   [bold blue]{final_host}:{final_port}[/bold blue]")

        print(f"数据目录:     [bold blue]{final_data_dir}[/bold blue]")
        print(f"工作线程:     [bold blue]{final_workers}[/bold blue]")
        print(f"日志级别:     [bold blue]{final_log_level}[/bold blue]")
        if final_enable_encryption:
            print(f"加密:         [bold green]启用[/bold green]")
        if final_enable_compression:
            print(f"压缩:         [bold green]启用[/bold green]")
        if final_performance_profile:
            print(f"性能配置:     [bold blue]{final_performance_profile}[/bold blue]")
        print(f"\n[dim]使用 Ctrl+C 停止服务器[/dim]\n")

        # 创建服务器参数
        server_kwargs = {
            'host': final_host,
            'port': final_port,
            'data_dir': final_data_dir,
            'max_workers': final_workers,
        }

        # 添加 Unix Socket 路径
        if final_socket_path:
            server_kwargs['socket_path'] = final_socket_path

        # 添加可选参数
        if final_enable_encryption:
            server_kwargs['enable_encryption'] = True
            if final_password:
                server_kwargs['password'] = final_password
                server_kwargs['derive_from_password'] = final_derive_from_password

        if final_enable_compression:
            server_kwargs['enable_compression'] = True

        # 创建并运行服务器
        server = FlaxKVServer(**server_kwargs)
        server.run()

    def config(self, action: str = 'show', path: Optional[str] = None):
        """
        管理 FlaxKV2 配置文件

        Args:
            action: 操作类型
                - 'show': 显示当前配置
                - 'init': 生成示例配置文件
                - 'path': 显示配置文件路径
                - 'servers': 列出所有定义的服务器
                - 'profiles': 列出所有 profiles
            path: 配置文件路径（用于 init 操作）

        示例:
            # 显示当前配置
            flaxkv2 config show

            # 生成示例配置文件到当前目录
            flaxkv2 config init

            # 生成示例配置文件到指定路径
            flaxkv2 config init --path ~/.flaxkv.toml

            # 显示配置文件路径
            flaxkv2 config path

            # 列出所有定义的服务器
            flaxkv2 config servers

            # 列出所有 profiles
            flaxkv2 config profiles
        """
        if action == 'init':
            # 生成示例配置文件
            try:
                config_path = save_sample_config(path)
                console.print(f"[bold green]✓[/bold green] 示例配置文件已生成:")
                console.print(f"  路径: [bold blue]{config_path}[/bold blue]")
                console.print(f"\n请编辑配置文件以适应您的环境")
            except FileExistsError:
                console.print(f"[bold red]错误:[/bold red] 配置文件已存在")
                console.print(f"如需重新生成，请先删除现有配置文件")
            except Exception as e:
                console.print(f"[bold red]错误:[/bold red] {str(e)}")

        elif action == 'show':
            # 显示当前配置
            if self.config_loader is None or not self.config_loader.config:
                console.print("[yellow]未找到配置文件[/yellow]")
                console.print("使用 [bold blue]flaxkv2 config init[/bold blue] 生成示例配置")
                return

            console.print("[bold]当前配置:[/bold]\n")

            # 显示服务器配置
            server_config = self.config_loader.get_server_config()
            if server_config:
                console.print("[bold cyan]服务器配置:[/bold cyan]")
                for key, value in server_config.items():
                    if key != 'profiles':
                        console.print(f"  {key}: {value}")

            # 显示客户端配置
            client_config = self.config_loader.get_client_config()
            if client_config:
                console.print("\n[bold cyan]客户端配置:[/bold cyan]")
                for key, value in client_config.items():
                    if key != 'profiles':
                        console.print(f"  {key}: {value}")

            # 显示默认配置
            defaults = self.config_loader.get_defaults()
            if defaults:
                console.print("\n[bold cyan]默认配置:[/bold cyan]")
                for key, value in defaults.items():
                    console.print(f"  {key}: {value}")

        elif action == 'path':
            # 显示配置文件路径
            if self.config_loader is None:
                console.print("[yellow]未找到配置文件[/yellow]")
            else:
                config_file = self.config_loader._find_config_file()
                if config_file:
                    console.print(f"配置文件路径: [bold blue]{config_file}[/bold blue]")
                else:
                    console.print("[yellow]未找到配置文件[/yellow]")

        elif action == 'servers':
            # 列出所有定义的服务器
            if self.config_loader is None or not self.config_loader.config:
                console.print("[yellow]未找到配置文件[/yellow]")
                return

            servers = self.config_loader.get_servers()
            if not servers:
                console.print("[yellow]未定义任何服务器[/yellow]")
                return

            console.print("[bold]定义的服务器:[/bold]\n")
            from rich.table import Table
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("名称", style="cyan", no_wrap=True)
            table.add_column("地址", style="green")
            table.add_column("密码", style="yellow")

            for name, config in servers.items():
                host = config.get('host', 'N/A')
                port = config.get('port', 'N/A')
                password = '***' if config.get('password') else '-'
                table.add_row(name, f"{host}:{port}", password)

            console.print(table)
            console.print(f"\n使用 [bold blue]--server @name[/bold blue] 引用服务器")

        elif action == 'profiles':
            # 列出所有 profiles
            if self.config_loader is None or not self.config_loader.config:
                console.print("[yellow]未找到配置文件[/yellow]")
                return

            server_profiles = self.config_loader.list_profiles('server')
            client_profiles = self.config_loader.list_profiles('client')

            if not server_profiles and not client_profiles:
                console.print("[yellow]未定义任何 profile[/yellow]")
                return

            if server_profiles:
                console.print("[bold cyan]服务器 Profiles:[/bold cyan]")
                for profile in server_profiles:
                    console.print(f"  • {profile}")

            if client_profiles:
                console.print("\n[bold cyan]客户端 Profiles:[/bold cyan]")
                for profile in client_profiles:
                    console.print(f"  • {profile}")

            console.print(f"\n使用 [bold blue]--profile name[/bold blue] 选择 profile")

        else:
            console.print(f"[bold red]错误:[/bold red] 未知的操作: {action}")
            console.print("可用操作: show, init, path, servers, profiles")

    def _find_pids_by_port(self, port: int) -> List[dict]:
        """
        根据端口查找进程 PID（跨平台）

        Returns:
            [{'pid': int, 'name': str, 'cmdline': str}, ...]
        """
        import platform
        import subprocess

        pids_info = []
        system = platform.system()

        try:
            if system == 'Darwin' or system == 'Linux':
                # macOS 和 Linux: 使用 lsof
                result = subprocess.run(
                    ['lsof', '-ti', f':{port}'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    pids = [int(pid.strip()) for pid in result.stdout.strip().split('\n') if pid.strip()]
                    for pid in pids:
                        try:
                            proc = psutil.Process(pid)
                            pids_info.append({
                                'pid': pid,
                                'name': proc.name(),
                                'cmdline': ' '.join(proc.cmdline()[:3]) if proc.cmdline() else proc.name(),
                            })
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass

            elif system == 'Windows':
                # Windows: 使用 netstat
                result = subprocess.run(
                    ['netstat', '-ano'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if f':{port}' in line and 'LISTENING' in line:
                            parts = line.split()
                            if parts:
                                try:
                                    pid = int(parts[-1])
                                    proc = psutil.Process(pid)
                                    pids_info.append({
                                        'pid': pid,
                                        'name': proc.name(),
                                        'cmdline': ' '.join(proc.cmdline()[:3]) if proc.cmdline() else proc.name(),
                                    })
                                except (ValueError, psutil.NoSuchProcess, psutil.AccessDenied):
                                    pass

        except subprocess.TimeoutExpired:
            pass
        except FileNotFoundError:
            # lsof 或 netstat 命令不存在，使用 psutil 后备方案
            try:
                for conn in psutil.net_connections(kind='inet'):
                    if conn.status == 'LISTEN' and conn.laddr.port == port:
                        try:
                            proc = psutil.Process(conn.pid)
                            pids_info.append({
                                'pid': conn.pid,
                                'name': proc.name(),
                                'cmdline': ' '.join(proc.cmdline()[:3]) if proc.cmdline() else proc.name(),
                            })
                        except (psutil.NoSuchProcess, psutil.AccessDenied):
                            pass
            except (PermissionError, psutil.AccessDenied):
                pass

        return pids_info

    def migrate(
        self,
        db_path: str,
        output: Optional[str] = None,
        replace: bool = False,
        no_backup: bool = False,
    ):
        """
        将 LevelDB 数据库迁移到 LMDB

        Args:
            db_path: LevelDB 数据库路径
            output: LMDB 输出路径（默认为 db_path + '.lmdb'）
            replace: 直接替换原有数据库（而非输出到新路径）
            no_backup: 替换时不保留 LevelDB 备份

        示例:
            # 迁移到新路径
            flaxkv2 migrate ./data/mydb

            # 迁移到指定路径
            flaxkv2 migrate ./data/mydb --output ./data/mydb_lmdb

            # 迁移并替换原数据库（保留备份）
            flaxkv2 migrate ./data/mydb --replace

            # 迁移并替换，不保留备份
            flaxkv2 migrate ./data/mydb --replace --no-backup
        """
        from flaxkv2.migration import migrate_leveldb_to_lmdb, migrate_and_replace

        try:
            if replace:
                console.print(f"[bold]迁移并替换: {db_path}[/bold]")
                result = migrate_and_replace(db_path, backup=not no_backup)
                console.print(f"[bold green]✓ 迁移完成: {result}[/bold green]")
            else:
                console.print(f"[bold]迁移: {db_path}[/bold]")
                result = migrate_leveldb_to_lmdb(db_path, output)
                console.print(f"[bold green]✓ 迁移完成: {result}[/bold green]")
        except ImportError as e:
            console.print(f"[bold red]错误:[/bold red] {e}")
        except (FileNotFoundError, FileExistsError) as e:
            console.print(f"[bold red]错误:[/bold red] {e}")
        except Exception as e:
            console.print(f"[bold red]迁移失败:[/bold red] {type(e).__name__}: {e}")

    def kill(self, *ports):
        """
        根据端口号 kill 进程（跨平台支持）

        Args:
            *ports: 一个或多个端口号

        示例:
            # kill 单个端口
            flaxkv2 kill 5555

            # kill 多个端口
            flaxkv2 kill 5555 8080 3000

            # kill FlaxKV 服务器（默认端口 5555）
            flaxkv2 kill 5555
        """
        if not ports:
            console.print("[bold red]错误:[/bold red] 请指定至少一个端口号")
            console.print("用法: flaxkv2 kill <port1> [port2] ...]")
            return

        # 转换端口为整数
        port_list = []
        for port in ports:
            try:
                port_num = int(port)
                if not (1 <= port_num <= 65535):
                    console.print(f"[bold red]错误:[/bold red] 无效的端口号: {port} (必须在 1-65535 之间)")
                    return
                port_list.append(port_num)
            except ValueError:
                console.print(f"[bold red]错误:[/bold red] 无效的端口号: {port}")
                return

        console.print(f"\n[bold]正在查找监听端口的进程...[/bold]")

        # 记录每个端口的处理结果
        results = []

        for port in port_list:
            try:
                # 查找监听该端口的进程
                listening_processes = self._find_pids_by_port(port)

                if not listening_processes:
                    results.append({
                        'port': port,
                        'status': 'not_found',
                        'message': '未找到监听该端口的进程'
                    })
                    continue

                # kill 所有监听该端口的进程
                killed_processes = []
                failed_processes = []

                for proc_info in listening_processes:
                    try:
                        proc = psutil.Process(proc_info['pid'])
                        proc.kill()  # 强制 kill
                        try:
                            proc.wait(timeout=3)  # 等待进程退出
                        except psutil.TimeoutExpired:
                            # 进程未在超时时间内退出，但 kill 信号已发送
                            pass
                        killed_processes.append(proc_info)
                    except psutil.NoSuchProcess:
                        # 进程已经不存在了
                        killed_processes.append(proc_info)
                    except psutil.AccessDenied:
                        failed_processes.append({
                            **proc_info,
                            'reason': '权限不足'
                        })
                    except Exception as e:
                        failed_processes.append({
                            **proc_info,
                            'reason': f'{type(e).__name__}: {str(e)}'
                        })

                if killed_processes:
                    results.append({
                        'port': port,
                        'status': 'success',
                        'processes': killed_processes,
                        'failed': failed_processes
                    })
                else:
                    results.append({
                        'port': port,
                        'status': 'failed',
                        'failed': failed_processes
                    })

            except Exception as e:
                results.append({
                    'port': port,
                    'status': 'error',
                    'message': f'发生错误: {type(e).__name__}: {str(e)}'
                })

        # 显示结果
        console.print()
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("端口", style="cyan", no_wrap=True)
        table.add_column("状态", style="yellow")
        table.add_column("详情", style="white")

        for result in results:
            port = result['port']
            status = result['status']

            if status == 'success':
                killed = result['processes']
                failed = result.get('failed', [])

                if killed:
                    killed_info = '\n'.join([
                        f"✓ PID {p['pid']}: {p['name']}"
                        for p in killed
                    ])
                    if failed:
                        failed_info = '\n'.join([
                            f"✗ PID {p['pid']}: {p['name']} ({p['reason']})"
                            for p in failed
                        ])
                        info = killed_info + '\n' + failed_info
                        table.add_row(str(port), "[green]部分成功[/green]", info)
                    else:
                        table.add_row(str(port), "[green]成功[/green]", killed_info)
                else:
                    table.add_row(str(port), "[red]失败[/red]", "所有进程都无法 kill")

            elif status == 'failed':
                failed_info = '\n'.join([
                    f"✗ PID {p['pid']}: {p['name']} ({p['reason']})"
                    for p in result['failed']
                ])
                table.add_row(str(port), "[red]失败[/red]", failed_info)

            elif status == 'not_found':
                table.add_row(str(port), "[yellow]未找到[/yellow]", result['message'])

            elif status == 'permission_denied':
                table.add_row(str(port), "[red]权限不足[/red]", result['message'])

            else:  # error
                table.add_row(str(port), "[red]错误[/red]", result['message'])

        console.print(table)
        console.print()


def main():
    """主函数"""
    import os
    import sys
    # less 分页器配置（仅 Unix-like 系统）
    # -R 保留颜色，-X 退出后内容保留在屏幕，-F 内容少时直接输出
    if sys.platform != 'win32':
        os.environ['PAGER'] = 'less -RXF'
    fire.Fire(FlaxKV2CLI)


if __name__ == '__main__':
    main() 