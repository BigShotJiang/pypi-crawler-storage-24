"""
Chroma client and collection operations. One module = one responsibility: connect and add documents.
Requires: pip install hecvec (chromadb). Connects only to a Chroma server; server must be running.
"""
from __future__ import annotations

import logging
import socket
import uuid
import base64
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000

logger = logging.getLogger(__name__)


def _is_port_listening(host: str, port: int, timeout: float = 2.0) -> bool:
    """Return True if something is listening on host:port."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.error):
        return False


def get_client(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    *,
    user: str | None = None,
    password: str | None = None,
):
    """
    Return a Chroma HttpClient connected to the server at host:port.
    Raises RuntimeError if nothing is listening. A Chroma server must be running.

    Auth options:
    - Pass user=... and password=... and we will build auth as "user:password".
    """
    import chromadb
    from chromadb.config import Settings
    logger.info("[5/5] Checking connectivity to %s:%s...", host, port)
    if not _is_port_listening(host, port):
        logger.error("[5/5] Nothing is listening at %s:%s", host, port)
        raise RuntimeError(
            f"Nothing is listening on {host}:{port}. A Chroma server is required. "
            f"Start one with: docker run -p 8000:8000 -v ./chroma-data:/chroma/chroma chromadb/chroma"
        )
    logger.info("[5/5] Port is open at %s:%s; verifying this is a Chroma server...", host, port)
    auth = None
    if user is not None or password is not None:
        if not user or not password:
            raise ValueError("Provide both user and password, or neither.")
        auth = f"{user}:{password}"

    headers = None
    if auth:
        # Standard HTTP Basic Auth header. This works when Chroma is deployed behind a reverse proxy
        # that enforces Basic Auth, and keeps auth transport consistent across future DB backends.
        basic = base64.b64encode(auth.encode("utf-8")).decode("utf-8")
        headers = {"Authorization": f"Basic {basic}"}

    settings = None
    if auth:
        settings = Settings(
            chroma_client_auth_provider="chromadb.auth.basic_authn.BasicAuthClientProvider",
            chroma_client_auth_credentials=auth,
        )
    client = chromadb.HttpClient(host=host, port=port, headers=headers, settings=settings)
    # Verify this is actually a working Chroma server (not just an open port).
    try:
        if hasattr(client, "heartbeat"):
            client.heartbeat()  # type: ignore[attr-defined]
        else:
            client.list_collections()
        logger.info("[5/5] Chroma server verified at %s:%s", host, port)
    except Exception as e:
        raise RuntimeError(
            f"Connected to {host}:{port} but Chroma health check failed. "
            f"This usually means the port is open but it is not a Chroma server, "
            f"or Basic Auth credentials are required/incorrect. Original error: {e!r}"
        ) from e
    return client


def get_cloud_client(*, api_key: str | None, tenant: str | None = None, database: str | None = None):
    """
    Return a Chroma Cloud client.

    Chroma Cloud uses API keys (not host/port + basic auth). The Chroma Python client exposes this
    via chromadb.CloudClient(...).
    """
    if not api_key:
        raise ValueError("chroma_cloud_api_key is required when db='chroma_cloud'")
    import chromadb
    if tenant is None and database is None:
        return chromadb.CloudClient(api_key=api_key)
    # If either is provided, require both for clarity.
    if not tenant or not database:
        raise ValueError("Provide both chroma_cloud_tenant and chroma_cloud_database, or neither.")
    return chromadb.CloudClient(api_key=api_key, tenant=tenant, database=database)


def get_or_create_collection(
    client: "chromadb.api.client.Client",
    name: str,
    metadata: dict | None = None,
):
    """Get or create a collection (cosine similarity by default)."""
    if metadata is None:
        metadata = {"hnsw:space": "cosine"}
    return client.get_or_create_collection(name=name, metadata=metadata)


def add_documents(
    client: "chromadb.api.client.Client",
    collection_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
) -> dict:
    """
    Add documents to a collection. If dimension mismatch, deletes and recreates the collection.
    Returns {"collection_existed": bool} so the caller can log whether the collection was pre-existing.
    """
    import chromadb
    existing_names = [c.name for c in client.list_collections()]
    collection_existed = collection_name in existing_names
    coll = get_or_create_collection(client, collection_name)
    # IDs produced by chunking restart at chunk_0 for each run; namespace by write to avoid collisions.
    write_prefix = uuid.uuid4().hex
    unique_ids = [f"{write_prefix}:{chunk_id}" for chunk_id in ids]
    try:
        coll.add(ids=unique_ids, embeddings=embeddings, documents=documents)
    except chromadb.errors.InvalidArgumentError as e:
        if "dimension" not in str(e).lower():
            raise
        client.delete_collection(name=collection_name)
        coll = client.create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        coll.add(ids=unique_ids, embeddings=embeddings, documents=documents)
        collection_existed = False  # we recreated it
    return {"collection_existed": collection_existed}
