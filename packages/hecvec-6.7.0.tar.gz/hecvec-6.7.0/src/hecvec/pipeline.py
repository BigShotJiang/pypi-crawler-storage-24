"""
Pipeline: composes listdir → read → token-chunk → embed → Chroma.
One module = one responsibility: orchestrate the full slice() flow.
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Literal

DbType = Literal["chroma", "chroma_cloud"]

from hecvec.chroma_client import add_documents, get_client, get_cloud_client
from hecvec.chroma_list import list_collections_from_client
from hecvec.chunkers import ChunkingMethod, chunk_documents as chunk_documents_by_method
from hecvec.embeddings import embed_texts
from hecvec.env import (
    load_chroma_cloud_database,
    load_chroma_cloud_key,
    load_chroma_cloud_tenant,
    load_openai_key,
)
from hecvec.listdir import ListDirTextFiles
from hecvec.reading import ReadText

logger = logging.getLogger(__name__)


def _ensure_slice_logging() -> None:
    """If hecvec logging has no handlers, attach a stream handler at INFO so slice() progress is visible."""
    hecvec_logger = logging.getLogger("hecvec")
    if not hecvec_logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.INFO)
        handler.setFormatter(logging.Formatter("%(message)s"))
        hecvec_logger.setLevel(logging.INFO)
        hecvec_logger.addHandler(handler)
    elif hecvec_logger.level == logging.NOTSET:
        hecvec_logger.setLevel(logging.INFO)


def _check_chroma_deps() -> None:
    try:
        import chromadb  # noqa: F401
        from langchain_text_splitters import TokenTextSplitter  # noqa: F401
        from openai import OpenAI  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "Chroma pipeline requires chromadb and other deps. Install with:\n"
            "  pip install hecvec[chroma]\n"
            "Then run your script with the same Python (or same venv) you used to install. "
            "If you're in the HecVec repo, use: uv run python scripts/test_slice.py ..."
        ) from e


def _record_collection_info(
    *,
    collection_name: str,
    db: str,
    llm: str | None,
    llm_model: str,
    chunking_method: str,
    chunk_size: int,
    chunk_overlap: int,
    encoding_name: str,
    source_path: Path,
) -> None:
    """
    Persist a human-readable registry of created collections.

    File location:
      collection/collections_info.md
    """
    out_dir = Path.cwd() / "collection"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / "collections_info.md"

    _ensure_collections_info_header(out_file)

    created_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    row = (
        f"| {created_at} | {collection_name} | {db} | {llm or '-'} | {llm_model} | "
        f"{chunking_method} | {chunk_size} | {chunk_overlap} | {encoding_name} | {source_path} | 0 |\n"
    )
    with out_file.open("a", encoding="utf-8") as f:
        f.write(row)


def _ensure_collections_info_header(out_file: Path) -> None:
    """
    Ensure collections_info.md exists and uses the current header format.
    Adds append_runs column to older files if missing.
    """
    header = (
        "# Collections Info\n\n"
        "| created_at_utc | collection_name | db | llm | llm_model | chunking_method | chunk_size | chunk_overlap | encoding_name | source_path | append_runs |\n"
        "|---|---|---|---|---|---|---:|---:|---|---|---:|\n"
    )
    if not out_file.exists():
        out_file.write_text(header, encoding="utf-8")
        return

    text = out_file.read_text(encoding="utf-8")
    if "append_runs" in text:
        return

    lines = text.splitlines()
    migrated: list[str] = []
    for line in lines:
        if line.startswith("| created_at_utc "):
            migrated.append(
                "| created_at_utc | collection_name | db | llm | llm_model | chunking_method | chunk_size | chunk_overlap | encoding_name | source_path | append_runs |"
            )
            continue
        if line.startswith("|---"):
            migrated.append("|---|---|---|---|---|---|---:|---:|---|---|---:|")
            continue
        if line.startswith("| ") and line.endswith(" |") and "created_at_utc" not in line:
            migrated.append(f"{line[:-2]} | 0 |")
            continue
        migrated.append(line)
    out_file.write_text("\n".join(migrated) + "\n", encoding="utf-8")


def _increment_collection_append_runs(collection_name: str) -> bool:
    """
    Increment append_runs for a collection in collection/collections_info.md.
    Returns True if a row was found and updated.
    """
    out_file = Path.cwd() / "collection" / "collections_info.md"
    if not out_file.exists():
        return False

    _ensure_collections_info_header(out_file)
    lines = out_file.read_text(encoding="utf-8").splitlines()
    updated = False
    out_lines: list[str] = []
    needle = f"| {collection_name} |"
    for line in lines:
        if line.startswith("| ") and needle in line and not updated:
            parts = [p.strip() for p in line.strip().strip("|").split("|")]
            if len(parts) >= 11:
                try:
                    runs = int(parts[10])
                except ValueError:
                    runs = 0
                parts[10] = str(runs + 1)
                line = "| " + " | ".join(parts) + " |"
                updated = True
        out_lines.append(line)
    out_file.write_text("\n".join(out_lines) + "\n", encoding="utf-8")
    return updated


def _get_db_client(
    db: DbType,
    *,
    host: str = "localhost",
    port: int = 8000,
    user: str | None = None,
    password: str | None = None,
    cloud_api_key: str | None = None,
    cloud_tenant: str | None = None,
    cloud_database: str | None = None,
    **kwargs: Any,
) -> Any:
    """
    Return a database client for the given db type using the connection parameters.
    - db="chroma": uses host/port (and optional user/password for Basic Auth headers).
    - db="chroma_cloud": uses api key (+ optional tenant/database).
    """
    _check_chroma_deps()
    if db == "chroma":
        return get_client(host=host, port=port, user=user, password=password)
    if db == "chroma_cloud":
        return get_cloud_client(
            api_key=cloud_api_key,
            tenant=cloud_tenant,
            database=cloud_database,
        )
    raise ValueError(f"Unsupported db={db!r}. Use 'chroma' or 'chroma_cloud'.")


class Slicer:
    """
    Library-only pipeline. No API.
    Call slice(path=...) to: list path → filter .txt/.md → token-chunk → push to Chroma.
    """

    def __init__(
        self,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        cloud_api_key: str | None = None,
        cloud_tenant: str | None = None,
        cloud_database: str | None = None,
        llm: str | None = None,
        llm_model: str = "text-embedding-3-small",
        embedding_model: str | None = None,
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        llm_token: str | None = None,
        dotenv_path: str | Path | None = None,
    ):
        self.root = Path(root).resolve() if root else Path.cwd()
        self.collection_name = collection_name
        self.db = db
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.cloud_api_key = cloud_api_key or load_chroma_cloud_key(dotenv_path)
        self.cloud_tenant = cloud_tenant or load_chroma_cloud_tenant(dotenv_path)
        self.cloud_database = cloud_database or load_chroma_cloud_database(dotenv_path)
        self.llm = llm
        # Backward compatibility: if embedding_model is provided, use it as llm_model.
        self.llm_model = embedding_model or llm_model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.encoding_name = encoding_name
        self.batch_size = batch_size
        self._dotenv_path = dotenv_path
        self._llm_token = llm_token or load_openai_key(dotenv_path)

    def slice(
        self,
        path: str | Path,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run the pipeline for this instance (uses instance config)."""
        return self._slice_impl(
            path,
            root=kwargs.pop("root", self.root),
            collection_name=kwargs.pop("collection_name", self.collection_name),
            db=kwargs.pop("db", self.db),
            host=kwargs.pop("host", kwargs.pop("chroma_host", self.host)),
            port=kwargs.pop("port", kwargs.pop("chroma_port", self.port)),
            user=kwargs.pop("user", kwargs.pop("chroma_user", self.user)),
            password=kwargs.pop("password", kwargs.pop("chroma_password", self.password)),
            cloud_api_key=kwargs.pop(
                "cloud_api_key",
                kwargs.pop("chroma_cloud_api_key", self.cloud_api_key),
            ),
            cloud_tenant=kwargs.pop(
                "cloud_tenant",
                kwargs.pop("chroma_cloud_tenant", self.cloud_tenant),
            ),
            cloud_database=kwargs.pop(
                "cloud_database",
                kwargs.pop("chroma_cloud_database", self.cloud_database),
            ),
            llm=kwargs.pop("llm", self.llm),
            llm_model=kwargs.pop("llm_model", kwargs.pop("embedding_model", self.llm_model)),
            chunk_size=kwargs.pop("chunk_size", self.chunk_size),
            chunk_overlap=kwargs.pop("chunk_overlap", self.chunk_overlap),
            encoding_name=kwargs.pop("encoding_name", self.encoding_name),
            batch_size=kwargs.pop("batch_size", self.batch_size),
            chunking_method=kwargs.pop("chunking_method", "token"),
            llm_token=kwargs.pop("llm_token", kwargs.pop("openai_api_key", self._llm_token)),
            dotenv_path=kwargs.pop("dotenv_path", self._dotenv_path),
            **kwargs,
        )

    def collections(self, **kwargs: Any) -> list[tuple[str, int]]:
        """List all collections (name, count) using this instance's db config."""
        return self._collections_impl(
            db=kwargs.pop("db", self.db),
            host=kwargs.pop("host", kwargs.pop("chroma_host", self.host)),
            port=kwargs.pop("port", kwargs.pop("chroma_port", self.port)),
            user=kwargs.pop("user", kwargs.pop("chroma_user", self.user)),
            password=kwargs.pop("password", kwargs.pop("chroma_password", self.password)),
            cloud_api_key=kwargs.pop(
                "cloud_api_key",
                kwargs.pop("chroma_cloud_api_key", self.cloud_api_key),
            ),
            cloud_tenant=kwargs.pop(
                "cloud_tenant",
                kwargs.pop("chroma_cloud_tenant", self.cloud_tenant),
            ),
            cloud_database=kwargs.pop(
                "cloud_database",
                kwargs.pop("chroma_cloud_database", self.cloud_database),
            ),
            **kwargs,
        )

    @classmethod
    def slice_path(
        cls,
        path: str | Path,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        cloud_api_key: str | None = None,
        cloud_tenant: str | None = None,
        cloud_database: str | None = None,
        llm: str | None = None,
        llm_model: str = "text-embedding-3-small",
        embedding_model: str | None = None,
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        chunking_method: ChunkingMethod = "token",
        llm_token: str | None = None,
        dotenv_path: str | Path | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run the full pipeline: find path → listdir → filter .txt/.md → chunk → push to db.
        Supports db='chroma' (self-hosted) and db='chroma_cloud'.
        If the resolved collection name already exists, new chunks are appended to it (not skipped).
        """
        return cls._slice_impl(
            path,
            root=root,
            collection_name=collection_name,
            db=db,
            host=host,
            port=port,
            user=user,
            password=password,
            cloud_api_key=cloud_api_key,
            cloud_tenant=cloud_tenant,
            cloud_database=cloud_database,
            llm=llm,
            llm_model=embedding_model or llm_model,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
            batch_size=batch_size,
            chunking_method=chunking_method,
            llm_token=llm_token,
            dotenv_path=dotenv_path,
            **kwargs,
        )

    @classmethod
    def _slice_impl(
        cls,
        path: str | Path,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        cloud_api_key: str | None = None,
        cloud_tenant: str | None = None,
        cloud_database: str | None = None,
        llm: str | None = None,
        llm_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        chunking_method: ChunkingMethod = "token",
        llm_token: str | None = None,
        dotenv_path: str | Path | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        _check_chroma_deps()
        _ensure_slice_logging()

        total_start = perf_counter()
        logger.info(
            "[0/6] Starting slice | path=%s | method=%s | llm=%s | llm_model=%s",
            path,
            chunking_method,
            llm,
            llm_model,
        )

        path = Path(path).resolve()
        if not path.exists():
            raise ValueError(f"path does not exist: {path}")

        if collection_name == "hecvec":
            collection_name = path.stem if path.is_file() else path.name
        # Keep collection names short; detailed config is written to collection/collections_info.md.
        cfg_suffix = f"cs{chunk_size}"
        collection_name = f"{collection_name}_{chunking_method}_{cfg_suffix}"

        logger.info("Resolved collection name: %s", collection_name)

        stage_start = perf_counter()
        if path.is_file():
            if path.suffix.lower() not in (".txt", ".md"):
                raise ValueError(f"File must be .txt or .md: {path}")
            root = path.parent
            paths = [path]
            logger.info("Single file: %s", path)
        else:
            root = Path(root).resolve() if root else path
            if not root.is_dir():
                raise ValueError(f"path must be an existing directory: {root}")
            logger.info("Scanning directory: %s", root)
            lister = ListDirTextFiles(root=root)
            paths = lister.listdir_recursive_txt_md(path)
            if not paths:
                logger.warning("No .txt/.md files found under %s", path)
                return {"files": 0, "chunks": 0, "collection": collection_name, "message": "No .txt/.md files found"}
            logger.info("Found %d .txt/.md file(s)", len(paths))
            for p in paths[:10]:
                logger.info("  %s", p)
            if len(paths) > 10:
                logger.info("  ... and %d more", len(paths) - 10)

        logger.info("[1/6] File discovery completed in %.2fs (%d file(s))", perf_counter() - stage_start, len(paths))

        # 2/6 Chroma server check: fail fast if nothing is listening (before read/chunk/embed to save time & API cost).
        # Step 6 always writes: if the collection name already exists, new chunks are appended (concatenated).
        stage_start = perf_counter()
        if db == "chroma":
            logger.info("[2/6] Chroma server check | db=%s | host=%s | port=%s", db, host, port)
        else:
            logger.info("[2/6] Chroma server check | db=%s | (cloud)", db)
        client = _get_db_client(
            db,
            host=host,
            port=port,
            user=user,
            password=password,
            cloud_api_key=cloud_api_key,
            cloud_tenant=cloud_tenant,
            cloud_database=cloud_database,
        )
        if db == "chroma":
            logger.info(
                "[2/6] Server reachable at %s:%s in %.2fs (client kept for final write)",
                host,
                port,
                perf_counter() - stage_start,
            )
        else:
            logger.info("[2/6] Cloud client created in %.2fs (client kept for final write)", perf_counter() - stage_start)

        # 3/6 Read as text
        stage_start = perf_counter()
        logger.info("[3/6] Reading content from %d file(s)...", len(paths))
        reader = ReadText(paths)
        path_and_text = reader.read_all()
        logger.info("[3/6] Read completed in %.2fs (%d/%d file(s) read)", perf_counter() - stage_start, len(path_and_text), len(paths))
        if len(path_and_text) < len(paths):
            logger.warning("Some files could not be read and were skipped (%d skipped)", len(paths) - len(path_and_text))

        # 4/6 Chunk (token, text, semantic, or llm)
        stage_start = perf_counter()
        api_key = llm_token or load_openai_key(dotenv_path)
        logger.info("[4/6] Chunking | method=%s | chunk_size=%d | overlap=%d", chunking_method, chunk_size, chunk_overlap)
        ids, documents = chunk_documents_by_method(
            path_and_text,
            method=chunking_method,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
            openai_api_key=api_key,
        )
        if not documents:
            logger.warning("[4/6] No chunks generated (empty or non-text content)")
            return {"files": len(path_and_text), "chunks": 0, "collection": collection_name}

        logger.info("[4/6] Chunking completed in %.2fs (%d chunk(s))", perf_counter() - stage_start, len(documents))

        # 5/6 Embed
        if not llm:
            raise ValueError(
                "llm is required for embeddings. Example: llm='openai'. "
                "Also set llm_model (or rely on default 'text-embedding-3-small')."
            )
        if llm != "openai":
            raise ValueError(
                f"Unsupported llm={llm!r} for embeddings. Currently supported: 'openai'."
            )
        api_key = llm_token or load_openai_key(dotenv_path)
        if not api_key:
            raise ValueError(
                "llm_token (or OPENAI_API_KEY in .env/env) is required when llm='openai' for embeddings. "
                "Pass llm_token=..., or set OPENAI_API_KEY in your environment/.env."
            )
        stage_start = perf_counter()
        logger.info(
            "[5/6] Generating embeddings | llm=%s | llm_model=%s | batch_size=%d | chunk_count=%d",
            llm,
            llm_model,
            batch_size,
            len(documents),
        )
        embeddings = embed_texts(
            documents,
            llm=llm,  # type: ignore[arg-type]
            api_key=api_key,
            llm_model=llm_model,
            batch_size=batch_size,
        )
        logger.info("[5/6] Embeddings completed in %.2fs (%d vector(s))", perf_counter() - stage_start, len(embeddings))

        # 6/6 Push to Chroma (reuse client from server check). Always add: append into an existing collection if the name is already in use.
        stage_start = perf_counter()
        logger.info("[6/6] db=%s | host=%s | port=%s | collection=%s", db, host, port, collection_name)
        logger.info("[6/6] Writing %d document chunk(s) to collection...", len(documents))
        add_result = add_documents(client, collection_name, ids, embeddings, documents)
        if add_result["collection_existed"]:
            logger.info(
                "[6/6] Collection %r already existed — concatenating: appending these chunks to that collection (same name).",
                collection_name,
            )
            if _increment_collection_append_runs(collection_name):
                logger.info("[6/6] Incremented append_runs in collection/collections_info.md")
        else:
            logger.info("[6/6] Collection %r did not exist before this run; created and populated.", collection_name)
            _record_collection_info(
                collection_name=collection_name,
                db=db,
                llm=llm,
                llm_model=llm_model,
                chunking_method=chunking_method,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                encoding_name=encoding_name,
                source_path=path,
            )
            logger.info("[6/6] Wrote collection metadata to collection/collections_info.md")
        logger.info("[6/6] Chroma write completed in %.2fs", perf_counter() - stage_start)

        if add_result["collection_existed"]:
            logger.info(
                "Slice finished in %.2fs | files=%d | chunks=%d | collection=%s | appended to existing collection",
                perf_counter() - total_start,
                len(path_and_text),
                len(documents),
                collection_name,
            )
        else:
            logger.info(
                "Slice finished in %.2fs | files=%d | chunks=%d | collection=%s",
                perf_counter() - total_start,
                len(path_and_text),
                len(documents),
                collection_name,
            )

        out: dict[str, Any] = {
            "files": len(path_and_text),
            "chunks": len(documents),
            "collection": collection_name,
            "appended_to_existing": add_result["collection_existed"],
        }
        if add_result["collection_existed"]:
            out["message"] = (
                f"Collection {collection_name!r} already existed; appended {len(documents)} chunk(s) (concatenated)."
            )
        return out

    @classmethod
    def collections_server(
        cls,
        *,
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        cloud_api_key: str | None = None,
        cloud_tenant: str | None = None,
        cloud_database: str | None = None,
        **kwargs: Any,
    ) -> list[tuple[str, int]]:
        """
        List all collections (name, count) from the db.
        Returns [(collection_name, document_count), ...]. Server must be listening.
        """
        return cls._collections_impl(
            db=db,
            host=host,
            port=port,
            user=user,
            password=password,
            cloud_api_key=cloud_api_key,
            cloud_tenant=cloud_tenant,
            cloud_database=cloud_database,
            **kwargs,
        )

    @classmethod
    def _collections_impl(
        cls,
        *,
        db: DbType = "chroma",
        host: str = "localhost",
        port: int = 8000,
        user: str | None = None,
        password: str | None = None,
        cloud_api_key: str | None = None,
        cloud_tenant: str | None = None,
        cloud_database: str | None = None,
        **kwargs: Any,
    ) -> list[tuple[str, int]]:
        client = _get_db_client(
            db,
            host=host,
            port=port,
            user=user,
            password=password,
            cloud_api_key=cloud_api_key,
            cloud_tenant=cloud_tenant,
            cloud_database=cloud_database,
        )
        return list_collections_from_client(client)

