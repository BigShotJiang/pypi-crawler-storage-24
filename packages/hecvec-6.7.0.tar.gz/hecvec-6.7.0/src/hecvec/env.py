"""
Load environment and secrets (e.g. OPENAI_API_KEY from .env).
Use this module to centralize dotenv and env access.
"""
from __future__ import annotations

import os
from pathlib import Path


def load_dotenv_if_available(dotenv_path: str | Path | None = None) -> None:
    """Load .env into os.environ if python-dotenv is installed. No-op otherwise."""
    try:
        from dotenv import load_dotenv
        load_dotenv(dotenv_path)
    except ImportError:
        pass


def load_openai_key(dotenv_path: str | Path | None = None) -> str | None:
    """
    Load OPENAI_API_KEY from the environment.
    If dotenv_path is given (or python-dotenv is available), loads .env first.
    """
    load_dotenv_if_available(dotenv_path)
    return os.environ.get("OPENAI_API_KEY")


def load_chroma_cloud_key(dotenv_path: str | Path | None = None) -> str | None:
    """
    Load Chroma Cloud API key from the environment.

    Preference order:
    - CHROMA_CLOUD_API_KEY (explicit for this project)
    - CHROMA_API_KEY (commonly used by Chroma clients)
    """
    load_dotenv_if_available(dotenv_path)
    return os.environ.get("CHROMA_CLOUD_API_KEY") or os.environ.get("CHROMA_API_KEY")


def load_chroma_cloud_tenant(dotenv_path: str | Path | None = None) -> str | None:
    """Load CHROMA_TENANT from the environment (loads .env first if available)."""
    load_dotenv_if_available(dotenv_path)
    return os.environ.get("CHROMA_TENANT")


def load_chroma_cloud_database(dotenv_path: str | Path | None = None) -> str | None:
    """Load CHROMA_DATABASE from the environment (loads .env first if available)."""
    load_dotenv_if_available(dotenv_path)
    return os.environ.get("CHROMA_DATABASE")
