"""
Embeddings provider abstraction.
Currently supports OpenAI; designed so more LLM providers can be added later.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from openai import OpenAI

DEFAULT_MODEL = "text-embedding-3-small"
DEFAULT_BATCH_SIZE = 100
EmbeddingLlm = Literal["openai"]


def _get_openai_client(api_key: str | None = None) -> "OpenAI":
    from openai import OpenAI
    if not api_key:
        raise ValueError("api_key is required for embeddings")
    return OpenAI(api_key=api_key)


def embed_texts_openai(
    texts: list[str],
    *,
    api_key: str,
    model: str = DEFAULT_MODEL,
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> list[list[float]]:
    """Embed a list of text strings with OpenAI."""
    client = _get_openai_client(api_key)
    out: list[list[float]] = []
    for start in range(0, len(texts), batch_size):
        batch = texts[start : start + batch_size]
        response = client.embeddings.create(model=model, input=batch)
        out.extend([item.embedding for item in response.data])
    return out


def embed_texts(
    texts: list[str],
    *,
    llm: EmbeddingLlm,
    api_key: str,
    llm_model: str = DEFAULT_MODEL,
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> list[list[float]]:
    """
    Embed text with the selected llm provider.
    Currently supported llm values: "openai".
    """
    if llm == "openai":
        return embed_texts_openai(
            texts,
            api_key=api_key,
            model=llm_model,
            batch_size=batch_size,
        )
    raise ValueError(f"Unsupported llm for embeddings: {llm!r}. Currently supported: 'openai'.")
