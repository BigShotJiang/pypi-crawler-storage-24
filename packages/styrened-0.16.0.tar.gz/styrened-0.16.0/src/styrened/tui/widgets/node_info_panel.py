"""Node Info Panel - consolidated local node status.

Combines system hardware, Reticulum stack, and Styrene mesh configuration
into a single unified view of "this node" - the daemon behind the TUI.

Uses cascade colors for theme-aware rendering.
"""


import RNS  # type: ignore
from rich.table import Table
from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static
from textual.worker import Worker

from styrened.models.mesh_device import DeviceType
from styrened.models.rns_error import RNSErrorState
from styrened.services.hub_connection import HubStatus  # Pure data enum, no service state
from styrened.tui.models.hardware import NetworkInterface, SystemInfo
from styrened.tui.services.config import load_config
from styrened.tui.services.hardware import (
    PlatformNotSupportedError,
    get_disks,
    get_network_interfaces,
    get_system_info,
)
from styrened.tui.services.reticulum import get_reticulum_status
from styrened.tui.themes.semantic import SemanticSymbols
from styrened.tui.widgets.highlighted_panel import get_color_cascade
from styrened.ui_state.daemon import (
    HomeNodeInfoState,
    HomeNodeLocalState,
    build_home_node_local_state,
)


class _NodeInfoPanelFallbackStateBuilder:
    """Compatibility helper for the widget-owned non-IPC fallback path."""

    def read_hardware_inputs(self) -> tuple[SystemInfo | None, NetworkInterface | None, int, str | None]:
        """Read hardware inputs for local fallback snapshot construction."""
        try:
            system_info = get_system_info()
        except PlatformNotSupportedError as e:
            return None, None, 0, str(e)

        primary_interface = None
        try:
            interfaces = get_network_interfaces()
            hardware_ifaces = [i for i in interfaces if i.is_hardware and i.is_up and i.ip_address]
            primary_interface = hardware_ifaces[0] if hardware_ifaces else None
        except PlatformNotSupportedError:
            primary_interface = None

        removable_count = 0
        try:
            disks = get_disks()
            removable_count = len([d for d in disks if d.is_removable])
        except PlatformNotSupportedError:
            removable_count = 0

        return system_info, primary_interface, removable_count, None

    def read_local_identity_config(self) -> tuple[str, str, str, str | None, str]:
        """Read local config inputs for fallback/local snapshot construction."""
        try:
            config = load_config()
            mode = config.reticulum.mode.value
            if hasattr(config, "identity"):
                return (
                    mode,
                    config.identity.display_name,
                    config.identity.icon,
                    config.identity.short_name,
                    getattr(config.identity, "provider", "file"),
                )
            return mode, "", "", None, "file"
        except Exception:
            return "standalone", "", "", None, "file"

    def build_local_snapshot(self) -> HomeNodeLocalState:
        """Build a coherent local fallback snapshot for non-IPC widget mode."""
        system_info, primary_interface, removable_count, hardware_error = self.read_hardware_inputs()
        mode, display_name, icon, short_name, identity_provider = self.read_local_identity_config()
        return build_home_node_local_state(
            system_info=system_info,
            primary_interface=primary_interface,
            removable_count=removable_count,
            hardware_error=hardware_error,
            mode=mode,
            identity_display_name=display_name,
            identity_icon=icon,
            identity_short_name=short_name,
            identity_provider=identity_provider,
        )


class NodeInfoPanel(Static):
    """Consolidated panel showing local node configuration and status.

    Displays sections:
    - SYSTEM: Hardware configuration (CPU, RAM, network, storage)
    - DAEMON: IPC connection to backing daemon (only in IPC mode)
    - RETICULUM: Network stack and interface status
    - STYRENE: Mesh participation and hub connection
    """

    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        self._identity_worker: Worker | None = None
        self._mesh_count_worker: Worker | None = None
        self._fallback_state_builder = _NodeInfoPanelFallbackStateBuilder()

    DEFAULT_CSS = """
    NodeInfoPanel {
        height: auto;
        padding: 0 1;
    }
    """

    # Hardware reactive vars
    system_info: reactive[SystemInfo | None] = reactive(None)
    primary_interface: reactive[NetworkInterface | None] = reactive(None)
    removable_count: reactive[int] = reactive(0)
    hardware_error: reactive[str | None] = reactive(None)

    # Styrene reactive vars
    mode: reactive[str] = reactive("standalone")
    hub_status: reactive[HubStatus] = reactive(HubStatus.DISABLED)
    styrene_mesh_count: reactive[int] = reactive(0)

    # Reticulum reactive vars
    rns_online: reactive[bool] = reactive(False)
    interface_count: reactive[int] = reactive(0)
    interface_status: reactive[str] = reactive("")
    error_state: reactive[RNSErrorState | None] = reactive(None)

    # Daemon reactive vars (IPC mode only - None means legacy/standalone mode)
    daemon_connected: reactive[bool | None] = reactive(None)
    daemon_version: reactive[str] = reactive("")
    daemon_uptime: reactive[float] = reactive(0.0)

    # Identity reactive vars
    identity_display_name: reactive[str] = reactive("")
    identity_icon: reactive[str] = reactive("")
    identity_short_name: reactive[str | None] = reactive(None)
    identity_hash: reactive[str] = reactive("")

    # Security tier (PQC session status)
    security_tier: reactive[str] = reactive("")

    # Comms reactive vars (populated from IPC or local DB)
    unread_count: reactive[int] = reactive(0)
    conversation_count: reactive[int] = reactive(0)
    contact_count: reactive[int] = reactive(0)
    messages_sent: reactive[int] = reactive(0)
    messages_received: reactive[int] = reactive(0)
    pending_deliveries: reactive[int] = reactive(0)
    auto_reply_enabled: reactive[bool] = reactive(False)
    propagation_enabled: reactive[bool] = reactive(False)
    transport_enabled: reactive[bool] = reactive(False)
    active_links: reactive[int] = reactive(0)

    # When True, skip local RNS/discovery queries (screen pushes daemon data)
    ipc_managed: reactive[bool] = reactive(False)

    @staticmethod
    def _format_uptime(seconds: float) -> str:
        """Format uptime seconds into human-readable string.

        Returns:
            Compact uptime like "45s", "12m", "2h 15m", "3d 4h".
        """
        s = int(seconds)
        if s < 60:
            return f"{s}s"
        elif s < 3600:
            return f"{s // 60}m"
        elif s < 86400:
            h = s // 3600
            m = (s % 3600) // 60
            return f"{h}h {m}m" if m else f"{h}h"
        else:
            d = s // 86400
            h = (s % 86400) // 3600
            return f"{d}d {h}h" if h else f"{d}d"

    def _render_left_column(self, cascade: object) -> list[str]:
        """Render left column: SYSTEM, DAEMON, IDENTITY."""
        lines: list[str] = []

        # === SYSTEM ===
        lines.append(f"[{cascade.bright}]SYSTEM[/]")
        if self.hardware_error:
            lines.append(f"  [{cascade.dim}]unsupported platform[/]")
        else:
            if self.system_info:
                cpu = self.system_info.cpu_model
                if len(cpu) > 35:
                    cpu = cpu[:32] + "..."
                lines.append(f"  CPU: {cpu} ({self.system_info.cpu_cores}c, {self.system_info.ram_total_gb:.1f}GB)")
            else:
                lines.append(f"  CPU: [{cascade.dim}]detecting...[/]")

            if self.primary_interface:
                iface = self.primary_interface
                ip = iface.ip_address or f"[{cascade.dim}]no ip[/]"
                iface_type = iface.interface_type.value.upper()
                lines.append(f"  NET: {iface.name} ({iface_type}) [{cascade.medium}]{ip}[/]")
            else:
                lines.append(f"  NET: [{cascade.dim}]none[/]")

            if self.removable_count > 0:
                lines.append(f"  STORAGE: [{cascade.bright} bold]{self.removable_count} removable[/]")
            else:
                lines.append(f"  STORAGE: [{cascade.dim}]no removable[/]")

        # === DAEMON (IPC mode only) ===
        if self.daemon_connected is not None:
            lines.append("")
            lines.append(f"[{cascade.bright}]DAEMON[/]")
            if self.daemon_connected:
                lines.append(f"  IPC: {SemanticSymbols.ONLINE} [{cascade.medium}]connected[/]")
                if self.daemon_uptime > 0:
                    lines.append(f"  UP: {self._format_uptime(self.daemon_uptime)}")
            else:
                lines.append(f"  IPC: {SemanticSymbols.OFFLINE} [{cascade.dim}]disconnected[/]")

        # === IDENTITY ===
        if self.identity_display_name or self.identity_icon:
            lines.append("")
            lines.append(f"[{cascade.bright}]IDENTITY[/]")
            name_parts = []
            if self.identity_icon:
                name_parts.append(self.identity_icon)
            if self.identity_display_name:
                name_parts.append(self.identity_display_name)
            if name_parts:
                lines.append(f"  NAME: [{cascade.medium}]{' '.join(name_parts)}[/]")
            if self.identity_short_name:
                lines.append(f"  ALIAS: [{cascade.medium}]{self.identity_short_name}[/]")
            else:
                lines.append(f"  ALIAS: [{cascade.dim}]not set[/]")
            if self.identity_hash:
                lines.append(f"  HASH: [{cascade.dim}]{self.identity_hash[:16]}[/]")
            if self.security_tier:
                tier_color = cascade.bright if "PQC" in self.security_tier.upper() else cascade.medium
                lines.append(f"  SEC: [{tier_color}]{self.security_tier}[/]")

        # === COMMS ===
        lines.append("")
        lines.append(f"[{cascade.bright}]COMMS[/]")
        if self.unread_count > 0:
            lines.append(f"  INBOX: [{cascade.bright} bold]✉ {self.unread_count} unread[/]")
        else:
            lines.append(f"  INBOX: [{cascade.dim}]no unread[/]")
        if self.conversation_count > 0:
            lines.append(f"  CHATS: [{cascade.medium}]{self.conversation_count}[/]")
        else:
            lines.append(f"  CHATS: [{cascade.dim}]none[/]")
        if self.contact_count > 0:
            lines.append(f"  CONTACTS: [{cascade.medium}]{self.contact_count}[/]")
        else:
            lines.append(f"  CONTACTS: [{cascade.dim}]none[/]")
        if self.auto_reply_enabled:
            lines.append(f"  AUTO-REPLY: {SemanticSymbols.ONLINE} [{cascade.medium}]on[/]")

        return lines

    def _render_right_column(self, cascade: object) -> list[str]:
        """Render right column: RETICULUM, STYRENE, VERSION."""
        lines: list[str] = []

        # === RETICULUM ===
        lines.append(f"[{cascade.bright}]RETICULUM[/]")
        if self.rns_online:
            if self.interface_count > 0:
                lines.append(f"  RNS: {SemanticSymbols.ONLINE} [{cascade.medium}]online ({self.interface_count} if)[/]")
            else:
                lines.append(f"  RNS: {SemanticSymbols.PENDING} [{cascade.medium}]no interfaces[/]")
        else:
            if self.error_state and self.error_state.is_error:
                lines.append(f"  RNS: {SemanticSymbols.REJECTED} [{cascade.bright}]{self.error_state.title}[/]")
            else:
                lines.append(f"  RNS: {SemanticSymbols.OFFLINE} [{cascade.dim}]offline[/]")

        if self.rns_online:
            if self.interface_status:
                lines.append(f"  UPLINK: {self.interface_status}")
            elif self.interface_count == 0:
                lines.append(f"  UPLINK: {SemanticSymbols.OFFLINE} [{cascade.dim}]no interfaces[/]")
        elif self.error_state and self.error_state.is_error:
            recovery = self.error_state.recovery
            if recovery:
                if len(recovery) > 40:
                    recovery = recovery[:37] + "..."
                lines.append(f"  [{cascade.medium}]{SemanticSymbols.PROCESSING} {recovery}[/]")

        # === STYRENE ===
        lines.append("")
        lines.append(f"[{cascade.bright}]STYRENE[/]")

        mode_display = self.mode.upper()
        if self.mode == "hub":
            lines.append(f"  MODE: {SemanticSymbols.ONLINE} [{cascade.medium}]{mode_display}[/]")
        elif self.mode == "peer":
            lines.append(f"  MODE: {SemanticSymbols.PENDING} [{cascade.medium}]{mode_display}[/]")
        else:
            lines.append(f"  MODE: {SemanticSymbols.IDLE} [{cascade.dim}]{mode_display}[/]")

        if self.hub_status == HubStatus.CONNECTED:
            lines.append(f"  HUB: {SemanticSymbols.ONLINE} [{cascade.medium}]connected[/]")
        elif self.hub_status == HubStatus.WAITING:
            lines.append(f"  HUB: {SemanticSymbols.PENDING} [{cascade.medium}]waiting...[/]")
        elif self.hub_status == HubStatus.DISCONNECTED:
            lines.append(f"  HUB: {SemanticSymbols.OFFLINE} [{cascade.dim}]disconnected[/]")
        else:
            lines.append(f"  HUB: {SemanticSymbols.OFFLINE} [{cascade.dim}]disabled[/]")

        if self.styrene_mesh_count > 0:
            noun = "node" if self.styrene_mesh_count == 1 else "nodes"
            lines.append(f"  MESH: {SemanticSymbols.ONLINE} [{cascade.medium}]{self.styrene_mesh_count} {noun}[/]")
        elif not self.rns_online and self.error_state and self.error_state.is_error:
            pass
        else:
            lines.append(f"  MESH: {SemanticSymbols.OFFLINE} [{cascade.dim}]no nodes[/]")

        # === TRAFFIC ===
        lines.append("")
        lines.append(f"[{cascade.bright}]TRAFFIC[/]")
        traffic_parts = []
        if self.messages_sent > 0:
            traffic_parts.append(f"↑{self.messages_sent}")
        if self.messages_received > 0:
            traffic_parts.append(f"↓{self.messages_received}")
        if traffic_parts:
            lines.append(f"  MSG: [{cascade.medium}]{' '.join(traffic_parts)}[/]")
        else:
            lines.append(f"  MSG: [{cascade.dim}]no traffic[/]")
        if self.pending_deliveries > 0:
            lines.append(f"  PENDING: [{cascade.bright}]{self.pending_deliveries}[/]")
        if self.active_links > 0:
            lines.append(f"  LINKS: [{cascade.medium}]{self.active_links} active[/]")
        role_parts = []
        if self.transport_enabled:
            role_parts.append("transport")
        if self.propagation_enabled:
            role_parts.append("propagation")
        if role_parts:
            lines.append(f"  ROLE: [{cascade.medium}]{', '.join(role_parts)}[/]")

        # === VERSION ===
        lines.append("")
        try:
            from styrened import __version__
            version = self.daemon_version if self.daemon_version else __version__
            lines.append(f"[{cascade.bright}]VERSION[/]")
            lines.append(f"  [{cascade.medium}]styrened {version}[/]")
        except ImportError:
            pass

        return lines

    def render(self) -> Table:
        """Render two-column node info display using a Rich Table.

        Left column: SYSTEM, DAEMON, IDENTITY
        Right column: RETICULUM, STYRENE, VERSION

        Uses a borderless Rich Table so column widths are computed by Rich's
        own layout engine rather than manual character counting — immune to
        ambiguous-width Unicode, emoji, and font-specific glyph widths.
        """
        cascade = get_color_cascade()
        left = self._render_left_column(cascade)
        right = self._render_right_column(cascade)

        # Pad shorter column to match heights
        max_lines = max(len(left), len(right))
        while len(left) < max_lines:
            left.append("")
        while len(right) < max_lines:
            right.append("")

        table = Table.grid(padding=(0, 2))
        table.add_column(min_width=42, no_wrap=False)
        table.add_column(no_wrap=False)

        for l_line, r_line in zip(left, right, strict=False):
            table.add_row(Text.from_markup(l_line), Text.from_markup(r_line))

        return table

    @property
    def _bridge(self) -> object | None:
        """Best-effort access to the app bridge without raising in tests/legacy mode."""
        try:
            return self.app.services.bridge  # type: ignore[union-attr]
        except Exception:
            return None

    def _start_identity_load(self) -> Worker:
        """Start or replace the identity-loading worker."""
        self._identity_worker = self.run_worker(
            self._load_identity_via_bridge(),
            group="identity-load",
            exclusive=True,
        )
        return self._identity_worker

    def _start_mesh_count_load(self) -> Worker:
        """Start or replace the mesh-count worker."""
        self._mesh_count_worker = self.run_worker(
            self._load_mesh_count_via_bridge(),
            group="mesh-discovery",
            exclusive=True,
        )
        return self._mesh_count_worker

    def on_mount(self) -> None:
        """Load all node data on mount."""
        self._load_all_data()

    def on_unmount(self) -> None:
        """Cancel in-flight bridge workers when the panel is removed."""
        if self._identity_worker is not None:
            self._identity_worker.cancel()
            self._identity_worker = None
        if self._mesh_count_worker is not None:
            self._mesh_count_worker.cancel()
            self._mesh_count_worker = None

    def _load_all_data(self) -> None:
        """Dispatch to the appropriate widget-owned refresh mode.

        IPC-managed Home treats this widget as presentation-only. Fallback/local
        mode retains the historical widget-owned refresh path.
        """
        if self.ipc_managed:
            self._refresh_ipc_managed_presentation()
            return
        self._refresh_local_fallback_mode()

    def _refresh_ipc_managed_presentation(self) -> None:
        """No-op refresh path for presentation-only IPC-managed Home.

        Parent screens own both local and daemon-backed snapshots in this mode.
        """
        return

    def _refresh_local_fallback_mode(self) -> None:
        """Legacy/local widget-owned refresh path used outside IPC-managed Home."""
        self._load_local_fallback_state()
        self._refresh_bridge_backed_fallback_state()

    def _load_local_fallback_state(self) -> None:
        """Load synchronous local fallback state only."""
        self.apply_home_local_snapshot(self._build_local_fallback_snapshot())
        self._load_reticulum_data()

    def _refresh_bridge_backed_fallback_state(self) -> None:
        """Schedule async bridge-backed refreshes for fallback/local mode only."""
        self._refresh_identity_via_bridge()
        self._refresh_mesh_count_via_bridge()

    def apply_home_local_snapshot(self, snapshot: HomeNodeLocalState) -> None:
        """Apply a coherent local Home snapshot to presentation state."""
        self.system_info = snapshot.system_info
        self.primary_interface = snapshot.primary_interface
        self.removable_count = snapshot.removable_count
        self.hardware_error = snapshot.hardware_error
        self.mode = snapshot.mode
        self.identity_display_name = snapshot.identity_display_name
        self.identity_icon = snapshot.identity_icon
        self.identity_short_name = snapshot.identity_short_name
        self.security_tier = snapshot.security_tier

    def _build_local_fallback_snapshot(self) -> HomeNodeLocalState:
        """Build a coherent local fallback snapshot for non-IPC widget mode."""
        return self._fallback_state_builder.build_local_snapshot()

    def _load_styrene_local_data(self) -> None:
        """Load synchronous Styrene-local config only.

        This intentionally excludes bridge-backed identity and mesh queries so
        callers can refresh local and async state independently.
        """
        snapshot = build_home_node_local_state(
            mode=self.mode,
            identity_display_name=self.identity_display_name,
            identity_icon=self.identity_icon,
            identity_short_name=self.identity_short_name,
            identity_provider="yubikey" if self.security_tier == "YubiKey/FIDO2" else "file",
        )
        mode, display_name, icon, short_name, identity_provider = (
            self._fallback_state_builder.read_local_identity_config()
        )
        snapshot = build_home_node_local_state(
            system_info=snapshot.system_info,
            primary_interface=snapshot.primary_interface,
            removable_count=snapshot.removable_count,
            hardware_error=snapshot.hardware_error,
            mode=mode,
            identity_display_name=display_name,
            identity_icon=icon,
            identity_short_name=short_name,
            identity_provider=identity_provider,
        )
        self.mode = snapshot.mode
        self.identity_display_name = snapshot.identity_display_name
        self.identity_icon = snapshot.identity_icon
        self.identity_short_name = snapshot.identity_short_name
        self.security_tier = snapshot.security_tier

        # In IPC mode, dashboard pushes mesh count and hub status from daemon.
        # In non-managed mode, report hub status as disabled locally.
        if not self.ipc_managed:
            self.hub_status = HubStatus.DISABLED

    def _refresh_identity_via_bridge(self) -> None:
        """Schedule identity refresh if bridge-backed identity is still missing."""
        if self.identity_hash or self._bridge is None:
            return
        self._start_identity_load()

    def _refresh_mesh_count_via_bridge(self) -> None:
        """Schedule mesh-count refresh when local mode owns mesh counting."""
        if self.ipc_managed or self._bridge is None:
            return
        self._start_mesh_count_load()

    def _apply_identity_snapshot(self, identity_hash: str, *, security_tier: str | None = None) -> None:
        """Apply bridge-backed identity data to panel state.

        Kept as a separate integration point so future app-level state models can
        push identity snapshots into the widget without going through worker code.
        """
        self.identity_hash = identity_hash

        if security_tier is not None:
            self.security_tier = security_tier
            return

        provider = "file"
        try:
            config = load_config()
            if config and hasattr(config, "identity"):
                provider = getattr(config.identity, "provider", "file")
        except Exception:
            provider = "file"
        if provider == "yubikey":
            self.security_tier = "YubiKey/FIDO2"
        else:
            self.security_tier = "X25519"

    async def _load_identity_via_bridge(self) -> None:
        """Load operator identity via IPC bridge."""
        try:
            bridge = self._bridge
            if bridge is None:
                return

            identity_info = await bridge.get_identity()
            if identity_info.identity_hash:
                self._apply_identity_snapshot(identity_info.identity_hash)
        except Exception:
            # No fallback - rely on IPC bridge only
            pass
    
    def _apply_mesh_catalog_count(self, device_infos: tuple[object, ...]) -> int:
        """Apply mesh count from canonical node catalog normalization.

        This exists as an integration seam for future app-level/shared state so
        dashboard code can push normalized node inventories into the widget.
        Returns the normalized mesh node count for parent-owned snapshot builders.
        """
        from styrened.ui_state.nodes import NodeCatalogInputs, build_node_catalog

        inputs = NodeCatalogInputs(devices=device_infos)
        catalog = build_node_catalog(inputs)
        self.styrene_mesh_count = len(catalog.nodes)
        return self.styrene_mesh_count

    def apply_home_snapshot(self, snapshot: HomeNodeInfoState) -> None:
        """Apply a coherent dashboard-owned Home snapshot to presentation state."""
        self.daemon_connected = snapshot.daemon_connected
        self.daemon_version = snapshot.daemon_version
        self.daemon_uptime = snapshot.daemon_uptime
        self.hub_status = snapshot.hub_status
        self.styrene_mesh_count = snapshot.styrene_mesh_count
        self.rns_online = snapshot.rns_online
        self.interface_count = snapshot.interface_count
        self.propagation_enabled = snapshot.propagation_enabled
        self.transport_enabled = snapshot.transport_enabled
        self.active_links = snapshot.active_links
        self.unread_count = snapshot.unread_count
        self.conversation_count = snapshot.conversation_count
        self.contact_count = snapshot.contact_count
        self.messages_sent = snapshot.messages_sent
        self.messages_received = snapshot.messages_received
        self.pending_deliveries = snapshot.pending_deliveries
        self.auto_reply_enabled = snapshot.auto_reply_enabled

        self.identity_hash = ""
        if snapshot.local_identity_hash:
            self._apply_identity_snapshot(
                snapshot.local_identity_hash,
                security_tier=self.security_tier,
            )

    async def _load_mesh_count_via_bridge(self) -> None:
        """Load mesh device count via IPC bridge."""
        try:
            bridge = self._bridge
            if bridge is None:
                return

            # Get only Styrene nodes using canonical node catalog normalization
            device_infos = await bridge.get_devices(styrene_only=True)
            self._apply_mesh_catalog_count(tuple(device_infos))
        except Exception:
            # No fallback - rely on IPC bridge only
            pass

    def _load_reticulum_data(self) -> None:
        """Load Reticulum stack status."""
        # In IPC mode, dashboard pushes RNS status from daemon
        if self.ipc_managed:
            return

        # Get RNS status
        status = get_reticulum_status()
        self.rns_online = bool(status.get("running", False))

        # Get error state from app's lifecycle if available
        self.error_state = self._get_error_state()

        # Get interface information
        if self.rns_online and hasattr(RNS.Transport, "interfaces"):
            try:
                interfaces = RNS.Transport.interfaces
                if interfaces:
                    self.interface_count = len(interfaces)
                    # Get interface types and online status
                    interface_parts = []
                    for interface in interfaces:
                        iface_type = type(interface).__name__

                        # Shorten common names
                        if "LocalClient" in iface_type:
                            iface_type = "Local"
                        elif "AutoInterface" in iface_type:
                            iface_type = "Auto"
                        elif "TCPClient" in iface_type:
                            iface_type = "TCP"
                        elif "UDPInterface" in iface_type:
                            iface_type = "UDP"

                        # Color by status
                        cascade = get_color_cascade()
                        iface_online = getattr(interface, "online", False)
                        if iface_online:
                            interface_parts.append(f"[{cascade.medium}]{iface_type}[/]")
                        else:
                            interface_parts.append(f"[{cascade.dim}]{iface_type}[/]")

                    self.interface_status = ", ".join(interface_parts)
                else:
                    self.interface_count = 0
                    self.interface_status = ""
            except Exception:
                self.interface_count = 0
                self.interface_status = ""
        else:
            self.interface_count = 0
            self.interface_status = ""

    def _get_error_state(self) -> RNSErrorState | None:
        """Get the RNS error state.

        In IPC mode, error state is set externally by the dashboard via
        the ``error_state`` reactive (from daemon status events).
        Returns None — the reactive provides the actual value.

        TODO: Add a GET_RNS_ERROR IPC command so the panel can fetch
        error state directly on refresh, not only when pushed.
        """
        return None

    def refresh_data(self) -> None:
        """Refresh all node data."""
        self._load_all_data()
