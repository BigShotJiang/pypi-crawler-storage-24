2026-03-02 Version: 0.0.8
- 涉及产品:EIP 创建资源转移返回转移ID&资源ID
2026-02-27 Version: 0.0.7
- 方法名称修正
2026-02-27 Version: 0.0.6
- params判断None
2026-02-26 Version: 0.0.5
- 支持EIP资源转移
2026-02-11 Version: 0.0.4
- 支持EIP接口SDK
2026-02-10 Version: 0.0.3
- Init
2026-02-10 Version: 0.0.2
- Init
2026-02-10 Version: 0.0.1
- Init