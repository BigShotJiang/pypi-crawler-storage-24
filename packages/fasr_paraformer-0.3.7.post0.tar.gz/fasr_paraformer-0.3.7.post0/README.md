# fasr-paraformer

基于 Paraformer 的语音识别流水线插件，为 [fasr](../../README.md) 提供离线/流式 ASR、VAD 和标点恢复能力。

## 安装

```bash
# 作为 fasr 工作空间成员安装
uv sync

# 或单独安装
pip install fasr-paraformer
```

## 快速开始

```python
import fasr

# 加载预置流水线（自动下载模型）
asr = fasr.load("paraformer")

# 识别音频
audios = asr("example.wav")
print(audios[0].text)
```

## 预置流水线

| 流水线名称 | 组件构成 | 说明 |
|---|---|---|
| `paraformer` | FSMN VAD → Paraformer → CT-Transformer | 通用中文离线识别，带时间戳 |
| `seaco_paraformer` | FSMN VAD → Seaco-Paraformer → CT-Transformer | 支持热词的离线识别 |
| `sensevoice` | FSMN VAD → SenseVoice → CT-Transformer | 多语言情感识别 |

```python
# 带热词的识别
asr = fasr.load("seaco_paraformer")
audios = asr("meeting.wav", hotwords=["Paraformer", "语音识别"])
```

## 模型组件

### ASR 模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `paraformer` | `ParaformerForASR` | `iic/speech_paraformer-large-vad-punc_asr_nat-zh-cn-16k-common-vocab8404-pytorch` | 离线 Paraformer，输出带时间戳的 token |
| `seaco_paraformer` | `SeacoParaformerForASR` | `iic/speech_seaco_paraformer_large_asr_nat-zh-cn-16k-common-vocab8404-pytorch` | 支持热词偏置的 Paraformer |
| `stream_paraformer` | `ParaformerForStreamASR` | `iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-online` | 流式 Paraformer (Torch) |
| `stream_paraformer.onnx` | `ParaformerForStreamASROnnx` | 同上 | 流式 Paraformer (ONNX) |

### VAD 模型

| 注册名 | 类 | 说明 |
|---|---|---|
| `fsmn` | `FSMNForVAD` | FSMN 离线 VAD，ONNX Runtime 推理，内置模型权重 |
| `stream_fsmn` | `FSMNForStreamVAD` | FSMN 流式 VAD (Torch) |
| `stream_fsmn.onnx` | `FSMNForStreamVADOnnx` | FSMN 流式 VAD (ONNX) |

### 标点模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `ct_transformer` | `CTTransformerForPunc` | `iic/punc_ct-transformer_zh-cn-common-vocab272727-pytorch` | CT-Transformer 标点恢复，中英文混合 |

## 自定义流水线

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="fsmn")
    .add_pipe("recognizer", model="seaco_paraformer")
    .add_pipe("sentencizer", model="ct_transformer")
)

audios = pipeline("audio.wav")
```

## 依赖

- `fasr >= 0.3.7`
- `funasr`
- `funasr-onnx >= 0.4.1`
- `onnxruntime >= 1.24.3`
- `torch >= 2.8.0`
- `torchaudio >= 2.8.0`
- Python 3.10–3.12

## 项目结构

```
src/fasr_paraformer/
├── __init__.py              # 流水线构建函数 & entry points
├── asset/fsmn-vad/          # 内置 FSMN VAD 模型权重与配置
├── models/
│   ├── asr.py               # Paraformer / Seaco-Paraformer
│   ├── vad.py               # FSMN VAD
│   ├── pun.py               # CT-Transformer 标点恢复
│   ├── stream_asr.py        # 流式 Paraformer (Torch / ONNX)
│   └── stream_vad.py        # 流式 FSMN VAD (Torch / ONNX)
├── preprocessors/
│   ├── waveform/             # Fbank 特征提取、LFR、CMVN
│   └── text/                 # SentencePiece / Char 分词器
└── runtimes/
    └── ort.py                # ONNX Runtime 推理封装
```
