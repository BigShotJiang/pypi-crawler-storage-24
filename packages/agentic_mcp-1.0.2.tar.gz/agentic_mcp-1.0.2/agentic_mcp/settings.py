from typing import Generic, Literal

from agentic_base.evaluation.settings import (
    DenseRetrieverSettings,
    NomicProcessorSettings,
    QdrantVectorStoreSettings,
    RerankerSettings,
    VLLMEmbedderSettings,
)
from agentic_base.settings import FromConfigMixinSettings
from agentic_mcp.constants import TCEvidenceBuilder
from pydantic_settings import BaseSettings


class ServerSettings(BaseSettings):
    transport: Literal['stdio', 'http', 'sse', 'streamable-http']
    host: str
    port: int


class RunnerSettings(FromConfigMixinSettings):
    pass


class EvidenceBuilderSettings(FromConfigMixinSettings):
    pass


class RetrieverWrapperSettings(BaseSettings):
    engine: DenseRetrieverSettings[
        VLLMEmbedderSettings, QdrantVectorStoreSettings, NomicProcessorSettings, RerankerSettings
    ]
    limit: int


class MCPRunnerSettings(RunnerSettings, Generic[TCEvidenceBuilder]):
    server: ServerSettings
    retriever: RetrieverWrapperSettings
    evidence: TCEvidenceBuilder
