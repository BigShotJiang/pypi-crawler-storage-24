import unittest
from unittest.mock import MagicMock
from jinja2 import Environment

from soprano_sdk.nodes.follow_up import FollowUpStrategy
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.core.constants import WorkflowKeys

class TestAgentDescriptionJinja(unittest.TestCase):
    def setUp(self):
        self.engine_context = MagicMock()
        self.engine_context.get_config_value.return_value = Environment()
        self.engine_context.data_fields = []

    def test_collect_input_renders_description(self):
        step_config = {
            'id': 'step_1',
            'action': 'collect_input_with_agent',
            'field': 'some_field',
            'agent': {
                'description': 'Description for {{ user_name }}'
            }
        }
        strategy = CollectInputStrategy(step_config, self.engine_context)
        state = {
            'user_name': 'Alice',
            WorkflowKeys.COLLECTOR_NODES: {}
        }
        
        strategy._register_collector_node(state)
        
        self.assertEqual(
            state[WorkflowKeys.COLLECTOR_NODES]['step_1'],
            'Description for Alice'
        )

    def test_follow_up_renders_description(self):
        follow_up_config = {
            'name': 'follow_up'
        }
        strategy = FollowUpStrategy(follow_up_config, self.engine_context, first_step_id='step_1')
        
        state = {
            'user_name': 'Bob',
            WorkflowKeys.COLLECTOR_NODES: {
                'step_1': 'Description for {{ user_name }}'
            }
        }
        
        guidance = strategy._build_intent_change_guidance(state)
        self.assertIn('Description for Bob', guidance)

if __name__ == '__main__':
    unittest.main()
