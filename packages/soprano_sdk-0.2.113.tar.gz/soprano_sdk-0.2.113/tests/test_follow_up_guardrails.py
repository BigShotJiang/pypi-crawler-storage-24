from unittest.mock import MagicMock, patch

from soprano_sdk.agents.structured_output import FollowUpOutput
from soprano_sdk.core.constants import FOLLOW_UP_NODE, WorkflowKeys
from soprano_sdk.nodes.follow_up import FollowUpStrategy
from soprano_sdk.guardrails import GuardrailViolationError, GuardrailFailureResponse

def _make_engine_context(
    failure_message: str = "",
    guardrail_registry=None,
    data_fields=None,
):
    ctx = MagicMock()
    ctx.failure_message = failure_message
    ctx.guardrail_registry = guardrail_registry or {}
    ctx.data_fields = data_fields or []
    ctx.get_config_value.side_effect = lambda key, default=None: default
    ctx.get_base_localization_instructions.return_value = "Base Localization"
    ctx.get_localization_rule.return_value = None
    ctx.get_localization_wait_phrases.return_value = []
    return ctx

def _make_strategy(
    follow_up_config=None,
    engine_context=None,
) -> FollowUpStrategy:
    if engine_context is None:
        engine_context = _make_engine_context()
    cfg = follow_up_config or {}
    return FollowUpStrategy(
        follow_up_config=cfg,
        engine_context=engine_context,
        first_step_id="step1",
        node_id=FOLLOW_UP_NODE,
    )

class TestFollowUpGuardrails:
    def test_init_loads_guardrails(self):
        g1 = MagicMock()
        g2 = MagicMock()
        registry = {"g1": g1, "g2": g2}
        ctx = _make_engine_context(guardrail_registry=registry)
        
        # Load both
        s = _make_strategy(follow_up_config={"guardrails": ["g1", "g2"]}, engine_context=ctx)
        assert s.output_guardrails == [g1, g2]
        
        # Load only existing
        s2 = _make_strategy(follow_up_config={"guardrails": ["g1", "missing"]}, engine_context=ctx)
        assert s2.output_guardrails == [g1]

    def test_build_function_outputs(self):
        s = _make_strategy()
        state = {
            WorkflowKeys.COMPUTED_FIELDS: ["field1", "field2"],
            "field1": "val1",
            "field2": 123,
            "field3": "ignored"
        }
        outputs = s._build_function_outputs(state)
        assert "field1: val1" in outputs
        assert "field2: 123" in outputs
        assert len(outputs) == 2

    def test_build_grounding_source(self):
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}])
        s = _make_strategy(follow_up_config={"accessible_fields": ["loan_id"]}, engine_context=ctx)
        agent = MagicMock()
        agent.last_tool_outputs = ["tool output 1"]
        state = {"loan_id": "LN789"}
        
        source = s._build_grounding_source(state, agent)
        assert "AGENT INSTRUCTIONS:" in source
        assert "WORKFLOW DATA:" in source
        assert "LN789" in source
        assert "TOOL OUTPUTS:" in source
        assert "tool output 1" in source

    def test_get_agent_response_sets_context(self):
        g1 = MagicMock()
        ctx = _make_engine_context(guardrail_registry={"g1": g1})
        s = _make_strategy(follow_up_config={"guardrails": ["g1"]}, engine_context=ctx)
        
        mock_agent = MagicMock()
        conversation = [{"role": "user", "content": "hello"}]
        
        with patch.object(s, "_create_agent", return_value=mock_agent):
            with patch.object(s, "_invoke_llm", return_value=FollowUpOutput(bot_response="resp")):
                s._get_agent_response({}, conversation)
                
        assert hasattr(mock_agent, "guardrail_context")
        assert mock_agent.guardrail_context["query"] == "hello"
        assert "grounding_source" in mock_agent.guardrail_context

    def test_get_agent_response_handles_violation(self):
        g1 = MagicMock()
        ctx = _make_engine_context(guardrail_registry={"g1": g1})
        s = _make_strategy(follow_up_config={"guardrails": ["g1"]}, engine_context=ctx)
        
        mock_agent = MagicMock()
        conversation = [{"role": "user", "content": "hello"}]
        
        error_msg = "Stop! Violation."
        with patch.object(s, "_create_agent", return_value=mock_agent):
            with patch.object(s, "_invoke_llm", side_effect=GuardrailViolationError(error_msg)):
                result = s._get_agent_response({}, conversation)
                
        assert isinstance(result, GuardrailFailureResponse)
        assert result.error_message == error_msg
        # Check that error message was added to conversation
        assert conversation[-1]["role"] == "assistant"
        assert conversation[-1]["content"] == error_msg

    def test_execute_handles_guardrail_failure(self):
        s = _make_strategy()
        conv_key = f"{FOLLOW_UP_NODE}_conversation"
        state = {
            WorkflowKeys.FOLLOW_UP_ACTIVE: True,
            WorkflowKeys.FOLLOW_UP_ATTEMPTS: 1,
            WorkflowKeys.USER_MESSAGE: "bad query",
            WorkflowKeys.CONVERSATIONS: {conv_key: []}
        }
        
        error_msg = "Grounding error"
        failure = GuardrailFailureResponse(error_msg)
        
        # We need to simulate _get_agent_response adding the message to the conversation
        def mock_get_response(st, conv):
            conv.append({"role": "assistant", "content": error_msg})
            return failure

        with patch.object(s, "_get_agent_response", side_effect=mock_get_response):
            with patch("soprano_sdk.nodes.follow_up.interrupt", return_value="user input"):
                result = s.execute(state)
            
        # Verify it didn't crash and returns the state (staying in answering)
        assert result == state
        # The conversation in state should have been updated by _update_conversation
        conv = state[WorkflowKeys.CONVERSATIONS][conv_key]
        assert len(conv) > 0
        assert conv[-1]["content"] == error_msg

