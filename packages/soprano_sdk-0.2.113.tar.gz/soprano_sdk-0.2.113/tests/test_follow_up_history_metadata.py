import uuid
import respx
import json

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    make_tool,
    llm_structured_response,
)


@respx.mock
def test_follow_up_history_and_metadata_preservation():
    """Verify that follow-up LLM sees full history and metadata hints."""
    captured_messages_per_turn = []
    
    context = {"turn": 0}

    def mock_llm(request):
        body = json.loads(request.content)
        messages = body["messages"]
        captured_messages_per_turn.append(messages)
        
        system_prompt = messages[0]["content"]
        
        # Follow-up node identification: use more specific markers than just "CONVERSATION HISTORY:"
        # as collectors now also show history when re-entering or when they have prior context.
        is_follow_up = (
            "post-workflow follow-up assistant" in system_prompt or 
            "RESPONSE FORMAT:" in system_prompt or
            "exactly these fields:" in system_prompt
        )
        
        if is_follow_up:
            return llm_structured_response({
                "bot_response": "Follow-up response",
                "options": [{"text": "Opt1", "subtext": "Sub1"}],
                "is_selectable": True
            })
        else:
            # Collector node (CollectInputNode)
            if context["turn"] == 0:
                context["turn"] += 1
                return llm_structured_response({"bot_response": "Asking for A"})
            else:
                return llm_structured_response({"field_a": "val_a"})

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=mock_llm)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    # 1. Start workflow
    tool.execute(thread_id=tid, initial_context={})

    # 2. Complete workflow -> Transition to outcome -> Interrupt (Follow-up)
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    # 3. Follow-up Turn 1 (User: "How are you?")
    tool.execute(thread_id=tid, user_message="How are you?", initial_context={})

    # 4. Follow-up Turn 2 (User: "What was the result?")
    tool.execute(thread_id=tid, user_message="What was the result?", initial_context={})
    
    # Analyze Prompt for Turn 3 (last turn)
    messages_turn_3 = captured_messages_per_turn[-1]
    system_prompt = messages_turn_3[0]["content"]
    message_history = messages_turn_3[1:]

    # 1. Check for Outcome Message (it's the first assistant message in follow-up history)
    # The FollowUp node injects the outcome message as the first entry in its local conversation.
    assert "val_a" in message_history[0]["content"], "Outcome message missing from first message history"
    
    # 2. Check for Turn 1 User Message in history list
    assert any("How are you?" in m["content"] for m in message_history), "Previous follow-up turn missing from message history"
    
    # 3. Check for Turn 1 Assistant Message in history list
    assert any("Follow-up response" in m["content"] for m in message_history), "Assistant follow-up response missing from message history"
    
    # 4. Check for Collector History in system prompt (prior to follow-up)
    assert "CONVERSATION HISTORY:" in system_prompt
    assert "Asking for A" in system_prompt
    assert "val_a" in system_prompt

    # 5. Check for Metadata Hint in Assistant message history (Turn 1 response)
    assistant_msg = next((m["content"] for m in reversed(message_history) if m["role"] == "assistant"), "")
    assert "Follow-up response" in assistant_msg
    assert "Options: Opt1" in assistant_msg, "Options metadata hint missing from Assistant message"

    print("Verification passed: History and Metadata are preserved in Follow-up node.")
