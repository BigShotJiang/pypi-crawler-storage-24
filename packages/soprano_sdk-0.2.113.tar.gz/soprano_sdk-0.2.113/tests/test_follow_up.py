"""
Unit tests for FollowUpStrategy — pure-logic methods only.
"""
import json
from unittest.mock import MagicMock, patch 


from soprano_sdk.agents.structured_output import FollowUpOutput
from soprano_sdk.core.constants import FOLLOW_UP_NODE, WorkflowKeys
from soprano_sdk.nodes.follow_up import FollowUpStrategy


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_engine_context(
    failure_message: str = "",
    data_fields=None,
    rollback_strategy: str = "history_based",
    history: list = None,
):
    """Return a MagicMock that satisfies FollowUpStrategy.__init__ dependencies."""
    ctx = MagicMock()
    ctx.failure_message = failure_message
    ctx.data_fields = data_fields or []
    ctx.get_config_value.side_effect = lambda key, default=None: (
        rollback_strategy if key == "rollback_strategy" else default
    )
    ctx._aggregate_conversation_history.return_value = history or []
    return ctx


def _make_strategy(
    follow_up_config=None,
    engine_context=None,
    first_step_id: str = "step1",
    node_id: str = FOLLOW_UP_NODE,
) -> FollowUpStrategy:
    if engine_context is None:
        engine_context = _make_engine_context()
    cfg = follow_up_config or {}
    return FollowUpStrategy(
        follow_up_config=cfg,
        engine_context=engine_context,
        first_step_id=first_step_id,
        node_id=node_id,
    )


# ---------------------------------------------------------------------------
# FollowUpOutput — Pydantic model
# ---------------------------------------------------------------------------

class TestFollowUpOutput:
    def test_all_fields_default_to_none_or_false(self):
        out = FollowUpOutput()
        assert out.bot_response is None
        assert out.options is None
        assert out.is_selectable is None
        assert out.intent_change is None
        assert out.out_of_scope is None
        assert not out.restart  # defaults to False

    def test_explicit_values_round_trip(self):
        opts = [{"text": "Yes", "subtext": None}]
        out = FollowUpOutput(
            bot_response="Hello",
            options=opts,
            is_selectable=True,
            intent_change="collect_a",
            out_of_scope="crypto",
            restart=True,
        )
        assert out.bot_response == "Hello"
        assert out.options == opts
        assert out.is_selectable is True
        assert out.intent_change == "collect_a"
        assert out.out_of_scope == "crypto"
        assert out.restart is True

    def test_model_copy_update(self):
        out = FollowUpOutput(bot_response="original")
        updated = out.model_copy(update={"bot_response": "replaced"})
        assert updated.bot_response == "replaced"
        assert out.bot_response == "original"  # original unchanged


# ---------------------------------------------------------------------------
# FollowUpStrategy.__init__
# ---------------------------------------------------------------------------

class TestFollowUpStrategyInit:
    def test_defaults_when_config_empty(self):
        s = _make_strategy()
        assert s.name == "follow_up"
        assert s.max_attempts is None
        assert s.max_history_turns is None
        assert s.on_max_attempts_reached == "Our conversation has ended. Thank you."
        assert s._LLM_INVOCATION_ERROR_FALLBACK == FollowUpStrategy._DEFAULT_LLM_INVOCATION_ERROR_FALLBACK

    def test_config_values_applied(self):
        cfg = {
            "name": "my_follow_up",
            "max_attempts": 5,
            "max_history_turns": 3,
            "on_max_attempts_reached": "Goodbye!",
        }
        s = _make_strategy(follow_up_config=cfg)
        assert s.name == "my_follow_up"
        assert s.max_attempts == 5
        assert s.max_history_turns == 3
        assert s.on_max_attempts_reached == "Goodbye!"

    def test_llm_fallback_uses_engine_failure_message_when_set(self):
        ctx = _make_engine_context(failure_message="Custom error message.")
        s = _make_strategy(engine_context=ctx)
        assert s._LLM_INVOCATION_ERROR_FALLBACK == "Custom error message."

    def test_llm_fallback_uses_default_when_engine_message_empty(self):
        ctx = _make_engine_context(failure_message="")
        s = _make_strategy(engine_context=ctx)
        assert s._LLM_INVOCATION_ERROR_FALLBACK == FollowUpStrategy._DEFAULT_LLM_INVOCATION_ERROR_FALLBACK

    def test_conversation_key_uses_node_id(self):
        s = _make_strategy(node_id="my_workflow_follow_up")
        assert s._conversation_key == "my_workflow_follow_up_conversation"

    def test_conversation_key_default_node_id(self):
        s = _make_strategy()
        assert s._conversation_key == f"{FOLLOW_UP_NODE}_conversation"

    def test_first_step_id_stored(self):
        s = _make_strategy(first_step_id="collect_loan_number")
        assert s.first_step_id == "collect_loan_number"


# ---------------------------------------------------------------------------
# _build_core_instructions
# ---------------------------------------------------------------------------

class TestBuildCoreInstructions:
    def test_contains_key_logic_strings(self):
        s = _make_strategy()
        block = s._build_core_instructions()
        assert "PURPOSE" in block
        assert "DECISION RULES" in block
        assert "intent_change" in block
        assert "restart" in block
        assert "out_of_scope" in block
        assert "bot_response" in block

    def test_returns_non_empty_string(self):
        s = _make_strategy()
        assert s._build_core_instructions().strip()


# ---------------------------------------------------------------------------
# _build_context_summary
# ---------------------------------------------------------------------------

class TestBuildContextSummary:
    def test_no_data_fields_shows_placeholder(self):
        ctx = _make_engine_context(data_fields=[])
        s = _make_strategy(engine_context=ctx)
        result = s._build_context_summary({})
        assert "No data collected yet" in result

    def test_plain_field_value_shown(self):
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}])
        s = _make_strategy(follow_up_config={"accessible_fields": ["loan_id"]}, engine_context=ctx)
        result = s._build_context_summary({"loan_id": "LN123"})
        assert "loan_id" in result
        assert "LN123" in result

    def test_none_field_value_omitted(self):
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}])
        s = _make_strategy(follow_up_config={"accessible_fields": ["loan_id"]}, engine_context=ctx)
        result = s._build_context_summary({"loan_id": None})
        assert "loan_id" not in result

    def test_structured_output_artifact_unwrapped(self):
        """When a collector stores the full structured-output dict as a field value,
        only the actual field value (not 'bot_response') should be surfaced."""
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}])
        s = _make_strategy(follow_up_config={"accessible_fields": ["loan_id"]}, engine_context=ctx)
        # Collector stored {"bot_response": "...", "loan_id": "LN456"}
        state = {"loan_id": {"bot_response": "Please enter loan ID.", "loan_id": "LN456"}}
        result = s._build_context_summary(state)
        assert "LN456" in result
        assert "bot_response" not in result

    def test_structured_artifact_with_null_field_omitted(self):
        """When the actual field inside the artifact is None, it should be omitted."""
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}])
        s = _make_strategy(follow_up_config={"accessible_fields": ["loan_id"]}, engine_context=ctx)
        state = {"loan_id": {"bot_response": "Please enter.", "loan_id": None}}
        result = s._build_context_summary(state)
        assert "loan_id" not in result

    def test_user_query_shown_when_present(self):
        ctx = _make_engine_context(data_fields=[])
        s = _make_strategy(engine_context=ctx)
        result = s._build_context_summary({WorkflowKeys.USER_MESSAGE: "close my account"})
        assert "close my account" in result

    def test_fields_filtered_by_accessible_fields_config(self):
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}, {"name": "secret"}])
        s = _make_strategy(follow_up_config={"accessible_fields": ["loan_id"]}, engine_context=ctx)
        result = s._build_context_summary({"loan_id": "LN123", "secret": "XYZ"})
        assert "loan_id" in result
        assert "secret" not in result
        
    def test_no_fields_accessible_when_config_absent(self):
        ctx = _make_engine_context(data_fields=[{"name": "loan_id"}])
        s = _make_strategy(engine_context=ctx)
        result = s._build_context_summary({"loan_id": "LN123"})
        assert "loan_id" not in result
        assert "No data collected yet" in result


# ---------------------------------------------------------------------------
# _build_conversation_history
# ---------------------------------------------------------------------------

class TestBuildConversationHistory:
    def test_empty_history_returns_none_label(self):
        ctx = _make_engine_context(history=[])
        s = _make_strategy(engine_context=ctx)
        result = s._build_conversation_history({})
        assert "(none)" in result

    def test_plain_text_assistant_message_shown(self):
        ctx = _make_engine_context(history=[
            {"role": "assistant", "content": "Hello there!"},
        ])
        s = _make_strategy(engine_context=ctx)
        result = s._build_conversation_history({})
        assert "Hello there!" in result

    def test_json_blob_with_text_key_unwrapped(self):
        ctx = _make_engine_context(history=[
            {"role": "assistant", "content": json.dumps({"text": "JSON wrapped message", "options": None})},
        ])
        s = _make_strategy(engine_context=ctx)
        result = s._build_conversation_history({})
        assert "JSON wrapped message" in result
        assert '"text"' not in result  # raw JSON key should not be present

    def test_json_blob_with_bot_response_key_unwrapped(self):
        ctx = _make_engine_context(history=[
            {"role": "assistant", "content": json.dumps({"bot_response": "Bot response text"})},
        ])
        s = _make_strategy(engine_context=ctx)
        result = s._build_conversation_history({})
        assert "Bot response text" in result

    def test_capture_only_turn_skipped(self):
        """A JSON assistant message with empty text/bot_response is silently skipped."""
        ctx = _make_engine_context(history=[
            {"role": "assistant", "content": json.dumps({"text": "", "bot_response": ""})},
        ])
        s = _make_strategy(engine_context=ctx)
        result = s._build_conversation_history({})
        # Only header; no ASSISTANT: line
        assert "ASSISTANT:" not in result

    def test_user_message_shown_as_user(self):
        ctx = _make_engine_context(history=[
            {"role": "user", "content": "I have a question."},
        ])
        s = _make_strategy(engine_context=ctx)
        result = s._build_conversation_history({})
        assert "USER: I have a question." in result


# ---------------------------------------------------------------------------
# _build_intent_change_guidance
# ---------------------------------------------------------------------------

class TestBuildIntentChangeGuidance:
    def test_empty_collector_nodes_returns_empty_string(self):
        s = _make_strategy()
        result = s._build_intent_change_guidance({WorkflowKeys.COLLECTOR_NODES: {}})
        assert result == ""

    def test_missing_collector_nodes_key_returns_empty_string(self):
        s = _make_strategy()
        result = s._build_intent_change_guidance({})
        assert result == ""

    def test_collector_nodes_present_in_output(self):
        s = _make_strategy()
        state = {
            WorkflowKeys.COLLECTOR_NODES: {
                "collect_loan_id": "Collect the customer's loan ID",
                "collect_reason": "Collect the reason for closure",
            }
        }
        result = s._build_intent_change_guidance(state)
        assert "INTENT CHANGE" in result
        assert "collect_loan_id" in result
        assert "Collect the customer's loan ID" in result
        assert "collect_reason" in result


# ---------------------------------------------------------------------------
# _build_response_format
# ---------------------------------------------------------------------------

class TestBuildResponseFormat:
    def test_all_six_fields_mentioned(self):
        s = _make_strategy()
        block = s._build_response_format()
        # Should now contain fields from FollowUpOutput
        for field in ("bot_response", "options", "is_selectable", "intent_change", "out_of_scope", "restart", "reasoning"):
            assert field in block, f"Field '{field}' missing from response format block"

    def test_response_format_has_json_label(self):
        s = _make_strategy()
        assert "Final Answer" in s._build_response_format()


# ---------------------------------------------------------------------------
# _to_llm_messages
# ---------------------------------------------------------------------------

class TestToLlmMessages:
    def _make_conv(self, *pairs):
        """Build a conversation list from (role, content) pairs."""
        return [{"role": r, "content": c} for r, c in pairs]

    def test_plain_messages_pass_through(self):
        s = _make_strategy()
        conv = self._make_conv(("assistant", "Hello!"), ("user", "Hi"))
        result = s._to_llm_messages(conv)
        assert result[0] == {"role": "assistant", "content": "Hello!"}

    def test_json_blob_content_unwrapped(self):
        s = _make_strategy()
        blob = json.dumps({"text": "Unwrapped text", "options": None})
        conv = self._make_conv(("assistant", blob))
        result = s._to_llm_messages(conv)
        assert result[0]["content"] == "Unwrapped text"

    def test_non_text_json_not_unwrapped(self):
        """JSON with neither 'text' nor 'bot_response' key must NOT be unwrapped."""
        s = _make_strategy()
        blob = json.dumps({"some_other_key": "something"})
        conv = self._make_conv(("assistant", blob))
        result = s._to_llm_messages(conv)
        # Content stays as the raw JSON string since there's no recognised key
        assert result[0]["content"] == blob

    def test_schema_reminder_appended_to_last_user_message(self):
        s = _make_strategy()
        conv = self._make_conv(
            ("assistant", "outcome message"),
            ("user", "my question"),
        )
        result = s._to_llm_messages(conv)
        last_user = next(m for m in reversed(result) if m["role"] == "user")
        assert "reasoning" in last_user["content"]
        assert "bot_response" in last_user["content"]
        assert "IMPORTANT" in last_user["content"]

    def test_schema_reminder_not_appended_if_no_user_message(self):
        """If there are no user messages, _to_llm_messages should not crash."""
        s = _make_strategy()
        conv = self._make_conv(("assistant", "only assistant"))
        result = s._to_llm_messages(conv)
        # Should not raise and assistant content should be unchanged
        assert result[0]["content"] == "only assistant"

    def test_truncation_keeps_first_and_last_n_turns(self):
        s = _make_strategy(follow_up_config={"max_history_turns": 1})
        # Build: [outcome (assistant)] + 4 turns (user+assistant each)
        conv = [{"role": "assistant", "content": "outcome"}]
        for i in range(4):
            conv.append({"role": "user", "content": f"q{i}"})
            conv.append({"role": "assistant", "content": f"a{i}"})
        # Total: 1 + 8 = 9 messages; max_history_turns=1 → keep first + last 2
        result = s._to_llm_messages(conv)
        assert result[0]["content"] == "outcome"  # first preserved
        # Last 2 messages (user q3 + assistant a3) preserved
        contents = [m["content"] for m in result]
        assert "a3" in contents[-1] or "q3" in contents[-2]

    def test_no_truncation_when_within_limit(self):
        s = _make_strategy(follow_up_config={"max_history_turns": 10})
        conv = self._make_conv(
            ("assistant", "outcome"),
            ("user", "q1"),
            ("assistant", "a1"),
        )
        result = s._to_llm_messages(conv)
        # All 3 messages should be present (well within limit of 10)
        assert len([m for m in result if m["role"] != "user" or "IMPORTANT" not in m["content"]]) >= 2

    def test_no_truncation_when_max_history_turns_is_none(self):
        s = _make_strategy()  # max_history_turns=None → unlimited
        conv = []
        for i in range(20):
            conv.append({"role": "user", "content": f"q{i}"})
            conv.append({"role": "assistant", "content": f"a{i}"})
        result = s._to_llm_messages(conv)
        assert len(result) == 40  # 20 user + 20 assistant, no truncation applied


# ---------------------------------------------------------------------------
# _build_conversation_entry
# ---------------------------------------------------------------------------

class TestBuildConversationEntry:
    def test_plain_entry_no_options(self):
        s = _make_strategy()
        entry = s._build_conversation_entry(role="assistant", content="Hello!")
        assert entry == {"role": "assistant", "content": "Hello!"}

    def test_entry_with_options_serialised_to_json(self):
        s = _make_strategy()
        opts = [{"text": "Option A", "subtext": None}]
        entry = s._build_conversation_entry(
            role="assistant",
            content="Choose one:",
            options=opts,
            is_selectable=True,
        )
        assert entry["role"] == "assistant"
        parsed = json.loads(entry["content"])
        assert parsed["bot_response"] == "Choose one:"
        assert parsed["options"] == opts
        assert parsed["is_selectable"] is True

    def test_entry_with_only_is_selectable_serialised(self):
        s = _make_strategy()
        entry = s._build_conversation_entry(role="user", content="hi", is_selectable=False)
        parsed = json.loads(entry["content"])
        assert parsed["is_selectable"] is False

    def test_user_role_preserved(self):
        s = _make_strategy()
        entry = s._build_conversation_entry(role="user", content="question")
        assert entry["role"] == "user"


# ---------------------------------------------------------------------------
# _get_last_interrupt_payload
# ---------------------------------------------------------------------------

class TestGetLastInterruptPayload:
    def test_empty_conversation_returns_empty_text_payload(self):
        s = _make_strategy()
        result = s._get_last_interrupt_payload([])
        assert result["type"] == "follow_up"
        assert result["text"] == ""

    def test_plain_text_assistant_entry(self):
        s = _make_strategy()
        conv = [{"role": "assistant", "content": "Plain answer."}]
        result = s._get_last_interrupt_payload(conv)
        assert result["text"] == "Plain answer."
        assert result["type"] == "follow_up"

    def test_json_blob_entry_unwrapped(self):
        s = _make_strategy()
        opts = [{"text": "Yes", "subtext": None}]
        blob = json.dumps({"text": "Would you like to proceed?", "options": opts, "is_selectable": True})
        conv = [{"role": "assistant", "content": blob}]
        result = s._get_last_interrupt_payload(conv)
        assert result["text"] == "Would you like to proceed?"
        assert result["options"] == opts
        assert result["is_selectable"] is True

    def test_returns_last_assistant_message(self):
        s = _make_strategy()
        conv = [
            {"role": "assistant", "content": "First answer."},
            {"role": "user", "content": "Follow-up question."},
            {"role": "assistant", "content": "Second answer."},
        ]
        result = s._get_last_interrupt_payload(conv)
        assert result["text"] == "Second answer."

    def test_skips_user_messages(self):
        s = _make_strategy()
        conv = [
            {"role": "user", "content": "user only"},
        ]
        result = s._get_last_interrupt_payload(conv)
        assert result["text"] == ""  # no assistant → fallback empty


# ---------------------------------------------------------------------------
# _make_interrupt_payload
# ---------------------------------------------------------------------------

class TestMakeInterruptPayload:
    def test_minimal_payload_has_type_and_text(self):
        s = _make_strategy()
        p = s._make_interrupt_payload("Hello!")
        assert p["type"] == "follow_up"
        assert p["text"] == "Hello!"
        assert "options" not in p
        assert "is_selectable" not in p

    def test_options_included_when_provided(self):
        s = _make_strategy()
        opts = [{"text": "A", "subtext": None}]
        p = s._make_interrupt_payload("Pick one:", options=opts)
        assert p["options"] == opts

    def test_is_selectable_included_when_provided(self):
        s = _make_strategy()
        p = s._make_interrupt_payload("Pick one:", is_selectable=True)
        assert p["is_selectable"] is True

    def test_none_options_not_included(self):
        s = _make_strategy()
        p = s._make_interrupt_payload("msg", options=None, is_selectable=None)
        assert "options" not in p
        assert "is_selectable" not in p


# ---------------------------------------------------------------------------
# _build_oos_payload
# ---------------------------------------------------------------------------

class TestBuildOosPayload:
    def test_basic_oos_payload_fields(self):
        s = _make_strategy(node_id="test_follow_up")
        output = FollowUpOutput(
            bot_response="I can't help with that.",
            out_of_scope="crypto trading",
        )
        p = s._build_oos_payload(output, user_input="buy bitcoin")
        assert p["type"] == "follow_up_out_of_scope"
        assert p["step_id"] == "test_follow_up"
        assert p["reason"] == "crypto trading"
        assert p["bot_response"] == "I can't help with that."
        assert p["user_message"] == "buy bitcoin"

    def test_empty_bot_response_defaults_to_empty_string(self):
        s = _make_strategy()
        output = FollowUpOutput(out_of_scope="topic")
        p = s._build_oos_payload(output, user_input="question")
        assert p["bot_response"] == ""

    def test_options_included_when_set(self):
        s = _make_strategy()
        opts = [{"text": "Related topic A", "subtext": None}]
        output = FollowUpOutput(out_of_scope="topic", options=opts, is_selectable=True)
        p = s._build_oos_payload(output, user_input="q")
        assert p["options"] == opts
        assert p["is_selectable"] is True

    def test_options_omitted_when_none(self):
        s = _make_strategy()
        output = FollowUpOutput(out_of_scope="topic")
        p = s._build_oos_payload(output, user_input="q")
        assert "options" not in p
        assert "is_selectable" not in p


# ---------------------------------------------------------------------------
# _handle_restart
# ---------------------------------------------------------------------------

class TestHandleRestart:


    def test_sets_restart_status(self):
        ctx = _make_engine_context()
        s = _make_strategy(engine_context=ctx)
        state = {}
        result = s._handle_restart(state)
        assert result.get("_status", "").endswith("_restart")


# ---------------------------------------------------------------------------
# _terminate_conversation
# ---------------------------------------------------------------------------

class TestTerminateConversation:
    def test_delivers_farewell_message(self):
        s = _make_strategy(follow_up_config={"on_max_attempts_reached": "Goodbye!"})
        state = {
            WorkflowKeys.FOLLOW_UP_ACTIVE: True,
            WorkflowKeys.FOLLOW_UP_ATTEMPTS: 5,
            WorkflowKeys.FOLLOW_UP_PENDING_PROMPT: {"type": "follow_up", "text": "last msg"},
            WorkflowKeys.OUTCOME_ID: "outcome_success",
        }
        result = s._terminate_conversation(state)
        assert "Goodbye!" in result[WorkflowKeys.MESSAGES]

    def test_clears_all_follow_up_keys(self):
        s = _make_strategy()
        state = {
            WorkflowKeys.FOLLOW_UP_ACTIVE: True,
            WorkflowKeys.FOLLOW_UP_ATTEMPTS: 3,
            WorkflowKeys.FOLLOW_UP_PENDING_PROMPT: {"type": "follow_up", "text": "x"},
            WorkflowKeys.OUTCOME_ID: "outcome_success",
        }
        result = s._terminate_conversation(state)
        assert result[WorkflowKeys.FOLLOW_UP_ACTIVE] is None
        assert result[WorkflowKeys.FOLLOW_UP_ATTEMPTS] is None
        assert result[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] is None
        assert result[WorkflowKeys.OUTCOME_ID] is None

    def test_sets_done_status(self):
        s = _make_strategy()
        result = s._terminate_conversation({})
        assert result.get("_status", "").endswith("_done")

    def test_default_farewell_message(self):
        s = _make_strategy()
        result = s._terminate_conversation({})
        assert "Our conversation has ended. Thank you." in result[WorkflowKeys.MESSAGES]


# ---------------------------------------------------------------------------
# _handle_intent_change
# ---------------------------------------------------------------------------

class TestHandleIntentChange:
    def test_successful_rollback_clears_follow_up_keys(self):
        ctx = _make_engine_context()
        s = _make_strategy(engine_context=ctx)
        rolled_back_state = {
            WorkflowKeys.FOLLOW_UP_ACTIVE: True,
            WorkflowKeys.FOLLOW_UP_ATTEMPTS: 2,
            "field_a": None,
        }
        with patch.object(s, "_rollback_state_to_node", return_value=rolled_back_state):
            result = s._handle_intent_change("collect_a", {})
        assert result[WorkflowKeys.FOLLOW_UP_ACTIVE] is None
        assert result[WorkflowKeys.FOLLOW_UP_ATTEMPTS] is None
        assert result[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] is None

    def test_unknown_node_falls_back_to_self_loop(self):
        ctx = _make_engine_context()
        s = _make_strategy(engine_context=ctx)
        original_state = {WorkflowKeys.FOLLOW_UP_ACTIVE: True}
        with patch.object(s, "_rollback_state_to_node", return_value=None):
            result = s._handle_intent_change("nonexistent_node", original_state)
        # Self-loop: follow_up still active, status set to answering
        assert result.get("_status", "").endswith("_answering")
        assert result.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is True

    def test_rollback_called_with_correct_node(self):
        ctx = _make_engine_context()
        s = _make_strategy(engine_context=ctx)
        with patch.object(s, "_rollback_state_to_node", return_value={"dummy": True}) as mock_rollback:
            s._handle_intent_change("collect_b", {})
        mock_rollback.assert_called_once_with({}, "collect_b", preserve_conversations=True)
