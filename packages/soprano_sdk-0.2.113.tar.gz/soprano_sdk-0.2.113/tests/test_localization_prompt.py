from unittest.mock import MagicMock
from soprano_sdk.core.engine import WorkflowEngine
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.localization import DEFAULT_WAIT_PHRASES, LocalizationRule, LocalizationManager
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from unittest.mock import patch

class TestLocalizationLogic:
    def test_engine_localization_instructions_hindi_devanagari(self):
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {}
        engine._resolve_localization_params.side_effect = lambda state: (
            state.get(WorkflowKeys.TARGET_LANGUAGE),
            state.get(WorkflowKeys.TARGET_SCRIPT)
        )
        engine.get_base_localization_instructions.side_effect = lambda s: WorkflowEngine.get_base_localization_instructions(engine, s)
        
        state = {
            WorkflowKeys.TARGET_LANGUAGE: "hi",
            WorkflowKeys.TARGET_SCRIPT: "devanagari"
        }
        instructions = WorkflowEngine.get_localization_instructions(engine, state)
        assert "HINDI STYLE RULES" in instructions
        assert "आपका रिफंड प्रोसेस हो गया है" in instructions
        assert "HINGLISH STYLE RULES" not in instructions
        assert "You MUST respond in hi using devanagari script only" in instructions

    def test_engine_localization_instructions_hindi_latin(self):
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {}
        engine._resolve_localization_params.side_effect = lambda state: (
            state.get(WorkflowKeys.TARGET_LANGUAGE),
            state.get(WorkflowKeys.TARGET_SCRIPT)
        )
        engine.get_base_localization_instructions.side_effect = lambda s: WorkflowEngine.get_base_localization_instructions(engine, s)
        
        state = {
            WorkflowKeys.TARGET_LANGUAGE: "hi",
            WorkflowKeys.TARGET_SCRIPT: "latin"
        }
        instructions = WorkflowEngine.get_localization_instructions(engine, state)
        assert "HINGLISH STYLE RULES" in instructions
        assert "Aapka refund process ho gaya hai" in instructions
        assert "आपका रिफंड प्रोसेस हो गया है" not in instructions
        assert "You MUST respond in hi using latin script only" in instructions

    def test_engine_localization_instructions_english(self):
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {}
        engine._resolve_localization_params.side_effect = lambda state: (
            state.get(WorkflowKeys.TARGET_LANGUAGE),
            state.get(WorkflowKeys.TARGET_SCRIPT)
        )
        engine.get_base_localization_instructions.side_effect = lambda s: WorkflowEngine.get_base_localization_instructions(engine, s)
        
        state = {
            WorkflowKeys.TARGET_LANGUAGE: "en",
            WorkflowKeys.TARGET_SCRIPT: "latin"
        }
        instructions = WorkflowEngine.get_localization_instructions(engine, state)
        # Should only have generic instructions
        assert "LANGUAGE REQUIREMENT:" in instructions
        assert "HINDI STYLE RULES" not in instructions
        assert "HINGLISH STYLE RULES" not in instructions
        assert "You MUST respond in en using latin script only" in instructions

    def test_engine_wait_phrases_hindi(self):
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {}
        engine._resolve_localization_params.side_effect = lambda state: (
            state.get(WorkflowKeys.TARGET_LANGUAGE),
            state.get(WorkflowKeys.TARGET_SCRIPT)
        )
        
        state = {
            WorkflowKeys.TARGET_LANGUAGE: "hi",
            WorkflowKeys.TARGET_SCRIPT: "devanagari"
        }
        phrases = WorkflowEngine.get_localization_wait_phrases(engine, state)
        assert "ruko" in phrases
        assert "hold on" in phrases
        assert "wait" in phrases

    def test_engine_wait_phrases_english(self):
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {}
        engine._resolve_localization_params.side_effect = lambda state: (
            state.get(WorkflowKeys.TARGET_LANGUAGE),
            state.get(WorkflowKeys.TARGET_SCRIPT)
        )
        
        state = {
            WorkflowKeys.TARGET_LANGUAGE: "en",
            WorkflowKeys.TARGET_SCRIPT: "latin"
        }
        phrases = WorkflowEngine.get_localization_wait_phrases(engine, state)
        assert "ruko" not in phrases
        assert "hold on" in phrases
        assert set(phrases) == set(DEFAULT_WAIT_PHRASES)

    def test_custom_localization_rules_from_yaml(self, tmp_path):
        import yaml
        
        # Create a temporary workflow file with custom rules
        # Using a simple valid step to avoid validation errors
        workflow_content = {
            "name": "Custom Localization",
            "description": "Test",
            "version": "1.0.0",
            "data": [],
            "steps": [{"id": "s1", "action": "call_function", "function": "os.getcwd"}],
            "outcomes": [{"id": "o1", "type": "success", "message": "done"}],
            "localization": {
                "rules": [
                    {
                        "language": "fr",
                        "script": "latin",
                        "instructions": "Talk like a chef.",
                        "examples": "Oui oui baguette.",
                        "wait_phrases": ["un moment", "attendez"]
                    }
                ]
            }
        }
        
        yaml_file = tmp_path / "custom_workflow.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(workflow_content, f)
            
        with patch('soprano_sdk.core.engine.validate_workflow'):
            engine = WorkflowEngine(str(yaml_file), {})
            
        state = {WorkflowKeys.TARGET_LANGUAGE: "fr", WorkflowKeys.TARGET_SCRIPT: "latin"}
        
        instructions = engine.get_localization_instructions(state)
        assert "Talk like a chef." in instructions
        assert "Oui oui baguette." in instructions
        assert "You MUST respond in fr using latin script only" in instructions
        
        phrases = engine.get_localization_wait_phrases(state)
        assert "un moment" in phrases
        assert "attendez" in phrases
        assert "one moment" in phrases # Default

    def test_runtime_localization_overrides(self, tmp_path):
        import yaml
        
        # Base YAML has one rule for 'hi'
        workflow_content = {
            "name": "Base Workflow",
            "description": "Test",
            "version": "1.0.0",
            "data": [],
            "steps": [{"id": "s1", "action": "call_function", "function": "os.getcwd"}],
            "outcomes": [{"id": "o1", "type": "success", "message": "done"}],
            "localization": {
                "rules": [
                    {
                        "language": "hi",
                        "script": "latin",
                        "instructions": "YAML Instructions"
                    }
                ]
            }
        }
        
        yaml_file = tmp_path / "base_workflow.yaml"
        with open(yaml_file, "w") as f:
            yaml.dump(workflow_content, f)
            
        # Runtime config overrides that rule
        runtime_config = {
            "localization": {
                "rules": [
                    {
                        "language": "hi",
                        "script": "latin",
                        "instructions": "RUNTIME OVERRIDE"
                    }
                ]
            }
        }
        
        with patch('soprano_sdk.core.engine.validate_workflow'):
            engine = WorkflowEngine(str(yaml_file), runtime_config)
            
        state = {WorkflowKeys.TARGET_LANGUAGE: "hi", WorkflowKeys.TARGET_SCRIPT: "latin"}
        instructions = engine.get_localization_instructions(state)
        
        assert "RUNTIME OVERRIDE" in instructions
        assert "YAML Instructions" not in instructions

class TestCollectInputLocalizationIntegration:
    def test_instructions_inject_localized_wait_phrases(self):
        engine_context = MagicMock()
        engine_context.get_base_localization_instructions.return_value = "BASE LOCALIZED PROMPT"
        engine_context.get_localization_instructions.return_value = "FULL LOCALIZED PROMPT"
        engine_context.get_localization_wait_phrases.return_value = ["hold on", "wait", "ruko"]
        
        # Mock localization rule for granular injection
        mock_rule = LocalizationRule(
            language="hi",
            script="devanagari",
            instructions="SPECIFIC RULES",
            examples="SPECIFIC EXAMPLES",
            wait_phrases=["ruko"]
        )
        engine_context.get_localization_rule.return_value = mock_rule
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based"
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow"
        
        step_config = {
            "id": "collect_name",
            "field": "user_name",
            "agent": {"name": "test", "instructions": "Ask for name"}
        }
        strategy = CollectInputStrategy(step_config, engine_context)
        state = {}
        
        instructions = strategy._get_instructions(state, {})
        
        assert "BASE LOCALIZED PROMPT" in instructions
        assert "SPECIFIC RULES" in instructions
        assert "SPECIFIC EXAMPLES" in instructions
        assert "ruko" in instructions
        assert "hold on" in instructions
        assert "wait" in instructions


class TestLocalizationManager:
    """Direct unit tests for LocalizationManager logic."""
    
    def test_default_registry_loading(self):
        manager = LocalizationManager()
        # Verify hindi rule exists
        rule = manager.get_rule("hi", "devanagari")
        assert rule.language == "hi"
        assert "HINDI STYLE RULES" in rule.instructions

    def test_custom_rule_overrides(self):
        custom_rule = LocalizationRule(
            language="hi",
            script="devanagari",
            instructions="CUSTOM HINDI"
        )
        manager = LocalizationManager(custom_rules=[custom_rule])
        rule = manager.get_rule("hi", "devanagari")
        assert rule.instructions == "CUSTOM HINDI"
        assert "HINDI STYLE RULES" not in rule.instructions

    def test_language_normalization(self):
        manager = LocalizationManager()
        # Test "Hindi" -> "hi"
        rule1 = manager.get_rule("Hindi", "devanagari")
        assert rule1.language == "hi"
        
        # Test "ENGLISH" -> "en"
        rule2 = manager.get_rule("ENGLISH", "latin")
        assert rule2.language == "en"

    def test_wait_phrases_merging(self):
        manager = LocalizationManager()
        # Standard Hindi has 'ruko'
        phrases = manager.get_wait_phrases("hi", "devanagari")
        assert "ruko" in phrases
        assert "hold on" in phrases
        
        # Custom rule adds a new phrase
        custom_rule = LocalizationRule(
            language="hi",
            script="devanagari",
            wait_phrases=["thahro"]
        )
        manager_custom = LocalizationManager(custom_rules=[custom_rule])
        phrases_custom = manager_custom.get_wait_phrases("hi", "devanagari")
        assert "thahro" in phrases_custom
        # If overridden, registry's 'ruko' is gone because the entire rule is replaced
        assert "ruko" not in phrases_custom 
        assert "hold on" in phrases_custom # Default English is still there

    def test_fallback_behavior(self):
        manager = LocalizationManager()
        # Requesting completely unknown language
        rule = manager.get_rule("swahili", "latin")
        assert rule.language == "swahili"
        assert rule.instructions == "" # Fallback to empty
        
        # Specific instructions for unknown lang should be empty
        instructions = manager.get_specific_instructions("swahili", "latin")
        assert instructions == ""


class TestEngineLocalizationResolution:
    """Tests for WorkflowEngine's parameter resolution and instruction composition."""

    def test_resolve_params_precedence(self):
        # YAML has hi/devanagari
        # State has hi/latin
        # State should win
        engine = MagicMock()
        engine._get_localization_config.return_value = {
            "language": "hi",
            "script": "devanagari"
        }
        
        state = {
            WorkflowKeys.TARGET_LANGUAGE: "hi",
            WorkflowKeys.TARGET_SCRIPT: "latin"
        }
        
        lang, script = WorkflowEngine._resolve_localization_params(engine, state)
        assert lang == "hi"
        assert script == "latin"

    def test_resolve_params_fallback_to_yaml(self):
        # State is empty
        engine = MagicMock()
        engine._get_localization_config.return_value = {
            "language": "hi",
            "script": "devanagari"
        }
        state = {}
        lang, script = WorkflowEngine._resolve_localization_params(engine, state)
        assert lang == "hi"
        assert script == "devanagari"

    def test_generic_instructions_persistence(self):
        # Verify that generic 'instructions' from YAML are included via get_base_localization_instructions
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {
            "instructions": "GLOBAL GUIDELINE"
        }
        # If we resolve to "en", output is "en". If we resolve to None, output is "English".
        engine._resolve_localization_params.return_value = (None, None)
        
        base_inst = WorkflowEngine.get_base_localization_instructions(engine, {})
        assert "GLOBAL GUIDELINE" in base_inst
        assert "You MUST respond in English" in base_inst


class TestEdgeCases:
    """Edge cases and error handling."""

    def test_empty_config_handling(self):
        # Engine with no localization config at all
        engine = MagicMock()
        engine.localization_manager = LocalizationManager()
        engine._get_localization_config.return_value = {}
        engine._resolve_localization_params.return_value = (None, None)
        # Mock internal method dependency to avoid MagicMock returning MagicMock
        engine.get_base_localization_instructions.side_effect = lambda s: WorkflowEngine.get_base_localization_instructions(engine, s)
        
        instructions = WorkflowEngine.get_localization_instructions(engine, {})
        # Should still get the default English base instruction
        assert "You MUST respond in English using Latin script" in instructions

    def test_partial_rule_in_yaml(self):
        # YAML rule with only instructions, no examples/wait_phrases
        custom_rules_data = [
            {"language": "hi", "script": "latin", "instructions": "Only instructions"}
        ]
        engine = MagicMock()
        engine._get_localization_config.return_value = {"rules": custom_rules_data}
        manager = WorkflowEngine.get_localization_manager(engine)
        
        rule = manager.get_rule("hi", "latin")
        assert rule.instructions == "Only instructions"
        assert rule.examples == ""
        assert rule.wait_phrases == []

class TestFollowUpLocalizationIntegration:
    """Verifies that FollowUpStrategy correctly integrates localization into its prompt."""

    def test_follow_up_instructions_composition(self):
        from soprano_sdk.nodes.follow_up import FollowUpStrategy
        
        engine_context = MagicMock()
        engine_context.get_base_localization_instructions.return_value = "BASE LOCALIZED PROMPT"
        engine_context.get_localization_wait_phrases.return_value = ["hold on", "wait", "ruko"]
        
        mock_rule = LocalizationRule(
            language="hi",
            script="devanagari",
            instructions="SPECIFIC RULES",
            examples="SPECIFIC EXAMPLES",
            wait_phrases=["ruko"]
        )
        engine_context.get_localization_rule.return_value = mock_rule
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        
        follow_up_config = {
            "name": "test_follow_up",
            "instructions": "Help the user."
        }
        
        strategy = FollowUpStrategy(follow_up_config, engine_context, first_step_id="s1")
        state = {}
        
        # We need to mock _create_agent or test _build_instructions directly
        # Since _create_agent calls _build_instructions, testing _build_instructions is cleaner
        instructions = strategy._build_instructions(
            state,
            base_localization="BASE LOCALIZED PROMPT",
            localization_rule=mock_rule,
            wait_phrases=["hold on", "wait", "ruko"]
        )
        
        # Assert tags
        assert "<localization>\nBASE LOCALIZED PROMPT\n</localization>" in instructions
        assert "<agent_instructions>" in instructions
        assert "</agent_instructions>" in instructions
        
        # Assert granular rules
        assert "LOCALIZATION GUIDELINES:\nSPECIFIC RULES" in instructions
        assert "LOCALIZATION EXAMPLES:\nSPECIFIC EXAMPLES" in instructions
        
        # Assert localized wait phrases in BOT RESPONSE RULES
        assert 'ruko' in instructions
        assert 'hold on' in instructions
        
        # Assert core instructions
        assert "Help the user." in instructions
        assert "Decide how to handle the user's message" in instructions
