from unittest.mock import MagicMock
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.utils.builtin_tools import MONTY_TOOL_NAME

def test_collect_input_strategy_wraps_tools_and_shares_context():
    """Verify that CollectInputStrategy wraps tools and shares tool responses via state."""
    # Setup mocks
    engine_context = MagicMock()
    
    # Mock a tool in the repository
    def get_user_vibe(name):
        return f"{name} is feeling great!"
    
    # Tool tuple: (name, description, callable)
    engine_context.tool_repository.load.return_value = ("get_user_vibe", "Get user vibe", get_user_vibe)
    
    # Instantiate strategy
    strategy = CollectInputStrategy(
        step_config={
            "id": "test_node", 
            "field": "user_vibe", 
            "agent": {
                "tools": ["get_user_vibe"],
                "default_tools": True
            }
        },
        engine_context=engine_context
    )
    
    # Load tools for an agent turn
    state = {"user_name": "Antigravity"}
    tools = strategy._load_agent_tools(state)
    
    # Find tools
    vibe_tool = next(t[2] for t in tools if t[0] == "get_user_vibe")
    compute_tool = next(t[2] for t in tools if t[0] == MONTY_TOOL_NAME)
    
    # Call the wrapped vibe tool
    vibe_result = vibe_tool(name="Will")
    assert vibe_result == "Will is feeling great!"
    
    # Verify state was updated with tool response
    assert state.get("_tool_responses", {}).get("get_user_vibe_response") == vibe_result
    
    # Verify compute tool can access vibe result automatically
    compute_result = compute_tool(code="get_user_vibe_response")
    assert compute_result == vibe_result

def test_follow_up_strategy_wraps_tools_and_shares_context():
    """Verify that FollowUpStrategy wraps tools and shares tool responses via state."""
    from soprano_sdk.nodes.follow_up import FollowUpStrategy
    
    engine_context = MagicMock()
    def get_weather(city): return f"Sunny in {city}"
    engine_context.tool_repository.load.return_value = ("get_weather", "Get weather", get_weather)
    
    strategy = FollowUpStrategy(
        follow_up_config={"tools": ["get_weather"], "default_tools": True},
        engine_context=engine_context,
        first_step_id="node_1"
    )
    
    state = {}
    tools = strategy._load_tools(state)
    weather_tool = next(t[2] for t in tools if t[0] == "get_weather")
    compute_tool = next(t[2] for t in tools if t[0] == MONTY_TOOL_NAME)
    
    weather_tool(city="London")
    assert state.get("_tool_responses", {}).get("get_weather_response") == "Sunny in London"
    assert compute_tool(code="get_weather_response") == "Sunny in London"
