from soprano_sdk.utils.builtin_tools import make_compute_tool

def test_compute_access_runtime_context():
    """Verify that compute can access outputs from other tools in the same turn."""
    state = {
        "user_id": "123", 
        "internal_secret": "hidden",
        "_tool_responses": {"get_balance_response": 1000.0, "get_tax_rate_response": 0.15}
    }
    
    compute = make_compute_tool(state)
    
    # Test access to state
    assert compute(code="user_id == '123'") == "True"
    
    # Test access to tool responses (other tool output)
    assert compute(code="get_balance_response * (1 - get_tax_rate_response)") == "850.0"
    
    # Test combination of state and tool responses
    assert compute(code="f'User {user_id} final: {get_balance_response * 0.9}'") == "User 123 final: 900.0"

def test_compute_with_none_runtime_context():
    """Verify compute still works when _tool_responses is missing."""
    state = {"x": 10}
    compute = make_compute_tool(state)
    assert compute(code="x * 2") == "20"

def test_compute_priority_runtime_context_over_state():
    """Verify _tool_responses values are accessible."""
    state = {"val": 10, "_tool_responses": {"val_response": 20}}
    compute = make_compute_tool(state)
    assert compute(code="val_response") == "20"
