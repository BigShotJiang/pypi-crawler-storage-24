"""
Shared test utilities for collect_input_with_agent tests.
All test modules import from here to avoid duplication.
"""

import json
from pathlib import Path

import httpx
from langgraph.checkpoint.memory import InMemorySaver
from soprano_sdk.tools import WorkflowTool

FAKE_LLM_URL = "http://fake-llm/v1"
FAKE_LLM_COMPLETIONS = f"{FAKE_LLM_URL}/chat/completions"

MODEL_CONFIG = {
    "model_name": "test-model",
    "provider": "openai",
    "api_key": "test-key",
    "base_url": FAKE_LLM_URL,
}

FIXTURES = Path(__file__).parent / "fixtures"


class CapturingCheckpointer(InMemorySaver):
    """InMemorySaver that skips thread deletion so tests can inspect the final
    state with tool.graph.get_state(config) even after the workflow completes."""

    def delete_thread(self, thread_id: str) -> None:  # type: ignore[override]
        pass  # keep checkpoint; tests will clean up naturally when the object is GC'd


def make_tool(yaml_name: str, checkpointer=None, runtime_config: dict = {}) -> WorkflowTool:
    """Create a WorkflowTool from a fixture YAML file with a CapturingCheckpointer."""
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=checkpointer or CapturingCheckpointer(),
        config={"model_config": MODEL_CONFIG, **runtime_config},
    )


def snap(tool: WorkflowTool, tid: str) -> dict:
    """Return a copy of the current checkpointed workflow state."""
    return tool.graph.get_state({"configurable": {"thread_id": tid}}).values


def follow_up_conv_key(tool: WorkflowTool) -> str:
    """Return the follow-up conversation key for the given tool's workflow."""
    return f"{tool.engine.follow_up_node_id}_conversation"


def llm_text_response(content: str) -> httpx.Response:
    """Pattern matching mode: plain text LLM response."""
    return httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1700000000,
            "model": "test-model",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": content},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        },
    )


def collector_prompt(text="Please tell me field A.") -> httpx.Response:
    """Collector LLM: prompt asking the user for field_a."""
    return llm_structured_response({"bot_response": text, "field_a": None})


def collector_capture(value, field = "field_a") -> httpx.Response:
    """Collector LLM: captures the given field_a value, no prompt."""
    return llm_structured_response({"bot_response": None, field: value})

def collector_intent_change(target_node: str) -> httpx.Response:
    """Collector LLM: captures the intent_change, no prompt."""
    return llm_structured_response({"bot_response": None, "intent_change": target_node})

def fu_answer(text: str, options=None, is_selectable=None) -> httpx.Response:
    """Follow-up LLM: normal Q&A answer (self-loop)."""
    return llm_structured_response({
        "bot_response": text, "options": options, "is_selectable": is_selectable,
        "intent_change": None, "out_of_scope": None, "restart": False,
    })


def fu_intent_change(target_node: str, text: str) -> httpx.Response:
    """Follow-up LLM: intent_change — rollback to target collector node."""
    return llm_structured_response({
        "bot_response": text, "options": None, "is_selectable": None,
        "intent_change": target_node, "out_of_scope": None, "restart": False,
    })


def fu_out_of_scope(reason: str, text: str) -> httpx.Response:
    """Follow-up LLM: out_of_scope — raises interrupt (graph paused, not ended)."""
    return llm_structured_response({
        "bot_response": text, "options": None, "is_selectable": None,
        "intent_change": None, "out_of_scope": reason, "restart": False,
    })


def fu_restart(text: str) -> httpx.Response:
    """Follow-up LLM: restart — clears state, routes to first step."""
    return llm_structured_response({
        "bot_response": text, "options": None, "is_selectable": None,
        "intent_change": None, "out_of_scope": None, "restart": True,
    })


def llm_structured_response(fields: dict) -> httpx.Response:
    """Structured output mode: JSON string in message.content (ProviderStrategy / json_schema format)."""
    return httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1700000000,
            "model": "test-model",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": json.dumps(fields),
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 10, "total_tokens": 20},
        },
    )
