from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Any

from opentelemetry import context as otel_context

from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
from soprano_sdk.utils.logger import logger


def _run_guardrail_with_context(guardrail, response, ctx, last_tool_outputs, check_kwargs):
    """Run a single guardrail check with the parent OTEL context attached."""
    token = otel_context.attach(ctx)
    try:
        return guardrail.check(response, last_tool_outputs=last_tool_outputs, **check_kwargs)
    finally:
        otel_context.detach(token)


def run_guardrails_parallel(
    response: str,
    guardrails: List[BaseGuardrail],
    last_tool_outputs: dict[str, Any],
    **check_kwargs,
) -> List[GuardrailResult]:
    """
    Execute all guardrails concurrently; return results in original order.

    Extra keyword arguments (e.g. grounding_source, query) are forwarded
    to each guardrail's check() method, so mixed lists of functional and
    grounding guardrails can be run together.
    """
    guardrails = [g for g in guardrails if g.is_enabled]
    if not guardrails:
        return []

    results: List[Optional[GuardrailResult]] = [None] * len(guardrails)
    # Capture the current OTEL context so child spans in threads are properly linked
    parent_ctx = otel_context.get_current()

    with ThreadPoolExecutor(max_workers=len(guardrails)) as executor:
        future_to_index = {
            executor.submit(
                _run_guardrail_with_context, g, response, parent_ctx, last_tool_outputs, check_kwargs
            ): i
            for i, g in enumerate(guardrails)
        }
        for future in as_completed(future_to_index):
            idx = future_to_index[future]
            try:
                results[idx] = future.result()
            except Exception as exc:
                logger.error(f"Guardrail at index {idx} raised from future: {exc}")
                results[idx] = GuardrailResult(passed=True)  # fail-open

    return results  # type: ignore[return-value]