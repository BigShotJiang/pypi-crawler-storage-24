"""
Functional guardrails for LLM output validation.

ThoughtActionGuardrail uses crewai.agents.parser.parse() to detect
leaked ReAct reasoning chain tokens (Thought:/Action:) in the final response.
"""
from __future__ import annotations

from ..utils.logger import logger
from ..utils.tracing import trace_guardrail_invocation
from ..utils.parser import convert_to_dict
from .base_guardrail import BaseGuardrail, GuardrailFactory, GuardrailResult
from pydantic import ValidationError


@GuardrailFactory.register("thought_action_check")
class ThoughtActionGuardrail(BaseGuardrail):
    """
    Validates CrewAI response format using crewai.agents.parser.parse().

    Only an AgentFinish result (a proper "Final Answer:" conclusion) is valid.
    Everything else indicates a malformed response:

    - parse() → AgentFinish      : PASS  (agent properly concluded)
    - parse() → AgentAction      : FAIL  (Thought:/Action: leaked)
    - parse() → OutputParserError: FAIL  (missing expected Final Answer: format)
    - Any other exception         : FAIL  (unexpected state)

    Supports retry with regeneration:
    - max_retries: Number of regeneration attempts (default: 1)
    """

    def __init__(self, error_message: str, max_retries: int = 1, is_enabled: bool = True, **kwargs):
        """Initialize with optional retry configuration."""
        super().__init__(error_message, is_enabled=is_enabled)
        self.max_retries = max_retries
        logger.info(f"ThoughtActionGuardrail initialized with max_retries={max_retries}")

    @property
    def regeneration_feedback(self) -> str:
        return (
            "[System: Your previous response contained internal reasoning patterns "
            "(Thought:/Action:) that should not be visible to the user. "
            "Please provide a clean, direct response starting with 'Final Answer:' "
            "containing only the user-facing message.]"
        )

    def check(self, response: str, **kwargs) -> GuardrailResult:
        with trace_guardrail_invocation(guardrail_name="ThoughtActionGuardrail", model="rule-based") as span:
            if span and span.is_recording():
                span.set_attribute("guardrail.input", response)

            react_keywords = ["Thought:", "Action:", "Observation:"]
            passed = True
            failed_keyword = None
            for keyword in react_keywords:
                if keyword in response:
                    passed = False
                    failed_keyword = keyword
                    break

            if span and span.is_recording():
                span.set_attribute("guardrail.passed", passed)
                if failed_keyword:
                    span.set_attribute("guardrail.failed_keyword", failed_keyword)

            if not passed:
                return GuardrailResult(passed=False, error_message=self.error_message)
            return GuardrailResult(passed=True)

@GuardrailFactory.register("structured_output_check")
class StructuredOutputGuardrail(BaseGuardrail):
    """
    Ensures that a structured output response is not empty.

    A response is considered empty if both:
    1. 'bot_response' is null or empty.
    2. No data fields (outside of framework metadata) are populated.

    This prevents 'silent failures' where the agent returns a schema-valid
    but semantically empty response.
    """

    def __init__(self, error_message: str, max_retries: int = 1, is_enabled: bool = True, **kwargs):
        """Initialize with optional retry configuration."""
        super().__init__(error_message, is_enabled=is_enabled)
        self.max_retries = max_retries
        # Stores the most recent ValidationError from schema validation, used in regeneration_feedback.
        self._validation_error: ValidationError | None = None
        logger.info(f"StructuredOutputGuardrail initialized with max_retries={max_retries}")

    @property
    def regeneration_feedback(self) -> str:
        if self._validation_error:
            return (
                f"[System: Your previous response failed schema validation.\n"
                f"Validation error: {self._validation_error}\n"
                f"Ensure all fields have the correct types and format. Please try again.]"
            )
        return (
            "[System: Your previous response was empty or incomplete. "
            "You must provide a conversational 'bot_response'. If providing 'options', "
            "you MUST also provide a 'bot_response' to provide context. "
            "Alternatively, populate the required data fields. Please try again.]"
        )

    def check(self, response: str, **kwargs) -> GuardrailResult:
        self._validation_error = None  # reset per check

        with trace_guardrail_invocation(guardrail_name="StructuredOutputGuardrail", model="rule-based") as span:
            if span and span.is_recording():
                span.set_attribute("guardrail.input", response)

            try:
                data = convert_to_dict(response)
                if span and span.is_recording():
                    span.set_attribute("guardrail.parsed_data", str(data))

                if not isinstance(data, dict):
                    # Plain-text response — no structured output to validate.
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", True)
                        span.set_attribute("guardrail.response_type", "plain_text")
                    return GuardrailResult(passed=True)

                bot_response = data.get("bot_response")
                options = data.get("options")

                # --- Rule 1: options require bot_response ---
                if options and not bot_response:
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", False)
                        span.set_attribute("guardrail.reason", "options_without_bot_response")
                    return GuardrailResult(passed=False, error_message=self.error_message)

                # --- Rule 2: bot_response present → PASS ---
                # Agent gave a conversational clarification; no data to validate.
                if bot_response:
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", True)
                        span.set_attribute("guardrail.has_bot_response", True)
                    return GuardrailResult(passed=True)

                # --- Rule 2: terminal routing fields present → always PASS ---
                # out_of_scope / intent_change / restart are valid structured decisions
                # that don't require the capture sentinel to be set.
                _ROUTING_FIELDS = ("out_of_scope", "intent_change", "restart")
                if any(data.get(f) for f in _ROUTING_FIELDS):
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", True)
                        span.set_attribute("guardrail.has_routing_field", True)
                    return GuardrailResult(passed=True)

                # --- Rule 3: required_fields check ---
                # No bot_response, no routing: agent is attempting to submit captured data.
                # Check that every declared required field is present (not None).
                required_fields: list[str] = kwargs.get("required_fields") or []
                missing = [f for f in required_fields if data.get(f) is None]

                if span and span.is_recording():
                    span.set_attribute("guardrail.has_bot_response", False)
                    span.set_attribute("guardrail.missing_required_fields", str(missing))

                if missing:
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", False)
                    return GuardrailResult(passed=False, error_message=self.error_message)

                # --- Rule 4: schema conformance check ---
                # Run when agent submitted data without bot_response and a schema is available.
                output_schema = kwargs.get("output_schema")
                if output_schema:
                    try:
                        output_schema.model_validate(data)
                    except ValidationError as e:
                        self._validation_error = e
                        if span and span.is_recording():
                            span.set_attribute("guardrail.schema_validation_failed", True)
                            span.set_attribute("guardrail.validation_error", str(e))
                            span.set_attribute("guardrail.passed", False)
                        return GuardrailResult(passed=False, error_message=self.error_message)

                if span and span.is_recording():
                    span.set_attribute("guardrail.passed", True)
                return GuardrailResult(passed=True)

            except (ValueError, SyntaxError, TypeError) as e:
                # Malformed JSON or structure — fail the guardrail
                logger.debug(f"StructuredOutputGuardrail: unexpected parse error: {e}")
                if span and span.is_recording():
                    span.set_attribute("guardrail.passed", False)
                    span.set_attribute("guardrail.parse_error", str(e))
                return GuardrailResult(passed=False, error_message=self.error_message)
