import re

def normalize_text(text: str) -> str:
    """Normalize user message for comparison with previous messages.
    """
    if not text:
        return ""
    text = text.lower().strip()
    # Remove common punctuation
    text = re.sub(r"[^\w\s]", "", text)
    # Collapse multiple spaces
    text = re.sub(r"\s+", " ", text)
    return text

def format_field_name(name: str) -> str:
    """Formats an underscore-separated field name into a proper human-readable format.
    Example: 'user_id' -> 'User Id'
    """
    if not name:
        return ""
    # Replace underscores with spaces
    return name.replace("_", " ")
