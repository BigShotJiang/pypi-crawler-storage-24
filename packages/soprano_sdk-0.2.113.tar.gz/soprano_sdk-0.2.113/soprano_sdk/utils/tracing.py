from opentelemetry import trace
from typing import Any
from contextlib import contextmanager

from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

from ..utils.logger import logger

tracer = trace.get_tracer(__name__)
propagator = TraceContextTextMapPropagator()

_SENSITIVE_KEYS = frozenset({
    "aws_access_key_id",
    "aws_secret_access_key",
    "aws_session_token",
})


class CredentialScrubberSpanProcessor:
    """OTEL SpanProcessor that redacts AWS credentials from span attributes.

    Register with your TracerProvider before exporting spans:

        from opentelemetry.sdk.trace import TracerProvider
        provider = TracerProvider()
        provider.add_span_processor(CredentialScrubberSpanProcessor())
    """

    def on_start(self, span, _parent_context=None):
        self._scrub(span)

    def on_end(self, span):
        self._scrub(span)

    def _scrub(self, span):
        if not span.is_recording():
            return
        for key in list(span.attributes or {}):
            if any(s in key.lower() for s in _SENSITIVE_KEYS):
                span.set_attribute(key, "[REDACTED]")

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return True


@contextmanager
def _create_span(span_name: str, base_attrs: dict, **extra_attrs):
    attrs = {**base_attrs, **extra_attrs}
    with tracer.start_as_current_span(span_name, attributes=attrs) as span:
        yield span


@contextmanager
def trace_node_execution(node_id: str, node_type: str, **attributes):
    with _create_span(f"node.{node_id}", {"node.id": node_id, "node.type": node_type}, **attributes) as span:
        logger.info(f"Started tracing node: {node_id} ({node_type})")
        yield span
        logger.info(f"Finished tracing node: {node_id}")


@contextmanager
def trace_agent_invocation(agent_name: str, model: str, **attributes):
    with _create_span(f"agent.invoke.{agent_name}", {"agent.name": agent_name, "agent.model": model}, **attributes) as span:
        yield span


@contextmanager
def trace_guardrail_invocation(guardrail_name: str, model: str, **attributes):
    with _create_span(f"guardrail.invoke.{guardrail_name}", {"guardrail.name": guardrail_name, "guardrail.model": model}, **attributes) as span:
        yield span


@contextmanager
def trace_workflow_execution(workflow_name: str, **attributes):
    with _create_span("workflow.execute", {"workflow.name": workflow_name}, **attributes) as span:
        yield span


@contextmanager
def trace_validation(step_id: str, field_name: str, **attributes):
    with _create_span(f"validator.{step_id}.{field_name}", {"validation.step_id": step_id, "validation.field": field_name}, **attributes) as span:
        yield span


def add_node_result(span, field: str, value: Any, status: str):
    if span and span.is_recording():
        span.set_attribute(f"field.{field}", str(value) if value is not None else "None")
        span.set_attribute("node.status", status)


def add_agent_result(span, response_length: int, tool_calls: int = 0):
    if span and span.is_recording():
        span.set_attribute("agent.response.length", response_length)
        if tool_calls > 0:
            span.set_attribute("agent.tool_calls.count", tool_calls)
