# File Explorer

A world-class, immersive file gallery and precision crop studio. Visualize, manage, and edit your media with intelligent directory-size transparency and zero-latency hardware acceleration.

### Installation
```bash
pip install file-explorer-viewer
```

## Usage

Run the file explorer in any directory:
```bash
file-explorer
# OR use shorthands
fexplorer
fe
gview
```

### Features
- **Intelligent Directory Size**: Recursive folder size calculation for total transparency.
- **Global Sort**: Mixed sorting across files and folders (Name, Size, Date).
- **Precision Crop Studio**: Dedicated high-performance cropping with common aspect ratios.
- **Universal Downloads**: One-click download for all supported media and code files.
- **Support**: Full support for Images, Videos, Audio, Code, and Markdown.

---
Created by Muhammad Ahmed ([muhammad-ahmed-ghani](https://github.com/muhammad-ahmed-ghani))
