# factumstack_mcp/bridge.py
import asyncio
import httpx
import sys
import os
import json
import logging
from mcp.server import Server
import mcp.types as types
from mcp.server.stdio import stdio_server

# LOGGING CONFIGURATION (Glass Box)
# Redirect logs to stderr to keep stdio transport (stdout) clean
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr
)
logger = logging.getLogger("factumstack-mcp")

# PRODUCTION CONSTANTS
DEFAULT_REMOTE_URL = "https://factumstack-api-131666191475.europe-west1.run.app/api/v1/audit/claim"

server = Server("factumstack-bridge")

@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """Lists available delegated tools from FactumStack backend."""
    return [
        types.Tool(
            name="check_claim",
            description="Audit a scientific claim using FactumStack (Scholar + OpenAlex).",
            inputSchema={
                "type": "object",
                "properties": {
                    "claim": {"type": "string", "description": "The scientific claim to audit."},
                    "max_rigor": {"type": "boolean", "default": False, "description": "Deep dual-swarm search (Plan Developer+)."},
                },
                "required": ["claim"],
            },
        ),
        types.Tool(
            name="get_account_status",
            description="Consult your current plan, capabilities and quotas in FactumStack.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="check_connection",
            description="Validate connectivity and latency with the FactumStack Cloud engine.",
            inputSchema={"type": "object", "properties": {}},
        )
    ]

@server.call_tool()
async def handle_call_tool(name: str, arguments: dict | None) -> list[types.TextContent]:
    """
    Professional bridge to the Cloud Run backend.
    Delegates tool logic to the API endpoints.
    """
    api_key = os.getenv("FACTUMSTACK_API_KEY")
    full_url = os.getenv("FACTUMSTACK_REMOTE_URL", DEFAULT_REMOTE_URL)
    # Extract base URL to navigate between endpoints (/audit vs /auth)
    base_url = full_url.split("/audit/claim")[0]

    if not api_key:
        logger.critical("FACTUMSTACK_API_KEY not found in environment.")
        return [types.TextContent(type="text", text=json.dumps({"error": "FACTUMSTACK_API_KEY not configured."}))]

    async with httpx.AsyncClient(timeout=120.0) as client:
        try:
            if name == "check_claim":
                claim = arguments.get("claim")
                max_rigor = arguments.get("max_rigor", False)
                logger.info(f"Starting audit: '{claim}' (Rigor: {max_rigor})")
                response = await client.post(
                    f"{base_url}/audit/claim",
                    json={"claim": claim, "max_rigor": max_rigor},
                    headers={"Authorization": f"Bearer {api_key}"}
                )
            elif name == "get_account_status":
                logger.info("Checking account status...")
                response = await client.get(
                    f"{base_url}/auth/profile",
                    headers={"Authorization": f"Bearer {api_key}"}
                )
            elif name == "check_connection":
                import time
                start_time = time.perf_counter()
                response = await client.get(f"{base_url}/auth/profile", headers={"Authorization": f"Bearer {api_key}"})
                latency = (time.perf_counter() - start_time) * 1000
                
                profile_data = response.json()
                conn_data = {
                    "status": "connected",
                    "latency_ms": round(latency, 2),
                    "endpoint": base_url,
                    "providers": profile_data.get("system_health", {})
                }
                return [types.TextContent(type="text", text=json.dumps(conn_data, indent=2))]
            else:
                return [types.TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]

            # Unified API Error Handling (Zero-Trust)
            if response.status_code == 401:
                return [types.TextContent(type="text", text=json.dumps({"error": "Invalid or expired API Key."}))]
            
            if response.status_code == 403:
                return [types.TextContent(type="text", text=json.dumps({"error": "Plan does not support this feature (e.g., max_rigor=True)."}))]
            
            response.raise_for_status()
            data = response.json()
            
            # PROFESSIONAL JSON Formatting
            if name == "check_claim":
                audit = data.get("epistemological_audit", {})
                flaws = audit.get("methodological_flaws", [])
                fallacies = audit.get("fallacies_detected", [])
                
                mcp_data = {
                    "factum_score": data.get("factum_score"),
                    "factum_rating": data.get("factum_rating"),
                    "evidence_level": audit.get("evidence_level_found", "N/A"),
                    "summary": data.get("summary"),
                    "critical_flaw": (flaws + fallacies)[0] if (flaws or fallacies) else "None"
                }
                logger.info(f"Audit completed. Score: {mcp_data['factum_score']}")
                return [types.TextContent(type="text", text=json.dumps(mcp_data, indent=2))]
            
            if name == "get_account_status":
                from datetime import datetime
                import time
                q = data.get("quotas", {})
                ident = data.get("identity", {})
                
                reset_ms = q.get('ratelimit_reset_ms')
                time_to_reset = max(0, int((reset_ms - (time.time() * 1000)) / 1000)) if reset_ms is not None else None
                exp = data.get("expires_at")

                account_data = {
                    "identity": {
                        "client_id": ident.get("client_id"),
                        "plan": ident.get("plan", "basic").upper(),
                        "roles": ident.get("roles", []),
                        "permissions": ident.get("permissions", [])
                    },
                    "quotas": {
                        "credits_remaining": q.get("credits_remaining"),
                        "ratelimit_limit": q.get("ratelimit_limit"),
                        "ratelimit_remaining": q.get("ratelimit_remaining"),
                        "ratelimit_reset_seconds": time_to_reset
                    },
                    "features": data.get("features", []),
                    "expires_at_iso": datetime.fromtimestamp(exp/1000).isoformat() if exp else None,
                    "metadata": data.get("metadata", {})
                }
                return [types.TextContent(type="text", text=json.dumps(account_data, indent=2))]
            
        except httpx.TimeoutException:
            logger.error(f"Timeout in tool {name}")
            return [types.TextContent(type="text", text=json.dumps({"error": "The server took too long to respond."}))]
        except Exception as e:
            logger.exception(f"Unexpected error in {name}")
            return [types.TextContent(type="text", text=json.dumps({"error": f"Bridge error: {str(e)}"}))]

async def start_server():
    """Startup the stdio transport server."""
    logger.info("FactumStack MCP Bridge started (Transport: stdio)")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )

def run():
    """Entry point for the factumstack-mcp command."""
    # Load environment variables from .env if available
    try:
        from dotenv import load_dotenv
        load_dotenv()
        logger.info(".env file loaded successfully.")
    except ImportError:
        logger.warning("python-dotenv not installed, skipping .env load.")

    if not os.getenv("FACTUMSTACK_API_KEY"):
        print("CRITICAL: FACTUMSTACK_API_KEY not found.", file=sys.stderr)
        print("Usage: export FACTUMSTACK_API_KEY='your_key' or set it in a .env file", file=sys.stderr)
        sys.exit(1)
        
    try:
        asyncio.run(start_server())
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
        sys.exit(0)

if __name__ == "__main__":
    run()
