#!/usr/bin/env python3
"""mspec CLI 入口"""

import click
from rich.console import Console

from mspec import __version__
from mspec.commands import doctor, init, update
from mspec.utils.console import print_banner

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="mspec")
@click.option("--verbose", "-v", is_flag=True, help="显示详细日志")
@click.pass_context
def cli(ctx: click.Context, verbose: bool) -> None:
    """mspec（Member Spec）- 会员组规范驱动开发工作流 CLI 工具

    快速开始:
        mspec init           初始化项目配置
        mspec doctor         检查环境配置
        mspec update         更新模板到最新版本

    更多信息: https://github.com/mspec-dev/mspec
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose


# 注册命令
cli.add_command(init.init_cmd)
cli.add_command(update.update_cmd)
cli.add_command(doctor.doctor_cmd)


def main() -> None:
    """主入口函数"""
    print_banner()
    cli()


if __name__ == "__main__":
    main()
