#!/usr/bin/env python3
"""update 命令实现"""

import shutil
from datetime import datetime
from pathlib import Path

import click
import semver
from rich.console import Console

from mspec.core.config import ConfigManager
from mspec.core.template import TemplateManager
from mspec.utils.console import print_error, print_success, print_warning

console = Console()


@click.command(name="update")
@click.option("--check", is_flag=True, help="仅检查更新，不执行更新")
def update_cmd(check: bool) -> None:
    """更新模板到最新版本

    自动检测并更新到最新版本的模板，同时保留用户的自定义配置。

    示例:
        mspec update          # 更新到最新版本
        mspec update --check  # 仅检查是否有更新
    """
    console.print("[bold blue]🔄 检查更新...[/bold blue]\n")

    # 检查当前版本
    openspec_path = Path("openspec")
    if not openspec_path.exists():
        print_error("未找到 openspec/ 目录，请先运行 mspec init")
        return

    config_manager = ConfigManager(openspec_path)
    current_version = config_manager.get_version()

    console.print(f"当前版本: [cyan]{current_version}[/cyan]")

    # 获取远程最新版本
    template_manager = TemplateManager()
    try:
        latest_version = template_manager.get_latest_version()
    except Exception as e:
        print_error(f"获取最新版本失败: {e}")
        return

    console.print(f"最新版本: [cyan]{latest_version}[/cyan]")

    # 比较版本
    try:
        if semver.compare(current_version, latest_version) >= 0:
            print_success(f"已是最新版本 ({current_version})")
            return
    except ValueError:
        # 版本号格式错误，继续尝试更新
        pass

    if check:
        print_warning(f"发现新版本: {current_version} → {latest_version}")
        return

    # 执行更新
    console.print(f"\n[yellow]正在更新到 {latest_version}...[/yellow]\n")

    try:
        # 备份旧配置
        backup_path = _backup_config()
        console.print(f"[dim]旧配置已备份到: {backup_path}[/dim]")

        # 下载新模板
        new_templates = template_manager.download_latest()

        # 合并配置
        merged_config = config_manager.merge_with_new(new_templates)

        # 写入新配置
        config_manager.write(merged_config)

        print_success("更新完成!")
        console.print(f"\n[dim]旧配置备份: {backup_path}[/dim]")

    except Exception as e:
        print_error(f"更新失败: {e}")
        console.print("[yellow]建议从备份恢复[/yellow]")


def _backup_config() -> Path:
    """备份当前配置"""
    openspec_path = Path("openspec")
    backup_dir = Path.home() / ".mspec" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"openspec_backup_{timestamp}"

    if backup_path.exists():
        shutil.rmtree(backup_path)

    shutil.copytree(openspec_path, backup_path)
    return backup_path
