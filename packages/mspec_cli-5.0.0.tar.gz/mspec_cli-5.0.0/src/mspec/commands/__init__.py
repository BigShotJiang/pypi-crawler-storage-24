"""mspec 命令模块"""

from mspec.commands.doctor import doctor_cmd
from mspec.commands.init import init_cmd
from mspec.commands.update import update_cmd

__all__ = ["init_cmd", "update_cmd", "doctor_cmd"]
