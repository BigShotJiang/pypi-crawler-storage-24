#!/usr/bin/env python3
"""终端输出工具"""

from rich.console import Console
from rich.text import Text

console = Console()


def print_banner():
    """打印欢迎横幅"""
    banner = Text()
    banner.append("╔══════════════════════════════════════╗\n", style="blue")
    banner.append("║  ", style="blue")
    banner.append("mspec", style="bold cyan")
    banner.append(" · Member Spec · 会员组规范驱动开发║\n", style="blue")
    banner.append("╚══════════════════════════════════════╝", style="blue")
    console.print(banner)
    console.print()


def print_success(message: str):
    """打印成功消息"""
    console.print(f"[bold green]✓[/bold green] {message}")


def print_error(message: str):
    """打印错误消息"""
    console.print(f"[bold red]✗[/bold red] {message}")


def print_warning(message: str):
    """打印警告消息"""
    console.print(f"[bold yellow]⚠[/bold yellow] {message}")


def print_info(message: str):
    """打印信息消息"""
    console.print(f"[dim]{message}[/dim]")
