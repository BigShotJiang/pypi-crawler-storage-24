#!/usr/bin/env python3
"""mspec CLI 入口点"""

from mspec.cli import main

if __name__ == "__main__":
    main()
