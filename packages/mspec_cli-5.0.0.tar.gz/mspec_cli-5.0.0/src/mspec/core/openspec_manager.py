#!/usr/bin/env python3
"""openspec 管理模块

负责检测、安装和调用 openspec
"""

import platform
import shutil
import subprocess
from enum import Enum
from pathlib import Path
from typing import List, Optional

from rich.console import Console

console = Console()


class OpenspecStatus(Enum):
    """openspec 状态"""

    INSTALLED = "installed"  # 已全局安装
    NPX_AVAILABLE = "npx"  # 可通过 npx 运行
    NOT_FOUND = "not_found"  # 未安装且无法自动安装


class OpenspecManager:
    """openspec 管理器

    负责检测、安装和调用 openspec
    """

    PACKAGE_NAME = "@fission-ai/openspec"

    def __init__(self):
        self._status: Optional[OpenspecStatus] = None

    def check(self) -> OpenspecStatus:
        """检查 openspec 可用状态

        Returns:
            OpenspecStatus: 当前状态
        """
        if self._status is not None:
            return self._status

        # 1. 检查全局安装
        # Windows 上优先检查 openspec.cmd，因为 npm 会安装 openspec.cmd
        if self._is_windows():
            if shutil.which("openspec.cmd") or shutil.which("openspec"):
                self._status = OpenspecStatus.INSTALLED
                return self._status
        else:
            if shutil.which("openspec"):
                self._status = OpenspecStatus.INSTALLED
                return self._status

        # 2. 检查 npx 是否可用（Windows 上检查 npx.cmd）
        if self._is_windows():
            if shutil.which("npx.cmd") or shutil.which("npx"):
                self._status = OpenspecStatus.NPX_AVAILABLE
                return self._status
        else:
            if shutil.which("npx"):
                self._status = OpenspecStatus.NPX_AVAILABLE
                return self._status

        self._status = OpenspecStatus.NOT_FOUND
        return self._status

    def _is_windows(self) -> bool:
        """检查是否为 Windows 系统"""
        return platform.system() == "Windows"

    def is_available(self) -> bool:
        """检查是否可用（已安装或可通过 npx 运行）"""
        return self.check() != OpenspecStatus.NOT_FOUND

    def _get_openspec_cmd(self) -> List[str]:
        """获取正确的 openspec 命令

        在 Windows 上，npm 会安装三个文件：
        - openspec (无扩展名的 shell script，Unix 兼容)
        - openspec.cmd (Windows batch 文件)
        - openspec.ps1 (PowerShell 脚本)

        Windows 无法直接执行无扩展名的 shell script，
        所以需要优先使用 .cmd 版本。

        Returns:
            List[str]: 命令列表，如 ["openspec"] 或 ["openspec.cmd"]
        """
        # Windows 优先使用 openspec.cmd
        if self._is_windows():
            # 先尝试直接找 openspec.cmd
            cmd_path = shutil.which("openspec.cmd")
            if cmd_path:
                return [cmd_path]

            # 如果没找到，但找到了 openspec（无扩展名），
            # 尝试在同一目录下找 openspec.cmd
            openspec_path = shutil.which("openspec")
            if openspec_path:
                # 构建 openspec.cmd 的完整路径
                base_path = openspec_path.replace("/openspec", "/openspec.cmd")
                base_path = base_path.replace("\\openspec", "\\openspec.cmd")
                if Path(base_path).exists():
                    return [base_path]

        # 非 Windows 或找不到 .cmd，使用默认命令
        openspec_path = shutil.which("openspec")
        if openspec_path:
            return [openspec_path]

        return ["openspec"]

    def _get_npx_cmd(self) -> List[str]:
        """获取正确的 npx 命令

        Windows 上 npx 也是通过 .cmd 文件调用的
        """
        if self._is_windows():
            # 优先使用 npx.cmd
            npx_cmd = shutil.which("npx.cmd")
            if npx_cmd:
                return [npx_cmd]
        return ["npx"]

    def run(
        self, args: list, cwd: Optional[Path] = None, interactive: bool = False
    ) -> subprocess.CompletedProcess:
        """运行 openspec 命令

        Args:
            args: 命令参数
            cwd: 工作目录
            interactive: 是否为交互模式（True 时直接连接终端，False 时捕获输出）

        Returns:
            subprocess.CompletedProcess: 执行结果

        Raises:
            RuntimeError: 当 openspec 不可用时
        """
        status = self.check()

        if status == OpenspecStatus.INSTALLED:
            cmd = self._get_openspec_cmd() + args
        elif status == OpenspecStatus.NPX_AVAILABLE:
            cmd = self._get_npx_cmd() + [self.PACKAGE_NAME] + args
        else:
            raise RuntimeError("openspec 不可用")

        # Windows 上使用 shell=True，让 cmd 自动处理扩展名
        use_shell = self._is_windows()

        if interactive:
            # 交互模式：直接连接终端，不捕获输出
            return subprocess.run(
                cmd, cwd=str(cwd) if cwd else None, shell=use_shell
            )
        else:
            # 非交互模式：捕获输出
            return subprocess.run(
                cmd,
                cwd=str(cwd) if cwd else None,
                capture_output=True,
                text=True,
                shell=use_shell,
            )

    def _get_npm_cmd(self) -> List[str]:
        """获取正确的 npm 命令

        Windows 上 npm 也是通过 .cmd 文件调用的
        """
        if self._is_windows():
            npm_cmd = shutil.which("npm.cmd")
            if npm_cmd:
                return [npm_cmd]
        return ["npm"]

    def install(self, global_install: bool = True) -> bool:
        """安装 openspec

        Args:
            global_install: 是否全局安装

        Returns:
            bool: 是否安装成功
        """
        # Windows 上检查 npm.cmd
        if self._is_windows():
            if not (shutil.which("npm.cmd") or shutil.which("npm")):
                console.print("[red]✗ npm 未安装，无法自动安装 openspec[/red]")
                return False
        else:
            if not shutil.which("npm"):
                console.print("[red]✗ npm 未安装，无法自动安装 openspec[/red]")
                return False

        try:
            cmd = self._get_npm_cmd() + ["install"]
            if global_install:
                cmd.append("-g")
            cmd.append(self.PACKAGE_NAME)

            console.print(f"[dim]正在执行: {' '.join(cmd)}[/dim]")

            # Windows 上使用 shell=True
            use_shell = self._is_windows()

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=180,  # 3分钟超时
                shell=use_shell,
            )

            if result.returncode == 0:
                # 清除缓存，重新检测
                self._status = None
                console.print("[green]✓ openspec 安装成功[/green]")
                return True
            else:
                # 检查是否是权限问题
                if "EACCES" in result.stderr or "permission" in result.stderr.lower():
                    console.print("[yellow]⚠ 权限不足，无法全局安装[/yellow]")
                else:
                    console.print(f"[red]✗ 安装失败: {result.stderr}[/red]")
                return False

        except subprocess.TimeoutExpired:
            console.print("[red]✗ 安装超时[/red]")
            return False
        except Exception as e:
            console.print(f"[red]✗ 安装出错: {e}[/red]")
            return False

    def print_install_guide(self):
        """打印安装指引"""
        console.print("\n[bold yellow]⚠ openspec 未安装[/bold yellow]")
        console.print("\n请执行以下命令安装:")
        console.print(f"  [cyan]npm install -g {self.PACKAGE_NAME}[/cyan]")
        console.print("\n[dim]如果权限不足，请尝试:[/dim]")
        console.print(f"  [cyan]sudo npm install -g {self.PACKAGE_NAME}[/cyan]")
        console.print("\n或使用 npx（无需安装）:")
        console.print(f"  [cyan]npx {self.PACKAGE_NAME} init[/cyan]")

    def print_npm_not_found_guide(self):
        """打印 npm 未安装的指引"""
        console.print("\n[bold red]✗ npm 未安装[/bold red]")
        console.print("\n[yellow]openspec 需要 Node.js 环境，请安装 Node.js:[/yellow]")
        console.print("  https://nodejs.org/")
        console.print("\n[dim]安装后请重新运行 mspec init[/dim]")

    def print_permission_guide(self):
        """打印权限问题的解决指引"""
        console.print("\n[yellow]⚠ npm 全局安装权限不足[/yellow]")
        console.print("\n解决方案 1 - 使用 npx（推荐，无需安装）:")
        console.print(f"  [cyan]npx {self.PACKAGE_NAME} init[/cyan]")
        console.print("\n解决方案 2 - 修改 npm 权限:")
        console.print("  https://docs.npmjs.com/resolving-eacces-permissions-errors")
        console.print("\n解决方案 3 - 使用 sudo:")
        console.print(f"  [cyan]sudo npm install -g {self.PACKAGE_NAME}[/cyan]")

    def get_version(self) -> Optional[str]:
        """获取 openspec 版本

        Returns:
            Optional[str]: 版本号，如果未安装则返回 None
        """
        if not self.is_available():
            return None

        try:
            result = self.run(["--version"])
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass

        return None
