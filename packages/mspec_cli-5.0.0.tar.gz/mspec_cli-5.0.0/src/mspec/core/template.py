#!/usr/bin/env python3
"""模板管理模块"""

import io
import tarfile
from pathlib import Path
from typing import Dict

import requests
import yaml


class TemplateManager:
    """模板管理器"""

    # GitHub 模板仓库
    DEFAULT_TEMPLATE_REPO = "https://github.com/mspec-dev/mspec-templates"

    def __init__(self):
        self.builtin_path = Path(__file__).parent.parent / "templates"

    def get_builtin_templates(self) -> Dict[str, str]:
        """获取内置模板文件

        Returns:
            文件名到内容的字典
        """
        files = {}

        # config.yaml 写入 openspec/ 根目录
        config_path = self.builtin_path / "config.yaml"
        if config_path.exists():
            files["config.yaml"] = config_path.read_text(encoding="utf-8")

        # .md 模板文件写入 openspec/templates/ 子目录
        template_md_files = [
            "requirement-issue-taxonomy.md",
            "design-issue-taxonomy.md",
            "requirement-issues.md",
            "design-issues.md",
        ]
        for file_name in template_md_files:
            file_path = self.builtin_path / file_name
            if file_path.exists():
                files[f"templates/{file_name}"] = file_path.read_text(encoding="utf-8")

        return files

    def download_from_url(self, url: str) -> Dict[str, str]:
        """从 URL 下载模板

        Args:
            url: 模板仓库 URL (GitHub/GitLab)

        Returns:
            文件名到内容的字典
        """
        # 支持 GitHub 仓库简写
        if "/" in url and not url.startswith(("http://", "https://")):
            url = f"https://github.com/{url}"

        # 下载模板压缩包
        if "github.com" in url:
            return self._download_github_template(url)
        else:
            return self._download_generic_template(url)

    def _download_github_template(self, repo_url: str) -> Dict[str, str]:
        """从 GitHub 下载模板"""
        files = {}

        raw_base = repo_url.replace("github.com", "raw.githubusercontent.com") + "/main/"

        # config.yaml 写入根目录，.md 文件写入 templates/ 子目录
        config_url = f"{raw_base}config.yaml"
        try:
            response = requests.get(config_url, timeout=30)
            if response.status_code == 200:
                files["config.yaml"] = response.text
        except requests.RequestException:
            pass

        md_files = [
            "requirement-issue-taxonomy.md",
            "design-issue-taxonomy.md",
            "requirement-issues.md",
            "design-issues.md",
        ]
        for file_name in md_files:
            url = f"{raw_base}{file_name}"
            try:
                response = requests.get(url, timeout=30)
                if response.status_code == 200:
                    files[f"templates/{file_name}"] = response.text
            except requests.RequestException:
                continue

        return files

    def _download_generic_template(self, url: str) -> Dict[str, str]:
        """从通用 URL 下载模板"""
        response = requests.get(url, timeout=30)
        response.raise_for_status()

        # 假设返回的是 tar.gz 压缩包
        files = {}
        with tarfile.open(fileobj=io.BytesIO(response.content), mode="r:gz") as tar:
            for member in tar.getmembers():
                if member.isfile():
                    f = tar.extractfile(member)
                    if f:
                        content = f.read().decode("utf-8")
                        files[Path(member.name).name] = content

        return files

    def get_latest_version(self) -> str:
        """获取最新版本号

        Returns:
            语义化版本号字符串
        """
        # 从 PyPI 获取最新版本
        try:
            response = requests.get(
                "https://pypi.org/pypi/mspec/json",
                timeout=10
            )
            data = response.json()
            return data["info"]["version"]
        except Exception:
            # 如果获取失败，返回一个默认版本
            return "4.0.0"

    def download_latest(self) -> Dict[str, str]:
        """下载最新版本模板

        Returns:
            文件名到内容的字典
        """
        # 从远程获取最新模板
        return self.download_from_url(self.DEFAULT_TEMPLATE_REPO)
