"""mspec 核心模块"""

from mspec.core.config import ConfigManager
from mspec.core.template import TemplateManager

__all__ = ["ConfigManager", "TemplateManager"]
