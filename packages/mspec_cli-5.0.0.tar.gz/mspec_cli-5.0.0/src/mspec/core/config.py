#!/usr/bin/env python3
"""配置管理模块"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

import yaml


@dataclass
class ValidationResult:
    """验证结果"""
    valid: bool
    errors: List[str] = field(default_factory=list)


class ConfigManager:
    """配置管理器"""

    def __init__(self, openspec_path: Path):
        self.openspec_path = Path(openspec_path)
        self.config_path = self.openspec_path / "config.yaml"

    def get_version(self) -> str:
        """获取当前配置版本"""
        if not self.config_path.exists():
            return "0.0.0"

        try:
            content = yaml.safe_load(self.config_path.read_text(encoding="utf-8"))
            if content and isinstance(content, dict):
                return content.get("version", "4.0.0")
            return "4.0.0"
        except Exception:
            return "4.0.0"

    def validate(self) -> ValidationResult:
        """验证配置是否完整

        Returns:
            验证结果
        """
        errors = []

        # 检查 config.yaml
        if not self.config_path.exists():
            errors.append("未找到 config.yaml")
        else:
            try:
                config = yaml.safe_load(self.config_path.read_text(encoding="utf-8"))
                if not config or not isinstance(config, dict):
                    errors.append("config.yaml 格式错误")
                elif not config.get("schema"):
                    errors.append("config.yaml 缺少 schema 字段")
            except yaml.YAMLError as e:
                errors.append(f"config.yaml 格式错误: {e}")

        # 检查模板文件
        templates_path = self.openspec_path / "templates"
        required_templates = [
            "requirement-issue-taxonomy.md",
            "design-issue-taxonomy.md",
            "requirement-issues.md",
            "design-issues.md",
        ]

        for template in required_templates:
            if not (templates_path / template).exists():
                errors.append(f"缺少模板文件: {template}")

        return ValidationResult(valid=len(errors) == 0, errors=errors)

    def merge_with_new(self, new_templates: Dict[str, str]) -> Dict[str, Any]:
        """合并现有配置与新模板

        Args:
            new_templates: 新模板内容

        Returns:
            合并后的配置
        """
        # 读取现有配置
        current_config = {}
        if self.config_path.exists():
            try:
                current_config = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
            except Exception:
                current_config = {}

        # 解析新配置
        new_config = {}
        if "config.yaml" in new_templates:
            try:
                new_config = yaml.safe_load(new_templates["config.yaml"]) or {}
            except Exception:
                new_config = {}

        # 合并策略：
        # 1. 系统字段使用新版本
        # 2. 用户自定义字段保留
        merged = {
            "schema": new_config.get("schema", "spec-driven"),
            "version": new_config.get("version", "4.0.0"),
            "language": current_config.get("language", new_config.get("language", "zh")),
            "context": self._merge_context(
                current_config.get("context", ""),
                new_config.get("context", "")
            ),
            "rules": self._merge_rules(
                current_config.get("rules", {}),
                new_config.get("rules", {})
            ),
        }

        return merged

    def _merge_context(self, current: str, new: str) -> str:
        """合并 context 字段"""
        if current and new and new not in current:
            return f"{current}\n\n# 以下为新版本添加的内容\n{new}"
        return new or current

    def _merge_rules(self, current: Dict, new: Dict) -> Dict:
        """合并 rules 字段"""
        # 使用新版本的规则为主
        merged = dict(new)

        # 但保留用户的自定义规则
        for key, value in current.items():
            if key not in merged:
                merged[key] = value

        return merged

    def write(self, config: Dict[str, Any]) -> None:
        """写入配置"""
        self.config_path.write_text(
            yaml.dump(config, allow_unicode=True, sort_keys=False),
            encoding="utf-8"
        )
