#!/usr/bin/env python3
"""init 命令测试"""

import pytest
from click.testing import CliRunner

from mspec.cli import cli


def test_init_help():
    """测试 init 命令帮助信息"""
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--help"])
    assert result.exit_code == 0
    assert "初始化 mspec 项目" in result.output


def test_init_dry_run():
    """测试 init 命令 dry-run 模式"""
    runner = CliRunner()
    with runner.isolated_filesystem():
        result = runner.invoke(cli, ["init", "--dry-run", "--yes"])
        assert result.exit_code == 0
        assert "模拟运行" in result.output
