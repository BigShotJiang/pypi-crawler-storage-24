import apim

apim.main()
