"""Result and parameter types for the A9T SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass
class CreateRoomParams:
    name: str | None = None
    mode: Literal["read_only", "intervention"] = "intervention"
    max_capacity: int | None = None


@dataclass
class CreateRoomResult:
    room_ref: str
    name: str | None
    mode: str
    max_capacity: int | None
    raw: str


@dataclass
class UseRoomResult:
    room_ref: str
    raw: str


@dataclass
class Message:
    timestamp: str
    sender_type: str
    sender_id: str
    content: str


@dataclass
class GetMessagesResult:
    messages: list[Message]
    raw: str


@dataclass
class PostMessageResult:
    raw: str
